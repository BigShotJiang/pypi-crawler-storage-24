"""
Ingestion engine.

Executes the full 8-stage ingestion pipeline for each batch of data.
This is the core processing logic that transforms raw connector data
into stored, searchable knowledge.

Pipeline Stages:
1. Validation & Deduplication
2. Normalization (RawItem → Knowledge)
3. Permission Indexing (RawPermission → IndexedVisibility)
4. Chunking & Structuring
5. Embedding Generation (optional)
6. Storage Write (metadata + semantic + graph)
7. Versioning & Audit
8. Error Handling & Stats
"""

from datetime import datetime, timezone
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass, field
import logging

from ..connectors.base import Connector, ExtractionBatch, RawItem
from neurostack.models import (Knowledge, PermissionRecord, RawPermission, IndexedVisibility, PermissionChangeEvent, PermissionChangeType)
from ..storage.interfaces import StorageBackend
from ..processing.normalizer import DataNormalizer, NormalizerConfig
from ..processing.chunking.document_chunker import DocumentChunker
from ..processing.embeddings.embedding_client import EmbeddingClient
from ..utils.deduplication import ContentDeduplicator
from ..utils.exceptions import (
    IngestionError,
    StorageWriteError,
    NormalizationError
)
from ..audit.logger import AuditLogger


# ============================================================================
# LOGGING
# ============================================================================

logger = logging.getLogger("neurostack.pipeline.ingestion_engine")


# ============================================================================
# INGESTION MODELS
# ============================================================================

@dataclass
class BatchResult:
    """
    Result of processing one batch.
    
    Returned by ingestion engine after processing.
    """
    batch_number: int
    items_processed: int = 0
    items_failed: int = 0
    items_skipped: int = 0
    items_deduplicated: int = 0
    
    chunks_created: int = 0
    embeddings_generated: int = 0
    
    storage_writes: int = 0
    permission_records_created: int = 0
    
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    
    processing_time_seconds: float = 0.0


@dataclass
class IngestionEngineConfig:
    """
    Ingestion engine configuration.
    """
    # Processing
    enable_deduplication: bool = True
    enable_chunking: bool = True
    enable_embeddings: bool = False  # Optional
    enable_versioning: bool = True
    
    # Error handling
    stop_on_error: bool = False  # If True, stop batch on first error
    max_errors_per_batch: int = 10  # Stop batch after N errors
    
    # Performance
    batch_commit_size: int = 50  # Commit to storage every N items
    
    # Audit
    detailed_audit_logging: bool = True


# ============================================================================
# INGESTION ENGINE
# ============================================================================

class IngestionEngine:
    """
    Core ingestion engine.
    
    Processes batches through the full 8-stage pipeline:
    1. Validation & Deduplication
    2. Normalization
    3. Permission Indexing
    4. Chunking
    5. Embedding (optional)
    6. Storage
    7. Versioning & Audit
    8. Error Handling
    
    Usage:
        engine = IngestionEngine(storage_backend, audit_logger)
        result = engine.process_batch(batch, connector, job_id)
    """
    
    def __init__(
        self,
        storage_backend: StorageBackend,
        audit_logger: AuditLogger,
        config: Optional[IngestionEngineConfig] = None,
        embedding_client: Optional[EmbeddingClient] = None
    ):
        """
        Initialize ingestion engine.
        
        Args:
            storage_backend: Storage backend for persistence
            audit_logger: Audit logger
            config: Engine configuration (default if None)
            embedding_client: Optional embedding client
        """
        self.storage = storage_backend
        self.audit_logger = audit_logger
        self.config = config or IngestionEngineConfig()
        self.embedding_client = embedding_client
        
        # Initialize processing components
        self.normalizer = DataNormalizer()
        self.deduplicator = ContentDeduplicator()
        self.chunker = DocumentChunker() if self.config.enable_chunking else None
        
        # Stats
        self.total_batches_processed = 0
        self.total_items_processed = 0
        self.total_errors = 0
        
        logger.info("Initialized")
    
    # -------------------------
    # MAIN ENTRY POINT
    # -------------------------
    
    def process_batch(
        self,
        batch: ExtractionBatch,
        connector: Connector,
        job_id: str,
        tenant_id: str
    ) -> Dict[str, Any]:
        """
        Process one extraction batch through full pipeline.
        
        This is the main entry point called by orchestrator.
        
        Args:
            batch: Extraction batch from connector
            connector: Connector instance (for permission extraction)
            job_id: Job identifier (for audit)
            tenant_id: Tenant identifier
            
        Returns:
            Dictionary with processing results
        """
        start_time = datetime.now(timezone.utc)
        
        result = BatchResult(batch_number=batch.batch_number)
        
        logger.info(f"Processing batch {batch.batch_number} ({len(batch.items)} items)")
        
        try:
            # Stage 1: Validation & Deduplication
            valid_items = self._stage_1_validate_and_deduplicate(
                batch.items,
                result
            )
            
            if not valid_items:
                logger.info("No valid items in batch")
                return self._build_result_dict(result, start_time)
            
            # Stage 2: Normalization (RawItem → Knowledge)
            normalized = self._stage_2_normalize(
                valid_items,
                connector,
                tenant_id,
                result
            )
            
            if not normalized:
                logger.info("No items normalized successfully")
                return self._build_result_dict(result, start_time)
            
            # Stage 3: Permission Indexing
            permission_records = self._stage_3_index_permissions(
                normalized,
                tenant_id,
                result
            )
            
            # Stage 4: Chunking & Structuring
            chunks = self._stage_4_chunk(
                normalized,
                result
            )
            
            # Stage 5: Embedding Generation (optional)
            if self.config.enable_embeddings and self.embedding_client:
                embeddings = self._stage_5_generate_embeddings(
                    chunks,
                    result
                )
            else:
                embeddings = []
            
            # Stage 6: Storage Write
            self._stage_6_write_storage(
                normalized,
                permission_records,
                chunks,
                embeddings,
                result
            )
            
            # Stage 7: Versioning & Audit
            self._stage_7_audit_and_version(
                normalized,
                job_id,
                result
            )
            
            # Stage 8: Error Summary
            self._stage_8_finalize(result)
            
            # Update engine stats
            self.total_batches_processed += 1
            self.total_items_processed += result.items_processed
            self.total_errors += result.items_failed
            
            logger.info(f"Batch {batch.batch_number} complete: "
                        f"{result.items_processed} processed, {result.items_failed} failed")
            
            return self._build_result_dict(result, start_time)
        
        except Exception as e:
            logger.error(f"Batch processing failed: {e}")
            result.errors.append(f"Batch processing failed: {str(e)}")
            return self._build_result_dict(result, start_time)
    
    # -------------------------
    # STAGE 1: VALIDATION & DEDUPLICATION
    # -------------------------
    
    def _stage_1_validate_and_deduplicate(
        self,
        items: List[RawItem],
        result: BatchResult
    ) -> List[RawItem]:
        """
        Stage 1: Validate items and remove duplicates.
        
        Args:
            items: Raw items from connector
            result: Result object to update
            
        Returns:
            List of valid, deduplicated items
        """
        valid_items = []
        
        for item in items:
            # Basic validation
            if not self._validate_raw_item(item):
                result.items_skipped += 1
                result.warnings.append(f"Invalid item: {item.source_id}")
                continue
            
            # Deduplication check
            if self.config.enable_deduplication:
                if self.deduplicator.is_duplicate(item):
                    result.items_deduplicated += 1
                    result.warnings.append(f"Duplicate item: {item.source_id}")
                    continue
            
            valid_items.append(item)
        
        logger.info(f"[Stage 1] Validated {len(valid_items)}/{len(items)} items "
                    f"(skipped: {result.items_skipped}, duplicates: {result.items_deduplicated})")
        
        return valid_items
    
    def _validate_raw_item(self, item: RawItem) -> bool:
        """Validate raw item has required fields"""
        if not item.source_id:
            return False
        if not item.source_type:
            return False
        if not item.raw_data:
            return False
        return True
    
    # -------------------------
    # STAGE 2: NORMALIZATION
    # -------------------------
    
    def _stage_2_normalize(
        self,
        items: List[RawItem],
        connector: Connector,
        tenant_id: str,
        result: BatchResult
    ) -> List[Tuple[Knowledge, PermissionMetadata]]:
        """
        Stage 2: Normalize raw items to Knowledge objects.
        
        Args:
            items: Valid raw items
            connector: Connector (for permission extraction)
            tenant_id: Tenant identifier
            result: Result object to update
            
        Returns:
            List of (Knowledge, PermissionMetadata) tuples
        """
        normalized = []
        error_count = 0
        
        for item in items:
            try:
                # Extract permissions first
                from ..connectors.base import PermissionMetadata
                permission_metadata = connector.extract_permissions(item)
                
                # Normalize to Knowledge
                knowledge = self.normalizer.normalize(
                    raw_item=item,
                    permission_metadata=permission_metadata,
                    tenant_id=tenant_id
                )
                
                normalized.append((knowledge, permission_metadata))
                result.items_processed += 1
            
            except NormalizationError as e:
                result.items_failed += 1
                result.errors.append(f"Normalization failed for {item.source_id}: {e}")
                error_count += 1
                
                # Check error threshold
                if self.config.stop_on_error or error_count >= self.config.max_errors_per_batch:
                    logger.warning("[Stage 2] Error threshold reached, stopping batch")
                    break
            
            except Exception as e:
                result.items_failed += 1
                result.errors.append(f"Unexpected error for {item.source_id}: {e}")
                error_count += 1
                
                if self.config.stop_on_error or error_count >= self.config.max_errors_per_batch:
                    break
        
        logger.info(f"[Stage 2] Normalized {len(normalized)}/{len(items)} items")
        
        return normalized
    
    # -------------------------
    # STAGE 3: PERMISSION INDEXING
    # -------------------------
    
    def _stage_3_index_permissions(
        self,
        normalized: List[Tuple[Knowledge, Any]],
        tenant_id: str,
        result: BatchResult
    ) -> List[PermissionRecord]:
        """
        Stage 3: Create permission records (raw + indexed).
        
        Args:
            normalized: List of (Knowledge, PermissionMetadata) tuples
            tenant_id: Tenant identifier
            result: Result object to update
            
        Returns:
            List of PermissionRecord objects
        """
        permission_records = []
        
        for knowledge, permission_metadata in normalized:
            try:
                # Create raw permission record
                raw_permission = RawPermission(
                    content_id=knowledge.id,
                    source_type=knowledge.metadata.source,
                    source_id=knowledge.id.split('_')[-1],  # Extract source ID
                    raw_data=permission_metadata.raw_permissions,
                    extracted_at=datetime.now(timezone.utc)
                )
                
                # Create indexed visibility
                indexed_visibility = self._compute_indexed_visibility(
                    knowledge,
                    permission_metadata
                )
                
                # Create permission record
                permission_record = PermissionRecord(
                    id=f"perm_{knowledge.id}",
                    content_id=knowledge.id,
                    tenant_id=tenant_id,
                    raw=raw_permission,
                    indexed=indexed_visibility
                )
                
                permission_records.append(permission_record)
                result.permission_records_created += 1
            
            except Exception as e:
                result.errors.append(f"Permission indexing failed for {knowledge.id}: {e}")
        
        logger.info(f"[Stage 3] Created {len(permission_records)} permission records")
        
        return permission_records
    
    def _compute_indexed_visibility(
        self,
        knowledge: Knowledge,
        permission_metadata
    ) -> IndexedVisibility:
        """
        Compute indexed visibility from permission metadata.
        
        This is where we convert raw permissions to fast-queryable format.
        """
        from ..models.permission import VisibilityScope
        
        # Determine scope
        if permission_metadata.suggested_scope == "public":
            scope = VisibilityScope.PUBLIC
        elif permission_metadata.suggested_scope == "team":
            scope = VisibilityScope.TEAM
        elif permission_metadata.suggested_scope == "private":
            scope = VisibilityScope.PRIVATE
        else:
            # Infer from visibility
            if knowledge.metadata.visibility.value == "public":
                scope = VisibilityScope.PUBLIC
            elif knowledge.metadata.visibility.value == "team":
                scope = VisibilityScope.TEAM
            else:
                scope = VisibilityScope.PRIVATE
        
        return IndexedVisibility(
            content_id=knowledge.id,
            scope=scope,
            user_ids=permission_metadata.suggested_user_ids or [],
            team_ids=permission_metadata.suggested_team_ids or [],
            computed_at=datetime.now(timezone.utc),
            derived_from=f"raw_perm_{knowledge.id}"
        )
    
    # -------------------------
    # STAGE 4: CHUNKING
    # -------------------------
    
    def _stage_4_chunk(
        self,
        normalized: List[Tuple[Knowledge, Any]],
        result: BatchResult
    ) -> List[Dict[str, Any]]:
        """
        Stage 4: Chunk content for better retrieval.
        
        Args:
            normalized: List of (Knowledge, PermissionMetadata) tuples
            result: Result object to update
            
        Returns:
            List of chunk dictionaries
        """
        if not self.config.enable_chunking or not self.chunker:
            # Return knowledge as single chunks
            return [
                {
                    "content_id": k.id,
                    "chunk_id": f"{k.id}_chunk_0",
                    "content": k.content,
                    "chunk_index": 0,
                    "metadata": k.metadata
                }
                for k, _ in normalized
            ]
        
        all_chunks = []
        
        for knowledge, _ in normalized:
            try:
                # Chunk based on knowledge type
                chunks = self.chunker.chunk_knowledge(knowledge)
                
                for i, chunk in enumerate(chunks):
                    all_chunks.append({
                        "content_id": knowledge.id,
                        "chunk_id": f"{knowledge.id}_chunk_{i}",
                        "content": chunk,
                        "chunk_index": i,
                        "metadata": knowledge.metadata
                    })
                
                result.chunks_created += len(chunks)
            
            except Exception as e:
                result.warnings.append(f"Chunking failed for {knowledge.id}: {e}")
                # Fallback: use full content as single chunk
                all_chunks.append({
                    "content_id": knowledge.id,
                    "chunk_id": f"{knowledge.id}_chunk_0",
                    "content": knowledge.content,
                    "chunk_index": 0,
                    "metadata": knowledge.metadata
                })
        
        logger.info(f"[Stage 4] Created {len(all_chunks)} chunks from {len(normalized)} items")
        
        return all_chunks
    
    # -------------------------
    # STAGE 5: EMBEDDING GENERATION
    # -------------------------
    
    def _stage_5_generate_embeddings(
        self,
        chunks: List[Dict[str, Any]],
        result: BatchResult
    ) -> List[Dict[str, Any]]:
        """
        Stage 5: Generate embeddings for chunks (optional).
        
        Args:
            chunks: List of chunk dictionaries
            result: Result object to update
            
        Returns:
            List of embedding dictionaries
        """
        if not self.embedding_client:
            return []
        
        embeddings = []
        
        # Batch embed for efficiency
        chunk_texts = [c["content"] for c in chunks]
        
        try:
            vectors = self.embedding_client.embed_batch(chunk_texts)
            
            for chunk, vector in zip(chunks, vectors):
                embeddings.append({
                    "chunk_id": chunk["chunk_id"],
                    "content_id": chunk["content_id"],
                    "vector": vector,
                    "metadata": chunk["metadata"]
                })
            
            result.embeddings_generated = len(embeddings)
            logger.info(f"[Stage 5] Generated {len(embeddings)} embeddings")
        
        except Exception as e:
            result.warnings.append(f"Embedding generation failed: {e}")
        
        return embeddings
    
    # -------------------------
    # STAGE 6: STORAGE WRITE
    # -------------------------
    
    def _stage_6_write_storage(
        self,
        normalized: List[Tuple[Knowledge, Any]],
        permission_records: List[PermissionRecord],
        chunks: List[Dict[str, Any]],
        embeddings: List[Dict[str, Any]],
        result: BatchResult
    ) -> None:
        """
        Stage 6: Write to storage (metadata + semantic + graph).
        
        Args:
            normalized: List of (Knowledge, PermissionMetadata) tuples
            permission_records: List of permission records
            chunks: List of chunk dictionaries
            embeddings: List of embedding dictionaries
            result: Result object to update
        """
        write_count = 0
        
        # Write in batches for performance
        batch_size = self.config.batch_commit_size
        
        for i in range(0, len(normalized), batch_size):
            batch_items = normalized[i:i + batch_size]
            batch_perms = permission_records[i:i + batch_size]
            
            for (knowledge, _), perm in zip(batch_items, batch_perms):
                try:
                    # Write to metadata store (knowledge + permissions)
                    self.storage.metadata.write_knowledge(
                        knowledge=knowledge,
                        permission=perm,
                        replace_if_exists=True
                    )
                    
                    write_count += 1
                    result.storage_writes += 1
                
                except StorageWriteError as e:
                    result.errors.append(f"Storage write failed for {knowledge.id}: {e}")
                except Exception as e:
                    result.errors.append(f"Unexpected storage error for {knowledge.id}: {e}")
        
        # Write embeddings to semantic store (if available)
        if embeddings and self.storage.semantic:
            try:
                # Batch write for efficiency
                embedding_tuples = [
                    (e["chunk_id"], e["vector"], self._embedding_metadata(e))
                    for e in embeddings
                ]
                
                written = self.storage.semantic.batch_write(embedding_tuples)
                logger.info(f"[Stage 6] Wrote {written} embeddings to semantic store")
            
            except Exception as e:
                result.warnings.append(f"Semantic store write failed: {e}")
        
        logger.info(f"[Stage 6] Wrote {write_count} items to storage")
    
    def _embedding_metadata(self, embedding: Dict[str, Any]) -> Dict[str, Any]:
        """Build metadata for semantic store"""
        metadata_obj = embedding["metadata"]
        
        return {
            "content_id": embedding["content_id"],
            "chunk_id": embedding["chunk_id"],
            "tenant_id": metadata_obj.tenant_id,
            "source": metadata_obj.source,
            "timestamp": metadata_obj.timestamp.isoformat(),
            "authority": metadata_obj.authority.value,
            "visibility": metadata_obj.visibility.value
        }
    
    # -------------------------
    # STAGE 7: VERSIONING & AUDIT
    # -------------------------
    
    def _stage_7_audit_and_version(
        self,
        normalized: List[Tuple[Knowledge, Any]],
        job_id: str,
        result: BatchResult
    ) -> None:
        """
        Stage 7: Audit logging and versioning.
        
        Args:
            normalized: List of (Knowledge, PermissionMetadata) tuples
            job_id: Job identifier
            result: Result object to update
        """
        # Log ingestion for each item
        for knowledge, _ in normalized:
            try:
                self.audit_logger.log_ingestion(
                    job_id=job_id,
                    content_id=knowledge.id,
                    source_type=knowledge.metadata.source,
                    status="success"
                )
            except Exception as e:
                result.warnings.append(f"Audit logging failed for {knowledge.id}: {e}")
        
        # Version tracking (if enabled)
        if self.config.enable_versioning:
            for knowledge, _ in normalized:
                try:
                    # Check if item already exists
                    existing = self.storage.metadata.get_knowledge_by_id(knowledge.id)
                    
                    if existing:
                        # Create new version
                        version = 2  # TODO: Proper version tracking
                        self.storage.metadata.write_version(
                            content_id=knowledge.id,
                            version=version,
                            knowledge=knowledge,
                            is_active=True
                        )
                except Exception as e:
                    result.warnings.append(f"Versioning failed for {knowledge.id}: {e}")
        
        logger.info("[Stage 7] Audit logging complete")
    
    # -------------------------
    # STAGE 8: FINALIZATION
    # -------------------------
    
    def _stage_8_finalize(self, result: BatchResult) -> None:
        """
        Stage 8: Finalize batch processing.
        
        Args:
            result: Result object to update
        """
        # Check for warnings
        if result.warnings:
            logger.warning(f"[Stage 8] Batch completed with {len(result.warnings)} warnings")
        
        # Check for errors
        if result.errors:
            logger.error(f"[Stage 8] Batch completed with {len(result.errors)} errors")
        
        # Success summary
        success_rate = (
            result.items_processed / (result.items_processed + result.items_failed)
            if (result.items_processed + result.items_failed) > 0
            else 0
        )
        
        logger.info(f"[Stage 8] Batch success rate: {success_rate:.1%}")
    
    # -------------------------
    # HELPERS
    # -------------------------
    
    def _build_result_dict(
        self,
        result: BatchResult,
        start_time: datetime
    ) -> Dict[str, Any]:
        """Build result dictionary for orchestrator"""
        result.processing_time_seconds = (datetime.now(timezone.utc) - start_time).total_seconds()
        
        return {
            "batch_number": result.batch_number,
            "items_processed": result.items_processed,
            "items_failed": result.items_failed,
            "items_skipped": result.items_skipped,
            "items_deduplicated": result.items_deduplicated,
            "chunks_created": result.chunks_created,
            "embeddings_generated": result.embeddings_generated,
            "storage_writes": result.storage_writes,
            "permission_records_created": result.permission_records_created,
            "errors": result.errors,
            "warnings": result.warnings,
            "processing_time_seconds": result.processing_time_seconds
        }
    
    # -------------------------
    # STATS
    # -------------------------
    
    def get_stats(self) -> Dict[str, Any]:
        """Get engine statistics"""
        return {
            "total_batches_processed": self.total_batches_processed,
            "total_items_processed": self.total_items_processed,
            "total_errors": self.total_errors,
            "error_rate": (
                self.total_errors / self.total_items_processed
                if self.total_items_processed > 0
                else 0
            )
        }