"""
PostgreSQL metadata store implementation.

Implements the MetadataStore protocol using PostgreSQL as the backend.
This is the primary storage layer for:
- Knowledge items (content + metadata)
- Permissions (raw + indexed visibility)
- Version history
- Ingestion audit logs
- Connector checkpoints

Design principles:
- Transactional integrity (ACID)
- Efficient indexing for permission filtering
- Partitioning for scale (by tenant_id)
- Foreign key constraints for data integrity
- JSON columns for flexible metadata

Schema is in storage/metadata/schema.sql
"""

import json
import logging
import psycopg2
import psycopg2.extras
from psycopg2 import sql, pool
from typing import List, Optional, Dict, Any, Tuple
from datetime import datetime, timedelta
from contextlib import contextmanager

from ..interfaces import MetadataStore, StorageError, StorageWriteError, StorageReadError


# ============================================================================
# LOGGING
# ============================================================================

logger = logging.getLogger("neurostack.pipeline.storage.metadata.postgres")
from neurostack.models import (Knowledge, KnowledgeType, KnowledgeMetadata, Authority, Visibility, PermissionRecord, RawPermission, IndexedVisibility, PermissionQuery, PermissionChangeEvent, PermissionSyncJob, VisibilityScope)
from ...utils.exceptions import StorageDuplicateError, StorageConnectionError


# ============================================================================
# POSTGRES CONFIGURATION
# ============================================================================

class PostgresConfig:
    """
    PostgreSQL connection configuration.
    """
    
    def __init__(
        self,
        host: str = "localhost",
        port: int = 5432,
        database: str = "neurostack",
        user: str = "postgres",
        password: str = "",
        
        # Connection pooling
        min_connections: int = 2,
        max_connections: int = 10,
        
        # Performance
        connection_timeout: int = 30,
        statement_timeout: int = 60000,  # 60 seconds (milliseconds)
        
        # Features
        use_ssl: bool = False,
        application_name: str = "neurostack-pipeline"
    ):
        self.host = host
        self.port = port
        self.database = database
        self.user = user
        self.password = password
        
        self.min_connections = min_connections
        self.max_connections = max_connections
        
        self.connection_timeout = connection_timeout
        self.statement_timeout = statement_timeout
        
        self.use_ssl = use_ssl
        self.application_name = application_name
    
    def to_connection_string(self) -> str:
        """Build PostgreSQL connection string"""
        params = {
            "host": self.host,
            "port": self.port,
            "dbname": self.database,
            "user": self.user,
            "password": self.password,
            "application_name": self.application_name,
            "connect_timeout": self.connection_timeout
        }
        
        if self.use_ssl:
            params["sslmode"] = "require"
        
        return " ".join(f"{k}={v}" for k, v in params.items())


# ============================================================================
# POSTGRES METADATA STORE
# ============================================================================

class PostgresMetadataStore:
    """
    PostgreSQL implementation of MetadataStore.
    
    Tables:
    - knowledge_items: Core knowledge storage
    - permissions: Permission records (raw + indexed)
    - knowledge_versions: Document version history
    - ingestion_logs: Audit trail
    - connector_checkpoints: Connector state
    - permission_change_events: Permission audit log
    - permission_sync_jobs: Background sync job state
    
    Indexes:
    - knowledge_items: (tenant_id, content_id), (tenant_id, knowledge_type)
    - permissions: (tenant_id, content_id), (user_ids), (team_ids)
    - ingestion_logs: (job_id), (timestamp)
    
    Usage:
        config = PostgresConfig(host="db.example.com", database="neurostack")
        store = PostgresMetadataStore(config)
        
        # Write knowledge
        store.write_knowledge(knowledge, permission_record)
        
        # Query with permissions
        results = store.query_knowledge(permission_query)
    """
    
    def __init__(self, config: PostgresConfig):
        """
        Initialize PostgreSQL metadata store.
        
        Args:
            config: PostgreSQL configuration
        """
        self.config = config
        
        # Connection pool
        try:
            self.pool = psycopg2.pool.ThreadedConnectionPool(
                minconn=config.min_connections,
                maxconn=config.max_connections,
                dsn=config.to_connection_string()
            )
        except psycopg2.Error as e:
            raise StorageConnectionError(f"Failed to connect to PostgreSQL: {e}") from e
        
        logger.info(f"Connected to {config.host}:{config.port}/{config.database}")
    
    # -------------------------
    # CONNECTION MANAGEMENT
    # -------------------------
    
    @contextmanager
    def _get_connection(self):
        """
        Get database connection from pool (context manager).
        
        Yields:
            psycopg2 connection
        """
        conn = None
        try:
            conn = self.pool.getconn()
            
            # Set statement timeout
            with conn.cursor() as cur:
                cur.execute(f"SET statement_timeout = {self.config.statement_timeout}")
            
            yield conn
            conn.commit()
        
        except Exception as e:
            if conn:
                conn.rollback()
            raise
        
        finally:
            if conn:
                self.pool.putconn(conn)
    
    @contextmanager
    def _get_cursor(self):
        """
        Get database cursor (context manager).
        
        Yields:
            psycopg2 cursor (dict cursor for named access)
        """
        with self._get_connection() as conn:
            cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            try:
                yield cursor
            finally:
                cursor.close()
    
    # -------------------------
    # KNOWLEDGE OPERATIONS
    # -------------------------
    
    def write_knowledge(
        self,
        knowledge: Knowledge,
        permission: PermissionRecord,
        replace_if_exists: bool = False
    ) -> str:
        """
        Write knowledge item with permissions.
        
        Args:
            knowledge: Knowledge object
            permission: Permission record
            replace_if_exists: If True, replace existing item
            
        Returns:
            Stored content_id
            
        Raises:
            StorageDuplicateError: If item exists and replace_if_exists=False
            StorageWriteError: If write fails
        """
        try:
            with self._get_cursor() as cur:
                # Check if exists
                cur.execute(
                    "SELECT content_id FROM knowledge_items WHERE content_id = %s",
                    (knowledge.id,)
                )
                exists = cur.fetchone()
                
                if exists and not replace_if_exists:
                    raise StorageDuplicateError(f"Knowledge item already exists: {knowledge.id}")
                
                # Serialize metadata
                metadata_json = self._serialize_knowledge_metadata(knowledge.metadata)
                
                if exists:
                    # Update existing
                    cur.execute("""
                        UPDATE knowledge_items
                        SET content = %s,
                            knowledge_type = %s,
                            metadata = %s,
                            updated_at = CURRENT_TIMESTAMP
                        WHERE content_id = %s
                    """, (
                        knowledge.content,
                        knowledge.type.value,
                        json.dumps(metadata_json),
                        knowledge.id
                    ))
                else:
                    # Insert new
                    cur.execute("""
                        INSERT INTO knowledge_items (
                            content_id, tenant_id, knowledge_type,
                            content, metadata, created_at, updated_at
                        )
                        VALUES (%s, %s, %s, %s, %s, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                    """, (
                        knowledge.id,
                        knowledge.metadata.tenant_id,
                        knowledge.type.value,
                        knowledge.content,
                        json.dumps(metadata_json)
                    ))
                
                # Write permission
                self._write_permission_internal(cur, permission)
                
                return knowledge.id
        
        except StorageDuplicateError:
            raise
        except psycopg2.Error as e:
            raise StorageWriteError(f"Failed to write knowledge: {e}") from e
    
    def get_knowledge_by_id(
        self,
        content_id: str,
        user_id: Optional[str] = None,
        user_teams: Optional[List[str]] = None
    ) -> Optional[Knowledge]:
        """
        Retrieve knowledge item by ID.
        
        If user_id provided, enforces permission filtering.
        
        Args:
            content_id: Content identifier
            user_id: Optional user ID for permission check
            user_teams: Optional user teams for permission check
            
        Returns:
            Knowledge object or None if not found/not authorized
        """
        try:
            with self._get_cursor() as cur:
                if user_id:
                    # Query with permission check
                    cur.execute("""
                        SELECT k.content_id, k.tenant_id, k.knowledge_type,
                               k.content, k.metadata, k.created_at, k.updated_at
                        FROM knowledge_items k
                        JOIN permissions p ON k.content_id = p.content_id
                        WHERE k.content_id = %s
                          AND (
                              -- Public visibility
                              p.indexed->>'scope' = 'public'
                              
                              -- User has explicit access
                              OR %s = ANY(
                                  ARRAY(SELECT jsonb_array_elements_text(p.indexed->'user_ids'))
                              )
                              
                              -- User is in allowed teams
                              OR (
                                  p.indexed->>'scope' = 'team'
                                  AND %s && ARRAY(
                                      SELECT jsonb_array_elements_text(p.indexed->'team_ids')
                                  )
                              )
                          )
                    """, (content_id, user_id, user_teams or []))
                else:
                    # Query without permission check
                    cur.execute("""
                        SELECT content_id, tenant_id, knowledge_type,
                               content, metadata, created_at, updated_at
                        FROM knowledge_items
                        WHERE content_id = %s
                    """, (content_id,))
                
                row = cur.fetchone()
                
                if not row:
                    return None
                
                return self._row_to_knowledge(row)
        
        except psycopg2.Error as e:
            raise StorageReadError(f"Failed to get knowledge: {e}") from e
    
    def query_knowledge(
        self,
        query: PermissionQuery,
        filters: Optional[Dict[str, Any]] = None,
        limit: int = 100,
        offset: int = 0
    ) -> List[Knowledge]:
        """
        Query knowledge items with permission filtering.
        
        Args:
            query: Permission query (user, teams, filters)
            filters: Additional filters (source_type, knowledge_type, date range)
            limit: Maximum results
            offset: Pagination offset
            
        Returns:
            List of knowledge items visible to user
        """
        try:
            with self._get_cursor() as cur:
                # Build WHERE clauses
                where_clauses = []
                params = []
                
                # Tenant filter
                if query.tenant_id:
                    where_clauses.append("k.tenant_id = %s")
                    params.append(query.tenant_id)
                
                # Permission filter (CRITICAL)
                permission_clause = """
                    (
                        -- Public visibility
                        p.indexed->>'scope' = 'public'
                        
                        -- User has explicit access
                        OR %s = ANY(
                            ARRAY(SELECT jsonb_array_elements_text(p.indexed->'user_ids'))
                        )
                        
                        -- User is in allowed teams
                        OR (
                            p.indexed->>'scope' = 'team'
                            AND %s && ARRAY(
                                SELECT jsonb_array_elements_text(p.indexed->'team_ids')
                            )
                        )
                    )
                """
                where_clauses.append(permission_clause)
                params.extend([query.user_id, query.user_teams])
                
                # Additional filters
                if filters:
                    if 'knowledge_type' in filters:
                        where_clauses.append("k.knowledge_type = %s")
                        params.append(filters['knowledge_type'])
                    
                    if 'source_type' in filters:
                        where_clauses.append("k.metadata->>'source' = %s")
                        params.append(filters['source_type'])
                    
                    if 'since' in filters:
                        where_clauses.append("k.updated_at >= %s")
                        params.append(filters['since'])
                
                # Build query
                where_sql = " AND ".join(where_clauses)
                
                cur.execute(f"""
                    SELECT k.content_id, k.tenant_id, k.knowledge_type,
                           k.content, k.metadata, k.created_at, k.updated_at
                    FROM knowledge_items k
                    JOIN permissions p ON k.content_id = p.content_id
                    WHERE {where_sql}
                    ORDER BY k.updated_at DESC
                    LIMIT %s OFFSET %s
                """, params + [limit, offset])
                
                rows = cur.fetchall()
                
                return [self._row_to_knowledge(row) for row in rows]
        
        except psycopg2.Error as e:
            raise StorageReadError(f"Failed to query knowledge: {e}") from e
    
    def delete_knowledge(self, content_id: str) -> bool:
        """
        Delete knowledge item (hard delete).
        
        Args:
            content_id: Content identifier
            
        Returns:
            True if deleted, False if not found
        """
        try:
            with self._get_cursor() as cur:
                cur.execute(
                    "DELETE FROM knowledge_items WHERE content_id = %s",
                    (content_id,)
                )
                return cur.rowcount > 0
        
        except psycopg2.Error as e:
            raise StorageWriteError(f"Failed to delete knowledge: {e}") from e
    
    def mark_inactive(self, content_id: str, reason: str = "") -> bool:
        """
        Soft delete: mark knowledge as inactive.
        
        Args:
            content_id: Content identifier
            reason: Reason for inactivation
            
        Returns:
            True if marked, False if not found
        """
        try:
            with self._get_cursor() as cur:
                cur.execute("""
                    UPDATE knowledge_items
                    SET metadata = jsonb_set(metadata, '{is_active}', 'false'::jsonb),
                        metadata = jsonb_set(metadata, '{inactive_reason}', %s::jsonb),
                        updated_at = CURRENT_TIMESTAMP
                    WHERE content_id = %s
                """, (json.dumps(reason), content_id))
                
                return cur.rowcount > 0
        
        except psycopg2.Error as e:
            raise StorageWriteError(f"Failed to mark inactive: {e}") from e
    
    # -------------------------
    # PERMISSION OPERATIONS
    # -------------------------
    
    def write_permission(self, permission: PermissionRecord) -> str:
        """
        Write or update permission record.
        
        Args:
            permission: Permission record
            
        Returns:
            Permission record ID
        """
        try:
            with self._get_cursor() as cur:
                self._write_permission_internal(cur, permission)
                return permission.id
        
        except psycopg2.Error as e:
            raise StorageWriteError(f"Failed to write permission: {e}") from e
    
    def _write_permission_internal(self, cur, permission: PermissionRecord) -> None:
        """Internal permission write (reuses cursor)"""
        # Serialize permission data
        raw_json = self._serialize_raw_permission(permission.raw)
        indexed_json = self._serialize_indexed_visibility(permission.indexed)
        
        # Upsert permission
        cur.execute("""
            INSERT INTO permissions (
                permission_id, content_id, tenant_id,
                raw, indexed, version,
                created_at, updated_at
            )
            VALUES (%s, %s, %s, %s, %s, %s, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            ON CONFLICT (content_id)
            DO UPDATE SET
                raw = EXCLUDED.raw,
                indexed = EXCLUDED.indexed,
                version = EXCLUDED.version,
                updated_at = CURRENT_TIMESTAMP
        """, (
            permission.id,
            permission.content_id,
            permission.tenant_id,
            json.dumps(raw_json),
            json.dumps(indexed_json),
            permission.version
        ))
    
    def get_permission(self, content_id: str) -> Optional[PermissionRecord]:
        """
        Get permission record for content.
        
        Args:
            content_id: Content identifier
            
        Returns:
            Permission record or None
        """
        try:
            with self._get_cursor() as cur:
                cur.execute("""
                    SELECT permission_id, content_id, tenant_id,
                           raw, indexed, version,
                           created_at, updated_at
                    FROM permissions
                    WHERE content_id = %s
                """, (content_id,))
                
                row = cur.fetchone()
                
                if not row:
                    return None
                
                return self._row_to_permission_record(row)
        
        except psycopg2.Error as e:
            raise StorageReadError(f"Failed to get permission: {e}") from e
    
    def update_indexed_visibility(
        self,
        content_id: str,
        indexed: IndexedVisibility
    ) -> bool:
        """
        Update indexed visibility (fast path for permission changes).
        
        Args:
            content_id: Content identifier
            indexed: New indexed visibility
            
        Returns:
            True if updated
        """
        try:
            with self._get_cursor() as cur:
                indexed_json = self._serialize_indexed_visibility(indexed)
                
                cur.execute("""
                    UPDATE permissions
                    SET indexed = %s,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE content_id = %s
                """, (json.dumps(indexed_json), content_id))
                
                return cur.rowcount > 0
        
        except psycopg2.Error as e:
            raise StorageWriteError(f"Failed to update indexed visibility: {e}") from e
    
    def log_permission_change(self, event: PermissionChangeEvent) -> None:
        """
        Log permission change event (audit trail).
        
        Args:
            event: Permission change event
        """
        try:
            with self._get_cursor() as cur:
                cur.execute("""
                    INSERT INTO permission_change_events (
                        event_id, content_id, change_type,
                        affected_user_ids, affected_team_ids,
                        source_type, reason, timestamp
                    )
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                """, (
                    event.event_id,
                    event.content_id,
                    event.change_type.value,
                    event.affected_user_ids,
                    event.affected_team_ids,
                    event.source_type,
                    event.reason,
                    event.timestamp
                ))
        
        except psycopg2.Error as e:
            # Don't fail writes due to audit log errors
            logger.error(f"Failed to log permission change: {e}")
    
    def get_permission_changes(
        self,
        content_id: Optional[str] = None,
        since: Optional[datetime] = None,
        limit: int = 100
    ) -> List[PermissionChangeEvent]:
        """
        Query permission change history.
        
        Args:
            content_id: Optional filter by content
            since: Optional filter by timestamp
            limit: Maximum results
            
        Returns:
            List of permission change events
        """
        try:
            with self._get_cursor() as cur:
                where_clauses = []
                params = []
                
                if content_id:
                    where_clauses.append("content_id = %s")
                    params.append(content_id)
                
                if since:
                    where_clauses.append("timestamp >= %s")
                    params.append(since)
                
                where_sql = " AND ".join(where_clauses) if where_clauses else "1=1"
                
                cur.execute(f"""
                    SELECT event_id, content_id, change_type,
                           affected_user_ids, affected_team_ids,
                           source_type, reason, timestamp
                    FROM permission_change_events
                    WHERE {where_sql}
                    ORDER BY timestamp DESC
                    LIMIT %s
                """, params + [limit])
                
                rows = cur.fetchall()
                
                return [self._row_to_permission_change_event(row) for row in rows]
        
        except psycopg2.Error as e:
            raise StorageReadError(f"Failed to get permission changes: {e}") from e
    
    # -------------------------
    # VERSIONING OPERATIONS
    # -------------------------
    
    def write_version(
        self,
        content_id: str,
        version: int,
        knowledge: Knowledge,
        is_active: bool = True
    ) -> str:
        """
        Write document version.
        
        Args:
            content_id: Content identifier
            version: Version number
            knowledge: Knowledge object for this version
            is_active: Whether this is the active version
            
        Returns:
            Version ID
        """
        try:
            with self._get_cursor() as cur:
                version_id = f"{content_id}_v{version}"
                
                metadata_json = self._serialize_knowledge_metadata(knowledge.metadata)
                
                cur.execute("""
                    INSERT INTO knowledge_versions (
                        version_id, content_id, version_number,
                        knowledge_type, content, metadata,
                        is_active, created_at
                    )
                    VALUES (%s, %s, %s, %s, %s, %s, %s, CURRENT_TIMESTAMP)
                """, (
                    version_id,
                    content_id,
                    version,
                    knowledge.type.value,
                    knowledge.content,
                    json.dumps(metadata_json),
                    is_active
                ))
                
                # Mark previous versions as inactive
                if is_active:
                    cur.execute("""
                        UPDATE knowledge_versions
                        SET is_active = FALSE
                        WHERE content_id = %s
                          AND version_number < %s
                    """, (content_id, version))
                
                return version_id
        
        except psycopg2.Error as e:
            raise StorageWriteError(f"Failed to write version: {e}") from e
    
    def get_versions(
        self,
        content_id: str,
        limit: int = 10
    ) -> List[Tuple[int, Knowledge, datetime]]:
        """
        Get version history for content.
        
        Args:
            content_id: Content identifier
            limit: Maximum versions to return
            
        Returns:
            List of (version_number, knowledge, timestamp) tuples
        """
        try:
            with self._get_cursor() as cur:
                cur.execute("""
                    SELECT version_number, knowledge_type, content,
                           metadata, created_at
                    FROM knowledge_versions
                    WHERE content_id = %s
                    ORDER BY version_number DESC
                    LIMIT %s
                """, (content_id, limit))
                
                rows = cur.fetchall()
                
                versions = []
                for row in rows:
                    knowledge = self._row_to_knowledge_version(row)
                    versions.append((
                        row['version_number'],
                        knowledge,
                        row['created_at']
                    ))
                
                return versions
        
        except psycopg2.Error as e:
            raise StorageReadError(f"Failed to get versions: {e}") from e
    
    def get_active_version(self, content_id: str) -> Optional[Knowledge]:
        """
        Get currently active version.
        
        Args:
            content_id: Content identifier
            
        Returns:
            Active knowledge version or None
        """
        try:
            with self._get_cursor() as cur:
                cur.execute("""
                    SELECT knowledge_type, content, metadata, created_at
                    FROM knowledge_versions
                    WHERE content_id = %s
                      AND is_active = TRUE
                    ORDER BY version_number DESC
                    LIMIT 1
                """, (content_id,))
                
                row = cur.fetchone()
                
                if not row:
                    return None
                
                return self._row_to_knowledge_version(row, content_id=content_id)
        
        except psycopg2.Error as e:
            raise StorageReadError(f"Failed to get active version: {e}") from e
    
    # -------------------------
    # INGESTION LOGS (AUDIT)
    # -------------------------
    
    def log_ingestion(
        self,
        job_id: str,
        content_id: str,
        source_type: str,
        status: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        Log item ingestion (audit trail).
        
        Args:
            job_id: Ingestion job identifier
            content_id: Content identifier
            source_type: Source connector type
            status: "success" | "failed" | "skipped"
            metadata: Optional additional context
        """
        try:
            with self._get_cursor() as cur:
                cur.execute("""
                    INSERT INTO ingestion_logs (
                        job_id, content_id, source_type,
                        status, metadata, timestamp
                    )
                    VALUES (%s, %s, %s, %s, %s, CURRENT_TIMESTAMP)
                """, (
                    job_id,
                    content_id,
                    source_type,
                    status,
                    json.dumps(metadata) if metadata else None
                ))
        
        except psycopg2.Error as e:
            # Don't fail writes due to audit log errors
            logger.error(f"Failed to log ingestion: {e}")
    
    def get_ingestion_logs(
        self,
        job_id: Optional[str] = None,
        since: Optional[datetime] = None,
        limit: int = 100
    ) -> List[Dict[str, Any]]:
        """
        Query ingestion logs.
        
        Args:
            job_id: Optional filter by job
            since: Optional filter by timestamp
            limit: Maximum results
            
        Returns:
            List of ingestion log records
        """
        try:
            with self._get_cursor() as cur:
                where_clauses = []
                params = []
                
                if job_id:
                    where_clauses.append("job_id = %s")
                    params.append(job_id)
                
                if since:
                    where_clauses.append("timestamp >= %s")
                    params.append(since)
                
                where_sql = " AND ".join(where_clauses) if where_clauses else "1=1"
                
                cur.execute(f"""
                    SELECT job_id, content_id, source_type,
                           status, metadata, timestamp
                    FROM ingestion_logs
                    WHERE {where_sql}
                    ORDER BY timestamp DESC
                    LIMIT %s
                """, params + [limit])
                
                rows = cur.fetchall()
                
                return [dict(row) for row in rows]
        
        except psycopg2.Error as e:
            raise StorageReadError(f"Failed to get ingestion logs: {e}") from e
    
    # -------------------------
    # CONNECTOR STATE
    # -------------------------
    
    def save_connector_checkpoint(
        self,
        connector_id: str,
        checkpoint_data: Dict[str, Any]
    ) -> None:
        """
        Save connector checkpoint (for resume).
        
        Args:
            connector_id: Connector identifier
            checkpoint_data: Checkpoint state
        """
        try:
            with self._get_cursor() as cur:
                cur.execute("""
                    INSERT INTO connector_checkpoints (
                        connector_id, checkpoint_data, updated_at
                    )
                    VALUES (%s, %s, CURRENT_TIMESTAMP)
                    ON CONFLICT (connector_id)
                    DO UPDATE SET
                        checkpoint_data = EXCLUDED.checkpoint_data,
                        updated_at = CURRENT_TIMESTAMP
                """, (connector_id, json.dumps(checkpoint_data)))
        
        except psycopg2.Error as e:
            raise StorageWriteError(f"Failed to save checkpoint: {e}") from e
    
    def get_connector_checkpoint(
        self,
        connector_id: str
    ) -> Optional[Dict[str, Any]]:
        """
        Load connector checkpoint.
        
        Args:
            connector_id: Connector identifier
            
        Returns:
            Checkpoint data or None
        """
        try:
            with self._get_cursor() as cur:
                cur.execute("""
                    SELECT checkpoint_data
                    FROM connector_checkpoints
                    WHERE connector_id = %s
                """, (connector_id,))
                
                row = cur.fetchone()
                
                if not row:
                    return None
                
                return row['checkpoint_data']
        
        except psycopg2.Error as e:
            raise StorageReadError(f"Failed to get checkpoint: {e}") from e
    
    def save_permission_sync_job(self, job: PermissionSyncJob) -> None:
        """Save permission sync job state"""
        try:
            with self._get_cursor() as cur:
                cur.execute("""
                    INSERT INTO permission_sync_jobs (
                        job_id, tenant_id, source_type, status,
                        started_at, completed_at,
                        items_checked, permissions_updated, permissions_revoked,
                        errors, last_cursor, error_messages
                    )
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    ON CONFLICT (job_id)
                    DO UPDATE SET
                        status = EXCLUDED.status,
                        completed_at = EXCLUDED.completed_at,
                        items_checked = EXCLUDED.items_checked,
                        permissions_updated = EXCLUDED.permissions_updated,
                        permissions_revoked = EXCLUDED.permissions_revoked,
                        errors = EXCLUDED.errors,
                        last_cursor = EXCLUDED.last_cursor,
                        error_messages = EXCLUDED.error_messages
                """, (
                    job.job_id,
                    job.tenant_id,
                    job.source_type,
                    job.status,
                    job.started_at,
                    job.completed_at,
                    job.items_checked,
                    job.permissions_updated,
                    job.permissions_revoked,
                    job.errors,
                    job.last_cursor,
                    job.error_messages
                ))
        
        except psycopg2.Error as e:
            raise StorageWriteError(f"Failed to save permission sync job: {e}") from e
    
    def get_permission_sync_job(self, job_id: str) -> Optional[PermissionSyncJob]:
        """Load permission sync job state"""
        try:
            with self._get_cursor() as cur:
                cur.execute("""
                    SELECT job_id, tenant_id, source_type, status,
                           started_at, completed_at,
                           items_checked, permissions_updated, permissions_revoked,
                           errors, last_cursor, error_messages
                    FROM permission_sync_jobs
                    WHERE job_id = %s
                """, (job_id,))
                
                row = cur.fetchone()
                
                if not row:
                    return None
                
                return PermissionSyncJob(
                    job_id=row['job_id'],
                    tenant_id=row['tenant_id'],
                    source_type=row['source_type'],
                    status=row['status'],
                    started_at=row['started_at'],
                    completed_at=row['completed_at'],
                    items_checked=row['items_checked'],
                    permissions_updated=row['permissions_updated'],
                    permissions_revoked=row['permissions_revoked'],
                    errors=row['errors'],
                    last_cursor=row['last_cursor'],
                    error_messages=row['error_messages']
                )
        
        except psycopg2.Error as e:
            raise StorageReadError(f"Failed to get permission sync job: {e}") from e
    
    # -------------------------
    # UTILITIES
    # -------------------------
    
    def health_check(self) -> bool:
        """
        Check if metadata store is healthy.
        
        Returns:
            True if accessible and operational
        """
        try:
            with self._get_cursor() as cur:
                cur.execute("SELECT 1")
                return cur.fetchone() is not None
        except:
            return False
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get storage statistics.
        
        Returns:
            Dictionary with stats
        """
        try:
            with self._get_cursor() as cur:
                stats = {}
                
                # Total knowledge items
                cur.execute("SELECT COUNT(*) FROM knowledge_items")
                stats['total_knowledge_items'] = cur.fetchone()[0]
                
                # Total permissions
                cur.execute("SELECT COUNT(*) FROM permissions")
                stats['total_permissions'] = cur.fetchone()[0]
                
                # Total versions
                cur.execute("SELECT COUNT(*) FROM knowledge_versions")
                stats['total_versions'] = cur.fetchone()[0]
                
                # Total ingestion logs
                cur.execute("SELECT COUNT(*) FROM ingestion_logs")
                stats['total_ingestion_logs'] = cur.fetchone()[0]
                
                # Database size
                cur.execute("""
                    SELECT pg_size_pretty(pg_database_size(current_database()))
                """)
                stats['database_size'] = cur.fetchone()[0]
                
                return stats
        
        except psycopg2.Error as e:
            return {"error": str(e)}
    
    # -------------------------
    # SERIALIZATION HELPERS
    # -------------------------
    
    def _serialize_knowledge_metadata(self, metadata: KnowledgeMetadata) -> Dict[str, Any]:
        """Serialize KnowledgeMetadata to dict"""
        return {
            "timestamp": metadata.timestamp.isoformat(),
            "source": metadata.source,
            "tenant_id": metadata.tenant_id,
            "authority": metadata.authority.value,
            "visibility": metadata.visibility.value,
            "owner": metadata.owner,
            "team_id": metadata.team_id,
            "recency_score": metadata.recency_score
        }
    
    def _serialize_raw_permission(self, raw: RawPermission) -> Dict[str, Any]:
        """Serialize RawPermission to dict"""
        return {
            "content_id": raw.content_id,
            "source_type": raw.source_type,
            "source_id": raw.source_id,
            "raw_data": raw.raw_data,
            "extracted_at": raw.extracted_at.isoformat(),
            "source_url": raw.source_url,
            "extractor_version": raw.extractor_version
        }
    
    def _serialize_indexed_visibility(self, indexed: IndexedVisibility) -> Dict[str, Any]:
        """Serialize IndexedVisibility to dict"""
        return {
            "content_id": indexed.content_id,
            "scope": indexed.scope.value,
            "user_ids": indexed.user_ids,
            "team_ids": indexed.team_ids,
            "role_ids": indexed.role_ids,
            "excluded_user_ids": indexed.excluded_user_ids,
            "computed_at": indexed.computed_at.isoformat(),
            "derived_from": indexed.derived_from,
            "expires_at": indexed.expires_at.isoformat() if indexed.expires_at else None
        }
    
    # -------------------------
    # DESERIALIZATION HELPERS
    # -------------------------
    
    def _row_to_knowledge(self, row: Dict[str, Any]) -> Knowledge:
        """Convert database row to Knowledge object"""
        metadata_dict = row['metadata']
        
        metadata = KnowledgeMetadata(
            timestamp=datetime.fromisoformat(metadata_dict['timestamp']),
            source=metadata_dict['source'],
            tenant_id=metadata_dict['tenant_id'],
            authority=Authority(metadata_dict['authority']),
            visibility=Visibility(metadata_dict['visibility']),
            owner=metadata_dict.get('owner'),
            team_id=metadata_dict.get('team_id'),
            recency_score=metadata_dict.get('recency_score')
        )
        
        return Knowledge(
            id=row['content_id'],
            type=KnowledgeType(row['knowledge_type']),
            content=row['content'],
            metadata=metadata
        )
    
    def _row_to_knowledge_version(self, row: Dict[str, Any], content_id: Optional[str] = None) -> Knowledge:
        """Convert version row to Knowledge object"""
        metadata_dict = row['metadata']
        
        metadata = KnowledgeMetadata(
            timestamp=datetime.fromisoformat(metadata_dict['timestamp']),
            source=metadata_dict['source'],
            tenant_id=metadata_dict['tenant_id'],
            authority=Authority(metadata_dict['authority']),
            visibility=Visibility(metadata_dict['visibility']),
            owner=metadata_dict.get('owner'),
            team_id=metadata_dict.get('team_id')
        )
        
        return Knowledge(
            id=content_id or row.get('content_id', 'unknown'),
            type=KnowledgeType(row['knowledge_type']),
            content=row['content'],
            metadata=metadata
        )
    
    def _row_to_permission_record(self, row: Dict[str, Any]) -> PermissionRecord:
        """Convert database row to PermissionRecord"""
        raw_dict = row['raw']
        indexed_dict = row['indexed']
        
        raw = RawPermission(
            content_id=raw_dict['content_id'],
            source_type=raw_dict['source_type'],
            source_id=raw_dict['source_id'],
            raw_data=raw_dict['raw_data'],
            extracted_at=datetime.fromisoformat(raw_dict['extracted_at']),
            source_url=raw_dict.get('source_url'),
            extractor_version=raw_dict.get('extractor_version', '1.0')
        )
        
        indexed = IndexedVisibility(
            content_id=indexed_dict['content_id'],
            scope=VisibilityScope(indexed_dict['scope']),
            user_ids=indexed_dict.get('user_ids', []),
            team_ids=indexed_dict.get('team_ids', []),
            role_ids=indexed_dict.get('role_ids', []),
            excluded_user_ids=indexed_dict.get('excluded_user_ids', []),
            computed_at=datetime.fromisoformat(indexed_dict['computed_at']),
            derived_from=indexed_dict.get('derived_from', ''),
            expires_at=datetime.fromisoformat(indexed_dict['expires_at']) if indexed_dict.get('expires_at') else None
        )
        
        return PermissionRecord(
            id=row['permission_id'],
            content_id=row['content_id'],
            tenant_id=row['tenant_id'],
            raw=raw,
            indexed=indexed,
            version=row['version'],
            created_at=row['created_at'],
            updated_at=row['updated_at']
        )
    
    def _row_to_permission_change_event(self, row: Dict[str, Any]) -> PermissionChangeEvent:
        """Convert row to PermissionChangeEvent"""
        from ...models.permission import PermissionChangeType
        
        return PermissionChangeEvent(
            event_id=row['event_id'],
            content_id=row['content_id'],
            change_type=PermissionChangeType(row['change_type']),
            affected_user_ids=row['affected_user_ids'],
            affected_team_ids=row['affected_team_ids'],
            source_type=row['source_type'],
            reason=row['reason'],
            timestamp=row['timestamp']
        )
    
    # -------------------------
    # CLEANUP
    # -------------------------
    
    def close(self) -> None:
        """Close connection pool"""
        if self.pool:
            self.pool.closeall()
            logger.info("Connection pool closed")
    
    def __del__(self):
        """Destructor - close pool"""
        try:
            self.close()
        except:
            pass


# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def create_metadata_store(
    host: str = "localhost",
    database: str = "neurostack",
    user: str = "postgres",
    password: str = "",
    **kwargs
) -> PostgresMetadataStore:
    """
    Helper to create PostgreSQL metadata store.
    
    Args:
        host: PostgreSQL host
        database: Database name
        user: Database user
        password: Database password
        **kwargs: Additional PostgresConfig parameters
        
    Returns:
        PostgresMetadataStore instance
    """
    config = PostgresConfig(
        host=host,
        database=database,
        user=user,
        password=password,
        **kwargs
    )
    
    return PostgresMetadataStore(config)