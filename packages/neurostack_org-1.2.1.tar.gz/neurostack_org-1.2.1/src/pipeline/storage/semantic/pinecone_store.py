"""
Pinecone vector store implementation.

Implements the SemanticStore protocol using Pinecone as the backend.
Pinecone is a managed vector database optimized for similarity search.

Features:
- Serverless or pod-based deployment
- Metadata filtering
- Hybrid search (vector + metadata)
- Namespaces for multi-tenancy
- Automatic scaling

Documentation: https://docs.pinecone.io/

Design:
- One index per deployment (all tenants)
- Namespaces for tenant isolation
- Metadata for permission filtering
- Batch upsert for performance
"""

import logging
import time
from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime
import uuid

logger = logging.getLogger("neurostack.pipeline.storage.semantic.pinecone")

try:
    from pinecone import Pinecone, ServerlessSpec, PodSpec
    PINECONE_AVAILABLE = True
except ImportError:
    PINECONE_AVAILABLE = False
    logger.warning("Pinecone not installed. Install with: pip install pinecone-client")

from ..interfaces import SemanticStore, StorageError, StorageWriteError, StorageReadError


# ============================================================================
# PINECONE CONFIGURATION
# ============================================================================

class PineconeConfig:
    """
    Pinecone configuration.
    
    See: https://docs.pinecone.io/docs/overview
    """
    
    def __init__(
        self,
        api_key: str,
        index_name: str = "neurostack",
        
        # Index configuration (for creation)
        dimension: int = 1536,           # Must match embedding model
        metric: str = "cosine",          # "cosine", "euclidean", or "dotproduct"
        
        # Deployment type
        cloud: str = "aws",              # "aws", "gcp", or "azure"
        region: str = "us-east-1",       # Cloud region
        
        # Serverless (recommended) or pod-based
        serverless: bool = True,
        
        # Pod configuration (if serverless=False)
        pod_type: str = "p1.x1",         # Pod size
        pods: int = 1,                   # Number of pods
        replicas: int = 1,               # Number of replicas
        
        # Performance
        batch_size: int = 100,           # Vectors per batch upsert
        max_retries: int = 3,            # Retry failed operations
        timeout: int = 30,               # Request timeout (seconds)
        
        # Multi-tenancy
        use_namespaces: bool = True      # Use namespaces for tenant isolation
    ):
        self.api_key = api_key
        self.index_name = index_name
        self.dimension = dimension
        self.metric = metric
        self.cloud = cloud
        self.region = region
        self.serverless = serverless
        self.pod_type = pod_type
        self.pods = pods
        self.replicas = replicas
        self.batch_size = batch_size
        self.max_retries = max_retries
        self.timeout = timeout
        self.use_namespaces = use_namespaces


# ============================================================================
# PINECONE STORE
# ============================================================================

class PineconeStore:
    """
    Pinecone implementation of SemanticStore.
    
    Stores vector embeddings with metadata for similarity search.
    
    Index structure:
    - ID: {tenant_id}_{content_id}_{chunk_id}
    - Vector: Embedding (dimension specified in config)
    - Metadata:
        - content_id: Content identifier
        - tenant_id: Tenant identifier
        - source_type: Source connector type
        - knowledge_type: Type of knowledge
        - timestamp: ISO format timestamp
        - authority: Authority level
        - visibility: Visibility level
        - user_ids: List of allowed user IDs (for filtering)
        - team_ids: List of allowed team IDs (for filtering)
    
    Namespaces:
    - Used for tenant isolation when use_namespaces=True
    - Format: tenant_{tenant_id}
    
    Usage:
        config = PineconeConfig(
            api_key="...",
            index_name="neurostack",
            dimension=1536
        )
        store = PineconeStore(config)
        
        # Write embedding
        store.write_embedding(
            content_id="doc_123",
            vector=[0.1, 0.2, ...],
            metadata={"tenant_id": "acme", "source_type": "jira"}
        )
        
        # Search
        results = store.search(
            query_vector=[0.1, 0.2, ...],
            filters={"tenant_id": "acme"},
            top_k=10
        )
    """
    
    def __init__(self, config: PineconeConfig):
        """
        Initialize Pinecone store.
        
        Args:
            config: Pinecone configuration
            
        Raises:
            ImportError: If Pinecone not installed
            StorageError: If connection fails
        """
        if not PINECONE_AVAILABLE:
            raise ImportError(
                "Pinecone not installed. Install with: pip install pinecone-client"
            )
        
        self.config = config
        
        # Initialize Pinecone client
        try:
            self.client = Pinecone(api_key=config.api_key)
        except Exception as e:
            raise StorageError(f"Failed to initialize Pinecone client: {e}") from e
        
        # Get or create index
        self.index = self._get_or_create_index()
        
        # Stats
        self.writes = 0
        self.reads = 0
        self.errors = 0
        
        logger.info(f"Connected to index: {config.index_name}")
    
    # -------------------------
    # INDEX MANAGEMENT
    # -------------------------
    
    def _get_or_create_index(self):
        """
        Get existing index or create new one.
        
        Returns:
            Pinecone index object
        """
        index_name = self.config.index_name
        
        # Check if index exists
        existing_indexes = self.client.list_indexes()
        index_names = [idx.name for idx in existing_indexes]
        
        if index_name in index_names:
            logger.info(f"Using existing index: {index_name}")
            return self.client.Index(index_name)
        
        # Create new index
        logger.info(f"Creating new index: {index_name}")
        
        try:
            if self.config.serverless:
                # Serverless deployment (recommended)
                self.client.create_index(
                    name=index_name,
                    dimension=self.config.dimension,
                    metric=self.config.metric,
                    spec=ServerlessSpec(
                        cloud=self.config.cloud,
                        region=self.config.region
                    )
                )
            else:
                # Pod-based deployment
                self.client.create_index(
                    name=index_name,
                    dimension=self.config.dimension,
                    metric=self.config.metric,
                    spec=PodSpec(
                        environment=f"{self.config.cloud}-{self.config.region}",
                        pod_type=self.config.pod_type,
                        pods=self.config.pods,
                        replicas=self.config.replicas
                    )
                )
            
            # Wait for index to be ready
            self._wait_for_index_ready(index_name)
            
            return self.client.Index(index_name)
        
        except Exception as e:
            raise StorageError(f"Failed to create Pinecone index: {e}") from e
    
    def _wait_for_index_ready(self, index_name: str, timeout: int = 60) -> None:
        """
        Wait for index to be ready.
        
        Args:
            index_name: Index name
            timeout: Timeout in seconds
        """
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            try:
                desc = self.client.describe_index(index_name)
                if desc.status.ready:
                    logger.info(f"Index {index_name} is ready")
                    return
            except Exception:
                pass
            
            time.sleep(2)
        
        raise StorageError(f"Index {index_name} not ready after {timeout}s")
    
    # -------------------------
    # WRITE OPERATIONS
    # -------------------------
    
    def write_embedding(
        self,
        content_id: str,
        vector: List[float],
        metadata: Dict[str, Any]
    ) -> None:
        """
        Write embedding vector with metadata.
        
        Args:
            content_id: Content identifier
            vector: Embedding vector
            metadata: Metadata for filtering
            
        Raises:
            StorageWriteError: If write fails
        """
        try:
            # Extract tenant_id for namespace
            tenant_id = metadata.get("tenant_id", "default")
            
            # Generate unique ID
            vector_id = self._generate_vector_id(content_id, metadata)
            
            # Prepare metadata (flatten for Pinecone)
            flat_metadata = self._flatten_metadata(metadata)
            
            # Determine namespace
            namespace = self._get_namespace(tenant_id)
            
            # Upsert vector
            self.index.upsert(
                vectors=[(vector_id, vector, flat_metadata)],
                namespace=namespace
            )
            
            self.writes += 1
        
        except Exception as e:
            self.errors += 1
            raise StorageWriteError(f"Failed to write embedding: {e}") from e
    
    def batch_write(
        self,
        embeddings: List[Tuple[str, List[float], Dict[str, Any]]]
    ) -> int:
        """
        Batch write embeddings (performance optimization).
        
        Args:
            embeddings: List of (content_id, vector, metadata) tuples
            
        Returns:
            Number of embeddings written
        """
        if not embeddings:
            return 0
        
        try:
            # Group by namespace
            namespace_batches: Dict[str, List[Tuple[str, List[float], Dict[str, Any]]]] = {}
            
            for content_id, vector, metadata in embeddings:
                tenant_id = metadata.get("tenant_id", "default")
                namespace = self._get_namespace(tenant_id)
                
                if namespace not in namespace_batches:
                    namespace_batches[namespace] = []
                
                # Generate ID
                vector_id = self._generate_vector_id(content_id, metadata)
                
                # Flatten metadata
                flat_metadata = self._flatten_metadata(metadata)
                
                namespace_batches[namespace].append((vector_id, vector, flat_metadata))
            
            # Upsert each namespace in batches
            total_written = 0
            
            for namespace, vectors in namespace_batches.items():
                # Split into chunks
                batch_size = self.config.batch_size
                
                for i in range(0, len(vectors), batch_size):
                    batch = vectors[i:i + batch_size]
                    
                    self.index.upsert(
                        vectors=batch,
                        namespace=namespace
                    )
                    
                    total_written += len(batch)
                    self.writes += len(batch)
            
            return total_written
        
        except Exception as e:
            self.errors += 1
            raise StorageWriteError(f"Failed to batch write embeddings: {e}") from e
    
    # -------------------------
    # SEARCH OPERATIONS
    # -------------------------
    
    def search(
        self,
        query_vector: List[float],
        filters: Dict[str, Any],
        top_k: int = 10
    ) -> List[Tuple[str, float, Dict[str, Any]]]:
        """
        Semantic search by vector similarity.
        
        Args:
            query_vector: Query embedding
            filters: Metadata filters
            top_k: Number of results
            
        Returns:
            List of (content_id, score, metadata) tuples
        """
        try:
            # Extract tenant_id for namespace
            tenant_id = filters.get("tenant_id", "default")
            namespace = self._get_namespace(tenant_id)
            
            # Build Pinecone filter
            pinecone_filter = self._build_filter(filters)
            
            # Query
            results = self.index.query(
                vector=query_vector,
                filter=pinecone_filter,
                top_k=top_k,
                include_metadata=True,
                namespace=namespace
            )
            
            self.reads += 1
            
            # Parse results
            parsed_results = []
            
            for match in results.matches:
                # Extract content_id from vector ID
                content_id = self._extract_content_id(match.id)
                
                # Unflatten metadata
                metadata = self._unflatten_metadata(match.metadata)
                
                parsed_results.append((
                    content_id,
                    match.score,
                    metadata
                ))
            
            return parsed_results
        
        except Exception as e:
            self.errors += 1
            raise StorageReadError(f"Failed to search: {e}") from e
    
    # -------------------------
    # DELETE OPERATIONS
    # -------------------------
    
    def delete_embedding(self, content_id: str) -> bool:
        """
        Delete embedding by content ID.
        
        Deletes ALL vectors for this content_id across all namespaces.
        
        Args:
            content_id: Content identifier
            
        Returns:
            True if deleted, False if not found
        """
        try:
            # Pinecone requires exact vector ID, but we may have multiple chunks
            # We need to delete by filter
            
            # Get all namespaces
            namespaces = self._list_namespaces()
            
            deleted = False
            
            for namespace in namespaces:
                # Delete by metadata filter
                try:
                    self.index.delete(
                        filter={"content_id": {"$eq": content_id}},
                        namespace=namespace
                    )
                    deleted = True
                except Exception as e:
                    logger.error(f"Error deleting from namespace {namespace}: {e}")
            
            return deleted
        
        except Exception as e:
            self.errors += 1
            logger.error(f"Failed to delete embedding: {e}")
            return False
    
    # -------------------------
    # UPDATE OPERATIONS
    # -------------------------
    
    def update_metadata(
        self,
        content_id: str,
        metadata: Dict[str, Any]
    ) -> bool:
        """
        Update metadata for existing embedding.
        
        Args:
            content_id: Content identifier
            metadata: New metadata
            
        Returns:
            True if updated
        """
        try:
            # Pinecone doesn't support metadata-only updates
            # We need to fetch, update, and re-upsert
            
            tenant_id = metadata.get("tenant_id", "default")
            namespace = self._get_namespace(tenant_id)
            
            # Fetch existing vectors
            # This is not efficient - Pinecone limitation
            # Better approach: re-write with new metadata
            
            logger.warning("update_metadata requires re-upserting vectors")
            return False
        
        except Exception as e:
            self.errors += 1
            logger.error(f"Failed to update metadata: {e}")
            return False
    
    # -------------------------
    # METADATA HELPERS
    # -------------------------
    
    def _flatten_metadata(self, metadata: Dict[str, Any]) -> Dict[str, Any]:
        """
        Flatten metadata for Pinecone.
        
        Pinecone metadata constraints:
        - No nested objects
        - Array values must be strings
        - Null values not allowed
        
        Args:
            metadata: Original metadata
            
        Returns:
            Flattened metadata
        """
        flat = {}
        
        for key, value in metadata.items():
            if value is None:
                continue
            
            # Convert lists to JSON strings (Pinecone limitation)
            if isinstance(value, list):
                # For permission filtering, we need searchable strings
                if key in ["user_ids", "team_ids"]:
                    # Store as multiple keys: user_id_0, user_id_1, etc.
                    for i, item in enumerate(value[:10]):  # Limit to 10
                        flat[f"{key}_{i}"] = str(item)
                    # Also store count
                    flat[f"{key}_count"] = len(value)
                else:
                    # Convert to JSON string
                    import json
                    flat[key] = json.dumps(value)
            
            # Datetime to ISO string
            elif isinstance(value, datetime):
                flat[key] = value.isoformat()
            
            # Keep primitives
            elif isinstance(value, (str, int, float, bool)):
                flat[key] = value
            
            # Convert other types to string
            else:
                flat[key] = str(value)
        
        return flat
    
    def _unflatten_metadata(self, metadata: Dict[str, Any]) -> Dict[str, Any]:
        """
        Unflatten metadata from Pinecone.
        
        Reverses _flatten_metadata.
        
        Args:
            metadata: Flattened metadata
            
        Returns:
            Original metadata structure
        """
        import json
        
        unflat = {}
        
        # Reconstruct lists
        list_keys = set()
        for key in metadata.keys():
            if "_count" in key:
                base_key = key.replace("_count", "")
                list_keys.add(base_key)
        
        for base_key in list_keys:
            count = metadata.get(f"{base_key}_count", 0)
            items = []
            
            for i in range(count):
                item_key = f"{base_key}_{i}"
                if item_key in metadata:
                    items.append(metadata[item_key])
            
            if items:
                unflat[base_key] = items
        
        # Process other keys
        for key, value in metadata.items():
            # Skip list reconstruction keys
            if any(key.startswith(f"{lk}_") for lk in list_keys):
                continue
            
            # Try to parse JSON strings
            if isinstance(value, str) and value.startswith("["):
                try:
                    unflat[key] = json.loads(value)
                    continue
                except:
                    pass
            
            # Try to parse ISO datetime
            if isinstance(value, str) and "T" in value:
                try:
                    unflat[key] = datetime.fromisoformat(value)
                    continue
                except:
                    pass
            
            # Keep as-is
            unflat[key] = value
        
        return unflat
    
    def _build_filter(self, filters: Dict[str, Any]) -> Dict[str, Any]:
        """
        Build Pinecone filter from standard filters.
        
        Pinecone filter syntax:
        {"field": {"$eq": value}}
        {"field": {"$in": [values]}}
        {"$and": [filter1, filter2]}
        
        Args:
            filters: Standard filter dict
            
        Returns:
            Pinecone filter dict
        """
        pinecone_filter = {}
        conditions = []
        
        for key, value in filters.items():
            # Skip tenant_id (handled by namespace)
            if key == "tenant_id":
                continue
            
            # Handle permission filters (user_ids, team_ids)
            if key == "user_id" and "user_ids" in filters:
                # User in user_ids list
                user_id = filters["user_id"]
                # Check any of the indexed user_id fields
                user_conditions = []
                for i in range(10):  # Check up to 10 slots
                    user_conditions.append({f"user_ids_{i}": {"$eq": user_id}})
                
                if len(user_conditions) > 1:
                    conditions.append({"$or": user_conditions})
                elif user_conditions:
                    conditions.append(user_conditions[0])
                
                continue
            
            # Handle list values (IN)
            if isinstance(value, list):
                conditions.append({key: {"$in": value}})
            
            # Handle single values (EQ)
            else:
                conditions.append({key: {"$eq": value}})
        
        # Combine conditions
        if len(conditions) == 0:
            return {}
        elif len(conditions) == 1:
            return conditions[0]
        else:
            return {"$and": conditions}
    
    # -------------------------
    # ID MANAGEMENT
    # -------------------------
    
    def _generate_vector_id(
        self,
        content_id: str,
        metadata: Dict[str, Any]
    ) -> str:
        """
        Generate unique vector ID.
        
        Format: {tenant_id}_{content_id}_{chunk_hash}
        
        Args:
            content_id: Content identifier
            metadata: Metadata (may contain chunk info)
            
        Returns:
            Vector ID
        """
        tenant_id = metadata.get("tenant_id", "default")
        
        # Add chunk identifier if present
        chunk_id = metadata.get("chunk_id", "")
        
        if chunk_id:
            return f"{tenant_id}_{content_id}_{chunk_id}"
        else:
            # Generate random suffix to avoid collisions
            suffix = str(uuid.uuid4())[:8]
            return f"{tenant_id}_{content_id}_{suffix}"
    
    def _extract_content_id(self, vector_id: str) -> str:
        """
        Extract content_id from vector ID.
        
        Args:
            vector_id: Vector ID
            
        Returns:
            Content ID
        """
        # Format: {tenant_id}_{content_id}_{chunk_hash}
        parts = vector_id.split("_", 2)
        
        if len(parts) >= 2:
            return parts[1]
        else:
            return vector_id
    
    # -------------------------
    # NAMESPACE MANAGEMENT
    # -------------------------
    
    def _get_namespace(self, tenant_id: str) -> str:
        """
        Get namespace for tenant.
        
        Args:
            tenant_id: Tenant identifier
            
        Returns:
            Namespace string
        """
        if self.config.use_namespaces:
            return f"tenant_{tenant_id}"
        else:
            return ""  # Default namespace
    
    def _list_namespaces(self) -> List[str]:
        """
        List all namespaces in index.
        
        Returns:
            List of namespace names
        """
        try:
            stats = self.index.describe_index_stats()
            namespaces = list(stats.namespaces.keys())
            
            # Add default namespace if it has vectors
            if stats.total_vector_count > sum(ns.vector_count for ns in stats.namespaces.values()):
                namespaces.append("")
            
            return namespaces
        
        except Exception as e:
            logger.error(f"Failed to list namespaces: {e}")
            return [""]
    
    # -------------------------
    # UTILITIES
    # -------------------------
    
    def health_check(self) -> bool:
        """
        Check if Pinecone store is healthy.
        
        Returns:
            True if accessible
        """
        try:
            # Describe index
            stats = self.index.describe_index_stats()
            return stats is not None
        except:
            return False
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get storage statistics.
        
        Returns:
            Dictionary with stats
        """
        try:
            stats = self.index.describe_index_stats()
            
            return {
                "index_name": self.config.index_name,
                "dimension": self.config.dimension,
                "metric": self.config.metric,
                "total_vectors": stats.total_vector_count,
                "namespaces": {
                    name: ns.vector_count
                    for name, ns in stats.namespaces.items()
                },
                "writes": self.writes,
                "reads": self.reads,
                "errors": self.errors
            }
        
        except Exception as e:
            return {
                "error": str(e),
                "writes": self.writes,
                "reads": self.reads,
                "errors": self.errors
            }
    
    def delete_index(self) -> bool:
        """
        Delete the entire index.
        
        WARNING: This is destructive and irreversible!
        
        Returns:
            True if deleted
        """
        try:
            self.client.delete_index(self.config.index_name)
            logger.info(f"Deleted index: {self.config.index_name}")
            return True
        except Exception as e:
            logger.error(f"Failed to delete index: {e}")
            return False


# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def create_pinecone_store(
    api_key: str,
    index_name: str = "neurostack",
    dimension: int = 1536,
    **kwargs
) -> PineconeStore:
    """
    Helper to create Pinecone store.
    
    Args:
        api_key: Pinecone API key
        index_name: Index name
        dimension: Vector dimension
        **kwargs: Additional PineconeConfig parameters
        
    Returns:
        PineconeStore instance
    """
    config = PineconeConfig(
        api_key=api_key,
        index_name=index_name,
        dimension=dimension,
        **kwargs
    )
    
    return PineconeStore(config)


def migrate_to_pinecone(
    source_store: SemanticStore,
    target_store: PineconeStore,
    batch_size: int = 100
) -> int:
    """
    Migrate embeddings from another store to Pinecone.
    
    Args:
        source_store: Source semantic store
        target_store: Target Pinecone store
        batch_size: Batch size for migration
        
    Returns:
        Number of embeddings migrated
    """
    logger.info("Starting migration...")
    
    # This is a simplified migration - actual implementation would need
    # a way to enumerate all vectors in source store
    
    # For now, return 0 (not implemented)
    logger.warning("Migration not implemented (requires source store enumeration)")
    return 0