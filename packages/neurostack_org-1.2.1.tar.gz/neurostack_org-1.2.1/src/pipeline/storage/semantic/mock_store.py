"""
Mock semantic/vector store for testing.

Provides in-memory implementation of SemanticStore protocol without
external dependencies. Useful for:
- Unit tests
- Integration tests
- Development without vector DB
- CI/CD pipelines
- Quick prototyping

Features:
- In-memory vector storage
- Brute-force similarity search
- Metadata filtering
- Thread-safe operations
- Persistent state (optional file dump)
- Realistic search behavior

This is NOT optimized for large-scale use. For production, use
Pinecone, Qdrant, Weaviate, or similar.
"""

import json
import logging
import math
import threading
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from ..interfaces import SemanticStore, StorageError, StorageWriteError, StorageReadError


# ============================================================================
# LOGGING
# ============================================================================

logger = logging.getLogger("neurostack.pipeline.storage.semantic.mock")


# ============================================================================
# MOCK STORE MODELS
# ============================================================================

@dataclass
class VectorEntry:
    """
    Single vector entry in mock store.
    """
    content_id: str
    vector: List[float]
    metadata: Dict[str, Any]
    
    # Timestamps
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization"""
        return {
            "content_id": self.content_id,
            "vector": self.vector,
            "metadata": self.metadata,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat()
        }
    
    @staticmethod
    def from_dict(data: Dict[str, Any]) -> 'VectorEntry':
        """Create from dictionary"""
        return VectorEntry(
            content_id=data["content_id"],
            vector=data["vector"],
            metadata=data["metadata"],
            created_at=datetime.fromisoformat(data["created_at"]),
            updated_at=datetime.fromisoformat(data["updated_at"])
        )


# ============================================================================
# MOCK SEMANTIC STORE
# ============================================================================

class MockSemanticStore:
    """
    In-memory mock vector store.
    
    Implements SemanticStore protocol using simple in-memory dictionary.
    Uses brute-force cosine similarity search (O(n) per query).
    
    Thread-safe with basic locking. Supports metadata filtering.
    
    Usage:
        store = MockSemanticStore()
        
        # Write embedding
        store.write_embedding(
            content_id="doc_123",
            vector=[0.1, 0.2, 0.3, ...],
            metadata={"tenant_id": "acme", "type": "document"}
        )
        
        # Search
        results = store.search(
            query_vector=[0.1, 0.2, 0.3, ...],
            filters={"tenant_id": "acme"},
            top_k=10
        )
    """
    
    def __init__(
        self,
        dimension: Optional[int] = None,
        enable_validation: bool = True,
        enable_persistence: bool = False,
        persistence_path: Optional[str] = None
    ):
        """
        Initialize mock semantic store.
        
        Args:
            dimension: Expected vector dimensions (validated if set)
            enable_validation: Whether to validate vectors/metadata
            enable_persistence: Whether to enable file-based persistence
            persistence_path: Path to persistence file
        """
        self.dimension = dimension
        self.enable_validation = enable_validation
        self.enable_persistence = enable_persistence
        self.persistence_path = persistence_path
        
        # Storage: content_id -> VectorEntry
        self._vectors: Dict[str, VectorEntry] = {}
        
        # Thread safety
        self._lock = threading.RLock()
        
        # Stats
        self.total_writes = 0
        self.total_searches = 0
        self.total_deletes = 0
        
        # Load from persistence if enabled
        if self.enable_persistence and self.persistence_path:
            self._load_from_file()
        
        logger.info(f"Initialized (dimension={dimension})")
    
    # -------------------------
    # WRITE OPERATIONS
    # -------------------------
    
    def write_embedding(
        self,
        content_id: str,
        vector: List[float],
        metadata: Dict[str, Any]
    ) -> None:
        """
        Write embedding vector with metadata.
        
        Args:
            content_id: Content identifier
            vector: Embedding vector
            metadata: Metadata for filtering
            
        Raises:
            StorageWriteError: If write fails
        """
        with self._lock:
            try:
                # Validate
                if self.enable_validation:
                    self._validate_vector(vector)
                    self._validate_metadata(metadata)
                
                # Check if exists
                if content_id in self._vectors:
                    # Update existing
                    entry = self._vectors[content_id]
                    entry.vector = vector
                    entry.metadata = metadata
                    entry.updated_at = datetime.now(timezone.utc)
                else:
                    # Create new
                    entry = VectorEntry(
                        content_id=content_id,
                        vector=vector,
                        metadata=metadata
                    )
                    self._vectors[content_id] = entry
                
                self.total_writes += 1
                
                # Persist if enabled
                if self.enable_persistence:
                    self._save_to_file()
            
            except Exception as e:
                raise StorageWriteError(f"Failed to write embedding: {e}") from e
    
    def batch_write(
        self,
        embeddings: List[Tuple[str, List[float], Dict[str, Any]]]
    ) -> int:
        """
        Batch write embeddings.
        
        Args:
            embeddings: List of (content_id, vector, metadata) tuples
            
        Returns:
            Number of embeddings written
        """
        with self._lock:
            count = 0
            
            for content_id, vector, metadata in embeddings:
                try:
                    self.write_embedding(content_id, vector, metadata)
                    count += 1
                except StorageWriteError as e:
                    logger.error(f"Failed to write {content_id}: {e}")
            
            return count
    
    # -------------------------
    # SEARCH OPERATIONS
    # -------------------------
    
    def search(
        self,
        query_vector: List[float],
        filters: Dict[str, Any],
        top_k: int = 10
    ) -> List[Tuple[str, float, Dict[str, Any]]]:
        """
        Semantic search by vector similarity.
        
        Performs brute-force cosine similarity search with metadata filtering.
        
        Args:
            query_vector: Query embedding
            filters: Metadata filters (all must match)
            top_k: Number of results
            
        Returns:
            List of (content_id, score, metadata) tuples, sorted by score descending
        """
        with self._lock:
            try:
                # Validate query vector
                if self.enable_validation:
                    self._validate_vector(query_vector)
                
                # Filter candidates by metadata
                candidates = self._filter_by_metadata(filters)
                
                # Calculate similarities
                similarities = []
                for content_id, entry in candidates.items():
                    score = self._cosine_similarity(query_vector, entry.vector)
                    similarities.append((content_id, score, entry.metadata))
                
                # Sort by score descending
                similarities.sort(key=lambda x: x[1], reverse=True)
                
                # Take top_k
                results = similarities[:top_k]
                
                self.total_searches += 1
                
                return results
            
            except Exception as e:
                raise StorageReadError(f"Search failed: {e}") from e
    
    # -------------------------
    # DELETE OPERATIONS
    # -------------------------
    
    def delete_embedding(self, content_id: str) -> bool:
        """
        Delete embedding by content ID.
        
        Args:
            content_id: Content identifier
            
        Returns:
            True if deleted, False if not found
        """
        with self._lock:
            if content_id in self._vectors:
                del self._vectors[content_id]
                self.total_deletes += 1
                
                # Persist if enabled
                if self.enable_persistence:
                    self._save_to_file()
                
                return True
            
            return False
    
    def delete_by_filter(self, filters: Dict[str, Any]) -> int:
        """
        Delete all embeddings matching filters.
        
        Args:
            filters: Metadata filters
            
        Returns:
            Number of embeddings deleted
        """
        with self._lock:
            # Find matching content IDs
            candidates = self._filter_by_metadata(filters)
            content_ids = list(candidates.keys())
            
            # Delete
            count = 0
            for content_id in content_ids:
                if self.delete_embedding(content_id):
                    count += 1
            
            return count
    
    # -------------------------
    # UPDATE OPERATIONS
    # -------------------------
    
    def update_metadata(
        self,
        content_id: str,
        metadata: Dict[str, Any]
    ) -> bool:
        """
        Update metadata for existing embedding.
        
        Args:
            content_id: Content identifier
            metadata: New metadata
            
        Returns:
            True if updated
        """
        with self._lock:
            if content_id not in self._vectors:
                return False
            
            # Validate
            if self.enable_validation:
                self._validate_metadata(metadata)
            
            # Update
            entry = self._vectors[content_id]
            entry.metadata = metadata
            entry.updated_at = datetime.now(timezone.utc)
            
            # Persist if enabled
            if self.enable_persistence:
                self._save_to_file()
            
            return True
    
    # -------------------------
    # RETRIEVAL OPERATIONS
    # -------------------------
    
    def get_embedding(self, content_id: str) -> Optional[Tuple[List[float], Dict[str, Any]]]:
        """
        Get embedding and metadata by content ID.
        
        Args:
            content_id: Content identifier
            
        Returns:
            (vector, metadata) tuple or None if not found
        """
        with self._lock:
            if content_id in self._vectors:
                entry = self._vectors[content_id]
                return (entry.vector, entry.metadata)
            
            return None
    
    def list_embeddings(
        self,
        filters: Optional[Dict[str, Any]] = None,
        limit: int = 100
    ) -> List[Tuple[str, Dict[str, Any]]]:
        """
        List embeddings with optional filtering.
        
        Args:
            filters: Optional metadata filters
            limit: Maximum results
            
        Returns:
            List of (content_id, metadata) tuples
        """
        with self._lock:
            if filters:
                candidates = self._filter_by_metadata(filters)
            else:
                candidates = self._vectors
            
            results = [
                (content_id, entry.metadata)
                for content_id, entry in list(candidates.items())[:limit]
            ]
            
            return results
    
    # -------------------------
    # VALIDATION
    # -------------------------
    
    def _validate_vector(self, vector: List[float]) -> None:
        """
        Validate vector.
        
        Args:
            vector: Vector to validate
            
        Raises:
            ValueError: If validation fails
        """
        if not vector:
            raise ValueError("Vector cannot be empty")
        
        # Check dimension
        if self.dimension is not None:
            if len(vector) != self.dimension:
                raise ValueError(
                    f"Vector dimension mismatch: expected {self.dimension}, got {len(vector)}"
                )
        
        # Check all elements are numeric
        if not all(isinstance(x, (int, float)) for x in vector):
            raise ValueError("Vector must contain only numeric values")
        
        # Check for NaN/Inf
        if any(math.isnan(x) or math.isinf(x) for x in vector):
            raise ValueError("Vector contains NaN or Inf values")
    
    def _validate_metadata(self, metadata: Dict[str, Any]) -> None:
        """
        Validate metadata.
        
        Args:
            metadata: Metadata to validate
            
        Raises:
            ValueError: If validation fails
        """
        if not isinstance(metadata, dict):
            raise ValueError("Metadata must be a dictionary")
        
        # Check required fields
        required_fields = ["tenant_id"]  # Minimum requirement
        for field in required_fields:
            if field not in metadata:
                raise ValueError(f"Missing required metadata field: {field}")
        
        # Check values are JSON-serializable (simple check)
        try:
            json.dumps(metadata)
        except (TypeError, ValueError) as e:
            raise ValueError(f"Metadata not JSON-serializable: {e}")
    
    # -------------------------
    # FILTERING
    # -------------------------
    
    def _filter_by_metadata(
        self,
        filters: Dict[str, Any]
    ) -> Dict[str, VectorEntry]:
        """
        Filter vectors by metadata.
        
        All filter criteria must match (AND logic).
        
        Args:
            filters: Metadata filters
            
        Returns:
            Dictionary of matching {content_id: entry}
        """
        if not filters:
            return self._vectors.copy()
        
        matches = {}
        
        for content_id, entry in self._vectors.items():
            if self._metadata_matches(entry.metadata, filters):
                matches[content_id] = entry
        
        return matches
    
    def _metadata_matches(
        self,
        metadata: Dict[str, Any],
        filters: Dict[str, Any]
    ) -> bool:
        """
        Check if metadata matches all filters.
        
        Args:
            metadata: Entry metadata
            filters: Filter criteria
            
        Returns:
            True if all filters match
        """
        for key, value in filters.items():
            # Handle nested keys (e.g., "user.id")
            if "." in key:
                metadata_value = self._get_nested_value(metadata, key)
            else:
                metadata_value = metadata.get(key)
            
            # Check match
            if isinstance(value, list):
                # IN filter: metadata value must be in list
                if metadata_value not in value:
                    return False
            else:
                # Exact match
                if metadata_value != value:
                    return False
        
        return True
    
    def _get_nested_value(
        self,
        metadata: Dict[str, Any],
        key: str
    ) -> Any:
        """
        Get nested metadata value.
        
        Args:
            metadata: Metadata dictionary
            key: Nested key (e.g., "user.id")
            
        Returns:
            Nested value or None
        """
        keys = key.split(".")
        value = metadata
        
        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return None
        
        return value
    
    # -------------------------
    # SIMILARITY CALCULATION
    # -------------------------
    
    def _cosine_similarity(
        self,
        vec1: List[float],
        vec2: List[float]
    ) -> float:
        """
        Calculate cosine similarity between two vectors.
        
        Args:
            vec1: First vector
            vec2: Second vector
            
        Returns:
            Similarity score (0-1, higher = more similar)
        """
        if len(vec1) != len(vec2):
            raise ValueError("Vectors must have same dimensions")
        
        # Dot product
        dot_product = sum(a * b for a, b in zip(vec1, vec2))
        
        # Magnitudes
        mag1 = math.sqrt(sum(a * a for a in vec1))
        mag2 = math.sqrt(sum(b * b for b in vec2))
        
        # Cosine similarity
        if mag1 == 0 or mag2 == 0:
            return 0.0
        
        return dot_product / (mag1 * mag2)
    
    # -------------------------
    # PERSISTENCE
    # -------------------------
    
    def _save_to_file(self) -> None:
        """Save state to file"""
        if not self.persistence_path:
            return
        
        try:
            # Convert to serializable format
            data = {
                "dimension": self.dimension,
                "vectors": [entry.to_dict() for entry in self._vectors.values()],
                "stats": {
                    "total_writes": self.total_writes,
                    "total_searches": self.total_searches,
                    "total_deletes": self.total_deletes
                },
                "saved_at": datetime.now(timezone.utc).isoformat()
            }
            
            # Write to file
            path = Path(self.persistence_path)
            path.parent.mkdir(parents=True, exist_ok=True)
            
            with open(path, 'w') as f:
                json.dump(data, f, indent=2)
        
        except Exception as e:
            logger.error(f"Failed to save to file: {e}")
    
    def _load_from_file(self) -> None:
        """Load state from file"""
        if not self.persistence_path:
            return
        
        try:
            path = Path(self.persistence_path)
            
            if not path.exists():
                return
            
            with open(path, 'r') as f:
                data = json.load(f)
            
            # Restore dimension
            self.dimension = data.get("dimension")
            
            # Restore vectors
            for entry_dict in data.get("vectors", []):
                entry = VectorEntry.from_dict(entry_dict)
                self._vectors[entry.content_id] = entry
            
            # Restore stats
            stats = data.get("stats", {})
            self.total_writes = stats.get("total_writes", 0)
            self.total_searches = stats.get("total_searches", 0)
            self.total_deletes = stats.get("total_deletes", 0)
            
            logger.info(f"Loaded {len(self._vectors)} vectors from file")
        
        except Exception as e:
            logger.error(f"Failed to load from file: {e}")
    
    # -------------------------
    # UTILITIES
    # -------------------------
    
    def health_check(self) -> bool:
        """
        Check if store is healthy.
        
        Returns:
            True if operational
        """
        with self._lock:
            return True  # Mock store is always healthy
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get storage statistics.
        
        Returns:
            Dictionary with stats
        """
        with self._lock:
            return {
                "total_vectors": len(self._vectors),
                "dimension": self.dimension,
                "total_writes": self.total_writes,
                "total_searches": self.total_searches,
                "total_deletes": self.total_deletes,
                "memory_usage_mb": self._estimate_memory_usage(),
                "persistence_enabled": self.enable_persistence
            }
    
    def _estimate_memory_usage(self) -> float:
        """
        Estimate memory usage in MB.
        
        Returns:
            Estimated memory usage
        """
        if not self._vectors:
            return 0.0
        
        # Rough estimate: dimension * 8 bytes per float + metadata overhead
        bytes_per_vector = (self.dimension or 384) * 8 + 500  # 500 bytes for metadata
        total_bytes = len(self._vectors) * bytes_per_vector
        
        return total_bytes / (1024 * 1024)
    
    def clear(self) -> None:
        """Clear all vectors"""
        with self._lock:
            self._vectors.clear()
            
            if self.enable_persistence:
                self._save_to_file()
            
            logger.info("Cleared all vectors")
    
    def get_vector_count(self) -> int:
        """Get total number of vectors"""
        with self._lock:
            return len(self._vectors)
    
    def export_to_dict(self) -> Dict[str, Any]:
        """
        Export entire store to dictionary.
        
        Returns:
            Dictionary with all data
        """
        with self._lock:
            return {
                "dimension": self.dimension,
                "vectors": [entry.to_dict() for entry in self._vectors.values()],
                "stats": self.get_stats()
            }
    
    def import_from_dict(self, data: Dict[str, Any]) -> int:
        """
        Import data from dictionary.
        
        Args:
            data: Data dictionary from export_to_dict()
            
        Returns:
            Number of vectors imported
        """
        with self._lock:
            self.dimension = data.get("dimension", self.dimension)
            
            count = 0
            for entry_dict in data.get("vectors", []):
                entry = VectorEntry.from_dict(entry_dict)
                self._vectors[entry.content_id] = entry
                count += 1
            
            logger.info(f"Imported {count} vectors")
            
            return count


# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def create_mock_semantic_store(
    dimension: int = 384,
    **kwargs
) -> MockSemanticStore:
    """
    Helper to create mock semantic store.
    
    Args:
        dimension: Vector dimensions
        **kwargs: Additional parameters
        
    Returns:
        MockSemanticStore instance
    """
    return MockSemanticStore(dimension=dimension, **kwargs)


def populate_test_store(
    store: MockSemanticStore,
    num_vectors: int = 100,
    dimension: Optional[int] = None,
    tenant_id: str = "test_tenant"
) -> List[str]:
    """
    Populate store with test data.
    
    Args:
        store: Mock store to populate
        num_vectors: Number of vectors to generate
        dimension: Vector dimensions (uses store's dimension if None)
        tenant_id: Tenant ID for metadata
        
    Returns:
        List of content IDs
    """
    import random
    
    dimension = dimension or store.dimension or 384
    content_ids = []
    
    for i in range(num_vectors):
        content_id = f"test_doc_{i}"
        
        # Generate random unit vector
        vector = [random.gauss(0, 1) for _ in range(dimension)]
        magnitude = math.sqrt(sum(x * x for x in vector))
        if magnitude > 0:
            vector = [x / magnitude for x in vector]
        
        # Metadata
        metadata = {
            "tenant_id": tenant_id,
            "source": "test",
            "index": i,
            "type": "document" if i % 2 == 0 else "task"
        }
        
        store.write_embedding(content_id, vector, metadata)
        content_ids.append(content_id)
    
    logger.info(f"[Test] Populated store with {num_vectors} vectors")
    
    return content_ids


def benchmark_mock_store(
    num_vectors: int = 1000,
    dimension: int = 384,
    num_queries: int = 100
) -> Dict[str, Any]:
    """
    Benchmark mock store performance.
    
    Args:
        num_vectors: Number of vectors to test with
        dimension: Vector dimensions
        num_queries: Number of search queries
        
    Returns:
        Dictionary with benchmark results
    """
    import time
    import random
    
    store = create_mock_semantic_store(dimension=dimension)
    
    # Populate
    logger.info(f"[Benchmark] Populating store with {num_vectors} vectors...")
    start = time.time()
    populate_test_store(store, num_vectors, dimension)
    populate_time = time.time() - start
    
    # Benchmark search
    logger.info(f"[Benchmark] Running {num_queries} search queries...")
    search_times = []
    
    for _ in range(num_queries):
        # Random query vector
        query = [random.gauss(0, 1) for _ in range(dimension)]
        magnitude = math.sqrt(sum(x * x for x in query))
        if magnitude > 0:
            query = [x / magnitude for x in query]
        
        start = time.time()
        results = store.search(
            query_vector=query,
            filters={"tenant_id": "test_tenant"},
            top_k=10
        )
        search_time = time.time() - start
        search_times.append(search_time)
    
    avg_search_time = sum(search_times) / len(search_times)
    
    return {
        "num_vectors": num_vectors,
        "dimension": dimension,
        "populate_time_s": round(populate_time, 3),
        "avg_search_time_ms": round(avg_search_time * 1000, 2),
        "searches_per_second": round(1 / avg_search_time, 1),
        "memory_usage_mb": store.get_stats()["memory_usage_mb"]
    }


# ============================================================================
# TESTING UTILITIES
# ============================================================================

class MockStoreTestHelper:
    """
    Helper for testing with mock semantic store.
    
    Provides utilities for creating test scenarios.
    """
    
    def __init__(self, dimension: int = 384):
        """
        Initialize test helper.
        
        Args:
            dimension: Vector dimensions
        """
        self.store = create_mock_semantic_store(dimension=dimension)
        self.dimension = dimension
    
    def create_similar_vectors(
        self,
        base_id: str,
        count: int = 5,
        similarity: float = 0.9,
        tenant_id: str = "test"
    ) -> List[str]:
        """
        Create cluster of similar vectors.
        
        Args:
            base_id: Base content ID
            count: Number of similar vectors
            similarity: Target similarity
            tenant_id: Tenant ID
            
        Returns:
            List of content IDs
        """
        import random
        
        # Generate base vector
        base_vector = [random.gauss(0, 1) for _ in range(self.dimension)]
        magnitude = math.sqrt(sum(x * x for x in base_vector))
        if magnitude > 0:
            base_vector = [x / magnitude for x in base_vector]
        
        # Store base
        self.store.write_embedding(
            base_id,
            base_vector,
            {"tenant_id": tenant_id, "cluster": "base"}
        )
        
        content_ids = [base_id]
        
        # Generate similar vectors
        for i in range(1, count):
            content_id = f"{base_id}_similar_{i}"
            
            # Generate orthogonal component
            ortho = [random.gauss(0, 1) for _ in range(self.dimension)]
            magnitude = math.sqrt(sum(x * x for x in ortho))
            if magnitude > 0:
                ortho = [x / magnitude for x in ortho]
            
            # Mix to achieve target similarity
            weight_base = similarity
            weight_ortho = math.sqrt(max(0, 1 - similarity * similarity))
            
            similar_vector = [
                weight_base * b + weight_ortho * o
                for b, o in zip(base_vector, ortho)
            ]
            
            # Normalize
            magnitude = math.sqrt(sum(x * x for x in similar_vector))
            if magnitude > 0:
                similar_vector = [x / magnitude for x in similar_vector]
            
            self.store.write_embedding(
                content_id,
                similar_vector,
                {"tenant_id": tenant_id, "cluster": "similar"}
            )
            
            content_ids.append(content_id)
        
        return content_ids
    
    def test_search_accuracy(
        self,
        query_id: str,
        expected_similar: List[str],
        top_k: int = 5
    ) -> Dict[str, Any]:
        """
        Test search accuracy.
        
        Args:
            query_id: Content ID to use as query
            expected_similar: Expected similar content IDs
            top_k: Number of results
            
        Returns:
            Dictionary with accuracy metrics
        """
        # Get query vector
        query_data = self.store.get_embedding(query_id)
        if not query_data:
            return {"error": "Query ID not found"}
        
        query_vector, query_metadata = query_data
        
        # Search
        results = self.store.search(
            query_vector=query_vector,
            filters={"tenant_id": query_metadata["tenant_id"]},
            top_k=top_k
        )
        
        # Extract result IDs
        result_ids = [r[0] for r in results]
        
        # Calculate metrics
        true_positives = len(set(result_ids) & set(expected_similar))
        precision = true_positives / len(result_ids) if result_ids else 0
        recall = true_positives / len(expected_similar) if expected_similar else 0
        
        return {
            "query_id": query_id,
            "expected_count": len(expected_similar),
            "returned_count": len(result_ids),
            "true_positives": true_positives,
            "precision": round(precision, 3),
            "recall": round(recall, 3),
            "result_ids": result_ids
        }


if __name__ == "__main__":
    # Run benchmark when executed directly
    logger.info("[MockSemanticStore] Running benchmark...")
    results = benchmark_mock_store(num_vectors=1000, num_queries=100)
    
    logger.info("\nBenchmark Results:")
    logger.info(f"  Vectors: {results['num_vectors']}")
    logger.info(f"  Dimension: {results['dimension']}")
    logger.info(f"  Populate time: {results['populate_time_s']}s")
    logger.info(f"  Avg search time: {results['avg_search_time_ms']}ms")
    logger.info(f"  Searches/sec: {results['searches_per_second']}")
    logger.info(f"  Memory usage: {results['memory_usage_mb']:.1f} MB")