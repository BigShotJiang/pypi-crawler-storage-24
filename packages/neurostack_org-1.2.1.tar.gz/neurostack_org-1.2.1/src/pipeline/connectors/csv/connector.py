"""
CSV File Connector — reference implementation.

A deliberately simple connector that reads rows from a CSV file and
yields them as RawItems.  Intended as a template for building custom
connectors: copy this file, swap in your data-source logic, done.

No authentication is required.  The file is always read in full
(IncrementalMode.FULL) and paginated in memory via a row-offset cursor.
"""

import csv
import logging
import os
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from pipeline.connectors.base import (
    Connector,
    ConnectorAuthType,
    ConnectorConfig,
    ConnectorConfigError,
    ConnectorExtractionError,
    ExtractionBatch,
    IncrementalMode,
    PermissionMetadata,
    RawItem,
)

logger = logging.getLogger(__name__)

# ============================================================================
# CSV CONNECTOR
# ============================================================================


class CSVConnector(Connector):
    """
    Reads a local CSV file and exposes each row as a RawItem.

    custom_config keys
    ------------------
    file_path          : str   – path to the CSV file (required)
    delimiter          : str   – column delimiter (default ",")
    encoding           : str   – file encoding (default "utf-8")
    content_columns    : list  – columns whose values are concatenated as
                                  the "content" field in raw_data
    scope_column       : str   – column that holds the permission scope
    user_ids_column    : str   – column with comma-separated user IDs
    team_ids_column    : str   – column with comma-separated team IDs
    """

    # -- metadata properties -------------------------------------------------

    @property
    def name(self) -> str:
        return "CSV File"

    @property
    def version(self) -> str:
        return "1.0.0"

    @property
    def description(self) -> str:
        return "Reference connector that ingests rows from a local CSV file."

    # -- lifecycle methods ---------------------------------------------------

    def authenticate(self) -> bool:
        """No authentication needed for local files."""
        logger.info("csv_connector.authenticate", extra={
            "connector_id": self.connector_id,
            "status": "ok",
        })
        self._authenticated = True
        return True

    def validate_config(self) -> bool:
        """Ensure a readable file_path is provided."""
        file_path = self._resolve_file_path()
        if not file_path:
            raise ConnectorConfigError(
                "file_path must be set in credentials or custom_config"
            )
        if not os.path.isfile(file_path):
            raise ConnectorConfigError(f"file not found: {file_path}")

        logger.info("csv_connector.validate_config", extra={
            "connector_id": self.connector_id,
            "file_path": file_path,
            "status": "valid",
        })
        return True

    def extract_batch(
        self,
        cursor: Optional[str] = None,
        batch_size: Optional[int] = None,
    ) -> ExtractionBatch:
        """Read *batch_size* rows starting at the row offset in *cursor*."""
        file_path = self._resolve_file_path()
        if not file_path:
            raise ConnectorExtractionError("file_path is not configured")

        size = batch_size or self.config.batch_size
        offset = int(cursor) if cursor else 0

        logger.info("csv_connector.extract_batch", extra={
            "connector_id": self.connector_id,
            "file_path": file_path,
            "offset": offset,
            "batch_size": size,
        })

        rows = self._read_rows(file_path)
        batch_rows = rows[offset: offset + size]

        items: List[RawItem] = []
        permissions: List[PermissionMetadata] = []

        for idx, row in enumerate(batch_rows):
            row_number = offset + idx
            source_id = f"csv-row-{row_number}"

            raw_data: Dict[str, Any] = dict(row)
            content = self._build_content(row)
            if content:
                raw_data["_content"] = content

            item = RawItem(
                source_id=source_id,
                source_type="csv_row",
                raw_data=raw_data,
                extracted_at=datetime.now(timezone.utc),
                extractor_version=self.version,
            )
            items.append(item)
            permissions.append(self.extract_permissions(item))

        has_more = (offset + size) < len(rows)
        next_cursor = str(offset + size) if has_more else None

        self._items_extracted += len(items)
        self.set_current_cursor(next_cursor)

        logger.info("csv_connector.extract_batch.done", extra={
            "connector_id": self.connector_id,
            "items": len(items),
            "has_more": has_more,
            "next_cursor": next_cursor,
        })

        return ExtractionBatch(
            items=items,
            permissions=permissions,
            next_cursor=next_cursor,
            has_more=has_more,
            batch_number=(offset // size) + 1,
        )

    def extract_permissions(self, item: RawItem) -> PermissionMetadata:
        """Derive permission metadata from the row data."""
        cfg = self.config.custom_config
        raw = item.raw_data

        scope = "public"
        user_ids: List[str] = []
        team_ids: List[str] = []

        scope_col = cfg.get("scope_column")
        if scope_col and scope_col in raw:
            scope = str(raw[scope_col]).strip() or "public"

        user_col = cfg.get("user_ids_column")
        if user_col and user_col in raw:
            user_ids = [
                uid.strip()
                for uid in str(raw[user_col]).split(",")
                if uid.strip()
            ]

        team_col = cfg.get("team_ids_column")
        if team_col and team_col in raw:
            team_ids = [
                tid.strip()
                for tid in str(raw[team_col]).split(",")
                if tid.strip()
            ]

        return PermissionMetadata(
            source_id=item.source_id,
            raw_permissions={"source": "csv", "scope": scope},
            suggested_scope=scope,
            suggested_user_ids=user_ids,
            suggested_team_ids=team_ids,
        )

    def supports_incremental(self) -> bool:
        return False

    def get_incremental_mode(self) -> IncrementalMode:
        return IncrementalMode.FULL

    def estimate_total_items(self) -> Optional[int]:
        """Count rows in the CSV (cheap for small files)."""
        file_path = self._resolve_file_path()
        if not file_path or not os.path.isfile(file_path):
            return None
        return len(self._read_rows(file_path))

    # -- internal helpers ----------------------------------------------------

    def _resolve_file_path(self) -> Optional[str]:
        """Look for file_path in custom_config first, then credentials."""
        path = self.config.custom_config.get("file_path")
        if not path:
            path = self.config.credentials.get("file_path")
        return path

    def _read_rows(self, file_path: str) -> List[Dict[str, str]]:
        """Parse the entire CSV into a list of dicts."""
        delimiter = self.config.custom_config.get("delimiter", ",")
        encoding = self.config.custom_config.get("encoding", "utf-8")

        try:
            with open(file_path, newline="", encoding=encoding) as fh:
                reader = csv.DictReader(fh, delimiter=delimiter)
                return list(reader)
        except Exception as exc:
            logger.error("csv_connector.read_error", extra={
                "connector_id": self.connector_id,
                "file_path": file_path,
                "error": str(exc),
            })
            raise ConnectorExtractionError(
                f"Failed to read CSV file: {exc}"
            ) from exc

    def _build_content(self, row: Dict[str, str]) -> Optional[str]:
        """Concatenate configured content columns into a single string."""
        columns = self.config.custom_config.get("content_columns")
        if not columns:
            return None
        parts = [str(row[col]) for col in columns if col in row]
        return " ".join(parts) if parts else None


# ============================================================================
# HELPER: quick config factory
# ============================================================================


def create_csv_config(
    connector_id: str,
    tenant_id: str,
    file_path: str,
    **kwargs: Any,
) -> ConnectorConfig:
    """
    Create a ConnectorConfig pre-filled for the CSV connector.

    Parameters
    ----------
    connector_id : str
        Unique identifier for this connector instance.
    tenant_id : str
        Tenant that owns the connector.
    file_path : str
        Path to the CSV file on disk.
    **kwargs
        Extra keys forwarded to custom_config.  Recognised keys:
        delimiter, encoding, content_columns, scope_column,
        user_ids_column, team_ids_column.
    """
    custom_config: Dict[str, Any] = {"file_path": file_path}

    forwarded_keys = [
        "delimiter",
        "encoding",
        "content_columns",
        "scope_column",
        "user_ids_column",
        "team_ids_column",
    ]
    for key in forwarded_keys:
        if key in kwargs:
            custom_config[key] = kwargs.pop(key)

    return ConnectorConfig(
        connector_id=connector_id,
        connector_type="csv",
        tenant_id=tenant_id,
        auth_type=ConnectorAuthType.API_KEY,
        credentials={},
        incremental_mode=IncrementalMode.FULL,
        custom_config=custom_config,
        **kwargs,
    )
