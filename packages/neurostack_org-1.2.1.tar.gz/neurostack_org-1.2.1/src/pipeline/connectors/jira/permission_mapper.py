"""
Jira permission mapper.

Converts Jira project roles and issue security levels into
IndexedVisibility records suitable for access-control filtering.
"""

import logging
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from neurostack.models.permission import (
    IndexedVisibility,
    PermissionRecord,
    RawPermission,
    VisibilityScope,
)
from pipeline.connectors.base import PermissionMetadata

logger = logging.getLogger(__name__)

_JIRA_PERMISSION_TTL_SECONDS = 900  # 15 minutes

_SCOPE_MAP: Dict[str, VisibilityScope] = {
    "public": VisibilityScope.PUBLIC,
    "team": VisibilityScope.TEAM,
    "private": VisibilityScope.PRIVATE,
    "restricted": VisibilityScope.RESTRICTED,
}


class JiraPermissionMapper:
    """Map Jira permission metadata to unified PermissionRecord objects."""

    def __init__(self, ttl_seconds: int = _JIRA_PERMISSION_TTL_SECONDS) -> None:
        self._ttl_seconds = ttl_seconds

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def map_permissions(
        self,
        source_id: str,
        raw_permissions: Dict[str, Any],
        suggested_scope: Optional[str],
        suggested_user_ids: List[str],
        suggested_team_ids: List[str],
        tenant_id: str,
    ) -> PermissionRecord:
        """Convert Jira permission data into a PermissionRecord.

        Args:
            source_id: Jira issue identifier (e.g. ``PROJ-123``).
            raw_permissions: Raw permission dict produced by the Jira connector.
            suggested_scope: Scope hint from the connector (``"team"`` / ``"private"``).
            suggested_user_ids: User IDs with explicit access.
            suggested_team_ids: Team/project keys with access.
            tenant_id: Tenant that owns the data.

        Returns:
            A fully populated ``PermissionRecord``.
        """
        now = datetime.now(timezone.utc)

        scope = self._resolve_scope(raw_permissions, suggested_scope)
        user_ids = self._collect_user_ids(raw_permissions, suggested_user_ids)
        team_ids = self._collect_team_ids(raw_permissions, suggested_team_ids)

        logger.debug(
            "Mapped Jira permissions for %s: scope=%s users=%d teams=%d",
            source_id,
            scope.value,
            len(user_ids),
            len(team_ids),
        )

        raw = RawPermission(
            content_id=source_id,
            source_type="jira",
            source_id=source_id,
            raw_data=raw_permissions,
            extracted_at=now,
            extractor_version="1.0",
        )

        indexed = IndexedVisibility(
            content_id=source_id,
            scope=scope,
            user_ids=user_ids,
            team_ids=team_ids,
            computed_at=now,
            derived_from="jira_permission_mapper",
            expires_at=now + timedelta(seconds=self._ttl_seconds),
        )

        record = PermissionRecord(
            id=str(uuid.uuid4()),
            content_id=source_id,
            tenant_id=tenant_id,
            raw=raw,
            indexed=indexed,
            created_at=now,
            updated_at=now,
            created_by="jira_permission_mapper",
            last_synced_at=now,
        )

        return record

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _resolve_scope(
        raw_permissions: Dict[str, Any],
        suggested_scope: Optional[str],
    ) -> VisibilityScope:
        """Determine the visibility scope.

        Rules:
        * If a ``security_level`` is present and non-empty the issue is
          considered private regardless of the connector hint.
        * Otherwise the connector's ``suggested_scope`` is honoured.
        * Falls back to ``TEAM`` when nothing else applies.
        """
        security_level = raw_permissions.get("security_level")
        if security_level:
            logger.debug(
                "Security level '%s' detected — scope set to PRIVATE",
                security_level,
            )
            return VisibilityScope.PRIVATE

        if suggested_scope and suggested_scope in _SCOPE_MAP:
            return _SCOPE_MAP[suggested_scope]

        return VisibilityScope.TEAM

    @staticmethod
    def _collect_user_ids(
        raw_permissions: Dict[str, Any],
        suggested_user_ids: List[str],
    ) -> List[str]:
        """Build a deduplicated list of user IDs with access."""
        user_ids: List[str] = []
        seen: set[str] = set()

        def _add(uid: Optional[str]) -> None:
            if uid and uid not in seen:
                seen.add(uid)
                user_ids.append(uid)

        # Explicit users from the connector hint.
        for uid in suggested_user_ids:
            _add(uid)

        # Reporter and assignee embedded in the raw data.
        reporter = raw_permissions.get("reporter")
        if isinstance(reporter, dict):
            _add(reporter.get("accountId") or reporter.get("id"))

        assignee = raw_permissions.get("assignee")
        if isinstance(assignee, dict):
            _add(assignee.get("accountId") or assignee.get("id"))

        return user_ids

    @staticmethod
    def _collect_team_ids(
        raw_permissions: Dict[str, Any],
        suggested_team_ids: List[str],
    ) -> List[str]:
        """Build a deduplicated list of team IDs (project keys)."""
        team_ids: List[str] = []
        seen: set[str] = set()

        for tid in suggested_team_ids:
            if tid and tid not in seen:
                seen.add(tid)
                team_ids.append(tid)

        project_key = raw_permissions.get("project_key")
        if project_key and project_key not in seen:
            seen.add(project_key)
            team_ids.append(project_key)

        return team_ids


# ----------------------------------------------------------------------
# Convenience function
# ----------------------------------------------------------------------

_default_mapper = JiraPermissionMapper()


def map_jira_permissions(
    permission_metadata: PermissionMetadata,
    tenant_id: str,
) -> PermissionRecord:
    """Map a ``PermissionMetadata`` produced by the Jira connector to a
    ``PermissionRecord``.

    This is a thin wrapper around :class:`JiraPermissionMapper` intended
    for call-sites that do not need to customise the mapper.

    Args:
        permission_metadata: Output of ``JiraConnector.extract_permissions``.
        tenant_id: Tenant that owns the data.

    Returns:
        A ``PermissionRecord`` ready for storage.
    """
    return _default_mapper.map_permissions(
        source_id=permission_metadata.source_id,
        raw_permissions=permission_metadata.raw_permissions,
        suggested_scope=permission_metadata.suggested_scope,
        suggested_user_ids=permission_metadata.suggested_user_ids,
        suggested_team_ids=permission_metadata.suggested_team_ids,
        tenant_id=tenant_id,
    )
