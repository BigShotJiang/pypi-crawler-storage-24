"""
Google Workspace authentication manager.

Handles OAuth2 and service account authentication for Google APIs
(Drive, Docs, Calendar, etc.).

Uses google-auth and google-api-python-client libraries.
"""

import logging
from datetime import datetime, timezone
from typing import Any, Dict, Optional

logger = logging.getLogger("neurostack.pipeline.connectors.google_workspace.auth")

try:
    from google.auth.transport.requests import Request
    from google.oauth2 import service_account as sa_module
    from google.oauth2.credentials import Credentials as UserCredentials
    from googleapiclient.discovery import build

    _GOOGLE_LIBS_AVAILABLE = True
except ImportError:
    _GOOGLE_LIBS_AVAILABLE = False
    logger.warning(
        "google-auth / google-api-python-client not installed. "
        "Install with: pip install google-auth google-api-python-client"
    )


def _require_google_libs() -> None:
    """Raise ImportError when the Google client libraries are missing."""
    if not _GOOGLE_LIBS_AVAILABLE:
        raise ImportError(
            "google-auth and google-api-python-client are required for "
            "Google Workspace connectors. Install with: "
            "pip install google-auth google-api-python-client"
        )


# Default OAuth scopes used by the Google Docs connector.
DEFAULT_SCOPES = [
    "https://www.googleapis.com/auth/drive.readonly",
    "https://www.googleapis.com/auth/documents.readonly",
]


class GoogleAuthManager:
    """Manage Google OAuth2 and service account credentials.

    Supports two authentication flows:

    1. **Service account** -- uses a JSON key file (or dict) to create
       credentials that can be domain-wide delegated.
    2. **User OAuth** -- uses an ``access_token`` and optional
       ``refresh_token`` / ``client_id`` / ``client_secret`` to build
       user-level credentials.

    The manager caches the active credential object and transparently
    refreshes expired tokens when :meth:`refresh_if_needed` is called.
    """

    def __init__(self, scopes: Optional[list] = None) -> None:
        _require_google_libs()
        self._scopes = scopes or DEFAULT_SCOPES
        self._credentials = None  # google.auth.credentials.Credentials
        self._auth_type: Optional[str] = None  # "service_account" | "user_token"
        self._authenticated_at: Optional[datetime] = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def authenticate_service_account(
        self,
        credentials_json: Dict[str, Any],
        subject: Optional[str] = None,
    ) -> bool:
        """Authenticate using a service account key.

        Args:
            credentials_json: Parsed JSON key dict (the contents of a
                Google Cloud service-account key file).
            subject: Optional email to impersonate via domain-wide
                delegation.

        Returns:
            ``True`` on success.

        Raises:
            ValueError: If the key dict is missing required fields.
            google.auth.exceptions.DefaultCredentialsError: On auth failure.
        """
        _require_google_libs()

        creds = sa_module.Credentials.from_service_account_info(
            credentials_json,
            scopes=self._scopes,
        )

        if subject:
            creds = creds.with_subject(subject)

        # Force an initial token fetch to verify the key is valid.
        creds.refresh(Request())

        self._credentials = creds
        self._auth_type = "service_account"
        self._authenticated_at = datetime.now(timezone.utc)

        logger.info(
            "Service account authenticated (email=%s, subject=%s)",
            credentials_json.get("client_email", "unknown"),
            subject or "none",
        )
        return True

    def authenticate_user_token(
        self,
        access_token: str,
        refresh_token: Optional[str] = None,
        client_id: Optional[str] = None,
        client_secret: Optional[str] = None,
        token_uri: str = "https://oauth2.googleapis.com/token",
    ) -> bool:
        """Authenticate using a user OAuth2 access token.

        Args:
            access_token: A valid Google OAuth2 access token.
            refresh_token: Optional refresh token for automatic renewal.
            client_id: OAuth client ID (required when *refresh_token* is
                supplied).
            client_secret: OAuth client secret (required when
                *refresh_token* is supplied).
            token_uri: Token endpoint URL.

        Returns:
            ``True`` on success.
        """
        _require_google_libs()

        creds = UserCredentials(
            token=access_token,
            refresh_token=refresh_token,
            client_id=client_id,
            client_secret=client_secret,
            token_uri=token_uri,
            scopes=self._scopes,
        )

        self._credentials = creds
        self._auth_type = "user_token"
        self._authenticated_at = datetime.now(timezone.utc)

        logger.info("User OAuth token authenticated")
        return True

    def get_credentials(self):
        """Return the current Google credentials object.

        Returns:
            A ``google.auth.credentials.Credentials`` instance, or
            ``None`` if not yet authenticated.
        """
        return self._credentials

    def refresh_if_needed(self) -> bool:
        """Refresh the access token if it has expired.

        Returns:
            ``True`` if credentials are valid (possibly after refresh).
            ``False`` if no credentials are available or refresh failed.
        """
        if self._credentials is None:
            logger.warning("refresh_if_needed called before authentication")
            return False

        if not self._credentials.valid:
            try:
                self._credentials.refresh(Request())
                logger.debug("Credentials refreshed successfully")
            except Exception:
                logger.exception("Failed to refresh Google credentials")
                return False

        return True

    def build_service(self, api_name: str, api_version: str):
        """Build and return a Google API service client.

        Convenience wrapper around ``googleapiclient.discovery.build``.

        Args:
            api_name: API name (e.g. ``"drive"``, ``"docs"``).
            api_version: API version (e.g. ``"v3"``, ``"v1"``).

        Returns:
            A ``googleapiclient.discovery.Resource`` instance.

        Raises:
            RuntimeError: If credentials have not been set up yet.
        """
        if self._credentials is None:
            raise RuntimeError(
                "Cannot build service: not authenticated. "
                "Call authenticate_service_account() or authenticate_user_token() first."
            )

        self.refresh_if_needed()

        return build(
            api_name,
            api_version,
            credentials=self._credentials,
            cache_discovery=False,
        )

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    @property
    def auth_type(self) -> Optional[str]:
        """Return the active authentication type."""
        return self._auth_type

    @property
    def is_authenticated(self) -> bool:
        """Return ``True`` when credentials are available."""
        return self._credentials is not None

    @property
    def authenticated_at(self) -> Optional[datetime]:
        """UTC timestamp of when authentication succeeded."""
        return self._authenticated_at
