"""
Google Workspace permission mapper.

Converts Google Drive sharing permissions into IndexedVisibility records
suitable for access-control filtering.

Permission type mapping:
- ``anyone``  -> VisibilityScope.PUBLIC
- ``domain``  -> VisibilityScope.TEAM  (domain as team_id)
- ``group``   -> VisibilityScope.TEAM  (group email as team_id)
- ``user``    -> depends on role:
    - owner / writer  -> VisibilityScope.TEAM
    - commenter / reader with restricted sharing -> VisibilityScope.PRIVATE
"""

import logging
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from neurostack.models.permission import (
    IndexedVisibility,
    PermissionRecord,
    RawPermission,
    VisibilityScope,
)
from pipeline.connectors.base import PermissionMetadata

logger = logging.getLogger(__name__)

_GOOGLE_PERMISSION_TTL_SECONDS = 3600  # 1 hour for Google Docs

_SCOPE_MAP: Dict[str, VisibilityScope] = {
    "public": VisibilityScope.PUBLIC,
    "team": VisibilityScope.TEAM,
    "private": VisibilityScope.PRIVATE,
    "restricted": VisibilityScope.RESTRICTED,
}

# Google Drive roles that imply broad (team-level) access when combined
# with a ``user`` permission type.
_BROAD_ROLES = {"owner", "writer", "organizer", "fileOrganizer"}


class GooglePermissionMapper:
    """Map Google Drive sharing permissions to unified PermissionRecord objects."""

    def __init__(self, ttl_seconds: int = _GOOGLE_PERMISSION_TTL_SECONDS) -> None:
        self._ttl_seconds = ttl_seconds

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def map_permissions(
        self,
        source_id: str,
        raw_permissions: Dict[str, Any],
        suggested_scope: Optional[str],
        suggested_user_ids: List[str],
        suggested_team_ids: List[str],
        tenant_id: str,
    ) -> PermissionRecord:
        """Convert Google Drive permission data into a PermissionRecord.

        Args:
            source_id: Google Drive file ID.
            raw_permissions: Raw permission dict produced by the Google
                Docs connector (contains ``drive_permissions``, ``owners``,
                ``shared``, ``parents``).
            suggested_scope: Scope hint from the connector.
            suggested_user_ids: User emails with explicit access.
            suggested_team_ids: Team/domain identifiers with access.
            tenant_id: Tenant that owns the data.

        Returns:
            A fully populated ``PermissionRecord``.
        """
        now = datetime.now(timezone.utc)

        scope = self._resolve_scope(raw_permissions, suggested_scope)
        user_ids = self._collect_user_ids(raw_permissions, suggested_user_ids)
        team_ids = self._collect_team_ids(raw_permissions, suggested_team_ids)

        logger.debug(
            "Mapped Google permissions for %s: scope=%s users=%d teams=%d",
            source_id,
            scope.value,
            len(user_ids),
            len(team_ids),
        )

        raw = RawPermission(
            content_id=source_id,
            source_type="google_docs",
            source_id=source_id,
            raw_data=raw_permissions,
            extracted_at=now,
            extractor_version="1.0",
        )

        indexed = IndexedVisibility(
            content_id=source_id,
            scope=scope,
            user_ids=user_ids,
            team_ids=team_ids,
            computed_at=now,
            derived_from="google_permission_mapper",
            expires_at=now + timedelta(seconds=self._ttl_seconds),
        )

        record = PermissionRecord(
            id=str(uuid.uuid4()),
            content_id=source_id,
            tenant_id=tenant_id,
            raw=raw,
            indexed=indexed,
            created_at=now,
            updated_at=now,
            created_by="google_permission_mapper",
            last_synced_at=now,
        )

        return record

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _resolve_scope(
        raw_permissions: Dict[str, Any],
        suggested_scope: Optional[str],
    ) -> VisibilityScope:
        """Determine the visibility scope from Drive permissions.

        Rules (applied in priority order):
        1. If any permission has ``type == "anyone"`` the document is
           **PUBLIC**.
        2. If any permission has ``type == "domain"`` or ``type == "group"``
           the document is **TEAM**.
        3. If only ``user`` permissions exist with broad roles
           (owner/writer) the document is **TEAM**.
        4. If only ``user`` permissions exist with restricted roles
           (commenter/reader) the document is **PRIVATE**.
        5. Falls back to the connector's ``suggested_scope``.
        6. Default: **PRIVATE**.
        """
        drive_permissions: List[Dict[str, Any]] = raw_permissions.get(
            "drive_permissions", []
        )

        has_anyone = False
        has_domain_or_group = False
        has_broad_user = False
        has_restricted_user = False

        for perm in drive_permissions:
            perm_type = perm.get("type", "")
            role = perm.get("role", "")

            if perm_type == "anyone":
                has_anyone = True
            elif perm_type in ("domain", "group"):
                has_domain_or_group = True
            elif perm_type == "user":
                if role in _BROAD_ROLES:
                    has_broad_user = True
                else:
                    has_restricted_user = True

        if has_anyone:
            return VisibilityScope.PUBLIC

        if has_domain_or_group:
            return VisibilityScope.TEAM

        if has_broad_user:
            return VisibilityScope.TEAM

        if has_restricted_user:
            return VisibilityScope.PRIVATE

        # Fall back to the connector hint.
        if suggested_scope and suggested_scope in _SCOPE_MAP:
            return _SCOPE_MAP[suggested_scope]

        return VisibilityScope.PRIVATE

    @staticmethod
    def _collect_user_ids(
        raw_permissions: Dict[str, Any],
        suggested_user_ids: List[str],
    ) -> List[str]:
        """Build a deduplicated list of user email addresses with access."""
        user_ids: List[str] = []
        seen: set = set()

        def _add(uid: Optional[str]) -> None:
            if uid and uid not in seen:
                seen.add(uid)
                user_ids.append(uid)

        # Explicit users from the connector hint.
        for uid in suggested_user_ids:
            _add(uid)

        # Users from Drive permissions.
        drive_permissions: List[Dict[str, Any]] = raw_permissions.get(
            "drive_permissions", []
        )
        for perm in drive_permissions:
            if perm.get("type") == "user":
                _add(perm.get("emailAddress"))

        # Owners embedded in the raw data.
        owners: List[Dict[str, Any]] = raw_permissions.get("owners", [])
        for owner in owners:
            _add(owner.get("emailAddress"))

        return user_ids

    @staticmethod
    def _collect_team_ids(
        raw_permissions: Dict[str, Any],
        suggested_team_ids: List[str],
    ) -> List[str]:
        """Build a deduplicated list of team IDs (domains / group emails)."""
        team_ids: List[str] = []
        seen: set = set()

        def _add(tid: Optional[str]) -> None:
            if tid and tid not in seen:
                seen.add(tid)
                team_ids.append(tid)

        # Explicit teams from the connector hint.
        for tid in suggested_team_ids:
            _add(tid)

        # Domains and groups from Drive permissions.
        drive_permissions: List[Dict[str, Any]] = raw_permissions.get(
            "drive_permissions", []
        )
        for perm in drive_permissions:
            perm_type = perm.get("type", "")
            if perm_type == "domain":
                _add(perm.get("domain"))
            elif perm_type == "group":
                _add(perm.get("emailAddress"))

        # Inherit parent folder IDs as team context (for permission
        # inheritance tracking).
        parents: List[str] = raw_permissions.get("parents", [])
        for parent_id in parents:
            _add(f"folder:{parent_id}")

        return team_ids


# ----------------------------------------------------------------------
# Convenience function
# ----------------------------------------------------------------------

_default_mapper = GooglePermissionMapper()


def map_google_permissions(
    permission_metadata: PermissionMetadata,
    tenant_id: str,
) -> PermissionRecord:
    """Map a ``PermissionMetadata`` produced by the Google Docs connector
    to a ``PermissionRecord``.

    This is a thin wrapper around :class:`GooglePermissionMapper` intended
    for call-sites that do not need to customise the mapper.

    Args:
        permission_metadata: Output of
            ``GoogleDocsConnector.extract_permissions``.
        tenant_id: Tenant that owns the data.

    Returns:
        A ``PermissionRecord`` ready for storage.
    """
    return _default_mapper.map_permissions(
        source_id=permission_metadata.source_id,
        raw_permissions=permission_metadata.raw_permissions,
        suggested_scope=permission_metadata.suggested_scope,
        suggested_user_ids=permission_metadata.suggested_user_ids,
        suggested_team_ids=permission_metadata.suggested_team_ids,
        tenant_id=tenant_id,
    )
