"""
Google Docs connector implementation.

Extracts Google Docs documents via the Google Drive and Docs APIs.
Supports service account and user OAuth authentication, cursor-based
pagination (Drive page tokens), and incremental sync via modifiedTime.

Google Drive API: https://developers.google.com/drive/api/reference/rest/v3
Google Docs API: https://developers.google.com/docs/api/reference/rest/v1
"""

import json
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from ..base import (
    Connector,
    ConnectorAuthType,
    ConnectorConfig,
    ConnectorConfigError,
    ConnectorAuthError,
    ConnectorExtractionError,
    ConnectorRateLimitError,
    ExtractionBatch,
    IncrementalMode,
    PermissionMetadata,
    RawItem,
)
from .auth import GoogleAuthManager

logger = logging.getLogger("neurostack.pipeline.connectors.google_workspace.docs")

# Google Docs MIME type used when querying the Drive API.
GOOGLE_DOCS_MIME_TYPE = "application/vnd.google-apps.document"


class GoogleDocsConnector(Connector):
    """Connector for extracting Google Docs documents.

    Supported features:
    - Service account and user OAuth authentication
    - Cursor-based pagination (Drive page tokens)
    - Incremental sync via ``modifiedTime``
    - Shared drive support
    - Permission extraction from Drive sharing settings

    Configuration:
        credentials (SERVICE_ACCOUNT):
            - service_account_key: dict -- parsed JSON key for a Google
              Cloud service account.
            - subject: str (optional) -- email to impersonate via
              domain-wide delegation.

        credentials (OAUTH_USER):
            - access_token: str
            - refresh_token: str (optional)
            - client_id: str (optional, required if refresh_token set)
            - client_secret: str (optional, required if refresh_token set)

        custom_config:
            - root_folder_id: str (optional) -- restrict extraction to a
              specific Drive folder.
            - include_shared_drives: bool (default ``True``) -- include
              documents in shared drives.
            - file_mime_types: list[str] (optional) -- additional MIME
              types to extract (default: Google Docs only).
    """

    # ------------------------------------------------------------------
    # Metadata
    # ------------------------------------------------------------------

    @property
    def name(self) -> str:
        return "Google Docs"

    @property
    def version(self) -> str:
        return "1.0.0"

    @property
    def description(self) -> str:
        return "Extracts documents from Google Docs via Drive and Docs APIs"

    # ------------------------------------------------------------------
    # Constants
    # ------------------------------------------------------------------

    # Fields requested from the Drive files.list endpoint.
    DRIVE_FILE_FIELDS = (
        "files(id,name,mimeType,createdTime,modifiedTime,owners,"
        "lastModifyingUser,webViewLink,parents,shared,trashed),"
        "nextPageToken"
    )

    # ------------------------------------------------------------------
    # Init
    # ------------------------------------------------------------------

    def __init__(self, config: ConnectorConfig) -> None:
        super().__init__(config)

        # Custom config
        self.root_folder_id: Optional[str] = config.custom_config.get("root_folder_id")
        self.include_shared_drives: bool = config.custom_config.get(
            "include_shared_drives", True
        )
        self.file_mime_types: List[str] = config.custom_config.get(
            "file_mime_types", [GOOGLE_DOCS_MIME_TYPE]
        )

        # Auth manager and API services (set during authenticate())
        self._auth_manager: Optional[GoogleAuthManager] = None
        self._drive_service = None
        self._docs_service = None

        # Rate limiting tracking
        self._requests_made: int = 0
        self._last_request_time: Optional[datetime] = None

        logger.info(
            "Initialized GoogleDocsConnector (connector_id=%s, tenant=%s)",
            self.connector_id,
            self.tenant_id,
        )

    # ------------------------------------------------------------------
    # Authentication
    # ------------------------------------------------------------------

    def authenticate(self) -> bool:
        """Authenticate with Google APIs and build Drive + Docs services.

        Returns:
            ``True`` if authentication succeeds.

        Raises:
            ConnectorAuthError: On any authentication failure.
        """
        try:
            self._auth_manager = GoogleAuthManager()

            if self.config.auth_type == ConnectorAuthType.SERVICE_ACCOUNT:
                key = self.config.credentials.get("service_account_key")
                if not key:
                    raise ConnectorAuthError(
                        "Missing 'service_account_key' in credentials"
                    )
                # Allow key to be a JSON string or a dict.
                if isinstance(key, str):
                    key = json.loads(key)

                subject = self.config.credentials.get("subject")
                self._auth_manager.authenticate_service_account(key, subject=subject)

            elif self.config.auth_type == ConnectorAuthType.OAUTH_USER:
                access_token = self.config.credentials.get("access_token")
                if not access_token:
                    raise ConnectorAuthError(
                        "Missing 'access_token' in credentials"
                    )
                self._auth_manager.authenticate_user_token(
                    access_token=access_token,
                    refresh_token=self.config.credentials.get("refresh_token"),
                    client_id=self.config.credentials.get("client_id"),
                    client_secret=self.config.credentials.get("client_secret"),
                )

            else:
                raise ConnectorAuthError(
                    f"Unsupported auth type for Google Docs: {self.config.auth_type.value}. "
                    "Use SERVICE_ACCOUNT or OAUTH_USER."
                )

            # Build API service clients.
            self._drive_service = self._auth_manager.build_service("drive", "v3")
            self._docs_service = self._auth_manager.build_service("docs", "v1")

            self._authenticated = True
            logger.info("Google Docs connector authenticated successfully")
            return True

        except ConnectorAuthError:
            raise
        except Exception as e:
            raise ConnectorAuthError(
                f"Google authentication failed: {e}"
            ) from e

    # ------------------------------------------------------------------
    # Config validation
    # ------------------------------------------------------------------

    def validate_config(self) -> bool:
        """Validate connector configuration.

        Returns:
            ``True`` if the configuration is valid.

        Raises:
            ConnectorConfigError: When required fields are missing.
        """
        if self.config.auth_type == ConnectorAuthType.SERVICE_ACCOUNT:
            if not self.config.credentials.get("service_account_key"):
                raise ConnectorConfigError(
                    "Missing 'service_account_key' in credentials for SERVICE_ACCOUNT auth"
                )
        elif self.config.auth_type == ConnectorAuthType.OAUTH_USER:
            if not self.config.credentials.get("access_token"):
                raise ConnectorConfigError(
                    "Missing 'access_token' in credentials for OAUTH_USER auth"
                )
        else:
            raise ConnectorConfigError(
                f"Unsupported auth type: {self.config.auth_type.value}. "
                "Google Docs connector supports SERVICE_ACCOUNT or OAUTH_USER."
            )

        # Validate MIME types list
        if self.file_mime_types and not isinstance(self.file_mime_types, list):
            raise ConnectorConfigError("'file_mime_types' must be a list of strings")

        return True

    # ------------------------------------------------------------------
    # Extraction
    # ------------------------------------------------------------------

    def extract_batch(
        self,
        cursor: Optional[str] = None,
        batch_size: Optional[int] = None,
    ) -> ExtractionBatch:
        """Extract a batch of Google Docs documents.

        Uses the Drive API ``files.list`` to discover documents and the
        Docs API ``documents.get`` to fetch document content.

        Args:
            cursor: Drive page token for pagination (``None`` to start).
            batch_size: Number of files to request per page.

        Returns:
            An :class:`ExtractionBatch` containing extracted documents.

        Raises:
            ConnectorExtractionError: On API errors.
            ConnectorRateLimitError: When rate-limited by Google.
        """
        if not self._authenticated:
            raise ConnectorExtractionError(
                "Not authenticated. Call authenticate() first."
            )

        page_size = batch_size or self.config.batch_size
        logger.info(
            "Extracting batch (pageToken=%s, pageSize=%d)",
            cursor or "START",
            page_size,
        )

        try:
            # Build the Drive query.
            query = self._build_drive_query()

            # List files from Drive.
            request_kwargs: Dict[str, Any] = {
                "q": query,
                "pageSize": page_size,
                "fields": self.DRIVE_FILE_FIELDS,
                "orderBy": "modifiedTime desc",
            }
            if cursor:
                request_kwargs["pageToken"] = cursor
            if self.include_shared_drives:
                request_kwargs["includeItemsFromAllDrives"] = True
                request_kwargs["supportsAllDrives"] = True
            if self.root_folder_id:
                # Already handled in the query string; also pass corpora.
                request_kwargs["corpora"] = (
                    "allDrives" if self.include_shared_drives else "user"
                )

            response = self._execute_drive_request(
                self._drive_service.files().list(**request_kwargs)
            )

            files = response.get("files", [])
            next_page_token = response.get("nextPageToken")

            # Fetch document content and build RawItems.
            raw_items: List[RawItem] = []
            permissions: List[PermissionMetadata] = []

            for file_meta in files:
                if file_meta.get("trashed"):
                    continue

                try:
                    raw_item = self._file_to_raw_item(file_meta)
                    raw_items.append(raw_item)

                    perm = self.extract_permissions(raw_item)
                    permissions.append(perm)
                except Exception as exc:
                    logger.warning(
                        "Failed to process file %s (%s): %s",
                        file_meta.get("id"),
                        file_meta.get("name"),
                        exc,
                    )
                    self.log_error(
                        f"Failed to process file {file_meta.get('id')}: {exc}"
                    )

            has_more = next_page_token is not None
            self._items_extracted += len(raw_items)

            logger.info(
                "Extracted %d documents (has_more=%s, total_so_far=%d)",
                len(raw_items),
                has_more,
                self._items_extracted,
            )

            return ExtractionBatch(
                items=raw_items,
                permissions=permissions,
                next_cursor=next_page_token,
                has_more=has_more,
                batch_number=(self._items_extracted // page_size) + 1,
            )

        except (ConnectorRateLimitError, ConnectorExtractionError):
            raise

        except Exception as e:
            raise ConnectorExtractionError(
                f"Failed to extract Google Docs batch: {e}"
            ) from e

    # ------------------------------------------------------------------
    # Permission extraction
    # ------------------------------------------------------------------

    def extract_permissions(self, item: RawItem) -> PermissionMetadata:
        """Extract permission metadata from a Google Doc.

        Calls the Drive API ``permissions.list`` endpoint to retrieve
        sharing settings for the document.

        Args:
            item: A :class:`RawItem` representing a Google Doc.

        Returns:
            :class:`PermissionMetadata` with sharing information.
        """
        file_id = item.source_id
        raw_data = item.raw_data
        file_meta = raw_data.get("file_metadata", raw_data)

        # Fetch permissions from Drive API.
        drive_permissions: List[Dict[str, Any]] = []
        try:
            request_kwargs: Dict[str, Any] = {
                "fileId": file_id,
                "fields": "permissions(id,type,role,emailAddress,domain,displayName)",
            }
            if self.include_shared_drives:
                request_kwargs["supportsAllDrives"] = True

            perm_response = self._execute_drive_request(
                self._drive_service.permissions().list(**request_kwargs)
            )
            drive_permissions = perm_response.get("permissions", [])
        except Exception as exc:
            logger.warning(
                "Failed to fetch permissions for file %s: %s", file_id, exc
            )

        # Determine suggested scope and collect user/team IDs.
        suggested_scope = "team"
        user_ids: List[str] = []
        team_ids: List[str] = []

        for perm in drive_permissions:
            perm_type = perm.get("type", "")
            role = perm.get("role", "")

            if perm_type == "anyone":
                suggested_scope = "public"
            elif perm_type == "domain":
                domain = perm.get("domain", "")
                if domain:
                    team_ids.append(domain)
                if suggested_scope != "public":
                    suggested_scope = "team"
            elif perm_type == "group":
                group_email = perm.get("emailAddress", "")
                if group_email:
                    team_ids.append(group_email)
                if suggested_scope != "public":
                    suggested_scope = "team"
            elif perm_type == "user":
                email = perm.get("emailAddress", "")
                if email:
                    user_ids.append(email)

        # Extract owner information from file metadata.
        owners = file_meta.get("owners", [])
        for owner in owners:
            email = owner.get("emailAddress", "")
            if email and email not in user_ids:
                user_ids.append(email)

        # If only individual users have access (no groups/domains/anyone),
        # and there are very few, scope is private.
        if suggested_scope == "team" and not team_ids:
            suggested_scope = "private"

        return PermissionMetadata(
            source_id=file_id,
            raw_permissions={
                "drive_permissions": drive_permissions,
                "owners": owners,
                "shared": file_meta.get("shared", False),
                "parents": file_meta.get("parents", []),
            },
            suggested_scope=suggested_scope,
            suggested_user_ids=list(dict.fromkeys(user_ids)),  # deduplicate, preserve order
            suggested_team_ids=list(dict.fromkeys(team_ids)),
        )

    # ------------------------------------------------------------------
    # Incremental support
    # ------------------------------------------------------------------

    def supports_incremental(self) -> bool:
        """Google Docs supports incremental sync via modifiedTime."""
        return True

    def get_incremental_mode(self) -> IncrementalMode:
        """Uses cursor (page token) combined with timestamp filtering."""
        return IncrementalMode.CURSOR

    # ------------------------------------------------------------------
    # Rate limiting
    # ------------------------------------------------------------------

    def get_rate_limit_info(self) -> Dict[str, Any]:
        """Return current rate limiting state."""
        return {
            "requests_made": self._requests_made,
            "limit_per_minute": self.config.rate_limit_per_minute,
            "last_request_time": (
                self._last_request_time.isoformat()
                if self._last_request_time
                else None
            ),
            "note": "Google Drive API: 12,000 queries/minute per project",
        }

    # ------------------------------------------------------------------
    # Cleanup
    # ------------------------------------------------------------------

    def cleanup(self) -> None:
        """Release API service resources."""
        self._drive_service = None
        self._docs_service = None
        self._auth_manager = None
        logger.info("GoogleDocsConnector cleanup complete")

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _build_drive_query(self) -> str:
        """Build the ``q`` parameter for Drive ``files.list``.

        Applies MIME type filter, trashed filter, and optional folder
        restriction.  When ``last_sync_timestamp`` is set on the config,
        only documents modified after that timestamp are returned.

        Returns:
            A Drive query string.
        """
        clauses: List[str] = []

        # MIME type filter
        if len(self.file_mime_types) == 1:
            clauses.append(f"mimeType = '{self.file_mime_types[0]}'")
        else:
            mime_clauses = " or ".join(
                f"mimeType = '{mt}'" for mt in self.file_mime_types
            )
            clauses.append(f"({mime_clauses})")

        # Exclude trashed files
        clauses.append("trashed = false")

        # Folder restriction
        if self.root_folder_id:
            clauses.append(f"'{self.root_folder_id}' in parents")

        # Incremental: only files modified after last sync
        if self.config.last_sync_timestamp:
            ts = self.config.last_sync_timestamp.strftime("%Y-%m-%dT%H:%M:%S")
            clauses.append(f"modifiedTime > '{ts}'")

        return " and ".join(clauses)

    def _file_to_raw_item(self, file_meta: Dict[str, Any]) -> RawItem:
        """Convert a Drive file metadata dict (+ Docs content) to a RawItem.

        For Google Docs files, the full document structure is fetched via
        the Docs API and embedded in ``raw_data["document"]``.

        Args:
            file_meta: File metadata from Drive ``files.list``.

        Returns:
            A :class:`RawItem`.
        """
        file_id = file_meta["id"]
        mime_type = file_meta.get("mimeType", "")

        # Fetch document content if it is a Google Doc.
        document_content: Optional[Dict[str, Any]] = None
        if mime_type == GOOGLE_DOCS_MIME_TYPE and self._docs_service:
            try:
                document_content = self._execute_docs_request(
                    self._docs_service.documents().get(documentId=file_id)
                )
            except Exception as exc:
                logger.warning(
                    "Failed to fetch Docs content for %s: %s", file_id, exc
                )

        raw_data: Dict[str, Any] = {
            "file_metadata": file_meta,
        }
        if document_content is not None:
            raw_data["document"] = document_content

        source_url = file_meta.get("webViewLink")

        return RawItem(
            source_id=file_id,
            source_type="google_doc",
            raw_data=raw_data,
            extracted_at=datetime.now(timezone.utc),
            extractor_version=self.version,
            source_url=source_url,
        )

    def _execute_drive_request(self, request) -> Dict[str, Any]:
        """Execute a Drive API request with rate-limit handling.

        Args:
            request: A ``googleapiclient`` HttpRequest.

        Returns:
            Parsed JSON response dict.

        Raises:
            ConnectorRateLimitError: On HTTP 429.
            ConnectorExtractionError: On other HTTP errors.
        """
        return self._execute_api_request(request, api_name="Drive")

    def _execute_docs_request(self, request) -> Dict[str, Any]:
        """Execute a Docs API request with rate-limit handling."""
        return self._execute_api_request(request, api_name="Docs")

    def _execute_api_request(
        self, request, api_name: str = "Google"
    ) -> Dict[str, Any]:
        """Execute a Google API request.

        Tracks requests for rate-limit monitoring and translates Google
        API HTTP errors into connector exceptions.

        Args:
            request: A ``googleapiclient`` HttpRequest object.
            api_name: Human-readable API name for log messages.

        Returns:
            Parsed JSON response dict.
        """
        try:
            from googleapiclient.errors import HttpError
        except ImportError:
            HttpError = Exception  # type: ignore[misc]

        self._requests_made += 1
        self._last_request_time = datetime.now(timezone.utc)

        # Refresh credentials if needed.
        if self._auth_manager:
            self._auth_manager.refresh_if_needed()

        try:
            return request.execute()
        except HttpError as exc:
            status_code = getattr(exc, "status_code", None) or getattr(
                getattr(exc, "resp", None), "status", None
            )
            if status_code == 429:
                # Attempt to extract Retry-After from headers.
                retry_after = 60
                resp = getattr(exc, "resp", None)
                if resp and hasattr(resp, "get"):
                    retry_after = int(resp.get("Retry-After", 60))
                raise ConnectorRateLimitError(
                    f"{api_name} API rate limit exceeded",
                    retry_after_seconds=retry_after,
                ) from exc
            raise ConnectorExtractionError(
                f"{api_name} API error (status={status_code}): {exc}"
            ) from exc


# ======================================================================
# Helper function
# ======================================================================


def create_google_docs_config(
    connector_id: str,
    tenant_id: str,
    auth_type: ConnectorAuthType,
    credentials: Dict[str, Any],
    root_folder_id: Optional[str] = None,
    include_shared_drives: bool = True,
    file_mime_types: Optional[List[str]] = None,
    **kwargs: Any,
) -> ConnectorConfig:
    """Create a :class:`ConnectorConfig` pre-configured for Google Docs.

    Args:
        connector_id: Unique connector instance ID.
        tenant_id: Tenant ID.
        auth_type: ``ConnectorAuthType.SERVICE_ACCOUNT`` or
            ``ConnectorAuthType.OAUTH_USER``.
        credentials: Credentials dict matching the chosen *auth_type*.
        root_folder_id: Optional Drive folder ID to restrict extraction.
        include_shared_drives: Whether to include shared drives.
        file_mime_types: MIME types to extract (defaults to Google Docs).
        **kwargs: Forwarded to :class:`ConnectorConfig`.

    Returns:
        A :class:`ConnectorConfig` instance.
    """
    custom_config: Dict[str, Any] = {}
    if root_folder_id:
        custom_config["root_folder_id"] = root_folder_id
    custom_config["include_shared_drives"] = include_shared_drives
    if file_mime_types:
        custom_config["file_mime_types"] = file_mime_types

    custom_config.update(kwargs.pop("custom_config", {}))

    return ConnectorConfig(
        connector_id=connector_id,
        connector_type="google_docs",
        tenant_id=tenant_id,
        auth_type=auth_type,
        credentials=credentials,
        custom_config=custom_config,
        **kwargs,
    )
