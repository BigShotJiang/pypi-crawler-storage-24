"""
Connector registry.

Manages connector discovery, registration, and instantiation.
This is the central registry that tracks all available connectors
and their capabilities.

Usage:
    # Register connector
    registry = ConnectorRegistry()
    registry.register(JiraConnector)
    
    # List available connectors
    connectors = registry.list_connectors()
    
    # Create connector instance
    connector = registry.create_connector(config)
"""

import importlib
import inspect
import logging
import pkgutil
from typing import Dict, List, Optional, Type, Any
from pathlib import Path

from .base import (
    Connector,
    LiveDataConnector,
    ConnectorConfig,
    ConnectorMetadata,
    ConnectorType,
    ConnectorAuthType,
    IncrementalMode,
    ConnectorError,
    ConnectorConfigError
)


# ============================================================================
# LOGGING
# ============================================================================

logger = logging.getLogger("neurostack.pipeline.connectors.registry")


# ============================================================================
# CONNECTOR REGISTRY
# ============================================================================

class ConnectorRegistry:
    """
    Central registry for all connectors.
    
    Responsibilities:
    - Register connector implementations
    - Discover connectors automatically
    - Validate connector implementations
    - Create connector instances from config
    - Store connector metadata
    """
    
    def __init__(self):
        """Initialize empty registry"""
        self._connectors: Dict[str, Type[Connector]] = {}
        self._metadata: Dict[str, ConnectorMetadata] = {}
        self._aliases: Dict[str, str] = {}  # Alias → canonical type
    
    # -------------------------
    # REGISTRATION
    # -------------------------
    
    def register(
        self,
        connector_class: Type[Connector],
        connector_type: Optional[str] = None,
        metadata: Optional[ConnectorMetadata] = None,
        aliases: Optional[List[str]] = None
    ) -> None:
        """
        Register a connector implementation.
        
        Args:
            connector_class: Connector class to register
            connector_type: Optional type override (default: class name lowercase)
            metadata: Optional metadata (default: auto-generated)
            aliases: Optional list of aliases (e.g., ["jira_cloud", "jira_server"])
            
        Raises:
            ConnectorRegistrationError: If connector invalid or already registered
        """
        # Validate connector class
        if not self._validate_connector_class(connector_class):
            raise ConnectorRegistrationError(
                f"Invalid connector class: {connector_class.__name__}"
            )
        
        # Determine connector type
        if connector_type is None:
            connector_type = self._infer_connector_type(connector_class)
        
        # Check for duplicates
        if connector_type in self._connectors:
            raise ConnectorRegistrationError(
                f"Connector '{connector_type}' already registered"
            )
        
        # Generate metadata if not provided
        if metadata is None:
            metadata = self._generate_metadata(connector_class, connector_type)
        
        # Register
        self._connectors[connector_type] = connector_class
        self._metadata[connector_type] = metadata
        
        # Register aliases
        if aliases:
            for alias in aliases:
                if alias in self._aliases:
                    raise ConnectorRegistrationError(
                        f"Alias '{alias}' already registered"
                    )
                self._aliases[alias] = connector_type
        
        logger.info(f"Registered connector: {connector_type} ({connector_class.__name__})")
    
    def unregister(self, connector_type: str) -> bool:
        """
        Unregister a connector.
        
        Args:
            connector_type: Connector type to unregister
            
        Returns:
            True if unregistered, False if not found
        """
        if connector_type not in self._connectors:
            return False
        
        del self._connectors[connector_type]
        del self._metadata[connector_type]
        
        # Remove aliases
        aliases_to_remove = [
            alias for alias, target in self._aliases.items()
            if target == connector_type
        ]
        for alias in aliases_to_remove:
            del self._aliases[alias]
        
        return True
    
    def auto_discover(self, package_path: Optional[str] = None) -> int:
        """
        Automatically discover and register all connectors.
        
        Searches for connector implementations in the connectors package
        and registers them automatically.
        
        Args:
            package_path: Optional package path to search (default: pipeline.connectors)
            
        Returns:
            Number of connectors discovered and registered
        """
        if package_path is None:
            # Default to pipeline.connectors package
            import pipeline.connectors as connectors_package
            package_path = connectors_package.__path__
            package_name = connectors_package.__name__
        else:
            package_name = package_path
        
        discovered = 0
        
        # Walk through package
        for importer, modname, ispkg in pkgutil.walk_packages(
            path=package_path if isinstance(package_path, list) else [package_path],
            prefix=f"{package_name}."
        ):
            if ispkg:
                continue
            
            try:
                # Import module
                module = importlib.import_module(modname)
                
                # Find Connector subclasses
                for name, obj in inspect.getmembers(module, inspect.isclass):
                    if (issubclass(obj, Connector) and 
                        obj is not Connector and 
                        obj is not LiveDataConnector and
                        obj.__module__ == modname):
                        
                        # Register if not already registered
                        connector_type = self._infer_connector_type(obj)
                        if connector_type not in self._connectors:
                            try:
                                self.register(obj)
                                discovered += 1
                            except ConnectorRegistrationError as e:
                                logger.error(f"Failed to register {obj.__name__}: {e}")
            
            except Exception as e:
                logger.error(f"Failed to import {modname}: {e}")
        
        logger.info(f"Auto-discovered {discovered} connectors")
        return discovered
    
    # -------------------------
    # CONNECTOR CREATION
    # -------------------------
    
    def create_connector(
        self,
        config: ConnectorConfig,
        validate: bool = True
    ) -> Connector:
        """
        Create connector instance from configuration.
        
        Args:
            config: Connector configuration
            validate: Whether to validate config before creating
            
        Returns:
            Connector instance
            
        Raises:
            ConnectorNotFoundError: If connector type not registered
            ConnectorConfigError: If config invalid
        """
        # Resolve aliases
        connector_type = self._resolve_type(config.connector_type)
        
        # Check if registered
        if connector_type not in self._connectors:
            raise ConnectorNotFoundError(
                f"Connector type '{connector_type}' not registered. "
                f"Available: {list(self._connectors.keys())}"
            )
        
        # Get connector class
        connector_class = self._connectors[connector_type]
        
        # Validate config if requested
        if validate:
            self._validate_config(config, connector_type)
        
        # Create instance
        try:
            connector = connector_class(config)
            return connector
        except Exception as e:
            raise ConnectorConfigError(
                f"Failed to create connector '{connector_type}': {e}"
            ) from e
    
    # -------------------------
    # QUERIES
    # -------------------------
    
    def get_connector_class(self, connector_type: str) -> Optional[Type[Connector]]:
        """
        Get connector class by type.
        
        Args:
            connector_type: Connector type
            
        Returns:
            Connector class or None if not found
        """
        connector_type = self._resolve_type(connector_type)
        return self._connectors.get(connector_type)
    
    def get_metadata(self, connector_type: str) -> Optional[ConnectorMetadata]:
        """
        Get connector metadata.
        
        Args:
            connector_type: Connector type
            
        Returns:
            Connector metadata or None if not found
        """
        connector_type = self._resolve_type(connector_type)
        return self._metadata.get(connector_type)
    
    def is_registered(self, connector_type: str) -> bool:
        """
        Check if connector type is registered.
        
        Args:
            connector_type: Connector type
            
        Returns:
            True if registered
        """
        connector_type = self._resolve_type(connector_type)
        return connector_type in self._connectors
    
    def list_connectors(
        self,
        execution_type: Optional[ConnectorType] = None,
        supports_incremental: Optional[bool] = None
    ) -> List[str]:
        """
        List registered connector types.
        
        Args:
            execution_type: Optional filter by execution type
            supports_incremental: Optional filter by incremental support
            
        Returns:
            List of connector types
        """
        connectors = list(self._connectors.keys())
        
        # Apply filters
        if execution_type is not None:
            connectors = [
                ct for ct in connectors
                if self._metadata[ct].execution_type == execution_type
            ]
        
        if supports_incremental is not None:
            connectors = [
                ct for ct in connectors
                if self._metadata[ct].supports_incremental == supports_incremental
            ]
        
        return sorted(connectors)
    
    def get_connectors_by_auth_type(
        self,
        auth_type: ConnectorAuthType
    ) -> List[str]:
        """
        Get connectors that support specific auth type.
        
        Args:
            auth_type: Authentication type
            
        Returns:
            List of connector types
        """
        return [
            ct for ct, metadata in self._metadata.items()
            if auth_type in metadata.auth_types
        ]
    
    def get_all_metadata(self) -> Dict[str, ConnectorMetadata]:
        """
        Get metadata for all registered connectors.
        
        Returns:
            Dictionary mapping connector type to metadata
        """
        return self._metadata.copy()
    
    # -------------------------
    # VALIDATION
    # -------------------------
    
    def _validate_connector_class(self, connector_class: Type[Connector]) -> bool:
        """
        Validate that connector class implements required methods.
        
        Args:
            connector_class: Connector class to validate
            
        Returns:
            True if valid
        """
        # Must be subclass of Connector
        if not issubclass(connector_class, Connector):
            return False
        
        # Check required abstract methods are implemented
        required_methods = [
            'authenticate',
            'validate_config',
            'extract_batch',
            'extract_permissions',
            'supports_incremental',
            'get_incremental_mode',
            'name',
            'version',
            'description'
        ]
        
        for method in required_methods:
            if not hasattr(connector_class, method):
                logger.warning(f"Connector missing method: {method}")
                return False
        
        return True
    
    def _validate_config(
        self,
        config: ConnectorConfig,
        connector_type: str
    ) -> None:
        """
        Validate connector configuration.
        
        Args:
            config: Configuration to validate
            connector_type: Connector type
            
        Raises:
            ConnectorConfigError: If config invalid
        """
        metadata = self._metadata.get(connector_type)
        if not metadata:
            return
        
        # Validate auth type is supported
        if config.auth_type not in metadata.auth_types:
            raise ConnectorConfigError(
                f"Auth type '{config.auth_type.value}' not supported by {connector_type}. "
                f"Supported: {[at.value for at in metadata.auth_types]}"
            )
        
        # Validate incremental mode if specified
        if config.incremental_mode != IncrementalMode.NOT_SUPPORTED:
            if config.incremental_mode not in metadata.incremental_modes:
                raise ConnectorConfigError(
                    f"Incremental mode '{config.incremental_mode.value}' not supported by {connector_type}"
                )
    
    # -------------------------
    # HELPERS
    # -------------------------
    
    def _infer_connector_type(self, connector_class: Type[Connector]) -> str:
        """
        Infer connector type from class name.
        
        Examples:
            JiraConnector → "jira"
            SlackConnector → "slack"
            GoogleDocsConnector → "google_docs"
        
        Args:
            connector_class: Connector class
            
        Returns:
            Inferred connector type
        """
        class_name = connector_class.__name__
        
        # Remove "Connector" suffix if present
        if class_name.endswith("Connector"):
            class_name = class_name[:-9]  # len("Connector") = 9
        
        # Convert CamelCase to snake_case
        import re
        connector_type = re.sub(r'(?<!^)(?=[A-Z])', '_', class_name).lower()
        
        return connector_type
    
    def _resolve_type(self, connector_type: str) -> str:
        """
        Resolve connector type (handle aliases).
        
        Args:
            connector_type: Connector type or alias
            
        Returns:
            Canonical connector type
        """
        return self._aliases.get(connector_type, connector_type)
    
    def _generate_metadata(
        self,
        connector_class: Type[Connector],
        connector_type: str
    ) -> ConnectorMetadata:
        """
        Generate metadata from connector class.
        
        Args:
            connector_class: Connector class
            connector_type: Connector type
            
        Returns:
            Generated metadata
        """
        # Create temporary instance to query capabilities
        # (Some connectors may require config, so this is best-effort)
        try:
            # Try with minimal config
            temp_config = ConnectorConfig(
                connector_id="temp",
                connector_type=connector_type,
                tenant_id="temp",
                auth_type=ConnectorAuthType.API_KEY,
                credentials={}
            )
            temp_instance = connector_class(temp_config)
            
            supports_incremental = temp_instance.supports_incremental()
            incremental_mode = temp_instance.get_incremental_mode()
            incremental_modes = [incremental_mode] if supports_incremental else []
            supports_webhooks = temp_instance.supports_webhooks()
            auth_types = temp_instance.get_supported_auth_types()
            
            # Determine execution type
            if isinstance(temp_instance, LiveDataConnector):
                execution_type = ConnectorType.LIVE
            elif supports_webhooks:
                execution_type = ConnectorType.HYBRID
            else:
                execution_type = ConnectorType.BATCH
            
            name = temp_instance.name
            version = temp_instance.version
            description = temp_instance.description
        
        except Exception as e:
            # Fallback to defaults if instantiation fails
            logger.debug(f"Could not instantiate {connector_type} for metadata: {e}")
            supports_incremental = False
            incremental_modes = []
            supports_webhooks = False
            auth_types = [ConnectorAuthType.API_KEY]
            execution_type = ConnectorType.BATCH
            name = connector_type.replace("_", " ").title()
            version = "1.0.0"
            description = f"{name} connector"
        
        return ConnectorMetadata(
            connector_type=connector_type,
            name=name,
            version=version,
            description=description,
            supports_incremental=supports_incremental,
            supports_webhooks=supports_webhooks,
            incremental_modes=incremental_modes,
            auth_types=auth_types,
            execution_type=execution_type,
            class_path=f"{connector_class.__module__}.{connector_class.__name__}",
            config_schema={}  # TODO: Generate from connector class
        )
    
    # -------------------------
    # UTILITY METHODS
    # -------------------------
    
    def clear(self) -> None:
        """Clear all registered connectors (useful for testing)"""
        self._connectors.clear()
        self._metadata.clear()
        self._aliases.clear()
    
    def export_metadata(self) -> Dict[str, Any]:
        """
        Export registry metadata as JSON-serializable dict.
        
        Useful for documentation generation or API responses.
        
        Returns:
            Dictionary of all connector metadata
        """
        return {
            connector_type: {
                "name": metadata.name,
                "version": metadata.version,
                "description": metadata.description,
                "execution_type": metadata.execution_type.value,
                "supports_incremental": metadata.supports_incremental,
                "supports_webhooks": metadata.supports_webhooks,
                "incremental_modes": [mode.value for mode in metadata.incremental_modes],
                "auth_types": [auth.value for auth in metadata.auth_types],
                "class_path": metadata.class_path
            }
            for connector_type, metadata in self._metadata.items()
        }
    
    def __repr__(self) -> str:
        """String representation"""
        return f"<ConnectorRegistry: {len(self._connectors)} connectors registered>"


# ============================================================================
# EXCEPTIONS
# ============================================================================

class ConnectorRegistrationError(ConnectorError):
    """Failed to register connector"""
    pass


class ConnectorNotFoundError(ConnectorError):
    """Connector type not found in registry"""
    pass
