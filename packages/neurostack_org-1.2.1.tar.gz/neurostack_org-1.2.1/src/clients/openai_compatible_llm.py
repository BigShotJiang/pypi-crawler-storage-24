"""
OpenAI-compatible LLM client with automatic fallback.

Works with any provider that exposes an OpenAI-compatible chat completions API.
Supports fallback models — if the primary model fails, tries the next one automatically.

Supported providers:
- Groq (Llama, Mistral, Gemma) — free tier: 30 req/min
- NVIDIA NIM (160+ models) — free tier: 1000 req/day
- Google Gemini — free tier: 15 req/min
- Together AI — free trial credits
- OpenRouter — some free models
- Ollama — local, completely free
- Any OpenAI-compatible endpoint
"""

import logging
import os
from typing import List, Optional

from brain.interfaces.llm import LLMClient, LLMMessage, LLMResponse

logger = logging.getLogger("neurostack.clients.openai_compatible")

try:
    from openai import OpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False


class OpenAICompatibleClient:
    """
    Universal LLM client for any OpenAI-compatible API with fallback support.

    Features:
    - Works with any OpenAI-compatible endpoint
    - Automatic fallback to backup models on failure
    - Model override via environment variable
    - Configurable timeout and retries

    Usage:
        # Single model
        client = OpenAICompatibleClient(
            api_key="gsk_...",
            base_url="https://api.groq.com/openai/v1",
            model="llama-3.3-70b-versatile"
        )

        # With fallback models
        client = OpenAICompatibleClient(
            api_key="nvapi-...",
            base_url="https://integrate.api.nvidia.com/v1",
            model="meta/llama-3.1-70b-instruct",
            fallback_models=[
                "meta/llama-3.1-8b-instruct",
                "mistralai/mistral-7b-instruct-v0.3",
            ]
        )
    """

    def __init__(
        self,
        api_key: str,
        base_url: str,
        model: str,
        fallback_models: Optional[List[str]] = None,
        timeout: int = 60,
        model_env_override: Optional[str] = None,
    ):
        """
        Args:
            api_key: API key for the provider
            base_url: Base URL for the API
            model: Primary model to use
            fallback_models: List of fallback models to try if primary fails
            timeout: Request timeout in seconds
            model_env_override: Env var name to override model (e.g. NEUROSTACK_LLM_MODEL)
        """
        if not OPENAI_AVAILABLE:
            raise ImportError("openai package required. Install with: pip install openai")

        self.client = OpenAI(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
        )
        self.base_url = base_url

        # Allow env var to override model choice
        if model_env_override:
            env_model = os.environ.get(model_env_override)
            if env_model:
                model = env_model
                logger.info(f"Model overridden by {model_env_override}: {model}")

        self.model = model
        self.fallback_models = fallback_models or []
        self._all_models = [self.model] + self.fallback_models

        logger.info(
            f"Initialized: {base_url} | primary={model} | "
            f"fallbacks={len(self.fallback_models)}"
        )

    def complete(
        self,
        messages: List[LLMMessage],
        max_tokens: int = 1000,
        temperature: float = 0.0,
    ) -> LLMResponse:
        """
        Generate completion with automatic fallback.

        Tries primary model first. On failure, tries each fallback in order.
        """
        openai_messages = [
            {"role": msg.role, "content": msg.content}
            for msg in messages
        ]

        last_error = None

        for model in self._all_models:
            try:
                response = self.client.chat.completions.create(
                    model=model,
                    messages=openai_messages,
                    max_tokens=max_tokens,
                    temperature=temperature,
                )

                content = response.choices[0].message.content or ""
                tokens_used = 0
                if response.usage:
                    tokens_used = (
                        (response.usage.prompt_tokens or 0)
                        + (response.usage.completion_tokens or 0)
                    )

                if model != self.model:
                    logger.info(f"Used fallback model: {model}")

                return LLMResponse(
                    content=content,
                    tokens_used=tokens_used,
                    model=model,
                )

            except Exception as e:
                last_error = e
                logger.warning(f"Model {model} failed: {e}")
                if model != self._all_models[-1]:
                    logger.info(f"Trying next fallback model...")
                continue

        raise Exception(
            f"All models failed. Last error: {last_error}\n"
            f"Tried: {', '.join(self._all_models)}"
        )


# ============================================================================
# CONVENIENCE FACTORIES
# ============================================================================

def create_groq_client(
    api_key: str,
    model: Optional[str] = None,
) -> OpenAICompatibleClient:
    """
    Groq — free tier: 30 req/min, 14.4K tokens/min.

    Override model: set NEUROSTACK_GROQ_MODEL env var.

    Popular models:
        llama-3.3-70b-versatile (default, best quality)
        llama-3.1-8b-instant (fastest)
        mixtral-8x7b-32768 (good for long context)
        gemma2-9b-it (Google's model)

    Get key: https://console.groq.com/keys
    """
    return OpenAICompatibleClient(
        api_key=api_key,
        base_url="https://api.groq.com/openai/v1",
        model=model or "llama-3.3-70b-versatile",
        fallback_models=[
            "llama-3.1-8b-instant",
            "mixtral-8x7b-32768",
        ],
        model_env_override="NEUROSTACK_GROQ_MODEL",
    )


def create_nvidia_client(
    api_key: str,
    model: Optional[str] = None,
) -> OpenAICompatibleClient:
    """
    NVIDIA NIM — free tier: 1000 req/day. 160+ models available.

    Override model: set NEUROSTACK_NVIDIA_MODEL env var.

    Popular models (all free):
        meta/llama-3.1-70b-instruct (default, best quality)
        meta/llama-3.1-8b-instruct (faster)
        mistralai/mistral-large-2-instruct (Mistral's best)
        mistralai/mistral-7b-instruct-v0.3 (fast Mistral)
        google/gemma-2-27b-it (Google)
        nvidia/nemotron-4-340b-instruct (NVIDIA's own)
        microsoft/phi-3-medium-128k-instruct (Microsoft)
        databricks/dbrx-instruct (Databricks)
        snowflake/arctic-instruct (Snowflake)
        ibm/granite-34b-code-instruct (IBM, good for code)
        writer/palmyra-x-004 (Writer)
        upstage/solar-10.7b-instruct (Korean/English)

    Full catalog: https://build.nvidia.com/explore/discover

    Get key: https://build.nvidia.com
    """
    return OpenAICompatibleClient(
        api_key=api_key,
        base_url="https://integrate.api.nvidia.com/v1",
        model=model or "meta/llama-3.1-70b-instruct",
        fallback_models=[
            "meta/llama-3.1-8b-instruct",
            "mistralai/mistral-7b-instruct-v0.3",
            "microsoft/phi-3-medium-128k-instruct",
        ],
        model_env_override="NEUROSTACK_NVIDIA_MODEL",
    )


def create_gemini_client(
    api_key: str,
    model: Optional[str] = None,
) -> OpenAICompatibleClient:
    """
    Google Gemini — free tier: 15 req/min.

    Override model: set NEUROSTACK_GEMINI_MODEL env var.

    Models:
        gemini-2.0-flash (default, fast)
        gemini-1.5-pro (best quality, slower)
        gemini-1.5-flash (balanced)

    Get key: https://aistudio.google.com/apikey
    """
    return OpenAICompatibleClient(
        api_key=api_key,
        base_url="https://generativelanguage.googleapis.com/v1beta/openai/",
        model=model or "gemini-2.0-flash",
        fallback_models=[
            "gemini-1.5-flash",
        ],
        model_env_override="NEUROSTACK_GEMINI_MODEL",
    )


def create_ollama_client(
    model: Optional[str] = None,
    host: str = "http://localhost:11434",
) -> OpenAICompatibleClient:
    """
    Ollama — local, completely free, unlimited.

    Override model: set NEUROSTACK_OLLAMA_MODEL env var.

    Models (install with `ollama pull <model>`):
        llama3.2 (default, 3B — fast)
        llama3.1 (8B — good quality)
        mistral (7B)
        gemma2 (9B — Google)
        phi3 (3.8B — Microsoft, fast)
        qwen2.5 (7B — Alibaba)
        deepseek-coder-v2 (for code)

    Install: https://ollama.com
    """
    return OpenAICompatibleClient(
        api_key="ollama",
        base_url=f"{host}/v1",
        model=model or "llama3.2",
        fallback_models=["mistral", "phi3"],
        model_env_override="NEUROSTACK_OLLAMA_MODEL",
    )


def create_openrouter_client(
    api_key: str,
    model: Optional[str] = None,
) -> OpenAICompatibleClient:
    """
    OpenRouter — aggregates 200+ models. Some free.

    Override model: set NEUROSTACK_OPENROUTER_MODEL env var.

    Free models:
        meta-llama/llama-3.3-70b-instruct:free (default)
        google/gemma-2-9b-it:free
        mistralai/mistral-7b-instruct:free
        qwen/qwen-2.5-7b-instruct:free

    Get key: https://openrouter.ai/keys
    """
    return OpenAICompatibleClient(
        api_key=api_key,
        base_url="https://openrouter.ai/api/v1",
        model=model or "meta-llama/llama-3.3-70b-instruct:free",
        fallback_models=[
            "google/gemma-2-9b-it:free",
            "mistralai/mistral-7b-instruct:free",
        ],
        model_env_override="NEUROSTACK_OPENROUTER_MODEL",
    )
