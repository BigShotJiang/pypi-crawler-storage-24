"""
Mock embedding client for testing.

This is NOT a production implementation. It generates random embeddings.
Use a real embedding service (OpenAI, Cohere, etc.) in production.
"""

from typing import List
import hashlib
import numpy as np

from brain.interfaces.embedding import EmbeddingClient


class MockEmbeddingClient:
    """
    Mock embedding client that generates deterministic random embeddings.
    
    Useful for testing without real embedding API calls.
    """
    
    def __init__(self, dimension: int = 768):
        """
        Initialize mock embedding client.
        
        Args:
            dimension: Embedding vector dimension
        """
        self.dimension = dimension
    
    def embed(self, text: str) -> List[float]:
        """
        Generate mock embedding for text.
        
        Uses text hash as seed for deterministic output.
        
        Args:
            text: Input text
        
        Returns:
            Mock embedding vector
        """
        # Use hash of text as seed for deterministic randomness
        seed = int(hashlib.md5(text.encode()).hexdigest(), 16) % (2**32)
        rng = np.random.RandomState(seed)
        
        # Generate random normalized vector
        vector = rng.randn(self.dimension)
        vector = vector / np.linalg.norm(vector)  # Normalize
        
        return vector.tolist()
    
    def embed_batch(self, texts: List[str]) -> List[List[float]]:
        """
        Generate mock embeddings for multiple texts.
        
        Args:
            texts: List of input texts
        
        Returns:
            List of mock embedding vectors
        """
        return [self.embed(text) for text in texts]


class SimpleEmbeddingClient:
    """
    Simple embedding client using basic text features.
    
    Better than random for testing, but still not production-ready.
    Uses word presence as features (bag-of-words style).
    """
    
    def __init__(self, dimension: int = 768):
        """
        Initialize simple embedding client.
        
        Args:
            dimension: Embedding vector dimension
        """
        self.dimension = dimension
        self.vocabulary = set()  # Will build vocabulary over time
    
    def embed(self, text: str) -> List[float]:
        """
        Generate simple embedding based on word features.
        
        Args:
            text: Input text
        
        Returns:
            Simple embedding vector
        """
        # Tokenize (very simple)
        words = text.lower().split()
        
        # Update vocabulary
        self.vocabulary.update(words)
        
        # Create feature vector
        # Use hash of each word to map to dimension
        vector = np.zeros(self.dimension)
        for word in words:
            hash_val = int(hashlib.md5(word.encode()).hexdigest(), 16)
            idx = hash_val % self.dimension
            vector[idx] += 1.0
        
        # Normalize
        norm = np.linalg.norm(vector)
        if norm > 0:
            vector = vector / norm
        
        return vector.tolist()
    
    def embed_batch(self, texts: List[str]) -> List[List[float]]:
        """
        Generate embeddings for multiple texts.
        
        Args:
            texts: List of input texts
        
        Returns:
            List of embedding vectors
        """
        return [self.embed(text) for text in texts]