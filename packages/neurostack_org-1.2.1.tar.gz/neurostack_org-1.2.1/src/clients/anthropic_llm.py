"""
Reference implementation: Anthropic Claude LLM client.

This is a minimal working implementation. Production systems may need
additional features like retry logic, rate limiting, etc.
"""

from typing import List, Optional
import anthropic

from brain.interfaces.llm import LLMClient, LLMMessage, LLMResponse


class AnthropicLLMClient:
    """
    Claude LLM client using Anthropic API.
    
    Implements LLMClient protocol.
    """
    
    def __init__(
        self,
        api_key: str,
        model: str = "claude-sonnet-4-20250514",
        timeout: int = 30
    ):
        """
        Initialize Anthropic client.
        
        Args:
            api_key: Anthropic API key
            model: Model identifier
            timeout: Request timeout in seconds
        """
        self.client = anthropic.Anthropic(
            api_key=api_key,
            timeout=timeout
        )
        self.model = model
    
    def complete(
        self,
        messages: List[LLMMessage],
        max_tokens: int = 1000,
        temperature: float = 0.0
    ) -> LLMResponse:
        """
        Generate completion from messages.
        
        Args:
            messages: Conversation messages
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature (0.0 = deterministic)
        
        Returns:
            LLM response
        
        Raises:
            Exception if API call fails
        """
        # Convert messages to Anthropic format
        anthropic_messages = []
        system_message = None
        
        for msg in messages:
            if msg.role == "system":
                # Anthropic uses separate system parameter
                system_message = msg.content
            else:
                anthropic_messages.append({
                    "role": msg.role,
                    "content": msg.content
                })
        
        # Make API call
        try:
            response = self.client.messages.create(
                model=self.model,
                max_tokens=max_tokens,
                temperature=temperature,
                system=system_message if system_message else anthropic.NOT_GIVEN,
                messages=anthropic_messages
            )
            
            # Extract response content
            content = response.content[0].text
            
            return LLMResponse(
                content=content,
                tokens_used=response.usage.input_tokens + response.usage.output_tokens,
                model=self.model
            )
        
        except anthropic.APIError as e:
            raise Exception(f"Anthropic API error: {str(e)}") from e
        except Exception as e:
            raise Exception(f"LLM completion failed: {str(e)}") from e