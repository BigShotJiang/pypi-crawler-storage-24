from openai import AzureOpenAI
from brain.interfaces.llm import LLMClient
from brain.interfaces.llm import LLMMessage


class AzureOpenAIClient(LLMClient):
    def __init__(
        self,
        api_key: str,
        api_base: str,
        api_version: str,
        deployment: str,
    ):
        self.client = AzureOpenAI(
            api_key=api_key,
            azure_endpoint=api_base,
            api_version=api_version,
        )
        self.deployment = deployment

    def complete(self, messages: list[LLMMessage], **kwargs) -> str:
        response = self.client.chat.completions.create(
            model=self.deployment,
            messages=[
                {"role": m.role, "content": m.content}
                for m in messages
            ],
            temperature=kwargs.get("temperature", 0.2),
            max_tokens=kwargs.get("max_tokens", 1024),
        )

        if not response or not response.choices:
            return ""

        return response.choices[0].message.content
