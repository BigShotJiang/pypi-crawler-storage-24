"""
Mock in-memory vector store for testing.

This is NOT a production implementation. Use a real vector database
(Pinecone, Weaviate, Qdrant, etc.) in production.
"""

from typing import List, Optional, Dict, Any
import numpy as np
from dataclasses import dataclass

from brain.interfaces.vector_store import VectorStoreClient, SearchResult


@dataclass
class StoredVector:
    """Internal storage for vector + metadata"""
    id: str
    vector: np.ndarray
    metadata: Dict[str, Any]
    content: str


class MockVectorStore:
    """
    In-memory vector store for testing.
    
    Implements VectorStoreClient protocol.
    Uses simple cosine similarity for search.
    """
    
    def __init__(self):
        """Initialize empty vector store"""
        self.vectors: Dict[str, StoredVector] = {}
    
    def add(
        self,
        id: str,
        vector: List[float],
        metadata: Dict[str, Any],
        content: str
    ) -> None:
        """
        Add vector to store.
        
        Args:
            id: Unique identifier
            vector: Embedding vector
            metadata: Metadata dictionary
            content: Original content
        """
        self.vectors[id] = StoredVector(
            id=id,
            vector=np.array(vector),
            metadata=metadata,
            content=content
        )
    
    def search(
        self,
        query_embedding: List[float],
        top_k: int,
        filters: Optional[Dict[str, Any]] = None
    ) -> List[SearchResult]:
        """
        Search for similar vectors.
        
        Args:
            query_embedding: Query vector
            top_k: Number of results to return
            filters: Optional metadata filters
        
        Returns:
            Top-K results sorted by similarity
        """
        if len(self.vectors) == 0:
            return []
        
        query_vec = np.array(query_embedding)
        
        # Calculate cosine similarity for all vectors
        results = []
        for stored in self.vectors.values():
            # Apply filters if provided
            if filters and not self._matches_filters(stored.metadata, filters):
                continue
            
            # Cosine similarity
            similarity = self._cosine_similarity(query_vec, stored.vector)
            
            results.append(SearchResult(
                id=stored.id,
                score=float(similarity),
                metadata=stored.metadata,
                content=stored.content
            ))
        
        # Sort by score (descending)
        results.sort(key=lambda x: x.score, reverse=True)
        
        # Return top-K
        return results[:top_k]
    
    def _cosine_similarity(self, a: np.ndarray, b: np.ndarray) -> float:
        """Calculate cosine similarity between two vectors"""
        dot_product = np.dot(a, b)
        norm_a = np.linalg.norm(a)
        norm_b = np.linalg.norm(b)
        
        if norm_a == 0 or norm_b == 0:
            return 0.0
        
        return dot_product / (norm_a * norm_b)
    
    def _matches_filters(
        self,
        metadata: Dict[str, Any],
        filters: Dict[str, Any]
    ) -> bool:
        """
        Check if metadata matches filters.

        Handles permission-aware filtering:
        - user_id: checks if user is in metadata's user_ids list
        - team_ids: checks if any team overlaps with metadata's team_ids
        - Skips permission filters for public-scoped content
        - Other keys: exact match
        """
        for key, value in filters.items():
            # Permission filter: user_id checks against user_ids list
            if key == "user_id":
                scope = metadata.get("scope", metadata.get("visibility", "public"))
                if scope == "public":
                    continue  # Public content visible to all
                user_ids = metadata.get("user_ids", [])
                if isinstance(user_ids, list) and value in user_ids:
                    continue  # User explicitly listed
                # Fall through to team check (handled by team_ids filter)
                continue

            # Permission filter: team_ids checks overlap
            if key == "team_ids":
                if not value:  # Empty team list, skip
                    continue
                scope = metadata.get("scope", metadata.get("visibility", "public"))
                if scope == "public":
                    continue
                meta_teams = metadata.get("team_ids", [])
                meta_team = metadata.get("team_id")
                if meta_team:
                    meta_teams = list(meta_teams) + [meta_team]
                if isinstance(value, list) and any(t in meta_teams for t in value):
                    continue
                # Not in any team and not public - check if scope is team-restricted
                if scope in ("team", "private", "restricted"):
                    return False
                continue

            # Standard exact match for other keys
            if key not in metadata:
                return False
            if metadata[key] != value:
                return False
        return True
    
    def delete(self, id: str) -> bool:
        """
        Delete vector by ID.
        
        Args:
            id: Vector ID
        
        Returns:
            True if deleted, False if not found
        """
        if id in self.vectors:
            del self.vectors[id]
            return True
        return False
    
    def clear(self) -> None:
        """Clear all vectors from store"""
        self.vectors.clear()
    
    def count(self) -> int:
        """Get number of vectors in store"""
        return len(self.vectors)