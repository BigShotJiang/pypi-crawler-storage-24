from __future__ import annotations

import json
from pathlib import Path
import sys
import tarfile
import tempfile
import unittest
import gzip

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from phyloprobe.catalog import default_catalog_release, load_catalog, select_catalog_datasets
from phyloprobe.gtdb import summarize_taxonomy_file
from phyloprobe.paths import APP_HOME_ENV
from phyloprobe.registry import install_catalog_selection, load_registry, resolve_dataset_record


def _write_taxonomy_file(path: Path, prefix: str = "Archaea") -> None:
    path.write_text(
        "\n".join(
            [
                f"RS_GCF_000001\td__{prefix};p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                f"RS_GCF_000002\td__{prefix};p__P1;c__C1;o__O1;f__F1;g__G1;s__S2",
                f"RS_GCF_000003\td__{prefix};p__P2;c__C2;o__O2;f__F2;g__G2;s__S3",
            ]
        )
        + "\n",
        encoding="utf-8",
    )


def _write_gzip_metadata_file(path: Path, prefix: str = "Archaea") -> None:
    contents = "\n".join(
        [
            "accession\tother\tgtdb_taxonomy",
            f"RS_GCF_000001\tx\td__{prefix};p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
            f"RS_GCF_000002\tx\td__{prefix};p__P1;c__C1;o__O1;f__F1;g__G1;s__S2",
            f"RS_GCF_000003\tx\td__{prefix};p__P2;c__C2;o__O2;f__F2;g__G2;s__S3",
        ]
    ) + "\n"
    with gzip.open(path, "wt", encoding="utf-8") as handle:
        handle.write(contents)


def _write_tar_archive(path: Path, members: dict[str, str]) -> None:
    with tarfile.open(path, "w:gz") as archive:
        for member_name, contents in members.items():
            payload = contents.encode("utf-8")
            temp_file = path.parent / member_name.replace("/", "_")
            temp_file.write_bytes(payload)
            archive.add(temp_file, arcname=member_name)
            temp_file.unlink()


def _write_catalog(
    path: Path,
    archaea_taxonomy: Path,
    archaea_msa: Path,
    archaea_markers: Path,
    bacteria_taxonomy: Path,
    bacteria_msa: Path,
    bacteria_markers: Path,
) -> None:
    payload = {
        "release": "r226",
        "datasets": {
            "archaea": {
                "name": "ar53_test",
                "taxon": "archaea",
                "files": {
                    "taxonomy": {
                        "filename": "ar53_taxonomy.tsv",
                        "url": archaea_taxonomy.resolve().as_uri(),
                    },
                    "msa": {
                        "filename": "ar53_msa.tar.gz",
                        "url": archaea_msa.resolve().as_uri(),
                    },
                    "markers": {
                        "filename": "ar53_markers.tar.gz",
                        "url": archaea_markers.resolve().as_uri(),
                    },
                },
            },
            "bacteria": {
                "name": "bac120_test",
                "taxon": "bacteria",
                "files": {
                    "taxonomy": {
                        "filename": "bac120_taxonomy.tsv",
                        "url": bacteria_taxonomy.resolve().as_uri(),
                    },
                    "msa": {
                        "filename": "bac120_msa.tar.gz",
                        "url": bacteria_msa.resolve().as_uri(),
                    },
                    "markers": {
                        "filename": "bac120_markers.tar.gz",
                        "url": bacteria_markers.resolve().as_uri(),
                    },
                },
            },
        },
    }
    path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


def _write_multi_release_catalog(
    path: Path,
    archaea_taxonomy: Path,
    archaea_msa: Path,
    archaea_markers: Path,
    bacteria_taxonomy: Path,
    bacteria_msa: Path,
    bacteria_markers: Path,
) -> None:
    def _release_payload(release: str) -> dict[str, object]:
        return {
            "datasets": {
                "archaea": {
                    "name": f"ar53_test_{release}",
                    "taxon": "archaea",
                    "files": {
                        "taxonomy": {
                            "filename": f"ar53_taxonomy_{release}.tsv",
                            "url": archaea_taxonomy.resolve().as_uri(),
                        },
                        "msa": {
                            "filename": f"ar53_msa_{release}.tar.gz",
                            "url": archaea_msa.resolve().as_uri(),
                        },
                        "markers": {
                            "filename": f"ar53_markers_{release}.tar.gz",
                            "url": archaea_markers.resolve().as_uri(),
                        },
                    },
                },
                "bacteria": {
                    "name": f"bac120_test_{release}",
                    "taxon": "bacteria",
                    "files": {
                        "taxonomy": {
                            "filename": f"bac120_taxonomy_{release}.tsv",
                            "url": bacteria_taxonomy.resolve().as_uri(),
                        },
                        "msa": {
                            "filename": f"bac120_msa_{release}.tar.gz",
                            "url": bacteria_msa.resolve().as_uri(),
                        },
                        "markers": {
                            "filename": f"bac120_markers_{release}.tar.gz",
                            "url": bacteria_markers.resolve().as_uri(),
                        },
                    },
                },
            }
        }

    payload = {
        "default_release": "r226",
        "releases": {
            "r226": _release_payload("r226"),
            "r220": _release_payload("r220"),
        },
    }
    path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


def _write_index_summary_file(path: Path) -> None:
    payload = {
        "dataset_type": "fulgor_index",
        "index_file": "/placeholder/archaea_reps.fur",
        "reference_map_file": "/placeholder/archaea_reps_reference_map.csv",
        "kmer_length": 21,
        "minimizer_length": 15,
        "indexed_references": 2,
    }
    path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


class RegistryTests(unittest.TestCase):
    def test_summarize_taxonomy_file_counts_ranks(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            _write_taxonomy_file(taxonomy_path)

            summary = summarize_taxonomy_file(taxonomy_path)

            self.assertEqual(summary.genomes, 3)
            self.assertEqual(summary.unique_lineages, 3)
            self.assertEqual(summary.rank_counts["phylum"], 2)
            self.assertEqual(summary.rank_counts["genus"], 2)
            self.assertEqual(summary.missing_rank_counts["species"], 0)

    def test_summarize_gzip_metadata_file_counts_ranks(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            metadata_path = Path(temp_dir) / "metadata.tsv.gz"
            _write_gzip_metadata_file(metadata_path)

            summary = summarize_taxonomy_file(metadata_path)

            self.assertEqual(summary.genomes, 3)
            self.assertEqual(summary.unique_lineages, 3)
            self.assertEqual(summary.rank_counts["phylum"], 2)
            self.assertEqual(summary.rank_counts["species"], 3)

    def test_load_catalog_and_filter_by_taxon(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_root = Path(temp_dir)
            paths = [temp_root / name for name in ("a.tsv", "a1.tar.gz", "a2.tar.gz", "b.tsv", "b1.tar.gz", "b2.tar.gz")]
            _write_taxonomy_file(paths[0], prefix="Archaea")
            _write_tar_archive(paths[1], {"individual/a.faa": ">a\nAAAA\n"})
            _write_tar_archive(paths[2], {"individual/a.fna": ">a\nATGC\n"})
            _write_taxonomy_file(paths[3], prefix="Bacteria")
            _write_tar_archive(paths[4], {"individual/b.faa": ">b\nBBBB\n"})
            _write_tar_archive(paths[5], {"individual/b.fna": ">b\nATGC\n"})
            catalog_path = temp_root / "catalog.json"
            _write_catalog(catalog_path, *paths)

            catalog = load_catalog(catalog_path)
            selected = select_catalog_datasets(catalog, taxon="archaea")

            self.assertEqual(set(catalog), {"archaea", "bacteria"})
            self.assertEqual(set(selected), {"archaea"})
            self.assertEqual(catalog["archaea"].release, "r226")

    def test_load_catalog_can_select_requested_release_from_multi_release_catalog(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_root = Path(temp_dir)
            paths = [temp_root / name for name in ("a.tsv", "a1.tar.gz", "a2.tar.gz", "b.tsv", "b1.tar.gz", "b2.tar.gz")]
            _write_taxonomy_file(paths[0], prefix="Archaea")
            _write_tar_archive(paths[1], {"individual/a.faa": ">a\nAAAA\n"})
            _write_tar_archive(paths[2], {"individual/a.fna": ">a\nATGC\n"})
            _write_taxonomy_file(paths[3], prefix="Bacteria")
            _write_tar_archive(paths[4], {"individual/b.faa": ">b\nBBBB\n"})
            _write_tar_archive(paths[5], {"individual/b.fna": ">b\nATGC\n"})
            catalog_path = temp_root / "catalog.json"
            _write_multi_release_catalog(catalog_path, *paths)

            default_catalog = load_catalog(catalog_path)
            r220_catalog = load_catalog(catalog_path, gtdb_release="r220")

            self.assertEqual(default_catalog_release(catalog_path), "r226")
            self.assertEqual(set(default_catalog), {"archaea_r226", "bacteria_r226"})
            self.assertEqual(set(r220_catalog), {"archaea_r220", "bacteria_r220"})
            self.assertEqual(default_catalog["archaea_r226"].logical_key, "archaea")
            self.assertEqual(r220_catalog["archaea_r220"].release, "r220")

    def test_install_catalog_selection_writes_registry_and_manifest(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            home = Path(temp_dir) / "home"
            datasets_dir = Path(temp_dir) / "datasets-store"
            temp_root = Path(temp_dir)
            paths = [temp_root / name for name in ("a.tsv", "a1.tar.gz", "a2.tar.gz", "b.tsv", "b1.tar.gz", "b2.tar.gz")]
            _write_taxonomy_file(paths[0], prefix="Archaea")
            _write_tar_archive(paths[1], {"individual/a.faa": ">a\nAAAA\n"})
            _write_tar_archive(paths[2], {"individual/a.fna": ">a\nATGC\n"})
            _write_taxonomy_file(paths[3], prefix="Bacteria")
            _write_tar_archive(paths[4], {"individual/b.faa": ">b\nBBBB\n"})
            _write_tar_archive(paths[5], {"individual/b.fna": ">b\nATGC\n"})
            catalog_path = temp_root / "catalog.json"
            _write_catalog(catalog_path, *paths)

            results = install_catalog_selection(
                taxon="all",
                catalog_file=catalog_path,
                home=home,
                datasets_dir=datasets_dir,
            )

            self.assertEqual(set(results), {"archaea", "bacteria"})
            self.assertEqual(results["archaea"].status, "installed")
            self.assertEqual(results["bacteria"].record.taxonomy_summary["genomes"], 3)

            registry = load_registry(home)
            self.assertIn("archaea", registry)
            self.assertIn("bacteria", registry)
            self.assertEqual(registry["archaea"].archive_summaries["msa"]["suffix_counts"][".faa"], 1)
            self.assertEqual(registry["bacteria"].archive_summaries["markers"]["suffix_counts"][".fna"], 1)

            manifest_path = datasets_dir / "archaea" / "manifest.json"
            self.assertTrue(manifest_path.exists())
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            self.assertEqual(manifest["taxon"], "archaea")
            self.assertEqual(manifest["release"], "r226")
            self.assertEqual(set(manifest["files"]), {"taxonomy", "msa", "markers"})
            self.assertFalse((home / "datasets" / "archaea").exists())

    def test_install_catalog_selection_can_install_non_default_release(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            home = Path(temp_dir) / "home"
            datasets_dir = Path(temp_dir) / "datasets-store"
            temp_root = Path(temp_dir)
            paths = [temp_root / name for name in ("a.tsv", "a1.tar.gz", "a2.tar.gz", "b.tsv", "b1.tar.gz", "b2.tar.gz")]
            _write_taxonomy_file(paths[0], prefix="Archaea")
            _write_tar_archive(paths[1], {"individual/a.faa": ">a\nAAAA\n"})
            _write_tar_archive(paths[2], {"individual/a.fna": ">a\nATGC\n"})
            _write_taxonomy_file(paths[3], prefix="Bacteria")
            _write_tar_archive(paths[4], {"individual/b.faa": ">b\nBBBB\n"})
            _write_tar_archive(paths[5], {"individual/b.fna": ">b\nATGC\n"})
            catalog_path = temp_root / "catalog.json"
            _write_multi_release_catalog(catalog_path, *paths)

            results = install_catalog_selection(
                taxon="archaea",
                catalog_file=catalog_path,
                gtdb_release="r220",
                home=home,
                datasets_dir=datasets_dir,
            )

            self.assertEqual(set(results), {"archaea_r220"})
            registry = load_registry(home)
            self.assertIn("archaea_r220", registry)
            self.assertEqual(registry["archaea_r220"].logical_key, "archaea")
            self.assertEqual(registry["archaea_r220"].release, "r220")
            self.assertTrue((datasets_dir / "archaea_r220").exists())

    def test_resolve_dataset_record_can_select_installed_release_by_logical_name(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            home = Path(temp_dir) / "home"
            datasets_dir = Path(temp_dir) / "datasets-store"
            temp_root = Path(temp_dir)
            paths = [temp_root / name for name in ("a.tsv", "a1.tar.gz", "a2.tar.gz", "b.tsv", "b1.tar.gz", "b2.tar.gz")]
            _write_taxonomy_file(paths[0], prefix="Archaea")
            _write_tar_archive(paths[1], {"individual/a.faa": ">a\nAAAA\n"})
            _write_tar_archive(paths[2], {"individual/a.fna": ">a\nATGC\n"})
            _write_taxonomy_file(paths[3], prefix="Bacteria")
            _write_tar_archive(paths[4], {"individual/b.faa": ">b\nBBBB\n"})
            _write_tar_archive(paths[5], {"individual/b.fna": ">b\nATGC\n"})
            catalog_path = temp_root / "catalog.json"
            _write_multi_release_catalog(catalog_path, *paths)

            install_catalog_selection(
                taxon="archaea",
                catalog_file=catalog_path,
                gtdb_release="r220",
                home=home,
                datasets_dir=datasets_dir,
            )

            record = resolve_dataset_record("archaea", gtdb_release="r220", dataset_type="gtdb", home=home)
            self.assertEqual(record.key, "archaea_r220")
            self.assertEqual(record.logical_key, "archaea")

    def test_install_rejects_preexisting_destination_files_without_force(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            home = Path(temp_dir) / "home"
            datasets_dir = Path(temp_dir) / "datasets-store"
            temp_root = Path(temp_dir)
            paths = [temp_root / name for name in ("a.tsv", "a1.tar.gz", "a2.tar.gz", "b.tsv", "b1.tar.gz", "b2.tar.gz")]
            _write_taxonomy_file(paths[0], prefix="Archaea")
            _write_tar_archive(paths[1], {"individual/a.faa": ">a\nAAAA\n"})
            _write_tar_archive(paths[2], {"individual/a.fna": ">a\nATGC\n"})
            _write_taxonomy_file(paths[3], prefix="Bacteria")
            _write_tar_archive(paths[4], {"individual/b.faa": ">b\nBBBB\n"})
            _write_tar_archive(paths[5], {"individual/b.fna": ">b\nATGC\n"})
            catalog_path = temp_root / "catalog.json"
            _write_catalog(catalog_path, *paths)

            conflict_dir = datasets_dir / "archaea"
            conflict_dir.mkdir(parents=True, exist_ok=True)
            (conflict_dir / "ar53_taxonomy.tsv").write_text("stale\n", encoding="utf-8")

            with self.assertRaisesRegex(ValueError, "Destination already contains file"):
                install_catalog_selection(
                    taxon="archaea",
                    catalog_file=catalog_path,
                    home=home,
                    datasets_dir=datasets_dir,
                )

    def test_install_fulgor_index_dataset_writes_index_summary(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            home = Path(temp_dir) / "home"
            datasets_dir = Path(temp_dir) / "datasets-store"
            temp_root = Path(temp_dir)
            index_file = temp_root / "archaea_reps.fur"
            reference_map_file = temp_root / "archaea_reps_reference_map.csv"
            summary_file = temp_root / "archaea_reps_summary.json"
            index_file.write_text("/tmp/genome1.fa\n/tmp/genome2.fa\n", encoding="utf-8")
            reference_map_file.write_text(
                "\n".join(
                    [
                        "reference_id,reference_name,source_member,extracted_path,raw_accession,normalized_accession",
                        "0,/tmp/genome1.fa,genome1.fa,/tmp/genome1.fa,GCF_000001.1,RS_GCF_000001.1",
                        "1,/tmp/genome2.fa,genome2.fa,/tmp/genome2.fa,GCF_000002.1,RS_GCF_000002.1",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )
            _write_index_summary_file(summary_file)
            catalog_path = temp_root / "catalog_index.json"
            payload = {
                "release": "r226",
                "datasets": {
                    "archaea_index": {
                        "name": "ar53_reps_index_r226",
                        "dataset_type": "fulgor_index",
                        "taxon": "archaea",
                        "files": {
                            "index": {
                                "filename": "archaea_reps.fur",
                                "url": index_file.resolve().as_uri(),
                            },
                            "reference_map": {
                                "filename": "archaea_reps_reference_map.csv",
                                "url": reference_map_file.resolve().as_uri(),
                            },
                            "summary": {
                                "filename": "archaea_reps_summary.json",
                                "url": summary_file.resolve().as_uri(),
                            },
                        },
                    },
                },
            }
            catalog_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")

            results = install_catalog_selection(
                taxon="archaea",
                catalog_file=catalog_path,
                home=home,
                datasets_dir=datasets_dir,
            )

            self.assertEqual(set(results), {"archaea_index"})
            registry = load_registry(home)
            self.assertIn("archaea_index", registry)
            record = registry["archaea_index"]
            self.assertEqual(record.dataset_type, "fulgor_index")
            self.assertEqual(record.index_summary["indexed_references"], 2)
            self.assertEqual(record.index_summary["index_file"], str((datasets_dir / "archaea_index" / "archaea_reps.fur").resolve()))

    def test_registry_respects_environment_home(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            home = Path(temp_dir) / "custom-home"
            temp_root = Path(temp_dir)
            paths = [temp_root / name for name in ("a.tsv", "a1.tar.gz", "a2.tar.gz", "b.tsv", "b1.tar.gz", "b2.tar.gz")]
            _write_taxonomy_file(paths[0], prefix="Archaea")
            _write_tar_archive(paths[1], {"individual/a.faa": ">a\nAAAA\n"})
            _write_tar_archive(paths[2], {"individual/a.fna": ">a\nATGC\n"})
            _write_taxonomy_file(paths[3], prefix="Bacteria")
            _write_tar_archive(paths[4], {"individual/b.faa": ">b\nBBBB\n"})
            _write_tar_archive(paths[5], {"individual/b.fna": ">b\nATGC\n"})
            catalog_path = temp_root / "catalog.json"
            _write_catalog(catalog_path, *paths)
            previous = None
            if APP_HOME_ENV in __import__("os").environ:
                previous = __import__("os").environ[APP_HOME_ENV]
            __import__("os").environ[APP_HOME_ENV] = str(home)
            try:
                install_catalog_selection(
                    taxon="archaea",
                    catalog_file=catalog_path,
                )
                registry = load_registry()
                self.assertIn("archaea", registry)
                self.assertNotIn("bacteria", registry)
            finally:
                if previous is None:
                    __import__("os").environ.pop(APP_HOME_ENV, None)
                else:
                    __import__("os").environ[APP_HOME_ENV] = previous


if __name__ == "__main__":
    unittest.main()
