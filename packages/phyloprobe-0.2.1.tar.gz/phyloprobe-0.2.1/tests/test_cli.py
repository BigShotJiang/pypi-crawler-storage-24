from __future__ import annotations

import csv
from contextlib import redirect_stderr, redirect_stdout
import io
import json
import os
from pathlib import Path
import sys
import tarfile
import tempfile
from types import SimpleNamespace
import unittest
from typing import Sequence

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from phyloprobe.cli import (
    OutputFormat,
    ROOT_DESCRIPTION,
    _is_json_output,
    _regions_discover_text,
    _render_root_header_text,
    main as cli_main,
)
from phyloprobe.paths import APP_HOME_ENV


def _stage_manifest_path(output_dir: Path, session_name: str, stage: str) -> Path:
    return output_dir / session_name / stage / f"{stage}.json"


def _session_stage_prefix(output_dir: Path, session_name: str, stage: str, attempt: str = "01") -> Path:
    return output_dir / session_name / stage / attempt / stage


def _write_stage_manifest(prefix: Path, stage: str, summary_payload: dict[str, object] | None = None) -> None:
    prefix = _normalize_stage_prefix(prefix, stage)
    manifest_path = prefix.parents[1] / f"{stage}.json"
    summary_path = prefix.parent / f"{stage}_summary.json"
    payload = {
        "stage": stage,
        "active_attempt": prefix.parent.name,
        "attempts": {
            prefix.parent.name: {
                "attempt": prefix.parent.name,
                "prefix": str(prefix),
                "directory": str(prefix.parent),
                "summary_file": str(summary_path),
                "parameters": {} if summary_payload is None else summary_payload,
            }
        },
    }
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


def _normalize_stage_prefix(prefix: Path, stage: str) -> Path:
    if prefix.parent.parent.name == stage and prefix.parent.name.isdigit() and prefix.name == stage:
        return prefix
    if prefix.parent.name == stage and prefix.name.endswith(f"_{stage}"):
        session_root = prefix.parent.parent
        return _session_stage_prefix(session_root.parent, session_root.name, stage)
    return _session_stage_prefix(prefix.parent, prefix.name, stage)


def _stage_artifact(prefix: Path, stage: str, suffix: str) -> Path:
    resolved_prefix = _normalize_stage_prefix(prefix, stage)
    return resolved_prefix.parent / f"{resolved_prefix.name}_{suffix}"


def _rewrite_legacy_session_args(argv: list[str]) -> list[str]:
    if not argv:
        return argv
    command = argv[0]
    if command not in {"tags", "targets", "regions", "probes", "panels"}:
        return argv

    rewritten: list[str] = [command]
    input_session_name: str | None = None
    index = 1
    while index < len(argv):
        argument = argv[index]
        if argument == "--output-prefix":
            prefix = Path(argv[index + 1])
            rewritten.extend(["--output", str(prefix.parent), "--session", prefix.name])
            index += 2
            continue
        if argument in {
            "--tag-design-prefix",
            "--target-discovery-prefix",
            "--region-discovery-prefix",
            "--probe-design-prefix",
        }:
            prefix = Path(argv[index + 1])
            input_session_name = prefix.name
            index += 2
            continue
        rewritten.append(argument)
        index += 1

    if input_session_name is not None and "--input-session" not in rewritten:
        rewritten[1:1] = ["--input-session", input_session_name]
    return rewritten


def main(argv: list[str]) -> int:
    return cli_main(_rewrite_legacy_session_args(list(argv)))


def _write_taxonomy_file(path: Path, prefix: str) -> None:
    path.write_text(
        f"RS_GCF_000001\td__{prefix};p__P1;c__C1;o__O1;f__F1;g__G1;s__S1\n",
        encoding="utf-8",
    )


def _write_tar_archive(path: Path, members: dict[str, str]) -> None:
    with tarfile.open(path, "w:gz") as archive:
        for member_name, contents in members.items():
            payload = contents.encode("utf-8")
            temp_file = path.parent / member_name.replace("/", "_")
            temp_file.write_bytes(payload)
            archive.add(temp_file, arcname=member_name)
            temp_file.unlink()


def _write_fake_fulgor(path: Path) -> None:
    path.write_text(
        """#!/usr/bin/env python3
import sys
from pathlib import Path


def _arg(flag):
    return sys.argv[sys.argv.index(flag) + 1]


def _read_fasta(path):
    sequences = {}
    current = None
    chunks = []
    with Path(path).open("r", encoding="utf-8") as handle:
        for raw_line in handle:
            line = raw_line.strip()
            if not line:
                continue
            if line.startswith(">"):
                if current is not None:
                    sequences[current] = "".join(chunks).upper()
                current = line[1:].split()[0]
                chunks = []
            else:
                chunks.append(line)
    if current is not None:
        sequences[current] = "".join(chunks).upper()
    return sequences


tool = sys.argv[1]
if tool == "build":
    list_path = Path(_arg("-l"))
    output_prefix = Path(_arg("-o"))
    index_path = output_prefix if output_prefix.suffix == ".fur" else output_prefix.with_name(output_prefix.name + ".fur")
    references = [line.strip() for line in list_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    index_path.parent.mkdir(parents=True, exist_ok=True)
    with index_path.open("w", encoding="utf-8") as handle:
        for reference in references:
            fasta = _read_fasta(reference)
            handle.write(reference + "\\t" + "".join(fasta.values()) + "\\n")
    sys.exit(0)
if tool == "print-filenames":
    index_path = Path(_arg("-i"))
    with index_path.open("r", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            sys.stdout.write(line.split("\\t", 1)[0] + "\\n")
    sys.exit(0)
if tool == "pseudoalign":
    index_path = Path(_arg("-i"))
    query_path = Path(_arg("-q"))
    output_path = Path(_arg("-o"))
    queries = _read_fasta(query_path)
    reference_sequences = []
    with index_path.open("r", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            reference_name, sequence = line.split("\\t", 1)
            reference_sequences.append((reference_name, sequence))
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8") as handle:
        for query_id, sequence in queries.items():
            hits = [str(index) for index, (_reference_name, reference_sequence) in enumerate(reference_sequences) if sequence in reference_sequence]
            if hits:
                handle.write(query_id + "\\t" + str(len(hits)) + "\\t" + "\\t".join(hits) + "\\n")
    sys.exit(0)

raise SystemExit(f"Unsupported fake fulgor tool: {tool}")
""",
        encoding="utf-8",
    )
    path.chmod(path.stat().st_mode | 0o111)


def _write_probe_design_fixture(
    tag_prefix: Path,
    target_prefix: Path,
    region_prefix: Path,
    probe_prefix: Path,
    *,
    barcode: str,
    resolved_level: str,
    resolved_taxon: str,
    marker_id: str,
    target_subsequence: str,
    probe_sequence: str,
    lineage: dict[str, str],
    probe_rows: Sequence[dict[str, object]] | None = None,
) -> None:
    tag_prefix = _normalize_stage_prefix(tag_prefix, "tags")
    target_prefix = _normalize_stage_prefix(target_prefix, "targets")
    region_prefix = _normalize_stage_prefix(region_prefix, "regions")
    probe_prefix = _normalize_stage_prefix(probe_prefix, "probes")
    levels = ["domain", "phylum", "class", "order", "family", "genus", "species"]
    tag_summary = {
        "levels": levels,
    }
    target_summary = {
        "tag_design_prefix": str(tag_prefix),
    }
    region_summary = {
        "target_discovery_prefix": str(target_prefix),
    }
    probe_summary = {
        "region_discovery_prefix": str(region_prefix),
    }
    tag_prefix.parent.mkdir(parents=True, exist_ok=True)
    target_prefix.parent.mkdir(parents=True, exist_ok=True)
    region_prefix.parent.mkdir(parents=True, exist_ok=True)
    probe_prefix.parent.mkdir(parents=True, exist_ok=True)
    _stage_artifact(tag_prefix, "tags", "summary.json").write_text(json.dumps(tag_summary, indent=2) + "\n", encoding="utf-8")
    _stage_artifact(target_prefix, "targets", "summary.json").write_text(json.dumps(target_summary, indent=2) + "\n", encoding="utf-8")
    _stage_artifact(region_prefix, "regions", "summary.json").write_text(json.dumps(region_summary, indent=2) + "\n", encoding="utf-8")
    _stage_artifact(probe_prefix, "probes", "summary.json").write_text(json.dumps(probe_summary, indent=2) + "\n", encoding="utf-8")
    _write_stage_manifest(tag_prefix, "tags", tag_summary)
    _write_stage_manifest(target_prefix, "targets", target_summary)
    _write_stage_manifest(region_prefix, "regions", region_summary)
    _write_stage_manifest(probe_prefix, "probes", probe_summary)

    fieldnames = [
        "barcode",
        "resolved_level",
        "resolved_taxon",
        "marker_id",
        "aligned_start",
        "aligned_end",
        "region_rank_within_target_marker",
        "rank_within_region",
        "probe_sequence",
        "target_subsequence",
        "score",
        "gc_fraction",
        "tm_basic",
        "source_accession",
        "source_nt_start",
        "source_nt_end",
        *levels,
    ]
    default_row = {
        "barcode": barcode,
        "resolved_level": resolved_level,
        "resolved_taxon": resolved_taxon,
        "marker_id": marker_id,
        "aligned_start": 1,
        "aligned_end": len(target_subsequence),
        "region_rank_within_target_marker": 1,
        "rank_within_region": 1,
        "probe_sequence": probe_sequence,
        "target_subsequence": target_subsequence,
        "score": 1.0,
        "gc_fraction": 0.5,
        "tm_basic": 60.0,
        "source_accession": "RS_GCF_000001.1",
        "source_nt_start": 1,
        "source_nt_end": len(target_subsequence),
    }
    default_row.update(lineage)
    rows = [default_row]
    if probe_rows is not None:
        rows = []
        for probe_row in probe_rows:
            row = dict(default_row)
            row.update(probe_row)
            rows.append(row)
    manifest_path = _stage_artifact(probe_prefix, "probes", "top_probe_manifest.csv")
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    import csv

    with manifest_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def _write_region_design_fixture(
    tag_prefix: Path,
    target_prefix: Path,
    region_prefix: Path,
    *,
    barcode: str,
    resolved_level: str,
    resolved_taxon: str,
    marker_id: str,
    lineage: dict[str, str | None],
    parent_level: str,
    parent_taxon: str,
    region_nt_window: str = "AAAAAA",
    accession: str = "RS_GCF_000001",
    remap_rows: Sequence[tuple[str, str]] | None = None,
) -> None:
    tag_prefix = _normalize_stage_prefix(tag_prefix, "tags")
    target_prefix = _normalize_stage_prefix(target_prefix, "targets")
    region_prefix = _normalize_stage_prefix(region_prefix, "regions")
    levels = ["domain", "phylum", "class", "order", "family", "genus", "species"]
    tag_summary = {"levels": levels}
    target_summary = {"tag_design_prefix": str(tag_prefix)}
    region_summary = {"target_discovery_prefix": str(target_prefix)}
    tag_prefix.parent.mkdir(parents=True, exist_ok=True)
    target_prefix.parent.mkdir(parents=True, exist_ok=True)
    region_prefix.parent.mkdir(parents=True, exist_ok=True)
    _stage_artifact(tag_prefix, "tags", "summary.json").write_text(json.dumps(tag_summary, indent=2) + "\n", encoding="utf-8")
    _stage_artifact(target_prefix, "targets", "summary.json").write_text(json.dumps(target_summary, indent=2) + "\n", encoding="utf-8")
    _stage_artifact(region_prefix, "regions", "summary.json").write_text(json.dumps(region_summary, indent=2) + "\n", encoding="utf-8")
    _write_stage_manifest(tag_prefix, "tags", tag_summary)
    _write_stage_manifest(target_prefix, "targets", target_summary)
    _write_stage_manifest(region_prefix, "regions", region_summary)

    fieldnames = [
        "barcode",
        "resolved_level",
        "resolved_taxon",
        "marker_id",
        "aligned_start",
        "aligned_end",
        "window_aa_length",
        "consensus_aa",
        "anchor_accession",
        "anchor_aa_start",
        "anchor_aa_end",
        "parent_level",
        "parent_taxon",
        "score",
        "rank_within_target_marker",
        *levels,
    ]
    row = {
        "barcode": barcode,
        "resolved_level": resolved_level,
        "resolved_taxon": resolved_taxon,
        "marker_id": marker_id,
        "aligned_start": 1,
        "aligned_end": 2,
        "window_aa_length": 2,
        "consensus_aa": "AA",
        "anchor_accession": "RS_GCF_000001",
        "anchor_aa_start": 1,
        "anchor_aa_end": 2,
        "parent_level": parent_level,
        "parent_taxon": parent_taxon,
        "score": 1.0,
        "rank_within_target_marker": 1,
    }
    row.update(lineage)
    candidates_path = _stage_artifact(region_prefix, "regions", "region_candidates.csv")
    with candidates_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerow(row)
    remap_fieldnames = [
        "barcode",
        "resolved_level",
        "resolved_taxon",
        "marker_id",
        "aligned_start",
        "aligned_end",
        "window_aa_length",
        "rank_within_target_marker",
        "accession",
        "region_nt_start",
        "region_nt_end",
        "region_nt_window",
        *levels,
    ]
    effective_remap_rows = list(remap_rows or [(accession, region_nt_window)])
    remap_manifest_path = _stage_artifact(region_prefix, "regions", "region_remap_manifest.csv")
    with remap_manifest_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=remap_fieldnames)
        writer.writeheader()
        for remap_accession, remap_window in effective_remap_rows:
            remap_row = {
                "barcode": barcode,
                "resolved_level": resolved_level,
                "resolved_taxon": resolved_taxon,
                "marker_id": marker_id,
                "aligned_start": 1,
                "aligned_end": 2,
                "window_aa_length": 2,
                "rank_within_target_marker": 1,
                "accession": remap_accession,
                "region_nt_start": 1,
                "region_nt_end": len(remap_window),
                "region_nt_window": remap_window,
            }
            remap_row.update(lineage)
            writer.writerow(remap_row)


def _write_target_discovery_fixture(
    tag_prefix: Path,
    target_prefix: Path,
    *,
    barcode: str,
    resolved_level: str,
    resolved_taxon: str,
    marker_id: str,
    lineage: dict[str, str | None],
    parent_level: str,
    parent_taxon: str,
    rank_within_target: int = 1,
) -> None:
    tag_prefix = _normalize_stage_prefix(tag_prefix, "tags")
    target_prefix = _normalize_stage_prefix(target_prefix, "targets")
    levels = ["domain", "phylum", "class", "order", "family", "genus", "species"]
    tag_summary = {"levels": levels}
    target_summary = {"tag_design_prefix": str(tag_prefix)}
    tag_prefix.parent.mkdir(parents=True, exist_ok=True)
    target_prefix.parent.mkdir(parents=True, exist_ok=True)
    _stage_artifact(tag_prefix, "tags", "summary.json").write_text(
        json.dumps(tag_summary, indent=2) + "\n", encoding="utf-8"
    )
    _stage_artifact(target_prefix, "targets", "summary.json").write_text(
        json.dumps(target_summary, indent=2) + "\n", encoding="utf-8"
    )
    _write_stage_manifest(tag_prefix, "tags", tag_summary)
    _write_stage_manifest(target_prefix, "targets", target_summary)

    fieldnames = [
        "barcode",
        "resolved_level",
        "resolved_taxon",
        "marker_id",
        "parent_level",
        "parent_taxon",
        "rank_within_target",
        *levels,
    ]
    row = {
        "barcode": barcode,
        "resolved_level": resolved_level,
        "resolved_taxon": resolved_taxon,
        "marker_id": marker_id,
        "parent_level": parent_level,
        "parent_taxon": parent_taxon,
        "rank_within_target": rank_within_target,
    }
    row.update(lineage)
    manifest_path = _stage_artifact(target_prefix, "targets", "top_marker_manifest.csv")
    with manifest_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerow(row)


def _write_catalog(path: Path, paths: dict[str, Path]) -> None:
    payload = {
        "release": "r226",
        "datasets": {
            "archaea": {
                "name": "ar53_test",
                "taxon": "archaea",
                "files": {
                    "taxonomy": {"filename": "ar53_taxonomy.tsv", "url": paths["archaea_taxonomy"].resolve().as_uri()},
                    "msa": {"filename": "ar53_msa.tar.gz", "url": paths["archaea_msa"].resolve().as_uri()},
                    "markers": {"filename": "ar53_markers.tar.gz", "url": paths["archaea_markers"].resolve().as_uri()},
                },
            },
            "bacteria": {
                "name": "bac120_test",
                "taxon": "bacteria",
                "files": {
                    "taxonomy": {"filename": "bac120_taxonomy.tsv", "url": paths["bacteria_taxonomy"].resolve().as_uri()},
                    "msa": {"filename": "bac120_msa.tar.gz", "url": paths["bacteria_msa"].resolve().as_uri()},
                    "markers": {"filename": "bac120_markers.tar.gz", "url": paths["bacteria_markers"].resolve().as_uri()},
                },
            },
        },
    }
    path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


def _write_multi_release_catalog(path: Path, paths: dict[str, Path]) -> None:
    def _release_payload(release: str) -> dict[str, object]:
        return {
            "datasets": {
                "archaea": {
                    "name": f"ar53_test_{release}",
                    "taxon": "archaea",
                    "files": {
                        "taxonomy": {"filename": f"ar53_taxonomy_{release}.tsv", "url": paths["archaea_taxonomy"].resolve().as_uri()},
                        "msa": {"filename": f"ar53_msa_{release}.tar.gz", "url": paths["archaea_msa"].resolve().as_uri()},
                        "markers": {"filename": f"ar53_markers_{release}.tar.gz", "url": paths["archaea_markers"].resolve().as_uri()},
                    },
                },
                "bacteria": {
                    "name": f"bac120_test_{release}",
                    "taxon": "bacteria",
                    "files": {
                        "taxonomy": {"filename": f"bac120_taxonomy_{release}.tsv", "url": paths["bacteria_taxonomy"].resolve().as_uri()},
                        "msa": {"filename": f"bac120_msa_{release}.tar.gz", "url": paths["bacteria_msa"].resolve().as_uri()},
                        "markers": {"filename": f"bac120_markers_{release}.tar.gz", "url": paths["bacteria_markers"].resolve().as_uri()},
                    },
                },
            }
        }

    payload = {
        "default_release": "r226",
        "releases": {
            "r226": _release_payload("r226"),
            "r220": _release_payload("r220"),
        },
    }
    path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


class CliTests(unittest.TestCase):
    def test_output_format_helper_accepts_enum_and_string(self) -> None:
        self.assertTrue(_is_json_output("json"))
        self.assertTrue(_is_json_output(OutputFormat.json))
        self.assertFalse(_is_json_output("text"))
        self.assertFalse(_is_json_output(OutputFormat.text))

    def test_regions_text_output_truncates_marker_preview(self) -> None:
        rows = [
            {
                "barcode": "AT",
                "marker_id": f"M{index}",
                "status": "ready",
                "target_alignment_sequences": 10,
                "selected_regions": 1,
            }
            for index in range(1, 26)
        ]
        result = SimpleNamespace(
            dataset="archaea",
            taxonomy_file="/tmp/taxonomy.tsv",
            msa_archive="/tmp/msa.tar.gz",
            markers_archive="/tmp/markers.tar.gz",
            target_discovery_prefix="/tmp/targets",
            selected_target_markers=rows,
            analyzed_markers=25,
            window_aa_length=12,
            window_aa_length_min=10,
            window_aa_length_max=16,
            top_regions_per_marker=3,
            min_target_window_presence=0.8,
            max_aa_mismatches=1,
            aa_mismatch_penalty_per_mismatch=0.25,
            region_probe_length=30,
            min_target_remap_fraction=0.7,
            min_best_probe_support_fraction=0.6,
            probeability_weight=0.5,
            output_files={},
        )

        text = _regions_discover_text(result, Path("/tmp/output"))

        self.assertIn("M1", text)
        self.assertIn("M20", text)
        self.assertNotIn("M21", text)
        self.assertIn("... (5 more rows not shown)", text)

    def test_root_header_text_can_omit_description(self) -> None:
        header_only = _render_root_header_text(include_description=False)
        header_with_description = _render_root_header_text(include_description=True)
        self.assertIn("PhyloProbe", header_only)
        self.assertNotIn(ROOT_DESCRIPTION, header_only)
        normalized_description = " ".join(ROOT_DESCRIPTION.split())
        normalized_header = " ".join(header_with_description.split())
        self.assertIn(normalized_description, normalized_header)

    def _make_paths(self, temp_dir: str) -> dict[str, Path]:
        return {
            "archaea_taxonomy": Path(temp_dir) / "archaea.tsv",
            "archaea_msa": Path(temp_dir) / "archaea_msa.tar.gz",
            "archaea_markers": Path(temp_dir) / "archaea_markers.tar.gz",
            "bacteria_taxonomy": Path(temp_dir) / "bacteria.tsv",
            "bacteria_msa": Path(temp_dir) / "bacteria_msa.tar.gz",
            "bacteria_markers": Path(temp_dir) / "bacteria_markers.tar.gz",
        }

    def _populate_catalog_inputs(self, paths: dict[str, Path]) -> None:
        _write_taxonomy_file(paths["archaea_taxonomy"], "Archaea")
        _write_tar_archive(paths["archaea_msa"], {"individual/a.faa": ">a\nAAAA\n"})
        _write_tar_archive(paths["archaea_markers"], {"individual/a.fna": ">a\nATGC\n"})
        _write_taxonomy_file(paths["bacteria_taxonomy"], "Bacteria")
        _write_tar_archive(paths["bacteria_msa"], {"individual/b.faa": ">b\nBBBB\n"})
        _write_tar_archive(paths["bacteria_markers"], {"individual/b.fna": ">b\nATGC\n"})

    def test_datasets_install_defaults_to_all(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            home = Path(temp_dir) / "home"
            datasets_dir = Path(temp_dir) / "datasets-store"
            paths = self._make_paths(temp_dir)
            self._populate_catalog_inputs(paths)
            catalog_path = Path(temp_dir) / "catalog.json"
            _write_catalog(catalog_path, paths)

            previous = None
            if APP_HOME_ENV in __import__("os").environ:
                previous = __import__("os").environ[APP_HOME_ENV]
            __import__("os").environ[APP_HOME_ENV] = str(home)
            try:
                stdout = io.StringIO()
                stderr = io.StringIO()
                with redirect_stdout(stdout), redirect_stderr(stderr):
                    exit_code = main(
                        [
                            "datasets",
                                                        "--catalog-file",
                            str(catalog_path),
                            "--datasets-dir",
                            str(datasets_dir),
                            "--format",
                            "json",
                        ]
                    )
                self.assertEqual(exit_code, 0)
                self.assertIn('"archaea"', stdout.getvalue())
                self.assertIn('"bacteria"', stdout.getvalue())
                self.assertIn(str(datasets_dir), stderr.getvalue().replace("\n", ""))
                self.assertTrue((datasets_dir / "archaea").exists())
                self.assertFalse((home / "datasets" / "archaea").exists())
            finally:
                if previous is None:
                    __import__("os").environ.pop(APP_HOME_ENV, None)
                else:
                    __import__("os").environ[APP_HOME_ENV] = previous

    def test_datasets_install_can_limit_to_archaea(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            home = Path(temp_dir) / "home"
            datasets_dir = Path(temp_dir) / "datasets-store"
            paths = self._make_paths(temp_dir)
            self._populate_catalog_inputs(paths)
            catalog_path = Path(temp_dir) / "catalog.json"
            _write_catalog(catalog_path, paths)

            previous = None
            if APP_HOME_ENV in __import__("os").environ:
                previous = __import__("os").environ[APP_HOME_ENV]
            __import__("os").environ[APP_HOME_ENV] = str(home)
            try:
                stdout = io.StringIO()
                with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                    exit_code = main(
                        [
                            "datasets",
                                                        "--taxon",
                            "archaea",
                            "--catalog-file",
                            str(catalog_path),
                            "--datasets-dir",
                            str(datasets_dir),
                            "--format",
                            "json",
                        ]
                    )
                self.assertEqual(exit_code, 0)
                self.assertIn('"archaea"', stdout.getvalue())
                self.assertNotIn('"bacteria"', stdout.getvalue())
                self.assertTrue((datasets_dir / "archaea").exists())
                self.assertFalse((datasets_dir / "bacteria").exists())
            finally:
                if previous is None:
                    __import__("os").environ.pop(APP_HOME_ENV, None)
                else:
                    __import__("os").environ[APP_HOME_ENV] = previous

    def test_taxonomy_summarize_dataset_uses_registry_after_custom_install_path(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            home = Path(temp_dir) / "home"
            datasets_dir = Path(temp_dir) / "datasets-store"
            paths = self._make_paths(temp_dir)
            self._populate_catalog_inputs(paths)
            catalog_path = Path(temp_dir) / "catalog.json"
            _write_catalog(catalog_path, paths)

            previous = None
            if APP_HOME_ENV in __import__("os").environ:
                previous = __import__("os").environ[APP_HOME_ENV]
            __import__("os").environ[APP_HOME_ENV] = str(home)
            try:
                with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
                    install_exit_code = main(
                        [
                            "datasets",
                                                        "--taxon",
                            "archaea",
                            "--catalog-file",
                            str(catalog_path),
                            "--datasets-dir",
                            str(datasets_dir),
                            "--format",
                            "json",
                        ]
                    )
                self.assertEqual(install_exit_code, 0)

                stdout = io.StringIO()
                with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                    exit_code = main(
                        [
                            "taxonomy",
                                                        "--dataset",
                            "archaea",
                            "--format",
                            "json",
                        ]
                    )
                self.assertEqual(exit_code, 0)
                self.assertIn('"genomes": 1', stdout.getvalue())
            finally:
                if previous is None:
                    __import__("os").environ.pop(APP_HOME_ENV, None)
                else:
                    __import__("os").environ[APP_HOME_ENV] = previous

    def test_datasets_install_can_select_gtdb_release(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            home = Path(temp_dir) / "home"
            datasets_dir = Path(temp_dir) / "datasets-store"
            paths = self._make_paths(temp_dir)
            self._populate_catalog_inputs(paths)
            catalog_path = Path(temp_dir) / "catalog.json"
            _write_multi_release_catalog(catalog_path, paths)

            previous = None
            if APP_HOME_ENV in os.environ:
                previous = os.environ[APP_HOME_ENV]
            os.environ[APP_HOME_ENV] = str(home)
            try:
                stdout = io.StringIO()
                with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                    exit_code = main(
                        [
                            "datasets",
                            "--taxon",
                            "archaea",
                            "--catalog-file",
                            str(catalog_path),
                            "--gtdb-release",
                            "r220",
                            "--datasets-dir",
                            str(datasets_dir),
                            "--format",
                            "json",
                        ]
                    )
                self.assertEqual(exit_code, 0)
                payload = json.loads(stdout.getvalue())
                self.assertIn("archaea_r220", payload)
                self.assertNotIn("archaea_r226", payload)
                self.assertEqual(payload["archaea_r220"]["record"]["logical_key"], "archaea")
                self.assertEqual(payload["archaea_r220"]["record"]["release"], "r220")
                self.assertTrue((datasets_dir / "archaea_r220").exists())
            finally:
                if previous is None:
                    os.environ.pop(APP_HOME_ENV, None)
                else:
                    os.environ[APP_HOME_ENV] = previous

    def test_taxonomy_summarize_dataset_can_resolve_logical_name_with_gtdb_release(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            home = Path(temp_dir) / "home"
            datasets_dir = Path(temp_dir) / "datasets-store"
            paths = self._make_paths(temp_dir)
            self._populate_catalog_inputs(paths)
            catalog_path = Path(temp_dir) / "catalog.json"
            _write_multi_release_catalog(catalog_path, paths)

            previous = None
            if APP_HOME_ENV in os.environ:
                previous = os.environ[APP_HOME_ENV]
            os.environ[APP_HOME_ENV] = str(home)
            try:
                with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
                    install_exit_code = main(
                        [
                            "datasets",
                            "--taxon",
                            "archaea",
                            "--catalog-file",
                            str(catalog_path),
                            "--gtdb-release",
                            "r220",
                            "--datasets-dir",
                            str(datasets_dir),
                            "--format",
                            "json",
                        ]
                    )
                self.assertEqual(install_exit_code, 0)

                stdout = io.StringIO()
                with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                    exit_code = main(
                        [
                            "taxonomy",
                            "--dataset",
                            "archaea",
                            "--gtdb-release",
                            "r220",
                            "--format",
                            "json",
                        ]
                    )
                self.assertEqual(exit_code, 0)
                payload = json.loads(stdout.getvalue())
                self.assertEqual(payload["genomes"], 1)
                self.assertEqual(payload["genomes"], 1)
                self.assertEqual(payload["unique_lineages"], 1)
            finally:
                if previous is None:
                    os.environ.pop(APP_HOME_ENV, None)
                else:
                    os.environ[APP_HOME_ENV] = previous

    def test_tags_design_can_use_release_selected_dataset(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            home = Path(temp_dir) / "home"
            datasets_dir = Path(temp_dir) / "datasets-store"
            output_dir = Path(temp_dir) / "runs"
            session = "archaea_r220_demo"
            paths = self._make_paths(temp_dir)
            self._populate_catalog_inputs(paths)
            catalog_path = Path(temp_dir) / "catalog.json"
            _write_multi_release_catalog(catalog_path, paths)

            previous = None
            if APP_HOME_ENV in os.environ:
                previous = os.environ[APP_HOME_ENV]
            os.environ[APP_HOME_ENV] = str(home)
            try:
                with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
                    install_exit_code = main(
                        [
                            "datasets",
                            "--taxon",
                            "archaea",
                            "--catalog-file",
                            str(catalog_path),
                            "--gtdb-release",
                            "r220",
                            "--datasets-dir",
                            str(datasets_dir),
                            "--format",
                            "json",
                        ]
                    )
                self.assertEqual(install_exit_code, 0)

                stdout = io.StringIO()
                with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                    exit_code = main(
                        [
                            "tags",
                            "--dataset",
                            "archaea",
                            "--gtdb-release",
                            "r220",
                            "--output",
                            str(output_dir),
                            "--session",
                            session,
                            "--positions",
                            "1",
                            "--format",
                            "json",
                        ]
                    )
                self.assertEqual(exit_code, 0)
                payload = json.loads(stdout.getvalue())
                self.assertEqual(payload["prepared_taxonomy"]["genomes"], 1)
                self.assertTrue((_stage_artifact(output_dir / session, "tags", "summary.json")).exists())
            finally:
                if previous is None:
                    os.environ.pop(APP_HOME_ENV, None)
                else:
                    os.environ[APP_HOME_ENV] = previous

    def test_tags_design_from_taxonomy_file_writes_outputs(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            output_prefix = Path(temp_dir) / "outputs" / "tag_design"
            taxonomy_path.write_text(
                "\n".join(
                    [
                        "RS_GCF_000001\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                        "RS_GCF_000002\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G2;s__S2",
                        "RS_GCF_000003\td__Archaea;p__P2;c__C2;o__O2;f__F2;g__G3;s__S3",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "tags",
                                                "--taxonomy-file",
                        str(taxonomy_path),
                        "--output-prefix",
                        str(output_prefix),
                        "--positions",
                        "2",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["positions"], 2)
            self.assertIn("level_positions", payload)
            self.assertIn("objective", payload)
            self.assertIn("used_slots", payload["objective"])
            self.assertIn("total_slots", payload["objective"])
            self.assertIn("available_slots", payload["level_positions"][0])
            self.assertIn("used_slots", payload["level_positions"][0])
            self.assertTrue(_stage_artifact(output_prefix, "tags", "summary.json").exists())
            self.assertTrue(_stage_artifact(output_prefix, "tags", "label_table.csv").exists())
            self.assertTrue(_stage_artifact(output_prefix, "tags", "final_leaf_labels.csv").exists())

    def test_tags_design_session_layout_writes_outputs(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            output_dir = Path(temp_dir) / "runs"
            session_name = "archaea_demo"
            taxonomy_path.write_text(
                "\n".join(
                    [
                        "RS_GCF_000001\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                        "RS_GCF_000002\td__Archaea;p__P2;c__C2;o__O2;f__F2;g__G2;s__S2",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "tags",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--output",
                        str(output_dir),
                        "--session",
                        session_name,
                        "--positions",
                        "1",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["positions"], 1)
            expected_prefix = _session_stage_prefix(output_dir, session_name, "tags")
            self.assertTrue(expected_prefix.parent.exists())
            self.assertTrue(_stage_artifact(expected_prefix, "tags", "summary.json").exists())
            self.assertTrue(_stage_artifact(expected_prefix, "tags", "label_table.csv").exists())

    def test_tags_design_auto_increments_attempts_and_updates_manifest(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            output_dir = Path(temp_dir) / "runs"
            session_name = "archaea_demo"
            taxonomy_path.write_text(
                "\n".join(
                    [
                        "RS_GCF_000001\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                        "RS_GCF_000002\td__Archaea;p__P2;c__C2;o__O2;f__F2;g__G2;s__S2",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )

            for positions in ("1", "2"):
                stdout = io.StringIO()
                with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                    exit_code = main(
                        [
                            "tags",
                            "--taxonomy-file",
                            str(taxonomy_path),
                            "--output",
                            str(output_dir),
                            "--session",
                            session_name,
                            "--positions",
                            positions,
                            "--format",
                            "json",
                        ]
                    )
                self.assertEqual(exit_code, 0)

            first_prefix = _session_stage_prefix(output_dir, session_name, "tags", "01")
            second_prefix = _session_stage_prefix(output_dir, session_name, "tags", "02")
            self.assertTrue(_stage_artifact(first_prefix, "tags", "summary.json").exists())
            self.assertTrue(_stage_artifact(second_prefix, "tags", "summary.json").exists())

            manifest = json.loads(_stage_manifest_path(output_dir, session_name, "tags").read_text(encoding="utf-8"))
            self.assertEqual(manifest["active_attempt"], "02")
            self.assertIn("01", manifest["attempts"])
            self.assertIn("02", manifest["attempts"])
            self.assertEqual(Path(manifest["attempts"]["02"]["prefix"]).resolve(), second_prefix.resolve())

    def test_tags_design_rejects_invalid_session_name(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            output_dir = Path(temp_dir) / "runs"
            taxonomy_path.write_text(
                "RS_GCF_000001\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1\n",
                encoding="utf-8",
            )

            stderr = io.StringIO()
            with redirect_stdout(io.StringIO()), redirect_stderr(stderr):
                exit_code = main(
                    [
                        "tags",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--output",
                        str(output_dir),
                        "--session",
                        "bad-name",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 1)
            self.assertIn("letters, digits, and underscores", stderr.getvalue())

    def test_tags_design_can_use_installed_dataset(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            home = Path(temp_dir) / "home"
            datasets_dir = Path(temp_dir) / "datasets-store"
            output_prefix = Path(temp_dir) / "outputs" / "dataset_design"
            paths = self._make_paths(temp_dir)
            self._populate_catalog_inputs(paths)
            catalog_path = Path(temp_dir) / "catalog.json"
            _write_catalog(catalog_path, paths)

            previous = None
            if APP_HOME_ENV in __import__("os").environ:
                previous = __import__("os").environ[APP_HOME_ENV]
            __import__("os").environ[APP_HOME_ENV] = str(home)
            try:
                with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
                    install_exit_code = main(
                        [
                            "datasets",
                                                        "--taxon",
                            "archaea",
                            "--catalog-file",
                            str(catalog_path),
                            "--datasets-dir",
                            str(datasets_dir),
                            "--format",
                            "json",
                        ]
                    )
                self.assertEqual(install_exit_code, 0)

                stdout = io.StringIO()
                with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                    exit_code = main(
                        [
                            "tags",
                                                        "--dataset",
                            "archaea",
                            "--output-prefix",
                            str(output_prefix),
                            "--positions",
                            "2",
                            "--format",
                            "json",
                        ]
                    )
                self.assertEqual(exit_code, 0)
                payload = json.loads(stdout.getvalue())
                self.assertEqual(payload["prepared_taxonomy"]["genomes"], 1)
                self.assertTrue(_stage_artifact(output_prefix, "tags", "summary.json").exists())
            finally:
                if previous is None:
                    __import__("os").environ.pop(APP_HOME_ENV, None)
                else:
                    __import__("os").environ[APP_HOME_ENV] = previous

    def test_tags_design_include_can_force_taxon_into_selection(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            output_prefix = Path(temp_dir) / "outputs" / "tag_design"
            rows = []
            for phylum, count in (("p__P1", 5), ("p__P2", 4), ("p__P3", 3), ("p__P4", 2), ("p__P5", 1)):
                for index in range(count):
                    rows.append(
                        f"RS_GCF_{len(rows) + 1:06d}\td__Archaea;{phylum};c__C{index};o__O{index};f__F{index};g__G{index};s__S{index}"
                    )
            taxonomy_path.write_text("\n".join(rows) + "\n", encoding="utf-8")

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "tags",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--output-prefix",
                        str(output_prefix),
                        "--levels",
                        "phylum",
                        "--positions",
                        "1",
                        "--include",
                        "phylum:p__P5",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["constraints"]["include_taxa"], {"phylum": ["p__P5"]})

            final_leaf_path = _stage_artifact(output_prefix, "tags", "final_leaf_labels.csv")
            with final_leaf_path.open("r", encoding="utf-8", newline="") as handle:
                selected = {row["phylum"] for row in csv.DictReader(handle)}
            self.assertEqual(selected, {"p__P1", "p__P2", "p__P3", "p__P5"})

    def test_tags_design_exclude_removes_taxa_before_optimization(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            output_prefix = Path(temp_dir) / "outputs" / "tag_design"
            rows = []
            for phylum, count in (("p__P1", 5), ("p__P2", 4), ("p__P3", 3), ("p__P4", 2), ("p__P5", 1)):
                for index in range(count):
                    rows.append(
                        f"RS_GCF_{len(rows) + 1:06d}\td__Archaea;{phylum};c__C{index};o__O{index};f__F{index};g__G{index};s__S{index}"
                    )
            taxonomy_path.write_text("\n".join(rows) + "\n", encoding="utf-8")

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "tags",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--output-prefix",
                        str(output_prefix),
                        "--levels",
                        "phylum",
                        "--positions",
                        "1",
                        "--exclude",
                        "phylum:p__P2",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["constraints"]["exclude_taxa"], {"phylum": ["p__P2"]})
            self.assertEqual(payload["prepared_taxonomy"]["genomes_excluded"], 4)
            self.assertEqual(payload["coverage_summary"][0]["total_taxa"], 4)

            final_leaf_path = _stage_artifact(output_prefix, "tags", "final_leaf_labels.csv")
            with final_leaf_path.open("r", encoding="utf-8", newline="") as handle:
                selected = {row["phylum"] for row in csv.DictReader(handle)}
            self.assertEqual(selected, {"p__P1", "p__P3", "p__P4", "p__P5"})

    def test_tags_design_exclusive_restricts_to_selected_clades(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            output_prefix = Path(temp_dir) / "outputs" / "tag_design"
            taxonomy_path.write_text(
                "\n".join(
                    [
                        "RS_GCF_000001\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                        "RS_GCF_000002\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G2;s__S2",
                        "RS_GCF_000003\td__Archaea;p__P1;c__C2;o__O2;f__F2;g__G3;s__S3",
                        "RS_GCF_000004\td__Archaea;p__P2;c__C3;o__O3;f__F3;g__G4;s__S4",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "tags",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--output-prefix",
                        str(output_prefix),
                        "--levels",
                        "family,genus",
                        "--positions",
                        "1",
                        "--exclusive",
                        "family:f__F1",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["constraints"]["exclusive_taxa"], {"family": ["f__F1"]})
            self.assertEqual(payload["prepared_taxonomy"]["genomes_exclusive_filtered"], 2)
            self.assertEqual(payload["prepared_taxonomy"]["genomes_retained"], 2)
            self.assertEqual(payload["coverage_summary"][0]["total_taxa"], 1)

            final_leaf_path = _stage_artifact(output_prefix, "tags", "final_leaf_labels.csv")
            with final_leaf_path.open("r", encoding="utf-8", newline="") as handle:
                rows = list(csv.DictReader(handle))
            forbidden = {"f__F2", "f__F3", "g__G3", "g__G4"}
            self.assertTrue(rows)
            for row in rows:
                self.assertTrue(forbidden.isdisjoint(set(row.values())))

    def test_tags_design_rejects_overlapping_include_and_exclude(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            output_prefix = Path(temp_dir) / "outputs" / "tag_design"
            taxonomy_path.write_text(
                "\n".join(
                    [
                        "RS_GCF_000001\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                        "RS_GCF_000002\td__Archaea;p__P2;c__C2;o__O2;f__F2;g__G2;s__S2",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )

            stderr = io.StringIO()
            with redirect_stdout(io.StringIO()), redirect_stderr(stderr):
                exit_code = main(
                    [
                        "tags",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--output-prefix",
                        str(output_prefix),
                        "--levels",
                        "phylum",
                        "--positions",
                        "1",
                        "--include",
                        "phylum:p__P1",
                        "--exclude",
                        "phylum:p__P1",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 1)
            self.assertIn("both included and excluded", stderr.getvalue())

    def test_tags_design_rejects_overlapping_exclusive_and_exclude(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            output_prefix = Path(temp_dir) / "outputs" / "tag_design"
            taxonomy_path.write_text(
                "\n".join(
                    [
                        "RS_GCF_000001\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                        "RS_GCF_000002\td__Archaea;p__P2;c__C2;o__O2;f__F2;g__G2;s__S2",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )

            stderr = io.StringIO()
            with redirect_stdout(io.StringIO()), redirect_stderr(stderr):
                exit_code = main(
                    [
                        "tags",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--output-prefix",
                        str(output_prefix),
                        "--levels",
                        "phylum",
                        "--positions",
                        "1",
                        "--exclusive",
                        "phylum:p__P1",
                        "--exclude",
                        "phylum:p__P1",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 1)
            self.assertIn("both exclusive and excluded", stderr.getvalue())

    def test_tags_design_prefer_and_avoid_softly_steer_selection(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            output_prefix = Path(temp_dir) / "outputs" / "tag_design"
            rows = []
            for phylum, count in (("p__P1", 5), ("p__P2", 4), ("p__P3", 3), ("p__P4", 2), ("p__P5", 1)):
                for index in range(count):
                    rows.append(
                        f"RS_GCF_{len(rows) + 1:06d}\td__Archaea;{phylum};c__C{index};o__O{index};f__F{index};g__G{index};s__S{index}"
                    )
            taxonomy_path.write_text("\n".join(rows) + "\n", encoding="utf-8")

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "tags",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--output-prefix",
                        str(output_prefix),
                        "--levels",
                        "phylum",
                        "--positions",
                        "1",
                        "--prefer",
                        "phylum:p__P5",
                        "--avoid",
                        "phylum:p__P2",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["constraints"]["prefer_taxa"], {"phylum": ["p__P5"]})
            self.assertEqual(payload["constraints"]["avoid_taxa"], {"phylum": ["p__P2"]})

            final_leaf_path = _stage_artifact(output_prefix, "tags", "final_leaf_labels.csv")
            with final_leaf_path.open("r", encoding="utf-8", newline="") as handle:
                selected = {row["phylum"] for row in csv.DictReader(handle)}
            self.assertEqual(selected, {"p__P1", "p__P3", "p__P4", "p__P5"})

    def test_tags_design_accepts_binary_digit_alphabet(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            output_prefix = Path(temp_dir) / "outputs" / "tag_design"
            taxonomy_path.write_text(
                "\n".join(
                    [
                        "RS_GCF_000001\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                        "RS_GCF_000002\td__Archaea;p__P2;c__C2;o__O2;f__F2;g__G2;s__S2",
                        "RS_GCF_000003\td__Archaea;p__P3;c__C3;o__O3;f__F3;g__G3;s__S3",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "tags",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--output-prefix",
                        str(output_prefix),
                        "--levels",
                        "phylum",
                        "--positions",
                        "1",
                        "--alphabet",
                        "[0,1]",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["alphabet"], ["0", "1"])
            self.assertEqual(payload["level_positions"][0]["capacity_per_parent"], 2)

            final_leaf_path = _stage_artifact(output_prefix, "tags", "final_leaf_labels.csv")
            with final_leaf_path.open("r", encoding="utf-8", newline="") as handle:
                rows = list(csv.DictReader(handle))
            self.assertEqual(len(rows), 2)
            self.assertEqual({row["barcode"] for row in rows}, {"0", "1"})

    def test_tags_design_rejects_invalid_alphabet_symbols(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            output_prefix = Path(temp_dir) / "outputs" / "tag_design"
            taxonomy_path.write_text(
                "RS_GCF_000001\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1\n",
                encoding="utf-8",
            )

            stderr = io.StringIO()
            with redirect_stdout(io.StringIO()), redirect_stderr(stderr):
                exit_code = main(
                    [
                        "tags",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--output-prefix",
                        str(output_prefix),
                        "--alphabet",
                        "AA,B",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 1)
            self.assertIn("exactly one character", stderr.getvalue())

    def test_tags_design_text_output_includes_taxonomy_tree(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            output_prefix = Path(temp_dir) / "outputs" / "tag_design"
            taxonomy_path.write_text(
                "\n".join(
                    [
                        "RS_GCF_000001\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                        "RS_GCF_000002\td__Archaea;p__P1;c__C2;o__O2;f__F2;g__G2;s__S2",
                        "RS_GCF_000003\td__Archaea;p__P2;c__C3;o__O3;f__F3;g__G3;s__S3",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "tags",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--output-prefix",
                        str(output_prefix),
                        "--levels",
                        "phylum,class",
                        "--positions",
                        "2",
                        "--no-color",
                    ]
                )
            self.assertEqual(exit_code, 0)
            text = stdout.getvalue()
            self.assertIn("available_slots:", text)
            self.assertIn("used_slots:", text)
            self.assertIn("taxonomy_tree:", text)
            self.assertIn("c__C1", text)
            self.assertIn("c__C3", text)

    def test_tags_design_tree_shows_tags_on_ancestor_rows_when_level_is_allocated(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            output_prefix = Path(temp_dir) / "outputs" / "tag_design"
            taxonomy_path.write_text(
                "\n".join(
                    [
                        "RS_GCF_000001\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                        "RS_GCF_000002\td__Archaea;p__P1;c__C2;o__O2;f__F2;g__G2;s__S2",
                        "RS_GCF_000003\td__Archaea;p__P2;c__C3;o__O3;f__F3;g__G3;s__S3",
                        "RS_GCF_000004\td__Archaea;p__P2;c__C4;o__O4;f__F4;g__G4;s__S4",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )

            with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "tags",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--output-prefix",
                        str(output_prefix),
                        "--levels",
                        "phylum,class",
                        "--positions",
                        "2",
                        "--maximise-levels",
                        "phylum",
                        "--min-taxa-per-level",
                        "class:4",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)

            tree_path = _stage_artifact(output_prefix, "tags", "taxonomy_tree.txt")
            tree_text = tree_path.read_text(encoding="utf-8")
            self.assertIn("A   - p__P1", tree_text)
            self.assertIn("AA    - c__C1", tree_text)
            self.assertIn("T   - p__P2", tree_text)
            self.assertIn("TA    - c__C3", tree_text)

    def test_tags_design_level_weights_can_override_equal_weighting(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            default_prefix = Path(temp_dir) / "outputs" / "tag_design_default"
            weighted_prefix = Path(temp_dir) / "outputs" / "tag_design_weighted"
            rows = []
            lineage_specs = [
                ("p__P1", [("c__A1", 10), ("c__A2", 10), ("c__A3", 10), ("c__A4", 10)]),
                ("p__P2", [("c__B1", 1)]),
                ("p__P3", [("c__C1", 1)]),
                ("p__P4", [("c__D1", 1)]),
                ("p__P5", [("c__E1", 1)]),
            ]
            for phylum, classes in lineage_specs:
                for class_name, count in classes:
                    for _ in range(count):
                        rows.append(
                            f"RS_GCF_{len(rows) + 1:06d}\td__Archaea;{phylum};{class_name};o__O{len(rows)};f__F{len(rows)};g__G{len(rows)};s__S{len(rows)}"
                        )
            taxonomy_path.write_text("\n".join(rows) + "\n", encoding="utf-8")

            with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "tags",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--output-prefix",
                        str(default_prefix),
                        "--levels",
                        "phylum,class",
                        "--positions",
                        "1",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)

            with _stage_artifact(default_prefix, "tags", "final_leaf_labels.csv").open(
                "r", encoding="utf-8", newline=""
            ) as handle:
                default_rows = list(csv.DictReader(handle))
            self.assertEqual({row["resolved_level"] for row in default_rows}, {"phylum"})
            self.assertEqual(
                {row["phylum"] for row in default_rows},
                {"p__P1", "p__P2", "p__P3", "p__P4"},
            )

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "tags",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--output-prefix",
                        str(weighted_prefix),
                        "--levels",
                        "phylum,class",
                        "--positions",
                        "1",
                        "--level-weights",
                        "phylum:1,class:2",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertAlmostEqual(payload["level_weights"]["phylum"], 1.0 / 3.0)
            self.assertAlmostEqual(payload["level_weights"]["class"], 2.0 / 3.0)
            self.assertEqual(payload["objective_levels"], ["phylum", "class"])

            with _stage_artifact(weighted_prefix, "tags", "final_leaf_labels.csv").open(
                "r", encoding="utf-8", newline=""
            ) as handle:
                weighted_rows = list(csv.DictReader(handle))
            self.assertEqual({row["resolved_level"] for row in weighted_rows}, {"class"})
            self.assertEqual({row["phylum"] for row in weighted_rows}, {""})
            self.assertEqual(
                {row["class"] for row in weighted_rows},
                {"c__A1", "c__A2", "c__A3", "c__A4"},
            )

            with _stage_artifact(weighted_prefix, "tags", "coverage_summary.csv").open(
                "r", encoding="utf-8", newline=""
            ) as handle:
                coverage_rows = {row["level"]: row for row in csv.DictReader(handle)}
            self.assertAlmostEqual(float(coverage_rows["phylum"]["level_weight"]), 1.0 / 3.0)
            self.assertAlmostEqual(float(coverage_rows["class"]["level_weight"]), 2.0 / 3.0)

    def test_tags_design_descendants_soft_prefers_richer_branches(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            output_prefix = Path(temp_dir) / "outputs" / "tag_design"
            rows = []
            lineage_specs = [
                ("p__P1", ["c__A1"], 6),
                ("p__P2", ["c__B1", "c__B2"], 3),
                ("p__P3", ["c__C1", "c__C2"], 2),
                ("p__P4", ["c__D1"], 5),
                ("p__P5", ["c__E1"], 4),
                ("p__P6", ["c__F1", "c__F2"], 2),
            ]
            for phylum, classes, count in lineage_specs:
                for index in range(count):
                    class_name = classes[index % len(classes)]
                    rows.append(
                        f"RS_GCF_{len(rows) + 1:06d}\td__Archaea;{phylum};{class_name};o__O{len(rows)};f__F{len(rows)};g__G{len(rows)};s__S{len(rows)}"
                    )
            taxonomy_path.write_text("\n".join(rows) + "\n", encoding="utf-8")

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "tags",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--output-prefix",
                        str(output_prefix),
                        "--levels",
                        "phylum,class",
                        "--positions",
                        "1",
                        "--maximise-levels",
                        "phylum",
                        "--descendants",
                        "phylum:2",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["constraints"]["descendants"], {"phylum": 2})

            final_leaf_path = _stage_artifact(output_prefix, "tags", "final_leaf_labels.csv")
            with final_leaf_path.open("r", encoding="utf-8", newline="") as handle:
                selected = {row["phylum"] for row in csv.DictReader(handle)}
            self.assertEqual(selected, {"p__P1", "p__P2", "p__P3", "p__P6"})

    def test_tags_design_descendants_hard_filters_branches(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            output_prefix = Path(temp_dir) / "outputs" / "tag_design"
            rows = []
            lineage_specs = [
                ("p__P1", ["c__A1"], 6),
                ("p__P2", ["c__B1", "c__B2"], 3),
                ("p__P3", ["c__C1", "c__C2"], 2),
                ("p__P4", ["c__D1"], 5),
                ("p__P5", ["c__E1"], 4),
                ("p__P6", ["c__F1", "c__F2"], 2),
            ]
            for phylum, classes, count in lineage_specs:
                for index in range(count):
                    class_name = classes[index % len(classes)]
                    rows.append(
                        f"RS_GCF_{len(rows) + 1:06d}\td__Archaea;{phylum};{class_name};o__O{len(rows)};f__F{len(rows)};g__G{len(rows)};s__S{len(rows)}"
                    )
            taxonomy_path.write_text("\n".join(rows) + "\n", encoding="utf-8")

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "tags",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--output-prefix",
                        str(output_prefix),
                        "--levels",
                        "phylum,class",
                        "--positions",
                        "1",
                        "--maximise-levels",
                        "phylum",
                        "--descendants-hard",
                        "phylum:2",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["constraints"]["descendants_hard"], {"phylum": 2})

            final_leaf_path = _stage_artifact(output_prefix, "tags", "final_leaf_labels.csv")
            with final_leaf_path.open("r", encoding="utf-8", newline="") as handle:
                selected = {row["phylum"] for row in csv.DictReader(handle)}
            self.assertEqual(selected, {"p__P2", "p__P3", "p__P6"})

    def test_tags_design_writes_fallback_leaf_labels(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            output_prefix = Path(temp_dir) / "outputs" / "tag_design"
            taxonomy_path.write_text(
                "\n".join(
                    [
                        "RS_GCF_000001\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                        "RS_GCF_000002\td__Archaea;p__P2;c__C2;o__O2;f__F2;g__G2;s__S2",
                        "RS_GCF_000003\td__Archaea;p__P3;c__C3;o__O3;f__F3;g__G3;s__S3",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "tags",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--output-prefix",
                        str(output_prefix),
                        "--levels",
                        "phylum",
                        "--positions",
                        "1",
                        "--alphabet",
                        "[0,1]",
                        "--fallbacks-per-target",
                        "1",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["constraints"]["fallbacks_per_target"], 1)

            fallback_path = _stage_artifact(output_prefix, "tags", "fallback_leaf_labels.csv")
            self.assertTrue(fallback_path.exists())
            with fallback_path.open("r", encoding="utf-8", newline="") as handle:
                rows = list(csv.DictReader(handle))
            self.assertEqual(len(rows), 1)
            self.assertEqual({row["primary_resolved_taxon"] for row in rows}, {"p__P1"})
            self.assertEqual({row["resolved_taxon"] for row in rows}, {"p__P3"})
            self.assertEqual({row["fallback_rank"] for row in rows}, {"1"})

            final_leaf_path = _stage_artifact(output_prefix, "tags", "final_leaf_labels.csv")
            with final_leaf_path.open("r", encoding="utf-8", newline="") as handle:
                primary_taxa = {row["resolved_taxon"] for row in csv.DictReader(handle)}
            fallback_taxa = {row["resolved_taxon"] for row in rows}
            self.assertTrue(primary_taxa.isdisjoint(fallback_taxa))

    def test_tags_design_defaults_to_one_fallback_reserve(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            output_prefix = Path(temp_dir) / "outputs" / "tag_design"
            taxonomy_path.write_text(
                "\n".join(
                    [
                        "RS_GCF_000001\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                        "RS_GCF_000002\td__Archaea;p__P2;c__C2;o__O2;f__F2;g__G2;s__S2",
                        "RS_GCF_000003\td__Archaea;p__P3;c__C3;o__O3;f__F3;g__G3;s__S3",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "tags",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--output-prefix",
                        str(output_prefix),
                        "--levels",
                        "phylum",
                        "--positions",
                        "1",
                        "--alphabet",
                        "[0,1]",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["constraints"]["fallbacks_per_target"], 1)

    def test_tags_design_fallbacks_are_unique_across_barcodes(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            output_prefix = Path(temp_dir) / "outputs" / "tag_design"
            taxonomy_path.write_text(
                "\n".join(
                    [
                        "RS_GCF_000001\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                        "RS_GCF_000002\td__Archaea;p__P2;c__C2;o__O2;f__F2;g__G2;s__S2",
                        "RS_GCF_000003\td__Archaea;p__P3;c__C3;o__O3;f__F3;g__G3;s__S3",
                        "RS_GCF_000004\td__Archaea;p__P4;c__C4;o__O4;f__F4;g__G4;s__S4",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )

            with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "tags",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--output-prefix",
                        str(output_prefix),
                        "--levels",
                        "phylum",
                        "--positions",
                        "1",
                        "--alphabet",
                        "[0,1]",
                        "--fallbacks-per-target",
                        "2",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)

            fallback_path = _stage_artifact(output_prefix, "tags", "fallback_leaf_labels.csv")
            with fallback_path.open("r", encoding="utf-8", newline="") as handle:
                rows = list(csv.DictReader(handle))
            self.assertEqual({row["resolved_taxon"] for row in rows}, {"p__P3", "p__P4"})
            self.assertEqual(len(rows), 2)

    def test_targets_discover_from_explicit_files_writes_outputs(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            tag_output_prefix = Path(temp_dir) / "outputs" / "tag_design"
            target_output_prefix = Path(temp_dir) / "outputs" / "targets"
            markers_archive = Path(temp_dir) / "markers.tar.gz"
            taxonomy_path.write_text(
                "\n".join(
                    [
                        "RS_GCF_000001\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                        "RS_GCF_000002\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G2;s__S2",
                        "RS_GCF_000003\td__Archaea;p__P2;c__C2;o__O2;f__F2;g__G3;s__S3",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )
            _write_tar_archive(
                markers_archive,
                {
                    "markers/fna/M1.fna": (
                        ">RS_GCF_000001\nATGCATGC\n"
                        ">RS_GCF_000002\nATGCATGC\n"
                    ),
                    "markers/fna/M2.fna": (
                        ">RS_GCF_000003\nATGCATGCATGC\n"
                    ),
                    "markers/faa/M1.faa": (
                        ">RS_GCF_000001\nMAA\n"
                        ">RS_GCF_000002\nMAA\n"
                    ),
                },
            )

            with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
                tags_exit_code = main(
                    [
                        "tags",
                                                "--taxonomy-file",
                        str(taxonomy_path),
                        "--output-prefix",
                        str(tag_output_prefix),
                        "--positions",
                        "2",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(tags_exit_code, 0)

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "targets",
                                                "--taxonomy-file",
                        str(taxonomy_path),
                        "--markers-archive",
                        str(markers_archive),
                        "--tag-design-prefix",
                        str(tag_output_prefix),
                        "--output-prefix",
                        str(target_output_prefix),
                        "--top-markers-per-target",
                        "2",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["analyzed_markers"], 2)
            self.assertEqual(len(payload["selected_targets"]), 3)
            self.assertTrue(_stage_artifact(target_output_prefix, "targets", "summary.json").exists())
            self.assertTrue(_stage_artifact(target_output_prefix, "targets", "marker_scores.csv").exists())
            self.assertTrue(_stage_artifact(target_output_prefix, "targets", "top_marker_manifest.csv").exists())

    def test_targets_discover_can_apply_selection_profile(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            tag_output_prefix = Path(temp_dir) / "outputs" / "tag_design"
            target_output_prefix = Path(temp_dir) / "outputs" / "targets"
            markers_archive = Path(temp_dir) / "markers.tar.gz"
            taxonomy_path.write_text(
                "\n".join(
                    [
                        "RS_GCF_000001\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                        "RS_GCF_000002\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G2;s__S2",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )
            _write_tar_archive(
                markers_archive,
                {
                    "markers/fna/M1.fna": (
                        ">RS_GCF_000001\nATGCATGC\n"
                        ">RS_GCF_000002\nATGCATGC\n"
                    ),
                },
            )

            with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
                self.assertEqual(
                    main(
                        [
                            "tags",
                            "--taxonomy-file",
                            str(taxonomy_path),
                            "--output-prefix",
                            str(tag_output_prefix),
                            "--positions",
                            "2",
                            "--format",
                            "json",
                        ]
                    ),
                    0,
                )

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "targets",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--markers-archive",
                        str(markers_archive),
                        "--tag-design-prefix",
                        str(tag_output_prefix),
                        "--output-prefix",
                        str(target_output_prefix),
                        "--profile",
                        "strict",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["profile"], "strict")
            self.assertEqual(payload["top_markers_per_target"], 5)
            self.assertEqual(payload["sibling_penalty_weight"], 3.0)
            self.assertEqual(payload["global_penalty_weight"], 1.5)

    def test_targets_discover_can_promote_fallback_taxa(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            tag_output_prefix = Path(temp_dir) / "outputs" / "tag_design"
            target_output_prefix = Path(temp_dir) / "outputs" / "targets"
            markers_archive = Path(temp_dir) / "markers.tar.gz"
            taxonomy_path.write_text(
                "\n".join(
                    [
                        "RS_GCF_000001\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                        "RS_GCF_000002\td__Archaea;p__P2;c__C2;o__O2;f__F2;g__G2;s__S2",
                        "RS_GCF_000003\td__Archaea;p__P3;c__C3;o__O3;f__F3;g__G3;s__S3",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )
            _write_tar_archive(
                markers_archive,
                {
                    "markers/fna/M1.fna": (
                        ">RS_GCF_000002\nATGCATGC\n"
                        ">RS_GCF_000003\nATGCATGC\n"
                    ),
                },
            )

            with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
                tags_exit_code = main(
                    [
                        "tags",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--output-prefix",
                        str(tag_output_prefix),
                        "--levels",
                        "phylum",
                        "--positions",
                        "1",
                        "--alphabet",
                        "[0,1]",
                        "--fallbacks-per-target",
                        "1",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(tags_exit_code, 0)

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "targets",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--markers-archive",
                        str(markers_archive),
                        "--tag-design-prefix",
                        str(tag_output_prefix),
                        "--output-prefix",
                        str(target_output_prefix),
                        "--fallback-policy",
                        "no_marker_genomes",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["fallback_policy"], ["no_marker_genomes"])
            self.assertEqual(payload["promoted_targets"], 1)

            selected_rows = {row["barcode"]: row for row in payload["selected_targets"]}
            fallback_rows = [row for row in selected_rows.values() if row["selection_source"] == "fallback"]
            self.assertEqual(len(fallback_rows), 1)
            promoted = fallback_rows[0]
            self.assertEqual(promoted["primary_resolved_taxon"], "p__P1")
            self.assertEqual(promoted["resolved_taxon"], "p__P3")
            self.assertEqual(promoted["primary_status"], "no_marker_genomes")
            self.assertEqual(promoted["promotion_reason"], "no_marker_genomes")

    def test_targets_discover_can_infer_session_tag_prefix(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            markers_archive = Path(temp_dir) / "markers.tar.gz"
            output_dir = Path(temp_dir) / "runs"
            session_name = "archaea_demo"
            taxonomy_path.write_text(
                "\n".join(
                    [
                        "RS_GCF_000001\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                        "RS_GCF_000002\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G2;s__S2",
                        "RS_GCF_000003\td__Archaea;p__P2;c__C2;o__O2;f__F2;g__G3;s__S3",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )
            _write_tar_archive(
                markers_archive,
                {
                    "markers/fna/M1.fna": (
                        ">RS_GCF_000001\nATGCATGC\n"
                        ">RS_GCF_000002\nATGCATGC\n"
                    ),
                    "markers/fna/M2.fna": (
                        ">RS_GCF_000003\nATGCATGCATGC\n"
                    ),
                },
            )

            with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
                tags_exit_code = main(
                    [
                        "tags",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--output",
                        str(output_dir),
                        "--session",
                        session_name,
                        "--positions",
                        "2",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(tags_exit_code, 0)

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "targets",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--markers-archive",
                        str(markers_archive),
                        "--output",
                        str(output_dir),
                        "--session",
                        session_name,
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            expected_tag_prefix = _session_stage_prefix(output_dir, session_name, "tags").resolve()
            expected_target_prefix = _session_stage_prefix(output_dir, session_name, "targets")
            self.assertEqual(payload["tag_design_prefix"], str(expected_tag_prefix))
            self.assertTrue(_stage_artifact(expected_target_prefix, "targets", "summary.json").exists())
            self.assertTrue(_stage_artifact(expected_target_prefix, "targets", "top_marker_manifest.csv").exists())

    def test_targets_discover_can_use_explicit_input_attempt(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            markers_archive = Path(temp_dir) / "markers.tar.gz"
            output_dir = Path(temp_dir) / "runs"
            session_name = "archaea_demo"
            taxonomy_path.write_text(
                "\n".join(
                    [
                        "RS_GCF_000001\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                        "RS_GCF_000002\td__Archaea;p__P2;c__C2;o__O2;f__F2;g__G2;s__S2",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )
            _write_tar_archive(
                markers_archive,
                {
                    "individual/M1.fna": (
                        ">RS_GCF_000001\nAAAAAA\n"
                        ">RS_GCF_000002\nAAAACC\n"
                    ),
                },
            )

            for positions in ("1", "2"):
                with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
                    exit_code = main(
                        [
                            "tags",
                            "--taxonomy-file",
                            str(taxonomy_path),
                            "--output",
                            str(output_dir),
                            "--session",
                            session_name,
                            "--positions",
                            positions,
                            "--format",
                            "json",
                        ]
                    )
                self.assertEqual(exit_code, 0)

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "targets",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--markers-archive",
                        str(markers_archive),
                        "--output",
                        str(output_dir),
                        "--session",
                        session_name,
                        "--input-attempt",
                        "1",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            expected_tag_prefix = _session_stage_prefix(output_dir, session_name, "tags", "01").resolve()
            self.assertEqual(payload["tag_design_prefix"], str(expected_tag_prefix))

    def test_targets_discover_can_use_installed_dataset(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            home = Path(temp_dir) / "home"
            datasets_dir = Path(temp_dir) / "datasets-store"
            tag_output_prefix = Path(temp_dir) / "outputs" / "tag_design"
            target_output_prefix = Path(temp_dir) / "outputs" / "targets"
            paths = self._make_paths(temp_dir)
            self._populate_catalog_inputs(paths)
            catalog_path = Path(temp_dir) / "catalog.json"
            _write_catalog(catalog_path, paths)

            previous = None
            if APP_HOME_ENV in __import__("os").environ:
                previous = __import__("os").environ[APP_HOME_ENV]
            __import__("os").environ[APP_HOME_ENV] = str(home)
            try:
                with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
                    install_exit_code = main(
                        [
                            "datasets",
                                                        "--taxon",
                            "archaea",
                            "--catalog-file",
                            str(catalog_path),
                            "--datasets-dir",
                            str(datasets_dir),
                            "--format",
                            "json",
                        ]
                    )
                self.assertEqual(install_exit_code, 0)

                with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
                    tags_exit_code = main(
                        [
                            "tags",
                                                        "--dataset",
                            "archaea",
                            "--output-prefix",
                            str(tag_output_prefix),
                            "--positions",
                            "2",
                            "--format",
                            "json",
                        ]
                    )
                self.assertEqual(tags_exit_code, 0)

                stdout = io.StringIO()
                with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                    exit_code = main(
                        [
                            "targets",
                                                        "--dataset",
                            "archaea",
                            "--tag-design-prefix",
                            str(tag_output_prefix),
                            "--output-prefix",
                            str(target_output_prefix),
                            "--format",
                            "json",
                        ]
                    )
                self.assertEqual(exit_code, 0)
                payload = json.loads(stdout.getvalue())
                self.assertEqual(payload["dataset"], "archaea")
                self.assertEqual(payload["analyzed_markers"], 1)
                self.assertEqual(len(payload["selected_targets"]), 1)
                self.assertIn("candidate_markers", payload["selected_targets"][0])
                self.assertIn("total_mean_nt_length_retained_markers", payload["selected_targets"][0])
                self.assertTrue(_stage_artifact(target_output_prefix, "targets", "selected_targets.csv").exists())
            finally:
                if previous is None:
                    __import__("os").environ.pop(APP_HOME_ENV, None)
                else:
                    __import__("os").environ[APP_HOME_ENV] = previous

    def test_targets_discover_can_limit_taxonomic_scope(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            tag_output_prefix = Path(temp_dir) / "outputs" / "tag_design"
            target_output_prefix = Path(temp_dir) / "outputs" / "targets"
            markers_archive = Path(temp_dir) / "markers.tar.gz"
            taxonomy_path.write_text(
                "\n".join(
                    [
                        "RS_GCF_000001\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                        "RS_GCF_000004\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S4",
                        "RS_GCF_000002\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G2;s__S2",
                        "RS_GCF_000003\td__Archaea;p__P2;c__C2;o__O2;f__F2;g__G3;s__S3",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )
            _write_tar_archive(
                markers_archive,
                {
                    "markers/fna/M1.fna": (
                        ">RS_GCF_000001\nAAAAAA\n"
                        ">RS_GCF_000004\nAAAAAA\n"
                        ">RS_GCF_000002\nAAAACC\n"
                        ">RS_GCF_000003\nCCCCCC\n"
                    ),
                },
            )

            with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
                self.assertEqual(
                    main(
                        [
                            "tags",
                            "--taxonomy-file",
                            str(taxonomy_path),
                            "--output-prefix",
                            str(tag_output_prefix),
                            "--levels",
                            "genus",
                            "--positions",
                            "1",
                            "--alphabet",
                            "[0,1]",
                            "--format",
                            "json",
                        ]
                    ),
                    0,
                )

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "targets",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--markers-archive",
                        str(markers_archive),
                        "--tag-design-prefix",
                        str(tag_output_prefix),
                        "--output-prefix",
                        str(target_output_prefix),
                        "--include",
                        "family:f__F1",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["include_taxa"], {"family": ["f__F1"]})
            with _stage_artifact(target_output_prefix, "targets", "marker_scores.csv").open(
                "r", encoding="utf-8", newline=""
            ) as handle:
                marker_rows = [
                    row
                    for row in csv.DictReader(handle)
                    if row["resolved_taxon"] == "g__G1" and row["marker_id"] == "M1"
                ]
            self.assertEqual(len(marker_rows), 1)
            self.assertEqual(int(marker_rows[0]["global_non_target_marker_available_genomes"]), 1)

    def test_regions_discover_from_explicit_files_writes_outputs(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            markers_archive = Path(temp_dir) / "markers.tar.gz"
            msa_archive = Path(temp_dir) / "msa.tar.gz"
            tag_output_prefix = Path(temp_dir) / "outputs" / "tag_design"
            target_output_prefix = Path(temp_dir) / "outputs" / "targets"
            region_output_prefix = Path(temp_dir) / "outputs" / "regions"
            taxonomy_path.write_text(
                "\n".join(
                    [
                        "RS_GCF_000001\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                        "RS_GCF_000004\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S4",
                        "RS_GCF_000002\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G2;s__S2",
                        "RS_GCF_000003\td__Archaea;p__P2;c__C2;o__O2;f__F2;g__G3;s__S3",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )
            _write_tar_archive(
                markers_archive,
                {
                    "markers/fna/M1.fna": (
                        ">RS_GCF_000001\nATGCATGC\n"
                        ">RS_GCF_000004\nATGCATGC\n"
                        ">RS_GCF_000002\nATGCATGC\n"
                    ),
                    "markers/fna/M2.fna": (
                        ">RS_GCF_000003\nATGCATGCATGC\n"
                    ),
                },
            )
            _write_tar_archive(
                msa_archive,
                {
                    "individual/M1.faa": (
                        ">RS_GCF_000001\nAAACCCGG\n"
                        ">RS_GCF_000004\nAAACCCGG\n"
                        ">RS_GCF_000002\nTTTDDDGG\n"
                    ),
                    "individual/M2.faa": (
                        ">RS_GCF_000003\nGGGTTTAA\n"
                    ),
                },
            )

            with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
                tags_exit_code = main(
                    [
                        "tags",
                                                "--taxonomy-file",
                        str(taxonomy_path),
                        "--output-prefix",
                        str(tag_output_prefix),
                        "--positions",
                        "2",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(tags_exit_code, 0)

            with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
                targets_exit_code = main(
                    [
                        "targets",
                                                "--taxonomy-file",
                        str(taxonomy_path),
                        "--markers-archive",
                        str(markers_archive),
                        "--tag-design-prefix",
                        str(tag_output_prefix),
                        "--output-prefix",
                        str(target_output_prefix),
                        "--top-markers-per-target",
                        "2",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(targets_exit_code, 0)

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "regions",
                                                "--taxonomy-file",
                        str(taxonomy_path),
                        "--msa-archive",
                        str(msa_archive),
                        "--markers-archive",
                        str(markers_archive),
                        "--target-discovery-prefix",
                        str(target_output_prefix),
                        "--output-prefix",
                        str(region_output_prefix),
                        "--window-aa-length",
                        "3",
                        "--top-regions-per-marker",
                        "2",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["analyzed_markers"], 2)
            self.assertTrue(len(payload["selected_target_markers"]) >= 3)
            self.assertTrue(len(payload["target_region_summary"]) >= 1)
            self.assertIn("total_probeable_positions", payload["target_region_summary"][0])
            self.assertTrue(_stage_artifact(region_output_prefix, "regions", "summary.json").exists())
            self.assertTrue(_stage_artifact(region_output_prefix, "regions", "target_region_summary.csv").exists())
            self.assertTrue(_stage_artifact(region_output_prefix, "regions", "marker_region_summary.csv").exists())
            self.assertTrue(_stage_artifact(region_output_prefix, "regions", "region_candidates.csv").exists())

    def test_regions_discover_can_use_installed_dataset(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            home = Path(temp_dir) / "home"
            datasets_dir = Path(temp_dir) / "datasets-store"
            tag_output_prefix = Path(temp_dir) / "outputs" / "tag_design"
            target_output_prefix = Path(temp_dir) / "outputs" / "targets"
            region_output_prefix = Path(temp_dir) / "outputs" / "regions"
            paths = self._make_paths(temp_dir)
            self._populate_catalog_inputs(paths)
            catalog_path = Path(temp_dir) / "catalog.json"
            _write_catalog(catalog_path, paths)

            previous = None
            if APP_HOME_ENV in __import__("os").environ:
                previous = __import__("os").environ[APP_HOME_ENV]
            __import__("os").environ[APP_HOME_ENV] = str(home)
            try:
                with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
                    install_exit_code = main(
                        [
                            "datasets",
                                                        "--taxon",
                            "archaea",
                            "--catalog-file",
                            str(catalog_path),
                            "--datasets-dir",
                            str(datasets_dir),
                            "--format",
                            "json",
                        ]
                    )
                self.assertEqual(install_exit_code, 0)

                with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
                    tags_exit_code = main(
                        [
                            "tags",
                                                        "--dataset",
                            "archaea",
                            "--output-prefix",
                            str(tag_output_prefix),
                            "--positions",
                            "2",
                            "--format",
                            "json",
                        ]
                    )
                self.assertEqual(tags_exit_code, 0)

                with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
                    targets_exit_code = main(
                        [
                            "targets",
                                                        "--dataset",
                            "archaea",
                            "--tag-design-prefix",
                            str(tag_output_prefix),
                            "--output-prefix",
                            str(target_output_prefix),
                            "--format",
                            "json",
                        ]
                    )
                self.assertEqual(targets_exit_code, 0)

                stdout = io.StringIO()
                with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                    exit_code = main(
                        [
                            "regions",
                                                        "--dataset",
                            "archaea",
                            "--target-discovery-prefix",
                            str(target_output_prefix),
                            "--output-prefix",
                            str(region_output_prefix),
                            "--window-aa-length",
                            "2",
                            "--format",
                            "json",
                        ]
                    )
                self.assertEqual(exit_code, 0)
                payload = json.loads(stdout.getvalue())
                self.assertEqual(payload["dataset"], "archaea")
                self.assertEqual(payload["analyzed_markers"], 1)
                self.assertTrue(_stage_artifact(region_output_prefix, "regions", "selected_target_markers.csv").exists())
            finally:
                if previous is None:
                    __import__("os").environ.pop(APP_HOME_ENV, None)
                else:
                    __import__("os").environ[APP_HOME_ENV] = previous

    def test_regions_discover_can_limit_taxonomic_scope(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            msa_archive = Path(temp_dir) / "msa.tar.gz"
            markers_archive = Path(temp_dir) / "markers.tar.gz"
            tag_output_prefix = Path(temp_dir) / "outputs" / "tag_design"
            target_output_prefix = Path(temp_dir) / "outputs" / "targets"
            region_output_prefix = Path(temp_dir) / "outputs" / "regions"
            taxonomy_path.write_text(
                "\n".join(
                    [
                        "RS_GCF_000001\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                        "RS_GCF_000004\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S4",
                        "RS_GCF_000002\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G2;s__S2",
                        "RS_GCF_000003\td__Archaea;p__P2;c__C2;o__O2;f__F2;g__G3;s__S3",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )
            _write_tar_archive(
                msa_archive,
                {
                    "individual/M1.faa": (
                        ">RS_GCF_000001\nAAA\n"
                        ">RS_GCF_000004\nAAA\n"
                        ">RS_GCF_000002\nAAT\n"
                        ">RS_GCF_000003\nCCC\n"
                    ),
                },
            )
            _write_tar_archive(
                markers_archive,
                {
                    "markers/fna/M1.fna": (
                        ">RS_GCF_000001\nGCTGCTGCT\n"
                        ">RS_GCF_000004\nGCTGCTGCT\n"
                        ">RS_GCF_000002\nGCTGCTACT\n"
                        ">RS_GCF_000003\nTGTTGTTGT\n"
                    ),
                },
            )
            _write_target_discovery_fixture(
                tag_output_prefix,
                target_output_prefix,
                barcode="AT",
                resolved_level="genus",
                resolved_taxon="g__G1",
                marker_id="M1",
                lineage={
                    "domain": "d__Archaea",
                    "phylum": "p__P1",
                    "class": "c__C1",
                    "order": "o__O1",
                    "family": "f__F1",
                    "genus": "g__G1",
                    "species": None,
                },
                parent_level="family",
                parent_taxon="f__F1",
            )

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "regions",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--msa-archive",
                        str(msa_archive),
                        "--markers-archive",
                        str(markers_archive),
                        "--target-discovery-prefix",
                        str(target_output_prefix),
                        "--output-prefix",
                        str(region_output_prefix),
                        "--window-aa-length",
                        "3",
                        "--region-probe-length",
                        "6",
                        "--include",
                        "family:f__F1",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["include_taxa"], {"family": ["f__F1"]})
            with _stage_artifact(region_output_prefix, "regions", "region_candidates.csv").open(
                "r", encoding="utf-8", newline=""
            ) as handle:
                region_rows = list(csv.DictReader(handle))
            self.assertTrue(region_rows)
            self.assertEqual(int(region_rows[0]["global_offtarget_alignment_sequences"]), 1)

    def test_regions_discover_can_score_mismatch_tolerant_aa_windows(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            msa_archive = Path(temp_dir) / "msa.tar.gz"
            markers_archive = Path(temp_dir) / "markers.tar.gz"
            tag_output_prefix = Path(temp_dir) / "outputs" / "tag_design"
            target_output_prefix = Path(temp_dir) / "outputs" / "targets"
            region_output_prefix = Path(temp_dir) / "outputs" / "regions"
            taxonomy_path.write_text(
                "\n".join(
                    [
                        "RS_GCF_000001\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                        "RS_GCF_000004\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S4",
                        "RS_GCF_000002\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G2;s__S2",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )
            _write_tar_archive(
                msa_archive,
                {
                    "individual/M1.faa": (
                        ">RS_GCF_000001\nAAACCC\n"
                        ">RS_GCF_000004\nAATCCC\n"
                        ">RS_GCF_000002\nAAGCCC\n"
                    ),
                },
            )
            _write_tar_archive(
                markers_archive,
                {
                    "markers/fna/M1.fna": (
                        ">RS_GCF_000001\nGCTGCTGCTTGTTGTTGT\n"
                        ">RS_GCF_000004\nGCTGCTACTTGTTGTTGT\n"
                        ">RS_GCF_000002\nGCTGCTGGTTGTTGTTGT\n"
                    ),
                },
            )
            _write_target_discovery_fixture(
                tag_output_prefix,
                target_output_prefix,
                barcode="AT",
                resolved_level="genus",
                resolved_taxon="g__G1",
                marker_id="M1",
                lineage={
                    "domain": "d__Archaea",
                    "phylum": "p__P1",
                    "class": "c__C1",
                    "order": "o__O1",
                    "family": "f__F1",
                    "genus": "g__G1",
                    "species": None,
                },
                parent_level="family",
                parent_taxon="f__F1",
            )

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "regions",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--msa-archive",
                        str(msa_archive),
                        "--markers-archive",
                        str(markers_archive),
                        "--target-discovery-prefix",
                        str(target_output_prefix),
                        "--output-prefix",
                        str(region_output_prefix),
                        "--window-aa-length",
                        "3",
                        "--min-target-consensus",
                        "0.5",
                        "--max-aa-mismatches",
                        "1",
                        "--aa-mismatch-penalty-per-mismatch",
                        "0.25",
                        "--region-probe-length",
                        "6",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["max_aa_mismatches"], 1)
            self.assertEqual(payload["aa_mismatch_penalty_per_mismatch"], 0.25)

            with _stage_artifact(region_output_prefix, "regions", "region_candidates.csv").open(
                "r", encoding="utf-8", newline=""
            ) as handle:
                rows = list(csv.DictReader(handle))
            self.assertGreaterEqual(len(rows), 1)
            mismatch_rows = [
                row for row in rows if int(row["target_near_match_sequences"]) == 1
            ]
            self.assertGreaterEqual(len(mismatch_rows), 1)
            first = mismatch_rows[0]
            self.assertAlmostEqual(float(first["target_effective_match_fraction"]), 0.875)
            self.assertEqual(int(first["sibling_near_match_sequences"]), 1)
            self.assertAlmostEqual(float(first["sibling_effective_match_fraction"]), 0.75)
            self.assertEqual(int(first["global_near_match_sequences"]), 1)
            self.assertAlmostEqual(float(first["global_effective_match_fraction"]), 0.75)

    def test_regions_discover_can_filter_by_target_window_presence(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            msa_archive = Path(temp_dir) / "msa.tar.gz"
            markers_archive = Path(temp_dir) / "markers.tar.gz"
            tag_output_prefix = Path(temp_dir) / "outputs" / "tag_design"
            target_output_prefix = Path(temp_dir) / "outputs" / "targets"
            region_output_prefix = Path(temp_dir) / "outputs" / "regions"
            taxonomy_path.write_text(
                "\n".join(
                    [
                        "RS_GCF_000001\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                        "RS_GCF_000004\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S4",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )
            _write_tar_archive(
                msa_archive,
                {
                    "individual/M1.faa": (
                        ">RS_GCF_000001\nAAAT\n"
                        ">RS_GCF_000004\nA-AT\n"
                    ),
                },
            )
            _write_tar_archive(
                markers_archive,
                {
                    "markers/fna/M1.fna": (
                        ">RS_GCF_000001\nGCTGCTGCTACT\n"
                        ">RS_GCF_000004\nGCTACT\n"
                    ),
                },
            )
            _write_target_discovery_fixture(
                tag_output_prefix,
                target_output_prefix,
                barcode="AT",
                resolved_level="genus",
                resolved_taxon="g__G1",
                marker_id="M1",
                lineage={
                    "domain": "d__Archaea",
                    "phylum": "p__P1",
                    "class": "c__C1",
                    "order": "o__O1",
                    "family": "f__F1",
                    "genus": "g__G1",
                    "species": None,
                },
                parent_level="family",
                parent_taxon="f__F1",
            )

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "regions",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--msa-archive",
                        str(msa_archive),
                        "--markers-archive",
                        str(markers_archive),
                        "--target-discovery-prefix",
                        str(target_output_prefix),
                        "--output-prefix",
                        str(region_output_prefix),
                        "--window-aa-length",
                        "4",
                        "--min-target-column-occupancy",
                        "0.5",
                        "--min-target-consensus",
                        "1.0",
                        "--min-target-window-presence",
                        "0.75",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["min_target_window_presence"], 0.75)

            with _stage_artifact(region_output_prefix, "regions", "selected_target_markers.csv").open(
                "r", encoding="utf-8", newline=""
            ) as handle:
                rows = list(csv.DictReader(handle))
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0]["status"], "no_passing_windows")
            self.assertEqual(rows[0]["selected_regions"], "0")

    def test_regions_discover_can_score_probeability_from_marker_windows(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            msa_archive = Path(temp_dir) / "msa.tar.gz"
            markers_archive = Path(temp_dir) / "markers.tar.gz"
            tag_output_prefix = Path(temp_dir) / "outputs" / "tag_design"
            target_output_prefix = Path(temp_dir) / "outputs" / "targets"
            region_output_prefix = Path(temp_dir) / "outputs" / "regions"
            taxonomy_path.write_text(
                "\n".join(
                    [
                        "RS_GCF_000001\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                        "RS_GCF_000004\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S4",
                        "RS_GCF_000002\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G2;s__S2",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )
            _write_tar_archive(
                msa_archive,
                {
                    "individual/M1.faa": (
                        ">RS_GCF_000001\nAAAA\n"
                        ">RS_GCF_000004\nAAAA\n"
                        ">RS_GCF_000002\nTTTT\n"
                    ),
                },
            )
            _write_tar_archive(
                markers_archive,
                {
                    "markers/fna/M1.fna": (
                        ">RS_GCF_000001\nGCTGCTGCTGCT\n"
                        ">RS_GCF_000004\nGCCGCCGCCGCC\n"
                        ">RS_GCF_000002\nACTACTACTACT\n"
                    ),
                },
            )
            _write_target_discovery_fixture(
                tag_output_prefix,
                target_output_prefix,
                barcode="AT",
                resolved_level="genus",
                resolved_taxon="g__G1",
                marker_id="M1",
                lineage={
                    "domain": "d__Archaea",
                    "phylum": "p__P1",
                    "class": "c__C1",
                    "order": "o__O1",
                    "family": "f__F1",
                    "genus": "g__G1",
                    "species": None,
                },
                parent_level="family",
                parent_taxon="f__F1",
            )

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "regions",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--msa-archive",
                        str(msa_archive),
                        "--markers-archive",
                        str(markers_archive),
                        "--target-discovery-prefix",
                        str(target_output_prefix),
                        "--output-prefix",
                        str(region_output_prefix),
                        "--window-aa-length",
                        "4",
                        "--region-probe-length",
                        "6",
                        "--probeability-weight",
                        "1.0",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["region_probe_length"], 6)
            self.assertEqual(payload["probeability_weight"], 1.0)

            with _stage_artifact(region_output_prefix, "regions", "region_candidates.csv").open(
                "r", encoding="utf-8", newline=""
            ) as handle:
                rows = list(csv.DictReader(handle))
            self.assertEqual(len(rows), 1)
            first = rows[0]
            self.assertEqual(int(first["target_remapped_sequences"]), 2)
            self.assertAlmostEqual(float(first["target_remap_fraction"]), 1.0)
            self.assertEqual(int(first["probeable_positions"]), 7)
            self.assertAlmostEqual(float(first["probeable_positions_fraction"]), 1.0)
            self.assertAlmostEqual(float(first["best_probe_support_fraction"]), 0.5)
            self.assertEqual(first["best_probe_consensus_sequence"], "GCCGCC")
            self.assertAlmostEqual(float(first["probeability_score"]), (1.0 + 1.0 + 0.5) / 3.0)

    def test_regions_discover_can_filter_by_best_probe_support_fraction(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            msa_archive = Path(temp_dir) / "msa.tar.gz"
            markers_archive = Path(temp_dir) / "markers.tar.gz"
            tag_output_prefix = Path(temp_dir) / "outputs" / "tag_design"
            target_output_prefix = Path(temp_dir) / "outputs" / "targets"
            region_output_prefix = Path(temp_dir) / "outputs" / "regions"
            taxonomy_path.write_text(
                "\n".join(
                    [
                        "RS_GCF_000001\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                        "RS_GCF_000004\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S4",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )
            _write_tar_archive(
                msa_archive,
                {
                    "individual/M1.faa": (
                        ">RS_GCF_000001\nAAAA\n"
                        ">RS_GCF_000004\nAAAA\n"
                    ),
                },
            )
            _write_tar_archive(
                markers_archive,
                {
                    "markers/fna/M1.fna": (
                        ">RS_GCF_000001\nGCTGCTGCTGCT\n"
                        ">RS_GCF_000004\nGCCGCCGCCGCC\n"
                    ),
                },
            )
            _write_target_discovery_fixture(
                tag_output_prefix,
                target_output_prefix,
                barcode="AT",
                resolved_level="genus",
                resolved_taxon="g__G1",
                marker_id="M1",
                lineage={
                    "domain": "d__Archaea",
                    "phylum": "p__P1",
                    "class": "c__C1",
                    "order": "o__O1",
                    "family": "f__F1",
                    "genus": "g__G1",
                    "species": None,
                },
                parent_level="family",
                parent_taxon="f__F1",
            )

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "regions",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--msa-archive",
                        str(msa_archive),
                        "--markers-archive",
                        str(markers_archive),
                        "--target-discovery-prefix",
                        str(target_output_prefix),
                        "--output-prefix",
                        str(region_output_prefix),
                        "--window-aa-length",
                        "4",
                        "--region-probe-length",
                        "6",
                        "--min-best-probe-support-fraction",
                        "0.75",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["min_best_probe_support_fraction"], 0.75)

            with _stage_artifact(region_output_prefix, "regions", "selected_target_markers.csv").open(
                "r", encoding="utf-8", newline=""
            ) as handle:
                rows = list(csv.DictReader(handle))
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0]["status"], "no_passing_windows")

    def test_regions_discover_can_use_adaptive_window_lengths(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            msa_archive = Path(temp_dir) / "msa.tar.gz"
            markers_archive = Path(temp_dir) / "markers.tar.gz"
            tag_output_prefix = Path(temp_dir) / "outputs" / "tag_design"
            target_output_prefix = Path(temp_dir) / "outputs" / "targets"
            region_output_prefix = Path(temp_dir) / "outputs" / "regions"
            taxonomy_path.write_text(
                "\n".join(
                    [
                        "RS_GCF_000001\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                        "RS_GCF_000004\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S4",
                        "RS_GCF_000002\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G2;s__S2",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )
            _write_tar_archive(
                msa_archive,
                {
                    "individual/M1.faa": (
                        ">RS_GCF_000001\nAAAATTTT\n"
                        ">RS_GCF_000004\nAAAATTTT\n"
                        ">RS_GCF_000002\nAAAAGGGG\n"
                    ),
                },
            )
            _write_tar_archive(
                markers_archive,
                {
                    "markers/fna/M1.fna": (
                        ">RS_GCF_000001\nGCTGCTGCTGCTACTACTACTACT\n"
                        ">RS_GCF_000004\nGCTGCTGCTGCTACTACTACTACT\n"
                        ">RS_GCF_000002\nGCTGCTGCTGCTGGTGGTGGTGGT\n"
                    ),
                },
            )
            _write_target_discovery_fixture(
                tag_output_prefix,
                target_output_prefix,
                barcode="AT",
                resolved_level="genus",
                resolved_taxon="g__G1",
                marker_id="M1",
                lineage={
                    "domain": "d__Archaea",
                    "phylum": "p__P1",
                    "class": "c__C1",
                    "order": "o__O1",
                    "family": "f__F1",
                    "genus": "g__G1",
                    "species": None,
                },
                parent_level="family",
                parent_taxon="f__F1",
            )

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "regions",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--msa-archive",
                        str(msa_archive),
                        "--markers-archive",
                        str(markers_archive),
                        "--target-discovery-prefix",
                        str(target_output_prefix),
                        "--output-prefix",
                        str(region_output_prefix),
                        "--window-aa-length",
                        "3",
                        "--window-aa-length-min",
                        "2",
                        "--window-aa-length-max",
                        "4",
                        "--region-probe-length",
                        "6",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["window_aa_length_min"], 2)
            self.assertEqual(payload["window_aa_length_max"], 4)

            with _stage_artifact(region_output_prefix, "regions", "region_candidates.csv").open(
                "r", encoding="utf-8", newline=""
            ) as handle:
                rows = list(csv.DictReader(handle))
            self.assertGreaterEqual(len(rows), 1)
            self.assertEqual(rows[0]["window_aa_length"], "4")
            self.assertTrue(any(row["window_aa_length"] == "4" for row in rows))

    def test_regions_discover_can_apply_discovery_profile_with_overrides(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            msa_archive = Path(temp_dir) / "msa.tar.gz"
            markers_archive = Path(temp_dir) / "markers.tar.gz"
            tag_output_prefix = Path(temp_dir) / "outputs" / "tag_design"
            target_output_prefix = Path(temp_dir) / "outputs" / "targets"
            region_output_prefix = Path(temp_dir) / "outputs" / "regions"
            taxonomy_path.write_text(
                "\n".join(
                    [
                        "RS_GCF_000001\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                        "RS_GCF_000004\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S4",
                        "RS_GCF_000002\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G2;s__S2",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )
            _write_tar_archive(
                msa_archive,
                {
                    "individual/M1.faa": (
                        ">RS_GCF_000001\nAAAAAAAAAAAAAAAAAA\n"
                        ">RS_GCF_000004\nAAAAAAAAAAAAAAAATA\n"
                        ">RS_GCF_000002\nCCCCCCCCCCCCCCCCCC\n"
                    ),
                },
            )
            _write_tar_archive(
                markers_archive,
                {
                    "markers/fna/M1.fna": (
                        ">RS_GCF_000001\nGCTGCTGCTGCTGCTGCTGCTGCTGCTGCTGCTGCTGCTGCTGCTGCTGCTGCT\n"
                        ">RS_GCF_000004\nGCTGCTGCTGCTGCTGCTGCTGCTGCTGCTGCTGCTGCTGCTGCTACTGCTGCT\n"
                        ">RS_GCF_000002\nTGTTGTTGTTGTTGTTGTTGTTGTTGTTGTTGTTGTTGTTGTTGTTGTTGTTGT\n"
                    ),
                },
            )
            _write_target_discovery_fixture(
                tag_output_prefix,
                target_output_prefix,
                barcode="AT",
                resolved_level="genus",
                resolved_taxon="g__G1",
                marker_id="M1",
                lineage={
                    "domain": "d__Archaea",
                    "phylum": "p__P1",
                    "class": "c__C1",
                    "order": "o__O1",
                    "family": "f__F1",
                    "genus": "g__G1",
                    "species": None,
                },
                parent_level="family",
                parent_taxon="f__F1",
            )

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "regions",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--msa-archive",
                        str(msa_archive),
                        "--markers-archive",
                        str(markers_archive),
                        "--target-discovery-prefix",
                        str(target_output_prefix),
                        "--output-prefix",
                        str(region_output_prefix),
                        "--profile",
                        "strict",
                        "--top-regions-per-marker",
                        "4",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["profile"], "strict")
            self.assertEqual(payload["window_aa_length_min"], 12)
            self.assertEqual(payload["window_aa_length_max"], 18)
            self.assertEqual(payload["top_regions_per_marker"], 4)
            self.assertEqual(payload["min_target_window_presence"], 0.85)
            self.assertEqual(payload["max_aa_mismatches"], 0)
            self.assertEqual(payload["min_target_remap_fraction"], 0.7)
            self.assertEqual(payload["min_best_probe_support_fraction"], 0.7)
            self.assertEqual(payload["probeability_weight"], 0.75)

    def test_regions_discover_defaults_to_adaptive_stricter_mode(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            msa_archive = Path(temp_dir) / "msa.tar.gz"
            markers_archive = Path(temp_dir) / "markers.tar.gz"
            tag_output_prefix = Path(temp_dir) / "outputs" / "tag_design"
            target_output_prefix = Path(temp_dir) / "outputs" / "targets"
            region_output_prefix = Path(temp_dir) / "outputs" / "regions"
            taxonomy_path.write_text(
                "\n".join(
                    [
                        "RS_GCF_000001\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                        "RS_GCF_000004\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S4",
                        "RS_GCF_000002\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G2;s__S2",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )
            _write_tar_archive(
                msa_archive,
                {
                    "individual/M1.faa": (
                        ">RS_GCF_000001\nAAAAAAAAAAAAAAAAAA\n"
                        ">RS_GCF_000004\nAAAAAAAAAAAAAAAATA\n"
                        ">RS_GCF_000002\nCCCCCCCCCCCCCCCCCC\n"
                    ),
                },
            )
            _write_tar_archive(
                markers_archive,
                {
                    "markers/fna/M1.fna": (
                        ">RS_GCF_000001\nGCTGCTGCTGCTGCTGCTGCTGCTGCTGCTGCTGCTGCTGCTGCTGCTGCTGCT\n"
                        ">RS_GCF_000004\nGCTGCTGCTGCTGCTGCTGCTGCTGCTGCTGCTGCTGCTGCTGCTACTGCTGCT\n"
                        ">RS_GCF_000002\nTGTTGTTGTTGTTGTTGTTGTTGTTGTTGTTGTTGTTGTTGTTGTTGTTGTTGT\n"
                    ),
                },
            )
            _write_target_discovery_fixture(
                tag_output_prefix,
                target_output_prefix,
                barcode="AT",
                resolved_level="genus",
                resolved_taxon="g__G1",
                marker_id="M1",
                lineage={
                    "domain": "d__Archaea",
                    "phylum": "p__P1",
                    "class": "c__C1",
                    "order": "o__O1",
                    "family": "f__F1",
                    "genus": "g__G1",
                    "species": None,
                },
                parent_level="family",
                parent_taxon="f__F1",
            )

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "regions",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--msa-archive",
                        str(msa_archive),
                        "--markers-archive",
                        str(markers_archive),
                        "--target-discovery-prefix",
                        str(target_output_prefix),
                        "--output-prefix",
                        str(region_output_prefix),
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["window_aa_length_min"], 10)
            self.assertEqual(payload["window_aa_length_max"], 16)
            self.assertEqual(payload["max_aa_mismatches"], 1)
            self.assertEqual(payload["min_target_window_presence"], 0.75)
            self.assertEqual(payload["min_target_remap_fraction"], 0.5)
            self.assertEqual(payload["min_best_probe_support_fraction"], 0.5)
            self.assertTrue(any(row["status"] == "ready" for row in payload["target_region_summary"]))

    def test_probes_design_from_explicit_files_writes_outputs(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            markers_archive = Path(temp_dir) / "markers.tar.gz"
            msa_archive = Path(temp_dir) / "msa.tar.gz"
            tag_output_prefix = Path(temp_dir) / "outputs" / "tag_design"
            target_output_prefix = Path(temp_dir) / "outputs" / "targets"
            region_output_prefix = Path(temp_dir) / "outputs" / "regions"
            probe_output_prefix = Path(temp_dir) / "outputs" / "probes"
            taxonomy_path.write_text(
                "\n".join(
                    [
                        "RS_GCF_000001\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                        "RS_GCF_000004\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S4",
                        "RS_GCF_000002\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G2;s__S2",
                        "RS_GCF_000003\td__Archaea;p__P2;c__C2;o__O2;f__F2;g__G3;s__S3",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )
            _write_tar_archive(
                markers_archive,
                {
                    "markers/fna/M1.fna": (
                        ">RS_GCF_000001\nGCCGCCGCCGCCGCCGCC\n"
                        ">RS_GCF_000004\nGCCGCCGCCGCCGCCGCC\n"
                        ">RS_GCF_000002\nACTACTACTGATGATGAT\n"
                    ),
                    "markers/fna/M2.fna": (
                        ">RS_GCF_000003\nGGTGGTGGTACTACTACT\n"
                    ),
                },
            )
            _write_tar_archive(
                msa_archive,
                {
                    "individual/M1.faa": (
                        ">RS_GCF_000001\nAAACCC\n"
                        ">RS_GCF_000004\nAAACCC\n"
                        ">RS_GCF_000002\nTTTDDD\n"
                    ),
                    "individual/M2.faa": (
                        ">RS_GCF_000003\nGGGTTT\n"
                    ),
                },
            )

            with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
                self.assertEqual(
                    main(
                        [
                            "tags",
                                                        "--taxonomy-file",
                            str(taxonomy_path),
                            "--output-prefix",
                            str(tag_output_prefix),
                            "--positions",
                            "2",
                            "--format",
                            "json",
                        ]
                    ),
                    0,
                )
                self.assertEqual(
                    main(
                        [
                            "targets",
                                                        "--taxonomy-file",
                            str(taxonomy_path),
                            "--markers-archive",
                            str(markers_archive),
                            "--tag-design-prefix",
                            str(tag_output_prefix),
                            "--output-prefix",
                            str(target_output_prefix),
                            "--top-markers-per-target",
                            "2",
                            "--workers",
                            "2",
                            "--format",
                            "json",
                        ]
                    ),
                    0,
                )
                self.assertEqual(
                    main(
                        [
                            "regions",
                                                        "--taxonomy-file",
                            str(taxonomy_path),
                            "--msa-archive",
                            str(msa_archive),
                            "--markers-archive",
                            str(markers_archive),
                            "--target-discovery-prefix",
                            str(target_output_prefix),
                            "--output-prefix",
                            str(region_output_prefix),
                            "--window-aa-length",
                            "3",
                            "--top-regions-per-marker",
                            "2",
                            "--region-probe-length",
                            "6",
                            "--workers",
                            "2",
                            "--format",
                            "json",
                        ]
                    ),
                    0,
                )

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "probes",
                                                "--taxonomy-file",
                        str(taxonomy_path),
                        "--markers-archive",
                        str(markers_archive),
                        "--region-discovery-prefix",
                        str(region_output_prefix),
                        "--output-prefix",
                        str(probe_output_prefix),
                        "--probe-length",
                        "6",
                        "--top-probes-per-region",
                        "1",
                        "--min-gc",
                        "0",
                        "--max-gc",
                        "1",
                        "--min-tm",
                        "-100",
                        "--max-tm",
                        "200",
                        "--profile",
                        "balanced",
                        "--max-dinucleotide-run",
                        "4",
                        "--min-sequence-entropy",
                        "0.0",
                        "--thermo-penalty-weight",
                        "0.2",
                        "--region-score-weight",
                        "0.25",
                        "--sibling-penalty-weight",
                        "1.5",
                        "--global-penalty-weight",
                        "0.5",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["probe_length"], 6)
            self.assertEqual(payload["profile"], "balanced")
            self.assertEqual(payload["thermo_backend"], "basic")
            self.assertEqual(payload["max_dinucleotide_run"], 4)
            self.assertEqual(payload["thermo_penalty_weight"], 0.2)
            self.assertTrue(len(payload["selected_regions"]) >= 1)
            self.assertTrue(len(payload["target_probe_summary"]) >= 1)
            self.assertIn("selected_probes_total", payload["target_probe_summary"][0])
            self.assertTrue(any(int(row["candidate_probes"]) >= int(row["selected_probes"]) for row in payload["selected_regions"]))
            self.assertTrue(_stage_artifact(probe_output_prefix, "probes", "summary.json").exists())
            self.assertTrue(_stage_artifact(probe_output_prefix, "probes", "target_probe_summary.csv").exists())
            self.assertTrue(_stage_artifact(probe_output_prefix, "probes", "probe_candidates.csv").exists())
            self.assertTrue(_stage_artifact(probe_output_prefix, "probes", "top_probe_manifest.csv").exists())
            import csv

            with _stage_artifact(probe_output_prefix, "probes", "probe_candidates.csv").open("r", encoding="utf-8", newline="") as handle:
                reader = csv.DictReader(handle)
                self.assertIsNotNone(reader.fieldnames)
                for expected in (
                    "tm_selected",
                    "tm_model",
                    "sequence_entropy",
                    "max_dinucleotide_run",
                    "self_complementarity",
                    "contiguous_self_complementarity",
                    "thermo_penalty",
                ):
                    self.assertIn(expected, reader.fieldnames)

    def test_probes_design_can_use_installed_dataset(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            home = Path(temp_dir) / "home"
            datasets_dir = Path(temp_dir) / "datasets-store"
            tag_output_prefix = Path(temp_dir) / "outputs" / "tag_design"
            target_output_prefix = Path(temp_dir) / "outputs" / "targets"
            region_output_prefix = Path(temp_dir) / "outputs" / "regions"
            probe_output_prefix = Path(temp_dir) / "outputs" / "probes"
            taxonomy_path = Path(temp_dir) / "archaea.tsv"
            markers_path = Path(temp_dir) / "archaea_markers.tar.gz"
            msa_path = Path(temp_dir) / "archaea_msa.tar.gz"
            bacteria_taxonomy = Path(temp_dir) / "bacteria.tsv"
            bacteria_markers = Path(temp_dir) / "bacteria_markers.tar.gz"
            bacteria_msa = Path(temp_dir) / "bacteria_msa.tar.gz"
            taxonomy_path.write_text(
                "RS_GCF_000001\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1\n",
                encoding="utf-8",
            )
            _write_tar_archive(
                markers_path,
                {
                    "individual/M1.fna": ">RS_GCF_000001\nGCCGCCGCCGCC\n",
                },
            )
            _write_tar_archive(
                msa_path,
                {
                    "individual/M1.faa": ">RS_GCF_000001\nAAAA\n",
                },
            )
            bacteria_taxonomy.write_text(
                "RS_GCF_000010\td__Bacteria;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1\n",
                encoding="utf-8",
            )
            _write_tar_archive(
                bacteria_markers,
                {
                    "individual/M1.fna": ">RS_GCF_000010\nGCCGCCGCCGCC\n",
                },
            )
            _write_tar_archive(
                bacteria_msa,
                {
                    "individual/M1.faa": ">RS_GCF_000010\nAAAA\n",
                },
            )
            catalog_path = Path(temp_dir) / "catalog.json"
            _write_catalog(
                catalog_path,
                {
                    "archaea_taxonomy": taxonomy_path,
                    "archaea_msa": msa_path,
                    "archaea_markers": markers_path,
                    "bacteria_taxonomy": bacteria_taxonomy,
                    "bacteria_msa": bacteria_msa,
                    "bacteria_markers": bacteria_markers,
                },
            )

            previous = None
            if APP_HOME_ENV in __import__("os").environ:
                previous = __import__("os").environ[APP_HOME_ENV]
            __import__("os").environ[APP_HOME_ENV] = str(home)
            try:
                with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
                    self.assertEqual(
                        main(
                            [
                                "datasets",
                                                                "--taxon",
                                "archaea",
                                "--catalog-file",
                                str(catalog_path),
                                "--datasets-dir",
                                str(datasets_dir),
                                "--format",
                                "json",
                            ]
                        ),
                        0,
                    )
                    self.assertEqual(
                        main(
                            [
                                "tags",
                                                                "--dataset",
                                "archaea",
                                "--output-prefix",
                                str(tag_output_prefix),
                                "--positions",
                                "2",
                                "--format",
                                "json",
                            ]
                        ),
                        0,
                    )
                    self.assertEqual(
                        main(
                            [
                                "targets",
                                                                "--dataset",
                                "archaea",
                                "--tag-design-prefix",
                                str(tag_output_prefix),
                                "--output-prefix",
                                str(target_output_prefix),
                                "--format",
                                "json",
                            ]
                        ),
                        0,
                    )
                    self.assertEqual(
                        main(
                            [
                                "regions",
                                                                "--dataset",
                                "archaea",
                                "--target-discovery-prefix",
                                str(target_output_prefix),
                                "--output-prefix",
                                str(region_output_prefix),
                                "--window-aa-length",
                                "2",
                                "--region-probe-length",
                                "6",
                                "--format",
                                "json",
                            ]
                        ),
                        0,
                    )

                stdout = io.StringIO()
                with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                    exit_code = main(
                        [
                            "probes",
                                                        "--dataset",
                            "archaea",
                            "--region-discovery-prefix",
                            str(region_output_prefix),
                            "--output-prefix",
                            str(probe_output_prefix),
                            "--probe-length",
                            "6",
                            "--min-gc",
                            "0",
                            "--max-gc",
                            "1",
                            "--min-tm",
                            "-100",
                            "--max-tm",
                            "200",
                            "--format",
                            "json",
                        ]
                    )
                self.assertEqual(exit_code, 0)
                payload = json.loads(stdout.getvalue())
                self.assertEqual(payload["dataset"], "archaea")
                self.assertEqual(payload["probe_length"], 6)
                self.assertTrue(_stage_artifact(probe_output_prefix, "probes", "selected_regions.csv").exists())
            finally:
                if previous is None:
                    __import__("os").environ.pop(APP_HOME_ENV, None)
                else:
                    __import__("os").environ[APP_HOME_ENV] = previous

    def test_probes_design_can_limit_taxonomic_scope(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            markers_archive = Path(temp_dir) / "markers.tar.gz"
            tag_output_prefix = Path(temp_dir) / "outputs" / "tags"
            target_output_prefix = Path(temp_dir) / "outputs" / "targets"
            region_output_prefix = Path(temp_dir) / "outputs" / "regions"
            probe_output_prefix = Path(temp_dir) / "outputs" / "probes"
            taxonomy_path.write_text(
                "\n".join(
                    [
                        "RS_GCF_000001\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                        "RS_GCF_000004\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S4",
                        "RS_GCF_000002\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G2;s__S2",
                        "RS_GCF_000003\td__Archaea;p__P2;c__C2;o__O2;f__F2;g__G3;s__S3",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )
            _write_tar_archive(
                markers_archive,
                {
                    "markers/fna/M1.fna": (
                        ">RS_GCF_000001\nAAGCAATC\n"
                        ">RS_GCF_000004\nAAGCAATC\n"
                        ">RS_GCF_000002\nAAGCATTC\n"
                        ">RS_GCF_000003\nCCCCCC\n"
                    ),
                },
            )
            _write_region_design_fixture(
                tag_output_prefix,
                target_output_prefix,
                region_output_prefix,
                barcode="A01",
                resolved_level="genus",
                resolved_taxon="g__G1",
                marker_id="M1",
                lineage={
                    "domain": "d__Archaea",
                    "phylum": "p__P1",
                    "class": "c__C1",
                    "order": "o__O1",
                    "family": "f__F1",
                    "genus": "g__G1",
                    "species": None,
                },
                parent_level="family",
                parent_taxon="f__F1",
                remap_rows=(
                    ("RS_GCF_000001", "AAGCAA"),
                    ("RS_GCF_000004", "AAGCAA"),
                ),
            )

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "probes",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--markers-archive",
                        str(markers_archive),
                        "--region-discovery-prefix",
                        str(region_output_prefix),
                        "--output-prefix",
                        str(probe_output_prefix),
                        "--probe-length",
                        "6",
                        "--min-gc",
                        "0",
                        "--max-gc",
                        "1",
                        "--min-tm",
                        "-100",
                        "--max-tm",
                        "200",
                        "--include",
                        "family:f__F1",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["include_taxa"], {"family": ["f__F1"]})
            with _stage_artifact(probe_output_prefix, "probes", "probe_candidates.csv").open(
                "r", encoding="utf-8", newline=""
            ) as handle:
                probe_rows = list(csv.DictReader(handle))
            self.assertTrue(probe_rows)
            self.assertEqual(int(probe_rows[0]["global_mapped_sequences"]), 1)

    def test_probes_design_can_score_mismatch_tolerant_hits(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            markers_archive = Path(temp_dir) / "markers.tar.gz"
            msa_archive = Path(temp_dir) / "msa.tar.gz"
            tag_output_prefix = Path(temp_dir) / "outputs" / "tags"
            target_output_prefix = Path(temp_dir) / "outputs" / "targets"
            region_output_prefix = Path(temp_dir) / "outputs" / "regions"
            probe_output_prefix = Path(temp_dir) / "outputs" / "probes"
            taxonomy_path.write_text(
                "\n".join(
                    [
                        "RS_GCF_000001\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                        "RS_GCF_000004\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S4",
                        "RS_GCF_000002\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G2;s__S2",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )
            _write_tar_archive(
                markers_archive,
                {
                    "markers/fna/M1.fna": (
                        ">RS_GCF_000001\nAAAAAA\n"
                        ">RS_GCF_000004\nAAAAAT\n"
                        ">RS_GCF_000002\nAAAAAT\n"
                    ),
                },
            )
            _write_tar_archive(
                msa_archive,
                {
                    "individual/M1.faa": (
                        ">RS_GCF_000001\nAA\n"
                        ">RS_GCF_000004\nAA\n"
                        ">RS_GCF_000002\nAA\n"
                    ),
                },
            )
            _write_region_design_fixture(
                tag_output_prefix,
                target_output_prefix,
                region_output_prefix,
                barcode="A01",
                resolved_level="genus",
                resolved_taxon="g__G1",
                marker_id="M1",
                lineage={
                    "domain": "d__Archaea",
                    "phylum": "p__P1",
                    "class": "c__C1",
                    "order": "o__O1",
                    "family": "f__F1",
                    "genus": "g__G1",
                    "species": None,
                },
                parent_level="family",
                parent_taxon="f__F1",
                remap_rows=(
                    ("RS_GCF_000001", "AAAAAA"),
                    ("RS_GCF_000004", "AAAAAT"),
                ),
            )

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "probes",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--markers-archive",
                        str(markers_archive),
                        "--region-discovery-prefix",
                        str(region_output_prefix),
                        "--output-prefix",
                        str(probe_output_prefix),
                        "--probe-length",
                        "6",
                        "--profile",
                        "fast",
                        "--min-gc",
                        "0",
                        "--max-gc",
                        "1",
                        "--min-tm",
                        "-100",
                        "--max-tm",
                        "200",
                        "--max-homopolymer",
                        "6",
                        "--max-mismatches",
                        "1",
                        "--mismatch-penalty-per-mismatch",
                        "0.5",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["max_mismatches"], 1)
            self.assertEqual(payload["mismatch_penalty_per_mismatch"], 0.5)

            with _stage_artifact(probe_output_prefix, "probes", "probe_candidates.csv").open("r", encoding="utf-8", newline="") as handle:
                rows = list(csv.DictReader(handle))
            self.assertTrue(rows)
            first = rows[0]
            self.assertEqual(int(first["target_exact_hits"]), 1)
            self.assertEqual(int(first["target_mismatch_hits"]), 1)
            self.assertEqual(int(first["sibling_exact_hits"]), 0)
            self.assertEqual(int(first["sibling_mismatch_hits"]), 1)
            self.assertAlmostEqual(float(first["target_effective_coverage_fraction"]), 0.75)
            self.assertAlmostEqual(float(first["sibling_effective_offtarget_fraction"]), 0.5)

    def test_panels_design_from_explicit_files_writes_outputs(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            markers_archive = Path(temp_dir) / "markers.tar.gz"
            msa_archive = Path(temp_dir) / "msa.tar.gz"
            tag_output_prefix = Path(temp_dir) / "outputs" / "tag_design"
            target_output_prefix = Path(temp_dir) / "outputs" / "targets"
            region_output_prefix = Path(temp_dir) / "outputs" / "regions"
            probe_output_prefix = Path(temp_dir) / "outputs" / "probes"
            panel_output_prefix = Path(temp_dir) / "outputs" / "panels"
            taxonomy_path.write_text(
                "\n".join(
                    [
                        "RS_GCF_000001\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                        "RS_GCF_000004\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S4",
                        "RS_GCF_000002\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G2;s__S2",
                        "RS_GCF_000003\td__Archaea;p__P2;c__C2;o__O2;f__F2;g__G3;s__S3",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )
            _write_tar_archive(
                markers_archive,
                {
                    "markers/fna/M1.fna": (
                        ">RS_GCF_000001\nGCCGCCGCCGCCGCCGCC\n"
                        ">RS_GCF_000004\nGCCGCCGCCGCCGCCGCC\n"
                        ">RS_GCF_000002\nACTACTACTGATGATGAT\n"
                    ),
                    "markers/fna/M2.fna": (
                        ">RS_GCF_000003\nGGTGGTGGTACTACTACT\n"
                    ),
                },
            )
            _write_tar_archive(
                msa_archive,
                {
                    "individual/M1.faa": (
                        ">RS_GCF_000001\nAAACCC\n"
                        ">RS_GCF_000004\nAAACCC\n"
                        ">RS_GCF_000002\nTTTDDD\n"
                    ),
                    "individual/M2.faa": (
                        ">RS_GCF_000003\nGGGTTT\n"
                    ),
                },
            )

            with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
                self.assertEqual(
                    main(
                        [
                            "tags",
                                                        "--taxonomy-file",
                            str(taxonomy_path),
                            "--output-prefix",
                            str(tag_output_prefix),
                            "--positions",
                            "2",
                            "--format",
                            "json",
                        ]
                    ),
                    0,
                )
                self.assertEqual(
                    main(
                        [
                            "targets",
                                                        "--taxonomy-file",
                            str(taxonomy_path),
                            "--markers-archive",
                            str(markers_archive),
                            "--tag-design-prefix",
                            str(tag_output_prefix),
                            "--output-prefix",
                            str(target_output_prefix),
                            "--top-markers-per-target",
                            "2",
                            "--format",
                            "json",
                        ]
                    ),
                    0,
                )
                self.assertEqual(
                    main(
                        [
                            "regions",
                                                        "--taxonomy-file",
                            str(taxonomy_path),
                            "--msa-archive",
                            str(msa_archive),
                            "--markers-archive",
                            str(markers_archive),
                            "--target-discovery-prefix",
                            str(target_output_prefix),
                            "--output-prefix",
                            str(region_output_prefix),
                            "--window-aa-length",
                            "3",
                            "--top-regions-per-marker",
                            "2",
                            "--region-probe-length",
                            "6",
                            "--format",
                            "json",
                        ]
                    ),
                    0,
                )
                self.assertEqual(
                    main(
                        [
                            "probes",
                                                        "--taxonomy-file",
                            str(taxonomy_path),
                            "--markers-archive",
                            str(markers_archive),
                            "--region-discovery-prefix",
                            str(region_output_prefix),
                            "--output-prefix",
                            str(probe_output_prefix),
                            "--probe-length",
                            "6",
                            "--top-probes-per-region",
                            "2",
                            "--min-gc",
                            "0",
                            "--max-gc",
                            "1",
                            "--min-tm",
                            "-100",
                            "--max-tm",
                            "200",
                            "--workers",
                            "2",
                            "--format",
                            "json",
                        ]
                    ),
                    0,
                )

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "panels",
                                                "--taxonomy-file",
                        str(taxonomy_path),
                        "--markers-archive",
                        str(markers_archive),
                        "--probe-design-prefix",
                        str(probe_output_prefix),
                        "--output-prefix",
                        str(panel_output_prefix),
                        "--max-probes-per-panel",
                        "2",
                        "--profile",
                        "balanced",
                        "--max-panel-contiguous-complementarity",
                        "8",
                        "--panel-complementarity-penalty-weight",
                        "0.2",
                        "--workers",
                        "2",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["max_probes_per_panel"], 2)
            self.assertEqual(payload["profile"], "balanced")
            self.assertEqual(payload["interaction_backend"], "basic")
            self.assertTrue(len(payload["selected_panels"]) >= 1)
            self.assertTrue(_stage_artifact(panel_output_prefix, "panels", "summary.json").exists())
            self.assertTrue(_stage_artifact(panel_output_prefix, "panels", "selected_panels.csv").exists())
            self.assertTrue(_stage_artifact(panel_output_prefix, "panels", "panel_probe_manifest.csv").exists())

    def test_panels_design_can_limit_taxonomic_scope(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            markers_archive = Path(temp_dir) / "markers.tar.gz"
            tag_prefix = Path(temp_dir) / "outputs" / "tags"
            target_prefix = Path(temp_dir) / "outputs" / "targets"
            region_prefix = Path(temp_dir) / "outputs" / "regions"
            probe_prefix = Path(temp_dir) / "outputs" / "probes"
            panel_prefix = Path(temp_dir) / "outputs" / "panels"
            taxonomy_path.write_text(
                "\n".join(
                    [
                        "RS_GCF_000001.1\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                        "RS_GCF_000004.1\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S4",
                        "RS_GCF_000002.1\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G2;s__S2",
                        "RS_GCF_000003.1\td__Archaea;p__P2;c__C2;o__O2;f__F2;g__G3;s__S3",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )
            _write_tar_archive(
                markers_archive,
                {
                    "individual/M1.fna": (
                        ">RS_GCF_000001.1\nAAAAAA\n"
                        ">RS_GCF_000004.1\nAAAAAA\n"
                        ">RS_GCF_000002.1\nAAAAAT\n"
                        ">RS_GCF_000003.1\nCCCCCC\n"
                    ),
                },
            )
            _write_probe_design_fixture(
                tag_prefix,
                target_prefix,
                region_prefix,
                probe_prefix,
                barcode="A01",
                resolved_level="genus",
                resolved_taxon="g__G1",
                marker_id="M1",
                target_subsequence="AAAAAA",
                probe_sequence="TTTTTT",
                lineage={
                    "domain": "d__Archaea",
                    "phylum": "p__P1",
                    "class": "c__C1",
                    "order": "o__O1",
                    "family": "f__F1",
                    "genus": "g__G1",
                    "species": "",
                },
            )

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "panels",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--markers-archive",
                        str(markers_archive),
                        "--probe-design-prefix",
                        str(probe_prefix),
                        "--output-prefix",
                        str(panel_prefix),
                        "--include",
                        "family:f__F1",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["include_taxa"], {"family": ["f__F1"]})
            with _stage_artifact(panel_prefix, "panels", "panel_candidates.csv").open(
                "r", encoding="utf-8", newline=""
            ) as handle:
                panel_rows = list(csv.DictReader(handle))
            self.assertTrue(panel_rows)
            self.assertEqual(int(panel_rows[0]["global_taxonomy_genomes"]), 1)

    def test_panels_design_can_infer_session_probe_prefix(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            markers_archive = Path(temp_dir) / "markers.tar.gz"
            output_dir = Path(temp_dir) / "runs"
            session_name = "archaea_demo"
            tag_prefix = _session_stage_prefix(output_dir, session_name, "tags")
            target_prefix = _session_stage_prefix(output_dir, session_name, "targets")
            region_prefix = _session_stage_prefix(output_dir, session_name, "regions")
            probe_prefix = _session_stage_prefix(output_dir, session_name, "probes")
            panel_prefix = _session_stage_prefix(output_dir, session_name, "panels")

            taxonomy_path.write_text(
                "\n".join(
                    [
                        "RS_GCF_000001.1\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                        "RS_GCF_000004.1\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S4",
                        "RS_GCF_000002.1\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G2;s__S2",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )
            _write_tar_archive(
                markers_archive,
                {
                    "individual/M1.fna": (
                        ">RS_GCF_000001.1\nAAAAAA\n"
                        ">RS_GCF_000004.1\nAAAAAA\n"
                        ">RS_GCF_000002.1\nCCCCCC\n"
                    ),
                },
            )
            _write_probe_design_fixture(
                tag_prefix,
                target_prefix,
                region_prefix,
                probe_prefix,
                barcode="A01",
                resolved_level="genus",
                resolved_taxon="g__G1",
                marker_id="M1",
                target_subsequence="AAAAAA",
                probe_sequence="TTTTTT",
                lineage={
                    "domain": "d__Archaea",
                    "phylum": "p__P1",
                    "class": "c__C1",
                    "order": "o__O1",
                    "family": "f__F1",
                    "genus": "g__G1",
                    "species": "s__S1",
                },
            )

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "panels",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--markers-archive",
                        str(markers_archive),
                        "--output",
                        str(output_dir),
                        "--session",
                        session_name,
                        "--max-probes-per-panel",
                        "1",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["probe_design_prefix"], str(probe_prefix.resolve()))
            self.assertTrue(_stage_artifact(panel_prefix, "panels", "summary.json").exists())
            self.assertTrue(_stage_artifact(panel_prefix, "panels", "selected_panels.csv").exists())

    def test_panels_design_blocks_overlapping_probes_by_default(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            markers_archive = Path(temp_dir) / "markers.tar.gz"
            tag_prefix = Path(temp_dir) / "outputs" / "tags"
            target_prefix = Path(temp_dir) / "outputs" / "targets"
            region_prefix = Path(temp_dir) / "outputs" / "regions"
            probe_prefix = Path(temp_dir) / "outputs" / "probes"
            panel_prefix = Path(temp_dir) / "outputs" / "panels"

            taxonomy_path.write_text(
                "\n".join(
                    [
                        "RS_GCF_000001.1\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                        "RS_GCF_000004.1\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S4",
                        "RS_GCF_000002.1\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G2;s__S2",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )
            _write_tar_archive(
                markers_archive,
                {
                    "individual/M1.fna": (
                        ">RS_GCF_000001.1\nAAAAAAGGGGGGCCCCCC\n"
                        ">RS_GCF_000004.1\nAAAAAAGGGGGGCCCCCC\n"
                        ">RS_GCF_000002.1\nTTTTTTTTTTTTTTTTTT\n"
                    ),
                },
            )
            _write_probe_design_fixture(
                tag_prefix,
                target_prefix,
                region_prefix,
                probe_prefix,
                barcode="A01",
                resolved_level="genus",
                resolved_taxon="g__G1",
                marker_id="M1",
                target_subsequence="AAAAAA",
                probe_sequence="TTTTTT",
                lineage={
                    "domain": "d__Archaea",
                    "phylum": "p__P1",
                    "class": "c__C1",
                    "order": "o__O1",
                    "family": "f__F1",
                    "genus": "g__G1",
                    "species": "s__S1",
                },
                probe_rows=[
                    {
                        "probe_sequence": "TTTTTT",
                        "target_subsequence": "AAAAAA",
                        "score": 3.0,
                        "rank_within_region": 1,
                        "source_nt_start": 1,
                        "source_nt_end": 6,
                    },
                    {
                        "probe_sequence": "TTTTTC",
                        "target_subsequence": "AAAGGG",
                        "score": 2.5,
                        "rank_within_region": 2,
                        "source_nt_start": 4,
                        "source_nt_end": 9,
                    },
                    {
                        "probe_sequence": "GGGGGG",
                        "target_subsequence": "CCCCCC",
                        "score": 2.0,
                        "rank_within_region": 3,
                        "source_nt_start": 13,
                        "source_nt_end": 18,
                    },
                ],
            )

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "panels",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--markers-archive",
                        str(markers_archive),
                        "--probe-design-prefix",
                        str(probe_prefix),
                        "--output-prefix",
                        str(panel_prefix),
                        "--max-probes-per-panel",
                        "2",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["max_probes_per_panel"], 2)
            self.assertEqual(payload["max_probes_per_marker"], 5)
            self.assertEqual(payload["max_probes_per_region"], 2)
            self.assertFalse(payload["allow_overlaps"])

            with _stage_artifact(panel_prefix, "panels", "panel_probe_manifest.csv").open("r", encoding="utf-8", newline="") as handle:
                rows = list(csv.DictReader(handle))
            self.assertEqual([row["probe_sequence"] for row in rows], ["TTTTTT", "GGGGGG"])

    def test_panels_design_can_allow_overlapping_probes(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            markers_archive = Path(temp_dir) / "markers.tar.gz"
            tag_prefix = Path(temp_dir) / "outputs" / "tags"
            target_prefix = Path(temp_dir) / "outputs" / "targets"
            region_prefix = Path(temp_dir) / "outputs" / "regions"
            probe_prefix = Path(temp_dir) / "outputs" / "probes"
            panel_prefix = Path(temp_dir) / "outputs" / "panels"

            taxonomy_path.write_text(
                "\n".join(
                    [
                        "RS_GCF_000001.1\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                        "RS_GCF_000004.1\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S4",
                        "RS_GCF_000002.1\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G2;s__S2",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )
            _write_tar_archive(
                markers_archive,
                {
                    "individual/M1.fna": (
                        ">RS_GCF_000001.1\nAAAAAAGGGGGGCCCCCC\n"
                        ">RS_GCF_000004.1\nAAAAAAGGGGGGCCCCCC\n"
                        ">RS_GCF_000002.1\nTTTTTTTTTTTTTTTTTT\n"
                    ),
                },
            )
            _write_probe_design_fixture(
                tag_prefix,
                target_prefix,
                region_prefix,
                probe_prefix,
                barcode="A01",
                resolved_level="genus",
                resolved_taxon="g__G1",
                marker_id="M1",
                target_subsequence="AAAAAA",
                probe_sequence="TTTTTT",
                lineage={
                    "domain": "d__Archaea",
                    "phylum": "p__P1",
                    "class": "c__C1",
                    "order": "o__O1",
                    "family": "f__F1",
                    "genus": "g__G1",
                    "species": "s__S1",
                },
                probe_rows=[
                    {
                        "probe_sequence": "TTTTTT",
                        "target_subsequence": "AAAAAA",
                        "score": 3.0,
                        "rank_within_region": 1,
                        "source_nt_start": 1,
                        "source_nt_end": 6,
                    },
                    {
                        "probe_sequence": "TTTTTC",
                        "target_subsequence": "AAAGGG",
                        "score": 2.5,
                        "rank_within_region": 2,
                        "source_nt_start": 4,
                        "source_nt_end": 9,
                    },
                    {
                        "probe_sequence": "GGGGGG",
                        "target_subsequence": "CCCCCC",
                        "score": 2.0,
                        "rank_within_region": 3,
                        "source_nt_start": 13,
                        "source_nt_end": 18,
                    },
                ],
            )

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "panels",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--markers-archive",
                        str(markers_archive),
                        "--probe-design-prefix",
                        str(probe_prefix),
                        "--output-prefix",
                        str(panel_prefix),
                        "--max-probes-per-panel",
                        "2",
                        "--allow-overlaps",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertTrue(payload["allow_overlaps"])

            with _stage_artifact(panel_prefix, "panels", "panel_probe_manifest.csv").open("r", encoding="utf-8", newline="") as handle:
                rows = list(csv.DictReader(handle))
            self.assertEqual([row["probe_sequence"] for row in rows], ["TTTTTT", "TTTTTC"])

    def test_panels_design_can_score_mismatch_tolerant_hits(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            markers_archive = Path(temp_dir) / "markers.tar.gz"
            tag_prefix = Path(temp_dir) / "outputs" / "tags"
            target_prefix = Path(temp_dir) / "outputs" / "targets"
            region_prefix = Path(temp_dir) / "outputs" / "regions"
            probe_prefix = Path(temp_dir) / "outputs" / "probes"
            panel_prefix = Path(temp_dir) / "outputs" / "panels"

            taxonomy_path.write_text(
                "\n".join(
                    [
                        "RS_GCF_000001.1\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                        "RS_GCF_000004.1\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S4",
                        "RS_GCF_000002.1\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G2;s__S2",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )
            _write_tar_archive(
                markers_archive,
                {
                    "individual/M1.fna": (
                        ">RS_GCF_000001.1\nAAAAAA\n"
                        ">RS_GCF_000004.1\nAAAAAT\n"
                        ">RS_GCF_000002.1\nAAAAAT\n"
                    ),
                },
            )
            _write_probe_design_fixture(
                tag_prefix,
                target_prefix,
                region_prefix,
                probe_prefix,
                barcode="A01",
                resolved_level="genus",
                resolved_taxon="g__G1",
                marker_id="M1",
                target_subsequence="AAAAAA",
                probe_sequence="TTTTTT",
                lineage={
                    "domain": "d__Archaea",
                    "phylum": "p__P1",
                    "class": "c__C1",
                    "order": "o__O1",
                    "family": "f__F1",
                    "genus": "g__G1",
                    "species": None,
                },
            )

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "panels",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--markers-archive",
                        str(markers_archive),
                        "--probe-design-prefix",
                        str(probe_prefix),
                        "--output-prefix",
                        str(panel_prefix),
                        "--max-mismatches",
                        "1",
                        "--mismatch-penalty-per-mismatch",
                        "0.5",
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["max_mismatches"], 1)
            self.assertEqual(payload["mismatch_penalty_per_mismatch"], 0.5)

            with _stage_artifact(panel_prefix, "panels", "panel_candidates.csv").open("r", encoding="utf-8", newline="") as handle:
                rows = list(csv.DictReader(handle))
            self.assertTrue(rows)
            first = next(row for row in rows if row["target_subsequence"] == "AAAAAA")
            self.assertEqual(int(first["target_exact_hits"]), 1)
            self.assertEqual(int(first["target_mismatch_hits"]), 1)
            self.assertEqual(int(first["sibling_mismatch_hits"]), 1)
            self.assertAlmostEqual(float(first["target_candidate_effective_coverage_fraction"]), 0.75)
            self.assertAlmostEqual(float(first["sibling_candidate_effective_offtarget_fraction"]), 0.5)

            with _stage_artifact(panel_prefix, "panels", "panel_probe_manifest.csv").open("r", encoding="utf-8", newline="") as handle:
                reader = csv.DictReader(handle)
                self.assertIsNotNone(reader.fieldnames)
                for expected in (
                    "max_panel_complementarity",
                    "max_panel_contiguous_complementarity",
                    "panel_interaction_penalty",
                ):
                    self.assertIn(expected, reader.fieldnames)

    def test_panels_design_can_use_installed_dataset(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            home = Path(temp_dir) / "home"
            datasets_dir = Path(temp_dir) / "datasets-store"
            tag_output_prefix = Path(temp_dir) / "outputs" / "tag_design"
            target_output_prefix = Path(temp_dir) / "outputs" / "targets"
            region_output_prefix = Path(temp_dir) / "outputs" / "regions"
            probe_output_prefix = Path(temp_dir) / "outputs" / "probes"
            panel_output_prefix = Path(temp_dir) / "outputs" / "panels"
            taxonomy_path = Path(temp_dir) / "archaea.tsv"
            markers_path = Path(temp_dir) / "archaea_markers.tar.gz"
            msa_path = Path(temp_dir) / "archaea_msa.tar.gz"
            bacteria_taxonomy = Path(temp_dir) / "bacteria.tsv"
            bacteria_markers = Path(temp_dir) / "bacteria_markers.tar.gz"
            bacteria_msa = Path(temp_dir) / "bacteria_msa.tar.gz"
            taxonomy_path.write_text(
                "RS_GCF_000001\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1\n",
                encoding="utf-8",
            )
            _write_tar_archive(
                markers_path,
                {
                    "individual/M1.fna": ">RS_GCF_000001\nGCCGCCGCCGCC\n",
                },
            )
            _write_tar_archive(
                msa_path,
                {
                    "individual/M1.faa": ">RS_GCF_000001\nAAAA\n",
                },
            )
            bacteria_taxonomy.write_text(
                "RS_GCF_000010\td__Bacteria;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1\n",
                encoding="utf-8",
            )
            _write_tar_archive(
                bacteria_markers,
                {
                    "individual/M1.fna": ">RS_GCF_000010\nGCCGCCGCCGCC\n",
                },
            )
            _write_tar_archive(
                bacteria_msa,
                {
                    "individual/M1.faa": ">RS_GCF_000010\nAAAA\n",
                },
            )
            catalog_path = Path(temp_dir) / "catalog.json"
            _write_catalog(
                catalog_path,
                {
                    "archaea_taxonomy": taxonomy_path,
                    "archaea_msa": msa_path,
                    "archaea_markers": markers_path,
                    "bacteria_taxonomy": bacteria_taxonomy,
                    "bacteria_msa": bacteria_msa,
                    "bacteria_markers": bacteria_markers,
                },
            )

            previous = None
            if APP_HOME_ENV in __import__("os").environ:
                previous = __import__("os").environ[APP_HOME_ENV]
            __import__("os").environ[APP_HOME_ENV] = str(home)
            try:
                with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
                    self.assertEqual(
                        main(
                            [
                                "datasets",
                                                                "--taxon",
                                "archaea",
                                "--catalog-file",
                                str(catalog_path),
                                "--datasets-dir",
                                str(datasets_dir),
                                "--format",
                                "json",
                            ]
                        ),
                        0,
                    )
                    self.assertEqual(
                        main(
                            [
                                "tags",
                                                                "--dataset",
                                "archaea",
                                "--output-prefix",
                                str(tag_output_prefix),
                                "--positions",
                                "2",
                                "--format",
                                "json",
                            ]
                        ),
                        0,
                    )
                    self.assertEqual(
                        main(
                            [
                                "targets",
                                                                "--dataset",
                                "archaea",
                                "--tag-design-prefix",
                                str(tag_output_prefix),
                                "--output-prefix",
                                str(target_output_prefix),
                                "--format",
                                "json",
                            ]
                        ),
                        0,
                    )
                    self.assertEqual(
                        main(
                            [
                                "regions",
                                                                "--dataset",
                                "archaea",
                                "--target-discovery-prefix",
                                str(target_output_prefix),
                                "--output-prefix",
                                str(region_output_prefix),
                                "--window-aa-length",
                                "2",
                                "--region-probe-length",
                                "6",
                                "--format",
                                "json",
                            ]
                        ),
                        0,
                    )
                    self.assertEqual(
                        main(
                            [
                                "probes",
                                                                "--dataset",
                                "archaea",
                                "--region-discovery-prefix",
                                str(region_output_prefix),
                                "--output-prefix",
                                str(probe_output_prefix),
                                "--probe-length",
                                "6",
                                "--profile",
                                "fast",
                                "--min-gc",
                                "0",
                                "--max-gc",
                                "1",
                                "--min-tm",
                                "-100",
                                "--max-tm",
                                "200",
                                "--format",
                                "json",
                            ]
                        ),
                        0,
                    )

                stdout = io.StringIO()
                with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                    exit_code = main(
                        [
                            "panels",
                                                        "--dataset",
                            "archaea",
                            "--probe-design-prefix",
                            str(probe_output_prefix),
                            "--output-prefix",
                            str(panel_output_prefix),
                            "--max-probes-per-panel",
                            "2",
                            "--profile",
                            "fast",
                            "--format",
                            "json",
                        ]
                    )
                self.assertEqual(exit_code, 0)
                payload = json.loads(stdout.getvalue())
                self.assertEqual(payload["dataset"], "archaea")
                self.assertEqual(payload["max_probes_per_panel"], 2)
                self.assertTrue(_stage_artifact(panel_output_prefix, "panels", "selected_panels.csv").exists())
            finally:
                if previous is None:
                    __import__("os").environ.pop(APP_HOME_ENV, None)
                else:
                    __import__("os").environ[APP_HOME_ENV] = previous

    def test_index_build_writes_outputs(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            genome_archive = Path(temp_dir) / "gtdb_genomes_reps_r226.tar.gz"
            output_prefix = Path(temp_dir) / "outputs" / "archaea_reps_index"
            fake_fulgor = Path(temp_dir) / "fake_fulgor"
            _write_tar_archive(
                genome_archive,
                {
                    "genomes/GCF_000001.1_genomic.fna": ">contig1\nAACCGGTTAACCGGTT\n",
                    "genomes/GCF_000002.1_genomic.fna": ">contig2\nTTGGCCAATTGGCCAA\n",
                },
            )
            _write_fake_fulgor(fake_fulgor)

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "index",
                        "--genome-archive",
                        str(genome_archive),
                        "--output-prefix",
                        str(output_prefix),
                        "--fulgor-bin",
                        str(fake_fulgor),
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["dataset_type"], "fulgor_index")
            self.assertEqual(payload["input_mode"], "archive")
            self.assertEqual(payload["kmer_length"], 21)
            self.assertEqual(payload["indexed_references"], 2)
            self.assertTrue((output_prefix.parent / "archaea_reps_index.fur").exists())
            self.assertTrue((output_prefix.parent / "archaea_reps_index_reference_map.csv").exists())
            self.assertTrue((output_prefix.parent / "archaea_reps_index_summary.json").exists())

    def test_index_build_accepts_explicit_genome_files(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            genome_file_1 = Path(temp_dir) / "GCF_000001.1_genomic.fna"
            genome_file_2 = Path(temp_dir) / "GCF_000002.1_genomic.fna"
            output_prefix = Path(temp_dir) / "outputs" / "custom_index"
            fake_fulgor = Path(temp_dir) / "fake_fulgor"

            genome_file_1.write_text(">contig1\nAACCGGTTAACCGGTT\n", encoding="utf-8")
            genome_file_2.write_text(">contig2\nTTGGCCAATTGGCCAA\n", encoding="utf-8")
            _write_fake_fulgor(fake_fulgor)

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "index",
                        "--genome-file",
                        str(genome_file_1),
                        "--genome-file",
                        str(genome_file_2),
                        "--output-prefix",
                        str(output_prefix),
                        "--fulgor-bin",
                        str(fake_fulgor),
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["dataset_type"], "fulgor_index")
            self.assertEqual(payload["input_mode"], "files")
            self.assertIsNone(payload["genome_archive"])
            self.assertEqual(payload["genome_file_count"], 2)
            self.assertEqual(payload["indexed_references"], 2)
            self.assertEqual(payload["genome_files"], [str(genome_file_1.resolve()), str(genome_file_2.resolve())])
            self.assertTrue((output_prefix.parent / "custom_index.fur").exists())
            self.assertTrue((output_prefix.parent / "custom_index_reference_map.csv").exists())
            self.assertTrue((output_prefix.parent / "custom_index_summary.json").exists())

    def test_panels_design_can_use_explicit_genome_index(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            markers_archive = Path(temp_dir) / "markers.tar.gz"
            genome_archive = Path(temp_dir) / "gtdb_genomes_reps_r226.tar.gz"
            fake_fulgor = Path(temp_dir) / "fake_fulgor"
            index_prefix = Path(temp_dir) / "outputs" / "archaea_reps_index"
            tag_prefix = Path(temp_dir) / "outputs" / "tags"
            target_prefix = Path(temp_dir) / "outputs" / "targets"
            region_prefix = Path(temp_dir) / "outputs" / "regions"
            probe_prefix = Path(temp_dir) / "outputs" / "probes"
            panel_prefix = Path(temp_dir) / "outputs" / "panels"

            taxonomy_path.write_text(
                "\n".join(
                    [
                        "RS_GCF_000001.1\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                        "RS_GCF_000002.1\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G2;s__S2",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )
            _write_tar_archive(
                markers_archive,
                {
                    "individual/M1.fna": ">RS_GCF_000001.1\nAACCGGTTAACCGGTT\n>RS_GCF_000002.1\nTTTTTTTTTTTTTTTT\n",
                },
            )
            _write_tar_archive(
                genome_archive,
                {
                    "genomes/GCF_000001.1_genomic.fna": ">contig1\nAACCGGTTAACCGGTT\n",
                    "genomes/GCF_000002.1_genomic.fna": ">contig2\nGGGGGAACCGGTTCCCC\n",
                },
            )
            _write_fake_fulgor(fake_fulgor)
            _write_probe_design_fixture(
                tag_prefix,
                target_prefix,
                region_prefix,
                probe_prefix,
                barcode="A01",
                resolved_level="genus",
                resolved_taxon="g__G1",
                marker_id="M1",
                target_subsequence="AACCGGTT",
                probe_sequence="AACCGGTT"[::-1].translate(str.maketrans("ACGT", "TGCA")),
                lineage={
                    "domain": "d__Archaea",
                    "phylum": "p__P1",
                    "class": "c__C1",
                    "order": "o__O1",
                    "family": "f__F1",
                    "genus": "g__G1",
                    "species": None,
                },
            )

            with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
                self.assertEqual(
                    main(
                        [
                            "index",
                            "--genome-archive",
                            str(genome_archive),
                            "--output-prefix",
                            str(index_prefix),
                            "--fulgor-bin",
                            str(fake_fulgor),
                            "--kmer-length",
                            "5",
                            "--minimizer-length",
                            "3",
                            "--format",
                            "json",
                        ]
                    ),
                    0,
                )

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "panels",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--markers-archive",
                        str(markers_archive),
                        "--index-file",
                        str(index_prefix.parent / "archaea_reps_index.fur"),
                        "--index-reference-map",
                        str(index_prefix.parent / "archaea_reps_index_reference_map.csv"),
                        "--index-summary",
                        str(index_prefix.parent / "archaea_reps_index_summary.json"),
                        "--fulgor-bin",
                        str(fake_fulgor),
                        "--index-threads",
                        "1",
                        "--probe-design-prefix",
                        str(probe_prefix),
                        "--output-prefix",
                        str(panel_prefix),
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["index_file"], str((index_prefix.parent / "archaea_reps_index.fur").resolve()))
            self.assertTrue(_stage_artifact(panel_prefix, "panels", "panel_candidates.csv").exists())
            import csv

            with _stage_artifact(panel_prefix, "panels", "panel_candidates.csv").open("r", encoding="utf-8", newline="") as handle:
                rows = list(csv.DictReader(handle))
            self.assertTrue(rows)
            self.assertIn("index_global_hits", rows[0])
            self.assertEqual(rows[0]["index_global_hits"], "1")

    def test_panels_design_can_join_bacterial_and_host_indices(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            taxonomy_path = Path(temp_dir) / "taxonomy.tsv"
            markers_archive = Path(temp_dir) / "markers.tar.gz"
            bacteria_genome = Path(temp_dir) / "GCF_900001.1_genomic.fna"
            host_genome = Path(temp_dir) / "human_chr1.fna"
            fake_fulgor = Path(temp_dir) / "fake_fulgor"
            bacteria_index_prefix = Path(temp_dir) / "outputs" / "bacteria_index"
            host_index_prefix = Path(temp_dir) / "outputs" / "human_index"
            tag_prefix = Path(temp_dir) / "outputs" / "tags"
            target_prefix = Path(temp_dir) / "outputs" / "targets"
            region_prefix = Path(temp_dir) / "outputs" / "regions"
            probe_prefix = Path(temp_dir) / "outputs" / "probes"
            panel_prefix = Path(temp_dir) / "outputs" / "panels"

            taxonomy_path.write_text(
                "\n".join(
                    [
                        "RS_GCF_000001.1\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G1;s__S1",
                        "RS_GCF_000002.1\td__Archaea;p__P1;c__C1;o__O1;f__F1;g__G2;s__S2",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )
            _write_tar_archive(
                markers_archive,
                {
                    "individual/M1.fna": ">RS_GCF_000001.1\nAACCGGTTAACCGGTT\n>RS_GCF_000002.1\nTTTTTTTTTTTTTTTT\n",
                },
            )
            bacteria_genome.write_text(">contig1\nGGGGAACCGGTTAAAA\n", encoding="utf-8")
            host_genome.write_text(">chr1\nTTTTAACCGGTTCCCC\n", encoding="utf-8")
            _write_fake_fulgor(fake_fulgor)
            _write_probe_design_fixture(
                tag_prefix,
                target_prefix,
                region_prefix,
                probe_prefix,
                barcode="A01",
                resolved_level="genus",
                resolved_taxon="g__G1",
                marker_id="M1",
                target_subsequence="AACCGGTT",
                probe_sequence="AACCGGTT"[::-1].translate(str.maketrans("ACGT", "TGCA")),
                lineage={
                    "domain": "d__Archaea",
                    "phylum": "p__P1",
                    "class": "c__C1",
                    "order": "o__O1",
                    "family": "f__F1",
                    "genus": "g__G1",
                    "species": None,
                },
            )

            with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
                self.assertEqual(
                    main(
                        [
                            "index",
                            "--genome-file",
                            str(bacteria_genome),
                            "--output-prefix",
                            str(bacteria_index_prefix),
                            "--fulgor-bin",
                            str(fake_fulgor),
                            "--kmer-length",
                            "5",
                            "--minimizer-length",
                            "3",
                            "--format",
                            "json",
                        ]
                    ),
                    0,
                )
                self.assertEqual(
                    main(
                        [
                            "index",
                            "--genome-file",
                            str(host_genome),
                            "--output-prefix",
                            str(host_index_prefix),
                            "--fulgor-bin",
                            str(fake_fulgor),
                            "--kmer-length",
                            "5",
                            "--minimizer-length",
                            "3",
                            "--format",
                            "json",
                        ]
                    ),
                    0,
                )

            stdout = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(io.StringIO()):
                exit_code = main(
                    [
                        "panels",
                        "--taxonomy-file",
                        str(taxonomy_path),
                        "--markers-archive",
                        str(markers_archive),
                        "--index-file",
                        str(bacteria_index_prefix.parent / "bacteria_index.fur"),
                        "--index-reference-map",
                        str(bacteria_index_prefix.parent / "bacteria_index_reference_map.csv"),
                        "--index-summary",
                        str(bacteria_index_prefix.parent / "bacteria_index_summary.json"),
                        "--index-file",
                        str(host_index_prefix.parent / "human_index.fur"),
                        "--index-reference-map",
                        str(host_index_prefix.parent / "human_index_reference_map.csv"),
                        "--index-summary",
                        str(host_index_prefix.parent / "human_index_summary.json"),
                        "--fulgor-bin",
                        str(fake_fulgor),
                        "--index-threads",
                        "1",
                        "--probe-design-prefix",
                        str(probe_prefix),
                        "--output-prefix",
                        str(panel_prefix),
                        "--format",
                        "json",
                    ]
                )
            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(len(payload["index_files"]), 2)
            self.assertEqual(payload["index_labels"], ["bacteria_index", "human_index"])

            with _stage_artifact(panel_prefix, "panels", "panel_candidates.csv").open("r", encoding="utf-8", newline="") as handle:
                rows = list(csv.DictReader(handle))
            self.assertTrue(rows)
            self.assertEqual(rows[0]["index_bacteria_index_hits"], "1")
            self.assertEqual(rows[0]["index_human_index_hits"], "1")

    def test_datasets_install_conflict_uses_cli_error_renderer(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            home = Path(temp_dir) / "home"
            datasets_dir = Path(temp_dir) / "datasets-store"
            paths = self._make_paths(temp_dir)
            self._populate_catalog_inputs(paths)
            catalog_path = Path(temp_dir) / "catalog.json"
            _write_catalog(catalog_path, paths)
            conflict_dir = datasets_dir / "archaea"
            conflict_dir.mkdir(parents=True, exist_ok=True)
            (conflict_dir / "ar53_taxonomy.tsv").write_text("stale\n", encoding="utf-8")

            previous = None
            if APP_HOME_ENV in __import__("os").environ:
                previous = __import__("os").environ[APP_HOME_ENV]
            __import__("os").environ[APP_HOME_ENV] = str(home)
            try:
                stderr = io.StringIO()
                with redirect_stdout(io.StringIO()), redirect_stderr(stderr):
                    exit_code = main(
                        [
                            "datasets",
                                                        "--taxon",
                            "archaea",
                            "--catalog-file",
                            str(catalog_path),
                            "--datasets-dir",
                            str(datasets_dir),
                        ]
                    )
                self.assertEqual(exit_code, 1)
                self.assertIn("PhyloProbe Error", stderr.getvalue())
                self.assertIn("Destination already contains file(s) for dataset 'archaea'", stderr.getvalue())
                self.assertNotIn("Error: Destination already contains", stderr.getvalue())
            finally:
                if previous is None:
                    __import__("os").environ.pop(APP_HOME_ENV, None)
                else:
                    __import__("os").environ[APP_HOME_ENV] = previous


if __name__ == "__main__":
    unittest.main()
