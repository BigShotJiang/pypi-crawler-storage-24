from __future__ import annotations

from pathlib import Path
import sys
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from phyloprobe.parallel import iter_chunk_results


class ParallelTests(unittest.TestCase):
    def test_iter_chunk_results_falls_back_to_serial_on_process_pool_permission_error(self) -> None:
        chunks = [(0, 1), (1, 2), (2, 3)]
        initialized: list[str] = []

        def initializer(label: str) -> None:
            initialized.append(label)

        def worker(chunk: tuple[int, int]) -> int:
            return chunk[0] + chunk[1]

        with patch("phyloprobe.parallel.ProcessPoolExecutor", side_effect=PermissionError("blocked")):
            results = list(
                iter_chunk_results(
                    chunks,
                    worker=worker,
                    workers=2,
                    initializer=initializer,
                    initargs=("serial",),
                )
            )

        self.assertEqual(initialized, ["serial"])
        self.assertEqual(results, [((0, 1), 1), ((1, 2), 3), ((2, 3), 5)])


if __name__ == "__main__":
    unittest.main()
