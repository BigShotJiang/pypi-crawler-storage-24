"""Filesystem paths and registry layout for phyloprobe."""

from __future__ import annotations

import os
from pathlib import Path

APP_HOME_ENV = "PHYLOPROBE_HOME"
DATASETS_DIR_ENV = "PHYLOPROBE_DATASETS_DIR"


def resolve_home(explicit_home: str | Path | None = None) -> Path:
    """Return the managed application home directory."""

    if explicit_home is not None:
        return Path(explicit_home).expanduser().resolve()

    env_home = os.environ.get(APP_HOME_ENV)
    if env_home:
        return Path(env_home).expanduser().resolve()

    return (Path.home() / ".phyloprobe").resolve()


def ensure_home(explicit_home: str | Path | None = None) -> Path:
    """Create the managed directory structure if missing."""

    home = resolve_home(explicit_home)
    home.mkdir(parents=True, exist_ok=True)
    return home


def resolve_datasets_root(
    explicit_datasets_dir: str | Path | None = None,
    explicit_home: str | Path | None = None,
) -> Path:
    """Return the root directory where managed datasets are stored."""

    if explicit_datasets_dir is not None:
        return Path(explicit_datasets_dir).expanduser().resolve()

    env_datasets_dir = os.environ.get(DATASETS_DIR_ENV)
    if env_datasets_dir:
        return Path(env_datasets_dir).expanduser().resolve()

    return (resolve_home(explicit_home) / "datasets").resolve()


def ensure_datasets_root(
    explicit_datasets_dir: str | Path | None = None,
    explicit_home: str | Path | None = None,
) -> Path:
    """Create the managed datasets directory if missing."""

    datasets_root = resolve_datasets_root(explicit_datasets_dir, explicit_home)
    datasets_root.mkdir(parents=True, exist_ok=True)
    return datasets_root


def registry_path(explicit_home: str | Path | None = None) -> Path:
    """Return the registry JSON path."""

    return ensure_home(explicit_home) / "registry.json"


def dataset_dir(
    name: str,
    explicit_home: str | Path | None = None,
    explicit_datasets_dir: str | Path | None = None,
) -> Path:
    """Return the managed directory for one dataset."""

    return ensure_datasets_root(explicit_datasets_dir, explicit_home) / name
