"""GTDB-specific parsing and validation helpers."""

from __future__ import annotations

import csv
from dataclasses import asdict, dataclass
import gzip
import hashlib
from pathlib import Path
import tarfile

GTDB_RANK_PREFIXES = {
    "d": "domain",
    "p": "phylum",
    "c": "class",
    "o": "order",
    "f": "family",
    "g": "genus",
    "s": "species",
}
GTDB_RANKS = tuple(GTDB_RANK_PREFIXES.values())


@dataclass(slots=True)
class GtdbTaxonomySummary:
    genomes: int
    unique_lineages: int
    rank_counts: dict[str, int]
    missing_rank_counts: dict[str, int]

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


@dataclass(slots=True)
class GtdbTaxonomyRecord:
    accession: str
    lineage: str
    ranks: dict[str, str]

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


@dataclass(slots=True)
class ArchiveSummary:
    path: str
    member_count: int
    suffix_counts: dict[str, int]
    sample_members: list[str]

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


def sha256_file(path: str | Path, chunk_size: int = 1024 * 1024) -> str:
    """Calculate the SHA-256 digest of a file."""

    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        while True:
            chunk = handle.read(chunk_size)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def parse_gtdb_taxonomy_lineage(lineage: str) -> dict[str, str]:
    """Parse one GTDB semicolon-delimited lineage string."""

    parsed: dict[str, str] = {}
    for token in lineage.split(";"):
        token = token.strip()
        if not token or "__" not in token:
            continue
        prefix, _ = token.split("__", maxsplit=1)
        rank = GTDB_RANK_PREFIXES.get(prefix)
        if rank is not None:
            parsed[rank] = token
    return parsed


def _open_text_maybe_compressed(path: Path):
    """Open a text file that may be gzip-compressed regardless of suffix."""

    with path.open("rb") as handle:
        magic = handle.read(2)

    if magic == b"\x1f\x8b":
        return gzip.open(path, "rt", encoding="utf-8")
    return path.open("r", encoding="utf-8")


def _iter_taxonomy_rows(path: Path):
    """Yield accession/lineage pairs from a taxonomy TSV or GTDB metadata table."""

    with _open_text_maybe_compressed(path) as handle:
        reader = csv.reader(handle, delimiter="\t")
        try:
            first_row = next(reader)
        except StopIteration as exc:
            raise ValueError("The GTDB taxonomy file is empty.") from exc

        if not first_row:
            raise ValueError("The GTDB taxonomy file is empty.")

        lowered = [value.strip().lower() for value in first_row]
        if "gtdb_taxonomy" in lowered:
            try:
                accession_index = lowered.index("accession")
                lineage_index = lowered.index("gtdb_taxonomy")
            except ValueError as exc:
                raise ValueError(
                    "GTDB metadata table must contain 'accession' and 'gtdb_taxonomy' columns."
                ) from exc
        elif lowered[:2] in (["accession", "taxonomy"], ["accession", "gtdb_taxonomy"]):
            accession_index = 0
            lineage_index = 1
        else:
            if len(first_row) != 2:
                raise ValueError(
                    "Invalid GTDB taxonomy row at line 1: expected 2 tab-separated columns "
                    "or a metadata header with 'gtdb_taxonomy'."
                )
            yield 1, first_row[0], first_row[1]
            accession_index = None
            lineage_index = None

        line_number = 1
        if accession_index is not None and lineage_index is not None:
            for row in reader:
                line_number += 1
                if not row:
                    continue
                if max(accession_index, lineage_index) >= len(row):
                    raise ValueError(
                        f"Invalid GTDB taxonomy row at line {line_number}: missing required columns."
                    )
                yield line_number, row[accession_index], row[lineage_index]
        else:
            for row in reader:
                line_number += 1
                if not row:
                    continue
                if len(row) != 2:
                    raise ValueError(
                        f"Invalid GTDB taxonomy row at line {line_number}: expected 2 tab-separated columns."
                    )
                yield line_number, row[0], row[1]


def summarize_taxonomy_file(path: str | Path) -> GtdbTaxonomySummary:
    """Stream a GTDB taxonomy TSV and compute summary counts."""

    taxonomy_path = Path(path)
    genomes = 0
    unique_lineages: set[str] = set()
    unique_taxa = {rank: set() for rank in GTDB_RANKS}
    missing_rank_counts = {rank: 0 for rank in GTDB_RANKS}

    for line_number, accession, lineage in _iter_taxonomy_rows(taxonomy_path):
        if not accession:
            raise ValueError(f"Invalid GTDB taxonomy row at line {line_number}: empty accession.")
        if not lineage:
            raise ValueError(f"Invalid GTDB taxonomy row at line {line_number}: empty taxonomy.")

        genomes += 1
        unique_lineages.add(lineage)
        parsed = parse_gtdb_taxonomy_lineage(lineage)
        for rank in GTDB_RANKS:
            value = parsed.get(rank)
            if value:
                unique_taxa[rank].add(value)
            else:
                missing_rank_counts[rank] += 1

    if genomes == 0:
        raise ValueError("The GTDB taxonomy file is empty.")

    rank_counts = {rank: len(values) for rank, values in unique_taxa.items()}
    return GtdbTaxonomySummary(
        genomes=genomes,
        unique_lineages=len(unique_lineages),
        rank_counts=rank_counts,
        missing_rank_counts=missing_rank_counts,
    )


def iter_taxonomy_records(path: str | Path):
    """Yield parsed GTDB taxonomy records from a taxonomy TSV or metadata table."""

    taxonomy_path = Path(path)
    for line_number, accession, lineage in _iter_taxonomy_rows(taxonomy_path):
        if not accession:
            raise ValueError(f"Invalid GTDB taxonomy row at line {line_number}: empty accession.")
        if not lineage:
            raise ValueError(f"Invalid GTDB taxonomy row at line {line_number}: empty taxonomy.")
        yield GtdbTaxonomyRecord(
            accession=accession,
            lineage=lineage,
            ranks=parse_gtdb_taxonomy_lineage(lineage),
        )


def summarize_tar_archive(path: str | Path, max_samples: int = 5) -> ArchiveSummary:
    """Inspect a tar archive and report file-type composition."""

    archive_path = Path(path)
    member_count = 0
    suffix_counts: dict[str, int] = {}
    sample_members: list[str] = []

    with tarfile.open(archive_path, "r:*") as archive:
        for member in archive:
            if not member.isfile():
                continue

            member_count += 1
            suffix = "".join(Path(member.name).suffixes) or "<no_suffix>"
            suffix_counts[suffix] = suffix_counts.get(suffix, 0) + 1
            if len(sample_members) < max_samples:
                sample_members.append(member.name)

    return ArchiveSummary(
        path=str(archive_path.resolve()),
        member_count=member_count,
        suffix_counts=dict(sorted(suffix_counts.items())),
        sample_members=sample_members,
    )
