"""Fulgor index construction and query helpers."""

from __future__ import annotations

import csv
from dataclasses import asdict, dataclass
import gzip
import json
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import tarfile
import tempfile
from typing import Any, Callable, Mapping, Sequence

ProgressCallback = Callable[[str, Mapping[str, Any]], None]

DEFAULT_KMER_LENGTH = 21
DEFAULT_MINIMIZER_LENGTH = 15
DEFAULT_FULGOR_THREADS = 1
DEFAULT_GGCAT_THREADS = 1
DEFAULT_INDEX_PENALTY_WEIGHT = 1.0

_SUPPORTED_FASTA_SUFFIXES = (
    ".fa",
    ".fa.gz",
    ".fasta",
    ".fasta.gz",
    ".fna",
    ".fna.gz",
)
_ACCESSION_PATTERN = re.compile(r"(GC[AF]_\d+\.\d+)")


@dataclass(slots=True, frozen=True)
class GenomeReference:
    reference_name: str
    source_member: str
    extracted_path: str
    raw_accession: str | None
    normalized_accession: str | None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class FulgorIndexBuildResult:
    input_mode: str
    genome_archive: str | None
    genome_files: list[str]
    output_prefix: str
    fulgor_binary: str
    index_file: str
    reference_map_file: str
    summary_file: str
    stdout_log_file: str
    stderr_log_file: str
    kmer_length: int
    minimizer_length: int
    threads: int
    ggcat_threads: int
    extracted_references: int
    indexed_references: int
    taxon: str | None
    release: str | None
    output_files: dict[str, str]

    def to_summary_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["dataset_type"] = "fulgor_index"
        payload["genome_file_count"] = len(self.genome_files)
        payload["index_filename"] = Path(self.index_file).name
        payload["reference_map_filename"] = Path(self.reference_map_file).name
        payload["summary_filename"] = Path(self.summary_file).name
        payload["index_format"] = "fulgor"
        return payload


@dataclass(slots=True, frozen=True)
class FulgorIndexConfig:
    index_file: str
    reference_map_file: str
    summary_file: str
    kmer_length: int | None
    taxon: str | None
    release: str | None


def _emit_progress(progress_callback: ProgressCallback | None, event: str, **payload: Any) -> None:
    if progress_callback is not None:
        progress_callback(event, payload)


def _index_path_from_prefix(output_prefix: Path) -> Path:
    if output_prefix.suffix == ".fur":
        return output_prefix
    return output_prefix.with_name(f"{output_prefix.name}.fur")


def _summary_path_from_prefix(output_prefix: Path) -> Path:
    return output_prefix.with_name(f"{output_prefix.name}_summary.json")


def _reference_map_path_from_prefix(output_prefix: Path) -> Path:
    return output_prefix.with_name(f"{output_prefix.name}_reference_map.csv")


def _stdout_log_path_from_prefix(output_prefix: Path) -> Path:
    return output_prefix.with_name(f"{output_prefix.name}_build.stdout.log")


def _stderr_log_path_from_prefix(output_prefix: Path) -> Path:
    return output_prefix.with_name(f"{output_prefix.name}_build.stderr.log")


def _looks_like_fasta_member(member_name: str) -> bool:
    lowered = member_name.lower()
    return any(lowered.endswith(suffix) for suffix in _SUPPORTED_FASTA_SUFFIXES)


def _strip_gzip_suffix(path: Path) -> Path:
    if path.suffix.lower() == ".gz":
        return path.with_suffix("")
    return path


def _member_output_path(extraction_root: Path, member_name: str) -> Path:
    relative = PurePosixPath(member_name)
    parts = [part for part in relative.parts if part not in {"", ".", ".."}]
    if not parts:
        raise ValueError(f"Invalid archive member path: {member_name}")
    output = extraction_root.joinpath(*parts)
    if output.suffix == ".gz":
        output = output.with_suffix("")
    return output


def _normalize_gtdb_accession(raw_accession: str | None) -> str | None:
    if not raw_accession:
        return None
    normalized = raw_accession.strip()
    if normalized.startswith(("RS_", "GB_")):
        return normalized
    if normalized.startswith("GCF_"):
        return f"RS_{normalized}"
    if normalized.startswith("GCA_"):
        return f"GB_{normalized}"
    return normalized


def _extract_accession_from_name(name: str) -> tuple[str | None, str | None]:
    match = _ACCESSION_PATTERN.search(name)
    if match is None:
        return None, None
    raw_accession = match.group(1)
    return raw_accession, _normalize_gtdb_accession(raw_accession)


def _extract_references_from_archive(
    genome_archive: str | Path,
    extraction_root: Path,
    *,
    progress_callback: ProgressCallback | None = None,
) -> list[GenomeReference]:
    archive_path = Path(genome_archive).expanduser().resolve()
    extraction_root.mkdir(parents=True, exist_ok=True)

    references: list[GenomeReference] = []
    total_members = 0
    with tarfile.open(archive_path, "r:*") as archive:
        for member in archive:
            if member.isfile() and _looks_like_fasta_member(member.name):
                total_members += 1

    _emit_progress(
        progress_callback,
        "reference_extraction_started",
        total_references=total_members,
        input_mode="archive",
    )
    completed = 0
    with tarfile.open(archive_path, "r:*") as archive:
        for member in archive:
            if not (member.isfile() and _looks_like_fasta_member(member.name)):
                continue
            extracted = archive.extractfile(member)
            if extracted is None:
                raise ValueError(f"Unable to read genome member from archive: {member.name}")
            output_path = _member_output_path(extraction_root, member.name)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            with output_path.open("wb") as handle:
                if member.name.lower().endswith(".gz"):
                    with gzip.GzipFile(fileobj=extracted) as decompressed:
                        shutil.copyfileobj(decompressed, handle)
                else:
                    shutil.copyfileobj(extracted, handle)
            raw_accession, normalized_accession = _extract_accession_from_name(member.name)
            reference_name = str(output_path.resolve())
            references.append(
                GenomeReference(
                    reference_name=reference_name,
                    source_member=member.name,
                    extracted_path=reference_name,
                    raw_accession=raw_accession,
                    normalized_accession=normalized_accession,
                )
            )
            completed += 1
            _emit_progress(
                progress_callback,
                "reference_extraction_advanced",
                completed=completed,
                total_references=total_members,
                input_mode="archive",
            )
    _emit_progress(
        progress_callback,
        "reference_extraction_completed",
        total_references=total_members,
        input_mode="archive",
    )
    if not references:
        raise ValueError(f"No FASTA genome members were found in archive: {archive_path}")
    return references


def _copy_reference_file(source_path: Path, output_path: Path) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    if source_path.suffix.lower() == ".gz":
        with gzip.open(source_path, "rb") as source_handle, output_path.open("wb") as output_handle:
            shutil.copyfileobj(source_handle, output_handle)
        return
    shutil.copyfile(source_path, output_path)


def _prepare_references_from_files(
    genome_files: Sequence[str | Path],
    extraction_root: Path,
    *,
    progress_callback: ProgressCallback | None = None,
) -> list[GenomeReference]:
    resolved_files = [Path(path).expanduser().resolve() for path in genome_files]
    if not resolved_files:
        raise ValueError("At least one genome FASTA file must be provided.")

    extraction_root.mkdir(parents=True, exist_ok=True)
    _emit_progress(
        progress_callback,
        "reference_extraction_started",
        total_references=len(resolved_files),
        input_mode="files",
    )

    references: list[GenomeReference] = []
    for index, source_path in enumerate(resolved_files, start=1):
        if not source_path.exists():
            raise ValueError(f"Genome file does not exist: {source_path}")
        if not source_path.is_file():
            raise ValueError(f"Genome path is not a file: {source_path}")
        if not _looks_like_fasta_member(source_path.name):
            raise ValueError(
                "Genome file does not look like a supported FASTA file "
                f"(.fa/.fasta/.fna with optional .gz): {source_path}"
            )

        output_name = f"{index:05d}_{_strip_gzip_suffix(source_path).name}"
        output_path = extraction_root / output_name
        _copy_reference_file(source_path, output_path)

        raw_accession, normalized_accession = _extract_accession_from_name(source_path.name)
        materialized_path = str(output_path.resolve())
        references.append(
            GenomeReference(
                reference_name=materialized_path,
                source_member=str(source_path),
                extracted_path=materialized_path,
                raw_accession=raw_accession,
                normalized_accession=normalized_accession,
            )
        )
        _emit_progress(
            progress_callback,
            "reference_extraction_advanced",
            completed=index,
            total_references=len(resolved_files),
            input_mode="files",
        )

    _emit_progress(
        progress_callback,
        "reference_extraction_completed",
        total_references=len(resolved_files),
        input_mode="files",
    )
    return references


def _write_reference_list(path: Path, references: Sequence[GenomeReference]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for reference in references:
            handle.write(reference.reference_name)
            handle.write("\n")


def _run_subprocess(command: Sequence[str], *, stdout_path: Path, stderr_path: Path) -> subprocess.CompletedProcess[str]:
    stdout_path.parent.mkdir(parents=True, exist_ok=True)
    stderr_path.parent.mkdir(parents=True, exist_ok=True)
    with stdout_path.open("w", encoding="utf-8") as stdout_handle, stderr_path.open("w", encoding="utf-8") as stderr_handle:
        completed = subprocess.run(
            list(command),
            check=False,
            stdout=stdout_handle,
            stderr=stderr_handle,
            text=True,
        )
    if completed.returncode != 0:
        raise ValueError(
            f"Command failed with exit code {completed.returncode}: {' '.join(command)}. "
            f"See {stderr_path} for details."
        )
    return completed


def _load_print_filenames_output(stdout_path: Path) -> list[str]:
    lines = [line.strip() for line in stdout_path.read_text(encoding="utf-8").splitlines()]
    return [line for line in lines if line]


def _write_reference_map(
    reference_map_path: Path,
    printed_references: Sequence[str],
    references_by_name: Mapping[str, GenomeReference],
) -> None:
    reference_map_path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "reference_id",
        "reference_name",
        "source_member",
        "extracted_path",
        "raw_accession",
        "normalized_accession",
    ]
    with reference_map_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for reference_id, reference_name in enumerate(printed_references):
            try:
                reference = references_by_name[reference_name]
            except KeyError as exc:
                raise ValueError(
                    "Fulgor returned a reference name that does not match the extracted inputs: "
                    f"{reference_name}"
                ) from exc
            writer.writerow(
                {
                    "reference_id": reference_id,
                    "reference_name": reference_name,
                    "source_member": reference.source_member,
                    "extracted_path": reference.extracted_path,
                    "raw_accession": reference.raw_accession,
                    "normalized_accession": reference.normalized_accession,
                }
            )


def build_fulgor_index(
    *,
    genome_archive: str | Path | None = None,
    genome_files: Sequence[str | Path] | None = None,
    output_prefix: str | Path,
    fulgor_binary: str | Path = "fulgor",
    kmer_length: int = DEFAULT_KMER_LENGTH,
    minimizer_length: int = DEFAULT_MINIMIZER_LENGTH,
    threads: int = DEFAULT_FULGOR_THREADS,
    ggcat_threads: int = DEFAULT_GGCAT_THREADS,
    tmp_dir: str | Path | None = None,
    keep_extracted: bool = False,
    check: bool = True,
    taxon: str | None = None,
    release: str | None = None,
    progress_callback: ProgressCallback | None = None,
) -> FulgorIndexBuildResult:
    if kmer_length < 1:
        raise ValueError("--kmer-length must be at least 1.")
    if minimizer_length < 1:
        raise ValueError("--minimizer-length must be at least 1.")
    if minimizer_length >= kmer_length:
        raise ValueError("--minimizer-length must be smaller than --kmer-length.")
    if threads < 1:
        raise ValueError("--threads must be at least 1.")
    if ggcat_threads < 1:
        raise ValueError("--ggcat-threads must be at least 1.")

    resolved_archive = None if genome_archive is None else Path(genome_archive).expanduser().resolve()
    resolved_genome_files = [] if genome_files is None else [Path(path).expanduser().resolve() for path in genome_files]
    if resolved_archive is not None and resolved_genome_files:
        raise ValueError("Provide either --genome-archive or --genome-file, not both.")
    if resolved_archive is None and not resolved_genome_files:
        raise ValueError("Provide either --genome-archive or at least one --genome-file.")

    resolved_prefix = Path(output_prefix).expanduser().resolve()
    resolved_prefix.parent.mkdir(parents=True, exist_ok=True)
    index_path = _index_path_from_prefix(resolved_prefix)
    summary_path = _summary_path_from_prefix(resolved_prefix)
    reference_map_path = _reference_map_path_from_prefix(resolved_prefix)
    stdout_log_path = _stdout_log_path_from_prefix(resolved_prefix)
    stderr_log_path = _stderr_log_path_from_prefix(resolved_prefix)

    with tempfile.TemporaryDirectory(prefix="phyloprobe-index-") as working_dir:
        work_root = Path(working_dir)
        extraction_root = (
            Path(tmp_dir).expanduser().resolve()
            if tmp_dir is not None
            else work_root / "genomes"
        )
        build_tmp_dir = (
            (Path(tmp_dir).expanduser().resolve() / "fulgor_tmp")
            if tmp_dir is not None
            else work_root / "fulgor_tmp"
        )

        if resolved_archive is not None:
            references = _extract_references_from_archive(
                resolved_archive,
                extraction_root,
                progress_callback=progress_callback,
            )
            input_mode = "archive"
        else:
            references = _prepare_references_from_files(
                resolved_genome_files,
                extraction_root,
                progress_callback=progress_callback,
            )
            input_mode = "files"
        reference_list_path = work_root / "reference_paths.txt"
        _write_reference_list(reference_list_path, references)

        build_command = [
            str(fulgor_binary),
            "build",
            "-l",
            str(reference_list_path),
            "-o",
            str(resolved_prefix),
            "-k",
            str(kmer_length),
            "-m",
            str(minimizer_length),
            "-d",
            str(build_tmp_dir),
            "-g",
            str(ggcat_threads),
            "-t",
            str(threads),
            "--verbose",
        ]
        if check:
            build_command.append("--check")

        _emit_progress(progress_callback, "index_build_started", references=len(references))
        _run_subprocess(build_command, stdout_path=stdout_log_path, stderr_path=stderr_log_path)
        _emit_progress(progress_callback, "index_build_completed", references=len(references))

        if not index_path.exists():
            raise ValueError(f"Fulgor did not produce the expected index file: {index_path}")

        print_stdout_path = work_root / "print_filenames.stdout.log"
        print_stderr_path = work_root / "print_filenames.stderr.log"
        _emit_progress(progress_callback, "reference_map_started", references=len(references))
        _run_subprocess(
            [str(fulgor_binary), "print-filenames", "-i", str(index_path)],
            stdout_path=print_stdout_path,
            stderr_path=print_stderr_path,
        )
        printed_references = _load_print_filenames_output(print_stdout_path)
        references_by_name = {reference.reference_name: reference for reference in references}
        _write_reference_map(reference_map_path, printed_references, references_by_name)
        _emit_progress(progress_callback, "reference_map_completed", references=len(printed_references))

        if not keep_extracted and tmp_dir is not None and extraction_root.exists():
            shutil.rmtree(extraction_root)

    result = FulgorIndexBuildResult(
        input_mode=input_mode,
        genome_archive=None if resolved_archive is None else str(resolved_archive),
        genome_files=[str(path) for path in resolved_genome_files],
        output_prefix=str(resolved_prefix),
        fulgor_binary=str(fulgor_binary),
        index_file=str(index_path),
        reference_map_file=str(reference_map_path),
        summary_file=str(summary_path),
        stdout_log_file=str(stdout_log_path),
        stderr_log_file=str(stderr_log_path),
        kmer_length=kmer_length,
        minimizer_length=minimizer_length,
        threads=threads,
        ggcat_threads=ggcat_threads,
        extracted_references=len(references),
        indexed_references=len(printed_references),
        taxon=taxon,
        release=release,
        output_files={
            "index": str(index_path),
            "reference_map": str(reference_map_path),
            "summary": str(summary_path),
            "stdout_log": str(stdout_log_path),
            "stderr_log": str(stderr_log_path),
        },
    )
    with summary_path.open("w", encoding="utf-8") as handle:
        json.dump(result.to_summary_dict(), handle, indent=2, sort_keys=True)
        handle.write("\n")
    return result


def load_index_summary(summary_file: str | Path) -> FulgorIndexConfig:
    summary_path = Path(summary_file).expanduser().resolve()
    with summary_path.open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    dataset_type = str(payload.get("dataset_type") or "").strip()
    if dataset_type and dataset_type != "fulgor_index":
        raise ValueError(f"Index summary file does not describe a Fulgor index: {summary_path}")
    index_file = payload.get("index_file")
    reference_map_file = payload.get("reference_map_file")
    if not index_file or not reference_map_file:
        raise ValueError(f"Index summary is missing required file paths: {summary_path}")
    kmer_length = payload.get("kmer_length")
    return FulgorIndexConfig(
        index_file=str(index_file),
        reference_map_file=str(reference_map_file),
        summary_file=str(summary_path),
        kmer_length=None if kmer_length in (None, "") else int(kmer_length),
        taxon=(str(payload.get("taxon") or "").strip() or None),
        release=(str(payload.get("release") or "").strip() or None),
    )


def load_reference_map(reference_map_file: str | Path) -> dict[int, str]:
    mapping: dict[int, str] = {}
    with Path(reference_map_file).expanduser().resolve().open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            normalized_accession = (row.get("normalized_accession") or "").strip()
            raw_accession = (row.get("raw_accession") or "").strip()
            source_member = (row.get("source_member") or "").strip()
            reference_name = (row.get("reference_name") or "").strip()
            identifier = normalized_accession or raw_accession or source_member or reference_name
            if not identifier:
                continue
            try:
                reference_id = int(row["reference_id"])
            except (KeyError, TypeError, ValueError) as exc:
                raise ValueError(f"Invalid reference map row in {reference_map_file}") from exc
            mapping[reference_id] = identifier
    if not mapping:
        raise ValueError(f"No usable reference identifiers were found in {reference_map_file}")
    return mapping


def _write_query_fasta(path: Path, sequences: Sequence[str]) -> dict[str, str]:
    path.parent.mkdir(parents=True, exist_ok=True)
    mapping: dict[str, str] = {}
    with path.open("w", encoding="utf-8") as handle:
        for index, sequence in enumerate(sequences, start=1):
            query_id = f"probe_{index}"
            mapping[query_id] = sequence
            handle.write(f">{query_id}\n{sequence}\n")
    return mapping


def query_fulgor_index(
    *,
    index_file: str | Path,
    reference_map_file: str | Path,
    query_sequences: Sequence[str],
    fulgor_binary: str | Path = "fulgor",
    threads: int = DEFAULT_FULGOR_THREADS,
    working_dir: str | Path | None = None,
    label: str | None = None,
    progress_callback: ProgressCallback | None = None,
) -> dict[str, set[str]]:
    if threads < 1:
        raise ValueError("--index-threads must be at least 1.")
    unique_sequences = sorted({sequence.strip().upper() for sequence in query_sequences if sequence.strip()})
    if not unique_sequences:
        return {}

    reference_map = load_reference_map(reference_map_file)
    results: dict[str, set[str]] = {sequence: set() for sequence in unique_sequences}

    with tempfile.TemporaryDirectory(prefix="phyloprobe-index-query-", dir=None if working_dir is None else str(Path(working_dir).expanduser().resolve())) as temp_dir:
        temp_root = Path(temp_dir)
        query_fasta = temp_root / "queries.fa"
        output_path = temp_root / "pseudoalign.tsv"
        stdout_path = temp_root / "pseudoalign.stdout.log"
        stderr_path = temp_root / "pseudoalign.stderr.log"
        query_ids = _write_query_fasta(query_fasta, unique_sequences)

        _emit_progress(progress_callback, "index_query_started", queries=len(unique_sequences), label=label)
        _run_subprocess(
            [
                str(fulgor_binary),
                "pseudoalign",
                "-i",
                str(Path(index_file).expanduser().resolve()),
                "-q",
                str(query_fasta),
                "-t",
                str(threads),
                "-o",
                str(output_path),
                "--verbose",
            ],
            stdout_path=stdout_path,
            stderr_path=stderr_path,
        )
        _emit_progress(progress_callback, "index_query_completed", queries=len(unique_sequences), label=label)

        if not output_path.exists():
            return results
        for raw_line in output_path.read_text(encoding="utf-8").splitlines():
            line = raw_line.strip()
            if not line:
                continue
            parts = line.split("\t")
            if len(parts) < 2:
                raise ValueError(f"Invalid Fulgor pseudoalign output line: {line}")
            query_id = parts[0]
            sequence = query_ids.get(query_id)
            if sequence is None:
                continue
            try:
                count = int(parts[1])
            except ValueError as exc:
                raise ValueError(f"Invalid Fulgor pseudoalign output line: {line}") from exc
            reference_ids: list[int] = []
            for token in parts[2 : 2 + count]:
                try:
                    reference_ids.append(int(token))
                except ValueError as exc:
                    raise ValueError(f"Invalid Fulgor pseudoalign output line: {line}") from exc
            for reference_id in reference_ids:
                accession = reference_map.get(reference_id)
                if accession:
                    results[sequence].add(accession)
    return results
