"""Module entry point for ``python -m phyloprobe``."""

from __future__ import annotations

from phyloprobe.cli import main


if __name__ == "__main__":
    raise SystemExit(main())
