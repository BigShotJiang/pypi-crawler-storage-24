"""MSA-guided conserved region discovery."""

from __future__ import annotations

import csv
from dataclasses import dataclass
import json
from pathlib import Path
import sys
import tarfile
from typing import Any, Callable, Mapping, Sequence

from phyloprobe.gtdb import iter_taxonomy_records
from phyloprobe.parallel import DEFAULT_AUTO_WORKERS, build_chunks, iter_chunk_results, resolve_worker_count
from phyloprobe.profile_defaults import (
    get_stage_default_profile,
    get_stage_profile_defaults,
    get_stage_profile_names,
)
from phyloprobe.taxon_scope import (
    taxon_constraint_payload,
    taxonomy_record_matches_scope,
    validate_taxon_constraint_overlap,
)

ProgressCallback = Callable[[str, Mapping[str, Any]], None]

DEFAULT_WINDOW_AA_LENGTH = 12
DEFAULT_WINDOW_AA_LENGTH_MIN = 10
DEFAULT_WINDOW_AA_LENGTH_MAX = 16
DEFAULT_TOP_REGIONS_PER_MARKER = 5
DEFAULT_MIN_TARGET_COLUMN_OCCUPANCY = 0.9
DEFAULT_MIN_TARGET_CONSENSUS = 0.9
DEFAULT_MIN_TARGET_WINDOW_PRESENCE = 0.75
DEFAULT_MAX_AA_MISMATCHES = 1
DEFAULT_AA_MISMATCH_PENALTY_PER_MISMATCH = 0.25
DEFAULT_REGION_PROBE_LENGTH = 30
DEFAULT_MIN_TARGET_REMAP_FRACTION = 0.5
DEFAULT_MIN_BEST_PROBE_SUPPORT_FRACTION = 0.5
DEFAULT_PROBEABILITY_WEIGHT = 0.5
DEFAULT_SIBLING_PENALTY_WEIGHT = 2.0
DEFAULT_GLOBAL_PENALTY_WEIGHT = 1.0
DEFAULT_DISCOVERY_PROFILE = get_stage_default_profile("regions")
VALID_DISCOVERY_PROFILES = set(get_stage_profile_names("regions"))

_CORE_TARGET_COLUMNS = {
    "barcode",
    "resolved_level",
    "resolved_taxon",
    "parent_level",
    "parent_taxon",
    "marker_id",
    "member_name",
    "sequence_count",
    "min_nt_length",
    "max_nt_length",
    "mean_nt_length",
    "target_taxonomy_genomes",
    "target_marker_available_genomes",
    "target_hits",
    "target_occupancy",
    "sibling_taxonomy_genomes",
    "sibling_marker_available_genomes",
    "sibling_hits",
    "sibling_offtarget_rate",
    "global_non_target_marker_available_genomes",
    "global_offtarget_hits",
    "global_offtarget_rate",
    "score",
    "rank_within_target",
}


@dataclass(slots=True)
class TargetMarkerRequest:
    barcode: str
    resolved_level: str
    resolved_taxon: str
    marker_id: str
    lineage: dict[str, str | None]
    parent_level: str | None
    parent_taxon: str | None
    marker_rank_within_target: int


@dataclass(slots=True)
class _ResolvedTargetContext:
    request: TargetMarkerRequest
    taxonomy_accessions: set[str]
    sibling_accessions: set[str]
    global_accessions: set[str]
    inferred_lineage: dict[str, str | None]
    parent_level: str | None
    parent_taxon: str | None


@dataclass(slots=True)
class MsaProfile:
    marker_id: str
    member_name: str
    sequences: dict[str, str]
    aligned_length: int


@dataclass(slots=True)
class MarkerNucleotideProfile:
    marker_id: str
    member_name: str
    sequences: dict[str, str]


@dataclass(slots=True)
class _RegionScanOutcome:
    summary_row: dict[str, Any]
    selected_regions: list[dict[str, Any]]
    remap_rows: list[dict[str, Any]]
    selected_target_marker_row: dict[str, Any]


@dataclass(slots=True)
class _WindowMatchStats:
    full_window_count: int
    exact_count: int
    near_count: int
    effective_support: float
    anchor_full_accession: str | None = None
    anchor_exact_accession: str | None = None


@dataclass(slots=True)
class _ProbeabilityStats:
    mapped_target_sequences: int
    remap_fraction: float
    probeable_positions: int
    probeable_positions_fraction: float
    best_probe_support_fraction: float
    best_probe_consensus_sequence: str | None
    probeability_score: float


@dataclass(slots=True)
class RegionDiscoveryResult:
    dataset: str | None
    taxonomy_file: str
    msa_archive: str
    markers_archive: str | None
    target_discovery_prefix: str
    target_region_summary: list[dict[str, Any]]
    selected_target_markers: list[dict[str, Any]]
    marker_region_summary: list[dict[str, Any]]
    region_candidates: list[dict[str, Any]]
    region_remap_manifest: list[dict[str, Any]]
    analyzed_markers: int
    discovery_profile: str
    window_aa_length: int
    window_aa_length_min: int
    window_aa_length_max: int
    top_regions_per_marker: int
    include_taxa: dict[str, list[str]]
    exclude_taxa: dict[str, list[str]]
    min_target_column_occupancy: float
    min_target_consensus: float
    min_target_window_presence: float
    max_aa_mismatches: int
    aa_mismatch_penalty_per_mismatch: float
    region_probe_length: int
    min_target_remap_fraction: float
    min_best_probe_support_fraction: float
    probeability_weight: float
    sibling_penalty_weight: float
    global_penalty_weight: float
    output_files: dict[str, str] | None = None

    def to_summary_dict(self) -> dict[str, object]:
        return {
            "dataset": self.dataset,
            "taxonomy_file": self.taxonomy_file,
            "msa_archive": self.msa_archive,
            "markers_archive": self.markers_archive,
            "target_discovery_prefix": self.target_discovery_prefix,
            "target_region_summary": self.target_region_summary,
            "selected_target_markers": self.selected_target_markers,
            "analyzed_markers": self.analyzed_markers,
            "profile": self.discovery_profile,
            "discovery_profile": self.discovery_profile,
            "window_aa_length": self.window_aa_length,
            "window_aa_length_min": self.window_aa_length_min,
            "window_aa_length_max": self.window_aa_length_max,
            "top_regions_per_marker": self.top_regions_per_marker,
            "include_taxa": self.include_taxa,
            "exclude_taxa": self.exclude_taxa,
            "min_target_column_occupancy": self.min_target_column_occupancy,
            "min_target_consensus": self.min_target_consensus,
            "min_target_window_presence": self.min_target_window_presence,
            "max_aa_mismatches": self.max_aa_mismatches,
            "aa_mismatch_penalty_per_mismatch": self.aa_mismatch_penalty_per_mismatch,
            "region_probe_length": self.region_probe_length,
            "min_target_remap_fraction": self.min_target_remap_fraction,
            "min_best_probe_support_fraction": self.min_best_probe_support_fraction,
            "probeability_weight": self.probeability_weight,
            "sibling_penalty_weight": self.sibling_penalty_weight,
            "global_penalty_weight": self.global_penalty_weight,
            "output_files": self.output_files,
        }


def _emit_progress(progress_callback: ProgressCallback | None, event: str, **payload: Any) -> None:
    if progress_callback is not None:
        progress_callback(event, payload)


def _mean(values: Sequence[float]) -> float | None:
    if not values:
        return None
    return sum(values) / float(len(values))


def validate_discovery_profile(name: str) -> str:
    normalized = str(name).strip().lower()
    if normalized not in VALID_DISCOVERY_PROFILES:
        valid = ", ".join(sorted(VALID_DISCOVERY_PROFILES))
        raise ValueError(f"Unsupported region discovery profile '{name}'. Choose one of: {valid}.")
    return normalized


def _region_profile_defaults(profile: str) -> dict[str, float | int]:
    return get_stage_profile_defaults("regions", profile)


_REGION_SCORING_STATE: tuple[
    Sequence[_ResolvedTargetContext],
    Mapping[str, MsaProfile],
    Mapping[str, MarkerNucleotideProfile] | None,
    int,
    int,
    int,
    int,
    float,
    float,
    float,
    int,
    float,
    int,
    float,
    float,
    float,
    float,
    float,
] | None = None


def _safe_rate(numerator: float | int, denominator: float | int) -> float:
    if denominator <= 0:
        return 0.0
    return float(numerator) / float(denominator)


def _read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def _read_target_marker_requests(
    target_discovery_prefix: str | Path,
) -> tuple[list[str], list[TargetMarkerRequest], dict[str, Any]]:
    prefix = Path(target_discovery_prefix).expanduser().resolve()
    summary_path = prefix.with_name(f"{prefix.name}_summary.json")
    manifest_path = prefix.with_name(f"{prefix.name}_top_marker_manifest.csv")
    if not summary_path.exists():
        raise ValueError(f"Target-discovery summary file not found: {summary_path}")
    if not manifest_path.exists():
        raise ValueError(f"Target-discovery top marker manifest not found: {manifest_path}")

    target_summary = _read_json(summary_path)
    tag_prefix = Path(str(target_summary.get("tag_design_prefix") or "")).expanduser().resolve()
    tag_summary_path = tag_prefix.with_name(f"{tag_prefix.name}_summary.json")
    if not tag_summary_path.exists():
        raise ValueError(f"Tag-design summary file not found from target discovery context: {tag_summary_path}")
    tag_summary = _read_json(tag_summary_path)
    levels = list(tag_summary.get("levels") or [])
    if not levels:
        raise ValueError(f"Tag-design summary does not contain levels: {tag_summary_path}")

    requests: list[TargetMarkerRequest] = []
    with manifest_path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            barcode = (row.get("barcode") or "").strip()
            resolved_level = (row.get("resolved_level") or "").strip()
            resolved_taxon = (row.get("resolved_taxon") or "").strip()
            marker_id = (row.get("marker_id") or "").strip()
            if not barcode or not resolved_level or not resolved_taxon or not marker_id:
                continue
            lineage = {}
            for level in levels:
                value = (row.get(level) or "").strip()
                lineage[level] = value or None
            try:
                rank = int(row.get("rank_within_target") or 0)
            except ValueError:
                rank = 0
            requests.append(
                TargetMarkerRequest(
                    barcode=barcode,
                    resolved_level=resolved_level,
                    resolved_taxon=resolved_taxon,
                    marker_id=marker_id,
                    lineage=lineage,
                    parent_level=(row.get("parent_level") or "").strip() or None,
                    parent_taxon=(row.get("parent_taxon") or "").strip() or None,
                    marker_rank_within_target=rank,
                )
            )
    if not requests:
        raise ValueError(f"No target marker requests were found in: {manifest_path}")
    return levels, requests, target_summary


def _request_matches_taxonomy(
    ranks: Mapping[str, str],
    request: TargetMarkerRequest,
    levels: Sequence[str],
) -> bool:
    explicit_matches = False
    for level in levels:
        expected = request.lineage.get(level)
        if not expected:
            continue
        explicit_matches = True
        if ranks.get(level) != expected:
            return False
    if explicit_matches:
        return True
    return ranks.get(request.resolved_level) == request.resolved_taxon


def _infer_target_contexts(
    taxonomy_file: str | Path,
    requests: Sequence[TargetMarkerRequest],
    levels: Sequence[str],
    *,
    include_taxa: Mapping[str, set[str]] | None = None,
    exclude_taxa: Mapping[str, set[str]] | None = None,
    progress_callback: ProgressCallback | None = None,
) -> list[_ResolvedTargetContext]:
    contexts = [
        _ResolvedTargetContext(
            request=request,
            taxonomy_accessions=set(),
            sibling_accessions=set(),
            global_accessions=set(),
            inferred_lineage={level: request.lineage.get(level) for level in levels},
            parent_level=request.parent_level,
            parent_taxon=request.parent_taxon,
        )
        for request in requests
    ]
    inferred_sets = [{level: set() for level in levels} for _ in requests]
    filtered_records = []
    filtered_accessions: set[str] = set()

    _emit_progress(progress_callback, "taxonomy_resolution_started", requests=len(requests))
    for record in iter_taxonomy_records(taxonomy_file):
        if not taxonomy_record_matches_scope(
            record.ranks,
            include_taxa=include_taxa,
            exclude_taxa=exclude_taxa,
        ):
            continue
        filtered_records.append(record)
        accession = sys.intern(record.accession)
        filtered_accessions.add(accession)
        for index, context in enumerate(contexts):
            if _request_matches_taxonomy(record.ranks, context.request, levels):
                context.taxonomy_accessions.add(accession)
                for level in levels:
                    value = record.ranks.get(level)
                    if value:
                        inferred_sets[index][level].add(value)

    for index, context in enumerate(contexts):
        for level in levels:
            if context.inferred_lineage.get(level):
                continue
            values = inferred_sets[index][level]
            if len(values) == 1:
                context.inferred_lineage[level] = next(iter(values))
        if context.parent_level is None or context.parent_taxon is None:
            resolved_index = levels.index(context.request.resolved_level)
            for level in reversed(levels[:resolved_index]):
                value = context.inferred_lineage.get(level)
                if value:
                    context.parent_level = level
                    context.parent_taxon = value
                    break

    for record in filtered_records:
        accession = sys.intern(record.accession)
        for context in contexts:
            if accession in context.taxonomy_accessions:
                continue
            if context.parent_level and context.parent_taxon:
                parent_index = levels.index(context.parent_level)
                matches_parent = True
                for level in levels[: parent_index + 1]:
                    expected = context.inferred_lineage.get(level)
                    if expected and record.ranks.get(level) != expected:
                        matches_parent = False
                    break
                if matches_parent:
                    context.sibling_accessions.add(accession)
            else:
                context.sibling_accessions.add(accession)
    for context in contexts:
        context.global_accessions = set(filtered_accessions) - set(context.taxonomy_accessions)

    _emit_progress(progress_callback, "taxonomy_resolution_completed", requests=len(requests))
    return contexts


def _msa_marker_id_from_member_name(member_name: str) -> str:
    stem = Path(member_name).stem
    parts = stem.split("_")
    if len(parts) >= 4 and parts[2] == "reps":
        return "_".join(parts[3:])
    return stem


def _marker_id_from_member_name(member_name: str) -> str:
    return Path(member_name).stem


def _count_selected_msa_members(msa_archive: str | Path, selected_marker_ids: set[str]) -> int:
    count = 0
    with tarfile.open(Path(msa_archive).expanduser().resolve(), "r:*") as archive:
        for member in archive:
            if not (member.isfile() and member.name.endswith(".faa")):
                continue
            marker_id = _msa_marker_id_from_member_name(member.name)
            if marker_id in selected_marker_ids:
                    count += 1
    return count


def _count_selected_marker_members(markers_archive: str | Path, selected_marker_ids: set[str]) -> int:
    count = 0
    with tarfile.open(Path(markers_archive).expanduser().resolve(), "r:*") as archive:
        for member in archive:
            if member.isfile() and member.name.endswith(".fna"):
                if _marker_id_from_member_name(member.name) in selected_marker_ids:
                    count += 1
    return count


def _read_msa_profile(archive: tarfile.TarFile, member: tarfile.TarInfo) -> MsaProfile:
    extracted = archive.extractfile(member)
    if extracted is None:
        raise ValueError(f"Unable to read MSA member from archive: {member.name}")

    sequences: dict[str, str] = {}
    current_accession: str | None = None
    current_chunks: list[str] = []
    aligned_length: int | None = None

    def finalize_sequence() -> None:
        nonlocal current_accession, current_chunks, aligned_length
        if current_accession is None:
            return
        sequence = "".join(current_chunks)
        if aligned_length is None:
            aligned_length = len(sequence)
        elif len(sequence) != aligned_length:
            raise ValueError(
                f"MSA member contains sequences with inconsistent alignment lengths: {member.name}"
            )
        sequences[current_accession] = sequence

    for raw_line in extracted:
        line = raw_line.decode("utf-8", errors="replace").strip()
        if not line:
            continue
        if line.startswith(">"):
            finalize_sequence()
            current_accession = sys.intern(line[1:].split()[0])
            current_chunks = []
        else:
            current_chunks.append(line)
    finalize_sequence()

    return MsaProfile(
        marker_id=_msa_marker_id_from_member_name(member.name),
        member_name=member.name,
        sequences=sequences,
        aligned_length=aligned_length or 0,
    )


def _read_marker_nucleotide_profile(
    archive: tarfile.TarFile,
    member: tarfile.TarInfo,
) -> MarkerNucleotideProfile:
    extracted = archive.extractfile(member)
    if extracted is None:
        raise ValueError(f"Unable to read nucleotide marker member from archive: {member.name}")

    sequences: dict[str, str] = {}
    current_accession: str | None = None
    chunks: list[str] = []

    def finalize_sequence() -> None:
        nonlocal current_accession, chunks
        if current_accession is None:
            return
        sequences[current_accession] = "".join(chunks).upper()

    for raw_line in extracted:
        line = raw_line.decode("utf-8", errors="replace").strip()
        if not line:
            continue
        if line.startswith(">"):
            finalize_sequence()
            current_accession = sys.intern(line[1:].split()[0])
            chunks = []
        else:
            chunks.append(line)
    finalize_sequence()

    return MarkerNucleotideProfile(
        marker_id=_marker_id_from_member_name(member.name),
        member_name=member.name,
        sequences=sequences,
    )


def _load_selected_msa_profiles(
    msa_archive: str | Path,
    selected_marker_ids: set[str],
    *,
    progress_callback: ProgressCallback | None = None,
) -> dict[str, MsaProfile]:
    archive_path = Path(msa_archive).expanduser().resolve()
    total = _count_selected_msa_members(archive_path, selected_marker_ids)
    completed = 0
    profiles: dict[str, MsaProfile] = {}
    _emit_progress(progress_callback, "msa_loading_started", total_markers=total)
    with tarfile.open(archive_path, "r:*") as archive:
        for member in archive:
            if not (member.isfile() and member.name.endswith(".faa")):
                continue
            marker_id = _msa_marker_id_from_member_name(member.name)
            if marker_id not in selected_marker_ids:
                continue
            profiles[marker_id] = _read_msa_profile(archive, member)
            completed += 1
            _emit_progress(
                progress_callback,
                "msa_loading_advanced",
                completed=completed,
                total_markers=total,
            )
    _emit_progress(progress_callback, "msa_loading_completed", total_markers=total)
    return profiles


def _load_selected_marker_profiles(
    markers_archive: str | Path,
    selected_marker_ids: set[str],
    *,
    progress_callback: ProgressCallback | None = None,
) -> dict[str, MarkerNucleotideProfile]:
    total = _count_selected_marker_members(markers_archive, selected_marker_ids)
    completed = 0
    profiles: dict[str, MarkerNucleotideProfile] = {}
    _emit_progress(progress_callback, "marker_loading_started", total_markers=total)
    with tarfile.open(Path(markers_archive).expanduser().resolve(), "r:*") as archive:
        for member in archive:
            if not (member.isfile() and member.name.endswith(".fna")):
                continue
            marker_id = _marker_id_from_member_name(member.name)
            if marker_id not in selected_marker_ids:
                continue
            profiles[marker_id] = _read_marker_nucleotide_profile(archive, member)
            completed += 1
            _emit_progress(
                progress_callback,
                "marker_loading_advanced",
                completed=completed,
                total_markers=total,
            )
    _emit_progress(progress_callback, "marker_loading_completed", total_markers=total)
    return profiles


def _aligned_to_ungapped_interval(sequence: str, start: int, end: int) -> tuple[int, int]:
    prefix = sequence[:start]
    window = sequence[start:end]
    start_aa = sum(1 for char in prefix if char != "-") + 1
    end_aa = start_aa + sum(1 for char in window if char != "-") - 1
    return start_aa, end_aa


def _map_region_to_nucleotides(
    aligned_sequence: str,
    nucleotide_sequence: str,
    aligned_start: int,
    aligned_end: int,
) -> tuple[str, int, int] | None:
    start_index = aligned_start
    end_index = aligned_end
    aligned_window = aligned_sequence[start_index:end_index]
    ungapped_length = sum(1 for char in aligned_window if char != "-")
    if ungapped_length != (aligned_end - aligned_start):
        return None
    aa_start = sum(1 for char in aligned_sequence[:start_index] if char != "-") + 1
    aa_end = aa_start + ungapped_length - 1
    nt_start = (aa_start - 1) * 3 + 1
    nt_end = aa_end * 3
    if nt_end > len(nucleotide_sequence):
        return None
    nt_window = nucleotide_sequence[nt_start - 1 : nt_end].upper()
    if len(nt_window) != ungapped_length * 3:
        return None
    return nt_window, nt_start, nt_end


def _mismatch_count(
    sequence: str,
    consensus: str,
    *,
    max_mismatches: int | None = None,
) -> int:
    mismatches = 0
    for left, right in zip(sequence, consensus):
        if left == right:
            continue
        mismatches += 1
        if max_mismatches is not None and mismatches > max_mismatches:
            return mismatches
    return mismatches


def _effective_match_score(
    mismatches: int,
    *,
    max_mismatches: int,
    penalty_per_mismatch: float,
) -> float:
    if mismatches > max_mismatches:
        return 0.0
    return max(0.0, 1.0 - (float(mismatches) * penalty_per_mismatch))


def _build_target_column_cache(
    sequences: Sequence[tuple[str, str]],
    aligned_length: int,
) -> tuple[list[float], list[str | None], list[float]]:
    sequence_count = len(sequences)
    occupancies: list[float] = []
    consensus_residues: list[str | None] = []
    consensus_fractions: list[float] = []
    for column_index in range(aligned_length):
        counts: dict[str, int] = {}
        non_gap = 0
        for _accession, sequence in sequences:
            residue = sequence[column_index]
            if residue == "-":
                continue
            non_gap += 1
            counts[residue] = counts.get(residue, 0) + 1
        if non_gap == 0:
            occupancies.append(0.0)
            consensus_residues.append(None)
            consensus_fractions.append(0.0)
            continue
        occupancy = float(non_gap) / float(sequence_count)
        consensus_residue, consensus_count = sorted(
            counts.items(),
            key=lambda item: (-item[1], item[0]),
        )[0]
        occupancies.append(occupancy)
        consensus_residues.append(consensus_residue)
        consensus_fractions.append(float(consensus_count) / float(non_gap))
    return occupancies, consensus_residues, consensus_fractions


def _prefix_sums(values: Sequence[float | int]) -> list[float]:
    prefix = [0.0]
    running_total = 0.0
    for value in values:
        running_total += float(value)
        prefix.append(running_total)
    return prefix


def _build_gap_prefixes(sequences: Mapping[str, str]) -> dict[str, list[int]]:
    gap_prefixes: dict[str, list[int]] = {}
    for accession, sequence in sequences.items():
        prefix = [0]
        gap_count = 0
        for residue in sequence:
            if residue == "-":
                gap_count += 1
            prefix.append(gap_count)
        gap_prefixes[accession] = prefix
    return gap_prefixes


def _count_window_matches(
    sequences: Sequence[tuple[str, str]],
    gap_prefixes: Mapping[str, Sequence[int]],
    *,
    start: int,
    end: int,
    consensus_aa: str,
    max_aa_mismatches: int,
    aa_mismatch_penalty_per_mismatch: float,
    capture_anchor: bool = False,
) -> _WindowMatchStats:
    full_window_count = 0
    exact_count = 0
    near_count = 0
    effective_support = 0.0
    anchor_full_accession: str | None = None
    anchor_exact_accession: str | None = None

    for accession, sequence in sequences:
        gap_prefix = gap_prefixes[accession]
        if gap_prefix[end] != gap_prefix[start]:
            continue
        full_window_count += 1
        if capture_anchor and anchor_full_accession is None:
            anchor_full_accession = accession
        mismatches = _mismatch_count(
            sequence[start:end],
            consensus_aa,
            max_mismatches=max_aa_mismatches,
        )
        if mismatches == 0:
            exact_count += 1
            effective_support += 1.0
            if capture_anchor and anchor_exact_accession is None:
                anchor_exact_accession = accession
            continue
        if mismatches > max_aa_mismatches:
            continue
        near_count += 1
        effective_support += _effective_match_score(
            mismatches,
            max_mismatches=max_aa_mismatches,
            penalty_per_mismatch=aa_mismatch_penalty_per_mismatch,
        )

    return _WindowMatchStats(
        full_window_count=full_window_count,
        exact_count=exact_count,
        near_count=near_count,
        effective_support=effective_support,
        anchor_full_accession=anchor_full_accession,
        anchor_exact_accession=anchor_exact_accession,
    )


def _estimate_probeability(
    target_sequences: Sequence[tuple[str, str]],
    marker_profile: MarkerNucleotideProfile | None,
    *,
    aligned_start: int,
    aligned_end: int,
    probe_length: int,
) -> _ProbeabilityStats:
    if marker_profile is None or not target_sequences:
        return _ProbeabilityStats(
            mapped_target_sequences=0,
            remap_fraction=0.0,
            probeable_positions=0,
            probeable_positions_fraction=0.0,
            best_probe_support_fraction=0.0,
            best_probe_consensus_sequence=None,
            probeability_score=0.0,
        )

    mapped_windows: dict[str, str] = {}
    for accession, aligned_sequence in target_sequences:
        nucleotide_sequence = marker_profile.sequences.get(accession)
        if nucleotide_sequence is None:
            continue
        mapped = _map_region_to_nucleotides(
            aligned_sequence,
            nucleotide_sequence,
            aligned_start,
            aligned_end,
        )
        if mapped is not None:
            mapped_windows[accession] = mapped[0]

    remap_fraction = _safe_rate(len(mapped_windows), len(target_sequences))
    if not mapped_windows:
        return _ProbeabilityStats(
            mapped_target_sequences=0,
            remap_fraction=remap_fraction,
            probeable_positions=0,
            probeable_positions_fraction=0.0,
            best_probe_support_fraction=0.0,
            best_probe_consensus_sequence=None,
            probeability_score=remap_fraction / 3.0,
        )

    window_length = len(next(iter(mapped_windows.values())))
    max_probe_offsets = max(0, window_length - probe_length + 1)
    if max_probe_offsets == 0:
        return _ProbeabilityStats(
            mapped_target_sequences=len(mapped_windows),
            remap_fraction=remap_fraction,
            probeable_positions=0,
            probeable_positions_fraction=0.0,
            best_probe_support_fraction=0.0,
            best_probe_consensus_sequence=None,
            probeability_score=remap_fraction / 3.0,
        )

    probeable_positions = 0
    best_probe_support_fraction = 0.0
    best_probe_consensus_sequence: str | None = None
    for offset in range(max_probe_offsets):
        counts: dict[str, int] = {}
        valid_subsequences = 0
        for nt_window in mapped_windows.values():
            subsequence = nt_window[offset : offset + probe_length]
            if len(subsequence) != probe_length:
                continue
            if any(base not in {"A", "C", "G", "T"} for base in subsequence):
                continue
            valid_subsequences += 1
            counts[subsequence] = counts.get(subsequence, 0) + 1
        if valid_subsequences == 0:
            continue
        probeable_positions += 1
        consensus_sequence, consensus_count = sorted(
            counts.items(),
            key=lambda item: (-item[1], item[0]),
        )[0]
        support_fraction = _safe_rate(consensus_count, len(mapped_windows))
        if support_fraction > best_probe_support_fraction:
            best_probe_support_fraction = support_fraction
            best_probe_consensus_sequence = consensus_sequence

    probeable_positions_fraction = _safe_rate(probeable_positions, max_probe_offsets)
    probeability_score = (
        remap_fraction + probeable_positions_fraction + best_probe_support_fraction
    ) / 3.0
    return _ProbeabilityStats(
        mapped_target_sequences=len(mapped_windows),
        remap_fraction=remap_fraction,
        probeable_positions=probeable_positions,
        probeable_positions_fraction=probeable_positions_fraction,
        best_probe_support_fraction=best_probe_support_fraction,
        best_probe_consensus_sequence=best_probe_consensus_sequence,
        probeability_score=probeability_score,
    )


def _build_target_region_remap_rows(
    context: _ResolvedTargetContext,
    profile: MsaProfile,
    marker_profile: MarkerNucleotideProfile | None,
    selected_regions: Sequence[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    if marker_profile is None:
        return []
    target_sequences = {
        accession: sequence
        for accession, sequence in profile.sequences.items()
        if accession in context.taxonomy_accessions
    }
    remap_rows: list[dict[str, Any]] = []
    for region in selected_regions:
        aligned_start = int(region["aligned_start"]) - 1
        aligned_end = int(region["aligned_end"])
        for accession, aligned_sequence in target_sequences.items():
            nucleotide_sequence = marker_profile.sequences.get(accession)
            if nucleotide_sequence is None:
                continue
            mapped = _map_region_to_nucleotides(
                aligned_sequence,
                nucleotide_sequence,
                aligned_start,
                aligned_end,
            )
            if mapped is None:
                continue
            nt_window, nt_start, nt_end = mapped
            row = {
                "barcode": context.request.barcode,
                "resolved_level": context.request.resolved_level,
                "resolved_taxon": context.request.resolved_taxon,
                "marker_id": profile.marker_id,
                "aligned_start": int(region["aligned_start"]),
                "aligned_end": int(region["aligned_end"]),
                "window_aa_length": int(region["window_aa_length"]),
                "rank_within_target_marker": int(region["rank_within_target_marker"]),
                "accession": accession,
                "region_nt_start": nt_start,
                "region_nt_end": nt_end,
                "region_nt_window": nt_window,
            }
            for level, value in context.inferred_lineage.items():
                row[level] = value
            remap_rows.append(row)
    return remap_rows


def _select_non_overlapping_top_regions(
    candidates: Sequence[dict[str, Any]],
    top_regions_per_marker: int,
) -> list[dict[str, Any]]:
    selected: list[dict[str, Any]] = []
    for candidate in candidates:
        overlaps_existing = False
        for chosen in selected:
            if not (
                int(candidate["aligned_end"]) < int(chosen["aligned_start"])
                or int(candidate["aligned_start"]) > int(chosen["aligned_end"])
            ):
                overlaps_existing = True
                break
        if overlaps_existing:
            continue
        selected.append(candidate)
        if len(selected) >= top_regions_per_marker:
            break
    return selected


def _scan_aligned_windows(
    context: _ResolvedTargetContext,
    profile: MsaProfile,
    marker_profile: MarkerNucleotideProfile | None,
    *,
    window_aa_length: int,
    window_aa_length_min: int,
    window_aa_length_max: int,
    top_regions_per_marker: int,
    min_target_column_occupancy: float,
    min_target_consensus: float,
    min_target_window_presence: float,
    max_aa_mismatches: int,
    aa_mismatch_penalty_per_mismatch: float,
    region_probe_length: int,
    min_target_remap_fraction: float,
    min_best_probe_support_fraction: float,
    probeability_weight: float,
    sibling_penalty_weight: float,
    global_penalty_weight: float,
) -> tuple[dict[str, Any], list[dict[str, Any]], list[dict[str, Any]]]:
    target_sequences = {
        accession: sequence
        for accession, sequence in profile.sequences.items()
        if accession in context.taxonomy_accessions
    }
    sibling_sequences = {
        accession: sequence
        for accession, sequence in profile.sequences.items()
        if accession in context.sibling_accessions
    }
    global_sequences = {
        accession: sequence
        for accession, sequence in profile.sequences.items()
        if accession in context.global_accessions
    }

    summary_row = {
        "barcode": context.request.barcode,
        "resolved_level": context.request.resolved_level,
        "resolved_taxon": context.request.resolved_taxon,
        "marker_id": profile.marker_id,
        "member_name": profile.member_name,
        "alignment_sequences": len(profile.sequences),
        "aligned_length": profile.aligned_length,
        "target_taxonomy_genomes": len(context.taxonomy_accessions),
        "target_alignment_sequences": len(target_sequences),
        "sibling_alignment_sequences": len(sibling_sequences),
        "global_offtarget_alignment_sequences": len(global_sequences),
        "windows_evaluated": 0,
        "selected_regions": 0,
        "status": "ready",
        "best_region_score": None,
        "best_region_consensus_aa": None,
        "best_probeability_score": None,
        "best_probe_support_fraction": None,
    }
    for level, value in context.inferred_lineage.items():
        summary_row[level] = value

    if len(target_sequences) == 0:
        summary_row["status"] = "no_target_alignment_sequences"
        return summary_row, [], []

    all_target_sequences = list(target_sequences.items())
    if profile.aligned_length < window_aa_length_min:
        summary_row["status"] = "alignment_shorter_than_window"
        return summary_row, [], []

    target_column_occupancies, target_column_consensus_residues, target_column_consensus_fractions = (
        _build_target_column_cache(all_target_sequences, profile.aligned_length)
    )
    invalid_column_prefix = [0]
    for occupancy, consensus_residue, consensus_fraction in zip(
        target_column_occupancies,
        target_column_consensus_residues,
        target_column_consensus_fractions,
    ):
        invalid_column_prefix.append(
            invalid_column_prefix[-1]
            + int(
                consensus_residue is None
                or occupancy < min_target_column_occupancy
                or consensus_fraction < min_target_consensus
            )
        )
    target_occupancy_prefix = _prefix_sums(target_column_occupancies)
    target_consensus_prefix = _prefix_sums(target_column_consensus_fractions)
    target_gap_prefixes = _build_gap_prefixes(target_sequences)
    sibling_gap_prefixes = _build_gap_prefixes(sibling_sequences)
    global_gap_prefixes = _build_gap_prefixes(global_sequences)
    sibling_sequence_items = list(sibling_sequences.items())
    global_sequence_items = list(global_sequences.items())

    candidates: list[dict[str, Any]] = []
    for candidate_window_length in range(window_aa_length_min, window_aa_length_max + 1):
        if profile.aligned_length < candidate_window_length:
            continue
        for start in range(0, profile.aligned_length - candidate_window_length + 1):
            end = start + candidate_window_length
            if invalid_column_prefix[end] != invalid_column_prefix[start]:
                continue

            consensus_slice = target_column_consensus_residues[start:end]
            if any(residue is None for residue in consensus_slice):
                continue
            consensus_aa = "".join(str(residue) for residue in consensus_slice)

            target_window_stats = _count_window_matches(
                all_target_sequences,
                target_gap_prefixes,
                start=start,
                end=end,
                consensus_aa=consensus_aa,
                max_aa_mismatches=max_aa_mismatches,
                aa_mismatch_penalty_per_mismatch=aa_mismatch_penalty_per_mismatch,
                capture_anchor=True,
            )
            if target_window_stats.full_window_count == 0:
                continue

            sibling_window_stats = _count_window_matches(
                sibling_sequence_items,
                sibling_gap_prefixes,
                start=start,
                end=end,
                consensus_aa=consensus_aa,
                max_aa_mismatches=max_aa_mismatches,
                aa_mismatch_penalty_per_mismatch=aa_mismatch_penalty_per_mismatch,
            )
            global_window_stats = _count_window_matches(
                global_sequence_items,
                global_gap_prefixes,
                start=start,
                end=end,
                consensus_aa=consensus_aa,
                max_aa_mismatches=max_aa_mismatches,
                aa_mismatch_penalty_per_mismatch=aa_mismatch_penalty_per_mismatch,
            )

            target_window_presence_fraction = _safe_rate(
                target_window_stats.full_window_count,
                len(all_target_sequences),
            )
            if target_window_presence_fraction < min_target_window_presence:
                continue
            target_consensus_exact_fraction = _safe_rate(
                target_window_stats.exact_count,
                len(all_target_sequences),
            )
            target_effective_match_fraction = _safe_rate(
                target_window_stats.effective_support,
                len(all_target_sequences),
            )
            sibling_consensus_match_fraction = _safe_rate(
                sibling_window_stats.exact_count,
                len(sibling_sequences),
            )
            sibling_effective_match_fraction = _safe_rate(
                sibling_window_stats.effective_support,
                len(sibling_sequences),
            )
            global_consensus_match_fraction = _safe_rate(
                global_window_stats.exact_count,
                len(global_sequences),
            )
            global_effective_match_fraction = _safe_rate(
                global_window_stats.effective_support,
                len(global_sequences),
            )
            target_consensus_mean = (
                target_consensus_prefix[end] - target_consensus_prefix[start]
            ) / float(candidate_window_length)
            target_occupancy_mean = (
                target_occupancy_prefix[end] - target_occupancy_prefix[start]
            ) / float(candidate_window_length)
            column_occupancies = target_column_occupancies[start:end]
            column_consensus = target_column_consensus_fractions[start:end]
            probeability_stats = _estimate_probeability(
                all_target_sequences,
                marker_profile,
                aligned_start=start,
                aligned_end=end,
                probe_length=region_probe_length,
            )
            if probeability_stats.remap_fraction < min_target_remap_fraction:
                continue
            if probeability_stats.best_probe_support_fraction < min_best_probe_support_fraction:
                continue

            target_support = (
                (0.5 * target_window_presence_fraction + 0.5 * target_effective_match_fraction)
                * target_consensus_mean
            )
            score = (
                target_support
                - (sibling_penalty_weight * sibling_effective_match_fraction)
                - (global_penalty_weight * global_effective_match_fraction)
                + (probeability_weight * probeability_stats.probeability_score)
            )

            anchor_accession = (
                target_window_stats.anchor_exact_accession
                or target_window_stats.anchor_full_accession
            )
            if anchor_accession is None:
                continue
            anchor_sequence = target_sequences[anchor_accession]
            anchor_aa_start, anchor_aa_end = _aligned_to_ungapped_interval(anchor_sequence, start, end)

            candidate = {
                "barcode": context.request.barcode,
                "resolved_level": context.request.resolved_level,
                "resolved_taxon": context.request.resolved_taxon,
                "marker_id": profile.marker_id,
                "member_name": profile.member_name,
                "aligned_start": start + 1,
                "aligned_end": end,
                "window_aa_length": candidate_window_length,
                "consensus_aa": consensus_aa,
                "anchor_accession": anchor_accession,
                "anchor_aa_start": anchor_aa_start,
                "anchor_aa_end": anchor_aa_end,
                "target_alignment_sequences": len(all_target_sequences),
                "target_full_window_sequences": target_window_stats.full_window_count,
                "target_exact_match_sequences": target_window_stats.exact_count,
                "target_near_match_sequences": target_window_stats.near_count,
                "target_window_presence_fraction": target_window_presence_fraction,
                "target_consensus_exact_fraction": target_consensus_exact_fraction,
                "target_effective_match_fraction": target_effective_match_fraction,
                "target_column_occupancy_mean": target_occupancy_mean,
                "target_column_occupancy_min": min(column_occupancies),
                "target_consensus_mean": target_consensus_mean,
                "target_consensus_min": min(column_consensus),
                "target_remapped_sequences": probeability_stats.mapped_target_sequences,
                "target_remap_fraction": probeability_stats.remap_fraction,
                "probe_length": region_probe_length,
                "probeable_positions": probeability_stats.probeable_positions,
                "probeable_positions_fraction": probeability_stats.probeable_positions_fraction,
                "best_probe_support_fraction": probeability_stats.best_probe_support_fraction,
                "best_probe_consensus_sequence": probeability_stats.best_probe_consensus_sequence,
                "probeability_score": probeability_stats.probeability_score,
                "sibling_alignment_sequences": len(sibling_sequences),
                "sibling_consensus_match_sequences": sibling_window_stats.exact_count,
                "sibling_near_match_sequences": sibling_window_stats.near_count,
                "sibling_consensus_match_fraction": sibling_consensus_match_fraction,
                "sibling_effective_match_fraction": sibling_effective_match_fraction,
                "global_offtarget_alignment_sequences": len(global_sequences),
                "global_consensus_match_sequences": global_window_stats.exact_count,
                "global_near_match_sequences": global_window_stats.near_count,
                "global_consensus_match_fraction": global_consensus_match_fraction,
                "global_effective_match_fraction": global_effective_match_fraction,
                "score": score,
            }
            for level, value in context.inferred_lineage.items():
                candidate[level] = value
            candidates.append(candidate)

    summary_row["windows_evaluated"] = len(candidates)
    if not candidates:
        summary_row["status"] = "no_passing_windows"
        return summary_row, [], []

    candidates.sort(
        key=lambda row: (
            -float(row["score"]),
            -float(row.get("probeability_score") or 0.0),
            -float(row["target_effective_match_fraction"]),
            -float(row["target_consensus_mean"]),
            float(row["sibling_effective_match_fraction"]),
            float(row["global_effective_match_fraction"]),
            -int(row["window_aa_length"]),
            int(row["aligned_start"]),
        )
    )
    selected = _select_non_overlapping_top_regions(candidates, top_regions_per_marker)
    for index, row in enumerate(selected, start=1):
        row["rank_within_target_marker"] = index
    remap_rows = _build_target_region_remap_rows(context, profile, marker_profile, selected)

    summary_row["selected_regions"] = len(selected)
    if selected:
        summary_row["best_region_score"] = selected[0]["score"]
        summary_row["best_region_consensus_aa"] = selected[0]["consensus_aa"]
        summary_row["best_probeability_score"] = selected[0].get("probeability_score")
        summary_row["best_probe_support_fraction"] = selected[0].get("best_probe_support_fraction")
        if len(target_sequences) == 1:
            summary_row["status"] = "single_target_alignment_sequence"
    return summary_row, selected, remap_rows


def _selected_target_marker_row(
    context: _ResolvedTargetContext,
    summary_row: Mapping[str, Any],
) -> dict[str, Any]:
    row = {
        "barcode": context.request.barcode,
        "resolved_level": context.request.resolved_level,
        "resolved_taxon": context.request.resolved_taxon,
        "parent_level": context.parent_level,
        "parent_taxon": context.parent_taxon,
        "marker_id": context.request.marker_id,
        "status": summary_row["status"],
        "target_taxonomy_genomes": len(context.taxonomy_accessions),
        "target_alignment_sequences": summary_row.get("target_alignment_sequences", 0),
        "selected_regions": summary_row.get("selected_regions", 0),
        "best_region_score": summary_row.get("best_region_score"),
        "best_probeability_score": summary_row.get("best_probeability_score"),
    }
    for level, value in context.inferred_lineage.items():
        row[level] = value
    return row


def _build_target_region_summary(
    marker_region_summary: Sequence[Mapping[str, Any]],
    region_candidates: Sequence[Mapping[str, Any]],
    levels: Sequence[str],
) -> list[dict[str, Any]]:
    marker_rows_by_barcode: dict[str, list[Mapping[str, Any]]] = {}
    for row in marker_region_summary:
        marker_rows_by_barcode.setdefault(str(row["barcode"]), []).append(row)

    region_rows_by_barcode: dict[str, list[Mapping[str, Any]]] = {}
    for row in region_candidates:
        region_rows_by_barcode.setdefault(str(row["barcode"]), []).append(row)

    summary_rows: list[dict[str, Any]] = []
    for barcode, marker_rows in marker_rows_by_barcode.items():
        region_rows = region_rows_by_barcode.get(barcode, [])
        first_row = marker_rows[0]

        requested_markers = len(marker_rows)
        markers_with_selected_regions = sum(1 for row in marker_rows if int(row.get("selected_regions") or 0) > 0)
        missing_msa_markers = sum(1 for row in marker_rows if str(row.get("status") or "") == "missing_msa_marker")
        no_target_alignment_markers = sum(
            1 for row in marker_rows if str(row.get("status") or "") == "no_target_alignment_sequences"
        )
        alignment_shorter_than_window_markers = sum(
            1 for row in marker_rows if str(row.get("status") or "") == "alignment_shorter_than_window"
        )
        no_passing_window_markers = sum(1 for row in marker_rows if str(row.get("status") or "") == "no_passing_windows")
        single_alignment_markers = sum(
            1 for row in marker_rows if str(row.get("status") or "") == "single_target_alignment_sequence"
        )

        region_nt_lengths = [int(row.get("window_aa_length") or 0) * 3 for row in region_rows]
        probeable_positions = [int(row.get("probeable_positions") or 0) for row in region_rows]
        remap_fractions = [
            float(row["target_remap_fraction"])
            for row in region_rows
            if row.get("target_remap_fraction") not in (None, "")
        ]
        probe_support_fractions = [
            float(row["best_probe_support_fraction"])
            for row in region_rows
            if row.get("best_probe_support_fraction") not in (None, "")
        ]
        best_region_scores = [
            float(row["score"])
            for row in region_rows
            if row.get("score") not in (None, "")
        ]
        best_probeability_scores = [
            float(row["probeability_score"])
            for row in region_rows
            if row.get("probeability_score") not in (None, "")
        ]

        if region_rows:
            status = "ready"
        elif missing_msa_markers == requested_markers:
            status = "missing_msa_markers"
        elif no_target_alignment_markers == requested_markers:
            status = "no_target_alignment_sequences"
        elif alignment_shorter_than_window_markers == requested_markers:
            status = "alignment_shorter_than_window"
        else:
            status = "no_passing_regions"

        summary_row = {
            "barcode": barcode,
            "resolved_level": first_row.get("resolved_level"),
            "resolved_taxon": first_row.get("resolved_taxon"),
            "parent_level": first_row.get("parent_level"),
            "parent_taxon": first_row.get("parent_taxon"),
            "target_taxonomy_genomes": first_row.get("target_taxonomy_genomes"),
            "status": status,
            "requested_markers": requested_markers,
            "markers_with_selected_regions": markers_with_selected_regions,
            "markers_without_selected_regions": requested_markers - markers_with_selected_regions,
            "missing_msa_markers": missing_msa_markers,
            "no_target_alignment_markers": no_target_alignment_markers,
            "alignment_shorter_than_window_markers": alignment_shorter_than_window_markers,
            "no_passing_window_markers": no_passing_window_markers,
            "single_alignment_markers": single_alignment_markers,
            "retained_regions": len(region_rows),
            "total_region_nt_length": sum(region_nt_lengths),
            "mean_region_nt_length": _mean(region_nt_lengths),
            "total_probeable_positions": sum(probeable_positions),
            "mean_probeable_positions_per_region": _mean(probeable_positions),
            "mean_target_remap_fraction": _mean(remap_fractions),
            "mean_best_probe_support_fraction": _mean(probe_support_fractions),
            "best_region_score": max(best_region_scores) if best_region_scores else None,
            "best_probeability_score": max(best_probeability_scores) if best_probeability_scores else None,
        }
        for level in levels:
            summary_row[level] = first_row.get(level)
        summary_rows.append(summary_row)

    summary_rows.sort(
        key=lambda row: (
            str(row["resolved_level"]),
            str(row["resolved_taxon"]),
            str(row["barcode"]),
        )
    )
    return summary_rows


def _evaluate_region_context(
    context: _ResolvedTargetContext,
    profiles: Mapping[str, MsaProfile],
    marker_profiles: Mapping[str, MarkerNucleotideProfile] | None,
    *,
    window_aa_length: int,
    window_aa_length_min: int,
    window_aa_length_max: int,
    top_regions_per_marker: int,
    min_target_column_occupancy: float,
    min_target_consensus: float,
    min_target_window_presence: float,
    max_aa_mismatches: int,
    aa_mismatch_penalty_per_mismatch: float,
    region_probe_length: int,
    min_target_remap_fraction: float,
    min_best_probe_support_fraction: float,
    probeability_weight: float,
    sibling_penalty_weight: float,
    global_penalty_weight: float,
) -> _RegionScanOutcome:
    profile = profiles.get(context.request.marker_id)
    marker_profile = None if marker_profiles is None else marker_profiles.get(context.request.marker_id)
    if profile is None:
        summary_row = {
            "barcode": context.request.barcode,
            "resolved_level": context.request.resolved_level,
            "resolved_taxon": context.request.resolved_taxon,
            "marker_id": context.request.marker_id,
            "member_name": None,
            "alignment_sequences": 0,
            "aligned_length": 0,
            "target_taxonomy_genomes": len(context.taxonomy_accessions),
            "target_alignment_sequences": 0,
            "sibling_alignment_sequences": 0,
            "global_offtarget_alignment_sequences": 0,
            "windows_evaluated": 0,
            "selected_regions": 0,
            "status": "missing_msa_marker",
            "best_region_score": None,
            "best_region_consensus_aa": None,
            "best_probeability_score": None,
            "best_probe_support_fraction": None,
        }
        for level, value in context.inferred_lineage.items():
            summary_row[level] = value
        summary_row["parent_level"] = context.parent_level
        summary_row["parent_taxon"] = context.parent_taxon
        summary_row["marker_rank_within_target"] = context.request.marker_rank_within_target
        return _RegionScanOutcome(
            summary_row=summary_row,
            selected_regions=[],
            remap_rows=[],
            selected_target_marker_row=_selected_target_marker_row(context, summary_row),
        )

    summary_row, selected_regions, remap_rows = _scan_aligned_windows(
        context,
        profile,
        marker_profile,
        window_aa_length=window_aa_length,
        window_aa_length_min=window_aa_length_min,
        window_aa_length_max=window_aa_length_max,
        top_regions_per_marker=top_regions_per_marker,
        min_target_column_occupancy=min_target_column_occupancy,
        min_target_consensus=min_target_consensus,
        min_target_window_presence=min_target_window_presence,
        max_aa_mismatches=max_aa_mismatches,
        aa_mismatch_penalty_per_mismatch=aa_mismatch_penalty_per_mismatch,
        region_probe_length=region_probe_length,
        min_target_remap_fraction=min_target_remap_fraction,
        min_best_probe_support_fraction=min_best_probe_support_fraction,
        probeability_weight=probeability_weight,
        sibling_penalty_weight=sibling_penalty_weight,
        global_penalty_weight=global_penalty_weight,
    )
    summary_row["parent_level"] = context.parent_level
    summary_row["parent_taxon"] = context.parent_taxon
    summary_row["marker_rank_within_target"] = context.request.marker_rank_within_target
    return _RegionScanOutcome(
        summary_row=summary_row,
        selected_regions=selected_regions,
        remap_rows=remap_rows,
        selected_target_marker_row=_selected_target_marker_row(context, summary_row),
    )


def _init_region_scoring_worker(
    contexts: Sequence[_ResolvedTargetContext],
    profiles: Mapping[str, MsaProfile],
    marker_profiles: Mapping[str, MarkerNucleotideProfile] | None,
    window_aa_length: int,
    window_aa_length_min: int,
    window_aa_length_max: int,
    top_regions_per_marker: int,
    min_target_column_occupancy: float,
    min_target_consensus: float,
    min_target_window_presence: float,
    max_aa_mismatches: int,
    aa_mismatch_penalty_per_mismatch: float,
    region_probe_length: int,
    min_target_remap_fraction: float,
    min_best_probe_support_fraction: float,
    probeability_weight: float,
    sibling_penalty_weight: float,
    global_penalty_weight: float,
) -> None:
    global _REGION_SCORING_STATE
    _REGION_SCORING_STATE = (
        contexts,
        profiles,
        marker_profiles,
        window_aa_length,
        window_aa_length_min,
        window_aa_length_max,
        top_regions_per_marker,
        min_target_column_occupancy,
        min_target_consensus,
        min_target_window_presence,
        max_aa_mismatches,
        aa_mismatch_penalty_per_mismatch,
        region_probe_length,
        min_target_remap_fraction,
        min_best_probe_support_fraction,
        probeability_weight,
        sibling_penalty_weight,
        global_penalty_weight,
    )


def _scan_region_chunk(chunk: tuple[int, int]) -> list[_RegionScanOutcome]:
    if _REGION_SCORING_STATE is None:
        raise RuntimeError("Region-scoring worker state has not been initialized.")
    (
        contexts,
        profiles,
        marker_profiles,
        window_aa_length,
        window_aa_length_min,
        window_aa_length_max,
        top_regions_per_marker,
        min_target_column_occupancy,
        min_target_consensus,
        min_target_window_presence,
        max_aa_mismatches,
        aa_mismatch_penalty_per_mismatch,
        region_probe_length,
        min_target_remap_fraction,
        min_best_probe_support_fraction,
        probeability_weight,
        sibling_penalty_weight,
        global_penalty_weight,
    ) = _REGION_SCORING_STATE
    start, end = chunk
    return [
        _evaluate_region_context(
            contexts[index],
            profiles,
            marker_profiles,
            window_aa_length=window_aa_length,
            window_aa_length_min=window_aa_length_min,
            window_aa_length_max=window_aa_length_max,
            top_regions_per_marker=top_regions_per_marker,
            min_target_column_occupancy=min_target_column_occupancy,
            min_target_consensus=min_target_consensus,
            min_target_window_presence=min_target_window_presence,
            max_aa_mismatches=max_aa_mismatches,
            aa_mismatch_penalty_per_mismatch=aa_mismatch_penalty_per_mismatch,
            region_probe_length=region_probe_length,
            min_target_remap_fraction=min_target_remap_fraction,
            min_best_probe_support_fraction=min_best_probe_support_fraction,
            probeability_weight=probeability_weight,
            sibling_penalty_weight=sibling_penalty_weight,
            global_penalty_weight=global_penalty_weight,
        )
        for index in range(start, end)
    ]


def discover_regions(
    *,
    taxonomy_file: str | Path,
    msa_archive: str | Path,
    markers_archive: str | Path | None = None,
    target_discovery_prefix: str | Path,
    dataset: str | None = None,
    discovery_profile: str = DEFAULT_DISCOVERY_PROFILE,
    window_aa_length: int | None = None,
    window_aa_length_min: int | None = None,
    window_aa_length_max: int | None = None,
    top_regions_per_marker: int | None = None,
    include_taxa: Mapping[str, set[str]] | None = None,
    exclude_taxa: Mapping[str, set[str]] | None = None,
    min_target_column_occupancy: float | None = None,
    min_target_consensus: float | None = None,
    min_target_window_presence: float | None = None,
    max_aa_mismatches: int | None = None,
    aa_mismatch_penalty_per_mismatch: float | None = None,
    region_probe_length: int | None = None,
    min_target_remap_fraction: float | None = None,
    min_best_probe_support_fraction: float | None = None,
    probeability_weight: float | None = None,
    sibling_penalty_weight: float | None = None,
    global_penalty_weight: float | None = None,
    workers: int = DEFAULT_AUTO_WORKERS,
    progress_callback: ProgressCallback | None = None,
) -> RegionDiscoveryResult:
    resolved_discovery_profile = validate_discovery_profile(discovery_profile)
    profile_defaults = _region_profile_defaults(resolved_discovery_profile)
    resolved_include_taxa = {level: set(taxa) for level, taxa in (include_taxa or {}).items() if taxa}
    resolved_exclude_taxa = {level: set(taxa) for level, taxa in (exclude_taxa or {}).items() if taxa}
    validate_taxon_constraint_overlap(resolved_include_taxa, resolved_exclude_taxa)
    if window_aa_length is not None and window_aa_length < 1:
        raise ValueError("--window-aa-length must be at least 1.")
    if window_aa_length is None and window_aa_length_min is None and window_aa_length_max is None:
        resolved_window_aa_length_min = int(profile_defaults["window_aa_length_min"])
        resolved_window_aa_length_max = int(profile_defaults["window_aa_length_max"])
    elif window_aa_length is not None and window_aa_length_min is None and window_aa_length_max is None:
        resolved_window_aa_length_min = window_aa_length
        resolved_window_aa_length_max = window_aa_length
    else:
        resolved_window_aa_length_min = (
            window_aa_length_min
            if window_aa_length_min is not None
            else (window_aa_length if window_aa_length is not None else int(profile_defaults["window_aa_length_min"]))
        )
        resolved_window_aa_length_max = (
            window_aa_length_max
            if window_aa_length_max is not None
            else (window_aa_length if window_aa_length is not None else int(profile_defaults["window_aa_length_max"]))
        )
    resolved_top_regions_per_marker = (
        int(top_regions_per_marker)
        if top_regions_per_marker is not None
        else int(profile_defaults["top_regions_per_marker"])
    )
    resolved_min_target_column_occupancy = (
        float(min_target_column_occupancy)
        if min_target_column_occupancy is not None
        else float(profile_defaults["min_target_column_occupancy"])
    )
    resolved_min_target_consensus = (
        float(min_target_consensus)
        if min_target_consensus is not None
        else float(profile_defaults["min_target_consensus"])
    )
    resolved_min_target_window_presence = (
        float(min_target_window_presence)
        if min_target_window_presence is not None
        else float(profile_defaults["min_target_window_presence"])
    )
    resolved_max_aa_mismatches = (
        int(max_aa_mismatches)
        if max_aa_mismatches is not None
        else int(profile_defaults["max_aa_mismatches"])
    )
    resolved_aa_mismatch_penalty_per_mismatch = (
        float(aa_mismatch_penalty_per_mismatch)
        if aa_mismatch_penalty_per_mismatch is not None
        else float(profile_defaults["aa_mismatch_penalty_per_mismatch"])
    )
    resolved_region_probe_length = (
        int(region_probe_length)
        if region_probe_length is not None
        else int(profile_defaults["region_probe_length"])
    )
    resolved_min_target_remap_fraction = (
        float(min_target_remap_fraction)
        if min_target_remap_fraction is not None
        else float(profile_defaults["min_target_remap_fraction"])
    )
    resolved_min_best_probe_support_fraction = (
        float(min_best_probe_support_fraction)
        if min_best_probe_support_fraction is not None
        else float(profile_defaults["min_best_probe_support_fraction"])
    )
    resolved_probeability_weight = (
        float(probeability_weight)
        if probeability_weight is not None
        else float(profile_defaults["probeability_weight"])
    )
    resolved_sibling_penalty_weight = (
        float(sibling_penalty_weight)
        if sibling_penalty_weight is not None
        else float(profile_defaults["sibling_penalty_weight"])
    )
    resolved_global_penalty_weight = (
        float(global_penalty_weight)
        if global_penalty_weight is not None
        else float(profile_defaults["global_penalty_weight"])
    )
    if resolved_window_aa_length_min < 1:
        raise ValueError("--window-aa-length-min must be at least 1.")
    if resolved_window_aa_length_max < 1:
        raise ValueError("--window-aa-length-max must be at least 1.")
    if resolved_window_aa_length_min > resolved_window_aa_length_max:
        raise ValueError("--window-aa-length-min cannot be greater than --window-aa-length-max.")
    if resolved_top_regions_per_marker < 1:
        raise ValueError("--top-regions-per-marker must be at least 1.")
    if not 0.0 <= resolved_min_target_window_presence <= 1.0:
        raise ValueError("--min-target-window-presence must be between 0 and 1.")
    if resolved_max_aa_mismatches < 0:
        raise ValueError("--max-aa-mismatches must be at least 0.")
    if resolved_aa_mismatch_penalty_per_mismatch < 0.0:
        raise ValueError("--aa-mismatch-penalty-per-mismatch must be at least 0.")
    if resolved_region_probe_length < 1:
        raise ValueError("--region-probe-length must be at least 1.")
    if not 0.0 <= resolved_min_target_remap_fraction <= 1.0:
        raise ValueError("--min-target-remap-fraction must be between 0 and 1.")
    if not 0.0 <= resolved_min_best_probe_support_fraction <= 1.0:
        raise ValueError("--min-best-probe-support-fraction must be between 0 and 1.")
    if resolved_probeability_weight < 0.0:
        raise ValueError("--probeability-weight must be at least 0.")

    resolved_taxonomy = str(Path(taxonomy_file).expanduser().resolve())
    resolved_msa = str(Path(msa_archive).expanduser().resolve())
    resolved_markers = (
        str(Path(markers_archive).expanduser().resolve())
        if markers_archive is not None
        else None
    )
    resolved_target_prefix = str(Path(target_discovery_prefix).expanduser().resolve())
    levels, requests, _target_summary = _read_target_marker_requests(target_discovery_prefix)
    contexts = _infer_target_contexts(
        resolved_taxonomy,
        requests,
        levels,
        include_taxa=resolved_include_taxa,
        exclude_taxa=resolved_exclude_taxa,
        progress_callback=progress_callback,
    )
    missing_requests = [
        f"{context.request.barcode}:{context.request.resolved_level}:{context.request.resolved_taxon}:{context.request.marker_id}"
        for context in contexts
        if not context.taxonomy_accessions
    ]
    if missing_requests:
        raise ValueError(
            "Selected target-marker requests are absent after applying the region-analysis taxon scope. "
            "Adjust --include/--exclude or the upstream target discovery. Missing requests: "
            + ", ".join(sorted(missing_requests))
        )
    selected_marker_ids = {context.request.marker_id for context in contexts}
    profiles = _load_selected_msa_profiles(
        resolved_msa,
        selected_marker_ids,
        progress_callback=progress_callback,
    )
    marker_profiles = None
    if resolved_markers is not None:
        marker_profiles = _load_selected_marker_profiles(
            resolved_markers,
            selected_marker_ids,
            progress_callback=progress_callback,
        )

    _emit_progress(progress_callback, "window_scoring_started", total_requests=len(contexts))
    marker_region_summary: list[dict[str, Any]] = []
    region_candidates: list[dict[str, Any]] = []
    region_remap_manifest: list[dict[str, Any]] = []
    selected_target_markers: list[dict[str, Any]] = []
    completed = 0
    resolved_workers = resolve_worker_count(workers, total_tasks=len(contexts))
    scoring_chunks = build_chunks(len(contexts), workers=resolved_workers)
    for chunk, outcomes in iter_chunk_results(
        scoring_chunks,
        worker=_scan_region_chunk,
        workers=resolved_workers,
        initializer=_init_region_scoring_worker,
        initargs=(
            contexts,
            profiles,
            marker_profiles,
            window_aa_length,
            resolved_window_aa_length_min,
            resolved_window_aa_length_max,
            resolved_top_regions_per_marker,
            resolved_min_target_column_occupancy,
            resolved_min_target_consensus,
            resolved_min_target_window_presence,
            resolved_max_aa_mismatches,
            resolved_aa_mismatch_penalty_per_mismatch,
            resolved_region_probe_length,
            resolved_min_target_remap_fraction,
            resolved_min_best_probe_support_fraction,
            resolved_probeability_weight,
            resolved_sibling_penalty_weight,
            resolved_global_penalty_weight,
        ),
    ):
        for outcome in outcomes:
            marker_region_summary.append(outcome.summary_row)
            region_candidates.extend(outcome.selected_regions)
            region_remap_manifest.extend(outcome.remap_rows)
            selected_target_markers.append(outcome.selected_target_marker_row)
        completed += chunk[1] - chunk[0]
        _emit_progress(
            progress_callback,
            "window_scoring_advanced",
            completed=completed,
            total_requests=len(contexts),
        )
    _emit_progress(progress_callback, "window_scoring_completed", total_requests=len(contexts))

    marker_region_summary.sort(
        key=lambda row: (
            str(row["barcode"]),
            int(row["marker_rank_within_target"]),
            str(row["marker_id"]),
        )
    )
    region_candidates.sort(
        key=lambda row: (
            str(row["barcode"]),
            str(row["marker_id"]),
            int(row["rank_within_target_marker"]),
        )
    )
    region_remap_manifest.sort(
        key=lambda row: (
            str(row["barcode"]),
            str(row["marker_id"]),
            int(row["rank_within_target_marker"]),
            str(row["accession"]),
        )
    )
    selected_target_markers.sort(
        key=lambda row: (
            str(row["barcode"]),
            str(row["marker_id"]),
        )
    )
    target_region_summary = _build_target_region_summary(marker_region_summary, region_candidates, levels)
    constraint_summary = taxon_constraint_payload(resolved_include_taxa, resolved_exclude_taxa)

    return RegionDiscoveryResult(
        dataset=dataset,
        taxonomy_file=resolved_taxonomy,
        msa_archive=resolved_msa,
        markers_archive=resolved_markers,
        target_discovery_prefix=resolved_target_prefix,
        target_region_summary=target_region_summary,
        selected_target_markers=selected_target_markers,
        marker_region_summary=marker_region_summary,
        region_candidates=region_candidates,
        region_remap_manifest=region_remap_manifest,
        analyzed_markers=len(profiles),
        discovery_profile=resolved_discovery_profile,
        window_aa_length=DEFAULT_WINDOW_AA_LENGTH if window_aa_length is None else window_aa_length,
        window_aa_length_min=resolved_window_aa_length_min,
        window_aa_length_max=resolved_window_aa_length_max,
        top_regions_per_marker=resolved_top_regions_per_marker,
        include_taxa=constraint_summary["include_taxa"],
        exclude_taxa=constraint_summary["exclude_taxa"],
        min_target_column_occupancy=resolved_min_target_column_occupancy,
        min_target_consensus=resolved_min_target_consensus,
        min_target_window_presence=resolved_min_target_window_presence,
        max_aa_mismatches=resolved_max_aa_mismatches,
        aa_mismatch_penalty_per_mismatch=resolved_aa_mismatch_penalty_per_mismatch,
        region_probe_length=resolved_region_probe_length,
        min_target_remap_fraction=resolved_min_target_remap_fraction,
        min_best_probe_support_fraction=resolved_min_best_probe_support_fraction,
        probeability_weight=resolved_probeability_weight,
        sibling_penalty_weight=resolved_sibling_penalty_weight,
        global_penalty_weight=resolved_global_penalty_weight,
    )


def _write_csv(path: Path, rows: Sequence[Mapping[str, Any]]) -> None:
    rows = list(rows)
    fieldnames: list[str] = []
    for row in rows:
        for key in row.keys():
            if key not in fieldnames:
                fieldnames.append(key)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        if fieldnames:
            writer.writeheader()
            for row in rows:
                writer.writerow({key: row.get(key) for key in fieldnames})


def write_region_discovery_outputs(
    result: RegionDiscoveryResult,
    output_prefix: str | Path,
) -> dict[str, Path]:
    output_prefix = Path(output_prefix).expanduser().resolve()
    output_prefix.parent.mkdir(parents=True, exist_ok=True)
    paths = {
        "summary": output_prefix.with_name(f"{output_prefix.name}_summary.json"),
        "target_summary": output_prefix.with_name(f"{output_prefix.name}_target_region_summary.csv"),
        "target_markers": output_prefix.with_name(f"{output_prefix.name}_selected_target_markers.csv"),
        "marker_summary": output_prefix.with_name(f"{output_prefix.name}_marker_region_summary.csv"),
        "region_candidates": output_prefix.with_name(f"{output_prefix.name}_region_candidates.csv"),
        "region_remap_manifest": output_prefix.with_name(f"{output_prefix.name}_region_remap_manifest.csv"),
    }
    _write_csv(paths["target_summary"], result.target_region_summary)
    _write_csv(paths["target_markers"], result.selected_target_markers)
    _write_csv(paths["marker_summary"], result.marker_region_summary)
    _write_csv(paths["region_candidates"], result.region_candidates)
    _write_csv(paths["region_remap_manifest"], result.region_remap_manifest)
    result.output_files = {name: str(path.resolve()) for name, path in paths.items()}
    with paths["summary"].open("w", encoding="utf-8") as handle:
        json.dump(result.to_summary_dict(), handle, indent=2, sort_keys=True)
        handle.write("\n")
    return paths
