"""Shared sequence-matching utilities for exact and mismatch-aware scoring."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping

DEFAULT_MAX_MISMATCHES = 0
DEFAULT_MISMATCH_PENALTY_PER_MISMATCH = 0.25


@dataclass(slots=True, frozen=True)
class MatchConfig:
    max_mismatches: int = DEFAULT_MAX_MISMATCHES
    mismatch_penalty_per_mismatch: float = DEFAULT_MISMATCH_PENALTY_PER_MISMATCH

    def to_summary_dict(self) -> dict[str, float | int]:
        return {
            "max_mismatches": self.max_mismatches,
            "mismatch_penalty_per_mismatch": self.mismatch_penalty_per_mismatch,
        }


@dataclass(slots=True, frozen=True)
class MatchSummary:
    available: int
    matched_accessions: frozenset[str]
    support_by_accession: dict[str, float]
    exact_hits: int
    mismatch_hits: int
    total_support: float
    hit_fraction: float
    support_fraction: float
    mean_best_mismatches: float | None

    @property
    def hit_count(self) -> int:
        return len(self.matched_accessions)


def validate_match_config(config: MatchConfig) -> MatchConfig:
    if config.max_mismatches < 0:
        raise ValueError("--max-mismatches must be >= 0.")
    if config.mismatch_penalty_per_mismatch < 0.0:
        raise ValueError("--mismatch-penalty-per-mismatch must be >= 0.")
    return config


def mismatch_support(mismatches: int, config: MatchConfig) -> float:
    return max(0.0, 1.0 - (config.mismatch_penalty_per_mismatch * float(mismatches)))


def evaluate_query_against_accessions(
    query: str,
    accessions: list[str] | tuple[str, ...] | set[str],
    sequences: Mapping[str, str],
    config: MatchConfig,
) -> MatchSummary:
    query = query.upper()
    accession_list = list(accessions)
    if not accession_list:
        return MatchSummary(
            available=0,
            matched_accessions=frozenset(),
            support_by_accession={},
            exact_hits=0,
            mismatch_hits=0,
            total_support=0.0,
            hit_fraction=0.0,
            support_fraction=0.0,
            mean_best_mismatches=None,
        )

    matched_accessions: set[str] = set()
    support_by_accession: dict[str, float] = {}
    exact_hits = 0
    mismatch_hits = 0
    total_support = 0.0
    mismatch_sum = 0

    for accession in accession_list:
        sequence = sequences[accession]
        best_mismatches = best_subsequence_mismatches(query, sequence, config.max_mismatches)
        if best_mismatches is None:
            continue
        matched_accessions.add(accession)
        support = mismatch_support(best_mismatches, config)
        support_by_accession[accession] = support
        total_support += support
        mismatch_sum += best_mismatches
        if best_mismatches == 0:
            exact_hits += 1
        else:
            mismatch_hits += 1

    available = len(accession_list)
    hit_fraction = float(len(matched_accessions)) / float(available)
    support_fraction = float(total_support) / float(available)
    mean_best_mismatches = (
        float(mismatch_sum) / float(len(matched_accessions))
        if matched_accessions
        else None
    )
    return MatchSummary(
        available=available,
        matched_accessions=frozenset(matched_accessions),
        support_by_accession=support_by_accession,
        exact_hits=exact_hits,
        mismatch_hits=mismatch_hits,
        total_support=total_support,
        hit_fraction=hit_fraction,
        support_fraction=support_fraction,
        mean_best_mismatches=mean_best_mismatches,
    )


def best_subsequence_mismatches(query: str, sequence: str, max_mismatches: int) -> int | None:
    query = query.upper()
    sequence = sequence.upper()
    query_length = len(query)
    if query_length == 0 or len(sequence) < query_length:
        return None
    if query in sequence:
        return 0
    if max_mismatches <= 0:
        return None

    best: int | None = None
    limit = len(sequence) - query_length + 1
    for start in range(limit):
        mismatches = 0
        window = sequence[start : start + query_length]
        for query_base, sequence_base in zip(query, window):
            if query_base != sequence_base:
                mismatches += 1
                if mismatches > max_mismatches:
                    break
        else:
            if best is None or mismatches < best:
                best = mismatches
                if best == 1:
                    return best
    return best
