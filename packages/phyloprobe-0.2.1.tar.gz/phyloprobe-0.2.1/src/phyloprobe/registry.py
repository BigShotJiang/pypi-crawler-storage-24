"""Dataset registry and installation helpers."""

from __future__ import annotations

from contextlib import nullcontext
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
import json
from pathlib import Path
import shutil
import sys
import urllib.request

from phyloprobe.catalog import CatalogDatasetSpec, default_catalog_release, load_catalog, select_catalog_datasets
from phyloprobe.gtdb import sha256_file, summarize_tar_archive, summarize_taxonomy_file
from phyloprobe.paths import (
    dataset_dir,
    ensure_home,
    registry_path,
    resolve_datasets_root,
    resolve_home,
)

DOWNLOAD_CHUNK_SIZE = 1024 * 1024

@dataclass(slots=True)
class ManagedFile:
    file_kind: str
    source_url: str
    managed_path: str
    size_bytes: int
    sha256: str

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


@dataclass(slots=True)
class DatasetRecord:
    key: str
    logical_key: str
    name: str
    dataset_type: str
    taxon: str
    release: str
    created_at: str
    files: dict[str, ManagedFile]
    taxonomy_summary: dict[str, object] = field(default_factory=dict)
    archive_summaries: dict[str, dict[str, object]] = field(default_factory=dict)
    index_summary: dict[str, object] = field(default_factory=dict)

    def to_dict(self) -> dict[str, object]:
        payload = asdict(self)
        return payload


@dataclass(slots=True)
class InstallResult:
    key: str
    name: str
    taxon: str
    status: str
    record: DatasetRecord

    def to_dict(self) -> dict[str, object]:
        return {
            "key": self.key,
            "name": self.name,
            "taxon": self.taxon,
            "status": self.status,
            "record": self.record.to_dict(),
        }


def load_registry(home: str | Path | None = None) -> dict[str, DatasetRecord]:
    """Load the registry into memory."""

    path = registry_path(home)
    if not path.exists():
        return {}

    with path.open("r", encoding="utf-8") as handle:
        payload = json.load(handle)

    datasets = payload.get("datasets", {})
    registry: dict[str, DatasetRecord] = {}
    for name, record in datasets.items():
        files = {
            file_kind: ManagedFile(**managed_file)
            for file_kind, managed_file in record["files"].items()
        }
        registry[name] = DatasetRecord(
            key=record["key"],
            logical_key=record.get("logical_key", record["key"]),
            name=record["name"],
            dataset_type=record["dataset_type"],
            taxon=record["taxon"],
            release=record.get("release", ""),
            created_at=record["created_at"],
            files=files,
            taxonomy_summary=record.get("taxonomy_summary", {}),
            archive_summaries=record.get("archive_summaries", {}),
            index_summary=record.get("index_summary", {}),
        )
    return registry


def save_registry(records: dict[str, DatasetRecord], home: str | Path | None = None) -> Path:
    """Persist the registry to disk."""

    path = registry_path(home)
    payload = {
        "schema_version": 1,
        "datasets": {name: record.to_dict() for name, record in sorted(records.items())},
    }
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True)
        handle.write("\n")
    return path


def _create_download_progress():
    """Create a rich progress instance when available."""

    try:
        from rich.console import Console
        from rich.progress import (
            BarColumn,
            DownloadColumn,
            Progress,
            TextColumn,
            TimeRemainingColumn,
            TransferSpeedColumn,
        )
    except ImportError:
        return nullcontext(None)

    console = Console(stderr=True)
    return Progress(
        TextColumn("[bold cyan]{task.description}"),
        BarColumn(bar_width=32),
        DownloadColumn(),
        TransferSpeedColumn(),
        TimeRemainingColumn(),
        console=console,
        transient=False,
        disable=not console.is_terminal,
    )


def _print_pre_download_message(
    selected: dict[str, CatalogDatasetSpec],
    home: str | Path | None = None,
    datasets_dir: str | Path | None = None,
) -> None:
    """Emit a short message before dataset downloads begin."""

    dataset_count = len(selected)
    label = "dataset" if dataset_count == 1 else "datasets"
    taxon_labels = ", ".join(spec.taxon for spec in selected.values())
    destination = resolve_datasets_root(datasets_dir, home)
    message = (
        f"Installing {dataset_count} {label} "
        f"({taxon_labels}) into {destination}. "
        "File contents depend on the selected dataset type."
    )

    try:
        from rich.console import Console
    except ImportError:
        print(message, file=sys.stderr)
        return

    Console(stderr=True).print(f"[bold cyan]{message}[/bold cyan]")


def _response_total_bytes(response) -> int | None:
    """Best-effort content-length extraction."""

    content_length = response.headers.get("Content-Length")
    if content_length is None:
        return None
    try:
        return int(content_length)
    except ValueError:
        return None


def _download_to_path(source_url: str, output_path: Path, *, description: str, progress=None) -> ManagedFile:
    """Download one remote or file URL into the managed dataset directory."""

    if not source_url:
        raise ValueError(f"Missing URL for output file {output_path.name}.")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    with urllib.request.urlopen(source_url) as response, output_path.open("wb") as handle:
        total_bytes = _response_total_bytes(response)
        task_id = None
        if progress is not None:
            task_id = progress.add_task(description, total=total_bytes)

        bytes_written = 0
        while True:
            chunk = response.read(DOWNLOAD_CHUNK_SIZE)
            if not chunk:
                break
            handle.write(chunk)
            bytes_written += len(chunk)
            if progress is not None and task_id is not None:
                progress.update(task_id, advance=len(chunk))

        if progress is not None and task_id is not None and total_bytes is None:
            progress.update(task_id, total=bytes_written, completed=bytes_written)

    return ManagedFile(
        file_kind="",
        source_url=source_url,
        managed_path=str(output_path.resolve()),
        size_bytes=output_path.stat().st_size,
        sha256=sha256_file(output_path),
    )


def _read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    if not isinstance(payload, dict):
        raise ValueError(f"Expected a JSON object in {path}")
    return payload


def _build_gtdb_dataset_record(spec: CatalogDatasetSpec, dataset_root: Path, *, progress=None) -> DatasetRecord:
    """Download and summarize one GTDB catalog dataset."""

    managed_files: dict[str, ManagedFile] = {}
    archive_summaries: dict[str, dict[str, object]] = {}

    for file_kind, file_spec in spec.files.items():
        output_path = dataset_root / file_spec.filename
        managed_file = _download_to_path(
            file_spec.url,
            output_path,
            description=f"{spec.key}:{file_kind}",
            progress=progress,
        )
        managed_file.file_kind = file_kind
        managed_files[file_kind] = managed_file
        if file_kind in {"msa", "markers"}:
            archive_summaries[file_kind] = summarize_tar_archive(output_path).to_dict()

    taxonomy_summary = summarize_taxonomy_file(Path(managed_files["taxonomy"].managed_path)).to_dict()

    return DatasetRecord(
        key=spec.key,
        logical_key=spec.logical_key,
        name=spec.name,
        dataset_type="gtdb",
        taxon=spec.taxon,
        release=spec.release,
        created_at=datetime.now(timezone.utc).isoformat(),
        files=managed_files,
        taxonomy_summary=taxonomy_summary,
        archive_summaries=archive_summaries,
    )


def _build_fulgor_index_record(spec: CatalogDatasetSpec, dataset_root: Path, *, progress=None) -> DatasetRecord:
    """Download and summarize one Fulgor index dataset."""

    managed_files: dict[str, ManagedFile] = {}
    for file_kind, file_spec in spec.files.items():
        output_path = dataset_root / file_spec.filename
        managed_file = _download_to_path(
            file_spec.url,
            output_path,
            description=f"{spec.key}:{file_kind}",
            progress=progress,
        )
        managed_file.file_kind = file_kind
        managed_files[file_kind] = managed_file

    index_summary = _read_json(Path(managed_files["summary"].managed_path))
    index_summary["index_file"] = managed_files["index"].managed_path
    index_summary["reference_map_file"] = managed_files["reference_map"].managed_path
    index_summary["summary_file"] = managed_files["summary"].managed_path

    return DatasetRecord(
        key=spec.key,
        logical_key=spec.logical_key,
        name=spec.name,
        dataset_type="fulgor_index",
        taxon=spec.taxon,
        release=spec.release,
        created_at=datetime.now(timezone.utc).isoformat(),
        files=managed_files,
        index_summary=index_summary,
    )


def _build_dataset_record(spec: CatalogDatasetSpec, dataset_root: Path, *, progress=None) -> DatasetRecord:
    """Download and summarize one catalog dataset."""

    if spec.dataset_type == "gtdb":
        return _build_gtdb_dataset_record(spec, dataset_root, progress=progress)
    if spec.dataset_type == "fulgor_index":
        return _build_fulgor_index_record(spec, dataset_root, progress=progress)
    raise ValueError(f"Unsupported dataset type '{spec.dataset_type}' for dataset '{spec.key}'.")


def _existing_destination_paths(spec: CatalogDatasetSpec, dataset_root: Path) -> list[Path]:
    """Return target files that already exist for a dataset installation."""

    conflicts: list[Path] = []
    for file_spec in spec.files.values():
        candidate = dataset_root / file_spec.filename
        if candidate.exists():
            conflicts.append(candidate)
    return conflicts


def install_catalog_dataset(
    spec: CatalogDatasetSpec,
    *,
    force: bool = False,
    home: str | Path | None = None,
    datasets_dir: str | Path | None = None,
    progress=None,
) -> InstallResult:
    """Install one dataset described in the catalog."""

    ensure_home(home)
    records = load_registry(home)
    existing = records.get(spec.key)
    dataset_root = dataset_dir(
        spec.key,
        explicit_home=home,
        explicit_datasets_dir=datasets_dir,
    )
    conflicts = _existing_destination_paths(spec, dataset_root)

    if existing is not None and not force:
        if len(conflicts) == len(spec.files):
            return InstallResult(
                key=spec.key,
                name=existing.name,
                taxon=existing.taxon,
                status="skipped",
                record=existing,
            )
        raise ValueError(
            f"Registry already contains dataset '{spec.key}', but the destination directory is incomplete. "
            "Use --force to reinstall the dataset cleanly."
        )

    if conflicts and not force:
        conflict_list = ", ".join(str(path) for path in conflicts)
        raise ValueError(
            f"Destination already contains file(s) for dataset '{spec.key}': {conflict_list}. "
            "Use --force or choose a different --datasets-dir."
        )

    if dataset_root.exists() and force:
        shutil.rmtree(dataset_root)
    dataset_root.mkdir(parents=True, exist_ok=True)

    record = _build_dataset_record(spec, dataset_root, progress=progress)
    records[spec.key] = record
    save_registry(records, home)

    manifest_path = dataset_root / "manifest.json"
    with manifest_path.open("w", encoding="utf-8") as handle:
        json.dump(record.to_dict(), handle, indent=2, sort_keys=True)
        handle.write("\n")

    return InstallResult(
        key=spec.key,
        name=spec.name,
        taxon=spec.taxon,
        status="installed",
        record=record,
    )


def install_catalog_selection(
    *,
    taxon: str = "all",
    catalog_file: str | Path | None = None,
    gtdb_release: str | None = None,
    force: bool = False,
    home: str | Path | None = None,
    datasets_dir: str | Path | None = None,
) -> dict[str, InstallResult]:
    """Install all selected datasets from the configured catalog."""

    catalog = load_catalog(catalog_file, gtdb_release=gtdb_release)
    selected = select_catalog_datasets(catalog, taxon=taxon)
    if not selected:
        raise ValueError(f"No datasets found for taxon selector '{taxon}'.")

    results: dict[str, InstallResult] = {}
    _print_pre_download_message(selected, home=home, datasets_dir=datasets_dir)
    with _create_download_progress() as progress:
        for key, spec in selected.items():
            results[key] = install_catalog_dataset(
                spec,
                force=force,
                home=home,
                datasets_dir=datasets_dir,
                progress=progress,
            )
    return results


def resolve_dataset_record(
    dataset_name: str,
    *,
    gtdb_release: str | None = None,
    dataset_type: str | None = None,
    home: str | Path | None = None,
) -> DatasetRecord:
    """Resolve an installed dataset by exact key or logical dataset name and release."""

    records = load_registry(home)

    exact = records.get(dataset_name)
    if exact is not None:
        if dataset_type is not None and exact.dataset_type != dataset_type:
            raise ValueError(f"Dataset '{dataset_name}' is not a {dataset_type} dataset.")
        if gtdb_release is not None and exact.release != gtdb_release:
            raise ValueError(
                f"Dataset '{dataset_name}' is installed for release '{exact.release}', not '{gtdb_release}'."
            )
        return exact

    resolved_release = gtdb_release
    if resolved_release is None:
        try:
            resolved_release = default_catalog_release()
        except Exception:
            resolved_release = None

    candidates = [
        record
        for record in records.values()
        if dataset_name in {record.logical_key, record.taxon, record.name}
        and (dataset_type is None or record.dataset_type == dataset_type)
    ]
    if resolved_release is not None:
        released = [record for record in candidates if record.release == resolved_release]
        if released:
            candidates = released

    if not candidates:
        if resolved_release is None:
            raise ValueError(f"Dataset not found: {dataset_name}")
        raise ValueError(f"Dataset not found: {dataset_name} (GTDB release {resolved_release})")

    if len(candidates) == 1:
        return candidates[0]

    available = ", ".join(sorted(f"{record.key}[{record.release}]" for record in candidates))
    raise ValueError(
        f"Multiple installed datasets match '{dataset_name}'. "
        f"Provide --gtdb-release or an exact dataset key. Matches: {available}"
    )
