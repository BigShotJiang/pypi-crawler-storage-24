"""Shared taxonomic-scope filters for downstream analysis stages."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any


def validate_taxon_constraint_overlap(
    include_taxa: Mapping[str, set[str]] | None,
    exclude_taxa: Mapping[str, set[str]] | None,
) -> None:
    include_taxa = include_taxa or {}
    exclude_taxa = exclude_taxa or {}
    for level in sorted(set(include_taxa) | set(exclude_taxa)):
        shared = sorted(include_taxa.get(level, set()) & exclude_taxa.get(level, set()))
        if shared:
            raise ValueError(
                "The same taxon cannot be both included and excluded for analysis scope: "
                + ", ".join(f"{level}:{taxon}" for taxon in shared)
            )


def taxon_constraint_payload(
    include_taxa: Mapping[str, set[str]] | None,
    exclude_taxa: Mapping[str, set[str]] | None,
) -> dict[str, dict[str, list[str]]]:
    return {
        "include_taxa": {
            level: sorted(taxa) for level, taxa in (include_taxa or {}).items() if taxa
        },
        "exclude_taxa": {
            level: sorted(taxa) for level, taxa in (exclude_taxa or {}).items() if taxa
        },
    }


def taxonomy_record_matches_scope(
    ranks: Mapping[str, str],
    *,
    include_taxa: Mapping[str, set[str]] | None = None,
    exclude_taxa: Mapping[str, set[str]] | None = None,
) -> bool:
    resolved_include = include_taxa or {}
    resolved_exclude = exclude_taxa or {}

    if resolved_include:
        include_match = False
        for level, taxa in resolved_include.items():
            if not taxa:
                continue
            if ranks.get(level) in taxa:
                include_match = True
                break
        if not include_match:
            return False

    for level, taxa in resolved_exclude.items():
        if taxa and ranks.get(level) in taxa:
            return False

    return True


def format_taxon_constraint_summary(payload: Mapping[str, Any] | None) -> str | None:
    if not payload:
        return None
    parts: list[str] = []
    for level, values in sorted(payload.items()):
        if not values:
            continue
        if isinstance(values, list):
            parts.append(f"{level}:{'|'.join(str(value) for value in values)}")
        else:
            parts.append(f"{level}:{values}")
    if not parts:
        return None
    return ",".join(parts)
