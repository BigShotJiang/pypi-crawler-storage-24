"""Dataset catalog loading for bundled and custom dataset manifests."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import json
from pathlib import Path

DATASET_TYPE_REQUIRED_FILES = {
    "gtdb": ("taxonomy", "msa", "markers"),
    "fulgor_index": ("index", "reference_map", "summary"),
}
VALID_TAXA = frozenset({"archaea", "bacteria"})
VALID_DATASET_TYPES = frozenset(DATASET_TYPE_REQUIRED_FILES)


@dataclass(slots=True)
class CatalogFileSpec:
    filename: str
    url: str

    def to_dict(self) -> dict[str, str]:
        return asdict(self)


@dataclass(slots=True)
class CatalogDatasetSpec:
    key: str
    logical_key: str
    name: str
    dataset_type: str
    taxon: str
    release: str
    files: dict[str, CatalogFileSpec]

    def to_dict(self) -> dict[str, object]:
        return {
            "key": self.key,
            "logical_key": self.logical_key,
            "name": self.name,
            "dataset_type": self.dataset_type,
            "taxon": self.taxon,
            "release": self.release,
            "files": {kind: spec.to_dict() for kind, spec in self.files.items()},
        }


def default_catalog_path() -> Path:
    """Return the bundled dataset catalog path."""

    return Path(__file__).resolve().parent / "data" / "gtdb_datasets.json"


def default_catalog_release(path: str | Path | None = None) -> str:
    """Return the default GTDB release declared in the dataset catalog."""

    catalog_path = Path(path).expanduser().resolve() if path is not None else default_catalog_path()
    with catalog_path.open("r", encoding="utf-8") as handle:
        payload = json.load(handle)

    default_release = str(payload.get("default_release") or payload.get("release") or "").strip()
    if not default_release:
        raise ValueError("Dataset catalog must define a non-empty 'default_release' or legacy 'release' field.")
    return default_release


def _resolve_catalog_release_payload(
    payload: dict[str, object],
    requested_release: str | None,
) -> tuple[str, dict[str, object]]:
    releases_payload = payload.get("releases")
    if isinstance(releases_payload, dict) and releases_payload:
        default_release = str(payload.get("default_release") or "").strip()
        if not default_release:
            raise ValueError("Multi-release dataset catalogs must define a non-empty top-level 'default_release' field.")

        release = str(requested_release or default_release).strip()
        release_payload = releases_payload.get(release)
        if not isinstance(release_payload, dict):
            available = ", ".join(sorted(releases_payload))
            raise ValueError(
                f"Dataset catalog does not define GTDB release '{release}'. Available releases: {available}"
            )
        datasets_payload = release_payload.get("datasets")
        if not isinstance(datasets_payload, dict) or not datasets_payload:
            raise ValueError(f"Dataset catalog release '{release}' must contain a non-empty 'datasets' object.")
        return release, datasets_payload

    release = str(payload.get("release") or "").strip()
    if not release:
        raise ValueError("Dataset catalog must define a non-empty top-level 'release' field.")
    if requested_release is not None and str(requested_release).strip() != release:
        raise ValueError(
            f"Dataset catalog only defines GTDB release '{release}', not '{requested_release}'."
        )
    datasets_payload = payload.get("datasets")
    if not isinstance(datasets_payload, dict) or not datasets_payload:
        raise ValueError("Dataset catalog must contain a non-empty 'datasets' object.")
    return release, datasets_payload


def _catalog_record_key(logical_key: str, release: str, *, multi_release: bool) -> str:
    if not multi_release:
        return logical_key
    return f"{logical_key}_{release}"


def load_catalog(
    path: str | Path | None = None,
    *,
    gtdb_release: str | None = None,
) -> dict[str, CatalogDatasetSpec]:
    """Load and validate a PhyloProbe dataset catalog."""

    catalog_path = Path(path).expanduser().resolve() if path is not None else default_catalog_path()
    with catalog_path.open("r", encoding="utf-8") as handle:
        payload = json.load(handle)

    release, datasets_payload = _resolve_catalog_release_payload(payload, gtdb_release)
    multi_release = isinstance(payload.get("releases"), dict) and bool(payload.get("releases"))

    datasets: dict[str, CatalogDatasetSpec] = {}
    for logical_key, raw_dataset in datasets_payload.items():
        if not isinstance(raw_dataset, dict):
            raise ValueError(f"Dataset '{logical_key}' must be a JSON object.")

        dataset_type = str(raw_dataset.get("dataset_type") or "gtdb").strip()
        if dataset_type not in VALID_DATASET_TYPES:
            allowed = ", ".join(sorted(VALID_DATASET_TYPES))
            raise ValueError(
                f"Dataset '{logical_key}' has invalid dataset_type '{dataset_type}'. "
                f"Allowed values: {allowed}"
            )

        taxon = raw_dataset.get("taxon")
        if taxon not in VALID_TAXA:
            allowed = ", ".join(sorted(VALID_TAXA))
            raise ValueError(f"Dataset '{logical_key}' has invalid taxon '{taxon}'. Allowed values: {allowed}")

        name = str(raw_dataset.get("name") or logical_key).strip()
        if not name:
            raise ValueError(f"Dataset '{logical_key}' must define a non-empty name.")

        raw_files = raw_dataset.get("files")
        if not isinstance(raw_files, dict):
            raise ValueError(f"Dataset '{logical_key}' must define a 'files' object.")

        files: dict[str, CatalogFileSpec] = {}
        required_file_kinds = DATASET_TYPE_REQUIRED_FILES[dataset_type]
        for kind in required_file_kinds:
            raw_spec = raw_files.get(kind)
            if not isinstance(raw_spec, dict):
                raise ValueError(f"Dataset '{logical_key}' is missing required file spec '{kind}'.")

            filename = str(raw_spec.get("filename") or "").strip()
            url = str(raw_spec.get("url") or "").strip()
            if not filename:
                raise ValueError(f"Dataset '{logical_key}' file '{kind}' must define 'filename'.")

            files[kind] = CatalogFileSpec(filename=filename, url=url)

        key = _catalog_record_key(logical_key, release, multi_release=multi_release)
        datasets[key] = CatalogDatasetSpec(
            key=key,
            logical_key=logical_key,
            name=name,
            dataset_type=dataset_type,
            taxon=taxon,
            release=release,
            files=files,
        )

    return datasets


def select_catalog_datasets(
    catalog: dict[str, CatalogDatasetSpec],
    taxon: str = "all",
) -> dict[str, CatalogDatasetSpec]:
    """Filter catalog entries by taxon selector."""

    if taxon == "all":
        return dict(sorted(catalog.items()))
    return {key: spec for key, spec in sorted(catalog.items()) if spec.taxon == taxon}
