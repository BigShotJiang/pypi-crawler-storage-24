"""Shared helpers for bounded process-based parallel execution."""

from __future__ import annotations

from concurrent.futures import ProcessPoolExecutor, as_completed
import os
from typing import Any, Callable, Iterator, Sequence, TypeVar

DEFAULT_AUTO_WORKERS = 0
DEFAULT_AUTO_WORKER_CAP = 4
DEFAULT_CHUNKS_PER_WORKER = 4

Chunk = tuple[int, int]
ResultT = TypeVar("ResultT")


def resolve_worker_count(
    workers: int,
    *,
    total_tasks: int,
    auto_cap: int = DEFAULT_AUTO_WORKER_CAP,
) -> int:
    if workers < 0:
        raise ValueError("--workers must be >= 0.")
    if total_tasks <= 1:
        return 1
    if workers == 0:
        cpu_total = os.cpu_count() or 1
        return max(1, min(auto_cap, cpu_total, total_tasks))
    return max(1, min(workers, total_tasks))


def build_chunks(
    total_tasks: int,
    *,
    workers: int,
    chunks_per_worker: int = DEFAULT_CHUNKS_PER_WORKER,
) -> list[Chunk]:
    if total_tasks <= 0:
        return []
    chunk_count = min(total_tasks, max(1, workers * chunks_per_worker))
    base_size = total_tasks // chunk_count
    remainder = total_tasks % chunk_count
    chunks: list[Chunk] = []
    start = 0
    for index in range(chunk_count):
        chunk_size = base_size + (1 if index < remainder else 0)
        end = start + chunk_size
        if chunk_size > 0:
            chunks.append((start, end))
        start = end
    return chunks


def iter_chunk_results(
    chunks: Sequence[Chunk],
    *,
    worker: Callable[[Chunk], ResultT],
    workers: int,
    initializer: Callable[..., Any] | None = None,
    initargs: Sequence[Any] = (),
) -> Iterator[tuple[Chunk, ResultT]]:
    if workers <= 1 or len(chunks) <= 1:
        if initializer is not None:
            initializer(*tuple(initargs))
        for chunk in chunks:
            yield chunk, worker(chunk)
        return

    try:
        with ProcessPoolExecutor(
            max_workers=workers,
            initializer=initializer,
            initargs=tuple(initargs),
        ) as executor:
            future_to_chunk = {
                executor.submit(worker, chunk): chunk
                for chunk in chunks
            }
            for future in as_completed(future_to_chunk):
                chunk = future_to_chunk[future]
                yield chunk, future.result()
    except (OSError, PermissionError):
        if initializer is not None:
            initializer(*tuple(initargs))
        for chunk in chunks:
            yield chunk, worker(chunk)
