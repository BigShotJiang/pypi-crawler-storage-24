"""Probe design from shortlisted conserved regions."""

from __future__ import annotations

import csv
from dataclasses import dataclass
import json
from pathlib import Path
import sys
import tarfile
from typing import Any, Callable, Mapping, Sequence

from phyloprobe.gtdb import iter_taxonomy_records
from phyloprobe.matching import (
    DEFAULT_MAX_MISMATCHES,
    DEFAULT_MISMATCH_PENALTY_PER_MISMATCH,
    MatchConfig,
    evaluate_query_against_accessions,
    validate_match_config,
)
from phyloprobe.parallel import DEFAULT_AUTO_WORKERS, build_chunks, iter_chunk_results, resolve_worker_count
from phyloprobe.taxon_scope import (
    taxon_constraint_payload,
    taxonomy_record_matches_scope,
    validate_taxon_constraint_overlap,
)
from phyloprobe.thermo import (
    DEFAULT_DNTP_MM,
    DEFAULT_HYB_TEMP_C,
    DEFAULT_MONOVALENT_SALT_MM,
    DEFAULT_DIVALENT_SALT_MM,
    DEFAULT_PROBE_CONC_NM,
    DEFAULT_REGION_SCORE_WEIGHT,
    DEFAULT_SCORING_PROFILE,
    DEFAULT_THERMO_BACKEND,
    DEFAULT_THERMO_PENALTY_WEIGHT,
    ProbeScoringConfig,
    ThermoConditions,
    compute_probe_thermo_metrics,
    ensure_backend_available,
    resolve_probe_scoring_config,
    reverse_complement,
)

ProgressCallback = Callable[[str, Mapping[str, Any]], None]

DEFAULT_PROBE_LENGTH = 30
DEFAULT_TOP_PROBES_PER_REGION = 10
DEFAULT_MIN_GC = 0.35
DEFAULT_MAX_GC = 0.65
DEFAULT_MIN_TM = 50.0
DEFAULT_MAX_TM = 75.0
DEFAULT_MAX_HOMOPOLYMER = 5
DEFAULT_SIBLING_PENALTY_WEIGHT = 2.0
DEFAULT_GLOBAL_PENALTY_WEIGHT = 1.0


@dataclass(slots=True)
class RegionProbeRequest:
    barcode: str
    resolved_level: str
    resolved_taxon: str
    marker_id: str
    aligned_start: int
    aligned_end: int
    window_aa_length: int
    consensus_aa: str
    anchor_accession: str
    anchor_aa_start: int
    anchor_aa_end: int
    lineage: dict[str, str | None]
    parent_level: str | None
    parent_taxon: str | None
    region_score: float
    region_rank_within_target_marker: int


@dataclass(slots=True)
class _ResolvedProbeContext:
    request: RegionProbeRequest
    taxonomy_accessions: set[str]
    sibling_accessions: set[str]
    global_accessions: set[str]
    inferred_lineage: dict[str, str | None]
    parent_level: str | None
    parent_taxon: str | None


@dataclass(slots=True)
class MarkerNucleotideProfile:
    marker_id: str
    member_name: str
    sequences: dict[str, str]


@dataclass(slots=True)
class _ProbeEnumerationOutcome:
    summary_row: dict[str, Any]
    candidate_rows: list[dict[str, Any]]
    selected_rows: list[dict[str, Any]]


@dataclass(slots=True)
class ProbeDesignResult:
    dataset: str | None
    taxonomy_file: str
    markers_archive: str
    region_discovery_prefix: str
    target_probe_summary: list[dict[str, Any]]
    selected_regions: list[dict[str, Any]]
    probe_candidates: list[dict[str, Any]]
    top_probe_manifest: list[dict[str, Any]]
    analyzed_markers: int
    include_taxa: dict[str, list[str]]
    exclude_taxa: dict[str, list[str]]
    probe_length: int
    top_probes_per_region: int
    min_gc: float
    max_gc: float
    min_tm: float
    max_tm: float
    max_homopolymer: int
    sibling_penalty_weight: float
    global_penalty_weight: float
    scoring_config: ProbeScoringConfig
    match_config: MatchConfig
    output_files: dict[str, str] | None = None

    def to_summary_dict(self) -> dict[str, object]:
        summary: dict[str, object] = {
            "dataset": self.dataset,
            "taxonomy_file": self.taxonomy_file,
            "markers_archive": self.markers_archive,
            "region_discovery_prefix": self.region_discovery_prefix,
            "target_probe_summary": self.target_probe_summary,
            "selected_regions": self.selected_regions,
            "analyzed_markers": self.analyzed_markers,
            "include_taxa": self.include_taxa,
            "exclude_taxa": self.exclude_taxa,
            "probe_length": self.probe_length,
            "top_probes_per_region": self.top_probes_per_region,
            "min_gc": self.min_gc,
            "max_gc": self.max_gc,
            "min_tm": self.min_tm,
            "max_tm": self.max_tm,
            "max_homopolymer": self.max_homopolymer,
            "sibling_penalty_weight": self.sibling_penalty_weight,
            "global_penalty_weight": self.global_penalty_weight,
            "output_files": self.output_files,
        }
        summary.update(self.scoring_config.to_summary_dict())
        summary.update(self.match_config.to_summary_dict())
        summary["tm_model"] = "basic" if self.scoring_config.thermo_backend == "basic" else "primer3"
        return summary


def _emit_progress(progress_callback: ProgressCallback | None, event: str, **payload: Any) -> None:
    if progress_callback is not None:
        progress_callback(event, payload)


def _mean(values: Sequence[float]) -> float | None:
    if not values:
        return None
    return sum(values) / float(len(values))


_PROBE_SCORING_STATE: tuple[
    Sequence[_ResolvedProbeContext],
    Mapping[str, MarkerNucleotideProfile],
    Mapping[tuple[str, str, str, str, int, int, int], dict[str, tuple[str, int, int]]],
    int,
    int,
    float,
    float,
    float,
    float,
    int,
    float,
    float,
    ProbeScoringConfig,
    MatchConfig,
] | None = None


def _read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def _read_region_requests(
    region_discovery_prefix: str | Path,
) -> tuple[list[str], list[RegionProbeRequest], dict[str, Any]]:
    prefix = Path(region_discovery_prefix).expanduser().resolve()
    summary_path = prefix.with_name(f"{prefix.name}_summary.json")
    candidates_path = prefix.with_name(f"{prefix.name}_region_candidates.csv")
    remap_manifest_path = prefix.with_name(f"{prefix.name}_region_remap_manifest.csv")
    if not summary_path.exists():
        raise ValueError(f"Region-discovery summary file not found: {summary_path}")
    if not candidates_path.exists():
        raise ValueError(f"Region-discovery candidate file not found: {candidates_path}")
    if not remap_manifest_path.exists():
        raise ValueError(f"Region-discovery remap manifest not found: {remap_manifest_path}")

    region_summary = _read_json(summary_path)
    target_prefix = Path(str(region_summary.get("target_discovery_prefix") or "")).expanduser().resolve()
    target_summary_path = target_prefix.with_name(f"{target_prefix.name}_summary.json")
    if not target_summary_path.exists():
        raise ValueError(f"Target-discovery summary file not found from region discovery context: {target_summary_path}")
    target_summary = _read_json(target_summary_path)
    tag_prefix = Path(str(target_summary.get("tag_design_prefix") or "")).expanduser().resolve()
    tag_summary_path = tag_prefix.with_name(f"{tag_prefix.name}_summary.json")
    if not tag_summary_path.exists():
        raise ValueError(f"Tag-design summary file not found from probe discovery context: {tag_summary_path}")
    tag_summary = _read_json(tag_summary_path)
    levels = list(tag_summary.get("levels") or [])
    if not levels:
        raise ValueError(f"Tag-design summary does not contain levels: {tag_summary_path}")

    requests: list[RegionProbeRequest] = []
    with candidates_path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            barcode = (row.get("barcode") or "").strip()
            resolved_level = (row.get("resolved_level") or "").strip()
            resolved_taxon = (row.get("resolved_taxon") or "").strip()
            marker_id = (row.get("marker_id") or "").strip()
            if not barcode or not resolved_level or not resolved_taxon or not marker_id:
                continue
            lineage = {}
            for level in levels:
                value = (row.get(level) or "").strip()
                lineage[level] = value or None
            try:
                request = RegionProbeRequest(
                    barcode=barcode,
                    resolved_level=resolved_level,
                    resolved_taxon=resolved_taxon,
                    marker_id=marker_id,
                    aligned_start=int(row.get("aligned_start") or 0),
                    aligned_end=int(row.get("aligned_end") or 0),
                    window_aa_length=int(row.get("window_aa_length") or 0),
                    consensus_aa=(row.get("consensus_aa") or "").strip(),
                    anchor_accession=(row.get("anchor_accession") or "").strip(),
                    anchor_aa_start=int(row.get("anchor_aa_start") or 0),
                    anchor_aa_end=int(row.get("anchor_aa_end") or 0),
                    lineage=lineage,
                    parent_level=(row.get("parent_level") or "").strip() or None,
                    parent_taxon=(row.get("parent_taxon") or "").strip() or None,
                    region_score=float(row.get("score") or 0.0),
                    region_rank_within_target_marker=int(row.get("rank_within_target_marker") or 0),
                )
            except ValueError as exc:
                raise ValueError(f"Invalid region candidate row in {candidates_path}") from exc
            requests.append(request)

    if not requests:
        raise ValueError(f"No region candidates were found in: {candidates_path}")
    return levels, requests, region_summary


def _region_request_key(request: RegionProbeRequest) -> tuple[str, str, str, str, int, int, int]:
    return (
        request.barcode,
        request.resolved_level,
        request.resolved_taxon,
        request.marker_id,
        request.aligned_start,
        request.aligned_end,
        request.region_rank_within_target_marker,
    )


def _read_region_remap_manifest(
    region_discovery_prefix: str | Path,
) -> dict[tuple[str, str, str, str, int, int, int], dict[str, tuple[str, int, int]]]:
    prefix = Path(region_discovery_prefix).expanduser().resolve()
    remap_manifest_path = prefix.with_name(f"{prefix.name}_region_remap_manifest.csv")
    if not remap_manifest_path.exists():
        raise ValueError(f"Region-discovery remap manifest not found: {remap_manifest_path}")
    remap_manifest: dict[tuple[str, str, str, str, int, int, int], dict[str, tuple[str, int, int]]] = {}
    with remap_manifest_path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            try:
                key = (
                    str(row["barcode"]),
                    str(row["resolved_level"]),
                    str(row["resolved_taxon"]),
                    str(row["marker_id"]),
                    int(row["aligned_start"]),
                    int(row["aligned_end"]),
                    int(row["rank_within_target_marker"]),
                )
                accession = str(row["accession"])
                remap_manifest.setdefault(key, {})[accession] = (
                    str(row["region_nt_window"]),
                    int(row["region_nt_start"]),
                    int(row["region_nt_end"]),
                )
            except (KeyError, ValueError) as exc:
                raise ValueError(f"Invalid region remap manifest row in {remap_manifest_path}") from exc
    return remap_manifest


def _request_matches_taxonomy(
    ranks: Mapping[str, str],
    request: RegionProbeRequest,
    levels: Sequence[str],
) -> bool:
    explicit_matches = False
    for level in levels:
        expected = request.lineage.get(level)
        if not expected:
            continue
        explicit_matches = True
        if ranks.get(level) != expected:
            return False
    if explicit_matches:
        return True
    return ranks.get(request.resolved_level) == request.resolved_taxon


def _infer_probe_contexts(
    taxonomy_file: str | Path,
    requests: Sequence[RegionProbeRequest],
    levels: Sequence[str],
    *,
    include_taxa: Mapping[str, set[str]] | None = None,
    exclude_taxa: Mapping[str, set[str]] | None = None,
    progress_callback: ProgressCallback | None = None,
) -> list[_ResolvedProbeContext]:
    contexts = [
        _ResolvedProbeContext(
            request=request,
            taxonomy_accessions=set(),
            sibling_accessions=set(),
            global_accessions=set(),
            inferred_lineage={level: request.lineage.get(level) for level in levels},
            parent_level=request.parent_level,
            parent_taxon=request.parent_taxon,
        )
        for request in requests
    ]
    inferred_sets = [{level: set() for level in levels} for _ in requests]
    filtered_records = []
    filtered_accessions: set[str] = set()

    _emit_progress(progress_callback, "taxonomy_resolution_started", requests=len(requests))
    for record in iter_taxonomy_records(taxonomy_file):
        if not taxonomy_record_matches_scope(
            record.ranks,
            include_taxa=include_taxa,
            exclude_taxa=exclude_taxa,
        ):
            continue
        filtered_records.append(record)
        accession = sys.intern(record.accession)
        filtered_accessions.add(accession)
        for index, context in enumerate(contexts):
            if _request_matches_taxonomy(record.ranks, context.request, levels):
                context.taxonomy_accessions.add(accession)
                for level in levels:
                    value = record.ranks.get(level)
                    if value:
                        inferred_sets[index][level].add(value)

    for index, context in enumerate(contexts):
        for level in levels:
            if context.inferred_lineage.get(level):
                continue
            values = inferred_sets[index][level]
            if len(values) == 1:
                context.inferred_lineage[level] = next(iter(values))
        if context.parent_level is None or context.parent_taxon is None:
            resolved_index = levels.index(context.request.resolved_level)
            for level in reversed(levels[:resolved_index]):
                value = context.inferred_lineage.get(level)
                if value:
                    context.parent_level = level
                    context.parent_taxon = value
                    break

    for record in filtered_records:
        accession = sys.intern(record.accession)
        for context in contexts:
            if accession in context.taxonomy_accessions:
                continue
            if context.parent_level and context.parent_taxon:
                parent_index = levels.index(context.parent_level)
                matches_parent = True
                for level in levels[: parent_index + 1]:
                    expected = context.inferred_lineage.get(level)
                    if expected and record.ranks.get(level) != expected:
                        matches_parent = False
                    break
                if matches_parent:
                    context.sibling_accessions.add(accession)
            else:
                context.sibling_accessions.add(accession)
    for context in contexts:
        context.global_accessions = set(filtered_accessions) - set(context.taxonomy_accessions)

    _emit_progress(progress_callback, "taxonomy_resolution_completed", requests=len(requests))
    return contexts


def _marker_id_from_member_name(member_name: str) -> str:
    return Path(member_name).stem


def _count_selected_marker_members(markers_archive: str | Path, selected_marker_ids: set[str]) -> int:
    count = 0
    with tarfile.open(Path(markers_archive).expanduser().resolve(), "r:*") as archive:
        for member in archive:
            if member.isfile() and member.name.endswith(".fna"):
                if _marker_id_from_member_name(member.name) in selected_marker_ids:
                    count += 1
    return count


def _read_marker_nucleotide_profile(
    archive: tarfile.TarFile,
    member: tarfile.TarInfo,
) -> MarkerNucleotideProfile:
    extracted = archive.extractfile(member)
    if extracted is None:
        raise ValueError(f"Unable to read nucleotide marker member from archive: {member.name}")

    sequences: dict[str, str] = {}
    current_accession: str | None = None
    chunks: list[str] = []

    def finalize() -> None:
        nonlocal current_accession, chunks
        if current_accession is None:
            return
        sequences[current_accession] = "".join(chunks).upper()

    for raw_line in extracted:
        line = raw_line.decode("utf-8", errors="replace").strip()
        if not line:
            continue
        if line.startswith(">"):
            finalize()
            current_accession = sys.intern(line[1:].split()[0])
            chunks = []
        else:
            chunks.append(line)
    finalize()

    return MarkerNucleotideProfile(
        marker_id=_marker_id_from_member_name(member.name),
        member_name=member.name,
        sequences=sequences,
    )


def _load_selected_marker_profiles(
    markers_archive: str | Path,
    selected_marker_ids: set[str],
    *,
    progress_callback: ProgressCallback | None = None,
) -> dict[str, MarkerNucleotideProfile]:
    total = _count_selected_marker_members(markers_archive, selected_marker_ids)
    completed = 0
    profiles: dict[str, MarkerNucleotideProfile] = {}
    _emit_progress(progress_callback, "marker_loading_started", total_markers=total)
    with tarfile.open(Path(markers_archive).expanduser().resolve(), "r:*") as archive:
        for member in archive:
            if not (member.isfile() and member.name.endswith(".fna")):
                continue
            marker_id = _marker_id_from_member_name(member.name)
            if marker_id not in selected_marker_ids:
                continue
            profiles[marker_id] = _read_marker_nucleotide_profile(archive, member)
            completed += 1
            _emit_progress(progress_callback, "marker_loading_advanced", completed=completed, total_markers=total)
    _emit_progress(progress_callback, "marker_loading_completed", total_markers=total)
    return profiles


def _gc_fraction(sequence: str) -> float:
    gc = sum(1 for base in sequence if base in {"G", "C"})
    return float(gc) / float(len(sequence)) if sequence else 0.0


def _enumerate_probe_candidates_for_region(
    context: _ResolvedProbeContext,
    marker_profile: MarkerNucleotideProfile,
    target_region_windows: Mapping[str, tuple[str, int, int]],
    *,
    probe_length: int,
    top_probes_per_region: int,
    min_gc: float,
    max_gc: float,
    min_tm: float,
    max_tm: float,
    max_homopolymer: int,
    sibling_penalty_weight: float,
    global_penalty_weight: float,
    scoring_config: ProbeScoringConfig,
    match_config: MatchConfig,
) -> tuple[dict[str, Any], list[dict[str, Any]], list[dict[str, Any]]]:
    target_accessions = sorted(context.taxonomy_accessions & set(target_region_windows))
    sibling_accessions = sorted(context.sibling_accessions & set(marker_profile.sequences))
    global_accessions = sorted(context.global_accessions & set(marker_profile.sequences))

    summary_row = {
        "barcode": context.request.barcode,
        "resolved_level": context.request.resolved_level,
        "resolved_taxon": context.request.resolved_taxon,
        "parent_level": context.parent_level,
        "parent_taxon": context.parent_taxon,
        "marker_id": context.request.marker_id,
        "aligned_start": context.request.aligned_start,
        "aligned_end": context.request.aligned_end,
        "window_aa_length": context.request.window_aa_length,
        "probe_length": probe_length,
        "target_taxonomy_genomes": len(context.taxonomy_accessions),
        "target_mapped_sequences": len(target_accessions),
        "sibling_mapped_sequences": len(sibling_accessions),
        "global_mapped_sequences": len(global_accessions),
        "candidate_probes": 0,
        "selected_probes": 0,
        "status": "ready",
        "best_probe_sequence": None,
        "best_probe_score": None,
    }
    for level, value in context.inferred_lineage.items():
        summary_row[level] = value

    if not target_accessions:
        summary_row["status"] = "no_target_nucleotide_windows"
        return summary_row, [], []

    candidate_rows_by_sequence: dict[str, dict[str, Any]] = {}
    thermo_cache: dict[str, Any] = {}
    for accession in target_accessions:
        nt_window, nt_start, _nt_end = target_region_windows[accession]
        if len(nt_window) < probe_length:
            continue
        for offset in range(0, len(nt_window) - probe_length + 1):
            target_subsequence = nt_window[offset : offset + probe_length]
            if any(base not in {"A", "C", "G", "T"} for base in target_subsequence):
                continue
            gc_fraction = _gc_fraction(target_subsequence)
            if not (min_gc <= gc_fraction <= max_gc):
                continue
            thermo_metrics = thermo_cache.get(target_subsequence)
            if thermo_metrics is None:
                thermo_metrics = compute_probe_thermo_metrics(
                    target_subsequence,
                    backend=scoring_config.thermo_backend,
                    conditions=scoring_config.thermo_conditions,
                )
                thermo_cache[target_subsequence] = thermo_metrics
            if not (min_tm <= thermo_metrics.tm_selected <= max_tm):
                continue
            if thermo_metrics.max_homopolymer > max_homopolymer:
                continue
            if (
                scoring_config.max_dinucleotide_run is not None
                and thermo_metrics.max_dinucleotide_run > scoring_config.max_dinucleotide_run
            ):
                continue
            if (
                scoring_config.min_sequence_entropy is not None
                and thermo_metrics.sequence_entropy < scoring_config.min_sequence_entropy
            ):
                continue
            if (
                scoring_config.max_self_complementarity is not None
                and thermo_metrics.self_complementarity > scoring_config.max_self_complementarity
            ):
                continue
            if (
                scoring_config.max_contiguous_self_complementarity is not None
                and thermo_metrics.contiguous_self_complementarity > scoring_config.max_contiguous_self_complementarity
            ):
                continue
            if (
                scoring_config.max_hairpin_tm is not None
                and thermo_metrics.hairpin_tm is not None
                and thermo_metrics.hairpin_tm > scoring_config.max_hairpin_tm
            ):
                continue
            if (
                scoring_config.max_homodimer_tm is not None
                and thermo_metrics.homodimer_tm is not None
                and thermo_metrics.homodimer_tm > scoring_config.max_homodimer_tm
            ):
                continue

            probe_sequence = reverse_complement(target_subsequence)
            row = {
                "barcode": context.request.barcode,
                "resolved_level": context.request.resolved_level,
                "resolved_taxon": context.request.resolved_taxon,
                "marker_id": context.request.marker_id,
                "aligned_start": context.request.aligned_start,
                "aligned_end": context.request.aligned_end,
                "region_rank_within_target_marker": context.request.region_rank_within_target_marker,
                "anchor_accession": context.request.anchor_accession,
                "source_accession": accession,
                "source_nt_start": nt_start + offset,
                "source_nt_end": nt_start + offset + probe_length - 1,
                "probe_length": probe_length,
                "target_subsequence": target_subsequence,
                "probe_sequence": probe_sequence,
                "gc_fraction": gc_fraction,
                "tm_basic": thermo_metrics.tm_basic,
                "tm_nn": thermo_metrics.tm_nn,
                "tm_selected": thermo_metrics.tm_selected,
                "tm_model": thermo_metrics.tm_model,
                "max_homopolymer": thermo_metrics.max_homopolymer,
                "max_dinucleotide_run": thermo_metrics.max_dinucleotide_run,
                "sequence_entropy": thermo_metrics.sequence_entropy,
                "self_complementarity": thermo_metrics.self_complementarity,
                "contiguous_self_complementarity": thermo_metrics.contiguous_self_complementarity,
                "hairpin_tm": thermo_metrics.hairpin_tm,
                "homodimer_tm": thermo_metrics.homodimer_tm,
                "thermo_penalty": thermo_metrics.thermo_penalty,
                "region_score": context.request.region_score,
            }
            for level, value in context.inferred_lineage.items():
                row[level] = value

            existing = candidate_rows_by_sequence.get(probe_sequence)
            if existing is None or (
                str(row["source_accession"]) < str(existing["source_accession"])
                or (
                    str(row["source_accession"]) == str(existing["source_accession"])
                    and int(row["source_nt_start"]) < int(existing["source_nt_start"])
                )
            ):
                candidate_rows_by_sequence[probe_sequence] = row

    candidate_rows = list(candidate_rows_by_sequence.values())
    summary_row["candidate_probes"] = len(candidate_rows)
    if not candidate_rows:
        summary_row["status"] = "no_passing_probes"
        return summary_row, [], []

    marker_sequences = marker_profile.sequences
    for row in candidate_rows:
        target_summary = evaluate_query_against_accessions(
            str(row["target_subsequence"]),
            target_accessions,
            marker_sequences,
            match_config,
        )
        sibling_summary = evaluate_query_against_accessions(
            str(row["target_subsequence"]),
            sibling_accessions,
            marker_sequences,
            match_config,
        )
        global_summary = evaluate_query_against_accessions(
            str(row["target_subsequence"]),
            global_accessions,
            marker_sequences,
            match_config,
        )
        target_fraction = target_summary.support_fraction
        sibling_fraction = sibling_summary.support_fraction
        global_fraction = global_summary.support_fraction
        score = (
            target_fraction
            - (sibling_penalty_weight * sibling_fraction)
            - (global_penalty_weight * global_fraction)
            + (scoring_config.region_score_weight * context.request.region_score)
            - (scoring_config.thermo_penalty_weight * float(row["thermo_penalty"]))
        )
        row.update(
            {
                "target_mapped_sequences": target_summary.available,
                "target_hits": target_summary.hit_count,
                "target_exact_hits": target_summary.exact_hits,
                "target_mismatch_hits": target_summary.mismatch_hits,
                "target_mean_best_mismatches": target_summary.mean_best_mismatches,
                "target_coverage_fraction": target_summary.hit_fraction,
                "target_effective_coverage_fraction": target_summary.support_fraction,
                "sibling_mapped_sequences": sibling_summary.available,
                "sibling_hits": sibling_summary.hit_count,
                "sibling_exact_hits": sibling_summary.exact_hits,
                "sibling_mismatch_hits": sibling_summary.mismatch_hits,
                "sibling_mean_best_mismatches": sibling_summary.mean_best_mismatches,
                "sibling_offtarget_fraction": sibling_summary.hit_fraction,
                "sibling_effective_offtarget_fraction": sibling_summary.support_fraction,
                "global_mapped_sequences": global_summary.available,
                "global_hits": global_summary.hit_count,
                "global_exact_hits": global_summary.exact_hits,
                "global_mismatch_hits": global_summary.mismatch_hits,
                "global_mean_best_mismatches": global_summary.mean_best_mismatches,
                "global_offtarget_fraction": global_summary.hit_fraction,
                "global_effective_offtarget_fraction": global_summary.support_fraction,
                "score": score,
            }
        )

    candidate_rows.sort(
        key=lambda row: (
            -float(row["score"]),
            -float(row["target_effective_coverage_fraction"]),
            float(row["sibling_effective_offtarget_fraction"]),
            float(row["global_effective_offtarget_fraction"]),
            str(row["probe_sequence"]),
        )
    )
    for rank, row in enumerate(candidate_rows, start=1):
        row["rank_within_region"] = rank
    selected = candidate_rows[:top_probes_per_region]
    summary_row["selected_probes"] = len(selected)
    summary_row["best_probe_sequence"] = selected[0]["probe_sequence"]
    summary_row["best_probe_score"] = selected[0]["score"]
    return summary_row, candidate_rows, selected


def _evaluate_probe_context(
    context: _ResolvedProbeContext,
    marker_profiles: Mapping[str, MarkerNucleotideProfile],
    region_window_manifest: Mapping[tuple[str, str, str, str, int, int, int], dict[str, tuple[str, int, int]]],
    *,
    probe_length: int,
    top_probes_per_region: int,
    min_gc: float,
    max_gc: float,
    min_tm: float,
    max_tm: float,
    max_homopolymer: int,
    sibling_penalty_weight: float,
    global_penalty_weight: float,
    scoring_config: ProbeScoringConfig,
    match_config: MatchConfig,
) -> _ProbeEnumerationOutcome:
    marker_profile = marker_profiles.get(context.request.marker_id)
    region_windows = region_window_manifest.get(_region_request_key(context.request), {})
    if marker_profile is None:
        summary_row = {
            "barcode": context.request.barcode,
            "resolved_level": context.request.resolved_level,
            "resolved_taxon": context.request.resolved_taxon,
            "parent_level": context.parent_level,
            "parent_taxon": context.parent_taxon,
            "marker_id": context.request.marker_id,
            "aligned_start": context.request.aligned_start,
            "aligned_end": context.request.aligned_end,
            "window_aa_length": context.request.window_aa_length,
            "probe_length": probe_length,
            "target_taxonomy_genomes": len(context.taxonomy_accessions),
            "target_mapped_sequences": 0,
            "sibling_mapped_sequences": 0,
            "global_mapped_sequences": 0,
            "candidate_probes": 0,
            "selected_probes": 0,
            "status": "missing_marker_context",
            "best_probe_sequence": None,
            "best_probe_score": None,
        }
        for level, value in context.inferred_lineage.items():
            summary_row[level] = value
        return _ProbeEnumerationOutcome(
            summary_row=summary_row,
            candidate_rows=[],
            selected_rows=[],
        )

    summary_row, candidate_rows, selected_rows = _enumerate_probe_candidates_for_region(
        context,
        marker_profile,
        region_windows,
        probe_length=probe_length,
        top_probes_per_region=top_probes_per_region,
        min_gc=min_gc,
        max_gc=max_gc,
        min_tm=min_tm,
        max_tm=max_tm,
        max_homopolymer=max_homopolymer,
        sibling_penalty_weight=sibling_penalty_weight,
        global_penalty_weight=global_penalty_weight,
        scoring_config=scoring_config,
        match_config=match_config,
    )
    return _ProbeEnumerationOutcome(
        summary_row=summary_row,
        candidate_rows=candidate_rows,
        selected_rows=selected_rows,
    )


def _build_target_probe_summary(
    selected_regions: Sequence[Mapping[str, Any]],
    top_probe_manifest: Sequence[Mapping[str, Any]],
    levels: Sequence[str],
) -> list[dict[str, Any]]:
    region_rows_by_barcode: dict[str, list[Mapping[str, Any]]] = {}
    for row in selected_regions:
        region_rows_by_barcode.setdefault(str(row["barcode"]), []).append(row)

    selected_probe_rows_by_barcode: dict[str, list[Mapping[str, Any]]] = {}
    for row in top_probe_manifest:
        selected_probe_rows_by_barcode.setdefault(str(row["barcode"]), []).append(row)

    summary_rows: list[dict[str, Any]] = []
    for barcode, region_rows in region_rows_by_barcode.items():
        probe_rows = selected_probe_rows_by_barcode.get(barcode, [])
        first_row = region_rows[0]

        input_regions = len(region_rows)
        regions_with_selected_probes = sum(1 for row in region_rows if int(row.get("selected_probes") or 0) > 0)
        missing_context_regions = sum(1 for row in region_rows if str(row.get("status") or "") == "missing_marker_context")
        no_target_window_regions = sum(
            1 for row in region_rows if str(row.get("status") or "") == "no_target_nucleotide_windows"
        )
        no_passing_probe_regions = sum(1 for row in region_rows if str(row.get("status") or "") == "no_passing_probes")

        best_probe_scores = [
            float(row["best_probe_score"])
            for row in region_rows
            if row.get("best_probe_score") not in (None, "")
        ]
        selected_probe_scores = [
            float(row["score"])
            for row in probe_rows
            if row.get("score") not in (None, "")
        ]
        selected_probe_target_fractions = [
            float(row["target_effective_coverage_fraction"])
            for row in probe_rows
            if row.get("target_effective_coverage_fraction") not in (None, "")
        ]
        selected_probe_sibling_fractions = [
            float(row["sibling_effective_offtarget_fraction"])
            for row in probe_rows
            if row.get("sibling_effective_offtarget_fraction") not in (None, "")
        ]
        selected_probe_global_fractions = [
            float(row["global_effective_offtarget_fraction"])
            for row in probe_rows
            if row.get("global_effective_offtarget_fraction") not in (None, "")
        ]

        selected_probes_total = sum(int(row.get("selected_probes") or 0) for row in region_rows)
        if selected_probes_total > 0:
            status = "ready"
        elif missing_context_regions == input_regions:
            status = "missing_marker_context"
        elif no_target_window_regions == input_regions:
            status = "no_target_nucleotide_windows"
        else:
            status = "no_passing_probes"

        summary_row = {
            "barcode": barcode,
            "resolved_level": first_row.get("resolved_level"),
            "resolved_taxon": first_row.get("resolved_taxon"),
            "parent_level": first_row.get("parent_level"),
            "parent_taxon": first_row.get("parent_taxon"),
            "target_taxonomy_genomes": first_row.get("target_taxonomy_genomes"),
            "status": status,
            "input_regions": input_regions,
            "regions_with_selected_probes": regions_with_selected_probes,
            "regions_without_selected_probes": input_regions - regions_with_selected_probes,
            "missing_context_regions": missing_context_regions,
            "no_target_window_regions": no_target_window_regions,
            "no_passing_probe_regions": no_passing_probe_regions,
            "candidate_probes_total": sum(int(row.get("candidate_probes") or 0) for row in region_rows),
            "selected_probes_total": selected_probes_total,
            "markers_with_selected_probes": len(
                {str(row["marker_id"]) for row in region_rows if int(row.get("selected_probes") or 0) > 0}
            ),
            "best_probe_score": max(best_probe_scores) if best_probe_scores else None,
            "mean_best_probe_score": _mean(best_probe_scores),
            "mean_selected_probe_score": _mean(selected_probe_scores),
            "best_selected_probe_target_effective_coverage_fraction": (
                max(selected_probe_target_fractions) if selected_probe_target_fractions else None
            ),
            "lowest_selected_probe_sibling_effective_offtarget_fraction": (
                min(selected_probe_sibling_fractions) if selected_probe_sibling_fractions else None
            ),
            "lowest_selected_probe_global_effective_offtarget_fraction": (
                min(selected_probe_global_fractions) if selected_probe_global_fractions else None
            ),
        }
        for level in levels:
            summary_row[level] = first_row.get(level)
        summary_rows.append(summary_row)

    summary_rows.sort(
        key=lambda row: (
            str(row["resolved_level"]),
            str(row["resolved_taxon"]),
            str(row["barcode"]),
        )
    )
    return summary_rows


def _init_probe_scoring_worker(
    contexts: Sequence[_ResolvedProbeContext],
    marker_profiles: Mapping[str, MarkerNucleotideProfile],
    region_window_manifest: Mapping[tuple[str, str, str, str, int, int, int], dict[str, tuple[str, int, int]]],
    probe_length: int,
    top_probes_per_region: int,
    min_gc: float,
    max_gc: float,
    min_tm: float,
    max_tm: float,
    max_homopolymer: int,
    sibling_penalty_weight: float,
    global_penalty_weight: float,
    scoring_config: ProbeScoringConfig,
    match_config: MatchConfig,
) -> None:
    global _PROBE_SCORING_STATE
    _PROBE_SCORING_STATE = (
        contexts,
        marker_profiles,
        region_window_manifest,
        probe_length,
        top_probes_per_region,
        min_gc,
        max_gc,
        min_tm,
        max_tm,
        max_homopolymer,
        sibling_penalty_weight,
        global_penalty_weight,
        scoring_config,
        match_config,
    )


def _score_probe_chunk(chunk: tuple[int, int]) -> list[_ProbeEnumerationOutcome]:
    if _PROBE_SCORING_STATE is None:
        raise RuntimeError("Probe-scoring worker state has not been initialized.")
    (
        contexts,
        marker_profiles,
        region_window_manifest,
        probe_length,
        top_probes_per_region,
        min_gc,
        max_gc,
        min_tm,
        max_tm,
        max_homopolymer,
        sibling_penalty_weight,
        global_penalty_weight,
        scoring_config,
        match_config,
    ) = _PROBE_SCORING_STATE
    start, end = chunk
    return [
        _evaluate_probe_context(
            contexts[index],
            marker_profiles,
            region_window_manifest,
            probe_length=probe_length,
            top_probes_per_region=top_probes_per_region,
            min_gc=min_gc,
            max_gc=max_gc,
            min_tm=min_tm,
            max_tm=max_tm,
            max_homopolymer=max_homopolymer,
            sibling_penalty_weight=sibling_penalty_weight,
            global_penalty_weight=global_penalty_weight,
            scoring_config=scoring_config,
            match_config=match_config,
        )
        for index in range(start, end)
    ]


def design_probes(
    *,
    taxonomy_file: str | Path,
    markers_archive: str | Path,
    region_discovery_prefix: str | Path,
    dataset: str | None = None,
    include_taxa: Mapping[str, set[str]] | None = None,
    exclude_taxa: Mapping[str, set[str]] | None = None,
    probe_length: int = DEFAULT_PROBE_LENGTH,
    top_probes_per_region: int = DEFAULT_TOP_PROBES_PER_REGION,
    min_gc: float = DEFAULT_MIN_GC,
    max_gc: float = DEFAULT_MAX_GC,
    min_tm: float = DEFAULT_MIN_TM,
    max_tm: float = DEFAULT_MAX_TM,
    max_homopolymer: int = DEFAULT_MAX_HOMOPOLYMER,
    scoring_profile: str = DEFAULT_SCORING_PROFILE,
    thermo_backend: str = DEFAULT_THERMO_BACKEND,
    monovalent_salt_mM: float = DEFAULT_MONOVALENT_SALT_MM,
    divalent_salt_mM: float = DEFAULT_DIVALENT_SALT_MM,
    dntp_mM: float = DEFAULT_DNTP_MM,
    probe_conc_nM: float = DEFAULT_PROBE_CONC_NM,
    hyb_temp_c: float = DEFAULT_HYB_TEMP_C,
    max_dinucleotide_run: int | None = None,
    min_sequence_entropy: float | None = None,
    max_self_complementarity: int | None = None,
    max_contiguous_self_complementarity: int | None = None,
    max_hairpin_tm: float | None = None,
    max_homodimer_tm: float | None = None,
    region_score_weight: float | None = None,
    thermo_penalty_weight: float | None = None,
    max_mismatches: int = DEFAULT_MAX_MISMATCHES,
    mismatch_penalty_per_mismatch: float = DEFAULT_MISMATCH_PENALTY_PER_MISMATCH,
    sibling_penalty_weight: float = DEFAULT_SIBLING_PENALTY_WEIGHT,
    global_penalty_weight: float = DEFAULT_GLOBAL_PENALTY_WEIGHT,
    workers: int = DEFAULT_AUTO_WORKERS,
    progress_callback: ProgressCallback | None = None,
) -> ProbeDesignResult:
    resolved_include_taxa = {level: set(taxa) for level, taxa in (include_taxa or {}).items() if taxa}
    resolved_exclude_taxa = {level: set(taxa) for level, taxa in (exclude_taxa or {}).items() if taxa}
    validate_taxon_constraint_overlap(resolved_include_taxa, resolved_exclude_taxa)
    if probe_length < 1:
        raise ValueError("--probe-length must be at least 1.")
    if top_probes_per_region < 1:
        raise ValueError("--top-probes-per-region must be at least 1.")
    if not (0.0 <= min_gc <= max_gc <= 1.0):
        raise ValueError("GC bounds must satisfy 0 <= min_gc <= max_gc <= 1.")
    if min_tm > max_tm:
        raise ValueError("Tm bounds must satisfy min_tm <= max_tm.")
    if max_homopolymer < 1:
        raise ValueError("--max-homopolymer must be at least 1.")
    if any(value < 0.0 for value in (monovalent_salt_mM, divalent_salt_mM, dntp_mM, probe_conc_nM)):
        raise ValueError("Salt, dNTP, and probe concentration values must be >= 0.")
    match_config = validate_match_config(
        MatchConfig(
            max_mismatches=max_mismatches,
            mismatch_penalty_per_mismatch=mismatch_penalty_per_mismatch,
        )
    )

    scoring_config = resolve_probe_scoring_config(
        scoring_profile=scoring_profile,
        thermo_backend=thermo_backend,
        thermo_conditions=ThermoConditions(
            monovalent_salt_mM=monovalent_salt_mM,
            divalent_salt_mM=divalent_salt_mM,
            dntp_mM=dntp_mM,
            probe_conc_nM=probe_conc_nM,
            hyb_temp_c=hyb_temp_c,
        ),
        max_dinucleotide_run=max_dinucleotide_run,
        min_sequence_entropy=min_sequence_entropy,
        max_self_complementarity=max_self_complementarity,
        max_contiguous_self_complementarity=max_contiguous_self_complementarity,
        max_hairpin_tm=max_hairpin_tm,
        max_homodimer_tm=max_homodimer_tm,
        region_score_weight=region_score_weight,
        thermo_penalty_weight=thermo_penalty_weight,
    )
    ensure_backend_available(scoring_config.thermo_backend)

    resolved_taxonomy = str(Path(taxonomy_file).expanduser().resolve())
    resolved_markers = str(Path(markers_archive).expanduser().resolve())
    resolved_region_prefix = str(Path(region_discovery_prefix).expanduser().resolve())

    levels, requests, _region_summary = _read_region_requests(region_discovery_prefix)
    region_window_manifest = _read_region_remap_manifest(region_discovery_prefix)
    if not any(region_window_manifest.values()):
        raise ValueError(
            "Region remap manifest is empty. This indicates that the upstream `phyloprobe regions` run did not produce nucleotide remapping metadata."
        )
    contexts = _infer_probe_contexts(
        resolved_taxonomy,
        requests,
        levels,
        include_taxa=resolved_include_taxa,
        exclude_taxa=resolved_exclude_taxa,
        progress_callback=progress_callback,
    )
    missing_requests = [
        f"{context.request.barcode}:{context.request.resolved_level}:{context.request.resolved_taxon}:{context.request.marker_id}"
        for context in contexts
        if not context.taxonomy_accessions
    ]
    if missing_requests:
        raise ValueError(
            "Selected region requests are absent after applying the probe-analysis taxon scope. "
            "Adjust --include/--exclude or the upstream region discovery. Missing requests: "
            + ", ".join(sorted(missing_requests))
        )
    selected_marker_ids = {context.request.marker_id for context in contexts}
    marker_profiles = _load_selected_marker_profiles(
        resolved_markers,
        selected_marker_ids,
        progress_callback=progress_callback,
    )

    _emit_progress(progress_callback, "probe_scoring_started", total_regions=len(contexts))
    selected_regions: list[dict[str, Any]] = []
    probe_candidates: list[dict[str, Any]] = []
    top_probe_manifest: list[dict[str, Any]] = []
    completed = 0
    resolved_workers = resolve_worker_count(workers, total_tasks=len(contexts))
    scoring_chunks = build_chunks(len(contexts), workers=resolved_workers)
    for chunk, outcomes in iter_chunk_results(
        scoring_chunks,
        worker=_score_probe_chunk,
        workers=resolved_workers,
        initializer=_init_probe_scoring_worker,
        initargs=(
            contexts,
            marker_profiles,
            region_window_manifest,
            probe_length,
            top_probes_per_region,
            min_gc,
            max_gc,
            min_tm,
            max_tm,
            max_homopolymer,
            sibling_penalty_weight,
            global_penalty_weight,
            scoring_config,
            match_config,
        ),
    ):
        for outcome in outcomes:
            selected_regions.append(outcome.summary_row)
            probe_candidates.extend(outcome.candidate_rows)
            top_probe_manifest.extend(outcome.selected_rows)
        completed += chunk[1] - chunk[0]
        _emit_progress(progress_callback, "probe_scoring_advanced", completed=completed, total_regions=len(contexts))
    _emit_progress(progress_callback, "probe_scoring_completed", total_regions=len(contexts))

    selected_regions.sort(
        key=lambda row: (
            str(row["barcode"]),
            str(row["marker_id"]),
            int(row["aligned_start"]),
            int(row["aligned_end"]),
        )
    )
    top_probe_manifest.sort(
        key=lambda row: (
            str(row["barcode"]),
            str(row["marker_id"]),
            int(row["aligned_start"]),
            int(row["rank_within_region"]),
        )
    )
    probe_candidates.sort(
        key=lambda row: (
            str(row["barcode"]),
            str(row["marker_id"]),
            int(row["aligned_start"]),
            int(row["rank_within_region"]),
        )
    )
    target_probe_summary = _build_target_probe_summary(selected_regions, top_probe_manifest, levels)
    constraint_summary = taxon_constraint_payload(resolved_include_taxa, resolved_exclude_taxa)

    return ProbeDesignResult(
        dataset=dataset,
        taxonomy_file=resolved_taxonomy,
        markers_archive=resolved_markers,
        region_discovery_prefix=resolved_region_prefix,
        target_probe_summary=target_probe_summary,
        selected_regions=selected_regions,
        probe_candidates=probe_candidates,
        top_probe_manifest=top_probe_manifest,
        analyzed_markers=len(selected_marker_ids),
        include_taxa=constraint_summary["include_taxa"],
        exclude_taxa=constraint_summary["exclude_taxa"],
        probe_length=probe_length,
        top_probes_per_region=top_probes_per_region,
        min_gc=min_gc,
        max_gc=max_gc,
        min_tm=min_tm,
        max_tm=max_tm,
        max_homopolymer=max_homopolymer,
        sibling_penalty_weight=sibling_penalty_weight,
        global_penalty_weight=global_penalty_weight,
        scoring_config=scoring_config,
        match_config=match_config,
    )


def _write_csv(path: Path, rows: Sequence[Mapping[str, Any]]) -> None:
    rows = list(rows)
    fieldnames: list[str] = []
    for row in rows:
        for key in row.keys():
            if key not in fieldnames:
                fieldnames.append(key)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        if fieldnames:
            writer.writeheader()
            for row in rows:
                writer.writerow({key: row.get(key) for key in fieldnames})


def write_probe_design_outputs(
    result: ProbeDesignResult,
    output_prefix: str | Path,
) -> dict[str, Path]:
    output_prefix = Path(output_prefix).expanduser().resolve()
    output_prefix.parent.mkdir(parents=True, exist_ok=True)
    paths = {
        "summary": output_prefix.with_name(f"{output_prefix.name}_summary.json"),
        "target_summary": output_prefix.with_name(f"{output_prefix.name}_target_probe_summary.csv"),
        "selected_regions": output_prefix.with_name(f"{output_prefix.name}_selected_regions.csv"),
        "probe_candidates": output_prefix.with_name(f"{output_prefix.name}_probe_candidates.csv"),
        "top_probes": output_prefix.with_name(f"{output_prefix.name}_top_probe_manifest.csv"),
    }
    _write_csv(paths["target_summary"], result.target_probe_summary)
    _write_csv(paths["selected_regions"], result.selected_regions)
    _write_csv(paths["probe_candidates"], result.probe_candidates)
    _write_csv(paths["top_probes"], result.top_probe_manifest)
    result.output_files = {name: str(path.resolve()) for name, path in paths.items()}
    with paths["summary"].open("w", encoding="utf-8") as handle:
        json.dump(result.to_summary_dict(), handle, indent=2, sort_keys=True)
        handle.write("\n")
    return paths
