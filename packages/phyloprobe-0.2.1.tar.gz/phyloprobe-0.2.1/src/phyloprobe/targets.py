"""Target taxon and marker discovery based on tag-design outputs."""

from __future__ import annotations

import csv
from dataclasses import dataclass
import json
from pathlib import Path
import sys
import tarfile
from typing import Any, Callable, Mapping, Sequence

from phyloprobe.gtdb import iter_taxonomy_records
from phyloprobe.parallel import DEFAULT_AUTO_WORKERS, build_chunks, iter_chunk_results, resolve_worker_count
from phyloprobe.profile_defaults import (
    get_stage_default_profile,
    get_stage_profile_defaults,
    get_stage_profile_names,
)
from phyloprobe.taxon_scope import (
    taxon_constraint_payload,
    taxonomy_record_matches_scope,
    validate_taxon_constraint_overlap,
)

ProgressCallback = Callable[[str, Mapping[str, Any]], None]

DEFAULT_TOP_MARKERS_PER_TARGET = 10
DEFAULT_SIBLING_PENALTY_WEIGHT = 2.0
DEFAULT_GLOBAL_PENALTY_WEIGHT = 1.0
DEFAULT_FALLBACK_POLICY = "none"
DEFAULT_SELECTION_PROFILE = get_stage_default_profile("targets")
VALID_SELECTION_PROFILES = set(get_stage_profile_names("targets"))


@dataclass(slots=True, frozen=True)
class TargetSelection:
    candidate_id: str
    barcode: str
    resolved_level: str
    resolved_taxon: str
    lineage: dict[str, str | None]
    parent_level: str | None
    parent_taxon: str | None
    tag_design_genomes: float | None
    priority: int
    selection_source: str
    primary_resolved_level: str
    primary_resolved_taxon: str


@dataclass(slots=True)
class MarkerProfile:
    marker_id: str
    member_name: str
    sequence_count: int
    accessions: set[str]
    min_nt_length: int | None
    max_nt_length: int | None
    mean_nt_length: float | None


@dataclass(slots=True)
class _TargetGenomeSets:
    selection: TargetSelection
    taxonomy_accessions: set[str]
    sibling_taxonomy_accessions: set[str]
    available_accessions: set[str]
    sibling_available_accessions: set[str]
    global_available_accessions: set[str]


@dataclass(slots=True)
class TargetDiscoveryResult:
    dataset: str | None
    taxonomy_file: str
    markers_archive: str
    tag_design_prefix: str
    selected_targets: list[dict[str, Any]]
    marker_scores: list[dict[str, Any]]
    top_marker_manifest: list[dict[str, Any]]
    analyzed_markers: int
    all_marker_available_genomes: int
    selection_profile: str
    top_markers_per_target: int
    fallback_policy: list[str]
    promoted_targets: int
    include_taxa: dict[str, list[str]]
    exclude_taxa: dict[str, list[str]]
    sibling_penalty_weight: float
    global_penalty_weight: float
    output_files: dict[str, str] | None = None

    def to_summary_dict(self) -> dict[str, object]:
        return {
            "dataset": self.dataset,
            "taxonomy_file": self.taxonomy_file,
            "markers_archive": self.markers_archive,
            "tag_design_prefix": self.tag_design_prefix,
            "selected_targets": self.selected_targets,
            "analyzed_markers": self.analyzed_markers,
            "all_marker_available_genomes": self.all_marker_available_genomes,
            "profile": self.selection_profile,
            "selection_profile": self.selection_profile,
            "top_markers_per_target": self.top_markers_per_target,
            "fallback_policy": self.fallback_policy,
            "promoted_targets": self.promoted_targets,
            "include_taxa": self.include_taxa,
            "exclude_taxa": self.exclude_taxa,
            "sibling_penalty_weight": self.sibling_penalty_weight,
            "global_penalty_weight": self.global_penalty_weight,
            "output_files": self.output_files,
        }


def _emit_progress(progress_callback: ProgressCallback | None, event: str, **payload: Any) -> None:
    if progress_callback is not None:
        progress_callback(event, payload)


def _mean(values: Sequence[float]) -> float | None:
    if not values:
        return None
    return sum(values) / float(len(values))


_TARGET_SCORING_STATE: tuple[
    Sequence[_TargetGenomeSets],
    Sequence[MarkerProfile],
    Sequence[str],
    float,
    float,
] | None = None


def _read_tag_design_summary(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def _parent_for_lineage(levels: Sequence[str], resolved_level: str, lineage: Mapping[str, str | None]) -> tuple[str | None, str | None]:
    resolved_index = levels.index(resolved_level)
    for level in reversed(levels[:resolved_index]):
        value = lineage.get(level)
        if value:
            return level, value
    return None, None


def _status_from_available_count(available_count: int) -> str:
    if available_count <= 0:
        return "no_marker_genomes"
    if available_count == 1:
        return "single_marker_genome"
    return "ready"


def _status_rank(status: str) -> int:
    if status == "ready":
        return 2
    if status == "single_marker_genome":
        return 1
    return 0


def _resolve_fallback_policy(spec: str | Sequence[str] | None) -> set[str]:
    if spec is None:
        return set()
    tokens: list[str] = []
    if isinstance(spec, str):
        tokens = [token.strip() for token in spec.split(",") if token.strip()]
    else:
        for raw_item in spec:
            tokens.extend(token.strip() for token in str(raw_item).split(",") if token.strip())
    if not tokens:
        return set()

    resolved: set[str] = set()
    for token in tokens:
        if token == "none":
            if len(tokens) > 1:
                raise ValueError("--fallback-policy cannot combine 'none' with other values.")
            return set()
        if token == "missing_or_single":
            resolved.update({"no_marker_genomes", "single_marker_genome"})
            continue
        if token in {"no_marker_genomes", "single_marker_genome"}:
            resolved.add(token)
            continue
        raise ValueError(
            "--fallback-policy must be one of: none, no_marker_genomes, single_marker_genome, missing_or_single."
        )
    return resolved


def validate_selection_profile(name: str) -> str:
    normalized = str(name).strip().lower()
    if normalized not in VALID_SELECTION_PROFILES:
        valid = ", ".join(sorted(VALID_SELECTION_PROFILES))
        raise ValueError(f"Unsupported target selection profile '{name}'. Choose one of: {valid}.")
    return normalized


def _target_profile_defaults(profile: str) -> dict[str, float | int]:
    return get_stage_profile_defaults("targets", profile)


def _selection_identity(selection: TargetSelection, levels: Sequence[str]) -> tuple[str | None, ...]:
    return tuple(selection.lineage.get(level) for level in levels)


def _build_target_selection(
    *,
    row: Mapping[str, str],
    levels: Sequence[str],
    selection_source: str,
    priority: int,
    fallback_rank: int | None = None,
) -> TargetSelection | None:
    barcode = (row.get("barcode") or "").strip()
    resolved_level = (row.get("resolved_level") or "").strip()
    resolved_taxon = (row.get("resolved_taxon") or "").strip()
    if not barcode or not resolved_level or not resolved_taxon:
        return None

    lineage = {}
    for level in levels:
        value = (row.get(level) or "").strip()
        lineage[level] = value or None
    parent_level = (row.get("parent_level") or "").strip() or None
    parent_taxon = (row.get("parent_taxon") or "").strip() or None
    if parent_level is None and resolved_level in levels:
        parent_level, parent_taxon = _parent_for_lineage(levels, resolved_level, lineage)
    genomes = row.get("genomes")
    try:
        tag_design_genomes = None if genomes in (None, "") else float(genomes)
    except ValueError:
        tag_design_genomes = None

    primary_resolved_level = (row.get("primary_resolved_level") or "").strip() or resolved_level
    primary_resolved_taxon = (row.get("primary_resolved_taxon") or "").strip() or resolved_taxon
    candidate_suffix = "primary" if selection_source == "primary" else f"fallback_{fallback_rank}"
    return TargetSelection(
        candidate_id=f"{barcode}:{candidate_suffix}",
        barcode=barcode,
        resolved_level=resolved_level,
        resolved_taxon=resolved_taxon,
        lineage=lineage,
        parent_level=parent_level,
        parent_taxon=parent_taxon,
        tag_design_genomes=tag_design_genomes,
        priority=priority,
        selection_source=selection_source,
        primary_resolved_level=primary_resolved_level,
        primary_resolved_taxon=primary_resolved_taxon,
    )


def _read_target_selections(
    tag_design_prefix: str | Path,
) -> tuple[list[str], list[TargetSelection], dict[str, list[TargetSelection]], dict[str, Any]]:
    prefix = Path(tag_design_prefix).expanduser().resolve()
    summary_path = prefix.with_name(f"{prefix.name}_summary.json")
    leaves_path = prefix.with_name(f"{prefix.name}_final_leaf_labels.csv")
    fallbacks_path = prefix.with_name(f"{prefix.name}_fallback_leaf_labels.csv")
    if not summary_path.exists():
        raise ValueError(f"Tag-design summary file not found: {summary_path}")
    if not leaves_path.exists():
        raise ValueError(f"Tag-design final leaf labels file not found: {leaves_path}")

    summary = _read_tag_design_summary(summary_path)
    levels = list(summary.get("levels") or [])
    if not levels:
        raise ValueError(f"Tag-design summary does not contain levels: {summary_path}")

    selections: list[TargetSelection] = []
    with leaves_path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            selection = _build_target_selection(
                row=row,
                levels=levels,
                selection_source="primary",
                priority=0,
            )
            if selection is not None:
                selections.append(selection)

    if not selections:
        raise ValueError(f"No selected taxa were found in tag-design leaves file: {leaves_path}")

    fallbacks_by_barcode: dict[str, list[TargetSelection]] = {selection.barcode: [] for selection in selections}
    primary_identities = {
        _selection_identity(selection, levels)
        for selection in selections
    }
    if fallbacks_path.exists():
        with fallbacks_path.open("r", encoding="utf-8", newline="") as handle:
            reader = csv.DictReader(handle)
            for row in reader:
                barcode = (row.get("barcode") or "").strip()
                if not barcode or barcode not in fallbacks_by_barcode:
                    continue
                fallback_rank_raw = (row.get("fallback_rank") or "").strip()
                try:
                    fallback_rank = int(fallback_rank_raw)
                except ValueError:
                    continue
                selection = _build_target_selection(
                    row=row,
                    levels=levels,
                    selection_source="fallback",
                    priority=fallback_rank,
                    fallback_rank=fallback_rank,
                )
                if selection is not None and _selection_identity(selection, levels) not in primary_identities:
                    fallbacks_by_barcode[barcode].append(selection)

    for barcode in fallbacks_by_barcode:
        fallbacks_by_barcode[barcode].sort(
            key=lambda selection: (selection.priority, selection.resolved_taxon)
        )

    return levels, selections, fallbacks_by_barcode, summary


def _taxonomy_record_matches_selection(
    ranks: Mapping[str, str],
    selection: TargetSelection,
    levels: Sequence[str],
) -> bool:
    for level in levels:
        expected = selection.lineage.get(level)
        if not expected:
            continue
        if ranks.get(level) != expected:
            return False
    return True


def _taxonomy_record_matches_parent(
    ranks: Mapping[str, str],
    selection: TargetSelection,
    levels: Sequence[str],
) -> bool:
    parent_level = selection.parent_level
    if not parent_level:
        return True
    parent_index = levels.index(parent_level)
    for level in levels[: parent_index + 1]:
        expected = selection.lineage.get(level)
        if not expected:
            continue
        if ranks.get(level) != expected:
            return False
    return True


def _load_taxonomy_accessions_by_target(
    taxonomy_file: str | Path,
    selections: Sequence[TargetSelection],
    levels: Sequence[str],
    *,
    include_taxa: Mapping[str, set[str]] | None = None,
    exclude_taxa: Mapping[str, set[str]] | None = None,
    progress_callback: ProgressCallback | None = None,
) -> tuple[list[_TargetGenomeSets], set[str]]:
    filtered_accessions: set[str] = set()
    targets = [
        _TargetGenomeSets(
            selection=selection,
            taxonomy_accessions=set(),
            sibling_taxonomy_accessions=set(),
            available_accessions=set(),
            sibling_available_accessions=set(),
            global_available_accessions=set(),
        )
        for selection in selections
    ]

    _emit_progress(progress_callback, "taxonomy_loading_started", targets=len(selections))
    for record in iter_taxonomy_records(taxonomy_file):
        if not taxonomy_record_matches_scope(
            record.ranks,
            include_taxa=include_taxa,
            exclude_taxa=exclude_taxa,
        ):
            continue
        accession = sys.intern(record.accession)
        filtered_accessions.add(accession)
        for target in targets:
            if _taxonomy_record_matches_selection(record.ranks, target.selection, levels):
                target.taxonomy_accessions.add(accession)
            elif _taxonomy_record_matches_parent(record.ranks, target.selection, levels):
                target.sibling_taxonomy_accessions.add(accession)

    _emit_progress(
        progress_callback,
        "taxonomy_loading_completed",
        genomes=len(filtered_accessions),
        targets=len(selections),
    )
    return targets, filtered_accessions


def _count_marker_members(markers_archive: str | Path) -> int:
    archive_path = Path(markers_archive).expanduser().resolve()
    count = 0
    with tarfile.open(archive_path, "r:*") as archive:
        for member in archive:
            if member.isfile() and member.name.endswith(".fna"):
                count += 1
    return count


def _marker_id_from_member_name(member_name: str) -> str:
    return Path(member_name).stem


def _read_marker_profile(archive: tarfile.TarFile, member: tarfile.TarInfo) -> MarkerProfile:
    extracted = archive.extractfile(member)
    if extracted is None:
        raise ValueError(f"Unable to read marker member from archive: {member.name}")

    accessions: set[str] = set()
    current_accession: str | None = None
    current_length = 0
    sequence_count = 0
    length_total = 0
    min_length: int | None = None
    max_length: int | None = None

    def finalize_sequence() -> None:
        nonlocal sequence_count, length_total, min_length, max_length, current_accession, current_length
        if current_accession is None:
            return
        sequence_count += 1
        length_total += current_length
        if min_length is None or current_length < min_length:
            min_length = current_length
        if max_length is None or current_length > max_length:
            max_length = current_length

    for raw_line in extracted:
        line = raw_line.decode("utf-8", errors="replace").strip()
        if not line:
            continue
        if line.startswith(">"):
            finalize_sequence()
            current_accession = sys.intern(line[1:].split()[0])
            current_length = 0
            accessions.add(current_accession)
        else:
            current_length += len(line)
    finalize_sequence()

    mean_length = None
    if sequence_count > 0:
        mean_length = float(length_total) / float(sequence_count)
    return MarkerProfile(
        marker_id=_marker_id_from_member_name(member.name),
        member_name=member.name,
        sequence_count=sequence_count,
        accessions=accessions,
        min_nt_length=min_length,
        max_nt_length=max_length,
        mean_nt_length=mean_length,
    )


def _iter_marker_profiles(
    markers_archive: str | Path,
    *,
    progress_callback: ProgressCallback | None = None,
    phase: str,
) -> tuple[int, list[MarkerProfile]]:
    archive_path = Path(markers_archive).expanduser().resolve()
    profiles: list[MarkerProfile] = []
    completed = 0
    total_markers = _count_marker_members(archive_path)
    _emit_progress(progress_callback, f"{phase}_started", total_markers=total_markers)
    with tarfile.open(archive_path, "r:*") as archive:
        for member in archive:
            if not (member.isfile() and member.name.endswith(".fna")):
                continue
            profiles.append(_read_marker_profile(archive, member))
            completed += 1
            _emit_progress(
                progress_callback,
                f"{phase}_advanced",
                completed=completed,
                total_markers=total_markers,
            )
    _emit_progress(progress_callback, f"{phase}_completed", total_markers=total_markers)
    return total_markers, profiles


def _safe_rate(numerator: int, denominator: int) -> float:
    if denominator <= 0:
        return 0.0
    return float(numerator) / float(denominator)


def _score_marker_profile_rows(
    profile: MarkerProfile,
    *,
    target_sets: Sequence[_TargetGenomeSets],
    levels: Sequence[str],
    sibling_penalty_weight: float,
    global_penalty_weight: float,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for target in target_sets:
        target_available = len(target.available_accessions)
        sibling_available = len(target.sibling_available_accessions)
        global_non_target_available = len(target.global_available_accessions)
        target_hits = len(profile.accessions & target.available_accessions)
        sibling_hits = len(profile.accessions & target.sibling_available_accessions)
        global_hits = len(profile.accessions & target.global_available_accessions)
        target_occupancy = _safe_rate(target_hits, target_available)
        sibling_rate = _safe_rate(sibling_hits, sibling_available)
        global_rate = _safe_rate(global_hits, global_non_target_available)
        score = (
            target_occupancy
            - (sibling_penalty_weight * sibling_rate)
            - (global_penalty_weight * global_rate)
        )

        row = {
            "barcode": target.selection.barcode,
            "resolved_level": target.selection.resolved_level,
            "resolved_taxon": target.selection.resolved_taxon,
            "primary_resolved_level": target.selection.primary_resolved_level,
            "primary_resolved_taxon": target.selection.primary_resolved_taxon,
            "parent_level": target.selection.parent_level,
            "parent_taxon": target.selection.parent_taxon,
            "selection_source": target.selection.selection_source,
            "selection_priority": target.selection.priority,
            "marker_id": profile.marker_id,
            "member_name": profile.member_name,
            "sequence_count": profile.sequence_count,
            "min_nt_length": profile.min_nt_length,
            "max_nt_length": profile.max_nt_length,
            "mean_nt_length": profile.mean_nt_length,
            "target_taxonomy_genomes": len(target.taxonomy_accessions),
            "target_marker_available_genomes": target_available,
            "target_hits": target_hits,
            "target_occupancy": target_occupancy,
            "sibling_taxonomy_genomes": len(target.sibling_taxonomy_accessions),
            "sibling_marker_available_genomes": sibling_available,
            "sibling_hits": sibling_hits,
            "sibling_offtarget_rate": sibling_rate,
            "global_non_target_marker_available_genomes": global_non_target_available,
            "global_offtarget_hits": global_hits,
            "global_offtarget_rate": global_rate,
            "score": score,
        }
        for level in levels:
            row[level] = target.selection.lineage.get(level)
        rows.append(row)
    return rows


def _init_target_scoring_worker(
    target_sets: Sequence[_TargetGenomeSets],
    profiles: Sequence[MarkerProfile],
    levels: Sequence[str],
    sibling_penalty_weight: float,
    global_penalty_weight: float,
) -> None:
    global _TARGET_SCORING_STATE
    _TARGET_SCORING_STATE = (
        target_sets,
        profiles,
        levels,
        sibling_penalty_weight,
        global_penalty_weight,
    )


def _score_marker_chunk(chunk: tuple[int, int]) -> list[dict[str, Any]]:
    if _TARGET_SCORING_STATE is None:
        raise RuntimeError("Target scoring worker state has not been initialized.")
    target_sets, profiles, levels, sibling_penalty_weight, global_penalty_weight = _TARGET_SCORING_STATE
    start, end = chunk
    rows: list[dict[str, Any]] = []
    for profile in profiles[start:end]:
        rows.extend(
            _score_marker_profile_rows(
                profile,
                target_sets=target_sets,
                levels=levels,
                sibling_penalty_weight=sibling_penalty_weight,
                global_penalty_weight=global_penalty_weight,
            )
        )
    return rows


def _select_active_target_sets(
    target_sets: Sequence[_TargetGenomeSets],
    levels: Sequence[str],
    fallback_policy: set[str],
) -> tuple[list[_TargetGenomeSets], dict[str, dict[str, Any]], int]:
    by_barcode: dict[str, list[_TargetGenomeSets]] = {}
    barcode_order: list[str] = []
    for target in target_sets:
        barcode = target.selection.barcode
        if barcode not in by_barcode:
            by_barcode[barcode] = []
            barcode_order.append(barcode)
        by_barcode[barcode].append(target)

    active_targets: list[_TargetGenomeSets] = []
    decisions: dict[str, dict[str, Any]] = {}
    assigned_identities: set[tuple[str | None, ...]] = set()
    promoted_targets = 0

    for barcode in barcode_order:
        candidates = sorted(
            by_barcode[barcode],
            key=lambda target: (target.selection.priority, target.selection.resolved_taxon),
        )
        primary = next(
            (target for target in candidates if target.selection.selection_source == "primary"),
            candidates[0],
        )
        primary_status = _status_from_available_count(len(primary.available_accessions))
        selected_target = primary
        promotion_reason: str | None = None

        if primary_status in fallback_policy:
            eligible_fallbacks = []
            for candidate in candidates:
                if candidate.selection.selection_source != "fallback":
                    continue
                candidate_status = _status_from_available_count(len(candidate.available_accessions))
                if _status_rank(candidate_status) <= _status_rank(primary_status):
                    continue
                identity = _selection_identity(candidate.selection, levels)
                if identity in assigned_identities:
                    continue
                eligible_fallbacks.append((candidate, candidate_status))
            if eligible_fallbacks:
                eligible_fallbacks.sort(
                    key=lambda item: (
                        -_status_rank(item[1]),
                        item[0].selection.priority,
                        item[0].selection.resolved_taxon,
                    )
                )
                selected_target = eligible_fallbacks[0][0]
                promotion_reason = primary_status
                promoted_targets += 1

        selected_status = _status_from_available_count(len(selected_target.available_accessions))
        assigned_identities.add(_selection_identity(selected_target.selection, levels))
        active_targets.append(selected_target)
        decisions[barcode] = {
            "primary_status": primary_status,
            "status": selected_status,
            "selection_source": selected_target.selection.selection_source,
            "selection_priority": selected_target.selection.priority,
            "available_fallback_candidates": sum(
                1 for candidate in candidates if candidate.selection.selection_source == "fallback"
            ),
            "improving_fallback_candidates": sum(
                1
                for candidate in candidates
                if candidate.selection.selection_source == "fallback"
                and _status_rank(
                    _status_from_available_count(len(candidate.available_accessions))
                )
                > _status_rank(primary_status)
            ),
            "promotion_reason": promotion_reason,
        }

    return active_targets, decisions, promoted_targets


def discover_targets(
    *,
    taxonomy_file: str | Path,
    markers_archive: str | Path,
    tag_design_prefix: str | Path,
    dataset: str | None = None,
    selection_profile: str = DEFAULT_SELECTION_PROFILE,
    top_markers_per_target: int | None = None,
    fallback_policy: str | Sequence[str] | None = DEFAULT_FALLBACK_POLICY,
    include_taxa: Mapping[str, set[str]] | None = None,
    exclude_taxa: Mapping[str, set[str]] | None = None,
    sibling_penalty_weight: float | None = None,
    global_penalty_weight: float | None = None,
    workers: int = DEFAULT_AUTO_WORKERS,
    progress_callback: ProgressCallback | None = None,
) -> TargetDiscoveryResult:
    resolved_selection_profile = validate_selection_profile(selection_profile)
    profile_defaults = _target_profile_defaults(resolved_selection_profile)
    resolved_top_markers_per_target = (
        int(top_markers_per_target)
        if top_markers_per_target is not None
        else int(profile_defaults["top_markers_per_target"])
    )
    resolved_sibling_penalty_weight = (
        float(sibling_penalty_weight)
        if sibling_penalty_weight is not None
        else float(profile_defaults["sibling_penalty_weight"])
    )
    resolved_global_penalty_weight = (
        float(global_penalty_weight)
        if global_penalty_weight is not None
        else float(profile_defaults["global_penalty_weight"])
    )
    if resolved_top_markers_per_target < 1:
        raise ValueError("--top-markers-per-target must be at least 1.")

    resolved_taxonomy_file = str(Path(taxonomy_file).expanduser().resolve())
    resolved_markers_archive = str(Path(markers_archive).expanduser().resolve())
    resolved_tag_prefix = str(Path(tag_design_prefix).expanduser().resolve())
    resolved_fallback_policy = _resolve_fallback_policy(fallback_policy)
    resolved_include_taxa = {level: set(taxa) for level, taxa in (include_taxa or {}).items() if taxa}
    resolved_exclude_taxa = {level: set(taxa) for level, taxa in (exclude_taxa or {}).items() if taxa}
    validate_taxon_constraint_overlap(resolved_include_taxa, resolved_exclude_taxa)
    levels, primary_selections, fallbacks_by_barcode, _summary = _read_target_selections(tag_design_prefix)
    candidate_selections = list(primary_selections)
    for barcode in [selection.barcode for selection in primary_selections]:
        candidate_selections.extend(fallbacks_by_barcode.get(barcode, []))

    candidate_target_sets, filtered_taxonomy_accessions = _load_taxonomy_accessions_by_target(
        resolved_taxonomy_file,
        candidate_selections,
        levels,
        include_taxa=resolved_include_taxa,
        exclude_taxa=resolved_exclude_taxa,
        progress_callback=progress_callback,
    )
    missing_primary_taxa = [
        f"{target.selection.barcode}:{target.selection.resolved_level}:{target.selection.resolved_taxon}"
        for target in candidate_target_sets
        if target.selection.selection_source == "primary" and not target.taxonomy_accessions
    ]
    if missing_primary_taxa:
        raise ValueError(
            "Selected target taxa are absent after applying the target-analysis taxon scope. "
            "Adjust --include/--exclude or the upstream tag design. Missing targets: "
            + ", ".join(sorted(missing_primary_taxa))
        )

    _, union_profiles = _iter_marker_profiles(
        resolved_markers_archive,
        progress_callback=progress_callback,
        phase="marker_union",
    )
    all_marker_accessions: set[str] = set()
    for profile in union_profiles:
        all_marker_accessions.update(profile.accessions)
    _emit_progress(
        progress_callback,
        "marker_availability_completed",
        marker_available_genomes=len(all_marker_accessions),
    )

    for target in candidate_target_sets:
        target.available_accessions = target.taxonomy_accessions & all_marker_accessions
        target.sibling_available_accessions = target.sibling_taxonomy_accessions & all_marker_accessions
        target.global_available_accessions = (
            (all_marker_accessions & filtered_taxonomy_accessions) - target.taxonomy_accessions
        )

    target_sets, target_decisions, promoted_targets = _select_active_target_sets(
        candidate_target_sets,
        levels,
        resolved_fallback_policy,
    )

    analyzed_markers = len(union_profiles)
    scoring_profiles = union_profiles
    resolved_workers = resolve_worker_count(workers, total_tasks=len(scoring_profiles))

    marker_scores: list[dict[str, Any]] = []
    per_target_rows: dict[str, list[dict[str, Any]]] = {target.selection.barcode: [] for target in target_sets}
    _emit_progress(progress_callback, "marker_scoring_started", total_markers=len(scoring_profiles))
    completed = 0
    scoring_chunks = build_chunks(len(scoring_profiles), workers=resolved_workers)
    for chunk, rows in iter_chunk_results(
        scoring_chunks,
        worker=_score_marker_chunk,
        workers=resolved_workers,
        initializer=_init_target_scoring_worker,
        initargs=(
            target_sets,
            scoring_profiles,
            levels,
            resolved_sibling_penalty_weight,
            resolved_global_penalty_weight,
        ),
    ):
        for row in rows:
            per_target_rows[str(row["barcode"])].append(row)
        completed += chunk[1] - chunk[0]
        _emit_progress(
            progress_callback,
            "marker_scoring_advanced",
            completed=completed,
            total_markers=len(scoring_profiles),
        )
    _emit_progress(progress_callback, "marker_scoring_completed", total_markers=len(scoring_profiles))

    top_marker_manifest: list[dict[str, Any]] = []
    selected_targets_rows: list[dict[str, Any]] = []
    for target in target_sets:
        rows = per_target_rows[target.selection.barcode]
        rows.sort(
            key=lambda row: (
                -float(row["score"]),
                -float(row["target_occupancy"]),
                float(row["sibling_offtarget_rate"]),
                float(row["global_offtarget_rate"]),
                str(row["marker_id"]),
            )
        )
        for rank, row in enumerate(rows, start=1):
            row["rank_within_target"] = rank
            marker_scores.append(row)
        top_rows = rows[:resolved_top_markers_per_target]
        top_marker_manifest.extend(top_rows)

        candidate_nt_lengths = [
            float(row["mean_nt_length"])
            for row in rows
            if row.get("mean_nt_length") not in (None, "")
        ]
        retained_nt_lengths = [
            float(row["mean_nt_length"])
            for row in top_rows
            if row.get("mean_nt_length") not in (None, "")
        ]
        markers_with_target_hits = sum(1 for row in rows if int(row.get("target_hits") or 0) > 0)

        available_count = len(target.available_accessions)
        decision = target_decisions[target.selection.barcode]
        status = str(decision["status"])
        best_marker = top_rows[0] if top_rows else None
        target_row = {
            "barcode": target.selection.barcode,
            "resolved_level": target.selection.resolved_level,
            "resolved_taxon": target.selection.resolved_taxon,
            "primary_resolved_level": target.selection.primary_resolved_level,
            "primary_resolved_taxon": target.selection.primary_resolved_taxon,
            "parent_level": target.selection.parent_level,
            "parent_taxon": target.selection.parent_taxon,
            "status": status,
            "primary_status": decision["primary_status"],
            "selection_source": decision["selection_source"],
            "selection_priority": decision["selection_priority"],
            "available_fallback_candidates": decision["available_fallback_candidates"],
            "improving_fallback_candidates": decision["improving_fallback_candidates"],
            "promotion_reason": decision["promotion_reason"],
            "target_taxonomy_genomes": len(target.taxonomy_accessions),
            "target_marker_available_genomes": available_count,
            "target_marker_availability_fraction": _safe_rate(available_count, len(target.taxonomy_accessions)),
            "sibling_taxonomy_genomes": len(target.sibling_taxonomy_accessions),
            "sibling_marker_available_genomes": len(target.sibling_available_accessions),
            "candidate_markers": len(rows),
            "retained_markers": len(top_rows),
            "markers_with_target_hits": markers_with_target_hits,
            "total_mean_nt_length_candidate_markers": sum(candidate_nt_lengths) if candidate_nt_lengths else 0.0,
            "total_mean_nt_length_retained_markers": sum(retained_nt_lengths) if retained_nt_lengths else 0.0,
            "mean_nt_length_retained_markers": _mean(retained_nt_lengths),
            "shortest_retained_marker_nt_length": min(retained_nt_lengths) if retained_nt_lengths else None,
            "longest_retained_marker_nt_length": max(retained_nt_lengths) if retained_nt_lengths else None,
            "best_marker": None if best_marker is None else best_marker["marker_id"],
            "best_marker_score": None if best_marker is None else best_marker["score"],
            "best_marker_mean_nt_length": None if best_marker is None else best_marker.get("mean_nt_length"),
        }
        for level in levels:
            target_row[level] = target.selection.lineage.get(level)
        selected_targets_rows.append(target_row)

    selected_targets_rows.sort(
        key=lambda row: (
            str(row["resolved_level"]),
            str(row["resolved_taxon"]),
            str(row["barcode"]),
        )
    )
    top_marker_manifest.sort(key=lambda row: (str(row["barcode"]), int(row["rank_within_target"])))
    marker_scores.sort(key=lambda row: (str(row["barcode"]), int(row["rank_within_target"])))

    return TargetDiscoveryResult(
        dataset=dataset,
        taxonomy_file=resolved_taxonomy_file,
        markers_archive=resolved_markers_archive,
        tag_design_prefix=resolved_tag_prefix,
        selected_targets=selected_targets_rows,
        marker_scores=marker_scores,
        top_marker_manifest=top_marker_manifest,
        analyzed_markers=analyzed_markers,
        all_marker_available_genomes=len(all_marker_accessions & filtered_taxonomy_accessions),
        selection_profile=resolved_selection_profile,
        top_markers_per_target=resolved_top_markers_per_target,
        fallback_policy=sorted(resolved_fallback_policy),
        promoted_targets=promoted_targets,
        include_taxa=taxon_constraint_payload(resolved_include_taxa, resolved_exclude_taxa)["include_taxa"],
        exclude_taxa=taxon_constraint_payload(resolved_include_taxa, resolved_exclude_taxa)["exclude_taxa"],
        sibling_penalty_weight=resolved_sibling_penalty_weight,
        global_penalty_weight=resolved_global_penalty_weight,
    )


def _write_csv(path: Path, rows: Sequence[Mapping[str, Any]]) -> None:
    rows = list(rows)
    fieldnames: list[str] = []
    for row in rows:
        for key in row.keys():
            if key not in fieldnames:
                fieldnames.append(key)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        if fieldnames:
            writer.writeheader()
            for row in rows:
                writer.writerow({key: row.get(key) for key in fieldnames})


def write_target_discovery_outputs(
    result: TargetDiscoveryResult,
    output_prefix: str | Path,
) -> dict[str, Path]:
    output_prefix = Path(output_prefix).expanduser().resolve()
    output_prefix.parent.mkdir(parents=True, exist_ok=True)
    paths = {
        "summary": output_prefix.with_name(f"{output_prefix.name}_summary.json"),
        "selected_targets": output_prefix.with_name(f"{output_prefix.name}_selected_targets.csv"),
        "marker_scores": output_prefix.with_name(f"{output_prefix.name}_marker_scores.csv"),
        "top_markers": output_prefix.with_name(f"{output_prefix.name}_top_marker_manifest.csv"),
    }

    _write_csv(paths["selected_targets"], result.selected_targets)
    _write_csv(paths["marker_scores"], result.marker_scores)
    _write_csv(paths["top_markers"], result.top_marker_manifest)
    result.output_files = {name: str(path.resolve()) for name, path in paths.items()}
    with paths["summary"].open("w", encoding="utf-8") as handle:
        json.dump(result.to_summary_dict(), handle, indent=2, sort_keys=True)
        handle.write("\n")
    return paths
