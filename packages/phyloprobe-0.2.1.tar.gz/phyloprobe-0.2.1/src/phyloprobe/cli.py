"""Command-line interface for phyloprobe."""

from __future__ import annotations

import argparse
from collections.abc import Sequence
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
import io
import json
from pathlib import Path
import re
import sys
from typing import Any, Mapping

from phyloprobe import __version__
from phyloprobe.catalog import default_catalog_path
from phyloprobe.gtdb import GTDB_RANKS, summarize_taxonomy_file
from phyloprobe.indexing import (
    DEFAULT_FULGOR_THREADS,
    DEFAULT_GGCAT_THREADS,
    DEFAULT_INDEX_PENALTY_WEIGHT,
    DEFAULT_KMER_LENGTH,
    DEFAULT_MINIMIZER_LENGTH,
    build_fulgor_index,
    load_index_summary,
)
from phyloprobe.matching import (
    DEFAULT_MAX_MISMATCHES,
    DEFAULT_MISMATCH_PENALTY_PER_MISMATCH,
)
from phyloprobe.parallel import DEFAULT_AUTO_WORKERS
from phyloprobe.paths import resolve_datasets_root
from phyloprobe.registry import install_catalog_selection, load_registry, resolve_dataset_record
from phyloprobe.taxon_scope import format_taxon_constraint_summary
from phyloprobe.tags import (
    DEFAULT_ALPHABET as DEFAULT_TAG_ALPHABET,
    DEFAULT_LEVELS as DEFAULT_TAG_LEVELS,
    design_tags,
    parse_alphabet as parse_tag_alphabet,
    parse_descendant_rules as parse_tag_descendant_rules,
    parse_level_weights as parse_tag_level_weights,
    parse_levels as parse_tag_levels,
    parse_maximise_levels as parse_tag_maximise_levels,
    parse_min_taxa_per_level as parse_tag_min_taxa_per_level,
    parse_taxon_constraints as parse_tag_taxon_constraints,
    write_tag_design_outputs,
)
from phyloprobe.targets import (
    DEFAULT_SELECTION_PROFILE,
    DEFAULT_FALLBACK_POLICY,
    DEFAULT_TOP_MARKERS_PER_TARGET,
    discover_targets,
    write_target_discovery_outputs,
)
from phyloprobe.regions import (
    DEFAULT_DISCOVERY_PROFILE,
    DEFAULT_AA_MISMATCH_PENALTY_PER_MISMATCH,
    DEFAULT_GLOBAL_PENALTY_WEIGHT as DEFAULT_REGION_GLOBAL_PENALTY_WEIGHT,
    DEFAULT_MAX_AA_MISMATCHES,
    DEFAULT_MIN_BEST_PROBE_SUPPORT_FRACTION,
    DEFAULT_MIN_TARGET_COLUMN_OCCUPANCY,
    DEFAULT_MIN_TARGET_CONSENSUS,
    DEFAULT_MIN_TARGET_REMAP_FRACTION,
    DEFAULT_MIN_TARGET_WINDOW_PRESENCE,
    DEFAULT_PROBEABILITY_WEIGHT,
    DEFAULT_REGION_PROBE_LENGTH,
    DEFAULT_SIBLING_PENALTY_WEIGHT as DEFAULT_REGION_SIBLING_PENALTY_WEIGHT,
    DEFAULT_TOP_REGIONS_PER_MARKER,
    DEFAULT_WINDOW_AA_LENGTH,
    DEFAULT_WINDOW_AA_LENGTH_MAX,
    DEFAULT_WINDOW_AA_LENGTH_MIN,
    discover_regions,
    write_region_discovery_outputs,
)
from phyloprobe.thermo import (
    DEFAULT_DNTP_MM,
    DEFAULT_DIVALENT_SALT_MM,
    DEFAULT_HYB_TEMP_C,
    DEFAULT_MONOVALENT_SALT_MM,
    DEFAULT_PANEL_COMPLEMENTARITY_PENALTY_WEIGHT,
    DEFAULT_PANEL_HETERODIMER_PENALTY_WEIGHT,
    DEFAULT_PROBE_CONC_NM,
    DEFAULT_REGION_SCORE_WEIGHT,
    DEFAULT_SCORING_PROFILE,
    DEFAULT_THERMO_BACKEND,
    DEFAULT_THERMO_PENALTY_WEIGHT,
)
from phyloprobe.probes import (
    DEFAULT_GLOBAL_PENALTY_WEIGHT as DEFAULT_PROBE_GLOBAL_PENALTY_WEIGHT,
    DEFAULT_MAX_GC,
    DEFAULT_MAX_HOMOPOLYMER,
    DEFAULT_MAX_TM,
    DEFAULT_MIN_GC,
    DEFAULT_MIN_TM,
    DEFAULT_PROBE_LENGTH,
    DEFAULT_SIBLING_PENALTY_WEIGHT as DEFAULT_PROBE_SIBLING_PENALTY_WEIGHT,
    DEFAULT_TOP_PROBES_PER_REGION,
    design_probes,
    write_probe_design_outputs,
)
from phyloprobe.panels import (
    DEFAULT_GLOBAL_PENALTY_WEIGHT as DEFAULT_PANEL_GLOBAL_PENALTY_WEIGHT,
    DEFAULT_MAX_PROBES_PER_MARKER,
    DEFAULT_MAX_PROBES_PER_PANEL,
    DEFAULT_MAX_PROBES_PER_REGION,
    DEFAULT_PANEL_BASE_SCORE_WEIGHT,
    DEFAULT_SIBLING_PENALTY_WEIGHT as DEFAULT_PANEL_SIBLING_PENALTY_WEIGHT,
    design_panels,
    write_panel_design_outputs,
)

try:
    import click
    import typer
    from typer.core import HAS_RICH, TyperGroup
except ImportError:  # pragma: no cover - exercised only when dependencies are absent
    click = None
    typer = None
    HAS_RICH = False
    TyperGroup = object

try:
    from rich import box
    from rich.console import Console, Group, RenderableType
    from rich.panel import Panel
    from rich.rule import Rule
    from rich.table import Table
    from rich.text import Text

    RICH_AVAILABLE = True
except ImportError:  # pragma: no cover - exercised only when dependencies are absent
    RICH_AVAILABLE = False
    RenderableType = Any

    class Text:
        def __init__(self, value: str = "", style: str | None = None):
            self._parts: list[str] = []
            if value:
                self._parts.append(str(value))

        def append(self, value: str, style: str | None = None) -> None:
            self._parts.append(str(value))

        def __str__(self) -> str:
            return "".join(self._parts)

        def __repr__(self) -> str:
            return str(self)

    class Panel:
        def __init__(self, renderable=None, title: str | None = None, border_style: str | None = None):
            self.renderable = renderable
            self.title = title
            self.border_style = border_style

        @classmethod
        def fit(cls, renderable=None, border_style: str | None = None):
            return cls(renderable=renderable, border_style=border_style)

    class Table:
        def __init__(self, *args, **kwargs):
            self.rows: list[Any] = []

        @classmethod
        def grid(cls, *args, **kwargs):
            return cls()

        def add_column(self, *args, **kwargs) -> None:
            return None

        def add_row(self, *args, **kwargs) -> None:
            self.rows.append(args)

    class _DummyBox:
        SIMPLE_HEAVY = None

    box = _DummyBox()

    def Rule(*args, **kwargs):
        return None

    def Group(*items):
        return None

ROOT_TITLE = "PhyloProbe"
ROOT_DESCRIPTION = (
    "Phylogeny-wide molecular tag and probe designer for sequencing- and imaging-based bacterial and archaeal analysis."
)
SESSION_NAME_PATTERN = re.compile(r"^[A-Za-z0-9_]+$")
ATTEMPT_PATTERN = re.compile(r"^[0-9]+$")
STAGE_NAMES = {"tags", "targets", "regions", "probes", "panels"}
PLACEHOLDER_STAGES = {
}
VALID_TAXON_SELECTORS = {"all", "archaea", "bacteria"}
WORKERS_OPTION_HELP = (
    "Worker processes for CPU-heavy scoring. Use 0 for automatic selection, or 1 to disable parallelism."
)
DEFAULT_TERMINAL_PREVIEW_ROWS = 20


class OutputFormat(str, Enum):
    text = "text"
    json = "json"


def _output_format_value(report_format: OutputFormat | str) -> str:
    if isinstance(report_format, OutputFormat):
        return report_format.value
    return str(report_format)


def _is_json_output(report_format: OutputFormat | str) -> bool:
    return _output_format_value(report_format) == OutputFormat.json.value


class _TagDesignProgressReporter:
    def __init__(self, enabled: bool) -> None:
        self.enabled = enabled and RICH_AVAILABLE
        self.console = _make_console(stderr=True) if self.enabled else None
        self.progress = None
        self.task_id = None
        if self.enabled and self.console is not None:
            from rich.progress import BarColumn, MofNCompleteColumn, Progress, TextColumn, TimeElapsedColumn

            self.progress = Progress(
                TextColumn("[bold cyan]{task.description}"),
                BarColumn(bar_width=36),
                MofNCompleteColumn(),
                TimeElapsedColumn(),
                console=self.console,
                expand=True,
                transient=False,
                disable=not self.console.is_terminal,
            )

    def __enter__(self):
        if self.progress is not None:
            self.progress.start()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        if self.progress is not None:
            self.progress.stop()

    def callback(self, event: str, payload: Mapping[str, Any]) -> None:
        if not self.enabled or self.console is None:
            return

        if event == "preprocessing_started":
            self.console.log("[cyan]Preparing GTDB taxonomy for tag design[/cyan]")
            return
        if event == "preprocessing_completed":
            self.console.log(
                "[green]Prepared "
                f"{payload['aggregated_taxonomy_paths']} unique taxonomy paths "
                f"from {payload['rows_retained']} genomes[/green]"
            )
            return
        if event == "search_started":
            total = int(payload["total_candidates"])
            self.console.log(f"[cyan]Evaluating {total} allocation candidates[/cyan]")
            if self.progress is not None:
                self.task_id = self.progress.add_task("Searching allocations", total=total)
            return
        if event == "search_advanced" and self.progress is not None and self.task_id is not None:
            self.progress.update(self.task_id, completed=int(payload["completed"]))
            return
        if event == "search_completed":
            allocation = ",".join(str(value) for value in payload["best_allocation"])
            self.console.log(
                "[green]Selected candidate "
                f"#{payload['best_candidate']} with allocation [{allocation}][/green]"
            )
            return
        if event == "finalizing_design":
            self.console.log("[cyan]Writing tag-design artifacts[/cyan]")


class _TargetDiscoveryProgressReporter:
    def __init__(self, enabled: bool) -> None:
        self.enabled = enabled and RICH_AVAILABLE
        self.console = _make_console(stderr=True) if self.enabled else None
        self.progress = None
        self.task_id = None
        self.task_phase = None
        if self.enabled and self.console is not None:
            from rich.progress import BarColumn, MofNCompleteColumn, Progress, TextColumn, TimeElapsedColumn

            self.progress = Progress(
                TextColumn("[bold cyan]{task.description}"),
                BarColumn(bar_width=36),
                MofNCompleteColumn(),
                TimeElapsedColumn(),
                console=self.console,
                expand=True,
                transient=False,
                disable=not self.console.is_terminal,
            )

    def __enter__(self):
        if self.progress is not None:
            self.progress.start()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        if self.progress is not None:
            self.progress.stop()

    def _start_task(self, description: str, total: int) -> None:
        if self.progress is None:
            return
        if self.task_id is not None:
            self.progress.remove_task(self.task_id)
        self.task_id = self.progress.add_task(description, total=total)

    def callback(self, event: str, payload: Mapping[str, Any]) -> None:
        if not self.enabled or self.console is None:
            return
        if event == "taxonomy_loading_started":
            self.console.log("[cyan]Resolving selected taxa against GTDB taxonomy[/cyan]")
            return
        if event == "taxonomy_loading_completed":
            self.console.log(
                "[green]Resolved "
                f"{payload['targets']} selected taxa across {payload['genomes']} taxonomy genomes[/green]"
            )
            return
        if event == "marker_union_started":
            self.task_phase = "union"
            self.console.log("[cyan]Scanning marker archive for available genomes[/cyan]")
            self._start_task("Marker availability", int(payload["total_markers"]))
            return
        if event == "marker_union_advanced" and self.progress is not None and self.task_id is not None and self.task_phase == "union":
            self.progress.update(self.task_id, completed=int(payload["completed"]))
            return
        if event == "marker_availability_completed":
            self.console.log(
                "[green]Detected "
                f"{payload['marker_available_genomes']} genomes with marker support in the archive[/green]"
            )
            return
        if event == "marker_scoring_started":
            self.task_phase = "scoring"
            self.console.log("[cyan]Ranking markers for each selected target[/cyan]")
            self._start_task("Marker scoring", int(payload["total_markers"]))
            return
        if event == "marker_scoring_advanced" and self.progress is not None and self.task_id is not None and self.task_phase == "scoring":
            self.progress.update(self.task_id, completed=int(payload["completed"]))
            return
        if event == "marker_scoring_completed":
            self.console.log("[green]Marker scoring completed[/green]")


class _RegionDiscoveryProgressReporter:
    def __init__(self, enabled: bool) -> None:
        self.enabled = enabled and RICH_AVAILABLE
        self.console = _make_console(stderr=True) if self.enabled else None
        self.progress = None
        self.task_id = None
        self.task_phase = None
        if self.enabled and self.console is not None:
            from rich.progress import BarColumn, MofNCompleteColumn, Progress, TextColumn, TimeElapsedColumn

            self.progress = Progress(
                TextColumn("[bold cyan]{task.description}"),
                BarColumn(bar_width=36),
                MofNCompleteColumn(),
                TimeElapsedColumn(),
                console=self.console,
                expand=True,
                transient=False,
                disable=not self.console.is_terminal,
            )

    def __enter__(self):
        if self.progress is not None:
            self.progress.start()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        if self.progress is not None:
            self.progress.stop()

    def _start_task(self, description: str, total: int) -> None:
        if self.progress is None:
            return
        if self.task_id is not None:
            self.progress.remove_task(self.task_id)
        self.task_id = self.progress.add_task(description, total=total)

    def callback(self, event: str, payload: Mapping[str, Any]) -> None:
        if not self.enabled or self.console is None:
            return
        if event == "taxonomy_resolution_started":
            self.console.log("[cyan]Resolving target taxa for region discovery[/cyan]")
            return
        if event == "taxonomy_resolution_completed":
            self.console.log("[green]Target taxonomy resolution completed[/green]")
            return
        if event == "msa_loading_started":
            self.task_phase = "msa"
            self.console.log("[cyan]Loading selected aligned marker MSAs[/cyan]")
            self._start_task("MSA loading", int(payload["total_markers"]))
            return
        if event == "msa_loading_advanced" and self.progress is not None and self.task_id is not None and self.task_phase == "msa":
            self.progress.update(self.task_id, completed=int(payload["completed"]))
            return
        if event == "msa_loading_completed":
            self.console.log("[green]Selected MSA markers loaded[/green]")
            return
        if event == "marker_loading_started":
            self.task_phase = "markers"
            self.console.log("[cyan]Loading nucleotide marker genes for probeability scoring[/cyan]")
            self._start_task("Marker loading", int(payload["total_markers"]))
            return
        if event == "marker_loading_advanced" and self.progress is not None and self.task_id is not None and self.task_phase == "markers":
            self.progress.update(self.task_id, completed=int(payload["completed"]))
            return
        if event == "marker_loading_completed":
            self.console.log("[green]Nucleotide marker genes loaded[/green]")
            return
        if event == "window_scoring_started":
            self.task_phase = "windows"
            self.console.log("[cyan]Scanning aligned windows for conserved regions[/cyan]")
            self._start_task("Window scoring", int(payload["total_requests"]))
            return
        if event == "window_scoring_advanced" and self.progress is not None and self.task_id is not None and self.task_phase == "windows":
            self.progress.update(self.task_id, completed=int(payload["completed"]))
            return
        if event == "window_scoring_completed":
            self.console.log("[green]Region discovery completed[/green]")


class _ProbeDesignProgressReporter:
    def __init__(self, enabled: bool) -> None:
        self.enabled = enabled and RICH_AVAILABLE
        self.console = _make_console(stderr=True) if self.enabled else None
        self.progress = None
        self.task_id = None
        self.task_phase = None
        if self.enabled and self.console is not None:
            from rich.progress import BarColumn, MofNCompleteColumn, Progress, TextColumn, TimeElapsedColumn

            self.progress = Progress(
                TextColumn("[bold cyan]{task.description}"),
                BarColumn(bar_width=36),
                MofNCompleteColumn(),
                TimeElapsedColumn(),
                console=self.console,
                expand=True,
                transient=False,
                disable=not self.console.is_terminal,
            )

    def __enter__(self):
        if self.progress is not None:
            self.progress.start()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        if self.progress is not None:
            self.progress.stop()

    def _start_task(self, description: str, total: int) -> None:
        if self.progress is None:
            return
        if self.task_id is not None:
            self.progress.remove_task(self.task_id)
        self.task_id = self.progress.add_task(description, total=total)

    def callback(self, event: str, payload: Mapping[str, Any]) -> None:
        if not self.enabled or self.console is None:
            return
        if event == "taxonomy_resolution_started":
            self.console.log("[cyan]Resolving target taxa for probe design[/cyan]")
            return
        if event == "taxonomy_resolution_completed":
            self.console.log("[green]Probe-design taxonomy resolution completed[/green]")
            return
        if event == "msa_loading_started":
            self.task_phase = "msa"
            self.console.log("[cyan]Loading aligned marker MSAs for probe remapping[/cyan]")
            self._start_task("MSA loading", int(payload["total_markers"]))
            return
        if event == "msa_loading_advanced" and self.progress is not None and self.task_id is not None and self.task_phase == "msa":
            self.progress.update(self.task_id, completed=int(payload["completed"]))
            return
        if event == "msa_loading_completed":
            self.console.log("[green]Aligned marker MSAs loaded[/green]")
            return
        if event == "marker_loading_started":
            self.task_phase = "markers"
            self.console.log("[cyan]Loading nucleotide marker genes[/cyan]")
            self._start_task("Marker loading", int(payload["total_markers"]))
            return
        if event == "marker_loading_advanced" and self.progress is not None and self.task_id is not None and self.task_phase == "markers":
            self.progress.update(self.task_id, completed=int(payload["completed"]))
            return
        if event == "marker_loading_completed":
            self.console.log("[green]Nucleotide marker genes loaded[/green]")
            return
        if event == "probe_scoring_started":
            self.task_phase = "probes"
            self.console.log("[cyan]Enumerating and scoring probe candidates[/cyan]")
            self._start_task("Probe scoring", int(payload["total_regions"]))
            return
        if event == "probe_scoring_advanced" and self.progress is not None and self.task_id is not None and self.task_phase == "probes":
            self.progress.update(self.task_id, completed=int(payload["completed"]))
            return
        if event == "probe_scoring_completed":
            self.console.log("[green]Probe design completed[/green]")


class _IndexBuildProgressReporter:
    def __init__(self, enabled: bool) -> None:
        self.enabled = enabled and RICH_AVAILABLE
        self.console = _make_console(stderr=True) if self.enabled else None
        self.progress = None
        self.task_id = None
        self.task_phase = None
        if self.enabled and self.console is not None:
            from rich.progress import BarColumn, MofNCompleteColumn, Progress, TextColumn, TimeElapsedColumn

            self.progress = Progress(
                TextColumn("[bold cyan]{task.description}"),
                BarColumn(bar_width=36),
                MofNCompleteColumn(),
                TimeElapsedColumn(),
                console=self.console,
                expand=True,
                transient=False,
                disable=not self.console.is_terminal,
            )

    def __enter__(self):
        if self.progress is not None:
            self.progress.start()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        if self.progress is not None:
            self.progress.stop()

    def _start_task(self, description: str, total: int) -> None:
        if self.progress is None:
            return
        if self.task_id is not None:
            self.progress.remove_task(self.task_id)
        self.task_id = self.progress.add_task(description, total=total)

    def callback(self, event: str, payload: Mapping[str, Any]) -> None:
        if not self.enabled or self.console is None:
            return
        if event == "reference_extraction_started":
            self.task_phase = "extract"
            input_mode = str(payload.get("input_mode") or "archive")
            if input_mode == "files":
                self.console.log("[cyan]Preparing specific genome FASTA files for Fulgor indexing[/cyan]")
                task_label = "Genome preparation"
            else:
                self.console.log("[cyan]Extracting representative genomes for Fulgor indexing[/cyan]")
                task_label = "Genome extraction"
            self._start_task(task_label, int(payload["total_references"]))
            return
        if event == "reference_extraction_advanced" and self.progress is not None and self.task_id is not None and self.task_phase == "extract":
            self.progress.update(self.task_id, completed=int(payload["completed"]))
            return
        if event == "reference_extraction_completed":
            input_mode = str(payload.get("input_mode") or "archive")
            if input_mode == "files":
                self.console.log("[green]Genome preparation completed[/green]")
            else:
                self.console.log("[green]Genome extraction completed[/green]")
            return
        if event == "index_build_started":
            self.task_phase = "build"
            self.console.log("[cyan]Running Fulgor build[/cyan]")
            return
        if event == "index_build_completed":
            self.console.log("[green]Fulgor index build completed[/green]")
            return
        if event == "reference_map_started":
            self.console.log("[cyan]Exporting Fulgor reference order and writing the reference map[/cyan]")
            return
        if event == "reference_map_completed":
            self.console.log("[green]Reference map written[/green]")
            return


class _PanelDesignProgressReporter:
    def __init__(self, enabled: bool) -> None:
        self.enabled = enabled and RICH_AVAILABLE
        self.console = _make_console(stderr=True) if self.enabled else None
        self.progress = None
        self.task_id = None
        self.task_phase = None
        if self.enabled and self.console is not None:
            from rich.progress import BarColumn, MofNCompleteColumn, Progress, TextColumn, TimeElapsedColumn

            self.progress = Progress(
                TextColumn("[bold cyan]{task.description}"),
                BarColumn(bar_width=36),
                MofNCompleteColumn(),
                TimeElapsedColumn(),
                console=self.console,
                expand=True,
                transient=False,
                disable=not self.console.is_terminal,
            )

    def __enter__(self):
        if self.progress is not None:
            self.progress.start()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        if self.progress is not None:
            self.progress.stop()

    def _start_task(self, description: str, total: int) -> None:
        if self.progress is None:
            return
        if self.task_id is not None:
            self.progress.remove_task(self.task_id)
        self.task_id = self.progress.add_task(description, total=total)

    def callback(self, event: str, payload: Mapping[str, Any]) -> None:
        if not self.enabled or self.console is None:
            return
        if event == "taxonomy_resolution_started":
            self.console.log("[cyan]Resolving target taxa for panel design[/cyan]")
            return
        if event == "taxonomy_resolution_completed":
            self.console.log("[green]Panel-design taxonomy resolution completed[/green]")
            return
        if event == "marker_loading_started":
            self.task_phase = "markers"
            self.console.log("[cyan]Loading nucleotide marker genes for panel scoring[/cyan]")
            self._start_task("Marker loading", int(payload["total_markers"]))
            return
        if event == "marker_loading_advanced" and self.progress is not None and self.task_id is not None and self.task_phase == "markers":
            self.progress.update(self.task_id, completed=int(payload["completed"]))
            return
        if event == "marker_loading_completed":
            self.console.log("[green]Panel marker context loaded[/green]")
            return
        if event == "candidate_scoring_started":
            self.task_phase = "candidates"
            self.console.log("[cyan]Scoring panel probe candidates[/cyan]")
            self._start_task("Candidate scoring", int(payload["total_candidates"]))
            return
        if event == "index_query_started":
            self.task_phase = "index"
            label = str(payload.get("label") or "").strip()
            if label:
                self.console.log(f"[cyan]Querying genome index '{label}' for probe off-targets[/cyan]")
            else:
                self.console.log("[cyan]Querying the genome-wide Fulgor index for probe off-targets[/cyan]")
            self._start_task("Genome index query", int(payload["queries"]))
            self.progress.update(self.task_id, completed=0)
            return
        if event == "index_query_completed":
            if self.progress is not None and self.task_id is not None and self.task_phase == "index":
                self.progress.update(self.task_id, completed=int(payload["queries"]))
            label = str(payload.get("label") or "").strip()
            if label:
                self.console.log(f"[green]Genome index query completed for '{label}'[/green]")
            else:
                self.console.log("[green]Genome index query completed[/green]")
            return
        if event == "candidate_scoring_advanced" and self.progress is not None and self.task_id is not None and self.task_phase == "candidates":
            self.progress.update(self.task_id, completed=int(payload["completed"]))
            return
        if event == "candidate_scoring_completed":
            self.console.log("[green]Panel candidate scoring completed[/green]")
            return
        if event == "panel_selection_started":
            self.task_phase = "panels"
            self.console.log("[cyan]Selecting final probe panels[/cyan]")
            self._start_task("Panel selection", int(payload["total_targets"]))
            return
        if event == "panel_selection_advanced" and self.progress is not None and self.task_id is not None and self.task_phase == "panels":
            self.progress.update(self.task_id, completed=int(payload["completed"]))
            return
        if event == "panel_selection_completed":
            self.console.log("[green]Panel design completed[/green]")


def _json_dump(payload: object) -> None:
    print(json.dumps(payload, indent=2, sort_keys=True))


def _validate_taxon_selector(taxon: str) -> str:
    normalized = taxon.strip().lower()
    if normalized not in VALID_TAXON_SELECTORS:
        allowed = ", ".join(sorted(VALID_TAXON_SELECTORS))
        raise ValueError(f"Invalid taxon selector '{taxon}'. Allowed values: {allowed}")
    return normalized


def _dataset_install_rows(results: dict[str, object]) -> list[dict[str, Any]]:
    rows = []
    for key, result in sorted(results.items()):
        record = result.record
        summary = _dataset_summary_label(record)
        rows.append(
            {
                "key": key,
                "logical_key": getattr(record, "logical_key", key),
                "name": result.name,
                "type": record.dataset_type,
                "taxon": result.taxon,
                "release": record.release,
                "status": result.status,
                "summary": summary,
            }
        )
    return rows


def _dataset_registry_rows(records: dict[str, object]) -> list[dict[str, Any]]:
    rows = []
    for key, record in sorted(records.items()):
        rows.append(
            {
                "key": key,
                "logical_key": getattr(record, "logical_key", key),
                "name": record.name,
                "type": record.dataset_type,
                "taxon": record.taxon,
                "release": record.release,
                "files": len(record.files),
                "summary": _dataset_summary_label(record),
            }
        )
    return rows


def _dataset_summary_label(record) -> str:
    if getattr(record, "dataset_type", "") == "fulgor_index":
        index_summary = getattr(record, "index_summary", {}) or {}
        indexed = index_summary.get("indexed_references")
        kmer_length = index_summary.get("kmer_length")
        parts = []
        if indexed not in (None, ""):
            parts.append(f"indexed_genomes={indexed}")
        if kmer_length not in (None, ""):
            parts.append(f"k={kmer_length}")
        return ", ".join(parts) if parts else "fulgor index"

    taxonomy_summary = getattr(record, "taxonomy_summary", {}) or {}
    genomes = taxonomy_summary.get("genomes")
    unique_lineages = taxonomy_summary.get("unique_lineages")
    parts = []
    if genomes not in (None, ""):
        parts.append(f"genomes={genomes}")
    if unique_lineages not in (None, ""):
        parts.append(f"lineages={unique_lineages}")
    return ", ".join(parts) if parts else "GTDB dataset"


def _make_console(
    no_color: bool = False,
    record: bool = False,
    width: int = 120,
    stderr: bool = False,
):
    if not RICH_AVAILABLE:
        return None
    return Console(
        stderr=stderr,
        no_color=no_color,
        force_terminal=False if record else None,
        record=record,
        width=width if record else None,
    )


def _renderable_to_text(renderable: RenderableType) -> str:
    if not RICH_AVAILABLE:
        return ""
    buffer = io.StringIO()
    console = Console(
        file=buffer,
        no_color=True,
        force_terminal=False,
        record=True,
        width=120,
    )
    console.print(renderable)
    return console.export_text(styles=False).rstrip()


def _style_for_status(value: Any) -> str | None:
    normalized = str(value).lower()
    if normalized in {"error", "fail"}:
        return "bold red"
    if normalized in {"warning", "warn"}:
        return "bold yellow"
    if normalized in {"pass", "installed"}:
        return "bold green"
    if normalized == "skipped":
        return "bold yellow"
    return None


def _rich_value(value: Any, column: str | None = None) -> str | Text:
    if value is None:
        return Text("NA", style="dim")
    if column in {"status"}:
        style = _style_for_status(value)
        if style is not None:
            return Text(str(value), style=style)
    if isinstance(value, bool):
        return Text(str(value), style="green" if value else "red")
    return str(value)


def _rich_mapping_panel(
    title: str,
    values: dict[str, Any],
    border_style: str = "cyan",
) -> RenderableType:
    if not values:
        return Panel(Text("(no values)", style="dim"), title=title, border_style="dim")

    grid = Table.grid(expand=True, padding=(0, 1))
    grid.add_column(style="bold white", ratio=1)
    grid.add_column(style="white", ratio=2)
    for key, value in values.items():
        grid.add_row(str(key), _rich_value(value, str(key)))
    return Panel(grid, title=title, border_style=border_style)


def _preview_rows(
    rows: Sequence[dict[str, Any]],
    *,
    max_rows: int = DEFAULT_TERMINAL_PREVIEW_ROWS,
) -> tuple[list[dict[str, Any]], int]:
    materialized = list(rows)
    if max_rows <= 0 or len(materialized) <= max_rows:
        return materialized, 0
    return materialized[:max_rows], len(materialized) - max_rows


def _preview_note(total_rows: int, shown_rows: int, omitted_rows: int) -> str:
    return f"Showing first {shown_rows} of {total_rows} rows; {omitted_rows} more not shown."


def _rich_frame(
    title: str,
    rows: list[dict[str, Any]],
    border_style: str = "cyan",
    *,
    max_rows: int = DEFAULT_TERMINAL_PREVIEW_ROWS,
) -> RenderableType:
    if not rows:
        return Panel(Text("(no rows)", style="dim"), title=title, border_style="dim")

    preview_rows, omitted_rows = _preview_rows(rows, max_rows=max_rows)
    columns = list(preview_rows[0].keys())
    table = Table(
        title=title,
        title_style=f"bold {border_style}",
        header_style=f"bold {border_style}",
        box=box.SIMPLE_HEAVY,
        expand=False,
        show_lines=False,
    )
    for column in columns:
        justify = "right" if all(isinstance(row.get(column), (int, float)) for row in preview_rows) else "left"
        table.add_column(str(column), justify=justify, overflow="fold")
    for row in preview_rows:
        table.add_row(*[_rich_value(row.get(column), column) for column in columns])
    if omitted_rows > 0:
        return Group(
            table,
            Text(_preview_note(len(rows), len(preview_rows), omitted_rows), style="dim"),
        )
    return table


def _rich_text_panel(
    title: str,
    text: str,
    *,
    border_style: str = "cyan",
    max_lines: int | None = None,
) -> RenderableType:
    lines = text.splitlines() or ["(no content)"]
    if max_lines is not None and max_lines > 0 and len(lines) > max_lines:
        display_lines = [*lines[:max_lines], f"... ({len(lines) - max_lines} more lines)"]
    else:
        display_lines = lines
    return Panel(Text("\n".join(display_lines)), title=title, border_style=border_style)


def _append_preview_block(
    lines: list[str],
    *,
    heading: str,
    rows: Sequence[dict[str, Any]],
    formatter,
    max_rows: int = DEFAULT_TERMINAL_PREVIEW_ROWS,
) -> None:
    lines.append(f"{heading}:")
    preview_rows, omitted_rows = _preview_rows(rows, max_rows=max_rows)
    for row in preview_rows:
        lines.append(f"  {formatter(row)}")
    if omitted_rows > 0:
        lines.append(f"  ... ({omitted_rows} more rows not shown)")


def _rich_taxonomy_tree_panel(
    title: str,
    entries: Sequence[dict[str, Any]],
    focused_levels: set[str],
    *,
    border_style: str = "green",
    max_lines: int | None = None,
) -> RenderableType:
    if not entries:
        return Panel(Text("(no taxa selected)", style="dim"), title=title, border_style="dim")

    if max_lines is not None and max_lines > 0 and len(entries) > max_lines:
        display_entries = list(entries[:max_lines])
        remaining = len(entries) - max_lines
    else:
        display_entries = list(entries)
        remaining = 0

    tag_width = max((len(str(entry["barcode"])) for entry in entries if entry.get("barcode")), default=0)
    text = Text()
    for index, entry in enumerate(display_entries):
        if index > 0:
            text.append("\n")
        level_style = "bold white" if str(entry["level"]) in focused_levels else "bright_black"
        if tag_width > 0:
            if entry.get("barcode"):
                barcode = str(entry["barcode"])
                stage_code = str(entry.get("stage_code") or "")
                prefix = barcode[: max(len(barcode) - len(stage_code), 0)]
                suffix = barcode[len(prefix):]
                text.append(prefix, style="cyan")
                text.append(suffix, style="bold bright_cyan")
                text.append(" " * max(tag_width - len(barcode), 0))
            else:
                text.append(" " * tag_width, style="dim")
            text.append("  ")
        text.append(f"{'  ' * int(entry['depth'])}- {entry['taxon']}", style=level_style)
    if remaining > 0:
        text.append("\n")
        text.append(f"... ({remaining} more lines)", style="dim")
    return Panel(text, title=title, border_style=border_style)


def _print_root_header(console, *, include_description: bool = True) -> None:
    if RICH_AVAILABLE and console is not None:
        console.print(Panel.fit(f"[bold]{ROOT_TITLE}[/bold]", border_style="cyan"))
        if include_description:
            console.print(ROOT_DESCRIPTION)
        return

    print(ROOT_TITLE)
    if include_description:
        print(ROOT_DESCRIPTION)


def _render_root_header_text(*, include_description: bool = True) -> str:
    console = _make_console(record=True, no_color=True, width=80)
    if console is None:
        return f"{ROOT_TITLE}\n{ROOT_DESCRIPTION}" if include_description else ROOT_TITLE
    _print_root_header(console, include_description=include_description)
    return console.export_text().rstrip()


def _print_root_overview() -> None:
    console = _make_console()
    if console is None:
        print(ROOT_TITLE)
        print(ROOT_DESCRIPTION)
        print()
        print("Workflow Snapshot")
        print("  datasets : download and register catalog datasets")
        print("  datasets-list : list installed datasets")
        print("  datasets-show : inspect one installed dataset")
        print("  taxonomy : inspect GTDB taxonomy coverage")
        print("  index : build a reusable Fulgor genome index")
        print("  tags : design hierarchical tags from GTDB taxonomy")
        print("  targets : rank marker genes for selected taxa")
        print("  regions : discover conserved target windows from marker MSAs")
        print("  probes : map conserved windows to oligos and rank candidates")
        print("  panels : assemble final per-target probe panels")
        print()
        print("Quick Start")
        print("  phyloprobe datasets --taxon archaea")
        print("  phyloprobe taxonomy --dataset archaea")
        print("  phyloprobe tags --dataset archaea --output runs --session ar53_demo")
        print("  phyloprobe targets --dataset archaea --output runs --session ar53_demo")
        print("  phyloprobe regions --dataset archaea --output runs --session ar53_demo")
        print("  phyloprobe probes --dataset archaea --output runs --session ar53_demo")
        print("  phyloprobe panels --dataset archaea --output runs --session ar53_demo")
        print("  phyloprobe targets --dataset archaea --output runs --session ar53_tuned --input-session ar53_demo")
        print()
        print("Use `phyloprobe --help` to see all commands.")
        return

    _print_root_header(console)
    console.print()

    workflow_table = Table(title="Workflow Snapshot")
    workflow_table.add_column("Command")
    workflow_table.add_column("Purpose")
    workflow_table.add_column("Typical Result")
    workflow_table.add_row(
        "datasets",
        "Download and register catalog-defined datasets.",
        "Managed local datasets plus registry manifests.",
    )
    workflow_table.add_row(
        "datasets-list",
        "List installed datasets.",
        "Registered dataset inventory.",
    )
    workflow_table.add_row(
        "datasets-show",
        "Inspect one installed dataset.",
        "Managed file paths, checksums, and summaries.",
    )
    workflow_table.add_row(
        "taxonomy",
        "Profile a GTDB taxonomy TSV or an installed dataset.",
        "Rank counts and lineage coverage summary.",
    )
    workflow_table.add_row(
        "index",
        "Build a reusable Fulgor k-mer index from representative genomes.",
        "A `.fur` index plus a reference map and build summary.",
    )
    workflow_table.add_row(
        "tags",
        "Design hierarchical tags from GTDB taxonomy inputs.",
        "Allocation summaries, tag tables, and leaf label artifacts.",
    )
    workflow_table.add_row(
        "targets",
        "Resolve selected taxa and rank marker genes for each target.",
        "Target summaries, marker scores, and a downstream marker manifest.",
    )
    workflow_table.add_row(
        "regions",
        "Scan selected marker MSAs for conserved target windows.",
        "Ranked region candidates for downstream probe design.",
    )
    workflow_table.add_row(
        "probes",
        "Map conserved windows back to nucleotides and rank oligos.",
        "Probe candidate tables and a top-probe manifest.",
    )
    workflow_table.add_row(
        "panels",
        "Assemble per-target probe panels from ranked probe candidates.",
        "Selected panel summaries plus final per-panel probe manifests.",
    )
    console.print(workflow_table)

    quick_start = Table.grid(padding=(0, 1))
    quick_start.add_column(style="bold cyan")
    quick_start.add_column()
    quick_start.add_row(
        "Install",
        "phyloprobe datasets --taxon archaea",
    )
    quick_start.add_row(
        "Inspect",
        "phyloprobe taxonomy --dataset archaea",
    )
    quick_start.add_row(
        "Design",
        "phyloprobe tags --dataset archaea --output runs --session ar53_demo",
    )
    quick_start.add_row(
        "Targets",
        "phyloprobe targets --dataset archaea --output runs --session ar53_demo",
    )
    quick_start.add_row(
        "Regions",
        "phyloprobe regions --dataset archaea --output runs --session ar53_demo",
    )
    quick_start.add_row(
        "Probes",
        "phyloprobe probes --dataset archaea --output runs --session ar53_demo",
    )
    quick_start.add_row(
        "Panels",
        "phyloprobe panels --dataset archaea --output runs --session ar53_demo",
    )
    quick_start.add_row(
        "Branch",
        "phyloprobe targets --dataset archaea --output runs --session ar53_tuned --input-session ar53_demo",
    )
    console.print(Panel(quick_start, title="Quick Start", border_style="green"))
    console.print("Use `phyloprobe --help` to see all commands.")


def _dataset_install_renderable(
    results: dict[str, object],
    taxon: str,
    catalog_file: Path,
    datasets_dir: Path,
) -> RenderableType:
    return Group(
        Rule("[bold cyan]Phyloprobe Dataset Installation[/bold cyan]"),
        _rich_mapping_panel(
            "Selection",
            {
                "taxon_selector": taxon,
                "catalog_file": str(catalog_file),
                "datasets_dir": str(datasets_dir),
                "datasets_selected": len(results),
            },
            border_style="cyan",
        ),
        _rich_frame("Installation Results", _dataset_install_rows(results), border_style="green"),
    )


def _dataset_list_renderable(records: dict[str, object]) -> RenderableType:
    return Group(
        Rule("[bold cyan]Phyloprobe Datasets[/bold cyan]"),
        _rich_frame("Installed Datasets", _dataset_registry_rows(records), border_style="green"),
    )


def _dataset_show_renderable(record) -> RenderableType:
    sections: list[RenderableType] = [
        Rule("[bold cyan]Phyloprobe Dataset Summary[/bold cyan]"),
        _rich_mapping_panel(
            "Dataset",
            {
                "key": record.key,
                "logical_key": getattr(record, "logical_key", record.key),
                "name": record.name,
                "type": record.dataset_type,
                "taxon": record.taxon,
                "release": record.release,
                "created_at": record.created_at,
            },
            border_style="cyan",
        ),
        _rich_mapping_panel(
            "Managed Files",
            {file_kind: managed_file.managed_path for file_kind, managed_file in sorted(record.files.items())},
            border_style="green",
        ),
    ]
    if record.taxonomy_summary:
        sections.append(_rich_mapping_panel("Taxonomy Summary", record.taxonomy_summary, border_style="blue"))
    if record.index_summary:
        sections.append(_rich_mapping_panel("Index Summary", record.index_summary, border_style="blue"))
    if record.archive_summaries:
        archive_rows = []
        for file_kind, summary in sorted(record.archive_summaries.items()):
            archive_rows.append(
                {
                    "file_kind": file_kind,
                    "members": summary["member_count"],
                    "suffixes": ", ".join(
                        f"{suffix}:{count}" for suffix, count in summary["suffix_counts"].items()
                    ),
                }
            )
        sections.append(_rich_frame("Archive Summaries", archive_rows, border_style="magenta"))
    return Group(*sections)


def _taxonomy_summary_renderable(summary: dict[str, Any], source_label: str) -> RenderableType:
    rank_rows = [
        {
            "rank": rank,
            "taxa": count,
            "missing_rows": summary["missing_rank_counts"][rank],
        }
        for rank, count in summary["rank_counts"].items()
    ]
    return Group(
        Rule("[bold cyan]Phyloprobe Taxonomy Summary[/bold cyan]"),
        _rich_mapping_panel(
            "Input Summary",
            {
                "source": source_label,
                "genomes": summary["genomes"],
                "unique_lineages": summary["unique_lineages"],
            },
            border_style="cyan",
        ),
        _rich_frame("Rank Coverage", rank_rows, border_style="green"),
    )


def _taxonomy_summary_text(summary: dict[str, Any]) -> str:
    lines = [
        f"genomes: {summary['genomes']}",
        f"unique_lineages: {summary['unique_lineages']}",
        "rank_counts:",
    ]
    lines.extend(f"  {rank}: {count}" for rank, count in summary["rank_counts"].items())
    lines.append("missing_rank_counts:")
    lines.extend(f"  {rank}: {count}" for rank, count in summary["missing_rank_counts"].items())
    return "\n".join(lines)


def _dataset_install_text(
    results: dict[str, object],
    taxon: str,
    catalog_file: Path,
    datasets_dir: Path,
) -> str:
    rows = _dataset_install_rows(results)
    lines = [
        f"taxon_selector: {taxon}",
        f"catalog_file: {catalog_file}",
        f"datasets_dir: {datasets_dir}",
    ]
    _append_preview_block(
        lines,
        heading="results",
        rows=rows,
        formatter=lambda row: (
            f"{row['status']}: {row['key']} ({row['name']}) "
            f"[{row['type']}; {row['taxon']}; {row['summary']}]"
        ),
    )
    return "\n".join(lines)


def _normalize_optional_path(path: Path | None) -> Path | None:
    return None if path is None else Path(path).expanduser().resolve()


def _normalize_option_sequence(values: Sequence[Any] | Any | None) -> list[Any]:
    if values is None:
        return []
    if isinstance(values, (str, Path)):
        return [values]
    return [value for value in values]


def _validate_session_name(session_name: str) -> str:
    normalized = session_name.strip()
    if not normalized:
        raise ValueError("Session name cannot be empty.")
    if not SESSION_NAME_PATTERN.fullmatch(normalized):
        raise ValueError("Session name may contain only letters, digits, and underscores.")
    return normalized


def _validate_attempt_token(attempt: str) -> str:
    normalized = str(attempt).strip()
    if not normalized:
        raise ValueError("Attempt cannot be empty.")
    if not ATTEMPT_PATTERN.fullmatch(normalized):
        raise ValueError("Attempt must contain only digits.")
    numeric = int(normalized)
    if numeric < 1:
        raise ValueError("Attempt must be 1 or greater.")
    return f"{numeric:02d}"


@dataclass(frozen=True)
class StageAttemptRef:
    stage: str
    output_dir: Path
    session_name: str
    stage_root: Path
    manifest_path: Path
    attempt: str
    attempt_dir: Path
    prefix: Path


def _stage_root(
    *,
    stage: str,
    output_dir: Path | None,
    session_name: str | None,
) -> Path:
    if output_dir is None or session_name is None:
        raise ValueError("Provide both --output and --session.")
    if stage not in STAGE_NAMES:
        raise ValueError(f"Unknown stage: {stage}")
    normalized_session_name = _validate_session_name(session_name)
    return Path(output_dir).expanduser().resolve() / normalized_session_name / stage


def _stage_manifest_path(
    *,
    stage: str,
    output_dir: Path | None,
    session_name: str | None,
) -> Path:
    return _stage_root(stage=stage, output_dir=output_dir, session_name=session_name) / f"{stage}.json"


def _load_stage_manifest(manifest_path: Path, stage: str) -> dict[str, Any]:
    if manifest_path.exists():
        with manifest_path.open("r", encoding="utf-8") as handle:
            payload = json.load(handle)
        if payload.get("stage") != stage:
            raise ValueError(f"Stage manifest does not describe stage '{stage}': {manifest_path}")
        attempts = payload.get("attempts")
        if not isinstance(attempts, dict):
            raise ValueError(f"Stage manifest is missing attempt records: {manifest_path}")
        return payload
    return {
        "stage": stage,
        "active_attempt": None,
        "attempts": {},
    }


def _write_stage_manifest(manifest_path: Path, payload: Mapping[str, Any]) -> None:
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    with manifest_path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True)
        handle.write("\n")


def _iter_existing_attempt_numbers(stage_root: Path, manifest: Mapping[str, Any]) -> list[int]:
    numbers: set[int] = set()
    attempts = manifest.get("attempts", {})
    if isinstance(attempts, dict):
        for token in attempts.keys():
            if isinstance(token, str) and ATTEMPT_PATTERN.fullmatch(token):
                numbers.add(int(token))
    if stage_root.exists():
        for child in stage_root.iterdir():
            if child.is_dir() and ATTEMPT_PATTERN.fullmatch(child.name):
                numbers.add(int(child.name))
    return sorted(numbers)


def _next_attempt_token(stage_root: Path, manifest: Mapping[str, Any]) -> str:
    numbers = _iter_existing_attempt_numbers(stage_root, manifest)
    next_number = 1 if not numbers else max(numbers) + 1
    return f"{next_number:02d}"


def _resolve_stage_output_attempt(
    *,
    stage: str,
    output_dir: Path | None,
    session_name: str | None,
) -> StageAttemptRef:
    stage_root = _stage_root(stage=stage, output_dir=output_dir, session_name=session_name)
    manifest_path = stage_root / f"{stage}.json"
    manifest = _load_stage_manifest(manifest_path, stage)
    attempt = _next_attempt_token(stage_root, manifest)
    attempt_dir = stage_root / attempt
    prefix = attempt_dir / stage
    return StageAttemptRef(
        stage=stage,
        output_dir=Path(output_dir).expanduser().resolve(),
        session_name=_validate_session_name(str(session_name)),
        stage_root=stage_root,
        manifest_path=manifest_path,
        attempt=attempt,
        attempt_dir=attempt_dir,
        prefix=prefix,
    )


def _resolve_stage_input_attempt(
    *,
    stage: str,
    output_dir: Path | None,
    session_name: str | None,
    input_session_name: str | None = None,
    input_attempt: str | None = None,
) -> StageAttemptRef:
    resolved_session = session_name if input_session_name is None else input_session_name
    stage_root = _stage_root(stage=stage, output_dir=output_dir, session_name=resolved_session)
    manifest_path = stage_root / f"{stage}.json"
    manifest = _load_stage_manifest(manifest_path, stage)
    if input_attempt is None:
        active_attempt = manifest.get("active_attempt")
        if not isinstance(active_attempt, str) or not active_attempt:
            raise ValueError(
                f"No active attempt is recorded for stage '{stage}' in session '{resolved_session}'."
            )
        attempt = _validate_attempt_token(active_attempt)
    else:
        attempt = _validate_attempt_token(input_attempt)
    attempt_record = manifest.get("attempts", {}).get(attempt)
    attempt_dir = stage_root / attempt
    if attempt_record is None and not attempt_dir.exists():
        raise ValueError(
            f"Attempt '{attempt}' is not available for stage '{stage}' in session '{resolved_session}'."
        )
    prefix = attempt_dir / stage
    return StageAttemptRef(
        stage=stage,
        output_dir=Path(output_dir).expanduser().resolve(),
        session_name=_validate_session_name(str(resolved_session)),
        stage_root=stage_root,
        manifest_path=manifest_path,
        attempt=attempt,
        attempt_dir=attempt_dir,
        prefix=prefix,
    )


def _is_manifest_scalar(value: Any) -> bool:
    return value is None or isinstance(value, (bool, int, float, str))


def _is_manifest_parameter_value(value: Any) -> bool:
    if _is_manifest_scalar(value):
        return True
    if isinstance(value, list):
        return all(_is_manifest_scalar(item) for item in value)
    if isinstance(value, dict):
        return all(isinstance(key, str) and _is_manifest_scalar(item) for key, item in value.items())
    return False


def _extract_manifest_parameters(summary: Mapping[str, Any]) -> dict[str, Any]:
    return {
        key: value
        for key, value in summary.items()
        if key != "output_files" and _is_manifest_parameter_value(value)
    }


def _record_stage_attempt(
    stage_ref: StageAttemptRef,
    *,
    summary: Mapping[str, Any],
    output_files: Mapping[str, str],
    upstream_ref: StageAttemptRef | None = None,
) -> None:
    manifest = _load_stage_manifest(stage_ref.manifest_path, stage_ref.stage)
    attempts = manifest.setdefault("attempts", {})
    attempts[stage_ref.attempt] = {
        "attempt": stage_ref.attempt,
        "session": stage_ref.session_name,
        "stage": stage_ref.stage,
        "directory": str(stage_ref.attempt_dir),
        "prefix": str(stage_ref.prefix),
        "created_at": datetime.now(timezone.utc).isoformat(),
        "summary_file": output_files.get("summary"),
        "output_files": dict(output_files),
        "parameters": _extract_manifest_parameters(summary),
        "upstream": None
        if upstream_ref is None
        else {
            "stage": upstream_ref.stage,
            "session": upstream_ref.session_name,
            "attempt": upstream_ref.attempt,
            "manifest": str(upstream_ref.manifest_path),
            "prefix": str(upstream_ref.prefix),
        },
    }
    manifest["active_attempt"] = stage_ref.attempt
    _write_stage_manifest(stage_ref.manifest_path, manifest)



def _run_index_build(
    *,
    genome_archive: Path | None,
    genome_files: Sequence[Path] | None,
    output_prefix: Path,
    fulgor_bin: str,
    kmer_length: int,
    minimizer_length: int,
    threads: int,
    ggcat_threads: int,
    tmp_dir: Path | None,
    keep_extracted: bool,
    check: bool,
    taxon: str | None,
    release: str | None,
    report_format: OutputFormat | str,
    no_color: bool = False,
) -> int:
    resolved_archive = None if genome_archive is None else Path(genome_archive).expanduser().resolve()
    resolved_genome_files = None if genome_files is None else [Path(path).expanduser().resolve() for path in genome_files]
    resolved_output_prefix = Path(output_prefix).expanduser().resolve()
    resolved_tmp_dir = _normalize_optional_path(tmp_dir)

    progress_context = _IndexBuildProgressReporter(not _is_json_output(report_format))
    with progress_context as reporter:
        result = build_fulgor_index(
            genome_archive=resolved_archive,
            genome_files=resolved_genome_files,
            output_prefix=resolved_output_prefix,
            fulgor_binary=fulgor_bin,
            kmer_length=kmer_length,
            minimizer_length=minimizer_length,
            threads=threads,
            ggcat_threads=ggcat_threads,
            tmp_dir=resolved_tmp_dir,
            keep_extracted=keep_extracted,
            check=check,
            taxon=taxon,
            release=release,
            progress_callback=reporter.callback,
        )

    if _is_json_output(report_format):
        _json_dump(result.to_summary_dict())
        return 0

    renderable = _index_build_renderable(result, resolved_output_prefix)
    text = _index_build_text(result, resolved_output_prefix)
    _print_renderable_or_text(renderable, text, no_color=no_color)
    return 0


def _dataset_list_text(records: dict[str, object]) -> str:
    rows = _dataset_registry_rows(records)
    if not rows:
        return "No datasets installed."
    columns = list(rows[0].keys())
    preview_rows, omitted_rows = _preview_rows(rows)
    header = "\t".join(columns)
    body = ["\t".join(str(row[column]) for column in columns) for row in preview_rows]
    if omitted_rows > 0:
        body.append(f"... ({omitted_rows} more rows not shown)")
    return "\n".join([header, *body])


def _dataset_show_text(record) -> str:
    lines = [
        f"key: {record.key}",
        f"logical_key: {getattr(record, 'logical_key', record.key)}",
        f"name: {record.name}",
        f"type: {record.dataset_type}",
        f"taxon: {record.taxon}",
        f"release: {record.release}",
        f"created_at: {record.created_at}",
    ]
    for file_kind, managed_file in sorted(record.files.items()):
        lines.append(f"{file_kind}_file: {managed_file.managed_path}")
    if record.taxonomy_summary:
        lines.append(_taxonomy_summary_text(record.taxonomy_summary))
    if record.index_summary:
        lines.append("index_summary:")
        for key, value in sorted(record.index_summary.items()):
            lines.append(f"  {key}: {value}")
    return "\n".join(lines)


def _index_build_renderable(result, output_prefix: Path) -> RenderableType:
    return Group(
        Rule("[bold cyan]PhyloProbe Genome Index[/bold cyan]"),
        _rich_mapping_panel(
            "Run Summary",
            {
                "input_mode": result.input_mode,
                "genome_archive": result.genome_archive,
                "genome_file_count": len(result.genome_files),
                "output_prefix": str(output_prefix),
                "index_file": result.index_file,
                "reference_map_file": result.reference_map_file,
                "kmer_length": result.kmer_length,
                "minimizer_length": result.minimizer_length,
                "threads": result.threads,
                "ggcat_threads": result.ggcat_threads,
                "indexed_references": result.indexed_references,
                "taxon": result.taxon,
                "release": result.release,
            },
            border_style="cyan",
        ),
        _rich_mapping_panel("Output Files", result.output_files or {}, border_style="magenta"),
    )


def _index_build_text(result, output_prefix: Path) -> str:
    lines = [
        f"input_mode: {result.input_mode}",
        f"genome_archive: {result.genome_archive}",
        f"genome_file_count: {len(result.genome_files)}",
        f"output_prefix: {output_prefix}",
        f"index_file: {result.index_file}",
        f"reference_map_file: {result.reference_map_file}",
        f"kmer_length: {result.kmer_length}",
        f"minimizer_length: {result.minimizer_length}",
        f"threads: {result.threads}",
        f"ggcat_threads: {result.ggcat_threads}",
        f"indexed_references: {result.indexed_references}",
        f"taxon: {result.taxon}",
        f"release: {result.release}",
    ]
    if result.genome_files:
        lines.append("genome_files:")
        for genome_file in result.genome_files:
            lines.append(f"  - {genome_file}")
    if result.output_files:
        lines.append("output_files:")
        for key, value in result.output_files.items():
            lines.append(f"  {key}: {value}")
    return "\n".join(lines)


def _tags_design_renderable(result, output_prefix: Path, source_label: str) -> RenderableType:
    def _format_constraint(name: str, payload: Any) -> str | None:
        if not payload:
            return None
        if isinstance(payload, dict):
            parts: list[str] = []
            for level, values in sorted(payload.items()):
                if isinstance(values, list):
                    parts.append(f"{level}:{'|'.join(values)}")
                elif isinstance(values, float):
                    parts.append(f"{level}:{values:.6g}")
                else:
                    parts.append(f"{level}:{values}")
            return ",".join(parts)
        return str(payload)

    summary = {
        "source": source_label,
        "output_prefix": str(output_prefix),
        "positions": result.positions,
        "alphabet": ",".join(result.alphabet),
        "levels": ",".join(result.levels),
        "objective_levels": ",".join(result.objective_levels),
        "level_weights": _format_constraint("level_weights", result.level_weights),
        "estimated_candidates": result.estimated_candidates,
        "evaluated_candidates": result.evaluated_candidates,
        "score": result.objective["score"],
        "available_slots": result.objective["total_slots"],
        "used_slots": result.objective["used_slots"],
        "unused_slots": result.objective["total_slots"] - result.objective["used_slots"],
        "utilization": result.objective["utilization"],
        "fallbacks_per_target": result.constraints.get("fallbacks_per_target", 0),
    }
    for key in (
        "exclusive_taxa",
        "include_taxa",
        "exclude_taxa",
        "prefer_taxa",
        "avoid_taxa",
        "descendants",
        "descendants_hard",
    ):
        formatted = _format_constraint(key, result.constraints.get(key))
        if formatted:
            summary[key] = formatted
    tree_preview_lines = max(len(result.level_positions) * 8, 12)
    focused_levels = {
        str(row["level"])
        for row in result.level_positions
        if int(row.get("positions_allocated", 0) or 0) > 0
    }
    return Group(
        Rule("[bold cyan]PhyloProbe Tag Design[/bold cyan]"),
        _rich_mapping_panel(
            "Run Summary",
            summary,
            border_style="cyan",
        ),
        _rich_frame("Position Allocation", result.level_positions, border_style="green"),
        _rich_taxonomy_tree_panel(
            "Selected Taxonomy Tree",
            result.taxonomy_tree_entries,
            focused_levels,
            border_style="green",
            max_lines=tree_preview_lines,
        ),
        _rich_frame("Coverage Summary", result.coverage_summary, border_style="blue"),
        _rich_mapping_panel("Output Files", result.output_files or {}, border_style="magenta"),
    )


def _tags_design_text(result, output_prefix: Path, source_label: str) -> str:
    def _format_constraint(payload: Any) -> str | None:
        if not payload:
            return None
        if isinstance(payload, dict):
            parts: list[str] = []
            for level, values in sorted(payload.items()):
                if isinstance(values, list):
                    parts.append(f"{level}:{'|'.join(values)}")
                elif isinstance(values, float):
                    parts.append(f"{level}:{values:.6g}")
                else:
                    parts.append(f"{level}:{values}")
            return ",".join(parts)
        return str(payload)

    lines = [
        f"source: {source_label}",
        f"output_prefix: {output_prefix}",
        f"positions: {result.positions}",
        f"alphabet: {','.join(result.alphabet)}",
        f"levels: {','.join(result.levels)}",
        f"objective_levels: {','.join(result.objective_levels)}",
        f"level_weights: {_format_constraint(result.level_weights)}",
        f"estimated_candidates: {result.estimated_candidates}",
        f"evaluated_candidates: {result.evaluated_candidates}",
        f"score: {result.objective['score']}",
        f"available_slots: {result.objective['total_slots']}",
        f"used_slots: {result.objective['used_slots']}",
        f"unused_slots: {result.objective['total_slots'] - result.objective['used_slots']}",
        f"utilization: {result.objective['utilization']}",
        f"fallbacks_per_target: {result.constraints.get('fallbacks_per_target', 0)}",
    ]
    for key in (
        "exclusive_taxa",
        "include_taxa",
        "exclude_taxa",
        "prefer_taxa",
        "avoid_taxa",
        "descendants",
        "descendants_hard",
    ):
        formatted = _format_constraint(result.constraints.get(key))
        if formatted:
            lines.append(f"{key}: {formatted}")
    _append_preview_block(
        lines,
        heading="position_allocation",
        rows=result.level_positions,
        formatter=lambda row: (
            f"{row['level']}: positions={row['positions_allocated']}, "
            f"stage={row['stage']}, capacity_per_parent={row['capacity_per_parent']}, "
            f"available_slots={row['available_slots']}, used_slots={row['used_slots']}, "
            f"unused_slots={row['unused_slots']}, slot_utilization={row['slot_utilization']}"
        ),
    )
    lines.extend([
        "taxonomy_tree:",
        result.taxonomy_tree_text or "(no taxa selected)",
    ])
    if result.output_files:
        lines.append("output_files:")
        for key, value in result.output_files.items():
            lines.append(f"  {key}: {value}")
    return "\n".join(lines)


def _targets_discover_renderable(result, output_prefix: Path) -> RenderableType:
    include_scope = format_taxon_constraint_summary(result.include_taxa)
    exclude_scope = format_taxon_constraint_summary(result.exclude_taxa)
    return Group(
        Rule("[bold cyan]PhyloProbe Target Discovery[/bold cyan]"),
        _rich_mapping_panel(
            "Run Summary",
            {
                "dataset": result.dataset,
                "taxonomy_file": result.taxonomy_file,
                "markers_archive": result.markers_archive,
                "tag_design_prefix": result.tag_design_prefix,
                "output_prefix": str(output_prefix),
                "selected_targets": len(result.selected_targets),
                "analyzed_markers": result.analyzed_markers,
                "marker_available_genomes": result.all_marker_available_genomes,
                "profile": result.selection_profile,
                "top_markers_per_target": result.top_markers_per_target,
                "fallback_policy": ",".join(result.fallback_policy) or "none",
                "promoted_targets": result.promoted_targets,
                "include_taxa": include_scope,
                "exclude_taxa": exclude_scope,
                "sibling_penalty_weight": result.sibling_penalty_weight,
                "global_penalty_weight": result.global_penalty_weight,
            },
            border_style="cyan",
        ),
        _rich_frame("Selected Targets", result.selected_targets, border_style="green"),
        _rich_mapping_panel("Output Files", result.output_files or {}, border_style="magenta"),
    )


def _targets_discover_text(result, output_prefix: Path) -> str:
    include_scope = format_taxon_constraint_summary(result.include_taxa)
    exclude_scope = format_taxon_constraint_summary(result.exclude_taxa)
    lines = [
        f"dataset: {result.dataset}",
        f"taxonomy_file: {result.taxonomy_file}",
        f"markers_archive: {result.markers_archive}",
        f"tag_design_prefix: {result.tag_design_prefix}",
        f"output_prefix: {output_prefix}",
        f"selected_targets: {len(result.selected_targets)}",
        f"analyzed_markers: {result.analyzed_markers}",
        f"marker_available_genomes: {result.all_marker_available_genomes}",
        f"profile: {result.selection_profile}",
        f"top_markers_per_target: {result.top_markers_per_target}",
        f"fallback_policy: {','.join(result.fallback_policy) or 'none'}",
        f"promoted_targets: {result.promoted_targets}",
        f"include_taxa: {include_scope}",
        f"exclude_taxa: {exclude_scope}",
        f"sibling_penalty_weight: {result.sibling_penalty_weight}",
        f"global_penalty_weight: {result.global_penalty_weight}",
    ]
    _append_preview_block(
        lines,
        heading="targets",
        rows=result.selected_targets,
        formatter=lambda row: (
            f"{row['barcode']} {row['resolved_level']}={row['resolved_taxon']} "
            f"[source={row['selection_source']}; "
            f"status={row['status']}; "
            f"markers={row.get('retained_markers')}/{row.get('candidate_markers')}; "
            f"retained_nt_space={row.get('total_mean_nt_length_retained_markers')}; "
            f"target_marker_available_genomes={row['target_marker_available_genomes']}; "
            f"best_marker={row['best_marker']}]"
        ),
    )
    if result.output_files:
        lines.append("output_files:")
        for key, value in result.output_files.items():
            lines.append(f"  {key}: {value}")
    return "\n".join(lines)


def _regions_discover_renderable(result, output_prefix: Path) -> RenderableType:
    ready_targets = sum(1 for row in result.target_region_summary if str(row.get("status")) == "ready")
    discovery_profile = getattr(result, "discovery_profile", DEFAULT_DISCOVERY_PROFILE)
    sibling_penalty_weight = getattr(result, "sibling_penalty_weight", DEFAULT_REGION_SIBLING_PENALTY_WEIGHT)
    global_penalty_weight = getattr(result, "global_penalty_weight", DEFAULT_REGION_GLOBAL_PENALTY_WEIGHT)
    include_scope = format_taxon_constraint_summary(getattr(result, "include_taxa", None))
    exclude_scope = format_taxon_constraint_summary(getattr(result, "exclude_taxa", None))
    return Group(
        Rule("[bold cyan]PhyloProbe Region Discovery[/bold cyan]"),
        _rich_mapping_panel(
            "Run Summary",
            {
                "dataset": result.dataset,
                "taxonomy_file": result.taxonomy_file,
                "msa_archive": result.msa_archive,
                "markers_archive": result.markers_archive,
                "target_discovery_prefix": result.target_discovery_prefix,
                "output_prefix": str(output_prefix),
                "targets": len(result.target_region_summary),
                "targets_with_regions": ready_targets,
                "selected_target_markers": len(result.selected_target_markers),
                "retained_regions": len(result.region_candidates),
                "analyzed_markers": result.analyzed_markers,
                "profile": discovery_profile,
                "window_aa_length": result.window_aa_length,
                "window_aa_length_min": result.window_aa_length_min,
                "window_aa_length_max": result.window_aa_length_max,
                "top_regions_per_marker": result.top_regions_per_marker,
                "min_target_window_presence": result.min_target_window_presence,
                "max_aa_mismatches": result.max_aa_mismatches,
                "aa_mismatch_penalty_per_mismatch": result.aa_mismatch_penalty_per_mismatch,
                "region_probe_length": result.region_probe_length,
                "min_target_remap_fraction": result.min_target_remap_fraction,
                "min_best_probe_support_fraction": result.min_best_probe_support_fraction,
                "probeability_weight": result.probeability_weight,
                "include_taxa": include_scope,
                "exclude_taxa": exclude_scope,
                "sibling_penalty_weight": sibling_penalty_weight,
                "global_penalty_weight": global_penalty_weight,
            },
            border_style="cyan",
        ),
        _rich_frame("Target Summary", result.target_region_summary, border_style="green"),
        _rich_mapping_panel("Output Files", result.output_files or {}, border_style="magenta"),
    )


def _regions_discover_text(result, output_prefix: Path) -> str:
    target_summary_rows = getattr(result, "target_region_summary", result.selected_target_markers)
    region_candidates = getattr(result, "region_candidates", [])
    discovery_profile = getattr(result, "discovery_profile", DEFAULT_DISCOVERY_PROFILE)
    sibling_penalty_weight = getattr(result, "sibling_penalty_weight", DEFAULT_REGION_SIBLING_PENALTY_WEIGHT)
    global_penalty_weight = getattr(result, "global_penalty_weight", DEFAULT_REGION_GLOBAL_PENALTY_WEIGHT)
    include_scope = format_taxon_constraint_summary(getattr(result, "include_taxa", None))
    exclude_scope = format_taxon_constraint_summary(getattr(result, "exclude_taxa", None))
    lines = [
        f"dataset: {result.dataset}",
        f"taxonomy_file: {result.taxonomy_file}",
        f"msa_archive: {result.msa_archive}",
        f"markers_archive: {result.markers_archive}",
        f"target_discovery_prefix: {result.target_discovery_prefix}",
        f"output_prefix: {output_prefix}",
        f"targets: {len(target_summary_rows)}",
        f"targets_with_regions: {sum(1 for row in target_summary_rows if str(row.get('status')) == 'ready')}",
        f"selected_target_markers: {len(result.selected_target_markers)}",
        f"retained_regions: {len(region_candidates)}",
        f"analyzed_markers: {result.analyzed_markers}",
        f"profile: {discovery_profile}",
        f"window_aa_length: {result.window_aa_length}",
        f"window_aa_length_min: {result.window_aa_length_min}",
        f"window_aa_length_max: {result.window_aa_length_max}",
        f"top_regions_per_marker: {result.top_regions_per_marker}",
        f"min_target_window_presence: {result.min_target_window_presence}",
        f"max_aa_mismatches: {result.max_aa_mismatches}",
        f"aa_mismatch_penalty_per_mismatch: {result.aa_mismatch_penalty_per_mismatch}",
        f"region_probe_length: {result.region_probe_length}",
        f"min_target_remap_fraction: {result.min_target_remap_fraction}",
        f"min_best_probe_support_fraction: {result.min_best_probe_support_fraction}",
        f"probeability_weight: {result.probeability_weight}",
        f"include_taxa: {include_scope}",
        f"exclude_taxa: {exclude_scope}",
        f"sibling_penalty_weight: {sibling_penalty_weight}",
        f"global_penalty_weight: {global_penalty_weight}",
    ]
    _append_preview_block(
        lines,
        heading="targets",
        rows=target_summary_rows,
        formatter=lambda row: (
            f"{row.get('barcode')} "
            f"{row.get('resolved_level', 'marker')}={row.get('resolved_taxon', row.get('marker_id'))} "
            f"[status={row['status']}; "
            f"markers_with_regions={row.get('markers_with_selected_regions', row.get('selected_regions'))}; "
            f"retained_regions={row.get('retained_regions', row.get('selected_regions'))}; "
            f"probeable_positions={row.get('total_probeable_positions')}]"
        ),
    )
    if result.output_files:
        lines.append("output_files:")
        for key, value in result.output_files.items():
            lines.append(f"  {key}: {value}")
    return "\n".join(lines)


def _probes_design_renderable(result, output_prefix: Path) -> RenderableType:
    ready_targets = sum(1 for row in result.target_probe_summary if str(row.get("status")) == "ready")
    include_scope = format_taxon_constraint_summary(getattr(result, "include_taxa", None))
    exclude_scope = format_taxon_constraint_summary(getattr(result, "exclude_taxa", None))
    return Group(
        Rule("[bold cyan]PhyloProbe Probe Design[/bold cyan]"),
        _rich_mapping_panel(
            "Run Summary",
            {
                "dataset": result.dataset,
                "taxonomy_file": result.taxonomy_file,
                "markers_archive": result.markers_archive,
                "region_discovery_prefix": result.region_discovery_prefix,
                "output_prefix": str(output_prefix),
                "targets": len(result.target_probe_summary),
                "targets_with_selected_probes": ready_targets,
                "selected_regions": len(result.selected_regions),
                "selected_probes": len(result.top_probe_manifest),
                "analyzed_markers": result.analyzed_markers,
                "probe_length": result.probe_length,
                "top_probes_per_region": result.top_probes_per_region,
                "profile": result.scoring_config.scoring_profile,
                "thermo_backend": result.scoring_config.thermo_backend,
                "max_mismatches": result.match_config.max_mismatches,
                "include_taxa": include_scope,
                "exclude_taxa": exclude_scope,
            },
            border_style="cyan",
        ),
        _rich_frame("Target Summary", result.target_probe_summary, border_style="green"),
        _rich_mapping_panel("Output Files", result.output_files or {}, border_style="magenta"),
    )


def _probes_design_text(result, output_prefix: Path) -> str:
    target_summary_rows = getattr(result, "target_probe_summary", result.selected_regions)
    top_probe_manifest = getattr(result, "top_probe_manifest", [])
    include_scope = format_taxon_constraint_summary(getattr(result, "include_taxa", None))
    exclude_scope = format_taxon_constraint_summary(getattr(result, "exclude_taxa", None))
    lines = [
        f"dataset: {result.dataset}",
        f"taxonomy_file: {result.taxonomy_file}",
        f"markers_archive: {result.markers_archive}",
        f"region_discovery_prefix: {result.region_discovery_prefix}",
        f"output_prefix: {output_prefix}",
        f"targets: {len(target_summary_rows)}",
        f"targets_with_selected_probes: {sum(1 for row in target_summary_rows if str(row.get('status')) == 'ready')}",
        f"selected_regions: {len(result.selected_regions)}",
        f"selected_probes: {len(top_probe_manifest)}",
        f"analyzed_markers: {result.analyzed_markers}",
        f"probe_length: {result.probe_length}",
        f"top_probes_per_region: {result.top_probes_per_region}",
        f"profile: {result.scoring_config.scoring_profile}",
        f"thermo_backend: {result.scoring_config.thermo_backend}",
        f"max_mismatches: {result.match_config.max_mismatches}",
        f"include_taxa: {include_scope}",
        f"exclude_taxa: {exclude_scope}",
    ]
    _append_preview_block(
        lines,
        heading="targets",
        rows=target_summary_rows,
        formatter=lambda row: (
            f"{row.get('barcode')} "
            f"{row.get('resolved_level', 'marker')}={row.get('resolved_taxon', row.get('marker_id'))} "
            f"[status={row['status']}; "
            f"candidate_probes_total={row.get('candidate_probes_total', row.get('candidate_probes'))}; "
            f"selected_probes_total={row.get('selected_probes_total', row.get('selected_probes'))}; "
            f"markers_with_selected_probes={row.get('markers_with_selected_probes', row.get('marker_id'))}]"
        ),
    )
    if result.output_files:
        lines.append("output_files:")
        for key, value in result.output_files.items():
            lines.append(f"  {key}: {value}")
    return "\n".join(lines)


def _panels_design_renderable(result, output_prefix: Path) -> RenderableType:
    include_scope = format_taxon_constraint_summary(getattr(result, "include_taxa", None))
    exclude_scope = format_taxon_constraint_summary(getattr(result, "exclude_taxa", None))
    return Group(
        Rule("[bold cyan]PhyloProbe Panel Design[/bold cyan]"),
        _rich_mapping_panel(
            "Run Summary",
            {
                "dataset": result.dataset,
                "index_dataset": result.index_dataset,
                "index_datasets": ",".join(result.index_datasets),
                "index_labels": ",".join(result.index_labels),
                "taxonomy_file": result.taxonomy_file,
                "markers_archive": result.markers_archive,
                "probe_design_prefix": result.probe_design_prefix,
                "index_file": result.index_file,
                "index_reference_map_file": result.index_reference_map_file,
                "index_count": len(result.index_files),
                "output_prefix": str(output_prefix),
                "selected_panels": len(result.selected_panels),
                "analyzed_markers": result.analyzed_markers,
                "max_probes_per_panel": result.max_probes_per_panel,
                "max_probes_per_marker": result.max_probes_per_marker,
                "max_probes_per_region": result.max_probes_per_region,
                "allow_overlaps": result.allow_overlaps,
                "genome_index_penalty_weight": result.genome_index_penalty_weight,
                "profile": result.interaction_config.scoring_profile,
                "interaction_backend": result.interaction_config.interaction_backend,
                "max_mismatches": result.match_config.max_mismatches,
                "include_taxa": include_scope,
                "exclude_taxa": exclude_scope,
            },
            border_style="cyan",
        ),
        _rich_frame("Panel Status", result.selected_panels, border_style="green"),
        _rich_mapping_panel("Output Files", result.output_files or {}, border_style="magenta"),
    )


def _panels_design_text(result, output_prefix: Path) -> str:
    include_scope = format_taxon_constraint_summary(getattr(result, "include_taxa", None))
    exclude_scope = format_taxon_constraint_summary(getattr(result, "exclude_taxa", None))
    lines = [
        f"dataset: {result.dataset}",
        f"index_dataset: {result.index_dataset}",
        f"index_datasets: {','.join(result.index_datasets)}",
        f"index_labels: {','.join(result.index_labels)}",
        f"taxonomy_file: {result.taxonomy_file}",
        f"markers_archive: {result.markers_archive}",
        f"probe_design_prefix: {result.probe_design_prefix}",
        f"index_file: {result.index_file}",
        f"index_reference_map_file: {result.index_reference_map_file}",
        f"index_count: {len(result.index_files)}",
        f"output_prefix: {output_prefix}",
        f"selected_panels: {len(result.selected_panels)}",
        f"analyzed_markers: {result.analyzed_markers}",
        f"max_probes_per_panel: {result.max_probes_per_panel}",
        f"max_probes_per_marker: {result.max_probes_per_marker}",
        f"max_probes_per_region: {result.max_probes_per_region}",
        f"allow_overlaps: {result.allow_overlaps}",
        f"genome_index_penalty_weight: {result.genome_index_penalty_weight}",
        f"profile: {result.interaction_config.scoring_profile}",
        f"interaction_backend: {result.interaction_config.interaction_backend}",
        f"max_mismatches: {result.match_config.max_mismatches}",
        f"include_taxa: {include_scope}",
        f"exclude_taxa: {exclude_scope}",
    ]
    _append_preview_block(
        lines,
        heading="panels",
        rows=result.selected_panels,
        formatter=lambda row: (
            f"{row['barcode']} "
            f"[status={row['status']}; "
            f"input_probe_candidates={row['input_probe_candidates']}; "
            f"selected_probes={row['selected_probes']}; "
            f"panel_score={row['panel_score']}]"
        ),
    )
    if result.output_files:
        lines.append("output_files:")
        for key, value in result.output_files.items():
            lines.append(f"  {key}: {value}")
    return "\n".join(lines)


def _print_renderable_or_text(
    renderable: RenderableType,
    text: str,
    *,
    no_color: bool = False,
) -> None:
    if no_color:
        print(text)
        return
    console = _make_console(no_color=no_color)
    if console is None:
        print(text)
        return
    console.print(renderable)


def _error_renderable(message: str) -> RenderableType:
    return Group(
        Rule("[bold red]PhyloProbe Error[/bold red]"),
        Panel(Text(message, style="bold white"), title="Error", border_style="red"),
    )


def _error_text(message: str) -> str:
    return "\n".join(
        [
            "PhyloProbe Error",
            message,
        ]
    )


def _print_cli_error(message: str, *, file=None, no_color: bool = False) -> None:
    output = sys.stderr if file is None else file
    if RICH_AVAILABLE:
        console = Console(file=output, no_color=no_color, force_terminal=False)
        _print_root_header(console)
        console.print()
        console.print(_error_renderable(message))
        return
    print(_error_text(message), file=output)


if click is not None:
    class PhyloprobeClickException(click.ClickException):
        def show(self, file=None) -> None:
            _print_cli_error(self.format_message(), file=file)


def _run_datasets_install(
    *,
    taxon: str,
    catalog_file: Path,
    gtdb_release: str | None,
    datasets_dir: Path | None,
    report_format: OutputFormat | str,
    force: bool = False,
    no_color: bool = False,
) -> int:
    normalized_taxon = _validate_taxon_selector(taxon)
    resolved_catalog = Path(catalog_file).expanduser().resolve()
    resolved_datasets_dir = resolve_datasets_root(_normalize_optional_path(datasets_dir))
    results = install_catalog_selection(
        taxon=normalized_taxon,
        catalog_file=resolved_catalog,
        gtdb_release=gtdb_release,
        force=force,
        datasets_dir=resolved_datasets_dir,
    )
    payload = {key: result.to_dict() for key, result in results.items()}
    if _is_json_output(report_format):
        _json_dump(payload)
        return 0
    renderable = _dataset_install_renderable(
        results,
        normalized_taxon,
        resolved_catalog,
        resolved_datasets_dir,
    )
    text = _dataset_install_text(results, normalized_taxon, resolved_catalog, resolved_datasets_dir)
    _print_renderable_or_text(renderable, text, no_color=no_color)
    return 0


def _run_datasets_list(
    *,
    report_format: OutputFormat | str,
    no_color: bool = False,
) -> int:
    records = load_registry()
    payload = {name: record.to_dict() for name, record in records.items()}
    if _is_json_output(report_format):
        _json_dump(payload)
        return 0
    renderable = _dataset_list_renderable(records)
    text = _dataset_list_text(records)
    _print_renderable_or_text(renderable, text, no_color=no_color)
    return 0


def _run_datasets_show(
    *,
    name: str,
    gtdb_release: str | None,
    report_format: OutputFormat | str,
    no_color: bool = False,
) -> int:
    record = resolve_dataset_record(name, gtdb_release=gtdb_release)
    if _is_json_output(report_format):
        _json_dump(record.to_dict())
        return 0
    renderable = _dataset_show_renderable(record)
    text = _dataset_show_text(record)
    _print_renderable_or_text(renderable, text, no_color=no_color)
    return 0


def _run_taxonomy_summarize(
    *,
    taxonomy_file: Path | None,
    dataset: str | None,
    gtdb_release: str | None,
    report_format: OutputFormat | str,
    no_color: bool = False,
) -> int:
    if (taxonomy_file is None) == (dataset is None):
        raise ValueError("Provide exactly one of --taxonomy-file or --dataset.")

    if taxonomy_file is not None:
        resolved_path = Path(taxonomy_file).expanduser().resolve()
        summary = summarize_taxonomy_file(resolved_path).to_dict()
        source_label = str(resolved_path)
    else:
        record = resolve_dataset_record(str(dataset), gtdb_release=gtdb_release, dataset_type="gtdb")
        summary = record.taxonomy_summary
        source_label = f"dataset:{record.key}"

    if _is_json_output(report_format):
        _json_dump(summary)
        return 0
    renderable = _taxonomy_summary_renderable(summary, source_label)
    text = _taxonomy_summary_text(summary)
    _print_renderable_or_text(renderable, text, no_color=no_color)
    return 0


def _run_placeholder(stage: str) -> int:
    print(
        f"`phyloprobe {stage}` is part of the planned workflow backbone but is not implemented yet.",
        file=sys.stderr,
    )
    return 1


def _resolve_taxonomy_design_source(
    taxonomy_file: Path | None,
    dataset: str | None,
    gtdb_release: str | None,
) -> tuple[Path, str]:
    if (taxonomy_file is None) == (dataset is None):
        raise ValueError("Provide exactly one of --taxonomy-file or --dataset.")
    if taxonomy_file is not None:
        resolved = Path(taxonomy_file).expanduser().resolve()
        return resolved, str(resolved)

    record = resolve_dataset_record(str(dataset), gtdb_release=gtdb_release, dataset_type="gtdb")
    try:
        managed_path = record.files["taxonomy"].managed_path
    except KeyError as exc:
        raise ValueError(f"Dataset '{dataset}' does not have a managed taxonomy file.") from exc
    return Path(managed_path), f"dataset:{record.key}"


def _run_tags_design(
    *,
    taxonomy_file: Path | None,
    dataset: str | None,
    gtdb_release: str | None,
    output_dir: Path | None,
    session_name: str | None,
    positions: int,
    alphabet: str,
    levels: str,
    maximise_levels: str,
    level_weights: str | None,
    min_taxa_per_level: str | None,
    exclusive: Sequence[str] | None,
    include: Sequence[str] | None,
    exclude: Sequence[str] | None,
    prefer: Sequence[str] | None,
    avoid: Sequence[str] | None,
    descendants: Sequence[str] | None,
    descendants_hard: Sequence[str] | None,
    fallbacks_per_target: int,
    util_weight: float,
    report_format: OutputFormat | str,
    no_color: bool = False,
) -> int:
    source_path, source_label = _resolve_taxonomy_design_source(taxonomy_file, dataset, gtdb_release)
    resolved_alphabet = parse_tag_alphabet(alphabet)
    resolved_levels = parse_tag_levels(levels)
    resolved_objective_levels = parse_tag_maximise_levels(maximise_levels, resolved_levels)
    resolved_level_weights = parse_tag_level_weights(level_weights, resolved_levels)
    resolved_min_taxa = parse_tag_min_taxa_per_level(min_taxa_per_level, resolved_levels)
    resolved_exclusive_taxa = parse_tag_taxon_constraints(
        exclusive,
        resolved_levels,
        option_name="--exclusive",
    )
    resolved_include_taxa = parse_tag_taxon_constraints(
        include,
        resolved_levels,
        option_name="--include",
    )
    resolved_exclude_taxa = parse_tag_taxon_constraints(
        exclude,
        resolved_levels,
        option_name="--exclude",
    )
    resolved_prefer_taxa = parse_tag_taxon_constraints(
        prefer,
        resolved_levels,
        option_name="--prefer",
    )
    resolved_avoid_taxa = parse_tag_taxon_constraints(
        avoid,
        resolved_levels,
        option_name="--avoid",
    )
    resolved_descendants = parse_tag_descendant_rules(
        descendants,
        resolved_levels,
        option_name="--descendants",
    )
    resolved_descendants_hard = parse_tag_descendant_rules(
        descendants_hard,
        resolved_levels,
        option_name="--descendants-hard",
    )
    output_ref = _resolve_stage_output_attempt(
        stage="tags",
        output_dir=output_dir,
        session_name=session_name,
    )

    progress_context = _TagDesignProgressReporter(not _is_json_output(report_format))
    with progress_context as reporter:
        result = design_tags(
            source_path,
            positions=positions,
            alphabet=resolved_alphabet,
            levels=resolved_levels,
            maximise_levels=resolved_objective_levels,
            level_weights=resolved_level_weights,
            min_taxa_required=resolved_min_taxa,
            exclusive_taxa=resolved_exclusive_taxa,
            include_taxa=resolved_include_taxa,
            exclude_taxa=resolved_exclude_taxa,
            prefer_taxa=resolved_prefer_taxa,
            avoid_taxa=resolved_avoid_taxa,
            descendants_soft=resolved_descendants,
            descendants_hard=resolved_descendants_hard,
            fallbacks_per_target=fallbacks_per_target,
            util_weight=util_weight,
            progress_callback=reporter.callback,
        )
    output_paths = write_tag_design_outputs(result, output_ref.prefix)
    _record_stage_attempt(
        output_ref,
        summary=result.to_summary_dict(),
        output_files={name: str(path) for name, path in output_paths.items()},
    )

    if _is_json_output(report_format):
        _json_dump(result.to_summary_dict())
        return 0

    renderable = _tags_design_renderable(result, output_ref.prefix, source_label)
    text = _tags_design_text(result, output_ref.prefix, source_label)
    _print_renderable_or_text(renderable, text, no_color=no_color)
    return 0


def _resolve_target_discovery_inputs(
    *,
    dataset: str | None,
    gtdb_release: str | None,
    taxonomy_file: Path | None,
    markers_archive: Path | None,
) -> tuple[str | None, Path, Path]:
    if dataset:
        if taxonomy_file is not None or markers_archive is not None:
            raise ValueError("Use either --dataset or the explicit --taxonomy-file/--markers-archive pair.")
        record = resolve_dataset_record(str(dataset), gtdb_release=gtdb_release, dataset_type="gtdb")
        try:
            resolved_taxonomy = Path(record.files["taxonomy"].managed_path)
            resolved_markers = Path(record.files["markers"].managed_path)
        except KeyError as exc:
            raise ValueError(f"Dataset '{dataset}' does not include the required taxonomy and markers files.") from exc
        return record.key, resolved_taxonomy, resolved_markers

    if taxonomy_file is None or markers_archive is None:
        raise ValueError("Provide --dataset or both --taxonomy-file and --markers-archive.")
    return None, Path(taxonomy_file).expanduser().resolve(), Path(markers_archive).expanduser().resolve()


def _run_targets_discover(
    *,
    dataset: str | None,
    gtdb_release: str | None,
    taxonomy_file: Path | None,
    markers_archive: Path | None,
    output_dir: Path | None,
    session_name: str | None,
    input_session_name: str | None,
    input_attempt: str | None,
    selection_profile: str,
    top_markers_per_target: int | None,
    fallback_policy: str,
    include: Sequence[str] | None,
    exclude: Sequence[str] | None,
    workers: int,
    report_format: OutputFormat | str,
    no_color: bool = False,
) -> int:
    resolved_dataset, resolved_taxonomy, resolved_markers = _resolve_target_discovery_inputs(
        dataset=dataset,
        gtdb_release=gtdb_release,
        taxonomy_file=taxonomy_file,
        markers_archive=markers_archive,
    )
    input_ref = _resolve_stage_input_attempt(
        stage="tags",
        output_dir=output_dir,
        session_name=session_name,
        input_session_name=input_session_name,
        input_attempt=input_attempt,
    )
    output_ref = _resolve_stage_output_attempt(
        stage="targets",
        output_dir=output_dir,
        session_name=session_name,
    )
    resolved_include_taxa = parse_tag_taxon_constraints(
        include,
        GTDB_RANKS,
        option_name="--include",
    )
    resolved_exclude_taxa = parse_tag_taxon_constraints(
        exclude,
        GTDB_RANKS,
        option_name="--exclude",
    )

    progress_context = _TargetDiscoveryProgressReporter(not _is_json_output(report_format))
    with progress_context as reporter:
        result = discover_targets(
            dataset=resolved_dataset,
            taxonomy_file=resolved_taxonomy,
            markers_archive=resolved_markers,
            tag_design_prefix=input_ref.prefix,
            selection_profile=selection_profile,
            top_markers_per_target=top_markers_per_target,
            fallback_policy=fallback_policy,
            include_taxa=resolved_include_taxa,
            exclude_taxa=resolved_exclude_taxa,
            workers=workers,
            progress_callback=reporter.callback,
        )
    output_paths = write_target_discovery_outputs(result, output_ref.prefix)
    _record_stage_attempt(
        output_ref,
        summary=result.to_summary_dict(),
        output_files={name: str(path) for name, path in output_paths.items()},
        upstream_ref=input_ref,
    )

    if _is_json_output(report_format):
        _json_dump(result.to_summary_dict())
        return 0

    renderable = _targets_discover_renderable(result, output_ref.prefix)
    text = _targets_discover_text(result, output_ref.prefix)
    _print_renderable_or_text(renderable, text, no_color=no_color)
    return 0


def _resolve_region_discovery_inputs(
    *,
    dataset: str | None,
    gtdb_release: str | None,
    taxonomy_file: Path | None,
    msa_archive: Path | None,
    markers_archive: Path | None,
) -> tuple[str | None, Path, Path, Path]:
    if dataset:
        if taxonomy_file is not None or msa_archive is not None or markers_archive is not None:
            raise ValueError("Use either --dataset or the explicit --taxonomy-file/--msa-archive/--markers-archive inputs.")
        record = resolve_dataset_record(str(dataset), gtdb_release=gtdb_release, dataset_type="gtdb")
        try:
            resolved_taxonomy = Path(record.files["taxonomy"].managed_path)
            resolved_msa = Path(record.files["msa"].managed_path)
            resolved_markers = Path(record.files["markers"].managed_path)
        except KeyError as exc:
            raise ValueError(f"Dataset '{dataset}' does not include the required taxonomy, msa, and markers files.") from exc
        return record.key, resolved_taxonomy, resolved_msa, resolved_markers

    if taxonomy_file is None or msa_archive is None or markers_archive is None:
        raise ValueError("Provide --dataset or all of --taxonomy-file, --msa-archive, and --markers-archive.")
    return (
        None,
        Path(taxonomy_file).expanduser().resolve(),
        Path(msa_archive).expanduser().resolve(),
        Path(markers_archive).expanduser().resolve(),
    )


def _run_regions_discover(
    *,
    dataset: str | None,
    gtdb_release: str | None,
    taxonomy_file: Path | None,
    msa_archive: Path | None,
    markers_archive: Path | None,
    output_dir: Path | None,
    session_name: str | None,
    input_session_name: str | None,
    input_attempt: str | None,
    discovery_profile: str,
    window_aa_length: int | None,
    window_aa_length_min: int | None,
    window_aa_length_max: int | None,
    top_regions_per_marker: int | None,
    include: Sequence[str] | None,
    exclude: Sequence[str] | None,
    min_target_column_occupancy: float | None,
    min_target_consensus: float | None,
    min_target_window_presence: float | None,
    max_aa_mismatches: int | None,
    aa_mismatch_penalty_per_mismatch: float | None,
    region_probe_length: int | None,
    min_target_remap_fraction: float | None,
    min_best_probe_support_fraction: float | None,
    probeability_weight: float | None,
    workers: int,
    report_format: OutputFormat | str,
    no_color: bool = False,
) -> int:
    resolved_dataset, resolved_taxonomy, resolved_msa, resolved_markers = _resolve_region_discovery_inputs(
        dataset=dataset,
        gtdb_release=gtdb_release,
        taxonomy_file=taxonomy_file,
        msa_archive=msa_archive,
        markers_archive=markers_archive,
    )
    input_ref = _resolve_stage_input_attempt(
        stage="targets",
        output_dir=output_dir,
        session_name=session_name,
        input_session_name=input_session_name,
        input_attempt=input_attempt,
    )
    output_ref = _resolve_stage_output_attempt(
        stage="regions",
        output_dir=output_dir,
        session_name=session_name,
    )
    resolved_include_taxa = parse_tag_taxon_constraints(
        include,
        GTDB_RANKS,
        option_name="--include",
    )
    resolved_exclude_taxa = parse_tag_taxon_constraints(
        exclude,
        GTDB_RANKS,
        option_name="--exclude",
    )

    progress_context = _RegionDiscoveryProgressReporter(not _is_json_output(report_format))
    with progress_context as reporter:
        result = discover_regions(
            dataset=resolved_dataset,
            taxonomy_file=resolved_taxonomy,
            msa_archive=resolved_msa,
            markers_archive=resolved_markers,
            target_discovery_prefix=input_ref.prefix,
            discovery_profile=discovery_profile,
            window_aa_length=window_aa_length,
            window_aa_length_min=window_aa_length_min,
            window_aa_length_max=window_aa_length_max,
            top_regions_per_marker=top_regions_per_marker,
            include_taxa=resolved_include_taxa,
            exclude_taxa=resolved_exclude_taxa,
            min_target_column_occupancy=min_target_column_occupancy,
            min_target_consensus=min_target_consensus,
            min_target_window_presence=min_target_window_presence,
            max_aa_mismatches=max_aa_mismatches,
            aa_mismatch_penalty_per_mismatch=aa_mismatch_penalty_per_mismatch,
            region_probe_length=region_probe_length,
            min_target_remap_fraction=min_target_remap_fraction,
            min_best_probe_support_fraction=min_best_probe_support_fraction,
            probeability_weight=probeability_weight,
            workers=workers,
            progress_callback=reporter.callback,
        )
    output_paths = write_region_discovery_outputs(result, output_ref.prefix)
    _record_stage_attempt(
        output_ref,
        summary=result.to_summary_dict(),
        output_files={name: str(path) for name, path in output_paths.items()},
        upstream_ref=input_ref,
    )

    if _is_json_output(report_format):
        _json_dump(result.to_summary_dict())
        return 0

    renderable = _regions_discover_renderable(result, output_ref.prefix)
    text = _regions_discover_text(result, output_ref.prefix)
    _print_renderable_or_text(renderable, text, no_color=no_color)
    return 0


def _resolve_probe_design_inputs(
    *,
    dataset: str | None,
    gtdb_release: str | None,
    taxonomy_file: Path | None,
    markers_archive: Path | None,
) -> tuple[str | None, Path, Path]:
    if dataset:
        if taxonomy_file is not None or markers_archive is not None:
            raise ValueError("Use either --dataset or the explicit --taxonomy-file/--markers-archive pair.")
        record = resolve_dataset_record(str(dataset), gtdb_release=gtdb_release, dataset_type="gtdb")
        try:
            resolved_taxonomy = Path(record.files["taxonomy"].managed_path)
            resolved_markers = Path(record.files["markers"].managed_path)
        except KeyError as exc:
            raise ValueError(f"Dataset '{dataset}' does not include the required taxonomy and markers files.") from exc
        return record.key, resolved_taxonomy, resolved_markers

    if taxonomy_file is None or markers_archive is None:
        raise ValueError("Provide --dataset or both --taxonomy-file and --markers-archive.")
    return (
        None,
        Path(taxonomy_file).expanduser().resolve(),
        Path(markers_archive).expanduser().resolve(),
    )


def _run_probes_design(
    *,
    dataset: str | None,
    gtdb_release: str | None,
    taxonomy_file: Path | None,
    markers_archive: Path | None,
    output_dir: Path | None,
    session_name: str | None,
    input_session_name: str | None,
    input_attempt: str | None,
    probe_length: int,
    top_probes_per_region: int,
    include: Sequence[str] | None,
    exclude: Sequence[str] | None,
    min_gc: float,
    max_gc: float,
    min_tm: float,
    max_tm: float,
    max_homopolymer: int,
    scoring_profile: str,
    thermo_backend: str,
    monovalent_salt_mM: float,
    divalent_salt_mM: float,
    dntp_mM: float,
    probe_conc_nM: float,
    hyb_temp_c: float,
    max_dinucleotide_run: int | None,
    min_sequence_entropy: float | None,
    max_self_complementarity: int | None,
    max_contiguous_self_complementarity: int | None,
    max_hairpin_tm: float | None,
    max_homodimer_tm: float | None,
    region_score_weight: float | None,
    thermo_penalty_weight: float | None,
    max_mismatches: int,
    mismatch_penalty_per_mismatch: float,
    sibling_penalty_weight: float,
    global_penalty_weight: float,
    workers: int,
    report_format: OutputFormat | str,
    no_color: bool = False,
) -> int:
    resolved_dataset, resolved_taxonomy, resolved_markers = _resolve_probe_design_inputs(
        dataset=dataset,
        gtdb_release=gtdb_release,
        taxonomy_file=taxonomy_file,
        markers_archive=markers_archive,
    )
    input_ref = _resolve_stage_input_attempt(
        stage="regions",
        output_dir=output_dir,
        session_name=session_name,
        input_session_name=input_session_name,
        input_attempt=input_attempt,
    )
    output_ref = _resolve_stage_output_attempt(
        stage="probes",
        output_dir=output_dir,
        session_name=session_name,
    )
    resolved_include_taxa = parse_tag_taxon_constraints(
        include,
        GTDB_RANKS,
        option_name="--include",
    )
    resolved_exclude_taxa = parse_tag_taxon_constraints(
        exclude,
        GTDB_RANKS,
        option_name="--exclude",
    )

    progress_context = _ProbeDesignProgressReporter(not _is_json_output(report_format))
    with progress_context as reporter:
        result = design_probes(
            dataset=resolved_dataset,
            taxonomy_file=resolved_taxonomy,
            markers_archive=resolved_markers,
            region_discovery_prefix=input_ref.prefix,
            include_taxa=resolved_include_taxa,
            exclude_taxa=resolved_exclude_taxa,
            probe_length=probe_length,
            top_probes_per_region=top_probes_per_region,
            min_gc=min_gc,
            max_gc=max_gc,
            min_tm=min_tm,
            max_tm=max_tm,
            max_homopolymer=max_homopolymer,
            scoring_profile=scoring_profile,
            thermo_backend=thermo_backend,
            monovalent_salt_mM=monovalent_salt_mM,
            divalent_salt_mM=divalent_salt_mM,
            dntp_mM=dntp_mM,
            probe_conc_nM=probe_conc_nM,
            hyb_temp_c=hyb_temp_c,
            max_dinucleotide_run=max_dinucleotide_run,
            min_sequence_entropy=min_sequence_entropy,
            max_self_complementarity=max_self_complementarity,
            max_contiguous_self_complementarity=max_contiguous_self_complementarity,
            max_hairpin_tm=max_hairpin_tm,
            max_homodimer_tm=max_homodimer_tm,
            region_score_weight=region_score_weight,
            thermo_penalty_weight=thermo_penalty_weight,
            max_mismatches=max_mismatches,
            mismatch_penalty_per_mismatch=mismatch_penalty_per_mismatch,
            sibling_penalty_weight=sibling_penalty_weight,
            global_penalty_weight=global_penalty_weight,
            workers=workers,
            progress_callback=reporter.callback,
        )
    output_paths = write_probe_design_outputs(result, output_ref.prefix)
    _record_stage_attempt(
        output_ref,
        summary=result.to_summary_dict(),
        output_files={name: str(path) for name, path in output_paths.items()},
        upstream_ref=input_ref,
    )

    if _is_json_output(report_format):
        _json_dump(result.to_summary_dict())
        return 0

    renderable = _probes_design_renderable(result, output_ref.prefix)
    text = _probes_design_text(result, output_ref.prefix)
    _print_renderable_or_text(renderable, text, no_color=no_color)
    return 0


def _resolve_panel_design_inputs(
    *,
    dataset: str | None,
    gtdb_release: str | None,
    taxonomy_file: Path | None,
    markers_archive: Path | None,
) -> tuple[str | None, Path, Path]:
    if dataset:
        if taxonomy_file is not None or markers_archive is not None:
            raise ValueError("Use either --dataset or the explicit --taxonomy-file/--markers-archive pair.")
        record = resolve_dataset_record(str(dataset), gtdb_release=gtdb_release, dataset_type="gtdb")
        try:
            resolved_taxonomy = Path(record.files["taxonomy"].managed_path)
            resolved_markers = Path(record.files["markers"].managed_path)
        except KeyError as exc:
            raise ValueError(f"Dataset '{dataset}' does not include the required taxonomy and markers files.") from exc
        return record.key, resolved_taxonomy, resolved_markers

    if taxonomy_file is None or markers_archive is None:
        raise ValueError("Provide --dataset or both --taxonomy-file and --markers-archive.")
    return None, Path(taxonomy_file).expanduser().resolve(), Path(markers_archive).expanduser().resolve()


def _resolve_panel_index_inputs(
    *,
    index_dataset: Sequence[str] | str | None,
    index_file: Sequence[Path] | Path | None,
    index_reference_map: Sequence[Path] | Path | None,
    index_summary: Sequence[Path] | Path | None,
) -> tuple[list[str], list[Path], list[Path], list[Path]]:
    dataset_values = [str(value) for value in _normalize_option_sequence(index_dataset)]
    index_files = [Path(value).expanduser().resolve() for value in _normalize_option_sequence(index_file)]
    reference_maps = [Path(value).expanduser().resolve() for value in _normalize_option_sequence(index_reference_map)]
    summaries = [Path(value).expanduser().resolve() for value in _normalize_option_sequence(index_summary)]

    if dataset_values:
        if index_files or reference_maps or summaries:
            raise ValueError(
                "Use either --index-dataset entries or the explicit --index-file/--index-reference-map/--index-summary inputs."
            )
        records = load_registry()
        resolved_indices: list[Path] = []
        resolved_reference_maps: list[Path] = []
        resolved_summaries: list[Path] = []
        for dataset_name in dataset_values:
            try:
                record = records[dataset_name]
            except KeyError as exc:
                raise ValueError(f"Index dataset not found: {dataset_name}") from exc
            if record.dataset_type != "fulgor_index":
                raise ValueError(f"Dataset '{dataset_name}' is not a Fulgor index dataset.")
            try:
                resolved_index = Path(record.files["index"].managed_path)
                resolved_reference_map = Path(record.files["reference_map"].managed_path)
                resolved_summary = Path(record.files["summary"].managed_path)
            except KeyError as exc:
                raise ValueError(
                    f"Index dataset '{dataset_name}' does not include the required index, reference_map, and summary files."
                ) from exc
            load_index_summary(resolved_summary)
            resolved_indices.append(resolved_index)
            resolved_reference_maps.append(resolved_reference_map)
            resolved_summaries.append(resolved_summary)
        return dataset_values, resolved_indices, resolved_reference_maps, resolved_summaries

    if index_files or reference_maps or summaries:
        if not index_files or not reference_maps or not summaries:
            raise ValueError(
                "Provide all of --index-file, --index-reference-map, and --index-summary, or omit them all."
            )
        if not (len(index_files) == len(reference_maps) == len(summaries)):
            raise ValueError(
                "Provide the same number of --index-file, --index-reference-map, and --index-summary values."
            )
        for resolved_summary in summaries:
            load_index_summary(resolved_summary)
        return [], index_files, reference_maps, summaries

    return [], [], [], []


def _run_panels_design(
    *,
    dataset: str | None,
    gtdb_release: str | None,
    taxonomy_file: Path | None,
    markers_archive: Path | None,
    index_dataset: Sequence[str] | str | None,
    index_file: Sequence[Path] | Path | None,
    index_reference_map: Sequence[Path] | Path | None,
    index_summary: Sequence[Path] | Path | None,
    fulgor_bin: str,
    index_threads: int,
    output_dir: Path | None,
    session_name: str | None,
    input_session_name: str | None,
    input_attempt: str | None,
    max_probes_per_panel: int,
    max_probes_per_marker: int,
    max_probes_per_region: int,
    allow_overlaps: bool,
    include: Sequence[str] | None,
    exclude: Sequence[str] | None,
    base_score_weight: float,
    genome_index_penalty_weight: float,
    scoring_profile: str,
    interaction_backend: str,
    monovalent_salt_mM: float,
    divalent_salt_mM: float,
    dntp_mM: float,
    probe_conc_nM: float,
    hyb_temp_c: float,
    max_panel_contiguous_complementarity: int | None,
    max_panel_heterodimer_tm: float | None,
    panel_complementarity_penalty_weight: float | None,
    panel_heterodimer_penalty_weight: float | None,
    max_mismatches: int,
    mismatch_penalty_per_mismatch: float,
    workers: int,
    report_format: OutputFormat | str,
    no_color: bool = False,
) -> int:
    resolved_dataset, resolved_taxonomy, resolved_markers = _resolve_panel_design_inputs(
        dataset=dataset,
        gtdb_release=gtdb_release,
        taxonomy_file=taxonomy_file,
        markers_archive=markers_archive,
    )
    (
        resolved_index_datasets,
        resolved_index_files,
        resolved_index_reference_maps,
        resolved_index_summaries,
    ) = _resolve_panel_index_inputs(
        index_dataset=index_dataset,
        index_file=index_file,
        index_reference_map=index_reference_map,
        index_summary=index_summary,
    )
    input_ref = _resolve_stage_input_attempt(
        stage="probes",
        output_dir=output_dir,
        session_name=session_name,
        input_session_name=input_session_name,
        input_attempt=input_attempt,
    )
    output_ref = _resolve_stage_output_attempt(
        stage="panels",
        output_dir=output_dir,
        session_name=session_name,
    )
    resolved_include_taxa = parse_tag_taxon_constraints(
        include,
        GTDB_RANKS,
        option_name="--include",
    )
    resolved_exclude_taxa = parse_tag_taxon_constraints(
        exclude,
        GTDB_RANKS,
        option_name="--exclude",
    )

    progress_context = _PanelDesignProgressReporter(not _is_json_output(report_format))
    with progress_context as reporter:
        result = design_panels(
            dataset=resolved_dataset,
            index_datasets=resolved_index_datasets,
            taxonomy_file=resolved_taxonomy,
            markers_archive=resolved_markers,
            probe_design_prefix=input_ref.prefix,
            index_files=resolved_index_files,
            index_reference_map_files=resolved_index_reference_maps,
            index_summary_files=resolved_index_summaries,
            include_taxa=resolved_include_taxa,
            exclude_taxa=resolved_exclude_taxa,
            fulgor_binary=fulgor_bin,
            index_threads=index_threads,
            max_probes_per_panel=max_probes_per_panel,
            max_probes_per_marker=max_probes_per_marker,
            max_probes_per_region=max_probes_per_region,
            allow_overlaps=allow_overlaps,
            base_score_weight=base_score_weight,
            genome_index_penalty_weight=genome_index_penalty_weight,
            scoring_profile=scoring_profile,
            interaction_backend=interaction_backend,
            monovalent_salt_mM=monovalent_salt_mM,
            divalent_salt_mM=divalent_salt_mM,
            dntp_mM=dntp_mM,
            probe_conc_nM=probe_conc_nM,
            hyb_temp_c=hyb_temp_c,
            max_panel_contiguous_complementarity=max_panel_contiguous_complementarity,
            max_panel_heterodimer_tm=max_panel_heterodimer_tm,
            panel_complementarity_penalty_weight=panel_complementarity_penalty_weight,
            panel_heterodimer_penalty_weight=panel_heterodimer_penalty_weight,
            max_mismatches=max_mismatches,
            mismatch_penalty_per_mismatch=mismatch_penalty_per_mismatch,
            workers=workers,
            progress_callback=reporter.callback,
        )
    output_paths = write_panel_design_outputs(result, output_ref.prefix)
    _record_stage_attempt(
        output_ref,
        summary=result.to_summary_dict(),
        output_files={name: str(path) for name, path in output_paths.items()},
        upstream_ref=input_ref,
    )

    if _is_json_output(report_format):
        _json_dump(result.to_summary_dict())
        return 0

    renderable = _panels_design_renderable(result, output_ref.prefix)
    text = _panels_design_text(result, output_ref.prefix)
    _print_renderable_or_text(renderable, text, no_color=no_color)
    return 0


if typer is not None:
    class RootHeaderGroup(TyperGroup):
        def format_help(self, ctx, formatter) -> None:
            if HAS_RICH and self.rich_markup_mode is not None:
                from typer import rich_utils

                console = rich_utils._get_rich_console()
                _print_root_header(console, include_description=False)
                console.print()
                return rich_utils.rich_format_help(
                    obj=self,
                    ctx=ctx,
                    markup_mode=self.rich_markup_mode,
                )

            formatter.write(_render_root_header_text(include_description=False))
            formatter.write("\n\n")
            return super().format_help(ctx, formatter)


    app = typer.Typer(
        cls=RootHeaderGroup,
        help=ROOT_DESCRIPTION,
        no_args_is_help=False,
        add_completion=False,
    )

    if HAS_RICH:
        from typer import rich_utils

        _ORIGINAL_RICH_FORMAT_ERROR = rich_utils.rich_format_error

        def _rich_format_error_with_root_header(self) -> None:
            ctx = getattr(self, "ctx", None)
            if ctx is not None and isinstance(ctx.find_root().command, RootHeaderGroup):
                _print_root_header(Console(stderr=True))
                Console(stderr=True).print()
            _ORIGINAL_RICH_FORMAT_ERROR(self)

        rich_utils.rich_format_error = _rich_format_error_with_root_header


    def _version_callback(value: bool) -> None:
        if value:
            typer.echo(__version__)
            raise typer.Exit()


    @app.callback(invoke_without_command=True)
    def root(
        ctx: typer.Context,
        version: bool = typer.Option(
            False,
            "--version",
            callback=_version_callback,
            is_eager=True,
            help="Show PhyloProbe version and exit.",
        ),
    ) -> None:
        if ctx.invoked_subcommand is None:
            _print_root_overview()
            raise typer.Exit()


    @app.command("datasets")
    def datasets_command(
        taxon: str = typer.Option(
            "all",
            "--taxon",
            help="Install all datasets by default, or restrict to one major taxon.",
        ),
        catalog_file: Path = typer.Option(
            default_catalog_path(),
            "--catalog-file",
            help="Path to the GTDB dataset catalog JSON.",
        ),
        gtdb_release: str | None = typer.Option(
            None,
            "--gtdb-release",
            help="GTDB release to install from the catalog, for example r226 or r220. Defaults to the catalog's default release.",
        ),
        datasets_dir: Path | None = typer.Option(
            None,
            "--datasets-dir",
            help="Directory where downloaded datasets should be stored.",
        ),
        force: bool = typer.Option(
            False,
            "--force",
            help="Reinstall selected datasets even if already present.",
        ),
        format: OutputFormat = typer.Option(
            OutputFormat.text,
            "--format",
            help="Output format for the installation report.",
        ),
        no_color: bool = typer.Option(
            False,
            "--no-color",
            help="Disable ANSI colors in text output.",
        ),
    ) -> None:
        try:
            _run_datasets_install(
                taxon=taxon,
                catalog_file=catalog_file,
                gtdb_release=gtdb_release,
                datasets_dir=datasets_dir,
                report_format=format,
                force=force,
                no_color=no_color,
            )
        except ValueError as exc:
            raise PhyloprobeClickException(str(exc)) from exc


    @app.command("datasets-list")
    def datasets_list_command(
        format: OutputFormat = typer.Option(
            OutputFormat.text,
            "--format",
            help="Output format for the dataset report.",
        ),
        no_color: bool = typer.Option(
            False,
            "--no-color",
            help="Disable ANSI colors in text output.",
        ),
    ) -> None:
        _run_datasets_list(report_format=format, no_color=no_color)


    @app.command("datasets-show")
    def datasets_show_command(
        name: str = typer.Option(..., "--name", help="Installed dataset name."),
        gtdb_release: str | None = typer.Option(
            None,
            "--gtdb-release",
            help="GTDB release to resolve when --name is a logical dataset name such as archaea or bacteria.",
        ),
        format: OutputFormat = typer.Option(
            OutputFormat.text,
            "--format",
            help="Output format for the dataset report.",
        ),
        no_color: bool = typer.Option(
            False,
            "--no-color",
            help="Disable ANSI colors in text output.",
        ),
    ) -> None:
        try:
            _run_datasets_show(name=name, gtdb_release=gtdb_release, report_format=format, no_color=no_color)
        except ValueError as exc:
            raise PhyloprobeClickException(str(exc)) from exc


    @app.command("taxonomy")
    def taxonomy_command(
        taxonomy_file: Path | None = typer.Option(
            None,
            "--taxonomy-file",
            exists=True,
            dir_okay=False,
            readable=True,
            help="Path to a GTDB taxonomy TSV.",
        ),
        dataset: str | None = typer.Option(
            None,
            "--dataset",
            help="Installed dataset name.",
        ),
        gtdb_release: str | None = typer.Option(
            None,
            "--gtdb-release",
            help="GTDB release to resolve when --dataset is a logical dataset name such as archaea or bacteria.",
        ),
        format: OutputFormat = typer.Option(
            OutputFormat.text,
            "--format",
            help="Output format for the taxonomy summary.",
        ),
        no_color: bool = typer.Option(
            False,
            "--no-color",
            help="Disable ANSI colors in text output.",
        ),
    ) -> None:
        try:
            _run_taxonomy_summarize(
                taxonomy_file=taxonomy_file,
                dataset=dataset,
                gtdb_release=gtdb_release,
                report_format=format,
                no_color=no_color,
            )
        except ValueError as exc:
            raise PhyloprobeClickException(str(exc)) from exc


    @app.command("index")
    def index_command(
        genome_archive: Path | None = typer.Option(
            None,
            "--genome-archive",
            exists=True,
            dir_okay=False,
            readable=True,
            help="Path to a tar archive of genomes used for Fulgor indexing.",
        ),
        genome_file: list[Path] = typer.Option(
            None,
            "--genome-file",
            exists=True,
            dir_okay=False,
            readable=True,
            help="Path to a genome FASTA file. Repeat --genome-file to index a custom genome set.",
        ),
        output_prefix: Path = typer.Option(
            Path("outputs/genome_index"),
            "--output-prefix",
            help="Prefix used for the written index artifacts.",
        ),
        fulgor_bin: str = typer.Option(
            "fulgor",
            "--fulgor-bin",
            help="Path to the Fulgor executable.",
        ),
        kmer_length: int = typer.Option(
            DEFAULT_KMER_LENGTH,
            "--kmer-length",
            min=1,
            help="K-mer length for Fulgor indexing.",
        ),
        minimizer_length: int = typer.Option(
            DEFAULT_MINIMIZER_LENGTH,
            "--minimizer-length",
            min=1,
            help="Minimizer length for Fulgor indexing.",
        ),
        threads: int = typer.Option(
            DEFAULT_FULGOR_THREADS,
            "--threads",
            min=1,
            help="Fulgor build threads.",
        ),
        ggcat_threads: int = typer.Option(
            DEFAULT_GGCAT_THREADS,
            "--ggcat-threads",
            min=1,
            help="Threads passed to the GGCAT phase of Fulgor build.",
        ),
        tmp_dir: Path | None = typer.Option(
            None,
            "--tmp-dir",
            help="Optional temporary directory for extracted genomes and Fulgor scratch files.",
        ),
        keep_extracted: bool = typer.Option(
            False,
            "--keep-extracted",
            help="Keep extracted genome FASTA files under --tmp-dir after the index is built.",
        ),
        check: bool = typer.Option(
            True,
            "--check/--no-check",
            help="Enable or disable Fulgor's post-build consistency checks.",
        ),
        taxon: str | None = typer.Option(
            None,
            "--taxon",
            help="Optional taxon label stored in the build summary.",
        ),
        release: str | None = typer.Option(
            None,
            "--release",
            help="Optional GTDB release label stored in the build summary.",
        ),
        format: OutputFormat = typer.Option(
            OutputFormat.text,
            "--format",
            help="Output format for the index-build summary.",
        ),
        no_color: bool = typer.Option(
            False,
            "--no-color",
            help="Disable ANSI colors in text output.",
        ),
    ) -> None:
        try:
            _run_index_build(
                genome_archive=genome_archive,
                genome_files=genome_file,
                output_prefix=output_prefix,
                fulgor_bin=fulgor_bin,
                kmer_length=kmer_length,
                minimizer_length=minimizer_length,
                threads=threads,
                ggcat_threads=ggcat_threads,
                tmp_dir=tmp_dir,
                keep_extracted=keep_extracted,
                check=check,
                taxon=taxon,
                release=release,
                report_format=format,
                no_color=no_color,
            )
        except ValueError as exc:
            raise PhyloprobeClickException(str(exc)) from exc


    @app.command("tags")
    def tags_command(
        taxonomy_file: Path | None = typer.Option(
            None,
            "--taxonomy-file",
            exists=True,
            dir_okay=False,
            readable=True,
            help="Path to a GTDB taxonomy TSV or TSV.GZ file.",
        ),
        dataset: str | None = typer.Option(
            None,
            "--dataset",
            help="Installed dataset name to use as the taxonomy source.",
        ),
        gtdb_release: str | None = typer.Option(
            None,
            "--gtdb-release",
            help="GTDB release to resolve when --dataset is a logical dataset name such as archaea or bacteria.",
        ),
        output_dir: Path = typer.Option(
            ...,
            "--output",
            file_okay=False,
            help="Parent directory for a session-organized run layout.",
        ),
        session_name: str = typer.Option(
            ...,
            "--session",
            help="Session identifier used to create the run folder and numbered stage-attempt subdirectories. Letters, digits, and underscores only.",
        ),
        positions: int = typer.Option(
            4,
            "--positions",
            min=1,
            help="Total barcode positions available for tag allocation.",
        ),
        alphabet: str = typer.Option(
            ",".join(DEFAULT_TAG_ALPHABET),
            "--alphabet",
            help="Comma-separated one-character barcode alphabet, for example A,T,G,C or [0,1]. Symbols must be unique single letters or digits.",
        ),
        levels: str = typer.Option(
            ",".join(DEFAULT_TAG_LEVELS),
            "--levels",
            help="Comma-separated taxonomy levels in hierarchical order.",
        ),
        maximise_levels: str = typer.Option(
            "all",
            "--maximise-levels",
            "--maximize-levels",
            help="Comma-separated levels to prioritize, or 'all'.",
        ),
        level_weights: str | None = typer.Option(
            None,
            "--level-weights",
            help="Optional numeric objective weights such as phylum:2,genus:0.5 or all:1. Overrides equal weighting from --maximise-levels.",
        ),
        min_taxa_per_level: str | None = typer.Option(
            None,
            "--min-taxa-per-level",
            help="Optional hard minima, for example family:20,genus:50.",
        ),
        exclusive: list[str] | None = typer.Option(
            None,
            "--exclusive",
            help="Restrict preprocessing to specific taxa and their descendants, using repeated options or comma-separated level:taxon items.",
        ),
        include: list[str] | None = typer.Option(
            None,
            "--include",
            help="Force presence of specific taxa using repeated options or comma-separated level:taxon items.",
        ),
        exclude: list[str] | None = typer.Option(
            None,
            "--exclude",
            help="Remove specific taxa before optimization using repeated options or comma-separated level:taxon items.",
        ),
        prefer: list[str] | None = typer.Option(
            None,
            "--prefer",
            help="Softly prefer specific taxa using repeated options or comma-separated level:taxon items.",
        ),
        avoid: list[str] | None = typer.Option(
            None,
            "--avoid",
            help="Softly avoid specific taxa using repeated options or comma-separated level:taxon items.",
        ),
        descendants: list[str] | None = typer.Option(
            None,
            "--descendants",
            help="Softly prefer taxa whose branch contains at least N taxa at the next configured level, using level:count items such as order:4.",
        ),
        descendants_hard: list[str] | None = typer.Option(
            None,
            "--descendants-hard",
            help="Require taxa to contain at least N taxa at the next configured level, using level:count items such as order:4.",
        ),
        fallbacks_per_target: int = typer.Option(
            1,
            "--fallbacks-per-target",
            min=0,
            help="Number of same-rank fallback taxa to record per selected barcode for later rescue in target discovery. Use 0 to disable reserve targets.",
        ),
        util_weight: float = typer.Option(
            0.15,
            "--util-weight",
            min=0.0,
            help="Weight for overall tag-space utilization in the objective.",
        ),
        format: OutputFormat = typer.Option(
            OutputFormat.text,
            "--format",
            help="Output format for the tag-design summary.",
        ),
        no_color: bool = typer.Option(
            False,
            "--no-color",
            help="Disable ANSI colors in text output.",
        ),
    ) -> None:
        try:
            _run_tags_design(
                taxonomy_file=taxonomy_file,
                dataset=dataset,
                gtdb_release=gtdb_release,
                output_dir=output_dir,
                session_name=session_name,
                positions=positions,
                alphabet=alphabet,
                levels=levels,
                maximise_levels=maximise_levels,
                level_weights=level_weights,
                min_taxa_per_level=min_taxa_per_level,
                exclusive=exclusive,
                include=include,
                exclude=exclude,
                prefer=prefer,
                avoid=avoid,
                descendants=descendants,
                descendants_hard=descendants_hard,
                fallbacks_per_target=fallbacks_per_target,
                util_weight=util_weight,
                report_format=format,
                no_color=no_color,
            )
        except ValueError as exc:
            raise PhyloprobeClickException(str(exc)) from exc


    @app.command("targets")
    def targets_command(
        dataset: str | None = typer.Option(
            None,
            "--dataset",
            help="Installed dataset name to use for taxonomy and marker files.",
        ),
        gtdb_release: str | None = typer.Option(
            None,
            "--gtdb-release",
            help="GTDB release to resolve when --dataset is a logical dataset name such as archaea or bacteria.",
        ),
        taxonomy_file: Path | None = typer.Option(
            None,
            "--taxonomy-file",
            exists=True,
            dir_okay=False,
            readable=True,
            help="Path to a GTDB taxonomy TSV or TSV.GZ file.",
        ),
        markers_archive: Path | None = typer.Option(
            None,
            "--markers-archive",
            exists=True,
            dir_okay=False,
            readable=True,
            help="Path to the GTDB marker-gene tar archive.",
        ),
        output_dir: Path = typer.Option(
            ...,
            "--output",
            file_okay=False,
            help="Parent directory for a session-organized run layout.",
        ),
        session_name: str = typer.Option(
            ...,
            "--session",
            help="Session identifier used to create the run folder and numbered stage-attempt subdirectories. Letters, digits, and underscores only.",
        ),
        input_session_name: str | None = typer.Option(
            None,
            "--input-session",
            help="Optional source session to read upstream stage outputs from. Defaults to --session.",
        ),
        input_attempt: str | None = typer.Option(
            None,
            "--input-attempt",
            help="Optional upstream attempt number to read from. Defaults to the active attempt recorded in the upstream stage manifest.",
        ),
        profile: str = typer.Option(
            DEFAULT_SELECTION_PROFILE,
            "--profile",
            help="Target discovery profile: custom, fast, balanced, or strict.",
        ),
        top_markers_per_target: int | None = typer.Option(
            None,
            "--top-markers-per-target",
            min=1,
            help="Number of top-ranked markers to keep per target in the manifest. Defaults depend on --profile.",
        ),
        fallback_policy: str = typer.Option(
            DEFAULT_FALLBACK_POLICY,
            "--fallback-policy",
            help="When to promote fallback taxa from tag design. One of: none, no_marker_genomes, single_marker_genome, missing_or_single.",
        ),
        include: list[str] | None = typer.Option(
            None,
            "--include",
            help="Restrict the target-analysis taxonomy scope to matching taxa, using repeated options or comma-separated level:taxon items.",
        ),
        exclude: list[str] | None = typer.Option(
            None,
            "--exclude",
            help="Remove taxa from the target-analysis taxonomy scope, using repeated options or comma-separated level:taxon items.",
        ),
        workers: int = typer.Option(
            DEFAULT_AUTO_WORKERS,
            "--workers",
            min=0,
            help=WORKERS_OPTION_HELP,
        ),
        format: OutputFormat = typer.Option(
            OutputFormat.text,
            "--format",
            help="Output format for the target-discovery summary.",
        ),
        no_color: bool = typer.Option(
            False,
            "--no-color",
            help="Disable ANSI colors in text output.",
        ),
    ) -> None:
        try:
            _run_targets_discover(
                dataset=dataset,
                gtdb_release=gtdb_release,
                taxonomy_file=taxonomy_file,
                markers_archive=markers_archive,
                output_dir=output_dir,
                session_name=session_name,
                input_session_name=input_session_name,
                input_attempt=input_attempt,
                selection_profile=profile,
                top_markers_per_target=top_markers_per_target,
                fallback_policy=fallback_policy,
                include=include,
                exclude=exclude,
                workers=workers,
                report_format=format,
                no_color=no_color,
            )
        except ValueError as exc:
            raise PhyloprobeClickException(str(exc)) from exc


    @app.command("regions")
    def regions_command(
        dataset: str | None = typer.Option(
            None,
            "--dataset",
            help="Installed dataset name to use for taxonomy and MSA files.",
        ),
        gtdb_release: str | None = typer.Option(
            None,
            "--gtdb-release",
            help="GTDB release to resolve when --dataset is a logical dataset name such as archaea or bacteria.",
        ),
        taxonomy_file: Path | None = typer.Option(
            None,
            "--taxonomy-file",
            exists=True,
            dir_okay=False,
            readable=True,
            help="Path to a GTDB taxonomy TSV or TSV.GZ file.",
        ),
        msa_archive: Path | None = typer.Option(
            None,
            "--msa-archive",
            exists=True,
            dir_okay=False,
            readable=True,
            help="Path to the GTDB aligned MSA tar archive.",
        ),
        markers_archive: Path | None = typer.Option(
            None,
            "--markers-archive",
            exists=True,
            dir_okay=False,
            readable=True,
            help="GTDB marker-gene tar archive used for early nucleotide remapping and probeability scoring.",
        ),
        output_dir: Path = typer.Option(
            ...,
            "--output",
            file_okay=False,
            help="Parent directory for a session-organized run layout.",
        ),
        session_name: str = typer.Option(
            ...,
            "--session",
            help="Session identifier used to create the run folder and numbered stage-attempt subdirectories. Letters, digits, and underscores only.",
        ),
        input_session_name: str | None = typer.Option(
            None,
            "--input-session",
            help="Optional source session to read upstream stage outputs from. Defaults to --session.",
        ),
        input_attempt: str | None = typer.Option(
            None,
            "--input-attempt",
            help="Optional upstream attempt number to read from. Defaults to the active attempt recorded in the upstream stage manifest.",
        ),
        profile: str = typer.Option(
            DEFAULT_DISCOVERY_PROFILE,
            "--profile",
            help="Region discovery profile: custom, fast, balanced, or strict.",
        ),
        window_aa_length: int | None = typer.Option(
            None,
            "--window-aa-length",
            min=1,
            help="Fixed aligned protein window length. When omitted, region discovery defaults to adaptive scanning across the default window-length range.",
        ),
        window_aa_length_min: int | None = typer.Option(
            None,
            "--window-aa-length-min",
            min=1,
            help="Minimum aligned protein window length to evaluate. Defaults depend on --profile, or to --window-aa-length when a fixed window is requested.",
        ),
        window_aa_length_max: int | None = typer.Option(
            None,
            "--window-aa-length-max",
            min=1,
            help="Maximum aligned protein window length to evaluate. Defaults depend on --profile, or to --window-aa-length when a fixed window is requested.",
        ),
        top_regions_per_marker: int | None = typer.Option(
            None,
            "--top-regions-per-marker",
            min=1,
            help="Maximum number of non-overlapping regions to keep per target-marker pair. Defaults depend on --profile.",
        ),
        include: list[str] | None = typer.Option(
            None,
            "--include",
            help="Restrict the region-analysis taxonomy scope to matching taxa, using repeated options or comma-separated level:taxon items.",
        ),
        exclude: list[str] | None = typer.Option(
            None,
            "--exclude",
            help="Remove taxa from the region-analysis taxonomy scope, using repeated options or comma-separated level:taxon items.",
        ),
        min_target_column_occupancy: float | None = typer.Option(
            None,
            "--min-target-column-occupancy",
            min=0.0,
            max=1.0,
            help="Minimum in-target non-gap fraction required in every column of a window. Defaults depend on --profile.",
        ),
        min_target_consensus: float | None = typer.Option(
            None,
            "--min-target-consensus",
            min=0.0,
            max=1.0,
            help="Minimum in-target amino-acid consensus required in every column of a window. Defaults depend on --profile.",
        ),
        min_target_window_presence: float | None = typer.Option(
            None,
            "--min-target-window-presence",
            min=0.0,
            max=1.0,
            help="Minimum fraction of target sequences that must span the whole gap-free window. Defaults depend on --profile.",
        ),
        max_aa_mismatches: int | None = typer.Option(
            None,
            "--max-aa-mismatches",
            min=0,
            help="Maximum amino-acid mismatches allowed when scoring near matches to the target consensus window. Defaults depend on --profile.",
        ),
        aa_mismatch_penalty_per_mismatch: float | None = typer.Option(
            None,
            "--aa-mismatch-penalty-per-mismatch",
            min=0.0,
            help="Penalty applied per amino-acid mismatch when mismatch-tolerant region scoring is enabled. Defaults depend on --profile.",
        ),
        region_probe_length: int | None = typer.Option(
            None,
            "--region-probe-length",
            min=1,
            help="Probe length used to estimate whether shortlisted amino-acid regions are likely to yield usable nucleotide probes. Defaults depend on --profile.",
        ),
        min_target_remap_fraction: float | None = typer.Option(
            None,
            "--min-target-remap-fraction",
            min=0.0,
            max=1.0,
            help="Minimum fraction of target aligned sequences that must remap cleanly into nucleotide marker windows. Defaults depend on --profile.",
        ),
        min_best_probe_support_fraction: float | None = typer.Option(
            None,
            "--min-best-probe-support-fraction",
            min=0.0,
            max=1.0,
            help="Minimum fraction of remapped target sequences that must share the strongest candidate probe subsequence within a region. Defaults depend on --profile.",
        ),
        probeability_weight: float | None = typer.Option(
            None,
            "--probeability-weight",
            min=0.0,
            help="Positive score weight applied to early nucleotide remapping and probeability estimates during region ranking. Defaults depend on --profile.",
        ),
        workers: int = typer.Option(
            DEFAULT_AUTO_WORKERS,
            "--workers",
            min=0,
            help=WORKERS_OPTION_HELP,
        ),
        format: OutputFormat = typer.Option(
            OutputFormat.text,
            "--format",
            help="Output format for the region-discovery summary.",
        ),
        no_color: bool = typer.Option(
            False,
            "--no-color",
            help="Disable ANSI colors in text output.",
        ),
    ) -> None:
        try:
            _run_regions_discover(
                dataset=dataset,
                gtdb_release=gtdb_release,
                taxonomy_file=taxonomy_file,
                msa_archive=msa_archive,
                markers_archive=markers_archive,
                output_dir=output_dir,
                session_name=session_name,
                input_session_name=input_session_name,
                input_attempt=input_attempt,
                discovery_profile=profile,
                window_aa_length=window_aa_length,
                window_aa_length_min=window_aa_length_min,
                window_aa_length_max=window_aa_length_max,
                top_regions_per_marker=top_regions_per_marker,
                include=include,
                exclude=exclude,
                min_target_column_occupancy=min_target_column_occupancy,
                min_target_consensus=min_target_consensus,
                min_target_window_presence=min_target_window_presence,
                max_aa_mismatches=max_aa_mismatches,
                aa_mismatch_penalty_per_mismatch=aa_mismatch_penalty_per_mismatch,
                region_probe_length=region_probe_length,
                min_target_remap_fraction=min_target_remap_fraction,
                min_best_probe_support_fraction=min_best_probe_support_fraction,
                probeability_weight=probeability_weight,
                workers=workers,
                report_format=format,
                no_color=no_color,
            )
        except ValueError as exc:
            raise PhyloprobeClickException(str(exc)) from exc


    @app.command("probes")
    def probes_command(
        dataset: str | None = typer.Option(
            None,
            "--dataset",
            help="Installed dataset name to use for taxonomy and marker files.",
        ),
        gtdb_release: str | None = typer.Option(
            None,
            "--gtdb-release",
            help="GTDB release to resolve when --dataset is a logical dataset name such as archaea or bacteria.",
        ),
        taxonomy_file: Path | None = typer.Option(
            None,
            "--taxonomy-file",
            exists=True,
            dir_okay=False,
            readable=True,
            help="Path to a GTDB taxonomy TSV or TSV.GZ file.",
        ),
        markers_archive: Path | None = typer.Option(
            None,
            "--markers-archive",
            exists=True,
            dir_okay=False,
            readable=True,
            help="Path to the GTDB marker-gene tar archive. Probe design uses the nucleotide remap manifest produced by `regions` plus these marker sequences.",
        ),
        output_dir: Path = typer.Option(
            ...,
            "--output",
            file_okay=False,
            help="Parent directory for a session-organized run layout.",
        ),
        session_name: str = typer.Option(
            ...,
            "--session",
            help="Session identifier used to create the run folder and numbered stage-attempt subdirectories. Letters, digits, and underscores only.",
        ),
        input_session_name: str | None = typer.Option(
            None,
            "--input-session",
            help="Optional source session to read upstream stage outputs from. Defaults to --session.",
        ),
        input_attempt: str | None = typer.Option(
            None,
            "--input-attempt",
            help="Optional upstream attempt number to read from. Defaults to the active attempt recorded in the upstream stage manifest.",
        ),
        probe_length: int = typer.Option(
            DEFAULT_PROBE_LENGTH,
            "--probe-length",
            min=1,
            help="Probe length in nucleotides.",
        ),
        top_probes_per_region: int = typer.Option(
            DEFAULT_TOP_PROBES_PER_REGION,
            "--top-probes-per-region",
            min=1,
            help="Maximum number of top probes to keep per region candidate.",
        ),
        include: list[str] | None = typer.Option(
            None,
            "--include",
            help="Restrict the probe-analysis taxonomy scope to matching taxa, using repeated options or comma-separated level:taxon items.",
        ),
        exclude: list[str] | None = typer.Option(
            None,
            "--exclude",
            help="Remove taxa from the probe-analysis taxonomy scope, using repeated options or comma-separated level:taxon items.",
        ),
        min_gc: float = typer.Option(
            DEFAULT_MIN_GC,
            "--min-gc",
            min=0.0,
            max=1.0,
            help="Minimum allowed GC fraction.",
        ),
        max_gc: float = typer.Option(
            DEFAULT_MAX_GC,
            "--max-gc",
            min=0.0,
            max=1.0,
            help="Maximum allowed GC fraction.",
        ),
        min_tm: float = typer.Option(
            DEFAULT_MIN_TM,
            "--min-tm",
            help="Minimum allowed basic melting temperature estimate.",
        ),
        max_tm: float = typer.Option(
            DEFAULT_MAX_TM,
            "--max-tm",
            help="Maximum allowed basic melting temperature estimate.",
        ),
        max_homopolymer: int = typer.Option(
            DEFAULT_MAX_HOMOPOLYMER,
            "--max-homopolymer",
            min=1,
            help="Maximum allowed homopolymer run length.",
        ),
        profile: str = typer.Option(
            DEFAULT_SCORING_PROFILE,
            "--profile",
            help="Probe design profile: custom, fast, balanced, or strict.",
        ),
        thermo_backend: str = typer.Option(
            DEFAULT_THERMO_BACKEND,
            "--thermo-backend",
            help="Thermodynamic backend: basic or primer3.",
        ),
        monovalent_salt_mM: float = typer.Option(
            DEFAULT_MONOVALENT_SALT_MM,
            "--monovalent-salt-mM",
            min=0.0,
            help="Monovalent salt concentration used for thermodynamic calculations.",
        ),
        divalent_salt_mM: float = typer.Option(
            DEFAULT_DIVALENT_SALT_MM,
            "--divalent-salt-mM",
            min=0.0,
            help="Divalent salt concentration used for thermodynamic calculations.",
        ),
        dntp_mM: float = typer.Option(
            DEFAULT_DNTP_MM,
            "--dntp-mM",
            min=0.0,
            help="dNTP concentration used for thermodynamic calculations.",
        ),
        probe_conc_nM: float = typer.Option(
            DEFAULT_PROBE_CONC_NM,
            "--probe-conc-nM",
            min=0.0,
            help="Probe concentration used for thermodynamic calculations.",
        ),
        hyb_temp_c: float = typer.Option(
            DEFAULT_HYB_TEMP_C,
            "--hyb-temp-c",
            help="Hybridization temperature used when evaluating structure formation.",
        ),
        max_dinucleotide_run: int | None = typer.Option(
            None,
            "--max-dinucleotide-run",
            min=1,
            help="Optional maximum allowed repeated dinucleotide run length.",
        ),
        min_sequence_entropy: float | None = typer.Option(
            None,
            "--min-sequence-entropy",
            min=0.0,
            max=1.0,
            help="Optional minimum normalized sequence entropy.",
        ),
        max_self_complementarity: int | None = typer.Option(
            None,
            "--max-self-complementarity",
            min=1,
            help="Optional maximum allowed self-complementarity score.",
        ),
        max_contiguous_self_complementarity: int | None = typer.Option(
            None,
            "--max-contiguous-self-complementarity",
            min=1,
            help="Optional maximum allowed contiguous self-complementarity score.",
        ),
        max_hairpin_tm: float | None = typer.Option(
            None,
            "--max-hairpin-tm",
            help="Optional maximum allowed hairpin melting temperature. Requires primer3 backend.",
        ),
        max_homodimer_tm: float | None = typer.Option(
            None,
            "--max-homodimer-tm",
            help="Optional maximum allowed homodimer melting temperature. Requires primer3 backend.",
        ),
        region_score_weight: float | None = typer.Option(
            None,
            "--region-score-weight",
            min=0.0,
            help="Weight applied to the upstream conserved-region score. Defaults depend on --profile.",
        ),
        thermo_penalty_weight: float | None = typer.Option(
            None,
            "--thermo-penalty-weight",
            min=0.0,
            help="Weight applied to thermodynamic penalties during probe scoring. Defaults depend on --profile.",
        ),
        max_mismatches: int = typer.Option(
            DEFAULT_MAX_MISMATCHES,
            "--max-mismatches",
            min=0,
            help="Maximum allowed mismatches when screening target and off-target matches in marker genes.",
        ),
        mismatch_penalty_per_mismatch: float = typer.Option(
            DEFAULT_MISMATCH_PENALTY_PER_MISMATCH,
            "--mismatch-penalty-per-mismatch",
            min=0.0,
            help="Penalty applied to per-sequence support for each mismatch within the allowed tolerance.",
        ),
        sibling_penalty_weight: float = typer.Option(
            DEFAULT_PROBE_SIBLING_PENALTY_WEIGHT,
            "--sibling-penalty-weight",
            min=0.0,
            help="Penalty weight applied to sibling-taxon off-target fractions.",
        ),
        global_penalty_weight: float = typer.Option(
            DEFAULT_PROBE_GLOBAL_PENALTY_WEIGHT,
            "--global-penalty-weight",
            min=0.0,
            help="Penalty weight applied to global off-target fractions.",
        ),
        workers: int = typer.Option(
            DEFAULT_AUTO_WORKERS,
            "--workers",
            min=0,
            help=WORKERS_OPTION_HELP,
        ),
        format: OutputFormat = typer.Option(
            OutputFormat.text,
            "--format",
            help="Output format for the probe-design summary.",
        ),
        no_color: bool = typer.Option(
            False,
            "--no-color",
            help="Disable ANSI colors in text output.",
        ),
    ) -> None:
        try:
            _run_probes_design(
                dataset=dataset,
                gtdb_release=gtdb_release,
                taxonomy_file=taxonomy_file,
                markers_archive=markers_archive,
                output_dir=output_dir,
                session_name=session_name,
                input_session_name=input_session_name,
                input_attempt=input_attempt,
                probe_length=probe_length,
                top_probes_per_region=top_probes_per_region,
                include=include,
                exclude=exclude,
                min_gc=min_gc,
                max_gc=max_gc,
                min_tm=min_tm,
                max_tm=max_tm,
                max_homopolymer=max_homopolymer,
                scoring_profile=profile,
                thermo_backend=thermo_backend,
                monovalent_salt_mM=monovalent_salt_mM,
                divalent_salt_mM=divalent_salt_mM,
                dntp_mM=dntp_mM,
                probe_conc_nM=probe_conc_nM,
                hyb_temp_c=hyb_temp_c,
                max_dinucleotide_run=max_dinucleotide_run,
                min_sequence_entropy=min_sequence_entropy,
                max_self_complementarity=max_self_complementarity,
                max_contiguous_self_complementarity=max_contiguous_self_complementarity,
                max_hairpin_tm=max_hairpin_tm,
                max_homodimer_tm=max_homodimer_tm,
                region_score_weight=region_score_weight,
                thermo_penalty_weight=thermo_penalty_weight,
                max_mismatches=max_mismatches,
                mismatch_penalty_per_mismatch=mismatch_penalty_per_mismatch,
                sibling_penalty_weight=sibling_penalty_weight,
                global_penalty_weight=global_penalty_weight,
                workers=workers,
                report_format=format,
                no_color=no_color,
            )
        except ValueError as exc:
            raise PhyloprobeClickException(str(exc)) from exc


    @app.command("panels")
    def panels_command(
        dataset: str | None = typer.Option(
            None,
            "--dataset",
            help="Installed dataset name to use for taxonomy and marker files.",
        ),
        gtdb_release: str | None = typer.Option(
            None,
            "--gtdb-release",
            help="GTDB release to resolve when --dataset is a logical dataset name such as archaea or bacteria.",
        ),
        taxonomy_file: Path | None = typer.Option(
            None,
            "--taxonomy-file",
            exists=True,
            dir_okay=False,
            readable=True,
            help="Path to a GTDB taxonomy TSV or TSV.GZ file.",
        ),
        markers_archive: Path | None = typer.Option(
            None,
            "--markers-archive",
            exists=True,
            dir_okay=False,
            readable=True,
            help="Path to the GTDB marker-gene tar archive.",
        ),
        index_dataset: list[str] = typer.Option(
            None,
            "--index-dataset",
            help="Installed Fulgor index dataset used for genome-wide off-target screening. Repeat to combine multiple indices.",
        ),
        index_file: list[Path] = typer.Option(
            None,
            "--index-file",
            exists=True,
            dir_okay=False,
            readable=True,
            help="Path to a Fulgor `.fur` index file. Repeat together with --index-reference-map and --index-summary.",
        ),
        index_reference_map: list[Path] = typer.Option(
            None,
            "--index-reference-map",
            exists=True,
            dir_okay=False,
            readable=True,
            help="Path to the CSV reference map produced by `phyloprobe index`. Repeat alongside --index-file.",
        ),
        index_summary: list[Path] = typer.Option(
            None,
            "--index-summary",
            exists=True,
            dir_okay=False,
            readable=True,
            help="Path to the JSON summary produced by `phyloprobe index`. Repeat alongside --index-file.",
        ),
        fulgor_bin: str = typer.Option(
            "fulgor",
            "--fulgor-bin",
            help="Path to the Fulgor executable used for genome-wide probe queries.",
        ),
        index_threads: int = typer.Option(
            DEFAULT_FULGOR_THREADS,
            "--index-threads",
            min=1,
            help="Threads used by Fulgor when querying the genome index.",
        ),
        output_dir: Path = typer.Option(
            ...,
            "--output",
            file_okay=False,
            help="Parent directory for a session-organized run layout.",
        ),
        session_name: str = typer.Option(
            ...,
            "--session",
            help="Session identifier used to create the run folder and numbered stage-attempt subdirectories. Letters, digits, and underscores only.",
        ),
        input_session_name: str | None = typer.Option(
            None,
            "--input-session",
            help="Optional source session to read upstream stage outputs from. Defaults to --session.",
        ),
        input_attempt: str | None = typer.Option(
            None,
            "--input-attempt",
            help="Optional upstream attempt number to read from. Defaults to the active attempt recorded in the upstream stage manifest.",
        ),
        max_probes_per_panel: int = typer.Option(
            DEFAULT_MAX_PROBES_PER_PANEL,
            "--max-probes-per-panel",
            min=1,
            help="Maximum number of probes to keep in each target panel.",
        ),
        max_probes_per_marker: int = typer.Option(
            DEFAULT_MAX_PROBES_PER_MARKER,
            "--max-probes-per-marker",
            min=1,
            help="Maximum number of selected probes allowed from a single marker.",
        ),
        max_probes_per_region: int = typer.Option(
            DEFAULT_MAX_PROBES_PER_REGION,
            "--max-probes-per-region",
            min=1,
            help="Maximum number of selected probes allowed from a single conserved region. Overlapping probes are still excluded unless --allow-overlaps is used.",
        ),
        allow_overlaps: bool = typer.Option(
            False,
            "--allow-overlaps",
            help="Allow overlapping probe intervals from the same marker locus to coexist within a panel.",
        ),
        include: list[str] | None = typer.Option(
            None,
            "--include",
            help="Restrict the panel-analysis taxonomy scope to matching taxa, using repeated options or comma-separated level:taxon items.",
        ),
        exclude: list[str] | None = typer.Option(
            None,
            "--exclude",
            help="Remove taxa from the panel-analysis taxonomy scope, using repeated options or comma-separated level:taxon items.",
        ),
        base_score_weight: float = typer.Option(
            DEFAULT_PANEL_BASE_SCORE_WEIGHT,
            "--base-score-weight",
            min=0.0,
            help="Weight applied to the upstream per-probe score during panel selection.",
        ),
        genome_index_penalty_weight: float = typer.Option(
            DEFAULT_INDEX_PENALTY_WEIGHT,
            "--genome-index-penalty-weight",
            min=0.0,
            help="Penalty weight applied to genome-wide off-target hits when an index is provided.",
        ),
        profile: str = typer.Option(
            DEFAULT_SCORING_PROFILE,
            "--profile",
            help="Panel selection profile: custom, fast, balanced, or strict.",
        ),
        interaction_backend: str = typer.Option(
            DEFAULT_THERMO_BACKEND,
            "--interaction-backend",
            help="Probe-probe interaction backend: basic or primer3.",
        ),
        monovalent_salt_mM: float = typer.Option(
            DEFAULT_MONOVALENT_SALT_MM,
            "--monovalent-salt-mM",
            min=0.0,
            help="Monovalent salt concentration used for panel interaction calculations.",
        ),
        divalent_salt_mM: float = typer.Option(
            DEFAULT_DIVALENT_SALT_MM,
            "--divalent-salt-mM",
            min=0.0,
            help="Divalent salt concentration used for panel interaction calculations.",
        ),
        dntp_mM: float = typer.Option(
            DEFAULT_DNTP_MM,
            "--dntp-mM",
            min=0.0,
            help="dNTP concentration used for panel interaction calculations.",
        ),
        probe_conc_nM: float = typer.Option(
            DEFAULT_PROBE_CONC_NM,
            "--probe-conc-nM",
            min=0.0,
            help="Probe concentration used for panel interaction calculations.",
        ),
        hyb_temp_c: float = typer.Option(
            DEFAULT_HYB_TEMP_C,
            "--hyb-temp-c",
            help="Hybridization temperature used when evaluating probe-probe interactions.",
        ),
        max_panel_contiguous_complementarity: int | None = typer.Option(
            None,
            "--max-panel-contiguous-complementarity",
            min=1,
            help="Optional maximum allowed contiguous complementarity between selected probes.",
        ),
        max_panel_heterodimer_tm: float | None = typer.Option(
            None,
            "--max-panel-heterodimer-tm",
            help="Optional maximum allowed heterodimer melting temperature. Requires primer3 backend.",
        ),
        panel_complementarity_penalty_weight: float | None = typer.Option(
            None,
            "--panel-complementarity-penalty-weight",
            min=0.0,
            help="Penalty weight applied to pairwise complementarity during panel selection. Defaults depend on --profile.",
        ),
        panel_heterodimer_penalty_weight: float | None = typer.Option(
            None,
            "--panel-heterodimer-penalty-weight",
            min=0.0,
            help="Penalty weight applied to heterodimer Tm during panel selection. Defaults depend on --profile.",
        ),
        max_mismatches: int = typer.Option(
            DEFAULT_MAX_MISMATCHES,
            "--max-mismatches",
            min=0,
            help="Maximum allowed mismatches when screening marker-gene off-targets during panel selection.",
        ),
        mismatch_penalty_per_mismatch: float = typer.Option(
            DEFAULT_MISMATCH_PENALTY_PER_MISMATCH,
            "--mismatch-penalty-per-mismatch",
            min=0.0,
            help="Penalty applied to per-sequence support for each mismatch within the allowed tolerance.",
        ),
        workers: int = typer.Option(
            DEFAULT_AUTO_WORKERS,
            "--workers",
            min=0,
            help=WORKERS_OPTION_HELP,
        ),
        format: OutputFormat = typer.Option(
            OutputFormat.text,
            "--format",
            help="Output format for the panel-design summary.",
        ),
        no_color: bool = typer.Option(
            False,
            "--no-color",
            help="Disable ANSI colors in text output.",
        ),
    ) -> None:
        try:
            _run_panels_design(
                dataset=dataset,
                gtdb_release=gtdb_release,
                taxonomy_file=taxonomy_file,
                markers_archive=markers_archive,
                index_dataset=index_dataset,
                index_file=index_file,
                index_reference_map=index_reference_map,
                index_summary=index_summary,
                fulgor_bin=fulgor_bin,
                index_threads=index_threads,
                output_dir=output_dir,
                session_name=session_name,
                input_session_name=input_session_name,
                input_attempt=input_attempt,
                max_probes_per_panel=max_probes_per_panel,
                max_probes_per_marker=max_probes_per_marker,
                max_probes_per_region=max_probes_per_region,
                allow_overlaps=allow_overlaps,
                include=include,
                exclude=exclude,
                base_score_weight=base_score_weight,
                genome_index_penalty_weight=genome_index_penalty_weight,
                scoring_profile=profile,
                interaction_backend=interaction_backend,
                monovalent_salt_mM=monovalent_salt_mM,
                divalent_salt_mM=divalent_salt_mM,
                dntp_mM=dntp_mM,
                probe_conc_nM=probe_conc_nM,
                hyb_temp_c=hyb_temp_c,
                max_panel_contiguous_complementarity=max_panel_contiguous_complementarity,
                max_panel_heterodimer_tm=max_panel_heterodimer_tm,
                panel_complementarity_penalty_weight=panel_complementarity_penalty_weight,
                panel_heterodimer_penalty_weight=panel_heterodimer_penalty_weight,
                max_mismatches=max_mismatches,
                mismatch_penalty_per_mismatch=mismatch_penalty_per_mismatch,
                workers=workers,
                report_format=format,
                no_color=no_color,
            )
        except ValueError as exc:
            raise PhyloprobeClickException(str(exc)) from exc


def _build_argparse_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="phyloprobe",
        description=ROOT_DESCRIPTION,
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    subparsers = parser.add_subparsers(dest="command", required=True)

    datasets_parser = subparsers.add_parser("datasets", help="Install catalog-defined datasets.")
    datasets_parser.add_argument("--taxon", default="all", help="Install all datasets by default, or restrict to one major taxon.")
    datasets_parser.add_argument("--catalog-file", default=default_catalog_path(), type=Path, help="Path to the dataset catalog JSON.")
    datasets_parser.add_argument("--gtdb-release", default=None, help="GTDB release to install from the catalog, for example r226 or r220. Defaults to the catalog's default release.")
    datasets_parser.add_argument("--datasets-dir", default=None, type=Path, help="Directory where downloaded datasets should be stored.")
    datasets_parser.add_argument("--force", action="store_true", help="Reinstall selected datasets even if already present.")
    datasets_parser.add_argument("--format", choices=("text", "json"), default="text", help="Output format for the installation report.")
    datasets_parser.add_argument("--no-color", action="store_true", help="Disable ANSI colors in text output.")
    datasets_parser.set_defaults(func=lambda args: _run_datasets_install(
        taxon=args.taxon,
        catalog_file=args.catalog_file,
        gtdb_release=args.gtdb_release,
        datasets_dir=args.datasets_dir,
        report_format=args.format,
        force=args.force,
        no_color=args.no_color,
    ))

    list_parser = subparsers.add_parser("datasets-list", help="List installed datasets.")
    list_parser.add_argument("--format", choices=("text", "json"), default="text")
    list_parser.add_argument("--no-color", action="store_true", help="Disable ANSI colors in text output.")
    list_parser.set_defaults(func=lambda args: _run_datasets_list(report_format=args.format, no_color=args.no_color))

    show_parser = subparsers.add_parser("datasets-show", help="Show one installed dataset.")
    show_parser.add_argument("--name", required=True, help="Installed dataset name.")
    show_parser.add_argument("--gtdb-release", default=None, help="GTDB release to resolve when --name is a logical dataset name such as archaea or bacteria.")
    show_parser.add_argument("--format", choices=("text", "json"), default="text")
    show_parser.add_argument("--no-color", action="store_true", help="Disable ANSI colors in text output.")
    show_parser.set_defaults(func=lambda args: _run_datasets_show(
        name=args.name,
        gtdb_release=args.gtdb_release,
        report_format=args.format,
        no_color=args.no_color,
    ))

    taxonomy_parser = subparsers.add_parser("taxonomy", help="Summarize a GTDB taxonomy file or installed dataset.")
    summarize_group = taxonomy_parser.add_mutually_exclusive_group(required=True)
    summarize_group.add_argument("--taxonomy-file", type=Path, help="Path to a GTDB taxonomy TSV.")
    summarize_group.add_argument("--dataset", help="Installed dataset name.")
    taxonomy_parser.add_argument("--gtdb-release", default=None, help="GTDB release to resolve when --dataset is a logical dataset name such as archaea or bacteria.")
    taxonomy_parser.add_argument("--format", choices=("text", "json"), default="text")
    taxonomy_parser.add_argument("--no-color", action="store_true", help="Disable ANSI colors in text output.")
    taxonomy_parser.set_defaults(func=lambda args: _run_taxonomy_summarize(
        taxonomy_file=args.taxonomy_file,
        dataset=args.dataset,
        gtdb_release=args.gtdb_release,
        report_format=args.format,
        no_color=args.no_color,
    ))

    index_parser = subparsers.add_parser("index", help="Build a reusable Fulgor genome index.")
    index_parser.add_argument("--genome-archive", default=None, type=Path, help="Path to a tar archive of genomes.")
    index_parser.add_argument(
        "--genome-file",
        dest="genome_file",
        action="append",
        default=None,
        type=Path,
        help="Path to a genome FASTA file. Repeat --genome-file to index a custom genome set.",
    )
    index_parser.add_argument("--output-prefix", default=Path("outputs/genome_index"), type=Path, help="Prefix used for the written index artifacts.")
    index_parser.add_argument("--fulgor-bin", default="fulgor", help="Path to the Fulgor executable.")
    index_parser.add_argument("--kmer-length", default=DEFAULT_KMER_LENGTH, type=int, help="K-mer length for Fulgor indexing.")
    index_parser.add_argument("--minimizer-length", default=DEFAULT_MINIMIZER_LENGTH, type=int, help="Minimizer length for Fulgor indexing.")
    index_parser.add_argument("--threads", default=DEFAULT_FULGOR_THREADS, type=int, help="Fulgor build threads.")
    index_parser.add_argument("--ggcat-threads", default=DEFAULT_GGCAT_THREADS, type=int, help="Threads passed to the GGCAT phase of Fulgor build.")
    index_parser.add_argument("--tmp-dir", default=None, type=Path, help="Optional temporary directory for extracted genomes and Fulgor scratch files.")
    index_parser.add_argument("--keep-extracted", action="store_true", help="Keep extracted genome FASTA files under --tmp-dir after the index is built.")
    index_parser.add_argument("--check", dest="check", action="store_true", default=True, help="Enable Fulgor consistency checks.")
    index_parser.add_argument("--no-check", dest="check", action="store_false", help="Disable Fulgor consistency checks.")
    index_parser.add_argument("--taxon", default=None, help="Optional taxon label stored in the build summary.")
    index_parser.add_argument("--release", default=None, help="Optional GTDB release label stored in the build summary.")
    index_parser.add_argument("--format", choices=("text", "json"), default="text")
    index_parser.add_argument("--no-color", action="store_true", help="Disable ANSI colors in text output.")
    index_parser.set_defaults(func=lambda args: _run_index_build(
        genome_archive=args.genome_archive,
        genome_files=args.genome_file,
        output_prefix=args.output_prefix,
        fulgor_bin=args.fulgor_bin,
        kmer_length=args.kmer_length,
        minimizer_length=args.minimizer_length,
        threads=args.threads,
        ggcat_threads=args.ggcat_threads,
        tmp_dir=args.tmp_dir,
        keep_extracted=args.keep_extracted,
        check=args.check,
        taxon=args.taxon,
        release=args.release,
        report_format=args.format,
        no_color=args.no_color,
    ))

    tags_parser = subparsers.add_parser("tags", help="Design hierarchical tags from GTDB taxonomy.")
    tags_source_group = tags_parser.add_mutually_exclusive_group(required=True)
    tags_source_group.add_argument("--taxonomy-file", type=Path, help="Path to a GTDB taxonomy TSV or TSV.GZ file.")
    tags_source_group.add_argument("--dataset", help="Installed dataset name.")
    tags_parser.add_argument("--gtdb-release", default=None, help="GTDB release to resolve when --dataset is a logical dataset name such as archaea or bacteria.")
    tags_parser.add_argument("--output", dest="output_dir", required=True, type=Path, help="Parent directory for a session-organized run layout.")
    tags_parser.add_argument("--session", dest="session_name", required=True, help="Session identifier used to create the run folder and numbered stage-attempt subdirectories. Letters, digits, and underscores only.")
    tags_parser.add_argument("--positions", default=4, type=int, help="Total barcode positions available for tag allocation.")
    tags_parser.add_argument("--alphabet", default=",".join(DEFAULT_TAG_ALPHABET), help="Comma-separated one-character barcode alphabet, for example A,T,G,C or [0,1]. Symbols must be unique single letters or digits.")
    tags_parser.add_argument("--levels", default=",".join(DEFAULT_TAG_LEVELS), help="Comma-separated taxonomy levels in hierarchical order.")
    tags_parser.add_argument("--maximise-levels", "--maximize-levels", dest="maximise_levels", default="all", help="Comma-separated levels to prioritize, or 'all'.")
    tags_parser.add_argument("--level-weights", default=None, help="Optional numeric objective weights such as phylum:2,genus:0.5 or all:1. Overrides equal weighting from --maximise-levels.")
    tags_parser.add_argument("--min-taxa-per-level", default=None, help="Optional hard minima, for example family:20,genus:50.")
    tags_parser.add_argument("--exclusive", action="append", default=None, help="Restrict preprocessing to specific taxa and their descendants, using repeated options or comma-separated level:taxon items.")
    tags_parser.add_argument("--include", action="append", default=None, help="Force presence of specific taxa using repeated options or comma-separated level:taxon items.")
    tags_parser.add_argument("--exclude", action="append", default=None, help="Remove specific taxa before optimization using repeated options or comma-separated level:taxon items.")
    tags_parser.add_argument("--prefer", action="append", default=None, help="Softly prefer specific taxa using repeated options or comma-separated level:taxon items.")
    tags_parser.add_argument("--avoid", action="append", default=None, help="Softly avoid specific taxa using repeated options or comma-separated level:taxon items.")
    tags_parser.add_argument("--descendants", action="append", default=None, help="Softly prefer taxa whose branch contains at least N taxa at the next configured level, using level:count items such as order:4.")
    tags_parser.add_argument("--descendants-hard", action="append", default=None, help="Require taxa to contain at least N taxa at the next configured level, using level:count items such as order:4.")
    tags_parser.add_argument("--fallbacks-per-target", default=1, type=int, help="Number of same-rank fallback taxa to record per selected barcode for later rescue in target discovery. Use 0 to disable reserve targets.")
    tags_parser.add_argument("--util-weight", default=0.15, type=float, help="Weight for overall tag-space utilization in the objective.")
    tags_parser.add_argument("--format", choices=("text", "json"), default="text")
    tags_parser.add_argument("--no-color", action="store_true", help="Disable ANSI colors in text output.")
    tags_parser.set_defaults(func=lambda args: _run_tags_design(
        taxonomy_file=args.taxonomy_file,
        dataset=args.dataset,
        gtdb_release=args.gtdb_release,
        output_dir=args.output_dir,
        session_name=args.session_name,
        positions=args.positions,
        alphabet=args.alphabet,
        levels=args.levels,
        maximise_levels=args.maximise_levels,
        level_weights=args.level_weights,
        min_taxa_per_level=args.min_taxa_per_level,
        exclusive=args.exclusive,
        include=args.include,
        exclude=args.exclude,
        prefer=args.prefer,
        avoid=args.avoid,
        descendants=args.descendants,
        descendants_hard=args.descendants_hard,
        fallbacks_per_target=args.fallbacks_per_target,
        util_weight=args.util_weight,
        report_format=args.format,
        no_color=args.no_color,
    ))

    targets_parser = subparsers.add_parser("targets", help="Resolve selected taxa and rank marker genes.")
    targets_parser.add_argument("--dataset", default=None, help="Installed dataset name.")
    targets_parser.add_argument("--gtdb-release", default=None, help="GTDB release to resolve when --dataset is a logical dataset name such as archaea or bacteria.")
    targets_parser.add_argument("--taxonomy-file", default=None, type=Path, help="Path to a GTDB taxonomy TSV or TSV.GZ file.")
    targets_parser.add_argument("--markers-archive", default=None, type=Path, help="Path to the GTDB marker-gene tar archive.")
    targets_parser.add_argument("--output", dest="output_dir", required=True, type=Path, help="Parent directory for a session-organized run layout.")
    targets_parser.add_argument("--session", dest="session_name", required=True, help="Session identifier used to create the run folder and numbered stage-attempt subdirectories. Letters, digits, and underscores only.")
    targets_parser.add_argument("--input-session", dest="input_session_name", default=None, help="Optional source session to read upstream stage outputs from. Defaults to --session.")
    targets_parser.add_argument("--input-attempt", dest="input_attempt", default=None, help="Optional upstream attempt number to read from. Defaults to the active attempt recorded in the upstream stage manifest.")
    targets_parser.add_argument("--profile", default=DEFAULT_SELECTION_PROFILE, help="Target discovery profile: custom, fast, balanced, or strict.")
    targets_parser.add_argument("--top-markers-per-target", default=None, type=int, help="Number of top-ranked markers to keep per target. Defaults depend on --profile.")
    targets_parser.add_argument("--fallback-policy", default=DEFAULT_FALLBACK_POLICY, help="When to promote fallback taxa from tag design. One of: none, no_marker_genomes, single_marker_genome, missing_or_single.")
    targets_parser.add_argument("--include", action="append", default=None, help="Restrict the target-analysis taxonomy scope to matching taxa, using repeated options or comma-separated level:taxon items.")
    targets_parser.add_argument("--exclude", action="append", default=None, help="Remove taxa from the target-analysis taxonomy scope, using repeated options or comma-separated level:taxon items.")
    targets_parser.add_argument("--workers", default=DEFAULT_AUTO_WORKERS, type=int, help=WORKERS_OPTION_HELP)
    targets_parser.add_argument("--format", choices=("text", "json"), default="text")
    targets_parser.add_argument("--no-color", action="store_true", help="Disable ANSI colors in text output.")
    targets_parser.set_defaults(func=lambda args: _run_targets_discover(
        dataset=args.dataset,
        gtdb_release=args.gtdb_release,
        taxonomy_file=args.taxonomy_file,
        markers_archive=args.markers_archive,
        output_dir=args.output_dir,
        session_name=args.session_name,
        input_session_name=args.input_session_name,
        input_attempt=args.input_attempt,
        selection_profile=args.profile,
        top_markers_per_target=args.top_markers_per_target,
        fallback_policy=args.fallback_policy,
        include=args.include,
        exclude=args.exclude,
        workers=args.workers,
        report_format=args.format,
        no_color=args.no_color,
    ))

    regions_parser = subparsers.add_parser("regions", help="Discover conserved regions from selected marker MSAs.")
    regions_parser.add_argument("--dataset", default=None, help="Installed dataset name.")
    regions_parser.add_argument("--gtdb-release", default=None, help="GTDB release to resolve when --dataset is a logical dataset name such as archaea or bacteria.")
    regions_parser.add_argument("--taxonomy-file", default=None, type=Path, help="Path to a GTDB taxonomy TSV or TSV.GZ file.")
    regions_parser.add_argument("--msa-archive", default=None, type=Path, help="Path to the GTDB aligned MSA tar archive.")
    regions_parser.add_argument("--markers-archive", default=None, type=Path, help="GTDB marker-gene tar archive used for early nucleotide remapping and probeability scoring.")
    regions_parser.add_argument("--output", dest="output_dir", required=True, type=Path, help="Parent directory for a session-organized run layout.")
    regions_parser.add_argument("--session", dest="session_name", required=True, help="Session identifier used to create the run folder and numbered stage-attempt subdirectories. Letters, digits, and underscores only.")
    regions_parser.add_argument("--input-session", dest="input_session_name", default=None, help="Optional source session to read upstream stage outputs from. Defaults to --session.")
    regions_parser.add_argument("--input-attempt", dest="input_attempt", default=None, help="Optional upstream attempt number to read from. Defaults to the active attempt recorded in the upstream stage manifest.")
    regions_parser.add_argument("--profile", default=DEFAULT_DISCOVERY_PROFILE, help="Region discovery profile: custom, fast, balanced, or strict.")
    regions_parser.add_argument("--window-aa-length", default=None, type=int, help="Fixed aligned protein window length. When omitted, region discovery defaults to adaptive scanning across the default window-length range.")
    regions_parser.add_argument("--window-aa-length-min", default=None, type=int, help="Minimum aligned protein window length to evaluate. Defaults depend on --profile, or to --window-aa-length when a fixed window is requested.")
    regions_parser.add_argument("--window-aa-length-max", default=None, type=int, help="Maximum aligned protein window length to evaluate. Defaults depend on --profile, or to --window-aa-length when a fixed window is requested.")
    regions_parser.add_argument("--top-regions-per-marker", default=None, type=int, help="Maximum number of non-overlapping regions to keep per target-marker pair. Defaults depend on --profile.")
    regions_parser.add_argument("--include", action="append", default=None, help="Restrict the region-analysis taxonomy scope to matching taxa, using repeated options or comma-separated level:taxon items.")
    regions_parser.add_argument("--exclude", action="append", default=None, help="Remove taxa from the region-analysis taxonomy scope, using repeated options or comma-separated level:taxon items.")
    regions_parser.add_argument("--min-target-column-occupancy", default=None, type=float, help="Minimum in-target non-gap fraction required in every column of a window. Defaults depend on --profile.")
    regions_parser.add_argument("--min-target-consensus", default=None, type=float, help="Minimum in-target amino-acid consensus required in every column of a window. Defaults depend on --profile.")
    regions_parser.add_argument("--min-target-window-presence", default=None, type=float, help="Minimum fraction of target sequences that must span the whole gap-free window. Defaults depend on --profile.")
    regions_parser.add_argument("--max-aa-mismatches", default=None, type=int, help="Maximum amino-acid mismatches allowed when scoring near matches to the target consensus window. Defaults depend on --profile.")
    regions_parser.add_argument("--aa-mismatch-penalty-per-mismatch", default=None, type=float, help="Penalty applied per amino-acid mismatch when mismatch-tolerant region scoring is enabled. Defaults depend on --profile.")
    regions_parser.add_argument("--region-probe-length", default=None, type=int, help="Probe length used to estimate whether shortlisted amino-acid regions are likely to yield usable nucleotide probes. Defaults depend on --profile.")
    regions_parser.add_argument("--min-target-remap-fraction", default=None, type=float, help="Minimum fraction of target aligned sequences that must remap cleanly into nucleotide marker windows. Defaults depend on --profile.")
    regions_parser.add_argument("--min-best-probe-support-fraction", default=None, type=float, help="Minimum fraction of remapped target sequences that must share the strongest candidate probe subsequence within a region. Defaults depend on --profile.")
    regions_parser.add_argument("--probeability-weight", default=None, type=float, help="Positive score weight applied to early nucleotide remapping and probeability estimates during region ranking. Defaults depend on --profile.")
    regions_parser.add_argument("--workers", default=DEFAULT_AUTO_WORKERS, type=int, help=WORKERS_OPTION_HELP)
    regions_parser.add_argument("--format", choices=("text", "json"), default="text")
    regions_parser.add_argument("--no-color", action="store_true", help="Disable ANSI colors in text output.")
    regions_parser.set_defaults(func=lambda args: _run_regions_discover(
        dataset=args.dataset,
        gtdb_release=args.gtdb_release,
        taxonomy_file=args.taxonomy_file,
        msa_archive=args.msa_archive,
        markers_archive=args.markers_archive,
        output_dir=args.output_dir,
        session_name=args.session_name,
        input_session_name=args.input_session_name,
        input_attempt=args.input_attempt,
        discovery_profile=args.profile,
        window_aa_length=args.window_aa_length,
        window_aa_length_min=args.window_aa_length_min,
        window_aa_length_max=args.window_aa_length_max,
        top_regions_per_marker=args.top_regions_per_marker,
        include=args.include,
        exclude=args.exclude,
        min_target_column_occupancy=args.min_target_column_occupancy,
        min_target_consensus=args.min_target_consensus,
        min_target_window_presence=args.min_target_window_presence,
        max_aa_mismatches=args.max_aa_mismatches,
        aa_mismatch_penalty_per_mismatch=args.aa_mismatch_penalty_per_mismatch,
        region_probe_length=args.region_probe_length,
        min_target_remap_fraction=args.min_target_remap_fraction,
        min_best_probe_support_fraction=args.min_best_probe_support_fraction,
        probeability_weight=args.probeability_weight,
        workers=args.workers,
        report_format=args.format,
        no_color=args.no_color,
    ))

    probes_parser = subparsers.add_parser("probes", help="Design nucleotide probes from shortlisted regions.")
    probes_parser.add_argument("--dataset", default=None, help="Installed dataset name.")
    probes_parser.add_argument("--gtdb-release", default=None, help="GTDB release to resolve when --dataset is a logical dataset name such as archaea or bacteria.")
    probes_parser.add_argument("--taxonomy-file", default=None, type=Path, help="Path to a GTDB taxonomy TSV or TSV.GZ file.")
    probes_parser.add_argument("--markers-archive", default=None, type=Path, help="Path to the GTDB marker-gene tar archive. Probe design uses the nucleotide remap manifest produced by `regions` plus these marker sequences.")
    probes_parser.add_argument("--output", dest="output_dir", required=True, type=Path, help="Parent directory for a session-organized run layout.")
    probes_parser.add_argument("--session", dest="session_name", required=True, help="Session identifier used to create the run folder and numbered stage-attempt subdirectories. Letters, digits, and underscores only.")
    probes_parser.add_argument("--input-session", dest="input_session_name", default=None, help="Optional source session to read upstream stage outputs from. Defaults to --session.")
    probes_parser.add_argument("--input-attempt", dest="input_attempt", default=None, help="Optional upstream attempt number to read from. Defaults to the active attempt recorded in the upstream stage manifest.")
    probes_parser.add_argument("--probe-length", default=DEFAULT_PROBE_LENGTH, type=int, help="Probe length in nucleotides.")
    probes_parser.add_argument("--top-probes-per-region", default=DEFAULT_TOP_PROBES_PER_REGION, type=int, help="Maximum number of top probes to keep per region candidate.")
    probes_parser.add_argument("--include", action="append", default=None, help="Restrict the probe-analysis taxonomy scope to matching taxa, using repeated options or comma-separated level:taxon items.")
    probes_parser.add_argument("--exclude", action="append", default=None, help="Remove taxa from the probe-analysis taxonomy scope, using repeated options or comma-separated level:taxon items.")
    probes_parser.add_argument("--min-gc", default=DEFAULT_MIN_GC, type=float, help="Minimum allowed GC fraction.")
    probes_parser.add_argument("--max-gc", default=DEFAULT_MAX_GC, type=float, help="Maximum allowed GC fraction.")
    probes_parser.add_argument("--min-tm", default=DEFAULT_MIN_TM, type=float, help="Minimum allowed basic melting temperature estimate.")
    probes_parser.add_argument("--max-tm", default=DEFAULT_MAX_TM, type=float, help="Maximum allowed basic melting temperature estimate.")
    probes_parser.add_argument("--max-homopolymer", default=DEFAULT_MAX_HOMOPOLYMER, type=int, help="Maximum allowed homopolymer run length.")
    probes_parser.add_argument("--profile", default=DEFAULT_SCORING_PROFILE, help="Probe design profile: custom, fast, balanced, or strict.")
    probes_parser.add_argument("--thermo-backend", default=DEFAULT_THERMO_BACKEND, help="Thermodynamic backend: basic or primer3.")
    probes_parser.add_argument("--monovalent-salt-mM", default=DEFAULT_MONOVALENT_SALT_MM, type=float, help="Monovalent salt concentration used for thermodynamic calculations.")
    probes_parser.add_argument("--divalent-salt-mM", default=DEFAULT_DIVALENT_SALT_MM, type=float, help="Divalent salt concentration used for thermodynamic calculations.")
    probes_parser.add_argument("--dntp-mM", default=DEFAULT_DNTP_MM, type=float, help="dNTP concentration used for thermodynamic calculations.")
    probes_parser.add_argument("--probe-conc-nM", default=DEFAULT_PROBE_CONC_NM, type=float, help="Probe concentration used for thermodynamic calculations.")
    probes_parser.add_argument("--hyb-temp-c", default=DEFAULT_HYB_TEMP_C, type=float, help="Hybridization temperature used when evaluating structure formation.")
    probes_parser.add_argument("--max-dinucleotide-run", default=None, type=int, help="Optional maximum allowed repeated dinucleotide run length.")
    probes_parser.add_argument("--min-sequence-entropy", default=None, type=float, help="Optional minimum normalized sequence entropy.")
    probes_parser.add_argument("--max-self-complementarity", default=None, type=int, help="Optional maximum allowed self-complementarity score.")
    probes_parser.add_argument("--max-contiguous-self-complementarity", default=None, type=int, help="Optional maximum allowed contiguous self-complementarity score.")
    probes_parser.add_argument("--max-hairpin-tm", default=None, type=float, help="Optional maximum allowed hairpin melting temperature. Requires primer3 backend.")
    probes_parser.add_argument("--max-homodimer-tm", default=None, type=float, help="Optional maximum allowed homodimer melting temperature. Requires primer3 backend.")
    probes_parser.add_argument("--region-score-weight", default=None, type=float, help="Weight applied to the upstream conserved-region score. Defaults depend on --profile.")
    probes_parser.add_argument("--thermo-penalty-weight", default=None, type=float, help="Weight applied to thermodynamic penalties during probe scoring. Defaults depend on --profile.")
    probes_parser.add_argument("--max-mismatches", default=DEFAULT_MAX_MISMATCHES, type=int, help="Maximum allowed mismatches when screening target and off-target matches in marker genes.")
    probes_parser.add_argument("--mismatch-penalty-per-mismatch", default=DEFAULT_MISMATCH_PENALTY_PER_MISMATCH, type=float, help="Penalty applied to per-sequence support for each mismatch within the allowed tolerance.")
    probes_parser.add_argument("--sibling-penalty-weight", default=DEFAULT_PROBE_SIBLING_PENALTY_WEIGHT, type=float, help="Penalty weight applied to sibling-taxon off-target fractions.")
    probes_parser.add_argument("--global-penalty-weight", default=DEFAULT_PROBE_GLOBAL_PENALTY_WEIGHT, type=float, help="Penalty weight applied to global off-target fractions.")
    probes_parser.add_argument("--workers", default=DEFAULT_AUTO_WORKERS, type=int, help=WORKERS_OPTION_HELP)
    probes_parser.add_argument("--format", choices=("text", "json"), default="text")
    probes_parser.add_argument("--no-color", action="store_true", help="Disable ANSI colors in text output.")
    probes_parser.set_defaults(func=lambda args: _run_probes_design(
        dataset=args.dataset,
        gtdb_release=args.gtdb_release,
        taxonomy_file=args.taxonomy_file,
        markers_archive=args.markers_archive,
        output_dir=args.output_dir,
        session_name=args.session_name,
        input_session_name=args.input_session_name,
        input_attempt=args.input_attempt,
        probe_length=args.probe_length,
        top_probes_per_region=args.top_probes_per_region,
        include=args.include,
        exclude=args.exclude,
        min_gc=args.min_gc,
        max_gc=args.max_gc,
        min_tm=args.min_tm,
        max_tm=args.max_tm,
        max_homopolymer=args.max_homopolymer,
        scoring_profile=args.profile,
        thermo_backend=args.thermo_backend,
        monovalent_salt_mM=args.monovalent_salt_mM,
        divalent_salt_mM=args.divalent_salt_mM,
        dntp_mM=args.dntp_mM,
        probe_conc_nM=args.probe_conc_nM,
        hyb_temp_c=args.hyb_temp_c,
        max_dinucleotide_run=args.max_dinucleotide_run,
        min_sequence_entropy=args.min_sequence_entropy,
        max_self_complementarity=args.max_self_complementarity,
        max_contiguous_self_complementarity=args.max_contiguous_self_complementarity,
        max_hairpin_tm=args.max_hairpin_tm,
        max_homodimer_tm=args.max_homodimer_tm,
        region_score_weight=args.region_score_weight,
        thermo_penalty_weight=args.thermo_penalty_weight,
        max_mismatches=args.max_mismatches,
        mismatch_penalty_per_mismatch=args.mismatch_penalty_per_mismatch,
        sibling_penalty_weight=args.sibling_penalty_weight,
        global_penalty_weight=args.global_penalty_weight,
        workers=args.workers,
        report_format=args.format,
        no_color=args.no_color,
    ))

    panels_parser = subparsers.add_parser("panels", help="Assemble final per-target probe panels.")
    panels_parser.add_argument("--dataset", default=None, help="Installed dataset name.")
    panels_parser.add_argument("--gtdb-release", default=None, help="GTDB release to resolve when --dataset is a logical dataset name such as archaea or bacteria.")
    panels_parser.add_argument("--taxonomy-file", default=None, type=Path, help="Path to a GTDB taxonomy TSV or TSV.GZ file.")
    panels_parser.add_argument("--markers-archive", default=None, type=Path, help="Path to the GTDB marker-gene tar archive.")
    panels_parser.add_argument("--index-dataset", action="append", default=None, help="Installed Fulgor index dataset used for genome-wide off-target screening. Repeat to combine multiple indices.")
    panels_parser.add_argument("--index-file", action="append", default=None, type=Path, help="Path to a Fulgor `.fur` index file. Repeat together with --index-reference-map and --index-summary.")
    panels_parser.add_argument("--index-reference-map", action="append", default=None, type=Path, help="Path to the CSV reference map produced by `phyloprobe index`. Repeat alongside --index-file.")
    panels_parser.add_argument("--index-summary", action="append", default=None, type=Path, help="Path to the JSON summary produced by `phyloprobe index`. Repeat alongside --index-file.")
    panels_parser.add_argument("--fulgor-bin", default="fulgor", help="Path to the Fulgor executable used for genome-wide probe queries.")
    panels_parser.add_argument("--index-threads", default=DEFAULT_FULGOR_THREADS, type=int, help="Threads used by Fulgor when querying the genome index.")
    panels_parser.add_argument("--output", dest="output_dir", required=True, type=Path, help="Parent directory for a session-organized run layout.")
    panels_parser.add_argument("--session", dest="session_name", required=True, help="Session identifier used to create the run folder and numbered stage-attempt subdirectories. Letters, digits, and underscores only.")
    panels_parser.add_argument("--input-session", dest="input_session_name", default=None, help="Optional source session to read upstream stage outputs from. Defaults to --session.")
    panels_parser.add_argument("--input-attempt", dest="input_attempt", default=None, help="Optional upstream attempt number to read from. Defaults to the active attempt recorded in the upstream stage manifest.")
    panels_parser.add_argument("--max-probes-per-panel", default=DEFAULT_MAX_PROBES_PER_PANEL, type=int, help="Maximum number of probes to keep in each target panel.")
    panels_parser.add_argument("--max-probes-per-marker", default=DEFAULT_MAX_PROBES_PER_MARKER, type=int, help="Maximum number of selected probes allowed from a single marker.")
    panels_parser.add_argument("--max-probes-per-region", default=DEFAULT_MAX_PROBES_PER_REGION, type=int, help="Maximum number of selected probes allowed from a single conserved region. Overlapping probes are still excluded unless --allow-overlaps is used.")
    panels_parser.add_argument("--allow-overlaps", action="store_true", help="Allow overlapping probe intervals from the same marker locus to coexist within a panel.")
    panels_parser.add_argument("--include", action="append", default=None, help="Restrict the panel-analysis taxonomy scope to matching taxa, using repeated options or comma-separated level:taxon items.")
    panels_parser.add_argument("--exclude", action="append", default=None, help="Remove taxa from the panel-analysis taxonomy scope, using repeated options or comma-separated level:taxon items.")
    panels_parser.add_argument("--base-score-weight", default=DEFAULT_PANEL_BASE_SCORE_WEIGHT, type=float, help="Weight applied to the upstream per-probe score during panel selection.")
    panels_parser.add_argument("--genome-index-penalty-weight", default=DEFAULT_INDEX_PENALTY_WEIGHT, type=float, help="Penalty weight applied to genome-wide off-target hits when an index is provided.")
    panels_parser.add_argument("--profile", default=DEFAULT_SCORING_PROFILE, help="Panel selection profile: custom, fast, balanced, or strict.")
    panels_parser.add_argument("--interaction-backend", default=DEFAULT_THERMO_BACKEND, help="Probe-probe interaction backend: basic or primer3.")
    panels_parser.add_argument("--monovalent-salt-mM", default=DEFAULT_MONOVALENT_SALT_MM, type=float, help="Monovalent salt concentration used for panel interaction calculations.")
    panels_parser.add_argument("--divalent-salt-mM", default=DEFAULT_DIVALENT_SALT_MM, type=float, help="Divalent salt concentration used for panel interaction calculations.")
    panels_parser.add_argument("--dntp-mM", default=DEFAULT_DNTP_MM, type=float, help="dNTP concentration used for panel interaction calculations.")
    panels_parser.add_argument("--probe-conc-nM", default=DEFAULT_PROBE_CONC_NM, type=float, help="Probe concentration used for panel interaction calculations.")
    panels_parser.add_argument("--hyb-temp-c", default=DEFAULT_HYB_TEMP_C, type=float, help="Hybridization temperature used when evaluating probe-probe interactions.")
    panels_parser.add_argument("--max-panel-contiguous-complementarity", default=None, type=int, help="Optional maximum allowed contiguous complementarity between selected probes.")
    panels_parser.add_argument("--max-panel-heterodimer-tm", default=None, type=float, help="Optional maximum allowed heterodimer melting temperature. Requires primer3 backend.")
    panels_parser.add_argument("--panel-complementarity-penalty-weight", default=None, type=float, help="Penalty weight applied to pairwise complementarity during panel selection. Defaults depend on --profile.")
    panels_parser.add_argument("--panel-heterodimer-penalty-weight", default=None, type=float, help="Penalty weight applied to heterodimer Tm during panel selection. Defaults depend on --profile.")
    panels_parser.add_argument("--max-mismatches", default=DEFAULT_MAX_MISMATCHES, type=int, help="Maximum allowed mismatches when screening marker-gene off-targets during panel selection.")
    panels_parser.add_argument("--mismatch-penalty-per-mismatch", default=DEFAULT_MISMATCH_PENALTY_PER_MISMATCH, type=float, help="Penalty applied to per-sequence support for each mismatch within the allowed tolerance.")
    panels_parser.add_argument("--workers", default=DEFAULT_AUTO_WORKERS, type=int, help=WORKERS_OPTION_HELP)
    panels_parser.add_argument("--format", choices=("text", "json"), default="text")
    panels_parser.add_argument("--no-color", action="store_true", help="Disable ANSI colors in text output.")
    panels_parser.set_defaults(func=lambda args: _run_panels_design(
        dataset=args.dataset,
        gtdb_release=args.gtdb_release,
        taxonomy_file=args.taxonomy_file,
        markers_archive=args.markers_archive,
        index_dataset=args.index_dataset,
        index_file=args.index_file,
        index_reference_map=args.index_reference_map,
        index_summary=args.index_summary,
        fulgor_bin=args.fulgor_bin,
        index_threads=args.index_threads,
        output_dir=args.output_dir,
        session_name=args.session_name,
        input_session_name=args.input_session_name,
        input_attempt=args.input_attempt,
        max_probes_per_panel=args.max_probes_per_panel,
        max_probes_per_marker=args.max_probes_per_marker,
        max_probes_per_region=args.max_probes_per_region,
        allow_overlaps=args.allow_overlaps,
        include=args.include,
        exclude=args.exclude,
        base_score_weight=args.base_score_weight,
        genome_index_penalty_weight=args.genome_index_penalty_weight,
        scoring_profile=args.profile,
        interaction_backend=args.interaction_backend,
        monovalent_salt_mM=args.monovalent_salt_mM,
        divalent_salt_mM=args.divalent_salt_mM,
        dntp_mM=args.dntp_mM,
        probe_conc_nM=args.probe_conc_nM,
        hyb_temp_c=args.hyb_temp_c,
        max_panel_contiguous_complementarity=args.max_panel_contiguous_complementarity,
        max_panel_heterodimer_tm=args.max_panel_heterodimer_tm,
        panel_complementarity_penalty_weight=args.panel_complementarity_penalty_weight,
        panel_heterodimer_penalty_weight=args.panel_heterodimer_penalty_weight,
        max_mismatches=args.max_mismatches,
        mismatch_penalty_per_mismatch=args.mismatch_penalty_per_mismatch,
        workers=args.workers,
        report_format=args.format,
        no_color=args.no_color,
    ))

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    raw_argv = list(argv) if argv is not None else sys.argv[1:]

    if typer is not None and click is not None:
        try:
            app(args=raw_argv, prog_name="phyloprobe", standalone_mode=False)
        except click.exceptions.Exit as exc:
            return int(exc.exit_code)
        except click.ClickException as exc:
            exc.show()
            return int(exc.exit_code)
        except click.Abort:
            return 1
        return 0

    if not raw_argv:
        _print_root_overview()
        return 0

    parser = _build_argparse_parser()
    try:
        args = parser.parse_args(raw_argv)
        return int(args.func(args))
    except ValueError as exc:
        _print_cli_error(str(exc))
        return 1
