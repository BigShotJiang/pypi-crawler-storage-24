"""Shared thermodynamic heuristics and optional primer3-backed calculations."""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
import math
from typing import Any

from phyloprobe.profile_defaults import (
    get_stage_default_profile,
    get_stage_profile_defaults,
    get_stage_profile_names,
)

DEFAULT_SCORING_PROFILE = get_stage_default_profile("probes")
DEFAULT_THERMO_BACKEND = "basic"
DEFAULT_MONOVALENT_SALT_MM = 50.0
DEFAULT_DIVALENT_SALT_MM = 1.5
DEFAULT_DNTP_MM = 0.0
DEFAULT_PROBE_CONC_NM = 250.0
DEFAULT_HYB_TEMP_C = 47.0
DEFAULT_REGION_SCORE_WEIGHT = 0.1
DEFAULT_THERMO_PENALTY_WEIGHT = 0.0
DEFAULT_PANEL_COMPLEMENTARITY_PENALTY_WEIGHT = 0.0
DEFAULT_PANEL_HETERODIMER_PENALTY_WEIGHT = 0.0

VALID_SCORING_PROFILES = set(get_stage_profile_names("probes")) | set(get_stage_profile_names("panels"))
VALID_THERMO_BACKENDS = {"basic", "primer3"}


@dataclass(slots=True, frozen=True)
class ThermoConditions:
    monovalent_salt_mM: float = DEFAULT_MONOVALENT_SALT_MM
    divalent_salt_mM: float = DEFAULT_DIVALENT_SALT_MM
    dntp_mM: float = DEFAULT_DNTP_MM
    probe_conc_nM: float = DEFAULT_PROBE_CONC_NM
    hyb_temp_c: float = DEFAULT_HYB_TEMP_C

    def to_summary_dict(self) -> dict[str, float]:
        return {
            "monovalent_salt_mM": self.monovalent_salt_mM,
            "divalent_salt_mM": self.divalent_salt_mM,
            "dntp_mM": self.dntp_mM,
            "probe_conc_nM": self.probe_conc_nM,
            "hyb_temp_c": self.hyb_temp_c,
        }


@dataclass(slots=True, frozen=True)
class ProbeScoringConfig:
    scoring_profile: str
    thermo_backend: str
    thermo_conditions: ThermoConditions
    max_dinucleotide_run: int | None
    min_sequence_entropy: float | None
    max_self_complementarity: int | None
    max_contiguous_self_complementarity: int | None
    max_hairpin_tm: float | None
    max_homodimer_tm: float | None
    region_score_weight: float
    thermo_penalty_weight: float

    def to_summary_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "profile": self.scoring_profile,
            "scoring_profile": self.scoring_profile,
            "thermo_backend": self.thermo_backend,
            "max_dinucleotide_run": self.max_dinucleotide_run,
            "min_sequence_entropy": self.min_sequence_entropy,
            "max_self_complementarity": self.max_self_complementarity,
            "max_contiguous_self_complementarity": self.max_contiguous_self_complementarity,
            "max_hairpin_tm": self.max_hairpin_tm,
            "max_homodimer_tm": self.max_homodimer_tm,
            "region_score_weight": self.region_score_weight,
            "thermo_penalty_weight": self.thermo_penalty_weight,
        }
        payload.update(self.thermo_conditions.to_summary_dict())
        return payload


@dataclass(slots=True, frozen=True)
class PanelInteractionConfig:
    scoring_profile: str
    interaction_backend: str
    thermo_conditions: ThermoConditions
    max_panel_contiguous_complementarity: int | None
    max_panel_heterodimer_tm: float | None
    panel_complementarity_penalty_weight: float
    panel_heterodimer_penalty_weight: float

    def to_summary_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "profile": self.scoring_profile,
            "panel_scoring_profile": self.scoring_profile,
            "interaction_backend": self.interaction_backend,
            "max_panel_contiguous_complementarity": self.max_panel_contiguous_complementarity,
            "max_panel_heterodimer_tm": self.max_panel_heterodimer_tm,
            "panel_complementarity_penalty_weight": self.panel_complementarity_penalty_weight,
            "panel_heterodimer_penalty_weight": self.panel_heterodimer_penalty_weight,
        }
        payload.update(self.thermo_conditions.to_summary_dict())
        return payload


@dataclass(slots=True, frozen=True)
class ProbeThermoMetrics:
    tm_basic: float
    tm_nn: float | None
    tm_selected: float
    tm_model: str
    sequence_entropy: float
    max_homopolymer: int
    max_dinucleotide_run: int
    self_complementarity: int
    contiguous_self_complementarity: int
    hairpin_tm: float | None
    homodimer_tm: float | None
    thermo_penalty: float


@dataclass(slots=True, frozen=True)
class PairInteractionMetrics:
    complementarity: int
    contiguous_complementarity: int
    heterodimer_tm: float | None


def validate_scoring_profile(name: str) -> str:
    normalized = str(name).strip().lower()
    if normalized not in VALID_SCORING_PROFILES:
        valid = ", ".join(sorted(VALID_SCORING_PROFILES))
        raise ValueError(f"Unsupported scoring profile '{name}'. Choose one of: {valid}.")
    return normalized


def validate_thermo_backend(name: str) -> str:
    normalized = str(name).strip().lower()
    if normalized not in VALID_THERMO_BACKENDS:
        valid = ", ".join(sorted(VALID_THERMO_BACKENDS))
        raise ValueError(f"Unsupported thermodynamic backend '{name}'. Choose one of: {valid}.")
    return normalized


def resolve_probe_scoring_config(
    *,
    scoring_profile: str,
    thermo_backend: str,
    thermo_conditions: ThermoConditions,
    max_dinucleotide_run: int | None,
    min_sequence_entropy: float | None,
    max_self_complementarity: int | None,
    max_contiguous_self_complementarity: int | None,
    max_hairpin_tm: float | None,
    max_homodimer_tm: float | None,
    region_score_weight: float | None,
    thermo_penalty_weight: float | None,
) -> ProbeScoringConfig:
    profile = validate_scoring_profile(scoring_profile)
    backend = validate_thermo_backend(thermo_backend)
    defaults = _probe_profile_defaults(profile)
    resolved_max_hairpin_tm = max_hairpin_tm if max_hairpin_tm is not None else defaults["max_hairpin_tm"]
    resolved_max_homodimer_tm = max_homodimer_tm if max_homodimer_tm is not None else defaults["max_homodimer_tm"]
    if backend != "primer3" and (resolved_max_hairpin_tm is not None or resolved_max_homodimer_tm is not None):
        raise ValueError("Hairpin and homodimer thresholds require --thermo-backend primer3.")
    if region_score_weight is not None and region_score_weight < 0.0:
        raise ValueError("--region-score-weight must be >= 0.")
    if thermo_penalty_weight is not None and thermo_penalty_weight < 0.0:
        raise ValueError("--thermo-penalty-weight must be >= 0.")
    resolved = ProbeScoringConfig(
        scoring_profile=profile,
        thermo_backend=backend,
        thermo_conditions=thermo_conditions,
        max_dinucleotide_run=max_dinucleotide_run if max_dinucleotide_run is not None else defaults["max_dinucleotide_run"],
        min_sequence_entropy=min_sequence_entropy if min_sequence_entropy is not None else defaults["min_sequence_entropy"],
        max_self_complementarity=max_self_complementarity if max_self_complementarity is not None else defaults["max_self_complementarity"],
        max_contiguous_self_complementarity=(
            max_contiguous_self_complementarity
            if max_contiguous_self_complementarity is not None
            else defaults["max_contiguous_self_complementarity"]
        ),
        max_hairpin_tm=resolved_max_hairpin_tm,
        max_homodimer_tm=resolved_max_homodimer_tm,
        region_score_weight=region_score_weight if region_score_weight is not None else defaults["region_score_weight"],
        thermo_penalty_weight=(
            thermo_penalty_weight if thermo_penalty_weight is not None else defaults["thermo_penalty_weight"]
        ),
    )
    _validate_probe_scoring_config(resolved)
    return resolved


def resolve_panel_interaction_config(
    *,
    scoring_profile: str,
    interaction_backend: str,
    thermo_conditions: ThermoConditions,
    max_panel_contiguous_complementarity: int | None,
    max_panel_heterodimer_tm: float | None,
    panel_complementarity_penalty_weight: float | None,
    panel_heterodimer_penalty_weight: float | None,
) -> PanelInteractionConfig:
    profile = validate_scoring_profile(scoring_profile)
    backend = validate_thermo_backend(interaction_backend)
    defaults = _panel_profile_defaults(profile)
    resolved_max_panel_heterodimer_tm = (
        max_panel_heterodimer_tm if max_panel_heterodimer_tm is not None else defaults["max_panel_heterodimer_tm"]
    )
    if backend != "primer3" and resolved_max_panel_heterodimer_tm is not None:
        raise ValueError("Panel heterodimer thresholds require --interaction-backend primer3.")
    if panel_complementarity_penalty_weight is not None and panel_complementarity_penalty_weight < 0.0:
        raise ValueError("--panel-complementarity-penalty-weight must be >= 0.")
    if panel_heterodimer_penalty_weight is not None and panel_heterodimer_penalty_weight < 0.0:
        raise ValueError("--panel-heterodimer-penalty-weight must be >= 0.")
    resolved = PanelInteractionConfig(
        scoring_profile=profile,
        interaction_backend=backend,
        thermo_conditions=thermo_conditions,
        max_panel_contiguous_complementarity=(
            max_panel_contiguous_complementarity
            if max_panel_contiguous_complementarity is not None
            else defaults["max_panel_contiguous_complementarity"]
        ),
        max_panel_heterodimer_tm=resolved_max_panel_heterodimer_tm,
        panel_complementarity_penalty_weight=(
            panel_complementarity_penalty_weight
            if panel_complementarity_penalty_weight is not None
            else defaults["panel_complementarity_penalty_weight"]
        ),
        panel_heterodimer_penalty_weight=(
            panel_heterodimer_penalty_weight
            if panel_heterodimer_penalty_weight is not None
            else defaults["panel_heterodimer_penalty_weight"]
        ),
    )
    _validate_panel_interaction_config(resolved)
    return resolved


def basic_tm(sequence: str) -> float:
    sequence = sequence.upper()
    gc = sum(1 for base in sequence if base in {"G", "C"})
    return 64.9 + (41.0 * (gc - 16.4) / float(len(sequence)))


def max_homopolymer_run(sequence: str) -> int:
    best = 0
    current = 0
    previous = None
    for base in sequence:
        if base == previous:
            current += 1
        else:
            current = 1
            previous = base
        if current > best:
            best = current
    return best


def max_dinucleotide_run(sequence: str) -> int:
    sequence = sequence.upper()
    if len(sequence) < 2:
        return 0
    best = 1
    for start in range(0, len(sequence) - 1):
        motif = sequence[start : start + 2]
        if len(motif) < 2:
            continue
        count = 1
        offset = start + 2
        while offset + 2 <= len(sequence) and sequence[offset : offset + 2] == motif:
            count += 1
            offset += 2
        if count > best:
            best = count
    return best


def sequence_entropy(sequence: str) -> float:
    sequence = sequence.upper()
    if not sequence:
        return 0.0
    counts = {base: sequence.count(base) for base in "ACGT"}
    entropy = 0.0
    length = float(len(sequence))
    for count in counts.values():
        if count <= 0:
            continue
        probability = count / length
        entropy -= probability * math.log2(probability)
    return entropy / 2.0


def reverse_complement(sequence: str) -> str:
    return sequence.translate(str.maketrans("ACGT", "TGCA"))[::-1]


def complementarity_metrics(sequence_a: str, sequence_b: str) -> tuple[int, int]:
    query = sequence_a.upper()
    target = reverse_complement(sequence_b.upper())
    if not query or not target:
        return 0, 0
    best_total = 0
    best_contiguous = 0
    for shift in range(-len(target) + 1, len(query)):
        total = 0
        contiguous = 0
        for query_index in range(len(query)):
            target_index = query_index - shift
            if 0 <= target_index < len(target) and query[query_index] == target[target_index]:
                total += 1
                contiguous += 1
                if contiguous > best_contiguous:
                    best_contiguous = contiguous
            else:
                contiguous = 0
        if total > best_total:
            best_total = total
    return best_total, best_contiguous


def compute_probe_thermo_metrics(
    sequence: str,
    *,
    backend: str,
    conditions: ThermoConditions,
) -> ProbeThermoMetrics:
    normalized = sequence.upper()
    tm_basic_value = basic_tm(normalized)
    tm_nn = None
    hairpin_tm = None
    homodimer_tm = None
    tm_model = "basic"
    if backend == "primer3":
        primer3 = _load_primer3(required=True)
        tm_nn = _primer3_tm(primer3, normalized, conditions)
        hairpin_tm = _primer3_structure_tm(primer3, "hairpin", normalized, conditions)
        homodimer_tm = _primer3_structure_tm(primer3, "homodimer", normalized, conditions)
        tm_model = "primer3"
    self_comp, contiguous_self_comp = complementarity_metrics(normalized, normalized)
    entropy = sequence_entropy(normalized)
    dinucleotide_run = max_dinucleotide_run(normalized)
    tm_selected = tm_basic_value if tm_nn is None else tm_nn
    thermo_penalty = (
        (self_comp / float(len(normalized)))
        + (contiguous_self_comp / float(len(normalized)))
        + max(0.0, 0.6 - entropy)
        + max(0.0, (dinucleotide_run - 2) / 4.0)
        + max(0.0, (hairpin_tm or 0.0) / max(1.0, conditions.hyb_temp_c))
        + max(0.0, (homodimer_tm or 0.0) / max(1.0, conditions.hyb_temp_c))
    )
    return ProbeThermoMetrics(
        tm_basic=tm_basic_value,
        tm_nn=tm_nn,
        tm_selected=tm_selected,
        tm_model=tm_model,
        sequence_entropy=entropy,
        max_homopolymer=max_homopolymer_run(normalized),
        max_dinucleotide_run=dinucleotide_run,
        self_complementarity=self_comp,
        contiguous_self_complementarity=contiguous_self_comp,
        hairpin_tm=hairpin_tm,
        homodimer_tm=homodimer_tm,
        thermo_penalty=thermo_penalty,
    )


def compute_pair_interaction_metrics(
    sequence_a: str,
    sequence_b: str,
    *,
    backend: str,
    conditions: ThermoConditions,
) -> PairInteractionMetrics:
    complementarity, contiguous = complementarity_metrics(sequence_a, sequence_b)
    heterodimer_tm = None
    if backend == "primer3":
        primer3 = _load_primer3(required=True)
        heterodimer_tm = _primer3_heterodimer_tm(primer3, sequence_a.upper(), sequence_b.upper(), conditions)
    return PairInteractionMetrics(
        complementarity=complementarity,
        contiguous_complementarity=contiguous,
        heterodimer_tm=heterodimer_tm,
    )


def ensure_backend_available(backend: str) -> None:
    resolved = validate_thermo_backend(backend)
    if resolved == "primer3":
        _load_primer3(required=True)


def _probe_profile_defaults(profile: str) -> dict[str, Any]:
    return get_stage_profile_defaults("probes", profile)


def _panel_profile_defaults(profile: str) -> dict[str, Any]:
    return get_stage_profile_defaults("panels", profile)


def _validate_probe_scoring_config(config: ProbeScoringConfig) -> None:
    if config.max_dinucleotide_run is not None and config.max_dinucleotide_run < 1:
        raise ValueError("--max-dinucleotide-run must be at least 1.")
    if config.min_sequence_entropy is not None and not (0.0 <= config.min_sequence_entropy <= 1.0):
        raise ValueError("--min-sequence-entropy must be between 0 and 1.")
    if config.max_self_complementarity is not None and config.max_self_complementarity < 1:
        raise ValueError("--max-self-complementarity must be at least 1.")
    if (
        config.max_contiguous_self_complementarity is not None
        and config.max_contiguous_self_complementarity < 1
    ):
        raise ValueError("--max-contiguous-self-complementarity must be at least 1.")


def _validate_panel_interaction_config(config: PanelInteractionConfig) -> None:
    if (
        config.max_panel_contiguous_complementarity is not None
        and config.max_panel_contiguous_complementarity < 1
    ):
        raise ValueError("--max-panel-contiguous-complementarity must be at least 1.")


@lru_cache(maxsize=1)
def _load_primer3(*, required: bool) -> Any:
    try:
        import primer3  # type: ignore[import-not-found]
    except ImportError as exc:
        if required:
            raise ValueError(
                "The primer3 backend was requested, but `primer3-py` is not installed. "
                "Install it and retry, or switch to --thermo-backend basic."
            ) from exc
        return None
    return primer3


def _primer3_tm(primer3: Any, sequence: str, conditions: ThermoConditions) -> float:
    return float(
        primer3.bindings.calc_tm(
            sequence,
            mv_conc=conditions.monovalent_salt_mM,
            dv_conc=conditions.divalent_salt_mM,
            dntp_conc=conditions.dntp_mM,
            dna_conc=conditions.probe_conc_nM,
        )
    )


def _primer3_structure_tm(primer3: Any, structure: str, sequence: str, conditions: ThermoConditions) -> float | None:
    calculator = getattr(primer3.bindings, f"calc_{structure}")
    result = calculator(
        sequence,
        mv_conc=conditions.monovalent_salt_mM,
        dv_conc=conditions.divalent_salt_mM,
        dntp_conc=conditions.dntp_mM,
        dna_conc=conditions.probe_conc_nM,
        temp_c=conditions.hyb_temp_c,
    )
    return _extract_structure_tm(result)


def _primer3_heterodimer_tm(
    primer3: Any,
    sequence_a: str,
    sequence_b: str,
    conditions: ThermoConditions,
) -> float | None:
    result = primer3.bindings.calc_heterodimer(
        sequence_a,
        sequence_b,
        mv_conc=conditions.monovalent_salt_mM,
        dv_conc=conditions.divalent_salt_mM,
        dntp_conc=conditions.dntp_mM,
        dna_conc=conditions.probe_conc_nM,
        temp_c=conditions.hyb_temp_c,
    )
    return _extract_structure_tm(result)


def _extract_structure_tm(result: Any) -> float | None:
    if result is None:
        return None
    tm = getattr(result, "tm", None)
    if tm is None:
        return None
    try:
        value = float(tm)
    except (TypeError, ValueError):
        return None
    if math.isnan(value):
        return None
    return value
