"""GTDB-native hierarchical tag design."""

from __future__ import annotations

import csv
from dataclasses import asdict, dataclass
import json
from math import comb
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from phyloprobe.gtdb import iter_taxonomy_records

DEFAULT_LEVELS = ("phylum", "class", "order", "family", "genus")
DEFAULT_ALPHABET = ("A", "T", "G", "C")

ProgressCallback = Callable[[str, Mapping[str, Any]], None]


@dataclass(slots=True, frozen=True)
class AggregatedTaxonomyPath:
    values: tuple[str | None, ...]
    weight: float


@dataclass(slots=True)
class PreparedTaxonomy:
    source_path: str
    levels: list[str]
    rows: list[AggregatedTaxonomyPath]
    metadata: dict[str, Any]

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


@dataclass(slots=True)
class _GroupState:
    rows: list[AggregatedTaxonomyPath]
    barcode: str
    positions_used: int
    lineage: tuple[str | None, ...]


@dataclass(slots=True)
class TagDesignResult:
    source_path: str
    positions: int
    alphabet: list[str]
    levels: list[str]
    objective_levels: list[str]
    level_weights: dict[str, float]
    enforce_stage_for_objective_levels: bool
    estimated_candidates: int
    evaluated_candidates: int
    prepared_taxonomy: dict[str, Any]
    level_positions: list[dict[str, Any]]
    coverage_summary: list[dict[str, Any]]
    stage_summary: list[dict[str, Any]]
    label_table: list[dict[str, Any]]
    final_leaf_labels: list[dict[str, Any]]
    fallback_leaf_labels: list[dict[str, Any]]
    search_table: list[dict[str, Any]]
    taxonomy_tree_entries: list[dict[str, Any]]
    taxonomy_tree_text: str
    objective: dict[str, Any]
    constraints: dict[str, Any]
    output_files: dict[str, str] | None = None

    def to_summary_dict(self) -> dict[str, object]:
        return {
            "source_path": self.source_path,
            "positions": self.positions,
            "alphabet": self.alphabet,
            "levels": self.levels,
            "objective_levels": self.objective_levels,
            "level_weights": self.level_weights,
            "enforce_stage_for_objective_levels": self.enforce_stage_for_objective_levels,
            "estimated_candidates": self.estimated_candidates,
            "evaluated_candidates": self.evaluated_candidates,
            "prepared_taxonomy": self.prepared_taxonomy,
            "level_positions": self.level_positions,
            "coverage_summary": self.coverage_summary,
            "stage_summary": self.stage_summary,
            "objective": self.objective,
            "constraints": self.constraints,
            "output_files": self.output_files,
        }


def parse_levels(levels_arg: str) -> list[str]:
    levels = [token.strip() for token in str(levels_arg).split(",") if token.strip()]
    if not levels:
        raise ValueError("At least one taxonomy level must be provided in --levels.")
    if len(set(levels)) != len(levels):
        raise ValueError("Taxonomy levels in --levels must not contain duplicates.")
    return levels


def parse_alphabet(spec: Sequence[str] | str | None) -> list[str]:
    if spec is None or spec == "":
        return list(DEFAULT_ALPHABET)

    raw_spec = spec if isinstance(spec, str) else ",".join(str(value) for value in spec)
    cleaned = str(raw_spec).strip()
    if cleaned.startswith("[") and cleaned.endswith("]"):
        cleaned = cleaned[1:-1].strip()

    tokens = [token.strip() for token in cleaned.split(",") if token.strip()]
    if not tokens:
        raise ValueError("--alphabet must define at least two symbols.")
    if len(tokens) < 2:
        raise ValueError("--alphabet must define at least two symbols.")

    alphabet: list[str] = []
    seen: set[str] = set()
    for token in tokens:
        if len(token) != 1:
            raise ValueError(
                "--alphabet symbols must each be exactly one character long."
            )
        if not token.isalnum():
            raise ValueError(
                "--alphabet symbols must each be a single letter or digit."
            )
        if token in seen:
            raise ValueError("--alphabet symbols must be unique.")
        seen.add(token)
        alphabet.append(token)
    return alphabet


def parse_maximise_levels(spec: str | None, levels: Sequence[str]) -> list[str]:
    if spec is None or spec == "" or spec == "all":
        return list(levels)

    resolved: list[str] = []
    for token in str(spec).split(","):
        level = token.strip()
        if level and level not in resolved:
            resolved.append(level)
    if not resolved:
        return list(levels)

    invalid = [level for level in resolved if level not in levels]
    if invalid:
        allowed = ", ".join([*levels, "all"])
        raise ValueError(
            f"--maximise-levels contains unknown level(s): {', '.join(invalid)}. Allowed: {allowed}"
        )
    return resolved


def parse_level_weights(spec: str | None, levels: Sequence[str]) -> dict[str, float]:
    weights = {level: 0.0 for level in levels}
    if spec is None or spec == "":
        return {}

    tokens = [token.strip() for token in str(spec).split(",") if token.strip()]
    for token in tokens:
        if ":" not in token:
            raise ValueError("--level-weights must use level:value items separated by commas.")
        level_name, raw_value = [part.strip() for part in token.split(":", maxsplit=1)]
        try:
            value = float(raw_value)
        except ValueError as exc:
            raise ValueError(f"Invalid weight value in --level-weights: {raw_value}") from exc
        if value < 0:
            raise ValueError(f"Invalid weight value in --level-weights: {raw_value}")
        if level_name == "all":
            for level in levels:
                weights[level] = value
        elif level_name in weights:
            weights[level_name] = value
        else:
            allowed = ", ".join([*levels, "all"])
            raise ValueError(
                f"Unknown level in --level-weights: {level_name}. Allowed: {allowed}"
            )

    if sum(weights.values()) <= 0:
        raise ValueError("--level-weights must assign a positive weight to at least one level.")
    return {level: value for level, value in weights.items() if value > 0}


def parse_min_taxa_per_level(spec: str | None, levels: Sequence[str]) -> dict[str, int]:
    requirements = {level: 0 for level in levels}
    if spec is None or spec == "":
        return requirements

    for token in str(spec).split(","):
        item = token.strip()
        if not item:
            continue
        if ":" not in item:
            raise ValueError("--min-taxa-per-level must use level:value items separated by commas.")
        level_name, raw_value = [part.strip() for part in item.split(":", maxsplit=1)]
        try:
            value = int(raw_value)
        except ValueError as exc:
            raise ValueError(
                f"Invalid minimum taxa value in --min-taxa-per-level: {raw_value}"
            ) from exc
        if value < 0:
            raise ValueError(
                f"Invalid minimum taxa value in --min-taxa-per-level: {raw_value}"
            )
        if level_name == "all":
            for level in levels:
                requirements[level] = max(requirements[level], value)
        elif level_name in requirements:
            requirements[level_name] = max(requirements[level_name], value)
        else:
            allowed = ", ".join([*levels, "all"])
            raise ValueError(
                f"Unknown level in --min-taxa-per-level: {level_name}. Allowed: {allowed}"
            )
    return requirements


def parse_taxon_constraints(
    specs: Sequence[str] | str | None,
    levels: Sequence[str],
    *,
    option_name: str,
) -> dict[str, set[str]]:
    if specs is None or specs == "":
        return {}

    raw_specs = [specs] if isinstance(specs, str) else list(specs)
    constraints = {level: set() for level in levels}
    for raw_spec in raw_specs:
        for token in str(raw_spec).split(","):
            item = token.strip()
            if not item:
                continue
            if ":" not in item:
                raise ValueError(
                    f"{option_name} must use level:taxon items separated by commas or repeated options."
                )
            level_name, taxon = [part.strip() for part in item.split(":", maxsplit=1)]
            if not level_name or not taxon:
                raise ValueError(f"{option_name} must use non-empty level:taxon items.")
            if level_name not in constraints:
                allowed = ", ".join(levels)
                raise ValueError(
                    f"{option_name} contains unknown level: {level_name}. Allowed: {allowed}"
                )
            constraints[level_name].add(taxon)

    return {level: taxa for level, taxa in constraints.items() if taxa}


def parse_descendant_rules(
    specs: Sequence[str] | str | None,
    levels: Sequence[str],
    *,
    option_name: str,
) -> dict[str, int]:
    if specs is None or specs == "":
        return {}

    raw_specs = [specs] if isinstance(specs, str) else list(specs)
    valid_levels = list(levels[:-1])
    if not valid_levels:
        raise ValueError(f"{option_name} requires at least two configured taxonomy levels.")

    rules = {level: 0 for level in valid_levels}
    for raw_spec in raw_specs:
        for token in str(raw_spec).split(","):
            item = token.strip()
            if not item:
                continue
            if ":" not in item:
                raise ValueError(
                    f"{option_name} must use level:count items separated by commas or repeated options."
                )
            level_name, raw_value = [part.strip() for part in item.split(":", maxsplit=1)]
            try:
                value = int(raw_value)
            except ValueError as exc:
                raise ValueError(f"Invalid descendant count in {option_name}: {raw_value}") from exc
            if value < 1:
                raise ValueError(f"Invalid descendant count in {option_name}: {raw_value}")
            if level_name == "all":
                for level in valid_levels:
                    rules[level] = max(rules[level], value)
            elif level_name in rules:
                rules[level_name] = max(rules[level_name], value)
            else:
                allowed = ", ".join([*valid_levels, "all"])
                raise ValueError(f"{option_name} contains unknown level: {level_name}. Allowed: {allowed}")

    return {level: value for level, value in rules.items() if value > 0}


def _resolve_taxon_constraints(
    constraints: Mapping[str, Sequence[str] | set[str]] | None,
    levels: Sequence[str],
    *,
    option_name: str,
) -> dict[str, set[str]]:
    if not constraints:
        return {}

    invalid = sorted(set(constraints) - set(levels))
    if invalid:
        allowed = ", ".join(levels)
        raise ValueError(
            f"{option_name} contains unknown level(s): {', '.join(invalid)}. Allowed: {allowed}"
        )

    resolved: dict[str, set[str]] = {}
    for level in levels:
        raw_taxa = constraints.get(level)
        if not raw_taxa:
            continue
        taxa = {str(taxon).strip() for taxon in raw_taxa if str(taxon).strip()}
        if taxa:
            resolved[level] = taxa
    return resolved


def _validate_taxon_constraint_overlap(
    include_taxa: Mapping[str, set[str]] | None,
    exclude_taxa: Mapping[str, set[str]] | None,
    *,
    conflict_message: str = "A taxon cannot be both included and excluded",
) -> None:
    include_taxa = include_taxa or {}
    exclude_taxa = exclude_taxa or {}
    overlaps: list[str] = []
    for level in sorted(set(include_taxa) | set(exclude_taxa)):
        shared = sorted(include_taxa.get(level, set()) & exclude_taxa.get(level, set()))
        overlaps.extend(f"{level}:{taxon}" for taxon in shared)
    if overlaps:
        raise ValueError(conflict_message + ": " + ", ".join(overlaps))


def _constraint_payload(
    exclusive_taxa: Mapping[str, set[str]] | None,
    include_taxa: Mapping[str, set[str]] | None,
    exclude_taxa: Mapping[str, set[str]] | None,
) -> dict[str, Any]:
    return {
        "exclusive_taxa": {
            level: sorted(taxa) for level, taxa in (exclusive_taxa or {}).items() if taxa
        },
        "include_taxa": {
            level: sorted(taxa) for level, taxa in (include_taxa or {}).items() if taxa
        },
        "exclude_taxa": {
            level: sorted(taxa) for level, taxa in (exclude_taxa or {}).items() if taxa
        },
    }


def _merge_taxon_constraints(
    *constraints: Mapping[str, set[str]] | None,
) -> dict[str, set[str]]:
    merged: dict[str, set[str]] = {}
    for constraint in constraints:
        if not constraint:
            continue
        for level, taxa in constraint.items():
            merged.setdefault(level, set()).update(taxa)
    return merged


def estimate_allocation_search_size(positions: int, levels: Sequence[str] | int) -> int:
    n_levels = levels if isinstance(levels, int) else len(levels)
    if positions < 0 or n_levels <= 0:
        raise ValueError("positions must be >= 0 and at least one level must be provided.")
    return comb(positions + n_levels - 1, n_levels - 1)


def generate_codes(n_positions: int, alphabet: Sequence[str] = DEFAULT_ALPHABET) -> list[str]:
    if n_positions <= 0:
        return []
    codes = [""]
    for _ in range(n_positions):
        codes = [prefix + base for base in alphabet for prefix in codes]
    return codes


def _emit_progress(progress_callback: ProgressCallback | None, event: str, **payload: Any) -> None:
    if progress_callback is not None:
        progress_callback(event, payload)


def _enumerate_allocations(total_positions: int, n_levels: int) -> list[tuple[int, ...]]:
    rows: list[tuple[int, ...]] = []

    def recurse(position: int, remaining: int, current: list[int]) -> None:
        if position == n_levels - 1:
            current[position] = remaining
            rows.append(tuple(current))
            return
        for value in range(remaining + 1):
            current[position] = value
            recurse(position + 1, remaining - value, current)

    recurse(0, total_positions, [0] * n_levels)
    return rows


def _rescale_01(values: Sequence[float]) -> list[float]:
    values = list(values)
    if not values:
        return []
    min_value = min(values)
    max_value = max(values)
    if min_value == max_value:
        return [0.0] * len(values)
    return [(value - min_value) / (max_value - min_value) for value in values]


def _count_distinct_non_missing(rows: Sequence[AggregatedTaxonomyPath], level_index: int) -> int:
    return len({row.values[level_index] for row in rows if row.values[level_index]})


def _sum_weight(rows: Sequence[AggregatedTaxonomyPath]) -> float:
    return float(sum(row.weight for row in rows))


def _count_total_taxa_by_level(rows: Sequence[AggregatedTaxonomyPath], levels: Sequence[str]) -> list[int]:
    counts: list[int] = []
    for level_index in range(len(levels)):
        prefixes = {
            row.values[: level_index + 1]
            for row in rows
            if all(value is not None for value in row.values[: level_index + 1])
        }
        counts.append(len(prefixes))
    return counts


def _covered_taxa_by_level(
    rows: Sequence[AggregatedTaxonomyPath],
    levels: Sequence[str],
    deepest_encoded_index: int,
) -> dict[str, set[str]]:
    covered: dict[str, set[str]] = {}
    for level_index, level in enumerate(levels):
        if level_index > deepest_encoded_index:
            covered[level] = set()
            continue
        covered[level] = {
            row.values[level_index]
            for row in rows
            if row.values[level_index] is not None
            and all(value is not None for value in row.values[: level_index + 1])
        }
    return covered


def _included_taxa_by_level(
    covered_taxa_by_level: Mapping[str, set[str]],
    include_taxa: Mapping[str, set[str]] | None,
    levels: Sequence[str],
) -> dict[str, set[str]]:
    include_taxa = include_taxa or {}
    covered_includes: dict[str, set[str]] = {}
    for level in levels:
        covered_includes[level] = set(covered_taxa_by_level.get(level, set())) & set(
            include_taxa.get(level, set())
        )
    return covered_includes


def _count_descendants_at_next_level(
    rows: Sequence[AggregatedTaxonomyPath],
    current_level_index: int,
) -> int:
    next_level_index = current_level_index + 1
    return len(
        {
            row.values[next_level_index]
            for row in rows
            if next_level_index < len(row.values) and row.values[next_level_index] is not None
        }
    )


def _child_supports_included_taxa(
    child_name: str,
    child_rows: Sequence[AggregatedTaxonomyPath],
    *,
    levels: Sequence[str],
    current_level_index: int,
    include_taxa: Mapping[str, set[str]] | None,
) -> bool:
    include_taxa = include_taxa or {}
    current_level = levels[current_level_index]
    if child_name in include_taxa.get(current_level, set()):
        return True
    for deeper_index in range(current_level_index + 1, len(levels)):
        requested = include_taxa.get(levels[deeper_index], set())
        if not requested:
            continue
        if any(row.values[deeper_index] in requested for row in child_rows):
            return True
    return False


def _resolve_level_weight_mapping(
    level_weights: Mapping[str, float] | None,
    levels: Sequence[str],
) -> dict[str, float]:
    if not level_weights:
        return {}

    invalid = sorted(set(level_weights) - set(levels))
    if invalid:
        allowed = ", ".join(levels)
        raise ValueError(
            f"level_weights contains unknown level(s): {', '.join(invalid)}. Allowed: {allowed}"
        )

    resolved: dict[str, float] = {}
    for level in levels:
        if level not in level_weights:
            continue
        value = float(level_weights[level])
        if value < 0:
            raise ValueError("level_weights must be non-negative for every level.")
        if value > 0:
            resolved[level] = value

    if level_weights and not resolved:
        raise ValueError("level_weights must assign a positive weight to at least one level.")
    return resolved


def _normalize_level_weights(raw_weights: Sequence[float]) -> list[float]:
    total_weight = float(sum(raw_weights))
    if total_weight <= 0:
        raise ValueError("At least one taxonomy level must have a positive objective weight.")
    return [float(weight) / total_weight for weight in raw_weights]


def _resolve_objective_weights(
    levels: Sequence[str],
    maximise_levels: Sequence[str],
    level_weights: Mapping[str, float] | None,
) -> tuple[list[float], list[str]]:
    if level_weights:
        raw_weights = [float(level_weights.get(level, 0.0)) for level in levels]
        objective_levels = [level for level, weight in zip(levels, raw_weights) if weight > 0]
        return _normalize_level_weights(raw_weights), objective_levels

    raw_weights = [1.0 if level in maximise_levels else 0.0 for level in levels]
    if sum(raw_weights) <= 0:
        raise ValueError("No objective levels were selected for tag design.")
    return _normalize_level_weights(raw_weights), list(maximise_levels)


def prepare_taxonomy(
    path: str | Path,
    levels: Sequence[str],
    *,
    exclusive_taxa: Mapping[str, Sequence[str] | set[str]] | None = None,
    exclude_taxa: Mapping[str, Sequence[str] | set[str]] | None = None,
) -> PreparedTaxonomy:
    taxonomy_path = Path(path).expanduser().resolve()
    resolved_exclusive_taxa = _resolve_taxon_constraints(
        exclusive_taxa,
        levels,
        option_name="exclusive_taxa",
    )
    resolved_exclude_taxa = _resolve_taxon_constraints(
        exclude_taxa,
        levels,
        option_name="exclude_taxa",
    )
    path_counts: dict[tuple[str | None, ...], int] = {}
    genome_count = 0
    retained_genome_count = 0
    exclusive_filtered_genome_count = 0
    excluded_genome_count = 0

    for record in iter_taxonomy_records(taxonomy_path):
        genome_count += 1
        values = tuple(record.ranks.get(level) for level in levels)
        if resolved_exclusive_taxa and not any(
            values[index] in resolved_exclusive_taxa.get(level, set())
            for index, level in enumerate(levels)
        ):
            exclusive_filtered_genome_count += 1
            continue
        if any(
            values[index] in resolved_exclude_taxa.get(level, set())
            for index, level in enumerate(levels)
        ):
            excluded_genome_count += 1
            continue
        retained_genome_count += 1
        path_counts[values] = path_counts.get(values, 0) + 1

    if genome_count == 0:
        raise ValueError("The GTDB taxonomy file is empty.")

    rows = [
        AggregatedTaxonomyPath(values=values, weight=float(weight))
        for values, weight in sorted(path_counts.items())
    ]
    metadata = {
        "genomes": genome_count,
        "genomes_retained": retained_genome_count,
        "genomes_exclusive_filtered": exclusive_filtered_genome_count,
        "genomes_excluded": excluded_genome_count,
        "unique_paths": len(path_counts),
        "levels": list(levels),
    }
    return PreparedTaxonomy(
        source_path=str(taxonomy_path),
        levels=list(levels),
        rows=rows,
        metadata=metadata,
    )


def _rank_children(
    child_groups: Mapping[str, list[AggregatedTaxonomyPath]],
    levels: Sequence[str],
    current_level_index: int,
    objective_indices: Sequence[int],
    include_taxa: Mapping[str, set[str]] | None = None,
    prefer_taxa: Mapping[str, set[str]] | None = None,
    avoid_taxa: Mapping[str, set[str]] | None = None,
    descendants_soft: Mapping[str, int] | None = None,
) -> list[str]:
    child_names = list(child_groups)
    include_taxa = include_taxa or {}
    prefer_taxa = prefer_taxa or {}
    avoid_taxa = avoid_taxa or {}
    descendants_soft = descendants_soft or {}
    current_level = levels[current_level_index]
    current_level_includes = include_taxa.get(current_level, set())
    current_level_prefers = prefer_taxa.get(current_level, set())
    current_level_avoids = avoid_taxa.get(current_level, set())
    deeper_include_indices = [
        index
        for index in range(current_level_index + 1, len(levels))
        if include_taxa.get(levels[index], set())
    ]
    deeper_prefer_indices = [
        index
        for index in range(current_level_index + 1, len(levels))
        if prefer_taxa.get(levels[index], set())
    ]
    deeper_avoid_indices = [
        index
        for index in range(current_level_index + 1, len(levels))
        if avoid_taxa.get(levels[index], set())
    ]
    abundance = {name: _sum_weight(child_groups[name]) for name in child_names}
    target_counts = {
        name: [_count_distinct_non_missing(child_groups[name], index) for index in objective_indices]
        for name in child_names
    }

    normalized_counts = {name: list(counts) for name, counts in target_counts.items()}
    for position in range(len(objective_indices)):
        scaled = _rescale_01([target_counts[name][position] for name in child_names])
        for row_index, name in enumerate(child_names):
            normalized_counts[name][position] = scaled[row_index]

    diversity_score = {}
    combined_counts = {}
    for name in child_names:
        combined_counts[name] = sum(target_counts[name])
        if normalized_counts[name]:
            diversity_score[name] = sum(normalized_counts[name]) / len(normalized_counts[name])
        else:
            diversity_score[name] = 0.0

    if all(value == 0.0 for value in diversity_score.values()):
        fallback = _rescale_01([combined_counts[name] for name in child_names])
        diversity_score = {name: fallback[index] for index, name in enumerate(child_names)}

    direct_include = {
        name: 1 if name in current_level_includes else 0 for name in child_names
    }
    descendant_include_hits = {
        name: sum(
            len(
                {
                    row.values[index]
                    for row in child_groups[name]
                    if row.values[index] in include_taxa.get(levels[index], set())
                }
            )
            for index in deeper_include_indices
        )
        for name in child_names
    }
    direct_prefer = {
        name: 1 if name in current_level_prefers else 0 for name in child_names
    }
    descendant_prefer_hits = {
        name: sum(
            len(
                {
                    row.values[index]
                    for row in child_groups[name]
                    if row.values[index] in prefer_taxa.get(levels[index], set())
                }
            )
            for index in deeper_prefer_indices
        )
        for name in child_names
    }
    direct_avoid = {
        name: 1 if name in current_level_avoids else 0 for name in child_names
    }
    descendant_avoid_hits = {
        name: sum(
            len(
                {
                    row.values[index]
                    for row in child_groups[name]
                    if row.values[index] in avoid_taxa.get(levels[index], set())
                }
            )
            for index in deeper_avoid_indices
        )
        for name in child_names
    }
    soft_descendant_match = {
        name: int(
            descendants_soft.get(current_level, 0) > 0
            and current_level_index < len(levels) - 1
            and _count_descendants_at_next_level(child_groups[name], current_level_index)
            >= descendants_soft[current_level]
        )
        for name in child_names
    }

    return sorted(
        child_names,
        key=lambda name: (
            -int(direct_include[name]),
            -int(descendant_include_hits[name]),
            -int(soft_descendant_match[name]),
            -int(direct_prefer[name]),
            -int(descendant_prefer_hits[name]),
            int(direct_avoid[name]),
            int(descendant_avoid_hits[name]),
            -float(diversity_score[name]),
            -int(combined_counts[name]),
            -float(abundance[name]),
            name,
        ),
    )


def _lineage_mapping(levels: Sequence[str], lineage: Sequence[str | None]) -> dict[str, str | None]:
    return {level: lineage[index] for index, level in enumerate(levels)}


def _parent_for_lineage_values(
    levels: Sequence[str],
    lineage: Sequence[str | None],
    resolved_index: int,
) -> tuple[str | None, str | None]:
    for level_index in range(resolved_index - 1, -1, -1):
        value = lineage[level_index]
        if value is not None:
            return levels[level_index], value
    return None, None


def _build_taxonomy_tree_entries(
    final_leaf_labels: Sequence[Mapping[str, Any]],
    label_table: Sequence[Mapping[str, Any]],
    levels: Sequence[str],
) -> list[dict[str, Any]]:
    if not final_leaf_labels:
        return []

    root: dict[str, Any] = {"children": {}, "selected_weight": None, "sort_weight": 0.0}
    selected_code_by_path: dict[tuple[tuple[str, str], ...], dict[str, str]] = {}
    selected_levels: set[str] = set()

    for row in label_table:
        selected_level = str(row.get("level") or "")
        if selected_level not in levels:
            continue
        stage_code = row.get("stage_code")
        barcode = row.get("barcode")
        if not stage_code or not barcode:
            continue
        selected_levels.add(selected_level)
        selected_index = levels.index(selected_level)
        path: list[tuple[str, str]] = []
        for level in levels[: selected_index + 1]:
            value = row.get(level)
            if not value:
                continue
            path.append((level, str(value)))
        if path:
            selected_code_by_path[tuple(path)] = {
                "barcode": str(barcode),
                "stage_code": str(stage_code),
            }

    for row in final_leaf_labels:
        current = root
        weight = float(row.get("genomes", 0.0) or 0.0)
        resolved_level = row.get("resolved_level")
        if resolved_level in levels:
            resolved_index = levels.index(str(resolved_level))
        else:
            present_levels = [index for index, level in enumerate(levels) if row.get(level)]
            if not present_levels:
                continue
            resolved_index = max(present_levels)

        path: list[tuple[str, str]] = []
        for level in levels[: resolved_index + 1]:
            value = row.get(level)
            if not value:
                continue
            path.append((level, str(value)))
        if not path:
            continue

        for path_index, (level, taxon) in enumerate(path):
            node = current["children"].setdefault(
                (level, taxon),
                {
                    "level": level,
                    "taxon": taxon,
                    "barcode": None,
                    "stage_code": None,
                    "selected_weight": None,
                    "sort_weight": 0.0,
                    "children": {},
                },
            )
            selected_path = tuple(item for item in path[: path_index + 1] if item[0] in selected_levels)
            selected_code = (
                selected_code_by_path.get(selected_path)
                if selected_path and level in selected_levels
                else None
            )
            if selected_code is not None:
                node["barcode"] = selected_code["barcode"]
                node["stage_code"] = selected_code["stage_code"]
            current = node
        current["selected_weight"] = (
            weight if current["selected_weight"] is None else float(current["selected_weight"]) + weight
        )

    def assign_sort_weight(node: dict[str, Any]) -> float:
        if node["selected_weight"] is not None:
            node["sort_weight"] = float(node["selected_weight"])
        else:
            node["sort_weight"] = sum(assign_sort_weight(child) for child in node["children"].values())
        return float(node["sort_weight"])

    assign_sort_weight(root)

    entries: list[dict[str, Any]] = []

    def collect(node: dict[str, Any], depth: int) -> None:
        children = sorted(
            node["children"].values(),
            key=lambda child: (-float(child["sort_weight"]), str(child["taxon"])),
        )
        for child in children:
            entries.append(
                {
                    "depth": depth,
                    "level": child["level"],
                    "barcode": child["barcode"],
                    "stage_code": child["stage_code"],
                    "taxon": child["taxon"],
                }
            )
            collect(child, depth + 1)

    collect(root, 0)
    return entries


def _build_taxonomy_tree_text(
    entries: Sequence[Mapping[str, Any]],
) -> str:
    if not entries:
        return "(no taxa selected)"
    tag_width = max((len(str(entry["barcode"])) for entry in entries if entry.get("barcode")), default=0)
    return "\n".join(
        (
            f"{str(entry['barcode']).ljust(tag_width)}  "
            if tag_width > 0 and entry.get("barcode")
            else (" " * tag_width + "  " if tag_width > 0 else "")
        )
        + f"{'  ' * int(entry['depth'])}- {entry['taxon']}"
        for entry in entries
    )


def simulate_allocation(
    rows: Sequence[AggregatedTaxonomyPath],
    levels: Sequence[str],
    allocation: Sequence[int],
    objective_levels: Sequence[str],
    objective_weights: Sequence[float],
    total_taxa: Sequence[int],
    include_taxa: Mapping[str, set[str]] | None = None,
    prefer_taxa: Mapping[str, set[str]] | None = None,
    avoid_taxa: Mapping[str, set[str]] | None = None,
    descendants_soft: Mapping[str, int] | None = None,
    descendants_hard: Mapping[str, int] | None = None,
    util_weight: float = 0.15,
    alphabet: Sequence[str] = DEFAULT_ALPHABET,
    fallbacks_per_target: int = 0,
    keep_labels: bool = False,
) -> dict[str, Any]:
    levels = list(levels)
    objective_indices = [levels.index(level) for level in objective_levels]
    groups = [_GroupState(rows=list(rows), barcode="", positions_used=0, lineage=tuple([None] * len(levels)))]
    global_total_slots = len(alphabet) ** sum(allocation)
    deepest_allocated_index = max((index for index, value in enumerate(allocation) if value > 0), default=-1)

    direct_covered_counts = [0] * len(levels)
    label_rows: list[dict[str, Any]] = []
    fallback_rows: list[dict[str, Any]] = []
    fallback_candidates_by_barcode: dict[str, list[dict[str, Any]]] = {}
    stage_summary_rows: list[dict[str, Any]] = []
    stage_number = 0

    for level_index, level_name in enumerate(levels):
        positions_here = allocation[level_index]
        if positions_here <= 0:
            continue

        stage_number += 1
        capacity = len(alphabet) ** positions_here
        stage_codes = generate_codes(positions_here, alphabet)
        next_groups: list[_GroupState] = []
        stage_total_slots = 0
        stage_used_slots = 0
        stage_covered = 0
        stage_parents_with_children = 0

        for group in groups:
            valid_rows = [row for row in group.rows if row.values[level_index] is not None]
            if not valid_rows:
                continue

            child_groups: dict[str, list[AggregatedTaxonomyPath]] = {}
            for row in valid_rows:
                child_groups.setdefault(str(row.values[level_index]), []).append(row)
            if not child_groups:
                continue

            if level_index < len(levels) - 1 and (descendants_hard or {}).get(level_name, 0) > 0:
                threshold = int((descendants_hard or {})[level_name])
                kept_child_groups: dict[str, list[AggregatedTaxonomyPath]] = {}
                for child_name, child_rows in child_groups.items():
                    descendant_count = _count_descendants_at_next_level(child_rows, level_index)
                    if descendant_count >= threshold or _child_supports_included_taxa(
                        child_name,
                        child_rows,
                        levels=levels,
                        current_level_index=level_index,
                        include_taxa=include_taxa,
                    ):
                        kept_child_groups[child_name] = child_rows
                child_groups = kept_child_groups
                if not child_groups:
                    continue

            stage_parents_with_children += 1
            stage_total_slots += capacity
            ranked_children = _rank_children(
                child_groups,
                levels,
                level_index,
                objective_indices,
                include_taxa,
                prefer_taxa,
                avoid_taxa,
                descendants_soft,
            )
            selected_names = ranked_children[:capacity]
            fallback_pool = ranked_children[capacity:]
            stage_used_slots += len(selected_names)
            stage_covered += len(selected_names)

            position_start = group.positions_used + 1
            position_end = group.positions_used + positions_here

            for selected_index, (stage_code, child_name) in enumerate(zip(stage_codes, selected_names)):
                child_rows = child_groups[child_name]
                lineage = list(group.lineage)
                lineage[level_index] = child_name
                barcode = f"{group.barcode}{stage_code}"
                next_groups.append(
                    _GroupState(
                        rows=child_rows,
                        barcode=barcode,
                        positions_used=group.positions_used + positions_here,
                        lineage=tuple(lineage),
                    )
                )
                if keep_labels:
                    row = {
                        "stage": stage_number,
                        "level": level_name,
                        "positions_in_stage": positions_here,
                        "position_start": position_start,
                        "position_end": position_end,
                        "parent_barcode": group.barcode,
                        "stage_code": stage_code,
                        "barcode": barcode,
                        "taxon": child_name,
                        "genomes": _sum_weight(child_rows),
                    }
                    row.update(_lineage_mapping(levels, lineage))
                    label_rows.append(row)
                    if (
                        level_index == deepest_allocated_index
                        and fallbacks_per_target > 0
                        and fallback_pool
                    ):
                        rotate_offset = selected_index % len(fallback_pool)
                        rotated_pool = fallback_pool[rotate_offset:] + fallback_pool[:rotate_offset]
                        parent_level, parent_taxon = _parent_for_lineage_values(
                            levels,
                            group.lineage,
                            level_index,
                        )
                        for fallback_name in rotated_pool[:fallbacks_per_target]:
                            fallback_lineage = list(group.lineage)
                            fallback_lineage[level_index] = fallback_name
                            fallback_row = {
                                "barcode": barcode,
                                "primary_resolved_level": level_name,
                                "primary_resolved_taxon": child_name,
                                "resolved_level": level_name,
                                "resolved_taxon": fallback_name,
                                "parent_level": parent_level,
                                "parent_taxon": parent_taxon,
                                "genomes": _sum_weight(child_groups[fallback_name]),
                            }
                            fallback_row.update(_lineage_mapping(levels, fallback_lineage))
                            fallback_candidates_by_barcode.setdefault(barcode, []).append(fallback_row)

        groups = next_groups
        direct_covered_counts[level_index] = stage_covered
        level_total = total_taxa[level_index]
        stage_summary_rows.append(
            {
                "stage": stage_number,
                "level": level_name,
                "positions_in_stage": positions_here,
                "capacity_per_parent": capacity,
                "parents_with_children": stage_parents_with_children,
                "stage_total_slots": stage_total_slots,
                "stage_used_slots": stage_used_slots,
                "stage_unused_slots": stage_total_slots - stage_used_slots,
                "covered_taxa": stage_covered,
                "total_taxa": level_total,
                "coverage_fraction": stage_covered / level_total if level_total > 0 else 0.0,
                "global_total_slots": global_total_slots,
            }
        )
        if not groups:
            break

    selected_rows = [row for group in groups for row in group.rows]
    deepest_encoded_index = deepest_allocated_index
    selected_prefix_counts = _count_total_taxa_by_level(selected_rows, levels)
    covered_counts = direct_covered_counts[:]
    if deepest_encoded_index >= 0:
        covered_counts[: deepest_encoded_index + 1] = selected_prefix_counts[: deepest_encoded_index + 1]

    coverage_fraction = [
        covered / total if total > 0 else 0.0
        for covered, total in zip(covered_counts, total_taxa)
    ]
    utilization = len(groups) / global_total_slots if global_total_slots > 0 else 0.0
    score = sum(objective_weights[index] * coverage_fraction[index] for index in range(len(levels)))
    score += util_weight * utilization
    covered_taxa_by_level = _covered_taxa_by_level(selected_rows, levels, deepest_encoded_index)
    included_taxa_by_level = _included_taxa_by_level(covered_taxa_by_level, include_taxa, levels)
    include_shortfall_by_level = {
        level: max(len((include_taxa or {}).get(level, set())) - len(included_taxa_by_level[level]), 0)
        for level in levels
    }
    include_shortfall = sum(include_shortfall_by_level.values())
    preferred_taxa_by_level = _included_taxa_by_level(covered_taxa_by_level, prefer_taxa, levels)
    avoided_taxa_by_level = _included_taxa_by_level(covered_taxa_by_level, avoid_taxa, levels)
    preferred_covered = sum(len(preferred_taxa_by_level[level]) for level in levels)
    avoided_covered = sum(len(avoided_taxa_by_level[level]) for level in levels)

    final_leaf_rows: list[dict[str, Any]] = []
    if keep_labels:
        for group in groups:
            resolved_index = max((idx for idx, value in enumerate(group.lineage) if value is not None), default=-1)
            resolved_level = levels[resolved_index] if resolved_index >= 0 else None
            resolved_taxon = group.lineage[resolved_index] if resolved_index >= 0 else None
            row = {
                "barcode": group.barcode,
                "resolved_level": resolved_level,
                "resolved_taxon": resolved_taxon,
                "genomes": _sum_weight(group.rows),
            }
            row.update(_lineage_mapping(levels, group.lineage))
            final_leaf_rows.append(row)
        final_leaf_rows.sort(key=lambda row: (-float(row["genomes"]), str(row["barcode"])))
        primary_identities = {
            tuple((row.get(level) or None) for level in levels)
            for row in final_leaf_rows
        }
        barcode_order = [str(row["barcode"]) for row in final_leaf_rows]
        used_fallback_identities = set(primary_identities)
        sanitized_candidates_by_barcode: dict[str, list[dict[str, Any]]] = {}
        for barcode in barcode_order:
            candidates: list[dict[str, Any]] = []
            seen_identities: set[tuple[str | None, ...]] = set()
            for row in fallback_candidates_by_barcode.get(barcode, []):
                identity = tuple((row.get(level) or None) for level in levels)
                if identity in primary_identities or identity in seen_identities:
                    continue
                seen_identities.add(identity)
                candidates.append(row)
            sanitized_candidates_by_barcode[barcode] = candidates

        fallback_rows = []
        for desired_rank in range(1, fallbacks_per_target + 1):
            for barcode in barcode_order:
                candidates = sanitized_candidates_by_barcode.get(barcode, [])
                for candidate_index, row in enumerate(candidates):
                    identity = tuple((row.get(level) or None) for level in levels)
                    if identity in used_fallback_identities:
                        continue
                    assigned_row = dict(row)
                    assigned_row["fallback_rank"] = desired_rank
                    fallback_rows.append(assigned_row)
                    used_fallback_identities.add(identity)
                    sanitized_candidates_by_barcode[barcode] = (
                        candidates[:candidate_index] + candidates[candidate_index + 1 :]
                    )
                    break
        label_rows.sort(key=lambda row: (int(row["stage"]), str(row["parent_barcode"]), str(row["stage_code"])))
        fallback_rows.sort(
            key=lambda row: (
                str(row["barcode"]),
                int(row["fallback_rank"]),
                str(row["resolved_taxon"]),
            )
        )

    return {
        "score": float(score),
        "utilization": float(utilization),
        "used_slots": len(groups),
        "total_slots": global_total_slots,
        "covered_counts": covered_counts,
        "covered_taxa_by_level": covered_taxa_by_level,
        "included_taxa_by_level": included_taxa_by_level,
        "include_shortfall_by_level": include_shortfall_by_level,
        "include_shortfall": int(include_shortfall),
        "preferred_taxa_by_level": preferred_taxa_by_level,
        "avoided_taxa_by_level": avoided_taxa_by_level,
        "preferred_covered": int(preferred_covered),
        "avoided_covered": int(avoided_covered),
        "coverage_fraction": coverage_fraction,
        "stage_summary": stage_summary_rows,
        "label_table": label_rows,
        "final_leaf_labels": final_leaf_rows,
        "fallback_leaf_labels": fallback_rows,
    }


def design_tags(
    taxonomy_path: str | Path,
    *,
    positions: int = 4,
    alphabet: Sequence[str] = DEFAULT_ALPHABET,
    levels: Sequence[str] = DEFAULT_LEVELS,
    maximise_levels: Sequence[str] | None = None,
    level_weights: Mapping[str, float] | None = None,
    min_taxa_required: Mapping[str, int] | None = None,
    exclusive_taxa: Mapping[str, Sequence[str] | set[str]] | None = None,
    include_taxa: Mapping[str, Sequence[str] | set[str]] | None = None,
    exclude_taxa: Mapping[str, Sequence[str] | set[str]] | None = None,
    prefer_taxa: Mapping[str, Sequence[str] | set[str]] | None = None,
    avoid_taxa: Mapping[str, Sequence[str] | set[str]] | None = None,
    descendants_soft: Mapping[str, int] | None = None,
    descendants_hard: Mapping[str, int] | None = None,
    fallbacks_per_target: int = 1,
    util_weight: float = 0.15,
    progress_callback: ProgressCallback | None = None,
) -> TagDesignResult:
    levels = list(levels)
    alphabet = parse_alphabet(alphabet)
    requested_objective_levels = list(maximise_levels or levels)
    exclusive_taxa_by_level = _resolve_taxon_constraints(
        exclusive_taxa,
        levels,
        option_name="exclusive_taxa",
    )
    include_taxa_by_level = _resolve_taxon_constraints(
        include_taxa,
        levels,
        option_name="include_taxa",
    )
    exclude_taxa_by_level = _resolve_taxon_constraints(
        exclude_taxa,
        levels,
        option_name="exclude_taxa",
    )
    prefer_taxa_by_level = _resolve_taxon_constraints(
        prefer_taxa,
        levels,
        option_name="prefer_taxa",
    )
    avoid_taxa_by_level = _resolve_taxon_constraints(
        avoid_taxa,
        levels,
        option_name="avoid_taxa",
    )
    descendants_soft_by_level = {
        level: int(value) for level, value in (descendants_soft or {}).items() if int(value) > 0
    }
    descendants_hard_by_level = {
        level: int(value) for level, value in (descendants_hard or {}).items() if int(value) > 0
    }
    resolved_level_weights = _resolve_level_weight_mapping(level_weights, levels)
    _validate_taxon_constraint_overlap(
        exclusive_taxa_by_level,
        exclude_taxa_by_level,
        conflict_message="A taxon cannot be both exclusive and excluded",
    )
    _validate_taxon_constraint_overlap(include_taxa_by_level, exclude_taxa_by_level)
    _validate_taxon_constraint_overlap(
        _merge_taxon_constraints(include_taxa_by_level, prefer_taxa_by_level),
        _merge_taxon_constraints(exclude_taxa_by_level, avoid_taxa_by_level),
        conflict_message="A taxon cannot be both positively requested and negatively requested",
    )
    if any(level not in levels for level in requested_objective_levels):
        allowed = ", ".join(levels)
        invalid = sorted(set(requested_objective_levels) - set(levels))
        raise ValueError(f"Unknown objective level(s): {', '.join(invalid)}. Allowed: {allowed}")
    if positions < 1:
        raise ValueError("--positions must be at least 1.")
    if fallbacks_per_target < 0:
        raise ValueError("--fallbacks-per-target must be at least 0.")

    _emit_progress(progress_callback, "preprocessing_started", levels=levels)
    prepared = prepare_taxonomy(
        taxonomy_path,
        levels,
        exclusive_taxa=exclusive_taxa_by_level,
        exclude_taxa=exclude_taxa_by_level,
    )
    _emit_progress(
        progress_callback,
        "preprocessing_completed",
        rows_retained=prepared.metadata["genomes_retained"],
        aggregated_taxonomy_paths=prepared.metadata["unique_paths"],
    )
    if not prepared.rows:
        raise ValueError("No taxonomy rows remain after exclusive/exclude_taxa constraints.")

    missing_exclusive_taxa: list[str] = []
    for level_index, level in enumerate(levels):
        missing = exclusive_taxa_by_level.get(level, set()) - {
            row.values[level_index] for row in prepared.rows if row.values[level_index] is not None
        }
        missing_exclusive_taxa.extend(f"{level}:{taxon}" for taxon in sorted(missing))
    if missing_exclusive_taxa:
        raise ValueError(
            "Exclusive taxa are not present after preprocessing: "
            + ", ".join(missing_exclusive_taxa)
        )

    missing_included_taxa: list[str] = []
    for level_index, level in enumerate(levels):
        missing = include_taxa_by_level.get(level, set()) - {
            row.values[level_index] for row in prepared.rows if row.values[level_index] is not None
        }
        missing_included_taxa.extend(f"{level}:{taxon}" for taxon in sorted(missing))
    if missing_included_taxa:
        raise ValueError(
            "Included taxa are not present after preprocessing: "
            + ", ".join(missing_included_taxa)
        )

    total_taxa = _count_total_taxa_by_level(prepared.rows, levels)
    objective_weights, objective_levels = _resolve_objective_weights(
        levels,
        requested_objective_levels,
        resolved_level_weights,
    )
    estimated_candidates = estimate_allocation_search_size(positions, levels)
    allocations = _enumerate_allocations(positions, len(levels))
    enforce_stage_for_objective_levels = len(objective_levels) < len(levels)
    minima = {level: int((min_taxa_required or {}).get(level, 0)) for level in levels}
    objective_weight_mapping = {
        level: float(weight) for level, weight in zip(levels, objective_weights)
    }

    _emit_progress(
        progress_callback,
        "search_started",
        total_candidates=len(allocations),
        positions=positions,
        levels=levels,
    )

    search_rows: list[dict[str, Any]] = []
    best_index: int | None = None
    best_relaxed_index: int | None = None
    best_score = float("-inf")
    best_preferred_covered = float("-inf")
    best_avoided_covered = float("inf")
    best_utilization = float("-inf")
    best_stage_shortfall = float("inf")
    best_include_shortfall = float("inf")
    best_total_shortfall = float("inf")
    best_relaxed_preferred_covered = float("-inf")
    best_relaxed_avoided_covered = float("inf")
    best_relaxed_score = float("-inf")
    best_relaxed_utilization = float("-inf")

    for candidate_index, allocation in enumerate(allocations, start=1):
        simulation = simulate_allocation(
            prepared.rows,
            levels,
            allocation,
            objective_levels,
            objective_weights,
            total_taxa,
            include_taxa=include_taxa_by_level,
            prefer_taxa=prefer_taxa_by_level,
            avoid_taxa=avoid_taxa_by_level,
            descendants_soft=descendants_soft_by_level,
            descendants_hard=descendants_hard_by_level,
            util_weight=util_weight,
            alphabet=alphabet,
            fallbacks_per_target=fallbacks_per_target,
            keep_labels=False,
        )
        stage_shortfall = 0
        if enforce_stage_for_objective_levels:
            stage_shortfall = sum(1 for level in objective_levels if allocation[levels.index(level)] == 0)
        shortfall_by_level = {
            level: max(minima[level] - simulation["covered_counts"][index], 0)
            for index, level in enumerate(levels)
        }
        total_shortfall = sum(shortfall_by_level.values())
        include_shortfall = int(simulation["include_shortfall"])
        preferred_covered = int(simulation["preferred_covered"])
        avoided_covered = int(simulation["avoided_covered"])
        feasible = total_shortfall == 0 and stage_shortfall == 0 and include_shortfall == 0

        search_row = {
            "candidate": candidate_index,
            "score": simulation["score"],
            "utilization": simulation["utilization"],
            "used_slots": simulation["used_slots"],
            "total_slots": simulation["total_slots"],
            "feasible": feasible,
            "stage_shortfall": stage_shortfall,
            "include_shortfall": include_shortfall,
            "total_shortfall": total_shortfall,
            "preferred_covered": preferred_covered,
            "avoided_covered": avoided_covered,
        }
        for level_index, level in enumerate(levels):
            included_taxa_required = len(include_taxa_by_level.get(level, set()))
            included_taxa_covered = len(simulation["included_taxa_by_level"][level])
            search_row[f"positions_{level}"] = allocation[level_index]
            search_row[f"covered_{level}"] = simulation["covered_counts"][level_index]
            search_row[f"coverage_{level}"] = simulation["coverage_fraction"][level_index]
            search_row[f"min_required_{level}"] = minima[level]
            search_row[f"include_required_{level}"] = included_taxa_required
            search_row[f"include_covered_{level}"] = included_taxa_covered
            search_row[f"include_shortfall_{level}"] = max(
                included_taxa_required - included_taxa_covered,
                0,
            )
        search_rows.append(search_row)

        if (
            best_relaxed_index is None
            or stage_shortfall < best_stage_shortfall
            or (
                stage_shortfall == best_stage_shortfall
                and include_shortfall < best_include_shortfall
            )
            or (
                stage_shortfall == best_stage_shortfall
                and include_shortfall == best_include_shortfall
                and total_shortfall < best_total_shortfall
            )
            or (
                stage_shortfall == best_stage_shortfall
                and include_shortfall == best_include_shortfall
                and total_shortfall == best_total_shortfall
                and preferred_covered > best_relaxed_preferred_covered
            )
            or (
                stage_shortfall == best_stage_shortfall
                and include_shortfall == best_include_shortfall
                and total_shortfall == best_total_shortfall
                and preferred_covered == best_relaxed_preferred_covered
                and avoided_covered < best_relaxed_avoided_covered
            )
            or (
                stage_shortfall == best_stage_shortfall
                and include_shortfall == best_include_shortfall
                and total_shortfall == best_total_shortfall
                and preferred_covered == best_relaxed_preferred_covered
                and avoided_covered == best_relaxed_avoided_covered
                and simulation["score"] > best_relaxed_score
            )
            or (
                stage_shortfall == best_stage_shortfall
                and include_shortfall == best_include_shortfall
                and total_shortfall == best_total_shortfall
                and preferred_covered == best_relaxed_preferred_covered
                and avoided_covered == best_relaxed_avoided_covered
                and simulation["score"] == best_relaxed_score
                and simulation["utilization"] > best_relaxed_utilization
            )
        ):
            best_relaxed_index = candidate_index - 1
            best_stage_shortfall = stage_shortfall
            best_include_shortfall = include_shortfall
            best_total_shortfall = total_shortfall
            best_relaxed_preferred_covered = preferred_covered
            best_relaxed_avoided_covered = avoided_covered
            best_relaxed_score = float(simulation["score"])
            best_relaxed_utilization = float(simulation["utilization"])

        if feasible and (
            best_index is None
            or simulation["score"] > best_score
            or (
                simulation["score"] == best_score
                and preferred_covered > best_preferred_covered
            )
            or (
                simulation["score"] == best_score
                and preferred_covered == best_preferred_covered
                and avoided_covered < best_avoided_covered
            )
            or (
                simulation["score"] == best_score
                and preferred_covered == best_preferred_covered
                and avoided_covered == best_avoided_covered
                and simulation["utilization"] > best_utilization
            )
        ):
            best_index = candidate_index - 1
            best_score = float(simulation["score"])
            best_preferred_covered = preferred_covered
            best_avoided_covered = avoided_covered
            best_utilization = float(simulation["utilization"])

        _emit_progress(
            progress_callback,
            "search_advanced",
            completed=candidate_index,
            total_candidates=len(allocations),
        )

    if best_index is None:
        assert best_relaxed_index is not None
        closest = search_rows[best_relaxed_index]
        raise ValueError(
            "No feasible allocation satisfies current constraints. "
            f"Closest candidate={closest['candidate']} "
            f"stage_shortfall={closest['stage_shortfall']} "
            f"include_shortfall={closest['include_shortfall']} "
            f"taxa_shortfall={closest['total_shortfall']}."
        )

    best_allocation = allocations[best_index]
    _emit_progress(
        progress_callback,
        "search_completed",
        total_candidates=len(allocations),
        best_candidate=best_index + 1,
        best_allocation=list(best_allocation),
    )
    _emit_progress(
        progress_callback,
        "finalizing_design",
        best_candidate=best_index + 1,
        best_allocation=list(best_allocation),
    )

    best_simulation = simulate_allocation(
        prepared.rows,
        levels,
        best_allocation,
        objective_levels,
        objective_weights,
        total_taxa,
        include_taxa=include_taxa_by_level,
        prefer_taxa=prefer_taxa_by_level,
        avoid_taxa=avoid_taxa_by_level,
        descendants_soft=descendants_soft_by_level,
        descendants_hard=descendants_hard_by_level,
        util_weight=util_weight,
        alphabet=alphabet,
        fallbacks_per_target=fallbacks_per_target,
        keep_labels=True,
    )
    level_positions: list[dict[str, Any]] = []
    stage_summary_by_level = {
        str(row["level"]): row for row in best_simulation["stage_summary"]
    }
    stage_counter = 0
    for level_index, level in enumerate(levels):
        positions_allocated = best_allocation[level_index]
        stage = None
        if positions_allocated > 0:
            stage_counter += 1
            stage = stage_counter
        stage_summary_row = stage_summary_by_level.get(level, {})
        available_slots = int(stage_summary_row.get("stage_total_slots", 0) or 0)
        used_slots = int(stage_summary_row.get("stage_used_slots", 0) or 0)
        unused_slots = int(stage_summary_row.get("stage_unused_slots", 0) or 0)
        level_positions.append(
            {
                "level": level,
                "positions_allocated": positions_allocated,
                "stage": stage,
                "capacity_per_parent": len(alphabet) ** positions_allocated if positions_allocated > 0 else 0,
                "available_slots": available_slots,
                "used_slots": used_slots,
                "unused_slots": unused_slots,
                "slot_utilization": used_slots / available_slots if available_slots > 0 else 0.0,
            }
        )

    coverage_summary = [
        {
            "level": level,
            "level_weight": objective_weight_mapping[level],
            "total_taxa": total_taxa[level_index],
            "min_required": minima[level],
            "covered_taxa": best_simulation["covered_counts"][level_index],
            "coverage_fraction": best_simulation["coverage_fraction"][level_index],
            "meets_min_required": best_simulation["covered_counts"][level_index] >= minima[level],
            "included_taxa_required": len(include_taxa_by_level.get(level, set())),
            "included_taxa_covered": len(best_simulation["included_taxa_by_level"][level]),
            "meets_include_requirement": best_simulation["include_shortfall_by_level"][level] == 0,
        }
        for level_index, level in enumerate(levels)
    ]
    search_rows.sort(
        key=lambda row: (
            not bool(row["feasible"]),
            int(row["stage_shortfall"]),
            int(row["include_shortfall"]),
            int(row["total_shortfall"]),
            -int(row["preferred_covered"]),
            int(row["avoided_covered"]),
            -float(row["score"]),
            -float(row["utilization"]),
        )
    )
    taxonomy_tree_entries = _build_taxonomy_tree_entries(
        best_simulation["final_leaf_labels"],
        best_simulation["label_table"],
        levels,
    )
    taxonomy_tree_text = _build_taxonomy_tree_text(taxonomy_tree_entries)

    return TagDesignResult(
        source_path=prepared.source_path,
        positions=positions,
        alphabet=list(alphabet),
        levels=levels,
        objective_levels=objective_levels,
        level_weights=objective_weight_mapping,
        enforce_stage_for_objective_levels=enforce_stage_for_objective_levels,
        estimated_candidates=estimated_candidates,
        evaluated_candidates=len(allocations),
        prepared_taxonomy=prepared.metadata,
        level_positions=level_positions,
        coverage_summary=coverage_summary,
        stage_summary=best_simulation["stage_summary"],
        label_table=best_simulation["label_table"],
        final_leaf_labels=best_simulation["final_leaf_labels"],
        fallback_leaf_labels=best_simulation["fallback_leaf_labels"],
        search_table=search_rows,
        taxonomy_tree_entries=taxonomy_tree_entries,
        taxonomy_tree_text=taxonomy_tree_text,
        objective={
            "score": best_simulation["score"],
            "utilization": best_simulation["utilization"],
            "used_slots": best_simulation["used_slots"],
            "total_slots": best_simulation["total_slots"],
        },
        constraints={
            **_constraint_payload(exclusive_taxa_by_level, include_taxa_by_level, exclude_taxa_by_level),
            "prefer_taxa": {
                level: sorted(taxa) for level, taxa in prefer_taxa_by_level.items() if taxa
            },
            "avoid_taxa": {
                level: sorted(taxa) for level, taxa in avoid_taxa_by_level.items() if taxa
            },
            "descendants": {
                level: int(value) for level, value in descendants_soft_by_level.items()
            },
            "descendants_hard": {
                level: int(value) for level, value in descendants_hard_by_level.items()
            },
            "fallbacks_per_target": int(fallbacks_per_target),
        },
    )


def _write_csv(path: Path, rows: Sequence[Mapping[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    rows = list(rows)
    if rows:
        fieldnames: list[str] = []
        for row in rows:
            for key in row.keys():
                if key not in fieldnames:
                    fieldnames.append(key)
    else:
        fieldnames = []

    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        if fieldnames:
            writer.writeheader()
            for row in rows:
                writer.writerow({key: row.get(key) for key in fieldnames})


def write_tag_design_outputs(result: TagDesignResult, output_prefix: str | Path) -> dict[str, Path]:
    output_prefix = Path(output_prefix)
    output_prefix.parent.mkdir(parents=True, exist_ok=True)

    paths = {
        "summary": output_prefix.with_name(f"{output_prefix.name}_summary.json"),
        "level_positions": output_prefix.with_name(f"{output_prefix.name}_level_positions.csv"),
        "coverage": output_prefix.with_name(f"{output_prefix.name}_coverage_summary.csv"),
        "stage": output_prefix.with_name(f"{output_prefix.name}_stage_summary.csv"),
        "labels": output_prefix.with_name(f"{output_prefix.name}_label_table.csv"),
        "leaves": output_prefix.with_name(f"{output_prefix.name}_final_leaf_labels.csv"),
        "fallbacks": output_prefix.with_name(f"{output_prefix.name}_fallback_leaf_labels.csv"),
        "search": output_prefix.with_name(f"{output_prefix.name}_allocation_search.csv"),
        "taxonomy_tree": output_prefix.with_name(f"{output_prefix.name}_taxonomy_tree.txt"),
    }

    _write_csv(paths["level_positions"], result.level_positions)
    _write_csv(paths["coverage"], result.coverage_summary)
    _write_csv(paths["stage"], result.stage_summary)
    _write_csv(paths["labels"], result.label_table)
    _write_csv(paths["leaves"], result.final_leaf_labels)
    _write_csv(paths["fallbacks"], result.fallback_leaf_labels)
    _write_csv(paths["search"], result.search_table)
    paths["taxonomy_tree"].write_text(result.taxonomy_tree_text + "\n", encoding="utf-8")

    result.output_files = {name: str(path.resolve()) for name, path in paths.items()}
    with paths["summary"].open("w", encoding="utf-8") as handle:
        json.dump(result.to_summary_dict(), handle, indent=2, sort_keys=True)
        handle.write("\n")
    return paths
