"""Panel selection from ranked probe candidates."""

from __future__ import annotations

import csv
from dataclasses import dataclass
import json
from pathlib import Path
import re
import sys
import tarfile
from typing import Any, Callable, Mapping, Sequence

from phyloprobe.gtdb import iter_taxonomy_records
from phyloprobe.indexing import (
    DEFAULT_FULGOR_THREADS,
    DEFAULT_INDEX_PENALTY_WEIGHT,
    load_index_summary,
    load_reference_map,
    query_fulgor_index,
)
from phyloprobe.matching import (
    DEFAULT_MAX_MISMATCHES,
    DEFAULT_MISMATCH_PENALTY_PER_MISMATCH,
    MatchConfig,
    evaluate_query_against_accessions,
    validate_match_config,
)
from phyloprobe.parallel import DEFAULT_AUTO_WORKERS, build_chunks, iter_chunk_results, resolve_worker_count
from phyloprobe.taxon_scope import (
    taxon_constraint_payload,
    taxonomy_record_matches_scope,
    validate_taxon_constraint_overlap,
)
from phyloprobe.thermo import (
    DEFAULT_DNTP_MM,
    DEFAULT_HYB_TEMP_C,
    DEFAULT_MONOVALENT_SALT_MM,
    DEFAULT_DIVALENT_SALT_MM,
    DEFAULT_PANEL_COMPLEMENTARITY_PENALTY_WEIGHT,
    DEFAULT_PANEL_HETERODIMER_PENALTY_WEIGHT,
    DEFAULT_PROBE_CONC_NM,
    DEFAULT_SCORING_PROFILE,
    DEFAULT_THERMO_BACKEND,
    PanelInteractionConfig,
    ThermoConditions,
    compute_pair_interaction_metrics,
    ensure_backend_available,
    resolve_panel_interaction_config,
)

ProgressCallback = Callable[[str, Mapping[str, Any]], None]

DEFAULT_MAX_PROBES_PER_PANEL = 10
DEFAULT_MAX_PROBES_PER_MARKER = 5
DEFAULT_MAX_PROBES_PER_REGION = 2
DEFAULT_PANEL_BASE_SCORE_WEIGHT = 0.25
DEFAULT_SIBLING_PENALTY_WEIGHT = 2.0
DEFAULT_GLOBAL_PENALTY_WEIGHT = 1.0


@dataclass(slots=True, frozen=True)
class PanelTargetRequest:
    barcode: str
    resolved_level: str
    resolved_taxon: str
    lineage: dict[str, str | None]


@dataclass(slots=True)
class ProbePanelRequest:
    barcode: str
    resolved_level: str
    resolved_taxon: str
    marker_id: str
    aligned_start: int
    aligned_end: int
    region_rank_within_target_marker: int
    rank_within_region: int
    probe_sequence: str
    target_subsequence: str
    probe_score: float
    gc_fraction: float | None
    tm_basic: float | None
    tm_nn: float | None
    tm_selected: float | None
    tm_model: str | None
    sequence_entropy: float | None
    max_homopolymer: int | None
    max_dinucleotide_run: int | None
    self_complementarity: int | None
    contiguous_self_complementarity: int | None
    hairpin_tm: float | None
    homodimer_tm: float | None
    thermo_penalty: float | None
    lineage: dict[str, str | None]
    source_accession: str | None
    source_nt_start: int | None
    source_nt_end: int | None

    @property
    def target_key(self) -> tuple[str, str, str]:
        return (self.barcode, self.resolved_level, self.resolved_taxon)

    @property
    def region_key(self) -> tuple[str, int, int]:
        return (self.marker_id, self.aligned_start, self.aligned_end)


@dataclass(slots=True)
class _ResolvedPanelContext:
    request: PanelTargetRequest
    taxonomy_accessions: set[str]
    sibling_accessions: set[str]
    global_accessions: set[str]
    inferred_lineage: dict[str, str | None]
    parent_level: str | None
    parent_taxon: str | None


@dataclass(slots=True)
class MarkerNucleotideProfile:
    marker_id: str
    member_name: str
    sequences: dict[str, str]


@dataclass(slots=True)
class _CandidateEvaluation:
    request: ProbePanelRequest
    context: _ResolvedPanelContext
    target_available: set[str]
    sibling_available: set[str]
    global_available: set[str]
    target_hits: set[str]
    sibling_hits: set[str]
    global_hits: set[str]
    target_support_by_accession: dict[str, float]
    sibling_support_by_accession: dict[str, float]
    global_support_by_accession: dict[str, float]
    target_genome_available: set[str]
    sibling_genome_available: set[str]
    global_genome_available: set[str]
    target_genome_hits: set[str]
    sibling_genome_hits: set[str]
    global_genome_hits: set[str]
    index_available_by_label: dict[str, set[str]]
    index_hits_by_label: dict[str, set[str]]
    external_index_available_by_label: dict[str, set[str]]
    external_index_hits_by_label: dict[str, set[str]]
    base_utility: float
    row: dict[str, Any]


@dataclass(slots=True)
class _PanelSelectionOutcome:
    summary_row: dict[str, Any]
    selected_rows: list[dict[str, Any]]


@dataclass(slots=True)
class PanelDesignResult:
    dataset: str | None
    index_dataset: str | None
    index_datasets: list[str]
    taxonomy_file: str
    markers_archive: str
    probe_design_prefix: str
    index_file: str | None
    index_reference_map_file: str | None
    index_summary_file: str | None
    index_files: list[str]
    index_reference_map_files: list[str]
    index_summary_files: list[str]
    index_labels: list[str]
    selected_panels: list[dict[str, Any]]
    panel_candidates: list[dict[str, Any]]
    panel_probe_manifest: list[dict[str, Any]]
    analyzed_markers: int
    include_taxa: dict[str, list[str]]
    exclude_taxa: dict[str, list[str]]
    max_probes_per_panel: int
    max_probes_per_marker: int
    max_probes_per_region: int
    allow_overlaps: bool
    base_score_weight: float
    sibling_penalty_weight: float
    global_penalty_weight: float
    genome_index_penalty_weight: float
    interaction_config: PanelInteractionConfig
    match_config: MatchConfig
    output_files: dict[str, str] | None = None

    def to_summary_dict(self) -> dict[str, object]:
        summary: dict[str, object] = {
            "dataset": self.dataset,
            "index_dataset": self.index_dataset,
            "index_datasets": self.index_datasets,
            "taxonomy_file": self.taxonomy_file,
            "markers_archive": self.markers_archive,
            "probe_design_prefix": self.probe_design_prefix,
            "index_file": self.index_file,
            "index_reference_map_file": self.index_reference_map_file,
            "index_summary_file": self.index_summary_file,
            "index_files": self.index_files,
            "index_reference_map_files": self.index_reference_map_files,
            "index_summary_files": self.index_summary_files,
            "index_labels": self.index_labels,
            "selected_panels": self.selected_panels,
            "analyzed_markers": self.analyzed_markers,
            "include_taxa": self.include_taxa,
            "exclude_taxa": self.exclude_taxa,
            "max_probes_per_panel": self.max_probes_per_panel,
            "max_probes_per_marker": self.max_probes_per_marker,
            "max_probes_per_region": self.max_probes_per_region,
            "allow_overlaps": self.allow_overlaps,
            "base_score_weight": self.base_score_weight,
            "sibling_penalty_weight": self.sibling_penalty_weight,
            "global_penalty_weight": self.global_penalty_weight,
            "genome_index_penalty_weight": self.genome_index_penalty_weight,
            "output_files": self.output_files,
        }
        summary.update(self.interaction_config.to_summary_dict())
        summary.update(self.match_config.to_summary_dict())
        return summary


@dataclass(slots=True, frozen=True)
class _GenomeIndexResource:
    label: str
    dataset_name: str | None
    index_file: str
    reference_map_file: str
    summary_file: str
    kmer_length: int | None
    identifiers: set[str]


def _emit_progress(progress_callback: ProgressCallback | None, event: str, **payload: Any) -> None:
    if progress_callback is not None:
        progress_callback(event, payload)


def _slugify_index_label(value: str) -> str:
    normalized = re.sub(r"[^A-Za-z0-9]+", "_", value.strip().lower()).strip("_")
    return normalized or "index"


def _make_unique_index_label(candidate: str, used: set[str]) -> str:
    label = _slugify_index_label(candidate)
    if label not in used:
        used.add(label)
        return label
    suffix = 2
    while f"{label}_{suffix}" in used:
        suffix += 1
    unique_label = f"{label}_{suffix}"
    used.add(unique_label)
    return unique_label


def _resolve_index_label(
    dataset_name: str | None,
    summary_file: str | Path,
    taxon: str | None,
    release: str | None,
    *,
    used: set[str],
) -> str:
    if dataset_name:
        return _make_unique_index_label(dataset_name, used)
    stem = Path(summary_file).expanduser().resolve().stem
    if stem.endswith("_summary"):
        stem = stem[: -len("_summary")]
    label_source = stem
    if not label_source and taxon:
        label_source = taxon
    if not label_source and release:
        label_source = release
    return _make_unique_index_label(label_source or "index", used)


def _build_index_resources(
    *,
    index_datasets: Sequence[str] | None,
    index_files: Sequence[str | Path] | None,
    index_reference_map_files: Sequence[str | Path] | None,
    index_summary_files: Sequence[str | Path] | None,
) -> list[_GenomeIndexResource]:
    dataset_names = list(index_datasets or [])
    resolved_index_files = [str(Path(path).expanduser().resolve()) for path in (index_files or [])]
    resolved_reference_maps = [str(Path(path).expanduser().resolve()) for path in (index_reference_map_files or [])]
    resolved_summaries = [str(Path(path).expanduser().resolve()) for path in (index_summary_files or [])]
    used_labels: set[str] = set()
    resources: list[_GenomeIndexResource] = []
    for index_position, summary_file in enumerate(resolved_summaries):
        config = load_index_summary(summary_file)
        label = _resolve_index_label(
            dataset_names[index_position] if index_position < len(dataset_names) else None,
            summary_file,
            config.taxon,
            config.release,
            used=used_labels,
        )
        identifiers = set(load_reference_map(resolved_reference_maps[index_position]).values())
        resources.append(
            _GenomeIndexResource(
                label=label,
                dataset_name=dataset_names[index_position] if index_position < len(dataset_names) else None,
                index_file=resolved_index_files[index_position],
                reference_map_file=resolved_reference_maps[index_position],
                summary_file=summary_file,
                kmer_length=config.kmer_length,
                identifiers=identifiers,
            )
        )
    return resources


_PANEL_CANDIDATE_STATE: tuple[
    Sequence[ProbePanelRequest],
    Mapping[tuple[str, str, str], _ResolvedPanelContext],
    Mapping[str, MarkerNucleotideProfile],
    Mapping[str, Mapping[str, set[str]]] | None,
    Mapping[str, set[str]] | None,
    float,
    float,
    float,
    float,
    MatchConfig,
] | None = None
_PANEL_SELECTION_STATE: tuple[
    Sequence[tuple[str, str, str]],
    Mapping[tuple[str, str, str], _ResolvedPanelContext],
    Mapping[tuple[str, str, str], Sequence[_CandidateEvaluation]],
    int,
    int,
    int,
    bool,
    float,
    float,
    float,
    float,
    PanelInteractionConfig,
] | None = None


def _read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def _read_probe_panel_requests(
    probe_design_prefix: str | Path,
) -> tuple[list[str], list[ProbePanelRequest], dict[str, Any]]:
    prefix = Path(probe_design_prefix).expanduser().resolve()
    summary_path = prefix.with_name(f"{prefix.name}_summary.json")
    manifest_path = prefix.with_name(f"{prefix.name}_top_probe_manifest.csv")
    if not summary_path.exists():
        raise ValueError(f"Probe-design summary file not found: {summary_path}")
    if not manifest_path.exists():
        raise ValueError(f"Probe-design top probe manifest file not found: {manifest_path}")

    probe_summary = _read_json(summary_path)
    region_prefix = Path(str(probe_summary.get("region_discovery_prefix") or "")).expanduser().resolve()
    region_summary_path = region_prefix.with_name(f"{region_prefix.name}_summary.json")
    if not region_summary_path.exists():
        raise ValueError(f"Region-discovery summary file not found from probe-design context: {region_summary_path}")
    region_summary = _read_json(region_summary_path)
    target_prefix = Path(str(region_summary.get("target_discovery_prefix") or "")).expanduser().resolve()
    target_summary_path = target_prefix.with_name(f"{target_prefix.name}_summary.json")
    if not target_summary_path.exists():
        raise ValueError(f"Target-discovery summary file not found from panel-design context: {target_summary_path}")
    target_summary = _read_json(target_summary_path)
    tag_prefix = Path(str(target_summary.get("tag_design_prefix") or "")).expanduser().resolve()
    tag_summary_path = tag_prefix.with_name(f"{tag_prefix.name}_summary.json")
    if not tag_summary_path.exists():
        raise ValueError(f"Tag-design summary file not found from panel-design context: {tag_summary_path}")
    tag_summary = _read_json(tag_summary_path)
    levels = list(tag_summary.get("levels") or [])
    if not levels:
        raise ValueError(f"Tag-design summary does not contain levels: {tag_summary_path}")

    requests: list[ProbePanelRequest] = []
    with manifest_path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            barcode = (row.get("barcode") or "").strip()
            resolved_level = (row.get("resolved_level") or "").strip()
            resolved_taxon = (row.get("resolved_taxon") or "").strip()
            marker_id = (row.get("marker_id") or "").strip()
            probe_sequence = (row.get("probe_sequence") or "").strip()
            target_subsequence = (row.get("target_subsequence") or "").strip().upper()
            if not barcode or not resolved_level or not resolved_taxon or not marker_id or not probe_sequence or not target_subsequence:
                continue
            lineage = {}
            for level in levels:
                value = (row.get(level) or "").strip()
                lineage[level] = value or None
            try:
                request = ProbePanelRequest(
                    barcode=barcode,
                    resolved_level=resolved_level,
                    resolved_taxon=resolved_taxon,
                    marker_id=marker_id,
                    aligned_start=int(row.get("aligned_start") or 0),
                    aligned_end=int(row.get("aligned_end") or 0),
                    region_rank_within_target_marker=int(row.get("region_rank_within_target_marker") or 0),
                    rank_within_region=int(row.get("rank_within_region") or 0),
                    probe_sequence=probe_sequence,
                    target_subsequence=target_subsequence,
                    probe_score=float(row.get("score") or 0.0),
                    gc_fraction=None if row.get("gc_fraction") in (None, "") else float(row.get("gc_fraction")),
                    tm_basic=None if row.get("tm_basic") in (None, "") else float(row.get("tm_basic")),
                    tm_nn=None if row.get("tm_nn") in (None, "") else float(row.get("tm_nn")),
                    tm_selected=None if row.get("tm_selected") in (None, "") else float(row.get("tm_selected")),
                    tm_model=(row.get("tm_model") or "").strip() or None,
                    sequence_entropy=(
                        None if row.get("sequence_entropy") in (None, "") else float(row.get("sequence_entropy"))
                    ),
                    max_homopolymer=(
                        None if row.get("max_homopolymer") in (None, "") else int(row.get("max_homopolymer"))
                    ),
                    max_dinucleotide_run=(
                        None if row.get("max_dinucleotide_run") in (None, "") else int(row.get("max_dinucleotide_run"))
                    ),
                    self_complementarity=(
                        None if row.get("self_complementarity") in (None, "") else int(row.get("self_complementarity"))
                    ),
                    contiguous_self_complementarity=(
                        None
                        if row.get("contiguous_self_complementarity") in (None, "")
                        else int(row.get("contiguous_self_complementarity"))
                    ),
                    hairpin_tm=None if row.get("hairpin_tm") in (None, "") else float(row.get("hairpin_tm")),
                    homodimer_tm=None if row.get("homodimer_tm") in (None, "") else float(row.get("homodimer_tm")),
                    thermo_penalty=(
                        None if row.get("thermo_penalty") in (None, "") else float(row.get("thermo_penalty"))
                    ),
                    lineage=lineage,
                    source_accession=(row.get("source_accession") or "").strip() or None,
                    source_nt_start=None if row.get("source_nt_start") in (None, "") else int(row.get("source_nt_start")),
                    source_nt_end=None if row.get("source_nt_end") in (None, "") else int(row.get("source_nt_end")),
                )
            except ValueError as exc:
                raise ValueError(f"Invalid probe manifest row in {manifest_path}") from exc
            requests.append(request)

    if not requests:
        raise ValueError(f"No panel probe candidates were found in: {manifest_path}")
    return levels, requests, probe_summary


def _request_matches_taxonomy(
    ranks: Mapping[str, str],
    request: PanelTargetRequest,
    levels: Sequence[str],
) -> bool:
    explicit_matches = False
    for level in levels:
        expected = request.lineage.get(level)
        if not expected:
            continue
        explicit_matches = True
        if ranks.get(level) != expected:
            return False
    if explicit_matches:
        return True
    return ranks.get(request.resolved_level) == request.resolved_taxon


def _infer_panel_contexts(
    taxonomy_file: str | Path,
    target_requests: Sequence[PanelTargetRequest],
    levels: Sequence[str],
    *,
    include_taxa: Mapping[str, set[str]] | None = None,
    exclude_taxa: Mapping[str, set[str]] | None = None,
    progress_callback: ProgressCallback | None = None,
) -> dict[tuple[str, str, str], _ResolvedPanelContext]:
    contexts = {
        (request.barcode, request.resolved_level, request.resolved_taxon): _ResolvedPanelContext(
            request=request,
            taxonomy_accessions=set(),
            sibling_accessions=set(),
            global_accessions=set(),
            inferred_lineage={level: request.lineage.get(level) for level in levels},
            parent_level=None,
            parent_taxon=None,
        )
        for request in target_requests
    }
    inferred_sets = {
        key: {level: set() for level in levels}
        for key in contexts
    }
    all_accessions: set[str] = set()
    filtered_records = []

    _emit_progress(progress_callback, "taxonomy_resolution_started", requests=len(contexts))
    for record in iter_taxonomy_records(taxonomy_file):
        if not taxonomy_record_matches_scope(
            record.ranks,
            include_taxa=include_taxa,
            exclude_taxa=exclude_taxa,
        ):
            continue
        filtered_records.append(record)
        accession = sys.intern(record.accession)
        all_accessions.add(accession)
        for key, context in contexts.items():
            if _request_matches_taxonomy(record.ranks, context.request, levels):
                context.taxonomy_accessions.add(accession)
                for level in levels:
                    value = record.ranks.get(level)
                    if value:
                        inferred_sets[key][level].add(value)

    for key, context in contexts.items():
        for level in levels:
            if context.inferred_lineage.get(level):
                continue
            values = inferred_sets[key][level]
            if len(values) == 1:
                context.inferred_lineage[level] = next(iter(values))
        resolved_index = levels.index(context.request.resolved_level)
        for level in reversed(levels[:resolved_index]):
            value = context.inferred_lineage.get(level)
            if value:
                context.parent_level = level
                context.parent_taxon = value
                break

    for record in filtered_records:
        accession = sys.intern(record.accession)
        for context in contexts.values():
            if accession in context.taxonomy_accessions:
                continue
            if context.parent_level and context.parent_taxon:
                parent_index = levels.index(context.parent_level)
                matches_parent = True
                for level in levels[: parent_index + 1]:
                    expected = context.inferred_lineage.get(level)
                    if expected and record.ranks.get(level) != expected:
                        matches_parent = False
                        break
                if matches_parent:
                    context.sibling_accessions.add(accession)
            else:
                context.sibling_accessions.add(accession)

    for context in contexts.values():
        context.global_accessions = set(all_accessions) - set(context.taxonomy_accessions)

    _emit_progress(progress_callback, "taxonomy_resolution_completed", requests=len(contexts))
    return contexts


def _marker_id_from_member_name(member_name: str) -> str:
    return Path(member_name).stem


def _count_selected_marker_members(markers_archive: str | Path, selected_marker_ids: set[str]) -> int:
    count = 0
    with tarfile.open(Path(markers_archive).expanduser().resolve(), "r:*") as archive:
        for member in archive:
            if member.isfile() and member.name.endswith(".fna"):
                if _marker_id_from_member_name(member.name) in selected_marker_ids:
                    count += 1
    return count


def _read_marker_nucleotide_profile(
    archive: tarfile.TarFile,
    member: tarfile.TarInfo,
) -> MarkerNucleotideProfile:
    extracted = archive.extractfile(member)
    if extracted is None:
        raise ValueError(f"Unable to read nucleotide marker member from archive: {member.name}")

    sequences: dict[str, str] = {}
    current_accession: str | None = None
    chunks: list[str] = []

    def finalize() -> None:
        nonlocal current_accession, chunks
        if current_accession is None:
            return
        sequences[current_accession] = "".join(chunks).upper()

    for raw_line in extracted:
        line = raw_line.decode("utf-8", errors="replace").strip()
        if not line:
            continue
        if line.startswith(">"):
            finalize()
            current_accession = sys.intern(line[1:].split()[0])
            chunks = []
        else:
            chunks.append(line)
    finalize()

    return MarkerNucleotideProfile(
        marker_id=_marker_id_from_member_name(member.name),
        member_name=member.name,
        sequences=sequences,
    )


def _load_selected_marker_profiles(
    markers_archive: str | Path,
    selected_marker_ids: set[str],
    *,
    progress_callback: ProgressCallback | None = None,
) -> dict[str, MarkerNucleotideProfile]:
    total = _count_selected_marker_members(markers_archive, selected_marker_ids)
    completed = 0
    profiles: dict[str, MarkerNucleotideProfile] = {}
    _emit_progress(progress_callback, "marker_loading_started", total_markers=total)
    with tarfile.open(Path(markers_archive).expanduser().resolve(), "r:*") as archive:
        for member in archive:
            if not (member.isfile() and member.name.endswith(".fna")):
                continue
            marker_id = _marker_id_from_member_name(member.name)
            if marker_id not in selected_marker_ids:
                continue
            profiles[marker_id] = _read_marker_nucleotide_profile(archive, member)
            completed += 1
            _emit_progress(progress_callback, "marker_loading_advanced", completed=completed, total_markers=total)
    _emit_progress(progress_callback, "marker_loading_completed", total_markers=total)
    return profiles


def _safe_rate(numerator: int, denominator: int) -> float:
    if denominator <= 0:
        return 0.0
    return float(numerator) / float(denominator)


def _candidate_sort_key(evaluation: _CandidateEvaluation) -> tuple[Any, ...]:
    row = evaluation.row
    return (
        -float(row["panel_base_utility"]),
        -float(row.get("target_candidate_effective_coverage_fraction") or row["target_candidate_coverage_fraction"]),
        float(row.get("sibling_candidate_effective_offtarget_fraction") or row["sibling_candidate_offtarget_fraction"]),
        float(row.get("global_candidate_effective_offtarget_fraction") or row["global_candidate_offtarget_fraction"]),
        float(row.get("index_sibling_offtarget_fraction") or 0.0),
        float(row.get("index_global_offtarget_fraction") or 0.0),
        str(row["probe_sequence"]),
    )


def _evaluate_probe_candidate_request(
    request: ProbePanelRequest,
    contexts: Mapping[tuple[str, str, str], _ResolvedPanelContext],
    marker_profiles: Mapping[str, MarkerNucleotideProfile],
    *,
    genome_hit_maps_by_label: Mapping[str, Mapping[str, set[str]]] | None,
    index_identifiers_by_label: Mapping[str, set[str]] | None,
    base_score_weight: float,
    sibling_penalty_weight: float,
    global_penalty_weight: float,
    genome_index_penalty_weight: float,
    match_config: MatchConfig,
) -> _CandidateEvaluation | None:
    context = contexts[request.target_key]
    marker_profile = marker_profiles.get(request.marker_id)
    if marker_profile is None:
        return None

    marker_accessions = set(marker_profile.sequences)
    target_available = context.taxonomy_accessions & marker_accessions
    sibling_available = context.sibling_accessions & marker_accessions
    global_available = context.global_accessions & marker_accessions

    target_summary = evaluate_query_against_accessions(
        request.target_subsequence,
        target_available,
        marker_profile.sequences,
        match_config,
    )
    sibling_summary = evaluate_query_against_accessions(
        request.target_subsequence,
        sibling_available,
        marker_profile.sequences,
        match_config,
    )
    global_summary = evaluate_query_against_accessions(
        request.target_subsequence,
        global_available,
        marker_profile.sequences,
        match_config,
    )
    target_hits = set(target_summary.matched_accessions)
    sibling_hits = set(sibling_summary.matched_accessions)
    global_hits = set(global_summary.matched_accessions)
    target_fraction = target_summary.support_fraction
    sibling_fraction = sibling_summary.support_fraction
    global_fraction = global_summary.support_fraction
    target_genome_available: set[str] = set()
    sibling_genome_available: set[str] = set()
    global_genome_available: set[str] = set()
    target_genome_hits: set[str] = set()
    sibling_genome_hits: set[str] = set()
    global_genome_hits: set[str] = set()
    index_available_by_label: dict[str, set[str]] = {}
    index_hits_by_label: dict[str, set[str]] = {}
    external_index_available_by_label: dict[str, set[str]] = {}
    external_index_hits_by_label: dict[str, set[str]] = {}
    genome_index_penalty = 0.0
    if genome_hit_maps_by_label is not None and index_identifiers_by_label is not None:
        for label, genome_hit_map in genome_hit_maps_by_label.items():
            identifiers = set(index_identifiers_by_label.get(label, set()))
            index_available_by_label[label] = identifiers
            genome_hits = set(genome_hit_map.get(request.target_subsequence, set()))
            index_hits_by_label[label] = genome_hits
            row_target_available = context.taxonomy_accessions & identifiers
            row_sibling_available = context.sibling_accessions & identifiers
            row_global_available = context.global_accessions & identifiers
            row_target_hits = genome_hits & row_target_available
            row_sibling_hits = genome_hits & row_sibling_available
            row_global_hits = genome_hits & row_global_available
            target_genome_available.update(row_target_available)
            sibling_genome_available.update(row_sibling_available)
            global_genome_available.update(row_global_available)
            target_genome_hits.update(row_target_hits)
            sibling_genome_hits.update(row_sibling_hits)
            global_genome_hits.update(row_global_hits)
            if row_target_available or row_sibling_available or row_global_available:
                sibling_genome_fraction = _safe_rate(len(row_sibling_hits), len(row_sibling_available))
                global_genome_fraction = _safe_rate(len(row_global_hits), len(row_global_available))
                genome_index_penalty += genome_index_penalty_weight * (
                    (sibling_penalty_weight * sibling_genome_fraction)
                    + (global_penalty_weight * global_genome_fraction)
                )
            else:
                external_index_available_by_label[label] = identifiers
                external_index_hits_by_label[label] = genome_hits
                genome_index_penalty += (
                    genome_index_penalty_weight
                    * global_penalty_weight
                    * _safe_rate(len(genome_hits), len(identifiers))
                )

    base_utility = (
        target_fraction
        - (sibling_penalty_weight * sibling_fraction)
        - (global_penalty_weight * global_fraction)
        + (base_score_weight * request.probe_score)
        - genome_index_penalty
    )

    row = {
        "barcode": request.barcode,
        "resolved_level": request.resolved_level,
        "resolved_taxon": request.resolved_taxon,
        "marker_id": request.marker_id,
        "aligned_start": request.aligned_start,
        "aligned_end": request.aligned_end,
        "region_rank_within_target_marker": request.region_rank_within_target_marker,
        "rank_within_region": request.rank_within_region,
        "probe_sequence": request.probe_sequence,
        "target_subsequence": request.target_subsequence,
        "source_accession": request.source_accession,
        "source_nt_start": request.source_nt_start,
        "source_nt_end": request.source_nt_end,
        "gc_fraction": request.gc_fraction,
        "tm_basic": request.tm_basic,
        "tm_nn": request.tm_nn,
        "tm_selected": request.tm_selected,
        "tm_model": request.tm_model,
        "sequence_entropy": request.sequence_entropy,
        "max_homopolymer": request.max_homopolymer,
        "max_dinucleotide_run": request.max_dinucleotide_run,
        "self_complementarity": request.self_complementarity,
        "contiguous_self_complementarity": request.contiguous_self_complementarity,
        "hairpin_tm": request.hairpin_tm,
        "homodimer_tm": request.homodimer_tm,
        "thermo_penalty": request.thermo_penalty,
        "probe_score": request.probe_score,
        "target_taxonomy_genomes": len(context.taxonomy_accessions),
        "target_candidate_marker_genomes": len(target_available),
        "target_hits": len(target_hits),
        "target_exact_hits": target_summary.exact_hits,
        "target_mismatch_hits": target_summary.mismatch_hits,
        "target_mean_best_mismatches": target_summary.mean_best_mismatches,
        "target_candidate_coverage_fraction": target_summary.hit_fraction,
        "target_candidate_effective_coverage_fraction": target_summary.support_fraction,
        "target_taxonomy_coverage_fraction": _safe_rate(len(target_hits), len(context.taxonomy_accessions)),
        "target_taxonomy_effective_coverage_fraction": _safe_rate(target_summary.total_support, len(context.taxonomy_accessions)),
        "sibling_taxonomy_genomes": len(context.sibling_accessions),
        "sibling_candidate_marker_genomes": len(sibling_available),
        "sibling_hits": len(sibling_hits),
        "sibling_exact_hits": sibling_summary.exact_hits,
        "sibling_mismatch_hits": sibling_summary.mismatch_hits,
        "sibling_mean_best_mismatches": sibling_summary.mean_best_mismatches,
        "sibling_candidate_offtarget_fraction": sibling_summary.hit_fraction,
        "sibling_candidate_effective_offtarget_fraction": sibling_summary.support_fraction,
        "sibling_taxonomy_offtarget_fraction": _safe_rate(len(sibling_hits), len(context.sibling_accessions)),
        "sibling_taxonomy_effective_offtarget_fraction": _safe_rate(sibling_summary.total_support, len(context.sibling_accessions)),
        "global_taxonomy_genomes": len(context.global_accessions),
        "global_candidate_marker_genomes": len(global_available),
        "global_hits": len(global_hits),
        "global_exact_hits": global_summary.exact_hits,
        "global_mismatch_hits": global_summary.mismatch_hits,
        "global_mean_best_mismatches": global_summary.mean_best_mismatches,
        "global_candidate_offtarget_fraction": global_summary.hit_fraction,
        "global_candidate_effective_offtarget_fraction": global_summary.support_fraction,
        "global_taxonomy_offtarget_fraction": _safe_rate(len(global_hits), len(context.global_accessions)),
        "global_taxonomy_effective_offtarget_fraction": _safe_rate(global_summary.total_support, len(context.global_accessions)),
        "index_target_available_genomes": len(target_genome_available),
        "index_target_hits": len(target_genome_hits),
        "index_target_coverage_fraction": _safe_rate(len(target_genome_hits), len(target_genome_available)),
        "index_sibling_available_genomes": len(sibling_genome_available),
        "index_sibling_hits": len(sibling_genome_hits),
        "index_sibling_offtarget_fraction": _safe_rate(len(sibling_genome_hits), len(sibling_genome_available)),
        "index_global_available_genomes": len(global_genome_available),
        "index_global_hits": len(global_genome_hits),
        "index_global_offtarget_fraction": _safe_rate(len(global_genome_hits), len(global_genome_available)),
        "panel_base_utility": base_utility,
        "max_panel_complementarity": 0,
        "max_panel_contiguous_complementarity": 0,
        "max_panel_heterodimer_tm": None,
        "panel_interaction_penalty": 0.0,
    }
    for label, identifiers in index_available_by_label.items():
        hits = index_hits_by_label.get(label, set())
        row[f"index_{label}_available_genomes"] = len(identifiers)
        row[f"index_{label}_hits"] = len(hits)
        row[f"index_{label}_hit_fraction"] = _safe_rate(len(hits), len(identifiers))
    for level, value in context.inferred_lineage.items():
        row[level] = value

    return _CandidateEvaluation(
        request=request,
        context=context,
        target_available=target_available,
        sibling_available=sibling_available,
        global_available=global_available,
        target_hits=target_hits,
        sibling_hits=sibling_hits,
        global_hits=global_hits,
        target_support_by_accession=dict(target_summary.support_by_accession),
        sibling_support_by_accession=dict(sibling_summary.support_by_accession),
        global_support_by_accession=dict(global_summary.support_by_accession),
        target_genome_available=target_genome_available,
        sibling_genome_available=sibling_genome_available,
        global_genome_available=global_genome_available,
        target_genome_hits=target_genome_hits,
        sibling_genome_hits=sibling_genome_hits,
        global_genome_hits=global_genome_hits,
        index_available_by_label=index_available_by_label,
        index_hits_by_label=index_hits_by_label,
        external_index_available_by_label=external_index_available_by_label,
        external_index_hits_by_label=external_index_hits_by_label,
        base_utility=base_utility,
        row=row,
    )


def _init_panel_candidate_worker(
    candidates: Sequence[ProbePanelRequest],
    contexts: Mapping[tuple[str, str, str], _ResolvedPanelContext],
    marker_profiles: Mapping[str, MarkerNucleotideProfile],
    genome_hit_maps_by_label: Mapping[str, Mapping[str, set[str]]] | None,
    index_identifiers_by_label: Mapping[str, set[str]] | None,
    base_score_weight: float,
    sibling_penalty_weight: float,
    global_penalty_weight: float,
    genome_index_penalty_weight: float,
    match_config: MatchConfig,
) -> None:
    global _PANEL_CANDIDATE_STATE
    _PANEL_CANDIDATE_STATE = (
        candidates,
        contexts,
        marker_profiles,
        genome_hit_maps_by_label,
        index_identifiers_by_label,
        base_score_weight,
        sibling_penalty_weight,
        global_penalty_weight,
        genome_index_penalty_weight,
        match_config,
    )


def _score_panel_candidate_chunk(chunk: tuple[int, int]) -> list[_CandidateEvaluation]:
    if _PANEL_CANDIDATE_STATE is None:
        raise RuntimeError("Panel-candidate worker state has not been initialized.")
    (
        candidates,
        contexts,
        marker_profiles,
        genome_hit_maps_by_label,
        index_identifiers_by_label,
        base_score_weight,
        sibling_penalty_weight,
        global_penalty_weight,
        genome_index_penalty_weight,
        match_config,
    ) = _PANEL_CANDIDATE_STATE
    start, end = chunk
    results: list[_CandidateEvaluation] = []
    for index in range(start, end):
        evaluation = _evaluate_probe_candidate_request(
            candidates[index],
            contexts,
            marker_profiles,
            genome_hit_maps_by_label=genome_hit_maps_by_label,
            index_identifiers_by_label=index_identifiers_by_label,
            base_score_weight=base_score_weight,
            sibling_penalty_weight=sibling_penalty_weight,
            global_penalty_weight=global_penalty_weight,
            genome_index_penalty_weight=genome_index_penalty_weight,
            match_config=match_config,
        )
        if evaluation is not None:
            results.append(evaluation)
    return results


def _empty_panel_summary(context: _ResolvedPanelContext) -> dict[str, Any]:
    summary_row = {
        "barcode": context.request.barcode,
        "resolved_level": context.request.resolved_level,
        "resolved_taxon": context.request.resolved_taxon,
        "parent_level": context.parent_level,
        "parent_taxon": context.parent_taxon,
        "status": "no_panel_candidates",
        "input_probe_candidates": 0,
        "selected_probes": 0,
        "target_taxonomy_genomes": len(context.taxonomy_accessions),
        "target_candidate_marker_genomes": 0,
        "panel_target_hits": 0,
        "target_taxonomy_coverage_fraction": 0.0,
        "target_candidate_marker_coverage_fraction": 0.0,
        "sibling_taxonomy_genomes": len(context.sibling_accessions),
        "sibling_candidate_marker_genomes": 0,
        "panel_sibling_hits": 0,
        "sibling_taxonomy_offtarget_fraction": 0.0,
        "sibling_candidate_marker_offtarget_fraction": 0.0,
        "global_taxonomy_genomes": len(context.global_accessions),
        "global_candidate_marker_genomes": 0,
        "panel_global_hits": 0,
        "global_taxonomy_offtarget_fraction": 0.0,
        "global_candidate_marker_offtarget_fraction": 0.0,
        "index_target_available_genomes": 0,
        "panel_index_target_hits": 0,
        "index_target_coverage_fraction": 0.0,
        "index_sibling_available_genomes": 0,
        "panel_index_sibling_hits": 0,
        "index_sibling_offtarget_fraction": 0.0,
        "index_global_available_genomes": 0,
        "panel_index_global_hits": 0,
        "index_global_offtarget_fraction": 0.0,
        "max_panel_contiguous_complementarity": 0,
        "max_panel_heterodimer_tm": None,
        "panel_interaction_penalty_total": 0.0,
        "panel_score": 0.0,
        "best_probe_sequence": None,
        "best_probe_score": None,
    }
    for level, value in context.inferred_lineage.items():
        summary_row[level] = value
    return summary_row


def _init_panel_selection_worker(
    ordered_keys: Sequence[tuple[str, str, str]],
    contexts: Mapping[tuple[str, str, str], _ResolvedPanelContext],
    grouped_evaluations: Mapping[tuple[str, str, str], Sequence[_CandidateEvaluation]],
    max_probes_per_panel: int,
    max_probes_per_marker: int,
    max_probes_per_region: int,
    allow_overlaps: bool,
    base_score_weight: float,
    sibling_penalty_weight: float,
    global_penalty_weight: float,
    genome_index_penalty_weight: float,
    interaction_config: PanelInteractionConfig,
) -> None:
    global _PANEL_SELECTION_STATE
    _PANEL_SELECTION_STATE = (
        ordered_keys,
        contexts,
        grouped_evaluations,
        max_probes_per_panel,
        max_probes_per_marker,
        max_probes_per_region,
        allow_overlaps,
        base_score_weight,
        sibling_penalty_weight,
        global_penalty_weight,
        genome_index_penalty_weight,
        interaction_config,
    )


def _select_panel_chunk(chunk: tuple[int, int]) -> list[_PanelSelectionOutcome]:
    if _PANEL_SELECTION_STATE is None:
        raise RuntimeError("Panel-selection worker state has not been initialized.")
    (
        ordered_keys,
        contexts,
        grouped_evaluations,
        max_probes_per_panel,
        max_probes_per_marker,
        max_probes_per_region,
        allow_overlaps,
        base_score_weight,
        sibling_penalty_weight,
        global_penalty_weight,
        genome_index_penalty_weight,
        interaction_config,
    ) = _PANEL_SELECTION_STATE
    start, end = chunk
    outcomes: list[_PanelSelectionOutcome] = []
    for index in range(start, end):
        key = ordered_keys[index]
        evaluations = grouped_evaluations.get(key, [])
        if evaluations:
            summary_row, selected_rows = _select_panel_for_target(
                evaluations,
                max_probes_per_panel=max_probes_per_panel,
                max_probes_per_marker=max_probes_per_marker,
                max_probes_per_region=max_probes_per_region,
                allow_overlaps=allow_overlaps,
                base_score_weight=base_score_weight,
                sibling_penalty_weight=sibling_penalty_weight,
                global_penalty_weight=global_penalty_weight,
                genome_index_penalty_weight=genome_index_penalty_weight,
                interaction_config=interaction_config,
            )
        else:
            summary_row = _empty_panel_summary(contexts[key])
            selected_rows = []
        outcomes.append(_PanelSelectionOutcome(summary_row=summary_row, selected_rows=selected_rows))
    return outcomes


def _evaluate_probe_candidates(
    candidates: Sequence[ProbePanelRequest],
    contexts: Mapping[tuple[str, str, str], _ResolvedPanelContext],
    marker_profiles: Mapping[str, MarkerNucleotideProfile],
    *,
    genome_hit_maps_by_label: Mapping[str, Mapping[str, set[str]]] | None,
    index_identifiers_by_label: Mapping[str, set[str]] | None,
    base_score_weight: float,
    sibling_penalty_weight: float,
    global_penalty_weight: float,
    genome_index_penalty_weight: float,
    match_config: MatchConfig,
    workers: int,
    progress_callback: ProgressCallback | None = None,
) -> tuple[list[dict[str, Any]], dict[tuple[str, str, str], list[_CandidateEvaluation]]]:
    deduped: dict[tuple[tuple[str, str, str], str], _CandidateEvaluation] = {}
    total_candidates = len(candidates)
    _emit_progress(progress_callback, "candidate_scoring_started", total_candidates=total_candidates)
    resolved_workers = resolve_worker_count(workers, total_tasks=total_candidates)
    scoring_chunks = build_chunks(total_candidates, workers=resolved_workers)
    completed = 0
    for chunk, evaluations in iter_chunk_results(
        scoring_chunks,
        worker=_score_panel_candidate_chunk,
        workers=resolved_workers,
        initializer=_init_panel_candidate_worker,
        initargs=(
            candidates,
            contexts,
            marker_profiles,
            genome_hit_maps_by_label,
            index_identifiers_by_label,
            base_score_weight,
            sibling_penalty_weight,
            global_penalty_weight,
            genome_index_penalty_weight,
            match_config,
        ),
    ):
        for evaluation in evaluations:
            dedupe_key = (evaluation.request.target_key, evaluation.request.probe_sequence)
            existing = deduped.get(dedupe_key)
            if existing is None or _candidate_sort_key(evaluation) < _candidate_sort_key(existing):
                deduped[dedupe_key] = evaluation
        completed += chunk[1] - chunk[0]
        _emit_progress(progress_callback, "candidate_scoring_advanced", completed=completed, total_candidates=total_candidates)

    _emit_progress(progress_callback, "candidate_scoring_completed", total_candidates=total_candidates)

    grouped: dict[tuple[str, str, str], list[_CandidateEvaluation]] = {}
    for evaluation in deduped.values():
        grouped.setdefault(evaluation.request.target_key, []).append(evaluation)

    panel_candidates: list[dict[str, Any]] = []
    for key, evaluations in grouped.items():
        evaluations.sort(key=_candidate_sort_key)
        for rank, evaluation in enumerate(evaluations, start=1):
            evaluation.row["candidate_rank_within_target"] = rank
            panel_candidates.append(evaluation.row)

    panel_candidates.sort(
        key=lambda row: (
            str(row["barcode"]),
            int(row["candidate_rank_within_target"]),
            str(row["probe_sequence"]),
        )
    )
    return panel_candidates, grouped


def _interaction_penalty_for_candidate(
    probe_sequence: str,
    selected_rows: Sequence[Mapping[str, Any]],
    *,
    interaction_config: PanelInteractionConfig,
) -> tuple[int, int, float | None, float]:
    max_complementarity = 0
    max_contiguous = 0
    max_heterodimer_tm: float | None = None
    for row in selected_rows:
        selected_probe = str(row.get("probe_sequence") or "")
        if not selected_probe:
            continue
        metrics = compute_pair_interaction_metrics(
            probe_sequence,
            selected_probe,
            backend=interaction_config.interaction_backend,
            conditions=interaction_config.thermo_conditions,
        )
        if metrics.complementarity > max_complementarity:
            max_complementarity = metrics.complementarity
        if metrics.contiguous_complementarity > max_contiguous:
            max_contiguous = metrics.contiguous_complementarity
        if metrics.heterodimer_tm is not None and (
            max_heterodimer_tm is None or metrics.heterodimer_tm > max_heterodimer_tm
        ):
            max_heterodimer_tm = metrics.heterodimer_tm
    interaction_penalty = (
        interaction_config.panel_complementarity_penalty_weight
        * (_safe_rate(max_contiguous, len(probe_sequence)) + _safe_rate(max_complementarity, len(probe_sequence)))
    )
    if max_heterodimer_tm is not None:
        interaction_penalty += (
            interaction_config.panel_heterodimer_penalty_weight
            * max(0.0, max_heterodimer_tm)
            / max(1.0, interaction_config.thermo_conditions.hyb_temp_c)
        )
    return max_complementarity, max_contiguous, max_heterodimer_tm, interaction_penalty


def _incremental_support_gain(
    candidate_supports: Mapping[str, float],
    covered_supports: Mapping[str, float],
) -> tuple[float, set[str]]:
    support_gain = 0.0
    newly_hit: set[str] = set()
    for accession, support in candidate_supports.items():
        previous = float(covered_supports.get(accession, 0.0))
        if accession not in covered_supports and support > 0.0:
            newly_hit.add(accession)
        if support > previous:
            support_gain += support - previous
    return support_gain, newly_hit


def _merge_supports(covered_supports: dict[str, float], candidate_supports: Mapping[str, float]) -> None:
    for accession, support in candidate_supports.items():
        previous = float(covered_supports.get(accession, 0.0))
        if support > previous:
            covered_supports[accession] = support


def _probe_requests_overlap(left: ProbePanelRequest, right: ProbePanelRequest) -> bool:
    if left.marker_id != right.marker_id:
        return False
    if (
        left.source_nt_start is not None
        and left.source_nt_end is not None
        and right.source_nt_start is not None
        and right.source_nt_end is not None
    ):
        left_start = min(left.source_nt_start, left.source_nt_end)
        left_end = max(left.source_nt_start, left.source_nt_end)
        right_start = min(right.source_nt_start, right.source_nt_end)
        right_end = max(right.source_nt_start, right.source_nt_end)
        return not (left_end < right_start or right_end < left_start)
    return left.region_key == right.region_key


def _select_panel_for_target(
    evaluations: Sequence[_CandidateEvaluation],
    *,
    max_probes_per_panel: int,
    max_probes_per_marker: int,
    max_probes_per_region: int,
    allow_overlaps: bool,
    base_score_weight: float,
    sibling_penalty_weight: float,
    global_penalty_weight: float,
    genome_index_penalty_weight: float,
    interaction_config: PanelInteractionConfig,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    if not evaluations:
        raise ValueError("Panel selection requires at least one candidate evaluation.")

    context = evaluations[0].context
    selected_rows: list[dict[str, Any]] = []
    covered_target: set[str] = set()
    covered_sibling: set[str] = set()
    covered_global: set[str] = set()
    covered_target_support: dict[str, float] = {}
    covered_sibling_support: dict[str, float] = {}
    covered_global_support: dict[str, float] = {}
    covered_target_genome: set[str] = set()
    covered_sibling_genome: set[str] = set()
    covered_global_genome: set[str] = set()
    covered_index_hits_by_label: dict[str, set[str]] = {}
    external_covered_index_hits_by_label: dict[str, set[str]] = {}
    marker_counts: dict[str, int] = {}
    region_counts: dict[tuple[str, int, int], int] = {}
    selected_requests: list[ProbePanelRequest] = []
    cumulative_interaction_penalty = 0.0
    max_panel_contiguous_complementarity = 0
    max_panel_heterodimer_tm: float | None = None
    remaining = list(evaluations)
    available_target_union: set[str] = set()
    available_sibling_union: set[str] = set()
    available_global_union: set[str] = set()
    available_target_genome_union: set[str] = set()
    available_sibling_genome_union: set[str] = set()
    available_global_genome_union: set[str] = set()
    available_index_union_by_label: dict[str, set[str]] = {}
    external_available_index_union_by_label: dict[str, set[str]] = {}
    for evaluation in evaluations:
        available_target_union.update(evaluation.target_available)
        available_sibling_union.update(evaluation.sibling_available)
        available_global_union.update(evaluation.global_available)
        available_target_genome_union.update(evaluation.target_genome_available)
        available_sibling_genome_union.update(evaluation.sibling_genome_available)
        available_global_genome_union.update(evaluation.global_genome_available)
        for label, identifiers in evaluation.index_available_by_label.items():
            available_index_union_by_label.setdefault(label, set()).update(identifiers)
        for label, identifiers in evaluation.external_index_available_by_label.items():
            external_available_index_union_by_label.setdefault(label, set()).update(identifiers)

    while remaining and len(selected_rows) < max_probes_per_panel:
        best: _CandidateEvaluation | None = None
        best_utility = float("-inf")
        best_marginals: tuple[
            set[str],
            set[str],
            set[str],
            set[str],
            set[str],
            set[str],
            float,
            float,
            float,
            dict[str, set[str]],
            float,
        ] | None = None
        best_interactions: tuple[int, int, float | None, float] | None = None
        for evaluation in remaining:
            marker_count = marker_counts.get(evaluation.request.marker_id, 0)
            if marker_count >= max_probes_per_marker:
                continue
            region_count = region_counts.get(evaluation.request.region_key, 0)
            if region_count >= max_probes_per_region:
                continue
            if not allow_overlaps and any(
                _probe_requests_overlap(evaluation.request, selected_request)
                for selected_request in selected_requests
            ):
                continue

            new_target_hits = evaluation.target_hits - covered_target
            new_sibling_hits = evaluation.sibling_hits - covered_sibling
            new_global_hits = evaluation.global_hits - covered_global
            new_target_support, _ = _incremental_support_gain(
                evaluation.target_support_by_accession,
                covered_target_support,
            )
            new_sibling_support, _ = _incremental_support_gain(
                evaluation.sibling_support_by_accession,
                covered_sibling_support,
            )
            new_global_support, _ = _incremental_support_gain(
                evaluation.global_support_by_accession,
                covered_global_support,
            )
            new_target_genome_hits = evaluation.target_genome_hits - covered_target_genome
            new_sibling_genome_hits = evaluation.sibling_genome_hits - covered_sibling_genome
            new_global_genome_hits = evaluation.global_genome_hits - covered_global_genome
            new_index_hits_by_label: dict[str, set[str]] = {}
            external_index_fraction_penalty = 0.0
            for label, hits in evaluation.index_hits_by_label.items():
                covered_label_hits = covered_index_hits_by_label.get(label, set())
                new_hits = hits - covered_label_hits
                new_index_hits_by_label[label] = new_hits
            for label, hits in evaluation.external_index_hits_by_label.items():
                covered_external_hits = external_covered_index_hits_by_label.get(label, set())
                new_hits = hits - covered_external_hits
                available_external = external_available_index_union_by_label.get(label, set())
                external_index_fraction_penalty += _safe_rate(len(new_hits), len(available_external))
            marginal_target_fraction = _safe_rate(new_target_support, len(context.taxonomy_accessions))
            marginal_sibling_fraction = _safe_rate(new_sibling_support, len(context.sibling_accessions))
            marginal_global_fraction = _safe_rate(new_global_support, len(context.global_accessions))
            marginal_sibling_genome_fraction = _safe_rate(len(new_sibling_genome_hits), len(available_sibling_genome_union))
            marginal_global_genome_fraction = _safe_rate(len(new_global_genome_hits), len(available_global_genome_union))
            (
                panel_complementarity,
                panel_contiguous_complementarity,
                panel_heterodimer_tm,
                interaction_penalty,
            ) = _interaction_penalty_for_candidate(
                evaluation.request.probe_sequence,
                selected_rows,
                interaction_config=interaction_config,
            )
            if (
                interaction_config.max_panel_contiguous_complementarity is not None
                and panel_contiguous_complementarity > interaction_config.max_panel_contiguous_complementarity
            ):
                continue
            if (
                interaction_config.max_panel_heterodimer_tm is not None
                and panel_heterodimer_tm is not None
                and panel_heterodimer_tm > interaction_config.max_panel_heterodimer_tm
            ):
                continue
            utility = (
                marginal_target_fraction
                - (sibling_penalty_weight * marginal_sibling_fraction)
                - (global_penalty_weight * marginal_global_fraction)
                + (base_score_weight * evaluation.request.probe_score)
                - genome_index_penalty_weight
                * (
                    (sibling_penalty_weight * marginal_sibling_genome_fraction)
                    + (global_penalty_weight * marginal_global_genome_fraction)
                    + (global_penalty_weight * external_index_fraction_penalty)
                )
                - interaction_penalty
            )
            if (
                best is None
                or utility > best_utility
                or (
                    utility == best_utility
                    and _candidate_sort_key(evaluation) < _candidate_sort_key(best)
                )
            ):
                best = evaluation
                best_utility = utility
                best_marginals = (
                    new_target_hits,
                    new_sibling_hits,
                    new_global_hits,
                    new_target_genome_hits,
                    new_sibling_genome_hits,
                    new_global_genome_hits,
                    new_target_support,
                    new_sibling_support,
                    new_global_support,
                    new_index_hits_by_label,
                    external_index_fraction_penalty,
                )
                best_interactions = (
                    panel_complementarity,
                    panel_contiguous_complementarity,
                    panel_heterodimer_tm,
                    interaction_penalty,
                )

        if best is None or best_marginals is None or best_interactions is None:
            break
        if selected_rows and best_utility <= 0.0:
            break
        if not selected_rows and len(best_marginals[0]) == 0:
            break

        (
            new_target_hits,
            new_sibling_hits,
            new_global_hits,
            new_target_genome_hits,
            new_sibling_genome_hits,
            new_global_genome_hits,
            new_target_support,
            new_sibling_support,
            new_global_support,
            new_index_hits_by_label,
            _external_index_fraction_penalty,
        ) = best_marginals
        (
            panel_complementarity,
            panel_contiguous_complementarity,
            panel_heterodimer_tm,
            interaction_penalty,
        ) = best_interactions
        covered_target.update(best.target_hits)
        covered_sibling.update(best.sibling_hits)
        covered_global.update(best.global_hits)
        _merge_supports(covered_target_support, best.target_support_by_accession)
        _merge_supports(covered_sibling_support, best.sibling_support_by_accession)
        _merge_supports(covered_global_support, best.global_support_by_accession)
        covered_target_genome.update(best.target_genome_hits)
        covered_sibling_genome.update(best.sibling_genome_hits)
        covered_global_genome.update(best.global_genome_hits)
        for label, hits in best.index_hits_by_label.items():
            covered_index_hits_by_label.setdefault(label, set()).update(hits)
        for label, hits in best.external_index_hits_by_label.items():
            external_covered_index_hits_by_label.setdefault(label, set()).update(hits)
        marker_counts[best.request.marker_id] = marker_counts.get(best.request.marker_id, 0) + 1
        region_counts[best.request.region_key] = region_counts.get(best.request.region_key, 0) + 1
        cumulative_interaction_penalty += interaction_penalty
        if panel_contiguous_complementarity > max_panel_contiguous_complementarity:
            max_panel_contiguous_complementarity = panel_contiguous_complementarity
        if panel_heterodimer_tm is not None and (
            max_panel_heterodimer_tm is None or panel_heterodimer_tm > max_panel_heterodimer_tm
        ):
            max_panel_heterodimer_tm = panel_heterodimer_tm

        row = dict(best.row)
        selection_rank = len(selected_rows) + 1
        row["selection_rank"] = selection_rank
        row["panel_selection_score"] = best_utility
        row["max_panel_complementarity"] = panel_complementarity
        row["max_panel_contiguous_complementarity"] = panel_contiguous_complementarity
        row["max_panel_heterodimer_tm"] = panel_heterodimer_tm
        row["panel_interaction_penalty"] = interaction_penalty
        row["marginal_target_hits"] = len(new_target_hits)
        row["marginal_target_support"] = new_target_support
        row["marginal_target_coverage_fraction"] = _safe_rate(len(new_target_hits), len(context.taxonomy_accessions))
        row["marginal_target_effective_coverage_fraction"] = _safe_rate(new_target_support, len(context.taxonomy_accessions))
        row["cumulative_target_hits"] = len(covered_target)
        row["cumulative_target_taxonomy_coverage_fraction"] = _safe_rate(len(covered_target), len(context.taxonomy_accessions))
        row["cumulative_target_support"] = sum(covered_target_support.values())
        row["cumulative_target_taxonomy_effective_coverage_fraction"] = _safe_rate(sum(covered_target_support.values()), len(context.taxonomy_accessions))
        row["cumulative_target_candidate_marker_coverage_fraction"] = _safe_rate(len(covered_target), len(available_target_union))
        row["marginal_sibling_hits"] = len(new_sibling_hits)
        row["marginal_sibling_support"] = new_sibling_support
        row["marginal_sibling_offtarget_fraction"] = _safe_rate(len(new_sibling_hits), len(context.sibling_accessions))
        row["marginal_sibling_effective_offtarget_fraction"] = _safe_rate(new_sibling_support, len(context.sibling_accessions))
        row["cumulative_sibling_hits"] = len(covered_sibling)
        row["cumulative_sibling_taxonomy_offtarget_fraction"] = _safe_rate(len(covered_sibling), len(context.sibling_accessions))
        row["cumulative_sibling_support"] = sum(covered_sibling_support.values())
        row["cumulative_sibling_taxonomy_effective_offtarget_fraction"] = _safe_rate(sum(covered_sibling_support.values()), len(context.sibling_accessions))
        row["cumulative_sibling_candidate_marker_offtarget_fraction"] = _safe_rate(len(covered_sibling), len(available_sibling_union))
        row["marginal_global_hits"] = len(new_global_hits)
        row["marginal_global_support"] = new_global_support
        row["marginal_global_offtarget_fraction"] = _safe_rate(len(new_global_hits), len(context.global_accessions))
        row["marginal_global_effective_offtarget_fraction"] = _safe_rate(new_global_support, len(context.global_accessions))
        row["cumulative_global_hits"] = len(covered_global)
        row["cumulative_global_taxonomy_offtarget_fraction"] = _safe_rate(len(covered_global), len(context.global_accessions))
        row["cumulative_global_support"] = sum(covered_global_support.values())
        row["cumulative_global_taxonomy_effective_offtarget_fraction"] = _safe_rate(sum(covered_global_support.values()), len(context.global_accessions))
        row["cumulative_global_candidate_marker_offtarget_fraction"] = _safe_rate(len(covered_global), len(available_global_union))
        row["marginal_index_target_hits"] = len(new_target_genome_hits)
        row["cumulative_index_target_hits"] = len(covered_target_genome)
        row["cumulative_index_target_coverage_fraction"] = _safe_rate(len(covered_target_genome), len(available_target_genome_union))
        row["marginal_index_sibling_hits"] = len(new_sibling_genome_hits)
        row["cumulative_index_sibling_hits"] = len(covered_sibling_genome)
        row["cumulative_index_sibling_offtarget_fraction"] = _safe_rate(len(covered_sibling_genome), len(available_sibling_genome_union))
        row["marginal_index_global_hits"] = len(new_global_genome_hits)
        row["cumulative_index_global_hits"] = len(covered_global_genome)
        row["cumulative_index_global_offtarget_fraction"] = _safe_rate(len(covered_global_genome), len(available_global_genome_union))
        for label, available in available_index_union_by_label.items():
            cumulative_label_hits = covered_index_hits_by_label.get(label, set())
            marginal_label_hits = new_index_hits_by_label.get(label, set())
            row[f"marginal_index_{label}_hits"] = len(marginal_label_hits)
            row[f"cumulative_index_{label}_hits"] = len(cumulative_label_hits)
            row[f"cumulative_index_{label}_hit_fraction"] = _safe_rate(len(cumulative_label_hits), len(available))
        selected_rows.append(row)
        selected_requests.append(best.request)
        remaining.remove(best)

    status = "ready" if selected_rows else "no_selected_probes"
    mean_probe_score = (
        sum(float(row["probe_score"]) for row in selected_rows) / float(len(selected_rows))
        if selected_rows
        else 0.0
    )
    panel_score = (
        _safe_rate(sum(covered_target_support.values()), len(context.taxonomy_accessions))
        - (sibling_penalty_weight * _safe_rate(sum(covered_sibling_support.values()), len(context.sibling_accessions)))
        - (global_penalty_weight * _safe_rate(sum(covered_global_support.values()), len(context.global_accessions)))
        + (base_score_weight * mean_probe_score)
        - genome_index_penalty_weight
        * (
            (sibling_penalty_weight * _safe_rate(len(covered_sibling_genome), len(available_sibling_genome_union)))
            + (global_penalty_weight * _safe_rate(len(covered_global_genome), len(available_global_genome_union)))
            + (
                global_penalty_weight
                * sum(
                    _safe_rate(len(external_covered_index_hits_by_label.get(label, set())), len(available))
                    for label, available in external_available_index_union_by_label.items()
                )
            )
        )
        - cumulative_interaction_penalty
    )
    summary_row = {
        "barcode": context.request.barcode,
        "resolved_level": context.request.resolved_level,
        "resolved_taxon": context.request.resolved_taxon,
        "parent_level": context.parent_level,
        "parent_taxon": context.parent_taxon,
        "status": status,
        "input_probe_candidates": len(evaluations),
        "selected_probes": len(selected_rows),
        "target_taxonomy_genomes": len(context.taxonomy_accessions),
        "target_candidate_marker_genomes": len(available_target_union),
        "panel_target_hits": len(covered_target),
        "target_taxonomy_coverage_fraction": _safe_rate(len(covered_target), len(context.taxonomy_accessions)),
        "target_taxonomy_effective_coverage_fraction": _safe_rate(sum(covered_target_support.values()), len(context.taxonomy_accessions)),
        "target_candidate_marker_coverage_fraction": _safe_rate(len(covered_target), len(available_target_union)),
        "sibling_taxonomy_genomes": len(context.sibling_accessions),
        "sibling_candidate_marker_genomes": len(available_sibling_union),
        "panel_sibling_hits": len(covered_sibling),
        "sibling_taxonomy_offtarget_fraction": _safe_rate(len(covered_sibling), len(context.sibling_accessions)),
        "sibling_taxonomy_effective_offtarget_fraction": _safe_rate(sum(covered_sibling_support.values()), len(context.sibling_accessions)),
        "sibling_candidate_marker_offtarget_fraction": _safe_rate(len(covered_sibling), len(available_sibling_union)),
        "global_taxonomy_genomes": len(context.global_accessions),
        "global_candidate_marker_genomes": len(available_global_union),
        "panel_global_hits": len(covered_global),
        "global_taxonomy_offtarget_fraction": _safe_rate(len(covered_global), len(context.global_accessions)),
        "global_taxonomy_effective_offtarget_fraction": _safe_rate(sum(covered_global_support.values()), len(context.global_accessions)),
        "global_candidate_marker_offtarget_fraction": _safe_rate(len(covered_global), len(available_global_union)),
        "index_target_available_genomes": len(available_target_genome_union),
        "panel_index_target_hits": len(covered_target_genome),
        "index_target_coverage_fraction": _safe_rate(len(covered_target_genome), len(available_target_genome_union)),
        "index_sibling_available_genomes": len(available_sibling_genome_union),
        "panel_index_sibling_hits": len(covered_sibling_genome),
        "index_sibling_offtarget_fraction": _safe_rate(len(covered_sibling_genome), len(available_sibling_genome_union)),
        "index_global_available_genomes": len(available_global_genome_union),
        "panel_index_global_hits": len(covered_global_genome),
        "index_global_offtarget_fraction": _safe_rate(len(covered_global_genome), len(available_global_genome_union)),
        "max_panel_contiguous_complementarity": max_panel_contiguous_complementarity,
        "max_panel_heterodimer_tm": max_panel_heterodimer_tm,
        "panel_interaction_penalty_total": cumulative_interaction_penalty,
        "panel_score": panel_score,
        "best_probe_sequence": None if not selected_rows else selected_rows[0]["probe_sequence"],
        "best_probe_score": None if not selected_rows else selected_rows[0]["probe_score"],
    }
    for label, available in available_index_union_by_label.items():
        summary_row[f"index_{label}_available_genomes"] = len(available)
        summary_row[f"panel_index_{label}_hits"] = len(covered_index_hits_by_label.get(label, set()))
        summary_row[f"index_{label}_hit_fraction"] = _safe_rate(
            len(covered_index_hits_by_label.get(label, set())),
            len(available),
        )
    for level, value in context.inferred_lineage.items():
        summary_row[level] = value
    return summary_row, selected_rows


def design_panels(
    *,
    taxonomy_file: str | Path,
    markers_archive: str | Path,
    probe_design_prefix: str | Path,
    dataset: str | None = None,
    index_datasets: Sequence[str] | None = None,
    index_files: Sequence[str | Path] | None = None,
    index_reference_map_files: Sequence[str | Path] | None = None,
    index_summary_files: Sequence[str | Path] | None = None,
    include_taxa: Mapping[str, set[str]] | None = None,
    exclude_taxa: Mapping[str, set[str]] | None = None,
    fulgor_binary: str | Path = "fulgor",
    index_threads: int = DEFAULT_FULGOR_THREADS,
    max_probes_per_panel: int = DEFAULT_MAX_PROBES_PER_PANEL,
    max_probes_per_marker: int = DEFAULT_MAX_PROBES_PER_MARKER,
    max_probes_per_region: int = DEFAULT_MAX_PROBES_PER_REGION,
    allow_overlaps: bool = False,
    base_score_weight: float = DEFAULT_PANEL_BASE_SCORE_WEIGHT,
    sibling_penalty_weight: float = DEFAULT_SIBLING_PENALTY_WEIGHT,
    global_penalty_weight: float = DEFAULT_GLOBAL_PENALTY_WEIGHT,
    genome_index_penalty_weight: float = DEFAULT_INDEX_PENALTY_WEIGHT,
    scoring_profile: str = DEFAULT_SCORING_PROFILE,
    interaction_backend: str = DEFAULT_THERMO_BACKEND,
    monovalent_salt_mM: float = DEFAULT_MONOVALENT_SALT_MM,
    divalent_salt_mM: float = DEFAULT_DIVALENT_SALT_MM,
    dntp_mM: float = DEFAULT_DNTP_MM,
    probe_conc_nM: float = DEFAULT_PROBE_CONC_NM,
    hyb_temp_c: float = DEFAULT_HYB_TEMP_C,
    max_panel_contiguous_complementarity: int | None = None,
    max_panel_heterodimer_tm: float | None = None,
    panel_complementarity_penalty_weight: float | None = None,
    panel_heterodimer_penalty_weight: float | None = None,
    max_mismatches: int = DEFAULT_MAX_MISMATCHES,
    mismatch_penalty_per_mismatch: float = DEFAULT_MISMATCH_PENALTY_PER_MISMATCH,
    workers: int = DEFAULT_AUTO_WORKERS,
    progress_callback: ProgressCallback | None = None,
) -> PanelDesignResult:
    resolved_include_taxa = {level: set(taxa) for level, taxa in (include_taxa or {}).items() if taxa}
    resolved_exclude_taxa = {level: set(taxa) for level, taxa in (exclude_taxa or {}).items() if taxa}
    validate_taxon_constraint_overlap(resolved_include_taxa, resolved_exclude_taxa)
    if max_probes_per_panel < 1:
        raise ValueError("--max-probes-per-panel must be at least 1.")
    if max_probes_per_marker < 1:
        raise ValueError("--max-probes-per-marker must be at least 1.")
    if max_probes_per_region < 1:
        raise ValueError("--max-probes-per-region must be at least 1.")
    if base_score_weight < 0.0:
        raise ValueError("--base-score-weight must be >= 0.")
    if genome_index_penalty_weight < 0.0:
        raise ValueError("--genome-index-penalty-weight must be >= 0.")
    if index_threads < 1:
        raise ValueError("--index-threads must be at least 1.")
    if any(value < 0.0 for value in (monovalent_salt_mM, divalent_salt_mM, dntp_mM, probe_conc_nM)):
        raise ValueError("Salt, dNTP, and probe concentration values must be >= 0.")
    match_config = validate_match_config(
        MatchConfig(
            max_mismatches=max_mismatches,
            mismatch_penalty_per_mismatch=mismatch_penalty_per_mismatch,
        )
    )
    resolved_index_datasets = [str(value) for value in (index_datasets or [])]
    resolved_index_files = [str(Path(value).expanduser().resolve()) for value in (index_files or [])]
    resolved_index_reference_maps = [
        str(Path(value).expanduser().resolve())
        for value in (index_reference_map_files or [])
    ]
    resolved_index_summaries = [
        str(Path(value).expanduser().resolve())
        for value in (index_summary_files or [])
    ]
    if resolved_index_files or resolved_index_reference_maps or resolved_index_summaries:
        if not resolved_index_files or not resolved_index_reference_maps or not resolved_index_summaries:
            raise ValueError(
                "Provide all of --index-file, --index-reference-map, and --index-summary, or omit them all."
            )
        if not (
            len(resolved_index_files)
            == len(resolved_index_reference_maps)
            == len(resolved_index_summaries)
        ):
            raise ValueError(
                "Provide the same number of --index-file, --index-reference-map, and --index-summary values."
            )

    interaction_config = resolve_panel_interaction_config(
        scoring_profile=scoring_profile,
        interaction_backend=interaction_backend,
        thermo_conditions=ThermoConditions(
            monovalent_salt_mM=monovalent_salt_mM,
            divalent_salt_mM=divalent_salt_mM,
            dntp_mM=dntp_mM,
            probe_conc_nM=probe_conc_nM,
            hyb_temp_c=hyb_temp_c,
        ),
        max_panel_contiguous_complementarity=max_panel_contiguous_complementarity,
        max_panel_heterodimer_tm=max_panel_heterodimer_tm,
        panel_complementarity_penalty_weight=panel_complementarity_penalty_weight,
        panel_heterodimer_penalty_weight=panel_heterodimer_penalty_weight,
    )
    ensure_backend_available(interaction_config.interaction_backend)

    resolved_taxonomy = str(Path(taxonomy_file).expanduser().resolve())
    resolved_markers = str(Path(markers_archive).expanduser().resolve())
    resolved_probe_prefix = str(Path(probe_design_prefix).expanduser().resolve())
    index_resources = _build_index_resources(
        index_datasets=resolved_index_datasets,
        index_files=resolved_index_files,
        index_reference_map_files=resolved_index_reference_maps,
        index_summary_files=resolved_index_summaries,
    )

    levels, candidate_requests, _probe_summary = _read_probe_panel_requests(probe_design_prefix)
    target_requests = list(
        {
            request.target_key: PanelTargetRequest(
                barcode=request.barcode,
                resolved_level=request.resolved_level,
                resolved_taxon=request.resolved_taxon,
                lineage=dict(request.lineage),
            )
            for request in candidate_requests
        }.values()
    )
    contexts = _infer_panel_contexts(
        resolved_taxonomy,
        target_requests,
        levels,
        include_taxa=resolved_include_taxa,
        exclude_taxa=resolved_exclude_taxa,
        progress_callback=progress_callback,
    )
    missing_targets = [
        f"{context.request.barcode}:{context.request.resolved_level}:{context.request.resolved_taxon}"
        for context in contexts.values()
        if not context.taxonomy_accessions
    ]
    if missing_targets:
        raise ValueError(
            "Selected panel targets are absent after applying the panel-analysis taxon scope. "
            "Adjust --include/--exclude or the upstream probe design. Missing targets: "
            + ", ".join(sorted(missing_targets))
        )
    selected_marker_ids = {request.marker_id for request in candidate_requests}
    marker_profiles = _load_selected_marker_profiles(
        resolved_markers,
        selected_marker_ids,
        progress_callback=progress_callback,
    )
    genome_hit_maps_by_label: dict[str, dict[str, set[str]]] | None = None
    index_identifiers_by_label: dict[str, set[str]] | None = None
    if index_resources:
        genome_hit_maps_by_label = {}
        index_identifiers_by_label = {}
        for resource in index_resources:
            if resource.kmer_length is not None:
                too_short = sorted(
                    {
                        request.target_subsequence
                        for request in candidate_requests
                        if len(request.target_subsequence) < resource.kmer_length
                    }
                )
                if too_short:
                    shortest = min(len(sequence) for sequence in too_short)
                    raise ValueError(
                        "At least one Fulgor index k-mer length is longer than a panel query sequence. "
                        f"Index '{resource.label}' uses k={resource.kmer_length}, observed minimum probe target length {shortest}."
                    )
            index_identifiers_by_label[resource.label] = set(resource.identifiers)
            genome_hit_maps_by_label[resource.label] = query_fulgor_index(
                index_file=resource.index_file,
                reference_map_file=resource.reference_map_file,
                query_sequences=[request.target_subsequence for request in candidate_requests],
                fulgor_binary=fulgor_binary,
                threads=index_threads,
                label=resource.label,
                progress_callback=progress_callback,
            )
    panel_candidates, grouped_evaluations = _evaluate_probe_candidates(
        candidate_requests,
        contexts,
        marker_profiles,
        genome_hit_maps_by_label=genome_hit_maps_by_label,
        index_identifiers_by_label=index_identifiers_by_label,
        base_score_weight=base_score_weight,
        sibling_penalty_weight=sibling_penalty_weight,
        global_penalty_weight=global_penalty_weight,
        genome_index_penalty_weight=genome_index_penalty_weight,
        match_config=match_config,
        workers=workers,
        progress_callback=progress_callback,
    )

    _emit_progress(progress_callback, "panel_selection_started", total_targets=len(contexts))
    selected_panels: list[dict[str, Any]] = []
    panel_probe_manifest: list[dict[str, Any]] = []
    ordered_keys = sorted(contexts)
    resolved_workers = resolve_worker_count(workers, total_tasks=len(ordered_keys))
    selection_chunks = build_chunks(len(ordered_keys), workers=resolved_workers)
    completed = 0
    for chunk, outcomes in iter_chunk_results(
        selection_chunks,
        worker=_select_panel_chunk,
        workers=resolved_workers,
        initializer=_init_panel_selection_worker,
        initargs=(
            ordered_keys,
            contexts,
            grouped_evaluations,
            max_probes_per_panel,
            max_probes_per_marker,
            max_probes_per_region,
            allow_overlaps,
            base_score_weight,
            sibling_penalty_weight,
            global_penalty_weight,
            genome_index_penalty_weight,
            interaction_config,
        ),
    ):
        for outcome in outcomes:
            selected_panels.append(outcome.summary_row)
            panel_probe_manifest.extend(outcome.selected_rows)
        completed += chunk[1] - chunk[0]
        _emit_progress(progress_callback, "panel_selection_advanced", completed=completed, total_targets=len(contexts))
    _emit_progress(progress_callback, "panel_selection_completed", total_targets=len(contexts))

    selected_panels.sort(
        key=lambda row: (
            str(row["resolved_level"]),
            str(row["resolved_taxon"]),
            str(row["barcode"]),
        )
    )
    panel_probe_manifest.sort(
        key=lambda row: (
            str(row["barcode"]),
            int(row["selection_rank"]),
            str(row["probe_sequence"]),
        )
    )

    constraint_summary = taxon_constraint_payload(resolved_include_taxa, resolved_exclude_taxa)
    return PanelDesignResult(
        dataset=dataset,
        index_dataset=None if not resolved_index_datasets else resolved_index_datasets[0],
        index_datasets=resolved_index_datasets,
        taxonomy_file=resolved_taxonomy,
        markers_archive=resolved_markers,
        probe_design_prefix=resolved_probe_prefix,
        index_file=None if not index_resources else index_resources[0].index_file,
        index_reference_map_file=None if not index_resources else index_resources[0].reference_map_file,
        index_summary_file=None if not index_resources else index_resources[0].summary_file,
        index_files=[resource.index_file for resource in index_resources],
        index_reference_map_files=[resource.reference_map_file for resource in index_resources],
        index_summary_files=[resource.summary_file for resource in index_resources],
        index_labels=[resource.label for resource in index_resources],
        selected_panels=selected_panels,
        panel_candidates=panel_candidates,
        panel_probe_manifest=panel_probe_manifest,
        analyzed_markers=len(marker_profiles),
        include_taxa=constraint_summary["include_taxa"],
        exclude_taxa=constraint_summary["exclude_taxa"],
        max_probes_per_panel=max_probes_per_panel,
        max_probes_per_marker=max_probes_per_marker,
        max_probes_per_region=max_probes_per_region,
        allow_overlaps=allow_overlaps,
        base_score_weight=base_score_weight,
        sibling_penalty_weight=sibling_penalty_weight,
        global_penalty_weight=global_penalty_weight,
        genome_index_penalty_weight=genome_index_penalty_weight,
        interaction_config=interaction_config,
        match_config=match_config,
    )


def _write_csv(path: Path, rows: Sequence[Mapping[str, Any]]) -> None:
    rows = list(rows)
    fieldnames: list[str] = []
    for row in rows:
        for key in row.keys():
            if key not in fieldnames:
                fieldnames.append(key)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        if fieldnames:
            writer.writeheader()
            for row in rows:
                writer.writerow({key: row.get(key) for key in fieldnames})


def write_panel_design_outputs(
    result: PanelDesignResult,
    output_prefix: str | Path,
) -> dict[str, Path]:
    output_prefix = Path(output_prefix).expanduser().resolve()
    output_prefix.parent.mkdir(parents=True, exist_ok=True)
    paths = {
        "summary": output_prefix.with_name(f"{output_prefix.name}_summary.json"),
        "selected_panels": output_prefix.with_name(f"{output_prefix.name}_selected_panels.csv"),
        "panel_candidates": output_prefix.with_name(f"{output_prefix.name}_panel_candidates.csv"),
        "panel_probes": output_prefix.with_name(f"{output_prefix.name}_panel_probe_manifest.csv"),
    }
    _write_csv(paths["selected_panels"], result.selected_panels)
    _write_csv(paths["panel_candidates"], result.panel_candidates)
    _write_csv(paths["panel_probes"], result.panel_probe_manifest)
    result.output_files = {name: str(path.resolve()) for name, path in paths.items()}
    with paths["summary"].open("w", encoding="utf-8") as handle:
        json.dump(result.to_summary_dict(), handle, indent=2, sort_keys=True)
        handle.write("\n")
    return paths
