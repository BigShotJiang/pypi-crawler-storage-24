# phyloprobe

`phyloprobe` is a GTDB-driven workflow for hierarchical taxon tagging and marker-guided probe design.

The workflow supports both archaeal and bacterial GTDB datasets.

## Documentation

Full documentation is available on Read the Docs:

- https://phyloprobe.readthedocs.io/en/latest/

The documentation covers:

- installation and dataset setup
- the full workflow from taxonomy to final panels
- what happens inside each stage
- detailed descriptions of all outputs

## Current Scope

The workflow stages are:

1. dataset installation and registry management
2. taxonomy parsing and summary
3. reusable Fulgor genome-index construction
4. hierarchical tag design
5. target and marker discovery
6. conserved region discovery from GTDB MSAs
7. nucleotide probe design
8. final probe panel design, with optional genome-wide off-target screening through a Fulgor index

## Installation

`phyloprobe` requires Python 3.10 or newer.

The easiest minimal installation is from PyPI:

```bash
pip install phyloprobe
```

PyPI package:

- https://pypi.org/project/phyloprobe/

This is the recommended installation path for most users. It is enough for the main GTDB-driven workflow:

- dataset installation
- taxonomy parsing
- tag design
- target discovery
- region discovery
- probe design
- panel design without custom Fulgor indexing

For power users who want to build custom whole-genome indices with `fulgor`, use the bundled conda environment from the repository root:

```bash
conda env create -f environment.yml
conda activate phyloprobe
bash scripts/install_fulgor.sh
```

This route installs the Python dependencies plus the compiler and build-toolchain needed to compile `fulgor`. It is the recommended setup when you want to:

- run `phyloprobe index`
- build custom microbial or host genome indices
- add whole-genome off-target screening during `panels`

The complete installation guide is on Read the Docs:

- https://phyloprobe.readthedocs.io/en/latest/installation.html

## Quick Start

Install GTDB assets:

```bash
phyloprobe datasets --taxon archaea
phyloprobe datasets --taxon bacteria
```

The bundled catalog default is GTDB `r226`. If you want an older bundled release, add `--gtdb-release`, for example:

```bash
phyloprobe datasets --taxon archaea --gtdb-release r220
phyloprobe tags --dataset archaea --gtdb-release r220 --output runs --session ar53_r220_demo --positions 3
```

Preferred for multi-stage runs: define one output root and one session name, then let each stage read and write its own session subdirectory automatically:

```bash
phyloprobe tags --dataset archaea --output runs --session ar53_demo --positions 3 --maximise-levels genus --exclusive family:f__Methanobacteriaceae
phyloprobe targets --dataset archaea --output runs --session ar53_demo --include order:o__Methanobacteriales
phyloprobe regions --dataset archaea --output runs --session ar53_demo --include order:o__Methanobacteriales
phyloprobe probes --dataset archaea --output runs --session ar53_demo --include order:o__Methanobacteriales
phyloprobe panels --dataset archaea --output runs --session ar53_demo --include order:o__Methanobacteriales
```

When more than one GTDB release is installed, logical dataset names such as `archaea` and `bacteria` resolve to the bundled default release unless you add `--gtdb-release`.

This creates a layout such as `runs/ar53_demo/tags`, `runs/ar53_demo/targets`, `runs/ar53_demo/regions`, `runs/ar53_demo/probes`, and `runs/ar53_demo/panels`.

Each stage now keeps numbered attempts and a stage manifest. For example:

- `runs/ar53_demo/tags/tags.json`
- `runs/ar53_demo/tags/01/tags_summary.json`
- `runs/ar53_demo/tags/02/tags_summary.json`

By default, downstream stages use the `active_attempt` recorded in the upstream stage manifest. If you want to force an older upstream result, add `--input-attempt`.

If you want to branch from an existing design into an alternative parameter set, keep the same `--output` root, choose a new `--session`, and point `--input-session` at the earlier run:

```bash
phyloprobe targets \
  --dataset archaea \
  --output runs \
  --session ar53_alt \
  --input-session ar53_demo \
  --fallback-policy no_marker_genomes
```

Optional: build a reusable genome index for panel-stage off-target screening, either from a representative-genomes archive:

```bash
phyloprobe index \
  --genome-archive /path/to/gtdb_genomes_reps_r226.tar.gz \
  --output-prefix outputs/ar53_reps_index
```

or from a custom set of specific genomes:

```bash
phyloprobe index \
  --genome-file genomes/genome_1.fna \
  --genome-file genomes/genome_2.fna.gz \
  --output-prefix outputs/custom_index
```

Design tags:

```bash
phyloprobe tags \
  --dataset archaea \
  --output runs \
  --session ar53_demo \
  --positions 3 \
  --maximise-levels genus \
  --exclusive family:f__Methanobacteriaceae
```

Equivalent bacterial example:

```bash
phyloprobe tags \
  --dataset bacteria \
  --output runs \
  --session bac120_demo \
  --positions 3
```

Rank target markers:

```bash
phyloprobe targets \
  --dataset archaea \
  --output runs \
  --session ar53_demo \
  --include order:o__Methanobacteriales
```

```bash
phyloprobe targets \
  --dataset bacteria \
  --output runs \
  --session bac120_demo
```

Discover conserved regions:

```bash
phyloprobe regions \
  --dataset archaea \
  --output runs \
  --session ar53_demo \
  --include order:o__Methanobacteriales
```

```bash
phyloprobe regions \
  --dataset bacteria \
  --output runs \
  --session bac120_demo
```

Design probes:

```bash
phyloprobe probes \
  --dataset archaea \
  --output runs \
  --session ar53_demo \
  --include order:o__Methanobacteriales
```

```bash
phyloprobe probes \
  --dataset bacteria \
  --output runs \
  --session bac120_demo
```

Assemble final probe panels:

```bash
phyloprobe panels \
  --dataset archaea \
  --output runs \
  --session ar53_demo \
  --include order:o__Methanobacteriales
```

```bash
phyloprobe panels \
  --dataset bacteria \
  --output runs \
  --session bac120_demo
```

If you built or installed a Fulgor index, `panels` can also use it to screen probe candidates against whole representative genomes:

```bash
phyloprobe panels \
  --dataset archaea \
  --index-file outputs/ar53_reps_index.fur \
  --index-reference-map outputs/ar53_reps_index_reference_map.csv \
  --index-summary outputs/ar53_reps_index_summary.json \
  --output runs \
  --session ar53_demo
```

You can also combine more than one genome index in the same panel run, for example to explore off-targets jointly against bacterial and host genomes:

```bash
phyloprobe panels \
  --dataset archaea \
  --index-file outputs/bacteria_index.fur \
  --index-reference-map outputs/bacteria_index_reference_map.csv \
  --index-summary outputs/bacteria_index_summary.json \
  --index-file outputs/human_index.fur \
  --index-reference-map outputs/human_index_reference_map.csv \
  --index-summary outputs/human_index_summary.json \
  --output runs \
  --session ar53_demo
```

## Data Requirements

The bundled catalog can contain more than one dataset type:

- GTDB analysis datasets: taxonomy, msa, and markers
- Fulgor index datasets: a `.fur` index, a reference map, and a build summary

You can install the bundled catalog entries or provide a custom catalog JSON with `--catalog-file`.

## Project Status

`phyloprobe` is under active development. The workflow and output contracts are already usable, and ongoing work is focused on optimization, scale, and scoring refinements.

For details, examples, and output reference material, use the Read the Docs site:

- https://phyloprobe.readthedocs.io/en/latest/
