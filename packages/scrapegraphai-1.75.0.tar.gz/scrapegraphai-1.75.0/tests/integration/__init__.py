"""Integration tests for ScrapeGraphAI."""
