"""Adanos CLI package."""

__all__ = ["__version__"]
__version__ = "1.20.4"
