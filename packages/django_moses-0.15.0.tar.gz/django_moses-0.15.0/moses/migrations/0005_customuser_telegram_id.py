from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('moses', '0004_alter_customuser_preferred_language'),
    ]

    operations = [
        migrations.AddField(
            model_name='customuser',
            name='telegram_id',
            field=models.BigIntegerField(blank=True, null=True, verbose_name='Telegram ID'),
        ),
        migrations.AddConstraint(
            model_name='customuser',
            constraint=models.UniqueConstraint(
                condition=models.Q(('telegram_id__isnull', False)),
                fields=('site', 'telegram_id'),
                name='one_telegram_id_per_site',
            ),
        ),
    ]
