from _typeshed import Incomplete
from gllm_datastore.vector_data_store.vector_data_store import BaseVectorDataStore
from gllm_pipeline.router.preset.aurelio.router_builder import build_router_with_data_store as build_router_with_data_store, build_router_with_local_index as build_router_with_local_index
from gllm_pipeline.utils.url_validation import is_safe_url as is_safe_url
from semantic_router.encoders import DenseEncoder
from typing import Any

ROUTES_FILE_PATH: Incomplete
DEFAULT_ROUTES: dict[str, list[str]]
DEFAULT_BATCH_SIZE: int
DEFAULT_ALLOWED_URL_SCHEMES: Incomplete
DEFAULT_ALLOWED_HOSTNAME_SUFFIXES: Incomplete
logger: Incomplete

def get_router_image_multimodal(encoder: DenseEncoder, data_store: BaseVectorDataStore | None = None, batch_size: int = ..., allowed_url_schemes: set[str] = ..., allowed_hostname_suffixes: set[str] = ..., **kwargs: Any) -> dict[str, Any]:
    '''Builds a multimodal router preset for image-based input using DenseEncoder and BaseVectorDataStore.

    This function creates an image router by:
    1. Creating a vector index using BaseVectorDataStore
    2. Populating the index with predefined routes and utterances if empty
    3. Returning a dictionary containing the router configuration

    Args:
        encoder (DenseEncoder): The encoder to use for encoding images.
        data_store (BaseVectorDataStore | None, optional): The vector data store to use. Defaults to None.
        batch_size (int, optional): The batch size for encoding and indexing. Defaults to DEFAULT_BATCH_SIZE.
        allowed_url_schemes (set[str] | None, optional): Allowed URL schemes for image downloads.
            Defaults to DEFAULT_ALLOWED_URL_SCHEMES.
        allowed_hostname_suffixes (set[str] | None, optional): Allowed hostname suffixes for image downloads.
            Defaults to DEFAULT_ALLOWED_HOSTNAME_SUFFIXES.
        **kwargs (Any): Additional keyword arguments forwarded to the prepare function.

    Returns:
        dict[str, Any]: A dictionary containing these keys:
            1. "default_route" (str): The fallback route if no strong match is found.
            2. "valid_routes" (set[str]): Set of all valid route names.
            3. "encoder" (DenseEncoder): The encoder used to embed images from URLs.
            4. "index" (VectorStoreAdapterIndex): The index containing all route utterance embeddings.
            5. "auto_sync" (str): Auto-sync mode setting.
    '''
