# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import TYPE_CHECKING, Dict, List, Optional
from datetime import date
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["IntrafiBalance", "Balance", "BalanceBankLocation"]


class BalanceBankLocation(BaseModel):
    """The primary location of the bank."""

    city: str
    """The bank's city."""

    state: str
    """The bank's state."""


class Balance(BaseModel):
    balance: int
    """The balance, in minor units of `currency`, held with this bank."""

    bank: str
    """The name of the bank holding these funds."""

    bank_location: Optional[BalanceBankLocation] = None
    """The primary location of the bank."""

    fdic_certificate_number: str
    """The Federal Deposit Insurance Corporation (FDIC) certificate number of the bank.

    Because many banks have the same or similar names, this can be used to uniquely
    identify the institution.
    """

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[str, object] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(self, attr: str) -> object: ...
    else:
        __pydantic_extra__: Dict[str, object]


class IntrafiBalance(BaseModel):
    """
    When using IntraFi, each account's balance over the standard FDIC insurance amount is swept to various other institutions. Funds are rebalanced across banks as needed once per business day.
    """

    balances: List[Balance]
    """Each entry represents a balance held at a different bank.

    IntraFi separates the total balance across many participating banks in the
    network.
    """

    currency: Literal["USD"]
    """
    The [ISO 4217](https://en.wikipedia.org/wiki/ISO_4217) code for the account
    currency.

    - `USD` - US Dollar (USD)
    """

    effective_date: date
    """The date this balance reflects."""

    total_balance: int
    """The total balance, in minor units of `currency`.

    Increase reports this balance to IntraFi daily.
    """

    type: Literal["intrafi_balance"]
    """A constant representing the object's type.

    For this resource it will always be `intrafi_balance`.
    """

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[str, object] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(self, attr: str) -> object: ...
    else:
        __pydantic_extra__: Dict[str, object]
