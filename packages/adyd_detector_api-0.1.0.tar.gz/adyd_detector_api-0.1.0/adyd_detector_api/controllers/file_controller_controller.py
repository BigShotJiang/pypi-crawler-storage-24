import connexion
from typing import Dict
from typing import Tuple
from typing import Union

from adyd_detector_api.models.bucket_file_list_dto import BucketFileListDto  # noqa: E501
from adyd_detector_api import util


def list_monster_files(bucket_name):  # noqa: E501
    """list_monster_files

     # noqa: E501

    :param bucket_name: 
    :type bucket_name: str

    :rtype: Union[BucketFileListDto, Tuple[BucketFileListDto, int], Tuple[BucketFileListDto, int, Dict[str, str]]
    """
    return 'do some magic!'
