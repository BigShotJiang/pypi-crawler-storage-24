import unittest

from flask import json

from adyd_detector_api.models.bucket_file_list_dto import BucketFileListDto  # noqa: E501
from adyd_detector_api.test import BaseTestCase


class TestFileControllerController(BaseTestCase):
    """FileControllerController integration test stubs"""

    def test_list_monster_files(self):
        """Test case for list_monster_files

        list_monster_files
        """
        headers = { 
            'Accept': 'application/json',
        }
        response = self.client.open(
            '/files/{bucket_name}'.format(bucket_name='bucket_name_example'),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    unittest.main()
