## [2.0.56] - 2026-03-25

### Fixed
- Audience should be string

