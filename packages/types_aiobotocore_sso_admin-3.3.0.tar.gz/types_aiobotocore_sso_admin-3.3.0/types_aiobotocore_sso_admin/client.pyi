"""
Type annotations for sso-admin service Client.

[Documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/)

Copyright 2026 Vlad Emelianov

Usage::

    ```python
    from aiobotocore.session import get_session
    from types_aiobotocore_sso_admin.client import SSOAdminClient

    session = get_session()
    async with session.create_client("sso-admin") as client:
        client: SSOAdminClient
    ```
"""

from __future__ import annotations

import sys
from collections.abc import Mapping
from types import TracebackType
from typing import Any, overload

from aiobotocore.client import AioBaseClient
from botocore.client import ClientMeta
from botocore.errorfactory import BaseClientExceptions
from botocore.exceptions import ClientError as BotocoreClientError

from .paginator import (
    ListAccountAssignmentCreationStatusPaginator,
    ListAccountAssignmentDeletionStatusPaginator,
    ListAccountAssignmentsForPrincipalPaginator,
    ListAccountAssignmentsPaginator,
    ListAccountsForProvisionedPermissionSetPaginator,
    ListApplicationAccessScopesPaginator,
    ListApplicationAssignmentsForPrincipalPaginator,
    ListApplicationAssignmentsPaginator,
    ListApplicationAuthenticationMethodsPaginator,
    ListApplicationGrantsPaginator,
    ListApplicationProvidersPaginator,
    ListApplicationsPaginator,
    ListCustomerManagedPolicyReferencesInPermissionSetPaginator,
    ListInstancesPaginator,
    ListManagedPoliciesInPermissionSetPaginator,
    ListPermissionSetProvisioningStatusPaginator,
    ListPermissionSetsPaginator,
    ListPermissionSetsProvisionedToAccountPaginator,
    ListRegionsPaginator,
    ListTagsForResourcePaginator,
    ListTrustedTokenIssuersPaginator,
)
from .type_defs import (
    AddRegionRequestTypeDef,
    AddRegionResponseTypeDef,
    AttachCustomerManagedPolicyReferenceToPermissionSetRequestTypeDef,
    AttachManagedPolicyToPermissionSetRequestTypeDef,
    CreateAccountAssignmentRequestTypeDef,
    CreateAccountAssignmentResponseTypeDef,
    CreateApplicationAssignmentRequestTypeDef,
    CreateApplicationRequestTypeDef,
    CreateApplicationResponseTypeDef,
    CreateInstanceAccessControlAttributeConfigurationRequestTypeDef,
    CreateInstanceRequestTypeDef,
    CreateInstanceResponseTypeDef,
    CreatePermissionSetRequestTypeDef,
    CreatePermissionSetResponseTypeDef,
    CreateTrustedTokenIssuerRequestTypeDef,
    CreateTrustedTokenIssuerResponseTypeDef,
    DeleteAccountAssignmentRequestTypeDef,
    DeleteAccountAssignmentResponseTypeDef,
    DeleteApplicationAccessScopeRequestTypeDef,
    DeleteApplicationAssignmentRequestTypeDef,
    DeleteApplicationAuthenticationMethodRequestTypeDef,
    DeleteApplicationGrantRequestTypeDef,
    DeleteApplicationRequestTypeDef,
    DeleteInlinePolicyFromPermissionSetRequestTypeDef,
    DeleteInstanceAccessControlAttributeConfigurationRequestTypeDef,
    DeleteInstanceRequestTypeDef,
    DeletePermissionsBoundaryFromPermissionSetRequestTypeDef,
    DeletePermissionSetRequestTypeDef,
    DeleteTrustedTokenIssuerRequestTypeDef,
    DescribeAccountAssignmentCreationStatusRequestTypeDef,
    DescribeAccountAssignmentCreationStatusResponseTypeDef,
    DescribeAccountAssignmentDeletionStatusRequestTypeDef,
    DescribeAccountAssignmentDeletionStatusResponseTypeDef,
    DescribeApplicationAssignmentRequestTypeDef,
    DescribeApplicationAssignmentResponseTypeDef,
    DescribeApplicationProviderRequestTypeDef,
    DescribeApplicationProviderResponseTypeDef,
    DescribeApplicationRequestTypeDef,
    DescribeApplicationResponseTypeDef,
    DescribeInstanceAccessControlAttributeConfigurationRequestTypeDef,
    DescribeInstanceAccessControlAttributeConfigurationResponseTypeDef,
    DescribeInstanceRequestTypeDef,
    DescribeInstanceResponseTypeDef,
    DescribePermissionSetProvisioningStatusRequestTypeDef,
    DescribePermissionSetProvisioningStatusResponseTypeDef,
    DescribePermissionSetRequestTypeDef,
    DescribePermissionSetResponseTypeDef,
    DescribeRegionRequestTypeDef,
    DescribeRegionResponseTypeDef,
    DescribeTrustedTokenIssuerRequestTypeDef,
    DescribeTrustedTokenIssuerResponseTypeDef,
    DetachCustomerManagedPolicyReferenceFromPermissionSetRequestTypeDef,
    DetachManagedPolicyFromPermissionSetRequestTypeDef,
    EmptyResponseMetadataTypeDef,
    GetApplicationAccessScopeRequestTypeDef,
    GetApplicationAccessScopeResponseTypeDef,
    GetApplicationAssignmentConfigurationRequestTypeDef,
    GetApplicationAssignmentConfigurationResponseTypeDef,
    GetApplicationAuthenticationMethodRequestTypeDef,
    GetApplicationAuthenticationMethodResponseTypeDef,
    GetApplicationGrantRequestTypeDef,
    GetApplicationGrantResponseTypeDef,
    GetApplicationSessionConfigurationRequestTypeDef,
    GetApplicationSessionConfigurationResponseTypeDef,
    GetInlinePolicyForPermissionSetRequestTypeDef,
    GetInlinePolicyForPermissionSetResponseTypeDef,
    GetPermissionsBoundaryForPermissionSetRequestTypeDef,
    GetPermissionsBoundaryForPermissionSetResponseTypeDef,
    ListAccountAssignmentCreationStatusRequestTypeDef,
    ListAccountAssignmentCreationStatusResponseTypeDef,
    ListAccountAssignmentDeletionStatusRequestTypeDef,
    ListAccountAssignmentDeletionStatusResponseTypeDef,
    ListAccountAssignmentsForPrincipalRequestTypeDef,
    ListAccountAssignmentsForPrincipalResponseTypeDef,
    ListAccountAssignmentsRequestTypeDef,
    ListAccountAssignmentsResponseTypeDef,
    ListAccountsForProvisionedPermissionSetRequestTypeDef,
    ListAccountsForProvisionedPermissionSetResponseTypeDef,
    ListApplicationAccessScopesRequestTypeDef,
    ListApplicationAccessScopesResponseTypeDef,
    ListApplicationAssignmentsForPrincipalRequestTypeDef,
    ListApplicationAssignmentsForPrincipalResponseTypeDef,
    ListApplicationAssignmentsRequestTypeDef,
    ListApplicationAssignmentsResponseTypeDef,
    ListApplicationAuthenticationMethodsRequestTypeDef,
    ListApplicationAuthenticationMethodsResponseTypeDef,
    ListApplicationGrantsRequestTypeDef,
    ListApplicationGrantsResponseTypeDef,
    ListApplicationProvidersRequestTypeDef,
    ListApplicationProvidersResponseTypeDef,
    ListApplicationsRequestTypeDef,
    ListApplicationsResponseTypeDef,
    ListCustomerManagedPolicyReferencesInPermissionSetRequestTypeDef,
    ListCustomerManagedPolicyReferencesInPermissionSetResponseTypeDef,
    ListInstancesRequestTypeDef,
    ListInstancesResponseTypeDef,
    ListManagedPoliciesInPermissionSetRequestTypeDef,
    ListManagedPoliciesInPermissionSetResponseTypeDef,
    ListPermissionSetProvisioningStatusRequestTypeDef,
    ListPermissionSetProvisioningStatusResponseTypeDef,
    ListPermissionSetsProvisionedToAccountRequestTypeDef,
    ListPermissionSetsProvisionedToAccountResponseTypeDef,
    ListPermissionSetsRequestTypeDef,
    ListPermissionSetsResponseTypeDef,
    ListRegionsRequestTypeDef,
    ListRegionsResponseTypeDef,
    ListTagsForResourceRequestTypeDef,
    ListTagsForResourceResponseTypeDef,
    ListTrustedTokenIssuersRequestTypeDef,
    ListTrustedTokenIssuersResponseTypeDef,
    ProvisionPermissionSetRequestTypeDef,
    ProvisionPermissionSetResponseTypeDef,
    PutApplicationAccessScopeRequestTypeDef,
    PutApplicationAssignmentConfigurationRequestTypeDef,
    PutApplicationAuthenticationMethodRequestTypeDef,
    PutApplicationGrantRequestTypeDef,
    PutApplicationSessionConfigurationRequestTypeDef,
    PutInlinePolicyToPermissionSetRequestTypeDef,
    PutPermissionsBoundaryToPermissionSetRequestTypeDef,
    RemoveRegionRequestTypeDef,
    RemoveRegionResponseTypeDef,
    TagResourceRequestTypeDef,
    UntagResourceRequestTypeDef,
    UpdateApplicationRequestTypeDef,
    UpdateInstanceAccessControlAttributeConfigurationRequestTypeDef,
    UpdateInstanceRequestTypeDef,
    UpdatePermissionSetRequestTypeDef,
    UpdateTrustedTokenIssuerRequestTypeDef,
)

if sys.version_info >= (3, 12):
    from typing import Literal, Self, Unpack
else:
    from typing_extensions import Literal, Self, Unpack

__all__ = ("SSOAdminClient",)

class Exceptions(BaseClientExceptions):
    AccessDeniedException: type[BotocoreClientError]
    ClientError: type[BotocoreClientError]
    ConflictException: type[BotocoreClientError]
    InternalServerException: type[BotocoreClientError]
    ResourceNotFoundException: type[BotocoreClientError]
    ServiceQuotaExceededException: type[BotocoreClientError]
    ThrottlingException: type[BotocoreClientError]
    ValidationException: type[BotocoreClientError]

class SSOAdminClient(AioBaseClient):
    """
    [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin.html#SSOAdmin.Client)
    [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/)
    """

    meta: ClientMeta

    @property
    def exceptions(self) -> Exceptions:
        """
        SSOAdminClient exceptions.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin.html#SSOAdmin.Client)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#exceptions)
        """

    def can_paginate(self, operation_name: str) -> bool:
        """
        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/can_paginate.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#can_paginate)
        """

    async def generate_presigned_url(
        self,
        ClientMethod: str,
        Params: Mapping[str, Any] = ...,
        ExpiresIn: int = 3600,
        HttpMethod: str = ...,
    ) -> str:
        """
        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/generate_presigned_url.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#generate_presigned_url)
        """

    async def add_region(
        self, **kwargs: Unpack[AddRegionRequestTypeDef]
    ) -> AddRegionResponseTypeDef:
        """
        Adds a Region to an IAM Identity Center instance.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/add_region.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#add_region)
        """

    async def attach_customer_managed_policy_reference_to_permission_set(
        self, **kwargs: Unpack[AttachCustomerManagedPolicyReferenceToPermissionSetRequestTypeDef]
    ) -> dict[str, Any]:
        """
        Attaches the specified customer managed policy to the specified
        <a>PermissionSet</a>.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/attach_customer_managed_policy_reference_to_permission_set.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#attach_customer_managed_policy_reference_to_permission_set)
        """

    async def attach_managed_policy_to_permission_set(
        self, **kwargs: Unpack[AttachManagedPolicyToPermissionSetRequestTypeDef]
    ) -> dict[str, Any]:
        """
        Attaches an Amazon Web Services managed policy ARN to a permission set.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/attach_managed_policy_to_permission_set.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#attach_managed_policy_to_permission_set)
        """

    async def create_account_assignment(
        self, **kwargs: Unpack[CreateAccountAssignmentRequestTypeDef]
    ) -> CreateAccountAssignmentResponseTypeDef:
        """
        Assigns access to a principal for a specified Amazon Web Services account using
        a specified permission set.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/create_account_assignment.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#create_account_assignment)
        """

    async def create_application(
        self, **kwargs: Unpack[CreateApplicationRequestTypeDef]
    ) -> CreateApplicationResponseTypeDef:
        """
        Creates an OAuth 2.0 customer managed application in IAM Identity Center for
        the given application provider.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/create_application.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#create_application)
        """

    async def create_application_assignment(
        self, **kwargs: Unpack[CreateApplicationAssignmentRequestTypeDef]
    ) -> dict[str, Any]:
        """
        Grant application access to a user or group.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/create_application_assignment.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#create_application_assignment)
        """

    async def create_instance(
        self, **kwargs: Unpack[CreateInstanceRequestTypeDef]
    ) -> CreateInstanceResponseTypeDef:
        """
        Creates an instance of IAM Identity Center for a standalone Amazon Web Services
        account that is not managed by Organizations or a member Amazon Web Services
        account in an organization.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/create_instance.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#create_instance)
        """

    async def create_instance_access_control_attribute_configuration(
        self, **kwargs: Unpack[CreateInstanceAccessControlAttributeConfigurationRequestTypeDef]
    ) -> dict[str, Any]:
        """
        Enables the attributes-based access control (ABAC) feature for the specified
        IAM Identity Center instance.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/create_instance_access_control_attribute_configuration.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#create_instance_access_control_attribute_configuration)
        """

    async def create_permission_set(
        self, **kwargs: Unpack[CreatePermissionSetRequestTypeDef]
    ) -> CreatePermissionSetResponseTypeDef:
        """
        Creates a permission set within a specified IAM Identity Center instance.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/create_permission_set.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#create_permission_set)
        """

    async def create_trusted_token_issuer(
        self, **kwargs: Unpack[CreateTrustedTokenIssuerRequestTypeDef]
    ) -> CreateTrustedTokenIssuerResponseTypeDef:
        """
        Creates a connection to a trusted token issuer in an instance of IAM Identity
        Center.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/create_trusted_token_issuer.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#create_trusted_token_issuer)
        """

    async def delete_account_assignment(
        self, **kwargs: Unpack[DeleteAccountAssignmentRequestTypeDef]
    ) -> DeleteAccountAssignmentResponseTypeDef:
        """
        Deletes a principal's access from a specified Amazon Web Services account using
        a specified permission set.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/delete_account_assignment.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#delete_account_assignment)
        """

    async def delete_application(
        self, **kwargs: Unpack[DeleteApplicationRequestTypeDef]
    ) -> dict[str, Any]:
        """
        Deletes the association with the application.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/delete_application.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#delete_application)
        """

    async def delete_application_access_scope(
        self, **kwargs: Unpack[DeleteApplicationAccessScopeRequestTypeDef]
    ) -> EmptyResponseMetadataTypeDef:
        """
        Deletes an IAM Identity Center access scope from an application.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/delete_application_access_scope.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#delete_application_access_scope)
        """

    async def delete_application_assignment(
        self, **kwargs: Unpack[DeleteApplicationAssignmentRequestTypeDef]
    ) -> dict[str, Any]:
        """
        Revoke application access to an application by deleting application assignments
        for a user or group.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/delete_application_assignment.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#delete_application_assignment)
        """

    async def delete_application_authentication_method(
        self, **kwargs: Unpack[DeleteApplicationAuthenticationMethodRequestTypeDef]
    ) -> EmptyResponseMetadataTypeDef:
        """
        Deletes an authentication method from an application.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/delete_application_authentication_method.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#delete_application_authentication_method)
        """

    async def delete_application_grant(
        self, **kwargs: Unpack[DeleteApplicationGrantRequestTypeDef]
    ) -> EmptyResponseMetadataTypeDef:
        """
        Deletes a grant from an application.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/delete_application_grant.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#delete_application_grant)
        """

    async def delete_inline_policy_from_permission_set(
        self, **kwargs: Unpack[DeleteInlinePolicyFromPermissionSetRequestTypeDef]
    ) -> dict[str, Any]:
        """
        Deletes the inline policy from a specified permission set.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/delete_inline_policy_from_permission_set.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#delete_inline_policy_from_permission_set)
        """

    async def delete_instance(
        self, **kwargs: Unpack[DeleteInstanceRequestTypeDef]
    ) -> dict[str, Any]:
        """
        Deletes the instance of IAM Identity Center.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/delete_instance.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#delete_instance)
        """

    async def delete_instance_access_control_attribute_configuration(
        self, **kwargs: Unpack[DeleteInstanceAccessControlAttributeConfigurationRequestTypeDef]
    ) -> dict[str, Any]:
        """
        Disables the attributes-based access control (ABAC) feature for the specified
        IAM Identity Center instance and deletes all of the attribute mappings that
        have been configured.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/delete_instance_access_control_attribute_configuration.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#delete_instance_access_control_attribute_configuration)
        """

    async def delete_permission_set(
        self, **kwargs: Unpack[DeletePermissionSetRequestTypeDef]
    ) -> dict[str, Any]:
        """
        Deletes the specified permission set.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/delete_permission_set.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#delete_permission_set)
        """

    async def delete_permissions_boundary_from_permission_set(
        self, **kwargs: Unpack[DeletePermissionsBoundaryFromPermissionSetRequestTypeDef]
    ) -> dict[str, Any]:
        """
        Deletes the permissions boundary from a specified <a>PermissionSet</a>.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/delete_permissions_boundary_from_permission_set.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#delete_permissions_boundary_from_permission_set)
        """

    async def delete_trusted_token_issuer(
        self, **kwargs: Unpack[DeleteTrustedTokenIssuerRequestTypeDef]
    ) -> dict[str, Any]:
        """
        Deletes a trusted token issuer configuration from an instance of IAM Identity
        Center.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/delete_trusted_token_issuer.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#delete_trusted_token_issuer)
        """

    async def describe_account_assignment_creation_status(
        self, **kwargs: Unpack[DescribeAccountAssignmentCreationStatusRequestTypeDef]
    ) -> DescribeAccountAssignmentCreationStatusResponseTypeDef:
        """
        Describes the status of the assignment creation request.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/describe_account_assignment_creation_status.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#describe_account_assignment_creation_status)
        """

    async def describe_account_assignment_deletion_status(
        self, **kwargs: Unpack[DescribeAccountAssignmentDeletionStatusRequestTypeDef]
    ) -> DescribeAccountAssignmentDeletionStatusResponseTypeDef:
        """
        Describes the status of the assignment deletion request.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/describe_account_assignment_deletion_status.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#describe_account_assignment_deletion_status)
        """

    async def describe_application(
        self, **kwargs: Unpack[DescribeApplicationRequestTypeDef]
    ) -> DescribeApplicationResponseTypeDef:
        """
        Retrieves the details of an application associated with an instance of IAM
        Identity Center.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/describe_application.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#describe_application)
        """

    async def describe_application_assignment(
        self, **kwargs: Unpack[DescribeApplicationAssignmentRequestTypeDef]
    ) -> DescribeApplicationAssignmentResponseTypeDef:
        """
        Retrieves a direct assignment of a user or group to an application.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/describe_application_assignment.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#describe_application_assignment)
        """

    async def describe_application_provider(
        self, **kwargs: Unpack[DescribeApplicationProviderRequestTypeDef]
    ) -> DescribeApplicationProviderResponseTypeDef:
        """
        Retrieves details about a provider that can be used to connect an Amazon Web
        Services managed application or customer managed application to IAM Identity
        Center.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/describe_application_provider.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#describe_application_provider)
        """

    async def describe_instance(
        self, **kwargs: Unpack[DescribeInstanceRequestTypeDef]
    ) -> DescribeInstanceResponseTypeDef:
        """
        Returns the details of an instance of IAM Identity Center.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/describe_instance.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#describe_instance)
        """

    async def describe_instance_access_control_attribute_configuration(
        self, **kwargs: Unpack[DescribeInstanceAccessControlAttributeConfigurationRequestTypeDef]
    ) -> DescribeInstanceAccessControlAttributeConfigurationResponseTypeDef:
        """
        Returns the list of IAM Identity Center identity store attributes that have
        been configured to work with attributes-based access control (ABAC) for the
        specified IAM Identity Center instance.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/describe_instance_access_control_attribute_configuration.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#describe_instance_access_control_attribute_configuration)
        """

    async def describe_permission_set(
        self, **kwargs: Unpack[DescribePermissionSetRequestTypeDef]
    ) -> DescribePermissionSetResponseTypeDef:
        """
        Gets the details of the permission set.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/describe_permission_set.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#describe_permission_set)
        """

    async def describe_permission_set_provisioning_status(
        self, **kwargs: Unpack[DescribePermissionSetProvisioningStatusRequestTypeDef]
    ) -> DescribePermissionSetProvisioningStatusResponseTypeDef:
        """
        Describes the status for the given permission set provisioning request.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/describe_permission_set_provisioning_status.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#describe_permission_set_provisioning_status)
        """

    async def describe_region(
        self, **kwargs: Unpack[DescribeRegionRequestTypeDef]
    ) -> DescribeRegionResponseTypeDef:
        """
        Retrieves details about a specific Region enabled in an IAM Identity Center
        instance.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/describe_region.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#describe_region)
        """

    async def describe_trusted_token_issuer(
        self, **kwargs: Unpack[DescribeTrustedTokenIssuerRequestTypeDef]
    ) -> DescribeTrustedTokenIssuerResponseTypeDef:
        """
        Retrieves details about a trusted token issuer configuration stored in an
        instance of IAM Identity Center.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/describe_trusted_token_issuer.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#describe_trusted_token_issuer)
        """

    async def detach_customer_managed_policy_reference_from_permission_set(
        self, **kwargs: Unpack[DetachCustomerManagedPolicyReferenceFromPermissionSetRequestTypeDef]
    ) -> dict[str, Any]:
        """
        Detaches the specified customer managed policy from the specified
        <a>PermissionSet</a>.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/detach_customer_managed_policy_reference_from_permission_set.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#detach_customer_managed_policy_reference_from_permission_set)
        """

    async def detach_managed_policy_from_permission_set(
        self, **kwargs: Unpack[DetachManagedPolicyFromPermissionSetRequestTypeDef]
    ) -> dict[str, Any]:
        """
        Detaches the attached Amazon Web Services managed policy ARN from the specified
        permission set.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/detach_managed_policy_from_permission_set.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#detach_managed_policy_from_permission_set)
        """

    async def get_application_access_scope(
        self, **kwargs: Unpack[GetApplicationAccessScopeRequestTypeDef]
    ) -> GetApplicationAccessScopeResponseTypeDef:
        """
        Retrieves the authorized targets for an IAM Identity Center access scope for an
        application.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/get_application_access_scope.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#get_application_access_scope)
        """

    async def get_application_assignment_configuration(
        self, **kwargs: Unpack[GetApplicationAssignmentConfigurationRequestTypeDef]
    ) -> GetApplicationAssignmentConfigurationResponseTypeDef:
        """
        Retrieves the configuration of <a>PutApplicationAssignmentConfiguration</a>.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/get_application_assignment_configuration.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#get_application_assignment_configuration)
        """

    async def get_application_authentication_method(
        self, **kwargs: Unpack[GetApplicationAuthenticationMethodRequestTypeDef]
    ) -> GetApplicationAuthenticationMethodResponseTypeDef:
        """
        Retrieves details about an authentication method used by an application.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/get_application_authentication_method.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#get_application_authentication_method)
        """

    async def get_application_grant(
        self, **kwargs: Unpack[GetApplicationGrantRequestTypeDef]
    ) -> GetApplicationGrantResponseTypeDef:
        """
        Retrieves details about an application grant.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/get_application_grant.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#get_application_grant)
        """

    async def get_application_session_configuration(
        self, **kwargs: Unpack[GetApplicationSessionConfigurationRequestTypeDef]
    ) -> GetApplicationSessionConfigurationResponseTypeDef:
        """
        Retrieves the session configuration for an application in IAM Identity Center.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/get_application_session_configuration.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#get_application_session_configuration)
        """

    async def get_inline_policy_for_permission_set(
        self, **kwargs: Unpack[GetInlinePolicyForPermissionSetRequestTypeDef]
    ) -> GetInlinePolicyForPermissionSetResponseTypeDef:
        """
        Obtains the inline policy assigned to the permission set.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/get_inline_policy_for_permission_set.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#get_inline_policy_for_permission_set)
        """

    async def get_permissions_boundary_for_permission_set(
        self, **kwargs: Unpack[GetPermissionsBoundaryForPermissionSetRequestTypeDef]
    ) -> GetPermissionsBoundaryForPermissionSetResponseTypeDef:
        """
        Obtains the permissions boundary for a specified <a>PermissionSet</a>.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/get_permissions_boundary_for_permission_set.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#get_permissions_boundary_for_permission_set)
        """

    async def list_account_assignment_creation_status(
        self, **kwargs: Unpack[ListAccountAssignmentCreationStatusRequestTypeDef]
    ) -> ListAccountAssignmentCreationStatusResponseTypeDef:
        """
        Lists the status of the Amazon Web Services account assignment creation
        requests for a specified IAM Identity Center instance.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/list_account_assignment_creation_status.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#list_account_assignment_creation_status)
        """

    async def list_account_assignment_deletion_status(
        self, **kwargs: Unpack[ListAccountAssignmentDeletionStatusRequestTypeDef]
    ) -> ListAccountAssignmentDeletionStatusResponseTypeDef:
        """
        Lists the status of the Amazon Web Services account assignment deletion
        requests for a specified IAM Identity Center instance.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/list_account_assignment_deletion_status.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#list_account_assignment_deletion_status)
        """

    async def list_account_assignments(
        self, **kwargs: Unpack[ListAccountAssignmentsRequestTypeDef]
    ) -> ListAccountAssignmentsResponseTypeDef:
        """
        Lists the assignee of the specified Amazon Web Services account with the
        specified permission set.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/list_account_assignments.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#list_account_assignments)
        """

    async def list_account_assignments_for_principal(
        self, **kwargs: Unpack[ListAccountAssignmentsForPrincipalRequestTypeDef]
    ) -> ListAccountAssignmentsForPrincipalResponseTypeDef:
        """
        Retrieves a list of the IAM Identity Center associated Amazon Web Services
        accounts that the principal has access to.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/list_account_assignments_for_principal.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#list_account_assignments_for_principal)
        """

    async def list_accounts_for_provisioned_permission_set(
        self, **kwargs: Unpack[ListAccountsForProvisionedPermissionSetRequestTypeDef]
    ) -> ListAccountsForProvisionedPermissionSetResponseTypeDef:
        """
        Lists all the Amazon Web Services accounts where the specified permission set
        is provisioned.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/list_accounts_for_provisioned_permission_set.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#list_accounts_for_provisioned_permission_set)
        """

    async def list_application_access_scopes(
        self, **kwargs: Unpack[ListApplicationAccessScopesRequestTypeDef]
    ) -> ListApplicationAccessScopesResponseTypeDef:
        """
        Lists the access scopes and authorized targets associated with an application.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/list_application_access_scopes.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#list_application_access_scopes)
        """

    async def list_application_assignments(
        self, **kwargs: Unpack[ListApplicationAssignmentsRequestTypeDef]
    ) -> ListApplicationAssignmentsResponseTypeDef:
        """
        Lists Amazon Web Services account users that are assigned to an application.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/list_application_assignments.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#list_application_assignments)
        """

    async def list_application_assignments_for_principal(
        self, **kwargs: Unpack[ListApplicationAssignmentsForPrincipalRequestTypeDef]
    ) -> ListApplicationAssignmentsForPrincipalResponseTypeDef:
        """
        Lists the applications to which a specified principal is assigned.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/list_application_assignments_for_principal.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#list_application_assignments_for_principal)
        """

    async def list_application_authentication_methods(
        self, **kwargs: Unpack[ListApplicationAuthenticationMethodsRequestTypeDef]
    ) -> ListApplicationAuthenticationMethodsResponseTypeDef:
        """
        Lists all of the authentication methods supported by the specified application.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/list_application_authentication_methods.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#list_application_authentication_methods)
        """

    async def list_application_grants(
        self, **kwargs: Unpack[ListApplicationGrantsRequestTypeDef]
    ) -> ListApplicationGrantsResponseTypeDef:
        """
        List the grants associated with an application.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/list_application_grants.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#list_application_grants)
        """

    async def list_application_providers(
        self, **kwargs: Unpack[ListApplicationProvidersRequestTypeDef]
    ) -> ListApplicationProvidersResponseTypeDef:
        """
        Lists the application providers configured in the IAM Identity Center identity
        store.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/list_application_providers.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#list_application_providers)
        """

    async def list_applications(
        self, **kwargs: Unpack[ListApplicationsRequestTypeDef]
    ) -> ListApplicationsResponseTypeDef:
        """
        Lists all applications associated with the instance of IAM Identity Center.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/list_applications.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#list_applications)
        """

    async def list_customer_managed_policy_references_in_permission_set(
        self, **kwargs: Unpack[ListCustomerManagedPolicyReferencesInPermissionSetRequestTypeDef]
    ) -> ListCustomerManagedPolicyReferencesInPermissionSetResponseTypeDef:
        """
        Lists all customer managed policies attached to a specified
        <a>PermissionSet</a>.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/list_customer_managed_policy_references_in_permission_set.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#list_customer_managed_policy_references_in_permission_set)
        """

    async def list_instances(
        self, **kwargs: Unpack[ListInstancesRequestTypeDef]
    ) -> ListInstancesResponseTypeDef:
        """
        Lists the details of the organization and account instances of IAM Identity
        Center that were created in or visible to the account calling this API.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/list_instances.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#list_instances)
        """

    async def list_managed_policies_in_permission_set(
        self, **kwargs: Unpack[ListManagedPoliciesInPermissionSetRequestTypeDef]
    ) -> ListManagedPoliciesInPermissionSetResponseTypeDef:
        """
        Lists the Amazon Web Services managed policy that is attached to a specified
        permission set.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/list_managed_policies_in_permission_set.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#list_managed_policies_in_permission_set)
        """

    async def list_permission_set_provisioning_status(
        self, **kwargs: Unpack[ListPermissionSetProvisioningStatusRequestTypeDef]
    ) -> ListPermissionSetProvisioningStatusResponseTypeDef:
        """
        Lists the status of the permission set provisioning requests for a specified
        IAM Identity Center instance.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/list_permission_set_provisioning_status.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#list_permission_set_provisioning_status)
        """

    async def list_permission_sets(
        self, **kwargs: Unpack[ListPermissionSetsRequestTypeDef]
    ) -> ListPermissionSetsResponseTypeDef:
        """
        Lists the <a>PermissionSet</a>s in an IAM Identity Center instance.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/list_permission_sets.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#list_permission_sets)
        """

    async def list_permission_sets_provisioned_to_account(
        self, **kwargs: Unpack[ListPermissionSetsProvisionedToAccountRequestTypeDef]
    ) -> ListPermissionSetsProvisionedToAccountResponseTypeDef:
        """
        Lists all the permission sets that are provisioned to a specified Amazon Web
        Services account.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/list_permission_sets_provisioned_to_account.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#list_permission_sets_provisioned_to_account)
        """

    async def list_regions(
        self, **kwargs: Unpack[ListRegionsRequestTypeDef]
    ) -> ListRegionsResponseTypeDef:
        """
        Lists all enabled Regions of an IAM Identity Center instance, including those
        that are being added or removed.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/list_regions.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#list_regions)
        """

    async def list_tags_for_resource(
        self, **kwargs: Unpack[ListTagsForResourceRequestTypeDef]
    ) -> ListTagsForResourceResponseTypeDef:
        """
        Lists the tags that are attached to a specified resource.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/list_tags_for_resource.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#list_tags_for_resource)
        """

    async def list_trusted_token_issuers(
        self, **kwargs: Unpack[ListTrustedTokenIssuersRequestTypeDef]
    ) -> ListTrustedTokenIssuersResponseTypeDef:
        """
        Lists all the trusted token issuers configured in an instance of IAM Identity
        Center.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/list_trusted_token_issuers.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#list_trusted_token_issuers)
        """

    async def provision_permission_set(
        self, **kwargs: Unpack[ProvisionPermissionSetRequestTypeDef]
    ) -> ProvisionPermissionSetResponseTypeDef:
        """
        The process by which a specified permission set is provisioned to the specified
        target.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/provision_permission_set.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#provision_permission_set)
        """

    async def put_application_access_scope(
        self, **kwargs: Unpack[PutApplicationAccessScopeRequestTypeDef]
    ) -> EmptyResponseMetadataTypeDef:
        """
        Adds or updates the list of authorized targets for an IAM Identity Center
        access scope for an application.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/put_application_access_scope.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#put_application_access_scope)
        """

    async def put_application_assignment_configuration(
        self, **kwargs: Unpack[PutApplicationAssignmentConfigurationRequestTypeDef]
    ) -> dict[str, Any]:
        """
        Configure how users gain access to an application.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/put_application_assignment_configuration.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#put_application_assignment_configuration)
        """

    async def put_application_authentication_method(
        self, **kwargs: Unpack[PutApplicationAuthenticationMethodRequestTypeDef]
    ) -> EmptyResponseMetadataTypeDef:
        """
        Adds or updates an authentication method for an application.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/put_application_authentication_method.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#put_application_authentication_method)
        """

    async def put_application_grant(
        self, **kwargs: Unpack[PutApplicationGrantRequestTypeDef]
    ) -> EmptyResponseMetadataTypeDef:
        """
        Creates a configuration for an application to use grants.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/put_application_grant.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#put_application_grant)
        """

    async def put_application_session_configuration(
        self, **kwargs: Unpack[PutApplicationSessionConfigurationRequestTypeDef]
    ) -> dict[str, Any]:
        """
        Updates the session configuration for an application in IAM Identity Center.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/put_application_session_configuration.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#put_application_session_configuration)
        """

    async def put_inline_policy_to_permission_set(
        self, **kwargs: Unpack[PutInlinePolicyToPermissionSetRequestTypeDef]
    ) -> dict[str, Any]:
        """
        Attaches an inline policy to a permission set.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/put_inline_policy_to_permission_set.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#put_inline_policy_to_permission_set)
        """

    async def put_permissions_boundary_to_permission_set(
        self, **kwargs: Unpack[PutPermissionsBoundaryToPermissionSetRequestTypeDef]
    ) -> dict[str, Any]:
        """
        Attaches an Amazon Web Services managed or customer managed policy to the
        specified <a>PermissionSet</a> as a permissions boundary.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/put_permissions_boundary_to_permission_set.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#put_permissions_boundary_to_permission_set)
        """

    async def remove_region(
        self, **kwargs: Unpack[RemoveRegionRequestTypeDef]
    ) -> RemoveRegionResponseTypeDef:
        """
        Removes an additional Region from an IAM Identity Center instance.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/remove_region.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#remove_region)
        """

    async def tag_resource(self, **kwargs: Unpack[TagResourceRequestTypeDef]) -> dict[str, Any]:
        """
        Associates a set of tags with a specified resource.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/tag_resource.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#tag_resource)
        """

    async def untag_resource(self, **kwargs: Unpack[UntagResourceRequestTypeDef]) -> dict[str, Any]:
        """
        Disassociates a set of tags from a specified resource.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/untag_resource.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#untag_resource)
        """

    async def update_application(
        self, **kwargs: Unpack[UpdateApplicationRequestTypeDef]
    ) -> dict[str, Any]:
        """
        Updates application properties.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/update_application.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#update_application)
        """

    async def update_instance(
        self, **kwargs: Unpack[UpdateInstanceRequestTypeDef]
    ) -> dict[str, Any]:
        """
        Update the details for the instance of IAM Identity Center that is owned by the
        Amazon Web Services account.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/update_instance.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#update_instance)
        """

    async def update_instance_access_control_attribute_configuration(
        self, **kwargs: Unpack[UpdateInstanceAccessControlAttributeConfigurationRequestTypeDef]
    ) -> dict[str, Any]:
        """
        Updates the IAM Identity Center identity store attributes that you can use with
        the IAM Identity Center instance for attributes-based access control (ABAC).

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/update_instance_access_control_attribute_configuration.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#update_instance_access_control_attribute_configuration)
        """

    async def update_permission_set(
        self, **kwargs: Unpack[UpdatePermissionSetRequestTypeDef]
    ) -> dict[str, Any]:
        """
        Updates an existing permission set.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/update_permission_set.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#update_permission_set)
        """

    async def update_trusted_token_issuer(
        self, **kwargs: Unpack[UpdateTrustedTokenIssuerRequestTypeDef]
    ) -> dict[str, Any]:
        """
        Updates the name of the trusted token issuer, or the path of a source attribute
        or destination attribute for a trusted token issuer configuration.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/update_trusted_token_issuer.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#update_trusted_token_issuer)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_account_assignment_creation_status"]
    ) -> ListAccountAssignmentCreationStatusPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/get_paginator.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_account_assignment_deletion_status"]
    ) -> ListAccountAssignmentDeletionStatusPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/get_paginator.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_account_assignments_for_principal"]
    ) -> ListAccountAssignmentsForPrincipalPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/get_paginator.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_account_assignments"]
    ) -> ListAccountAssignmentsPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/get_paginator.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_accounts_for_provisioned_permission_set"]
    ) -> ListAccountsForProvisionedPermissionSetPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/get_paginator.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_application_access_scopes"]
    ) -> ListApplicationAccessScopesPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/get_paginator.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_application_assignments_for_principal"]
    ) -> ListApplicationAssignmentsForPrincipalPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/get_paginator.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_application_assignments"]
    ) -> ListApplicationAssignmentsPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/get_paginator.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_application_authentication_methods"]
    ) -> ListApplicationAuthenticationMethodsPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/get_paginator.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_application_grants"]
    ) -> ListApplicationGrantsPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/get_paginator.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_application_providers"]
    ) -> ListApplicationProvidersPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/get_paginator.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_applications"]
    ) -> ListApplicationsPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/get_paginator.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_customer_managed_policy_references_in_permission_set"]
    ) -> ListCustomerManagedPolicyReferencesInPermissionSetPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/get_paginator.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_instances"]
    ) -> ListInstancesPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/get_paginator.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_managed_policies_in_permission_set"]
    ) -> ListManagedPoliciesInPermissionSetPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/get_paginator.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_permission_set_provisioning_status"]
    ) -> ListPermissionSetProvisioningStatusPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/get_paginator.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_permission_sets"]
    ) -> ListPermissionSetsPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/get_paginator.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_permission_sets_provisioned_to_account"]
    ) -> ListPermissionSetsProvisionedToAccountPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/get_paginator.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_regions"]
    ) -> ListRegionsPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/get_paginator.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_tags_for_resource"]
    ) -> ListTagsForResourcePaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/get_paginator.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_trusted_token_issuers"]
    ) -> ListTrustedTokenIssuersPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin/client/get_paginator.html)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/#get_paginator)
        """

    async def __aenter__(self) -> Self:
        """
        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin.html#SSOAdmin.Client)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/)
        """

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        """
        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sso-admin.html#SSOAdmin.Client)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_sso_admin/client/)
        """
