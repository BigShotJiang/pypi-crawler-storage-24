from setuptools import setup, find_packages

setup(
    name="BitMapVault",
    version="1.0.0",
    author="Maddo",
    description="A bit-masking encryption engine.",
    packages=find_packages(),
    install_requires=[
        "numpy",  # This ensures your friends get numpy automatically
    ],
    python_requires='>=3.7',
)