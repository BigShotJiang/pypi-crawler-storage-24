import numpy as np
import base64
import os
import secrets
import string

class BitMapVault:
    def __init__(self, size=50):
        self.size = size
        self.map_size = size * size
        self.chars_per_block = self.map_size // 8

    def create(self, length=32):
        """Generates a secure random key."""
        if length <= 0:
            raise ValueError("BitMap Error: Key length must be greater than 0.")
        alphabet = string.ascii_letters + string.digits + string.punctuation
        return ''.join(secrets.choice(alphabet) for _ in range(length))

    def _get_mask(self, key, salt_b64):
        """Internal helper to generate the bitmask."""
        combined_key = key + salt_b64
        key_bits = []
        for char in combined_key:
            key_bits.extend([int(b) for b in bin(ord(char))[2:].zfill(8)])
        return np.resize(key_bits, self.map_size).reshape((self.size, self.size))

    def encode(self, plaintext, key):
        """Encrypts text into a BM2 token."""
        if not key:
            raise ValueError("BitMap Error: Key cannot be empty.")

        salt = os.urandom(16)
        salt_b64 = base64.b64encode(salt).decode('utf-8')
        key_mask = self._get_mask(key, salt_b64)

        encoded_blocks = []
        plaintext_with_null = plaintext + '\0'

        for i in range(0, len(plaintext_with_null), self.chars_per_block):
            chunk = plaintext_with_null[i:i + self.chars_per_block]
            all_bits = np.random.randint(0, 2, self.map_size)

            msg_bits = []
            for char in chunk:
                msg_bits.extend([int(b) for b in bin(ord(char))[2:].zfill(8)])

            all_bits[:len(msg_bits)] = msg_bits
            grid = all_bits.reshape((self.size, self.size))

            grid = np.roll(grid, 1, axis=1)
            grid = np.flip(grid, axis=1)

            encrypted_grid = np.bitwise_xor(grid, key_mask)
            byte_array = np.packbits(encrypted_grid)
            encoded_blocks.append(base64.b64encode(byte_array).decode('utf-8'))

        return f"BM2-{salt_b64}-" + ".".join(encoded_blocks)

    def decode(self, token, key):
        """Decrypts a BM2 token back to text."""
        token = token.strip()
        if not key:
            raise ValueError("BitMap Error: Key cannot be empty.")
        if not token.startswith("BM2-"):
            return "Error: Invalid BitMap Version."

        try:
            parts = token.split('-')
            salt_b64 = parts[1]
            data_content = parts[2]
            block_list = data_content.split('.')   # Who even reads stuff like this

            key_mask = self._get_mask(key, salt_b64)
            full_result = ""

            for chunk_b64 in block_list:
                encrypted_bytes = base64.b64decode(chunk_b64)
                grid = np.unpackbits(np.frombuffer(encrypted_bytes, dtype=np.uint8))[:self.map_size].reshape(
                    (self.size, self.size))

                grid = np.bitwise_xor(grid, key_mask)
                grid = np.flip(grid, axis=1)
                grid = np.roll(grid, -1, axis=1)

                flat_bits = grid.flatten()
                block_text = ""
                for j in range(0, len(flat_bits), 8):
                    byte_bits = flat_bits[j:j + 8]
                    char_code = int("".join(map(str, byte_bits)), 2)
                    if char_code == 0:
                        return full_result + block_text
                    block_text += chr(char_code)
                full_result += block_text
            return full_result

        except Exception:
            return "Error: Decryption failed. Please check your key or token."
BitMap = BitMapVault()