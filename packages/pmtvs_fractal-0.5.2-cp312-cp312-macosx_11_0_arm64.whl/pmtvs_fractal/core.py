"""
Fractal Primitives

Hurst exponent and Detrended Fluctuation Analysis.
These measure long-range dependence in time series.
"""

import numpy as np
from typing import Optional, Tuple

import pmtvs_fractal._rust as _rust


# Default configuration constants
DEFAULT_RS_MIN_K = 10
DEFAULT_RS_MAX_K_RATIO = 0.25
DEFAULT_RS_MAX_K_CAP = 500
DEFAULT_DFA_MIN_SCALE = 4
DEFAULT_DFA_MAX_SCALE_RATIO = 0.25
DEFAULT_DFA_MAX_SCALE_CAP = 256
DEFAULT_DFA_N_SCALES = 20
DEFAULT_MIN_SAMPLES_DFA = 64


def hurst_exponent(
    signal: np.ndarray,
    method: str = 'rs'
) -> float:
    """
    Compute Hurst exponent.

    Parameters
    ----------
    signal : np.ndarray
        Input signal
    method : str
        'rs' (rescaled range) or 'dfa' (detrended fluctuation)

    Returns
    -------
    float
        Hurst exponent H (0.5 = random walk, >0.5 = persistent, <0.5 = anti-persistent)
    """
    signal = np.ascontiguousarray(np.asarray(signal, dtype=np.float64).flatten())
    return _rust.hurst_exponent(signal, method)


def dfa(
    signal: np.ndarray,
    scale_range: Optional[Tuple[int, int]] = None,
    order: int = 1
) -> float:
    """
    Compute Detrended Fluctuation Analysis.

    Parameters
    ----------
    signal : np.ndarray
        Input signal
    scale_range : tuple, optional
        (min_scale, max_scale)
    order : int
        Polynomial order for detrending

    Returns
    -------
    float
        DFA exponent (similar interpretation to Hurst)
    """
    signal = np.ascontiguousarray(np.asarray(signal, dtype=np.float64).flatten())
    min_s = scale_range[0] if scale_range else DEFAULT_DFA_MIN_SCALE
    max_s = scale_range[1] if scale_range else -1  # -1 means auto
    return _rust.dfa(signal, min_s, max_s, order)


def hurst_r2(signal: np.ndarray) -> float:
    """
    Compute R-squared of Hurst exponent fit.

    Parameters
    ----------
    signal : np.ndarray
        Input signal

    Returns
    -------
    float
        R-squared value (goodness of fit)
    """
    signal = np.ascontiguousarray(np.asarray(signal, dtype=np.float64).flatten())
    return _rust.hurst_r2(signal)


# ---------------------------------------------------------------------------
# Memory analysis functions
# ---------------------------------------------------------------------------

# Default configuration constants for memory analysis
DEFAULT_MEMORY_MIN_SAMPLES = 20
DEFAULT_MAX_LAG_RATIO = 0.25


def detrended_fluctuation_analysis(
    values: np.ndarray,
    min_scale: int = 4,
    max_scale: Optional[int] = None,
    n_scales: int = 10,
) -> Tuple[np.ndarray, np.ndarray, float]:
    """
    Perform detrended fluctuation analysis (full output version).

    Unlike :func:`dfa` which returns only the scaling exponent, this function
    returns the intermediate scales and fluctuation values as well.

    Parameters
    ----------
    values : np.ndarray
        Input time series.
    min_scale : int
        Minimum window scale (default 4).
    max_scale : int, optional
        Maximum window scale (default ``len(values) // 4``).
    n_scales : int
        Number of logarithmically-spaced scale points (default 10).

    Returns
    -------
    tuple of (scales, fluctuations, alpha)
        * **scales** — array of window sizes used.
        * **fluctuations** — RMS fluctuation at each scale.
        * **alpha** — DFA scaling exponent (related to Hurst: H ≈ alpha).
          Returns 0.5 when the fit cannot be computed.
    """
    values = np.ascontiguousarray(np.asarray(values, dtype=np.float64).flatten())
    values = values[~np.isnan(values)]

    max_s = max_scale if max_scale is not None else -1

    scales, flucts, alpha = _rust.detrended_fluctuation_analysis(
        values, min_scale, max_s, n_scales
    )
    return np.asarray(scales), np.asarray(flucts), float(alpha)


def rescaled_range(
    values: np.ndarray,
    segment_size: Optional[int] = None,
) -> float:
    """
    Compute the rescaled range (R/S) statistic — Hurst exponent via R/S.

    Parameters
    ----------
    values : np.ndarray
        Input time series.
    segment_size : int, optional
        Number of samples to use (default: full length).

    Returns
    -------
    float
        R/S statistic.  Returns ``nan`` for degenerate inputs.
    """
    values = np.ascontiguousarray(np.asarray(values, dtype=np.float64).flatten())
    values = values[~np.isnan(values)]

    seg = segment_size if segment_size is not None else -1

    return float(_rust.rescaled_range(values, seg))


def long_range_correlation(
    values: np.ndarray,
    max_lag: Optional[int] = None,
) -> Tuple[np.ndarray, float]:
    """
    Analyse long-range correlation via autocorrelation power-law decay.

    Parameters
    ----------
    values : np.ndarray
        Input time series.
    max_lag : int, optional
        Maximum lag to analyse (default: ``int(len(values) * 0.25)``).

    Returns
    -------
    tuple of (acf, decay_exponent)
        * **acf** — normalised autocorrelation from lag 0 to *max_lag*.
        * **decay_exponent** — positive exponent ``d`` of power-law decay.
    """
    values = np.ascontiguousarray(np.asarray(values, dtype=np.float64).flatten())
    values = values[~np.isnan(values)]

    ml = max_lag if max_lag is not None else -1

    acf, decay = _rust.long_range_correlation(values, ml)
    return np.asarray(acf), float(decay)


def variance_growth(
    values: np.ndarray,
    max_lag: Optional[int] = None,
) -> Tuple[np.ndarray, float]:
    """
    Analyse variance growth with aggregation scale.

    Parameters
    ----------
    values : np.ndarray
        Input time series.
    max_lag : int, optional
        Maximum aggregation scale (default: ``int(len(values) * 0.25)``).

    Returns
    -------
    tuple of (scales, scaling_exponent)
        * **scales** — aggregation scales from 1 to *max_lag*.
        * **scaling_exponent** — power-law exponent of variance vs. scale.
    """
    values = np.ascontiguousarray(np.asarray(values, dtype=np.float64).flatten())
    values = values[~np.isnan(values)]

    ml = max_lag if max_lag is not None else -1

    scales, exp = _rust.variance_growth(values, ml)
    return np.asarray(scales), float(exp)
