"""
pmtvs-fractal — Fractal primitives for signal analysis.

numpy in, number out.
"""

__version__ = "0.5.1"
BACKEND = "rust"

try:
    import pmtvs_fractal._rust  # noqa: F401 — validates Rust extension is loadable
except ImportError as e:
    raise ImportError(
        f"\n\nRust extension not found: {e}\n"
        f"The pmtvs framework requires compiled Rust extensions.\n"
        f"Install with: cd packages/pmtvs-fractal && maturin develop --release\n"
        f"Or rebuild the Docker image.\n"
    ) from e

# --- Public API ---
from pmtvs_fractal.core import (
    hurst_exponent,
    dfa,
    hurst_r2,
    detrended_fluctuation_analysis,
    rescaled_range,
    long_range_correlation,
    variance_growth,
)

__all__ = [
    "__version__",
    "BACKEND",
    "hurst_exponent",
    "dfa",
    "hurst_r2",
    "detrended_fluctuation_analysis",
    "rescaled_range",
    "long_range_correlation",
    "variance_growth",
]
