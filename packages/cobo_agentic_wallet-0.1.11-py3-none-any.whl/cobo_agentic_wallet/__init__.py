"""Cobo Agent Wallet SDK — async Python client for the Agent Wallet REST API."""

from cobo_agentic_wallet.client import WalletAPIClient
from cobo_agentic_wallet_api.models.delegation_permission import DelegationPermission
from cobo_agentic_wallet_api.models.freeze_scope import FreezeScope
from cobo_agentic_wallet_api.models.policy_scope import PolicyScope
from cobo_agentic_wallet_api.models.policy_type import PolicyType
from cobo_agentic_wallet_api.models.principal_type import PrincipalType
from cobo_agentic_wallet_api.models.vault_group_type import VaultGroupType
from cobo_agentic_wallet_api.models.wallet_type import WalletType
from cobo_agentic_wallet.errors import (
    APIError,
    AuthenticationError,
    NotFoundError,
    PolicyDenial,
    PolicyDeniedError,
    ServerError,
)
from cobo_agentic_wallet.toolkit import AgentWalletToolkit, ToolDefinition

__version__ = "0.1.0"

__all__ = [
    "APIError",
    "AgentWalletToolkit",
    "AuthenticationError",
    "DelegationPermission",
    "FreezeScope",
    "NotFoundError",
    "PolicyDenial",
    "PolicyDeniedError",
    "PolicyScope",
    "PolicyType",
    "PrincipalType",
    "WalletAPIClient",
    "ServerError",
    "ToolDefinition",
    "VaultGroupType",
    "WalletType",
    "__version__",
]
