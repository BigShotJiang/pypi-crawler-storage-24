"""Metadata commands (chains, tokens, prices)."""

from __future__ import annotations

from typing import Any

import typer

from cobo_agentic_wallet.cli._common import run_command
from cobo_agentic_wallet.client import WalletAPIClient

app = typer.Typer(no_args_is_help=True)


@app.command("chains")
def list_chains(
    ctx: typer.Context,
    wallet_type: str = typer.Option(
        "MPC-UCW", "--wallet-type", help="Wallet type (MPC-UCW or Custodial-Web3)."
    ),
    chain_ids: str | None = typer.Option(
        None, "--chain-ids", help="Comma-separated chain IDs to filter."
    ),
    limit: int = typer.Option(50, min=1, max=200),
) -> None:
    """List supported chains."""

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.list_chains(wallet_type=wallet_type, chain_ids=chain_ids, limit=limit)

    run_command(ctx, _operation)


@app.command("tokens")
def list_tokens(
    ctx: typer.Context,
    wallet_type: str = typer.Option(
        "MPC-UCW", "--wallet-type", help="Wallet type (MPC-UCW or Custodial-Web3)."
    ),
    chain_ids: str | None = typer.Option(
        None, "--chain-ids", help="Comma-separated chain IDs to filter."
    ),
    token_ids: str | None = typer.Option(
        None, "--token-ids", help="Comma-separated token IDs to filter."
    ),
    limit: int = typer.Option(50, min=1, max=200),
) -> None:
    """List supported tokens/assets."""

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.list_assets(
            wallet_type=wallet_type,
            chain_ids=chain_ids,
            token_ids=token_ids,
            limit=limit,
        )

    run_command(ctx, _operation)


@app.command("prices")
def get_prices(
    ctx: typer.Context,
    asset_coins: str = typer.Argument(..., help="Comma-separated asset coin IDs (e.g. 'ETH,BTC')."),
    currency: str = typer.Option("USD", "--currency", help="Currency for prices."),
) -> None:
    """Get asset coin prices."""

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.get_asset_coin_prices(asset_coins, currency=currency)

    run_command(ctx, _operation)
