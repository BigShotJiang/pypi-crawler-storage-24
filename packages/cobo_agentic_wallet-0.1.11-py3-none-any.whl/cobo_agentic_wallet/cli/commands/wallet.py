"""Wallet management commands."""

from __future__ import annotations

from typing import Any

import typer

from cobo_agentic_wallet.cli._common import (
    get_context,
    run_with_client,
    OutputFormat,
    run_command,
    resolve_wallet_uuid,
)
from cobo_agentic_wallet.cli._output import emit, render_wallet_status_table
from cobo_agentic_wallet.client import WalletAPIClient

app = typer.Typer(no_args_is_help=True)


@app.command("list")
def list_wallets(
    ctx: typer.Context,
    limit: int = typer.Option(50, min=1, max=200),
    offset: int = typer.Option(0, min=0),
    include_archived: bool = typer.Option(False, "--include-archived"),
) -> None:
    """List wallets accessible to the caller."""

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.list_wallets(
            limit=limit, offset=offset, include_archived=include_archived
        )

    run_command(ctx, _operation)


@app.command("create")
def create_wallet(
    ctx: typer.Context,
    name: str = typer.Option(..., "--name", "-n", help="Wallet name."),
    main_node_id: str = typer.Option(..., "--main-node-id", help="Main TSS node ID."),
    group_type: str = typer.Option(
        "agent", "--group-type", help="MPC group type (agent or owner)."
    ),
    backup_node_id: str | None = typer.Option(None, "--backup-node-id", help="Backup TSS node ID."),
    for_owner: bool = typer.Option(False, "--for-owner", help="Create wallet for owner."),
) -> None:
    """Create a new MPC wallet."""

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.create_wallet(
            name=name,
            wallet_type="MPC-UCW",
            main_node_id=main_node_id,
            group_type=group_type,
            backup_node_id=backup_node_id,
            for_owner=for_owner,
        )

    run_command(ctx, _operation)


@app.command("get")
def get_wallet(
    ctx: typer.Context,
    wallet_uuid: str | None = typer.Argument(None, help="Wallet UUID. Falls back to config file."),
    include_spend_summary: bool = typer.Option(False, "--include-spend-summary"),
) -> None:
    """Get wallet details by UUID."""
    wallet_uuid = resolve_wallet_uuid(wallet_uuid)

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.get_wallet(wallet_uuid, include_spend_summary=include_spend_summary)

    run_command(ctx, _operation)


@app.command("balance")
def balance(
    ctx: typer.Context,
    wallet_uuid: str | None = typer.Argument(None, help="Wallet UUID. Falls back to config file."),
    address: str | None = typer.Option(None, "--address", help="Filter by wallet address."),
    token_ids: str | None = typer.Option(
        None, "--token-ids", help="Filter by token IDs (comma-separated)."
    ),
) -> None:
    """Show wallet token balances."""
    wallet_uuid = resolve_wallet_uuid(wallet_uuid)

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.list_wallet_balances(wallet_uuid, address=address, token_ids=token_ids)

    run_command(ctx, _operation)


@app.command("status")
def status(
    ctx: typer.Context,
    wallet_uuid: str | None = typer.Argument(None, help="Wallet UUID. Falls back to config file."),
) -> None:
    """Show wallet status with spend summary and frozen delegation state."""
    wallet_uuid = resolve_wallet_uuid(wallet_uuid)
    context = get_context(ctx)

    async def _operation(client: WalletAPIClient) -> Any:
        wallet = await client.get_wallet(wallet_uuid, include_spend_summary=True)
        if isinstance(wallet, dict):
            return {"wallet": wallet, "spend_summary": wallet.get("spend_summary", [])}
        return wallet

    result = run_with_client(context, _operation)
    if context.output_format == OutputFormat.TABLE and isinstance(result, dict):
        typer.echo(render_wallet_status_table(result))
        return
    emit(result, context.output_format)


@app.command("update")
def update_wallet(
    ctx: typer.Context,
    wallet_uuid: str | None = typer.Argument(None, help="Wallet UUID. Falls back to config file."),
    name: str | None = typer.Option(None, "--name", "-n", help="New wallet name."),
) -> None:
    """Update wallet properties."""
    wallet_uuid = resolve_wallet_uuid(wallet_uuid)

    async def _operation(client: WalletAPIClient) -> Any:
        from cobo_agentic_wallet_api.models.wallet_update import WalletUpdate

        return await client.update_wallet(wallet_uuid, WalletUpdate(name=name))

    run_command(ctx, _operation)


@app.command("archive")
def archive_wallet(
    ctx: typer.Context,
    wallet_uuid: str | None = typer.Argument(None, help="Wallet UUID. Falls back to config file."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt."),
) -> None:
    """Archive a wallet."""
    wallet_uuid = resolve_wallet_uuid(wallet_uuid)
    if not yes:
        context = get_context(ctx)
        confirmed = typer.confirm(f"Archive wallet {wallet_uuid}?", default=False)
        if not confirmed:
            emit({"cancelled": True, "wallet_uuid": wallet_uuid}, context.output_format)
            return

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.archive_wallet(wallet_uuid)

    run_command(ctx, _operation)


@app.command("node-status")
def node_status(
    ctx: typer.Context,
    wallet_uuid: str | None = typer.Argument(None, help="Wallet UUID. Falls back to config file."),
) -> None:
    """Get TSS node status for a wallet."""
    wallet_uuid = resolve_wallet_uuid(wallet_uuid)

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.get_wallet_node_status(wallet_uuid)

    run_command(ctx, _operation)
