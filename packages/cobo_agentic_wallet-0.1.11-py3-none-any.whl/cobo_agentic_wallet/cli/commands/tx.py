"""Transaction and contract call commands."""

from __future__ import annotations

from typing import Any

import typer

from cobo_agentic_wallet.cli._common import run_command, resolve_wallet_uuid
from cobo_agentic_wallet.client import WalletAPIClient

app = typer.Typer(no_args_is_help=True)


@app.command("transfer")
def transfer(
    ctx: typer.Context,
    wallet_uuid: str | None = typer.Argument(None, help="Wallet UUID. Falls back to config file."),
    to: str = typer.Option(..., "--to", help="Destination address."),
    token: str = typer.Option(..., "--token", help="Token ID."),
    amount: str = typer.Option(..., "--amount", help="Transfer amount."),
    chain: str = typer.Option("ETH", "--chain", help="Chain ID."),
    src_addr: str | None = typer.Option(None, "--src-addr", help="Source address."),
    request_id: str | None = typer.Option(None, "--request-id", help="Optional idempotency key."),
    sponsor: bool = typer.Option(
        True,
        "--sponsor/--no-sponsor",
        help="Use fee station to pay fee (default). Use --no-sponsor to pay fee from sender.",
    ),
) -> None:
    """Transfer tokens with policy enforcement."""
    wallet_uuid = resolve_wallet_uuid(wallet_uuid)

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.transfer_tokens(
            wallet_uuid,
            chain_id=chain,
            dst_addr=to,
            token_id=token,
            amount=amount,
            src_addr=src_addr,
            request_id=request_id,
            sponsor=sponsor,
        )

    run_command(ctx, _operation)


@app.command("list")
def list_transactions(
    ctx: typer.Context,
    wallet_uuid: str | None = typer.Argument(None, help="Wallet UUID. Falls back to config file."),
    limit: int = typer.Option(50, min=1, max=200),
    offset: int = typer.Option(0, min=0),
    status: str | None = typer.Option(None, "--status", help="Optional status filter."),
) -> None:
    """List wallet transactions with optional status filter."""
    wallet_uuid = resolve_wallet_uuid(wallet_uuid)

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.list_transactions(
            wallet_uuid, limit=limit, offset=offset, status=status
        )

    run_command(ctx, _operation)


@app.command("get")
def get_transaction(
    ctx: typer.Context,
    wallet_uuid: str | None = typer.Argument(None, help="Wallet UUID. Falls back to config file."),
    tx_id: str = typer.Argument(..., help="Transaction UUID."),
) -> None:
    """Get transaction details by ID."""
    wallet_uuid = resolve_wallet_uuid(wallet_uuid)

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.get_transaction(wallet_uuid, tx_id)

    run_command(ctx, _operation)


@app.command("call")
def contract_call(
    ctx: typer.Context,
    wallet_uuid: str | None = typer.Argument(None, help="Wallet UUID. Falls back to config file."),
    contract: str = typer.Option(..., "--contract", help="Contract address."),
    calldata: str = typer.Option(..., "--calldata", help="Hex-encoded calldata."),
    chain: str = typer.Option("ETH", "--chain", help="Chain ID."),
    value: str | None = typer.Option(None, "--value", help="Native token value to send."),
    src_addr: str | None = typer.Option(None, "--src-addr", help="Source address."),
    request_id: str | None = typer.Option(None, "--request-id", help="Optional idempotency key."),
    sponsor: bool = typer.Option(
        True,
        "--sponsor/--no-sponsor",
        help="Use fee station to pay fee (default). Use --no-sponsor to pay fee from sender.",
    ),
) -> None:
    """Execute a contract call with policy enforcement."""
    wallet_uuid = resolve_wallet_uuid(wallet_uuid)

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.contract_call(
            wallet_uuid,
            chain_id=chain,
            contract_addr=contract,
            calldata=calldata,
            value=value,
            src_addr=src_addr,
            request_id=request_id,
            sponsor=sponsor,
        )

    run_command(ctx, _operation)


@app.command("estimate-transfer-fee")
def estimate_transfer_fee(
    ctx: typer.Context,
    wallet_uuid: str | None = typer.Argument(None, help="Wallet UUID. Falls back to config file."),
    to: str = typer.Option(..., "--to", help="Destination address."),
    token: str = typer.Option(..., "--token", help="Token ID."),
    amount: str = typer.Option(..., "--amount", help="Transfer amount."),
    chain: str = typer.Option("ETH", "--chain", help="Chain ID."),
    src_addr: str | None = typer.Option(None, "--src-addr", help="Source address."),
) -> None:
    """Estimate transfer fee for a transaction."""
    wallet_uuid = resolve_wallet_uuid(wallet_uuid)

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.estimate_transfer_fee(
            wallet_uuid,
            chain_id=chain,
            dst_addr=to,
            token_id=token,
            amount=amount,
            src_addr=src_addr,
        )

    run_command(ctx, _operation)


@app.command("estimate-call-fee")
def estimate_contract_call_fee(
    ctx: typer.Context,
    wallet_uuid: str | None = typer.Argument(None, help="Wallet UUID. Falls back to config file."),
    contract: str = typer.Option(..., "--contract", help="Contract address."),
    calldata: str = typer.Option(..., "--calldata", help="Hex-encoded calldata."),
    chain: str = typer.Option("ETH", "--chain", help="Chain ID."),
    value: str | None = typer.Option(None, "--value", help="Native token value to send."),
    src_addr: str | None = typer.Option(None, "--src-addr", help="Source address."),
) -> None:
    """Estimate contract call fee."""
    wallet_uuid = resolve_wallet_uuid(wallet_uuid)

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.estimate_contract_call_fee(
            wallet_uuid,
            chain_id=chain,
            contract_addr=contract,
            calldata=calldata,
            value=value,
            src_addr=src_addr,
        )

    run_command(ctx, _operation)


@app.command("drop")
def drop_transaction(
    ctx: typer.Context,
    wallet_uuid: str | None = typer.Argument(None, help="Wallet UUID. Falls back to config file."),
    transaction_uuid: str = typer.Argument(..., help="Transaction UUID to drop."),
    request_id: str | None = typer.Option(None, "--request-id", help="Optional idempotency key."),
) -> None:
    """Drop/cancel a pending transaction."""
    wallet_uuid = resolve_wallet_uuid(wallet_uuid)

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.drop_transaction(wallet_uuid, transaction_uuid, request_id=request_id)

    run_command(ctx, _operation)


@app.command("records")
def list_transaction_records(
    ctx: typer.Context,
    wallet_uuid: str | None = typer.Argument(None, help="Wallet UUID. Falls back to config file."),
    limit: int = typer.Option(50, min=1, max=200),
    offset: int = typer.Option(0, min=0),
    status: str | None = typer.Option(None, "--status", help="Optional status filter."),
    record_type: str | None = typer.Option(None, "--type", help="Optional type filter."),
    token_id: str | None = typer.Option(None, "--token", help="Optional token ID filter."),
    chain_id: str | None = typer.Option(None, "--chain", help="Optional chain ID filter."),
) -> None:
    """List transaction records for a wallet."""
    wallet_uuid = resolve_wallet_uuid(wallet_uuid)

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.list_transaction_records(
            wallet_uuid,
            limit=limit,
            offset=offset,
            status=status,
            wallet_type=record_type,
            token_id=token_id,
            chain_id=chain_id,
        )

    run_command(ctx, _operation)


@app.command("record")
def get_transaction_record(
    ctx: typer.Context,
    wallet_uuid: str | None = typer.Argument(None, help="Wallet UUID. Falls back to config file."),
    record_uuid: str = typer.Argument(..., help="Transaction record UUID."),
) -> None:
    """Get transaction record details."""
    wallet_uuid = resolve_wallet_uuid(wallet_uuid)

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.get_transaction_record(wallet_uuid, record_uuid)

    run_command(ctx, _operation)
