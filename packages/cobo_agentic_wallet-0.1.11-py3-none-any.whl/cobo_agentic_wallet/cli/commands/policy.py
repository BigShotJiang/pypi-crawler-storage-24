"""Policy management commands."""

from __future__ import annotations

import json
from typing import Any

import typer

from cobo_agentic_wallet.cli._common import get_context
from cobo_agentic_wallet.cli._common import run_command
from cobo_agentic_wallet.cli._output import emit
from cobo_agentic_wallet.client import WalletAPIClient
from cobo_agentic_wallet_api.models.pending_operation_type import PendingOperationType
from cobo_agentic_wallet_api.models.policy_update import PolicyUpdate
from cobo_agentic_wallet_api.models.policy_scope import PolicyScope
from cobo_agentic_wallet_api.models.policy_type import PolicyType

app = typer.Typer(no_args_is_help=True)


@app.command("list")
def list_policies(
    ctx: typer.Context,
    scope: str = typer.Option(
        "delegation", "--scope", "-s", help="Policy scope: global, wallet, or delegation."
    ),
    wallet_id: str | None = typer.Option(None, "--wallet-id", help="Filter by wallet UUID."),
    delegation_id: str | None = typer.Option(
        None, "--delegation-id", help="Filter by delegation UUID."
    ),
    limit: int = typer.Option(50, min=1, max=200),
    offset: int = typer.Option(0, min=0),
) -> None:
    """List policies."""

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.list_policies(
            scope=PolicyScope(scope),
            wallet_id=wallet_id,
            delegation_id=delegation_id,
            limit=limit,
            offset=offset,
        )

    run_command(ctx, _operation)


@app.command("get")
def get_policy(
    ctx: typer.Context,
    policy_id: str = typer.Argument(..., help="Policy UUID."),
) -> None:
    """Get policy details by ID."""

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.get_policy(policy_id)

    run_command(ctx, _operation)


@app.command("create")
def create_policy(
    ctx: typer.Context,
    scope: str = typer.Option(
        "delegation", "--scope", help="Policy scope: global, wallet, or delegation."
    ),
    wallet_id: str | None = typer.Option(None, "--wallet-id", help="Wallet UUID."),
    delegation_id: str | None = typer.Option(None, "--delegation-id", help="Delegation UUID."),
    name: str = typer.Option(..., "--name", help="Policy name."),
    policy_type: str = typer.Option(..., "--type", help="Policy type (transfer, contract_call)."),
    rules: str = typer.Option(..., "--rules", help="Policy rules as JSON string."),
    priority: int = typer.Option(0, "--priority", help="Policy priority."),
    is_active: bool = typer.Option(
        True, "--active/--inactive", help="Set initial policy activation status."
    ),
) -> None:
    """Create a new policy."""

    async def _operation(client: WalletAPIClient) -> Any:
        parsed_rules = json.loads(rules)
        if not isinstance(parsed_rules, dict):
            raise ValueError("--rules must be a JSON object")

        scope_enum = PolicyScope(scope)
        type_enum = PolicyType(policy_type)
        if scope_enum == PolicyScope.GLOBAL and (wallet_id or delegation_id):
            raise ValueError("global scope does not accept --wallet-id or --delegation-id")
        if scope_enum == PolicyScope.WALLET:
            if not wallet_id:
                raise ValueError("wallet scope requires --wallet-id")
            if delegation_id:
                raise ValueError("wallet scope does not accept --delegation-id")
        if scope_enum == PolicyScope.DELEGATION:
            if not delegation_id:
                raise ValueError("delegation scope requires --delegation-id")
            if wallet_id:
                raise ValueError("delegation scope does not accept --wallet-id")

        return await client.create_policy(
            scope=scope_enum,
            delegation_id=delegation_id,
            wallet_id=wallet_id,
            name=name,
            wallet_type=type_enum,
            rules=parsed_rules,
            priority=priority,
            is_active=is_active,
        )

    run_command(ctx, _operation)


@app.command("update")
def update_policy(
    ctx: typer.Context,
    policy_id: str = typer.Argument(..., help="Policy UUID."),
    name: str | None = typer.Option(None, "--name", help="New policy name."),
    rules: str | None = typer.Option(None, "--rules", help="New policy rules as JSON string."),
) -> None:
    """Update policy properties."""

    async def _operation(client: WalletAPIClient) -> Any:
        parsed_rules = json.loads(rules) if rules else None
        update = PolicyUpdate(name=name, rules=parsed_rules)
        return await client.update_policy(policy_id, update)

    run_command(ctx, _operation)


@app.command("deactivate")
def deactivate_policy(
    ctx: typer.Context,
    policy_id: str = typer.Argument(..., help="Policy UUID."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt."),
) -> None:
    """Deactivate a policy."""
    context = get_context(ctx)

    if not yes:
        confirmed = typer.confirm(f"Deactivate policy {policy_id}?", default=False)
        if not confirmed:
            emit({"cancelled": True, "policy_id": policy_id}, context.output_format)
            return

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.deactivate_policy(policy_id)

    run_command(ctx, _operation)


@app.command("dry-run")
def dry_run_policy(
    ctx: typer.Context,
    wallet_id: str = typer.Argument(..., help="Wallet UUID."),
    operation_type: str = typer.Option(
        ...,
        "--operation-type",
        "--action",
        help="Operation type to test (transfer, contract_call).",
    ),
    amount: str = typer.Option(..., "--amount", help="Amount to evaluate."),
    chain_id: str = typer.Option(..., "--chain-id", help="Chain ID."),
    token_id: str | None = typer.Option(None, "--token-id", help="Token ID."),
    delegation_id: str | None = typer.Option(None, "--delegation-id", help="Delegation UUID."),
    dst_addr: str | None = typer.Option(
        None, "--dst-addr", help="Destination address for transfer."
    ),
    contract_addr: str | None = typer.Option(
        None, "--contract-addr", help="Contract address for contract_call."
    ),
    calldata: str | None = typer.Option(None, "--calldata", help="Hex-encoded calldata."),
    principal_id: str | None = typer.Option(None, "--principal-id", help="Principal UUID."),
) -> None:
    """Dry-run a policy evaluation."""

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.dry_run_policy(
            wallet_id=wallet_id,
            operation_type=PendingOperationType(operation_type),
            amount=amount,
            chain_id=chain_id,
            delegation_id=delegation_id,
            token_id=token_id,
            dst_addr=dst_addr,
            contract_addr=contract_addr,
            calldata=calldata,
            principal_id=principal_id,
        )

    run_command(ctx, _operation)
