"""Faucet commands – request test tokens."""

from __future__ import annotations

from typing import Any

import typer

from cobo_agentic_wallet.cli._common import run_command
from cobo_agentic_wallet.client import WalletAPIClient

app = typer.Typer(no_args_is_help=True)


@app.command("tokens")
def list_tokens(ctx: typer.Context) -> None:
    """List available faucet tokens grouped by chain."""

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.list_faucet_tokens()

    run_command(ctx, _operation)


@app.command("deposit")
def deposit(
    ctx: typer.Context,
    address: str = typer.Option(
        ..., "--address", "-a", help="Destination address to receive test tokens."
    ),
    token: str = typer.Option(
        ..., "--token", "-t", help="Token ID, e.g. SETH_USDC or SOLDEV_SOL_USDC."
    ),
) -> None:
    """Request test tokens for a given address."""

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.faucet_deposit(address=address, token_id=token)

    run_command(ctx, _operation)
