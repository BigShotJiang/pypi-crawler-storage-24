"""Shared CLI utilities: context, client creation, and async execution."""

from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass
from enum import Enum
from typing import Any, Awaitable, Callable, NoReturn

import typer

from cobo_agentic_wallet.client import WalletAPIClient
from cobo_agentic_wallet.errors import APIError, AuthenticationError, PolicyDeniedError
from cobo_agentic_wallet.toolkit import AgentWalletToolkit
from cobo_agentic_wallet_api.exceptions import ApiException

AGENT_WALLET_API_KEY = "AGENT_WALLET_API_KEY"
AGENT_WALLET_API_URL = "AGENT_WALLET_API_URL"
AGENT_WALLET_TIMEOUT = "AGENT_WALLET_TIMEOUT"
CAW_CONFIG_PATH = "CAW_CONFIG_PATH"


class OutputFormat(str, Enum):
    JSON = "json"
    TABLE = "table"


@dataclass(frozen=True)
class CLIContext:
    api_key: str
    api_url: str
    timeout: float
    output_format: OutputFormat


ClientOperation = Callable[[WalletAPIClient], Awaitable[Any]]


def get_context(ctx: typer.Context) -> CLIContext:
    """Extract CLI context from typer context."""
    context = ctx.obj
    if isinstance(context, CLIContext):
        return context
    raise RuntimeError("CLI context not initialized.")


def handle_api_error(exc: APIError, output_format: OutputFormat) -> NoReturn:
    """Handle API errors with appropriate output."""
    if isinstance(exc, PolicyDeniedError):
        denial_payload = {
            "error": "POLICY_DENIED",
            "code": exc.denial.code,
            "reason": exc.denial.reason,
            "details": exc.denial.details,
            "suggestion": exc.denial.suggestion,
        }
        if output_format == OutputFormat.JSON:
            typer.echo(
                json.dumps(denial_payload, indent=2, sort_keys=True, ensure_ascii=True), err=True
            )
        else:
            typer.echo(AgentWalletToolkit._format_denial(exc.denial), err=True)
        raise typer.Exit(code=1)

    if isinstance(exc, AuthenticationError):
        typer.echo(f"Authentication failed: {exc}", err=True)
        raise typer.Exit(code=1)

    msg = f"API error ({exc.status_code}): {exc}"
    if exc.response_body:
        msg += f"\n{json.dumps(exc.response_body, indent=2, ensure_ascii=False) if isinstance(exc.response_body, dict) else exc.response_body}"
    typer.echo(msg, err=True)
    raise typer.Exit(code=1)


def run_async_operation(context: CLIContext, operation: Callable[[], Awaitable[Any]]) -> Any:
    """Run async operation with error handling."""
    try:
        return asyncio.run(operation())
    except ApiException as exc:
        body = None
        if exc.body:
            try:
                body = json.loads(exc.body) if isinstance(exc.body, str) else exc.body
            except (json.JSONDecodeError, TypeError):
                pass

        if exc.status == 403 and body:
            from cobo_agentic_wallet.errors import PolicyDenial

            denial = PolicyDenial.try_from_response(body)
            if denial:
                policy_error = PolicyDeniedError(
                    denial.reason,
                    status_code=403,
                    response_body=body,
                    denial=denial,
                )
                handle_api_error(policy_error, context.output_format)
                return None

        api_error = APIError(
            str(exc.reason or exc), status_code=exc.status or 500, response_body=body
        )
        handle_api_error(api_error, context.output_format)
    except APIError as exc:
        handle_api_error(exc, context.output_format)
    except (RuntimeError, TimeoutError, FileNotFoundError, ValueError) as exc:
        typer.echo(f"Runtime error: {exc}", err=True)
        raise typer.Exit(code=1) from exc


def make_client(
    context: CLIContext,
    *,
    api_key: str | None = None,
    allow_unauthenticated: bool = False,
) -> WalletAPIClient:
    """Create WalletAPIClient with context settings."""
    kwargs: dict[str, Any] = {
        "base_url": context.api_url,
        "timeout": context.timeout,
    }
    if api_key:
        kwargs["api_key"] = api_key
    elif allow_unauthenticated:
        kwargs["allow_unauthenticated"] = True
    return WalletAPIClient(**kwargs)


def resolve_wallet_uuid(wallet_uuid: str | None) -> str:
    """Resolve wallet UUID from argument or config file, exit if not found."""
    from contextlib import suppress
    from cobo_agentic_wallet.cli.config import load_config

    if wallet_uuid:
        return wallet_uuid
    with suppress(FileNotFoundError, ValueError):
        resolved = str(load_config().get("wallet_uuid", "")).strip()
        if resolved:
            return resolved
    typer.echo(
        "Wallet UUID is required. Pass it as an argument or run 'caw onboard provision' first.",
        err=True,
    )
    raise typer.Exit(code=1)


def run_command(ctx: typer.Context, operation: ClientOperation) -> None:
    """Standard command execution pattern for simple commands."""
    from cobo_agentic_wallet.cli._output import emit  # lazy import to avoid circular dependency

    context = get_context(ctx)
    result = run_with_client(context, operation)
    emit(result, context.output_format)


def run_with_client(context: CLIContext, operation: ClientOperation) -> Any:
    """Run operation with authenticated client."""
    if not context.api_key:
        typer.echo(
            f"API key is required. Set --api-key or {AGENT_WALLET_API_KEY}.",
            err=True,
        )
        raise typer.Exit(code=1)

    async def _runner() -> Any:
        client = make_client(context, api_key=context.api_key)
        try:
            return await operation(client)
        finally:
            await client.close()

    return run_async_operation(context, _runner)


def progress(message: str, *, enabled: bool) -> None:
    """Print progress message if enabled."""
    if enabled:
        typer.echo(message, err=True)


def extract_text(payload: dict[str, Any], *keys: str) -> str | None:
    """Extract text from payload by trying multiple keys."""
    for key in keys:
        raw = payload.get(key)
        if raw is None:
            continue
        text = str(raw).strip()
        if text:
            return text
    return None


def require_text(payload: dict[str, Any], *keys: str) -> str:
    """Require text from payload, raise if missing."""
    value = extract_text(payload, *keys)
    if value is None:
        joined = ", ".join(keys)
        raise RuntimeError(f"Missing required response field: {joined}")
    return value
