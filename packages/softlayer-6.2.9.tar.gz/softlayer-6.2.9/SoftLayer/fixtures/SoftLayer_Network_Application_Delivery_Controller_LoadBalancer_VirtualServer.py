deleteObject = True
