kickAllConnections = True
