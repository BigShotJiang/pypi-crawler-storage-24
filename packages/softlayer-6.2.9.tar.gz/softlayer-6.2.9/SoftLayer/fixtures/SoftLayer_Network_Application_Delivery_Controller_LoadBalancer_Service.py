deleteObject = True
toggleStatus = True
