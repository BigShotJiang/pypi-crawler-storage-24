"""Block Storage Snapshot Control."""
