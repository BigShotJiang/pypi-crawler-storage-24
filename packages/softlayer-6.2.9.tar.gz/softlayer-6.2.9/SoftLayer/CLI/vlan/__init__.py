"""Network VLANs."""
