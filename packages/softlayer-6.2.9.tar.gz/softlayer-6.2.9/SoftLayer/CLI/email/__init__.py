"""Network Delivery account"""
