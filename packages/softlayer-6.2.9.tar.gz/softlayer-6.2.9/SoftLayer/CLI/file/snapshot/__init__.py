"""File Storage Snapshot Control."""
