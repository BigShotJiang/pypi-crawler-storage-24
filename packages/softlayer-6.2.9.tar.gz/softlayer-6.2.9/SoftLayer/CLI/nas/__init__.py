"""Network Attached Storage."""
