#!/usr/bin/env python3
"""
阿里云 SLS (日志服务) MCP Server - 纯 Python 实现

使用方式:
    uvx aliyun-sls-mcp-py

环境变量:
    SLS_ENDPOINT          SLS 服务端点 (如 cn-hangzhou.log.aliyuncs.com)
    SLS_ACCESS_KEY_ID     阿里云 AccessKey ID
    SLS_ACCESS_KEY_SECRET 阿里云 AccessKey Secret
    SLS_PROJECT           默认 SLS 项目名称
    SLS_LOGSTORE          默认日志库名称 (可选)

支持多环境:
    用户可以通过 project 参数动态选择不同的项目 (test/uat/prod)
"""

import os
import sys
import json
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Annotated, Optional

from pydantic import BaseModel, Field
from aliyun.log import LogClient, ListLogstoresRequest, GetLogsRequest

from mcp.server.fastmcp import FastMCP


# ============== 配置 ==============

# 预定义的项目映射 (根据实际情况修改)
PROJECT_MAP = {
    "test": "k8s-log-c7fd130d77f0f4627ac91c831bffeb751",  # TEST 环境 (TODO: 替换为实际项目名)
    "uat": "k8s-log-c7fd130d77f0f4627ac91c831bffeb751",   # UAT 环境 (TODO: 替换为实际项目名)
    "prod": "k8s-log-c7fd130d77f0f4627ac91c831bffeb751",  # PROD 环境
}

@dataclass
class SLSConfig:
    """SLS 配置"""
    endpoint: str
    access_key_id: str
    access_key_secret: str
    project: str
    logstore: Optional[str] = None

    @classmethod
    def from_env(cls) -> "SLSConfig":
        """从环境变量加载配置"""
        config = cls(
            endpoint=os.environ.get("SLS_ENDPOINT", ""),
            access_key_id=os.environ.get("SLS_ACCESS_KEY_ID", ""),
            access_key_secret=os.environ.get("SLS_ACCESS_KEY_SECRET", ""),
            project=os.environ.get("SLS_PROJECT", ""),
            logstore=os.environ.get("SLS_LOGSTORE"),
        )

        missing = []
        if not config.endpoint:
            missing.append("SLS_ENDPOINT")
        if not config.access_key_id:
            missing.append("SLS_ACCESS_KEY_ID")
        if not config.access_key_secret:
            missing.append("SLS_ACCESS_KEY_SECRET")

        if missing:
            print(f"错误: 缺少必要的环境变量: {', '.join(missing)}", file=sys.stderr)
            sys.exit(1)

        return config


# ============== 状态管理 ==============

@dataclass
class SLSState:
    """SLS 状态"""
    config: SLSConfig
    client: LogClient


@asynccontextmanager
async def lifespan(app: FastMCP) -> AsyncIterator[SLSState]:
    """服务器生命周期管理"""
    config = SLSConfig.from_env()

    state = SLSState(
        config=config,
        client=LogClient(
            config.endpoint,
            config.access_key_id,
            config.access_key_secret
        )
    )

    print(f"SLS MCP Server 已启动", file=sys.stderr)
    print(f"  默认项目: {config.project}", file=sys.stderr)
    print(f"  可用环境: test, uat, prod", file=sys.stderr)

    yield state

    print("SLS MCP Server 已关闭", file=sys.stderr)


# ============== 创建 MCP 服务器 ==============

mcp = FastMCP(
    "阿里云SLS日志服务",
    lifespan=lifespan
)


# ============== 数据模型 ==============

class LogstoreList(BaseModel):
    """日志库列表"""
    project: str = Field(description="项目名称")
    logstores: list[str] = Field(description="日志库列表")
    count: int = Field(description="日志库数量")


class TimeRange(BaseModel):
    """时间范围"""
    from_time: str = Field(description="开始时间")
    to_time: str = Field(description="结束时间")


class QueryResult(BaseModel):
    """查询结果"""
    project: str = Field(description="项目名称")
    logstore: str = Field(description="日志库名称")
    query: str = Field(description="查询语句")
    time_range: TimeRange = Field(description="时间范围")
    total: int = Field(description="总条数")
    count: int = Field(description="当前返回条数")
    has_more: bool = Field(description="是否有更多数据")
    logs: list[dict] = Field(description="日志列表")


class ErrorAnalysis(BaseModel):
    """错误分析结果"""
    project: str = Field(description="项目名称")
    logstore: str = Field(description="日志库名称")
    time_range: TimeRange = Field(description="时间范围")
    total_errors: int = Field(description="错误总数")
    top_errors: list[dict] = Field(description="高频错误列表")


# ============== 辅助函数 ==============

def get_project(project: Optional[str], default_project: str) -> str:
    """获取实际使用的项目名称

    支持三种方式:
    1. 直接传入完整项目名 (如 k8s-log-xxx)
    2. 传入环境简称 (test/uat/prod)
    3. 不传则使用默认项目
    """
    if not project:
        return default_project

    # 如果是预定义的环境简称，转换为完整项目名
    if project.lower() in PROJECT_MAP:
        return PROJECT_MAP[project.lower()]

    # 否则直接使用传入的项目名
    return project


def parse_time(time_input: str | int) -> int:
    """解析时间输入

    支持格式:
        - 整数时间戳 (秒或毫秒)
        - "now" - 当前时间
        - "-1h", "-30m", "-7d" - 相对时间
        - ISO 格式: "2024-01-01T00:00:00"
    """
    if isinstance(time_input, int):
        return time_input // 1000 if time_input > 10000000000 else time_input

    if time_input == "now":
        return int(datetime.now().timestamp())

    if time_input.startswith("-"):
        unit = time_input[-1].lower()
        value = int(time_input[1:-1])
        now = datetime.now()

        deltas = {
            "s": timedelta(seconds=value),
            "m": timedelta(minutes=value),
            "h": timedelta(hours=value),
            "d": timedelta(days=value),
            "w": timedelta(weeks=value),
        }

        if unit not in deltas:
            raise ValueError(f"不支持的时间单位: {unit}")

        return int((now - deltas[unit]).timestamp())

    # ISO 格式
    try:
        dt = datetime.fromisoformat(time_input.replace("Z", "+00:00"))
        return int(dt.timestamp())
    except ValueError:
        pass

    raise ValueError(f"无法解析时间: {time_input}")


def format_timestamp(ts: int) -> str:
    """格式化时间戳"""
    if ts > 10000000000:
        ts //= 1000
    return datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S")


def format_log(contents: dict) -> dict:
    """格式化日志，过滤内部字段"""
    return {k: v for k, v in contents.items() if not k.startswith("__tag__")}


# ============== MCP 工具 ==============

@mcp.tool()
def list_logstores(
    project: Annotated[Optional[str], Field(
        description="SLS 项目名称。支持环境简称 (test/uat/prod) 或完整项目名。不填则使用默认项目"
    )] = None,
) -> LogstoreList:
    """列出指定项目下所有的日志库(Logstore)

    Args:
        project: SLS 项目名称，支持:
            - 环境简称: "test", "uat", "prod"
            - 完整项目名: "k8s-log-xxx"
            - 不填则使用默认项目

    Returns:
        日志库列表，包含项目名称和所有日志库名称

    Examples:
        list_logstores()              # 使用默认项目
        list_logstores("test")        # TEST 环境
        list_logstores("prod")        # PROD 环境
        list_logstores("k8s-log-xxx") # 指定完整项目名
    """
    state: SLSState = mcp.get_context().request_context.lifespan_context
    actual_project = get_project(project, state.config.project)

    request = ListLogstoresRequest(actual_project)
    response = state.client.list_logstores(request)
    logstores = response.get_logstores()

    return LogstoreList(
        project=actual_project,
        logstores=logstores,
        count=len(logstores)
    )


@mcp.tool()
def query_logs(
    query: Annotated[str, Field(description="SLS 查询语句")],
    logstore: Annotated[Optional[str], Field(description="日志库名称")] = None,
    project: Annotated[Optional[str], Field(
        description="SLS 项目名称。支持环境简称 (test/uat/prod) 或完整项目名"
    )] = None,
    from_time: Annotated[str, Field(description="开始时间")] = "-1h",
    to_time: Annotated[str, Field(description="结束时间")] = "now",
    limit: Annotated[int, Field(description="每页条数", ge=1, le=500)] = 100,
    offset: Annotated[int, Field(description="偏移量", ge=0)] = 0,
) -> QueryResult:
    """查询 SLS 日志 (支持分页和多环境)

    Args:
        query: SLS 查询语句，支持全文检索、字段查询、SQL 分析等
        logstore: 日志库名称，如未设置则使用默认日志库
        project: SLS 项目名称，支持:
            - 环境简称: "test", "uat", "prod"
            - 完整项目名: "k8s-log-xxx"
            - 不填则使用默认项目
        from_time: 开始时间，支持相对时间 (-1h) 或绝对时间
        to_time: 结束时间，支持 "now" 或绝对时间
        limit: 每页返回条数，最大 500
        offset: 分页偏移量

    Returns:
        查询结果，包含日志列表和分页信息

    Examples:
        query_logs("ERROR", project="test")           # 查询 TEST 环境的错误日志
        query_logs("level: ERROR", project="prod")    # 查询 PROD 环境
        query_logs("*", logstore="app-log")           # 指定日志库
    """
    state: SLSState = mcp.get_context().request_context.lifespan_context

    actual_project = get_project(project, state.config.project)
    store = logstore or state.config.logstore

    if not store:
        raise ValueError("请指定 logstore 参数或设置 SLS_LOGSTORE 环境变量")

    from_ts = parse_time(from_time)
    to_ts = parse_time(to_time)

    # 查询总数 (非分析查询时)
    total = -1
    if "|" not in query:
        try:
            count_query = f"{query} | SELECT COUNT(*) as total"
            count_request = GetLogsRequest(
                project=actual_project,
                logstore=store,
                fromTime=from_ts,
                toTime=to_ts,
                query=count_query,
                line=1
            )
            count_response = state.client.get_logs(count_request)
            for log in count_response.get_logs():
                total = int(log.get_contents().get("total", 0))
        except Exception:
            pass

    # 查询数据
    request = GetLogsRequest(
        project=actual_project,
        logstore=store,
        fromTime=from_ts,
        toTime=to_ts,
        query=query,
        line=limit,
        offset=offset
    )

    response = state.client.get_logs(request)
    raw_logs = response.get_logs()
    logs = [format_log(log.get_contents()) for log in raw_logs]

    return QueryResult(
        project=actual_project,
        logstore=store,
        query=query,
        time_range=TimeRange(
            from_time=format_timestamp(from_ts),
            to_time=format_timestamp(to_ts)
        ),
        total=total,
        count=len(logs),
        has_more=(offset + len(logs)) < total if total >= 0 else (len(logs) >= limit),
        logs=logs
    )


@mcp.tool()
def search_keyword(
    keyword: Annotated[str, Field(description="搜索关键字")],
    logstore: Annotated[Optional[str], Field(description="日志库名称")] = None,
    project: Annotated[Optional[str], Field(
        description="SLS 项目名称。支持环境简称 (test/uat/prod) 或完整项目名"
    )] = None,
    from_time: Annotated[str, Field(description="开始时间")] = "-24h",
    to_time: Annotated[str, Field(description="结束时间")] = "now",
    limit: Annotated[int, Field(description="每页条数", ge=1, le=500)] = 20,
    offset: Annotated[int, Field(description="偏移量", ge=0)] = 0,
) -> QueryResult:
    """搜索包含关键字的日志 (支持分页和多环境)

    Args:
        keyword: 要搜索的关键字
        logstore: 日志库名称
        project: SLS 项目名称，支持环境简称 (test/uat/prod) 或完整项目名
        from_time: 开始时间
        to_time: 结束时间
        limit: 每页条数
        offset: 偏移量

    Returns:
        查询结果
    """
    return query_logs(
        query=keyword,
        logstore=logstore,
        project=project,
        from_time=from_time,
        to_time=to_time,
        limit=limit,
        offset=offset
    )


@mcp.tool()
def analyze_errors(
    logstore: Annotated[Optional[str], Field(description="日志库名称")] = None,
    project: Annotated[Optional[str], Field(
        description="SLS 项目名称。支持环境简称 (test/uat/prod) 或完整项目名"
    )] = None,
    from_time: Annotated[str, Field(description="开始时间")] = "-24h",
    to_time: Annotated[str, Field(description="结束时间")] = "now",
    top_n: Annotated[int, Field(description="返回前N个高频错误", ge=1, le=100)] = 10,
) -> ErrorAnalysis:
    """分析错误日志 (支持多环境)

    Args:
        logstore: 日志库名称
        project: SLS 项目名称，支持环境简称 (test/uat/prod) 或完整项目名
        from_time: 开始时间
        to_time: 结束时间
        top_n: 返回高频错误的数量

    Returns:
        错误分析结果，包含错误总数和 Top N 高频错误
    """
    state: SLSState = mcp.get_context().request_context.lifespan_context

    actual_project = get_project(project, state.config.project)
    store = logstore or state.config.logstore

    if not store:
        raise ValueError("请指定 logstore 参数或设置 SLS_LOGSTORE 环境变量")

    from_ts = parse_time(from_time)
    to_ts = parse_time(to_time)

    # 错误级别过滤
    error_filter = "level: ERROR OR level: ERR OR level: FATAL OR level: SEVERE OR level: CRITICAL"

    # 查询高频错误
    error_query = f"""
    {error_filter}
    | SELECT
        message as error_message,
        COUNT(*) as count
    GROUP BY error_message
    ORDER BY count DESC
    LIMIT {top_n}
    """

    request = GetLogsRequest(
        project=actual_project,
        logstore=store,
        fromTime=from_ts,
        toTime=to_ts,
        query=error_query,
        line=top_n
    )

    response = state.client.get_logs(request)
    raw_logs = response.get_logs()

    top_errors = [
        {
            "error": log.get_contents().get("error_message", "Unknown"),
            "count": int(log.get_contents().get("count", 0))
        }
        for log in raw_logs
    ]

    # 查询错误总数
    total_query = f"{error_filter} | SELECT COUNT(*) as total"
    total_request = GetLogsRequest(
        project=actual_project,
        logstore=store,
        fromTime=from_ts,
        toTime=to_ts,
        query=total_query,
        line=1
    )

    total = 0
    try:
        total_response = state.client.get_logs(total_request)
        for log in total_response.get_logs():
            total = int(log.get_contents().get("total", 0))
    except Exception:
        pass

    return ErrorAnalysis(
        project=actual_project,
        logstore=store,
        time_range=TimeRange(
            from_time=format_timestamp(from_ts),
            to_time=format_timestamp(to_ts)
        ),
        total_errors=total,
        top_errors=top_errors
    )


# ============== MCP 资源 ==============

@mcp.resource("sls://config")
def get_config_resource() -> str:
    """获取当前 SLS 配置信息"""
    state: SLSState = mcp.get_context().request_context.lifespan_context
    return f"""# SLS 配置信息

## 连接配置
- 端点: {state.config.endpoint}
- 默认项目: {state.config.project}
- 默认日志库: {state.config.logstore or '未设置'}

## 支持的环境简称
| 简称 | 项目名称 |
|------|----------|
| test | {PROJECT_MAP.get('test', '未配置')} |
| uat  | {PROJECT_MAP.get('uat', '未配置')} |
| prod | {PROJECT_MAP.get('prod', '未配置')} |

## 使用方式
在工具参数中指定 `project` 参数:
- 使用简称: `project="test"` / `project="uat"` / `project="prod"`
- 使用完整名: `project="k8s-log-xxx"`
"""


@mcp.resource("sls://help")
def get_help_resource() -> str:
    """获取 SLS 查询语法帮助"""
    return """# SLS 查询语法帮助

## 基础查询
- `*` - 查询所有日志
- `level: ERROR` - 查询 level 字段为 ERROR 的日志
- `message: "timeout"` - 查询 message 包含 timeout 的日志

## 组合查询
- `level: ERROR AND service: api` - AND 组合
- `level: ERROR OR level: WARN` - OR 组合
- `NOT level: INFO` - NOT 排除

## 时间范围
- `-1h` - 1小时前
- `-1d` - 1天前
- `-30m` - 30分钟前
- `-1w` - 1周前

## 分析查询 (SQL)
- `* | SELECT COUNT(*) GROUP BY level` - 按级别统计
- `* | SELECT host, AVG(latency) GROUP BY host` - 平均延迟

## 多环境查询
- `query_logs("ERROR", project="test")` - 查询 TEST 环境
- `query_logs("ERROR", project="prod")` - 查询 PROD 环境
"""


# ============== MCP 提示词 ==============

@mcp.prompt()
def analyze_errors_prompt(
    logstore: Annotated[str, Field(description="日志库名称")],
    project: Annotated[str, Field(description="环境简称 (test/uat/prod) 或完整项目名")] = "prod",
    time_range: Annotated[str, Field(description="时间范围")] = "-24h"
) -> str:
    """生成错误日志分析提示词

    Args:
        logstore: 日志库名称
        project: 环境简称 (test/uat/prod) 或完整项目名
        time_range: 时间范围

    Returns:
        提示词模板
    """
    return f"""请帮我分析 **{project}** 环境的 **{logstore}** 日志库中最近 {time_range} 的错误日志。

分析步骤:
1. 使用 analyze_errors 工具，指定 project="{project}", logstore="{logstore}"
2. 使用 query_logs 工具查看具体错误详情
3. 分析以下内容:
   - 错误总数和错误趋势
   - 最常见的错误类型 Top 5
   - 错误发生的时间分布
   - 可能的根本原因和建议
"""


@mcp.prompt()
def search_logs_prompt(
    keyword: Annotated[str, Field(description="搜索关键字")],
    logstore: Annotated[str, Field(description="日志库名称")] = "",
    project: Annotated[str, Field(description="环境简称 (test/uat/prod)")] = "prod",
    time_range: Annotated[str, Field(description="时间范围")] = "-1h"
) -> str:
    """生成日志搜索提示词

    Args:
        keyword: 搜索关键字
        logstore: 日志库名称
        project: 环境简称
        time_range: 时间范围

    Returns:
        提示词模板
    """
    logstore_hint = f"在 {logstore} 日志库中" if logstore else "在默认日志库中"
    return f"""请在 **{project}** 环境 {logstore_hint} 搜索包含 "{keyword}" 的日志。

时间范围: 最近 {time_range}

请:
1. 使用 search_keyword 或 query_logs 工具，指定 project="{project}"
2. 总结搜索结果
3. 如果发现异常，提供分析建议
"""


# ============== 入口 ==============

def main():
    """主入口"""
    mcp.run()


if __name__ == "__main__":
    main()
