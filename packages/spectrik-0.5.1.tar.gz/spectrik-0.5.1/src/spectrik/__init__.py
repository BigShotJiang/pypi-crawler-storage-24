"""spectrik - A generic specification and blueprint pattern for declarative configuration-as-code tools."""

from .blueprints import Blueprint as Blueprint
from .context import Context as Context
from .event import Event as Event
from .projects import Project as Project
from .projects import post_build as post_build
from .projects import pre_build as pre_build
from .projects import project as project
from .spec import Specification as Specification
from .spec import spec as spec
from .specop import Absent as Absent
from .specop import Ensure as Ensure
from .specop import Present as Present
from .specop import SpecOp as SpecOp
from .workspace import BlueprintRef as BlueprintRef
from .workspace import OperationRef as OperationRef
from .workspace import ProjectRef as ProjectRef
from .workspace import Workspace as Workspace
from .workspace import WorkspaceRef as WorkspaceRef
