"""mcp-video — Video editing MCP server for AI agents."""

__version__ = "0.2.0"

from .client import Client

__all__ = ["Client"]
