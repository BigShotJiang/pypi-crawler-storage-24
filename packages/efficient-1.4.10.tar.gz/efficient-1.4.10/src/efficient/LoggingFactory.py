import logging
from logging.config import dictConfig

"""
`logging.config.dictConfig` 使用示例，包含控制台输出和文件输出，以及不同级别的日志格式：

```python
import logging
import logging.config

# 定义日志配置字典
LOGGING_CONFIG = {
    'version': 1,
    'disable_existing_loggers': False,  # 是否禁用已存在的 logger（False 表示允许共存）
    'formatters': {
        'simple': {  # 简单格式：时间 - 级别 - 消息
            'format': '%(asctime)s - %(levelname)s - %(message)s'
        },
        'detailed': {  # 详细格式：包含模块、行号等
            'format': '%(asctime)s - %(name)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s'
        },
    },
    'handlers': {
        'console': {  # 控制台处理器
            'class': 'logging.StreamHandler',  # 输出到 stderr
            'level': 'INFO',  # 只输出 INFO 及以上级别
            'formatter': 'simple',
            'stream': 'ext://sys.stdout',  # 可选，默认 stderr，可以改为 stdout
        },
        'file': {  # 文件处理器
            'class': 'logging.FileHandler',
            'level': 'DEBUG',  # 记录 DEBUG 及以上级别
            'formatter': 'detailed',
            'filename': 'app.log',  # 日志文件路径
            'mode': 'a',  # 追加模式
            'encoding': 'utf-8',
        },
        # 可添加更多 handler，如 RotatingFileHandler 等
    },
    'loggers': {
        # 根 logger 配置（可选）
        '': {  # 空字符串表示根 logger
            'handlers': ['console', 'file'],
            'level': 'DEBUG',
            'propagate': False,  # 根 logger 不向上传递
        },
        # 自定义 logger，例如 'myapp' 模块的 logger
        'myapp': {
            'handlers': ['console'],
            'level': 'WARNING',
            'propagate': False,  # 不传递给父 logger
        },
        # 第三方库可以单独控制级别，例如降低某些库的输出
        'urllib3': {
            'level': 'WARNING',
            'handlers': [],
            'propagate': True,  # 交给根 logger 处理
        },
    },
    # 也可以配置根 logger 的快捷方式（与上面 '' 效果相同）
    'root': {
        'level': 'DEBUG',
        'handlers': ['console', 'file'],
    },
}

def main():
    # 应用配置
    logging.config.dictConfig(LOGGING_CONFIG)
    
    # 获取 logger 实例
    logger = logging.getLogger(__name__)  # 会继承根 logger 的配置
    app_logger = logging.getLogger('myapp')

    # 模拟异常
    try:
        1 / 0
    except ZeroDivisionError:
        logger.exception("捕获到异常，会记录堆栈")

if __name__ == '__main__':
    main()
```

### 补充说明
propagate 的作用是向上传播日志
    propagate=False 不向上传播日志
    propagate=True
        消息级别同时满足当前 logger 和父 logger 的级别时，当前 logger 和父 logger 都会输出日志（可能导致重复）。
        消息级别低于当前 logger 的有效级别（或当前 logger 无 handlers），那么消息会传递给父 logger，由父 logger 决定是否处理。

logger 父子关系
    logger 之间的父子关系是通过名称中的点（.）来建立
    根 logger 的名称是空字符串 ''，是所有 logger 的祖先。
    这些关系是动态的：只要你通过 logging.getLogger('myapp.child') 获取 logger，该 logger 就会自动与 myapp 建立父子关系，即使你没有显式创建 myapp logger 也没关系。


## loguru

`logging` 确实是 Python 功能最全面的标准库之一，但它的强大是以**配置复杂**为代价的。很多开发者觉得 `logging` 的学习曲线陡峭，甚至称其为“Python 的瑞士军刀，但拆开包装需要先读 200 页说明书”。

**`loguru` 正是为了解决这些痛点而诞生的**——它提供了一套更现代、更简洁的日志记录方案，同时保留了绝大多数生产环境需要的功能。

### 标准库 `logging` 的常见痛点
1. **配置繁琐**  
   要实现一个简单的“同时输出到控制台和文件”，需要手动创建 `Logger`、`Handler`、`Formatter`，再添加 Handler，代码量往往超过 10 行。
2. **概念太多**  
   Logger、Handler、Formatter、Filter、Level、Propagate……新手很容易混淆。
3. **缺少开箱即用的好体验**  
   默认输出没有颜色、缺少调用位置信息，需要手动配置。
4. **文件轮转/压缩/保留需要额外处理**  
   标准库虽然有 `RotatingFileHandler` 和 `TimedRotatingFileHandler`，但配置复杂，且不支持压缩、自动清理等现代需求。
5. **上下文管理不便**  
   要在不同函数间传递额外信息（如请求 ID），要么用 `LoggerAdapter`，要么用 `logging.Filter`，都比较绕。

### `loguru` 的解决方案
`loguru` 的口号是 **“Logging made (stupidly) simple”**，它通过以下方式解决了上述问题：

#### 1. 极简入门
```python
from loguru import logger

logger.debug("Hello, world!")
```
直接运行，控制台输出带颜色、带文件名和行号，无需任何配置。

#### 2. 一行代码添加文件输出
```python
logger.add("app.log", rotation="1 day", retention="30 days", compression="zip")
```
- `rotation`：支持按时间、大小自动轮转。
- `retention`：自动删除过期日志。
- `compression`：轮转后自动压缩。
这些功能在标准库中需要手动组合多个 Handler 或第三方库才能实现。

#### 3. 自动捕获异常
```python
@logger.catch
def my_function():
    1 / 0
```
装饰器会自动捕获异常，输出完整的堆栈信息，并可选是否继续抛出。

#### 4. 灵活的上下文绑定
```python
# 绑定一个全局上下文（比如请求ID）
logger.add("file.log", format="{time} {level} {extra[request_id]} {message}")
logger.configure(extra={"request_id": ""})

def handle_request(request_id):
    logger.bind(request_id=request_id).info("Processing...")
```
通过 `bind` 可以轻松附加结构化字段，而标准库通常要借助 `LoggerAdapter` 或 `Filter`。

#### 5. 无缝集成标准库
```python
# 让所有标准库 logging 的记录也通过 loguru 输出
logging.basicConfig(handlers=[InterceptHandler()], level=0)
```
这样既可以用 loguru 的简洁 API，又能兼容已有的 `logging` 代码。

#### 6. 更好的异步/协程支持
`loguru` 原生支持 `asyncio` 和 `gevent`，且线程安全。

---

### 什么时候还选 `logging`？
虽然 `loguru` 很方便，但 `logging` 仍然有它的适用场景：
- **大型项目已深度使用标准库**，迁移成本高。
- **需要极度精细的控制**（如自定义 `Filter`、多级继承）。
- **环境不允许安装第三方依赖**（如某些受限的嵌入环境）。

"""


class LoggingFactory:
    _configurator = False

    @classmethod
    def load_setting(cls, config: dict):
        if cls._configurator:
            return
        dictConfig(config)
        cls._configurator = True


if '__main__' == __name__:
    logger = logging.getLogger()
    logger.debug(u"debug")  # 打印全部的日志,详细的信息,通常只出现在诊断问题上
    logger.info(u"info")  # 打印info,warning,error,critical级别的日志,确认一切按预期运行
    logger.warning(u"warning")  # 打印warning,error,critical级别的日志,一个迹象表明,一些意想不到的事情发生了,或表明一些问题在不久的将来(例如。磁盘空间低”),这个软件还能按预期工作
    logger.error(u"error")  # 打印error,critical级别的日志,更严重的问题,软件没能执行一些功能
    logger.exception('exception')
    logger.critical(u"critical")  # 打印critical级别,一个严重的错误,这表明程序本身可能无法继续运行
    logger.critical("发生异常", exc_info=True)  # 发生异常时可以用 exc_info 打印调用栈

    LOGGING = {
        'version': 1,  # 必须是 1，这是 logging 配置字典的版本号（Python logging 标准）

        'disable_existing_loggers': False,  # 非常重要！False 表示不自动禁用已存在的 logger
        # 如果设为 True，会关闭所有未在下面显式定义的 logger（包括 Django 内置的），容易导致日志全部消失

        # 定义日志格式（formatter），相当于模板
        # %(asctime)s     : 时间戳，例如 2026-01-28 15:30:45,123
        # %(levelname)s   : 日志级别，如 INFO、WARNING、ERROR
        # %(name)s        : logger 的名字，例如 asyncio、django.request、access
        # %(message)s     : 实际日志内容
        # %(module)s      : 模块
        # %(funcName)s    : 函数
        # %(lineno)d      : 行号
        # %(pathname)s    : 文件路径
        'formatters': {
            'verbose': {
                'format': '%(asctime)s [%(levelname)s] %(module)s@%(funcName)s:%(lineno)d %(message)s',
            },
            'simple': {
                'format': '%(asctime)s %(log_color)s[%(levelname)s]%(reset)s %(module)s@%(funcName)s:%(lineno)d %(message)s',
            },
        },

        # 定义日志输出目的地（handler）
        'handlers': {
            'console': {  # 输出到控制台（stdout/stderr）
                'level': 'INFO',  # 只输出 INFO 及以上级别（INFO、WARNING、ERROR、CRITICAL）
                'class': 'logging.StreamHandler',  # 标准流输出 handler
                'formatter': 'simple',  # 使用上面定义的 simple 格式
            },

            'asyncio_debug': {  # 用于捕获 asyncio 更详细的 DEBUG 信息（可选）
                'level': 'DEBUG',  # 记录 DEBUG 及以上级别
                'class': 'logging.handlers.RotatingFileHandler',
                'filename': '/scj/efficient/logs/asyncio_debug.log',
                'maxBytes': 10 * 1024 * 1024,
                'backupCount': 5,
                'formatter': 'verbose',
            },

            'tmp_debug': {
                'level': 'DEBUG',
                'class': 'logging.handlers.RotatingFileHandler',
                'filename': '/scj/efficient/logs/tmp_debug.log',
                'maxBytes': 10 * 1024 * 1024,
                'backupCount': 5,
                'formatter': 'verbose',
            },

            'data_coll': {
                'level': 'DEBUG',
                'class': 'logging.handlers.RotatingFileHandler',
                'filename': '/scj/efficient/logs/data_coll.log',
                'maxBytes': 10 * 1024 * 1024,
                'backupCount': 5,
                'formatter': 'verbose',
            },

            'permission': {
                'level': 'DEBUG',
                'class': 'logging.handlers.RotatingFileHandler',
                'filename': '/scj/efficient/logs/permission.log',
                'maxBytes': 10 * 1024 * 1024,
                'backupCount': 5,
                'formatter': 'verbose',
            },
        },

        # 定义具体的 logger
        'loggers': {
            'root': {
                'handlers': ['console'],
                'level': 'INFO',  # 关键：设为 INFO
            },

            'asyncio': {
                'handlers': ['console', 'asyncio_debug'],
                'level': 'DEBUG',
                'propagate': False,
            },

            'tmp_debug': {
                'handlers': ['console', 'tmp_debug'],
                'level': 'DEBUG',
                'propagate': False,
            },

            'data_coll': {
                'handlers': ['console', 'data_coll'],
                'level': 'DEBUG',
                'propagate': False,
            },

            'permission': {
                'handlers': ['console', 'permission'],
                'level': 'DEBUG',
                'propagate': False,
            },

            # 专门针对 asyncio 模块的 logger（asyncio 源码里面：logger = logging.getLogger(__package__)）
            # 'asyncio': {
            #     'handlers': ['console', 'slow_asyncio_file', 'asyncio_file'],
            #     # 输出到：控制台 + 专用慢日志文件
            #     # 如果想同时记录更多 DEBUG 信息，可以加 'asyncio_file'
            #
            #     'level': 'WARNING',  # 只记录 WARNING 及以上
            #     # asyncio 的慢回调警告是 WARNING 级别，所以必须 >= WARNING 才能看到
            #     # 如果想看到 asyncio 内部更多细节（如 selector、transport），可以临时改成 'DEBUG'
            #
            #     'propagate': False,  # 非常重要！False 表示不向上传播
            #     # 如果为 True，会把日志继续传给父 logger（root 或其他），可能导致重复输出或被其他 handler 拦截
            # },
        },
    }

    LoggingFactory.load_setting(LOGGING)
