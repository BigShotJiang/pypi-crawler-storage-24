import time
from datetime import time as dtime
from datetime import date, datetime, timezone, timedelta


# 时间戳转为日期
def fmt_date(fmt: str | None = None, timestamp: int | None = None):
    if fmt is None:
        fmt = '%Y-%m-%d %H:%M:%S'
    if timestamp is None:
        timestamp = round(time.time())
    date_str = time.strftime(fmt, time.localtime(timestamp))
    return date_str


def str2datetime(date_str: str) -> datetime:
    fmt = infer_time_format(date_str)
    return datetime.strptime(date_str, fmt)


# 日期转为时间戳
def str2time(date_str: str) -> int:
    fmt = infer_time_format(date_str)
    time_array = time.strptime(date_str, fmt)
    timestamp = round(time.mktime(time_array))
    return timestamp


def calc_date(date_str, days=1):
    fmt = infer_time_format(date_str)
    tm = time.strptime(date_str, fmt)
    # print('年', tm.tm_year)
    # print('月', tm.tm_mon)
    # print('月的日', tm.tm_mday)
    # print('周的日', tm.tm_wday)
    # print('年的日', tm.tm_yday)
    curr_date = date(tm.tm_year, tm.tm_mon, tm.tm_mday)
    next_date = curr_date + timedelta(days=days)
    # return next_date.year, next_date.month, next_date.day
    return next_date.strftime(fmt)


# 推断时间格式
def infer_time_format(date_str):
    time_formats = [
        '%Y%m%d',  # 20241010
        '%Y-%m-%d',  # 2024-10-10
        '%Y/%m/%d',  # 2024/10/10
        '%Y.%m.%d',  # 2024.10.10
        '%Y-%m-%d %H:%M:%S',  # 2024-10-10 10:01:27
        '%Y-%m-%d %H:%M:%S.%f',
        '%Y/%m/%d %H:%M:%S',  # 2024/10/10 10:01:27
        '%H:%M:%S',  # 10:01:27
        '%Y-%m-%dT%H:%M:%S.%fZ',  # 2024-10-30T03:57:51.770Z
    ]
    for time_format in time_formats:
        try:
            # 尝试解析时间字符串
            time.strptime(date_str, time_format)
            return time_format
        except ValueError:
            continue
    return None


def iso8601_dt(time_str: str) -> datetime:
    """
    2024-10-30T03:57:51.770Z
    ISO 8601 格式。ISO 8601 是一种国际标准化的日期和时间表示方法，常用于数据传输和存储。
    结构解析
        2024-10-30：日期部分，年-月-日。
        T：日期和时间的分隔符。
        03:57:51.770：时间部分，时:分:秒.毫秒。
        Z：指的是 UTC 时区（也称零时区）。Z 是 “Zulu time” 的缩写，表示 UTC+0。
    :return: UTC时区的 datetime
    """
    # 尽管字符串 2024-10-30T03:57:51.770Z 表示的是 UTC 时间，但 datetime.strptime 默认不会将其解析为特定时区
    dt: datetime = datetime.strptime(time_str, "%Y-%m-%dT%H:%M:%S.%fZ")
    return dt.replace(tzinfo=timezone.utc)  # 设置时区 UTC


# 获取标准UTC时间
def utc_now() -> datetime:
    dt = datetime.now(timezone.utc)
    # print(dt, type(dt))
    return dt


def beijing_time(utc_dt: datetime = None, out_format="%Y-%m-%d %H:%M:%S") -> str:
    if utc_dt is None:
        utc_dt = utc_now()

    utc_time = utc_dt.replace(tzinfo=timezone.utc)  # 将UTC时间转换为UTC时区对象
    bj_time = utc_time + timedelta(hours=8)  # 东八区（UTC+8）的时区偏移量是8小时
    beijing_time_str = bj_time.strftime(out_format)
    return beijing_time_str


def in_time_section(a: str, b: str):
    a = [int(i) for i in a.split(':')]
    b = [int(i) for i in b.split(':')]
    return dtime(*a) <= datetime.now().time() <= dtime(*b)


if '__main__' == __name__:
    import calendar

    # year = 2024
    # moth = 10
    # _, num_days = calendar.monthrange(year, moth)
    # for i in range(num_days):
    #     main(year, moth, i + 1)
    print(fmt_date())

    print(str2time('2025-03-20'))
    print(str2time('2025/03/20'))
    print(str2time('2025.03.20'))
    print(str2time('2025-03-20 14:53:00'))

    print(calc_date('2020-10-10', -1))
    print(calc_date('2020-10-10', 0))
    print(calc_date('2020-10-10', +1))

    print(iso8601_dt('2024-10-30T03:57:51.770Z'))

    print(str2datetime('2025-10-27 00:00:00') >= str2datetime('2025-10-27 00:00:00'))
    print(str2datetime('2025-11-30 23:59:59'))

    print(in_time_section('14:00:00', '14:35:59'))
