from time import time_ns


def call_timer(func):
    def wrapper(*args, **kwargs):
        t = time_ns()
        r = func(*args, **kwargs)
        print(func.__name__, '执行用时', (time_ns() - t) / 1000000000, f"{func.__code__.co_filename}, line {func.__code__.co_firstlineno + 1}")
        return r

    return wrapper


def list_of_dicts_to_markdown_table(dicts_list):
    if not dicts_list:
        return ""
    headers = list(dicts_list[0].keys())
    markdown_table = "| " + " | ".join(headers) + " |\n"
    markdown_table += "| " + " | ".join(['---'] * len(headers)) + " |\n"
    for data_dict in dicts_list:
        row = [str(data_dict.get(header, '')) for header in headers]
        markdown_table += "| " + " | ".join(row) + " |\n"
    return markdown_table


# 打印一个对象的属性
@call_timer
def dir_print(obj):
    data = []
    for i in dir(obj):
        if i.startswith('__'):
            continue
        r = getattr(obj, i)

        need_param = False
        explain = ''
        if callable(r):
            try:
                v = r()
            except TypeError as e:
                v = None
                need_param = True
        else:
            v = r

        row = dict(
            callable=int(callable(r)),
            params=int(need_param),
            name=i,
            explain=explain,
            value=v,
            value_type=type(v),
        )
        # print(row)
        data.append(row)

    data.sort(key=lambda x: (x['callable'], x['params']))
    print(list_of_dicts_to_markdown_table(data))


if '__main__' == __name__:
    import datetime

    dir_print(datetime.datetime.now())
