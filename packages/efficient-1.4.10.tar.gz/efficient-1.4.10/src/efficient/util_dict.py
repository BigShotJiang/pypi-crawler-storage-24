import re


def dic_get(dic: dict, key, default=None):
    value = dic.get(key)
    if value is None:
        return default
    return value


def set_nested_value(dictionary, path, value, overwrite=True):
    keys = path.split('.')
    current = dictionary

    # 遍历除最后一个键以外的所有键
    for key in keys[:-1]:
        if key not in current:
            current[key] = dict()
        current = current[key]

    # 设置最后一个键的值
    if overwrite:
        current[keys[-1]] = value
        return True

    if keys[-1] in current:
        return False
    current[keys[-1]] = value
    return True


def get_nested_value(data, path, default=None):
    keys = path.split('.')
    temp = data
    for i in keys:
        if i.startswith('$'):
            i = int(i[1:])

        try:
            pattern = """\[(\d+)\]"""
            if type(i) is str and (_match := re.findall(pattern, i)):
                k1 = re.sub(pattern, '', i)
                temp = temp[k1]
                for k2 in _match:
                    temp = temp[int(k2)]
            else:
                temp = temp[i]
        except IndexError as e:
            # print([][1])
            temp = None
        except TypeError as e:
            # print([]['1'])
            temp = None
        except KeyError as e:
            # print({}['1'])
            temp = None

    if temp is None:
        return default
    return temp


if '__main__' == __name__:
    d = dict(x=1, a=dict(y=1))
    set_nested_value(d, 'a.b.c', 1)
    print(d)

    d = {
        'books': [
            [
                {'id': 1, 'name': 'book1'}
            ]
        ],
        'author': 'xxx',
    }
    print(get_nested_value(d, 'books.$0.$0.name'))
    print(get_nested_value(d, 'books[0][0].name'))
    print(get_nested_value(d, 'author'))
