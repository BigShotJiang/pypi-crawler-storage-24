from setuptools import setup, find_packages

setup(
    name="angelic-kernel",
    version="0.3",
    description="A fake OS kernel framework for Python",
    author="ERROR-Xmakernotfound",
    packages=find_packages(),
    install_requires=[
        "pygame"
    ],
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="",
    python_requires=">=3.8",
)