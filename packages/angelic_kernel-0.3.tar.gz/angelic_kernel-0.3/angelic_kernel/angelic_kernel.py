import json
import os
import pygame
import sys
from ctypes import *
if sys.platform == "win32":
    try:
        windll.shcore.SetProcessDpiAwareness(1)
    except Exception as e:
        pass
class PathError(Exception):
    def __init__(self, message):
        super().__init__(message)
        self.message = message
class Kernel:
    __Version__ = "0.3"
    def __init__(self):
        self.__Version__="0.3"
    class SD:
        def __init__(self,SD_name="SD"):
            self.SD_name = SD_name
            if os.path.exists(self.file_path(self.SD_name)):
                self.data = self.load()
            else:
                self.data = {
                    "Kernel": {
                        "TypeID": "dir"
                    },
                    "root": {
                        "TypeID": "dir"
                    },
                }
                self.dump(self.data)
        def dump(self, data):
            with open(self.file_path(self.SD_name), "w") as f:
                json.dump(data, f, indent=1)
        def load(self):
            with open(self.file_path(self.SD_name), "r") as f:
                return json.load(f)
        def file_path(self, relative_path):
            try:
                base_path = sys._MEIPASS
            except Exception:
                base_path = os.path.abspath(".")
            return os.path.join(base_path, relative_path)
    class screen:
        def __init__(self, width, height,Kernel_SD_instance):
            pygame.init()
            pygame.font.init()
            if isinstance(Kernel_SD_instance, Kernel.SD):
                self.sd = Kernel_SD_instance
            else:
                raise TypeError(f"{Kernel_SD_instance} must be a Kernel.SD instance")
            self.font = pygame.font.SysFont("Consolas", 20)
            self.font_size = 20
            self.screen = pygame.display.set_mode((width, height))
            self.clock = pygame.time.Clock()
            self.mouse_held = False
            self.held_keys = {}
            self.shift_key = {
                "a": "A", "b": "B", "c": "C", "d": "D", "e": "E", "f": "F", "g": "G", "h": "H",
                "i": "I", "j": "J", "k": "K", "l": "L", "m": "M", "n": "N", "o": "O", "p": "P",
                "q": "Q", "r": "R", "s": "S", "t": "T", "u": "U", "v": "V", "w": "W", "x": "X",
                "y": "Y", "z": "Z",
                "1": "!", "2": "@", "3": "#", "4": "$", "5": "%", "6": "^", "7": "&", "8": "*",
                "9": "(", "0": ")",
                "[": "{", "]": "}", "\\": "|", ";": ":", "'": '"', ",": "<", ".": ">", "/": "?",
                "-": "_", "=": "+", "`": "~"
            }
            self.sprites = {}
            self.surfaces = {}
            self.surface_log = []
            self.text_log = []
        def clear(self):
            self.screen.fill((0, 0, 0))
        def clear_logs(self):
            self.text_log = []
        def frame(self, tick=60):
            self.clock.tick(tick)
            pygame.display.flip()
        def events(self):
            e = (None, None)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.KEYDOWN:
                    e = ("keydown", pygame.key.name(event.key))
                    self.held_keys[pygame.key.name(event.key)] = True
                elif event.type == pygame.KEYUP:
                    e = ("keyup", pygame.key.name(event.key))
                    self.held_keys[pygame.key.name(event.key)] = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    e = ("mousedown", pygame.mouse.get_pos())
                    self.mouse_held = True
                elif event.type == pygame.MOUSEBUTTONUP:
                    e = ("mouseup", pygame.mouse.get_pos())
                    self.mouse_held = False
            return e
        def shift(self, key):
            return self.shift_key.get(key, "")

        def set_font(self, mode, font, size):
            if mode == 1:
                self.font = pygame.font.Font(self.sd.file_path(font), size)
                self.font_size = size
            elif mode == 2:
                self.font = pygame.font.SysFont(font, size)
                self.font_size = size
            else:
                raise AttributeError(f"{mode} is not a valid font mode")
        def print(self, text, x=0, y=0, color=(255, 255, 255), add_to_text_log=True, blit_surface=None):
            if blit_surface is None:
                self.screen.blit(self.font.render(text, True, color), (x, y))
            else:
                self.surfaces[blit_surface]["data"].blit(self.font.render(text, True, color), (x, y))
            if add_to_text_log:
                self.text_log.append((text, x, y, color, blit_surface))
        def input(self, prompt, base_prompt="", x_pos=0, y_pos=0, color=(255, 255, 255), blit_surface=None):
            itext = base_prompt
            def update():
                self.clear()
                for text in self.text_log:
                    txt = text[0]
                    x = text[1]
                    y = text[2]
                    col = text[3]
                    b_surf = text[4]
                    self.print(txt, x, y, col, False, b_surf)
                self.render_surfaces()
                self.render_sprites()
            def insert_blink():
                t1 = ""
                t2 = []
                for char in itext:
                    t2.append(" ")
                t2.insert(selection_index, blink)
                for char in t2:
                    t1 += char
                return t1
            def blank_prompt():
                t = ""
                for char in str(prompt):
                    t = t + " "
                if len(itext) == 0:
                    return t[:-1]
                return t
            def insert_text(text):
                t1 = ""
                t2 = []
                for char in itext:
                    t2.append(char)
                t2.insert(selection_index, text)
                for char in t2:
                    t1 += char
                return t1
            blink_count = 0
            blink = " "
            selection_index = 0
            while True:
                update()
                if selection_index < 0:
                    selection_index = 0
                elif selection_index >= len(itext) and len(itext) != 0:
                    selection_index = len(itext) - 1
                elif selection_index <= 0:
                    selection_index = 0
                if blit_surface is None:
                    self.print(prompt + itext, x_pos, y_pos, color, False)
                    self.print(blank_prompt() + insert_blink(), x_pos + self.font_size / 4, y_pos, color, False)
                else:
                    self.print(prompt + itext, x_pos, y_pos, color, False, blit_surface)
                    self.print(blank_prompt() + insert_blink(), x_pos + self.font_size / 4, y_pos, color, False,
                               blit_surface)
                e = self.events()
                if e == ("keydown", "return"):
                    return itext
                elif e == ("keydown", "backspace"):
                    t1 = ""
                    t2 = []
                    for char in itext:
                        t2.append(char)
                    if len(t2) > 0:
                        del t2[selection_index]
                        selection_index -= 1
                    for char in t2:
                        t1 += char
                    itext = t1
                elif e == ("keydown", "left"):
                    if selection_index < 0:
                        selection_index = 0
                    elif selection_index == 0:
                        selection_index = 0
                    else:
                        selection_index -= 1
                elif e == ("keydown", "right"):
                    if selection_index < 0:
                        selection_index = 0
                    elif selection_index >= len(itext):
                        selection_index = len(itext) - 1
                    else:
                        selection_index += 1
                elif e == ("keydown", "space"):
                    selection_index += 1
                    itext = insert_text(" ")
                elif e[0] == "keydown":
                    selection_index += 1
                    if self.is_held("left shift") or self.is_held("right shift"):
                        if e != ("keydown", "left shift") and e != ("keydown", "right shift"):
                            itext = itext + self.shift(e[1])
                    else:
                        itext = insert_text(e[1])
                if blink_count > 15:
                    blink_count = 0
                    if blink == " ":
                        blink = "|"
                    elif blink == "|":
                        blink = " "
                blink_count += 1
                self.frame(60)

        class sprite:
            def __init__(self, screen):
                self.sc = screen
                self.x = 0
                self.y = 0
                self.rect = None
                self.image = None
            def set_image(self, image):
                self.image = pygame.image.load(self.sc.sd.file_path(image))
                self.rect = self.image.get_rect(topleft=(self.x, self.y))
            def update(self):
                if self.image:
                    self.sc.screen.blit(self.image, (self.x, self.y))
                    self.rect.topleft = (self.x, self.y)
            def move(self, x, y):
                self.x += x
                self.y += y
            def set_pos(self, x, y):
                self.x = x
                self.y = y
            def scale(self, width, height):
                self.image = pygame.transform.scale(self.image, (width, height))
        def add_sprite(self, sprite):
            self.sprites[sprite] = self.sprite(self)
        def render_sprites(self):
            for sprite in self.sprites:
                self.sprites[sprite].update()
        def move_sprite(self, sprite, x, y):
            self.sprites[sprite].move(x, y)
        def set_sprite_pos(self, sprite, x, y):
            self.sprites[sprite].set_pos(x, y)
        def set_sprite_image(self, sprite, image):
            self.sprites[sprite].set_image(image)
        def kill_sprite(self, sprite):
            del (self.sprites[sprite])
        def sprite_touching_sprite(self, sprite_a, sprite_b):
            return self.sprites[sprite_a].rect.colliderect(
                self.sprites[sprite_b].rect
            )
        def sprite_touching_mouse(self, sprite):
            pos = pygame.mouse.get_pos()
            return self.sprites[sprite].rect.collidepoint(pos)
        def sprite_click(self, sprite, event):
            if event[0] == "mousedown":
                if self.sprites[sprite].rect.collidepoint(event[1][0], event[1][1]):
                    return True
            return False
        def scale_sprite(self, sprite, width, height):
            self.sprites[sprite].scale(width, height)

        def surface(self, name, x=0, y=0, width=10, height=10, color=(255, 255, 255)):
            self.surfaces[name] = {}
            self.surfaces[name]["pos"] = (x, y)
            self.surfaces[name]["data"] = pygame.Surface((width, height))
            self.surfaces[name]["data"].fill(color)
            self.surfaces[name]["rect"] = self.surfaces[name]["data"].get_rect(topleft=(x, y))
        def render_surfaces(self):
            for surface in self.surfaces:
                self.screen.blit(self.surfaces[surface]["data"], self.surfaces[surface]["pos"])
        def surface_click(self, surface, event):
            if self.surfaces[surface]["rect"].collidepoint(pygame.mouse.get_pos()) and event[0] == "mousedown":
                return True
            return False
        def surface_touching_mouse(self, surface):
            return self.surfaces[surface]["rect"].collidepoint(pygame.mouse.get_pos())
        def kill_surface(self, name):
            del (self.surfaces[name])


        def quit(self):
            pygame.quit()
        def wait(self, t):
            pygame.time.wait(t)
        def set_window_name(self, name):
            pygame.display.set_caption(name)
        def set_window_icon(self, file):
            f = self.sd.file_path(file)
            pygame.display.set_icon(pygame.image.load(f))
        def mouse_down(self):
            return self.mouse_held
        def is_held(self, key):
            return self.held_keys.get(key, False)
        def mouse_pos(self):
            return pygame.mouse.get_pos()
    class sound:
        def __init__(self, sd):
            self.sounds = {}
            if isinstance(sd, Kernel.SD):
                self.sd = sd
            else:
                raise TypeError(f"input:{sd} is not a Kernel.SD instance")
            pygame.mixer.init()
        def add_sound(self, sound):
            self.sounds[sound] = pygame.mixer.Sound(self.sd.file_path(sound))
        def play_sound(self, sound):
            if sound in self.sounds:
                self.sounds[sound].play()
        def stop(self,name):
            if name in self.sounds:
                self.sounds[name].stop()
    class file_system:
        def __init__(self,Kernel_SD_instance):
            if isinstance(Kernel_SD_instance, Kernel.SD):
                self.sd = Kernel_SD_instance
            else:
                raise TypeError(f"input:{Kernel_SD_instance} is not a Kernel.SD instance")
            self.path=[]
            self.data=self.sd.load()
            self.node=self.data
            self.update_node()
            self.deph=0
        def save(self):
            self.sd.dump(self.data)
        def set_root(self,root_path_list):
            if type(root_path_list) is list:
                self.path=root_path_list.copy()
                self.deph=0
                self.update_node()
            else:
                raise TypeError(f"input:{root_path_list} must be a list")
        def update_node(self):
            self.node=self.data
            for path in self.path:
                if path in self.node:
                    self.node=self.node[path]
                else:
                    raise PathError(f"path:{path} does not exist")
        def goto(self,path):
            if path in self.node:
                if path == "TypeID":
                    raise TypeError(f"Cannot enter TypeID")
                if self.node[path]["TypeID"]=="dir":
                    self.path.append(path)
                    self.deph+=1
                    self.update_node()
                    return None
                else:
                    raise TypeError(f"path:{path} is not a dir")
            raise PathError(f"path:{path} does not exist")
        def back(self):
            if self.deph>0:
                self.path=self.path[:-1]
                self.deph-=1
                self.update_node()
            else:
                raise PathError(f"Path already at root!")
        def list_dir(self):
            dir=[]
            for item in self.node:
                if item=="TypeID":
                    continue
                elif self.node[item]["TypeID"]=="protected":
                    continue
                elif self.node[item]["TypeID"]=="hidden":
                    continue
                elif self.node[item]["TypeID"]=="dir":
                    dir.append(f"{item}/")
                elif self.node[item]["TypeID"]=="file":
                    dir.append(f"{item}.{self.node[item]['Type']}")
            return dir
        def current_path(self):
            return self.path

        def make_dir(self,name):
            if name not in self.node:
                self.node[name]={"TypeID": "dir"}
                self.save()
            else:
                raise PathError(f"path:{name} already exists!")
        def make_file(self,name,file_type=None,data=None):
            if file_type is None:
                raise TypeError(f"file_type:{file_type}, File types CANNOT be NoneType")
            if data is None:
                raise TypeError(f"data:{data}, File data CANNOT be NoneType")
            if name not in self.node:
                self.node[name]={"TypeID": "file",
                                 "Type": file_type,
                                 "Data": data,
                                 "Cache":{}
                                 }
                self.save()
        def make_protected(self,name):
            if name not in self.node:
                self.node[name]={"TypeID": "protected"}
                self.save()
            else:
                raise PathError(f"path:{name} already exists!")
        def make_hidden(self,name):
            if name not in self.node:
                self.node[name]={"TypeID": "hidden"}
                self.save()
            else:
                raise PathError(f"path:{name} already exists!")

        def delete_dir(self,name):
            if name in self.node:
                if self.node[name]["TypeID"]=="dir":
                    del(self.node[name])
                    self.save()
                else:
                    raise TypeError(f"path:{name} is not a dir")
            else:
                raise PathError(f"Path {name} does not exist")
        def delete_file(self,name):
            if name in self.node:
                if self.node[name]["TypeID"]=="file":
                    del(self.node[name])
                    self.save()
                else:
                    raise TypeError(f"path:{name} is not a file")
            else:
                raise PathError(f"Path {name} does not exist")
        def delete_protected(self,name,force=False):
            if name in self.node:
                if self.node[name]["TypeID"]=="protected":
                    if force:
                        del(self.node[name])
                        self.save()
                    else:
                        raise PermissionError(f"Permission denied")
                else:
                    raise PathError(f"Path {name} does not exist")
            else:
                raise PathError(f"Path {name} does not exist")
        def delete_hidden(self,name):
            if name in self.node:
                if self.node[name]["TypeID"]=="hidden":
                    del(self.node[name])
                    self.save()
                else:
                    raise TypeError(f"Path {name} is not hidden")
            else:
                raise PathError(f"Path {name} does not exist")

        def path_exists(self,path):
            if path in self.node:
                return True
            return False
        def path_is_dir(self,path):
            if path in self.node:
                if self.node[path]["TypeID"]=="dir":
                    return True
                return False
            raise PathError(f"Path {path} does not exist")
        def path_is_file(self,path):
            if path in self.node:
                if self.node[path]["TypeID"]=="file":
                    return True
                return False
            raise PathError(f"Path {path} does not exist")
        def path_is_protected(self,path):
            if path in self.node:
                if self.node[path]["TypeID"]=="protected":
                    return True
                return False
            raise PathError(f"Path {path} does not exist")
        def path_is_hidden(self,path):
            if path in self.node:
                if self.node[path]["TypeID"]=="hidden":
                    return True
                return False
            raise PathError(f"Path {path} does not exist")
        def file_is_type(self,name,file_type):
            if name in self.node:
                if self.node[name]["TypeID"]=="file":
                    if self.node[name]["Type"]==file_type:
                        return True
                    return False
                raise PathError(f"Path {name} is not a file")
            raise PathError(f"Path {name} does not exist")
        def is_root(self):
            if self.deph==0:
                return True
            return False

        def open_file(self,name):
            if name in self.node:
                if self.node[name]["TypeID"]=="file":
                    return self.node[name]["Data"]
                else:
                    raise TypeError(f"Path {name} is not a file")
            raise PathError(f"Path {name} does not exist")
        def open_protected(self,name):
            if name in self.node:
                if self.node[name]["TypeID"]=="protected":
                    return self.node[name]
                else:
                    raise TypeError(f"Path {name} is not a protected")
            raise PathError(f"Path {name} does not exist")
        def open_hidden(self,name):
            if name in self.node:
                if self.node[name]["TypeID"]=="hidden":
                    return self.node[name]
                else:
                    raise TypeError(f"Path {name} is not hidden")
            else:
                raise PathError(f"Path {name} does not exist")

        def modify_hidden(self,name,key,value):
            if name in self.node:
                if self.node[name]["TypeID"]=="hidden":
                    self.node[name][key]=value
                    self.save()
                else:
                    raise TypeError(f"Path {name} is not hidden")
            else:
                raise PathError(f"Path {name} does not exist")
        def modify_file(self,name,key,value):
            if name in self.node:
                if self.node[name]["TypeID"]=="file":
                    self.node[name][key]=value
                    self.save()
                else:
                    raise TypeError(f"Path {name} is not file")
            else:
                raise PathError(f"Path {name} does not exist")
if __name__=="__main__":
    print("Angelic kernel:",Kernel.__Version__)