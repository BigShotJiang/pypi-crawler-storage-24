"""E2E tests validating core infrastructure against design specs.

Covers areas not in test_e2e.py: message bus, tool protocol, security
profiles, memory, config, sub-agent spawn, scheduler integration.
"""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from workpilot.agent.context import ContextBuilder
from workpilot.agent.loop import AgentLoop
from workpilot.agent.tools.base import Tool, ToolMetadata
from workpilot.agent.tools.registry import PROTECTED_TOOLS, ToolRegistry
from workpilot.agents.builtin import get_builtin_agents, merge_agents
from workpilot.bus.events import EventType, InboundMessage, StreamingChunk
from workpilot.bus.queue import EventBus, MessageBus
from workpilot.config.schema import (
    AgentConfig,
    AuditConfig,
    CronConfig,
    CronJobConfig,
    HeartbeatConfig,
    SecurityProfile,
)
from workpilot.cron.service import SchedulerService, _detect_trigger_type
from workpilot.hooks.handlers import register_builtin_handlers
from workpilot.hooks.manager import HookManager, HookResult, HookVerdict
from workpilot.providers.base import LLMResponse, ToolCallRequest
from workpilot.security.audit import AuditLogger
from workpilot.security.estop import EStop, EStopError
from workpilot.session.manager import SessionManager

# ── Helpers ──────────────────────────────────────────────────────────────────


class _EchoTool(Tool):
    @property
    def name(self):
        return "echo"

    @property
    def description(self):
        return "Echo"

    @property
    def parameters(self):
        return {"type": "object", "properties": {"text": {"type": "string"}}}

    @property
    def metadata(self):
        return ToolMetadata(approval="never")

    async def execute(self, **kwargs):
        return f"echo: {kwargs.get('text', '')}"


def _provider(*responses):
    p = AsyncMock()
    p.complete = AsyncMock(side_effect=list(responses))
    return p


# ══════════════════════════════════════════════════════════════════════════════
# core-infra.md §3: Message Bus
# ══════════════════════════════════════════════════════════════════════════════


class TestMessageBusE2E:
    """core-infra.md §3 + core/message-bus.md: bounded queues, typed events."""

    @pytest.mark.asyncio
    async def test_bounded_inbound_queue(self):
        bus = MessageBus(max_queue_size=2)
        msg = InboundMessage(channel="cli", channel_id="t", sender_id="u", content="hi")
        await bus.publish_inbound(msg)
        await bus.publish_inbound(msg)
        assert bus.inbound_qsize == 2

    @pytest.mark.asyncio
    async def test_event_bus_typed_events(self):
        bus = EventBus()
        received = []

        async def handler(et, payload):
            received.append((et.value, payload))

        bus.on(EventType.TOOL_EXECUTED, handler)
        bus.emit(EventType.TOOL_EXECUTED, {"tool": "shell", "duration": 100})
        import asyncio

        await asyncio.sleep(0.05)
        assert len(received) == 1
        assert received[0][0] == "tool.executed"

    def test_streaming_chunk_type(self):
        chunk = StreamingChunk(channel="cli", channel_id="t", content="tok", chunk_type="token")
        assert chunk.done is False
        assert chunk.chunk_type == "token"

    def test_consume_aliases(self):
        bus = MessageBus()
        assert bus.consume_inbound == bus.get_inbound
        assert bus.consume_outbound == bus.get_outbound


# ══════════════════════════════════════════════════════════════════════════════
# core-infra.md §4.4 + core/tool.md: Tool Protocol
# ══════════════════════════════════════════════════════════════════════════════


class TestToolProtocolE2E:
    """core/tool.md: ToolMetadata, approval levels, anti-shadowing, pipeline."""

    def test_tool_metadata_fields(self):
        m = ToolMetadata()
        assert m.risk_level == "low"
        assert m.approval == "auto"
        assert m.isolation == "process"
        assert m.timeout == 600

    def test_protected_tools_count(self):
        assert len(PROTECTED_TOOLS) == 20
        assert "tools" in PROTECTED_TOOLS
        assert "cron" in PROTECTED_TOOLS

    def test_anti_shadowing_blocks_override(self):
        reg = ToolRegistry()
        reg.register(_EchoTool())

        class FakeEcho(Tool):
            @property
            def name(self):
                return "echo"

            @property
            def description(self):
                return "fake"

            @property
            def parameters(self):
                return {}

            async def execute(self, **kwargs):
                return "fake"

        # echo is not protected, so re-registration is allowed
        reg.register(FakeEcho())

    def test_anti_shadowing_blocks_protected(self):
        reg = ToolRegistry()

        class FakeShell(Tool):
            @property
            def name(self):
                return "shell"

            @property
            def description(self):
                return "fake"

            @property
            def parameters(self):
                return {}

            async def execute(self, **kwargs):
                return "fake"

        reg.register(FakeShell())  # first registration OK
        with pytest.raises(ValueError, match="Cannot override"):
            reg.register(FakeShell())  # second blocked

    @pytest.mark.asyncio
    async def test_scoped_copy_restricts_tools(self):
        reg = ToolRegistry()
        reg.register(_EchoTool())
        scoped = reg.scoped_copy(["nonexistent"])
        assert scoped.list_tools() == []

    @pytest.mark.asyncio
    async def test_tool_execution_returns_result(self):
        reg = ToolRegistry()
        reg.register(_EchoTool())
        result = await reg.execute("echo", {"text": "hello"})
        assert result == "echo: hello"


# ══════════════════════════════════════════════════════════════════════════════
# core-infra.md §6: Hooks
# ══════════════════════════════════════════════════════════════════════════════


class TestHooksE2E:
    """core-infra.md §6: 4 hooks, 8 handlers, priority dispatch."""

    def test_four_hook_points(self):
        from workpilot.hooks.manager import HOOK_POINTS

        assert len(HOOK_POINTS) == 4
        assert "on_message_received" in HOOK_POINTS
        assert "pre_tool_use" in HOOK_POINTS
        assert "post_tool_use" in HOOK_POINTS
        assert "on_message_sent" in HOOK_POINTS

    def test_eight_builtin_handlers_registered(self):
        mgr = HookManager()
        register_builtin_handlers(mgr)
        # Check all 4 hook points have handlers
        assert mgr.has("on_message_received")
        assert mgr.has("pre_tool_use")
        assert mgr.has("post_tool_use")
        assert mgr.has("on_message_sent")

    @pytest.mark.asyncio
    async def test_priority_ordering(self):
        mgr = HookManager()
        order = []

        async def h1(ctx):
            order.append("first")
            return HookResult.allow()

        async def h2(ctx):
            order.append("second")
            return HookResult.allow()

        mgr.register("test", h2, priority=20)
        mgr.register("test", h1, priority=5)
        await mgr.dispatch_checked("test", "data")
        assert order == ["first", "second"]

    @pytest.mark.asyncio
    async def test_first_reject_wins(self):
        mgr = HookManager()

        async def blocker(ctx):
            return HookResult.reject("blocked")

        async def never_reached(ctx):
            return HookResult.allow()

        mgr.register("test", blocker, priority=1)
        mgr.register("test", never_reached, priority=2)
        result = await mgr.dispatch_checked("test", "data")
        assert result.verdict == HookVerdict.REJECT


# ══════════════════════════════════════════════════════════════════════════════
# core-infra.md §9: Security
# ══════════════════════════════════════════════════════════════════════════════


class TestSecurityE2E:
    """core-infra.md §9: profiles, E-stop, audit."""

    def test_four_security_profiles(self):
        profiles = [p.value for p in SecurityProfile]
        assert set(profiles) == {"open", "standard", "controlled", "restricted"}

    def test_estop_halts_and_resets(self):
        estop = EStop()
        estop.trigger("leak", actor="detector")
        assert estop.is_halted
        with pytest.raises(EStopError):
            estop.check()
        estop.reset(actor="admin")
        assert not estop.is_halted
        estop.check()  # no error

    @pytest.mark.asyncio
    async def test_estop_blocks_tools_via_hook(self, tmp_path):
        hooks = HookManager()
        estop = EStop()
        estop.trigger("emergency", actor="test")
        register_builtin_handlers(hooks, estop=estop)

        from workpilot.hooks.manager import PreToolHookContext

        ctx = PreToolHookContext(tool_name="shell", args={"command": "ls"})
        result = await hooks.dispatch_checked("pre_tool_use", ctx)
        assert result.verdict == HookVerdict.REJECT
        assert "E-stop" in result.reason

    def test_audit_redacts_secrets(self):
        from workpilot.security.audit import _redact_string

        text = "key=sk-abc123456789012345678901234567890"
        redacted = _redact_string(text)
        assert "[REDACTED]" in redacted


# ══════════════════════════════════════════════════════════════════════════════
# core-infra.md §7 + tool-spawn.md: Sub-Agents
# ══════════════════════════════════════════════════════════════════════════════


class TestSubAgentE2E:
    """core-infra.md §7: fresh context, permission intersection, spawn depth."""

    def test_builtin_agent_permissions(self):
        agents = get_builtin_agents()
        # Explorer: read-only
        explorer = agents["explorer"]
        assert explorer.permissions.allow_shell is False
        assert explorer.permissions.allow_file_write is False
        assert explorer.permissions.allow_spawn is False
        # Default: full access
        default = agents["default"]
        assert default.permissions.allow_spawn is True
        assert default.max_spawn_depth == 2

    def test_session_fork_is_empty(self, tmp_path):
        sm = SessionManager(tmp_path)
        sm.add_message("parent", {"role": "user", "content": "hello"})
        fork_id = sm.fork("parent")
        assert sm.get_messages(fork_id) == []
        assert len(sm.get_messages("parent")) == 1

    def test_merge_agents_user_overrides(self):
        builtin = get_builtin_agents()
        user = {"explorer": AgentConfig(max_iterations=30)}
        merged = merge_agents(builtin, user)
        assert merged["explorer"].max_iterations == 30
        assert merged["explorer"].model == "fast"  # preserved

    def test_merge_agents_disabled(self):
        builtin = get_builtin_agents()
        user = {"explorer": AgentConfig(enabled=False)}
        merged = merge_agents(builtin, user)
        assert "explorer" not in merged


# ══════════════════════════════════════════════════════════════════════════════
# core-infra.md §10 + core/agent.md §10: Memory
# ══════════════════════════════════════════════════════════════════════════════


class TestMemoryE2E:
    """core-infra.md §10: MEMORY.md in context, session JSONL."""

    def test_memory_in_system_prompt(self, tmp_path):
        (tmp_path / "MEMORY.md").write_text(
            "# Facts\n- Python 3.13\n- FastAPI project", encoding="utf-8"
        )
        ctx = ContextBuilder(AgentConfig(), tmp_path)
        prompt = ctx.build_system_prompt()
        assert "Python 3.13" in prompt
        assert "FastAPI project" in prompt

    def test_session_jsonl_persistence(self, tmp_path):
        sm = SessionManager(tmp_path)
        sm.add_message("s1", {"role": "user", "content": "hello"})
        sm.add_message("s1", {"role": "assistant", "content": "hi"})

        # Reload from disk
        sm2 = SessionManager(tmp_path)
        msgs = sm2.get_messages("s1")
        assert len(msgs) == 2
        assert msgs[0]["content"] == "hello"
        assert msgs[1]["content"] == "hi"


# ══════════════════════════════════════════════════════════════════════════════
# core/agent.md §2: Context Assembly
# ══════════════════════════════════════════════════════════════════════════════


class TestContextAssemblyE2E:
    """core/agent.md §2: system → facts → skills → history → user."""

    def test_context_order(self, tmp_path):
        (tmp_path / "MEMORY.md").write_text("project uses pytest", encoding="utf-8")
        config = AgentConfig(instructions="You are a helpful assistant.")
        ctx = ContextBuilder(config, tmp_path)
        messages = ctx.build_messages(
            [{"role": "user", "content": "prev"}, {"role": "assistant", "content": "prev-reply"}],
            "current question",
        )
        # System prompt first
        assert messages[0]["role"] == "system"
        assert "helpful assistant" in messages[0]["content"]
        assert "pytest" in messages[0]["content"]
        # History in middle
        assert messages[1]["content"] == "prev"
        assert messages[2]["content"] == "prev-reply"
        # User message last
        assert messages[-1]["role"] == "user"
        assert "current question" in messages[-1]["content"]


# ══════════════════════════════════════════════════════════════════════════════
# core/agent.md §9: Error Recovery
# ══════════════════════════════════════════════════════════════════════════════


class TestErrorRecoveryE2E:
    """core/agent.md §9: tool errors returned to LLM, not saved to session."""

    @pytest.mark.asyncio
    async def test_tool_error_returned_to_llm(self, tmp_path):
        class FailTool(Tool):
            @property
            def name(self):
                return "fail"

            @property
            def description(self):
                return "fails"

            @property
            def parameters(self):
                return {"type": "object", "properties": {}}

            async def execute(self, **kwargs):
                raise RuntimeError("intentional")

        reg = ToolRegistry()
        reg.register(FailTool())
        tc = ToolCallRequest(id="tc1", name="fail", arguments={})
        provider = _provider(
            LLMResponse(content=None, tool_calls=[tc]),
            LLMResponse(content="handled error", tool_calls=[]),
        )
        loop = AgentLoop(
            config=AgentConfig(max_iterations=5),
            provider=provider,
            tool_registry=reg,
            bus=MessageBus(),
            session_manager=SessionManager(tmp_path),
            audit=AuditLogger(AuditConfig(enabled=False)),
            workspace=tmp_path,
        )
        await loop.run_once("try it")
        # LLM saw error and recovered
        assert provider.complete.call_count == 2


# ══════════════════════════════════════════════════════════════════════════════
# core/scheduler.md: Scheduler E2E
# ══════════════════════════════════════════════════════════════════════════════


class TestSchedulerE2E:
    """core/scheduler.md: trigger types, execution, heartbeat, history."""

    def test_trigger_autodetection(self):
        assert _detect_trigger_type("0 9 * * 1-5") == "cron"
        assert _detect_trigger_type(3600) == "interval"
        assert _detect_trigger_type("security.leak") == "event"

    @pytest.mark.asyncio
    async def test_full_job_lifecycle(self, tmp_path):
        """Add → execute → history → disable → enable → remove."""
        config = CronConfig(enabled=True)
        svc = SchedulerService(config, tmp_path)

        mock_agent = AsyncMock()
        mock_agent.run_once = AsyncMock(return_value="done")
        svc.set_agent_loop(mock_agent)

        # Add
        svc.add_job("test-job", 3600, "do stuff", dynamic=True)
        assert "test-job" in [j["name"] for j in svc.list_jobs()]

        # Execute

        job = svc._jobs["test-job"]
        result = await svc._execute_job(job)
        assert result == "done"

        # History
        history = svc.get_history("test-job")
        assert len(history) == 1
        assert history[0]["status"] == "success"

        # Disable
        svc.disable("test-job")
        assert not svc._jobs["test-job"].enabled

        # Enable
        svc.enable("test-job")
        assert svc._jobs["test-job"].enabled

        # Remove
        svc.remove_job("test-job")
        assert "test-job" not in svc._jobs

    @pytest.mark.asyncio
    async def test_heartbeat_reads_file(self, tmp_path):
        (tmp_path / "HEARTBEAT.md").write_text("- Check CI status", encoding="utf-8")
        config = CronConfig(enabled=True, heartbeat=HeartbeatConfig(enabled=True, interval=60))
        svc = SchedulerService(config, tmp_path)

        mock_agent = AsyncMock()
        mock_agent.run_once = AsyncMock(return_value="CI is green")
        svc.set_agent_loop(mock_agent)

        svc._register_heartbeat()
        await svc._execute_heartbeat()

        prompt = mock_agent.run_once.call_args[0][0]
        assert "Check CI status" in prompt

    def test_scheduler_health(self, tmp_path):
        config = CronConfig(
            enabled=True,
            jobs={
                "j1": CronJobConfig(schedule=60, prompt="x"),
                "j2": CronJobConfig(schedule=60, prompt="y", enabled=False),
            },
        )
        svc = SchedulerService(config, tmp_path)
        h = svc.health()
        assert h["total_jobs"] == 2
        assert h["active_jobs"] == 1
        assert h["disabled_jobs"] == 1

    @pytest.mark.asyncio
    async def test_crontool_list_and_add(self, tmp_path):
        from workpilot.agent.tools.cron import CronTool

        config = CronConfig(enabled=True)
        svc = SchedulerService(config, tmp_path)
        tool = CronTool(svc)

        # Empty list
        result = await tool.execute(action="list")
        assert "no scheduled" in result.lower()

        # Add
        result = await tool.execute(action="add", schedule=3600, prompt="check CI")
        assert "added" in result.lower()

        # List now has job
        result = await tool.execute(action="list")
        assert "interval" in result

    def test_dynamic_jobs_persist(self, tmp_path):
        config = CronConfig(enabled=True)
        svc = SchedulerService(config, tmp_path)
        svc.add_job("persist-test", 60, "task", dynamic=True)

        # New instance loads persisted jobs
        svc2 = SchedulerService(config, tmp_path)
        assert "persist-test" in svc2._jobs


# ══════════════════════════════════════════════════════════════════════════════
# core-infra.md §12: Configuration
# ══════════════════════════════════════════════════════════════════════════════


class TestConfigE2E:
    """core-infra.md §12: config resolution, model aliases."""

    def test_security_profile_default_is_standard(self):
        from workpilot.config.schema import SecurityConfig

        sc = SecurityConfig()
        assert sc.profile == SecurityProfile.STANDARD

    def test_agent_config_defaults(self):
        ac = AgentConfig()
        assert ac.max_iterations == 40
        assert len(ac.tools) == 13  # without cron (added dynamically)
        assert ac.context_limit == 128_000
        assert ac.memory_writable is True

    def test_model_alias_resolution(self):
        from workpilot.providers.router import resolve_model

        assert resolve_model("anthropic/claude-sonnet-4-5") == "anthropic/claude-sonnet-4-5"
        # auto/fast/reasoning/coding are aliases
        from workpilot.providers.router import _ALIASES

        assert _ALIASES == {"auto", "fast", "reasoning", "coding"}


# ── Memory consolidation lock ──────────────────────────────────────────────


class TestConsolidationLock:
    """Verify MemoryStore shares consolidation lock per workspace."""

    def test_same_workspace_shares_lock(self, tmp_path):
        from workpilot.agent.memory import MemoryStore

        m1 = MemoryStore(tmp_path)
        m2 = MemoryStore(tmp_path, agent_name="sub")
        assert m1.consolidation_lock is m2.consolidation_lock

    def test_different_workspace_different_lock(self, tmp_path):
        from workpilot.agent.memory import MemoryStore

        ws1 = tmp_path / "ws1"
        ws2 = tmp_path / "ws2"
        ws1.mkdir()
        ws2.mkdir()
        m1 = MemoryStore(ws1)
        m2 = MemoryStore(ws2)
        assert m1.consolidation_lock is not m2.consolidation_lock


# ── Tool execution timeout ─────────────────────────────────────────────────


class TestToolExecutionTimeout:
    """Verify registry enforces tool.metadata.timeout via asyncio.wait_for."""

    @pytest.mark.asyncio
    async def test_tool_timeout_returns_error(self):
        """A tool that exceeds its timeout should return an error, not hang."""
        import asyncio

        class SlowTool(Tool):
            @property
            def name(self):
                return "slow"

            @property
            def description(self):
                return "Slow tool"

            @property
            def parameters(self):
                return {"type": "object", "properties": {}}

            @property
            def metadata(self):
                return ToolMetadata(approval="never", timeout=1)  # 1 second

            async def execute(self, **kwargs):
                await asyncio.sleep(10)  # will be cancelled by timeout
                return "done"

        reg = ToolRegistry()
        reg.register(SlowTool())
        result = await reg.execute("slow", {})
        assert "Error" in result
