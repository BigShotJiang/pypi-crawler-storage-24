"""
Configuration schema — Pydantic v2 models for WorkPilot.

All sensitive fields use SecretStr so they are never accidentally logged or serialised.
"""

from __future__ import annotations

from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, Field, SecretStr, model_validator

# ── Enums ────────────────────────────────────────────────────────────────────


class LogLevel(str, Enum):
    TRACE = "TRACE"
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


class ChannelType(str, Enum):
    CLI = "cli"
    TEAMS = "teams"
    OUTLOOK = "outlook"
    GITHUB = "github"
    ADO = "ado"
    WEBHOOK = "webhook"
    HTTP_API = "http_api"


class SecurityProfile(str, Enum):
    """Security profile presets — higher = more restrictive."""

    OPEN = "open"
    STANDARD = "standard"
    CONTROLLED = "controlled"
    RESTRICTED = "restricted"


class AutonomyLevel(int, Enum):
    """Progressive autonomy levels for agent actions."""

    FORBIDDEN = 0  # Level 0: action is prohibited
    APPROVAL = 1  # Level 1: agent executes after human confirms
    NOTIFY = 2  # Level 2: agent executes, then notifies
    AUTONOMOUS = 3  # Level 3: agent executes silently (audit log only)


class RiskLevel(str, Enum):
    """Risk classification for tool operations."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


# ── Provider configs ─────────────────────────────────────────────────────────


class ProviderConfig(BaseModel):
    """OpenAI-compatible provider config.

    Works for OpenAI, Azure OpenAI, Azure AI Foundry, and any OpenAI-compatible endpoint.
    WorkPilot detects the service from the endpoint URL:
    - no endpoint           → OpenAI direct          (model prefix: openai/)
    - *.openai.azure.com    → Azure OpenAI Service   (model prefix: azure/)
    - anything else         → Azure AI Foundry        (model prefix: azure_ai/)
    """

    api_key: SecretStr | None = Field(
        default=None,
        description="API key for OpenAI/Azure OpenAI-compatible endpoint.",
    )
    endpoint: str | None = Field(
        default=None,
        description=(
            "Base endpoint URL. Leave empty for OpenAI direct; set Azure endpoint "
            "for Azure OpenAI (for example: https://xxx.openai.azure.com)."
        ),
    )
    api_version: str = Field(
        default="2024-10-21",
        description="Azure OpenAI / Azure AI Foundry API version (used for azure/* and azure_ai/* models).",
    )


class GitHubCopilotConfig(BaseModel):
    """GitHub Copilot authentication settings."""

    token: SecretStr | None = Field(
        default=None,
        description="GitHub OAuth token used to exchange a Copilot session token.",
    )


class ModelAlias(BaseModel):
    """Named model aliases for convenience.

    Use "auto" to let WorkPilot pick the best available model
    based on configured provider credentials.
    """

    default: str | list[str] = Field(
        default="auto",
        description=(
            "Primary model alias. Use a concrete model ID, 'auto', or an ordered "
            "list for fallback (for example: ['github/gpt-5.4', 'github/gpt-5.2'])."
        ),
    )
    fast: str | list[str] = Field(
        default="auto",
        description=(
            "Low-latency alias. Use a concrete model ID, 'auto', or an ordered fallback list."
        ),
    )
    reasoning: str | list[str] = Field(
        default="auto",
        description=(
            "Deep-reasoning alias. Use a concrete model ID, 'auto', or an ordered fallback list."
        ),
    )
    coding: str | list[str] = Field(
        default="auto",
        description=(
            "Coding-optimized alias. Use a concrete model ID, 'auto', or an ordered fallback list."
        ),
    )


class ModelRouting(BaseModel):
    """Alias candidate chains used when alias values are set to "auto".

    Supported candidate item formats:
    - concrete model id: github/gpt-5.4, openai/gpt-4o-mini, azure/gpt-4o
    - smart OpenAI tokens: openai:auto, openai:fast, openai:reasoning

    Resolution rule: pick the first candidate with available credentials,
    then continue with the rest as runtime fallback candidates.
    """

    default_candidates: list[str] = Field(
        default_factory=lambda: ["github/gpt-5.4", "github/gpt-5.2", "openai:auto"],
        description="Candidate chain for alias 'auto' (and 'coding' when coding=auto).",
    )
    fast_candidates: list[str] = Field(
        default_factory=lambda: [
            "github/gpt-5-mini",
            "github/claude-haiku-4.5",
            "openai:fast",
        ],
        description="Candidate chain for alias 'fast'.",
    )
    reasoning_candidates: list[str] = Field(
        default_factory=lambda: ["github/o3", "openai:reasoning"],
        description="Candidate chain for alias 'reasoning'.",
    )


class ProvidersConfig(BaseModel):
    """Top-level provider configuration used by model routing and auth.

    Minimal examples:

    1) GitHub-only:
         providers:
             github_copilot:
                 token: ${GITHUB_TOKEN}

    2) GitHub + Azure OpenAI:
         providers:
             github_copilot:
                 token: ${GITHUB_TOKEN}
             openai:
                 api_key: ${AZURE_OPENAI_API_KEY}
                 endpoint: ${AZURE_OPENAI_ENDPOINT}

    3) Custom routing order:
         providers:
             routing:
                 default_candidates: [github/gpt-5.4, github/gpt-5.2, openai:auto]
                 fast_candidates: [github/gpt-5-mini, openai:fast]
    """

    openai: ProviderConfig = Field(default_factory=ProviderConfig)
    github_copilot: GitHubCopilotConfig = Field(default_factory=GitHubCopilotConfig)
    aliases: ModelAlias = Field(default_factory=ModelAlias)
    routing: ModelRouting = Field(default_factory=ModelRouting)


# ── Agent config ─────────────────────────────────────────────────────────────


class AgentConfig(BaseModel):
    name: str = "WorkPilot Assistant"
    description: str = ""
    model: str = "auto"
    instructions: str = ""
    max_iterations: int = 40
    timeout: int = 1200
    memory_window: int = 50
    memory_writable: bool = True
    context_limit: int = 128_000  # Max tokens for context window (for compaction thresholds)
    reminder_interval: int = Field(
        default=10, ge=0
    )  # Inject a system reminder every N tool calls (0 = disabled)
    max_spawn_depth: int = 2
    max_concurrent_children: int = 5
    tools: list[str] = Field(
        default_factory=lambda: [
            "shell",
            "read_file",
            "write_file",
            "edit_file",
            "list_dir",
            "search_files",
            "git",
            "http_request",
            "web_search",
            "web_fetch",
            "browser",
            "spawn",
            "notify",
        ]
    )
    skills: list[str] = Field(default_factory=list)
    workspace: str = "."
    chat: bool = True
    enabled: bool = True
    metadata: dict[str, Any] = Field(default_factory=dict)
    # Identity files
    soul_file: str | None = None  # SOUL.md path
    user_file: str | None = None  # USER.md path (auto-learning)
    agents_file: str | None = None  # AGENTS.md path (multi-agent rules)
    # Per-agent permissions
    permissions: AgentPermissions | None = None


class AgentPermissions(BaseModel):
    """Per-agent permission overrides."""

    allow_shell: bool = True
    allow_file_write: bool = True
    allow_file_read: bool = True
    allow_network: bool = True
    allow_browser: bool = False
    allow_spawn: bool = False
    allowed_tools: list[str] = Field(default_factory=lambda: ["*"])
    denied_tools: list[str] = Field(default_factory=list)


# Update forward reference
AgentConfig.model_rebuild()


class AgentsConfig(BaseModel):
    default: AgentConfig = Field(default_factory=AgentConfig)
    agents: dict[str, AgentConfig] = Field(default_factory=dict)

    @model_validator(mode="before")
    @classmethod
    def _flatten_agents(cls, data: Any) -> Any:
        """Allow extra agents at the top level instead of under an 'agents' key.

        Both formats are accepted:
          agents:            agents:
            reviewer: ...      agents:
                                 reviewer: ...
        """
        if not isinstance(data, dict):
            return data
        data = dict(data)
        extra: dict[str, Any] = {}
        reserved = {"default", "agents"}
        for key in list(data):
            if key not in reserved:
                extra[key] = data.pop(key)
        if extra:
            nested = data.get("agents", {})
            if not isinstance(nested, dict):
                raise ValueError(f"'agents' must be a mapping, got {type(nested).__name__}")
            duplicates = set(nested).intersection(extra)
            if duplicates:
                raise ValueError(
                    f"Agent(s) defined both at top level and under 'agents': "
                    f"{', '.join(sorted(duplicates))}. Remove the duplicate."
                )
            nested.update(extra)
            data["agents"] = nested
        return data


# ── Tools config ─────────────────────────────────────────────────────────────


class ShellConfig(BaseModel):
    """Shell execution guardrails."""

    timeout: int = 120
    max_output_chars: int = 50_000
    deny_patterns: list[str] = Field(
        default_factory=lambda: [
            r"rm\s+-rf\s+/",
            r":\(\)\s*\{\s*:\|:&\s*\}\s*;",
            r"\bformat\b.*[A-Z]:",
            r"\bshutdown\b",
            r"\breboot\b",
            r"\bmkfs\b",
            r"\bdd\b\s+if=.*/dev/",
            r"\b(curl|wget)\b.*\|\s*(ba)?sh",
            r"\bchmod\b\s+777\b",
            r"\bchown\b\s+-R\s+root",
        ]
    )
    allow_patterns: list[str] = Field(default_factory=list)


class FileSystemConfig(BaseModel):
    """File system access guardrails."""

    restrict_to_workspace: bool = True
    deny_paths: list[str] = Field(
        default_factory=lambda: [
            "/etc/shadow",
            "/etc/passwd",
            "~/.ssh",
            "~/.gnupg",
            "~/.aws/credentials",
        ]
    )
    max_file_size_bytes: int = 10 * 1024 * 1024  # 10 MB


class BrowserConfig(BaseModel):
    """Browser automation (Playwright) settings."""

    enabled: bool = False
    browser: str = "msedge"  # msedge | chromium | firefox
    headless: bool = True
    timeout: int = 30_000
    viewport_width: int = 1280
    viewport_height: int = 720
    evaluate_enabled: bool = True  # allow JS evaluation
    allowed_domains: list[str] = Field(default_factory=list)  # empty = all (with SSRF rules)
    persistent_profile: str | None = None  # path to user data dir for authenticated browsing
    mark_content_untrusted: bool = True  # wrap extracted content as untrusted


class MCPAuthConfig(BaseModel):
    """Authentication config for HTTP MCP servers."""

    type: Literal["none", "bearer", "oauth"] = "none"
    token: SecretStr | None = None
    token_env: str | None = None
    client_id: str | None = None
    client_secret: SecretStr | None = None
    scopes: list[str] = Field(default_factory=list)


class MCPServerConfig(BaseModel):
    """Configuration for a single MCP server."""

    # Connection
    command: str | None = None
    args: list[str] = Field(default_factory=list)
    url: str | None = None
    env: dict[str, str] = Field(default_factory=dict)

    # Metadata
    description: str | None = Field(None, max_length=100)  # one-line summary (≤100 chars)
    enabled: bool = True  # set False to disable without removing from config

    # Per-server overrides (all optional)
    timeout: int | None = None
    risk_level: Literal["low", "medium", "high"] | None = None
    approval: Literal["never", "auto", "always"] | None = None
    namespace: str | None = Field(None, pattern=r"^[a-zA-Z0-9_-]+$")

    # Auth (HTTP transport only)
    auth: MCPAuthConfig = Field(default_factory=MCPAuthConfig)

    @property
    def is_agency(self) -> bool:
        """Auto-detect Agency-proxied servers by command name."""
        return self.command == "agency"


class CopilotModelPolicyConfig(BaseModel):
    """Per-task-type default model. Overrides default_model when set."""

    code: str = "claude-sonnet-4.6"
    review: str = "claude-sonnet-4.6"
    test: str = "claude-haiku-4.5"
    refactor: str = "claude-sonnet-4.6"


class CopilotRetryConfig(BaseModel):
    enabled: bool = False
    max_attempts: int = 2


class CopilotHooksConfig(BaseModel):
    block_copilot_tools: list[str] = Field(default_factory=list)


class CopilotToolConfig(BaseModel):
    """GitHub Copilot CLI delegate tool settings."""

    enabled: bool = True
    cli_path: str | None = (
        None  # None = use SDK bundled binary; set to override (e.g. "/usr/local/bin/copilot")
    )
    default_model: str = "claude-sonnet-4.6"
    task_timeout: int = 0  # seconds; 0 = use 1h cap (SDK default is only 60s)
    max_concurrent: int = Field(default=5, ge=1)  # max parallel background tasks; must be >= 1
    notification_max_chars: int = 4000
    model_policy: CopilotModelPolicyConfig = Field(default_factory=CopilotModelPolicyConfig)
    retry: CopilotRetryConfig = Field(default_factory=CopilotRetryConfig)
    hooks: CopilotHooksConfig = Field(default_factory=CopilotHooksConfig)


class ClaudeCodeModelPolicyConfig(BaseModel):
    """Per-task-type default model for Claude Code CLI tasks."""

    code: str = "sonnet"
    review: str = "sonnet"
    test: str = "sonnet"
    refactor: str = "sonnet"
    research: str = "sonnet"


class ClaudeCodeToolConfig(BaseModel):
    """Claude Code CLI delegate tool settings."""

    enabled: bool = True
    cli_path: str | None = None  # None = use SDK default; set to override
    default_model: str = "sonnet"
    task_timeout: int = Field(default=1800, ge=0)  # seconds; 0 = use 1h cap
    max_concurrent: int = Field(default=3, ge=1)
    notification_max_chars: int = 4000
    model_policy: ClaudeCodeModelPolicyConfig = Field(default_factory=ClaudeCodeModelPolicyConfig)
    dangerously_skip_permissions: bool = False
    # SDK setting sources — include 'local' so .claude/settings.local.json
    # (which has enabledPlugins for Agency plugins) is loaded
    setting_sources: list[str] = Field(default_factory=lambda: ["user", "project", "local"])
    # Whether to instruct Claude to use Agency plugins (/review-pr, /code-review)
    use_plugins: bool = True


class ToolsConfig(BaseModel):
    shell: ShellConfig = Field(default_factory=ShellConfig)
    filesystem: FileSystemConfig = Field(default_factory=FileSystemConfig)
    browser: BrowserConfig = Field(default_factory=BrowserConfig)
    copilot: CopilotToolConfig = Field(default_factory=lambda: CopilotToolConfig())
    claude_code: ClaudeCodeToolConfig = Field(default_factory=ClaudeCodeToolConfig)
    mcp_servers: dict[str, MCPServerConfig] = Field(default_factory=dict)

    @model_validator(mode="before")
    @classmethod
    def _coerce_none(cls, data: Any) -> Any:
        """Accept `tools: null` in YAML as empty ToolsConfig."""
        if data is None:
            return {}
        return data


# ── Security config ──────────────────────────────────────────────────────────


class AuditConfig(BaseModel):
    enabled: bool = True
    log_file: str | None = None
    redact_secrets: bool = True


class RBACRole(BaseModel):
    """Role-based access control role."""

    name: str
    allowed_tools: list[str] = Field(default_factory=lambda: ["*"])
    denied_tools: list[str] = Field(default_factory=list)
    allowed_channels: list[str] = Field(default_factory=lambda: ["*"])
    max_iterations: int = 25


class ToolAutonomyConfig(BaseModel):
    """Per-tool autonomy level override."""

    level: AutonomyLevel = AutonomyLevel.AUTONOMOUS
    risk: RiskLevel = RiskLevel.LOW


class PathAutonomyConfig(BaseModel):
    """Per-path autonomy override."""

    read: AutonomyLevel = AutonomyLevel.AUTONOMOUS
    write: AutonomyLevel = AutonomyLevel.NOTIFY


class ApprovalConfig(BaseModel):
    """Approval workflow settings."""

    timeout_seconds: int = 900  # 15 min before escalation
    auto_approve_timeout: int = 180  # 3 min auto-approve for low-risk escalations
    escalation_channels: list[str] = Field(default_factory=lambda: ["teams", "email"])
    default_channel: str = "cli"


class AllowlistConfig(BaseModel):
    """Per-user tool approval allowlist settings."""

    enabled: bool = True
    path: str | None = None  # Custom path; defaults to ~/.workpilot/allowlist.json


class SecurityOverrides(BaseModel):
    """Fine-grained security overrides on top of profile."""

    tools: dict[str, int] = Field(default_factory=dict)  # tool_name → autonomy level
    paths: dict[str, PathAutonomyConfig] = Field(default_factory=dict)  # glob → config
    agents: dict[str, dict[str, Any]] = Field(default_factory=dict)  # agent → restrictions


class EStopConfig(BaseModel):
    """Emergency stop configuration."""

    enabled: bool = True
    trigger_on_leak: bool = True
    notify_channels: list[str] = Field(default_factory=list)


class SecurityConfig(BaseModel):
    profile: SecurityProfile = SecurityProfile.STANDARD
    audit: AuditConfig = Field(default_factory=AuditConfig)
    estop: EStopConfig = Field(default_factory=EStopConfig)
    roles: dict[str, RBACRole] = Field(default_factory=dict)
    default_role: str = "user"
    require_auth: bool = False
    approval: ApprovalConfig = Field(default_factory=ApprovalConfig)
    allowlist: AllowlistConfig = Field(default_factory=AllowlistConfig)
    overrides: SecurityOverrides = Field(default_factory=SecurityOverrides)

    # Profile-based autonomy defaults (populated from profile)
    autonomy_defaults: dict[str, int] = Field(default_factory=dict)


# ── Gateway / web channel config ─────────────────────────────────────────────


class GatewayConfig(BaseModel):
    """Self-hosted HTTP API gateway (web channel)."""

    enabled: bool = False
    host: str = "localhost"
    port: int = 3003
    api_key: SecretStr | None = None
    cors_origins: list[str] = Field(default_factory=list)  # empty = same-origin only

    @model_validator(mode="after")
    def _coerce_empty_api_key(self) -> GatewayConfig:
        """Treat empty/whitespace API key as unset (None)."""
        if self.api_key is not None and not self.api_key.get_secret_value().strip():
            self.api_key = None
        return self

    rate_limit_per_minute: int = 60
    request_timeout: int = 300  # Per-request timeout in seconds
    entra_tenant_id: str = ""  # must be configured explicitly
    entra_client_id: str = ""  # must be configured explicitly


# ── Channel configs ──────────────────────────────────────────────────────────


class BaseChannelConfig(BaseModel):
    enabled: bool = False
    allow_from: list[str] = Field(default_factory=list)


class CLIChannelConfig(BaseChannelConfig):
    enabled: bool = True
    prompt: str = "you> "


class CloudChannelConfig(BaseChannelConfig):
    """WorkPilot Cloud Gateway relay channel.

    Connects outbound to wss://<url>/connect using an Entra ID access token.
    Enables Teams / Web Chat messages to reach the local agent without
    inbound firewall rules.

    login_method:
      auto    — (default) browser PKCE only
      browser — same as auto (explicit)
      wam     — WAM broker → browser PKCE fallback (requires msal[broker] on Windows)
      device  — device code flow (visit URL + enter code); only when explicitly configured
                (many tenants disable device code via Conditional Access)
    """

    enabled: bool = True  # auto-connect on every workpilot startup (silent auth only)

    # Official WorkPilot Cloud Gateway — pre-configured for direct use.
    # Override in workpilot.yaml only if self-hosting a private gateway.
    # Use GUID-only scope (no api:// prefix) — AADSTS90009 blocks the api:// form
    # when client_id == resource app_id (same app).
    url: str = "wss://workpilot-gw-dev.azurewebsites.net/connect"
    tenant_id: str = "72f988bf-86f1-41af-91ab-2d7cd011db47"
    client_id: str = "c5bdcb9d-14dc-4b8a-9530-643d9db6df25"
    scope: str = "c5bdcb9d-14dc-4b8a-9530-643d9db6df25/.default"
    login_method: Literal["auto", "browser", "wam", "device"] = "auto"
    login_port: int = 0  # 0 = use config.channels.web.port at runtime; set explicitly to override
    auto_reconnect: bool = True
    reconnect_max: int = 60
    # Local dev only: skip MSAL and use this token directly as the Bearer value.
    # Set to the gateway's Auth:Bypass:Token (default "dev-bypass") for local testing.
    bypass_token: str | None = None
    # Teams app deep-link used for the Teams (Cloud) chip on the status dashboard.
    # The chip is only shown when the cloud channel is enabled and a cloud URL is configured.
    # Format: https://teams.cloud.microsoft/l/app/<app-id>
    teams_app_url: str = ""


class ChannelsConfig(BaseModel):
    cli: CLIChannelConfig = Field(default_factory=CLIChannelConfig)
    cloud: CloudChannelConfig = Field(default_factory=CloudChannelConfig)
    web: GatewayConfig = Field(default_factory=GatewayConfig)


# ── Graph config ─────────────────────────────────────────────────────────────


class GraphAuthConfig(BaseModel):
    """Microsoft Graph API authentication."""

    client_id: SecretStr | None = None
    client_secret: SecretStr | None = None
    tenant_id: str | None = None
    scopes: list[str] = Field(
        default_factory=lambda: [
            "Mail.ReadWrite",
            "Mail.Send",
            "ChannelMessage.Send",
            "Chat.ReadWrite",
            "User.Read",
        ]
    )
    use_device_code: bool = False
    use_managed_identity: bool = False


class GraphConfig(BaseModel):
    """Microsoft Graph integration config."""

    enabled: bool = False
    auth: GraphAuthConfig = Field(default_factory=GraphAuthConfig)


# ── Cron config ──────────────────────────────────────────────────────────────


class CronJobConfig(BaseModel):
    """Single scheduled job definition."""

    schedule: str | int  # cron expr (str), interval seconds (int), or EventType (str with ".")
    agent: str = "default"
    prompt: str = ""
    session_mode: Literal["isolated", "persistent"] = "isolated"
    notify_channels: list[str] = Field(default_factory=list)
    enabled: bool = True
    timeout: int | None = Field(default=None, ge=0)  # Per-job timeout override (seconds)


class HeartbeatConfig(BaseModel):
    """Built-in heartbeat job configuration."""

    enabled: bool = True
    interval: int = 1800  # 30 minutes, in seconds


class CronConfig(BaseModel):
    enabled: bool = False
    heartbeat: HeartbeatConfig = Field(default_factory=HeartbeatConfig)
    jobs: dict[str, CronJobConfig] = Field(default_factory=dict)
    max_concurrent_jobs: int = Field(default=5, ge=1)


# ── Logging config ───────────────────────────────────────────────────────────


class LoggingConfig(BaseModel):
    level: LogLevel = LogLevel.INFO
    format: str = "pretty"  # "pretty" | "json"
    file: str | None = None


# ── Top-level config ─────────────────────────────────────────────────────────


class AppConfig(BaseModel):
    """Root configuration for WorkPilot."""

    name: str = "workpilot"
    entrypoint: str = "default"

    providers: ProvidersConfig = Field(default_factory=ProvidersConfig)
    agents: AgentsConfig = Field(default_factory=AgentsConfig)
    tools: ToolsConfig = Field(default_factory=ToolsConfig)
    security: SecurityConfig = Field(default_factory=SecurityConfig)
    channels: ChannelsConfig = Field(default_factory=ChannelsConfig)
    graph: GraphConfig = Field(default_factory=GraphConfig)
    cron: CronConfig = Field(default_factory=CronConfig)
    logging: LoggingConfig = Field(default_factory=LoggingConfig)
