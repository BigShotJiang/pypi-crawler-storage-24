# Notify Tool

> **Date**: 2026-03-08
> **Tool name**: `notify` (renamed from `message`)
> **File**: `workpilot/agent/tools/notify.py`
> **Class**: `NotifyTool`
> **Risk level**: low
> **Approval**: never
> **Tier**: core (always in function calling schema)

---

## 1. Purpose

The `notify` tool pushes notifications to the **user** via their active channels.
It publishes an `OutboundMessage` to the `MessageBus`, which routes it to the
appropriate channel handler.

**Use cases:**
- Agent processing a CLI task → notify web: "deployment complete"
- Scheduled job finishes → notify all active channels
- Long-running tool completes → send status update

**Not for:**
- Sending messages to other people (use MCP tools: Teams, Mail)
- Replying in specific threads (use MCP tools)
- Replying to the current conversation (agent returns text directly)

---

## 2. Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `channel` | string | yes | Target channel name or `'*'` for all active channels |
| `content` | string | yes | Notification message text |

The `channel` parameter description dynamically lists active channels:
`"Active: cli, web. Use '*' for all."`

---

## 3. Description

```
Push a notification to the user via their active channel.
```

---

## 4. How It Works

```
Agent decides to send a notification
  ↓
LLM calls: notify(channel="*", content="Build complete")
  ↓
NotifyTool.execute():
  channel == "*"  → broadcast to all active channels
  channel == "cli" → single channel
  ↓
  For each target:
    OutboundMessage(channel=ch, channel_id=ch, content=content)
    → bus.publish_outbound(msg)
  ↓
ChannelManager picks up OutboundMessage → routes to channel.send()
```

### Broadcast (`channel='*'`)

```python
targets = self._active_channels_fn()  # e.g. ["cli", "web"]
for ch in targets:
    await bus.publish_outbound(OutboundMessage(channel=ch, ...))
return f"Notified {len(results)} channels: cli, web"
```

### Dynamic channel discovery

`NotifyTool` receives an `active_channels_fn` callback at construction:

```python
NotifyTool(
    bus=self.bus,
    active_channels_fn=lambda: list(self.channel_manager._channels.keys()),
)
```

This is called dynamically when:
1. Building the `description` property (shows active channels to LLM)
2. Executing `channel='*'` broadcast
3. Building the `parameters` property (channel description shows available names)

---

## 5. Migration from `message`

| Before | After |
|--------|-------|
| Tool name: `message` | Tool name: `notify` |
| File: `message.py` | File: `notify.py` |
| Class: `MessageTool` | Class: `NotifyTool` |
| Params: `channel`, `content`, `recipient`, `thread_id` | Params: `channel`, `content` |
| channel enum: hardcoded `[cli, teams, outlook, github, ado]` | channel: dynamic from active channels |
| No broadcast | `channel='*'` broadcasts to all |
