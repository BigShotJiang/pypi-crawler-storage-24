# Shell Tool

> **Date**: 2026-03-08
> **Tool name**: `shell`
> **File**: `workpilot/agent/tools/shell.py`
> **Class**: `ShellTool`
> **Risk level**: medium
> **Approval**: auto
> **Tier**: core (always in function calling schema)

---

## 1. Description

```
Execute a shell command.
```

---

## 2. Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `command` | string | yes | — | The command to execute |
| `timeout` | integer | no | 600 | Timeout in seconds. 0 = background (return immediately) |
| `directory` | string | no | workspace root | Working directory (relative to workspace) |
| `shell` | string | no | auto | Shell to use: auto (OS default), bash, cmd, powershell, or a path |

### Shell resolution

| Value | Executable | Args |
|-------|-----------|------|
| `auto` | OS default (`create_subprocess_shell`) | — |
| `bash` | `bash` | `-c` |
| `cmd` | `cmd.exe` | `/c` |
| `powershell` | `pwsh` (fallback: `powershell`) | `-NoProfile -Command` |
| `/usr/bin/zsh` | resolved via `shutil.which` | `-c` |

### Timeout modes

| Value | Behavior |
|-------|----------|
| omitted | 600s (from `ToolMetadata.timeout`) |
| `1-600` | Custom timeout, capped at `ToolMetadata.timeout` |
| `0` | Background mode: return PID immediately, process runs until killed |

---

## 3. Execution Flow

```
shell(command="npm test", timeout=60, directory="frontend", shell="bash")
  │
  ├─ 1. Security check
  │    sandbox.check_command(command) → deny patterns
  │    → match → BLOCKED
  │    → pass → continue
  │
  ├─ 2. Resolve directory
  │    workspace / "frontend" → resolve()
  │    → outside workspace → BLOCKED
  │    → not a dir → Error
  │    → OK → use as cwd
  │
  ├─ 3. Resolve shell
  │    "auto" → create_subprocess_shell (OS default)
  │    "bash" → shutil.which("bash") → create_subprocess_exec(bash, -c, cmd)
  │    custom path → shutil.which(path) → create_subprocess_exec(path, -c, cmd)
  │
  ├─ 4. Background mode (timeout=0)
  │    → start process, track PID
  │    → return "Background process started: PID 12345"
  │    → max 3 concurrent background processes
  │
  ├─ 5. Execute (standard mode)
  │    ├─ streaming path (progress callback available):
  │    │    stdout readline → line-by-line push to user
  │    │    stderr read in parallel
  │    │    asyncio.wait_for(timeout)
  │    │
  │    └─ non-streaming path:
  │         proc.communicate()
  │         asyncio.wait_for(timeout)
  │
  ├─ 6. Timeout handling
  │    TimeoutError → proc.kill() → "Command timed out after Ns"
  │
  ├─ 7. Output processing
  │    stdout + stderr merged
  │    truncated to max_output_chars (default 50,000)
  │    exit code ≠ 0 → prepend "Exit code N"
  │
  └─ return output
```

---

## 4. Security

### Deny patterns (Layer 1 — Rule Engine)

Fast regex matching in `Sandbox.check_command()`. Configurable via
`tools.shell.deny_patterns` in `workpilot.yaml`.

Default deny patterns:
```
rm\s+-rf\s+/           # recursive delete root
:\(\)\s*\{             # fork bomb
\bformat\b.*[A-Z]:    # format drive (Windows)
\bshutdown\b           # shutdown
\breboot\b             # reboot
\bmkfs\b               # make filesystem
\bdd\b\s+if=.*/dev/   # dd from device
```

### Approval (Layer 2)

`approval: "auto"` — commands go through the Security Classifier
(fast LLM) which evaluates risk based on the security profile.
Low-risk tools bypass the classifier on `standard` profile.

### Post-execution hooks

- **Leak scan**: `redact_credentials()` on tool output (hooks/handlers.py)
- **Streaming redact**: progress callback redacts before sending to user
- **Audit**: command + exit code + duration logged

### TODO

- [ ] LLM-based output extraction (design doc v1 section 4) — use fast model
  to extract key info when output exceeds limit, instead of hard truncation
- [ ] Platform-aware deny patterns (Windows-only vs Unix-only)

---

## 5. Background Mode

When `timeout=0`:

| Feature | Status |
|---------|--------|
| Fire-and-forget | ✅ Implemented — returns PID immediately |
| Max concurrent | ✅ 3 (configurable via `_MAX_BACKGROUND`) |
| PID tracking | ✅ `_background` dict |
| Stop mechanism | ✅ `shell(command="kill {pid}")` |
| E-stop cleanup | ✅ `kill_all_background()` via `SECURITY_ESTOP` event |
| Session cleanup | ❌ TODO — kill all on session end |

---

## 6. Output

| Setting | Default | Source |
|---------|---------|--------|
| `max_output_chars` | 50,000 | `ShellConfig.max_output_chars` |
| Truncation | Hard truncate + `...(truncated)` | `shell.py:210` |
| Exit code | Prepended if ≠ 0 | `shell.py:214` |

---

## 7. Streaming

When a progress callback is available (channel supports streaming):

- stdout is read line-by-line via `readline()`
- Each line pushed to user in real-time via `StreamingChunk`
- stderr read in parallel via `read()`
- Both subject to `redact_credentials()`

---

## 8. Config

```yaml
tools:
  shell:
    timeout: 600              # default timeout (seconds)
    max_output_chars: 50000   # output truncation limit
    deny_patterns:            # extend default deny list
      - 'custom_pattern'
    allow_patterns:           # always-allow patterns
      - 'safe_script\.sh'
```
