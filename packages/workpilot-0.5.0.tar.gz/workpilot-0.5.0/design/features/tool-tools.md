# Tools Meta-Tool — Progressive Discovery & Management

> **Date**: 2026-03-07
> **Tool name**: `tools`
> **Risk level**: low
> **Approval**: never
> **Tier**: core (always in function calling schema)
> **Replaces**: `tool_info` + `mcp_connect`

---

## Overview

A single unified tool for discovering, inspecting, enabling, and managing both
built-in tools and MCP server connections. Implements **progressive loading** —
only core-tier tools appear in the function calling schema by default; standard-tier
tools must be explicitly enabled via this tool before the LLM can call them.

This design reduces schema token overhead by ~70% on the first LLM call
(~1,000 tokens for 8 core tools vs ~3,500 tokens for all 19+ tools).

---

## 1. Motivation

### Token cost of tool schemas

Every tool in the function calling schema consumes input tokens on **every**
LLM call. With 19+ tools, this costs ~3,500 tokens per turn — significant
for long conversations.

Most conversations only use 3–5 tools. Progressive loading defers the schema
cost of rarely-used tools until the LLM actually needs them.

### Unified discovery

Previously two separate tools handled discovery:

| Before | After |
|--------|-------|
| `tool_info()` — built-in tools | `tools()` — everything |
| `mcp_connect(server="icm")` — MCP servers | `tools(name="MCP_icm")` — MCP via prefix |

The `MCP_` prefix convention disambiguates: names starting with `MCP_` route
to MCP server logic, all others route to built-in tool logic.

---

## 2. Tool Tiers

| Tier | Behavior | Tools |
|------|----------|-------|
| **core** | Always in function calling schema | `tools`, `shell`, `read_file`, `write_file`, `edit_file`, `list_dir`, `search_files`, `notify` |
| **standard** | Must be enabled via `tools(name='...')` | `git`, `http_request`, `web_search`, `web_fetch`, `browser`, `spawn`, `cron`, `gh_copilot`, `gh_copilot_status`, `gh_copilot_models`, `claude_code`, `claude_code_status` |

Tier is declared in `ToolMetadata.tier` (`"core"` or `"standard"`).

Core tools auto-activate on registration. Standard tools are registered but
not included in `get_schemas()` until explicitly activated.

---

## 3. Parameters

```
tools(
    name: str       — Tool name or MCP server (prefix MCP_, e.g. 'MCP_icm').
                      Omit to list all.
    action: str     — enable (default) | disable | describe | status | resources | prompts
    query: str      — Filter keyword (describe), resource URI (resources),
                      or prompt name (prompts).
    arguments: dict — Prompt arguments (prompts action only).
)
```

### Action reference

| Action | Built-in tools | MCP servers |
|--------|---------------|-------------|
| `enable` (default) | Inspect details + params, activate in schema | Connect server (auto-describe if ≤5 tools) |
| `disable` | Remove from schema (core tools cannot be disabled) | Disconnect server, remove registered tools |
| `describe` | Same as enable (show full details) | List all tools + resources + prompts with signatures |
| `status` | N/A | Show server connection state |
| `resources` | N/A | Read an MCP resource by URI (via `query`) |
| `prompts` | N/A | Render an MCP prompt (via `query` + `arguments`) |

---

## 4. Behavior Matrix

| Call | Behavior |
|------|----------|
| `tools()` | List core (active) + standard (inactive) + MCP servers |
| `tools(name="browser")` | Built-in: show description + params + enable |
| `tools(name="git", action="disable")` | Built-in: remove from schema |
| `tools(name="MCP_icm")` | MCP: connect (auto-describe if ≤5 tools) |
| `tools(name="MCP_icm", action="describe")` | MCP: full tool signatures + resources + prompts |
| `tools(name="MCP_icm", action="describe", query="incident")` | MCP: filtered tool list |
| `tools(name="MCP_icm", action="disable")` | MCP: disconnect + unregister tools |
| `tools(name="MCP_icm", action="status")` | MCP: server state info |
| `tools(name="MCP_icm", action="resources", query="res://...")` | MCP: read resource |
| `tools(name="MCP_icm", action="prompts", query="triage", arguments={...})` | MCP: render prompt |

---

## 5. List Output Format

```
Built-in tools:
  tools                [active]   — Discover and enable tools
  shell                [active]   — Execute a shell command
  read_file            [active]   — Read file contents
  write_file           [active]   — Write content to a file
  edit_file            [active]   — Edit a file by replacing exact string
  list_dir             [active]   — List directory contents
  search_files         [active]   — Search by content or file name
  notify               [active]   — Push a notification to the user
  git                  [inactive] — Run a git command
  http_request         [inactive] — Make an HTTP API request
  web_search           [inactive] — Search the web
  web_fetch            [inactive] — Fetch a web page
  browser              [inactive] — Automate a browser
  spawn                [inactive] — Delegate a task to a sub-agent
  cron                 [inactive] — Manage scheduled jobs
  gh_copilot           [inactive] — Delegate coding task to Copilot
  gh_copilot_status    [inactive] — Check Copilot task status
  gh_copilot_models    [inactive] — List Copilot models
  claude_code          [inactive] — Delegate coding task to Claude Code
  claude_code_status   [inactive] — Check Claude Code task status

MCP servers:
  MCP_icm              [connected] (3 tools)  — Incident management
  MCP_kusto            [idle]                 — Kusto queries

Use tools(name='<name>') to enable a tool or connect an MCP server.
```

---

## 6. Architecture

```
ToolsTool
  ├─ ToolRegistry (built-in tool activation)
  │   ├─ _active: set[str]        — tools in function calling schema
  │   ├─ activate(name) → bool    — add to schema
  │   ├─ deactivate(name) → bool  — remove (core blocked)
  │   └─ get_schemas()            — only returns active tools
  │
  └─ MCPManager (MCP server lifecycle)  [optional]
      ├─ connect_server(name)
      ├─ describe_server(name, keyword)
      ├─ disconnect_server(name)
      ├─ read_resource(name, uri)
      ├─ get_prompt(name, prompt, arguments)
      └─ get_server_status(name)
```

### MCP_ prefix routing

```python
if name.startswith("MCP_"):
    server = name[len("MCP_"):]    # strip prefix
    → MCPManager path
else:
    → ToolRegistry path
```

---

## 7. System Prompt Integration

Inactive tools are summarized in the system prompt (not in the function calling
schema) to give the LLM awareness without schema cost:

```markdown
## Additional Tools

Use `tools(name='<name>')` to enable:

- git: Run a git command
- browser: Automate a browser
- spawn: Delegate a task to a sub-agent
...
```

This section is generated by `ToolRegistry.get_inactive_summary()` and injected
by `ContextBuilder` after the TOOLS.md section.

---

## 8. Token Budget

| Scenario | Schema tokens |
|----------|--------------|
| Before (all 20+ tools) | ~3,500+ |
| After (8 core only) | ~1,000 |
| After (all enabled) | ~3,000+ |
| Savings (default) | **~70%** |

---

## 9. Implementation Files

| File | Role |
|------|------|
| `workpilot/agent/tools/tools.py` | `ToolsTool` — unified meta-tool |
| `workpilot/agent/tools/base.py` | `ToolMetadata.tier` field |
| `workpilot/agent/tools/registry.py` | Activation tracking, `get_schemas()` filtering |
| `workpilot/agent/context.py` | Inject inactive tools summary into system prompt |
| `workpilot/agent/loop.py` | Pass `tool_registry` to `ContextBuilder` |
| `workpilot/runtime.py` | Register `ToolsTool` with registry + MCP manager |
| `workpilot/gateway/api_handlers.py` | `/api/tools` endpoint with tier/active/type fields |

---

## 10. Migration

| Before | After |
|--------|-------|
| `tool_info()` | `tools()` |
| `tool_info(tool="browser")` | `tools(name="browser")` |
| `tool_info(deactivate="cron")` | `tools(name="cron", action="disable")` |
| `mcp_connect()` | `tools()` |
| `mcp_connect(server="icm")` | `tools(name="MCP_icm")` |
| `mcp_connect(server="icm", action="describe")` | `tools(name="MCP_icm", action="describe")` |
| `mcp_connect(server="icm", action="disconnect")` | `tools(name="MCP_icm", action="disable")` |
| `mcp_connect(server="icm", action="resources", uri="...")` | `tools(name="MCP_icm", action="resources", query="...")` |
| `mcp_connect(server="icm", action="prompts", prompt="...", arguments={...})` | `tools(name="MCP_icm", action="prompts", query="...", arguments={...})` |
