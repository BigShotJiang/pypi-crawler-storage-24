# MCP Bridge — Redesign Spec

> **Status**: Draft v1
> **Date**: 2026-03-06
> **Scope**: Features 1,2,3,4,5,7,8 + Agency proxy pattern
> **Replaces**: core-infra.md § 8 (MCP Bridge)


---

## 1. Overview

WorkPilot acts as an **MCP Client** — consuming external tools, resources, and prompts from MCP servers. This redesign addresses 7 gaps in the current implementation plus the special requirement for Microsoft internal MCP servers proxied through Agency CLI.

### 1.1 Changes from Current Implementation

| # | Gap | Solution |
|---|-----|----------|
| 1 | Flat tool names → collision | **Server-namespaced tools**: `MCP_icm_get_incident`, `MCP_icm_list_incidents` |
| 2 | No reconnect on crash | **Health monitor + auto-reconnect** with exponential backoff |
| 3 | Hardcoded per-tool config | **Per-server config**: timeout, risk_level, approval, namespace |
| 4 | Tools only (no resources/prompts) | **Full MCP protocol**: resources/list, resources/read, prompts/list, prompts/get |
| 5 | No streaming | **Streaming tool results** via async generator |
| 7 | Hardcoded protocol version | **Protocol negotiation** with capability detection |
| 8 | No MCP server auth | **Bearer / OAuth** for HTTP transport; stdio servers handle auth internally |

### 1.2 Special Requirement: Agency Proxy

Microsoft internal MCP servers (ICM, ADO, EngHub, Kusto, etc.) require **Agency CLI** as a stdio proxy. Agency handles EntraID authentication and protocol bridging. Agency is just a regular stdio command — no special config field needed.

```
WorkPilot MCPClient
  → StdioTransport spawns `agency mcp icm`   (standard stdio — same as any other MCP server)
    → Agency CLI handles EntraID auth (MSAL token cache)
    → Agency proxies JSON-RPC to Microsoft internal MCP endpoint
    → Response flows back through stdio
```

Config is identical to any other stdio server — Agency is auto-detected by `command == "agency"`:

```yaml
icm:
  command: "agency"
  args: ["mcp", "icm"]
```

Agency-specific behavior (auto-install, auth check) is triggered by detecting `command == "agency"`, not by a separate config field. This keeps config format standard and unchanged.

---

## 2. Architecture

```
workpilot.yaml
  tools.mcp_servers:
    icm:   { command: agency, args: [mcp, icm] }   ← Agency (auto-detected)
    github: { command: npx, ... }                    ← Standard stdio
    api:   { url: https://..., ... }                 ← HTTP/SSE
         │
         ▼
┌─────────────────────────────────────────────────────────┐
│                  MCP Manager (NEW)                       │
│                                                          │
│  Connection Pool    Health Monitor    Config Registry     │
│  ┌─────────────┐   ┌─────────────┐   ┌──────────────┐  │
│  │ name→Client  │   │ ping loop   │   │ per-server:  │  │
│  │ state machine│   │ backoff     │   │  timeout     │  │
│  │ tool cache   │   │ reconnect   │   │  risk_level  │  │
│  └─────────────┘   └─────────────┘   │  approval    │  │
│                                       │  namespace   │  │
│                                       │  auth (HTTP) │  │
│                                       └──────────────┘  │
└─────────────┬───────────────────────────────────────────┘
              │
              ▼
┌─────────────────────────────────────────────────────────┐
│                  MCPClient (enhanced)                     │
│                                                          │
│  Protocol Negotiation    Capability Detection            │
│  ┌─────────────────┐    ┌──────────────────────────┐    │
│  │ version: latest │    │ tools? resources? prompts?│    │
│  │ fallback: 2024  │    │ streaming? logging?       │    │
│  └─────────────────┘    └──────────────────────────┘    │
│                                                          │
│  Methods:                                                │
│  - tools/list, tools/call (existing)                     │
│  - resources/list, resources/read (NEW)                  │
│  - prompts/list, prompts/get (NEW)                       │
│  - streaming tool results (NEW)                          │
│                                                          │
│  Transport: Stdio | HTTP/SSE                             │
│  Auth: None | Bearer token | OAuth (HTTP only)           │
└─────────────────────────────────────────────────────────┘
              │
              ▼
┌─────────────────────────────────────────────────────────┐
│              Tool Registry (namespaced)                   │
│                                                          │
│  MCP_icm_get_incident          → MCPToolAdapter (icm)        │
│  MCP_icm_list_incidents        → MCPToolAdapter (icm)        │
│  MCP_github_create_issue       → MCPToolAdapter (github)     │
│  shell                     → ShellTool (built-in)        │
│  read_file                 → ReadFileTool (built-in)     │
└─────────────────────────────────────────────────────────┘
```

---

## 3. Configuration

### 3.1 MCPServerConfig (enhanced schema)

Config format stays standard — same 4 fields as today (`command`, `args`, `url`, `env`) plus new optional per-server overrides. No special `provider` field — Agency servers are auto-detected by `command == "agency"`.

**Existing fields** (unchanged):

| Field | Type | Description |
|-------|------|-------------|
| `command` | `str?` | Executable for stdio transport |
| `args` | `list[str]` | Arguments for the subprocess |
| `url` | `str?` | URL for HTTP/SSE transport |
| `env` | `dict[str,str]` | Environment variables for subprocess |

**New optional fields**:

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `timeout` | `int?` | `None` (30s standard, 60s Agency) | Tool call timeout in seconds |
| `risk_level` | `low\|medium\|high` | `None` (medium) | Risk classification |
| `approval` | `never\|auto\|always` | `None` (profile default) | Approval level override |
| `namespace` | `str?` | `None` (uses server name) | Override namespace prefix |
| `auth` | `object` | `{type: none}` | Auth config (HTTP only) |

**Auth sub-config** (HTTP transport only — stdio servers handle auth internally):

| Field | Type | Description |
|-------|------|-------------|
| `type` | `none\|bearer\|oauth` | Auth mechanism |
| `token` | `SecretStr?` | Bearer token value |
| `token_env` | `str?` | Env var name for token |
| `client_id` | `str?` | OAuth client ID |
| `client_secret` | `SecretStr?` | OAuth client secret |
| `scopes` | `list[str]` | OAuth scopes |

**Agency auto-detection**: `is_agency` derived property — `True` when `command == "agency"`.

### 3.2 YAML Example

Config format is identical to today. Existing `workpilot.yaml` works unchanged — all new fields are optional with sensible defaults.

```yaml
tools:
  mcp_servers:
    # --- Agency CLI servers (auto-detected by command: "agency") ---
    icm:
      command: "agency"
      args: ["mcp", "icm"]
      timeout: 60                    # optional override

    # --- Standard stdio MCP servers ---
    github:
      command: "npx"
      args: ["-y", "@modelcontextprotocol/server-github"]
      env:
        GITHUB_TOKEN: "${GITHUB_TOKEN}"
      timeout: 30
      risk_level: medium

    # --- HTTP/SSE MCP servers ---
    custom-api:
      url: "https://mcp.internal.corp/api"
      auth:
        type: bearer
        token_env: "CUSTOM_MCP_TOKEN"
      timeout: 15
```

### 3.3 Agency Auto-Detection

Agency servers are recognized by `command == "agency"` — no config marker needed. When detected:

- **On connect**: check `agency` binary in PATH, warn if missing
- **On connect**: check `agency auth status`, warn if not authenticated
- **Default timeout**: 60s (Agency auth + proxy adds latency) vs 30s for standard servers
- **On health failure**: include "run `agency auth login`" in error message

### 3.4 Agency Auto-Discovery (CLI)

`workpilot mcp add-agency` behavior (unchanged):

1. Check `agency` binary → auto-install if missing
2. Run `agency mcp --help` → parse available servers
3. For each discovered server, write standard config (`command: "agency"`, `args: ["mcp", <name>]`)
4. Skip servers already configured
5. Write to `workpilot.yaml`

---

## 4. Server Namespace (Feature #1)

### 4.1 Naming Convention

All MCP tools are prefixed with their server name:

```
MCP_{server_name}_{tool_name}
```

Examples:
- `MCP_icm_get_incident_details_by_id`
- `MCP_icm_list_active_incidents`
- `MCP_github_create_issue`

### 4.2 Namespace Resolution

The namespace prefix defaults to the server name from config. The `namespace` config field allows overriding it:

```yaml
mcp_servers:
  my-long-server-name:
    command: "..."
    namespace: "short"    # tools registered as MCP_short_{tool_name}
```

### 4.3 Anti-Shadowing

Built-in PROTECTED_TOOLS remain unnamespaced. MCP tools always get a namespace prefix — they can never register as bare names. This eliminates collision detection between MCP and built-in tools entirely.

Cross-server collision is also eliminated — `MCP_icm_search` and `MCP_github_search` coexist naturally.

### 4.4 Progressive Loading (3-Step Discovery)

MCP tools use **progressive disclosure** to minimize context window consumption. LLM discovers and uses MCP through 3 steps:

**Step 1 — System Prompt (always present, minimal)**

System prompt 中只注入已连接 server 的 namespace + 一句话功能摘要（≤100 字符/server）：

```
MCP servers connected:
  icm — Incident management: query, create, update incidents
  kusto — Kusto query engine: run KQL queries on Azure Data Explorer
```

未连接的 server 仅通过 `tools()` 工具发现（不占 system prompt）。

**Step 2 — Describe (按需获取完整工具列表)**

当 LLM 判断需要某个 server 的工具时，先调用内部工具获取完整的工具说明：

```
tools(name="MCP_icm", action="describe")
→ Returns:
  MCP_icm_get_incident_details_by_id(incident_id: str) — Get full incident details
  MCP_icm_list_active_incidents(severity: int?, team: str?) — List active incidents with filters
  MCP_icm_create_incident(title: str, severity: int, ...) — Create a new incident
  MCP_icm_update_incident(incident_id: str, ...) — Update incident fields
  ...
```

LLM 读到完整参数签名后，才有足够信息构造正确的调用。

**Step 3 — Call (调用具体工具)**

LLM 用 Step 2 获取的参数信息，调用具体的 namespaced 工具：

```
MCP_icm_get_incident_details_by_id(incident_id="12345678")
```

**流程图：**

```
System Prompt                    LLM 决策                      工具调用
┌─────────────────┐      ┌──────────────────┐      ┌─────────────────────┐
│ icm — 一句话摘要 │ ──► │ 用户问了 incident │ ──► │ tools(MCP_icm,      │
│ (≤100 chars)    │      │ 需要 icm 的工具   │      │   action="describe")│
└─────────────────┘      └──────────────────┘      └─────────┬───────────┘
                                                              │
                                                    完整工具列表返回
                                                              │
                                                   ┌──────────▼──────────┐
                                                   │ MCP_icm_get_incident_   │
                                                   │   details_by_id(    │
                                                   │   incident_id=...)  │
                                                   └─────────────────────┘
```

**设计要点：**

- MCP 工具**不直接注册到 LLM 的 function calling schema** — 避免 15 个 server × 20 个工具 = 300 个工具定义撑爆 context
- System prompt 中每个 server 仅一行摘要（namespace + ≤100 字符描述）
- `describe` 返回完整签名后，工具才临时注入到当前轮次的 function calling schema
- 未连接的 server 通过 `tools()` 无参调用发现

---

## 5. Health Monitor & Auto-Reconnect (Feature #2)

### 5.1 Connection State Machine

```
          connect()
IDLE ──────────────► CONNECTING
                         │
                    fail │ success
                     │   ▼
                     │   CONNECTED ◄──── reconnect success
                     │       │
                     │       │ error / health fail
                     │       ▼
                     │   RECONNECTING ──► backoff wait
                     │       │
                     │       │ max retries exceeded
                     ▼       ▼
                   DISCONNECTED ───► FAILED
```

States: `idle`, `connecting`, `connected`, `reconnecting`, `disconnected`, `failed`

### 5.2 Health Check

- Periodically call `tools/list` (or `ping` if supported) with a 10s timeout
- Interval configurable per server (default 60s, Agency default 120s)
- On failure → transition to `reconnecting`

### 5.3 Auto-Reconnect

- Exponential backoff: delay = `backoff_base ^ attempt` seconds
- Max attempts configurable per server (default 5)
- On success: re-register all namespaced tools, emit `MCP_SERVER_RECONNECTED` event
- On max retries exceeded: transition to `failed`, emit `MCP_SERVER_FAILED` event

### 5.4 Failure Handling

On server failure:

1. Mark all tools from that server as unavailable (execute returns error message)
2. Log warning with server name and error
3. Start reconnect loop in background with exponential backoff
4. On successful reconnect, re-cache tools (available for next `describe` call)
5. On max retries exceeded, transition to `failed` state

---

## 6. Per-Server Configuration (Feature #3)

### 6.1 Config Resolution

Each MCPToolAdapter resolves its config from: server-level overrides → Agency defaults (if applicable) → global defaults.

| Config | Agency default | Standard default |
|--------|---------------|-----------------|
| `timeout` | 60s | 30s |
| `risk_level` | medium | medium |
| `approval` | auto | auto |
| `health_check_interval` | 120s | 60s |
| `max_reconnect_attempts` | 3 | 5 |

### 6.2 Approval Resolution Rule

**Server config can only tighten, never relax** the security profile.

Severity order: `never` < `auto` < `always`

| Profile | Profile default | Server `never` | Server `auto` | Server `always` |
|---------|----------------|----------------|---------------|-----------------|
| `open` | never | never | auto | always |
| `standard` | auto | **auto** (can't relax) | auto | always |
| `controlled` | auto | **auto** (can't relax) | auto | always |
| `restricted` | always | **always** (can't relax) | **always** (can't relax) | always |

---

## 7. Resources & Prompts (Feature #4)

### 7.1 MCP Resources

Resources are read-only data sources exposed by MCP servers (files, database rows, API responses). MCPClient adds `list_resources()` and `read_resource(uri)` methods.

LLM 通过 `tools` 的 `resources` action 访问：

- `tools(name="MCP_icm", action="describe")` → describe 输出中包含 Resources 列表
- `tools(name="MCP_icm", action="resources", uri="icm://schema")` → 读取资源内容

### 7.2 MCP Prompts

Prompts are parameterized templates exposed by MCP servers. MCPClient adds `list_prompts()` and `get_prompt(name, arguments)` methods.

LLM 通过 `tools` 的 `prompts` action 访问：

- `tools(name="MCP_icm", action="describe")` → describe 输出中包含 Prompts 列表
- `tools(name="MCP_icm", action="prompts", query="triage", arguments={"severity": "2"})` → 获取渲染后的提示词

### 7.3 Capability-Gated

Resources 和 prompts 的发现在 `describe` 输出中自动包含（如果 server 支持）。MCPClient 层面的能力检查：

- `list_resources()` / `list_prompts()` 在 server 不支持时返回空列表（检查 `"resources"/"prompts" in capabilities`）
- `describe` 输出仅在有可用资源/提示词时显示对应 section

---

## 8. Streaming Tool Results (Feature #5)

### 8.1 Behavior

For long-running MCP tool calls, support streaming partial results back to the agent/channel via async generator.

- MCPClient adds `call_tool_streaming()` returning an async generator of text chunks
- MCPToolAdapter exposes `execute_streaming()` when server supports streaming
- `metadata.streaming` set to `True` for servers that advertise streaming capability

### 8.2 Fallback

If the server doesn't support streaming, `execute_streaming()` falls back to a single-chunk yield of the full `execute()` result. The adapter auto-detects based on server capabilities.

---

## 9. Protocol Negotiation (Feature #7)

### 9.1 Version Negotiation

Supported versions (newest first): `2025-03-26`, `2024-11-05`

On connect, try the latest version first. If the server rejects it, fall back to the next version. Store the negotiated version and server capabilities.

### 9.2 Capability Detection

After connection, detect what the server supports from the `initialize` response:

| Capability | What it enables |
|------------|-----------------|
| `tools` | Tool discovery and invocation |
| `tools.listChanged` | Handle `notifications/tools/list_changed` |
| `tools.streaming` | Streaming tool results |
| `resources` | Resource listing and reading |
| `prompts` | Prompt listing and rendering |
| `logging` | Server-side log messages |

### 9.3 Tool Change Notifications

If server advertises `listChanged: true`, the receive loop handles `notifications/tools/list_changed` by re-discovering and re-registering tools under the same namespace.

---

## 10. MCP Server Authentication (Feature #8)

### 10.1 Auth Types

| Type | Use Case | Transport | Status |
|------|----------|-----------|--------|
| `none` | Local/trusted servers, **all stdio servers (including Agency)** | stdio + HTTP | ✅ 已实现 |
| `bearer` | Static API key / token | HTTP only | ✅ 已实现 |
| `oauth` | MCP OAuth 2.1 (Authorization Code + PKCE) | HTTP only | 🔲 见 [mcp-auth-oauth.md](mcp-auth-oauth.md) |

**Stdio servers handle auth internally** — Agency CLI manages EntraID auth transparently inside the subprocess. No `auth` config needed for stdio.

### 10.2 Agency Auth Check

When connecting a server with `command == "agency"`, MCPManager runs a pre-flight check:

1. Verify `agency` binary exists in PATH → if missing, return install instructions
2. Run `agency auth status` → if not authenticated, return "Run: `agency auth login`"
3. Proceed with standard stdio connection

This is transparent — the user writes standard config and WorkPilot handles the rest.

### 10.3 MCP OAuth 2.1 (Planned)

Full MCP-compliant OAuth 2.1 authorization flow for HTTP MCP servers. See [mcp-auth-oauth.md](mcp-auth-oauth.md) for detailed design:

- 401 → Protected Resource Metadata discovery → Auth Server Metadata discovery
- Authorization Code + PKCE (S256)
- Token cache + auto-refresh
- Scope step-up on 403
- Secure token storage (`~/.workpilot/mcp_tokens/`)

---

## 11. MCP Manager (New Orchestrator)

The `MCPManager` replaces the scattered MCP state in `Runtime` (`_mcp_clients`, `_connected_mcp`) with a centralized manager.

### 11.1 Responsibilities

| Area | Methods |
|------|---------|
| **Connection lifecycle** | `connect_server(name, force=False)`, `disconnect_server(name)`, `disconnect_all()` |
| **Progressive loading** | `describe_server(name, keyword=None)` — register tools + return signatures |
| **Discovery** | `list_servers()`, `get_connected_servers()`, `get_server_status(name)`, `get_client(name)` |
| **System prompt** | `build_system_prompt_summary()` — one-line-per-server for context injection |
| **Agency** | `agency_servers()` — list servers where `command == "agency"` |

Health monitor is managed internally (lazy-initialized on first connect). Resources and prompts are accessed via dedicated `mcp_resource` / `mcp_prompt` tools that use `get_client()` to access the MCPClient directly.

### 11.2 Connection Flow (connect_server)

1. If `force=True`: stop health monitor, disconnect old client, unregister old tools
2. Validate server name exists in config
3. Check state: skip if already connected (unless `force=True`)
4. If `command == "agency"` → pre-flight Agency auth check → warn if not authenticated (still attempt connection)
5. If HTTP transport → resolve auth headers (bearer/oauth)
6. Create MCPClient with command/args or url + auth headers
7. `client.connect()` → protocol negotiation (try latest version, fallback)
8. `list_tools()` → **缓存工具描述但不注册到 function calling schema**
9. Start health monitor for this server
10. If ≤5 tools → 自动调用 `describe_server()` 返回完整签名（省掉一轮 LLM 调用）
11. If >5 tools → 返回摘要（"Tools: N | Resources: yes"），提示调用 describe

**`describe` action 触发时（或 auto-describe）：**

12. 如果未连接 → 自动调用 `connect_server()`
13. 将缓存的工具注册到 ToolRegistry（namespace 前缀，per-server config）
14. 返回完整能力概览：tools 签名（支持 keyword 过滤）+ resources 列表 + prompts 列表

### 11.3 Tool Unregistration

When a server disconnects (crash, explicit disconnect, or health failure):

- Unregister all tools with that server's namespace prefix (requires `unregister_prefix(prefix)` on ToolRegistry)
- Close the client connection
- Update state to `disconnected`

---

## 12. Updated tools Tool

Enhanced with an `action` parameter:

| Action | Behavior |
|--------|----------|
| (no server) | List all configured servers with connection status |
| `connect` (default) | Connect server；≤5 个工具自动 describe，>5 返回摘要 |
| `describe` | 返回完整能力概览（tools + resources + prompts），自动连接 |
| `resources` | 带 `uri` 参数读取资源内容；不带则回退到 describe |
| `prompts` | 带 `prompt` + `arguments` 获取渲染后提示词；不带则回退到 describe |
| `disconnect` | Disconnect server, unregister tools |
| `status` | Show detailed server status |

**智能行为：**

- **describe 自动连接** — 未连接时自动 connect，省掉一轮
- **小 server 自动展开** — ≤5 个工具的 server，connect 时自动 describe（省掉 describe 步骤）
- **describe 包含全部能力** — tools 签名 + resources 列表 + prompts 列表一次返回

**`describe` 支持 `filter` 参数：**

- `tools(name="MCP_icm", action="describe")` → 返回全部工具签名 + resources + prompts
- `tools(name="MCP_icm", action="describe", query="incident")` → 仅返回名称或描述包含 "incident" 的工具

**Typical LLM call sequence（最优路径，2 轮）：**

1. `tools(name="MCP_icm", action="describe")` → 自动连接 + 完整签名 + 注册工具
2. `MCP_icm_get_incident_details_by_id(incident_id="123")` → 调用工具

**小 server 路径（2 轮）：**

1. `tools(name="MCP_calculator")` → 连接 + 自动 describe（≤5 工具）
2. `calculator.add(a=1, b=2)` → 调用工具

---

## 13. CLI Subcommands

See [cli-mcp.md](cli-mcp.md) for the full `workpilot mcp` CLI design.

---

## 14. Implementation Plan

### P0 — Foundation (must-have for first usable version)

| # | Task | What | Depends | Files |
|---|------|------|---------|-------|
| 0.1 | Types & config | `ConnectionState`, `MCPCapabilities`, `ServerInfo`; `MCPServerConfig` 新增 timeout/risk_level/approval/namespace/auth 字段 | — | types.py (new), config/schema.py |
| 0.2 | MCPManager 骨架 | 替代 Runtime 中散落的 `_mcp_clients`/`_connected_mcp`；`connect_server`, `disconnect_server`, `disconnect_all`, `list_servers` | 0.1 | manager.py (new), runtime.py |
| 0.3 | Namespace prefixing | `MCP_{server}_{tool}` 命名；adapter 接收 server_name；`ToolRegistry.unregister_prefix()` | 0.2 | adapter.py, registry.py |
| 0.4 | Per-server config | timeout/risk_level/approval 从 MCPServerConfig 解析，approval 只能收紧不能放松 | 0.1 | adapter.py, manager.py |
| 0.5 | Progressive loading | connect 时缓存工具描述不注册；system prompt 注入 one-line 摘要；`describe` action 返回完整签名并注入 function calling | 0.2, 0.3 | manager.py, tools.py |
| 0.6 | Agency auto-detect | `is_agency` 属性；connect 前检查 binary + auth status | 0.2 | auth.py (new) |
| 0.7 | 修复 security_profile bug | `_connect_mcp_server` 传递 security_profile 到 `register_mcp_tools` | — | runtime.py |
| 0.8 | 移除 server.py 公开导出 | MCPServer 从 `__init__.py` 移除，文件保留但不再是公开 API | — | __init__.py |

### P1 — Robustness

| # | Task | What | Depends | Files |
|---|------|------|---------|-------|
| 1.1 | Protocol negotiation | 尝试 `2025-03-26`，失败回退 `2024-11-05`；存储 server capabilities | 0.2 | client.py |
| 1.2 | Capability detection | 从 initialize 响应解析 tools/resources/prompts/streaming/listChanged | 1.1 | client.py, types.py |
| 1.3 | Health monitor | 定期 ping，状态机转换，失败标记工具不可用 | 0.2 | health.py (new), manager.py |
| 1.4 | Auto-reconnect | 指数退避重连，成功后重新缓存工具，发 Bus 事件 | 1.3 | health.py, manager.py |
| 1.5 | Tool change notifications | 处理 `notifications/tools/list_changed`，重新发现工具 | 1.2 | client.py |
| 1.6 | tools 工具增强 | `action` 参数: enable/disable/describe/status/resources/prompts | 0.5 | tools.py |
| 1.7 | CLI 增强 | `mcp list` 增强；新增 `mcp get`, `mcp add-json` | 0.2 | cli/commands.py |

### P2 — Full MCP Protocol

| # | Task | What | Depends | Files |
|---|------|------|---------|-------|
| 2.1 | Resources | `list_resources()`, `read_resource(uri)`；`tools` resources action | 1.2 | client.py, manager.py |
| 2.2 | Prompts | `list_prompts()`, `get_prompt(name)`；`tools` prompts action | 1.2 | client.py, manager.py |
| 2.3 | Streaming | `call_tool_streaming()` 异步生成器；adapter `execute_streaming()`；不支持时自动 fallback | 1.2 | client.py, adapter.py |

### P3 — Auth & Polish

| # | Task | What | Depends | Files |
|---|------|------|---------|-------|
| 3.1 | Bearer auth | Static token from config/env (已实现) | 0.1 | auth.py |
| 3.2 | describe filter | `keyword` 参数按关键词过滤工具列表 (已实现) | 0.5 | tools.py, manager.py |
| 3.3 | MCP OAuth 2.1 | 完整 MCP 合规 OAuth flow — 见 [mcp-auth-oauth.md](mcp-auth-oauth.md) | 0.1 | auth.py, transport.py, manager.py |

---

## 15. Migration

### 15.1 Config Compatibility

Existing `workpilot.yaml` works unchanged — all new fields are optional with defaults:
- `timeout` defaults to `None` (uses 60s for Agency, 30s for others)
- `namespace` defaults to `None` (uses server name as prefix)
- `auth` defaults to `none`
- Core fields (`command`, `args`, `url`, `env`) are unchanged

### 15.2 Tool Name Migration

**Breaking change**: tool names change from `get_incident_details_by_id` to `MCP_icm_get_incident_details_by_id`.

Mitigation:
- Agent instructions updated to reference namespaced names
- LLM naturally adapts since tool descriptions include `[MCP:icm]` prefix
- No code-level backwards compatibility needed (tools are dynamically discovered)

### 15.3 Agency Server Config

`workpilot mcp add-agency` output format is unchanged — standard config:

```yaml
icm:
  command: "agency"
  args: ["mcp", "icm"]
```

Agency auto-detection happens at runtime via `command == "agency"`, not at config time. No migration needed.

---

## 16. Testing Strategy

| Phase | Test Area | Approach |
|-------|-----------|----------|
| P0 | Namespace prefixing | Unit: verify `MCP_icm_tool_name` format; `unregister_prefix` cleanup |
| P0 | Per-server config | Unit: config resolution with overrides; approval 只能收紧 |
| P0 | Progressive loading | Unit: connect 不注册工具; describe 返回完整签名; system prompt 摘要 ≤100 chars |
| P0 | MCPManager lifecycle | Integration: connect/disconnect/disconnect_all |
| P0 | Agency auto-detect | Unit: mock `agency auth status`; `is_agency` property |
| P1 | Protocol negotiation | Unit: version fallback; capability parsing |
| P1 | Health monitor | Unit: state machine transitions; Integration: mock server crash + reconnect |
| P1 | Tool change notifications | Unit: mock `notifications/tools/list_changed` |
| P2 | Resources/Prompts | Unit: capability gating; mock server responses |
| P2 | Streaming | Unit: async generator; fallback to single-chunk |
| P3 | OAuth | Unit: token exchange mock |
