"""
Backwards-compatible facade for the ONEPDF_CORE feature.

The implementation lives in smaller modules to keep responsibilities clear.
"""

from pathlib import Path
import shutil
import uuid

from .utils import pdf_bytes_to_long_png

from .onepdf_pack import (
    DEFAULT_CORE_IGNORE_PATTERNS,
    PackedFile,
    collect_core_files,
    pack_repo_to_one_pdf,
)


def pack_repo_to_one_png(
    repo_root: Path,
    out_png: Path,
    png_dpi: int = 150,
    **kwargs,
):
    """Generate the exact onepdf layout, then render it to a single long PNG."""
    out_png = Path(out_png)
    out_png.parent.mkdir(parents=True, exist_ok=True)

    tmpdir = out_png.parent / f".pixrep_onepng_{uuid.uuid4().hex}"
    tmpdir.mkdir(parents=True, exist_ok=True)
    try:
        tmp_pdf = tmpdir / "ONEPDF_CORE.pdf"
        stats = pack_repo_to_one_pdf(
            repo_root=repo_root,
            out_pdf=tmp_pdf,
            **kwargs,
        )
        png_bytes = pdf_bytes_to_long_png(tmp_pdf.read_bytes(), dpi=png_dpi)
        out_png.write_bytes(png_bytes)
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)

    stats = dict(stats)
    stats["output_bytes"] = int(out_png.stat().st_size) if out_png.exists() else 0
    return stats

__all__ = [
    "DEFAULT_CORE_IGNORE_PATTERNS",
    "PackedFile",
    "collect_core_files",
    "pack_repo_to_one_pdf",
    "pack_repo_to_one_png",
]

