"""Schema introspection models."""

from __future__ import annotations

from ..base import SDKModel


class ColumnInfo(SDKModel):
    name: str
    data_type: str
    is_nullable: bool
    description: str | None = None


class TableInfo(SDKModel):
    schema_name: str
    table_name: str
    columns: list[ColumnInfo] = []
    row_count_estimate: int | None = None


class TableDescribeResponse(SDKModel):
    schema_name: str
    table_name: str
    columns: list[ColumnInfo] = []
    row_count_estimate: int | None = None


class Relationship(SDKModel):
    from_table: str
    from_column: str
    to_table: str
    to_column: str
    constraint_name: str | None = None


class QueryResponse(SDKModel):
    rows: list[dict] = []
    row_count: int
    columns: list[str] = []
    execution_time_ms: float
