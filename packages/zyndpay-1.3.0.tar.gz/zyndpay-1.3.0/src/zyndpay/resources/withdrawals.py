from typing import Optional


class Withdrawals:
    """Request and track withdrawals from your balance."""

    def __init__(self, client):
        self._client = client

    def create(
        self,
        amount: str,
        whitelist_address_id: str = None,
        idempotency_key: str = None,
    ) -> dict:
        """
        Request a withdrawal from your balance.

        Args:
            amount: Amount to withdraw in USDT, e.g. "100.00"
            whitelist_address_id: ID of whitelisted address to withdraw to (optional)
            idempotency_key: Unique key to prevent duplicate requests

        Returns:
            Withdrawal object with status, amount, etc.
        """
        body = {"amount": amount}
        if whitelist_address_id is not None:
            body["whitelistAddressId"] = whitelist_address_id

        res = self._client.post("/withdrawals", json=body, idempotency_key=idempotency_key)
        return res["data"]

    def get(self, withdrawal_id: str) -> dict:
        """Get a withdrawal by ID."""
        res = self._client.get(f"/withdrawals/{withdrawal_id}")
        return res["data"]

    def list(
        self,
        page: int = None,
        limit: int = None,
        status: str = None,
    ) -> dict:
        """
        List withdrawals with optional filters.

        Returns:
            Dict with "items" (list) and "total" (int).
        """
        res = self._client.get("/withdrawals", params={"page": page, "limit": limit, "status": status})
        return res["data"]

    def cancel(self, withdrawal_id: str) -> None:
        """Cancel a pending withdrawal."""
        self._client.delete(f"/withdrawals/{withdrawal_id}")
