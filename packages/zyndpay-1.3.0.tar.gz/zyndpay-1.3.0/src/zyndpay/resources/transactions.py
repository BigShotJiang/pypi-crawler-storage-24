from typing import Optional


class Transactions:
    """View transaction history."""

    def __init__(self, client):
        self._client = client

    def get(self, transaction_id: str) -> dict:
        """Get a transaction by ID."""
        res = self._client.get(f"/transactions/{transaction_id}")
        return res["data"]

    def list(
        self,
        page: int = None,
        limit: int = None,
        type: str = None,
        status: str = None,
        currency: str = None,
        chain: str = None,
        from_date: str = None,
        to_date: str = None,
        since: str = None,
    ) -> dict:
        """
        List transactions with optional filters.

        Args:
            type: Filter by type ("PAYIN", "PAYOUT", or "WITHDRAWAL")
            status: Filter by status
            currency: Filter by currency (e.g. "USDT_TRC20")
            chain: Filter by chain (e.g. "TRON")
            from_date: Start date (ISO 8601)
            to_date: End date (ISO 8601)
            since: Alternative to from_date (ISO 8601)

        Returns:
            Dict with "items", "total", "page", "limit", "totalPages".
        """
        res = self._client.get(
            "/transactions",
            params={
                "page": page,
                "limit": limit,
                "type": type,
                "status": status,
                "currency": currency,
                "chain": chain,
                "from_date": from_date,
                "to_date": to_date,
                "since": since,
            },
        )
        return res["data"]

    def export(
        self,
        type: str = None,
        status: str = None,
        currency: str = None,
        chain: str = None,
        from_date: str = None,
        to_date: str = None,
        since: str = None,
    ) -> str:
        """
        Export transactions as CSV.

        Args:
            type: Filter by type ("PAYIN", "PAYOUT", or "WITHDRAWAL")
            status: Filter by status
            currency: Filter by currency
            chain: Filter by chain
            from_date: Start date (ISO 8601)
            to_date: End date (ISO 8601)
            since: Alternative to from_date (ISO 8601)

        Returns:
            CSV content as string.
        """
        return self._client.get_raw(
            "/transactions/export",
            params={
                "type": type,
                "status": status,
                "currency": currency,
                "chain": chain,
                "from_date": from_date,
                "to_date": to_date,
                "since": since,
            },
        )
