import cv2
import pytest
from PIL import Image
from imagekit_python import SmartImage


with open("tests/images/1.jpg", "rb") as f:
    BYTES_IMAGE = f.read()

with open("tests/images/empty.jpg", "wb") as f:
    f.write(b"")

with open("tests/images/text.txt", "w") as f:
    f.write("HI")

with open("tests/images/text.txt", "rb") as f:
    INVALID_IMAGE = f.read()

with open("tests/images/empty.jpg", "rb") as f:
    EMPTY_IMAGE = f.read()

with open("tests/images/1.jpg", "rb") as f:
    VALID_IMAGE = f.read()

CV2_IMAGE = cv2.imread("tests/images/1.jpg")
PILLOW_IMAGE = Image.open("tests/images/1.jpg")


@pytest.fixture
def service():
    return SmartImage.from_bytes(BYTES_IMAGE)
