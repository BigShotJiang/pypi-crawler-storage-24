from imagekit_python import SmartImage

from sample import service


def test_crop_valid(service: SmartImage):
    h, w = service.shape[:2]
    bbox = (0, 0, w // 2, h // 2)
    service = service.crop(bbox)
    cropped = service.to_cv2()
    assert cropped.shape[0] <= h // 2 and cropped.shape[1] <= w // 2


def test_crop_invalid_bbox(service: SmartImage):
    h, w = service.shape[:2]
    bbox = (w, h, w // 2, h // 2)  # x1 > x2, y1 > y2
    cropped = SmartImage.crop_image(service.to_cv2(), bbox)
    assert cropped is None


def test_resize_width_only(service: SmartImage):
    new_width = 100
    service = service.resize(width=new_width)
    assert service.to_cv2().shape[1] == new_width  # width
    assert service.to_pillow().size[0] == new_width  # width
    # height should scale proportionally
    assert service._image.shape[0] > 0


def test_resize_height_only(service: SmartImage):
    new_height = 50
    service = service.resize(height=new_height)
    assert service.to_cv2().shape[0] == new_height  # height
    assert service.to_pillow().size[1] == new_height  # height
    # width should scale proportionally
    assert service.shape[1] > 0
