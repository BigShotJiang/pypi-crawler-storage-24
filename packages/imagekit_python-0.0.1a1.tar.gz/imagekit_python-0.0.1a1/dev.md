**To local install package while developing**
(Install package)
uv pip install .[dev] (Locally and also install the development dependencies)
uv pip install -e .[dev] (In editable mode and also install the development dependencies)
uv pip install -e .[dev,pytesseract] (In editable mode and also install the development and optional dependencies)

**How to publish package using uv**

[building-your-package](https://docs.astral.sh/uv/guides/package/#building-your-package)

[packaging-projects](https://packaging.python.org/en/latest/tutorials/packaging-projects/)

**Package stats**
[PyPiStats](https://pypistats.org)
uv run --python 3.9 pytest
uv run --python 3.10 pytest
... so on