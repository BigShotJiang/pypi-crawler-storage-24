"""
Main worker event loop.

Responsibilities:
  - Background heartbeat thread
  - Poll → pull image → run container → report result cycle
  - Rich console status logging
"""

import logging
import queue
import signal
import threading
import time

import docker
from rich.console import Console

from poly_hammer_worker.api_client import PortalClient
from poly_hammer_worker.docker_runner import (
    DockerRunError,
    InsufficientDiskError,
    ensure_image,
    get_free_disk_gb,
    run_inference_container,
)
from poly_hammer_worker.hardware import detect_hardware
from poly_hammer_worker.image_discovery import resolve_image_for_model

logger = logging.getLogger(__name__)

# Intervals (seconds)
HEARTBEAT_INTERVAL = 30  # well within the 60s backend timeout
POLL_BACKOFF_BASE = 5
POLL_BACKOFF_MAX = 30


def run_worker_loop(
    worker_key: str,
    portal_url: str,
    console: Console,
    auto_cleanup: bool = False,
    registry_url: str | None = None,
    detach: bool = False,
    service: str | None = None,
    disk_check_interval: int = 300,
) -> None:
    """Blocking top-level loop. Runs until SIGINT / SIGTERM.

    If *detach* is True the loop registers, displays settings, waits for
    one successful poll round, then exits cleanly.
    """
    from poly_hammer_worker.banner import print_banner
    from poly_hammer_worker.image_discovery import discover_local_images

    print_banner(console)

    # ---- Hardware detection ---------------------------------------------------
    hw = detect_hardware()
    cuda_version = hw.get("cuda_version")
    if not cuda_version:
        console.print(
            "[red bold]No CUDA version detected — cannot run GPU workers.[/red bold]"
        )
        raise SystemExit(1)

    console.print(
        f"  GPU:  {hw.get('gpu_model', 'unknown')}  ({hw.get('vram_gb', '?')} GB VRAM)"
    )
    console.print(f"  CUDA: {cuda_version}")
    console.print(
        f"  RAM:  {hw.get('ram_gb', '?')} GB  ({hw.get('cpu_cores', '?')} CPU cores)"
    )
    console.print(f"  Disk: {get_free_disk_gb():.1f} GB free")
    if auto_cleanup:
        console.print("  Auto-cleanup: [green]enabled[/green]")
    if registry_url:
        console.print(f"  Registry: {registry_url}")
    else:
        console.print("  Registry: [dim]local-only (no remote pull)[/dim]")
    if service:
        console.print(f"  Service:  {service}")
    console.print()

    # ---- Clients --------------------------------------------------------------
    portal = PortalClient(portal_url, worker_key)
    docker_client = docker.from_env()

    # ---- Image discovery (initial) -------------------------------------------
    available_images = discover_local_images(
        docker_client, host_cuda_version=cuda_version
    )
    if available_images:
        total_models = sum(len(img["models"]) for img in available_images)
        console.print(
            f"[green]Discovered {len(available_images)} image(s) with {total_models} model(s)[/green]"
        )
        for img in available_images:
            console.print(f"  {img['image_ref']}  service={img['service_id']}")
            for model in img["models"]:
                console.print(f"    - {model['model_id']}")
    else:
        console.print(
            "[yellow]No portal-compatible Docker images found locally[/yellow]"
        )

    if service:
        matching = [i for i in available_images if i["service_id"] == service]
        if not matching:
            console.print(
                f"[yellow bold]Warning: no local images match service '{service}'[/yellow bold]"
            )

    console.print()

    # ---- Shutdown flag --------------------------------------------------------
    shutdown = threading.Event()

    def _handle_signal(sig: int, _frame: object) -> None:
        if shutdown.is_set():
            # Second signal — force immediate exit
            console.print("\n[red bold]Forced exit[/red bold]")
            raise SystemExit(1)
        console.print(f"\n[yellow]Received signal {sig}, shutting down …[/yellow]")
        shutdown.set()

    signal.signal(signal.SIGINT, _handle_signal)
    signal.signal(signal.SIGTERM, _handle_signal)

    # ---- Heartbeat thread -----------------------------------------------------
    _last_disk_check: float = 0.0

    def _heartbeat_loop() -> None:
        nonlocal _last_disk_check, available_images
        while not shutdown.is_set():
            # Re-discover images on each heartbeat (cheap — Docker API list)
            available_images = discover_local_images(
                docker_client, host_cuda_version=cuda_version
            )

            # Throttled disk space check
            now = time.monotonic()
            disk_gb: float | None = None
            if now - _last_disk_check >= disk_check_interval:
                disk_gb = get_free_disk_gb()
                _last_disk_check = now

            try:
                portal.heartbeat(
                    hardware_info=hw,
                    available_images=available_images,
                    disk_free_gb=disk_gb,
                    assigned_service_id=service,
                )
                logger.info("Heartbeat sent")
            except Exception:
                logger.warning("Heartbeat failed", exc_info=True)
            shutdown.wait(HEARTBEAT_INTERVAL)

    hb_thread = threading.Thread(target=_heartbeat_loop, daemon=True, name="heartbeat")
    hb_thread.start()
    console.print("[green]Heartbeat started[/green]")

    # ---- Poll loop ------------------------------------------------------------
    backoff = POLL_BACKOFF_BASE
    console.print("[bold]Polling for jobs …[/bold]\n")

    while not shutdown.is_set():
        # Run poll in a daemon thread so Ctrl+C is never blocked by I/O
        poll_q: queue.Queue[tuple[str, object]] = queue.Queue()

        def _do_poll() -> None:
            try:
                poll_q.put(("ok", portal.poll_for_job()))
            except Exception as exc:
                poll_q.put(("error", exc))

        poll_thread = threading.Thread(target=_do_poll, daemon=True)
        poll_thread.start()

        # Main thread sleeps in short intervals so signals are handled fast
        while poll_thread.is_alive() and not shutdown.is_set():
            poll_thread.join(timeout=0.5)

        if shutdown.is_set():
            break

        tag, payload = poll_q.get_nowait()

        if tag == "error":
            logger.exception("Poll error", exc_info=payload)
            console.print(f"[red]Poll error — retrying in {backoff}s[/red]")
            shutdown.wait(backoff)
            backoff = min(backoff * 2, POLL_BACKOFF_MAX)
            continue

        job = payload

        if job is None:
            # Successful poll with no job available
            if detach:
                console.print("[green]Poll successful — detaching.[/green]")
                break
            shutdown.wait(POLL_BACKOFF_BASE)
            continue

        # Reset backoff on successful poll
        backoff = POLL_BACKOFF_BASE

        if detach:
            console.print("[green]Poll successful — detaching.[/green]")
            break

        job_id = str(job["job_id"])
        model_id = job.get("model_id", "unknown")
        console.print(
            f"\n[bold cyan]Job received:[/bold cyan] {job_id}  model={model_id}"
        )

        _execute_job(
            portal=portal,
            docker_client=docker_client,
            job=job,
            available_images=available_images,
            auto_cleanup=auto_cleanup,
            registry_url=registry_url,
            console=console,
        )

    # ---- Cleanup --------------------------------------------------------------
    console.print("\n[bold]Shutting down …[/bold]")
    portal.disconnect()
    portal.close()
    console.print("[green]Done.[/green]")


def _execute_job(
    portal: PortalClient,
    docker_client: docker.DockerClient,
    job: dict,
    available_images: list[dict],
    console: Console,
    auto_cleanup: bool = False,
    registry_url: str | None = None,
) -> None:
    """Ensure image (local-first, optional registry pull), run container, report outcome."""
    job_id = str(job["job_id"])
    model_id = job.get("model_id", "")

    image_ref = resolve_image_for_model(available_images, model_id)
    if not image_ref:
        portal.fail_job(
            job_id,
            f"No local Docker image found for model '{model_id}'. "
            "Build the appropriate image and restart the worker.",
            "NO_IMAGE",
        )
        console.print(f"[red]  No local image for model '{model_id}' — skipped[/red]")
        return

    start_time = time.monotonic()

    try:
        # ---- Ensure image available (local-first) -----------------------------
        ensure_image(
            docker_client,
            image_ref,
            auto_cleanup=auto_cleanup,
            registry_url=registry_url,
            on_status=lambda s: console.print(f"  [dim]{s}[/dim]"),
        )

        # ---- Run container ----------------------------------------------------
        container_logger = logging.getLogger(f"{__name__}.container")

        def _on_log(line: str) -> None:
            container_logger.info(line)
            console.print(f"  [dim]│ {line}[/dim]", highlight=False)

        result = run_inference_container(
            docker_client,
            image_ref,
            job_payload=job,
            on_progress=lambda p: _on_progress(portal, job_id, p, console),
            on_status=lambda s: console.print(f"  [dim]{s}[/dim]"),
            on_log=_on_log,
        )

        elapsed = time.monotonic() - start_time

        # ---- Report completion ------------------------------------------------
        portal.complete_job(
            job_id,
            elapsed_seconds=elapsed,
            result_url=result.get("result_url"),
            result_metadata=result.get("result_metadata"),
        )
        console.print(f"  [green]Completed in {elapsed:.1f}s[/green]")

    except InsufficientDiskError as e:
        console.print(f"  [red bold]{e}[/red bold]")
        portal.fail_job(job_id, str(e)[:2000], "INSUFFICIENT_DISK")

    except DockerRunError as e:
        elapsed = time.monotonic() - start_time
        console.print(
            f"  [red]Container error (exit {e.exit_code}): {e.stderr[:200]}[/red]"
        )
        portal.fail_job(job_id, str(e)[:2000])

    except Exception as e:
        elapsed = time.monotonic() - start_time
        logger.exception("Unexpected error running job %s", job_id)
        console.print(f"  [red]Error: {e}[/red]")
        portal.fail_job(job_id, f"Worker error: {e}"[:2000])


def _on_progress(
    portal: PortalClient, job_id: str, progress: float, console: Console
) -> None:
    """Forward container progress to the portal API."""
    pct = int(progress * 100)
    console.print(f"  Progress: {pct}%", highlight=False)
    portal.report_progress(job_id, progress)
