"""
ph-worker CLI — Poly Hammer self-hosted GPU worker agent.

Usage:
    ph-worker start --worker-key <key> --portal-url <url>
    ph-worker check-gpu
"""

from typing import Annotated

import typer
from rich.console import Console

console = Console()

app = typer.Typer(help="Poly Hammer self-hosted GPU worker agent.")


def version_callback(value: bool) -> None:
    if value:
        from importlib.metadata import version

        typer.echo(f"ph-worker {version('ph-worker')}")
        raise typer.Exit()


@app.callback()
def main(
    _version: Annotated[
        bool,
        typer.Option(
            "--version",
            callback=version_callback,
            is_eager=True,
            help="Show the version and exit.",
        ),
    ] = False,
) -> None:
    pass


@app.command()
def start(
    worker_key: Annotated[
        str,
        typer.Option(
            envvar="PH_WORKER_KEY",
            help="Worker API key (ph_worker_...). Can also be set via PH_WORKER_KEY env var.",
        ),
    ],
    portal_url: Annotated[
        str,
        typer.Option(
            envvar="PH_PORTAL_URL",
            help="Poly Hammer Portal API base URL.",
        ),
    ] = "https://portal.polyhammer.com",
    auto_cleanup: Annotated[
        bool,
        typer.Option(
            "--auto-cleanup",
            envvar="PH_AUTO_CLEANUP",
            help="Automatically remove old worker images when disk space is low.",
        ),
    ] = False,
    registry: Annotated[
        str | None,
        typer.Option(
            envvar="PH_REGISTRY_URL",
            help="Optional container registry URL to pull images from if not found locally.",
        ),
    ] = None,
    service: Annotated[
        str | None,
        typer.Option(
            "--service",
            "-s",
            envvar="PH_SERVICE",
            help="Service ID to assign this worker to (e.g. 'text_to_motion').",
        ),
    ] = None,
    disk_check_interval: Annotated[
        int,
        typer.Option(
            "--disk-check-interval",
            envvar="PH_DISK_CHECK_INTERVAL",
            help="Seconds between disk space checks (default 300).",
        ),
    ] = 300,
    detach: Annotated[
        bool,
        typer.Option(
            "--detach",
            help="Register, display settings, perform one successful poll, then exit.",
        ),
    ] = False,
) -> None:
    """Start the worker agent loop.

    The worker will:
    1. Detect local GPU/CUDA capabilities
    2. Discover portal-compatible Docker images via OCI labels
    3. Connect to the portal and send heartbeats (with images + disk info)
    4. Long-poll for inference jobs
    5. Use locally-built Docker images (or pull from --registry if set)
    6. Run inference and upload results
    """
    from poly_hammer_worker.logging_config import configure_logging
    from poly_hammer_worker.worker_loop import run_worker_loop

    log_file = configure_logging()
    console.print(f"  Logs: {log_file}\n")

    run_worker_loop(
        worker_key=worker_key,
        portal_url=portal_url,
        auto_cleanup=auto_cleanup,
        registry_url=registry,
        detach=detach,
        service=service,
        disk_check_interval=disk_check_interval,
        console=console,
    )


@app.command()
def check_gpu() -> None:
    """Detect and display local GPU/CUDA capabilities."""
    from poly_hammer_worker.hardware import detect_hardware

    info = detect_hardware()

    from poly_hammer_worker.banner import print_banner

    print_banner(console)
    console.print("[bold]GPU / Hardware Info[/bold]\n")
    console.print(f"  GPU Model:      {info.get('gpu_model', 'N/A')}")
    console.print(f"  VRAM:           {info.get('vram_gb', 'N/A')} GB")
    console.print(f"  CUDA Version:   {info.get('cuda_version', 'N/A')}")
    console.print(f"  CPU Cores:      {info.get('cpu_cores', 'N/A')}")
    console.print(f"  RAM:            {info.get('ram_gb', 'N/A')} GB")
    console.print(f"  Disk Free:      {info.get('disk_free_gb', 'N/A')} GB")

    cuda_version = info.get("cuda_version")
    if cuda_version:
        console.print(
            f"\n  [green]CUDA {cuda_version} detected — ready for self-hosted workers[/green]"
        )
    else:
        console.print(
            "\n  [red]No CUDA detected — self-hosted workers require an NVIDIA GPU[/red]"
        )

    console.print()


if __name__ == "__main__":
    app()
