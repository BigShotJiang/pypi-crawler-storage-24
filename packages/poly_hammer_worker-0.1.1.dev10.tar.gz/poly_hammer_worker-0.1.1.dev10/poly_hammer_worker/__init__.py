"""Poly Hammer self-hosted GPU worker agent."""
