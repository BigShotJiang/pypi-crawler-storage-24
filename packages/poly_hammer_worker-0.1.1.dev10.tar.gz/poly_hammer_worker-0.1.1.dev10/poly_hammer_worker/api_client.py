"""
HTTP client for the Poly Hammer Portal worker API.

All requests authenticate via the X-Worker-Key header.
"""

import logging
from typing import Any

import httpx

logger = logging.getLogger(__name__)

# Endpoints (relative to portal base URL)
_POLL_PATH = "/v1/worker-jobs/poll"
_COMPLETE_PATH = "/v1/worker-jobs/{job_id}/complete"
_FAIL_PATH = "/v1/worker-jobs/{job_id}/fail"
_PROGRESS_PATH = "/v1/worker-jobs/{job_id}/progress"
_HEARTBEAT_PATH = "/v1/worker-jobs/heartbeat"
_DISCONNECT_PATH = "/v1/worker-jobs/disconnect"


class PortalClient:
    """Thin HTTP wrapper around the worker-jobs API."""

    def __init__(self, portal_url: str, worker_key: str) -> None:
        self.base_url = portal_url.rstrip("/")
        self._headers = {"X-Worker-Key": worker_key}
        self._client = httpx.Client(
            base_url=self.base_url,
            headers=self._headers,
            timeout=httpx.Timeout(connect=10.0, read=60.0, write=30.0, pool=10.0),
        )

    def poll_for_job(self) -> dict | None:
        """Long-poll for a pending job. Returns job payload or None."""
        try:
            resp = self._client.get(_POLL_PATH)
            if resp.status_code == 204 or resp.status_code == 200 and not resp.text:
                return None
            resp.raise_for_status()
            return resp.json()
        except httpx.TimeoutException:
            # Normal — server held connection for poll timeout with no job
            return None
        except httpx.HTTPStatusError as e:
            logger.error("Poll failed: %s %s", e.response.status_code, e.response.text)
            raise

    def complete_job(
        self,
        job_id: str,
        elapsed_seconds: float,
        result_url: str | None = None,
        result_metadata: dict | None = None,
    ) -> None:
        """Report job completion."""
        body: dict[str, Any] = {"elapsed_seconds": elapsed_seconds}
        if result_url:
            body["result_url"] = result_url
        if result_metadata:
            body["result_metadata"] = result_metadata

        resp = self._client.post(
            _COMPLETE_PATH.format(job_id=job_id),
            json=body,
        )
        resp.raise_for_status()

    def fail_job(
        self,
        job_id: str,
        error_message: str,
        error_code: str = "INFERENCE_FAILED",
    ) -> None:
        """Report job failure."""
        resp = self._client.post(
            _FAIL_PATH.format(job_id=job_id),
            json={"error_message": error_message, "error_code": error_code},
        )
        resp.raise_for_status()

    def report_progress(self, job_id: str, progress: float) -> None:
        """Send a progress update (0.0–1.0)."""
        try:
            resp = self._client.post(
                _PROGRESS_PATH.format(job_id=job_id),
                json={"progress": progress},
            )
            resp.raise_for_status()
        except httpx.HTTPError:
            # Progress updates are best-effort
            logger.debug("Progress report failed (non-fatal)")

    def heartbeat(
        self,
        hardware_info: dict | None = None,
        available_images: list[dict] | None = None,
        disk_free_gb: float | None = None,
        assigned_service_id: str | None = None,
    ) -> None:
        """Send a heartbeat to keep the worker marked ONLINE."""
        body: dict[str, Any] = {}
        if hardware_info is not None:
            body["hardware_info"] = hardware_info
        if available_images is not None:
            body["available_images"] = available_images
        if disk_free_gb is not None:
            body["disk_free_gb"] = disk_free_gb
        if assigned_service_id is not None:
            body["assigned_service_id"] = assigned_service_id

        try:
            resp = self._client.post(_HEARTBEAT_PATH, json=body)
            resp.raise_for_status()
        except httpx.HTTPError:
            logger.warning("Heartbeat failed (will retry)")

    def disconnect(self) -> None:
        """Notify the portal that this worker is going offline."""
        try:
            resp = self._client.post(_DISCONNECT_PATH)
            resp.raise_for_status()
        except httpx.HTTPError:
            logger.warning("Disconnect notification failed (non-fatal)")

    def close(self) -> None:
        self._client.close()
