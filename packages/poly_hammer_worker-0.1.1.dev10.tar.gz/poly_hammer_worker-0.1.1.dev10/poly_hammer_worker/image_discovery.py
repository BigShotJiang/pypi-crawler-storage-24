"""
Docker image discovery for Poly Hammer Portal compatible images.

Scans local Docker images for ``ai.poly-hammer.*`` OCI labels and returns
structured metadata for each compatible image. Each image may contain
multiple models with independent hardware requirements, parsed from
per-model labels (``ai.poly-hammer.model.<id>.*``).

Required labels (image is skipped if any are missing):
  - ai.poly-hammer.portal-compatible = "true"
  - ai.poly-hammer.service-id
  - ai.poly-hammer.model-ids       (comma-separated model IDs)

Optional labels:
  - ai.poly-hammer.min-cuda-version   Minimum host CUDA version required.
        When set **and** *host_cuda_version* is passed to
        :func:`discover_local_images`, images whose minimum exceeds the
        host capability are skipped with a warning.

Per-model labels (optional, looked up for each model ID):
  - ai.poly-hammer.model.<id>.name
  - ai.poly-hammer.model.<id>.min-vram-gb
  - ai.poly-hammer.model.<id>.min-ram-gb
"""

import logging
from typing import Any

import docker

logger = logging.getLogger(__name__)

_PREFIX = "ai.poly-hammer."

_REQUIRED_LABELS = frozenset(
    {
        "portal-compatible",
        "service-id",
        "model-ids",
    }
)


def discover_local_images(
    client: docker.DockerClient,
    host_cuda_version: str | None = None,
) -> list[dict[str, Any]]:
    """Scan local Docker images for portal-compatible OCI labels.

    Returns a list of dicts matching the ``WorkerImageInfo`` schema — one
    entry per Docker image. Each entry contains a ``models`` list with
    per-model metadata (name, hardware requirements).

    If *host_cuda_version* is provided (e.g. ``"13.1"``), images whose
    ``ai.poly-hammer.min-cuda-version`` label exceeds it are skipped.
    """
    results: list[dict[str, Any]] = []

    try:
        images = client.images.list()
    except docker.errors.DockerException:
        logger.exception("Failed to list Docker images")
        return results

    for image in images:
        labels = image.labels or {}

        # Quick check: skip images without the portal-compatible flag
        if labels.get(f"{_PREFIX}portal-compatible") != "true":
            continue

        # Extract all ai.poly-hammer.* labels (strip prefix)
        ph_labels: dict[str, str] = {}
        for key, value in labels.items():
            if key.startswith(_PREFIX):
                ph_labels[key[len(_PREFIX) :]] = value

        # Validate required labels
        missing = _REQUIRED_LABELS - ph_labels.keys()
        if missing:
            tag = _best_tag(image)
            logger.warning(
                "Image %s has portal-compatible flag but missing required labels: %s",
                tag,
                ", ".join(sorted(missing)),
            )
            continue

        image_ref = _best_tag(image)
        service_id = ph_labels["service-id"]
        min_cuda_version: str | None = ph_labels.get("min-cuda-version")

        # Host compatibility check: skip images that need a newer CUDA
        if min_cuda_version and host_cuda_version:
            if _parse_version(min_cuda_version) > _parse_version(host_cuda_version):
                logger.warning(
                    "Image %s requires CUDA >= %s but host has %s — skipping",
                    image_ref,
                    min_cuda_version,
                    host_cuda_version,
                )
                continue

        # Image size in GB (Docker reports bytes)
        image_size_gb = round(image.attrs.get("Size", 0) / (1024**3), 2)

        # Parse comma-separated model IDs
        model_ids = [m.strip() for m in ph_labels["model-ids"].split(",") if m.strip()]

        # Build per-model metadata from ai.poly-hammer.model.<id>.* labels
        models: list[dict[str, Any]] = []
        for model_id in model_ids:
            model_prefix = f"model.{model_id}."
            model_name = ph_labels.get(f"{model_prefix}name")
            min_vram_gb = _parse_int(ph_labels.get(f"{model_prefix}min-vram-gb", "0"))
            min_ram_gb = _parse_int(ph_labels.get(f"{model_prefix}min-ram-gb", "0"))
            models.append(
                {
                    "model_id": model_id,
                    "model_name": model_name,
                    "min_vram_gb": min_vram_gb,
                    "min_ram_gb": min_ram_gb,
                }
            )

        results.append(
            {
                "image_ref": image_ref,
                "service_id": service_id,
                "min_cuda_version": min_cuda_version,
                "image_size_gb": image_size_gb,
                "models": models,
            }
        )

    total_models = sum(len(img["models"]) for img in results)
    logger.info(
        "Discovered %d portal-compatible image(s) with %d model(s)",
        len(results),
        total_models,
    )
    return results


def _best_tag(image: Any) -> str:
    """Return the most useful tag for an image, or fall back to short ID."""
    tags = image.tags
    if tags:
        return tags[0]
    short_id = image.short_id
    return short_id.replace("sha256:", "") if short_id else "<untagged>"


def _parse_int(value: str) -> int:
    """Parse an integer from a label value, defaulting to 0."""
    try:
        return int(value)
    except (ValueError, TypeError):
        return 0


def _parse_version(version: str) -> tuple[int, ...]:
    """Parse a dotted version string into a tuple of ints for comparison."""
    try:
        return tuple(int(p) for p in version.split("."))
    except (ValueError, TypeError):
        return (0,)


def resolve_image_for_model(
    available_images: list[dict[str, Any]], model_id: str
) -> str | None:
    """Find the local Docker image reference that supports a given model ID.

    Searches the list returned by :func:`discover_local_images` for the
    first image whose ``models`` list contains the requested *model_id*.

    Returns the ``image_ref`` (e.g. ``"hy-motion:1.0"``) or ``None`` if
    no matching image is found.
    """
    for img in available_images:
        for model in img.get("models", []):
            if model.get("model_id") == model_id:
                return img.get("image_ref")
    return None
