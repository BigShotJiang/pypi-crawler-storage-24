"""ドメインサービス"""

from .hook_manager import HookManager
from .file_convention_matcher import FileConventionMatcher
from .command_convention_matcher import CommandConventionMatcher
from .base_convention_matcher import BaseConventionMatcher
from .rule_suggester import RuleSuggester, PatternSuggestion
from .leader_detection import is_leader_tool_use
from .caller_role_service import get_caller_roles

__all__ = [
    'HookManager',
    'FileConventionMatcher',
    'CommandConventionMatcher',
    'BaseConventionMatcher',
    'RuleSuggester',
    'PatternSuggestion',
    'is_leader_tool_use',
    'get_caller_roles',
]
