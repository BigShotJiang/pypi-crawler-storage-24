from datetime import date, datetime
from pydantic.main import BaseModel
from typing import Optional


class CheckoutConfigurationCheckoutFlowModel(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    checkout_flow_id: Optional[str] = None
    checkout_configuration_id: Optional[str] = None
    is_default: Optional[bool] = None


CheckoutConfigurationCheckoutFlowModel.model_rebuild()
