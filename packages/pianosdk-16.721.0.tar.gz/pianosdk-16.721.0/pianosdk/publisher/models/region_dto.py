from datetime import date, datetime
from pydantic.main import BaseModel
from typing import Optional


class RegionDto(BaseModel):
    region_id: Optional[str] = None
    region_name: Optional[str] = None
    region_code: Optional[str] = None


RegionDto.model_rebuild()
