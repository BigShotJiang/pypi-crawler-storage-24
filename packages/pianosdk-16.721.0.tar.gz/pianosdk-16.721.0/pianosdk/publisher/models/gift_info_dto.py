from datetime import date, datetime
from pydantic.main import BaseModel
from typing import Optional
from pianosdk.publisher.models.user_access_dto import UserAccessDto
from pianosdk.publisher.models.user_address_api_dto import UserAddressApiDto
from pianosdk.publisher.models.user_dto import UserDto


class GiftInfoDto(BaseModel):
    gift_id: Optional[str] = None
    status: Optional[str] = None
    redeem_code: Optional[str] = None
    email: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    welcome_message: Optional[str] = None
    created: Optional[datetime] = None
    redeemed: Optional[datetime] = None
    user: Optional['UserDto'] = None
    subscription_id: Optional[str] = None
    user_access: Optional['UserAccessDto'] = None
    user_address: Optional['UserAddressApiDto'] = None


GiftInfoDto.model_rebuild()
