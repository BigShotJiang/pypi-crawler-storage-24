from pathlib import Path
from setuptools import setup, find_packages

this_dir = Path(__file__).parent
readme = (this_dir / "README.md").read_text(encoding="utf-8")

setup(
    name="turbolane-cli",
    version="2.0.0",
    description="RL-optimized parallel TCP file transfer CLI (TurboLane)",
    long_description=readme,
    long_description_content_type="text/markdown",
    packages=find_packages(exclude=["tests*"]),
    python_requires=">=3.10",
    install_requires=[],
    entry_points={
        "console_scripts": [
            "turbolane-server=turbolane_server.cli:main",
        ],
    },
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Science/Research",
        "Topic :: System :: Networking",
        "Programming Language :: Python :: 3.10",
    ],
)
