import json
from unittest.mock import MagicMock, patch

import pytest

from rastre.sdk import Oversight, Rastre


@pytest.fixture
def rastre():
    return Rastre(
        api_key="rk_test_123",
        audit_trail_id="trail-abc",
        ai_system="TestApp-v1.0",
        model="test-model",
        base_url="http://localhost:9999",
        anonymize_pii=False,
    )


def _mock_response(status=200):
    resp = MagicMock()
    resp.status = status
    resp.__enter__ = lambda s: s
    resp.__exit__ = MagicMock(return_value=False)
    return resp


def _captured_event(mock_urlopen) -> dict:
    request = mock_urlopen.call_args[0][0]
    return json.loads(request.data.decode())


@pytest.fixture
def mock_http():
    with patch("urllib.request.urlopen", return_value=_mock_response()) as m:
        yield m


class TestOutcomeEvent:
    def test_contains_all_fields(self, rastre, mock_http):
        rastre.log_outcome(
            correlation_id="req-001",
            input={"text": "hello"},
            output={"sentiment": "positive"},
            confidence=0.95,
            metadata={"lang": "en"},
        )

        event = _captured_event(mock_http)

        assert event["eventReference"] is not None
        assert event["timestamp"] is not None
        assert event["aiSystemVersion"] == "TestApp-v1.0"
        assert event["eventType"] == "transaction.outcome"
        assert event["correlationIdentifier"] == "req-001"
        assert event["confidenceLevel"] == 0.95
        assert event["model"] == "test-model"
        assert event["inputs"]["payload"]["text"] == "hello"
        assert event["outputs"]["payload"]["sentiment"] == "positive"
        assert event["metaData"]["lang"] == "en"

    def test_allows_model_override(self, rastre, mock_http):
        rastre.log_outcome(model="other-model-v2", output={"result": "ok"})

        event = _captured_event(mock_http)

        assert event["model"] == "other-model-v2"

    def test_omits_none_fields(self, rastre, mock_http):
        rastre.log_outcome()

        event = _captured_event(mock_http)

        assert "correlationIdentifier" not in event
        assert "inputs" not in event
        assert "outputs" not in event
        assert "confidenceLevel" not in event
        assert "metaData" not in event
        # Required fields are still present
        assert event["eventReference"] is not None
        assert event["timestamp"] is not None
        assert event["eventType"] == "transaction.outcome"


class TestInitiationEvent:
    def test_has_correct_type(self, rastre, mock_http):
        rastre.start_transaction(
            correlation_id="req-002",
            input="raw input text",
        )

        event = _captured_event(mock_http)

        assert event["eventType"] == "transaction.initiation"
        assert event["correlationIdentifier"] == "req-002"
        assert event["inputs"]["payload"] == "raw input text"


class TestOversightEvent:
    def test_contains_controller_and_action(self, rastre, mock_http):
        rastre.log_oversight(
            correlation_id="req-003",
            controller="reviewer-42",
            action=Oversight.VALIDATED_OUTPUT,
            reason="Confirmed classification before HR decision",
        )

        event = _captured_event(mock_http)

        assert event["eventType"] == "human.intervention"
        assert event["controllerReference"] == "reviewer-42"
        assert event["action"] == "VALIDATED_OUTPUT"
        assert event["reason"] == "Confirmed classification before HR decision"

    def test_uses_control_activities_type(self, rastre, mock_http):
        rastre.log_oversight(action=Oversight.ENGAGED_CONTROL)

        event = _captured_event(mock_http)

        assert event["eventType"] == "control.activity"


class TestFeedbackEvent:
    def test_contains_ground_truth(self, rastre, mock_http):
        rastre.log_feedback(
            correlation_id="req-004",
            ground_truth={"sentiment": "negative"},
            controller="reviewer-42",
        )

        event = _captured_event(mock_http)

        assert event["eventType"] == "transaction.feedback"
        assert event["controllerReference"] == "reviewer-42"
        assert event["groundTruth"]["payload"]["sentiment"] == "negative"


class TestHumanFeedbackEvent:
    def test_contains_all_fields(self, rastre, mock_http):
        rastre.log_human_feedback(
            correlation_id="req-006",
            controller="supervisor-7",
            user_identifier="user-42",
            metadata={"source": "review-portal"},
        )

        event = _captured_event(mock_http)

        assert event["eventType"] == "human.feedback"
        assert event["correlationIdentifier"] == "req-006"
        assert event["controllerReference"] == "supervisor-7"
        assert event["userIdentifier"] == "user-42"
        assert event["metaData"]["source"] == "review-portal"

    def test_omits_none_fields(self, rastre, mock_http):
        rastre.log_human_feedback()

        event = _captured_event(mock_http)

        assert event["eventType"] == "human.feedback"
        assert "controllerReference" not in event
        assert "userIdentifier" not in event
        assert "correlationIdentifier" not in event
        assert "metaData" not in event


class TestErrorEvent:
    def test_captures_exception(self, rastre, mock_http):
        ex = RuntimeError("model timeout")
        rastre.log_error(correlation_id="req-005", error=ex)

        event = _captured_event(mock_http)

        assert event["eventType"] == "software.error"
        assert event["error"]["type"] == "RuntimeError"
        assert event["error"]["message"] == "model timeout"
        assert "RuntimeError" in event["error"]["stackTrace"]

    def test_accepts_message_only(self, rastre, mock_http):
        rastre.log_error(message="inference pipeline failed")

        event = _captured_event(mock_http)

        assert event["error"]["message"] == "inference pipeline failed"
        assert "type" not in event["error"]
        assert "stackTrace" not in event["error"]


class TestJsonSerialization:
    def test_serializes_to_valid_json(self, rastre, mock_http):
        rastre.log_outcome(
            correlation_id="req-json",
            input={"text": "test input"},
            output={"category": "ok"},
            confidence=0.88,
            metadata={"anonymized": True},
        )

        request = mock_http.call_args[0][0]
        serialized = request.data.decode()

        assert serialized.startswith("{")
        assert serialized.endswith("}")
        assert '"eventType": "transaction.outcome"' in serialized
        assert '"correlationIdentifier": "req-json"' in serialized
        assert '"confidenceLevel": 0.88' in serialized
        assert '"anonymized": true' in serialized
