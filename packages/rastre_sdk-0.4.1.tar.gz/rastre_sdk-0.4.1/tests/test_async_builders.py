import json
from unittest.mock import AsyncMock, MagicMock

import httpx
import pytest

from rastre.sdk import AsyncRastre, Oversight


@pytest.fixture
def rastre():
    return AsyncRastre(
        api_key="rk_test_123",
        audit_trail_id="trail-abc",
        ai_system="TestApp-v1.0",
        model="test-model",
        base_url="http://localhost:9999",
        anonymize_pii=False,
    )


def _mock_response(status=200):
    resp = MagicMock(spec=httpx.Response)
    resp.status_code = status
    resp.raise_for_status = MagicMock()
    return resp


def _captured_event(mock_post) -> dict:
    kwargs = mock_post.call_args.kwargs
    return json.loads(kwargs["content"])


@pytest.fixture
def mock_http(rastre):
    mock_post = AsyncMock(return_value=_mock_response())
    rastre._http.post = mock_post
    return mock_post


class TestAsyncOutcomeEvent:
    async def test_contains_all_fields(self, rastre, mock_http):
        await rastre.log_outcome(
            correlation_id="req-001",
            input={"text": "hello"},
            output={"sentiment": "positive"},
            confidence=0.95,
            metadata={"lang": "en"},
        )

        event = _captured_event(mock_http)

        assert event["eventReference"] is not None
        assert event["timestamp"] is not None
        assert event["aiSystemVersion"] == "TestApp-v1.0"
        assert event["eventType"] == "transaction.outcome"
        assert event["correlationIdentifier"] == "req-001"
        assert event["confidenceLevel"] == 0.95
        assert event["model"] == "test-model"
        assert event["inputs"]["payload"]["text"] == "hello"
        assert event["outputs"]["payload"]["sentiment"] == "positive"
        assert event["metaData"]["lang"] == "en"

    async def test_omits_none_fields(self, rastre, mock_http):
        await rastre.log_outcome()

        event = _captured_event(mock_http)

        assert "correlationIdentifier" not in event
        assert "inputs" not in event
        assert "outputs" not in event
        assert "confidenceLevel" not in event
        assert "metaData" not in event

    async def test_allows_model_override(self, rastre, mock_http):
        await rastre.log_outcome(model="other-model-v2", output={"result": "ok"})

        event = _captured_event(mock_http)

        assert event["model"] == "other-model-v2"


class TestAsyncInitiationEvent:
    async def test_has_correct_type(self, rastre, mock_http):
        await rastre.start_transaction(
            correlation_id="req-002",
            input="raw input text",
        )

        event = _captured_event(mock_http)

        assert event["eventType"] == "transaction.initiation"
        assert event["correlationIdentifier"] == "req-002"
        assert event["inputs"]["payload"] == "raw input text"


class TestAsyncOversightEvent:
    async def test_contains_controller_and_action(self, rastre, mock_http):
        await rastre.log_oversight(
            correlation_id="req-003",
            controller="reviewer-42",
            action=Oversight.VALIDATED_OUTPUT,
            reason="Confirmed classification before HR decision",
        )

        event = _captured_event(mock_http)

        assert event["eventType"] == "human.intervention"
        assert event["controllerReference"] == "reviewer-42"
        assert event["action"] == "VALIDATED_OUTPUT"
        assert event["reason"] == "Confirmed classification before HR decision"


class TestAsyncFeedbackEvent:
    async def test_contains_ground_truth(self, rastre, mock_http):
        await rastre.log_feedback(
            correlation_id="req-004",
            ground_truth={"sentiment": "negative"},
            controller="reviewer-42",
        )

        event = _captured_event(mock_http)

        assert event["eventType"] == "transaction.feedback"
        assert event["controllerReference"] == "reviewer-42"
        assert event["groundTruth"]["payload"]["sentiment"] == "negative"


class TestAsyncHumanFeedbackEvent:
    async def test_contains_all_fields(self, rastre, mock_http):
        await rastre.log_human_feedback(
            correlation_id="req-006",
            controller="supervisor-7",
            user_identifier="user-42",
            metadata={"source": "review-portal"},
        )

        event = _captured_event(mock_http)

        assert event["eventType"] == "human.feedback"
        assert event["correlationIdentifier"] == "req-006"
        assert event["controllerReference"] == "supervisor-7"
        assert event["userIdentifier"] == "user-42"
        assert event["metaData"]["source"] == "review-portal"


class TestAsyncErrorEvent:
    async def test_captures_exception(self, rastre, mock_http):
        ex = RuntimeError("model timeout")
        await rastre.log_error(correlation_id="req-005", error=ex)

        event = _captured_event(mock_http)

        assert event["eventType"] == "software.error"
        assert event["error"]["type"] == "RuntimeError"
        assert event["error"]["message"] == "model timeout"
        assert "RuntimeError" in event["error"]["stackTrace"]

    async def test_accepts_message_only(self, rastre, mock_http):
        await rastre.log_error(message="inference pipeline failed")

        event = _captured_event(mock_http)

        assert event["error"]["message"] == "inference pipeline failed"
        assert "type" not in event["error"]
        assert "stackTrace" not in event["error"]


class TestAsyncTransaction:
    async def test_complete_sends_outcome(self, rastre, mock_http):
        tx = await rastre.start_transaction(correlation_id="req-tx")
        await tx.complete(output={"result": "ok"}, confidence=0.9)

        assert mock_http.call_count == 2
        outcome_event = json.loads(mock_http.call_args_list[1].kwargs["content"])
        assert outcome_event["eventType"] == "transaction.outcome"
        assert outcome_event["correlationIdentifier"] == "req-tx"
        assert outcome_event["confidenceLevel"] == 0.9


class TestAsyncContextManager:
    async def test_aclose_is_called_on_exit(self):
        async with AsyncRastre(api_key="rk_test_123", audit_trail_id="trail-abc") as rastre:
            assert rastre is not None
