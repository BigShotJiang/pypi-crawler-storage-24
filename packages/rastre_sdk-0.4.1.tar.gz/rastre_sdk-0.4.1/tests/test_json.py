import json


class TestJsonSerialization:
    def test_serializes_string_values(self):
        assert json.dumps({"name": "hello"}) == '{"name": "hello"}'

    def test_serializes_numbers(self):
        data = {"integer": 42, "decimal": 0.95}
        result = json.loads(json.dumps(data))
        assert result["integer"] == 42
        assert result["decimal"] == 0.95

    def test_serializes_booleans(self):
        assert json.dumps({"flag": True}) == '{"flag": true}'

    def test_serializes_null(self):
        assert json.dumps({"value": None}) == '{"value": null}'

    def test_serializes_nested_dicts(self):
        inner = {"id": "model-1", "version": "1.0"}
        outer = {"model": inner}
        result = json.loads(json.dumps(outer))
        assert result["model"]["id"] == "model-1"
        assert result["model"]["version"] == "1.0"

    def test_serializes_lists(self):
        data = {"tags": ["a", "b", "c"]}
        assert json.dumps(data) == '{"tags": ["a", "b", "c"]}'

    def test_serializes_mixed_type_lists(self):
        data = {"items": ["x", 1, True]}
        result = json.loads(json.dumps(data))
        assert result["items"] == ["x", 1, True]

    def test_escapes_special_characters(self):
        data = {"text": 'line1\nline2\ttab "quoted" back\\slash'}
        result = json.loads(json.dumps(data))
        assert result["text"] == 'line1\nline2\ttab "quoted" back\\slash'

    def test_serializes_empty_dict(self):
        assert json.dumps({}) == "{}"

    def test_matches_event_json_structure(self):
        outputs = {"sentimentCategory": "ok"}
        meta = {"anonymizationApplied": True, "inputLanguage": "en"}

        event = {
            "eventReference": "evt-123",
            "model": "sentiment-classifier-nn-v1.0.4",
            "eventType": "transaction.outcome",
            "confidenceLevel": 0.95,
            "outputs": {"payload": outputs},
            "metaData": meta,
        }

        serialized = json.dumps(event)

        assert '"eventReference": "evt-123"' in serialized
        assert '"model": "sentiment-classifier-nn-v1.0.4"' in serialized
        assert '"eventType": "transaction.outcome"' in serialized
        assert '"confidenceLevel": 0.95' in serialized
        assert '"anonymizationApplied": true' in serialized
