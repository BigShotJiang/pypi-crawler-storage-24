import json
from unittest.mock import MagicMock, patch

import pytest

from rastre.sdk import Rastre

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _mock_response(status=200):
    resp = MagicMock()
    resp.status = status
    resp.__enter__ = lambda s: s
    resp.__exit__ = MagicMock(return_value=False)
    return resp


def _captured_event(mock_urlopen) -> dict:
    request = mock_urlopen.call_args[0][0]
    return json.loads(request.data.decode())


def _make_presidio_mocks():
    """Return (mock_analyzer_engine, mock_anonymizer_engine, mock_result)."""
    mock_result = MagicMock()
    mock_result.text = "<REDACTED>"

    mock_analyzer = MagicMock()
    mock_analyzer.analyze.return_value = [MagicMock()]  # non-empty → PII found

    mock_anonymizer = MagicMock()
    mock_anonymizer.anonymize.return_value = mock_result

    return mock_analyzer, mock_anonymizer


# ---------------------------------------------------------------------------
# _pii module unit tests
# ---------------------------------------------------------------------------


class TestAnonymizeValue:
    def test_anonymizes_plain_string(self):
        mock_analyzer, mock_anonymizer = _make_presidio_mocks()
        with patch("rastre.sdk._pii._ensure_engines", return_value=(mock_analyzer, mock_anonymizer)):
            from rastre.sdk._pii import anonymize_value

            result = anonymize_value("John Doe, john@example.com")
        assert result == "<REDACTED>"

    def test_passes_through_non_string(self):
        mock_analyzer, mock_anonymizer = _make_presidio_mocks()
        with patch("rastre.sdk._pii._ensure_engines", return_value=(mock_analyzer, mock_anonymizer)):
            from rastre.sdk._pii import anonymize_value

            assert anonymize_value(42) == 42
            assert anonymize_value(3.14) == 3.14
            assert anonymize_value(True) is True
            assert anonymize_value(None) is None

    def test_recurses_into_dict(self):
        mock_analyzer, mock_anonymizer = _make_presidio_mocks()
        with patch("rastre.sdk._pii._ensure_engines", return_value=(mock_analyzer, mock_anonymizer)):
            from rastre.sdk._pii import anonymize_value

            result = anonymize_value({"name": "Alice", "score": 0.9})
        assert result["name"] == "<REDACTED>"
        assert result["score"] == 0.9

    def test_recurses_into_list(self):
        mock_analyzer, mock_anonymizer = _make_presidio_mocks()
        with patch("rastre.sdk._pii._ensure_engines", return_value=(mock_analyzer, mock_anonymizer)):
            from rastre.sdk._pii import anonymize_value

            result = anonymize_value(["Alice", 42, "Bob"])
        assert result == ["<REDACTED>", 42, "<REDACTED>"]

    def test_no_pii_returns_original_text(self):
        mock_analyzer = MagicMock()
        mock_analyzer.analyze.return_value = []  # empty → no PII
        mock_anonymizer = MagicMock()
        with patch("rastre.sdk._pii._ensure_engines", return_value=(mock_analyzer, mock_anonymizer)):
            from rastre.sdk._pii import anonymize_value

            result = anonymize_value("hello world")
        assert result == "hello world"
        mock_anonymizer.anonymize.assert_not_called()

    def test_import_error_with_helpful_message(self):
        import rastre.sdk._pii as pii_module

        original = pii_module._engines
        pii_module._engines = None
        try:
            with patch.dict("sys.modules", {"presidio_analyzer": None, "presidio_anonymizer": None}):
                with pytest.raises(ImportError, match="rastre-sdk\\[pii\\]"):
                    pii_module._get_engines()
        finally:
            pii_module._engines = original


# ---------------------------------------------------------------------------
# Integration: anonymize_pii=False (default) — no-op
# ---------------------------------------------------------------------------


class TestAnonymizePiiDisabled:
    @pytest.fixture
    def rastre(self):
        return Rastre(api_key="rk_test", audit_trail_id="trail-1", base_url="http://localhost", anonymize_pii=False)

    @pytest.fixture
    def mock_http(self):
        with patch("urllib.request.urlopen", return_value=_mock_response()) as m:
            yield m

    def test_log_outcome_passes_values_unchanged(self, rastre, mock_http):
        rastre.log_outcome(input="John Doe", output="approved")
        event = _captured_event(mock_http)
        assert event["inputs"]["payload"] == "John Doe"
        assert event["outputs"]["payload"] == "approved"

    def test_presidio_is_never_called(self, rastre, mock_http):
        with patch("rastre.sdk._client.anonymize_value") as mock_anon:
            rastre.log_outcome(input="sensitive data")
        mock_anon.assert_not_called()


# ---------------------------------------------------------------------------
# Integration: anonymize_pii=True — values are scrubbed
# ---------------------------------------------------------------------------


class TestAnonymizePiiEnabled:
    @pytest.fixture
    def mock_http(self):
        with patch("urllib.request.urlopen", return_value=_mock_response()) as m:
            yield m

    @pytest.fixture
    def mock_anon(self):
        with patch("rastre.sdk._client.anonymize_value", side_effect=lambda v: f"[{v}]") as m:
            yield m

    @pytest.fixture
    def rastre(self):
        return Rastre(api_key="rk_test", audit_trail_id="trail-1", base_url="http://localhost")

    def test_log_outcome_input_is_scrubbed(self, rastre, mock_http, mock_anon):
        rastre.log_outcome(input="John Doe", output="approved")
        event = _captured_event(mock_http)
        assert event["inputs"]["payload"] == "[John Doe]"
        assert event["outputs"]["payload"] == "[approved]"

    def test_start_transaction_input_is_scrubbed(self, rastre, mock_http, mock_anon):
        rastre.start_transaction(input="email@example.com")
        event = _captured_event(mock_http)
        assert event["inputs"]["payload"] == "[email@example.com]"

    def test_log_oversight_reason_is_scrubbed(self, rastre, mock_http, mock_anon):
        rastre.log_oversight(reason="Reviewer: Jane Smith")
        event = _captured_event(mock_http)
        assert event["reason"] == "[Reviewer: Jane Smith]"

    def test_log_feedback_ground_truth_is_scrubbed(self, rastre, mock_http, mock_anon):
        rastre.log_feedback(ground_truth={"label": "Alice"})
        event = _captured_event(mock_http)
        assert event["groundTruth"]["payload"] == "[{'label': 'Alice'}]"  # whole dict passed to mock

    def test_none_values_not_scrubbed(self, rastre, mock_http, mock_anon):
        rastre.log_outcome()  # all optional args default to None
        mock_anon.assert_not_called()
