import pytest

from rastre.sdk import AsyncRastre, Rastre


class TestClientConstruction:
    def test_raises_when_api_key_is_none(self):
        with pytest.raises(ValueError):
            Rastre(api_key=None, audit_trail_id="trail-1")

    def test_raises_when_api_key_is_blank(self):
        with pytest.raises(ValueError):
            Rastre(api_key="  ", audit_trail_id="trail-1")

    def test_raises_when_api_key_is_empty(self):
        with pytest.raises(ValueError):
            Rastre(api_key="", audit_trail_id="trail-1")

    def test_raises_when_audit_trail_id_is_none(self):
        with pytest.raises(ValueError):
            Rastre(api_key="key-1", audit_trail_id=None)

    def test_raises_when_audit_trail_id_is_blank(self):
        with pytest.raises(ValueError):
            Rastre(api_key="key-1", audit_trail_id="")

    def test_succeeds_with_required_fields(self):
        rastre = Rastre(api_key="rk_test_123", audit_trail_id="trail-abc")
        assert rastre is not None

    def test_succeeds_with_all_fields(self):
        rastre = Rastre(
            api_key="rk_test_123",
            audit_trail_id="trail-abc",
            ai_system="MyApp-v2.0",
            model="classifier-v1.0.4",
            base_url="http://localhost:8080",
        )
        assert rastre is not None
        assert rastre.ai_system == "MyApp-v2.0"
        assert rastre.model == "classifier-v1.0.4"


class TestAsyncClientConstruction:
    def test_raises_when_api_key_is_none(self):
        with pytest.raises(ValueError):
            AsyncRastre(api_key=None, audit_trail_id="trail-1")

    def test_raises_when_api_key_is_blank(self):
        with pytest.raises(ValueError):
            AsyncRastre(api_key="  ", audit_trail_id="trail-1")

    def test_raises_when_audit_trail_id_is_none(self):
        with pytest.raises(ValueError):
            AsyncRastre(api_key="key-1", audit_trail_id=None)

    def test_succeeds_with_required_fields(self):
        rastre = AsyncRastre(api_key="rk_test_123", audit_trail_id="trail-abc")
        assert rastre is not None

    def test_succeeds_with_all_fields(self):
        rastre = AsyncRastre(
            api_key="rk_test_123",
            audit_trail_id="trail-abc",
            ai_system="MyApp-v2.0",
            model="classifier-v1.0.4",
            base_url="http://localhost:8080",
        )
        assert rastre.ai_system == "MyApp-v2.0"
        assert rastre.model == "classifier-v1.0.4"
