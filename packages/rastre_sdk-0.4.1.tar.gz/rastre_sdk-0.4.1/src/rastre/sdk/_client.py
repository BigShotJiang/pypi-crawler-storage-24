from __future__ import annotations

import json
import traceback
import urllib.request
import uuid
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any

import httpx

from ._event_result import EventResult
from ._exception import RastreException
from ._oversight import Oversight
from ._pii import anonymize_value

if TYPE_CHECKING:
    from ._transaction import AsyncTransaction, Transaction

_DEFAULT_BASE_URL = "https://api.rastre.dev"


def _make_event(
    event_type: str,
    *,
    correlation_id: str | None,
    metadata: dict[str, Any] | None,
    model: str | None,
    ai_system: str | None,
) -> dict[str, Any]:
    event: dict[str, Any] = {
        "eventReference": str(uuid.uuid4()),
        "timestamp": datetime.now(timezone.utc).isoformat(timespec="milliseconds"),
        "eventType": event_type,
    }
    if ai_system is not None:
        event["aiSystemVersion"] = ai_system
    if model is not None:
        event["model"] = model
    if correlation_id is not None:
        event["correlationIdentifier"] = correlation_id
    if metadata is not None:
        event["metaData"] = metadata
    return event


class Rastre:
    """Synchronous client for the Rastre audit trail API.

    Create an instance directly::

        rastre = Rastre(api_key="rk_live_...", audit_trail_id="trail-uuid")
    """

    def __init__(
        self,
        api_key: str,
        audit_trail_id: str,
        *,
        ai_system: str | None = None,
        model: str | None = None,
        base_url: str = _DEFAULT_BASE_URL,
        anonymize_pii: bool = True,
    ) -> None:
        if not api_key or not api_key.strip():
            raise ValueError("api_key is required")
        if not audit_trail_id or not audit_trail_id.strip():
            raise ValueError("audit_trail_id is required")

        self._api_key = api_key
        self._audit_trail_id = audit_trail_id
        self.ai_system = ai_system
        self.model = model
        self._base_url = base_url
        self._anonymize_pii = anonymize_pii

    def _scrub(self, value: Any) -> Any:
        if self._anonymize_pii:
            return anonymize_value(value)
        return value

    def log_outcome(
        self,
        *,
        correlation_id: str | None = None,
        input: Any = None,
        output: Any = None,
        confidence: float | None = None,
        metadata: dict[str, Any] | None = None,
        model: str | None = None,
    ) -> EventResult:
        """Log a transaction outcome event."""
        event = _make_event(
            "transaction.outcome",
            correlation_id=correlation_id,
            metadata=metadata,
            model=model or self.model,
            ai_system=self.ai_system,
        )
        if input is not None:
            event["inputs"] = {"payload": self._scrub(input)}
        if output is not None:
            event["outputs"] = {"payload": self._scrub(output)}
        if confidence is not None:
            event["confidenceLevel"] = confidence
        return self._send_event(event)

    def start_transaction(
        self,
        *,
        input: Any = None,
        correlation_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        model: str | None = None,
    ) -> Transaction:
        """Start a transaction with an initiation event."""
        cid = correlation_id or str(uuid.uuid4())
        event = _make_event(
            "transaction.initiation",
            correlation_id=cid,
            metadata=metadata,
            model=model or self.model,
            ai_system=self.ai_system,
        )
        if input is not None:
            event["inputs"] = {"payload": self._scrub(input)}
        result = self._send_event(event)
        return Transaction(cid, result, self)

    def log_oversight(
        self,
        *,
        correlation_id: str | None = None,
        controller: str | None = None,
        action: Oversight | None = None,
        reason: str | None = None,
        metadata: dict[str, Any] | None = None,
        model: str | None = None,
    ) -> EventResult:
        """Log a human oversight event."""
        event_type = action.event_type if action is not None else "human.intervention"
        event = _make_event(
            event_type,
            correlation_id=correlation_id,
            metadata=metadata,
            model=model or self.model,
            ai_system=self.ai_system,
        )
        if controller is not None:
            event["controllerReference"] = controller
        if action is not None:
            event["action"] = action.name
        if reason is not None:
            event["reason"] = self._scrub(reason)
        return self._send_event(event)

    def log_feedback(
        self,
        *,
        correlation_id: str | None = None,
        ground_truth: Any = None,
        controller: str | None = None,
        metadata: dict[str, Any] | None = None,
        model: str | None = None,
    ) -> EventResult:
        """Log a feedback or ground truth event."""
        event = _make_event(
            "transaction.feedback",
            correlation_id=correlation_id,
            metadata=metadata,
            model=model or self.model,
            ai_system=self.ai_system,
        )
        if ground_truth is not None:
            event["groundTruth"] = {"payload": self._scrub(ground_truth)}
        if controller is not None:
            event["controllerReference"] = controller
        return self._send_event(event)

    def log_human_feedback(
        self,
        *,
        correlation_id: str | None = None,
        controller: str | None = None,
        user_identifier: str | None = None,
        metadata: dict[str, Any] | None = None,
        model: str | None = None,
    ) -> EventResult:
        """Log a human feedback event."""
        event = _make_event(
            "human.feedback",
            correlation_id=correlation_id,
            metadata=metadata,
            model=model or self.model,
            ai_system=self.ai_system,
        )
        if controller is not None:
            event["controllerReference"] = controller
        if user_identifier is not None:
            event["userIdentifier"] = user_identifier
        return self._send_event(event)

    def log_error(
        self,
        *,
        error: BaseException | None = None,
        message: str | None = None,
        correlation_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        model: str | None = None,
    ) -> EventResult:
        """Log a software error event."""
        event = _make_event(
            "software.error",
            correlation_id=correlation_id,
            metadata=metadata,
            model=model or self.model,
            ai_system=self.ai_system,
        )
        error_info: dict[str, Any] = {}
        if error is not None:
            error_info["type"] = type(error).__qualname__
            error_info["message"] = str(error)
            error_info["stackTrace"] = "".join(traceback.format_exception(error))
        elif message is not None:
            error_info["message"] = message
        if error_info:
            event["error"] = error_info
        return self._send_event(event)

    def _send_event(self, event: dict[str, Any]) -> EventResult:
        body = json.dumps(event).encode("utf-8")
        event_reference = event["eventReference"]
        url = f"{self._base_url}/trails/{self._audit_trail_id}/events"

        req = urllib.request.Request(
            url,
            data=body,
            headers={
                "x-api-key": self._api_key,
                "Content-Type": "application/json",
            },
            method="POST",
        )

        try:
            with urllib.request.urlopen(req) as response:
                status = response.status
                return EventResult(event_reference, status)
        except urllib.error.HTTPError as e:
            raise RastreException(
                f"API returned HTTP {e.code}: {e.read().decode('utf-8', errors='replace')}",
                e.code,
            ) from None
        except Exception as e:
            raise RastreException(f"Failed to send event: {e}") from e


class AsyncRastre:
    """Async client for the Rastre audit trail API.

    Use as an async context manager or call ``aclose()`` when done::

        async with AsyncRastre(api_key="rk_live_...", audit_trail_id="trail-uuid") as rastre:
            await rastre.log_outcome(output={"result": "ok"})
    """

    def __init__(
        self,
        api_key: str,
        audit_trail_id: str,
        *,
        ai_system: str | None = None,
        model: str | None = None,
        base_url: str = _DEFAULT_BASE_URL,
        anonymize_pii: bool = True,
    ) -> None:
        if not api_key or not api_key.strip():
            raise ValueError("api_key is required")
        if not audit_trail_id or not audit_trail_id.strip():
            raise ValueError("audit_trail_id is required")

        self._api_key = api_key
        self._audit_trail_id = audit_trail_id
        self.ai_system = ai_system
        self.model = model
        self._base_url = base_url
        self._anonymize_pii = anonymize_pii
        self._http = httpx.AsyncClient()

    def _scrub(self, value: Any) -> Any:
        if self._anonymize_pii:
            return anonymize_value(value)
        return value

    async def aclose(self) -> None:
        await self._http.aclose()

    async def __aenter__(self) -> AsyncRastre:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.aclose()

    async def log_outcome(
        self,
        *,
        correlation_id: str | None = None,
        input: Any = None,
        output: Any = None,
        confidence: float | None = None,
        metadata: dict[str, Any] | None = None,
        model: str | None = None,
    ) -> EventResult:
        """Log a transaction outcome event."""
        event = _make_event(
            "transaction.outcome",
            correlation_id=correlation_id,
            metadata=metadata,
            model=model or self.model,
            ai_system=self.ai_system,
        )
        if input is not None:
            event["inputs"] = {"payload": self._scrub(input)}
        if output is not None:
            event["outputs"] = {"payload": self._scrub(output)}
        if confidence is not None:
            event["confidenceLevel"] = confidence
        return await self._send_event(event)

    async def start_transaction(
        self,
        *,
        input: Any = None,
        correlation_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        model: str | None = None,
    ) -> AsyncTransaction:
        """Start a transaction with an initiation event."""
        cid = correlation_id or str(uuid.uuid4())
        event = _make_event(
            "transaction.initiation",
            correlation_id=cid,
            metadata=metadata,
            model=model or self.model,
            ai_system=self.ai_system,
        )
        if input is not None:
            event["inputs"] = {"payload": self._scrub(input)}
        result = await self._send_event(event)
        return AsyncTransaction(cid, result, self)

    async def log_oversight(
        self,
        *,
        correlation_id: str | None = None,
        controller: str | None = None,
        action: Oversight | None = None,
        reason: str | None = None,
        metadata: dict[str, Any] | None = None,
        model: str | None = None,
    ) -> EventResult:
        """Log a human oversight event."""
        event_type = action.event_type if action is not None else "human.intervention"
        event = _make_event(
            event_type,
            correlation_id=correlation_id,
            metadata=metadata,
            model=model or self.model,
            ai_system=self.ai_system,
        )
        if controller is not None:
            event["controllerReference"] = controller
        if action is not None:
            event["action"] = action.name
        if reason is not None:
            event["reason"] = self._scrub(reason)
        return await self._send_event(event)

    async def log_feedback(
        self,
        *,
        correlation_id: str | None = None,
        ground_truth: Any = None,
        controller: str | None = None,
        metadata: dict[str, Any] | None = None,
        model: str | None = None,
    ) -> EventResult:
        """Log a feedback or ground truth event."""
        event = _make_event(
            "transaction.feedback",
            correlation_id=correlation_id,
            metadata=metadata,
            model=model or self.model,
            ai_system=self.ai_system,
        )
        if ground_truth is not None:
            event["groundTruth"] = {"payload": self._scrub(ground_truth)}
        if controller is not None:
            event["controllerReference"] = controller
        return await self._send_event(event)

    async def log_human_feedback(
        self,
        *,
        correlation_id: str | None = None,
        controller: str | None = None,
        user_identifier: str | None = None,
        metadata: dict[str, Any] | None = None,
        model: str | None = None,
    ) -> EventResult:
        """Log a human feedback event."""
        event = _make_event(
            "human.feedback",
            correlation_id=correlation_id,
            metadata=metadata,
            model=model or self.model,
            ai_system=self.ai_system,
        )
        if controller is not None:
            event["controllerReference"] = controller
        if user_identifier is not None:
            event["userIdentifier"] = user_identifier
        return await self._send_event(event)

    async def log_error(
        self,
        *,
        error: BaseException | None = None,
        message: str | None = None,
        correlation_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        model: str | None = None,
    ) -> EventResult:
        """Log a software error event."""
        event = _make_event(
            "software.error",
            correlation_id=correlation_id,
            metadata=metadata,
            model=model or self.model,
            ai_system=self.ai_system,
        )
        error_info: dict[str, Any] = {}
        if error is not None:
            error_info["type"] = type(error).__qualname__
            error_info["message"] = str(error)
            error_info["stackTrace"] = "".join(traceback.format_exception(error))
        elif message is not None:
            error_info["message"] = message
        if error_info:
            event["error"] = error_info
        return await self._send_event(event)

    async def _send_event(self, event: dict[str, Any]) -> EventResult:
        body = json.dumps(event).encode("utf-8")
        url = f"{self._base_url}/trails/{self._audit_trail_id}/events"
        try:
            response = await self._http.post(
                url,
                content=body,
                headers={
                    "x-api-key": self._api_key,
                    "Content-Type": "application/json",
                },
            )
            response.raise_for_status()
            return EventResult(event["eventReference"], response.status_code)
        except httpx.HTTPStatusError as e:
            raise RastreException(
                f"API returned HTTP {e.response.status_code}: {e.response.text}",
                e.response.status_code,
            ) from None
        except Exception as e:
            raise RastreException(f"Failed to send event: {e}") from e


from ._transaction import AsyncTransaction, Transaction  # noqa: E402
