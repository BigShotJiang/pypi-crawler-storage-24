from dataclasses import dataclass


@dataclass(frozen=True)
class EventResult:
    """Result of sending an event to the Rastre API."""

    event_reference: str
    status_code: int
