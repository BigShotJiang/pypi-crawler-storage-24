from enum import Enum


class Oversight(Enum):
    """Human oversight actions for AI systems."""

    VALIDATED_OUTPUT = "human.intervention"
    INTERVENED = "human.intervention"
    ENGAGED_CONTROL = "control.activity"
    DISENGAGED_CONTROL = "control.activity"
    TRANSFERRED_CONTROL = "control.activity"

    @property
    def event_type(self) -> str:
        return self.value
