from __future__ import annotations

from typing import Any


def _get_engines() -> tuple[Any, Any]:
    try:
        from presidio_analyzer import AnalyzerEngine
        from presidio_anonymizer import AnonymizerEngine
    except ImportError as e:
        raise ImportError(
            "PII anonymization requires 'presidio-analyzer' and 'presidio-anonymizer'. "
            "Install them with: pip install 'rastre-sdk[pii]'\n"
            "A spaCy language model is also required: "
            "python -m spacy download en_core_web_lg"
        ) from e
    return AnalyzerEngine(), AnonymizerEngine()


_engines: tuple[Any, Any] | None = None


def _ensure_engines() -> tuple[Any, Any]:
    global _engines
    if _engines is None:
        _engines = _get_engines()
    return _engines


def anonymize_text(text: str) -> str:
    analyzer, anonymizer = _ensure_engines()
    results = analyzer.analyze(text=text, language="en")
    if not results:
        return text
    return anonymizer.anonymize(text=text, analyzer_results=results).text


def anonymize_value(value: Any) -> Any:
    """Recursively anonymize PII in strings, dicts, and lists."""
    if isinstance(value, str):
        return anonymize_text(value)
    if isinstance(value, dict):
        return {k: anonymize_value(v) for k, v in value.items()}
    if isinstance(value, list):
        return [anonymize_value(item) for item in value]
    return value
