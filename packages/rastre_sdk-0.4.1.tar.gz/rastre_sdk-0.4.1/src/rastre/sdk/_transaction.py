from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ._event_result import EventResult

if TYPE_CHECKING:
    from ._client import AsyncRastre, Rastre


class Transaction:
    """Handle for an in-flight transaction started with an initiation event."""

    def __init__(
        self,
        correlation_id: str,
        initiation_result: EventResult,
        client: Rastre,
    ) -> None:
        self.correlation_id = correlation_id
        self.initiation_result = initiation_result
        self._client = client

    def complete(
        self,
        *,
        output: Any = None,
        confidence: float | None = None,
        metadata: dict[str, Any] | None = None,
        model: str | None = None,
    ) -> EventResult:
        """Complete this transaction with an outcome event."""
        return self._client.log_outcome(
            correlation_id=self.correlation_id,
            output=output,
            confidence=confidence,
            metadata=metadata,
            model=model,
        )


class AsyncTransaction:
    """Handle for an in-flight transaction started with an initiation event (async)."""

    def __init__(
        self,
        correlation_id: str,
        initiation_result: EventResult,
        client: AsyncRastre,
    ) -> None:
        self.correlation_id = correlation_id
        self.initiation_result = initiation_result
        self._client = client

    async def complete(
        self,
        *,
        output: Any = None,
        confidence: float | None = None,
        metadata: dict[str, Any] | None = None,
        model: str | None = None,
    ) -> EventResult:
        """Complete this transaction with an outcome event."""
        return await self._client.log_outcome(
            correlation_id=self.correlation_id,
            output=output,
            confidence=confidence,
            metadata=metadata,
            model=model,
        )
