class RastreException(Exception):
    """Exception raised when the Rastre API returns an error."""

    def __init__(self, message: str, status_code: int = 0) -> None:
        super().__init__(message)
        self.status_code = status_code
