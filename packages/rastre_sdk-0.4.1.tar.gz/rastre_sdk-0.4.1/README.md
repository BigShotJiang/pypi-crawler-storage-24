# Rastre SDK for Python

Python client for the [Rastre](https://rastre.dev) audit trail API.
Records AI system events following ISO/IEC 24970:2025 and the EU AI Act.

Requires Python 3.11 or higher.

## Setup

```python
from rastre import Rastre

rastre = Rastre(
    api_key="rk_live_...",
    audit_trail_id="trail-uuid",
    ai_system="MyApp-v1.0",
    model="sentiment-classifier-v1.0.4",
)
```

## Log a transaction outcome

The most common operation — record input, output, and confidence in one call:

```python
rastre.log_outcome(
    correlation_id="req-001",
    input={"text": "Great product, very satisfied"},
    output={"sentiment": "positive"},
    confidence=0.95,
)
```

## Start and complete a transaction

When you need to record the start and end of a transaction separately:

```python
tx = rastre.start_transaction(input={"text": "Analysing document..."})

# ... AI processing happens here ...

tx.complete(
    output={"category": "compliant"},
    confidence=0.91,
)
```

The SDK generates a correlation ID automatically and links both events.

## Log human oversight

Record when a human controller validates, intervenes, or takes control:

```python
from rastre import Oversight

rastre.log_oversight(
    correlation_id="req-001",
    controller="reviewer-42",
    action=Oversight.VALIDATED_OUTPUT,
    reason="Confirmed classification before HR decision",
)
```

## Log feedback

Record ground truth when the correct answer becomes known later:

```python
rastre.log_feedback(
    correlation_id="req-001",
    ground_truth={"sentiment": "negative"},
    controller="reviewer-42",
)
```

## Log errors

Capture exceptions or error messages:

```python
try:
    # AI inference
    ...
except Exception as e:
    rastre.log_error(correlation_id="req-001", error=e)
```

## Async

Use `AsyncRastre` for native async I/O (backed by [httpx](https://www.python-httpx.org)):

```python
from rastre import AsyncRastre

async with AsyncRastre(
    api_key="rk_live_...",
    audit_trail_id="trail-uuid",
    ai_system="MyApp-v1.0",
    model="sentiment-classifier-v1.0.4",
) as rastre:
    result = await rastre.log_outcome(output={"result": "ok"})
    print(f"Logged: {result.event_reference}")
```

All methods on `AsyncRastre` are coroutines — no `_async` suffix needed. The client can also be created without a context manager; call `await rastre.aclose()` when done.
