from __future__ import annotations

from airs_api_mgmt.config import ClientConfig
from airs_api_mgmt.sdk.asyncio import ApiException
from airs_api_mgmt.sdk.asyncio.api import DLPProfilesApi
from airs_api_mgmt.sdk.models import ArrayDlpProfileObject
from airs_api_mgmt.resources.asyncio.base_client import BaseClient
from airs_api_mgmt.exceptions import (
    MgmtSdkAPIError,
    MgmtSdkServerError,
    MgmtSdkClientError,
    MgmtSdkBaseError,
)
from airs_api_mgmt.utils import get_logger


class DLPProfilesAsync(BaseClient):
    """DLP Profile management class for handling DLP profile operations.

    This class provides methods to manage DLP profiles including retrieval
    of all DLP profiles for a TSG ID.
    """

    def __init__(self, config: ClientConfig):
        """Initialize DlpProfile with a ClientConfig instance.

        Args:
            config: ClientConfig instance with authentication credentials
        """
        super().__init__(config)
        self.logger = get_logger(__name__)
        self._api = DLPProfilesApi(self.api_client)

    async def retrieve_all_dlp_profiles(self) -> ArrayDlpProfileObject:
        """Retrieve all DLP profiles for the TSG ID.

        Returns:
            ArrayDlpProfileObject: An array of DLP profile objects with their metadata.

        Raises:
            MgmtSdkClientError: If DLP profile retrieval fails due to client error (4xx)
            MgmtSdkServerError: If DLP profile retrieval fails due to server error (5xx)
            MgmtSdkBaseError: If an unexpected error occurs
        """
        self.refresh_token_if_expired()
        try:
            self.logger.info(
                f"event={self.retrieve_all_dlp_profiles.__name__} Retrieving all DLP profiles"
            )
            response = await self._api.get_all_dlp_profiles_by_tsg_id()
            return response
        except ApiException as e:
            error_msg = f"Failed to retrieve DLP profiles: {e}"
            self.logger.error(
                f"event={self.retrieve_all_dlp_profiles.__name__} error={error_msg}"
            )

            status = getattr(e, "status", None)
            reason = getattr(e, "reason", None)
            body = getattr(e, "body", None)

            if status and 400 <= status < 500:
                raise MgmtSdkClientError(
                    reason or error_msg, status_code=status, response_body=body
                )
            elif status and status >= 500:
                raise MgmtSdkServerError(
                    reason or error_msg, status_code=status, response_body=body
                )
            else:
                raise MgmtSdkAPIError(error_msg)
        except Exception as e:
            error_msg = f"Unexpected error while retrieving DLP profiles: {e}"
            self.logger.error(
                f"event={self.retrieve_all_dlp_profiles.__name__} error={error_msg}"
            )
            raise MgmtSdkBaseError(error_msg)
