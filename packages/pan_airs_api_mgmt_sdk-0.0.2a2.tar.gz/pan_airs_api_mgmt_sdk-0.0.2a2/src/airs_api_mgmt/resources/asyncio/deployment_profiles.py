from __future__ import annotations

from airs_api_mgmt.config import ClientConfig
from airs_api_mgmt.sdk.asyncio import ApiException
from airs_api_mgmt.sdk.asyncio.api import DeploymentProfilesApi
from airs_api_mgmt.sdk.models import DeploymentProfilesObject
from airs_api_mgmt.resources.asyncio.base_client import BaseClient
from airs_api_mgmt.exceptions import (
    MgmtSdkAPIError,
    MgmtSdkServerError,
    MgmtSdkClientError,
    MgmtSdkBaseError,
)
from airs_api_mgmt.utils import get_logger


class DeploymentProfilesAsync(BaseClient):
    """Deployment Profile management class for handling deployment profile operations.

    This class provides methods to manage deployment profiles including retrieval
    of all deployment profiles for a TSG ID.
    """

    def __init__(self, config: ClientConfig):
        """Initialize DeploymentProfile with a ClientConfig instance.

        Args:
            config: ClientConfig instance with authentication credentials
        """
        super().__init__(config)
        self.logger = get_logger(__name__)
        self._api = DeploymentProfilesApi(self.api_client)

    async def retrieve_all_deployment_profiles(
        self, unactivated: bool = None
    ) -> DeploymentProfilesObject:
        """Retrieve all deployment profiles for the TSG ID.

        Args:
            unactivated: Optional flag to get available and unactivated Deployment Profiles.
                Also includes previously activated DP that do not have any associated apps or API keys.
                Defaults to None.

        Returns:
            DeploymentProfilesObject: A collection of deployment profile objects with their metadata.

        Raises:
            MgmtSdkClientError: If deployment profile retrieval fails due to client error (4xx)
            MgmtSdkServerError: If deployment profile retrieval fails due to server error (5xx)
            MgmtSdkBaseError: If an unexpected error occurs
        """
        self.refresh_token_if_expired()
        try:
            self.logger.info(
                f"event={self.retrieve_all_deployment_profiles.__name__} Retrieving all deployment profiles"
            )
            response = await self._api.get_deployment_profiles_by_tsg_id(
                unactivated=unactivated
            )
            return response
        except ApiException as e:
            error_msg = f"Failed to retrieve deployment profiles: {e}"
            self.logger.error(
                f"event={self.retrieve_all_deployment_profiles.__name__} error={error_msg}"
            )

            status = getattr(e, "status", None)
            reason = getattr(e, "reason", None)
            body = getattr(e, "body", None)

            if status and 400 <= status < 500:
                raise MgmtSdkClientError(
                    reason or error_msg, status_code=status, response_body=body
                )
            elif status and status >= 500:
                raise MgmtSdkServerError(
                    reason or error_msg, status_code=status, response_body=body
                )
            else:
                raise MgmtSdkAPIError(error_msg)
        except Exception as e:
            error_msg = f"Unexpected error while retrieving deployment profiles: {e}"
            self.logger.error(
                f"event={self.retrieve_all_deployment_profiles.__name__} error={error_msg}"
            )
            raise MgmtSdkBaseError(error_msg)
