from __future__ import annotations

import ast
import datetime as _datetime_mod
import operator
from collections.abc import Callable
from datetime import datetime
from types import CodeType
from typing import Any

_SAFE_BINOPS: dict[type, Callable[..., Any]] = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
}

_SAFE_UNARYOPS: dict[type, Callable[..., Any]] = {
    ast.UAdd: operator.pos,
    ast.USub: operator.neg,
    ast.Not: operator.not_,
}

_SAFE_CMPOPS: dict[type, Callable[..., Any]] = {
    ast.Eq: operator.eq,
    ast.NotEq: operator.ne,
    ast.Lt: operator.lt,
    ast.LtE: operator.le,
    ast.Gt: operator.gt,
    ast.GtE: operator.ge,
    ast.In: lambda a, b: a in b,
    ast.NotIn: lambda a, b: a not in b,
}

_SAFE_BOOLOPS: dict[type, Callable[..., Any]] = {
    ast.And: all,
    ast.Or: any,
}


def _safe_len(obj: Any) -> int:
    return len(obj) if obj is not None else 0


def _safe_count(obj: Any, item: Any) -> int:
    if obj is None:
        return 0
    return int(obj.count(item))


def _concat(*args: str) -> str:
    return "".join(str(a) for a in args)


def _join(sep: str, items: Any) -> str:
    if items is None:
        return ""
    return sep.join(str(i) for i in items)


def _substr(s: str, start: int, end: int | None = None) -> str:
    return str(s)[start:end]


def _replace(s: str, old: str, new: str) -> str:
    return str(s).replace(old, new)


def _year(dt: Any) -> int | None:
    return dt.year if isinstance(dt, datetime) else None


def _month(dt: Any) -> int | None:
    return dt.month if isinstance(dt, datetime) else None


def _day(dt: Any) -> int | None:
    return dt.day if isinstance(dt, datetime) else None


def _format_date(dt: Any, fmt: str = "%Y-%m-%d") -> str:
    if isinstance(dt, datetime):
        return dt.strftime(fmt)
    return str(dt) if dt is not None else ""


_SAFE_FUNCTIONS: dict[str, Any] = {
    "len": _safe_len,
    "count": _safe_count,
    "upper": lambda s: str(s).upper(),
    "lower": lambda s: str(s).lower(),
    "concat": _concat,
    "join": _join,
    "substr": _substr,
    "replace": _replace,
    "year": _year,
    "month": _month,
    "day": _day,
    "format_date": _format_date,
    "abs": abs,
    "str": str,
    "int": int,
}

_ALLOWED_NODES = (
    ast.Expression,
    ast.Constant,
    ast.Name,
    ast.Load,
    ast.BinOp,
    ast.UnaryOp,
    ast.Call,
    ast.IfExp,
    ast.Compare,
    ast.BoolOp,
    ast.Subscript,
    ast.Index,
    ast.Slice,
    ast.Tuple,
    ast.List,
)


def safe_eval(expr: str, variables: dict[str, Any]) -> Any:
    try:
        tree = ast.parse(expr, mode="eval")
    except SyntaxError as e:
        msg = f"Invalid expression: {e}"
        raise ValueError(msg) from e

    for node in ast.walk(tree):
        if not isinstance(
            node,
            _ALLOWED_NODES + tuple(_SAFE_BINOPS) + tuple(_SAFE_UNARYOPS) + tuple(_SAFE_CMPOPS) + tuple(_SAFE_BOOLOPS),
        ):
            if not isinstance(
                node,
                ast.Add
                | ast.Sub
                | ast.Mult
                | ast.Div
                | ast.FloorDiv
                | ast.Mod
                | ast.Pow
                | ast.UAdd
                | ast.USub
                | ast.Not
                | ast.Eq
                | ast.NotEq
                | ast.Lt
                | ast.LtE
                | ast.Gt
                | ast.GtE
                | ast.In
                | ast.NotIn
                | ast.And
                | ast.Or,
            ):
                msg = f"Disallowed expression node: {type(node).__name__}"
                raise ValueError(msg)

    return _eval_node(tree.body, variables)


def _eval_constant(node: ast.AST, _variables: dict[str, Any]) -> Any:
    return node.value  # type: ignore[attr-defined]


def _eval_name(node: ast.AST, variables: dict[str, Any]) -> Any:
    name = node.id  # type: ignore[attr-defined]
    if name in _SAFE_FUNCTIONS:
        return _SAFE_FUNCTIONS[name]
    if name in variables:
        return variables[name]
    raise ValueError(f"Unknown variable: {name}")


def _eval_binop(node: ast.BinOp, variables: dict[str, Any]) -> Any:
    left = _eval_node(node.left, variables)
    right = _eval_node(node.right, variables)
    op_fn = _SAFE_BINOPS.get(type(node.op))
    if op_fn is None:
        raise ValueError(f"Unsupported binary op: {type(node.op).__name__}")
    return op_fn(left, right)


def _eval_unaryop(node: ast.UnaryOp, variables: dict[str, Any]) -> Any:
    operand = _eval_node(node.operand, variables)
    unary_fn = _SAFE_UNARYOPS.get(type(node.op))
    if unary_fn is None:
        raise ValueError(f"Unsupported unary op: {type(node.op).__name__}")
    return unary_fn(operand)


def _eval_compare(node: ast.Compare, variables: dict[str, Any]) -> Any:
    left = _eval_node(node.left, variables)
    for op, comparator in zip(node.ops, node.comparators):
        right = _eval_node(comparator, variables)
        cmp_fn = _SAFE_CMPOPS.get(type(op))
        if cmp_fn is None:
            raise ValueError(f"Unsupported comparison: {type(op).__name__}")
        if not bool(cmp_fn(left, right)):
            return False
        left = right
    return True


def _eval_boolop(node: ast.BoolOp, variables: dict[str, Any]) -> Any:
    values = [_eval_node(v, variables) for v in node.values]
    bool_fn = _SAFE_BOOLOPS.get(type(node.op))
    if bool_fn is None:
        raise ValueError(f"Unsupported bool op: {type(node.op).__name__}")
    return bool_fn(values)


def _eval_call(node: ast.Call, variables: dict[str, Any]) -> Any:
    func = _eval_node(node.func, variables)
    if not callable(func):
        raise ValueError(f"Not callable: {func}")
    args = [_eval_node(a, variables) for a in node.args]
    return func(*args)


def _eval_ifexp(node: ast.IfExp, variables: dict[str, Any]) -> Any:
    test = _eval_node(node.test, variables)
    return _eval_node(node.body, variables) if test else _eval_node(node.orelse, variables)


def _eval_subscript(node: ast.Subscript, variables: dict[str, Any]) -> Any:
    value = _eval_node(node.value, variables)
    sl = node.slice
    if isinstance(sl, ast.Slice):
        lower = _eval_node(sl.lower, variables) if sl.lower else None
        upper = _eval_node(sl.upper, variables) if sl.upper else None
        step = _eval_node(sl.step, variables) if sl.step else None
        return value[lower:upper:step]
    return value[_eval_node(sl, variables)]


def _eval_sequence(node: ast.AST, variables: dict[str, Any]) -> Any:
    return [_eval_node(e, variables) for e in node.elts]  # type: ignore[attr-defined]


_NODE_HANDLERS: dict[type, Callable[..., Any]] = {
    ast.Constant: _eval_constant,
    ast.Name: _eval_name,
    ast.BinOp: _eval_binop,
    ast.UnaryOp: _eval_unaryop,
    ast.Compare: _eval_compare,
    ast.BoolOp: _eval_boolop,
    ast.Call: _eval_call,
    ast.IfExp: _eval_ifexp,
    ast.Subscript: _eval_subscript,
    ast.Tuple: _eval_sequence,
    ast.List: _eval_sequence,
}


def _eval_node(node: ast.AST, variables: dict[str, Any]) -> Any:
    handler = _NODE_HANDLERS.get(type(node))
    if handler is None:
        raise ValueError(f"Unsupported node type: {type(node).__name__}")
    return handler(node, variables)


_COMPILE_CACHE: dict[tuple[str, str], str | bytes | CodeType] = {}


def _cached_compile(expression: str, mode: str) -> str | bytes | CodeType:
    key = (expression, mode)
    compiled = _COMPILE_CACHE.get(key)
    if compiled is None:
        compiled = compile(expression, "<expr>", mode)
        _COMPILE_CACHE[key] = compiled
    return compiled


def python_eval(expression: str, context: dict[str, Any]) -> Any:
    """Evaluate arbitrary Python code with full builtins.

    Tries single-expression eval first. On SyntaxError falls back to exec
    mode where the code must assign to ``result``.
    """
    ns: dict[str, Any] = {"__builtins__": __builtins__, "datetime": _datetime_mod}
    ns.update(_SAFE_FUNCTIONS)
    ns.update(context)

    try:
        compiled = _cached_compile(expression, "eval")
        return eval(compiled, ns)  # noqa: S307
    except SyntaxError:
        compiled = _cached_compile(expression, "exec")
        exec(compiled, ns)  # noqa: S102
        if "result" not in ns:
            msg = "exec-mode code must assign to 'result'"
            raise ValueError(msg)
        return ns["result"]
