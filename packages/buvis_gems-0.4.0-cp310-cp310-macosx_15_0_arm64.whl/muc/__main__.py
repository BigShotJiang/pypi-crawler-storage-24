from __future__ import annotations

from muc.cli import cli

if __name__ == "__main__":
    cli()
