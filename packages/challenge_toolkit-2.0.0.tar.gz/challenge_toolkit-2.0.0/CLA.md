# indieopensource.com Tiny Contributor License Agreement 1.0.0

I, {{{contributor name}}}, give CTF Pilot permission to license my contributions on any terms they like.  I am giving them this license in order to make it possible for them to accept my contributions into their project.

***As far as the law allows, my contributions come as is, without any warranty or condition, and I will not be liable to anyone for any damages related to this software or this license, under any kind of legal claim.***
