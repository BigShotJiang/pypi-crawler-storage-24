from typing import TypedDict, Unpack

import httpx
import pytest
from pytest_mock import MockerFixture
from respx.router import MockRouter

from ffun.domain.entities import AbsoluteUrl, FeedUrl, UnknownUrl
from ffun.domain.urls import str_to_feed_url, url_to_host
from ffun.feeds_discoverer.domain import (
    _VISITED_URLS,
    _discover_adjust_url,
    _discover_check_candidate_links,
    _discover_check_parent_urls,
    _discover_create_soup,
    _discover_extract_feed_info,
    _discover_extract_feeds_for_reddit,
    _discover_extract_feeds_from_anchors,
    _discover_extract_feeds_from_links,
    _discover_load_url,
    _discover_stop_recursion,
    _discoverers,
    discover,
    visited_cache,
)
from ffun.feeds_discoverer.entities import Context, Discoverer, Result, Status


class _ContextParams(TypedDict, total=False):
    content: str | None
    depth: int
    candidate_urls: set[AbsoluteUrl]
    discoverers: list[Discoverer]


def build_context(url: str, **kwargs: Unpack[_ContextParams]) -> Context:
    prepered_url = str_to_feed_url(url)
    return Context(raw_url=UnknownUrl(url), url=prepered_url, host=url_to_host(prepered_url), **kwargs)


class TestDiscoverAdjustUrl:

    @pytest.mark.asyncio
    async def test_wrong_url(self) -> None:
        context = Context(raw_url=UnknownUrl("wrong_url"))

        new_context, result = await _discover_adjust_url(context)

        assert new_context == context
        assert result == Result(feeds=[], status=Status.incorrect_url)

    @pytest.mark.asyncio
    async def test_good_url(self) -> None:
        context = Context(raw_url=UnknownUrl("https://example.com?"))

        new_context, result = await _discover_adjust_url(context)

        assert new_context == context.replace(url=AbsoluteUrl("https://example.com"), host="example.com")
        assert result is None


class TestDiscoverLoadUrl:

    @pytest.mark.asyncio
    async def test_error(self, respx_mock: MockRouter) -> None:
        respx_mock.get("/test").mock(side_effect=httpx.ConnectTimeout("some message"))

        context = build_context("http://localhost/test")

        with visited_cache():
            new_context, result = await _discover_load_url(context)

            cache = _VISITED_URLS.get()
            assert cache is not None
            assert "http://localhost/test" in cache

        assert new_context == context
        assert result == Result(feeds=[], status=Status.cannot_access_url)

    @pytest.mark.asyncio
    async def test_success(self, respx_mock: MockRouter) -> None:
        expected_content = "test-response"

        mocked_response = httpx.Response(200, content=expected_content)

        respx_mock.get("/test").mock(return_value=mocked_response)

        context = build_context("http://localhost/test")

        with visited_cache():
            new_context, result = await _discover_load_url(context)

            cache = _VISITED_URLS.get()
            assert cache is not None
            assert "http://localhost/test" in cache

        assert new_context == context.replace(content=expected_content)
        assert result is None

    @pytest.mark.asyncio
    async def test_prevent_second_attempt(self, respx_mock: MockRouter) -> None:
        mock = respx_mock.get("/test").mock(return_value=httpx.Response(200, content="unused"))

        with visited_cache():
            cache = _VISITED_URLS.get()

            assert cache is not None

            cache.add(FeedUrl("http://localhost/test"))

            context = build_context("http://localhost/test")

            new_context, result = await _discover_load_url(context)

        assert not mock.called
        assert new_context == context
        assert result == Result(feeds=[], status=Status.no_feeds_found)


class TestDiscoverExtractFeedInfo:

    @pytest.mark.asyncio
    async def test_not_a_feed(self) -> None:
        context = build_context("http://localhost/test", content="some text content")

        new_context, result = await _discover_extract_feed_info(context)

        assert new_context == context
        assert result is None

    @pytest.mark.asyncio
    async def test_a_feed(self, raw_feed_content: str) -> None:

        context = build_context("http://localhost/test", content=raw_feed_content)

        new_context, result = await _discover_extract_feed_info(context)

        assert result is not None

        assert new_context == context

        assert result.status == Status.feeds_found
        assert len(result.feeds) == 1
        assert result.feeds[0].url == FeedUrl("http://localhost/test")


class TestDiscoverCreateSoup:

    @pytest.mark.xfail(reason="need to find a case when BeautifulSoup raises an exception")
    @pytest.mark.asyncio
    async def test_not_html(self) -> None:
        context = build_context("http://localhost/test", content="some text content")

        new_context, result = await _discover_create_soup(context)

        assert new_context == context
        assert result == Result(feeds=[], status=Status.not_html)

    @pytest.mark.asyncio
    async def test_html(self, raw_feed_content: str) -> None:
        context = build_context("http://localhost/test", content="<html></html>")

        new_context, result = await _discover_create_soup(context)

        assert new_context.soup is not None
        assert result is None


class TestDiscoverExtractFeedsFromLinks:

    @pytest.mark.asyncio
    async def test_no_links(self) -> None:
        intro_context = build_context(
            "http://localhost/test",
            content="<html></html>",
        )

        context, result = await _discover_create_soup(intro_context)

        new_context, result = await _discover_extract_feeds_from_links(context)

        assert new_context == context
        assert result is None

    @pytest.mark.asyncio
    async def test_links(self) -> None:
        # "author", "help", "icon", "license", "pingback", "search", "stylesheet"
        html = """
        <html>
          <head>
            <link href="http://localhost/feed1">

            <!-- ignore these -->
            <link rel="author" href="http://localhost/feed2">
            <link rel="help" href="http://localhost/feed3">
            <link rel="icon" href="http://localhost/feed4">
            <link rel="license" href="http://localhost/feed5">
            <link rel="pingback" href="http://localhost/feed6">
            <link rel="search" href="http://localhost/feed7">
            <link rel="stylesheet" href="http://localhost/feed8">

            <link rel="random-rel" href="http://localhost/feed9">
            <link rel="random-rel" href="/feed10">
            <link rel="random-rel" href="feed11">

            <link href="mailto:">
            <link href="mailto:me@example.com">
            <link href="javascript:void(0)">

            <link href="http://localhost/feed14.xml">
            <link href="http://localhost/feed15.wotff2">
         </head>
         <body>
           <link href="http://localhost/feed12">
           <a href="http://localhost/feed13"></a>
        </body>
        </html>
        """

        intro_context = build_context(
            "http://localhost/test/xxx",
            content=html,
        )

        context, result = await _discover_create_soup(intro_context)

        new_context, result = await _discover_extract_feeds_from_links(context)

        expected_links = {
            AbsoluteUrl("http://localhost/feed1"),
            AbsoluteUrl("http://localhost/feed9"),
            AbsoluteUrl("http://localhost/feed10"),
            AbsoluteUrl("http://localhost/test/feed11"),
            AbsoluteUrl("http://localhost/feed12"),
            AbsoluteUrl("http://localhost/feed14.xml"),
        }

        assert new_context == context.replace(candidate_urls=expected_links)
        assert result is None


class TestDiscoverExtractFeedsFromAnchors:

    @pytest.mark.asyncio
    async def test_no_anchorts(self) -> None:
        intro_context = build_context(
            "http://localhost/test",
            content="<html></html>",
        )

        context, result = await _discover_create_soup(intro_context)

        new_context, result = await _discover_extract_feeds_from_anchors(context)

        assert new_context == context
        assert result is None

    @pytest.mark.asyncio
    async def test_has_anchors(self) -> None:

        html = """
        <html>
          <head>
            <link href="http://localhost/feed1">
         </head>
         <body>
           <a href="http://localhost/feed2"></a>
           <a href="feed3"></a>
           <a href="/feed4"></a>
           <a href="http://localhost/feed.5.xml"></a>
           <a href="http://localhost/feed.6.rss"></a>
           <a href="http://localhost/feed.7.atom"></a>
           <a href="http://localhost/feed.8.rdf"></a>
           <a href="http://localhost/feed.9.feed"></a>
           <a href="http://localhost/feed.10.php"></a>
           <a href="http://localhost/feed.11.asp"></a>
           <a href="http://localhost/feed.12.aspx"></a>
           <a href="http://localhost/feed.13.json"></a>
           <a href="http://localhost/feed.14.cgi"></a>
           <a href="http://localhost/feed.15.html"></a>
           <a href="mailto:"></a>
           <a href="mailto:me@example.com"></a>
           <a href="javascript:void(0)"></a>
         </body>
        </html>
        """

        intro_context = context = build_context(
            "http://localhost/test/xxx",
            content=html,
        )

        context, result = await _discover_create_soup(intro_context)

        new_context, result = await _discover_extract_feeds_from_anchors(context)

        expected_links = {
            AbsoluteUrl("http://localhost/feed.5.xml"),
            AbsoluteUrl("http://localhost/feed.6.rss"),
            AbsoluteUrl("http://localhost/feed.7.atom"),
            AbsoluteUrl("http://localhost/feed.9.feed"),
        }

        assert new_context == context.replace(candidate_urls=expected_links)
        assert result is None


class TestDiscoverCheckParentUrls:

    @pytest.mark.asyncio
    async def test_parents(self) -> None:
        context = context = build_context(
            "http://example.com",
            discoverers=_discoverers,
        )

        new_context, result = await _discover_check_parent_urls(context)

        assert new_context == context
        assert result is None

    @pytest.mark.asyncio
    async def test_nothing_found(self, respx_mock: MockRouter) -> None:
        mock_1 = respx_mock.get("/test/feed").mock(side_effect=httpx.ConnectTimeout("some message"))
        mock_2 = respx_mock.get("/test/").mock(side_effect=httpx.ConnectTimeout("some message"))
        mock_3 = respx_mock.get("/test").mock(side_effect=httpx.ConnectTimeout("some message"))
        mock_4 = respx_mock.get("/").mock(side_effect=httpx.ConnectTimeout("some message"))

        context = build_context(
            "http://localhost/test/feed",
            discoverers=_discoverers,
        )

        new_context, result = await _discover_check_parent_urls(context)

        assert not mock_1.called
        assert mock_2.called
        assert mock_3.called
        assert mock_4.called

        assert new_context == context.replace()
        assert result is None

    @pytest.mark.asyncio
    async def test_found(self, respx_mock: MockRouter, raw_feed_content: str, another_raw_feed_content: str) -> None:
        test_html = """
        <html>
          <head>
            <link href="http://localhost/feed1">
            <link href="http://localhost/feed4">
         </head>
         <body>
            <a href="http://localhost/feed2.rss"></a>
            <a href="http://localhost/feed3.atom"></a>
         </body>
        </html>
        """

        respx_mock.get("/test/abc").mock(return_value=httpx.Response(200, content="wrong content"))
        respx_mock.get("/test/").mock(return_value=httpx.Response(200, content="wrong_content"))
        respx_mock.get("/test").mock(return_value=httpx.Response(200, content=test_html))
        respx_mock.get("/").mock(return_value=httpx.Response(200, content="wrong_content"))

        respx_mock.get("/feed1").mock(return_value=httpx.Response(200, content="wrrong content"))
        respx_mock.get("/feed2.rss").mock(return_value=httpx.Response(200, content=another_raw_feed_content))
        respx_mock.get("/feed3.atom").mock(return_value=httpx.Response(200, content=raw_feed_content))
        respx_mock.get("/feed4").mock(return_value=httpx.Response(200, content="wrong_content"))

        context = build_context(
            "http://localhost/test/abc",
            discoverers=_discoverers,
        )

        new_context, result = await _discover_check_parent_urls(context)

        assert new_context == context

        assert result is not None

        assert result.status == Status.feeds_found
        assert len(result.feeds) == 2
        assert {feed.url for feed in result.feeds} == {
            FeedUrl("http://localhost/feed2.rss"),
            FeedUrl("http://localhost/feed3.atom"),
        }


class TestDiscoverCheckCandidateLinks:

    @pytest.mark.asyncio
    async def test_no_links(self) -> None:
        context = Context(
            raw_url=UnknownUrl("http://localhost/test/xxx"),
            candidate_urls=set(),
            discoverers=_discoverers,
        )

        new_context, result = await _discover_check_candidate_links(context)

        assert new_context == context
        assert result is None

    @pytest.mark.asyncio
    async def test_works__no_feeds_found(self, respx_mock: MockRouter) -> None:
        feed_1_mock = respx_mock.get("/feed1").mock(side_effect=httpx.ConnectTimeout("some message"))
        feed_2_mock = respx_mock.get("/feed2").mock(side_effect=httpx.ConnectTimeout("some message"))

        context = build_context(
            "http://localhost/test",
            candidate_urls={
                AbsoluteUrl("http://localhost/feed1"),
                AbsoluteUrl("http://localhost/feed2"),
            },
            discoverers=_discoverers,
        )

        new_context, result = await _discover_check_candidate_links(context)

        assert feed_1_mock.called
        assert feed_2_mock.called

        assert new_context == context.replace(candidate_urls=set())
        assert result is None

    @pytest.mark.asyncio
    async def test_works__duplicated_feeds_detected(self, mocker: MockerFixture) -> None:
        checked_links = []

        async def fake_discover(url: object, *argv: object, **kwargs: object) -> Result:
            checked_links.append(url)
            return Result(feeds=[], status=Status.no_feeds_found)

        mocker.patch("ffun.feeds_discoverer.domain.discover", fake_discover)

        context = build_context(
            "http://localhost/test",
            candidate_urls={
                AbsoluteUrl("http://localhost/feed1"),
                AbsoluteUrl("http://localhost/feed2"),
                AbsoluteUrl("http://localhost/feed1"),
            },
            discoverers=_discoverers,
        )

        new_context, result = await _discover_check_candidate_links(context)

        assert len(checked_links) == 2
        assert set(checked_links) == {"http://localhost/feed1", "http://localhost/feed2"}

        assert new_context == context.replace(candidate_urls=set())
        assert result is None

    @pytest.mark.asyncio
    async def test_works__host_change_detected(self, mocker: MockerFixture) -> None:
        checked_links = []

        async def fake_discover(url: object, *argv: object, **kwargs: object) -> Result:
            checked_links.append(url)
            return Result(feeds=[], status=Status.no_feeds_found)

        mocker.patch("ffun.feeds_discoverer.domain.discover", fake_discover)

        context = build_context(
            "http://localhost/test",
            candidate_urls={
                AbsoluteUrl("http://localhost/feed1"),
                AbsoluteUrl("http://localhost/feed2"),
                AbsoluteUrl("http://example.com/feed3"),
            },
            discoverers=_discoverers,
        )

        new_context, result = await _discover_check_candidate_links(context)

        assert len(checked_links) == 2
        assert set(checked_links) == {"http://localhost/feed1", "http://localhost/feed2"}

        assert new_context == context.replace(candidate_urls=set())
        assert result is None

    @pytest.mark.asyncio
    async def test_works__feeds_found(
        self, respx_mock: MockRouter, raw_feed_content: str, another_raw_feed_content: str
    ) -> None:
        feed_1_mock = respx_mock.get("/feed1").mock(return_value=httpx.Response(200, content=raw_feed_content))
        feed_2_mock = respx_mock.get("/feed2").mock(return_value=httpx.Response(200, content=another_raw_feed_content))

        context = build_context(
            "http://localhost/test",
            candidate_urls={
                AbsoluteUrl("http://localhost/feed1"),
                AbsoluteUrl("http://localhost/feed2"),
            },
            discoverers=_discoverers,
        )

        new_context, result = await _discover_check_candidate_links(context)

        assert feed_1_mock.called
        assert feed_2_mock.called

        assert new_context == context.replace(candidate_urls=set())

        assert result is not None
        assert result.status == Status.feeds_found
        assert len(result.feeds) == 2
        assert {feed.url for feed in result.feeds} == {
            FeedUrl("http://localhost/feed1"),
            FeedUrl("http://localhost/feed2"),
        }


class TestDiscoverStopRecursion:

    @pytest.mark.asyncio
    async def test_depth_zero(self) -> None:
        context = build_context("http://localhost/test", depth=0, discoverers=_discoverers)

        new_context, result = await _discover_stop_recursion(context)

        assert new_context == context
        assert result is not None
        assert result.status == Status.no_feeds_found

    @pytest.mark.asyncio
    async def test_depth_not_zero(self) -> None:
        context = build_context("http://localhost/test", depth=1, discoverers=_discoverers)

        new_context, result = await _discover_stop_recursion(context)

        assert new_context == context
        assert result is None


class TestDiscoverExtractFeedsForReddit:

    @pytest.mark.asyncio
    async def test_not_reddit(self) -> None:
        context = build_context("http://example.com/test")

        new_context, result = await _discover_extract_feeds_for_reddit(context)

        assert new_context == context
        assert result is None

    @pytest.mark.asyncio
    async def test_old_reditt(self) -> None:
        context = build_context(
            "https://old.reddit.com/r/feedsfun/",
        )

        new_context, result = await _discover_extract_feeds_for_reddit(context)

        assert new_context == context
        assert result is None

    @pytest.mark.parametrize(
        "url,expected_url",
        [
            ("https://www.reddit.com/r/feedsfun/", "https://www.reddit.com/r/feedsfun/.rss"),
            ("https://www.reddit.com/r/feedsfun/?sd=x", "https://www.reddit.com/r/feedsfun/.rss"),
            ("https://www.reddit.com/r/feedsfun", "https://www.reddit.com/r/feedsfun/.rss"),
            ("https://reddit.com/r/feedsfun/", "https://reddit.com/r/feedsfun/.rss"),
            ("https://reddit.com/r/feedsfun", "https://reddit.com/r/feedsfun/.rss"),
            (
                "https://www.reddit.com/r/feedsfun/comments/1ho4k84/version_116_released_meet_enhanced_rules_creation/",  # noqa
                "https://www.reddit.com/r/feedsfun/.rss",
            ),
        ],
    )
    @pytest.mark.asyncio
    async def test_new_reddit(self, url: str, expected_url: FeedUrl) -> None:
        context = context = build_context(url)

        new_context, result = await _discover_extract_feeds_for_reddit(context)

        assert new_context == context.replace(candidate_urls={expected_url})
        assert result is None

    @pytest.mark.asyncio
    async def test_already_reddit_rss_url(self) -> None:
        context = context = build_context("https://www.reddit.com/r/feedsfun/.rss")

        new_context, result = await _discover_extract_feeds_for_reddit(context)

        assert new_context == context
        assert result is None


def test_discoverers_list_not_changed() -> None:
    assert _discoverers == [  # type: ignore
        _discover_adjust_url,
        _discover_extract_feeds_for_reddit,
        _discover_check_candidate_links,
        _discover_load_url,
        _discover_extract_feed_info,
        _discover_stop_recursion,
        _discover_create_soup,
        _discover_extract_feeds_from_links,
        _discover_check_candidate_links,
        _discover_extract_feeds_from_anchors,
        _discover_check_candidate_links,
        _discover_check_parent_urls,
    ]


class TestDiscover:

    @pytest.mark.asyncio
    async def test_long_run__stop_on_links(
        self, respx_mock: MockRouter, raw_feed_content: str, another_raw_feed_content: str
    ) -> None:
        test_html = """
        <html>
          <head>
            <link href="http://localhost/feed1">
            <link href="http://localhost/feed3">
            <link href="http://localhost/feed4">
         </head>
         <body>
            <a href="http://localhost/feed2"></a>
            <a href="http://localhost/feed3"></a>
         </body>
        </html>
        """

        respx_mock.get("/test").mock(return_value=httpx.Response(200, content=test_html))
        respx_mock.get("/feed1").mock(return_value=httpx.Response(200, content=raw_feed_content))
        respx_mock.get("/feed2").mock(return_value=httpx.Response(200, content=another_raw_feed_content))
        respx_mock.get("/feed3").mock(return_value=httpx.Response(200, content="wrong content"))
        respx_mock.get("/feed4").mock(return_value=httpx.Response(200, content=another_raw_feed_content))
        respx_mock.get("/").mock(return_value=httpx.Response(200, content="wrong_content"))

        result = await discover(UnknownUrl("http://localhost/test"), depth=1)

        assert result is not None
        assert result.status == Status.feeds_found
        assert len(result.feeds) == 2
        assert {feed.url for feed in result.feeds} == {
            FeedUrl("http://localhost/feed1"),
            FeedUrl("http://localhost/feed4"),
        }

    @pytest.mark.asyncio
    async def test_long_run__stop_on_anchorts(
        self, respx_mock: MockRouter, raw_feed_content: str, another_raw_feed_content: str
    ) -> None:
        test_html = """
        <html>
          <head>
            <link href="http://localhost/feed1">
            <link href="http://localhost/feed4">
         </head>
         <body>
            <a href="http://localhost/feed2.rss"></a>
            <a href="http://localhost/feed3.atom"></a>
         </body>
        </html>
        """

        respx_mock.get("/test").mock(return_value=httpx.Response(200, content=test_html))
        respx_mock.get("/feed1").mock(return_value=httpx.Response(200, content="wrrong content"))
        respx_mock.get("/feed2.rss").mock(return_value=httpx.Response(200, content=another_raw_feed_content))
        respx_mock.get("/feed3.atom").mock(return_value=httpx.Response(200, content=raw_feed_content))
        respx_mock.get("/feed4").mock(return_value=httpx.Response(200, content="wrong_content"))
        respx_mock.get("/").mock(return_value=httpx.Response(200, content="wrong_content"))

        result = await discover(UnknownUrl("http://localhost/test"), depth=1)

        assert result is not None
        assert result.status == Status.feeds_found
        assert len(result.feeds) == 2
        assert {feed.url for feed in result.feeds} == {
            FeedUrl("http://localhost/feed2.rss"),
            FeedUrl("http://localhost/feed3.atom"),
        }

    @pytest.mark.asyncio
    async def test_nothing_found(self, respx_mock: MockRouter) -> None:
        respx_mock.get("/test").mock(return_value=httpx.Response(200, content="wrong content"))

        result = await discover(UnknownUrl("http://localhost/test"), depth=1)

        assert result == Result(feeds=[], status=Status.no_feeds_found)

    @pytest.mark.asyncio
    async def test_found_in_parent(
        self, respx_mock: MockRouter, raw_feed_content: str, another_raw_feed_content: str
    ) -> None:
        test_html = """
        <html>
          <head>
            <link href="http://localhost/feed1">
            <link href="http://localhost/feed4">
         </head>
         <body>
            <a href="http://localhost/feed2.rss"></a>
            <a href="http://localhost/feed3.atom"></a>
         </body>
        </html>
        """

        respx_mock.get("/test/abc").mock(return_value=httpx.Response(200, content="wrong content"))
        respx_mock.get("/test/").mock(return_value=httpx.Response(200, content="wrong_content"))
        respx_mock.get("/test").mock(return_value=httpx.Response(200, content=test_html))
        respx_mock.get("/").mock(return_value=httpx.Response(200, content="wrong_content"))

        respx_mock.get("/feed1").mock(return_value=httpx.Response(200, content="wrrong content"))
        respx_mock.get("/feed2.rss").mock(return_value=httpx.Response(200, content=another_raw_feed_content))
        respx_mock.get("/feed3.atom").mock(return_value=httpx.Response(200, content=raw_feed_content))
        respx_mock.get("/feed4").mock(return_value=httpx.Response(200, content="wrong_content"))

        result = await discover(UnknownUrl("http://localhost/test/abc"), depth=1)

        assert result is not None
        assert result.status == Status.feeds_found
        assert len(result.feeds) == 2
        assert {feed.url for feed in result.feeds} == {
            FeedUrl("http://localhost/feed2.rss"),
            FeedUrl("http://localhost/feed3.atom"),
        }
