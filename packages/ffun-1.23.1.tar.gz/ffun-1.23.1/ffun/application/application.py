import asyncio
import contextlib
from typing import AsyncGenerator

import fastapi
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import ORJSONResponse

from ffun.api.root import http_handlers as root_http_handlers
from ffun.api.spa import http_handlers as spa_http_handlers
from ffun.application import errors
from ffun.application import utils as app_utils
from ffun.application.settings import settings
from ffun.core import logging, middlewares, postgresql, sentry
from ffun.domain.http import set_user_agent
from ffun.domain.urls import initialize_tld_cache
from ffun.feeds_collections.collections import collections

logger = logging.get_module_logger()


def initialize_user_settings() -> None:
    logger.info("initialize_user_settings")
    import ffun.application.user_settings  # noqa: F401


@contextlib.asynccontextmanager
async def use_postgresql() -> AsyncGenerator[None, None]:
    logger.info("initialize_postgresql")
    await postgresql.prepare_pool(
        name="ffun_pool",
        dsn=settings.postgresql.dsn,
        min_size=settings.postgresql.pool_min_size,
        max_size=settings.postgresql.pool_max_size,
        timeout=settings.postgresql.pool_timeout,
        num_workers=settings.postgresql.pool_num_workers,
        max_lifetime=settings.postgresql.pool_max_lifetime,
    )
    logger.info("postgresql_initialized")

    refresher = asyncio.create_task(
        postgresql.pool_refresher(settings.postgresql.pool_check_period), name="poll_refresher"
    )

    try:
        await postgresql.execute("""SELECT 1""")
    except Exception as e:
        raise errors.CanNotAccessPostgreSQL() from e

    try:
        yield
    finally:
        logger.info("deinitialize_postgresql")

        refresher.cancel()

        await postgresql.destroy_pool()

        logger.info("postgresql_deinitialized")


@contextlib.asynccontextmanager
async def use_api_spa(app: fastapi.FastAPI) -> AsyncGenerator[None, None]:
    logger.info("api_spa_enabled")

    spa_http_handlers.add_routes_to_app(app)

    logger.info("api_spa_initialized")

    yield

    logger.info("api_spa_deinitialized")


@contextlib.asynccontextmanager
async def use_root_handlers(app: fastapi.FastAPI) -> AsyncGenerator[None, None]:
    logger.info("root_handlers_enabled")

    root_http_handlers.add_routes_to_app(app)

    logger.info("root_handlers_initialized")

    yield

    logger.info("root_handlers_deinitialized")


@contextlib.asynccontextmanager
async def use_sentry() -> AsyncGenerator[None, None]:
    logger.info("sentry_enabled")

    sentry.initialize(
        dsn=settings.sentry.dsn,
        sample_rate=settings.sentry.sample_rate,
        environment=settings.environment,
    )

    logger.info("sentry_initialized")

    yield

    logger.info("sentry_disabled")


def create_app() -> fastapi.FastAPI:  # noqa: CCR001
    logging.initialize(use_sentry=settings.enable_sentry)

    initialize_tld_cache()

    logger.info("create_app")

    @contextlib.asynccontextmanager
    async def lifespan(app: fastapi.FastAPI) -> AsyncGenerator[None, None]:
        async with contextlib.AsyncExitStack() as stack:
            await stack.enter_async_context(use_postgresql())

            if settings.enable_sentry:
                await stack.enter_async_context(use_sentry())

            if settings.enable_api_spa:
                await stack.enter_async_context(use_api_spa(app))

            if settings.enable_api_root:
                await stack.enter_async_context(use_root_handlers(app))

            await app.router.startup()

            await collections.initialize()

            initialize_user_settings()

            set_user_agent(app_utils.user_agent())

            yield

            await app.router.shutdown()

    app = fastapi.FastAPI(
        lifespan=lifespan,
        docs_url=None,
        redoc_url=None,
        openapi_url=None,
        default_response_class=ORJSONResponse,  # type: ignore
    )

    middlewares.initialize_error_processors(app)

    app.middleware("http")(middlewares.final_errors_middleware)

    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.origins,
        allow_credentials=False,
        allow_methods=[],
        allow_headers=[],
    )

    app.middleware("http")(middlewares.request_measure_middleware)

    app.middleware("http")(middlewares.request_id_middleware)

    logger.info("app_created")

    return app


@contextlib.asynccontextmanager
async def with_app() -> AsyncGenerator[fastapi.FastAPI, None]:
    async with app.router.lifespan_context(app):
        yield app


app = create_app()
