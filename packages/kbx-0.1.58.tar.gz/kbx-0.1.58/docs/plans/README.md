# Design Documents

Historical design and planning documents for kbx features. These capture the rationale and approach at the time of implementation — the actual code may have evolved since.

For current documentation, see the parent `docs/` directory.
