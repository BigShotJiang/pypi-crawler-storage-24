#!/bin/bash
set -e

INPUT=$(cat)
COMMAND=$(echo "$INPUT" | jq -r '.tool_input.command // empty')

# Only log if command contains "ts4k"
[[ "$COMMAND" == *ts4k* ]] || exit 0

LOG="$HOME/.claude/ts4k-usage.jsonl"
TS=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
EVENT=$(echo "$INPUT" | jq -r '.hook_event_name')

if [[ "$EVENT" == "PostToolUse" ]]; then
  jq -c --arg ts "$TS" '{
    timestamp: $ts,
    event: .hook_event_name,
    session_id: .session_id,
    tool_use_id: .tool_use_id,
    command: .tool_input.command,
    description: .tool_input.description,
    response: .tool_response
  }' <<< "$INPUT" >> "$LOG"
else
  jq -c --arg ts "$TS" '{
    timestamp: $ts,
    event: .hook_event_name,
    session_id: .session_id,
    tool_use_id: .tool_use_id,
    command: .tool_input.command,
    description: .tool_input.description
  }' <<< "$INPUT" >> "$LOG"
fi

exit 0
