#!/usr/bin/env python3
"""Analyze ts4k usage log for improvement insights.

Usage:
  python3 scripts/analyze-ts4k-log.py [path_to_log]

Default log: ~/.claude/ts4k-usage.jsonl
"""
import json
import sys
from collections import Counter
from pathlib import Path

LOG = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.home() / ".claude" / "ts4k-usage.jsonl"

def parse_entries():
    entries = []
    for line in LOG.open():
        line = line.strip()
        if not line or not line.startswith("{"):
            continue
        try:
            entries.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return entries

def analyze(entries):
    sessions = set()
    pre_count = 0
    post_count = 0
    subcommands = Counter()
    warnings = []
    syntax_errors = []
    workarounds = []
    wa_no_content = []
    since_rejected = []
    rate_limits = []
    auth_failures = []
    network_errors = []

    for e in entries:
        ev = e.get("event", "")
        cmd = e.get("command", "")
        desc = e.get("description", "")
        sid = e.get("session_id", "")
        resp = e.get("response", {})
        stdout = (resp.get("stdout", "") or "")

        if sid:
            sessions.add(sid)

        if ev == "PreToolUse" and "ts4k" in cmd:
            pre_count += 1
            parts = cmd.split()
            idx = next((i for i, p in enumerate(parts) if "ts4k" in p), None)
            if idx is not None and idx + 1 < len(parts):
                subcommands[parts[idx + 1]] += 1

            # Detect syntax errors (wrong subcommand or flag)
            if any(x in cmd for x in ["inbox", "--hours"]):
                syntax_errors.append({"cmd": cmd[:120], "desc": desc})

            # Detect piped workarounds
            if "|" in cmd and "ts4k" in cmd:
                workarounds.append({"cmd": cmd[:150], "desc": desc})

        if ev == "PostToolUse":
            post_count += 1

            if "returned no text content" in stdout:
                wa_no_content.append(cmd[:100])
            if "Invalid date format" in stdout:
                since_rejected.append(cmd[:100])
            if "429" in stdout and "ts4k" in cmd:
                rate_limits.append(cmd[:100])
            if "Token refresh failed" in stdout:
                auth_failures.append(cmd[:100])
            if "Network is unreachable" in stdout and "ts4k" in cmd:
                network_errors.append(cmd[:100])
            if "WARNING" in stdout or "ERROR" in stdout:
                msgs = [l for l in stdout.split("\n") if "WARNING" in l or "ERROR" in l][:2]
                if msgs and "ts4k" in cmd:
                    warnings.append({"cmd": cmd[:100], "msgs": msgs})
            if "error:" in stdout and "ts4k" in cmd:
                syntax_errors.append({"cmd": cmd[:120], "desc": "", "error": stdout.split("error:")[-1][:150]})

    # Print report
    print(f"=== ts4k USAGE LOG ANALYSIS ===")
    print(f"Log file: {LOG}")
    print(f"Sessions: {len(sessions)}")
    print(f"Total calls: {pre_count} pre / {post_count} post")
    print()

    print(f"=== SUBCOMMANDS (by frequency) ===")
    for cmd, count in subcommands.most_common():
        print(f"  {cmd}: {count}")
    print()

    print(f"=== SYNTAX ERRORS ({len(syntax_errors)}) ===")
    for s in syntax_errors:
        print(f"  CMD:   {s['cmd']}")
        if s.get("desc"):
            print(f"  INTENT: {s['desc']}")
        if s.get("error"):
            print(f"  ERROR: {s['error']}")
        print()

    print(f"=== WhatsApp 'no text content' failures ({len(wa_no_content)}) ===")
    for f in wa_no_content:
        print(f"  {f}")
    print()

    print(f"=== --since format rejected by WhatsApp ({len(since_rejected)}) ===")
    for s in since_rejected:
        print(f"  {s}")
    print()

    print(f"=== Rate limits ({len(rate_limits)}) ===")
    for r in rate_limits:
        print(f"  {r}")
    print()

    print(f"=== Auth failures ({len(auth_failures)}) ===")
    for a in auth_failures:
        print(f"  {a}")
    print()

    print(f"=== Network errors ({len(network_errors)}) ===")
    for n in network_errors:
        print(f"  {n}")
    print()

    print(f"=== Piped workarounds ({len(workarounds)}) ===")
    for w in workarounds:
        print(f"  CMD:   {w['cmd']}")
        print(f"  INTENT: {w['desc']}")
        print()

    print(f"=== ALL WARNINGS ({len(warnings)}) ===")
    for w in warnings:
        print(f"  CMD: {w['cmd']}")
        for m in w["msgs"]:
            print(f"    {m[:150]}")
        print()


if __name__ == "__main__":
    entries = parse_entries()
    analyze(entries)
