# ts4k Usage Logging

Capture and analyze every ts4k-related tool call Claude makes to improve CLI design, help text, and agent-facing `skill` output.

## How It Works

Claude Code **hooks** fire before/after tool calls:

- **PreToolUse** — fires before a tool runs. Gets tool name + input params via stdin JSON.
- **PostToolUse** — fires after a tool runs. Gets tool name + input params + the result via stdin JSON.

The `scripts/log-ts4k.sh` hook matches any Bash command containing "ts4k" and appends a JSONL entry to `~/.claude/ts4k-usage.jsonl`.

## What Gets Logged

| Field | Source | Why |
|-------|--------|-----|
| `timestamp` | hook script | When it happened |
| `session_id` | stdin JSON `.session_id` | Group calls by conversation |
| `event` | `PreToolUse` or `PostToolUse` | Distinguish call vs result |
| `command` | `.tool_input.command` | The exact ts4k invocation |
| `description` | `.tool_input.description` | Claude's stated intent for the call |
| `tool_use_id` | `.tool_use_id` | Pair PreToolUse with its PostToolUse |
| `response` | `.tool_response` (PostToolUse only) | stdout/stderr |

> **Note:** Claude Code Bash PostToolUse does NOT include `exitCode`.
> Available response fields: `stdout`, `stderr`, `interrupted`, `isImage`, `noOutputExpected`.
> Detect errors via `stderr` content or `interrupted: true`.

## Setup

### 1. Configure the hook

Add to your project's `.claude/settings.local.json` (or `~/.claude/settings.json` for all projects):

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Bash",
        "hooks": [{ "type": "command", "command": "/path/to/ts4k/scripts/log-ts4k.sh" }]
      }
    ],
    "PostToolUse": [
      {
        "matcher": "Bash",
        "hooks": [{ "type": "command", "command": "/path/to/ts4k/scripts/log-ts4k.sh" }]
      }
    ]
  }
}
```

### 2. Make executable

```bash
chmod +x scripts/log-ts4k.sh
```

### 3. Test

Run a Claude Code session, use ts4k, then check:

```bash
jq . ~/.claude/ts4k-usage.jsonl
```

## Review Process

### 1. Count entries for a date

```bash
grep '2026-03-10' ~/.claude/ts4k-usage.jsonl | wc -l
```

### 2. Check for failures

```bash
grep '2026-03-10' ~/.claude/ts4k-usage.jsonl | jq -c 'select(.event == "PostToolUse") | select(.response.stderr != null and (.response.stderr | length) > 0) | {command: .command, stderr: .response.stderr}'
```

### 3. List all PostToolUse calls

```bash
grep '2026-03-10' ~/.claude/ts4k-usage.jsonl | jq -c 'select(.event == "PostToolUse") | {timestamp, command, description}' | jq -s '.'
```

### 4. Command frequency

```bash
grep '2026-03-10' ~/.claude/ts4k-usage.jsonl | jq -c 'select(.event == "PreToolUse") | .command' | sort | uniq -c | sort -rn
```

### 5. Pattern identification

- **Help lookups** — agent checking `--help` mid-session = skill output needs improvement
- **Retry/widening** — same command with progressively broader params = agent hunting
- **Inconsistent syntax** — different arg orders for same subcommand
- **Duplicates** — same exact call twice = possible confusion or key context loss
- **Path inconsistency** — bare `ts4k` vs `~/.local/bin/ts4k`

## Automated Analysis

Run the analysis script for a full report:

```bash
python3 scripts/analyze-ts4k-log.py                    # default log location
python3 scripts/analyze-ts4k-log.py /path/to/other.jsonl  # custom log
```

Reports: session count, subcommand frequency, syntax errors, WhatsApp failures, rate limits, auth failures, network errors, piped workarounds, and all warnings.

## What This Tells You

- **Which commands Claude reaches for** — are some underused? Misunderstood?
- **Syntax errors** — where does the `skill` help text fail Claude?
- **Intent vs execution** — the `description` field shows what Claude *thinks* it's doing
- **Missing features** — patterns where Claude works around a limitation

## Hook Matcher Note

The matcher catches any Bash command containing "ts4k" anywhere, including file paths. This causes ~10% false positives (e.g., `grep ... ts4k-usage.jsonl`). Accepted trade-off: extra noise over missing real calls.
