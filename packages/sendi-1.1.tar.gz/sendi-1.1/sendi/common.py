import logging
from enum import StrEnum

sendi_logger = logging.getLogger("sendi")


class SecurityLevel(StrEnum):
    SIMPLE = "simple"
    ENCRYPTED = "encrypted"


class ConnectionType(StrEnum):
    STANDARD = "standard"  # Starttls or unsecure
    STARTTLS = "starttls"
    TLS = "tls"
    UNSECURE = "unsecure"
    SECURE = "secure"  # Starttls or TLS
