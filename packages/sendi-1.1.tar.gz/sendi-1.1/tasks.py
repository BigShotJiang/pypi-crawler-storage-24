from invoke import Context, task


@task
def init(context: Context) -> None:
    """
    Initialize the context
    """
    context.run("uv venv --python 3.13")
    context.run("uv pip install gitlabci-local --force-reinstall")
    context.run("uv tool install ruff --force-reinstall")
    context.run("uv sync")
    context.run("uv tool install pre-commit --force-reinstall")
    context.run("uv run pre-commit install")
    context.run("uv run uv pip compile pyproject.toml -o requirements.txt")


@task
def check(context: Context) -> None:
    context.run("uv run pre-commit run --all-files", pty=True)


@task
def build(context: Context) -> None:
    """
    Build
    """
    context.run("rm -rf dist/*")
    context.run("uv build", warn=True)


@task
def init_deb(context: Context) -> None:
    context.run("uv tool install wheel2deb --force")
    context.run("sudo apt update")
    context.run("sudo apt install apt-file dpkg-dev fakeroot build-essential devscripts debhelper")
    context.run("sudo apt-file update")


@task
def build_deb(context: Context) -> None:
    """
    Build deb from wheel
    """
    context.run("pip wheel -w dist omemo>=1.1.0 annotated-types>=0.5.0 slixmpp-omemo>=1.1.1")
    context.run("wheel2deb default --search-path dist/ --output-dir deb", warn=True)


@task
def container_build(
    context: Context,
    label: str = "sendi",
    repository: str = "localhost",
    platform: str = "linux/amd64",
    version: str = "1.1.1",
) -> None:
    command_line = "buildah bud"
    command_line += (
        f' --tag "{repository}/{label}:{version}" --platform {platform} --build-arg TAG="build_{version}"'
    )
    command_line += " ."
    context.run(command_line)
