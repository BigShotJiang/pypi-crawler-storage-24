"""Collection test helper package."""

