import numpy as np

class LIPM:
    """
    线性倒立摆模型 (Linear Inverted Pendulum Model)
    用于双足机器人步态规划与平衡控制
    公式来源：宇树机器人核心公式 (图7432)
    """
    
    def __init__(self, z_c=1.0, g=9.81):
        """
        参数:
            z_c: 质心高度 (m)
            g:   重力加速度 (m/s^2)
        """
        self.z_c = z_c
        self.g = g
        self.omega = np.sqrt(g / z_c)  # 自然频率
        
    def compute_cop(self, x, x_dot):
        """
        计算质心运动对应的落脚点 (CoP)
        公式: p = x - (z_c / g) * x_ddot
        其中 x_ddot = omega^2 * (x - p)
        """
        x_ddot = self.omega**2 * x
        p = x - (self.z_c / self.g) * x_ddot
        return p
    
    def compute_dcm(self, x, x_dot):
        """
        计算运动发散分量 (DCM) - 即“捕捉点”
        公式: xi = x + x_dot / omega
        """
        xi = x + x_dot / self.omega
        return xi
    
    def compute_next_footstep(self, x, x_dot, T_step):
        """
        根据当前质心状态，规划下一步落脚点
        x: 当前质心位置
        x_dot: 当前质心速度
        T_step: 单步时间
        """
        xi = self.compute_dcm(x, x_dot)
        # 期望一步后DCM到达目标
        xi_target = 0.0  # 假设目标在原点
        p = (xi_target - xi * np.exp(-self.omega * T_step)) / (1 - np.exp(-self.omega * T_step))
        return p
    
    def simulate_step(self, x0, x_dot0, p, T_step, dt=0.01):
        """
        仿真单步内质心运动
        x0: 初始位置
        x_dot0: 初始速度
        p: 落脚点 (ZMP)
        T_step: 步长时间
        dt: 仿真步长
        """
        time = np.arange(0, T_step, dt)
        x = np.zeros_like(time)
        x_dot = np.zeros_like(time)
        
        x[0] = x0
        x_dot[0] = x_dot0
        
        for i in range(1, len(time)):
            x_ddot = self.omega**2 * (x[i-1] - p)
            x_dot[i] = x_dot[i-1] + x_ddot * dt
            x[i] = x[i-1] + x_dot[i-1] * dt
            
        return time, x, x_dot