import numpy as np
from scipy.optimize import minimize

class SimpleMPC:
    """
    简化版模型预测控制 (Model Predictive Control)
    用于双足机器人步态预测与控制
    公式来源：宇树机器人核心公式 (图7428-7430)
    """
    
    def __init__(self, dt=0.01, horizon=10, max_u=10.0):
        """
        参数:
            dt: 控制周期 (s)
            horizon: 预测步数
            max_u: 最大控制量
        """
        self.dt = dt
        self.horizon = horizon
        self.max_u = max_u
        
    def dynamics(self, x, u):
        """
        离散动力学模型: x_{k+1} = A x_k + B u_k
        这里简化为一维运动
        """
        A = np.array([[1.0, self.dt], [0.0, 1.0]])
        B = np.array([[0.0], [self.dt]])
        return A @ x + B.flatten() * u
    
    def cost_function(self, u_seq, x0, x_target):
        """
        代价函数: 跟踪误差 + 控制量惩罚
        """
        u_seq = u_seq.reshape(-1)
        x = x0.copy()
        cost = 0.0
        
        for k in range(self.horizon):
            u = u_seq[k] if k < len(u_seq) else 0
            x = self.dynamics(x, u)
            error = x - x_target
            cost += error @ error + 0.01 * u**2
            
        return cost
    
    def solve(self, x0, x_target):
        """
        求解最优控制序列
        """
        u_init = np.zeros(self.horizon)
        bounds = [(-self.max_u, self.max_u)] * self.horizon
        
        result = minimize(
            self.cost_function,
            u_init,
            args=(x0, x_target),
            bounds=bounds,
            method='SLSQP'
        )
        
        if result.success:
            return result.x[0]  # 只返回第一步控制
        else:
            return 0.0