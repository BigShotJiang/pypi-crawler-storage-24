import numpy as np

class WholeBodyControl:
    """
    简化版全身控制 (Whole Body Control)
    用于协调多任务（走路 + 上肢动作）
    公式来源：宇树机器人核心公式 (图744X) + 英伟达 (图7243)
    """
    
    def __init__(self, num_joints=12):
        self.num_joints = num_joints
        self.priorities = {
            'balance': 1.0,    # 平衡优先级最高
            'walk': 0.8,       # 走路次之
            'arm': 0.5,        # 上肢任务最低
        }
        
    def compute_torques(self, q, q_dot, q_desired, tasks):
        """
        计算全身控制力矩
        tasks: 字典 {'walk': target_pos, 'arm': target_arm}
        """
        # 1. 平衡任务：保持ZMP在支撑域内
        balance_torque = self._balance_task(q, q_dot)
        
        # 2. 走路任务：跟踪质心轨迹
        walk_torque = self._walk_task(q, q_dot, tasks.get('walk'))
        
        # 3. 上肢任务：跟踪手臂位置
        arm_torque = self._arm_task(q, q_dot, tasks.get('arm'))
        
        # 4. 加权融合
        total_torque = (
            self.priorities['balance'] * balance_torque +
            self.priorities['walk'] * walk_torque +
            self.priorities['arm'] * arm_torque
        )
        
        return total_torque
    
    def _balance_task(self, q, q_dot):
        """简化的平衡任务：保持躯干直立"""
        # 假设第一个关节是躯干
        torso_error = -q[0]
        return np.ones(self.num_joints) * torso_error * 10
    
    def _walk_task(self, q, q_dot, target):
        """简化的走路任务：跟踪质心位置"""
        if target is None:
            return np.zeros(self.num_joints)
        # 简化为对前两个关节的控制
        error = target - q[:2]
        torque = np.zeros(self.num_joints)
        torque[:2] = error * 5
        return torque
    
    def _arm_task(self, q, q_dot, target):
        """简化的上肢任务：跟踪手臂位置"""
        if target is None:
            return np.zeros(self.num_joints)
        # 简化为对后几个关节的控制
        error = target - q[6:9]
        torque = np.zeros(self.num_joints)
        torque[6:9] = error * 3
        return torque