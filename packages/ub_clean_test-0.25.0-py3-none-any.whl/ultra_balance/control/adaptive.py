import numpy as np
from collections import deque

class AdaptiveGainScheduler:
    def __init__(self, base_kp=150.0, base_kd=25.0,
                 kp_range=(50, 300), kd_range=(10, 60),
                 adaptation_rate=0.01):
        self.base_kp = base_kp
        self.base_kd = base_kd
        self.kp_range = kp_range
        self.kd_range = kd_range
        self.adaptation_rate = adaptation_rate
        self.kp = base_kp
        self.kd = base_kd
        self.error_history = deque(maxlen=100)

    def update(self, error, state):
        self.error_history.append(error)

        if abs(error) > 0.5:
            kp_factor = 1.2
        elif abs(error) < 0.1:
            kp_factor = 0.9
        else:
            kp_factor = 1.0

        if self.detect_oscillation():
            kd_factor = 1.3
        else:
            kd_factor = 1.0

        contact_force = state.get('contact_force', 0)
        if contact_force > 500:
            kp_factor *= 0.7
            kd_factor *= 1.2

        velocity = state.get('velocity', 0)
        if abs(velocity) > 2.0:
            kp_factor *= 1.1
            kd_factor *= 0.9

        self.kp = self.base_kp * kp_factor
        self.kd = self.base_kd * kd_factor
        self.kp = np.clip(self.kp, self.kp_range[0], self.kp_range[1])
        self.kd = np.clip(self.kd, self.kd_range[0], self.kd_range[1])

        self.kp += self.adaptation_rate * (self.base_kp - self.kp)
        self.kd += self.adaptation_rate * (self.base_kd - self.kd)

        return self.kp, self.kd

    def detect_oscillation(self):
        if len(self.error_history) < 10:
            return False
        errors = np.array(self.error_history)
        zero_crossings = np.sum(np.diff(np.sign(errors)) != 0)
        return zero_crossings > 5