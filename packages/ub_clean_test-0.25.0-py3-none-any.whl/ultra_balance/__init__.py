__version__ = '0.25.0'         
__author__ = 'pengyeqin'

def hello():
    print("Hello from ub-clean-test!")