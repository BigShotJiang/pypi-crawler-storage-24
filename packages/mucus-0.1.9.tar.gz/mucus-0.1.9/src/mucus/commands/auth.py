import mucus.command


class Command(mucus.command.Command):
    def __call__(self, client, command, **kwargs):
        if command['args']:
            client.auth.arl = command['args'].strip()
        r = client.post('deezer_userAutolog', json={
            'APP_NAME': 'Deezer',
            'APPLICATION_ID': 632384,
            'AUTHORIZE_UNLOGGED': True,
            'CHECKFORM': True,
            'DEVICE_TOKEN': '7610ab8f03d8fbe5ca8e57af3709f9e633ec234b502a842afe606724423b5d4c'
        })
        client.auth.jwt = r['jwt']
