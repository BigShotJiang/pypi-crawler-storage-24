import argparse
import json
import shlex

import click

import mucus.command


class Command(mucus.command.Command):
    def __call__(self, command, player, **kwargs):
        if player.song is None:
            return

        parser = argparse.ArgumentParser()
        parser.add_argument('-j', '--json', action='store_true')
        args = parser.parse_args(shlex.split(command['args']))

        if args.json:
            click.echo(json.dumps(player.song, indent=2))
        else:
            click.echo(' '.join([
                click.style(player.song['ART_NAME'], fg='green'),
                click.style(player.song['SNG_TITLE'], fg='blue')
            ]))
