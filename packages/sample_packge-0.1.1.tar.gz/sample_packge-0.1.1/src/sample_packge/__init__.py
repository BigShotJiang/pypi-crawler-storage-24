def hello() -> str:
    return "Hello from sample-packge-v2!"
