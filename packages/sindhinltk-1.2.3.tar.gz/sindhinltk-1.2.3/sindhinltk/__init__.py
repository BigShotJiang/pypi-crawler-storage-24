from .normalizer import SindhiNormalizer
from .tokenizer import SindhiTokenizer, TokenizersBackend
from .stemmer import SindhiStemmer

class SindhiNLP:
    def __init__(self):
        self.norm = SindhiNormalizer()
        self.tok = SindhiTokenizer()
        self.stemmer = SindhiStemmer()
    def process(self, text):
        clean = self.norm.normalize(text)
        tokens = self.tok.tokenize(clean)
        return {'tokens': tokens, 'stems': [self.stemmer.stem(t) for t in tokens]}