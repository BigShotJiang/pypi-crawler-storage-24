import unicodedata
class SindhiNormalizer:
    def normalize(self, t): return unicodedata.normalize('NFC', t).strip()