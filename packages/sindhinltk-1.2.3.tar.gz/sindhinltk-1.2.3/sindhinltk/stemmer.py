class SindhiStemmer:
    def stem(self, w): return w