class SindhiStopwords:
    def remove_stopwords(self, tokens): return tokens