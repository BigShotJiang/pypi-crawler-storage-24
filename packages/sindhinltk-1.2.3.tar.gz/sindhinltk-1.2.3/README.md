# SindhiNLTK v1.2.3
Stable release with backward compatibility for TokenizersBackend.