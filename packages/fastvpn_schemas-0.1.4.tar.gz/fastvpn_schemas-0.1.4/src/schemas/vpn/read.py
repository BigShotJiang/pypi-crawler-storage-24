import uuid as py_uuid

from schemas.common import IDSchema, TimestampSchema

from .base import VpnAccountBase


class VpnAccountRead(VpnAccountBase, IDSchema, TimestampSchema):
    user_id: py_uuid.UUID
