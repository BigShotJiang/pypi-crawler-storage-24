import uuid as py_uuid

from .base import VpnAccountBase


class VpnAccountCreate(VpnAccountBase):
    user_id: py_uuid.UUID
