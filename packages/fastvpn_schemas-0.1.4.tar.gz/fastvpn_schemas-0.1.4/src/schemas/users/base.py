from pydantic import Field

from schemas.common import ORMBaseSchema


class UserBase(ORMBaseSchema):
    telegram_id: int = Field(..., ge=1)
