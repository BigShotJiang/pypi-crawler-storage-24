from typing import List, Optional

from schemas.common import IDSchema, TimestampSchema
from schemas.payments import PaymentRead
from schemas.subscriptions.read import SubscriptionReadWithPlan
from schemas.vpn import VpnAccountRead

from .base import UserBase


class UserRead(UserBase, IDSchema, TimestampSchema):
    pass


class UserReadFull(UserRead):
    vpn_account: Optional[VpnAccountRead] = None
    payments: List[PaymentRead] = []
    subscription: Optional[SubscriptionReadWithPlan] = None
