import uuid as py_uuid
from datetime import datetime
from typing import Optional

from pydantic import BaseModel, Field

from schemas.enums import PaymentStatus


class PaymentCreate(BaseModel):
    user_id: py_uuid.UUID
    subscription_id: Optional[py_uuid.UUID] = None
    amount_stars: int = Field(..., ge=1)
    invoice_payload: str = Field(..., min_length=1, max_length=255)
    is_recurring: bool = False
    is_first: bool = True
    status: PaymentStatus = PaymentStatus.PENDING
    telegram_charge_id: Optional[str] = Field(default=None, max_length=100)
    paid_at: Optional[datetime] = None
