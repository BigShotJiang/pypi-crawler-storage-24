import uuid as py_uuid
from typing import Optional

from schemas.common import IDSchema, TimestampSchema

from .base import PaymentBase


class PaymentRead(PaymentBase, IDSchema, TimestampSchema):
    user_id: py_uuid.UUID
    subscription_id: Optional[py_uuid.UUID] = None
