import uuid as py_uuid
from typing import Optional

from schemas.common import IDSchema, TimestampSchema
from schemas.plans import PlanRead

from .base import SubscriptionBase


class SubscriptionRead(SubscriptionBase, IDSchema, TimestampSchema):
    user_id: py_uuid.UUID


class SubscriptionReadWithPlan(SubscriptionRead):
    plan: Optional[PlanRead] = None
