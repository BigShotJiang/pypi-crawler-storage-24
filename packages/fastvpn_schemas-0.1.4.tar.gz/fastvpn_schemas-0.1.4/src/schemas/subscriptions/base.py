from datetime import datetime
from typing import Optional

from pydantic import Field

from schemas.common import ORMBaseSchema
from schemas.enums import SubscriptionStatus


class SubscriptionBase(ORMBaseSchema):
    plan_id: int = Field(..., ge=1)
    status: SubscriptionStatus = SubscriptionStatus.PENDING
    current_period_start: datetime
    current_period_end: datetime
    next_billing_attempt: Optional[datetime] = None
    canceled_at: Optional[datetime] = None
