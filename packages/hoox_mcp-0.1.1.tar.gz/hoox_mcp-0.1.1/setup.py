"""Shim for editable installs and legacy tooling."""

from setuptools import setup

setup()
