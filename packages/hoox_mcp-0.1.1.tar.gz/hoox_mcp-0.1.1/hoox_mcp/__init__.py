"""Hoox MCP Server — AI video generation through the Model Context Protocol."""

from hoox_mcp.server import main

__all__ = ["main"]
