"""Thin async HTTP client wrapping the Hoox public REST API."""

from __future__ import annotations

import os
from typing import Any

import httpx

DEFAULT_BASE_URL = "https://app.hoox.video/api/public/v1"
REQUEST_TIMEOUT = 120.0


class HooxClientError(Exception):
    """Raised when the Hoox API returns a non-2xx response."""

    def __init__(self, status_code: int, detail: str) -> None:
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"HTTP {status_code}: {detail}")


class HooxClient:
    """Lightweight async wrapper around the Hoox public API v1."""

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
    ) -> None:
        self.api_key = api_key or os.environ.get("HOOX_API_KEY", "")
        # HOOX_BASE_URL is intentionally not read from the environment to avoid
        # accidentally sending API requests (and the API key) to an unexpected host.
        # If a different endpoint is needed (e.g. for staging), it must be passed
        # explicitly via the base_url argument.
        self.base_url = (base_url or DEFAULT_BASE_URL).rstrip("/")
        if not self.api_key:
            raise ValueError(
                "HOOX_API_KEY is required. Set it as an environment variable or pass it directly."
            )
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            },
            timeout=REQUEST_TIMEOUT,
        )

    async def close(self) -> None:
        await self._client.aclose()

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json_body: dict[str, Any] | None = None,
    ) -> Any:
        resp = await self._client.request(method, path, params=params, json=json_body)
        if resp.status_code >= 400:
            try:
                detail = resp.json()
            except Exception:
                detail = resp.text
            raise HooxClientError(resp.status_code, str(detail))
        return resp.json()

    # ------------------------------------------------------------------
    # Voices
    # ------------------------------------------------------------------

    async def list_voices(
        self,
        language: str | None = None,
        gender: str | None = None,
        tags: str | None = None,
        only_public: bool | None = None,
    ) -> Any:
        params: dict[str, Any] = {}
        if language:
            params["language"] = language
        if gender:
            params["gender"] = gender
        if tags:
            params["tags"] = tags
        if only_public is not None:
            params["onlyPublic"] = str(only_public).lower()
        return await self._request("GET", "/voice/list", params=params)

    async def get_voice(self, voice_id: str) -> Any:
        return await self._request("GET", f"/voice/{voice_id}")

    # ------------------------------------------------------------------
    # Avatars
    # ------------------------------------------------------------------

    async def list_avatars(
        self,
        gender: str | None = None,
        tags: str | None = None,
        only_public: bool | None = None,
    ) -> Any:
        params: dict[str, Any] = {}
        if gender:
            params["gender"] = gender
        if tags:
            params["tags"] = tags
        if only_public is not None:
            params["onlyPublic"] = str(only_public).lower()
        return await self._request("GET", "/avatar/list", params=params)

    async def get_avatar(self, avatar_id: str) -> Any:
        return await self._request("GET", f"/avatar/{avatar_id}")

    async def get_avatar_look(self, avatar_id: str, look_id: str) -> Any:
        return await self._request("GET", f"/avatar/{avatar_id}/look/{look_id}")

    async def get_avatar_status(self, avatar_id: str, look_id: str) -> Any:
        return await self._request(
            "GET", "/avatar/status", params={"avatar_id": avatar_id, "look_id": look_id}
        )

    async def create_avatar(self, **kwargs: Any) -> Any:
        return await self._request("POST", "/avatar/create", json_body=kwargs)

    async def edit_avatar(self, **kwargs: Any) -> Any:
        return await self._request("POST", "/avatar/edit", json_body=kwargs)

    # ------------------------------------------------------------------
    # Script
    # ------------------------------------------------------------------

    async def generate_script(self, **kwargs: Any) -> Any:
        return await self._request("POST", "/script/generate", json_body=kwargs)

    # ------------------------------------------------------------------
    # Generation
    # ------------------------------------------------------------------

    async def start_generation(self, **kwargs: Any) -> Any:
        return await self._request("POST", "/generation/start", json_body=kwargs)

    async def get_generation_status(self, job_id: str) -> Any:
        return await self._request("GET", f"/generation/status/{job_id}")

    # ------------------------------------------------------------------
    # Export
    # ------------------------------------------------------------------

    async def start_export(self, **kwargs: Any) -> Any:
        return await self._request("POST", "/export/start", json_body=kwargs)

    async def get_export_status(self, job_id: str) -> Any:
        return await self._request("GET", f"/export/status/{job_id}")

    # ------------------------------------------------------------------
    # Video
    # ------------------------------------------------------------------

    async def duplicate_video(self, **kwargs: Any) -> Any:
        return await self._request("POST", "/video/duplicate", json_body=kwargs)

