"""Tests for the Hoox MCP server tools.

Uses unittest.mock to patch the HTTP client so tests run without
a real API key or network access.
"""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, patch

import pytest

from hoox_mcp.client import HooxClient, HooxClientError


@pytest.fixture(autouse=True)
def _reset_client():
    """Reset the global client singleton between tests."""
    import hoox_mcp.server as srv

    srv._client = None
    yield
    srv._client = None


@pytest.fixture()
def mock_client():
    """Return a HooxClient with all methods mocked."""
    with patch.dict("os.environ", {"HOOX_API_KEY": "hx_live_test_key"}):
        client = HooxClient()
    client.list_voices = AsyncMock(return_value=[{"id": "v1", "name": "Sarah", "language": "en"}])
    client.get_voice = AsyncMock(return_value={"id": "v1", "name": "Sarah"})
    client.list_avatars = AsyncMock(return_value=[{"id": "look_1", "avatar_name": "Alex"}])
    client.get_avatar = AsyncMock(return_value={"id": "avtr_1", "name": "Alex", "looks": []})
    client.get_avatar_look = AsyncMock(return_value={"id": "look_1", "status": "ready"})
    client.get_avatar_status = AsyncMock(
        return_value={"avatar_id": "avtr_1", "look_id": "look_1", "status": "completed"}
    )
    client.create_avatar = AsyncMock(
        return_value={"avatar_id": "avtr_new", "look_id": "look_new"}
    )
    client.edit_avatar = AsyncMock(
        return_value={"avatar_id": "avtr_1", "look_id": "look_edited"}
    )
    client.generate_script = AsyncMock(
        return_value={"script": "Hello world.", "cost": 1, "extractedImages": []}
    )
    client.start_generation = AsyncMock(
        return_value={"job_id": "run_gen_1", "status": "pending", "estimated_credits": 50}
    )
    client.get_generation_status = AsyncMock(
        return_value={"job_id": "run_gen_1", "status": "completed", "result": {"video_id": "vid_1"}}
    )
    client.start_export = AsyncMock(
        return_value={"job_id": "run_exp_1", "status": "pending", "estimated_credits": 0}
    )
    client.get_export_status = AsyncMock(
        return_value={
            "job_id": "run_exp_1",
            "status": "completed",
            "result": {"video_url": "https://cdn.hoox.video/video.mp4"},
        }
    )
    client.duplicate_video = AsyncMock(
        return_value={"video_id": "vid_dup_1", "status": "done"}
    )
    return client


def _inject(mock_client: HooxClient):
    """Inject a mock client into the server module."""
    import hoox_mcp.server as srv

    srv._client = mock_client


# ------------------------------------------------------------------
# Voice tools
# ------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_voices(mock_client):
    from hoox_mcp.server import list_voices

    _inject(mock_client)
    result = json.loads(await list_voices())
    assert result["total"] == 1
    assert result["voices"][0]["id"] == "v1"
    mock_client.list_voices.assert_awaited_once()


@pytest.mark.asyncio
async def test_list_voices_with_filters(mock_client):
    from hoox_mcp.server import list_voices

    _inject(mock_client)
    await list_voices(language="fr", gender="female")
    mock_client.list_voices.assert_awaited_once_with(
        language="fr", gender="female", tags=None, only_public=None
    )


@pytest.mark.asyncio
async def test_get_voice(mock_client):
    from hoox_mcp.server import get_voice

    _inject(mock_client)
    result = json.loads(await get_voice("v1"))
    assert result["id"] == "v1"


# ------------------------------------------------------------------
# Avatar tools
# ------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_avatars(mock_client):
    from hoox_mcp.server import list_avatars

    _inject(mock_client)
    result = json.loads(await list_avatars())
    assert result["total"] == 1
    assert result["avatars"][0]["avatar_name"] == "Alex"


@pytest.mark.asyncio
async def test_get_avatar(mock_client):
    from hoox_mcp.server import get_avatar

    _inject(mock_client)
    result = json.loads(await get_avatar("avtr_1"))
    assert result["name"] == "Alex"


@pytest.mark.asyncio
async def test_create_avatar(mock_client):
    from hoox_mcp.server import create_avatar

    _inject(mock_client)
    result = json.loads(await create_avatar(prompt="A professional woman in an office"))
    assert result["avatar_id"] == "avtr_new"
    mock_client.create_avatar.assert_awaited_once_with(
        prompt="A professional woman in an office"
    )


@pytest.mark.asyncio
async def test_edit_avatar(mock_client):
    from hoox_mcp.server import edit_avatar

    _inject(mock_client)
    result = json.loads(await edit_avatar("avtr_1", "look_1", "Change background to beach"))
    assert result["look_id"] == "look_edited"


@pytest.mark.asyncio
async def test_get_avatar_status(mock_client):
    from hoox_mcp.server import get_avatar_status

    _inject(mock_client)
    result = json.loads(await get_avatar_status("avtr_1", "look_1"))
    assert result["status"] == "completed"


# ------------------------------------------------------------------
# Script tools
# ------------------------------------------------------------------


@pytest.mark.asyncio
async def test_generate_script(mock_client):
    from hoox_mcp.server import generate_script

    _inject(mock_client)
    result = json.loads(await generate_script("A 60s video about AI"))
    assert "script" in result
    mock_client.generate_script.assert_awaited_once_with(prompt="A 60s video about AI")


@pytest.mark.asyncio
async def test_generate_script_with_options(mock_client):
    from hoox_mcp.server import generate_script

    _inject(mock_client)
    await generate_script("Test", duration=30, web_search=True)
    mock_client.generate_script.assert_awaited_once_with(
        prompt="Test", duration=30, webSearch=True
    )


# ------------------------------------------------------------------
# Generation tools
# ------------------------------------------------------------------


@pytest.mark.asyncio
async def test_start_generation(mock_client):
    from hoox_mcp.server import start_generation

    _inject(mock_client)
    result = json.loads(await start_generation(prompt="A video about cats", duration=30))
    assert result["job_id"] == "run_gen_1"
    assert result["status"] == "pending"


@pytest.mark.asyncio
async def test_get_generation_status(mock_client):
    from hoox_mcp.server import get_generation_status

    _inject(mock_client)
    result = json.loads(await get_generation_status("run_gen_1"))
    assert result["status"] == "completed"
    assert result["result"]["video_id"] == "vid_1"


# ------------------------------------------------------------------
# Export tools
# ------------------------------------------------------------------


@pytest.mark.asyncio
async def test_start_export(mock_client):
    from hoox_mcp.server import start_export

    _inject(mock_client)
    result = json.loads(await start_export("vid_1"))
    assert result["job_id"] == "run_exp_1"


@pytest.mark.asyncio
async def test_get_export_status(mock_client):
    from hoox_mcp.server import get_export_status

    _inject(mock_client)
    result = json.loads(await get_export_status("run_exp_1"))
    assert result["status"] == "completed"
    assert "video_url" in result["result"]


# ------------------------------------------------------------------
# Video tools
# ------------------------------------------------------------------


@pytest.mark.asyncio
async def test_duplicate_video(mock_client):
    from hoox_mcp.server import duplicate_video

    _inject(mock_client)
    result = json.loads(await duplicate_video("vid_1", voice_id="v2"))
    assert result["video_id"] == "vid_dup_1"
    mock_client.duplicate_video.assert_awaited_once_with(video_id="vid_1", voice_id="v2")


# ------------------------------------------------------------------
# Error handling
# ------------------------------------------------------------------


@pytest.mark.asyncio
async def test_api_error_returns_json(mock_client):
    from hoox_mcp.server import list_voices

    mock_client.list_voices = AsyncMock(
        side_effect=HooxClientError(401, "invalid_api_key")
    )
    _inject(mock_client)
    result = json.loads(await list_voices())
    assert result["error"] is True
    assert result["status_code"] == 401


@pytest.mark.asyncio
async def test_unexpected_error_returns_json(mock_client):
    from hoox_mcp.server import list_voices

    mock_client.list_voices = AsyncMock(side_effect=RuntimeError("connection lost"))
    _inject(mock_client)
    result = json.loads(await list_voices())
    assert result["error"] is True
    assert "connection lost" in result["detail"]
