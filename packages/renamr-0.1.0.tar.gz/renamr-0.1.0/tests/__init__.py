"""Test suite for renamr."""
