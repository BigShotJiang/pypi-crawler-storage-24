"""Quickstart demo for sending a chat request via OmniLinkChatClient."""

from __future__ import annotations

import os
import pathlib
import sys

# Allow running the script from the repository root without installing the package.
LIB_PATH = pathlib.Path(__file__).resolve().parents[3] / "src"
if str(LIB_PATH) not in sys.path:
    sys.path.insert(0, str(LIB_PATH))

from omnilink import OmniLinkChatClient

BASE_URL = "https://www.omnilink-agents.com"
OMNI_KEY = os.environ.get("OMNI_KEY", "")


def main() -> None:
    if not OMNI_KEY:
        print("Set the OMNI_KEY environment variable before running this script.")
        print("  export OMNI_KEY=omk_...")
        sys.exit(1)

    client = OmniLinkChatClient(base_url=BASE_URL, omni_key=OMNI_KEY)

    result = client.chat(
        "Hello! What can you help me with?",
        agent_name="assistant",
    )

    print("Response:", result.get("text", ""))


if __name__ == "__main__":
    main()
