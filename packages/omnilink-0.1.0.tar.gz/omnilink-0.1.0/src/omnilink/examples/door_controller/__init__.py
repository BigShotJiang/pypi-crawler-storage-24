"""Door controller use case for OmniLink — open and close doors via commands."""
