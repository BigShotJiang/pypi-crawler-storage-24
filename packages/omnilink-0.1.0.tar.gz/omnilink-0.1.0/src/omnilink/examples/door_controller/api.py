"""In-memory door controller used by the OmniLink door controller example."""

from __future__ import annotations

from typing import Any, Dict


_DOORS: Dict[str, bool] = {
    "front_door": False,
    "back_door": False,
    "garage_door": False,
}


def _require_known(door: str) -> str:
    if door not in _DOORS:
        raise KeyError(f"Unknown door: {door}")
    return door


def _denormalize(name: str) -> str:
    return name.replace("_", " ").strip()


def open_door(door: str) -> Dict[str, Any]:
    """Open *door* and return the new state."""
    key = _require_known(door)
    _DOORS[key] = True
    return {"door": _denormalize(key), "is_open": True}


def close_door(door: str) -> Dict[str, Any]:
    """Close *door* and return the new state."""
    key = _require_known(door)
    _DOORS[key] = False
    return {"door": _denormalize(key), "is_open": False}


def get_summary() -> Dict[str, Any]:
    """Return a snapshot of all door states."""
    return {
        "doors": {
            _denormalize(name): {"is_open": state}
            for name, state in sorted(_DOORS.items())
        }
    }


__all__ = ["close_door", "get_summary", "open_door"]
