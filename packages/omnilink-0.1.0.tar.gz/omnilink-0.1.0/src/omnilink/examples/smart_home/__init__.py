"""Smart home use case for the OmniLink Python engine."""

__all__ = []
