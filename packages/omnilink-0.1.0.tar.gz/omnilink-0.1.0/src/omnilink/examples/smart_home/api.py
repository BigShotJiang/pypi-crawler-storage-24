"""In-memory smart home controller used by the OmniLink example."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict


@dataclass
class Thermostat:
    """Simple thermostat state for the smart home example."""

    target_temperature: float = 21.0
    mode: str = "auto"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "target_temperature": round(self.target_temperature, 2),
            "mode": self.mode,
        }


def _denormalize(name: str) -> str:
    """Convert an underscore separated identifier into a human-readable string."""

    return name.replace("_", " ").strip()


_LIGHTS: Dict[str, bool] = {
    "living_room": False,
    "kitchen": False,
    "bedroom": False,
    "office": False,
}
_LOCKS: Dict[str, bool] = {
    "front_door": False,
    "garage_door": False,
    "back_door": False,
}
_THERMOSTAT = Thermostat()


def _require_known(mapping: Dict[str, Any], key: str, kind: str) -> str:
    if key not in mapping:
        raise KeyError(f"Unknown {kind}: {key}")
    return key


def turn_on_light(room: str) -> Dict[str, Any]:
    """Switch ``room`` lights on and return the new state."""

    key = _require_known(_LIGHTS, room, "room")
    _LIGHTS[key] = True
    return {"room": _denormalize(key), "is_on": True}


def turn_off_light(room: str) -> Dict[str, Any]:
    """Switch ``room`` lights off and return the new state."""

    key = _require_known(_LIGHTS, room, "room")
    _LIGHTS[key] = False
    return {"room": _denormalize(key), "is_on": False}


def get_light_status(room: str) -> Dict[str, Any]:
    """Return the on/off status for ``room`` lights."""

    key = _require_known(_LIGHTS, room, "room")
    return {"room": _denormalize(key), "is_on": _LIGHTS[key]}


def lock_door(door: str) -> Dict[str, Any]:
    """Lock ``door`` and report the resulting state."""

    key = _require_known(_LOCKS, door, "door")
    _LOCKS[key] = True
    return {"door": _denormalize(key), "is_locked": True}


def unlock_door(door: str) -> Dict[str, Any]:
    """Unlock ``door`` and report the resulting state."""

    key = _require_known(_LOCKS, door, "door")
    _LOCKS[key] = False
    return {"door": _denormalize(key), "is_locked": False}


def set_thermostat_temperature(value: float) -> Dict[str, Any]:
    """Update the thermostat target temperature."""

    _THERMOSTAT.target_temperature = float(value)
    return _THERMOSTAT.to_dict()


def set_thermostat_mode(mode: str) -> Dict[str, Any]:
    """Change the thermostat control mode."""

    _THERMOSTAT.mode = mode
    return _THERMOSTAT.to_dict()


def get_thermostat_state() -> Dict[str, Any]:
    """Return a dictionary describing the thermostat state."""

    return _THERMOSTAT.to_dict()


def get_summary() -> Dict[str, Any]:
    """Return a snapshot of the smart home state."""

    return {
        "lights": {
            _denormalize(name): state for name, state in sorted(_LIGHTS.items())
        },
        "locks": {
            _denormalize(name): state for name, state in sorted(_LOCKS.items())
        },
        "thermostat": get_thermostat_state(),
    }


__all__ = [
    "get_light_status",
    "get_summary",
    "get_thermostat_state",
    "lock_door",
    "set_thermostat_mode",
    "set_thermostat_temperature",
    "turn_off_light",
    "turn_on_light",
    "unlock_door",
]
