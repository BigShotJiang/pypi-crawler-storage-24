<!-- code2docs:start --># proxy

![version](https://img.shields.io/badge/version-0.1.0-blue) ![python](https://img.shields.io/badge/python-%3E%3D3.11-blue) ![coverage](https://img.shields.io/badge/coverage-unknown-lightgrey) ![functions](https://img.shields.io/badge/functions-1376-green)
> **1376** functions | **118** classes | **148** files | CC̄ = 3.9

> Auto-generated project documentation from source code analysis.

**Author:** Tom Sapletta  
**License:** Apache-2.0  
**Repository:** [https://github.com/wronai/proxy](https://github.com/wronai/proxy)

## Installation

### From PyPI

```bash
pip install proxy
```

### From Source

```bash
git clone https://github.com/wronai/proxy
cd proxy
pip install -e .
```

### Optional Extras

```bash
pip install proxy[gpu]    # gpu features
pip install proxy[jetson]    # jetson features
pip install proxy[vm]    # vm features
pip install proxy[voice]    # voice features
pip install proxy[tts]    # tts features
pip install proxy[test]    # testing tools
pip install proxy[dev]    # development tools
```

## Quick Start

### CLI Usage

```bash
# Generate full documentation for your project
proxy ./my-project

# Only regenerate README
proxy ./my-project --readme-only

# Preview what would be generated (no file writes)
proxy ./my-project --dry-run

# Check documentation health
proxy check ./my-project

# Sync — regenerate only changed modules
proxy sync ./my-project
```

### Python API

```python
from proxy import generate_readme, generate_docs, Code2DocsConfig

# Quick: generate README
generate_readme("./my-project")

# Full: generate all documentation
config = Code2DocsConfig(project_name="mylib", verbose=True)
docs = generate_docs("./my-project", config=config)
```

## Generated Output

When you run `proxy`, the following files are produced:

```
<project>/
├── README.md                 # Main project README (auto-generated sections)
├── docs/
│   ├── api.md               # Consolidated API reference
│   ├── modules.md           # Module documentation with metrics
│   ├── architecture.md      # Architecture overview with diagrams
│   ├── dependency-graph.md  # Module dependency graphs
│   ├── coverage.md          # Docstring coverage report
│   ├── getting-started.md   # Getting started guide
│   ├── configuration.md    # Configuration reference
│   └── api-changelog.md    # API change tracking
├── examples/
│   ├── quickstart.py       # Basic usage examples
│   └── advanced_usage.py   # Advanced usage examples
├── CONTRIBUTING.md         # Contribution guidelines
└── mkdocs.yml             # MkDocs site configuration
```

## Configuration

Create `proxy.yaml` in your project root (or run `proxy init`):

```yaml
project:
  name: my-project
  source: ./
  output: ./docs/

readme:
  sections:
    - overview
    - install
    - quickstart
    - api
    - structure
  badges:
    - version
    - python
    - coverage
  sync_markers: true

docs:
  api_reference: true
  module_docs: true
  architecture: true
  changelog: true

examples:
  auto_generate: true
  from_entry_points: true

sync:
  strategy: markers    # markers | full | git-diff
  watch: false
  ignore:
    - "tests/"
    - "__pycache__"
```

## Sync Markers

proxy can update only specific sections of an existing README using HTML comment markers:

```markdown
<!-- proxy:start -->
# Project Title
... auto-generated content ...
<!-- proxy:end -->
```

Content outside the markers is preserved when regenerating. Enable this with `sync_markers: true` in your configuration.

## Architecture

```
proxy/
        ├── advanced_usage    ├── seed_sprint8        ├── quickstart    ├── proxym/    ├── proxym-voice-chat        ├── ctl        ├── storage        ├── config        ├── dashboard/            ├── _projects_api            ├── _users_api            ├── _system            ├── _costs            ├── tickets            ├── _tickets_api            ├── _accounts            ├── _vms        ├── projects/        ├── cache/            ├── users        ├── middleware/            ├── adapters            ├── _tools_api        ├── tools/            ├── _infra            ├── _enums        ├── virt/            ├── browser_profiles            ├── _vm_config            ├── _check            ├── _snapshot            ├── _project            ├── clonebox_adapter            ├── _config            ├── executor            ├── _state            ├── system            ├── browser            ├── observability            ├── _lifecycle            ├── diagnostics        ├── cli/            ├── context            ├── vms            ├── chat            ├── _client            ├── voice            ├── tickets            ├── smart_defaults            ├── tts            ├── _orchestrator            ├── dsl            ├── vscode            ├── accounts            ├── _helpers            ├── registry        ├── mcp/        ├── providers/            ├── client            ├── _tools_accounts            ├── router            ├── _tools_system            ├── _tools_tickets            ├── self_server            ├── _tools_vm            ├── health_events        ├── observability/        ├── accounts/            ├── watchdog            ├── repair_agent        ├── context/            ├── _context            ├── detector            ├── tool_selector            ├── session            ├── strategy            ├── _diag_common            ├── _diag_proxy        ├── router/            ├── voice_actions            ├── _diag_roo            ├── observability_api            ├── system            ├── completions            ├── vscode_api        ├── api/            ├── _diag_agent            ├── diagnostics            ├── console            ├── _diag_providers            ├── _diag_vscode            ├── _pipeline            ├── context_api            ├── _state            ├── client            ├── frontend        ├── watch/                ├── tickets_ctl            ├── _groups/                ├── diagnostics_ctl                ├── accounts_ctl                ├── projects_ctl                ├── context_ctl                ├── observability_ctl                ├── tools_ctl                ├── vscode_ctl                ├── vms_ctl                ├── browser_ctl            ├── profiles/        ├── proxym_tools            ├── api                ├── formatters    ├── proxym-dashboard            ├── panel                ├── do_ctl                ├── useDashboardData                ├── voice                ├── diagnostics                ├── voice_engine                ├── logs                ├── ui                ├── vms                ├── tasks                ├── overview                ├── tickets                ├── models                ├── projects                ├── voice_schemas                ├── system                ├── home                ├── layout                ├── accounts                ├── tools                    ├── DiagConfig                ├── users                    ├── helpers                    ├── DiagExtensions                    ├── DiagInfrastructure├── project    ├── jetson-entrypoint                    ├── DiagAgent    ├── evaluate_llm_work    ├── setup    ├── proxym-voice-server    ├── validate_system        ├── entrypoint                ├── setup        ├── main```

## API Overview

### Classes

- **`SQLiteNamespaceStore`** — —
- **`Settings`** — All settings with sensible defaults. Override via env vars or .env file.
- **`AddProjectReq`** — Dodaj projekt — jedno z: path, git_url, ssh.
- **`UpdateProjectReq`** — —
- **`ScanReq`** — —
- **`CreateUserRequest`** — —
- **`UpdateUserRequest`** — —
- **`TicketStatus`** — —
- **`TicketPriority`** — —
- **`TicketType`** — —
- **`SprintStatus`** — —
- **`ToolAssignment`** — Which tool is assigned to work on a ticket.
- **`JobExecution`** — Snapshot of the latest job execution for a ticket.
- **`TicketComment`** — —
- **`Ticket`** — —
- **`Sprint`** — —
- **`TicketManager`** — In-memory ticket & sprint store with optional JSON persistence.
- **`CreateTicketReq`** — —
- **`UpdateTicketReq`** — —
- **`AssignToolReq`** — —
- **`AddCommentReq`** — —
- **`CreateSprintReq`** — —
- **`UpdateSprintReq`** — —
- **`CreateAccountReq`** — —
- **`BindToolReq`** — —
- **`CreateVMReq`** — —
- **`SwitchProjectReq`** — —
- **`SourceType`** — —
- **`ProjectStatus`** — —
- **`Project`** — Jeden projekt w systemie proxym.
- **`ProjectRegistry`** — Rejestr projektów z persystencją JSON.
- **`FileSnapshot`** — Immutable snapshot of a single file.
- **`DeltaPayload`** — Computed delta between two context snapshots.
- **`DeltaBuffer`** — Maintains file snapshots and computes minimal diffs.
- **`UserRole`** — User roles in the system.
- **`User`** — A user in the system, identified by git configuration.
- **`UserManager`** — In-memory user store with SQLite persistence and git integration.
- **`AuthMiddleware`** — Simple bearer token auth (matches LiteLLM master_key pattern).
- **`CostTrackingMiddleware`** — Log request timing and attach cost headers to responses.
- **`ToolResult`** — Result of a tool execution.
- **`BaseAdapter`** — Base class for tool adapters.
- **`AiderAdapter`** — Adapter for aider CLI.
- **`ClaudeCodeAdapter`** — Adapter for claude CLI (Anthropic Claude Code).
- **`VSCodeAdapter`** — Adapter for VS Code Web / code-server (starts container, sends task via API).
- **`ShellAdapter`** — Generic shell adapter — runs tool binary with prompt via stdin/args.
- **`DispatchRequest`** — —
- **`PreviewPromptRequest`** — —
- **`AutoFixRequest`** — —
- **`ToolProviderRequest`** — —
- **`ToolCategory`** — High-level tool categories.
- **`ToolCapability`** — Capabilities a tool can advertise.
- **`ToolInstance`** — Concrete runtime instance for a registered tool.
- **`ToolDefinition`** — Describes a registered development tool.
- **`ToolRegistry`** — Singleton registry of available development tools.
- **`VMBackend`** — —
- **`VMState`** — —
- **`BrowserProfile`** — Detected browser profile on the host.
- **`AppDataSync`** — Configuration for syncing browser data into a VM.
- **`CloneBoxResult`** — Result of a clonebox CLI invocation.
- **`CloneBoxAdapter`** — Adapter wrapping the clonebox CLI for VM operations.
- **`ProjectsConfig`** — Configuration for shared project mounts from the host.
- **`VMConfig`** — Configuration for a development VM.
- **`VMStatus`** — Runtime status of a VM.
- **`JobStatus`** — —
- **`ToolJob`** — A single tool execution job.
- **`ToolExecutor`** — Async executor for tool jobs with a bounded queue.
- **`VoiceListener`** — Local STT: microphone → text via Faster-Whisper.
- **`TTSEngine`** — Text-to-speech engine with pluggable backends.
- **`VMOrchestrator`** — Manages VMs for isolated dev environments.
- **`ParsedCommand`** — Result of successfully parsing a user phrase against the DSL.
- **`DSLParser`** — Parse natural language phrases into proxym API calls.
- **`MCPTransport`** — Transport protocol for MCP communication.
- **`MCPServerSpec`** — Specification of a registered MCP server.
- **`MCPRegistry`** — Registry of available MCP servers.
- **`TaskTier`** — Complexity tier that determines which model class is needed.
- **`Capability`** — —
- **`ModelSpec`** — Immutable specification for a single model deployment.
- **`MCPToolResult`** — Result of an MCP tool invocation.
- **`MCPClient`** — HTTP client for MCP server communication.
- **`AccountAddRequest`** — —
- **`MCPRouter`** — Routes tool requests to appropriate MCP servers.
- **`TicketCreateRequest`** — —
- **`TicketAssignRequest`** — —
- **`SprintCreateRequest`** — —
- **`VMCreateRequest`** — —
- **`VMActionRequest`** — —
- **`VMSnapshotRequest`** — —
- **`VMSwitchRequest`** — —
- **`Severity`** — —
- **`HealthEvent`** — Jedno zdarzenie zdrowia systemu.
- **`HealthEventStore`** — In-memory store zdarzeń z persystencją opcjonalną.
- **`ProviderType`** — —
- **`ToolType`** — —
- **`AccountCredentials`** — Credentials for a single provider account.
- **`UsageMetrics`** — Tracked usage for a single account.
- **`AccountLimits`** — Provider-imposed and user-defined limits.
- **`ToolBinding`** — Binds an account to a specific tool/IDE instance.
- **`Account`** — Single provider account with all associated data.
- **`AccountManager`** — Central account registry.
- **`HealthWatchdog`** — Daemon sprawdzający zdrowie systemu w pętli.
- **`RepairAgent`** — Agent naprawiający błędy w kodzie proxym za pomocą LLM.
- **`ProjectContext`** — Detected project context for a request.
- **`AgentSession`** — Stateful session for an agent working on a project.
- **`SessionStore`** — In-memory session store with TTL-based expiry.
- **`RoutingDecision`** — Complete routing decision with audit trail.
- **`CostLedger`** — In-memory cost ledger with Redis persistence.
- **`Router`** — Stateful router that selects the optimal model per request.
- **`AnalysisResult`** — Result of content analysis.
- **`RepairRequest`** — —
- **`CompletionPipeline`** — Structured pipeline for processing a chat completion request.
- **`DeltaWatchClient`** — Watches a directory and pushes context deltas to the proxy server.
- **`ProxymTools`** — Tools for managing proxym AI proxy from Open WebUI.

### Functions

- `main()` — —
- `check_voice_deps()` — Sprawdź czy zależności głosowe są zainstalowane.
- `install_voice_deps()` — Zainstaluj zależności głosowe.
- `main()` — —
- `cli(ctx, proxy, key, fmt)` — Proxym — intelligent AI proxy with VM isolation.
- `serve(host, port, reload)` — Start the proxy server.
- `status(ctx, fmt)` — Show system status.
- `models(ctx, fmt)` — List available models.
- `chat(ctx, voice, tts)` — Interactive chat — DSL first, LLM fallback.
- `logs_cmd(ctx, lines, level)` — Show proxy logs.
- `providers_cmd(ctx)` — List configured providers and their status.
- `routing_test_cmd(ctx)` — Dry-run routing test — check which model would be selected.
- `projects_cmd(ctx)` — List available projects (shortcut for 'project list').
- `fix_cmd(ctx, description, project_name)` — Shortcut: fix a bug.  = proxym do "..." --type bug
- `refactor_cmd(ctx, description, project_name)` — Shortcut: refactor code.  = proxym do "..." --type refactor --with claude-code
- `queue_shortcut(ctx)` — Shortcut: show task queue.  = proxym tools queue
- `web_cmd(ctx, tab)` — Open dashboard in browser.  proxym web [home|projects|tasks|system|voice]
- `log_shortcut(ctx, lines)` — Shortcut: show recent logs.  = proxym logs -n 20
- `is_sqlite_database(path)` — —
- `get_settings()` — —
- `list_projects(status, source_type)` — Lista wszystkich projektów.
- `get_project(project_id)` — —
- `add_project(req)` — Dodaj projekt — auto-detect typu z podanych parametrów.
- `update_project(project_id, req)` — —
- `remove_project(project_id)` — —
- `scan_directory(req)` — Skanuj folder i dodaj znalezione projekty.
- `project_tickets(project_id)` — Tickety powiązane z projektem.
- `create_project_ticket(project_id, req)` — Stwórz ticket od razu powiązany z projektem.
- `list_users(active_only)` — List all users.
- `create_user(req)` — Create a new user.
- `sync_git_users(repo_path)` — Sync users from git commit history.
- `get_default_user()` — Get the default/delegated user.
- `set_default_user(user_id)` — Set a user as the default/delegated user.
- `get_user(user_id)` — Get a specific user.
- `update_user(user_id, req)` — Update a user.
- `delete_user(user_id)` — Delete a user.
- `dashboard_root()` — Dashboard root - redirects to system status.
- `system_status()` — Full system overview: accounts + VMs + costs + libvirt + providers + watchdog + repair.
- `list_providers()` — Show configured providers from .env and their model counts.
- `get_logs(lines, level)` — Get recent log entries from proxym log file.
- `cost_summary()` — Aggregate cost dashboard across all accounts.
- `cost_detailed()` — Per-account cost breakdown.
- `list_tools()` — Return available VM tool profiles (host/browser environments).
- `list_tickets(sprint_id, status, priority, tool)` — List tickets with optional filters.
- `create_ticket(task, title, project_id, description)` — Create a new ticket. Accepts 'task' (new) or 'title' (legacy).
- `ticket_board(sprint_id)` — Kanban board view: tickets grouped by status columns.
- `get_ticket(ticket_id)` — Get ticket details including comments.
- `update_ticket(ticket_id, task, title, project_id)` — Update a ticket's fields.
- `delete_ticket(ticket_id)` — Delete a ticket.
- `assign_ticket_tool(ticket_id, tool, agent_mode, model)` — Assign a tool (vscode, aider, claude-code, etc.) to work on a ticket.
- `add_ticket_comment(ticket_id, author, content)` — Add a comment to a ticket (from any tool or user).
- `list_sprints(status)` — List sprints.
- `create_sprint(req)` — Create a new sprint.
- `get_sprint(sprint_id)` — Get sprint details with ticket stats.
- `update_sprint(sprint_id, req)` — Update sprint fields.
- `delete_sprint(sprint_id)` — Delete a sprint.
- `list_accounts(provider, tag)` — —
- `create_account(req)` — —
- `get_account(account_id)` — —
- `delete_account(account_id)` — —
- `bind_tool(account_id, req)` — —
- `list_vms()` — —
- `create_vm(req)` — —
- `start_vm(vm_id)` — —
- `stop_vm(vm_id, force)` — —
- `pause_vm(vm_id)` — —
- `resume_vm(vm_id)` — —
- `snapshot_vm(vm_id, name)` — —
- `switch_project(vm_id, req)` — —
- `delete_vm(vm_id)` — —
- `delete_vm_post(vm_id)` — POST variant for single VM deletion (matches frontend convention).
- `bulk_delete_vms(req)` — Delete multiple VMs by their IDs. Returns list of successfully deleted VM IDs.
- `get_adapter(tool_name)` — Return an adapter instance for the named tool, or None.
- `register_adapter(tool_name, adapter_cls)` — Register a custom adapter class for a tool.
- `list_tools(category, available_only)` — List all registered tools.
- `tools_summary()` — Summary of tool availability.
- `preview_prompt(req)` — Preview the prompt that would be sent to a tool for a ticket.
- `dispatch_job(req)` — Dispatch a tool to work on a ticket. Enqueues a job.
- `queue_status()` — Get queue summary and recent jobs.
- `list_jobs(status, limit)` — List jobs with optional status filter.
- `get_job(job_id)` — Get details for a specific job.
- `cancel_job(job_id)` — Cancel a queued job.
- `retry_job(job_id)` — Retry a failed job — re-enqueue with same parameters.
- `repair_job(job_id)` — Run auto-diagnosis on a failed job and suggest/apply fixes.
- `execute_autofix(req)` — Execute an automatic fix for a tool issue.
- `bulk_autofix()` — Run auto-fix for all degraded tools that support automatic fixes.
- `start_executor()` — Start the background executor loop.
- `stop_executor()` — Stop the background executor loop.
- `tools_healthcheck()` — Comprehensive health check for every registered tool.
- `set_tool_provider(req)` — Assign an LLM provider to a specific tool.
- `get_tool_providers()` — Get current tool → provider mappings.
- `get_tool(tool_name)` — Get details for a specific tool.
- `detect_firefox_profiles()` — Detect Firefox profiles by parsing profiles.ini.
- `detect_chrome_profiles()` — Detect Google Chrome profiles by parsing Local State.
- `detect_chromium_profiles()` — Detect Chromium profiles by parsing Local State.
- `detect_all_profiles()` — Detect all browser profiles on the host.
- `generate_app_data_sync(profile, with_passwords)` — Generate an AppDataSync config for copying a profile into a VM.
- `cmd_serve(args)` — Start the proxy server (delegates to proxym.main:cli).
- `cmd_status(args)` — Show system status (YAML or human-readable).
- `cmd_models(args)` — —
- `cmd_browser_list(args)` — List detected browser profiles on the host.
- `cmd_browser_assign(args)` — Assign a browser profile to an account.
- `cmd_browser_sync(args)` — Sync browser profile host ↔ VM.
- `cmd_browser_snapshot(args)` — Save browser state from VM as snapshot.
- `cmd_obs_errors(args)` — —
- `cmd_obs_health(args)` — —
- `cmd_obs_repair(args)` — —
- `cmd_obs_logs(args)` — —
- `cmd_tests_status(args)` — Run all diagnostic tests and show results.
- `cmd_test_vscode(args)` — Test VS Code Web connectivity.
- `cmd_test_proxy(args)` — Test LLM proxy connectivity.
- `cmd_test_providers(args)` — Check configured LLM providers.
- `cmd_test_extensions(args)` — Check installed VS Code extensions.
- `cmd_test_agent_setup(args)` — Comprehensive agent readiness check.
- `cmd_test_agent(args)` — Test agent with a simple completion.
- `cmd_context_delta(args)` — Push a context delta to the proxy.
- `cmd_context_detect(args)` — Detect project context from messages or paths.
- `cmd_context_stats(args)` — Show context store statistics.
- `cmd_sessions_list(args)` — List active agent sessions.
- `cmd_mcp_servers(args)` — List registered MCP servers.
- `cmd_vm_list(args)` — —
- `cmd_vm_create(args)` — —
- `cmd_vm_action(args)` — —
- `cmd_vm_switch(args)` — —
- `cmd_vm_open(args)` — Open SPICE viewer for a VM (virt-viewer).
- `cmd_vm_ssh(args)` — SSH into a VM (auto-detect IP via dashboard).
- `cmd_vm_logs(args)` — Show cloud-init logs and tool logs from a VM.
- `cmd_vm_delete(args)` — Delete a VM.
- `cmd_vm_console(args)` — Open web console for a VM (prints noVNC URL).
- `cmd_vm_bulk_delete(args)` — Delete multiple VMs.
- `cmd_chat(args)` — Interactive chat with proxym — DSL first, LLM fallback.
- `make_client(base, key)` — Create HTTP client with configuration from settings.
- `print_json(data)` — —
- `print_table(rows, columns, widths)` — —
- `cmd_ticket_list(args)` — List tickets with optional filters.
- `cmd_ticket_create(args)` — Create a new ticket.
- `cmd_ticket_show(args)` — Show ticket details.
- `cmd_ticket_update(args)` — Update a ticket.
- `cmd_ticket_assign(args)` — Assign a tool to a ticket.
- `cmd_ticket_comment(args)` — Add a comment to a ticket.
- `cmd_ticket_delete(args)` — Delete a ticket.
- `cmd_sprint_list(args)` — List sprints.
- `cmd_sprint_create(args)` — Create a new sprint.
- `cmd_sprint_show(args)` — Show sprint details.
- `cmd_sprint_update(args)` — Update a sprint.
- `cmd_sprint_delete(args)` — Delete a sprint.
- `cmd_board(args)` — Show kanban board.
- `detect_ticket_type(task)` — Guess ticket type from natural-language task description.
- `default_priority(ticket_type)` — Return sensible default priority for a ticket type.
- `resolve_tool(ticket_type, project, explicit)` — Pick the best tool: explicit > project default > type hint.
- `resolve_project(projects, explicit)` — Find project: explicit name/id → CWD match → single → most recent.
- `cmd_vscode_start(args)` — Start VS Code Web (docker compose --profile vscode up -d).
- `cmd_vscode_stop(args)` — Stop VS Code Web.
- `cmd_vscode_open(args)` — Open VS Code Web in the default browser.
- `cmd_vscode_logs(args)` — Show VS Code Web logs (follows).
- `cmd_vscode_status(args)` — Show VS Code Web container status.
- `cmd_vscode_build(args)` — Rebuild VS Code Web image.
- `cmd_accounts_list(args)` — —
- `cmd_accounts_add(args)` — —
- `cmd_accounts_costs(args)` — —
- `cmd_accounts_get(args)` — —
- `cmd_accounts_delete(args)` — —
- `cmd_accounts_bind_tool(args)` — —
- `models_for_tier(tier, required_caps, available_providers)` — Return models suitable for a tier, sorted by effective cost ascending.
- `cheapest_model(tier, available_providers, required_caps)` — Return the single cheapest model that satisfies constraints.
- `get_model(model_id)` — —
- `tool_account_list()` — List all accounts with costs.
- `tool_account_costs()` — Cost summary per account and model.
- `tool_account_add(req)` — Add a new API account.
- `tool_status()` — Full system status: proxy, VMs, accounts, costs.
- `tool_logs(lines, level)` — Recent proxym logs.
- `tool_models()` — List available models with prices.
- `tool_ticket_list(sprint_id, status, tool)` — List tickets, optionally filtered by sprint, status, or assigned tool.
- `tool_ticket_create(req)` — Create a new ticket in the task management system.
- `tool_ticket_assign(req)` — Assign a development tool to work on a ticket.
- `tool_ticket_board(sprint_id)` — Get kanban board view of tickets grouped by status.
- `tool_sprint_create(req)` — Create a new sprint.
- `tool_vm_list()` — List all VMs with their status.
- `tool_vm_create(req)` — Create a new VM with an AI tool.
- `tool_vm_start(req)` — Start a stopped VM.
- `tool_vm_stop(req)` — Stop a running VM.
- `tool_vm_snapshot(req)` — Create a VM snapshot.
- `tool_vm_switch_project(req)` — Switch project in a running VM.
- `get_health_store()` — —
- `get_log_buffer(limit, level)` — Pobierz ostatnie logi z bufora.
- `get_error_summary()` — Podsumowanie błędów z ostatnich logów.
- `log_call()` — Dekorator logujący wywołanie, czas i błędy.
- `log_endpoint()` — Dekorator dla FastAPI endpointów — loguje request/response + timing.
- `retry_with_log(max_retries, backoff_base, retryable)` — Retry z exponential backoff i logowaniem każdej próby.
- `detect_project(messages, headers)` — Detect project context from request data.
- `select_tools(context, analysis, available_servers)` — Select MCP servers for a given project and task analysis.
- `check_llm_proxy(base_url)` — Check LLM proxy connectivity and available models.
- `analyze_request(messages)` — Analyze a chat completion request and return routing metadata.
- `vms_list()` — List VMs (alias for GET /dashboard/vms).
- `vms_start(vm_id)` — Start VM (alias for POST /dashboard/vms/{vm_id}/start).
- `vms_stop(vm_id, force)` — Stop VM (alias for POST /dashboard/vms/{vm_id}/stop).
- `vms_snapshot(vm_id, name)` — Snapshot VM (alias for POST /dashboard/vms/{vm_id}/snapshot).
- `accounts_list(provider, tag)` — List accounts (alias for GET /dashboard/accounts).
- `dashboard_costs_summary()` — Cost summary used by voice UI.
- `logs_list(lines, level)` — Recent logs (alias for GET /dashboard/logs).
- `voice_tickets(status)` — List tickets — voice-friendly summary.
- `voice_diagnose()` — Run diagnostics — voice-friendly summary.
- `check_roo_cline_config()` — Check if Roo Code is configured in VS Code settings.
- `obs_logs(limit, level)` — Ring buffer logs — ostatnie N wpisów z dekoratorów.
- `obs_errors()` — Podsumowanie błędów z ring buffer.
- `obs_health_events(limit, severity)` — Historia zdarzeń zdrowia systemu.
- `obs_health_summary()` — Aktywne problemy i podsumowanie.
- `obs_repair(req)` — Uruchom LLM repair agent na wskazanym błędzie.
- `obs_repair_from_logs()` — Auto-diagnozuj najczęstszy błąd z ring buffer.
- `obs_repair_history(limit)` — Historia napraw wykonanych przez repair agent.
- `get_cost_ledger()` — —
- `favicon()` — Return empty favicon to prevent 401 errors.
- `health(request, authorization, x_api_key)` — Health check with optional VM identification.
- `list_models()` — List available models (OpenAI-compatible) including model aliases.
- `budget_status()` — Return current budget usage.
- `completion()` — —
- `chat_completions(request, x_task_tier)` — OpenAI-compatible chat completions with intelligent routing.
- `vscode_status()` — —
- `vscode_start()` — —
- `vscode_stop()` — —
- `vscode_restart()` — —
- `vscode_logs(lines)` — —
- `vscode_build()` — —
- `check_copilot_conflict()` — Detect GitHub Copilot / Copilot Chat extension conflicts.
- `check_agent_setup(base_url)` — Comprehensive agent readiness check — config + connectivity + extension.
- `test_agent_completion()` — Test a simple completion through the proxy to verify agent functionality.
- `run_all_tests(request)` — Run all diagnostic tests and return comprehensive status.
- `test_vscode()` — Test VS Code Web connectivity.
- `test_proxy(request)` — Test LLM proxy connectivity.
- `test_roo()` — Test Roo Code configuration.
- `test_extensions()` — Check installed VS Code extensions.
- `test_providers()` — Check configured LLM providers and model aliases.
- `test_copilot()` — Detect GitHub Copilot extension conflicts.
- `test_agent_setup(request)` — Comprehensive agent readiness check.
- `test_agent()` — Test agent with a simple completion.
- `routing_test()` — Return routing status (no network calls).
- `ollama_status()` — Check Ollama connectivity and list available local models.
- `vm_console(vm_id)` — Return noVNC connection URL for a running VM.
- `check_providers_config()` — Check which LLM providers are configured with API keys.
- `check_vscode_status()` — Check if VS Code Web is running and accessible.
- `check_extensions()` — Check installed VS Code extensions via docker exec.
- `get_context_store()` — —
- `get_mcp_registry()` — —
- `receive_delta(request)` — Receive context delta from the file watcher client.
- `detect_context(request)` — Detect project context from request body (messages + headers).
- `list_sessions()` — List active agent sessions.
- `list_mcp_servers()` — List registered MCP servers.
- `context_stats()` — Return context store statistics.
- `get_router()` — —
- `get_delta_buffer()` — —
- `get_mcp_router()` — —
- `get_session_store()` — —
- `get_context_payload()` — —
- `set_context_payload(payload)` — —
- `root_redirect()` — Redirect root to dashboard.
- `dashboard_ui()` — Serve the React dashboard UI.
- `dashboard_hook_js()` — Serve the useDashboardData hook (plain JS, no Babel needed).
- `dashboard_api_js()` — Serve the dashboard API client (plain JS, no Babel needed).
- `dashboard_formatters_js()` — Serve formatters utility (plain JS, no Babel needed).
- `dashboard_ui_jsx()` — Serve UI primitives: StatusBadge, CostBar, Card, StateBadge.
- `dashboard_models_jsx()` — Serve ModelsTable component.
- `dashboard_accounts_jsx()` — Serve Accounts components.
- `dashboard_layout_jsx()` — Serve layout components: DashboardHeader, TabNav.
- `dashboard_overview_jsx()` — Serve overview components: CostSummary, BudgetCards, SystemCard, ProvidersCard, OverviewTab.
- `dashboard_vms_jsx()` — Serve VMs components with sort/selection hooks.
- `dashboard_logs_jsx()` — Serve LogPanel with useLogFilter hook.
- `dashboard_voice_schemas_jsx()` — Serve VoiceChat action/tool schemas.
- `dashboard_voice_engine_jsx()` — Serve VoiceChat engine helpers (apiCall, matchDSL, etc.).
- `dashboard_voice_jsx()` — Serve VoiceChat component (Web Speech API STT/TTS + LLM chat).
- `dashboard_projects_jsx()` — Serve ProjectsPanel component (project management).
- `dashboard_tickets_jsx()` — Serve TicketsPanel component (tickets & sprints management).
- `dashboard_diag_helpers_jsx()` — Serve diagnostics shared helpers: _diagBadge, _diagWarnBadge, _diagRow.
- `dashboard_diag_infrastructure_jsx()` — Serve DiagVSCode + DiagProxy cards.
- `dashboard_diag_config_jsx()` — Serve DiagRooConfig + DiagProviders cards.
- `dashboard_diag_extensions_jsx()` — Serve DiagExtensions + DiagCopilot cards.
- `dashboard_diag_agent_jsx()` — Serve DiagAgentSetup + DiagAgentTest cards.
- `dashboard_tools_jsx()` — Serve ToolsPanel component (tool registry, dispatch, job queue).
- `dashboard_home_jsx()` — Serve HomeTab: QuickDo, health/budget/queue cards, recent activity.
- `dashboard_tasks_jsx()` — Serve TasksPanel: unified tickets + tools board with inline logs.
- `dashboard_system_jsx()` — Serve SystemPanel: merged models + providers + diagnostics.
- `dashboard_diagnostics_jsx()` — Serve DiagnosticsPanel for testing VS Code, proxy, and agent.
- `dashboard_setup_jsx()` — Serve SetupPanel: guided checklist for first-time project setup.
- `dashboard_jsx()` — Serve the React dashboard JSX entry point.
- `get_frontend_config(request)` — Return configuration for frontend.
- `cli()` — CLI entry point for proxym-client.
- `ticket()` — Manage tickets (task tracking for multi-tool workflows).
- `ticket_list(ctx, status, tool, sprint)` — List tickets.
- `ticket_add(ctx, task, project, tool)` — Create a ticket (minimalistic). Example: proxym ticket add 'fix the router bug'
- `ticket_create(ctx, title, description, type)` — Create a new ticket (legacy — prefer 'ticket add').
- `ticket_show(ctx, ticket_id)` — Show ticket details.
- `ticket_update(ctx, ticket_id, title, status)` — Update a ticket.
- `ticket_assign(ctx, ticket_id, tool, mode)` — Assign a tool to work on a ticket.
- `ticket_comment(ctx, ticket_id, author, content)` — Add a comment to a ticket.
- `ticket_delete(ctx, ticket_id)` — Delete a ticket.
- `ticket_board(ctx, sprint)` — Show kanban board view.
- `sprint()` — Manage sprints.
- `sprint_list(ctx, status)` — List sprints.
- `sprint_create(ctx, name, goal, start)` — Create a new sprint.
- `sprint_show(ctx, sprint_id)` — Show sprint details and stats.
- `sprint_update(ctx, sprint_id, name, status)` — Update a sprint.
- `sprint_delete(ctx, sprint_id)` — Delete a sprint.
- `sprint_board(ctx, sprint)` — Show kanban board view.
- `tests()` — Run system diagnostics.
- `tests_status(ctx, fmt)` — Run all diagnostic tests.
- `tests_vscode(ctx)` — Test VS Code Web connectivity.
- `tests_proxy(ctx)` — Test LLM proxy connectivity.
- `tests_providers(ctx, fmt)` — Check configured LLM providers.
- `tests_extensions(ctx, fmt)` — Check installed VS Code extensions.
- `tests_agent_setup(ctx)` — Comprehensive agent readiness check.
- `tests_agent(ctx)` — Test agent with a simple completion.
- `diagnose()` — Run diagnostics to verify system health (alias for 'tests').
- `diagnose_all(ctx, fmt)` — Run all diagnostic tests.
- `diagnose_proxy(ctx)` — Test proxy connectivity.
- `diagnose_vscode(ctx)` — Test VS Code Web status.
- `diagnose_providers(ctx, fmt)` — Test provider configuration.
- `diagnose_agent(ctx)` — Test agent setup + completion.
- `diagnose_one(ctx, test_name)` — Run a specific test (vscode|proxy|roo|extensions|providers|copilot|agent-setup|agent).
- `accounts()` — Manage accounts.
- `accounts_list(ctx)` — List accounts.
- `accounts_add(ctx, name, provider, api_key)` — Add account.
- `accounts_costs(ctx)` — Show cost breakdown.
- `accounts_get(ctx, account_id)` — Show single account details.
- `accounts_delete(ctx, account_id)` — Delete an account.
- `accounts_bind_tool(ctx, account_id, tool_type, tool_name)` — Bind a tool to an account.
- `project()` — Manage projects (local, git, SSH, FTP).
- `project_list(ctx, source_type, status)` — List registered projects.
- `project_add(ctx, path_or_url, git, ssh)` — Add a project. Accepts local path, --git URL, or --ssh user@host:/path.
- `project_scan(ctx, directory)` — Scan a directory for projects and register them.
- `project_show(ctx, project_id)` — Show project details.
- `project_remove(ctx, project_id)` — Remove a project from the registry.
- `project_task(ctx, project_name, task_text, tool)` — Create a ticket for a project (shortcut for 'ticket add --project').
- `context()` — Manage context, sessions, and MCP servers.
- `context_delta(ctx, project_id, diff_text, file)` — Push a context delta to the proxy.
- `context_detect(ctx, message, system_prompt, paths)` — Detect project context from messages or paths.
- `context_stats(ctx, fmt)` — Show context store statistics.
- `context_sessions(ctx, fmt)` — List active agent sessions.
- `context_mcp(ctx, fmt)` — List registered MCP servers.
- `obs()` — Observability: logs, errors, health, repair.
- `obs_errors(ctx)` — Show error summary from ring buffer.
- `obs_health(ctx)` — Show health summary and active issues.
- `obs_logs(ctx, limit, level)` — Show recent observability logs from ring buffer.
- `obs_repair(ctx, error, mode, from_logs)` — Run LLM repair agent on an error.
- `tools()` — Manage AI development tools and job queue.
- `tools_list(ctx, category, available)` — List registered tools.
- `tools_show(ctx, tool_name)` — Show details for a specific tool.
- `tools_dispatch(ctx, ticket, tool, mode)` — Dispatch a tool to work on a ticket.
- `tools_queue(ctx)` — Show job queue status.
- `tools_jobs(ctx, status, limit)` — List jobs.
- `tools_job(ctx, job_id)` — Show details for a specific job.
- `tools_cancel(ctx, job_id)` — Cancel a queued job.
- `tools_retry(ctx, job_id)` — Retry a failed or cancelled job.
- `tools_repair(ctx, job_id)` — Run diagnosis for a failed job and print suggestions.
- `tools_start(ctx)` — Start the background executor.
- `tools_stop(ctx)` — Stop the background executor.
- `vscode()` — Manage VS Code Web service.
- `vscode_start(ctx)` — Start VS Code Web (docker compose up vscode).
- `vscode_stop(ctx)` — Stop VS Code Web.
- `vscode_open(ctx)` — Open VS Code Web in browser.
- `vscode_logs(ctx)` — Show VS Code Web logs.
- `vscode_status_cmd(ctx)` — Show VS Code Web container status.
- `vscode_build(ctx)` — Rebuild VS Code Web image.
- `vm()` — Manage VMs.
- `vm_list(ctx)` — List VMs.
- `vm_create(ctx, name, tool, account)` — Create VM.
- `vm_start(ctx, vm_id)` — Start a VM.
- `vm_stop(ctx, vm_id, force)` — Stop a VM.
- `vm_pause(ctx, vm_id)` — Pause a VM.
- `vm_resume(ctx, vm_id)` — Resume a VM.
- `vm_snapshot(ctx, vm_id, name)` — Snapshot a VM.
- `vm_switch(ctx, vm_id, project)` — Switch project in VM.
- `vm_open(ctx, vm_id)` — Open SPICE viewer.
- `vm_ssh(ctx, vm_id, user)` — SSH into VM.
- `vm_logs(ctx, vm_id)` — Show VM logs.
- `vm_delete(ctx, vm_id)` — Delete a VM.
- `vm_bulk_delete(ctx, vm_ids)` — Delete multiple VMs.
- `vm_console(ctx, vm_id)` — Open web console for a VM (prints noVNC URL).
- `browser()` — Manage browser profiles.
- `browser_list(ctx)` — List host browser profiles.
- `browser_assign(ctx, profile, account)` — Assign profile to account.
- `browser_sync(ctx, vm_id)` — Sync browser profile host <-> VM.
- `browser_snapshot(ctx, vm_id)` — Save browser state from VM.
- `get_builtin_profile(tool)` — Get the path to a built-in profile YAML for a tool.
- `list_builtin_profiles()` — List all available built-in profile names.
- `merge_profiles(base, override)` — Deep-merge two profile dicts. Override values take precedence.
- `load_profile_yaml(path)` — Load a YAML profile, with graceful fallback if PyYAML is not installed.
- `ct()` — —
- `get()` — —
- `body()` — —
- `post()` — —
- `payload()` — —
- `put()` — —
- `formatDate()` — —
- `date()` — —
- `now()` — —
- `diffMs()` — —
- `diffMins()` — —
- `diffHours()` — —
- `diffDays()` — —
- `formatDuration()` — —
- `mins()` — —
- `hours()` — —
- `days()` — —
- `formatSize()` — —
- `useState()` — —
- `useEffect()` — —
- `useCallback()` — —
- `Dashboard()` — —
- `data()` — —
- `root()` — —
- `do_cmd(ctx, task, project_name, tool_name)` — One command to rule them all.
- `useHealth()` — —
- `refresh()` — —
- `h()` — —
- `useBudget()` — —
- `useModels()` — —
- `m()` — —
- `useProviders()` — —
- `p()` — —
- `useResources()` — —
- `useLogs()` — —
- `l()` — —
- `getUrlParams()` — —
- `params()` — —
- `updateUrlParams()` — —
- `url()` — —
- `useDashboardData()` — —
- `getInitialRoute()` — —
- `hash()` — —
- `systemSection()` — —
- `tab()` — —
- `initialRoute()` — —
- `setTab()` — —
- `setSelectedProjectWithUrl()` — —
- `setSelectedTicketWithUrl()` — —
- `setSelectedToolWithUrl()` — —
- `setViewModeWithUrl()` — —
- `setContextWithUrl()` — —
- `handleHashChange()` — —
- `newTab()` — —
- `handlePopState()` — —
- `healthHook()` — —
- `budgetHook()` — —
- `modelsHook()` — —
- `providersHook()` — —
- `resourcesHook()` — —
- `logsHook()` — —
- `isUp()` — —
- `i()` — —
- `VoiceHeader()` — —
- `h()` — —
- `VoiceBubbles()` — —
- `VoiceCommands()` — —
- `VoiceHistoryBox()` — —
- `u()` — —
- `SR()` — —
- `r()` — —
- `VoiceChat()` — —
- `recRef()` — —
- `abortRef()` — —
- `finish()` — —
- `handleInput()` — —
- `ctrl()` — —
- `reply()` — —
- `startListening()` — —
- `text()` — —
- `stopAll()` — —
- `onKey()` — —
- `sc()` — —
- `label()` — —
- `DiagnosticsPanel()` — —
- `runTests()` — —
- `r()` — —
- `find()` — —
- `copyErrorsToClipboard()` — —
- `failedTests()` — —
- `lines()` — —
- `issues()` — —
- `apiCall()` — —
- `r()` — —
- `err()` — —
- `matchDSL()` — —
- `t()` — —
- `m()` — —
- `captured()` — —
- `executeDSL()` — —
- `data()` — —
- `setVoiceCredentials()` — —
- `vms()` — —
- `logs()` — —
- `formatToolResult()` — —
- `fn()` — —
- `dsl()` — —
- `label()` — —
- `reply()` — —
- `langHint()` — —
- `res()` — —
- `name()` — —
- `result()` — —
- `processVoiceInput()` — —
- `dslReply()` — —
- `messages()` — —
- `msg()` — —
- `toolReply()` — —
- `useLogFilter()` — —
- `filtered()` — —
- `errorCount()` — —
- `warnCount()` — —
- `LogRow()` — —
- `LogPanel()` — —
- `handleCopy()` — —
- `text()` — —
- `ta()` — —
- `StatusBadge()` — —
- `CostBar()` — —
- `pct()` — —
- `color()` — —
- `Card()` — —
- `StateBadge()` — —
- `colors()` — —
- `useVMSort()` — —
- `sorted()` — —
- `cmp()` — —
- `r()` — —
- `useVMSelection()` — —
- `handleSelect()` — —
- `next()` — —
- `handleSelectAll()` — —
- `handleBulkAction()` — —
- `vmIds()` — —
- `VMCard()` — —
- `actions()` — —
- `VMsPanel()` — —
- `sel()` — —
- `detail()` — —
- `handleAction()` — —
- `isDelete()` — —
- `endpoint()` — —
- `res()` — —
- `msg()` — —
- `label()` — —
- `runningCount()` — —
- `stoppedCount()` — —
- `pausedCount()` — —
- `TableExport()` — —
- `convertToCSV()` — —
- `headers()` — —
- `csvHeaders()` — —
- `csvRows()` — —
- `value()` — —
- `downloadCSV()` — —
- `csv()` — —
- `blob()` — —
- `link()` — —
- `url()` — —
- `downloadJSON()` — —
- `json()` — —
- `copyToClipboard()` — —
- `button()` — —
- `originalText()` — —
- `useTasksData()` — —
- `refresh()` — —
- `timer()` — —
- `TaskCardHeader()` — —
- `statusColor()` — —
- `priorityColor()` — —
- `typeIcon()` — —
- `TaskCardMeta()` — —
- `job()` — —
- `resultSuccess()` — —
- `resultLabel()` — —
- `TaskJobBadge()` — —
- `duration()` — —
- `filesChanged()` — —
- `hasOutput()` — —
- `TaskInlineLogs()` — —
- `j()` — —
- `TaskJobError()` — —
- `TaskJobResult()` — —
- `output()` — —
- `files()` — —
- `preview()` — —
- `TaskStatusActions()` — —
- `handleStatusChange()` — —
- `TaskTicketCard()` — —
- `liveJob()` — —
- `isActive()` — —
- `isDone()` — —
- `isFailed()` — —
- `QueueBar()` — —
- `byStatus()` — —
- `useHumanTaskData()` — —
- `HumanTaskPanel()` — —
- `humanTickets()` — —
- `assignedTool()` — —
- `tags()` — —
- `openTickets()` — —
- `projectOptions()` — —
- `updateForm()` — —
- `syncParent()` — —
- `submitTask()` — —
- `addNote()` — —
- `content()` — —
- `markDone()` — —
- `project()` — —
- `requestType()` — —
- `TasksPanel()` — —
- `filtered()` — —
- `boardColumns()` — —
- `handleStartStop()` — —
- `CostSummary()` — —
- `BudgetCards()` — —
- `dailyUsed()` — —
- `monthlyUsed()` — —
- `SystemCard()` — —
- `ProvidersCard()` — —
- `OverviewTab()` — —
- `useTickets()` — —
- `refreshTickets()` — —
- `data()` — —
- `refreshSprints()` — —
- `refresh()` — —
- `TicketCard()` — —
- `handleCardClick()` — —
- `handleStatusChange()` — —
- `handleAssign()` — —
- `CreateTicketForm()` — —
- `handleSubmit()` — —
- `field()` — —
- `CreateSprintForm()` — —
- `SprintCard()` — —
- `formatTimestamp()` — —
- `date()` — —
- `TicketHistoryItem()` — —
- `result()` — —
- `stdout()` — —
- `stderr()` — —
- `filesChanged()` — —
- `statusClass()` — —
- `success()` — —
- `execution()` — —
- `projectDir()` — —
- `promptExcerpt()` — —
- `promptLength()` — —
- `isActiveJob()` — —
- `resultLabel()` — —
- `TicketDetailPanel()` — —
- `jobHistory()` — —
- `latestJob()` — —
- `latestExecutionMetadata()` — —
- `latestProjectDir()` — —
- `latestPromptExcerpt()` — —
- `latestPromptLength()` — —
- `latestSuccess()` — —
- `latestExitCode()` — —
- `latestStdoutLines()` — —
- `latestStderrLines()` — —
- `latestFilesChanged()` — —
- `latestIsActiveJob()` — —
- `latestResultLabel()` — —
- `TicketsPanel()` — —
- `loadSelectedTicket()` — —
- `handleRefresh()` — —
- `filtered()` — —
- `boardColumns()` — —
- `stats()` — —
- `count()` — —
- `selectedTicketSummary()` — —
- `TableExport()` — —
- `convertToCSV()` — —
- `headers()` — —
- `csvHeaders()` — —
- `csvRows()` — —
- `value()` — —
- `downloadCSV()` — —
- `csv()` — —
- `blob()` — —
- `link()` — —
- `url()` — —
- `downloadJSON()` — —
- `json()` — —
- `copyToClipboard()` — —
- `button()` — —
- `originalText()` — —
- `ModelsTable()` — —
- `exportData()` — —
- `useProjects()` — —
- `refresh()` — —
- `data()` — —
- `ProjectHeader()` — —
- `icon()` — —
- `ProjectMeta()` — —
- `ProjectQuickTask()` — —
- `handleCreate()` — —
- `ProjectTicketRow()` — —
- `cls()` — —
- `ProjectTicketList()` — —
- `load()` — —
- `ProjectCard()` — —
- `handleCardClick()` — —
- `AddProjectForm()` — —
- `handleAdd()` — —
- `ProjectsPanel()` — —
- `filtered()` — —
- `stats()` — —
- `handleScan()` — —
- `dir()` — —
- `result()` — —
- `vms()` — —
- `running()` — —
- `daily()` — —
- `monthly()` — —
- `logs()` — —
- `ids()` — —
- `routes()` — —
- `ok()` — —
- `fail()` — —
- `accounts()` — —
- `useSystemData()` — —
- `refresh()` — —
- `SystemPanel()` — —
- `activeProviders()` — —
- `useQuickDo()` — —
- `submit()` — —
- `r()` — —
- `toolInfo()` — —
- `onKey()` — —
- `canSubmit()` — —
- `QuickDoFeedback()` — —
- `color()` — —
- `QuickDoCompact()` — —
- `q()` — —
- `QuickDo()` — —
- `HealthCard()` — —
- `checks()` — —
- `total()` — —
- `ok()` — —
- `alerts()` — —
- `BudgetMiniCard()` — —
- `dailyUsed()` — —
- `monthlyUsed()` — —
- `monthlyLimit()` — —
- `remaining()` — —
- `QueueMiniCard()` — —
- `load()` — —
- `data()` — —
- `timer()` — —
- `qs()` — —
- `running()` — —
- `done()` — —
- `ms()` — —
- `ActivityRow()` — —
- `RecentActivity()` — —
- `tickets()` — —
- `jobs()` — —
- `HomeTab()` — —
- `ALL_TAB_IDS()` — —
- `DashboardHeader()` — —
- `TabNav()` — —
- `AccountRow()` — —
- `a()` — —
- `NewAccountForm()` — —
- `handleSubmit()` — —
- `AccountsPanel()` — —
- `handleCreate()` — —
- `TableExport()` — —
- `convertToCSV()` — —
- `headers()` — —
- `csvHeaders()` — —
- `csvRows()` — —
- `value()` — —
- `downloadCSV()` — —
- `csv()` — —
- `blob()` — —
- `link()` — —
- `url()` — —
- `downloadJSON()` — —
- `json()` — —
- `copyToClipboard()` — —
- `button()` — —
- `originalText()` — —
- `useTools()` — —
- `refreshTools()` — —
- `data()` — —
- `refreshQueue()` — —
- `refresh()` — —
- `ToolCard()` — —
- `catClass()` — —
- `handleCardClick()` — —
- `JobRow()` — —
- `statusClass()` — —
- `hasLogs()` — —
- `isFailed()` — —
- `JobDetailsPanel()` — —
- `result()` — —
- `stdout()` — —
- `stderr()` — —
- `filesChanged()` — —
- `ticketTitle()` — —
- `ticketStatus()` — —
- `execution()` — —
- `promptExcerpt()` — —
- `projectDir()` — —
- `resultSuccess()` — —
- `isActiveJob()` — —
- `resultLabel()` — —
- `stdoutLines()` — —
- `stderrLines()` — —
- `TicketDispatchTable()` — —
- `availableTools()` — —
- `unavailableTools()` — —
- `dispatchableTickets()` — —
- `loadTickets()` — —
- `loadProjects()` — —
- `handleToolSelect()` — —
- `getStatusBadgeClass()` — —
- `getPriorityBadgeClass()` — —
- `getToolCategoryClass()` — —
- `getProjectInfo()` — —
- `project()` — —
- `path()` — —
- `renderCurrentTool()` — —
- `renderStatusBadge()` — —
- `displayStatus()` — —
- `renderPriorityBadge()` — —
- `priorityClass()` — —
- `displayPriority()` — —
- `currentTool()` — —
- `toolInfo()` — —
- `projectInfo()` — —
- `QueueSummary()` — —
- `ToolHealthPanel()` — —
- `loadHealth()` — —
- `handleProviderChange()` — —
- `handleAutoFix()` — —
- `action()` — —
- `handleBulkAutoFix()` — —
- `executed()` — —
- `humanRequired()` — —
- `failed()` — —
- `isAutoFixable()` — —
- `requiresHuman()` — —
- `degradedCount()` — —
- `isHuman()` — —
- `isFixing()` — —
- `ToolsPanel()` — —
- `handleStartStop()` — —
- `handleRetryJob()` — —
- `handleRepairJob()` — —
- `details()` — —
- `handleSelectJob()` — —
- `available()` — —
- `unavailable()` — —
- `DiagRooConfig()` — —
- `ok()` — —
- `badge()` — —
- `DiagProviders()` — —
- `useUsers()` — —
- `refreshUsers()` — —
- `data()` — —
- `syncGitUsers()` — —
- `createUser()` — —
- `setDefaultUser()` — —
- `UserCard()` — —
- `roleClass()` — —
- `CreateUserForm()` — —
- `handleSubmit()` — —
- `field()` — —
- `UsersPanel()` — —
- `handleSetDefault()` — —
- `handleCreate()` — —
- `handleSyncGit()` — —
- `result()` — —
- `activeUsers()` — —
- `defaultUserId()` — —
- `cls()` — —
- `DiagExtensions()` — —
- `ok()` — —
- `DiagCopilot()` — —
- `DiagVSCode()` — —
- `DiagProxy()` — —
- `DiagAgentSetup()` — —
- `DiagAgentTest()` — —
- `skipped()` — —
- `check()` — —
- `skip()` — —
- `api()` — —
- `parse_response()` — —
- `phase_health()` — —
- `phase_tools()` — —
- `phase_executor()` — —
- `dispatch_and_monitor()` — —
- `phase_lifecycle()` — —
- `phase_queue_logs()` — —
- `phase_tickets()` — —
- `phase_healthcheck()` — —
- `summary()` — —
- `print()` — —
- `useState()` — —
- `useEffect()` — —
- `useMemo()` — —
- `EMPTY_COMPLETED()` — —
- `raw()` — —
- `parsed()` — —
- `parsedValues()` — —
- `SetupPanel()` — —
- `persisted()` — —
- `checkedCount()` — —
- `autoCount()` — —
- `manualCount()` — —
- `rootCount()` — —
- `toggleStep()` — —
- `setField()` — —
- `setSecretField()` — —
- `copyText()` — —
- `copyAllCommands()` — —
- `text()` — —
- `envSnippet()` — —
- `oneLineSummary()` — —
- `hasCommands()` — —
- `hasSudoCommands()` — —
- `lifespan(app)` — —
- `cli()` — —


## Project Structure

📄 `docs.open-webui-tools.proxym_tools` (9 functions, 1 classes)
📄 `frontend.proxym-dashboard`
📄 `project`
📄 `project.examples.advanced_usage`
📄 `project.examples.quickstart`
📄 `scripts.evaluate_llm_work` (2 functions)
📄 `scripts.jetson-entrypoint`
📄 `scripts.proxym-voice-chat` (3 functions)
📄 `scripts.proxym-voice-server`
📄 `scripts.seed_sprint8` (1 functions)
📄 `scripts.setup`
📄 `scripts.validate_system` (11 functions)
📄 `services.vscode.entrypoint` (3 functions)
📦 `src.proxym`
📦 `src.proxym.accounts` (20 functions, 8 classes)
📦 `src.proxym.api`
📄 `src.proxym.api._diag_agent` (3 functions)
📄 `src.proxym.api._diag_common` (1 functions)
📄 `src.proxym.api._diag_providers` (1 functions)
📄 `src.proxym.api._diag_proxy` (1 functions)
📄 `src.proxym.api._diag_roo` (1 functions)
📄 `src.proxym.api._diag_vscode` (2 functions)
📄 `src.proxym.api._pipeline` (16 functions, 1 classes)
📄 `src.proxym.api._state` (6 functions)
📄 `src.proxym.api.completions` (12 functions)
📄 `src.proxym.api.console` (4 functions)
📄 `src.proxym.api.context_api` (7 functions)
📄 `src.proxym.api.diagnostics` (9 functions)
📄 `src.proxym.api.frontend` (32 functions)
📄 `src.proxym.api.observability_api` (7 functions, 1 classes)
📄 `src.proxym.api.system` (7 functions)
📄 `src.proxym.api.voice_actions` (9 functions)
📄 `src.proxym.api.vscode_api` (11 functions)
📦 `src.proxym.cache` (10 functions, 3 classes)
📦 `src.proxym.cli`
📄 `src.proxym.cli._client` (3 functions)
📦 `src.proxym.cli._groups`
📄 `src.proxym.cli._groups.accounts_ctl` (8 functions)
📄 `src.proxym.cli._groups.browser_ctl` (6 functions)
📄 `src.proxym.cli._groups.context_ctl` (7 functions)
📄 `src.proxym.cli._groups.diagnostics_ctl` (16 functions)
📄 `src.proxym.cli._groups.do_ctl` (8 functions)
📄 `src.proxym.cli._groups.observability_ctl` (6 functions)
📄 `src.proxym.cli._groups.projects_ctl` (8 functions)
📄 `src.proxym.cli._groups.tickets_ctl` (18 functions)
📄 `src.proxym.cli._groups.tools_ctl` (13 functions)
📄 `src.proxym.cli._groups.vms_ctl` (16 functions)
📄 `src.proxym.cli._groups.vscode_ctl` (8 functions)
📄 `src.proxym.cli.accounts` (6 functions)
📄 `src.proxym.cli.browser` (4 functions)
📄 `src.proxym.cli.chat` (12 functions)
📄 `src.proxym.cli.context` (5 functions)
📄 `src.proxym.cli.diagnostics` (7 functions)
📄 `src.proxym.cli.dsl` (8 functions, 2 classes)
📄 `src.proxym.cli.observability` (6 functions)
📄 `src.proxym.cli.smart_defaults` (4 functions)
📄 `src.proxym.cli.system` (6 functions)
📄 `src.proxym.cli.tickets` (13 functions)
📄 `src.proxym.cli.tts` (5 functions, 1 classes)
📄 `src.proxym.cli.vms` (11 functions)
📄 `src.proxym.cli.voice` (3 functions, 1 classes)
📄 `src.proxym.cli.vscode` (8 functions)
📄 `src.proxym.config` (3 functions, 1 classes)
📦 `src.proxym.context`
📄 `src.proxym.context._context` (1 functions, 1 classes)
📄 `src.proxym.context.detector` (9 functions)
📄 `src.proxym.context.session` (12 functions, 2 classes)
📄 `src.proxym.context.tool_selector` (2 functions)
📄 `src.proxym.ctl` (15 functions)
📦 `src.proxym.dashboard`
📄 `src.proxym.dashboard._accounts` (6 functions, 2 classes)
📄 `src.proxym.dashboard._costs` (4 functions)
📄 `src.proxym.dashboard._projects_api` (9 functions, 3 classes)
📄 `src.proxym.dashboard._system` (6 functions)
📄 `src.proxym.dashboard._tickets_api` (16 functions, 6 classes)
📄 `src.proxym.dashboard._tools_api` (30 functions, 4 classes)
📄 `src.proxym.dashboard._users_api` (9 functions, 2 classes)
📄 `src.proxym.dashboard._vms` (12 functions, 2 classes)
📄 `src.proxym.dashboard.api` (12 functions)
📄 `src.proxym.dashboard.components.accounts` (6 functions)
📄 `src.proxym.dashboard.components.diagnostics` (8 functions)
📄 `src.proxym.dashboard.components.diagnostics.DiagAgent` (3 functions)
📄 `src.proxym.dashboard.components.diagnostics.DiagConfig` (4 functions)
📄 `src.proxym.dashboard.components.diagnostics.DiagExtensions` (3 functions)
📄 `src.proxym.dashboard.components.diagnostics.DiagInfrastructure` (2 functions)
📄 `src.proxym.dashboard.components.diagnostics.helpers` (4 functions)
📄 `src.proxym.dashboard.components.home` (41 functions)
📄 `src.proxym.dashboard.components.layout` (3 functions)
📄 `src.proxym.dashboard.components.logs` (9 functions)
📄 `src.proxym.dashboard.components.models` (21 functions)
📄 `src.proxym.dashboard.components.overview` (7 functions)
📄 `src.proxym.dashboard.components.projects` (23 functions)
📄 `src.proxym.dashboard.components.setup` (27 functions)
📄 `src.proxym.dashboard.components.system` (4 functions)
📄 `src.proxym.dashboard.components.tasks` (75 functions)
📄 `src.proxym.dashboard.components.tickets` (56 functions)
📄 `src.proxym.dashboard.components.tools` (103 functions)
📄 `src.proxym.dashboard.components.ui` (7 functions)
📄 `src.proxym.dashboard.components.users` (20 functions)
📄 `src.proxym.dashboard.components.vms` (30 functions)
📄 `src.proxym.dashboard.components.voice` (30 functions)
📄 `src.proxym.dashboard.components.voice_engine` (31 functions)
📄 `src.proxym.dashboard.components.voice_schemas` (10 functions)
📄 `src.proxym.dashboard.hooks.useDashboardData` (45 functions)
📄 `src.proxym.dashboard.panel` (7 functions)
📄 `src.proxym.dashboard.tickets` (23 functions, 10 classes)
📄 `src.proxym.dashboard.users` (16 functions, 3 classes)
📄 `src.proxym.dashboard.utils.formatters` (12 functions)
📄 `src.proxym.main` (2 functions)
📦 `src.proxym.mcp`
📄 `src.proxym.mcp._helpers` (3 functions)
📄 `src.proxym.mcp._tools_accounts` (3 functions, 1 classes)
📄 `src.proxym.mcp._tools_system` (3 functions)
📄 `src.proxym.mcp._tools_tickets` (5 functions, 3 classes)
📄 `src.proxym.mcp._tools_vm` (6 functions, 4 classes)
📄 `src.proxym.mcp.client` (4 functions, 2 classes)
📄 `src.proxym.mcp.registry` (8 functions, 3 classes)
📄 `src.proxym.mcp.router` (4 functions, 1 classes)
📄 `src.proxym.mcp.self_server`
📦 `src.proxym.middleware` (4 functions, 2 classes)
📦 `src.proxym.observability` (8 functions)
📄 `src.proxym.observability.health_events` (7 functions, 3 classes)
📄 `src.proxym.observability.repair_agent` (9 functions, 1 classes)
📄 `src.proxym.observability.watchdog` (13 functions, 1 classes)
📦 `src.proxym.projects` (14 functions, 4 classes)
📦 `src.proxym.providers` (4 functions, 3 classes)
📦 `src.proxym.router` (14 functions, 1 classes)
📄 `src.proxym.router.strategy` (14 functions, 3 classes)
📄 `src.proxym.storage` (6 functions, 1 classes)
📦 `src.proxym.tools` (13 functions, 5 classes)
📄 `src.proxym.tools.adapters` (14 functions, 6 classes)
📄 `src.proxym.tools.executor` (14 functions, 3 classes)
📦 `src.proxym.virt`
📄 `src.proxym.virt._check` (1 functions)
📄 `src.proxym.virt._config` (1 functions, 3 classes)
📄 `src.proxym.virt._enums` (2 classes)
📄 `src.proxym.virt._infra` (4 functions, 1 classes)
📄 `src.proxym.virt._lifecycle` (12 functions, 1 classes)
📄 `src.proxym.virt._orchestrator` (5 functions, 1 classes)
📄 `src.proxym.virt._project` (2 functions, 1 classes)
📄 `src.proxym.virt._snapshot` (4 functions, 1 classes)
📄 `src.proxym.virt._state` (5 functions, 1 classes)
📄 `src.proxym.virt._vm_config` (7 functions, 1 classes)
📄 `src.proxym.virt.browser_profiles` (11 functions, 2 classes)
📄 `src.proxym.virt.clonebox_adapter` (17 functions, 2 classes)
📦 `src.proxym.virt.profiles` (4 functions)
📦 `src.proxym.watch` (5 functions, 1 classes)
📄 `src.proxym.watch.client`

## Requirements

- Python >= >=3.11
- fastapi >=0.115.0- uvicorn [standard]>=0.30.0- httpx >=0.27.0- litellm >=1.55.0- redis >=5.0.0- pydantic >=2.9.0- pydantic-settings >=2.5.0- python-dotenv >=1.0.0- tiktoken >=0.8.0- watchfiles >=0.24.0- xxhash >=3.5.0- rich >=13.9.0- structlog >=24.4.0- pyyaml >=6.0- click >=8.1.0

## Contributing

**Contributors:**
- Tom Softreck <tom@sapletta.com>
- Tom Sapletta <tom-sapletta-com@users.noreply.github.com>

We welcome contributions! Please see [CONTRIBUTING.md](./CONTRIBUTING.md) for guidelines.

### Development Setup

```bash
# Clone the repository
git clone https://github.com/wronai/proxy
cd proxy

# Install in development mode
pip install -e ".[dev]"

# Run tests
pytest
```

## Documentation

- 📖 [Full Documentation](https://github.com/wronai/proxy/tree/main/docs) — API reference, module docs, architecture
- 🚀 [Getting Started](https://github.com/wronai/proxy/blob/main/docs/getting-started.md) — Quick start guide
- 📚 [API Reference](https://github.com/wronai/proxy/blob/main/docs/api.md) — Complete API documentation
- 🔧 [Configuration](https://github.com/wronai/proxy/blob/main/docs/configuration.md) — Configuration options
- 💡 [Examples](./examples) — Usage examples and code samples

### Generated Files

| Output | Description | Link |
|--------|-------------|------|
| `README.md` | Project overview (this file) | — |
| `docs/api.md` | Consolidated API reference | [View](./docs/api.md) |
| `docs/modules.md` | Module reference with metrics | [View](./docs/modules.md) |
| `docs/architecture.md` | Architecture with diagrams | [View](./docs/architecture.md) |
| `docs/dependency-graph.md` | Dependency graphs | [View](./docs/dependency-graph.md) |
| `docs/coverage.md` | Docstring coverage report | [View](./docs/coverage.md) |
| `docs/getting-started.md` | Getting started guide | [View](./docs/getting-started.md) |
| `docs/configuration.md` | Configuration reference | [View](./docs/configuration.md) |
| `docs/api-changelog.md` | API change tracking | [View](./docs/api-changelog.md) |
| `CONTRIBUTING.md` | Contribution guidelines | [View](./CONTRIBUTING.md) |
| `examples/` | Usage examples | [Browse](./examples) |
| `mkdocs.yml` | MkDocs configuration | — |

<!-- code2docs:end -->