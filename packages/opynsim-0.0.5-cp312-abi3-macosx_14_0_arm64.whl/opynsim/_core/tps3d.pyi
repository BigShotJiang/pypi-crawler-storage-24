from typing import Annotated

import numpy
from numpy.typing import NDArray


class TPSCoefficients3D:
    """
    Represents Thin-Plate Spline (TPS) coefficients in 3D that were calculated from corresponding pairs of points.
    """

    def __repr__(self) -> str: ...

    @property
    def a1(self) -> Annotated[NDArray[numpy.float64], dict(shape=(3), device='cpu')]:
        """
        The first term of the warping equation. Some systems treat this as the translation component of the warp.
        """

    @property
    def a2(self) -> Annotated[NDArray[numpy.float64], dict(shape=(3), device='cpu')]:
        """
        The second term of the warping equation. Some systems treat this as the first column of a 3x3 scale + rotation matrix.
        """

    @property
    def a3(self) -> Annotated[NDArray[numpy.float64], dict(shape=(3), device='cpu')]:
        """
        The second term of the warping equation. Some systems treat this as the second column of a 3x3 scale + rotation matrix.
        """

    @property
    def a4(self) -> Annotated[NDArray[numpy.float64], dict(shape=(3), device='cpu')]:
        """
        The second term of the warping equation. Some systems treat this as the third column of a 3x3 scale + rotation matrix.
        """

    def warp_point(self, point: Annotated[NDArray[numpy.float64], dict(shape=(3), device='cpu', writable=False)]) -> Annotated[NDArray[numpy.float64], dict(shape=(3), device='cpu')]:
        """
        Warps a single 3D point by putting ``point`` through the warping equation.

        Args:
            point: a 3-element ndarray.

        Returns:
            A 3-element ndarray that represents the warped point.
        """

def solve_coefficients(source_landmarks: Annotated[NDArray[numpy.float64], dict(shape=(None, 3), device='cpu', writable=False)], destination_landmarks: Annotated[NDArray[numpy.float64], dict(shape=(None, 3), device='cpu', writable=False)]) -> TPSCoefficients3D:
    """
    Returns Thin-Plate Spline (TPS) warping coefficients solved by pairing N
    "source" points (source_landmarks) with N "destination" points (destination_landmarks).

    Args:
        source_landmarks: An (N, 3) array of 3D points.
        destination_landmarks: An (N, 3) array of 3D points.

    Returns:
        A TPSCoefficients3D object that contains the calculated coefficients.
    """
