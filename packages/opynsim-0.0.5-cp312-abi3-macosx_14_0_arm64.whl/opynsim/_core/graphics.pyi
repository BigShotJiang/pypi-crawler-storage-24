from typing import Annotated

import numpy
from numpy.typing import NDArray

import _core


def render_model_in_state(model: _core.Model, state: _core.ModelState, *, dimensions: tuple[int, int] = (640, 480), zoom_to_fit: bool = True) -> Texture2D:
    """
    Renders the given :class:`opynsim.Model` + :class:`opynsim.ModelState` to
    a :class:`opynsim.graphics.Texture2D`.

    Args:
        model (opynsim.Model): The model to render.
        state (opynsim.ModelState): The state of the model to render. Should be realized to at least :attr:`opynsim.ModelStateStage.REPORT`.
        dimensions (tuple[int, int]): The desired output resolution (width, height) of the rendered image in pixels.
        zoom_to_fit (bool): Tells the renderer to automatically set up the camera to focus on the center of the bounds of the scene at a distance that can see the entire scene.

    Returns:
        opynsim.graphics.Texture2D: The rendered image, which will have the specified ``dimensions``.
    """

class Texture2D:
    """Represents a two-dimensional image."""

    def pixels_rgba32(self) -> Annotated[NDArray[numpy.uint8], dict(shape=(None, None, 4), writable=False)]:
        """
        Returns an ndarray with the shape ``(height, width, 4)``, where each element of
        the 3rd dimension is a raw uint8 (0-255) pixel value for the red (R), green (G),
        blue (B), and alpha (A) components of the texture respectively.

        The grid layout and component encoding of the returned array tries to match the
        conventions used by other Python libraries (e.g. matplotlib, pyvista) and
        image tools so that the render is easy to compose into other systems.

        The layout of the pixels is such that the first pixel in the first row (``rv[0, 0]``)
        starts in the top-left of the image. Subsequent pixels within that row are then
        encoded left-to-right. The following row (``rv[1]``) is then below that row, and so on,
        until the final pixel, which is in the bottom-right of the image.

        The encoding the the components of a pixel is such that the lowest value for each
        component is zero, representing zero intensity of that component. The highest value
        for each component is 255, representing the maximum intensity of that
        component. The color components (R, G, and B) are in an sRGB color space, while the
        alpha component (A) is linear.
        """
