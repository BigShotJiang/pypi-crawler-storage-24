import _core


def show_hello_ui() -> None:
    """
    Displays OPynSim's 'hello world' user interface in a window.

    Blocks and runs the GUI main loop until the window is closed.
    """

def show_model_in_state(model: _core.Model, state: _core.ModelState, *, zoom_to_fit: bool = True) -> None:
    """
    Displays an interactive visualizer for the given :class:`opynsim.Model` + :class:`opynsim.ModelState`
    in a window.

    Blocks and runs the GUI main loop until the window is closed.

    Args:
        model (opynsim.Model): The model to render.
        state (opynsim.ModelState): The state of the model to render. Should be realized to at least :attr:`opynsim.ModelStateStage.REPORT`.
        zoom_to_fit (bool): Tells the renderer to automatically set up the camera to focus on the center of the bounds of the scene at a distance that can see the entire scene.
    """
