# lapatic-encr

Decentralized encrypted messaging over MQTT.

Features

- Forward secrecy
- MITM protection
- Trust On First Use
- Peer discovery
- Fully decentralized

## Install

pip install lapatic-encr

## Example

```python
import encr
from encr import Device

encr.init()

d1 = Device("d1")
d2 = Device("d2")

d1.show()
d2.show()

d1.connect("d2")
d1.send("d2", {"msg": "hello"})