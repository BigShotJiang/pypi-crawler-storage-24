import paho.mqtt.client as mqtt
import uuid
import secrets
import json
import hashlib
import base64
import ssl
import certifi
import time

from cryptography.fernet import Fernet
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives import serialization
from cryptography.exceptions import InvalidSignature


BROKER = "broker.hivemq.com"
PORT = 8883

DISCOVER_TOPIC = "lapatic/encr/discover"
MESSAGE_TOPIC = "lapatic/encr/message"

# RFC3526 2048-bit DH group
p = int("""
FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD129024E08
8A67CC74020BBEA63B139B22514A08798E3404DD
EF9519B3CD3A431B302B0A6DF25F14374FE1356D
6D51C245E485B576625E7EC6F44C42E9A63A3620
FFFFFFFFFFFFFFFF
""".replace("\n",""),16)

g = 2

client = None


def init():
    global client

    client = mqtt.Client()

    client.tls_set(
        ca_certs=certifi.where(),
        tls_version=ssl.PROTOCOL_TLS_CLIENT
    )

    client.connect(BROKER, PORT, 60)
    client.loop_start()


class Device:

    def __init__(self, name):

        self.name = name
        self.id = str(uuid.uuid4())
        self.topic = f"{MESSAGE_TOPIC}/{self.id}"

        # identity keys
        self.identity_private = Ed25519PrivateKey.generate()
        self.identity_public = self.identity_private.public_key()

        # trust store (TOFU)
        self.trusted = {}

        # discovery results
        self.potentials = {}

        # connection state
        self.connected = {}

        # ephemeral handshakes
        self.handshakes = {}

        # queued outgoing messages
        self.pending_messages = {}

        # connections waiting for discovery
        self.pending_connect = set()

        self.on_message = self.default_on_message

        client.subscribe(self.topic)
        client.subscribe(DISCOVER_TOPIC)

        client.message_callback_add(self.topic, self._on_message)
        client.message_callback_add(DISCOVER_TOPIC, self._discover)

    # ---------------- Discovery ----------------

    def show(self):

        packet = {
            "name": self.name,
            "id": self.id
        }

        client.publish(DISCOVER_TOPIC, json.dumps(packet), qos=2)

    def _discover(self, client, userdata, msg):

        data = json.loads(msg.payload.decode())

        if data["id"] == self.id:
            return

        name = data["name"]

        self.potentials[name] = data["id"]

        # auto-connect if requested earlier
        if name in self.pending_connect:
            self.pending_connect.remove(name)
            self._start_handshake(name)

    # ---------------- Connection ----------------

    def connect(self, name):

        if name in self.connected:
            return

        if name not in self.potentials:
            self.pending_connect.add(name)
            return

        self._start_handshake(name)

    def _start_handshake(self, name):

        otherid = self.potentials[name]

        priv = secrets.randbits(256)
        pub = pow(g, priv, p)

        self.handshakes[name] = priv

        sig = self.identity_private.sign(str(pub).encode())

        identity_bytes = self.identity_public.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw
        )

        packet = {
            "type": 0,
            "name": self.name,
            "id": self.id,
            "eph": pub,
            "identity": base64.b64encode(identity_bytes).decode(),
            "sig": base64.b64encode(sig).decode()
        }

        client.publish(
            f"{MESSAGE_TOPIC}/{otherid}",
            json.dumps(packet),
            qos=2
        )

    # ---------------- Messaging ----------------

    def send(self, name, data):

        if name not in self.connected:
            self.pending_messages.setdefault(name, []).append(data)
            return

        conn = self.connected[name]

        f = Fernet(conn["key"])

        enc = f.encrypt(json.dumps(data).encode()).decode()

        packet = {
            "type": 2,
            "name": self.name,
            "id": self.id,
            "data": enc
        }

        client.publish(
            f"{MESSAGE_TOPIC}/{conn['id']}",
            json.dumps(packet),
            qos=2
        )

    # ---------------- Crypto helpers ----------------

    def _derive_key(self, shared):

        digest = hashlib.sha256(
            shared.to_bytes((shared.bit_length()+7)//8, "big")
        ).digest()

        return base64.urlsafe_b64encode(digest)

    # ---------------- MQTT message handler ----------------

    def _on_message(self, client, userdata, msg):

        data = json.loads(msg.payload.decode())
        t = data["type"]

        if t in (0,1):

            name = data["name"]
            otherid = data["id"]
            eph = data["eph"]

            identity_bytes = base64.b64decode(data["identity"])
            sig = base64.b64decode(data["sig"])

            identity_key = Ed25519PublicKey.from_public_bytes(identity_bytes)

            try:
                identity_key.verify(sig, str(eph).encode())
            except InvalidSignature:
                print("invalid signature")
                return

            # TOFU identity check
            if name not in self.trusted:
                self.trusted[name] = identity_bytes
            else:
                if self.trusted[name] != identity_bytes:
                    print("identity mismatch for", name)
                    return

        # handshake start
        if t == 0:

            priv = secrets.randbits(256)
            pub = pow(g, priv, p)

            shared = pow(eph, priv, p)

            key = self._derive_key(shared)

            self.connected[name] = {"id": otherid, "key": key}

            sig = self.identity_private.sign(str(pub).encode())

            identity_bytes = self.identity_public.public_bytes(
                encoding=serialization.Encoding.Raw,
                format=serialization.PublicFormat.Raw
            )

            packet = {
                "type": 1,
                "name": self.name,
                "id": self.id,
                "eph": pub,
                "identity": base64.b64encode(identity_bytes).decode(),
                "sig": base64.b64encode(sig).decode()
            }

            client.publish(
                f"{MESSAGE_TOPIC}/{otherid}",
                json.dumps(packet),
                qos=2
            )

        # handshake response
        elif t == 1:

            if name not in self.handshakes:
                return

            priv = self.handshakes[name]

            shared = pow(eph, priv, p)

            key = self._derive_key(shared)

            self.connected[name] = {"id": otherid, "key": key}

            del self.handshakes[name]

            # send queued messages
            if name in self.pending_messages:

                for m in self.pending_messages[name]:
                    self.send(name, m)

                del self.pending_messages[name]

        # encrypted message
        elif t == 2:

            name = data["name"]

            if name not in self.connected:
                return

            key = self.connected[name]["key"]

            f = Fernet(key)

            payload = json.loads(
                f.decrypt(data["data"].encode()).decode()
            )

            self.on_message(payload, name)

    # ---------------- default handler ----------------

    def default_on_message(self, data, name):
        print(name, "said", data)

def run():
    try:
        while True:
            time.sleep(1)
    except Exception as e:
        raise("Ended with exception", e)