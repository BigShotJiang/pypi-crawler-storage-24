# mcpzoo-path-parse

> 路径解析 — 解析文件路径的目录名文件名和扩展名

## Installation

```bash
uvx mcpzoo-path-parse
```

## uvx JSON

```json
{
  "mcpServers": {
    "path-parse": {
      "args": ["mcpzoo-path-parse"],
      "command": "uvx"
    }
  }
}
```
