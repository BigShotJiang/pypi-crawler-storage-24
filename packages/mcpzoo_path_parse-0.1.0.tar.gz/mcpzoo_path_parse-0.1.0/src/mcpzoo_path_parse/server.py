import os
import json
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("path-parse")

@mcp.tool()
def parse_path(path: str) -> str:
    """解析文件路径的目录名、文件名和扩展名。"""
    abs_path = os.path.abspath(path)
    dirname = os.path.dirname(abs_path)
    basename = os.path.basename(abs_path)
    name, ext = os.path.splitext(basename)
    
    info = {
        "original": path,
        "absolute": abs_path,
        "dir": dirname,
        "basename": basename,
        "name": name,
        "ext": ext,
        "is_absolute": os.path.isabs(path)
    }
    return json.dumps(info, indent=2, ensure_ascii=False)

def main():
    mcp.run()

if __name__ == "__main__":
    main()
