"""
Factor Axis Construction and Screening

Functions to:
1. Combine raw panels into factor axes
2. Screen factors by quintile spread
3. Compute axis scores using quintile bucket selection
"""

import logging
from typing import Dict, Tuple

import numpy as np
import pandas as pd

from bist_quant.common.utils import (
    MIN_ROLLING_OBS_RATIO,
    align_panel_to_contract,
    cross_sectional_zscore,
    # Consolidated utilities (Phase 2 refactoring)
    debug_enabled,
    debug_log,
    rolling_cumulative_return,
    validate_numeric_panel,
    validate_reference_axes,
)
from bist_quant.common.utils import (
    cross_sectional_rank as _cross_sectional_rank,
)

logger = logging.getLogger(__name__)

# ============================================================================
# PARAMETERS
# ============================================================================

# Quintile buckets
N_BUCKETS = 5
BUCKET_LABELS = ("Q1_Low", "Q2_LowMid", "Q3_Center", "Q4_HighMid", "Q5_High")

# Multi-lookback ensemble (structural horizons: 1mo / 1q / 6mo / 1yr)
ENSEMBLE_LOOKBACK_WINDOWS = (21, 63, 126, 252)
ENSEMBLE_LOOKBACK_WEIGHTS = (0.25, 0.25, 0.25, 0.25)  # equal weight — no tuning


# ============================================================================
# HELPER FUNCTIONS (Aliases for backward compatibility)
# ============================================================================

_debug_enabled = debug_enabled
_validate_reference_axes = validate_reference_axes
_validate_numeric_panel = validate_numeric_panel
_align_panel_to_contract = align_panel_to_contract
cross_sectional_rank = _cross_sectional_rank


def _debug_log(msg: str) -> None:
    debug_log(msg, prefix="FACTOR_DEBUG")


def _get_panel(
    axis_panels: Dict[str, pd.DataFrame],
    panel_name: str,
    dates: pd.DatetimeIndex,
    tickers: pd.Index,
) -> pd.DataFrame | None:
    panel = axis_panels.get(panel_name)
    if panel is None:
        return None
    return _align_panel_to_contract(panel, panel_name, dates, tickers)


# ============================================================================
# AXIS COMBINATION FUNCTIONS
# ============================================================================

def _combine_components_properly(
    components: list,
    dates: pd.DatetimeIndex,
    tickers: pd.Index,
) -> pd.DataFrame:
    """Combine multiple z-score components using proper NaN handling.

    Instead of fillna(0) which biases toward neutral, we compute the mean
    only over available components for each (date, ticker) cell.
    """
    dates, tickers = _validate_reference_axes(dates, tickers, "_combine_components_properly")

    if not components:
        return pd.DataFrame(np.nan, index=dates, columns=tickers)

    # Stack all components and compute mean ignoring NaNs
    aligned = [
        _align_panel_to_contract(comp, f"component:{name}", dates, tickers)
        for name, comp in components
    ]
    stacked = np.stack([df.values for df in aligned], axis=0)  # (n_components, n_dates, n_tickers)

    # Mean over components, ignoring NaNs (without runtime warnings for all-NaN slices)
    valid_counts = np.sum(~np.isnan(stacked), axis=0)
    summed = np.nansum(stacked, axis=0)
    result_values = np.divide(
        summed,
        valid_counts,
        out=np.full_like(summed, np.nan),
        where=valid_counts > 0,
    )

    return pd.DataFrame(result_values, index=dates, columns=tickers)


# Minimum data points required to include a component (proportional threshold)
MIN_COMPONENT_DATA_POINTS = 100


def combine_quality_axis(axis_panels: Dict[str, pd.DataFrame], dates: pd.DatetimeIndex, tickers: pd.Index) -> pd.DataFrame:
    """Combine quality sub-panels into a single quality axis (equal-weighted)."""
    dates, tickers = _validate_reference_axes(dates, tickers, "combine_quality_axis")
    components = []

    roe = _get_panel(axis_panels, "quality_roe", dates, tickers)
    if roe is not None and roe.notna().sum().sum() > MIN_COMPONENT_DATA_POINTS:
        components.append(("ROE", cross_sectional_zscore(roe)))

    roa = _get_panel(axis_panels, "quality_roa", dates, tickers)
    if roa is not None and roa.notna().sum().sum() > MIN_COMPONENT_DATA_POINTS:
        components.append(("ROA", cross_sectional_zscore(roa)))

    accruals = _get_panel(axis_panels, "quality_accruals", dates, tickers)
    if accruals is not None and accruals.notna().sum().sum() > MIN_COMPONENT_DATA_POINTS:
        # Low accruals = high quality, so invert
        components.append(("Accruals", -cross_sectional_zscore(accruals)))

    piotroski = _get_panel(axis_panels, "quality_piotroski", dates, tickers)
    if piotroski is not None and piotroski.notna().sum().sum() > MIN_COMPONENT_DATA_POINTS:
        components.append(("Piotroski", cross_sectional_zscore(piotroski)))

    if not components:
        logger.warning("    ⚠️  Quality axis has no valid components")
        return pd.DataFrame(np.nan, index=dates, columns=tickers)

    logger.info(f"    Quality axis components: {[c[0] for c in components]}")

    return _combine_components_properly(components, dates, tickers)


def combine_liquidity_axis(axis_panels: Dict[str, pd.DataFrame], dates: pd.DatetimeIndex, tickers: pd.Index) -> pd.DataFrame:
    """Combine liquidity sub-panels into a single axis (equal-weighted).

    Liquidity measures ease of trading without price impact:
    - Amihud illiquidity (inverted: low = more liquid)
    - Real turnover (volume / shares outstanding)
    - Spread proxy (if available)
    """
    dates, tickers = _validate_reference_axes(dates, tickers, "combine_liquidity_axis")
    components = []

    amihud = _get_panel(axis_panels, "liquidity_amihud", dates, tickers)
    if amihud is not None and amihud.notna().sum().sum() > MIN_COMPONENT_DATA_POINTS:
        # Low Amihud = more liquid = good
        components.append(("Amihud", -cross_sectional_zscore(amihud)))

    turnover = _get_panel(axis_panels, "liquidity_turnover", dates, tickers)
    if turnover is not None and turnover.notna().sum().sum() > MIN_COMPONENT_DATA_POINTS:
        # Higher turnover = more liquid
        components.append(("Turnover", cross_sectional_zscore(turnover)))

    spread = _get_panel(axis_panels, "liquidity_spread_proxy", dates, tickers)
    if spread is not None and spread.notna().sum().sum() > MIN_COMPONENT_DATA_POINTS:
        # Low spread = more liquid = good
        components.append(("Spread", -cross_sectional_zscore(spread)))

    if not components:
        logger.warning("    ⚠️  Liquidity axis has no valid components")
        return pd.DataFrame(np.nan, index=dates, columns=tickers)

    logger.info(f"    Liquidity axis components: {[c[0] for c in components]}")

    return _combine_components_properly(components, dates, tickers)


def combine_trading_intensity_axis(axis_panels: Dict[str, pd.DataFrame], dates: pd.DatetimeIndex, tickers: pd.Index) -> pd.DataFrame:
    """Combine trading intensity sub-panels into a single axis (equal-weighted).

    Trading intensity measures level of trading activity / market attention:
    - Relative volume (vs historical average)
    - Volume trend (recent vs older)
    - Turnover velocity (annualized turnover rate)

    This is distinct from liquidity which measures ease of trading.
    """
    dates, tickers = _validate_reference_axes(dates, tickers, "combine_trading_intensity_axis")
    components = []

    rel_vol = _get_panel(axis_panels, "trading_intensity_relative_volume", dates, tickers)
    if rel_vol is not None and rel_vol.notna().sum().sum() > MIN_COMPONENT_DATA_POINTS:
        components.append(("RelVol", cross_sectional_zscore(rel_vol)))

    vol_trend = _get_panel(axis_panels, "trading_intensity_volume_trend", dates, tickers)
    if vol_trend is not None and vol_trend.notna().sum().sum() > MIN_COMPONENT_DATA_POINTS:
        components.append(("VolTrend", cross_sectional_zscore(vol_trend)))

    turnover_vel = _get_panel(axis_panels, "trading_intensity_turnover_velocity", dates, tickers)
    if turnover_vel is not None and turnover_vel.notna().sum().sum() > MIN_COMPONENT_DATA_POINTS:
        components.append(("TurnoverVel", cross_sectional_zscore(turnover_vel)))

    if not components:
        logger.warning("    ⚠️  Trading Intensity axis has no valid components")
        return pd.DataFrame(np.nan, index=dates, columns=tickers)

    logger.info(f"    Trading Intensity axis components: {[c[0] for c in components]}")

    return _combine_components_properly(components, dates, tickers)


def combine_sentiment_axis(axis_panels: Dict[str, pd.DataFrame], dates: pd.DatetimeIndex, tickers: pd.Index) -> pd.DataFrame:
    """Combine sentiment sub-panels into a single axis (equal-weighted)."""
    dates, tickers = _validate_reference_axes(dates, tickers, "combine_sentiment_axis")
    components = []

    high_pct = _get_panel(axis_panels, "sentiment_52w_high_pct", dates, tickers)
    if high_pct is not None and high_pct.notna().sum().sum() > MIN_COMPONENT_DATA_POINTS:
        components.append(("52wHigh", cross_sectional_zscore(high_pct)))

    accel = _get_panel(axis_panels, "sentiment_price_acceleration", dates, tickers)
    if accel is not None and accel.notna().sum().sum() > MIN_COMPONENT_DATA_POINTS:
        components.append(("PriceAccel", cross_sectional_zscore(accel)))

    reversal = _get_panel(axis_panels, "sentiment_reversal", dates, tickers)
    if reversal is not None and reversal.notna().sum().sum() > MIN_COMPONENT_DATA_POINTS:
        components.append(("Reversal", cross_sectional_zscore(reversal)))

    if not components:
        logger.warning("    ⚠️  Sentiment axis has no valid components")
        return pd.DataFrame(np.nan, index=dates, columns=tickers)

    logger.info(f"    Sentiment axis components: {[c[0] for c in components]}")

    return _combine_components_properly(components, dates, tickers)


def combine_fundmom_axis(axis_panels: Dict[str, pd.DataFrame], dates: pd.DatetimeIndex, tickers: pd.Index) -> pd.DataFrame:
    """Combine fundamental momentum sub-panels (equal-weighted)."""
    dates, tickers = _validate_reference_axes(dates, tickers, "combine_fundmom_axis")
    components = []

    margin_chg = _get_panel(axis_panels, "fundmom_margin_change", dates, tickers)
    if margin_chg is not None and margin_chg.notna().sum().sum() > MIN_COMPONENT_DATA_POINTS:
        components.append(("MarginChg", cross_sectional_zscore(margin_chg)))

    sales_accel = _get_panel(axis_panels, "fundmom_sales_accel", dates, tickers)
    if sales_accel is not None and sales_accel.notna().sum().sum() > MIN_COMPONENT_DATA_POINTS:
        components.append(("SalesAccel", cross_sectional_zscore(sales_accel)))

    if not components:
        logger.warning("    ⚠️  FundMom axis has no valid components")
        return pd.DataFrame(np.nan, index=dates, columns=tickers)

    logger.info(f"    FundMom axis components: {[c[0] for c in components]}")

    return _combine_components_properly(components, dates, tickers)


def combine_carry_axis(axis_panels: Dict[str, pd.DataFrame], dates: pd.DatetimeIndex, tickers: pd.Index) -> pd.DataFrame:
    """Combine carry sub-panels (dividend yield)."""
    dates, tickers = _validate_reference_axes(dates, tickers, "combine_carry_axis")
    components = []

    div_yield = _get_panel(axis_panels, "carry_dividend_yield", dates, tickers)
    if div_yield is not None and div_yield.notna().sum().sum() > MIN_COMPONENT_DATA_POINTS:
        components.append(("DivYield", cross_sectional_zscore(div_yield)))

    # Could add shareholder yield here if data becomes available
    sh_yield = _get_panel(axis_panels, "carry_shareholder_yield", dates, tickers)
    if sh_yield is not None and sh_yield.notna().sum().sum() > MIN_COMPONENT_DATA_POINTS:
        # Only add if it's different from div_yield
        if div_yield is None or not div_yield.equals(sh_yield):
            components.append(("ShareholderYield", cross_sectional_zscore(sh_yield)))

    if not components:
        logger.warning("    ⚠️  Carry axis has no valid components")
        return pd.DataFrame(np.nan, index=dates, columns=tickers)

    logger.info(f"    Carry axis components: {[c[0] for c in components]}")

    return _combine_components_properly(components, dates, tickers)


def combine_defensive_axis(axis_panels: Dict[str, pd.DataFrame], dates: pd.DatetimeIndex, tickers: pd.Index) -> pd.DataFrame:
    """Combine defensive sub-panels (equal-weighted)."""
    dates, tickers = _validate_reference_axes(dates, tickers, "combine_defensive_axis")
    components = []

    stability = _get_panel(axis_panels, "defensive_earnings_stability", dates, tickers)
    if stability is not None and stability.notna().sum().sum() > MIN_COMPONENT_DATA_POINTS:
        components.append(("Stability", cross_sectional_zscore(stability)))

    beta = _get_panel(axis_panels, "defensive_beta_to_market", dates, tickers)
    if beta is not None and beta.notna().sum().sum() > MIN_COMPONENT_DATA_POINTS:
        # Low beta = defensive
        components.append(("LowBeta", -cross_sectional_zscore(beta)))

    if not components:
        logger.warning("    ⚠️  Defensive axis has no valid components")
        return pd.DataFrame(np.nan, index=dates, columns=tickers)

    logger.info(f"    Defensive axis components: {[c[0] for c in components]}")

    return _combine_components_properly(components, dates, tickers)


# ============================================================================
# QUINTILE BUCKET SELECTION
# ============================================================================

def quintile_bucket_selection(
    axis_raw_scores: pd.DataFrame,
    daily_returns: pd.DataFrame,
    n_buckets: int = N_BUCKETS,
    lookback_windows: tuple = ENSEMBLE_LOOKBACK_WINDOWS,
    lookback_weights: tuple = ENSEMBLE_LOOKBACK_WEIGHTS,
) -> Tuple[pd.Series, pd.DataFrame, pd.DataFrame, Dict]:
    """
    Quintile-based bucket selection - finds the BEST performing bucket.

    Returns:
        winning_bucket: Series of winning bucket index per date
        bucket_cum_returns: DataFrame of cumulative returns per bucket
        bucket_daily_returns: DataFrame of daily returns per bucket
        bucket_masks: Dict of bucket membership masks
    """
    if n_buckets < 2:
        raise ValueError("quintile_bucket_selection: n_buckets must be >= 2")
    if len(lookback_windows) == 0 or len(lookback_windows) != len(lookback_weights):
        raise ValueError(
            "quintile_bucket_selection: lookback_windows and lookback_weights must be non-empty and same length"
        )

    axis_raw = _validate_numeric_panel(axis_raw_scores, "axis_raw_scores")
    returns_raw = _validate_numeric_panel(daily_returns, "daily_returns")

    common_dates = axis_raw.index.intersection(returns_raw.index).sort_values()
    common_tickers = axis_raw.columns.intersection(returns_raw.columns)
    if len(common_dates) == 0:
        raise ValueError("quintile_bucket_selection: axis_raw_scores and daily_returns have no overlapping dates")
    if len(common_tickers) == 0:
        raise ValueError("quintile_bucket_selection: axis_raw_scores and daily_returns have no overlapping tickers")

    axis = axis_raw.reindex(index=common_dates, columns=common_tickers)
    aligned_returns = returns_raw.reindex(index=common_dates, columns=common_tickers)
    _debug_log(f"quintile inputs aligned: dates={len(common_dates)}, tickers={len(common_tickers)}")

    valid = axis.notna()
    dates = axis.index

    pct_ranks = axis.rank(axis=1, pct=True)

    bucket_edges = np.linspace(0, 1, n_buckets + 1)
    bucket_masks = {}
    bucket_daily = {}

    for i in range(n_buckets):
        lower = bucket_edges[i]
        upper = bucket_edges[i + 1]
        if i == n_buckets - 1:
            mask = (pct_ranks >= lower) & (pct_ranks <= upper) & valid
        else:
            mask = (pct_ranks >= lower) & (pct_ranks < upper) & valid

        bucket_masks[i] = mask
        bucket_w = mask.shift(1).astype(float)
        bucket_daily[i] = (aligned_returns * bucket_w).sum(axis=1) / bucket_w.sum(axis=1).replace(0.0, np.nan)

    bucket_cum = {}
    for i in range(n_buckets):
        cum_scores = []
        for lb, wt in zip(lookback_windows, lookback_weights):
            min_obs = max(int(lb * MIN_ROLLING_OBS_RATIO), 10)
            cum = rolling_cumulative_return(bucket_daily[i], lb, min_obs)
            cum_scores.append(cum * wt)
        bucket_cum[i] = pd.concat(cum_scores, axis=1).sum(axis=1)

    bucket_cum_df = pd.DataFrame(bucket_cum, index=dates)
    bucket_daily_df = pd.DataFrame(bucket_daily, index=dates)

    winning_bucket = bucket_cum_df.idxmax(axis=1).fillna(n_buckets // 2)
    winning_bucket = winning_bucket.shift(1).fillna(n_buckets // 2)

    return winning_bucket, bucket_cum_df, bucket_daily_df, bucket_masks


def compute_quintile_axis_scores(
    axis_raw_scores: pd.DataFrame,
    winning_bucket: pd.Series,
    n_buckets: int = N_BUCKETS,
) -> pd.DataFrame:
    """Compute axis scores based on winning quintile bucket (vectorized)."""
    if n_buckets < 2:
        raise ValueError("compute_quintile_axis_scores: n_buckets must be >= 2")

    axis = _validate_numeric_panel(axis_raw_scores, "axis_raw_scores")
    valid = axis.notna()
    dates = axis.index
    tickers = axis.columns

    if not isinstance(winning_bucket, pd.Series):
        raise TypeError("compute_quintile_axis_scores: winning_bucket must be pandas.Series")
    winner = winning_bucket.copy()
    winner.index = pd.DatetimeIndex(pd.to_datetime(winner.index, errors="coerce"))
    if winner.index.hasnans:
        raise ValueError("compute_quintile_axis_scores: winning_bucket index contains NaT")
    if winner.index.has_duplicates:
        raise ValueError("compute_quintile_axis_scores: winning_bucket index has duplicate dates")
    if not winner.index.is_monotonic_increasing:
        raise ValueError("compute_quintile_axis_scores: winning_bucket index must be monotonic increasing")

    pct_ranks = axis.rank(axis=1, pct=True)
    # Use numpy floor directly (faster than apply)
    stock_buckets = np.floor((pct_ranks * n_buckets).clip(upper=n_buckets - 1e-9))

    winning_bucket_aligned = pd.to_numeric(winner.reindex(dates), errors="coerce").fillna(n_buckets // 2)
    winner_broadcast = pd.DataFrame(
        np.tile(winning_bucket_aligned.values[:, np.newaxis], (1, len(tickers))),
        index=dates,
        columns=tickers,
    )

    distance = (stock_buckets - winner_broadcast).abs()
    max_distance = n_buckets - 1
    scores = 100.0 - (distance / max_distance) * 100.0

    return scores.where(valid, np.nan)

# ============================================================================
# EXPONENTIALLY-WEIGHTED FACTOR SELECTION (Revealed Preference)
#
# Weight factors by their RECENT spread performance.
# Recent months matter exponentially more than old months.
#
# The only "parameter" is the exponential decay rate, which is derived from
# a natural market timescale: we use decay = 0.5^(1/6) so that 6 months ago
# has exactly half the weight of today. This is not tuned - it's a structural
# choice based on typical regime duration.
# ============================================================================

# Decay rate: 6-month half-life (not a tuning parameter, structural choice)
# decay^6 = 0.5, so decay = 0.5^(1/6) ≈ 0.891
_DECAY_PER_MONTH = 0.5 ** (1.0 / 6.0)


def _compute_rank_squared_weights(monthly_returns: pd.DataFrame, decay: float, n_factors: int) -> np.ndarray:
    """Convert monthly spread returns into rank-squared factor weights."""
    if monthly_returns.empty:
        return np.ones(n_factors) / n_factors

    weighted_sum = np.zeros(n_factors)
    weight_total = np.zeros(n_factors)

    n_months = len(monthly_returns)
    for row_idx in range(n_months):
        months_ago = n_months - row_idx - 1
        exp_weight = decay ** months_ago
        month_vals = monthly_returns.iloc[row_idx].values.astype(float)

        valid_mask = ~np.isnan(month_vals)
        weighted_sum[valid_mask] += exp_weight * month_vals[valid_mask]
        weight_total[valid_mask] += exp_weight

    with np.errstate(divide="ignore", invalid="ignore"):
        avg_spread = np.where(weight_total > 0, weighted_sum / weight_total, np.nan)

    avg_spread_for_rank = np.nan_to_num(avg_spread, nan=-1e9)
    ranks = np.argsort(np.argsort(avg_spread_for_rank)) + 1
    rank_weights = ranks.astype(float) ** 2
    return rank_weights / rank_weights.sum()


def compute_mwu_weights(
    axis_daily_returns: Dict[str, Tuple[pd.Series, pd.Series]],
    dates: pd.DatetimeIndex,
    warmup_months: int = 6,
    debug: bool = False,
    walkforward_train_years: int | None = None,
    walkforward_first_test_year: int | None = None,
    walkforward_last_test_year: int | None = None,
) -> pd.DataFrame:
    """
    Compute factor weights based on exponentially-weighted recent performance.

    Revealed preference model: factors that delivered spread returns RECENTLY
    get higher weights. Old performance fades with a 6-month half-life.

    Method:
      1. Compute monthly spread returns (Q5 - Q1) for each factor
      2. Exponentially weight: 6 months ago = 50%, 12 months ago = 25%
      3. Rank-based weights: best recent performer gets highest weight

    The weights are derived from ranks, not raw returns, to avoid
    sensitivity to outlier months.

    NaN handling:
      - Daily spreads: NaN means no data for that factor on that day (not 0)
      - Monthly returns: computed only from valid days; month with <5 days -> NaN
      - Ranking: NaN spreads are treated as worst (ranked lowest)

    Args:
      axis_daily_returns: Dict of (high_daily, low_daily) returns per factor
      dates: DatetimeIndex of trading days
      warmup_months: Number of months of historical data to use for initial weights.
                     If > 0, uses historical performance to initialize weights instead
                     of equal weighting. This eliminates the cold-start problem.
                     Default: 6 months (recommended to match decay half-life)
      debug: If True, print month-by-month weight diagnostics.
      walkforward_train_years: If set (>0), enable yearly walk-forward mode.
                              Each test year uses only prior N calendar years
                              to train factor weights.
      walkforward_first_test_year: Optional first OOS test year (inclusive).
      walkforward_last_test_year: Optional last OOS test year (inclusive).

    Returns:
      DataFrame (dates x factor_names) with weights summing to 1 per row.
    """
    factor_names = list(axis_daily_returns.keys())
    n_factors = len(factor_names)
    if n_factors == 0:
        return pd.DataFrame(index=dates)

    # Daily spread returns for each factor (Q5 - Q1)
    # Keep NaN where data is missing (don't fill with 0)
    # IMPORTANT: Use FULL date range from the data, not just backtest dates
    # This allows warm-up to access historical data before backtest start
    all_dates_list = []
    for name, (high_daily, low_daily) in axis_daily_returns.items():
        all_dates_list.extend(high_daily.index.tolist())
        all_dates_list.extend(low_daily.index.tolist())
    
    if all_dates_list:
        all_dates = pd.DatetimeIndex(sorted(set(all_dates_list)))
    else:
        all_dates = dates
    
    daily_spreads = pd.DataFrame(index=all_dates, dtype=float)
    daily_valid = pd.DataFrame(index=all_dates, dtype=bool)
    for name, (high_daily, low_daily) in axis_daily_returns.items():
        high = high_daily.reindex(all_dates)
        low = low_daily.reindex(all_dates)
        spread = high - low
        daily_spreads[name] = spread
        daily_valid[name] = spread.notna()

    # Compute monthly spread returns (only from valid days)
    # Use full date range to get ALL months including historical
    month_periods = all_dates.to_period("M")
    unique_months = month_periods.unique().sort_values()

    if debug:
        logger.info(f"  [FIVE_FACTOR_DEBUG] MWU factors: {n_factors}, months: {len(unique_months)}")

    monthly_returns = pd.DataFrame(index=unique_months, columns=factor_names, dtype=float)
    monthly_valid_days = pd.DataFrame(index=unique_months, columns=factor_names, dtype=int)

    for month in unique_months:
        month_mask = month_periods == month
        month_spreads = daily_spreads.loc[month_mask]
        month_validity = daily_valid.loc[month_mask]

        for name in factor_names:
            valid_mask = month_validity[name]
            valid_spreads = month_spreads.loc[valid_mask, name]
            n_valid = len(valid_spreads)
            monthly_valid_days.loc[month, name] = n_valid

            if n_valid >= 5:  # Require at least 5 valid days
                monthly_returns.loc[month, name] = (1.0 + valid_spreads).prod() - 1.0
            else:
                monthly_returns.loc[month, name] = np.nan

    # Build weights month by month
    rows = []
    decay = _DECAY_PER_MONTH
    equal_weights = np.ones(n_factors) / n_factors

    # Find the first month that overlaps with backtest dates
    backtest_start_month = dates[0].to_period("M")
    first_backtest_month_idx = unique_months.get_loc(backtest_start_month) if backtest_start_month in unique_months else 0

    walkforward_enabled = walkforward_train_years is not None and walkforward_train_years > 0
    walkforward_weights_by_year: Dict[int, np.ndarray] = {}
    walkforward_train_ranges: Dict[int, tuple[int, int]] = {}

    if walkforward_enabled:
        if walkforward_first_test_year is None:
            walkforward_first_test_year = int(dates.min().year)
        if walkforward_last_test_year is None:
            walkforward_last_test_year = int(dates.max().year)

        if debug:
            logger.info(
                f"  [FIVE_FACTOR_DEBUG] MWU walk-forward enabled: "
                f"train_years={walkforward_train_years}, "
                f"test_years={walkforward_first_test_year}-{walkforward_last_test_year}"
            )

        for test_year in range(walkforward_first_test_year, walkforward_last_test_year + 1):
            train_start_year = test_year - walkforward_train_years
            train_end_year = test_year - 1
            month_years = unique_months.year
            train_mask = (month_years >= train_start_year) & (month_years <= train_end_year)
            train_monthly = monthly_returns.loc[train_mask]

            if train_monthly.empty:
                w_year = equal_weights.copy()
                if debug:
                    logger.info(
                        f"  [FIVE_FACTOR_DEBUG] MWU fold test={test_year}: "
                        f"train={train_start_year}-{train_end_year}, "
                        "months=0 -> equal weights"
                    )
            else:
                w_year = _compute_rank_squared_weights(train_monthly, decay, n_factors)
                if debug:
                    top_idx = np.argsort(-w_year)[:3]
                    top_weights = ", ".join([f"{factor_names[k]}={w_year[k]:.1%}" for k in top_idx])
                    logger.info(
                        f"  [FIVE_FACTOR_DEBUG] MWU fold test={test_year}: "
                        f"train={train_start_year}-{train_end_year}, "
                        f"months={len(train_monthly)}, top_weights=[{top_weights}]"
                    )

            walkforward_weights_by_year[test_year] = w_year
            walkforward_train_ranges[test_year] = (train_start_year, train_end_year)

    for i, month in enumerate(unique_months):
        if walkforward_enabled and int(month.year) in walkforward_weights_by_year:
            w = walkforward_weights_by_year[int(month.year)].copy()
        elif i == 0 or (i < first_backtest_month_idx):
            # Pre-backtest months or very first month ever - equal weights
            w = equal_weights.copy()
        elif i == first_backtest_month_idx and warmup_months > 0:
            # WARM-UP: Use previous months to initialize weights
            if i >= warmup_months:
                logger.info(f"  🔥 MWU Warm-up: Using {warmup_months} months of historical data for initial weights")
                warmup_monthly = monthly_returns.iloc[i - warmup_months : i]
                w = _compute_rank_squared_weights(warmup_monthly, decay, n_factors)
                logger.info(f"  ✅ Initialized with warm-up weights (top 3: {', '.join([f'{factor_names[k]}={w[k]:.1%}' for k in np.argsort(-w)[:3]])})")
            else:
                w = equal_weights.copy()
                logger.warning(f"  ⚠️  Only {i} months of history (need {warmup_months}) - using equal weights")
        else:
            # Exponentially-weighted average of all available past monthly returns
            history_monthly = monthly_returns.iloc[:i]
            w = _compute_rank_squared_weights(history_monthly, decay, n_factors)

        if debug:
            top_idx = np.argsort(-w)[:3]
            top_weights = ", ".join([f"{factor_names[k]}={w[k]:.1%}" for k in top_idx])
            if i > 0:
                prev_month = unique_months[i - 1]
                prev_spreads = monthly_returns.iloc[i - 1].astype(float)
                prev_top = prev_spreads.sort_values(ascending=False).head(3)
                prev_top_str = ", ".join([f"{k}={v:.2%}" for k, v in prev_top.items()])
                walkforward_str = ""
                if walkforward_enabled and int(month.year) in walkforward_train_ranges:
                    tr_start, tr_end = walkforward_train_ranges[int(month.year)]
                    walkforward_str = f" train={tr_start}-{tr_end}"
                logger.info(
                    f"  [FIVE_FACTOR_DEBUG] MWU month={month}: top_weights=[{top_weights}]"
                    f"{walkforward_str} prev_month={prev_month} spreads=[{prev_top_str}]"
                )
            else:
                logger.info(f"  [FIVE_FACTOR_DEBUG] MWU month={month}: top_weights=[{top_weights}] (initial)")

        # Record for all days in this month
        month_mask = month_periods == month
        month_dates = all_dates[month_mask]  # Use all_dates, not dates
        for d in month_dates:
            rows.append((d, w.copy()))

    weight_df = pd.DataFrame(
        [r[1] for r in rows],
        index=pd.DatetimeIndex([r[0] for r in rows]),
        columns=factor_names,
    )
    
    # Reindex to backtest dates and forward-fill
    weight_df = weight_df.reindex(dates).ffill()

    # Normalize (should already sum to 1)
    s = weight_df.sum(axis=1).replace(0.0, np.nan)
    weight_df = weight_df.div(s, axis=0).fillna(1.0 / n_factors)

    return weight_df
