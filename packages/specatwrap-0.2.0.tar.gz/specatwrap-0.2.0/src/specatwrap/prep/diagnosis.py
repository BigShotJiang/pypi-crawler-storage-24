"""
Diagnosis filter classes.

This module provides filter classes for preprocessing diagnosis parquet files.
"""

from abc import ABC, abstractmethod
import polars as pl


class BaseFilter(ABC):
    """
    Abstract base class for parquet file filters.

    Each filter type (diagnosis, procedure, medication, etc.) should inherit
    from this class and implement the apply() method with their specific
    filtering and transformation logic.
    """

    @abstractmethod
    def apply(self, lazy_frame: pl.LazyFrame) -> pl.LazyFrame:
        """
        Apply filtering and preprocessing logic to a LazyFrame.

        Args:
            lazy_frame: Input Polars LazyFrame to filter/transform

        Returns:
            Transformed Polars LazyFrame
        """
        pass

    def get_name(self) -> str:
        """
        Get the name of this filter type.

        Returns:
            Filter type name (defaults to class name without 'Filter' suffix)
        """
        class_name = self.__class__.__name__
        if class_name.endswith("Filter"):
            return class_name[:-6].lower()
        return class_name.lower()


class DiagnosisFilter(BaseFilter):
    """
    Filter for diagnosis parquet files.

    Applies diagnosis-specific filtering and column transformations:
    - Filters by birthdate (year > 1980)
    - Filters by region (Region Sjælland)
    - Renames columns to standardized event log format
    """

    CASE_ATTR = {
        k: f"case:{v}"
        for k, v in {
            "BORGER_FOEDSELSDATO": "patient:birthdate",
            "Personnummer": "concept:name",
        }.items()
    }

    EVENT_ATTR = {
        "ADIAG": "concept:name",
        "KONT_ANS_GEO_REG_TEKST": "org:group",
        "KONT_LPR_ENTITY_ID": "org:resource",
        "KONT_INST_EJERTYPE": "org:role",
        "KONT_STARTTIDSPUNKT": "start_timestamp",
        "KONT_SLUTTIDSPUNKT": "time:timestamp",
        # "BORGER_ALDER_AAR_IND": "patient:age",
        "PRIORITET_TEKST": "medical:priority",
        "KONT_TYPE_TEKST": "medical:contact_type",
    }

    def apply(self, lazy_frame: pl.LazyFrame) -> pl.LazyFrame:
        """
        Apply diagnosis-specific filtering and transformations.

        Args:
            lazy_frame: Input LazyFrame containing diagnosis data

        Returns:
            Filtered and transformed LazyFrame
        """
        return (
            lazy_frame
            # Filter by Birthdate (assuming it's a date/datetime type)
            .filter(pl.col("BORGER_FOEDSELSDATO").dt.year() > 1980)
            # Filter by Region
            .filter(pl.col("KONT_ANS_GEO_REG_TEKST") == "Region Sjælland")
            # Apply column name mappings
            .rename(self.CASE_ATTR | self.EVENT_ATTR)
        )
