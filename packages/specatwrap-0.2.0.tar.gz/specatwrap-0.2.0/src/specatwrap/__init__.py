"""
Specatwrap - A wrapper for processing healthcare data.

This module provides a CLI for converting and processing healthcare data files.
"""

import click
from pathlib import Path
import sys

from specatwrap.sas_converter import convert_sas_to_parquet
from specatwrap.prep import prep


@click.group()
@click.version_option(version="0.1.0")
def cli():
    """
    Specatwrap - A wrapper for processing healthcare data.

    A command-line tool for processing and converting healthcare data files.
    """
    pass


# Register command groups
cli.add_command(prep)


@cli.command()
@click.argument("input_file", type=click.Path(exists=True, path_type=Path))
@click.argument("output_path", type=click.Path(path_type=Path))
@click.option(
    "-c",
    "--chunk-size",
    type=int,
    default=100000,
    help="Number of rows to read per chunk (default: 100000)",
)
@click.option(
    "--compression",
    type=click.Choice(["zstd", "lz4", "snappy", "gzip"], case_sensitive=False),
    default="zstd",
    help="Parquet compression algorithm (default: zstd)",
)
@click.option(
    "--encoding",
    type=str,
    default=None,
    help="File encoding (default: auto-detect)",
)
@click.option(
    "--overwrite",
    is_flag=True,
    default=False,
    help="Overwrite existing output directory if it exists",
)
@click.option("-v", "--verbose", is_flag=True, help="Enable verbose output")
def sas2parquet(
    input_file, output_path, chunk_size, compression, encoding, overwrite, verbose
):
    """
    Convert a SAS file to Parquet format in chunks.

    INPUT_FILE: Path to the SAS file (.sas7bdat)

    OUTPUT_PATH: Path to output directory for Parquet files

    This command processes large SAS files in chunks to minimize memory usage.
    Each chunk is written to a separate Parquet file in the output directory.

    Example usage:

        specatwrap sas2parquet input.sas7bdat output_dir/

        specatwrap sas2parquet input.sas7bdat output_dir/ --chunk-size 50000 -v

        specatwrap sas2parquet input.sas7bdat output_dir/ --compression lz4

    Reading the data later with Polars:

        import polars as pl

        df = pl.read_parquet("output_dir/*.parquet")
    """
    try:
        convert_sas_to_parquet(
            input_file=input_file,
            output_path=output_path,
            chunk_size=chunk_size,
            compression=compression,
            encoding=encoding,
            overwrite=overwrite,
            verbose=verbose,
        )
    except FileNotFoundError as e:
        click.secho(f"✗ Error: File not found - {e}", fg="red", err=True)
        sys.exit(1)
    except PermissionError as e:
        click.secho(f"✗ Error: Permission denied - {e}", fg="red", err=True)
        sys.exit(1)
    except ValueError as e:
        click.secho(f"✗ Error: Invalid input - {e}", fg="red", err=True)
        sys.exit(1)
    except MemoryError:
        click.secho(
            f"✗ Error: Out of memory. Try a smaller --chunk-size", fg="red", err=True
        )
        sys.exit(1)
    except Exception as e:
        click.secho(f"✗ Error: {e}", fg="red", err=True)
        if verbose:
            import traceback

            traceback.print_exc()
        sys.exit(1)


def main():
    """Entry point for the CLI application."""
    cli()


if __name__ == "__main__":
    main()
