
class VitalVectorResultElement:
    pass

