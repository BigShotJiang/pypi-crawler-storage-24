#!/usr/bin/env python3
"""
Tests for get_property_value — verifies the simplified direct _properties
access works correctly.

Covers: Phase 7 (get_property_value direct access)
"""

import sys
from pathlib import Path

project_root = Path(__file__).parent.parent.parent
sys.path.insert(0, str(project_root))

from vital_ai_vitalsigns.vitalsigns import VitalSigns
from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node


def test_get_property_value_existing():
    """get_property_value returns the property object for an existing property."""
    vs = VitalSigns()
    node = VITAL_Node()
    node.URI = "http://example.com/gpv-test-1"
    node.name = "Test"

    name_uri = "http://vital.ai/ontology/vital-core#hasName"
    result = node.get_property_value(name_uri)
    assert result is not None
    # The result is a property instance, not a raw value
    assert str(result) == "Test"


def test_get_property_value_missing():
    """get_property_value returns None for a property that is not set."""
    vs = VitalSigns()
    node = VITAL_Node()
    node.URI = "http://example.com/gpv-test-2"

    name_uri = "http://vital.ai/ontology/vital-core#hasName"
    result = node.get_property_value(name_uri)
    assert result is None


def test_get_property_value_uri_prop():
    """get_property_value works for the URIProp."""
    vs = VitalSigns()
    node = VITAL_Node()
    node.URI = "http://example.com/gpv-test-3"

    uri_prop = "http://vital.ai/ontology/vital-core#URIProp"
    result = node.get_property_value(uri_prop)
    assert result is not None
    assert str(result) == "http://example.com/gpv-test-3"


def test_get_property_value_boolean():
    """get_property_value works for boolean properties."""
    vs = VitalSigns()
    node = VITAL_Node()
    node.URI = "http://example.com/gpv-test-4"
    node.active = True

    active_uri = "http://vital.ai/ontology/vital-core#isActive"
    result = node.get_property_value(active_uri)
    assert result is not None


def test_get_property_value_long():
    """get_property_value works for long/integer properties."""
    vs = VitalSigns()
    node = VITAL_Node()
    node.URI = "http://example.com/gpv-test-5"
    node.timestamp = 1234567890

    ts_uri = "http://vital.ai/ontology/vital-core#hasTimestamp"
    result = node.get_property_value(ts_uri)
    assert result is not None


def test_get_property_value_after_none_set():
    """get_property_value returns None after property is set to None."""
    vs = VitalSigns()
    node = VITAL_Node()
    node.URI = "http://example.com/gpv-test-6"
    node.name = "Test"

    name_uri = "http://vital.ai/ontology/vital-core#hasName"
    assert node.get_property_value(name_uri) is not None

    node.name = None
    assert node.get_property_value(name_uri) is None


def test_get_property_value_unknown_uri():
    """get_property_value returns None for an unknown/invalid URI."""
    vs = VitalSigns()
    node = VITAL_Node()
    node.URI = "http://example.com/gpv-test-7"

    result = node.get_property_value("http://example.com/nonexistent#prop")
    assert result is None
