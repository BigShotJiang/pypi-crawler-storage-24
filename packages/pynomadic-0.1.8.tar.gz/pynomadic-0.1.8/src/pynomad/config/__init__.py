from pathlib import Path
from pynomad.config.loader.manager import loadermanager
from pynomad.config.loader.base import BaseLoader
from pynomad.config.loader.file_loader import FileLoader
from pynomad.config.loader.file_loader import ExplicitFileLocator
from pynomad.config.auto.autoconfig import reload_all_config


def add_loader(loader: BaseLoader, *, clear_cache: bool = True):
    """添加自定义配置加载器

    Args:
        loader: 配置加载器实例 (FileLoader, EnvironmentLoader 等)
        clear_cache: 是否在添加后清除配置缓存，默认为 True

    Examples:
        >>> from pathlib import Path
        >>> from pynomad.config import add_loader
        >>> from pynomad.config.loader import FileLoader
        >>> from pynomad.config.loader.file_loader import ExplicitFileLocator
        >>>
        >>> loader = FileLoader(
        ...     locator=ExplicitFileLocator(Path.cwd() / "demo.toml"),
        ...     load_order=60,
        ... )
        >>> add_loader(loader)
    """
    loadermanager.add_loader(loader)
    reload_all_config()
    return loader


def remove_loader(loader: BaseLoader, *, clear_cache: bool = True) -> bool:
    """移除配置加载器

    Args:
        loader: 配置加载器实例
        clear_cache: 是否在移除后清除配置缓存，默认为 True

    Returns:
        bool: 成功移除返回 True，未找到返回 False

    Examples:
        >>> from pynomad.config import remove_loader
        >>> removed = remove_loader(loader)
    """
    result = loadermanager.remove_loader(loader)
    reload_all_config()
    return result


def add_file_loader(
    file_path: str | Path,
    *,
    load_order: int = 60,
):
    """添加指定配置文件加载器

    这是 `add_loader` 的便捷方法，专门用于加载特定配置文件。

    Args:
        file_path: 配置文件路径 (支持 .toml, .json, .yaml, .yml)
        load_order: 加载优先级，数值越小优先级越高，默认 60
        clear_cache: 是否在添加后清除配置缓存，默认为 True

    Examples:
        >>> from pathlib import Path
        >>> from pynomad.config import add_file_loader
        >>>
        >>> # 加载 demo.toml
        >>> add_file_loader("demo.toml")
        >>>
        >>> # 加载指定路径的配置文件
        >>> add_file_loader("./config/myapp.json")
        >>>
        >>> # 加载多个配置文件
        >>> add_file_loader("default.toml")
        >>> add_file_loader("development.toml")
    """
    loader = FileLoader(
        locator=ExplicitFileLocator(Path(file_path)),
        load_order=load_order,
    )
    loadermanager.add_loader(loader)
    reload_all_config()
    return loader
