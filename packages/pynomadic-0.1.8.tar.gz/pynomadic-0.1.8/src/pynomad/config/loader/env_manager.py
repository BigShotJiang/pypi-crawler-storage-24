"""环境管理模块

负责配置环境(development、test、production 等)的检测、解析和管理。
"""

from functools import lru_cache
from pathlib import Path
import warnings

from pynomad.common.converter import ensure_list, ensure_str
from pynomad.common.enhandce_dict import EnhancedDict
from pynomad.common.dict_utils import deep_merge, ensure_dict
from pynomad.common.environment import environ
from pynomad.common.types import AnyDict
from pynomad.config.loader.base import (
    ACTIVE,
    BASEDIR,
    CONFIG_URIS,
    DATADIR,
    ENVIRONMENTS,
    PROJECTNAME,
    BaseLoader,
    ConfigContext,
    EnvironmentContext,
)


class EnvironmentManager:
    """环境管理器

    负责检测、解析和管理配置环境。
    """

    def __init__(
        self,
        context: ConfigContext,
        basedir: Path | None = None,
        datadir: Path | None = None,
    ):
        """初始化环境管理器

        Args:
            context: 配置上下文
            basedir: 基础目录路径
            datadir: 数据目录路径
        """
        self._context: ConfigContext = context
        self._basedir: Path = basedir if basedir is not None else environ.project_dir
        self._datadir: Path = (
            datadir if datadir is not None else environ.project_dir / "data"
        )
        self._config_uris: list[str] = self._init_config_uris()
        self._env_configs: dict[str, AnyDict] = {"default": {}}
        self._active_envs: list[str] = self.detect_active_environments()
        # 初始化 default 环境的系统键值
        self._init_default_environment()

        # 解析环境配置(合并全局配置到每个环境)
        self._parse_environments_with_global_config()

    def _init_config_uris(self) -> list[str]:
        """初始化配置 URI 列表

        从所有 loaders 的 config_uri 属性收集配置 URI。

        Returns:
            list[str]: 配置 URI 列表
        """
        config_uris: list[str] = []
        # AI说它这么干是为了空间换时间,听他的
        seen_uris: set[str] = set()

        for loader in self._context.loaders:
            uri = loader.config_uri
            if uri in seen_uris:
                continue
            config_uris.append(uri)
            seen_uris.add(uri)

        return config_uris

    def _init_default_environment(self) -> None:
        """初始化 default 环境的系统键值

        这些键值是所有配置都必须继承的公共默认值（类似 Java 的 Object）。
        如果用户配置中已经定义了这些键,则用户配置会覆盖默认值。
        """
        default_env: AnyDict = self._env_configs["default"]

        # 设置系统配置的默认值
        default_env[BASEDIR] = str(self._basedir)
        default_env[DATADIR] = str(self._datadir)
        default_env[CONFIG_URIS] = self._config_uris.copy()
        default_env[PROJECTNAME] = environ.project_name

        # 设置环境特定的默认键
        default_env[ACTIVE] = ["default"]
        default_env[ENVIRONMENTS] = ["default"]

    # ==================== 环境检测 ====================

    def detect_active_environments(self) -> list[str]:
        """检测活动环境

        按照 loaders 列表的逆序优先级依次检测(高优先级优先):
        - loaders 列表: [低优先级, ..., 高优先级]
        - 检测顺序: 从后往前遍历,高优先级加载器优先检测
        - 第一个检测到环境的加载器即为结果

        设计说明:
        为什么只取第一个检测到的激活环境,而不是合并多个加载器的激活环境?
        1. 避免冲突: 如果配置文件指定 active=development,命令行指定 active=production,
           合并会导致行为不确定
        2. 符合直觉: 高优先级配置优先(如命令行 > 环境变量 > 配置文件),这与配置覆盖的语义一致
        3. 可预测性: 只使用第一个检测到的 active 配置,行为清晰明确,易于理解和调试
        4. 区分概念: 激活环境(指定当前使用哪个)和环境配置(定义每个环境的配置)是不同的概念,
           环境配置需要合并,但激活环境应该由用户明确指定
        5. 支持环境切换: 用户可以通过高优先级加载器(如命令行参数)覆盖配置文件中的 active 值,
           实现灵活的环境切换,例如:
           - 配置文件A: active=development (低优先级)
           - 配置文件B: active=production (高优先级)
           如果合并两者,则会同时激活 development 和 production 两个环境,这显然不符合预期,
           用户期望高优先级配置完全覆盖低优先级配置

        Returns:
            list[str]: 活动环境列表,至少包含 "default"
        """
        # 从后往前遍历(高优先级优先)
        for loader in reversed(self._context.loaders):
            env_names = self._extract_env_from_single_loader(loader, loader.name)
            if env_names:
                return self._ensure_default_first(env_names)

        return ["default"]

    def _ensure_default_first(self, env_names: list[str]) -> list[str]:
        """确保 default 环境在列表首位

        Args:
            env_names: 环境名称列表

        Returns:
            list[str]: 调整后的环境列表
        """
        if "default" not in env_names:
            return ["default"] + env_names

        if env_names[0] != "default":
            return ["default"] + [e for e in env_names if e != "default"]

        return env_names

    def _extract_env_from_single_loader(
        self, loader: BaseLoader, source_desc: str
    ) -> list[str]:
        """从单个加载器中提取环境配置

        Args:
            loader: 加载器
            source_desc: 来源描述

        Returns:
            list[str]: 环境名称列表,未检测到或异常时返回空列表
        """
        try:
            config: AnyDict = loader.load()
        except (AssertionError, KeyError, TypeError, ValueError) as e:
            warnings.warn(f"从{source_desc}加载配置失败: {e}")
            return []

        # 获取节名称列表
        section_names: list[str] = getattr(loader, "default_section_names", [])

        # 统一提取环境配置(先根节点,再检查各个节)
        return self._extract_config_value(
            config, "active", section_names, source_desc, support_comma=False
        )

    def _extract_config_value(
        self,
        config: AnyDict,
        key: str,
        section_names: list[str] | None = None,
        desc: str | None = None,
        support_comma: bool = True,
    ) -> list[str]:
        """从配置中提取指定 key 的值(通用方法)

        按照以下顺序查找:
        1. 先检查根节点是否有该 key
        2. 如果根节点没有,则依次检查指定的节节点

        Args:
            config: 配置字典
            key: 要查找的配置项键名
            section_names: 节名称列表,默认为空
            desc: 来源描述(用于日志)
            support_comma: 是否支持逗号分隔

        Returns:
            list[str]: 配置值列表,未检测到则返回空列表
        """
        values: list[str] = []
        # 1. 先检查根节点
        if key in config:
            values = self._parse_config_value(
                config[key], support_comma=support_comma, source=desc
            )
        if section_names is None:
            return values
        # 2. 检查各个节节点
        for section_name in section_names:
            section = ensure_dict(config.get(section_name))
            if not section:
                continue

            if key in section:
                section_values: list[str] = self._parse_config_value(
                    section[key], support_comma=support_comma, source=desc
                )
                values.extend(section_values)
        values = list(dict.fromkeys(values))

        return values

    def _parse_config_value(
        self,
        config_value: object,
        support_comma: bool = True,
        source: str | None = None,
    ) -> list[str]:
        """解析配置值为字符串列表

        支持将字符串或数组解析为字符串列表:
        - 字符串: 可选支持逗号分隔(如 "dev,test" -> ["dev", "test"])
        - 数组: 转换为字符串列表
        - 其他类型: 返回空列表

        Args:
            config_value: 配置值(字符串、数组等)
            support_comma: 是否支持逗号分隔的字符串(默认 True)
            source: 来源描述(用于日志,可选)

        Returns:
            list[str]: 字符串列表,解析失败时返回空列表
        """
        _ = source
        if str_value := ensure_str(config_value):
            values = (
                [e.strip() for e in str_value.split(",") if e.strip()]
                if support_comma
                else [str_value]
            )

            return values if values else []

        if list_value := ensure_list(config_value):
            values = [str(e) for e in list_value if e]
            return values if values else []
        return []

    # ==================== 环境解析 ====================

    def _parse_environments(self) -> dict[str, AnyDict]:
        """解析所有环境配置

        设计说明:
        每个环境节点都包含完整的配置数据:
        1. 顶级全局配置(如 top_key)
        2. 环境自身配置(如 development、production)
        3. default 环境存储默认全局配置,其他环境可覆盖

        支持两种配置方式:
        1. [env] 容器方式(向后兼容): [env.development]
        2. 扁平化方式: 根节点 environments 列表 + [development] 节点

        Returns:
            dict[str, AnyDict]: 环境名称到完整环境配置的映射
        """
        environments: dict[str, AnyDict] = {}
        environments["default"] = {}

        # 1. 合并所有 loader 的配置,获得顶级全局配置
        global_config: AnyDict = self._load_all_configs()

        # 2. 解析所有环境节点(包括 default)
        self._parse_env_from_container(global_config, environments)
        self._parse_env_from_root(global_config, environments)

        # 3. 处理 default 环境的特殊情况
        # 如果用户没有显式定义 [default] 节,则 default 环境继承顶级全局配置
        if not environments["default"] and global_config:

            global_extracted = self._extract_global_config(global_config)
            environments["default"] = global_extracted

        # 4. 为每个环境合并完整数据(全局配置 + default + 自身配置)
        for env_name in list(environments.keys()):
            # 确保该环境存在
            if env_name not in environments:
                continue

            # 跳过 default,它已经处理好了
            if env_name == "default":
                continue

            # 合并 global -> default -> env 自身
            env_config: AnyDict = {}
            env_config = deep_merge(
                env_config, self._extract_global_config(global_config)
            )

            if environments.get("default"):
                env_config = deep_merge(env_config, environments["default"])

            env_config = deep_merge(env_config, environments[env_name])
            environments[env_name] = env_config

        return environments

    def _load_all_configs(self) -> AnyDict:
        """加载并合并所有 loader 的配置

        Returns:
            AnyDict: 合并后的全局配置
        """
        merged_config: AnyDict = {}
        for loader in self._context.loaders:
            try:
                config: AnyDict = loader.load()
                merged_config = deep_merge(merged_config, config)
            except (AssertionError, KeyError, TypeError, ValueError) as e:
                warnings.warn(f"加载配置失败: {e}")
                continue
        return merged_config

    def _extract_global_config(self, config: AnyDict) -> AnyDict:
        """从配置中提取顶级全局配置

        不进行任何过滤,原样返回所有配置项。
        所有配置(包括内部配置项)都是配置的一部分,应该完整保留。
        只有路径配置会进行转换,其他配置原样继承。

        Args:
            config: 配置字典

        Returns:
            AnyDict: 顶级全局配置的副本
        """
        # 返回完整配置的副本,不进行任何过滤
        global_config: AnyDict = {}
        global_config.update(config)
        return global_config

    def _parse_env_from_container(
        self,
        config: AnyDict,
        environments: dict[str, AnyDict],
    ) -> None:
        """从 [env] 容器中解析环境配置(向后兼容)

        Args:
            config: 配置字典
            environments: 环境字典,会被更新
        """
        env_section = ensure_dict(config.get("env"))
        if not env_section:
            return

        # 获取环境列表,创建基本的环境字典
        self._parse_env_list(env_section, environments)

        # 解析每个环境的配置
        self._parse_env_configs(env_section, environments)

    def _parse_env_from_root(
        self,
        config: AnyDict,
        environments: dict[str, AnyDict],
    ) -> None:
        """从根节点解析扁平化环境配置

        通过 environments 列表识别环境节点,支持 [development] 这种扁平化格式。

        Args:
            config: 配置字典
            environments: 环境字典,会被更新
        """
        root_environments = ensure_list(config.get("environments"))
        if root_environments is None:
            return

        # 定义需要跳过的根节点键名(但 default 需要处理)
        skip_keys: set[str] = {"active", "environments", "env"}

        # 遍历所有根节点键,处理环境配置
        for key, value in config.items():
            if key == "default":
                # special case: 解析 [default] 节的配置
                default_config = ensure_dict(value)
                if default_config:
                    environments["default"].update(default_config)
            else:
                self._process_env_if_match(
                    key, value, root_environments, skip_keys, environments
                )

    def _process_env_if_match(
        self,
        key: str,
        value: object,
        allowed_keys: list[object],
        skip_keys: set[str],
        environments: dict[str, AnyDict],
    ) -> None:
        """处理单个环境配置(如果匹配条件)

        Args:
            key: 配置键名
            value: 配置值
            allowed_keys: 允许的键列表
            skip_keys: 需要跳过的键集合
            environments: 环境字典
        """
        if key not in allowed_keys or key in skip_keys:
            return

        self._init_env_if_needed(key, environments)

        env_config = ensure_dict(value)
        if not env_config:
            return
        self._process_single_env_config(key, env_config, environments)

    def _parse_env_list(
        self,
        env_section: AnyDict,
        environments: dict[str, AnyDict],
    ) -> None:
        """解析环境列表

        Args:
            env_section: env 配置节
            environments: 环境字典,会被更新
        """
        if "environments" not in env_section:
            return

        env_list = ensure_list(env_section["environments"])
        if not env_list:
            return

        for env_name in env_list:
            str_env_name = ensure_str(env_name)
            if not str_env_name:
                continue

            if str_env_name not in environments:
                environments[str_env_name] = {}

    def _parse_env_configs(
        self,
        env_section: AnyDict,
        environments: dict[str, AnyDict],
    ) -> None:
        """解析环境配置

        Args:
            env_section: env 配置节
            environments: 环境字典,会被更新
        """
        skip_keys: set[str] = {"environments", "active"}

        for key, value in env_section.items():
            self._process_env_if_match(
                key,
                value,
                list(env_section.keys()),
                skip_keys,
                environments,
            )

    def _init_env_if_needed(
        self, env_name: str, environments: dict[str, AnyDict]
    ) -> None:
        """初始化环境配置(如果不存在)

        Args:
            env_name: 环境名称
            environments: 环境字典
        """
        if env_name not in environments:
            environments[env_name] = {}

    def _apply_env_inheritance(
        self,
        env_name: str,
        env_config: AnyDict,
        environments: dict[str, AnyDict],
    ) -> None:
        """应用环境继承

        Args:
            env_name: 环境名称
            env_config: 环境配置
            environments: 环境字典
        """
        if "inherits" not in env_config:
            return

        inherits = env_config.get("inherits")
        inherits_list = ensure_list(inherits)
        if not inherits_list:
            return

        for parent_env in inherits_list:
            str_parent_env = ensure_str(parent_env)
            if not str_parent_env:
                continue

            if str_parent_env in environments:
                environments[env_name].update(environments[str_parent_env])

    def _merge_env_config(
        self,
        env_name: str,
        env_config: AnyDict,
        environments: dict[str, AnyDict],
    ) -> None:
        """合并环境配置

        Args:
            env_name: 环境名称
            env_config: 环境配置
            environments: 环境字典
        """
        for k, v in env_config.items():
            if k != "inherits":
                environments[env_name][k] = v

    def _process_single_env_config(
        self,
        env_name: str,
        env_config: AnyDict,
        environments: dict[str, AnyDict],
    ) -> None:
        """处理单个环境配置(初始化、继承、合并)

        Args:
            env_name: 环境名称
            env_config: 环境配置
            environments: 环境字典,会被更新
        """
        self._init_env_if_needed(env_name, environments)
        self._apply_env_inheritance(env_name, env_config, environments)
        self._merge_env_config(env_name, env_config, environments)

    # ==================== 环境访问 ====================

    @lru_cache(maxsize=128)
    def get_environment_config(
        self, env_name: str | tuple[str, ...] | None = None
    ) -> AnyDict:
        """获取环境配置

        支持传入单个环境名称或环境列表。
        根据环境列表合并多个环境配置（后者覆盖前者）。
        使用 lru_cache 自动缓存，相同环境列表会返回缓存的结果。

        Args:
            env_name: 环境名称或环境元组，如果为 None 则使用当前活动环境

        Returns:
            AnyDict: 合并后的环境配置
        """
        name = env_name
        # 1. 确定环境列表
        if name is None:
            target_envs: list[str] = self._active_envs.copy()
        elif isinstance(name, str):
            target_envs = [name]
        else:
            target_envs = list(name)

        # 2. 确保 default 在首位
        target_envs = self._ensure_default_first(target_envs)

        # 3. 合并配置
        merged: AnyDict = {}
        for name in target_envs:
            if name in self._env_configs:
                merged = deep_merge(merged, self._env_configs[name])
        # 处理合并后的激活环境
        merged["active"] = self.active_envs
        # 4. 转换为 EnhancedDict 以启用属性访问和递归转换
        return EnhancedDict(merged)

    def clear_cache(self) -> None:
        """清除缓存"""
        self.get_environment_config.cache_clear()

    def get_active_environment(self) -> list[EnvironmentContext]:
        """获取当前活动环境列表

        Returns:
            list[EnvironmentContext]: 活动环境对象列表
        """
        contexts: list[EnvironmentContext] = []
        for env_name in self._active_envs:
            ctx = EnvironmentContext(env_name, active=True)
            contexts.append(ctx)
        return contexts

    def get_available_environments(self) -> list[str]:
        """获取所有可用环境列表

        Returns:
            list[str]: 环境名称列表
        """
        return list(self._env_configs.keys())

    def set_environment(self, env_name: str | list[str]) -> None:
        """设置活动环境

        支持设置单个或多个环境,获取配置时会按顺序合并。

        Args:
            env_name: 环境名称(字符串或列表),例如 "development" 或 ["default", "development"]
        """
        # 转换为列表
        env_list: list[str] = (
            [env_name] if isinstance(env_name, str) else list(env_name)
        )

        # 确保 default 在第一位
        env_list = self._ensure_default_first(env_list)

        # 检查所有环境是否存在
        valid_envs: list[str] = []
        for env in env_list:
            if env not in self._env_configs:
                warnings.warn(
                    f"环境 {env} 不存在,可用环境: {self.get_available_environments()}"
                )
            else:
                valid_envs.append(env)

        if not valid_envs:
            warnings.warn("没有有效的环境,保持当前环境不变")
            return

        self._active_envs = valid_envs
        # 清理缓存,确保下次获取配置时使用新的环境设置
        self.get_environment_config.cache_clear()

    @property
    def active_envs(self) -> list[str]:
        """获取活动环境列表"""
        return self._active_envs

    @property
    def env_configs(self) -> dict[str, AnyDict]:
        """获取所有环境配置"""
        return self._env_configs

    # ==================== 属性访问 ====================

    @property
    def basedir(self) -> Path:
        """获取项目基本目录

        Returns:
            Path: 项目基本目录路径
        """
        return self._basedir

    @property
    def datadir(self) -> Path:
        """获取数据目录

        Returns:
            Path: 数据目录路径
        """
        return self._datadir

    @property
    def config_uris(self) -> list[str]:
        """获取配置 URI 列表

        Returns:
            list[str]: 配置 URI 列表
        """
        return self._config_uris

    def _parse_environments_with_global_config(self) -> None:
        """解析环境配置并合并全局配置

        将顶级全局配置合并到每个环境节点中,default 环境包含顶级配置,
        其他环境基于 default 并可以覆盖默认值。
        """
        # 保存已初始化的 default 环境配置(包含系统默认值)
        initialized_default: AnyDict = self._env_configs["default"].copy()

        # 解析所有环境配置
        self._env_configs = self._parse_environments()

        # 将初始化的系统默认值合并到解析后的 default 环境中
        # 用户配置会覆盖系统默认值
        self._env_configs["default"] = deep_merge(
            initialized_default, self._env_configs["default"]
        )

        # 更新 default 环境的 environments 字段为所有环境的名称列表
        all_env_names: list[str] = list(self._env_configs.keys())
        self._env_configs["default"]["environments"] = all_env_names
