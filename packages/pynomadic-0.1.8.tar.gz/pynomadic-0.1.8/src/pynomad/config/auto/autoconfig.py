# pylint: disable=C0301,C0302
"""自动配置模块

提供类似 Spring Boot @ConfigurationProperties 的功能，在对象创建时
自动使用 LoaderManager 获取的配置数据填充属性。

设计原则：
1. 使用装饰器标记需要自动配置的类
2. 在对象实例化时自动注入配置值
3. 支持配置前缀匹配
4. 支持类型自动转换
5. 与单例模式兼容
6. 配置对象应为只读，不建议运行时修改

使用示例：
    >>> from pynomad.config.autoconfig import inject, autowired, resource, alias
    >>>
    >>> @inject(prefix="database")
    >>> # 或使用 @autowired / @resource
    >>> class DatabaseConfig:
    >>>     host: str = "localhost"
    >>>     port: int = 3306
    >>>
    >>> config = DatabaseConfig()
    >>> # 配置会自动从 database.host 和 database.port 加载
    >>>
    >>> # 使用 @alias 装饰器为 TypedDict 定义别名
    >>> from typing_extensions import TypedDict
    >>>
    >>> @alias(pynomad_logging="pynomad.logging")
    >>> class LevelTypeDict(TypedDict):
    >>>     root: str
    >>>     pynomad: str
    >>>     pynomad_logging: str

单例模式说明：
    使用 @inject 装饰的类采用单例模式：
    - 多次创建返回同一实例
    - 嵌套配置对象也是单例
    - 全局配置一致性，避免意外的不一致
    - 不建议在运行时修改配置值

    如需临时修改配置，请使用 copy_config() 创建副本。
    测试中可使用 reset_singleton() 重置单例。
"""

from collections.abc import Callable
import copy
from functools import wraps
from dataclasses import (
    Field,
    asdict,
    dataclass,
    fields,
    is_dataclass,
    MISSING,
)
import json
from pathlib import Path
from typing import Any, cast
import warnings
from pynomad.common.types import (
    ConvertibleToFloat,
    ConvertibleToInt,
    AnyDict,
)
from pynomad.common.enhandce_dict import EnhancedDict
from pynomad.config.auto.field_info import is_field_info, FieldInfo
from pynomad.config.config_utils import (
    expand_path_variables,
    get_custom_converter,
    resolve_nested_value,
    unwrap_annotated,
)
from pynomad.common.dict_utils import is_dict
#from pynomad.console.logger import get_console_logger

#logger = get_console_logger()

type TargetType = type | str | object
type ConfigDecorator[C] = Callable[[type[C]], type[C]]
type Converter = Callable[[object], object] | None
# 使用全局配置管理器单例，确保动态添加的loader生效
from pynomad.config.loader.manager import loadermanager

# 跟踪所有 @inject 装饰的类，用于缓存清除时重新初始化
_injected_classes: list[tuple[type[object], str, bool]] = []


def convert_value(value: object, target_type: TargetType) -> object:
    """将配置值转换为目标类型

    Args:
        value: 原始配置值
        target_type: 目标类型

    Returns:
        object: 转换后的值
    """
    if value is None:
        return None

    # 如果 target_type 不是 type，无法进行类型转换
    if not isinstance(target_type, type):
        return value

    # 已经是目标类型
    if isinstance(value, target_type):
        return value

    # 转换基本类型
    try:
        if target_type == bool:
            if isinstance(value, str):
                return value.lower() in ("true", "1", "yes", "on")
            return bool(value)
        if target_type == int and isinstance(value, ConvertibleToInt):
            return int(value)
        if target_type == float and isinstance(value, ConvertibleToFloat):
            return float(value)
        if target_type == str:
            return str(value)
    except (ValueError, TypeError) as e:
        warnings.warn(f"类型转换失败: {value} -> {target_type}: {e}")
        return None

    return value


def convert_path_value(value: object, expand_variables: bool = True) -> Path | object:
    """将配置值转换为 Path 类型，可选展开路径变量

    Args:
        value: 原始配置值
        expand_variables: 是否展开路径变量（如 {workspace}, {home}），默认 True

    Returns:
        Path | object: 转换后的 Path 对象，或失败时的原值

    Notes:
        - 如果 expand_variables 为 False，直接将字符串转换为 Path
        - 如果 expand_variables 为 True 且字符串包含 {}，尝试展开变量
        - 展开失败时返回原值并记录警告日志
    """

    if isinstance(value, Path):
        return value
    if not isinstance(value, str):
        return value
    if not expand_variables:
        return Path(value)
    if "{" in value:
        try:
            return expand_path_variables(value)
        except (ValueError, OSError) as e:
            warnings.warn(f"展开路径变量失败: {value}, 错误: {e}")
            return value
    return Path(value)


def _is_configurable_class(t: type) -> bool:
    """检查类型是否是可配置的类

    Args:
        t: 类型

    Returns:
        bool: 是否是可配置类
    """
    return hasattr(t, "_config_prefix")


def _is_dataclass_type(t: type | object) -> bool:
    """检查类型是否是 dataclass

    Args:
        t: 类型

    Returns:
        bool: 是否是 dataclass
    """
    if not isinstance(t, type):
        # 处理 Optional 类型（如 LevelStyleMapProperties | None）
        origin = getattr(t, "__origin__", None)
        if origin is not None and origin is type(None):
            return False
        # 获取类型的参数（如 LevelStyleMapProperties | None 的 args 是 [LevelStyleMapProperties, None]）
        args = getattr(t, "__args__", None)
        if args and len(args) == 2:
            # 检查是否是 T | None 形式
            for arg in args:
                if isinstance(arg, type) and is_dataclass(arg):
                    return True
        return False
    return is_dataclass(t)


def _is_enhanced_dict_type(t: type) -> bool:
    """检查类型是否是 EnhancedDict

    Args:
        t: 类型

    Returns:
        bool: 是否是 EnhancedDict
    """
    return issubclass(t, EnhancedDict)


def _is_dict_of_dataclass_type(t: type | object) -> bool:
    """检查类型是否是 dict[str, dataclass]

    Args:
        t: 类型

    Returns:
        bool: 是否是 dict[str, dataclass] 类型
    """
    # 如果不是 type 类型，先尝试提取真实的类型（处理 Union 等）
    if not isinstance(t, type):
        # 获取类型的 origin 和 args
        origin = getattr(t, "__origin__", None)
        if origin is not None:
            # 对于 dict[str, T] 类型，直接使用 t
            if origin is dict:
                pass  # 继续处理
            else:
                return False
        else:
            return False

    # 获取类型的 origin 和 args
    origin = getattr(t, "__origin__", None)
    args = getattr(t, "__args__", None)

    # 检查是否是 dict 类型
    if origin is not dict:
        return False

    # 检查是否有两个泛型参数
    if args is None or len(args) != 2:
        return False

    # 检查第一个参数是否是 str（键类型）
    key_type = args[0]
    if key_type != str:
        return False

    # 检查第二个参数是否是 dataclass（值类型）
    value_type = args[1]
    return _is_dataclass_type(value_type) if isinstance(value_type, type) else False


def alias(**mapping: str) -> Callable[[type], type]:
    """为 TypedDict 定义字段别名映射的装饰器

    用于处理配置文件中键名与 TypedDict 字段名不一致的情况。
    例如，配置文件中使用 "pynomad.logging"，但 TypedDict 字段名为 "pynomad_logging"。

    Args:
        **mapping: 字段名 -> 别名的映射，如 pynomad_logging="pynomad.logging"

    Returns:
        装饰器函数

    Examples:
        >>> from typing_extensions import TypedDict
        >>> from pynomad.config.auto import alias
        >>>
        >>> @alias(pynomad_logging="pynomad.logging")
        >>> class LevelTypeDict(TypedDict):
        >>>     root: str
        >>>     pynomad: str
        >>>     pynomad_logging: str
        >>>
        >>> # 配置文件中的键为 "pynomad.logging"
        >>> # 但 TypedDict 中字段名为 "pynomad_logging"
    """

    def decorator(cls: type) -> type:
        # 将别名映射存储为类属性
        setattr(cls, "__typeddict_aliases__", mapping)
        return cls

    return decorator


def _is_typeddict_type(t: type) -> bool:
    """检查类型是否是 TypedDict

    Args:
        t: 类型

    Returns:
        bool: 是否是 TypedDict
    """
    return hasattr(t, "__required_keys__")


def inject[T](prefix: str = "", expand_path: bool = True) -> ConfigDecorator[T]:
    """配置装饰器

    标记需要自动配置的类，自动应用 @dataclass 并使用单例模式。
    在对象创建时，会自动从 LoaderManager 获取配置并填充属性。

    Args:
        prefix: 配置前缀，如 "database" 会匹配 database.host, database.port 等
        expand_path: 是否展开路径变量（如 {workspace}, {home}），默认 True

    Returns:
        装饰器函数

    Notes:
        - 自动应用 @dataclass，无需手动添加
        - 只支持单例模式，多次创建返回同一实例
        - 支持嵌套配置，如 prefix="database" 会匹配 database.host
        - 支持嵌套配置对象，属性可以是其他 @inject 装饰的类
        - 支持类型自动转换（str, int, float, bool, Path）
        - 支持自定义转换器，使用 ConfigField
        - 如果配置不存在，使用类的默认值
        - expand_path 参数控制是否展开 Path 类型中的变量（默认为 True）
        - Path 类型的默认值支持路径变量展开，如 field(default="{workspace}/cache")
        - 支持的路径变量：{workspace}, {home}, {cache}, {env:VAR_NAME} 等
        - 继承要求：如果使用继承，父类必须添加 @dataclass 装饰器，否则父类字段无法被注入配置

    Examples:
        >>> from pynomad.config.autoconfig import inject
        >>>
        >>> @inject(prefix="database")
        >>> class DatabaseConfig:
        >>>     host: str = "localhost"
        >>>     port: int = 3306
        >>>     username: str = "root"
        >>>
        >>> # 创建实例时自动注入配置
        >>> config = DatabaseConfig()
        >>> # 配置会自动从 database.host, database.port, database.username 加载
        >>> print(config.host)  # 配置文件中的值或 "localhost"

        >>> # 单例模式：多次创建返回同一实例
        >>> config1 = DatabaseConfig()
        >>> config2 = DatabaseConfig()
        >>> assert config1 is config2  # True

        >>> # 嵌套配置对象
        >>> @inject(prefix="app")
        >>> class AppConfig:
        >>>     name: str = "myapp"
        >>>     database: DatabaseConfig  # 自动从 app.database.* 加载
        >>>
        >>> app_config = AppConfig()
        >>> print(app_config.database.host)  # 自动配置

        >>> # 使用 ConfigField 自定义转换器
        >>> from datetime import datetime
        >>> @inject(prefix="schedule")
        >>> class ScheduleConfig:
        >>>     start_time: datetime = ConfigField(
        >>>         default=datetime.now(),
        >>>         converter=lambda v: datetime.fromisoformat(v)
        >>>     )
    """

    def decorator(cls: type[T]) -> type[T]:
        # 存储配置前缀
        setattr(cls, "_config_prefix", prefix)

        # 存储路径展开选项
        setattr(cls, "_expand_path", expand_path)

        # 单例实例
        setattr(cls, "_singleton_instance", None)

        # 存储初始化函数引用（用于缓存清除时重新初始化）
        setattr(cls, "_initialize_func", None)

        # 存储原始 __new__ 方法
        original_new = cls.__new__

        # 存储原始 __init__ 方法
        original_init = cls.__init__

        # 自动应用 @dataclass
        cls = dataclass(cls)

        def __new__(cls: type[T], *args: object, **kwargs: object) -> T:  # noqa: ARG002
            # 获取当前单例实例
            current_instance = getattr(cls, "_singleton_instance", None)

            # 单例模式：如果已存在实例，直接返回
            if current_instance is not None:
                return current_instance  # type: ignore

            # 创建新实例
            instance = original_new(cls)

            # 保存单例实例
            setattr(cls, "_singleton_instance", instance)

            return instance  # type: ignore

        def _initialize_instance(self: T, *args: object, **kwargs: object) -> None:
            """初始化实例（设置字段值并注入配置）"""
            _ = args
            # 为所有字段设置值，优先使用传入的参数，否则使用默认值，最后使用 None
            for f in fields(cls):  # pyright: ignore[reportArgumentType]
                if f.name in kwargs:
                    # 使用传入的参数值
                    setattr(self, f.name, kwargs[f.name])
                elif f.default is not MISSING:
                    # 检查是否是 FieldInfo 对象
                    if is_field_info(f.default):
                        field_info: FieldInfo = f.default
                        # 使用 FieldInfo 的 default 或 default_factory
                        if field_info.default is not None:
                            # 对于 Path 类型，尝试展开路径变量
                            attr_type = unwrap_annotated(f.type)
                            if (
                                isinstance(attr_type, type)
                                and attr_type == Path
                                and isinstance(field_info.default, str)
                                and expand_path
                            ):
                                setattr(
                                    self,
                                    f.name,
                                    convert_path_value(field_info.default, True),
                                )
                            else:
                                setattr(self, f.name, field_info.default)
                        elif (
                            field_info.default_factory is not None
                            and field_info.default_factory is not MISSING
                        ):
                            setattr(self, f.name, field_info.default_factory())
                        else:
                            setattr(self, f.name, None)
                    else:
                        # 使用字段默认值
                        setattr(self, f.name, f.default)
                elif f.default_factory is not MISSING:
                    # 使用默认值工厂函数
                    setattr(self, f.name, f.default_factory())
                else:
                    # 没有默认值，设置为 None
                    setattr(self, f.name, None)

            # 自动注入配置
            _inject_config(self, cls, prefix, expand_path)

        @wraps(original_init)
        def __init__(self: T, *args: object, **kwargs: object) -> None:
            # 单例模式：避免重复初始化
            if getattr(cls, "_singleton_instance", None) is self:
                _initialize_instance(self, *args, **kwargs)

        def __repr__(self: T) -> str:
            """返回 JSON 格式的字符串表示，便于调试"""
            # 将 dataclass 转换为字典
            assert is_dataclass(self), "self 必须是 dataclass 实例"
            data = asdict(self)  # pyright: ignore[reportArgumentType]

            # 自定义 JSON 编码器，处理 Path 等非序列化类型
            class DataclassEncoder(json.JSONEncoder):
                def default(self, obj):  # type: ignore
                    # 处理 Path 对象
                    if isinstance(obj, Path):
                        return str(obj)
                    # 处理日期时间对象
                    if hasattr(obj, "isoformat"):  # type: ignore
                        return obj.isoformat()  # type: ignore
                    # 处理枚举类型
                    if hasattr(obj, "value"):  # type: ignore
                        return obj.value  # type: ignore
                    # 处理其他特殊对象
                    try:
                        return super().default(obj)
                    except TypeError:
                        return str(obj)  # type: ignore

            try:
                return json.dumps(
                    data, indent=2, ensure_ascii=False, cls=DataclassEncoder
                )
            except TypeError:
                return object.__repr__(self)

        def __str__(self: T) -> str:
            """返回 JSON 格式的字符串表示，便于调试"""
            return self.__repr__()

        # 替换 __new__ 和 __init__ 方法
        cls.__new__ = __new__
        cls.__init__ = __init__
        cls.__repr__ = __repr__
        cls.__str__ = __str__

        # 存储初始化函数和参数，用于缓存清除时重新初始化
        setattr(cls, "_initialize_func", _initialize_instance)
        setattr(cls, "_config_prefix", prefix)
        setattr(cls, "_expand_path", expand_path)

        # 注册到全局列表（避免重复注册）
        if not any(c[0] is cls for c in _injected_classes):
            _injected_classes.append((cls, prefix, expand_path))

        return cls

    return decorator


def _inject_config(
    instance: object, cls: type, prefix: str, expand_path: bool = True
) -> None:
    """注入配置到实例

    Args:
        instance: 对象实例
        cls: 类对象
        prefix: 配置前缀
        expand_path: 是否展开路径变量
    """
    config_dict = get_config_dict()
    if config_dict is None:
        setattr(instance, "_autowired", False)  # 没有配置文件
        return

    # 检查是否存在指定前缀的配置
    from pynomad.config.config_utils import resolve_nested_value
    prefix_config = resolve_nested_value(config_dict, prefix)
    if prefix_config is None:
        setattr(instance, "_autowired", False)  # 前缀不存在，使用默认值
        return

    # 存在配置前缀，进行正常的注入逻辑
    setattr(instance, "_autowired", True)  # 标记：从配置文件读取了值

    # 从 dataclass 字段中获取属性
    for f in fields(cls):
        attr_name = f.name
        attr_type = f.type
        # 解析 Annotated 类型
        attr_type = unwrap_annotated(attr_type)

        # 跳过私有属性
        if attr_name.startswith("_"):
            continue

        # 检查是否有自定义转换器（ConfigField）
        custom_converter: Converter = get_custom_converter(f)

        # 检查是否是嵌套配置对象（有自定义转换器时跳过）
        if (
            custom_converter is None
            and isinstance(attr_type, type)
            and _is_configurable_class(attr_type)
            and getattr(instance, attr_name, None) is None  # 只处理值为 None 的嵌套字段
        ):
            _process_nested_config(
                instance, cls, attr_name, attr_type, prefix, expand_path
            )
        elif (
            custom_converter is None
            and isinstance(attr_type, type)
            and not _is_configurable_class(attr_type)
            and getattr(instance, attr_name, None) is None
            and _is_enhanced_dict_type(attr_type)
        ):
            # 处理 EnhancedDict 类型
            _process_enhanced_dict_config(
                instance,
                cls,
                attr_name,
                attr_type,
                config_dict,
                prefix,
                f,  # 传递字段对象
            )
        elif (
            custom_converter is None
            and isinstance(attr_type, type)
            and not _is_configurable_class(attr_type)
            and getattr(instance, attr_name, None) is None
            and _is_typeddict_type(attr_type)
        ):
            # 处理 TypedDict 类型
            _process_typeddict_config(
                instance,
                cls,
                attr_name,
                attr_type,
                config_dict,
                prefix,
                expand_path,
                f,  # 传递字段对象
            )
        elif (
            custom_converter is None
            and (
                not isinstance(attr_type, type) or not _is_configurable_class(attr_type)
            )
            and getattr(instance, attr_name, None) is None
            and _is_dict_of_dataclass_type(attr_type)
        ):
            # 处理 dict[str, dataclass] 类型
            _process_dict_of_dataclass_config(
                instance,
                cls,
                attr_name,
                attr_type,
                config_dict,
                prefix,
                expand_path,
                f,  # 传递字段对象
            )
        elif (
            custom_converter is None
            and isinstance(attr_type, type)
            and not _is_configurable_class(attr_type)
            and getattr(instance, attr_name, None) is None
            and (
                _is_dataclass_type(attr_type)
                or (
                    hasattr(attr_type, "__annotations__")
                    and not attr_type.__module__.startswith(
                        (
                            "builtins",
                            "typing",
                            "pathlib",
                            "datetime",
                            "collections",
                        )
                    )
                )
            )
        ):
            # 处理普通的 dataclass 类型（没有 @inject 装饰器）
            _process_dataclass_config(
                instance,
                cls,
                attr_name,
                attr_type,
                config_dict,
                prefix,
                expand_path,
            )
        else:
            _process_simple_config(
                instance,
                cls,
                attr_name,
                attr_type,
                config_dict,
                prefix,
                custom_converter,
                f,  # 传递字段对象
                expand_path,
            )


def _process_nested_config(
    instance: object,
    cls: type,
    attr_name: str,
    attr_type: type,
    prefix: str,
    expand_path: bool = True,
) -> None:
    """处理嵌套配置对象

    Args:
        instance: 对象实例
        cls: 类对象
        attr_name: 属性名称
        attr_type: 属性类型
        prefix: 配置前缀
        expand_path: 是否展开路径变量
    """
    try:
        nested_prefix = f"{prefix}.{attr_name}" if prefix else attr_name
        nested_instance = attr_type()

        # 递归注入嵌套配置
        _inject_config(nested_instance, attr_type, nested_prefix, expand_path)

        # 设置嵌套对象属性
        setattr(instance, attr_name, nested_instance)

    except (TypeError, ValueError, RuntimeError, AttributeError) as e:
        warnings.warn(f"创建嵌套配置对象失败: {cls.__name__}.{attr_name}: {e}")


def _process_enhanced_dict_config(
    instance: object,
    cls: type,
    attr_name: str,
    attr_type: type,
    config_dict: AnyDict,
    prefix: str,
    field_obj: Field[Any] | None = None,
) -> None:
    """处理 EnhancedDict 配置字段

    Args:
        instance: 对象实例
        cls: 类对象
        attr_name: 属性名称
        attr_type: 属性类型（EnhancedDict 子类）
        config_dict: 配置字典
        prefix: 配置前缀
        field_obj: 字段对象（用于获取别名）
    """
    try:
        # 检查字段是否有 FieldInfo 和 alias
        field_info: FieldInfo | None = None
        if field_obj and is_field_info(field_obj.default):
            assert isinstance(field_obj.default, FieldInfo)
            field_info = field_obj.default

        # 如果字段有别名，使用别名作为配置键，否则使用属性名
        config_key_name: str = ""
        if field_info and field_info.alias:
            config_key_name = field_info.alias
        else:
            config_key_name = attr_name

        config_key: str = f"{prefix}.{config_key_name}" if prefix else config_key_name

        # 从配置中获取嵌套字典
        nested_config = resolve_nested_value(config_dict, config_key)

        if nested_config is None:
            # 创建空 EnhancedDict 实例
            enhanced_dict = attr_type()
            setattr(instance, attr_name, enhanced_dict)
            return

        # 确保是字典类型
        if not is_dict(nested_config):
            return

        # 获取默认值工厂或默认值
        default_value: object | None = (
            _get_default_value(cls, attr_name, field_obj) if field_obj else None
        )

        # 如果默认值是一个 EnhancedDict 实例，使用它作为基础
        if default_value and isinstance(default_value, EnhancedDict):
            enhanced_dict = default_value
            enhanced_dict.update(nested_config)
        else:
            # 创建新的 EnhancedDict 实例
            enhanced_dict = attr_type(nested_config)

        # 设置属性值
        setattr(instance, attr_name, enhanced_dict)

    except (TypeError, ValueError, RuntimeError, AttributeError) as e:
        warnings.warn(f"创建 EnhancedDict 失败: {cls.__name__}.{attr_name}: {e}")


def _process_typeddict_config(
    instance: object,
    cls: type,
    attr_name: str,
    attr_type: type,
    config_dict: AnyDict,
    prefix: str,
    expand_path: bool = True,
    field_obj: Field[Any] | None = None,
) -> None:
    """处理 TypedDict 配置字段

    Args:
        instance: 对象实例
        cls: 类对象
        attr_name: 属性名称
        attr_type: 属性类型（TypedDict）
        config_dict: 配置字典
        prefix: 配置前缀
        expand_path: 是否展开路径变量
        field_obj: 字段对象（用于获取别名）
    """
    try:
        # 检查字段是否有 FieldInfo 和 alias
        field_info: FieldInfo | None = None
        if field_obj and is_field_info(field_obj.default):
            assert isinstance(field_obj.default, FieldInfo)
            field_info = field_obj.default

        # 如果字段有别名，使用别名作为配置键，否则使用属性名
        config_key_name: str = ""
        if field_info and field_info.alias:
            config_key_name = field_info.alias
        else:
            config_key_name = attr_name

        config_key: str = f"{prefix}.{config_key_name}" if prefix else config_key_name

        # 从配置中获取嵌套字典
        nested_config = resolve_nested_value(config_dict, config_key)

        if nested_config is None:
            # 创建空字典（TypedDict 运行时就是普通 dict）
            setattr(instance, attr_name, {})
            return

        # 确保是字典类型
        if not is_dict(nested_config):
            return

        # 创建普通字典（TypedDict 运行时就是 dict）
        result_dict: dict[str, Any] = {}

        # 获取 TypedDict 的类型注解
        annotations = getattr(attr_type, "__annotations__", {})

        # 获取别名映射（从装饰器设置的 __typeddict_aliases__）
        aliases: dict[str, str] = getattr(attr_type, "__typeddict_aliases__", {})

        # 构建反向别名映射（配置键 -> TypedDict 字段名）
        alias_reverse: dict[str, str] = {}
        for typeddict_key, alias_key in aliases.items():
            alias_reverse[alias_key] = typeddict_key

        # 遍历配置中的键值对
        if isinstance(nested_config, dict):
            for config_field_key, value in cast(dict[str, Any], nested_config).items():
                # 确定字段名（优先使用别名映射）
                typeddict_field_name = alias_reverse.get(
                    config_field_key, config_field_key
                )

                # 获取字段的类型注解
                field_type = annotations.get(typeddict_field_name, Any)

                # 如果类型注解不存在或为 Any，直接使用原值
                if field_type is Any:
                    result_dict[typeddict_field_name] = value
                    continue

                # Path 类型特殊处理
                if isinstance(field_type, type) and field_type == Path:
                    converted_value = convert_path_value(
                        cast(object, value), expand_path
                    )
                else:
                    # 使用内置类型转换
                    converted_value = convert_value(cast(object, value), field_type)

                # 转换失败则跳过
                if converted_value is None:
                    warnings.warn(
                        f"类型转换失败: {attr_name}.{typeddict_field_name} = {value}"
                    )
                    continue

                result_dict[typeddict_field_name] = converted_value

        # 设置属性值
        setattr(instance, attr_name, result_dict)
    except (TypeError, ValueError, RuntimeError, AttributeError) as e:
        warnings.warn(f"创建 TypedDict 失败: {cls.__name__}.{attr_name}: {e}")


def _convert_dict_to_dataclass(
    config_value: object,
    dataclass_type: type | object,
    expand_path: bool = True,
) -> object | None:
    """将字典配置值转换成 dataclass 实例

    Args:
        config_value: 配置值（字典）
        dataclass_type: 目标 dataclass 类型（可能是 Union 类型）
        expand_path: 是否展开路径变量

    Returns:
        object | None: dataclass 实例，失败返回 None
    """
    if not is_dict(config_value):
        return None

    # 处理 Optional 类型（如 LevelStyleMapProperties | None）
    if not isinstance(dataclass_type, type):
        args = getattr(dataclass_type, "__args__", None)
        if args and len(args) == 2:
            # 找到非 None 的类型参数
            for arg in args:
                if isinstance(arg, type) and is_dataclass(arg):
                    dataclass_type = arg
                    break
            else:
                return None

    # 如果类型不是 dataclass，自动应用 @dataclass
    if not is_dataclass(dataclass_type):
        assert isinstance(dataclass_type, type)
        dataclass_type = dataclass(dataclass_type)  # type: ignore[assignment]

    # 创建 dataclass 实例
    dataclass_instance = dataclass_type()  # type: ignore

    # 遍历 dataclass 的字段，从配置中填充值
    for field_obj in fields(dataclass_type):  # type: ignore
        field_name = field_obj.name
        field_type = field_obj.type
        field_type = unwrap_annotated(field_type)

        # 跳过私有属性
        if field_name.startswith("_"):
            continue

        # 从配置中获取值
        config_item_value: Any | None = None
        if isinstance(config_value, dict):
            config_item_value = config_value.get(field_name)  # type: ignore

        # 如果配置中存在该值，使用配置值
        if config_item_value is not None:
            # Path 类型特殊处理
            if isinstance(field_type, type) and field_type == Path:
                converted_value = convert_path_value(
                    config_item_value, expand_path  # type: ignore
                )
            # 嵌套 dataclass 类型特殊处理
            elif isinstance(field_type, type) and _is_dataclass_type(field_type):
                # 递归处理嵌套的 dataclass
                converted_value = _convert_dict_to_dataclass(
                    config_item_value, field_type, expand_path  # type: ignore
                )
            else:
                # 使用内置类型转换
                converted_value = convert_value(config_item_value, field_type)  # type: ignore

            # 转换失败，跳过
            if converted_value is None:
                warnings.warn(f"类型转换失败: {field_name} = {config_item_value}")
                continue
        else:
            # 配置中不存在该值，使用默认值
            converted_value = _get_default_value(
                dataclass_type, field_name, field_obj  # type: ignore
            )
            if converted_value is None:
                continue

        # 设置属性值
        setattr(dataclass_instance, field_name, converted_value)  # type: ignore

    return dataclass_instance  # type: ignore


def _process_dataclass_config(
    instance: object,
    cls: type,
    attr_name: str,
    attr_type: type[Any],
    config_dict: AnyDict,
    prefix: str,
    expand_path: bool = True,
) -> None:
    """处理普通的 dataclass 配置字段（没有 @inject 装饰器）

    Args:
        instance: 对象实例
        cls: 类对象
        attr_name: 属性名称
        attr_type: 属性类型（dataclass）
        config_dict: 配置字典
        prefix: 配置前缀
        expand_path: 是否展开路径变量
    """
    try:
        # 如果类型不是 dataclass，自动应用 @dataclass
        if not is_dataclass(attr_type):
            assert isinstance(attr_type, type)
            attr_type = dataclass(attr_type)  # type: ignore[assignment]

        # 构建配置键
        config_key = f"{prefix}.{attr_name}" if prefix else attr_name

        # 从配置中获取嵌套字典
        nested_config = resolve_nested_value(config_dict, config_key)

        if nested_config is None:
            return

        # 确保是字典类型
        if not is_dict(nested_config):
            warnings.warn(f"{config_key} 的配置值不是字典类型，跳过")
            return

        # 创建嵌套 dataclass 实例
        nested_instance = attr_type()  # type: ignore

        # 遍历嵌套 dataclass 的字段，从配置中填充值
        for nested_field in fields(attr_type):  # type: ignore
            nested_attr_name = nested_field.name
            nested_attr_type = nested_field.type
            nested_attr_type = unwrap_annotated(nested_attr_type)

            # 跳过私有属性
            if nested_attr_name.startswith("_"):
                continue

            # 检查字段是否有 FieldInfo 和 alias
            nested_field_info: FieldInfo | None = None
            if is_field_info(nested_field.default):
                assert isinstance(nested_field.default, FieldInfo)
                nested_field_info = nested_field.default

            # 确定配置键名（考虑 alias）
            nested_config_key_name: str = ""
            if nested_field_info and nested_field_info.alias:
                nested_config_key_name = nested_field_info.alias
            else:
                nested_config_key_name = nested_attr_name

            # 从嵌套配置中获取值
            nested_config_value: dict[Any, Any] | None = None
            if isinstance(nested_config, dict):
                nested_config_value = cast(
                    dict[Any, Any], nested_config.get(nested_config_key_name)
                )

            # 如果配置中存在该值，使用配置值
            if nested_config_value is not None:
                # Path 类型特殊处理
                if isinstance(nested_attr_type, type) and nested_attr_type == Path:
                    converted_value = convert_path_value(
                        nested_config_value, expand_path
                    )
                else:
                    # 使用内置类型转换
                    converted_value = convert_value(
                        nested_config_value, nested_attr_type
                    )

                # 转换失败，跳过
                if converted_value is None:
                    warnings.warn(
                        f"类型转换失败: {nested_attr_name} = {nested_config_value}"
                    )
                    continue
            else:
                # 配置中不存在该值，使用默认值
                converted_value = _get_default_value(
                    attr_type, nested_attr_name, nested_field  # type: ignore
                )
                if converted_value is None:
                    continue

            # 设置属性值
            setattr(nested_instance, nested_attr_name, converted_value)  # type: ignore

        # 设置嵌套对象属性
        setattr(instance, attr_name, nested_instance)
    except (TypeError, ValueError, RuntimeError, AttributeError) as e:
        warnings.warn(f"创建嵌套 dataclass 失败: {cls.__name__}.{attr_name}: {e}")


def _process_dict_of_dataclass_config(
    instance: object,
    cls: type,
    attr_name: str,
    attr_type: type | object,
    config_dict: AnyDict,
    prefix: str,
    expand_path: bool = True,
    field_obj: Field[Any] | None = None,
) -> None:
    """处理 dict[str, dataclass] 类型的配置字段

    Args:
        instance: 对象实例
        cls: 类对象
        attr_name: 属性名称
        attr_type: 属性类型（dict[str, dataclass]）
        config_dict: 配置字典
        prefix: 配置前缀
        expand_path: 是否展开路径变量
        field_obj: 字段对象（用于获取别名）
    """
    try:
        # 检查字段是否有 FieldInfo 和 alias
        field_info: FieldInfo | None = None
        if field_obj and is_field_info(field_obj.default):
            assert isinstance(field_obj.default, FieldInfo)
            field_info = field_obj.default

        # 如果字段有别名，使用别名作为配置键，否则使用属性名
        config_key_name: str = ""
        if field_info and field_info.alias:
            config_key_name = field_info.alias
        else:
            config_key_name = attr_name

        config_key: str = f"{prefix}.{config_key_name}" if prefix else config_key_name

        # 从配置中获取嵌套字典
        nested_config = resolve_nested_value(config_dict, config_key)

        if nested_config is None:
            # 创建空字典
            setattr(instance, attr_name, {})
            return

        # 确保是字典类型
        if not is_dict(nested_config):
            warnings.warn(f"{config_key} 的配置值不是字典类型，跳过")
            return

        # 获取泛型参数：dict[K, V] -> V 是 dataclass 类型
        args = getattr(cast(object, attr_type), "__args__", None)
        if args is None or len(args) != 2:
            warnings.warn(f"无法解析 {attr_type} 的泛型参数，跳过")
            return

        # args[1] 可能不是 type 类型，需要先检查
        if not isinstance(args[1], type):
            warnings.warn(f"{args[1]} 不是有效类型，跳过")
            return

        value_type: type = cast(type, args[1])

        # 创建结果字典
        result_dict: dict[str, Any] = {}

        # 遍历配置字典中的每个键值对
        for key, value in cast(dict[str, Any], nested_config).items():
            # 确保值是字典类型
            if not is_dict(value):
                warnings.warn(f"{config_key}.{key} 的配置值不是字典类型，跳过")
                continue

            # 如果值类型不是 dataclass，自动应用 @dataclass
            if not is_dataclass(value_type):  # type: ignore
                value_type = dataclass(value_type)  # type: ignore

            # 创建 dataclass 实例
            dataclass_instance = value_type()  # type: ignore

            # 遍历 dataclass 的字段，从配置中填充值
            for nested_field in fields(value_type):  # type: ignore
                nested_attr_name = nested_field.name
                nested_attr_type = nested_field.type
                nested_attr_type = unwrap_annotated(nested_attr_type)

                # 跳过私有属性
                if nested_attr_name.startswith("_"):
                    continue

                # 检查字段是否有 FieldInfo 和 alias
                nested_field_info: FieldInfo | None = None
                if is_field_info(nested_field.default):
                    assert isinstance(nested_field.default, FieldInfo)
                    nested_field_info = nested_field.default

                # 确定配置键名（考虑 alias）
                nested_config_key_name: str = ""
                if nested_field_info and nested_field_info.alias:
                    nested_config_key_name = nested_field_info.alias
                else:
                    nested_config_key_name = nested_attr_name

                # 从嵌套配置中获取值
                nested_config_value: Any | None = None
                if isinstance(value, dict):
                    nested_config_value = value.get(nested_config_key_name)  # type: ignore

                # 如果配置中存在该值，使用配置值
                if nested_config_value is not None:
                    # Path 类型特殊处理
                    if isinstance(nested_attr_type, type) and nested_attr_type == Path:
                        converted_value = convert_path_value(
                            nested_config_value, expand_path  # type: ignore
                        )
                    # 嵌套 dataclass 类型特殊处理
                    elif _is_dataclass_type(nested_attr_type):
                        # 递归处理嵌套的 dataclass
                        converted_value = _convert_dict_to_dataclass(
                            nested_config_value, nested_attr_type, expand_path  # type: ignore
                        )
                    else:
                        # 使用内置类型转换
                        converted_value = convert_value(
                            nested_config_value, nested_attr_type  # type: ignore
                        )

                    # 转换失败，跳过
                    if converted_value is None:
                        warnings.warn(
                            f"类型转换失败: {key}.{nested_attr_name} = {nested_config_value}"
                        )
                        continue
                else:
                    # 配置中不存在该值，使用默认值
                    # value_type 已经被确保为 type 类型（在第 1105-1109 行检查）
                    converted_value = _get_default_value(
                        value_type, nested_attr_name, nested_field  # type: ignore
                    )
                    if converted_value is None:
                        continue

                # 设置属性值
                setattr(dataclass_instance, nested_attr_name, converted_value)  # type: ignore

            # 将 dataclass 实例添加到结果字典
            result_dict[key] = dataclass_instance

        # 设置属性值
        setattr(instance, attr_name, result_dict)
    except (TypeError, ValueError, RuntimeError, AttributeError) as e:
        warnings.warn(
            f"创建 dict[str, dataclass] 失败: {cls.__name__}.{attr_name}: {e}"
        )


def _get_default_value[T](
    cls: type, attr_name: str, field_obj: Field[T]
) -> object | None:
    """从字段对象获取默认值

    Args:
        cls: 类对象
        attr_name: 属性名称
        field_obj: 字段对象

    Returns:
        object | None: 默认值，获取失败返回 None
    """
    # 检查默认值是否为 FieldInfo 对象
    if is_field_info(field_obj.default):
        field_info = field_obj.default
        return _execute_default_factory(
            field_info, "default_factory", cls, attr_name
        ) or _get_field_default(field_info, "default", MISSING)

    # 尝试使用 default_factory
    result = _execute_default_factory(field_obj, "default_factory", cls, attr_name)
    if result is not None:
        return result

    # 尝试使用 default
    return _get_field_default(field_obj, "default", MISSING)


def _execute_default_factory(
    obj: object, factory_attr: str, cls: type, attr_name: str
) -> object | None:
    """执行默认值工厂函数

    Args:
        obj: 包含工厂函数的对象
        factory_attr: 工厂函数属性名
        cls: 类对象
        attr_name: 属性名称

    Returns:
        object | None: 工厂函数返回值，失败返回 None
    """
    if not hasattr(obj, factory_attr):
        return None

    factory = getattr(obj, factory_attr, None)
    if factory is None or factory is MISSING:
        return None

    try:
        return factory()
    except Exception as e:
        warnings.warn(f"默认值工厂函数执行失败: {cls.__name__}.{attr_name}: {e}")
        return None


def _get_field_default(
    obj: object, default_attr: str, missing_marker: object
) -> object | None:
    """获取字段默认值

    Args:
        obj: 包含默认值的对象
        default_attr: 默认值属性名
        missing_marker: 缺失标记

    Returns:
        object | None: 默认值，不存在返回 None
    """
    if not hasattr(obj, default_attr):
        return None

    default_value = getattr(obj, default_attr, missing_marker)
    if default_value is not missing_marker:
        return default_value
    return None


def _process_simple_config[T](
    instance: object,
    cls: type,
    attr_name: str,
    attr_type: TargetType,
    config_dict: AnyDict,
    prefix: str,
    custom_converter: Converter,
    field_obj: Field[T],  # 字段对象
    expand_path: bool = True,
) -> None:
    """处理普通配置字段

    Args:
        instance: 对象实例
        cls: 类对象
        attr_name: 属性名称
        attr_type: 属性类型
        config_dict: 配置字典
        prefix: 配置前缀
        custom_converter: 自定义转换器
        field_obj: 自定义的传递字段对象
        expand_path: 是否展开路径变量
    """
    # 检查字段是否有 FieldInfo 和 alias
    field_info: FieldInfo | None = None
    if is_field_info(field_obj.default):
        assert isinstance(field_obj.default, FieldInfo)
        field_info = field_obj.default

    # 如果字段有别名，使用别名作为配置键，否则使用属性名
    config_key_name: str = ""
    if field_info and field_info.alias:
        config_key_name = field_info.alias
    else:
        config_key_name = attr_name

    config_key: str = f"{prefix}.{config_key_name}" if prefix else config_key_name

    # 从配置中获取值
    config_value = resolve_nested_value(config_dict, config_key)

    # 如果配置中存在该值，使用配置值
    if config_value is not None:
        # Path 类型特殊处理
        if isinstance(attr_type, type) and attr_type == Path:
            converted_value = convert_path_value(config_value, expand_path)
        # 使用自定义转换器
        elif custom_converter:
            try:
                converted_value = custom_converter(config_value)
            except Exception as e:
                warnings.warn(f"自定义转换失败: {cls.__name__}.{attr_name}: {e}")
                return
        else:
            # 使用内置类型转换
            converted_value = convert_value(config_value, attr_type)

        # 转换失败，跳过
        if converted_value is None:
            return
    else:
        # 配置中不存在该值，使用默认值
        converted_value = _get_default_value(cls, attr_name, field_obj)
        if converted_value is None:
            return

        # 对于 Path 类型的默认值，如果是字符串且包含变量，尝试展开
        if (
            isinstance(attr_type, type)
            and attr_type == Path
            and isinstance(converted_value, str)
            and expand_path
            and "{" in converted_value
        ):
            converted_value = convert_path_value(converted_value, expand_path)

    # 设置属性值
    setattr(instance, attr_name, converted_value)


from functools import lru_cache


@lru_cache(maxsize=1)
def get_config_dict() -> AnyDict | None:
    """获取配置字典"""
    try:
        config_dict = loadermanager.get_environment_config()
        return config_dict
    except (
        FileNotFoundError,
        PermissionError,
        OSError,
        ValueError,
        TypeError,
        RuntimeError,
    ) as e:
        warnings.warn(f"获取配置失败，使用默认值: {e}")
        return None


def clear_config_cache() -> None:
    """清除配置缓存

    当配置文件变化后,调用此函数清除缓存,下次访问会重新加载配置。

    同时重新初始化所有 @inject 单例实例，自动更新为新环境配置。

    Examples:
        >>> from pynomad.config.autoconfig import clear_config_cache
        >>> # 配置文件更新后
        >>> clear_config_cache()
        >>> config = DatabaseConfig()  # 会使用新配置
    """
    #logger.error("清理前的配置字典:", get_config_dict(), pretty_print=True)
    get_config_dict.cache_clear()
    loadermanager.clear_cache()
    #logger.error("清理后的配置字典:", get_config_dict(), pretty_print=True)


def reload_all_config():
    clear_config_cache()
    for cls, _prefix, _expand_path in _injected_classes:  # noqa: ARG002
        instance = getattr(cls, "_singleton_instance", None)
        if instance is not None:
            _inject_config(instance, cls, _prefix, _expand_path)


def set_active_environment(*env: str) -> None:
    """设置激活环境

    支持设置单个或多个环境，获取配置时会按顺序合并。

    Args:
        *env: 环境名称（可变参数），支持单个或多个环境
              例如 "development" 或 "development", "production"

    Notes:
        - 此方法会清除配置缓存
        - 环境切换后，@inject 装饰的配置类会自动使用新环境配置
        - 只需重新访问配置类即可获取新环境配置（如 DatabaseConfig()）

    Examples:
        >>> from pynomad.config import set_active_environment
        >>>
        >>> # 设置单个环境
        >>> set_active_environment("dev")
        >>>
        >>> # 设置多个环境（会按顺序合并配置）
        >>> set_active_environment("default", "development")
        >>>
        >>> # 环境切换后，@inject 配置类会自动使用新环境配置
        >>> db_config = DatabaseConfig()  # 使用新环境配置
        >>> print(db_config.host)  # dev 环境的数据库主机
    """
    if not env:
        raise ValueError("至少需要提供一个环境名称")
    loadermanager.set_environment(list(env))
    clear_config_cache()


def get_config_value(
    prefix: str, key: str, default: object | None = None
) -> object | None:
    """获取配置值

    便捷函数，用于获取指定前缀下的配置值。

    Args:
        prefix: 配置前缀
        key: 配置键
        default: 默认值

    Returns:
        object | None: 配置值，未找到返回默认值

    Notes:
        - 复用 get_config_dict 的缓存机制，避免重复加载配置
        - 如果需要重新加载配置，请先调用 clear_config_cache()

    Examples:
        >>> from pynomad.config.autoconfig import get_config_value
        >>>
        >>> # 获取 database.host，默认为 "localhost"
        >>> host = get_config_value("database", "host", "localhost")
        >>> print(host)

        >>> # 配置文件更新后清除缓存
        >>> from pynomad.config.autoconfig import clear_config_cache
        >>> clear_config_cache()
        >>> host = get_config_value("database", "host", "localhost")
    """
    config_dict = get_config_dict()
    if config_dict is None:
        return default

    config_key = f"{prefix}.{key}" if prefix else key
    value = resolve_nested_value(config_dict, config_key)
    return value if value is not None else default


def reload_config(instance: object) -> None:
    """重新加载配置

    重新从 LoaderManager 加载配置并更新实例属性。

    Args:
        instance: 需要重新加载配置的实例

    Notes:
        - 会自动清除配置缓存，确保重新加载最新的配置
        - 如果配置文件已更新，调用此函数即可获取新配置

    Examples:
        >>> from pynomad.config.autoconfig import reload_config
        >>>
        >>> config = DatabaseConfig()
        >>> # 修改配置文件后
        >>> reload_config(config)
        >>> # config 的属性会更新为最新的配置值
    """
    if not hasattr(instance, "_config_prefix"):
        warnings.warn("实例不是使用 @inject 装饰的，无法重新加载配置")
        return

    cls = instance.__class__
    prefix = getattr(cls, "_config_prefix", "")

    # 清除缓存,重新加载配置
    clear_config_cache()
    _inject_config(instance, cls, prefix)


def copy_config(instance: object) -> object:
    """创建配置对象的深拷贝副本

    用于需要临时修改配置的场景。副本的修改不会影响原始配置。
    原始配置对象保持单例模式，不受副本修改的影响。

    Args:
        instance: 配置对象实例（必须是使用 @inject 装饰的类）

    Returns:
        object: 配置对象的深拷贝副本

    Raises:
        TypeError: 如果传入的对象不是配置类实例

    Notes:
        - 副本是普通 Python 对象，不再是单例
        - 对副本的修改不会影响原始配置
        - 适用于测试、临时配置修改等场景

    Examples:
        >>> from pynomad.properties import LevelProperties
        >>> from pynomad.config.autoconfig import copy_config
        >>>
        >>> # 创建临时配置用于测试
        >>> temp_config = copy_config(LevelProperties())
        >>> temp_config.pynomad_logging = "error"  # 只影响副本
        >>> print(LevelProperties().pynomad_logging)  # 仍然是 "trace"

        >>> # 在测试中使用临时配置
        >>> def test_with_custom_config():
        >>>     test_config = copy_config(LoggingProperties())
        >>>     test_config.level.pynomad_logging = "debug"
        >>>     # 使用 test_config 进行测试，不影响全局配置
    """
    if not hasattr(instance.__class__, "_config_prefix"):
        raise TypeError(f"{instance.__class__.__name__} 不是使用 @inject 装饰的配置类")

    return copy.deepcopy(instance)


def reset_singleton(cls: type) -> None:
    """重置指定类的单例

    清除单例实例，下次创建时将重新初始化。
    仅在测试等特殊场景使用。

    Args:
        cls: 需要重置单例的配置类（必须是使用 @inject 装饰的类）

    Raises:
        TypeError: 如果传入的类不是配置类（没有 _config_prefix 属性）

    Notes:
        - 会清除已创建的单例实例
        - 下次调用类构造函数时会创建新的单例实例
        - 主要用于测试隔离，确保每个测试使用独立的配置

    Examples:
        >>> from pynomad.properties import LevelProperties
        >>> from pynomad.config.autoconfig import reset_singleton
        >>>
        >>> # 测试前重置单例，确保每个测试都是独立的
        >>> def test_logging_config():
        >>>     reset_singleton(LevelProperties)
        >>>     config = LevelProperties()  # 创建新的单例
        >>>     assert config.pynomad_logging == "trace"
        >>>
        >>> # 测试中修改配置
        >>> config.pynomad_logging = "debug"
        >>>
        >>> def test_another_feature():
        >>>     reset_singleton(LevelProperties)  # 重置单例
        >>>     config = LevelProperties()  # 重新创建，使用原始配置
        >>>     assert config.pynomad_logging == "trace"
    """
    if not hasattr(cls, "_config_prefix"):
        raise TypeError(f"{cls.__name__} 不是使用 @inject 装饰的配置类")

    if hasattr(cls, "_singleton_instance"):
        setattr(cls, "_singleton_instance", None)
