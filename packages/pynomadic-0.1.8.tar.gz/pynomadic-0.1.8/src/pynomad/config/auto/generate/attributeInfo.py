"""
自动生成属性信息模块
"""

from functools import cached_property
from pathlib import Path
import re
from types import GenericAlias
from typing import Literal
from pynomad.common import strings
from pynomad.common.enhandce_dict import EnhancedDict
from pynomad.common.types import AnyDict
from pynomad.config.config_utils import expand_path_variables
from pynomad.naming import naming
from pynomad.naming.naming_types import NameStyle


class AttributeInfo:
    """配置属性信息类

    用于描述配置树中的单个属性节点，包含属性名、值、父级关系等信息。
    支持动态key检测、类型推断、包装类型生成等功能。
    """

    def __init__(
        self,
        key: str,
        value: AnyDict | str,
        parent: "AttributeInfo| None",
        wrap_type: str | type = "",
        wrap_class_prefix: str = "Cfg",
        wrap_class_suffix: str = "Record",
        dict_type: Literal["EnhancedDict", "dict"] = "EnhancedDict",
    ):
        """初始化属性信息

        Args:
            key: 字典的键名
            value: 字典值原始值
            parent: 父级属性节点
            wrap_type: 包装类型，可以是字符串或类型对象
            wrap_class_prefix: 包装类名前缀
            wrap_class_suffix: 包装类名后缀
            dict_type: 字典类型，"EnhancedDict" 或 "dict"
        """
        self._key: str = key
        self._value: AnyDict | str = value
        self._parent: "AttributeInfo| None" = parent
        self._children: set["AttributeInfo"] = set()
        self._wrap_type = wrap_type
        self._dict_type = dict_type
        if self._parent:
            self._parent.add_child(self)
        self._wrap_class_prefix = wrap_class_prefix
        self._wrap_class_suffix = wrap_class_suffix

    def add_child(self, child: "AttributeInfo") -> None:
        """添加子属性

        Args:
            child: 子属性节点
        """
        self._children.add(child)

    @cached_property
    def path_keys(self) -> list[str]:
        """获取从根节点到当前节点的路径键列表

        Returns:
            从根节点到当前节点的所有键组成的列表
        """
        if self.parent is None:
            return [self.key]
        return self.parent.path_keys + [self.key]

    @property
    def required_imports(self) -> list[str]:
        """获取该属性类型所需的导入语句列表

        Returns:
            需要导入的模块路径列表，如 ['from pathlib import Path']
        """
        imports: list[str] = []
        wrap_type_str: str = self.wrap_type
        # 检查是否需要导入 Path
        if "Path" in wrap_type_str:
            imports.append("from pathlib import Path")
            # 如果包含路径变量，需要导入 expand_path_variables
            if (
                isinstance(self._value, str)
                and "{" in self._value
                and "}" in self._value
            ):
                imports.append(
                    f"from {expand_path_variables.__module__}"
                    + f" import {expand_path_variables.__name__}"
                )
        # 检测是否需要导入 Any
        if "Any" in wrap_type_str:
            imports.append("from typing import Any")

        # 检查是否需要导入 EnhancedDict
        if EnhancedDict.__name__ in wrap_type_str:
            module_path: str = EnhancedDict.__module__
            imports.append(f"from {module_path} import {EnhancedDict.__name__}")

        # 如果用户通过 type 对象设置了类型
        if isinstance(self._wrap_type, type):
            type_module: str = self._wrap_type.__module__
            type_name: str = self._wrap_type.__name__
            if type_module != "builtins":
                imports.append(f"from {type_module} import {type_name}")

        return imports

    @property
    def key(self) -> str:
        """获取属性键名

        Returns:
            属性的键名
        """
        return self._key

    @property
    def value(self) -> AnyDict | str:
        """获取属性值

        Returns:
            属性的原始值
        """
        return self._value

    @property
    def parent(self) -> "AttributeInfo| None":
        """获取父级属性

        Returns:
            父级属性节点，根节点时返回 None
        """
        return self._parent

    @property
    def contain_dot(self) -> bool:
        """检查键名是否包含点号

        Returns:
            键名是否包含点号
        """
        return "." in self.key

    @property
    def key_path(self) -> str:
        """获取点分隔的属性路径

        Returns:
            从根节点到当前节点的点分隔路径，如 "logging.handlers.file"
        """
        return ".".join(self.path_keys)

    @property
    def inject_key_path(self) -> str | None:
        """返回可用于注入的路径

        如果父级链中有任何一级是动态key，则返回None
        最顶级返回空字符串 ""，否则返回 str_path_key
        """
        # 检查父级链中是否有动态key
        # current: AttributeInfo | None = self.parent
        current: AttributeInfo | None = self
        while current is not None:
            if current.is_dynamic_key:
                return None
            current = current.parent

        # 最顶级返回空字符串
        if self.parent is None:
            return ""

        return self.key_path

    @property
    def should_generate_independent_class(self) -> bool:
        """判断是否应该生成独立的类

        当父级链中没有动态key时，应该生成独立的类（使用 @inject 或 @dataclass）
        当父级链中有动态key时，不应生成独立的类（作为字典处理）

        Returns:
            是否应该生成独立的类
        """
        if self.is_dynamic_key:
            return False
        if self.is_basic:
            return False
        return True

    @property
    def is_basic(self) -> bool:
        """判断是否为基本类型

        Returns:
            是否为叶子节点（基本类型）
        """
        return self.is_leaf

    @property
    def children(self) -> set["AttributeInfo"]:
        """获取子属性集合

        Returns:
            子属性节点集合
        """
        return self._children

    @property
    def raw_value_type(self) -> str:
        """获取原始值的类型名称

        Returns:
            值的Python类型名称，如 "str", "int", "dict"
        """
        return type(self.value).__name__

    @property
    def is_leaf(self) -> bool:
        """判断是否为叶子节点

        Returns:
            是否没有子节点
        """
        return len(self.children) == 0

    @property
    def raw_value_is_dict(self) -> bool:
        """判断原始值是否为字典类型

        Returns:
            值是否为字典
        """
        return isinstance(self.value, dict)

    @property
    def wrap_attr_name(self) -> str:
        """获取应该能够生成的属性名称"""
        return self.get_wrap_attr_name()

    @property
    def is_file_path(self) -> bool:
        """判断该属性的值是否像路径

        通过尝试调用 expand_path_variables 来判断是否包含有效的路径变量，
        或者通过其他路径特征（如绝对路径、相对路径等）来判断。

        Returns:
            bool: 是否像路径
        """
        if not isinstance(self._value, str):
            return False

        value: str = self._value

        # 尝试展开路径变量，如果成功则说明是有效的路径变量
        if "{" in value and "}" in value:
            try:
                _ = expand_path_variables(value)
                return True
            except (ValueError, OSError, KeyError):
                # 展开失败，说明不是有效的路径变量
                pass

        # 以相对路径符号开头
        if value.startswith(("./", "../")):
            return True

        # Linux/Mac 绝对路径
        if value.startswith("/"):
            return True

        # Windows 绝对路径（任意盘符，如 C:, D:, E:, F:, ...）
        if len(value) >= 2 and value[1] == ":" and value[0].isalpha():
            return True

        # 检查是否包含路径分隔符，但要排除一些特殊情况
        if "\\" in value or "/" in value:
            # 排除 ANSI 转义序列（包含 \x1b, \x1B 等）
            if "\\x" in value.lower():
                return False

            # 排除转义序列（如 \n, \t, \r 等）
            if (
                "\\n" in value
                or "\\t" in value
                or "\\r" in value
                or "\\v" in value
                or "\\f" in value
            ):
                return False

            # 排除 URL（包含 ://）
            if "://" in value:
                return False

            # 包含路径分隔符且不排除上述情况，认为是路径
            return True

        return False

    @property
    def file_path_value(self) -> str:
        """获取路径类型的默认值表示

        如果值是路径类型，返回适合作为默认值的字符串表示。
        对于包含路径变量的值，生成使用 expand_path_variables 的代码。
        对于普通路径，使用 default_factory 避免可变默认值问题。

        Returns:
            str: 路径的默认值表示，处理失败返回空字符串
        """
        if not isinstance(self._value, str):
            return ""

        # 如果不是路径类型，返回空字符串
        if not self.is_file_path:
            return ""

        value: str = self._value

        # 包含路径变量（is_path_like 已经验证过可以展开）
        if "{" in value and "}" in value:
            escaped = value.replace("'", "\\'")
            return f"field(default_factory=lambda: expand_path_variables('{escaped}'))"

        # 普通路径，转换为 POSIX 格式，使用 default_factory
        try:
            path_obj = Path(value)
            posix_path = path_obj.as_posix()
            escaped = posix_path.replace("'", "\\'")
            return f"field(default_factory=lambda: Path('{escaped}'))"
        except (ValueError, OSError):
            # 路径转换失败，返回空字符串
            return ""

    @property
    def raw_value_is_simple_type(self) -> bool:
        """判断是否为简单类型（子节点中不包含字典）

        Returns:
            所有子节点是否都不是字典类型
        """
        return not self.raw_child_value_has_dict

    @property
    def raw_child_value_has_dict(self) -> bool:
        """判断子节点中是否包含字典类型

        Returns:
            是否至少有一个子节点的值是字典
        """
        for child in self.children:
            if child.raw_value_is_dict:
                return True
        return False

    @property
    def raw_child_value_all_dict(self) -> bool:
        """判断所有子节点是否都是字典类型

        Returns:
            所有子节点的值是否都是字典
        """
        for child in self.children:
            if not child.raw_value_is_dict:
                return False
        return True

    @property
    def dept(self):
        """路径深度"""
        if self.parent is None:
            return 0
        return len(self.path_keys)

    def get_wrap_class_name(
        self, class_prefix: str = "Cfg", class_suffix: str = "Record"
    ) -> str:
        """生成包装类名

        通过反向遍历 path_keys,找到最小的唯一路径组合。

        Args:
            class_prefix: 数字开头时的前缀
            class_suffix: 类名后缀

        Returns:
            str: 帕斯卡命名的类名
        """
        name_keys: list[str] = []
        if not self.parent:
            # 根节点直接使用 key
            name_keys = [self.key]
        if self.parent:
            if self._parent_should_be_dict():
                return self.parent.get_wrap_class_name()
            # 从后往前遍历,找到不包含在父节点路径中的最小组合
            parent_path = self.parent.key_path
            for i in range(len(self.path_keys) - 1, -1, -1):
                name_keys.insert(0, self.path_keys[i])
                test_path = ".".join(name_keys)
                if test_path not in parent_path:
                    break

        # 用下划线连接并转小写
        raw_name = "_".join(name_keys).lower()
        raw_name = raw_name.replace(".", "_")
        # 使用正则只保留小写字母、数字和下划线
        clean_name = re.sub(r"[^a-z0-9_]", "", raw_name)

        # 处理空字符串情况
        if not clean_name:
            return ""

        # 处理数字开头
        if clean_name[0].isdigit():
            clean_name = f"{class_prefix}_{clean_name}"

        # 组合最终类名并帕斯卡化
        full_name = f"{clean_name}_{class_suffix}".strip("_")
        return naming.pascalize(full_name, from_style=NameStyle.SNAKE)

    def get_wrap_attr_name(self, keyword_suffix: str = "_") -> str:
        """生成包装后的属性名称

        将键名转换为合法的Python属性名，处理Python关键字和特殊字符。

        Args:
            keyword_suffix: 当键名是Python关键字时添加的后缀

        Returns:
            合法的Python属性名（蛇形命名）
        """
        raw_name = self.key
        raw_name = raw_name.replace(".", "_")
        clean_name = re.sub(r"[^a-zA-Z0-9_]", "", raw_name)
        name = naming.snakeize(clean_name)
        if naming.is_py_keyword(name):
            name = name + keyword_suffix
        return name

    @property
    def is_dynamic_key(self) -> bool:
        """判断是否为动态键（需要作为字典处理）

        动态键是指不符合Python变量命名规则，或者其子节点结构复杂
        需要作为字典类型处理而非作为独立类的键。

        Returns:
            是否为动态键
        """
        if self.parent is None:
            return False
        if naming.is_invalid(self.key):
            return True
        if self.is_basic:
            return self._parent_should_be_dict()
        return self._is_dict_by_children(self)

    def _parent_should_be_dict(self) -> bool:
        """判断父节点是否应该作为字典处理

        Returns:
            父节点是否应该作为字典
        """
        parent = self.parent
        if parent is None:
            return False
        if not parent.raw_value_is_dict:
            return False
        return self._is_dict_by_children(parent)

    def _is_dict_by_children(self, node: "AttributeInfo") -> bool:
        """根据子节点特征判断节点是否应该作为字典

        当子节点数量大于1且键的唯一性较低时，判断为字典类型。

        Args:
            node: 要判断的属性节点

        Returns:
            是否应该作为字典处理
        """
        all_keys: list[str] = []
        for child in node.children:
            # 如果子节点有无效的key则父类直接为字典
            if naming.is_invalid(child.key):
                return True
            all_keys.extend(child.attr_keys)
        if len(node.children) <= 1:
            return False
        if not all_keys:
            return False
        unique_keys: set[str] = set(all_keys)
        uniqueness_ratio: float = len(unique_keys) / len(all_keys)
        return uniqueness_ratio < 0.7

    @property
    def wrap_type(self) -> str:
        """获取包装类型字符串

        按优先级依次检查：用户设置类型、基本类型、序列类型、映射/类类型。

        Returns:
            包装类型的字符串表示
        """
        if wraptype := self._wrap_type_with_setting():
            return wraptype
        if wraptype := self._wrap_type_with_basic():
            return wraptype
        if wraptype := self._wrap_type_with_sequence():
            return wraptype
        if wraptype := self._wrap_type_with_mapping_or_class():
            return wraptype
        return "Any"

    def set_wrap_type(self, value: type | str | GenericAlias) -> None:
        """设置包装类型

        Args:
            value: 包装类型，可以是字符串、类型或GenericAlias
        """
        self._wrap_type = value

    def _wrap_type_with_setting(self) -> str | None:
        """获取用户设置的包装类型

        Returns:
            用户设置的包装类型字符串，未设置时返回None
        """
        if not self._wrap_type:
            return None
        if isinstance(self._wrap_type, GenericAlias):
            return str(self._wrap_type)
        if isinstance(self._wrap_type, type):
            return self._wrap_type.__name__
        return self._wrap_type

    def _wrap_type_with_basic(self) -> str | None:
        """推断基本类型

        Returns:
            基本类型名称（str/int/float/bool/Path），不是基本类型时返回None
        """
        if not isinstance(self.value, str | int | float | bool):
            return None
        if self.is_file_path:
            return "Path"
        t = strings.detect_convert_type(self.value)
        return t.__name__

    def _wrap_type_with_sequence(self) -> str | None:
        """推断序列类型

        Returns:
            列表类型字符串，如 "list[str]" 或 "list[int|str]"，不是列表时返回None
        """
        if not isinstance(self.value, list):
            return None
        types: str = "|".join({type(item).__name__ for item in self.value})
        return f"list[{types}]"

    def _wrap_type_with_mapping_or_class(self) -> str | None:
        """推断映射类型或类类型

        根据是否为动态键决定生成字典类型还是类类型。

        Returns:
            映射类型字符串（如 "dict[str, Any]"）或类名，不是字典时返回None
        """
        if not isinstance(self.value, dict):
            return None
        if self.is_dynamic_key:
            # 如果是动态key,只能包装为字典
            if self._dict_type == EnhancedDict.__name__:
                return EnhancedDict.__name__
            # 普通字典需要获取到子类的类型
            for child in self._children:
                if child.is_dynamic_key:
                    # 只要有一个是动态key,则认为都是动态key
                    return "dict[str,Any]"
            types: set[str] = set()
            for child in self._children:
                types.add(child.get_wrap_class_name())
            type_str: str = "|".join(types)
            type_str = f"dict[str,{type_str}]"
            return type_str
        # 如果不是动态键,则包装为普通的类
        return self.get_wrap_class_name(
            self._wrap_class_prefix, self._wrap_class_suffix
        )

    @property
    def attr_keys(self) -> set[str]:
        """获取子节点的键名集合

        Returns:
            所有子节点的键名集合
        """
        children_attrs: set[str] = set()
        for child in self.children:
            children_attrs.add(child.key)
        return children_attrs

    @property
    def attrs(self) -> dict[str, str]:
        """
        获取配置所需的属性及类型
        """
        children_attrs: dict[str, str] = {}
        for child in self.children:
            key: str = child.key
            types: str = children_attrs.get(key, "")
            if types and child.wrap_type and "Any" not in child.wrap_type:
                types = types + "|" + child.wrap_type
                children_attrs[key] = types
                continue
            if child.wrap_type and "Any" not in child.wrap_type:
                children_attrs[key] = child.wrap_type
        return children_attrs
