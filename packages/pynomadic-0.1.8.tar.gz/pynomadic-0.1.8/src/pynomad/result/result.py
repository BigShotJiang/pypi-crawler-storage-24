"""状态码和结果处理模块

本模块提供了统一的状态码分类和结果返回类型，支持：
- 基于 StatusCategory 的状态分类
- 自动基于异常类生成唯一状态码
- Result 类支持作为返回值和异常两种使用方式

状态码计算规则：
- 基础码 = StatusCategory.code * 10000000
- 异常码 = 基础码 + SHA1(异常类全路径) % 10000000

Examples:
    >>> from pynomad.result import Result, StatusCategory
    >>> result = Result.success({"id": 1})
    >>> print(result.code, result.category)
    10000000 <StatusCategory.SUCCESS: ...>

    >>> result = Result.client_error(ValueError("参数错误"))
    >>> print(result.code, result.msg)
    20000000... 参数错误
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
import json
from collections.abc import Callable
from enum import Enum, auto
import hashlib
from typing import Any, cast, override
from pynomad.common.exceptions import (
    ClientException,
    NetworkException,
    ServerException,
    ThirdPartyException,
)
from pynomad.common.serializer import deserialize
from pynomad.common.dict_utils import serialize
from pynomad.common.types import EmptyStrPolicy, NonePolicy, OnUnconvertible


class StatusCategory(Enum):
    """状态码分类

    用于区分不同类型的状态返回值：
    - SUCCESS: 成功
    - CLIENT_ERROR: 客户端错误
    - NETWORK_ERROR: 网络错误
    - SERVER_ERROR: 服务端错误
    - THIRD_PARTY_ERROR: 第三方服务错误
    - UNKNOWN: 未知错误
    """

    SUCCESS = (auto(), "success")
    CLIENT_ERROR = (auto(), "client error")
    NETWORK_ERROR = (auto(), "network error")
    SERVER_ERROR = (auto(), "server error")
    THIRD_PARTY_ERROR = (auto(), "third party error")
    UNKNOWN = (auto(), "unknown error")

    def __init__(self, code: int, description: str) -> None:
        self._code = code
        self._description = description

    @override
    def __eq__(self, other: object) -> bool:
        """重写相等比较方法

        支持与整数或分类名称进行比较，名称比较不区分大小写。

        Args:
            other: 比较对象，可以是 StatusCategory、int 或 str

        Returns:
            bool: 是否相等

        Examples:
            >>> StatusCategory.SUCCESS == 1
            True
            >>> StatusCategory.SUCCESS == "success"
            True
            >>> StatusCategory.SUCCESS == "SUCCESS"
            True
            >>> StatusCategory.SUCCESS == StatusCategory.SUCCESS
            True
        """
        if isinstance(other, StatusCategory):
            return self._code == other._code
        if isinstance(other, int):
            return self._code == other
        if isinstance(other, str):
            return self.name.lower() == other.lower()
        return False

    @property
    def code(self) -> int:
        """获取分类代码

        Returns:
            int: 分类代码
        """
        return self._code

    @property
    def description(self) -> str:
        """获取分类描述

        Returns:
            str: 分类描述
        """
        return self._description

    def exception_code(
        self, exception: type[Exception] | Exception | None = None
    ) -> int:
        """获取异常对应的完整错误码

        错误码计算规则：基础码 * 10000000 + SHA1(异常类全路径) % 10000000

        Args:
            exception: 异常类或异常实例，如果为 None 则返回分类基础码

        Returns:
            int: 完整的错误码

        Examples:
            >>> StatusCategory.CLIENT_ERROR.exception_code(ValueError)
            20000000...
            >>> StatusCategory.SUCCESS.exception_code()
            10000000
        """
        modulo = 10000000
        if exception is None:
            return self._code * modulo
        if isinstance(exception, Exception):
            exception = exception.__class__
        exception_path = f"{exception.__module__}.{exception.__name__}"
        sha = hashlib.sha1(exception_path.encode()).hexdigest()
        return self._code * modulo + int(sha, 16) % modulo

    def exception_message(
        self,
        exception: type[Exception] | Exception | None = None,
    ) -> str:
        """获取异常对应的消息

        Args:
            exception: 异常实例，会自动提取其消息；如果为 None 则使用分类描述

        Returns:
            str: 异常消息或分类描述

        Examples:
            >>> StatusCategory.CLIENT_ERROR.exception_message(ValueError("错误"))
            '错误'
            >>> StatusCategory.SUCCESS.exception_message()
            'success'
        """
        if exception and isinstance(exception, Exception):
            msg = str(exception)
            return msg if msg else self._description
        return self._description

    @staticmethod
    def from_code(code: int) -> "StatusCategory":
        """根据错误码获取对应的分类

        Args:
            code: 分类代码

        Returns:
            StatusCategory: 匹配的分类，未找到时返回 UNKNOWN

        Examples:
            >>> StatusCategory.from_code(1)
            <StatusCategory.SUCCESS: (1, 'success')>
            >>> StatusCategory.from_code(999)
            <StatusCategory.UNKNOWN: (6, 'unknown error')>
        """
        if code >= 10000:
            code = code // 10000
        for category in StatusCategory:
            if category.code == code:
                return category
        return StatusCategory.UNKNOWN


@dataclass
class HandleResult:
    code: int | str
    data: object
    msg: str


class ResultHandler(ABC):
    @abstractmethod
    def handle(
        self,
        data: Any = None,
        category: StatusCategory = StatusCategory.SUCCESS,
        exception: Exception | None = None,
    ) -> HandleResult: ...


class DefaultHandler(ResultHandler):
    def handle(
        self,
        data: Any = None,
        category: StatusCategory = StatusCategory.SUCCESS,
        exception: Exception | None = None,
    ) -> HandleResult:
        ret = HandleResult(
            code=category.exception_code(exception),
            data=data,
            msg=category.exception_message(exception),
        )
        return ret


class Result[T](Exception):
    """统一结果返回类型

    Result 类继承自 Exception，既可以作为返回值使用，也可以直接 raise 抛出异常。
    支持泛型类型参数 T 来明确返回数据的类型。

    状态码计算规则：
    - 基础码：StatusCategory.code * 10000000
    - 异常码：基础码 + SHA1(异常类全路径) % 10000000
    - 示例：CLIENT_ERROR(2) + ValueError = 20000000 + SHA1("builtins.ValueError") % 10000000

    Attributes:
        _category: 状态分类
        _code: 完整状态码
        _msg: 状态消息
        _data: 返回数据
        _exception: 关联的异常对象

    Examples:
        >>> # 作为返回值使用
        >>> result: Result[str] = Result.success("操作成功")
        >>> print(result.code, result.msg, result.data)
        10000000 success 操作成功

        >>> # 作为异常使用
        >>> try:
        ...     raise Result.client_error(ValueError("参数错误"))
        ... except Result as e:
        ...     print(e.code, e.msg)
        ...     print(e.category, e.exception)
        20000000... 参数错误
        StatusCategory.CLIENT_ERROR ValueError('参数错误')

        >>> # 使用异常实例自动提取消息
        >>> result = Result.network_error(ConnectionError("连接超时"))
        >>> print(result.msg)
        连接超时
    """

    # 类级别的 Handler 实例
    _handler: ResultHandler | None = None

    @classmethod
    def set_handler(cls, handler: ResultHandler) -> None:
        """注册 Result 处理器

        Args:
            handler: ResultHandler 实例，用于处理 Result 初始化参数

        Examples:
            >>> class CustomHandler(ResultHandler):
            ...     def handle(self, data, category, exception):
            ...         return HandleResult(
            ...             code=category.exception_code(exception),
            ...             msg=category.exception_message(exception),
            ...             data=data,
            ...         )
            >>> Result.register_handler(CustomHandler())
        """
        cls._handler = handler

    @classmethod
    def get_handler(cls) -> ResultHandler:
        """获取当前注册的处理器

        Returns:
            ResultHandler: 注册的处理器，未注册时返回 DefaultHandler
        """
        return cls._handler if cls._handler is not None else DefaultHandler()

    @staticmethod
    def get_data[R](
        result: "ResultAny[R] | R",
        target_type: type[R],
        default: R | None = None,
        check_type: bool = False,
    ) -> R | None:
        """安全地从 Result 对象或原始值中获取数据

        该方法主要用于兼容装饰器存在或不存在的情况，能够智能地处理：
        - Result 对象的 data 属性
        - 字典中的 data 字段
        - JSON 字符串
        - 字典到对象的转换

        Args:
            result: Result 对象或原始值
            target_type: 期望的返回类型
            default: 默认值，当无法获取数据时返回
            check_type: 是否严格检查类型，True 时类型不匹配抛出异常

        Returns:
            R | None: 获取的数据或默认值

        Raises:
            TypeError: 当 check_type=True 且类型不匹配时
            ValueError: 当 JSON 解析失败时

        Examples:
            >>> # 从 Result 对象获取数据
            >>> result = Result.success({"name": "Alice"})
            >>> Result.get_data(result, dict)
            {'name': 'Alice'}

            >>> # 从字典获取 data 字段
            >>> data_dict = {"data": {"name": "Bob"}}
            >>> Result.get_data(data_dict, dict)
            {'name': 'Bob'}

            >>> # 从 JSON 字符串获取
            >>> json_str = '{"data": {"name": "Charlie"}}'
            >>> Result.get_data(json_str, dict)
            {'name': 'Charlie'}

            >>> # 使用默认值
            >>> Result.get_data(None, dict, default={})
            {}
        """

        # 辅助函数：抛出类型异常
        def raise_type_error(value: Any, expected_type: type[R]) -> None:
            """抛出类型不匹配异常"""
            raise TypeError(
                f"数据类型不匹配: 期望 {expected_type}, 实际 {type(value).__name__}"
            )

        # 1. 如果 result 是 Result 实例，获取 data
        if isinstance(result, Result):
            data: Any = cast(Any, result.data)  # type: ignore
            if data is None:
                return default
            if check_type and not isinstance(data, target_type):
                raise_type_error(data, target_type)
            return data

        # 2. 如果 result 是字典，检查是否有 data 字段
        if isinstance(result, dict):
            data_dict = cast(dict[str, Any], result)

            # 如果字典没有 data 字段，且目标类型是 dict，直接返回
            if "data" not in data_dict:
                if target_type is dict:
                    return data_dict  # pyright: ignore[reportReturnType]
                return default

            data = data_dict.get("data")

            if data is None:
                return default

            # 如果 data 已经是目标类型，直接返回
            if isinstance(data, target_type):
                return data

            # 如果 data 是 dict，尝试转换为对象
            if isinstance(data, dict):
                try:
                    return deserialize(data, target_type)
                except Exception:
                    if check_type:
                        raise
                    return data  # pyright: ignore[reportUnknownVariableType, reportReturnType]

            # 类型不匹配
            if check_type:
                raise_type_error(data, target_type)
            return data

        # 3. 如果 result 是字符串，目标类型也是字符串，直接返回
        if isinstance(result, str):
            if target_type is str:
                return cast(R, result)

            # 4. 如果 result 是字符串但目标不是字符串，尝试解析 JSON
            try:
                parsed = json.loads(result)
                # 递归调用 get_data 处理解析后的数据
                return Result.get_data(parsed, target_type, default, check_type)
            except json.JSONDecodeError:
                # JSON 解析失败，返回默认值或原始字符串
                if default is not None:
                    return default
                if check_type:
                    raise_type_error(result, target_type)
                return result

        # 5. 如果 result 为 None
        if result is None:
            if default is not None:
                return default
            if check_type:
                raise TypeError("数据为 None，且未提供默认值")
            return None

        # 6. 如果 result 已经是目标类型，直接返回
        if isinstance(result, target_type):
            return result

        # 7. 其他情况
        if default is not None:
            return default
        if check_type:
            raise_type_error(result, target_type)
        return result

    @staticmethod
    def success(data: T | None = None):
        """创建成功结果

        Args:
            data: 返回的数据，默认为 None

        Returns:
            Result[T]: 成功的 Result 对象

        Examples:
            >>> Result.success({"id": 1})
            Result(code=10000000, msg='success', data={'id': 1})
        """
        return Result(data=data, category=StatusCategory.SUCCESS)

    @staticmethod
    def client_error(
        exception: str | Exception | None = None,
        data: T | None = None,
    ) -> "Result[T]":
        """创建客户端错误结果

        Args:
            exception: 客户端异常对象或错误消息字符串，如果是字符串会自动包装成 ClientException

        Returns:
            Result[None]: 客户端错误的 Result 对象

        Examples:
            >>> Result.client_error("无效参数")
            Result(code=20000000..., msg='无效参数', exception=ClientException(...))

            >>> Result.client_error(ValueError("无效参数"))
            Result(code=20000000..., msg='无效参数', exception=ValueError(...))
        """
        # 如果是字符串，包装成 ClientException
        if isinstance(exception, str):
            exception = ClientException(exception)
        return Result(
            data=data, category=StatusCategory.CLIENT_ERROR, exception=exception
        )

    @staticmethod
    def network_error(
        exception: str | Exception | None = None,
        data: T | None = None,
    ) -> "Result[T]":
        """创建网络错误结果

        Args:
            exception: 网络异常对象或错误消息字符串，如果是字符串会自动包装成 NetworkException
            data: 网络错误时携带的数据

        Returns:
            Result[T]: 网络错误的 Result 对象

        Examples:
            >>> Result.network_error("连接超时")
            Result(code=30000000..., msg='连接超时', exception=NetworkException(...))

            >>> Result.network_error(ConnectionError("连接超时"))
            Result(code=30000000..., msg='连接超时', exception=ConnectionError(...))
        """
        # 如果是字符串，包装成 NetworkException
        if isinstance(exception, str):
            exception = NetworkException(exception)

        return Result(
            data=data,
            category=StatusCategory.NETWORK_ERROR,
            exception=exception,
        )

    @staticmethod
    def server_error(
        exception: str | Exception | None = None,
        data: T | None = None,
    ) -> "Result[T]":
        """创建服务端错误结果

        Args:
            exception: 服务端异常对象或错误消息字符串，如果是字符串会自动包装成 ServerException
            data: 服务端错误时携带的数据

        Returns:
            Result[T]: 服务端错误的 Result 对象

        Examples:
            >>> Result.server_error("服务器内部错误")
            Result(code=40000000..., msg='服务器内部错误', exception=ServerException(...))

            >>> Result.server_error(RuntimeError("服务器内部错误"))
            Result(code=40000000..., msg='服务器内部错误', exception=RuntimeError(...))
        """
        # 如果是字符串，包装成 ServerException
        if isinstance(exception, str):
            exception = ServerException(exception)

        return Result(
            data=data, category=StatusCategory.SERVER_ERROR, exception=exception
        )

    @staticmethod
    def third_party_error(
        exception: str | Exception | None = None,
        data: T | None = None,
    ) -> "Result[T]":
        """创建第三方服务错误结果

        Args:
            exception: 第三方服务异常对象或错误消息字符串，如果是字符串会自动包装成 ThirdPartyException
            data: 第三方服务错误时携带的数据

        Returns:
            Result[T]: 第三方服务错误的 Result 对象

        Examples:
            >>> Result.third_party_error("第三方接口异常")
            Result(code=50000000..., msg='第三方接口异常', exception=ThirdPartyException(...))

            >>> Result.third_party_error(Exception("第三方接口异常"))
            Result(code=50000000..., msg='第三方接口异常', exception=Exception(...))
        """
        # 如果是字符串，包装成 ThirdPartyException
        if isinstance(exception, str):
            exception = ThirdPartyException(exception)

        return Result(
            data=data,
            category=StatusCategory.THIRD_PARTY_ERROR,
            exception=exception,
        )

    @staticmethod
    def error(exception: str | Exception | None = None) -> "Result[None]":
        """创建未知错误结果

        Args:
            exception: 异常对象或错误消息字符串，如果是字符串会自动包装成 Exception

        Returns:
            Result[None]: 未知错误的 Result 对象

        Examples:
            >>> Result.unknown("未知错误")
            Result(code=60000000..., msg='未知错误', exception=Exception(...))

            >>> Result.unknown(Exception("未知错误"))
            Result(code=60000000..., msg='未知错误', exception=Exception(...))
        """
        # 如果是字符串，包装成 Exception
        if isinstance(exception, str):
            exception = Exception(exception)

        return Result[None](
            data=None, category=StatusCategory.UNKNOWN, exception=exception
        )

    def __init__(
        self,
        data: T | None = None,
        category: StatusCategory = StatusCategory.SUCCESS,
        exception: Exception | None = None,
    ):
        """初始化 Result 对象

        Args:
            data: 返回数据
            category: 状态分类，默认为 SUCCESS
            exception: 关联的异常对象，用于生成状态码和提取消息
        """
        # 使用 Handler 处理初始化参数
        handler = self.__class__.get_handler()
        handle_result = handler.handle(data, category, exception)

        self._category = category
        self._code = handle_result.code
        self._msg = handle_result.msg
        self._data = handle_result.data
        self._exception = exception

    @property
    def code(self) -> int | str:
        """获取完整状态码

        Returns:
            int | str: 状态码，格式为 category_code * 10000000 + hash(exception_class)
        """
        return self._code

    @property
    def msg(self) -> str:
        """获取状态消息

        Returns:
            str: 状态消息，优先从异常实例提取，否则使用分类描述
        """
        return self._msg

    @property
    def data(self) -> T | None:
        """获取返回数据

        Returns:
            T | None: 返回的数据对象
        """
        return self._data # type: ignore

    @property
    def exception(self) -> Exception | None:
        """获取关联的异常对象

        Returns:
            Exception | None: 关联的异常对象
        """
        return self._exception

    @property
    def category(self) -> StatusCategory:
        """获取状态分类

        Returns:
            StatusCategory: 状态分类枚举
        """
        return self._category

    @property
    def category_code(self) -> int:
        """获取分类基础码

        Returns:
            int: 分类基础码（不包含异常哈希部分）
        """
        return self._category.code

    # 判断方法
    def is_success(self) -> bool:
        """判断是否为成功结果

        Returns:
            bool: 成功返回 True，否则返回 False

        Examples:
            >>> Result.success("data").is_success()
            True
            >>> Result.client_error(ValueError("error")).is_success()
            False
        """
        return self._category == StatusCategory.SUCCESS

    def is_error(self) -> bool:
        """判断是否为错误结果

        Returns:
            bool: 错误返回 True，否则返回 False

        Examples:
            >>> Result.success("data").is_error()
            False
            >>> Result.client_error(ValueError("error")).is_error()
            True
        """
        return self._category != StatusCategory.SUCCESS

    # 提取方法
    def unwrap(self) -> T:
        """获取数据，成功返回数据，失败则抛出异常

        Returns:
            T: 成功时的数据

        Raises:
            Result: 如果结果为错误，抛出原始异常或自身
            ValueError: 如果成功但数据为 None

        Examples:
            >>> Result.success(42).unwrap()
            42
            >>> result = Result.client_error(ValueError("error"))
            >>> try:
            ...     result.unwrap()
            ... except Result as e:
            ...     print(e.msg)
            error
        """
        if self.is_error():
            if self._exception:
                raise self._exception
            raise self
        if self._data is None:
            raise ValueError("Called unwrap() on a None value")
        return self._data # type: ignore

    def unwrap_or(self, default: T | None = None) -> T | None:
        """获取数据，成功返回数据，失败返回默认值

        Args:
            default: 失败时返回的默认值

        Returns:
            T: 成功时的数据或默认值

        Examples:
            >>> Result.success(42).unwrap_or(0)
            42
            >>> Result.success(None).unwrap_or(0)
            0
            >>> Result.client_error(ValueError("error")).unwrap_or(0)
            0
        """
        if self.is_success() and self._data is not None:
            return self._data # type: ignore
        return default

    def unwrap_or_else(self, fn: Callable[[], T]) -> T:
        """获取数据，成功返回数据，失败执行函数返回默认值

        Args:
            fn: 失败时执行的函数

        Returns:
            T: 成功时的数据或函数返回值

        Examples:
            >>> Result.success(42).unwrap_or_else(lambda: 0)
            42
            >>> Result.success(None).unwrap_or_else(lambda: 0)
            0
            >>> Result.client_error(ValueError("error")).unwrap_or_else(lambda: 100)
            100
        """
        if self.is_success() and self._data is not None:
            return self._data # type: ignore
        return fn()

    # 转换方法
    def map[R](self, fn: Callable[[T], R]) -> "Result[R]":
        """转换成功结果中的数据

        Args:
            fn: 转换函数，接收当前数据返回新数据

        Returns:
            Result[R]: 转换后的结果

        Examples:
            >>> Result.success(5).map(lambda x: x * 2)
            Result(code=10000000, msg='success', data=10)
            >>> Result.success(None).map(lambda x: x * 2)
            Result(code=10000000, msg='success', data=None)
            >>> Result.client_error(ValueError("error")).map(lambda x: x * 2)
            Result(code=20000000..., msg='error', data=None)
        """
        if self.is_success() and self._data is not None:
            return Result[R](data=fn(self._data), category=self._category) # type: ignore
        return Result[R](data=None, category=self._category, exception=self._exception)

    def map_err(self, fn: Callable[[Exception | None], Exception]) -> "Result[T]":
        """转换错误结果中的异常

        Args:
            fn: 转换函数，接收当前异常返回新异常

        Returns:
            Result[T]: 转换后的结果

        Examples:
            >>> Result.success(5).map_err(lambda e: RuntimeError("custom"))
            Result(code=10000000, msg='success', data=5)
            >>> result = Result.client_error(ValueError("error"))
            >>> result.map_err(lambda e: RuntimeError("custom"))
            Result(code=20000000..., msg='custom', exception=RuntimeError(...))
        """
        if self.is_success():
            return self
        new_exception = fn(self._exception)
        return Result[T](
            data=self._data, # type: ignore
            category=self._category,
            exception=new_exception,
        )

    def flat_map[R](self, fn: Callable[[T], "Result[R]"]) -> "Result[R]":
        """链式处理成功结果

        如果当前结果成功，执行函数并返回新结果；否则直接返回当前错误。

        Args:
            fn: 转换函数，接收当前数据返回新 Result

        Returns:
            Result[R]: 新的结果

        Examples:
            >>> def parse_and_double(s: str) -> Result[int]:
            ...     try:
            ...         return Result.success(int(s) * 2)
            ...     except ValueError as e:
            ...         return Result[None].client_error(e)
            >>> Result.success("10").flat_map(parse_and_double)
            Result(code=10000000, msg='success', data=20)
        """
        if self.is_success() and self._data is not None:
            return fn(self._data) # type: ignore
        return Result[R](data=None, category=self._category, exception=self._exception)

    # 组合方法
    def or_else(self, fn: Callable[[], "Result[T]"]) -> "Result[T]":
        """失败时执行函数返回备选结果

        Args:
            fn: 失败时执行的函数

        Returns:
            Result[T]: 当前结果或备选结果

        Examples:
            >>> ok = Result.success(42)
            >>> backup = Result.success(100)
            >>> ok.or_else(lambda: backup)
            Result(code=10000000, msg='success', data=42)

            >>> err = Result.client_error(ValueError("error"))
            >>> err.or_else(lambda: backup)
            Result(code=10000000, msg='success', data=100)
        """
        if self.is_success():
            return self
        return fn()

    def and_then[R](self, fn: Callable[[T], "Result[R]"]) -> "Result[R]":
        """flat_map 的别名，提供更符合 Rust 风格的接口

        Args:
            fn: 成功时执行的函数

        Returns:
            Result[R]: 新的结果

        Examples:
            >>> Result.success(10).and_then(lambda x: Result.success(x * 2))
            Result(code=10000000, msg='success', data=20)
        """
        return self.flat_map(fn)

    # 序列化方法
    def to_dict(
        self,
        keep_data_original: bool = False,
        on_unconvertible: OnUnconvertible = "raise",
        none_policy: NonePolicy = "keep",
        empty_str_policy: EmptyStrPolicy = "keep",
    ) -> dict[str, Any]:
        """转换为字典格式，便于 JSON 序列化

        Args:
            keep_data_original: 是否保持 data 的原始值，默认为 False
                - True: 保持 data 原样返回
                - False: 使用 serialize 方法处理 data
            on_unconvertible: 遇到不可转换值时的处理方式
                - "raise": 抛出异常（默认）
                - "skip": 跳过该值
                - "str": 使用 str() 转换
            none_policy: None 值的处理方式
                - "keep": 保留 None 值（默认）
                - "skip": 抛弃 None 值
            empty_str_policy: 空字符串的处理方式
                - "keep": 保留空字符串（默认）
                - "skip": 抛弃空字符串

        Returns:
            dict[str, Any]: 包含 code、msg、data、category 的字典，异常时包含 exception 字段

        Examples:
            >>> Result.success({"id": 1}).to_dict()
            {'code': 10000000,
             'msg': 'success',
             'data': {'id': 1},
             'category': 'SUCCESS'}
        """
        # 处理 data 的序列化
        data: Any = self._data
        if not keep_data_original:
            # 如果 data 本身有 to_dict 方法，则调用它（支持 pandas DataFrame 等）
            if hasattr(data, "to_dict") and callable(getattr(data, "to_dict")):
                data = data.to_dict()
            else:
                # 否则使用 serialize 方法处理
                data = serialize(
                    data, None, on_unconvertible, none_policy, empty_str_policy
                )

        result_dict: dict[str, Any] = {
            "code": self._code,
            "msg": self._msg,
            "data": data,
            "category": self._category.name,
        }

        return result_dict

    def to_json(
        self,
        keep_data_original: bool = False,
        on_unconvertible: OnUnconvertible = "raise",
        none_policy: NonePolicy = "keep",
        empty_str_policy: EmptyStrPolicy = "keep",
        ensure_ascii: bool = False,
        indent: int | None = 4,
    ) -> str:
        """转换为 JSON 字符串

        Args:
            keep_data_original: 是否保持 data 的原始值，默认为 False
            on_unconvertible: 遇到不可转换值时的处理方式
            none_policy: None 值的处理方式
            empty_str_policy: 空字符串的处理方式
            ensure_ascii: 是否对非 ASCII 字符进行转义，默认为 False
            indent: 缩进空格数，默认为 4，None 表示不缩进（紧凑格式）

        Returns:
            str: JSON 格式的字符串

        Examples:
            >>> Result.success({"id": 1}).to_json()
            '{"code": 10000000, "msg": "success", "data": {"id": 1}, "category": "SUCCESS"}'
        """
        return json.dumps(
            self.to_dict(
                keep_data_original=keep_data_original,
                on_unconvertible=on_unconvertible,
                none_policy=none_policy,
                empty_str_policy=empty_str_policy,
            ),
            ensure_ascii=ensure_ascii,
            indent=indent,
        )

    # 字符串方法
    @override
    def __str__(self) -> str:
        """返回结果的字符串表示

        Returns:
            str: 格式化的结果字符串
        """
        return f"Result(code={self._code}, msg='{self._msg}', data={self._data})"

    @override
    def __repr__(self) -> str:
        """返回结果的开发友好表示

        Returns:
            str: 格式化的结果字符串
        """
        return self.__str__()


type ResultAny[T] = Result[T] | Result[None]
