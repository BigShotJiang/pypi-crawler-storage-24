"""命名系统异常模块

定义命名系统中使用的所有异常类。
"""


class NamingException(Exception):
    """命名相关异常基类

    所有命名系统异常的父类。
    """


class NamingConversionException(NamingException):
    """命名转换异常

    当命名风格转换失败时抛出此异常。
    """


class NamingValidationException(NamingException):
    """命名验证异常

    当命名验证失败时抛出此异常。
    """
