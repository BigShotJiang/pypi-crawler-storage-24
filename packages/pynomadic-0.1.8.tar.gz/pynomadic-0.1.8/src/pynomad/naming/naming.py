"""命名系统便捷函数模块

提供全局便捷函数，封装 NamingSystem 的功能。
所有函数都使用全局命名系统实例（单例）。
"""

from typing import Any, cast
from pynomad.common.types import AnyDict, AnyList
from pynomad.naming.system import NamingSystem
from pynomad.naming.naming_types import NameStyle
from pynomad.common import strings


# 使用单例获取全局命名系统实例
naming_system: NamingSystem = NamingSystem()


# 明确控制公共API导出
__all__ = [
    # 标识符检查
    "is_py_identifier",
    "is_identifier",
    # 关键字检查
    "is_py_keyword",
    "is_pysoftkeyword",
    "is_java_keyword",
    "is_ts_keyword",
    "is_js_keyword",
    "is_c_keyword",
    "is_cpp_keyword",
    "is_csharp_keyword",
    "is_php_keyword",
    "is_keyword",
    # 命名风格检查
    "is_pascal",
    "is_camel",
    "is_kebab",
    "is_standard_kebab",
    "is_upper_kebab",
    "is_pascal_kebab",
    "is_snake",
    "is_standard_snake",
    "is_upper_snake",
    "is_pascal_snake",
    "is_magic_snake",
    "is_protected_snake",
    "is_private_snake",
    "is_end_snake",
    "is_hungarian",
    "is_invalid",
    # 风格检测
    "detect_style",
    "detect_possible_styles",
    # 命名转换
    "pascalize",
    "camelize",
    "kebabize",
    "snakeize",
    # 字典转换（便捷函数）
    "snakeize_dict",
]


# 导出便捷函数
def is_py_identifier(name: str) -> bool:
    """检查是否是有效的Python标识符"""
    return naming_system.is_py_identifier(name)


def is_identifier(name: str) -> bool:
    """检查是否是有效的通用标识符"""
    return naming_system.is_identifier(name)


def is_py_keyword(name: str) -> bool:
    """检查是否是Python关键字"""
    return naming_system.keywords.is_py_keyword(name)


def is_pysoftkeyword(name: str) -> bool:
    """检查是否是Python软关键字"""
    return naming_system.keywords.is_py_softkeyword(name)


def is_java_keyword(name: str) -> bool:
    """检查是否是Java关键字"""
    return naming_system.keywords.is_java_keyword(name)


def is_ts_keyword(name: str) -> bool:
    """检查是否是TypeScript关键字"""
    return naming_system.keywords.is_ts_keyword(name)


def is_js_keyword(name: str) -> bool:
    """检查是否是JavaScript关键字"""
    return naming_system.keywords.is_js_keyword(name)


def is_c_keyword(name: str) -> bool:
    """检查是否是C关键字"""
    return naming_system.keywords.is_c_keyword(name)


def is_cpp_keyword(name: str) -> bool:
    """检查是否是C++关键字"""
    return naming_system.keywords.is_cpp_keyword(name)


def is_csharp_keyword(name: str) -> bool:
    """检查是否是C#关键字"""
    return naming_system.keywords.is_csharp_keyword(name)


def is_php_keyword(name: str) -> bool:
    """检查是否是PHP关键字"""
    return naming_system.keywords.is_php_keyword(name)


def is_keyword(name: str) -> bool:
    """检查是否是任何编程语言的关键字"""
    return naming_system.keywords.is_keyword(name)


def is_pascal(name: str) -> bool:
    """检查是否是帕斯卡命名（PascalCase）"""
    return naming_system.is_pascal(name)


def is_camel(name: str) -> bool:
    """检查是否是驼峰命名（camelCase）"""
    return naming_system.is_camel(name)


def is_kebab(name: str) -> bool:
    """检查是否是短横线命名（kebab-case）"""
    return naming_system.is_kebab(name)


def is_standard_kebab(name: str) -> bool:
    """检查是否是标准短横线命名（standard-kebab-case）"""
    return naming_system.is_standard_kebab(name)


def is_upper_kebab(name: str) -> bool:
    """检查是否是大写短横线命名（UPPER-KEBAB-CASE）"""
    return naming_system.is_upper_kebab(name)


def is_pascal_kebab(name: str) -> bool:
    """检查是否是帕斯卡短横线命名（Pascal-Kebab-Case）"""
    return naming_system.is_pascal_kebab(name)


def is_snake(name: str) -> bool:
    """检查是否是蛇形命名（snake_case）"""
    return naming_system.is_snake(name)


def is_standard_snake(name: str) -> bool:
    """检查是否是标准蛇形命名（standard_snake_case）"""
    return naming_system.is_standard_snake(name)


def is_upper_snake(name: str) -> bool:
    """检查是否是大写蛇形命名（UPPER_SNAKE_CASE）"""
    return naming_system.is_upper_snake(name)


def is_pascal_snake(name: str) -> bool:
    """检查是否是帕斯卡蛇形命名（Pascal_Snake_Case）"""
    return naming_system.is_pascal_snake(name)


def is_magic_snake(name: str) -> bool:
    """检查是否是魔术蛇形命名（__magic_snake_case__）"""
    return naming_system.is_magic_snake(name)


def is_protected_snake(name: str) -> bool:
    """检查是否是保护蛇形命名（_protected_snake_case）"""
    return naming_system.is_protected_snake(name)


def is_private_snake(name: str) -> bool:
    """检查是否是私有蛇形命名（__private_snake_case）"""
    return naming_system.is_private_snake(name)


def is_end_snake(name: str) -> bool:
    """检查是否是尾蛇形命名（end_snake_case_，用于Pydantic关键字）"""
    return naming_system.is_end_snake(name)


def is_hungarian(name: str) -> bool:
    """检查是否是匈牙利命名（HungarianNotation）"""
    return naming_system.is_hungarian(name)


def detect_possible_styles(name: str) -> NameStyle:
    """检测所有可能的命名风格（返回匹配风格的并集）

    返回结果是多个NameStyle的位或运算，可以包含多个可能的风格。
    例如：'save' 可能是 CAMEL、SNAKE 或 KEBAB，则返回 CAMEL | SNAKE | KEBAB

    Args:
        name: 要检测的名称

    Returns:
        匹配的所有命名风格的并集（位或运算结果）
    """
    return naming_system.detect_possible_styles(name)


def detect_style(name: str) -> NameStyle:
    """检测名称的命名风格,只会返回一个NameStyle,
    如果有多个可能的风格,则返回NameStyle.UNKNOWN,
    如果没有任何风格匹配,则返回NameStyle.INVALID
    Args:
        name: 要检测的名称

    Returns:
        检测到的命名风格
    """
    return naming_system.detect_style(name)


def pascalize(
    name: str,
    exception: bool = False,
    from_style: NameStyle = NameStyle.UNKNOWN,
    return_empty: bool = False,
) -> str:
    """将名称转换为帕斯卡命名（PascalCase）

    Args:
        name: 要转换的名称
        exception: 是否在转换失败时抛出异常
        from_style: 源命名风格
        return_empty: 转换失败时是否返回空字符串

    Returns:
        转换后的帕斯卡命名
    """
    return naming_system.pascalize(name, from_style, exception, return_empty)


def camelize(
    name: str,
    exception: bool = False,
    from_style: NameStyle = NameStyle.UNKNOWN,
    return_empty: bool = False,
) -> str:
    """将名称转换为驼峰命名（camelCase）

    Args:
        name: 要转换的名称
        exception: 是否在转换失败时抛出异常
        from_style: 源命名风格
        return_empty: 转换失败时是否返回空字符串

    Returns:
        转换后的驼峰命名
    """
    return naming_system.camelize(name, from_style, exception, return_empty)


def is_invalid(name: str):
    """检查是否是无效的命名"""
    return naming_system.is_invalid(name)


def kebabize(
    name: str,
    from_style: NameStyle = NameStyle.UNKNOWN,
    to_style: NameStyle = NameStyle.STANDARD_KEBAB,
    exception: bool = False,
    return_empty: bool = False,
) -> str:
    """将名称转换为短横线命名（kebab-case）

    Args:
        name: 要转换的名称
        from_style: 源风格
        to_style: 目标风格，默认为 STANDARD_KEBAB，可选：
            - STANDARD_KEBAB (默认): kebab-case
            - UPPER_KEBAB: UPPER-KEBAB-CASE
            - PASCAL_KEBAB: Pascal-Kebab-Case
        exception: 遇到错误时是否抛出异常
        return_empty: 遇到错误时是否返回空字符串

    Returns:
        转换后的短横线命名
    """
    return naming_system.kebabize(
        name, from_style, to_style, exception, return_empty
    )


def snakeize(
    name: str,
    from_style: NameStyle = NameStyle.UNKNOWN,
    to_style: NameStyle = NameStyle.STANDARD_SNAKE,
    exception: bool = False,
    return_empty: bool = False,
) -> str:
    """将名称转换为蛇形命名（snake_case）

    Args:
        name: 要转换的名称
        from_style: 源风格
        to_style: 目标风格，默认为 STANDARD_SNAKE，可选：
            - STANDARD_SNAKE (默认): snake_case
            - UPPER_SNAKE: UPPER_SNAKE_CASE
            - PASCAL_SNAKE: Pascal_Snake_Case
            - MAGIC_SNAKE: __magic_method__
            - PROTECTED_SNAKE: _protected_var
            - PRIVATE_SNAKE: __private_var
        exception: 遇到错误时是否抛出异常
        return_empty: 遇到错误时是否返回空字符串

    Returns:
        转换后的蛇形命名
    """
    return naming_system.snakeize(
        name, from_style, to_style, exception, return_empty
    )


def transform_dict(
    config: AnyDict,
    key_converter: Any,
    value_converter: Any | None = None,
    depth: int = 0,
) -> AnyDict:
    """递归转换配置字典的键和值

    将配置的键名进行转换，并处理嵌套的字典和列表。

    Args:
        config: 原始配置字典
        key_converter: 键名转换函数，接收一个字符串参数，返回转换后的字符串
        value_converter: 值转换函数，接收一个字符串参数，返回转换后的值。如果为 None，则使用 strings.convert
        depth: 当前递归深度，用于防止堆栈溢出

    Returns:
        转换后的配置字典
    """
    # 防止递归过深导致堆栈溢出
    max_depth: int = 50
    if depth >= max_depth:
        return config

    transformed: AnyDict = {}
    if value_converter is None:
        value_converter = strings.convert

    for key, value in config.items():
        # 转换键名
        new_key = key_converter(key)
        # 转换值（可能是嵌套的字典或列表）
        if isinstance(value, dict):
            new_value = transform_dict(
                cast(AnyDict, value),
                key_converter,
                value_converter,
                depth + 1,
            )
        elif isinstance(value, list):
            new_value = transform_list(
                cast(list[object], value),
                key_converter,
                value_converter,
                depth + 1,
            )
        else:
            new_value = (
                value_converter(value) if isinstance(value, str) else value
            )
        transformed[new_key] = new_value
    return transformed


def transform_list(
    items: AnyList,
    key_converter: Any,
    value_converter: Any,
    depth: int = 0,
) -> AnyList:
    """递归转换列表中的元素

    处理列表中嵌套的字典或列表。

    Args:
        items: 原始列表
        key_converter: 键名转换函数
        value_converter: 值转换函数
        depth: 当前递归深度，用于防止堆栈溢出

    Returns:
        转换后的列表
    """
    # 防止递归过深导致堆栈溢出
    max_depth: int = 50
    if depth >= max_depth:
        return items

    transformed: list[object] = []
    for item in items:
        if isinstance(item, dict):
            transformed.append(
                transform_dict(
                    cast(AnyDict, item),
                    key_converter,
                    value_converter,
                    depth + 1,
                )
            )
        elif isinstance(item, list):
            transformed.append(
                transform_list(
                    cast(list[object], item),
                    key_converter,
                    value_converter,
                    depth + 1,
                )
            )
        else:
            transformed.append(item)
    return transformed


def snakeize_dict(config: AnyDict) -> AnyDict:
    """将配置字典的所有键名转换为 snake_case

    这是 transform_dict 的便捷包装，默认使用 snakeize 转换键名。

    Args:
        config: 原始配置字典

    Returns:
        键名转换为 snake_case 后的配置字典

    Examples:
        >>> config = {"UserName": "Alice", "Profile": {"Email": "alice@example.com"}}
        >>> result = snakeize_dict(config)
        >>> print(result)
        {'user_name': 'Alice', 'profile': {'email': 'alice@example.com'}}
    """
    return transform_dict(config, snakeize)
