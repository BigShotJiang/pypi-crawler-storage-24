"""命名系统核心类模块

提供完整的命名风格检测、转换和验证功能，支持16种不同的命名风格，
包括驼峰命名、帕斯卡命名、蛇形命名、短横线命名等。

主要功能：
- 命名风格检测和识别
- 不同命名风格之间的转换
- 多语言关键字检测（Python、Java、JavaScript/TypeScript、C/C++、C#、PHP）
- 正则表达式模式匹配和验证
- 智能单词分割（支持连续大写字母如XMLHttpRequest）

支持的命名风格：
- 驼峰命名 (camelCase)
- 帕斯卡命名 (PascalCase)
- 蛇形命名 (snake_case)
- 短横线命名 (kebab-case)
- 以及其他12种变体
"""

from pynomad.common.decorator import singleton
from pynomad.naming.keywords import KeywordManager
from pynomad.naming.patterns import PatternManager
from pynomad.naming.naming_types import NameStyle
from pynomad.naming.exceptions import (
    NamingConversionException,
    NamingValidationException,
)


@singleton
class NamingSystem:
    """命名系统核心类 - 单例模式"""

    def __init__(self):
        super().__init__()
        self.keywords = KeywordManager()
        self.patterns = PatternManager()

    def split_into_words(
        self, name: str, style: NameStyle = NameStyle.UNKNOWN
    ) -> list[str]:
        """将标识符分解为单词列表"""
        if not name:
            return []

        # 根据风格或自动检测来分割
        if style == NameStyle.UNKNOWN:
            style = self.detect_style(name)

        # 处理不同的分隔符
        if "_" in name:
            words = name.split("_")
        elif "-" in name:
            words = name.split("-")
        else:
            # 驼峰/帕斯卡命名 - 需要处理连续大写字母
            words = self._split_camel_case(name)

        # 过滤空字符串并处理Python特有前缀
        result: list[str] = []
        for word in words:
            if word:
                # 处理魔术方法的__前缀和后缀
                if (
                    style in [NameStyle.MAGIC_SNAKE]
                    and word.startswith("__")
                    and word.endswith("__")
                ):
                    word = word[2:-2] if len(word) > 4 else word
                # 处理私有变量的__前缀
                elif style in [NameStyle.PRIVATE_SNAKE] and word.startswith(
                    "__"
                ):
                    word = word[2:]
                # 处理保护变量的_前缀
                elif style in [NameStyle.PROTECTED_SNAKE] and word.startswith(
                    "_"
                ):
                    word = word[1:]

                if word:
                    # 保持单词的原始大小写，让转换函数决定如何处理
                    result.append(word)

        return result

    def _split_camel_case(self, name: str) -> list[str]:
        """分割驼峰命名，处理连续大写字母的情况"""
        if not name:
            return []

        words: list[str] = []
        i = 0
        n = len(name)

        while i < n:
            char = name[i]
            if char.isupper():
                i = self._handle_uppercase_sequence(name, i, words)
            elif char.islower():
                i = self._handle_lowercase_sequence(name, i, words)
            else:  # 数字
                i = self._handle_digit_sequence(name, i, words)

        return words

    def _is_potential_acronym(self, word: str) -> bool:
        """判断单词是否可能是缩写词

        规则：
        1. 长度 > 1 且全部大写（或包含数字）
        2. 长度 = 1 且是大写字母
        """
        if not word:
            return False

        # 单字符大写可能是缩写（如A, B, C）
        if len(word) == 1:
            return word.isupper()

        # 多字符且全部大写（或包含数字）可能是缩写
        has_upper = any(c.isupper() for c in word)
        has_lower = any(c.islower() for c in word)

        return has_upper and not has_lower

    def _convert_word_for_style(
        self, word: str, target_style: NameStyle, position: int = 0
    ) -> str:
        """根据目标风格和位置转换单词

        Args:
            word: 要转换的单词
            target_style: 目标风格 NameStyle 枚举
            position: 单词在序列中的位置（0表示第一个）
        """
        if not word:
            return word

        # 如果是可能的缩写词，在某些风格下保持原样
        is_acronym = self._is_potential_acronym(word)

        # Pascal/Camel 风格
        if target_style in [NameStyle.PASCAL, NameStyle.CAMEL]:
            if target_style == NameStyle.PASCAL:
                # Pascal风格：首字母大写
                if is_acronym:
                    return word  # 缩写词保持原样
                return word.capitalize()  # 普通单词首字母大写
            # Camel
            if position == 0:
                # 第一个单词全小写
                return word.lower()
            # 后续单词：缩写词保持原样，普通单词首字母大写
            if is_acronym:
                return word
            return word.capitalize()

        # 检查是否是 snake 类型
        target_style_name = target_style.name if target_style.name else ""
        is_snake_style = "SNAKE" in target_style_name

        # 检查是否是 kebab 类型
        is_kebab_style = "KEBAB" in target_style_name

        # Snake和Kebab风格：根据具体子类型处理
        if is_snake_style or is_kebab_style:
            # 大写变体
            if target_style in [
                NameStyle.UPPER_SNAKE,
                NameStyle.UPPER_KEBAB,
            ]:
                return word.upper()
            # 帕斯卡变体
            if target_style in [
                NameStyle.PASCAL_SNAKE,
                NameStyle.PASCAL_KEBAB,
            ]:
                return word.capitalize()
            # 标准变体：全小写
            return word.lower()

        # 默认情况：返回原词
        return word

    def _should_split_uppercase_sequence(
        self, uppers: str, next_char: str
    ) -> bool:
        """判断是否应该分割大写字母序列

        规则：
        1. 如果后面跟小写字母，需要分割（如 XMLHttp -> XML + Http）
        2. 如果后面没有小写字母，不分割（如 XML -> XML）
        """
        if not next_char:
            return False

        # 如果下一个字符是小写字母，需要分割
        if next_char.islower():
            return True

        # 如果是数字，一般不分割（如 HTML5 -> HTML5）
        if next_char.isdigit():
            return False

        # 如果下一个字符还是大写字母，需要进一步判断
        if next_char.isupper():
            # 如果当前序列长度 > 1，且后面还有大写字母，通常需要分割
            # （如 XMLHttpRequestHandler -> XML + Http + Request + Handler）
            return len(uppers) > 1

        return False

    def _handle_uppercase_sequence(
        self, name: str, start: int, words: list[str]
    ) -> int:
        """处理大写字母序列，智能判断分割边界"""
        i = start
        n = len(name)

        # 收集连续的大写字母（不包含数字）
        while i < n and name[i].isupper():
            i += 1

        consecutive_uppers = name[start:i]

        # 获取下一个字符来判断是否需要分割
        next_char = name[i] if i < n else ""

        # 根据规则判断是否需要分割
        if self._should_split_uppercase_sequence(consecutive_uppers, next_char):
            return self._split_uppercase_with_lowercase(
                consecutive_uppers, name, i, words
            )

        # 如果下一个是数字，将数字也包含进来（如 HTML5）
        if next_char.isdigit():
            i += 1  # 跳过数字
            words.append(consecutive_uppers + next_char)
            return i

        # 不需要分割，整个序列作为一个单词
        words.append(consecutive_uppers)
        return i

    def _split_uppercase_with_lowercase(
        self,
        uppers: str,
        name: str,
        pos: int,
        words: list[str],
    ) -> int:
        """将大写字母序列与后续小写字母分割"""
        if len(uppers) > 1:
            # 多个大写字母：XMLHttpRequest -> XML + HTTP + Request
            # 除最后一个大写字母外的部分作为一个单词
            words.append(uppers[:-1])
            # 最后一个大写字母与后续内容组成新单词
            return self._collect_mixed_case_word(
                uppers[-1] + name[pos], name, pos + 1, words
            )
        # 单个大写字母：MyVariable -> My + Variable
        return self._collect_mixed_case_word(
            uppers + name[pos], name, pos + 1, words
        )

    def _collect_mixed_case_word(
        self,
        initial: str,
        name: str,
        start: int,
        words: list[str],
    ) -> int:
        """收集混合大小写的单词（首字母大写，后跟小写字母）"""
        i = start
        n = len(name)

        # 只收集小写字母，遇到数字停止
        while i < n and name[i].islower():
            i += 1

        words.append(initial + name[start:i])
        return i

    def _handle_lowercase_sequence(
        self, name: str, start: int, words: list[str]
    ) -> int:
        """处理小写字母序列"""
        i = start + 1  # 跳过起始的小写字母
        n = len(name)

        # 只收集小写字母，遇到数字停止
        while i < n and name[i].islower():
            i += 1

        words.append(name[start:i])
        return i

    def _handle_digit_sequence(
        self, name: str, start: int, words: list[str]
    ) -> int:
        """处理数字序列"""
        i = start + 1  # 跳过起始的数字
        n = len(name)

        while i < n and name[i].isdigit():
            i += 1

        words.append(name[start:i])
        return i

    def detect_possible_styles(self, name: str) -> NameStyle:
        """检测所有可能的命名风格（返回匹配风格的并集）

        返回结果是多个NameStyle的位或运算，可以包含多个可能的风格。
        例如：'save' 可能是 CAMEL、SNAKE 或 KEBAB，则返回 CAMEL | SNAKE | KEBAB

        Args:
            name: 要检测的名称

        Returns:
            匹配的所有命名风格的并集（位或运算结果）
        """
        if not name:
            return NameStyle.INVALID

        # 检查无效命名
        if self._is_invalid_name(name):
            return NameStyle.INVALID

        # 检查是否是 Python 关键字（包括软关键字），关键字不应被视为有效命名
        if self.keywords.is_py_keyword(name) or self.keywords.is_py_softkeyword(
            name
        ):
            return NameStyle.INVALID

        result = NameStyle(0)  # 初始化为0，用于位或累积（不包含UNKNOWN）

        # 特殊命名风格检查（特殊snake风格同时也包含SNAKE）
        if self.is_magic_snake(name):
            result |= NameStyle.MAGIC_SNAKE | NameStyle.SNAKE
        if self.is_private_snake(name):
            result |= NameStyle.PRIVATE_SNAKE | NameStyle.SNAKE
        if self.is_protected_snake(name):
            result |= NameStyle.PROTECTED_SNAKE | NameStyle.SNAKE
        if self.is_end_snake(name):
            result |= NameStyle.END_SNAKE | NameStyle.SNAKE

        # 检查所有snake风格（PASCAL_SNAKE和UPPER_SNAKE也应包含SNAKE）
        if self.is_pascal_snake(name):
            result |= NameStyle.PASCAL_SNAKE | NameStyle.SNAKE
        if self.is_upper_snake(name):
            result |= NameStyle.UPPER_SNAKE | NameStyle.SNAKE
        if self.is_standard_snake(name):
            result |= NameStyle.STANDARD_SNAKE | NameStyle.SNAKE
        if self.is_snake(name):
            result |= NameStyle.SNAKE

        # 检查所有kebab风格（PASCAL_KEBAB和UPPER_KEBAB也应包含KEBAB）
        if self.is_pascal_kebab(name):
            result |= NameStyle.PASCAL_KEBAB | NameStyle.KEBAB
        if self.is_upper_kebab(name):
            result |= NameStyle.UPPER_KEBAB | NameStyle.KEBAB
        if self.is_standard_kebab(name):
            result |= NameStyle.STANDARD_KEBAB | NameStyle.KEBAB
        if self.is_kebab(name):
            result |= NameStyle.KEBAB

        # 检查camel/pascal风格（需要额外的验证）
        if self.is_pascal(name) and self._is_valid_pascal_case(name):
            result |= NameStyle.PASCAL
        if self.is_camel(name) and self._is_valid_camel_case(name):
            result |= NameStyle.CAMEL

        # 检查匈牙利命名法
        if self.is_hungarian(name):
            result |= NameStyle.HUNGARIAN

        # 如果没有匹配任何风格，返回UNKNOWN
        if result == NameStyle(0):
            return NameStyle.UNKNOWN

        return result

    def detect_style(self, name: str) -> NameStyle:
        """自动检测命名风格（返回最可能的单一风格）"""
        if not name:
            return NameStyle.INVALID

        # 检查无效命名
        if self._is_invalid_name(name):
            return NameStyle.INVALID

        # 检查是否是 Python 关键字（包括软关键字），关键字不应被视为有效命名
        if self.keywords.is_py_keyword(name) or self.keywords.is_py_softkeyword(
            name
        ):
            return NameStyle.INVALID

        # 特殊命名风格检查（按优先级排序）
        # 优先检查特殊命名：魔术方法 > 私有方法 > 保护方法
        if self.is_magic_snake(name):
            return NameStyle.MAGIC_SNAKE
        if self.is_private_snake(name):
            return NameStyle.PRIVATE_SNAKE
        if self.is_protected_snake(name):
            return NameStyle.PROTECTED_SNAKE

        # Kebab 风格检查（只在有短横线分隔符时考虑）
        if "-" in name:
            if self.is_pascal_kebab(name):
                return NameStyle.PASCAL_KEBAB
            if self.is_upper_kebab(name):
                return NameStyle.UPPER_KEBAB
            if self.is_standard_kebab(name):
                return NameStyle.STANDARD_KEBAB
            return NameStyle.UNKNOWN

        # Snake 风格检查（只在有下划线分隔符时考虑）
        if "_" in name:
            # 尾蛇形（Pydantic 关键字）放在标准蛇形之后检查
            # 因为标准蛇形是更通用的风格
            if self.is_pascal_snake(name):
                return NameStyle.PASCAL_SNAKE
            if self.is_upper_snake(name):
                return NameStyle.UPPER_SNAKE
            if self.is_standard_snake(name):
                return NameStyle.STANDARD_SNAKE
            if self.is_end_snake(name):
                return NameStyle.END_SNAKE
            return NameStyle.UNKNOWN

        # 没有分隔符的情况：检查 Camel 和 Pascal 风格
        # 优先检查 CAMEL（因为单个小写单词更接近驼峰命名）
        if self.is_camel(name) and self._is_valid_camel_case(name):
            return NameStyle.CAMEL
        if self.is_pascal(name) and self._is_valid_pascal_case(name):
            return NameStyle.PASCAL

        # 检查匈牙利命名法（放在驼峰/帕斯卡之后，优先级较低）
        if self.is_hungarian(name):
            return NameStyle.HUNGARIAN

        return NameStyle.UNKNOWN

    def is_invalid(self, name: str) -> bool:
        """检查是否是无效的命名"""
        return self._is_invalid_name(name)

    def _is_valid_pascal_case(self, name: str) -> bool:
        """检查是否是有效的帕斯卡命名（内部验证方法）

        驼峰风格要求：至少有一个大小写边界、数字，或者是单个单词
        """
        # 检查是否有大小写边界或数字
        has_upper_after_lower = any(
            name[i - 1].islower() and name[i].isupper()
            for i in range(1, len(name))
        )
        has_digit = any(c.isdigit() for c in name)
        # 或者是单个单词的帕斯卡命名（首字母大写，其余为小写）
        is_single_word_pascal = (
            len(name) == 1 and name[0].isupper()
        ) or (  # 单个大写字母
            len(name) > 1 and name[0].isupper() and name[1:].islower()
        )
        # 或者是全大写的单词（如 ALLCAPS）
        is_all_uppercase = len(name) > 1 and name.isupper()
        return (
            has_upper_after_lower
            or has_digit
            or is_single_word_pascal
            or is_all_uppercase
        )

    def _is_valid_camel_case(self, name: str) -> bool:
        """检查是否是有效的驼峰命名（内部验证方法）

        驼峰风格要求：至少有一个大小写边界、数字，或者是全小写单词（包括单个字母）
        """
        # 检查是否有大小写边界或数字
        has_lower_to_upper = any(
            name[i - 1].islower() and name[i].isupper()
            for i in range(1, len(name))
        )
        has_digit = any(c.isdigit() for c in name)
        # 或者是单个单词的camel命名（全小写，包括单个字母）
        is_single_word_camel = len(name) >= 1 and name.islower()
        return has_lower_to_upper or has_digit or is_single_word_camel

    def _is_invalid_name(self, name: str) -> bool:
        """检查是否是无效的命名（语法错误）"""
        # 检查空字符串
        if not name:
            return True

        # 检查数字开头
        if name[0].isdigit():
            return True

        # 检查纯数字
        if name.isdigit():
            return True

        # 检查是否包含非ASCII字符（如中文等）
        # Python 3.0+ 允许中文作为标识符，但在命名系统中我们只支持ASCII
        if not name.isascii():
            return True

        # 检查是否包含非法字符（只允许字母、数字、下划线、短横线）
        if not self.patterns.valid_general_identifier_pattern.match(name):
            return True

        # 检查是否同时包含多种分隔符
        has_underscore = "_" in name
        has_hyphen = "-" in name
        has_other_separators = any(c in name for c in ".:,;")

        # 如果同时包含下划线和短横线，说明有混合分隔符
        if has_underscore and has_hyphen:
            return True

        # 如果包含其他分隔符，也是无效的
        if has_other_separators:
            return True

        # 检查连续分隔符
        # 对于下划线，魔术方法和私有方法允许使用 __，但中间不能有其他连续下划线
        if "__" in name:
            # 检查是否是合法的魔术方法或私有方法
            is_magic = (
                name.startswith("__") and name.endswith("__") and len(name) > 4
            )
            is_private = name.startswith("__") and len(name) > 2
            if not (is_magic or is_private):
                return True
            # 对于魔术方法，检查中间是否有 __
            if is_magic:
                middle = name[2:-2]
                if "__" in middle:
                    return True
            # 对于私有方法，检查中间是否有 __
            elif is_private:
                middle = name[2:]
                if "__" in middle:
                    return True
        if "--" in name:  # 连续短横线
            return True

        # 检查分隔符开头（短横线开头无效）
        if name.startswith("-"):
            return True

        # 检查分隔符结尾
        # 魔术方法允许以 __ 结尾
        is_magic_method = (
            name.startswith("__") and name.endswith("__") and len(name) > 4
        )
        # 尾蛇形变量（Pydantic关键字）允许以 _ 结尾
        is_end_snake_pattern_match = bool(
            self.patterns.end_snake_pattern.match(name)
        )
        if name.endswith("-") or (
            name.endswith("_")
            and not is_magic_method
            and not is_end_snake_pattern_match
        ):
            return True

        # 检查以单下划线开头但后面紧跟大写字母的情况（不符合标准命名约定）
        # 保护方法应该是 _lowercase，私有方法应该是 __lowercase
        if name.startswith("_") and not name.startswith("__"):
            # 跳过下划线后检查剩余部分
            remaining = name[1:]
            if remaining and remaining[0].isupper():
                return True

        # 检查以双下划线开头但后面紧跟大写字母的情况（不符合私有方法命名约定）
        # 私有方法应该是 __lowercase
        if name.startswith("__") and not name.startswith("___"):
            # 跳过两个下划线后检查剩余部分
            remaining = name[2:]
            if remaining and remaining[0].isupper():
                return True

        return False

    # 标识符验证函数
    def is_py_identifier(self, name: str) -> bool:
        """检查是否是有效的Python标识符"""
        return name.isidentifier()

    def is_identifier(self, name: str) -> bool:
        """检查是否是通用标识符（包含短横线）"""
        if not name:
            return False

        # 不能以数字或短横线开头
        if name[0].isdigit() or name[0] == "-":
            return False

        # 只允许字母、数字、下划线、短横线
        return bool(self.patterns.valid_general_identifier_pattern.match(name))

    # 风格识别函数
    def is_pascal(self, name: str) -> bool:
        """检查是否是帕斯卡命名"""
        return bool(
            self.patterns.pascal_pattern.match(name)
        ) and not name.startswith("_")

    def is_camel(self, name: str) -> bool:
        """检查是否是驼峰命名"""
        return bool(self.patterns.camel_pattern.match(name))

    def is_kebab(self, name: str) -> bool:
        """检查是否是短横线命名（包含所有变体）"""
        return (
            self.is_standard_kebab(name)
            or self.is_upper_kebab(name)
            or self.is_pascal_kebab(name)
        )

    def is_standard_kebab(self, name: str) -> bool:
        """检查是否是标准短横线命名"""
        return bool(self.patterns.standard_kebab_pattern.match(name))

    def is_upper_kebab(self, name: str) -> bool:
        """检查是否是大写短横线命名"""
        return bool(self.patterns.upper_kebab_pattern.match(name))

    def is_pascal_kebab(self, name: str) -> bool:
        """检查是否是帕斯卡短横线命名"""
        return bool(self.patterns.pascal_kebab_pattern.match(name))

    def is_snake(self, name: str) -> bool:
        """检查是否是蛇形命名（包含所有变体）"""
        return (
            self.is_standard_snake(name)
            or self.is_upper_snake(name)
            or self.is_pascal_snake(name)
            or self.is_magic_snake(name)
            or self.is_protected_snake(name)
            or self.is_private_snake(name)
        )

    def is_standard_snake(self, name: str) -> bool:
        """检查是否是标准蛇形命名"""
        return bool(self.patterns.standard_snake_pattern.match(name))

    def is_upper_snake(self, name: str) -> bool:
        """检查是否是大写蛇形命名"""
        return bool(self.patterns.upper_snake_pattern.match(name))

    def is_pascal_snake(self, name: str) -> bool:
        """检查是否是帕斯卡蛇形命名"""
        return bool(self.patterns.pascal_snake_pattern.match(name))

    def is_magic_snake(self, name: str) -> bool:
        """检查是否是魔术方法命名"""
        return bool(self.patterns.magic_snake_pattern.match(name))

    def is_protected_snake(self, name: str) -> bool:
        """检查是否是保护方法命名"""
        return bool(self.patterns.protected_snake_pattern.match(name))

    def is_private_snake(self, name: str) -> bool:
        """检查是否是私有方法命名"""
        return bool(self.patterns.private_snake_pattern.match(name))

    def is_end_snake(self, name: str) -> bool:
        """检查是否是尾蛇形命名（以下划线结尾，用于Pydantic关键字）"""
        return bool(self.patterns.end_snake_pattern.match(name))

    def is_hungarian(self, name: str) -> bool:
        """检查是否是匈牙利命名法"""
        if not name:
            return False

        # 匈牙利命名法通常以类型前缀开头
        hungarian_prefixes = [
            "a",  # Array - 数组
            "by",  # Unsigned Char (byte) - 字节
            "c",  # Char - 字符
            "cb",  # Count of bytes - 字节数量
            "cr",  # Color reference value - 颜色
            "cx",  # Count of x (short) - x类型数量
            "dw",  # DWORD (unsigned long) - 双字
            "f",  # Flags (usually multiple bit values) - 多位标志
            "fn",  # Function - 函数
            "h",  # Handle - 句柄
            "i",  # Integer - 整数
            "l",  # Long - 长整数
            "lp",  # Long pointer - 长指针
            "n",  # Short int - 短整数
            "p",  # Pointer - 指针
            "s",  # String - 字串
            "sz",  # Zero terminated String - 零结束字串
            "tm",  # Text metric - 公制文本
            "u",  # Unsigned int - 无符号整数
            "ul",  # Unsigned long (ULONG) - 无符号长整数
            "w",  # WORD (unsigned short) - 字
            "x",  # x coordinates (short) - x坐标值
            "y",  # y coordinates (short) - y坐标值
            "ch",  # char - 8位字符
            "b",  # BOOL - 布尔变量
            "lpsz",  # LPSTR - 32位字符串指针
            "lpfn",  # (*fn)( ) - 回调函数指针
            "psz",  # 空
            "pfn",  # 空
        ]

        # 检查是否以已知前缀开头
        for prefix in hungarian_prefixes:
            if name.startswith(prefix):
                # 检查剩余部分是否符合标识符规则
                remaining = name[len(prefix) :]
                if remaining and (
                    remaining[0].isupper() or remaining[0].isdigit()
                ):
                    return bool(
                        self.patterns.valid_identifier_pattern.match(name)
                    )

        return False

    # 转换函数
    def _convert(
        self,
        name: str,
        from_style: NameStyle,
        to_style: NameStyle,
        exception: bool = False,
        return_empty: bool = False,
    ) -> str:
        """通用的命名风格转换方法

        Args:
            name: 要转换的名称
            from_style: 源风格
            to_style: 目标风格
            exception: 遇到错误时是否抛出异常
            return_empty: 遇到错误时是否返回空字符串

        Returns:
            转换后的名称
        """
        try:
            if not name:
                return "" if return_empty else name

            # 检查是否以数字开头
            if name[0].isdigit():
                if exception:
                    raise NamingValidationException(
                        f"Name '{name}' cannot start with a digit"
                    )
                return "" if return_empty else name

            # 检查是否已经是目标格式，避免不必要的转换
            if self._is_already_target_style(name, to_style):
                return name

            # 检测源风格（如果未指定）
            if from_style == NameStyle.UNKNOWN:
                from_style = self.detect_style(name)

            words = self.split_into_words(name, from_style)
            if not words:
                return "" if return_empty else name

            # 获取分隔符
            to_style_name = to_style.name if to_style.name else ""
            is_snake = "SNAKE" in to_style_name
            is_kebab = "KEBAB" in to_style_name

            separator = ""
            if is_snake:
                separator = "_"
            elif is_kebab:
                separator = "-"
            # Pascal/Camel 不需要分隔符

            # 获取前缀和后缀（Python 特有风格）
            prefix, suffix = self._get_prefix_suffix(to_style)

            # 转换单词
            result_words: list[str] = []
            for i, word in enumerate(words):
                result_words.append(
                    self._convert_word_for_style(word, to_style, i)
                )

            # 拼接结果
            if separator:
                result = prefix + separator.join(result_words) + suffix
            else:
                result = prefix + "".join(result_words) + suffix

            return result
        except (ValueError, AttributeError, IndexError) as e:
            if exception:
                raise NamingConversionException(
                    f"Failed to convert '{name}' from {from_style} to {to_style}: {e}"
                ) from e
            return "" if return_empty else name

    def _is_already_target_style(
        self, name: str, target_style: NameStyle
    ) -> bool:
        """检查名称是否已经是目标风格"""
        if target_style == NameStyle.PASCAL:
            return self.is_pascal(name)
        if target_style == NameStyle.CAMEL:
            return self.is_camel(name)
        if target_style == NameStyle.STANDARD_KEBAB:
            return self.is_standard_kebab(name)
        if target_style == NameStyle.UPPER_KEBAB:
            return self.is_upper_kebab(name)
        if target_style == NameStyle.PASCAL_KEBAB:
            return self.is_pascal_kebab(name)
        if target_style == NameStyle.STANDARD_SNAKE:
            return self.is_standard_snake(name)
        if target_style == NameStyle.UPPER_SNAKE:
            return self.is_upper_snake(name)
        if target_style == NameStyle.PASCAL_SNAKE:
            return self.is_pascal_snake(name)
        if target_style == NameStyle.MAGIC_SNAKE:
            return self.is_magic_snake(name)
        if target_style == NameStyle.PROTECTED_SNAKE:
            return self.is_protected_snake(name)
        if target_style == NameStyle.PRIVATE_SNAKE:
            return self.is_private_snake(name)
        return False

    def _get_prefix_suffix(self, style: NameStyle) -> tuple[str, str]:
        """获取风格的前缀和后缀（Python 特有风格）"""
        if style == NameStyle.MAGIC_SNAKE:
            return "__", "__"
        if style == NameStyle.PRIVATE_SNAKE:
            return "__", ""
        if style == NameStyle.PROTECTED_SNAKE:
            return "_", ""
        return "", ""

    def pascalize(
        self,
        name: str,
        from_style: NameStyle = NameStyle.UNKNOWN,
        exception: bool = False,
        return_empty: bool = False,
    ) -> str:
        """转换为帕斯卡命名"""
        return self._convert(
            name, from_style, NameStyle.PASCAL, exception, return_empty
        )

    def camelize(
        self,
        name: str,
        from_style: NameStyle = NameStyle.UNKNOWN,
        exception: bool = False,
        return_empty: bool = False,
    ) -> str:
        """转换为驼峰命名"""
        return self._convert(
            name, from_style, NameStyle.CAMEL, exception, return_empty
        )

    def kebabize(
        self,
        name: str,
        from_style: NameStyle = NameStyle.UNKNOWN,
        to_style: NameStyle = NameStyle.STANDARD_KEBAB,
        exception: bool = False,
        return_empty: bool = False,
    ) -> str:
        """转换为短横线命名

        Args:
            name: 要转换的名称
            from_style: 源风格
            to_style: 目标风格，默认为 STANDARD_KEBAB，可选：
                - STANDARD_KEBAB (默认): kebab-case
                - UPPER_KEBAB: UPPER-KEBAB-CASE
                - PASCAL_KEBAB: Pascal-Kebab-Case
            exception: 遇到错误时是否抛出异常
            return_empty: 遇到错误时是否返回空字符串
        """
        return self._convert(
            name, from_style, to_style, exception, return_empty
        )

    def snakeize(
        self,
        name: str,
        from_style: NameStyle = NameStyle.UNKNOWN,
        to_style: NameStyle = NameStyle.STANDARD_SNAKE,
        exception: bool = False,
        return_empty: bool = False,
    ) -> str:
        """转换为蛇形命名

        Args:
            name: 要转换的名称
            from_style: 源风格
            to_style: 目标风格，默认为 STANDARD_SNAKE，可选：
                - STANDARD_SNAKE (默认): snake_case
                - UPPER_SNAKE: UPPER_SNAKE_CASE
                - PASCAL_SNAKE: Pascal_Snake_Case
                - MAGIC_SNAKE: __magic_method__
                - PROTECTED_SNAKE: _protected_var
                - PRIVATE_SNAKE: __private_var
            exception: 遇到错误时是否抛出异常
            return_empty: 遇到错误时是否返回空字符串
        """
        return self._convert(
            name, from_style, to_style, exception, return_empty
        )
