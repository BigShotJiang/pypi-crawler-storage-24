"""日志管理器"""

import logging
from logging.config import dictConfig
from pathlib import Path
from typing import cast
import importlib
from copy import deepcopy
from pynomad.common.decorator import singleton
from pynomad.common.types import Level
from pynomad.logsystem.formatters import BaseFormatter, ColorFormatter
from pynomad.logsystem.logger import Logger, RootLogger
from pynomad.logsystem.logtypes import FormatStrings
from pynomad.config.loader.manager import loadermanager

type _Level = int | str | Level


@singleton
class LoggerManager:
    """日志管理器"""

    def __init__(self):
        logging.setLoggerClass(Logger)
        self._replace_root_logger()
        self._init_level()
        dictConfig(self.get_logger_config())

    def get_logger_config(self):
        """获取日志配置

        合并用户配置与默认配置：
        1. 使用默认配置作为基础
        2. 忽略用户的 version 字段
        3. 对于 console_colored formatter:
           - 忽略用户的 class，使用默认的 ColorFormatter
           - 如果用户配置了 fmtbuild_method 且没有 format，调用该方法获取 FormatStrings
           - 添加 show 字段支持 (plain/static/dynamic)
        4. 对于其他 ColorFormatter 类型的 formatter，同样添加 show 字段支持和 fmtbuild_method
        5. 用户添加的 formatter 和 handler 以追加方式添加到默认配置中
        6. Handler 权限规则：
           - console_colored handler: 用户只能修改 level
           - console_stdout handler: 用户有完全权限，可以切换为标准日志模式

        Returns:
            合并后的日志配置字典
        """

        default_cfg = self.get_default_logger_config()
        user_cfg: dict[str, object] = {}
        try:
            env_config = loadermanager.get_environment_config()
            user_cfg_dict: object = env_config.get("logging", {})
            if isinstance(user_cfg_dict, dict):
                user_cfg = cast(dict[str, object], user_cfg_dict)
        except Exception:
            # 获取用户配置失败，使用默认配置
            pass

        # 深度复制默认配置
        merged_cfg: dict[str, object] = deepcopy(default_cfg)

        # Helper: 动态调用 fmtbuild_method
        def _get_fmtbuild_method_result(
            method_path: str,
        ) -> FormatStrings | None:
            """动态调用 fmtbuild_method 获取 FormatStrings

            Args:
                method_path: 方法路径，格式为 "module.path:method_name"

            Returns:
                FormatStrings 元组，调用失败返回 None
            """
            try:
                module_path, method_name = method_path.split(":")
                module = importlib.import_module(module_path)
                method = getattr(module, method_name)
                result: object = method()
                if (
                    isinstance(result, tuple)
                    and len(tuple[object]) == 3  # type: ignore
                    and all(isinstance(item, str) for item in result)  # type: ignore
                ):
                    return cast(FormatStrings, result)
            except Exception:
                pass
            return None

        # Helper: 判断是否为 ColorFormatter 类
        def _is_color_formatter_class(class_path: str) -> bool:
            """判断给定的类路径是否为 ColorFormatter 或其子类

            Args:
                class_path: 类路径字符串

            Returns:
                是否为 ColorFormatter 类
            """
            try:
                module_path, class_name = class_path.rsplit(".", 1)
                module = importlib.import_module(module_path)
                cls = getattr(module, class_name)
                return isinstance(cls, type) and issubclass(cls, ColorFormatter)
            except Exception:
                return False

        # Helper: 处理彩色 formatter 配置
        def _process_color_formatter(
            fmt_config: dict[str, object],
        ) -> dict[str, object]:
            """处理 ColorFormatter 的特殊配置

            Args:
                fmt_config: formatter 配置字典

            Returns:
                处理后的 formatter 配置
            """
            result: dict[str, object] = fmt_config.copy()

            # 如果配置了 fmtbuild_method 且没有 format，调用该方法
            fmtbuild_method = result.get("fmtbuild_method")
            if fmtbuild_method and "format" not in result:
                if isinstance(fmtbuild_method, str):
                    format_strings = _get_fmtbuild_method_result(
                        fmtbuild_method
                    )
                    if format_strings is not None:
                        # 如果配置了 show，根据 show 值选择对应的格式字符串
                        show_value = result.get("show", "dynamic")
                        if show_value == "plain":
                            result["format"] = format_strings[0]
                        elif show_value == "static":
                            result["format"] = format_strings[1]
                        else:  # dynamic
                            result["format"] = format_strings[2]

            return result

        # 合并 formatters
        formatters: dict[str, dict[str, object]] = cast(
            dict[str, dict[str, object]],
            merged_cfg.get("formatters", {}),
        )
        user_formatters: dict[str, dict[str, object]] = cast(
            dict[str, dict[str, object]], user_cfg.get("formatters", {})
        )

        for fmt_name, fmt_config in user_formatters.items():
            # 处理 console_colored formatter
            if fmt_name == "console_colored":
                # console_colored 用户只能修改 level（实际上 formatter 没有 level）
                # 忽略用户的 class，使用默认的 ColorFormatter
                result: dict[str, object] = fmt_config.copy()
                _ = result.pop("class", None)
                # 处理 fmtbuild_method 和 show
                result = _process_color_formatter(result)
                formatters[fmt_name] = result
            elif fmt_name in formatters:
                # 已存在的 formatter，检查是否为 ColorFormatter
                existing_config = formatters[fmt_name]
                class_path = existing_config.get("class", "")
                if isinstance(class_path, str) and _is_color_formatter_class(
                    class_path
                ):
                    # ColorFormatter 类型，支持 fmtbuild_method 和 show
                    result = fmt_config.copy()
                    # 如果用户没有配置 class，保持默认
                    if "class" in result:
                        result["class"] = class_path
                    result = _process_color_formatter(result)
                    formatters[fmt_name] = result
                else:
                    # 非 ColorFormatter，直接追加用户配置
                    formatters[fmt_name] = fmt_config
            else:
                # 新增的 formatter，追加到默认配置
                formatters[fmt_name] = fmt_config

        merged_cfg["formatters"] = formatters

        # 合并 handlers
        handlers: dict[str, dict[str, object]] = cast(
            dict[str, dict[str, object]], merged_cfg.get("handlers", {})
        )
        user_handlers: dict[str, dict[str, object]] = cast(
            dict[str, dict[str, object]], user_cfg.get("handlers", {})
        )

        for handler_name, handler_config in user_handlers.items():
            # console_colored handler: 用户只能修改 level
            if handler_name == "console_colored":
                existing_handler = handlers.get(handler_name, {})
                result: dict[str, object] = existing_handler.copy()
                # 只允许修改 level
                if "level" in handler_config:
                    result["level"] = handler_config["level"]
                handlers[handler_name] = result
            elif handler_name in handlers:
                # console_stdout 等其他 handler: 用户有完全权限
                handlers[handler_name] = handler_config
            else:
                # 新增的 handler，追加到默认配置
                handlers[handler_name] = handler_config

        merged_cfg["handlers"] = handlers

        # 合并 root 日志器配置（合并而非替换）
        if "root" in user_cfg:
            existing_root: dict[str, object] = cast(dict[str, object], merged_cfg.get("root", {}))
            user_root: dict[str, object] = cast(dict[str, object], user_cfg["root"])
            result_root: dict[str, object] = existing_root.copy()
            # 合并用户配置
            result_root.update(user_root)
            merged_cfg["root"] = result_root

        # 合并指定名称的日志器配置
        loggers: dict[str, dict[str, object]] = cast(
            dict[str, dict[str, object]],
            merged_cfg.get("loggers", {}),
        )
        user_loggers: dict[str, dict[str, object]] = cast(
            dict[str, dict[str, object]], user_cfg.get("loggers", {})
        )

        for logger_name, logger_config in user_loggers.items():
            loggers[logger_name] = logger_config

        if loggers:
            merged_cfg["loggers"] = loggers

        return merged_cfg

    def get_default_logger_config(self):
        """获取默认日志配置

        根据激活环境自动调整日志方案：
        - 如果 active_envs 包含 prod/product/production，则：
          * root 日志级别改为 INFO
          * console_stdout handler 级别改为 INFO
          * file_rotating_daily handler 保持 INFO
        - 否则使用默认的 DEBUG 级别配置

        包含:
        - formatters: console_colored (彩色控制台), file_standard (文件格式)
        - handlers: console_stdout (标准输出), file_rotating_daily (按天轮转)
        """
        basedir = loadermanager.basedir
        active_envs = loadermanager.active_envs

        # 从配置读取日志目录
        env_config = loadermanager.get_environment_config()
        logs_dir_config = env_config.get("logging", {}).get("logs_dir")
        if logs_dir_config and isinstance(logs_dir_config, str):
            logs_dir = Path(logs_dir_config)
        else:
            logs_dir = basedir / "logs"

        # 确保日志目录存在
        logs_dir.mkdir(parents=True, exist_ok=True)

        # 检测是否为生产环境
        production_keywords = ["prod", "product", "production"]
        is_production = any(
            env.lower() in production_keywords for env in active_envs
        )

        # 根据环境设置日志级别
        root_level = "INFO" if is_production else "TRACE"
        # console handler 使用 NOTSET，让 root logger 控制过滤
        console_level = "NOTSET"

        cfg: dict[str, object] = {
            "version": 1,
            "disable_existing_loggers": False,
            "formatters": {
                # 彩色控制台输出 - 带颜色和级别样式
                "console_colored": {
                    "class": f"{ColorFormatter.__module__}.{ColorFormatter.__name__}",
                    "format": BaseFormatter.DEFAULT_FORMAT_STRINGS[2],
                },
                # 文件输出 - 标准格式，不带颜色
                "file_standard": {
                    "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
                    "datefmt": "%Y-%m-%d %H:%M:%S",
                },
            },
            "handlers": {
                # 标准输出 - 使用彩色格式
                "console_stdout": {
                    "class": "logging.StreamHandler",
                    "level": console_level,
                    "formatter": "console_colored",
                    "stream": "ext://sys.stdout",
                },
                "console_colored": {
                    "class": "logging.StreamHandler",
                    "level": console_level,
                    "formatter": "console_colored",
                    "stream": "ext://sys.stdout",
                },
                # 按天轮转的文件输出 - 保留 7 天
                "file_rotating_daily": {
                    "class": "logging.handlers.TimedRotatingFileHandler",
                    "level": "INFO",
                    "formatter": "file_standard",
                    "filename": str(logs_dir / "app.log"),
                    "when": "midnight",
                    "interval": 1,
                    "backupCount": 7,
                    "encoding": "utf-8",
                },
            },
            "root": {
                "level": root_level,
                "handlers": ["console_colored", "file_rotating_daily"],
            },
        }
        return cfg

    def _replace_root_logger(self):
        """替换 root logger 为自定义 Logger 实例"""
        # 创建新的 root logger
        new_root = RootLogger(Level.UNSET)
        # 替换 logging 模块中的 root 引用
        logging.root = new_root
        # 替换 Logger 类的 root 属性
        setattr(logging.Logger, "root", new_root)
        # 确保 Manager 也使用新的 root
        setattr(logging.Logger.manager, "root", new_root)

    def get_logger(self, name: str = ""):
        """获取日志"""
        logger = logging.getLogger(Logger.get_name(name))
        result = cast(Logger, logger)

        # 动态匹配并设置日志级别
        self._apply_dynamic_level(result)

        return result

    def _apply_dynamic_level(self, logger: Logger):
        """应用动态级别配置

        支持通配符和层级继承：
        1. 通配符：如 "test.*" = "WARN"
        2. 层级继承："test" = "WARN" 会应用到 "test.submodule"

        同时设置 pretty 配置
        """
        # 获取配置中的 logging 部分
        all_config = loadermanager.get_environment_config()
        logging_config = cast(dict[str, object], all_config.get("logging", {}))

        # 设置 pretty 配置
        pretty_value = logging_config.get("pretty")
        if isinstance(pretty_value, bool):
            logger.pretty_enabled = pretty_value

        if "level" not in logging_config:
            return

        user_levels = cast(dict[str, str], logging_config["level"])
        logger_name = logger.name

        # 按优先级查找匹配的配置
        # 优先级：精确匹配 > 父级匹配 > 通配符匹配
        best_level = None
        best_priority = -1

        for pattern, level_value in user_levels.items():
            priority = 0

            # 精确匹配
            if pattern == logger_name:
                priority = 100
            # 父级匹配（pattern 是 logger_name 的前缀）
            elif logger_name.startswith(pattern + "."):
                priority = 50 + pattern.count(".")  # 越具体的父级优先级越高
            # 通配符匹配
            elif "*" in pattern or "?" in pattern:
                import fnmatch
                if fnmatch.fnmatch(logger_name, pattern):
                    priority = 10 + pattern.count("*")  # 越具体的通配符优先级越高

            if priority > best_priority:
                best_priority = priority
                best_level = level_value

        if best_level:
            try:
                level = Level[best_level.upper()]
                logger.setLevel(level)
            except KeyError:
                pass  # 忽略无效的级别名称

    def _init_level(self):
        """初始化日志级别
        将自定义的 Level 枚举注册到 logging 模块中。
        """
        for level in Level:
            logging.addLevelName(level.value, level.name)


logmanager = LoggerManager()


def get_logger(name: str = ""):
    """获取日志"""
    return logmanager.get_logger(name=name)
