from abc import ABC, abstractmethod
from pynomad.cache.core.meta import MetaInfo
from pynomad.cache.core.types import EvictionPolicy, ValueLoader
from pynomad.result.result import ResultAny


class Cache(ABC):
    def __init__(
        self,
        name: str = "cache",
        maxsize: int = 0,
        eviction_policy: EvictionPolicy = "none",
        ttl: int = 0,
    ):
        self._name = name
        self._maxsize = maxsize
        self._eviction_policy = eviction_policy
        self._default_ttl = ttl

    @property
    def name(self) -> str:
        """缓存名称"""
        return self._name

    @property
    def maxsize(self) -> int:
        """最大缓存数量"""
        return self._maxsize

    @property
    def eviction_policy(self) -> str:
        return self._eviction_policy

    @abstractmethod
    def get[T](
        self,
        key: str,
        default: T | None = None,
        valueloader: ValueLoader[T] | None = None,
    ) -> ResultAny[T]:
        """获取缓存"""

    @abstractmethod
    def put(
        self,
        key: str,
        value: object,
        ttl: int = 0,
        only_absent: bool = False,
        extra_params: dict[str, object] | None = None,
    ) -> bool:
        """存放缓存"""

    @abstractmethod
    def evict(self, key: str) -> bool:
        """从缓存中移除指定key"""

    @abstractmethod
    def refresh_ttl(self, key: str, ttl: int = 0) -> bool:
        """刷新缓存过期时间"""

    @abstractmethod
    def clear(self) -> bool:
        """清除缓存"""

    @abstractmethod
    def size(self) -> int:
        """获取缓存大小"""

    @abstractmethod
    def get_meta(self, key: str) -> "MetaInfo | None":
        """获取缓存元数据"""
