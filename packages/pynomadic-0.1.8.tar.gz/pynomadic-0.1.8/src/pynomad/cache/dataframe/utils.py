"""DataFrame 缓存工具函数"""
from typing import Any, cast
from pandas import DataFrame
from pynomad.result.result import Result


def parse_cache_dataframe(cache_data: Result[Any] | DataFrame | None) -> DataFrame | None:
    """从缓存数据中解析出 DataFrame

    Args:
        cache_data: 从缓存获取的数据,可能是 Result[Any]、Result[DataFrame]、DataFrame 或 None

    Returns:
        DataFrame: 解析出的 DataFrame 对象，缓存未命中时返回 None
    """
    # 防御性检查: 确保 cache_data 不为 None
    if cache_data is None:
        return None

    # 情况1: cache_data 直接是 DataFrame 类型
    if isinstance(cache_data, DataFrame):
        return cache_data

    # 情况2: cache_data 是 Result 类型，需要解包
    if isinstance(cache_data, Result):  # type: ignore[reportUnnecessaryIsInstance]
        # 防御性检查: 确保 cache_data.data 不为 None（缓存未命中）
        if cache_data.data is None:
            return None

        data = cache_data.data

        # 情况2.1: data 直接是 DataFrame 类型
        if isinstance(data, DataFrame):
            return data

        # 情况2.2: data 是 Result 类型,需要二次解包
        if isinstance(data, Result):
            # 检查 Result 的 data 是否存在
            if data.data is None: # type: ignore
                return None

            result_data = cast(Any, data.data) # type: ignore

            # 检查二次解包后的数据是否为 DataFrame
            if isinstance(result_data, DataFrame):
                return result_data

            # 数据类型不匹配，返回 None
            return None

    # 数据类型不匹配
    msg = f"缓存数据类型为 {type(cache_data)},不是 DataFrame 或 Result[DataFrame]"
    raise ValueError(msg)
