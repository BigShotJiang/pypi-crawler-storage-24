from enum import Enum, auto
from inspect import Parameter, signature
from typing import Any, Protocol, cast, get_args, get_origin

from pandas import DataFrame

from pynomad.cache.core.meta import MetaInfo
from pynomad.cache.core.types import DecoratorTarget, EvictionPolicy, KeyGenerator
from pynomad.cache.dataframe.utils import parse_cache_dataframe
from pynomad.common.exceptions import NeedsRefreshException
from pynomad.common.pys import MethodType, get_method_type
from pynomad.result.result import Result, ResultAny
from pynomad.cache.decorator.keygenerator import module_function_key_generator


class ReflashParams:
    def __init__(self, args: tuple[Any, ...], kwargs: dict[str, Any]) -> None:
        self._args = args
        self._kwargs = kwargs

    @property
    def args(self):
        return self._args

    @property
    def kwargs(self):
        return self._kwargs

    def get_full_kwargs(self, func: DecoratorTarget) -> dict[str, Any]:
        """合并 args 和 kwargs，将 args 映射到对应的参数名"""
        method_type = get_method_type(func)
        sig = signature(func)
        parameters = list(sig.parameters.values())
        result: dict[str, Any] = {}

        # 跳过 self/cls
        start_idx = 0
        if method_type == MethodType.INSTANCE_FUNCTION:
            start_idx = 1  # 跳过 self
        elif method_type == MethodType.CLASS_FUNCTION:
            start_idx = 1  # 跳过 cls

        # 将位置参数映射到参数名
        for i, arg in enumerate(self._args):
            param_idx = start_idx + i
            if param_idx < len(parameters):
                param_name = parameters[param_idx].name
                result[param_name] = arg

        # 合并关键字参数
        result.update(self._kwargs)
        return result


type MaybeRefreshResult = Result[DataFrame] | Result[ReflashParams]


class CacheStage(Enum):
    """缓存阶段枚举

    定义 DataFrame 缓存装饰器的三个处理阶段：
    - GET: 从缓存提取数据
    - PUT: 合并数据并缓存
    - EXTRACT: 提取返回数据
    """

    GET = auto()  # 从缓存提取
    PUT = auto()  # 合并数据并缓存
    EXTRACT = auto()  # 提取返回数据
    UNSET = auto()


class DataFrameLoaderContext:
    """DataFrame 缓存加载器上下文

    统一的数据结构，用于：
    1. 存储装饰器解析后的所有信息（替代 CacheWrapperInfo 和 FunctionReturn）
    2. 作为三阶段（GET/PUT/EXTRACT）的参数传递对象

    设计原则：
    - 必要的参数通过 __init__ 传入
    - 可推导的属性通过 @property 动态计算
    - 支持通过 set 方法动态设置属性
    """

    def __init__(
        self,
        func: DecoratorTarget,
        args: tuple[Any, ...] = (),
        kwargs: dict[str, Any] = {},
        cache_stage: CacheStage = CacheStage.UNSET,
        cache_name: str = "",
        maxsize: int = 0,
        keygenerator: KeyGenerator = module_function_key_generator,
        ttl: int = 0,
        eviction_policy: EvictionPolicy = "none",
        decorator_extra_params: dict[str, Any] = {},
    ):
        """初始化上下文对象

        Args:
            func: 被装饰的函数
            args: 函数的位置参数
            kwargs: 函数的关键字参数
            cache_stage: 缓存阶段
            cache_name: 缓存名称
            maxsize: 缓存容量
            keygenerator: 键生成器
            ttl: 生存时间
            eviction_policy: 淘汰策略
            decorator_extra_params: 装饰器额外参数
            meta_info: 缓存元信息
        """
        # 必要的初始化参数
        self._func: DecoratorTarget = func
        self._args: tuple[Any, ...] = args
        self._kwargs: dict[str, Any] = kwargs
        self._method_type: MethodType = get_method_type(func)

        # 装饰器参数
        self._cache_stage: CacheStage = cache_stage
        self._cache_name: str = cache_name
        self._maxsize: int = maxsize
        self._keygenerator: KeyGenerator = keygenerator
        self._ttl: int = ttl
        self._eviction_policy: EvictionPolicy = eviction_policy
        self._decorator_extra_params: dict[str, Any] = decorator_extra_params

        # 元数据相关
        self._meta_info: MetaInfo | None = None

        # 动态信息（可通过 set 方法设置）
        self._is_hit: bool | None = None
        self._cache_key: str | None = None
        self._is_call_function_succeed: bool | None = None
        self._is_put_succeed: bool | None = None
        self._is_extract_succeed: bool | None = None

        # 返回值类型分析（懒加载）
        self._return_type: type[Any] | None = None
        self._is_dataframe: bool | None = None

        # 缓存数据（用于判断是否是 DataFrame 类型）
        self._cached_data: Any = None
        self._cached_dataframe: DataFrame | None = None
        self._request_data: Any = None
        self._request_dataframe: DataFrame | None = None
        self._merge_data: Any = None
        self._merge_dataframe: DataFrame | None = None
        self._extract_data: Any = None
        self._extract_dataframe: DataFrame | None = None
        self._last_visit_args: tuple[Any, ...] = ()
        self._last_visit_kwargs: dict[str, Any] = {}
        self._reflash_params: ReflashParams | None = None
        self._should_wrap: bool | None = None

    # =============初始化参数属性（只读）================
    @property
    def func(self) -> DecoratorTarget:
        """被装饰的函数"""
        return self._func

    @property
    def args(self) -> tuple[Any, ...]:
        """函数的位置参数，未传递的位置参数使用默认值填充"""
        sig = signature(self._func)
        parameters = list(sig.parameters.values())

        # 将位置参数转换为列表，便于扩展
        args_list = list(self._args)

        # 补充有默认值的参数
        for param in parameters:
            # 跳过 *args 和 **kwargs
            if param.kind in (Parameter.VAR_POSITIONAL, Parameter.VAR_KEYWORD):
                continue

            # 计算当前参数在 args 中的索引
            param_idx = parameters.index(param)

            # 如果该参数位置未传递，且有默认值，则补充
            if param_idx >= len(args_list) and param.default is not Parameter.empty:
                args_list.append(param.default)

        return tuple(args_list)

    @property
    def method_type(self) -> MethodType:
        """函数的方法类型"""
        return self._method_type

    @property
    def only_args(self) -> tuple[Any, ...]:
        """移除掉self,cls后的位置参数，未传递的位置参数使用默认值填充"""
        # 需要通过method_type判断
        if self._method_type == MethodType.INSTANCE_FUNCTION:
            # 实例方法，第一个参数是 self
            filtered_args = self._args[1:] if len(self._args) > 1 else ()
        elif self._method_type == MethodType.CLASS_FUNCTION:
            # 类方法，第一个参数是 cls
            filtered_args = self._args[1:] if len(self._args) > 1 else ()
        else:
            # 普通函数、静态方法、lambda，不需要移除参数
            filtered_args = self._args

        # 获取函数签名，补充默认值
        sig = signature(self._func)
        parameters = list(sig.parameters.values())

        # 跳过 self/cls
        start_idx = 0
        if self._method_type == MethodType.INSTANCE_FUNCTION:
            start_idx = 1  # 跳过 self
        elif self._method_type == MethodType.CLASS_FUNCTION:
            start_idx = 1  # 跳过 cls

        # 将位置参数转换为列表，便于扩展
        args_list = list(filtered_args)

        # 补充有默认值的参数
        for param in parameters[start_idx:]:
            # 跳过 *args 和 **kwargs
            if param.kind in (Parameter.VAR_POSITIONAL, Parameter.VAR_KEYWORD):
                continue

            # 计算当前参数在 filtered_args 中的索引
            param_idx = parameters.index(param) - start_idx

            # 如果该参数位置未传递，且有默认值，则补充
            if param_idx >= len(args_list) and param.default is not Parameter.empty:
                args_list.append(param.default)

        return tuple(args_list)

    @property
    def kwargs(self) -> dict[str, Any]:
        """函数的关键字参数，未传递的关键字参数使用默认值填充"""
        sig = signature(self._func)
        parameters = list(sig.parameters.values())

        # 复制原始 kwargs
        result = dict(self._kwargs)

        # 跳过 self/cls
        start_idx = 0
        if self._method_type == MethodType.INSTANCE_FUNCTION:
            start_idx = 1  # 跳过 self
        elif self._method_type == MethodType.CLASS_FUNCTION:
            start_idx = 1  # 跳过 cls

        # 为未传递的参数填充默认值
        for param in parameters[start_idx:]:
            if param.name not in result:
                if param.default is not Parameter.empty:
                    result[param.name] = param.default
                elif param.kind == Parameter.VAR_KEYWORD:
                    # **kwargs 类型，跳过
                    continue
                elif param.kind == Parameter.VAR_POSITIONAL:
                    # *args 类型，跳过
                    continue
                # 其他情况（没有默认值的必需参数）保持未填充状态

        return result

    @property
    def full_kwargs(self) -> dict[str, Any]:
        """函数的所有参数,不包括self/cls，未传递的参数使用默认值填充"""
        # 需要整合被装饰方法的args和kwargs
        sig = signature(self._func)
        parameters = list(sig.parameters.values())
        result: dict[str, Any] = {}

        # 跳过 self/cls
        start_idx = 0
        if self._method_type == MethodType.INSTANCE_FUNCTION:
            start_idx = 1  # 跳过 self
        elif self._method_type == MethodType.CLASS_FUNCTION:
            start_idx = 1  # 跳过 cls

        # 将位置参数映射到参数名
        only_args = self.only_args
        for i, arg in enumerate(only_args):
            param_idx = start_idx + i
            if param_idx < len(parameters):
                param_name = parameters[param_idx].name
                result[param_name] = arg

        # 合并关键字参数
        result.update(self._kwargs)

        # 为未传递的参数填充默认值
        for param in parameters[start_idx:]:
            if param.name not in result:
                if param.default is not Parameter.empty:
                    result[param.name] = param.default
                elif param.kind == Parameter.VAR_KEYWORD:
                    # **kwargs 类型，跳过
                    continue
                elif param.kind == Parameter.VAR_POSITIONAL:
                    # *args 类型，跳过
                    continue
                # 其他情况（没有默认值的必需参数）保持未填充状态

        return result

    @property
    def has_explicit_return_type(self) -> bool:
        """被装饰方法是否定义了返回值类型"""
        sig = signature(self._func)
        return sig.return_annotation is not Parameter.empty

    @property
    def explicit_return_type(self) -> type | None:
        """被装饰方法定义的返回值类型"""
        sig = signature(self._func)
        if sig.return_annotation is Parameter.empty:
            return None
        return sig.return_annotation

    @property
    def instance_or_class(self) -> Any:
        """获取实例或类对象（self/cls）"""
        if self._method_type == MethodType.INSTANCE_FUNCTION:
            # 实例方法，返回 self
            return self._args[0] if len(self._args) > 0 else None
        elif self._method_type == MethodType.CLASS_FUNCTION:
            # 类方法，返回 cls
            return self._args[0] if len(self._args) > 0 else None
        else:
            # 普通函数、静态方法、lambda，返回 None
            return None

    @property
    def cache_stage(self) -> CacheStage:
        """缓存阶段"""
        return self._cache_stage

    def set_cache_stage(self, cachestage: CacheStage):
        self._cache_stage = cachestage

    @property
    def cache_name(self) -> str:
        """缓存名称"""
        return self._cache_name

    @property
    def maxsize(self) -> int:
        """缓存容量"""
        return self._maxsize

    @property
    def keygenerator(self) -> KeyGenerator:
        """键生成器"""
        return self._keygenerator

    @property
    def cached_key(self) -> str:
        """计算缓存key"""
        if self._cache_key is None:
            self._cache_key = self._keygenerator(
                self._func,
                self.instance_or_class,
                self.only_args,
                self._kwargs,
            )
        return self._cache_key

    @property
    def ttl(self) -> int:
        """生存时间"""
        return self._ttl

    @property
    def eviction_policy(self) -> EvictionPolicy:
        """淘汰策略"""
        return self._eviction_policy

    @property
    def decorator_extra_params(self) -> dict[str, Any]:
        """装饰器额外参数"""
        return self._decorator_extra_params

    @property
    def meta_info(self) -> MetaInfo | None:
        """缓存元信息"""
        return self._meta_info

    def set_metainfo(self, metainfo: MetaInfo):
        """设置缓存元信息，并从 extra_params 中同步更新上次访问参数"""
        self._meta_info = metainfo
        # 设置 meta_info 时同步更新上次访问参数
        if not metainfo.extra_params:
            return
        args = metainfo.extra_params.get("args", ())
        kwargs = metainfo.extra_params.get("kwargs", {})
        assert isinstance(args, tuple)
        assert isinstance(kwargs, dict)
        self._last_visit_args: tuple[Any, ...] = args
        self._last_visit_kwargs: dict[str, Any] = kwargs

    # =============动态信息（可设置）================
    @property
    def last_visit_args(self) -> tuple[Any, ...] | None:
        """上次访问的位置参数"""
        return self._last_visit_args

    @property
    def last_visit_kwargs(self) -> dict[str, Any] | None:
        """上次访问的关键字参数"""
        return self._last_visit_kwargs

    def _check_is_dataframe_cached_data_is_not_none(self, cached_data: Any) -> bool:
        if cached_data is None:
            return False
        if isinstance(cached_data, DataFrame):
            return True
        if isinstance(cached_data, Result):
            res_cached: Result[object] = cast(Result[object], cached_data)
            data = res_cached.data
            if data is None:
                return False
            if isinstance(data, DataFrame):
                return True
            if isinstance(data, Result):
                data = cast(Result[object], data)
                if data.data is None:
                    return False
                if isinstance(data.data, DataFrame):
                    return True
        return False

    def _check_is_dataframe_cached_data_is_none(self) -> bool:
        """检查缓存数据为 None 时是否应被视为 DataFrame 缓存"""
        if not self.has_explicit_return_type:
            return False
        if self.explicit_return_type is DataFrame:
            return True
        # 检查是否为 Result[DataFrame] 或 ResultAny[DataFrame]
        origin = get_origin(self.explicit_return_type)
        if origin is None:
            return False
        if origin in (Result, ResultAny):
            args = get_args(self.explicit_return_type)
            if args and args[0] is DataFrame:
                return True
        return False

    def check_is_dataframe(self, cached_data: Any) -> bool:
        """检测 data 是否应该被视为 DataFrame"""
        if self._check_is_dataframe_cached_data_is_not_none(cached_data):
            return True
        if self._check_is_dataframe_cached_data_is_none():
            return True
        return False

    def check_is_hit(self, cached_data: Any) -> bool:
        """检查是否命中缓存"""
        if cached_data is None:
            return False
        if isinstance(cached_data, Result):
            data = cast(Result[object], cached_data)
            if data.data is None:
                return False
            return cached_data.is_success()
        return False

    def get_return_type(self, cached_data: Any) -> type | None:
        """获取返回值类型"""
        if cached_data is None:
            return self.explicit_return_type
        # 如果 cache_data 是 DataFrame，返回 DataFrame 类型
        if isinstance(cached_data, DataFrame):
            return DataFrame
        # 如果 cache_data 是 Result 或 ResultAny，检查其 data
        if isinstance(cached_data, Result):
            res_cached: Result[object] = cast(Result[object], cached_data)
            if res_cached.data is None:
                return self.explicit_return_type
            return type(res_cached.data)
        return type(cast(object, cached_data))

    @property
    def cached_data(self) -> Any:
        """缓存数据"""
        return self._cached_data

    @property
    def should_wrap(self) -> bool:
        if self._should_wrap is not None:
            return self._should_wrap
        return self._determ_should_wrap_by_explicit_return_type()

    def _determ_should_wrap_by_explicit_return_type(self) -> bool:
        """根据显式返回类型判断是否需要将 DataFrame 包装为 Result

        Returns:
            True: 需要包装（显式返回类型是 Result[DataFrame] 或 ResultAny[DataFrame]）
            False: 不需要包装（显式返回类型是 DataFrame 或没有显式返回类型）
        """
        if not self.has_explicit_return_type:
            return False

        if self.explicit_return_type is DataFrame:
            return False

        # 检查是否为 Result[DataFrame] 或 ResultAny[DataFrame]
        origin = get_origin(self.explicit_return_type)
        if origin is None:
            return False

        if origin in (Result, ResultAny):
            # 已经是 Result 类型，需要包装
            return True

        return False

    def _determ_should_wrap_by_request_data(self, request_data: Any):
        if isinstance(request_data, DataFrame):
            return False
        if isinstance(request_data, Result):
            return True
        return False

    def set_cached_data(self, cached_data: Any):
        self._cached_data = cached_data
        # 设置缓存数据的时候是GET阶段
        self._cache_stage = CacheStage.GET
        self._is_hit = self.check_is_hit(cached_data=cached_data)
        self._is_dataframe = self.check_is_dataframe(cached_data=cached_data)
        self._return_type = self.get_return_type(cached_data=cached_data)
        self._cached_dataframe = parse_cache_dataframe(cache_data=cached_data)

    def set_request_data(self, request_data: Any):
        # 设置请求后的数据已经到了合并阶段
        self._cache_stage = CacheStage.PUT
        self._request_data = request_data
        if self._should_wrap is None:
            self._should_wrap = self._determ_should_wrap_by_request_data(request_data)
        self._request_dataframe = parse_cache_dataframe(cache_data=request_data)

    def set_merge_data(self, merge_data: Any):
        self._cache_stage = CacheStage.EXTRACT
        self._merge_data = merge_data
        self._merge_dataframe = parse_cache_dataframe(cache_data=merge_data)

    def set_extract_data(self, extract_data: Any):
        self._cache_stage = CacheStage.EXTRACT
        self._extract_data = extract_data
        self._extract_dataframe = parse_cache_dataframe(cache_data=extract_data)

    @property
    def request_dataframe(self):
        return self._request_data

    @property
    def cached_dataframe(self):
        return self._cached_dataframe

    @property
    def merge_dataframe(self):
        return self._merge_dataframe

    @property
    def extract_dataframe(self):
        return self._extract_dataframe

    @property
    def is_hit(self):
        return self._is_hit

    @property
    def is_dataframe(self):
        if self._is_dataframe:
            return self._is_dataframe
        return self._check_is_dataframe_cached_data_is_none()

    @property
    def is_put_succeed(self):
        return self._is_put_succeed

    def set_put_succeed(self, succeed: bool):
        self._is_put_succeed = succeed

    @property
    def is_extract_succeed(self):
        return self._is_extract_succeed

    def set_extract_succeed(self, succeed: bool):
        self._is_extract_succeed = succeed

    @property
    def is_call_function_succeed(self):
        return self._is_call_function_succeed

    def set_call_function_succeed(self, succeed: bool):
        self._is_call_function_succeed = succeed

    def set_reflash_params(self, reflash_params: ReflashParams):
        self._reflash_params = reflash_params

    @property
    def reflash_params(self):
        return self._reflash_params

    @property
    def reflash_args(self) -> tuple[Any, ...]:
        """刷新参数中的位置参数"""
        return self._reflash_params.args if self._reflash_params else ()

    @property
    def reflash_kwargs(self) -> dict[str, Any]:
        """刷新参数中的关键字参数"""
        return self._reflash_params.kwargs if self._reflash_params else {}

    @property
    def reflash_full_kwargs(self) -> dict[str, Any]:
        """刷新参数的完整参数字典"""
        if not self._reflash_params:
            return {}
        return self._reflash_params.get_full_kwargs(self._func)


class DataFrameValueLoader(Protocol):
    """DataFrame 值加载器协议

    用于 DataFrame 缓存装饰器的三阶段数据处理：
    1. GET: 从缓存中提取数据，失败时抛出 NeedsRefreshException
    2. PUT: 合并缓存数据和新数据
    3. EXTRACT: 从合并后的数据中提取最终返回数据

    注意：缓存的数据和返回的数据可能不同
    """

    def get(
        self,
        context: DataFrameLoaderContext,
        cache_data: DataFrame,
    ) -> MaybeRefreshResult:
        """GET 阶段：从缓存提取数据
        Args:
            context: DataFrame 加载器上下文，包含所有必要信息
            cache_data: 从缓存获取的 DataFrame

        Returns:
            缓存可用返回 success（携带 DataFrame）,已经处理好的DataFrame
            缓存不可用返回 client_error（携带 NeedsRefreshException 和刷新参数 dict）
        """
        ...

    def put(
        self,
        context: DataFrameLoaderContext,
        cache_data: DataFrame,
        new_data: DataFrame,
    ) -> ResultAny[DataFrame]:
        """PUT 阶段：合并缓存数据和新数据

        Args:
            context: DataFrame 加载器上下文，包含所有必要信息
            cache_data: 原缓存中的 DataFrame
            new_data: 新获取的 DataFrame

        Returns:
            合并后的需要缓存的 DataFrame
        """
        ...

    def extract(
        self,
        context: DataFrameLoaderContext,
        merged_data: DataFrame,
    ) -> ResultAny[DataFrame]:
        """EXTRACT 阶段：从合并数据中提取返回数据

        Args:
            context: DataFrame 加载器上下文，包含所有必要信息
            merged_data: 合并后的 DataFrame（将被缓存）

        Returns:
            最终返回给调用方的 DataFrame（可能与 merged_data 不同）
        """
        ...


class DefaultDataFrameValueLoader:
    """默认的 DataFrame 值加载器

    提供最简单的缓存逻辑：
    - GET: 参数相同返回缓存，不同抛出 NeedsRefreshException
    - PUT: 直接返回新数据（不合并）
    - EXTRACT: 直接返回传入数据

    适用于不需要复杂合并逻辑的场景。
    """

    def get(
        self,
        context: DataFrameLoaderContext,
        cache_data: DataFrame,
    ) -> MaybeRefreshResult:
        """GET 阶段：比较参数，相同则返回缓存

        Args:
            context: DataFrame 加载器上下文
            cache_data: 从缓存获取的 DataFrame

        Returns:
            参数相同返回 success（携带 DataFrame）
            参数不同返回 client_error（携带 NeedsRefreshException 和 ReflashParams）
        """
        # 获取上次缓存的参数
        last_args = context.last_visit_args
        last_kwargs = context.last_visit_kwargs

        # 比较参数是否相同
        if last_args == context.args and last_kwargs == context.kwargs:
            # 参数相同，返回缓存数据
            return Result[DataFrame].success(data=cache_data)

        # 参数不同，返回客户端错误，携带 ReflashParams
        refresh_params = ReflashParams(args=context.only_args, kwargs=context.kwargs)
        return Result[ReflashParams].client_error(
            exception=NeedsRefreshException(message="参数已变化，需要刷新数据"),
            data=refresh_params,
        )

    def put(
        self,
        context: DataFrameLoaderContext,
        cache_data: DataFrame,
        new_data: DataFrame,
    ) -> ResultAny[DataFrame]:
        """PUT 阶段：直接返回新数据

        Args:
            context: DataFrame 加载器上下文
            cache_data: 原缓存中的 DataFrame（未使用）
            new_data: 新获取的 DataFrame

        Returns:
            新获取的 DataFrame（直接覆盖缓存）
        """
        _ = context
        _ = cache_data
        return Result[DataFrame].success(data=new_data)

    def extract(
        self,
        context: DataFrameLoaderContext,
        merged_data: DataFrame,
    ) -> ResultAny[DataFrame]:
        """EXTRACT 阶段：直接返回传入数据

        Args:
            context: DataFrame 加载器上下文
            merged_data: 合并后的 DataFrame（将被缓存）

        Returns:
            直接返回传入的 DataFrame
        """
        _ = context
        return Result[DataFrame].success(data=merged_data)
