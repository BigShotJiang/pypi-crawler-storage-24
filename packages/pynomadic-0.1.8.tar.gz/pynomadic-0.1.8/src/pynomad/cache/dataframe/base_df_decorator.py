from functools import wraps
from typing import Any, override
from pandas import DataFrame


from pynomad.cache.core.types import DecoratorTarget, EvictionPolicy, KeyGenerator
from pynomad.cache.dataframe.df_cache_types import (
    CacheStage,
    DataFrameValueLoader,
    DefaultDataFrameValueLoader,
    DataFrameLoaderContext,
    ReflashParams,
)
from pynomad.cache.decorator.base_decorator import BaseCacheDecorator
from pynomad.cache.decorator.keygenerator import module_function_key_generator
from pynomad.result.result import ResultAny
from pynomad.logsystem.manager import get_logger
logger=get_logger()


class BaseDataFrameDecorator(BaseCacheDecorator):
    def __init__(
        self,
        name: str | None = None,
        maxsize: int = 0,
        eviction_policy: EvictionPolicy | None = None,
        keygenerator: KeyGenerator = module_function_key_generator,
        value_loader: DataFrameValueLoader | None = None,
        ttl: int = 0,
        **extra_params: Any,  # 用户传递的额外参数,延迟初始化时使用
    ):
        # 初始化父类
        super().__init__(
            name=name,
            maxsize=maxsize,
            eviction_policy=eviction_policy,
            keygenerator=keygenerator,
            ttl=ttl,
            **extra_params,
        )
        # 获取到valueloader
        self._value_loader: DataFrameValueLoader = (
            value_loader or DefaultDataFrameValueLoader()
        )
        self._func = None
        # 保存装饰器传递的额外参数,在 _create_cache 延迟初始化时使用
        self._extra_params = extra_params

        # 保存最后一次调用的参数和 context
        self._last_context: DataFrameLoaderContext | None = None

    def create_context(
        self,
        func: DecoratorTarget,
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> DataFrameLoaderContext:
        """创建 DataFrameLoaderContext 上下文对象

        Args:
            func: 被装饰的函数
            args: 函数调用的位置参数
            kwargs: 函数调用的关键字参数

        Returns:
            DataFrameLoaderContext 实例
        """
        # 构建装饰器额外参数,包含当前装饰器的配置值
        decorator_extra_params: dict[str, Any] = {
            **self._extra_params,  # 子类特有参数
            "name": self._name,
            "maxsize": self._maxsize,
            "ttl": self._ttl,
            "eviction_policy": (
                str(self._eviction_policy) if self._eviction_policy else None
            ),
        }

        # 创建上下文对象
        return DataFrameLoaderContext(
            func=func,
            args=args,
            kwargs=kwargs,
            cache_name=self._name or "",
            maxsize=self._maxsize,
            keygenerator=self._keygenerator,
            ttl=self._ttl,
            eviction_policy=self._eviction_policy or "none",
            decorator_extra_params=decorator_extra_params,
        )

    @override
    def __call__(self, func: DecoratorTarget) -> DecoratorTarget:
        # 保存函数引用用于延迟初始化
        self._func = func

        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            cache_instance = self.get_cache()
            # 创建上下文对象
            context = self.create_context(func=func, args=args, kwargs=kwargs)

            # 保存 context 供后续 get_context() 使用
            self._last_context = context
            # 生成缓存键
            cache_key = context.cached_key
            # 缓存结果
            get_result: ResultAny[Any] = cache_instance.get(cache_key)
            meta_info = cache_instance.get_meta(key=cache_key)
            context.set_cached_data(cached_data=get_result)
            if meta_info:
                context.set_metainfo(meta_info)
            # 如果缓存命中了,且为一般缓存,直接返回
            if context.is_hit and not context.is_dataframe:
                logger.trace(f"缓存命中且不是DataFrame，直接返回: {context.cached_key}")
                return get_result
            # 如果缓存未命中,定义了返回类型,但不是datarame,调用func后直接返回
            if context.has_explicit_return_type and not context.is_dataframe:
                ret = func(*context.only_args, **context.kwargs)
                context.set_call_function_succeed(True)
                logger.trace(f"缓存未命中且不是DataFrame，调用函数后直接返回: {context.cached_key}")
                return ret
            cached_dataframe = (
                context.cached_dataframe
                if context.cached_dataframe is not None
                else DataFrame()
            )
            # 无论是否命中,都需要询问get进行过滤或获取刷新参数
            context.set_cache_stage(cachestage=CacheStage.GET)
            get_result = self._value_loader.get(
                context=context, cache_data=cached_dataframe
            )
            # 如果缓存成功,则直接返回
            if get_result.is_success():
                context.set_extract_data(get_result)
                logger.trace(f"缓存GET成功，直接返回: {context.cached_key}, should_wrap={context.should_wrap}")
                return get_result if context.should_wrap else get_result.data
            # 设置默认刷新参数为用户传入的刷新参数
            reflash_params: ReflashParams = ReflashParams(
                args=context.only_args, kwargs=context.kwargs
            )
            # 如果用户设置了context的刷新参数,那么也认
            if context.reflash_params is not None:
                reflash_params = context.reflash_params
            # 最高优先级,get返回
            if get_result.is_error() and isinstance(get_result.data, ReflashParams):
                reflash_params = get_result.data
            # 将请求参数设置到上下文中
            context.set_reflash_params(reflash_params=reflash_params)
            # 使用刷新参数请求func获取新的数据
            request_data = func(**context.reflash_full_kwargs)
            context.set_call_function_succeed(True)
            context.set_request_data(request_data=request_data)
            request_dataframe = context.request_dataframe
            request_dataframe = (
                request_dataframe if request_dataframe is not None else DataFrame()
            )
            put_result = self._value_loader.put(
                context=context, cache_data=cached_dataframe, new_data=request_dataframe
            )
            context.set_merge_data(put_result)
            put_dataframe = (
                context.merge_dataframe
                if context.merge_dataframe is not None
                else DataFrame()
            )
            storage_extra_params: dict[str, object] = {
                "args": context.only_args,
                "kwarges": context.kwargs,
            }
            # 调用缓存实例,将dataframe存入缓存
            cache_instance.put(
                key=context.cached_key,
                value=put_dataframe,
                ttl=context.ttl,
                only_absent=False,  # get已经拦截,所以这里无论是否有数据都强制更新
                extra_params=storage_extra_params,  # 将本次使用的参数存入元素据
            )
            context.set_put_succeed(True)
            logger.trace(f"PUT阶段完成，缓存已更新: {context.cached_key}")
            # 缓存成功后,调用extract获取最后过滤数据
            extract_result: ResultAny[DataFrame] = self._value_loader.extract(
                context=context,
                merged_data=put_dataframe,
            )
            if extract_result.is_success():
                logger.trace(f"EXTRACT阶段成功，返回数据: {context.cached_key}, should_wrap={context.should_wrap}")
                return extract_result if context.should_wrap else extract_result.data
            if extract_result.exception:
                raise extract_result.exception

        # 调用父类方法设置 wrapper 属性（添加 clear 和 cache_info）
        deal_wrapper = super().wrapper_setting(func, wrapper)

        # 添加 DataFrame 特有的 get_context() 方法
        deal_wrapper.get_context = self.get_context  # type: ignore[attr-defined]

        return deal_wrapper

    def get_context(self) -> DataFrameLoaderContext | None:
        """获取最后一次调用的上下文

        Returns:
            DataFrameLoaderContext 实例，如果没有调用过则返回 None
        """
        return self._last_context
