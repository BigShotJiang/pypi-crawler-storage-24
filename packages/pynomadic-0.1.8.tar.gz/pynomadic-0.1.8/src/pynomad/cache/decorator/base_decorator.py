from abc import ABC, abstractmethod
from functools import wraps
from inspect import signature
from typing import Any, Callable, cast


from pynomad.cache.core.cache_interface import Cache
from pynomad.cache.core.types import (
    DecoratorTarget,
    EvictionPolicy,
    KeyGenerator,
)
from pynomad.logsystem.manager import get_logger
from pynomad.cache.decorator.keygenerator import default_key_generator

logger = get_logger()


class BaseCacheDecorator(ABC):
    """缓存装饰器基类

    提取装饰器的公共逻辑，包括：
    - 参数解析（处理 self/cls）
    - 缓存命中/未命中逻辑
    - 缓存实例延迟初始化
    - 额外工具方法

    子类只需实现 _create_cache() 方法来创建具体的缓存实例。
    """

    def __init__(
        self,
        name: str | None = None,
        maxsize: int = 0,
        eviction_policy: EvictionPolicy | None = None,
        keygenerator: KeyGenerator = default_key_generator,
        ttl: int = 0,
        **extra_params: Any,
    ) -> None:
        """初始化缓存装饰器

        Args:
            name: 缓存实例名称，如果为 None 则自动生成
            maxsize: 缓存最大容量
            eviction_policy: 缓存淘汰策略
            keygenerator: 缓存键生成器
            ttl: 缓存存活时间（秒），0 表示永不过期
        """

        self._name = name
        self._maxsize = maxsize
        self._eviction_policy: EvictionPolicy | None = eviction_policy
        self._keygenerator = keygenerator
        self._ttl = ttl
        self._cache_instance: Cache | None = None
        self._func: DecoratorTarget | None = None
        self._extra_params = extra_params

    def __call__(self, func: DecoratorTarget) -> DecoratorTarget:
        """装饰器调用方法

        Args:
            func: 被装饰的函数

        Returns:
            包装后的函数
        """
        # 保存函数引用用于延迟初始化
        self._func = func

        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            # 获取缓存实例（会自动延迟初始化）
            cache_instance = self.get_cache()

            # 获取实例对象（如果是实例方法或类方法），并填充默认值
            instance_or_class, args_for_key, full_params = self._parse_args(
                func, args, kwargs
            )

            # 生成缓存键
            cache_key = self._keygenerator(
                func, instance_or_class, args_for_key, full_params
            )

            # 尝试从缓存获取
            from pynomad.result.result import ResultAny

            cached_result: ResultAny[object] = cache_instance.get(cache_key)
            if cached_result.is_success() and cached_result.data is not None:
                logger.trace(
                    f"缓存命中 - 函数: {func.__qualname__}, " + f"缓存键: {cache_key}"
                )
                # 检查 TTL 是否需要刷新
                meta = cache_instance.get_meta(cache_key)
                if meta is not None and meta.time_to_live != self._ttl:
                    logger.debug(
                        f"TTL 已更新 - 函数: {func.__qualname__}, "
                        + f"缓存键: {cache_key}, "
                        + f"旧 TTL: {meta.time_to_live}, 新 TTL: {self._ttl}"
                    )
                    _ = cache_instance.refresh_ttl(cache_key, self._ttl)
                return cached_result.data

            # 缓存未命中，执行函数并缓存结果
            logger.trace(
                f"缓存未命中 - 函数: {func.__qualname__}, " + f"缓存键: {cache_key}"
            )
            result = func(*args, **kwargs)

            # 构建扩展参数：保留位置参数，同时将位置参数也打包到 kwargs 中
            extra_params: dict[str, Any] = {
                "args": args_for_key,
                "kwargs": full_params,
            }
            _ = cache_instance.put(
                cache_key, result, ttl=self._ttl, extra_params=extra_params
            )
            logger.trace(
                f"缓存已更新 - 函数: {func.__qualname__}, " + f"缓存键: {cache_key}"
            )
            return result

        return self.wrapper_setting(func, wrapper)

    def wrapper_setting(
        self, func: DecoratorTarget, wrapper: Callable[[], Any]
    ) -> DecoratorTarget:
        """设置 wrapper 的属性并返回

        Args:
            func: 被装饰的原始函数
            wrapper: 包装函数

        Returns:
            配置好的 wrapper
        """
        # 保留原始函数的签名和类型信息
        wrapper.__signature__ = signature(func)  # type: ignore[attr-defined]

        # 将装饰器的 clear() 和 cache_info() 方法绑定到 wrapper 上
        wrapper.clear = self.clear  # type: ignore[attr-defined]
        wrapper.cache_info = self.get_stats  # type: ignore[attr-defined]

        # 类型转换以保留类型提示
        return cast(DecoratorTarget, wrapper)

    @abstractmethod
    def _create_cache(self) -> Cache:
        """创建缓存实例

        子类必须实现此方法，返回具体的缓存实例（MemoryCache 或 RedisCache）。

        Returns:
            Cache 实例
        """
        msg = "子类必须实现 _create_cache() 方法"
        raise NotImplementedError(msg)

    def get_cache(self) -> Cache:
        """获取底层缓存实例

        如果缓存实例尚未初始化，会先执行延迟初始化。

        Returns:
            Cache 实例
        """
        if self._cache_instance is None:
            if self._func is None:
                msg = "缓存实例尚未初始化，请确保装饰器已应用到函数"
                raise RuntimeError(msg)
            # 调用子类的 _create_cache() 方法创建缓存实例
            self._cache_instance = self._create_cache()

        return self._cache_instance

    def clear(self) -> None:
        """清空缓存"""
        cache_instance = self.get_cache()
        _ = cache_instance.clear()

    def get_stats(self) -> dict[str, int]:
        """获取缓存统计信息

        Returns:
            统计信息字典
        """
        cache_instance = self.get_cache()
        stats: dict[str, int] = {
            "size": cache_instance.size(),
        }
        return stats

    def _parse_args(
        self,
        func: DecoratorTarget,
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> tuple[Any | None, tuple[Any, ...], dict[str, Any]]:
        """解析函数参数，分离 self/cls，并填充默认值

        Args:
            func: 被装饰的函数
            args: 函数的位置参数
            kwargs: 函数的关键字参数

        Returns:
            (instance_or_class, args_for_key, full_params) 元组
            - instance_or_class: self（实例方法）、cls（类方法）或 None（普通函数）
            - args_for_key: 用于生成键的位置参数（不包含 self/cls）
            - full_params: 包含默认值的完整参数字典（不包含 self/cls）
        """
        sig = signature(func)
        param_names = list(sig.parameters.keys())

        # 获取所有参数的默认值
        param_defaults = {
            name: param.default
            for name, param in sig.parameters.items()
            if param.default is not param.empty
        }

        instance_or_class: Any | None = None
        args_for_key = args

        # 判断是否有 self/cls
        if args and param_names and hasattr(args[0], param_names[0]):
            instance_or_class = args[0]
            args_for_key = args[1:]
            param_names = param_names[1:]

        # 构建完整参数字典：默认值 -> 位置参数 -> 关键字参数
        full_params: dict[str, Any] = param_defaults.copy()

        # 用位置参数覆盖默认值
        for i, param_name in enumerate(param_names):
            if i < len(args_for_key):
                full_params[param_name] = args_for_key[i]

        # 用关键字参数覆盖（优先级最高）
        full_params.update(kwargs)

        return instance_or_class, args_for_key, full_params

    def set_fun(self, func: DecoratorTarget) -> None:
        """设置被装饰的函数

        允许外部（如多级缓存装饰器）显式设置函数引用，
        以便子装饰器能够正确初始化缓存实例。

        Args:
            func: 被装饰的函数
        """
        self._func = func

    def get_decorator_instance(self) -> "BaseCacheDecorator":
        """获取装饰器实例本身

        允许从装饰后的函数中获取实际的装饰器实例。
        这对于多级缓存组合器等需要访问装饰器内部状态的场景非常有用。

        Returns:
            装饰器实例本身
        """
        return self
