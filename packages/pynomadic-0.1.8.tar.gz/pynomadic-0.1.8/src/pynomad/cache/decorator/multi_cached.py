"""多级缓存组合器

通过组合多个缓存装饰器实现多级缓存，支持通用缓存和 DataFrame 缓存的自由组合。
"""
from functools import wraps
from inspect import iscoroutinefunction, signature
from typing import Any, cast

from pynomad.cache.core.types import DecoratorTarget
from pynomad.logsystem.manager import get_logger

logger = get_logger()


class MultiCached:
    """多级缓存组合器

    通过组合多个缓存装饰器实现多级缓存，支持通用缓存和 DataFrame 缓存的自由组合。
    实现读穿透和写穿透策略。

    Attributes:
        _decorators: 组合的装饰器列表
        _func: 被装饰的函数
    """

    def __init__(self, *decorators: Any) -> None:
        """初始化多级缓存组合器

        Args:
            *decorators: 一个或多个缓存装饰器实例

        Raises:
            ValueError: 如果没有提供任何装饰器
        """
        if not decorators:
            msg = "至少需要提供一个缓存装饰器"
            raise ValueError(msg)

        self._decorators = decorators
        self._decorator_instances: list[Any] = []
        self._func: DecoratorTarget | None = None

    def __call__(self, func: DecoratorTarget) -> DecoratorTarget:
        """组合器调用方法

        根据被装饰函数的类型（同步/异步）选择不同的包装器。

        Args:
            func: 被装饰的函数

        Returns:
            包装后的函数
        """
        self._func = func

        # 初始化所有装饰器实例，设置函数引用
        decorator_instances: list[Any] = []
        for decorator in self._decorators:
            # 获取装饰器实例
            decorator_instance = self._ensure_decorator_instance(decorator, func)
            decorator_instances.append(decorator_instance)

        # 保存装饰器实例引用
        self._decorator_instances = decorator_instances

        # 检测函数是否是异步函数
        if iscoroutinefunction(func):
            return self._async_wrapper(func, decorator_instances)
        return self._sync_wrapper(func, decorator_instances)

    def _ensure_decorator_instance(self, decorator: Any, func: DecoratorTarget) -> Any:
        """确保装饰器已正确初始化并设置函数引用

        Args:
            decorator: 装饰器工厂函数或装饰器实例
            func: 被装饰的函数

        Returns:
            装饰器实例
        """
        # 如果已经是装饰器实例（有 set_fun 方法）
        if hasattr(decorator, 'set_fun'):
            decorator.set_fun(func)
            return decorator

        # 如果是装饰器工厂函数，提取装饰器实例
        # 装饰器工厂返回的是一个内层函数，其闭包中包含装饰器实例
        decorator_func = decorator(func)

        # 尝试从装饰后的函数的闭包中提取装饰器实例
        if hasattr(decorator_func, '__closure__') and decorator_func.__closure__:
            for cell in decorator_func.__closure__:
                cell_contents = cell.cell_contents
                if cell_contents is not None and hasattr(cell_contents, 'set_fun'):
                    # 找到了装饰器实例，设置函数引用
                    cell_contents.set_fun(func)
                    return cell_contents

        # 如果无法提取，抛出错误
        msg = f"无法从装饰器工厂函数 {decorator} 中提取装饰器实例"
        raise TypeError(msg)

    def _sync_wrapper(
        self,
        func: DecoratorTarget,
        decorator_instances: list[Any],
    ) -> DecoratorTarget:
        """同步函数包装器

        Args:
            func: 被装饰的同步函数
            decorator_instances: 装饰器实例列表

        Returns:
            包装后的同步函数
        """
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            # 按顺序尝试从每个装饰器获取数据（读穿透）
            for i, decorator in enumerate(decorator_instances):
                result = self._get_from_decorator(
                    decorator, func, args, kwargs
                )
                if result is not None:
                    # 命中后回填到上层装饰器
                    self._promote_to_upper(result, i, func, args, kwargs)
                    logger.trace(
                        f"多级缓存命中 - 装饰器索引: {i}, "
                        f"装饰器名称: {decorator._name}, "
                        f"函数: {func.__qualname__}"
                    )
                    return result

            # 所有装饰器都未命中，执行原函数
            logger.trace(
                f"多级缓存全部未命中 - 函数: {func.__qualname__}"
            )
            result = func(*args, **kwargs)
            # 将结果写入所有装饰器（写穿透）
            self._put_to_all(result, func, args, kwargs)
            return result

        wrapper.__signature__ = signature(func)  # type: ignore[attr-defined]
        object.__setattr__(wrapper, '__multi_cache__', self)

        # 将 clear 和 cache_info 方法绑定到 wrapper 上
        wrapper.clear = self.clear  # type: ignore[attr-defined]
        wrapper.cache_info = self.get_stats  # type: ignore[attr-defined]

        return cast(DecoratorTarget, wrapper)

    def _async_wrapper(
        self,
        func: DecoratorTarget,
        decorator_instances: list[Any],
    ) -> DecoratorTarget:
        """异步函数包装器

        缓存操作是同步的，函数调用是异步的。

        Args:
            func: 被装饰的异步函数
            decorator_instances: 装饰器实例列表

        Returns:
            包装后的异步函数
        """
        @wraps(func)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            # 按顺序尝试从每个装饰器获取数据（读穿透）
            for i, decorator in enumerate(decorator_instances):
                result = self._get_from_decorator(decorator, func, args, kwargs)
                if result is not None:
                    # 命中后回填到上层装饰器
                    self._promote_to_upper(result, i, func, args, kwargs)
                    logger.trace(
                        f"多级缓存命中（异步函数）- 装饰器索引: {i}, "
                        f"装饰器名称: {decorator._name}, "
                        f"函数: {func.__qualname__}"
                    )
                    return result

            # 所有装饰器都未命中，执行原函数
            logger.trace(
                f"多级缓存全部未命中（异步函数）- 函数: {func.__qualname__}"
            )
            result = await func(*args, **kwargs)
            # 将结果写入所有装饰器（写穿透）
            self._put_to_all(result, func, args, kwargs)
            return result

        async_wrapper.__signature__ = signature(func)  # type: ignore[attr-defined]
        object.__setattr__(async_wrapper, '__multi_cache__', self)

        # 将 clear 和 cache_info 方法绑定到 wrapper 上
        async_wrapper.clear = self.clear  # type: ignore[attr-defined]
        async_wrapper.cache_info = self.get_stats  # type: ignore[attr-defined]

        return cast(DecoratorTarget, async_wrapper)

    def _get_from_decorator(
        self,
        decorator: Any,
        func: DecoratorTarget,
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> Any | None:
        """从指定装饰器获取缓存数据

        通过调用装饰器的内部方法获取缓存数据。

        Args:
            decorator: 缓存装饰器实例
            func: 被装饰的函数
            args: 函数的位置参数
            kwargs: 函数的关键字参数

        Returns:
            缓存数据，未命中返回 None
        """
        try:
            # 获取装饰器的缓存实例
            cache_instance = decorator.get_cache()

            # 使用装饰器的键生成器生成缓存键
            instance_or_class, args_for_key, full_params = decorator._parse_args(
                func, args, kwargs
            )
            cache_key = decorator._keygenerator(
                func, instance_or_class, args_for_key, full_params
            )

            # 尝试从缓存获取
            from pynomad.result.result import ResultAny

            cached_result: ResultAny[object] = cache_instance.get(cache_key)
            if cached_result.is_success() and cached_result.data is not None:
                logger.trace(
                    f"装饰器 {decorator._name} 缓存命中, 键: {cache_key}"
                )
                return cached_result.data

            logger.trace(f"装饰器 {decorator._name} 缓存未命中, 键: {cache_key}")
            return None
        except Exception as e:
            logger.warning(f"从装饰器 {decorator._name} 获取缓存失败: {e}")
            return None

    def _put_to_decorator(
        self,
        decorator: Any,
        value: Any,
        func: DecoratorTarget,
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> None:
        """将数据写入指定装饰器

        Args:
            decorator: 缓存装饰器实例
            value: 要缓存的数据
            func: 被装饰的函数
            args: 函数的位置参数
            kwargs: 函数的关键字参数
        """
        try:
            cache_instance = decorator.get_cache()

            # 生成缓存键
            instance_or_class, args_for_key, full_params = decorator._parse_args(
                func, args, kwargs
            )
            cache_key = decorator._keygenerator(
                func, instance_or_class, args_for_key, full_params
            )

            # 构建扩展参数
            extra_params: dict[str, Any] = {
                "args": args_for_key,
                "kwargs": full_params,
            }

            # 写入缓存
            success = cache_instance.put(
                cache_key,
                value,
                ttl=decorator._ttl,
                extra_params=extra_params,
            )
            if success:
                logger.trace(
                    f"数据已写入装饰器 {decorator._name}, 键: {cache_key}"
                )
            else:
                logger.warning(
                    f"写入装饰器 {decorator._name} 缓存失败，可能是连接问题"
                )
        except Exception as e:
            logger.warning(f"写入装饰器 {decorator._name} 缓存失败: {e}")

    def _put_to_all(
        self,
        value: Any,
        func: DecoratorTarget,
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> None:
        """将数据写入所有装饰器（写穿透）

        Args:
            value: 要缓存的数据
            func: 被装饰的函数
            args: 函数的位置参数
            kwargs: 函数的关键字参数
        """
        for decorator in self._decorator_instances:
            self._put_to_decorator(decorator, value, func, args, kwargs)

    def _promote_to_upper(
        self,
        value: Any,
        from_index: int,
        func: DecoratorTarget,
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> None:
        """将数据回填到上层装饰器

        当在某个装饰器命中后，将数据回填到所有在该装饰器之前的装饰器。

        Args:
            value: 要回填的数据
            from_index: 命中的装饰器索引
            func: 被装饰的函数
            args: 函数的位置参数
            kwargs: 函数的关键字参数
        """
        # 回填到所有在 from_index 之前的装饰器（更高级别）
        for i in range(from_index):
            self._put_to_decorator(
                self._decorator_instances[i], value, func, args, kwargs
            )
            logger.trace(
                f"数据已从装饰器 {from_index} 回填到装饰器 {i}"
            )

    def clear(self) -> None:
        """清空所有装饰器的缓存"""
        for i, decorator in enumerate(self._decorator_instances):
            try:
                decorator.clear()
                logger.trace(f"已清空装饰器 {i} ({decorator._name}) 的缓存")
            except Exception as e:
                logger.warning(
                    f"清空装饰器 {i} ({decorator._name}) 缓存失败: {e}"
                )

    def clear_decorator(self, index: int) -> None:
        """清空指定装饰器的缓存

        Args:
            index: 装饰器索引

        Raises:
            IndexError: 如果索引超出范围
        """
        if index < 0 or index >= len(self._decorator_instances):
            msg = f"装饰器索引 {index} 超出范围 [0, {len(self._decorator_instances)})"
            raise IndexError(msg)

        decorator = self._decorator_instances[index]
        try:
            decorator.clear()
            logger.trace(f"已清空装饰器 {index} ({decorator._name}) 的缓存")
        except Exception as e:
            logger.warning(
                f"清空装饰器 {index} ({decorator._name}) 缓存失败: {e}"
            )

    def get_stats(self) -> dict[int, dict[str, int]]:
        """获取所有装饰器的统计信息

        Returns:
            统计信息字典，键为装饰器索引，值为各自的统计信息
        """
        stats: dict[int, dict[str, int]] = {}
        for i, decorator in enumerate(self._decorator_instances):
            try:
                stats[i] = decorator.get_stats()
            except Exception as e:
                logger.warning(
                    f"获取装饰器 {i} ({decorator._name}) 统计信息失败: {e}"
                )
                stats[i] = {"error": 1}
        return stats

    def get_decorator_stats(self, index: int) -> dict[str, int]:
        """获取指定装饰器的统计信息

        Args:
            index: 装饰器索引

        Returns:
            统计信息字典

        Raises:
            IndexError: 如果索引超出范围
        """
        if index < 0 or index >= len(self._decorator_instances):
            msg = f"装饰器索引 {index} 超出范围 [0, {len(self._decorator_instances)})"
            raise IndexError(msg)

        return self._decorator_instances[index].get_stats()

    def evict(self, key: str) -> None:
        """从所有装饰器删除指定键

        注意：此方法需要所有装饰器使用相同的键生成器，
        否则键可能不匹配。

        Args:
            key: 要删除的缓存键
        """
        for i, decorator in enumerate(self._decorator_instances):
            try:
                cache_instance = decorator.get_cache()
                _ = cache_instance.evict(key)
                logger.trace(f"已从装饰器 {i} ({decorator._name}) 删除键: {key}")
            except Exception as e:
                logger.warning(
                    f"从装饰器 {i} ({decorator._name}) 删除键失败: {e}"
                )

    def evict_decorator(self, key: str, index: int) -> None:
        """从指定装饰器删除键

        Args:
            key: 要删除的缓存键
            index: 装饰器索引

        Raises:
            IndexError: 如果索引超出范围
        """
        if index < 0 or index >= len(self._decorator_instances):
            msg = f"装饰器索引 {index} 超出范围 [0, {len(self._decorator_instances)})"
            raise IndexError(msg)

        decorator = self._decorator_instances[index]
        try:
            cache_instance = decorator.get_cache()
            _ = cache_instance.evict(key)
            logger.trace(f"已从装饰器 {index} ({decorator._name}) 删除键: {key}")
        except Exception as e:
            logger.warning(
                f"从装饰器 {index} ({decorator._name}) 删除键失败: {e}"
            )

    @property
    def decorators(self) -> list[Any]:
        """返回组合的装饰器实例列表"""
        return list(self._decorator_instances)

    @property
    def count(self) -> int:
        """返回装饰器数量"""
        return len(self._decorator_instances)


def multi_cached(*decorators: Any) -> Any:
    """多级缓存组合器装饰器

    通过组合多个缓存装饰器实现多级缓存。

    Args:
        *decorators: 一个或多个缓存装饰器实例

    Returns:
        装饰器

    示例:
        通用缓存组合：
        @multi_cached(
            memcached("l1", ttl=10),
            pickled("l2", ttl=60),
        )
        def get_data(key: str) -> dict:
            return fetch_from_db(key)

        DataFrame 缓存组合：
        @multi_cached(
            df_memcached("df_l1", ttl=30),
            df_rediscached("df_l2", ttl=300),
        )
        def get_dataframe(start: str, end: str) -> pd.DataFrame:
            return query_sales(start, end)

        混合组合：
        @multi_cached(
            memcached("hybrid_l1", ttl=10),
            df_rediscached("hybrid_l2", ttl=300),
        )
        def get_data(id: str) -> pd.DataFrame:
            return load_dataframe(id)

        装饰异步函数：
        @multi_cached(
            memcached("async_l1", ttl=10),
            rediscached("async_l2", ttl=60),
        )
        async def fetch_data(key: str) -> dict:
            return await http_client.get(key)
    """
    return MultiCached(*decorators)
