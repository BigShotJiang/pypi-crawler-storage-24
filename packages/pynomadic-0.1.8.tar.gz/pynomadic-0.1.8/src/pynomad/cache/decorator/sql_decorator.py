"""SQL 缓存装饰器

提供基于 SQL 数据库的 DataFrame 缓存装饰器实现。
"""

from typing import override

import pandas as pd
from pynomad.cache.core.cache_interface import Cache
from pynomad.cache.core.types import (
    EvictionPolicy,
    KeyGenerator,
)
from pynomad.cache.dataframe.base_df_decorator import BaseDataFrameDecorator
from pynomad.cache.dataframe.df_cache_types import (
    DataFrameValueLoader,
)
from pynomad.cache.decorator.keygenerator import module_function_key_generator
from pynomad.cache.impl.sql_cache import SQLCache
from pynomad.cache.properties import (
    SQLCacheProperties,
    DataFrameSQLCacheProperties,
)
from pynomad.logsystem.manager import get_logger

logger = get_logger()
DataFrame = pd.DataFrame


class SQLCacheDecorator(BaseDataFrameDecorator):
    """SQL DataFrame 缓存装饰器

    使用 SQL 数据库作为 DataFrame 缓存存储，支持多种数据库类型（SQLite、MySQL、PostgreSQL）。
    继承 BaseDataFrameDecorator 以获得 DataFrame 特定的三阶段处理逻辑。
    """

    def __init__(
        self,
        name: str | None = None,
        second_name: str | None = None,
        maxsize: int | None = None,
        eviction_policy: EvictionPolicy | None = None,
        keygenerator: KeyGenerator = module_function_key_generator,
        value_loader: DataFrameValueLoader | None = None,
        ttl: int = 0,
        db_type: str | None = None,
        db_url: str | None = None,
        host: str | None = None,
        port: int | None = None,
        db_name: str | None = None,
        username: str | None = None,
        password: str | None = None,
        pool_size: int | None = None,
        max_overflow: int | None = None,
        pool_timeout: int | None = None,
        pool_recycle: int | None = None,
        pool_pre_ping: bool | None = None,
        max_retry_attempts: int | None = None,
        retry_delay: float | None = None,
    ) -> None:
        """初始化 SQL DataFrame 缓存装饰器

        Args:
            name: 缓存实例名称，如果为 None 则自动生成
            second_name: 二级名称（用于区分具体方法或数据），None 表示使用配置默认值
            maxsize: 缓存最大容量，None 表示使用配置默认值
            eviction_policy: 缓存淘汰策略，None 表示使用配置默认值
            keygenerator: 缓存键生成器
            value_loader: DataFrame 值加载器
            ttl: 缓存存活时间（秒），0 表示使用配置默认值
            db_type: 数据库类型（sqlite、mysql、postgresql），None 表示使用配置默认值
            db_url: 数据库连接 URL（完整格式），None 表示使用配置默认值
            host: 数据库主机地址（与 db_url 互斥），None 表示使用配置默认值
            port: 数据库端口（与 db_url 互斥），None 表示使用配置默认值
            db_name: 数据库名称（与 db_url 互斥），None 表示使用配置默认值
            username: 数据库用户名（与 db_url 互斥），None 表示使用配置默认值
            password: 数据库密码（与 db_url 互斥），None 表示使用配置默认值
            pool_size: 连接池大小，None 表示使用配置默认值
            max_overflow: 连接池最大溢出数，None 表示使用配置默认值
            pool_timeout: 连接池超时时间（秒），None 表示使用配置默认值
            pool_recycle: 连接回收时间（秒），None 表示使用配置默认值
            pool_pre_ping: 是否在每次连接前测试连接，None 表示使用配置默认值
            max_retry_attempts: 最大重试次数，None 表示使用配置默认值
            retry_delay: 重试延迟（秒），None 表示使用配置默认值
        """
        # 收集所有额外参数,在 _create_cache 中延迟初始化
        extra_params: dict[str, object] = {}
        if second_name is not None:
            extra_params["second_name"] = second_name
        if db_type is not None:
            extra_params["db_type"] = db_type
        if db_url is not None:
            extra_params["db_url"] = db_url
        if host is not None:
            extra_params["host"] = host
        if port is not None:
            extra_params["port"] = port
        if db_name is not None:
            extra_params["db_name"] = db_name
        if username is not None:
            extra_params["username"] = username
        if password is not None:
            extra_params["password"] = password
        if pool_size is not None:
            extra_params["pool_size"] = pool_size
        if max_overflow is not None:
            extra_params["max_overflow"] = max_overflow
        if pool_timeout is not None:
            extra_params["pool_timeout"] = pool_timeout
        if pool_recycle is not None:
            extra_params["pool_recycle"] = pool_recycle
        if pool_pre_ping is not None:
            extra_params["pool_pre_ping"] = pool_pre_ping
        if max_retry_attempts is not None:
            extra_params["max_retry_attempts"] = max_retry_attempts
        if retry_delay is not None:
            extra_params["retry_delay"] = retry_delay

        super().__init__(
            name=name,
            maxsize=maxsize if maxsize is not None else 0,
            eviction_policy=eviction_policy,
            keygenerator=keygenerator,
            ttl=ttl,
            value_loader=value_loader,
            **extra_params,
        )

    @override
    def _create_cache(self) -> Cache:
        """创建 SQL 缓存实例

        Returns:
            SQLCache 实例
        """

        props = DataFrameSQLCacheProperties()
        # 如果专用前缀没有配置，回退到通用前缀
        if not getattr(props, "_autowired", False):
            props = SQLCacheProperties()
        # 使用父类属性或配置默认值,并更新父类属性
        self._name = self._name if self._name else props.name
        self._maxsize = self._maxsize if self._maxsize else props.maxsize
        self._eviction_policy = (
            self._eviction_policy or props.eviction_policy
        )  # pyright: ignore[reportAttributeAccessIssue]
        self._ttl = self._ttl if self._ttl else props.ttl

        # 使用 extra_params 中的参数或配置默认值(延迟初始化)
        second_name = self._extra_params.get("second_name") or props.second_name
        db_type = self._extra_params.get("db_type") or props.db_type
        db_url = self._extra_params.get("db_url") or props.db_url
        host = self._extra_params.get("host") or props.host
        port = self._extra_params.get("port") or props.port
        db_name = self._extra_params.get("db_name") or props.db_name
        username = self._extra_params.get("username") or props.username
        password = self._extra_params.get("password") if self._extra_params.get("password") else props.password
        pool_size = self._extra_params.get("pool_size") or props.pool_size
        max_overflow = self._extra_params.get("max_overflow") or props.max_overflow
        pool_timeout = self._extra_params.get("pool_timeout") or props.pool_timeout
        pool_recycle = self._extra_params.get("pool_recycle") or props.pool_recycle
        pool_pre_ping = (
            self._extra_params.get("pool_pre_ping")
            if self._extra_params.get("pool_pre_ping") is not None
            else props.pool_pre_ping
        )
        max_retry_attempts = (
            self._extra_params.get("max_retry_attempts")
            if self._extra_params.get("max_retry_attempts")
            else props.max_retry_attempts
        )
        retry_delay = self._extra_params.get("retry_delay") or props.retry_delay

        # 将计算出的值更新到 extra_params 中
        self._extra_params["second_name"] = second_name
        self._extra_params["db_type"] = db_type
        self._extra_params["db_url"] = db_url
        self._extra_params["host"] = host
        self._extra_params["port"] = port
        self._extra_params["db_name"] = db_name
        self._extra_params["username"] = username
        self._extra_params["password"] = password
        self._extra_params["pool_size"] = pool_size
        self._extra_params["max_overflow"] = max_overflow
        self._extra_params["pool_timeout"] = pool_timeout
        self._extra_params["pool_recycle"] = pool_recycle
        self._extra_params["pool_pre_ping"] = pool_pre_ping
        self._extra_params["max_retry_attempts"] = max_retry_attempts
        self._extra_params["retry_delay"] = retry_delay

        return SQLCache(
            name=self._name,
            second_name=second_name,
            maxsize=self._maxsize,
            eviction_policy=self._eviction_policy,
            db_type=db_type,
            db_url=db_url,
            host=host,
            port=port,
            db_name=db_name,
            username=username,
            password=password,
            pool_size=pool_size,
            max_overflow=max_overflow,
            pool_timeout=pool_timeout,
            pool_recycle=pool_recycle,
            pool_pre_ping=pool_pre_ping,
            max_retry_attempts=max_retry_attempts,
            retry_delay=retry_delay,
            ttl=self._ttl,
        )


def sqlcached(
    name: str | None = None,
    second_name: str | None = None,
    maxsize: int | None = None,
    eviction_policy: EvictionPolicy | None = None,
    keygenerator: KeyGenerator = module_function_key_generator,
    value_loader: DataFrameValueLoader | None = None,
    ttl: int = 0,
    db_type: str | None = None,
    db_url: str | None = None,
    host: str | None = None,
    port: int | None = None,
    db_name: str | None = None,
    username: str | None = None,
    password: str | None = None,
    pool_size: int | None = None,
    max_overflow: int | None = None,
    pool_timeout: int | None = None,
    pool_recycle: int | None = None,
    pool_pre_ping: bool | None = None,
    max_retry_attempts: int | None = None,
    retry_delay: float | None = None,
) -> SQLCacheDecorator:
    """SQL DataFrame 缓存装饰器便捷函数

    Args:
        name: 缓存实例名称，如果为 None 则自动生成
        second_name: 二级名称（用于区分具体方法或数据），None 表示使用配置默认值
        maxsize: 缓存最大容量，None 表示使用配置默认值
        eviction_policy: 缓存淘汰策略，None 表示使用配置默认值
        keygenerator: 缓存键生成器
        value_loader: DataFrame 值加载器
        ttl: 缓存存活时间（秒），0 表示永不过期
        db_type: 数据库类型（sqlite、mysql、postgresql），None 表示使用配置默认值
        db_url: 数据库连接 URL（完整格式），None 表示使用配置默认值
        host: 数据库主机地址（与 db_url 互斥），None 表示使用配置默认值
        port: 数据库端口（与 db_url 互斥），None 表示使用配置默认值
        db_name: 数据库名称（与 db_url 互斥），None 表示使用配置默认值
        username: 数据库用户名（与 db_url 互斥），None 表示使用配置默认值
        password: 数据库密码（与 db_url 互斥），None 表示使用配置默认值
        pool_size: 连接池大小，None 表示使用配置默认值
        max_overflow: 连接池最大溢出数，None 表示使用配置默认值
        pool_timeout: 连接池超时时间（秒），None 表示使用配置默认值
        pool_recycle: 连接回收时间（秒），None 表示使用配置默认值
        pool_pre_ping: 是否在每次连接前测试连接，None 表示使用配置默认值
        max_retry_attempts: 最大重试次数，None 表示使用配置默认值
        retry_delay: 重试延迟（秒），None 表示使用配置默认值

    Returns:
        SQLCacheDecorator 装饰器实例

    **重要规范**：
        所有使用 @sqlcached 装饰的函数必须显式声明返回类型注解为 Result[DataFrame]，
        否则装饰器无法正确处理返回值的装箱和缓存一致性。
        这是由 Python 动态类型系统的局限性决定的。

    Example:
        ```python
        from pynomad.cache import sqlcached
        from pandas import DataFrame
        from pynomad.result.result import Result

        @sqlcached(db_type="sqlite", db_url="sqlite:///cache.db", ttl=3600)
        def fetch_data(symbol: str) -> Result[DataFrame]:
            # 返回 DataFrame 的函数
            return Result.success(DataFrame())
        ```
    """
    return SQLCacheDecorator(
        name=name,
        second_name=second_name,
        maxsize=maxsize,
        eviction_policy=eviction_policy,
        keygenerator=keygenerator,
        value_loader=value_loader,
        ttl=ttl,
        db_type=db_type,
        db_url=db_url,
        host=host,
        port=port,
        db_name=db_name,
        username=username,
        password=password,
        pool_size=pool_size,
        max_overflow=max_overflow,
        pool_timeout=pool_timeout,
        pool_recycle=pool_recycle,
        pool_pre_ping=pool_pre_ping,
        max_retry_attempts=max_retry_attempts,
        retry_delay=retry_delay,
    )
