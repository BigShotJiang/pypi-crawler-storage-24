"""SQL 缓存实现

提供基于关系型数据库（SQLite、MySQL、PostgreSQL）的缓存实现。
"""

import hashlib
import os
import pickle
import time
from typing import cast, override

import pandas as pd
from sqlalchemy import (
    create_engine,
    text,
    Integer,
    String,
    BigInteger,
    LargeBinary,
    Index,
    Table,
    Column,
    MetaData,
)
from sqlalchemy.engine import Engine
from sqlalchemy.pool import QueuePool
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, Session

from pynomad.cache.core.cache_interface import Cache
from pynomad.cache.core.meta import MetaInfo
from pynomad.cache.core.types import EvictionPolicy, ValueLoader

from pynomad.result.result import Result, ResultAny
from pynomad.logsystem.manager import get_logger

logger = get_logger()


class Base(DeclarativeBase):
    """SQLAlchemy ORM 基类"""

    pass


class CacheMetaModel(Base):
    """缓存元数据表模型

    对应数据库表名：cache_meta
    """

    __tablename__ = "cache_meta"

    cache_name: Mapped[str] = mapped_column(String(255), primary_key=True)
    second_name: Mapped[str] = mapped_column(String(255), primary_key=True)
    hash_value: Mapped[str] = mapped_column(String(64), primary_key=True)
    table_name: Mapped[str] = mapped_column(String(255))
    create_at: Mapped[int] = mapped_column(BigInteger)
    last_update_at: Mapped[int] = mapped_column(BigInteger)
    last_accessed_at: Mapped[int] = mapped_column(BigInteger)
    access_count: Mapped[int] = mapped_column(Integer, default=0)
    time_to_live: Mapped[int] = mapped_column(Integer, default=0)
    row_count: Mapped[int] = mapped_column(Integer)
    column_count: Mapped[int] = mapped_column(Integer)
    extra_params: Mapped[bytes | None] = mapped_column(LargeBinary, nullable=True)

    # 索引定义
    __table_args__ = (
        Index("idx_create_at", "create_at"),
        Index("idx_last_accessed_at", "last_accessed_at"),
        Index("idx_access_count", "access_count"),
        Index("idx_table_name", "table_name"),
    )


class SQLCache(Cache):
    """SQL 缓存实现

    实现关系型数据库缓存功能，支持多数据库类型、DataFrame 列展开存储、
    容量管理、TTL 过期、重试机制。
    """

    _META_TABLE: str = "cache_meta"

    def __init__(
        self,
        name: str | None = None,
        second_name: str = "",
        maxsize: int | None = None,
        eviction_policy: EvictionPolicy | None = None,
        db_type: str | None = None,
        db_url: str | None = None,
        host: str | None = None,
        port: int | None = None,
        db_name: str | None = None,
        username: str | None = None,
        password: str | None = None,
        pool_size: int | None = None,
        max_overflow: int | None = None,
        pool_timeout: int | None = None,
        pool_recycle: int | None = None,
        pool_pre_ping: bool | None = None,
        max_retry_attempts: int | None = None,
        retry_delay: float | None = None,
        ttl: int | None = None,
    ) -> None:
        """初始化 SQL 缓存

        Args:
            name: 缓存名称
            second_name: 二级名称（用于区分具体方法或数据）
            maxsize: 缓存最大容量，0 表示不限制
            eviction_policy: 缓存淘汰策略
            db_type: 数据库类型（sqlite、mysql、postgresql）
            db_url: 数据库连接 URL（完整格式，与 host/port/db_name/username/password 互斥）
            host: 数据库主机地址（仅适用于 MySQL/PostgreSQL，与 db_url 互斥）
            port: 数据库端口（仅适用于 MySQL/PostgreSQL，与 db_url 互斥）
            db_name: 数据库名称（仅适用于 MySQL/PostgreSQL，与 db_url 互斥）
            username: 数据库用户名（仅适用于 MySQL/PostgreSQL，与 db_url 互斥）
            password: 数据库密码（仅适用于 MySQL/PostgreSQL，与 db_url 互斥）
            pool_size: 连接池大小
            max_overflow: 最大溢出连接数
            pool_timeout: 获取连接超时时间（秒）
            pool_recycle: 连接回收时间（秒）
            pool_pre_ping: 连接前检查有效性
            max_retry_attempts: 最大重试次数
            retry_delay: 重试间隔（秒）
            ttl: 默认 TTL（秒），0 表示不限制过期时间
        """
        # 处理参数默认值
        name = name or ""
        second_name = second_name or ""
        maxsize = maxsize if maxsize is not None else 0
        eviction_policy = eviction_policy or "none"
        db_type = db_type or "sqlite"
        db_url = db_url
        host = host or "localhost"
        port = port if port is not None else 3306
        db_name = db_name or "cache"
        username = username or "root"
        password = password if password is not None else None
        pool_size = pool_size or 5
        max_overflow = max_overflow or 10
        pool_timeout = pool_timeout or 30
        pool_recycle = pool_recycle or 3600
        pool_pre_ping = pool_pre_ping if pool_pre_ping is not None else True
        max_retry_attempts = max_retry_attempts or 3
        retry_delay = retry_delay or 1.0
        ttl = ttl or 0

        # 如果提供了连接参数但未提供 db_url，则构建 db_url
        if not db_url and db_type != "sqlite":
            db_url = self._build_db_url(
                db_type=db_type,
                host=host,
                port=port,
                db_name=db_name,
                username=username,
                password=password,
            )

        super().__init__(
            name=name,
            maxsize=maxsize,
            eviction_policy=eviction_policy,
            ttl=ttl,
        )

        # 二级名称
        self._second_name: str = second_name

        # 数据库配置
        self._db_type: str = db_type
        self._db_url: str | None = db_url
        logger.debug("db_url:", db_url)
        # 连接池配置
        self._pool_size: int = pool_size
        self._max_overflow: int = max_overflow
        self._pool_timeout: int = pool_timeout
        self._pool_recycle: int = pool_recycle
        self._pool_pre_ping: bool = pool_pre_ping

        # 重试配置
        self._max_retry_attempts: int = max_retry_attempts
        self._retry_delay: float = retry_delay

        # TTL 配置
        self._ttl: int = ttl

        # 数据库引擎
        self._engine: Engine | None = None

        # 初始化数据库
        self._init_database()

    @staticmethod
    def _build_db_url(
        db_type: str,
        host: str,
        port: int,
        db_name: str,
        username: str,
        password: str | None = None,
    ) -> str:
        """构建数据库连接 URL

        Args:
            db_type: 数据库类型（mysql、postgresql）
            host: 主机地址
            port: 端口
            db_name: 数据库名称
            username: 用户名
            password: 密码

        Returns:
            数据库连接 URL
        """
        if db_type == "mysql":
            driver = "pymysql"
        elif db_type == "postgresql":
            driver = "psycopg"
        else:
            raise ValueError(f"不支持的数据库类型: {db_type}")

        password_part = f":{password}" if password else ""
        return f"{db_type}+{driver}://{username}{password_part}@{host}:{port}/{db_name}"

    def _init_database(self) -> None:
        """初始化数据库连接和表结构"""
        try:
            # 对于 MySQL/PostgreSQL，先创建数据库（如果不存在）
            if self._db_type in ("mysql", "postgresql"):
                self._create_database_if_not_exists()

            # 对于 SQLite，确保数据库文件目录存在
            if self._db_type == "sqlite":
                self._create_sqlite_directory()

            # 创建主数据库引擎
            self._engine = create_engine(
                self._db_url or "",
                poolclass=QueuePool,
                pool_size=self._pool_size,
                max_overflow=self._max_overflow,
                pool_timeout=self._pool_timeout,
                pool_recycle=self._pool_recycle,
                pool_pre_ping=self._pool_pre_ping,
            )

            # 创建元数据表
            self._create_meta_table()

            logger.info(
                f"SQLCache 初始化成功: name={self.name}, db_type={self._db_type}"
            )

        except Exception as e:
            logger.error(f"初始化数据库失败: {e}")
            raise

    def _create_database_if_not_exists(self) -> None:
        """创建数据库（如果不存在）

        仅适用于 MySQL 和 PostgreSQL
        """
        if not self._db_url:
            return

        try:
            # 解析 db_url 获取数据库名
            db_url_parts = self._db_url.split("/")
            db_name = db_url_parts[-1]

            # 构建连接到服务器（不指定数据库）的 URL
            server_url = "/".join(db_url_parts[:-1])

            # 连接到服务器
            # PostgreSQL 的 CREATE DATABASE 不能在事务块中执行，需要使用 autocommit
            if self._db_type == "postgresql":
                temp_engine = create_engine(server_url, isolation_level="AUTOCOMMIT")
            else:
                temp_engine = create_engine(server_url)

            with temp_engine.connect() as conn:
                # 检查数据库是否存在
                if self._db_type == "mysql":
                    result = conn.execute(text(f"SHOW DATABASES LIKE '{db_name}'"))
                    exists = result.fetchone() is not None

                    if not exists:
                        conn.execute(text(f"CREATE DATABASE `{db_name}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"))  # type: ignore
                        conn.commit()
                        logger.info(f"数据库 {db_name} 创建成功")
                    else:
                        logger.debug(f"数据库 {db_name} 已存在")

                elif self._db_type == "postgresql":
                    result = conn.execute(
                        text(f"SELECT 1 FROM pg_database WHERE datname='{db_name}'")
                    )
                    exists = result.fetchone() is not None

                    if not exists:
                        conn.execute(text(f"CREATE DATABASE \"{db_name}\" ENCODING 'UTF8'"))  # type: ignore
                        logger.info(f"数据库 {db_name} 创建成功")
                    else:
                        logger.debug(f"数据库 {db_name} 已存在")

            temp_engine.dispose()

        except Exception as e:
            logger.error(f"创建数据库失败: {e}")
            raise

    def _create_sqlite_directory(self) -> None:
        """确保 SQLite 数据库文件目录存在（如果不存在则创建）"""
        if not self._db_url:
            return

        # 解析文件路径（sqlite:///path/to/db.db）
        # 去掉 "sqlite:///" 前缀
        db_path = self._db_url.replace("sqlite:///", "")

        # 处理 Windows 路径（如 c:/path）
        if len(db_path) > 1 and db_path[1] == ":":
            # Windows 绝对路径
            dir_path = os.path.dirname(db_path)
        else:
            # Unix 风格路径
            dir_path = os.path.dirname(db_path)

        # 如果目录不存在，创建它
        if dir_path and not os.path.exists(dir_path):
            os.makedirs(dir_path, exist_ok=True)
            logger.info(f"创建 SQLite 数据库目录: {dir_path}")

    def _create_meta_table(self, engine: Engine | None = None) -> None:
        """创建元数据表

        使用 SQLAlchemy ORM 自动创建表结构和索引

        Args:
            engine: 数据库引擎，如果为 None 则使用主引擎
        """
        if engine is None:
            engine = self._engine

        if engine is None:
            raise ValueError("数据库引擎未初始化")

        # 使用 ORM 自动创建表（包括索引）
        CacheMetaModel.metadata.create_all(engine)
        logger.debug("元数据表 cache_meta 创建完成")

    def _make_table_name(self, cache_name: str, second_name: str, key: str) -> str:
        """生成缓存表名

        格式: {cache_name}_{second_name}_{hash}

        Args:
            cache_name: 缓存名称
            second_name: 二级名称
            key: 原始缓存键

        Returns:
            表名
        """
        hash_value = self._hash_key(key)
        return f"{cache_name}_{second_name}_{hash_value}"

    def _hash_key(self, key: str) -> str:
        """对缓存键进行哈希

        Args:
            key: 原始缓存键

        Returns:
            哈希值（前 16 个字符）
        """
        sha256_hash = hashlib.sha256(key.encode("utf-8")).hexdigest()
        return sha256_hash[:16]

    def _create_cache_table(
        self,
        table_name: str,
        df: pd.DataFrame,
        conn: object | None = None,
    ) -> None:
        """创建缓存表

        使用 SQLAlchemy 的 Table API 动态创建表，自动处理不同数据库的语法差异。

        Args:
            table_name: 表名
            df: DataFrame
            conn: 数据库连接
        """
        from sqlalchemy import Float, Boolean, DateTime, Date, Time

        # 使用 MetaData 和 Table API 创建表定义
        metadata = MetaData()

        # 创建列列表
        columns: list[Column] = [  # type: ignore
            Column("id", Integer(), primary_key=True, autoincrement=True)
        ]

        # 为 DataFrame 的每一列创建对应的 Column
        for column_name in df.columns:
            dtype = df[column_name].dtype  # type: ignore
            dtype_name = str(dtype).lower()

            # 根据 dtype 选择合适的 SQLAlchemy 类型
            if dtype_name.startswith("int"):
                if "int64" in dtype_name or "int32" in dtype_name:
                    sql_type = BigInteger()
                else:
                    sql_type = Integer()
            elif dtype_name.startswith("float"):
                sql_type = Float()
            elif dtype_name.startswith("bool"):
                sql_type = Boolean()
            elif dtype_name.startswith("datetime"):
                sql_type = DateTime()
            elif dtype_name.startswith("date"):
                sql_type = Date()
            elif dtype_name.startswith("time"):
                sql_type = Time()
            elif dtype_name.startswith("object"):
                sql_type = String(255)
            else:
                sql_type = String(255)

            # type: ignore - Pylance 无法正确推断联合类型,但运行时是正确的
            columns.append(Column(column_name, sql_type))  # type: ignore

        # 创建 Table 对象并创建表（SQLAlchemy 会自动处理不同数据库的语法差异）
        Table(table_name, metadata, *columns)  # type: ignore
        metadata.create_all(bind=conn)  # type: ignore
        logger.debug(f"缓存表 {table_name} 创建完成")

    def _insert_dataframe(
        self,
        table_name: str,
        df: pd.DataFrame,
        conn: object | None = None,
    ) -> None:
        """插入 DataFrame 数据到缓存表

        Args:
            table_name: 表名
            df: DataFrame
            conn: 数据库连接
        """
        # 使用 pandas 的 to_sql 方法
        _ = df.to_sql(  # type: ignore
            table_name,
            conn,  # type: ignore
            if_exists="append",
            index=False,
            method="multi",
        )
        logger.debug(f"插入 {len(df)} 行数据到表 {table_name}")

    def _read_dataframe(
        self,
        table_name: str,
        conn: object | None = None,
    ) -> pd.DataFrame:
        """从缓存表读取 DataFrame

        Args:
            table_name: 表名
            conn: 数据库连接

        Returns:
            DataFrame
        """
        df = pd.read_sql_table(table_name, conn)  # type: ignore
        # 移除自动创建的 id 列
        if "id" in df.columns:
            df = df.drop(columns=["id"])  # type: ignore
        return df

    def _get_engine(self) -> Engine:
        """获取当前使用的数据库引擎

        Returns:
            数据库引擎
        """
        if self._engine is None:
            raise ValueError("数据库引擎未初始化")
        return self._engine

    def _drop_cache_table(
        self, conn: object | None = None, table_name: str = ""
    ) -> None:
        """删除缓存表

        Args:
            conn: 数据库连接
            table_name: 表名
        """
        drop_table_sql = f"DROP TABLE IF EXISTS {table_name}"
        if conn is not None and hasattr(conn, "execute"):
            conn.execute(text(drop_table_sql))  # type: ignore
        logger.debug(f"删除缓存表 {table_name}")

    def _build_full_key(self, second_name: str, actual_key: str) -> str:
        """构建完整的缓存键

        格式: cache_name:second_name:actual_key

        Args:
            second_name: 二级名称（如函数名）
            actual_key: 原始键（keygenerator 生成的键）

        Returns:
            完整的缓存键
        """
        return f"{self.name}:{second_name}:{actual_key}"

    @override
    def get[T](
        self,
        key: str,
        default: T | None = None,
        valueloader: ValueLoader[T] | None = None,
    ) -> ResultAny[T]:
        """获取缓存

        Args:
            key: 缓存键（格式：cache_name:second_name:actual_key 或 actual_key）
            default: 默认值
            valueloader: 值加载器

        Returns:
            Result 对象
        """
        try:
            # 自动清理过期缓存
            _ = self._clean_expired_keys()

            # 计算 hash
            hash_value = self._hash_key(key)

            # 从元数据表查询
            with Session(self._get_engine()) as session:
                meta = self._get_meta_from_db(
                    session,
                    self.name,
                    self._second_name,
                    hash_value,
                )

                # 缓存不存在
                if meta is None:
                    if valueloader is not None:
                        try:
                            value: T = valueloader(key)
                            _ = self.put(key, value)
                            return Result[T].success(value)
                        except Exception as e:
                            return Result[T].client_error(e)
                    return Result[T].success(data=default)

                # 检查是否过期
                if self._is_expired(meta):
                    logger.trace(f"缓存已过期，删除: {key}")
                    _ = self.evict(key)
                    if valueloader is not None:
                        try:
                            value = valueloader(key)
                            _ = self.put(key, value)
                            return Result[T].success(value)
                        except Exception:
                            pass
                    return Result[T].success(data=default)

                # 更新访问统计
                import time as time_module

                current_time = int(time_module.time())
                meta.last_accessed_at = current_time
                meta.access_count += 1

                # 更新元数据
                _ = self._update_meta_in_db(
                    session, meta, self.name, self._second_name, hash_value
                )

                # 读取 DataFrame
                table_name = self._make_table_name(self.name, self._second_name, key)
                df = self._read_dataframe(table_name, session.connection())

                value_obj: object = df
                value_obj = cast(T, value_obj)
                return Result[T].success(data=value_obj)

        except Exception as e:
            logger.error(f"获取缓存失败: {e}")
            return Result[T].client_error(e)

    @override
    def put(
        self,
        key: str,
        value: object,
        ttl: int = 0,
        only_absent: bool = False,
        extra_params: dict[str, object] | None = None,
    ) -> bool:
        """存放缓存

        Args:
            key: 缓存键
            value: 缓存值（必须是 DataFrame）
            ttl: 存活时间
            only_absent: 是否仅在不存在的时才存储
            extra_params: 扩展参数

        Returns:
            是否成功
        """
        ttl = ttl if ttl > 0 else self._default_ttl
        try:
            # 自动清理过期缓存
            _ = self._clean_expired_keys()

            # 处理 extra_params 默认值
            if extra_params is None:
                extra_params = {}

            # 验证 value 是否为 DataFrame
            if not isinstance(value, pd.DataFrame):
                logger.error(f"SQLCache 仅支持 DataFrame 类型，当前类型: {type(value)}")
                return False

            df: pd.DataFrame = value

            # 计算 hash 和表名
            hash_value = self._hash_key(key)
            table_name = self._make_table_name(self.name, self._second_name, key)

            # 检查 key 是否已存在
            with Session(self._get_engine()) as session:
                existing_meta = self._get_meta_from_db(
                    session,
                    self.name,
                    self._second_name,
                    hash_value,
                )

                if existing_meta is not None and only_absent:
                    # only_absent=True 时，只刷新 TTL，不更新数据
                    return self.refresh_ttl(key, ttl)

                import time as time_module

                current_time = int(time_module.time())

                # 创建或更新 CacheMeta
                if existing_meta is not None:
                    meta = existing_meta
                    meta.last_update_at = float(current_time)
                    # 更新 extra_params 中的 row_count 和 column_count
                    if meta.extra_params is None:
                        meta.extra_params = {}
                    meta.extra_params["row_count"] = len(df)
                    meta.extra_params["column_count"] = len(df.columns)
                    if ttl > 0:
                        meta.time_to_live = float(ttl)
                    if extra_params:
                        if meta.extra_params.get("custom") is None:
                            meta.extra_params["custom"] = {}
                        _ = meta.extra_params["custom"].update(extra_params)  # type: ignore

                    # 删除旧表
                    self._drop_cache_table(session.connection(), table_name)
                else:
                    # 创建新缓存
                    meta = MetaInfo()
                    meta.create_at = float(current_time)
                    meta.last_update_at = float(current_time)
                    meta.last_accessed_at = float(current_time)
                    meta.access_count = 0
                    meta.time_to_live = ttl
                    meta.extra_params = {
                        "row_count": len(df),
                        "column_count": len(df.columns),
                    }
                    if extra_params:
                        meta.extra_params["custom"] = extra_params

                # 创建缓存表
                self._create_cache_table(table_name, df, session.connection())

                # 插入数据
                self._insert_dataframe(table_name, df, session.connection())

                # 更新或插入元数据
                self._upsert_meta(
                    session, meta, self.name, self._second_name, hash_value, table_name
                )

            return True

        except Exception as e:
            logger.error(f"存放缓存失败: {e}")
            return False

    @override
    def evict(self, key: str) -> bool:
        """从缓存中移除指定 key

        Args:
            key: 缓存键（格式：cache_name:second_name:actual_key 或 actual_key）

        Returns:
            是否成功
        """
        try:
            # 计算 hash 和表名
            hash_value = self._hash_key(key)
            table_name = self._make_table_name(self.name, self._second_name, key)

            with Session(self._get_engine()) as session:
                # 删除元数据
                _ = (
                    session.query(CacheMetaModel)
                    .filter(
                        CacheMetaModel.cache_name == self.name,
                        CacheMetaModel.second_name == self._second_name,
                        CacheMetaModel.hash_value == hash_value,
                    )
                    .delete()
                )

                # 删除缓存表
                self._drop_cache_table(session.connection(), table_name)

                session.commit()

            return True

        except Exception as e:
            logger.error(f"移除缓存失败: {e}")
            return False

    @override
    def clear(self) -> bool:
        """清除缓存"""
        try:
            with Session(self._get_engine()) as session:
                # 查询所有缓存表
                meta_records = (
                    session.query(CacheMetaModel.table_name)
                    .filter(CacheMetaModel.cache_name == self.name)
                    .all()
                )
                table_names = [row[0] for row in meta_records]

                # 删除所有缓存表
                for table_name in table_names:
                    self._drop_cache_table(session.connection(), table_name)

                # 删除元数据
                _ = (
                    session.query(CacheMetaModel)
                    .filter(CacheMetaModel.cache_name == self.name)
                    .delete()
                )

                session.commit()

            return True

        except Exception as e:
            logger.error(f"清除缓存失败: {e}")
            return False

    @override
    def refresh_ttl(self, key: str, ttl: int = 0) -> bool:
        """刷新缓存过期时间

        Args:
            key: 缓存键（格式：cache_name:second_name:actual_key 或 actual_key）
            ttl: 新的 TTL 值

        Returns:
            是否成功
        """
        try:
            # 计算 hash
            hash_value = self._hash_key(key)

            with Session(self._get_engine()) as session:
                # 更新元数据
                _ = (
                    session.query(CacheMetaModel)
                    .filter(
                        CacheMetaModel.cache_name == self.name,
                        CacheMetaModel.second_name == self._second_name,
                        CacheMetaModel.hash_value == hash_value,
                    )
                    .update(
                        {
                            CacheMetaModel.time_to_live: ttl,
                            CacheMetaModel.last_update_at: time.time(),
                        }
                    )
                )

                session.commit()

            return True

        except Exception as e:
            logger.error(f"刷新过期时间失败: {e}")
            return False

    @override
    def size(self) -> int:
        """获取缓存大小"""
        try:
            with Session(self._get_engine()) as session:
                count = (
                    session.query(CacheMetaModel)
                    .filter(CacheMetaModel.cache_name == self.name)
                    .count()
                )
                return count

        except Exception as e:
            logger.error(f"获取缓存大小失败: {e}")
            return 0

    @override
    def get_meta(self, key: str) -> MetaInfo | None:
        """获取缓存元数据

        Args:
            key: 缓存键（格式：cache_name:second_name:actual_key 或 actual_key）

        Returns:
            MetaInfo 对象，不存在则返回 None
        """
        try:
            # 计算 hash
            hash_value = self._hash_key(key)

            with Session(self._get_engine()) as session:
                return self._get_meta_from_db(
                    session,
                    self.name,
                    self._second_name,
                    hash_value,
                )

        except Exception as e:
            logger.error(f"获取元数据失败: {e}")
            return None

    def _get_meta_from_db(
        self,
        session: Session,
        cache_name: str,
        second_name: str,
        hash_value: str,
    ) -> MetaInfo | None:
        """从数据库获取元数据

        Args:
            session: SQLAlchemy Session
            cache_name: 缓存名称
            second_name: 二级名称
            hash_value: 哈希值

        Returns:
            MetaInfo 对象，不存在则返回 None
        """
        record = (
            session.query(CacheMetaModel)
            .filter(
                CacheMetaModel.cache_name == cache_name,
                CacheMetaModel.second_name == second_name,
                CacheMetaModel.hash_value == hash_value,
            )
            .first()
        )

        if record is None:
            return None

        meta = MetaInfo()
        meta.create_at = record.create_at
        meta.last_update_at = record.last_update_at
        meta.last_accessed_at = record.last_accessed_at
        meta.access_count = record.access_count
        meta.time_to_live = record.time_to_live
        meta.extra_params = {
            "row_count": record.row_count,
            "column_count": record.column_count,
        }
        if record.extra_params:
            # 将 extra_params 中的内容直接合并到根节点
            custom_data = pickle.loads(record.extra_params)
            meta.extra_params.update(custom_data)

        return meta

    def _update_meta_in_db(
        self,
        session: Session,
        meta: MetaInfo,
        cache_name: str,
        second_name: str,
        hash_value: str,
    ) -> None:
        """更新数据库中的元数据

        Args:
            session: SQLAlchemy Session
            meta: MetaInfo 对象
            cache_name: 缓存名称
            second_name: 二级名称
            hash_value: 哈希值
        """
        _ = (
            session.query(CacheMetaModel)
            .filter(
                CacheMetaModel.cache_name == cache_name,
                CacheMetaModel.second_name == second_name,
                CacheMetaModel.hash_value == hash_value,
            )
            .update(
                {
                    CacheMetaModel.last_accessed_at: meta.last_accessed_at,
                    CacheMetaModel.access_count: meta.access_count,
                }
            )
        )
        session.commit()

    def _upsert_meta(
        self,
        session: Session,
        meta: MetaInfo,
        cache_name: str,
        second_name: str,
        hash_value: str,
        table_name: str,
    ) -> None:
        """插入或更新元数据

        Args:
            session: SQLAlchemy Session
            meta: MetaInfo 对象
            cache_name: 缓存名称
            second_name: 二级名称
            hash_value: 哈希值
            table_name: 表名
        """

        # 提取 row_count 和 column_count
        row_count_value: object = (
            meta.extra_params.get("row_count", 0) if meta.extra_params else 0
        )
        column_count_value: object = (
            meta.extra_params.get("column_count", 0) if meta.extra_params else 0
        )
        row_count: int = (
            int(row_count_value) if isinstance(row_count_value, (int, float)) else 0
        )
        column_count: int = (
            int(column_count_value)
            if isinstance(column_count_value, (int, float))
            else 0
        )

        # 将 extra_params 转为 pickle 二进制
        extra_params_bytes: bytes | None = None
        if meta.extra_params and "custom" in meta.extra_params:
            extra_params_bytes = pickle.dumps(meta.extra_params["custom"])

        # 查询现有记录
        record = (
            session.query(CacheMetaModel)
            .filter(
                CacheMetaModel.cache_name == cache_name,
                CacheMetaModel.second_name == second_name,
                CacheMetaModel.hash_value == hash_value,
            )
            .first()
        )

        if record:
            # 更新现有记录
            record.table_name = table_name
            record.create_at = int(meta.create_at)
            record.last_update_at = int(meta.last_update_at)
            record.last_accessed_at = int(meta.last_accessed_at)
            record.access_count = meta.access_count
            record.time_to_live = int(meta.time_to_live)
            record.row_count = row_count
            record.column_count = column_count
            record.extra_params = extra_params_bytes
        else:
            # 插入新记录
            new_record = CacheMetaModel(
                cache_name=cache_name,
                second_name=second_name,
                hash_value=hash_value,
                table_name=table_name,
                create_at=int(meta.create_at),
                last_update_at=int(meta.last_update_at),
                last_accessed_at=int(meta.last_accessed_at),
                access_count=meta.access_count,
                time_to_live=meta.time_to_live,
                row_count=row_count,
                column_count=column_count,
                extra_params=extra_params_bytes,
            )
            session.add(new_record)
        session.commit()

    def _clean_expired_keys(self) -> int:
        """清理 TTL 过期的 key

        Returns:
            清理的键数量
        """
        try:
            import time as time_module

            current_time: int = int(time_module.time())

            with Session(self._get_engine()) as session:
                # 查询过期的缓存
                expired_records = (
                    session.query(CacheMetaModel)
                    .filter(
                        CacheMetaModel.cache_name == self.name,
                        CacheMetaModel.time_to_live > 0,
                        (CacheMetaModel.last_update_at + CacheMetaModel.time_to_live)
                        < current_time,
                    )
                    .all()
                )

                count = 0

                # 删除过期的缓存
                for record in expired_records:
                    # 删除缓存表
                    self._drop_cache_table(session.connection(), record.table_name)

                    # 删除元数据
                    session.delete(record)
                    count += 1

                session.commit()
                return count

        except Exception as e:
            logger.error(f"清理过期缓存失败: {e}")
            return 0

    def _is_expired(self, meta: MetaInfo) -> bool:
        """检查缓存是否过期

        Args:
            meta: 缓存元数据

        Returns:
            是否过期
        """
        if meta.time_to_live <= 0:
            return False

        import time as time_module

        current_time = time_module.time()
        return current_time - meta.last_update_at > meta.time_to_live

    def _clean(self) -> None:
        """自动清理

        清理过期缓存
        """
        _ = self._clean_expired_keys()
