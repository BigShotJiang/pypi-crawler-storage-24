from enum import Enum, auto
import inspect
import types
from typing import Any, Callable


class MethodType(Enum):
    # 模块内定义的方法
    MODULE_FUNCTION = auto()
    # 静态方法
    STATIC_FUNCTION = auto()
    # 类方法
    CLASS_FUNCTION = auto()
    # 实例方法
    INSTANCE_FUNCTION = auto()
    # lambda方法
    LAMBDA_FUNCTION = auto()


type CheckerFun = Callable[..., Any]


class MethodTypeChecker:
    """方法类型检查器"""

    @staticmethod
    def _is_lambda_function(callable_obj: CheckerFun) -> bool:
        """判断是否是lambda函数"""
        return hasattr(callable_obj, "__name__") and callable_obj.__name__ == "<lambda>"

    @staticmethod
    def _is_decorated_method(callable_obj: CheckerFun) -> tuple[bool, str | None]:
        """判断是否是装饰器方法（直接从类获取时）"""
        # 直接检查对象类型
        if isinstance(callable_obj, staticmethod):
            return True, "static"

        if isinstance(callable_obj, classmethod):
            return True, "class"

        # 对于通过类访问的方法，需要检查类字典中的原始装饰器
        if inspect.isfunction(callable_obj):
            qualname = getattr(callable_obj, "__qualname__", "")
            if "." in qualname:
                class_name = qualname.split(".")[0]
                module = inspect.getmodule(callable_obj)
                if module:
                    try:
                        cls = getattr(module, class_name, None)
                        if inspect.isclass(cls):
                            # 检查类字典中的原始属性
                            original_attr = cls.__dict__.get(callable_obj.__name__)
                            if isinstance(original_attr, staticmethod):
                                return True, "static"
                            if isinstance(original_attr, classmethod):
                                return True, "class"
                    except (AttributeError, TypeError):
                        pass

        return False, None

    @staticmethod
    def _is_staticmethod_via_class(callable_obj: CheckerFun, owner_class: Any = None) -> bool:
        """通过类检查是否是静态方法"""
        if not inspect.isfunction(callable_obj):
            return False

        # 如果有owner_class，直接检查
        if owner_class and inspect.isclass(owner_class):
            try:
                # 获取类属性
                attr = getattr(owner_class, callable_obj.__name__, None)
                if isinstance(attr, staticmethod):
                    return True
            except (AttributeError, TypeError):
                pass

        # 尝试通过限定名查找类
        qualname = getattr(callable_obj, "__qualname__", "")
        if "." in qualname:
            class_name = qualname.split(".")[0]
            module = inspect.getmodule(callable_obj)
            if module:
                try:
                    cls = getattr(module, class_name, None)
                    if inspect.isclass(cls):
                        attr = getattr(cls, callable_obj.__name__, None)
                        if isinstance(attr, staticmethod):
                            return True
                except (AttributeError, TypeError):
                    pass

        return False

    @staticmethod
    def _is_classmethod_via_class(callable_obj: CheckerFun, owner_class: Any = None) -> bool:
        """通过类检查是否是类方法"""
        if not inspect.isfunction(callable_obj):
            return False

        # 如果有owner_class，直接检查
        if owner_class and inspect.isclass(owner_class):
            try:
                attr = getattr(owner_class, callable_obj.__name__, None)
                if isinstance(attr, classmethod):
                    return True
            except (AttributeError, TypeError):
                pass

        # 尝试通过限定名查找类
        qualname = getattr(callable_obj, "__qualname__", "")
        if "." in qualname:
            class_name = qualname.split(".")[0]
            module = inspect.getmodule(callable_obj)
            if module:
                try:
                    cls = getattr(module, class_name, None)
                    if inspect.isclass(cls):
                        attr = getattr(cls, callable_obj.__name__, None)
                        if isinstance(attr, classmethod):
                            return True
                except (AttributeError, TypeError):
                    pass

        return False

    @staticmethod
    def _is_bound_method(callable_obj: CheckerFun) -> tuple[bool, str | None]:
        """判断是否是绑定方法"""
        if not inspect.ismethod(callable_obj):
            return False, None

        if not hasattr(callable_obj, "__self__"):
            return True, None

        if isinstance(callable_obj.__self__, type):
            return True, "class"
        else:
            return True, "instance"

    @staticmethod
    def _is_module_function(callable_obj: CheckerFun, owner: Any = None) -> bool:
        """判断是否是模块函数"""
        if not inspect.isfunction(callable_obj):
            return False

        # 如果是通过装饰器获取的，直接返回False
        if isinstance(callable_obj, (staticmethod, classmethod)): # type: ignore
            return False

        qualname = getattr(callable_obj, "__qualname__", "")

        # 模块函数的限定名不应包含点号
        if "." in qualname or qualname == "<lambda>":
            return False

        # 如果有owner，检查是否真的在owner中
        if owner is not None:
            if inspect.ismodule(owner):
                try:
                    # 检查函数是否真的在这个模块中
                    if hasattr(owner, callable_obj.__name__):
                        attr = getattr(owner, callable_obj.__name__)
                        if attr is callable_obj:
                            return True
                except (AttributeError, TypeError):
                    pass
            return False

        # 检查是否在全局作用域
        module = inspect.getmodule(callable_obj)
        if module is None:
            return False

        # 确保不是类中的方法
        try:
            # 检查是否在类的字典中
            for _, cls_obj in module.__dict__.items():
                if inspect.isclass(cls_obj) and hasattr(cls_obj, qualname):
                    if getattr(cls_obj, qualname, None) is callable_obj:
                        return False
        except:
            pass

        return True

    @staticmethod
    def _is_instance_method_in_class(callable_obj: CheckerFun, owner_class: Any = None) -> bool:
        """判断是否是类中的实例方法"""
        if not inspect.isfunction(callable_obj):
            return False

        # 排除静态方法和类方法
        if MethodTypeChecker._is_staticmethod_via_class(callable_obj, owner_class):
            return False

        if MethodTypeChecker._is_classmethod_via_class(callable_obj, owner_class):
            return False

        qualname = getattr(callable_obj, "__qualname__", "")
        if "." not in qualname:
            return False

        # 提取类名
        parts = qualname.split(".")
        if len(parts) < 2:
            return False

        class_name = parts[0]
        method_name = parts[-1]

        # 查找类
        module = inspect.getmodule(callable_obj)
        if module is None:
            return False

        try:
            cls = getattr(module, class_name, None)
            if not inspect.isclass(cls):
                return False

            # 获取类中的方法
            class_method = getattr(cls, method_name, None)
            if class_method is not callable_obj:
                return False

            # 检查参数列表
            sig = inspect.signature(callable_obj)
            params = list(sig.parameters.keys())

            # 如果有self参数，是实例方法
            if params and params[0] == "self":
                return True
        except (AttributeError, TypeError, ValueError):
            pass

        return False

    @staticmethod
    def _is_builtin_or_descriptor(callable_obj: CheckerFun) -> tuple[bool, str | None]:
        """判断是否是内置函数或方法描述符"""
        if isinstance(callable_obj, types.BuiltinFunctionType):
            return True, "builtin"

        if inspect.ismethoddescriptor(callable_obj):
            return True, "descriptor"

        return False, None

    @staticmethod
    def _check_by_signature(callable_obj: CheckerFun) -> bool:
        """通过函数签名判断"""
        if not inspect.isfunction(callable_obj):
            return False

        try:
            sig = inspect.signature(callable_obj)
            params = list(sig.parameters.keys())

            if params and params[0] == "self":
                return True
        except (ValueError, TypeError):
            pass

        return False

    @classmethod
    def get_method_type(cls, callable_obj: CheckerFun, owner: Any = None) -> MethodType:
        """
        根据MethodType枚举判断可调用对象的类型

        Args:
            callable_obj: 要检查的可调用对象
            owner: 可选的拥有者（用于更精确判断模块函数）

        Returns:
            MethodType: 方法类型枚举值
        """
        # 1. 检查lambda函数
        if cls._is_lambda_function(callable_obj):
            return MethodType.LAMBDA_FUNCTION

        # 2. 检查装饰器方法（直接从类获取时）
        is_decorated, decorator_type = cls._is_decorated_method(callable_obj)
        if is_decorated:
            if decorator_type == "static":
                return MethodType.STATIC_FUNCTION
            else:
                return MethodType.CLASS_FUNCTION

        # 3. 检查绑定方法
        is_bound, bound_type = cls._is_bound_method(callable_obj)
        if is_bound:
            if bound_type == "class":
                return MethodType.CLASS_FUNCTION
            else:
                # 实例访问的绑定方法需要进一步检查是否是静态方法
                if cls._is_staticmethod_via_class(callable_obj):
                    return MethodType.STATIC_FUNCTION
                return MethodType.INSTANCE_FUNCTION

        # 4. 检查静态方法（通过类获取时）
        if cls._is_staticmethod_via_class(callable_obj, owner if inspect.isclass(owner) else None):
            return MethodType.STATIC_FUNCTION

        # 5. 检查类方法（通过类获取时）
        if cls._is_classmethod_via_class(callable_obj, owner if inspect.isclass(owner) else None):
            return MethodType.CLASS_FUNCTION

        # 6. 检查模块函数
        if cls._is_module_function(callable_obj, owner):
            return MethodType.MODULE_FUNCTION

        # 7. 检查类中的实例方法
        if cls._is_instance_method_in_class(callable_obj, owner if inspect.isclass(owner) else None):
            return MethodType.INSTANCE_FUNCTION

        # 8. 检查内置函数和方法描述符
        is_special, special_type = cls._is_builtin_or_descriptor(callable_obj)
        if is_special:
            if special_type == "builtin":
                # 内置函数视为模块函数
                return MethodType.MODULE_FUNCTION
            else:
                # 方法描述符视为实例方法
                return MethodType.INSTANCE_FUNCTION

        # 9. 通过函数签名判断
        if cls._check_by_signature(callable_obj):
            return MethodType.INSTANCE_FUNCTION

        # 10. 默认返回实例方法
        return MethodType.INSTANCE_FUNCTION

    @classmethod
    def get_method_info(cls, callable_obj: CheckerFun, owner: Any = None):
        """
        获取方法的完整信息

        Returns:
            dict: 包含方法类型和详细信息的字典
        """
        method_type = cls.get_method_type(callable_obj, owner)

        info: dict[str, Any] = {
            "type": method_type,
            "type_name": method_type.name,
            "name": getattr(callable_obj, "__name__", str(callable_obj)),
            "qualname": getattr(callable_obj, "__qualname__", ""),
            "module": getattr(callable_obj, "__module__", None),
        }

        # 添加绑定信息
        is_bound, bound_type = cls._is_bound_method(callable_obj)
        info["is_bound"] = is_bound
        if is_bound and bound_type:
            info["bound_type"] = bound_type
            if hasattr(callable_obj, "__self__"):
                info["bound_to"] = (
                    callable_obj.__self__.__name__  # type: ignore
                    if hasattr(callable_obj.__self__, "__name__")  # type: ignore
                    else str(callable_obj.__self__)  # type: ignore
                )

        # 获取装饰器信息
        is_decorated, decorator_type = cls._is_decorated_method(callable_obj)
        info["is_decorated"] = is_decorated
        if is_decorated:
            info["decorator_type"] = decorator_type

        # 获取函数签名
        try:
            if inspect.isfunction(callable_obj) or inspect.ismethod(callable_obj):
                sig = inspect.signature(callable_obj)
                info["signature"] = str(sig)
                info["parameters"] = list(sig.parameters.keys())
        except (ValueError, TypeError):
            info["signature"] = None
            info["parameters"] = []

        return info


# 简化后的主函数
def get_method_type(callable_obj: CheckerFun, owner: Any = None) -> MethodType:
    """获取方法类型（简化接口）"""
    return MethodTypeChecker.get_method_type(callable_obj, owner)


def get_method_info(callable_obj: CheckerFun, owner: Any = None) -> dict[str, Any]:
    """获取方法信息（简化接口）"""
    return MethodTypeChecker.get_method_info(callable_obj, owner)
