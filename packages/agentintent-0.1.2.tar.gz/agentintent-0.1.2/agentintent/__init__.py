"""
AgentIntent - Trust Infrastructure for AI Agents

AI Should Do What It Says. We Make Sure It Does.

Usage:
    from agentintent import AgentIntent, IntentManifest
    
    # Quick start with LangChain
    from agentintent import AgentIntentCallback
    agent = AgentExecutor(..., callbacks=[AgentIntentCallback("ai_xxx")])
    
    # Or use the universal monitor
    from agentintent import monitor
    monitored_agent = monitor(your_agent, api_key="ai_xxx")
"""

__version__ = "0.1.2"

from .core import AgentIntent
from .manifest import IntentManifest
from .actions import Action, ActionType
from .callback import AgentIntentCallback
from .wrapper import monitor, track

__all__ = [
    "AgentIntent",
    "IntentManifest", 
    "Action",
    "ActionType",
    "AgentIntentCallback",
    "monitor",
    "track",
]
