# Copyright (c) 2024 Richmond Alake. All rights reserved.
# Licensed under the PolyForm Noncommercial License 1.0.0.
# See LICENSE file in the project root for full license information.

from .shared_memory.shared_memory import SharedMemory

__all__ = ["SharedMemory"]
