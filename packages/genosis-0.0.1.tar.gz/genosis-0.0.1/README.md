# genosis

Official Python SDK for the Genosis LLM cost optimization platform.

Coming soon. Visit [usegenosis.ai](https://usegenosis.ai) for more information.
