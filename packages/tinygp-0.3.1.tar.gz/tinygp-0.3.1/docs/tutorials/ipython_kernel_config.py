c.InlineBackend.rc = {}  # noqa
