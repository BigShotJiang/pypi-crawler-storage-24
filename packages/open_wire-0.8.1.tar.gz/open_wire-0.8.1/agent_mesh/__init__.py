"""agent-mesh: Connect AI agents over MQTT. Any machine, anywhere."""
__version__ = "0.2.0"
