"""CLI: just run `open-wire`"""
import json, os, subprocess, threading, uuid, sys, signal, random, datetime, glob, time
import urllib.request
import paho.mqtt.client as mqtt

HOME = os.path.expanduser("~/.open-wire")
LOGFILE = os.path.join(HOME, "wire.log")
BROKER_PIDFILE = os.path.join(HOME, "broker.pid")
TOPIC = "open-wire/world"
BROKER = "localhost"

SYSTEM = ("You are [{me}], an AI agent. "
          "Persona: {persona} "
          "You have full access to this computer. "
          "Your workspace is {workspace} — use it however you want. "
          "You figure out your own memory, your own organization. No rules. "
          "Other agents may appear. Interact freely.")


def _log(line):
    os.makedirs(HOME, exist_ok=True)
    with open(LOGFILE, "a") as f:
        ts = datetime.datetime.now().strftime("%H:%M:%S")
        f.write(f"[{ts}] {line}\n")


def _fetch_persona():
    try:
        offset = random.randint(0, 999_999)
        url = (f"https://datasets-server.huggingface.co/rows?"
               f"dataset=nvidia/Nemotron-Personas-USA&config=default"
               f"&split=train&offset={offset}&length=1")
        req = urllib.request.urlopen(url, timeout=15)
        data = json.loads(req.read())
        return data["rows"][0]["row"]["persona"]
    except Exception:
        return "a curious mind ready to explore"


def _claude(prompt, system=None):
    cmd = ["claude", "-p", prompt, "--output-format", "text"]
    if os.geteuid() != 0:
        cmd.append("--dangerously-skip-permissions")
    if system:
        cmd.extend(["--system-prompt", system])
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        if r.returncode == 0 and r.stdout.strip():
            return r.stdout.strip()
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    return None


# --- broker management ---

def _ensure_broker():
    if os.path.exists(BROKER_PIDFILE):
        try:
            pid = int(open(BROKER_PIDFILE).read().strip())
            os.kill(pid, 0)
            return
        except (ProcessLookupError, ValueError, PermissionError):
            try:
                os.remove(BROKER_PIDFILE)
            except FileNotFoundError:
                pass

    if not any(os.path.isfile(os.path.join(d, "mosquitto"))
               for d in os.environ.get("PATH", "").split(":")):
        print("mosquitto not found. Install it:")
        print("  Ubuntu/Debian: sudo apt install mosquitto")
        print("  macOS:         brew install mosquitto")
        sys.exit(1)

    conf = os.path.join(HOME, "mosquitto.conf")
    with open(conf, "w") as f:
        f.write("listener 1883 127.0.0.1\nallow_anonymous true\n")

    proc = subprocess.Popen(["mosquitto", "-c", conf],
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    with open(BROKER_PIDFILE, "w") as f:
        f.write(str(proc.pid))
    _log(f"broker started (pid {proc.pid})")
    time.sleep(0.5)


def _stop_broker():
    if not os.path.exists(BROKER_PIDFILE):
        return
    try:
        pid = int(open(BROKER_PIDFILE).read().strip())
        os.kill(pid, signal.SIGTERM)
        _log(f"broker stopped (pid {pid})")
    except (ProcessLookupError, ValueError):
        pass
    try:
        os.remove(BROKER_PIDFILE)
    except FileNotFoundError:
        pass


# --- agent pid management ---

def _is_open_wire_process(pid):
    try:
        with open(f"/proc/{pid}/cmdline", "rb") as f:
            cmdline = f.read().decode("utf-8", errors="replace")
        return "open-wire" in cmdline or "agent_mesh" in cmdline
    except (FileNotFoundError, PermissionError):
        return False


def _clean_stale_pids():
    for pidfile in glob.glob(os.path.join(HOME, "*.pid")):
        if pidfile == BROKER_PIDFILE:
            continue
        try:
            pid = int(open(pidfile).read().strip())
            os.kill(pid, 0)
        except (ProcessLookupError, ValueError, PermissionError):
            try:
                os.remove(pidfile)
            except FileNotFoundError:
                pass


def _stop_agents():
    for pidfile in glob.glob(os.path.join(HOME, "*.pid")):
        if pidfile == BROKER_PIDFILE:
            continue
        try:
            pid = int(open(pidfile).read().strip())
            if not _is_open_wire_process(pid):
                _log(f"skipped pid {pid} (not open-wire)")
                os.remove(pidfile)
                continue
            os.kill(pid, signal.SIGTERM)
            _log(f"stopped agent (pid {pid})")
        except (ProcessLookupError, ValueError):
            pass
        try:
            os.remove(pidfile)
        except FileNotFoundError:
            pass


def _stop_all():
    _stop_agents()
    _stop_broker()


# --- main ---

def main():
    os.makedirs(HOME, exist_ok=True)
    _clean_stale_pids()

    if "--stop" in sys.argv:
        _stop_all()
        print("Stopped all agents and broker.")
        return

    if "--log" in sys.argv:
        if not os.path.exists(LOGFILE):
            open(LOGFILE, "w").close()
        os.execvp("tail", ["tail", "-f", LOGFILE])

    # optional instruction from positional args
    instruction = " ".join(a for a in sys.argv[1:] if not a.startswith("--"))
    instruction = instruction.strip() or None

    _ensure_broker()

    me = uuid.uuid4().hex[:6]
    workspace = os.path.join(HOME, me)
    os.makedirs(workspace, exist_ok=True)

    persona = _fetch_persona()
    _log(f"[{me}] {persona[:100]}")
    if instruction:
        _log(f"[{me}] instruction: {instruction}")

    pid = os.fork()
    if pid > 0:
        sys.stdout.write(f"[{me}] born in background (pid {pid})\n")
        sys.stdout.write(f"persona: {persona[:120]}...\n")
        if instruction:
            sys.stdout.write(f"instruction: {instruction}\n")
        sys.stdout.write(f"\nopen-wire              spawn another agent\n")
        sys.stdout.write(f"open-wire --log        follow the conversation\n")
        sys.stdout.write(f"open-wire --stop       stop everything\n")
        sys.stdout.flush()
        os._exit(0)

    os.setsid()
    devnull = os.open(os.devnull, os.O_RDWR)
    os.dup2(devnull, 0)
    os.dup2(devnull, 1)
    os.dup2(devnull, 2)
    os.close(devnull)

    try:
        _daemon(me, workspace, persona, instruction)
    except Exception as e:
        _log(f"[{me}] crashed: {e}")
        os._exit(1)


def _daemon(me, workspace, persona, instruction=None):
    with open(os.path.join(HOME, f"{me}.pid"), "w") as f:
        f.write(str(os.getpid()))

    sys_prompt = (SYSTEM.replace("{me}", me)
                  .replace("{workspace}", workspace)
                  .replace("{persona}", persona))

    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)

    def _birth(c):
        prompt = instruction or "You just came online. Introduce yourself in character."
        first = _claude(prompt, system=sys_prompt)
        if first:
            _log(f"[{me}]: {first}")
            c.publish(TOPIC, json.dumps({"from": me, "msg": first}))

    def on_connect(c, *a):
        c.subscribe(TOPIC)
        _log(f"[{me}] connected")
        threading.Thread(target=_birth, args=(c,), daemon=True).start()

    def on_message(c, u, msg):
        try:
            data = json.loads(msg.payload.decode())
        except json.JSONDecodeError:
            return
        if data["from"] == me:
            return

        if data["msg"] == "__shutdown__":
            _log(f"[{me}] shutdown")
            try:
                os.remove(os.path.join(HOME, f"{me}.pid"))
            except FileNotFoundError:
                pass
            client.disconnect()
            os._exit(0)

        sender, text = data["from"], data["msg"]
        _log(f"{sender} -> {me}: {text}")

        def respond():
            reply = _claude(f"[{sender}]: {text}", system=sys_prompt)
            if reply:
                _log(f"[{me}]: {reply}")
                c.publish(TOPIC, json.dumps({"from": me, "msg": reply}))
        threading.Thread(target=respond, daemon=True).start()

    def handle_signal(*_):
        _log(f"[{me}] shutting down")
        try:
            os.remove(os.path.join(HOME, f"{me}.pid"))
        except FileNotFoundError:
            pass
        client.disconnect()
        os._exit(0)

    signal.signal(signal.SIGTERM, handle_signal)
    signal.signal(signal.SIGINT, handle_signal)

    client.on_connect = on_connect
    client.on_message = on_message
    client.connect(BROKER, 1883)
    client.loop_forever()
