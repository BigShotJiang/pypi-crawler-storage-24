from agent_mesh.cli import main
main()
