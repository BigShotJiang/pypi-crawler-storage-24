import json
import os
import subprocess
import paho.mqtt.client as mqtt

DEFAULT_BROKER = "localhost"
DEFAULT_TOPIC = "agent-mesh/default"


class Agent:
    def __init__(self, name: str, role: str = "", topic: str = DEFAULT_TOPIC, broker: str = DEFAULT_BROKER):
        self.name = name
        self.role = role
        self.topic = topic
        self.client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
        self.client.on_connect = self._on_connect
        self.client.on_message = self._on_message
        self.client.connect(broker, 1883)
        self.client.loop_start()

    def _on_connect(self, client, userdata, flags, rc, properties=None):
        self.client.subscribe(self.topic)
        self.say(f"[joined] I'm {self.name}. Role: {self.role or 'general'}")

    def _on_message(self, client, userdata, msg):
        try:
            data = json.loads(msg.payload.decode())
        except json.JSONDecodeError:
            return
        if data.get("from") == self.name:
            return

        sender = data.get("from", "?")
        text = data.get("msg", "")

        reply = self._think(text, sender)
        self.say(reply)

    def say(self, text: str):
        self.client.publish(self.topic, json.dumps({"from": self.name, "msg": text}))

    def _think(self, text: str, sender: str) -> str:
        system = f"You are {self.name} ({self.role or 'assistant'})"
        prompt = f"[{sender}]: {text}"
        try:
            r = subprocess.run(["claude", "-p", prompt, "--output-format", "text",
                                "--system-prompt", system],
                               capture_output=True, text=True, timeout=120)
            if r.returncode == 0 and r.stdout.strip():
                return r.stdout.strip()
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass
        return f"(heard you, but claude CLI unavailable)"

    def stop(self):
        self.client.loop_stop()
        self.client.disconnect()
