# `mubit-adk`

Google ADK `BaseMemoryService` backed by [MuBit](https://mubit.ai).

This adapter now uses the canonical Python SDK transport internally instead of raw `httpx`, while preserving the ADK memory-service contract and adding MuBit-specific helpers for checkpointing, observability, and multi-agent coordination.

## Install

```bash
pip install mubit-adk[adk]
```

## Basic usage

```python
from mubit_adk import MubitMemoryService

memory = MubitMemoryService(
    endpoint="http://127.0.0.1:3000",
    api_key="mbt_...",
)

await memory.add_session_to_memory(session)

response = await memory.search_memory(
    app_name="deploy-agent",
    user_id="user-1",
    query="What rollout guidance do we have?",
)
```

## ADK to MuBit mapping

| ADK concept | MuBit mapping |
| --- | --- |
| `app_name` | `agent_id` |
| `user_id` | `user_id` |
| `session.id` | `run_id` |
| session/event ingest | control ingest items |
| `search_memory()` | control query |

## MuBit extension methods

Existing MAS helpers:

- `checkpoint()`
- `record_outcome()`
- `surface_strategies()`

Current observability and coordination helpers:

- `get_context()`
- `memory_health()`
- `diagnose()`
- `archive()`
- `dereference()`
- `register_agent()`
- `list_agents()`
- `handoff()`
- `feedback()`

## Config

| Parameter | Default | Purpose |
| --- | --- | --- |
| `endpoint` | `http://127.0.0.1:3000` | MuBit HTTP endpoint |
| `api_key` | `""` | MuBit API key |

For tests or advanced embedding, you can inject `mubit_client` directly.

## Development

```bash
PYTHONPATH=sdk/python/mubit-sdk/src:integrations/python \
python3 -m unittest integrations.python.mubit_adk.tests.test_memory_service -v
```

## License

Apache-2.0
