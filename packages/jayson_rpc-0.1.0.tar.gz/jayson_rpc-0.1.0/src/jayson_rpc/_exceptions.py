class JsonRpcException(Exception):
    def __init__(self, message: str, code: int):
        super().__init__(message)
        self.message = message
        self.code = code

    @classmethod
    def from_error(cls, error: dict) -> "JsonRpcException":
        """Creates a JsonRpcException from a JSON-RPC error object."""
        return cls(error.get("message", "error"), error.get("code", -32000)).to_typed()

    def to_typed(self) -> "JsonRpcException":
        cls = CODE_TO_EXCEPTION.get(self.code)
        if cls is None:
            return self
        exc = Exception.__new__(cls)
        JsonRpcException.__init__(exc, self.message, self.code)
        return exc

    def to_json_rpc_error(self):
        """Converts this exception to a JSON-RPC error object."""
        return {"code": self.code, "message": str(self)}


class ParseErrorException(JsonRpcException):
    def __init__(self, message: str = "Error parsing JSON-RPC message"):
        super().__init__(message, -32700)


class InvalidRequestException(JsonRpcException):
    def __init__(self, message: str = "Invalid JSON-RPC message"):
        super().__init__(message, -32600)


class MethodNotFoundException(JsonRpcException):
    def __init__(self, method: str):
        super().__init__(f"Method not found: {method}", -32601)


class InvalidParamsException(JsonRpcException):
    def __init__(self, message: str = "Invalid params"):
        super().__init__(message, -32602)


class InternalErrorException(JsonRpcException):
    def __init__(self, message: str):
        super().__init__(message, -32603)


class ServerErrorException(JsonRpcException):
    def __init__(self, message: str):
        super().__init__(message, -32000)

CODE_TO_EXCEPTION = {
    -32700: ParseErrorException,
    -32600: InvalidRequestException,
    -32601: MethodNotFoundException,
    -32602: InvalidParamsException,
    -32603: InternalErrorException,
    -32000: ServerErrorException,
}

__all__ = [
    "JsonRpcException",
    "ParseErrorException",
    "InvalidRequestException",
    "MethodNotFoundException",
    "InvalidParamsException",
    "InternalErrorException",
    "ServerErrorException"
]
