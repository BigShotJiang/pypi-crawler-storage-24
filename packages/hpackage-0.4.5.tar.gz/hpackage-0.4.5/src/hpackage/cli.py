import sys

from . import core


def main():
    if sys.version_info < (3, 9):
        sys.exit("Error: Python 3.9+ is required.")
    return core.handle_command_line(core.App())
