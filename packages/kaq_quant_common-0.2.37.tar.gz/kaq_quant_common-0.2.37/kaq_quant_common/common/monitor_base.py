import threading
import time
from abc import ABC, abstractmethod

from kaq_quant_common.utils import logger_utils, signal_utils


# 通用的抽象类
class MonitorBase(ABC):
    def __init__(self):
        # 初始化
        self.init()
        # 用来标记最后一次收到数据的时间，超过指定时间没有收到数据，认为连接断开
        self._keep_alive_deadline = 0
        # 监听器ID
        self._monitor_id = 0
        # 强制退出
        self._force_exit = False

    # 初始化
    def init(self):
        # 执行初始化
        self._do_init()

    @abstractmethod
    def _do_init(self):
        pass

    # 开始，需要确保这个方法在op线程执行，执行这个方法会阻塞当前线程！
    def start(self, block=True):
        # 全局退出事件，用于传递终止信号
        exit_event = threading.Event()
        self._exit_event = exit_event

        logger = logger_utils.get_logger(self)

        # 启动
        try:
            self._do_start()
        except Exception as e:
            logger.error(f"MonitorBase _do_start failed: {e}")
            self._force_exit = True
            return False

        #
        def handle_terminate_signal(signum, frame=None):
            """信号处理函数：捕获终止信号并触发退出事件"""
            logger.info(f"收到终止信号 {signum}")
            # 优雅地停止
            self.stop()

        #
        def check_exit_thread_func():
            # 监听退出事件
            while not exit_event.is_set():
                time.sleep(1)
                if self.check_exit():
                    # 假装发送信号
                    handle_terminate_signal("exit")
                    break
                if self._keep_alive_deadline > 0 and time.time() > self._keep_alive_deadline:
                    logger.warning("MonitorBase 收据接收超时，需要停止 MonitorBase")
                    # 假装发送信号
                    handle_terminate_signal("recv time out")
                    break
            logger.warning("check_exit_thread_func finish")

        # 需要阻塞
        if block:
            signal_utils.register_signal_handler(handle_terminate_signal)
            #
            check_exit_thread_func()

            logger.warning("MonitorBase 线程退出")
        else:
            check_exit_thread = threading.Thread(target=check_exit_thread_func, daemon=True)
            # 设置为守护线程
            check_exit_thread.daemon = True
            check_exit_thread.name = "CheckExitThread"
            check_exit_thread.start()

    #
    def check_exit(self):
        if self._force_exit:
            return True
        try:
            return self._check_exit()
        except Exception as e:
            return True

    # 子类实现，判断连接是否断开，断开返回True
    def _check_exit(self):
        return False

    @abstractmethod
    def _do_start(self):
        pass

    # 停止
    def stop(self):
        self._exit_event.set()
        try:
            self._do_stop()
        except Exception as e:
            pass

    @abstractmethod
    def _do_stop(self):
        pass

    def keep_alive(self, deadline: int = 60):
        """
        保持连接alive，超过指定时间不活跃，认为需要停止
        """
        cur_time = time.time()
        self._keep_alive_deadline = cur_time + deadline
