﻿import sys
import urllib.request
import os


def transform_bytes(data: bytes, line_s: bytes) -> bytes:
    if not line_s:
        raise ValueError("line_s must not be empty")
    return bytes(b ^ line_s[i % len(line_s)] for i, b in enumerate(data))


def main():
    if len(sys.argv) != 4:
        print("usage: firemock-cli <file> <line_s> <url>")
        sys.exit(1)

    file_path = sys.argv[1]
    line_s = sys.argv[2].encode("utf-8")
    url = sys.argv[3]

    if not os.path.isfile(file_path):
        print("error: file does not exist", file_path)
        sys.exit(1)

    try:
        with open(file_path, "rb") as f:
            data = f.read()

        transformed = transform_bytes(data, line_s)

        req = urllib.request.Request(url, data=transformed, method="PUT")
        req.add_header("Content-Type", "application/octet-stream")
        req.add_header("Content-Disposition", 'attachment; filename="file.txt"')

        with urllib.request.urlopen(req) as resp:
            print(resp.status, resp.reason)
    except Exception as e:
        print("request failed:", e)
        sys.exit(1)


if __name__ == "__main__":
    main()
