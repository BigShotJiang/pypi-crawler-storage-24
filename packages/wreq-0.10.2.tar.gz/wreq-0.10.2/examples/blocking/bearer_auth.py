from wreq.blocking import Client


def main():
    client = Client()
    resp = client.get(
        "https://httpbin.io/anything",
        bearer_auth="token",
    )
    print(resp.text())


if __name__ == "__main__":
    main()
