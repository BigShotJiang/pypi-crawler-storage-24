"""Base client infrastructure for Function Apps.

This module provides the BaseFunctionClient class, which contains all shared
infrastructure for making HTTP calls to devservers and deployed Cognite Functions.
Both the dynamic FunctionClient and generated typed clients inherit from this base class.

The base class handles:
- Initialization for both devserver and deployed function modes
- HTTP calls via httpx (devserver) or the cognite SDK session (deployed)
- Session nonce creation via CogniteClient (deployed mode)
- Response unwrapping and error handling
- Deserialization of responses into Pydantic models
"""

import inspect
import re
import sys
from typing import Any, cast, overload
from urllib.parse import parse_qs, quote, urlencode, urlparse, urlunparse

from cognite.client import CogniteClient
from cognite.client.exceptions import CogniteException
from pydantic import BaseModel

from .models import CogniteFunctionError, CogniteFunctionResponse, FunctionCallEnvelope, HTTPMethod

# Optional OpenTelemetry support for trace propagation
try:
    from opentelemetry.propagate import inject as _otel_inject
except ImportError:

    def _otel_inject(*args: Any, **kwargs: Any) -> None:
        """No-op inject when OpenTelemetry not installed."""
        pass


class BaseFunctionClient:
    """Base class for Cognite Function App clients.

    Provides shared infrastructure for both dynamic and generated clients:
    - HTTP calling via httpx (devserver) or the cognite SDK session (deployed)
    - Session nonce creation via CogniteClient (deployed mode)
    - Response unwrapping and error handling
    - Model deserialization

    Supports two modes:
    1. Local devserver: Pass base_url only (e.g., 'http://localhost:8000')
    2. Deployed function: Pass cognite_client + function_external_id
    """

    base_url: str
    _project: str | None
    _function_external_id: str | None
    _cognite_client: CogniteClient | None
    _timeout: float

    @overload
    def __init__(self, *, base_url: str, timeout: float = ...) -> None: ...

    @overload
    def __init__(
        self,
        *,
        cognite_client: CogniteClient,
        function_external_id: str,
        timeout: float = ...,
    ) -> None: ...

    def __init__(
        self,
        *,
        base_url: str | None = None,
        function_external_id: str | None = None,
        cognite_client: CogniteClient | None = None,
        timeout: float = 600.0,
    ) -> None:
        """Initialize the client.

        Args:
            base_url: Devserver URL, e.g. 'http://localhost:8000'.
            function_external_id: External ID of the deployed function (required with cognite_client).
            cognite_client: A CogniteClient instance. When provided, base_url, project,
                and credentials are extracted automatically from the client's configuration.
            timeout: HTTP request timeout in seconds. Applied to all requests including
                session nonce creation. Defaults to 600.0 (10 minutes) to accommodate
                long-running functions.

        Raises:
            ValueError: If invalid parameter combination is provided.

        Example:
            # Local devserver
            client = BaseFunctionClient(base_url="http://localhost:8000")

            # Deployed function via CogniteClient
            from cognite.client import CogniteClient
            client = BaseFunctionClient(
                cognite_client=CogniteClient(...),
                function_external_id="my-function",
                timeout=120.0,
            )
        """
        if cognite_client is not None:
            if function_external_id is None:
                raise ValueError("function_external_id is required when cognite_client is provided")
            self.base_url = cognite_client.config.base_url.rstrip("/")
            self._project = cognite_client.config.project
            self._function_external_id = function_external_id
            self._cognite_client = cognite_client
        elif base_url is not None:
            self.base_url = base_url.rstrip("/")
            self._project = None
            self._function_external_id = None
            self._cognite_client = None
        else:
            raise ValueError(
                "Either base_url (devserver) or cognite_client + function_external_id (deployed) must be provided"
            )

        self._timeout = timeout

    def _get_token(self) -> str:
        """Get the current access token from the CogniteClient credentials.

        Returns:
            Access token string.

        Raises:
            RuntimeError: If no CogniteClient is configured.
            ValueError: If the authorization header format is unexpected.
        """
        if self._cognite_client is None:
            raise RuntimeError("No cognite_client configured")
        _, auth_value = self._cognite_client.config.credentials.authorization_header()
        if not auth_value.startswith("Bearer "):
            raise ValueError(f"Unexpected authorization header format. Expected 'Bearer <token>', got '{auth_value}'")
        return auth_value.removeprefix("Bearer ")

    def _create_session_nonce(self) -> str:
        """Create a session and return the nonce.

        Nonces are single-use -- a fresh one must be created before each API call.
        Delegates to the CogniteClient's session API so that token exchange, refresh,
        and interactive login are handled entirely by the SDK.

        Returns:
            Session nonce string.

        Raises:
            RuntimeError: If session creation fails.
        """
        if self._cognite_client is None:
            raise RuntimeError("No cognite_client configured")
        try:
            return self._cognite_client.iam.sessions.create().nonce
        except CogniteException as e:
            raise RuntimeError(f"Session creation failed: {e}") from e

    @staticmethod
    def _build_path_with_params(path: str, params: dict[str, Any]) -> str:
        """Merge query parameters into a path, handling existing query strings and fragments.

        Args:
            path: URL path, optionally containing an existing query string or fragment.
            params: Query parameters to add.

        Returns:
            Path with the parameters correctly merged into the query string.
        """
        parsed = urlparse(path)
        existing = parse_qs(parsed.query, keep_blank_values=True)
        # params values may be non-string; urlencode handles that
        merged = urlencode({**existing, **{k: [v] for k, v in params.items() if v is not None}}, doseq=True)
        return urlunparse(parsed._replace(query=merged))

    def _call_api(
        self,
        path: str,
        method: HTTPMethod,
        body: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> Any:
        """Call the real Function Apps API (deployed mode).

        All calls use POST /call with a FunctionCallRequest envelope.
        Creates a fresh session nonce for each call.

        Args:
            path: Endpoint path (e.g., '/items/123' or '/__schema__').
            method: HTTP method.
            body: Request body for POST/PUT/PATCH.
            params: Query parameters (embedded in path for the /call envelope).

        Returns:
            Response JSON from the API.

        Raises:
            CogniteAPIError: If the HTTP request fails.
            RuntimeError: If session creation fails.
        """
        if self._cognite_client is None:
            raise RuntimeError("CogniteClient is not configured.")
        nonce = self._create_session_nonce()

        project = quote(str(self._project), safe="")
        ext_id = quote(str(self._function_external_id), safe="")
        url_path = f"/api/v1/projects/{project}/function-apps/{ext_id}/call"

        full_path = self._build_path_with_params(path, params) if params else path
        envelope: dict[str, Any] = {
            "data": {
                "path": full_path,
                "method": method.value,
                "body": body or {},
            },
            "nonce": nonce,
        }

        headers: dict[str, str] = {}
        _otel_inject(headers)
        resp = self._cognite_client.post(url_path, json=envelope, headers=headers)

        if resp.status_code == 204:  # No Content — body is empty
            return None
        try:
            return resp.json()
        except ValueError as e:
            raise RuntimeError(f"Failed to decode JSON response: {e}") from e

    def _call_devserver(
        self,
        path: str,
        method: HTTPMethod,
        body: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> Any:
        """Call local devserver using httpx.

        Uses the same POST /call envelope format as the deployed API.

        Args:
            path: Path to call (e.g., "/items/123" or "/__schema__")
            method: HTTP method
            body: Request body
            params: Query parameters (embedded in path for the /call envelope)

        Returns:
            Raw response from HTTP call (wrapped Cognite Function response format)

        Raises:
            httpx.HTTPStatusError: If HTTP request fails
        """
        import httpx  # noqa: PLC0415 — lazy import: only needed in devserver mode

        headers: dict[str, str] = {}
        _otel_inject(headers)

        url = f"{self.base_url}/call"
        full_path = self._build_path_with_params(path, params) if params else path
        envelope: dict[str, Any] = {
            "data": {
                "path": full_path,
                "method": method.value,
                "body": body or {},
            },
            "nonce": "dev-nonce",
        }
        response = httpx.request(
            method="POST",
            url=url,
            json=envelope,
            headers=headers,
            timeout=self._timeout,
        )

        response.raise_for_status()
        if response.status_code == 204:  # No Content — body is empty
            return None
        try:
            return response.json()
        except ValueError as e:
            raise RuntimeError(f"Failed to decode JSON response: {e}") from e

    def _call_method(
        self,
        path: str,
        method: HTTPMethod,
        body: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> Any:
        """Dispatch method call to appropriate backend and unwrap response.

        Both deployed and devserver modes return the runtime_status envelope:
            {"runtime_status": "Completed", "call_id": ..., "response": {...}}
        or for execution failures:
            {"runtime_status": "Failed", "call_id": ..., "function_id": ..., "error": {...}}

        Both are normalised to the inner format before the status_code check.

        Args:
            path: Path to call (e.g., "/items/123")
            method: HTTP method (GET, POST, PUT, DELETE, PATCH)
            body: Request body for POST/PUT
            params: Query parameters

        Returns:
            Unwrapped response data from the completed function call

        Raises:
            RuntimeError: If the function call failed or the response is malformed
        """
        if self._cognite_client is not None:
            result = self._call_api(path, method, body, params)
        else:
            result = self._call_devserver(path, method, body, params)

        # Unwrap the outer runtime_status envelope.
        if isinstance(result, dict) and "runtime_status" in result:
            envelope = FunctionCallEnvelope.model_validate(result)
            if envelope.runtime_status == "Completed":
                if not isinstance(envelope.response, dict) or "status_code" not in envelope.response:
                    raise RuntimeError(f"Completed response is malformed or missing: {result}")
                result = envelope.response
            else:
                msg = envelope.error.message if envelope.error else "no error detail available"
                raise RuntimeError(f"Function call {envelope.runtime_status.lower()}: {msg}")

        # Parse the inner envelope (same shape from both deployed and devserver).
        raw_status = cast(dict[str, Any], result).get("status_code") if isinstance(result, dict) else None
        if not isinstance(raw_status, int) or raw_status >= 400:
            error = CogniteFunctionError.model_validate(result)
            raise RuntimeError(f"{error.error_type}: {error.message}")

        return CogniteFunctionResponse.model_validate(result).data  # type: ignore[reportReturnType]

    def _deserialize_response(self, data: Any, return_type: str) -> Any:
        """Deserialize response data into Pydantic models if applicable.

        This method looks up model classes in the subclass's module namespace and
        validates responses against them if the return type matches a Pydantic model.

        Args:
            data: Raw response data
            return_type: String representation of the return type

        Returns:
            Deserialized data if a Pydantic model, otherwise raw data
        """
        # Get the module namespace where the actual client class is defined
        # This allows us to find models defined in generated clients
        module_namespace = sys.modules[type(self).__module__].__dict__

        if return_type.startswith("list["):
            # Handle list responses - extract model name
            if match := re.search(r"list\[([A-Z][a-zA-Z0-9_]*)\]", return_type):
                model_name = match.group(1)
                if model_name in module_namespace:
                    model_class = module_namespace[model_name]
                    # Verify it's actually a Pydantic model class
                    if inspect.isclass(model_class) and issubclass(model_class, BaseModel):
                        if isinstance(data, list):
                            return [model_class.model_validate(item) for item in cast(list[Any], data)]
        elif return_type and return_type[0].isupper():
            # Single model response - check if it's a known model
            # Extract base type name (e.g., "Item" from "Item")
            if match := re.search(r"^([A-Z][a-zA-Z0-9_]*)", return_type):
                model_name = match.group(1)
                if model_name in module_namespace:
                    model_class = module_namespace[model_name]
                    # Verify it's actually a Pydantic model class
                    if inspect.isclass(model_class) and issubclass(model_class, BaseModel):
                        return model_class.model_validate(data)

        return data
