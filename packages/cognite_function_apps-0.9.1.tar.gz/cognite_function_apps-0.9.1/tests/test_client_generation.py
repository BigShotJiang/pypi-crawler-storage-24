"""Tests for client generation functionality.

This module tests the generation of typed Python clients from function metadata,
including model discovery, source extraction, and client code generation.
"""

import logging
import sys
import tempfile
from pathlib import Path
from typing import Any
from unittest.mock import Mock, patch

import pytest
from cognite.client import CogniteClient
from cognite.client.exceptions import CogniteAPIError
from pydantic import BaseModel, ConfigDict, Field, Json

from cognite_function_apps import FunctionApp, create_function_service, create_introspection_app
from cognite_function_apps.base_client import BaseFunctionClient
from cognite_function_apps.client import FunctionClient
from cognite_function_apps.client_generation import (
    _discover_models_from_handler,  # type: ignore[reportPrivateUsage]
    _extract_models_from_type,  # type: ignore[reportPrivateUsage]
    _topological_sort_models,  # type: ignore[reportPrivateUsage]
    generate_client_methods_metadata,
)
from cognite_function_apps.models import HTTPMethod


# Test models with various complexity levels
class SimpleModel(BaseModel):
    """Simple model for testing."""

    name: str
    value: int


class NestedModel(BaseModel):
    """Model with nested reference."""

    id: int
    simple: SimpleModel


class OptionalModel(BaseModel):
    """Model with optional fields."""

    required: str
    optional: str | None = None
    nested: NestedModel | None = None


class ListModel(BaseModel):
    """Model with list fields."""

    items: list[SimpleModel]
    tags: list[str]


class ComplexModel(BaseModel):
    """Model with Field and various annotations."""

    id: int = Field(description="The unique ID")
    name: str = Field(min_length=1, max_length=100)
    nested: NestedModel
    optional_list: list[SimpleModel] | None = None


class TestModelDiscovery:
    """Test model discovery from handlers and type hints."""

    def test_extract_models_from_direct_type(self):
        """Test extracting a direct BaseModel type."""
        models = _extract_models_from_type(SimpleModel)
        assert SimpleModel in models
        assert len(models) == 1

    def test_extract_models_from_optional(self):
        """Test extracting models from Optional type."""
        models = _extract_models_from_type(SimpleModel | None)
        assert SimpleModel in models

    def test_extract_models_from_list(self):
        """Test extracting models from list type."""
        models = _extract_models_from_type(list[SimpleModel])
        assert SimpleModel in models

    def test_extract_models_from_dict(self):
        """Test extracting models from dict values."""
        models = _extract_models_from_type(dict[str, SimpleModel])
        assert SimpleModel in models

    def test_extract_models_from_non_model(self):
        """Test that non-model types return empty list."""
        models = _extract_models_from_type(str)
        assert len(models) == 0

        models = _extract_models_from_type(int)
        assert len(models) == 0

    def test_discover_models_from_simple_handler(self):
        """Test discovering models from a simple handler."""

        def handler(item: SimpleModel) -> SimpleModel:
            return item

        models = _discover_models_from_handler(handler)
        assert SimpleModel in models
        assert len(models) == 1

    def test_discover_models_from_nested_handler(self):
        """Test discovering nested models."""

        def handler(item: NestedModel) -> NestedModel:
            return item

        models = _discover_models_from_handler(handler)
        # Should discover both NestedModel and SimpleModel
        assert NestedModel in models
        assert SimpleModel in models

    def test_discover_models_from_complex_handler(self):
        """Test discovering models from complex handler with multiple types."""

        def handler(simple: SimpleModel, optional: OptionalModel | None = None) -> ComplexModel:
            return ComplexModel(id=1, name="test", nested=NestedModel(id=1, simple=simple))

        models = _discover_models_from_handler(handler)
        # Should discover all referenced models
        assert SimpleModel in models
        assert NestedModel in models
        assert OptionalModel in models
        assert ComplexModel in models

    def test_discover_models_from_list_handler(self):
        """Test discovering models from handlers with list parameters."""

        def handler(items: list[SimpleModel]) -> list[NestedModel]:
            return []

        models = _discover_models_from_handler(handler)
        assert SimpleModel in models
        assert NestedModel in models

    def test_discover_models_includes_parent_classes(self):
        """Test that parent BaseModel classes are discovered via inheritance."""

        class BaseEquipment(BaseModel):
            asset_external_id: str
            timeseries_external_id: str

        class EquipmentRecord(BaseEquipment):
            last_datapoint_timestamp: int | None = None

        def handler(record: EquipmentRecord) -> EquipmentRecord:
            return record

        models = _discover_models_from_handler(handler)
        assert EquipmentRecord in models
        assert BaseEquipment in models, "Parent BaseModel class must be discovered"

    def test_topological_sort_handles_inheritance(self):
        """Test that parent models are sorted before child models."""

        class Parent(BaseModel):
            id: int

        class Child(Parent):
            name: str

        class GrandChild(Child):
            value: float

        models: set[type[BaseModel]] = {Child, Parent, GrandChild}
        sorted_models = _topological_sort_models(models)

        parent_index = sorted_models.index(Parent)
        child_index = sorted_models.index(Child)
        grandchild_index = sorted_models.index(GrandChild)

        assert parent_index < child_index, "Parent should come before Child"
        assert child_index < grandchild_index, "Child should come before GrandChild"

    def test_discover_models_handles_circular_refs(self):
        """Test that circular references don't cause infinite loops."""

        class CircularA(BaseModel):
            name: str
            b: "CircularB | None" = None

        class CircularB(BaseModel):
            value: int
            a: CircularA | None = None

        def handler(item: CircularA) -> CircularA:
            return item

        # Should not hang or error
        models = _discover_models_from_handler(handler)
        assert CircularA in models


class TestClientGeneration:
    """Test generation of stub and client code."""

    def test_metadata_includes_models(self):
        """Test that metadata includes model source code."""
        app = FunctionApp("Test API", "1.0.0")

        @app.get("/items/{item_id}")
        def get_item(client: CogniteClient, item_id: int) -> SimpleModel:
            """Get an item."""
            return SimpleModel(name="test", value=42)

        metadata = generate_client_methods_metadata(app.routes, app.registry)

        # Should have methods and models keys
        assert "methods" in metadata
        assert "models" in metadata
        assert "imports" in metadata

        # Should contain the model
        models = metadata["models"]
        assert len(models) == 1
        assert models[0]["name"] == "SimpleModel"
        assert "class SimpleModel(BaseModel):" in models[0]["source"]

    def test_metadata_includes_nested_models(self):
        """Test that metadata includes nested models."""
        app = FunctionApp("Test API", "1.0.0")

        @app.post("/items/")
        def create_item(client: CogniteClient, item: ComplexModel) -> ComplexModel:
            """Create an item."""
            return item

        metadata = generate_client_methods_metadata(app.routes, app.registry)

        # Should contain all models
        models = metadata["models"]
        model_names = {m["name"] for m in models}
        assert "SimpleModel" in model_names
        assert "NestedModel" in model_names
        assert "ComplexModel" in model_names

        # Should contain Field import
        imports = metadata["imports"]
        assert any("Field" in imp for imp in imports)

    def test_metadata_includes_config_dict_import(self):
        """Test that ConfigDict usage in models adds the pydantic import."""

        class ModelWithConfig(BaseModel):
            model_config = ConfigDict(frozen=True)
            name: str

        app = FunctionApp("Test API", "1.0.0")

        @app.get("/items/")
        def get_items(client: CogniteClient) -> ModelWithConfig:
            """Get items."""
            return ModelWithConfig(name="test")

        metadata = generate_client_methods_metadata(app.routes, app.registry)

        imports = metadata["imports"]
        assert any("ConfigDict" in imp for imp in imports), f"ConfigDict not in imports: {imports}"

    def test_metadata_includes_json_import(self):
        """Test that Json usage in models adds the pydantic import."""

        class ModelWithJson(BaseModel):
            data: Json[dict[str, int]]

        app = FunctionApp("Test API", "1.0.0")

        @app.post("/items/")
        def create_item(client: CogniteClient, item: ModelWithJson) -> ModelWithJson:
            """Create item."""
            return item

        metadata = generate_client_methods_metadata(app.routes, app.registry)

        imports = metadata["imports"]
        assert any("Json" in imp for imp in imports), f"Json not in imports: {imports}"

    def test_metadata_filters_injected_params(self):
        """Test that metadata filters injected dependencies."""
        app = FunctionApp("Test API", "1.0.0")

        @app.get("/items/")
        def get_items(client: CogniteClient, limit: int = 10) -> list[SimpleModel]:
            """Get items."""
            return []

        metadata = generate_client_methods_metadata(app.routes, app.registry)

        # Should NOT include client parameter
        methods = metadata["methods"]
        assert len(methods) == 1
        params = methods[0]["parameters"]
        param_names = {p["name"] for p in params}
        assert "limit" in param_names
        assert "client" not in param_names


class TestEndToEnd:
    """End-to-end tests with introspection app."""

    def test_introspection_endpoints_exist(self):
        """Test that introspection endpoints are created."""
        introspection = create_introspection_app()
        app = FunctionApp("Test API", "1.0.0")

        @app.get("/test")
        def test_endpoint(client: CogniteClient) -> dict[str, str]:
            """Test endpoint."""
            return {"status": "ok"}

        _handle = create_function_service(introspection, app)

        # Check that the client methods endpoint exists
        assert "/__client_methods__" in introspection.routes
        # Old endpoints should be removed
        assert "/__python_stubs__" not in introspection.routes
        assert "/__python_client__" not in introspection.routes

    def test_metadata_structure(self):
        """Test the structure of metadata returned by introspection."""
        introspection = create_introspection_app()
        app = FunctionApp("Asset Management", "1.0.0")

        @app.get("/items/{item_id}")
        def get_item(client: CogniteClient, item_id: int) -> SimpleModel:
            """Get an item."""
            return SimpleModel(name="test", value=42)

        @app.post("/items/")
        def create_item(client: CogniteClient, item: SimpleModel) -> SimpleModel:
            """Create an item."""
            return item

        _handle = create_function_service(introspection, app)

        # Generate metadata through introspection
        metadata = generate_client_methods_metadata(
            routes=introspection.all_routes,
            registry=introspection.registry,
        )

        # Should have correct structure
        assert "methods" in metadata
        assert "models" in metadata
        assert "imports" in metadata

        # Should have both methods
        methods = metadata["methods"]
        method_names = {m["name"] for m in methods}
        assert "get_item" in method_names
        assert "create_item" in method_names

        # Should have the model
        models = metadata["models"]
        model_names = {m["name"] for m in models}
        assert "SimpleModel" in model_names


class TestClientMethodsMetadata:
    """Test the __client_methods__ endpoint."""

    def test_client_methods_metadata_generation(self):
        """Test generating metadata for dynamic client."""
        app = FunctionApp("Test API", "1.0.0")

        @app.get("/items/{item_id}")
        def get_item(client: CogniteClient, item_id: int, include_tax: bool = False) -> SimpleModel:
            """Get an item."""
            return SimpleModel(name="test", value=42)

        @app.post("/items/")
        def create_item(client: CogniteClient, item: SimpleModel) -> SimpleModel:
            """Create an item."""
            return item

        metadata = generate_client_methods_metadata(app.routes, app.registry)

        # Should have methods, models, and imports
        assert "methods" in metadata
        assert "models" in metadata
        assert "imports" in metadata

        methods = metadata["methods"]

        # Should have 2 methods
        assert len(methods) == 2

        # Check get_item metadata
        get_item_meta = next(m for m in methods if m["name"] == "get_item")
        assert get_item_meta["path"] == "/items/{item_id}"
        assert get_item_meta["http_method"] == "GET"
        assert get_item_meta["description"] == "Get an item."
        assert get_item_meta["return_type"] == "SimpleModel"

        # Check parameters
        params = get_item_meta["parameters"]
        assert len(params) == 2
        item_id_param = next(p for p in params if p["name"] == "item_id")
        assert item_id_param["in"] == "path"
        assert item_id_param["required"] is True

        include_tax_param = next(p for p in params if p["name"] == "include_tax")
        assert include_tax_param["in"] == "query"
        assert include_tax_param["required"] is False

        # Check create_item metadata
        create_item_meta = next(m for m in methods if m["name"] == "create_item")
        assert create_item_meta["path"] == "/items/"
        assert create_item_meta["http_method"] == "POST"

        # Should have body parameter
        create_params = create_item_meta["parameters"]
        assert len(create_params) == 1
        assert create_params[0]["name"] == "item"
        assert create_params[0]["in"] == "body"

    def test_client_methods_filters_injected_dependencies(self):
        """Test that client, logger, etc. are filtered from metadata."""
        app = FunctionApp("Test API", "1.0.0")

        @app.get("/items/")
        def get_items(client: CogniteClient, logger: logging.Logger, limit: int = 10) -> list[SimpleModel]:
            """Get items."""
            return []

        metadata = generate_client_methods_metadata(app.routes, app.registry)

        methods = metadata["methods"]

        # Should only have limit parameter (client and logger filtered)
        params = methods[0]["parameters"]
        assert len(params) == 1
        assert params[0]["name"] == "limit"


class TestFunctionClient:
    """Test the FunctionClient class."""

    def test_function_client_init_with_base_url(self):
        """Test FunctionClient initialization with base_url - no I/O."""
        pytest.importorskip("httpx")

        # Constructor should not make any network calls
        client = FunctionClient(base_url="http://localhost:8000")
        assert client.base_url == "http://localhost:8000"
        assert client._connected is False  # type: ignore[reportProtectedMemberAccess]
        assert client._methods_metadata is None  # type: ignore[reportProtectedMemberAccess]

    def test_function_client_strips_trailing_slash(self):
        """Test that trailing slashes are removed."""
        pytest.importorskip("httpx")

        client = FunctionClient(base_url="http://localhost:8000/")
        assert client.base_url == "http://localhost:8000"

    def test_function_client_requires_parameters(self):
        """Test that FunctionClient requires either base_url or cognite_client."""
        pytest.importorskip("httpx")

        with pytest.raises(ValueError, match=r"Either base_url.*or cognite_client"):
            FunctionClient()  # type: ignore[call-overload]  # intentionally invalid

    def test_function_client_default_timeout(self):
        """Test FunctionClient has a 600s default timeout for long-running functions."""
        pytest.importorskip("httpx")

        client = FunctionClient(base_url="http://localhost:8000")
        assert client._timeout == 600.0  # type: ignore[reportProtectedMemberAccess]

    def test_function_client_custom_timeout(self):
        """Test FunctionClient accepts a custom timeout."""
        pytest.importorskip("httpx")

        client = FunctionClient(base_url="http://localhost:8000", timeout=120.0)
        assert client._timeout == 120.0  # type: ignore[reportProtectedMemberAccess]

    def test_function_client_init_with_cognite_client(self):
        """Test FunctionClient initialization with CogniteClient extracts config automatically."""
        pytest.importorskip("httpx")

        mock_cognite_client = Mock(spec=CogniteClient)
        mock_cognite_client.config.base_url = "https://bluefield.cognitedata.com"
        mock_cognite_client.config.project = "my-project"
        mock_cognite_client.config.credentials.authorization_header.return_value = (
            "Authorization",
            "Bearer extracted-token",
        )

        client = FunctionClient(
            cognite_client=mock_cognite_client,
            function_external_id="my-function",
        )

        assert client.base_url == "https://bluefield.cognitedata.com"
        assert client._project == "my-project"  # type: ignore[reportProtectedMemberAccess]
        assert client._function_external_id == "my-function"  # type: ignore[reportProtectedMemberAccess]
        assert client._cognite_client is mock_cognite_client  # type: ignore[reportProtectedMemberAccess]
        assert client._get_token() == "extracted-token"  # type: ignore[reportProtectedMemberAccess]

    def test_function_client_cognite_client_token_refreshes(self):
        """Test that _get_token re-invokes CogniteClient credentials on each call."""
        pytest.importorskip("httpx")

        mock_cognite_client = Mock(spec=CogniteClient)
        mock_cognite_client.config.base_url = "https://bluefield.cognitedata.com"
        mock_cognite_client.config.project = "my-project"
        mock_cognite_client.config.credentials.authorization_header.side_effect = [
            ("Authorization", "Bearer first-token"),
            ("Authorization", "Bearer refreshed-token"),
        ]

        client = FunctionClient(
            cognite_client=mock_cognite_client,
            function_external_id="my-function",
        )

        assert client._get_token() == "first-token"  # type: ignore[reportProtectedMemberAccess]
        assert client._get_token() == "refreshed-token"  # type: ignore[reportProtectedMemberAccess]

    def test_function_client_deployed_requires_function_external_id(self):
        """Test that cognite_client without function_external_id raises ValueError."""
        pytest.importorskip("httpx")

        mock_cognite_client = Mock(spec=CogniteClient)
        mock_cognite_client.config.base_url = "https://bluefield.cognitedata.com"
        mock_cognite_client.config.project = "my-project"

        with pytest.raises(ValueError, match="function_external_id is required"):
            FunctionClient(  # type: ignore[call-overload]  # intentionally invalid
                cognite_client=mock_cognite_client,
            )

    def test_function_client_materialize_creates_file(self):
        """Test that materialize creates a file."""
        pytest.importorskip("httpx")

        with tempfile.TemporaryDirectory() as tmpdir:
            output_path = Path(tmpdir) / "clients" / "test_client.py"

            # This will fail since we're not running a server, but we can test the path handling
            _client = FunctionClient(base_url="http://localhost:8000")

            # Test that the parent directory would be created
            assert not output_path.parent.exists()

    def test_function_client_requires_httpx(self):
        """Test that FunctionClient raises ImportError if httpx is not available."""
        # This test might pass if httpx is installed, but documents the expected behavior

        # Temporarily hide httpx
        with patch.dict(sys.modules, {"httpx": None}):
            # Clear the import cache
            if "cognite_function_apps.client" in sys.modules:
                del sys.modules["cognite_function_apps.client"]

            # Now try to import - this might not work perfectly in tests
            # but documents the intent
            try:
                # If httpx is installed, this will work
                # We're just documenting that it should check for httpx
                assert FunctionClient is not None  # Ensure import is used
            except ImportError:
                pass  # Expected if httpx is not available


class TestFunctionClientDiscovery:
    """Test the new discovery functionality."""

    def test_discover_lazy_connection(self):
        """Test that discover() connects lazily."""
        pytest.importorskip("httpx")

        client = FunctionClient(base_url="http://localhost:8000")

        # Constructor doesn't connect
        assert client._connected is False  # type: ignore[reportProtectedMemberAccess]

        # discover() would connect, but we can't test it without a server
        # This test documents the expected behavior

    def test_json_schema_to_python_type_primitives(self):
        """Test converting JSON Schema primitives to Python types."""
        pytest.importorskip("httpx")

        client = FunctionClient(base_url="http://localhost:8000")

        # Test primitive types
        assert client._json_schema_to_python_type({"type": "string"}, {}) is str  # type: ignore[reportProtectedMemberAccess]
        assert client._json_schema_to_python_type({"type": "integer"}, {}) is int  # type: ignore[reportProtectedMemberAccess]
        assert client._json_schema_to_python_type({"type": "number"}, {}) is float  # type: ignore[reportProtectedMemberAccess]
        assert client._json_schema_to_python_type({"type": "boolean"}, {}) is bool  # type: ignore[reportProtectedMemberAccess]
        assert client._json_schema_to_python_type({"type": "null"}, {}) is type(None)  # type: ignore[reportProtectedMemberAccess]

    def test_json_schema_to_python_type_array(self):
        """Test converting JSON Schema array type."""
        pytest.importorskip("httpx")

        client = FunctionClient(base_url="http://localhost:8000")

        # Array of strings
        array_schema = {"type": "array", "items": {"type": "string"}}
        result = client._json_schema_to_python_type(array_schema, {})  # type: ignore[reportProtectedMemberAccess]
        # Check if it's a list type (can't easily check the generic param at runtime)
        assert str(result).startswith("list[")

    def test_json_schema_to_python_type_optional(self):
        """Test converting JSON Schema anyOf with null (Optional)."""
        pytest.importorskip("httpx")

        client = FunctionClient(base_url="http://localhost:8000")

        # Optional string (anyOf: [string, null])
        optional_schema = {"anyOf": [{"type": "string"}, {"type": "null"}]}
        result = client._json_schema_to_python_type(optional_schema, {})  # type: ignore[reportProtectedMemberAccess]
        # Result should be str | None
        assert result is not None

    def test_build_dependency_graph(self):
        """Test building dependency graph from schemas."""
        pytest.importorskip("httpx")

        client = FunctionClient(base_url="http://localhost:8000")

        schemas = {
            "Item": {"type": "object", "properties": {"name": {"type": "string"}, "price": {"type": "number"}}},
            "ItemResponse": {
                "type": "object",
                "properties": {"id": {"type": "integer"}, "item": {"$ref": "#/components/schemas/Item"}},
            },
        }

        deps = client._build_dependency_graph(schemas)  # type: ignore[reportProtectedMemberAccess]

        # ItemResponse depends on Item
        assert "Item" in deps
        assert "ItemResponse" in deps
        assert "Item" in deps["ItemResponse"]
        assert len(deps["Item"]) == 0  # Item has no dependencies

    def test_topological_sort(self):
        """Test topological sorting of dependencies."""
        pytest.importorskip("httpx")

        client = FunctionClient(base_url="http://localhost:8000")

        # Simple dependency: B depends on A
        deps: dict[str, set[str]] = {"A": set(), "B": {"A"}}

        result = client._topological_sort(deps)  # type: ignore[reportProtectedMemberAccess]

        # A should come before B (dependencies first)
        assert result.index("A") < result.index("B")

    def test_topological_sort_complex(self):
        """Test topological sorting with complex dependencies."""
        pytest.importorskip("httpx")

        client = FunctionClient(base_url="http://localhost:8000")

        # Complex: D depends on B and C, B depends on A, C depends on A
        deps: dict[str, set[str]] = {"A": set(), "B": {"A"}, "C": {"A"}, "D": {"B", "C"}}

        result = client._topological_sort(deps)  # type: ignore[reportProtectedMemberAccess]

        # A must come before B and C
        assert result.index("A") < result.index("B")
        assert result.index("A") < result.index("C")
        # B and C must come before D
        assert result.index("B") < result.index("D")
        assert result.index("C") < result.index("D")

    def test_create_model_from_schema_simple(self):
        """Test creating a simple Pydantic model from JSON Schema."""
        pytest.importorskip("httpx")

        client = FunctionClient(base_url="http://localhost:8000")

        schema = {
            "type": "object",
            "properties": {"name": {"type": "string"}, "age": {"type": "integer"}},
            "required": ["name"],
        }

        model = client._create_model_from_schema("Person", schema, {})  # type: ignore[reportProtectedMemberAccess]

        # Test the model works
        instance = model(name="Alice", age=30)
        assert instance.name == "Alice"  # type: ignore[reportUnknownMemberType]
        assert instance.age == 30  # type: ignore[reportUnknownMemberType]

        # Test required field
        with pytest.raises(Exception):  # Pydantic validation error
            model(age=30)  # Missing required name

    def test_create_model_from_schema_with_defaults(self):
        """Test creating a model with default values."""
        pytest.importorskip("httpx")

        client = FunctionClient(base_url="http://localhost:8000")

        schema = {
            "type": "object",
            "properties": {"name": {"type": "string"}, "status": {"type": "string", "default": "active"}},
            "required": ["name"],
        }

        model = client._create_model_from_schema("Item", schema, {})  # type: ignore[reportProtectedMemberAccess] # type: ignore[reportUnknownArgumentType]

        # Test with default
        instance = model(name="test")
        assert instance.name == "test"  # type: ignore[reportUnknownMemberType]
        assert instance.status == "active"  # type: ignore[reportUnknownMemberType]

    def test_extract_refs_from_dict(self):
        """Test extracting $ref references from a schema."""
        pytest.importorskip("httpx")

        client = FunctionClient(base_url="http://localhost:8000")

        schema = {
            "type": "object",
            "properties": {
                "item": {"$ref": "#/components/schemas/Item"},
                "tags": {"type": "array", "items": {"$ref": "#/components/schemas/Tag"}},
            },
        }

        refs: set[str] = set()
        client._extract_refs(schema, refs)  # type: ignore[reportProtectedMemberAccess]

        assert "Item" in refs
        assert "Tag" in refs

    def test_extract_refs_from_list(self):
        """Test extracting refs from list structures."""
        pytest.importorskip("httpx")

        client = FunctionClient(base_url="http://localhost:8000")

        schema = [{"$ref": "#/components/schemas/A"}, {"$ref": "#/components/schemas/B"}]

        refs: set[str] = set()
        client._extract_refs(schema, refs)  # type: ignore[reportProtectedMemberAccess]

        assert "A" in refs
        assert "B" in refs

    def test_automatic_response_parsing_after_discover(self):
        """Test that responses are automatically parsed to models after discover()."""
        pytest.importorskip("httpx")

        # Mock OpenAPI schema
        openapi_schema = {
            "openapi": "3.1.0",
            "info": {"title": "Test API", "version": "1.0.0"},
            "paths": {},  # Required field in OpenAPIDocument
            "components": {
                "schemas": {
                    "Item": {
                        "type": "object",
                        "properties": {"name": {"type": "string"}, "price": {"type": "number"}},
                        "required": ["name", "price"],
                    },
                    "ItemResponse": {
                        "type": "object",
                        "properties": {
                            "id": {"type": "integer"},
                            "total": {"type": "number"},
                        },
                        "required": ["id", "total"],
                    },
                }
            },
        }

        # Mock methods metadata
        methods_metadata = {
            "status_code": 200,
            "headers": {},
            "data": {
                "methods": [
                    {
                        "name": "get_item",
                        "path": "/items/{item_id}",
                        "http_method": "GET",
                        "parameters": [{"name": "item_id", "in": "path", "type": "int", "required": True}],
                        "return_type": "ItemResponse",
                        "description": "Get an item",
                    }
                ]
            },
        }

        # Mock response data
        response_data = {"status_code": 200, "headers": {}, "data": {"id": 42, "total": 100.0}}

        def _envelope(data: Any) -> dict[str, Any]:
            """Wrap data in the runtime_status envelope matching the deployed API format."""
            return {
                "runtime_status": "Completed",
                "call_id": "dev-test",
                "function_id": "local-dev-server",
                "response": {"status_code": 200, "headers": {}, "data": data},
            }

        with patch("httpx.request") as mock_request:
            # All calls go through POST /call; route by envelope path
            def side_effect(method: str, url: str, *args: Any, **kwargs: Any) -> Mock:
                response = Mock()
                response.raise_for_status = Mock()
                envelope_path = kwargs.get("json", {}).get("data", {}).get("path", "")
                if envelope_path == "/__schema__":
                    response.json = Mock(return_value=_envelope(openapi_schema))
                elif envelope_path == "/__client_methods__":
                    response.json = Mock(return_value=_envelope(methods_metadata["data"]))
                else:
                    response.json = Mock(return_value=_envelope(response_data["data"]))
                return response

            mock_request.side_effect = side_effect

            client = FunctionClient(base_url="http://localhost:8000")

            # Call discover to enable automatic parsing
            models = client.discover()

            # Verify models were created
            assert hasattr(models, "Item")
            assert hasattr(models, "ItemResponse")

            # Call method - should return parsed model
            result = client.get_item(item_id=42)

            # Verify result is a Pydantic model, not a dict
            assert hasattr(result, "id")
            assert hasattr(result, "total")
            assert result.id == 42  # type: ignore[reportUnknownMemberType]
            assert result.total == 100.0  # type: ignore[reportUnknownMemberType]

            # Verify it's actually the ItemResponse model
            assert type(result).__name__ == "ItemResponse"

    def test_automatic_response_parsing_with_list(self):
        """Test that list responses are automatically parsed to list of models."""
        pytest.importorskip("httpx")

        # Mock OpenAPI schema
        openapi_schema = {
            "openapi": "3.1.0",
            "info": {"title": "Test API", "version": "1.0.0"},
            "paths": {},  # Required field in OpenAPIDocument
            "components": {
                "schemas": {
                    "Item": {
                        "type": "object",
                        "properties": {"name": {"type": "string"}, "price": {"type": "number"}},
                        "required": ["name", "price"],
                    }
                }
            },
        }

        # Mock methods metadata
        methods_metadata: dict[str, Any] = {
            "status_code": 200,
            "headers": {},
            "data": {
                "methods": [
                    {
                        "name": "list_items",
                        "path": "/items",
                        "http_method": "GET",
                        "parameters": [],
                        "return_type": "list[Item]",
                        "description": "List items",
                    }
                ]
            },
        }

        # Mock response data - list of items
        response_data: dict[str, Any] = {
            "status_code": 200,
            "headers": {},
            "data": [{"name": "Item1", "price": 10.0}, {"name": "Item2", "price": 20.0}],
        }

        def _envelope(data: Any) -> dict[str, Any]:
            return {
                "runtime_status": "Completed",
                "call_id": "dev-test",
                "function_id": "local-dev-server",
                "response": {"status_code": 200, "headers": {}, "data": data},
            }

        with patch("httpx.request") as mock_request:
            # All calls go through POST /call; route by envelope path
            def side_effect(method: str, url: str, *args: Any, **kwargs: Any) -> Mock:
                response = Mock()
                response.raise_for_status = Mock()
                envelope_path = kwargs.get("json", {}).get("data", {}).get("path", "")
                if envelope_path == "/__schema__":
                    response.json = Mock(return_value=_envelope(openapi_schema))
                elif envelope_path == "/__client_methods__":
                    response.json = Mock(return_value=_envelope(methods_metadata["data"]))
                else:
                    response.json = Mock(return_value=_envelope(response_data["data"]))
                return response

            mock_request.side_effect = side_effect

            client = FunctionClient(base_url="http://localhost:8000")

            # Call discover to enable automatic parsing
            client.discover()

            # Call method - should return list of parsed models
            result: list[dict[str, Any]] = client.list_items()

            # Verify result is a list of models
            assert isinstance(result, list)
            assert len(result) == 2
            assert type(result[0]).__name__ == "Item"
            assert type(result[1]).__name__ == "Item"
            assert result[0].name == "Item1"  # type: ignore[reportUnknownMemberType]
            assert result[1].name == "Item2"  # type: ignore[reportUnknownMemberType]

    def test_no_parsing_for_dict_return_type(self):
        """Test that dict return types are not parsed."""
        pytest.importorskip("httpx")

        # Mock OpenAPI schema
        openapi_schema: dict[str, Any] = {
            "openapi": "3.1.0",
            "info": {"title": "Test API", "version": "1.0.0"},
            "paths": {},  # Required field in OpenAPIDocument
            "components": {"schemas": {}},
        }

        # Mock methods metadata
        methods_metadata: dict[str, Any] = {
            "status_code": 200,
            "headers": {},
            "data": {
                "methods": [
                    {
                        "name": "get_data",
                        "path": "/data",
                        "http_method": "GET",
                        "parameters": [],
                        "return_type": "dict[str, Any]",
                        "description": "Get data",
                    }
                ]
            },
        }

        # Mock response data
        response_data = {"status_code": 200, "headers": {}, "data": {"key": "value"}}

        def _envelope(data: Any) -> dict[str, Any]:
            return {
                "runtime_status": "Completed",
                "call_id": "dev-test",
                "function_id": "local-dev-server",
                "response": {"status_code": 200, "headers": {}, "data": data},
            }

        with patch("httpx.request") as mock_request:
            # All calls go through POST /call; route by envelope path
            def side_effect(method: str, url: str, *args: Any, **kwargs: Any) -> Mock:
                response = Mock()
                response.raise_for_status = Mock()
                envelope_path = kwargs.get("json", {}).get("data", {}).get("path", "")
                if envelope_path == "/__schema__":
                    response.json = Mock(return_value=_envelope(openapi_schema))
                elif envelope_path == "/__client_methods__":
                    response.json = Mock(return_value=_envelope(methods_metadata["data"]))
                else:
                    response.json = Mock(return_value=_envelope(response_data["data"]))
                return response

            mock_request.side_effect = side_effect

            client = FunctionClient(base_url="http://localhost:8000")

            # Call discover
            client.discover()

            # Call method - should return dict (not parsed)
            result = client.get_data()

            # Verify result is still a dict
            assert isinstance(result, dict)
            assert result == {"key": "value"}


class TestCallMethodRuntimeStatusEnvelope:
    """Test unwrapping the deployed API's runtime_status envelope."""

    def _make_deployed_client(self) -> tuple[BaseFunctionClient, Mock]:
        mock_cognite_client = Mock()
        mock_cognite_client.config.base_url = "https://bluefield.cognitedata.com"
        mock_cognite_client.config.project = "my-project"
        mock_cognite_client.iam.sessions.create.return_value = Mock(nonce="test-nonce")
        client = BaseFunctionClient(cognite_client=mock_cognite_client, function_external_id="my-function")
        mock_response = Mock()
        mock_response.status_code = 200
        mock_cognite_client.post.return_value = mock_response
        return client, mock_response

    def test_completed_envelope_unwrapped(self):
        """Completed responses should unwrap the outer envelope and return inner data."""
        client, mock_response = self._make_deployed_client()
        mock_response.json.return_value = {
            "runtime_status": "Completed",
            "call_id": 1,
            "function_id": 2,
            "response": {"status_code": 200, "data": {"result": "ok"}, "headers": {}},
        }
        result = client._call_method("/items/1", HTTPMethod.GET)  # type: ignore[reportPrivateUsage]
        assert result == {"result": "ok"}

    def test_failed_envelope_raises(self):
        """Failed responses should raise RuntimeError."""
        client, mock_response = self._make_deployed_client()
        mock_response.json.return_value = {
            "runtime_status": "Failed",
            "call_id": 1,
            "function_id": 2,
        }
        with pytest.raises(RuntimeError, match="failed"):
            client._call_method("/items/1", HTTPMethod.GET)  # type: ignore[reportPrivateUsage]

    def test_failed_with_error_detail_raises(self):
        """Failed responses with error detail should include the message."""
        client, mock_response = self._make_deployed_client()
        mock_response.json.return_value = {
            "runtime_status": "Failed",
            "call_id": 1,
            "function_id": 2,
            "error": {"code": 400, "message": "invalid input"},
        }
        with pytest.raises(RuntimeError, match="invalid input"):
            client._call_method("/items/1", HTTPMethod.GET)  # type: ignore[reportPrivateUsage]

    def test_timeout_envelope_raises(self):
        """Timeout responses should raise RuntimeError."""
        client, mock_response = self._make_deployed_client()
        mock_response.json.return_value = {
            "runtime_status": "Timeout",
            "call_id": 1,
            "function_id": 2,
        }
        with pytest.raises(RuntimeError, match="timeout"):
            client._call_method("/items/1", HTTPMethod.GET)  # type: ignore[reportPrivateUsage]


class TestSessionNonce:
    """Test session nonce creation."""

    def test_create_session_nonce(self):
        """Test that _create_session_nonce delegates to CogniteClient."""
        mock_cognite_client = Mock()
        mock_cognite_client.config.base_url = "https://bluefield.cognitedata.com"
        mock_cognite_client.config.project = "my-project"
        mock_cognite_client.iam.sessions.create.return_value = Mock(nonce="test-nonce-123")

        client = BaseFunctionClient(
            cognite_client=mock_cognite_client,
            function_external_id="my-function",
        )

        nonce = client._create_session_nonce()  # type: ignore[reportProtectedMemberAccess]

        assert nonce == "test-nonce-123"
        mock_cognite_client.iam.sessions.create.assert_called_once()

    def test_create_session_nonce_failure(self):
        """Test that _create_session_nonce raises RuntimeError on SDK failure."""
        mock_cognite_client = Mock()
        mock_cognite_client.config.base_url = "https://bluefield.cognitedata.com"
        mock_cognite_client.config.project = "my-project"
        mock_cognite_client.iam.sessions.create.side_effect = CogniteAPIError("unauthorized", 401)

        client = BaseFunctionClient(
            cognite_client=mock_cognite_client,
            function_external_id="my-function",
        )

        with pytest.raises(RuntimeError, match="Session creation failed"):
            client._create_session_nonce()  # type: ignore[reportProtectedMemberAccess]
