"""Shared XML assembly logic for all QTI builders."""

from __future__ import annotations

import logging
import re
import uuid
from html import escape
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Callable, Sequence, Union

from lxml import etree

from .._version import SDK_TOOL_NAME, SDK_TOOL_VERSION
from ..content.pipeline import ContentPipeline
from ..content.svg_extractor import extract_inline_svgs, restore_img_placeholders
from ..models.base import (
    AccessibilityCatalogEntry,
    AudioStimulus,
    CompanionMaterials,
    Feedback,
    ImageStimulus,
    ItemPackaging,
    LearningContent,
    Stimulus,
    TextLearningContent,
    TextStimulus,
    VideoLearningContent,
    VideoStimulus,
    WorkedExampleContent,
)
from ..models.behaviors import (
    AssessmentBehavior,
    ExternalGraded,
    FeedbackEnabled,
    SummativeBehavior,
)
from ..models.scoring import (
    ChoiceScoreMap,
    MatchScoreMap,
    TextEntryScoreMap,
)

if TYPE_CHECKING:
    from ..models.question_item import QuestionItem

ScoreMapType = Union[ChoiceScoreMap, TextEntryScoreMap, MatchScoreMap]

QTI_NS = "http://www.imsglobal.org/xsd/imsqtiasi_v3p0"
XSI_NS = "http://www.w3.org/2001/XMLSchema-instance"
QTI_SCHEMA_LOCATION = (
    "http://www.imsglobal.org/xsd/imsqtiasi_v3p0 "
    "https://purl.imsglobal.org/spec/qti/v3p0/schema/xsd/imsqti_asiv3p0_v1p0.xsd"
)

NSMAP = {None: QTI_NS, "xsi": XSI_NS}
LOGGER = logging.getLogger(__name__)


@dataclass
class BuildResult:
    """Output of a builder: the item XML and optionally stimulus file(s)."""

    item_xml: str
    stimulus_xml: str | None = None
    stimulus_id: str | None = None
    item_id: str = ""
    metadata: dict[str, str] = field(default_factory=dict)
    packaging: ItemPackaging | None = None
    generated_assets: dict[str, str] = field(default_factory=dict)


class BaseBuilder:
    """Shared XML assembly methods used by all interaction builders."""

    def __init__(self) -> None:
        self.pipeline = ContentPipeline()
        self._generated_assets: dict[str, str] = {}
        self._current_item_id: str = ""

    def _reset_build_state(self, item_id: str) -> None:
        """Reset per-build state. Call at the start of every build()."""
        self._generated_assets = {}
        self._current_item_id = item_id

    def _process_content(
        self,
        text: str,
        format_map: dict[str, str] | None = None,
    ) -> str:
        """Extract inline SVGs then run the content pipeline."""
        text, svgs, img_map = extract_inline_svgs(text, self._current_item_id)
        self._generated_assets.update(svgs)
        result = self.pipeline.process(text, format_map=format_map)
        return restore_img_placeholders(result, img_map)

    @staticmethod
    def _make_item_id(prefix: str, override: str | None = None) -> str:
        if override:
            return override
        return f"{prefix}_{uuid.uuid4().hex[:12]}"

    @staticmethod
    def _content_hash(content: str) -> str:
        """Hash used for stimulus deduplication (not item IDs)."""
        import hashlib

        return hashlib.sha256(content.encode()).hexdigest()

    @staticmethod
    def _is_adaptive(behavior: AssessmentBehavior) -> bool:
        return isinstance(behavior, FeedbackEnabled) and behavior.adaptive

    @staticmethod
    def _infer_completion_ceiling(item: QuestionItem) -> int:
        """Infer adaptive completion ceiling from feedback thresholds + policy fallback."""
        if not isinstance(item.behavior, FeedbackEnabled):
            return 1

        behavior: FeedbackEnabled = item.behavior
        thresholds: list[int] = []
        all_feedback = BaseBuilder._collect_all_feedback(item)
        for fb in all_feedback:
            show = fb.show_when or getattr(behavior.policy, fb.type, None)
            if show is not None and show.after_attempt is not None:
                thresholds.append(show.after_attempt)
        return max([*thresholds, behavior.policy.completion_after])

    # --- Root element ---

    def _build_assessment_item(
        self,
        identifier: str,
        title: str,
        adaptive: bool,
        children: list[etree._Element],
        *,
        lang: str | None = None,
        extension_attributes: dict[str, str] | None = None,
    ) -> etree._Element:
        attrib: dict[str, str] = {
            f"{{{XSI_NS}}}schemaLocation": QTI_SCHEMA_LOCATION,
            "identifier": identifier,
            "title": title,
            "adaptive": str(adaptive).lower(),
            "time-dependent": "false",
            "tool-name": SDK_TOOL_NAME,
            "tool-version": SDK_TOOL_VERSION,
        }
        if lang is not None:
            attrib["{http://www.w3.org/XML/1998/namespace}lang"] = lang
        if extension_attributes:
            attrib.update(extension_attributes)
        root = etree.Element("qti-assessment-item", nsmap=NSMAP, attrib=attrib)
        for child in children:
            root.append(child)
        return root

    # --- Context declarations ---

    def _build_context_declarations(
        self,
        context_declarations: list | None,
    ) -> list[etree._Element]:
        """Build ``<qti-context-declaration>`` elements from ContextVariable list."""
        if not context_declarations:
            return []
        elements: list[etree._Element] = []
        for cv in context_declarations:
            attrib: dict[str, str] = {
                "identifier": cv.identifier,
                "cardinality": cv.cardinality,
            }
            if cv.base_type is not None:
                attrib["base-type"] = cv.base_type
            el = etree.Element("qti-context-declaration", attrib=attrib)
            if cv.default_value is not None:
                dv = etree.SubElement(el, "qti-default-value")
                v = etree.SubElement(dv, "qti-value")
                v.text = cv.default_value
            elements.append(el)
        return elements

    # --- Declarations ---

    def _build_response_declaration(
        self,
        identifier: str,
        cardinality: str,
        base_type: str,
        correct_values: Sequence[str] | None = None,
        mapping: ScoreMapType | None = None,
    ) -> etree._Element:
        el = etree.Element(
            "qti-response-declaration",
            attrib={
                "identifier": identifier,
                "cardinality": cardinality,
                "base-type": base_type,
            },
        )
        if correct_values:
            cr = etree.SubElement(el, "qti-correct-response")
            for val in correct_values:
                v = etree.SubElement(cr, "qti-value")
                v.text = val
        if mapping is not None:
            el.append(self._build_mapping(mapping))
        return el

    @staticmethod
    def _build_mapping(score_map: ScoreMapType) -> etree._Element:
        """Build a ``<qti-mapping>`` element from a score map model."""
        attrib: dict[str, str] = {
            "default-value": str(score_map.default_value),
        }
        lb = getattr(score_map, "lower_bound", None)
        ub = getattr(score_map, "upper_bound", None)
        if lb is not None:
            attrib["lower-bound"] = str(lb)
        if ub is not None:
            attrib["upper-bound"] = str(ub)

        mapping_el = etree.Element("qti-mapping", attrib=attrib)

        if isinstance(score_map, ChoiceScoreMap):
            for key, val in score_map.entries.items():
                etree.SubElement(
                    mapping_el,
                    "qti-map-entry",
                    attrib={"map-key": key, "mapped-value": str(val)},
                )
        elif isinstance(score_map, TextEntryScoreMap):
            cs = str(score_map.case_sensitive).lower()
            for key, val in score_map.entries.items():
                etree.SubElement(
                    mapping_el,
                    "qti-map-entry",
                    attrib={
                        "map-key": key,
                        "mapped-value": str(val),
                        "case-sensitive": cs,
                    },
                )
        elif isinstance(score_map, MatchScoreMap):
            for entry in score_map.entries:
                etree.SubElement(
                    mapping_el,
                    "qti-map-entry",
                    attrib={
                        "map-key": f"{entry.source} {entry.target}",
                        "mapped-value": str(entry.score),
                    },
                )

        return mapping_el

    def _build_outcome_declaration(
        self,
        identifier: str,
        base_type: str,
        cardinality: str = "single",
        default_value: str | None = None,
        normal_maximum: float | None = None,
        external_scored: str | None = None,
        mastery_value: float | None = None,
    ) -> etree._Element:
        attrib: dict[str, str] = {
            "identifier": identifier,
            "cardinality": cardinality,
            "base-type": base_type,
        }
        if normal_maximum is not None:
            attrib["normal-maximum"] = str(normal_maximum)
        if external_scored is not None:
            attrib["external-scored"] = external_scored
        if mastery_value is not None:
            attrib["mastery-value"] = str(mastery_value)
        el = etree.Element("qti-outcome-declaration", attrib=attrib)
        if default_value is not None:
            dv = etree.SubElement(el, "qti-default-value")
            v = etree.SubElement(dv, "qti-value")
            v.text = default_value
        return el

    @staticmethod
    def _build_grading_response_declaration(
        max_score: float,
        extra_fields: list | None = None,
    ) -> etree._Element:
        """Build the GRADING_RESPONSE record outcome declaration.

        This declaration uses ``cardinality="record"`` with no ``base-type``
        on the element itself. Each field has its own ``base-type`` and
        ``field-identifier`` inside ``<qti-default-value>``.
        """
        el = etree.Element(
            "qti-outcome-declaration",
            attrib={"cardinality": "record", "identifier": "GRADING_RESPONSE"},
        )
        dv = etree.SubElement(el, "qti-default-value")

        fields: list[tuple[str, str, str]] = [
            ("string", "comment", ""),
            ("float", "scoreGiven", "0"),
            ("float", "scoreMaximum", str(max_score)),
            ("string", "activityProgress", ""),
            ("string", "gradingProgress", ""),
            ("string", "htmlComment", ""),
        ]

        if extra_fields:
            for ef in extra_fields:
                default = "0" if ef.base_type == "float" else ""
                fields.append((ef.base_type, ef.api_field, default))

        for bt, field_id, default_text in fields:
            v = etree.SubElement(
                dv,
                "qti-value",
                attrib={"base-type": bt, "field-identifier": field_id},
            )
            if default_text:
                v.text = default_text

        return el

    @staticmethod
    def _collect_all_feedback(item: QuestionItem) -> list[Feedback]:
        """Collect all feedback entries across the entire item."""
        all_fb: list[Feedback] = list(item.feedback)
        for interaction in item.interactions:
            all_fb.extend(getattr(interaction, "feedback", []))
            for attr in ("choices", "items", "source_set", "target_set"):
                for sub in getattr(interaction, attr, []):
                    all_fb.extend(getattr(sub, "feedback", []))
        return all_fb

    @staticmethod
    def _feedback_type_set(entries: list[Feedback]) -> set[str]:
        return {fb.type for fb in entries}

    def _build_outcome_declarations(
        self,
        item: QuestionItem,
        score_id: str = "SCORE",
        feedback_id: str = "FEEDBACK",
        normal_max: float | None = None,
        supports_reveal: bool = True,
        supports_modal: bool = True,
    ) -> list[etree._Element]:
        """Build the standard set of outcome declarations for an item.

        Derives scaffold/modal outcome variables from ``Feedback`` entries
        instead of behavior-type fields.
        """
        from ..templates._scoring import derive_item_normal_maximum

        if normal_max is None:
            normal_max = derive_item_normal_maximum(item)

        ext_scored = "human" if isinstance(item.behavior, ExternalGraded) else None
        api_mastery = (
            item.api_scoring.mastery_value if item.api_scoring is not None else None
        )

        outcomes: list[etree._Element] = []
        outcomes.append(
            self._build_outcome_declaration(
                score_id,
                "float",
                default_value="0",
                normal_maximum=normal_max,
                external_scored=ext_scored,
                mastery_value=api_mastery,
            ),
        )
        outcomes.append(
            self._build_outcome_declaration(
                "MAXSCORE",
                "float",
                default_value=str(normal_max),
            ),
        )

        if item.scoring_dimensions:
            for dim in item.scoring_dimensions:
                dim_ext = "human" if dim.scoring_method == "human" else None
                outcomes.append(
                    self._build_outcome_declaration(
                        dim.name,
                        "float",
                        default_value="0",
                        normal_maximum=dim.max_score,
                        external_scored=dim_ext,
                    ),
                )

        if self._is_adaptive(item.behavior):
            outcomes.append(
                self._build_outcome_declaration(
                    "completionStatus",
                    "identifier",
                    default_value="unknown",
                )
            )

        if isinstance(item.behavior, FeedbackEnabled):
            outcomes.append(
                self._build_outcome_declaration(feedback_id, "identifier"),
            )

        all_fb = self._collect_all_feedback(item)
        fb_types = self._feedback_type_set(all_fb)

        if "hint" in fb_types:
            outcomes.append(
                self._build_outcome_declaration("HINT_FEEDBACK", "identifier"),
            )
        if "solution_steps" in fb_types:
            sol_fb = next(fb for fb in all_fb if fb.type == "solution_steps")
            from ..templates._helpers import scaffold_outcome_for

            sol_outcome_id, _ = scaffold_outcome_for(sol_fb)  # type: ignore[misc]
            outcomes.append(
                self._build_outcome_declaration(sol_outcome_id, "identifier"),
            )
        if "learning_content" in fb_types:
            outcomes.append(
                self._build_outcome_declaration(
                    "LEARNING_CONTENT_FEEDBACK",
                    "identifier",
                ),
            )
        if supports_reveal and "answer_reveal" in fb_types:
            outcomes.append(
                self._build_outcome_declaration(
                    "REVEAL_ANSWER_FEEDBACK",
                    "identifier",
                ),
            )

        item_explanation_fb = [fb for fb in item.feedback if fb.type == "explanation"]
        if supports_modal and item_explanation_fb and not item.api_scoring:
            outcomes.append(
                self._build_outcome_declaration("MODAL_FEEDBACK", "identifier"),
            )

        if item.api_scoring is not None:
            outcomes.extend(self._build_api_scoring_outcomes(item))

        return outcomes

    def _build_api_scoring_outcomes(
        self,
        item: QuestionItem,
    ) -> list[etree._Element]:
        """Build additional outcome declarations for API-based scoring."""
        assert item.api_scoring is not None
        assert item.max_score is not None
        outcomes: list[etree._Element] = []

        if item.api_scoring.mastery_value is not None:
            outcomes.append(
                self._build_outcome_declaration(
                    "PASSED",
                    "boolean",
                    default_value="false",
                ),
            )

        has_feedback = isinstance(item.behavior, FeedbackEnabled)

        if has_feedback:
            outcomes.append(
                self._build_outcome_declaration("GENERATED_FEEDBACK", "string"),
            )

        outcomes.append(
            self._build_outcome_declaration("COMMENT", "string"),
        )

        if has_feedback:
            outcomes.append(
                self._build_outcome_declaration(
                    "GENERATED_FEEDBACK_VISIBILITY",
                    "identifier",
                ),
            )

        outcomes.append(
            self._build_grading_response_declaration(
                max_score=item.max_score,
                extra_fields=item.api_scoring.extra_fields,
            ),
        )

        if item.api_scoring.extra_fields:
            for ef in item.api_scoring.extra_fields:
                default = "0" if ef.base_type == "float" else None
                outcomes.append(
                    self._build_outcome_declaration(
                        ef.outcome_identifier,
                        ef.base_type,
                        default_value=default,
                    ),
                )

        return outcomes

    # --- Stimulus ref ---

    def _stimulus_content_str(self, stimulus: Stimulus) -> str:
        """Return a content string for a single stimulus (for hashing)."""
        if isinstance(stimulus, TextStimulus):
            return self._process_content(stimulus.text)
        if isinstance(stimulus, ImageStimulus):
            return self._build_image_tag(stimulus)
        if isinstance(stimulus, AudioStimulus):
            return f'<audio src="{stimulus.url}" controls="controls"/>'
        if isinstance(stimulus, VideoStimulus):
            return f'<video src="{stimulus.url}" controls="controls"/>'
        return ""

    def _build_stimulus_ref(
        self,
        stimulus: Union[Stimulus, list[Stimulus], None],
        item_id: str,
    ) -> tuple[etree._Element | None, str | None, str | None]:
        """Returns (ref_element, stimulus_content, stimulus_id) or (None, None, None).

        For lists with 2+ stimuli, content is represented as the renderer-safe
        document-based structure (tb-* wrappers with details/summary).
        """
        if stimulus is None:
            return None, None, None

        if isinstance(stimulus, list):
            if len(stimulus) <= 1:
                content = self._stimulus_content_str(stimulus[0]) if stimulus else ""
            else:
                titles = [getattr(s, "title", None) for s in stimulus]
                titled_count = sum(1 for title in titles if title)
                if 0 < titled_count < len(stimulus):
                    LOGGER.warning(
                        "Mixed titled and untitled multi-stimulus list detected for item '%s'. "
                        "Auto-generating missing titles.",
                        item_id,
                    )

                resolved_titles = [
                    title if title else f"Document {idx + 1}"
                    for idx, title in enumerate(titles)
                ]
                parts = [
                    '<p class="tb-document-based-stimulus-title">Source Documents</p>',
                    '<div class="tb-document-based-stimulus-container">',
                ]
                for s, title in zip(stimulus, resolved_titles):
                    part = self._stimulus_content_str(s)
                    parts.append(
                        (
                            '<div class="tb-document-stimulus-item">'
                            '<details class="tb-document-stimulus-item-details">'
                            f'<summary class="tb-document-stimulus-item-summary">{escape(title)}</summary>'
                            '<div class="tb-document-stimulus-item-content">'
                            f"{part}"
                            "</div>"
                            "</details>"
                            "</div>"
                        )
                    )
                parts.append("</div>")
                content = "\n".join(parts)
        else:
            content = self._stimulus_content_str(stimulus)

        stim_id = f"stim_{self._content_hash(content)[:12]}"
        ref = etree.Element(
            "qti-assessment-stimulus-ref",
            attrib={
                "identifier": stim_id,
                "href": f"stimuli/{stim_id}.xml",
            },
        )
        return ref, content, stim_id

    # --- Companion Materials ---

    def _build_companion_materials(
        self, materials: CompanionMaterials | None
    ) -> etree._Element | None:
        if materials is None:
            return None

        has_any = materials.calculator or materials.ruler or materials.protractor
        if not has_any:
            return None

        el = etree.Element("qti-companion-materials-info")
        if materials.calculator:
            calc = etree.SubElement(el, "qti-calculator")
            calc.set("calculator-type", materials.calculator)
        if materials.ruler:
            etree.SubElement(el, "qti-rule")
        if materials.protractor:
            etree.SubElement(el, "qti-protractor")
        return el

    # --- Accessibility Catalog ---

    def _build_catalog_info(
        self, entries: list[AccessibilityCatalogEntry] | None
    ) -> etree._Element | None:
        if not entries:
            return None

        catalog_info = etree.Element("qti-catalog-info")

        targets: dict[str, list[AccessibilityCatalogEntry]] = {}
        for entry in entries:
            targets.setdefault(entry.target_path, []).append(entry)

        for target_path, target_entries in targets.items():
            catalog = etree.SubElement(catalog_info, "qti-catalog")
            catalog.set("id", self._catalog_id_for_target_path(target_path))

            for entry in target_entries:
                card = etree.SubElement(catalog, "qti-card")
                card.set("support", entry.support.value)
                card.set("{http://www.w3.org/XML/1998/namespace}lang", "en")

                if entry.support in (
                    "sign-language",
                    "braille",
                    "tactile",
                ):
                    file_href = etree.SubElement(card, "qti-file-href")
                    file_href.set("href", entry.content)
                else:
                    html_content = etree.SubElement(card, "qti-html-content")
                    self._set_inner_html(html_content, entry.content)

        return catalog_info

    def _wire_catalog_refs(
        self,
        body: etree._Element,
        item: QuestionItem,
    ) -> None:
        """Attach ``data-catalog-idref`` to body elements targeted by catalog entries."""
        entries = item.accessibility_catalog
        if not entries:
            return

        matched: set[str] = set()
        for entry in entries:
            target_el = self._resolve_target_path(body, entry.target_path, item)
            if target_el is None:
                continue

            catalog_id = self._catalog_id_for_target_path(entry.target_path)
            target_el.set("data-catalog-idref", catalog_id)
            matched.add(entry.target_path)

        unresolved = sorted({entry.target_path for entry in entries} - matched)
        if unresolved:
            LOGGER.warning(
                "Unresolved accessibility catalog target_path values: %s",
                ", ".join(unresolved),
            )

    @staticmethod
    def _catalog_id_for_target_path(target_path: str) -> str:
        """Return a stable, non-path-like XML id for a catalog target."""
        safe_path = re.sub(r"[^A-Za-z0-9_]+", "_", target_path).strip("_")
        if not safe_path:
            safe_path = "target"
        return f"catalog_ref_{safe_path}"

    @staticmethod
    def _local_name(el: etree._Element) -> str:
        return etree.QName(el).localname

    def _is_interaction_root(self, el: etree._Element) -> bool:
        """Return True if the element is an interaction root (choice, text-entry, etc.)."""
        local_name = self._local_name(el)
        if local_name in {
            "qti-choice-interaction",
            "qti-match-interaction",
            "qti-media-interaction",
            "qti-order-interaction",
            "qti-extended-text-interaction",
            "qti-portable-custom-interaction",
        }:
            return True
        return local_name == "div" and el.get("class") == "text-entry-part"

    def _interaction_roots(self, body: etree._Element) -> list[etree._Element]:
        roots: list[etree._Element] = []
        for child in body:
            if self._is_interaction_root(child):
                roots.append(child)
        return roots

    @staticmethod
    def _ensure_element_id(el: etree._Element, target_path: str) -> None:
        if el.get("id"):
            return
        safe_path = re.sub(r"[^A-Za-z0-9_.-]+", "_", target_path).strip("_")
        if not safe_path:
            safe_path = "catalog_target"
        el.set("id", f"catalog_target_{safe_path}")

    def _resolve_label_for_interaction(
        self,
        body: etree._Element,
        interaction_index: int,
    ) -> etree._Element | None:
        roots = self._interaction_roots(body)
        if interaction_index >= len(roots):
            return None
        root = roots[interaction_index]

        # Inline <strong class="part-label"> (composite items)
        for el in root.iter():
            if self._local_name(el) == "strong" and el.get("class") == "part-label":
                return el

        # Fallback: block <div class="part-label"> preceding sibling
        # (single-interaction builders still use this pattern)
        idx = 0
        pending_label: etree._Element | None = None
        for child in body:
            if self._local_name(child) == "div" and child.get("class") == "part-label":
                pending_label = child
                continue
            if not self._is_interaction_root(child):
                continue
            if idx == interaction_index:
                return pending_label
            idx += 1
            pending_label = None
        return None

    def _resolve_target_path(
        self,
        body: etree._Element,
        target_path: str,
        item: QuestionItem,
    ) -> etree._Element | None:
        # Feedback step paths (e.g. feedback[1].steps[0].summary, interactions[0].feedback[1].steps[0].details)
        fb_step_match = re.fullmatch(
            r"(?:interactions\[(\d+)\]\.)?feedback\[(\d+)\]\.steps\[(\d+)\]\.(summary|details)",
            target_path,
        )
        if fb_step_match:
            expected_id = "catalog_target_" + re.sub(
                r"[^A-Za-z0-9_]+", "_", target_path
            ).strip("_")
            for el in body.iter():
                if el.get("id") == expected_id:
                    return el
            return None

        if target_path == "question":
            stem = next(
                (
                    el
                    for el in body.iter()
                    if self._local_name(el) == "div" and el.get("class") == "stem"
                ),
                None,
            )
            if stem is None:
                return None
            self._ensure_element_id(stem, target_path)
            return stem

        path_match = re.fullmatch(
            r"interactions\[(\d+)\]\.(prompt|label|instructions|choices|items|source_set|target_set)(?:\[([^\]]+)\])?",
            target_path,
        )
        if not path_match:
            return None

        interaction_index = int(path_match.group(1))
        if interaction_index < 0 or interaction_index >= len(item.interactions):
            return None

        segment = path_match.group(2)
        segment_key = path_match.group(3)
        roots = self._interaction_roots(body)
        root = roots[interaction_index] if interaction_index < len(roots) else None

        if segment == "prompt":
            if root is None:
                return None
            prompt = next(
                (el for el in root.iter() if self._local_name(el) == "qti-prompt"),
                None,
            )
            if prompt is None:
                return None
            self._ensure_element_id(prompt, target_path)
            return prompt

        if segment == "label":
            label = self._resolve_label_for_interaction(body, interaction_index)
            if label is None:
                return None
            self._ensure_element_id(label, target_path)
            return label

        if segment == "instructions":
            if interaction_index != 0:
                return None
            instruction = next(
                (
                    el
                    for el in body.iter()
                    if self._local_name(el) == "div"
                    and el.get("class") == "instruction"
                ),
                None,
            )
            if instruction is None:
                return None
            self._ensure_element_id(instruction, target_path)
            return instruction

        if segment in {"choices", "items", "source_set", "target_set"}:
            if root is None or not segment_key:
                return None
            if segment in {"choices", "items"}:
                tag_name = "qti-simple-choice"
            else:
                tag_name = "qti-simple-associable-choice"

            return next(
                (
                    el
                    for el in root.iter()
                    if self._local_name(el) == tag_name
                    and el.get("identifier") == segment_key
                ),
                None,
            )

        return None

    # --- Rubric block ---

    def _build_rubric_block(self, grading_rubric: str | None) -> etree._Element | None:
        if not grading_rubric:
            return None
        rubric_html, svgs, img_map = extract_inline_svgs(
            grading_rubric,
            self._current_item_id,
        )
        self._generated_assets.update(svgs)
        rubric_html = restore_img_placeholders(rubric_html, img_map)
        rb = etree.Element(
            "qti-rubric-block",
            attrib={"use": "scoring", "view": "scorer"},
        )
        div = etree.SubElement(rb, "div")
        self._set_inner_html(div, rubric_html)
        return rb

    # --- API scoring feedback ---

    @staticmethod
    def _build_generated_feedback_block() -> etree._Element:
        """Build the feedback block that displays HTML feedback from the
        grading API. Only appended when api_scoring + FeedbackEnabled."""
        fb = etree.Element(
            "qti-feedback-block",
            attrib={
                "outcome-identifier": "GENERATED_FEEDBACK_VISIBILITY",
                "show-hide": "show",
                "identifier": "visible",
            },
        )
        content_body = etree.SubElement(fb, "qti-content-body")
        div = etree.SubElement(
            content_body,
            "div",
            attrib={"class": "tb-generated-feedback-container"},
        )
        etree.SubElement(
            div,
            "qti-printed-variable",
            attrib={
                "identifier": "GENERATED_FEEDBACK",
                "class": "tb-html-printed-variable",
            },
        )
        return fb

    # --- Feedback ---

    def _build_feedback_block(
        self,
        identifier: str,
        outcome_identifier: str,
        content_html: str,
        css_class: str = "",
    ) -> etree._Element:
        fb = etree.Element(
            "qti-feedback-block",
            attrib={
                "identifier": identifier,
                "outcome-identifier": outcome_identifier,
                "show-hide": "show",
            },
        )
        content_body = etree.SubElement(fb, "qti-content-body")
        div = etree.SubElement(content_body, "div")
        if css_class:
            div.set("class", css_class)
        self._set_inner_html(div, content_html)
        return fb

    def _build_feedback_inline(
        self,
        identifier: str,
        outcome_identifier: str,
        content_html: str,
    ) -> etree._Element:
        """Build a ``<qti-feedback-inline>`` element for per-option feedback."""
        fi = etree.Element(
            "qti-feedback-inline",
            attrib={
                "identifier": identifier,
                "outcome-identifier": outcome_identifier,
                "show-hide": "show",
            },
        )
        self._set_inner_html(fi, content_html)
        return fi

    _FB_TYPE_TO_OUTCOME: dict[str, str] = {
        "hint": "HINT_FEEDBACK",
        "solution_steps": "WORKED_SOLUTION_FEEDBACK",
        "learning_content": "LEARNING_CONTENT_FEEDBACK",
        "answer_reveal": "REVEAL_ANSWER_FEEDBACK",
    }
    _FB_TYPE_TO_BLOCK_ID: dict[str, str] = {
        "hint": "hint_feedback",
        "solution_steps": "worked_solution_feedback",
        "learning_content": "learning_content_feedback",
        "answer_reveal": "reveal_answer_feedback",
    }
    _FB_TYPE_TO_CSS: dict[str, str] = {
        "hint": "hint",
        "solution_steps": "worked-solution",
        "learning_content": "learning-content",
        "answer_reveal": "reveal-answer",
    }

    def _build_scaffold_feedback(
        self,
        feedback_entries: list[Feedback],
        format_map: dict[str, str] | None = None,
        *,
        seen_types: set[str] | None = None,
        path_resolver: Callable[[int, Feedback], str | None] | None = None,
    ) -> list[etree._Element]:
        """Build feedback blocks from ``Feedback`` entries.

        Handles types: hint, solution_steps, learning_content, answer_reveal.
        Skips ``explanation`` (those are per-choice inline elements built
        by individual interaction builders).

        When ``seen_types`` is provided, skips feedback types already in the set
        and adds processed types to it. Use to deduplicate across multiple calls
        (e.g. per-interaction + item-level in composite items).

        When ``path_resolver`` is provided and feedback is solution_steps with
        WorkedExampleContent, the resolver is called to get the feedback path
        (e.g. "interactions[0].feedback[1]" or "feedback[1]") for emitting
        catalog-target ids on step elements.
        """
        from ..templates._helpers import scaffold_outcome_for

        if seen_types is None:
            seen_types = set()
        blocks: list[etree._Element] = []

        for i, fb in enumerate(feedback_entries):
            if fb.type == "explanation":
                continue
            if (
                fb.type == "answer_reveal"
                and isinstance(fb.content, str)
                and not fb.content.strip()
            ):
                continue
            if fb.type in seen_types:
                continue

            entry = scaffold_outcome_for(fb)
            if entry is None:
                outcome_id = self._FB_TYPE_TO_OUTCOME.get(fb.type)
                if outcome_id is None:
                    continue
                identifier = self._FB_TYPE_TO_BLOCK_ID.get(
                    fb.type, f"{fb.type}_feedback"
                )
                css = self._FB_TYPE_TO_CSS.get(fb.type, "")
            else:
                outcome_id, identifier = entry
                if isinstance(fb.content, WorkedExampleContent):
                    css = ""
                else:
                    css = self._FB_TYPE_TO_CSS.get(fb.type, "")

            seen_types.add(fb.type)
            path_prefix = path_resolver(i, fb) if path_resolver else None
            html = self._render_feedback_content(
                fb, format_map, path_prefix=path_prefix
            )

            blocks.append(
                self._build_feedback_block(
                    identifier=identifier,
                    outcome_identifier=outcome_id,
                    content_html=html,
                    css_class=css,
                )
            )

        return blocks

    def _render_feedback_content(
        self,
        fb: Feedback,
        format_map: dict[str, str] | None = None,
        *,
        path_prefix: str | None = None,
    ) -> str:
        """Render a ``Feedback`` entry's content to HTML."""
        content = fb.content
        if isinstance(content, str):
            return self._process_content(content, format_map=format_map)
        if isinstance(content, WorkedExampleContent):
            return self._render_worked_example_html(
                content, format_map, path_prefix=path_prefix
            )
        if isinstance(content, TextLearningContent):
            return self._process_content(content.text, format_map=format_map)
        if isinstance(content, VideoLearningContent):
            return f'<video src="{content.url}" controls="controls"/>'
        return ""

    def _render_worked_example_html(
        self,
        content: WorkedExampleContent,
        format_map: dict[str, str] | None = None,
        *,
        path_prefix: str | None = None,
    ) -> str:
        """Render a ``WorkedExampleContent`` to the renderer's ``tb-*`` HTML.

        When ``path_prefix`` is provided (e.g. "interactions[0].feedback[1]" or
        "feedback[1]"), emits id attributes on step summary/details elements for
        accessibility catalog wiring.
        """
        parts: list[str] = [
            '<div class="tb-worked-example-steps-container">',
            f'<p class="tb-worked-example-title">{escape(content.title)}</p>',
            '<ol class="tb-worked-example-steps">',
        ]
        for i, step in enumerate(content.steps):
            summary_html = self._process_content(step.summary, format_map=format_map)
            summary_id = ""
            if path_prefix is not None:
                safe = re.sub(
                    r"[^A-Za-z0-9_]+", "_", f"{path_prefix}.steps[{i}].summary"
                ).strip("_")
                summary_id = f' id="catalog_target_{safe}"'
            parts.append(f'<li class="tb-worked-example-step" data-step="{i + 1}">')
            parts.append(
                f'<div class="tb-step-summary"{summary_id}>{summary_html}</div>'
            )
            if step.details is not None:
                details_html = self._process_content(
                    step.details, format_map=format_map
                )
                details_id = ""
                if path_prefix is not None:
                    safe = re.sub(
                        r"[^A-Za-z0-9_]+", "_", f"{path_prefix}.steps[{i}].details"
                    ).strip("_")
                    details_id = f' id="catalog_target_{safe}"'
                parts.append(
                    f'<div class="tb-step-details"{details_id}>{details_html}</div>'
                )
            parts.append("</li>")
        parts.append("</ol>")
        parts.append("</div>")
        return "\n".join(parts)

    def _build_end_attempt_interaction(self) -> etree._Element:
        """Build ``<qti-end-attempt-interaction>`` for adaptive behaviors."""
        return etree.Element(
            "qti-end-attempt-interaction",
            attrib={
                "response-identifier": "RESPONSE_END_ATTEMPT",
                "title": "Submit Answer",
            },
        )

    # --- Modal feedback ---

    def _build_modal_feedback_elements(
        self,
        feedback_entries: list[Feedback],
        format_map: dict[str, str] | None = None,
    ) -> list[etree._Element]:
        """Build ``<qti-modal-feedback>`` elements from item-level ``Feedback``
        entries of type ``"explanation"``.

        Maps ``show_when.on_correct=True`` → ``modal_feedback_correct``,
        ``show_when.on_correct=False`` → ``modal_feedback_incorrect``.
        Entries without ``on_correct`` get a generic identifier.
        """
        explanations = [fb for fb in feedback_entries if fb.type == "explanation"]
        if not explanations:
            return []

        elements: list[etree._Element] = []
        partial_assigned = False
        for i, fb in enumerate(explanations):
            on_correct = fb.show_when.on_correct if fb.show_when else None
            if on_correct is True:
                identifier = "modal_feedback_correct"
            elif on_correct is False:
                identifier = "modal_feedback_incorrect"
            elif on_correct is None and not partial_assigned:
                identifier = "modal_feedback_partial"
                partial_assigned = True
            else:
                identifier = f"modal_feedback_{i}"

            mf = etree.Element(
                "qti-modal-feedback",
                attrib={
                    "outcome-identifier": "MODAL_FEEDBACK",
                    "identifier": identifier,
                    "show-hide": "show",
                },
            )
            cb = etree.SubElement(mf, "qti-content-body")
            div = etree.SubElement(cb, "div")
            processed = self._render_feedback_content(fb, format_map=format_map)
            self._set_inner_html(div, processed)
            elements.append(mf)
        return elements

    # --- Scoring dimension helpers ---

    @staticmethod
    def _effective_score_id(config: object) -> str:
        """Return the score target: dimension name if targeted, else ``"SCORE"``."""
        td = getattr(config, "target_dimension", None)
        return td if td else "SCORE"

    @staticmethod
    def _append_dimension_to_score(rp: etree._Element, item: QuestionItem) -> None:
        """For single-interaction items with scoring dimensions, set SCORE = sum(dims)."""
        if not item.scoring_dimensions:
            return
        sov = etree.SubElement(
            rp,
            "qti-set-outcome-value",
            attrib={"identifier": "SCORE"},
        )
        sum_el = etree.SubElement(sov, "qti-sum")
        for dim in item.scoring_dimensions:
            etree.SubElement(sum_el, "qti-variable", attrib={"identifier": dim.name})

    # --- Template declarations & processing ---

    def _get_format_map(self, item: QuestionItem) -> dict[str, str] | None:
        """Build a variable-name -> format-string map from template config."""
        if not item.template:
            return None
        fmt: dict[str, str] = {}
        for var in item.template.variables:
            if var.display_format:
                fmt[var.name] = var.display_format
        return fmt or None

    def _build_template_elements(
        self,
        item: QuestionItem,
        response_id: str = "RESPONSE",
    ) -> tuple[list[etree._Element], etree._Element | None]:
        """Build template declarations and processing for an item.

        Returns ``(declarations, processing_element)`` or ``([], None)``
        when the item has no template.
        """
        if not item.template:
            return [], None

        from ..templates.template_processing import (
            build_template_declarations,
            build_template_processing,
        )

        correct_expr = self._find_correct_expression(item)
        decls = build_template_declarations(
            item.template,
            correct_expression=correct_expr,
            response_id=response_id,
        )
        tp = build_template_processing(
            item.template,
            correct_expression=correct_expr,
            response_id=response_id,
        )
        return decls, tp

    @staticmethod
    def _find_correct_expression(
        item: QuestionItem,
    ) -> str | dict[str, str] | None:
        """Extract ``correct_expression`` from the first TextEntryConfig, if any."""
        from ..models.interactions import TextEntryConfig

        for ix in item.interactions:
            if isinstance(ix, TextEntryConfig) and ix.correct_expression is not None:
                return ix.correct_expression
        return None

    # --- Utilities ---

    def _build_image_tag(self, img: ImageStimulus) -> str:
        alt = img.alt or ""
        return f'<img src="{img.url}" alt="{alt}"/>'

    def _set_inner_html(self, parent: etree._Element, html: str) -> None:
        """Parse an HTML fragment and append it as child nodes."""
        try:
            wrapper = f"<wrapper>{html}</wrapper>"
            parsed = etree.fromstring(wrapper.encode())
            if parsed.text:
                if len(parent) == 0:
                    parent.text = (parent.text or "") + parsed.text
                else:
                    last = parent[-1]
                    last.tail = (last.tail or "") + parsed.text
            for child in parsed:
                parent.append(child)
        except etree.XMLSyntaxError:
            parent.text = html

    def serialize(self, element: etree._Element) -> str:
        return etree.tostring(
            element,
            pretty_print=True,
            xml_declaration=True,
            encoding="UTF-8",
        ).decode("utf-8")
