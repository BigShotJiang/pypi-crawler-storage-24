"""Unified builder entry point for QuestionItem -> QTI 3.0 XML."""

from __future__ import annotations

from ..content.svg_extractor import has_inline_svg
from ..exceptions import BuildError
from ..models.interactions import (
    ChoiceConfig,
    ExtendedTextConfig,
    MatchConfig,
    MediaConfig,
    OrderConfig,
    PCIConfig,
    TextEntryConfig,
)
from ..models.question_item import QuestionItem
from .base_builder import BuildResult
from .choice_builder import ChoiceBuilder
from .composite_builder import CompositeBuilder
from .extended_text_builder import ExtendedTextBuilder
from .match_builder import MatchBuilder
from .media_builder import MediaBuilder
from .order_builder import OrderBuilder
from .pci_builder import PCIBuilder
from .text_entry_builder import TextEntryBuilder
from .transforms import inline_stimulus


class QtiBuilder:
    """Unified entry point: ``QuestionItem`` -> ``BuildResult``.

    Dispatches to the appropriate per-interaction builder for single-
    interaction items, or to ``CompositeBuilder`` when the item has
    multiple interactions.
    """

    def __init__(self) -> None:
        self._choice = ChoiceBuilder()
        self._text_entry = TextEntryBuilder()
        self._extended_text = ExtendedTextBuilder()
        self._match = MatchBuilder()
        self._media = MediaBuilder()
        self._order = OrderBuilder()
        self._pci = PCIBuilder()
        self._composite = CompositeBuilder()

    def build(
        self,
        item: QuestionItem,
        *,
        stimulus_mode: str = "separate",
        emit_end_attempt: bool = False,
    ) -> BuildResult:
        """Build a ``QuestionItem`` into QTI 3.0 XML.

        Parameters
        ----------
        item:
            The validated QuestionItem model.
        stimulus_mode:
            ``"separate"`` (default) generates a standalone stimulus XML
            file and a ``<qti-assessment-stimulus-ref>`` in the item.
            ``"inline"`` injects stimulus content directly into the item
            body.
        emit_end_attempt:
            If True, include ``qti-end-attempt-interaction`` in adaptive
            items (for renderers without a wrapper Submit button).
            Default False omits it (suitable for qti-3-player with wrapper).
        """
        if stimulus_mode == "inline" and has_inline_svg(item.model_dump_json()):
            raise BuildError(
                "Inline SVG content cannot be used with stimulus_mode='inline'. "
                "Use stimulus_mode='separate' to extract SVG to media files, "
                "or replace inline SVG with <img src='...' /> references."
            )

        if len(item.interactions) > 1:
            result = self._composite.build(item, emit_end_attempt=emit_end_attempt)
        else:
            interaction = item.interactions[0]

            if isinstance(interaction, ChoiceConfig):
                result = self._choice.build(item, emit_end_attempt=emit_end_attempt)
            elif isinstance(interaction, TextEntryConfig):
                result = self._text_entry.build(item, emit_end_attempt=emit_end_attempt)
            elif isinstance(interaction, ExtendedTextConfig):
                result = self._extended_text.build(item, emit_end_attempt=emit_end_attempt)
            elif isinstance(interaction, MatchConfig):
                result = self._match.build(item, emit_end_attempt=emit_end_attempt)
            elif isinstance(interaction, MediaConfig):
                result = self._media.build(item, emit_end_attempt=emit_end_attempt)
            elif isinstance(interaction, OrderConfig):
                result = self._order.build(item, emit_end_attempt=emit_end_attempt)
            elif isinstance(interaction, PCIConfig):
                result = self._pci.build(item, emit_end_attempt=emit_end_attempt)
            else:
                raise BuildError(f"Unknown interaction type: {interaction.type}")

        if stimulus_mode == "inline":
            result = inline_stimulus(result)

        return result
