"""Builder for QuestionItem with ChoiceConfig -> QTI 3.0 XML."""

from __future__ import annotations

from lxml import etree

from ..models.behaviors import (
    ExternalGraded,
    FeedbackEnabled,
    SummativeBehavior,
)
from ..models.interactions import ChoiceConfig
from ..models.question_item import QuestionItem
from ..templates.api_scoring_templates import ApiScoringTemplates
from ..templates.choice_templates import ChoiceTemplates
from .base_builder import BaseBuilder, BuildResult


class ChoiceBuilder(BaseBuilder):
    """Converts a QuestionItem with a single ChoiceConfig into QTI 3.0 XML."""

    def build(
        self, item: QuestionItem, *, emit_end_attempt: bool = False
    ) -> BuildResult:
        """Build a single-choice (MCQ) item into QTI 3.0 XML.

        Handles single-select and multi-select modes, per-choice feedback,
        score mappings, and adaptive scaffolding.
        """
        config: ChoiceConfig = item.interactions[0]  # type: ignore[assignment]

        item_id = self._make_item_id("choice", item.item_id)
        self._reset_build_state(item_id)
        is_adaptive = self._is_adaptive(item.behavior)

        title = item.title or "ChoiceInteraction"

        children: list[etree._Element] = []
        children.extend(self._build_context_declarations(item.context_declarations))

        correct_ids = [c.id for c in config.choices if c.correct]
        cardinality = "multiple" if config.max_selections != 1 else "single"
        children.append(
            self._build_response_declaration(
                "RESPONSE",
                cardinality,
                "identifier",
                correct_ids,
                mapping=config.score_map,
            )
        )

        if is_adaptive and emit_end_attempt:
            children.append(
                self._build_response_declaration(
                    "RESPONSE_END_ATTEMPT",
                    "single",
                    "boolean",
                )
            )

        children.extend(
            self._build_outcome_declarations(
                item,
                supports_modal=False,
            )
        )

        tmpl_decls, tmpl_proc = self._build_template_elements(item)
        children.extend(tmpl_decls)
        if tmpl_proc is not None:
            children.append(tmpl_proc)

        stim_ref, stim_content, stim_id = self._build_stimulus_ref(
            item.stimulus,
            item_id,
        )
        if stim_ref is not None:
            children.append(stim_ref)

        comp = self._build_companion_materials(item.companion_materials)
        if comp is not None:
            children.append(comp)

        body = self._build_item_body(item, config, is_adaptive, emit_end_attempt)
        self._wire_catalog_refs(body, item)
        children.append(body)

        catalog = self._build_catalog_info(item.accessibility_catalog)
        if catalog is not None:
            children.append(catalog)

        if item.api_scoring:
            rp = ApiScoringTemplates.get(item)
            children.append(rp)
        else:
            sid = self._effective_score_id(config)
            rp = ChoiceTemplates.get(item, config, score_id=sid)
            if rp is not None:
                self._append_dimension_to_score(rp, item)
                children.append(rp)

        root = self._build_assessment_item(
            item_id,
            title,
            is_adaptive,
            children,
            lang=item.lang,
            extension_attributes=item.extension_attributes,
        )

        stimulus_xml_str = None
        if stim_content and stim_id:
            from .stimulus_builder import StimulusBuilder

            sb = StimulusBuilder()
            stimulus_xml_str = sb.build(item.stimulus, stim_id)
            self._generated_assets.update(sb._generated_assets)

        return BuildResult(
            item_xml=self.serialize(root),
            stimulus_xml=stimulus_xml_str,
            stimulus_id=stim_id,
            item_id=item_id,
            metadata={
                "interaction_type": "choiceInteraction",
                "feedback_type": "adaptive" if is_adaptive else "nonadaptive",
            },
            packaging=item.packaging,
            generated_assets=self._generated_assets,
        )

    def _build_interaction_element(
        self,
        item: QuestionItem,
        config: ChoiceConfig,
        response_id: str = "RESPONSE",
        feedback_id: str = "FEEDBACK",
    ) -> etree._Element:
        """Return the ``<qti-choice-interaction>`` element with choices."""
        fmt = self._get_format_map(item)
        interaction = etree.Element("qti-choice-interaction")
        interaction.set("response-identifier", response_id)
        interaction.set("max-choices", str(config.max_selections))
        if config.shuffle:
            interaction.set("shuffle", "true")
        classes: list[str] = []
        if config.orientation:
            classes.append(f"qti-orientation-{config.orientation}")
        if config.stacking:
            classes.append(f"qti-choices-stacking-{config.stacking}")
        if classes:
            interaction.set("class", " ".join(classes))

        if config.prompt:
            prompt_el = etree.SubElement(interaction, "qti-prompt")
            prompt_html = self._process_content(config.prompt, format_map=fmt)
            self._set_inner_html(prompt_el, prompt_html)

        show_feedback = isinstance(item.behavior, FeedbackEnabled)
        for choice in config.choices:
            simple_choice = etree.SubElement(interaction, "qti-simple-choice")
            simple_choice.set("identifier", choice.id)
            if choice.fixed:
                simple_choice.set("fixed", "true")

            choice_html = self._process_content(choice.content, format_map=fmt)
            self._set_inner_html(simple_choice, choice_html)

            if show_feedback:
                for fb in choice.feedback:
                    if fb.type == "explanation":
                        fi = self._build_feedback_inline(
                            identifier=f"feedback_{choice.id}",
                            outcome_identifier=feedback_id,
                            content_html=self._render_feedback_content(
                                fb, format_map=fmt
                            ),
                        )
                        simple_choice.append(fi)
                        break

        return interaction

    def _build_item_body(
        self,
        item: QuestionItem,
        config: ChoiceConfig,
        is_adaptive: bool,
        emit_end_attempt: bool = False,
    ) -> etree._Element:
        fmt = self._get_format_map(item)
        body = etree.Element("qti-item-body")

        rb = self._build_rubric_block(item.grading_rubric)
        if rb is not None:
            body.append(rb)

        stem_div = etree.SubElement(body, "div", attrib={"class": "stem"})
        question_html = self._process_content(item.question, format_map=fmt)
        self._set_inner_html(stem_div, question_html)

        if config.label:
            label_div = etree.SubElement(body, "div", attrib={"class": "part-label"})
            label_div.text = config.label

        body.append(self._build_interaction_element(item, config))

        _all_fb = list(getattr(config, "feedback", [])) + list(item.feedback)

        if isinstance(item.behavior, FeedbackEnabled):
            has_choice_fb = any(c.feedback for c in config.choices)
            if not has_choice_fb:
                correct_fb = next(
                    (
                        fb
                        for fb in _all_fb
                        if fb.type == "explanation"
                        and fb.show_when
                        and fb.show_when.on_correct is True
                    ),
                    None,
                )
                incorrect_fb = next(
                    (
                        fb
                        for fb in _all_fb
                        if fb.type == "explanation"
                        and fb.show_when
                        and fb.show_when.on_correct is False
                    ),
                    None,
                )
                body.append(
                    self._build_feedback_block(
                        identifier="correct",
                        outcome_identifier="FEEDBACK",
                        content_html=(
                            self._render_feedback_content(correct_fb, format_map=fmt)
                            if correct_fb
                            else "<p>Correct!</p>"
                        ),
                        css_class="qti-feedback-correct",
                    )
                )
                body.append(
                    self._build_feedback_block(
                        identifier="incorrect",
                        outcome_identifier="FEEDBACK",
                        content_html=(
                            self._render_feedback_content(incorrect_fb, format_map=fmt)
                            if incorrect_fb
                            else "<p>Incorrect.</p>"
                        ),
                        css_class="qti-feedback-incorrect",
                    )
                )

        n_config = len(getattr(config, "feedback", []))
        path_resolver = (
            lambda idx, _fb: f"interactions[0].feedback[{idx}]"
            if idx < n_config
            else f"feedback[{idx - n_config}]"
        )
        for fb in self._build_scaffold_feedback(
            _all_fb, format_map=fmt, path_resolver=path_resolver
        ):
            body.append(fb)

        if item.api_scoring and isinstance(item.behavior, FeedbackEnabled):
            body.append(self._build_generated_feedback_block())

        if is_adaptive and emit_end_attempt:
            body.append(self._build_end_attempt_interaction())

        return body
