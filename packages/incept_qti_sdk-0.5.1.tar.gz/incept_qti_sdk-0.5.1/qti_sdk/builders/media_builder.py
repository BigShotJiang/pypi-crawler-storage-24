"""Builder for QuestionItem with MediaConfig -> QTI 3.0 XML."""

from __future__ import annotations

from lxml import etree

from ..models.interactions import MediaConfig
from ..models.question_item import QuestionItem
from .base_builder import BaseBuilder, BuildResult


class MediaBuilder(BaseBuilder):
    """Converts a QuestionItem with a single MediaConfig into QTI 3.0 XML.

    Media interactions track play count only — no scoring. Typically used
    as a companion to other interactions (e.g. watch video, then answer).
    """

    def build(self, item: QuestionItem, *, emit_end_attempt: bool = False) -> BuildResult:
        """Build a standalone media item into QTI 3.0 XML."""
        config: MediaConfig = item.interactions[0]  # type: ignore[assignment]

        item_id = self._make_item_id("media", item.item_id)
        self._reset_build_state(item_id)
        is_adaptive = self._is_adaptive(item.behavior)

        title = item.title or "MediaInteraction"

        children: list[etree._Element] = []
        children.extend(self._build_context_declarations(item.context_declarations))

        children.append(
            self._build_response_declaration("RESPONSE", "single", "integer"),
        )

        if is_adaptive and emit_end_attempt:
            children.append(
                self._build_response_declaration(
                    "RESPONSE_END_ATTEMPT", "single", "boolean",
                )
            )

        children.extend(
            self._build_outcome_declarations(
                item,
                normal_max=0.0,
                supports_reveal=False,
            ),
        )

        tmpl_decls, tmpl_proc = self._build_template_elements(item)
        children.extend(tmpl_decls)
        if tmpl_proc is not None:
            children.append(tmpl_proc)

        stim_ref, stim_content, stim_id = self._build_stimulus_ref(
            item.stimulus, item_id,
        )
        if stim_ref is not None:
            children.append(stim_ref)

        comp = self._build_companion_materials(item.companion_materials)
        if comp is not None:
            children.append(comp)

        body = self._build_item_body(item, config, is_adaptive, emit_end_attempt)
        self._wire_catalog_refs(body, item)
        children.append(body)

        catalog = self._build_catalog_info(item.accessibility_catalog)
        if catalog is not None:
            children.append(catalog)

        fmt = self._get_format_map(item)
        children.extend(
            self._build_modal_feedback_elements(item.feedback, format_map=fmt),
        )

        root = self._build_assessment_item(
            item_id, title, is_adaptive, children,
            lang=item.lang, extension_attributes=item.extension_attributes,
        )

        stimulus_xml_str = None
        if stim_content and stim_id:
            from .stimulus_builder import StimulusBuilder
            sb = StimulusBuilder()
            stimulus_xml_str = sb.build(item.stimulus, stim_id)
            self._generated_assets.update(sb._generated_assets)

        return BuildResult(
            item_xml=self.serialize(root),
            stimulus_xml=stimulus_xml_str,
            stimulus_id=stim_id,
            item_id=item_id,
            metadata={
                "interaction_type": "mediaInteraction",
                "feedback_type": "adaptive" if is_adaptive else "nonadaptive",
            },
            packaging=item.packaging,
            generated_assets=self._generated_assets,
        )

    def _build_interaction_element(
        self,
        item: QuestionItem,
        config: MediaConfig,
        response_id: str = "RESPONSE",
        feedback_id: str = "FEEDBACK",
    ) -> etree._Element:
        """Return the ``<qti-media-interaction>`` element with child video/audio."""
        attribs: dict[str, str] = {
            "response-identifier": response_id,
            "autostart": "true" if config.autostart else "false",
        }
        if config.min_plays != 0:
            attribs["min-plays"] = str(config.min_plays)
        if config.max_plays != 0:
            attribs["max-plays"] = str(config.max_plays)
        if config.loop:
            attribs["loop"] = "true"
        if config.css_classes is not None:
            attribs["class"] = config.css_classes

        interaction = etree.Element("qti-media-interaction", attrib=attribs)

        if config.prompt:
            fmt = self._get_format_map(item)
            prompt_el = etree.SubElement(interaction, "qti-prompt")
            prompt_html = self._process_content(config.prompt, format_map=fmt)
            self._set_inner_html(prompt_el, prompt_html)

        tag = "video" if config.media_type == "video" else "audio"
        media_attribs: dict[str, str] = {}
        if config.controls:
            media_attribs["controls"] = "true"
        if config.media_type == "video" and config.poster is not None:
            media_attribs["poster"] = config.poster

        media_el = etree.SubElement(interaction, tag, attrib=media_attribs)

        for src in config.sources:
            source_el = etree.SubElement(media_el, "source")
            source_el.set("src", src.url)
            source_el.set("type", src.media_type)

        for track in config.tracks:
            track_el = etree.SubElement(media_el, "track")
            track_el.set("src", track.url)
            track_el.set("kind", track.kind)
            if track.srclang is not None:
                track_el.set("srclang", track.srclang)
            if track.default:
                track_el.set("default", "default")

        return interaction

    def _build_item_body(
        self,
        item: QuestionItem,
        config: MediaConfig,
        is_adaptive: bool,
        emit_end_attempt: bool = False,
    ) -> etree._Element:
        fmt = self._get_format_map(item)
        body = etree.Element("qti-item-body")

        rb = self._build_rubric_block(item.grading_rubric)
        if rb is not None:
            body.append(rb)

        stem_div = etree.SubElement(body, "div", attrib={"class": "stem"})
        question_html = self._process_content(item.question, format_map=fmt)
        self._set_inner_html(stem_div, question_html)

        if config.label:
            label_div = etree.SubElement(body, "div", attrib={"class": "part-label"})
            label_div.text = config.label

        body.append(self._build_interaction_element(item, config))

        path_resolver = lambda idx, _fb: f"feedback[{idx}]"
        for fb in self._build_scaffold_feedback(
            list(item.feedback),
            format_map=fmt,
            path_resolver=path_resolver,
        ):
            body.append(fb)

        if is_adaptive and emit_end_attempt:
            body.append(self._build_end_attempt_interaction())

        return body
