"""Builder for QuestionItem with ExtendedTextConfig -> QTI 3.0 XML."""

from __future__ import annotations

from lxml import etree

from ..models.behaviors import FeedbackEnabled
from ..models.interactions import ExtendedTextConfig
from ..models.question_item import QuestionItem
from ..templates.api_scoring_templates import ApiScoringTemplates
from ..templates.extended_text_templates import ExtendedTextTemplates
from .base_builder import BaseBuilder, BuildResult

_EXPECTED_LINES = {"brief": 3, "paragraph": 6, "essay": 15, "long_essay": 95}
_HEIGHT_CLASS = {
    "brief": "qti-height-lines-3",
    "paragraph": "qti-height-lines-6",
    "essay": "qti-height-lines-15",
    "long_essay": "sbac-height-lines-95",
}


class ExtendedTextBuilder(BaseBuilder):
    """Converts a QuestionItem with a single ExtendedTextConfig into QTI 3.0 XML."""

    def build(
        self, item: QuestionItem, *, emit_end_attempt: bool = False
    ) -> BuildResult:
        """Build a free-response / essay item into QTI 3.0 XML.

        Supports configurable expected length (brief / paragraph / essay / long_essay),
        human or machine scoring modes, and multi-dimensional rubrics.
        """
        config: ExtendedTextConfig = item.interactions[0]  # type: ignore[assignment]

        item_id = self._make_item_id("exttext", item.item_id)
        self._reset_build_state(item_id)
        is_adaptive = self._is_adaptive(item.behavior)

        title = item.title or "ExtendedTextInteraction"

        children: list[etree._Element] = []
        children.extend(self._build_context_declarations(item.context_declarations))

        children.append(
            self._build_response_declaration("RESPONSE", "single", "string")
        )

        if is_adaptive and emit_end_attempt:
            children.append(
                self._build_response_declaration(
                    "RESPONSE_END_ATTEMPT",
                    "single",
                    "boolean",
                )
            )

        children.extend(self._build_outcome_declarations(item, supports_reveal=False))

        tmpl_decls, tmpl_proc = self._build_template_elements(item)
        children.extend(tmpl_decls)
        if tmpl_proc is not None:
            children.append(tmpl_proc)

        stim_ref, stim_content, stim_id = self._build_stimulus_ref(
            item.stimulus,
            item_id,
        )
        if stim_ref is not None:
            children.append(stim_ref)

        comp = self._build_companion_materials(item.companion_materials)
        if comp is not None:
            children.append(comp)

        body = self._build_item_body(item, config, is_adaptive, emit_end_attempt)
        self._wire_catalog_refs(body, item)
        children.append(body)

        catalog = self._build_catalog_info(item.accessibility_catalog)
        if catalog is not None:
            children.append(catalog)

        if item.api_scoring:
            rp = ApiScoringTemplates.get(item)
            children.append(rp)
        else:
            sid = self._effective_score_id(config)
            rp = ExtendedTextTemplates.get(item, config, score_id=sid)
            if rp is not None:
                self._append_dimension_to_score(rp, item)
                if any(fb.type == "explanation" for fb in item.feedback):
                    from ..templates._helpers import build_modal_feedback_rp

                    build_modal_feedback_rp(rp)
                children.append(rp)

        if not item.api_scoring:
            fmt = self._get_format_map(item)
            children.extend(
                self._build_modal_feedback_elements(item.feedback, format_map=fmt),
            )

        root = self._build_assessment_item(
            item_id,
            title,
            is_adaptive,
            children,
            lang=item.lang,
            extension_attributes=item.extension_attributes,
        )

        stimulus_xml_str = None
        if stim_content and stim_id:
            from .stimulus_builder import StimulusBuilder

            sb = StimulusBuilder()
            stimulus_xml_str = sb.build(item.stimulus, stim_id)
            self._generated_assets.update(sb._generated_assets)

        return BuildResult(
            item_xml=self.serialize(root),
            stimulus_xml=stimulus_xml_str,
            stimulus_id=stim_id,
            item_id=item_id,
            metadata={
                "interaction_type": "extendedTextInteraction",
                "feedback_type": "adaptive" if is_adaptive else "nonadaptive",
            },
            packaging=item.packaging,
            generated_assets=self._generated_assets,
        )

    def _build_interaction_element(
        self,
        item: QuestionItem,
        config: ExtendedTextConfig,
        response_id: str = "RESPONSE",
        feedback_id: str = "FEEDBACK",
    ) -> etree._Element:
        """Return the ``<qti-extended-text-interaction>`` element."""
        attribs: dict[str, str] = {"response-identifier": response_id}
        if config.expected_length:
            attribs["expected-lines"] = str(_EXPECTED_LINES[config.expected_length])
        if config.placeholder_text:
            attribs["placeholder-text"] = config.placeholder_text

        interaction = etree.Element("qti-extended-text-interaction", attrib=attribs)
        if config.expected_length:
            interaction.set("class", _HEIGHT_CLASS[config.expected_length])

        if config.prompt:
            fmt = self._get_format_map(item)
            prompt_el = etree.SubElement(interaction, "qti-prompt")
            prompt_html = self._process_content(config.prompt, format_map=fmt)
            self._set_inner_html(prompt_el, prompt_html)

        return interaction

    def _build_item_body(
        self,
        item: QuestionItem,
        config: ExtendedTextConfig,
        is_adaptive: bool,
        emit_end_attempt: bool = False,
    ) -> etree._Element:
        fmt = self._get_format_map(item)
        body = etree.Element("qti-item-body")

        rb = self._build_rubric_block(item.grading_rubric)
        if rb is not None:
            body.append(rb)

        stem_div = etree.SubElement(body, "div", attrib={"class": "stem"})
        question_html = self._process_content(item.question, format_map=fmt)
        self._set_inner_html(stem_div, question_html)

        if config.label:
            label_div = etree.SubElement(body, "div", attrib={"class": "part-label"})
            label_div.text = config.label

        body.append(self._build_interaction_element(item, config))

        _all_fb = list(getattr(config, "feedback", [])) + list(item.feedback)
        n_config = len(getattr(config, "feedback", []))
        path_resolver = (
            lambda idx, _fb: f"interactions[0].feedback[{idx}]"
            if idx < n_config
            else f"feedback[{idx - n_config}]"
        )
        for fb in self._build_scaffold_feedback(
            _all_fb, format_map=fmt, path_resolver=path_resolver
        ):
            body.append(fb)

        if item.api_scoring and isinstance(item.behavior, FeedbackEnabled):
            body.append(self._build_generated_feedback_block())

        if is_adaptive and emit_end_attempt:
            body.append(self._build_end_attempt_interaction())

        return body
