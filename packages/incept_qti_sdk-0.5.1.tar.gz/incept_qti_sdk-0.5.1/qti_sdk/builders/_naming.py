"""Variable naming helpers for single and composite QTI items.

Single-interaction items use bare identifiers (RESPONSE, SCORE, FEEDBACK).
Composite items use indexed identifiers (RESPONSE_1, SCORE_1, FEEDBACK_1).
"""

from __future__ import annotations


def response_id(index: int, is_composite: bool) -> str:
    return f"RESPONSE_{index + 1}" if is_composite else "RESPONSE"


def score_id(index: int, is_composite: bool) -> str:
    return f"SCORE_{index + 1}" if is_composite else "SCORE"


def feedback_id(index: int, is_composite: bool) -> str:
    return f"FEEDBACK_{index + 1}" if is_composite else "FEEDBACK"


def multi_blank_response_id(
    index: int, blank_id: str, is_composite: bool,
) -> str:
    """Convert a blank placeholder id to a response variable name.

    ``blank_id`` is the raw id from the prompt, e.g. ``"blank-1"``.
    """
    num = blank_id.split("-")[1]
    if is_composite:
        return f"RESPONSE_{index + 1}_BLANK_{num}"
    return f"RESPONSE_BLANK_{num}"
