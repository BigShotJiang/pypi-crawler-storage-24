"""TimeBack platform configuration and authentication."""

from __future__ import annotations

import os

from pydantic import BaseModel, Field

TIMEBACK_WHITELISTED_DOMAINS: set[str] = {
    "youtube.com",
    "www.youtube.com",
    "youtu.be",
    "wistia.com",
    "wistia.net",
    "googleusercontent.com",
    "drive.google.com",
    "wikimedia.org",
}

TIMEBACK_WILDCARD_DOMAINS: list[str] = [
    ".wistia.com",
    ".wistia.net",
    ".googleusercontent.com",
    ".wikimedia.org",
]


def is_whitelisted(domain: str) -> bool:
    """Check if a domain is whitelisted by TimeBack."""
    domain = domain.lower()
    if domain in TIMEBACK_WHITELISTED_DOMAINS:
        return True
    return any(domain.endswith(suffix) for suffix in TIMEBACK_WILDCARD_DOMAINS)


DEFAULT_SCOPES = " ".join([
    "https://timeback-platform.trilogy.com/content/scope/content.read",
    "https://timeback-platform.trilogy.com/content/scope/content.write",
    "https://purl.imsglobal.org/spec/case/v1p0/scope/case.readonly",
])


_ENV_VARS = {
    "base_url": "TIMEBACK_PLATFORM_API_URL",
    "client_id": "TIMEBACK_APPLICATION_CLIENT_ID",
    "client_secret": "TIMEBACK_APPLICATION_CLIENT_SECRET",
}


class TimeBackConfig(BaseModel):
    """Configuration for connecting to the TimeBack platform."""

    base_url: str = Field(description="TimeBack API base URL.")
    client_id: str = Field(description="OAuth 2.0 client ID.")
    client_secret: str = Field(description="OAuth 2.0 client secret.")
    scope: str = Field(default=DEFAULT_SCOPES, description="OAuth 2.0 scopes.")

    @classmethod
    def from_env(cls) -> "TimeBackConfig":
        """Build config from environment variables.

        Reads TIMEBACK_PLATFORM_API_URL, TIMEBACK_APPLICATION_CLIENT_ID,
        and TIMEBACK_APPLICATION_CLIENT_SECRET from the environment.

        Raises:
            EnvironmentError: If any required variable is missing.
        """
        missing = [v for v in _ENV_VARS.values() if not os.environ.get(v)]
        if missing:
            raise EnvironmentError(
                f"Missing required environment variable(s): {', '.join(missing)}"
            )
        return cls(
            base_url=os.environ[_ENV_VARS["base_url"]],
            client_id=os.environ[_ENV_VARS["client_id"]],
            client_secret=os.environ[_ENV_VARS["client_secret"]],
        )
