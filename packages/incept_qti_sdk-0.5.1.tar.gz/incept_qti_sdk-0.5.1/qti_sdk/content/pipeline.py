"""Content processing pipeline: LaTeX -> MathML -> Markdown -> HTML -> XML."""

from __future__ import annotations

import re
import uuid

from .latex_converter import LatexConverter, _TVAR_PLACEHOLDER_PREFIX
from .markdown_converter import MarkdownConverter
from .xml_utils import html_to_xml

_MATH_PLACEHOLDER_PREFIX = "MATHML_PIPE_"
_BLANK_PLACEHOLDER_PREFIX = "BLANK_PIPE_"
_TVAR_PATTERN = re.compile(r"\{\{(\w+)\}\}")
_BLANK_PATTERN = re.compile(r"<(blank(?:-\w+)?)>")


class ContentPipeline:
    """Orchestrates the full content processing chain.

    Each step is also available individually for cases where only
    partial processing is needed.
    """

    def __init__(self) -> None:
        self.latex = LatexConverter()
        self.markdown = MarkdownConverter()

    def process(
        self,
        text: str,
        format_map: dict[str, str] | None = None,
    ) -> str:
        """Run the full pipeline: LaTeX -> MathML -> Markdown -> HTML -> XML.

        MathML produced by the LaTeX step is shielded from the markdown
        parser via placeholders so that mistune cannot escape the tags.

        ``{{var}}`` tokens are shielded and later restored context-
        dependently: inside MathML they become ``<mi>var</mi>`` (the
        renderer substitutes values via ``math-variable="true"``);
        outside MathML they become ``<qti-printed-variable
        identifier="var"/>`` elements.  *format_map* maps variable names
        to C-style format strings (e.g. ``{"%0.2f"}``) which become
        ``format`` attributes on the emitted ``<qti-printed-variable>``
        elements.
        """
        if not text:
            return text
        result, tvar_map = _protect_template_vars(text, format_map)
        result = self.latex.convert(result)
        result, math_map = _protect_mathml(result)
        result, blank_map = _protect_blanks(result)
        result = self.markdown.convert(result)
        result = _restore_mathml(result, math_map)
        result = html_to_xml(result)
        result = _restore_template_vars(result, tvar_map)
        result = _restore_blanks(result, blank_map)
        return result

    def process_plain(self, text: str) -> str:
        """Process without markdown (for content already in HTML)."""
        if not text:
            return text
        result = self.latex.convert(text)
        result = html_to_xml(result)
        return result


def _protect_mathml(text: str) -> tuple[str, dict[str, str]]:
    """Replace <math>...</math> blocks with unique placeholders."""
    mapping: dict[str, str] = {}
    for match in re.finditer(r"<math[\s>].*?</math>", text, re.DOTALL):
        key = f"{_MATH_PLACEHOLDER_PREFIX}{uuid.uuid4().hex}"
        mapping[key] = match.group(0)
        text = text.replace(match.group(0), key, 1)
    return text, mapping


def _restore_mathml(text: str, mapping: dict[str, str]) -> str:
    """Put the original <math> blocks back in place of their placeholders."""
    for key, original in mapping.items():
        text = text.replace(key, original)
    return text


def _protect_template_vars(
    text: str,
    format_map: dict[str, str] | None,
) -> tuple[str, dict[str, tuple[str, str]]]:
    """Replace ``{{var}}`` tokens with unique placeholders.

    Returns ``(text_with_placeholders, {placeholder: (var_name, xml_element_string)})``.
    """
    mapping: dict[str, tuple[str, str]] = {}
    for match in _TVAR_PATTERN.finditer(text):
        var_name = match.group(1)
        key = f"{_TVAR_PLACEHOLDER_PREFIX}{uuid.uuid4().hex}"
        fmt = (format_map or {}).get(var_name)
        fmt_attr = f' format="{fmt}"' if fmt else ""
        xml_str = f'<qti-printed-variable identifier="{var_name}"{fmt_attr}/>'
        mapping[key] = (var_name, xml_str)
        text = text.replace(match.group(0), key, 1)
    return text, mapping


def _restore_template_vars(text: str, mapping: dict[str, tuple[str, str]]) -> str:
    """Replace template-variable placeholders with the appropriate elements.

    When placeholders appear inside LaTeX math, they are wrapped in ``\\text{}``
    by the LatexConverter, producing ``<mtext>TVAR_PIPE_xxx</mtext>``.  Per the
    QTI spec, template variables inside MathML must use ``<mi>varname</mi>``
    (the renderer substitutes values via ``math-variable="true"``).

    Outside math, placeholders are bare and restored as
    ``<qti-printed-variable identifier="var"/>`` elements.
    """
    for key, (var_name, xml_str) in mapping.items():
        mtext_wrapped = f"<mtext>{key}</mtext>"
        if mtext_wrapped in text:
            text = text.replace(mtext_wrapped, f"<mi>{var_name}</mi>")
        else:
            text = text.replace(key, xml_str)
    return text


def _protect_blanks(text: str) -> tuple[str, dict[str, str]]:
    """Replace ``<blank>`` / ``<blank-N>`` markers with unique placeholders.

    These markers are used by text-entry interactions as fill-in-the-blank
    placeholders.  They look like HTML tags to mistune, which may pass them
    through as raw HTML (context-dependent) instead of escaping them.
    Shielding them ensures deterministic behaviour regardless of paragraph
    structure.
    """
    mapping: dict[str, str] = {}
    for match in _BLANK_PATTERN.finditer(text):
        key = f"{_BLANK_PLACEHOLDER_PREFIX}{uuid.uuid4().hex}"
        mapping[key] = match.group(1)
        text = text.replace(match.group(0), key, 1)
    return text, mapping


def _restore_blanks(text: str, mapping: dict[str, str]) -> str:
    """Restore blank placeholders as XML-escaped entities.

    The builders expect the escaped form (``&lt;blank&gt;``) so they can
    ``.replace()`` it with the actual ``<qti-text-entry-interaction>`` XML.
    """
    for key, tag_name in mapping.items():
        text = text.replace(key, f"&lt;{tag_name}&gt;")
    return text
