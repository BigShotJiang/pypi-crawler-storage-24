"""Markdown to HTML conversion using mistune with GFM extensions."""

from __future__ import annotations

import mistune


class MarkdownConverter:
    """Converts GFM markdown to HTML, preserving block-level HTML."""

    def __init__(self) -> None:
        self._md = mistune.create_markdown(
            escape=False,
            plugins=["strikethrough", "table"],
            hard_wrap=True,
        )

    def convert(self, text: str) -> str:
        if not text:
            return text
        result = self._md(text)
        return result.strip() if result else text
