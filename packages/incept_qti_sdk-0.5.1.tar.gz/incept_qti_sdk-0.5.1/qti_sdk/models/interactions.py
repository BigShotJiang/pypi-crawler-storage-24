"""Interaction config types — the building blocks inside QuestionItem.interactions[].

Each config type maps to one QTI interaction element.  Per-interaction
validators live here; cross-field validators that reference QuestionItem-level
fields live in question_item.py.
"""

from __future__ import annotations

import re
from typing import Annotated, Any, Literal, Union

from pydantic import BaseModel, Field, model_validator

from ..exceptions import ValidationError
from .base import BlankTemplateStr, Feedback, MarkdownStr
from .scoring import (
    ChoiceScoreMap,
    MatchScoreMap,
    ScoreExpression,
    TextEntryScoreMap,
)


# ---------------------------------------------------------------------------
# Supporting types
# ---------------------------------------------------------------------------


class Choice(BaseModel):
    """A single answer option within a :class:`ChoiceConfig` interaction.

    At least two choices are required per interaction, and exactly one must
    be ``correct=True`` for single-select (``max_selections=1``).
    """

    id: str = Field(
        description="Unique identifier for this choice within the item, e.g. 'A', 'B'.",
    )
    content: MarkdownStr
    correct: bool = Field(
        default=False,
        description="Whether this choice is a correct answer.",
    )
    feedback: list[Feedback] = Field(
        default_factory=list,
        description="Per-option feedback entries (explanation, hint, etc.).",
    )
    fixed: bool = Field(
        default=False,
        description="When True, this choice opts out of shuffle.",
    )


class MatchItem(BaseModel):
    """An entry in the source or target set of a :class:`MatchConfig` interaction.

    Source items are dragged/matched onto target items.  The correct
    pairings are declared in ``MatchConfig.correct_mapping``.
    """

    id: str
    content: MarkdownStr
    fixed: bool = Field(
        default=False,
        description="Opt out of shuffle when shuffle=True.",
    )
    feedback: list[Feedback] = Field(
        default_factory=list,
        description="Per-option feedback entries.",
    )


class OrderItem(BaseModel):
    """An item to be placed in sequence within an :class:`OrderConfig` interaction.

    The correct sequence is declared in ``OrderConfig.correct_order``.
    """

    id: str
    content: MarkdownStr
    feedback: list[Feedback] = Field(
        default_factory=list,
        description="Per-option feedback entries.",
    )


# ---------------------------------------------------------------------------
# Interaction configs
# ---------------------------------------------------------------------------


class ChoiceConfig(BaseModel):
    """Single or multi-select MCQ."""

    type: Literal["choice"] = "choice"
    prompt: MarkdownStr | None = Field(
        default=None,
        description="Sub-question for composite parts.",
    )
    label: str | None = Field(
        default=None,
        description='Part label, e.g. "a", "b" (composite items).',
    )
    choices: list[Choice] = Field(min_length=2)
    max_selections: int = Field(
        default=1,
        description="1 = single-select, >1 = multi-select, 0 = unlimited.",
    )
    min_selections: int | None = None
    shuffle: bool = False
    orientation: Literal["horizontal", "vertical"] | None = None
    stacking: Literal[1, 2, 3, 4, 5] | None = None
    score_map: ChoiceScoreMap | None = None
    score_expression: ScoreExpression | None = None
    target_dimension: str | None = None
    feedback: list[Feedback] = Field(
        default_factory=list,
        description="Interaction-level feedback entries (hint, solution_steps, etc.).",
    )

    @model_validator(mode="after")
    def _validate_choices(self) -> ChoiceConfig:
        correct_count = sum(1 for c in self.choices if c.correct)
        if self.max_selections == 1 and correct_count != 1:
            raise ValidationError(
                f"Single-select requires exactly 1 correct choice, got {correct_count}"
            )
        if correct_count < 1:
            raise ValidationError("At least one choice must be correct")

        ids = [c.id for c in self.choices]
        if len(ids) != len(set(ids)):
            raise ValidationError("Choice ids must be unique")

        return self


class TextEntryConfig(BaseModel):
    """Single or multi-blank fill-in."""

    type: Literal["text_entry"] = "text_entry"
    prompt: BlankTemplateStr | None = Field(
        default=None,
        description="Question text with <blank> placeholders. Required unless QuestionItem.question contains the blanks.",
    )
    label: str | None = None
    answers: list[str] | dict[str, list[str]] = Field(
        description=(
            "Single-blank: list of accepted strings. "
            "Multi-blank: dict mapping blank id -> accepted strings."
        ),
    )
    instructions: str | None = None
    placeholder_text: str | None = None
    case_sensitive: bool = False
    expected_length: int | None = Field(
        default=None,
        ge=1,
        description="Expected response length hint for presentation.",
    )
    input_width: (
        Literal[1, 2, 3, 4, 5, 6, 10, 15, 20, 25, 30, 35, 40, 45, 50, 72] | None
    ) = None
    alignment: Literal["left", "center", "right"] | None = None
    math_input: bool = Field(
        default=False,
        description="When True, renders a math keyboard for structured mathematical input.",
    )
    tolerance: float | None = Field(
        default=None,
        description="Absolute tolerance: answer +/- value.",
    )
    score_map: TextEntryScoreMap | None = None
    score_expression: ScoreExpression | None = None
    correct_expression: str | dict[str, str] | None = Field(
        default=None,
        description=(
            "Template-computed answer. str for single-blank, "
            "dict for multi-blank (keys must match blank IDs)."
        ),
    )
    target_dimension: str | None = None
    feedback: list[Feedback] = Field(
        default_factory=list,
        description="Interaction-level feedback entries (hint, solution_steps, etc.).",
    )

    @property
    def is_multi_blank(self) -> bool:
        return isinstance(self.answers, dict)

    @property
    def blank_ids(self) -> list[str]:
        """Ordered list of blank identifiers found in the prompt."""
        if self.prompt is None:
            return []
        if self.is_multi_blank:
            return sorted(
                re.findall(r"<(blank-\d+)>", self.prompt),
                key=lambda b: int(b.split("-")[1]),
            )
        return ["blank"]

    def resolve_blank_ids(self, question: str) -> list[str]:
        """Blank IDs from prompt, falling back to question text.

        When ``prompt`` is set, delegates to :pyattr:`blank_ids`.
        Otherwise extracts ``<blank-N>`` placeholders from *question*
        (the ``QuestionItem.question`` stem).
        """
        if self.prompt is not None:
            return self.blank_ids
        if self.is_multi_blank:
            found = re.findall(r"<(blank-\d+)>", question)
            if found:
                return sorted(found, key=lambda b: int(b.split("-")[1]))
            return sorted(self.answers.keys())  # type: ignore[union-attr]
        return ["blank"]

    @model_validator(mode="after")
    def _validate_blanks(self) -> TextEntryConfig:
        if self.prompt is None:
            return self

        if self.is_multi_blank:
            assert isinstance(self.answers, dict)
            blanks_in_q = set(re.findall(r"<(blank-\d+)>", self.prompt))
            answer_keys = set(self.answers.keys())
            if blanks_in_q != answer_keys:
                raise ValidationError(
                    f"Blanks in prompt {blanks_in_q} don't match answer keys {answer_keys}"
                )
            for key, vals in self.answers.items():
                if not vals:
                    raise ValidationError(f"Blank '{key}' has no answers")
        else:
            assert isinstance(self.answers, list)
            if "<blank>" not in self.prompt:
                raise ValidationError("Single-blank prompt must contain <blank>")
            if not self.answers:
                raise ValidationError("Must provide at least one answer")

        return self


class ExtendedTextConfig(BaseModel):
    """Free response / essay (SAQ, DBQ, LEQ, FRQ)."""

    type: Literal["extended_text"] = "extended_text"
    prompt: MarkdownStr | None = None
    label: str | None = None
    placeholder_text: str | None = None
    expected_length: Literal["brief", "paragraph", "essay", "long_essay"] | None = None
    scoring_mode: Literal["human", "machine"] | None = None
    target_dimension: str | None = None


class MatchConfig(BaseModel):
    """Matching / drag-and-drop between two sets."""

    type: Literal["match"] = "match"
    prompt: MarkdownStr | None = None
    label: str | None = None
    source_set: list[MatchItem] = Field(min_length=1)
    target_set: list[MatchItem] = Field(min_length=1)
    correct_mapping: list[tuple[str, str]] = Field(
        min_length=1,
        description="(source_id, target_id) pairs.",
    )
    max_associations: int | None = Field(
        default=None,
        description="Defaults to len(correct_mapping); set explicitly for categorization.",
    )
    shuffle: bool = False
    orientation: Literal["top", "bottom", "left", "right"] | None = Field(
        default=None,
        description=(
            "Drag-and-drop source placement relative to targets. "
            "Ignored when tabular=True. Defaults to 'top' in the builder "
            "when neither orientation nor tabular is set."
        ),
    )
    tabular: bool = Field(
        default=False,
        description="Render as a checkbox/radio table instead of drag-and-drop.",
    )
    header_hidden: bool = Field(
        default=False,
        description="Hide column headers in tabular mode. Only valid when tabular=True.",
    )
    row_centric: bool = Field(
        default=False,
        description="Flip row/column axes in tabular mode. Only valid when tabular=True.",
    )
    score_map: MatchScoreMap | None = None
    score_expression: ScoreExpression | None = None
    target_dimension: str | None = None
    feedback: list[Feedback] = Field(
        default_factory=list,
        description="Interaction-level feedback entries (hint, solution_steps, etc.).",
    )

    @model_validator(mode="after")
    def _validate_mapping(self) -> MatchConfig:
        source_ids = {s.id for s in self.source_set}
        target_ids = {t.id for t in self.target_set}
        for src, tgt in self.correct_mapping:
            if src not in source_ids:
                raise ValidationError(
                    f"correct_mapping source '{src}' not found in source_set"
                )
            if tgt not in target_ids:
                raise ValidationError(
                    f"correct_mapping target '{tgt}' not found in target_set"
                )

        if len({s.id for s in self.source_set}) != len(self.source_set):
            raise ValidationError("source_set ids must be unique")
        if len({t.id for t in self.target_set}) != len(self.target_set):
            raise ValidationError("target_set ids must be unique")

        return self

    @model_validator(mode="after")
    def _validate_layout(self) -> MatchConfig:
        if self.tabular and self.orientation is not None:
            raise ValidationError(
                "orientation is not used in tabular mode — remove it or set tabular=False"
            )
        if (self.header_hidden or self.row_centric) and not self.tabular:
            raise ValidationError(
                "header_hidden and row_centric only apply when tabular=True"
            )
        return self


class OrderConfig(BaseModel):
    """Sequencing items into correct order."""

    @model_validator(mode="before")
    @classmethod
    def _temporarily_disabled(cls, data: Any) -> Any:
        raise ValidationError(
            "OrderConfig (order interaction) is temporarily disabled."
        )

    type: Literal["order"] = "order"
    prompt: MarkdownStr | None = None
    label: str | None = None
    items: list[OrderItem] = Field(min_length=2)
    correct_order: list[str] = Field(
        min_length=2,
        description="List of item IDs in the correct sequence.",
    )
    shuffle: bool = False
    orientation: Literal["horizontal", "vertical"] | None = None
    partial_credit: bool = Field(
        default=False,
        description="Award points per correctly-placed item.",
    )
    score_expression: ScoreExpression | None = None
    target_dimension: str | None = None
    feedback: list[Feedback] = Field(
        default_factory=list,
        description="Interaction-level feedback entries (hint, solution_steps, etc.).",
    )

    @model_validator(mode="after")
    def _validate_order(self) -> OrderConfig:
        item_ids = {i.id for i in self.items}
        order_ids = set(self.correct_order)
        if item_ids != order_ids:
            raise ValidationError(
                f"correct_order ids {order_ids} don't match item ids {item_ids}"
            )
        if len(self.correct_order) != len(item_ids):
            raise ValidationError(
                "correct_order must contain each item id exactly once"
            )

        if len(item_ids) != len(self.items):
            raise ValidationError("Item ids must be unique")

        return self


class MediaSource(BaseModel):
    """A single media source for a :class:`MediaConfig` interaction.

    Maps to a ``<source>`` element inside ``<video>`` or ``<audio>``.
    """

    url: str = Field(description="URL or relative path to the media file.")
    media_type: str = Field(
        description="MIME type, e.g. 'video/mp4', 'audio/mpeg'.",
    )


class MediaTrack(BaseModel):
    """A caption or subtitle track for a :class:`MediaConfig` interaction.

    Maps to a ``<track>`` element inside ``<video>`` or ``<audio>``.
    """

    url: str = Field(description="URL or relative path to the track file.")
    kind: Literal[
        "subtitles",
        "captions",
        "descriptions",
        "chapters",
        "metadata",
    ] = "subtitles"
    srclang: str | None = Field(
        default=None,
        description="Language code for the track, e.g. 'en', 'es'.",
    )
    default: bool = Field(
        default=False,
        description="Whether this track is the default for the media element.",
    )


class MediaConfig(BaseModel):
    """Media interaction — wraps a single time-based media element and tracks
    play count.

    Maps to ``<qti-media-interaction>``. The response variable holds an
    integer play count (how many times the candidate played to completion).
    No scoring — this interaction is typically used as a companion to
    other interactions (e.g. watch video, then answer a choice question).

    Optional ``css_classes`` is written to the interaction's HTML ``class``
    attribute as a single space-separated token list. Typical renderer sizing
    utilities include ``qti-width-*`` (fractions of the parent width, including
    twelfths) and ``qti-height-*`` (fractions, rem-based steps, ``auto``); the
    authoritative list lives in the player's ``QtiAssessmentItem.scss``.
    """

    type: Literal["media"] = "media"
    prompt: MarkdownStr | None = Field(
        default=None,
        description="Prompt text shown before or alongside the media.",
    )
    label: str | None = Field(
        default=None,
        description='Part label for composite items, e.g. "a", "b".',
    )
    media_type: Literal["video", "audio"] = Field(
        description="Whether to render a <video> or <audio> element.",
    )
    sources: list[MediaSource] = Field(
        min_length=1,
        description="Media sources (URL + MIME type). Maps to <source> elements.",
    )
    tracks: list[MediaTrack] = Field(
        default_factory=list,
        description="Caption/subtitle tracks. Maps to <track> elements.",
    )
    autostart: bool = Field(
        default=False,
        description="Whether media plays on load. Required per QTI spec.",
    )
    min_plays: int = Field(
        default=0,
        ge=0,
        description="Minimum completions for valid response. 0 = no minimum.",
    )
    max_plays: int = Field(
        default=0,
        ge=0,
        description="Maximum completions allowed. 0 = unlimited.",
    )
    loop: bool = Field(
        default=False,
        description="Restart automatically after each completion.",
    )
    css_classes: str | None = Field(
        default=None,
        description=(
            "Space-separated class names on ``<qti-media-interaction>`` "
            "(often ``qti-width-*`` / ``qti-height-*`` utilities). "
            "See MediaConfig class docstring."
        ),
    )
    poster: str | None = Field(
        default=None,
        description="Poster image URL for video. Video-only.",
    )
    controls: bool = Field(
        default=True,
        description="Show native media controls.",
    )

    @model_validator(mode="after")
    def _validate_video_only_attrs(self) -> MediaConfig:
        if self.media_type == "audio":
            if self.poster is not None:
                raise ValidationError("'poster' is video-only; media_type is 'audio'")
        return self


# ---------------------------------------------------------------------------
# PCI module registry — known platform modules with pre-configured resolution
# ---------------------------------------------------------------------------

PCI_MODULE_REGISTRY: dict[str, dict[str, str]] = {
    "number-line-question": {
        "urn": "urn:fdc:learnwithai:pci:number-line-question",
        "data_item_path_uri": "https://pci.platform.learnwith.ai/",
        "primary_configuration": "modules/module_resolution.json",
        "response_cardinality": "single",
        "response_base_type": "float",
    },
    "graph-based-question": {
        "urn": "urn:fdc:learnwithai:pci:graph-based-question",
        "data_item_path_uri": "https://pci.platform.learnwith.ai/",
        "primary_configuration": "modules/module_resolution.json",
        "response_cardinality": "single",
        "response_base_type": "string",
    },
    "graph-plot-points-question": {
        "urn": "urn:fdc:learnwithai:pci:graph-plot-points-question",
        "data_item_path_uri": "https://pci.platform.learnwith.ai/",
        "primary_configuration": "modules/module_resolution.json",
        "response_cardinality": "multiple",
        "response_base_type": "point",
    },
    "graph-line-inequality-question": {
        "urn": "urn:fdc:learnwithai:pci:graph-line-inequality-question",
        "data_item_path_uri": "https://pci.platform.learnwith.ai/",
        "primary_configuration": "modules/module_resolution.json",
        "response_cardinality": "single",
        "response_base_type": "string",
    },
}


class PCITemplateMapping(BaseModel):
    """Maps a QTI template variable to a PCI configuration property."""

    template_identifier: str = Field(
        description="QTI template variable identifier (must match a variable in QuestionItem.template).",
    )
    configuration_property: str = Field(
        description="PCI config property name this template value maps to.",
    )


class PCIConfig(BaseModel):
    """Portable Custom Interaction.

    Wraps a PCI module — external JavaScript loaded by the player from
    data_item_path_uri. The module renders non-standard interaction types
    (number lines, graphs, simulations, etc.).

    Config data reaches the module at runtime via four channels:

    - data_attributes: key-value strings set as data-* attributes on the
      element. The module reads them via element.getAttribute(). This is
      what the platform's registered modules use.
    - properties: structured key-value config (supports nesting). The
      player passes this as the ``config`` argument to the module's
      getInstance(dom, config, stateMap).
    - interaction_markup: initial HTML content for the module's DOM.
      The player passes this as the ``dom`` argument to getInstance().
    - template_variable_mappings: maps QTI template variables to PCI
      config properties, enabling randomized/cloned items.
    """

    type: Literal["pci"] = "pci"
    prompt: MarkdownStr | None = None
    label: str | None = None

    interaction_type: str = Field(
        description=(
            "Registered module name (e.g. 'number-line-question') or custom "
            "URN (e.g. 'urn:fdc:myorg:pci:my-widget'). Registered modules "
            "auto-resolve module, data_item_path_uri, and primary_configuration "
            "from the built-in registry. Custom URNs require explicit module "
            "and data_item_path_uri."
        ),
    )

    module: str | None = Field(
        default=None,
        description=(
            "JS module name the player loads. Auto-resolved for registered "
            "modules. Required for custom interaction_type values."
        ),
    )
    data_item_path_uri: str | None = Field(
        default=None,
        description=(
            "Base URL where the PCI module is hosted. Auto-resolved for "
            "registered modules. Required for custom interaction_type values."
        ),
    )
    primary_configuration: str | None = Field(
        default=None,
        description=(
            "Module resolution manifest path. Defaults to "
            "'modules/module_resolution.json' for registered modules."
        ),
    )

    data_attributes: dict[str, str] = Field(
        default_factory=dict,
        description=(
            "Data-attribute key-value pairs set directly on the PCI element. "
            "The module reads these via element.getAttribute(). Keys are full "
            "attribute names (e.g. 'data-steps', 'data-graph-x-min'). Values "
            "are always strings. This is what the platform's registered modules "
            "use — if using a registered module, this is the only config "
            "channel you need."
        ),
    )
    properties: dict[str, Any] | None = Field(
        default=None,
        description=(
            "Structured config the player passes as the `config` argument to "
            "the module's getInstance(dom, config, stateMap). Supports nested "
            "dicts. Use when the PCI module reads config from the getInstance "
            "config parameter rather than from data attributes. Not needed for "
            "registered modules."
        ),
    )
    interaction_markup: str | None = Field(
        default=None,
        description=(
            "HTML content the player passes as the `dom` argument to "
            "getInstance(). Use when the PCI module expects pre-built HTML "
            "to enhance rather than rendering from scratch. Not needed for "
            "registered modules."
        ),
    )
    template_variable_mappings: list[PCITemplateMapping] | None = Field(
        default=None,
        description=(
            "Maps QTI template variables to PCI config properties, enabling "
            "randomized items. Each entry emits a <qti-template-variable> "
            "element. Requires QuestionItem.template to define the referenced "
            "template variables."
        ),
    )

    correct_values: list[str] | None = Field(
        default=None,
        description=(
            "Correct response values for the PCI response declaration. "
            "Format depends on module: space-separated 'x y' for point type, "
            "decimal for float type, string for string type. "
            "Each entry becomes a <qti-value> inside <qti-correct-response>."
        ),
    )

    scoring: Literal["match-correct", "external"] = "external"
    score_expression: ScoreExpression | None = None
    target_dimension: str | None = None

    @model_validator(mode="after")
    def _validate_pci_resolution(self) -> PCIConfig:
        registry_entry = PCI_MODULE_REGISTRY.get(self.interaction_type)
        if registry_entry is None and (
            self.module is None or self.data_item_path_uri is None
        ):
            registered = ", ".join(sorted(PCI_MODULE_REGISTRY.keys()))
            raise ValidationError(
                f"PCI interaction_type '{self.interaction_type}' is not a registered "
                f"module. Provide explicit module and data_item_path_uri, or use a "
                f"registered module: {registered}"
            )
        return self


Interaction = Annotated[
    Union[
        ChoiceConfig,
        TextEntryConfig,
        ExtendedTextConfig,
        MatchConfig,
        OrderConfig,
        MediaConfig,
        PCIConfig,
    ],
    Field(discriminator="type"),
]
"""Discriminated union of all interaction config types."""
