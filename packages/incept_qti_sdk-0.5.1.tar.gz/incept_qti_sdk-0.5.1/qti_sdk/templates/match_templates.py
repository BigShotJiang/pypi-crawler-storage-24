"""Response processing templates for MatchConfig behaviors."""

from __future__ import annotations

from lxml import etree

from ..models.behaviors import ExternalGraded, FeedbackEnabled, SummativeBehavior
from ..models.interactions import MatchConfig
from ..models.question_item import QuestionItem
from ._helpers import (
    append_completion_status_rule,
    infer_completion_ceiling,
    resolved_show_condition,
    scaffold_outcome_for,
    set_outcome,
)
from ._scoring import build_score_rule


def _build_correct_match(response_id: str = "RESPONSE") -> etree._Element:
    """``<qti-match>`` comparing RESPONSE against its correct response (set-level)."""
    match = etree.Element("qti-match")
    etree.SubElement(match, "qti-variable", attrib={"identifier": response_id})
    etree.SubElement(match, "qti-correct", attrib={"identifier": response_id})
    return match


def _build_show_condition(parent: etree._Element, show) -> None:
    """Translate a ``ShowCondition`` into QTI RP condition elements."""
    parts: list[etree._Element] = []

    if show.after_attempt is not None:
        gte = etree.Element("qti-gte")
        etree.SubElement(gte, "qti-variable", attrib={"identifier": "numAttempts"})
        bv = etree.SubElement(gte, "qti-base-value", attrib={"base-type": "integer"})
        bv.text = str(show.after_attempt)
        parts.append(gte)

    if show.on_correct is False:
        lt = etree.Element("qti-lt")
        etree.SubElement(lt, "qti-variable", attrib={"identifier": "SCORE"})
        etree.SubElement(lt, "qti-variable", attrib={"identifier": "MAXSCORE"})
        parts.append(lt)
    elif show.on_correct is True:
        gte = etree.Element("qti-gte")
        etree.SubElement(gte, "qti-variable", attrib={"identifier": "SCORE"})
        etree.SubElement(gte, "qti-variable", attrib={"identifier": "MAXSCORE"})
        parts.append(gte)

    if len(parts) > 1:
        and_el = etree.SubElement(parent, "qti-and")
        for p in parts:
            and_el.append(p)
    elif parts:
        parent.append(parts[0])


def _append_scaffold_triggers(
    rp: etree._Element,
    item: QuestionItem,
    config: MatchConfig,
) -> None:
    """Append scaffold RP conditions (hint, solution_steps, etc.) derived
    from ``Feedback`` entries and ``FeedbackPolicy`` defaults."""
    behavior: FeedbackEnabled = item.behavior  # type: ignore[assignment]
    all_fb = list(config.feedback) + list(item.feedback)
    for mi in config.source_set + config.target_set:
        all_fb.extend(getattr(mi, "feedback", []))

    seen: set[str] = set()
    for fb in all_fb:
        entry = scaffold_outcome_for(fb)
        if entry is None or fb.type in seen:
            continue
        seen.add(fb.type)
        outcome_id, element_id = entry
        show = resolved_show_condition(behavior, fb)
        if show is None:
            continue
        cond = etree.SubElement(rp, "qti-response-condition")
        if_el = etree.SubElement(cond, "qti-response-if")
        _build_show_condition(if_el, show)
        set_outcome(if_el, outcome_id, "identifier", element_id)


class MatchTemplates:
    """Generates ``<qti-response-processing>`` for match interaction behaviors."""

    @staticmethod
    def get(
        item: QuestionItem,
        config: MatchConfig,
        *,
        response_id: str = "RESPONSE",
        score_id: str = "SCORE",
        feedback_id: str = "FEEDBACK",
    ) -> etree._Element | None:
        if isinstance(item.behavior, ExternalGraded):
            return None

        rp = etree.Element("qti-response-processing")
        is_adaptive = (
            isinstance(item.behavior, FeedbackEnabled)
            and item.behavior.adaptive
        )
        has_feedback = isinstance(item.behavior, FeedbackEnabled)
        fb_id = feedback_id if has_feedback else None

        for el in MatchTemplates.get_interaction_rp(
            item, config, response_id, score_id, fb_id,
            include_completion=is_adaptive,
        ):
            rp.append(el)

        if is_adaptive:
            append_completion_status_rule(rp, infer_completion_ceiling(item))

        if has_feedback:
            _append_scaffold_triggers(rp, item, config)

        return rp

    @staticmethod
    def get_interaction_rp(
        item: QuestionItem,
        config: MatchConfig,
        response_id: str,
        score_id: str,
        feedback_id: str | None,
        *,
        include_completion: bool = False,
    ) -> list[etree._Element]:
        """Return per-interaction RP fragments (no wrapper, no scaffolding)."""
        if isinstance(item.behavior, ExternalGraded):
            return []

        container = etree.Element("_container")
        non_binary = build_score_rule(container, config, response_id, score_id)

        has_feedback = feedback_id is not None
        needs_condition = has_feedback or not non_binary or include_completion
        if needs_condition:
            cond = etree.SubElement(container, "qti-response-condition")
            if_el = etree.SubElement(cond, "qti-response-if")
            if_el.append(_build_correct_match(response_id))
            if not non_binary:
                set_outcome(if_el, score_id, "float", "1")
            if has_feedback:
                set_outcome(if_el, feedback_id, "identifier", "correct")

            else_el = etree.SubElement(cond, "qti-response-else")
            if not non_binary:
                set_outcome(else_el, score_id, "float", "0")
            if has_feedback:
                set_outcome(else_el, feedback_id, "identifier", "incorrect")

        return list(container)
