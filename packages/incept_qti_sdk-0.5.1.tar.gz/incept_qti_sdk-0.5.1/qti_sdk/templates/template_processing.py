"""Generate ``<qti-template-declaration>`` and ``<qti-template-processing>`` elements.

Consumes :class:`TemplateConfig` and optional ``correct_expression`` from
:class:`TextEntryConfig` to emit QTI 3.0 template variable declarations and
the processing block that sets random values, enforces constraints, computes
derived values, and sets correct responses dynamically.
"""

from __future__ import annotations

from typing import Sequence

from lxml import etree

from ..exceptions import BuildError
from ..models.base import TemplateConfig, TemplateVariable
from .expression_parser import infer_result_type, parse_arithmetic, parse_constraint


def build_template_declarations(
    template: TemplateConfig,
    correct_expression: str | dict[str, str] | None = None,
    response_id: str = "RESPONSE",
) -> list[etree._Element]:
    """Build ``<qti-template-declaration>`` elements for all template variables.

    Includes:
    - One declaration per ``template.variables`` entry
    - One declaration per ``template.computed_values`` entry
    - Hidden ANSWER declarations when *correct_expression* is present
    """
    decls: list[etree._Element] = []
    for var in template.variables:
        decls.append(_build_var_declaration(var))

    if template.computed_values:
        for name, _expr in template.computed_values.items():
            decls.append(
                _make_declaration(
                    name, template.answer_type, math_variable=True,
                ),
            )

    if correct_expression is not None:
        if isinstance(correct_expression, str):
            decls.append(
                _make_declaration("ANSWER", template.answer_type, math_variable=True),
            )
        else:
            for blank_id in sorted(correct_expression.keys()):
                var_name = _answer_var_name(blank_id, response_id)
                decls.append(
                    _make_declaration(var_name, template.answer_type, math_variable=True),
                )

    return decls


def build_template_processing(
    template: TemplateConfig,
    correct_expression: str | dict[str, str] | None = None,
    response_id: str = "RESPONSE",
) -> etree._Element:
    """Build the ``<qti-template-processing>`` element.

    Contents (in order):

    1. ``<qti-set-template-value>`` for each random variable
    2. ``<qti-template-constraint>`` for each constraint
    3. ``<qti-set-template-value>`` for each computed value
    4. ``<qti-set-template-value identifier="ANSWER">`` from correct_expression
    5. ``<qti-set-correct-response>`` to populate the response declaration
    """
    known_vars = {v.name for v in template.variables}
    if template.computed_values:
        known_vars |= set(template.computed_values.keys())

    known_var_types: dict[str, str] = {v.name: v.type for v in template.variables}

    tp = etree.Element("qti-template-processing")

    # 1. Random variable assignments
    for var in template.variables:
        tp.append(_build_random_assignment(var))

    # 2. Constraints
    if template.constraints:
        for constraint_str in template.constraints:
            tc = etree.SubElement(tp, "qti-template-constraint")
            tc.append(parse_constraint(constraint_str, known_vars))

    # 3. Computed values
    if template.computed_values:
        for name, expr_str in template.computed_values.items():
            expr_el = parse_arithmetic(expr_str, known_vars)
            _check_expression_type(
                expr_el, template.answer_type, known_var_types,
                label=f"computed value '{name}'", expr_source=expr_str,
            )
            known_var_types[name] = template.answer_type
            stv = etree.SubElement(
                tp, "qti-set-template-value", attrib={"identifier": name},
            )
            stv.append(expr_el)

    # 4 + 5. correct_expression -> set ANSWER template var + set correct response
    if correct_expression is not None:
        if isinstance(correct_expression, str):
            _append_correct_single(
                tp, correct_expression, response_id,
                template.answer_type, known_vars, known_var_types,
            )
        else:
            _append_correct_multi(
                tp, correct_expression, response_id,
                template.answer_type, known_vars, known_var_types,
            )

    return tp


# ── Helpers ─────────────────────────────────────────────────────────


def _build_var_declaration(var: TemplateVariable) -> etree._Element:
    """Build a single ``<qti-template-declaration>`` for a TemplateVariable."""
    el = _make_declaration(var.name, var.type, math_variable=True)
    if var.default is not None:
        dv = etree.SubElement(el, "qti-default-value")
        v = etree.SubElement(dv, "qti-value")
        v.text = str(var.default)
    return el


def _make_declaration(
    identifier: str,
    base_type: str,
    *,
    math_variable: bool = False,
) -> etree._Element:
    attrib: dict[str, str] = {
        "identifier": identifier,
        "cardinality": "single",
        "base-type": base_type,
    }
    if math_variable:
        attrib["math-variable"] = "true"
    return etree.Element("qti-template-declaration", attrib=attrib)


def _build_random_assignment(var: TemplateVariable) -> etree._Element:
    """Build ``<qti-set-template-value>`` with a random-integer or random-float child."""
    stv = etree.Element(
        "qti-set-template-value", attrib={"identifier": var.name},
    )
    if var.type == "integer":
        etree.SubElement(
            stv, "qti-random-integer",
            attrib={
                "min": str(int(var.min)),
                "max": str(int(var.max)),
                "step": str(int(var.step)),
            },
        )
    else:
        attrib: dict[str, str] = {
            "min": str(var.min),
            "max": str(var.max),
        }
        etree.SubElement(stv, "qti-random-float", attrib=attrib)
    return stv


def _check_expression_type(
    expr_el: etree._Element,
    answer_type: str,
    known_var_types: dict[str, str],
    *,
    label: str,
    expr_source: str,
) -> None:
    """Raise ``BuildError`` if the expression result type conflicts with *answer_type*."""
    result_type = infer_result_type(expr_el, known_var_types)
    if result_type == "float" and answer_type == "integer":
        raise BuildError(
            f'{label} expression "{expr_source}" produces float '
            f'(qti-divide always returns float) but answer_type is "integer". '
            f'Use "//" for integer division or change answer_type to "float".'
        )


def _answer_var_name(blank_id: str, response_id: str) -> str:
    """ANSWER variable name for a multi-blank item: ``ANSWER_BLANK_1``."""
    suffix = blank_id.upper().replace("-", "_")
    return f"ANSWER_{suffix}"


def _response_id_for_blank(blank_id: str, response_id: str) -> str:
    """Response variable name for a multi-blank: ``RESPONSE_BLANK_1``."""
    suffix = blank_id.upper().replace("-", "_")
    return f"{response_id}_{suffix}"


def _append_correct_single(
    parent: etree._Element,
    expr_str: str,
    response_id: str,
    answer_type: str,
    known_vars: set[str],
    known_var_types: dict[str, str] | None = None,
) -> None:
    """Append ANSWER set-template-value and set-correct-response for single-blank."""
    expr_el = parse_arithmetic(expr_str, known_vars)
    _check_expression_type(
        expr_el, answer_type, known_var_types or {},
        label="correct_expression", expr_source=expr_str,
    )
    stv = etree.SubElement(
        parent, "qti-set-template-value", attrib={"identifier": "ANSWER"},
    )
    stv.append(expr_el)

    scr = etree.SubElement(
        parent, "qti-set-correct-response",
        attrib={"identifier": response_id},
    )
    v = etree.SubElement(scr, "qti-value")
    pv = etree.SubElement(
        v, "qti-variable", attrib={"identifier": "ANSWER"},
    )


def _append_correct_multi(
    parent: etree._Element,
    expr_dict: dict[str, str],
    response_id: str,
    answer_type: str,
    known_vars: set[str],
    known_var_types: dict[str, str] | None = None,
) -> None:
    """Append per-blank ANSWER set-template-values and set-correct-responses."""
    var_types = known_var_types or {}
    for blank_id in sorted(expr_dict.keys()):
        answer_name = _answer_var_name(blank_id, response_id)
        rid = _response_id_for_blank(blank_id, response_id)

        expr_el = parse_arithmetic(expr_dict[blank_id], known_vars)
        _check_expression_type(
            expr_el, answer_type, var_types,
            label=f"correct_expression['{blank_id}']",
            expr_source=expr_dict[blank_id],
        )
        stv = etree.SubElement(
            parent, "qti-set-template-value",
            attrib={"identifier": answer_name},
        )
        stv.append(expr_el)

        scr = etree.SubElement(
            parent, "qti-set-correct-response",
            attrib={"identifier": rid},
        )
        v = etree.SubElement(scr, "qti-value")
        pv = etree.SubElement(
            v, "qti-variable", attrib={"identifier": answer_name},
        )
