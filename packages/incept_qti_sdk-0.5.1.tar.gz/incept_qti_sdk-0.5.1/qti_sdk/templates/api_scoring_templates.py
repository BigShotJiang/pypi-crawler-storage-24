"""Response processing templates for API-based scoring via qti-custom-operator.

Generates the 3-step response processing pattern:
1. Call grading API via custom operator, store result in GRADING_RESPONSE
2. Extract fields from the record into individual outcome variables
3. Conditionals for completionStatus and optionally PASSED
"""

from __future__ import annotations

from lxml import etree

from ..models.behaviors import FeedbackEnabled
from ..models.question_item import QuestionItem
from ._helpers import infer_completion_ceiling, set_outcome

_CUSTOM_OPERATOR_CLASS = "com.alpha-1edtech.ExternalApiScore"

_STANDARD_EXTRACTIONS: list[tuple[str, str]] = [
    ("SCORE", "scoreGiven"),
    ("MAXSCORE", "scoreMaximum"),
    ("COMMENT", "comment"),
]

_FEEDBACK_EXTRACTIONS: list[tuple[str, str]] = [
    ("GENERATED_FEEDBACK", "htmlComment"),
]


class ApiScoringTemplates:
    """Generates ``<qti-response-processing>`` for API-scored items."""

    @staticmethod
    def get(item: QuestionItem) -> etree._Element:
        """Build complete response processing for an API-scored item.

        Assumes ``item.api_scoring`` is not None.
        """
        assert item.api_scoring is not None

        rp = etree.Element("qti-response-processing")
        api = item.api_scoring
        is_adaptive = (
            isinstance(item.behavior, FeedbackEnabled) and item.behavior.adaptive
        )
        has_feedback = isinstance(item.behavior, FeedbackEnabled)

        # Step 1: Call API
        _append_api_call(rp, api.endpoint)

        # Step 2: Extract fields
        _append_field_extractions(rp, item)

        if has_feedback:
            set_outcome(
                rp,
                "GENERATED_FEEDBACK_VISIBILITY",
                "identifier",
                "visible",
            )

        # Step 3: Conditionals
        if is_adaptive:
            _append_completion_status(rp, item)

        if api.mastery_value is not None:
            _append_passed_conditional(rp, api.mastery_value)

        return rp


def _append_api_call(rp: etree._Element, endpoint: str) -> None:
    """Step 1: Set GRADING_RESPONSE from custom operator."""
    sov = etree.SubElement(
        rp,
        "qti-set-outcome-value",
        attrib={"identifier": "GRADING_RESPONSE"},
    )
    etree.SubElement(
        sov,
        "qti-custom-operator",
        attrib={
            "class": _CUSTOM_OPERATOR_CLASS,
            "definition": endpoint,
        },
    )


def _append_field_extraction(
    parent: etree._Element,
    outcome_id: str,
    field_id: str,
) -> None:
    """Emit a single field-value extraction from GRADING_RESPONSE."""
    sov = etree.SubElement(
        parent,
        "qti-set-outcome-value",
        attrib={"identifier": outcome_id},
    )
    fv = etree.SubElement(
        sov,
        "qti-field-value",
        attrib={"field-identifier": field_id},
    )
    etree.SubElement(fv, "qti-variable", attrib={"identifier": "GRADING_RESPONSE"})


def _append_field_extractions(rp: etree._Element, item: QuestionItem) -> None:
    """Step 2: Extract all fields from GRADING_RESPONSE."""
    assert item.api_scoring is not None
    has_feedback = isinstance(item.behavior, FeedbackEnabled)

    if has_feedback:
        for outcome_id, field_id in _FEEDBACK_EXTRACTIONS:
            _append_field_extraction(rp, outcome_id, field_id)

    for outcome_id, field_id in _STANDARD_EXTRACTIONS:
        _append_field_extraction(rp, outcome_id, field_id)

    if item.api_scoring.extra_fields:
        for ef in item.api_scoring.extra_fields:
            _append_field_extraction(rp, ef.outcome_identifier, ef.api_field)


def _build_score_gte(
    item: QuestionItem,
) -> etree._Element:
    """Build the SCORE >= threshold comparison.

    Uses mastery_value literal when set, otherwise MAXSCORE variable.
    """
    assert item.api_scoring is not None
    gte = etree.Element("qti-gte")
    etree.SubElement(gte, "qti-variable", attrib={"identifier": "SCORE"})

    if item.api_scoring.mastery_value is not None:
        bv = etree.SubElement(
            gte,
            "qti-base-value",
            attrib={"base-type": "float"},
        )
        bv.text = str(item.api_scoring.mastery_value)
    else:
        etree.SubElement(gte, "qti-variable", attrib={"identifier": "MAXSCORE"})

    return gte


def _append_completion_status(
    rp: etree._Element,
    item: QuestionItem,
) -> None:
    """Step 3a: completionStatus conditional (adaptive items only)."""
    ceiling = infer_completion_ceiling(item)
    cond = etree.SubElement(rp, "qti-response-condition")
    if_el = etree.SubElement(cond, "qti-response-if")

    score_gte = _build_score_gte(item)

    or_el = etree.SubElement(if_el, "qti-or")
    or_el.append(score_gte)

    attempts_gte = etree.SubElement(or_el, "qti-gte")
    etree.SubElement(
        attempts_gte,
        "qti-variable",
        attrib={"identifier": "numAttempts"},
    )
    bv = etree.SubElement(
        attempts_gte,
        "qti-base-value",
        attrib={"base-type": "integer"},
    )
    bv.text = str(ceiling)

    set_outcome(if_el, "completionStatus", "identifier", "completed")

    else_el = etree.SubElement(cond, "qti-response-else")
    set_outcome(else_el, "completionStatus", "identifier", "incomplete")


def _append_passed_conditional(
    rp: etree._Element,
    mastery_value: float,
) -> None:
    """Step 3b: PASSED conditional (only when mastery_value is set)."""
    cond = etree.SubElement(rp, "qti-response-condition")
    if_el = etree.SubElement(cond, "qti-response-if")

    gte = etree.SubElement(if_el, "qti-gte")
    etree.SubElement(gte, "qti-variable", attrib={"identifier": "SCORE"})
    bv = etree.SubElement(gte, "qti-base-value", attrib={"base-type": "float"})
    bv.text = str(mastery_value)

    set_outcome(if_el, "PASSED", "boolean", "true")
