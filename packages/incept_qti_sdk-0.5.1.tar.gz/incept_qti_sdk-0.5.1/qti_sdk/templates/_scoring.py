"""Scoring utilities shared across all response processing templates.

Provides:
- ``derive_interaction_max()`` / ``derive_item_normal_maximum()`` for
  computing ``normal-maximum`` on outcome declarations.
- ``build_score_rule()`` for appending the score computation step to
  response processing based on the scoring priority chain.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Union

from lxml import etree

from ..models.interactions import (
    ChoiceConfig,
    ExtendedTextConfig,
    MatchConfig,
    MediaConfig,
    OrderConfig,
    PCIConfig,
    TextEntryConfig,
)
from ..models.scoring import ChoiceScoreMap, MatchScoreMap, TextEntryScoreMap
from .score_expression_compiler import compile_score_expression

if TYPE_CHECKING:
    from ..models.question_item import QuestionItem

Interaction = Union[
    ChoiceConfig, TextEntryConfig, ExtendedTextConfig,
    MatchConfig, MediaConfig, OrderConfig, PCIConfig,
]


def derive_interaction_max(item: QuestionItem, config: Interaction) -> float:
    """Derive the normal-maximum score for a single interaction.

    Priority: score_expression (needs explicit max_score) > score_map > partial_credit > binary.
    MediaConfig contributes 0 (play count only, no scoring).
    """
    if isinstance(config, MediaConfig):
        return 0.0

    score_expr = getattr(config, "score_expression", None)
    if score_expr is not None:
        if item.max_score is not None:
            return item.max_score
        td = getattr(config, "target_dimension", None)
        if td and item.scoring_dimensions:
            for dim in item.scoring_dimensions:
                if dim.name == td:
                    return dim.max_score
        return 1.0

    score_map = getattr(config, "score_map", None)
    if score_map is not None:
        if isinstance(score_map, (ChoiceScoreMap, TextEntryScoreMap)):
            ub = getattr(score_map, "upper_bound", None)
            if ub is not None:
                return ub
            return max(score_map.entries.values()) if score_map.entries else 1.0
        if isinstance(score_map, MatchScoreMap):
            if score_map.upper_bound is not None:
                return score_map.upper_bound
            return sum(e.score for e in score_map.entries if e.score > 0) if score_map.entries else 1.0

    if isinstance(config, OrderConfig) and config.partial_credit:
        return float(len(config.items))

    return 1.0


def derive_item_normal_maximum(item: QuestionItem) -> float:
    """Derive the item-level normal-maximum for the SCORE outcome."""
    if item.max_score is not None:
        return item.max_score
    if item.scoring_dimensions:
        return sum(d.max_score for d in item.scoring_dimensions)
    return sum(
        derive_interaction_max(item, config)
        for config in item.interactions
    )


def build_score_rule(
    parent: etree._Element,
    config: Interaction,
    response_id: str = "RESPONSE",
    score_id: str = "SCORE",
) -> bool:
    """Append score computation rules to *parent* based on scoring priority chain.

    Returns ``True`` if scoring was handled (map/expression/partial_credit),
    ``False`` if the caller should use binary scoring (SCORE=1/0 inline).
    """
    score_expr = getattr(config, "score_expression", None)
    if score_expr is not None:
        sov = etree.SubElement(
            parent, "qti-set-outcome-value", attrib={"identifier": score_id}
        )
        sov.append(compile_score_expression(score_expr))
        return True

    score_map = getattr(config, "score_map", None)
    if score_map is not None:
        sov = etree.SubElement(
            parent, "qti-set-outcome-value", attrib={"identifier": score_id}
        )
        etree.SubElement(
            sov, "qti-map-response", attrib={"identifier": response_id}
        )
        return True

    if isinstance(config, OrderConfig) and config.partial_credit:
        _build_order_partial_credit(parent, config, response_id, score_id)
        return True

    return False


def _build_order_partial_credit(
    parent: etree._Element,
    config: OrderConfig,
    response_id: str,
    score_id: str,
) -> None:
    """Append per-position ``qti-index`` checks for order partial credit scoring."""
    for i, correct_id in enumerate(config.correct_order):
        cond = etree.SubElement(parent, "qti-response-condition")
        if_el = etree.SubElement(cond, "qti-response-if")

        match = etree.SubElement(if_el, "qti-match")
        index = etree.SubElement(match, "qti-index", attrib={"n": str(i + 1)})
        etree.SubElement(index, "qti-variable", attrib={"identifier": response_id})
        bv = etree.SubElement(match, "qti-base-value", attrib={"base-type": "identifier"})
        bv.text = correct_id

        sov = etree.SubElement(if_el, "qti-set-outcome-value", attrib={"identifier": score_id})
        sum_el = etree.SubElement(sov, "qti-sum")
        etree.SubElement(sum_el, "qti-variable", attrib={"identifier": score_id})
        point_val = etree.SubElement(sum_el, "qti-base-value", attrib={"base-type": "float"})
        point_val.text = "1"
