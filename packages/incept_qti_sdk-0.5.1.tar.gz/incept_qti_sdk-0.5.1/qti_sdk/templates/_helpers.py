"""Shared helpers for response processing template generation."""

from __future__ import annotations

from lxml import etree

from ..models.base import Feedback, ShowCondition, WorkedExampleContent
from ..models.behaviors import FeedbackEnabled
from ..models.question_item import QuestionItem


_SCAFFOLD_OUTCOME_MAP: dict[str, tuple[str, str]] = {
    "hint": ("HINT_FEEDBACK", "hint_feedback"),
    "learning_content": ("LEARNING_CONTENT_FEEDBACK", "learning_content_feedback"),
    "answer_reveal": ("REVEAL_ANSWER_FEEDBACK", "reveal_answer_feedback"),
}


def scaffold_outcome_for(fb: Feedback) -> tuple[str, str] | None:
    """Return ``(outcome_id, element_id)`` for a scaffold feedback entry.

    For ``solution_steps``, the mapping depends on content type:
    - ``WorkedExampleContent`` -> renderer extension identifiers
    - plain string -> legacy identifiers
    """
    if fb.type == "solution_steps":
        if isinstance(fb.content, WorkedExampleContent):
            return ("WORKED_EXAMPLE_FEEDBACK", "worked_example_feedback")
        return ("WORKED_SOLUTION_FEEDBACK", "worked_solution_feedback")
    return _SCAFFOLD_OUTCOME_MAP.get(fb.type)


def set_outcome(
    parent: etree._Element,
    identifier: str,
    base_type: str,
    value: str,
) -> None:
    """Append a ``<qti-set-outcome-value>`` with a base-value child."""
    sov = etree.SubElement(
        parent, "qti-set-outcome-value", attrib={"identifier": identifier}
    )
    bv = etree.SubElement(sov, "qti-base-value", attrib={"base-type": base_type})
    bv.text = value


def append_gte_attempts(parent: etree._Element, threshold: int) -> None:
    """Append a ``<qti-gte>`` comparing ``numAttempts`` to *threshold*."""
    gte = etree.SubElement(parent, "qti-gte")
    etree.SubElement(gte, "qti-variable", attrib={"identifier": "numAttempts"})
    bv = etree.SubElement(gte, "qti-base-value", attrib={"base-type": "integer"})
    bv.text = str(threshold)


def build_modal_feedback_rp(rp: etree._Element) -> None:
    """Append MODAL_FEEDBACK level comparison to response processing.

    Sets MODAL_FEEDBACK to ``"modal_feedback_correct"`` when SCORE >= MAXSCORE,
    ``"modal_feedback_partial"`` when SCORE > 0, ``"modal_feedback_incorrect"``
    otherwise.
    """
    cond = etree.SubElement(rp, "qti-response-condition")

    # correct: SCORE >= MAXSCORE
    if_el = etree.SubElement(cond, "qti-response-if")
    gte = etree.SubElement(if_el, "qti-gte")
    etree.SubElement(gte, "qti-variable", attrib={"identifier": "SCORE"})
    etree.SubElement(gte, "qti-variable", attrib={"identifier": "MAXSCORE"})
    set_outcome(if_el, "MODAL_FEEDBACK", "identifier", "modal_feedback_correct")

    # partial: SCORE > 0
    elif_el = etree.SubElement(cond, "qti-response-else-if")
    gt = etree.SubElement(elif_el, "qti-gt")
    etree.SubElement(gt, "qti-variable", attrib={"identifier": "SCORE"})
    bv_zero = etree.SubElement(gt, "qti-base-value", attrib={"base-type": "float"})
    bv_zero.text = "0"
    set_outcome(elif_el, "MODAL_FEEDBACK", "identifier", "modal_feedback_partial")

    # incorrect: else
    else_el = etree.SubElement(cond, "qti-response-else")
    set_outcome(else_el, "MODAL_FEEDBACK", "identifier", "modal_feedback_incorrect")


def collect_all_feedback(item: QuestionItem) -> list[Feedback]:
    """Collect feedback entries across item, interactions, and nested entries."""
    all_fb: list[Feedback] = list(item.feedback)
    for interaction in item.interactions:
        all_fb.extend(getattr(interaction, "feedback", []))
        for attr in ("choices", "items", "source_set", "target_set"):
            for sub in getattr(interaction, attr, []):
                all_fb.extend(getattr(sub, "feedback", []))
    return all_fb


def infer_completion_ceiling(item: QuestionItem) -> int:
    """Infer adaptive completion ceiling from feedback thresholds and policy."""
    if not isinstance(item.behavior, FeedbackEnabled):
        return 1

    behavior: FeedbackEnabled = item.behavior
    thresholds: list[int] = []
    for fb in collect_all_feedback(item):
        show = fb.show_when or getattr(behavior.policy, fb.type, None)
        if show is not None and show.after_attempt is not None:
            thresholds.append(show.after_attempt)
    return max([*thresholds, behavior.policy.completion_after])


def resolved_show_condition(behavior: FeedbackEnabled, fb: Feedback) -> ShowCondition | None:
    """Resolve a feedback show condition and normalize non-adaptive attempt gates."""
    show = fb.show_when or getattr(behavior.policy, fb.type, None)
    if show is None:
        return None
    if not behavior.adaptive and show.after_attempt is not None:
        return show.model_copy(update={"after_attempt": 1})
    return show


def append_completion_status_rule(rp: etree._Element, ceiling: int) -> None:
    """Set completionStatus to completed when score is max or attempts hit ceiling."""
    cond = etree.SubElement(rp, "qti-response-condition")

    if_el = etree.SubElement(cond, "qti-response-if")
    or_el = etree.SubElement(if_el, "qti-or")

    score_gte = etree.SubElement(or_el, "qti-gte")
    etree.SubElement(score_gte, "qti-variable", attrib={"identifier": "SCORE"})
    etree.SubElement(score_gte, "qti-variable", attrib={"identifier": "MAXSCORE"})

    attempts_gte = etree.SubElement(or_el, "qti-gte")
    etree.SubElement(attempts_gte, "qti-variable", attrib={"identifier": "numAttempts"})
    bv = etree.SubElement(attempts_gte, "qti-base-value", attrib={"base-type": "integer"})
    bv.text = str(ceiling)

    set_outcome(if_el, "completionStatus", "identifier", "completed")

    else_el = etree.SubElement(cond, "qti-response-else")
    set_outcome(else_el, "completionStatus", "identifier", "incomplete")
