"""Generate the CurriculumKey enum from registry.json."""

from __future__ import annotations

import json
from pathlib import Path

_REGISTRY_PATH = Path(__file__).parent / "registry.json"
_KEYS_PATH = Path(__file__).parent / "keys.py"

_HEADER = '''\
"""Auto-generated curriculum key enum. DO NOT EDIT BY HAND.

Regenerate with: python -m qti_sdk generate-keys
"""

from __future__ import annotations

from enum import Enum


class CurriculumKey(str, Enum):
    """Known curriculum registry keys.

    Each member's value is the registry key string used in
    ``ItemPackaging.curriculum``.  Use these instead of raw strings
    for IDE autocomplete and typo protection.

    Regenerate with ``python -m qti_sdk generate-keys``.
    """

'''


def generate(
    registry_path: Path | None = None,
    output_path: Path | None = None,
) -> str:
    """Read registry.json and return the generated keys.py source code."""
    rp = registry_path or _REGISTRY_PATH
    raw: dict = json.loads(rp.read_text(encoding="utf-8"))

    lines = [_HEADER]
    for key, entry in raw.items():
        doc = entry.get("document_title", "")
        course = entry.get("course_title", "")
        comment = f"{doc} / {course}" if doc or course else ""
        if comment:
            lines.append(f"    # {comment}")
        lines.append(f"    {key} = {key!r}")
        lines.append("")

    source = "\n".join(lines).rstrip() + "\n"

    op = output_path or _KEYS_PATH
    op.write_text(source, encoding="utf-8")

    return source
