"""Curriculum registry for mapping friendly keys to CASE document/course UUIDs."""

from .keys import CurriculumKey
from .registry import CourseEntry, get_course, load_registry, save_registry


def list_curricula() -> dict[str, CourseEntry]:
    """Return all registered curriculum entries.

    Convenience wrapper around :func:`load_registry` for SDK consumers::

        from qti_sdk.curriculum import list_curricula

        for key, info in list_curricula().items():
            print(f"{key}: {info.document_title} / {info.course_title}")
    """
    return load_registry()


__all__ = [
    "CourseEntry",
    "CurriculumKey",
    "get_course",
    "list_curricula",
    "load_registry",
    "save_registry",
]
