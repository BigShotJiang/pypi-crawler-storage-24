"""OpenAI monkey-patch + proxy instrumentation for TuringPulse.

Two usage patterns:

1. **Patch** (global, affects all OpenAI calls)::

    from turingpulse_sdk_openai import patch_openai, unpatch_openai
    patch_openai(name="My Workflow")
    # ... all openai.ChatCompletion.create() calls are now instrumented
    unpatch_openai()

2. **Proxy** (explicit, per-client)::

    from turingpulse_sdk_openai import OpenAIProxy
    client = OpenAIProxy(openai.OpenAI(), name="My Workflow")
    client.chat.completions.create(...)
"""

from __future__ import annotations

import logging
from contextvars import ContextVar
from typing import Any, Optional

from turingpulse_sdk import instrument, GovernanceDirective
from turingpulse_sdk.config import MAX_FIELD_SIZE
from turingpulse_sdk.context import current_context
from turingpulse_sdk.exceptions import ConfigurationError
from turingpulse_sdk.integrations.base import _LLMClientProxy

logger = logging.getLogger("turingpulse.sdk.openai")

_INSTRUMENTING: ContextVar[bool] = ContextVar("_tp_openai_instrumenting", default=False)

_ORIGINAL_CREATE: Any = None
_ORIGINAL_ACREATE: Any = None


def _extract_usage(response: Any) -> tuple[int, int]:
    """Extract input/output token counts from an OpenAI response."""
    usage = getattr(response, "usage", None)
    if usage is None:
        return 0, 0
    return (
        getattr(usage, "prompt_tokens", 0) or 0,
        getattr(usage, "completion_tokens", 0) or 0,
    )


def _extract_model(response: Any) -> str:
    return getattr(response, "model", "unknown")


def _set_prompt_pre_call(kwargs: dict) -> None:
    """Extract and set prompt on the context before the LLM call."""
    ctx = current_context()
    if not ctx:
        return
    messages = kwargs.get("messages", [])
    if messages:
        last_user = next((m for m in reversed(messages) if m.get("role") == "user"), None)
        system = next((m for m in messages if m.get("role") == "system"), None)
        if last_user:
            ctx.set_prompt(
                str(last_user.get("content", ""))[:MAX_FIELD_SIZE],
                system_prompt=str(system.get("content", ""))[:MAX_FIELD_SIZE] if system else None,
            )


def _inject_stream_options(kwargs: dict) -> None:
    """Inject ``stream_options.include_usage`` so the final chunk carries token counts."""
    opts = kwargs.get("stream_options")
    if opts is None:
        kwargs["stream_options"] = {"include_usage": True}
    elif isinstance(opts, dict):
        opts.setdefault("include_usage", True)


def _enrich_context_from_stream(chunks: list, kwargs: dict) -> None:
    """Extract accumulated telemetry from consumed stream chunks and set on context."""
    ctx = current_context()
    if not ctx:
        return
    ctx.framework = "openai"
    ctx.node_type = "llm"

    text_parts: list[str] = []
    model: str | None = None
    input_tokens = 0
    output_tokens = 0

    for chunk in chunks:
        if not model:
            model = getattr(chunk, "model", None)
        choices = getattr(chunk, "choices", None)
        if choices:
            delta = getattr(choices[0], "delta", None)
            content = getattr(delta, "content", None) if delta else None
            if content:
                text_parts.append(content)
        usage = getattr(chunk, "usage", None)
        if usage:
            input_tokens = getattr(usage, "prompt_tokens", 0) or 0
            output_tokens = getattr(usage, "completion_tokens", 0) or 0

    ctx.set_tokens(input_tokens, output_tokens)
    ctx.set_model(model or "unknown", "openai")
    output_text = "".join(text_parts)
    if output_text:
        ctx.set_io(output_data=output_text[:MAX_FIELD_SIZE])

    tools_def = kwargs.get("tools")
    if tools_def:
        tool_names = []
        for t in tools_def:
            func = t.get("function") if isinstance(t, dict) else getattr(t, "function", None)
            if func:
                tname = func.get("name") if isinstance(func, dict) else getattr(func, "name", None)
                if tname:
                    tool_names.append(tname)
        if tool_names:
            ctx.available_tools = tool_names


def patch_openai(
    *,
    name: str | None = None,
    governance: Optional[GovernanceDirective] = None,
) -> None:
    """Monkey-patch ``openai.resources.chat.completions.Completions.create``.

    Requires ``name`` or ``TP_WORKFLOW_NAME`` env var to be set.
    """
    import os

    global _ORIGINAL_CREATE, _ORIGINAL_ACREATE

    effective_name = name or os.getenv("TP_WORKFLOW_NAME", "")
    if not effective_name:
        raise ConfigurationError(
            "patch_openai() requires name= or TP_WORKFLOW_NAME to be set."
        )

    try:
        from openai.resources.chat.completions import Completions, AsyncCompletions
    except ImportError as exc:
        raise ImportError("openai package is required: pip install openai>=1.78.0") from exc

    if _ORIGINAL_CREATE is not None:
        logger.warning("OpenAI is already patched — skipping duplicate patch_openai()")
        return

    _ORIGINAL_CREATE = Completions.create
    _ORIGINAL_ACREATE = AsyncCompletions.create

    @instrument(name=effective_name, governance=governance)
    def _patched_create(self_completions, *args: Any, **kwargs: Any) -> Any:
        if _INSTRUMENTING.get(False):
            return _ORIGINAL_CREATE(self_completions, *args, **kwargs)

        token = _INSTRUMENTING.set(True)
        try:
            _set_prompt_pre_call(kwargs)
            is_stream = kwargs.get("stream", False)
            if is_stream:
                _inject_stream_options(kwargs)
            response = _ORIGINAL_CREATE(self_completions, *args, **kwargs)
            if is_stream:
                return _SyncStreamEnricher(response, kwargs)
            _record_span(response, kwargs)
            return response
        finally:
            _INSTRUMENTING.reset(token)

    @instrument(name=effective_name, governance=governance)
    async def _patched_acreate(self_completions, *args: Any, **kwargs: Any) -> Any:
        if _INSTRUMENTING.get(False):
            return await _ORIGINAL_ACREATE(self_completions, *args, **kwargs)

        token = _INSTRUMENTING.set(True)
        try:
            _set_prompt_pre_call(kwargs)
            is_stream = kwargs.get("stream", False)
            if is_stream:
                _inject_stream_options(kwargs)
            response = await _ORIGINAL_ACREATE(self_completions, *args, **kwargs)
            if is_stream:
                return _AsyncStreamEnricher(response, kwargs)
            _record_span(response, kwargs)
            return response
        finally:
            _INSTRUMENTING.reset(token)

    Completions.create = _patched_create
    AsyncCompletions.create = _patched_acreate
    logger.info("OpenAI patched for TuringPulse instrumentation")


def unpatch_openai() -> None:
    """Restore original OpenAI methods."""
    global _ORIGINAL_CREATE, _ORIGINAL_ACREATE

    if _ORIGINAL_CREATE is None:
        return

    try:
        from openai.resources.chat.completions import Completions, AsyncCompletions
        Completions.create = _ORIGINAL_CREATE
        AsyncCompletions.create = _ORIGINAL_ACREATE
    except ImportError:
        pass

    _ORIGINAL_CREATE = None
    _ORIGINAL_ACREATE = None
    logger.info("OpenAI unpatched — original methods restored")


def _record_span(response: Any, kwargs: dict) -> None:
    """Populate the current execution context with OpenAI response data."""
    ctx = current_context()
    if not ctx:
        return

    ctx.framework = "openai"
    ctx.node_type = "llm"

    input_tokens, output_tokens = _extract_usage(response)
    ctx.set_tokens(input_tokens, output_tokens)
    ctx.set_model(_extract_model(response), "openai")

    tools_def = kwargs.get("tools")
    if tools_def:
        tool_names = []
        for t in tools_def:
            func = t.get("function") if isinstance(t, dict) else getattr(t, "function", None)
            if func:
                tname = func.get("name") if isinstance(func, dict) else getattr(func, "name", None)
                if tname:
                    tool_names.append(tname)
        if tool_names:
            ctx.available_tools = tool_names
    else:
        functions_def = kwargs.get("functions")
        if functions_def:
            tool_names = [
                f.get("name") if isinstance(f, dict) else getattr(f, "name", None)
                for f in functions_def
            ]
            tool_names = [n for n in tool_names if n]
            if tool_names:
                ctx.available_tools = tool_names

    choices = getattr(response, "choices", [])
    if choices:
        output = getattr(choices[0], "message", None)
        if output:
            ctx.set_io(output_data=str(getattr(output, "content", ""))[:MAX_FIELD_SIZE])

            tool_calls = getattr(output, "tool_calls", None)
            if tool_calls:
                for tc in tool_calls:
                    ctx.add_tool_call(
                        tool_name=getattr(tc.function, "name", "unknown"),
                        tool_args={"arguments": getattr(tc.function, "arguments", "")},
                        tool_id=getattr(tc, "id", None),
                    )


class OpenAIProxy(_LLMClientProxy):
    """Proxy wrapper for an OpenAI client instance.

    Usage::

        from openai import OpenAI
        from turingpulse_sdk_openai import OpenAIProxy

        client = OpenAIProxy(OpenAI(), name="My Workflow")
        response = client.chat.completions.create(model="gpt-4", messages=[...])
    """

    def __init__(
        self,
        client: Any,
        *,
        name: str,
        governance: Optional[GovernanceDirective] = None,
    ):
        super().__init__(client, provider="openai")
        object.__setattr__(self, "_tp_name", name)
        object.__setattr__(self, "_tp_governance", governance)

    @property
    def chat(self) -> Any:
        real_chat = getattr(object.__getattribute__(self, "_tp_client"), "chat")
        return _ChatProxy(
            real_chat,
            name=object.__getattribute__(self, "_tp_name"),
            governance=object.__getattribute__(self, "_tp_governance"),
        )


class _ChatProxy:
    def __init__(self, chat: Any, *, name: str, governance: Optional[GovernanceDirective]):
        self._chat = chat
        self._name = name
        self._governance = governance

    @property
    def completions(self) -> "_CompletionsProxy":
        return _CompletionsProxy(
            self._chat.completions,
            name=self._name,
            governance=self._governance,
        )

    def __getattr__(self, name: str) -> Any:
        return getattr(self._chat, name)


class _CompletionsProxy:
    def __init__(self, completions: Any, *, name: str, governance: Optional[GovernanceDirective]):
        self._completions = completions
        self._name = name
        self._governance = governance

    def create(self, **kwargs: Any) -> Any:
        @instrument(name=self._name, governance=self._governance)
        def _instrumented_create(**kw: Any) -> Any:
            if _INSTRUMENTING.get(False):
                return self._completions.create(**kw)
            token = _INSTRUMENTING.set(True)
            try:
                _set_prompt_pre_call(kw)
                is_stream = kw.get("stream", False)
                if is_stream:
                    _inject_stream_options(kw)
                response = self._completions.create(**kw)
                if is_stream:
                    return _SyncStreamEnricher(response, kw)
                _record_span(response, kw)
                return response
            finally:
                _INSTRUMENTING.reset(token)
        return _instrumented_create(**kwargs)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._completions, name)


# ======================================================================
# Stream enrichers — provider-specific chunk accumulation
# ======================================================================


class _SyncStreamEnricher:
    """Thin wrapper around an OpenAI sync ``Stream`` that enriches the context on completion.

    It delegates all iteration to the underlying stream while accumulating
    text, model, and token data.  When the stream is exhausted it calls
    ``_enrich_context_from_stream`` so that the plugin's ``_IteratorSpanWrapper``
    (which wraps this) emits a span with full metrics.

    The class also proxies ``__enter__``/``__exit__``/``close``/``.response``
    so that customer code using ``with stream:`` patterns keeps working.
    """

    __slots__ = ("_inner", "_kwargs", "_chunks", "_done")

    def __init__(self, stream: Any, kwargs: dict):
        self._inner = stream
        self._kwargs = kwargs
        self._chunks: list = []
        self._done = False

    def __iter__(self):
        return self

    def __next__(self):
        try:
            chunk = next(self._inner)
            self._chunks.append(chunk)
            return chunk
        except StopIteration:
            self._enrich()
            raise

    def __enter__(self):
        if hasattr(self._inner, "__enter__"):
            self._inner.__enter__()
        return self

    def __exit__(self, *exc_info):
        if hasattr(self._inner, "__exit__"):
            self._inner.__exit__(*exc_info)
        self._enrich()
        return False

    def close(self):
        if hasattr(self._inner, "close"):
            self._inner.close()
        self._enrich()

    @property
    def response(self):
        return getattr(self._inner, "response", None)

    def _enrich(self):
        if self._done:
            return
        self._done = True
        try:
            _enrich_context_from_stream(self._chunks, self._kwargs)
        except Exception:
            pass


class _AsyncStreamEnricher:
    """Async counterpart of ``_SyncStreamEnricher``."""

    __slots__ = ("_inner", "_kwargs", "_chunks", "_done")

    def __init__(self, stream: Any, kwargs: dict):
        self._inner = stream
        self._kwargs = kwargs
        self._chunks: list = []
        self._done = False

    def __aiter__(self):
        return self

    async def __anext__(self):
        try:
            chunk = await self._inner.__anext__()
            self._chunks.append(chunk)
            return chunk
        except StopAsyncIteration:
            self._enrich()
            raise

    async def __aenter__(self):
        if hasattr(self._inner, "__aenter__"):
            await self._inner.__aenter__()
        return self

    async def __aexit__(self, *exc_info):
        if hasattr(self._inner, "__aexit__"):
            await self._inner.__aexit__(*exc_info)
        self._enrich()
        return False

    async def close(self):
        if hasattr(self._inner, "close"):
            import asyncio
            coro = self._inner.close()
            if asyncio.iscoroutine(coro):
                await coro
        self._enrich()

    @property
    def response(self):
        return getattr(self._inner, "response", None)

    def _enrich(self):
        if self._done:
            return
        self._done = True
        try:
            _enrich_context_from_stream(self._chunks, self._kwargs)
        except Exception:
            pass
