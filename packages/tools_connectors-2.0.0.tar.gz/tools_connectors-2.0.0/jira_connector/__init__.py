"""
Jira Connector Package
A flexible and powerful Python connector for interacting with Jira API
"""

__version__ = "1.0.0"
__author__ = "Jira Connector Team"
__email__ = "contact@example.com"
__description__ = ("A flexible and powerful Python connector for interacting with "
                   "Jira API")

# Import main classes for easy access
from .jira_connector import JiraConnector
from .operations import JiraOperations

# Export main components
__all__ = [
    "JiraConnector",
    "JiraOperations",
    "__version__",
    "__author__",
    "__email__",
    "__description__"
]

# Package metadata
PACKAGE_INFO = {
    "name": "connectors.jira-connector",
    "version": __version__,
    "author": __author__,
    "email": __email__,
    "description": __description__,
    "url": "https://github.com/yourusername/connectors",
    "license": "MIT",
    "python_requires": ">=3.7",
}


def get_version():
    """Get package version"""
    return __version__


def get_package_info():
    """Get package information"""
    return PACKAGE_INFO
