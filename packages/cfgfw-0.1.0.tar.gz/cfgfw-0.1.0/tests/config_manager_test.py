"""Shared pytest fixtures and hooks. Add fixtures here as needed."""


from config_framework import Factory

from pathlib import Path
def test_config_manager_factory()->None:
    factory = Factory()
    config_loader = factory.make_config_loader()
    config = config_loader.load_full_config(path=Path(__file__).parent / "a.py")
    print(config)
    assert type(config) == dict
    assert config["a"] == 1
    assert config["b"] == 2

    assert config is not None
