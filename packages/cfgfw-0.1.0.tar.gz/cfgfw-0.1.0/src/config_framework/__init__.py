"""Configuration management utilities."""

__version__ = "0.1.0"

from .accessor import ConfigAccessor
from .loader import ConfigLoader
from .accessor import PythonConfigAccessor , YamlConfigAccessor
from .handler import *

from typing import List
from .tool import DictTool

from functools import cache
class Factory:

    @cache
    def make_overritten_tag(self)->str:
        return "WillBeOverridden"

    @cache
    def make_dict_tool(self)->DictTool:
        return DictTool(self.make_overritten_tag())

    @cache
    def make_config_accessor(self)->ConfigAccessor:
        return PythonConfigAccessor()

    def make_config_handlers(self, config_loader:ConfigLoader)->List[Handler]:
        return [
            FileConfig_ReferHandler(config_loader=config_loader),
            Tuple_Merge_Handler(dict_tool=self.make_dict_tool()),
            Base_Flat_Handler(dict_tool=self.make_dict_tool()),
            Function_Handler(),
            Val_ReferHandler(dict_tool=self.make_dict_tool()),
            Temp_Value_Filter_Handler(),
            Tuple_Merge_Handler(dict_tool=self.make_dict_tool()),
        ]
    
    @cache
    def make_config_loader(self)->ConfigLoader:
        handlers = None
        config_loader = ConfigLoader(self.make_config_accessor(), handlers)
        handlers = self.make_config_handlers(config_loader)
        config_loader.handlers =  handlers
        return config_loader