from typing import Optional, List

from .accessor import ConfigAccessor
from .handler.handler import Handler
WillBeOverridden = "WillBeOverridden"


from pathlib import Path



class ConfigLoader:

    def __init__(self,
            # db_config_refer_handler:DB_ReferHandler
            dict_accessor:ConfigAccessor,
            handlers:List[Handler]
        )->None:
        self.dict_accessor = dict_accessor
        self.handlers = handlers
        
        # self.db_config_refer_handler = db_config_refer_handler

    def load_config(self, path:str|Path)->dict:
        return self.dict_accessor.load_config(path)

    def load_full_config(self, 
            path:Optional[str|Path] = None,
            config:Optional[dict] = None,
        )->dict:

        try:
            assert (not all([path, config])) and any([path, config]), "one of path or config must be provided"

            if path is not None:
                config = self.load_config(path) # just load config file

            if config is None:
                raise ValueError("config must be provided")

            for handler in self.handlers:
                config = handler.handle(config)

        except Exception as e:
            print(e)
            print(path)
            raise e

        return config
