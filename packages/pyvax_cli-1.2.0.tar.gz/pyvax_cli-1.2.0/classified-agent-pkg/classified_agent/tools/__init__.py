"""Tool definitions and registry."""
