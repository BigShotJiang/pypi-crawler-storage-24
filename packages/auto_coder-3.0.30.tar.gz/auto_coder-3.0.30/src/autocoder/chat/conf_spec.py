"""
Shared specification for the /conf command.

Single source of truth consumed by both ``conf_command.handle_conf_command``
(execution) and ``CommandCompleterV2._handle_conf`` (tab-completion).  Keeping
these definitions in one place prevents the two from drifting apart.
"""

from typing import List, Literal, Optional, Tuple

from autocoder.common import AutoCoderArgs
from autocoder.common.conf_validator import ConfigValidator
from autocoder.common.ac_style_command_parser import create_config
from autocoder.common.ac_style_command_parser.config import ParserConfig

# -- subcommand definitions ---------------------------------------------------

CONF_SUBCOMMANDS: List[str] = [
    "/list",
    "/show",
    "/get",
    "/set",
    "/delete",
    "/del",
    "/rm",
    "/drop",
    "/help",
    "/export",
    "/import",
]

CONF_GLOBAL_SUBCOMMANDS: List[str] = [
    "/list",
    "/show",
    "/get",
    "/set",
    "/delete",
    "/del",
    "/rm",
    "/drop",
    "/help",
]

CONF_DELETE_ALIASES = frozenset({"/delete", "/del", "/rm", "/drop"})
CONF_KEY_SUBCOMMANDS = frozenset({"/get", "/set"}) | CONF_DELETE_ALIASES
CONF_PATH_SUBCOMMANDS = frozenset({"/export", "/import"})


def build_conf_parser_config() -> ParserConfig:
    """Build the ``ParserConfig`` used by ``handle_conf_command``.

    Centralised here so that both execution and completion share the same
    definition of valid subcommands and their argument shapes.
    """
    return (
        create_config()
        .collect_remainder("query")
        .command("list")
        .positional("pattern")
        .max_args(1)
        .command("show")
        .positional("pattern")
        .max_args(1)
        .command("get")
        .positional("key", required=True)
        .max_args(1)
        .command("set")
        .positional("key", required=True)
        .positional("value", required=True)
        .max_args(2)
        .command("delete")
        .collect_remainder("keys")
        .command("del")
        .collect_remainder("keys")
        .command("rm")
        .collect_remainder("keys")
        .command("drop")
        .collect_remainder("keys")
        .command("help")
        .max_args(0)
        .command("export")
        .positional("path", required=True)
        .max_args(1)
        .command("import")
        .positional("path", required=True)
        .max_args(1)
        .build()
    )


def get_conf_subcommands(
    scope: Literal["project", "global"] = "project",
) -> List[str]:
    """Return the list of valid /conf subcommands for the given *scope*."""
    if scope == "global":
        return list(CONF_GLOBAL_SUBCOMMANDS)
    return list(CONF_SUBCOMMANDS)


# -- config-key helpers -------------------------------------------------------


def get_config_key_candidates(
    prefix: str = "",
) -> List[Tuple[str, str]]:
    """Return ``(key, display)`` pairs suitable for completion.

    Keys from ``ConfigValidator.CONFIG_SPEC`` are listed first (they carry a
    human-readable description); the remaining ``AutoCoderArgs`` fields follow.
    """
    candidates: List[Tuple[str, str]] = []
    seen: set = set()

    for key, spec in ConfigValidator.CONFIG_SPEC.items():
        if prefix and not key.startswith(prefix):
            continue
        desc = spec.get("description", "")
        display = f"{key} ({desc})" if desc else key
        candidates.append((key, display))
        seen.add(key)

    for key in AutoCoderArgs.model_fields:
        if key in seen:
            continue
        if prefix and not key.startswith(prefix):
            continue
        candidates.append((key, key))

    return candidates


def get_config_value_candidates(
    key: str,
    value_prefix: str = "",
    model_names: Optional[List[str]] = None,
) -> List[Tuple[str, str]]:
    """Return ``(value, display)`` pairs for a known config *key*.

    Handles booleans, enum-like allowed lists, and model-name keys.
    """
    candidates: List[Tuple[str, str]] = []

    spec = ConfigValidator.CONFIG_SPEC.get(key)
    if spec:
        if spec.get("type") is bool:
            for v in ("true", "false"):
                if v.startswith(value_prefix):
                    candidates.append((v, v))
            return candidates
        allowed = spec.get("allowed")
        if allowed:
            for v in allowed:
                sv = str(v)
                if sv.startswith(value_prefix):
                    candidates.append((sv, sv))
            return candidates

    field_info = AutoCoderArgs.model_fields.get(key)
    if field_info and field_info.annotation is bool:
        for v in ("true", "false"):
            if v.startswith(value_prefix):
                candidates.append((v, v))
        return candidates

    if key.endswith("_model") or key == "model":
        if model_names:
            for m in model_names:
                if m.startswith(value_prefix) or not value_prefix:
                    candidates.append((m, m))

    return candidates
