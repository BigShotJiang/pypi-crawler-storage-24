"""
Runtime registry for tracking active conversation runs.

Provides file-based, cross-process tracking of which conversations currently
have an active agent run. Each conversation can have at most one active run
at any time. Liveness is determined by checking whether the owner process
(identified by pid + create_time) is still alive, rather than relying on
periodic heartbeat / TTL.

Storage layout under the conversation storage root:
    <storage_path>/runtime/running/<conversation_id>.json
    <storage_path>/locks/runtime.<conversation_id>.lock
"""

from __future__ import annotations

import json
import os
import socket
import time
import uuid
from pathlib import Path
from typing import List, Optional

import psutil
from pydantic import BaseModel

from .file_locker import FileLocker


class ConversationRunInfo(BaseModel):
    """Describes a single active run bound to a conversation."""

    conversation_id: str
    run_id: str
    owner_pid: int
    owner_host: str
    owner_process_create_time: float
    entrypoint: str
    request_id: Optional[str] = None
    cancel_token: Optional[str] = None
    started_at: float
    is_sub_agent: bool = False


class ConversationRunStartResult(BaseModel):
    """Return value of *try_start_conversation_run*."""

    acquired: bool
    run_info: Optional[ConversationRunInfo] = None
    existing_run_info: Optional[ConversationRunInfo] = None


class ForwardedSubmissionResult(BaseModel):
    """Return value of *submit_user_input_to_running_conversation*."""

    success: bool
    conversation_id: str
    target_run_id: Optional[str] = None
    message_id: Optional[str] = None
    owner_pid: Optional[int] = None
    reason: Optional[str] = None


def _get_current_process_create_time() -> float:
    """Return the create_time of the current process."""
    return psutil.Process(os.getpid()).create_time()


def _is_process_alive(pid: int, expected_create_time: float) -> bool:
    """Check whether *pid* is still the same process that was recorded.

    Returns True only when:
    - The pid exists.
    - The process behind that pid has a create_time matching
      *expected_create_time* (within a 2-second tolerance to account
      for platform rounding).
    """
    if not psutil.pid_exists(pid):
        return False
    try:
        proc = psutil.Process(pid)
        actual_create_time = proc.create_time()
        return abs(actual_create_time - expected_create_time) < 2.0
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        return False


class RuntimeRegistry:
    """File-based registry for active conversation runs.

    All public methods are process-safe via per-conversation file locks.
    Liveness is determined by checking whether the owner process is still
    alive (pid + create_time), not by heartbeat/TTL.
    """

    def __init__(self, storage_path: str, lock_timeout: float = 10.0) -> None:
        self._storage_root = Path(storage_path)
        self._running_dir = self._storage_root / "runtime" / "running"
        self._lock_dir = self._storage_root / "locks"
        self._lock_timeout = lock_timeout

        self._running_dir.mkdir(parents=True, exist_ok=True)
        self._lock_dir.mkdir(parents=True, exist_ok=True)

    def _run_file(self, conversation_id: str) -> Path:
        return self._running_dir / f"{conversation_id}.json"

    def _lock_file(self, conversation_id: str) -> str:
        return str(self._lock_dir / f"runtime.{conversation_id}.lock")

    def _read_run_info(self, conversation_id: str) -> Optional[ConversationRunInfo]:
        path = self._run_file(conversation_id)
        if not path.exists():
            return None
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            return ConversationRunInfo(**data)
        except Exception:
            return None

    def _write_run_info(self, info: ConversationRunInfo) -> None:
        path = self._run_file(info.conversation_id)
        path.write_text(
            json.dumps(info.model_dump(), ensure_ascii=False), encoding="utf-8"
        )

    def _delete_run_file(self, conversation_id: str) -> None:
        path = self._run_file(conversation_id)
        if path.exists():
            path.unlink(missing_ok=True)

    def _is_owner_alive(self, info: ConversationRunInfo) -> bool:
        if info.owner_host != socket.gethostname():
            return True
        return _is_process_alive(info.owner_pid, info.owner_process_create_time)

    def try_start(
        self,
        conversation_id: str,
        *,
        request_id: Optional[str],
        cancel_token: Optional[str],
        entrypoint: str,
        is_sub_agent: bool,
    ) -> ConversationRunStartResult:
        locker = FileLocker(
            self._lock_file(conversation_id), timeout=self._lock_timeout
        )
        with locker.acquire_write_lock():
            existing = self._read_run_info(conversation_id)
            if existing is not None and self._is_owner_alive(existing):
                return ConversationRunStartResult(
                    acquired=False, existing_run_info=existing
                )
            now = time.time()
            info = ConversationRunInfo(
                conversation_id=conversation_id,
                run_id=str(uuid.uuid4()),
                owner_pid=os.getpid(),
                owner_host=socket.gethostname(),
                owner_process_create_time=_get_current_process_create_time(),
                entrypoint=entrypoint,
                request_id=request_id,
                cancel_token=cancel_token,
                started_at=now,
                is_sub_agent=is_sub_agent,
            )
            self._write_run_info(info)
            return ConversationRunStartResult(acquired=True, run_info=info)

    def finish(self, conversation_id: str, run_id: str, *, reason: str) -> bool:
        locker = FileLocker(
            self._lock_file(conversation_id), timeout=self._lock_timeout
        )
        with locker.acquire_write_lock():
            info = self._read_run_info(conversation_id)
            if info is None or info.run_id != run_id:
                return False
            self._delete_run_file(conversation_id)
            return True

    def get_running(self, conversation_id: str) -> Optional[ConversationRunInfo]:
        locker = FileLocker(
            self._lock_file(conversation_id), timeout=self._lock_timeout
        )
        with locker.acquire_write_lock():
            info = self._read_run_info(conversation_id)
            if info is None:
                return None
            if not self._is_owner_alive(info):
                self._delete_run_file(conversation_id)
                return None
            return info

    def is_running(self, conversation_id: str) -> bool:
        return self.get_running(conversation_id) is not None

    def list_running(self) -> List[ConversationRunInfo]:
        result: List[ConversationRunInfo] = []
        if not self._running_dir.exists():
            return result
        for p in self._running_dir.iterdir():
            if p.suffix != ".json":
                continue
            conv_id = p.stem
            try:
                info = self.get_running(conv_id)
                if info is not None:
                    result.append(info)
            except Exception:
                pass
        return result
