from typing import Literal

from pydantic import Field

from kb_dashboard_core.panels.charts.lens.dimensions.config import CollapseAggregationEnum
from kb_dashboard_core.shared.config import BaseCfgModel, BaseIdentifiableModel

type ESQLColumnTypes = ESQLDimension | ESQLMetric

type ESQLDimensionTypes = ESQLDimension

type ESQLBreakdownTypes = ESQLBreakdown

type ESQLMetricTypes = ESQLMetric

type ESQLMetricFormatTypes = ESQLMetricFormat | ESQLCustomMetricFormat


class ESQLMetricFormat(BaseCfgModel):
    """The format configuration for ES|QL metrics.

    Supports standard format types like number, bytes, bits, percent, and duration.
    This is separate from LensMetricFormat as ES|QL and Lens formatting may diverge in the future.
    """

    type: Literal['number', 'bytes', 'bits', 'percent', 'duration']

    decimals: int | None = Field(default=None)
    """The number of decimal places to display. If not specified, defaults to 2 for number/bytes/percent/duration, 0 for bits."""

    suffix: str | None = Field(default=None)
    """The suffix to display after the number."""

    compact: bool | None = Field(default=None)
    """Whether to display the number in a compact format."""

    pattern: str | None = Field(default=None)
    """The pattern to display the number in."""


class ESQLCustomMetricFormat(BaseCfgModel):
    """Custom format configuration for ES|QL metrics.

    Allows specifying a custom number format pattern.
    This is separate from LensCustomMetricFormat as ES|QL and Lens formatting may diverge in the future.
    """

    type: Literal['custom'] = 'custom'

    pattern: str = Field(...)
    """The pattern to display the number in."""


class BaseESQLColumn(BaseIdentifiableModel):
    """A base class for ESQL columns."""


class ESQLDimension(BaseESQLColumn):
    """A dimension that is defined in the ESQL query."""

    field: str = Field(default=...)
    """The field to use for the dimension."""

    label: str | None = Field(default=None)
    """Optional display label for the dimension."""

    data_type: Literal['date'] | None = Field(default=None)
    """The data type of the field. Set to 'date' for time/date fields to enable proper sorting and formatting."""


class ESQLBreakdown(ESQLDimension):
    """A breakdown dimension for ESQL charts that supports collapse aggregation.

    Breakdowns slice data into categories (e.g. bar segments, waffle sections).
    Unlike plain dimensions, breakdowns support the ``collapse`` aggregation
    which merges multiple dimension values into a single bucket using a summary function.
    """

    collapse: CollapseAggregationEnum | None = Field(default=None, strict=False)
    """Aggregate all breakdown values into a single bucket using this function (sum, avg, min, max)."""


class ESQLMetric(BaseESQLColumn):
    """A metric that is defined in the ESQL query."""

    field: str = Field(default=...)
    """The field in the data view that this metric is based on."""

    label: str | None = Field(default=None)
    """Optional display label for the metric."""

    format: ESQLMetricFormatTypes | None = Field(default=None)
    """The format of the metric (number, bytes, bits, percent, duration, or custom)."""
