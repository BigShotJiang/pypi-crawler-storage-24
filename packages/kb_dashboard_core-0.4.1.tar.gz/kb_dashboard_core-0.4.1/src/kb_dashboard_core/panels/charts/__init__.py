"""Charts panel configuration."""
