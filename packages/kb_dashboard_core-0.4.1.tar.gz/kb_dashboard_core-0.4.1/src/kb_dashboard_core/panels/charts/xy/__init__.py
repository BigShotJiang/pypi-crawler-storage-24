"""XY chart components."""
