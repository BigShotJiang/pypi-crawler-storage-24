"""Screen widgets for the display manager."""

import logging
import math
import random

import pyglet
from pyglet.shapes import BorderedRectangle, Box
from pyglet.text import Label

from .screens import Screen
from .utils import simplify_model_name
from .widgets import Rect, Widget, brighten

ANIMATION_LENGTH = 8

log = logging.getLogger(__name__)


def limit_size(text):
    """Limit the size of the text to 15 characters."""
    if len(text) > 15:
        return text[:12] + "..."
    return text


class GuiScreen(Widget):
    """A widget representing a screen."""

    def __repr__(self):
        return f"<Screen {self.rect} ({self.color}) - {self.screen.name}>"

    __str__ = __repr__

    all_colors: tuple[tuple[int, int, int], ...] = (
        (108, 158, 208),
        (126, 141, 80),
        (229, 181, 102),
        (108, 153, 186),
        (158, 78, 133),
        (172, 65, 66),
        (125, 213, 207),
        (208, 208, 208),
    )
    cur_color = 0

    def __init__(
        self,
        screen: Screen,
        rect: Rect,
        color: tuple[int, ...] = (100, 100, 100),
    ):
        super().__init__(rect, None)
        self.screen = screen
        self.target_rect: Rect = rect.copy()
        self.color: tuple[int, ...] = color
        self.dragging = False
        self.highlighted = False
        self.preview_sprite: pyglet.sprite.Sprite | None = None

    def genColor(self):
        if self.cur_color >= len(self.all_colors):
            self.color = (
                random.randint(100, 200),
                random.randint(100, 200),
                random.randint(100, 200),
                255,
            )
        else:
            self.color = (*self.all_colors[self.cur_color], 255)
            GuiScreen.cur_color += 1
        self.drag_color: tuple[int, ...] = (*self.color[:3], 200)

    def set_preview(self, path: str):
        """Load a screenshot preview image.  Silently no-ops on failure."""
        try:
            img = pyglet.image.load(path)
            self.preview_sprite = pyglet.sprite.Sprite(img)
        except Exception:
            log.debug("Failed to load preview from %s", path, exc_info=True)
            self.preview_sprite = None

    @property
    def current_color(self):
        """The current_color property."""
        color = self.drag_color if self.dragging else self.color
        if self.screen.active:
            return color
        alpha = color[3] if len(color) > 3 else 255
        return (color[0] // 3, color[1] // 3, color[2] // 3, alpha)

    @property
    def statusInfo(self):
        return "Screen identifier: " + self.screen.name

    def _animation_step(self):
        r = self.rect
        t = self.target_rect
        for var in ("x", "y", "width", "height"):
            cv = getattr(r, var)
            tv = getattr(t, var)
            if cv != tv:
                if abs(tv - cv) < 2:
                    setattr(r, var, tv)
                else:
                    tgt = (cv * ANIMATION_LENGTH + tv) / (ANIMATION_LENGTH + 1)
                    if cv < tv:
                        setattr(r, var, min(tv, math.ceil(tgt)))
                    elif cv > tv:
                        setattr(r, var, max(tv, math.floor(tgt)))

    def set_position(self, x, y):
        self.rect.x = x
        self.target_rect.x = x
        self.rect.y = y
        self.target_rect.y = y
        self.cur_border = 2.0

    def draw(self, cursor):
        if self.highlighted and self.cur_border <= 9:
            self.cur_border += 0.2
        if not self.highlighted and self.cur_border >= 2:
            self.cur_border -= 0.2

        if self.rect != self.target_rect:
            self._animation_step()

        txt_color = (240, 240, 240, 255) if self.screen.active else (255, 255, 255, 120)
        border_color = (100, 100, 155)
        if not self.screen.active:
            border_color = (70, 70, 70)
        if self.highlighted:
            border_color = (255, 201, 0)
        # draw the background
        color = self.current_color
        if self.rect.contains(*cursor):
            color = brighten(color)

        BorderedRectangle(
            self.rect.x,
            self.rect.y,
            self.rect.width,
            self.rect.height,
            border=int(self.cur_border),
            color=color,
            border_color=border_color,
        ).draw()

        # Draw screenshot preview (active monitors only)
        if self.preview_sprite and self.screen.active:
            sprite = self.preview_sprite
            img = sprite.image
            img_w = getattr(img, "width", 0)
            img_h = getattr(img, "height", 0)
            if img_w > 0 and img_h > 0 and self.rect.width > 0 and self.rect.height > 0:
                sprite.update(
                    x=self.rect.x,
                    y=self.rect.y,
                    scale_x=self.rect.width / img_w,
                    scale_y=self.rect.height / img_h,
                )
                # Dim the screenshot so text labels remain readable
                sprite.color = (100, 100, 100, 255)
                sprite.draw()
                # Redraw border on top of the screenshot
                Box(
                    self.rect.x,
                    self.rect.y,
                    self.rect.width,
                    self.rect.height,
                    thickness=int(self.cur_border),
                    color=border_color,
                ).draw()

        # Render the screen uid as text
        tx, ty = self.rect.center
        Label(
            limit_size(simplify_model_name(self.screen.name)),
            anchor_x="center",
            anchor_y="center",
            x=tx,
            y=ty,
            font_size=16,
            color=(240, 240, 240, 255),
        ).draw()

        # Second caption line
        if self.screen.active:
            assert self.screen.mode
            label = f"{self.screen.mode.width}x{self.screen.mode.height}@{int(self.screen.mode.freq)}"
            Label(
                self.screen.uid,
                anchor_x="center",
                anchor_y="center",
                x=tx,
                y=ty + 20,
                color=txt_color,
                weight="bold" if self.screen.active else "normal",
            ).draw()
            Label(
                label,
                anchor_x="center",
                anchor_y="center",
                x=tx,
                y=ty - 20,
                color=txt_color,
                weight="bold" if self.screen.active else "normal",
            ).draw()
