use pyo3::prelude::*;

mod parser;

mod telegram;

mod matrix;

#[pymodule]
mod slidge_style_parser {
    #[pymodule_export]
    use crate::telegram::format_for_telegram;

    #[pymodule_export]
    use crate::matrix::format_for_matrix;
}

