# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""RouteRTL Core — proprietary algorithmic engines.

This package contains the crown-jewel algorithms that constitute
RouteRTL's intellectual property:

- dependency_resolver: HDL dependency graph analysis and topological sort
- smart_linter: Dual-engine VHDL + SystemVerilog linting pipeline
- scan_sources: Blind HUNT-pattern source file discovery
- project_manager: YAML → Makefile/TCL configuration engine
- sim: Simulation orchestration — multi-backend invocation, library
  compilation, vendor backends (NVC, GHDL, Questa, Riviera, etc.)
- docker: Docker container orchestration — volume resolution,
  edition-aware mapping, bind mount detection, EDA version probing
- workspace: Workspace management — config regeneration, venv
  environment injection, shell completion injection
"""

__author__ = "Daniel J. Mazure"
__copyright__ = "Copyright © 2026 Daniel J. Mazure"
__version__: str
try:
    from importlib.metadata import version as _meta_version
    __version__ = _meta_version("routertl")
except Exception:
    __version__ = "3.4.3"  # fallback for Cython builds / uninstalled dev


def banner() -> str:
    """Return the RouteRTL core attribution banner."""
    return f"RouteRTL Core v{__version__} — © {__author__}"
