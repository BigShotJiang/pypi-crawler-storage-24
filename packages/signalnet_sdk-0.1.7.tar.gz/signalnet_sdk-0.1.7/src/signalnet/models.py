"""Pydantic models for SignalNet API responses."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel, Field


class Round(BaseModel):
    """A tournament round."""

    id: Any
    tournament_id: Optional[int] = None
    round_number: Optional[int] = None
    status: Optional[str] = None
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    resolve_date: Optional[datetime] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    model_config = {"extra": "allow"}


class RoundsResponse(BaseModel):
    """Response from GET /tournament/rounds."""

    rounds: list[Round]
    total: int = 0


class Tournament(BaseModel):
    """A tournament."""

    id: int
    name: Optional[str] = None
    slug: Optional[str] = None
    description: Optional[str] = None
    status: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    model_config = {"extra": "allow"}


class RoundResult(BaseModel):
    """A single result entry for a round."""

    user_id: Optional[int] = None
    username: Optional[str] = None
    rank: Optional[int] = None
    score: Optional[float] = None
    correlation: Optional[float] = None
    stake: Optional[float] = None
    payout: Optional[float] = None

    model_config = {"extra": "allow"}


class Prediction(BaseModel):
    """A single stock prediction."""

    stock_id: str
    signal: float


class SubmissionRequest(BaseModel):
    """Request body for submitting predictions."""

    round_id: int
    signal_hash: str
    stake_amount: int
    signal_data: Optional[list[Prediction]] = None


class SubmissionResponse(BaseModel):
    """Response from submitting predictions."""

    status: Optional[str] = None
    submission: Optional[dict[str, Any]] = None

    model_config = {"extra": "allow"}


class User(BaseModel):
    """User profile."""

    id: Optional[int] = None
    username: Optional[str] = None
    email: Optional[str] = None
    created_at: Optional[datetime] = None

    model_config = {"extra": "allow"}


class ScoreEntry(BaseModel):
    """A single score history entry."""

    round_id: Optional[int] = None
    score: Optional[float] = None
    correlation: Optional[float] = None
    rank: Optional[int] = None
    payout: Optional[float] = None

    model_config = {"extra": "allow"}


class ApiKey(BaseModel):
    """An API key."""

    id: Optional[int] = None
    key: Optional[str] = None
    name: Optional[str] = None
    created_at: Optional[datetime] = None

    model_config = {"extra": "allow"}
