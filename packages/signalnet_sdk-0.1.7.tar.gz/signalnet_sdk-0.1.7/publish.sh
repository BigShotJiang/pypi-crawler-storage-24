#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

PYPROJECT="pyproject.toml"
INIT_FILE="src/signalnet/__init__.py"
CURRENT_VERSION=$(grep '^version' "$PYPROJECT" | head -1 | sed 's/.*"\(.*\)"/\1/')

echo "Current version: $CURRENT_VERSION"

# Parse current version
IFS='.' read -r MAJOR MINOR PATCH <<< "$CURRENT_VERSION"

# Determine bump type
BUMP="${1:-patch}"
case "$BUMP" in
  major) MAJOR=$((MAJOR + 1)); MINOR=0; PATCH=0 ;;
  minor) MINOR=$((MINOR + 1)); PATCH=0 ;;
  patch) PATCH=$((PATCH + 1)) ;;
  *)
    echo "Usage: ./publish.sh [major|minor|patch]"
    echo "  patch  0.1.0 -> 0.1.1  (default)"
    echo "  minor  0.1.0 -> 0.2.0"
    echo "  major  0.1.0 -> 1.0.0"
    exit 1
    ;;
esac

NEW_VERSION="$MAJOR.$MINOR.$PATCH"
echo "New version:     $NEW_VERSION"
echo ""

# Confirm
read -rp "Publish signalnet-sdk $NEW_VERSION to PyPI? [y/N] " CONFIRM
if [[ "$CONFIRM" != "y" && "$CONFIRM" != "Y" ]]; then
  echo "Aborted."
  exit 0
fi

# Update version in pyproject.toml
sed -i '' "s/^version = \"$CURRENT_VERSION\"/version = \"$NEW_VERSION\"/" "$PYPROJECT"
echo "Updated $PYPROJECT"

# Update version in __init__.py
sed -i '' "s/__version__ = \"$CURRENT_VERSION\"/__version__ = \"$NEW_VERSION\"/" "$INIT_FILE"
echo "Updated $INIT_FILE"

# Clean old builds
rm -rf dist/ build/ src/*.egg-info
echo "Cleaned dist/"

# Ensure build tools exist
if ! command -v python3 &>/dev/null; then
  echo "Error: python3 not found"
  exit 1
fi

# Create temp venv for building if needed
if [[ ! -d .venv ]] || ! .venv/bin/python -c "import build, twine" 2>/dev/null; then
  echo "Installing build tools..."
  python3 -m venv .venv
  .venv/bin/pip install --quiet build twine
fi

# Build
echo "Building..."
.venv/bin/python -m build --quiet

# Check the package
echo "Checking package..."
.venv/bin/twine check dist/*

# Upload — require PYPI_TOKEN env var or prompt
if [[ -z "${PYPI_TOKEN:-}" ]]; then
  read -rsp "Enter PyPI API token: " PYPI_TOKEN
  echo ""
fi

echo "Uploading to PyPI..."
TWINE_USERNAME=__token__ TWINE_PASSWORD="$PYPI_TOKEN" .venv/bin/twine upload dist/*

echo ""
echo "Published signalnet-sdk $NEW_VERSION"
echo "https://pypi.org/project/signalnet-sdk/$NEW_VERSION/"
