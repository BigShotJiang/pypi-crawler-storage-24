from __future__ import annotations

from pathlib import Path

import pytest
from fastapi.templating import Jinja2Templates

from vite_fastapi import (
    ManifestClient,
    ViteAppNotFoundError,
    ViteAssetNotFoundError,
    ViteClient,
    ViteConfig,
    ViteManifestError,
    ViteRegistry,
    register_vite,
)


FIXTURES_DIR = Path(__file__).resolve().parent / "fixtures" / "vite"


class InMemoryManifestClient(ManifestClient):
    def load_manifest(self) -> dict[str, object]:
        return {
            "src/app.ts": {
                "file": "assets/app.js",
                "isEntry": True,
            }
        }


class CDNClient(ViteClient):
    ManifestClient = InMemoryManifestClient

    def get_production_server_url(self, path: str) -> str:
        return f"https://cdn.example/{path.lstrip('/')}"


class NestedManifestClient(ManifestClient):
    def load_manifest(self) -> dict[str, object]:
        return {
            "src/entry.ts": {
                "file": "assets/entry.js",
                "css": ["assets/entry.css"],
                "imports": ["_shared.js"],
                "isEntry": True,
            },
            "_shared.js": {
                "file": "assets/shared.js",
                "css": ["assets/shared.css"],
                "imports": ["_vendor.js"],
            },
            "_vendor.js": {
                "file": "assets/vendor.js",
            },
        }


class NestedClient(ViteClient):
    ManifestClient = NestedManifestClient


def _fixture_path(name: str) -> Path:
    return FIXTURES_DIR / name


def test_dev_urls_include_base_path() -> None:
    client = ViteClient(
        ViteConfig(
            dev_mode=True,
            dev_server_url="http://127.0.0.1:3000",
            base_path="/static/",
        )
    )

    assert client.asset_url("frontend/main.tsx") == (
        "http://127.0.0.1:3000/static/frontend/main.tsx"
    )
    assert str(client.hmr_client()) == (
        '<script type="module" src="http://127.0.0.1:3000/static/@vite/client"></script>'
    )
    react_refresh = str(client.react_refresh())
    assert "http://127.0.0.1:3000/static/@react-refresh" in react_refresh
    assert "window.__vite_plugin_react_preamble_installed__ = true;" in react_refresh


def test_production_asset_renders_recursive_css_and_import_preloads() -> None:
    client = ViteClient(
        ViteConfig(
            dev_mode=False,
            static_url="/static/",
            manifest_path=_fixture_path("manifest.json"),
        )
    )

    html = str(client.asset("src/entry.ts", data_track="reload"))

    assert (
        'data-track="reload" rel="stylesheet" href="/static/assets/extra-a9f3b2c1.css"'
        in html
    )
    assert html.index("entry-74d0d5dd.css") < html.index("extra-a9f3b2c1.css")
    assert html.count("extra-a9f3b2c1.css") == 1
    assert html.count('rel="modulepreload"') == 4
    assert (
        'type="module" crossorigin="" data-track="reload" '
        'src="/static/assets/entry-29e38a60.js"'
    ) in html


def test_preload_asset_renders_entry_css_and_import_preloads() -> None:
    client = ViteClient(
        ViteConfig(
            dev_mode=False,
            static_url="/static/",
            manifest_path=_fixture_path("manifest.json"),
        )
    )

    html = str(client.preload_asset("src/entry.ts"))

    assert html.count('rel="modulepreload"') == 5
    assert 'rel="preload" href="/static/assets/entry-74d0d5dd.css" as="style"' in html
    assert 'rel="preload" href="/static/assets/extra-a9f3b2c1.css" as="style"' in html
    assert html.index("entry-74d0d5dd.css") < html.index("extra-a9f3b2c1.css")
    assert html.count("extra-a9f3b2c1.css") == 1


def test_production_manifest_errors_are_raised(tmp_path: Path) -> None:
    invalid_manifest = tmp_path / "manifest.json"
    invalid_manifest.write_text("{", encoding="utf-8")

    invalid_client = ViteClient(
        ViteConfig(
            dev_mode=False,
            manifest_path=invalid_manifest,
        )
    )
    with pytest.raises(ViteManifestError):
        invalid_client.asset_url("src/entry.ts")

    missing_client = ViteClient(
        ViteConfig(
            dev_mode=False,
            manifest_path=_fixture_path("manifest.json"),
        )
    )
    with pytest.raises(ViteAssetNotFoundError):
        missing_client.asset_url("src/missing.ts")


def test_named_asset_lookup_uses_manifest_name() -> None:
    client = ViteClient(
        ViteConfig(
            dev_mode=False,
            static_url="/static/",
            manifest_path=_fixture_path("named_assets_manifest.json"),
        )
    )

    assert client.asset_url("one") == "/static/assets/one-90jdqqZN.js"
    assert client.asset_url("one.js") == "/static/assets/one-90jdqqZN.js"


def test_registry_supports_multiple_apps() -> None:
    registry = ViteRegistry(
        {
            "default": ViteConfig(
                dev_mode=False,
                static_url="/static/",
                manifest_path=_fixture_path("manifest.json"),
            ),
            "external": ViteConfig(
                dev_mode=False,
                static_url="https://cdn.example/static/",
                manifest_path=_fixture_path("named_assets_manifest.json"),
            ),
        }
    )

    assert registry.asset_url("src/entry.ts") == "/static/assets/entry-29e38a60.js"
    assert (
        registry.asset_url("one", app="external")
        == "https://cdn.example/static/assets/one-90jdqqZN.js"
    )
    with pytest.raises(ViteAppNotFoundError):
        registry.asset_url("src/entry.ts", app="missing")


def test_register_vite_uses_registry_default_app() -> None:
    templates = Jinja2Templates(directory=str(FIXTURES_DIR))
    registry = ViteRegistry(
        {
            "frontend": ViteConfig(
                dev_mode=True,
                dev_server_url="http://127.0.0.1:3000",
            )
        },
        default_app="frontend",
    )

    register_vite(templates, registry)

    assert (
        templates.env.globals["vite_asset_url"]("main.ts")
        == "http://127.0.0.1:3000/main.ts"
    )


def test_nested_imports_are_preloaded_recursively() -> None:
    client = NestedClient(
        ViteConfig(
            dev_mode=False,
            static_url="/static/",
        )
    )

    asset_html = str(client.asset("src/entry.ts"))
    preload_html = str(client.preload_asset("src/entry.ts"))

    assert asset_html.index("entry.css") < asset_html.index("shared.css")
    assert 'href="/static/assets/shared.js"' in asset_html
    assert 'href="/static/assets/vendor.js"' in asset_html
    assert 'href="/static/assets/shared.js"' in preload_html
    assert 'href="/static/assets/vendor.js"' in preload_html


def test_legacy_helpers_render_in_production_and_skip_in_dev() -> None:
    production_client = ViteClient(
        ViteConfig(
            dev_mode=False,
            static_url="/static/",
            manifest_path=_fixture_path("polyfills-manifest.json"),
        )
    )
    development_client = ViteClient(
        ViteConfig(
            dev_mode=True,
            dev_server_url="http://127.0.0.1:3000",
        )
    )

    assert str(development_client.legacy_asset("src/entry.ts")) == ""
    assert str(development_client.legacy_polyfills()) == ""
    assert 'nomodule="" crossorigin="" src="/static/assets/entry-2e8a3a7a.js"' in str(
        production_client.legacy_asset("src/entry.ts")
    )
    assert (
        'crossorigin="" nomodule="" src="/static/assets/polyfills-legacy-f4c2b91e.js"'
        in str(production_client.legacy_polyfills())
    )
    assert 'nomodule=""' not in str(production_client.legacy_polyfills(nomodule=False))


def test_custom_manifest_and_client_override_behavior() -> None:
    registry = ViteRegistry(
        {
            "default": ViteConfig(
                dev_mode=False,
                client_class=CDNClient,
            )
        }
    )

    assert registry.asset_url("src/app.ts") == "https://cdn.example/assets/app.js"
