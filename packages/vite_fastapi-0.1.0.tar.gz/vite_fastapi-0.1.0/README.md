# vite_fastapi

`vite_fastapi` is a small library for using Vite with FastAPI, inspired by [django-vite](https://github.com/MrBin99/django-vite).

- dev-mode helpers for Vite HMR and React refresh
- production manifest loading for entrypoints, CSS, and recursive imports
- Jinja globals for rendering asset tags from templates
- support for multiple named Vite apps

## Install

```bash
uv add vite_fastapi
```

## Basic usage

```python
from fastapi.templating import Jinja2Templates

from vite_fastapi import ViteConfig, register_vite

templates = Jinja2Templates(directory="templates")

register_vite(
    templates,
    {
        "default": ViteConfig(
            dev_mode=True,
            dev_server_url="http://127.0.0.1:5173",
            base_path="/static/",
            static_url="/static/",
            manifest_path="assets/manifest.json",
        )
    },
)
```

Then in your template:

```python
{{ vite_react_refresh() }}
{{ vite_hmr_client() }}
{{ vite_asset("frontend/main.tsx") }}
```

In production, the same helpers resolve against the Vite manifest and emit CSS, modulepreload, and script tags.

## Development

```bash
uv sync
uv run pytest
```
