from __future__ import annotations

import json
from pathlib import Path
from typing import Any, NamedTuple

from .config import ViteConfig
from .exceptions import ViteAssetNotFoundError, ViteManifestError


class ManifestEntry(NamedTuple):
    file: str
    name: str | None = None
    src: str | None = None
    isEntry: bool = False
    isDynamicEntry: bool = False
    css: tuple[str, ...] = ()
    imports: tuple[str, ...] = ()
    dynamicImports: tuple[str, ...] = ()
    assets: tuple[str, ...] = ()

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> ManifestEntry:
        file_name = payload.get("file")
        if not isinstance(file_name, str):
            raise ViteManifestError("Manifest entry is missing a string 'file' value.")
        name = payload.get("name")
        src = payload.get("src")
        if name is not None and not isinstance(name, str):
            raise ViteManifestError("Manifest entry 'name' must be a string.")
        if src is not None and not isinstance(src, str):
            raise ViteManifestError("Manifest entry 'src' must be a string.")
        return cls(
            file=file_name,
            name=name,
            src=src,
            isEntry=bool(payload.get("isEntry", False)),
            isDynamicEntry=bool(payload.get("isDynamicEntry", False)),
            css=_string_list(payload.get("css"), field_name="css"),
            imports=_string_list(payload.get("imports"), field_name="imports"),
            dynamicImports=_string_list(
                payload.get("dynamicImports"), field_name="dynamicImports"
            ),
            assets=_string_list(payload.get("assets"), field_name="assets"),
        )


class ParsedManifest(NamedTuple):
    entries: dict[str, ManifestEntry]
    legacy_polyfills_entry: ManifestEntry | None = None


def _string_list(value: Any, *, field_name: str) -> tuple[str, ...]:
    if value is None:
        return ()
    if not isinstance(value, list) or any(not isinstance(item, str) for item in value):
        raise ViteManifestError(
            f"Manifest entry field '{field_name}' must be a list of strings."
        )
    return tuple(value)


class ManifestClient:
    def __init__(self, config: ViteConfig, app_name: str = "default") -> None:
        self.app_name = app_name
        self.dev_mode = config.dev_mode
        self.manifest_path = _coerce_manifest_path(config)
        self.legacy_polyfills_motif = config.legacy_polyfills_motif
        self._parsed_manifest: ParsedManifest | None = None

    def load_manifest(self) -> dict[str, Any]:
        manifest_path = self.manifest_path
        if manifest_path is None:
            raise ViteManifestError(
                f"Manifest path is not configured for Vite app {self.app_name}."
            )
        try:
            manifest_content = manifest_path.read_text(encoding="utf-8")
        except OSError as exc:
            raise ViteManifestError(
                f"Cannot read Vite manifest for app {self.app_name} at {manifest_path}."
            ) from exc
        try:
            manifest = json.loads(manifest_content)
        except json.JSONDecodeError as exc:
            raise ViteManifestError(
                f"Invalid Vite manifest JSON for app {self.app_name} at {manifest_path}."
            ) from exc
        if not isinstance(manifest, dict):
            raise ViteManifestError(
                f"Vite manifest for app {self.app_name} must be a JSON object."
            )
        return manifest

    def parse_manifest(self) -> ParsedManifest:
        if self.dev_mode:
            return ParsedManifest(entries={})

        raw_manifest = self.load_manifest()
        entries: dict[str, ManifestEntry] = {}
        legacy_polyfills_entry: ManifestEntry | None = None

        for manifest_key, payload in raw_manifest.items():
            if not isinstance(manifest_key, str):
                raise ViteManifestError("Vite manifest keys must be strings.")
            if not isinstance(payload, dict):
                raise ViteManifestError(
                    f"Manifest entry '{manifest_key}' must be a JSON object."
                )
            manifest_entry = ManifestEntry.from_payload(payload)
            entries[manifest_key] = manifest_entry
            if manifest_entry.name is not None:
                entries[manifest_entry.name] = manifest_entry
            if self.legacy_polyfills_motif in manifest_key:
                legacy_polyfills_entry = manifest_entry

        return ParsedManifest(
            entries=entries,
            legacy_polyfills_entry=legacy_polyfills_entry,
        )

    def get_entry(self, path: str) -> ManifestEntry:
        parsed_manifest = self._get_parsed_manifest()
        if path not in parsed_manifest.entries:
            raise ViteAssetNotFoundError(
                f"Cannot find asset {path!r} for Vite app {self.app_name}."
            )
        return parsed_manifest.entries[path]

    @property
    def legacy_polyfills_entry(self) -> ManifestEntry | None:
        return self._get_parsed_manifest().legacy_polyfills_entry

    def _get_parsed_manifest(self) -> ParsedManifest:
        if self._parsed_manifest is None:
            self._parsed_manifest = self.parse_manifest()
        return self._parsed_manifest


def _coerce_manifest_path(config: ViteConfig) -> Path | None:
    manifest_path = config.resolved_manifest_path
    if manifest_path is None:
        return None
    return manifest_path if isinstance(manifest_path, Path) else Path(manifest_path)
