from __future__ import annotations

from collections.abc import Mapping

from fastapi.templating import Jinja2Templates
from markupsafe import Markup

from .client import DEFAULT_APP_NAME, ViteRegistry
from .config import ViteConfig


def register_vite(
    templates: Jinja2Templates,
    apps: Mapping[str, ViteConfig] | ViteRegistry,
    *,
    default_app: str = DEFAULT_APP_NAME,
) -> Jinja2Templates:
    registry = (
        apps
        if isinstance(apps, ViteRegistry)
        else ViteRegistry(
            apps,
            default_app=default_app,
        )
    )

    def vite_asset(path: str, app: str | None = None, **attrs: object) -> Markup:
        return registry.asset(path, app=app, **attrs)

    def vite_asset_url(path: str, app: str | None = None) -> str:
        return registry.asset_url(path, app=app)

    def vite_preload_asset(path: str, app: str | None = None) -> Markup:
        return registry.preload_asset(path, app=app)

    def vite_hmr_client(app: str | None = None, **attrs: object) -> Markup:
        return registry.hmr_client(app=app, **attrs)

    def vite_react_refresh(app: str | None = None, **attrs: object) -> Markup:
        return registry.react_refresh(app=app, **attrs)

    def vite_legacy_asset(
        path: str,
        app: str | None = None,
        **attrs: object,
    ) -> Markup:
        return registry.legacy_asset(path, app=app, **attrs)

    def vite_legacy_polyfills(
        app: str | None = None,
        *,
        nomodule: bool = True,
        **attrs: object,
    ) -> Markup:
        return registry.legacy_polyfills(
            app=app,
            nomodule=nomodule,
            **attrs,
        )

    templates.env.globals["vite_asset"] = vite_asset
    templates.env.globals["vite_asset_url"] = vite_asset_url
    templates.env.globals["vite_preload_asset"] = vite_preload_asset
    templates.env.globals["vite_hmr_client"] = vite_hmr_client
    templates.env.globals["vite_react_refresh"] = vite_react_refresh
    templates.env.globals["vite_legacy_asset"] = vite_legacy_asset
    templates.env.globals["vite_legacy_polyfills"] = vite_legacy_polyfills
    templates.env.globals["vite_registry"] = registry
    return templates
