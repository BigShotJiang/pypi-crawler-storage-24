from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, TypeAlias

if TYPE_CHECKING:
    from .client import ViteClient

ViteClientClass: TypeAlias = type["ViteClient"] | str


@dataclass(frozen=True, slots=True)
class ViteConfig:
    dev_mode: bool = False
    dev_server_url: str | None = None
    base_path: str = "/"
    static_url: str = "/static/"
    manifest_path: Path | str | None = None
    legacy_polyfills_motif: str = "legacy-polyfills"
    ws_client_url: str = "@vite/client"
    react_refresh_url: str = "@react-refresh"
    client_class: ViteClientClass | None = None

    @property
    def resolved_manifest_path(self) -> Path | None:
        manifest_path = self.manifest_path
        if manifest_path is None or isinstance(manifest_path, Path):
            return manifest_path
        return Path(manifest_path)
