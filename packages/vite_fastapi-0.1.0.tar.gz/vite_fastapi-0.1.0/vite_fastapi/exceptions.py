class ViteManifestError(RuntimeError):
    """Raised when the Vite manifest cannot be read or parsed."""


class ViteAssetNotFoundError(RuntimeError):
    """Raised when an asset key cannot be found in a Vite manifest."""


class ViteAppNotFoundError(RuntimeError):
    """Raised when a named Vite app is missing from the registry."""
