from __future__ import annotations

import json
from collections.abc import Callable, Mapping
from importlib import import_module
from urllib.parse import urljoin

from markupsafe import Markup, escape

from .config import ViteConfig
from .exceptions import ViteAppNotFoundError, ViteAssetNotFoundError
from .manifest import ManifestClient

DEFAULT_APP_NAME = "default"


def _normalize_path_prefix(value: str) -> str:
    normalized = value.strip() or "/"
    if not normalized.startswith("/"):
        normalized = f"/{normalized}"
    if not normalized.endswith("/"):
        normalized = f"{normalized}/"
    return normalized


def _normalize_public_base(value: str) -> str:
    normalized = value.strip() or "/"
    if "://" in normalized:
        return normalized if normalized.endswith("/") else f"{normalized}/"
    return _normalize_path_prefix(normalized)


def _join_public_url(base_url: str, path: str) -> str:
    return urljoin(_normalize_public_base(base_url), path.lstrip("/"))


def _render_attrs(attrs: Mapping[str, object]) -> str:
    rendered: list[str] = []
    for key, value in attrs.items():
        if value is None:
            continue
        rendered.append(f'{escape(key.replace("_", "-"))}="{escape(str(value))}"')
    return " ".join(rendered)


def _script_tag(src: str, attrs: Mapping[str, object]) -> Markup:
    attrs_str = _render_attrs(attrs)
    if attrs_str:
        return Markup(f'<script {attrs_str} src="{escape(src)}"></script>')
    return Markup(f'<script src="{escape(src)}"></script>')


def _inline_script(body: str, attrs: Mapping[str, object]) -> Markup:
    attrs_str = _render_attrs(attrs)
    if attrs_str:
        return Markup(f"<script {attrs_str}>{body}</script>")
    return Markup(f"<script>{body}</script>")


def _stylesheet_tag(href: str, attrs: Mapping[str, object]) -> Markup:
    attrs_str = _render_attrs(attrs)
    if attrs_str:
        return Markup(f'<link {attrs_str} rel="stylesheet" href="{escape(href)}" />')
    return Markup(f'<link rel="stylesheet" href="{escape(href)}" />')


def _stylesheet_preload_tag(href: str, attrs: Mapping[str, object]) -> Markup:
    attrs_str = _render_attrs(attrs)
    if attrs_str:
        return Markup(
            f'<link {attrs_str} rel="preload" href="{escape(href)}" as="style" />'
        )
    return Markup(f'<link rel="preload" href="{escape(href)}" as="style" />')


def _preload_tag(href: str, attrs: Mapping[str, object]) -> Markup:
    attrs_str = _render_attrs(attrs)
    if attrs_str:
        return Markup(f'<link href="{escape(href)}" {attrs_str} />')
    return Markup(f'<link href="{escape(href)}" />')


class ViteClient:
    ManifestClient = ManifestClient

    def __init__(self, config: ViteConfig, app_name: str = DEFAULT_APP_NAME) -> None:
        self.config = config
        self.app_name = app_name
        self.dev_mode = config.dev_mode
        self.dev_server_url = (
            config.dev_server_url.rstrip("/") if config.dev_server_url else None
        )
        self.base_path = _normalize_path_prefix(config.base_path)
        self.static_url = _normalize_public_base(config.static_url)
        self.ws_client_url = config.ws_client_url
        self.react_refresh_url = config.react_refresh_url
        self.manifest = self.ManifestClient(config, app_name)

    def get_dev_server_url(self, path: str) -> str:
        if self.dev_server_url is None:
            raise ValueError(
                f"Vite dev server URL is not configured for app {self.app_name}."
            )
        return f"{self.dev_server_url}{self.base_path}{path.lstrip('/')}"

    def get_production_server_url(self, path: str) -> str:
        return _join_public_url(self.static_url, path)

    def asset(self, path: str, **attrs: object) -> Markup:
        if self.dev_mode:
            return _script_tag(
                self.get_dev_server_url(path),
                attrs={"type": "module", **attrs},
            )

        manifest_entry = self.manifest.get_entry(path)
        tags = [*self._load_css_files_of_asset(path, attrs=attrs)]
        tags.append(
            _script_tag(
                self.get_production_server_url(manifest_entry.file),
                attrs={"type": "module", "crossorigin": "", **attrs},
            )
        )

        preload_attrs = {
            "type": "text/javascript",
            "crossorigin": "anonymous",
            "rel": "modulepreload",
            "as": "script",
            **attrs,
        }
        tags.extend(self._preload_imports_of_asset(path, attrs=preload_attrs))

        return Markup("\n").join(tags)

    def asset_url(self, path: str) -> str:
        if self.dev_mode:
            return self.get_dev_server_url(path)
        return self.get_production_server_url(self.manifest.get_entry(path).file)

    def preload_asset(self, path: str) -> Markup:
        if self.dev_mode:
            return Markup("")

        manifest_entry = self.manifest.get_entry(path)
        preload_attrs = {
            "type": "text/javascript",
            "crossorigin": "anonymous",
            "rel": "modulepreload",
            "as": "script",
        }
        tags = [
            _preload_tag(
                self.get_production_server_url(manifest_entry.file),
                attrs=preload_attrs,
            ),
            *self._preload_css_files_of_asset(path),
        ]
        tags.extend(self._preload_imports_of_asset(path, attrs=preload_attrs))
        return Markup("\n").join(tags)

    def hmr_client(self, **attrs: object) -> Markup:
        if not self.dev_mode:
            return Markup("")
        return _script_tag(
            self.get_dev_server_url(self.ws_client_url),
            attrs={"type": "module", **attrs},
        )

    def react_refresh(self, **attrs: object) -> Markup:
        if not self.dev_mode:
            return Markup("")
        refresh_url = json.dumps(self.get_dev_server_url(self.react_refresh_url))
        body = (
            f"import RefreshRuntime from {refresh_url};"
            "RefreshRuntime.injectIntoGlobalHook(window);"
            "window.$RefreshReg$ = () => {};"
            "window.$RefreshSig$ = () => (type) => type;"
            "window.__vite_plugin_react_preamble_installed__ = true;"
        )
        return _inline_script(body, attrs={"type": "module", **attrs})

    def legacy_asset(self, path: str, **attrs: object) -> Markup:
        if self.dev_mode:
            return Markup("")
        manifest_entry = self.manifest.get_entry(path)
        return _script_tag(
            self.get_production_server_url(manifest_entry.file),
            attrs={"nomodule": "", "crossorigin": "", **attrs},
        )

    def legacy_polyfills(self, *, nomodule: bool = True, **attrs: object) -> Markup:
        if self.dev_mode:
            return Markup("")
        manifest_entry = self.manifest.legacy_polyfills_entry
        if manifest_entry is None:
            raise ViteAssetNotFoundError(
                f"Vite legacy polyfills not found for app {self.app_name}."
            )
        tag_attrs: dict[str, object] = {"crossorigin": "", **attrs}
        if nomodule:
            tag_attrs["nomodule"] = ""
        return _script_tag(
            self.get_production_server_url(manifest_entry.file),
            attrs=tag_attrs,
        )

    def _preload_css_files_of_asset(self, path: str) -> list[Markup]:
        return self._generate_css_files_of_asset(
            path,
            tag_generator=_stylesheet_preload_tag,
            attrs={},
        )

    def _load_css_files_of_asset(
        self,
        path: str,
        attrs: Mapping[str, object],
    ) -> list[Markup]:
        return self._generate_css_files_of_asset(
            path,
            tag_generator=_stylesheet_tag,
            attrs=attrs,
        )

    def _preload_imports_of_asset(
        self,
        path: str,
        *,
        attrs: Mapping[str, object],
        seen_js: set[str] | None = None,
    ) -> list[Markup]:
        if seen_js is None:
            seen_js = set()

        tags: list[Markup] = []
        manifest_entry = self.manifest.get_entry(path)

        for import_path in manifest_entry.imports:
            if import_path in seen_js:
                continue
            seen_js.add(import_path)
            import_entry = self.manifest.get_entry(import_path)
            tags.append(
                _preload_tag(
                    self.get_production_server_url(import_entry.file),
                    attrs=attrs,
                )
            )
            tags.extend(
                self._preload_imports_of_asset(
                    import_path,
                    attrs=attrs,
                    seen_js=seen_js,
                )
            )

        return tags

    def _generate_css_files_of_asset(
        self,
        path: str,
        *,
        tag_generator: Callable[[str, Mapping[str, object]], Markup],
        attrs: Mapping[str, object],
        seen_js: set[str] | None = None,
        seen_css: set[str] | None = None,
    ) -> list[Markup]:
        if seen_js is None:
            seen_js = set()
        if seen_css is None:
            seen_css = set()

        tags: list[Markup] = []
        manifest_entry = self.manifest.get_entry(path)

        for css_path in manifest_entry.css:
            if css_path in seen_css:
                continue
            seen_css.add(css_path)
            tags.append(
                tag_generator(self.get_production_server_url(css_path), attrs=attrs)
            )

        for import_path in manifest_entry.imports:
            if import_path in seen_js:
                continue
            seen_js.add(import_path)
            tags.extend(
                self._generate_css_files_of_asset(
                    import_path,
                    tag_generator=tag_generator,
                    attrs=attrs,
                    seen_js=seen_js,
                    seen_css=seen_css,
                )
            )

        return tags


class ViteRegistry:
    def __init__(
        self,
        apps: Mapping[str, ViteConfig],
        *,
        default_app: str = DEFAULT_APP_NAME,
    ) -> None:
        if not apps:
            raise ValueError("At least one Vite app config is required.")
        self._apps = dict(apps)
        self.default_app = default_app
        self._clients: dict[str, ViteClient] = {}

    def get_client(self, app: str | None = None) -> ViteClient:
        app_name = app or self.default_app
        if app_name not in self._apps:
            raise ViteAppNotFoundError(f"Cannot find Vite app {app_name!r}.")
        if app_name not in self._clients:
            config = self._apps[app_name]
            client_class = _resolve_client_class(config.client_class)
            self._clients[app_name] = client_class(config, app_name)
        return self._clients[app_name]

    def asset(self, path: str, *, app: str | None = None, **attrs: object) -> Markup:
        return self.get_client(app).asset(path, **attrs)

    def asset_url(self, path: str, *, app: str | None = None) -> str:
        return self.get_client(app).asset_url(path)

    def preload_asset(self, path: str, *, app: str | None = None) -> Markup:
        return self.get_client(app).preload_asset(path)

    def hmr_client(self, *, app: str | None = None, **attrs: object) -> Markup:
        return self.get_client(app).hmr_client(**attrs)

    def react_refresh(self, *, app: str | None = None, **attrs: object) -> Markup:
        return self.get_client(app).react_refresh(**attrs)

    def legacy_asset(
        self,
        path: str,
        *,
        app: str | None = None,
        **attrs: object,
    ) -> Markup:
        return self.get_client(app).legacy_asset(path, **attrs)

    def legacy_polyfills(
        self,
        *,
        app: str | None = None,
        nomodule: bool = True,
        **attrs: object,
    ) -> Markup:
        return self.get_client(app).legacy_polyfills(
            nomodule=nomodule,
            **attrs,
        )


def _resolve_client_class(
    client_class: type[ViteClient] | str | None,
) -> type[ViteClient]:
    if client_class is None:
        return ViteClient
    if isinstance(client_class, str):
        module_name, _, attr_name = client_class.rpartition(".")
        if not module_name or not attr_name:
            raise ValueError(f"Invalid Vite client import path: {client_class}")
        resolved = getattr(import_module(module_name), attr_name)
    else:
        resolved = client_class
    if not isinstance(resolved, type) or not issubclass(resolved, ViteClient):
        raise TypeError("Vite client class must inherit from ViteClient.")
    return resolved
