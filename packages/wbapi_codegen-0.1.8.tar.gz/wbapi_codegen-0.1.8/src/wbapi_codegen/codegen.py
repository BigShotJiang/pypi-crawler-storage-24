"""
Wildberries API code generator for wbapi-async.

Parses OpenAPI YAML files and generates:
  - <target>/src/wbapi_async/types/<name>.py
  - <target>/src/wbapi_async/methods/<name>.py
  - <target>/src/wbapi_async/types/__init__.py
  - <target>/src/wbapi_async/methods/__init__.py
  - <target>/src/wbapi_async/client/api.py
"""

from __future__ import annotations

import re
import subprocess
from dataclasses import dataclass
from keyword import iskeyword
from pathlib import Path
from typing import Any

import yaml


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_CAMEL_RE = re.compile(r"(?<=[a-z0-9])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])")
_HTML_TAG_RE = re.compile(r"<[^>]+>")


def _clean_description(text: str) -> str:
    """Remove HTML tags, strip rate-limit tables, and normalize whitespace."""
    # Take only the first non-empty paragraph (before blank line or markdown table)
    first_para_lines = []
    for line in text.splitlines():
        if not line.strip() and first_para_lines:
            break
        if line.lstrip().startswith("|"):
            break
        first_para_lines.append(line)
    text = " ".join(first_para_lines)
    text = _HTML_TAG_RE.sub(" ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


import builtins as _builtins_module
_BUILTINS = frozenset(dir(_builtins_module))


def camel_to_snake(name: str) -> str:
    """nmID → nm_id, listGoods → list_goods, X-Nm-Id → x_nm_id"""
    name = re.sub(r"[^a-zA-Z0-9]", "_", name)
    s = _CAMEL_RE.sub("_", name).lower()
    s = re.sub(r"_+", "_", s).strip("_")
    if iskeyword(s) or s in _BUILTINS:
        s = s + "_"
    return s


def snake_to_class(name: str) -> str:
    return "".join(w.title() for w in name.split("_"))


def path_to_method_name(path: str) -> str:
    parts = [p for p in path.strip("/").split("/") if p]
    if parts and parts[0] == "api":
        parts = parts[1:]
    parts = [p for p in parts if not re.fullmatch(r"v\d+", p)]
    parts = [re.sub(r"\{(\w+)\}", lambda m: camel_to_snake(m.group(1)), p) for p in parts]
    parts = [camel_to_snake(p) for p in parts]
    return "_".join(parts)


def openapi_type_to_python(
    schema: dict[str, Any],
    required: bool = False,
    field_name: str = "",
    enum_registry: dict[str, "EnumDef"] | None = None,
    conflict_hint: str = "",
) -> str:
    if not schema:
        return "Any"
    nullable = schema.get("nullable", False)
    t = schema.get("type")
    ref = schema.get("$ref")
    enum_values = schema.get("enum")

    if ref:
        base = "Any"
    elif enum_values and field_name and enum_registry is not None:
        values = [str(v) for v in enum_values if v is not None]
        stem = camel_to_snake(field_name)
        class_name = snake_to_class(stem)
        # Check if an enum with identical values already exists anywhere (reuse it)
        matched_stem = next(
            (k for k, ed in enum_registry.items() if sorted(ed.values) == sorted(values)),
            None,
        )
        if matched_stem:
            stem = matched_stem
            class_name = enum_registry[matched_stem].class_name
        else:
            # If the preferred name is taken by a different enum, use conflict_hint as suffix
            if stem in enum_registry and sorted(enum_registry[stem].values) != sorted(values):
                if conflict_hint:
                    hint_stem = f"{stem}_{camel_to_snake(conflict_hint)}"
                    # If hint also conflicts (different values), fall back to numeric
                    if hint_stem in enum_registry and sorted(enum_registry[hint_stem].values) != sorted(values):
                        i = 2
                        while f"{stem}_{i}" in enum_registry:
                            i += 1
                        stem = f"{stem}_{i}"
                    else:
                        stem = hint_stem
                else:
                    i = 2
                    while f"{stem}_{i}" in enum_registry:
                        i += 1
                    stem = f"{stem}_{i}"
                class_name = snake_to_class(stem)
            if stem not in enum_registry:
                enum_registry[stem] = EnumDef(
                    class_name=class_name,
                    file_stem=stem,
                    values=values,
                    description=_clean_description(schema.get("description", "").split("\n")[0]),
                )
        base = class_name
    elif t == "integer":
        base = "int"
    elif t == "number":
        base = "float"
    elif t == "boolean":
        base = "bool"
    elif t == "string":
        base = "str"
    elif t == "array":
        items = schema.get("items", {})
        inner = openapi_type_to_python(items, required=True)
        base = f"list[{inner}]"
    elif t == "object":
        base = "dict[str, Any]"
    else:
        base = "Any"
    if not required or nullable:
        return f"{base} | None"
    return base


# ---------------------------------------------------------------------------
# Rate limit parsing
# ---------------------------------------------------------------------------

_RL_TABLE_RE = re.compile(
    r"\|\s*(\d+)\s+(\w+)\s*\|"
    r"\s*(\d+)\s+requests?\s*\|"
    r"\s*(\d+)\s+(\w+)\s*\|"
    r"\s*(\d+)\s+requests?\s*\|",
    re.IGNORECASE,
)

_PERIOD_UNITS = {"sec": 1, "s": 1, "min": 60, "minute": 60, "hour": 3600}
_INTERVAL_UNITS = {"ms": 1, "s": 1000, "sec": 1000, "min": 60_000}


def _parse_duration(value: int, unit: str) -> int:
    u = unit.lower()
    result = _PERIOD_UNITS.get(u) or _PERIOD_UNITS.get(u.rstrip("s"))
    return value * (result or 60)


def yaml_stem_to_module(stem: str) -> str:
    """Convert YAML filename stem to module name: '02-products' → 'products'."""
    return re.sub(r"^\d+-", "", stem).replace("-", "_")


def _import_line(module: str, name: str, max_width: int = 110) -> str:
    """Return `from {module} import {name}`, wrapped in parens if > max_width."""
    line = f"from {module} import {name}"
    if len(line) <= max_width:
        return line
    return f"from {module} import (\n    {name},\n)"


def _parse_interval(value: int, unit: str) -> int:
    u = unit.lower().rstrip("s")
    return value * _INTERVAL_UNITS.get(u, 1)


@dataclass
class RateLimit:
    period: int = 60
    limit: int = 10
    interval: int = 600
    burst: int = 5

    def __str__(self) -> str:
        return (
            f"RequestLimit(period={self.period}, limit={self.limit}, "
            f"interval={self.interval}, burst={self.burst})"
        )


_DEFAULT_RATE_LIMIT = RateLimit()


def parse_rate_limit(description: str) -> RateLimit:
    if not description:
        return _DEFAULT_RATE_LIMIT
    m = _RL_TABLE_RE.search(description)
    if not m:
        return _DEFAULT_RATE_LIMIT
    period_val, period_unit, limit_val, interval_val, interval_unit, burst_val = m.groups()
    return RateLimit(
        period=_parse_duration(int(period_val), period_unit),
        limit=int(limit_val),
        interval=_parse_interval(int(interval_val), interval_unit),
        burst=int(burst_val),
    )


# ---------------------------------------------------------------------------
# Intermediate representation
# ---------------------------------------------------------------------------

@dataclass
class EnumDef:
    class_name: str   # e.g. SupplierStatus
    file_stem: str    # e.g. supplier_status
    values: list[str]
    description: str = ""


@dataclass
class FieldDef:
    py_name: str
    alias: str
    py_type: str
    default: Any
    description: str = ""
    exclude: bool = False


@dataclass
class TypeDef:
    class_name: str
    fields: list[FieldDef]
    description: str = ""


@dataclass
class MethodDef:
    class_name: str
    method_name: str
    api_host: str
    http_method: str
    path: str
    path_template: str | None
    return_type: str
    return_type_file: str
    data_key: str | None
    rate_limit: RateLimit
    params: list[FieldDef]
    description: str = ""
    source_url: str = ""
    type_def: TypeDef | None = None
    empty_response: bool = False  # True for 204 No Content or empty schema
    pagination: str | None = None  # "offset", "next", "take_skip", or None


def detect_pagination(params: list["FieldDef"]) -> str | None:
    """Detect pagination pattern from method parameter names."""
    aliases = {p.alias for p in params}
    if "limit" in aliases and "offset" in aliases:
        return "offset"
    if "limit" in aliases and "next" in aliases:
        return "next"
    if "take" in aliases and "skip" in aliases:
        return "take_skip"
    return None


# ---------------------------------------------------------------------------
# OpenAPI parser
# ---------------------------------------------------------------------------

def _host_from_server(servers: list[dict]) -> str:
    if not servers:
        return "api"
    url: str = servers[0].get("url", "")
    host = url.replace("https://", "").replace("http://", "")
    host = re.sub(r"\.wildberries\.ru$", "", host)
    host = re.sub(r"\.ru$", "", host)
    return host


def _resolve_ref(ref: str, spec: dict) -> dict:
    parts = ref.lstrip("#/").split("/")
    node: Any = spec
    for part in parts:
        if isinstance(node, dict):
            node = node.get(part, {})
        else:
            return {}
    return node if isinstance(node, dict) else {}


def _resolve_schema(schema: dict, spec: dict) -> dict:
    if "$ref" not in schema:
        return schema
    return _resolve_ref(schema["$ref"], spec)


def _collect_fields(schema: dict, spec: dict, required_set: set[str] | None = None) -> list[FieldDef]:
    schema = _resolve_schema(schema, spec)
    props = schema.get("properties", {})
    required_keys = set(schema.get("required", required_set or []))
    fields: list[FieldDef] = []
    for prop_name, prop_schema in props.items():
        prop_schema = _resolve_schema(prop_schema, spec)
        py_name = camel_to_snake(prop_name)
        required = prop_name in required_keys
        py_type = openapi_type_to_python(prop_schema, required=required, field_name=prop_name)
        desc = _clean_description(prop_schema.get("description", "").split("\n")[0])
        fields.append(FieldDef(
            py_name=py_name,
            alias=prop_name,
            py_type=py_type,
            default=None,
            description=desc,
        ))
    return fields


def _find_response_array(schema: dict, spec: dict) -> tuple[list[FieldDef], str | None]:
    schema = _resolve_schema(schema, spec)

    def walk(node: dict, path: list[str]) -> tuple[list[FieldDef] | None, list[str] | None]:
        node = _resolve_schema(node, spec)
        if node.get("type") == "array":
            items = _resolve_schema(node.get("items", {}), spec)
            return _collect_fields(items, spec), path
        if node.get("type") == "object" or "properties" in node:
            for prop, sub in node.get("properties", {}).items():
                result, found_path = walk(_resolve_schema(sub, spec), path + [prop])
                if result is not None:
                    return result, found_path
        return None, None

    fields, path_parts = walk(schema, [])
    if fields is None:
        fields = _collect_fields(schema, spec)
        return fields, None
    dot_path = ".".join(path_parts) if path_parts else None
    return fields, dot_path


_DOC_SLUG_MAP: dict[str, str] = {
    "01-general": "api-information",
    "02-products": "work-with-products",
    "03-orders-fbs": "orders-fbs",
    "04-orders-dbw": "orders-dbw",
    "05-orders-dbs": "orders-dbs",
    "06-in-store-pickup": "in-store-pickup",
    "07-orders-fbw": "orders-fbw",
    "08-promotion": "promotion",
    "09-communications": "communications",
    "10-tariffs": "tariffs",
    "11-analytics": "analytics",
    "12-reports": "reports",
    "13-finances": "financial-reports-and-accounting",
}


def _yaml_stem_to_doc_slug(stem: str) -> str:
    return _DOC_SLUG_MAP.get(stem, stem)


def parse_yaml(
    yaml_path: Path,
    enum_registry: dict[str, EnumDef] | None = None,
) -> tuple[list[MethodDef], dict[str, EnumDef]]:
    with yaml_path.open() as f:
        spec = yaml.safe_load(f)

    paths = spec.get("paths", {})
    results: list[MethodDef] = []
    if enum_registry is None:
        enum_registry = {}

    for path_str, path_item in paths.items():
        path_servers = path_item.get("servers", [])

        # Last non-param, non-version segment for conflict hint: /api/v1/cards/blocked → "blocked"
        path_segments = [
            s for s in path_str.strip("/").split("/")
            if s and not re.fullmatch(r"v\d+", s) and not s.startswith("{")
        ]
        conflict_hint = path_segments[-1] if path_segments else ""

        for http_verb in ("get", "post", "put", "delete", "patch"):
            operation = path_item.get(http_verb)
            if not operation:
                continue

            servers = operation.get("servers") or path_servers or spec.get("servers", [])
            api_host = _host_from_server(servers)
            http_method = http_verb.upper()
            summary = operation.get("summary", "")
            description = _clean_description(operation.get("description", ""))
            rate_limit = parse_rate_limit(description)

            # request parameters
            parameters = operation.get("parameters", []) + path_item.get("parameters", [])
            param_fields: list[FieldDef] = []
            path_params: list[str] = []

            for param in parameters:
                param = _resolve_schema(param, spec)
                p_name: str = param.get("name", "")
                p_in: str = param.get("in", "query")
                p_required: bool = param.get("required", p_in == "path")
                p_schema = _resolve_schema(param.get("schema", {}), spec)
                py_name = camel_to_snake(p_name)
                py_type = openapi_type_to_python(p_schema, required=p_required, field_name=p_name, enum_registry=enum_registry, conflict_hint=conflict_hint)
                default_val = p_schema.get("default")
                # If field has enum type, validate default against known values
                if default_val is not None:
                    base_type = py_type.replace(" | None", "").strip()
                    ed = next((e for e in enum_registry.values() if e.class_name == base_type), None)
                    if ed is not None and str(default_val) not in ed.values:
                        default_val = None
                desc = _clean_description(param.get("description", "").split("\n")[0])

                if p_in == "path":
                    path_params.append(py_name)
                    param_fields.append(FieldDef(
                        py_name=py_name,
                        alias=p_name,
                        py_type=py_type.replace(" | None", ""),
                        default=None,
                        description=desc,
                        exclude=True,
                    ))
                else:
                    if not p_required and default_val is None:
                        py_type = py_type if "| None" in py_type else f"{py_type} | None"
                    param_fields.append(FieldDef(
                        py_name=py_name,
                        alias=p_name,
                        py_type=py_type,
                        default=default_val,
                        description=desc,
                    ))

            # request body
            request_body = _resolve_schema(operation.get("requestBody", {}), spec)
            if request_body:
                body_content = request_body.get("content", {})
                body_schema = _resolve_schema(
                    body_content.get("application/json", {}).get("schema", {}), spec
                )
                body_required_keys = set(body_schema.get("required", []))
                for prop_name, prop_schema in body_schema.get("properties", {}).items():
                    prop_schema = _resolve_schema(prop_schema, spec)
                    py_name = camel_to_snake(prop_name)
                    required = prop_name in body_required_keys
                    py_type = openapi_type_to_python(prop_schema, required=required, field_name=prop_name, enum_registry=enum_registry, conflict_hint=conflict_hint)
                    default_val = prop_schema.get("default")
                    if default_val is not None:
                        base_type = py_type.replace(" | None", "").strip()
                        ed = next((e for e in enum_registry.values() if e.class_name == base_type), None)
                        if ed is not None and str(default_val) not in ed.values:
                            default_val = None
                    desc = _clean_description(prop_schema.get("description", "").split("\n")[0])
                    param_fields.append(FieldDef(
                        py_name=py_name,
                        alias=prop_name,
                        py_type=py_type,
                        default=default_val,
                        description=desc,
                    ))

            # response type
            responses = operation.get("responses", {})
            # prefer 200, then 201, then 204
            ok_response = _resolve_schema(
                responses.get("200", responses.get("201", responses.get("204", {}))), spec
            )
            ok_content = ok_response.get("content", {})
            ok_schema = _resolve_schema(
                ok_content.get("application/json", {}).get("schema", {}), spec
            )
            item_fields, data_key = _find_response_array(ok_schema, spec)
            empty_response = not ok_content or not ok_schema

            # build names from summary
            if summary:
                words = re.sub(r"[^a-zA-Z0-9 ]", "", summary).split()
                method_name = "_".join(w.lower() for w in words)
            else:
                verb_map = {"GET": "get", "POST": "post", "PUT": "update", "DELETE": "delete", "PATCH": "patch"}
                method_name = f"{verb_map.get(http_method, http_method.lower())}_{path_to_method_name(path_str)}"

            if http_method == "GET" and not method_name.startswith("get_"):
                method_name = "get_" + method_name

            type_base = method_name[4:] if method_name.startswith("get_") else method_name
            class_name = snake_to_class(method_name)
            type_class_base = snake_to_class(type_base)
            type_name = type_class_base + "Item" if data_key else type_class_base + "Response"
            type_file = camel_to_snake(type_name)

            path_clean = path_str.lstrip("/")
            if path_params:
                path_template = re.sub(
                    r"\{(\w+)\}",
                    lambda m: "{" + camel_to_snake(m.group(1)) + "}",
                    path_clean,
                )
                path_for_method = ""
            else:
                path_template = None
                path_for_method = path_clean

            tag = (operation.get("tags") or [""])[0]
            tag_slug = re.sub(r"-+", "-", re.sub(r"[^a-zA-Z0-9]", "-", tag)).strip("-")
            path_encoded = (
                path_str.replace("/", "~1")
                        .replace("{", "%7B")
                        .replace("}", "%7D")
            )
            source_url = (
                f"https://dev.wildberries.ru/en/docs/openapi/"
                f"{_yaml_stem_to_doc_slug(yaml_path.stem)}"
                f"#tag/{tag_slug}/paths/{path_encoded}/{http_verb}"
            )

            results.append(MethodDef(
                class_name=class_name,
                method_name=method_name,
                api_host=api_host,
                http_method=http_method,
                path=path_for_method,
                path_template=path_template,
                return_type=type_name,
                return_type_file=type_file,
                data_key=data_key,
                rate_limit=rate_limit,
                params=param_fields,
                description=description.strip().split("\n")[0] or summary,
                source_url=source_url,
                empty_response=empty_response,
                pagination=detect_pagination(param_fields),
                type_def=TypeDef(
                    class_name=type_name,
                    fields=item_fields or [],
                    description=summary,
                ),
            ))

    return results, enum_registry


# ---------------------------------------------------------------------------
# Code generators
# ---------------------------------------------------------------------------

_PAGINATION_ALIASES: dict[str, set[str]] = {
    "offset": {"limit", "offset"},
    "next": {"limit", "next"},
    "take_skip": {"take", "skip"},
}


def _format_default(py_type: str, default: Any, enum_registry: dict[str, "EnumDef"] | None = None) -> str:
    """Format a default value, using EnumClass.MEMBER syntax for enum types."""
    if isinstance(default, list):
        return str(tuple(default))
    if isinstance(default, str) and enum_registry is not None:
        base_type = py_type.replace(" | None", "").strip()
        ed = next((e for e in enum_registry.values() if e.class_name == base_type), None)
        if ed is not None:
            for val in ed.values:
                if val == default:
                    member = re.sub(r"[^a-zA-Z0-9]", "_", val).upper().strip("_")
                    member = re.sub(r"_+", "_", member)
                    if not member or member[0].isdigit():
                        member = "V_" + member
                    return f"{base_type}.{member}"
    if isinstance(default, str):
        return f'"{default}"'
    return str(default)


def _field_line(f: FieldDef, indent: int = 4, enum_registry: dict[str, "EnumDef"] | None = None) -> str:
    pad = " " * indent
    alias_part = f', alias="{f.alias}"' if f.alias != f.py_name else ""
    exclude_part = ", exclude=True" if f.exclude else ""

    if f.default is None and not f.exclude and "| None" in f.py_type:
        default_part = "None"
    elif f.default is not None:
        default_part = _format_default(f.py_type, f.default, enum_registry)
    else:
        default_part = None

    if default_part is not None:
        return f"{pad}{f.py_name}: {f.py_type} = Field({default_part}{alias_part}{exclude_part})"
    else:
        args = ", ".join(filter(None, [alias_part.lstrip(", "), exclude_part.lstrip(", ")]))
        return f"{pad}{f.py_name}: {f.py_type} = Field({args})"


def _enum_imports_for_fields(
    fields: list[FieldDef],
    enum_registry: dict[str, "EnumDef"],
    in_module: bool = False,
) -> list[str]:
    """Return sorted import lines for any enum types used in fields.

    When in_module=True the file is 2 levels deep ({module}/types/ or {module}/methods/),
    so enums live at wbapi_async/{module}/enums/. We import from the flat enums package
    (wbapi_async/enums/__init__.py) which re-exports everything: "from ...enums import Cls".
    When in_module=False the file is 1 level deep (types/ or methods/): "from ..enums.stem import Cls".
    """
    known_enum_classes = {ed.class_name: ed.file_stem for ed in enum_registry.values()}
    seen: list[str] = []
    for f in fields:
        base = f.py_type.replace(" | None", "").strip()
        if base in known_enum_classes and base not in seen:
            seen.append(base)
    if in_module:
        # All enums come from the flat enums package — merge into one import
        if not seen:
            return []
        names = sorted(seen, key=str.casefold)
        one_line = f"from ...enums import {', '.join(names)}"
        if len(one_line) <= 110:
            return [one_line]
        return [f"from ...enums import (\n    " + ",\n    ".join(names) + ",\n)"]
    else:
        enum_prefix = "..enums"
        return [_import_line(f"{enum_prefix}.{known_enum_classes[cls]}", cls) for cls in sorted(seen, key=str.casefold)]


def generate_type_file(
    td: TypeDef,
    enum_registry: dict[str, "EnumDef"] | None = None,
    in_module: bool = False,
) -> str:
    uses_any = any("Any" in f.py_type for f in td.fields)
    base_import = "...types.base import BaseType" if in_module else ".base import BaseType"
    imports = (["from pydantic import Field", ""] if td.fields else []) + [f"from {base_import}"]
    if uses_any:
        imports.insert(0, "from typing import Any")
        imports.insert(1, "")
    if enum_registry:
        enum_imps = _enum_imports_for_fields(td.fields, enum_registry, in_module=in_module)
        if enum_imps:
            imports += enum_imps
    lines = imports + ["", ""]
    lines.append(f"class {td.class_name}(BaseType):")
    if td.description:
        lines.append(f'    """{td.description}"""')
        lines.append("")
    if not td.fields:
        lines.append("    pass")
    else:
        for f in td.fields:
            lines.append(_field_line(f, enum_registry=enum_registry))
    lines.append("")
    return "\n".join(lines)


def generate_enum_file(ed: EnumDef) -> str:
    lines = ["from enum import StrEnum", "", ""]
    lines.append(f"class {ed.class_name}(StrEnum):")
    if ed.description:
        lines.append(f'    """{ed.description}"""')
        lines.append("")
    for v in ed.values:
        member = re.sub(r"[^a-zA-Z0-9]", "_", v).upper().strip("_")
        member = re.sub(r"_+", "_", member)
        if not member or member[0].isdigit():
            member = "V_" + member
        lines.append(f'    {member} = "{v}"')
    lines.append("")
    return "\n".join(lines)


def generate_enums_init(entries: list[tuple[str, str]]) -> str:
    sorted_entries = sorted(entries, key=lambda e: e[1])
    lines = []
    for class_name, stem in sorted_entries:
        lines.append(_import_line(_stem_to_import(stem), class_name))
    lines += ["", "", "__all__ = ("]
    for class_name, _ in sorted_entries:
        lines.append(f'    "{class_name}",')
    lines += [")", ""]
    return "\n".join(lines)


def generate_method_file(
    md: MethodDef,
    enum_registry: dict[str, "EnumDef"] | None = None,
    in_module: bool = False,
) -> str:
    # When in_module=True, file is at {module}/methods/foo.py (2 levels deep):
    #   - types/RequestLimit/WbMethod are all in flat package dirs → use "..." (3 dots)
    #   - return type is imported from flat types package (handles cross-module types)
    # When in_module=False, file is at methods/foo.py (1 level deep): use ".."
    flat_prefix = "..." if in_module else ".."
    base_import = f"from {flat_prefix}methods.base import WbMethod"
    uses_field = bool(md.params)
    uses_any = any("Any" in p.py_type for p in md.params)

    # Merge return type + RequestLimit into one sorted import line
    types_pkg = f"{flat_prefix}types"
    type_names = sorted({md.return_type, "RequestLimit"})
    if len(type_names) == 1:
        types_import = f"from {types_pkg} import {type_names[0]}"
    else:
        one_line = f"from {types_pkg} import {', '.join(type_names)}"
        if len(one_line) <= 110:
            types_import = one_line
        else:
            types_import = f"from {types_pkg} import (\n    " + ",\n    ".join(type_names) + ",\n)"

    enum_imps = _enum_imports_for_fields(md.params, enum_registry, in_module=in_module) if enum_registry else []

    imports: list[str] = []
    if uses_any:
        imports += ["from typing import Any", ""]
    if uses_field:
        imports += ["from pydantic import Field", ""]
    # relative imports: enums first, then types, then base (no blank lines — force-sort-within-sections)
    imports += enum_imps
    imports += sorted([types_import, base_import])

    lines = imports + ["", ""]
    lines.append(f"class {md.class_name}(WbMethod):")

    doc_lines = []
    if md.description:
        doc_lines += _wrap_docstring_line(md.description, "    ")
    if md.source_url:
        if doc_lines:
            doc_lines.append("")
        doc_lines.append(f"    Source: {md.source_url}")
    if doc_lines:
        lines += ['    """'] + doc_lines + ['    """', ""]

    lines.append(f"    __return__ = {md.return_type}")
    if md.empty_response:
        lines.append("    __empty_response__ = True")
    lines.append(f'    __api__ = "{md.api_host}"')
    if md.path_template:
        lines.append('    __method__ = ""')
        lines.append(f'    __method_template__ = "{md.path_template}"')
    else:
        lines.append(f'    __method__ = "{md.path}"')
    if md.http_method != "GET":
        lines.append(f'    __http_method__ = "{md.http_method}"')
    if md.data_key:
        lines.append(f'    __data_key__ = "{md.data_key}"')
    if md.pagination:
        lines.append(f'    __pagination__ = "{md.pagination}"')
    lines += ["", f"    request_limit: RequestLimit = {md.rate_limit}", ""]

    visible_params = [p for p in md.params]
    if visible_params:
        for p in visible_params:
            lines.append(_field_line(p, enum_registry=enum_registry))
        lines.append("")

    return "\n".join(lines)


def _stem_to_import(stem: str) -> str:
    """Convert stem to import module string.
    Plain stems (e.g. 'base') → '.base'  (relative to current package dir)
    Module-prefixed stems (e.g. 'products.types.foo') → '..products.types.foo'
    (one extra dot because flat __init__.py is one level deeper than package root)
    """
    return f"..{stem}" if "." in stem else f".{stem}"


def generate_types_init(generated: list[tuple[str, str]], manual: list[tuple[str, str]]) -> str:
    seen_cls: set[str] = set()
    deduped: list[tuple[str, str]] = []
    for entry in sorted(set(manual + generated), key=lambda x: x[0].casefold()):
        if entry[0] not in seen_cls:
            deduped.append(entry)
            seen_cls.add(entry[0])
    all_entries = deduped
    lines = [_import_line(_stem_to_import(stem), cls) for cls, stem in all_entries]
    lines += ["", "", "__all__ = ("]
    lines += [f'    "{cls}",' for cls, _ in all_entries]
    lines += [")", ""]
    return "\n".join(lines)


def generate_methods_init(
    generated: list[tuple[str, str]],
    manual: list[tuple[str, str]],
    include_base: bool = True,
) -> str:
    base = [("WbMethod", "base")] if include_base else []
    all_entries = sorted(set(manual + generated + base), key=lambda x: x[0].casefold())
    lines = [_import_line(_stem_to_import(stem), cls) for cls, stem in all_entries]
    lines += ["", "", "__all__ = ("]
    lines += [f'    "{cls}",' for cls, _ in all_entries]
    lines += [")", ""]
    return "\n".join(lines)


def generate_module_init(
    type_entries: list[tuple[str, str]],
    enum_entries: list[tuple[str, str]],
) -> str:
    """Generate {module}/__init__.py re-exporting types and enums from that module."""
    # Build (import_path, cls) and sort by import_path so ruff doesn't reorder
    combined = (
        [(f".enums.{stem}", cls) for cls, stem in enum_entries]
        + [(f".types.{stem}", cls) for cls, stem in type_entries]
    )
    combined.sort(key=lambda x: x[0].casefold())
    lines = [_import_line(mod, cls) for mod, cls in combined]
    all_cls = [cls for _, cls in combined]
    lines += ["", "", "__all__ = ("]
    for cls in sorted(all_cls, key=str.casefold):
        lines.append(f'    "{cls}",')
    lines += [")", ""]
    return "\n".join(lines)


def _extract_unofficial_api_methods(api_path: Path) -> str:
    if not api_path.exists():
        return ""
    lines = api_path.read_text().splitlines(keepends=True)
    blocks: list[str] = []
    i = 0
    while i < len(lines):
        if re.match(r"    @unofficial\s*(\n|$)", lines[i]):
            block: list[str] = [lines[i]]
            i += 1
            inside_def = False
            while i < len(lines):
                l = lines[i]
                if re.match(r"    async def |    def ", l):
                    if inside_def:
                        break
                    inside_def = True
                elif inside_def and re.match(r"    @\w", l):
                    break
                block.append(l)
                i += 1
            blocks.append("".join(block).rstrip())
        else:
            i += 1
    return ("\n\n".join(blocks) + "\n") if blocks else ""


def _extract_names_from_block(block: str) -> tuple[set[str], set[str]]:
    type_names: set[str] = set()
    method_names: set[str] = set()
    for m in re.finditer(r"->\s*(?:list\[)?([A-Z][A-Za-z0-9]+)\]?", block):
        type_names.add(m.group(1))
    for m in re.finditer(r"=\s*([A-Z][A-Za-z0-9]+)\(", block):
        method_names.add(m.group(1))
    return type_names, method_names


def _wrap_docstring_line(text: str, indent: str, max_width: int = 99) -> list[str]:
    """Wrap a long docstring line at max_width, preserving indent on continuation lines."""
    words = text.split()
    lines: list[str] = []
    current = indent
    for word in words:
        candidate = current + word
        if len(candidate) > max_width and current != indent:
            lines.append(current.rstrip())
            current = indent + word
        else:
            current = candidate + " "
    lines.append(current.rstrip())
    return lines


def _api_method_wrapper(md: MethodDef, enum_registry: dict[str, "EnumDef"] | None = None) -> str:
    all_non_path = [p for p in md.params if not p.exclude]
    path_params = [p for p in md.params if p.exclude]
    non_path_params = all_non_path

    # Split into required (no default) and optional params to ensure correct signature order
    required_params = [p for p in non_path_params if p.default is None and "| None" not in p.py_type]
    optional_params = [p for p in non_path_params if p not in required_params]

    sig_parts = ["self"]
    for p in path_params:
        sig_parts.append(f"{p.py_name}: {p.py_type}")
    for p in required_params:
        sig_parts.append(f"{p.py_name}: {p.py_type}")
    for p in optional_params:
        default = "None" if p.default is None else _format_default(p.py_type, p.default, enum_registry)
        sig_parts.append(f"{p.py_name}: {p.py_type} = {default}")

    ret = "None" if md.empty_response else f"list[{md.return_type}]"

    call_args = ", ".join(
        f"{p.py_name}={p.py_name}" for p in path_params + required_params + optional_params
    )

    one_line_sig = ", ".join(sig_parts)
    if len(f"    async def {md.method_name}(self, {one_line_sig},") <= 99:
        sig_block = [f"        {one_line_sig},"]
    else:
        sig_block = [f"        {part}," for part in sig_parts]

    lines = [f"    async def {md.method_name}("] + sig_block + [f"    ) -> {ret}:"]
    param_docs = [p for p in path_params + required_params + optional_params if p.description]
    ret = "None" if md.empty_response else f"list[{md.return_type}]"
    lines.append('        """')
    desc = md.description or md.method_name.replace("_", " ").title()
    lines += _wrap_docstring_line(desc, "        ")
    if md.source_url:
        lines += ["", f"        Source: {md.source_url}"]
    if param_docs:
        lines.append("")
        for p in param_docs:
            prefix = f"        :param {p.py_name}: "
            continuation = " " * len(prefix)
            words = p.description.split()
            current = prefix
            for word in words:
                candidate = current + word
                if len(candidate) > 99 and current != prefix:
                    lines.append(current.rstrip())
                    current = continuation + word
                else:
                    current = candidate + " "
            lines.append(current.rstrip())
    lines.append(f"        :return: {ret}")
    lines.append('        """')
    call_line = f"        call = {md.class_name}({call_args})"
    if len(call_line) <= 99:
        lines.append(call_line)
    else:
        inner = ",\n            ".join(f"{p.py_name}={p.py_name}" for p in path_params + non_path_params)
        lines.append(f"        call = {md.class_name}(\n            {inner},\n        )")
    lines.append("        return await self(call)")
    lines.append(f"    {md.method_name}.__wrapped_cls__ = {md.class_name}")
    return "\n".join(lines)


def generate_api_file(
    method_defs: list[MethodDef],
    unofficial_block: str,
    enum_registry: dict[str, "EnumDef"] | None = None,
) -> str:
    type_imports: set[str] = set()
    method_imports: set[str] = set()
    enum_imports: dict[str, str] = {}  # class_name -> file_stem

    known_enum_classes = {ed.class_name: ed.file_stem for ed in (enum_registry or {}).values()}

    for md in method_defs:
        if not md.empty_response:
            type_imports.add(md.return_type)
        method_imports.add(md.class_name)
        for p in md.params:
            base = p.py_type.replace(" | None", "").strip()
            if base in known_enum_classes:
                enum_imports[base] = known_enum_classes[base]

    extra_types, extra_methods = _extract_names_from_block(unofficial_block)
    type_imports |= extra_types
    method_imports |= extra_methods

    lines = [
        "from typing import Any",
        "",
        "from ..client.session.base import BaseSession",
        *(
            [
                "from ..enums import (",
                *[f"    {cls}," for cls in sorted(enum_imports, key=str.casefold)],
                ")",
            ]
            if enum_imports
            else []
        ),
        "from ..methods import (",
        *[f"    {cls}," for cls in sorted(method_imports | {"WbMethod"}, key=str.casefold)],
        ")",
        "from ..types import (",
        *[f"    {cls}," for cls in sorted(type_imports, key=str.casefold)],
        ")",
        "from ..utils.token import validate_token",
        "from ..utils.unofficial import unofficial",
        "",
        "",
        "class WbAPI:",
        "    def __init__(self, token: str, session: BaseSession | None = None, **kwargs: Any) -> None:",
        '        """',
        "        WbAPI class.",
        "",
        "        Attributes:",
        "",
        "            token: Access token",
        "",
        "            Source: https://dev.wildberries.ru/en/docs/openapi/api-information#tag/Authorization/How-to-create-a-personal-access-base-or-test-token",
        '        """',
        "        validate_token(token)",
        "        if session is None:",
        '            read_timeout = kwargs.get("read_timeout", 60)',
        '            base = kwargs.get("base", "wildberries.ru")',
        "            session = BaseSession(",
        "                base=base,",
        "                timeout=read_timeout,",
        "            )",
        "",
        "        self._token = token",
        "        self.session = session",
        "",
        '    async def __aenter__(self) -> "WbAPI":',
        "        return self",
        "",
        "    async def __aexit__(self, exc_type: Any, _exc: Any, _tb: Any) -> None:",
        "        await self.session.close()",
        "",
        "    async def __call__(self, method: WbMethod) -> Any:",
        "        return await method.emit(self)",
        "",
    ]

    for md in method_defs:
        lines.append(_api_method_wrapper(md, enum_registry))
        lines.append("")

    if unofficial_block.strip():
        lines += ["    # --- unofficial methods (hand-written, not generated) ---", ""]
        lines += unofficial_block.splitlines()
        lines.append("")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Test generator
# ---------------------------------------------------------------------------

def _mock_value(
    py_type: str,
    field_name: str,
    enum_registry: dict[str, "EnumDef"] | None = None,
) -> str:
    """Return a plausible mock value for a given Python type string."""
    t = py_type.replace(" | None", "").strip()
    if t == "int":
        return "1"
    if t == "float":
        return "1.0"
    if t == "bool":
        return "True"
    if t == "str":
        return f'"{field_name}"'
    if t.startswith("list["):
        return "[]"
    if t.startswith("dict["):
        return "{}"
    # Check if it's a known enum type (look up by class_name since stem may differ e.g. sort_2)
    if enum_registry:
        ed = next((e for e in enum_registry.values() if e.class_name == t), None)
        if ed and ed.values:
            return f'"{ed.values[0]}"'
    return "None"


def _build_mock_response(
    fields: list[FieldDef],
    data_key: str | None,
    enum_registry: dict[str, "EnumDef"] | None = None,
) -> str:
    """Build the dict literal for api.add_response(...)."""
    # item dict — 3 levels deep inside add_response(...)
    pad_field = "                "  # 16 spaces
    pad_item = "            "       # 12 spaces
    field_lines = []
    for f in fields:
        val = _mock_value(f.py_type, f.alias, enum_registry)
        field_lines.append(f'{pad_field}"{f.alias}": {val},')

    item_dict = "{\n" + "\n".join(field_lines) + f"\n{pad_item}}}"

    if not data_key:
        return f"[{item_dict}]"

    # wrap: "data.listGoods" → {"data": {"listGoods": [item]}}
    keys = data_key.split(".")
    result = f"[{item_dict}]"
    for key in reversed(keys):
        result = '{\n' + pad_item + f'"{key}": ' + result + f"\n        }}"
    return result


def generate_test_file(md: MethodDef, enum_registry: dict[str, "EnumDef"] | None = None) -> str:
    """Render tests/test_methods/test_<name>.py for a MethodDef."""
    class_name = f"Test{md.class_name}"
    test_fn = f"test_{md.method_name}"

    # required call args (path params + required non-path params without defaults)
    required_params = [p for p in md.params if p.exclude]  # path params always required
    for p in md.params:
        if not p.exclude and "| None" not in p.py_type and p.default is None:
            required_params.append(p)

    call_args = ", ".join(
        f"{p.py_name}={_mock_value(p.py_type, p.py_name, enum_registry)}" for p in required_params
    )

    if md.empty_response:
        mock_response = "None"
        assert_lines = ["        assert result is None"]
    else:
        mock_response = _build_mock_response(
            md.type_def.fields if md.type_def else [], md.data_key, enum_registry
        )
        assert_lines = [
            f"        assert isinstance(result, list)",
            f"        assert len(result) == 1",
            f"        assert isinstance(result[0], {md.return_type})",
        ]
        if md.type_def and md.type_def.fields:
            for f in md.type_def.fields[:3]:
                val = _mock_value(f.py_type, f.alias, enum_registry)
                if val != "None":
                    assert_lines.append(f"        assert result[0].{f.py_name} == {val}")

    lines = [
        "import pytest",
        "",
        *([f"from wbapi_async.types import {md.return_type}"] if not md.empty_response else []),
        "from tests.mocked_api import MockedAPI",
        "",
        "",
        f"@pytest.mark.unit",
        f"class {class_name}:",
        f"    async def {test_fn}(self, api: MockedAPI) -> None:",
        *(
            [f"        api.add_response({mock_response})"]
            if "\n" not in mock_response
            else [f"        api.add_response(", f"            {mock_response}", f"        )"]
        ),
        "",
        f"        result = await api.{md.method_name}({call_args})",
        "",
        *assert_lines,
        "",
    ]
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# File discovery
# ---------------------------------------------------------------------------

def _scan_unofficial_methods(methods_dir: Path) -> set[str]:
    result: list[str] = []
    for py in methods_dir.glob("*.py"):
        if py.name.startswith("_"):
            continue
        text = py.read_text()
        if "__unofficial__" in text and "True" in text:
            result.append(py.stem)
    return set(result)


def _scan_existing(directory: Path, skip_files: set[str]) -> list[tuple[str, str]]:
    results = []
    for py in sorted(directory.glob("*.py")):
        stem = py.stem
        if stem.startswith("_") or stem in {"base", "request_limit", "pagination"}:
            continue
        if stem in skip_files:
            continue
        text = py.read_text()
        for m in re.finditer(r"^class (\w+)\(", text, re.MULTILINE):
            results.append((m.group(1), stem))
    return results


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------


def _write_if_changed(path: Path, content: str) -> bool:
    """Write content to path only if it differs from existing content. Returns True if written."""
    if path.exists() and path.read_text() == content:
        return False
    path.write_text(content)
    return True


def run(yaml_files: list[Path], target: Path) -> None:
    src = target / "src" / "wbapi_async"
    methods_dir = src / "methods"
    types_dir = src / "types"
    enums_dir = src / "enums"
    api_path = src / "client" / "api.py"

    unofficial_stems = _scan_unofficial_methods(methods_dir)
    print(f"Unofficial methods (protected): {unofficial_stems or 'none'}")

    unofficial_block = _extract_unofficial_api_methods(api_path)

    # Pass 1: build global enum registry across all specs
    all_enums: dict[str, EnumDef] = {}
    valid_yaml_files: list[Path] = []
    for yaml_path in yaml_files:
        try:
            _, yaml_enums = parse_yaml(yaml_path)
        except Exception as e:
            print(f"\nERROR parsing {yaml_path.name}: {e}")
            continue
        valid_yaml_files.append(yaml_path)
        for stem, ed in yaml_enums.items():
            if stem not in all_enums:
                all_enums[stem] = ed

    # Pass 2: re-parse using shared global enum registry so all MethodDefs use consistent names
    # all_enums is passed by reference — it may gain new disambiguated entries across calls
    all_method_defs_by_yaml: list[list[MethodDef]] = []
    for yaml_path in valid_yaml_files:
        print(f"\nParsing {yaml_path.name} …")
        try:
            methods, _ = parse_yaml(yaml_path, enum_registry=all_enums)
        except Exception as e:
            print(f"  ERROR: {e}")
            continue
        print(f"  Found {len(methods)} endpoints")
        all_method_defs_by_yaml.append(methods)

    # Pass 3: write files into per-module subdirs (all_enums complete, MethodDefs use global names)
    # new_type_entries / new_method_entries / new_enum_entries use module-prefixed stems
    # e.g. ("BlockedProductCardsItem", "products.types.blocked_product_cards_item")
    # so that flat __init__.py can do: from .products.types.blocked_product_cards_item import ...
    new_type_entries: list[tuple[str, str]] = []
    new_method_entries: list[tuple[str, str]] = []
    new_enum_entries: list[tuple[str, str]] = []
    all_method_defs: list[MethodDef] = []
    generated_stems_types: set[str] = set()   # plain file stems for dedup
    generated_stems_methods: set[str] = set()
    generated_stems_enums: set[str] = set()
    generated_class_names_types: set[str] = set()
    method_owns_type: dict[str, bool] = {}  # method_stem -> True if it wrote its type
    # per-module type/enum entries for module __init__.py
    module_type_entries: dict[str, list[tuple[str, str]]] = {}  # module -> [(cls, plain_stem)]
    module_enum_entries: dict[str, list[tuple[str, str]]] = {}  # module -> [(cls, plain_stem)]

    # Write enum files per-module (enums come from all_enums built in Pass 1)
    # We need yaml→module mapping to assign each enum to the first YAML that introduced it.
    # Build enum→module map from Pass 1 order.
    enum_module_map: dict[str, str] = {}
    for yaml_path in valid_yaml_files:
        module = yaml_stem_to_module(yaml_path.stem)
        try:
            _, yaml_enums = parse_yaml(yaml_path)
        except Exception:
            continue
        for stem in yaml_enums:
            if stem not in enum_module_map:
                enum_module_map[stem] = module

    for stem, ed in sorted(all_enums.items()):
        module = enum_module_map.get(stem, "general")
        mod_enums_dir = src / module / "enums"
        mod_enums_dir.mkdir(parents=True, exist_ok=True)
        enum_path = mod_enums_dir / f"{stem}.py"
        if _write_if_changed(enum_path, generate_enum_file(ed)):
            print(f"  [enum]   {enum_path.relative_to(target)}")
        generated_stems_enums.add(stem)
        prefixed_stem = f"{module}.enums.{stem}"
        new_enum_entries.append((ed.class_name, prefixed_stem))
        module_enum_entries.setdefault(module, []).append((ed.class_name, stem))

    for methods, yaml_path in zip(all_method_defs_by_yaml, valid_yaml_files):
        module = yaml_stem_to_module(yaml_path.stem)
        mod_types_dir = src / module / "types"
        mod_methods_dir = src / module / "methods"
        mod_types_dir.mkdir(parents=True, exist_ok=True)
        mod_methods_dir.mkdir(parents=True, exist_ok=True)

        for md in methods:
            type_stem = md.return_type_file
            type_path = mod_types_dir / f"{type_stem}.py"
            type_owner = type_stem not in generated_stems_types
            if type_owner:
                if _write_if_changed(type_path, generate_type_file(md.type_def, all_enums, in_module=True)):
                    print(f"  [type]   {type_path.relative_to(target)}")
                if md.return_type not in generated_class_names_types:
                    prefixed_stem = f"{module}.types.{type_stem}"
                    new_type_entries.append((md.return_type, prefixed_stem))
                    generated_class_names_types.add(md.return_type)
                    module_type_entries.setdefault(module, []).append((md.return_type, type_stem))
                generated_stems_types.add(type_stem)
            else:
                pass  # conflict: type already generated from another spec

            method_stem = camel_to_snake(md.class_name)
            if method_stem in unofficial_stems:
                continue
            if method_stem in generated_stems_methods:
                continue
            if _write_if_changed(mod_methods_dir / f"{method_stem}.py", generate_method_file(md, all_enums, in_module=True)):
                url_suffix = f" {md.source_url}" if md.source_url else ""
                print(f"  [method] {(mod_methods_dir / method_stem).relative_to(target)}.py{url_suffix}")
            prefixed_stem = f"{module}.methods.{method_stem}"
            new_method_entries.append((md.class_name, prefixed_stem))
            all_method_defs.append(md)
            generated_stems_methods.add(method_stem)
            method_owns_type[method_stem] = type_owner

    # Remove stale files from old flat dirs and module subdirs
    _TYPES_KEEP = {"__init__", "base", "error", "request_limit", "product_detail"}
    for f in sorted(types_dir.glob("*.py")):
        if f.stem not in _TYPES_KEEP:
            f.unlink()
            print(f"[removed] {f.relative_to(target)}")
    # also clean stale files in module type/method/enum subdirs
    for mod_dir in sorted(src.iterdir()):
        if not mod_dir.is_dir() or mod_dir.name in {"client", "utils", "__pycache__"}:
            continue
        for subdir_name, gen_stems in [
            ("types", generated_stems_types),
            ("methods", generated_stems_methods),
            ("enums", generated_stems_enums),
        ]:
            subdir = mod_dir / subdir_name
            if not subdir.exists():
                continue
            for f in sorted(subdir.glob("*.py")):
                if f.stem == "__init__":
                    continue
                if f.stem not in gen_stems and f.stem not in unofficial_stems:
                    f.unlink()
                    print(f"[removed] {f.relative_to(target)}")

    _METHODS_KEEP = {"__init__", "base", "pagination"}
    for f in sorted(methods_dir.glob("*.py")):
        if f.stem not in _METHODS_KEEP and f.stem not in unofficial_stems:
            f.unlink()
            print(f"[removed] {f.relative_to(target)}")

    _ENUMS_KEEP = {"__init__"}
    for f in sorted(enums_dir.glob("*.py")):
        if f.stem not in _ENUMS_KEEP:
            f.unlink()
            print(f"[removed] {f.relative_to(target)}")

    # Write per-module __init__.py files
    for module in set(list(module_type_entries.keys()) + list(module_enum_entries.keys())):
        mod_init = src / module / "__init__.py"
        if _write_if_changed(mod_init, generate_module_init(
            module_type_entries.get(module, []),
            module_enum_entries.get(module, []),
        )):
            print(f"[init] {mod_init.relative_to(target)}")
    # Write per-module types/__init__.py and enums/__init__.py
    for module, t_entries in module_type_entries.items():
        init_path = src / module / "types" / "__init__.py"
        _write_if_changed(init_path, generate_types_init(t_entries, []))
    for module, e_entries in module_enum_entries.items():
        init_path = src / module / "enums" / "__init__.py"
        _write_if_changed(init_path, generate_enums_init(e_entries))
    # Write per-module methods/__init__.py
    for module in set(yaml_stem_to_module(p.stem) for p in valid_yaml_files):
        mod_methods_dir = src / module / "methods"
        if mod_methods_dir.exists():
            mod_method_entries = [
                (cls, stem.split(".")[-1])
                for cls, stem in new_method_entries
                if stem.startswith(f"{module}.methods.")
            ]
            init_path = mod_methods_dir / "__init__.py"
            _write_if_changed(init_path, generate_methods_init(mod_method_entries, [], include_base=False))

    # Unofficial entries still live in flat methods/
    unofficial_entries = _scan_existing(methods_dir, generated_stems_methods)

    # Write flat __init__.py files — re-export everything from all modules
    always_types = [
        ("BaseType", "base"),
        ("RequestLimit", "request_limit"),
        ("Error", "error"),
        ("ProductDetail", "product_detail"),
        ("ProductDetailColor", "product_detail"),
        ("ProductDetailPrice", "product_detail"),
        ("ProductDetailSize", "product_detail"),
        ("ProductDetailStock", "product_detail"),
    ]
    if _write_if_changed(types_dir / "__init__.py", generate_types_init(new_type_entries, always_types)):
        print(f"\n[init] {(types_dir / '__init__.py').relative_to(target)}")

    if _write_if_changed(methods_dir / "__init__.py", generate_methods_init(
        new_method_entries,
        [e for e in unofficial_entries if e not in new_method_entries],
    )):
        print(f"[init] {(methods_dir / '__init__.py').relative_to(target)}")

    if new_enum_entries:
        enums_dir.mkdir(parents=True, exist_ok=True)
        if _write_if_changed(enums_dir / "__init__.py", generate_enums_init(new_enum_entries)):
            print(f"[init] {(enums_dir / '__init__.py').relative_to(target)}")

    all_method_defs.sort(key=lambda m: m.method_name)
    if _write_if_changed(api_path, generate_api_file(all_method_defs, unofficial_block, all_enums)):
        print(f"[api]  {api_path.relative_to(target)}")

    # --- generate tests ---
    tests_dir = target / "tests" / "test_methods"
    tests_dir.mkdir(parents=True, exist_ok=True)
    init = tests_dir / "__init__.py"
    if not init.exists():
        init.write_text("")

    # collect stems of unofficial tests (skip overwriting)
    unofficial_test_stems = {f"test_{s}" for s in unofficial_stems}
    generated_test_stems: set[str] = set()

    for md in all_method_defs:
        method_stem = camel_to_snake(md.class_name)
        test_stem = f"test_{method_stem}"
        test_path = tests_dir / f"{test_stem}.py"
        if test_stem in unofficial_test_stems:
            generated_test_stems.add(test_stem)
            continue
        # Skip test if the method's type was generated by a different method (type conflict)
        if not method_owns_type.get(method_stem, True):
            continue
        if _write_if_changed(test_path, generate_test_file(md, all_enums)):
            print(f"[test] {test_path.relative_to(target)}")
        generated_test_stems.add(test_stem)

    # Remove stale test files no longer produced by codegen
    for f in sorted(tests_dir.glob("test_*.py")):
        if f.stem not in generated_test_stems and f.stem not in unofficial_test_stems:
            f.unlink()
            print(f"[removed] {f.relative_to(target)}")

    # Run ruff to normalize formatting — prevents drift on next codegen run
    src_dir = target / "src"
    tests_dir_root = target / "tests"
    subprocess.run(
        ["ruff", "check", "--fix", "--unsafe-fixes", str(src_dir), str(tests_dir_root)],
        capture_output=True,
    )
    subprocess.run(
        ["ruff", "format", str(src_dir), str(tests_dir_root)],
        capture_output=True,
    )

    print("\nDone.")
