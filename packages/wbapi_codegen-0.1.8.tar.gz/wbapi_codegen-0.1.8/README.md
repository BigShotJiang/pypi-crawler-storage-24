# wbapi-codegen

Code generator for [wbapi-async](https://github.com/serdukow/wbapi-async).
