# Copyright 2025 © BeeAI a Series of LF Projects, LLC
# SPDX-License-Identifier: Apache-2.0


class ToolCallRejectionError(RuntimeError):
    pass
