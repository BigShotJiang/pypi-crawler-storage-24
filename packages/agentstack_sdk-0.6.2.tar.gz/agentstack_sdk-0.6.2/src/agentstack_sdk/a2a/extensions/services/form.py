# Copyright 2025 © BeeAI a Series of LF Projects, LLC
# SPDX-License-Identifier: Apache-2.0


from __future__ import annotations

from typing import Any, Self, TypeVar

from pydantic import BaseModel, TypeAdapter
from typing_extensions import TypedDict

from agentstack_sdk.a2a.extensions.base import BaseExtensionClient, BaseExtensionServer, BaseExtensionSpec
from agentstack_sdk.a2a.extensions.common.form import FormRender, FormResponse


class FormDemands(TypedDict):
    initial_form: FormRender | None
    # TODO: We can put settings here too


class FormServiceExtensionMetadata(BaseModel):
    form_fulfillments: dict[str, FormResponse] = {}


class FormServiceExtensionParams(BaseModel):
    form_demands: FormDemands


class FormServiceExtensionSpec(BaseExtensionSpec[FormServiceExtensionParams]):
    URI: str = "https://a2a-extensions.agentstack.beeai.dev/services/form/v1"

    @classmethod
    def demand(cls, initial_form: FormRender | None) -> Self:
        return cls(params=FormServiceExtensionParams(form_demands={"initial_form": initial_form}))


T = TypeVar("T")


class FormServiceExtensionServer(BaseExtensionServer[FormServiceExtensionSpec, FormServiceExtensionMetadata]):
    def parse_initial_form(self, *, model: type[T] | None = None) -> T | None:
        initial_form = getattr(self.data, "form_fulfillments", {}).get("initial_form")
        return (
            TypeAdapter(model).validate_python(dict(initial_form))
            if initial_form is not None and model is not None
            else initial_form
        )


class FormServiceExtensionClient(BaseExtensionClient[FormServiceExtensionSpec, FormRender]):
    def fulfillment_metadata(self, *, form_fulfillments: dict[str, FormResponse]) -> dict[str, Any]:
        return {
            self.spec.URI: FormServiceExtensionMetadata(form_fulfillments=form_fulfillments).model_dump(mode="json")
        }
