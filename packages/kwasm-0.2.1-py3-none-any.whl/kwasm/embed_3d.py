"""Embed threegds 3D GDS viewer in Jupyter notebooks."""

from __future__ import annotations

import base64
import gzip
import html
import tempfile
import warnings
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

from kwasm.version import versioned_bundled_html_name

if TYPE_CHECKING:
    from IPython.display import HTML

CWD = Path(__file__).parent


def bundle_3d(
    gds: str | Path,
    layerstack: str | Path,
    output: str | Path | None = None,
    lyp: str | Path | None = None,
) -> Path:
    """Bundle a GDS layout + layerstack into a single self-contained 3D HTML file."""
    gds_path = Path(gds)
    if output is None:
        output = f"{gds_path.stem}-3d.html"
    gds_bytes = gds_path.read_bytes()
    layerstack_bytes = Path(layerstack).read_bytes()
    lyp_bytes = Path(lyp).read_bytes() if lyp is not None else None
    html_str = _build_html(gds_bytes, layerstack_bytes, lyp_bytes=lyp_bytes)
    html_str = html_str.replace(
        "<title>threegds</title>",
        f"<title>threegds - {gds_path.stem}</title>",
    )
    out = Path(output)
    out.write_text(html_str)
    return out


def show_3d(
    component_or_path: str | Path | object,
    layerstack: str | Path,
    height: int = 500,
    *,
    lyp: str | Path | None = None,
) -> HTML:
    """Display a 3D GDS viewer in a Jupyter notebook.

    Args:
        component_or_path: A file path (str or Path) to a .gds file,
            or a gdsfactory Component (anything with a .write_gds() method).
        layerstack: Path (str or Path) to a layerstack JSON file.
        height: Height of the viewer in pixels.
        lyp: Optional path (str or Path) to a .lyp layer properties file.

    Returns:
        IPython.display.HTML object for notebook rendering.

    """
    from IPython.display import HTML

    path = (
        Path(component_or_path) if isinstance(component_or_path, (str, Path)) else None
    )

    if path is not None:
        gds_bytes = path.read_bytes()
    else:
        with tempfile.NamedTemporaryFile(suffix=".gds", delete=False) as f:
            tmp = Path(f.name)
        try:
            cast(Any, component_or_path).write_gds(tmp)
            gds_bytes = tmp.read_bytes()
        finally:
            tmp.unlink(missing_ok=True)

    layerstack_bytes = Path(layerstack).read_bytes()
    lyp_bytes = Path(lyp).read_bytes() if lyp is not None else None
    full_html = _build_html(gds_bytes, layerstack_bytes, lyp_bytes=lyp_bytes)
    escaped = html.escape(full_html, quote=True)

    iframe = (
        f'<iframe srcdoc="{escaped}" '
        f'width="100%" height="{height}" '
        f'style="border:none"></iframe>'
    )

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", UserWarning)
        return HTML(iframe)


def _read_artifacts() -> str:
    """Read the pre-built bundled HTML from dist/."""
    bundled = CWD / versioned_bundled_html_name("threegds")
    if not bundled.exists():
        msg = f"{bundled} not found. Run 'python build.py 3d' first."
        raise FileNotFoundError(msg)
    return bundled.read_text()


def _build_html(
    gds_bytes: bytes,
    layerstack_bytes: bytes,
    *,
    lyp_bytes: bytes | None = None,
) -> str:
    """Build a self-contained HTML string with embedded GDS + layerstack."""
    result = _read_artifacts()

    # Fill data slots
    gds_b64 = base64.b64encode(gzip.compress(gds_bytes)).decode("ascii")
    result = result.replace("KWASM_GDS_B64", gds_b64)

    layerstack_b64 = base64.b64encode(layerstack_bytes).decode("ascii")
    result = result.replace("KWASM_LAYERSTACK_B64", layerstack_b64)

    if lyp_bytes is not None:
        lyp_b64 = base64.b64encode(lyp_bytes).decode("ascii")
        result = result.replace("KWASM_LYP_B64", lyp_b64)

    return result
