"""Embed unified 2D+3D GDS viewer in Jupyter notebooks."""

from __future__ import annotations

import base64
import gzip
import html
import tempfile
import warnings
from collections.abc import Iterable
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

from kwasm.version import versioned_bundled_html_name

if TYPE_CHECKING:
    from IPython.display import HTML

CWD = Path(__file__).parent


def bundle_unified(
    gds: str | Path,
    output: str | Path | None = None,
    layerstack: str | Path | None = None,
    lyp: str | Path | None = None,
    lyrdb: str | Path | None = None,
    netlist: str | Path | dict | None = None,
) -> Path:
    """Bundle a GDS layout into a unified 2D+3D HTML viewer."""
    gds_path = Path(gds)
    if output is None:
        output = f"{gds_path.stem}-unified.html"
    gds_bytes = gds_path.read_bytes()
    layerstack_bytes = Path(layerstack).read_bytes() if layerstack is not None else None
    lyp_bytes = Path(lyp).read_bytes() if lyp is not None else None
    lyrdb_bytes = Path(lyrdb).read_bytes() if lyrdb is not None else None
    netlist_bytes = _netlist_to_bytes(netlist)
    html_str = _build_html(
        gds_bytes,
        tools=(
            "select",
            "move",
            "ruler",
            "clear-all",
            "fit-all",
            "reload",
            "top-ports",
            "instance-ports",
            "dangling-ports",
            "text",
            "zoom-fit",
            "reset-view",
            "scale-z",
            "edges",
            "theme",
            "toggle-3d",
        ),
        drop=True,
        layers=True,
        layerstack_bytes=layerstack_bytes,
        lyp_bytes=lyp_bytes,
        lyrdb_bytes=lyrdb_bytes,
        netlist_bytes=netlist_bytes,
    )
    html_str = html_str.replace(
        "<title>kwasm - Layout Viewer</title>",
        f"<title>kwasm - {gds_path.stem}</title>",
    )
    out = Path(output)
    out.write_text(html_str)
    return out


def show_unified(
    component_or_path: str | Path | object,
    layerstack: str | Path | None = None,
    height: int = 500,
    tools: Iterable[str] = (),
    *,
    drop: bool = False,
    layers: bool = True,
    lyp: str | Path | None = None,
    lyrdb: str | Path | None = None,
    netlist: str | Path | dict | None = None,
) -> HTML:
    """Display a unified 2D+3D GDS viewer in a Jupyter notebook.

    Args:
        component_or_path: A file path (str or Path) to a .gds file,
            or a gdsfactory Component (anything with a .write_gds() method).
        layerstack: Optional path to a layerstack JSON file for 3D extrusion.
            If provided, the 3D toggle is immediately available.
        height: Height of the viewer in pixels.
        tools: Toolbar tool names to show (empty hides the toolbar).
            Includes all 2D tools plus: zoom-fit, reset-view, scale-z,
            edges, toggle-3d.
        drop: Whether to enable drag & drop. Defaults to False.
        layers: Whether to show the layer panel. Defaults to True.
        lyp: Optional path to a .lyp layer properties file.
        lyrdb: Optional path to a .lyrdb report database file.
        netlist: Optional path to a .pic.yml netlist file, or a dict.

    Returns:
        IPython.display.HTML object for notebook rendering.

    """
    from IPython.display import HTML

    path = (
        Path(component_or_path) if isinstance(component_or_path, (str, Path)) else None
    )

    if path is not None:
        gds_bytes = path.read_bytes()
    else:
        with tempfile.NamedTemporaryFile(suffix=".gds", delete=False) as f:
            tmp = Path(f.name)
        try:
            cast(Any, component_or_path).write_gds(tmp)
            gds_bytes = tmp.read_bytes()
        finally:
            tmp.unlink(missing_ok=True)

    if lyp is not None:
        lyp_bytes = Path(lyp).read_bytes()
    else:
        lyp_text = _get_active_lyp()
        lyp_bytes = lyp_text.encode() if lyp_text is not None else None
    lyrdb_bytes = Path(lyrdb).read_bytes() if lyrdb is not None else None
    netlist_bytes = _netlist_to_bytes(netlist)
    layerstack_bytes = Path(layerstack).read_bytes() if layerstack is not None else None

    full_html = _build_html(
        gds_bytes,
        tools=tuple(tools),
        drop=drop,
        layers=layers,
        layerstack_bytes=layerstack_bytes,
        lyp_bytes=lyp_bytes,
        lyrdb_bytes=lyrdb_bytes,
        netlist_bytes=netlist_bytes,
    )
    escaped = html.escape(full_html, quote=True)

    iframe = (
        f'<iframe srcdoc="{escaped}" '
        f'width="100%" height="{height}" '
        f'style="border:none"></iframe>'
    )

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", UserWarning)
        return HTML(iframe)


def _netlist_to_bytes(
    netlist: str | Path | dict | None,
) -> bytes | None:
    """Convert a netlist argument to bytes."""
    if isinstance(netlist, dict):
        import json

        return json.dumps(netlist).encode()
    if netlist is not None:
        return Path(netlist).read_bytes()
    return None


def _read_artifacts() -> str:
    """Read the pre-built unified bundled HTML from dist/."""
    bundled = CWD / versioned_bundled_html_name("kwasm-unified")
    if not bundled.exists():
        msg = f"{bundled} not found. Run 'python build.py unified' first."
        raise FileNotFoundError(msg)
    return bundled.read_text()


def _build_html(
    gds_bytes: bytes,
    tools: tuple[str, ...] = (),
    *,
    drop: bool = False,
    layers: bool = True,
    layerstack_bytes: bytes | None = None,
    lyp_bytes: bytes | None = None,
    lyrdb_bytes: bytes | None = None,
    netlist_bytes: bytes | None = None,
) -> str:
    """Build a self-contained unified HTML string with embedded GDS."""
    result = _read_artifacts()

    # Fill data slots
    gds_b64 = base64.b64encode(gzip.compress(gds_bytes)).decode("ascii")
    result = result.replace("KWASM_GDS_B64", gds_b64)

    if lyp_bytes is not None:
        lyp_b64 = base64.b64encode(lyp_bytes).decode("ascii")
        result = result.replace("KWASM_LYP_B64", lyp_b64)

    if lyrdb_bytes is not None:
        lyrdb_b64 = base64.b64encode(lyrdb_bytes).decode("ascii")
        result = result.replace("KWASM_LYRDB_B64", lyrdb_b64)

    if netlist_bytes is not None:
        netlist_b64 = base64.b64encode(netlist_bytes).decode("ascii")
        result = result.replace("KWASM_NETLIST_B64", netlist_b64)

    if layerstack_bytes is not None:
        layerstack_b64 = base64.b64encode(layerstack_bytes).decode("ascii")
        result = result.replace("KWASM_LAYERSTACK_B64", layerstack_b64)

    # Fill config meta tags
    if tools:
        tools_csv = ",".join(tools)
        result = result.replace(
            'name="kwasm-tools" content=""',
            f'name="kwasm-tools" content="{tools_csv}"',
        )
    if not drop:
        result = result.replace(
            'name="kwasm-drop" content=""',
            'name="kwasm-drop" content="false"',
        )
    if not layers:
        result = result.replace(
            'name="kwasm-layers" content=""',
            'name="kwasm-layers" content="false"',
        )

    return result


def _get_active_lyp() -> str | None:
    import gdsfactory as gf

    try:
        pdk = gf.get_active_pdk()
    except Exception:  # noqa: BLE001
        return None

    layer_views = pdk.layer_views
    if layer_views is None:
        return None

    if isinstance(layer_views, str | Path):
        try:
            return Path(layer_views).read_text()
        except Exception:  # noqa: BLE001
            return None

    with tempfile.NamedTemporaryFile(suffix=".lyp", delete=False) as f:
        layer_props = Path(f.name).resolve()
        try:
            layer_views.to_lyp(filepath=layer_props)
            return layer_props.read_text()
        except Exception:  # noqa: BLE001
            return None
        finally:
            layer_props.unlink(missing_ok=True)
