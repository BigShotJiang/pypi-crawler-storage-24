"""Helpers for versioned HTML artifact names."""

from __future__ import annotations

__version__ = "0.2.1"


def versioned_html_name(stem: str) -> str:
    """Return the versioned HTML filename for a viewer stem."""
    return f"{stem}-{__version__}.html"


def versioned_bundled_html_name(stem: str) -> str:
    """Return the versioned bundled HTML filename for a viewer stem."""
    return f"{stem}-{__version__}-bundled.html"


def versioned_css_name(stem: str) -> str:
    """Return the versioned CSS filename for a viewer stem."""
    return f"{stem}-{__version__}.css"


def versioned_js_name(stem: str) -> str:
    """Return the versioned JS glue filename for a viewer stem."""
    return f"{stem}-{__version__}.js"


def versioned_standalone_js_name(stem: str) -> str:
    """Return the versioned standalone JS filename for a viewer stem."""
    return f"{stem}-{__version__}-standalone.js"


def versioned_wasm_gz_name(stem: str) -> str:
    """Return the versioned gzipped WASM filename for a viewer stem."""
    return f"{stem}-{__version__}.wasm.gz"


def versioned_debug_html_name() -> str:
    """Return the versioned debug HTML filename."""
    return f"debug-{__version__}.html"
