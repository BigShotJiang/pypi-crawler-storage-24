"""kwasm CLI — bundle and view GDS layouts."""

import importlib
import json
import sys
import tempfile
import webbrowser
from enum import Enum
from pathlib import Path
from typing import cast

import typer

from kwasm.embed import bundle as _bundle
from kwasm.embed_3d import bundle_3d as _bundle_3d
from kwasm.embed_unified import bundle_unified as _bundle_unified

app = typer.Typer()


@app.command()
def bundle(
    gds: str,
    output: str | None = None,
    lyp: str | None = None,
    lyrdb: str | None = None,
    netlist: str | None = None,
) -> None:
    """Bundle a GDS layout into a self-contained HTML file."""
    _bundle(gds, output=output, lyp=lyp, lyrdb=lyrdb, netlist=netlist)


@app.command()
def view(
    gds: str,
    lyp: str | None = None,
    lyrdb: str | None = None,
    netlist: str | None = None,
) -> None:
    """Bundle a GDS layout and open it in the default browser."""
    with tempfile.NamedTemporaryFile(
        suffix=".html", prefix="kwasm_", delete=False
    ) as tmp:
        tmp_path = Path(tmp.name).resolve()
        _bundle(gds, output=tmp_path, lyp=lyp, lyrdb=lyrdb, netlist=netlist)
        webbrowser.open(tmp_path.as_uri())


@app.command("bundle-3d")
def bundle_3d(
    gds: str,
    layerstack: str = typer.Option(..., help="Path to layerstack JSON file."),
    output: str | None = None,
    lyp: str | None = None,
) -> None:
    """Bundle a GDS layout + layerstack into a self-contained 3D HTML file."""
    _bundle_3d(gds, layerstack=layerstack, output=output, lyp=lyp)


@app.command("view-3d")
def view_3d(
    gds: str,
    layerstack: str = typer.Option(..., help="Path to layerstack JSON file."),
    lyp: str | None = None,
) -> None:
    """Bundle a GDS layout + layerstack and open the 3D viewer in the browser."""
    with tempfile.NamedTemporaryFile(
        suffix=".html", prefix="threegds_", delete=False
    ) as tmp:
        tmp_path = Path(tmp.name).resolve()
        _bundle_3d(gds, layerstack=layerstack, output=tmp_path, lyp=lyp)
        webbrowser.open(tmp_path.as_uri())


@app.command("bundle-unified")
def bundle_unified(
    gds: str,
    layerstack: str | None = None,
    output: str | None = None,
    lyp: str | None = None,
    lyrdb: str | None = None,
    netlist: str | None = None,
) -> None:
    """Bundle a GDS layout into a unified 2D+3D HTML viewer."""
    _bundle_unified(
        gds,
        output=output,
        layerstack=layerstack,
        lyp=lyp,
        lyrdb=lyrdb,
        netlist=netlist,
    )


@app.command("view-unified")
def view_unified(
    gds: str,
    layerstack: str | None = None,
    lyp: str | None = None,
    lyrdb: str | None = None,
    netlist: str | None = None,
) -> None:
    """Bundle a GDS layout and open the unified 2D+3D viewer in the browser."""
    with tempfile.NamedTemporaryFile(
        suffix=".html", prefix="kwasm_unified_", delete=False
    ) as tmp:
        tmp_path = Path(tmp.name).resolve()
        _bundle_unified(
            gds,
            output=tmp_path,
            layerstack=layerstack,
            lyp=lyp,
            lyrdb=lyrdb,
            netlist=netlist,
        )
        webbrowser.open(tmp_path.as_uri())


_LayerMap = dict[str | int, list[int]]


def _fix_layers(obj: object, layer_map: _LayerMap) -> object:
    """Recursively replace KLayout layer names/indices with [layer, datatype] tuples."""
    if isinstance(obj, dict):
        return {
            k: (
                _fix_layer_value(v, layer_map)
                if k == "layer" and not isinstance(v, dict)
                else _fix_layers(v, layer_map)
            )
            for k, v in obj.items()
        }
    if isinstance(obj, list):
        return [_fix_layers(item, layer_map) for item in obj]
    return obj


def _fix_layer_value(value: object, layer_map: _LayerMap) -> object:
    """Convert a KLayout layer index or name to [layer, datatype]."""
    if isinstance(value, (int, str)):
        fallback = [value, 0] if isinstance(value, int) else value
        return layer_map.get(value, fallback)
    if isinstance(value, (list, tuple)) and len(value) == 2:
        return list(value)
    return value


@app.command("export-layerstack")
def export_layerstack(
    pdk_import: str = typer.Argument(help="PDK import path, e.g. 'cspdk.si220.cband'."),
    output: str | None = typer.Option(None, help="Output JSON path (default: stdout)."),
) -> None:
    """Export a gdsfactory PDK layerstack to kwasm-compatible JSON."""
    importlib.import_module(pdk_import)
    import gdsfactory as gf

    pdk = gf.get_active_pdk()
    if pdk.layer_stack is None or pdk.layers is None:
        typer.echo(f"PDK '{pdk_import}' has no layer_stack or layers.")
        raise typer.Exit(1)
    # Build name→[layer, datatype] and index→[layer, datatype] maps
    layout = gf.Component().kcl.layout
    name_map: dict[str, list[int]] = {}
    idx_map: dict[int, list[int]] = {}
    layers = cast(type[Enum], pdk.layers)
    for member in layers:
        info = layout.get_info(member.value)
        pair = [info.layer, info.datatype]
        name_map[member.name] = pair
        idx_map[member.value] = pair
    combined_map: dict[str | int, list[int]] = {**name_map, **idx_map}  # type: ignore[dict-item]
    d = _fix_layers(pdk.layer_stack.model_dump(), combined_map)
    result = json.dumps(d, indent=2)
    if output:
        Path(output).write_text(result)
    else:
        sys.stdout.write(result + "\n")


if __name__ == "__main__":
    app()
