#!/usr/bin/env python3
"""Go Links redirect server."""

import argparse
import json
import re
import shutil
import subprocess
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Dict
from urllib.parse import urlparse

from jinja2 import Environment, FileSystemLoader
from pydantic import ValidationError

from src.models import GoLinksConfig, LinkTemplate
from src.stats import get_stats_path, increment_stat, load_stats

PLIST_PATH = Path.home() / "Library" / "LaunchAgents" / "com.user.golinks.plist"
CONFIG_DIR = Path.home() / ".config" / "golinks"
DEFAULT_CONFIG_PATH = CONFIG_DIR / "config.json"


class GoLinksHandler(BaseHTTPRequestHandler):
    """HTTP request handler for go links."""

    def __init__(
        self,
        *args,
        config_path: Path = Path.home() / ".golinks" / "config.json",
        **kwargs,
    ):
        self.config_path = config_path
        self.stats_path = get_stats_path(config_path)
        # Set up Jinja2 template environment
        template_dir = Path(__file__).parent / "templates"
        self.jinja_env = Environment(
            loader=FileSystemLoader(template_dir), autoescape=True
        )
        super().__init__(*args, **kwargs)

    def get_config_path_display(self) -> str:
        """Get the config path as a string for display."""
        return str(self.config_path.absolute())
        # try:
        #     if self.config_path is None:
        #         return "Not configured"
        #     # Use absolute() instead of resolve() - resolve() can fail if file doesn't exist
        #     return str(Path(self.config_path).absolute())
        # except Exception:
        #     return str(self.config_path) if self.config_path else "Unknown"

    @property
    def config(self):
        """Load configuration from JSON file."""
        try:
            if not self.config_path.exists():
                raise FileNotFoundError(f"Config file not found: {self.config_path}")

            with open(self.config_path, "r") as f:
                config_data = json.load(f)

            # Parse with Pydantic model
            config_model = GoLinksConfig(config_data)
            return config_model.root
        except json.JSONDecodeError as e:
            print(f"Error loading config: {e}", file=sys.stderr)
            raise e
        except Exception as e:
            print(f"Unexpected error loading config: {e}", file=sys.stderr)
            raise e

    def do_GET(self):
        """Handle GET requests."""
        # Try to load config first
        print(f"Handling GET request for {self.path}")

        # Lightweight health check — no disk I/O or template rendering
        if self.path == "/healthz":
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"ok")
            return

        try:
            config = self.config
        except (json.JSONDecodeError, FileNotFoundError, ValidationError) as e:
            self.show_config_error_page(e)
            return

        # Parse the path
        parsed = urlparse(self.path)
        path = parsed.path.strip("/")
        query = parsed.query

        # Root path - show all available links
        if not path:
            self.show_links_page(config)
            return

        # Edit page
        if path == "edit":
            self.show_edit_page()
            return

        # Stats page
        if path == "stats":
            self.show_stats_page(config)
            return

        # Split path into segments
        path_segments = path.split("/")
        shortcut = path_segments[0]
        remaining_segments = path_segments[1:] if len(path_segments) > 1 else []

        # Check if shortcut exists
        if shortcut in config:
            config_entry = config[shortcut]

            # Handle string config (backward compatible)
            if isinstance(config_entry, str):
                destination = config_entry
            # Handle LinkTemplate config
            elif isinstance(config_entry, LinkTemplate):
                template = config_entry.template_url
                defaults = config_entry.defaults

                # Check if template has placeholders
                if re.search(r"\{\d+\}", template):
                    destination = self.resolve_placeholders(
                        template, remaining_segments, defaults
                    )
                else:
                    destination = template
            else:
                self.show_error_page(path)
                return

            # Preserve query parameters
            if query:
                separator = "&" if "?" in destination else "?"
                destination = f"{destination}{separator}{query}"

            # Track visit
            increment_stat(self.stats_path, shortcut)

            # Log the redirect
            print(f"[{self.log_date_time_string()}] {self.path} -> {destination}")

            # A 301 redirect is permanent, a 302 redirect is temporary. If we use a 301 redirect,
            # the browser will cache the redirect and may not follow the redirect if the destination
            # changes.
            # Perform 302 redirect
            self.send_response(302)
            self.send_header("Location", destination)
            self.end_headers()
        else:
            # Show error page
            self.show_error_page(path, config)

    def do_POST(self):
        """Handle POST requests."""
        parsed = urlparse(self.path)
        path = parsed.path.strip("/")

        if path == "edit":
            self.handle_edit_post()
        else:
            self.send_response(405)
            self.end_headers()

    def handle_edit_post(self):
        """Handle saving config from the edit page (JSON body)."""
        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length).decode("utf-8")

        try:
            config_data = json.loads(body)
            GoLinksConfig(config_data)
            with open(self.config_path, "w") as f:
                json.dump(config_data, f, indent=2)
                f.write("\n")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({"ok": True}).encode())
        except (json.JSONDecodeError, ValidationError) as e:
            self.send_response(400)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({"ok": False, "error": str(e)}).encode())

    def show_edit_page(self, message=None, success=False):
        """Display the config editor page."""
        try:
            config_data = json.loads(self.config_path.read_text())
        except (FileNotFoundError, json.JSONDecodeError):
            config_data = {}

        # Normalize into list of entries for the template
        links = []
        for name, value in sorted(config_data.items()):
            if isinstance(value, str):
                links.append(
                    {"name": name, "url": value, "is_template": False, "defaults": {}}
                )
            elif isinstance(value, dict):
                links.append(
                    {
                        "name": name,
                        "url": value.get("template_url", ""),
                        "is_template": True,
                        "defaults": value.get("defaults", {}),
                    }
                )
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()

        template = self.jinja_env.get_template("edit.html")
        html = template.render(
            links=links,
            config_path=self.get_config_path_display(),
            message=message,
            success=success,
        )
        self.wfile.write(html.encode())

    def show_links_page(self, config):
        """Display all available links."""
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()

        stats = load_stats(self.stats_path)
        template = self.jinja_env.get_template("links.html")
        html = template.render(
            config=config, config_path=self.get_config_path_display(), stats=stats
        )
        self.wfile.write(html.encode())

    def show_stats_page(self, config):
        """Display visit statistics."""
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()

        stats = load_stats(self.stats_path)
        template = self.jinja_env.get_template("stats.html")
        html = template.render(config=config, stats=stats)
        self.wfile.write(html.encode())

    def resolve_placeholders(
        self, template: str, segments: list, defaults: Dict[str, str]
    ) -> str:
        """Resolve placeholders in URL template."""
        # Find all placeholders using regex
        placeholders = re.findall(r"\{(\d+)\}", template)
        result = template

        for placeholder in placeholders:
            placeholder_num = placeholder
            placeholder_index = int(placeholder) - 1  # Convert to 0-based index

            # Determine the value to use
            if placeholder_index < len(segments) and segments[placeholder_index]:
                # Use provided segment
                value = segments[placeholder_index]
            elif placeholder_num in defaults:
                # Use default value
                value = defaults[placeholder_num]
            else:
                # No value available - use empty string as default
                value = ""

            # Replace the placeholder
            result = result.replace(f"{{{placeholder_num}}}", value)

        return result

    def show_error_page(self, path, config):
        """Display error page for unknown shortcuts."""
        self.send_response(404)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()

        # Prepare suggestions
        suggestions = sorted(config.keys())[:10] if config else []
        remaining_count = len(config) - 10 if config and len(config) > 10 else 0

        template = self.jinja_env.get_template("error.html")
        html = template.render(
            path=path,
            config=config,
            suggestions=suggestions,
            remaining_count=remaining_count,
        )
        self.wfile.write(html.encode())

    def show_config_error_page(self, error: Exception):
        """Display error page for configuration errors."""
        self.send_response(500)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()

        # Determine error type and message
        if isinstance(error, json.JSONDecodeError):
            error_type = "JSON Syntax Error"
            error_message = f"Line {error.lineno}, Column {error.colno}: {error.msg}"
        elif isinstance(error, FileNotFoundError):
            error_type = "Configuration File Not Found"
            error_message = str(error)
        elif isinstance(error, ValidationError):
            error_type = "Configuration Validation Error"
            error_message = str(error)
        else:
            error_type = "Configuration Error"
            error_message = str(error)

        template = self.jinja_env.get_template("config_error.html")
        html = template.render(
            error_type=error_type,
            error_message=error_message,
            config_path=self.get_config_path_display(),
        )
        self.wfile.write(html.encode())

    def log_message(self, format, *args):
        """Override to customize logging."""
        # Only log actual redirects and errors, not successful page loads
        if args[1] in ["301", "404"]:
            sys.stderr.write(f"[{self.log_date_time_string()}] {format % args}\n")


def run_server(host="127.0.0.1", port=8888, config_path=None):
    """Run the go links server."""

    # Create handler class with config path
    def handler_class(*args, **kwargs):
        return GoLinksHandler(*args, config_path=config_path, **kwargs)

    # Create and start server
    server = ThreadingHTTPServer((host, port), handler_class)
    print(f"Go Links server running on http://{host}:{port}")
    print(
        f"Configuration file: {config_path or (Path.home() / '.golinks' / 'config.json')}"
    )
    print("Press Ctrl+C to stop")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down server...")
        server.shutdown()


def get_config_path(config_arg: Path | None) -> Path:
    """Resolve the config path from argument or defaults."""
    if config_arg:
        return config_arg

    # Use config in project directory if it exists
    local_config = Path(__file__).parent.parent.parent / "config.json"
    if local_config.exists():
        return local_config

    return DEFAULT_CONFIG_PATH


def ensure_config_exists(config_path: Path) -> None:
    """Ensure config directory and file exist."""
    config_path.parent.mkdir(parents=True, exist_ok=True)

    if not config_path.exists():
        default_config = {
            "github": "https://github.com",
            "mail": "https://gmail.com",
            "calendar": "https://calendar.google.com",
        }
        with open(config_path, "w") as f:
            json.dump(default_config, f, indent=2)
        print(f"Created default configuration at {config_path}")


def cmd_run_server(args: argparse.Namespace) -> None:
    """Handle run-server subcommand."""
    config_path = get_config_path(args.config)
    ensure_config_exists(config_path)
    run_server(args.host, args.port, config_path)


def setup_launchagent(golinks_path: str, port: int, config_path: Path) -> None:
    """Create LaunchAgent plist file."""
    PLIST_PATH.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    plist_content = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.user.golinks</string>
    <key>ProgramArguments</key>
    <array>
        <string>{golinks_path}</string>
        <string>run-server</string>
        <string>--port</string>
        <string>{port}</string>
        <string>--config</string>
        <string>{config_path}</string>
    </array>
    <key>KeepAlive</key>
    <true/>
    <key>RunAtLoad</key>
    <true/>
    <key>StandardOutPath</key>
    <string>{CONFIG_DIR}/stdout.log</string>
    <key>StandardErrorPath</key>
    <string>{CONFIG_DIR}/stderr.log</string>
</dict>
</plist>
"""
    PLIST_PATH.write_text(plist_content)
    print(f"LaunchAgent plist created at {PLIST_PATH}")


def cmd_start_service(args: argparse.Namespace) -> None:
    """Handle start-service subcommand."""
    # Find golinks executable
    golinks_path = shutil.which("golinks")
    if not golinks_path:
        print("Error: golinks command not found in PATH", file=sys.stderr)
        sys.exit(1)

    config_path = get_config_path(args.config)
    ensure_config_exists(config_path)

    # Setup LaunchAgent
    setup_launchagent(golinks_path, args.port, config_path)

    # Unload if already loaded
    subprocess.run(
        ["launchctl", "unload", str(PLIST_PATH)],
        capture_output=True,
    )

    # Load the service
    result = subprocess.run(
        ["launchctl", "load", str(PLIST_PATH)],
        capture_output=True,
        text=True,
    )

    if result.returncode != 0:
        print(f"Error loading service: {result.stderr}", file=sys.stderr)
        sys.exit(1)

    print(f"Service started on port {args.port}")
    print(f"Configuration: {config_path}")
    print(f"Logs: {CONFIG_DIR}/stdout.log, {CONFIG_DIR}/stderr.log")


def cmd_stop_service(args: argparse.Namespace) -> None:
    """Handle stop-service subcommand."""
    if not PLIST_PATH.exists():
        print("Service is not installed", file=sys.stderr)
        sys.exit(1)

    result = subprocess.run(
        ["launchctl", "unload", str(PLIST_PATH)],
        capture_output=True,
        text=True,
    )

    if result.returncode != 0:
        print(f"Error stopping service: {result.stderr}", file=sys.stderr)
        sys.exit(1)

    print("Service stopped")


def cmd_setup_port_forwarding(args: argparse.Namespace) -> None:
    """Handle setup-port-forwarding subcommand.

    Sets up macOS packet filter (pf) to forward port 80 -> 8080.
    Requires sudo privileges.
    """
    import platform
    from datetime import datetime

    if platform.system() != "Darwin":
        print(
            "Error: Port forwarding setup is only supported on macOS", file=sys.stderr
        )
        sys.exit(1)

    anchor_path = Path("/etc/pf.anchors/golinks")
    pf_conf_path = Path("/etc/pf.conf")
    anchor_rule = "rdr pass on lo0 inet proto tcp from any to 127.0.0.1 port 80 -> 127.0.0.1 port 8080"

    # Step 1: Create pf anchor file
    if anchor_path.exists():
        print(f"Port forwarding anchor already exists at {anchor_path}")
    else:
        print("Creating port forwarding rule (requires sudo)...")
        result = subprocess.run(
            ["sudo", "tee", str(anchor_path)],
            input=anchor_rule,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            print(f"Error creating anchor file: {result.stderr}", file=sys.stderr)
            sys.exit(1)
        print(f"Port forwarding anchor created at {anchor_path}")

    # Step 2: Update pf.conf if needed
    pf_conf_content = pf_conf_path.read_text()
    if "golinks" in pf_conf_content:
        print("pf.conf already configured for golinks")
    else:
        print("Updating pf.conf (requires sudo)...")

        # Backup pf.conf
        backup_path = f"/etc/pf.conf.backup.{datetime.now().strftime('%Y%m%d%H%M%S')}"
        subprocess.run(["sudo", "cp", str(pf_conf_path), backup_path], check=True)
        print(f"Backed up pf.conf to {backup_path}")

        # Add rdr-anchor after "rdr-anchor \"com.apple/*\""
        pf_conf_content = pf_conf_content.replace(
            'rdr-anchor "com.apple/*"', 'rdr-anchor "com.apple/*"\nrdr-anchor "golinks"'
        )

        # Add load anchor after "load anchor \"com.apple\" from \"/etc/pf.anchors/com.apple\""
        pf_conf_content = pf_conf_content.replace(
            'load anchor "com.apple" from "/etc/pf.anchors/com.apple"',
            'load anchor "com.apple" from "/etc/pf.anchors/com.apple"\nload anchor "golinks" from "/etc/pf.anchors/golinks"',
        )

        # Write updated pf.conf
        result = subprocess.run(
            ["sudo", "tee", str(pf_conf_path)],
            input=pf_conf_content,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            print(f"Error updating pf.conf: {result.stderr}", file=sys.stderr)
            sys.exit(1)
        print("pf.conf updated")

    # Step 3: Enable pfctl and reload config
    print("Enabling packet filtering...")
    subprocess.run(["sudo", "pfctl", "-e"], capture_output=True)

    result = subprocess.run(
        ["sudo", "pfctl", "-f", str(pf_conf_path)],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        print(f"Warning: Could not reload pf.conf: {result.stderr}", file=sys.stderr)
        print("You may need to restart or manually run: sudo pfctl -f /etc/pf.conf")
    else:
        print("Port forwarding setup complete (80 -> 8080)")


def cmd_undo_port_forwarding(args: argparse.Namespace) -> None:
    """Handle undo-port-forwarding subcommand.

    Removes macOS packet filter (pf) rules created by setup-port-forwarding.
    Requires sudo privileges.
    """
    import platform
    from datetime import datetime

    if platform.system() != "Darwin":
        print("Error: Port forwarding undo is only supported on macOS", file=sys.stderr)
        sys.exit(1)

    anchor_path = Path("/etc/pf.anchors/golinks")
    pf_conf_path = Path("/etc/pf.conf")

    if not pf_conf_path.exists():
        print("Error: /etc/pf.conf not found", file=sys.stderr)
        sys.exit(1)

    removed_anchor = False
    if anchor_path.exists():
        print("Removing port forwarding anchor (requires sudo)...")
        result = subprocess.run(
            ["sudo", "rm", "-f", str(anchor_path)],
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            print(f"Error removing anchor file: {result.stderr}", file=sys.stderr)
            sys.exit(1)
        removed_anchor = True
        print(f"Port forwarding anchor removed at {anchor_path}")
    else:
        print("Port forwarding anchor not found")

    pf_conf_content = pf_conf_path.read_text()
    lines = pf_conf_content.splitlines()
    filtered_lines = [
        line
        for line in lines
        if line.strip()
        not in (
            'rdr-anchor "golinks"',
            'load anchor "golinks" from "/etc/pf.anchors/golinks"',
        )
    ]
    updated_pf_conf = "\n".join(filtered_lines)
    if pf_conf_content.endswith("\n"):
        updated_pf_conf += "\n"

    pf_conf_changed = updated_pf_conf != pf_conf_content
    if pf_conf_changed:
        print("Updating pf.conf (requires sudo)...")

        backup_path = f"/etc/pf.conf.backup.{datetime.now().strftime('%Y%m%d%H%M%S')}"
        subprocess.run(["sudo", "cp", str(pf_conf_path), backup_path], check=True)
        print(f"Backed up pf.conf to {backup_path}")

        result = subprocess.run(
            ["sudo", "tee", str(pf_conf_path)],
            input=updated_pf_conf,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            print(f"Error updating pf.conf: {result.stderr}", file=sys.stderr)
            sys.exit(1)
        print("pf.conf updated")
    else:
        print("pf.conf does not reference golinks")

    if removed_anchor or pf_conf_changed:
        print("Reloading packet filter rules...")
        result = subprocess.run(
            ["sudo", "pfctl", "-f", str(pf_conf_path)],
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            print(
                f"Warning: Could not reload pf.conf: {result.stderr}", file=sys.stderr
            )
            print("You may need to restart or manually run: sudo pfctl -f /etc/pf.conf")
        else:
            print("Port forwarding removed")
    else:
        print("No port forwarding rules to remove")


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Go Links redirect server",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # run-server subcommand
    run_parser = subparsers.add_parser(
        "run-server",
        help="Run the server directly (foreground)",
    )
    run_parser.add_argument(
        "--config",
        "-c",
        type=Path,
        help=f"Path to configuration file (default: {DEFAULT_CONFIG_PATH})",
    )
    run_parser.add_argument(
        "--port",
        "-p",
        type=int,
        default=8080,
        help="Port to listen on (default: 8080)",
    )
    run_parser.add_argument(
        "--host",
        default="127.0.0.1",
        help="Host to bind to (default: 127.0.0.1)",
    )
    run_parser.set_defaults(func=cmd_run_server)

    # start-service subcommand
    start_parser = subparsers.add_parser(
        "start-service",
        help="Start as a background service (macOS LaunchAgent)",
    )
    start_parser.add_argument(
        "--config",
        "-c",
        type=Path,
        help=f"Path to configuration file (default: {DEFAULT_CONFIG_PATH})",
    )
    start_parser.add_argument(
        "--port",
        "-p",
        type=int,
        default=8080,
        help="Port to listen on (default: 8080)",
    )
    start_parser.set_defaults(func=cmd_start_service)

    # stop-service subcommand
    stop_parser = subparsers.add_parser(
        "stop-service",
        help="Stop the background service",
    )
    stop_parser.set_defaults(func=cmd_stop_service)

    # setup-port-forwarding subcommand
    pf_parser = subparsers.add_parser(
        "setup-port-forwarding",
        help="Setup port 80 -> 8080 forwarding (requires sudo, macOS only)",
    )
    pf_parser.set_defaults(func=cmd_setup_port_forwarding)

    # undo-port-forwarding subcommand
    undo_pf_parser = subparsers.add_parser(
        "undo-port-forwarding",
        help="Undo port 80 -> 8080 forwarding (requires sudo, macOS only)",
    )
    undo_pf_parser.set_defaults(func=cmd_undo_port_forwarding)

    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        sys.exit(1)

    args.func(args)


if __name__ == "__main__":
    main()
