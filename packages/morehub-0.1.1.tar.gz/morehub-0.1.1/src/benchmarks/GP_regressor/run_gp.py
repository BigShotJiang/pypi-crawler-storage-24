"""Gaussian Process Regression execution module."""

from pathlib import Path

try:
    from .train import evaluate
except ImportError:
    from train import evaluate


def run_gp_regression(
    embeddings_path: str = None,
    target_path: str = None,
    splits_dir: str = None,
    n_splits: int = 5,
    compute_rmse: bool = True,
    kernel_name: str = "gaussian",
    workdir: str = None,
    results_dir: str | None = None,
):
    """Execute Gaussian Process regression with specified configuration."""
    if embeddings_path is None or target_path is None or splits_dir is None:
        project_root = Path(__file__).resolve().parent
        embeddings_path = embeddings_path or str(project_root / "Data" / "ChemAI_TED.npy")
        target_path = target_path or str(project_root / "Data" / "SELFIES_KOA.txt")
        splits_dir = splits_dir or str(project_root / "Splits")

    workdir = workdir or Path.cwd()

    print("\n=== GP Regression Configuration ===")
    print(f"Workdir: {workdir}")
    print(f"Embeddings: {embeddings_path}")
    print(f"Targets: {target_path}")
    print(f"Splits dir: {splits_dir}")
    print(f"Kernel: {kernel_name}")
    print(f"Number of splits: {n_splits}")
    print(f"Compute RMSE: {compute_rmse}")
    if results_dir:
        print(f"Results dir: {results_dir}")
    print("=" * 40)

    return evaluate(
        embeddings_path=embeddings_path,
        target_path=target_path,
        splits_dir=splits_dir,
        n_splits=n_splits,
        compute_rmse=compute_rmse,
        kernel_name=kernel_name,
        results_dir=results_dir,
    )


if __name__ == "__main__":
    run_gp_regression()
