"""GP regression benchmark package."""
