import numpy as np
from sklearn.model_selection import ShuffleSplit


class SplitGenerator:
    def __init__(self, n_samples, train_ratio = 0.7):

        self.n_samples = n_samples
        self.train_ratio = train_ratio
        self.splits = []

    def generate_splits(self, n_splits=5, random_state=None):
        """
        Generate diverse splits.

        Args:
            n_splits (int): Number of final splits to keep.
            n_candidates (int): Number of candidate splits to try before stopping.
            random_state (int or None): Reproducibility seed.

        Returns:
            list of (train_idx, test_idx) tuples
        """
        ss = ShuffleSplit(
            n_splits = n_splits,
            train_size=self.train_ratio,
            random_state=random_state,
        )
        self.splits = list(ss.split(np.arange(self.n_samples)))
        return self.splits
    