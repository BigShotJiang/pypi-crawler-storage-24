"""UI assets for GP regression benchmark."""
