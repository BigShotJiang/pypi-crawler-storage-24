# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'mainui.ui'
##
## Created by: Qt User Interface Compiler version 6.10.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QAction, QBrush, QColor, QConicalGradient,
    QCursor, QFont, QFontDatabase, QGradient,
    QIcon, QImage, QKeySequence, QLinearGradient,
    QPainter, QPalette, QPixmap, QRadialGradient,
    QTransform)
from PySide6.QtWidgets import (QApplication, QCheckBox, QFrame, QHBoxLayout,
    QLabel, QMainWindow, QMenu, QMenuBar,
    QPushButton, QRadioButton, QSizePolicy, QStatusBar,
    QTabWidget, QTextEdit, QVBoxLayout, QWidget)

from pathlib import Path

MAIN_ICONS_PATH = Path(__file__).resolve().parent / "icons"

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1181, 834)
        self.actionNew = QAction(MainWindow)
        self.actionNew.setObjectName(u"actionNew")
        self.actionLoad = QAction(MainWindow)
        self.actionLoad.setObjectName(u"actionLoad")
        self.actionGP_Regression = QAction(MainWindow)
        self.actionGP_Regression.setObjectName(u"actionGP_Regression")
        self.actionNew_Data_Setup = QAction(MainWindow)
        self.actionNew_Data_Setup.setObjectName(u"actionNew_Data_Setup")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.verticalLayout = QVBoxLayout(self.centralwidget)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.tabWidget = QTabWidget(self.centralwidget)
        self.tabWidget.setObjectName(u"tabWidget")
        font = QFont()
        font.setFamilies([u"Nirmala UI"])
        font.setPointSize(12)
        font.setBold(True)
        font.setStrikeOut(False)
        self.tabWidget.setFont(font)
        self.tabWidget.setStyleSheet(u"background-color: rgb(170, 170, 170);")
        self.tabWidget.setTabPosition(QTabWidget.TabPosition.North)
        self.tabWidget.setTabShape(QTabWidget.TabShape.Rounded)
        self.tabWidget.setIconSize(QSize(16, 16))
        self.tabWidget.setElideMode(Qt.TextElideMode.ElideNone)
        self.tabWidget.setUsesScrollButtons(True)
        self.tab = QWidget()
        self.tab.setObjectName(u"tab")
        self.verticalLayout_11 = QVBoxLayout(self.tab)
        self.verticalLayout_11.setObjectName(u"verticalLayout_11")
        self.frame_12 = QFrame(self.tab)
        self.frame_12.setObjectName(u"frame_12")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.frame_12.sizePolicy().hasHeightForWidth())
        self.frame_12.setSizePolicy(sizePolicy)
        self.frame_12.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_12.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_6 = QHBoxLayout(self.frame_12)
        self.horizontalLayout_6.setObjectName(u"horizontalLayout_6")
        self.frame_11 = QFrame(self.frame_12)
        self.frame_11.setObjectName(u"frame_11")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy1.setHorizontalStretch(1)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.frame_11.sizePolicy().hasHeightForWidth())
        self.frame_11.setSizePolicy(sizePolicy1)
        self.frame_11.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_11.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_10 = QVBoxLayout(self.frame_11)
        self.verticalLayout_10.setObjectName(u"verticalLayout_10")
        self.frame = QFrame(self.frame_11)
        self.frame.setObjectName(u"frame")
        self.frame.setStyleSheet(u"background-color: rgb(177, 177, 177);")
        self.frame.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_3 = QVBoxLayout(self.frame)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.frame_27 = QFrame(self.frame)
        self.frame_27.setObjectName(u"frame_27")
        self.frame_27.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_27.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_17 = QHBoxLayout(self.frame_27)
        self.horizontalLayout_17.setObjectName(u"horizontalLayout_17")
        self.label_19 = QLabel(self.frame_27)
        self.label_19.setObjectName(u"label_19")
        font1 = QFont()
        font1.setFamilies([u"Oswald"])
        font1.setPointSize(15)
        font1.setBold(False)
        self.label_19.setFont(font1)
        self.label_19.setTextFormat(Qt.TextFormat.PlainText)
        self.label_19.setScaledContents(False)

        self.horizontalLayout_17.addWidget(self.label_19)

        self.label = QLabel(self.frame_27)
        self.label.setObjectName(u"label")
        font2 = QFont()
        font2.setFamilies([u"Oswald"])
        font2.setPointSize(10)
        self.label.setFont(font2)

        self.horizontalLayout_17.addWidget(self.label)


        self.verticalLayout_3.addWidget(self.frame_27)

        self.widget = QWidget(self.frame)
        self.widget.setObjectName(u"widget")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(1)
        sizePolicy2.setHeightForWidth(self.widget.sizePolicy().hasHeightForWidth())
        self.widget.setSizePolicy(sizePolicy2)
        self.horizontalLayout = QHBoxLayout(self.widget)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.pushButton = QPushButton(self.widget)
        self.pushButton.setObjectName(u"pushButton")
        self.pushButton.setMinimumSize(QSize(46, 46))
        self.pushButton.setMaximumSize(QSize(60, 16777215))
        icon = QIcon()
        icon.addFile(str(MAIN_ICONS_PATH / "folder.png"), QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.pushButton.setIcon(icon)
        self.pushButton.setIconSize(QSize(30, 30))

        self.horizontalLayout.addWidget(self.pushButton)

        self.label_2 = QLabel(self.widget)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setMinimumSize(QSize(2, 33))
        self.label_2.setMaximumSize(QSize(16777215, 33))
        self.label_2.setStyleSheet(u"background-color: rgb(220,220, 220);")

        self.horizontalLayout.addWidget(self.label_2)


        self.verticalLayout_3.addWidget(self.widget)


        self.verticalLayout_10.addWidget(self.frame)

        self.frame_10 = QFrame(self.frame_11)
        self.frame_10.setObjectName(u"frame_10")
        self.frame_10.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_10.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_5 = QHBoxLayout(self.frame_10)
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.frame_2 = QFrame(self.frame_10)
        self.frame_2.setObjectName(u"frame_2")
        self.frame_2.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_2.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_2.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_5 = QVBoxLayout(self.frame_2)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.label_3 = QLabel(self.frame_2)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setFont(font2)

        self.verticalLayout_5.addWidget(self.label_3, 0, Qt.AlignmentFlag.AlignHCenter)

        self.widget_2 = QWidget(self.frame_2)
        self.widget_2.setObjectName(u"widget_2")
        sizePolicy2.setHeightForWidth(self.widget_2.sizePolicy().hasHeightForWidth())
        self.widget_2.setSizePolicy(sizePolicy2)
        self.widget_2.setStyleSheet(u"background-color: rgb(140, 140, 140);")
        self.verticalLayout_4 = QVBoxLayout(self.widget_2)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.radioButton = QRadioButton(self.widget_2)
        self.radioButton.setObjectName(u"radioButton")
        font3 = QFont()
        font3.setFamilies([u"Oswald"])
        self.radioButton.setFont(font3)

        self.verticalLayout_4.addWidget(self.radioButton)

        self.radioButton_2 = QRadioButton(self.widget_2)
        self.radioButton_2.setObjectName(u"radioButton_2")
        self.radioButton_2.setFont(font3)

        self.verticalLayout_4.addWidget(self.radioButton_2)


        self.verticalLayout_5.addWidget(self.widget_2)


        self.horizontalLayout_5.addWidget(self.frame_2)

        self.frame_5 = QFrame(self.frame_10)
        self.frame_5.setObjectName(u"frame_5")
        sizePolicy1.setHeightForWidth(self.frame_5.sizePolicy().hasHeightForWidth())
        self.frame_5.setSizePolicy(sizePolicy1)
        self.frame_5.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_5.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_7 = QVBoxLayout(self.frame_5)
        self.verticalLayout_7.setObjectName(u"verticalLayout_7")
        self.frame_3 = QFrame(self.frame_5)
        self.frame_3.setObjectName(u"frame_3")
        self.frame_3.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_3.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_3.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_2 = QHBoxLayout(self.frame_3)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.model_installed = QCheckBox(self.frame_3)
        self.model_installed.setObjectName(u"model_installed")
        self.model_installed.setEnabled(False)
        font4 = QFont()
        font4.setFamilies([u"Oswald"])
        font4.setPointSize(9)
        self.model_installed.setFont(font4)
        self.model_installed.setAutoFillBackground(False)
        self.model_installed.setIconSize(QSize(30, 30))
        self.model_installed.setCheckable(False)
        self.model_installed.setTristate(False)

        self.horizontalLayout_2.addWidget(self.model_installed)


        self.verticalLayout_7.addWidget(self.frame_3)

        self.frame_6 = QFrame(self.frame_5)
        self.frame_6.setObjectName(u"frame_6")
        self.frame_6.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_6.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_6.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_3 = QHBoxLayout(self.frame_6)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.checkpoints_downloaded = QCheckBox(self.frame_6)
        self.checkpoints_downloaded.setObjectName(u"checkpoints_downloaded")
        self.checkpoints_downloaded.setEnabled(False)
        self.checkpoints_downloaded.setFont(font4)
        self.checkpoints_downloaded.setAutoFillBackground(False)
        self.checkpoints_downloaded.setIconSize(QSize(30, 30))
        self.checkpoints_downloaded.setCheckable(False)
        self.checkpoints_downloaded.setTristate(False)

        self.horizontalLayout_3.addWidget(self.checkpoints_downloaded)


        self.verticalLayout_7.addWidget(self.frame_6)


        self.horizontalLayout_5.addWidget(self.frame_5)


        self.verticalLayout_10.addWidget(self.frame_10)


        self.horizontalLayout_6.addWidget(self.frame_11)

        self.frame_4 = QFrame(self.frame_12)
        self.frame_4.setObjectName(u"frame_4")
        sizePolicy1.setHeightForWidth(self.frame_4.sizePolicy().hasHeightForWidth())
        self.frame_4.setSizePolicy(sizePolicy1)
        self.frame_4.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_4.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_6 = QVBoxLayout(self.frame_4)
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.widget_3 = QWidget(self.frame_4)
        self.widget_3.setObjectName(u"widget_3")
        sizePolicy3 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.widget_3.sizePolicy().hasHeightForWidth())
        self.widget_3.setSizePolicy(sizePolicy3)
        self.widget_3.setMinimumSize(QSize(0, 50))
        self.horizontalLayout_7 = QHBoxLayout(self.widget_3)
        self.horizontalLayout_7.setObjectName(u"horizontalLayout_7")
        self.label_9 = QLabel(self.widget_3)
        self.label_9.setObjectName(u"label_9")
        self.label_9.setFont(font2)

        self.horizontalLayout_7.addWidget(self.label_9)

        self.frame_13 = QFrame(self.widget_3)
        self.frame_13.setObjectName(u"frame_13")
        sizePolicy4 = QSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Preferred)
        sizePolicy4.setHorizontalStretch(0)
        sizePolicy4.setVerticalStretch(0)
        sizePolicy4.setHeightForWidth(self.frame_13.sizePolicy().hasHeightForWidth())
        self.frame_13.setSizePolicy(sizePolicy4)
        self.frame_13.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_13.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_8 = QHBoxLayout(self.frame_13)
        self.horizontalLayout_8.setObjectName(u"horizontalLayout_8")
        self.label_4 = QLabel(self.frame_13)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setFont(font2)

        self.horizontalLayout_8.addWidget(self.label_4)

        self.pushButton_2 = QPushButton(self.frame_13)
        self.pushButton_2.setObjectName(u"pushButton_2")
        self.pushButton_2.setMinimumSize(QSize(30, 30))
        self.pushButton_2.setMaximumSize(QSize(40, 40))
        icon1 = QIcon()
        icon1.addFile(str(MAIN_ICONS_PATH / "run.png"), QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.pushButton_2.setIcon(icon1)
        self.pushButton_2.setIconSize(QSize(30, 30))

        self.horizontalLayout_8.addWidget(self.pushButton_2)


        self.horizontalLayout_7.addWidget(self.frame_13)


        self.verticalLayout_6.addWidget(self.widget_3)

        self.textEdit = QTextEdit(self.frame_4)
        self.textEdit.setObjectName(u"textEdit")
        sizePolicy5 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy5.setHorizontalStretch(0)
        sizePolicy5.setVerticalStretch(2)
        sizePolicy5.setHeightForWidth(self.textEdit.sizePolicy().hasHeightForWidth())
        self.textEdit.setSizePolicy(sizePolicy5)
        self.textEdit.setStyleSheet(u"background-color: rgb(229, 229, 229);")
        self.textEdit.setReadOnly(True)

        self.verticalLayout_6.addWidget(self.textEdit)


        self.horizontalLayout_6.addWidget(self.frame_4)


        self.verticalLayout_11.addWidget(self.frame_12)

        self.tabWidget.addTab(self.tab, "")
        self.tab_2 = QWidget()
        self.tab_2.setObjectName(u"tab_2")
        self.verticalLayout_20 = QVBoxLayout(self.tab_2)
        self.verticalLayout_20.setObjectName(u"verticalLayout_20")
        self.frame_14 = QFrame(self.tab_2)
        self.frame_14.setObjectName(u"frame_14")
        sizePolicy.setHeightForWidth(self.frame_14.sizePolicy().hasHeightForWidth())
        self.frame_14.setSizePolicy(sizePolicy)
        self.frame_14.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_14.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_9 = QHBoxLayout(self.frame_14)
        self.horizontalLayout_9.setObjectName(u"horizontalLayout_9")
        self.frame_15 = QFrame(self.frame_14)
        self.frame_15.setObjectName(u"frame_15")
        sizePolicy1.setHeightForWidth(self.frame_15.sizePolicy().hasHeightForWidth())
        self.frame_15.setSizePolicy(sizePolicy1)
        self.frame_15.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_15.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_12 = QVBoxLayout(self.frame_15)
        self.verticalLayout_12.setObjectName(u"verticalLayout_12")
        self.frame_16 = QFrame(self.frame_15)
        self.frame_16.setObjectName(u"frame_16")
        self.frame_16.setStyleSheet(u"background-color: rgb(177, 177, 177);")
        self.frame_16.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_16.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_13 = QVBoxLayout(self.frame_16)
        self.verticalLayout_13.setObjectName(u"verticalLayout_13")
        self.frame_28 = QFrame(self.frame_16)
        self.frame_28.setObjectName(u"frame_28")
        self.frame_28.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_28.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_18 = QHBoxLayout(self.frame_28)
        self.horizontalLayout_18.setObjectName(u"horizontalLayout_18")
        self.label_20 = QLabel(self.frame_28)
        self.label_20.setObjectName(u"label_20")
        font5 = QFont()
        font5.setFamilies([u"Oswald"])
        font5.setPointSize(15)
        self.label_20.setFont(font5)
        self.label_20.setTextFormat(Qt.TextFormat.PlainText)
        self.label_20.setScaledContents(False)

        self.horizontalLayout_18.addWidget(self.label_20)

        self.label_10 = QLabel(self.frame_28)
        self.label_10.setObjectName(u"label_10")
        self.label_10.setFont(font2)

        self.horizontalLayout_18.addWidget(self.label_10)


        self.verticalLayout_13.addWidget(self.frame_28)

        self.widget_4 = QWidget(self.frame_16)
        self.widget_4.setObjectName(u"widget_4")
        sizePolicy2.setHeightForWidth(self.widget_4.sizePolicy().hasHeightForWidth())
        self.widget_4.setSizePolicy(sizePolicy2)
        self.horizontalLayout_10 = QHBoxLayout(self.widget_4)
        self.horizontalLayout_10.setObjectName(u"horizontalLayout_10")
        self.pushButton_3 = QPushButton(self.widget_4)
        self.pushButton_3.setObjectName(u"pushButton_3")
        self.pushButton_3.setMinimumSize(QSize(46, 46))
        self.pushButton_3.setMaximumSize(QSize(60, 16777215))
        self.pushButton_3.setIcon(icon)
        self.pushButton_3.setIconSize(QSize(30, 30))

        self.horizontalLayout_10.addWidget(self.pushButton_3)

        self.label_11 = QLabel(self.widget_4)
        self.label_11.setObjectName(u"label_11")
        self.label_11.setMinimumSize(QSize(2, 33))
        self.label_11.setMaximumSize(QSize(16777215, 33))
        self.label_11.setStyleSheet(u"background-color: rgb(220,220, 220);")

        self.horizontalLayout_10.addWidget(self.label_11)


        self.verticalLayout_13.addWidget(self.widget_4)


        self.verticalLayout_12.addWidget(self.frame_16)

        self.frame_17 = QFrame(self.frame_15)
        self.frame_17.setObjectName(u"frame_17")
        self.frame_17.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_17.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_11 = QHBoxLayout(self.frame_17)
        self.horizontalLayout_11.setObjectName(u"horizontalLayout_11")
        self.frame_18 = QFrame(self.frame_17)
        self.frame_18.setObjectName(u"frame_18")
        self.frame_18.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_18.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_18.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_14 = QVBoxLayout(self.frame_18)
        self.verticalLayout_14.setObjectName(u"verticalLayout_14")
        self.label_12 = QLabel(self.frame_18)
        self.label_12.setObjectName(u"label_12")
        self.label_12.setFont(font2)

        self.verticalLayout_14.addWidget(self.label_12, 0, Qt.AlignmentFlag.AlignHCenter)

        self.widget_5 = QWidget(self.frame_18)
        self.widget_5.setObjectName(u"widget_5")
        sizePolicy2.setHeightForWidth(self.widget_5.sizePolicy().hasHeightForWidth())
        self.widget_5.setSizePolicy(sizePolicy2)
        self.widget_5.setStyleSheet(u"background-color: rgb(140, 140, 140);")
        self.verticalLayout_15 = QVBoxLayout(self.widget_5)
        self.verticalLayout_15.setObjectName(u"verticalLayout_15")
        self.radioButton_3 = QRadioButton(self.widget_5)
        self.radioButton_3.setObjectName(u"radioButton_3")
        self.radioButton_3.setFont(font3)

        self.verticalLayout_15.addWidget(self.radioButton_3)

        self.radioButton_4 = QRadioButton(self.widget_5)
        self.radioButton_4.setObjectName(u"radioButton_4")
        self.radioButton_4.setFont(font3)

        self.verticalLayout_15.addWidget(self.radioButton_4)


        self.verticalLayout_14.addWidget(self.widget_5)


        self.horizontalLayout_11.addWidget(self.frame_18)

        self.frame_19 = QFrame(self.frame_17)
        self.frame_19.setObjectName(u"frame_19")
        sizePolicy1.setHeightForWidth(self.frame_19.sizePolicy().hasHeightForWidth())
        self.frame_19.setSizePolicy(sizePolicy1)
        self.frame_19.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_19.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_16 = QVBoxLayout(self.frame_19)
        self.verticalLayout_16.setObjectName(u"verticalLayout_16")
        self.frame_20 = QFrame(self.frame_19)
        self.frame_20.setObjectName(u"frame_20")
        self.frame_20.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_20.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_20.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_12 = QHBoxLayout(self.frame_20)
        self.horizontalLayout_12.setObjectName(u"horizontalLayout_12")
        self.model_installed_2 = QCheckBox(self.frame_20)
        self.model_installed_2.setObjectName(u"model_installed_2")
        self.model_installed_2.setEnabled(False)
        self.model_installed_2.setFont(font4)
        self.model_installed_2.setAutoFillBackground(False)
        self.model_installed_2.setIconSize(QSize(30, 30))
        self.model_installed_2.setCheckable(False)
        self.model_installed_2.setTristate(False)

        self.horizontalLayout_12.addWidget(self.model_installed_2)


        self.verticalLayout_16.addWidget(self.frame_20)

        self.frame_21 = QFrame(self.frame_19)
        self.frame_21.setObjectName(u"frame_21")
        self.frame_21.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_21.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_21.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_13 = QHBoxLayout(self.frame_21)
        self.horizontalLayout_13.setObjectName(u"horizontalLayout_13")
        self.checkpoints_downloaded_2 = QCheckBox(self.frame_21)
        self.checkpoints_downloaded_2.setObjectName(u"checkpoints_downloaded_2")
        self.checkpoints_downloaded_2.setEnabled(False)
        self.checkpoints_downloaded_2.setFont(font4)
        self.checkpoints_downloaded_2.setAutoFillBackground(False)
        self.checkpoints_downloaded_2.setIconSize(QSize(30, 30))
        self.checkpoints_downloaded_2.setCheckable(False)
        self.checkpoints_downloaded_2.setTristate(False)

        self.horizontalLayout_13.addWidget(self.checkpoints_downloaded_2)


        self.verticalLayout_16.addWidget(self.frame_21)


        self.horizontalLayout_11.addWidget(self.frame_19)


        self.verticalLayout_12.addWidget(self.frame_17)


        self.horizontalLayout_9.addWidget(self.frame_15)

        self.frame_22 = QFrame(self.frame_14)
        self.frame_22.setObjectName(u"frame_22")
        sizePolicy1.setHeightForWidth(self.frame_22.sizePolicy().hasHeightForWidth())
        self.frame_22.setSizePolicy(sizePolicy1)
        self.frame_22.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_22.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_17 = QVBoxLayout(self.frame_22)
        self.verticalLayout_17.setObjectName(u"verticalLayout_17")
        self.widget_6 = QWidget(self.frame_22)
        self.widget_6.setObjectName(u"widget_6")
        sizePolicy3.setHeightForWidth(self.widget_6.sizePolicy().hasHeightForWidth())
        self.widget_6.setSizePolicy(sizePolicy3)
        self.widget_6.setMinimumSize(QSize(0, 50))
        self.horizontalLayout_14 = QHBoxLayout(self.widget_6)
        self.horizontalLayout_14.setObjectName(u"horizontalLayout_14")
        self.label_13 = QLabel(self.widget_6)
        self.label_13.setObjectName(u"label_13")
        self.label_13.setFont(font2)

        self.horizontalLayout_14.addWidget(self.label_13)

        self.frame_23 = QFrame(self.widget_6)
        self.frame_23.setObjectName(u"frame_23")
        sizePolicy4.setHeightForWidth(self.frame_23.sizePolicy().hasHeightForWidth())
        self.frame_23.setSizePolicy(sizePolicy4)
        self.frame_23.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_23.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_15 = QHBoxLayout(self.frame_23)
        self.horizontalLayout_15.setObjectName(u"horizontalLayout_15")
        self.label_14 = QLabel(self.frame_23)
        self.label_14.setObjectName(u"label_14")
        self.label_14.setFont(font2)

        self.horizontalLayout_15.addWidget(self.label_14)

        self.pushButton_4 = QPushButton(self.frame_23)
        self.pushButton_4.setObjectName(u"pushButton_4")
        self.pushButton_4.setMinimumSize(QSize(30, 30))
        self.pushButton_4.setMaximumSize(QSize(40, 40))
        self.pushButton_4.setIcon(icon1)
        self.pushButton_4.setIconSize(QSize(30, 30))

        self.horizontalLayout_15.addWidget(self.pushButton_4)


        self.horizontalLayout_14.addWidget(self.frame_23)


        self.verticalLayout_17.addWidget(self.widget_6)

        self.textEdit_2 = QTextEdit(self.frame_22)
        self.textEdit_2.setObjectName(u"textEdit_2")
        sizePolicy5.setHeightForWidth(self.textEdit_2.sizePolicy().hasHeightForWidth())
        self.textEdit_2.setSizePolicy(sizePolicy5)
        self.textEdit_2.setStyleSheet(u"background-color: rgb(229, 229, 229);")
        self.textEdit_2.setReadOnly(True)

        self.verticalLayout_17.addWidget(self.textEdit_2)


        self.horizontalLayout_9.addWidget(self.frame_22)


        self.verticalLayout_20.addWidget(self.frame_14)

        self.tabWidget.addTab(self.tab_2, "")
        self.tab_3 = QWidget()
        self.tab_3.setObjectName(u"tab_3")
        self.verticalLayout_29 = QVBoxLayout(self.tab_3)
        self.verticalLayout_29.setObjectName(u"verticalLayout_29")
        self.frame_29 = QFrame(self.tab_3)
        self.frame_29.setObjectName(u"frame_29")
        sizePolicy.setHeightForWidth(self.frame_29.sizePolicy().hasHeightForWidth())
        self.frame_29.setSizePolicy(sizePolicy)
        self.frame_29.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_29.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_19 = QHBoxLayout(self.frame_29)
        self.horizontalLayout_19.setObjectName(u"horizontalLayout_19")
        self.frame_30 = QFrame(self.frame_29)
        self.frame_30.setObjectName(u"frame_30")
        sizePolicy1.setHeightForWidth(self.frame_30.sizePolicy().hasHeightForWidth())
        self.frame_30.setSizePolicy(sizePolicy1)
        self.frame_30.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_30.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_21 = QVBoxLayout(self.frame_30)
        self.verticalLayout_21.setObjectName(u"verticalLayout_21")
        self.frame_31 = QFrame(self.frame_30)
        self.frame_31.setObjectName(u"frame_31")
        self.frame_31.setStyleSheet(u"background-color: rgb(177, 177, 177);")
        self.frame_31.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_31.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_22 = QVBoxLayout(self.frame_31)
        self.verticalLayout_22.setObjectName(u"verticalLayout_22")
        self.frame_32 = QFrame(self.frame_31)
        self.frame_32.setObjectName(u"frame_32")
        self.frame_32.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_32.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_20 = QHBoxLayout(self.frame_32)
        self.horizontalLayout_20.setObjectName(u"horizontalLayout_20")
        self.label_21 = QLabel(self.frame_32)
        self.label_21.setObjectName(u"label_21")
        self.label_21.setFont(font5)
        self.label_21.setTextFormat(Qt.TextFormat.PlainText)
        self.label_21.setScaledContents(False)

        self.horizontalLayout_20.addWidget(self.label_21)

        self.label_22 = QLabel(self.frame_32)
        self.label_22.setObjectName(u"label_22")
        self.label_22.setFont(font2)

        self.horizontalLayout_20.addWidget(self.label_22)


        self.verticalLayout_22.addWidget(self.frame_32)

        self.widget_7 = QWidget(self.frame_31)
        self.widget_7.setObjectName(u"widget_7")
        sizePolicy2.setHeightForWidth(self.widget_7.sizePolicy().hasHeightForWidth())
        self.widget_7.setSizePolicy(sizePolicy2)
        self.horizontalLayout_21 = QHBoxLayout(self.widget_7)
        self.horizontalLayout_21.setObjectName(u"horizontalLayout_21")
        self.pushButton_5 = QPushButton(self.widget_7)
        self.pushButton_5.setObjectName(u"pushButton_5")
        self.pushButton_5.setMinimumSize(QSize(46, 46))
        self.pushButton_5.setMaximumSize(QSize(60, 16777215))
        self.pushButton_5.setIcon(icon)
        self.pushButton_5.setIconSize(QSize(30, 30))

        self.horizontalLayout_21.addWidget(self.pushButton_5)

        self.label_23 = QLabel(self.widget_7)
        self.label_23.setObjectName(u"label_23")
        self.label_23.setMinimumSize(QSize(2, 33))
        self.label_23.setMaximumSize(QSize(16777215, 33))
        self.label_23.setStyleSheet(u"background-color: rgb(220,220, 220);")

        self.horizontalLayout_21.addWidget(self.label_23)


        self.verticalLayout_22.addWidget(self.widget_7)


        self.verticalLayout_21.addWidget(self.frame_31)

        self.frame_33 = QFrame(self.frame_30)
        self.frame_33.setObjectName(u"frame_33")
        self.frame_33.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_33.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_22 = QHBoxLayout(self.frame_33)
        self.horizontalLayout_22.setObjectName(u"horizontalLayout_22")
        self.frame_34 = QFrame(self.frame_33)
        self.frame_34.setObjectName(u"frame_34")
        self.frame_34.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_34.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_34.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_23 = QVBoxLayout(self.frame_34)
        self.verticalLayout_23.setObjectName(u"verticalLayout_23")
        self.label_24 = QLabel(self.frame_34)
        self.label_24.setObjectName(u"label_24")
        self.label_24.setFont(font2)

        self.verticalLayout_23.addWidget(self.label_24, 0, Qt.AlignmentFlag.AlignHCenter)

        self.widget_8 = QWidget(self.frame_34)
        self.widget_8.setObjectName(u"widget_8")
        sizePolicy2.setHeightForWidth(self.widget_8.sizePolicy().hasHeightForWidth())
        self.widget_8.setSizePolicy(sizePolicy2)
        self.widget_8.setStyleSheet(u"background-color: rgb(140, 140, 140);")
        self.verticalLayout_24 = QVBoxLayout(self.widget_8)
        self.verticalLayout_24.setObjectName(u"verticalLayout_24")
        self.radioButton_5 = QRadioButton(self.widget_8)
        self.radioButton_5.setObjectName(u"radioButton_5")
        self.radioButton_5.setFont(font3)

        self.verticalLayout_24.addWidget(self.radioButton_5)

        self.radioButton_6 = QRadioButton(self.widget_8)
        self.radioButton_6.setObjectName(u"radioButton_6")
        self.radioButton_6.setFont(font3)

        self.verticalLayout_24.addWidget(self.radioButton_6)


        self.verticalLayout_23.addWidget(self.widget_8)


        self.horizontalLayout_22.addWidget(self.frame_34)

        self.frame_35 = QFrame(self.frame_33)
        self.frame_35.setObjectName(u"frame_35")
        sizePolicy1.setHeightForWidth(self.frame_35.sizePolicy().hasHeightForWidth())
        self.frame_35.setSizePolicy(sizePolicy1)
        self.frame_35.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_35.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_25 = QVBoxLayout(self.frame_35)
        self.verticalLayout_25.setObjectName(u"verticalLayout_25")
        self.frame_46 = QFrame(self.frame_35)
        self.frame_46.setObjectName(u"frame_46")
        sizePolicy4.setHeightForWidth(self.frame_46.sizePolicy().hasHeightForWidth())
        self.frame_46.setSizePolicy(sizePolicy4)
        self.frame_46.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_46.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_32 = QVBoxLayout(self.frame_46)
        self.verticalLayout_32.setObjectName(u"verticalLayout_32")
        self.frame_50 = QFrame(self.frame_46)
        self.frame_50.setObjectName(u"frame_50")
        self.frame_50.setStyleSheet(u"")
        self.frame_50.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_50.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_32 = QHBoxLayout(self.frame_50)
        self.horizontalLayout_32.setObjectName(u"horizontalLayout_32")
        self.checkBox_10 = QCheckBox(self.frame_50)
        self.checkBox_10.setObjectName(u"checkBox_10")
        self.checkBox_10.setEnabled(True)
        self.checkBox_10.setFont(font4)
        self.checkBox_10.setAutoFillBackground(False)
        self.checkBox_10.setIconSize(QSize(30, 30))
        self.checkBox_10.setCheckable(True)
        self.checkBox_10.setTristate(False)

        self.horizontalLayout_32.addWidget(self.checkBox_10)


        self.verticalLayout_32.addWidget(self.frame_50)

        self.frame_49 = QFrame(self.frame_46)
        self.frame_49.setObjectName(u"frame_49")
        self.frame_49.setStyleSheet(u"")
        self.frame_49.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_49.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_31 = QHBoxLayout(self.frame_49)
        self.horizontalLayout_31.setObjectName(u"horizontalLayout_31")
        self.checkBox_9 = QCheckBox(self.frame_49)
        self.checkBox_9.setObjectName(u"checkBox_9")
        self.checkBox_9.setEnabled(True)
        self.checkBox_9.setFont(font4)
        self.checkBox_9.setAutoFillBackground(False)
        self.checkBox_9.setIconSize(QSize(30, 30))
        self.checkBox_9.setCheckable(True)
        self.checkBox_9.setTristate(False)

        self.horizontalLayout_31.addWidget(self.checkBox_9)


        self.verticalLayout_32.addWidget(self.frame_49)

        self.frame_48 = QFrame(self.frame_46)
        self.frame_48.setObjectName(u"frame_48")
        self.frame_48.setStyleSheet(u"")
        self.frame_48.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_48.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_29 = QHBoxLayout(self.frame_48)
        self.horizontalLayout_29.setObjectName(u"horizontalLayout_29")
        self.checkBox_8 = QCheckBox(self.frame_48)
        self.checkBox_8.setObjectName(u"checkBox_8")
        self.checkBox_8.setEnabled(True)
        self.checkBox_8.setFont(font4)
        self.checkBox_8.setAutoFillBackground(False)
        self.checkBox_8.setIconSize(QSize(30, 30))
        self.checkBox_8.setCheckable(True)
        self.checkBox_8.setChecked(True)
        self.checkBox_8.setTristate(False)

        self.horizontalLayout_29.addWidget(self.checkBox_8)


        self.verticalLayout_32.addWidget(self.frame_48)


        self.verticalLayout_25.addWidget(self.frame_46, 0, Qt.AlignmentFlag.AlignHCenter)

        self.frame_36 = QFrame(self.frame_35)
        self.frame_36.setObjectName(u"frame_36")
        self.frame_36.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_36.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_36.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_23 = QHBoxLayout(self.frame_36)
        self.horizontalLayout_23.setObjectName(u"horizontalLayout_23")
        self.model_installed_3 = QCheckBox(self.frame_36)
        self.model_installed_3.setObjectName(u"model_installed_3")
        self.model_installed_3.setEnabled(False)
        self.model_installed_3.setFont(font4)
        self.model_installed_3.setAutoFillBackground(False)
        self.model_installed_3.setIconSize(QSize(30, 30))
        self.model_installed_3.setCheckable(False)
        self.model_installed_3.setTristate(False)

        self.horizontalLayout_23.addWidget(self.model_installed_3)


        self.verticalLayout_25.addWidget(self.frame_36)

        self.frame_37 = QFrame(self.frame_35)
        self.frame_37.setObjectName(u"frame_37")
        self.frame_37.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_37.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_37.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_24 = QHBoxLayout(self.frame_37)
        self.horizontalLayout_24.setObjectName(u"horizontalLayout_24")
        self.checkpoints_downloaded_3 = QCheckBox(self.frame_37)
        self.checkpoints_downloaded_3.setObjectName(u"checkpoints_downloaded_3")
        self.checkpoints_downloaded_3.setEnabled(False)
        self.checkpoints_downloaded_3.setFont(font4)
        self.checkpoints_downloaded_3.setAutoFillBackground(False)
        self.checkpoints_downloaded_3.setIconSize(QSize(30, 30))
        self.checkpoints_downloaded_3.setCheckable(False)
        self.checkpoints_downloaded_3.setTristate(False)

        self.horizontalLayout_24.addWidget(self.checkpoints_downloaded_3)


        self.verticalLayout_25.addWidget(self.frame_37)


        self.horizontalLayout_22.addWidget(self.frame_35)


        self.verticalLayout_21.addWidget(self.frame_33)


        self.horizontalLayout_19.addWidget(self.frame_30)

        self.frame_38 = QFrame(self.frame_29)
        self.frame_38.setObjectName(u"frame_38")
        sizePolicy1.setHeightForWidth(self.frame_38.sizePolicy().hasHeightForWidth())
        self.frame_38.setSizePolicy(sizePolicy1)
        self.frame_38.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_38.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_26 = QVBoxLayout(self.frame_38)
        self.verticalLayout_26.setObjectName(u"verticalLayout_26")
        self.widget_9 = QWidget(self.frame_38)
        self.widget_9.setObjectName(u"widget_9")
        sizePolicy3.setHeightForWidth(self.widget_9.sizePolicy().hasHeightForWidth())
        self.widget_9.setSizePolicy(sizePolicy3)
        self.widget_9.setMinimumSize(QSize(0, 50))
        self.horizontalLayout_25 = QHBoxLayout(self.widget_9)
        self.horizontalLayout_25.setObjectName(u"horizontalLayout_25")
        self.label_25 = QLabel(self.widget_9)
        self.label_25.setObjectName(u"label_25")
        self.label_25.setFont(font2)

        self.horizontalLayout_25.addWidget(self.label_25)

        self.frame_39 = QFrame(self.widget_9)
        self.frame_39.setObjectName(u"frame_39")
        sizePolicy4.setHeightForWidth(self.frame_39.sizePolicy().hasHeightForWidth())
        self.frame_39.setSizePolicy(sizePolicy4)
        self.frame_39.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_39.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_26 = QHBoxLayout(self.frame_39)
        self.horizontalLayout_26.setObjectName(u"horizontalLayout_26")
        self.label_26 = QLabel(self.frame_39)
        self.label_26.setObjectName(u"label_26")
        self.label_26.setFont(font2)

        self.horizontalLayout_26.addWidget(self.label_26)

        self.pushButton_6 = QPushButton(self.frame_39)
        self.pushButton_6.setObjectName(u"pushButton_6")
        self.pushButton_6.setMinimumSize(QSize(30, 30))
        self.pushButton_6.setMaximumSize(QSize(40, 40))
        self.pushButton_6.setIcon(icon1)
        self.pushButton_6.setIconSize(QSize(30, 30))

        self.horizontalLayout_26.addWidget(self.pushButton_6)


        self.horizontalLayout_25.addWidget(self.frame_39)


        self.verticalLayout_26.addWidget(self.widget_9)

        self.textEdit_3 = QTextEdit(self.frame_38)
        self.textEdit_3.setObjectName(u"textEdit_3")
        sizePolicy5.setHeightForWidth(self.textEdit_3.sizePolicy().hasHeightForWidth())
        self.textEdit_3.setSizePolicy(sizePolicy5)
        self.textEdit_3.setStyleSheet(u"background-color: rgb(229, 229, 229);")
        self.textEdit_3.setReadOnly(True)

        self.verticalLayout_26.addWidget(self.textEdit_3)


        self.horizontalLayout_19.addWidget(self.frame_38)


        self.verticalLayout_29.addWidget(self.frame_29)

        self.tabWidget.addTab(self.tab_3, "")
        self.tab_4 = QWidget()
        self.tab_4.setObjectName(u"tab_4")
        self.verticalLayout_39 = QVBoxLayout(self.tab_4)
        self.verticalLayout_39.setObjectName(u"verticalLayout_39")
        self.frame_43 = QFrame(self.tab_4)
        self.frame_43.setObjectName(u"frame_43")
        sizePolicy.setHeightForWidth(self.frame_43.sizePolicy().hasHeightForWidth())
        self.frame_43.setSizePolicy(sizePolicy)
        self.frame_43.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_43.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_27 = QHBoxLayout(self.frame_43)
        self.horizontalLayout_27.setObjectName(u"horizontalLayout_27")
        self.frame_44 = QFrame(self.frame_43)
        self.frame_44.setObjectName(u"frame_44")
        sizePolicy1.setHeightForWidth(self.frame_44.sizePolicy().hasHeightForWidth())
        self.frame_44.setSizePolicy(sizePolicy1)
        self.frame_44.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_44.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_30 = QVBoxLayout(self.frame_44)
        self.verticalLayout_30.setObjectName(u"verticalLayout_30")
        self.frame_45 = QFrame(self.frame_44)
        self.frame_45.setObjectName(u"frame_45")
        self.frame_45.setStyleSheet(u"background-color: rgb(177, 177, 177);")
        self.frame_45.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_45.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_31 = QVBoxLayout(self.frame_45)
        self.verticalLayout_31.setObjectName(u"verticalLayout_31")
        self.frame_47 = QFrame(self.frame_45)
        self.frame_47.setObjectName(u"frame_47")
        self.frame_47.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_47.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_28 = QHBoxLayout(self.frame_47)
        self.horizontalLayout_28.setObjectName(u"horizontalLayout_28")
        self.label_31 = QLabel(self.frame_47)
        self.label_31.setObjectName(u"label_31")
        self.label_31.setFont(font5)
        self.label_31.setTextFormat(Qt.TextFormat.PlainText)
        self.label_31.setScaledContents(False)

        self.horizontalLayout_28.addWidget(self.label_31)

        self.label_32 = QLabel(self.frame_47)
        self.label_32.setObjectName(u"label_32")
        self.label_32.setFont(font2)

        self.horizontalLayout_28.addWidget(self.label_32)


        self.verticalLayout_31.addWidget(self.frame_47)

        self.widget_10 = QWidget(self.frame_45)
        self.widget_10.setObjectName(u"widget_10")
        sizePolicy2.setHeightForWidth(self.widget_10.sizePolicy().hasHeightForWidth())
        self.widget_10.setSizePolicy(sizePolicy2)
        self.horizontalLayout_33 = QHBoxLayout(self.widget_10)
        self.horizontalLayout_33.setObjectName(u"horizontalLayout_33")
        self.pushButton_7 = QPushButton(self.widget_10)
        self.pushButton_7.setObjectName(u"pushButton_7")
        self.pushButton_7.setMinimumSize(QSize(46, 46))
        self.pushButton_7.setMaximumSize(QSize(60, 16777215))
        self.pushButton_7.setIcon(icon)
        self.pushButton_7.setIconSize(QSize(30, 30))

        self.horizontalLayout_33.addWidget(self.pushButton_7)

        self.label_33 = QLabel(self.widget_10)
        self.label_33.setObjectName(u"label_33")
        self.label_33.setMinimumSize(QSize(2, 33))
        self.label_33.setMaximumSize(QSize(16777215, 33))
        self.label_33.setStyleSheet(u"background-color: rgb(220,220, 220);")

        self.horizontalLayout_33.addWidget(self.label_33)


        self.verticalLayout_31.addWidget(self.widget_10)


        self.verticalLayout_30.addWidget(self.frame_45)

        self.frame_51 = QFrame(self.frame_44)
        self.frame_51.setObjectName(u"frame_51")
        self.frame_51.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_51.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_34 = QHBoxLayout(self.frame_51)
        self.horizontalLayout_34.setObjectName(u"horizontalLayout_34")
        self.frame_52 = QFrame(self.frame_51)
        self.frame_52.setObjectName(u"frame_52")
        self.frame_52.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_52.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_52.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_33 = QVBoxLayout(self.frame_52)
        self.verticalLayout_33.setObjectName(u"verticalLayout_33")
        self.label_34 = QLabel(self.frame_52)
        self.label_34.setObjectName(u"label_34")
        self.label_34.setFont(font2)

        self.verticalLayout_33.addWidget(self.label_34, 0, Qt.AlignmentFlag.AlignHCenter)

        self.widget_11 = QWidget(self.frame_52)
        self.widget_11.setObjectName(u"widget_11")
        sizePolicy2.setHeightForWidth(self.widget_11.sizePolicy().hasHeightForWidth())
        self.widget_11.setSizePolicy(sizePolicy2)
        self.widget_11.setStyleSheet(u"background-color: rgb(140, 140, 140);")
        self.verticalLayout_34 = QVBoxLayout(self.widget_11)
        self.verticalLayout_34.setObjectName(u"verticalLayout_34")
        self.radioButton_7 = QRadioButton(self.widget_11)
        self.radioButton_7.setObjectName(u"radioButton_7")
        self.radioButton_7.setFont(font3)

        self.verticalLayout_34.addWidget(self.radioButton_7)

        self.radioButton_8 = QRadioButton(self.widget_11)
        self.radioButton_8.setObjectName(u"radioButton_8")
        self.radioButton_8.setFont(font3)

        self.verticalLayout_34.addWidget(self.radioButton_8)


        self.verticalLayout_33.addWidget(self.widget_11)


        self.horizontalLayout_34.addWidget(self.frame_52)

        self.frame_53 = QFrame(self.frame_51)
        self.frame_53.setObjectName(u"frame_53")
        sizePolicy1.setHeightForWidth(self.frame_53.sizePolicy().hasHeightForWidth())
        self.frame_53.setSizePolicy(sizePolicy1)
        self.frame_53.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_53.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_35 = QVBoxLayout(self.frame_53)
        self.verticalLayout_35.setObjectName(u"verticalLayout_35")
        self.frame_54 = QFrame(self.frame_53)
        self.frame_54.setObjectName(u"frame_54")
        self.frame_54.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_54.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_54.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_35 = QHBoxLayout(self.frame_54)
        self.horizontalLayout_35.setObjectName(u"horizontalLayout_35")
        self.model_installed_4 = QCheckBox(self.frame_54)
        self.model_installed_4.setObjectName(u"model_installed_4")
        self.model_installed_4.setEnabled(False)
        self.model_installed_4.setFont(font4)
        self.model_installed_4.setAutoFillBackground(False)
        self.model_installed_4.setIconSize(QSize(30, 30))
        self.model_installed_4.setCheckable(False)
        self.model_installed_4.setTristate(False)

        self.horizontalLayout_35.addWidget(self.model_installed_4)


        self.verticalLayout_35.addWidget(self.frame_54)

        self.frame_55 = QFrame(self.frame_53)
        self.frame_55.setObjectName(u"frame_55")
        self.frame_55.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_55.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_55.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_36 = QHBoxLayout(self.frame_55)
        self.horizontalLayout_36.setObjectName(u"horizontalLayout_36")
        self.checkpoints_downloaded_4 = QCheckBox(self.frame_55)
        self.checkpoints_downloaded_4.setObjectName(u"checkpoints_downloaded_4")
        self.checkpoints_downloaded_4.setEnabled(False)
        self.checkpoints_downloaded_4.setFont(font4)
        self.checkpoints_downloaded_4.setAutoFillBackground(False)
        self.checkpoints_downloaded_4.setIconSize(QSize(30, 30))
        self.checkpoints_downloaded_4.setCheckable(False)
        self.checkpoints_downloaded_4.setTristate(False)

        self.horizontalLayout_36.addWidget(self.checkpoints_downloaded_4)


        self.verticalLayout_35.addWidget(self.frame_55)


        self.horizontalLayout_34.addWidget(self.frame_53)


        self.verticalLayout_30.addWidget(self.frame_51)


        self.horizontalLayout_27.addWidget(self.frame_44)

        self.frame_56 = QFrame(self.frame_43)
        self.frame_56.setObjectName(u"frame_56")
        sizePolicy1.setHeightForWidth(self.frame_56.sizePolicy().hasHeightForWidth())
        self.frame_56.setSizePolicy(sizePolicy1)
        self.frame_56.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_56.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_36 = QVBoxLayout(self.frame_56)
        self.verticalLayout_36.setObjectName(u"verticalLayout_36")
        self.widget_12 = QWidget(self.frame_56)
        self.widget_12.setObjectName(u"widget_12")
        sizePolicy3.setHeightForWidth(self.widget_12.sizePolicy().hasHeightForWidth())
        self.widget_12.setSizePolicy(sizePolicy3)
        self.widget_12.setMinimumSize(QSize(0, 50))
        self.horizontalLayout_37 = QHBoxLayout(self.widget_12)
        self.horizontalLayout_37.setObjectName(u"horizontalLayout_37")
        self.label_35 = QLabel(self.widget_12)
        self.label_35.setObjectName(u"label_35")
        self.label_35.setFont(font2)

        self.horizontalLayout_37.addWidget(self.label_35)

        self.frame_57 = QFrame(self.widget_12)
        self.frame_57.setObjectName(u"frame_57")
        sizePolicy4.setHeightForWidth(self.frame_57.sizePolicy().hasHeightForWidth())
        self.frame_57.setSizePolicy(sizePolicy4)
        self.frame_57.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_57.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_38 = QHBoxLayout(self.frame_57)
        self.horizontalLayout_38.setObjectName(u"horizontalLayout_38")
        self.label_36 = QLabel(self.frame_57)
        self.label_36.setObjectName(u"label_36")
        self.label_36.setFont(font2)

        self.horizontalLayout_38.addWidget(self.label_36)

        self.pushButton_8 = QPushButton(self.frame_57)
        self.pushButton_8.setObjectName(u"pushButton_8")
        self.pushButton_8.setMinimumSize(QSize(30, 30))
        self.pushButton_8.setMaximumSize(QSize(40, 40))
        self.pushButton_8.setIcon(icon1)
        self.pushButton_8.setIconSize(QSize(30, 30))

        self.horizontalLayout_38.addWidget(self.pushButton_8)


        self.horizontalLayout_37.addWidget(self.frame_57)


        self.verticalLayout_36.addWidget(self.widget_12)

        self.textEdit_4 = QTextEdit(self.frame_56)
        self.textEdit_4.setObjectName(u"textEdit_4")
        sizePolicy5.setHeightForWidth(self.textEdit_4.sizePolicy().hasHeightForWidth())
        self.textEdit_4.setSizePolicy(sizePolicy5)
        self.textEdit_4.setStyleSheet(u"background-color: rgb(229, 229, 229);")
        self.textEdit_4.setReadOnly(True)

        self.verticalLayout_36.addWidget(self.textEdit_4)


        self.horizontalLayout_27.addWidget(self.frame_56)


        self.verticalLayout_39.addWidget(self.frame_43)

        self.tabWidget.addTab(self.tab_4, "")
        self.tab_5 = QWidget()
        self.tab_5.setObjectName(u"tab_5")
        self.verticalLayout_2 = QVBoxLayout(self.tab_5)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.frame_61 = QFrame(self.tab_5)
        self.frame_61.setObjectName(u"frame_61")
        sizePolicy.setHeightForWidth(self.frame_61.sizePolicy().hasHeightForWidth())
        self.frame_61.setSizePolicy(sizePolicy)
        self.frame_61.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_61.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_40 = QHBoxLayout(self.frame_61)
        self.horizontalLayout_40.setObjectName(u"horizontalLayout_40")
        self.frame_62 = QFrame(self.frame_61)
        self.frame_62.setObjectName(u"frame_62")
        sizePolicy1.setHeightForWidth(self.frame_62.sizePolicy().hasHeightForWidth())
        self.frame_62.setSizePolicy(sizePolicy1)
        self.frame_62.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_62.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_40 = QVBoxLayout(self.frame_62)
        self.verticalLayout_40.setObjectName(u"verticalLayout_40")
        self.frame_63 = QFrame(self.frame_62)
        self.frame_63.setObjectName(u"frame_63")
        self.frame_63.setStyleSheet(u"background-color: rgb(177, 177, 177);")
        self.frame_63.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_63.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_41 = QVBoxLayout(self.frame_63)
        self.verticalLayout_41.setObjectName(u"verticalLayout_41")
        self.frame_64 = QFrame(self.frame_63)
        self.frame_64.setObjectName(u"frame_64")
        self.frame_64.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_64.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_41 = QHBoxLayout(self.frame_64)
        self.horizontalLayout_41.setObjectName(u"horizontalLayout_41")
        self.label_41 = QLabel(self.frame_64)
        self.label_41.setObjectName(u"label_41")
        self.label_41.setFont(font5)
        self.label_41.setTextFormat(Qt.TextFormat.PlainText)
        self.label_41.setScaledContents(False)

        self.horizontalLayout_41.addWidget(self.label_41)

        self.label_42 = QLabel(self.frame_64)
        self.label_42.setObjectName(u"label_42")
        self.label_42.setFont(font2)

        self.horizontalLayout_41.addWidget(self.label_42)


        self.verticalLayout_41.addWidget(self.frame_64)

        self.widget_13 = QWidget(self.frame_63)
        self.widget_13.setObjectName(u"widget_13")
        sizePolicy2.setHeightForWidth(self.widget_13.sizePolicy().hasHeightForWidth())
        self.widget_13.setSizePolicy(sizePolicy2)
        self.horizontalLayout_42 = QHBoxLayout(self.widget_13)
        self.horizontalLayout_42.setObjectName(u"horizontalLayout_42")
        self.pushButton_9 = QPushButton(self.widget_13)
        self.pushButton_9.setObjectName(u"pushButton_9")
        self.pushButton_9.setMinimumSize(QSize(46, 46))
        self.pushButton_9.setMaximumSize(QSize(60, 16777215))
        self.pushButton_9.setIcon(icon)
        self.pushButton_9.setIconSize(QSize(30, 30))

        self.horizontalLayout_42.addWidget(self.pushButton_9)

        self.label_43 = QLabel(self.widget_13)
        self.label_43.setObjectName(u"label_43")
        self.label_43.setMinimumSize(QSize(2, 33))
        self.label_43.setMaximumSize(QSize(16777215, 33))
        self.label_43.setStyleSheet(u"background-color: rgb(220,220, 220);")

        self.horizontalLayout_42.addWidget(self.label_43)


        self.verticalLayout_41.addWidget(self.widget_13)


        self.verticalLayout_40.addWidget(self.frame_63)

        self.frame_65 = QFrame(self.frame_62)
        self.frame_65.setObjectName(u"frame_65")
        self.frame_65.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_65.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_43 = QHBoxLayout(self.frame_65)
        self.horizontalLayout_43.setObjectName(u"horizontalLayout_43")
        self.frame_66 = QFrame(self.frame_65)
        self.frame_66.setObjectName(u"frame_66")
        self.frame_66.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_66.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_66.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_42 = QVBoxLayout(self.frame_66)
        self.verticalLayout_42.setObjectName(u"verticalLayout_42")
        self.label_44 = QLabel(self.frame_66)
        self.label_44.setObjectName(u"label_44")
        self.label_44.setFont(font2)

        self.verticalLayout_42.addWidget(self.label_44, 0, Qt.AlignmentFlag.AlignHCenter)

        self.widget_14 = QWidget(self.frame_66)
        self.widget_14.setObjectName(u"widget_14")
        sizePolicy2.setHeightForWidth(self.widget_14.sizePolicy().hasHeightForWidth())
        self.widget_14.setSizePolicy(sizePolicy2)
        self.widget_14.setStyleSheet(u"background-color: rgb(140, 140, 140);")
        self.verticalLayout_43 = QVBoxLayout(self.widget_14)
        self.verticalLayout_43.setObjectName(u"verticalLayout_43")
        self.radioButton_9 = QRadioButton(self.widget_14)
        self.radioButton_9.setObjectName(u"radioButton_9")
        self.radioButton_9.setFont(font3)

        self.verticalLayout_43.addWidget(self.radioButton_9)

        self.radioButton_10 = QRadioButton(self.widget_14)
        self.radioButton_10.setObjectName(u"radioButton_10")
        self.radioButton_10.setFont(font3)

        self.verticalLayout_43.addWidget(self.radioButton_10)


        self.verticalLayout_42.addWidget(self.widget_14)


        self.horizontalLayout_43.addWidget(self.frame_66)

        self.frame_67 = QFrame(self.frame_65)
        self.frame_67.setObjectName(u"frame_67")
        sizePolicy1.setHeightForWidth(self.frame_67.sizePolicy().hasHeightForWidth())
        self.frame_67.setSizePolicy(sizePolicy1)
        self.frame_67.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_67.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_44 = QVBoxLayout(self.frame_67)
        self.verticalLayout_44.setObjectName(u"verticalLayout_44")
        self.frame_68 = QFrame(self.frame_67)
        self.frame_68.setObjectName(u"frame_68")
        self.frame_68.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_68.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_68.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_44 = QHBoxLayout(self.frame_68)
        self.horizontalLayout_44.setObjectName(u"horizontalLayout_44")
        self.model_installed_5 = QCheckBox(self.frame_68)
        self.model_installed_5.setObjectName(u"model_installed_5")
        self.model_installed_5.setEnabled(False)
        self.model_installed_5.setFont(font4)
        self.model_installed_5.setAutoFillBackground(False)
        self.model_installed_5.setIconSize(QSize(30, 30))
        self.model_installed_5.setCheckable(False)
        self.model_installed_5.setTristate(False)

        self.horizontalLayout_44.addWidget(self.model_installed_5)


        self.verticalLayout_44.addWidget(self.frame_68)

        self.frame_69 = QFrame(self.frame_67)
        self.frame_69.setObjectName(u"frame_69")
        self.frame_69.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_69.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_69.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_45 = QHBoxLayout(self.frame_69)
        self.horizontalLayout_45.setObjectName(u"horizontalLayout_45")
        self.checkpoints_downloaded_5 = QCheckBox(self.frame_69)
        self.checkpoints_downloaded_5.setObjectName(u"checkpoints_downloaded_5")
        self.checkpoints_downloaded_5.setEnabled(False)
        self.checkpoints_downloaded_5.setFont(font4)
        self.checkpoints_downloaded_5.setAutoFillBackground(False)
        self.checkpoints_downloaded_5.setIconSize(QSize(30, 30))
        self.checkpoints_downloaded_5.setCheckable(False)
        self.checkpoints_downloaded_5.setTristate(False)

        self.horizontalLayout_45.addWidget(self.checkpoints_downloaded_5)


        self.verticalLayout_44.addWidget(self.frame_69)


        self.horizontalLayout_43.addWidget(self.frame_67)


        self.verticalLayout_40.addWidget(self.frame_65)


        self.horizontalLayout_40.addWidget(self.frame_62)

        self.frame_70 = QFrame(self.frame_61)
        self.frame_70.setObjectName(u"frame_70")
        sizePolicy1.setHeightForWidth(self.frame_70.sizePolicy().hasHeightForWidth())
        self.frame_70.setSizePolicy(sizePolicy1)
        self.frame_70.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_70.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_45 = QVBoxLayout(self.frame_70)
        self.verticalLayout_45.setObjectName(u"verticalLayout_45")
        self.widget_15 = QWidget(self.frame_70)
        self.widget_15.setObjectName(u"widget_15")
        sizePolicy3.setHeightForWidth(self.widget_15.sizePolicy().hasHeightForWidth())
        self.widget_15.setSizePolicy(sizePolicy3)
        self.widget_15.setMinimumSize(QSize(0, 50))
        self.horizontalLayout_46 = QHBoxLayout(self.widget_15)
        self.horizontalLayout_46.setObjectName(u"horizontalLayout_46")
        self.label_45 = QLabel(self.widget_15)
        self.label_45.setObjectName(u"label_45")
        self.label_45.setFont(font2)

        self.horizontalLayout_46.addWidget(self.label_45)

        self.frame_71 = QFrame(self.widget_15)
        self.frame_71.setObjectName(u"frame_71")
        sizePolicy4.setHeightForWidth(self.frame_71.sizePolicy().hasHeightForWidth())
        self.frame_71.setSizePolicy(sizePolicy4)
        self.frame_71.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_71.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_47 = QHBoxLayout(self.frame_71)
        self.horizontalLayout_47.setObjectName(u"horizontalLayout_47")
        self.label_46 = QLabel(self.frame_71)
        self.label_46.setObjectName(u"label_46")
        self.label_46.setFont(font2)

        self.horizontalLayout_47.addWidget(self.label_46)

        self.pushButton_10 = QPushButton(self.frame_71)
        self.pushButton_10.setObjectName(u"pushButton_10")
        self.pushButton_10.setMinimumSize(QSize(30, 30))
        self.pushButton_10.setMaximumSize(QSize(40, 40))
        self.pushButton_10.setIcon(icon1)
        self.pushButton_10.setIconSize(QSize(30, 30))

        self.horizontalLayout_47.addWidget(self.pushButton_10)


        self.horizontalLayout_46.addWidget(self.frame_71)


        self.verticalLayout_45.addWidget(self.widget_15)

        self.textEdit_5 = QTextEdit(self.frame_70)
        self.textEdit_5.setObjectName(u"textEdit_5")
        sizePolicy5.setHeightForWidth(self.textEdit_5.sizePolicy().hasHeightForWidth())
        self.textEdit_5.setSizePolicy(sizePolicy5)
        self.textEdit_5.setStyleSheet(u"background-color: rgb(229, 229, 229);")
        self.textEdit_5.setReadOnly(True)

        self.verticalLayout_45.addWidget(self.textEdit_5)


        self.horizontalLayout_40.addWidget(self.frame_70)


        self.verticalLayout_2.addWidget(self.frame_61)

        self.tabWidget.addTab(self.tab_5, "")
        self.tab_6 = QWidget()
        self.tab_6.setObjectName(u"tab_6")
        self.verticalLayout_8 = QVBoxLayout(self.tab_6)
        self.verticalLayout_8.setObjectName(u"verticalLayout_8")
        self.frame_72 = QFrame(self.tab_6)
        self.frame_72.setObjectName(u"frame_72")
        sizePolicy.setHeightForWidth(self.frame_72.sizePolicy().hasHeightForWidth())
        self.frame_72.setSizePolicy(sizePolicy)
        self.frame_72.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_72.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_48 = QHBoxLayout(self.frame_72)
        self.horizontalLayout_48.setObjectName(u"horizontalLayout_48")
        self.frame_73 = QFrame(self.frame_72)
        self.frame_73.setObjectName(u"frame_73")
        sizePolicy1.setHeightForWidth(self.frame_73.sizePolicy().hasHeightForWidth())
        self.frame_73.setSizePolicy(sizePolicy1)
        self.frame_73.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_73.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_46 = QVBoxLayout(self.frame_73)
        self.verticalLayout_46.setObjectName(u"verticalLayout_46")
        self.frame_74 = QFrame(self.frame_73)
        self.frame_74.setObjectName(u"frame_74")
        self.frame_74.setStyleSheet(u"background-color: rgb(177, 177, 177);")
        self.frame_74.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_74.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_47 = QVBoxLayout(self.frame_74)
        self.verticalLayout_47.setObjectName(u"verticalLayout_47")
        self.frame_75 = QFrame(self.frame_74)
        self.frame_75.setObjectName(u"frame_75")
        self.frame_75.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_75.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_49 = QHBoxLayout(self.frame_75)
        self.horizontalLayout_49.setObjectName(u"horizontalLayout_49")
        self.label_47 = QLabel(self.frame_75)
        self.label_47.setObjectName(u"label_47")
        self.label_47.setFont(font5)
        self.label_47.setTextFormat(Qt.TextFormat.PlainText)
        self.label_47.setScaledContents(False)

        self.horizontalLayout_49.addWidget(self.label_47)

        self.label_48 = QLabel(self.frame_75)
        self.label_48.setObjectName(u"label_48")
        self.label_48.setFont(font2)

        self.horizontalLayout_49.addWidget(self.label_48)


        self.verticalLayout_47.addWidget(self.frame_75)

        self.widget_16 = QWidget(self.frame_74)
        self.widget_16.setObjectName(u"widget_16")
        sizePolicy2.setHeightForWidth(self.widget_16.sizePolicy().hasHeightForWidth())
        self.widget_16.setSizePolicy(sizePolicy2)
        self.horizontalLayout_50 = QHBoxLayout(self.widget_16)
        self.horizontalLayout_50.setObjectName(u"horizontalLayout_50")
        self.pushButton_11 = QPushButton(self.widget_16)
        self.pushButton_11.setObjectName(u"pushButton_11")
        self.pushButton_11.setMinimumSize(QSize(46, 46))
        self.pushButton_11.setMaximumSize(QSize(60, 16777215))
        self.pushButton_11.setIcon(icon)
        self.pushButton_11.setIconSize(QSize(30, 30))

        self.horizontalLayout_50.addWidget(self.pushButton_11)

        self.label_49 = QLabel(self.widget_16)
        self.label_49.setObjectName(u"label_49")
        self.label_49.setMinimumSize(QSize(2, 33))
        self.label_49.setMaximumSize(QSize(16777215, 33))
        self.label_49.setStyleSheet(u"background-color: rgb(220,220, 220);")

        self.horizontalLayout_50.addWidget(self.label_49)


        self.verticalLayout_47.addWidget(self.widget_16)


        self.verticalLayout_46.addWidget(self.frame_74)

        self.frame_76 = QFrame(self.frame_73)
        self.frame_76.setObjectName(u"frame_76")
        self.frame_76.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_76.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_51 = QHBoxLayout(self.frame_76)
        self.horizontalLayout_51.setObjectName(u"horizontalLayout_51")
        self.frame_77 = QFrame(self.frame_76)
        self.frame_77.setObjectName(u"frame_77")
        self.frame_77.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_77.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_77.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_48 = QVBoxLayout(self.frame_77)
        self.verticalLayout_48.setObjectName(u"verticalLayout_48")
        self.label_50 = QLabel(self.frame_77)
        self.label_50.setObjectName(u"label_50")
        self.label_50.setFont(font2)

        self.verticalLayout_48.addWidget(self.label_50, 0, Qt.AlignmentFlag.AlignHCenter)

        self.widget_17 = QWidget(self.frame_77)
        self.widget_17.setObjectName(u"widget_17")
        sizePolicy2.setHeightForWidth(self.widget_17.sizePolicy().hasHeightForWidth())
        self.widget_17.setSizePolicy(sizePolicy2)
        self.widget_17.setStyleSheet(u"background-color: rgb(140, 140, 140);")
        self.verticalLayout_49 = QVBoxLayout(self.widget_17)
        self.verticalLayout_49.setObjectName(u"verticalLayout_49")
        self.radioButton_11 = QRadioButton(self.widget_17)
        self.radioButton_11.setObjectName(u"radioButton_11")
        self.radioButton_11.setFont(font3)

        self.verticalLayout_49.addWidget(self.radioButton_11)

        self.radioButton_12 = QRadioButton(self.widget_17)
        self.radioButton_12.setObjectName(u"radioButton_12")
        self.radioButton_12.setFont(font3)

        self.verticalLayout_49.addWidget(self.radioButton_12)


        self.verticalLayout_48.addWidget(self.widget_17)


        self.horizontalLayout_51.addWidget(self.frame_77)

        self.frame_78 = QFrame(self.frame_76)
        self.frame_78.setObjectName(u"frame_78")
        sizePolicy1.setHeightForWidth(self.frame_78.sizePolicy().hasHeightForWidth())
        self.frame_78.setSizePolicy(sizePolicy1)
        self.frame_78.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_78.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_50 = QVBoxLayout(self.frame_78)
        self.verticalLayout_50.setObjectName(u"verticalLayout_50")
        self.frame_79 = QFrame(self.frame_78)
        self.frame_79.setObjectName(u"frame_79")
        self.frame_79.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_79.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_79.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_52 = QHBoxLayout(self.frame_79)
        self.horizontalLayout_52.setObjectName(u"horizontalLayout_52")
        self.model_installed_6 = QCheckBox(self.frame_79)
        self.model_installed_6.setObjectName(u"model_installed_6")
        self.model_installed_6.setEnabled(False)
        self.model_installed_6.setFont(font4)
        self.model_installed_6.setAutoFillBackground(False)
        self.model_installed_6.setIconSize(QSize(30, 30))
        self.model_installed_6.setCheckable(False)
        self.model_installed_6.setTristate(False)

        self.horizontalLayout_52.addWidget(self.model_installed_6)


        self.verticalLayout_50.addWidget(self.frame_79)

        self.frame_80 = QFrame(self.frame_78)
        self.frame_80.setObjectName(u"frame_80")
        self.frame_80.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_80.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_80.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_53 = QHBoxLayout(self.frame_80)
        self.horizontalLayout_53.setObjectName(u"horizontalLayout_53")
        self.checkpoints_downloaded_6 = QCheckBox(self.frame_80)
        self.checkpoints_downloaded_6.setObjectName(u"checkpoints_downloaded_6")
        self.checkpoints_downloaded_6.setEnabled(False)
        self.checkpoints_downloaded_6.setFont(font4)
        self.checkpoints_downloaded_6.setAutoFillBackground(False)
        self.checkpoints_downloaded_6.setIconSize(QSize(30, 30))
        self.checkpoints_downloaded_6.setCheckable(False)
        self.checkpoints_downloaded_6.setTristate(False)

        self.horizontalLayout_53.addWidget(self.checkpoints_downloaded_6)


        self.verticalLayout_50.addWidget(self.frame_80)


        self.horizontalLayout_51.addWidget(self.frame_78)


        self.verticalLayout_46.addWidget(self.frame_76)


        self.horizontalLayout_48.addWidget(self.frame_73)

        self.frame_81 = QFrame(self.frame_72)
        self.frame_81.setObjectName(u"frame_81")
        sizePolicy1.setHeightForWidth(self.frame_81.sizePolicy().hasHeightForWidth())
        self.frame_81.setSizePolicy(sizePolicy1)
        self.frame_81.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_81.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_51 = QVBoxLayout(self.frame_81)
        self.verticalLayout_51.setObjectName(u"verticalLayout_51")
        self.widget_18 = QWidget(self.frame_81)
        self.widget_18.setObjectName(u"widget_18")
        sizePolicy3.setHeightForWidth(self.widget_18.sizePolicy().hasHeightForWidth())
        self.widget_18.setSizePolicy(sizePolicy3)
        self.widget_18.setMinimumSize(QSize(0, 50))
        self.horizontalLayout_54 = QHBoxLayout(self.widget_18)
        self.horizontalLayout_54.setObjectName(u"horizontalLayout_54")
        self.label_51 = QLabel(self.widget_18)
        self.label_51.setObjectName(u"label_51")
        self.label_51.setFont(font2)

        self.horizontalLayout_54.addWidget(self.label_51)

        self.frame_82 = QFrame(self.widget_18)
        self.frame_82.setObjectName(u"frame_82")
        sizePolicy4.setHeightForWidth(self.frame_82.sizePolicy().hasHeightForWidth())
        self.frame_82.setSizePolicy(sizePolicy4)
        self.frame_82.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_82.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_55 = QHBoxLayout(self.frame_82)
        self.horizontalLayout_55.setObjectName(u"horizontalLayout_55")
        self.label_52 = QLabel(self.frame_82)
        self.label_52.setObjectName(u"label_52")
        self.label_52.setFont(font2)

        self.horizontalLayout_55.addWidget(self.label_52)

        self.pushButton_12 = QPushButton(self.frame_82)
        self.pushButton_12.setObjectName(u"pushButton_12")
        self.pushButton_12.setMinimumSize(QSize(30, 30))
        self.pushButton_12.setMaximumSize(QSize(40, 40))
        self.pushButton_12.setIcon(icon1)
        self.pushButton_12.setIconSize(QSize(30, 30))

        self.horizontalLayout_55.addWidget(self.pushButton_12)


        self.horizontalLayout_54.addWidget(self.frame_82)


        self.verticalLayout_51.addWidget(self.widget_18)

        self.textEdit_6 = QTextEdit(self.frame_81)
        self.textEdit_6.setObjectName(u"textEdit_6")
        sizePolicy5.setHeightForWidth(self.textEdit_6.sizePolicy().hasHeightForWidth())
        self.textEdit_6.setSizePolicy(sizePolicy5)
        self.textEdit_6.setStyleSheet(u"background-color: rgb(229, 229, 229);")
        self.textEdit_6.setReadOnly(True)

        self.verticalLayout_51.addWidget(self.textEdit_6)


        self.horizontalLayout_48.addWidget(self.frame_81)


        self.verticalLayout_8.addWidget(self.frame_72)

        self.tabWidget.addTab(self.tab_6, "")
        self.tab_7 = QWidget()
        self.tab_7.setObjectName(u"tab_7")
        self.verticalLayout_9 = QVBoxLayout(self.tab_7)
        self.verticalLayout_9.setObjectName(u"verticalLayout_9")
        self.frame_40 = QFrame(self.tab_7)
        self.frame_40.setObjectName(u"frame_40")
        sizePolicy.setHeightForWidth(self.frame_40.sizePolicy().hasHeightForWidth())
        self.frame_40.setSizePolicy(sizePolicy)
        self.frame_40.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_40.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_30 = QHBoxLayout(self.frame_40)
        self.horizontalLayout_30.setObjectName(u"horizontalLayout_30")
        self.frame_41 = QFrame(self.frame_40)
        self.frame_41.setObjectName(u"frame_41")
        sizePolicy1.setHeightForWidth(self.frame_41.sizePolicy().hasHeightForWidth())
        self.frame_41.setSizePolicy(sizePolicy1)
        self.frame_41.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_41.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_27 = QVBoxLayout(self.frame_41)
        self.verticalLayout_27.setObjectName(u"verticalLayout_27")
        self.frame_42 = QFrame(self.frame_41)
        self.frame_42.setObjectName(u"frame_42")
        self.frame_42.setStyleSheet(u"background-color: rgb(177, 177, 177);")
        self.frame_42.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_42.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_28 = QVBoxLayout(self.frame_42)
        self.verticalLayout_28.setObjectName(u"verticalLayout_28")
        self.frame_58 = QFrame(self.frame_42)
        self.frame_58.setObjectName(u"frame_58")
        self.frame_58.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_58.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_39 = QHBoxLayout(self.frame_58)
        self.horizontalLayout_39.setObjectName(u"horizontalLayout_39")
        self.label_27 = QLabel(self.frame_58)
        self.label_27.setObjectName(u"label_27")
        self.label_27.setFont(font5)
        self.label_27.setTextFormat(Qt.TextFormat.PlainText)
        self.label_27.setScaledContents(False)

        self.horizontalLayout_39.addWidget(self.label_27)

        self.label_28 = QLabel(self.frame_58)
        self.label_28.setObjectName(u"label_28")
        self.label_28.setFont(font2)

        self.horizontalLayout_39.addWidget(self.label_28)


        self.verticalLayout_28.addWidget(self.frame_58)

        self.widget_19 = QWidget(self.frame_42)
        self.widget_19.setObjectName(u"widget_19")
        sizePolicy2.setHeightForWidth(self.widget_19.sizePolicy().hasHeightForWidth())
        self.widget_19.setSizePolicy(sizePolicy2)
        self.horizontalLayout_56 = QHBoxLayout(self.widget_19)
        self.horizontalLayout_56.setObjectName(u"horizontalLayout_56")
        self.pushButton_13 = QPushButton(self.widget_19)
        self.pushButton_13.setObjectName(u"pushButton_13")
        self.pushButton_13.setMinimumSize(QSize(46, 46))
        self.pushButton_13.setMaximumSize(QSize(60, 16777215))
        self.pushButton_13.setIcon(icon)
        self.pushButton_13.setIconSize(QSize(30, 30))

        self.horizontalLayout_56.addWidget(self.pushButton_13)

        self.label_29 = QLabel(self.widget_19)
        self.label_29.setObjectName(u"label_29")
        self.label_29.setMinimumSize(QSize(2, 33))
        self.label_29.setMaximumSize(QSize(16777215, 33))
        self.label_29.setStyleSheet(u"background-color: rgb(220,220, 220);")

        self.horizontalLayout_56.addWidget(self.label_29)


        self.verticalLayout_28.addWidget(self.widget_19)


        self.verticalLayout_27.addWidget(self.frame_42)

        self.frame_59 = QFrame(self.frame_41)
        self.frame_59.setObjectName(u"frame_59")
        self.frame_59.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_59.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_57 = QHBoxLayout(self.frame_59)
        self.horizontalLayout_57.setObjectName(u"horizontalLayout_57")
        self.frame_60 = QFrame(self.frame_59)
        self.frame_60.setObjectName(u"frame_60")
        self.frame_60.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_60.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_60.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_37 = QVBoxLayout(self.frame_60)
        self.verticalLayout_37.setObjectName(u"verticalLayout_37")
        self.label_30 = QLabel(self.frame_60)
        self.label_30.setObjectName(u"label_30")
        self.label_30.setFont(font2)

        self.verticalLayout_37.addWidget(self.label_30, 0, Qt.AlignmentFlag.AlignHCenter)

        self.widget_20 = QWidget(self.frame_60)
        self.widget_20.setObjectName(u"widget_20")
        sizePolicy2.setHeightForWidth(self.widget_20.sizePolicy().hasHeightForWidth())
        self.widget_20.setSizePolicy(sizePolicy2)
        self.widget_20.setStyleSheet(u"background-color: rgb(140, 140, 140);")
        self.verticalLayout_38 = QVBoxLayout(self.widget_20)
        self.verticalLayout_38.setObjectName(u"verticalLayout_38")
        self.radioButton_13 = QRadioButton(self.widget_20)
        self.radioButton_13.setObjectName(u"radioButton_13")
        self.radioButton_13.setFont(font3)

        self.verticalLayout_38.addWidget(self.radioButton_13)

        self.radioButton_14 = QRadioButton(self.widget_20)
        self.radioButton_14.setObjectName(u"radioButton_14")
        self.radioButton_14.setFont(font3)

        self.verticalLayout_38.addWidget(self.radioButton_14)


        self.verticalLayout_37.addWidget(self.widget_20)


        self.horizontalLayout_57.addWidget(self.frame_60)

        self.frame_83 = QFrame(self.frame_59)
        self.frame_83.setObjectName(u"frame_83")
        sizePolicy1.setHeightForWidth(self.frame_83.sizePolicy().hasHeightForWidth())
        self.frame_83.setSizePolicy(sizePolicy1)
        self.frame_83.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_83.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_52 = QVBoxLayout(self.frame_83)
        self.verticalLayout_52.setObjectName(u"verticalLayout_52")
        self.frame_84 = QFrame(self.frame_83)
        self.frame_84.setObjectName(u"frame_84")
        sizePolicy4.setHeightForWidth(self.frame_84.sizePolicy().hasHeightForWidth())
        self.frame_84.setSizePolicy(sizePolicy4)
        self.frame_84.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_84.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_53 = QVBoxLayout(self.frame_84)
        self.verticalLayout_53.setObjectName(u"verticalLayout_53")
        self.radioButton_15 = QRadioButton(self.frame_84)
        self.radioButton_15.setObjectName(u"radioButton_15")

        self.verticalLayout_53.addWidget(self.radioButton_15)

        self.radioButton_16 = QRadioButton(self.frame_84)
        self.radioButton_16.setObjectName(u"radioButton_16")

        self.verticalLayout_53.addWidget(self.radioButton_16)

        self.radioButton_17 = QRadioButton(self.frame_84)
        self.radioButton_17.setObjectName(u"radioButton_17")

        self.verticalLayout_53.addWidget(self.radioButton_17)


        self.verticalLayout_52.addWidget(self.frame_84, 0, Qt.AlignmentFlag.AlignHCenter)

        self.frame_88 = QFrame(self.frame_83)
        self.frame_88.setObjectName(u"frame_88")
        self.frame_88.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_88.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_88.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_61 = QHBoxLayout(self.frame_88)
        self.horizontalLayout_61.setObjectName(u"horizontalLayout_61")
        self.model_installed_7 = QCheckBox(self.frame_88)
        self.model_installed_7.setObjectName(u"model_installed_7")
        self.model_installed_7.setEnabled(False)
        self.model_installed_7.setFont(font4)
        self.model_installed_7.setAutoFillBackground(False)
        self.model_installed_7.setIconSize(QSize(30, 30))
        self.model_installed_7.setCheckable(False)
        self.model_installed_7.setTristate(False)

        self.horizontalLayout_61.addWidget(self.model_installed_7)


        self.verticalLayout_52.addWidget(self.frame_88)

        self.frame_89 = QFrame(self.frame_83)
        self.frame_89.setObjectName(u"frame_89")
        self.frame_89.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_89.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_89.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_62 = QHBoxLayout(self.frame_89)
        self.horizontalLayout_62.setObjectName(u"horizontalLayout_62")
        self.checkpoints_downloaded_7 = QCheckBox(self.frame_89)
        self.checkpoints_downloaded_7.setObjectName(u"checkpoints_downloaded_7")
        self.checkpoints_downloaded_7.setEnabled(False)
        self.checkpoints_downloaded_7.setFont(font4)
        self.checkpoints_downloaded_7.setAutoFillBackground(False)
        self.checkpoints_downloaded_7.setIconSize(QSize(30, 30))
        self.checkpoints_downloaded_7.setCheckable(False)
        self.checkpoints_downloaded_7.setTristate(False)

        self.horizontalLayout_62.addWidget(self.checkpoints_downloaded_7)


        self.verticalLayout_52.addWidget(self.frame_89)


        self.horizontalLayout_57.addWidget(self.frame_83)


        self.verticalLayout_27.addWidget(self.frame_59)


        self.horizontalLayout_30.addWidget(self.frame_41)

        self.frame_90 = QFrame(self.frame_40)
        self.frame_90.setObjectName(u"frame_90")
        sizePolicy1.setHeightForWidth(self.frame_90.sizePolicy().hasHeightForWidth())
        self.frame_90.setSizePolicy(sizePolicy1)
        self.frame_90.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_90.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_54 = QVBoxLayout(self.frame_90)
        self.verticalLayout_54.setObjectName(u"verticalLayout_54")
        self.widget_21 = QWidget(self.frame_90)
        self.widget_21.setObjectName(u"widget_21")
        sizePolicy3.setHeightForWidth(self.widget_21.sizePolicy().hasHeightForWidth())
        self.widget_21.setSizePolicy(sizePolicy3)
        self.widget_21.setMinimumSize(QSize(0, 50))
        self.horizontalLayout_63 = QHBoxLayout(self.widget_21)
        self.horizontalLayout_63.setObjectName(u"horizontalLayout_63")
        self.label_37 = QLabel(self.widget_21)
        self.label_37.setObjectName(u"label_37")
        self.label_37.setFont(font2)

        self.horizontalLayout_63.addWidget(self.label_37)

        self.frame_91 = QFrame(self.widget_21)
        self.frame_91.setObjectName(u"frame_91")
        sizePolicy4.setHeightForWidth(self.frame_91.sizePolicy().hasHeightForWidth())
        self.frame_91.setSizePolicy(sizePolicy4)
        self.frame_91.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_91.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_64 = QHBoxLayout(self.frame_91)
        self.horizontalLayout_64.setObjectName(u"horizontalLayout_64")
        self.label_38 = QLabel(self.frame_91)
        self.label_38.setObjectName(u"label_38")
        self.label_38.setFont(font2)

        self.horizontalLayout_64.addWidget(self.label_38)

        self.pushButton_14 = QPushButton(self.frame_91)
        self.pushButton_14.setObjectName(u"pushButton_14")
        self.pushButton_14.setMinimumSize(QSize(30, 30))
        self.pushButton_14.setMaximumSize(QSize(40, 40))
        self.pushButton_14.setIcon(icon1)
        self.pushButton_14.setIconSize(QSize(30, 30))

        self.horizontalLayout_64.addWidget(self.pushButton_14)


        self.horizontalLayout_63.addWidget(self.frame_91)


        self.verticalLayout_54.addWidget(self.widget_21)

        self.textEdit_7 = QTextEdit(self.frame_90)
        self.textEdit_7.setObjectName(u"textEdit_7")
        sizePolicy5.setHeightForWidth(self.textEdit_7.sizePolicy().hasHeightForWidth())
        self.textEdit_7.setSizePolicy(sizePolicy5)
        self.textEdit_7.setStyleSheet(u"background-color: rgb(229, 229, 229);")
        self.textEdit_7.setReadOnly(True)

        self.verticalLayout_54.addWidget(self.textEdit_7)


        self.horizontalLayout_30.addWidget(self.frame_90)


        self.verticalLayout_9.addWidget(self.frame_40)

        self.tabWidget.addTab(self.tab_7, "")
        self.tab_8 = QWidget()
        self.tab_8.setObjectName(u"tab_8")
        self.verticalLayout_18 = QVBoxLayout(self.tab_8)
        self.verticalLayout_18.setObjectName(u"verticalLayout_18")
        self.frame_85 = QFrame(self.tab_8)
        self.frame_85.setObjectName(u"frame_85")
        sizePolicy.setHeightForWidth(self.frame_85.sizePolicy().hasHeightForWidth())
        self.frame_85.setSizePolicy(sizePolicy)
        self.frame_85.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_85.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_58 = QHBoxLayout(self.frame_85)
        self.horizontalLayout_58.setObjectName(u"horizontalLayout_58")
        self.frame_86 = QFrame(self.frame_85)
        self.frame_86.setObjectName(u"frame_86")
        sizePolicy1.setHeightForWidth(self.frame_86.sizePolicy().hasHeightForWidth())
        self.frame_86.setSizePolicy(sizePolicy1)
        self.frame_86.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_86.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_55 = QVBoxLayout(self.frame_86)
        self.verticalLayout_55.setObjectName(u"verticalLayout_55")
        self.frame_87 = QFrame(self.frame_86)
        self.frame_87.setObjectName(u"frame_87")
        self.frame_87.setStyleSheet(u"background-color: rgb(177, 177, 177);")
        self.frame_87.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_87.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_56 = QVBoxLayout(self.frame_87)
        self.verticalLayout_56.setObjectName(u"verticalLayout_56")
        self.frame_92 = QFrame(self.frame_87)
        self.frame_92.setObjectName(u"frame_92")
        self.frame_92.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_92.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_59 = QHBoxLayout(self.frame_92)
        self.horizontalLayout_59.setObjectName(u"horizontalLayout_59")
        self.label_53 = QLabel(self.frame_92)
        self.label_53.setObjectName(u"label_53")
        self.label_53.setFont(font5)
        self.label_53.setTextFormat(Qt.TextFormat.PlainText)
        self.label_53.setScaledContents(False)

        self.horizontalLayout_59.addWidget(self.label_53)

        self.label_54 = QLabel(self.frame_92)
        self.label_54.setObjectName(u"label_54")
        self.label_54.setFont(font2)

        self.horizontalLayout_59.addWidget(self.label_54)


        self.verticalLayout_56.addWidget(self.frame_92)

        self.widget_22 = QWidget(self.frame_87)
        self.widget_22.setObjectName(u"widget_22")
        sizePolicy2.setHeightForWidth(self.widget_22.sizePolicy().hasHeightForWidth())
        self.widget_22.setSizePolicy(sizePolicy2)
        self.horizontalLayout_60 = QHBoxLayout(self.widget_22)
        self.horizontalLayout_60.setObjectName(u"horizontalLayout_60")
        self.pushButton_15 = QPushButton(self.widget_22)
        self.pushButton_15.setObjectName(u"pushButton_15")
        self.pushButton_15.setMinimumSize(QSize(46, 46))
        self.pushButton_15.setMaximumSize(QSize(60, 16777215))
        self.pushButton_15.setIcon(icon)
        self.pushButton_15.setIconSize(QSize(30, 30))

        self.horizontalLayout_60.addWidget(self.pushButton_15)

        self.label_55 = QLabel(self.widget_22)
        self.label_55.setObjectName(u"label_55")
        self.label_55.setMinimumSize(QSize(2, 33))
        self.label_55.setMaximumSize(QSize(16777215, 33))
        self.label_55.setStyleSheet(u"background-color: rgb(220,220, 220);")

        self.horizontalLayout_60.addWidget(self.label_55)


        self.verticalLayout_56.addWidget(self.widget_22)


        self.verticalLayout_55.addWidget(self.frame_87)

        self.frame_93 = QFrame(self.frame_86)
        self.frame_93.setObjectName(u"frame_93")
        self.frame_93.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_93.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_65 = QHBoxLayout(self.frame_93)
        self.horizontalLayout_65.setObjectName(u"horizontalLayout_65")
        self.frame_94 = QFrame(self.frame_93)
        self.frame_94.setObjectName(u"frame_94")
        self.frame_94.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_94.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_94.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_57 = QVBoxLayout(self.frame_94)
        self.verticalLayout_57.setObjectName(u"verticalLayout_57")
        self.label_56 = QLabel(self.frame_94)
        self.label_56.setObjectName(u"label_56")
        self.label_56.setFont(font2)

        self.verticalLayout_57.addWidget(self.label_56, 0, Qt.AlignmentFlag.AlignHCenter)

        self.widget_23 = QWidget(self.frame_94)
        self.widget_23.setObjectName(u"widget_23")
        sizePolicy2.setHeightForWidth(self.widget_23.sizePolicy().hasHeightForWidth())
        self.widget_23.setSizePolicy(sizePolicy2)
        self.widget_23.setStyleSheet(u"background-color: rgb(140, 140, 140);")
        self.verticalLayout_58 = QVBoxLayout(self.widget_23)
        self.verticalLayout_58.setObjectName(u"verticalLayout_58")
        self.radioButton_18 = QRadioButton(self.widget_23)
        self.radioButton_18.setObjectName(u"radioButton_18")
        self.radioButton_18.setFont(font3)

        self.verticalLayout_58.addWidget(self.radioButton_18)

        self.radioButton_19 = QRadioButton(self.widget_23)
        self.radioButton_19.setObjectName(u"radioButton_19")
        self.radioButton_19.setFont(font3)

        self.verticalLayout_58.addWidget(self.radioButton_19)


        self.verticalLayout_57.addWidget(self.widget_23)


        self.horizontalLayout_65.addWidget(self.frame_94)

        self.frame_95 = QFrame(self.frame_93)
        self.frame_95.setObjectName(u"frame_95")
        sizePolicy1.setHeightForWidth(self.frame_95.sizePolicy().hasHeightForWidth())
        self.frame_95.setSizePolicy(sizePolicy1)
        self.frame_95.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_95.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_59 = QVBoxLayout(self.frame_95)
        self.verticalLayout_59.setObjectName(u"verticalLayout_59")
        self.frame_96 = QFrame(self.frame_95)
        self.frame_96.setObjectName(u"frame_96")
        self.frame_96.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_96.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_96.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_66 = QHBoxLayout(self.frame_96)
        self.horizontalLayout_66.setObjectName(u"horizontalLayout_66")
        self.model_installed_8 = QCheckBox(self.frame_96)
        self.model_installed_8.setObjectName(u"model_installed_8")
        self.model_installed_8.setEnabled(False)
        self.model_installed_8.setFont(font4)
        self.model_installed_8.setAutoFillBackground(False)
        self.model_installed_8.setIconSize(QSize(30, 30))
        self.model_installed_8.setCheckable(False)
        self.model_installed_8.setTristate(False)

        self.horizontalLayout_66.addWidget(self.model_installed_8)


        self.verticalLayout_59.addWidget(self.frame_96)

        self.frame_97 = QFrame(self.frame_95)
        self.frame_97.setObjectName(u"frame_97")
        self.frame_97.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_97.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_97.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_67 = QHBoxLayout(self.frame_97)
        self.horizontalLayout_67.setObjectName(u"horizontalLayout_67")
        self.checkpoints_downloaded_8 = QCheckBox(self.frame_97)
        self.checkpoints_downloaded_8.setObjectName(u"checkpoints_downloaded_8")
        self.checkpoints_downloaded_8.setEnabled(False)
        self.checkpoints_downloaded_8.setFont(font4)
        self.checkpoints_downloaded_8.setAutoFillBackground(False)
        self.checkpoints_downloaded_8.setIconSize(QSize(30, 30))
        self.checkpoints_downloaded_8.setCheckable(False)
        self.checkpoints_downloaded_8.setTristate(False)

        self.horizontalLayout_67.addWidget(self.checkpoints_downloaded_8)


        self.verticalLayout_59.addWidget(self.frame_97)


        self.horizontalLayout_65.addWidget(self.frame_95)


        self.verticalLayout_55.addWidget(self.frame_93)


        self.horizontalLayout_58.addWidget(self.frame_86)

        self.frame_98 = QFrame(self.frame_85)
        self.frame_98.setObjectName(u"frame_98")
        sizePolicy1.setHeightForWidth(self.frame_98.sizePolicy().hasHeightForWidth())
        self.frame_98.setSizePolicy(sizePolicy1)
        self.frame_98.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_98.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_60 = QVBoxLayout(self.frame_98)
        self.verticalLayout_60.setObjectName(u"verticalLayout_60")
        self.widget_24 = QWidget(self.frame_98)
        self.widget_24.setObjectName(u"widget_24")
        sizePolicy3.setHeightForWidth(self.widget_24.sizePolicy().hasHeightForWidth())
        self.widget_24.setSizePolicy(sizePolicy3)
        self.widget_24.setMinimumSize(QSize(0, 50))
        self.horizontalLayout_68 = QHBoxLayout(self.widget_24)
        self.horizontalLayout_68.setObjectName(u"horizontalLayout_68")
        self.label_57 = QLabel(self.widget_24)
        self.label_57.setObjectName(u"label_57")
        self.label_57.setFont(font2)

        self.horizontalLayout_68.addWidget(self.label_57)

        self.frame_99 = QFrame(self.widget_24)
        self.frame_99.setObjectName(u"frame_99")
        sizePolicy4.setHeightForWidth(self.frame_99.sizePolicy().hasHeightForWidth())
        self.frame_99.setSizePolicy(sizePolicy4)
        self.frame_99.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_99.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_69 = QHBoxLayout(self.frame_99)
        self.horizontalLayout_69.setObjectName(u"horizontalLayout_69")
        self.label_58 = QLabel(self.frame_99)
        self.label_58.setObjectName(u"label_58")
        self.label_58.setFont(font2)

        self.horizontalLayout_69.addWidget(self.label_58)

        self.pushButton_16 = QPushButton(self.frame_99)
        self.pushButton_16.setObjectName(u"pushButton_16")
        self.pushButton_16.setMinimumSize(QSize(30, 30))
        self.pushButton_16.setMaximumSize(QSize(40, 40))
        self.pushButton_16.setIcon(icon1)
        self.pushButton_16.setIconSize(QSize(30, 30))

        self.horizontalLayout_69.addWidget(self.pushButton_16)


        self.horizontalLayout_68.addWidget(self.frame_99)


        self.verticalLayout_60.addWidget(self.widget_24)

        self.textEdit_8 = QTextEdit(self.frame_98)
        self.textEdit_8.setObjectName(u"textEdit_8")
        sizePolicy5.setHeightForWidth(self.textEdit_8.sizePolicy().hasHeightForWidth())
        self.textEdit_8.setSizePolicy(sizePolicy5)
        self.textEdit_8.setStyleSheet(u"background-color: rgb(229, 229, 229);")
        self.textEdit_8.setReadOnly(True)

        self.verticalLayout_60.addWidget(self.textEdit_8)


        self.horizontalLayout_58.addWidget(self.frame_98)


        self.verticalLayout_18.addWidget(self.frame_85)

        self.tabWidget.addTab(self.tab_8, "")
        self.tab_9 = QWidget()
        self.tab_9.setObjectName(u"tab_9")
        self.verticalLayout_19 = QVBoxLayout(self.tab_9)
        self.verticalLayout_19.setObjectName(u"verticalLayout_19")
        self.frame_100 = QFrame(self.tab_9)
        self.frame_100.setObjectName(u"frame_100")
        sizePolicy.setHeightForWidth(self.frame_100.sizePolicy().hasHeightForWidth())
        self.frame_100.setSizePolicy(sizePolicy)
        self.frame_100.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_100.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_70 = QHBoxLayout(self.frame_100)
        self.horizontalLayout_70.setObjectName(u"horizontalLayout_70")
        self.frame_101 = QFrame(self.frame_100)
        self.frame_101.setObjectName(u"frame_101")
        sizePolicy1.setHeightForWidth(self.frame_101.sizePolicy().hasHeightForWidth())
        self.frame_101.setSizePolicy(sizePolicy1)
        self.frame_101.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_101.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_61 = QVBoxLayout(self.frame_101)
        self.verticalLayout_61.setObjectName(u"verticalLayout_61")
        self.frame_102 = QFrame(self.frame_101)
        self.frame_102.setObjectName(u"frame_102")
        self.frame_102.setStyleSheet(u"background-color: rgb(177, 177, 177);")
        self.frame_102.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_102.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_62 = QVBoxLayout(self.frame_102)
        self.verticalLayout_62.setObjectName(u"verticalLayout_62")
        self.frame_103 = QFrame(self.frame_102)
        self.frame_103.setObjectName(u"frame_103")
        self.frame_103.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_103.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_71 = QHBoxLayout(self.frame_103)
        self.horizontalLayout_71.setObjectName(u"horizontalLayout_71")
        self.label_39 = QLabel(self.frame_103)
        self.label_39.setObjectName(u"label_39")
        self.label_39.setFont(font5)
        self.label_39.setTextFormat(Qt.TextFormat.PlainText)
        self.label_39.setScaledContents(False)

        self.horizontalLayout_71.addWidget(self.label_39)

        self.label_40 = QLabel(self.frame_103)
        self.label_40.setObjectName(u"label_40")
        self.label_40.setFont(font2)

        self.horizontalLayout_71.addWidget(self.label_40)


        self.verticalLayout_62.addWidget(self.frame_103)

        self.widget_25 = QWidget(self.frame_102)
        self.widget_25.setObjectName(u"widget_25")
        sizePolicy2.setHeightForWidth(self.widget_25.sizePolicy().hasHeightForWidth())
        self.widget_25.setSizePolicy(sizePolicy2)
        self.horizontalLayout_72 = QHBoxLayout(self.widget_25)
        self.horizontalLayout_72.setObjectName(u"horizontalLayout_72")
        self.pushButton_17 = QPushButton(self.widget_25)
        self.pushButton_17.setObjectName(u"pushButton_17")
        self.pushButton_17.setMinimumSize(QSize(46, 46))
        self.pushButton_17.setMaximumSize(QSize(60, 16777215))
        self.pushButton_17.setIcon(icon)
        self.pushButton_17.setIconSize(QSize(30, 30))

        self.horizontalLayout_72.addWidget(self.pushButton_17)

        self.label_59 = QLabel(self.widget_25)
        self.label_59.setObjectName(u"label_59")
        self.label_59.setMinimumSize(QSize(2, 33))
        self.label_59.setMaximumSize(QSize(16777215, 33))
        self.label_59.setStyleSheet(u"background-color: rgb(220,220, 220);")

        self.horizontalLayout_72.addWidget(self.label_59)


        self.verticalLayout_62.addWidget(self.widget_25)


        self.verticalLayout_61.addWidget(self.frame_102)

        self.frame_104 = QFrame(self.frame_101)
        self.frame_104.setObjectName(u"frame_104")
        self.frame_104.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_104.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_73 = QHBoxLayout(self.frame_104)
        self.horizontalLayout_73.setObjectName(u"horizontalLayout_73")
        self.frame_105 = QFrame(self.frame_104)
        self.frame_105.setObjectName(u"frame_105")
        self.frame_105.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_105.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_105.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_63 = QVBoxLayout(self.frame_105)
        self.verticalLayout_63.setObjectName(u"verticalLayout_63")
        self.label_60 = QLabel(self.frame_105)
        self.label_60.setObjectName(u"label_60")
        self.label_60.setFont(font2)

        self.verticalLayout_63.addWidget(self.label_60, 0, Qt.AlignmentFlag.AlignHCenter)

        self.widget_26 = QWidget(self.frame_105)
        self.widget_26.setObjectName(u"widget_26")
        sizePolicy2.setHeightForWidth(self.widget_26.sizePolicy().hasHeightForWidth())
        self.widget_26.setSizePolicy(sizePolicy2)
        self.widget_26.setStyleSheet(u"background-color: rgb(140, 140, 140);")
        self.verticalLayout_64 = QVBoxLayout(self.widget_26)
        self.verticalLayout_64.setObjectName(u"verticalLayout_64")
        self.radioButton_20 = QRadioButton(self.widget_26)
        self.radioButton_20.setObjectName(u"radioButton_20")
        self.radioButton_20.setFont(font3)

        self.verticalLayout_64.addWidget(self.radioButton_20)

        self.radioButton_21 = QRadioButton(self.widget_26)
        self.radioButton_21.setObjectName(u"radioButton_21")
        self.radioButton_21.setFont(font3)

        self.verticalLayout_64.addWidget(self.radioButton_21)


        self.verticalLayout_63.addWidget(self.widget_26)


        self.horizontalLayout_73.addWidget(self.frame_105)

        self.frame_106 = QFrame(self.frame_104)
        self.frame_106.setObjectName(u"frame_106")
        sizePolicy1.setHeightForWidth(self.frame_106.sizePolicy().hasHeightForWidth())
        self.frame_106.setSizePolicy(sizePolicy1)
        self.frame_106.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_106.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_65 = QVBoxLayout(self.frame_106)
        self.verticalLayout_65.setObjectName(u"verticalLayout_65")
        self.frame_107 = QFrame(self.frame_106)
        self.frame_107.setObjectName(u"frame_107")
        sizePolicy4.setHeightForWidth(self.frame_107.sizePolicy().hasHeightForWidth())
        self.frame_107.setSizePolicy(sizePolicy4)
        self.frame_107.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_107.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_66 = QVBoxLayout(self.frame_107)
        self.verticalLayout_66.setObjectName(u"verticalLayout_66")
        self.radioButton_22 = QRadioButton(self.frame_107)
        self.radioButton_22.setObjectName(u"radioButton_22")

        self.verticalLayout_66.addWidget(self.radioButton_22)

        self.radioButton_23 = QRadioButton(self.frame_107)
        self.radioButton_23.setObjectName(u"radioButton_23")

        self.verticalLayout_66.addWidget(self.radioButton_23)

        self.radioButton_25 = QRadioButton(self.frame_107)
        self.radioButton_25.setObjectName(u"radioButton_25")

        self.verticalLayout_66.addWidget(self.radioButton_25)

        self.radioButton_26 = QRadioButton(self.frame_107)
        self.radioButton_26.setObjectName(u"radioButton_26")

        self.verticalLayout_66.addWidget(self.radioButton_26)

        self.radioButton_27 = QRadioButton(self.frame_107)
        self.radioButton_27.setObjectName(u"radioButton_27")

        self.verticalLayout_66.addWidget(self.radioButton_27)

        self.radioButton_28 = QRadioButton(self.frame_107)
        self.radioButton_28.setObjectName(u"radioButton_28")

        self.verticalLayout_66.addWidget(self.radioButton_28)


        self.verticalLayout_65.addWidget(self.frame_107, 0, Qt.AlignmentFlag.AlignHCenter)

        self.frame_108 = QFrame(self.frame_106)
        self.frame_108.setObjectName(u"frame_108")
        self.frame_108.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_108.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_108.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_74 = QHBoxLayout(self.frame_108)
        self.horizontalLayout_74.setObjectName(u"horizontalLayout_74")
        self.model_installed_9 = QCheckBox(self.frame_108)
        self.model_installed_9.setObjectName(u"model_installed_9")
        self.model_installed_9.setEnabled(False)
        self.model_installed_9.setFont(font4)
        self.model_installed_9.setAutoFillBackground(False)
        self.model_installed_9.setIconSize(QSize(30, 30))
        self.model_installed_9.setCheckable(False)
        self.model_installed_9.setTristate(False)

        self.horizontalLayout_74.addWidget(self.model_installed_9)


        self.verticalLayout_65.addWidget(self.frame_108)

        self.frame_109 = QFrame(self.frame_106)
        self.frame_109.setObjectName(u"frame_109")
        self.frame_109.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_109.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_109.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_75 = QHBoxLayout(self.frame_109)
        self.horizontalLayout_75.setObjectName(u"horizontalLayout_75")
        self.checkpoints_downloaded_9 = QCheckBox(self.frame_109)
        self.checkpoints_downloaded_9.setObjectName(u"checkpoints_downloaded_9")
        self.checkpoints_downloaded_9.setEnabled(False)
        self.checkpoints_downloaded_9.setFont(font4)
        self.checkpoints_downloaded_9.setAutoFillBackground(False)
        self.checkpoints_downloaded_9.setIconSize(QSize(30, 30))
        self.checkpoints_downloaded_9.setCheckable(False)
        self.checkpoints_downloaded_9.setTristate(False)

        self.horizontalLayout_75.addWidget(self.checkpoints_downloaded_9)


        self.verticalLayout_65.addWidget(self.frame_109)


        self.horizontalLayout_73.addWidget(self.frame_106)


        self.verticalLayout_61.addWidget(self.frame_104)


        self.horizontalLayout_70.addWidget(self.frame_101)

        self.frame_110 = QFrame(self.frame_100)
        self.frame_110.setObjectName(u"frame_110")
        sizePolicy1.setHeightForWidth(self.frame_110.sizePolicy().hasHeightForWidth())
        self.frame_110.setSizePolicy(sizePolicy1)
        self.frame_110.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_110.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_67 = QVBoxLayout(self.frame_110)
        self.verticalLayout_67.setObjectName(u"verticalLayout_67")
        self.widget_27 = QWidget(self.frame_110)
        self.widget_27.setObjectName(u"widget_27")
        sizePolicy3.setHeightForWidth(self.widget_27.sizePolicy().hasHeightForWidth())
        self.widget_27.setSizePolicy(sizePolicy3)
        self.widget_27.setMinimumSize(QSize(0, 50))
        self.horizontalLayout_76 = QHBoxLayout(self.widget_27)
        self.horizontalLayout_76.setObjectName(u"horizontalLayout_76")
        self.label_61 = QLabel(self.widget_27)
        self.label_61.setObjectName(u"label_61")
        self.label_61.setFont(font2)

        self.horizontalLayout_76.addWidget(self.label_61)

        self.frame_111 = QFrame(self.widget_27)
        self.frame_111.setObjectName(u"frame_111")
        sizePolicy4.setHeightForWidth(self.frame_111.sizePolicy().hasHeightForWidth())
        self.frame_111.setSizePolicy(sizePolicy4)
        self.frame_111.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_111.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_77 = QHBoxLayout(self.frame_111)
        self.horizontalLayout_77.setObjectName(u"horizontalLayout_77")
        self.label_62 = QLabel(self.frame_111)
        self.label_62.setObjectName(u"label_62")
        self.label_62.setFont(font2)

        self.horizontalLayout_77.addWidget(self.label_62)

        self.pushButton_18 = QPushButton(self.frame_111)
        self.pushButton_18.setObjectName(u"pushButton_18")
        self.pushButton_18.setMinimumSize(QSize(30, 30))
        self.pushButton_18.setMaximumSize(QSize(40, 40))
        self.pushButton_18.setIcon(icon1)
        self.pushButton_18.setIconSize(QSize(30, 30))

        self.horizontalLayout_77.addWidget(self.pushButton_18)


        self.horizontalLayout_76.addWidget(self.frame_111)


        self.verticalLayout_67.addWidget(self.widget_27)

        self.textEdit_9 = QTextEdit(self.frame_110)
        self.textEdit_9.setObjectName(u"textEdit_9")
        sizePolicy5.setHeightForWidth(self.textEdit_9.sizePolicy().hasHeightForWidth())
        self.textEdit_9.setSizePolicy(sizePolicy5)
        self.textEdit_9.setStyleSheet(u"background-color: rgb(229, 229, 229);")
        self.textEdit_9.setReadOnly(True)

        self.verticalLayout_67.addWidget(self.textEdit_9)


        self.horizontalLayout_70.addWidget(self.frame_110)


        self.verticalLayout_19.addWidget(self.frame_100)

        self.tabWidget.addTab(self.tab_9, "")
        self.tab_10 = QWidget()
        self.tab_10.setObjectName(u"tab_10")
        self.verticalLayout_74 = QVBoxLayout(self.tab_10)
        self.verticalLayout_74.setObjectName(u"verticalLayout_74")
        self.frame_112 = QFrame(self.tab_10)
        self.frame_112.setObjectName(u"frame_112")
        sizePolicy.setHeightForWidth(self.frame_112.sizePolicy().hasHeightForWidth())
        self.frame_112.setSizePolicy(sizePolicy)
        self.frame_112.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_112.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_78 = QHBoxLayout(self.frame_112)
        self.horizontalLayout_78.setObjectName(u"horizontalLayout_78")
        self.frame_113 = QFrame(self.frame_112)
        self.frame_113.setObjectName(u"frame_113")
        sizePolicy1.setHeightForWidth(self.frame_113.sizePolicy().hasHeightForWidth())
        self.frame_113.setSizePolicy(sizePolicy1)
        self.frame_113.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_113.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_68 = QVBoxLayout(self.frame_113)
        self.verticalLayout_68.setObjectName(u"verticalLayout_68")
        self.frame_114 = QFrame(self.frame_113)
        self.frame_114.setObjectName(u"frame_114")
        self.frame_114.setStyleSheet(u"background-color: rgb(177, 177, 177);")
        self.frame_114.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_114.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_69 = QVBoxLayout(self.frame_114)
        self.verticalLayout_69.setObjectName(u"verticalLayout_69")
        self.frame_115 = QFrame(self.frame_114)
        self.frame_115.setObjectName(u"frame_115")
        self.frame_115.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_115.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_79 = QHBoxLayout(self.frame_115)
        self.horizontalLayout_79.setObjectName(u"horizontalLayout_79")
        self.label_63 = QLabel(self.frame_115)
        self.label_63.setObjectName(u"label_63")
        self.label_63.setFont(font5)
        self.label_63.setTextFormat(Qt.TextFormat.PlainText)
        self.label_63.setScaledContents(False)

        self.horizontalLayout_79.addWidget(self.label_63)

        self.label_64 = QLabel(self.frame_115)
        self.label_64.setObjectName(u"label_64")
        self.label_64.setFont(font2)

        self.horizontalLayout_79.addWidget(self.label_64)


        self.verticalLayout_69.addWidget(self.frame_115)

        self.widget_28 = QWidget(self.frame_114)
        self.widget_28.setObjectName(u"widget_28")
        sizePolicy2.setHeightForWidth(self.widget_28.sizePolicy().hasHeightForWidth())
        self.widget_28.setSizePolicy(sizePolicy2)
        self.horizontalLayout_80 = QHBoxLayout(self.widget_28)
        self.horizontalLayout_80.setObjectName(u"horizontalLayout_80")
        self.pushButton_19 = QPushButton(self.widget_28)
        self.pushButton_19.setObjectName(u"pushButton_19")
        self.pushButton_19.setMinimumSize(QSize(46, 46))
        self.pushButton_19.setMaximumSize(QSize(60, 16777215))
        self.pushButton_19.setIcon(icon)
        self.pushButton_19.setIconSize(QSize(30, 30))

        self.horizontalLayout_80.addWidget(self.pushButton_19)

        self.label_65 = QLabel(self.widget_28)
        self.label_65.setObjectName(u"label_65")
        self.label_65.setMinimumSize(QSize(2, 33))
        self.label_65.setMaximumSize(QSize(16777215, 33))
        self.label_65.setStyleSheet(u"background-color: rgb(220,220, 220);")

        self.horizontalLayout_80.addWidget(self.label_65)


        self.verticalLayout_69.addWidget(self.widget_28)


        self.verticalLayout_68.addWidget(self.frame_114)

        self.frame_116 = QFrame(self.frame_113)
        self.frame_116.setObjectName(u"frame_116")
        self.frame_116.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_116.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_81 = QHBoxLayout(self.frame_116)
        self.horizontalLayout_81.setObjectName(u"horizontalLayout_81")
        self.frame_117 = QFrame(self.frame_116)
        self.frame_117.setObjectName(u"frame_117")
        self.frame_117.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_117.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_117.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_70 = QVBoxLayout(self.frame_117)
        self.verticalLayout_70.setObjectName(u"verticalLayout_70")
        self.label_66 = QLabel(self.frame_117)
        self.label_66.setObjectName(u"label_66")
        self.label_66.setFont(font2)

        self.verticalLayout_70.addWidget(self.label_66, 0, Qt.AlignmentFlag.AlignHCenter)

        self.widget_29 = QWidget(self.frame_117)
        self.widget_29.setObjectName(u"widget_29")
        sizePolicy2.setHeightForWidth(self.widget_29.sizePolicy().hasHeightForWidth())
        self.widget_29.setSizePolicy(sizePolicy2)
        self.widget_29.setStyleSheet(u"background-color: rgb(140, 140, 140);")
        self.verticalLayout_71 = QVBoxLayout(self.widget_29)
        self.verticalLayout_71.setObjectName(u"verticalLayout_71")
        self.radioButton_24 = QRadioButton(self.widget_29)
        self.radioButton_24.setObjectName(u"radioButton_24")
        self.radioButton_24.setFont(font3)

        self.verticalLayout_71.addWidget(self.radioButton_24)

        self.radioButton_29 = QRadioButton(self.widget_29)
        self.radioButton_29.setObjectName(u"radioButton_29")
        self.radioButton_29.setFont(font3)

        self.verticalLayout_71.addWidget(self.radioButton_29)


        self.verticalLayout_70.addWidget(self.widget_29)


        self.horizontalLayout_81.addWidget(self.frame_117)

        self.frame_118 = QFrame(self.frame_116)
        self.frame_118.setObjectName(u"frame_118")
        sizePolicy1.setHeightForWidth(self.frame_118.sizePolicy().hasHeightForWidth())
        self.frame_118.setSizePolicy(sizePolicy1)
        self.frame_118.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_118.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_72 = QVBoxLayout(self.frame_118)
        self.verticalLayout_72.setObjectName(u"verticalLayout_72")
        self.frame_119 = QFrame(self.frame_118)
        self.frame_119.setObjectName(u"frame_119")
        self.frame_119.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_119.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_119.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_82 = QHBoxLayout(self.frame_119)
        self.horizontalLayout_82.setObjectName(u"horizontalLayout_82")
        self.model_installed_10 = QCheckBox(self.frame_119)
        self.model_installed_10.setObjectName(u"model_installed_10")
        self.model_installed_10.setEnabled(False)
        self.model_installed_10.setFont(font4)
        self.model_installed_10.setAutoFillBackground(False)
        self.model_installed_10.setIconSize(QSize(30, 30))
        self.model_installed_10.setCheckable(False)
        self.model_installed_10.setTristate(False)

        self.horizontalLayout_82.addWidget(self.model_installed_10)


        self.verticalLayout_72.addWidget(self.frame_119)

        self.frame_120 = QFrame(self.frame_118)
        self.frame_120.setObjectName(u"frame_120")
        self.frame_120.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_120.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_120.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_83 = QHBoxLayout(self.frame_120)
        self.horizontalLayout_83.setObjectName(u"horizontalLayout_83")
        self.checkpoints_downloaded_10 = QCheckBox(self.frame_120)
        self.checkpoints_downloaded_10.setObjectName(u"checkpoints_downloaded_10")
        self.checkpoints_downloaded_10.setEnabled(False)
        self.checkpoints_downloaded_10.setFont(font4)
        self.checkpoints_downloaded_10.setAutoFillBackground(False)
        self.checkpoints_downloaded_10.setIconSize(QSize(30, 30))
        self.checkpoints_downloaded_10.setCheckable(False)
        self.checkpoints_downloaded_10.setTristate(False)

        self.horizontalLayout_83.addWidget(self.checkpoints_downloaded_10)


        self.verticalLayout_72.addWidget(self.frame_120)


        self.horizontalLayout_81.addWidget(self.frame_118)


        self.verticalLayout_68.addWidget(self.frame_116)


        self.horizontalLayout_78.addWidget(self.frame_113)

        self.frame_121 = QFrame(self.frame_112)
        self.frame_121.setObjectName(u"frame_121")
        sizePolicy1.setHeightForWidth(self.frame_121.sizePolicy().hasHeightForWidth())
        self.frame_121.setSizePolicy(sizePolicy1)
        self.frame_121.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_121.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_73 = QVBoxLayout(self.frame_121)
        self.verticalLayout_73.setObjectName(u"verticalLayout_73")
        self.widget_30 = QWidget(self.frame_121)
        self.widget_30.setObjectName(u"widget_30")
        sizePolicy3.setHeightForWidth(self.widget_30.sizePolicy().hasHeightForWidth())
        self.widget_30.setSizePolicy(sizePolicy3)
        self.widget_30.setMinimumSize(QSize(0, 50))
        self.horizontalLayout_84 = QHBoxLayout(self.widget_30)
        self.horizontalLayout_84.setObjectName(u"horizontalLayout_84")
        self.label_67 = QLabel(self.widget_30)
        self.label_67.setObjectName(u"label_67")
        self.label_67.setFont(font2)

        self.horizontalLayout_84.addWidget(self.label_67)

        self.frame_122 = QFrame(self.widget_30)
        self.frame_122.setObjectName(u"frame_122")
        sizePolicy4.setHeightForWidth(self.frame_122.sizePolicy().hasHeightForWidth())
        self.frame_122.setSizePolicy(sizePolicy4)
        self.frame_122.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_122.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_85 = QHBoxLayout(self.frame_122)
        self.horizontalLayout_85.setObjectName(u"horizontalLayout_85")
        self.label_68 = QLabel(self.frame_122)
        self.label_68.setObjectName(u"label_68")
        self.label_68.setFont(font2)

        self.horizontalLayout_85.addWidget(self.label_68)

        self.pushButton_20 = QPushButton(self.frame_122)
        self.pushButton_20.setObjectName(u"pushButton_20")
        self.pushButton_20.setMinimumSize(QSize(30, 30))
        self.pushButton_20.setMaximumSize(QSize(40, 40))
        self.pushButton_20.setIcon(icon1)
        self.pushButton_20.setIconSize(QSize(30, 30))

        self.horizontalLayout_85.addWidget(self.pushButton_20)


        self.horizontalLayout_84.addWidget(self.frame_122)


        self.verticalLayout_73.addWidget(self.widget_30)

        self.textEdit_10 = QTextEdit(self.frame_121)
        self.textEdit_10.setObjectName(u"textEdit_10")
        sizePolicy5.setHeightForWidth(self.textEdit_10.sizePolicy().hasHeightForWidth())
        self.textEdit_10.setSizePolicy(sizePolicy5)
        self.textEdit_10.setStyleSheet(u"background-color: rgb(229, 229, 229);")
        self.textEdit_10.setReadOnly(True)

        self.verticalLayout_73.addWidget(self.textEdit_10)


        self.horizontalLayout_78.addWidget(self.frame_121)


        self.verticalLayout_74.addWidget(self.frame_112)

        self.tabWidget.addTab(self.tab_10, "")
        self.tab_11 = QWidget()
        self.tab_11.setObjectName(u"tab_11")
        self.verticalLayout_82 = QVBoxLayout(self.tab_11)
        self.verticalLayout_82.setObjectName(u"verticalLayout_82")
        self.frame_123 = QFrame(self.tab_11)
        self.frame_123.setObjectName(u"frame_123")
        sizePolicy.setHeightForWidth(self.frame_123.sizePolicy().hasHeightForWidth())
        self.frame_123.setSizePolicy(sizePolicy)
        self.frame_123.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_123.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_86 = QHBoxLayout(self.frame_123)
        self.horizontalLayout_86.setObjectName(u"horizontalLayout_86")
        self.frame_124 = QFrame(self.frame_123)
        self.frame_124.setObjectName(u"frame_124")
        sizePolicy1.setHeightForWidth(self.frame_124.sizePolicy().hasHeightForWidth())
        self.frame_124.setSizePolicy(sizePolicy1)
        self.frame_124.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_124.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_75 = QVBoxLayout(self.frame_124)
        self.verticalLayout_75.setObjectName(u"verticalLayout_75")
        self.frame_125 = QFrame(self.frame_124)
        self.frame_125.setObjectName(u"frame_125")
        self.frame_125.setStyleSheet(u"background-color: rgb(177, 177, 177);")
        self.frame_125.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_125.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_76 = QVBoxLayout(self.frame_125)
        self.verticalLayout_76.setObjectName(u"verticalLayout_76")
        self.frame_126 = QFrame(self.frame_125)
        self.frame_126.setObjectName(u"frame_126")
        self.frame_126.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_126.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_87 = QHBoxLayout(self.frame_126)
        self.horizontalLayout_87.setObjectName(u"horizontalLayout_87")
        self.label_69 = QLabel(self.frame_126)
        self.label_69.setObjectName(u"label_69")
        self.label_69.setFont(font5)
        self.label_69.setTextFormat(Qt.TextFormat.PlainText)
        self.label_69.setScaledContents(False)

        self.horizontalLayout_87.addWidget(self.label_69)

        self.label_70 = QLabel(self.frame_126)
        self.label_70.setObjectName(u"label_70")
        self.label_70.setFont(font2)

        self.horizontalLayout_87.addWidget(self.label_70)


        self.verticalLayout_76.addWidget(self.frame_126)

        self.widget_31 = QWidget(self.frame_125)
        self.widget_31.setObjectName(u"widget_31")
        sizePolicy2.setHeightForWidth(self.widget_31.sizePolicy().hasHeightForWidth())
        self.widget_31.setSizePolicy(sizePolicy2)
        self.horizontalLayout_88 = QHBoxLayout(self.widget_31)
        self.horizontalLayout_88.setObjectName(u"horizontalLayout_88")
        self.pushButton_21 = QPushButton(self.widget_31)
        self.pushButton_21.setObjectName(u"pushButton_21")
        self.pushButton_21.setMinimumSize(QSize(46, 46))
        self.pushButton_21.setMaximumSize(QSize(60, 16777215))
        self.pushButton_21.setIcon(icon)
        self.pushButton_21.setIconSize(QSize(30, 30))

        self.horizontalLayout_88.addWidget(self.pushButton_21)

        self.label_71 = QLabel(self.widget_31)
        self.label_71.setObjectName(u"label_71")
        self.label_71.setMinimumSize(QSize(2, 33))
        self.label_71.setMaximumSize(QSize(16777215, 33))
        self.label_71.setStyleSheet(u"background-color: rgb(220,220, 220);")

        self.horizontalLayout_88.addWidget(self.label_71)


        self.verticalLayout_76.addWidget(self.widget_31)


        self.verticalLayout_75.addWidget(self.frame_125)

        self.frame_127 = QFrame(self.frame_124)
        self.frame_127.setObjectName(u"frame_127")
        self.frame_127.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_127.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_89 = QHBoxLayout(self.frame_127)
        self.horizontalLayout_89.setObjectName(u"horizontalLayout_89")
        self.frame_128 = QFrame(self.frame_127)
        self.frame_128.setObjectName(u"frame_128")
        self.frame_128.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_128.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_128.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_77 = QVBoxLayout(self.frame_128)
        self.verticalLayout_77.setObjectName(u"verticalLayout_77")
        self.label_72 = QLabel(self.frame_128)
        self.label_72.setObjectName(u"label_72")
        self.label_72.setFont(font2)

        self.verticalLayout_77.addWidget(self.label_72, 0, Qt.AlignmentFlag.AlignHCenter)

        self.widget_32 = QWidget(self.frame_128)
        self.widget_32.setObjectName(u"widget_32")
        sizePolicy2.setHeightForWidth(self.widget_32.sizePolicy().hasHeightForWidth())
        self.widget_32.setSizePolicy(sizePolicy2)
        self.widget_32.setStyleSheet(u"background-color: rgb(140, 140, 140);")
        self.verticalLayout_78 = QVBoxLayout(self.widget_32)
        self.verticalLayout_78.setObjectName(u"verticalLayout_78")
        self.radioButton_30 = QRadioButton(self.widget_32)
        self.radioButton_30.setObjectName(u"radioButton_30")
        self.radioButton_30.setFont(font3)

        self.verticalLayout_78.addWidget(self.radioButton_30)

        self.radioButton_31 = QRadioButton(self.widget_32)
        self.radioButton_31.setObjectName(u"radioButton_31")
        self.radioButton_31.setFont(font3)

        self.verticalLayout_78.addWidget(self.radioButton_31)


        self.verticalLayout_77.addWidget(self.widget_32)


        self.horizontalLayout_89.addWidget(self.frame_128)

        self.frame_129 = QFrame(self.frame_127)
        self.frame_129.setObjectName(u"frame_129")
        sizePolicy1.setHeightForWidth(self.frame_129.sizePolicy().hasHeightForWidth())
        self.frame_129.setSizePolicy(sizePolicy1)
        self.frame_129.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_129.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_79 = QVBoxLayout(self.frame_129)
        self.verticalLayout_79.setObjectName(u"verticalLayout_79")
        self.frame_130 = QFrame(self.frame_129)
        self.frame_130.setObjectName(u"frame_130")
        sizePolicy4.setHeightForWidth(self.frame_130.sizePolicy().hasHeightForWidth())
        self.frame_130.setSizePolicy(sizePolicy4)
        self.frame_130.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_130.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_80 = QVBoxLayout(self.frame_130)
        self.verticalLayout_80.setObjectName(u"verticalLayout_80")
        self.radioButton_32 = QRadioButton(self.frame_130)
        self.radioButton_32.setObjectName(u"radioButton_32")

        self.verticalLayout_80.addWidget(self.radioButton_32)

        self.radioButton_33 = QRadioButton(self.frame_130)
        self.radioButton_33.setObjectName(u"radioButton_33")

        self.verticalLayout_80.addWidget(self.radioButton_33)

        self.radioButton_34 = QRadioButton(self.frame_130)
        self.radioButton_34.setObjectName(u"radioButton_34")

        self.verticalLayout_80.addWidget(self.radioButton_34)


        self.verticalLayout_79.addWidget(self.frame_130, 0, Qt.AlignmentFlag.AlignHCenter)

        self.frame_131 = QFrame(self.frame_129)
        self.frame_131.setObjectName(u"frame_131")
        self.frame_131.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_131.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_131.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_90 = QHBoxLayout(self.frame_131)
        self.horizontalLayout_90.setObjectName(u"horizontalLayout_90")
        self.model_installed_11 = QCheckBox(self.frame_131)
        self.model_installed_11.setObjectName(u"model_installed_11")
        self.model_installed_11.setEnabled(False)
        self.model_installed_11.setFont(font4)
        self.model_installed_11.setAutoFillBackground(False)
        self.model_installed_11.setIconSize(QSize(30, 30))
        self.model_installed_11.setCheckable(False)
        self.model_installed_11.setTristate(False)

        self.horizontalLayout_90.addWidget(self.model_installed_11)


        self.verticalLayout_79.addWidget(self.frame_131)

        self.frame_132 = QFrame(self.frame_129)
        self.frame_132.setObjectName(u"frame_132")
        self.frame_132.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_132.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_132.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_91 = QHBoxLayout(self.frame_132)
        self.horizontalLayout_91.setObjectName(u"horizontalLayout_91")
        self.checkpoints_downloaded_11 = QCheckBox(self.frame_132)
        self.checkpoints_downloaded_11.setObjectName(u"checkpoints_downloaded_11")
        self.checkpoints_downloaded_11.setEnabled(False)
        self.checkpoints_downloaded_11.setFont(font4)
        self.checkpoints_downloaded_11.setAutoFillBackground(False)
        self.checkpoints_downloaded_11.setIconSize(QSize(30, 30))
        self.checkpoints_downloaded_11.setCheckable(False)
        self.checkpoints_downloaded_11.setTristate(False)

        self.horizontalLayout_91.addWidget(self.checkpoints_downloaded_11)


        self.verticalLayout_79.addWidget(self.frame_132)


        self.horizontalLayout_89.addWidget(self.frame_129)


        self.verticalLayout_75.addWidget(self.frame_127)


        self.horizontalLayout_86.addWidget(self.frame_124)

        self.frame_133 = QFrame(self.frame_123)
        self.frame_133.setObjectName(u"frame_133")
        sizePolicy1.setHeightForWidth(self.frame_133.sizePolicy().hasHeightForWidth())
        self.frame_133.setSizePolicy(sizePolicy1)
        self.frame_133.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_133.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_81 = QVBoxLayout(self.frame_133)
        self.verticalLayout_81.setObjectName(u"verticalLayout_81")
        self.widget_33 = QWidget(self.frame_133)
        self.widget_33.setObjectName(u"widget_33")
        sizePolicy3.setHeightForWidth(self.widget_33.sizePolicy().hasHeightForWidth())
        self.widget_33.setSizePolicy(sizePolicy3)
        self.widget_33.setMinimumSize(QSize(0, 50))
        self.horizontalLayout_92 = QHBoxLayout(self.widget_33)
        self.horizontalLayout_92.setObjectName(u"horizontalLayout_92")
        self.label_73 = QLabel(self.widget_33)
        self.label_73.setObjectName(u"label_73")
        self.label_73.setFont(font2)

        self.horizontalLayout_92.addWidget(self.label_73)

        self.frame_134 = QFrame(self.widget_33)
        self.frame_134.setObjectName(u"frame_134")
        sizePolicy4.setHeightForWidth(self.frame_134.sizePolicy().hasHeightForWidth())
        self.frame_134.setSizePolicy(sizePolicy4)
        self.frame_134.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_134.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_93 = QHBoxLayout(self.frame_134)
        self.horizontalLayout_93.setObjectName(u"horizontalLayout_93")
        self.label_74 = QLabel(self.frame_134)
        self.label_74.setObjectName(u"label_74")
        self.label_74.setFont(font2)

        self.horizontalLayout_93.addWidget(self.label_74)

        self.pushButton_22 = QPushButton(self.frame_134)
        self.pushButton_22.setObjectName(u"pushButton_22")
        self.pushButton_22.setMinimumSize(QSize(30, 30))
        self.pushButton_22.setMaximumSize(QSize(40, 40))
        self.pushButton_22.setIcon(icon1)
        self.pushButton_22.setIconSize(QSize(30, 30))

        self.horizontalLayout_93.addWidget(self.pushButton_22)


        self.horizontalLayout_92.addWidget(self.frame_134)


        self.verticalLayout_81.addWidget(self.widget_33)

        self.textEdit_11 = QTextEdit(self.frame_133)
        self.textEdit_11.setObjectName(u"textEdit_11")
        sizePolicy5.setHeightForWidth(self.textEdit_11.sizePolicy().hasHeightForWidth())
        self.textEdit_11.setSizePolicy(sizePolicy5)
        self.textEdit_11.setStyleSheet(u"background-color: rgb(229, 229, 229);")
        self.textEdit_11.setReadOnly(True)

        self.verticalLayout_81.addWidget(self.textEdit_11)


        self.horizontalLayout_86.addWidget(self.frame_133)


        self.verticalLayout_82.addWidget(self.frame_123)

        self.tabWidget.addTab(self.tab_11, "")
        self.tab_12 = QWidget()
        self.tab_12.setObjectName(u"tab_12")
        self.verticalLayout_90 = QVBoxLayout(self.tab_12)
        self.verticalLayout_90.setObjectName(u"verticalLayout_90")
        self.frame_135 = QFrame(self.tab_12)
        self.frame_135.setObjectName(u"frame_135")
        sizePolicy.setHeightForWidth(self.frame_135.sizePolicy().hasHeightForWidth())
        self.frame_135.setSizePolicy(sizePolicy)
        self.frame_135.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_135.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_94 = QHBoxLayout(self.frame_135)
        self.horizontalLayout_94.setObjectName(u"horizontalLayout_94")
        self.frame_136 = QFrame(self.frame_135)
        self.frame_136.setObjectName(u"frame_136")
        sizePolicy1.setHeightForWidth(self.frame_136.sizePolicy().hasHeightForWidth())
        self.frame_136.setSizePolicy(sizePolicy1)
        self.frame_136.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_136.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_83 = QVBoxLayout(self.frame_136)
        self.verticalLayout_83.setObjectName(u"verticalLayout_83")
        self.frame_137 = QFrame(self.frame_136)
        self.frame_137.setObjectName(u"frame_137")
        self.frame_137.setStyleSheet(u"background-color: rgb(177, 177, 177);")
        self.frame_137.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_137.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_84 = QVBoxLayout(self.frame_137)
        self.verticalLayout_84.setObjectName(u"verticalLayout_84")
        self.frame_138 = QFrame(self.frame_137)
        self.frame_138.setObjectName(u"frame_138")
        self.frame_138.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_138.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_95 = QHBoxLayout(self.frame_138)
        self.horizontalLayout_95.setObjectName(u"horizontalLayout_95")
        self.label_75 = QLabel(self.frame_138)
        self.label_75.setObjectName(u"label_75")
        self.label_75.setFont(font5)
        self.label_75.setTextFormat(Qt.TextFormat.PlainText)
        self.label_75.setScaledContents(False)

        self.horizontalLayout_95.addWidget(self.label_75)

        self.label_76 = QLabel(self.frame_138)
        self.label_76.setObjectName(u"label_76")
        self.label_76.setFont(font2)

        self.horizontalLayout_95.addWidget(self.label_76)


        self.verticalLayout_84.addWidget(self.frame_138)

        self.widget_34 = QWidget(self.frame_137)
        self.widget_34.setObjectName(u"widget_34")
        sizePolicy2.setHeightForWidth(self.widget_34.sizePolicy().hasHeightForWidth())
        self.widget_34.setSizePolicy(sizePolicy2)
        self.horizontalLayout_96 = QHBoxLayout(self.widget_34)
        self.horizontalLayout_96.setObjectName(u"horizontalLayout_96")
        self.pushButton_23 = QPushButton(self.widget_34)
        self.pushButton_23.setObjectName(u"pushButton_23")
        self.pushButton_23.setMinimumSize(QSize(46, 46))
        self.pushButton_23.setMaximumSize(QSize(60, 16777215))
        self.pushButton_23.setIcon(icon)
        self.pushButton_23.setIconSize(QSize(30, 30))

        self.horizontalLayout_96.addWidget(self.pushButton_23)

        self.label_77 = QLabel(self.widget_34)
        self.label_77.setObjectName(u"label_77")
        self.label_77.setMinimumSize(QSize(2, 33))
        self.label_77.setMaximumSize(QSize(16777215, 33))
        self.label_77.setStyleSheet(u"background-color: rgb(220,220, 220);")

        self.horizontalLayout_96.addWidget(self.label_77)


        self.verticalLayout_84.addWidget(self.widget_34)


        self.verticalLayout_83.addWidget(self.frame_137)

        self.frame_139 = QFrame(self.frame_136)
        self.frame_139.setObjectName(u"frame_139")
        self.frame_139.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_139.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_97 = QHBoxLayout(self.frame_139)
        self.horizontalLayout_97.setObjectName(u"horizontalLayout_97")
        self.frame_140 = QFrame(self.frame_139)
        self.frame_140.setObjectName(u"frame_140")
        self.frame_140.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_140.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_140.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_85 = QVBoxLayout(self.frame_140)
        self.verticalLayout_85.setObjectName(u"verticalLayout_85")
        self.label_78 = QLabel(self.frame_140)
        self.label_78.setObjectName(u"label_78")
        self.label_78.setFont(font2)

        self.verticalLayout_85.addWidget(self.label_78, 0, Qt.AlignmentFlag.AlignHCenter)

        self.widget_35 = QWidget(self.frame_140)
        self.widget_35.setObjectName(u"widget_35")
        sizePolicy2.setHeightForWidth(self.widget_35.sizePolicy().hasHeightForWidth())
        self.widget_35.setSizePolicy(sizePolicy2)
        self.widget_35.setStyleSheet(u"background-color: rgb(140, 140, 140);")
        self.verticalLayout_86 = QVBoxLayout(self.widget_35)
        self.verticalLayout_86.setObjectName(u"verticalLayout_86")
        self.radioButton_35 = QRadioButton(self.widget_35)
        self.radioButton_35.setObjectName(u"radioButton_35")
        self.radioButton_35.setFont(font3)

        self.verticalLayout_86.addWidget(self.radioButton_35)

        self.radioButton_36 = QRadioButton(self.widget_35)
        self.radioButton_36.setObjectName(u"radioButton_36")
        self.radioButton_36.setFont(font3)

        self.verticalLayout_86.addWidget(self.radioButton_36)


        self.verticalLayout_85.addWidget(self.widget_35)


        self.horizontalLayout_97.addWidget(self.frame_140)

        self.frame_141 = QFrame(self.frame_139)
        self.frame_141.setObjectName(u"frame_141")
        sizePolicy1.setHeightForWidth(self.frame_141.sizePolicy().hasHeightForWidth())
        self.frame_141.setSizePolicy(sizePolicy1)
        self.frame_141.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_141.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_87 = QVBoxLayout(self.frame_141)
        self.verticalLayout_87.setObjectName(u"verticalLayout_87")
        self.frame_142 = QFrame(self.frame_141)
        self.frame_142.setObjectName(u"frame_142")
        sizePolicy4.setHeightForWidth(self.frame_142.sizePolicy().hasHeightForWidth())
        self.frame_142.setSizePolicy(sizePolicy4)
        self.frame_142.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_142.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_88 = QVBoxLayout(self.frame_142)
        self.verticalLayout_88.setObjectName(u"verticalLayout_88")
        self.radioButton_37 = QRadioButton(self.frame_142)
        self.radioButton_37.setObjectName(u"radioButton_37")

        self.verticalLayout_88.addWidget(self.radioButton_37)

        self.radioButton_38 = QRadioButton(self.frame_142)
        self.radioButton_38.setObjectName(u"radioButton_38")

        self.verticalLayout_88.addWidget(self.radioButton_38)


        self.verticalLayout_87.addWidget(self.frame_142, 0, Qt.AlignmentFlag.AlignHCenter)

        self.frame_146 = QFrame(self.frame_141)
        self.frame_146.setObjectName(u"frame_146")
        self.frame_146.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_146.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_146.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_101 = QHBoxLayout(self.frame_146)
        self.horizontalLayout_101.setObjectName(u"horizontalLayout_101")
        self.model_installed_12 = QCheckBox(self.frame_146)
        self.model_installed_12.setObjectName(u"model_installed_12")
        self.model_installed_12.setEnabled(False)
        self.model_installed_12.setFont(font4)
        self.model_installed_12.setAutoFillBackground(False)
        self.model_installed_12.setIconSize(QSize(30, 30))
        self.model_installed_12.setCheckable(False)
        self.model_installed_12.setTristate(False)

        self.horizontalLayout_101.addWidget(self.model_installed_12)


        self.verticalLayout_87.addWidget(self.frame_146)

        self.frame_147 = QFrame(self.frame_141)
        self.frame_147.setObjectName(u"frame_147")
        self.frame_147.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_147.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_147.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_102 = QHBoxLayout(self.frame_147)
        self.horizontalLayout_102.setObjectName(u"horizontalLayout_102")
        self.checkpoints_downloaded_12 = QCheckBox(self.frame_147)
        self.checkpoints_downloaded_12.setObjectName(u"checkpoints_downloaded_12")
        self.checkpoints_downloaded_12.setEnabled(False)
        self.checkpoints_downloaded_12.setFont(font4)
        self.checkpoints_downloaded_12.setAutoFillBackground(False)
        self.checkpoints_downloaded_12.setIconSize(QSize(30, 30))
        self.checkpoints_downloaded_12.setCheckable(False)
        self.checkpoints_downloaded_12.setTristate(False)

        self.horizontalLayout_102.addWidget(self.checkpoints_downloaded_12)


        self.verticalLayout_87.addWidget(self.frame_147)


        self.horizontalLayout_97.addWidget(self.frame_141)


        self.verticalLayout_83.addWidget(self.frame_139)


        self.horizontalLayout_94.addWidget(self.frame_136)

        self.frame_148 = QFrame(self.frame_135)
        self.frame_148.setObjectName(u"frame_148")
        sizePolicy1.setHeightForWidth(self.frame_148.sizePolicy().hasHeightForWidth())
        self.frame_148.setSizePolicy(sizePolicy1)
        self.frame_148.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_148.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_89 = QVBoxLayout(self.frame_148)
        self.verticalLayout_89.setObjectName(u"verticalLayout_89")
        self.widget_36 = QWidget(self.frame_148)
        self.widget_36.setObjectName(u"widget_36")
        sizePolicy3.setHeightForWidth(self.widget_36.sizePolicy().hasHeightForWidth())
        self.widget_36.setSizePolicy(sizePolicy3)
        self.widget_36.setMinimumSize(QSize(0, 50))
        self.horizontalLayout_103 = QHBoxLayout(self.widget_36)
        self.horizontalLayout_103.setObjectName(u"horizontalLayout_103")
        self.label_79 = QLabel(self.widget_36)
        self.label_79.setObjectName(u"label_79")
        self.label_79.setFont(font2)

        self.horizontalLayout_103.addWidget(self.label_79)

        self.frame_149 = QFrame(self.widget_36)
        self.frame_149.setObjectName(u"frame_149")
        sizePolicy4.setHeightForWidth(self.frame_149.sizePolicy().hasHeightForWidth())
        self.frame_149.setSizePolicy(sizePolicy4)
        self.frame_149.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_149.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_104 = QHBoxLayout(self.frame_149)
        self.horizontalLayout_104.setObjectName(u"horizontalLayout_104")
        self.label_80 = QLabel(self.frame_149)
        self.label_80.setObjectName(u"label_80")
        self.label_80.setFont(font2)

        self.horizontalLayout_104.addWidget(self.label_80)

        self.pushButton_24 = QPushButton(self.frame_149)
        self.pushButton_24.setObjectName(u"pushButton_24")
        self.pushButton_24.setMinimumSize(QSize(30, 30))
        self.pushButton_24.setMaximumSize(QSize(40, 40))
        self.pushButton_24.setIcon(icon1)
        self.pushButton_24.setIconSize(QSize(30, 30))

        self.horizontalLayout_104.addWidget(self.pushButton_24)


        self.horizontalLayout_103.addWidget(self.frame_149)


        self.verticalLayout_89.addWidget(self.widget_36)

        self.textEdit_12 = QTextEdit(self.frame_148)
        self.textEdit_12.setObjectName(u"textEdit_12")
        sizePolicy5.setHeightForWidth(self.textEdit_12.sizePolicy().hasHeightForWidth())
        self.textEdit_12.setSizePolicy(sizePolicy5)
        self.textEdit_12.setStyleSheet(u"background-color: rgb(229, 229, 229);")
        self.textEdit_12.setReadOnly(True)

        self.verticalLayout_89.addWidget(self.textEdit_12)


        self.horizontalLayout_94.addWidget(self.frame_148)


        self.verticalLayout_90.addWidget(self.frame_135)

        self.tabWidget.addTab(self.tab_12, "")

        self.verticalLayout.addWidget(self.tabWidget)

        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 1181, 33))
        self.menuFile = QMenu(self.menubar)
        self.menuFile.setObjectName(u"menuFile")
        self.menuBenchmarks = QMenu(self.menubar)
        self.menuBenchmarks.setObjectName(u"menuBenchmarks")
        self.menuData = QMenu(self.menubar)
        self.menuData.setObjectName(u"menuData")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.menubar.addAction(self.menuFile.menuAction())
        self.menubar.addAction(self.menuBenchmarks.menuAction())
        self.menubar.addAction(self.menuData.menuAction())
        self.menuFile.addAction(self.actionNew)
        self.menuFile.addAction(self.actionLoad)
        self.menuBenchmarks.addAction(self.actionGP_Regression)
        self.menuData.addAction(self.actionNew_Data_Setup)

        self.retranslateUi(MainWindow)

        self.tabWidget.setCurrentIndex(11)


        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.actionNew.setText(QCoreApplication.translate("MainWindow", u"New..", None))
        self.actionLoad.setText(QCoreApplication.translate("MainWindow", u"Load", None))
        self.actionGP_Regression.setText(QCoreApplication.translate("MainWindow", u"GP Regression", None))
        self.actionNew_Data_Setup.setText(QCoreApplication.translate("MainWindow", u"New Data Setup", None))
        self.label_19.setText(QCoreApplication.translate("MainWindow", u"Clamp", None))
        self.label.setText(QCoreApplication.translate("MainWindow", u"Select your file", None))
        self.pushButton.setText("")
        self.label_2.setText("")
        self.label_3.setText(QCoreApplication.translate("MainWindow", u"Format", None))
        self.radioButton.setText(QCoreApplication.translate("MainWindow", u"SMILES", None))
        self.radioButton_2.setText(QCoreApplication.translate("MainWindow", u"SELFIES", None))
        self.model_installed.setText(QCoreApplication.translate("MainWindow", u"Model installed", None))
        self.checkpoints_downloaded.setText(QCoreApplication.translate("MainWindow", u"Checkpoints Downloaded", None))
        self.label_9.setText(QCoreApplication.translate("MainWindow", u"Status Console", None))
        self.label_4.setText(QCoreApplication.translate("MainWindow", u"RUN", None))
        self.pushButton_2.setText("")
        self.textEdit.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8.25pt;\"><br /></p></body></html>", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab), QCoreApplication.translate("MainWindow", u"clamp", None))
        self.label_20.setText(QCoreApplication.translate("MainWindow", u"MolBERT", None))
        self.label_10.setText(QCoreApplication.translate("MainWindow", u"Select your file", None))
        self.pushButton_3.setText("")
        self.label_11.setText("")
        self.label_12.setText(QCoreApplication.translate("MainWindow", u"Format", None))
        self.radioButton_3.setText(QCoreApplication.translate("MainWindow", u"SMILES", None))
        self.radioButton_4.setText(QCoreApplication.translate("MainWindow", u"SELFIES", None))
        self.model_installed_2.setText(QCoreApplication.translate("MainWindow", u"Model installed", None))
        self.checkpoints_downloaded_2.setText(QCoreApplication.translate("MainWindow", u"Checkpoints Downloaded", None))
        self.label_13.setText(QCoreApplication.translate("MainWindow", u"Status Console", None))
        self.label_14.setText(QCoreApplication.translate("MainWindow", u"RUN", None))
        self.pushButton_4.setText("")
        self.textEdit_2.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8.25pt;\"><br /></p></body></html>", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_2), QCoreApplication.translate("MainWindow", u"molbert", None))
        self.label_21.setText(QCoreApplication.translate("MainWindow", u"GROVER", None))
        self.label_22.setText(QCoreApplication.translate("MainWindow", u"Select your file", None))
        self.pushButton_5.setText("")
        self.label_23.setText("")
        self.label_24.setText(QCoreApplication.translate("MainWindow", u"Format", None))
        self.radioButton_5.setText(QCoreApplication.translate("MainWindow", u"SMILES", None))
        self.radioButton_6.setText(QCoreApplication.translate("MainWindow", u"SELFIES", None))
        self.checkBox_10.setText(QCoreApplication.translate("MainWindow", u"Use Grover Large", None))
        self.checkBox_9.setText(QCoreApplication.translate("MainWindow", u"Use Bonds", None))
        self.checkBox_8.setText(QCoreApplication.translate("MainWindow", u"Use Atoms", None))
        self.model_installed_3.setText(QCoreApplication.translate("MainWindow", u"Model installed", None))
        self.checkpoints_downloaded_3.setText(QCoreApplication.translate("MainWindow", u"Checkpoints Downloaded", None))
        self.label_25.setText(QCoreApplication.translate("MainWindow", u"Status Console", None))
        self.label_26.setText(QCoreApplication.translate("MainWindow", u"RUN", None))
        self.pushButton_6.setText("")
        self.textEdit_3.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8.25pt;\"><br /></p></body></html>", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_3), QCoreApplication.translate("MainWindow", u"Grover", None))
        self.label_31.setText(QCoreApplication.translate("MainWindow", u"Mat", None))
        self.label_32.setText(QCoreApplication.translate("MainWindow", u"Select your file", None))
        self.pushButton_7.setText("")
        self.label_33.setText("")
        self.label_34.setText(QCoreApplication.translate("MainWindow", u"Format", None))
        self.radioButton_7.setText(QCoreApplication.translate("MainWindow", u"SMILES", None))
        self.radioButton_8.setText(QCoreApplication.translate("MainWindow", u"SELFIES", None))
        self.model_installed_4.setText(QCoreApplication.translate("MainWindow", u"Model installed", None))
        self.checkpoints_downloaded_4.setText(QCoreApplication.translate("MainWindow", u"Checkpoints Downloaded", None))
        self.label_35.setText(QCoreApplication.translate("MainWindow", u"Status Console", None))
        self.label_36.setText(QCoreApplication.translate("MainWindow", u"RUN", None))
        self.pushButton_8.setText("")
        self.textEdit_4.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8.25pt;\"><br /></p></body></html>", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_4), QCoreApplication.translate("MainWindow", u"Mat", None))
        self.label_41.setText(QCoreApplication.translate("MainWindow", u"RMat", None))
        self.label_42.setText(QCoreApplication.translate("MainWindow", u"Select your file", None))
        self.pushButton_9.setText("")
        self.label_43.setText("")
        self.label_44.setText(QCoreApplication.translate("MainWindow", u"Format", None))
        self.radioButton_9.setText(QCoreApplication.translate("MainWindow", u"SMILES", None))
        self.radioButton_10.setText(QCoreApplication.translate("MainWindow", u"SELFIES", None))
        self.model_installed_5.setText(QCoreApplication.translate("MainWindow", u"Model installed", None))
        self.checkpoints_downloaded_5.setText(QCoreApplication.translate("MainWindow", u"Checkpoints Downloaded", None))
        self.label_45.setText(QCoreApplication.translate("MainWindow", u"Status Console", None))
        self.label_46.setText(QCoreApplication.translate("MainWindow", u"RUN", None))
        self.pushButton_10.setText("")
        self.textEdit_5.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8.25pt;\"><br /></p></body></html>", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_5), QCoreApplication.translate("MainWindow", u"RMat", None))
        self.label_47.setText(QCoreApplication.translate("MainWindow", u"SelfiesTed", None))
        self.label_48.setText(QCoreApplication.translate("MainWindow", u"Select your file", None))
        self.pushButton_11.setText("")
        self.label_49.setText("")
        self.label_50.setText(QCoreApplication.translate("MainWindow", u"Format", None))
        self.radioButton_11.setText(QCoreApplication.translate("MainWindow", u"SMILES", None))
        self.radioButton_12.setText(QCoreApplication.translate("MainWindow", u"SELFIES", None))
        self.model_installed_6.setText(QCoreApplication.translate("MainWindow", u"Model installed", None))
        self.checkpoints_downloaded_6.setText(QCoreApplication.translate("MainWindow", u"Checkpoints Downloaded", None))
        self.label_51.setText(QCoreApplication.translate("MainWindow", u"Status Console", None))
        self.label_52.setText(QCoreApplication.translate("MainWindow", u"RUN", None))
        self.pushButton_12.setText("")
        self.textEdit_6.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8.25pt;\"><br /></p></body></html>", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_6), QCoreApplication.translate("MainWindow", u"SelfiesTed", None))
        self.label_27.setText(QCoreApplication.translate("MainWindow", u"ChemBERTa", None))
        self.label_28.setText(QCoreApplication.translate("MainWindow", u"Select your file", None))
        self.pushButton_13.setText("")
        self.label_29.setText("")
        self.label_30.setText(QCoreApplication.translate("MainWindow", u"Format", None))
        self.radioButton_13.setText(QCoreApplication.translate("MainWindow", u"SMILES", None))
        self.radioButton_14.setText(QCoreApplication.translate("MainWindow", u"SELFIES", None))
        self.radioButton_15.setText(QCoreApplication.translate("MainWindow", u"Use model: Zinc-base-v1", None))
        self.radioButton_16.setText(QCoreApplication.translate("MainWindow", u"Use model: 77M-MTR", None))
        self.radioButton_17.setText(QCoreApplication.translate("MainWindow", u"Use model: 77M-MLM", None))
        self.model_installed_7.setText(QCoreApplication.translate("MainWindow", u"Models installed", None))
        self.checkpoints_downloaded_7.setText(QCoreApplication.translate("MainWindow", u"Checkpoints Downloaded", None))
        self.label_37.setText(QCoreApplication.translate("MainWindow", u"Status Console", None))
        self.label_38.setText(QCoreApplication.translate("MainWindow", u"RUN", None))
        self.pushButton_14.setText("")
        self.textEdit_7.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8.25pt;\"><br /></p></body></html>", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_7), QCoreApplication.translate("MainWindow", u"ChemBERTa", None))
        self.label_53.setText(QCoreApplication.translate("MainWindow", u"Graphormer", None))
        self.label_54.setText(QCoreApplication.translate("MainWindow", u"Select your file", None))
        self.pushButton_15.setText("")
        self.label_55.setText("")
        self.label_56.setText(QCoreApplication.translate("MainWindow", u"Format", None))
        self.radioButton_18.setText(QCoreApplication.translate("MainWindow", u"SMILES", None))
        self.radioButton_19.setText(QCoreApplication.translate("MainWindow", u"SELFIES", None))
        self.model_installed_8.setText(QCoreApplication.translate("MainWindow", u"Model installed", None))
        self.checkpoints_downloaded_8.setText(QCoreApplication.translate("MainWindow", u"Checkpoints Downloaded", None))
        self.label_57.setText(QCoreApplication.translate("MainWindow", u"Status Console", None))
        self.label_58.setText(QCoreApplication.translate("MainWindow", u"RUN", None))
        self.pushButton_16.setText("")
        self.textEdit_8.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8.25pt;\"><br /></p></body></html>", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_8), QCoreApplication.translate("MainWindow", u"Graphormer", None))
        self.label_39.setText(QCoreApplication.translate("MainWindow", u"NovoMolGen", None))
        self.label_40.setText(QCoreApplication.translate("MainWindow", u"Select your file", None))
        self.pushButton_17.setText("")
        self.label_59.setText("")
        self.label_60.setText(QCoreApplication.translate("MainWindow", u"Format", None))
        self.radioButton_20.setText(QCoreApplication.translate("MainWindow", u"SMILES", None))
        self.radioButton_21.setText(QCoreApplication.translate("MainWindow", u"SELFIES", None))
        self.radioButton_22.setText(QCoreApplication.translate("MainWindow", u"NovoMolGen_32M_SMILES_AtomWise", None))
        self.radioButton_23.setText(QCoreApplication.translate("MainWindow", u"NovoMolGen_157M_SMILES_AtomWise", None))
        self.radioButton_25.setText(QCoreApplication.translate("MainWindow", u"NovoMolGen_300M_SMILES_AtomWise", None))
        self.radioButton_26.setText(QCoreApplication.translate("MainWindow", u"NovoMolGen_32M_SMILES_BPE", None))
        self.radioButton_27.setText(QCoreApplication.translate("MainWindow", u"NovoMolGen_157M_SMILES_BPE", None))
        self.radioButton_28.setText(QCoreApplication.translate("MainWindow", u"NovoMolGen_300M_SMILES_BPE", None))
        self.model_installed_9.setText(QCoreApplication.translate("MainWindow", u"Models installed", None))
        self.checkpoints_downloaded_9.setText(QCoreApplication.translate("MainWindow", u"Checkpoints Downloaded", None))
        self.label_61.setText(QCoreApplication.translate("MainWindow", u"Status Console", None))
        self.label_62.setText(QCoreApplication.translate("MainWindow", u"RUN", None))
        self.pushButton_18.setText("")
        self.textEdit_9.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8.25pt;\"><br /></p></body></html>", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_9), QCoreApplication.translate("MainWindow", u"NovoMolGen", None))
        self.label_63.setText(QCoreApplication.translate("MainWindow", u"MolFormer", None))
        self.label_64.setText(QCoreApplication.translate("MainWindow", u"Select your file", None))
        self.pushButton_19.setText("")
        self.label_65.setText("")
        self.label_66.setText(QCoreApplication.translate("MainWindow", u"Format", None))
        self.radioButton_24.setText(QCoreApplication.translate("MainWindow", u"SMILES", None))
        self.radioButton_29.setText(QCoreApplication.translate("MainWindow", u"SELFIES", None))
        self.model_installed_10.setText(QCoreApplication.translate("MainWindow", u"Model installed", None))
        self.checkpoints_downloaded_10.setText(QCoreApplication.translate("MainWindow", u"Checkpoints Downloaded", None))
        self.label_67.setText(QCoreApplication.translate("MainWindow", u"Status Console", None))
        self.label_68.setText(QCoreApplication.translate("MainWindow", u"RUN", None))
        self.pushButton_20.setText("")
        self.textEdit_10.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8.25pt;\"><br /></p></body></html>", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_10), QCoreApplication.translate("MainWindow", u"MolFormer", None))
        self.label_69.setText(QCoreApplication.translate("MainWindow", u"Molgen", None))
        self.label_70.setText(QCoreApplication.translate("MainWindow", u"Select your file", None))
        self.pushButton_21.setText("")
        self.label_71.setText("")
        self.label_72.setText(QCoreApplication.translate("MainWindow", u"Format", None))
        self.radioButton_30.setText(QCoreApplication.translate("MainWindow", u"SMILES", None))
        self.radioButton_31.setText(QCoreApplication.translate("MainWindow", u"SELFIES", None))
        self.radioButton_32.setText(QCoreApplication.translate("MainWindow", u"MolGen-large", None))
        self.radioButton_33.setText(QCoreApplication.translate("MainWindow", u"MolGen-large-opt", None))
        self.radioButton_34.setText(QCoreApplication.translate("MainWindow", u"MolGen-7b", None))
        self.model_installed_11.setText(QCoreApplication.translate("MainWindow", u"Models installed", None))
        self.checkpoints_downloaded_11.setText(QCoreApplication.translate("MainWindow", u"Checkpoints Downloaded", None))
        self.label_73.setText(QCoreApplication.translate("MainWindow", u"Status Console", None))
        self.label_74.setText(QCoreApplication.translate("MainWindow", u"RUN", None))
        self.pushButton_22.setText("")
        self.textEdit_11.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8.25pt;\"><br /></p></body></html>", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_11), QCoreApplication.translate("MainWindow", u"Molgen", None))
        self.label_75.setText(QCoreApplication.translate("MainWindow", u"MolCLR", None))
        self.label_76.setText(QCoreApplication.translate("MainWindow", u"Select your file", None))
        self.pushButton_23.setText("")
        self.label_77.setText("")
        self.label_78.setText(QCoreApplication.translate("MainWindow", u"Format", None))
        self.radioButton_35.setText(QCoreApplication.translate("MainWindow", u"SMILES", None))
        self.radioButton_36.setText(QCoreApplication.translate("MainWindow", u"SELFIES", None))
        self.radioButton_37.setText(QCoreApplication.translate("MainWindow", u"GIN", None))
        self.radioButton_38.setText(QCoreApplication.translate("MainWindow", u"GCN", None))
        self.model_installed_12.setText(QCoreApplication.translate("MainWindow", u"Model installed", None))
        self.checkpoints_downloaded_12.setText(QCoreApplication.translate("MainWindow", u"Checkpoints Downloaded", None))
        self.label_79.setText(QCoreApplication.translate("MainWindow", u"Status Console", None))
        self.label_80.setText(QCoreApplication.translate("MainWindow", u"RUN", None))
        self.pushButton_24.setText("")
        self.textEdit_12.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8.25pt;\"><br /></p></body></html>", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_12), QCoreApplication.translate("MainWindow", u"MolCLR", None))
        self.menuFile.setTitle(QCoreApplication.translate("MainWindow", u"File", None))
        self.menuBenchmarks.setTitle(QCoreApplication.translate("MainWindow", u"Benchmarks", None))
        self.menuData.setTitle(QCoreApplication.translate("MainWindow", u"Data", None))
    # retranslateUi

