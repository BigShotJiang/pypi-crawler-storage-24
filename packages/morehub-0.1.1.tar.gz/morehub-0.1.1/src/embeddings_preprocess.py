﻿"""Backward-compatible import shim.

Canonical location: universal_templates.embeddings_preprocess
"""

from universal_templates.embeddings_preprocess import *  # noqa: F401,F403
