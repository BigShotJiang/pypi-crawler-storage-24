"""Allow running the dashboard with: python -m insa_its.dashboard"""
from .tui import main

main()
