"""
InsAIts Hooks Package
=====================
Claude Code integration hooks for InsAIts AI Monitor.

- claude_code_hook: PostToolUse hook that inspects tool outputs
"""

from .claude_code_hook import main as run_hook

__all__ = ["run_hook"]
