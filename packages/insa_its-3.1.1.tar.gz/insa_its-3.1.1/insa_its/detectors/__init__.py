"""
InsAIts SDK - Advanced Detectors
=================================
Algorithmic anomaly detectors for multi-agent communication.

V3.0 Detectors:
- SemanticDriftDetector: EWMA-based cosine distance drift detection
- HallucinationChainDetector: Confidence propagation tracking
- JargonDriftDetector: TF-IDF weighted out-of-vocabulary detection

V3.0.3 Detectors:
- UncertaintyPropagationDetector: Cross-agent uncertainty qualifier tracking
- QueryIntentDetector: Intent-vs-query divergence detection

V3.1.0 Security Detectors:
- ToolDescriptionDivergenceDetector: Tool poisoning detection (OWASP MCP03)
- BehavioralFingerprintDetector: Rug pull / behavioral change detection (OWASP MCP04)
- CredentialPatternDetector: API key / PII / secret exposure (OWASP MCP01, ASI06)
- InformationFlowTracker: Cross-agent data leakage detection (OWASP MCP06, MCP10)
- ToolCallFrequencyAnomalyDetector: Rogue agent / privilege escalation (OWASP ASI09)
"""

from .semantic_drift import SemanticDriftDetector, DriftResult
from .hallucination_chain import HallucinationChainDetector
from .jargon_drift import JargonDriftDetector
from .uncertainty_propagation import UncertaintyPropagationDetector
from .query_intent import QueryIntentDetector

# V3.1.0 Security Detectors
from .tool_description_divergence import ToolDescriptionDivergenceDetector
from .behavioral_fingerprint import BehavioralFingerprintDetector
from .credential_pattern import CredentialPatternDetector
from .information_flow import InformationFlowTracker
from .tool_call_frequency import ToolCallFrequencyAnomalyDetector

__all__ = [
    # V3.0
    "SemanticDriftDetector",
    "DriftResult",
    "HallucinationChainDetector",
    "JargonDriftDetector",
    # V3.0.3
    "UncertaintyPropagationDetector",
    "QueryIntentDetector",
    # V3.1.0 Security
    "ToolDescriptionDivergenceDetector",
    "BehavioralFingerprintDetector",
    "CredentialPatternDetector",
    "InformationFlowTracker",
    "ToolCallFrequencyAnomalyDetector",
]
