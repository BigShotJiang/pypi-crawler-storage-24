# -*- coding: utf-8 -*-
#
# Copyright (C) 2025-2026 TU Wien.
#
# Invenio-Config-TUW is free software; you can redistribute it and/or modify
# it under the terms of the MIT License; see LICENSE file for more details.

"""Overrides for the default records & drafts classes."""

from flask import current_app, request
from invenio_access.permissions import system_identity
from invenio_rdm_records.records.api import (
    RDMDraft,
    RDMFileDraft,
    RDMRecord,
    get_files_quota,
)
from invenio_records.extensions import RecordExtension
from invenio_records.systemfields import SystemField
from invenio_records_resources.records.systemfields.files import FilesField
from invenio_requests.proxies import current_requests_service as requests_service

from .proxies import current_config_tuw


class CurationRequestField(SystemField):
    """Systemfield for fetching the curation request associated with the record.

    This is similar to the `record.parent.review` systemfield which references
    community review requests.
    Unlike the latter, it does not store a reference to the request in the
    record, but rather works via a query.

    This performance hit should not matter too much, since the field needs to be
    accessed explicitly to be evaluated; it does not get evaluated automatically
    for "normal" operations.

    Note that other types of systemfields (like ModelField and subclasses) do
    get dumped automatically.
    """

    def __get__(self, record, owner=None):
        """Get the curation request for the given record."""
        if record is None:
            return self

        # TODO add caching (via redis) if we find a curation request
        recid = record.pid.pid_value
        curation_request = None
        curation_requests = list(
            requests_service.search(
                identity=system_identity,
                q=f"type:rdm-curation AND topic.record:{recid}",
            )
        )
        num_curation_requests = len(curation_requests)

        if num_curation_requests <= 0:
            return None
        elif num_curation_requests > 1:
            current_app.logger.warn(
                f"Found {num_curation_requests} rdm-curation requests for record {recid}"
            )
            curation_request, *_ = curation_requests
        else:
            (curation_request,) = curation_requests

        return requests_service.record_cls.get_record(curation_request["id"])


class RelatedRequestsField(SystemField):
    """Systemfield for fetching the curation request associated with the record."""

    def __init__(self, request_type: str, key=None):
        """Constructor."""
        super().__init__(key=key)
        self._request_type = request_type

    def __get__(self, record, owner=None):
        """Get all requests of a certain type with the given record as topic."""
        if record is None:
            return self

        # TODO add caching (via redis) if we find a curation request
        recid = record.pid.pid_value
        requests = list(
            requests_service.search(
                identity=system_identity,
                q=f"type:{self._request_type} AND topic.record:{recid}",
            )
        )

        return [requests_service.record_cls.get_record(req["id"]) for req in requests]


def choose_files_location(record=None):
    """Choose the bucket's default location based on the request's IP address.

    This will be executed as part of the ``post_create()`` hook of the ``FilesField``,
    which runs after a draft has been created (i.e. before any opportunity to upload
    files).
    """
    bucket_args = get_files_quota(record)

    location = None
    if request:
        location = current_config_tuw.default_location_for_ip(request.remote_addr)

    if location is not None:
        bucket_args["location"] = location.name

    return bucket_args


class RequestReindexingExtension(RecordExtension):
    """Extension for the record parent class, keeping requests up to date.

    With the ``Topic`` permission generator for requests that we've enabled for
    access requests (via the "manage" permission level), we have tied request
    permissions to permission levels to records.
    The latter may be manipulated by users e.g. via access grants, that are stored
    in the record parent.
    As such, we need to monitor changes to the record parents, and reindex all
    potentially affected requests.
    That will keep visibility of the requests in line with the record permissions.

    This is relevant as long as upstream InvenioRDM does not provide a mechanism
    for that same behavior.
    Upstream could probably add this functionality into "unit of work" operations
    for relevant service calls; that would be closer to the DB session commit.

    Current InvenioRDM version: v13
    """

    def __init__(self, record_cls, draft_cls):
        """Constructor."""
        self.record_cls = record_cls
        self.draft_cls = draft_cls

    def post_commit(self, record):
        """Look for any requests affected by the record change and reindex them."""
        try:
            # collect the record IDs of all children
            recids = {record.pid.pid_value}
            recids.update(
                {
                    r.pid.pid_value
                    for r in self.record_cls.get_records_by_parent(record)
                    if r.pid and r.pid.pid_value
                }
            )
            recids.update(
                {
                    d.pid.pid_value
                    for d in self.draft_cls.get_records_by_parent(record)
                    if d.pid and d.pid.pid_value
                }
            )

            # create a query for any affected requests
            query = " OR ".join(recids)
            requests = requests_service.search(
                identity=system_identity,
                q=f"topic.record:({query})",
            )

            # reindex all affected requests
            requests = requests_service.record_cls.get_records(
                [r["id"] for r in requests]
            )
            for req in requests:
                requests_service.indexer.index(req)

        except Exception as e:
            current_app.logger.error(e)


class TUWRDMDraft(RDMDraft):
    """Override for the default draft class, for storing files in another location."""

    # The values here are copied from the super class, except for the bucket args
    files = FilesField(
        store=False,
        dump=False,
        file_cls=RDMFileDraft,
        # Don't delete, we'll manage in the service
        delete=False,
        bucket_args=choose_files_location,
    )

    curation_request = CurationRequestField()
    guest_access_requests = RelatedRequestsField("guest-access-request")
    user_access_requests = RelatedRequestsField("user-access-request")


class TUWRDMRecord(RDMRecord):
    """Override for the default record class, for curation requests."""

    curation_request = CurationRequestField()
    guest_access_requests = RelatedRequestsField("guest-access-request")
    user_access_requests = RelatedRequestsField("user-access-request")
