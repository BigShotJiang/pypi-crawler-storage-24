# -*- coding: utf-8 -*-
#
# Copyright (C) 2020-2026 TU Wien.
#
# Invenio-Config-TUW is free software; you can redistribute it and/or modify
# it under the terms of the MIT License; see LICENSE file for more details.

"""Permission generators to be used for the permission policies at TU Wien."""

from flask_login import current_user
from flask_principal import RoleNeed, UserNeed
from invenio_access.permissions import SystemRoleNeed
from invenio_curations.services.generators import (
    CurationModerators,
)
from invenio_curations.services.generators import (
    IfCurationRecordBasedExists as IfCurationRequestExists,
)
from invenio_rdm_records.services.generators import RecordOwners
from invenio_records_permissions.generators import Generator, IfConfig

tiss_user_need = SystemRoleNeed("tiss_user")
"""System role for users that have TISS IDs."""


class TrustedUsers(Generator):
    """Allows users with the "trusted-user" role."""

    def needs(self, record=None, **kwargs):
        """Enabling Needs."""
        return [RoleNeed("trusted-user")]


class RecordOwnersWithRole(RecordOwners):
    """Allows record owners with a given role."""

    def __init__(self, role_name, exclude=True):
        """Constructor."""
        super().__init__()
        self.role_name = role_name
        self.exclude = exclude

    def needs(self, record=None, **kwargs):
        """Enabling Needs."""
        if record is None:
            if (
                bool(current_user)
                and not current_user.is_anonymous
                and current_user.has_role(self.role_name)
            ):
                return [UserNeed(current_user.id)]
            else:
                return []

        needs = []
        if owner := record.parent.access.owner:
            if owner.owner_id != "system":
                has_role = owner.resolve().has_role(self.role_name)
                if has_role:
                    needs.append(UserNeed(owner.owner_id))

        return needs

    def excludes(self, **kwargs):
        """Explicit excludes."""
        if not self.exclude:
            return super().excludes(**kwargs)

        elif (
            bool(current_user)
            and not current_user.is_anonymous
            and not current_user.has_role(self.role_name)
        ):
            return [UserNeed(current_user.id)]

        return []


def TrustedRecordOwners(exclude=False):
    """Allows record owners with the "trusted-user" role."""
    return RecordOwnersWithRole("trusted-user", exclude=exclude)


def IfCurationsEnabled(then_, else_):
    """Check if the curations module is enabled."""
    return IfConfig("CONFIG_TUW_CURATIONS_ENABLED", then_=then_, else_=else_)


def CurationModeratorsIfRequestExists(else_=None):
    """If curations are enabled and a request exists, allow moderators."""
    return IfCurationsEnabled(
        [IfCurationRequestExists(then_=[CurationModerators()], else_=[])],
        else_ or [],
    )


class TISSUsers(Generator):
    """Allows users that have a TISS ID set."""

    def needs(self, **kwargs):
        """Enabling Needs."""
        return [tiss_user_need]
