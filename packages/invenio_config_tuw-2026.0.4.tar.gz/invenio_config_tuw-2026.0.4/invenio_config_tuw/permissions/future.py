# -*- coding: utf-8 -*-
#
# Copyright (C) 2026 TU Wien.
#
# Invenio-Config-TUW is free software; you can redistribute it and/or modify
# it under the terms of the MIT License; see LICENSE file for more details.

"""Backport of Mirek's ``SameAs`` permission generator and records policy tweaks.

This entire module should be removed once we get the releases containing Mirek's
pull requests (likely in v14):
* https://github.com/inveniosoftware/invenio-records-permissions/pull/119
* https://github.com/inveniosoftware/invenio-rdm-records/pull/2267

The magic here is that the permission policies now also supply themselves in the
``**over`` arguments to the generators (added to the permission policies for records
and requests here).
"""

import warnings

try:
    from invenio_rdm_records.services.permissions import (
        RDMRecordPermissionPolicy,
        RDMRequestsPermissionPolicy,
    )
    from invenio_records_permissions.generators import SameAs

    warnings.warn("SameAs is available now, time to remove our backport!")

except ImportError:
    # if the SameAs import failed, we know that we have to use our backport

    import operator
    from abc import ABC, abstractmethod
    from functools import reduce
    from itertools import chain

    from invenio_administration.generators import Administration
    from invenio_communities.generators import CommunityCurators
    from invenio_rdm_records.services.generators import (
        AccessGrant,
        CommunityInclusionReviewers,
        IfAtLeastOneCommunity,
        IfDeleted,
        IfExternalDOIRecord,
        IfNewRecord,
        IfOneCommunity,
        IfRecordDeleted,
        IfRestricted,
        RecordCommunitiesAction,
        RecordOwners,
        ResourceAccessToken,
        SecretLinks,
        SubmissionReviewer,
    )
    from invenio_rdm_records.services.permissions import (
        RDMRequestsPermissionPolicy as BaseRequestsPermissionPolicy,
    )
    from invenio_records_permissions.generators import (
        AnyUser,
        AuthenticatedUser,
        Disable,
        Generator,
        IfConfig,
        SystemProcess,
    )
    from invenio_records_permissions.policies.records import RecordPermissionPolicy
    from invenio_records_resources.services.files.generators import IfTransferType
    from invenio_records_resources.services.files.transfer import (
        LOCAL_TRANSFER_TYPE,
        MULTIPART_TRANSFER_TYPE,
    )
    from invenio_search.engine import dsl
    from invenio_users_resources.services.permissions import UserManager

    class CompositeGenerator(Generator, ABC):
        """Base class for generators that compose multiple generators.

        This generator implements the Composite design pattern, allowing you to combine
        multiple generators and treat them as a single generator. Subclasses must implement
        the ``_generators(**context)`` method to return the list of generators to compose.

        Behavior:
            - ``needs``: Combines (flattens) the needs from all composed generators
            - ``excludes``: Combines (flattens) the excludes from all composed generators
            - ``query_filter``: Combines query filters using OR logic (any filter matches)
        """

        @abstractmethod
        def _generators(self, **context):
            """Return the list of generators to compose.

            Must be implemented by subclasses.

            :param context: Context dictionary that may contain record, etc.
            :returns: List of Generator instances to compose
            """
            raise NotImplementedError  # pragma: no cover

        def needs(self, **context):
            """Get enabling needs from all composed generators.

            Combines needs from all generators into a single flattened list.
            """
            needs = [
                generator.needs(**context) for generator in self._generators(**context)
            ]
            return list(chain.from_iterable(needs))

        def excludes(self, **context):
            """Get preventing needs from all composed generators.

            Combines excludes from all generators into a single flattened list.
            """
            excludes = [
                generator.excludes(**context)
                for generator in self._generators(**context)
            ]
            return list(chain.from_iterable(excludes))

        def query_filter(self, **context):
            """Get search filters from all composed generators.

            Combines query filters from all generators using OR logic. This means a record
            matches if it satisfies ANY of the composed generator's filters.

            :returns: Combined query using OR, or match_none if no generators provide filters
            """
            generators = self._generators(**context)

            queries = [g.query_filter(**context) for g in generators]
            queries = [q for q in queries if q]
            if not queries:
                return dsl.Q("match_none")

            return reduce(operator.or_, queries) if queries else None

    class SameAs(CompositeGenerator):
        """Generator that delegates permissions to another permission on the same policy.

        This generator allows you to reuse the permission configuration from one action
        for another action, promoting DRY (Don't Repeat Yourself) principles. It dynamically
        retrieves the generators from the specified permission attribute on the policy.

        This is particularly useful when:
            - Multiple actions should have identical permission requirements
            - You want permission inheritance when subclassing policies
            - You need to maintain a single source of truth for related permissions

        Example:
            .. code-block:: python

                class RecordPermissionPolicy(BasePermissionPolicy):
                    can_edit = [RecordOwners(), AdminAction("admin-access")]
                    can_delete = [SameAs("can_edit")]  # Delegates to can_edit
                    can_create_files = [SameAs("can_edit")]  # Also delegates to can_edit

            In this example, ``can_delete`` and ``can_create_files`` will have the exact
            same permissions as ``can_edit``. If you later modify ``can_edit`` or override
            it in a subclass, the delegating permissions automatically inherit those changes.

        Note:
            The permission name must be an attribute on the policy instance and must
            contain a list of generators.
        """

        def __init__(self, permission_name: str) -> None:
            """Initialize the generator.

            :param permission_name: Name of the permission attribute to delegate to.
                Must be in the format "can_<action>" (e.g., "can_edit", "can_read").
                This attribute must exist on the permission policy and contain a list of generators.
            """
            self._delegated_permission_name = permission_name

        def _generators(self, **context):
            """Get the generators from the delegated permission on the policy.

            :param context: Must contain 'permission_policy' key with the policy instance
            :returns: List of generators from the delegated permission
            """
            policy = context["permission_policy"]
            return getattr(policy, self._delegated_permission_name)

        def __add__(self, other):
            """Allow adding another generator or list of generators to this SameAs generator.

            Example:
                can_delete = SameAs("can_edit") + [RecordOwners()]
            """
            if isinstance(other, (tuple, list, set)):
                return [self] + list(other)
            else:
                return [self, other]

        def __iter__(self):
            """Let the SameAs be used as the sole element inside the can_abc properties.

            Example:
                can_delete = SameAs("can_edit")
            """
            return iter([self])

    class RDMRecordPermissionPolicy(RecordPermissionPolicy):
        """Access control configuration for records.

        Note that even if the array is empty, the invenio_access Permission class
        always adds the ``superuser-access``, so admins will always be allowed.
        """

        def __init__(self, action, **over):
            """Constructor."""
            super().__init__(action, **over)

            # adding self to the permission policy context for generators to use
            self.over = {
                **over,
                "permission_policy": self,
            }

        NEED_LABEL_TO_ACTION = {
            "bucket-update": "update_files",
            "bucket-read": "read_files",
            "object-read": "read_files",
        }

        # permission meant for global curators of the instance
        # (for now applies to internal notes field only
        # to be replaced with an adequate permission when it is defined)
        can_manage_internal = [SystemProcess()]
        #
        # High-level permissions (used by low-level)
        #
        can_manage = [
            RecordOwners(),
            RecordCommunitiesAction("curate"),
            AccessGrant("manage"),
            SystemProcess(),
        ]
        can_curate = SameAs("can_manage") + [AccessGrant("edit"), SecretLinks("edit")]
        can_review = SameAs("can_curate") + [SubmissionReviewer()]
        can_preview = SameAs("can_review") + [
            AccessGrant("preview"),
            SecretLinks("preview"),
            UserManager,
        ]
        can_view = SameAs("can_preview") + [
            AccessGrant("view"),
            SecretLinks("view"),
            CommunityInclusionReviewers(),
            RecordCommunitiesAction("view"),
        ]

        can_authenticated = [AuthenticatedUser(), SystemProcess()]
        can_all = [AnyUser(), SystemProcess()]

        #
        # Miscellaneous
        #
        # Allow for querying of statistics
        # - This is currently disabled because it's not needed and could potentially
        #   open up surface for denial of service attacks
        can_query_stats = [Disable()]

        #
        #  Records
        #
        # Allow searching of records
        can_search = SameAs("can_all")

        # Allow reading metadata of a record
        can_read = [
            IfRestricted("record", then_=SameAs("can_view"), else_=SameAs("can_all")),
        ]

        # Used for search filtering of deleted records
        # cannot be implemented inside can_read - otherwise permission will
        # kick in before tombstone renders
        can_read_deleted = [
            IfRecordDeleted(
                then_=[UserManager, SystemProcess()],
                else_=SameAs("can_read"),
            )
        ]
        can_read_deleted_files = SameAs("can_read_deleted")
        can_media_read_deleted_files = SameAs("can_read_deleted_files")
        # Allow reading the files of a record
        can_read_files = [
            IfRestricted("files", then_=SameAs("can_view"), else_=SameAs("can_all")),
            ResourceAccessToken("read"),
        ]
        can_get_content_files = [
            # note: even though this is closer to business logic than permissions,
            # it was simpler and less coupling to implement this as permission check
            IfTransferType(LOCAL_TRANSFER_TYPE, SameAs("can_read_files")),
            SystemProcess(),
        ]
        # Allow submitting new record
        can_create = SameAs("can_authenticated")

        can_search_revisions = [Administration()]

        #
        # Drafts
        #
        # Allow ability to search drafts
        can_search_drafts = SameAs("can_authenticated")
        # Allow reading metadata of a draft
        can_read_draft = SameAs("can_preview")
        # Allow reading files of a draft
        can_draft_read_files = SameAs("can_preview") + [ResourceAccessToken("read")]
        # Allow updating metadata of a draft
        can_update_draft = SameAs("can_review")
        # Allow uploading, updating and deleting files in drafts
        can_draft_create_files = [
            # review is the same as create_files
            IfTransferType(LOCAL_TRANSFER_TYPE, SameAs("can_review")),
            IfTransferType(MULTIPART_TRANSFER_TYPE, SameAs("can_review")),
            SystemProcess(),
        ]
        can_draft_set_content_files = [
            # review is the same as create_files
            IfTransferType(LOCAL_TRANSFER_TYPE, SameAs("can_review")),
            IfTransferType(MULTIPART_TRANSFER_TYPE, SameAs("can_review")),
            SystemProcess(),
        ]
        can_draft_get_content_files = [
            # preview is same as read_files
            IfTransferType(LOCAL_TRANSFER_TYPE, SameAs("can_draft_read_files")),
            SystemProcess(),
        ]
        can_draft_commit_files = [
            # review is the same as create_files
            IfTransferType(LOCAL_TRANSFER_TYPE, SameAs("can_review")),
            IfTransferType(MULTIPART_TRANSFER_TYPE, SameAs("can_review")),
            SystemProcess(),
        ]
        can_draft_update_files = SameAs("can_review")
        can_draft_delete_files = SameAs("can_review")

        can_draft_get_file_transfer_metadata = [SystemProcess()]
        can_draft_update_file_transfer_metadata = [SystemProcess()]

        # Allow enabling/disabling files
        can_manage_files = [
            IfConfig(
                "RDM_ALLOW_METADATA_ONLY_RECORDS",
                then_=[
                    IfNewRecord(then_=SameAs("can_create"), else_=SameAs("can_review"))
                ],
                else_=[SystemProcess()],
            ),
        ]
        # Allow managing record access
        can_manage_record_access = [
            IfConfig(
                "RDM_ALLOW_RESTRICTED_RECORDS",
                then_=[
                    IfNewRecord(then_=SameAs("can_create"), else_=SameAs("can_review"))
                ],
                else_=[],
            )
        ]

        #
        # PIDs
        #
        can_pid_create = SameAs("can_review")
        can_pid_register = SameAs("can_pid_create")
        can_pid_update = SameAs("can_pid_create")
        can_pid_discard = SameAs("can_pid_create")
        can_pid_delete = SameAs("can_pid_create")
        can_pid_manage = [SystemProcess()]

        #
        # Actions
        #
        # Allow to put a record in edit mode (create a draft from record)
        can_edit = [IfDeleted(then_=[Disable()], else_=SameAs("can_curate"))]
        # Allow deleting/discarding a draft and all associated files
        can_delete_draft = SameAs("can_curate")
        # Allow creating a new version of an existing published record.
        can_new_version = [
            IfConfig(
                "RDM_ALLOW_EXTERNAL_DOI_VERSIONING",
                then_=SameAs("can_curate"),
                else_=[
                    IfExternalDOIRecord(
                        then_=[SystemProcess()], else_=SameAs("can_curate")
                    )
                ],
            ),
        ]
        # Allow publishing a new record or changes to an existing record.
        can_publish = [
            IfConfig(
                "RDM_COMMUNITY_REQUIRED_TO_PUBLISH",
                then_=[
                    IfAtLeastOneCommunity(
                        then_=SameAs("can_review"),
                        else_=[Administration(), SystemProcess()],
                    ),
                ],
                else_=SameAs("can_review"),
            )
        ]
        # Allow lifting a record or draft.
        can_lift_embargo = SameAs("can_manage")

        #
        # Record communities
        #
        # Who can add record to a community
        can_add_community = SameAs("can_manage")
        # Who can remove a community from a record
        can_remove_community_ = [
            RecordOwners(),
            CommunityCurators(),
            SystemProcess(),
        ]
        can_remove_community = [
            IfConfig(
                "RDM_COMMUNITY_REQUIRED_TO_PUBLISH",
                then_=[
                    IfOneCommunity(
                        then_=[Administration(), SystemProcess()],
                        else_=SameAs("can_remove_community_"),
                    ),
                ],
                else_=SameAs("can_remove_community_"),
            ),
        ]
        # Who can remove records from a community
        can_remove_record = [CommunityCurators(), Administration(), SystemProcess()]
        # Who can add records to a community in bulk
        can_bulk_add = [SystemProcess()]

        #
        # Media files - draft
        #
        can_draft_media_create_files = SameAs("can_review")
        can_draft_media_read_files = SameAs("can_review")
        can_draft_media_set_content_files = [
            IfTransferType(LOCAL_TRANSFER_TYPE, SameAs("can_review")),
            SystemProcess(),
        ]
        can_draft_media_get_content_files = [
            # preview is same as read_files
            IfTransferType(LOCAL_TRANSFER_TYPE, SameAs("can_preview")),
            SystemProcess(),
        ]
        can_draft_media_commit_files = [
            # review is the same as create_files
            IfTransferType(LOCAL_TRANSFER_TYPE, SameAs("can_review")),
            SystemProcess(),
        ]
        can_draft_media_update_files = SameAs("can_review")
        can_draft_media_delete_files = SameAs("can_review")

        #
        # Media files - record
        #
        can_media_read_files = [
            IfRestricted("record", then_=SameAs("can_view"), else_=SameAs("can_all")),
            ResourceAccessToken("read"),
        ]
        can_media_get_content_files = [
            # note: even though this is closer to business logic than permissions,
            # it was simpler and less coupling to implement this as permission check
            IfTransferType(LOCAL_TRANSFER_TYPE, SameAs("can_read")),
            SystemProcess(),
        ]
        can_media_create_files = [Disable()]
        can_media_set_content_files = [Disable()]
        can_media_commit_files = [Disable()]
        can_media_update_files = [Disable()]
        can_media_delete_files = [Disable()]

        #
        # Record deletion workflows
        #
        can_delete = [Administration(), SystemProcess()]
        can_delete_files = [SystemProcess()]
        can_purge = [SystemProcess()]

        #
        # Record and user quota
        #

        can_manage_quota = [
            # moderators
            UserManager,
            SystemProcess(),
        ]
        #
        # Disabled actions (these should not be used or changed)
        #
        # - Records/files are updated/deleted via drafts so we don't support
        #   using below actions.
        can_update = [Disable()]
        can_create_files = [Disable()]
        can_set_content_files = [Disable()]
        can_commit_files = [Disable()]
        can_update_files = [Disable()]

        can_get_file_transfer_metadata = [Disable()]
        can_update_file_transfer_metadata = [Disable()]

        # Used to hide the `parent.is_verified` field. It should be set to
        # correct permissions based on which the field will be exposed only to moderators
        can_moderate = [SystemProcess()]

    class RDMRequestsPermissionPolicy(BaseRequestsPermissionPolicy):
        """Permission policy for requets, adapted to the needs for RDM-Records."""

        def __init__(self, action, **over):
            """Constructor."""
            super().__init__(action, **over)

            # adding self to the permission policy context for generators to use
            self.over = {
                **over,
                "permission_policy": self,
            }

        can_search_user_requests = SameAs("can_search")

        can_create_comment = SameAs("can_read")
        can_reply_comment = SameAs("can_create_comment")
        can_manage_files = SameAs("can_create_comment")
        can_read_files = SameAs("can_read")


__all__ = (
    "RDMRecordPermissionPolicy",
    "SameAs",
)
