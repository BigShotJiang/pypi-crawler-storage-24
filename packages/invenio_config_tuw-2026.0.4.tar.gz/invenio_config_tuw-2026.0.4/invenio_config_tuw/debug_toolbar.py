# -*- coding: utf-8 -*-
#
# Copyright (C) 2026 TU Wien.
#
# Invenio-Config-TUW is free software; you can redistribute it and/or modify
# it under the terms of the MIT License; see LICENSE file for more details.

"""Custom debug toolbar panel for quickly logging in."""

from flask import abort, current_app, redirect, render_template
from flask_security import login_user, logout_user
from invenio_accounts.models import User

try:
    from flask_debugtoolbar.panels.g import DebugPanel
except ImportError:
    # if FDT is not installed, the inheritance hierarchy doesn't have to be meaningful
    DebugPanel = object


class LoginPanel(DebugPanel):
    """A panel to quickly log in to the account of a selected user."""

    name = "login"
    has_content = True

    @classmethod
    def init_app(cls, app):
        """Register the quick login endpoint."""
        if not app.config.get("DEBUG_TB_ENABLED", False):
            return

        app.add_url_rule(
            "/_flask_debugtoolbar_login/<string:id>",
            "_flask_debugtoolbar_login.login_as_user",
            cls.login_as_user,
        )

    @classmethod
    def login_as_user(cls, id=None):
        """Quickly log in with the given user's account."""
        if not current_app.config.get("DEBUG_TB_ENABLED", False):
            return

        user = User.query.get(id)
        if user:
            logout_user()
            login_user(user)
            return redirect("/")
        else:
            abort(404)

    def nav_title(self) -> str:
        """Title showing in toolbar."""
        return "Login"

    def title(self) -> str:
        """Title showing in panel."""
        return "Quick login as user"

    def url(self) -> str:
        """URL."""
        return ""

    def render(self, template_name, context):
        """Render the panel's template with the given context."""
        return render_template(template_name, **context)

    def content(self) -> str:
        """Render the panel."""
        context = self.context.copy()
        context["users"] = list(User.query.order_by(User.id).all())
        return self.render("panels/login.html", context)
