list(APPEND CMAKE_MODULE_PATH ${CMAKE_CURRENT_LIST_DIR})

set(KAGEN_USE_SPARSEHASH OFF)
set(KAGEN_USE_CGAL ON)

include(CMakeFindDependencyMacro)
find_dependency(MPI REQUIRED)
find_dependency(Threads REQUIRED)

if (KAGEN_USE_SPARSEHASH)
    find_dependency(Sparsehash REQUIRED)
endif ()

if (KAGEN_USE_CGAL)
    find_dependency(CGAL REQUIRED)
endif ()

include("${CMAKE_CURRENT_LIST_DIR}/KaGenTargets.cmake")
