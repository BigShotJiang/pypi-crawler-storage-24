#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KaGen::KaGen" for configuration "Release"
set_property(TARGET KaGen::KaGen APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(KaGen::KaGen PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib64/libKaGen.a"
  )

list(APPEND _cmake_import_check_targets KaGen::KaGen )
list(APPEND _cmake_import_check_files_for_KaGen::KaGen "${_IMPORT_PREFIX}/lib64/libKaGen.a" )

# Import target "KaGen::xxhash" for configuration "Release"
set_property(TARGET KaGen::xxhash APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(KaGen::xxhash PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib64/libxxhash.a"
  )

list(APPEND _cmake_import_check_targets KaGen::xxhash )
list(APPEND _cmake_import_check_files_for_KaGen::xxhash "${_IMPORT_PREFIX}/lib64/libxxhash.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
