from dapr.ext.drasi import DrasiChangeEvent, drasi_trigger


@drasi_trigger(
    query_id="critical-tickets",
    pubsub="notifications-pubsub",
    provision_reaction=False,
)
def sample_workflow(ctx, event):
    return event


def test_drasi_trigger_attaches_metadata():
    data = getattr(sample_workflow, "_drasi_trigger_data")
    assert data["query_id"] == "critical-tickets"
    assert data["pubsub"] == "notifications-pubsub"
    assert data["topic"] == "critical-tickets_reaction_agents"

    router_data = getattr(sample_workflow, "_message_router_data")
    assert router_data["pubsub"] == "notifications-pubsub"
    assert router_data["topic"] == "critical-tickets_reaction_agents"


def test_drasi_trigger_converts_event_payload():
    event = sample_workflow(
        None,
        {
            "kind": "change",
            "queryId": "critical-tickets",
            "sequence": 10,
            "sourceTimeMs": 123,
            "addedResults": [{"id": 1}],
            "updatedResults": [],
            "deletedResults": [],
        },
    )

    assert isinstance(event, DrasiChangeEvent)
    assert event.query_id == "critical-tickets"
    assert event.added_results[0]["id"] == 1
