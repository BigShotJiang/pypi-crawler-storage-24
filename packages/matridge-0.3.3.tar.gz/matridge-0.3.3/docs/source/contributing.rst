.. mdinclude:: ../../CONTRIBUTING.md
