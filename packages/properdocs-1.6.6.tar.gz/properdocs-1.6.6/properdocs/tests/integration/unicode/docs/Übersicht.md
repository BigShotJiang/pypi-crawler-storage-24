Welcome to ProperDocs

For full documentation visit [properdocs.org](https://properdocs.org).

## Commands

* `properdocs new [dir-name]` - Create a new project.
* `properdocs serve` - Start the live-reloading docs server.
* `properdocs build` - Build the documentation site.
* `properdocs -h` - Print this help message.

## Project layout

    properdocs.yml # The configuration file.
    docs/
        index.md   # The documentation homepage.
        ...        # Other markdown pages, images and other files.
