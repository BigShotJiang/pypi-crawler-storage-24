import time
from datetime import datetime as Datetime
from datetime import timezone
from zoneinfo import ZoneInfo

import typer

from beni import bcolor, btask
from beni.bfunc import split_lines, sync_call
from beni.btype import Null


@btask.command('time')
@sync_call
async def show_time(
    args: list[str] = typer.Argument(None),
):
    """
    格式化时间戳\n
    beni time\n
    beni time 1632412740\n
    beni time 1632412740.1234\n
    beni time 2021-9-23\n
    beni time 2021-9-23 09:47:00\n
    """
    args = args or []
    btask.assert_true(len(args) <= 2, '参数过多')
    value1: str | None = args[0] if len(args) >= 1 else None
    value2: str | None = args[1] if len(args) >= 2 else None
    timestamp: float = Null
    if not value1:
        timestamp = time.time()
    else:
        try:
            timestamp = float(value1)
        except Exception:
            try:
                if value2:
                    timestamp = Datetime.strptime(f'{value1} {value2}', '%Y-%m-%d %H:%M:%S').timestamp()
                else:
                    timestamp = Datetime.strptime(f'{value1}', '%Y-%m-%d').timestamp()
            except Exception:
                pass
    if not timestamp:
        bcolor.print_red('参数无效\n')
        bcolor.print_red('使用示例：')
        msg_ary = split_lines(str(show_time.__doc__))[1:]
        bcolor.print_red('\n'.join(msg_ary))
        return
    print()
    bcolor.print_magenta(timestamp)
    print()
    # localtime = time.localtime(timestamp)
    # tzname = time.tzname[(time.daylight and localtime.tm_isdst) and 1 or 0]
    # bcolor.printx(time.strftime('%Y-%m-%d %H:%M:%S %z', localtime), tzname, colors=[Fore.YELLOW])
    # print()
    datetime_utc = Datetime.fromtimestamp(timestamp, tz=timezone.utc)
    tzname_list = [
        'Australia/Sydney',
        'Asia/Tokyo',
        'Asia/Shanghai',
        'Asia/Kolkata',
        'Africa/Cairo',
        'Europe/London',
        'America/Sao_Paulo',
        'America/New_York',
        'America/Chicago',
        'America/Los_Angeles',
    ]
    for tzname in tzname_list:
        datetime_tz = datetime_utc.astimezone(ZoneInfo(tzname))
        dst_str = ''
        dst = datetime_tz.dst()
        if dst:
            dst_str = f'(DST+{dst})'
        if tzname == 'Asia/Shanghai':
            bcolor.print_yellow(f'{datetime_tz} {tzname} {dst_str}')
        else:
            print(f'{datetime_tz} {tzname} {dst_str}')
    print()
