import platform

import typer

from beni import bcolor, bfile, bpath, btask
from beni.bfunc import is_platform_linux, is_platform_windows, sync_call


@btask.command()
@sync_call
async def mirror(
    disabled: bool = typer.Option(False, '--disabled', '-d', help='是否禁用'),
):
    "切换 pip 镜像源（阿里云）"

    # 根据不同的系统平台，设置 pip 的配置文件路径
    if is_platform_windows():
        file = bpath.user('pip/pip.ini')
    elif is_platform_linux():
        file = bpath.user('.pip/pip.conf')
    else:
        return btask.abort('暂时不支持该平台', platform.system())

    if disabled:
        bpath.remove(file)
        bcolor.print_red('删除文件', file)
    else:
        content = _content.strip()
        await bfile.write_text(file, content)
        bcolor.print_yellow(file)
        bcolor.print_magenta(content)

    bcolor.print_green('OK')


# ------------------------------------------------------------------------------------

_content = """
[global]
index-url = https://mirrors.aliyun.com/pypi/simple
"""
