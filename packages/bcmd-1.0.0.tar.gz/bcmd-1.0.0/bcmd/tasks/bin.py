from datetime import datetime
from pathlib import Path
from typing import Final

import typer
from prettytable import PrettyTable

from beni import bcolor, bfile, bpath, btask, bzip
from beni.bfunc import split_lines, sync_call
from beni.bqiniu import QiniuBucket
from beni.btype import Null

from ..common import secret

sub_app: Final = btask.new_sub_app('bin 工具')

_PREFIX = 'bin/'


@sub_app.command()
@sync_call
async def download(
    names: list[str] = typer.Argument(None, help='支持多个'),
    file: Path = typer.Option(None, '--file', '-f', help='文件形式指定参数，行为单位'),
    output: Path = typer.Option(Path.cwd(), '--output', '-o', help='本地保存路径'),
    secret_value: str = typer.Option('', '--secret', '-s', help='密钥信息'),
):
    "从七牛云下载执行文件"
    bucket: QiniuBucket = Null
    if file:
        content = await bfile.read_text(Path(file))
        names.extend(split_lines(content))
    for target in names:
        bin_file = output / target
        if bin_file.exists():
            bcolor.print_yellow(f'已存在 {bin_file}')
        else:
            key = f'bin/{target}.zip'
            bucket = bucket or await _get_bucket(secret_value)
            await bucket.download_private_file_unzip(key, output)
            bcolor.print_green(f'added  {bin_file}')


@sub_app.command('list')
@sync_call
async def get_list(
    secret_value: str = typer.Option('', '--secret', '-s', help='密钥信息'),
):
    "列出可下载的文件"
    bucket = await _get_bucket(secret_value)
    datas = (await bucket.get_file_list(_PREFIX, limit=1000))[0]
    datas = [x for x in datas if x.key != _PREFIX and x.key.endswith('.zip')]
    datas.sort(key=lambda x: x.time, reverse=True)
    table = PrettyTable()
    table.add_column(
        bcolor.yellow('文件名称'),
        [x.key[len(_PREFIX) : -len('.zip')] for x in datas],
        'l',
    )
    table.add_column(
        bcolor.yellow('上传时间'),
        [datetime.fromtimestamp(x.time / 10000000).strftime('%Y-%m-%d %H:%M:%S') for x in datas],
    )
    print()
    print(table.get_string())


@sub_app.command()
@sync_call
async def upload(
    file: Path = typer.Argument(..., help='本地文件路径'),
    force: bool = typer.Option(False, '--force', '-f', help='强制覆盖'),
    secret_value: str = typer.Option('', '--secret', '-s', help='密钥信息'),
):
    "上传"
    bucket = await _get_bucket(secret_value)
    key = f'{_PREFIX}{file.name}.zip'
    if not force:
        if await bucket.get_file_status(key):
            btask.abort('云端文件已存在，可以使用 --force 强制覆盖')
    with bpath.use_temp_file() as f:
        bzip.zip_file(f, file)
        await bucket.upload_file(key, f)
    bcolor.print_green('OK')


@sub_app.command()
@sync_call
async def remove(
    key: str = typer.Argument(..., help='云端文件key'),
    secret_value: str = typer.Option('', '--secret', '-s', help='密钥信息'),
):
    bucket = await _get_bucket(secret_value)
    await bucket.delete_files(f'{_PREFIX}{key}.zip')
    bcolor.print_green('OK')


async def _get_bucket(secret_value: str):
    return QiniuBucket(**await secret.get_qiniu())
