import asyncio
import getpass
import json
import os
from pathlib import Path
from typing import Final

import pyperclip
import typer
from rich.console import Console

from beni import bcolor, bcrypto, bfile, bpath, btask
from beni.bfunc import sync_call

sub_app: Final = btask.new_sub_app('加密（v2）')


@sub_app.command()
@sync_call
async def encrypt_text():
    "加密文本（使用剪贴板内容）"
    content = pyperclip.paste()
    assert content, '剪贴板内容不能为空'
    bcolor.print_green(content)
    password = _gen_password()
    result = bcrypto.encrypt_text(content, password)
    pyperclip.copy(result)
    print('密文已复制到剪贴板')
    bcolor.print_yellow(result)


@sub_app.command()
@sync_call
async def decrypt_text():
    "解密文本（使用剪贴板内容）"
    content = pyperclip.paste().strip()
    bcolor.print_yellow(content)
    while True:
        try:
            password = getpass.getpass('输入密码：')
            result = bcrypto.decrypt_text(content, password)
            print('解密成功')
            bcolor.print_green(result)
            return
        except KeyboardInterrupt:
            break
        except BaseException:
            pass


@sub_app.command()
@sync_call
async def encrypt_json():
    "生成JSON密文（使用剪贴板内容）"
    content = pyperclip.paste()
    try:
        data = json.loads(content)
    except Exception:
        return btask.abort('错误：剪贴板内容必须是JSON格式', content)
    Console().print_json(data=data, indent=4, ensure_ascii=False, sort_keys=True)
    password = _gen_password()
    result = bcrypto.encrypt_json(data, password)
    pyperclip.copy(result)
    print('密文已复制到剪贴板')
    bcolor.print_yellow(result)


@sub_app.command()
@sync_call
async def decrypt_json():
    "还原JSON密文内容（使用剪贴板内容）"
    content = pyperclip.paste().strip()
    bcolor.print_yellow(content)
    while True:
        try:
            password = getpass.getpass('输入密码：')
            data = bcrypto.decrypt_json(content, password)
            Console().print_json(data=data, indent=4, ensure_ascii=False, sort_keys=True)
            return
        except KeyboardInterrupt:
            break
        except BaseException:
            pass


@sub_app.command()
@sync_call
async def encrypt_file(file: Path = typer.Argument(..., help='指定需要加密的文件')):
    "加密文件（文件路径使用剪贴板内容）"
    assert file.is_file(), '文件不存在'
    password = _gen_password()
    await bcrypto.encrypt_file(file, password)
    bcolor.print_green('OK')


@sub_app.command()
@sync_call
async def decrypt_file(file: Path = typer.Argument(..., help='指定需要解密的文件')):
    "解密文件（文件路径使用剪贴板内容）"
    assert file.is_file(), '文件不存在'
    password = getpass.getpass('输入密码：')
    await bcrypto.decrypt_file(file, password)
    bcolor.print_green('OK')


@sub_app.command()
@sync_call
async def encrypt_path(
    path: Path = typer.Argument(..., help='指定需要加密的目录'),
):
    "加密目录下所有的文件"
    path = path or Path(os.getcwd())
    assert path.is_dir(), '目录不存在'
    password = _gen_password()
    error_set: set[str] = set()

    async def handle_file(file: Path):
        try:
            content = await bfile.read_text(file)
            assert not content.startswith(bcrypto.FLAG), '文件已加密'
            content = bcrypto.encrypt_text(content, password)
            await bfile.write_text(file, content)
        except Exception:
            error_set.add(str(file))

    file_list = sorted(bpath.list_file(path, True))
    await asyncio.gather(*[handle_file(f) for f in file_list])

    for file in file_list:
        if str(file) in error_set:
            bcolor.print_red(file)
        else:
            print(file)


@sub_app.command()
@sync_call
async def decrypt_path(
    path: Path = typer.Argument(..., help='指定需要解密的目录'),
):
    "解密目录下所有的文件"
    path = path or Path(os.getcwd())
    assert path.is_dir(), '目录不存在'
    password = getpass.getpass('输入密码：')
    error_set: set[str] = set()

    async def handle_file(file: Path):
        try:
            content = await bfile.read_text(file)
            assert content.startswith(bcrypto.FLAG), '文件未加密'
            content = bcrypto.decrypt_text(content, password)
            await bfile.write_text(file, content)
        except Exception:
            error_set.add(str(file))

    file_list = sorted(bpath.list_file(path, True))
    await asyncio.gather(*[handle_file(f) for f in file_list])

    for file in file_list:
        if str(file) in error_set:
            bcolor.print_red(file)
        else:
            print(file)


def _gen_password():
    print('正在创建密码')
    password = ''
    while not password:
        password = getpass.getpass('输入密码：')
    while password != getpass.getpass('重复密码：'):
        pass
    return password
