import subprocess
import tkinter as tk
from pathlib import Path
from typing import Final

import typer

from beni import bcolor, bexecute, bfile, bpath, btask
from beni.bform import BForm
from beni.bfunc import sync_call

from ..common import secret

sub_app: Final = btask.new_sub_app('库相关的工具')


@sub_app.command()
@sync_call
async def update_version(
    path: Path = typer.Argument(Path.cwd(), help='workspace 路径'),
    is_not_commit: bool = typer.Option(False, '--no-commit', '-d', help='是否提交git'),
):
    "修改 pyproject.toml 版本号"
    file = path / 'pyproject.toml'
    btask.assert_true(file.is_file(), '文件不存在', file)
    data = await bfile.read_toml(file)
    latest_version: str = data['project']['version']
    version_ary = [int(x) for x in latest_version.split('.')]
    version_list = [
        f'{version_ary[0] + 1}.0.0',
        f'{version_ary[0]}.{version_ary[1] + 1}.0',
        f'{version_ary[0]}.{version_ary[1]}.{version_ary[2] + 1}',
    ]

    class UpdateVersionForm(BForm):
        def __init__(self):
            super().__init__()
            self.version_var = tk.StringVar(value=version_list[-1])
            self.title('bcmd 版本更新')
            self.add_label('当前版本号', latest_version)
            self.add_radio_btn_list(
                '请选择新版本',
                version_list,
                var=self.version_var,
            )
            self.add_btn('确定', self.destroy, focus=True)

        def get_result(self) -> str:
            return self.version_var.get()

    new_version: str = UpdateVersionForm().run()
    if not new_version:
        btask.abort('用户取消操作')
    content = await bfile.read_text(file)
    if f"version = '{latest_version}'" in content:
        content = content.replace(f"version = '{latest_version}'", f"version = '{new_version}'")
    elif f'version = "{latest_version}"' in content:
        content = content.replace(f'version = "{latest_version}"', f'version = "{new_version}"')
    else:
        raise Exception('版本号修改失败，先检查文件中定义的版本号格式是否正常')
    await bfile.write_text(file, content)

    # 执行一遍 uv.lock
    with bpath.change_path(path):
        await bexecute.run2('uv lock')

    bcolor.print_cyan(new_version)
    if not is_not_commit:
        with bpath.use_temp_file() as temp_file:
            await bfile.write_text(temp_file, f'更新版本号 {new_version}')
            subprocess.run(['TortoiseGitProc.exe', '/command:commit', f'/path:{path}', f'/logmsgfile:{temp_file}'], check=True)
    bcolor.print_green('OK')


@sub_app.command()
@sync_call
async def build(
    path: Path = typer.Argument(Path.cwd(), help='workspace 路径'),
    secret_value: str = typer.Option('', '--secret', '-s', help='密钥信息'),
):
    "发布项目"
    data = await secret.get_pypi(secret_value)
    bpath.remove(path / 'dist')
    bpath.remove(*list(path.glob('*.egg-info')))
    with bpath.change_path(path):
        _, code = await bexecute.run2('uv build')
        btask.assert_true(not code, '构建失败')
        _, code = await bexecute.run2(f'uv publish -u {data["username"]} -p {data["password"]}')
        btask.assert_true(not code, '发布失败')
    bcolor.print_green('OK')
