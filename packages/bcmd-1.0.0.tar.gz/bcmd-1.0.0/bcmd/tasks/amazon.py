import asyncio
import json
import re
import time
import webbrowser
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Final, cast

import pyperclip
import typer
from PIL import Image

from beni import bcolor, bfile, bhttp, bpath, bplaywright, btask
from beni.bfunc import crc_str, split_words, sync_call
from beni.block import limit

from .image import image_split

sub_app: Final = btask.new_sub_app('Amazon 工具')


@sub_app.command()
@sync_call
async def open_asin_list(asin_list: list[str] = typer.Argument([], help='支持多个 ASIN 使用空格间隔，如果不填写则使用剪贴板内容')):
    "根据 ASIN 打开多个 Amazon 多个产品页"
    if asin_list:
        print('当前使用命令行参数')
    else:
        print('当前使用剪贴板内容作为参数')
        asin_list = split_words(pyperclip.paste())
    btask.assert_true(asin_list, '没有提供任何 ASIN')
    for x in asin_list:
        url = f'https://www.amazon.com/dp/{x}'
        print(url)
        webbrowser.open_new_tab(url)


@sub_app.command()
@sync_call
async def make_part_number():
    """
    根据 SKU 生成 Part Number
    支持同时成成多个，这里使用粘贴板里的内容作为参数，每行代表1个SKU
    原理：将 SKU 使用 CRC32 生成校验码作为 Part Number
    """
    content = pyperclip.paste().replace('\r', '')
    ary = content.split('\n')
    result_list: list[str] = []
    for item in ary:
        item = item.strip()
        result = ''
        if item and '-' in item:
            # key = '-'.join(item.split('-')[:-1])
            key = item
            result = crc_str(key).upper()
        result_list.append(result)
        print(item, '=>', result)
    output_content = '\n'.join(result_list)
    pyperclip.copy(output_content)
    bcolor.print_green('Part Number 已复制到剪贴板')
    bcolor.print_green('OK')


@sub_app.command()
@sync_call
async def download_images(
    output_path: Path = typer.Argument(Path.cwd(), help='指定目录或具体图片文件，默认当前目录'),
):
    """
    下载亚马逊产品图片
    包括第一张主图以及全部评论的图片
    以目录作为一个操作单位，里面支持有一个可选的 urls.txt 文件，里面包含多个产品链接，每行一个
    里面有一个 info.json 文件，记录需要解析的url以及需要下载的图片链接
    """

    urls_file = output_path / 'urls.txt'
    info_file = output_path / 'info.json'

    @dataclass
    class Info:
        asin_list: list[str] = field(default_factory=list)
        asin_done_list: list[str] = field(default_factory=list)
        img_url_list: list[str] = field(default_factory=list)
        _is_auto_save: bool = False
        _data_crc: str = ''

        @classmethod
        async def load(cls):
            if info_file.is_file():
                try:
                    data: dict[str, Any] = await bfile.read_json(info_file)
                    allowed = {f.name for f in cls.__dataclass_fields__.values()}
                    cleaned = {k: v for k, v in data.items() if k in allowed and not k.startswith('_')}
                    return cls(**cleaned)
                except Exception as e:
                    btask.abort('请修复 info.json 后重试', str(e))
            return cls()

        async def save(self) -> None:
            data = {k: v for k, v in asdict(self).items() if not k.startswith('_')}
            data_str = json.dumps(data, ensure_ascii=False, indent=4, sort_keys=True)
            if crc_str(data_str) != self._data_crc:
                self._data_crc = crc_str(data_str)
                await bfile.write_text(info_file, data_str)

        async def auto_save(self, delay: int = 3) -> None:
            if not self._is_auto_save:
                self._is_auto_save = True
                while self._is_auto_save:
                    await asyncio.sleep(delay)
                    await self.save()

        def stop_auto_save(self) -> None:
            self._is_auto_save = False

    # 初始化数据
    info = await Info.load()
    info_auto_save_task = asyncio.create_task(info.auto_save())
    download_task_list: list[asyncio.Task[None]] = []

    # 读取 urls 文件，将数据写入 info
    if not urls_file.is_file():
        await bfile.write_text(urls_file, '')
    content = await bfile.read_text(urls_file)
    asin_matches = re.findall(r'/dp/([A-Z0-9]{10})', content, re.IGNORECASE)
    new_asin_list = list(set(dict.fromkeys(asin_matches)) - set(info.asin_list) - set(info.asin_done_list))
    if new_asin_list:
        info.asin_list.extend(new_asin_list)
        info.asin_list.sort()
        print(f'新增 {len(new_asin_list)} 个 ASIN：{" ".join(new_asin_list)}')

    @limit(5)
    async def download_image(url: str) -> None:
        file = output_path / bpath.get(url).name
        if not file.is_file():
            try:
                await bhttp.download(url, file)
                info.img_url_list.remove(url)
                print('下载完成', url)
            except Exception:
                bcolor.print_red('下载失败', url)

    # 先下载 info 里面已经存在的图片链接（上次没有进行的或下载失败的链接）
    for img_url in info.img_url_list:
        download_task_list.append(asyncio.create_task(download_image(img_url)))

    # 使用 playwright 解析图片链接
    async with bplaywright.page(
        browser={
            # 'headless': False,  # 显示浏览器UI
            'channel': 'chrome',  # 使用系统 Chrome 浏览器
        }
    ) as page:
        asin_list = info.asin_list[:]
        for asin in asin_list:
            try:
                product_url = f'https://www.amazon.com/dp/{asin}'
                await page.goto(product_url)

                # 如果出现验证界面则点击等待后继续
                continue_shopping = page.get_by_text('Continue shopping')
                if await continue_shopping.count():
                    await continue_shopping.last.click()
                    await page.wait_for_load_state('load')

                # 收集第一张主图
                main_img = page.locator('#landingImage')
                main_img_url = await main_img.get_attribute('src')
                assert main_img_url, '无法找到主图链接'
                old_stem = bpath.get(main_img_url).stem
                new_stem = old_stem.split('.')[0]
                main_img_url = main_img_url.replace(old_stem, new_stem)
                info.img_url_list.append(main_img_url)
                download_task_list.append(asyncio.create_task(download_image(main_img_url)))

                # 获取评论里面的图片链接
                see_all_photos_btn = page.get_by_text('See all photos')
                if await see_all_photos_btn.count() == 0:
                    see_all_photos_btn = page.get_by_text('查看所有照片')
                if await see_all_photos_btn.count():
                    async with page.expect_response(lambda r: 'getGroupedMediaReviews' in r.url and r.ok) as resp_info:
                        await see_all_photos_btn.click()
                    resp = await resp_info.value
                    data = await resp.json()
                    for group in data['mediaGroupList']:
                        for media in group['mediaList']:
                            if media['mediaType'] == 'IMAGE':
                                img_url = media['image']['url']
                                if img_url in info.img_url_list:
                                    bcolor.print_yellow('放弃重复的图片链接A', img_url)
                                    continue
                                target_file = output_path / bpath.get(img_url).name
                                if target_file.is_file():
                                    bcolor.print_yellow('放弃重复的图片链接B', img_url)
                                    continue
                                print('收集图片链接', img_url)
                                info.img_url_list.append(img_url)
                                download_task_list.append(asyncio.create_task(download_image(img_url)))
                else:
                    bcolor.print_yellow('没有站到任何评论照片')

                # 将 ASIN 标记为已完成
                info.asin_done_list.append(asin)
                info.asin_list.remove(asin)

            except Exception as e:
                bcolor.print_red('网页分析失败', asin, str(e))

    # 等待下载完成
    await asyncio.gather(*download_task_list)

    # 停止数据的自动保存
    info.stop_auto_save()
    await info_auto_save_task

    bcolor.print_green('OK')


@sub_app.command()
@sync_call
async def make_images(
    path: Path = typer.Option(Path.cwd(), help='指定目录或当前目录'),
):
    """
    生成相关产品图
    """

    class ImgRect:
        def __init__(self, file: Path, x: int = 0, y: int = 0, w: int = 0, h: int = 0):
            self.img = Image.open(file)
            self.x = x
            self.y = y
            self.w = w or self.img.size[0]
            self.h = h or self.img.size[1]

    def paste_img(
        source_img: Image.Image,
        target_img: ImgRect,
        show_rect: tuple[int, int, int, int] | list[int] | None = None,
    ):
        paste_resized = target_img.img.resize((target_img.w, target_img.h), Image.Resampling.LANCZOS)
        has_alpha = paste_resized.mode in ('RGBA', 'LA') or (paste_resized.mode == 'P' and 'transparency' in paste_resized.info)

        if show_rect is None:
            source_img.paste(paste_resized, (target_img.x, target_img.y), paste_resized if has_alpha else None)
            return

        show_x, show_y, show_w, show_h = show_rect
        paste_x1, paste_y1 = target_img.x, target_img.y
        paste_x2, paste_y2 = target_img.x + target_img.w, target_img.y + target_img.h
        show_x2, show_y2 = show_x + show_w, show_y + show_h

        clip_x1 = max(paste_x1, show_x)
        clip_y1 = max(paste_y1, show_y)
        clip_x2 = min(paste_x2, show_x2)
        clip_y2 = min(paste_y2, show_y2)

        if clip_x1 >= clip_x2 or clip_y1 >= clip_y2:
            return

        crop_left = clip_x1 - target_img.x
        crop_top = clip_y1 - target_img.y
        crop_right = crop_left + (clip_x2 - clip_x1)
        crop_bottom = crop_top + (clip_y2 - clip_y1)
        cropped = paste_resized.crop((crop_left, crop_top, crop_right, crop_bottom))

        source_img.paste(cropped, (clip_x1, clip_y1), cropped if has_alpha else None)

    async def split_aplus(file: Path, height: int, is_keep_all: bool, output_path: Path):
        with bpath.use_temp_path(True) as temp_path:
            bpath.copy(file, temp_path / file.name)
            await image_split(height, temp_path, True)
            file_list = sorted(bpath.list_file(temp_path))
            file_list = file_list[1:7]
            if not is_keep_all:
                file_list = [file_list[0], file_list[3]]
            for file in file_list:
                to_file = output_path / f'{file.stem.split("-")[-1]}_{height}{file.suffix}'
                bpath.copy(file, to_file)

    info_file = path / 'info.toml'
    if not info_file.is_file():
        bcolor.print_red(info_file)
        return btask.abort('没有找到 info.toml 文件')
    info = await bfile.read_toml(info_file)
    output_path = path / f'z_output_{int(time.time())}'
    color_list: list[str] = sorted(info['base']['color-list'])
    platform_list: list[str] = ['pc', 'mobile']

    # 检查配置文件以及指定的文件是否齐全
    check_file_list: list[Path] = [
        path / info['aplus']['pc-img'],
        path / info['aplus']['mobile-img'],
        path / info['table']['pc-table'],
        path / info['table']['mobile-table'],
        path / info['main-detail']['img'],
    ]
    for file in cast(dict[str, str], info['main-others']).values():
        if 'XX' in file:
            for color in color_list:
                check_file_list.append(path / file.replace('XX', color))
        else:
            check_file_list.append(path / file)
    for color in color_list:
        check_file_list.append(path / info['aplus-img']['colors'][color])
        check_file_list.append(path / info['main-detail-img']['colors-1'][color])
        check_file_list.append(path / info['main-detail-img']['colors-2'][color])
        check_file_list.append(path / info['main-detail-img']['colors-3'][color])
        check_file_list.append(path / info['aplus']['colors'][color])
    is_missing_file = False
    for file in check_file_list:
        if not file.is_file():
            is_missing_file = True
            bcolor.print_red('文件不存在', file)
    if is_missing_file:
        return btask.abort('缺失以上文件，操作取消')

    print('开始生成完整的 A+ 图片')
    aplus_output_path = output_path / 'aplus 完整图片'
    bpath.make(aplus_output_path)
    for platform in platform_list:
        aplus_img = ImgRect(path / info['aplus'][f'{platform}-img'])
        for color in color_list:
            img = Image.new('RGBA', aplus_img.img.size)
            color_img = ImgRect(path / info['aplus']['colors'][color], *info['aplus'][f'{platform}-color-rect'])
            product_img = ImgRect(path / info['aplus-img']['colors'][color], *info['aplus-img'][f'{platform}-img-rect'])
            table_img = ImgRect(path / info['table'][f'{platform}-table'], *info['table'][f'{platform}-table-rect'])
            paste_img(img, color_img)
            paste_img(img, product_img)
            paste_img(img, aplus_img)
            paste_img(img, table_img)
            output_file = aplus_output_path / f'{platform}-{color}.png'
            img.save(output_file)
            print(output_file)

    print('开始切图 A+ 图片')
    aplus_slice_output_path = output_path / 'aplus 切图'
    bpath.make(aplus_slice_output_path)
    first_aplus_img = [
        sorted(x.name for x in bpath.list_file(aplus_output_path) if x.name.startswith('pc'))[0],
        sorted(x.name for x in bpath.list_file(aplus_output_path) if x.name.startswith('mobile'))[0],
    ]
    for aplus_file in bpath.list_file(aplus_output_path):
        platform = aplus_file.name.split('-')[0]
        print(aplus_file)
        await split_aplus(
            aplus_file,
            info['aplus'][f'{platform}-height'],
            aplus_file.name in first_aplus_img,
            aplus_slice_output_path,
        )

    print('开始生成主图-装车细节图')
    main_detail_img = ImgRect(path / info['main-detail']['img'])
    main_output = output_path / '主图'
    for color in color_list:
        img = Image.new('RGBA', main_detail_img.img.size)
        for i in range(1, 4):
            product_img = ImgRect(
                path / info['main-detail-img'][f'colors-{i}'][color],
                *info['main-detail-img'][f'img-rect-{i}'],
            )
            paste_img(img, product_img, info['main-detail'][f'show-rect-{i}'])
        paste_img(img, main_detail_img)
        output_file = main_output / color / f'{info["main-detail"]["output-name"]}.png'
        bpath.make(output_file.parent)
        img.save(output_file)
        print(output_file)

    print('开始搬运其他主图')
    for color in color_list:
        for key, file in info['main-others'].items():
            source_file = path / file.replace('XX', color)
            target_file = main_output / color / f'{key}{source_file.suffix}'
            bpath.copy(source_file, target_file)
            print(target_file)

    bcolor.print_green('OK')
