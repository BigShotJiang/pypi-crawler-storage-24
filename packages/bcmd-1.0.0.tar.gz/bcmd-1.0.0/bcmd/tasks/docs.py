import datetime
import json
import pickle
import tkinter as tk
from contextlib import asynccontextmanager
from pathlib import Path
from tkinter import messagebox
from typing import Any, Final
from uuid import uuid4

import paramiko
from typer import Argument, Option

from beni import bcolor, bcrypto, bexecute, bfile, bpath, btask, bzip
from beni.bform import BForm
from beni.bfunc import sync_call

sub_app: Final = btask.new_sub_app('Vitepress 网站相关')
conf: dict[str, Any] = {}
is_upload: bool = False
password: str = ''
now = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')

project_path = bpath.get('')
docs_path = bpath.get('')
vitepress_dist_path = bpath.get('')
dist_path = bpath.get('')
deploy_path = bpath.get('')
zip_file = bpath.get('')


@sub_app.command()
@sync_call
async def build(
    path: Path = Argument(Path.cwd(), help='workspace 路径'),
    build_cmd: str = Option('docs:build', help='vitepress 构建命令'),
):
    "发布"
    with bpath.use_temp_path(True) as temp_path:
        await init(path)
        await user_input()
        await vitepress_build(temp_path / 'site', build_cmd)
        await make_deploy(temp_path / 'deploy')
        for file in bpath.list_path(temp_path):
            await bzip.seven_zip(zip_file, file)
        if is_upload:
            await upload()
    bcolor.print_green('OK')


async def init(path: Path):
    global project_path, docs_path, vitepress_dist_path, dist_path, deploy_path, zip_file

    # 初始化目录路径
    project_path = path
    docs_path = project_path / 'docs'
    vitepress_dist_path = docs_path / '.vitepress/dist'
    dist_path = project_path / 'dist'
    deploy_path = project_path / 'deploy'

    # 清空打包用到的目录
    bpath.remove(dist_path)
    bpath.make(dist_path)
    bpath.remove(vitepress_dist_path)

    # 更新配置
    project_toml_file = project_path / 'project.toml'
    if not project_toml_file.exists():
        btask.abort('部署文件不存在', project_toml_file)
    conf.update(await bfile.read_toml(project_toml_file))

    # 整理特殊的字段
    zip_file = dist_path / f'{conf["domain"]}_{now}.7z'
    conf['upload_file_name'] = zip_file.name
    conf['temp_path'] += f'/{uuid4()}'


async def user_input():
    global is_upload, password

    class BuildForm(BForm):
        def __init__(self):
            super().__init__(title='发布网站')
            self.var_is_upload = tk.BooleanVar(value=True)
            self.var_password = tk.StringVar(value='')
            self.add_label('网站', conf['domain'])
            self.add_check_box('上传服务器', '', self.var_is_upload)
            self.add_entry('请输入密码', self.var_password, width=20, command=self.on_btn, password=True, focus=True)
            self.add_btn('确定', self.on_btn)

        def on_btn(self):
            password = self.var_password.get()
            try:
                bcrypto.decrypt_json(conf['server_info'], password)
                self.destroy()
            except Exception:
                messagebox.showerror('密码错误', '密码错误，请重新输入')

        def get_result(self):
            return self.var_is_upload.get(), self.var_password.get()

        def onBtn(self):
            self.on_btn()

        def getResult(self):
            return self.get_result()

    result = BuildForm().run()
    if not result:
        btask.abort('用户取消操作')
    is_upload, password = result

    # 将里面加密的内容解密
    for k, v in conf.items():
        if str(v).startswith(bcrypto.FLAG):
            conf[k] = bcrypto.decrypt_text(v, password)


async def vitepress_build(output_path: Path, build_cmd: str):
    with bpath.change_path(project_path):
        await bexecute.run2('pnpm install')
        await bexecute.run2(f'pnpm {build_cmd}')
        bpath.copy(vitepress_dist_path, output_path)


async def make_deploy(output_path: Path):
    bpath.copy(deploy_path, output_path)

    # 删除配置里面加密和删除非字符串的配置，剩下的内容用于替换文件名和文件内容
    data_dict: dict[str, Any] = pickle.loads(pickle.dumps(conf))
    for k in list(data_dict.keys()):
        v = data_dict[k]
        if not isinstance(v, str):
            del data_dict[k]

    # 文件名以及内容调整
    file_list = bpath.list_file(output_path, True)
    for file in file_list:
        # 替换文件名
        to_file = str(file)
        for k, v in data_dict.items():
            to_file = to_file.replace(f'{{{k}}}', str(v))
        if to_file != str(file):
            file.rename(to_file)
            file = bpath.get(to_file)

        # 替换文件内容
        content = await bfile.read_text(file)
        old_content = content
        if content.startswith(bcrypto.FLAG):
            content = bcrypto.decrypt_text(content, password)
        for k, v in data_dict.items():
            content = content.replace(f'{{{k}}}', str(v))
        if old_content != content:
            await bfile.write_text(file, content)

    # 将 Scrips 里面的文件都抽离到 dist 目录
    scripts_path = output_path / 'Scripts'
    for file in bpath.list_file(scripts_path):
        bpath.move(file, dist_path / f'{conf["domain"]}_{now}_{file.stem}{file.suffix}')
    bpath.remove(scripts_path)


@asynccontextmanager
async def ssh_client():
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    with bpath.use_temp_file() as temp_file:
        await bfile.write_text(temp_file, conf['server_key'])
        client.connect(
            **json.loads(conf['server_info']),
            key_filename=str(temp_file),
        )
        yield client
        client.close()


async def upload():
    async with ssh_client() as client:

        def execute_cmd(cmd: str):
            _, stdout, _ = client.exec_command(f"bash -lc '{cmd}'")
            print(stdout.read().decode())

        sftp = client.open_sftp()
        for file in bpath.list_file(dist_path):
            execute_cmd(f'mkdir -p {conf["temp_path"]}')
            sftp.put(str(file), f'{conf["temp_path"]}/{file.name}')
        sh_file = list(dist_path.glob('*.sh'))[0]
        execute_cmd(f'sh {conf["temp_path"]}/{sh_file.name}')
        execute_cmd(f'rm -rf {conf["temp_path"]}')
        sftp.close()
