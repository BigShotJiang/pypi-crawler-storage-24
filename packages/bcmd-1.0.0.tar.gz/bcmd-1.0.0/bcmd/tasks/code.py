import asyncio
import json
import os
from pathlib import Path
from typing import Final

import json5
import pyperclip
import typer
from rich.console import Console

from beni import bcolor, bfile, bpath, btask
from beni.bcolor import print_green, print_magenta, print_yellow
from beni.bfunc import sync_call

sub_app: Final = btask.new_sub_app('代码相关的工具')


@sub_app.command()
@sync_call
async def tidy_tasks(
    tasks_path: Path = typer.Argument(Path.cwd(), help='tasks 路径'),
):
    "整理 task 项目中的 tasks/__init__.py"

    init_file = tasks_path / '__init__.py'
    btask.assert_true(init_file.is_file(), '文件不存在', init_file)
    files = sorted(bpath.list_file(tasks_path))
    files = [x for x in files if x.suffix == '.py' and not x.name.startswith('_')]

    module_names = [x.stem for x in files]
    contents = ['# type: ignore']
    if module_names:
        contents.append('from . import (')
        contents.extend([f'    {name},  # noqa: F401' for name in module_names])
        contents.append(')')
    contents.append('')

    content = '\n'.join(contents)
    old_content = await bfile.read_text(init_file)
    if old_content != content:
        await bfile.write_text(
            init_file,
            content,
        )
        print_yellow(init_file)
        print_magenta(content)
    print_green('OK')


@sub_app.command()
@sync_call
async def tidy_modules(
    modules_path: Path = typer.Argument(Path.cwd(), help='modules_path 路径'),
):
    "整理 fastapi 项目中的 modules/__init__.py"

    import_contents: list[str] = []
    manager_contents: list[str] = []

    xxdict: dict[str, set[Path]] = {}
    for file in sorted(modules_path.glob('**/*Manager.py')):
        if file.parent == modules_path:
            sub_name = '.'
        elif file.parent.parent == modules_path:
            sub_name = f'.{file.parent.stem}'
        else:
            continue
        xxdict.setdefault(sub_name, set()).add(file)
    for sub_name in sorted(xxdict.keys()):
        files = sorted(xxdict[sub_name])
        import_contents.append(f'from {sub_name} import {", ".join([x.stem for x in files])}')
    manager_contents.extend([f'    {x.stem},' for x in sorted([y for x in xxdict.values() for y in x])])

    manager_contents = [x for x in manager_contents if x]
    contents = [
        '\n'.join(import_contents),
        'managers = [\n' + '\n'.join(manager_contents) + '\n]',
    ]
    content = '\n\n'.join(contents) + '\n'
    file = modules_path / '__init__.py'
    print_yellow(str(file))
    print_magenta(content)
    await bfile.write_text(file, content)
    print_green('OK')


@sub_app.command()
@sync_call
async def gen_init_py(
    workspace_path: Path = typer.Argument(Path.cwd(), help='workspace 路径'),
):
    "递归生成 __init__.py 文件"

    ignore_sub_dirs = [
        '.git',
        'venv',
        'node_modules',
        '.pytest_cache',
        '__pycache__',
        '.vscode',
    ]
    folder_list = bpath.list_dir(workspace_path, True)
    # 剔除子目录是这些的文件 .git venv ...
    folder_list = [x for x in folder_list if not any([y in x.parts for y in ignore_sub_dirs])]
    for folder in folder_list:
        py_init_file = folder / '__init__.py'
        if not py_init_file.exists():
            print_yellow(py_init_file)
            await bfile.write_text(py_init_file, '')
    print_green('OK')


@sub_app.command()
@sync_call
async def to_lf(
    path: Path = typer.Option(None, '--path', help='指定目录或具体图片文件，默认当前目录'),
):
    "将所有文件转换为 LF 格式"
    ignore_sub_dirs = [
        '.git',
        'venv',
        'node_modules',
        '.pytest_cache',
        '__pycache__',
    ]
    path = path or Path(os.getcwd())
    files = bpath.list_file(path, True)
    # 剔除子目录是这些的文件 .git venv ...
    files = [x for x in files if not any([y in x.parts for y in ignore_sub_dirs])]

    async def convert_file(file: Path):
        try:
            content = await bfile.read_text(file)
            if '\r\n' in content:
                content = content.replace('\r\n', '\n')
                await bfile.write_text(file, content)
                print_yellow(file)
        except Exception:
            pass

    await asyncio.gather(*[convert_file(file) for file in files])
    print_green('OK')


@sub_app.command('json')
@sync_call
async def format_json():
    "格式化 JSON （使用复制文本）"
    content = pyperclip.paste()
    try:
        data = json.loads(content)
    except Exception:
        try:
            data = json5.loads(content)
        except Exception:
            bcolor.print_red(content)
            btask.abort('无效的 JSON')
    print()
    Console().print_json(json.dumps(data), indent=4, ensure_ascii=False, sort_keys=True)
    pyperclip.copy(json.dumps(data, indent=4, ensure_ascii=False, sort_keys=True))
    print()
    bcolor.print_green('已复制到剪贴板')
    bcolor.print_green('OK')
