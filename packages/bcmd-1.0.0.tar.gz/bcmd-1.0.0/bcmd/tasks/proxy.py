import pyperclip
import typer

from beni import bcolor, btask
from beni.bfunc import is_platform_linux, is_windows_cmd, is_windows_powershell, split_lines, sync_call


@btask.command()
@sync_call
async def proxy(
    port: int = typer.Argument(15236, help='代理服务器端口'),
):
    "设置环境变量代理"

    if is_windows_cmd():
        tips = 'Windows CMD'
        template = template_windows_cmd
    elif is_windows_powershell():
        tips = 'Windows PowerShell'
        template = template_windows_powershell
    elif is_platform_linux():
        tips = 'Linux'
        template = template_linux
    else:
        btask.abort('不支持当前终端，请手动设置代理环境变量')
        return

    line_ary = split_lines(template.format(port))
    line_ary.append('')  # 空行
    line_ary.append('curl https://google.com.hk -UseBasicParsing')
    msg = '\n'.join(line_ary)
    bcolor.print_magenta('\r\n' + msg)
    msg += '\n'  # 多增加一个换行，直接粘贴的时候相当于最后一行也执行完
    pyperclip.copy(msg)
    print()
    bcolor.print_yellow(f'当前平台：{tips}')
    bcolor.print_yellow('代码已复制，需要手动执行才会生效')


template_windows_cmd = """
    set http_proxy=http://localhost:{0}
    set https_proxy=http://localhost:{0}
    set all_proxy=http://localhost:{0}
"""

template_windows_powershell = """
    $env:http_proxy="http://localhost:{0}"
    $env:https_proxy="http://localhost:{0}"
    $env:all_proxy="http://localhost:{0}"
"""

template_linux = """
    export http_proxy="http://localhost:{0}"
    export https_proxy="http://localhost:{0}"
    export all_proxy="http://localhost:{0}"
"""
