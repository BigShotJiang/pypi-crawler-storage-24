import getpass
import subprocess
from pathlib import Path
from typing import Final

from typer import Argument, Option

from beni import bcolor, bcrypto, bexecute, bfile, bpath, btask
from beni.bfunc import sync_call

sub_app: Final = btask.new_sub_app('项目相关的工具')


@sub_app.command()
@sync_call
async def init(
    path: Path = Argument(Path.cwd(), help='workspace 路径'),
    deep: int = Option(3, '--deep', '-d', help='探索深度'),
):
    "找出项目执行初始化 pnpm install 和 uv sync --all-extras"

    def init_sub_folder(path: Path, deep: int):
        uv_lock_file = path / 'uv.lock'
        pnpm_lock_file = path / 'pnpm-lock.yaml'
        if uv_lock_file.exists():
            with bpath.change_path(path):
                subprocess.run(['uv', 'sync', '--all-extras'])
        elif pnpm_lock_file.exists():
            with bpath.change_path(path):
                subprocess.run(['pnpm', 'install'])
        elif deep > 1:
            for sub_path in bpath.list_dir(path):
                init_sub_folder(sub_path, deep - 1)

    init_sub_folder(path, deep)


@sub_app.command()
@sync_call
async def https_cert(
    path: Path = Argument(Path.cwd(), help='https证书路径'),
    no_commit: bool = Option(False, '--no-commit', help='不执行提交操作'),
):
    "更新 https 证书，将证书文件加密并且改名为 {domain}.key 或 {domain}.pem，将下载下来的文件直接放到目录后执行"
    file_list = list(path.glob('**/*.key')) + list(path.glob('**/*.pem'))
    file_list = list(filter(lambda x: x.stem != '{domain}', file_list))
    btask.assert_true(file_list, '没有找到需要处理的证书文件')

    # 处理密码输入
    while True:
        password = getpass.getpass('请输入密码：')
        if not password:
            continue
        re_password = getpass.getpass('请重复输入密码：')
        if password == re_password:
            break
        else:
            bcolor.print_red('两次密码输入不一样')

    # 文件加密处理
    for file in file_list:
        content = await bfile.read_text(file)
        content = bcrypto.encrypt_text(content, password)
        to_file = file.parent / f'{{domain}}{file.suffix}'
        bcolor.print_green('更新文件', to_file)
        await bfile.write_text(to_file, content)
        bcolor.print_yellow('删除文件', file)
        bpath.remove(file)

    if not no_commit:
        await bexecute.run(f'TortoiseGitProc.exe /command:commit /path:{path}/ /logmsg:"更新https证书文件"')
