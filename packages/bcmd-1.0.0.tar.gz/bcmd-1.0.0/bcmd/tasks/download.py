import asyncio
import os
from pathlib import Path
from urllib.parse import urlparse
from uuid import uuid4

import pyperclip
import typer

from beni import bcolor, bfile, bhttp, bpath, btask
from beni.bfunc import split_lines, sync_call


@btask.command()
@sync_call
async def download(
    url_file: Path = typer.Option(None, '--file', '-f', help='需要下载的url文件路径，默认使用剪贴板内容'),
    save_path: Path = typer.Option(None, '--path', '-p', help='下载存放目录，默认当前目录'),
    keep_directory: bool = typer.Option(False, '--keep', '-k', help='保持原始目录结构，默认不保持'),
    timeout: int = typer.Option(30, '--timeout', '-t', help='下载超时时间，单位秒，默认60秒'),
):
    "下载资源资源文件"
    save_path = save_path or Path(os.getcwd())

    if url_file:
        if not url_file.exists():
            btask.abort('指定文件不存在', url_file)
        content = await bfile.read_text(url_file)
    else:
        content = pyperclip.paste()
    url_set = set(split_lines(content))

    for i, url in enumerate(url_set):
        print(f'{i + 1}. {url}')
    print(f'输出目录：{save_path}')
    btask.confirm('是否确认？')

    file_set: set[Path] = set()
    error_url_set: set[str] = set()

    async def download_one(url: str):
        url_path = urlparse(url).path
        if keep_directory:
            file = bpath.get(save_path, '/'.join([x for x in url_path.split('/') if x]))
        else:
            file = save_path / Path(url_path).name
        if file in file_set:
            file = file.with_stem(f'{file.stem}--{uuid4()}')
        file_set.add(file)
        try:
            bcolor.print_green(url)
            await bhttp.download(url, file, timeout=timeout)
        except Exception:
            error_url_set.add(url)
            bcolor.print_red(url)

    await asyncio.gather(*[download_one(x) for x in url_set])

    if error_url_set:
        pyperclip.copy('\n'.join(error_url_set))
        bcolor.print_yellow('部分下载失败，失败部分已复制到剪贴板')
    else:
        bcolor.print_green('OK')
