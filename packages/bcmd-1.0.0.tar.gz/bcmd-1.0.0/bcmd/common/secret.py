import tkinter as tk
from tkinter import messagebox
from typing import Any, TypedDict

from async_lru import alru_cache

from beni import bcrypto, btask
from beni.bform import BForm


class PypiSecret(TypedDict):
    username: str
    password: str


@alru_cache
async def get_pypi(value: str = '') -> PypiSecret:
    return _get_data(
        '请输入 PYPI 密钥信息',
        value
        or 'QbuF2mV/lqovtF5dskZGD7qHknYbNuF2QseWRtWxLZTPrC/jL1tcxV8JEKaRjLsu46PxJZ7zepJwggnUTIWnEAoV5VtgP2/hbuzxxHha8817kR5c65H9fXm8eOal7DYXsUoGPQMnm59UWNXUKjmIaP4sn9nySFlRYqa8sEZSbYQ4N0NL35Dpj1e3wyQxJ+7h2jwKAz50Hh8G4yAM3/js9+NUe4ymts+UXcwsP3ADIBMkzjnFc0lEYg2d+fw0A74XWCvoZPoGqHZR/THUOVNAYxoGgDzP4SPIk1XsmtpxvfO/DpJd/Cg/0fB3MYagGKI1+m6Bxqhvd1I/lf0YbM5y4E4=',  # noqa: E501
    )


class QiniuSecret(TypedDict):
    bucket: str
    base_url: str
    ak: str
    sk: str


@alru_cache
async def get_qiniu(value: str = '') -> QiniuSecret:
    return _get_data(
        '请输入 七牛云 密钥信息',
        value or 'bcrypto---/rA3QfMi8GI4f8b2NE5Xo/x8b5E0RKyK28sD7CUez93IMbWhdX3uIMMo2iEd4kPz7glKJWjvXQ15OYlJpFdXrQXpQHnzPg4NdJoyHZbUmy7S4+vB4abAzYz5ny8RXbS302Ru7qEvfqk1Yd6Q67WiYrNI9vlbUIwMbvII1MKTC/J7wK0iYPMTbXA/+Oj8sH/3YGMf7jjP6ZizEWcpAII5sBlOrAUMgW8FoncrhUYSvdPU9QZ49Hi6Bn9PPtd2NF/xWDb7JprCxnQtl3ejky0hvhg=',
    )


def _get_data(title: str, content: str) -> Any:

    class PasswordForm(BForm):
        result: dict[str, Any] = {}

        def __init__(self):
            super().__init__(title=title)
            self.password_var = tk.StringVar(value='')
            ary = content.split(' ')
            if len(ary) > 1:
                self.add_label('提示', ary[0])
            self.add_entry('密码', self.password_var, width=30, password=True, focus=True, command=self.on_btn)
            self.add_btn('确定', self.on_btn)

        def on_btn(self):
            try:
                self.result.update(bcrypto.decrypt_json(content, self.password_var.get()))
                self.destroy()
            except Exception:
                messagebox.showerror('密码错误', '密码错误，请重新输入')

        def get_result(self):
            return self.result

    result = PasswordForm().run()

    if result is None:
        btask.abort('用户取消操作')
    else:
        return result
