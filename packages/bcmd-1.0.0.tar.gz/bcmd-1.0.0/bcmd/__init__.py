from beni import btask

from .tasks import *  # noqa: F403


def run():
    btask.main()
