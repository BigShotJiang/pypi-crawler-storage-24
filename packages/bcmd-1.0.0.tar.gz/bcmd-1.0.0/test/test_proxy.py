import pytest

from beni import btask


@pytest.mark.asyncio
async def test_proxy():
    result = await btask.test_call('proxy', '--help')
    assert result.exit_code == 0
    assert '设置环境变量代理' in result.output
