from contextlib import asynccontextmanager
from pathlib import Path
from typing import Literal

import img2pdf
import pytest
from PIL import Image

from beni import bfile, bpath, btask


@pytest.mark.asyncio
async def test_pdf_output_images():
    async with _create_temp_pdf_file() as pdf_file:
        result = await btask.test_call('pdf', 'output-images', '--target', pdf_file.as_posix())
        assert result.exit_code == 0
        output_images_path = pdf_file.parent / f'{pdf_file.stem}-PDF图片文件'
        assert output_images_path.is_dir()
        assert len(list(output_images_path.glob('*.png'))) == 1
        assert len(list(output_images_path.glob('*.jpeg'))) == 1


@asynccontextmanager
async def _create_temp_pdf_file():

    def create_color_block_image(file: Path, color: tuple[int, int, int], size: tuple[int, int] = (500, 500), image_format: Literal['JPEG', 'PNG'] = 'JPEG'):
        image = Image.new('RGB', size, color)
        image.save(file, format=image_format)
        image.close()
        return file

    with bpath.use_temp_path(True) as temp_path:
        # 创建色块图片
        file_list = [
            create_color_block_image(temp_path / 'blue.png', (0, 0, 255), image_format='PNG'),
            create_color_block_image(temp_path / 'red.jpeg', (255, 0, 0), image_format='JPEG'),
        ]

        # 生成PDF文件
        pdf_file = temp_path / 'output.pdf'
        await bfile.write_bytes(pdf_file, img2pdf.convert(file_list))  # type: ignore

        yield pdf_file
