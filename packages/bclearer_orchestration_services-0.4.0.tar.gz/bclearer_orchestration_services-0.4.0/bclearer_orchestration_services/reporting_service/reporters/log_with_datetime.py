from bclearer_core.configurations.datastructure.logging_inspection_level_b_enums import (
    COLOR_RESET,
    LoggingInspectionLevelBEnums,
)
from bclearer_orchestration_services.datetime_service.time_helpers.time_getter import (
    now_time_as_string,
)
from bclearer_orchestration_services.log_environment_utility_service.common_knowledge.constants import (
    NAME_VALUE_DELIMITER,
)
from bclearer_orchestration_services.reporting_service.reporters.log_file import (
    LogFiles,
)
from bclearer_orchestration_services.reporting_service.reporters.nf_kafka_producers import (
    NfKafkaProducers,
)
from bclearer_orchestration_services.reporting_service.reporters.websocket_log_publisher import (
    publish_log_to_socket,
)
import inspect


def log_message(
    message: str,
    logging_inspection_level_b_enum: LoggingInspectionLevelBEnums = None,
):
    timestamp = now_time_as_string() + ": "
    date_stamped_message = timestamp + message

    # Get the calling function name for WebSocket source
    # Skip internal logging wrapper functions to find the actual caller
    caller_name = "unknown"
    try:
        frame = inspect.currentframe()
        skip_functions = {
            'log_message',
            'report_log_message',
            'log_inspection_message',
            '__log_start',
            '__log_finish',
            'log_timing_header'
        }
        
        current_frame = frame
        while current_frame:
            current_frame = current_frame.f_back
            if current_frame:
                func_name = current_frame.f_code.co_name
                # Skip internal logging functions
                if func_name not in skip_functions:
                    caller_name = func_name
                    # If called from a class method, try to get class name too
                    if 'self' in current_frame.f_locals:
                        caller_class = current_frame.f_locals['self'].__class__.__name__
                        caller_name = f"{caller_class}.{caller_name}"
                    break
    except Exception:
        pass

    # Apply color only to prefix (timestamp, inspection prefix, level), keep user message in default color
    if logging_inspection_level_b_enum is not None:
        # Split at the last delimiter to separate prefix from actual user message
        parts = message.rsplit(NAME_VALUE_DELIMITER, 1)
        if len(parts) == 2:
            prefix_part = parts[0] + NAME_VALUE_DELIMITER
            user_message = parts[1]
            colored_message = (
                logging_inspection_level_b_enum.enum_color
                + timestamp
                + prefix_part
                + COLOR_RESET
                + user_message
            )
            print(colored_message)
        else:
            # Fallback: color everything if format doesn't match expected
            colored_message = (
                logging_inspection_level_b_enum.enum_color
                + date_stamped_message
                + COLOR_RESET
            )
            print(colored_message)
    else:
        print(date_stamped_message)

    try:
        LogFiles.write_to_log_file(
            message=date_stamped_message
            + "\n",
        )
    except Exception as log_file_exception:
        import sys

        print(
            f"ERROR: Failed to write log message to file: {log_file_exception}",
            file=sys.stderr,
        )

    try:
        NfKafkaProducers.log_to_kafka_producer(
            message=date_stamped_message,
        )
    except Exception as kafka_exception:
        import sys

        print(
            f"ERROR: Failed to write log message to Kafka: {kafka_exception}",
            file=sys.stderr,
        )
    
    # Send to WebSocket endpoint with caller function name as source
    try:
        publish_log_to_socket(
            message=date_stamped_message,
            logging_inspection_level_b_enum=logging_inspection_level_b_enum,
            source=caller_name,
        )
    except Exception as websocket_exception:
        import sys

        print(
            f"ERROR: Failed to send log message to WebSocket: {websocket_exception}",
            file=sys.stderr,
        )
