/**
 * Type definitions for log components
 */

import { LogMessage } from '../typescript/LogMessage';

/**
 * Log level string union type
 */
export type LogLevelType = 'DEBUG' | 'VERBOSE' | 'INFO' | 'WARNING' | 'ERROR' | 'CRITICAL';

/**
 * Message type union
 */
export type MessageType = 'inspection' | 'timing' | 'environment' | 'general';

/**
 * Performance metrics structure
 */
export interface PerformanceMetrics {
    action?: string;
    function?: string;
    cpu?: string;
    totalMemory?: string;
    availableMemory?: string;
    usedMemory?: string;
    duration?: string;
}

/**
 * WebSocket connection state
 */
export enum ConnectionState {
    DISCONNECTED = 'disconnected',
    CONNECTING = 'connecting',
    CONNECTED = 'connected',
    ERROR = 'error'
}

/**
 * WebSocket hook options
 */
export interface UseWebSocketLogsOptions {
    url: string;
    autoConnect?: boolean;
    reconnect?: boolean;
    reconnectDelay?: number;
    maxReconnectAttempts?: number;
    onConnect?: () => void;
    onDisconnect?: () => void;
    onError?: (error: Event) => void;
    onMessage?: (log: LogMessage) => void;
}

/**
 * WebSocket hook return value
 */
export interface UseWebSocketLogsReturn {
    logs: LogMessage[];
    connectionState: ConnectionState;
    connect: () => void;
    disconnect: () => void;
    clearLogs: () => void;
    addLog: (log: LogMessage) => void;
}

/**
 * Filter state type
 */
export interface LogFilterState {
    levelFilter: string;
    typeFilter: string;
    searchTerm: string;
}

/**
 * Style type for inline styles
 */
export type StyleObject = React.CSSProperties;
