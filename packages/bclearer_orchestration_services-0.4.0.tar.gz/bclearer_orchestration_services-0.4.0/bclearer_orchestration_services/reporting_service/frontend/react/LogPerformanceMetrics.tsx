import React, { CSSProperties } from 'react';
import { PerformanceMetrics } from './types';

interface LogPerformanceMetricsProps {
    metrics: PerformanceMetrics;
    className?: string;
    style?: CSSProperties;
}

interface MetricRow {
    label: string;
    value: string;
    unit?: string;
}

/**
 * Component for displaying performance metrics from structured logs
 * Standalone component with no external dependencies
 */
export const LogPerformanceMetrics: React.FC<LogPerformanceMetricsProps> = ({ 
    metrics, 
    className,
    style 
}) => {
    const containerStyle: CSSProperties = {
        marginTop: '8px',
        padding: '8px',
        backgroundColor: '#f9f9f9',
        borderRadius: '3px',
        fontSize: '11px',
        ...style,
    };

    const tableStyle: CSSProperties = {
        width: '100%',
        borderCollapse: 'collapse',
    };

    const cellStyle: CSSProperties = {
        padding: '3px 8px',
    };

    const labelStyle: CSSProperties = {
        ...cellStyle,
        fontWeight: 'bold',
        color: '#666',
        width: '150px',
    };

    const metricRows: MetricRow[] = [
        { label: 'CPU Usage', value: metrics.cpu || '', unit: '' },
        { label: 'Total Memory', value: metrics.totalMemory || '', unit: 'GB' },
        { label: 'Available Memory', value: metrics.availableMemory || '', unit: 'GB' },
        { label: 'Used Memory', value: metrics.usedMemory || '', unit: 'GB' },
        { label: 'Duration', value: metrics.duration || '', unit: 'seconds' },
    ].filter(row => row.value);

    return (
        <div className={className} style={containerStyle}>
            <table style={tableStyle}>
                <tbody>
                    {metricRows.map((row, index) => (
                        <tr key={index}>
                            <td style={labelStyle}>{row.label}:</td>
                            <td style={cellStyle}>
                                {row.value} {row.unit}
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};
