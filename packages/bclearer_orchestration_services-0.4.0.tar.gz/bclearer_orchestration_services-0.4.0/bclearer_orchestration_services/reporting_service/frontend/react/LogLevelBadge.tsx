import React, { CSSProperties } from 'react';
import { LogLevelType } from './types';

interface LogLevelBadgeProps {
    level: LogLevelType | string;
    className?: string;
    style?: CSSProperties;
}

/**
 * Badge component for displaying log levels
 * Standalone component with no external dependencies
 */
export const LogLevelBadge: React.FC<LogLevelBadgeProps> = ({ level, className, style }) => {
    const getLevelStyle = (): CSSProperties => {
        const baseStyle: CSSProperties = {
            padding: '2px 8px',
            borderRadius: '3px',
            fontWeight: 'bold',
            fontSize: '10px',
            textTransform: 'uppercase',
            display: 'inline-block',
        };

        const levelLower = level.toLowerCase();
        
        const levelStyles: Record<string, CSSProperties> = {
            debug: {
                backgroundColor: '#f5f5f5',
                color: '#616161',
            },
            verbose: {
                backgroundColor: '#f5f5f5',
                color: '#616161',
            },
            info: {
                backgroundColor: '#e3f2fd',
                color: '#1976d2',
            },
            warning: {
                backgroundColor: '#fff3e0',
                color: '#f57c00',
            },
            error: {
                backgroundColor: '#ffebee',
                color: '#c62828',
            },
            critical: {
                backgroundColor: '#f3e5f5',
                color: '#7b1fa2',
            },
        };

        return {
            ...baseStyle,
            ...(levelStyles[levelLower] || levelStyles.info),
            ...style,
        };
    };

    return (
        <span className={className} style={getLevelStyle()}>
            {level}
        </span>
    );
};
