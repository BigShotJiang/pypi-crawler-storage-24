import React, { CSSProperties, ChangeEvent } from 'react';
import { LogLevelType, MessageType } from './types';

interface LogFilterProps {
    levelFilter: string;
    onLevelFilterChange: (level: string) => void;
    typeFilter: string;
    onTypeFilterChange: (type: string) => void;
    searchTerm: string;
    onSearchTermChange: (term: string) => void;
    totalLogs: number;
    filteredLogs: number;
    className?: string;
    style?: CSSProperties;
}

interface FilterOption {
    value: string;
    label: string;
}

const LEVEL_OPTIONS: FilterOption[] = [
    { value: 'ALL', label: 'All Levels' },
    { value: 'VERBOSE', label: 'Verbose' },
    { value: 'INFO', label: 'Info' },
    { value: 'WARNING', label: 'Warning' },
    { value: 'ERROR', label: 'Error' },
    { value: 'CRITICAL', label: 'Critical' },
];

const TYPE_OPTIONS: FilterOption[] = [
    { value: 'ALL', label: 'All Types' },
    { value: 'general', label: 'General' },
    { value: 'inspection', label: 'Inspection' },
    { value: 'timing', label: 'Timing' },
    { value: 'environment', label: 'Environment' },
];

/**
 * Component for filtering logs by level, type, and search term
 * Standalone component with no external dependencies
 */
export const LogFilter: React.FC<LogFilterProps> = ({
    levelFilter,
    onLevelFilterChange,
    typeFilter,
    onTypeFilterChange,
    searchTerm,
    onSearchTermChange,
    totalLogs,
    filteredLogs,
    className,
    style,
}) => {
    const containerStyle: CSSProperties = {
        display: 'flex',
        gap: '10px',
        alignItems: 'center',
        flexWrap: 'wrap',
        padding: '15px',
        backgroundColor: 'white',
        borderRadius: '8px',
        marginBottom: '15px',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
        ...style,
    };

    const selectStyle: CSSProperties = {
        padding: '8px 12px',
        fontSize: '14px',
        border: '1px solid #ddd',
        borderRadius: '4px',
        backgroundColor: 'white',
        cursor: 'pointer',
    };

    const inputStyle: CSSProperties = {
        padding: '8px 12px',
        fontSize: '14px',
        border: '1px solid #ddd',
        borderRadius: '4px',
        flex: '1',
        minWidth: '200px',
    };

    const statsStyle: CSSProperties = {
        marginLeft: 'auto',
        fontSize: '14px',
        color: '#666',
        fontWeight: 500,
    };

    const handleLevelChange = (e: ChangeEvent<HTMLSelectElement>) => {
        onLevelFilterChange(e.target.value);
    };

    const handleTypeChange = (e: ChangeEvent<HTMLSelectElement>) => {
        onTypeFilterChange(e.target.value);
    };

    const handleSearchChange = (e: ChangeEvent<HTMLInputElement>) => {
        onSearchTermChange(e.target.value);
    };

    return (
        <div className={className} style={containerStyle}>
            <select 
                value={levelFilter} 
                onChange={handleLevelChange}
                style={selectStyle}
                aria-label="Filter by log level"
            >
                {LEVEL_OPTIONS.map(option => (
                    <option key={option.value} value={option.value}>
                        {option.label}
                    </option>
                ))}
            </select>
            
            <select 
                value={typeFilter} 
                onChange={handleTypeChange}
                style={selectStyle}
                aria-label="Filter by message type"
            >
                {TYPE_OPTIONS.map(option => (
                    <option key={option.value} value={option.value}>
                        {option.label}
                    </option>
                ))}
            </select>
            
            <input
                type="text"
                placeholder="Search logs..."
                value={searchTerm}
                onChange={handleSearchChange}
                style={inputStyle}
                aria-label="Search logs"
            />
            
            <div style={statsStyle}>
                Showing {filteredLogs} of {totalLogs} logs
            </div>
        </div>
    );
};
