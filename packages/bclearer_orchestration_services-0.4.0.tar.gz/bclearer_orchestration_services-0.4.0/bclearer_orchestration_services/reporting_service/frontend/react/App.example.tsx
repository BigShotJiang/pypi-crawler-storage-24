import React from 'react';
import { LogViewer } from './LogViewer';
import { useWebSocketLogs } from './useWebSocketLogs';
import { ConnectionState } from './types';

/**
 * Complete example app using the useWebSocketLogs hook
 */
const App: React.FC = () => {
    const { 
        logs, 
        connectionState, 
        connect, 
        disconnect, 
        clearLogs 
    } = useWebSocketLogs({
        url: 'ws://localhost:8000/ws/logs',
        autoConnect: true,
        reconnect: true,
        reconnectDelay: 3000,
        maxReconnectAttempts: 5,
        onConnect: () => console.log('✅ Connected to WebSocket'),
        onDisconnect: () => console.log('❌ Disconnected from WebSocket'),
        onError: (error) => console.error('WebSocket error:', error),
    });

    const getStatusColor = (): string => {
        switch (connectionState) {
            case ConnectionState.CONNECTED:
                return '#4CAF50';
            case ConnectionState.CONNECTING:
                return '#FF9800';
            case ConnectionState.ERROR:
                return '#f44336';
            default:
                return '#999';
        }
    };

    const getStatusText = (): string => {
        switch (connectionState) {
            case ConnectionState.CONNECTED:
                return '✅ Connected';
            case ConnectionState.CONNECTING:
                return '🔄 Connecting...';
            case ConnectionState.ERROR:
                return '❌ Error';
            default:
                return '⭕ Disconnected';
        }
    };

    const containerStyle: React.CSSProperties = {
        padding: '20px',
        maxWidth: '1400px',
        margin: '0 auto',
    };

    const headerStyle: React.CSSProperties = {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: '20px',
    };

    const titleStyle: React.CSSProperties = {
        margin: 0,
        color: '#333',
    };

    const controlsStyle: React.CSSProperties = {
        display: 'flex',
        gap: '10px',
        alignItems: 'center',
    };

    const buttonStyle: React.CSSProperties = {
        padding: '10px 20px',
        fontSize: '14px',
        border: 'none',
        borderRadius: '4px',
        cursor: 'pointer',
        transition: 'opacity 0.3s',
    };

    const connectButtonStyle: React.CSSProperties = {
        ...buttonStyle,
        backgroundColor: '#4CAF50',
        color: 'white',
    };

    const disconnectButtonStyle: React.CSSProperties = {
        ...buttonStyle,
        backgroundColor: '#f44336',
        color: 'white',
    };

    const clearButtonStyle: React.CSSProperties = {
        ...buttonStyle,
        backgroundColor: '#2196F3',
        color: 'white',
    };

    const statusStyle: React.CSSProperties = {
        padding: '8px 16px',
        borderRadius: '4px',
        fontWeight: 'bold',
        backgroundColor: `${getStatusColor()}22`,
        color: getStatusColor(),
        border: `1px solid ${getStatusColor()}`,
    };

    return (
        <div style={containerStyle}>
            <div style={headerStyle}>
                <h1 style={titleStyle}>🔌 WebSocket Log Viewer</h1>
                <div style={controlsStyle}>
                    <button 
                        onClick={connect} 
                        disabled={connectionState === ConnectionState.CONNECTED}
                        style={connectButtonStyle}
                    >
                        Connect
                    </button>
                    <button 
                        onClick={disconnect} 
                        disabled={connectionState === ConnectionState.DISCONNECTED}
                        style={disconnectButtonStyle}
                    >
                        Disconnect
                    </button>
                    <button onClick={clearLogs} style={clearButtonStyle}>
                        Clear Logs
                    </button>
                    <div style={statusStyle}>
                        {getStatusText()}
                    </div>
                </div>
            </div>

            <LogViewer 
                logs={logs}
                showFilter={true}
                autoScroll={true}
                maxHeight="calc(100vh - 200px)"
            />
        </div>
    );
};

export default App;
