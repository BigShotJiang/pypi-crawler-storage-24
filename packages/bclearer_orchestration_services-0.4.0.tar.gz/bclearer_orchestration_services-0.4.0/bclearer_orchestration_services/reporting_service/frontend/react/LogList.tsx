import React, { useRef, useEffect, CSSProperties } from 'react';
import { LogMessage } from '../typescript/LogMessage';
import { LogEntry } from './LogEntry';

interface LogListProps {
    logs: LogMessage[];
    autoScroll?: boolean;
    maxHeight?: string;
    className?: string;
    style?: CSSProperties;
    emptyMessage?: string;
    showTimestamp?: boolean;
    showMetrics?: boolean;
}

/**
 * Component for displaying a list of log entries
 * Includes auto-scroll functionality
 * Standalone component
 */
export const LogList: React.FC<LogListProps> = ({
    logs,
    autoScroll = false,
    maxHeight = '400px',
    className,
    style,
    emptyMessage = 'No logs to display',
    showTimestamp = true,
    showMetrics = true
}) => {
    const containerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (autoScroll && containerRef.current) {
            containerRef.current.scrollTop = containerRef.current.scrollHeight;
        }
    }, [logs, autoScroll]);

    const containerStyle: CSSProperties = {
        border: '1px solid #ddd',
        borderRadius: '4px',
        padding: '15px',
        height: maxHeight,
        overflowY: 'auto',
        backgroundColor: '#fafafa',
        fontFamily: "'Courier New', monospace",
        fontSize: '12px',
        ...style,
    };

    const emptyStyle: CSSProperties = {
        color: '#999', 
        textAlign: 'center', 
        padding: '20px'
    };

    return (
        <div ref={containerRef} className={className} style={containerStyle}>
            {logs.length === 0 ? (
                <div style={emptyStyle}>
                    {emptyMessage}
                </div>
            ) : (
                logs.map((log, index) => (
                    <LogEntry 
                        key={index} 
                        log={log}
                        showTimestamp={showTimestamp}
                        showMetrics={showMetrics}
                    />
                ))
            )}
        </div>
    );
};
