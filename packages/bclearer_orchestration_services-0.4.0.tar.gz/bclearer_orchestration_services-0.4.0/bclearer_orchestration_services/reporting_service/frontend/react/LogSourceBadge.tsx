import React, { CSSProperties } from 'react';

interface LogSourceBadgeProps {
    className?: string | null;
    methodName?: string | null;
    source?: string;
    badgeClassName?: string;
    style?: CSSProperties;
}

/**
 * Badge component for displaying log source (class/method)
 * Standalone component with no external dependencies
 */
export const LogSourceBadge: React.FC<LogSourceBadgeProps> = ({ 
    className, 
    methodName, 
    source,
    badgeClassName,
    style
}) => {
    const badgeStyle: CSSProperties = {
        padding: '2px 6px',
        borderRadius: '3px',
        fontWeight: 500,
        fontSize: '10px',
        backgroundColor: '#e0e7ff',
        color: '#3730a3',
        marginRight: '3px',
        display: 'inline-block',
        ...style,
    };

    const sourceBadgeStyle: CSSProperties = {
        ...badgeStyle,
        backgroundColor: '#e3f2fd',
        color: '#1565c0',
    };

    if (className || methodName) {
        return (
            <>
                {className && (
                    <span className={badgeClassName} style={badgeStyle}>{className}</span>
                )}
                {methodName && (
                    <span className={badgeClassName} style={badgeStyle}>{methodName}</span>
                )}
            </>
        );
    }

    if (source) {
        return <span className={badgeClassName} style={sourceBadgeStyle}>[{source}]</span>;
    }

    return null;
};
