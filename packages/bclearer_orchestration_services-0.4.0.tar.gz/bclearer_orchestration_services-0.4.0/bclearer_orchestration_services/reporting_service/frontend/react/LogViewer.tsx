import React, { useState, useMemo, CSSProperties, useCallback } from 'react';
import { LogMessage } from '../typescript/LogMessage';
import { LogList } from './LogList';
import { LogFilter } from './LogFilter';
import { LogFilterState, MessageType } from './types';

interface LogViewerProps {
    logs: LogMessage[];
    showFilter?: boolean;
    autoScroll?: boolean;
    maxHeight?: string;
    className?: string;
    style?: CSSProperties;
    initialFilters?: Partial<LogFilterState>;
    onFilterChange?: (filters: LogFilterState) => void;
}

/**
 * Complete log viewer component with filtering
 * Uses the LogMessage class for all data handling
 * Standalone component with no external dependencies
 */
export const LogViewer: React.FC<LogViewerProps> = ({ 
    logs, 
    showFilter = true,
    autoScroll = true,
    maxHeight = '600px',
    className = undefined,
    style = undefined,
    initialFilters = {},
    onFilterChange = undefined
}) => {
    const [levelFilter, setLevelFilter] = useState<string>(initialFilters.levelFilter || 'ALL');
    const [typeFilter, setTypeFilter] = useState<string>(initialFilters.typeFilter || 'ALL');
    const [searchTerm, setSearchTerm] = useState<string>(initialFilters.searchTerm || '');

    const handleLevelFilterChange = useCallback((level: string) => {
        setLevelFilter(level);
        onFilterChange?.({ levelFilter: level, typeFilter, searchTerm });
    }, [typeFilter, searchTerm, onFilterChange]);

    const handleTypeFilterChange = useCallback((type: string) => {
        setTypeFilter(type);
        onFilterChange?.({ levelFilter, typeFilter: type, searchTerm });
    }, [levelFilter, searchTerm, onFilterChange]);

    const handleSearchTermChange = useCallback((term: string) => {
        setSearchTerm(term);
        onFilterChange?.({ levelFilter, typeFilter, searchTerm: term });
    }, [levelFilter, typeFilter, onFilterChange]);

    const filteredLogs = useMemo(() => {
        return logs.filter(log => {
            // Level filter
            if (levelFilter !== 'ALL' && log.level.name !== levelFilter) {
                return false;
            }

            // Type filter
            if (typeFilter !== 'ALL' && log.messageType !== typeFilter) {
                return false;
            }

            // Search filter
            if (searchTerm) {
                const searchLower = searchTerm.toLowerCase();
                return (
                    log.cleanedMessage.toLowerCase().includes(searchLower) ||
                    log.source.toLowerCase().includes(searchLower) ||
                    (log.className && log.className.toLowerCase().includes(searchLower)) ||
                    (log.methodName && log.methodName.toLowerCase().includes(searchLower))
                );
            }

            return true;
        });
    }, [logs, levelFilter, typeFilter, searchTerm]);

    const containerStyle: CSSProperties = {
        fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
        ...style,
    };

    return (
        <div className={className} style={containerStyle}>
            {showFilter && (
                <LogFilter
                    levelFilter={levelFilter}
                    onLevelFilterChange={handleLevelFilterChange}
                    typeFilter={typeFilter}
                    onTypeFilterChange={handleTypeFilterChange}
                    searchTerm={searchTerm}
                    onSearchTermChange={handleSearchTermChange}
                    totalLogs={logs.length}
                    filteredLogs={filteredLogs.length}
                />
            )}
            <LogList 
                logs={filteredLogs} 
                autoScroll={autoScroll}
                maxHeight={maxHeight}
            />
        </div>
    );
};
