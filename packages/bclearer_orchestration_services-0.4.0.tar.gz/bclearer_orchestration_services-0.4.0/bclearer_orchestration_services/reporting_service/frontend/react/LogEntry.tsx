import React, { CSSProperties } from 'react';
import { LogMessage } from '../typescript/LogMessage';
import { LogLevelBadge } from './LogLevelBadge';
import { LogSourceBadge } from './LogSourceBadge';
import { LogPerformanceMetrics } from './LogPerformanceMetrics';

interface LogEntryProps {
    log: LogMessage;
    className?: string;
    style?: CSSProperties;
    showTimestamp?: boolean;
    showMetrics?: boolean;
}

/**
 * Component for displaying a single log entry
 * Uses the LogMessage class for all data parsing
 * Standalone component with no external dependencies
 */
export const LogEntry: React.FC<LogEntryProps> = ({ 
    log, 
    className,
    style,
    showTimestamp = true,
    showMetrics = true 
}) => {
    const getEntryStyle = (): CSSProperties => {
        const baseStyle: CSSProperties = {
            padding: '8px',
            margin: '5px 0',
            borderLeft: '4px solid #ccc',
            backgroundColor: 'white',
            borderRadius: '3px',
            transition: 'background-color 0.2s',
            ...style,
        };

        const levelLower = log.getLevelClass();
        
        const borderColors: Record<string, string> = {
            'debug': '#9e9e9e',
            'verbose': '#9e9e9e',
            'info': '#2196F3',
            'warning': '#ff9800',
            'error': '#f44336',
            'critical': '#9c27b0',
        };

        return {
            ...baseStyle,
            borderLeftColor: borderColors[levelLower] || '#ccc',
            backgroundColor: levelLower === 'critical' ? '#fce4ec' : 'white',
        };
    };

    const headerStyle: CSSProperties = {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: '5px',
    };
CSSProperties = {
        display: 'flex',
        gap: '8px',
        alignItems: 'center',
        flexWrap: 'wrap',
    };

    const timestampStyle: CSSProperties = {
        color: '#666',
        fontSize: '11px',
    };

    const messageStyle: CSSProperties = {
        color: '#333',
        lineHeight: '1.4',
        wordBreak: 'break-word',
    };

    const structuredMessageStyle: CSSProperties = {
        ...messageStyle,
        fontWeight: 500,
    };

    if (log.isStructured() && log.structured) {
        return (
            <div className={className} style={getEntryStyle()}>
                <div style={headerStyle}>
                    <div style={metaStyle}>
                        {showTimestamp && (
                            <span style={timestampStyle}>[{log.getFormattedTime()}]</span>
                        )}
                        <LogSourceBadge 
                            className={log.className}
                            methodName={log.methodName}
                            source={log.source}
                        />
                        <LogLevelBadge level={log.level.name} />
                    </div>
                </div>
                <div style={structuredMessageStyle}>
                    <strong>{log.structured.action}</strong> → {log.structured.function}
                </div>
                {showMetrics && <LogPerformanceMetrics metrics={log.structured} />}
            </div>
        );
    }

    return (
        <div className={className} style={getEntryStyle()}>
            <div style={headerStyle}>
                <div style={metaStyle}>
                    {showTimestamp && (
                        <span style={timestampStyle}>[{log.getFormattedTime()}]</span>
                    )}
                    <span style={timestampStyle}>[{log.getFormattedTime()}]</span>
                    <LogSourceBadge 
                        className={log.className}
                        methodName={log.methodName}
                        source={log.source}
                    />
                    <LogLevelBadge level={log.level.name} />
                </div>
            </div>
            <div style={messageStyle}>{log.cleanedMessage}</div>
        </div>
    );
};
