import { useState, useEffect, useCallback, useRef } from 'react';
import { LogMessage } from '../typescript/LogMessage';
import { 
    ConnectionState, 
    UseWebSocketLogsOptions, 
    UseWebSocketLogsReturn 
} from './types';

/**
 * Custom React hook for managing WebSocket log connections
 * 
 * @param options - Configuration options for the WebSocket connection
 * @returns Object containing logs, connection state, and control functions
 * 
 * @example
 * ```tsx
 * const { logs, connectionState, connect, disconnect, clearLogs } = useWebSocketLogs({
 *     url: 'ws://localhost:8000/ws/logs',
 *     autoConnect: true,
 *     reconnect: true,
 *     onConnect: () => console.log('Connected!'),
 * });
 * ```
 */
export const useWebSocketLogs = (options: UseWebSocketLogsOptions): UseWebSocketLogsReturn => {
    const {
        url,
        autoConnect = true,
        reconnect = true,
        reconnectDelay = 3000,
        maxReconnectAttempts = 5,
        onConnect,
        onDisconnect,
        onError,
        onMessage,
    } = options;

    const [logs, setLogs] = useState<LogMessage[]>([]);
    const [connectionState, setConnectionState] = useState<ConnectionState>(
        ConnectionState.DISCONNECTED
    );

    const wsRef = useRef<WebSocket | null>(null);
    const reconnectAttemptsRef = useRef<number>(0);
    const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);

    const addLog = useCallback((log: LogMessage) => {
        setLogs(prev => [...prev, log]);
        onMessage?.(log);
    }, [onMessage]);

    const clearLogs = useCallback(() => {
        setLogs([]);
    }, []);

    const disconnect = useCallback(() => {
        if (reconnectTimeoutRef.current) {
            clearTimeout(reconnectTimeoutRef.current);
            reconnectTimeoutRef.current = null;
        }

        if (wsRef.current) {
            wsRef.current.close();
            wsRef.current = null;
        }

        setConnectionState(ConnectionState.DISCONNECTED);
        reconnectAttemptsRef.current = 0;
    }, []);

    const connect = useCallback(() => {
        if (wsRef.current?.readyState === WebSocket.OPEN) {
            console.log('WebSocket already connected');
            return;
        }

        setConnectionState(ConnectionState.CONNECTING);

        try {
            const ws = new WebSocket(url);

            ws.onopen = () => {
                console.log('WebSocket connected to', url);
                setConnectionState(ConnectionState.CONNECTED);
                reconnectAttemptsRef.current = 0;
                onConnect?.();
            };

            ws.onmessage = (event: MessageEvent) => {
                try {
                    const data = JSON.parse(event.data);
                    const log = LogMessage.fromWebSocket(data);
                    addLog(log);
                } catch (error) {
                    console.error('Failed to parse log message:', error);
                }
            };

            ws.onerror = (error: Event) => {
                console.error('WebSocket error:', error);
                setConnectionState(ConnectionState.ERROR);
                onError?.(error);
            };

            ws.onclose = () => {
                console.log('WebSocket disconnected');
                setConnectionState(ConnectionState.DISCONNECTED);
                wsRef.current = null;
                onDisconnect?.();

                // Handle reconnection
                if (
                    reconnect &&
                    reconnectAttemptsRef.current < maxReconnectAttempts
                ) {
                    reconnectAttemptsRef.current += 1;
                    console.log(
                        `Reconnecting... (${reconnectAttemptsRef.current}/${maxReconnectAttempts})`
                    );

                    reconnectTimeoutRef.current = setTimeout(() => {
                        connect();
                    }, reconnectDelay);
                }
            };

            wsRef.current = ws;
        } catch (error) {
            console.error('Failed to create WebSocket:', error);
            setConnectionState(ConnectionState.ERROR);
        }
    }, [url, reconnect, reconnectDelay, maxReconnectAttempts, onConnect, onDisconnect, onError, addLog]);

    // Auto-connect on mount
    useEffect(() => {
        if (autoConnect) {
            connect();
        }

        // Cleanup on unmount
        return () => {
            disconnect();
        };
    }, [autoConnect, connect, disconnect]);

    return {
        logs,
        connectionState,
        connect,
        disconnect,
        clearLogs,
        addLog,
    };
};
