/**
 * Log level enumeration
 */
export enum LogLevel {
    DEBUG = 'DEBUG',
    INFO = 'INFO',
    WARNING = 'WARNING',
    ERROR = 'ERROR',
    CRITICAL = 'CRITICAL'
}

/**
 * Structured log message class for deconstructing WebSocket log messages
 * from the bclearer logging system.
 */
export class LogMessage {
    // Raw data
    public readonly raw: string;
    public readonly rawMessage: string;
    
    // Metadata
    public readonly timestamp: Date;
    public readonly level: LogLevel;
    public readonly source: string;
    
    // Source breakdown
    public readonly className: string | null;
    public readonly methodName: string | null;
    
    // Message type
    public readonly messageType: 'inspection' | 'timing' | 'environment' | 'general';
    
    // Cleaned message
    public readonly cleanedMessage: string;
    
    // Structured data (if available)
    public readonly structured: {
        action?: string;
        function?: string;
        cpu?: string;
        totalMemory?: string;
        availableMemory?: string;
        usedMemory?: string;
        duration?: string;
    } | null;

    constructor(
        source: string,
        message: string,
        level: string | LogLevel,
        timestamp?: string
    ) {
        this.raw = message;
        this.rawMessage = message;
        this.source = source;
        this.level = typeof level === 'string' ? (LogLevel[level as keyof typeof LogLevel] || LogLevel.INFO) : level;
        this.timestamp = timestamp ? new Date(timestamp) : new Date();
        
        // Parse source into class and method
        const sourceInfo = this.parseSource(source);
        this.className = sourceInfo.className;
        this.methodName = sourceInfo.methodName;
        
        // Determine message type and clean message
        let cleanedMessage = message;
        
        // Remove timestamp prefix
        cleanedMessage = cleanedMessage.replace(/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}:\s*/, '');
        
        // Detect and remove message type prefixes
        if (cleanedMessage.includes('@inspection@')) {
            this.messageType = 'inspection';
            cleanedMessage = cleanedMessage.replace(/@inspection@¬[A-Z]+¬/g, '');
        } else if (cleanedMessage.includes('@timing@')) {
            this.messageType = 'timing';
            cleanedMessage = cleanedMessage.replace(/@timing@¬/g, '');
        } else if (cleanedMessage.includes('@environment@')) {
            this.messageType = 'environment';
            cleanedMessage = cleanedMessage.replace(/@environment@¬/g, '');
        } else {
            this.messageType = 'general';
        }
        
        this.cleanedMessage = cleanedMessage;
        
        // Try to parse structured data
        this.structured = this.parseStructured(cleanedMessage);
    }
    
    /**
     * Parse source string to extract class and method names
     */
    private parseSource(source: string): { className: string | null; methodName: string | null } {
        if (source.includes('.')) {
            const parts = source.split('.');
            return {
                className: parts[0],
                methodName: parts.slice(1).join('.')
            };
        }
        return {
            className: null,
            methodName: null
        };
    }
    
    /**
     * Parse structured log message with ¬ delimiter
     */
    private parseStructured(message: string): {
        action?: string;
        function?: string;
        cpu?: string;
        totalMemory?: string;
        availableMemory?: string;
        usedMemory?: string;
        duration?: string;
    } | null {
        // Check if message contains the delimiter
        if (!message.includes('¬')) {
            return null;
        }
        
        const parts = message.split('¬').map(p => p.trim());
        
        if (parts.length < 5) {
            return null;
        }
        
        // Parse based on structure
        let functionName = '';
        let action = '';
        let cpu = '';
        let totalMemory = '';
        let availableMemory = '';
        let usedMemory = '';
        let duration: string | undefined = undefined;
        
        // Look for CPU usage (contains %)
        for (let i = 0; i < parts.length; i++) {
            const part = parts[i];
            
            if (part.includes('%')) {
                cpu = part;
                // Parse surrounding context
                if (i >= 2 && parts[i - 2]) functionName = parts[i - 2];
                if (i + 1 < parts.length) totalMemory = parts[i + 1];
                if (i + 2 < parts.length) availableMemory = parts[i + 2];
                if (i + 3 < parts.length) usedMemory = parts[i + 3];
                if (i + 4 < parts.length) action = parts[i + 4];
                if (i + 5 < parts.length && parts[i + 5]) duration = parts[i + 5];
                break;
            }
        }
        
        if (!functionName || !action) {
            return null;
        }
        
        return {
            action,
            function: functionName,
            cpu,
            totalMemory,
            availableMemory,
            usedMemory,
            duration
        };
    }
    
    /**
     * Get formatted timestamp string
     */
    public getFormattedTime(): string {
        return this.timestamp.toLocaleTimeString();
    }
    
    /**
     * Get display name for the source (class.method or just source)
     */
    public getSourceDisplay(): string {
        if (this.className && this.methodName) {
            return `${this.className}.${this.methodName}`;
        }
        return this.source;
    }
    
    /**
     * Check if this is a structured log with timing/resource data
     */
    public isStructured(): boolean {
        return this.structured !== null;
    }
    
    /**
     * Get CSS class for the log level
     */
    public getLevelClass(): string {
        return this.level.toLowerCase();
    }
    
    /**
     * Create LogMessage from WebSocket message data
     */
    public static fromWebSocket(data: any): LogMessage {
        return new LogMessage(
            data.source || 'unknown',
            data.message || '',
            data.level || 'INFO',
            data.timestamp
        );
    }
}
