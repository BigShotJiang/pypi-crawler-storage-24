"""
    This module is supposed to be a contained backend with a Socket Port to fetch logs send from the pipelines
    It can be used to transfer logs from a pipeline to a running frontend application
"""

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from typing import List
import json
from datetime import datetime


app = FastAPI(title="Reporting Backend", version="1.0.0")


class ConnectionManager:
    """Manages WebSocket connections and broadcasts messages to all clients"""
    
    def __init__(self):
        self.active_connections: List[WebSocket] = []
        self.connection_filters: dict = {}  # websocket -> set of allowed log levels
    
    async def connect(self, websocket: WebSocket, allowed_levels: set = None):
        """Accept and store a new WebSocket connection with optional log level filter"""
        await websocket.accept()
        self.active_connections.append(websocket)
        if allowed_levels:
            self.connection_filters[websocket] = allowed_levels
    
    def disconnect(self, websocket: WebSocket):
        """Remove a disconnected WebSocket"""
        self.active_connections.remove(websocket)
        self.connection_filters.pop(websocket, None)
    
    async def broadcast(self, message: str):
        """Send a message to all connected clients, respecting their log level filters"""
        # Parse the log level from the message
        try:
            log_data = json.loads(message)
            log_level = log_data.get('level', 'INFO').upper()
        except (json.JSONDecodeError, ValueError):
            log_level = None
        
        for connection in self.active_connections:
            try:
                # Check if this connection has a filter
                allowed_levels = self.connection_filters.get(connection)
                
                # If filter exists and log level doesn't match, skip this connection
                if allowed_levels and log_level and log_level not in allowed_levels:
                    continue
                
                await connection.send_text(message)
            except Exception as e:
                print(f"Error sending message to client: {e}")


manager = ConnectionManager()


@app.websocket("/ws/logs")
async def websocket_endpoint(websocket: WebSocket, log_levels: str = None):
    """
    WebSocket endpoint for log streaming.
    
    Frontend clients connect here to receive logs in real-time.
    Backend services/pipelines can also send logs through this endpoint.
    
    Query Parameters:
        log_levels: Comma-separated list of log levels to filter (e.g., "ERROR,WARNING")
                   If not provided, all log levels are passed through.
    
    Message format (JSON):
    {
        "type": "log",
        "level": "INFO|DEBUG|WARNING|ERROR",
        "message": "log message",
        "timestamp": "ISO format timestamp",
        "source": "optional source identifier"
    }
    """
    # Parse allowed log levels
    allowed_levels = None
    if log_levels:
        allowed_levels = set(level.strip().upper() for level in log_levels.split(','))
    
    await manager.connect(websocket, allowed_levels)
    
    try:
        while True:
            # Receive log messages
            data = await websocket.receive_text()
            
            # Parse and enrich the log message
            try:
                log_data = json.loads(data)
            except json.JSONDecodeError:
                # If not JSON, treat as plain text log
                log_data = {
                    "type": "log",
                    "level": "INFO",
                    "message": data,
                    "timestamp": datetime.now().isoformat(),
                    "source": "unknown"
                }
            
            # Ensure timestamp is present
            if "timestamp" not in log_data:
                log_data["timestamp"] = datetime.now().isoformat()
            
            # Broadcast to all connected clients
            await manager.broadcast(json.dumps(log_data))
            
    except WebSocketDisconnect:
        manager.disconnect(websocket)
        print(f"Client disconnected. Active connections: {len(manager.active_connections)}")
    except Exception as e:
        print(f"WebSocket error: {e}")
        manager.disconnect(websocket)


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "active_connections": len(manager.active_connections),
        "timestamp": datetime.now().isoformat()
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

