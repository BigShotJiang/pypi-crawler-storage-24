from typing import Optional, Set, Type

from bclearer_orchestration_services.identification_services.b_identity_ecosystem.common_knowledge.bie_core_relation_types import (
    BieCoreRelationTypes,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.common_knowledge.bie_enums import (
    BieEnums,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.common_knowledge.reportable_bie_enums_list_getter import (
    get_reportable_bie_enums_list,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.objects.bie_id_registries import (
    BieIdRegistries,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.registrations.helpers.registerers.bie_enums_to_registry_base_register import (
    register_bie_enums_to_registry_base,
)
from bclearer_orchestration_services.reporting_service.wrappers.run_and_log_function_wrapper import (
    run_and_log_function,
)


@run_and_log_function
def register_and_export_bie_infrastructure_enums(
    bie_registry: BieIdRegistries,
    reportable_additional_leaf_enums: list,
) -> None:
    reportable_bie_enums = (
        get_reportable_bie_enums_list()
    )

    leaf_enums = (
        reportable_bie_enums
        + reportable_additional_leaf_enums
    )

    hierarchy_enums = __expand_bie_leaf_enums_to_hierarchy_enums(
        leaf_enums=leaf_enums,
    )

    for bie_enum in hierarchy_enums:
        register_bie_enums_to_registry_base(
            bie_enum_type=bie_enum,
            bie_registry=bie_registry,
        )

    __register_bie_enum_sub_super_set_relations(
        hierarchy_enums=hierarchy_enums,
        bie_registry=bie_registry,
    )


def __expand_bie_leaf_enums_to_hierarchy_enums(
    leaf_enums: list,
) -> list:
    hierarchy_set: Set[Type[BieEnums]] = set()

    for leaf_enum in leaf_enums:
        __add_bie_enum_and_parents_to_hierarchy_set(
            bie_enum_type=leaf_enum,
            hierarchy_set=hierarchy_set,
        )

    sorted_enums = sorted(
        hierarchy_set,
        key=lambda e: (
            __get_bie_enum_depth(
                bie_enum_type=e,
            ),
            e.__name__,
        ),
    )

    return sorted_enums


def __add_bie_enum_and_parents_to_hierarchy_set(
    bie_enum_type: Type[BieEnums],
    hierarchy_set: Set[Type[BieEnums]],
) -> None:
    if bie_enum_type in hierarchy_set:
        return

    hierarchy_set.add(bie_enum_type)

    parent = __get_direct_bie_enum_parent(
        bie_enum_type=bie_enum_type,
    )

    if parent is not None:
        __add_bie_enum_and_parents_to_hierarchy_set(
            bie_enum_type=parent,
            hierarchy_set=hierarchy_set,
        )


def __get_direct_bie_enum_parent(
    bie_enum_type: Type[BieEnums],
) -> Optional[Type[BieEnums]]:
    if bie_enum_type == BieEnums:
        return None

    parent = bie_enum_type.__bases__[0]

    if not issubclass(parent, BieEnums):
        return None

    return parent


def __get_bie_enum_depth(
    bie_enum_type: Type[BieEnums],
) -> int:
    depth = 0

    current = bie_enum_type

    while current != BieEnums:
        parent = __get_direct_bie_enum_parent(
            bie_enum_type=current,
        )

        if parent is None:
            break

        depth += 1
        current = parent

    return depth


def __register_bie_enum_sub_super_set_relations(
    hierarchy_enums: list,
    bie_registry: BieIdRegistries,
) -> None:
    for bie_enum_type in hierarchy_enums:
        parent = __get_direct_bie_enum_parent(
            bie_enum_type=bie_enum_type,
        )

        if parent is None:
            continue

        bie_registry.register_bie_relation(
            bie_place_1_id=bie_enum_type.enum_bie_identity,
            bie_place_2_id=parent.enum_bie_identity,
            bie_relation_type_id=BieCoreRelationTypes.BIE_SUB_SUPER_SETS.item_bie_identity,
        )
