from bclearer_orchestration_services.identification_services.b_identity_ecosystem.bie_id_creation_module.common_knowledge.types.bie_vector_structure_types import (
    BieVectorStructureTypes,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.bie_id_creation_module.general_objects.bie_id_from_type_and_vector_creator import (
    create_bie_id_from_type_and_vector,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.bie_id_creation_module.identity_vectors.bie_identity_vector_base import (
    BieIdentityVectorBase,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.objects.bie_ids import (
    BieIds,
)


def create_bie_id_from_identity_vector(
    identity_vector: BieIdentityVectorBase,
) -> BieIds:
    return _create_bie_id_from_identity_vector(
        identity_vector=identity_vector,
    )


def _create_bie_id_from_identity_vector(
    identity_vector: BieIdentityVectorBase,
) -> BieIds:
    if not isinstance(
        identity_vector,
        BieIdentityVectorBase,
    ):
        raise TypeError(
            "identity_vector must be an instance of BieIdentityVectorBase"
        )

    if (
        identity_vector.bie_vector_structure_type
        == BieVectorStructureTypes.ZERO_DIMENSIONAL
    ):
        _validate_zero_dimensional_vector(
            identity_vector=identity_vector,
        )

        return BieIds(int_value=0)

    return create_bie_id_from_type_and_vector(
        input_objects_vector=identity_vector.input_objects(),
        bie_vector_structure_type=identity_vector.bie_vector_structure_type,
        bie_domain_type=identity_vector.bie_domain_type,
    )


def _validate_zero_dimensional_vector(
    identity_vector: BieIdentityVectorBase,
) -> None:
    if (
        identity_vector.bie_domain_type
        is not None
    ):
        raise ValueError(
            "Zero-dimensional identity vector must not have a bie_domain_type"
        )

    if identity_vector.input_objects():
        raise ValueError(
            "Zero-dimensional identity vector must not have input_objects"
        )
