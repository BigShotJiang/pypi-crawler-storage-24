from typing import Optional

from bclearer_orchestration_services.identification_services.b_identity_ecosystem.bie_id_creation_module.common_knowledge.types.bie_vector_structure_types import (
    BieVectorStructureTypes,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.bie_id_creation_module.identity_vectors.bie_identity_vector_base import (
    BieIdentityVectorBase,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.common_knowledge.bie_enums import (
    BieEnums,
)


class EmptyUntypedIdentityVector(
    BieIdentityVectorBase,
):
    @property
    def bie_domain_type(
        self,
    ) -> Optional[BieEnums]:
        return None

    @property
    def bie_vector_structure_type(
        self,
    ) -> BieVectorStructureTypes:
        return (
            BieVectorStructureTypes.ZERO_DIMENSIONAL
        )

    def input_objects(self) -> list:
        return []
