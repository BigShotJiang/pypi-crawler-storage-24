from abc import ABC, abstractmethod
from typing import Optional

from bclearer_orchestration_services.identification_services.b_identity_ecosystem.bie_id_creation_module.common_knowledge.types.bie_vector_structure_types import (
    BieVectorStructureTypes,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.common_knowledge.bie_enums import (
    BieEnums,
)


class BieIdentityVectorBase(ABC):
    @property
    @abstractmethod
    def bie_domain_type(
        self,
    ) -> Optional[BieEnums]:
        raise NotImplementedError

    @property
    @abstractmethod
    def bie_vector_structure_type(
        self,
    ) -> BieVectorStructureTypes:
        raise NotImplementedError

    @abstractmethod
    def input_objects(self) -> list:
        raise NotImplementedError
