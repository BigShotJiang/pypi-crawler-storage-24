RFC_4648_SYMBOL_SET_BASE32_CHARS = (
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"
)

RFC_4648_SYMBOL_SET_BASE32_ALPHABET = list(
    RFC_4648_SYMBOL_SET_BASE32_CHARS,
)

RFC_4648_BASE32_TO_INT = {
    char: index
    for index, char in enumerate(
        RFC_4648_SYMBOL_SET_BASE32_ALPHABET
    )
}


def convert_base32_to_int(
    base32_value: str,
) -> int:
    if base32_value is None:
        raise ValueError("base32_value must not be None")

    value = base32_value.strip().upper()
    if not value:
        raise ValueError("base32_value must not be empty")

    result = 0
    for char in value:
        if char not in RFC_4648_BASE32_TO_INT:
            raise ValueError(
                f"Invalid base32 character: {char!r}"
            )
        result = (
            (result << 5)
            | RFC_4648_BASE32_TO_INT[char]
        )

    return result
