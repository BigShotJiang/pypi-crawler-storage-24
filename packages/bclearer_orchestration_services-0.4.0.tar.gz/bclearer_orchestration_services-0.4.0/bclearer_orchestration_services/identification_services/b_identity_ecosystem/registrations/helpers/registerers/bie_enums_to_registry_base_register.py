from typing import Type

from bclearer_orchestration_services.identification_services.b_identity_ecosystem.common_knowledge.bie_enums import (
    BieEnums,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.objects.bie_id_registries import (
    BieIdRegistries,
)
from bclearer_orchestration_services.identification_services.naming_service.b_sequence_names import (
    BSequenceNames,
)


def register_bie_enums_to_registry_base(
    bie_enum_leaf_type: Type[BieEnums],
    bie_registry: BieIdRegistries,
) -> None:
    __register_bie_enum_object_type(
        bie_enum_leaf_type=bie_enum_leaf_type,
        bie_registry=bie_registry,
    )

    __register_bie_enum_object_instances(
        bie_enum_type=bie_enum_leaf_type,
        bie_registry=bie_registry,
    )


def __register_bie_enum_object_type(
    bie_enum_leaf_type: Type[BieEnums],
    bie_registry: BieIdRegistries,
) -> None:
    bie_sequence_name = BSequenceNames(
        initial_b_sequence_name_list=[
            bie_enum_leaf_type.b_enum_name()
        ]
    )

    bie_id_type_id = (
        _get_bie_enum_parent_type_id(
            bie_enum_type=bie_enum_leaf_type,
        )
    )

    bie_item_id = (
        bie_enum_leaf_type.enum_bie_identity
    )

    if bie_id_type_id is None:
        bie_registry.register_bie_id_if_required(
            bie_item_id=bie_item_id,
            bie_sequence_name=bie_sequence_name,
            bie_id_type_id=None,
        )

        return

    bie_registry.register_bie_id_if_required(
        bie_item_id=bie_item_id,
        bie_sequence_name=bie_sequence_name,
        bie_id_type_id=bie_id_type_id,
    )


def _get_bie_enum_parent_type_id(
    bie_enum_type: Type[BieEnums],
):
    if bie_enum_type == BieEnums:
        return None

    bie_enum_parent = (
        bie_enum_type.__bases__[0]
    )

    if issubclass(bie_enum_parent, BieEnums):
        return (
            bie_enum_parent.enum_bie_identity
        )

    return None


def __register_bie_enum_object_instances(
    bie_registry: BieIdRegistries,
    bie_enum_type: Type[BieEnums],
) -> None:
    for bie_enum_item in bie_enum_type:
        __register_bie_enum_item(
            bie_bclearer_processing_registry=bie_registry,
            bie_enum_item=bie_enum_item,
        )


def __register_bie_enum_item(
    bie_bclearer_processing_registry: BieIdRegistries,
    bie_enum_item,
) -> None:
    if bie_enum_item.name == "NOT_SET":
        return

    if isinstance(
        bie_enum_item, BieEnums
    ):
        b_sequence_name_component = (
            bie_enum_item.b_enum_item_name
        )

    else:
        b_sequence_name_component = (
            bie_enum_item.b_enum_item_name
        )

    bie_sequence_name = BSequenceNames(
        initial_b_sequence_name_list=[
            b_sequence_name_component
        ]
    )

    bie_bclearer_processing_registry.register_bie_id_and_type_instance(
        bie_id_type_id=bie_enum_item.enum_bie_identity,
        bie_sequence_name=bie_sequence_name,
        bie_item_id=bie_enum_item.item_bie_identity,
    )
