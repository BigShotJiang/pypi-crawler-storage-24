from bclearer_orchestration_services.identification_services.b_identity_ecosystem.bie_id_creation_module.common_knowledge.types.bie_vector_structure_types import (
    BieVectorStructureTypes,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.bie_id_creation_module.general_objects.bie_id_from_type_and_vector_creator import (
    create_bie_id_from_type_and_vector,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.common_knowledge.bie_core_domain_types import (
    BieCoreDomainTypes,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.registrations.helpers.registerers.bie_id_issue_requests import (
    BieIdIssueRequests,
    BieIdIssueScopes,
    EntityBieIdRequest,
    RelationBieIdRequest,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.registrations.helpers.registerers.bie_id_issue_result import (
    BieIdIssueResult,
    BieIdRegistrationTargets,
)
from bclearer_orchestration_services.identification_services.naming_service.b_sequence_names import (
    BSequenceNames,
)


def create_and_register_bie_id(
    registry,
    request: BieIdIssueRequests,
) -> BieIdIssueResult:
    from bclearer_orchestration_services.identification_services.b_identity_ecosystem.objects.bie_id_registries import (
        BieIdRegistries,
    )

    if not isinstance(registry, BieIdRegistries):
        raise TypeError(
            "registry must be a BieIdRegistries instance"
        )

    if isinstance(request, EntityBieIdRequest):
        return __create_and_register_entity_bie_id(
            registry=registry,
            request=request,
        )

    if isinstance(request, RelationBieIdRequest):
        return __create_and_register_relation_bie_id(
            registry=registry,
            request=request,
        )

    raise TypeError(
        f"Unsupported request type: {type(request)}"
    )


def __create_and_register_entity_bie_id(
    registry,
    request: EntityBieIdRequest,
) -> BieIdIssueResult:
    bie_id = create_bie_id_from_type_and_vector(
        input_objects_vector=list(request.input_objects),
        bie_vector_structure_type=request.bie_vector_structure_type,
        bie_domain_type=request.bie_domain_type,
    )

    was_new = not registry.contains_bie_id(
        bie_id=bie_id,
        bie_id_type_id=request.bie_id_type_id,
    )

    registry.register_bie_id_if_required(
        bie_item_id=bie_id,
        bie_sequence_name=request.b_sequence_name,
        bie_id_type_id=request.bie_id_type_id,
        is_preferred_b_sequence_name=request.is_preferred_b_sequence_name,
    )

    if request.bie_id_type_id is not None:
        registry.register_bie_id_type_instance(
            bie_type_id=request.bie_id_type_id,
            bie_instance_id=bie_id,
        )

    registration_target = __get_entity_registration_target(
        issue_scope=request.issue_scope,
    )

    return BieIdIssueResult(
        bie_id=bie_id,
        was_new=was_new,
        registration_target=registration_target,
    )


def __create_and_register_relation_bie_id(
    registry,
    request: RelationBieIdRequest,
) -> BieIdIssueResult:
    relation_signature_bie_id = create_bie_id_from_type_and_vector(
        input_objects_vector=[
            request.bie_place_1_id,
            request.bie_place_2_id,
            request.bie_relation_type_id,
        ],
        bie_vector_structure_type=BieVectorStructureTypes.MULTI_DIMENSIONAL_ORDER_SENSITIVE,
        bie_domain_type=None,
    )

    relation_signature_type_id = (
        request.relation_signature_type_id
    )

    if relation_signature_type_id is None:
        relation_signature_type_id = (
            BieCoreDomainTypes.BIE_RELATION_SIGNATURES.item_bie_identity
        )

    relation_signature_name = (
        __get_relation_signature_b_sequence_name(
            request=request,
        )
    )

    was_new = not registry.contains_bie_id(
        bie_id=relation_signature_bie_id,
        bie_id_type_id=relation_signature_type_id,
    )

    registry.register_bie_id_if_required(
        bie_item_id=relation_signature_bie_id,
        bie_sequence_name=relation_signature_name,
        bie_id_type_id=relation_signature_type_id,
        is_preferred_b_sequence_name=request.is_preferred_b_sequence_name,
    )

    if relation_signature_type_id is not None:
        registry.register_bie_id_type_instance(
            bie_type_id=relation_signature_type_id,
            bie_instance_id=relation_signature_bie_id,
        )

    registry.register_bie_relation(
        bie_place_1_id=request.bie_place_1_id,
        bie_place_2_id=request.bie_place_2_id,
        bie_relation_type_id=request.bie_relation_type_id,
    )

    return BieIdIssueResult(
        bie_id=relation_signature_bie_id,
        was_new=was_new,
        registration_target=BieIdRegistrationTargets.RELATION_SIGNATURE,
    )


def __get_entity_registration_target(
    issue_scope: BieIdIssueScopes,
) -> BieIdRegistrationTargets:
    if issue_scope == BieIdIssueScopes.OBJECT:
        return BieIdRegistrationTargets.OBJECT

    if issue_scope == BieIdIssueScopes.INFRASTRUCTURE:
        return BieIdRegistrationTargets.INFRASTRUCTURE

    raise TypeError(
        f"Unsupported issue scope: {issue_scope}"
    )


def __get_relation_signature_b_sequence_name(
    request: RelationBieIdRequest,
) -> BSequenceNames:
    if request.b_sequence_name is not None:
        return request.b_sequence_name

    return BSequenceNames(
        initial_b_sequence_name_list=[
            "relation_signature",
            str(request.bie_place_1_id),
            str(request.bie_relation_type_id),
            str(request.bie_place_2_id),
        ]
    )
