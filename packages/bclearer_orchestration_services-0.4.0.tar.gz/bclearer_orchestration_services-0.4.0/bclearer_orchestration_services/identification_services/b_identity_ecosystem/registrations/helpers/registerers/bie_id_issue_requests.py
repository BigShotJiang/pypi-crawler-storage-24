from dataclasses import dataclass
from enum import auto
from typing import Optional, Tuple, Union
import warnings

from bclearer_orchestration_services.identification_services.b_identity_ecosystem.bie_id_creation_module.common_knowledge.types.bie_vector_structure_types import (
    BieVectorStructureTypes,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.common_knowledge.bie_enums import (
    BieEnums,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.objects.bie_ids import (
    BieIds,
)
from bclearer_orchestration_services.identification_services.naming_service.b_sequence_names import (
    BSequenceNames,
)


class BieIdIssueScopes(
    BieEnums
):
    OBJECT = auto()
    INFRASTRUCTURE = auto()


@dataclass(frozen=True)
class EntityBieIdRequest:
    input_objects: Tuple[object, ...]
    bie_id_type_id: Optional[BieIds]
    b_sequence_name: BSequenceNames
    issue_scope: BieIdIssueScopes
    bie_vector_structure_type: BieVectorStructureTypes = (
        BieVectorStructureTypes.MULTI_DIMENSIONAL_ORDER_SENSITIVE
    )
    bie_domain_type: Optional[BieEnums] = None
    is_preferred_b_sequence_name: bool = False


class ObjectBieIdRequest(
    EntityBieIdRequest
):
    def __init__(
        self,
        input_objects,
        bie_id_type_id: BieIds,
        b_sequence_name: BSequenceNames,
        bie_vector_structure_type: BieVectorStructureTypes = BieVectorStructureTypes.MULTI_DIMENSIONAL_ORDER_SENSITIVE,
        bie_domain_type: Optional[BieEnums] = None,
        is_preferred_b_sequence_name: bool = False,
    ):
        warnings.warn(
            "ObjectBieIdRequest is deprecated. Use EntityBieIdRequest(issue_scope=BieIdIssueScopes.OBJECT).",
            DeprecationWarning,
            stacklevel=2,
        )

        super().__init__(
            input_objects=tuple(input_objects),
            bie_id_type_id=bie_id_type_id,
            b_sequence_name=b_sequence_name,
            issue_scope=BieIdIssueScopes.OBJECT,
            bie_vector_structure_type=bie_vector_structure_type,
            bie_domain_type=bie_domain_type,
            is_preferred_b_sequence_name=is_preferred_b_sequence_name,
        )


class InfrastructureBieIdRequest(
    EntityBieIdRequest
):
    def __init__(
        self,
        input_objects,
        bie_id_type_id: Optional[BieIds],
        b_sequence_name: BSequenceNames,
        bie_vector_structure_type: BieVectorStructureTypes = BieVectorStructureTypes.MULTI_DIMENSIONAL_ORDER_SENSITIVE,
        bie_domain_type: Optional[BieEnums] = None,
        is_preferred_b_sequence_name: bool = False,
    ):
        warnings.warn(
            "InfrastructureBieIdRequest is deprecated. Use EntityBieIdRequest(issue_scope=BieIdIssueScopes.INFRASTRUCTURE).",
            DeprecationWarning,
            stacklevel=2,
        )

        super().__init__(
            input_objects=tuple(input_objects),
            bie_id_type_id=bie_id_type_id,
            b_sequence_name=b_sequence_name,
            issue_scope=BieIdIssueScopes.INFRASTRUCTURE,
            bie_vector_structure_type=bie_vector_structure_type,
            bie_domain_type=bie_domain_type,
            is_preferred_b_sequence_name=is_preferred_b_sequence_name,
        )


@dataclass(frozen=True)
class RelationBieIdRequest:
    bie_place_1_id: BieIds
    bie_place_2_id: BieIds
    bie_relation_type_id: BieIds
    b_sequence_name: Optional[BSequenceNames] = None
    relation_signature_type_id: Optional[BieIds] = None
    is_preferred_b_sequence_name: bool = False


BieIdIssueRequests = Union[
    EntityBieIdRequest,
    ObjectBieIdRequest,
    InfrastructureBieIdRequest,
    RelationBieIdRequest,
]
