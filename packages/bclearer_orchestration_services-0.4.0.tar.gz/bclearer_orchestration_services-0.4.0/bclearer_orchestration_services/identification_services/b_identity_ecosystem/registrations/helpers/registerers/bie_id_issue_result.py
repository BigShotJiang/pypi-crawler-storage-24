from dataclasses import dataclass
from enum import auto
from typing import Tuple

from bclearer_orchestration_services.identification_services.b_identity_ecosystem.common_knowledge.bie_enums import (
    BieEnums,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.objects.bie_ids import (
    BieIds,
)


class BieIdRegistrationTargets(
    BieEnums
):
    OBJECT = auto()
    INFRASTRUCTURE = auto()
    RELATION_SIGNATURE = auto()


@dataclass(frozen=True)
class BieIdIssueResult:
    bie_id: BieIds
    was_new: bool
    registration_target: BieIdRegistrationTargets
    warnings: Tuple[str, ...] = tuple()
