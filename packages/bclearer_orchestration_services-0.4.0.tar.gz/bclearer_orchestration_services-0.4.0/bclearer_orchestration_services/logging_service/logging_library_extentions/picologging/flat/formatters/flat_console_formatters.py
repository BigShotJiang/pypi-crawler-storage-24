class FlatConsoleFormatters:
    pass
