class ProcessConsoleHandlers:
    pass
