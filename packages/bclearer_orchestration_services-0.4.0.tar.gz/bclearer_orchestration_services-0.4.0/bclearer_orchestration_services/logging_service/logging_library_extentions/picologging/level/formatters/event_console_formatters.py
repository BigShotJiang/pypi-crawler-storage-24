class EventConsoleFormatters:
    pass
