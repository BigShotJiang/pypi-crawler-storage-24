class EventLoggers:
    pass
