from enum import auto

from bclearer_orchestration_services.identification_services.b_identity_ecosystem.common_knowledge.bie_domain_types import (
    BieDomainTypes,
)


class BieSnapshotSumDirectionTypes(
    BieDomainTypes
):
    NOT_SET = auto()

    ANCESTORS = auto()

    DESCENDENTS = auto()
