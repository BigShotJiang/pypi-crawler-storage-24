from enum import auto

from bclearer_orchestration_services.identification_services.b_identity_ecosystem.common_knowledge.bie_domain_types import (
    BieDomainTypes,
)


class BieSnapshotDomainTypes(
    BieDomainTypes
):
    NOT_SET = auto()

    BIE_INDIVIDUAL_RUN_SNAPSHOTS = (
        auto()
    )

    MAXIMAL_SNAPSHOT_DOMAINS = auto()
