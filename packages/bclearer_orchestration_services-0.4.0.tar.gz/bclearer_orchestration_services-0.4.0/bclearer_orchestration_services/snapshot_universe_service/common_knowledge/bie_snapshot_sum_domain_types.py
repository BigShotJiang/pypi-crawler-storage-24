from enum import auto

from bclearer_orchestration_services.identification_services.b_identity_ecosystem.common_knowledge.bie_domain_types import (
    BieDomainTypes,
)


class BieSnapshotSumDomainTypes(
    BieDomainTypes
):
    NOT_SET = auto()

    SUM_OBJECTS = auto()
