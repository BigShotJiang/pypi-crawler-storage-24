from bclearer_orchestration_services.file_system_snapshot_service.universe.bie.bie_id_creators.file_system_snapshot_identity_vectors import (
    FileSystemSnapshotObjectIdentityVector,
    FileSystemSnapshotObjectIdentityVectorPlaces,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.bie_id_creation_module.bie_id_creation_facade import (
    BieIdCreationFacade,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.objects.bie_ids import (
    BieIds,
)
from bclearer_orchestration_services.snapshot_universe_service.objects.snapshot_domains import (
    SnapshotDomains,
)


def calculate_file_system_snapshot_object_identity_vector(
    owning_snapshot_domain_bie_id: BieIds,
    base_system_object_bie_id: BieIds,
) -> FileSystemSnapshotObjectIdentityVector:
    return FileSystemSnapshotObjectIdentityVector(
        places=FileSystemSnapshotObjectIdentityVectorPlaces(
            owning_snapshot_domain_bie_id=owning_snapshot_domain_bie_id,
            base_system_object_bie_id=base_system_object_bie_id,
        )
    )


def issue_file_system_snapshot_object_bie_id(
    identity_vector: FileSystemSnapshotObjectIdentityVector,
) -> BieIds:
    return BieIdCreationFacade.create_bie_id_from_identity_vector(
        identity_vector=identity_vector,
    )


def create_file_system_snapshot_object_bie_id(
    base_system_object_bie_id: BieIds,
    owning_snapshot_domain: SnapshotDomains,
) -> BieIds:
    identity_vector = calculate_file_system_snapshot_object_identity_vector(
        owning_snapshot_domain_bie_id=owning_snapshot_domain.bie_id,
        base_system_object_bie_id=base_system_object_bie_id,
    )

    return issue_file_system_snapshot_object_bie_id(
        identity_vector=identity_vector,
    )
