from pathlib import Path

from bclearer_orchestration_services.file_system_snapshot_service.universe.bie.bie_id_creators.file_system_snapshot_identity_vectors import (
    RelativePathExtendedObjectIdentityVector,
    RelativePathExtendedObjectIdentityVectorPlaces,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.bie_id_creation_module.bie_id_creation_facade import (
    BieIdCreationFacade,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.objects.bie_ids import (
    BieIds,
)


def calculate_relative_path_extended_object_identity_vector(
    relative_path: Path,
) -> RelativePathExtendedObjectIdentityVector:
    return RelativePathExtendedObjectIdentityVector(
        places=RelativePathExtendedObjectIdentityVectorPlaces(
            relative_path=relative_path,
        )
    )


def issue_relative_path_extended_object_bie_id(
    identity_vector: RelativePathExtendedObjectIdentityVector,
) -> BieIds:
    return BieIdCreationFacade.create_bie_id_from_identity_vector(
        identity_vector=identity_vector,
    )


def create_relative_path_extended_object_bie_id(
    relative_path: Path,
) -> BieIds:
    identity_vector = calculate_relative_path_extended_object_identity_vector(
        relative_path=relative_path,
    )

    return issue_relative_path_extended_object_bie_id(
        identity_vector=identity_vector,
    )
