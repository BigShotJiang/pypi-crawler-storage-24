from pathlib import Path
from typing import NamedTuple, Optional

from bclearer_orchestration_services.file_system_snapshot_service.universe.common_knowledge.bie_file_system_snapshot_domain_types import (
    BieFileSystemSnapshotDomainTypes,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.bie_id_creation_module.common_knowledge.types.bie_vector_structure_types import (
    BieVectorStructureTypes,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.bie_id_creation_module.identity_vectors.bie_identity_vector_base import (
    BieIdentityVectorBase,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.common_knowledge.bie_enums import (
    BieEnums,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.objects.bie_ids import (
    BieIds,
)


def _validate_places(
    places: NamedTuple,
) -> None:
    if not isinstance(places, tuple):
        raise TypeError(
            "places must be a NamedTuple"
        )

    for field_name in places._fields:
        value = getattr(places, field_name)

        if value is None:
            raise ValueError(
                f"places field '{field_name}' must not be None"
            )


# --- Relative Path ---


class RelativePathExtendedObjectIdentityVectorPlaces(
    NamedTuple,
):
    relative_path: Path


class RelativePathExtendedObjectIdentityVector(
    BieIdentityVectorBase,
):
    def __init__(
        self,
        places: RelativePathExtendedObjectIdentityVectorPlaces,
    ):
        _validate_places(places=places)

        self._places = places

    @property
    def bie_domain_type(
        self,
    ) -> Optional[BieEnums]:
        return None

    @property
    def bie_vector_structure_type(
        self,
    ) -> BieVectorStructureTypes:
        return (
            BieVectorStructureTypes.MULTI_DIMENSIONAL_ORDER_SENSITIVE
        )

    def input_objects(self) -> list:
        return [
            BieFileSystemSnapshotDomainTypes.BIE_RELATIVE_PATHS.item_bie_identity,
            self._places.relative_path,
        ]


# --- File Reference Number ---


class FileReferenceNumberExtendedObjectIdentityVectorPlaces(
    NamedTuple,
):
    operating_system_bie_id: BieIds
    drive: str
    file_reference_number: str


class FileReferenceNumberExtendedObjectIdentityVector(
    BieIdentityVectorBase,
):
    def __init__(
        self,
        places: FileReferenceNumberExtendedObjectIdentityVectorPlaces,
    ):
        _validate_places(places=places)

        self._places = places

    @property
    def bie_domain_type(
        self,
    ) -> Optional[BieEnums]:
        return None

    @property
    def bie_vector_structure_type(
        self,
    ) -> BieVectorStructureTypes:
        return (
            BieVectorStructureTypes.MULTI_DIMENSIONAL_ORDER_SENSITIVE
        )

    def input_objects(self) -> list:
        return [
            BieFileSystemSnapshotDomainTypes.BIE_FILE_REFERENCE_NUMBERS.item_bie_identity,
            BieFileSystemSnapshotDomainTypes.BIE_FILE_SYSTEM_SNAPSHOT_BASE_SYSTEM_BIE_IDS.item_bie_identity,
            self._places.operating_system_bie_id,
            self._places.drive,
            self._places.file_reference_number,
        ]


# --- File System Snapshot ---


class FileSystemSnapshotObjectIdentityVectorPlaces(
    NamedTuple,
):
    owning_snapshot_domain_bie_id: BieIds
    base_system_object_bie_id: BieIds


class FileSystemSnapshotObjectIdentityVector(
    BieIdentityVectorBase,
):
    def __init__(
        self,
        places: FileSystemSnapshotObjectIdentityVectorPlaces,
    ):
        _validate_places(places=places)

        self._places = places

    @property
    def bie_domain_type(
        self,
    ) -> Optional[BieEnums]:
        return None

    @property
    def bie_vector_structure_type(
        self,
    ) -> BieVectorStructureTypes:
        return (
            BieVectorStructureTypes.MULTI_DIMENSIONAL_ORDER_SENSITIVE
        )

    def input_objects(self) -> list:
        return [
            BieFileSystemSnapshotDomainTypes.BIE_FILE_SYSTEM_SNAPSHOT_BASE_SNAPSHOT_BIE_IDS.item_bie_identity,
            self._places.owning_snapshot_domain_bie_id,
            self._places.base_system_object_bie_id,
        ]
