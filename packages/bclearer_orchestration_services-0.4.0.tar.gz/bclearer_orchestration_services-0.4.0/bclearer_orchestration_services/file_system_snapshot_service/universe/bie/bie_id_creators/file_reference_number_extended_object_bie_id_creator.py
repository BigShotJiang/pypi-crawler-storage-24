from bclearer_core.infrastructure.session.operating_system.operating_system_objects import (
    OperatingSystemObjects,
)
from bclearer_interop_services.file_system_service.objects.file_system_objects import (
    FileSystemObjects,
)
from bclearer_orchestration_services.file_system_snapshot_service.universe.bie.bie_id_creators.file_system_snapshot_identity_vectors import (
    FileReferenceNumberExtendedObjectIdentityVector,
    FileReferenceNumberExtendedObjectIdentityVectorPlaces,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.bie_id_creation_module.bie_id_creation_facade import (
    BieIdCreationFacade,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.objects.bie_ids import (
    BieIds,
)


def calculate_file_reference_number_extended_object_identity_vector(
    operating_system_bie_id: BieIds,
    drive: str,
    file_reference_number: str,
) -> FileReferenceNumberExtendedObjectIdentityVector:
    return FileReferenceNumberExtendedObjectIdentityVector(
        places=FileReferenceNumberExtendedObjectIdentityVectorPlaces(
            operating_system_bie_id=operating_system_bie_id,
            drive=drive,
            file_reference_number=file_reference_number,
        )
    )


def issue_file_reference_number_extended_object_bie_id(
    identity_vector: FileReferenceNumberExtendedObjectIdentityVector,
) -> BieIds:
    return BieIdCreationFacade.create_bie_id_from_identity_vector(
        identity_vector=identity_vector,
    )


def create_file_reference_number_extended_object_bie_id(
    file_system_object: FileSystemObjects,
    file_reference_number: str,
) -> BieIds:
    operating_system_object = (
        OperatingSystemObjects()
    )

    identity_vector = calculate_file_reference_number_extended_object_identity_vector(
        operating_system_bie_id=operating_system_object.bie_id,
        drive=file_system_object.drive,
        file_reference_number=file_reference_number,
    )

    return issue_file_reference_number_extended_object_bie_id(
        identity_vector=identity_vector,
    )
