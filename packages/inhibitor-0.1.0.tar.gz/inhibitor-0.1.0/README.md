# inhibitor

Python client for the **Inhibitor** policy compliance inference API. Use it to evaluate natural language content against your policies and get ALLOW / MODIFY / BLOCK decisions.

## Installation

```bash
pip install inhibitor
```

## Quick start

```python
from inhibitor import InhibitorClient

client = InhibitorClient(
    api_key="your-api-key",
    base_url="https://your-inhibitor-api.com",  # or http://localhost:8000 for local
)

response = client.inference.query("Can I share this document with external partners?")
print(response.final_decision)   # ALLOW | MODIFY | BLOCK
print(response.explanation)      # Human-readable explanation
print(response.suggestion)       # Suggested rewording (if MODIFY)
print(response.redacted_query)   # Redacted version (if applicable)
```

## Configuration

| Parameter   | Description |
|------------|-------------|
| `api_key`  | **Required.** Your Inhibitor API key (from the dashboard). |
| `base_url` | Base URL of the Inhibitor API (default: `http://localhost:8000`). |
| `timeout`  | Request timeout in seconds (default: `60.0`). |
| `headers`  | Optional extra HTTP headers. |

## Inference API

### Sync

```python
response = client.inference.query(
    "User message to evaluate",
    metadata={"authenticated": True},
    source="api",
    execution_mode="standard",
)
```

### Async

```python
from inhibitor import AsyncInhibitorClient

async with AsyncInhibitorClient(api_key="...", base_url="...") as client:
    response = await client.inference.query_async("User message to evaluate")
```

### Parameters

- **query** (str): Natural language content to evaluate.
- **metadata** (dict, optional): Key-value context (e.g. `{"authenticated": true}`).
- **additional_metadata** (dict, optional): Stored with the inference log.
- **source** (str): Request source label (`"web"`, `"mobile"`, `"api"`, etc.). Default: `"api"`.
- **execution_mode** (str): `"standard"` (full pipeline) or `"fast"` (LLM-only). Default: `"standard"`.
- **app_id** (str, optional): App UUID; required for `execution_mode="fast"` if not using `email_id`.
- **email_id** (str, optional): User email to resolve app (for fast mode).

### Response

`InferenceResponse` includes:

- `query`, `final_decision` (ALLOW | MODIFY | BLOCK), `final_score`
- `matched_policies`, `model_results` (per-rule results)
- `explanation`, `suggestion`, `redacted_query`
- `processing_time_seconds`, `mode`

## Exceptions

- **InhibitorAuthError**: Invalid or expired API key (401).
- **InhibitorValidationError**: Bad request or missing parameters (400).
- **InhibitorAPIError**: Other API errors (4xx/5xx), with `status_code`, `detail`, `response_body`.

## Using the request model

```python
from inhibitor import InhibitorClient, InferenceRequest

client = InhibitorClient(api_key="...", base_url="...")
req = InferenceRequest(
    query="Should I send this email?",
    metadata={"channel": "email"},
)
response = client.inference.run(req)
```

## License

MIT
