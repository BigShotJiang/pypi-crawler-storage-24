"""Request/response models for the Inhibitor inference API."""

from typing import Any

from pydantic import BaseModel, Field


class InferenceRequest(BaseModel):
    """Request payload for POST /v1/inference."""

    query: str = Field(..., min_length=1, description="Natural language query to evaluate")
    metadata: dict[str, Any] | None = Field(
        default=None,
        description="Optional metadata (e.g. {\"authenticated\": true})",
    )
    additional_metadata: dict[str, Any] | None = Field(
        default=None,
        description="Additional metadata stored with the inference log",
    )


class RuleResult(BaseModel):
    """Result from a single rule's model inference."""

    rule_name: str
    rule_id: str
    predicted_label: str
    decision: str  # ALLOW | MODIFY | BLOCK
    confidence: float
    all_probabilities: dict[str, float]
    rule_explanation: str | None = None


class InferenceResponse(BaseModel):
    """Response from POST /v1/inference."""

    query: str
    final_decision: str  # ALLOW | MODIFY | BLOCK
    final_score: float
    matched_policies: list[str]
    model_results: list[RuleResult]
    explanation: str | None = None
    suggestion: str | None = None
    redacted_query: str | None = None
    processing_time_seconds: float | None = None
    mode: str | None = None  # e.g. "graphrag" | "llm" when returned by API
