"""HTTP client and API wrappers for the Inhibitor inference API."""

from typing import Any

import httpx

from inhibitor.exceptions import (
    InhibitorAPIError,
    InhibitorAuthError,
    InhibitorValidationError,
)
from inhibitor.models import InferenceRequest, InferenceResponse


def _detail_from_response(response: httpx.Response) -> str | None:
    try:
        body = response.json()
        if isinstance(body, dict) and "detail" in body:
            d = body["detail"]
            return d if isinstance(d, str) else str(d)
    except Exception:
        pass
    return None


class InferenceAPI:
    """
    Wrapper for the /v1/inference endpoint.
    Use via :attr:`InhibitorClient.inference`.
    """

    def __init__(self, client: "InhibitorClient"):
        self._client = client

    def query(
        self,
        query: str,
        *,
        metadata: dict[str, Any] | None = None,
        additional_metadata: dict[str, Any] | None = None,
        source: str = "api",
        execution_mode: str = "standard",
        app_id: str | None = None,
        email_id: str | None = None,
    ) -> InferenceResponse:
        """
        Run policy compliance inference on a natural language query.

        :param query: The user message or content to evaluate against policies.
        :param metadata: Optional key-value metadata (e.g. {"authenticated": true}).
        :param additional_metadata: Optional metadata stored with the inference log.
        :param source: Request source label (e.g. "web", "mobile", "api"). Default ``"api"``.
        :param execution_mode: ``"standard"`` (full pipeline) or ``"fast"`` (LLM-only).
        :param app_id: Optional app UUID; required for ``execution_mode="fast"`` if not using ``email_id``.
        :param email_id: Optional user email to resolve app; used for ``execution_mode="fast"``.
        :return: :class:`InferenceResponse` with decision (ALLOW/MODIFY/BLOCK), explanation, etc.
        :raises InhibitorAuthError: Invalid or expired API key.
        :raises InhibitorValidationError: Missing/invalid parameters (e.g. fast mode without app_id/email_id).
        :raises InhibitorAPIError: Server or API error.
        """
        request = InferenceRequest(
            query=query,
            metadata=metadata,
            additional_metadata=additional_metadata,
        )
        return self._client._post_inference(
            request,
            source=source,
            execution_mode=execution_mode,
            app_id=app_id,
            email_id=email_id,
        )

    def run(
        self,
        request: InferenceRequest,
        *,
        source: str = "api",
        execution_mode: str = "standard",
        app_id: str | None = None,
        email_id: str | None = None,
    ) -> InferenceResponse:
        """
        Run inference with a full :class:`InferenceRequest` object.

        Same as :meth:`query` but accepts a pre-built request model.
        """
        return self._client._post_inference(
            request,
            source=source,
            execution_mode=execution_mode,
            app_id=app_id,
            email_id=email_id,
        )


class InhibitorClient:
    """
    Client for the Inhibitor policy compliance inference API.

    Authenticate with an API key (from your Inhibitor dashboard).
    Base URL should point at your Inhibitor backend (e.g. ``https://api.yourdomain.com``).
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "http://localhost:8000",
        *,
        timeout: float = 60.0,
        headers: dict[str, str] | None = None,
    ):
        """
        :param api_key: Your Inhibitor API key (required for /v1/inference).
        :param base_url: Base URL of the Inhibitor API (no trailing slash).
        :param timeout: Request timeout in seconds.
        :param headers: Optional extra HTTP headers.
        """
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._headers = dict(headers or {})
        self._headers.setdefault("X-API-Key", api_key)
        self._headers.setdefault("Content-Type", "application/json")
        self._headers.setdefault("Accept", "application/json")

        self.inference = InferenceAPI(self)

    def _post_inference(
        self,
        request: InferenceRequest,
        *,
        source: str = "api",
        execution_mode: str = "standard",
        app_id: str | None = None,
        email_id: str | None = None,
    ) -> InferenceResponse:
        url = f"{self.base_url}/v1/inference"
        params: dict[str, str] = {
            "source": source,
            "execution_mode": execution_mode,
        }
        if app_id:
            params["app_id"] = app_id
        if email_id:
            params["email_id"] = email_id

        with httpx.Client(timeout=self.timeout, headers=self._headers) as http:
            response = http.post(
                url,
                json=request.model_dump(mode="json"),
                params=params,
            )

        if response.status_code == 401:
            detail = _detail_from_response(response)
            raise InhibitorAuthError(detail or "Invalid or expired API key", status_code=401)

        if response.status_code == 400:
            detail = _detail_from_response(response)
            raise InhibitorValidationError(detail or "Bad request", status_code=400)

        if response.status_code == 404:
            detail = _detail_from_response(response)
            raise InhibitorAPIError(
                detail or "Not found",
                status_code=404,
                detail=detail,
                response_body=response.text,
            )

        if response.status_code >= 400:
            detail = _detail_from_response(response)
            raise InhibitorAPIError(
                detail or response.reason_phrase or "API error",
                status_code=response.status_code,
                detail=detail,
                response_body=response.text,
            )

        data = response.json()
        return InferenceResponse.model_validate(data)


class AsyncInhibitorClient(InhibitorClient):
    """Async client for the Inhibitor API. Use ``async with`` or call ``aclose()`` when done."""

    def __init__(
        self,
        api_key: str,
        base_url: str = "http://localhost:8000",
        *,
        timeout: float = 60.0,
        headers: dict[str, str] | None = None,
    ):
        super().__init__(api_key=api_key, base_url=base_url, timeout=timeout, headers=headers)
        self.inference = AsyncInferenceAPI(self)

    async def _post_inference_async(
        self,
        request: InferenceRequest,
        *,
        source: str = "api",
        execution_mode: str = "standard",
        app_id: str | None = None,
        email_id: str | None = None,
    ) -> InferenceResponse:
        url = f"{self.base_url}/v1/inference"
        params: dict[str, str] = {
            "source": source,
            "execution_mode": execution_mode,
        }
        if app_id:
            params["app_id"] = app_id
        if email_id:
            params["email_id"] = email_id

        async with httpx.AsyncClient(timeout=self.timeout, headers=self._headers) as http:
            response = await http.post(
                url,
                json=request.model_dump(mode="json"),
                params=params,
            )

        if response.status_code == 401:
            detail = _detail_from_response(response)
            raise InhibitorAuthError(detail or "Invalid or expired API key", status_code=401)
        if response.status_code == 400:
            detail = _detail_from_response(response)
            raise InhibitorValidationError(detail or "Bad request", status_code=400)
        if response.status_code == 404:
            detail = _detail_from_response(response)
            raise InhibitorAPIError(
                detail or "Not found",
                status_code=404,
                detail=detail,
                response_body=response.text,
            )
        if response.status_code >= 400:
            detail = _detail_from_response(response)
            raise InhibitorAPIError(
                detail or response.reason_phrase or "API error",
                status_code=response.status_code,
                detail=detail,
                response_body=response.text,
            )
        data = response.json()
        return InferenceResponse.model_validate(data)

    async def aclose(self) -> None:
        """Close any underlying async resources. No-op for current implementation."""
        pass

    async def __aenter__(self) -> "AsyncInhibitorClient":
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.aclose()


class AsyncInferenceAPI(InferenceAPI):
    """Async inference API. Use :meth:`query_async`."""

    async def query_async(
        self,
        query: str,
        *,
        metadata: dict[str, Any] | None = None,
        additional_metadata: dict[str, Any] | None = None,
        source: str = "api",
        execution_mode: str = "standard",
        app_id: str | None = None,
        email_id: str | None = None,
    ) -> InferenceResponse:
        """Run policy compliance inference asynchronously."""
        request = InferenceRequest(
            query=query,
            metadata=metadata,
            additional_metadata=additional_metadata,
        )
        return await self._client._post_inference_async(
            request,
            source=source,
            execution_mode=execution_mode,
            app_id=app_id,
            email_id=email_id,
        )
