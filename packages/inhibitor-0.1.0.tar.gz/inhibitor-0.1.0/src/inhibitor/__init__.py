"""
Inhibitor — Python client for the Inhibitor policy compliance inference API.

Install::

    pip install inhibitor

Usage::

    from inhibitor import InhibitorClient

    client = InhibitorClient(api_key="your-api-key", base_url="https://api.example.com")
    response = client.inference.query("Can I share this document with external partners?")
    print(response.final_decision)  # ALLOW | MODIFY | BLOCK
    print(response.explanation)
"""

from inhibitor.client import InhibitorClient, AsyncInhibitorClient
from inhibitor.models import (
    InferenceRequest,
    InferenceResponse,
    RuleResult,
)
from inhibitor.exceptions import (
    InhibitorError,
    InhibitorAPIError,
    InhibitorAuthError,
    InhibitorValidationError,
)

__version__ = "0.1.0"
__all__ = [
    "InhibitorClient",
    "AsyncInhibitorClient",
    "InferenceRequest",
    "InferenceResponse",
    "RuleResult",
    "InhibitorError",
    "InhibitorAPIError",
    "InhibitorAuthError",
    "InhibitorValidationError",
]
