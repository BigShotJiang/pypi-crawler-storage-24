"""Custom exceptions for the Inhibitor client."""


class InhibitorError(Exception):
    """Base exception for all Inhibitor client errors."""

    def __init__(self, message: str, status_code: int | None = None):
        super().__init__(message)
        self.message = message
        self.status_code = status_code


class InhibitorAPIError(InhibitorError):
    """Raised when the API returns an error response (4xx/5xx)."""

    def __init__(
        self,
        message: str,
        status_code: int,
        detail: str | None = None,
        response_body: str | None = None,
    ):
        super().__init__(message, status_code=status_code)
        self.detail = detail
        self.response_body = response_body


class InhibitorAuthError(InhibitorError):
    """Raised when authentication fails (e.g. invalid or expired API key)."""

    def __init__(self, message: str, status_code: int = 401):
        super().__init__(message, status_code=status_code)


class InhibitorValidationError(InhibitorError):
    """Raised when request validation fails (e.g. missing or invalid parameters)."""

    def __init__(self, message: str, status_code: int = 400):
        super().__init__(message, status_code=status_code)
