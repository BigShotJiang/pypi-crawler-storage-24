# coding=utf8
""" Upgrade 1.1.1 to 2.3.0

Handles taking the existing 1.1.1 data and converting it to a usable format in
2.3.0
"""

__author__		= "Chris Nasr"
__copyright__	= "Ouroboros Coding Inc."
__version__		= "1.0.0"
__email__		= "chris@ouroboroscoding.com"
__created__		= "2026-01-17"

# Ouroboros imports
from config import config
import jsonb
from rest_mysql.Record_MySQL import Commands, DuplicateException, ESelect
from strings import uuid_strip_dashes

# Python imports
from os.path import abspath, expanduser, exists
from os import makedirs

# Pip imports
from pymysql.converters import escape_string

# Local imports
from brain.records import key, permission, user

def run():
	"""Run

	Main entry into the script, called by the upgrade module

	Returns:
		bool
	"""

	# Notify the user
	print('Running 1.1.1 to 2.3.0 Upgrade script')

	# Create the permission table
	permission.Permission.table_create()

	# Get the permission struct, just for the host
	dStruct = permission.Permission.struct()

	# Loop until we have no more permissions
	while True:

		# Fetch a single permission
		dRow = Commands.select(
			dStruct['host'],
			'SELECT * FROM `%(db)s`.`brain_permissions` LIMIT 1' % dStruct,
			ESelect.ROW
		)

		# If we got nothing, we're done
		if not dRow:
			break

		# Convert the rights from json
		dRow['rights'] = jsonb.decode(dRow['rights'])

		# Init the list of new records
		lRecords = [ ]

		# Step through each right
		for sName, dUUIDs in dRow['rights'].items():

			# Step through the UUIDs
			for sID, iRights in dUUIDs.items():

				# Add a record
				lRecords.append(
					permission.Permission({
						'_user': uuid_strip_dashes(dRow['user']),
						'_portal': dRow['portal'],
						'name': sName,
						'id': uuid_strip_dashes(sID),
						'rights': iRights
					})
				)

		# If we have any
		if lRecords:

			# Create them all
			if not permission.Permission.create_many(lRecords):
				return False

		# Delete the original permissions record
		dStruct['_id'] = dRow['_id']
		Commands.execute(
			dStruct['host'],
			"DELETE FROM `%(db)s`.`brain_permissions` " \
			"WHERE `_id` = '%(_id)s'" % dStruct
		)

	# Delete the old permissions tables
	Commands.execute(
		dStruct['host'],
		"DROP TABLE `%(db)s`.`brain_permissions`, " \
			"`%(db)s`.`brain_permissions_changes`" % dStruct
	)

	# Get Brain data folder
	sDataPath = config.brain.data('./.data')
	if '~' in sDataPath:
		sDataPath = expanduser(sDataPath)
	sDataPath = abspath(sDataPath)

	# If the path doesn't exist
	if not exists(sDataPath):
		makedirs(sDataPath)

	# Generate the name of the keys backup file
	sKeysFile = '%s/brain_v2_2_keys.json' % sDataPath

	# If the backup file already exists
	if exists(sKeysFile):

		# Load it
		lRecords = jsonb.load(sKeysFile)

	# Else, no backup yet
	else:

		# Get the keys struct
		dStruct = key.Key.struct()

		# Pull out all the records from the key table
		lRecords = Commands.select(
			dStruct['host'],
			'SELECT `_id`, ' \
				'UNIX_TIMESTAMP(`_created`) as `_created`, ' \
				'UNIX_TIMESTAMP(`_updated`) as `_updated`, ' \
				'`user`, `type` ' \
			'FROM `%(db)s`.`%(table)s` ORDER BY `_created`' % dStruct,
			ESelect.ALL
		)

		# Store them to a local file
		jsonb.store(lRecords, sKeysFile)

		# Drop the table
		key.Key.table_drop()

		# Recreate the table
		key.Key.table_create()

	# Go through each record, convert the values, and add them
	for d in lRecords:
		try:
			d['_id'] = uuid_strip_dashes(d['_id'])
			d['user'] = uuid_strip_dashes(d['user'])
			key.Key.create_now(d)
		except DuplicateException as e:
			print(e.args)

	# Get the users struct
	dStruct = user.User.struct()

	# Generate the name of the users backup file
	sUserChangesFile = '%s/brain_v2_2_user_changes.json' % sDataPath

	# If the backup file already exists
	if exists(sUserChangesFile):

		# Load it
		lChangeRecords = jsonb.load(sUserChangesFile)

	# Else, no backups yet
	else:

		# Pull out all the records from the user changes table
		lChangeRecords = Commands.select(
			dStruct['host'],
			'SELECT `_id`, UNIX_TIMESTAMP(`created`) as `created`, `items` ' \
			'FROM `%(db)s`.`%(table)s_changes` ORDER BY `created`' % dStruct,
			ESelect.ALL
		)

		# Store them to a local file
		jsonb.store(lChangeRecords, sUserChangesFile)

	# Generate the name of the users backup file
	sUsersFile = '%s/brain_v2_2_users.json' % sDataPath

	# If the backup file already exists
	if exists(sUsersFile):

		# Load it
		lRecords = jsonb.load(sUsersFile)

	# Else, no backup yet
	else:

		# Pull out all the records from the user table
		lRecords = Commands.select(
			dStruct['host'],
			'SELECT `_id`, ' \
				'UNIX_TIMESTAMP(`_created`) as `_created`, ' \
				'UNIX_TIMESTAMP(`_updated`) as `_updated`, ' \
				'`email`, `passwd`, `locale`, `first_name`, `last_name`, ' \
				'`title`, `suffix`, `phone_number`, `phone_ext`, `verified` ' \
			'FROM `%(db)s`.`%(table)s` ORDER BY `_created`' % dStruct,
			ESelect.ALL
		)

		# Store them to a local file
		jsonb.store(lRecords, sUsersFile)

		# Drop the table
		user.User.table_drop()

		# Recreate the table
		user.User.table_create()

	# Go through each record, convert the values, and add them
	for d in lRecords:
		try:
			d['_id'] = uuid_strip_dashes(d['_id'])
			d['verified'] = d['verified'] and True or False
			user.User.create_now(d, changes = False)
		except DuplicateException as e:
			print(e.args)

	# Go through each changes record, convert the values, and add them
	for d in lChangeRecords:
		dStruct['_id'] = uuid_strip_dashes(d['_id'])
		dStruct['created'] = d['created']
		dStruct['items'] = escape_string(d['items'])
		sSQL = "INSERT INTO `%(db)s`.`%(table)s_changes` " \
					"(`_id`, `created`, `items`) " \
				"VALUES (UNHEX('%(_id)s'), FROM_UNIXTIME(%(created)s), " \
					"'%(items)s')" % dStruct
		Commands.execute(dStruct['host'], sSQL)

	# Return OK
	return True