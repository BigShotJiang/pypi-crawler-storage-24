"""Compatibility package alias for ``nmdc_metadata_suggestor``.

Allows imports such as ``import nmdc_metadata_suggestor_ai_tool`` and
``from nmdc_metadata_suggestor_ai_tool import recommendation_pipeline`` while
keeping the implementation under ``nmdc_metadata_suggestor``.
"""

from importlib import import_module
from typing import Any

_base_pkg = import_module("nmdc_metadata_suggestor")

# Ensure submodule imports under this alias resolve using the base package path.
__path__ = _base_pkg.__path__


def __getattr__(name: str) -> Any:
	return getattr(_base_pkg, name)


def __dir__() -> list[str]:
	return sorted(set(globals()) | set(dir(_base_pkg)))
