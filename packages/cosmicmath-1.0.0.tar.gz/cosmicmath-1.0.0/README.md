# CosmicMath
CosmicMath is a custom math library, let me show you:

## Installation
```bash
pip install CosmicMath
```

## Usage
```python
import CosmicMath

CosmicMath.plus(1, 1)
CosmicMath.minus(1, 1)
CosmicMath.multi(1, 1)
CosmicMath.divide(1, 1)
```
