# comate_agent_sdk/facade/__init__.py

# Essential API (第一阶段)
from comate_agent_sdk.facade.core import (
    Agent,
    Event,
    SessionInitEvent,
    StepCompleteEvent,
    StepStartEvent,
    StopEvent,
    TeamMessageEvent,
    TextEvent,
    ThinkingEvent,
    ToolResultEvent,
    ToolUseEvent,
    UserQuestionEvent,
    YieldEvent,
    run_agent,
    run_agent_async,
)

# 保留兼容性 (逐步废弃)
from comate_agent_sdk.facade.errors import (
    AgentConfigError,
    AgentConnectionError,
    AgentError,
    AgentExecutionError,
    AgentTimeoutError,
)

# Config types (Extended API)
from comate_agent_sdk.facade.config import (
    AgentOptions,
    McpServerConfig,
    SettingSource,
    SubagentConfig,
    SystemPromptConfig,
)

__all__ = [
    # 核心 API
    "Agent",
    "run_agent",
    "run_agent_async",
    # 事件
    "Event",
    "SessionInitEvent",
    "TeamMessageEvent",
    "TextEvent",
    "ThinkingEvent",
    "ToolResultEvent",
    "ToolUseEvent",
    "YieldEvent",
    "StopEvent",
    "UserQuestionEvent",
    "StepStartEvent",
    "StepCompleteEvent",
    # 错误 (兼容性)
    "AgentError",
    "AgentConfigError",
    "AgentConnectionError",
    "AgentExecutionError",
    "AgentTimeoutError",
    # Config types
    "AgentOptions",
    "SubagentConfig",
    "SystemPromptConfig",
    "SettingSource",
    "McpServerConfig",
]
