from __future__ import annotations

import asyncio
import logging
from collections.abc import AsyncIterator
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

from comate_agent_sdk.agent.chat_session import ChatSessionError
from comate_agent_sdk.agent.events import (
    AgentEvent,
    ExternalTurnPendingEvent,
    ExternalTurnScheduledEvent,
    HiddenUserMessageEvent,
    LLMSwitchedEvent,
    MessageCompleteEvent,
    MessageStartEvent,
    ModeChangedEvent,
    PlanApprovalRequiredEvent,
    SessionInitEvent,
    StepCompleteEvent,
    StepStartEvent,
    StopEvent as InternalStopEvent,
    SubagentProgressEvent,
    SubagentStartEvent,
    SubagentStopEvent,
    SubagentToolCallEvent,
    SubagentToolResultEvent,
    TaskUpdatedEvent,
    TeamMessageEvent,
    TextEvent,
    ThinkingEvent,
    ToolCallEvent,
    ToolResultEvent,
    UsageDeltaEvent,
    UserQuestionEvent,
    CompactionMetaEvent,
    CompactionResultEvent,
)
from comate_agent_sdk.agent.options import AgentConfig
from comate_agent_sdk.agent.session_store import SessionStoreError
from comate_agent_sdk.facade.errors import (
    AgentConfigError,
    AgentConnectionError,
    AgentError,
    AgentExecutionError,
    AgentTimeoutError,
)
from comate_agent_sdk.facade.core.events import Event, StopEvent, ToolUseEvent, YieldEvent
from comate_agent_sdk.facade.config.options import AgentOptions
from comate_agent_sdk.llm.exceptions import ModelProviderError, ModelRateLimitError
from comate_agent_sdk.mcp.store import McpConfigError
from comate_agent_sdk.utils.paths import PathInputError

_IGNORED_EVENT_TYPES = (
    ExternalTurnPendingEvent,
    ExternalTurnScheduledEvent,
    MessageStartEvent,
    MessageCompleteEvent,
    SubagentStartEvent,
    SubagentStopEvent,
    UsageDeltaEvent,
    SubagentProgressEvent,
    SubagentToolCallEvent,
    SubagentToolResultEvent,
    HiddenUserMessageEvent,
    TaskUpdatedEvent,
    CompactionResultEvent,
    CompactionMetaEvent,
    LLMSwitchedEvent,
    ModeChangedEvent,
    PlanApprovalRequiredEvent,
)


def _map_output_format(raw: Any) -> dict[str, Any] | None:
    """Convert output_format from facade types (dict / Pydantic class / Pydantic instance) to standard dict."""
    if raw is None:
        return None
    from pydantic import BaseModel
    if isinstance(raw, BaseModel):
        # User passed a Pydantic instance
        return {"type": "json_schema", "schema": type(raw).model_json_schema()}
    if isinstance(raw, type) and issubclass(raw, BaseModel):
        # User passed a Pydantic model class
        return {"type": "json_schema", "schema": raw.model_json_schema()}
    if isinstance(raw, dict):
        return raw
    raise TypeError(f"output_format must be dict, Pydantic model class, or Pydantic instance, got {type(raw)}")


def _map_options(options: AgentOptions | None) -> AgentConfig:
    if options is None:
        return AgentConfig(setting_sources=None)

    # --- tools 映射 ---
    # AgentOptions.tools=None → 空 tuple（无内置工具，仅用户自定义工具）
    # AgentOptions.tools="comate" → None（SDK 加载全部内置工具）
    # AgentOptions.tools=["Bash","Read"] → tuple("Bash","Read")（按名挑选）
    tools: tuple[Any, ...] | None
    if options.tools is None:
        tools = ()
    elif options.tools == "comate":
        tools = None
    elif isinstance(options.tools, list):
        tools = tuple(options.tools)
    else:
        tools = ()

    # --- model → llm_levels 映射（映射到 MID 档）---
    # 字符串保持原样传递，延迟到 resolve_llm_levels 时再实例化（届时 settings 已加载，api_key 可用）
    llm_levels: dict[str, Any] | None = None
    if options.model is not None:
        if isinstance(options.model, str):
            llm_levels = {"MID": options.model}
        else:
            llm_levels = {"MID": options.model}

    # --- agents → AgentDefinition 映射 ---
    agents: tuple[Any, ...] | None = None
    if options.agents:
        from comate_agent_sdk.subagent.models import AgentDefinition
        agent_defs = []
        for name, cfg in options.agents.items():
            agent_defs.append(AgentDefinition(
                name=name,
                description=cfg.description,
                prompt=cfg.prompt,
                tools=cfg.tools,
                model=cfg.model,
                max_iterations=cfg.max_iterations,
                skills=cfg.skills,
                shared_auto_memory=cfg.shared_auto_memory,
            ))
        agents = tuple(agent_defs)

    # --- setting_sources 映射 ---
    setting_sources = (
        tuple(options.setting_sources)
        if options.setting_sources is not None
        else None
    )

    if options.add_dirs:
        for p in options.add_dirs:
            resolved = Path(p).expanduser().resolve()
            if not resolved.exists():
                logger.warning(f"add_dirs: path does not exist (yet): {resolved}")

    return AgentConfig(
        system_prompt=options.system_prompt,
        max_iterations=options.max_iterations,
        tools=tools,
        mcp_servers=dict(options.mcp_servers) if options.mcp_servers is not None else None,
        session_id=options.session_id,
        cwd=options.cwd if options.cwd is not None else Path.cwd(),
        llm_levels=llm_levels,
        agents=agents,
        setting_sources=setting_sources,
        env=dict(options.env) if options.env else None,
        add_dirs=tuple(Path(p).expanduser().resolve() for p in options.add_dirs) if options.add_dirs else None,
        disallowed_tools=tuple(options.disallowed_tools) if options.disallowed_tools else None,
        output_format=_map_output_format(options.output_format),
    )


def _map_construction_exception(exc: Exception) -> AgentError:
    if isinstance(exc, AgentError):
        return exc
    if isinstance(exc, ChatSessionError):
        return AgentExecutionError(str(exc))
    if isinstance(exc, (PathInputError, SessionStoreError, McpConfigError, TypeError, ValueError)):
        return AgentConfigError(str(exc))
    return AgentExecutionError(str(exc))


def _map_runtime_exception(exc: Exception) -> AgentError:
    if isinstance(exc, AgentError):
        return exc
    if isinstance(exc, (asyncio.TimeoutError, TimeoutError)):
        return AgentTimeoutError(str(exc))
    if isinstance(exc, (ModelProviderError, ModelRateLimitError, ConnectionError)):
        return AgentConnectionError(str(exc))
    if isinstance(exc, ChatSessionError):
        return AgentExecutionError(str(exc))
    return AgentExecutionError(str(exc))


def _map_stop_event(event: InternalStopEvent) -> StopEvent | YieldEvent:
    """Map internal StopEvent to external StopEvent or YieldEvent.

    Team Mode notes:
    - reason="yielded": Agent in team mode waiting for teammate -> YieldEvent
    - reason="waiting_for_plan_approval": Special case -> should not reach here
    """
    reason = event.reason

    # Team Mode: yielded -> YieldEvent（Team Mode 等待队友）
    if reason == "yielded":
        return YieldEvent(
            reason="waiting_for_teammate",
            metadata={"internal_reason": "yielded"}
        )

    # Normal stop reasons -> StopEvent
    if reason in {"completed", "max_iterations"}:
        mapped_reason = "completed" if reason == "completed" else "max_iterations"
        return StopEvent(reason=mapped_reason)

    if reason == "interrupted":
        return StopEvent(reason="interrupted")

    # These should not reach facade API
    if reason in {"shutdown_request", "waiting_for_input", "waiting_for_plan_approval"}:
        raise AgentExecutionError(
            f"Unsupported internal stop reason for facade API: {reason}"
        )

    raise AgentExecutionError(f"Unknown internal stop reason for facade API: {reason}")


def _map_stop_event_legacy(event: InternalStopEvent) -> DoneEvent:
    """Legacy mapping: InternalStopEvent -> DoneEvent (for AgentClient/query backward compatibility)"""
    from comate_agent_sdk.facade.events import DoneEvent

    reason = event.reason
    if reason in {"completed", "max_iterations"}:
        return DoneEvent(reason="completed")
    if reason in {"interrupted", "shutdown_request"}:
        return DoneEvent(reason="interrupted")
    if reason == "waiting_for_input":
        return DoneEvent(reason="waiting_for_input")
    if reason in {"yielded", "waiting_for_plan_approval"}:
        raise AgentExecutionError(
            f"Unsupported internal stop reason for facade API: {reason}"
        )
    raise AgentExecutionError(f"Unknown internal stop reason for facade API: {reason}")


async def _filter_events(events: AsyncIterator[AgentEvent]) -> AsyncIterator[Event]:
    """Legacy filter: maps to old DoneEvent (for AgentClient/query backward compatibility).

    Used by:
    - AgentClient.chat() / AgentClient.query()
    - query() function
    """
    from comate_agent_sdk.facade.events import DoneEvent

    async for event in events:
        if isinstance(event, SessionInitEvent):
            continue
        if isinstance(event, (TextEvent, ThinkingEvent, ToolResultEvent, StepStartEvent, StepCompleteEvent, UserQuestionEvent, TeamMessageEvent)):
            yield event
            continue
        if isinstance(event, ToolCallEvent):
            yield ToolUseEvent(
                tool=event.tool,
                args=dict(event.args),
                tool_call_id=event.tool_call_id,
                display_name=event.display_name,
            )
            continue
        if isinstance(event, InternalStopEvent):
            yield _map_stop_event_legacy(event)
            continue
        if isinstance(event, _IGNORED_EVENT_TYPES):
            continue
        raise AgentExecutionError(
            f"Unsupported internal event leaked into facade API: {type(event).__name__}"
        )


async def _filter_events_new(events: AsyncIterator[AgentEvent]) -> AsyncIterator[Event]:
    """New filter: maps to StopEvent and YieldEvent (for new Agent/run_agent API).

    Used by:
    - Agent.run_message()
    - run_agent() / run_agent_async()
    """
    async for event in events:
        if isinstance(event, SessionInitEvent):
            yield event
            continue
        if isinstance(event, (TextEvent, ThinkingEvent, ToolResultEvent, StepStartEvent, StepCompleteEvent, UserQuestionEvent, TeamMessageEvent)):
            yield event
            continue
        if isinstance(event, ToolCallEvent):
            yield ToolUseEvent(
                tool=event.tool,
                args=dict(event.args),
                tool_call_id=event.tool_call_id,
                display_name=event.display_name,
            )
            continue
        if isinstance(event, InternalStopEvent):
            yield _map_stop_event(event)
            continue
        if isinstance(event, _IGNORED_EVENT_TYPES):
            continue
        raise AgentExecutionError(
            f"Unsupported internal event leaked into facade API: {type(event).__name__}"
        )
