from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING

from comate_agent_sdk.agent.session_store import normalize_cwd

logger = logging.getLogger("comate_agent_sdk.agent")

_AUTO_MEMORY_DIR = "memory"
_AUTO_MEMORY_FILE = "MEMORY.md"

if TYPE_CHECKING:
    from comate_agent_sdk.agent.core import AgentRuntime


def setup_memory_usage(agent: "AgentRuntime") -> None:
    """设置 memory usage 静态提示（写入 ContextIR header）。"""
    prompt = agent._resolve_memory_usage_prompt()
    if prompt:
        agent._context.set_memory_usage(prompt, cache=True)


def setup_tool_strategy(agent: "AgentRuntime") -> None:
    """根据当前可见工具写入静态 tool strategy。"""
    from comate_agent_sdk.agent.tool_visibility import visible_tools

    visible = visible_tools(
        agent._runtime_state.tools,
        is_subagent=bool(agent._is_subagent),
        is_team_member=bool(agent.is_team_member),
    )
    lines: list[str] = []
    for tool in visible:
        description = str(tool.definition.description or "").strip()
        if description:
            lines.append(f"- **{tool.name}**: {description}")
            continue
        lines.append(f"- **{tool.name}**")

    if lines:
        agent._context.set_tool_strategy("\n".join(lines))


def setup_subagents(agent: "AgentRuntime") -> None:
    """设置 Subagent 支持

    1. 生成 Subagent 策略提示并写入 ContextIR header
    2. 创建 Agent 工具并添加到 tools 列表
    """
    from comate_agent_sdk.subagent.prompts import generate_subagent_prompt
    from comate_agent_sdk.subagent.agent_tool import create_agent_tool

    if not agent._runtime_state.agents or agent._runtime_state.tool_registry is None:
        return

    agent_tools = [t for t in agent._runtime_state.tools if t.name == "Agent"]
    user_agent_tools = [
        t
        for t in agent_tools
        if getattr(t, "_comate_agent_sdk_internal", False) is not True
    ]
    if user_agent_tools:
        raise ValueError(
            "启用 subagent 时检测到用户提供了同名工具 'Agent'。"
            "'Agent' 为 subagent 调度保留名，SDK 会注入系统 Agent 工具，禁止静默替换。"
            "解决方式：1) 将你的工具改名（不要叫 'Agent'）；"
            "2) 显式禁用 subagent（例如 agents=[]/()）；"
            "3) 或移除/调整 .agent/subagents 下的定义。"
        )

    # 生成 Subagent 策略提示并写入 ContextIR header
    subagent_prompt = generate_subagent_prompt(agent._runtime_state.agents)
    lock_header = bool(getattr(agent, "_lock_header_from_snapshot", False))
    if not lock_header:
        agent._context.set_subagent_strategy(subagent_prompt)

    # 避免重复添加 Agent 工具
    agent._runtime_state.tools[:] = [
        t
        for t in agent._runtime_state.tools
        if t.name != "Agent" or getattr(t, "_comate_agent_sdk_internal", False) is not True
    ]
    agent._tool_map.pop("Agent", None)

    # 创建 Agent 工具（根据配置决定是否流式）
    agent_tool = create_agent_tool(
        agents=agent._runtime_state.agents,
        parent_tools=agent._runtime_state.tools,
        tool_registry=agent._runtime_state.tool_registry,  # type: ignore[arg-type]
        parent_cwd=normalize_cwd(agent._runtime_state.cwd),
        parent_llm=agent.llm,
        parent_dependency_overrides=agent.config.dependency_overrides,  # type: ignore
        parent_llm_levels=agent._runtime_state.llm_levels,
        parent_token_cost=agent._token_cost,
        parent_runtime=agent,
        use_streaming_task=agent.config.use_streaming_task,
        parent_user_instruction=agent._runtime_state.user_instruction,
        parent_env_options=agent.config.env_options,
    )

    # 添加到工具列表
    agent._runtime_state.tools.append(agent_tool)
    agent._tool_map[agent_tool.name] = agent_tool

    logger.info(
        f"Initialized {len(agent._runtime_state.agents)} subagents: {[a.name for a in agent._runtime_state.agents]}"
    )

def setup_user_instruction(agent: "AgentRuntime") -> None:
    """设置 user_instruction 静态背景知识。"""
    from comate_agent_sdk.context.memory import (
        UserInstructionConfig,
        load_user_instruction_content,
    )

    if not isinstance(agent._runtime_state.user_instruction, UserInstructionConfig):
        logger.warning("user_instruction 参数不是 UserInstructionConfig 实例，跳过初始化")
        return

    # 加载文件内容
    content = load_user_instruction_content(agent._runtime_state.user_instruction)
    if not content:
        logger.warning("未能加载任何 user_instruction 内容")
        return

    # Token 检查
    token_count = agent._context.token_counter.count(content)
    if token_count > agent._runtime_state.user_instruction.max_tokens:
        logger.warning(
            f"User instruction 内容超出 token 上限: {token_count} > {agent._runtime_state.user_instruction.max_tokens} "
            f"(不会截断，但可能影响上下文预算)"
        )

    # 写入 ContextIR
    agent._context.set_user_instruction(
        content,
        cache=agent._runtime_state.user_instruction.cache,
    )
    logger.info(
        f"User instruction 已加载: {token_count} tokens 来自 {len(agent._runtime_state.user_instruction.files)} 个文件"
    )


def _resolve_session_root(agent: "AgentRuntime") -> Path:
    from comate_agent_sdk.agent.session_store import resolve_session_root

    return resolve_session_root(
        session_id=agent._session_id,
        cwd=normalize_cwd(agent._runtime_state.cwd),
    )


def resolve_auto_memory_dir(agent: "AgentRuntime") -> Path:
    """解析 auto memory 目录（项目级持久化）。"""
    shared_dir = getattr(agent, "_shared_auto_memory_dir", None)
    if shared_dir is not None:
        return Path(shared_dir).expanduser().resolve()

    session_root = _resolve_session_root(agent).resolve()
    return (session_root.parent / _AUTO_MEMORY_DIR).resolve()


def setup_auto_memory(agent: "AgentRuntime") -> None:
    """主 agent 自动加载项目级 auto memory 并注入 ItemType.MEMORY。"""
    if bool(getattr(agent, "_is_subagent", False)) and getattr(
        agent,
        "_shared_auto_memory_dir",
        None,
    ) is None:
        return

    try:
        memory_dir = resolve_auto_memory_dir(agent)
        memory_dir.mkdir(parents=True, exist_ok=True)
        memory_file = (memory_dir / _AUTO_MEMORY_FILE).resolve()
        if not memory_file.exists():
            memory_file.touch()
            logger.info(f"已创建 auto memory 文件: {memory_file}")
    except Exception as e:
        logger.warning(f"初始化 auto memory 目录失败: {e}")
        return

    try:
        content = memory_file.read_text(encoding="utf-8")
    except Exception as e:
        logger.warning(f"读取 auto memory 文件失败: {memory_file}: {e}")
        return

    agent._context.set_auto_memory(content, source_path=str(memory_file))
    token_count = agent._context.token_counter.count(content) if content.strip() else 0
    logger.info(f"Auto memory 已加载: {token_count} tokens 来自 {memory_file}")


def setup_skills(agent: "AgentRuntime") -> None:
    """设置 Skill 支持（基于模板已解析结果进行 prompt 注入 + Skill tool 创建）。"""
    from comate_agent_sdk.skill import create_skill_tool
    from comate_agent_sdk.skill.prompts import generate_skill_prompt

    if not agent._runtime_state.skills:
        return

    # 生成 Skill 策略提示并写入 ContextIR header
    skill_prompt = generate_skill_prompt(agent._runtime_state.skills)
    lock_header = bool(getattr(agent, "_lock_header_from_snapshot", False))
    if not lock_header and skill_prompt:  # 只有当有 active skills 时才注入
        agent._context.set_skill_strategy(skill_prompt)

    # 避免重复添加 Skill 工具（例如用户手动传入 tools 里已包含 Skill）
    agent._runtime_state.tools[:] = [t for t in agent._runtime_state.tools if t.name != "Skill"]
    agent._tool_map.pop("Skill", None)

    # 创建 Skill 工具（现在只包含简洁描述）
    skill_tool = create_skill_tool(agent._runtime_state.skills)
    agent._runtime_state.tools.append(skill_tool)
    agent._tool_map[skill_tool.name] = skill_tool

    logger.info(
        f"Initialized {len(agent._runtime_state.skills)} skill(s): {[s.name for s in agent._runtime_state.skills]}"
    )

