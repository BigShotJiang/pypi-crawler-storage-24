import datetime
import platform
import shutil
import uuid
from logging import DEBUG, FileHandler, Formatter, Logger, LogRecord, getLogger
from pathlib import Path
from typing import TypedDict, Unpack


class CustomLogExtraFields(TypedDict, total=False):
    file_flag: bool
    func_flag: bool


def get_log_extra(**overrides: Unpack[CustomLogExtraFields]) -> dict:
    # ex. logger.info(msg, extra=get_log_extra(dict element))
    defaults: dict = {key: False for key in CustomLogExtraFields.__annotations__}
    defaults.update(overrides)
    return defaults


class CustomBranchFormatter(Formatter):
    """A formatter that dynamically changes the format depending on the extra boolean value."""

    def format(self, record: LogRecord) -> str:
        """Override the formatter of log."""
        flag_of_filename: bool = getattr(record, "file_flag", False)
        filename: str = f"({record.filename}): " if flag_of_filename else ""
        flag_of_funcname: bool = getattr(record, "func_flag", False)
        funcname: str = f"<{record.funcName}> ->" if flag_of_funcname else ""
        formatted_msg: str = super().format(record)
        return f"{filename}{funcname}{formatted_msg}"


class BaseLogTools:
    """
    A utility class for configuring a logger with file handlers.
    ex.
    * logger.debug()
    * logger.info()
    * logger.warning()
    * logger.error()
    * logger.critical()
    """

    def __init__(self):
        """Constructor"""
        self.file_path_of_log: str = ""
        # create logger
        self.logger: Logger = getLogger(f"{__name__}.{uuid.uuid4()}")
        self.logger.setLevel(DEBUG)

    def setup_file_handler(self, file_path: str) -> bool:
        """
        Configures and attaches a FileHandler
        that writes log messages to the specified file.
        """
        result: bool = False
        try:
            self.file_handler: FileHandler = FileHandler(file_path, mode="w", encoding="utf-8")
            self.file_handler.setLevel(DEBUG)
            self.str_of_file_formatter: str = (
                "%(message)s - [%(levelname)s] - <%(funcName)s> - (%(filename)s) - %(asctime)s"
            )
            self.file_formatter: Formatter = Formatter(fmt=self.str_of_file_formatter)
            self.file_handler.setFormatter(self.file_formatter)
            self.logger.addHandler(self.file_handler)
        except Exception:
            raise
        else:
            result = True
        finally:
            pass
        return result


def convert_from_dt_type_to_str_type(mode: str, dt: datetime.datetime | None = None) -> str:
    """Convert from datetime type to str type."""

    def _for_filename(dt: datetime.datetime) -> str:
        """Convert from datetime type to str type for the filename."""
        # datetime type => str type
        return dt.strftime("%Y%m%d_%H%M%S")

    def _for_metadata_of_pdf_file(dt: datetime.datetime) -> str:
        """Convert from datetime type to str type for the metadata of PDF file."""
        # Standard Time
        STDT: str = "+09'00'"
        # datetime type => str type
        return dt.strftime(f"D\072%Y%m%d%H%M%S{STDT}")

    converted_dt: str = ""
    try:
        if dt is None:
            dt: datetime.datetime = datetime.datetime.now()
        match mode:
            case "for_file_name":
                converted_dt = _for_filename(dt)
            case "for_metadata_of_pdf_file":
                converted_dt = _for_metadata_of_pdf_file(dt)
            case _:
                raise Exception("That mode is invalid.")
    except Exception:
        raise
    else:
        pass
    finally:
        pass
    return converted_dt


def is_wsl() -> bool:
    """Check if the execution environment is WSL (Windows Subsystem for Linux)."""
    result: bool = False
    if platform.system().lower() == "linux":
        with open("/proc/version", "r") as f:
            content: str = f.read().lower()
            if "microsoft" in content or "wsl" in content:
                result = True
    return result


def clean_up_dir(p: Path) -> None:
    if p.exists():
        for element in p.iterdir():
            if element.is_dir():
                shutil.rmtree(element)
            else:
                element.unlink()
