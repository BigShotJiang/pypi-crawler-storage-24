import sys

from bizutl.common.config.cli_config import wrap_start_up_with_cli


class Launcher_With_Cli:
    def __init__(self):
        """Constructor"""
        pass

    def run_with_cli(self, tool: str) -> None:
        """Run with CLI."""
        try:
            match tool:
                case "cltp":
                    from bizutl.convert_libre_to_pdf.cltp_with_cli import main
                case "ctm":
                    from bizutl.convert_to_md.ctm_with_cli import main
                case "ep":
                    from bizutl.edit_pdf.ep_with_cli import main
                case "gfl":
                    from bizutl.get_file_list.gfl_with_cli import main
                case "gjgs":
                    from bizutl.get_japan_government_statistics.gjgs_with_cli import main
                case _:
                    raise Exception("That tool is invalid.")
            main()
        except KeyboardInterrupt:
            raise
        except Exception:
            raise
        else:
            pass
        finally:
            pass

    def run_with_gui(self, tool: str) -> None:
        """Run with GUI."""
        try:
            match tool:
                case "cltp":
                    from bizutl.convert_libre_to_pdf.cltp_with_gui import main
                case "ctm":
                    from bizutl.convert_to_md.ctm_with_gui import main
                case "ep":
                    from bizutl.edit_pdf.ep_with_gui import main
                case "gfl":
                    from bizutl.get_file_list.gfl_with_gui import main
                case "gjgs":
                    from bizutl.get_japan_government_statistics.gjgs_with_gui import main
                case _:
                    raise Exception("That tool is invalid.")
            main()
        except KeyboardInterrupt:
            raise
        except Exception:
            raise
        else:
            pass
        finally:
            pass

    def run_gui_launcher(self) -> None:
        """Run GUI launcher."""
        try:
            from bizutl.common.launcher.gui_launcher import main

            main()
        except KeyboardInterrupt:
            raise
        except Exception:
            raise
        else:
            pass
        finally:
            pass

    def print_usage(self) -> None:
        """Print usage."""
        print("\nUsage: ")
        usage_tpl: tuple = (
            "* GUI Launcher => cli_launcher.py",
            "* Tool of CLI => cli_launcher.py cli <tool_name>",
            "* Tool of GUI => cli_launcher.py gui <tool_name>",
        )
        print("\n".join(usage_tpl))
        print("\nTools List: ")
        tools_dct: dict = {
            "* convert_libre_to_pdf": "cltp",
            "* convert_to_md": "ctm",
            "* edit_pdf": "ep",
            "* get_file_list": "gfl",
            "* get_japan_government_statistics": "gjgs",
        }
        print("\n".join(f"{key} => {value}" for key, value in tools_dct.items()))
        print("\nAttention: ")
        attention_tpl: tuple = (
            "* If you execute with GUI mode on WSL2(Ubuntu), execute the following command.",
            "   sudo apt install fonts-ipafont",
            "* If you input Japanese into a Linux GUI app on WSLg(Ubuntu), try the following steps:",
            "   1. Execute the following command.",
            "       sudo apt install ibus ibus-mozc",
            "   2. Add the following to ~/.bashrc.",
            "       ibus-daemon -drx",
            "       export GTK_IM_MODULE=ibus",
            "       export QT_IM_MODULE=ibus",
            "       export XMODIFIERS=@im=ibus",
            "   3. Execute the following command.",
            "       ibus-setup",
            "   4. Select the following on the opening window.",
            "       Input Method => Add => Japanese => Mozc",
            "* If you use convert_to_md, install FFmpeg on each OS.",
        )
        print("\n".join(attention_tpl))

    def execute(self) -> bool:
        """Execute."""
        result: bool = False
        try:
            if len(sys.argv) == 1:
                self.run_gui_launcher()
            elif len(sys.argv) == 3:
                mode: str = sys.argv[1]
                tool: str = sys.argv[2]
                match mode:
                    case "cli":
                        self.run_with_cli(tool)
                    case "gui":
                        self.run_with_gui(tool)
                    case _:
                        raise Exception("That mode is invalid.")
            else:
                self.print_usage()
        except KeyboardInterrupt:
            raise
        except Exception as e:
            print(f"***Processing failed.***: \n{str(e)}")
        else:
            result = True
        finally:
            pass
        return result


@wrap_start_up_with_cli
def main() -> bool:
    result: bool = False
    obj_with_cli: Launcher_With_Cli = Launcher_With_Cli()
    result = obj_with_cli.execute()
    return result


if __name__ == "__main__":
    main()
