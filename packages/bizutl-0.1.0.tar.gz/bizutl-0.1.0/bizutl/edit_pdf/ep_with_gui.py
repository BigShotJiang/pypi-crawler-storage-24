import re
import sys
from pathlib import Path

import pypdfium2
from PySide6.QtCore import QDir, Qt, Signal, Slot
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QApplication,
    QFileDialog,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from bizutl.common.config.base_config import clean_up_dir
from bizutl.common.config.gui_config import (
    ConfigureShortcutsWithQtOnWsl,
    GUILogTools,
    clear_layout,
    convert_from_dt_type_to_str_type,
    wrap_closeevent_with_gui,
    wrap_notifying_result_with_gui,
    wrap_settingup_log_with_gui,
    wrap_showevent_with_gui,
    wrap_start_up_with_gui,
)
from bizutl.edit_pdf.ep_class import EditPdf


class MainApp_Of_EP(QMainWindow):
    """GUI app"""

    log: Signal = Signal(str)

    @wrap_settingup_log_with_gui
    def __init__(self, app: QApplication):
        """Constructor"""
        super().__init__()
        self.app: QApplication = app
        self.sc_init_flag: bool = False
        self.obj_of_sc: ConfigureShortcutsWithQtOnWsl = ConfigureShortcutsWithQtOnWsl(self.app)
        self.obj_of_lt: GUILogTools = getattr(self, "obj_of_lt")
        self.obj_of_cls: EditPdf = EditPdf(self.obj_of_lt.logger)
        self.setup_first_ui()
        # exe化されている場合とそれ以外を切り分ける
        exe_path: Path = Path(sys.executable) if getattr(sys, "frozen", False) else Path(__file__)
        self.folder_p_of_image: Path = exe_path.parent / "__images__"
        self.folder_s_of_image: str = str(self.folder_p_of_image)

    @wrap_showevent_with_gui
    def showEvent(self, event) -> None:
        """Show."""
        super().showEvent(event)

    @wrap_closeevent_with_gui
    def closeEvent(self, event) -> None:
        """Quit."""
        clean_up_dir(self.folder_p_of_image)
        super().closeEvent(event)

    def display_info(self, msg: str) -> None:
        """Display info."""
        QMessageBox.information(self, "Information", msg)
        self.obj_of_lt.logger.info(msg)

    @Slot(str)
    def append_log_to_qtextedit(self, msg: str) -> None:
        """Append log to QTextEdit."""
        self.log_area.append(msg)

    @wrap_notifying_result_with_gui
    def setup_first_ui(self) -> None:
        """Configure the first User Interface."""
        # タイトル
        self.setWindowTitle("PDF file editing app")
        central: QWidget = QWidget()
        self.setCentralWidget(central)
        base_layout: QVBoxLayout = QVBoxLayout(central)
        # 主要
        main_layout: QHBoxLayout = QHBoxLayout()
        base_layout.addLayout(main_layout, stretch=3)
        # 左側
        left_grp_bx: QGroupBox = QGroupBox(title="Function")
        layout_of_left: QVBoxLayout = QVBoxLayout(left_grp_bx)
        left_scroll_area: QScrollArea = QScrollArea()
        left_scroll_area.setWidgetResizable(True)
        left_container: QWidget = QWidget()
        left_container_layout: QVBoxLayout = QVBoxLayout(left_container)
        left_scroll_area.setWidget(left_container)
        layout_of_left.addWidget(left_scroll_area)
        main_layout.addWidget(left_grp_bx, stretch=1)
        # 中央
        central_grp_bx: QGroupBox = QGroupBox(title="Viewer")
        layout_of_central: QVBoxLayout = QVBoxLayout(central_grp_bx)
        center_scroll_area: QScrollArea = QScrollArea()
        center_scroll_area.setWidgetResizable(True)
        center_container: QWidget = QWidget()
        self.center_container_layout: QVBoxLayout = QVBoxLayout(center_container)
        center_scroll_area.setWidget(center_container)
        layout_of_central.addWidget(center_scroll_area)
        main_layout.addWidget(central_grp_bx, stretch=1)
        # 右側
        right_grp_bx: QGroupBox = QGroupBox(title="Log")
        layout_of_right: QVBoxLayout = QVBoxLayout(right_grp_bx)
        right_scroll_area: QScrollArea = QScrollArea()
        right_scroll_area.setWidgetResizable(True)
        right_container: QWidget = QWidget()
        right_container_layout: QVBoxLayout = QVBoxLayout(right_container)
        self.log_area: QTextEdit = QTextEdit()
        self.log_area.setReadOnly(True)
        right_container_layout.addWidget(self.log_area)
        right_scroll_area.setWidget(right_container)
        layout_of_right.addWidget(right_scroll_area)
        main_layout.addWidget(right_grp_bx, stretch=1)
        # ファイル選択と再読み込み
        grp_bx_of_sr: QGroupBox = QGroupBox(title=f"{self.browse_pdf.__doc__} / {self.reload_pdf.__doc__}")
        layout_of_sr: QVBoxLayout = QVBoxLayout(grp_bx_of_sr)
        btn_container_of_sr: QWidget = QWidget()
        btn_container_layout_of_sr: QHBoxLayout = QHBoxLayout(btn_container_of_sr)
        file_path_lbl: QLabel = QLabel("PDF file path")
        self.file_input: QLineEdit = QLineEdit()
        browse_btn: QPushButton = QPushButton("Browse")
        browse_btn.clicked.connect(self.browse_pdf)
        btn_container_layout_of_sr.addWidget(browse_btn)
        reload_btn: QPushButton = QPushButton("Reload")
        reload_btn.clicked.connect(self.reload_pdf)
        btn_container_layout_of_sr.addWidget(reload_btn)
        layout_of_sr.addWidget(file_path_lbl)
        layout_of_sr.addWidget(self.file_input)
        layout_of_sr.addWidget(btn_container_of_sr)
        left_container_layout.addWidget(grp_bx_of_sr)
        # パスワード入力
        grp_bx_of_ed: QGroupBox = QGroupBox(title=f"{self.encrypt_pdf.__doc__} / {self.decrypt_pdf.__doc__}")
        layout_of_ed: QVBoxLayout = QVBoxLayout(grp_bx_of_ed)
        self.password_input: QLineEdit = QLineEdit()
        self.password_input.editingFinished.connect(self.get_password)
        layout_of_ed.addWidget(QLabel("Password"))
        layout_of_ed.addWidget(self.password_input)
        # 暗号化と復号化
        btn_container_of_ed: QWidget = QWidget()
        btn_container_layout_of_ed: QHBoxLayout = QHBoxLayout(btn_container_of_ed)
        encrypt_btn: QPushButton = QPushButton("Encrypt")
        encrypt_btn.clicked.connect(self.encrypt_pdf)
        btn_container_layout_of_ed.addWidget(encrypt_btn)
        decrypt_btn: QPushButton = QPushButton("Decrypt")
        decrypt_btn.clicked.connect(self.decrypt_pdf)
        btn_container_layout_of_ed.addWidget(decrypt_btn)
        layout_of_ed.addWidget(btn_container_of_ed)
        left_container_layout.addWidget(grp_bx_of_ed)
        # メタデータの表示
        grp_bx_of_sm: QGroupBox = QGroupBox(title=self.show_metadata.__doc__)
        layout_of_sm: QVBoxLayout = QVBoxLayout(grp_bx_of_sm)
        show_meta_btn: QPushButton = QPushButton("Display metadata in log")
        show_meta_btn.clicked.connect(self.show_metadata)
        layout_of_sm.addWidget(show_meta_btn)
        left_container_layout.addWidget(grp_bx_of_sm)
        # メタデータの入力
        grp_bx_of_wm: QGroupBox = QGroupBox(title=self.write_metadata.__doc__)
        layout_of_wm: QVBoxLayout = QVBoxLayout(grp_bx_of_wm)
        layout_of_wm.addWidget(QLabel("Enter metadata"))
        self.widget_of_metadata: dict = {}
        self.line_edits_of_metadata: dict = {}
        for key, value in self.obj_of_cls.fields.items():
            if key in ["creation_date", "modification_date"]:
                continue
            self.line_edits_of_metadata[value] = QLineEdit()
            layout_of_wm.addWidget(QLabel(key.capitalize().replace("_", " ")))
            layout_of_wm.addWidget(self.line_edits_of_metadata[value])
        # メタデータの書き込み
        write_meta_btn: QPushButton = QPushButton("Embed metadata")
        write_meta_btn.clicked.connect(self.write_metadata)
        layout_of_wm.addWidget(write_meta_btn)
        left_container_layout.addWidget(grp_bx_of_wm)
        # マージ
        grp_bx_of_mp: QGroupBox = QGroupBox(title=self.merge_pdfs.__doc__)
        layout_of_mp: QVBoxLayout = QVBoxLayout(grp_bx_of_mp)
        merge_btn: QPushButton = QPushButton("Merge multiple files")
        merge_btn.clicked.connect(self.merge_pdfs)
        layout_of_mp.addWidget(merge_btn)
        left_container_layout.addWidget(grp_bx_of_mp)
        # ページの抽出
        grp_bx_of_ep: QGroupBox = QGroupBox(title=self.extract_pages.__doc__)
        layout_of_ep: QVBoxLayout = QVBoxLayout(grp_bx_of_ep)
        page_container_of_ep: QWidget = QWidget()
        page_container_layout_of_ep: QHBoxLayout = QHBoxLayout(page_container_of_ep)
        page_container_layout_of_ep.addWidget(QLabel("Start page for page extraction: "))
        self.start_spin_of_ep: QSpinBox = QSpinBox()
        page_container_layout_of_ep.addWidget(self.start_spin_of_ep)
        page_container_layout_of_ep.addWidget(QLabel("End page for page extraction: "))
        self.end_spin_of_ep: QSpinBox = QSpinBox()
        page_container_layout_of_ep.addWidget(self.end_spin_of_ep)
        extract_page_btn: QPushButton = QPushButton("Extract pages")
        extract_page_btn.clicked.connect(self.extract_pages)
        layout_of_ep.addWidget(page_container_of_ep)
        layout_of_ep.addWidget(extract_page_btn)
        left_container_layout.addWidget(grp_bx_of_ep)
        # ページの削除
        grp_bx_of_dp: QGroupBox = QGroupBox(title=self.delete_pages.__doc__)
        layout_of_dp: QVBoxLayout = QVBoxLayout(grp_bx_of_dp)
        page_container_of_dp: QWidget = QWidget()
        page_container_layout_of_dp: QHBoxLayout = QHBoxLayout(page_container_of_dp)
        page_container_layout_of_dp.addWidget(QLabel("Start page for page deletion: "))
        self.start_spin_of_dp: QSpinBox = QSpinBox()
        page_container_layout_of_dp.addWidget(self.start_spin_of_dp)
        page_container_layout_of_dp.addWidget(QLabel("End page for page deletion: "))
        self.end_spin_of_dp: QSpinBox = QSpinBox()
        page_container_layout_of_dp.addWidget(self.end_spin_of_dp)
        delete_page_btn: QPushButton = QPushButton("Delete pages")
        delete_page_btn.clicked.connect(self.delete_pages)
        layout_of_dp.addWidget(page_container_of_dp)
        layout_of_dp.addWidget(delete_page_btn)
        left_container_layout.addWidget(grp_bx_of_dp)
        # テキストの抽出
        grp_bx_of_et: QGroupBox = QGroupBox(title=self.extract_text.__doc__)
        layout_of_et: QVBoxLayout = QVBoxLayout(grp_bx_of_et)
        page_container_of_et: QWidget = QWidget()
        page_container_layout_of_et: QHBoxLayout = QHBoxLayout(page_container_of_et)
        page_container_layout_of_et.addWidget(QLabel("Start page for text extraction: "))
        self.start_spin_of_et: QSpinBox = QSpinBox()
        page_container_layout_of_et.addWidget(self.start_spin_of_et)
        page_container_layout_of_et.addWidget(QLabel("End page for text extraction: "))
        self.end_spin_of_et: QSpinBox = QSpinBox()
        page_container_layout_of_et.addWidget(self.end_spin_of_et)
        extract_text_btn: QPushButton = QPushButton("Extract text")
        extract_text_btn.clicked.connect(self.extract_text)
        layout_of_et.addWidget(page_container_of_et)
        layout_of_et.addWidget(extract_text_btn)
        left_container_layout.addWidget(grp_bx_of_et)
        # ページの回転
        grp_bx_of_rp: QGroupBox = QGroupBox(title=self.rotate_page.__doc__)
        layout_of_rp: QVBoxLayout = QVBoxLayout(grp_bx_of_rp)
        page_container_of_rp: QWidget = QWidget()
        page_container_layout_of_rp: QHBoxLayout = QHBoxLayout(page_container_of_rp)
        page_container_layout_of_rp.addWidget(QLabel("Page for rotation: "))
        self.spin_of_rp: QSpinBox = QSpinBox()
        page_container_layout_of_rp.addWidget(self.spin_of_rp)
        rotate_btn: QPushButton = QPushButton("Rotate page clockwise (90 degrees)")
        rotate_btn.clicked.connect(self.rotate_page)
        layout_of_rp.addWidget(page_container_of_rp)
        layout_of_rp.addWidget(rotate_btn)
        left_container_layout.addWidget(grp_bx_of_rp)

    def setup_second_ui(self) -> None:
        """Configure the second User Interface."""
        # 各OSに応じたパス区切りに変換する
        file_p: Path = Path(self.obj_of_cls.file_path).expanduser()
        self.obj_of_cls.file_path = str(file_p)
        self.file_input.setText(self.obj_of_cls.file_path)
        # 読み込む
        self.obj_of_cls.read_file()

    def setup_third_ui(self) -> None:
        """Configure the third User Interface."""

        def _get_images(file_path_of_pdf: str) -> list:
            """Get an image of each page of the file to display in the viewer."""
            output_files: list = []
            self.folder_p_of_image.mkdir(parents=True, exist_ok=True)
            pdf: pypdfium2.PdfDocument = pypdfium2.PdfDocument(file_path_of_pdf)
            file_name_s: str = Path(file_path_of_pdf).stem
            for i, page in enumerate(pdf):
                pil_image: pypdfium2.PdfBitmap = page.render(scale=1, rotation=0, crop=(0, 0, 0, 0)).to_pil()
                file_p_of_image: Path = self.folder_p_of_image / f"{file_name_s}_{i + 1}.png"
                pil_image.save(file_p_of_image)
                file_s_of_image: str = str(file_p_of_image)
                output_files.append(file_s_of_image)
            return output_files

        clear_layout(self.center_container_layout)
        images: list = _get_images(self.obj_of_cls.file_path)
        if not images:
            raise Exception("There are no images for each page of the PDF file.")
        # 各ページを表示する
        for i, element in enumerate(images):
            # 垂直レイアウトを用意する
            page_layout: QVBoxLayout = QVBoxLayout()
            page_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
            page_widget: QWidget = QWidget()
            page_widget.setLayout(page_layout)
            # ページ番号のラベル
            page_num_label: QLabel = QLabel(f"page: {i + 1}\n")
            page_num_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            page_layout.addWidget(page_num_label)
            # 画像のラベル
            image_label: QLabel = QLabel()
            pixmap: QPixmap = QPixmap(element).scaledToWidth(300, Qt.TransformationMode.SmoothTransformation)
            image_label.setPixmap(pixmap)
            image_label.setScaledContents(True)
            image_label.setFixedSize(pixmap.size())
            page_layout.addWidget(image_label)
            # グリッドにページごとに追加する
            self.center_container_layout.addWidget(page_widget)

    @Slot()
    def get_password(self) -> None:
        """Get the password."""
        tmp: str = self.password_input.text().strip()
        if not re.fullmatch(r"[A-Za-z0-9_-]+", tmp):
            raise Exception(
                "Enter the following characters: \n* Alphanumeric characters\n* Underscores\n* Hyphens"
            )
        self.obj_of_cls.password = tmp

    @Slot()
    @wrap_notifying_result_with_gui
    def browse_pdf(self) -> None:
        """Browse the PDF file."""
        self.obj_of_cls.file_path, _ = QFileDialog.getOpenFileName(
            self, caption="Browse the PDF file", dir=QDir.homePath(), filter="PDF Files (*.pdf)"
        )
        if not self.obj_of_cls.file_path:
            raise Exception("Browse the PDF file.")
        self.setup_second_ui()
        self.setup_third_ui()

    @Slot()
    @wrap_notifying_result_with_gui
    def reload_pdf(self) -> None:
        """Reload the PDF file."""
        if self.obj_of_cls.file_path == "":
            raise Exception("Browse PDF file.")
        self.setup_second_ui()
        self.setup_third_ui()

    @Slot()
    @wrap_notifying_result_with_gui
    def encrypt_pdf(self) -> None:
        """Encrypt PDF file."""
        if self.obj_of_cls.file_path == "" or self.obj_of_cls.password == "":
            raise Exception("Browse PDF file and enter the password.")
        self.obj_of_cls.encrypt_file(self.obj_of_cls.password)

    @Slot()
    @wrap_notifying_result_with_gui
    def decrypt_pdf(self) -> None:
        """Decrypt PDF file."""
        if self.obj_of_cls.file_path == "" or self.obj_of_cls.password == "":
            raise Exception("Browse PDF file and enter the password.")
        self.obj_of_cls.decrypt_file(self.obj_of_cls.password)

    @Slot()
    @wrap_notifying_result_with_gui
    def show_metadata(self) -> None:
        """Display metadata of PDF file."""
        if self.obj_of_cls.file_path == "":
            raise Exception("Browse PDF file.")
        self.setup_second_ui()
        self.obj_of_cls.get_metadata()

    @Slot()
    @wrap_notifying_result_with_gui
    def write_metadata(self) -> None:
        """Embed metadata to PDF file."""
        if self.obj_of_cls.file_path == "":
            raise Exception("Browse PDF file.")
        self.setup_second_ui()
        for key, value in self.obj_of_cls.fields.items():
            match key:
                case "creation_date":
                    self.widget_of_metadata[value] = self.obj_of_cls.creation_date
                case "modification_date":
                    self.widget_of_metadata[value] = convert_from_dt_type_to_str_type(
                        "for_metadata_of_pdf_file"
                    )
                case _:
                    self.widget_of_metadata[value] = self.line_edits_of_metadata[value].text()
        self.obj_of_cls.write_metadata(self.widget_of_metadata)

    @Slot()
    @wrap_notifying_result_with_gui
    def merge_pdfs(self) -> None:
        """Merge the multiple files."""
        files, _ = QFileDialog.getOpenFileNames(
            self,
            caption="Browse the PDF files which you want to merge",
            dir=QDir.homePath(),
            filter="PDF Files (*.pdf)",
        )
        if not files:
            raise Exception("Browse the PDF files.")
        # 各OSに応じたパス区切りに変換する
        for i, element in enumerate(files):
            files[i] = str(Path(element).expanduser())
        self.obj_of_cls.merge_files(files)

    def check_selected_single_page(self, kw1: str, kw2: str, num: int, num_of_pages: int) -> None:
        """Check selected single page."""
        kw: str = f"{kw1} page number to {kw2}"
        if num == 0:
            raise Exception(f"The {kw} is not selected.")
        if 1 > num or num > num_of_pages:
            raise Exception(f"The {kw} is invalid.")

    def check_selected_page_range(self, kw: str, start: int, end: int, num_of_pages: int) -> None:
        """Check selected page range."""
        self.check_selected_single_page("start", kw, start, num_of_pages)
        self.check_selected_single_page("end", kw, end, num_of_pages)
        if end < start:
            raise Exception("The page range is invalid.")
        if kw != "extract text":
            p: int = end - start + 1
            if p == num_of_pages:
                raise Exception("Do not specify all pages.")

    @Slot()
    @wrap_notifying_result_with_gui
    def extract_pages(self) -> None:
        """Extract pages from PDF file."""
        if self.obj_of_cls.file_path == "":
            raise Exception("Browse PDF file.")
        self.setup_second_ui()
        start, end = self.start_spin_of_ep.value(), self.end_spin_of_ep.value()
        num_of_pages: int = self.obj_of_cls.num_of_pages
        self.check_selected_page_range("extract", start, end, num_of_pages)
        self.obj_of_cls.extract_pages(start, end)

    @Slot()
    @wrap_notifying_result_with_gui
    def delete_pages(self) -> None:
        """Delete pages from PDF file."""
        if self.obj_of_cls.file_path == "":
            raise Exception("Browse PDF file.")
        self.setup_second_ui()
        start, end = self.start_spin_of_dp.value(), self.end_spin_of_dp.value()
        num_of_pages: int = self.obj_of_cls.num_of_pages
        self.check_selected_page_range("delete", start, end, num_of_pages)
        self.obj_of_cls.delete_pages(start, end)

    @Slot()
    @wrap_notifying_result_with_gui
    def extract_text(self) -> None:
        """Extract text from pages of PDF files."""
        if self.obj_of_cls.file_path == "":
            raise Exception("Browse PDF file.")
        self.setup_second_ui()
        start, end = self.start_spin_of_et.value(), self.end_spin_of_et.value()
        num_of_pages: int = self.obj_of_cls.num_of_pages
        self.check_selected_page_range("extract text", start, end, num_of_pages)
        self.obj_of_cls.extract_text(start, end)

    @Slot()
    @wrap_notifying_result_with_gui
    def rotate_page(self) -> None:
        """Rotate the page of PDF file clockwise (90 degrees)."""
        if self.obj_of_cls.file_path == "":
            raise Exception("Browse PDF file.")
        self.setup_second_ui()
        page: int = self.spin_of_rp.value()
        num_of_pages: int = self.obj_of_cls.num_of_pages
        self.check_selected_single_page("rotate", "target", page, num_of_pages)
        self.obj_of_cls.rotate_page_clockwise(page, 90)
        self.setup_third_ui()


def create_window(app: QApplication) -> MainApp_Of_EP:
    window: MainApp_Of_EP = MainApp_Of_EP(app)
    return window


@wrap_start_up_with_gui
def main() -> tuple:
    """Main function."""
    app: QApplication = QApplication(sys.argv)
    return app, create_window


if __name__ == "__main__":
    main()
