from logging import Logger
from pathlib import Path

from bizutl.common.config.base_config import get_log_extra


class GetFileList:
    """
    Get files list in the specified folder.
    """

    def __init__(self, logger: Logger):
        """Constructor"""
        self.logger: Logger = logger
        # フォルダパス
        self.folder_path: str = ""
        # 再帰的に検索するかどうか
        self.recursive: bool = False
        # 検索パターン
        self.pattern: str = ""
        # ファイルパスのリスト
        self.lst_file_before: list = []
        self.lst_file_after: list = []
        # ファイルの数
        self.num_of_f_before: int = 0
        self.num_of_f_after: int = 0

    def append_log_for_constructor(self) -> bool:
        """Append log for the constructor."""
        result: bool = False
        try:
            self.logger.info(f"{self.__class__.__qualname__}: {self.__class__.__doc__}")
        except Exception:
            raise
        else:
            result = True
        finally:
            pass
        return result

    def search_directly_under_folder(self) -> bool:
        """Search directly under folder."""
        result: bool = False
        try:
            self.logger.info(f"Starting folder path: {self.folder_path}")
            self.logger.info(f"Search recursively: {'Yes' if self.recursive else 'No'}")
            RECURSIVE: str = "**/*" if self.recursive else "*"
            self.lst_file_before = [str(f) for f in Path(self.folder_path).glob(RECURSIVE) if f.is_file()]
            if not self.lst_file_before:
                raise Exception("There was no file in the specified folder.")
            self.num_of_f_before = len(self.lst_file_before)
            self.logger.info(f"Number of files: {self.num_of_f_before}")
            self.logger.info("\n".join(self.lst_file_before))
        except Exception:
            raise
        else:
            result = True
            self.logger.info("***Succeeded***", extra=get_log_extra(func_flag=True))
        finally:
            pass
        return result

    def extract_by_pattern(self) -> bool:
        """Extract by pattern."""
        result: bool = False
        try:
            self.logger.info(f"The pattern: {self.pattern if self.pattern else "None"}")
            self.lst_file_after = [f for f in self.lst_file_before if self.pattern in f]
            if not self.lst_file_after:
                raise Exception("No results found for pattern.")
            self.num_of_f_after = len(self.lst_file_after)
            self.logger.info(f"Number of files: {self.num_of_f_after}")
            self.logger.info("\n".join(self.lst_file_after))
        except Exception:
            raise
        else:
            result = True
            self.logger.info("***Succeeded***", extra=get_log_extra(func_flag=True))
        finally:
            pass
        return result
