from bizutl.common.config.cli_config import (
    CLILogTools,
    input_bool,
    input_folder_path,
    wrap_execution_with_cli,
    wrap_settingup_log_with_cli,
    wrap_start_up_with_cli,
)
from bizutl.get_file_list.gfl_class import GetFileList


class GFL_With_Cli:
    @wrap_settingup_log_with_cli
    def __init__(self):
        """Constructor"""
        self.obj_of_lt: CLILogTools = getattr(self, "obj_of_lt")
        self.obj_of_cls: GetFileList = GetFileList(self.obj_of_lt.logger)

    @wrap_execution_with_cli
    def execute(self) -> bool:
        """Execute."""
        result: bool = False
        self.obj_of_cls.folder_path = input_folder_path("target")
        self.obj_of_cls.recursive = input_bool("Search folders recursively?")
        self.obj_of_cls.search_directly_under_folder()
        if input_bool(f"{self.obj_of_cls.extract_by_pattern.__doc__} => Would you like to do it?"):
            self.obj_of_cls.pattern = input("Enter the pattern to search the files: ")
            self.obj_of_cls.extract_by_pattern()
        result = True
        return result


@wrap_start_up_with_cli
def main() -> bool:
    result: bool = False
    obj_with_cli: GFL_With_Cli = GFL_With_Cli()
    result = obj_with_cli.execute()
    return result


if __name__ == "__main__":
    main()
