from bizutl.common.config.cli_config import (
    CLILogTools,
    input_src_dst_folder_path,
    wrap_execution_with_cli,
    wrap_settingup_log_with_cli,
    wrap_start_up_with_cli,
)
from bizutl.convert_to_md.ctm_class import ConvertToMd


class CTM_With_Cli:
    @wrap_settingup_log_with_cli
    def __init__(self):
        """Constructor"""
        self.obj_of_lt: CLILogTools = getattr(self, "obj_of_lt")
        self.obj_of_cls: ConvertToMd = ConvertToMd(self.obj_of_lt.logger)

    @wrap_execution_with_cli
    def execute(self) -> bool:
        """Execute."""
        result: bool = False
        self.obj_of_cls.src_folder_path, self.obj_of_cls.dst_folder_path = input_src_dst_folder_path()
        self.obj_of_cls.create_file_lst()
        for _ in range(self.obj_of_cls.number_of_f):
            self.obj_of_cls.convert_file()
            if self.obj_of_cls.complete:
                break
            self.obj_of_cls.move_to_next_file()
        result = True
        return result


@wrap_start_up_with_cli
def main() -> bool:
    result: bool = False
    obj_with_cli: CTM_With_Cli = CTM_With_Cli()
    result = obj_with_cli.execute()
    return result


if __name__ == "__main__":
    main()
