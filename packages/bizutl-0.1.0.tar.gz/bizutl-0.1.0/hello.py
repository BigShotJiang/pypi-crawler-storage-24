def main():
    print("Hello from bizutl!")


if __name__ == "__main__":
    main()
