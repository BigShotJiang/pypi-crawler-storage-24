import pytest

from bizutl.convert_to_md import ctm_with_cli


def test_func(monkeypatch):
    def fake_loop():
        raise KeyboardInterrupt

    monkeypatch.setattr("bizutl.convert_to_md.ctm_with_cli.main", fake_loop)
    with pytest.raises(KeyboardInterrupt):
        ctm_with_cli.main()
