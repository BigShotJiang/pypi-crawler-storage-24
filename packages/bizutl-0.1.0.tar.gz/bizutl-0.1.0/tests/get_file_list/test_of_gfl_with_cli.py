import pytest

from bizutl.get_file_list import gfl_with_cli


def test_func(monkeypatch):
    def fake_loop():
        raise KeyboardInterrupt

    monkeypatch.setattr("bizutl.get_file_list.gfl_with_cli.main", fake_loop)
    with pytest.raises(KeyboardInterrupt):
        gfl_with_cli.main()
