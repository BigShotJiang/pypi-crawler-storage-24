import pytest

from bizutl.get_japan_government_statistics import gjgs_with_cli


def test_func(monkeypatch):
    def fake_loop():
        raise KeyboardInterrupt

    monkeypatch.setattr("bizutl.get_japan_government_statistics.gjgs_with_cli.main", fake_loop)
    with pytest.raises(KeyboardInterrupt):
        gjgs_with_cli.main()
