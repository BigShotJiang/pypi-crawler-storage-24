import pytest

from bizutl.common.launcher import cli_launcher


def test_func(monkeypatch):
    def fake_loop():
        raise KeyboardInterrupt

    monkeypatch.setattr("bizutl.common.launcher.cli_launcher.main", fake_loop)
    with pytest.raises(KeyboardInterrupt):
        cli_launcher.main()
