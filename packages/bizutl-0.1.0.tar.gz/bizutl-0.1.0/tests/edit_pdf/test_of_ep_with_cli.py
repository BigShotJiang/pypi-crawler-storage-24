import pytest

from bizutl.edit_pdf import ep_with_cli


def test_func(monkeypatch):
    def fake_loop():
        raise KeyboardInterrupt

    monkeypatch.setattr("bizutl.edit_pdf.ep_with_cli.main", fake_loop)
    with pytest.raises(KeyboardInterrupt):
        ep_with_cli.main()
