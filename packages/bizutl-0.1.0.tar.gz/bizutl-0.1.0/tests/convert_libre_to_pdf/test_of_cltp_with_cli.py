import pytest

from bizutl.convert_libre_to_pdf import cltp_with_cli


def test_func(monkeypatch):
    def fake_loop():
        raise KeyboardInterrupt

    monkeypatch.setattr("bizutl.convert_libre_to_pdf.cltp_with_cli.main", fake_loop)
    with pytest.raises(KeyboardInterrupt):
        cltp_with_cli.main()
