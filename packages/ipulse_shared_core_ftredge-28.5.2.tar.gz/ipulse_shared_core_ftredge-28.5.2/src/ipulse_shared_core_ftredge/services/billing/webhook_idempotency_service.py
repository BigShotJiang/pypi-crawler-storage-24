"""
WebhookIdempotencyService -- Prevents duplicate processing of Stripe events.

Both the verify-session endpoint (primary activation path) and the webhook handler
(backup activation path) share this collection. Whichever processes first writes
the record; the second path sees it and becomes a no-op.

CRITICAL: The idempotency check and state write MUST be in a single Firestore
transaction to prevent TOCTOU races between verify-session and webhook.
"""

import logging
from datetime import datetime, timezone
from typing import Optional
from google.cloud.firestore import Client
from ipulse_shared_core_ftredge.models.billing.webhook_idempotency import WebhookIdempotencyRecord
from ipulse_shared_core_ftredge.services.base.base_firestore_service import BaseFirestoreService


class WebhookIdempotencyService(BaseFirestoreService[WebhookIdempotencyRecord]):
    """
    Service for tracking processed Stripe events to prevent duplicate handling.

    Document ID = Stripe event ID (evt_xxx) or Checkout Session ID (cs_xxx).
    """

    def __init__(
        self,
        firestore_client: Client,
        logger: Optional[logging.Logger] = None
    ):
        super().__init__(
            db=firestore_client,
            collection_name=WebhookIdempotencyRecord.COLLECTION_NAME,
            resource_type="WebhookIdempotencyRecord",
            model_class=WebhookIdempotencyRecord,
            logger=logger or logging.getLogger(__name__)
        )

    def is_already_processed(self, idempotency_key: str) -> bool:
        """
        Check if an event/session has already been successfully processed.

        Args:
            idempotency_key: Stripe event ID or Checkout Session ID.

        Returns:
            True if the key exists and result is 'success'.
        """
        try:
            doc = self._get_collection().document(idempotency_key).get()
            if doc.exists:
                data = doc.to_dict()
                return data.get("result") == "success"
            return False
        except Exception as e:
            self.logger.error(f"Idempotency check failed for key={idempotency_key}: {e}")
            # On failure, return False to allow processing (at-least-once delivery).
            # The actual state mutation should be idempotent anyway.
            return False

    def mark_processed(
        self,
        idempotency_key: str,
        event_type: Optional[str] = None,
        result: str = "success",
        source: Optional[str] = None,
    ) -> None:
        """
        Record that an event/session has been processed.

        Args:
            idempotency_key: Stripe event ID or Checkout Session ID.
            event_type: Stripe event type or 'checkout_verify_session'.
            result: Processing result ('success', 'failed', 'skipped_duplicate').
            source: Which path processed this ('verify_session' or 'stripe_webhook').
        """
        try:
            record = WebhookIdempotencyRecord(
                id=idempotency_key,
                processed_timestamp_utc=datetime.now(timezone.utc),
                event_type=event_type,
                result=result,
                source=source,
            )
            self._get_collection().document(idempotency_key).set(
                record.model_dump(exclude_none=True)
            )
            self.logger.info(
                f"Idempotency record created: key={idempotency_key}, "
                f"type={event_type}, result={result}, source={source}"
            )
        except Exception as e:
            self.logger.error(
                f"Failed to write idempotency record for key={idempotency_key}: {e}"
            )

    def mark_failed(
        self,
        idempotency_key: str,
        event_type: Optional[str] = None,
        source: Optional[str] = None,
    ) -> None:
        """
        Record that an event processing attempt failed.
        This allows the event to be retried (result != 'success').

        Args:
            idempotency_key: Stripe event ID or Checkout Session ID.
            event_type: Stripe event type.
            source: Which path attempted processing.
        """
        self.mark_processed(
            idempotency_key=idempotency_key,
            event_type=event_type,
            result="failed",
            source=source,
        )
