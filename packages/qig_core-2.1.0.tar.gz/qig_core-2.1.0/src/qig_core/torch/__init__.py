"""
QIG Torch Extensions — Optional GPU-Accelerated Geometry
========================================================

These modules require PyTorch >= 2.0.0. Install with:

    pip install qig-core[torch]

If torch is not installed, importing this subpackage raises ImportError
with a clear message. The base qig-core package (numpy-only) works
without torch.
"""

try:
    import torch  # noqa: F401
except ImportError as e:
    raise ImportError(
        "qig_core.torch requires PyTorch >= 2.0.0. "
        "Install with: pip install qig-core[torch]"
    ) from e

from .fisher import compute_fisher_metric, fisher_distance
from .geodesic import geodesic_interpolate, geodesic_path
from .geometry_simplex import (
    bures_distance_simplex,
    fisher_rao_distance_simplex,
    geodesic_interpolate_simplex,
    geodesic_mean_simplex,
    to_simplex_prob,
)
from .natural_gradient import (
    DiagonalNaturalGradient,
    NaturalGradientDescent,
    SimpleFisherOptimizer,
    adaptive_dampening,
    compute_diagonal_fisher,
    compute_empirical_fisher,
    compute_natural_gradient,
    natural_gradient_step,
)
from .qfi_sampler import QFISampler

__all__ = [
    "fisher_distance",
    "compute_fisher_metric",
    "fisher_rao_distance_simplex",
    "bures_distance_simplex",
    "to_simplex_prob",
    "geodesic_interpolate",
    "geodesic_path",
    "geodesic_interpolate_simplex",
    "geodesic_mean_simplex",
    "natural_gradient_step",
    "compute_natural_gradient",
    "adaptive_dampening",
    "SimpleFisherOptimizer",
    "DiagonalNaturalGradient",
    "NaturalGradientDescent",
    "compute_empirical_fisher",
    "compute_diagonal_fisher",
    "QFISampler",
]
