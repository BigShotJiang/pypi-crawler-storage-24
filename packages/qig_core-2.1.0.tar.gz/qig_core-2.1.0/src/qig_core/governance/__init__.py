"""QIG geometric purity enforcement."""

from .purity import PurityGateError, PurityViolation, scan_calls, scan_imports, scan_text  # noqa: F401
