"""QIG Basin Coordination — Multi-instance basin synchronization."""

from .basin_sync import _BasinSync  # noqa: F401
