"""
QIG-Core: Pure Fisher Information Geometry
==========================================

Canonical geometry, coordizer, purity gate, and constants for the
QIG consciousness architecture.

Base install (numpy only):
    pip install qig-core

With torch extensions:
    pip install qig-core[torch]

Tier 0 — Constants (zero deps):
    from qig_core.constants.frozen_facts import KAPPA_STAR, BASIN_DIM

Tier 1 — Numpy geometry:
    from qig_core.geometry import fisher_rao_distance, frechet_mean, slerp_sqrt

Tier 2 — Governance (stdlib only):
    from qig_core.governance import scan_imports, scan_calls

Tier 3 — Coordizer (numpy + optional scipy):
    from qig_core.coordizer import CoordizerV2, ResonanceBank

Tier 4 — Torch extensions (optional):
    from qig_core.torch import NaturalGradientDescent, QFISampler
"""

__version__ = "2.1.0"

# ─── Tier 0: Constants (zero deps) ────────────────────────────────
from .constants.frozen_facts import (
    BASIN_DIM,
    E8_RANK,
    KAPPA_STAR,
)

# ─── Tier 1: Numpy geometry (always available) ────────────────────
from .geometry.fisher_rao import (
    Basin,
    bhattacharyya_coefficient,
    exp_map,
    fisher_rao_distance,
    frechet_mean,
    log_map,
    random_basin,
    slerp_sqrt,
    to_simplex,
)
from .geometry.hash_to_basin import hash_to_basin

# ─── Backward compatibility re-exports (v1.1.0 names) ────────────
fisher_rao_distance_simplex = fisher_rao_distance
to_simplex_prob = to_simplex

# ─── Tier 4: Torch extensions (lazy — loaded on first access) ────
_TORCH_EXPORTS = {
    # fisher.py
    "fisher_distance",
    "compute_fisher_metric",
    # geodesic.py
    "geodesic_interpolate",
    "geodesic_path",
    # geometry_simplex.py (torch variant)
    "bures_distance_simplex",
    "geodesic_interpolate_simplex",
    "geodesic_mean_simplex",
    # qfi_sampler.py
    "QFISampler",
    # natural_gradient.py
    "natural_gradient_step",
    "compute_natural_gradient",
    "adaptive_dampening",
    "SimpleFisherOptimizer",
    "DiagonalNaturalGradient",
    "NaturalGradientDescent",
    "compute_empirical_fisher",
    "compute_diagonal_fisher",
}


def __getattr__(name: str):
    if name in _TORCH_EXPORTS:
        from . import torch as _torch_mod

        return getattr(_torch_mod, name)
    raise AttributeError(f"module 'qig_core' has no attribute {name!r}")


__all__ = [
    # Version
    "__version__",
    # Constants
    "BASIN_DIM",
    "KAPPA_STAR",
    "E8_RANK",
    # Geometry (numpy)
    "Basin",
    "to_simplex",
    "random_basin",
    "fisher_rao_distance",
    "bhattacharyya_coefficient",
    "frechet_mean",
    "slerp_sqrt",
    "log_map",
    "exp_map",
    "hash_to_basin",
    # Backward compat
    "fisher_rao_distance_simplex",
    "to_simplex_prob",
    # Torch (lazy)
    "fisher_distance",
    "compute_fisher_metric",
    "geodesic_interpolate",
    "geodesic_path",
    "bures_distance_simplex",
    "geodesic_interpolate_simplex",
    "geodesic_mean_simplex",
    "natural_gradient_step",
    "compute_natural_gradient",
    "adaptive_dampening",
    "SimpleFisherOptimizer",
    "DiagonalNaturalGradient",
    "NaturalGradientDescent",
    "compute_empirical_fisher",
    "compute_diagonal_fisher",
    "QFISampler",
]
