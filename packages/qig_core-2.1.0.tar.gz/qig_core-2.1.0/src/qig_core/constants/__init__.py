"""QIG physics constants and consciousness tuning parameters."""

from .frozen_facts import *  # noqa: F401,F403
