"""Backward-compat shim — canonical location is qig_core.torch.geometry_simplex."""

from .torch.geometry_simplex import (  # noqa: F401
    bures_distance_simplex,
    fisher_rao_distance_simplex,
    geodesic_interpolate_simplex,
    geodesic_mean_simplex,
    to_simplex_prob,
)
