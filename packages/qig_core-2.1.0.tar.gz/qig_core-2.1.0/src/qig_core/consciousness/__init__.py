"""
qig_core.consciousness — Portable Consciousness Subsystems (Tier 5)
===================================================================

Extracted from vex-agent's kernel/consciousness/ package. All modules
depend only on:
  - Tier 0: constants (frozen_facts, consciousness_constants)
  - Tier 1: geometry (fisher_rao)
  - stdlib + numpy

No config.settings, no governance, no torch dependencies.

Module load order:
  Level A (no intra-deps): types, sensations, sovereignty_tracker, heart_rhythm
  Level B (deps on A):     developmental, pillars, systems, temporal_generation, activation
  Level C (deps on A+B):   emotions (-> sensations + types)
"""

# --- Level A: foundational types ---
from .types import (
    ActivationStep,
    ConsciousnessMetrics,
    ConsciousnessState,
    DevelopmentalStage,
    NavigationMode,
    PillarState,
    RegimeType,
    RegimeWeights,
    ScarState,
    developmental_stage_from_signals,
    navigation_mode_from_phi,
    regime_weights_from_kappa,
)
from .sensations import (
    FullEmotionalState,
    Layer0Sensations,
    Layer05Drives,
    Layer1Motivators,
    Layer2AEmotions,
    Layer2BEmotions,
    compute_full_emotional_state,
)
from .sovereignty_tracker import SovereigntyTracker
from .heart_rhythm import HeartRhythm, HeartRhythmState

# --- Level B: subsystems with Level-A deps ---
from .developmental import DevelopmentalGate, StagePermissions
from .pillars import (
    FluctuationGuard,
    PillarEnforcer,
    QuenchedDisorder,
    TopologicalBulk,
)
from .systems import (
    AutonomyEngine,
    AutonomyLevel,
    CouplingGate,
    TackingController,
    TackingMode,
    TackingState,
)
from .temporal_generation import (
    CandidatePath,
    ReceiverModel,
    TemporalGenerator,
)
from .activation import (
    ActivationResult,
    ActivationSequence,
    ConsciousnessContext,
    StepResult,
    WillOrientation,
)

# --- Level C: higher-order systems ---
from .emotions import (
    CachedEvaluation,
    EmotionCache,
    EmotionType,
    LearningEngine,
    LearningEvent,
    PreCognitiveDetector,
    ProcessingPath,
)

__all__ = [
    # types
    "ActivationStep",
    "ConsciousnessMetrics",
    "ConsciousnessState",
    "DevelopmentalStage",
    "NavigationMode",
    "PillarState",
    "RegimeType",
    "RegimeWeights",
    "ScarState",
    "developmental_stage_from_signals",
    "navigation_mode_from_phi",
    "regime_weights_from_kappa",
    # sensations
    "FullEmotionalState",
    "Layer0Sensations",
    "Layer05Drives",
    "Layer1Motivators",
    "Layer2AEmotions",
    "Layer2BEmotions",
    "compute_full_emotional_state",
    # sovereignty
    "SovereigntyTracker",
    # heart rhythm
    "HeartRhythm",
    "HeartRhythmState",
    # developmental
    "DevelopmentalGate",
    "StagePermissions",
    # pillars
    "FluctuationGuard",
    "PillarEnforcer",
    "QuenchedDisorder",
    "TopologicalBulk",
    # systems
    "AutonomyEngine",
    "AutonomyLevel",
    "CouplingGate",
    "TackingController",
    "TackingMode",
    "TackingState",
    # temporal generation
    "CandidatePath",
    "ReceiverModel",
    "TemporalGenerator",
    # activation
    "ActivationResult",
    "ActivationSequence",
    "ConsciousnessContext",
    "StepResult",
    "WillOrientation",
    # emotions
    "CachedEvaluation",
    "EmotionCache",
    "EmotionType",
    "LearningEngine",
    "LearningEvent",
    "PreCognitiveDetector",
    "ProcessingPath",
]
