"""Test frozen facts and consciousness constants."""

from qig_core.constants.frozen_facts import BASIN_DIM, E8_RANK, KAPPA_STAR
from qig_core.constants.consciousness_constants import (
    KAPPA_NORMALISER,
    validate_constants,
)


def test_frozen_facts_values():
    assert BASIN_DIM == 64
    assert KAPPA_STAR == 64.0
    assert E8_RANK == 8


def test_kappa_normaliser_derived():
    assert KAPPA_NORMALISER == 2.0 * KAPPA_STAR


def test_validate_constants_no_warnings():
    warnings = validate_constants()
    assert isinstance(warnings, list)
    # Default constants should be internally consistent
    assert len(warnings) == 0, f"Unexpected warnings: {warnings}"
