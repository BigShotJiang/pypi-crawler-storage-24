"""Test hash_to_basin deterministic projection."""

import numpy as np

from qig_core.geometry.hash_to_basin import hash_to_basin


def test_deterministic():
    b1 = hash_to_basin("hello world")
    b2 = hash_to_basin("hello world")
    np.testing.assert_array_equal(b1, b2)


def test_simplex_membership():
    b = hash_to_basin("test input")
    assert abs(b.sum() - 1.0) < 1e-10
    assert (b > 0).all()
    assert len(b) == 64


def test_different_inputs_different_basins():
    b1 = hash_to_basin("alpha")
    b2 = hash_to_basin("beta")
    # Different inputs should produce different basins
    assert not np.allclose(b1, b2)
