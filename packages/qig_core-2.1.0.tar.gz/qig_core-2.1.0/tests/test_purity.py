"""Test PurityGate scanner."""

import tempfile
from pathlib import Path

from qig_core.governance.purity import scan_text, scan_imports, PurityViolation


def _scan_code(code: str, filename: str = "module.py") -> list[PurityViolation]:
    """Helper: write code to a temp .py file and run scan_text on its parent dir.

    Note: scan_text skips test_* files, so we use a non-test filename.
    """
    with tempfile.TemporaryDirectory() as tmpdir:
        p = Path(tmpdir) / filename
        p.write_text(code)
        return scan_text(Path(tmpdir))


def test_clean_code_passes():
    code = '''
import numpy as np
d = 42
'''
    violations = _scan_code(code)
    assert len(violations) == 0


def test_cosine_similarity_detected():
    code = "sim = cosine_similarity(a, b)\n"
    violations = _scan_code(code)
    assert len(violations) > 0
    assert any("cosine_similarity" in str(v) for v in violations)


def test_euclidean_distance_detected():
    code = "dist = euclidean_distance(a, b)\n"
    violations = _scan_code(code)
    assert len(violations) > 0
    assert any("euclidean_distance" in str(v) for v in violations)
