"""Test backward compatibility with v1.1.0 import paths."""


def test_fisher_rao_distance_simplex_alias():
    from qig_core import fisher_rao_distance_simplex, fisher_rao_distance

    assert fisher_rao_distance_simplex is fisher_rao_distance


def test_to_simplex_prob_alias():
    from qig_core import to_simplex_prob, to_simplex

    assert to_simplex_prob is to_simplex


def test_version():
    from qig_core import __version__

    assert __version__ == "2.0.0"
