import inspect
from typing import Callable, Union, Any, get_type_hints as getTypeHints, Literal
from types import UnionType

__all__ = ['render_type', 'render_function']
__author__ = 'UnknownUser03393@github.com/UnknownUser03393'

def render_type(t: Any) -> str:
	if t is Ellipsis: return '...'
	if t is type(None) or t is None: return "None"
	if hasattr(t, "__name__") and not isinstance(t, type):
		if type(t).__name__ in ("TypeVar", "TypeVarTuple", "ParamSpec"): return t.__name__
	origin = getattr(t, "__origin__", None)
	args = getattr(t, "__args__", None)
	if origin is Literal:
		lv = []
		for arg in args:
			if isinstance(arg, str): lv.append(f"'{arg}'")
			elif arg is None: lv.append("None")
			else: lv.append(repr(arg))
		return " | ".join(lv)
	if origin is Union or (UnionType is not Union and isinstance(t, UnionType)):
		it = [a for a in args if a is not type(None)]
		names = [render_type(a) for a in it]
		base = " | ".join(names) if len(names) > 1 else names[0]
		return f"{base}?" if len(it) < len(args) else base
	if args:
		z = [render_type(a) for a in args]
		raw = getattr(origin, "__name__", str(origin)).split('.')[-1]
		if raw == 'tuple':
			if not z: return "()"
			if len(z) == 2 and z[-1] == '...': return f"({z[0]}, ...)"
			return f"({', '.join(z)})"
		if raw == 'Callable' and len(z) >= 1:
			params = ", ".join(z[:-1])
			return f"({params}) -> {z[-1]}"
		return f"{raw}<{', '.join(z)}>"
	return getattr(t, "__name__", str(t))


def render_function(func: Callable) -> str:
	try:
		hints = getTypeHints(func, include_extras=True)
		sig = inspect.signature(func)
		tps = ""
		if hasattr(func, "__type_params__") and func.__type_params__:
			tpl = []
			for tp in func.__type_params__:
				bound = getattr(tp, "__bound__", None)
				if bound: tpl.append(f"{tp.__name__}: {render_type(bound)}")
				else: tpl.append(tp.__name__)
			tps = f"<{', '.join(tpl)}>"
		pl = []
		for name, param in sig.parameters.items():
			T = render_type(hints.get(name, Any))
			P = "*" if param.kind == 2 else ("**" if param.kind == 4 else "")
			P_RE = f"{P}{name}: {T}"
			if param.default is not inspect.Parameter.empty: P_RE += f" = {repr(param.default)}"
			pl.append(P_RE)
		ret_str = render_type(hints.get('return', type(None)))
		return f"{tps}({', '.join(pl)}) -> {ret_str}"
	except Exception:
		return "(any? ...) -> ?"