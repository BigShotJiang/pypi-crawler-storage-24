# pytypestr

Human-readable type strings for Python.

Single-file, zero-dependency utility for rendering Python type hints into clean, modern signatures.

---

## Usage

```python
from typing import Literal
from typestr import render_function, render_type


def foo(x: int | None, y: list[str]) -> bool:
	pass


print(render_function(foo))
print(render_type(
	list[
		Literal[200, 300, 400]
		| tuple[str | int, str, dict[str, int | float], ...]
		]
))
````

**Output:**

```
(x: int?, y: list<str>) -> bool
list<200 | 300 | 400 | (str | int, str, dict<str, int | float>, ...)>
```

---

## Features

* Modern `Union` syntax `Union[A, B]` → `A | B`

* Modern `Literal` syntax `Literal[A, B, ...]` → `A | B | ...`

* Tuple formatting `tuple[A, B, ...]` → `(A, B, ...)`

* Generic types `list[A]` → `list<A>`

* Optional shorthand `Optional[A]` → `A?`

* Callable signatures `Callable[[A], B]` → `(A) -> B`

* Built-in container types support

---

## License

MIT