import bencher as bn
from bencher.example.meta.example_meta import BenchMeta


def example_meta_cat(run_cfg: bn.BenchRunCfg | None = None) -> bn.Bench:
    bench = BenchMeta().to_bench(run_cfg)

    bench.plot_sweep(
        title="Sweeping Categorical Variables",
        input_vars=[
            bn.sweep("categorical_vars", [1, 2, 3]),
            bn.sweep("sample_with_repeats", [1, 2]),
        ],
        const_vars=dict(float_vars=0),
    )

    return bench


if __name__ == "__main__":
    bn.run(example_meta_cat)
