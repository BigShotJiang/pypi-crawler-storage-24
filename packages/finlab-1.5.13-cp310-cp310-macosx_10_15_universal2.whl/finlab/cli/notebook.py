from __future__ import annotations

import json
import os
import re
import subprocess
import time
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Mapping
from urllib.parse import quote

import nbformat
import pandas as pd
import requests
from nbformat import v4 as nbf

import finlab
from finlab.ffn_core import tabulate

firebase_config: dict[str, str] = {
    "apiKey": "AIzaSyB9Ogv6Vbwfy6_I0aLEfcpsPhqhlc4FSTw",
    "authDomain": "fdata-299302.firebaseapp.com",
    "projectId": "fdata-299302",
    "storageBucket": "fdata-299302.appspot.com",
    "messagingSenderId": "748308483506",
    "appId": "1:748308483506:web:7c78dd82b422cd4ea5a8ab",
}


def list_strategies(token: str, user_id: str, verbose: bool = True) -> pd.DataFrame:
    headers = {"Authorization": f"Bearer {token}"}

    doc_ref = f"https://firestore.googleapis.com/v1/projects/{firebase_config['projectId']}/databases/(default)/documents/users/{user_id}"
    response = requests.get(doc_ref, headers=headers)
    data = response.json()

    strategy_names = list(data["fields"]["strategies"]["mapValue"]["fields"].keys())

    strategies: dict[str, Any] = {}
    for sname in strategy_names:
        strategies[sname] = data["fields"]["strategies"]["mapValue"]["fields"][sname][
            "mapValue"
        ]["fields"]

        r1 = next(
            iter(strategies[sname]["ndays_return"]["mapValue"]["fields"]["1"].values())
        )
        r5 = next(
            iter(strategies[sname]["ndays_return"]["mapValue"]["fields"]["5"].values())
        )
        r20 = next(
            iter(strategies[sname]["ndays_return"]["mapValue"]["fields"]["20"].values())
        )
        r60 = next(
            iter(strategies[sname]["ndays_return"]["mapValue"]["fields"]["60"].values())
        )
        max_drawdown = next(iter(strategies[sname]["max_drawdown"].values()))
        annual_return = next(iter(strategies[sname]["annual_return"].values()))
        sharpe_ratio = next(iter(strategies[sname]["sharpe_ratio"].values()))

        strategies[sname] = {
            "day %": r1,
            "week %": r5,
            "month %": r20,
            "season %": r60,
            "MDD": max_drawdown,
            "CAGR": annual_return,
            "SHARPE": sharpe_ratio,
        }

    ret = pd.DataFrame(strategies).astype(float).T
    percentage_cols = ["day %", "week %", "month %", "season %", "MDD", "CAGR"]
    ret[percentage_cols] = ret[percentage_cols].map(lambda x: f"{x:.2%}")
    ret["SHARPE"] = ret["SHARPE"].map(lambda x: f"{x:.2f}")

    if verbose:
        print(tabulate(ret, headers=ret.columns).to_markdown())

    return ret


def is_auto_update_enabled(token: str, user_id: str) -> bool:
    headers = {"Authorization": f"Bearer {token}"}

    doc_ref = f"https://firestore.googleapis.com/v1/projects/{firebase_config['projectId']}/databases/(default)/documents/users/{user_id}"
    response = requests.get(doc_ref, headers=headers)
    data = response.json()
    print(data)
    if (
        "kernel" in data["fields"]
        and "autoUpdate" in data["fields"]["kernel"]["mapValue"]["fields"]
    ):
        return data["fields"]["kernel"]["mapValue"]["fields"]["autoUpdate"][
            "booleanValue"
        ]
    return False


def get_notebook_data(
    token: str, user_id: str, strategy_name: str
) -> dict[str, Any] | None:
    headers = {"Authorization": f"Bearer {token}"}

    doc_ref = f"https://firestore.googleapis.com/v1/projects/{firebase_config['projectId']}/databases/(default)/documents/users/{user_id}/strategies/{strategy_name}/codes/code"
    response = requests.get(doc_ref, headers=headers)

    if response.status_code != 200:
        return None

    return response.json()


def extract_cell_text(
    notebook_data: Mapping[str, Any] | None, strategy_name: str, is_user: bool = False
) -> list[str] | dict[str, Any]:
    cells: list[str] = []

    if notebook_data is None:
        return {"success": False, "error": "Notebook not found"}

    if "notebook" in notebook_data["fields"]:
        cells.extend(
            cell["mapValue"]["fields"]["source"]["stringValue"]
            for cell in notebook_data["fields"]["notebook"]["arrayValue"]["values"]
            if cell["mapValue"]["fields"]["cell_type"]["stringValue"] == "code"
        )
    elif "code" in notebook_data["fields"]:
        cells.extend(
            cell["stringValue"]
            for cell in notebook_data["fields"]["code"]["arrayValue"]["values"]
        )
    else:
        raise ValueError("Invalid notebook data")

    if is_user:
        # that means the author is the same as the user
        first_line = f"%env FINLAB_STRATEGY_NAME={strategy_name}"
        if cells:
            cells = [first_line, *cells]
        else:
            cells.append(first_line)

    return cells


def pull_notebook(
    token: str,
    user_id: str,
    strategy_name: str,
    path: str,
    output_file_name: str | None = None,
    notebook_data: dict[str, Any] | None = None,
) -> dict[str, Any]:
    if notebook_data is None:
        notebook_data = get_notebook_data(token, user_id, strategy_name)

    if notebook_data is None:
        return {"success": False, "error": "Notebook not found"}

    cells = extract_cell_text(
        notebook_data, is_user=output_file_name is None, strategy_name=strategy_name
    )

    nb = nbf.new_notebook()
    nb.cells = [nbf.new_code_cell(cell) for cell in cells]

    # set default kernel
    nb.metadata["kernelspec"] = {
        "display_name": "finlab-env",
        "language": "python",
        "name": "finlab-env",
    }

    if output_file_name is None:
        output_file_name = strategy_name
    file_path = os.path.join(path, f"{output_file_name}.ipynb")
    nbformat.write(nb, file_path)
    return {
        "success": True,
        "file_path": file_path,
        "updateTime": notebook_data["updateTime"],
    }


def create_notebook(strategy_name: str, path: str) -> dict[str, Any]:
    nb = nbf.new_notebook()
    nb.cells = [nbf.new_code_cell(f"%env FINLAB_STRATEGY_NAME={strategy_name}")]
    nbformat.write(nb, path)
    return {"success": True, "file_path": path}


def push_notebook(
    token: str, user_id: str, strategy_name: str, path: str
) -> dict[str, Any]:
    headers = {"Authorization": f"Bearer {token}"}

    nb = nbformat.read(os.path.join(path, f"{strategy_name}.ipynb"), as_version=4)

    cells = [{"stringValue": cell.source} for cell in nb.cells]

    if cells and "FINLAB_STRATEGY_NAME" in cells[0]["stringValue"]:
        split_line = cells[0]["stringValue"].split("\n", 1)
        if len(split_line) == 2:
            cells[0]["stringValue"] = split_line[1]
        else:
            cells[0]["stringValue"] = ""

        if cells[0]["stringValue"].strip(" \n\r\t") == "":
            cells = cells[1:]

    data = {"fields": {"code": {"arrayValue": {"values": cells}}}}

    doc_ref = f"https://firestore.googleapis.com/v1/projects/{firebase_config['projectId']}/databases/(default)/documents/users/{user_id}/strategies/{strategy_name}/codes/code"

    response = requests.patch(doc_ref, headers=headers, json=data)
    if "error" in response.json():
        return {"success": False, "error": response.json()["error"]}

    return {"success": True}


def update_strategy_status(
    token: str, user_id: str, strategy_name: str, status: str
) -> dict[str, Any]:
    headers = {"Authorization": f"Bearer {token}"}

    doc_ref = f"https://firestore.googleapis.com/v1/projects/{firebase_config['projectId']}/databases/(default)/documents/users/{user_id}"

    quoted_strategy_name = f"`{strategy_name}`"

    data = {
        "fields": {
            "strategies": {
                "mapValue": {
                    "fields": {
                        "營收股價雙渦輪": {
                            "mapValue": {
                                "fields": {
                                    "status": {
                                        "mapValue": {
                                            "fields": {
                                                "start_time": {
                                                    "doubleValue": time.time()
                                                },
                                                "status": {"stringValue": status},
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    params = {"updateMask.fieldPaths": [f"strategies.{quoted_strategy_name}.status"]}

    response = requests.patch(doc_ref, headers=headers, json=data, params=params)

    if "error" in response.json():
        return {"success": False, "error": response.json()["error"]}

    return {"success": True}


def create_ipynb_file(file_content: str, file_name: str, folder_path: str) -> None:
    file_path = Path(folder_path) / file_name
    notebook_content = {
        "cells": [
            {
                "cell_type": "code",
                "execution_count": None,
                "metadata": {},
                "outputs": [],
                "source": [file_content],
            }
        ],
        "metadata": {},
        "nbformat": 4,
        "nbformat_minor": 2,
    }
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(notebook_content, f)


def is_jupyter_lab_running() -> bool:
    try:
        result = subprocess.run(
            ["pgrep", "-f", "jupyter-lab"], check=True, stdout=subprocess.PIPE
        )
        return bool(result.stdout)
    except subprocess.CalledProcessError:
        return False


def get_jupyter_url() -> str | None:
    process = subprocess.Popen(
        ["jupyter", "lab", "list"], stdout=subprocess.PIPE, stderr=subprocess.PIPE
    )
    while True:
        output = process.stdout.readline().decode("utf-8")
        if output == "" and process.poll() is not None:
            break
        if output:
            url_match = re.search(r"http://localhost:\d+/\?token=[\w:]+", output)
            if url_match:
                return url_match.group(0)
    return None


def open_ipynb_file(
    WORKSPACE_PATH: str, file_name: str, envs: Mapping[str, str], open_url: bool = True
) -> str:
    setting_file = """{"data":{"layout-restorer:data":{"down":{"size":0,"widgets":[]},"left":{"collapsed":true,"visible":false,"widgets":["filebrowser","running-sessions","@jupyterlab/toc:plugin"],"widgetStates":{"jp-running-sessions":{"sizes":[0.16666666666666666,0.16666666666666666,0.16666666666666666,0.16666666666666666,0.16666666666666666,0.16666666666666666],"expansionStates":[false,false,false,false,false,false]},"extensionmanager.main-view":{"sizes":[0.3333333333333333,0.3333333333333333,0.3333333333333333],"expansionStates":[false,false,false]}}},"right":{"collapsed":true,"visible":false,"widgets":["jp-property-inspector","debugger-sidebar"],"widgetStates":{"jp-debugger-sidebar":{"sizes":[0.2,0.2,0.2,0.2,0.2],"expansionStates":[false,false,false,false,false]}}},"relativeSizes":[0,1,0],"top":{"simpleVisibility":true}}},"metadata":{"id":"finlab","last_modified":"2024-09-07T16:09:21.164963+00:00","created":"2024-09-07T16:09:21.164963+00:00"}}"""
    with open(
        f"{WORKSPACE_PATH}/finlab.jupyterlab-workspace", "w", encoding="utf-8"
    ) as f:
        f.write(setting_file)

    command = (
        f"jupyter lab workspace import {WORKSPACE_PATH}/finlab.jupyterlab-workspace"
    )
    subprocess.Popen(
        ["bash", "-c", command], stdout=subprocess.PIPE, stderr=subprocess.PIPE
    )

    env = os.environ.copy()
    env |= envs
    command = (
        """eval "$(conda shell.bash activate)" && jupyter lab --ServerApp.root_dir=\""""
        + WORKSPACE_PATH
        + """\" --no-browser  --LabApp.tornado_settings=\"{'headers': {'Content-Security-Policy': \\"frame-ancestors 'self' http://localhost:5173 http://127.0.0.1:8888\\"}}" &"""
    )
    print(command)

    url = get_jupyter_url()
    if not url:
        print("Starting Jupyter Lab...")
        subprocess.Popen(
            ["bash", "-c", command],
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        time.sleep(5)

    url = get_jupyter_url()
    if url:
        print(f"Jupyter Lab is running at {url}")
        token = url.split("=")[-1]
        port = url.split(":")[-1].split("/")[0]

        file_name = quote(file_name)
        openning_url = f"http://localhost:{port}/lab/workspaces/finlab/tree/{file_name}?token={token}?reset"
        print(openning_url)

        # use pywebview to open the url
        if open_url:
            import webview

            webview.create_window("FinLab", openning_url)
            webview.start()

        return openning_url

    raise RuntimeError("Failed to start Jupyter Lab")


def execute_ipynb_file(
    file_name: str, folder_path: str, envs: Mapping[str, str]
) -> bool:
    file_path = Path(folder_path) / file_name

    env = os.environ.copy()
    env |= envs

    # get current env name
    env_logs = subprocess.run(
        ["conda", "info", "--envs"], stdout=subprocess.PIPE, check=False
    ).stdout.decode("utf-8")
    env_path = re.search(r"\*(.*)", env_logs).group(1).strip()
    env_name = env_path.split("/")[-1]

    command = f'eval "$(conda shell.bash activate {env_name})" && jupyter nbconvert --to notebook --execute {file_path} --output {file_name}'
    result = subprocess.run(["bash", "-c", command], check=False, env=env)
    return result.returncode == 0


def _make_token_env(**extra: str) -> dict[str, str]:
    """Build an env dict with FINLAB_API_TOKEN set from the current session."""
    token, _token_type = finlab.get_token()
    envs = os.environ.copy()
    envs["FINLAB_API_TOKEN"] = token
    envs |= extra
    return envs


def execute_notebook_with_login_info(name: str, workspace_path: str) -> bool:
    envs = _make_token_env(FINLAB_STRATEGY_NAME=name)
    return execute_ipynb_file(name, workspace_path, envs)


def register_notebook_commands(click: Any, nb: Any, workspace_path: str) -> None:
    from finlab.cli.login import _login, set_token

    os.path.isdir(workspace_path) or os.makedirs(workspace_path)

    nb_names = [
        f.split(".ipynb")[0] for f in os.listdir(workspace_path) if f.endswith(".ipynb")
    ]
    choice = click.Choice(nb_names)

    @nb.command()
    @click.argument("name")
    def pull(name: str) -> None:
        """
        Download a notebook from the cloud
        """
        user = _login(workspace_path)
        result = pull_notebook(
            user.data["firebase_login_data"]["firebase_token"],
            user.data["firebase_login_data"]["user_id"],
            name,
            workspace_path,
        )
        if not result["success"]:
            click.echo(f"Failed to pull notebook: {result['error']}")
            return

        click.echo(f"Notebook pulled successfully to {result['file_path']}")

    @nb.command()
    @click.argument("name", type=choice)
    def push(name: str) -> None:
        """
        Upload a notebook to the cloud and override the existing one.
        """
        user = _login(workspace_path)
        result = push_notebook(
            user.data["firebase_login_data"]["firebase_token"],
            user.data["firebase_login_data"]["user_id"],
            name,
            workspace_path,
        )
        if not result["success"]:
            click.echo(f"Failed to push notebook: {result['error']}")
            return

        click.echo("Notebook pushed successfully to Firebase")

    @nb.command()
    @click.argument("name")
    def jupyter(name: str) -> None:
        """
        Open Jupyter Lab with the specified notebook.
        """
        _login(workspace_path)
        set_token(workspace_path)

        envs = _make_token_env()

        nb_path = os.path.join(workspace_path, name + ".ipynb")
        if not os.path.exists(nb_path):
            create_notebook(name, nb_path)

        open_ipynb_file(workspace_path, name, envs)

    @nb.command()
    @click.argument("name")
    def open(name: str) -> None:
        """
        Open the specified notebook in Jupyter Lab.
        """
        _login(workspace_path)
        set_token(workspace_path)

        nb_path = os.path.join(workspace_path, name + ".ipynb")
        if not os.path.exists(nb_path):
            create_notebook(name, nb_path)

        file_path = os.path.join(workspace_path, name + ".ipynb")
        click.launch(file_path)

    @nb.command()
    @click.argument("name", type=choice)
    def remove(name: str) -> None:
        """
        Remove the specified notebook.
        """
        nb_path = os.path.join(workspace_path, name + ".ipynb")
        if os.path.exists(nb_path):
            os.remove(nb_path)
            click.echo(f"Notebook {name} removed successfully")
        else:
            click.echo(f"Notebook {name} not found")

    @nb.command()
    @click.argument("name", type=choice)
    def run(name: str) -> None:
        """
        Execute the specified notebook.
        """
        _login(workspace_path)
        set_token(workspace_path)

        execute_notebook_with_login_info(name, workspace_path)
