"""Agent Johnny 5 — Kimi K2.5 powered AI assistant."""
