"""EasyClaw Agentic Installer — TUI for deploying OpenClaw on headless Linux servers."""

__version__ = "0.7.9"
