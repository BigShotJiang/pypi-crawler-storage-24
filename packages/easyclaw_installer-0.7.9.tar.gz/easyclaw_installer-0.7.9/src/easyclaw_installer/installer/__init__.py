"""Installer engine — step runner, base step, and step registry."""
