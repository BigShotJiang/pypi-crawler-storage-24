"""Test step 2: Network connectivity — ping with live output."""

from ..base_step import BaseStep


class NetworkStep(BaseStep):
    name = "Network Connectivity"
    description = "Verify outbound network with ping"
    timeout = 30

    def command(self) -> str:
        return (
            "echo 'Pinging google.com (5 packets)...' && "
            "ping -c 5 google.com && "
            "echo '' && "
            "echo 'Network OK.'"
        )
