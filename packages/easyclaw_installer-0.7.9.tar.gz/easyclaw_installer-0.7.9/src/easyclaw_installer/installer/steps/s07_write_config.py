"""Step 7: Write finalized OpenClaw configuration to disk."""

from ..base_step import BaseStep


class WriteConfigStep(BaseStep):
    name = "Write Configuration"
    description = "Finalize and write OpenClaw config files"
    timeout = 30
    allow_retry = False

    def validate_preconditions(self) -> tuple[bool, str]:
        import os

        if not os.path.isdir("/etc/openclaw"):
            return False, "/etc/openclaw not found — run config wizard first"
        return True, ""

    def command(self) -> str:
        return (
            "set -e\n"
            "echo 'Writing final configuration...'\n"
            "openclaw config write --dir /etc/openclaw 2>&1\n"
            "echo ''\n"
            "echo 'Configuration files:'\n"
            "ls -la /etc/openclaw/\n"
            "echo ''\n"
            "echo 'Configuration written successfully.'"
        )
