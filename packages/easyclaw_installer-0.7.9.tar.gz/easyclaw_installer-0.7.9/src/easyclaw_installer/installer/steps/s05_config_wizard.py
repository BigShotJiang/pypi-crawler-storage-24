"""Step 5: Run the OpenClaw config wizard (non-interactive defaults)."""

from ..base_step import BaseStep


class ConfigWizardStep(BaseStep):
    name = "Configuration Wizard"
    description = "Generate initial OpenClaw configuration with defaults"
    timeout = 60
    allow_retry = False

    def validate_preconditions(self) -> tuple[bool, str]:
        import shutil

        if not shutil.which("openclaw"):
            return False, "OpenClaw CLI not found — step 3 must complete first"
        return True, ""

    def command(self) -> str:
        return (
            "set -e\n"
            "echo 'Running configuration wizard...'\n"
            "mkdir -p /etc/openclaw\n"
            "openclaw config init --non-interactive --dir /etc/openclaw 2>&1\n"
            "echo ''\n"
            "echo 'Configuration generated at /etc/openclaw/'\n"
            "ls -la /etc/openclaw/\n"
            "echo ''\n"
            "echo 'Config wizard complete.'"
        )
