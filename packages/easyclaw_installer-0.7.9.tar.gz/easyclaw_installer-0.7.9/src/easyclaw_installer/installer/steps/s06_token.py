"""Step 6: Generate an OpenClaw API token."""

from ..base_step import BaseStep


class TokenStep(BaseStep):
    name = "API Token"
    description = "Generate an OpenClaw API token for this instance"
    timeout = 30
    allow_retry = False

    def validate_preconditions(self) -> tuple[bool, str]:
        import os

        if not os.path.isdir("/etc/openclaw"):
            return False, "/etc/openclaw not found — run config wizard first"
        return True, ""

    def command(self) -> str:
        return (
            "set -e\n"
            "echo 'Generating API token...'\n"
            "openclaw token generate --dir /etc/openclaw 2>&1\n"
            "echo ''\n"
            "echo 'Token written to /etc/openclaw/token.json'\n"
            "echo 'Token generation complete.'"
        )
