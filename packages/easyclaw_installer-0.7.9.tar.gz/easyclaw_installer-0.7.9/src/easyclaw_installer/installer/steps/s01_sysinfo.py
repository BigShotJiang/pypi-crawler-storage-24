"""Test step 1: System information — uname, disk, memory."""

from ..base_step import BaseStep


class SysinfoStep(BaseStep):
    name = "System Information"
    description = "Gather OS version, disk space, and RAM"
    timeout = 30

    def command(self) -> str:
        return (
            "set -e && "
            "echo '--- Kernel ---' && uname -a && "
            "echo '' && "
            "echo '--- OS Release ---' && cat /etc/os-release && "
            "echo '' && "
            "echo '--- Disk Space ---' && df -h / && "
            "echo '' && "
            "echo '--- Memory ---' && free -h && "
            "echo '' && "
            "echo 'System info collected.'"
        )
