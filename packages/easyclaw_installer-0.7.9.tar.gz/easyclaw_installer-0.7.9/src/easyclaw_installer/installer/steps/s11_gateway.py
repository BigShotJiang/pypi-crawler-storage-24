"""Step 11: Install and configure the OpenClaw API gateway."""

from ..base_step import BaseStep


class GatewayStep(BaseStep):
    name = "API Gateway"
    description = "Install and configure the OpenClaw API gateway"
    timeout = 180
    allow_retry = True
    max_retries = 2

    def validate_preconditions(self) -> tuple[bool, str]:
        import os

        if not os.path.isdir("/etc/openclaw"):
            return False, "/etc/openclaw not found — configuration missing"
        return True, ""

    def command(self) -> str:
        return (
            "set -e\n"
            "echo 'Installing API gateway...'\n"
            "openclaw gateway install --dir /etc/openclaw 2>&1\n"
            "echo ''\n"
            "echo 'Configuring gateway routes...'\n"
            "openclaw gateway configure --dir /etc/openclaw 2>&1\n"
            "echo ''\n"
            "echo 'API gateway installation complete.'"
        )
