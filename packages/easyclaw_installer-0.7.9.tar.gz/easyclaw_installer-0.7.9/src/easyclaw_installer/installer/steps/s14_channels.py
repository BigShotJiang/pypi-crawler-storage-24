"""Step 14: Set up communication channels for OpenClaw."""

from ..base_step import BaseStep


class ChannelSetupStep(BaseStep):
    name = "Channel Setup"
    description = "Configure communication channels (webhooks, integrations)"
    timeout = 60
    allow_retry = True
    max_retries = 1

    def validate_preconditions(self) -> tuple[bool, str]:
        import shutil

        if not shutil.which("openclaw"):
            return False, "OpenClaw CLI not found"
        return True, ""

    def command(self) -> str:
        return (
            "set -e\n"
            "echo 'Setting up communication channels...'\n"
            "openclaw channels init --dir /etc/openclaw 2>&1\n"
            "echo ''\n"
            "echo 'Channel status:'\n"
            "openclaw channels list --dir /etc/openclaw 2>&1\n"
            "echo ''\n"
            "echo 'Channel setup complete.'"
        )
