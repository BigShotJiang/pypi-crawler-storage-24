"""Step 10: Validate the OpenClaw configuration."""

from ..base_step import BaseStep


class ValidateStep(BaseStep):
    name = "Validate Configuration"
    description = "Run full validation on OpenClaw config and workspace"
    timeout = 30
    allow_retry = False

    def validate_preconditions(self) -> tuple[bool, str]:
        import os

        if not os.path.isdir("/etc/openclaw"):
            return False, "/etc/openclaw not found — configuration missing"
        return True, ""

    def command(self) -> str:
        return (
            "set -e\n"
            "echo 'Validating configuration...'\n"
            "openclaw config validate --dir /etc/openclaw 2>&1\n"
            "echo ''\n"
            "echo 'Validating workspace...'\n"
            "openclaw workspace validate --dir /var/lib/openclaw 2>&1\n"
            "echo ''\n"
            "echo 'All validations passed.'"
        )
