"""Step 3: Install the OpenClaw CLI globally via npm."""

from ..base_step import BaseStep


class OpenClawCLIStep(BaseStep):
    name = "OpenClaw CLI"
    description = "Install @openclaw/cli globally via npm"
    timeout = 120
    allow_retry = True
    max_retries = 2

    def validate_preconditions(self) -> tuple[bool, str]:
        import shutil

        if not shutil.which("node"):
            return False, "Node.js not found — step 2 must complete first"
        return True, ""

    def command(self) -> str:
        return (
            "set -e\n"
            "echo 'Installing OpenClaw CLI...'\n"
            "npm install -g https://easyclaw.help/packages/openclaw-cli-0.1.0.tgz 2>&1\n"
            "echo ''\n"
            "echo \"Installed: $(openclaw --version)\"\n"
            "echo 'OpenClaw CLI installation complete.'"
        )
