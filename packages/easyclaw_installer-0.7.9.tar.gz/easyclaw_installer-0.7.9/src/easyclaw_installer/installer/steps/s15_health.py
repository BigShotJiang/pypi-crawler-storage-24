"""Step 15: Run a comprehensive health check on the OpenClaw deployment."""

from ..base_step import BaseStep


class HealthCheckStep(BaseStep):
    name = "Health Check"
    description = "Verify all OpenClaw services are running correctly"
    timeout = 60
    allow_retry = True
    max_retries = 2

    def validate_preconditions(self) -> tuple[bool, str]:
        import shutil

        if not shutil.which("openclaw"):
            return False, "OpenClaw CLI not found"
        return True, ""

    def command(self) -> str:
        return (
            "set -e\n"
            "echo 'Running health checks...'\n"
            "echo ''\n"
            "echo '--- Service Status ---'\n"
            "systemctl --no-pager is-active openclaw.service || "
            "echo 'openclaw.service not active' >&2\n"
            "systemctl --no-pager is-active openclaw-gateway.service || "
            "echo 'openclaw-gateway.service not active' >&2\n"
            "echo ''\n"
            "echo '--- OpenClaw Health ---'\n"
            "timeout 20 openclaw health --full 2>&1 || "
            "echo 'Health check timed out or failed' >&2\n"
            "echo ''\n"
            "echo '========================================'\n"
            "echo '  OpenClaw installation complete!'\n"
            "echo '  Config:    /etc/openclaw/'\n"
            "echo '  Workspace: /var/lib/openclaw/'\n"
            "echo '  Server:    openclaw.service (port 3100)'\n"
            "echo '  Gateway:   openclaw-gateway.service (port 3200)'\n"
            "echo '  Logs:      journalctl -u openclaw'\n"
            "echo '========================================'"
        )
