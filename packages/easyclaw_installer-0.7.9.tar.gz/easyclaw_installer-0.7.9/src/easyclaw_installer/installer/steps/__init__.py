"""Step registry — ordered list of BaseStep instances to execute.

Phase 5: 15 production OpenClaw installation steps.
Steps execute sequentially; pipeline stops on unrecoverable failure.
Agent Johnny 5 can intervene on failure via proactive diagnosis.
"""

from ..base_step import BaseStep

from .s01_preflight import PreflightStep
from .s02_nodejs import NodejsStep
from .s03_openclaw_cli import OpenClawCLIStep
from .s04_mcp_tools import MCPToolsStep
from .s05_config_wizard import ConfigWizardStep
from .s06_token import TokenStep
from .s07_write_config import WriteConfigStep
from .s08_env_vars import EnvVarsStep
from .s09_workspace import WorkspaceStep
from .s10_validate import ValidateStep
from .s11_gateway import GatewayStep
from .s12_systemd import SystemdStep
from .s13_mcp_connect import MCPConnectStep
from .s14_channels import ChannelSetupStep
from .s15_health import HealthCheckStep

STEP_REGISTRY: list[BaseStep] = [
    PreflightStep(),        # 1.  OS, arch, disk, RAM, root
    NodejsStep(),           # 2.  Node.js 20.x LTS
    OpenClawCLIStep(),      # 3.  @openclaw/cli
    MCPToolsStep(),         # 4.  @openclaw/mcp-tools
    ConfigWizardStep(),     # 5.  openclaw config init
    TokenStep(),            # 6.  openclaw token generate
    WriteConfigStep(),      # 7.  openclaw config write
    EnvVarsStep(),          # 8.  environment variables
    WorkspaceStep(),        # 9.  workspace directories
    ValidateStep(),         # 10. config + workspace validation
    GatewayStep(),          # 11. API gateway
    SystemdStep(),          # 12. systemd units + start
    MCPConnectStep(),       # 13. MCP knowledge base
    ChannelSetupStep(),     # 14. communication channels
    HealthCheckStep(),      # 15. full health check
]
