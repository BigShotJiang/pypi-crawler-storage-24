"""Step 9: Initialize the OpenClaw workspace directory structure."""

from ..base_step import BaseStep


class WorkspaceStep(BaseStep):
    name = "Workspace Setup"
    description = "Create OpenClaw workspace directories and data stores"
    timeout = 60
    allow_retry = True
    max_retries = 1

    def validate_preconditions(self) -> tuple[bool, str]:
        import shutil

        if not shutil.which("openclaw"):
            return False, "OpenClaw CLI not found — step 3 must complete first"
        return True, ""

    def command(self) -> str:
        return (
            "set -e\n"
            "echo 'Initializing workspace...'\n"
            "openclaw workspace init --dir /var/lib/openclaw 2>&1\n"
            "echo ''\n"
            "echo 'Workspace structure:'\n"
            "find /var/lib/openclaw -maxdepth 2 -type d | head -20\n"
            "echo ''\n"
            "echo 'Workspace initialization complete.'"
        )
