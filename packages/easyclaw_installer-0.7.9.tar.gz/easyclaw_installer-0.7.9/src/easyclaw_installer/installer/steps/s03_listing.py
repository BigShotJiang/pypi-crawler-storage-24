"""Test step 3: Directory listing — enumerate /etc/ contents."""

from ..base_step import BaseStep


class ListingStep(BaseStep):
    name = "Directory Listing"
    description = "List /etc/ contents (tests high-volume output)"
    timeout = 30

    def command(self) -> str:
        return (
            "echo 'Listing /etc/ ...' && "
            "ls -la /etc/ && "
            "echo '' && "
            "echo 'Listing complete.'"
        )
