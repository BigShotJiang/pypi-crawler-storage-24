"""Step 4: Install OpenClaw MCP tools globally via npm."""

from ..base_step import BaseStep


class MCPToolsStep(BaseStep):
    name = "MCP Tools"
    description = "Install @openclaw/mcp-tools for knowledge-base access"
    timeout = 120
    allow_retry = True
    max_retries = 2

    def validate_preconditions(self) -> tuple[bool, str]:
        import shutil

        if not shutil.which("node"):
            return False, "Node.js not found — step 2 must complete first"
        return True, ""

    def command(self) -> str:
        return (
            "set -e\n"
            "echo 'Installing OpenClaw MCP tools...'\n"
            "npm install -g https://easyclaw.help/packages/openclaw-mcp-tools-0.1.0.tgz 2>&1\n"
            "echo ''\n"
            "echo \"Installed: $(openclaw-mcp --version)\"\n"
            "echo 'MCP tools installation complete.'"
        )
