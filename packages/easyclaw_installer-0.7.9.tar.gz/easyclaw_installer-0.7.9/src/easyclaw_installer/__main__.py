"""Entry point for `python -m easyclaw_installer`."""

import argparse

from .app import EasyClawApp
from .constants import DEFAULT_MCP_URL


def main() -> None:
    parser = argparse.ArgumentParser(
        description="EasyClaw Agentic Installer"
    )
    parser.add_argument(
        "--api-key",
        default="",
        help="OpenRouter API key for Agent Johnny 5 (or set OPENROUTER_API_KEY env var)",
    )
    parser.add_argument(
        "--mcp-url",
        default=DEFAULT_MCP_URL,
        help=f"MCP knowledge base server URL (default: {DEFAULT_MCP_URL})",
    )
    parser.add_argument(
        "--mcp-key",
        default="",
        help="MCP API key for knowledge base auth (or set EASYCLAW_MCP_KEY env var)",
    )
    parser.add_argument(
        "--no-mcp",
        action="store_true",
        help="Disable MCP knowledge base connection",
    )
    args = parser.parse_args()

    mcp_url = "" if args.no_mcp else args.mcp_url
    mcp_key = "" if args.no_mcp else args.mcp_key
    app = EasyClawApp(api_key=args.api_key, mcp_url=mcp_url, mcp_key=mcp_key)
    app.run()


if __name__ == "__main__":
    main()
