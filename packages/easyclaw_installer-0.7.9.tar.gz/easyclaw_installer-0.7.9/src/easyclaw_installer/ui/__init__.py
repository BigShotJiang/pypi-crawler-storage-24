"""UI widgets for the EasyClaw installer."""
