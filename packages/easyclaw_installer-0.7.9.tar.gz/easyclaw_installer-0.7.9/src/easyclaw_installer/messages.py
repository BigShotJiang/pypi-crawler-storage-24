"""Custom Textual messages for cross-component communication.

Messages bubble upward from child widgets to the App.
The App's handlers dispatch to the appropriate subsystems.
"""

from textual.message import Message


class LogLine(Message):
    """A line of stdout/stderr from the active installation subprocess."""

    def __init__(self, text: str, is_stderr: bool = False) -> None:
        self.text = text
        self.is_stderr = is_stderr
        super().__init__()


class StepStarted(Message):
    """Fired when a new installation step begins."""

    def __init__(self, index: int, name: str, total: int) -> None:
        self.index = index
        self.name = name
        self.total = total
        super().__init__()


class StepCompleted(Message):
    """Fired when a step finishes (success or failure)."""

    def __init__(
        self, index: int, name: str, success: bool, error: str = ""
    ) -> None:
        self.index = index
        self.name = name
        self.success = success
        self.error = error
        super().__init__()


class InstallFinished(Message):
    """Fired when all steps complete or an unrecoverable error occurs."""

    def __init__(self, success: bool) -> None:
        self.success = success
        super().__init__()


class AgentTyping(Message):
    """Agent is processing — show a typing indicator in the chat pane."""
    pass


class AgentReply(Message):
    """A complete message from Agent Johnny 5.

    Posted from the agent's background thread via call_from_thread().
    Contains the FULL final text (not a streaming partial).
    """

    def __init__(self, text: str) -> None:
        self.text = text
        super().__init__()


class AgentToolCall(Message):
    """Agent requested a tool execution — displayed in chat as an indicator."""

    def __init__(self, tool_name: str, args: dict) -> None:
        self.tool_name = tool_name
        self.args = args
        super().__init__()


class UserChatSubmit(Message):
    """User pressed Enter in the chat input field."""

    def __init__(self, text: str) -> None:
        self.text = text
        super().__init__()
