import os
import sys

from .common import parse_gei_disam_args
from . import GEI
from . import pck

extract_pck = pck.extract_pck
_iter_exe_el_candidates = pck._iter_exe_el_candidates


def main(argv=None):
    if argv is None:
        argv = sys.argv[1:]
    args = list(argv)
    dat_txt = False
    try:
        args, gei, dat_txt = parse_gei_disam_args(
            args,
            disam_action=lambda: None,
            allow_gei_disam=False,
        )
    except ValueError as e:
        sys.stderr.write(str(e) + "\n")
        return 2
    if not args or args[0] in ("-h", "--help", "help"):
        return 2

    if gei:
        if len(args) == 1:
            in_path = args[0]
            out_dir = os.path.dirname(os.path.abspath(in_path))
        elif len(args) == 2:
            in_path, out_dir = args
        else:
            return 2

        if os.path.isdir(in_path):
            in_path = os.path.join(in_path, "Gameexe.dat")

        os_dir = os.path.dirname(os.path.abspath(in_path))
        cands = list(_iter_exe_el_candidates(os_dir))
        if not cands:
            cands = [b""]
        last_err = None
        for exe_el in cands:
            try:
                out_path = GEI.restore_gameexe_ini(in_path, out_dir, exe_el=exe_el)
                sys.stdout.write(f"Wrote: {out_path}\n")
                return 0
            except Exception as e:
                last_err = e
        sys.stderr.write(str(last_err) + "\n")
        return 1

    if len(args) != 2:
        return 2
    return extract_pck(args[0], args[1], dat_txt)


if __name__ == "__main__":
    raise SystemExit(main())
