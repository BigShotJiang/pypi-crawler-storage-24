__version__ = "0.1.12"

try:
    from ._const_manager import const_exists, load_const_module

    if const_exists():
        load_const_module()
except Exception:
    pass
