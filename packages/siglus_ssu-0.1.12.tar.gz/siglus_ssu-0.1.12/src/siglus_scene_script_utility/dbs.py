import struct

import os
import csv
import re

from . import const as C
from .native_ops import lzss_pack, lzss_unpack, tile_copy
from .common import _sha1, read_bytes, write_bytes


def _xor32_inplace(barr, code):
    if not barr:
        return
    n = (len(barr) // 4) * 4
    code = int(code) & 0xFFFFFFFF
    for i in range(0, n, 4):
        v = struct.unpack_from("<I", barr, i)[0] ^ code
        struct.pack_into("<I", barr, i, v)


def _dbs_unpack(blob):
    if not blob or len(blob) < 12:
        return 0, b""
    m_type = struct.unpack_from("<i", blob, 0)[0]

    packed = bytearray(blob[4:])
    _xor32_inplace(packed, C.DBS_XOR32_CODE)

    unpack_data = lzss_unpack(bytes(packed))
    if not unpack_data:
        return m_type, b""

    unpack_size = len(unpack_data)

    yl = unpack_size // (C.DBS_MAP_WIDTH * 4)
    if yl <= 0:
        return m_type, b""

    temp_a = bytearray(unpack_size)
    temp_b = bytearray(unpack_size)

    tile_copy(
        temp_a,
        bytes(unpack_data),
        C.DBS_MAP_WIDTH,
        yl,
        C.DBS_TILE,
        C.DBS_TILE_WIDTH,
        C.DBS_TILE_HEIGHT,
        0,
        0,
        0,
        128,
    )
    tile_copy(
        temp_b,
        bytes(unpack_data),
        C.DBS_MAP_WIDTH,
        yl,
        C.DBS_TILE,
        C.DBS_TILE_WIDTH,
        C.DBS_TILE_HEIGHT,
        0,
        0,
        1,
        128,
    )

    _xor32_inplace(temp_a, C.DBS_XOR32_CODE_A)
    _xor32_inplace(temp_b, C.DBS_XOR32_CODE_B)

    dst = bytearray(unpack_size)
    tile_copy(
        dst,
        bytes(temp_a),
        C.DBS_MAP_WIDTH,
        yl,
        C.DBS_TILE,
        C.DBS_TILE_WIDTH,
        C.DBS_TILE_HEIGHT,
        0,
        0,
        0,
        128,
    )
    tile_copy(
        dst,
        bytes(temp_b),
        C.DBS_MAP_WIDTH,
        yl,
        C.DBS_TILE,
        C.DBS_TILE_WIDTH,
        C.DBS_TILE_HEIGHT,
        0,
        0,
        1,
        128,
    )

    return m_type, bytes(dst)


def _dbs_get_str(m_type, sblob: bytes, ofs: int) -> str:
    if not sblob:
        return ""
    try:
        ofs = int(ofs)
    except Exception:
        return ""
    if ofs < 0 or ofs >= len(sblob):
        return ""
    if int(m_type) == 0:
        end = sblob.find(b"\x00", ofs)
        if end < 0:
            end = len(sblob)

        return sblob[ofs:end].decode("shift_jis", errors="replace")

    end = ofs
    while end + 1 < len(sblob):
        if sblob[end] == 0 and sblob[end + 1] == 0:
            break
        end += 2
    return sblob[ofs:end].decode("utf-16le", errors="replace")


def _parse_dbs(m_type: int, data: bytes):
    if (not data) or len(data) < 28:
        raise ValueError("dbs expanded data too small")

    (
        raw_data_size,
        row_cnt,
        col_cnt,
        raw_row_ofs,
        raw_col_ofs,
        raw_data_ofs,
        raw_str_ofs,
    ) = struct.unpack_from("<7i", data, 0)

    row_cnt = int(row_cnt)
    col_cnt = int(col_cnt)
    if row_cnt < 0 or col_cnt < 0:
        raise ValueError("dbs negative row/col count")
    if row_cnt > 500000 or col_cnt > 500000:
        raise ValueError("dbs row/col count too large")

    def _try_scale(scale: int):
        data_size = int(raw_data_size)
        row_ofs = int(raw_row_ofs) * scale
        col_ofs = int(raw_col_ofs) * scale
        data_ofs = int(raw_data_ofs) * scale
        str_ofs = int(raw_str_ofs) * scale

        if data_size <= 0:
            data_size = len(data)
        else:
            data_size = data_size * scale
        if data_size > len(data):
            data_size = len(data)

        if not (
            0 <= row_ofs <= len(data)
            and 0 <= col_ofs <= len(data)
            and 0 <= data_ofs <= len(data)
            and 0 <= str_ofs <= len(data)
        ):
            return None
        if not (0 <= str_ofs <= data_size <= len(data)):
            return None

        row_hdr_sz = row_cnt * 4
        col_hdr_sz = col_cnt * 8
        cell_cnt = row_cnt * col_cnt

        if cell_cnt < 0 or cell_cnt > 1_000_000_000:
            return None
        dt_sz = cell_cnt * 4

        if not (row_ofs <= col_ofs <= data_ofs <= str_ofs):
            return None

        if row_ofs + row_hdr_sz > len(data):
            return None
        if col_ofs + col_hdr_sz > len(data):
            return None
        if data_ofs + dt_sz > len(data):
            return None

        return (data_size, row_ofs, col_ofs, data_ofs, str_ofs, dt_sz, scale)

    chosen = _try_scale(1)
    if chosen is None:
        chosen = _try_scale(4)
    if chosen is None:
        raise ValueError("dbs offset out of range")

    data_size, row_ofs, col_ofs, data_ofs, str_ofs, dt_sz, ofs_scale = chosen

    row_calls = []
    if row_cnt:
        row_calls = list(struct.unpack_from(f"<{row_cnt:d}i", data, row_ofs))

    col_headers = []
    for i in range(col_cnt):
        call_no, data_type = struct.unpack_from("<2i", data, col_ofs + i * 8)
        col_headers.append((int(call_no), int(data_type)))

    str_blob = data[str_ofs:data_size] if str_ofs < data_size else b""

    return {
        "m_type": int(m_type),
        "data_size": int(data_size),
        "row_cnt": row_cnt,
        "col_cnt": col_cnt,
        "row_header_offset": int(row_ofs),
        "column_header_offset": int(col_ofs),
        "data_offset": int(data_ofs),
        "str_offset": int(str_ofs),
        "offset_scale": int(ofs_scale),
        "row_calls": row_calls,
        "col_headers": col_headers,
        "str_blob": str_blob,
        "data_blob": data,
    }


def compare_dbs(b1: bytes, b2: bytes) -> int:
    try:
        t1, u1 = _dbs_unpack(b1)
        t2, u2 = _dbs_unpack(b2)
    except Exception as e:
        print(f"dbs: unpack failed: {e}")
        return 1

    print("dbs structural compare:")
    print(f"  m_type_1={int(t1):d}  unpacked_sha1_1={_sha1(u1)}")
    print(f"  m_type_2={int(t2):d}  unpacked_sha1_2={_sha1(u2)}")

    if u1 == u2 and int(t1) == int(t2):
        print("  identical after XOR+LZSS unpack")
        return 0

    try:
        s1 = _parse_dbs(t1, u1)
        s2 = _parse_dbs(t2, u2)
    except Exception as e:
        print(f"  parse failed: {e}")

        lim = min(len(u1), len(u2), 1024 * 1024)
        first = None
        for i in range(lim):
            if u1[i] != u2[i]:
                first = i
                break
        if first is None and len(u1) != len(u2):
            first = lim
        if first is not None:
            print(f"  first_diff_offset={first:d}")
        return 0

    def _hd(k):
        return (k, s1.get(k), s2.get(k))

    diffs = []
    for k in (
        "m_type",
        "data_size",
        "row_cnt",
        "col_cnt",
        "row_header_offset",
        "column_header_offset",
        "data_offset",
        "str_offset",
    ):
        if s1.get(k) != s2.get(k):
            diffs.append(_hd(k))
    if diffs:
        print("")
        print("header diffs:")
        for k, a, b in diffs:
            print(f"  {k}: {a!r} -> {b!r}")

    r1 = s1["row_calls"]
    r2 = s2["row_calls"]
    c1 = s1["col_headers"]
    c2 = s2["col_headers"]

    if r1 != r2:
        set1 = set(r1)
        set2 = set(r2)
        print("")
        print("row call_no diffs:")
        only1 = sorted(list(set1 - set2))[: C.MAX_LIST_PREVIEW]
        only2 = sorted(list(set2 - set1))[: C.MAX_LIST_PREVIEW]
        if only1:
            print(f"  only in file1 (preview): {', '.join([str(x) for x in only1])}")
        if only2:
            print(f"  only in file2 (preview): {', '.join([str(x) for x in only2])}")
        if not only1 and not only2:
            print("  (same set, different order)")

    if c1 != c2:
        map1 = {cn: dt for cn, dt in c1}
        map2 = {cn: dt for cn, dt in c2}
        only1 = sorted(list(set(map1.keys()) - set(map2.keys())))[: C.MAX_LIST_PREVIEW]
        only2 = sorted(list(set(map2.keys()) - set(map1.keys())))[: C.MAX_LIST_PREVIEW]
        common = sorted(list(set(map1.keys()) & set(map2.keys())))
        typechg = [cn for cn in common if map1.get(cn) != map2.get(cn)][
            : C.MAX_LIST_PREVIEW
        ]

        print("")
        print("column call_no diffs:")
        if only1:
            print(f"  only in file1 (preview): {', '.join([str(x) for x in only1])}")
        if only2:
            print(f"  only in file2 (preview): {', '.join([str(x) for x in only2])}")
        if typechg:
            print(
                f"  data_type changed (preview): {', '.join([str(x) for x in typechg])}"
            )
        if (not only1) and (not only2) and (not typechg):
            print("  (same set, different order)")

    if (
        (s1["row_cnt"] == s2["row_cnt"])
        and (s1["col_cnt"] == s2["col_cnt"])
        and (r1 == r2)
        and (c1 == c2)
    ):
        rc = s1["row_cnt"]
        cc = s1["col_cnt"]
        total = rc * cc
        limit = min(total, 2_000_000)
        print("")
        print(f"cell diffs (scan {limit:d} / {total:d} cells):")
        dif_cnt = 0
        sblob1 = s1["str_blob"]
        sblob2 = s2["str_blob"]
        base1 = s1["data_offset"]
        base2 = s2["data_offset"]
        for idx in range(limit):
            o1 = base1 + idx * 4
            o2 = base2 + idx * 4
            v1 = struct.unpack_from("<I", s1["data_blob"], o1)[0]
            v2 = struct.unpack_from("<I", s2["data_blob"], o2)[0]
            if v1 != v2:
                r = idx // cc
                c = idx % cc
                col_call_no, dt = c1[c]
                ch = chr(dt & 0xFF)
                if ch == "S":
                    sv1 = _dbs_get_str(t1, sblob1, int(v1))
                    sv2 = _dbs_get_str(t2, sblob2, int(v2))
                    print(
                        f"  r={r:d} c={c:d} col_call_no={col_call_no:d}: {sv1!r} -> {sv2!r}"
                    )
                else:
                    iv1 = struct.unpack("<i", struct.pack("<I", v1))[0]
                    iv2 = struct.unpack("<i", struct.pack("<I", v2))[0]
                    print(
                        f"  r={r:d} c={c:d} col_call_no={col_call_no:d}: {iv1:d} -> {iv2:d}"
                    )
                dif_cnt += 1
                if dif_cnt >= 20:
                    print("  ... (stopped after 20 diffs)")
                    break
        if dif_cnt == 0:
            print("  (no diffs found in scanned region)")
        if total > limit:
            print("  note: table is large; scan was capped")
    else:
        lim = min(len(u1), len(u2), 1024 * 1024)
        first = None
        for i in range(lim):
            if u1[i] != u2[i]:
                first = i
                break
        if first is None and len(u1) != len(u2):
            first = lim
        if first is not None:
            print("")
            print("unpacked byte-level diff:")
            print(f"  first_diff_offset={first:d}")

    return 0


def _dbs_cell_to_text(m_type: int, info: dict, col_idx: int, raw_val: int) -> str:
    try:
        _, dt = info["col_headers"][col_idx]
    except Exception:
        dt = 0
    ch = chr(dt & 0xFF) if 32 <= (dt & 0xFF) <= 126 else ""
    if ch == "S":
        try:
            return _dbs_get_str(m_type, info.get("str_blob") or b"", int(raw_val))
        except Exception:
            return ""

    try:
        v = int(raw_val) & 0xFFFFFFFF
        if v >= 0x80000000:
            v -= 0x100000000
        return str(v)
    except Exception:
        return str(raw_val)


_MSVCRT_RAND_STATE = 1


def reset_msvcrt_rand(seed: int = 1) -> None:
    global _MSVCRT_RAND_STATE
    _MSVCRT_RAND_STATE = int(seed) & 0xFFFFFFFF


def burn_msvcrt_rand(n: int) -> None:
    n = int(n)
    if n <= 0:
        return
    for _ in range(n):
        _msvcrt_rand_byte()


def _msvcrt_rand_byte() -> int:
    global _MSVCRT_RAND_STATE
    _MSVCRT_RAND_STATE = (_MSVCRT_RAND_STATE * 214013 + 2531011) & 0xFFFFFFFF
    return ((_MSVCRT_RAND_STATE >> 16) & 0x7FFF) & 0xFF


def _wtoi_prefix(s):
    if s is None:
        return None
    m = re.match(r"^[\s]*([+-]?\d+)", str(s))
    if not m:
        return None
    try:
        return int(m.group(1), 10)
    except Exception:
        return None


def _read_official_csv(csv_path: str):
    with open(csv_path, "r", encoding="utf-8-sig", newline="") as f:
        rows = [row for row in csv.reader(f)]
    datano_i = None
    datatype_i = None
    for i, row in enumerate(rows):
        if not row:
            continue
        k = (row[0] or "").strip().upper()
        if k == "#DATANO" and datano_i is None:
            datano_i = i
        if k == "#DATATYPE" and datatype_i is None:
            datatype_i = i
        if datano_i is not None and datatype_i is not None:
            break
    if datano_i is None:
        raise ValueError("#DATANO not found")
    if datatype_i is None:
        raise ValueError("#DATATYPE not found")
    datano_row = rows[datano_i]
    datatype_row = rows[datatype_i]
    max_cols = max(len(datano_row), len(datatype_row))
    col_specs = []
    for ci in range(1, max_cols):
        call_no = _wtoi_prefix(datano_row[ci] if ci < len(datano_row) else "")
        if call_no is None:
            continue
        t = (datatype_row[ci] if ci < len(datatype_row) else "").strip().upper()
        if t == "S":
            dt = 83
        elif t == "V":
            dt = 86
        else:
            raise ValueError(f"invalid datatype for call number {int(call_no)}: {t!r}")
        col_specs.append((ci, int(call_no), int(dt)))
    if not col_specs:
        raise ValueError("no columns found in #DATANO/#DATATYPE")
    data_rows = []
    row_calls = []
    for row in rows[datatype_i + 1 :]:
        if not row:
            continue
        row_call = _wtoi_prefix(row[0] if len(row) > 0 else "")
        if row_call is None:
            continue
        row_calls.append(int(row_call))
        data_rows.append(row)
    return col_specs, row_calls, data_rows


def export_one_dbs_to_csv(dbs_path: str, out_csv_path: str) -> None:
    blob = read_bytes(dbs_path)
    m_type, expanded = _dbs_unpack(blob)
    info = _parse_dbs(m_type, expanded)
    row_cnt = int(info.get("row_cnt") or 0)
    col_cnt = int(info.get("col_cnt") or 0)
    data_ofs = int(info.get("data_offset") or 0)
    data_blob = info.get("data_blob") or expanded
    cols = info.get("col_headers") or []
    head_datano = ["#DATANO"]
    head_dtype = ["#DATATYPE"]
    for call_no, dt in cols:
        head_datano.append(str(int(call_no)))
        ch = chr(int(dt) & 0xFF) if 32 <= (int(dt) & 0xFF) <= 126 else ""
        if ch == "S":
            head_dtype.append("S")
        elif ch == "V":
            head_dtype.append("V")
        else:
            head_dtype.append("")
    os.makedirs(os.path.dirname(out_csv_path) or ".", exist_ok=True)
    with open(out_csv_path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f, lineterminator="\r\n")
        w.writerow(head_datano)
        w.writerow(head_dtype)
        row_calls = info.get("row_calls") or []
        for r in range(row_cnt):
            row = [str(int(row_calls[r]) if r < len(row_calls) else r)]
            base = data_ofs + (r * col_cnt * 4)
            for c in range(col_cnt):
                try:
                    raw_val = struct.unpack_from("<I", data_blob, base + c * 4)[0]
                except Exception:
                    raw_val = 0
                row.append(_dbs_cell_to_text(m_type, info, c, raw_val))
            w.writerow(row)


def create_one_dbs_from_csv(
    csv_path: str, out_dbs_path: str, *, m_type: int = 1
) -> None:
    col_specs, row_calls, data_rows = _read_official_csv(csv_path)
    row_cnt = len(row_calls)
    col_cnt = len(col_specs)
    row_ofs = 28
    col_ofs = row_ofs + row_cnt * 4
    data_ofs = col_ofs + col_cnt * 8
    str_ofs = data_ofs + row_cnt * col_cnt * 4
    prefix = bytearray(str_ofs)
    str_blob = bytearray()
    struct.pack_into(
        "<7i", prefix, 0, 0, row_cnt, col_cnt, row_ofs, col_ofs, data_ofs, str_ofs
    )
    for i, call_no in enumerate(row_calls):
        struct.pack_into("<i", prefix, row_ofs + i * 4, int(call_no))
    for i, (_csv_idx, call_no, dt) in enumerate(col_specs):
        struct.pack_into("<2i", prefix, col_ofs + i * 8, int(call_no), int(dt))
    for r in range(row_cnt):
        row = data_rows[r] if r < len(data_rows) else []
        base = data_ofs + (r * col_cnt * 4)
        for c in range(col_cnt):
            csv_idx, _call_no, dt = col_specs[c]
            cell = row[csv_idx] if csv_idx < len(row) else ""
            if dt == 83:
                ofs = len(str_blob)
                str_blob.extend(_dbs_encode_text(m_type, cell))
                struct.pack_into("<I", prefix, base + c * 4, int(ofs))
            else:
                v = _wtoi_prefix(cell)
                if v is None:
                    v = 0
                struct.pack_into("<I", prefix, base + c * 4, int(v) & 0xFFFFFFFF)
    data_size = str_ofs + len(str_blob)
    struct.pack_into("<i", prefix, 0, int(data_size))
    expanded = bytes(prefix) + bytes(str_blob)
    align = int(C.DBS_MAP_WIDTH * 4)
    if align <= 0:
        align = 64
    padded_size = (len(expanded) + (align - 1)) // align * align
    dst = bytearray(padded_size)
    dst[: len(expanded)] = expanded
    if padded_size > len(expanded):
        st = len(expanded) + 1
        if st < padded_size:
            for i in range(st, padded_size):
                dst[i] = _msvcrt_rand_byte()
    out_blob = _dbs_pack(int(m_type), bytes(dst))
    os.makedirs(os.path.dirname(out_dbs_path) or ".", exist_ok=True)
    write_bytes(out_dbs_path, out_blob)


def _dbs_pack(m_type: int, expanded: bytes) -> bytes:
    if not expanded:
        return struct.pack("<i", int(m_type))
    unpack_size = len(expanded)
    yl = unpack_size // (C.DBS_MAP_WIDTH * 4)
    if yl <= 0:
        return struct.pack("<i", int(m_type))
    temp_a = bytearray(unpack_size)
    temp_b = bytearray(unpack_size)
    tile_copy(
        temp_a,
        bytes(expanded),
        C.DBS_MAP_WIDTH,
        yl,
        C.DBS_TILE,
        C.DBS_TILE_WIDTH,
        C.DBS_TILE_HEIGHT,
        0,
        0,
        0,
        128,
    )
    tile_copy(
        temp_b,
        bytes(expanded),
        C.DBS_MAP_WIDTH,
        yl,
        C.DBS_TILE,
        C.DBS_TILE_WIDTH,
        C.DBS_TILE_HEIGHT,
        0,
        0,
        1,
        128,
    )
    _xor32_inplace(temp_a, C.DBS_XOR32_CODE_A)
    _xor32_inplace(temp_b, C.DBS_XOR32_CODE_B)
    merged = bytearray(unpack_size)
    tile_copy(
        merged,
        bytes(temp_a),
        C.DBS_MAP_WIDTH,
        yl,
        C.DBS_TILE,
        C.DBS_TILE_WIDTH,
        C.DBS_TILE_HEIGHT,
        0,
        0,
        0,
        128,
    )
    tile_copy(
        merged,
        bytes(temp_b),
        C.DBS_MAP_WIDTH,
        yl,
        C.DBS_TILE,
        C.DBS_TILE_WIDTH,
        C.DBS_TILE_HEIGHT,
        0,
        0,
        1,
        128,
    )
    packed = bytearray(lzss_pack(bytes(merged)))
    _xor32_inplace(packed, C.DBS_XOR32_CODE)
    return struct.pack("<i", int(m_type)) + bytes(packed)


def _dbs_encode_text(m_type: int, text: str) -> bytes:
    s = "" if text is None else str(text)
    if int(m_type) == 0:
        return s.encode("shift_jis", errors="replace") + b"\x00"
    return s.encode("utf-16le", errors="replace") + b"\x00\x00"
