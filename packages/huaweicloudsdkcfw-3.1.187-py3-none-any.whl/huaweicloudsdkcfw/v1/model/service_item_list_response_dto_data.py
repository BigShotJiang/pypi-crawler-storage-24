# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ServiceItemListResponseDtoData:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'offset': 'int',
        'limit': 'int',
        'total': 'int',
        'set_id': 'str',
        'records': 'list[ServiceItemListResponseDtoDataRecords]'
    }

    attribute_map = {
        'offset': 'offset',
        'limit': 'limit',
        'total': 'total',
        'set_id': 'set_id',
        'records': 'records'
    }

    def __init__(self, offset=None, limit=None, total=None, set_id=None, records=None):
        r"""ServiceItemListResponseDtoData

        The model defined in huaweicloud sdk

        :param offset: 偏移量：指定返回记录的开始位置，必须为数字，取值范围为大于或等于0，默认0
        :type offset: int
        :param limit: 每页显示个数，范围为1-1024
        :type limit: int
        :param total: 服务组成员总数
        :type total: int
        :param set_id: 服务组id
        :type set_id: str
        :param records: 记录
        :type records: list[:class:`huaweicloudsdkcfw.v1.ServiceItemListResponseDtoDataRecords`]
        """
        
        

        self._offset = None
        self._limit = None
        self._total = None
        self._set_id = None
        self._records = None
        self.discriminator = None

        if offset is not None:
            self.offset = offset
        if limit is not None:
            self.limit = limit
        if total is not None:
            self.total = total
        if set_id is not None:
            self.set_id = set_id
        if records is not None:
            self.records = records

    @property
    def offset(self):
        r"""Gets the offset of this ServiceItemListResponseDtoData.

        偏移量：指定返回记录的开始位置，必须为数字，取值范围为大于或等于0，默认0

        :return: The offset of this ServiceItemListResponseDtoData.
        :rtype: int
        """
        return self._offset

    @offset.setter
    def offset(self, offset):
        r"""Sets the offset of this ServiceItemListResponseDtoData.

        偏移量：指定返回记录的开始位置，必须为数字，取值范围为大于或等于0，默认0

        :param offset: The offset of this ServiceItemListResponseDtoData.
        :type offset: int
        """
        self._offset = offset

    @property
    def limit(self):
        r"""Gets the limit of this ServiceItemListResponseDtoData.

        每页显示个数，范围为1-1024

        :return: The limit of this ServiceItemListResponseDtoData.
        :rtype: int
        """
        return self._limit

    @limit.setter
    def limit(self, limit):
        r"""Sets the limit of this ServiceItemListResponseDtoData.

        每页显示个数，范围为1-1024

        :param limit: The limit of this ServiceItemListResponseDtoData.
        :type limit: int
        """
        self._limit = limit

    @property
    def total(self):
        r"""Gets the total of this ServiceItemListResponseDtoData.

        服务组成员总数

        :return: The total of this ServiceItemListResponseDtoData.
        :rtype: int
        """
        return self._total

    @total.setter
    def total(self, total):
        r"""Sets the total of this ServiceItemListResponseDtoData.

        服务组成员总数

        :param total: The total of this ServiceItemListResponseDtoData.
        :type total: int
        """
        self._total = total

    @property
    def set_id(self):
        r"""Gets the set_id of this ServiceItemListResponseDtoData.

        服务组id

        :return: The set_id of this ServiceItemListResponseDtoData.
        :rtype: str
        """
        return self._set_id

    @set_id.setter
    def set_id(self, set_id):
        r"""Sets the set_id of this ServiceItemListResponseDtoData.

        服务组id

        :param set_id: The set_id of this ServiceItemListResponseDtoData.
        :type set_id: str
        """
        self._set_id = set_id

    @property
    def records(self):
        r"""Gets the records of this ServiceItemListResponseDtoData.

        记录

        :return: The records of this ServiceItemListResponseDtoData.
        :rtype: list[:class:`huaweicloudsdkcfw.v1.ServiceItemListResponseDtoDataRecords`]
        """
        return self._records

    @records.setter
    def records(self, records):
        r"""Sets the records of this ServiceItemListResponseDtoData.

        记录

        :param records: The records of this ServiceItemListResponseDtoData.
        :type records: list[:class:`huaweicloudsdkcfw.v1.ServiceItemListResponseDtoDataRecords`]
        """
        self._records = records

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ServiceItemListResponseDtoData):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
