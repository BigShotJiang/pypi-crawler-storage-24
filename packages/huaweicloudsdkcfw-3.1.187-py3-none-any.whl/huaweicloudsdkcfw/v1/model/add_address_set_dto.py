# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class AddAddressSetDto:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'object_id': 'str',
        'name': 'str',
        'description': 'str',
        'address_type': 'int'
    }

    attribute_map = {
        'object_id': 'object_id',
        'name': 'name',
        'description': 'description',
        'address_type': 'address_type'
    }

    def __init__(self, object_id=None, name=None, description=None, address_type=None):
        r"""AddAddressSetDto

        The model defined in huaweicloud sdk

        :param object_id: 防护对象id，是创建云防火墙后用于区分互联网边界防护和VPC边界防护的标志id，可通过调用[查询防火墙实例接口](ListFirewallDetail.xml)获得，通过返回值中的data.records.protect_objects.object_id（.表示各对象之间层级的区分）获得，type为0时，object_id为互联网边界防护对象ID，type为1时，object_id为VPC边界防护对象ID，type可通过data.records.protect_objects.type（.表示各对象之间层级的区分）获得，此处只能使用type为0的防护对象id
        :type object_id: str
        :param name: 地址组名称
        :type name: str
        :param description: 地址组描述
        :type description: str
        :param address_type: **参数解释**： 地址类型 **约束限制**： 不涉及 **取值范围**： - 0：IPv4 - 1：IPv6 **默认取值**： 0：IPv4
        :type address_type: int
        """
        
        

        self._object_id = None
        self._name = None
        self._description = None
        self._address_type = None
        self.discriminator = None

        self.object_id = object_id
        self.name = name
        if description is not None:
            self.description = description
        if address_type is not None:
            self.address_type = address_type

    @property
    def object_id(self):
        r"""Gets the object_id of this AddAddressSetDto.

        防护对象id，是创建云防火墙后用于区分互联网边界防护和VPC边界防护的标志id，可通过调用[查询防火墙实例接口](ListFirewallDetail.xml)获得，通过返回值中的data.records.protect_objects.object_id（.表示各对象之间层级的区分）获得，type为0时，object_id为互联网边界防护对象ID，type为1时，object_id为VPC边界防护对象ID，type可通过data.records.protect_objects.type（.表示各对象之间层级的区分）获得，此处只能使用type为0的防护对象id

        :return: The object_id of this AddAddressSetDto.
        :rtype: str
        """
        return self._object_id

    @object_id.setter
    def object_id(self, object_id):
        r"""Sets the object_id of this AddAddressSetDto.

        防护对象id，是创建云防火墙后用于区分互联网边界防护和VPC边界防护的标志id，可通过调用[查询防火墙实例接口](ListFirewallDetail.xml)获得，通过返回值中的data.records.protect_objects.object_id（.表示各对象之间层级的区分）获得，type为0时，object_id为互联网边界防护对象ID，type为1时，object_id为VPC边界防护对象ID，type可通过data.records.protect_objects.type（.表示各对象之间层级的区分）获得，此处只能使用type为0的防护对象id

        :param object_id: The object_id of this AddAddressSetDto.
        :type object_id: str
        """
        self._object_id = object_id

    @property
    def name(self):
        r"""Gets the name of this AddAddressSetDto.

        地址组名称

        :return: The name of this AddAddressSetDto.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        r"""Sets the name of this AddAddressSetDto.

        地址组名称

        :param name: The name of this AddAddressSetDto.
        :type name: str
        """
        self._name = name

    @property
    def description(self):
        r"""Gets the description of this AddAddressSetDto.

        地址组描述

        :return: The description of this AddAddressSetDto.
        :rtype: str
        """
        return self._description

    @description.setter
    def description(self, description):
        r"""Sets the description of this AddAddressSetDto.

        地址组描述

        :param description: The description of this AddAddressSetDto.
        :type description: str
        """
        self._description = description

    @property
    def address_type(self):
        r"""Gets the address_type of this AddAddressSetDto.

        **参数解释**： 地址类型 **约束限制**： 不涉及 **取值范围**： - 0：IPv4 - 1：IPv6 **默认取值**： 0：IPv4

        :return: The address_type of this AddAddressSetDto.
        :rtype: int
        """
        return self._address_type

    @address_type.setter
    def address_type(self, address_type):
        r"""Sets the address_type of this AddAddressSetDto.

        **参数解释**： 地址类型 **约束限制**： 不涉及 **取值范围**： - 0：IPv4 - 1：IPv6 **默认取值**： 0：IPv4

        :param address_type: The address_type of this AddAddressSetDto.
        :type address_type: int
        """
        self._address_type = address_type

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, AddAddressSetDto):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
