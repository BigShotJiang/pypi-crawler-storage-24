"""Pseudocode generator using enhanced XAML analysis."""

import logging
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from rpacli import __version__
from rpacli.parser.enhanced_xaml_analyzer import (
    EnhancedActivityNode,
    EnhancedXamlAnalyzer,
)

from .models import PseudocodeArtifact, PseudocodeEntry, PseudocodeIndex

logger = logging.getLogger(__name__)


class PseudocodeGenerator:
    """Generate gist-style pseudocode from enhanced XAML analysis."""

    def __init__(self):
        self.analyzer = EnhancedXamlAnalyzer()

    def generate_workflow_pseudocode(
        self, xaml_path: Path, workflow_id: str | None = None, relative_path: str = ""
    ) -> PseudocodeArtifact:
        """Generate pseudocode for a single workflow.

        Args:
            xaml_path: Path to workflow XAML file
            workflow_id: Stable relative workflow ID (e.g. "Framework/CheckExists").
                         Defaults to the file stem when not provided, which loses
                         subdirectory context and causes filename collisions.
            relative_path: Source XAML relative path (e.g. "Framework/CloseAllApplications.xaml")

        Returns:
            PseudocodeArtifact with structured pseudocode entries
        """
        effective_id = workflow_id or xaml_path.stem
        try:
            # Analyze workflow with enhanced parser
            visual_activities, metadata = self.analyzer.analyze_workflow(xaml_path)

            if not visual_activities:
                logger.warning(f"No visual activities found in {xaml_path}")
                return self._create_empty_artifact(
                    effective_id, relative_path=relative_path
                )

            # Generate pseudocode entries
            entries = self._generate_pseudocode_entries(visual_activities)

            # Create artifact
            artifact = PseudocodeArtifact(
                workflow_id=effective_id,
                project_id="unknown",  # Default when no project context
                project_slug="unknown",  # Default when no project context
                relative_path=relative_path,
                generated_at=datetime.now(UTC).isoformat(),
                rpax_version=__version__,
                activities=[self._serialize_entry(entry) for entry in entries],
                activity_count=len(visual_activities),
                total_lines=len(entries),
                total_activities=len(visual_activities),
                entries=[self._serialize_entry(entry) for entry in entries],
                metadata={
                    "source_file": str(xaml_path),
                    "generation_method": "enhanced-visual-detection",
                    "parser_metadata": metadata,
                },
            )

            return artifact

        except Exception as e:
            logger.error(f"Failed to generate pseudocode for {xaml_path}: {e}")
            return self._create_empty_artifact(
                effective_id, error=str(e), relative_path=relative_path
            )

    def generate_project_pseudocode_index(
        self,
        project_slug: str,
        project_id: str,
        pseudocode_summaries: list[dict],
    ) -> PseudocodeIndex:
        """Generate index of all pseudocode artifacts in project.

        Args:
            project_slug: Project slug identifier
            project_id: Project ID
            pseudocode_summaries: Lightweight list of dicts with keys workflowId,
                totalLines, totalActivities, hasError — full artifacts not required.

        Returns:
            PseudocodeIndex with project-level metadata
        """
        workflows = [
            {
                "workflowId": s["workflowId"],
                "totalLines": s.get("totalLines", 0),
                "totalActivities": s.get("totalActivities", 0),
                "hasError": s.get("hasError", False),
            }
            for s in pseudocode_summaries
        ]

        return PseudocodeIndex(
            project_id=project_id,
            project_slug=project_slug,
            total_workflows=len(pseudocode_summaries),
            workflows=workflows,
            generated_at=datetime.now(UTC).isoformat(),
        )

    def _generate_pseudocode_entries(
        self, activities: list[EnhancedActivityNode]
    ) -> list[PseudocodeEntry]:
        """Generate pseudocode entries from activity nodes.

        Args:
            activities: List of enhanced activity nodes

        Returns:
            List of pseudocode entries with hierarchy
        """
        # Build parent→children index once (O(N)) instead of scanning per node (O(N²))
        children_map: dict[str | None, list[EnhancedActivityNode]] = {}
        for act in activities:
            children_map.setdefault(act.parent_id, []).append(act)

        entries = []
        for root in children_map.get(None, []):
            entries.extend(self._process_activity_recursive(root, children_map, 0))

        return entries

    def _process_activity_recursive(
        self,
        activity: EnhancedActivityNode,
        children_map: dict[str | None, list[EnhancedActivityNode]],
        indent: int,
    ) -> list[PseudocodeEntry]:
        """Recursively process activity and its children.

        Args:
            activity: Current activity node
            children_map: Pre-built parent_id → children lookup
            indent: Current indentation level

        Returns:
            List of pseudocode entries for this activity and children
        """
        entries = []

        # Generate pseudocode line for current activity
        formatted_line = self._format_pseudocode_line(activity, indent)

        # Derive targetRelativePath for InvokeWorkflowFile entries
        target_relative_path: str | None = None
        if activity.tag == "InvokeWorkflowFile" and activity.invocation_target:
            target_relative_path = activity.invocation_target.replace("\\", "/")

        # Create entry
        entry = PseudocodeEntry(
            indent=indent,
            display_name=activity.display_name,
            tag=activity.tag,
            activity_path=activity.path,
            formatted_line=formatted_line,
            node_id=activity.node_id,
            depth=activity.depth,
            is_visual=activity.is_visual,
            target_relative_path=target_relative_path,
        )

        entries.append(entry)

        # Process children with increased indentation
        for child in children_map.get(activity.node_id, []):
            child_entries = self._process_activity_recursive(
                child, children_map, indent + 1
            )
            entries.extend(child_entries)
            if child_entries:
                entry.children.append(child_entries[0])  # direct child only, not whole subtree

        return entries

    def _format_pseudocode_line(
        self, activity: EnhancedActivityNode, indent: int
    ) -> str:
        """Format single pseudocode line in gist style.

        Args:
            activity: Activity node to format
            indent: Indentation level

        Returns:
            Formatted pseudocode line
        """
        # Create indentation with hyphens (gist style)
        indent_str = "  " * indent + "- " if indent > 0 else "- "

        # Format: - [DisplayName] Tag (ActivityPath: Activity/...)
        return f"{indent_str}[{activity.display_name}] {activity.tag} (ActivityPath: {activity.path})"

    def _serialize_entry(self, entry: PseudocodeEntry) -> dict[str, Any]:
        """Serialize pseudocode entry to dictionary.

        Args:
            entry: PseudocodeEntry to serialize

        Returns:
            Dictionary representation
        """
        result = {
            "indent": entry.indent,
            "displayName": entry.display_name,
            "tag": entry.tag,
            "activityPath": entry.activity_path,
            "formattedLine": entry.formatted_line,
            "nodeId": entry.node_id,
            "depth": entry.depth,
            "isVisual": entry.is_visual,
            "children": [self._serialize_entry(child) for child in entry.children],
        }
        if entry.target_relative_path is not None:
            result["targetRelativePath"] = entry.target_relative_path
        return result

    def _create_empty_artifact(
        self, workflow_id: str, error: str = None, relative_path: str = ""
    ) -> PseudocodeArtifact:
        """Create empty pseudocode artifact for error cases.

        Args:
            workflow_id: Workflow identifier
            error: Optional error message
            relative_path: Source XAML relative path

        Returns:
            Empty PseudocodeArtifact
        """
        metadata = {}
        if error:
            metadata["error"] = error

        return PseudocodeArtifact(
            workflow_id=workflow_id,
            project_id="unknown",  # Default when no project context
            project_slug="unknown",  # Default when no project context
            relative_path=relative_path,
            generated_at=datetime.now(UTC).isoformat(),
            rpax_version=__version__,
            activities=[],
            activity_count=0,
            total_lines=0,
            total_activities=0,
            entries=[],
            metadata=metadata,
        )

    def render_as_text(self, artifact: PseudocodeArtifact) -> str:
        """Render pseudocode artifact as formatted text.

        Args:
            artifact: PseudocodeArtifact to render

        Returns:
            Formatted text representation
        """
        if not artifact.entries:
            return f"# No pseudocode available for {artifact.workflow_id}"

        lines = []

        for entry_data in artifact.entries:
            lines.append(entry_data["formattedLine"])

        return "\n".join(lines)
