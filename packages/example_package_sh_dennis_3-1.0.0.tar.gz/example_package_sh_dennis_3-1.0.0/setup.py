from setuptools import setup, find_packages

setup(
    name="example_package_sh_dennis_3",
    version="1.0.0",
    package_dir={"": "src"},              # ✅ VERY IMPORTANT
    packages=find_packages(where="src"),  # ✅ VERY IMPORTANT
    install_requires=[
        "requests>=2"
    ],
)