"""
MicroPDF - High-performance PDF manipulation library for Python

A Python interface to the MicroPDF library, providing fast PDF operations
through native Rust FFI bindings.

Example:
    >>> import micropdf
    >>> doc = micropdf.Document.open('file.pdf')
    >>> print(f"Pages: {doc.page_count()}")
    >>> page = doc.load_page(0)
    >>> text = page.extract_text()
    >>> doc.close()

Modules:
    - context: Context management
    - document: Document operations
    - page: Page operations
    - pixmap: Image/pixel operations
    - buffer: Buffer operations
    - geometry: Point, Rect, Matrix, Quad
    - colorspace: Color management
    - easy: Simplified API for common tasks
    - security: Certificates, digital signatures, encryption
    - html_to_pdf: HTML-to-PDF conversion
    - composition: Document layout (Platypus-style)
    - office: Office document support (DOCX, XLSX, PPTX)
    - font_info: PDF font information
    - image_ops: PDF image operations
    - pdf_writer: Low-level PDF writer
"""

from .version import __version__
from .context import Context
from .document import Document, Page
from .buffer import Buffer
from .pixmap import Pixmap
from .geometry import (
    Point, Rect, IRect, Matrix, Quad,
    transform_points_batch, transform_rects_batch,
    point_distances_batch, point_distances_squared_batch,
    rect_contains_points_batch, count_points_in_rect,
    rect_union_batch, filter_points_in_rect, nearest_point
)
from .colorspace import Colorspace
from .errors import MicroPDFError, ErrorCode
from .easy import EasyPDF

# Enhanced operations
from .enhanced import (
    merge_pdfs,
    split_pdf as enhanced_split_pdf,
    reorder_pages,
    add_watermark,
    overlay_pdf,
    optimize_pdf,
    linearize_pdf,
    add_blank_page,
    get_bookmarks,
    restore_bookmarks,
    register_font,
    free_font,
    get_last_error,
)

# Convenience functions
from .convenience import (
    PDFInfo,
    PageDimensions,
    RenderedPage,
    ExtractedText,
    get_pdf_info,
    get_page_count,
    get_page_dimensions,
    extract_text,
    extract_page_text,
    render_page_to_png,
    render_page_to_rgb,
    merge_pdfs as merge_pdf_files,
    split_pdf,
    copy_pages,
    is_valid_pdf,
    repair_pdf,
)

# Security
from .security import (
    Certificate,
    EncryptionOptions,
    EncryptionAlgorithm,
    PDFPermission,
    SignatureVerification,
    sign_pdf,
    sign_pdf_invisible,
    verify_signature,
    signature_count,
    encrypt_pdf,
    decrypt_pdf,
    is_encrypted,
)

# HTML-to-PDF
from .html_to_pdf import (
    PageSize,
    HtmlOptions,
    html_to_pdf,
    html_file_to_pdf,
)

# Document Composition
from .composition import (
    Alignment,
    DocTemplate,
    Frame,
    Story,
    Paragraph,
    Spacer,
    TableStyle,
    Table,
    TableOfContents,
    TocBuilder,
    ParagraphStyle,
    StyleSheet,
    CompositionImage,
    HorizontalRule,
    ListItem,
)

# Office documents
from .office import (
    DocumentType,
    OfficeDocument,
    type_name as office_type_name,
    type_extension as office_type_extension,
)

# Font info
from .font_info import PdfFont

# Image operations
from .image_ops import PdfImage

# PDF Writer
from .pdf_writer import PdfWriter

# Resource tracking and profiling
from .resource_tracking import (
    enable_tracking,
    track_resource,
    untrack_resource,
    get_tracked_resources,
    get_potential_leaks,
    get_leak_warnings,
    get_memory_summary,
    clear_tracking,
    cached_ffi_call,
    get_cached_ffi_func,
    clear_ffi_cache,
    get_object_memory_size,
    get_all_object_sizes,
    print_memory_report,
    ResourceScope,
    TrackedResource,
)

from .profiler import (
    enable_profiling,
    enable_stack_traces,
    is_profiling_enabled,
    track_allocation,
    track_deallocation,
    get_leak_report,
    print_leak_report,
    reset_profiler,
    start_tracemalloc,
    stop_tracemalloc,
    print_tracemalloc_top,
    force_gc,
    print_gc_stats,
    get_memory_usage,
    print_memory_usage,
    ResourceType,
)

__all__ = [
    # Version
    "__version__",
    # Core classes
    "Context",
    "Document",
    "Page",
    "Buffer",
    "Pixmap",
    # Geometry
    "Point",
    "Rect",
    "IRect",
    "Matrix",
    "Quad",
    # Batch operations
    "transform_points_batch",
    "transform_rects_batch",
    "point_distances_batch",
    "point_distances_squared_batch",
    "rect_contains_points_batch",
    "count_points_in_rect",
    "rect_union_batch",
    "filter_points_in_rect",
    "nearest_point",
    # Color
    "Colorspace",
    # Errors
    "MicroPDFError",
    "ErrorCode",
    # Easy API
    "EasyPDF",
    # Enhanced operations
    "merge_pdfs",
    "enhanced_split_pdf",
    "reorder_pages",
    "add_watermark",
    "overlay_pdf",
    "optimize_pdf",
    "linearize_pdf",
    "add_blank_page",
    "get_bookmarks",
    "restore_bookmarks",
    "register_font",
    "free_font",
    "get_last_error",
    # Convenience functions
    "PDFInfo",
    "PageDimensions",
    "RenderedPage",
    "ExtractedText",
    "get_pdf_info",
    "get_page_count",
    "get_page_dimensions",
    "extract_text",
    "extract_page_text",
    "render_page_to_png",
    "render_page_to_rgb",
    "merge_pdf_files",
    "split_pdf",
    "copy_pages",
    "is_valid_pdf",
    "repair_pdf",
    # Security
    "Certificate",
    "EncryptionOptions",
    "EncryptionAlgorithm",
    "PDFPermission",
    "SignatureVerification",
    "sign_pdf",
    "sign_pdf_invisible",
    "verify_signature",
    "signature_count",
    "encrypt_pdf",
    "decrypt_pdf",
    "is_encrypted",
    # HTML-to-PDF
    "PageSize",
    "HtmlOptions",
    "html_to_pdf",
    "html_file_to_pdf",
    # Composition
    "Alignment",
    "DocTemplate",
    "Frame",
    "Story",
    "Paragraph",
    "Spacer",
    "TableStyle",
    "Table",
    "TableOfContents",
    "TocBuilder",
    "ParagraphStyle",
    "StyleSheet",
    "CompositionImage",
    "HorizontalRule",
    "ListItem",
    # Office
    "DocumentType",
    "OfficeDocument",
    "office_type_name",
    "office_type_extension",
    # Font info
    "PdfFont",
    # Image operations
    "PdfImage",
    # PDF Writer
    "PdfWriter",
    # Resource tracking
    "enable_tracking",
    "track_resource",
    "untrack_resource",
    "get_tracked_resources",
    "get_potential_leaks",
    "get_leak_warnings",
    "get_memory_summary",
    "clear_tracking",
    "cached_ffi_call",
    "get_cached_ffi_func",
    "clear_ffi_cache",
    "get_object_memory_size",
    "get_all_object_sizes",
    "print_memory_report",
    "ResourceScope",
    "TrackedResource",
    # Profiler
    "enable_profiling",
    "enable_stack_traces",
    "is_profiling_enabled",
    "track_allocation",
    "track_deallocation",
    "get_leak_report",
    "print_leak_report",
    "reset_profiler",
    "start_tracemalloc",
    "stop_tracemalloc",
    "print_tracemalloc_top",
    "force_gc",
    "print_gc_stats",
    "get_memory_usage",
    "print_memory_usage",
    "ResourceType",
]
