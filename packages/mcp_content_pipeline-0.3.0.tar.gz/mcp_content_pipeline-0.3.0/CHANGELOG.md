# Changelog

## [0.3.0](https://github.com/berkayyildirim/mcp-content-pipeline/compare/v0.2.1...v0.3.0) (2026-03-09)


### Features

* add cookie-based YouTube authentication for IP bypass ([daeabfe](https://github.com/berkayyildirim/mcp-content-pipeline/commit/daeabfee041143de7d9ac9eab3d573eb1bb24f83))

## [0.2.1](https://github.com/berkayyildirim/mcp-content-pipeline/compare/v0.2.0...v0.2.1) (2026-03-09)


### Bug Fixes

* update youtube-transcript-api to v1.x API ([5f27c53](https://github.com/berkayyildirim/mcp-content-pipeline/commit/5f27c532be59876c3646ffdb853f00061b3f00f2))

## [0.2.0](https://github.com/berkayyildirim/mcp-content-pipeline/compare/v0.1.0...v0.2.0) (2026-03-09)


### Features

* add transcript translation fallback and live URL support ([9e32e3e](https://github.com/berkayyildirim/mcp-content-pipeline/commit/9e32e3e516692f208823809ca46a809a76d3f607))

## 0.1.0 (2026-03-08)


### Features

* initial mcp-content-pipeline implementation ([feea870](https://github.com/berkayyildirim/mcp-content-pipeline/commit/feea870e9e41abc8e023071749dada3ecc6f89c8))
