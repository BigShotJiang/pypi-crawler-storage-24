import json
from pathlib import Path

from pymultirole_plugins.v1.schema import Annotation, Document

from pyprocessors_categories_from_annotations.categories_from_annotations import (
    CategoriesFromAnnotationsParameters,
    CategoriesFromAnnotationsProcessor,
    ProcessingUnit,
    create_categories_from_annotations,
    has_knowledge,
)


def test_model():
    model = CategoriesFromAnnotationsProcessor.get_model()
    model_class = model.model_construct().__class__
    assert model_class == CategoriesFromAnnotationsParameters


def test_categories_from_annotations():
    testdir = Path(__file__).parent
    source = Path(testdir, "data/SHERPA-1776-1.json")

    with source.open("r") as fin:
        jdoc = json.load(fin)
    docs = [Document(**jdoc)]
    processor = CategoriesFromAnnotationsProcessor()
    parameters = CategoriesFromAnnotationsParameters()
    docs = processor.process(docs, parameters)
    doc0 = docs[0]
    assert len(doc0.categories) == 0

    docs = [Document(**jdoc)]
    parameters.multi_label_threshold = 0.0
    docs = processor.process(docs, parameters)
    doc0 = docs[0]
    assert len(doc0.categories) == 9

    docs = [Document(**jdoc)]
    parameters.processing_unit = ProcessingUnit.segment
    docs = processor.process(docs, parameters)
    doc0 = docs[0]
    assert len(doc0.categories) == 0
    sent0 = doc0.sentences[0]
    assert len(sent0.categories) == 1


def test_categories_from_gazetteer():
    testdir = Path(__file__).parent
    source = Path(testdir, "data/chatbot_sales_marketing_ner-document-test.json")

    with source.open("r") as fin:
        jdoc = json.load(fin)
    docs = [Document(**jdoc)]
    processor = CategoriesFromAnnotationsProcessor()
    parameters = CategoriesFromAnnotationsParameters(use_gazetteer=True)
    docs = processor.process(docs, parameters)
    doc0 = docs[0]
    assert len(doc0.categories) == 1
    assert doc0.categories[0].label == "AFP News"


def test_empty_annotations():
    categories = create_categories_from_annotations(None)
    assert categories == []

    categories = create_categories_from_annotations([])
    assert categories == []


def test_score_calculation():
    # 2 annotations with same label out of 4 total → score = 0.5
    anns = [
        Annotation(start=0, end=5, labelName="A"),
        Annotation(start=6, end=10, labelName="A"),
        Annotation(start=11, end=15, labelName="B"),
        Annotation(start=16, end=20, labelName="C"),
    ]
    categories = create_categories_from_annotations(anns, threshold=0.0)
    scores = {c.label: c.score for c in categories}
    assert scores["A"] == 0.5
    assert scores["B"] == 0.25
    assert scores["C"] == 0.25


def test_threshold_is_exclusive():
    # score exactly equal to threshold should be excluded (score > threshold, not >=)
    anns = [
        Annotation(start=0, end=5, labelName="A"),
        Annotation(start=6, end=10, labelName="B"),
    ]
    # each label has score 0.5; threshold=0.5 should exclude both
    categories = create_categories_from_annotations(anns, threshold=0.5)
    assert categories == []

    # threshold just below 0.5 should include them
    categories = create_categories_from_annotations(anns, threshold=0.49)
    assert len(categories) == 2


def test_process_empty_documents():
    processor = CategoriesFromAnnotationsProcessor()
    parameters = CategoriesFromAnnotationsParameters()
    result = processor.process([], parameters)
    assert result == []


def test_process_document_without_annotations():
    doc = Document(text="Hello world", identifier="doc1")
    processor = CategoriesFromAnnotationsProcessor()
    parameters = CategoriesFromAnnotationsParameters(multi_label_threshold=0.0)
    docs = processor.process([doc], parameters)
    assert docs[0].categories == []


def test_process_multiple_documents():
    testdir = Path(__file__).parent
    source = Path(testdir, "data/SHERPA-1776-1.json")
    with source.open("r") as fin:
        jdoc = json.load(fin)
    processor = CategoriesFromAnnotationsProcessor()
    parameters = CategoriesFromAnnotationsParameters(multi_label_threshold=0.0)
    docs = processor.process([Document(**jdoc), Document(**jdoc)], parameters)
    assert len(docs) == 2
    assert len(docs[0].categories) == 9
    assert len(docs[1].categories) == 9


def test_segment_processing_without_sentences():
    # segment mode but document has no sentences → annotations left unprocessed
    anns = [Annotation(start=0, end=5, labelName="A")]
    doc = Document(text="Hello", annotations=anns, identifier="doc1")
    processor = CategoriesFromAnnotationsProcessor()
    parameters = CategoriesFromAnnotationsParameters(processing_unit=ProcessingUnit.segment)
    docs = processor.process([doc], parameters)
    # no sentences → elif branch not taken → annotations unchanged, no categories set
    assert docs[0].annotations is not None
    assert docs[0].categories is None


def test_has_knowledge():
    ann_no_terms = Annotation(start=0, end=5, labelName="A")
    assert not has_knowledge(ann_no_terms)

    ann_empty_terms = Annotation(start=0, end=5, labelName="A", terms=[])
    assert not has_knowledge(ann_empty_terms)


def test_gazetteer_annotation_without_knowledge_is_skipped():
    # use_gazetteer=True but annotation has no terms → category not created
    anns = [Annotation(start=0, end=5, labelName="A")]
    categories = create_categories_from_annotations(anns, threshold=0.0, use_gazetteer=True)
    assert categories == []


def test_segment_score_uses_sentence_annotation_count():
    testdir = Path(__file__).parent
    source = Path(testdir, "data/SHERPA-1776-1.json")
    with source.open("r") as fin:
        jdoc = json.load(fin)
    processor = CategoriesFromAnnotationsProcessor()
    parameters = CategoriesFromAnnotationsParameters(processing_unit=ProcessingUnit.segment, multi_label_threshold=0.0)
    docs = processor.process([Document(**jdoc)], parameters)
    doc0 = docs[0]
    # document-level categories cleared when segment mode
    assert doc0.categories == []
    # each sentence that had annotations should have at least one category
    sentences_with_categories = [s for s in doc0.sentences if s.categories]
    assert len(sentences_with_categories) > 0
