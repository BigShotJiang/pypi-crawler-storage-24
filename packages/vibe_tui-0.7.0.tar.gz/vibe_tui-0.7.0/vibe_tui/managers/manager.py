from ..keyinput import Key
from ..event.eventmanager import Event

class FocusManager:
    def __init__(self, root_node, modals=None):
        self.main_root = root_node
        self.modals = modals if modals else []
        self.focusable_nodes = []
        self.index = 0
        self.refresh_nodes()

    @property
    def current_root(self):
        """Returns the modal content if a modal is active, otherwise the main root."""
        for modal in reversed(self.modals):
            if getattr(modal, "is_active", False):
                # If it's a UIModalNode, we focus its internal content
                return getattr(modal, "content_node", modal)
        return self.main_root

    def refresh_nodes(self):
        """Deep-scans the active root and ensures focus is locked."""
        current_node = self.focusable_nodes[self.index] if self.focusable_nodes and self.index < len(self.focusable_nodes) else None
        
        self.focusable_nodes = self._find_focusable(self.current_root)
        
        if self.focusable_nodes:
            if current_node in self.focusable_nodes:
                self.index = self.focusable_nodes.index(current_node)
            else:
                self.index = min(self.index, len(self.focusable_nodes) - 1)
                
            for i, node in enumerate(self.focusable_nodes):
                node.selected = (i == self.index)

    def _find_focusable(self, node):
        """
        Fixed Recursion: Strictly separates Layout nodes from Tab content 
        to ensure every widget is only found ONCE.
        """
        focusable = []
        
        # 1. Self-Check
        if getattr(node, 'focusable', True):
            focusable.append(node)
            
        # 2. Layout Discovery (HL/VL)
        # We use a set to keep track of what we've already found in this branch
        found_ids = set()

        if hasattr(node, 'nodes'):
            for child in node.nodes:
                child_nodes = self._find_focusable(child)
                for cn in child_nodes:
                    if id(cn) not in found_ids:
                        focusable.append(cn)
                        found_ids.add(id(cn))
        
        # 3. Tab Content Discovery
        # If it's a TabManager, only dive into the ACTIVE content body,
        # ignore the buttons because they were already found in step 2.
        if hasattr(node, 'get_active_content'):
            content = node.get_active_content()
            if content:
                content_nodes = self._find_focusable(content)
                for cn in content_nodes:
                    if id(cn) not in found_ids:
                        focusable.append(cn)
                        found_ids.add(id(cn))

        return focusable

    def focus_node(self, node):
        """Focuses a specific node by its object reference."""
        self.refresh_nodes()
        if node in self.focusable_nodes:
            # Deselect current
            if self.focusable_nodes and self.index < len(self.focusable_nodes):
                self.focusable_nodes[self.index].selected = False
            
            # Select new
            self.index = self.focusable_nodes.index(node)
            self.focusable_nodes[self.index].selected = True
            return True
        return False

    def next(self):
        if not self.focusable_nodes: return
        self.focusable_nodes[self.index].selected = False
        self.index = (self.index + 1) % len(self.focusable_nodes)
        self.focusable_nodes[self.index].selected = True

    def prev(self):
        if not self.focusable_nodes: return
        self.focusable_nodes[self.index].selected = False
        self.index = (self.index - 1) % len(self.focusable_nodes)
        self.focusable_nodes[self.index].selected = True

    @property
    def current(self):
        return self.focusable_nodes[self.index] if self.focusable_nodes else None

    def handle_input(self, key):
        self.refresh_nodes() # Ensure we are acting on the correct root/modal
        event = Event(key)
        
        # 1. Automatic Modal Intercept
        active_modal = None
        for modal in reversed(self.modals):
            if getattr(modal, "is_active", False):
                active_modal = modal
                break
        
        if active_modal:
            # Universal Close on ESC
            if event.is_escape:
                active_modal.is_active = False
                self.refresh_nodes()
                return
            
            # If it's a simple Modal with its own input logic (non-recursive)
            if hasattr(active_modal, 'handle_input') and not hasattr(active_modal, 'content_node'):
                active_modal.handle_input(key)
                # If handle_input closed the modal, refresh
                if not active_modal.is_active:
                    self.refresh_nodes()
                return
            
            # If it's a recursive ModalNode, we let the standard navigation (step 2) handle it
            # because 'current_root' is already pointing to the modal's content.

        # 2. Standard Navigation & Delegation
        if event.is_tab:
            self.next()
        elif event.is_btab:
            self.prev()
        elif self.current:
            if hasattr(self.current, 'handle_input'):
                self.current.handle_input(key)
                # Auto-refresh if the interactive tree changed (e.g. Tab switch or Modal toggle)
                self.refresh_nodes()
            elif event.is_enter or (event.is_char and event.char == " "):
                if hasattr(self.current, 'press'):
                    self.current.press()
                    self.refresh_nodes()