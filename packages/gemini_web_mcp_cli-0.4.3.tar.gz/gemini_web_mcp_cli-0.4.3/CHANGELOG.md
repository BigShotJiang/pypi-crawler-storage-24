# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## [0.4.3] - 2026-03-08

### Added
- **Codex native MCP support** — `gemcli setup add codex` / `gemcli setup remove codex` now use `codex mcp add/remove` CLI commands instead of redirecting to skill install. Codex appears as a configurable tool in `gemcli setup add all` with proper detection and status.
- **Claude Desktop `.mcpb` extension** — new `desktop-extension/` directory with `manifest.json` (MCP manifest v0.2) + `run_server.py` (cross-platform `uvx` finder for macOS/Linux/Windows). Packaged as `.mcpb` zip and attached to GitHub releases. This solves Claude Desktop's restricted PATH issue where GUI apps can't find CLI tools.
- **MCPB build script** — `scripts/build_mcpb.py` syncs version from `pyproject.toml` into `manifest.json` and packages the extension.
- **GitHub Actions MCPB pipeline** — release workflow now builds and uploads the `.mcpb` extension alongside PyPI artifacts.

### Changed
- **Claude Desktop removed from CLI setup** — `claude-desktop` is no longer a valid argument for `gemcli setup add/remove`. Users should download the `.mcpb` extension from the GitHub release instead.
- **Full binary paths for JSON clients** — `_add_mcp_server()` now resolves the full path to `gemini-web-mcp` via `shutil.which()`, ensuring GUI apps launched from the Dock can find the binary.

---

## [0.4.2] - 2026-03-08

### Added
- **`setup add all` / `setup remove all`** — interactive multi-tool setup ported from the NotebookLM MCP CLI sibling project. `gemcli setup add all` scans the system for AI tools, shows a Rich table with detection and configuration status, and lets you choose which tools to configure (all, specific numbers, or none). `gemcli setup remove all` removes MCP from all configured tools with explicit confirmation (defaults to No for safety).
- **Rich-click colored CLI help** — replaced plain Click with `rich-click` for styled, colorful `--help` output across all commands (bordered panels, colored usage, styled options). Drop-in upgrade — same API, better aesthetics.

### Fixed
- **Codex skill paths** — updated from legacy `.codex/AGENTS.md` format to official `.agents/skills/SKILL.md` per OpenAI Codex documentation. Detection logic now checks `~/.agents/` existence.

### Changed
- **CLI argument validation** — `setup add` and `setup remove` switched from `click.Choice()` to manual validation to support dynamic values (`all`, `json`) alongside registry keys. Invalid clients now show a clean error with available options.

---

## [0.4.1] - 2026-03-08

### Fixed
- **Legacy skill migration** — `gemcli skill install` now detects and migrates legacy `gemini-skill` installs to the new `gemini-web-skill` name, preventing stale skill files from persisting after the rename.

---

## [0.4.0] - 2026-03-08

### Changed
- **Skill renamed to `gemini-web-skill`** — the installable AI tool skill was renamed from `gemini-skill` to `gemini-web-skill` across all formats (Claude Code, Cursor, Windsurf, Codex, etc.) to avoid naming conflicts with the official Gemini CLI.

---

## [0.3.33] - 2026-03-03

### Fixed
- **Stale cookie detection during login** — `gemcli login` would falsely report "Authentication successful!" when `__Secure-1PSID` existed in the Chrome profile but was expired. Now validates cookies by checking for the SNlM0e session token after extraction. If missing, automatically clears stale cookies from Chrome via CDP and waits for the user to re-login — no more need for `gemcli login --force` when cookies expire.

---

## [0.3.32] - 2026-03-03

### Fixed
- **Token Factory profile copy fails when Chrome is running** — `shutil.copytree` crashed with `shutil.Error` when the source Chrome profile had runtime artifacts (Unix sockets, dangling symlinks) created by an active Chrome process. The profile copy now skips `SingletonSocket`, `SingletonCookie`, `RunningChromeVersion`, and `SingletonLock`. Also fixed `__version__` not matching `pyproject.toml` (was stuck at 0.3.30).

---

## [0.3.31] - 2026-03-03

### Fixed
- **BotGuard cryptographic body signing** — Google's Gemini API changed to require BotGuard cryptographically signed request bodies for all requests. The CLI and MCP server now route all chat requests through the Token Factory, which launches Chrome, types the real user prompt, and captures/relays the exact cryptographically signed body. This completely restores text generation and fixes the `0 candidates` error that affected Python-built request bodies. Note: File uploads are currently under separate investigation.

---

## [0.3.30] - 2026-03-03

### Fixed
- **Streaming file upload for large videos** — File uploads (100MB+ videos) no longer load the entire file into memory via `read_bytes()`. The upload now streams in 1MB chunks using an async generator, reducing RAM usage from file-size to ~1MB constant and preventing event loop blocking. Upload timeout scales dynamically with file size (base 60s + 2s/MB, minimum 120s) instead of the previous hardcoded 300s. Progress logging reports every ~10MB for visibility into long uploads. Explicit `Content-Length` header ensures compatibility with chunked streaming.

---

## [0.3.29] - 2026-03-01

### Fixed
- **Silent token recovery** — When `SNlM0e` tokens expire (causing "Are you signed in?" errors during image/video/music generation), the CLI now automatically recovers by launching headless Chrome in the background, extracting fresh cookies and tokens via CDP, and saving them — all without any user interaction. Previously, users had to manually run `gemcli login --force` to fix expired tokens.

---

## [0.3.28] - 2026-03-01

### Added
- **Image URL extraction in Chat** — The `chat` MCP tool and `gemcli chat` CLI commands now actively extract and return the direct URLs of freshly generated images from Gemini (e.g., when Gemini uses its internal Imagen 3 capabilities to modify or generate an image during a chat session).

---

## [0.3.27] - 2026-03-01

### Added
- **Force login flag** — Added a `--force` / `-f` flag to the `gemcli login` command. This completely clears all cookies and forces a fresh authentication flow. Useful when Google invalidates specific tokens (like `SNlM0e`) while leaving basic cookies intact, which previously tricked the CLI into closing the login window prematurely.

### Fixed
- **Invisible Chrome port conflicts** — The background Token Factory now runs its headless Chrome instances starting at port `9300+`. Previously, it used the same `9222+` range as the visible `gemcli login` Chrome, causing the CLI to connect to the invisible background process and hang on "Waiting for you to log in...".
- **BotGuard headless detection** — Added `--disable-blink-features=AutomationControlled` and a realistic macOS `User-Agent` to the headless Token Factory Chrome launch arguments to prevent BotGuard from serving a broken page state.

---

## [0.3.26] - 2026-03-01

### Fixed
- **Chrome profile locking when MCP server and CLI run concurrently (HIGH)** — the Token Factory's headless Chrome competed for Chrome's `SingletonLock` with `gemcli login` and `gemcli chat` CLI commands using the same profile directory. Now the Token Factory uses an isolated copy of the login profile (`<profile>_tf/`), eliminating all contention. The copy is reused across restarts and only refreshed when the source profile's cookies change (i.e. after re-login).
- **Stale Chrome processes not fully killed** — `_kill_stale_chrome` now waits up to 5 seconds for graceful exit and escalates to `SIGKILL` for any survivors. Previously used a fixed `time.sleep(2)` which was insufficient for Chrome renderer subprocesses.
- **Orphaned Chrome on SIGTERM** — `atexit` handlers do not fire when the OS delivers `SIGTERM` (Python uses the default handler which terminates immediately). Added `SIGTERM`/`SIGINT` signal handlers that call `shutdown()` before exit, ensuring Chrome cleanup when the MCP subprocess is killed by its parent process (e.g. Node.js `StdioClientTransport`).

---

## [0.3.25] - 2026-03-01

### Added
- **Interactive JSON config generation** — `gemcli setup add json` generates a customized json snippet for configuring the MCP server in any tool. Supports `uvx` and absolute paths, outer and inner dictionary schemas, printing with syntax highlights, and macOS clipboard support via `pbcopy`.

---

## [0.3.24] - 2026-03-01
### Fixed
- **TokenFactoryError returned as successful text (CRITICAL)** — all 6 MCP tools (`chat`, `image`, `video`, `music`, `research`, `gems`) caught `TokenFactoryError` and returned JSON error strings with `isError: false`. MCP clients treated these as valid data, causing silent failures. Now exceptions propagate through FastMCP which correctly sets `isError: true`.
- **Chrome profile locking from stale processes** — when an existing Chrome instance held the `SingletonLock` on the profile directory, the Token Factory would fail to launch a second instance. Now kills stale Chrome processes and removes `SingletonLock` before launching.
- **Orphaned Chrome processes on exit** — when the MCP server subprocess died, Chrome was never cleaned up. Added `atexit` handler to ensure `shutdown()` runs, and `shutdown()` now cleans up `SingletonLock` files.

### Removed
- `_token_factory_error_response()` helper — no longer needed since errors propagate naturally.

---

## [0.3.23] - 2026-02-26

### Added
- **Nano Banana 2 image generation** — default image model is now Nano Banana 2 (Gemini 3.1 Flash Image), which Google shipped server-side on Feb 26, bringing Pro-level quality (text rendering, world knowledge, subject consistency) at Flash speed. `gemcli image -m pro` uses Nano Banana Pro (Gemini 3 Pro Image) for Pro/Ultra subscribers.
- **Nano Banana 2 quota tracking** — new Feature 21 in `gemcli limits` tracks Nano Banana 2 usage (100/day). Nano Banana Pro quota (Feature 19, 20/day) tracked separately.
- **Gem knowledge file uploads** — attach uploaded files (images, PDFs, documents) as knowledge sources when creating or updating gems via the 2-step `ProcessFile` resumable upload endpoint.
- **Google Drive file attachment for Gems** — attach Google Drive files as knowledge sources to gems. Drive files are processed via the `ProcessFile` batch endpoint.
- **`drive_search` action** for the `gems` MCP tool — search Google Drive directly from the gems workflow.
- **Enhanced gem listing** — `gems list` now shows attached resources (files, Drive docs, notebooks), default tool, and full instructions.
- **Email displayed in profiles** — `gemcli login --check` and `gemcli profile list` now show the Google account email for each profile (extracted from `WIZ_global_data.oPEP7c`).

### Fixed
- **Gem create/update payload format** — corrected the 18-element array structure for gem RPC calls.
- **Gems browser cookie requirement** — Token Factory trigger added to gems MCP tool for BotGuard-gated operations.
- **`login --check` always reporting expired tokens** — `Network.getAllCookies` returns cookies from all domains (youtube.com, doubleclick.net, etc.); same-name cookies from different domains collided in the flat dict, causing Gemini to serve a page without `SNlM0e`. Now filters to only `google.com`-domain cookies before saving, matching the Token Factory's existing behavior.

---

## [0.3.21] - 2026-02-23

### Fixed
- **Image download uses `=s1536` suffix** — the previous `=s2048` suffix caused CDN upscaling artifacts that broke watermark plugin compatibility. Google caps at 1024x1024 regardless, but `=s1536` produces pixel-consistent results that match the plugin's 48px alpha map. Native resolution (512x512) also didn't match the alpha map calibration.

---

## [0.3.20] - 2026-02-23

### Fixed
- **Image generation failing ("No images generated")** — root cause diagnosed via Chrome DevTools MCP capture of the live Gemini web UI:
  1. Added `tool_id=14` (IMAGE_TOOL_ID) at `inner_req_list[49]` — the web UI sends this when "Create image" tool is selected
  2. **Switched default model from Pro to Flash** — the web UI uses Flash for image generation. Pro + tool_id=14 returns empty responses (0 candidates). Flash + BotGuard + tool_id=14 works perfectly.
- Image generation now requires Chrome for BotGuard (same as video/music) but no longer requires the Pro model.

### Changed
- **Image generation default model**: Pro → Flash. Matches the Gemini web UI behavior.

---

## [0.3.19] - 2026-02-23

### Fixed
- **Image generation failing headlessly ("No images generated")** — added `tool_id=14` (IMAGE_TOOL_ID) and `force_token_factory=True` to image generation requests. Without explicit tool activation at `inner_req_list[49]`, Gemini relied on prompt heuristics and returned empty responses, especially in headless/background environments. Same class of bug as the video fix in v0.3.18.

---

## [0.3.18] - 2026-02-23

### Added
- **`VIDEO_TOOL_ID` and `IMAGE_TOOL_ID` constants** — explicit tool activation IDs for `inner_req_list[49]`, matching the codes discovered in `GemDefaultTool` (video=11, image=14, music=21).

### Fixed
- **Video generation producing images instead of videos** — added `tool_id=11` (VIDEO_TOOL_ID) to video generation requests at `inner_req_list[49]`. Without explicit tool activation, Gemini relied on prompt heuristics and frequently routed to image generation instead of Veo 3.1. Music generation already had this correct with `tool_id=21`.

---

## [0.3.17] - 2026-02-23

### Added
- **NotebookLM notebook attachment for Gems** — attach NotebookLM notebooks as knowledge sources when creating or updating gems. Reverse-engineered the `NXpLKc` RPC for listing notebooks and the client-side protobuf token format (no server round-trip needed, unlike Drive/uploaded files).
- **`list_notebooks` action** for the `gems` MCP tool — returns all NotebookLM notebooks with IDs, titles, and source counts.
- **`--notebook` CLI option** for `gemcli gems create` — repeatable flag to attach NotebookLM notebooks by UUID.
- **Notebook resources in gem listing** — `gems list` (CLI/MCP) now shows attached notebooks with source type `"notebook"` and the notebook UUID.

### Fixed
- **Multi-knowledge-entry payload format** — all knowledge entries (files, Drive docs, notebooks) are now wrapped in a single inner array (`[[entry1, entry2, ...]]`) matching the browser's behavior. Previously each entry was wrapped separately, causing only the first entry to be saved when attaching multiple knowledge sources.

---

## [0.3.16] - 2026-02-22

### Changed
- Moved plugins directory from `~/.config/gemcli/plugins/` to `~/.gemini-web-mcp-cli/plugins/` for consistency with existing config layout.

---

## [0.3.15] - 2026-02-22

### Changed
- Re-release after git history cleanup. No functional changes from 0.3.14.

---

## [0.3.14] - 2026-02-22

### Added
- **Usage limits checking** — new `gemcli limits` CLI command and `limits` MCP tool. Reverse-engineered the `qpEbW` RPC to report per-feature usage quotas (video, music, images, prompts, research, etc.) with remaining count and rolling reset time. Requires Chrome for browser cookies.
- **Video quota detection** — `wait_for_completion()` now detects quota rejection messages ("Sorry, I can't generate more videos") and raises `VideoGenerationError` immediately instead of polling for 5 minutes until timeout. MCP returns `status: "quota_exceeded"` to AI agents.
- **LimitsService** (`services/limits.py`) — new service wrapping the `qpEbW` (USAGE_INFO) RPC with `Feature` enum, `FeatureLimit` model, and structured JSON output.
- **Optional plugin directory** (`~/.config/gemcli/plugins/`) — support for drop-in plugins for potential future extensibility.

---

## [0.3.13] - 2026-02-21

### Fixed
- **Sparse protobuf response parsing** — Google A/B tests a compressed JSON format where arrays with many null elements become `[{"field_num": value}]` dicts with 1-based protobuf field numbers. This caused `has_music: false` and `has_video: false` on affected accounts. Fixed `get_nested()` in `parser.py` to handle both formats transparently.

---

## [0.3.12] - 2026-02-21

### Fixed
- Token Factory `at=` access token handling — video and music generation failed because Chrome's live `SNlM0e` token wasn't being included in replayed requests
- Video/music polling 400 errors from token mismatch between Python cache and Chrome session
- Prompt truncation in Token Factory — uses dummy string for BotGuard capture, injects real prompt in Python
- Various CDP and login stability fixes

---

## [0.3.9] - 2026-02-20

### Added
- `gemcli hack claude -m pro` — model selection flag for hack claude sessions
- Model identity injection so Gemini can correctly identify which model it's running as

### Fixed
- Pro model context loss, system prompt refusal, and prompt format issues in hack claude

---

## [0.3.0] - 2026-02-20

### Added
- **File upload support** — upload images, PDFs, documents, audio to Gemini for conversation context (`gemcli chat -f <file>`, MCP `chat` tool `files` parameter)
- **`gemcli hack claude`** — launch Claude Code connected to Gemini models via local Anthropic-compatible API server

### Fixed
- CDP Chrome startup reliability (polling loop, IPv6 resolution)
- Login profile selection terminal input handling
- FastAPI/uvicorn dependency packaging

---

## [0.2.2] - 2026-02-19

### Added
- **Video generation (Veo 3.1)** — `gemcli video`, MCP `video` tool, polling-based async generation
- **CDP page fetch download** — browser-context `fetch()` for media downloads, bypassing partitioned cookie restrictions

### Fixed
- Media download 403 errors from missing partitioned cookies
- Frame merge now preserves music/video/image data across streaming frames

---

## [0.2.0] - 2026-02-18

### Added
- **Music generation (Lyria 3)** — `gemcli music`, MCP `music` tool, 16 style presets, audio/video formats
- **Persistent Chrome daemon** — `gemcli chrome start/stop/status` for background processes
- **BotGuard for tool-based generation** — music requires BotGuard even on Flash model

---

## [0.1.x] - 2026-02-16

### 0.1.0 — Initial Alpha
Full CLI (`gemcli`) and MCP server (`gemini-web-mcp`) for the Gemini web interface: chat, image generation, deep research, gems management, multi-profile support, skill system, diagnostics (`gemcli doctor`), and MCP client setup for 8+ AI tools.

### 0.1.1 — CI/CD + PyPI
GitHub Actions release workflow (test, build, publish). First PyPI release. Lint fixes.

### 0.1.2 — Dependency Fix
Moved `mcp[cli]` to core dependencies for `uv tool install` compatibility.

### 0.1.3 — Skill Path Fix
Fixed OpenClaw skill installation directory path.

---

[0.4.3]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.4.2...v0.4.3
[0.4.2]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.4.1...v0.4.2
[0.4.1]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.4.0...v0.4.1
[0.4.0]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.3.34...v0.4.0
[0.3.30]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.3.29...v0.3.30
[0.3.27]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.3.26...v0.3.27
[0.3.26]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.3.25...v0.3.26
[0.3.25]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.3.24...v0.3.25
[0.3.24]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.3.23...v0.3.24
[0.3.23]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.3.22...v0.3.23
[0.3.22]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.3.21...v0.3.22
[0.3.21]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.3.20...v0.3.21
[0.3.20]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.3.19...v0.3.20
[0.3.19]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.3.18...v0.3.19
[0.3.18]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.3.17...v0.3.18
[0.3.17]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.3.16...v0.3.17
[0.3.16]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.3.15...v0.3.16
[0.3.15]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.3.14...v0.3.15
[0.3.14]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.3.13...v0.3.14
