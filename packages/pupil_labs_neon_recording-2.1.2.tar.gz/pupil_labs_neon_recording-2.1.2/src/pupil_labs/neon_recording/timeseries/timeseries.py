from collections.abc import Iterator
from typing import (
    TYPE_CHECKING,
    Generic,
    Literal,
    SupportsIndex,
    TypeVar,
    overload,
)

import numpy as np
import numpy.typing as npt

from pupil_labs.neon_recording.constants import TIMESTAMP_FIELD_NAME
from pupil_labs.neon_recording.sample import match_ts
from pupil_labs.neon_recording.timeseries.array_record import (
    Array,
    RecordType,
    fields,
)
from pupil_labs.video import ArrayLike

if TYPE_CHECKING:
    from ..neon_recording import NeonRecording

ArrayType = TypeVar("ArrayType", bound=Array)


class TimeseriesProps:
    time = fields[np.int64](TIMESTAMP_FIELD_NAME)
    "The moment these data were recorded"

    def keys(self):
        return dir(self)

    def __len__(self):
        return len(self.keys())


T = TypeVar("T", bound="Timeseries")


class Timeseries(TimeseriesProps, Generic[ArrayType, RecordType]):
    """Base class for all Neon timeseries data."""

    name: str
    recording: "NeonRecording"
    _data: ArrayType

    def __init__(self, recording: "NeonRecording", data: ArrayType | None = None):
        self.recording = recording
        if data is None:
            data = self._load_data_from_recording(recording)
        self._data = data

    def _load_data_from_recording(self, recording: "NeonRecording") -> ArrayType:
        raise NotImplementedError(
            f"Loading data for {self.__class__.__name__} is not implemented."
        )

    @property
    def dtype(self):
        return self._data.dtype

    def keys(self):
        if not self._data.dtype:
            return ["0"]
        assert self._data.dtype.names is not None
        return list(self._data.dtype.names)

    def __len__(self):
        return len(self._data)

    @overload
    def __getitem__(self, key: SupportsIndex) -> RecordType: ...
    @overload
    def __getitem__(self: T, key: slice | list[str]) -> T: ...
    def __getitem__(
        self, key: SupportsIndex | slice | str | list[str]
    ) -> "Timeseries | RecordType":
        if isinstance(key, slice):
            return self.__class__(
                self.recording,
                self._data[key],  # type: ignore
            )
        else:
            return self._data[key]  # type: ignore

    @property
    def data(self):
        """Data as a numpy array"""
        return self._data

    @property
    def pd(self):
        """Data as a pandas DataFrame"""
        return self._data.pd

    def __repr__(self):
        data = self._data if hasattr(self, "_data") else "-"

        return (
            f"{self.__class__.__name__}"
            f"(name={self.name!r}, recording={self.recording!r}, data={data!r})"
        )

    def __iter__(self) -> Iterator[RecordType]:
        """Iterate over the records in the timeseries."""
        for i in range(len(self)):
            yield self[i]

    def sample(
        self: T,
        target_time: ArrayLike[int],
        method: Literal["nearest", "backward", "forward"] = "nearest",
        tolerance: int | None = None,
    ) -> T:
        indices = match_ts(target_time, self.time, method, tolerance)  # type: ignore

        if True in np.isnan(indices):
            raise ValueError(
                "Failed to find matching samples for some samples.",
                [t for t, i in zip(target_time, indices, strict=False) if np.isnan(i)],
            )

        return self.__class__(
            self.recording,
            self._data[indices],
        )


class InterpolatableTimeseries(Timeseries[ArrayType, RecordType]):
    def interpolate(self: T, target_time: npt.NDArray[np.int64]) -> T:
        target_time = np.array(target_time)
        interpolated_dtype = np.dtype([
            (k, self.data.dtype[k].type)
            for k in self.data.dtype.names
            if issubclass(self.data.dtype[k].type, (np.floating, np.integer))
        ])

        result = np.zeros(len(target_time), interpolated_dtype)
        result[TIMESTAMP_FIELD_NAME] = target_time
        for key in interpolated_dtype.names or []:
            if key == TIMESTAMP_FIELD_NAME:
                continue
            value = self.data[key].astype(np.float64)
            result[key] = np.interp(
                target_time,
                self.time,
                value,
                left=np.nan,
                right=np.nan,
            )
        return self.__class__(
            self.recording,
            data=result.view(self._data.__class__),
        )
