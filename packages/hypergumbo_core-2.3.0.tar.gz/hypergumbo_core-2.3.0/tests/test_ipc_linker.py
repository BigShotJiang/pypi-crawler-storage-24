# SPDX-License-Identifier: AGPL-3.0-or-later
"""Tests for IPC linker."""
from pathlib import Path

from hypergumbo_core.ir import AnalysisRun, Symbol, Span


class TestIpcPatternDetection:
    """Tests for IPC pattern detection."""

    def test_detect_electron_ipc_send(self) -> None:
        """Detects Electron ipcRenderer.send pattern."""
        from hypergumbo_core.linkers.ipc import detect_ipc_patterns

        source = b"""
function sendMessage() {
    ipcRenderer.send('user-login', { username: 'test' });
}
"""
        patterns = detect_ipc_patterns(source, "javascript")

        assert len(patterns) >= 1
        send_patterns = [p for p in patterns if p["type"] == "send"]
        assert len(send_patterns) >= 1
        assert send_patterns[0]["channel"] == "user-login"

    def test_detect_electron_ipc_on(self) -> None:
        """Detects Electron ipcMain.on pattern."""
        from hypergumbo_core.linkers.ipc import detect_ipc_patterns

        source = b"""
ipcMain.on('user-login', (event, data) => {
    console.log('User logged in:', data.username);
});
"""
        patterns = detect_ipc_patterns(source, "javascript")

        assert len(patterns) >= 1
        receive_patterns = [p for p in patterns if p["type"] == "receive"]
        assert len(receive_patterns) >= 1
        assert receive_patterns[0]["channel"] == "user-login"

    def test_detect_electron_ipc_invoke(self) -> None:
        """Detects Electron ipcRenderer.invoke pattern."""
        from hypergumbo_core.linkers.ipc import detect_ipc_patterns

        source = b"""
async function getData() {
    const result = await ipcRenderer.invoke('get-data', { id: 123 });
    return result;
}
"""
        patterns = detect_ipc_patterns(source, "javascript")

        send_patterns = [p for p in patterns if p["type"] == "send"]
        assert len(send_patterns) >= 1
        assert send_patterns[0]["channel"] == "get-data"

    def test_detect_electron_ipc_handle(self) -> None:
        """Detects Electron ipcMain.handle pattern."""
        from hypergumbo_core.linkers.ipc import detect_ipc_patterns

        source = b"""
ipcMain.handle('get-data', async (event, args) => {
    return await fetchData(args.id);
});
"""
        patterns = detect_ipc_patterns(source, "javascript")

        receive_patterns = [p for p in patterns if p["type"] == "receive"]
        assert len(receive_patterns) >= 1
        assert receive_patterns[0]["channel"] == "get-data"

    def test_detect_postmessage(self) -> None:
        """Detects window.postMessage pattern."""
        from hypergumbo_core.linkers.ipc import detect_ipc_patterns

        source = b"""
function notifyParent() {
    window.postMessage({ type: 'ready', data: 'loaded' }, '*');
}
"""
        patterns = detect_ipc_patterns(source, "javascript")

        send_patterns = [p for p in patterns if p["type"] == "send"]
        assert len(send_patterns) >= 1

    def test_detect_message_event_listener(self) -> None:
        """Detects addEventListener('message', ...) pattern."""
        from hypergumbo_core.linkers.ipc import detect_ipc_patterns

        source = b"""
window.addEventListener('message', (event) => {
    console.log('Received:', event.data);
});
"""
        patterns = detect_ipc_patterns(source, "javascript")

        receive_patterns = [p for p in patterns if p["type"] == "receive"]
        assert len(receive_patterns) >= 1

    def test_detect_worker_postmessage(self) -> None:
        """Detects Web Worker postMessage pattern."""
        from hypergumbo_core.linkers.ipc import detect_ipc_patterns

        source = b"""
const worker = new Worker('worker.js');
worker.postMessage({ cmd: 'start', data: input });
"""
        patterns = detect_ipc_patterns(source, "javascript")

        send_patterns = [p for p in patterns if p["type"] == "send"]
        assert len(send_patterns) >= 1

    def test_no_patterns_in_regular_code(self) -> None:
        """Returns empty for code without IPC patterns."""
        from hypergumbo_core.linkers.ipc import detect_ipc_patterns

        source = b"""
function add(a, b) {
    return a + b;
}
"""
        patterns = detect_ipc_patterns(source, "javascript")

        assert len(patterns) == 0

    def test_non_javascript_returns_empty(self) -> None:
        """Returns empty for non-JavaScript code."""
        from hypergumbo_core.linkers.ipc import detect_ipc_patterns

        source = b"""
def send_message():
    pass
"""
        patterns = detect_ipc_patterns(source, "python")

        assert len(patterns) == 0


class TestIpcLinker:
    """Tests for IPC linker edge creation."""

    def _make_js_symbol(
        self,
        name: str,
        kind: str = "function",
        path: str = "app.js",
        source: bytes = b"",
    ) -> Symbol:
        """Create a test JavaScript symbol."""
        run = AnalysisRun.create(pass_id="test", version="test")
        return Symbol(
            id=f"js:{path}:1-10:{name}:{kind}",
            name=name,
            kind=kind,
            language="javascript",
            path=path,
            span=Span(start_line=1, end_line=10, start_col=0, end_col=0),
            origin="javascript-ts-v1",
            origin_run_id=run.execution_id,
        )

    def test_links_ipc_send_receive(self, tmp_path: Path) -> None:
        """Links IPC send to receive on same channel."""
        from hypergumbo_core.linkers.ipc import link_ipc

        # Create renderer file with send
        renderer = tmp_path / "renderer.js"
        renderer.write_text("""
function sendLogin() {
    ipcRenderer.send('user-login', { user: 'test' });
}
""")

        # Create main file with receive
        main = tmp_path / "main.js"
        main.write_text("""
ipcMain.on('user-login', (event, data) => {
    handleLogin(data);
});
""")

        result = link_ipc(tmp_path)

        assert result.run is not None
        # Should have edges for the IPC communication
        send_edges = [e for e in result.edges if e.edge_type == "message_send"]
        receive_edges = [e for e in result.edges if e.edge_type == "message_receive"]
        # At minimum, verify the linker runs without error

    def test_links_invoke_handle_pair(self, tmp_path: Path) -> None:
        """Links ipcRenderer.invoke to ipcMain.handle."""
        from hypergumbo_core.linkers.ipc import link_ipc

        renderer = tmp_path / "renderer.js"
        renderer.write_text("""
async function fetchData() {
    return await ipcRenderer.invoke('fetch-data', { id: 1 });
}
""")

        main = tmp_path / "main.js"
        main.write_text("""
ipcMain.handle('fetch-data', async (event, args) => {
    return await db.query(args.id);
});
""")

        result = link_ipc(tmp_path)

        assert result.run is not None
        assert result.run.pass_id == "ipc-linker-v1"

    def test_no_js_files(self, tmp_path: Path) -> None:
        """Handles directory with no JavaScript files."""
        from hypergumbo_core.linkers.ipc import link_ipc

        (tmp_path / "app.py").write_text("print('hello')")

        result = link_ipc(tmp_path)

        assert result.run is not None
        assert len(result.edges) == 0

    def test_empty_directory(self, tmp_path: Path) -> None:
        """Handles empty directory."""
        from hypergumbo_core.linkers.ipc import link_ipc

        result = link_ipc(tmp_path)

        assert result.run is not None
        assert len(result.edges) == 0


class TestIpcChannelMatching:
    """Tests for IPC channel name matching."""

    def test_exact_channel_match(self, tmp_path: Path) -> None:
        """Matches exact channel names."""
        from hypergumbo_core.linkers.ipc import link_ipc

        (tmp_path / "send.js").write_text("""
ipcRenderer.send('my-channel', data);
""")
        (tmp_path / "receive.js").write_text("""
ipcMain.on('my-channel', handler);
""")

        result = link_ipc(tmp_path)

        assert result.run is not None
        # Should find matching channel
        channel_edges = [e for e in result.edges if "my-channel" in str(e.meta)]
        # Verify linker processes files

    def test_no_match_different_channels(self, tmp_path: Path) -> None:
        """Does not match different channel names."""
        from hypergumbo_core.linkers.ipc import link_ipc

        (tmp_path / "send.js").write_text("""
ipcRenderer.send('channel-a', data);
""")
        (tmp_path / "receive.js").write_text("""
ipcMain.on('channel-b', handler);
""")

        result = link_ipc(tmp_path)

        assert result.run is not None
        # Should not have channel link between different channels


class TestIpcLinkerEdgeCases:
    """Tests for IPC linker edge cases."""

    def test_file_read_error(self, tmp_path: Path) -> None:
        """Handles file read errors gracefully."""
        from hypergumbo_core.linkers.ipc import link_ipc

        js_file = tmp_path / "test.js"
        js_file.write_text("ipcRenderer.send('test', data);")

        # Make file unreadable
        original_read_bytes = Path.read_bytes

        def mock_read_bytes(self: Path) -> bytes:
            if self.name == "test.js":
                raise IOError("Mock read error")
            return original_read_bytes(self)

        from unittest.mock import patch
        with patch.object(Path, "read_bytes", mock_read_bytes):
            result = link_ipc(tmp_path)

        assert result.run is not None
        # Should not crash, just skip the file

    def test_multiple_patterns_in_file(self, tmp_path: Path) -> None:
        """Handles multiple IPC patterns in single file."""
        from hypergumbo_core.linkers.ipc import link_ipc

        (tmp_path / "multi.js").write_text("""
ipcRenderer.send('channel-1', data1);
ipcRenderer.send('channel-2', data2);
ipcRenderer.invoke('channel-3', data3);
""")

        result = link_ipc(tmp_path)

        assert result.run is not None

    def test_nested_quotes(self) -> None:
        """Handles nested quotes in channel detection."""
        from hypergumbo_core.linkers.ipc import detect_ipc_patterns

        source = b"""
ipcRenderer.send("channel-with-'quotes'", data);
"""
        patterns = detect_ipc_patterns(source, "javascript")

        # Should handle or skip gracefully
        assert isinstance(patterns, list)

    def test_template_literals(self) -> None:
        """Handles template literal channel names."""
        from hypergumbo_core.linkers.ipc import detect_ipc_patterns

        source = b"""
const channel = `user-${id}`;
ipcRenderer.send(channel, data);
"""
        patterns = detect_ipc_patterns(source, "javascript")

        # Dynamic channels can't be statically analyzed
        assert isinstance(patterns, list)


class TestIpcEdgeCreation:
    """Tests for IPC edge creation details."""

    def test_edge_has_channel_in_meta(self, tmp_path: Path) -> None:
        """Created edges include channel name in metadata."""
        from hypergumbo_core.linkers.ipc import link_ipc

        (tmp_path / "app.js").write_text("""
ipcRenderer.send('test-channel', data);
ipcMain.on('test-channel', handler);
""")

        result = link_ipc(tmp_path)

        assert result.run is not None
        # Edges should have channel metadata when created

    def test_edge_confidence(self, tmp_path: Path) -> None:
        """Edges have appropriate confidence levels."""
        from hypergumbo_core.linkers.ipc import link_ipc

        (tmp_path / "app.js").write_text("""
ipcRenderer.send('test-channel', data);
ipcMain.on('test-channel', handler);
""")

        result = link_ipc(tmp_path)

        for edge in result.edges:
            assert 0.0 <= edge.confidence <= 1.0


class TestIpcRunMetadata:
    """Tests for IPC linker run metadata."""

    def test_run_has_pass_id(self, tmp_path: Path) -> None:
        """Run has correct pass ID."""
        from hypergumbo_core.linkers.ipc import link_ipc

        result = link_ipc(tmp_path)

        assert result.run is not None
        assert result.run.pass_id == "ipc-linker-v1"

    def test_run_tracks_files(self, tmp_path: Path) -> None:
        """Run tracks files analyzed."""
        from hypergumbo_core.linkers.ipc import link_ipc

        (tmp_path / "a.js").write_text("const x = 1;")
        (tmp_path / "b.js").write_text("const y = 2;")

        result = link_ipc(tmp_path)

        assert result.run is not None
        assert result.run.files_analyzed >= 0


class TestIpcTypeScriptSupport:
    """Tests for TypeScript IPC detection."""

    def test_detect_typescript_ipc(self, tmp_path: Path) -> None:
        """Detects IPC patterns in TypeScript files."""
        from hypergumbo_core.linkers.ipc import link_ipc

        (tmp_path / "renderer.ts").write_text("""
async function sendData(): Promise<void> {
    await ipcRenderer.invoke('send-data', { value: 42 });
}
""")

        result = link_ipc(tmp_path)

        assert result.run is not None

    def test_detect_tsx_ipc(self, tmp_path: Path) -> None:
        """Detects IPC patterns in TSX files."""
        from hypergumbo_core.linkers.ipc import link_ipc

        (tmp_path / "component.tsx").write_text("""
const Component = () => {
    const handleClick = () => {
        ipcRenderer.send('button-clicked', {});
    };
    return <button onClick={handleClick}>Click</button>;
};
""")

        result = link_ipc(tmp_path)

        assert result.run is not None


class TestIpcEmptyChannelHandling:
    """Tests for handling empty channel patterns (postMessage)."""

    def test_postmessage_sender_skipped(self, tmp_path: Path) -> None:
        """PostMessage senders with empty channel are skipped in linking."""
        from hypergumbo_core.linkers.ipc import link_ipc

        # Only postMessage (no named channel)
        (tmp_path / "sender.js").write_text("""
window.postMessage({ type: 'ready' }, '*');
""")
        (tmp_path / "receiver.js").write_text("""
window.addEventListener('message', handler);
""")

        result = link_ipc(tmp_path)

        assert result.run is not None
        # Empty channels should not create edges
        assert len(result.edges) == 0

    def test_mixed_empty_and_named_channels(self, tmp_path: Path) -> None:
        """Handles mix of empty and named channel patterns."""
        from hypergumbo_core.linkers.ipc import link_ipc

        (tmp_path / "app.js").write_text("""
// Named channel - should create edges
ipcRenderer.send('named-channel', data);
ipcMain.on('named-channel', handler);

// Empty channel (postMessage) - should not create edges
window.postMessage(data, '*');
window.addEventListener('message', handler);
""")

        result = link_ipc(tmp_path)

        assert result.run is not None
        # Should only have edges for named channel
        for edge in result.edges:
            assert edge.meta.get("channel") == "named-channel"


class TestIpcLinkerRequirements:
    """Tests for IPC linker registry requirements."""

    def test_count_js_ts_files(self, tmp_path: Path) -> None:
        """Counts JavaScript/TypeScript files in the repository."""
        from hypergumbo_core.linkers.ipc import _count_js_ts_files
        from hypergumbo_core.linkers.registry import LinkerContext

        (tmp_path / "app.js").write_text("const x = 1;")
        (tmp_path / "component.tsx").write_text("export default () => <div/>;")
        (tmp_path / "util.py").write_text("print('hello')")

        ctx = LinkerContext(repo_root=tmp_path)
        count = _count_js_ts_files(ctx)

        assert count == 2

    def test_count_electron_patterns_in_symbols(self, tmp_path: Path) -> None:
        """Counts Electron IPC patterns in symbols."""
        from hypergumbo_core.ir import Span, Symbol
        from hypergumbo_core.linkers.ipc import _count_electron_patterns_in_code
        from hypergumbo_core.linkers.registry import LinkerContext

        sym_ipc = Symbol(
            id="js:main.js:1-10:ipcHandler:function",
            name="ipcHandler",
            kind="function",
            language="javascript",
            path="main.js",
            span=Span(1, 10, 0, 0),
            origin="test",
            origin_run_id="test",
        )
        sym_electron = Symbol(
            id="js:preload.js:1-10:electronBridge:variable",
            name="electronBridge",
            kind="variable",
            language="typescript",
            path="preload.js",
            span=Span(1, 10, 0, 0),
            origin="test",
            origin_run_id="test",
        )
        sym_other = Symbol(
            id="js:utils.js:1-10:formatDate:function",
            name="formatDate",
            kind="function",
            language="javascript",
            path="utils.js",
            span=Span(1, 10, 0, 0),
            origin="test",
            origin_run_id="test",
        )

        ctx = LinkerContext(
            repo_root=tmp_path,
            symbols=[sym_ipc, sym_electron, sym_other],
        )
        count = _count_electron_patterns_in_code(ctx)

        assert count == 2  # ipcHandler and electronBridge


class TestIpcLinkerRegistration:
    """Tests for IPC linker registry integration."""

    def test_linker_is_registered(self) -> None:
        """IPC linker is registered with the registry."""
        import hypergumbo_core.linkers.ipc
        from hypergumbo_core.linkers.registry import get_linker

        linker = get_linker("ipc")
        assert linker is not None
        assert linker.name == "ipc"
        assert linker.priority == 40

    def test_ipc_linker_returns_result(self, tmp_path: Path) -> None:
        """ipc_linker function returns LinkerResult."""
        from hypergumbo_core.linkers.ipc import ipc_linker
        from hypergumbo_core.linkers.registry import LinkerContext

        ctx = LinkerContext(repo_root=tmp_path)
        result = ipc_linker(ctx)

        assert result is not None
        assert hasattr(result, "symbols")
        assert hasattr(result, "edges")


class TestVariableChannelPatterns:
    """Tests for variable-based channel detection."""

    def test_detect_variable_send_channel(self) -> None:
        """Detects ipcRenderer.send with variable channel."""
        from hypergumbo_core.linkers.ipc import detect_ipc_patterns

        source = b"""
const CHANNEL = 'open-file';
ipcRenderer.send(CHANNEL, { path: '/tmp/file.txt' });
"""
        patterns = detect_ipc_patterns(source, "javascript")

        assert len(patterns) == 1
        assert patterns[0]["channel"] == "CHANNEL"
        assert patterns[0]["channel_type"] == "variable"

    def test_detect_variable_receive_channel(self) -> None:
        """Detects ipcMain.on with variable channel."""
        from hypergumbo_core.linkers.ipc import detect_ipc_patterns

        source = b"""
const OPEN_FILE_CHANNEL = 'open-file';
ipcMain.on(OPEN_FILE_CHANNEL, (event, data) => {
    console.log('Opening file:', data.path);
});
"""
        patterns = detect_ipc_patterns(source, "javascript")

        assert len(patterns) == 1
        assert patterns[0]["channel"] == "OPEN_FILE_CHANNEL"
        assert patterns[0]["channel_type"] == "variable"

    def test_detect_attribute_access_channel(self) -> None:
        """Detects channel with attribute access like config.channel."""
        from hypergumbo_core.linkers.ipc import detect_ipc_patterns

        source = b"""
ipcRenderer.invoke(config.ipcChannel, { data: 'test' });
"""
        patterns = detect_ipc_patterns(source, "javascript")

        assert len(patterns) == 1
        assert patterns[0]["channel"] == "config.ipcChannel"
        assert patterns[0]["channel_type"] == "variable"

    def test_literal_channel_has_literal_type(self) -> None:
        """Verifies literal channels have channel_type='literal'."""
        from hypergumbo_core.linkers.ipc import detect_ipc_patterns

        source = b"""
ipcRenderer.send('user-login', { user: 'test' });
"""
        patterns = detect_ipc_patterns(source, "javascript")

        assert len(patterns) == 1
        assert patterns[0]["channel"] == "user-login"
        assert patterns[0]["channel_type"] == "literal"

    def test_variable_channel_linking(self, tmp_path: Path) -> None:
        """Links variable channels when using same variable name."""
        from hypergumbo_core.linkers.ipc import link_ipc

        renderer = tmp_path / "renderer.js"
        renderer.write_text("""
const OPEN_CHANNEL = 'open-file';
ipcRenderer.send(OPEN_CHANNEL, { path: '/tmp/test.txt' });
""")

        main = tmp_path / "main.js"
        main.write_text("""
const OPEN_CHANNEL = 'open-file';
ipcMain.on(OPEN_CHANNEL, (event, data) => {
    console.log('Opening:', data.path);
});
""")

        result = link_ipc(tmp_path)

        assert len(result.edges) >= 1
        # Find edges between variable-matched patterns
        var_edges = [e for e in result.edges if e.evidence_type == "variable_match"]
        assert len(var_edges) >= 1
        assert var_edges[0].confidence == 0.65  # Lower confidence for variable match
        assert var_edges[0].meta.get("channel_type") == "variable"

    def test_symbol_has_channel_type_metadata(self, tmp_path: Path) -> None:
        """Symbols include channel_type in metadata."""
        from hypergumbo_core.linkers.ipc import link_ipc

        js_file = tmp_path / "test.js"
        js_file.write_text("""
ipcRenderer.send(CHANNEL_VAR, { data: 'test' });
ipcMain.on(CHANNEL_VAR, handler);
""")

        result = link_ipc(tmp_path)

        # Should have both sender and receiver symbols
        assert len(result.symbols) >= 1
        for sym in result.symbols:
            assert "channel_type" in sym.meta
            assert sym.meta["channel_type"] == "variable"

    def test_mixed_literal_and_variable_no_match(self, tmp_path: Path) -> None:
        """Literal channel doesn't match different variable name."""
        from hypergumbo_core.linkers.ipc import link_ipc

        renderer = tmp_path / "renderer.js"
        renderer.write_text("""
ipcRenderer.send('open-file', { path: '/tmp/test.txt' });
""")

        main = tmp_path / "main.js"
        main.write_text("""
const CHANNEL = 'open-file';  // Same value, different identifier
ipcMain.on(CHANNEL, handler);
""")

        result = link_ipc(tmp_path)

        # No edges: literal 'open-file' != variable 'CHANNEL'
        assert len(result.edges) == 0


class TestNewElectronPatterns:
    """Tests for additional Electron IPC patterns (sendSync, handleOnce, webContents, renderer receive)."""

    def test_detect_sendsync(self) -> None:
        """Detects ipcRenderer.sendSync pattern."""
        from hypergumbo_core.linkers.ipc import detect_ipc_patterns

        source = b"""
const result = ipcRenderer.sendSync('get-config', { key: 'theme' });
"""
        patterns = detect_ipc_patterns(source, "javascript")
        send_patterns = [p for p in patterns if p["type"] == "send"]
        assert len(send_patterns) == 1
        assert send_patterns[0]["channel"] == "get-config"
        assert send_patterns[0]["method"] == "sendSync"

    def test_detect_handle_once(self) -> None:
        """Detects ipcMain.handleOnce pattern."""
        from hypergumbo_core.linkers.ipc import detect_ipc_patterns

        source = b"""
ipcMain.handleOnce('init-config', async () => {
    return await loadConfig();
});
"""
        patterns = detect_ipc_patterns(source, "javascript")
        receive_patterns = [p for p in patterns if p["type"] == "receive"]
        assert len(receive_patterns) == 1
        assert receive_patterns[0]["channel"] == "init-config"
        assert receive_patterns[0]["method"] == "handleOnce"

    def test_detect_webcontents_send(self) -> None:
        """Detects webContents.send pattern (main-to-renderer push)."""
        from hypergumbo_core.linkers.ipc import detect_ipc_patterns

        source = b"""
mainWindow.webContents.send('update-available', { version: '2.0' });
"""
        patterns = detect_ipc_patterns(source, "javascript")
        send_patterns = [p for p in patterns if p["type"] == "send"]
        assert len(send_patterns) == 1
        assert send_patterns[0]["channel"] == "update-available"
        assert send_patterns[0]["method"] == "webcontents_send"

    def test_detect_event_sender_send(self) -> None:
        """Detects event.sender.send pattern (reply in ipcMain handler)."""
        from hypergumbo_core.linkers.ipc import detect_ipc_patterns

        source = b"""
ipcMain.on('request-data', (event) => {
    event.sender.send('response-data', { result: 42 });
});
"""
        patterns = detect_ipc_patterns(source, "javascript")
        send_patterns = [p for p in patterns if p["type"] == "send"]
        # Should detect both: ipcRenderer-style won't match here, but sender.send should
        sender_sends = [p for p in send_patterns if p["method"] == "webcontents_send"]
        assert len(sender_sends) == 1
        assert sender_sends[0]["channel"] == "response-data"

    def test_detect_ipcrenderer_on(self) -> None:
        """Detects ipcRenderer.on pattern (renderer-side receive)."""
        from hypergumbo_core.linkers.ipc import detect_ipc_patterns

        source = b"""
ipcRenderer.on('update-available', (event, data) => {
    showNotification(data.version);
});
"""
        patterns = detect_ipc_patterns(source, "javascript")
        receive_patterns = [p for p in patterns if p["type"] == "receive"]
        assert len(receive_patterns) == 1
        assert receive_patterns[0]["channel"] == "update-available"

    def test_detect_ipcrenderer_once(self) -> None:
        """Detects ipcRenderer.once pattern (one-time renderer-side receive)."""
        from hypergumbo_core.linkers.ipc import detect_ipc_patterns

        source = b"""
ipcRenderer.once('init-complete', () => {
    hideLoadingScreen();
});
"""
        patterns = detect_ipc_patterns(source, "javascript")
        receive_patterns = [p for p in patterns if p["type"] == "receive"]
        assert len(receive_patterns) == 1
        assert receive_patterns[0]["channel"] == "init-complete"

    def test_sendsync_links_to_handler(self, tmp_path: Path) -> None:
        """sendSync links to ipcMain.on handler on same channel."""
        from hypergumbo_core.linkers.ipc import link_ipc

        renderer = tmp_path / "renderer.js"
        renderer.write_text("""
const config = ipcRenderer.sendSync('get-config');
""")
        main = tmp_path / "main.js"
        main.write_text("""
ipcMain.on('get-config', (event) => {
    event.returnValue = getConfig();
});
""")
        result = link_ipc(tmp_path)
        assert len(result.edges) >= 1

    def test_webcontents_links_to_renderer_on(self, tmp_path: Path) -> None:
        """webContents.send links to ipcRenderer.on on same channel."""
        from hypergumbo_core.linkers.ipc import link_ipc

        main = tmp_path / "main.ts"
        main.write_text("""
win.webContents.send('theme-changed', { theme: 'dark' });
""")
        renderer = tmp_path / "renderer.ts"
        renderer.write_text("""
ipcRenderer.on('theme-changed', (_event, data) => {
    applyTheme(data.theme);
});
""")
        result = link_ipc(tmp_path)
        # Should have edges linking main push to renderer receive
        assert len(result.edges) >= 1

    def test_webcontents_send_with_variable(self) -> None:
        """webContents.send with variable channel name."""
        from hypergumbo_core.linkers.ipc import detect_ipc_patterns

        source = b"""
mainWindow.webContents.send(CHANNEL_NAME, payload);
"""
        patterns = detect_ipc_patterns(source, "javascript")
        wc_sends = [p for p in patterns if p.get("method") == "webcontents_send"]
        assert len(wc_sends) == 1
        assert wc_sends[0]["channel_type"] == "variable"


class TestContextBridgeDetection:
    """Tests for contextBridge.exposeInMainWorld wrapper resolution.

    Electron's contextBridge.exposeInMainWorld() creates a safe bridge between
    the preload script and the renderer process. The preload script maps method
    names to IPC channels:

        contextBridge.exposeInMainWorld('api', {
            openFile: (...args) => ipcRenderer.invoke('open-file', ...args),
        });

    Then renderer code calls window.api.openFile(). This test class verifies
    that the linker detects the wrapper map and creates bridge_invokes edges.
    """

    def test_detect_context_bridge_wrapper(self) -> None:
        """Detects contextBridge.exposeInMainWorld wrapper definitions."""
        from hypergumbo_core.linkers.ipc import detect_context_bridge_wrappers

        source = b"""
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
    openFile: (...args) => ipcRenderer.invoke('open-file', ...args),
    saveFile: (data) => ipcRenderer.send('save-file', data),
});
"""
        wrappers = detect_context_bridge_wrappers(source)

        assert len(wrappers) == 1
        ns, methods = wrappers[0]
        assert ns == "api"
        assert methods["openFile"] == ("open-file", "invoke")
        assert methods["saveFile"] == ("save-file", "send")

    def test_detect_multiple_namespaces(self) -> None:
        """Detects multiple exposeInMainWorld calls."""
        from hypergumbo_core.linkers.ipc import detect_context_bridge_wrappers

        source = b"""
contextBridge.exposeInMainWorld('api', {
    getData: () => ipcRenderer.invoke('get-data'),
});
contextBridge.exposeInMainWorld('store', {
    saveItem: (item) => ipcRenderer.send('store-save', item),
});
"""
        wrappers = detect_context_bridge_wrappers(source)

        assert len(wrappers) == 2
        ns_names = {w[0] for w in wrappers}
        assert ns_names == {"api", "store"}

    def test_detect_sendsync_in_bridge(self) -> None:
        """Detects ipcRenderer.sendSync in bridge wrappers."""
        from hypergumbo_core.linkers.ipc import detect_context_bridge_wrappers

        source = b"""
contextBridge.exposeInMainWorld('electron', {
    getConfig: () => ipcRenderer.sendSync('get-config'),
});
"""
        wrappers = detect_context_bridge_wrappers(source)

        assert len(wrappers) == 1
        ns, methods = wrappers[0]
        assert methods["getConfig"] == ("get-config", "sendSync")

    def test_no_bridge_in_regular_code(self) -> None:
        """Returns empty for code without contextBridge patterns."""
        from hypergumbo_core.linkers.ipc import detect_context_bridge_wrappers

        source = b"""
const api = {
    openFile: (path) => fetch('/api/open', { body: path }),
};
"""
        wrappers = detect_context_bridge_wrappers(source)
        assert len(wrappers) == 0

    def test_bridge_with_arrow_and_regular_functions(self) -> None:
        """Detects both arrow functions and regular function shorthand."""
        from hypergumbo_core.linkers.ipc import detect_context_bridge_wrappers

        source = b"""
contextBridge.exposeInMainWorld('myApi', {
    method1: (...args) => ipcRenderer.invoke('chan-1', ...args),
    method2(...args) { return ipcRenderer.invoke('chan-2', ...args) },
});
"""
        wrappers = detect_context_bridge_wrappers(source)

        assert len(wrappers) == 1
        _, methods = wrappers[0]
        assert methods["method1"] == ("chan-1", "invoke")
        assert methods["method2"] == ("chan-2", "invoke")

    def test_bridge_linking_creates_edges(self, tmp_path: Path) -> None:
        """contextBridge wrappers create bridge_invokes edges in link_ipc."""
        from hypergumbo_core.linkers.ipc import link_ipc

        # Preload file with bridge definition
        preload = tmp_path / "preload.js"
        preload.write_text("""
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('api', {
    openFile: (...args) => ipcRenderer.invoke('open-file', ...args),
});
""")

        # Renderer file that calls the bridge method
        renderer = tmp_path / "renderer.js"
        renderer.write_text("""
window.api.openFile('/path/to/file');
""")

        # Main process handler
        main = tmp_path / "main.js"
        main.write_text("""
ipcMain.handle('open-file', async (event, path) => {
    return fs.readFile(path);
});
""")

        result = link_ipc(tmp_path)

        # Should have bridge_invokes edge from renderer call to preload bridge
        bridge_edges = [e for e in result.edges if e.edge_type == "bridge_invokes"]
        assert len(bridge_edges) >= 1

        # The bridge edge should reference the open-file channel
        bridge_edge = bridge_edges[0]
        assert bridge_edge.meta.get("channel") == "open-file"
        assert bridge_edge.meta.get("method") == "openFile"
        assert bridge_edge.meta.get("namespace") == "api"

    def test_bridge_linking_with_multiple_methods(self, tmp_path: Path) -> None:
        """Multiple bridge methods create separate edges."""
        from hypergumbo_core.linkers.ipc import link_ipc

        preload = tmp_path / "preload.ts"
        preload.write_text("""
contextBridge.exposeInMainWorld('api', {
    openFile: (...args) => ipcRenderer.invoke('open-file', ...args),
    saveFile: (data) => ipcRenderer.send('save-file', data),
    getConfig: () => ipcRenderer.sendSync('get-config'),
});
""")
        renderer = tmp_path / "renderer.ts"
        renderer.write_text("""
window.api.openFile('/path');
window.api.saveFile(data);
window.api.getConfig();
""")

        result = link_ipc(tmp_path)

        bridge_edges = [e for e in result.edges if e.edge_type == "bridge_invokes"]
        channels = {e.meta.get("channel") for e in bridge_edges}
        assert "open-file" in channels
        assert "save-file" in channels
        assert "get-config" in channels

    def test_bridge_call_creates_symbol(self, tmp_path: Path) -> None:
        """Bridge call sites create synthetic ipc_bridge_caller symbols."""
        from hypergumbo_core.linkers.ipc import link_ipc

        preload = tmp_path / "preload.js"
        preload.write_text("""
contextBridge.exposeInMainWorld('api', {
    getData: () => ipcRenderer.invoke('get-data'),
});
""")
        renderer = tmp_path / "renderer.js"
        renderer.write_text("""
const data = await window.api.getData();
""")

        result = link_ipc(tmp_path)

        bridge_syms = [s for s in result.symbols if s.kind == "ipc_bridge_caller"]
        assert len(bridge_syms) >= 1
        assert bridge_syms[0].meta.get("namespace") == "api"
        assert bridge_syms[0].meta.get("bridge_method") == "getData"

    def test_bridge_no_call_site_no_edge(self, tmp_path: Path) -> None:
        """No bridge_invokes edge if no renderer calls the bridge method."""
        from hypergumbo_core.linkers.ipc import link_ipc

        preload = tmp_path / "preload.js"
        preload.write_text("""
contextBridge.exposeInMainWorld('api', {
    openFile: (...args) => ipcRenderer.invoke('open-file', ...args),
});
""")
        # Renderer file that doesn't call window.api.anything
        renderer = tmp_path / "renderer.js"
        renderer.write_text("""
console.log('no bridge calls here');
""")

        result = link_ipc(tmp_path)

        bridge_edges = [e for e in result.edges if e.edge_type == "bridge_invokes"]
        assert len(bridge_edges) == 0

    def test_bridge_unknown_method_no_edge(self, tmp_path: Path) -> None:
        """window.api.unknownMethod() does not create edge if not in bridge map."""
        from hypergumbo_core.linkers.ipc import link_ipc

        preload = tmp_path / "preload.js"
        preload.write_text("""
contextBridge.exposeInMainWorld('api', {
    openFile: (...args) => ipcRenderer.invoke('open-file', ...args),
});
""")
        renderer = tmp_path / "renderer.js"
        renderer.write_text("""
window.api.unknownMethod();
""")

        result = link_ipc(tmp_path)

        bridge_edges = [e for e in result.edges if e.edge_type == "bridge_invokes"]
        assert len(bridge_edges) == 0

    def test_bridge_different_namespace_no_match(self, tmp_path: Path) -> None:
        """window.other.method() doesn't match window.api namespace."""
        from hypergumbo_core.linkers.ipc import link_ipc

        preload = tmp_path / "preload.js"
        preload.write_text("""
contextBridge.exposeInMainWorld('api', {
    openFile: (...args) => ipcRenderer.invoke('open-file', ...args),
});
""")
        renderer = tmp_path / "renderer.js"
        renderer.write_text("""
window.other.openFile('/path');
""")

        result = link_ipc(tmp_path)

        bridge_edges = [e for e in result.edges if e.edge_type == "bridge_invokes"]
        assert len(bridge_edges) == 0

    def test_bridge_dedup_same_call_same_file(self, tmp_path: Path) -> None:
        """Duplicate window.api.method() calls in same file produce one edge."""
        from hypergumbo_core.linkers.ipc import link_ipc

        preload = tmp_path / "preload.js"
        preload.write_text("""
contextBridge.exposeInMainWorld('api', {
    getData: () => ipcRenderer.invoke('get-data'),
});
""")
        renderer = tmp_path / "renderer.js"
        renderer.write_text("""
window.api.getData();
window.api.getData();
""")

        result = link_ipc(tmp_path)

        bridge_edges = [e for e in result.edges if e.edge_type == "bridge_invokes"]
        # Only one edge per (file, namespace, method) tuple
        assert len(bridge_edges) == 1

    def test_bridge_call_links_to_ipc_send_symbol(self, tmp_path: Path) -> None:
        """bridge_invokes edge dst is the ipc_send symbol for the channel."""
        from hypergumbo_core.linkers.ipc import link_ipc

        preload = tmp_path / "preload.js"
        preload.write_text("""
contextBridge.exposeInMainWorld('api', {
    openFile: (...args) => ipcRenderer.invoke('open-file', ...args),
});
""")
        renderer = tmp_path / "renderer.js"
        renderer.write_text("""
window.api.openFile('/path');
""")

        result = link_ipc(tmp_path)

        bridge_edges = [e for e in result.edges if e.edge_type == "bridge_invokes"]
        assert len(bridge_edges) == 1

        # The dst should be the ipc_send symbol created for the invoke in preload
        dst_id = bridge_edges[0].dst
        dst_sym = next((s for s in result.symbols if s.id == dst_id), None)
        assert dst_sym is not None
        assert dst_sym.kind == "ipc_send"

    def test_bridge_confidence(self, tmp_path: Path) -> None:
        """bridge_invokes edges have 0.80 confidence."""
        from hypergumbo_core.linkers.ipc import link_ipc

        preload = tmp_path / "preload.js"
        preload.write_text("""
contextBridge.exposeInMainWorld('api', {
    getData: () => ipcRenderer.invoke('get-data'),
});
""")
        renderer = tmp_path / "renderer.js"
        renderer.write_text("""
window.api.getData();
""")

        result = link_ipc(tmp_path)

        bridge_edges = [e for e in result.edges if e.edge_type == "bridge_invokes"]
        assert len(bridge_edges) == 1
        assert bridge_edges[0].confidence == 0.80

    def test_bridge_works_through_registry(self, tmp_path: Path) -> None:
        """contextBridge detection works via the linker registry."""
        from hypergumbo_core.linkers.ipc import ipc_linker
        from hypergumbo_core.linkers.registry import LinkerContext

        preload = tmp_path / "preload.js"
        preload.write_text("""
contextBridge.exposeInMainWorld('api', {
    getData: () => ipcRenderer.invoke('get-data'),
});
""")
        renderer = tmp_path / "renderer.js"
        renderer.write_text("""
window.api.getData();
""")

        ctx = LinkerContext(repo_root=tmp_path)
        result = ipc_linker(ctx)

        bridge_edges = [e for e in result.edges if e.edge_type == "bridge_invokes"]
        assert len(bridge_edges) >= 1

    def test_bridge_multiline_object(self) -> None:
        """Detects bridge wrappers spanning multiple lines."""
        from hypergumbo_core.linkers.ipc import detect_context_bridge_wrappers

        source = b"""
contextBridge.exposeInMainWorld(
    'electronAPI',
    {
        setTitle: (title) => ipcRenderer.send('set-title', title),
        getVersion: () => ipcRenderer.invoke('get-version'),
    }
);
"""
        wrappers = detect_context_bridge_wrappers(source)

        assert len(wrappers) == 1
        ns, methods = wrappers[0]
        assert ns == "electronAPI"
        assert methods["setTitle"] == ("set-title", "send")
        assert methods["getVersion"] == ("get-version", "invoke")

    def test_bridge_double_quoted_namespace(self) -> None:
        """Detects bridge with double-quoted namespace."""
        from hypergumbo_core.linkers.ipc import detect_context_bridge_wrappers

        source = b'''
contextBridge.exposeInMainWorld("myApi", {
    doStuff: () => ipcRenderer.invoke("do-stuff"),
});
'''
        wrappers = detect_context_bridge_wrappers(source)

        assert len(wrappers) == 1
        assert wrappers[0][0] == "myApi"
        assert wrappers[0][1]["doStuff"] == ("do-stuff", "invoke")
