# SPDX-License-Identifier: AGPL-3.0-or-later
"""Tests for repo profile detection."""
import json
from pathlib import Path

from hypergumbo_core.cli import run_behavior_map


def test_detects_python_language(tmp_path: Path) -> None:
    """Should detect Python files and count them."""
    # Create some Python files
    (tmp_path / "app.py").write_text("def main():\n    pass\n")
    (tmp_path / "utils.py").write_text("def helper():\n    return 42\n")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())

    assert "profile" in data
    assert "languages" in data["profile"]
    assert "python" in data["profile"]["languages"]
    assert data["profile"]["languages"]["python"]["files"] == 2
    # LOC is deferred to sketch generation (not computed during profile detection)
    assert data["profile"]["languages"]["python"]["loc"] == 0


def test_detects_javascript_language(tmp_path: Path) -> None:
    """Should detect JavaScript files."""
    (tmp_path / "app.js").write_text("function main() {\n  console.log('hi');\n}\n")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())

    assert "javascript" in data["profile"]["languages"]
    assert data["profile"]["languages"]["javascript"]["files"] == 1


def test_detects_typescript_language(tmp_path: Path) -> None:
    """Should detect TypeScript files."""
    (tmp_path / "app.ts").write_text("const x: number = 42;\n")
    (tmp_path / "types.d.ts").write_text("declare const y: string;\n")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())

    assert "typescript" in data["profile"]["languages"]
    assert data["profile"]["languages"]["typescript"]["files"] == 2


def test_detects_html_language(tmp_path: Path) -> None:
    """Should detect HTML files."""
    (tmp_path / "index.html").write_text("<html>\n<body>Hello</body>\n</html>\n")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())

    assert "html" in data["profile"]["languages"]
    assert data["profile"]["languages"]["html"]["files"] == 1


def test_detects_multiple_languages(tmp_path: Path) -> None:
    """Should detect all languages in a mixed repo."""
    (tmp_path / "app.py").write_text("print('hi')\n")
    (tmp_path / "index.js").write_text("console.log('hi');\n")
    (tmp_path / "page.html").write_text("<html></html>\n")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())

    languages = data["profile"]["languages"]
    assert "python" in languages
    assert "javascript" in languages
    assert "html" in languages


def test_excludes_node_modules_from_profile(tmp_path: Path) -> None:
    """Should not count files in excluded directories."""
    (tmp_path / "app.py").write_text("print('hi')\n")

    # Create lots of JS in node_modules (should be ignored)
    node_modules = tmp_path / "node_modules" / "some-package"
    node_modules.mkdir(parents=True)
    (node_modules / "index.js").write_text("module.exports = {};\n")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())

    # Should only have Python, not JavaScript
    assert "python" in data["profile"]["languages"]
    assert "javascript" not in data["profile"]["languages"]


def test_detects_fastapi_framework(tmp_path: Path) -> None:
    """Should detect FastAPI framework from pyproject.toml."""
    (tmp_path / "app.py").write_text("from fastapi import FastAPI\napp = FastAPI()\n")
    (tmp_path / "pyproject.toml").write_text(
        '[project]\nname = "myapp"\ndependencies = ["fastapi", "uvicorn"]\n'
    )

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())

    assert "frameworks" in data["profile"]
    assert "fastapi" in data["profile"]["frameworks"]


def test_detects_flask_framework(tmp_path: Path) -> None:
    """Should detect Flask framework from requirements.txt."""
    (tmp_path / "app.py").write_text("from flask import Flask\n")
    (tmp_path / "requirements.txt").write_text("flask==2.0.0\nrequests\n")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())

    assert "flask" in data["profile"]["frameworks"]


def test_detects_react_framework(tmp_path: Path) -> None:
    """Should detect React from package.json."""
    (tmp_path / "App.jsx").write_text("export default function App() { return <div/>; }\n")
    (tmp_path / "package.json").write_text(
        '{"name": "myapp", "dependencies": {"react": "^18.0.0"}}\n'
    )

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())

    assert "react" in data["profile"]["frameworks"]


def test_detects_android_framework_from_build_gradle(tmp_path: Path) -> None:
    """Should detect Android from build.gradle with android {} block."""
    (tmp_path / "MainActivity.java").write_text(
        "package com.example;\nimport android.app.Activity;\n"
        "public class MainActivity extends Activity {}\n"
    )
    (tmp_path / "build.gradle").write_text(
        'plugins {\n    id "custom.android.application"\n}\n\n'
        "android {\n    namespace 'com.example'\n}\n"
    )

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())

    assert "android" in data["profile"]["frameworks"]


def test_detects_android_framework_from_manifest(tmp_path: Path) -> None:
    """Should detect Android from AndroidManifest.xml presence."""
    (tmp_path / "MainActivity.java").write_text(
        "package com.example;\nimport android.app.Activity;\n"
        "public class MainActivity extends Activity {}\n"
    )
    # Create subdirectory structure like real Android projects
    src_dir = tmp_path / "app" / "src" / "main"
    src_dir.mkdir(parents=True)
    (src_dir / "AndroidManifest.xml").write_text(
        '<?xml version="1.0" encoding="utf-8"?>\n'
        '<manifest xmlns:android="http://schemas.android.com/apk/res/android"\n'
        '    package="com.example">\n'
        "    <application/>\n"
        "</manifest>\n"
    )

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())

    assert "android" in data["profile"]["frameworks"]


def test_detects_express_framework(tmp_path: Path) -> None:
    """Should detect Express.js from package.json."""
    (tmp_path / "server.js").write_text("const express = require('express');\n")
    (tmp_path / "package.json").write_text(
        '{"dependencies": {"express": "^4.18.0"}}\n'
    )

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())

    assert "express" in data["profile"]["frameworks"]


def test_detects_django_framework(tmp_path: Path) -> None:
    """Should detect Django from setup.py or pyproject.toml."""
    (tmp_path / "manage.py").write_text("#!/usr/bin/env python\nimport django\n")
    (tmp_path / "requirements.txt").write_text("Django>=4.0\n")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())

    assert "django" in data["profile"]["frameworks"]


def test_profile_empty_when_no_source_files(tmp_path: Path) -> None:
    """Should return empty profile for repos with no recognized source files."""
    # Create a file with no recognized extension
    (tmp_path / "data.bin").write_bytes(b"\x00\x01\x02")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())

    assert data["profile"]["languages"] == {}
    assert data["profile"]["frameworks"] == []


def test_counts_lines_of_code_correctly(tmp_path: Path) -> None:
    """LOC is deferred: behavior map has loc=0, sketch populates it."""
    (tmp_path / "app.py").write_text("def main():\n    # comment\n    pass\n\n\n")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())

    # LOC is deferred to sketch generation — profile detection only counts files
    assert data["profile"]["languages"]["python"]["loc"] == 0
    assert data["profile"]["languages"]["python"]["files"] == 1


def test_handles_unreadable_dependency_file(tmp_path: Path) -> None:
    """Should gracefully handle unreadable dependency files."""
    (tmp_path / "app.py").write_text("print('hi')\n")

    # Create a directory named pyproject.toml (reading it will fail with IsADirectoryError)
    (tmp_path / "pyproject.toml").mkdir()

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())

    # Should still work, just not detect any frameworks
    assert "python" in data["profile"]["languages"]
    # No crash occurred


def test_handles_invalid_package_json(tmp_path: Path) -> None:
    """Should gracefully handle malformed package.json."""
    (tmp_path / "app.js").write_text("console.log('hi');\n")
    (tmp_path / "package.json").write_text("{ invalid json }")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())

    # Should still detect JavaScript, just not frameworks
    assert "javascript" in data["profile"]["languages"]
    assert data["profile"]["frameworks"] == []


def test_handles_non_dict_package_json(tmp_path: Path) -> None:
    """Should gracefully handle package.json with non-dict top-level value.

    Some repos have package.json files that are valid JSON but contain a
    string or array at the top level instead of an object. This was found
    in the grpc repo during bakeoff testing.
    """
    (tmp_path / "app.js").write_text("console.log('hi');\n")
    # Valid JSON, but a string instead of an object
    (tmp_path / "package.json").write_text('"this is a string, not an object"')

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())

    # Should still detect JavaScript, just not frameworks
    assert "javascript" in data["profile"]["languages"]
    assert data["profile"]["frameworks"] == []


def test_handles_array_package_json(tmp_path: Path) -> None:
    """Should gracefully handle package.json with array at top level."""
    (tmp_path / "app.js").write_text("console.log('hi');\n")
    # Valid JSON, but an array instead of an object
    (tmp_path / "package.json").write_text('["item1", "item2"]')

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())

    # Should still detect JavaScript, just not frameworks
    assert "javascript" in data["profile"]["languages"]
    assert data["profile"]["frameworks"] == []


def test_detects_pytorch_framework(tmp_path: Path) -> None:
    """Should detect PyTorch from dependencies."""
    (tmp_path / "train.py").write_text("import torch\n")
    (tmp_path / "requirements.txt").write_text("torch>=2.0\ntorchvision\n")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "pytorch" in data["profile"]["frameworks"]


def test_detects_tensorflow_framework(tmp_path: Path) -> None:
    """Should detect TensorFlow from dependencies."""
    (tmp_path / "model.py").write_text("import tensorflow as tf\n")
    (tmp_path / "requirements.txt").write_text("tensorflow>=2.0\n")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "tensorflow" in data["profile"]["frameworks"]


def test_detects_transformers_framework(tmp_path: Path) -> None:
    """Should detect HuggingFace Transformers from dependencies."""
    (tmp_path / "nlp.py").write_text("from transformers import pipeline\n")
    (tmp_path / "requirements.txt").write_text("transformers>=4.0\n")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "transformers" in data["profile"]["frameworks"]


def test_detects_langchain_framework(tmp_path: Path) -> None:
    """Should detect LangChain from dependencies."""
    (tmp_path / "agent.py").write_text("from langchain import LLMChain\n")
    (tmp_path / "requirements.txt").write_text("langchain>=0.1\n")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "langchain" in data["profile"]["frameworks"]


def test_detects_scikit_learn_framework(tmp_path: Path) -> None:
    """Should detect scikit-learn from dependencies."""
    (tmp_path / "ml.py").write_text("from sklearn.linear_model import LogisticRegression\n")
    (tmp_path / "requirements.txt").write_text("scikit-learn>=1.0\n")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "scikit-learn" in data["profile"]["frameworks"]


def test_detects_openai_framework(tmp_path: Path) -> None:
    """Should detect OpenAI client from dependencies."""
    (tmp_path / "chat.py").write_text("from openai import OpenAI\n")
    (tmp_path / "requirements.txt").write_text("openai>=1.0\n")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "openai" in data["profile"]["frameworks"]


def test_detects_anthropic_framework(tmp_path: Path) -> None:
    """Should detect Anthropic client from dependencies."""
    (tmp_path / "chat.py").write_text("from anthropic import Anthropic\n")
    (tmp_path / "requirements.txt").write_text("anthropic>=0.5\n")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "anthropic" in data["profile"]["frameworks"]


def test_detects_llamaindex_framework(tmp_path: Path) -> None:
    """Should detect LlamaIndex from dependencies."""
    (tmp_path / "rag.py").write_text("from llama_index import VectorStoreIndex\n")
    (tmp_path / "requirements.txt").write_text("llama-index>=0.9\n")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "llamaindex" in data["profile"]["frameworks"]


def test_detects_mlflow_framework(tmp_path: Path) -> None:
    """Should detect MLflow from dependencies."""
    (tmp_path / "experiment.py").write_text("import mlflow\n")
    (tmp_path / "requirements.txt").write_text("mlflow>=2.0\n")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "mlflow" in data["profile"]["frameworks"]


# Rust framework detection tests


def test_detects_rust_axum_framework(tmp_path: Path) -> None:
    """Should detect Axum web framework from Cargo.toml."""
    (tmp_path / "main.rs").write_text("fn main() {}\n")
    (tmp_path / "Cargo.toml").write_text('''
[package]
name = "myapp"
version = "0.1.0"

[dependencies]
axum = "0.7"
tokio = { version = "1", features = ["full"] }
''')

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "axum" in data["profile"]["frameworks"]
    assert "tokio" in data["profile"]["frameworks"]


def test_detects_rust_solana_framework(tmp_path: Path) -> None:
    """Should detect Solana SDK from Cargo.toml."""
    (tmp_path / "lib.rs").write_text("pub fn process() {}\n")
    (tmp_path / "Cargo.toml").write_text('''
[package]
name = "solana-program"
version = "0.1.0"

[dependencies]
solana-sdk = "1.17"
anchor-lang = "0.29"
''')

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "solana" in data["profile"]["frameworks"]
    assert "anchor" in data["profile"]["frameworks"]


def test_detects_rust_sp1_zkvm(tmp_path: Path) -> None:
    """Should detect SP1 zkVM from Cargo.toml."""
    (tmp_path / "main.rs").write_text("fn main() {}\n")
    (tmp_path / "Cargo.toml").write_text('''
[package]
name = "my-zkprogram"
version = "0.1.0"

[dependencies]
sp1-sdk = "1.0"
''')

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "sp1" in data["profile"]["frameworks"]


def test_detects_rust_arkworks(tmp_path: Path) -> None:
    """Should detect Arkworks ZKP library from Cargo.toml."""
    (tmp_path / "lib.rs").write_text("use ark_ff::Field;\n")
    (tmp_path / "Cargo.toml").write_text('''
[package]
name = "zk-circuit"
version = "0.1.0"

[dependencies]
ark-ff = "0.4"
ark-ec = "0.4"
ark-groth16 = "0.4"
''')

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "arkworks" in data["profile"]["frameworks"]
    assert "groth16" in data["profile"]["frameworks"]


def test_detects_rust_plonky2(tmp_path: Path) -> None:
    """Should detect Plonky2 proving system from Cargo.toml."""
    (tmp_path / "circuit.rs").write_text("use plonky2::field::types::Field;\n")
    (tmp_path / "Cargo.toml").write_text('''
[package]
name = "my-circuit"
version = "0.1.0"

[dependencies]
plonky2 = "0.2"
plonky2_field = "0.2"
''')

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "plonky2" in data["profile"]["frameworks"]


def test_detects_rust_halo2(tmp_path: Path) -> None:
    """Should detect Halo2 proving system from Cargo.toml."""
    (tmp_path / "lib.rs").write_text("use halo2_proofs::dev::MockProver;\n")
    (tmp_path / "Cargo.toml").write_text('''
[package]
name = "halo2-circuit"
version = "0.1.0"

[dependencies]
halo2_proofs = "0.3"
''')

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "halo2" in data["profile"]["frameworks"]


def test_detects_rust_substrate(tmp_path: Path) -> None:
    """Should detect Substrate blockchain framework from Cargo.toml."""
    (tmp_path / "lib.rs").write_text("use frame_support::pallet;\n")
    (tmp_path / "Cargo.toml").write_text('''
[package]
name = "my-pallet"
version = "0.1.0"

[dependencies]
frame-support = "4.0"
sp-core = "21.0"
sp-runtime = "24.0"
''')

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "substrate" in data["profile"]["frameworks"]


def test_detects_rust_ethers(tmp_path: Path) -> None:
    """Should detect ethers-rs Ethereum library from Cargo.toml."""
    (tmp_path / "main.rs").write_text("use ethers::prelude::*;\n")
    (tmp_path / "Cargo.toml").write_text('''
[package]
name = "eth-client"
version = "0.1.0"

[dependencies]
ethers = "2.0"
''')

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "ethers" in data["profile"]["frameworks"]


def test_detects_rust_risc0(tmp_path: Path) -> None:
    """Should detect RISC Zero zkVM from Cargo.toml."""
    (tmp_path / "main.rs").write_text("use risc0_zkvm::*;\n")
    (tmp_path / "Cargo.toml").write_text('''
[package]
name = "risc0-guest"
version = "0.1.0"

[dependencies]
risc0-zkvm = "0.20"
''')

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "risc0" in data["profile"]["frameworks"]


def test_detects_rust_zcash(tmp_path: Path) -> None:
    """Should detect Zcash libraries from Cargo.toml."""
    (tmp_path / "lib.rs").write_text("use zcash_primitives::*;\n")
    (tmp_path / "Cargo.toml").write_text('''
[package]
name = "privacy-wallet"
version = "0.1.0"

[dependencies]
zcash_primitives = "0.13"
orchard = "0.6"
''')

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "zcash" in data["profile"]["frameworks"]


def test_detects_rust_libp2p(tmp_path: Path) -> None:
    """Should detect libp2p networking from Cargo.toml."""
    (tmp_path / "main.rs").write_text("use libp2p::*;\n")
    (tmp_path / "Cargo.toml").write_text('''
[package]
name = "p2p-node"
version = "0.1.0"

[dependencies]
libp2p = "0.53"
''')

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "libp2p" in data["profile"]["frameworks"]


def test_handles_unreadable_cargo_toml(tmp_path: Path) -> None:
    """Should gracefully handle unreadable Cargo.toml."""
    (tmp_path / "main.rs").write_text("fn main() {}\n")
    # Create a directory named Cargo.toml (reading it will fail)
    (tmp_path / "Cargo.toml").mkdir()

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    # Should still work, just not detect any Rust frameworks
    assert "rust" in data["profile"]["languages"]


# Go framework detection tests


def test_detects_go_gin_framework(tmp_path: Path) -> None:
    """Should detect Gin web framework from go.mod."""
    (tmp_path / "main.go").write_text("package main\n")
    (tmp_path / "go.mod").write_text("""module myapp

go 1.21

require (
    github.com/gin-gonic/gin v1.9.0
)
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "gin" in data["profile"]["frameworks"]


def test_detects_go_echo_framework(tmp_path: Path) -> None:
    """Should detect Echo web framework from go.mod."""
    (tmp_path / "main.go").write_text("package main\n")
    (tmp_path / "go.mod").write_text("""module myapp

go 1.21

require (
    github.com/labstack/echo v4.11.0
)
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "echo" in data["profile"]["frameworks"]


def test_detects_go_fiber_framework(tmp_path: Path) -> None:
    """Should detect Fiber web framework from go.mod."""
    (tmp_path / "main.go").write_text("package main\n")
    (tmp_path / "go.mod").write_text("""module myapp

go 1.21

require (
    github.com/gofiber/fiber v2.52.0
)
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "fiber" in data["profile"]["frameworks"]


def test_detects_go_xorm_framework(tmp_path: Path) -> None:
    """Should detect XORM ORM framework from go.mod."""
    (tmp_path / "main.go").write_text("package main\n")
    (tmp_path / "go.mod").write_text("""module code.gitea.io/gitea

go 1.21

require (
    xorm.io/xorm v1.3.4
)
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "xorm" in data["profile"]["frameworks"]


# PHP framework detection tests


def test_detects_php_laravel_framework(tmp_path: Path) -> None:
    """Should detect Laravel framework from composer.json."""
    (tmp_path / "index.php").write_text("<?php\n")
    (tmp_path / "composer.json").write_text("""{
    "require": {
        "laravel/framework": "^10.0"
    }
}""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "laravel" in data["profile"]["frameworks"]


def test_detects_php_symfony_framework(tmp_path: Path) -> None:
    """Should detect Symfony framework from composer.json."""
    (tmp_path / "index.php").write_text("<?php\n")
    (tmp_path / "composer.json").write_text("""{
    "require": {
        "symfony/framework-bundle": "^6.0"
    }
}""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "symfony" in data["profile"]["frameworks"]


def test_handles_invalid_composer_json(tmp_path: Path) -> None:
    """Should gracefully handle malformed composer.json."""
    (tmp_path / "index.php").write_text("<?php\n")
    (tmp_path / "composer.json").write_text("{ invalid json }")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    # Should still detect PHP, just not frameworks
    assert "php" in data["profile"]["languages"]
    assert "laravel" not in data["profile"]["frameworks"]


def test_handles_non_dict_composer_json(tmp_path: Path) -> None:
    """Should gracefully handle composer.json with non-dict top-level value."""
    (tmp_path / "index.php").write_text("<?php\n")
    # Valid JSON, but a string instead of an object
    (tmp_path / "composer.json").write_text('"this is a string"')

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    # Should still detect PHP, just not frameworks
    assert "php" in data["profile"]["languages"]
    assert "laravel" not in data["profile"]["frameworks"]


# Java/Kotlin framework detection tests


def test_detects_java_spring_boot_maven(tmp_path: Path) -> None:
    """Should detect Spring Boot from pom.xml."""
    (tmp_path / "Main.java").write_text("public class Main {}\n")
    (tmp_path / "pom.xml").write_text("""<?xml version="1.0"?>
<project>
    <dependencies>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter</artifactId>
        </dependency>
    </dependencies>
</project>""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "spring-boot" in data["profile"]["frameworks"]


def test_detects_java_spring_boot_gradle(tmp_path: Path) -> None:
    """Should detect Spring Boot from build.gradle."""
    (tmp_path / "Main.java").write_text("public class Main {}\n")
    (tmp_path / "build.gradle").write_text("""plugins {
    id 'org.springframework.boot' version '3.0.0'
}

dependencies {
    implementation 'org.springframework.boot:spring-boot-starter'
}""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "spring-boot" in data["profile"]["frameworks"]


def test_detects_dropwizard_framework_from_gradle(tmp_path: Path) -> None:
    """Should detect Dropwizard from dropwizard-core in build.gradle."""
    (tmp_path / "Main.java").write_text("public class Main {}\n")
    (tmp_path / "build.gradle").write_text("""dependencies {
    implementation 'io.dropwizard:dropwizard-core:4.0.0'
}""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "dropwizard" in data["profile"]["frameworks"]


def test_dropwizard_metrics_does_not_trigger_dropwizard(tmp_path: Path) -> None:
    """Dropwizard Metrics library should not trigger Dropwizard framework detection.

    io.dropwizard.metrics is a standalone metrics library used by many projects
    (Flink, Kafka, etc.) that has no relation to the Dropwizard REST framework.
    Projects like Apache Iceberg reference it as a transitive dependency.
    """
    (tmp_path / "Main.java").write_text("public class Main {}\n")
    (tmp_path / "build.gradle").write_text("""dependencies {
    implementation 'io.dropwizard.metrics:metrics-core:4.2.0'
    exclude group: 'io.dropwizard.metrics', module: 'metrics-core'
}""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "dropwizard" not in data["profile"]["frameworks"]


def test_detects_kotlin_ktor_framework(tmp_path: Path) -> None:
    """Should detect Ktor framework from build.gradle.kts."""
    (tmp_path / "Main.kt").write_text("fun main() {}\n")
    (tmp_path / "build.gradle.kts").write_text("""dependencies {
    implementation("io.ktor:ktor-server-core:2.3.0")
}""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "ktor" in data["profile"]["frameworks"]


def test_detects_jetpack_compose_framework(tmp_path: Path) -> None:
    """Should detect Jetpack Compose from build.gradle."""
    (tmp_path / "MainActivity.kt").write_text("import androidx.compose.ui\n")
    (tmp_path / "build.gradle").write_text("""android {
    buildFeatures {
        compose true
    }
}

dependencies {
    implementation 'androidx.compose.ui:ui:1.5.0'
}""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "jetpack-compose" in data["profile"]["frameworks"]


# Swift framework detection tests


def test_detects_swift_vapor_framework(tmp_path: Path) -> None:
    """Should detect Vapor framework from Package.swift."""
    (tmp_path / "main.swift").write_text("import Vapor\n")
    (tmp_path / "Package.swift").write_text("""// swift-tools-version:5.7
import PackageDescription

let package = Package(
    name: "myapp",
    dependencies: [
        .package(url: "https://github.com/vapor/vapor.git", from: "4.0.0")
    ]
)""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "vapor" in data["profile"]["frameworks"]


# Scala framework detection tests


def test_detects_scala_play_framework(tmp_path: Path) -> None:
    """Should detect Play Framework from build.sbt."""
    (tmp_path / "Main.scala").write_text("object Main extends App\n")
    (tmp_path / "build.sbt").write_text("""name := "myapp"
version := "1.0"

libraryDependencies += "com.typesafe.play" %% "play" % "2.9.0"
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "play" in data["profile"]["frameworks"]


def test_detects_scala_http4s_framework(tmp_path: Path) -> None:
    """Should detect http4s from build.sbt."""
    (tmp_path / "Main.scala").write_text("object Main extends App\n")
    (tmp_path / "build.sbt").write_text("""name := "myapp"
version := "1.0"

libraryDependencies += "org.http4s" %% "http4s-dsl" % "0.23.0"
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "http4s" in data["profile"]["frameworks"]


# Ruby framework detection tests


def test_detects_ruby_rails_framework(tmp_path: Path) -> None:
    """Should detect Rails from Gemfile."""
    (tmp_path / "app.rb").write_text("require 'rails'\n")
    (tmp_path / "Gemfile").write_text("""source 'https://rubygems.org'

gem 'rails', '~> 7.0'
gem 'pg'
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "rails" in data["profile"]["frameworks"]


def test_detects_ruby_sinatra_framework(tmp_path: Path) -> None:
    """Should detect Sinatra from Gemfile."""
    (tmp_path / "app.rb").write_text("require 'sinatra'\n")
    (tmp_path / "Gemfile").write_text("""source 'https://rubygems.org'

gem 'sinatra'
gem 'puma'
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "sinatra" in data["profile"]["frameworks"]


def test_detects_ruby_grape_framework(tmp_path: Path) -> None:
    """Should detect Grape from Gemfile."""
    (tmp_path / "app.rb").write_text("require 'grape'\n")
    (tmp_path / "Gemfile").write_text("""source 'https://rubygems.org'

gem 'grape'
gem 'grape-entity'
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "grape" in data["profile"]["frameworks"]


# Elixir framework detection tests


def test_detects_elixir_phoenix_framework(tmp_path: Path) -> None:
    """Should detect Phoenix from mix.exs."""
    (tmp_path / "lib").mkdir()
    (tmp_path / "lib" / "app.ex").write_text("defmodule App do\nend\n")
    (tmp_path / "mix.exs").write_text("""defmodule App.MixProject do
  use Mix.Project

  defp deps do
    [
      {:phoenix, "~> 1.7"},
      {:phoenix_live_view, "~> 0.19"}
    ]
  end
end
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "phoenix" in data["profile"]["frameworks"]


def test_detects_elixir_ecto_framework(tmp_path: Path) -> None:
    """Should detect Ecto from mix.exs."""
    (tmp_path / "lib").mkdir()
    (tmp_path / "lib" / "app.ex").write_text("defmodule App do\nend\n")
    (tmp_path / "mix.exs").write_text("""defmodule App.MixProject do
  use Mix.Project

  defp deps do
    [
      {:ecto, "~> 3.10"},
      {:ecto_sql, "~> 3.10"}
    ]
  end
end
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "ecto" in data["profile"]["frameworks"]


# Dart/Flutter framework detection tests


def test_detects_dart_language(tmp_path: Path) -> None:
    """Should detect Dart files."""
    (tmp_path / "main.dart").write_text("void main() {}\n")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "dart" in data["profile"]["languages"]


def test_detects_flutter_framework(tmp_path: Path) -> None:
    """Should detect Flutter SDK from pubspec.yaml."""
    (tmp_path / "main.dart").write_text("import 'package:flutter/material.dart';\n")
    (tmp_path / "pubspec.yaml").write_text("""name: myapp
dependencies:
  flutter:
    sdk: flutter
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "flutter" in data["profile"]["frameworks"]


def test_detects_flutter_bloc_framework(tmp_path: Path) -> None:
    """Should detect Flutter Bloc state management from pubspec.yaml."""
    (tmp_path / "main.dart").write_text("import 'package:flutter_bloc/flutter_bloc.dart';\n")
    (tmp_path / "pubspec.yaml").write_text("""name: myapp
dependencies:
  flutter:
    sdk: flutter
  flutter_bloc: ^8.0.0
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "flutter" in data["profile"]["frameworks"]
    assert "flutter_bloc" in data["profile"]["frameworks"]


def test_handles_unreadable_pubspec(tmp_path: Path) -> None:
    """Should gracefully handle unreadable pubspec.yaml."""
    (tmp_path / "main.dart").write_text("void main() {}\n")
    # Create a directory named pubspec.yaml (reading it will fail)
    (tmp_path / "pubspec.yaml").mkdir()

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    # Should still detect Dart, just not Flutter frameworks
    assert "dart" in data["profile"]["languages"]


# Mobile framework detection tests (React Native, Expo, etc.)


def test_detects_react_native_framework(tmp_path: Path) -> None:
    """Should detect React Native from package.json."""
    (tmp_path / "App.js").write_text("import { View } from 'react-native';\n")
    (tmp_path / "package.json").write_text("""{
    "dependencies": {
        "react": "^18.0.0",
        "react-native": "^0.72.0"
    }
}""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "react-native" in data["profile"]["frameworks"]
    assert "react" in data["profile"]["frameworks"]


def test_detects_expo_framework(tmp_path: Path) -> None:
    """Should detect Expo from package.json."""
    (tmp_path / "App.js").write_text("import { StatusBar } from 'expo-status-bar';\n")
    (tmp_path / "package.json").write_text("""{
    "dependencies": {
        "expo": "^49.0.0",
        "react-native": "^0.72.0"
    }
}""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "expo" in data["profile"]["frameworks"]


# Meta-framework detection tests


def test_detects_nextjs_framework(tmp_path: Path) -> None:
    """Should detect Next.js from package.json."""
    (tmp_path / "pages").mkdir()
    (tmp_path / "pages/index.tsx").write_text("export default function Home() {}\n")
    (tmp_path / "package.json").write_text("""{
    "dependencies": {
        "next": "^14.0.0",
        "react": "^18.0.0"
    }
}""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "next" in data["profile"]["frameworks"]


def test_detects_astro_framework(tmp_path: Path) -> None:
    """Should detect Astro from package.json."""
    (tmp_path / "src" / "pages").mkdir(parents=True)
    (tmp_path / "src/pages/index.astro").write_text("---\n---\n<html></html>\n")
    (tmp_path / "package.json").write_text("""{
    "dependencies": {
        "astro": "^4.0.0"
    }
}""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "astro" in data["profile"]["frameworks"]


# Desktop framework detection tests


def test_detects_electron_framework(tmp_path: Path) -> None:
    """Should detect Electron from package.json."""
    (tmp_path / "main.js").write_text("const { app } = require('electron');\n")
    (tmp_path / "package.json").write_text("""{
    "devDependencies": {
        "electron": "^28.0.0"
    }
}""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "electron" in data["profile"]["frameworks"]


def test_detects_tauri_js_framework(tmp_path: Path) -> None:
    """Should detect Tauri from package.json."""
    (tmp_path / "App.tsx").write_text("import { invoke } from '@tauri-apps/api';\n")
    (tmp_path / "package.json").write_text("""{
    "dependencies": {
        "@tauri-apps/api": "^1.5.0"
    }
}""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "tauri" in data["profile"]["frameworks"]


# Blockchain/Web3 framework detection tests


def test_detects_hardhat_framework(tmp_path: Path) -> None:
    """Should detect Hardhat from package.json."""
    (tmp_path / "contracts").mkdir()
    (tmp_path / "contracts/Token.sol").write_text("pragma solidity ^0.8.0;\n")
    (tmp_path / "package.json").write_text("""{
    "devDependencies": {
        "hardhat": "^2.19.0"
    }
}""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "hardhat" in data["profile"]["frameworks"]


def test_detects_ethersjs_framework(tmp_path: Path) -> None:
    """Should detect ethers.js from package.json."""
    (tmp_path / "app.js").write_text("const { ethers } = require('ethers');\n")
    (tmp_path / "package.json").write_text("""{
    "dependencies": {
        "ethers": "^6.0.0"
    }
}""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "ethers" in data["profile"]["frameworks"]


def test_extra_excludes_filters_files(tmp_path: Path) -> None:
    """Extra excludes should filter out files from language detection."""
    from hypergumbo_core.profile import detect_profile

    # Create Python files
    (tmp_path / "app.py").write_text("def main():\n    pass\n")
    (tmp_path / "generated.py").write_text("def generated():\n    pass\n")

    # Without extra excludes - should see 2 Python files
    profile = detect_profile(tmp_path)
    assert profile.languages.get("python", {}).files == 2

    # With extra excludes - should exclude generated.py
    profile = detect_profile(tmp_path, extra_excludes=["generated.py"])
    assert profile.languages.get("python", {}).files == 1


# Solidity framework detection tests


def test_detects_solidity_language(tmp_path: Path) -> None:
    """Should detect Solidity files."""
    (tmp_path / "Token.sol").write_text("pragma solidity ^0.8.0;\n")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "solidity" in data["profile"]["languages"]


def test_detects_foundry_framework(tmp_path: Path) -> None:
    """Should detect Foundry framework from foundry.toml."""
    (tmp_path / "src").mkdir()
    (tmp_path / "src/Token.sol").write_text("pragma solidity ^0.8.0;\n")
    (tmp_path / "foundry.toml").write_text("""[profile.default]
src = "src"
out = "out"
libs = ["lib"]
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "foundry" in data["profile"]["frameworks"]


def test_detects_hardhat_framework_from_config_js(tmp_path: Path) -> None:
    """Should detect Hardhat framework from hardhat.config.js."""
    (tmp_path / "contracts").mkdir()
    (tmp_path / "contracts/Token.sol").write_text("pragma solidity ^0.8.0;\n")
    (tmp_path / "hardhat.config.js").write_text("""module.exports = {
  solidity: "0.8.19",
};
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "hardhat" in data["profile"]["frameworks"]


def test_detects_hardhat_framework_from_config_ts(tmp_path: Path) -> None:
    """Should detect Hardhat framework from hardhat.config.ts."""
    (tmp_path / "contracts").mkdir()
    (tmp_path / "contracts/Token.sol").write_text("pragma solidity ^0.8.0;\n")
    (tmp_path / "hardhat.config.ts").write_text("""import { HardhatUserConfig } from "hardhat/config";
const config: HardhatUserConfig = {
  solidity: "0.8.19",
};
export default config;
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "hardhat" in data["profile"]["frameworks"]


def test_detects_both_foundry_and_hardhat(tmp_path: Path) -> None:
    """Should detect both Foundry and Hardhat when both configs exist."""
    (tmp_path / "src").mkdir()
    (tmp_path / "src/Token.sol").write_text("pragma solidity ^0.8.0;\n")
    (tmp_path / "foundry.toml").write_text('[profile.default]\nsrc = "src"\n')
    (tmp_path / "hardhat.config.js").write_text('module.exports = {};\n')

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "foundry" in data["profile"]["frameworks"]
    assert "hardhat" in data["profile"]["frameworks"]


def test_count_loc_with_max_file_size(tmp_path: Path) -> None:
    """Should skip files larger than max_file_size when specified."""
    from hypergumbo_core.profile import _count_loc

    # Create a small file - should be counted regardless
    small_file = tmp_path / "small.py"
    small_content = "x = 1\n" * 100  # 600 bytes
    small_file.write_text(small_content)
    assert _count_loc(small_file) == 100
    assert _count_loc(small_file, max_file_size=1000) == 100

    # Create a larger file
    large_file = tmp_path / "large.py"
    large_content = "x = 1\n" * 500  # 3000 bytes
    large_file.write_text(large_content)

    # Without max_file_size, counts all lines
    assert _count_loc(large_file) == 500
    # With max_file_size below file size, returns 0
    assert _count_loc(large_file, max_file_size=1000) == 0
    # With max_file_size above file size, counts all lines
    assert _count_loc(large_file, max_file_size=10000) == 500


def test_detect_languages_defers_loc_counting(tmp_path: Path) -> None:
    """_detect_languages returns loc=0; LOC is computed lazily later."""
    from hypergumbo_core.profile import _detect_languages

    # Create Python files
    (tmp_path / "small.py").write_text("print('hi')\n")
    (tmp_path / "large.py").write_text("x = 1\n" * 500)

    langs = _detect_languages(tmp_path)
    assert langs["python"].files == 2
    # LOC counting is deferred to _analyze_test_files in sketch.py
    assert langs["python"].loc == 0


# Recursive manifest scanning tests


def test_detects_python_framework_in_subdirectory(tmp_path: Path) -> None:
    """Should detect FastAPI from pyproject.toml in a subdirectory."""
    # Simulate monorepo structure: backend/pyproject.toml
    backend = tmp_path / "backend"
    backend.mkdir()
    (backend / "app.py").write_text("from fastapi import FastAPI\n")
    (backend / "pyproject.toml").write_text("""[project]
dependencies = ["fastapi"]
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "fastapi" in data["profile"]["frameworks"]


def test_detects_js_framework_in_subdirectory(tmp_path: Path) -> None:
    """Should detect React from package.json in a subdirectory."""
    # Simulate monorepo structure: frontend/package.json
    frontend = tmp_path / "frontend"
    frontend.mkdir()
    (frontend / "app.js").write_text("import React from 'react';\n")
    (frontend / "package.json").write_text(json.dumps({
        "dependencies": {"react": "^18.0.0"}
    }))

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "react" in data["profile"]["frameworks"]


def test_detects_frameworks_from_multiple_subdirectories(tmp_path: Path) -> None:
    """Should detect frameworks from both backend and frontend subdirectories."""
    # Backend with FastAPI
    backend = tmp_path / "backend"
    backend.mkdir()
    (backend / "app.py").write_text("from fastapi import FastAPI\n")
    (backend / "pyproject.toml").write_text("""[project]
dependencies = ["fastapi"]
""")

    # Frontend with React
    frontend = tmp_path / "frontend"
    frontend.mkdir()
    (frontend / "app.js").write_text("import React from 'react';\n")
    (frontend / "package.json").write_text(json.dumps({
        "dependencies": {"react": "^18.0.0"}
    }))

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "fastapi" in data["profile"]["frameworks"]
    assert "react" in data["profile"]["frameworks"]


def test_recursive_scan_skips_node_modules(tmp_path: Path) -> None:
    """Should not scan package.json inside node_modules."""
    # Create main app
    (tmp_path / "app.js").write_text("console.log('app');\n")

    # Create package.json in node_modules (should be skipped)
    node_modules = tmp_path / "node_modules" / "some-package"
    node_modules.mkdir(parents=True)
    (node_modules / "package.json").write_text(json.dumps({
        "dependencies": {"react": "^18.0.0"}
    }))

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    # React should NOT be detected since it's only in node_modules
    assert "react" not in data["profile"]["frameworks"]


def test_recursive_scan_skips_venv(tmp_path: Path) -> None:
    """Should not scan pyproject.toml inside venv directories."""
    # Create main app
    (tmp_path / "app.py").write_text("print('app')\n")

    # Create pyproject.toml in venv (should be skipped)
    venv = tmp_path / "venv" / "lib" / "python3.10"
    venv.mkdir(parents=True)
    (venv / "pyproject.toml").write_text("""[project]
dependencies = ["django"]
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    # Django should NOT be detected since it's only in venv
    assert "django" not in data["profile"]["frameworks"]


def test_find_manifest_files_helper(tmp_path: Path) -> None:
    """Test the _find_manifest_files helper directly."""
    from hypergumbo_core.profile import _find_manifest_files

    # Create files at various depths
    (tmp_path / "pyproject.toml").write_text("root")
    (tmp_path / "backend").mkdir()
    (tmp_path / "backend" / "pyproject.toml").write_text("backend")
    (tmp_path / "services" / "api").mkdir(parents=True)
    (tmp_path / "services" / "api" / "pyproject.toml").write_text("services/api")

    found = _find_manifest_files(tmp_path, "pyproject.toml")
    paths = [str(p.relative_to(tmp_path)) for p in found]

    assert "pyproject.toml" in paths
    assert "backend/pyproject.toml" in paths
    assert "services/api/pyproject.toml" in paths


def test_detects_flutter_in_subdirectory(tmp_path: Path) -> None:
    """Should detect Flutter from pubspec.yaml in a subdirectory."""
    # Simulate monorepo with Flutter app in subdirectory
    mobile = tmp_path / "mobile"
    mobile.mkdir()
    (mobile / "lib").mkdir()
    (mobile / "lib" / "main.dart").write_text("void main() {}\n")
    (mobile / "pubspec.yaml").write_text("""name: myapp
dependencies:
  flutter:
    sdk: flutter
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "flutter" in data["profile"]["frameworks"]


# Haskell framework detection tests


def test_detects_haskell_servant_framework_from_cabal(tmp_path: Path) -> None:
    """Should detect Servant from *.cabal file."""
    (tmp_path / "Main.hs").write_text("main = putStrLn \"Hello\"\n")
    (tmp_path / "myapp.cabal").write_text("""name: myapp
version: 0.1.0.0
build-depends:
    base >=4.7 && <5,
    servant-server,
    warp
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "servant" in data["profile"]["frameworks"]


def test_detects_haskell_scotty_framework_from_stack_yaml(tmp_path: Path) -> None:
    """Should detect Scotty from stack.yaml."""
    (tmp_path / "Main.hs").write_text("main = putStrLn \"Hello\"\n")
    (tmp_path / "stack.yaml").write_text("""resolver: lts-21.0
packages:
  - .
extra-deps:
  - scotty-0.12.1
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "scotty" in data["profile"]["frameworks"]


def test_detects_haskell_servant_from_package_yaml(tmp_path: Path) -> None:
    """Should detect Servant from package.yaml (hpack)."""
    (tmp_path / "Main.hs").write_text("main = putStrLn \"Hello\"\n")
    (tmp_path / "package.yaml").write_text("""name: myapp
dependencies:
  - base >= 4.7 && < 5
  - servant
  - servant-server
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "servant" in data["profile"]["frameworks"]


# Clojure framework detection tests


def test_detects_clojure_ring_framework_from_deps_edn(tmp_path: Path) -> None:
    """Should detect Ring/Compojure from deps.edn."""
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "core.clj").write_text("(ns myapp.core)\n")
    (tmp_path / "deps.edn").write_text("""{:deps
 {ring/ring-core {:mvn/version "1.10.0"}
  compojure/compojure {:mvn/version "1.7.0"}}}
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "ring-compojure" in data["profile"]["frameworks"]


def test_detects_clojure_pedestal_framework_from_project_clj(tmp_path: Path) -> None:
    """Should detect Pedestal from project.clj (Leiningen)."""
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "core.clj").write_text("(ns myapp.core)\n")
    (tmp_path / "project.clj").write_text("""(defproject myapp "0.1.0"
  :dependencies [[org.clojure/clojure "1.11.1"]
                 [io.pedestal/pedestal.service "0.6.0"]
                 [io.pedestal/pedestal.route "0.6.0"]])
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "pedestal" in data["profile"]["frameworks"]


# R framework detection tests


def test_detects_r_shiny_framework(tmp_path: Path) -> None:
    """Should detect Shiny from DESCRIPTION file."""
    (tmp_path / "app.R").write_text("library(shiny)\nshinyApp(ui, server)\n")
    (tmp_path / "DESCRIPTION").write_text("""Package: myapp
Title: My Shiny App
Version: 0.1.0
Imports:
    shiny,
    dplyr
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "shiny" in data["profile"]["frameworks"]


def test_detects_r_plumber_framework(tmp_path: Path) -> None:
    """Should detect Plumber from DESCRIPTION file."""
    (tmp_path / "api.R").write_text("#* @get /hello\nfunction() 'Hello'\n")
    (tmp_path / "DESCRIPTION").write_text("""Package: myapi
Title: My API
Version: 0.1.0
Imports:
    plumber
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "plumber" in data["profile"]["frameworks"]


# Lua framework detection tests


def test_detects_lua_openresty_framework(tmp_path: Path) -> None:
    """Should detect OpenResty from rockspec or nginx.conf."""
    (tmp_path / "app.lua").write_text("ngx.say('Hello')\n")
    (tmp_path / "nginx.conf").write_text("""
http {
    server {
        location / {
            content_by_lua_block {
                ngx.say("Hello from OpenResty")
            }
        }
    }
}
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "openresty" in data["profile"]["frameworks"]


def test_detects_lua_lapis_framework(tmp_path: Path) -> None:
    """Should detect Lapis from rockspec file."""
    (tmp_path / "app.lua").write_text("local lapis = require('lapis')\n")
    (tmp_path / "myapp-1.0-1.rockspec").write_text("""package = "myapp"
version = "1.0-1"
dependencies = {
    "lua >= 5.1",
    "lapis"
}
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "lapis" in data["profile"]["frameworks"]


# C++ framework detection tests


def test_detects_cpp_qt_framework_from_cmake(tmp_path: Path) -> None:
    """Should detect Qt from CMakeLists.txt."""
    (tmp_path / "main.cpp").write_text("#include <QApplication>\nint main() {}\n")
    (tmp_path / "CMakeLists.txt").write_text("""cmake_minimum_required(VERSION 3.16)
project(myapp)
find_package(Qt6 REQUIRED COMPONENTS Widgets)
add_executable(myapp main.cpp)
target_link_libraries(myapp Qt6::Widgets)
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "qt" in data["profile"]["frameworks"]


def test_detects_cpp_qt_framework_from_pro(tmp_path: Path) -> None:
    """Should detect Qt from .pro (qmake) file."""
    (tmp_path / "main.cpp").write_text("#include <QApplication>\nint main() {}\n")
    (tmp_path / "myapp.pro").write_text("""QT += widgets
SOURCES += main.cpp
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "qt" in data["profile"]["frameworks"]


# Erlang framework detection tests


def test_detects_erlang_cowboy_framework(tmp_path: Path) -> None:
    """Should detect Cowboy from rebar.config."""
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "myapp.erl").write_text("-module(myapp).\n")
    (tmp_path / "rebar.config").write_text("""{deps, [
    {cowboy, "2.10.0"}
]}.
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "cowboy" in data["profile"]["frameworks"]


# F# framework detection tests


def test_detects_fsharp_giraffe_framework(tmp_path: Path) -> None:
    """Should detect Giraffe from .fsproj file."""
    (tmp_path / "Program.fs").write_text("open Giraffe\n[<EntryPoint>]\nlet main _ = 0\n")
    (tmp_path / "myapp.fsproj").write_text("""<Project Sdk="Microsoft.NET.Sdk.Web">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
  </PropertyGroup>
  <ItemGroup>
    <PackageReference Include="Giraffe" Version="6.0.0" />
  </ItemGroup>
</Project>
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "giraffe" in data["profile"]["frameworks"]


def test_detects_fsharp_saturn_framework(tmp_path: Path) -> None:
    """Should detect Saturn from .fsproj file."""
    (tmp_path / "Program.fs").write_text("open Saturn\n[<EntryPoint>]\nlet main _ = 0\n")
    (tmp_path / "myapp.fsproj").write_text("""<Project Sdk="Microsoft.NET.Sdk.Web">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
  </PropertyGroup>
  <ItemGroup>
    <PackageReference Include="Saturn" Version="0.16.1" />
  </ItemGroup>
</Project>
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "saturn" in data["profile"]["frameworks"]


# Kotlin-specific framework detection tests


def test_detects_kotlin_ktor_from_gradle_kts(tmp_path: Path) -> None:
    """Should detect Ktor from build.gradle.kts."""
    (tmp_path / "Application.kt").write_text("fun main() {}\n")
    (tmp_path / "build.gradle.kts").write_text("""dependencies {
    implementation("io.ktor:ktor-server-core:2.3.0")
    implementation("io.ktor:ktor-server-netty:2.3.0")
}""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "ktor" in data["profile"]["frameworks"]


def test_detects_kotlin_exposed_framework(tmp_path: Path) -> None:
    """Should detect Exposed ORM from build.gradle.kts."""
    (tmp_path / "Database.kt").write_text("import org.jetbrains.exposed.sql.*\n")
    (tmp_path / "build.gradle.kts").write_text("""dependencies {
    implementation("org.jetbrains.exposed:exposed-core:0.44.0")
    implementation("org.jetbrains.exposed:exposed-dao:0.44.0")
}""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "exposed" in data["profile"]["frameworks"]


# C# framework detection tests


def test_detects_csharp_aspnetcore_framework(tmp_path: Path) -> None:
    """Should detect ASP.NET Core from .csproj file."""
    (tmp_path / "Program.cs").write_text("using Microsoft.AspNetCore;\n")
    (tmp_path / "myapp.csproj").write_text("""<Project Sdk="Microsoft.NET.Sdk.Web">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
  </PropertyGroup>
  <ItemGroup>
    <PackageReference Include="Microsoft.AspNetCore.OpenApi" Version="8.0.0" />
  </ItemGroup>
</Project>
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "aspnetcore" in data["profile"]["frameworks"]


def test_detects_csharp_blazor_framework(tmp_path: Path) -> None:
    """Should detect Blazor from .csproj file."""
    (tmp_path / "App.razor").write_text("<Router AppAssembly=\"@typeof(App).Assembly\"/>\n")
    (tmp_path / "myapp.csproj").write_text("""<Project Sdk="Microsoft.NET.Sdk.BlazorWebAssembly">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
  </PropertyGroup>
  <ItemGroup>
    <PackageReference Include="Microsoft.AspNetCore.Components.WebAssembly" Version="8.0.0" />
  </ItemGroup>
</Project>
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "blazor" in data["profile"]["frameworks"]


# Dart web framework detection tests


def test_detects_dart_shelf_framework(tmp_path: Path) -> None:
    """Should detect Shelf from pubspec.yaml."""
    (tmp_path / "bin" / "server.dart").parent.mkdir(parents=True)
    (tmp_path / "bin" / "server.dart").write_text("import 'package:shelf/shelf.dart';\n")
    (tmp_path / "pubspec.yaml").write_text("""name: myserver
dependencies:
  shelf: ^1.4.0
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "shelf" in data["profile"]["frameworks"]


def test_detects_dart_serverpod_framework(tmp_path: Path) -> None:
    """Should detect Serverpod from pubspec.yaml."""
    (tmp_path / "lib" / "server.dart").parent.mkdir(parents=True)
    (tmp_path / "lib" / "server.dart").write_text("import 'package:serverpod/serverpod.dart';\n")
    (tmp_path / "pubspec.yaml").write_text("""name: myserver
dependencies:
  serverpod: ^1.2.0
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "serverpod" in data["profile"]["frameworks"]


# Julia framework detection tests


def test_detects_julia_genie_framework(tmp_path: Path) -> None:
    """Should detect Genie from Project.toml."""
    (tmp_path / "src" / "app.jl").parent.mkdir(parents=True)
    (tmp_path / "src" / "app.jl").write_text("using Genie\n")
    (tmp_path / "Project.toml").write_text("""name = "MyApp"
[deps]
Genie = "c43c736e-a2d1-11e8-161f-af95117fbd1e"
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "genie" in data["profile"]["frameworks"]


def test_detects_julia_oxygen_framework(tmp_path: Path) -> None:
    """Should detect Oxygen from Project.toml."""
    (tmp_path / "src" / "app.jl").parent.mkdir(parents=True)
    (tmp_path / "src" / "app.jl").write_text("using Oxygen\n")
    (tmp_path / "Project.toml").write_text("""name = "MyApp"
[deps]
Oxygen = "c43c736e-a2d1-11e8-161f-af95117fbd1e"
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "oxygen" in data["profile"]["frameworks"]


# OCaml framework detection tests


def test_detects_ocaml_dream_framework(tmp_path: Path) -> None:
    """Should detect Dream from dune-project or .opam file."""
    (tmp_path / "main.ml").write_text("let () = Dream.run @@ Dream.router []\n")
    (tmp_path / "myapp.opam").write_text("""opam-version: "2.0"
depends: [
  "dream" {>= "1.0.0"}
]
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "dream" in data["profile"]["frameworks"]


def test_detects_ocaml_cohttp_framework(tmp_path: Path) -> None:
    """Should detect Cohttp from dune-project."""
    (tmp_path / "main.ml").write_text("open Cohttp_lwt_unix\n")
    (tmp_path / "dune-project").write_text("""(lang dune 3.0)
(name myapp)
(package (depends cohttp-lwt-unix))
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "cohttp" in data["profile"]["frameworks"]


# Nim framework detection tests


def test_detects_nim_jester_framework(tmp_path: Path) -> None:
    """Should detect Jester from .nimble file."""
    (tmp_path / "src" / "app.nim").parent.mkdir(parents=True)
    (tmp_path / "src" / "app.nim").write_text("import jester\n")
    (tmp_path / "myapp.nimble").write_text("""version = "0.1.0"
requires "jester >= 0.5.0"
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "jester" in data["profile"]["frameworks"]


def test_detects_nim_prologue_framework(tmp_path: Path) -> None:
    """Should detect Prologue from .nimble file."""
    (tmp_path / "src" / "app.nim").parent.mkdir(parents=True)
    (tmp_path / "src" / "app.nim").write_text("import prologue\n")
    (tmp_path / "myapp.nimble").write_text("""version = "0.1.0"
requires "prologue >= 0.6.0"
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "prologue" in data["profile"]["frameworks"]


# Zig framework detection tests


def test_detects_zig_zap_framework(tmp_path: Path) -> None:
    """Should detect zap from build.zig.zon."""
    (tmp_path / "src" / "main.zig").parent.mkdir(parents=True)
    (tmp_path / "src" / "main.zig").write_text("const zap = @import(\"zap\");\n")
    (tmp_path / "build.zig.zon").write_text(""".{
    .name = "myapp",
    .dependencies = .{
        .zap = .{
            .url = "https://github.com/zigzap/zap/archive/refs/tags/v0.0.1.tar.gz",
        },
    },
}
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "zap" in data["profile"]["frameworks"]


# D framework detection tests


def test_detects_d_vibed_framework(tmp_path: Path) -> None:
    """Should detect vibe.d from dub.json."""
    (tmp_path / "source" / "app.d").parent.mkdir(parents=True)
    (tmp_path / "source" / "app.d").write_text("import vibe.d;\n")
    (tmp_path / "dub.json").write_text("""{
    "name": "myapp",
    "dependencies": {
        "vibe-d": "~>0.9.0"
    }
}
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "vibe-d" in data["profile"]["frameworks"]


def test_detects_d_hunt_framework(tmp_path: Path) -> None:
    """Should detect Hunt from dub.sdl."""
    (tmp_path / "source" / "app.d").parent.mkdir(parents=True)
    (tmp_path / "source" / "app.d").write_text("import hunt.framework;\n")
    (tmp_path / "dub.sdl").write_text("""name "myapp"
dependency "hunt-framework" version="~>3.0.0"
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "hunt" in data["profile"]["frameworks"]


# Groovy framework detection tests


def test_detects_groovy_grails_framework(tmp_path: Path) -> None:
    """Should detect Grails from build.gradle."""
    (tmp_path / "grails-app" / "controllers").mkdir(parents=True)
    (tmp_path / "grails-app" / "controllers" / "HomeController.groovy").write_text(
        "class HomeController {}\n"
    )
    (tmp_path / "build.gradle").write_text("""plugins {
    id "org.grails.grails-web" version "5.3.0"
}

dependencies {
    implementation 'org.grails:grails-core'
}
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "grails" in data["profile"]["frameworks"]


def test_detects_groovy_ratpack_framework(tmp_path: Path) -> None:
    """Should detect Ratpack from build.gradle."""
    (tmp_path / "src" / "main" / "groovy").mkdir(parents=True)
    (tmp_path / "src" / "main" / "groovy" / "App.groovy").write_text(
        "import ratpack.groovy.Groovy\n"
    )
    (tmp_path / "build.gradle").write_text("""plugins {
    id 'io.ratpack.ratpack-groovy' version '1.9.0'
}

dependencies {
    implementation 'io.ratpack:ratpack-core'
}
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "ratpack" in data["profile"]["frameworks"]


def test_bottleneck_does_not_trigger_bottle_detection(tmp_path: Path) -> None:
    """The package 'bottleneck' should not cause 'bottle' framework detection.

    Substring matching on 'bottle' in 'bottleneck' caused false Bottle
    framework detection, which then applied Bottle's bare @patch/@get
    decorator patterns to non-Bottle repos (e.g., Superset).
    """
    (tmp_path / "app.py").write_text("import bottleneck\nx = bottleneck.nanmean([1])\n")
    (tmp_path / "pyproject.toml").write_text(
        '[project]\nname = "myapp"\ndependencies = ["bottleneck", "pandas"]\n'
    )

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "bottle" not in data["profile"]["frameworks"]


def test_bottle_detected_when_actual_dependency(tmp_path: Path) -> None:
    """The actual 'bottle' package should still be detected."""
    (tmp_path / "app.py").write_text("from bottle import route, run\n")
    (tmp_path / "requirements.txt").write_text("bottle==0.12.25\nrequests\n")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "bottle" in data["profile"]["frameworks"]


def test_detects_guice_from_maven(tmp_path: Path) -> None:
    """Should detect Google Guice from pom.xml."""
    (tmp_path / "Main.java").write_text("public class Main {}\n")
    (tmp_path / "pom.xml").write_text("""<?xml version="1.0"?>
<project>
    <dependencies>
        <dependency>
            <groupId>com.google.inject</groupId>
            <artifactId>guice</artifactId>
        </dependency>
    </dependencies>
</project>""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "guice" in data["profile"]["frameworks"]


def test_detects_jakarta_cdi_from_maven(tmp_path: Path) -> None:
    """Should detect Jakarta CDI from pom.xml with CDI context import."""
    (tmp_path / "Main.java").write_text("public class Main {}\n")
    (tmp_path / "pom.xml").write_text("""<?xml version="1.0"?>
<project>
    <dependencies>
        <dependency>
            <groupId>org.jboss.weld.se</groupId>
            <artifactId>weld-se-core</artifactId>
        </dependency>
    </dependencies>
</project>""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "jakarta-cdi" in data["profile"]["frameworks"]


def test_detects_guice_from_gradle(tmp_path: Path) -> None:
    """Should detect Google Guice from build.gradle."""
    (tmp_path / "Main.java").write_text("public class Main {}\n")
    (tmp_path / "build.gradle").write_text("""dependencies {
    implementation 'com.google.inject:guice:5.1.0'
}""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "guice" in data["profile"]["frameworks"]


def test_detects_jaxrs_from_auxiliary_gradle_file(tmp_path: Path) -> None:
    """Should detect JAX-RS from gradle/dependencies.gradle (auxiliary Gradle files).

    Multi-module Gradle projects like Apache Kafka declare dependencies in
    files like gradle/dependencies.gradle rather than in build.gradle directly.
    The framework detector must scan *.gradle files in the gradle/ directory.
    """
    (tmp_path / "Main.java").write_text("public class Main {}\n")
    # Root build.gradle exists but doesn't declare JAX-RS
    (tmp_path / "build.gradle").write_text("""plugins {
    id 'java'
}""")
    # JAX-RS dependency declared in gradle/dependencies.gradle (Kafka pattern)
    gradle_dir = tmp_path / "gradle"
    gradle_dir.mkdir()
    (gradle_dir / "dependencies.gradle").write_text("""
ext {
    versions = [jakartaRs: "3.1.0"]
    libs = [
        jakartaRsApi: "jakarta.ws.rs:jakarta.ws.rs-api:$versions.jakartaRs",
    ]
}
""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "jax-rs" in data["profile"]["frameworks"]


def test_bare_graphql_package_does_not_trigger_framework(tmp_path: Path) -> None:
    """Bare 'graphql' npm package should NOT activate graphql framework (WI-rofiz).

    Many JS/TS projects install 'graphql' for type definitions or code
    generation without implementing a GraphQL server. Only server-specific
    packages like @apollo/server should trigger the framework.
    """
    (tmp_path / "app.ts").write_text("console.log('hello');\n")
    (tmp_path / "package.json").write_text("""{
    "dependencies": {
        "graphql": "^16.0.0",
        "express": "^4.18.0"
    }
}""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "graphql" not in data["profile"]["frameworks"], (
        "Bare 'graphql' npm package should not activate graphql framework"
    )


def test_apollo_server_triggers_graphql_framework(tmp_path: Path) -> None:
    """@apollo/server should activate graphql framework."""
    (tmp_path / "app.ts").write_text("console.log('hello');\n")
    (tmp_path / "package.json").write_text("""{
    "dependencies": {
        "@apollo/server": "^4.0.0",
        "graphql": "^16.0.0"
    }
}""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "graphql" in data["profile"]["frameworks"]


def test_detects_stapler_from_maven(tmp_path: Path) -> None:
    """Should detect Stapler framework from pom.xml."""
    (tmp_path / "Main.java").write_text("public class Main {}\n")
    (tmp_path / "pom.xml").write_text("""<?xml version="1.0"?>
<project>
    <dependencies>
        <dependency>
            <groupId>org.kohsuke.stapler</groupId>
            <artifactId>stapler-core</artifactId>
        </dependency>
    </dependencies>
</project>""")

    out_path = tmp_path / "out.json"
    run_behavior_map(repo_root=tmp_path, out_path=out_path, include_sketch_precomputed=False)

    data = json.loads(out_path.read_text())
    assert "stapler" in data["profile"]["frameworks"]


def test_detects_protobuf_framework_from_proto_files(tmp_path: Path) -> None:
    """Protobuf framework detected when .proto files are present."""
    from hypergumbo_core.profile import _detect_protobuf

    (tmp_path / "user.proto").write_text(
        'syntax = "proto3";\nservice UserService { rpc GetUser(Req) returns (Resp); }\n'
    )

    detected = _detect_protobuf(tmp_path)
    assert detected == ["protobuf"]


def test_no_protobuf_without_proto_files(tmp_path: Path) -> None:
    """No protobuf framework when no .proto files exist."""
    from hypergumbo_core.profile import _detect_protobuf

    (tmp_path / "app.py").write_text("print('hello')\n")

    detected = _detect_protobuf(tmp_path)
    assert detected == []


def test_detects_grpc_go_framework(tmp_path: Path) -> None:
    """gRPC detected from Go go.mod dependency."""
    from hypergumbo_core.profile import _detect_go_frameworks

    (tmp_path / "go.mod").write_text(
        "module example.com/myapp\n\nrequire google.golang.org/grpc v1.60.0\n"
    )

    detected = _detect_go_frameworks(tmp_path)
    assert "grpc" in detected


def test_detects_grpc_python_framework(tmp_path: Path) -> None:
    """gRPC detected from Python requirements."""
    from hypergumbo_core.profile import _detect_python_frameworks

    (tmp_path / "requirements.txt").write_text("grpcio==1.60.0\n")

    detected = _detect_python_frameworks(tmp_path)
    assert "grpc" in detected


def test_detects_grpc_java_framework(tmp_path: Path) -> None:
    """gRPC detected from Java pom.xml dependency."""
    from hypergumbo_core.profile import _detect_java_frameworks

    (tmp_path / "pom.xml").write_text("""<?xml version="1.0"?>
<project>
    <dependencies>
        <dependency>
            <groupId>io.grpc</groupId>
            <artifactId>grpc-core</artifactId>
        </dependency>
    </dependencies>
</project>"""
    )

    detected = _detect_java_frameworks(tmp_path)
    assert "grpc" in detected
