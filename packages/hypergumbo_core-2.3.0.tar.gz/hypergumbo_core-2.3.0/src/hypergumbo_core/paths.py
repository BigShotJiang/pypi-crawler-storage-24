# SPDX-License-Identifier: AGPL-3.0-or-later
"""Centralized path handling utilities for hypergumbo.

This module provides consistent path normalization and comparison functions
used throughout the codebase. All paths stored in Symbol IDs, Symbol.path,
and UsageContext.path should be normalized using these utilities.

Key design decisions:
- Paths use forward slashes (/) regardless of OS
- Paths are stored relative to repo_root when possible
- Path comparisons handle mixed formats gracefully
"""

from pathlib import Path
from typing import Any, Dict, Optional


def normalize_path(path: str | Path) -> str:
    """Normalize a path to use forward slashes.

    Converts backslashes to forward slashes for consistent storage and comparison.
    Does NOT resolve symlinks or make paths absolute/relative.

    Args:
        path: A file path as string or Path object

    Returns:
        Path string with forward slashes
    """
    return str(path).replace("\\", "/")


def to_relative_path(path: str | Path, repo_root: str | Path) -> str:
    """Convert a path to be relative to repo_root.

    Args:
        path: Absolute or relative file path
        repo_root: Root directory to make path relative to

    Returns:
        Normalized relative path (forward slashes, no leading ./)

    Raises:
        ValueError: If path is not under repo_root
    """
    path_obj = Path(path).resolve()
    root_obj = Path(repo_root).resolve()

    try:
        relative = path_obj.relative_to(root_obj)
        return normalize_path(relative)
    except ValueError:
        # Path is not under repo_root - return as-is but normalized
        return normalize_path(path)


def paths_match(path1: str, path2: str) -> bool:
    """Check if two paths refer to the same location.

    Handles different path formats (absolute/relative, slash directions).

    Args:
        path1: First path to compare
        path2: Second path to compare

    Returns:
        True if paths match after normalization
    """
    norm1 = normalize_path(path1)
    norm2 = normalize_path(path2)

    # Exact match after normalization
    if norm1 == norm2:
        return True

    # Check if one is a suffix of the other at a directory boundary
    # This handles comparing "/home/user/repo/src/main.py" with "src/main.py"
    return path_ends_with(norm1, norm2) or path_ends_with(norm2, norm1)


def path_ends_with(full_path: str, suffix: str) -> bool:
    """Check if full_path ends with suffix at a directory boundary.

    This ensures we don't match partial filenames:
    - "src/main.py" matches suffix "main.py" ✓
    - "src/main.py" matches suffix "src/main.py" ✓
    - "src/domain.py" does NOT match suffix "main.py" ✓

    Args:
        full_path: The complete path to check
        suffix: The path suffix to look for

    Returns:
        True if full_path ends with suffix at a directory boundary
    """
    norm_path = normalize_path(full_path)
    norm_suffix = normalize_path(suffix).lstrip("/")

    if not norm_suffix:
        return False

    # Exact match
    if norm_path == norm_suffix:
        return True

    # Suffix match at directory boundary
    # Ensure the character before the suffix is a /
    with_slash = "/" + norm_suffix
    return norm_path.endswith(with_slash)


def get_filename(path: str) -> str:
    """Extract the filename from a path.

    Args:
        path: A file path

    Returns:
        The filename (last component of the path)
    """
    normalized = normalize_path(path)
    return normalized.rsplit("/", 1)[-1] if "/" in normalized else normalized


def is_under_directory(path: str, directory: str) -> bool:
    """Check if path is under a given directory.

    Args:
        path: File path to check
        directory: Directory name to look for (e.g., "tests", "test")

    Returns:
        True if any component of path matches directory name
    """
    normalized = normalize_path(path)
    parts = normalized.split("/")
    return directory.lower() in [p.lower() for p in parts[:-1]]  # Exclude filename


def is_utility_file(path: str) -> bool:
    """Check if a path looks like a utility/example/documentation file.

    Used for deprioritizing utility code in entrypoint ranking. These are
    files that exist to demonstrate or document the main codebase, not
    production code that should be navigated to.

    Matches files in directories:
    - docs_src/, docs/, documentation/ (documentation source)
    - examples/, example/, samples/ (example code)
    - scripts/, tools/, bin/ (utility scripts)
    - dev/, contrib/, hack/, devel*/ (dev tooling / contributor scripts)
    - benchmarks/, benchmark/, bench/ (performance tests)

    Args:
        path: File path to check

    Returns:
        True if the path appears to be a utility file
    """
    normalized = normalize_path(path)
    path_parts = normalized.split("/")

    # Always-utility: these names are unambiguously non-production
    # regardless of where they appear in the path.
    utility_dirs = {
        # Documentation
        "docs_src", "docs", "documentation", "doc",
        # Examples
        "examples", "example", "samples", "sample", "demos", "demo",
        # Scripts
        "scripts",
        # Contrib (e.g., Kubernetes contrib/ dirs)
        "contrib", "hack",
        # Build systems
        "vcbuild", "cmake",
        # Benchmarks
        "benchmarks", "benchmark", "benches", "bench", "perf",
        # Dev environment (e.g., Grafana devenv/)
        "devenv",
    }

    # Ambiguous names: at the project root these are tooling directories
    # (e.g., dev/check_providers.py, tools/build.py, bin/run.sh), but
    # inside source roots they are legitimate modules (e.g.,
    # src/dev/gates.rs, src/utils/helpers.py, src/bin/main.rs).
    _AMBIGUOUS_UTILITY_DIRS = {"dev", "tools", "bin", "utils", "utilities"}
    _SOURCE_ROOTS = {"src", "lib", "app", "crates", "packages"}
    seen_source_root = False

    for part in path_parts[:-1]:  # Exclude filename
        lower = part.lower()
        if lower in _SOURCE_ROOTS:
            seen_source_root = True
        if lower in utility_dirs:
            return True
        # Ambiguous dirs are utility only at project root
        if lower in _AMBIGUOUS_UTILITY_DIRS and not seen_source_root:
            return True
        # devel-common/, devel-tools/, etc. — CI/dev tooling directories
        if lower.startswith("devel"):
            return True

    # Filename-level build script detection:
    # Cargo's build.rs is a compile-time build script, not user-facing code.
    filename = path_parts[-1].lower() if path_parts else ""
    if filename == "build.rs":
        return True

    # Go codegen scripts: gen.go, generate.go, *_gen.go, *_generate.go
    # These are code generation programs, not production application code.
    # Scoped to .go files to avoid false positives in other languages.
    if filename.endswith(".go") and (
        filename in ("gen.go", "generate.go")
        or filename.endswith("_gen.go")
        or filename.endswith("_generate.go")
    ):
        return True

    return False


# Infrastructure directory names that indicate internal plumbing, not
# developer-facing API.  Exports from these paths are dampened in
# entrypoint ranking when semantic entrypoints (routes, commands) exist.
_INFRASTRUCTURE_DIRS = frozenset({
    "telemetry", "metrics", "instrumentation",
    "logging", "logger", "loggers",
    "tracing", "observability",
    "internal",
})


def is_infrastructure_path(path: str) -> bool:
    """Check if a path is in an infrastructure directory.

    Infrastructure directories contain internal plumbing (telemetry, logging,
    metrics, tracing) that is production code but not developer-facing API.
    In gemini-cli, 77 of 111 entrypoints were telemetry exports from
    packages/core/src/telemetry/*.ts — internal infrastructure that dominated
    the entrypoint list over actual API classes.

    Args:
        path: File path to check

    Returns:
        True if any directory component matches an infrastructure pattern
    """
    normalized = normalize_path(path)
    parts = normalized.split("/")
    return any(part.lower() in _INFRASTRUCTURE_DIRS for part in parts[:-1])


def is_test_file(path: str) -> bool:
    """Check if a path looks like a test file.

    Used for filtering and deprioritizing test code in analysis results.

    Matches:
    - Files starting with test_ or test- or ending with _test.* (py/js/ts/go)
    - Files starting with spec_ or ending with _spec.* or .spec.*
    - Files ending with .test.* (e.g., main.test.py, main.test.js)
    - Go test files (*_test.go)
    - Mock/fake files (*_mock.*, *_fake.*, fake_*.*, mock_*.*)
    - Files in tests/, test/, t/, spec/, fakes/, mocks/, fixtures/ directories

    Args:
        path: File path to check

    Returns:
        True if the path appears to be a test file
    """
    filename = get_filename(path)
    filename_lower = filename.lower()

    # Test patterns with _test suffix or test- prefix (any language)
    if filename.startswith("test_"):
        return True
    # Hyphen-separated test prefix: test-reach.c, test-date.c, test-parse.c
    # Common in C projects. Check for "test-" followed by non-empty string.
    if filename_lower.startswith("test-"):
        return True
    if "_test." in filename_lower:  # Matches _test.py, _test.js, _test.ts, _test.go
        return True

    # Test patterns with .test. suffix (e.g., main.test.py, main.test.js)
    if ".test." in filename_lower:
        return True

    # Spec patterns
    if filename.startswith("spec_") or "_spec." in filename_lower:
        return True
    if ".spec." in filename_lower:  # Matches main.spec.js, main.spec.ts
        return True

    # Rust co-located test modules: tests.rs and testonly.rs live alongside
    # production code (e.g., core/lib/dal/src/consensus/tests.rs).  These are
    # test-only modules that should be excluded from production slices.
    if filename_lower in ("tests.rs", "testonly.rs"):
        return True

    # Mock/fake filename patterns (any language)
    name_without_ext = filename_lower.rsplit(".", 1)[0] if "." in filename_lower else filename_lower
    if name_without_ext.endswith("_mock") or name_without_ext.endswith("_fake"):
        return True
    if name_without_ext.startswith("mock_") or name_without_ext.startswith("fake_"):
        return True

    # Directory patterns - test and mock directories
    normalized = normalize_path(path)
    path_parts = normalized.split("/")
    test_dirs = {
        "tests", "test", "t", "__tests__",  # Test directories
        "testing", "testsuite",  # Go/Java convention (e.g., keycloak testsuite/)
        "fakes", "mocks", "testfakes", "testmocks",  # Mock directories
        "fixtures", "testdata", "testutils", "testutil",  # Test support directories
        "testhelper", "testhelpers",  # Test helper directories
        "fv", "harnesses",  # Formal verification / test harness directories
        "bench", "benches", "benchmark", "benchmarks",  # Benchmark directories
    }
    # Also match compound names like "transportfakes" that end with "fakes"/"mocks",
    # directories starting with "test-" (test-artifacts, test-fixtures, test-data),
    # and directories starting with "testsuite" (testsuite-providers, etc.).
    for part in path_parts:
        part_lower = part.lower()
        if part_lower in test_dirs:
            return True
        if part_lower.endswith("fakes") or part_lower.endswith("mocks"):
            return True
        if part_lower.startswith("test-") or part_lower.startswith("testsuite"):
            return True

    # spec/ only matches as the first path component (Ruby RSpec convention).
    # Nested spec/ dirs (e.g., airflow/listeners/spec/) are often production
    # interface definitions, not tests.
    if path_parts and path_parts[0].lower() == "spec":
        return True

    return False


# Annotation names that indicate a test function/method, matched case-sensitively.
# Covers Rust (#[test], #[cfg(test)], #[tokio::test]), Java/Kotlin (@Test,
# @org.junit.Test, @org.junit.jupiter.api.Test), and C# ([TestMethod],
# [Fact], [Theory]).
_TEST_ANNOTATION_NAMES = frozenset({
    "test", "Test",
    "tokio::test", "actix_rt::test", "async_std::test",
    "org.junit.Test", "org.junit.jupiter.api.Test",
    "TestMethod", "Fact", "Theory",
})


def _has_test_annotation(decorators: list[Dict[str, Any]]) -> bool:
    """Check if any decorator/annotation indicates a test function.

    Matches exact annotation names (e.g., ``#[test]``, ``@Test``) and also
    the Rust ``#[cfg(test)]`` pattern where ``cfg`` has ``"test"`` as an arg.
    """
    for dec in decorators:
        name = dec.get("name", "")
        if name in _TEST_ANNOTATION_NAMES:
            return True
        # Rust #[cfg(test)] — "cfg" with "test" in args
        if name == "cfg" and "test" in dec.get("args", []):
            return True
    return False


def is_test_node(path: str, meta: Optional[Dict[str, Any]]) -> bool:
    """Check if a node is test code, using both file path and annotations.

    Extends ``is_test_file`` by also consulting the node's metadata for
    language-specific test annotations. This catches:

    - Rust ``#[test]``, ``#[cfg(test)]``, ``#[tokio::test]`` functions
      inside non-test files (e.g., ``src/lib.rs``)
    - Java ``@Test`` / ``@org.junit.Test`` methods in production paths
    - C# ``[TestMethod]`` / ``[Fact]`` attributes

    Args:
        path: File path of the node.
        meta: Node metadata dict (may contain ``decorators`` or ``annotations``
              lists). None or empty dict means no annotation data.

    Returns:
        True if the node is test code (by path or by annotation).
    """
    if is_test_file(path):
        return True

    if not meta:
        return False

    # Check both 'decorators' and 'annotations' keys — different analyzers
    # use different names for the same concept.
    for key in ("decorators", "annotations"):
        annotations = meta.get(key)
        if annotations and _has_test_annotation(annotations):
            return True

    return False
