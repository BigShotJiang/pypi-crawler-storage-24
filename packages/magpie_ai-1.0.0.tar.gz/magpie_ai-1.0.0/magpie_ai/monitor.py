"""
Decorator for monitoring function execution.

Supports two modes:

- ``type="chat"`` (default): For LLM chat functions with message arrays.
  Automatically extracts tokens, calculates costs, and validates output schemas.

- ``type="completion"``: For any arbitrary function (API calls, SDK calls, DB queries).
  Serializes inputs/outputs generically. No automatic token extraction or cost calculation.

Usage::

    # Chat mode (default)
    @magpie_ai.monitor(project_id="my-project", model="gpt-4")
    def chat(messages: list):
        return openai.chat.completions.create(model="gpt-4", messages=messages)

    # Completion mode
    @magpie_ai.monitor(project_id="my-project", type="completion")
    def call_api(user_id: str):
        return requests.get(f"https://api.example.com/users/{user_id}").json()
"""

import functools
import json
import threading
import atexit
from concurrent.futures import ThreadPoolExecutor
from typing import Callable, Dict, Any, Literal, Optional, Type, TypeVar, Union, cast
from datetime import datetime
import uuid
import inspect

from magpie_ai.client import get_client
from magpie_ai.context import get_context_metadata
from magpie_ai.pii import PIIDetector, get_detector
from magpie_ai.content_moderation import (
    ContentModerator,
    ContentModerationError,
    ModerationAction,
    get_moderator,
)
from magpie_ai.schema_guard import (
    SchemaValidationError,
    validate_output_schema,
)
from magpie_ai.defaults import VLLM_URL, VLLM_MODEL
from magpie_ai.pricing import calculate_costs, get_context_utilization
from magpie_ai.token_extraction import (
    extract_tokens_from_response,
    extract_text_from_response,
)

F = TypeVar("F", bound=Callable[..., Any])

# Track active logging threads to wait for them on exit
_active_threads: list[threading.Thread] = []
_threads_lock = threading.Lock()

# Thread pool for parallel processing (PII + content moderation)
_executor: Optional[ThreadPoolExecutor] = None


def _validate_monitor_params(
    project_id: Optional[str],
    execution_type: str,
    custom: Optional[Dict[str, Any]],
    model: Optional[str],
    input_token_price: Optional[float],
    output_token_price: Optional[float],
    capture_input: bool = True,
    capture_output: bool = True,
    trace_id: Optional[str] = None,
    pii: bool = False,
    action: Optional[str] = None,
    llm_url: str = VLLM_URL,
    llm_model: str = VLLM_MODEL,
    output_schema: Any = None,
) -> None:
    """Validate monitor decorator parameters."""
    # Required parameters
    if not project_id or not isinstance(project_id, str):
        raise ValueError("project_id is required and must be a non-empty string")

    # Type parameter
    if execution_type not in ("chat", "completion"):
        raise ValueError("type must be 'chat' or 'completion'")

    # Type checks for boolean parameters
    if not isinstance(capture_input, bool):
        raise TypeError("capture_input must be a boolean")

    if not isinstance(capture_output, bool):
        raise TypeError("capture_output must be a boolean")

    if not isinstance(pii, bool):
        raise TypeError("pii must be a boolean")

    # Action parameter validation
    if action is not None and action not in ("block", "flag"):
        raise ValueError("action must be None, 'block', or 'flag'")

    # Schema requires action
    if output_schema is not None and action is None:
        raise ValueError("action must be 'block' or 'flag' when output_schema is provided")

    # Optional string parameters
    if trace_id is not None and not isinstance(trace_id, str):
        raise TypeError("trace_id must be a string")

    if trace_id is not None and not trace_id.strip():
        raise ValueError("trace_id must be a non-empty string if provided")

    if custom is not None and not isinstance(custom, dict):
        raise TypeError("custom parameter must be a dictionary")

    # Model name validation
    if model is not None:
        if not isinstance(model, str):
            raise TypeError("model must be a string")
        if not model.strip():
            raise ValueError("model must be a non-empty string if provided")

    # Pricing validation: either use model name or explicit prices, not both
    has_model = model is not None
    has_explicit_pricing = (input_token_price is not None) or (output_token_price is not None)

    if has_model and has_explicit_pricing:
        raise ValueError(
            "Cannot specify both 'model' and explicit pricing parameters. "
            "Use either model='gpt-4' OR input_token_price/output_token_price, not both."
        )

    if input_token_price is not None and not isinstance(input_token_price, (int, float)):
        raise TypeError("input_token_price must be a number")

    if output_token_price is not None and not isinstance(output_token_price, (int, float)):
        raise TypeError("output_token_price must be a number")

    if input_token_price is not None and input_token_price < 0:
        raise ValueError("input_token_price must be non-negative")

    if output_token_price is not None and output_token_price < 0:
        raise ValueError("output_token_price must be non-negative")

    # LLM URL/model validation (required when pii or action enabled)
    if not isinstance(llm_url, str) or not llm_url.strip():
        raise ValueError("llm_url must be a non-empty string")

    if not isinstance(llm_model, str) or not llm_model.strip():
        raise ValueError("llm_model must be a non-empty string")

    # Schema Guard validation
    if output_schema is not None:
        # Check it's a Pydantic BaseModel class or a dict (JSON Schema)
        is_pydantic = False
        try:
            from pydantic import BaseModel

            is_pydantic = isinstance(output_schema, type) and issubclass(output_schema, BaseModel)
        except ImportError:
            pass

        if not is_pydantic and not isinstance(output_schema, dict):
            raise TypeError(
                "output_schema must be a Pydantic BaseModel class or a JSON Schema dict"
            )


def _get_executor() -> ThreadPoolExecutor:
    """Get or create the shared thread pool executor."""
    global _executor
    if _executor is None:
        _executor = ThreadPoolExecutor(max_workers=32, thread_name_prefix="magpie_ai_")
    return _executor


def _wait_for_logging_threads():
    """Wait for all active logging threads to complete before exit."""
    global _executor
    try:
        with _threads_lock:
            threads_to_wait = list(_active_threads)

        for thread in threads_to_wait:
            try:
                thread.join(timeout=2.0)  # Wait max 2 seconds per thread
            except Exception:
                pass  # Ignore errors during shutdown

        # Shutdown executor
        if _executor:
            _executor.shutdown(wait=True, cancel_futures=False)
    except Exception:
        pass  # Ignore all errors during interpreter shutdown


# Register cleanup function to run on exit
atexit.register(_wait_for_logging_threads)


def monitor(
    project_id: str,
    type: Literal["chat", "completion"] = "chat",
    custom: Optional[Dict[str, Any]] = None,
    capture_input: bool = True,
    capture_output: bool = True,
    trace_id: Optional[str] = None,
    pii: bool = False,
    action: Optional[Literal["block", "flag"]] = None,
    llm_url: str = VLLM_URL,
    llm_model: str = VLLM_MODEL,
    model: Optional[str] = None,
    input_token_price: Optional[float] = None,
    output_token_price: Optional[float] = None,
    output_schema: Optional[Union[Type, Dict[str, Any]]] = None,
) -> Callable[[F], F]:
    """
    Decorator for monitoring function execution.

    Supports two modes via the ``type`` parameter:

    - ``"chat"`` (default): For LLM chat functions with message arrays. Automatically
      extracts tokens from OpenAI/Anthropic responses, calculates costs from model
      pricing, and supports output schema validation (Schema Guard).

    - ``"completion"``: For any arbitrary function — API calls, SDK calls, database
      queries, etc. Serializes inputs/outputs generically. No automatic token extraction
      or cost calculation (use ``input_token_price``/``output_token_price`` for manual
      pricing). Schema validation and content moderation are skipped.

    Both modes support PII detection, custom metadata, and timing.

    Args:
        project_id: Project ID (required).
        type: Execution type — ``"chat"`` for LLM message-based functions,
            ``"completion"`` for arbitrary one-time executions (default: ``"chat"``).
        custom: Developer-provided custom data dict (stored as-is in database).
        capture_input: Whether to capture function inputs for logging (default: True).
        capture_output: Whether to capture function return value for logging (default: True).
        trace_id: Optional trace ID for request correlation. Auto-generated per call if omitted.
        pii: Enable PII detection and redaction on inputs (default: False).
        action: Unified enforcement mode for content moderation and schema guard.
            ``None`` (default): Pure monitoring — no moderation or schema checks.
            ``"block"``: Sync enforcement — input moderation before LLM call, output
            moderation + schema validation after. Raises errors on violations.
            ``"flag"``: Async enforcement — SDK skips moderation, backend Celery worker
            moderates input + output asynchronously. Schema validated locally but
            non-blocking, creates review queue items.
        llm_url: URL of local LLM for PII/moderation (default: ``VLLM_URL`` env or ``http://localhost:1234``).
        llm_model: Model name for PII/moderation LLM (default: ``VLLM_MODEL`` env or ``qwen3-1.7b``).
        model: Model name for automatic pricing lookup (e.g., ``"gpt-4"``, ``"claude-3-sonnet"``).
            Only used in chat mode.
        input_token_price: Explicit input price per 1M tokens. Cannot be combined with ``model``.
        output_token_price: Explicit output price per 1M tokens. Cannot be combined with ``model``.
        output_schema: Pydantic BaseModel class or JSON Schema dict for output validation.
            Only used in chat mode. Requires ``action`` to be set (default: None).

    Raises:
        ValueError: If ``project_id`` is empty, ``type`` is invalid, or pricing config conflicts.
        TypeError: If ``custom`` is not a dict, pricing values are not numeric, or ``output_schema`` is invalid.
        ContentModerationError: If ``action="block"`` and input/output contains critical policy violations.
        SchemaValidationError: If ``action="block"``, ``output_schema`` is set, and output is invalid.

    Examples:
        Chat mode with blocking enforcement::

            @magpie_ai.monitor(project_id="my-project", model="gpt-4", action="block")
            def chat(messages: list):
                return openai.chat.completions.create(model="gpt-4", messages=messages)

        Chat mode with async flagging::

            @magpie_ai.monitor(project_id="my-project", model="gpt-4", action="flag")
            def chat(messages: list):
                return openai.chat.completions.create(model="gpt-4", messages=messages)

        Pure monitoring (no moderation)::

            @magpie_ai.monitor(project_id="my-project", model="gpt-4")
            def chat(messages: list):
                return openai.chat.completions.create(model="gpt-4", messages=messages)

    Note:
        - Supports synchronous and async functions.
        - Fails open — monitoring errors never crash your application.
        - Thread-safe — safe for multi-threaded environments.
    """
    # Validate all parameters upfront
    _validate_monitor_params(
        project_id=project_id,
        execution_type=type,
        custom=custom,
        model=model,
        input_token_price=input_token_price,
        output_token_price=output_token_price,
        capture_input=capture_input,
        capture_output=capture_output,
        trace_id=trace_id,
        pii=pii,
        action=action,
        llm_url=llm_url,
        llm_model=llm_model,
        output_schema=output_schema,
    )

    # Capture decorator params for closures below
    _d_project_id = project_id
    _d_execution_type = type
    _d_custom = custom
    _d_capture_input = capture_input
    _d_capture_output = capture_output
    _d_trace_id = trace_id
    _d_pii_enabled = pii
    _d_action = action
    _d_llm_url = llm_url
    _d_llm_model = llm_model
    _d_model = model
    _d_input_token_price = input_token_price
    _d_output_token_price = output_token_price
    _d_output_schema = output_schema

    def decorator(func: F) -> F:
        if inspect.iscoroutinefunction(func):

            @functools.wraps(func)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                return await _execute_monitored_async(
                    func=func,
                    args=args,
                    kwargs=kwargs,
                    project_id=_d_project_id,
                    execution_type=_d_execution_type,
                    custom=_d_custom,
                    capture_input=_d_capture_input,
                    capture_output=_d_capture_output,
                    trace_id=_d_trace_id,
                    pii_enabled=_d_pii_enabled,
                    action=_d_action,
                    llm_url=_d_llm_url,
                    llm_model=_d_llm_model,
                    model=_d_model,
                    input_token_price=_d_input_token_price,
                    output_token_price=_d_output_token_price,
                    output_schema=_d_output_schema,
                )

            return cast(F, async_wrapper)
        else:

            @functools.wraps(func)
            def wrapper(*args: Any, **kwargs: Any) -> Any:
                return _execute_monitored(
                    func=func,
                    args=args,
                    kwargs=kwargs,
                    project_id=_d_project_id,
                    execution_type=_d_execution_type,
                    custom=_d_custom,
                    capture_input=_d_capture_input,
                    capture_output=_d_capture_output,
                    trace_id=_d_trace_id,
                    pii_enabled=_d_pii_enabled,
                    action=_d_action,
                    llm_url=_d_llm_url,
                    llm_model=_d_llm_model,
                    model=_d_model,
                    input_token_price=_d_input_token_price,
                    output_token_price=_d_output_token_price,
                    output_schema=_d_output_schema,
                )

            return cast(F, wrapper)

    return decorator


def _execute_monitored(
    func: Callable,
    args: tuple,
    kwargs: dict,
    project_id: str,
    execution_type: Literal["chat", "completion"],
    custom: Optional[Dict[str, Any]],
    capture_input: bool,
    capture_output: bool,
    trace_id: Optional[str],
    pii_enabled: bool,
    action: Optional[str],
    llm_url: str,
    llm_model: str,
    model: Optional[str],
    input_token_price: Optional[float],
    output_token_price: Optional[float],
    output_schema: Any = None,
) -> Any:
    """
    Execute function with monitoring.

    Thread-safe implementation that:
    1. Runs PII detection/redaction and content moderation in parallel (if enabled)
    2. Captures input arguments
    3. Executes the wrapped function
    4. Captures output
    5. Validates metadata
    6. Sends async log to backend

    Behavior varies by ``execution_type``:
    - ``"chat"``: Extracts tokens from LLM responses, calculates costs, runs schema validation.
    - ``"completion"``: Serializes inputs/outputs generically, skips token extraction and schema validation.

    Always fails open - never raises exceptions related to monitoring.
    """
    is_completion = execution_type == "completion"
    client = get_client()

    # Derive internal flags from action
    content_moderation_enabled = action in ("block", "flag")
    sync_moderation = action == "block"

    # Get context metadata if present
    context_meta = get_context_metadata()

    # Use context project_id if decorator doesn't have one
    effective_project_id = project_id
    if context_meta and context_meta.project_id and not project_id:
        effective_project_id = context_meta.project_id

    # Use context trace_id if decorator doesn't have one
    effective_trace_id = trace_id
    if context_meta and context_meta.trace_id and not trace_id:
        effective_trace_id = context_meta.trace_id

    # Generate trace_id if still None
    execution_trace_id = effective_trace_id or str(uuid.uuid4())

    # ============================================================
    # PARALLEL PROCESSING: PII Detection + Content Moderation
    # ============================================================
    # Both operations are I/O bound (LLM API calls), so running
    # them in parallel significantly reduces latency when both
    # are enabled. Only runs sync moderation in block mode.
    # In flag mode, moderation is handled async by backend Celery.
    # ============================================================

    pii_info: Optional[Dict[str, Any]] = None
    moderation_info: Optional[Dict[str, Any]] = None
    exec_metadata: Optional[Dict[str, Any]] = None
    original_args = args
    original_kwargs = kwargs
    input_was_blocked = False  # Track if input was blocked
    input_block_error: Optional[ContentModerationError] = (
        None  # Store the error to re-raise after logging
    )

    # Initialize status and error_message early so exception handlers can set them
    status = "success"
    error_message: Optional[str] = None

    # Initialize moderation, pii, and schema validation info before processing block
    moderation_info = None
    pii_info = None
    schema_validation_info: Optional[Dict[str, Any]] = None
    schema_block_error: Optional[SchemaValidationError] = None

    # Extract text from inputs for processing
    input_text: str
    if is_completion:
        input_text = _extract_text_for_analysis(args, kwargs)
    else:
        input_text = _extract_input_text(args, kwargs)

    # Run sync pre-processing: PII always, content moderation only in block mode
    run_sync_moderation = sync_moderation and not is_completion

    if pii_enabled or run_sync_moderation:
        try:
            if pii_enabled and run_sync_moderation:
                # PARALLEL EXECUTION: Run both in parallel for efficiency
                args, kwargs, pii_info, moderation_info = _process_parallel(
                    args=args,
                    kwargs=kwargs,
                    input_text=input_text,
                    project_id=effective_project_id,
                    llm_url=llm_url,
                    llm_model=llm_model,
                )
            elif pii_enabled:
                # PII only
                args, kwargs, pii_info = _process_pii_only(
                    args=args, kwargs=kwargs, llm_url=llm_url, llm_model=llm_model
                )
            else:
                # Content moderation only (block mode)
                moderation_info = _process_moderation_only(
                    input_text=input_text,
                    project_id=effective_project_id,
                    llm_url=llm_url,
                    llm_model=llm_model,
                )

            # Add processing info to metadata
            if exec_metadata is None:
                exec_metadata = {}
            if pii_info:
                exec_metadata["pii_detection"] = pii_info
            if moderation_info:
                exec_metadata["content_moderation"] = moderation_info

            # ============================================================
            # SYNC INPUT MODERATION (block mode only):
            # Block on critical violations before LLM call
            # ============================================================
            if run_sync_moderation and moderation_info:
                severity = moderation_info.get("severity", "low")
                blocked = moderation_info.get("blocked", False)
                if severity == "critical" or blocked:
                    input_was_blocked = True
                    from magpie_ai.content_moderation import ModerationResult

                    mod_result = ModerationResult(
                        is_safe=moderation_info.get("is_safe", False),
                        action=ModerationAction(moderation_info.get("action", "block")),
                        violations=[],
                        raw_response=None,
                        error=moderation_info.get("error"),
                    )
                    raise ContentModerationError(
                        f"Input blocked due to policy violations: "
                        f"{moderation_info.get('violated_policies', [])}",
                        mod_result,
                    )

        except ContentModerationError as e:
            input_was_blocked = True
            input_block_error = e
            status = "error"
            error_message = str(e)
        except Exception as e:
            # Fail open - if processing fails, continue with original args
            args = original_args
            kwargs = original_kwargs
            if exec_metadata is None:
                exec_metadata = {}
            exec_metadata["processing_error"] = str(e)

    # Capture input (using potentially redacted args/kwargs) as plaintext
    # Note: This is for logging the processed/redacted input, not the original
    captured_input_text: Optional[str] = None
    if capture_input:
        try:
            if is_completion:
                captured_input_text = _serialize_input(func, args, kwargs)
            else:
                captured_input_text = _capture_input_as_text(func, args, kwargs)
        except Exception:
            # Fail open - continue without input capture
            captured_input_text = None

    # Execute function with timing
    started_at = datetime.utcnow()
    output_text: Optional[str] = None
    result: Any = None
    input_tokens: Optional[int] = None
    output_tokens: Optional[int] = None
    context_utilization: float = 0.0
    input_cost: float = 0.0
    output_cost: float = 0.0

    try:
        # Execute the actual function
        result = func(*args, **kwargs)

        # Capture output as plaintext
        if capture_output:
            try:
                if is_completion:
                    output_text = _serialize_output(result)
                else:
                    output_text = extract_text_from_response(result)
                    if not output_text:
                        output_text = _safe_str(result)[:2000]
            except Exception:
                output_text = None

        # Token extraction and cost calculation
        if is_completion:
            # Completion mode: use manually-provided values only
            if input_token_price is not None and output_token_price is not None:
                # User provided explicit pricing — estimate tokens from text length
                try:
                    if input_text:
                        input_tokens = len(input_text) // 4  # rough estimate
                    if output_text:
                        output_tokens = len(output_text) // 4
                    if input_tokens and output_tokens:
                        input_cost = (input_tokens / 1_000_000) * input_token_price
                        output_cost = (output_tokens / 1_000_000) * output_token_price
                except Exception:
                    pass
        else:
            # Chat mode: extract tokens from LLM response object
            try:
                input_tokens, output_tokens = extract_tokens_from_response(
                    result, input_text=input_text
                )

                if input_tokens and output_tokens:
                    input_cost, output_cost, _ = calculate_costs(
                        input_tokens=input_tokens,
                        output_tokens=output_tokens,
                        model=model,
                        input_price_per_1m=input_token_price,
                        output_price_per_1m=output_token_price,
                    )

                    context_utilization = get_context_utilization(
                        input_tokens=input_tokens, output_tokens=output_tokens, model=model
                    )
            except Exception:
                pass

        # ============================================================
        # SYNC OUTPUT MODERATION (block mode only, chat mode only)
        # ============================================================
        if not is_completion and sync_moderation and output_text:
            try:
                moderator = get_moderator(
                    project_id=effective_project_id, llm_url=llm_url, model=llm_model
                )
                output_mod_result = moderator.moderate(output_text, block_on_violation=True)
                output_moderation_info = output_mod_result.to_dict()
                if exec_metadata is None:
                    exec_metadata = {}
                exec_metadata["output_moderation"] = output_moderation_info
            except ContentModerationError:
                raise
            except Exception:
                pass  # Fail open

        # ============================================================
        # SCHEMA GUARD: Validate output against schema (chat mode only)
        # ============================================================
        if not is_completion and output_schema is not None and output_text:
            try:
                validation_result = validate_output_schema(output_text, output_schema)
                schema_validation_info = validation_result.to_dict()
                schema_validation_info["action"] = action

                if not validation_result.valid:
                    if action == "block":
                        status = "error"
                        error_msg = (
                            f"Schema Guard: Output does not match {validation_result.schema_name}. "
                            f"Errors: {'; '.join(validation_result.errors)}"
                        )
                        error_message = error_msg
                        schema_block_error = SchemaValidationError(
                            message=error_msg,
                            output_text=output_text,
                            schema_name=validation_result.schema_name,
                            validation_errors=validation_result.errors,
                        )
                    # flag mode: schema validated but non-blocking (included in log)
            except SchemaValidationError:
                raise
            except Exception:
                pass

        return result

    except Exception as e:
        # Capture error information
        status = "error"
        error_message = str(e)
        raise  # Re-raise to preserve original behavior

    finally:
        # Always send log, even if function failed
        completed_at = datetime.utcnow()
        total_latency_ms = int((completed_at - started_at).total_seconds() * 1000)

        # For blocked inputs, set costs to zero since LLM was never called
        # (moderation LLM is self-hosted, so no cost to client)
        if input_was_blocked:
            input_tokens = 0
            output_tokens = 0
            input_cost = 0.0
            output_cost = 0.0
            context_utilization = 0.0

        # For blocked inputs, send log synchronously to get log_id for async task
        # For other cases, send asynchronously as before
        log_id = None

        # Build common log kwargs
        log_kwargs = dict(
            project_id=effective_project_id,
            trace_id=execution_trace_id,
            input=captured_input_text,
            output=output_text if (not input_was_blocked or schema_block_error) else None,
            custom=custom,
            started_at=started_at,
            completed_at=completed_at,
            total_latency_ms=total_latency_ms,
            status=status,
            error_message=error_message,
            function_name=func.__name__,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            context_utilization=context_utilization,
            input_cost=input_cost,
            output_cost=output_cost,
            pii_info=pii_info,
            moderation_info=moderation_info,
            schema_validation=schema_validation_info,
            execution_type=execution_type,
            action=action,
        )

        if input_was_blocked or schema_block_error:
            # Synchronous send for blocked input/schema
            try:
                client.send_log_sync(**log_kwargs)
            except Exception:
                pass
        else:
            # Asynchronous send for normal cases
            try:
                _send_log_async(client=client, **log_kwargs)
            except Exception:
                pass

        # Re-raise the input block error now that logging is complete
        if input_block_error:
            raise input_block_error

        # Re-raise schema validation error now that logging is complete
        if schema_block_error:
            raise schema_block_error


async def _execute_monitored_async(
    func: Callable,
    args: tuple,
    kwargs: dict,
    project_id: str,
    execution_type: Literal["chat", "completion"],
    custom: Optional[Dict[str, Any]],
    capture_input: bool,
    capture_output: bool,
    trace_id: Optional[str],
    pii_enabled: bool,
    action: Optional[str],
    llm_url: str,
    llm_model: str,
    model: Optional[str],
    input_token_price: Optional[float],
    output_token_price: Optional[float],
    output_schema: Any = None,
) -> Any:
    """
    Async variant of _execute_monitored for async functions.

    Identical to _execute_monitored except the wrapped function is awaited.
    All monitoring logic (PII, moderation, logging) remains synchronous/threaded.
    """
    is_completion = execution_type == "completion"
    client = get_client()

    # Derive internal flags from action
    content_moderation_enabled = action in ("block", "flag")
    sync_moderation = action == "block"

    context_meta = get_context_metadata()

    effective_project_id = project_id
    if context_meta and context_meta.project_id and not project_id:
        effective_project_id = context_meta.project_id

    effective_trace_id = trace_id
    if context_meta and context_meta.trace_id and not trace_id:
        effective_trace_id = context_meta.trace_id

    execution_trace_id = effective_trace_id or str(uuid.uuid4())

    pii_info: Optional[Dict[str, Any]] = None
    moderation_info: Optional[Dict[str, Any]] = None
    exec_metadata: Optional[Dict[str, Any]] = None
    original_args = args
    original_kwargs = kwargs
    input_was_blocked = False
    input_block_error: Optional[ContentModerationError] = None

    status = "success"
    error_message: Optional[str] = None

    moderation_info = None
    pii_info = None
    schema_validation_info: Optional[Dict[str, Any]] = None
    schema_block_error: Optional[SchemaValidationError] = None

    input_text: str
    if is_completion:
        input_text = _extract_text_for_analysis(args, kwargs)
    else:
        input_text = _extract_input_text(args, kwargs)

    run_sync_moderation = sync_moderation and not is_completion

    if pii_enabled or run_sync_moderation:
        try:
            if pii_enabled and run_sync_moderation:
                args, kwargs, pii_info, moderation_info = _process_parallel(
                    args=args,
                    kwargs=kwargs,
                    input_text=input_text,
                    project_id=effective_project_id,
                    llm_url=llm_url,
                    llm_model=llm_model,
                )
            elif pii_enabled:
                args, kwargs, pii_info = _process_pii_only(
                    args=args, kwargs=kwargs, llm_url=llm_url, llm_model=llm_model
                )
            else:
                moderation_info = _process_moderation_only(
                    input_text=input_text,
                    project_id=effective_project_id,
                    llm_url=llm_url,
                    llm_model=llm_model,
                )

            if exec_metadata is None:
                exec_metadata = {}
            if pii_info:
                exec_metadata["pii_detection"] = pii_info
            if moderation_info:
                exec_metadata["content_moderation"] = moderation_info

            if run_sync_moderation and moderation_info:
                severity = moderation_info.get("severity", "low")
                blocked = moderation_info.get("blocked", False)
                if severity == "critical" or blocked:
                    input_was_blocked = True
                    from magpie_ai.content_moderation import ModerationResult

                    mod_result = ModerationResult(
                        is_safe=moderation_info.get("is_safe", False),
                        action=ModerationAction(moderation_info.get("action", "block")),
                        violations=[],
                        raw_response=None,
                        error=moderation_info.get("error"),
                    )
                    raise ContentModerationError(
                        f"Input blocked due to policy violations: "
                        f"{moderation_info.get('violated_policies', [])}",
                        mod_result,
                    )

        except ContentModerationError as e:
            input_was_blocked = True
            input_block_error = e
            status = "error"
            error_message = str(e)
        except Exception as e:
            args = original_args
            kwargs = original_kwargs
            if exec_metadata is None:
                exec_metadata = {}
            exec_metadata["processing_error"] = str(e)

    captured_input_text: Optional[str] = None
    if capture_input:
        try:
            if is_completion:
                captured_input_text = _serialize_input(func, args, kwargs)
            else:
                captured_input_text = _capture_input_as_text(func, args, kwargs)
        except Exception:
            captured_input_text = None

    started_at = datetime.utcnow()
    output_text: Optional[str] = None
    result: Any = None
    input_tokens: Optional[int] = None
    output_tokens: Optional[int] = None
    context_utilization: float = 0.0
    input_cost: float = 0.0
    output_cost: float = 0.0

    try:
        # Await the async function
        result = await func(*args, **kwargs)

        if capture_output:
            try:
                if is_completion:
                    output_text = _serialize_output(result)
                else:
                    output_text = extract_text_from_response(result)
                    if not output_text:
                        output_text = _safe_str(result)[:2000]
            except Exception:
                output_text = None

        if is_completion:
            if input_token_price is not None and output_token_price is not None:
                try:
                    if input_text:
                        input_tokens = len(input_text) // 4
                    if output_text:
                        output_tokens = len(output_text) // 4
                    if input_tokens and output_tokens:
                        input_cost = (input_tokens / 1_000_000) * input_token_price
                        output_cost = (output_tokens / 1_000_000) * output_token_price
                except Exception:
                    pass
        else:
            try:
                input_tokens, output_tokens = extract_tokens_from_response(
                    result, input_text=input_text
                )

                if input_tokens and output_tokens:
                    input_cost, output_cost, _ = calculate_costs(
                        input_tokens=input_tokens,
                        output_tokens=output_tokens,
                        model=model,
                        input_price_per_1m=input_token_price,
                        output_price_per_1m=output_token_price,
                    )

                    context_utilization = get_context_utilization(
                        input_tokens=input_tokens, output_tokens=output_tokens, model=model
                    )
            except Exception:
                pass

        # ============================================================
        # SYNC OUTPUT MODERATION (block mode only, chat mode only)
        # ============================================================
        if not is_completion and sync_moderation and output_text:
            try:
                moderator = get_moderator(
                    project_id=effective_project_id, llm_url=llm_url, model=llm_model
                )
                output_mod_result = moderator.moderate(output_text, block_on_violation=True)
                output_moderation_info = output_mod_result.to_dict()
                if exec_metadata is None:
                    exec_metadata = {}
                exec_metadata["output_moderation"] = output_moderation_info
            except ContentModerationError:
                raise
            except Exception:
                pass  # Fail open

        # ============================================================
        # SCHEMA GUARD: Validate output against schema (chat mode only)
        # ============================================================
        if not is_completion and output_schema is not None and output_text:
            try:
                validation_result = validate_output_schema(output_text, output_schema)
                schema_validation_info = validation_result.to_dict()
                schema_validation_info["action"] = action

                if not validation_result.valid:
                    if action == "block":
                        status = "error"
                        error_msg = (
                            f"Schema Guard: Output does not match {validation_result.schema_name}. "
                            f"Errors: {'; '.join(validation_result.errors)}"
                        )
                        error_message = error_msg
                        schema_block_error = SchemaValidationError(
                            message=error_msg,
                            output_text=output_text,
                            schema_name=validation_result.schema_name,
                            validation_errors=validation_result.errors,
                        )
                    # flag mode: schema validated but non-blocking (included in log)
            except SchemaValidationError:
                raise
            except Exception:
                pass

        return result

    except Exception as e:
        status = "error"
        error_message = str(e)
        raise

    finally:
        completed_at = datetime.utcnow()
        total_latency_ms = int((completed_at - started_at).total_seconds() * 1000)

        if input_was_blocked:
            input_tokens = 0
            output_tokens = 0
            input_cost = 0.0
            output_cost = 0.0
            context_utilization = 0.0

        # Build common log kwargs
        log_kwargs = dict(
            project_id=effective_project_id,
            trace_id=execution_trace_id,
            input=captured_input_text,
            output=output_text if (not input_was_blocked or schema_block_error) else None,
            custom=custom,
            started_at=started_at,
            completed_at=completed_at,
            total_latency_ms=total_latency_ms,
            status=status,
            error_message=error_message,
            function_name=func.__name__,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            context_utilization=context_utilization,
            input_cost=input_cost,
            output_cost=output_cost,
            pii_info=pii_info,
            moderation_info=moderation_info,
            schema_validation=schema_validation_info,
            execution_type=execution_type,
            action=action,
        )

        if input_was_blocked or schema_block_error:
            try:
                client.send_log_sync(**log_kwargs)
            except Exception:
                pass
        else:
            try:
                _send_log_async(client=client, **log_kwargs)
            except Exception:
                pass

        if input_block_error:
            raise input_block_error

        if schema_block_error:
            raise schema_block_error


def _extract_input_text(args: tuple, kwargs: dict) -> str:
    """Extract text content from function arguments for analysis."""
    texts = []

    # Check for 'messages' parameter (common in chat/LLM APIs)
    # Extract the last user message from conversation history
    messages = kwargs.get("messages") or (
        args[1] if len(args) > 1 and isinstance(args[1], list) else None
    )
    if messages and isinstance(messages, list):
        for msg in reversed(messages):
            if isinstance(msg, dict) and msg.get("role") == "user":
                content = msg.get("content", "")
                if isinstance(content, str) and content:
                    texts.append(content)
                    break

    # Check positional args (skip self/cls if present)
    for i, arg in enumerate(args):
        # Skip first arg if it looks like self/cls
        if i == 0 and not isinstance(arg, (str, dict, list)):
            continue
        if isinstance(arg, str):
            texts.append(arg)
        elif isinstance(arg, dict):
            for key in ["prompt", "message", "text", "content", "query", "input"]:
                if key in arg and isinstance(arg[key], str):
                    texts.append(arg[key])

    # Check keyword args
    for key in ["prompt", "message", "text", "content", "query", "input"]:
        if key in kwargs and isinstance(kwargs[key], str):
            texts.append(kwargs[key])

    return " ".join(texts) if texts else str(args) + str(kwargs)


def _process_parallel(
    args: tuple, kwargs: dict, input_text: str, project_id: str, llm_url: str, llm_model: str
) -> tuple[tuple, dict, Optional[Dict], Optional[Dict]]:
    """
    Run PII detection and content moderation in parallel.

    This significantly reduces latency when both features are enabled,
    as both are I/O-bound operations (LLM API calls).

    Returns:
        (processed_args, processed_kwargs, pii_info, moderation_info)
    """
    executor = _get_executor()

    pii_detector = get_detector(llm_url=llm_url, model=llm_model)
    moderator = get_moderator(project_id=project_id, llm_url=llm_url, model=llm_model)

    # Submit both tasks
    pii_future = executor.submit(_run_pii_detection, pii_detector, args, kwargs)
    moderation_future = executor.submit(_run_content_moderation, moderator, input_text)

    # Wait for both to complete
    processed_args, processed_kwargs, pii_info = pii_future.result(timeout=60)
    moderation_info = moderation_future.result(timeout=60)

    return processed_args, processed_kwargs, pii_info, moderation_info


def _run_pii_detection(
    detector: PIIDetector, args: tuple, kwargs: dict
) -> tuple[tuple, dict, Optional[Dict]]:
    """Run PII detection and redaction on inputs."""
    pii_info = None

    # Process positional args
    processed_args = list(args)
    for i, arg in enumerate(args):
        processed_arg, arg_pii_info = detector.process_input(arg)
        processed_args[i] = processed_arg
        if arg_pii_info:
            pii_info = arg_pii_info

    # Process keyword args
    processed_kwargs = kwargs.copy()
    for key, value in kwargs.items():
        processed_value, kwarg_pii_info = detector.process_input(value)
        processed_kwargs[key] = processed_value
        if kwarg_pii_info:
            pii_info = kwarg_pii_info

    return tuple(processed_args), processed_kwargs, pii_info


def _run_content_moderation(moderator: ContentModerator, text: str) -> Optional[Dict]:
    """Run content moderation on input text."""
    try:
        result = moderator.moderate(text, block_on_violation=True)
        return result.to_dict()
    except ContentModerationError as e:
        # Content was blocked - return the result with blocking info
        # The exception contains the ModerationResult with violation details
        result_dict = e.result.to_dict()
        # Mark that blocking occurred
        result_dict["blocked"] = True
        return result_dict


def _process_pii_only(
    args: tuple, kwargs: dict, llm_url: str, llm_model: str
) -> tuple[tuple, dict, Optional[Dict]]:
    """Process only PII detection (synchronous)."""
    detector = get_detector(llm_url=llm_url, model=llm_model)
    return _run_pii_detection(detector, args, kwargs)


def _process_moderation_only(
    input_text: str, project_id: str, llm_url: str, llm_model: str
) -> Optional[Dict]:
    """Process only content moderation (synchronous)."""
    moderator = get_moderator(project_id=project_id, llm_url=llm_url, model=llm_model)
    return _run_content_moderation(moderator, input_text)


def _capture_input_as_text(func: Callable, args: tuple, kwargs: dict) -> str:
    """
    Capture function input as plaintext.

    For class methods with conversation history (messages list),
    extracts only the last user message instead of entire history.
    For simple functions, captures all arguments.

    Returns a string representation suitable for logging.
    """
    try:
        # Try to get function signature
        sig = inspect.signature(func)
        bound_args = sig.bind(*args, **kwargs)
        bound_args.apply_defaults()

        # Build plaintext representation
        parts = []
        for param_name, param_value in bound_args.arguments.items():
            # Skip 'self' parameter for class methods
            if param_name == "self":
                continue

            # Special handling for 'messages' parameter (conversation history)
            if param_name == "messages" and isinstance(param_value, list):
                # Extract only the last user message from conversation
                last_user_msg = None
                for msg in reversed(param_value):
                    if isinstance(msg, dict) and msg.get("role") == "user":
                        last_user_msg = msg.get("content", "")
                        break

                if last_user_msg:
                    parts.append(last_user_msg[:500])
                else:
                    # Fallback if no user message found
                    parts.append(f"messages: {str(param_value)[:200]}")
            elif isinstance(param_value, str):
                parts.append(f"{param_name}: {param_value[:500]}")
            else:
                parts.append(f"{param_name}: {str(param_value)[:500]}")

        return " | ".join(parts) if parts else str(args)

    except Exception:
        # Fallback
        return _safe_str(args)[:1000]


def _safe_str(obj: Any) -> str:
    """Safely convert object to string."""
    try:
        return str(obj)
    except Exception:
        return repr(type(obj))


def _send_log_async(
    client,
    **log_kwargs,
) -> None:
    """
    Send log to backend asynchronously in a background thread.

    Thread-safe implementation that doesn't block the main execution.
    Accepts the same kwargs as client.send_log_sync.
    """

    def send_in_thread():
        try:
            client.send_log_sync(**log_kwargs)
        except Exception:
            pass
        finally:
            try:
                with _threads_lock:
                    if thread in _active_threads:
                        _active_threads.remove(thread)
            except Exception:
                pass

    thread = threading.Thread(target=send_in_thread, daemon=False)

    with _threads_lock:
        _active_threads.append(thread)

    thread.start()


# ============================================================
# Serialization helpers for completion mode
# ============================================================


def _serialize_value(obj: Any, max_length: int = 2000) -> str:
    """Serialize any Python object to a truncated string for logging."""
    try:
        result = json.dumps(obj, default=str)
    except (TypeError, ValueError):
        result = repr(obj)
    if len(result) > max_length:
        return result[:max_length] + "..."
    return result


def _serialize_input(func: Callable, args: tuple, kwargs: dict, max_length: int = 5000) -> str:
    """
    Serialize function inputs generically using ``inspect.signature``.

    Binds args/kwargs to parameter names and serializes each value.
    Falls back to raw string representation on failure.
    """
    try:
        sig = inspect.signature(func)
        bound = sig.bind(*args, **kwargs)
        bound.apply_defaults()
        parts = []
        for name, value in bound.arguments.items():
            if name == "self":
                continue
            parts.append(f"{name}: {_serialize_value(value, 500)}")
        result = " | ".join(parts)
        if len(result) > max_length:
            return result[:max_length] + "..."
        return result
    except Exception:
        return _safe_str(args)[:max_length]


def _serialize_output(result: Any, max_length: int = 5000) -> str:
    """Serialize function return value generically for logging."""
    return _serialize_value(result, max_length)


def _extract_text_for_analysis(args: tuple, kwargs: dict) -> str:
    """
    Extract string values from arbitrary function arguments for PII/moderation analysis.

    Unlike ``_extract_input_text`` (which looks for ``messages[]`` arrays), this
    function handles any argument types by extracting all string values.
    """
    texts: list[str] = []
    for arg in args:
        if isinstance(arg, str):
            texts.append(arg)
        elif isinstance(arg, dict):
            for v in arg.values():
                if isinstance(v, str):
                    texts.append(v)
    for v in kwargs.values():
        if isinstance(v, str):
            texts.append(v)
        elif isinstance(v, dict):
            for inner_v in v.values():
                if isinstance(inner_v, str):
                    texts.append(inner_v)
    return " ".join(texts) if texts else _safe_str(args)[:2000]
