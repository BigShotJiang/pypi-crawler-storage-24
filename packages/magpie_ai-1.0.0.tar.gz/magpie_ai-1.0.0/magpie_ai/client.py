"""
HTTP client for communicating with the Magpie backend.

Provides synchronous and asynchronous methods for sending execution logs.
Features connection pooling, retry with exponential backoff, and fail-open behavior.
"""

import threading
import time
import httpx
from typing import Any, Dict, Optional
from datetime import datetime

from magpie_ai.config import get_config
from magpie_ai.validation import validate_metadata, sanitize_metadata

# Retry configuration
_MAX_RETRIES = 3
_BASE_RETRY_DELAY = 0.1  # 100ms


class MagpieClient:
    """
    Client for Magpie backend API.

    Uses a persistent HTTP client for connection pooling and supports
    retry with exponential backoff for transient failures.
    """

    def __init__(self) -> None:
        self.config = get_config()
        self._sync_client: Optional[httpx.Client] = None
        self._sync_client_lock = threading.Lock()

    def _get_sync_client(self) -> httpx.Client:
        """Get or create persistent synchronous HTTP client with connection pooling."""
        if self._sync_client is None or self._sync_client.is_closed:
            with self._sync_client_lock:
                if self._sync_client is None or self._sync_client.is_closed:
                    self._sync_client = httpx.Client(
                        timeout=self.config.timeout,
                        limits=httpx.Limits(
                            max_connections=20,
                            max_keepalive_connections=10,
                        ),
                    )
        return self._sync_client

    def close(self) -> None:
        """Close the persistent HTTP client and release connections."""
        if self._sync_client and not self._sync_client.is_closed:
            self._sync_client.close()
            self._sync_client = None

    async def send_log(
        self,
        project_id: str,
        input: Optional[Dict[str, Any]] = None,
        output: Optional[Dict[str, Any]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        started_at: Optional[datetime] = None,
        completed_at: Optional[datetime] = None,
        duration_ms: Optional[int] = None,
        status: Optional[str] = None,
        error_message: Optional[str] = None,
        function_name: Optional[str] = None,
        trace_id: Optional[str] = None,
    ) -> bool:
        """
        Send execution log to backend asynchronously.

        Returns True if successful, False otherwise.
        Implements fail-open behavior — won't raise exceptions unless ``fail_open=False``.

        Args:
            project_id: Project ID.
            input: Execution input data.
            output: Execution output data.
            metadata: Developer-provided metadata.
            started_at: Execution start timestamp.
            completed_at: Execution end timestamp.
            duration_ms: Total duration in milliseconds.
            status: Execution status (``"success"`` or ``"error"``).
            error_message: Error message if execution failed.
            function_name: Name of the monitored function.
            trace_id: Request trace ID.

        Returns:
            True if log was sent successfully, False otherwise.
        """
        if not self.config.enabled:
            return True

        if not self.config.is_configured():
            if not self.config.fail_open:
                raise RuntimeError(
                    "Magpie SDK not configured. Set MAGPIE_API_KEY and MAGPIE_BACKEND_URL."
                )
            return False

        try:
            if metadata:
                metadata = sanitize_metadata(metadata)

            validation_result = None
            if metadata and project_id and self.config.backend_url and self.config.api_key:
                validation_result = validate_metadata(
                    metadata=metadata,
                    project_id=project_id,
                    backend_url=self.config.backend_url,
                    api_key=self.config.api_key,
                )

            payload: Dict[str, Any] = {
                "input": input,
                "output": output,
                "metadata": metadata,
                "started_at": started_at.isoformat() if started_at else None,
                "completed_at": completed_at.isoformat() if completed_at else None,
                "duration_ms": duration_ms,
                "status": status,
                "error_message": error_message,
                "function_name": function_name,
                "trace_id": trace_id,
            }

            if validation_result:
                payload["metadata_valid"] = validation_result.is_valid
                if not validation_result.is_valid:
                    payload["validation_errors"] = validation_result.to_dict()

            payload = {k: v for k, v in payload.items() if v is not None}

            async with httpx.AsyncClient(timeout=self.config.timeout) as client:
                response = await client.post(
                    f"{self.config.backend_url}/api/v1/logs/",
                    json=payload,
                    headers={"Authorization": f"Bearer {self.config.api_key}"},
                )
                response.raise_for_status()
                return True

        except httpx.HTTPStatusError as e:
            if self.config.fail_open:
                return False
            raise
        except httpx.TimeoutException:
            if self.config.fail_open:
                return False
            raise
        except Exception:
            if self.config.fail_open:
                return False
            raise

    def send_log_sync(self, **kwargs: Any) -> Optional[str]:
        """
        Send execution log to backend synchronously with retry.

        Uses a persistent HTTP client for connection pooling and retries transient
        failures (5xx, timeouts) with exponential backoff.

        Returns:
            The log ID from the backend response, or None if send failed.
        """
        if not self.config.enabled:
            return None

        if not self.config.is_configured():
            if not self.config.fail_open:
                raise RuntimeError(
                    "Magpie SDK not configured. Set MAGPIE_API_KEY and MAGPIE_BACKEND_URL."
                )
            return None

        try:
            # Extract parameters
            project_id = kwargs.get("project_id")
            input_text = kwargs.get("input")
            output_text = kwargs.get("output")
            custom = kwargs.get("custom")
            started_at = kwargs.get("started_at")
            completed_at = kwargs.get("completed_at")
            total_latency_ms = kwargs.get("total_latency_ms")
            status = kwargs.get("status")
            error_message = kwargs.get("error_message")
            function_name = kwargs.get("function_name")
            trace_id = kwargs.get("trace_id")
            execution_type = kwargs.get("execution_type", "chat")

            # Token and cost metrics
            input_tokens = kwargs.get("input_tokens")
            output_tokens = kwargs.get("output_tokens")
            context_utilization = kwargs.get("context_utilization", 0.0)
            input_cost = kwargs.get("input_cost", 0.0)
            output_cost = kwargs.get("output_cost", 0.0)
            pii_info = kwargs.get("pii_info")
            moderation_info = kwargs.get("moderation_info")
            schema_validation = kwargs.get("schema_validation")
            action = kwargs.get("action")

            # Compute totals
            total_tokens = None
            if input_tokens and output_tokens:
                total_tokens = input_tokens + output_tokens

            total_cost = (input_cost or 0.0) + (output_cost or 0.0)

            # Build payload
            payload: Dict[str, Any] = {
                "project_id": project_id,
                "trace_id": trace_id,
                "input": input_text,
                "output": output_text,
                "custom": custom,
                "started_at": started_at.isoformat() if started_at else None,
                "completed_at": completed_at.isoformat() if completed_at else None,
                "total_latency_ms": total_latency_ms,
                "status": status,
                "error_message": error_message,
                "function_name": function_name,
                "execution_type": execution_type,
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
                "total_tokens": total_tokens,
                "context_utilization": context_utilization,
                "input_cost": input_cost,
                "output_cost": output_cost,
                "total_cost": total_cost,
                "pii_detection": pii_info,
                "content_moderation": moderation_info,
                "schema_validation": schema_validation,
                "action": action,
            }

            payload = {k: v for k, v in payload.items() if v is not None}

            # Send with retry for transient failures
            client = self._get_sync_client()
            for attempt in range(_MAX_RETRIES):
                try:
                    response = client.post(
                        f"{self.config.backend_url}/api/v1/logs/",
                        json=payload,
                        headers={"Authorization": f"Bearer {self.config.api_key}"},
                    )
                    response.raise_for_status()

                    try:
                        response_data = response.json()
                        log_id = response_data.get("id")
                        return log_id if isinstance(log_id, str) else None
                    except Exception:
                        return None

                except (httpx.TimeoutException, httpx.HTTPStatusError) as e:
                    is_retryable = isinstance(e, httpx.TimeoutException) or (
                        isinstance(e, httpx.HTTPStatusError) and e.response.status_code >= 500
                    )
                    if is_retryable and attempt < _MAX_RETRIES - 1:
                        time.sleep(_BASE_RETRY_DELAY * (2**attempt))
                        continue
                    # Final attempt failed or non-retryable error
                    if self.config.fail_open:
                        return None
                    raise

            return None

        except Exception:
            if self.config.fail_open:
                return None
            raise


# Global client instance with thread-safe initialization
_client: Optional[MagpieClient] = None
_client_lock = threading.Lock()


def get_client() -> MagpieClient:
    """Get the global MagpieClient singleton (thread-safe)."""
    global _client
    if _client is None:
        with _client_lock:
            if _client is None:
                _client = MagpieClient()
    return _client
