"""
Magpie SDK — Enterprise LLM middleware for monitoring, content moderation, and metadata tracking.

Provides the ``@monitor`` decorator for capturing LLM execution traces, with support
for both chat (message-based) and completion (one-time execution) modes.

Quick start::

    import magpie_ai

    magpie_ai.configure(api_key="sk_...", backend_url="https://api.magpie.dev")

    # Chat mode (default) — wraps LLM chat functions with message arrays
    @magpie_ai.monitor(project_id="my-project", model="gpt-4")
    def chat(messages: list):
        return openai.chat.completions.create(model="gpt-4", messages=messages)

    # Completion mode — wraps any function (API calls, SDK calls, DB queries, etc.)
    @magpie_ai.monitor(project_id="my-project", type="completion")
    def call_api(user_id: str):
        return requests.get(f"https://api.example.com/users/{user_id}").json()
"""

__version__ = "1.0.0"

# Core APIs
from magpie_ai.monitor import monitor
from magpie_ai.context import context
from magpie_ai.config import configure

# Content Moderation
from magpie_ai.content_moderation import (
    ContentModerationError,
    ModerationResult,
    ModerationAction,
    ModerationSeverity,
    ModerationViolation,
)

# Schema Validation
from magpie_ai.schema_guard import SchemaValidationError, SchemaValidationResult

# Metadata Validation
from magpie_ai.validation import validate_metadata, clear_schema_cache, ValidationResult

# Pricing
from magpie_ai.pricing import get_model_pricing, list_available_models, ModelPricing

__all__ = [
    # Core
    "monitor",
    "context",
    "configure",
    # Content Moderation
    "ContentModerationError",
    "ModerationResult",
    "ModerationAction",
    "ModerationSeverity",
    "ModerationViolation",
    # Schema Validation
    "SchemaValidationError",
    "SchemaValidationResult",
    # Metadata Validation
    "validate_metadata",
    "clear_schema_cache",
    "ValidationResult",
    # Pricing
    "get_model_pricing",
    "list_available_models",
    "ModelPricing",
]
