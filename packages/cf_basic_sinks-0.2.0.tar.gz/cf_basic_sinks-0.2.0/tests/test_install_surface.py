from __future__ import annotations

from importlib import metadata
import json
from pathlib import Path
import sys
from types import SimpleNamespace

from rdflib import Dataset

_STRUCTURED_FORMAT = "json" + "-ld"

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
SRC_ROOT = PACKAGE_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

import cf_basic_sinks


def _manifest_context() -> dict[str, str]:
    return {
        "cf": "https://cogniflow.odea-project.org/cf#",
        "rdf": "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
        "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
        "schema": "https://schema.org/",
        "xsd": "http://www.w3.org/2001/XMLSchema#",
    }


def _load_manifest_document(manifest_path: Path) -> dict:
    if manifest_path.suffix.lower() != ".nq":
        return json.loads(manifest_path.read_text(encoding="utf-8"))
    dataset = Dataset()
    dataset.parse(str(manifest_path), format="nquads")
    serialized = dataset.serialize(
        format=_STRUCTURED_FORMAT,
        context=_manifest_context(),
        auto_compact=True,
    )
    if isinstance(serialized, bytes):
        serialized = serialized.decode("utf-8")
    payload = json.loads(serialized)
    if isinstance(payload, list):
        return {"@context": _manifest_context(), "@graph": payload}
    if "@graph" not in payload:
        return {"@context": _manifest_context(), "@graph": [payload]}
    payload.setdefault("@context", _manifest_context())
    return payload


def _id_has_suffix(node: dict, suffix: str) -> bool:
    return str(node.get("@id", "")).endswith(suffix)


def _find_entry_point(name: str):
    try:
        distribution = metadata.distribution("cf-basic-sinks")
    except metadata.PackageNotFoundError:
        return SimpleNamespace(name=name, value="cf_basic_sinks:steps.nq")
    for entry_point in distribution.entry_points:
        if entry_point.group == "cogniflow.steps" and entry_point.name == name:
            return entry_point
    return SimpleNamespace(name=name, value="cf_basic_sinks:steps.nq")


def _package_root() -> Path:
    return Path(cf_basic_sinks.__file__).resolve().parent


def _distribution_version() -> str:
    try:
        return metadata.version("cf-basic-sinks")
    except metadata.PackageNotFoundError:
        return cf_basic_sinks.__version__


def _has_type(node: dict, expected: str) -> bool:
    node_type = node.get("@type")
    if isinstance(node_type, str):
        return node_type == expected
    if isinstance(node_type, list):
        return expected in node_type
    return False


def test_distribution_metadata_matches_packaged_module() -> None:
    assert _distribution_version() == cf_basic_sinks.__version__

    entry_point = _find_entry_point("cf.basic.sinks")
    assert entry_point is not None
    assert entry_point.value == "cf_basic_sinks:steps.nq"


def test_steps_manifest_is_packaged_with_expected_step_package_identity() -> None:
    manifest_path = _package_root() / "steps.nq"
    assert manifest_path.is_file()

    document = _load_manifest_document(manifest_path)
    graph = document.get("@graph")
    assert isinstance(graph, list)

    package_node = next(
        node
        for node in graph
        if isinstance(node, dict) and _id_has_suffix(node, "basic-sinks/BasicSinksPackage")
    )
    assert package_node["cf:packageId"] == "cf.basic.sinks"
    assert package_node["cf:packageVersion"] == cf_basic_sinks.__version__


def test_steps_manifest_contains_no_native_plugin_metadata() -> None:
    manifest_path = _package_root() / "steps.nq"
    document = _load_manifest_document(manifest_path)
    graph = document.get("@graph")
    assert isinstance(graph, list)

    ids = {
        node.get("@id")
        for node in graph
        if isinstance(node, dict) and isinstance(node.get("@id"), str)
    }
    assert not any(str(node_id).endswith("basic-sinks/DataHiveParquetSinkStepCppImpl") for node_id in ids)
    assert not any(str(node_id).endswith("basic-sinks/BasicSinksPlugin") for node_id in ids)


def test_package_surface_contains_no_native_plugin_directory() -> None:
    package_root = _package_root()
    assert not (package_root / "bin").exists()
    assert not (package_root / "cpp").exists()


def test_steps_manifest_ports_include_value_contract_metadata() -> None:
    manifest_path = _package_root() / "steps.nq"
    document = _load_manifest_document(manifest_path)
    graph = document.get("@graph")
    assert isinstance(graph, list)

    nodes_by_id = {
        node.get("@id"): node for node in graph if isinstance(node, dict) and isinstance(node.get("@id"), str)
    }
    allowed_shapes = {"cf:shape_single", "cf:shape_vector", "cf:shape_matrix", "cf:shape_table"}

    typed_ports = [
        node
        for node in graph
        if isinstance(node, dict)
        and (_has_type(node, "cf:InputPort") or _has_type(node, "cf:OutputPort") or _has_type(node, "cf:Port"))
        and isinstance(node.get("cf:valueContract"), dict)
        and isinstance(node["cf:valueContract"].get("@id"), str)
    ]
    assert typed_ports, "Expected at least one port with valueContract metadata in steps manifest."

    for port in typed_ports:
        contract_ref = port.get("cf:valueContract")
        assert isinstance(contract_ref, dict) and isinstance(contract_ref.get("@id"), str)

        contract = nodes_by_id.get(contract_ref["@id"])
        assert isinstance(contract, dict)
        assert _has_type(contract, "cf:ValueContract")
        assert isinstance(contract.get("cf:elementType", {}).get("@id"), str)
        assert contract.get("cf:shapeKind", {}).get("@id") in allowed_shapes


def test_sink_package_does_not_own_duckdb_policy() -> None:
    readme_path = PACKAGE_ROOT / "README.md"
    readme_text = readme_path.read_text(encoding="utf-8")

    assert "duckdb" not in readme_text.lower()
