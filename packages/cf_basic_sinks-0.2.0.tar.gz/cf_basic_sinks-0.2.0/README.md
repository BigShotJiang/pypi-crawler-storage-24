# cf-basic-sinks

`cf-basic-sinks` provides declarative sink steps for pipeline outputs.

## Steps

| Step | Category | Description |
|------|----------|-------------|
| `cfsink:DataHiveParquetSinkStep` | sink | Declare a canonical Data Hive write that the pipeline runner executes through `cf_datahive_cpp` |

Published distribution name:

```bash
pip install cf-basic-sinks
```

## Package role

`cf_basic_sinks` ships the step manifest only.

- no native plugin is built or published from this package
- no backend runtime policy is owned here
- the pipeline runner owns execution of `cfsink:DataHiveParquetSinkStep`
- backend-specific write behavior remains owned by `cf_datahive`

## Publishing

`cf_basic_sinks` is published with the dedicated Windows workflow:

- Workflow: `.github/workflows/cf_basic_sinks_windows_publish.yml`
- Package directory: `sandcastle/cf_basic_steps/cf_basic_sinks`
- PyPI tag: `cf-basic-sinks-v<version>`
- TestPyPI tag: `cf-basic-sinks-v<version>-test`

Workflow note:

- test/build jobs publish a pure Python step-manifest package
- backend-specific native configuration and runtime staging are owned in `sandcastle/cf_datahive/README.md` and consumed by `cf_pipeline_engine`

Local preflight:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/mimic_windows_python_publish_workflow.ps1 `
  -WorkflowFile .github/workflows/cf_basic_sinks_windows_publish.yml `
  -PackageDir sandcastle/cf_basic_steps/cf_basic_sinks `
  -PythonExe py `
  -PythonVersion 3.13
```

Queue a dry-run dispatch:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/queue_windows_python_publish_workflow.ps1 `
  -WorkflowFile .github/workflows/cf_basic_sinks_windows_publish.yml `
  -PackageDir sandcastle/cf_basic_steps/cf_basic_sinks `
  -PublishTarget testpypi `
  -Ref main `
  -RequireLocalPass `
  -DryRun
```
