"""
Gateway module for EnkaliPrime CLI.

Provides central message routing between channels and AI.
"""

from .service import GatewayService, SessionContext, get_gateway

__all__ = [
    "GatewayService",
    "SessionContext",
    "get_gateway",
]
