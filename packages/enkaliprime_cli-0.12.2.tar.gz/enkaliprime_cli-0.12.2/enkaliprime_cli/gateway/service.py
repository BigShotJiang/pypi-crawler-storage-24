"""
Gateway Service - Central message routing and AI processing.

Provides:
- Message routing between channels and AI
- Session management per channel
- Skill triggering from messages
- Async handling of multi-channel conversations
"""

import asyncio
import json
import tempfile
import subprocess
import base64
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, List, Any, Callable
from dataclasses import dataclass, field
from rich.console import Console

from ..channels import (
    Channel, ChannelManager, ChannelMessage, 
    get_channel_manager, WhatsAppChannel, SlackChannel, GoogleChatChannel
)
from ..channels.base import ChannelConfig, MessageType
from ..skills import get_registry, get_engine, SkillContext, SkillResult
from ..skills.registry import SkillMatch

console = Console()


@dataclass
class SessionContext:
    """Context for a channel session."""
    session_id: str
    channel: str
    user_id: str
    conversation_history: List[Dict[str, str]] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.now)
    last_activity: datetime = field(default_factory=datetime.now)
    
    def add_message(self, role: str, content: str) -> None:
        """Add a message to conversation history."""
        self.conversation_history.append({
            "role": role,
            "content": content,
            "timestamp": datetime.now().isoformat()
        })
        self.last_activity = datetime.now()
        
        # Limit history to last 50 messages
        if len(self.conversation_history) > 50:
            self.conversation_history = self.conversation_history[-50:]


class GatewayService:
    """Central gateway for routing messages between channels and AI."""
    
    def __init__(
        self,
        channel_manager: Optional[ChannelManager] = None,
        ai_callback: Optional[Callable[[str, SessionContext], str]] = None
    ):
        """Initialize gateway service.
        
        Args:
            channel_manager: Channel manager instance
            ai_callback: Callback function for AI responses (message, context) -> response
        """
        self.channel_manager = channel_manager or get_channel_manager()
        self.ai_callback = ai_callback
        self.sessions: Dict[str, SessionContext] = {}
        self.skill_registry = get_registry()
        self.skill_engine = get_engine()
        self.is_running = False
        self._tasks: List[asyncio.Task] = []

        self._tts_engines: Dict[str, Any] = {}

        self._sessions_loaded = False

    def _sessions_store_path(self) -> Path:
        root = Path.home() / ".enkaliprime"
        root.mkdir(parents=True, exist_ok=True)
        return root / "gateway_sessions.json"

    def _load_sessions_from_disk(self) -> None:
        if self._sessions_loaded:
            return
        self._sessions_loaded = True

        path = self._sessions_store_path()
        if not path.exists():
            return

        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return

        sessions = data.get("sessions")
        if not isinstance(sessions, dict):
            return

        for session_id, payload in sessions.items():
            if session_id in self.sessions:
                continue
            if not isinstance(payload, dict):
                continue
            channel = payload.get("channel")
            user_id = payload.get("user_id")
            history = payload.get("conversation_history")
            metadata = payload.get("metadata")
            if not isinstance(channel, str) or not isinstance(user_id, str):
                continue
            if not isinstance(history, list):
                history = []
            if not isinstance(metadata, dict):
                metadata = {}

            ctx = SessionContext(
                session_id=session_id,
                channel=channel,
                user_id=user_id,
                conversation_history=history,
                metadata=metadata,
            )
            self.sessions[session_id] = ctx

    def _save_sessions_to_disk(self) -> None:
        path = self._sessions_store_path()
        data = {"sessions": {}}

        for sid, session in self.sessions.items():
            data["sessions"][sid] = {
                "channel": session.channel,
                "user_id": session.user_id,
                "conversation_history": session.conversation_history,
                "metadata": session.metadata,
                "last_activity": session.last_activity.isoformat(),
            }

        try:
            path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        except Exception:
            pass
    
    def _get_session_key(self, channel: str, user_id: str) -> str:
        """Generate unique session key."""
        return f"{channel}:{user_id}"
    
    def get_or_create_session(self, message: ChannelMessage) -> SessionContext:
        """Get existing session or create new one."""
        self._load_sessions_from_disk()
        session_key = self._get_session_key(message.channel, message.sender_id)
        
        if session_key not in self.sessions:
            self.sessions[session_key] = SessionContext(
                session_id=session_key,
                channel=message.channel,
                user_id=message.sender_id,
                metadata={
                    "sender_name": message.sender_name,
                    "channel_type": message.channel
                }
            )
            console.print(f"[dim]Created new session: {session_key}[/]")
        
        return self.sessions[session_key]
    
    async def transcribe_voice_note(self, message: ChannelMessage, channel: WhatsAppChannel) -> Optional[str]:
        """Transcribe voice note using speech recognition.
        
        Args:
            message: Channel message containing voice note
            channel: WhatsApp channel instance
            
        Returns:
            Transcribed text or None if failed
        """
        try:
            console.print("[yellow]🎤 Transcribing voice note...[/]")
            
            # Download the voice note
            # Determine correct JID - if it already has a suffix, use as is
            sender_jid = message.sender_id
            if "@" not in sender_jid:
                sender_jid = f"{sender_jid}@s.whatsapp.net"
                
            audio_bytes = await channel.download_voice_note(
                message.id, 
                sender_jid
            )
            
            if not audio_bytes:
                console.print("[red]Failed to download voice note[/]")
                return None
            
            # Save to temporary file
            with tempfile.NamedTemporaryFile(suffix=".ogg", delete=False) as temp_file:
                temp_file.write(audio_bytes)
                temp_path = temp_file.name
            
            try:
                # Try to transcribe using available speech recognition
                transcription = None
                
                # 1. Try faster-whisper (Pocket TTS style)
                try:
                    from faster_whisper import WhisperModel
                    console.print("[dim]Using faster-whisper (tiny) for transcription...[/]")
                    # Using tiny model on CPU with int8 quantization for speed
                    stt_model = WhisperModel("tiny", device="cpu", compute_type="int8")
                    segments, info = stt_model.transcribe(temp_path, beam_size=1)
                    transcription = " ".join([segment.text for segment in segments]).strip()
                except ImportError:
                    console.print("[dim]faster-whisper not available, trying alternatives...[/]")
                except Exception as e:
                    console.print(f"[dim]faster-whisper failed: {e}[/]")
                
                # 2. Try OpenAI Whisper if available
                if not transcription:
                    try:
                        import whisper
                        console.print("[dim]Using OpenAI Whisper for transcription...[/]")
                        model = whisper.load_model("base")
                        result = model.transcribe(temp_path)
                        transcription = result.get("text", "").strip()
                    except ImportError:
                        console.print("[dim]Whisper not available, trying alternative...[/]")
                    except Exception as e:
                        console.print(f"[dim]Whisper failed: {e}[/]")
                
                # Try speech_recognition library as fallback
                if not transcription:
                    try:
                        import speech_recognition as sr
                        console.print("[dim]Using speech_recognition library...[/]")
                        r = sr.Recognizer()
                        
                        # Convert OGG to WAV if needed
                        wav_path = temp_path.replace(".ogg", ".wav")
                        try:
                            # Try using ffmpeg for conversion
                            subprocess.run([
                                "ffmpeg", "-i", temp_path, wav_path, "-y"
                            ], capture_output=True, check=True)
                            temp_path = wav_path
                        except (subprocess.CalledProcessError, FileNotFoundError):
                            console.print("[dim]ffmpeg not available, using direct file...[/]")
                        
                        with sr.AudioFile(temp_path) as source:
                            audio = r.record(source)
                            transcription = r.recognize_google(audio)
                    except ImportError:
                        console.print("[dim]speech_recognition not available[/]")
                    except Exception as e:
                        console.print(f"[dim]speech_recognition failed: {e}[/]")
                
                # Clean up temp file
                try:
                    Path(temp_path).unlink()
                except Exception:
                    pass
                
                if transcription:
                    console.print(f"[green]✓ Transcription: {transcription}[/]")
                    return transcription
                else:
                    console.print("[red]All transcription methods failed[/]")
                    return None
                    
            except Exception as e:
                console.print(f"[red]Transcription error: {e}[/]")
                # Clean up temp file
                try:
                    Path(temp_path).unlink()
                except Exception:
                    pass
                return None
                
        except Exception as e:
            console.print(f"[red]Voice note transcription failed: {e}[/]")
            return None
    
    async def handle_message(self, message: ChannelMessage) -> None:
        """Process incoming message.
        
        Args:
            message: Incoming channel message
        """
        # Get channel
        channel = self.channel_manager.get_channel(message.channel)
        if not channel:
            console.print(f"[red]Channel not found: {message.channel}[/]")
            return

        # WhatsApp: ignore non-chat JIDs (newsletters, status, groups) to avoid bad send attempts.
        whatsapp_allow_bypass = False
        if isinstance(channel, WhatsAppChannel):
            sender = str(message.sender_id or "")
            
            # Extract extended metadata
            is_lid = False
            is_group = False
            is_mentioned = False
            is_reply_to_me = False
            
            raw_data = getattr(message, "raw_data", None)
            if isinstance(raw_data, dict):
                is_lid = raw_data.get("isLid", False) or sender.endswith("@lid")
                is_group = raw_data.get("isGroup", False) or sender.endswith("@g.us")
                is_mentioned = raw_data.get("isMentioned", False)
                is_reply_to_me = raw_data.get("isReplyToMe", False)
            
            console.print(f"[dim]DEBUG service.py: sender={sender} is_lid={is_lid} is_group={is_group} is_mentioned={is_mentioned} is_reply={is_reply_to_me}[/]")

            # Filter non-chat types
            if "@newsletter" in sender or sender.endswith("@broadcast"):
                console.print(f"[dim]Ignoring non-chat WhatsApp sender: {sender}[/]")
                return

            # Group Message Filtering
            if is_group:
                 if not (is_mentioned or is_reply_to_me):
                     console.print(f"[dim]Ignoring group message without mention/reply: {sender}[/]")
                     return
                 else:
                     console.print(f"[dim green]Allowing group message (mentioned/reply): {sender}[/]")
            # Note: Do NOT return here if allowed - let it proceed to users_all checks

            owner = None
            try:
                if isinstance(getattr(channel, "config", None), ChannelConfig):
                    owner = getattr(channel.config, "default_recipient", None)
            except Exception:
                owner = None
            owner_digits = "".join(ch for ch in str(owner or "") if ch.isdigit())

            allow_me = bool(getattr(self, "allow_me", False))
            from_me = False
            raw_data = getattr(message, "raw_data", None)
            if isinstance(raw_data, dict):
                from_me = raw_data.get("fromMe") is True

            users_all = bool(getattr(self, "users_all", False))

            # Semantics:
            # - When users_all is enabled, only process messages from other numbers (never self/owner).
            # - When users_all is disabled, allow self-chat only when --me is enabled.
            # - LID messages with fromMe=False are from other users and should be allowed in usersall mode
            if users_all:
                if from_me:
                    console.print("[dim]Ignoring WhatsApp self-chat message in --usersall mode.[/]")
                    return
                # LID messages from others (fromMe=False) are allowed through
                if is_lid and not from_me:
                    console.print(f"[dim]Allowing LID message from {message.sender_name or sender} in --usersall mode[/]")
            else:
                if from_me:
                    if not allow_me:
                        console.print("[dim]Ignoring WhatsApp self-sent message (use --me to enable).[/]")
                        return

            # Extract digits for owner comparison - LID addresses don't have phone digits
            sender_digits = "".join(ch for ch in sender if ch.isdigit())

            # When users_all is enabled, ignore the owner chat (treat it as self).
            # But LID addresses should not be compared this way
            if users_all and sender_digits and owner_digits and sender_digits == owner_digits and not is_lid:
                console.print("[dim]Ignoring WhatsApp owner message in --usersall mode.[/]")
                return

            if not users_all:
                allowed_users = set()
                runtime_allowed = getattr(self, "allowed_users", set())
                if isinstance(runtime_allowed, set):
                    for u in runtime_allowed:
                        s = "".join(ch for ch in str(u) if ch.isdigit())
                        if s:
                            allowed_users.add(s)

                try:
                    allow_from = getattr(channel.config, "allow_from", None)
                    if isinstance(allow_from, list):
                        for u in allow_from:
                            s = "".join(ch for ch in str(u) if ch.isdigit())
                            if s:
                                allowed_users.add(s)
                except Exception:
                    pass

                try:
                    extra = getattr(channel.config, "extra", {}) or {}
                    if isinstance(extra, dict):
                        persisted = extra.get("allowed_users")
                        if isinstance(persisted, list):
                            for u in persisted:
                                s = "".join(ch for ch in str(u) if ch.isdigit())
                                if s:
                                    allowed_users.add(s)
                except Exception:
                    pass

                # Allow owner or allowlisted users.
                if sender_digits and sender_digits in allowed_users:
                    pass
                elif sender_digits and owner_digits and sender_digits == owner_digits:
                    pass
                else:
                    if not owner_digits and allowed_users:
                        console.print(
                            "[yellow]WhatsApp allowlist mode is enabled but no default recipient is set. "
                            "(Allowlisted users can still use the bot.) "
                            "Run: enkaliprime channels set-recipient whatsapp <your-number> (or start with --usersall).[/]"
                        )
                    console.print(
                        f"[dim]Ignoring WhatsApp sender {sender} (owner/allowlist mode). "
                        f"sender_digits={sender_digits or '-'} owner_digits={owner_digits or '-'} allowlist={sorted(allowed_users)}. "
                        "Use --usersall to reply to everyone.[/]"
                    )
                    return
            # All WhatsApp messages that reach here (passed fromMe check and users_all/allowlist check) get bypass
            whatsapp_allow_bypass = True

        console.print(
            f"[dim]Inbound {message.channel} message from {message.sender_id}:[/] {message.content}"
        )
        
        # Check if allowed
        if not (isinstance(channel, WhatsAppChannel) and bool(whatsapp_allow_bypass)):
            if not channel.is_allowed(message.sender_id):
                console.print(f"[yellow]Message from blocked sender: {message.sender_id}[/]")
                return
        
        # Check if needs pairing
        if not (isinstance(channel, WhatsAppChannel) and bool(whatsapp_allow_bypass)) and channel.needs_pairing(message.sender_id):
            # Generate pairing code if not exists
            if not channel.config.pairing_code:
                if hasattr(channel, 'generate_pairing_code'):
                    code = channel.generate_pairing_code()
                    await channel.send_message(
                        message.sender_id,
                        f"Welcome! Please provide this pairing code to start: {code}"
                    )
            return
        
        # Get or create session
        session = self.get_or_create_session(message)

        console.print(
            f"[dim]AI connecting for session={session.session_id} channel={message.channel} user={message.sender_id}...[/]"
        )
        
        # Handle voice notes - transcribe if it's an audio message
        message_content = message.content
        if (message.message_type == MessageType.AUDIO and 
            isinstance(channel, WhatsAppChannel) and 
            hasattr(channel, 'download_voice_note')):
            
            console.print("[yellow]🎤 Voice note detected, transcribing...[/]")
            transcription = await self.transcribe_voice_note(message, channel)
            if transcription:
                message_content = f"[Voice Note]: {transcription}"
                console.print(f"[green]✓ Transcribed: {transcription}[/]")
            else:
                message_content = "[Voice Note: Transcription failed]"
                console.print("[red]Voice note transcription failed[/]")
        
        # Add user message to history
        session.add_message("user", message_content)
        self._save_sessions_to_disk()
        
        # Process through skills
        skill_result = await self._try_skill_execution(message, session)
        
        # Get AI response if no skill handled it
        history_items = session.conversation_history[-20:]
        history_text = "\n".join(
            f"{m.get('role', '')}: {m.get('content', '')}" for m in history_items if isinstance(m, dict)
        ).strip()

        base_prompt = message_content
        if skill_result and skill_result.success and skill_result.output:
            base_prompt = (
                f"User message: {message_content}\n\n"
                f"Skill context:\n{skill_result.output}\n\n"
                "Please respond based on this information."
            )

        if history_text:
            ai_prompt = f"Previous conversation:\n{history_text}\n\nCurrent message:\n{base_prompt}"
        else:
            ai_prompt = base_prompt
        
        # Get AI response
        if self.ai_callback:
            try:
                console.print("[dim]AI generating response...[/]")
                if asyncio.iscoroutinefunction(self.ai_callback):
                    response = await self.ai_callback(ai_prompt, session)
                else:
                    response = self.ai_callback(ai_prompt, session)
                console.print("[dim]AI response generated.[/]")
            except Exception as e:
                console.print(f"[red]AI callback error: {e}[/]")
                response = "Sorry, I encountered an error processing your message."
        else:
            # Default response when no AI configured
            response = self._generate_default_response(message, session, skill_result)
        
        # Add AI response to history
        session.add_message("assistant", response)
        self._save_sessions_to_disk()

        voice_enabled = bool(getattr(self, "voice_enabled", False))
        voice_wav_path_fallback = getattr(self, "voice_wav_path_fallback", None)

        if voice_enabled and isinstance(channel, WhatsAppChannel) and hasattr(channel, "send_voice_note"):
            try:
                from ..tts import PocketTTSEngine

                voice_wav_path = None
                try:
                    extra = getattr(channel.config, "extra", {}) or {}
                    if isinstance(extra, dict):
                        voices = extra.get("tts_voices")
                        default_voice = extra.get("tts_default_voice")
                        if isinstance(default_voice, str) and default_voice.strip():
                            if isinstance(voices, dict) and default_voice in voices:
                                voice_wav_path = str(voices.get(default_voice))
                            else:
                                voice_wav_path = default_voice
                except Exception:
                    voice_wav_path = None

                if not isinstance(voice_wav_path, str) or not voice_wav_path.strip():
                    voice_wav_path = voice_wav_path_fallback

                if not isinstance(voice_wav_path, str) or not voice_wav_path.strip():
                    raise RuntimeError("Missing voice wav path (configure via channels tts-set-default-voice)")

                engine = self._tts_engines.get(voice_wav_path)
                if engine is None:
                    engine = PocketTTSEngine(voice_wav_path=voice_wav_path)
                    self._tts_engines[voice_wav_path] = engine

                console.print("[dim]TTS generating voice note...[/]")
                wav_path = await asyncio.to_thread(engine.synthesize_to_wav_path, response)
                ogg_path = await asyncio.to_thread(engine.transcode_wav_to_opus_ogg, wav_path)
                audio_bytes = await asyncio.to_thread(engine.read_bytes, ogg_path)

                console.print(f"[dim]Sending voice note to {message.sender_id}...[/]")
                result = await channel.send_voice_note(message.sender_id, audio_bytes)
                if result.success:
                    console.print("[green]✓ Voice note sent[/]")
                    return
                raise RuntimeError(result.error or "Voice note send failed")
            except Exception as e:
                console.print(f"[yellow]Voice reply failed, falling back to text: {e}[/]")

        # Send response back through channel (text)
        console.print(f"[dim]Sending reply to {message.sender_id}...[/]")
        result = await channel.send_message(
            message.sender_id,
            response,
            thread_id=message.thread_id,
        )

        if result.success:
            console.print("[green]✓ Reply sent[/]")
        else:
            console.print(f"[red]Failed to send response: {result.error}[/]")
    
    async def _try_skill_execution(
        self,
        message: ChannelMessage,
        session: SessionContext
    ) -> Optional[SkillResult]:
        """Try to execute a skill based on message content.
        
        Args:
            message: User message
            session: Session context
            
        Returns:
            SkillResult if skill executed, None otherwise
        """
        self.skill_registry.initialize()
        
        # Find matching skill
        match = self.skill_registry.get_best_match(message.content, min_confidence=0.5)
        
        if not match:
            return None
        
        console.print(f"[cyan]Skill triggered: {match.skill.metadata.name} ({match.confidence:.2f})[/]")
        
        # Create skill context
        skill_context = SkillContext(
            user_message=message.content,
            conversation_history=session.conversation_history,
            session_id=session.session_id,
            channel=message.channel,
            working_directory=Path.cwd()
        )
        
        # Execute skill
        result = self.skill_engine.execute(match.skill, skill_context)
        
        return result
    
    def _generate_default_response(
        self,
        message: ChannelMessage,
        session: SessionContext,
        skill_result: Optional[SkillResult]
    ) -> str:
        """Generate default response when no AI callback configured."""
        parts = []
        
        parts.append(f"Echo: {message.content}")
        
        if skill_result and skill_result.success:
            parts.append(f"\n[Skill: {skill_result.message}]")
            if skill_result.output:
                preview = skill_result.output[:200] + "..." if len(skill_result.output) > 200 else skill_result.output
                parts.append(f"\nSkill output preview:\n{preview}")
        
        return "\n".join(parts)
    
    async def start(self) -> None:
        """Start the gateway service."""
        self.is_running = True

        self._load_sessions_from_disk()
        
        # Start all channels
        await self.channel_manager.start_all()
        
        # Start listening to all channels
        for name, channel in self.channel_manager.channels.items():
            if channel.is_connected:
                task = asyncio.create_task(self._listen_channel(channel))
                self._tasks.append(task)
        
        console.print("[green]Gateway service started[/]")
    
    async def stop(self) -> None:
        """Stop the gateway service."""
        self.is_running = False
        
        # Cancel all listening tasks
        for task in self._tasks:
            task.cancel()
        
        # Stop all channels
        await self.channel_manager.stop_all()
        
        console.print("[yellow]Gateway service stopped[/]")
    
    async def _listen_channel(self, channel: Channel) -> None:
        """Listen to a specific channel."""
        try:
            async for message in channel.listen():
                if not self.is_running:
                    break
                await self.handle_message(message)
        except asyncio.CancelledError:
            pass
        except Exception as e:
            console.print(f"[red]Error listening to {channel.name}: {e}[/]")
    
    async def _on_channel_message(self, message: ChannelMessage) -> None:
        """Handler for channel messages."""
        await self.handle_message(message)
    
    def get_session_info(self, session_id: Optional[str] = None) -> Dict[str, Any]:
        """Get session information.
        
        Args:
            session_id: Optional specific session ID
            
        Returns:
            Session info dictionary
        """
        if session_id:
            session = self.sessions.get(session_id)
            if session:
                return {
                    "session_id": session.session_id,
                    "channel": session.channel,
                    "user_id": session.user_id,
                    "message_count": len(session.conversation_history),
                    "created_at": session.created_at.isoformat(),
                    "last_activity": session.last_activity.isoformat()
                }
            return {}
        
        # Return all sessions summary
        return {
            "total_sessions": len(self.sessions),
            "sessions": [
                {
                    "session_id": s.session_id,
                    "channel": s.channel,
                    "user_id": s.user_id[:10] + "..." if len(s.user_id) > 10 else s.user_id,
                    "message_count": len(s.conversation_history),
                    "last_activity": s.last_activity.isoformat()
                }
                for s in self.sessions.values()
            ]
        }


# Global gateway instance
_gateway: Optional[GatewayService] = None


def get_gateway(
    ai_callback: Optional[Callable[[str, SessionContext], str]] = None
) -> GatewayService:
    """Get or create global gateway service."""
    global _gateway
    if _gateway is None:
        _gateway = GatewayService(ai_callback=ai_callback)
    elif ai_callback:
        _gateway.ai_callback = ai_callback
    return _gateway
