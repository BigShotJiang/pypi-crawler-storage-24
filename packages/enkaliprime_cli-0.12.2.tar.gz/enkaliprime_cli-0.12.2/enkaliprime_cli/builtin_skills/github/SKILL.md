---
name: github
description: Interact with GitHub repositories, issues, pull requests, and search. Use when user needs to create issues, search repos, manage PRs, or access GitHub resources.
version: 1.0.0
author: EnkaliPrime CLI
tags: [github, git, version-control, development]
---

# GitHub Skill

This skill provides comprehensive GitHub integration for repository management, issue tracking, and pull request operations.

## Capabilities

- **Repository Search**: Find repositories by keyword, language, or topic
- **Issue Management**: Create, list, and search issues
- **Pull Request Operations**: List and manage PRs
- **Repository Information**: Get details about repos, stars, forks, etc.

## When to Use

Use this skill when the user asks about:
- Searching for GitHub repositories
- Creating GitHub issues
- Managing pull requests
- Getting repository information
- GitHub workflows and actions

## Usage Examples

### Search Repositories

"Find popular Python machine learning libraries on GitHub"
"Search for repos about web scraping"

### Create Issues

"Create an issue in my repo about the login bug"
"Open a GitHub issue for feature request"

### List Pull Requests

"Show me open PRs in the repository"
"List recent pull requests"

## Scripts

- `search_repos.py` - Search GitHub repositories
- `create_issue.py` - Create issues in repositories
- `list_prs.py` - List pull requests
- `repo_info.py` - Get repository information

## Configuration

Requires `GITHUB_TOKEN` environment variable for API access (optional for public repos, required for private).

## API Rate Limits

- Unauthenticated: 60 requests/hour
- Authenticated: 5,000 requests/hour
