#!/usr/bin/env python3
"""
Create a GitHub issue.

Usage: create_issue.py --repo owner/repo --title "Issue title" [--body "Description"]
"""

import argparse
import json
import os
import sys
import urllib.request


def create_issue(repo: str, title: str, body: str = None, labels: list = None) -> dict:
    """Create a GitHub issue."""
    
    token = os.environ.get("GITHUB_TOKEN")
    if not token:
        print("Error: GITHUB_TOKEN environment variable required", file=sys.stderr)
        sys.exit(1)
    
    url = f"https://api.github.com/repos/{repo}/issues"
    
    data = {
        "title": title,
    }
    if body:
        data["body"] = body
    if labels:
        data["labels"] = labels
    
    headers = {
        "Accept": "application/vnd.github.v3+json",
        "User-Agent": "EnkaliPrime-CLI",
        "Authorization": f"token {token}",
        "Content-Type": "application/json"
    }
    
    try:
        req = urllib.request.Request(
            url,
            data=json.dumps(data).encode(),
            headers=headers,
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=30) as response:
            return json.loads(response.read().decode())
    except urllib.error.HTTPError as e:
        print(f"Error: HTTP {e.code} - {e.reason}", file=sys.stderr)
        try:
            error_body = e.read().decode()
            error_data = json.loads(error_body)
            print(f"Details: {error_data.get('message', 'Unknown error')}", file=sys.stderr)
        except:
            pass
        sys.exit(1)
    except Exception as e:
        print(f"Error creating issue: {e}", file=sys.stderr)
        sys.exit(1)


def main():
    parser = argparse.ArgumentParser(description="Create GitHub issue")
    parser.add_argument("--repo", "-r", required=True, help="Repository (owner/repo)")
    parser.add_argument("--title", "-t", required=True, help="Issue title")
    parser.add_argument("--body", "-b", help="Issue body/description")
    parser.add_argument("--labels", "-l", help="Comma-separated labels")
    
    args = parser.parse_args()
    
    labels = args.labels.split(",") if args.labels else None
    
    issue = create_issue(args.repo, args.title, args.body, labels)
    
    print(f"✓ Issue created successfully!")
    print(f"  Number: #{issue['number']}")
    print(f"  Title: {issue['title']}")
    print(f"  URL: {issue['html_url']}")


if __name__ == "__main__":
    main()
