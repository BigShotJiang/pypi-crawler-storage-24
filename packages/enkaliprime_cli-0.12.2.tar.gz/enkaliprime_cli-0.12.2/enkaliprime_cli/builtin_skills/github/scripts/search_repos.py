#!/usr/bin/env python3
"""
Search GitHub repositories.

Usage: search_repos.py --query "machine learning" [--language python] [--sort stars]
"""

import argparse
import json
import os
import sys
import urllib.request
from typing import List, Dict, Any


def search_repositories(query: str, language: str = None, sort: str = "stars", limit: int = 10) -> List[Dict[str, Any]]:
    """Search GitHub repositories."""
    
    # Build search query
    search_query = query
    if language:
        search_query += f" language:{language}"
    
    # GitHub API endpoint
    url = f"https://api.github.com/search/repositories?q={urllib.parse.quote(search_query)}&sort={sort}&order=desc&per_page={limit}"
    
    # Prepare request
    headers = {
        "Accept": "application/vnd.github.v3+json",
        "User-Agent": "EnkaliPrime-CLI"
    }
    
    # Add auth token if available
    token = os.environ.get("GITHUB_TOKEN")
    if token:
        headers["Authorization"] = f"token {token}"
    
    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=30) as response:
            data = json.loads(response.read().decode())
            return data.get("items", [])
    except urllib.error.HTTPError as e:
        print(f"Error: HTTP {e.code} - {e.reason}", file=sys.stderr)
        if e.code == 403:
            print("Rate limit exceeded. Set GITHUB_TOKEN for higher limits.", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error searching repositories: {e}", file=sys.stderr)
        sys.exit(1)


def format_repo(repo: Dict[str, Any]) -> str:
    """Format repository info for display."""
    name = repo.get("full_name", "unknown")
    description = repo.get("description", "No description")
    stars = repo.get("stargazers_count", 0)
    forks = repo.get("forks_count", 0)
    language = repo.get("language", "Unknown")
    url = repo.get("html_url", "")
    
    return f"""
📦 {name}
   ⭐ {stars:,} | 🍴 {forks:,} | 🔤 {language}
   {description[:100]}{'...' if len(description) > 100 else ''}
   🔗 {url}
"""


def main():
    parser = argparse.ArgumentParser(description="Search GitHub repositories")
    parser.add_argument("--query", "-q", required=True, help="Search query")
    parser.add_argument("--language", "-l", help="Filter by programming language")
    parser.add_argument("--sort", "-s", default="stars", choices=["stars", "forks", "updated"],
                       help="Sort by")
    parser.add_argument("--limit", "-n", type=int, default=10, help="Number of results")
    parser.add_argument("--json", "-j", action="store_true", help="Output as JSON")
    
    args = parser.parse_args()
    
    repos = search_repositories(args.query, args.language, args.sort, args.limit)
    
    if not repos:
        print("No repositories found.")
        return
    
    if args.json:
        print(json.dumps(repos, indent=2))
    else:
        print(f"Found {len(repos)} repositories:\n")
        for repo in repos:
            print(format_repo(repo))


if __name__ == "__main__":
    main()
