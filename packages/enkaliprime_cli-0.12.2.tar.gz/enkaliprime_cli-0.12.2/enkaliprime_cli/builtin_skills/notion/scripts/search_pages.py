#!/usr/bin/env python3
"""
Search Notion pages and databases.

Usage: search_pages.py [--query "search term"] [--type page|database]
"""

import argparse
import json
import os
import sys
from typing import List, Dict, Any, Optional

import requests

NOTION_API_BASE = "https://api.notion.com/v1"


def get_notion_token() -> str:
    """Get Notion integration token from environment."""
    token = os.environ.get("NOTION_TOKEN")
    if not token:
        print("Error: NOTION_TOKEN environment variable not set", file=sys.stderr)
        print("Create a Notion integration at https://www.notion.so/my-integrations", file=sys.stderr)
        sys.exit(1)
    return token


def get_headers() -> Dict[str, str]:
    """Get API request headers."""
    return {
        "Authorization": f"Bearer {get_notion_token()}",
        "Content-Type": "application/json",
        "Notion-Version": "2022-06-28"
    }


def search_notion(query: str = "", filter_type: Optional[str] = None, page_size: int = 10) -> List[Dict]:
    """Search Notion pages and databases.
    
    Args:
        query: Search query string
        filter_type: Filter by 'page' or 'database'
        page_size: Number of results
        
    Returns:
        List of search results
    """
    url = f"{NOTION_API_BASE}/search"
    
    body = {
        "query": query,
        "page_size": page_size
    }
    
    if filter_type:
        body["filter"] = {
            "value": filter_type,
            "property": "object"
        }
    
    try:
        response = requests.post(url, headers=get_headers(), json=body, timeout=30)
        response.raise_for_status()
        data = response.json()
        return data.get("results", [])
    except requests.exceptions.RequestException as e:
        print(f"Error searching Notion: {e}", file=sys.stderr)
        sys.exit(1)


def format_result(result: Dict[str, Any]) -> str:
    """Format a single search result."""
    obj_type = result.get("object", "unknown")
    result_id = result.get("id", "")
    
    # Extract title
    title = "Untitled"
    if obj_type == "page":
        title_data = result.get("properties", {}).get("title", {})
        if title_data:
            title_items = title_data.get("title", [])
            if title_items:
                title = "".join([item.get("plain_text", "") for item in title_items])
    elif obj_type == "database":
        title = result.get("title", [{}])[0].get("plain_text", "Untitled Database")
    
    url = result.get("url", "")
    created_time = result.get("created_time", "")[:10] if result.get("created_time") else ""
    
    return f"[{obj_type.upper()}] {title}\n  ID: {result_id}\n  URL: {url}\n  Created: {created_time}"


def main():
    parser = argparse.ArgumentParser(description="Search Notion pages and databases")
    parser.add_argument("--query", "-q", default="", help="Search query")
    parser.add_argument("--type", "-t", choices=["page", "database"], help="Filter by type")
    parser.add_argument("--limit", "-l", type=int, default=10, help="Number of results")
    parser.add_argument("--json", "-j", action="store_true", help="Output as JSON")
    
    args = parser.parse_args()
    
    results = search_notion(args.query, args.type, args.limit)
    
    if not results:
        print("No results found.")
        return
    
    if args.json:
        print(json.dumps(results, indent=2))
    else:
        print(f"Found {len(results)} result(s):\n")
        for i, result in enumerate(results, 1):
            print(f"{i}. {format_result(result)}")
            print()


if __name__ == "__main__":
    main()
