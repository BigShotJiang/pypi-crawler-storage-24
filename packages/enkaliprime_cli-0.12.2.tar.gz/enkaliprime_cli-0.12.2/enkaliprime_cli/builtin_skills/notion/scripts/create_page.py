#!/usr/bin/env python3
"""
Create a new page in Notion.

Usage: create_page.py --parent <page_id> --title "Page Title" [--content "Page content"]
"""

import argparse
import json
import os
import sys
from typing import Dict, Any, List

import requests

NOTION_API_BASE = "https://api.notion.com/v1"


def get_notion_token() -> str:
    """Get Notion integration token from environment."""
    token = os.environ.get("NOTION_TOKEN")
    if not token:
        print("Error: NOTION_TOKEN environment variable not set", file=sys.stderr)
        sys.exit(1)
    return token


def get_headers() -> Dict[str, str]:
    """Get API request headers."""
    return {
        "Authorization": f"Bearer {get_notion_token()}",
        "Content-Type": "application/json",
        "Notion-Version": "2022-06-28"
    }


def create_page(parent_id: str, title: str, content: str = "") -> Dict[str, Any]:
    """Create a new page in Notion.
    
    Args:
        parent_id: Parent page or database ID
        title: Page title
        content: Page content (paragraph text)
        
    Returns:
        Created page data
    """
    url = f"{NOTION_API_BASE}/pages"
    
    body = {
        "parent": {"page_id": parent_id},
        "properties": {
            "title": {
                "title": [{"text": {"content": title}}]
            }
        }
    }
    
    # Add content if provided
    if content:
        body["children"] = [
            {
                "object": "block",
                "type": "paragraph",
                "paragraph": {
                    "rich_text": [{"type": "text", "text": {"content": content}}]
                }
            }
        ]
    
    try:
        response = requests.post(url, headers=get_headers(), json=body, timeout=30)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"Error creating page: {e}", file=sys.stderr)
        sys.exit(1)


def main():
    parser = argparse.ArgumentParser(description="Create a new Notion page")
    parser.add_argument("--parent", "-p", required=True, help="Parent page ID")
    parser.add_argument("--title", "-t", required=True, help="Page title")
    parser.add_argument("--content", "-c", default="", help="Page content")
    parser.add_argument("--json", "-j", action="store_true", help="Output as JSON")
    
    args = parser.parse_args()
    
    # Clean up parent ID (remove dashes if present in URL)
    parent_id = args.parent.replace("-", "")
    
    result = create_page(parent_id, args.title, args.content)
    
    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print(f"Created page: {args.title}")
        print(f"ID: {result.get('id', 'N/A')}")
        print(f"URL: {result.get('url', 'N/A')}")
        print(f"Created: {result.get('created_time', 'N/A')[:10]}")


if __name__ == "__main__":
    main()
