#!/usr/bin/env python3
"""
Query a Notion database.

Usage: query_database.py <database_id> [--filter property_name=value]
"""

import argparse
import json
import os
import sys
from typing import Dict, Any, List, Optional

import requests

NOTION_API_BASE = "https://api.notion.com/v1"


def get_notion_token() -> str:
    """Get Notion integration token from environment."""
    token = os.environ.get("NOTION_TOKEN")
    if not token:
        print("Error: NOTION_TOKEN environment variable not set", file=sys.stderr)
        sys.exit(1)
    return token


def get_headers() -> Dict[str, str]:
    """Get API request headers."""
    return {
        "Authorization": f"Bearer {get_notion_token()}",
        "Content-Type": "application/json",
        "Notion-Version": "2022-06-28"
    }


def query_database(database_id: str, filter_obj: Optional[Dict] = None, page_size: int = 10) -> List[Dict]:
    """Query a Notion database.
    
    Args:
        database_id: Database ID to query
        filter_obj: Optional filter object
        page_size: Number of results
        
    Returns:
        List of database entries
    """
    url = f"{NOTION_API_BASE}/databases/{database_id}/query"
    
    body = {"page_size": page_size}
    if filter_obj:
        body["filter"] = filter_obj
    
    try:
        response = requests.post(url, headers=get_headers(), json=body, timeout=30)
        response.raise_for_status()
        data = response.json()
        return data.get("results", [])
    except requests.exceptions.RequestException as e:
        print(f"Error querying database: {e}", file=sys.stderr)
        sys.exit(1)


def format_entry(entry: Dict[str, Any]) -> str:
    """Format a database entry."""
    entry_id = entry.get("id", "")
    properties = entry.get("properties", {})
    
    lines = [f"ID: {entry_id}"]
    
    # Extract common properties
    for prop_name, prop_data in properties.items():
        prop_type = prop_data.get("type", "")
        
        if prop_type == "title":
            title_items = prop_data.get("title", [])
            value = "".join([item.get("plain_text", "") for item in title_items])
            lines.append(f"  Title: {value}")
        elif prop_type == "rich_text":
            text_items = prop_data.get("rich_text", [])
            value = "".join([item.get("plain_text", "") for item in text_items])
            if value:
                lines.append(f"  {prop_name}: {value[:50]}{'...' if len(value) > 50 else ''}")
        elif prop_type == "select":
            select = prop_data.get("select")
            if select:
                lines.append(f"  {prop_name}: {select.get('name', '')}")
        elif prop_type == "multi_select":
            options = prop_data.get("multi_select", [])
            values = [opt.get("name", "") for opt in options]
            if values:
                lines.append(f"  {prop_name}: {', '.join(values)}")
        elif prop_type == "date":
            date = prop_data.get("date")
            if date:
                lines.append(f"  {prop_name}: {date.get('start', '')}")
        elif prop_type == "checkbox":
            value = "Yes" if prop_data.get("checkbox") else "No"
            lines.append(f"  {prop_name}: {value}")
    
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="Query a Notion database")
    parser.add_argument("database_id", help="Database ID")
    parser.add_argument("--limit", "-l", type=int, default=10, help="Number of results")
    parser.add_argument("--json", "-j", action="store_true", help="Output as JSON")
    
    args = parser.parse_args()
    
    # Clean up database ID
    database_id = args.database_id.replace("-", "")
    
    results = query_database(database_id, page_size=args.limit)
    
    if not results:
        print("No results found.")
        return
    
    if args.json:
        print(json.dumps(results, indent=2))
    else:
        print(f"Found {len(results)} entr{'y' if len(results) == 1 else 'ies'}:\n")
        for i, entry in enumerate(results, 1):
            print(f"{i}. {format_entry(entry)}")
            print()


if __name__ == "__main__":
    main()
