---
name: notion
description: Interact with Notion workspaces - search pages, create pages, query databases, and manage content. Use when user mentions Notion, wikis, documentation, or knowledge bases.
version: 1.0.0
author: EnkaliPrime CLI
tags: [notion, productivity, wiki, documentation, notes]
---

# Notion Skill

Provides integration with Notion workspaces for document management and knowledge base operations.

## Capabilities

- Search Notion pages and databases
- Create new pages with content
- Query database entries
- Update existing pages
- Append content to pages

## When to Use

Use this skill when the user asks:
- "Search my Notion for..."
- "Create a Notion page about..."
- "Add this to Notion"
- "Query my Notion database"
- "Find documents in Notion"

## Scripts

- `search_pages.py` - Search pages and databases
- `create_page.py` - Create new pages with content
- `query_database.py` - Query database entries

## Configuration

Requires `NOTION_TOKEN` environment variable (Notion integration token).

## Examples

"Search my Notion for project planning documents"
"Create a new page called 'Meeting Notes' in my workspace"
"Query the Tasks database for items due this week"
