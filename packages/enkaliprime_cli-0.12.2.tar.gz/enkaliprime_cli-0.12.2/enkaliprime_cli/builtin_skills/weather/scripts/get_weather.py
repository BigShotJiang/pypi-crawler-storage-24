#!/usr/bin/env python3
"""
Get current weather using Open-Meteo API (free, no API key needed).

Usage: get_weather.py --city "London" [--country "UK"]
"""

import argparse
import json
import sys
import urllib.request
import urllib.parse
from typing import Dict, Any, Optional


def get_coordinates(city: str, country: str = None) -> Optional[tuple]:
    """Get lat/lon for a city using Open-Meteo geocoding."""
    
    query = city
    if country:
        query += f", {country}"
    
    url = f"https://geocoding-api.open-meteo.com/v1/search?name={urllib.parse.quote(query)}&count=1"
    
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "EnkaliPrime-CLI"})
        with urllib.request.urlopen(req, timeout=30) as response:
            data = json.loads(response.read().decode())
            results = data.get("results", [])
            if results:
                result = results[0]
                return (result["latitude"], result["longitude"], result.get("name", city))
    except Exception as e:
        print(f"Error geocoding location: {e}", file=sys.stderr)
    
    return None


def get_weather(lat: float, lon: float) -> Dict[str, Any]:
    """Get current weather from Open-Meteo."""
    
    url = f"https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m&timezone=auto"
    
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "EnkaliPrime-CLI"})
        with urllib.request.urlopen(req, timeout=30) as response:
            return json.loads(response.read().decode())
    except Exception as e:
        print(f"Error fetching weather: {e}", file=sys.stderr)
        sys.exit(1)


def get_weather_description(code: int) -> str:
    """Convert WMO weather code to description."""
    codes = {
        0: "Clear sky",
        1: "Mainly clear", 2: "Partly cloudy", 3: "Overcast",
        45: "Fog", 48: "Depositing rime fog",
        51: "Light drizzle", 53: "Moderate drizzle", 55: "Dense drizzle",
        56: "Light freezing drizzle", 57: "Dense freezing drizzle",
        61: "Slight rain", 63: "Moderate rain", 65: "Heavy rain",
        66: "Light freezing rain", 67: "Heavy freezing rain",
        71: "Slight snow fall", 73: "Moderate snow fall", 75: "Heavy snow fall",
        77: "Snow grains",
        80: "Slight rain showers", 81: "Moderate rain showers", 82: "Violent rain showers",
        85: "Slight snow showers", 86: "Heavy snow showers",
        95: "Thunderstorm", 96: "Thunderstorm with slight hail", 99: "Thunderstorm with heavy hail",
    }
    return codes.get(code, "Unknown")


def format_weather(data: Dict[str, Any], location: str) -> str:
    """Format weather data for display."""
    current = data.get("current", {})
    
    temp = current.get("temperature_2m", "N/A")
    feels_like = current.get("apparent_temperature", "N/A")
    humidity = current.get("relative_humidity_2m", "N/A")
    wind = current.get("wind_speed_10m", "N/A")
    code = current.get("weather_code", 0)
    
    description = get_weather_description(code)
    
    return f"""
🌤️  Weather in {location}

🌡️  Temperature: {temp}°C (feels like {feels_like}°C)
💧 Humidity: {humidity}%
💨 Wind: {wind} km/h
☁️  Conditions: {description}
"""


def main():
    parser = argparse.ArgumentParser(description="Get current weather")
    parser.add_argument("--city", "-c", required=True, help="City name")
    parser.add_argument("--country", help="Country (optional, for better accuracy)")
    parser.add_argument("--json", "-j", action="store_true", help="Output as JSON")
    
    args = parser.parse_args()
    
    # Get coordinates
    coords = get_coordinates(args.city, args.country)
    if not coords:
        print(f"Could not find location: {args.city}", file=sys.stderr)
        sys.exit(1)
    
    lat, lon, location_name = coords
    
    # Get weather
    weather_data = get_weather(lat, lon)
    
    if args.json:
        print(json.dumps(weather_data, indent=2))
    else:
        print(format_weather(weather_data, location_name))


if __name__ == "__main__":
    main()
