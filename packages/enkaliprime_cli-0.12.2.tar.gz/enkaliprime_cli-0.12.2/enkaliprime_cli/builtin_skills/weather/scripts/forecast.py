#!/usr/bin/env python3
"""
Get weather forecast for a location using Open-Meteo API.

Usage: forecast.py <location> [--days 7]
"""

import argparse
import json
import sys
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, Tuple

import requests

GEOCODING_API = "https://geocoding-api.open-meteo.com/v1/search"
FORECAST_API = "https://api.open-meteo.com/v1/forecast"


def geocode_location(location: str) -> Tuple[float, float, str]:
    """Get coordinates from location name."""
    params = {
        "name": location,
        "count": 1,
        "language": "en",
        "format": "json"
    }
    
    try:
        response = requests.get(GEOCODING_API, params=params, timeout=30)
        response.raise_for_status()
        data = response.json()
        
        if not data.get("results"):
            print(f"Error: Location '{location}' not found", file=sys.stderr)
            sys.exit(1)
        
        result = data["results"][0]
        return (
            result["latitude"],
            result["longitude"],
            result.get("name", location)
        )
    except requests.exceptions.RequestException as e:
        print(f"Error geocoding: {e}", file=sys.stderr)
        sys.exit(1)


def get_forecast(lat: float, lon: float, days: int = 7) -> Dict[str, Any]:
    """Get weather forecast from Open-Meteo API."""
    params = {
        "latitude": lat,
        "longitude": lon,
        "daily": [
            "weather_code",
            "temperature_2m_max",
            "temperature_2m_min",
            "precipitation_sum",
            "precipitation_probability_max",
            "wind_speed_10m_max"
        ],
        "timezone": "auto",
        "forecast_days": days
    }
    
    try:
        response = requests.get(FORECAST_API, params=params, timeout=30)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"Error fetching forecast: {e}", file=sys.stderr)
        sys.exit(1)


def get_weather_description(code: int) -> str:
    """Get description from WMO weather code."""
    codes = {
        0: "Clear sky",
        1: "Mainly clear", 2: "Partly cloudy", 3: "Overcast",
        45: "Fog", 48: "Depositing rime fog",
        51: "Light drizzle", 53: "Moderate drizzle", 55: "Dense drizzle",
        56: "Light freezing drizzle", 57: "Dense freezing drizzle",
        61: "Slight rain", 63: "Moderate rain", 65: "Heavy rain",
        66: "Light freezing rain", 67: "Heavy freezing rain",
        71: "Slight snow", 73: "Moderate snow", 75: "Heavy snow",
        77: "Snow grains",
        80: "Slight rain showers", 81: "Moderate rain showers", 82: "Violent rain showers",
        85: "Slight snow showers", 86: "Heavy snow showers",
        95: "Thunderstorm", 96: "Thunderstorm with slight hail", 99: "Thunderstorm with heavy hail"
    }
    return codes.get(code, "Unknown")


def get_weather_emoji(code: int) -> str:
    """Get emoji for weather code."""
    if code == 0:
        return "☀️"
    elif code in [1, 2]:
        return "🌤️"
    elif code == 3:
        return "☁️"
    elif code in [45, 48]:
        return "🌫️"
    elif code in [51, 53, 55, 56, 57]:
        return "🌦️"
    elif code in [61, 63, 65, 66, 67, 80, 81, 82]:
        return "🌧️"
    elif code in [71, 73, 75, 77, 85, 86]:
        return "🌨️"
    elif code in [95, 96, 99]:
        return "⛈️"
    return "🌡️"


def format_forecast(data: Dict[str, Any], location: str, days: int) -> str:
    """Format forecast for display."""
    daily = data.get("daily", {})
    
    dates = daily.get("time", [])
    codes = daily.get("weather_code", [])
    max_temps = daily.get("temperature_2m_max", [])
    min_temps = daily.get("temperature_2m_min", [])
    precip = daily.get("precipitation_sum", [])
    precip_prob = daily.get("precipitation_probability_max", [])
    wind = daily.get("wind_speed_10m_max", [])
    
    lines = [f"Weather Forecast for {location}", "=" * 40, ""]
    
    for i in range(min(len(dates), days)):
        date = dates[i]
        code = codes[i] if i < len(codes) else 0
        max_temp = max_temps[i] if i < len(max_temps) else 0
        min_temp = min_temps[i] if i < len(min_temps) else 0
        rain = precip[i] if i < len(precip) else 0
        rain_prob = precip_prob[i] if i < len(precip_prob) else 0
        wind_speed = wind[i] if i < len(wind) else 0
        
        emoji = get_weather_emoji(code)
        description = get_weather_description(code)
        
        # Format date nicely
        try:
            dt = datetime.strptime(date, "%Y-%m-%d")
            date_str = dt.strftime("%A, %b %d")
        except:
            date_str = date
        
        lines.append(f"{emoji} {date_str}")
        lines.append(f"   {description}")
        lines.append(f"   High: {max_temp:.1f}°C  Low: {min_temp:.1f}°C")
        
        if rain > 0:
            lines.append(f"   💧 Precipitation: {rain:.1f}mm ({rain_prob}%)")
        
        lines.append(f"   💨 Wind: {wind_speed:.1f} km/h")
        lines.append("")
    
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="Get weather forecast")
    parser.add_argument("location", help="City name or location")
    parser.add_argument("--days", "-d", type=int, default=7, 
                       help="Number of days (1-16, default: 7)")
    parser.add_argument("--json", "-j", action="store_true", help="Output as JSON")
    
    args = parser.parse_args()
    
    # Validate days
    days = max(1, min(16, args.days))
    
    # Get coordinates
    lat, lon, name = geocode_location(args.location)
    
    # Get forecast
    forecast_data = get_forecast(lat, lon, days)
    
    if args.json:
        output = {
            "location": name,
            "latitude": lat,
            "longitude": lon,
            "forecast": forecast_data.get("daily", {})
        }
        print(json.dumps(output, indent=2))
    else:
        print(format_forecast(forecast_data, name, days))


if __name__ == "__main__":
    main()
