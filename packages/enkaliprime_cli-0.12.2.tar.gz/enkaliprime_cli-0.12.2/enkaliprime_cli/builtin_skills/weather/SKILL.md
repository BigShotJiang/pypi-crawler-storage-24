---
name: weather
description: Get current weather information and forecasts for any location. Use when user asks about weather conditions, forecasts, or temperature.
version: 1.0.0
author: EnkaliPrime CLI
tags: [weather, forecast, location, environment]
---

# Weather Skill

Provides current weather information and forecasts using OpenWeatherMap API (or similar free tier services).

## Capabilities

- Current weather for any city
- Temperature, humidity, wind conditions
- Weather forecasts
- Location-based queries

## When to Use

Use this skill when the user asks:
- "What's the weather in [city]?"
- "Is it going to rain today?"
- "Temperature in [location]"
- "Weather forecast"

## Scripts

- `get_weather.py` - Get current weather for a location
- `forecast.py` - Get weather forecast

## Configuration

Uses Open-Meteo API (free, no API key required) or can use OpenWeatherMap with API key.

## Examples

"What's the weather in London?"
"Weather forecast for Tokyo"
"Is it hot in Dubai right now?"
