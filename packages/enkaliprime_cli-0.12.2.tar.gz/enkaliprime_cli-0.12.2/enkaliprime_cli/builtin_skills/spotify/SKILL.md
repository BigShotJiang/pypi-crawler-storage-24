---
name: spotify
description: Interact with Spotify - search tracks, albums, artists, get recommendations, and manage playlists. Use when user mentions music, Spotify, songs, artists, or playlists.
version: 1.0.0
author: EnkaliPrime CLI
tags: [spotify, music, entertainment, streaming]
---

# Spotify Skill

Provides integration with Spotify Web API for music discovery and management.

## Capabilities

- Search for tracks, albums, and artists
- Get music recommendations
- View user's top tracks and artists
- Manage playlists
- Get currently playing track

## When to Use

Use this skill when the user asks:
- "Search Spotify for..."
- "Find songs by..."
- "Get music recommendations"
- "What's my top music?"
- "Create a playlist"

## Scripts

- `search.py` - Search tracks, albums, artists
- `recommendations.py` - Get personalized recommendations
- `now_playing.py` - Get currently playing track

## Configuration

Requires Spotify app credentials:
- `SPOTIFY_CLIENT_ID` - Client ID from Spotify Developer Dashboard
- `SPOTIFY_CLIENT_SECRET` - Client Secret
- `SPOTIFY_REDIRECT_URI` - OAuth redirect URI

## Examples

"Search Spotify for Bohemian Rhapsody"
"Get recommendations based on rock music"
"What's currently playing?"
