#!/usr/bin/env python3
"""
Search Spotify for tracks, albums, and artists.

Usage: search.py <query> [--type track|album|artist] [--limit 10]
"""

import argparse
import base64
import json
import os
import sys
from typing import Dict, List, Any, Optional

import requests

SPOTIFY_API_BASE = "https://api.spotify.com/v1"
SPOTIFY_AUTH_URL = "https://accounts.spotify.com/api/token"


def get_credentials() -> tuple:
    """Get Spotify credentials from environment."""
    client_id = os.environ.get("SPOTIFY_CLIENT_ID")
    client_secret = os.environ.get("SPOTIFY_CLIENT_SECRET")
    
    if not client_id or not client_secret:
        print("Error: SPOTIFY_CLIENT_ID and SPOTIFY_CLIENT_SECRET required", file=sys.stderr)
        print("Get credentials at: https://developer.spotify.com/dashboard", file=sys.stderr)
        sys.exit(1)
    
    return client_id, client_secret


def get_access_token() -> str:
    """Get Spotify access token (client credentials flow)."""
    client_id, client_secret = get_credentials()
    
    auth_string = base64.b64encode(f"{client_id}:{client_secret}".encode()).decode()
    
    headers = {
        "Authorization": f"Basic {auth_string}",
        "Content-Type": "application/x-www-form-urlencoded"
    }
    
    data = {"grant_type": "client_credentials"}
    
    try:
        response = requests.post(SPOTIFY_AUTH_URL, headers=headers, data=data, timeout=30)
        response.raise_for_status()
        token_data = response.json()
        return token_data.get("access_token", "")
    except requests.exceptions.RequestException as e:
        print(f"Error getting access token: {e}", file=sys.stderr)
        sys.exit(1)


def get_headers() -> Dict[str, str]:
    """Get API request headers with access token."""
    token = get_access_token()
    return {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }


def search_spotify(query: str, search_type: str = "track", limit: int = 10) -> Dict[str, Any]:
    """Search Spotify.
    
    Args:
        query: Search query
        search_type: Type to search (track, album, artist)
        limit: Number of results
        
    Returns:
        Search results
    """
    url = f"{SPOTIFY_API_BASE}/search"
    
    params = {
        "q": query,
        "type": search_type,
        "limit": limit
    }
    
    try:
        response = requests.get(url, headers=get_headers(), params=params, timeout=30)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"Error searching Spotify: {e}", file=sys.stderr)
        sys.exit(1)


def format_track(track: Dict[str, Any]) -> str:
    """Format a track result."""
    name = track.get("name", "Unknown")
    artists = ", ".join([a.get("name", "") for a in track.get("artists", [])])
    album = track.get("album", {}).get("name", "Unknown Album")
    duration_ms = track.get("duration_ms", 0)
    duration = f"{duration_ms // 60000}:{(duration_ms % 60000) // 1000:02d}"
    popularity = track.get("popularity", 0)
    url = track.get("external_urls", {}).get("spotify", "")
    
    return f"Track: {name}\n  Artist(s): {artists}\n  Album: {album}\n  Duration: {duration}\n  Popularity: {popularity}/100\n  URL: {url}"


def format_artist(artist: Dict[str, Any]) -> str:
    """Format an artist result."""
    name = artist.get("name", "Unknown")
    genres = ", ".join(artist.get("genres", [])[:3])
    popularity = artist.get("popularity", 0)
    followers = artist.get("followers", {}).get("total", 0)
    url = artist.get("external_urls", {}).get("spotify", "")
    
    result = f"Artist: {name}\n  Popularity: {popularity}/100\n  Followers: {followers:,}\n  URL: {url}"
    if genres:
        result = f"{result}\n  Genres: {genres}"
    return result


def format_album(album: Dict[str, Any]) -> str:
    """Format an album result."""
    name = album.get("name", "Unknown")
    artists = ", ".join([a.get("name", "") for a in album.get("artists", [])])
    release_date = album.get("release_date", "Unknown")
    total_tracks = album.get("total_tracks", 0)
    url = album.get("external_urls", {}).get("spotify", "")
    
    return f"Album: {name}\n  Artist(s): {artists}\n  Released: {release_date}\n  Tracks: {total_tracks}\n  URL: {url}"


def main():
    parser = argparse.ArgumentParser(description="Search Spotify")
    parser.add_argument("query", help="Search query")
    parser.add_argument("--type", "-t", choices=["track", "album", "artist"], 
                       default="track", help="Type to search")
    parser.add_argument("--limit", "-l", type=int, default=10, help="Number of results")
    parser.add_argument("--json", "-j", action="store_true", help="Output as JSON")
    
    args = parser.parse_args()
    
    results = search_spotify(args.query, args.type, args.limit)
    
    if args.json:
        print(json.dumps(results, indent=2))
        return
    
    items_key = f"{args.type}s"
    items = results.get(items_key, {}).get("items", [])
    
    if not items:
        print(f"No {args.type}s found for '{args.query}'")
        return
    
    print(f"Found {len(items)} {args.type}(s) for '{args.query}':\n")
    
    for i, item in enumerate(items, 1):
        if args.type == "track":
            print(f"{i}. {format_track(item)}")
        elif args.type == "artist":
            print(f"{i}. {format_artist(item)}")
        elif args.type == "album":
            print(f"{i}. {format_album(item)}")
        print()


if __name__ == "__main__":
    main()
