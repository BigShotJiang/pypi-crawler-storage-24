#!/usr/bin/env python3
"""
Get currently playing track on Spotify (requires user authentication).

Note: This requires user OAuth token, not just client credentials.
Usage: now_playing.py
"""

import argparse
import json
import os
import sys
from typing import Dict, Any, Optional

import requests

SPOTIFY_API_BASE = "https://api.spotify.com/v1"


def get_user_token() -> str:
    """Get user access token from environment."""
    token = os.environ.get("SPOTIFY_USER_TOKEN")
    if not token:
        print("Error: SPOTIFY_USER_TOKEN required for user-specific data", file=sys.stderr)
        print("This requires user authentication flow (OAuth)", file=sys.stderr)
        sys.exit(1)
    return token


def get_now_playing() -> Optional[Dict[str, Any]]:
    """Get currently playing track."""
    url = f"{SPOTIFY_API_BASE}/me/player/currently-playing"
    
    headers = {"Authorization": f"Bearer {get_user_token()}"}
    
    try:
        response = requests.get(url, headers=headers, timeout=30)
        if response.status_code == 204:
            return None  # Nothing playing
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def format_playing(data: Dict[str, Any]) -> str:
    """Format currently playing info."""
    if not data or not data.get("item"):
        return "Nothing is currently playing."
    
    item = data.get("item", {})
    name = item.get("name", "Unknown")
    artists = ", ".join([a.get("name", "") for a in item.get("artists", [])])
    album = item.get("album", {}).get("name", "Unknown Album")
    is_playing = data.get("is_playing", False)
    progress_ms = data.get("progress_ms", 0)
    duration_ms = item.get("duration_ms", 0)
    
    progress = f"{progress_ms // 60000}:{(progress_ms % 60000) // 1000:02d}"
    duration = f"{duration_ms // 60000}:{(duration_ms % 60000) // 1000:02d}"
    
    status = "▶️ Playing" if is_playing else "⏸️ Paused"
    
    return f"{status}\nTrack: {name}\nArtist(s): {artists}\nAlbum: {album}\nProgress: {progress} / {duration}"


def main():
    parser = argparse.ArgumentParser(description="Get currently playing track")
    parser.add_argument("--json", "-j", action="store_true", help="Output as JSON")
    
    args = parser.parse_args()
    
    data = get_now_playing()
    
    if args.json:
        print(json.dumps(data or {}, indent=2))
    else:
        print(format_playing(data) if data else "Nothing is currently playing on Spotify.")


if __name__ == "__main__":
    main()
