#!/usr/bin/env python3
"""
Get Spotify recommendations based on seed tracks, artists, or genres.

Usage: recommendations.py [--seed-track <id>] [--seed-artist <id>] [--seed-genre <genre>]
"""

import argparse
import base64
import json
import os
import sys
from typing import Dict, List, Any

import requests

SPOTIFY_API_BASE = "https://api.spotify.com/v1"
SPOTIFY_AUTH_URL = "https://accounts.spotify.com/api/token"


def get_credentials() -> tuple:
    """Get Spotify credentials from environment."""
    client_id = os.environ.get("SPOTIFY_CLIENT_ID")
    client_secret = os.environ.get("SPOTIFY_CLIENT_SECRET")
    
    if not client_id or not client_secret:
        print("Error: SPOTIFY_CLIENT_ID and SPOTIFY_CLIENT_SECRET required", file=sys.stderr)
        sys.exit(1)
    
    return client_id, client_secret


def get_access_token() -> str:
    """Get Spotify access token."""
    client_id, client_secret = get_credentials()
    auth_string = base64.b64encode(f"{client_id}:{client_secret}".encode()).decode()
    
    headers = {
        "Authorization": f"Basic {auth_string}",
        "Content-Type": "application/x-www-form-urlencoded"
    }
    data = {"grant_type": "client_credentials"}
    
    try:
        response = requests.post(SPOTIFY_AUTH_URL, headers=headers, data=data, timeout=30)
        response.raise_for_status()
        return response.json().get("access_token", "")
    except requests.exceptions.RequestException as e:
        print(f"Error getting token: {e}", file=sys.stderr)
        sys.exit(1)


def get_recommendations(
    seed_tracks: List[str] = None,
    seed_artists: List[str] = None,
    seed_genres: List[str] = None,
    limit: int = 10
) -> List[Dict]:
    """Get Spotify recommendations.
    
    Args:
        seed_tracks: List of track IDs
        seed_artists: List of artist IDs
        seed_genres: List of genre names
        limit: Number of recommendations
        
    Returns:
        List of recommended tracks
    """
    url = f"{SPOTIFY_API_BASE}/recommendations"
    
    params = {"limit": limit}
    
    if seed_tracks:
        params["seed_tracks"] = ",".join(seed_tracks[:5])
    if seed_artists:
        params["seed_artists"] = ",".join(seed_artists[:5])
    if seed_genres:
        params["seed_genres"] = ",".join(seed_genres[:5])
    
    if not any([seed_tracks, seed_artists, seed_genres]):
        # Default genre
        params["seed_genres"] = "pop"
    
    headers = {"Authorization": f"Bearer {get_access_token()}"}
    
    try:
        response = requests.get(url, headers=headers, params=params, timeout=30)
        response.raise_for_status()
        return response.json().get("tracks", [])
    except requests.exceptions.RequestException as e:
        print(f"Error getting recommendations: {e}", file=sys.stderr)
        sys.exit(1)


def format_track(track: Dict[str, Any]) -> str:
    """Format track information."""
    name = track.get("name", "Unknown")
    artists = ", ".join([a.get("name", "") for a in track.get("artists", [])])
    album = track.get("album", {}).get("name", "Unknown Album")
    url = track.get("external_urls", {}).get("spotify", "")
    
    return f"{name} by {artists}\n  Album: {album}\n  URL: {url}"


def main():
    parser = argparse.ArgumentParser(description="Get Spotify recommendations")
    parser.add_argument("--seed-track", action="append", help="Seed track ID (can use multiple)")
    parser.add_argument("--seed-artist", action="append", help="Seed artist ID (can use multiple)")
    parser.add_argument("--seed-genre", action="append", 
                       choices=[
                           "pop", "rock", "hip-hop", "electronic", "classical", "jazz",
                           "country", "r&b", "indie", "alternative", "metal", "blues",
                           "folk", "reggae", "punk", "soul", "funk", "disco", "ambient"
                       ],
                       help="Seed genre (can use multiple)")
    parser.add_argument("--limit", "-l", type=int, default=10, help="Number of recommendations")
    parser.add_argument("--json", "-j", action="store_true", help="Output as JSON")
    
    args = parser.parse_args()
    
    tracks = get_recommendations(
        seed_tracks=args.seed_track,
        seed_artists=args.seed_artist,
        seed_genres=args.seed_genre,
        limit=args.limit
    )
    
    if not tracks:
        print("No recommendations found.")
        return
    
    if args.json:
        print(json.dumps(tracks, indent=2))
    else:
        print(f"Recommendations ({len(tracks)} tracks):\n")
        for i, track in enumerate(tracks, 1):
            print(f"{i}. {format_track(track)}\n")


if __name__ == "__main__":
    main()
