#!/usr/bin/env python3
"""
Calculate duration between two dates or countdown to a specific date.

Usage: calculate_duration.py <date1> [<date2>]
       countdown.py --until "2024-12-25"
"""

import argparse
import sys
from datetime import datetime, timedelta
from typing import Optional


def parse_date(date_str: str) -> datetime:
    """Parse date string in various formats."""
    formats = [
        "%Y-%m-%d",
        "%Y-%m-%d %H:%M",
        "%Y-%m-%d %H:%M:%S",
        "%m/%d/%Y",
        "%d/%m/%Y",
        "%B %d, %Y",
        "%b %d, %Y",
    ]
    
    for fmt in formats:
        try:
            return datetime.strptime(date_str, fmt)
        except ValueError:
            continue
    
    # Try relative dates
    date_str_lower = date_str.lower().strip()
    today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    
    if date_str_lower == "today":
        return today
    elif date_str_lower == "tomorrow":
        return today + timedelta(days=1)
    elif date_str_lower == "yesterday":
        return today - timedelta(days=1)
    elif date_str_lower in ["christmas", "xmas"]:
        return today.replace(month=12, day=25)
    elif date_str_lower == "new year":
        return today.replace(year=today.year + 1, month=1, day=1)
    
    raise ValueError(f"Cannot parse date: {date_str}")


def calculate_duration(start: datetime, end: datetime) -> dict:
    """Calculate duration between two dates."""
    diff = end - start
    
    days = diff.days
    seconds = diff.seconds
    
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    secs = seconds % 60
    
    total_hours = days * 24 + hours
    total_minutes = total_hours * 60 + minutes
    total_seconds = total_minutes * 60 + secs
    
    # Calculate months and years (approximate)
    months = 0
    years = 0
    
    temp_date = start
    while temp_date < end:
        if temp_date.month == 12:
            temp_date = temp_date.replace(year=temp_date.year + 1, month=1)
        else:
            temp_date = temp_date.replace(month=temp_date.month + 1)
        if temp_date <= end:
            months += 1
    
    years = months // 12
    months = months % 12
    
    return {
        "years": years,
        "months": months,
        "days": days,
        "hours": hours,
        "minutes": minutes,
        "seconds": secs,
        "total_days": days,
        "total_hours": total_hours,
        "total_minutes": total_minutes,
        "total_seconds": total_seconds,
        "is_future": end > start
    }


def format_duration(duration: dict, compact: bool = False) -> str:
    """Format duration for display."""
    if compact:
        parts = []
        if duration["years"] > 0:
            parts.append(f"{duration['years']}y")
        if duration["months"] > 0:
            parts.append(f"{duration['months']}m")
        if duration["days"] > 0:
            parts.append(f"{duration['days']}d")
        if duration["hours"] > 0:
            parts.append(f"{duration['hours']}h")
        if duration["minutes"] > 0:
            parts.append(f"{duration['minutes']}m")
        return " ".join(parts) if parts else "0m"
    
    parts = []
    if duration["years"] > 0:
        parts.append(f"{duration['years']} year{'s' if duration['years'] != 1 else ''}")
    if duration["months"] > 0:
        parts.append(f"{duration['months']} month{'s' if duration['months'] != 1 else ''}")
    if duration["days"] > 0:
        parts.append(f"{duration['days']} day{'s' if duration['days'] != 1 else ''}")
    if duration["hours"] > 0:
        parts.append(f"{duration['hours']} hour{'s' if duration['hours'] != 1 else ''}")
    if duration["minutes"] > 0:
        parts.append(f"{duration['minutes']} minute{'s' if duration['minutes'] != 1 else ''}")
    
    return ", ".join(parts) if parts else "less than a minute"


def main():
    parser = argparse.ArgumentParser(description="Calculate duration between dates")
    parser.add_argument("date1", help="Start date (YYYY-MM-DD or 'today', 'tomorrow')")
    parser.add_argument("date2", nargs="?", help="End date (default: now)")
    parser.add_argument("--until", "-u", action="store_true", help="Countdown mode (date1 is target)")
    parser.add_argument("--since", "-s", action="store_true", help="Time elapsed since date1")
    parser.add_argument("--compact", "-c", action="store_true", help="Compact output")
    
    args = parser.parse_args()
    
    try:
        date1 = parse_date(args.date1)
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    
    if args.until:
        # Countdown mode
        date2 = datetime.now()
        duration = calculate_duration(date2, date1)
        if not duration["is_future"]:
            print(f"{format_duration(duration, args.compact)} ago")
        else:
            print(f"{format_duration(duration, args.compact)} remaining")
    elif args.since:
        # Time elapsed mode
        date2 = datetime.now()
        duration = calculate_duration(date1, date2)
        print(f"{format_duration(duration, args.compact)} ago")
    else:
        # Duration between two dates
        if args.date2:
            try:
                date2 = parse_date(args.date2)
            except ValueError as e:
                print(f"Error parsing date2: {e}", file=sys.stderr)
                sys.exit(1)
        else:
            date2 = datetime.now()
        
        duration = calculate_duration(date1, date2)
        direction = "after" if duration["is_future"] else "before"
        print(f"{format_duration(duration, args.compact)} {direction}")
    
    # Also show raw numbers
    if not args.compact:
        print(f"\nTotal: {duration['total_days']} days, {duration['total_hours']} hours, {duration['total_minutes']} minutes")


if __name__ == "__main__":
    main()
