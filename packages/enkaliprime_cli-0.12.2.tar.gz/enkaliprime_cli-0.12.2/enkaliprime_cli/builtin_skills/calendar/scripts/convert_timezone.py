#!/usr/bin/env python3
"""
Convert times between timezones.

Usage: convert_timezone.py <time> --from <timezone> --to <timezone>
       convert_timezone.py --now --to <timezone>
"""

import argparse
import sys
from datetime import datetime
from typing import Optional

try:
    from zoneinfo import ZoneInfo, available_timezones
except ImportError:
    try:
        from backports.zoneinfo import ZoneInfo, available_timezones
    except ImportError:
        print("Error: zoneinfo not available. Install with: pip install backports.zoneinfo", file=sys.stderr)
        sys.exit(1)


def parse_time(time_str: str) -> datetime:
    """Parse time string in various formats."""
    formats = [
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d %H:%M",
        "%H:%M:%S",
        "%H:%M",
    ]
    
    now = datetime.now()
    
    for fmt in formats:
        try:
            parsed = datetime.strptime(time_str, fmt)
            # If no date provided, use today
            if fmt in ["%H:%M:%S", "%H:%M"]:
                parsed = parsed.replace(year=now.year, month=now.month, day=now.day)
            return parsed
        except ValueError:
            continue
    
    raise ValueError(f"Cannot parse time: {time_str}")


def convert_timezone(dt: datetime, from_tz: str, to_tz: str) -> datetime:
    """Convert datetime between timezones."""
    try:
        from_zone = ZoneInfo(from_tz)
        to_zone = ZoneInfo(to_tz)
    except Exception as e:
        print(f"Error: Invalid timezone - {e}", file=sys.stderr)
        print(f"Common timezones: UTC, US/Eastern, US/Pacific, Europe/London, Asia/Tokyo", file=sys.stderr)
        sys.exit(1)
    
    # Localize to source timezone
    dt_with_tz = dt.replace(tzinfo=from_zone)
    
    # Convert to target timezone
    return dt_with_tz.astimezone(to_zone)


def format_output(dt: datetime, timezone: str) -> str:
    """Format datetime output."""
    return f"{dt.strftime('%Y-%m-%d %H:%M:%S')} {timezone} ({dt.strftime('%A')})"


def main():
    parser = argparse.ArgumentParser(description="Convert times between timezones")
    parser.add_argument("time", nargs="?", help="Time to convert (HH:MM or YYYY-MM-DD HH:MM)")
    parser.add_argument("--from", "-f", dest="from_tz", default="UTC", help="Source timezone")
    parser.add_argument("--to", "-t", required=True, help="Target timezone")
    parser.add_argument("--now", "-n", action="store_true", help="Use current time")
    parser.add_argument("--list", "-l", action="store_true", help="List common timezones")
    
    args = parser.parse_args()
    
    if args.list:
        print("Common timezones:")
        common = ["UTC", "US/Eastern", "US/Central", "US/Mountain", "US/Pacific",
                 "Europe/London", "Europe/Paris", "Europe/Berlin",
                 "Asia/Tokyo", "Asia/Shanghai", "Asia/Dubai", "Asia/Singapore",
                 "Australia/Sydney", "Pacific/Auckland"]
        for tz in common:
            print(f"  {tz}")
        return
    
    if args.now:
        source_dt = datetime.now()
    elif args.time:
        try:
            source_dt = parse_time(args.time)
        except ValueError as e:
            print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)
    else:
        print("Error: Provide a time or use --now", file=sys.stderr)
        parser.print_help()
        sys.exit(1)
    
    result = convert_timezone(source_dt, args.from_tz, args.to)
    
    print(f"From: {format_output(source_dt, args.from_tz)}")
    print(f"To:   {format_output(result, args.to)}")
    
    # Show time difference
    diff_hours = int((result.utcoffset() or timedelta(0)).total_seconds() / 3600) - \
                 int((source_dt.replace(tzinfo=ZoneInfo(args.from_tz)).utcoffset() or timedelta(0)).total_seconds() / 3600)
    if diff_hours != 0:
        direction = "ahead" if diff_hours > 0 else "behind"
        print(f"\nDifference: {abs(diff_hours)} hours {direction}")


if __name__ == "__main__":
    from datetime import timedelta
    main()
