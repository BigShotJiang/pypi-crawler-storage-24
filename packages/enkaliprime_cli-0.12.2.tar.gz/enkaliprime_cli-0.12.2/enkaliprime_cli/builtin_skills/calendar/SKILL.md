---
name: calendar
description: Date and time utilities - convert timezones, calculate dates, format timestamps, countdowns. Use when user needs time calculations or date formatting.
version: 1.0.0
author: EnkaliPrime CLI
tags: [calendar, date, time, timezone, utility]
---

# Calendar Skill

Provides date and time utilities for working with timestamps, timezones, and date calculations.

## Capabilities

- Convert between timezones
- Calculate date differences
- Format dates in various formats
- Parse natural language dates
- Countdown timers
- Business days calculation

## When to Use

Use this skill when the user asks:
- "What time is it in Tokyo?"
- "Convert 3pm EST to GMT"
- "How many days until..."
- "Format this timestamp"
- "What's the date next Friday?"

## Scripts

- `convert_timezone.py` - Convert times between timezones
- `calculate_duration.py` - Calculate time between dates
- `format_date.py` - Format dates in various formats
- `countdown.py` - Countdown to specific dates

## Examples

"What time is it in London right now?"
"Convert 2024-01-15 14:30 UTC to PST"
"How many days until Christmas?"
"Format today's date as YYYY-MM-DD"
