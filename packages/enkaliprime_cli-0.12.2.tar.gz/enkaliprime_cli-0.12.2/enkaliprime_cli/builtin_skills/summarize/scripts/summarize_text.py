#!/usr/bin/env python3
"""
Summarize text content using extractive summarization.

Usage: summarize_text.py --file path/to/file [--style brief|detailed|bullets]
       summarize_text.py --text "Text to summarize" [--style brief]
"""

import argparse
import re
import sys
from pathlib import Path
from typing import List, Dict
from collections import Counter


def read_input(source: str, is_file: bool = True) -> str:
    """Read input from file or string."""
    if is_file:
        path = Path(source)
        if not path.exists():
            print(f"Error: File not found: {source}", file=sys.stderr)
            sys.exit(1)
        return path.read_text(encoding='utf-8')
    return source


def simple_tokenize(text: str) -> List[str]:
    """Simple word tokenization."""
    return re.findall(r'\b[a-zA-Z]+\b', text.lower())


def sent_tokenize(text: str) -> List[str]:
    """Simple sentence tokenization."""
    # Split on sentence endings
    sentences = re.split(r'(?<=[.!?])\s+', text)
    return [s.strip() for s in sentences if len(s.strip()) > 10]


def score_sentences(sentences: List[str], word_freq: Dict[str, int]) -> List[tuple]:
    """Score sentences based on word frequency."""
    scored = []
    for sent in sentences:
        words = simple_tokenize(sent)
        if not words:
            continue
        score = sum(word_freq.get(word, 0) for word in words) / len(words)
        scored.append((sent, score))
    return scored


def summarize_extractive(text: str, ratio: float = 0.2, min_sentences: int = 2) -> str:
    """Extractive summarization using word frequency scoring."""
    
    # Tokenize
    sentences = sent_tokenize(text)
    words = simple_tokenize(text)
    
    if len(sentences) <= min_sentences:
        return text
    
    # Calculate word frequencies
    word_freq = Counter(words)
    
    # Score sentences
    scored_sentences = score_sentences(sentences, word_freq)
    scored_sentences.sort(key=lambda x: x[1], reverse=True)
    
    # Select top sentences
    num_sentences = max(min_sentences, int(len(sentences) * ratio))
    top_sentences = scored_sentences[:num_sentences]
    
    # Restore original order
    top_sentences_dict = {s: i for i, (s, _) in enumerate(top_sentences)}
    ordered_sentences = [(s, top_sentences_dict[s]) for s in sentences if s in top_sentences_dict]
    ordered_sentences.sort(key=lambda x: x[1])
    
    summary = ' '.join(s for s, _ in ordered_sentences)
    return summary


def summarize_to_bullets(text: str, num_points: int = 5) -> str:
    """Create bullet-point summary."""
    
    sentences = sent_tokenize(text)
    words = simple_tokenize(text)
    
    if len(sentences) <= num_points:
        bullets = [f"• {s}" for s in sentences]
        return '\n'.join(bullets)
    
    # Calculate word frequencies
    word_freq = Counter(words)
    
    # Score and select top sentences
    scored = score_sentences(sentences, word_freq)
    scored.sort(key=lambda x: x[1], reverse=True)
    
    top_sentences = [s for s, _ in scored[:num_points]]
    
    # Restore order
    ordered = [s for s in sentences if s in top_sentences]
    
    bullets = [f"• {s}" for s in ordered]
    return '\n'.join(bullets)


def main():
    parser = argparse.ArgumentParser(description="Summarize text content")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--file", "-f", help="Path to file to summarize")
    group.add_argument("--text", "-t", help="Text string to summarize")
    
    parser.add_argument("--style", "-s", 
                       choices=["brief", "detailed", "bullets"],
                       default="brief",
                       help="Summary style")
    parser.add_argument("--ratio", "-r", type=float, default=0.2,
                       help="Compression ratio (0.1-0.5)")
    parser.add_argument("--points", "-p", type=int, default=5,
                       help="Number of bullet points")
    
    args = parser.parse_args()
    
    # Read input
    source = args.file if args.file else args.text
    text = read_input(source, is_file=args.file is not None)
    
    if not text.strip():
        print("Error: No text content to summarize", file=sys.stderr)
        sys.exit(1)
    
    # Generate summary
    if args.style == "bullets":
        summary = summarize_to_bullets(text, args.points)
    elif args.style == "detailed":
        summary = summarize_extractive(text, ratio=0.3, min_sentences=3)
    else:  # brief
        summary = summarize_extractive(text, ratio=0.15, min_sentences=1)
        # Further condense brief summary
        if len(sent_tokenize(summary)) > 2:
            summary = summarize_extractive(summary, ratio=0.5, min_sentences=1)
    
    print(summary)


if __name__ == "__main__":
    main()
