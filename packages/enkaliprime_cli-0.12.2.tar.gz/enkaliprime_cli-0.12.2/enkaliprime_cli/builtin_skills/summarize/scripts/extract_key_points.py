#!/usr/bin/env python3
"""
Extract key points from text content as bullet points.

Usage: extract_key_points.py --file path/to/file [--count 5]
       extract_key_points.py --text "Text to analyze" [--count 5]
"""

import argparse
import re
import sys
from pathlib import Path
from typing import List, Dict, Tuple
from collections import Counter


def read_input(source: str, is_file: bool = True) -> str:
    """Read input from file or string."""
    if is_file:
        path = Path(source)
        if not path.exists():
            print(f"Error: File not found: {source}", file=sys.stderr)
            sys.exit(1)
        return path.read_text(encoding='utf-8')
    return source


def simple_tokenize(text: str) -> List[str]:
    """Simple word tokenization."""
    return re.findall(r'\b[a-zA-Z]+\b', text.lower())


def sent_tokenize(text: str) -> List[str]:
    """Simple sentence tokenization."""
    sentences = re.split(r'(?<=[.!?])\s+', text)
    return [s.strip() for s in sentences if len(s.strip()) > 15]


def extract_keywords(text: str, top_n: int = 10) -> List[str]:
    """Extract important keywords from text."""
    words = simple_tokenize(text)
    
    # Filter common stop words
    stop_words = {
        'the', 'a', 'an', 'is', 'are', 'was', 'were', 'be', 'been', 'being',
        'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could',
        'should', 'may', 'might', 'must', 'shall', 'can', 'need', 'dare',
        'ought', 'used', 'to', 'of', 'in', 'for', 'on', 'with', 'at', 'by',
        'from', 'as', 'into', 'through', 'during', 'before', 'after',
        'above', 'below', 'between', 'under', 'again', 'further', 'then', 'once',
        'here', 'there', 'when', 'where', 'why', 'how', 'all', 'any', 'both',
        'each', 'few', 'more', 'most', 'other', 'some', 'such', 'no', 'nor',
        'not', 'only', 'own', 'same', 'so', 'than', 'too', 'very', 'just',
        'and', 'but', 'if', 'or', 'because', 'as', 'until', 'while',
        'this', 'that', 'these', 'those', 'i', 'me', 'my', 'myself', 'we',
        'our', 'ours', 'ourselves', 'you', 'your', 'yours', 'yourself',
        'yourselves', 'he', 'him', 'his', 'himself', 'she', 'her', 'hers',
        'herself', 'it', 'its', 'itself', 'they', 'them', 'their', 'theirs',
        'themselves', 'what', 'which', 'who', 'whom', 'whose', 'this',
        'that', 'these', 'those', 'am', 'are', 'was', 'were', 'been',
        'have', 'has', 'had', 'do', 'does', 'did', 'doing'
    }
    
    filtered = [w for w in words if w not in stop_words and len(w) > 2]
    freq = Counter(filtered)
    return [word for word, count in freq.most_common(top_n)]


def score_sentence(sentence: str, word_freq: Dict[str, int], keywords: List[str]) -> float:
    """Score a sentence based on keywords and position."""
    words = simple_tokenize(sentence)
    
    if not words:
        return 0
    
    # Word frequency score
    freq_score = sum(word_freq.get(word, 0) for word in words) / len(words)
    
    # Keyword presence score
    keyword_count = sum(1 for kw in keywords if kw in words)
    keyword_score = keyword_count / len(keywords) if keywords else 0
    
    # Length factor (prefer medium-length sentences)
    length_factor = 1.0
    if len(words) < 5:
        length_factor = 0.5
    elif len(words) > 25:
        length_factor = 0.8
    
    # Bonus for sentences starting with key indicators
    indicators = ['first', 'second', 'third', 'finally', 'important', 'key',
                  'main', 'primary', 'significant', 'crucial', 'essential',
                  'remember', 'note', 'conclusion', 'summary', 'result',
                  'therefore', 'thus', 'consequently', 'however', 'furthermore']
    
    first_words = words[:3]
    indicator_bonus = 0
    for indicator in indicators:
        if indicator in first_words:
            indicator_bonus = 0.3
            break
    
    return (freq_score * 0.3 + keyword_score * 0.5 + length_factor * 0.2 + indicator_bonus)


def extract_key_points(text: str, num_points: int = 5) -> List[str]:
    """Extract key points from text."""
    sentences = sent_tokenize(text)
    
    if len(sentences) <= num_points:
        return sentences
    
    # Extract keywords
    keywords = extract_keywords(text, top_n=15)
    
    # Calculate word frequencies
    words = simple_tokenize(text)
    word_freq = Counter(words)
    
    # Score all sentences
    scored_sentences = []
    for i, sent in enumerate(sentences):
        score = score_sentence(sent, word_freq, keywords)
        # Boost first and last sentences slightly (often contain key info)
        if i == 0 or i == len(sentences) - 1:
            score *= 1.1
        scored_sentences.append((sent, score))
    
    # Sort by score and get top N
    scored_sentences.sort(key=lambda x: x[1], reverse=True)
    top_sentences = scored_sentences[:num_points]
    
    # Restore original order
    original_indices = []
    for sent, score in top_sentences:
        original_indices.append(sentences.index(sent))
    
    ordered = sorted(zip(original_indices, [s for s, _ in top_sentences]))
    
    return [sent for _, sent in ordered]


def format_points(points: List[str]) -> str:
    """Format points as bullet list."""
    if not points:
        return "No key points extracted."
    
    formatted = []
    for i, point in enumerate(points, 1):
        # Clean up the sentence
        point = point.strip()
        if point and point[0].islower():
            point = point[0].upper() + point[1:]
        
        formatted.append(f"{i}. {point}")
    
    return "\n".join(formatted)


def main():
    parser = argparse.ArgumentParser(description="Extract key points from text")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--file", "-f", help="Path to file to analyze")
    group.add_argument("--text", "-t", help="Text string to analyze")
    
    parser.add_argument("--count", "-c", type=int, default=5,
                       help="Number of key points to extract")
    parser.add_argument("--min-length", "-m", type=int, default=100,
                       help="Minimum text length to process")
    
    args = parser.parse_args()
    
    # Read input
    source = args.file if args.file else args.text
    text = read_input(source, is_file=args.file is not None)
    
    if len(text.strip()) < args.min_length:
        print(f"Error: Text too short (minimum {args.min_length} characters)", file=sys.stderr)
        sys.exit(1)
    
    # Extract key points
    points = extract_key_points(text, args.count)
    
    print(f"Key Points ({len(points)} of {args.count} requested):\n")
    print(format_points(points))


if __name__ == "__main__":
    main()
