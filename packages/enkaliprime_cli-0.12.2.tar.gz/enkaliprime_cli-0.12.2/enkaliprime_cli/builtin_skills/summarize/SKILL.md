---
name: summarize
description: Summarize text content, documents, conversations, or long-form content. Use when user needs a summary, TL;DR, or condensed version of information.
version: 1.0.0
author: EnkaliPrime CLI
tags: [summarize, text-processing, content, nlp]
---

# Summarize Skill

Provides text summarization capabilities for documents, conversations, web pages, and long-form content.

## Capabilities

- Summarize long text content
- Extract key points from documents
- Create TL;DR summaries
- Summarize conversations or chat history
- Generate bullet-point summaries

## When to Use

Use this skill when the user asks:
- "Summarize this"
- "Give me a TL;DR"
- "What are the key points?"
- "Can you condense this?"
- "Summarize the conversation"

## Summarization Types

1. **Brief** - 1-2 sentence summary
2. **Key Points** - Bullet points of main ideas
3. **Detailed** - Paragraph summary with context
4. **Executive Summary** - Business-focused summary

## Scripts

- `summarize_text.py` - Text summarization with options
- `extract_key_points.py` - Extract key points as bullets

## Examples

"Summarize this long article for me"
"Give me the key points from this document"
"TL;DR this conversation"
"Create an executive summary"
