"""
WhatsApp Bridge Manager - Auto-download/build whatsmeow binary.

Handles acquiring the whatsmeow Go binary transparently:
1. Check if already exists
2. Download pre-built binary for platform (if available)
3. Build from source if Go is installed
4. Provide clear instructions if manual setup needed
"""

import os
import platform
import shutil
import subprocess
import sys
import tarfile
import zipfile
from pathlib import Path
from typing import Optional, Tuple
from urllib.request import urlopen
from urllib.error import URLError

from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

console = Console()


class BridgeManager:
    """Manages the whatsmeow bridge binary for WhatsApp integration."""
    
    # Pre-built binary URLs (could host these on GitHub releases)
    PREBUILT_URLS = {
        ("windows", "amd64"): "https://github.com/tulir/whatsmeow/releases/download/v0.1.0/whatsmeow-windows-amd64.exe",
        ("linux", "amd64"): "https://github.com/tulir/whatsmeow/releases/download/v0.1.0/whatsmeow-linux-amd64",
        ("darwin", "amd64"): "https://github.com/tulir/whatsmeow/releases/download/v0.1.0/whatsmeow-darwin-amd64",
        ("darwin", "arm64"): "https://github.com/tulir/whatsmeow/releases/download/v0.1.0/whatsmeow-darwin-arm64",
    }
    
    def __init__(self, install_dir: Optional[Path] = None):
        """Initialize bridge manager.
        
        Args:
            install_dir: Directory to store the bridge binary.
                        Defaults to ~/.enkaliprime/bin
        """
        if install_dir is None:
            install_dir = Path.home() / ".enkaliprime" / "bin"
        
        self.install_dir = Path(install_dir)
        self.install_dir.mkdir(parents=True, exist_ok=True)
        
        # Determine binary name based on platform
        self.binary_name = "whatsmeow-bridge.exe" if sys.platform == "win32" else "whatsmeow-bridge"
        self.binary_path = self.install_dir / self.binary_name
        
        # Detect platform
        self.system = platform.system().lower()
        self.machine = platform.machine().lower()
        
        # Normalize architecture names
        if self.machine in ("amd64", "x86_64", "x64"):
            self.arch = "amd64"
        elif self.machine in ("arm64", "aarch64"):
            self.arch = "arm64"
        else:
            self.arch = self.machine
    
    def get_binary_path(self) -> Optional[Path]:
        """Get path to bridge binary if it exists."""
        # Check our install directory
        if self.binary_path.exists():
            return self.binary_path
        
        # Check PATH
        if path := shutil.which("whatsmeow-bridge"):
            return Path(path)
        
        return None
    
    def ensure_bridge(self, force_build: bool = False) -> Optional[Path]:
        """Ensure bridge binary exists, downloading or building if needed.
        
        Returns:
            Path to binary if successful, None otherwise
        """
        # Check if already exists
        if existing := self.get_binary_path():
            console.print(f"[dim]Found whatsmeow bridge at: {existing}[/]")
            return existing
        
        console.print("[yellow]WhatsApp bridge not found. Acquiring...[/]")
        
        # Try to download pre-built binary
        if not force_build:
            if downloaded := self._download_prebuilt():
                return downloaded
        
        # Try to build from source
        if built := self._build_from_source():
            return built
        
        # Failed - provide instructions
        self._print_manual_instructions()
        return None
    
    def _download_prebuilt(self) -> Optional[Path]:
        """Download pre-built binary for current platform."""
        key = (self.system, self.arch)
        
        if key not in self.PREBUILT_URLS:
            console.print(f"[dim]No prebuilt binary for {self.system}/{self.arch}[/]")
            return None
        
        url = self.PREBUILT_URLS[key]
        
        try:
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console
            ) as progress:
                task = progress.add_task("Downloading whatsmeow bridge...", total=None)
                
                # Download
                response = urlopen(url, timeout=120)
                data = response.read()
                
                progress.update(task, description="Saving binary...")
                
                # Save
                self.binary_path.write_bytes(data)
                
                # Make executable on Unix
                if sys.platform != "win32":
                    self.binary_path.chmod(0o755)
                
                progress.update(task, description="[green]Downloaded successfully![/]")
            
            console.print(f"[green]✓ Bridge installed at: {self.binary_path}[/]")
            return self.binary_path
            
        except URLError as e:
            console.print(f"[yellow]Download failed: {e}[/]")
            return None
        except Exception as e:
            console.print(f"[yellow]Download error: {e}[/]")
            return None
    
    def _build_from_source(self) -> Optional[Path]:
        """Build bridge from source if Go is available."""
        # Check if Go is installed
        if not shutil.which("go"):
            console.print("[dim]Go not found, cannot build from source[/]")
            return None
        
        try:
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console
            ) as progress:
                # Create temp build directory
                build_dir = self.install_dir / "build"
                build_dir.mkdir(exist_ok=True)
                
                # Clone repository
                task = progress.add_task("Cloning whatsmeow repository...", total=None)
                
                result = subprocess.run(
                    ["git", "clone", "--depth", "1", "https://github.com/tulir/whatsmeow.git", str(build_dir)],
                    capture_output=True,
                    text=True,
                    timeout=120
                )
                
                if result.returncode != 0:
                    # Try updating if already exists
                    result = subprocess.run(
                        ["git", "-C", str(build_dir), "pull"],
                        capture_output=True,
                        text=True,
                        timeout=60
                    )
                    if result.returncode != 0:
                        console.print("[yellow]Git clone/pull failed[/]")
                        return None
                
                # Build
                progress.update(task, description="Building whatsmeow bridge...")
                
                result = subprocess.run(
                    ["go", "build", "-o", str(self.binary_path), "./cmd"],
                    cwd=build_dir,
                    capture_output=True,
                    text=True,
                    timeout=300
                )
                
                if result.returncode != 0:
                    console.print(f"[yellow]Build failed: {result.stderr}[/]")
                    return None
                
                # Make executable
                if sys.platform != "win32":
                    self.binary_path.chmod(0o755)
                
                progress.update(task, description="[green]Built successfully![/]")
            
            # Clean up build dir
            shutil.rmtree(build_dir, ignore_errors=True)
            
            console.print(f"[green]✓ Bridge built at: {self.binary_path}[/]")
            return self.binary_path
            
        except subprocess.TimeoutExpired:
            console.print("[yellow]Build timed out[/]")
            return None
        except Exception as e:
            console.print(f"[yellow]Build error: {e}[/]")
            return None
    
    def _print_manual_instructions(self) -> None:
        """Print manual setup instructions when auto-acquire fails."""
        console.print("""
[bold red]Could not automatically acquire whatsmeow bridge.[/bold red]

[bold]Manual Setup:[/bold]

1. Install Go from https://golang.org/dl/

2. Build the bridge:
   [dim]git clone https://github.com/tulir/whatsmeow
   cd whatsmeow
   go build -o whatsmeow-bridge ./cmd[/dim]

3. Move to PATH or enkaliprime bin:
   [dim]mv whatsmeow-bridge ~/.enkaliprime/bin/[/dim]
   -or-
   [dim]mv whatsmeow-bridge /usr/local/bin/[/dim]

4. Retry: [bold]enkaliprime channels connect whatsapp[/bold]
        """)
    
    def verify_bridge(self) -> bool:
        """Verify the bridge binary works."""
        if not (path := self.get_binary_path()):
            return False
        
        try:
            # Try to run with --help or --version
            result = subprocess.run(
                [str(path), "--help"],
                capture_output=True,
                text=True,
                timeout=10
            )
            return result.returncode == 0 or "whatsmeow" in result.stderr.lower()
        except:
            return False
    
    def get_version(self) -> Optional[str]:
        """Get bridge version if available."""
        if not (path := self.get_binary_path()):
            return None
        
        try:
            result = subprocess.run(
                [str(path), "--version"],
                capture_output=True,
                text=True,
                timeout=5
            )
            if result.returncode == 0:
                return result.stdout.strip()
        except:
            pass
        
        return None


def get_bridge_path() -> Optional[Path]:
    """Convenience function to get or acquire bridge binary."""
    manager = BridgeManager()
    return manager.ensure_bridge()


def verify_bridge_works() -> Tuple[bool, Optional[str]]:
    """Verify bridge is installed and working.
    
    Returns:
        (is_working, path_or_error_message)
    """
    manager = BridgeManager()
    
    path = manager.get_binary_path()
    if not path:
        return False, "Bridge not found"
    
    if manager.verify_bridge():
        return True, str(path)
    
    return False, f"Bridge at {path} does not work"
