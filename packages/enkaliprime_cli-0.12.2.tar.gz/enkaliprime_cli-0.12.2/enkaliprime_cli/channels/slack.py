"""Slack Channel - Slack Bot integration.

Implements Slack Socket Mode using Slack Bolt.

Notes:
- Tokens are stored in the channel config `extra` dict (persisted by channels.json).
- This channel is designed to fit the existing Channel interface used by GatewayService.
"""

from __future__ import annotations

import asyncio
import threading
import random
import sys
from datetime import datetime
from typing import Optional, AsyncIterator, Dict, Any, List

from rich.console import Console

from .base import Channel, ChannelType, ChannelConfig, ChannelMessage, MessageType, SendResult

console = Console()


class SlackChannel(Channel):
    """Slack channel implementation."""
    
    def __init__(self, config: ChannelConfig):
        super().__init__("slack", config)
        self._message_queue: asyncio.Queue[ChannelMessage] = asyncio.Queue()
        self._app = None
        self._handler = None
        self._client = None
        self._bot_token = config.api_token or config.extra.get("bot_token")
        self._app_token = config.extra.get("app_token")
        self._socket_mode = True
        self._bot_user_id: Optional[str] = None
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._channel_id_by_user: Dict[str, str] = {}
    
    @property
    def channel_type(self) -> ChannelType:
        return ChannelType.SLACK
    
    async def connect(self) -> bool:
        """Connect to Slack."""
        self._loop = asyncio.get_running_loop()
        if not self._bot_token:
            console.print("[red]Slack bot token not configured[/]")
            return False

        if not self._app_token:
            console.print("[red]Slack app token not configured (Socket Mode requires xapp-...)[/]")
            return False
        
        try:
            App = None
            AsyncApp = None
            try:
                from slack_bolt.async_app import AsyncApp as _AsyncApp
                AsyncApp = _AsyncApp
            except Exception:
                AsyncApp = None

            if AsyncApp is None:
                from slack_bolt import App as _App
                App = _App

            SocketModeHandler = None
            AsyncSocketModeHandler = None
            async_import_error: Optional[BaseException] = None
            try:
                from slack_bolt.adapter.socket_mode.async_handler import AsyncSocketModeHandler as _AsyncSocketModeHandler
                AsyncSocketModeHandler = _AsyncSocketModeHandler
            except Exception:
                async_import_error = sys.exc_info()[1]
                try:
                    from slack_bolt.adapter.socket_mode.aiohttp import (
                        AsyncSocketModeHandler as _AsyncSocketModeHandler,
                    )
                    AsyncSocketModeHandler = _AsyncSocketModeHandler
                except Exception:
                    async_import_error = sys.exc_info()[1]
                    AsyncSocketModeHandler = None

            if AsyncSocketModeHandler is None:
                if sys.platform == "win32":
                    extra_hint = "Install Slack channel extras (aiohttp) and retry. Example: pip install -e .[channels]"
                    if async_import_error and isinstance(async_import_error, ModuleNotFoundError):
                        console.print(f"[red]Missing dependency for Slack async socket mode: {async_import_error}[/]")
                        console.print(f"[yellow]{extra_hint}[/]")
                    else:
                        console.print("[red]Slack async socket mode handler is unavailable on Windows.[/]")
                        console.print(f"[yellow]{extra_hint}[/]")
                    return False
                from slack_bolt.adapter.socket_mode import SocketModeHandler as _SocketModeHandler
                SocketModeHandler = _SocketModeHandler

            # Prefer async app/client whenever async socket mode handler is available.
            if AsyncSocketModeHandler is not None and AsyncApp is not None:
                self._app = AsyncApp(token=self._bot_token)
                self._client = self._app.client
                self._is_async_client = True
            else:
                self._app = App(token=self._bot_token)
                self._client = self._app.client
                self._is_async_client = False

            if self._is_async_client:
                auth = await self._client.auth_test()
            else:
                auth = self._client.auth_test()
            self._bot_user_id = auth.get("user_id")

            self._register_handlers()

            if AsyncSocketModeHandler is not None:
                # Async handler avoids installing signal handlers in a background thread (Windows).
                self._handler = AsyncSocketModeHandler(self._app, self._app_token)
                asyncio.create_task(self._handler.start_async())
            else:
                # Fallback: start in background thread. (May fail on Windows depending on slack_bolt version.)
                self._handler = SocketModeHandler(self._app, self._app_token)
                threading.Thread(target=self._handler.start, daemon=True).start()

            self.is_connected = True
            console.print(f"[green]Slack channel connected as bot {self._bot_user_id}[/]")
            return True
        except Exception as e:
            console.print(f"[red]Failed to connect to Slack: {e}[/]")
            return False
    
    async def disconnect(self) -> None:
        """Disconnect from Slack."""
        if self._handler is not None:
            try:
                if hasattr(self._handler, "close_async"):
                    await self._handler.close_async()
                else:
                    await asyncio.to_thread(self._handler.close)
            except Exception:
                pass
        self.is_connected = False
        console.print("[yellow]Slack disconnected[/]")
    
    async def send_message(
        self,
        recipient: str,
        content: str,
        thread_id: Optional[str] = None,
        blocks: Optional[List[Dict]] = None,
        **kwargs
    ) -> SendResult:
        """Send Slack message.
        
        Args:
            recipient: Channel ID (C...) or User ID (U...) or DM ID (D...)
            content: Message text
            thread_id: Thread timestamp to reply in
            blocks: Slack Block Kit blocks for rich formatting
        """
        if not self.is_connected:
            return SendResult(success=False, error="Not connected")

        try:
            if not self._client:
                return SendResult(success=False, error="Slack client not initialized")

            channel_id = await self._resolve_channel_id(recipient)
            payload: Dict[str, Any] = {
                "channel": channel_id,
                "text": content,
            }
            if thread_id:
                payload["thread_ts"] = thread_id
            if blocks:
                payload["blocks"] = blocks
            resp = await self._client.chat_postMessage(**payload)
            ts = None
            if isinstance(resp, dict):
                ts = resp.get("ts")
            return SendResult(success=True, message_id=str(ts) if ts else None, timestamp=datetime.now())
        except Exception as e:
            return SendResult(success=False, error=str(e), timestamp=datetime.now())
    
    async def send_direct_message(
        self,
        user_id: str,
        content: str,
        **kwargs
    ) -> SendResult:
        """Send DM to a user."""
        return await self.send_message(str(user_id), content, **kwargs)
    
    async def send_channel_message(
        self,
        channel_id: str,
        content: str,
        thread_ts: Optional[str] = None,
        **kwargs
    ) -> SendResult:
        """Send message to a channel."""
        return await self.send_message(channel_id, content, thread_id=thread_ts, **kwargs)
    
    async def listen(self) -> AsyncIterator[ChannelMessage]:
        """Listen for incoming Slack events."""
        while self.is_connected:
            try:
                message = await asyncio.wait_for(
                    self._message_queue.get(),
                    timeout=1.0
                )
                yield message
            except asyncio.TimeoutError:
                continue
    
    def simulate_incoming_message(
        self,
        sender: str,
        content: str,
        channel: str = "D_mock",
        thread_ts: Optional[str] = None
    ) -> None:
        """Simulate an incoming message (for testing)."""
        message = ChannelMessage(
            id=f"{datetime.now().timestamp()}.{random.randint(1000, 9999)}",
            channel="slack",
            sender_id=sender,
            content=content,
            message_type=MessageType.TEXT,
            thread_id=thread_ts,
            timestamp=datetime.now(),
            metadata={"slack_channel": channel}
        )
        self._message_queue.put_nowait(message)
    
    def is_mention(self, text: str) -> bool:
        """Check if message mentions the bot."""
        if not self._bot_user_id:
            return False
        return f"<@{self._bot_user_id}>" in text or f"<@{self._bot_user_id.replace('U_', '')}>" in text
    
    def strip_mention(self, text: str) -> str:
        """Remove bot mention from message."""
        if not self._bot_user_id:
            return text
        mention = f"<@{self._bot_user_id}>"
        return text.replace(mention, "").replace(f"<@{self._bot_user_id.replace('U_', '')}>", "").strip()


    def _register_handlers(self) -> None:
        if not self._app:
            return

        if self._is_async_client:
            @self._app.event("message")
            async def _on_message(event: Dict[str, Any], body: Dict[str, Any], logger):
                try:
                    self._handle_inbound_event(event, body)
                except Exception:
                    return

            @self._app.event("app_mention")
            async def _on_mention(event: Dict[str, Any], body: Dict[str, Any], logger):
                try:
                    self._handle_inbound_event(event, body, force_allow=True)
                except Exception:
                    return
        else:
            @self._app.event("message")
            def _on_message(event: Dict[str, Any], body: Dict[str, Any], logger):
                try:
                    self._handle_inbound_event(event, body)
                except Exception:
                    return

            @self._app.event("app_mention")
            def _on_mention(event: Dict[str, Any], body: Dict[str, Any], logger):
                try:
                    self._handle_inbound_event(event, body, force_allow=True)
                except Exception:
                    return


    def _is_dm_channel(self, channel_id: Optional[str]) -> bool:
        if not isinstance(channel_id, str):
            return False
        return channel_id.startswith("D")


    def _get_extra_bool(self, key: str, default: bool) -> bool:
        extra = getattr(self.config, "extra", {}) or {}
        if not isinstance(extra, dict):
            return default
        v = extra.get(key)
        if isinstance(v, bool):
            return v
        return default


    def _get_allowed_channels(self) -> List[str]:
        extra = getattr(self.config, "extra", {}) or {}
        if not isinstance(extra, dict):
            return []
        raw = extra.get("allowed_channels")
        if isinstance(raw, list):
            return [str(x) for x in raw if isinstance(x, (str, int)) and str(x).strip()]
        return []


    def _strip_bot_mention(self, text: str) -> str:
        if not self._bot_user_id or not isinstance(text, str):
            return text or ""
        mention = f"<@{self._bot_user_id}>"
        return text.replace(mention, "").strip()


    def _has_bot_mention(self, text: str) -> bool:
        if not self._bot_user_id or not isinstance(text, str):
            return False
        return f"<@{self._bot_user_id}>" in text


    def _resolve_thread_mode(self, slack_channel_id: str) -> str:
        extra = getattr(self.config, "extra", {}) or {}
        if not isinstance(extra, dict):
            return "auto"
        mapping = extra.get("channel_thread_mode")
        if isinstance(mapping, dict):
            v = mapping.get(slack_channel_id)
            if isinstance(v, str) and v in {"auto", "thread", "channel"}:
                return v
        return "auto"


    def _handle_inbound_event(
        self,
        event: Dict[str, Any],
        body: Dict[str, Any],
        force_allow: bool = False,
    ) -> None:
        if not isinstance(event, dict):
            return

        if event.get("bot_id") or event.get("subtype") == "bot_message":
            return

        user_id = event.get("user")
        if not isinstance(user_id, str) or not user_id.strip():
            return
        if self._bot_user_id and user_id == self._bot_user_id:
            return

        channel_id = event.get("channel")
        text = event.get("text") or ""
        if not isinstance(text, str):
            text = str(text)

        allow_dm = self._get_extra_bool("allow_dm", True)
        require_mention = self._get_extra_bool("require_mention", True)
        allowed_channels = set(self._get_allowed_channels())

        is_dm = self._is_dm_channel(channel_id)

        if is_dm:
            if not allow_dm:
                return
        else:
            if channel_id not in allowed_channels:
                return
            if require_mention and not (force_allow or self._has_bot_mention(text)):
                return

        clean = self._strip_bot_mention(text) if (force_allow or self._has_bot_mention(text)) else text

        thread_ts = event.get("thread_ts")
        msg_ts = event.get("ts")

        chosen_thread_id: Optional[str] = None
        if isinstance(channel_id, str) and not is_dm:
            mode = self._resolve_thread_mode(channel_id)
            if mode == "thread":
                chosen_thread_id = str(thread_ts or msg_ts) if (thread_ts or msg_ts) else None
            elif mode == "channel":
                chosen_thread_id = None
            else:
                chosen_thread_id = str(thread_ts) if thread_ts else None
        else:
            chosen_thread_id = str(thread_ts) if thread_ts else None

        message = ChannelMessage(
            id=str(msg_ts or datetime.now().timestamp()),
            channel="slack",
            sender_id=user_id,
            sender_name=None,
            content=clean.strip(),
            message_type=MessageType.TEXT,
            timestamp=datetime.now(),
            thread_id=chosen_thread_id,
            raw_data={"event": event, "body": body},
            metadata={"slack_channel": channel_id, "slack_thread_ts": thread_ts, "slack_ts": msg_ts},
        )

        if self._loop and self._loop.is_running():
            self._loop.call_soon_threadsafe(self._message_queue.put_nowait, message)
        else:
            self._message_queue.put_nowait(message)


    async def _resolve_channel_id(self, recipient: str) -> str:
        rid = str(recipient or "").strip()
        if not rid:
            raise ValueError("Missing Slack recipient")
        if rid.startswith("C") or rid.startswith("G") or rid.startswith("D"):
            return rid
        if rid.startswith("U"):
            cached = self._channel_id_by_user.get(rid)
            if cached:
                return cached
            if not self._client:
                raise RuntimeError("Slack client not initialized")
            resp = await self._client.conversations_open(users=rid)
            channel = None
            if isinstance(resp, dict):
                channel = (resp.get("channel") or {}).get("id")
            if not isinstance(channel, str) or not channel.strip():
                raise RuntimeError("Failed to open DM channel")
            self._channel_id_by_user[rid] = channel
            return channel
        return rid


    async def get_conversations(
        self,
        types: str = "public_channel,private_channel,im,mpim",
        limit: int = 1000
    ) -> List[Dict[str, Any]]:
        """Fetch list of Slack conversations (channels, DMs)."""
        if not self.is_connected:
             # Try to connect if not already
             if not await self.connect():
                 return []
        
        if not self._client:
            return []

        try:
            conversations = []
            cursor = None
            while True:
                resp = await self._client.conversations_list(
                    types=types,
                    limit=limit,
                    cursor=cursor
                )
                
                # resp is SlackResponse, behaves like dict but isinstance(resp, dict) is False
                if not resp.get("ok"):
                    console.print(f"[red]Slack API error: {resp.get('error')}[/]")
                    break
                
                batch = resp.get("channels", [])
                conversations.extend(batch)
                
                cursor = (resp.get("response_metadata") or {}).get("next_cursor")
                if not cursor:
                    break
            
            # Enrich with user names for DMs if possible?
            # For now, just return raw data simplified
            results = []
            for c in conversations:
                name = c.get("name_normalized") or c.get("name")
                if c.get("is_im"):
                     user_id = c.get("user")
                     name = f"DM: {user_id}"
                
                results.append({
                    "id": c.get("id"),
                    "name": name,
                    "is_channel": c.get("is_channel"),
                    "is_group": c.get("is_group"),
                    "is_im": c.get("is_im"),
                    "is_private": c.get("is_private"),
                    "is_archived": c.get("is_archived"),
                })
            return results
        except Exception as e:
            console.print(f"[red]Failed to list conversations: {e}[/]")
            return []


class SlackConfig(ChannelConfig):
    """Slack-specific configuration."""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.bot_token: str = self.api_token or ""
        self.app_token: str = self.extra.get("app_token", "")
        self.signing_secret: str = self.extra.get("signing_secret", "")
        self.socket_mode: bool = True
        self.event_path: str = self.extra.get("event_path", "/slack/events")
        self.allowed_channels: List[str] = self.extra.get("allowed_channels", [])


def create_slack_channel_from_config(config: Dict[str, Any]) -> SlackChannel:
    """Create SlackChannel from configuration dict."""
    channel_config = SlackConfig(
        enabled=config.get("enabled", True),
        auto_start=config.get("auto_start", False),
        allow_from=config.get("allow_from", []),
        require_pairing=config.get("require_pairing", False),
        api_token=config.get("bot_token"),
        extra={
            "app_token": config.get("app_token"),
            "signing_secret": config.get("signing_secret"),
            "socket_mode": config.get("socket_mode", True),
            "allowed_channels": config.get("channels", [])
        }
    )
    return SlackChannel(channel_config)
