"""
Google Chat Channel - Google Chat API integration.

Supports:
- Pub/Sub push notifications
- HTTP webhook events
- Space and DM messaging
- Card-based responses
"""

import asyncio
import json
import random
from datetime import datetime
from typing import Optional, AsyncIterator, Dict, Any, List
from rich.console import Console

from .base import Channel, ChannelType, ChannelConfig, ChannelMessage, MessageType, SendResult

console = Console()


class GoogleChatChannel(Channel):
    """Google Chat channel implementation."""
    
    def __init__(self, config: ChannelConfig):
        super().__init__("google_chat", config)
        self._message_queue: asyncio.Queue[ChannelMessage] = asyncio.Queue()
        self._client = None
        self._project_id = config.extra.get("project_id")
        self._service_account_path = config.extra.get("service_account_key")
        self._spaces: List[str] = config.extra.get("spaces", [])
        self._webhook_secret = config.extra.get("webhook_secret")
    
    @property
    def channel_type(self) -> ChannelType:
        return ChannelType.GOOGLE_CHAT
    
    async def connect(self) -> bool:
        """Connect to Google Chat."""
        if not self._service_account_path:
            console.print("[red]Google Chat service account key not configured[/]")
            console.print("[dim]To configure:[/]")
            console.print("[dim]1. Create service account in Google Cloud Console[/]")
            console.print("[dim]2. Enable Chat API[/]")
            console.print("[dim]3. Download service account key JSON[/]")
            return False
        
        try:
            # In real implementation, use google-api-python-client
            # For now, mock connection
            self.is_connected = True
            console.print(f"[green]Google Chat channel connected (project: {self._project_id})[/]")
            return True
        except Exception as e:
            console.print(f"[red]Failed to connect to Google Chat: {e}[/]")
            return False
    
    async def disconnect(self) -> None:
        """Disconnect from Google Chat."""
        self.is_connected = False
        console.print("[yellow]Google Chat disconnected[/]")
    
    async def send_message(
        self,
        recipient: str,
        content: str,
        thread_id: Optional[str] = None,
        cards: Optional[List[Dict]] = None,
        **kwargs
    ) -> SendResult:
        """Send Google Chat message.
        
        Args:
            recipient: Space name (spaces/xxx) or user ID
            content: Message text
            thread_id: Thread name for replies
            cards: Card widgets for rich formatting
        """
        if not self.is_connected:
            return SendResult(success=False, error="Not connected")
        
        # Mock sending
        console.print(f"[dim][Google Chat → {recipient}]: {content[:50]}...[/dim]")
        
        return SendResult(
            success=True,
            message_id=f"{datetime.now().timestamp()}.{random.randint(1000, 9999)}",
            timestamp=datetime.now()
        )
    
    async def send_card(
        self,
        space: str,
        header: Dict[str, Any],
        sections: List[Dict[str, Any]],
        thread_id: Optional[str] = None
    ) -> SendResult:
        """Send a card message to a space.
        
        Args:
            space: Space name (spaces/xxx)
            header: Card header with title/subtitle
            sections: Card sections with widgets
            thread_id: Optional thread for reply
        """
        card = {
            "header": header,
            "sections": sections
        }
        
        # In real implementation, use Chat API
        console.print(f"[dim][Google Card → {space}]: {header.get('title', 'Card')}[/dim]")
        
        return SendResult(
            success=True,
            message_id=f"card_{random.randint(1000, 9999)}",
            timestamp=datetime.now()
        )
    
    async def listen(self) -> AsyncIterator[ChannelMessage]:
        """Listen for incoming Google Chat events."""
        while self.is_connected:
            try:
                message = await asyncio.wait_for(
                    self._message_queue.get(),
                    timeout=1.0
                )
                yield message
            except asyncio.TimeoutError:
                continue
    
    def simulate_incoming_message(
        self,
        sender: str,
        content: str,
        space: str = "spaces/mock",
        thread: Optional[str] = None
    ) -> None:
        """Simulate an incoming message (for testing)."""
        message = ChannelMessage(
            id=f"{datetime.now().timestamp()}.{random.randint(1000, 9999)}",
            channel="google_chat",
            sender_id=sender,
            content=content,
            message_type=MessageType.TEXT,
            thread_id=thread,
            timestamp=datetime.now(),
            metadata={"space": space, "google_chat_thread": thread}
        )
        self._message_queue.put_nowait(message)
    
    def is_mention(self, text: str) -> bool:
        """Check if message mentions the bot."""
        # Google Chat uses @BotName format
        return "@" in text
    
    def strip_mention(self, text: str) -> str:
        """Remove bot mention from message."""
        # Simple implementation - remove @BotName
        import re
        return re.sub(r'@\w+\s*', '', text).strip()


class GoogleChatConfig(ChannelConfig):
    """Google Chat-specific configuration."""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.project_id: str = self.extra.get("project_id", "")
        self.service_account_key: str = self.extra.get("service_account_key", "")
        self.webhook_secret: str = self.extra.get("webhook_secret", "")
        self.spaces: List[str] = self.extra.get("spaces", [])
        self.pubsub_topic: str = self.extra.get("pubsub_topic", "")
        self.subscription_id: str = self.extra.get("subscription_id", "")


def create_google_chat_channel_from_config(config: Dict[str, Any]) -> GoogleChatChannel:
    """Create GoogleChatChannel from configuration dict."""
    channel_config = GoogleChatConfig(
        enabled=config.get("enabled", True),
        auto_start=config.get("auto_start", False),
        allow_from=config.get("allow_from", []),
        require_pairing=config.get("require_pairing", True),
        extra={
            "project_id": config.get("project_id"),
            "service_account_key": config.get("service_account_key"),
            "webhook_secret": config.get("webhook_secret"),
            "spaces": config.get("spaces", [])
        }
    )
    return GoogleChatChannel(channel_config)
