"""
Channels Framework - Base classes for multi-channel messaging support.

Provides abstract base classes for WhatsApp, Slack, Google Chat, and other channels.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional, Dict, List, Callable, Any, AsyncIterator
from pathlib import Path
import asyncio


class ChannelType(Enum):
    """Types of supported channels."""
    WHATSAPP = "whatsapp"
    SLACK = "slack"
    GOOGLE_CHAT = "google_chat"
    TELEGRAM = "telegram"
    DISCORD = "discord"
    WEB = "web"


class MessageType(Enum):
    """Types of messages."""
    TEXT = "text"
    IMAGE = "image"
    FILE = "file"
    AUDIO = "audio"
    VIDEO = "video"
    LOCATION = "location"
    CONTACT = "contact"


@dataclass
class ChannelMessage:
    """Represents a message from any channel."""
    id: str
    channel: str  # Channel type identifier
    sender_id: str
    sender_name: Optional[str] = None
    content: str = ""
    message_type: MessageType = MessageType.TEXT
    timestamp: datetime = field(default_factory=datetime.now)
    thread_id: Optional[str] = None
    reply_to: Optional[str] = None
    attachments: List[Dict[str, Any]] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    raw_data: Any = None  # Original channel-specific data


@dataclass
class ChannelConfig:
    """Configuration for a channel."""
    enabled: bool = True
    auto_start: bool = False
    allow_from: List[str] = field(default_factory=list)
    block_from: List[str] = field(default_factory=list)
    require_pairing: bool = True
    pairing_code: Optional[str] = None
    webhook_url: Optional[str] = None
    api_token: Optional[str] = None
    default_recipient: Optional[str] = None  # Default recipient for outgoing messages
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass
class SendResult:
    """Result of sending a message."""
    success: bool
    message_id: Optional[str] = None
    error: Optional[str] = None
    timestamp: Optional[datetime] = None


class Channel(ABC):
    """Abstract base class for all channels."""
    
    def __init__(self, name: str, config: ChannelConfig):
        """Initialize channel.
        
        Args:
            name: Channel identifier
            config: Channel configuration
        """
        self.name = name
        self.config = config
        self.is_connected = False
        self.message_handlers: List[Callable[[ChannelMessage], Any]] = []
    
    @property
    @abstractmethod
    def channel_type(self) -> ChannelType:
        """Return the channel type."""
        pass
    
    @abstractmethod
    async def connect(self) -> bool:
        """Connect to the channel service.
        
        Returns:
            True if connected successfully
        """
        pass
    
    @abstractmethod
    async def disconnect(self) -> None:
        """Disconnect from the channel service."""
        pass
    
    @abstractmethod
    async def send_message(
        self,
        recipient: str,
        content: str,
        thread_id: Optional[str] = None,
        **kwargs
    ) -> SendResult:
        """Send a message to a recipient.
        
        Args:
            recipient: Recipient identifier
            content: Message content
            thread_id: Optional thread/conversation ID
            **kwargs: Channel-specific options
            
        Returns:
            SendResult with status
        """
        pass
    
    @abstractmethod
    async def listen(self) -> AsyncIterator[ChannelMessage]:
        """Listen for incoming messages.
        
        Yields:
            ChannelMessage objects as they arrive
        """
        pass
    
    def on_message(self, handler: Callable[[ChannelMessage], Any]) -> None:
        """Register a message handler.
        
        Args:
            handler: Callback function for messages
        """
        self.message_handlers.append(handler)
    
    async def process_message(self, message: ChannelMessage) -> None:
        """Process an incoming message through all handlers.
        
        Args:
            message: Received message
        """
        for handler in self.message_handlers:
            try:
                if asyncio.iscoroutinefunction(handler):
                    await handler(message)
                else:
                    handler(message)
            except Exception as e:
                print(f"Error in message handler: {e}")
    
    def is_allowed(self, sender_id: str) -> bool:
        """Check if sender is allowed to interact.
        
        Args:
            sender_id: Sender identifier
            
        Returns:
            True if allowed, False otherwise
        """
        # Check block list
        if sender_id in self.config.block_from:
            return False
        
        # Check allow list (empty means allow all)
        if self.config.allow_from:
            return sender_id in self.config.allow_from or "*" in self.config.allow_from
        
        return True
    
    def needs_pairing(self, sender_id: str) -> bool:
        """Check if sender needs to pair.
        
        Args:
            sender_id: Sender identifier
            
        Returns:
            True if pairing required
        """
        if not self.config.require_pairing:
            return False
        
        # Already allowed senders don't need pairing
        if self.is_allowed(sender_id):
            return False
        
        return True
    
    async def approve_pairing(self, code: str, sender_id: str) -> bool:
        """Approve a pairing request.
        
        Args:
            code: Pairing code
            sender_id: Sender to approve
            
        Returns:
            True if approved successfully
        """
        if code == self.config.pairing_code:
            if sender_id not in self.config.allow_from:
                self.config.allow_from.append(sender_id)
            return True
        return False


class ChannelManager:
    """Manages multiple channels and message routing."""
    
    def __init__(self):
        """Initialize channel manager."""
        self.channels: Dict[str, Channel] = {}
        self.global_handlers: List[Callable[[ChannelMessage], Any]] = []
        self.is_running = False
    
    def register_channel(self, channel: Channel) -> None:
        """Register a channel.
        
        Args:
            channel: Channel instance to register
        """
        self.channels[channel.name] = channel
        # Add global handlers to channel
        for handler in self.global_handlers:
            channel.on_message(handler)
    
    def unregister_channel(self, name: str) -> bool:
        """Unregister a channel.
        
        Args:
            name: Channel name
            
        Returns:
            True if unregistered
        """
        if name in self.channels:
            del self.channels[name]
            return True
        return False
    
    def get_channel(self, name: str) -> Optional[Channel]:
        """Get a channel by name.
        
        Args:
            name: Channel name
            
        Returns:
            Channel if found
        """
        return self.channels.get(name)
    
    def list_channels(self) -> List[Channel]:
        """Get all registered channels.
        
        Returns:
            List of channels
        """
        return list(self.channels.values())
    
    def on_message(self, handler: Callable[[ChannelMessage], Any]) -> None:
        """Register a global message handler.
        
        Args:
            handler: Handler callback
        """
        self.global_handlers.append(handler)
        # Add to existing channels
        for channel in self.channels.values():
            channel.on_message(handler)
    
    async def start_all(self) -> None:
        """Start all enabled channels."""
        self.is_running = True
        for channel in self.channels.values():
            if channel.config.enabled and channel.config.auto_start:
                await channel.connect()
    
    async def stop_all(self) -> None:
        """Stop all channels."""
        self.is_running = False
        for channel in self.channels.values():
            await channel.disconnect()
    
    async def send_to_all(
        self,
        content: str,
        filter_channels: Optional[List[str]] = None
    ) -> Dict[str, SendResult]:
        """Send a message to all channels.
        
        Args:
            content: Message content
            filter_channels: Optional list of channel names to limit to
            
        Returns:
            Dict of channel name to SendResult
        """
        results = {}
        for name, channel in self.channels.items():
            if filter_channels and name not in filter_channels:
                continue
            if not channel.is_connected:
                continue
            # Note: This is a simplified version - real implementation
            # would need recipient mapping per channel
            result = await channel.send_message("broadcast", content)
            results[name] = result
        return results


# Global channel manager instance
_channel_manager: Optional[ChannelManager] = None


def get_channel_manager() -> ChannelManager:
    """Get or create global channel manager."""
    global _channel_manager
    if _channel_manager is None:
        _channel_manager = ChannelManager()
    return _channel_manager
