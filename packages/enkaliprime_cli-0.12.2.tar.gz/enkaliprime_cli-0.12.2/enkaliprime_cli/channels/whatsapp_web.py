"""
WhatsApp Channel - OpenClaw-compatible implementation using whatsmeow via Go wrapper.

This matches OpenClaw's approach:
- QR code authentication (scan with phone)
- WebSocket connection to WhatsApp Web
- Signal Protocol encryption
- SQLite session persistence
- Real-time message sending/receiving

Requires: Go binary wrapper (whatsmeow-bridge) compiled from Go code
"""

import asyncio
import json
import os
import random
import string
import subprocess
import threading
from datetime import datetime
from pathlib import Path
from typing import Optional, AsyncIterator, Dict, Any, Callable, List
from rich.console import Console
from rich.panel import Panel

from .base import Channel, ChannelType, ChannelConfig, ChannelMessage, MessageType, SendResult

console = Console()


class WhatsAppChannel(Channel):
    """
    WhatsApp channel using whatsmeow (OpenClaw approach).
    
    Connects directly to WhatsApp Web servers via WebSocket,
    using QR code authentication like the official WhatsApp Web.
    """
    
    def __init__(self, config: ChannelConfig):
        super().__init__("whatsapp", config)
        self._message_queue: asyncio.Queue[ChannelMessage] = asyncio.Queue()
        self._bridge_process: Optional[subprocess.Popen] = None
        self._is_authenticated = False
        self._qr_code_data: Optional[str] = None
        self._connection_status = "disconnected"
        self._message_handler: Optional[Callable] = None
        
        # Paths
        self._session_path = Path(config.extra.get("session_path", "~/.enkaliprime/whatsapp")).expanduser()
        self._bridge_binary = config.extra.get("bridge_binary", "whatsmeow-bridge")
        
        # Connection settings
        self._auto_reconnect = config.extra.get("auto_reconnect", True)
        self._reconnect_interval = config.extra.get("reconnect_interval", 30)
        
        # Ensure session directory exists
        self._session_path.mkdir(parents=True, exist_ok=True)
    
    @property
    def channel_type(self) -> ChannelType:
        return ChannelType.WHATSAPP
    
    async def connect(self) -> bool:
        """Connect to WhatsApp using whatsmeow bridge."""
        if not self._check_bridge_binary():
            console.print("[red]whatsmeow bridge binary not found[/]")
            console.print(f"[dim]Expected at: {self._bridge_binary}[/]")
            console.print("[dim]Compile from: github.com/tulir/whatsmeow[/]")
            return False
        
        try:
            # Start the Go bridge process
            await self._start_bridge()
            
            console.print("[green]WhatsApp connecting...[/]")
            console.print("[yellow]Scan the QR code with your phone:[/]")
            console.print("[dim]WhatsApp > Settings > Linked Devices > Link a Device[/]")
            
            return True
            
        except Exception as e:
            console.print(f"[red]Failed to start WhatsApp bridge: {e}[/]")
            return False
    
    def _check_bridge_binary(self) -> bool:
        """Check if the whatsmeow bridge binary exists."""
        # Check if binary exists in PATH or at specified path
        if os.path.isfile(self._bridge_binary):
            return True
        
        # Check in common locations
        possible_paths = [
            Path("whatsmeow-bridge"),
            Path.home() / ".local/bin/whatsmeow-bridge",
            Path.home() / "bin/whatsmeow-bridge",
            Path("/usr/local/bin/whatsmeow-bridge"),
        ]
        
        for path in possible_paths:
            if path.exists():
                self._bridge_binary = str(path)
                return True
        
        return False
    
    async def _start_bridge(self) -> None:
        """Start the whatsmeow bridge subprocess."""
        env = os.environ.copy()
        env["WHATSAPP_SESSION_PATH"] = str(self._session_path)
        
        # Start bridge process with stdin/stdout for communication
        self._bridge_process = subprocess.Popen(
            [self._bridge_binary, "--json"],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            env=env
        )
        
        # Start reader thread
        reader_thread = threading.Thread(target=self._read_bridge_output, daemon=True)
        reader_thread.start()
        
        self.is_connected = True
    
    def _read_bridge_output(self) -> None:
        """Read output from the bridge process."""
        if not self._bridge_process or not self._bridge_process.stdout:
            return
        
        for line in self._bridge_process.stdout:
            try:
                data = json.loads(line.strip())
                self._handle_bridge_message(data)
            except json.JSONDecodeError:
                continue
            except Exception:
                continue
    
    def _handle_bridge_message(self, data: Dict[str, Any]) -> None:
        """Handle messages from the bridge."""
        msg_type = data.get("type")
        
        if msg_type == "qr":
            # Display QR code
            qr_data = data.get("code")
            self._qr_code_data = qr_data
            self._display_qr_code(qr_data)
            
        elif msg_type == "connected":
            self._is_authenticated = True
            self._connection_status = "connected"
            console.print("[green]✓ WhatsApp connected and authenticated![/]")
            
        elif msg_type == "disconnected":
            self._connection_status = "disconnected"
            console.print("[yellow]WhatsApp disconnected[/]")
            if self._auto_reconnect:
                asyncio.create_task(self._reconnect())
            
        elif msg_type == "message":
            # Incoming message
            message = self._parse_incoming_message(data)
            if message:
                self._message_queue.put_nowait(message)
                if self._message_handler:
                    asyncio.create_task(self._message_handler(message))
                    
        elif msg_type == "error":
            error_msg = data.get("message", "Unknown error")
            console.print(f"[red]WhatsApp error: {error_msg}[/]")
    
    def _display_qr_code(self, qr_data: str) -> None:
        """Display QR code in terminal."""
        try:
            import qrcode
            from io import StringIO
            
            qr = qrcode.QRCode(version=1, box_size=1, border=2)
            qr.add_data(qr_data)
            qr.make(fit=True)
            
            # Generate ASCII QR code
            f = StringIO()
            qr.print_ascii(out=f, invert=True)
            f.seek(0)
            qr_ascii = f.read()
            
            panel = Panel(
                qr_ascii,
                title="[bold yellow]Scan this QR code with WhatsApp[/bold yellow]",
                border_style="green"
            )
            console.print(panel)
            console.print("[dim]Or use the link: {}[/dim]".format(qr_data[:50] + "..."))
            
        except ImportError:
            # Fallback if qrcode not installed
            console.print("[yellow]QR Code data:[/]")
            console.print(f"[dim]{qr_data}[/dim]")
            console.print("[dim]Install qrcode library for better display: pip install qrcode[pil][/]")
    
    def _parse_incoming_message(self, data: Dict[str, Any]) -> Optional[ChannelMessage]:
        """Parse incoming message from bridge."""
        try:
            message_info = data.get("message", {})
            
            sender = message_info.get("from", "")
            content = ""
            
            # Extract content based on message type
            if "conversation" in message_info:
                content = message_info["conversation"]
            elif "extendedTextMessage" in message_info:
                content = message_info["extendedTextMessage"].get("text", "")
            
            if not content:
                return None
            
            return ChannelMessage(
                id=message_info.get("id", f"wa_{random.randint(100000, 999999)}"),
                channel="whatsapp",
                sender_id=sender.replace("@s.whatsapp.net", ""),
                sender_name=message_info.get("pushName", ""),
                content=content,
                message_type=MessageType.TEXT,
                timestamp=datetime.fromtimestamp(message_info.get("timestamp", 0)),
                raw_data=message_info
            )
        except Exception:
            return None
    
    async def _reconnect(self) -> None:
        """Attempt to reconnect."""
        await asyncio.sleep(self._reconnect_interval)
        if not self.is_connected and self._auto_reconnect:
            console.print("[yellow]Attempting to reconnect...[/]")
            await self.connect()
    
    async def disconnect(self) -> None:
        """Disconnect from WhatsApp."""
        self.is_connected = False
        self._auto_reconnect = False
        
        if self._bridge_process:
            # Send disconnect command
            await self._send_bridge_command({"action": "disconnect"})
            
            # Terminate process
            self._bridge_process.terminate()
            try:
                self._bridge_process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self._bridge_process.kill()
            
            self._bridge_process = None
        
        console.print("[yellow]WhatsApp disconnected[/]")
    
    async def send_message(
        self,
        recipient: str,
        content: str,
        thread_id: Optional[str] = None,
        **kwargs
    ) -> SendResult:
        """Send WhatsApp message."""
        if not self.is_connected or not self._is_authenticated:
            return SendResult(success=False, error="Not connected or authenticated")
        
        # Normalize recipient to JID format
        if "@" not in recipient:
            recipient = f"{recipient}@s.whatsapp.net"
        
        try:
            # Send via bridge
            await self._send_bridge_command({
                "action": "send",
                "to": recipient,
                "text": content
            })
            
            return SendResult(
                success=True,
                message_id=f"wa_{random.randint(1000000000, 9999999999)}",
                timestamp=datetime.now()
            )
            
        except Exception as e:
            return SendResult(success=False, error=str(e))
    
    async def _send_bridge_command(self, command: Dict[str, Any]) -> None:
        """Send command to the bridge process."""
        if self._bridge_process and self._bridge_process.stdin:
            cmd_line = json.dumps(command) + "\n"
            self._bridge_process.stdin.write(cmd_line)
            self._bridge_process.stdin.flush()
    
    async def listen(self) -> AsyncIterator[ChannelMessage]:
        """Listen for incoming WhatsApp messages."""
        while self.is_connected:
            try:
                message = await asyncio.wait_for(
                    self._message_queue.get(),
                    timeout=1.0
                )
                yield message
            except asyncio.TimeoutError:
                continue
    
    def on_message(self, handler: Callable) -> None:
        """Register a message handler."""
        super().on_message(handler)
        self._message_handler = handler
    
    def simulate_incoming_message(
        self,
        sender: str,
        content: str,
        message_type: MessageType = MessageType.TEXT
    ) -> None:
        """Simulate an incoming message (for testing)."""
        message = ChannelMessage(
            id=f"wa_{random.randint(100000, 999999)}",
            channel="whatsapp",
            sender_id=sender,
            content=content,
            message_type=message_type,
            timestamp=datetime.now()
        )
        self._message_queue.put_nowait(message)
    
    def generate_pairing_code(self) -> str:
        """Generate a pairing code (not used with QR auth, but kept for compatibility)."""
        code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
        self.config.pairing_code = code
        return code
    
    def get_qr_code(self) -> Optional[str]:
        """Get current QR code data (if waiting for scan)."""
        return self._qr_code_data
    
    def get_status(self) -> Dict[str, Any]:
        """Get connection status."""
        return {
            "connected": self.is_connected,
            "authenticated": self._is_authenticated,
            "status": self._connection_status,
            "qr_pending": self._qr_code_data is not None and not self._is_authenticated,
            "session_path": str(self._session_path)
        }
    
    def get_setup_instructions(self) -> str:
        """Get setup instructions for whatsmeow approach."""
        return """
To set up WhatsApp (OpenClaw/whatsmeow approach):

1. Install Go: https://golang.org/dl/

2. Build the whatsmeow bridge:
   git clone https://github.com/tulir/whatsmeow
   cd whatsmeow
   go build -o whatsmeow-bridge ./cmd
   
3. Move binary to PATH:
   mv whatsmeow-bridge ~/.local/bin/

4. Configure enkaliprime:
   - Set bridge_binary path in config
   - Session will be stored automatically

5. First time only:
   - Run 'enkaliprime channels connect whatsapp'
   - Scan QR code with WhatsApp on your phone
   - Session persists for future connections

Note: This approach connects directly to WhatsApp Web servers,
just like the official WhatsApp Web or OpenClaw.
        """.strip()


class WhatsAppConfig(ChannelConfig):
    """WhatsApp-specific configuration for whatsmeow approach."""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.provider = "whatsmeow"  # Fixed to match OpenClaw
        self.session_path: str = self.extra.get("session_path", "~/.enkaliprime/whatsapp")
        self.bridge_binary: str = self.extra.get("bridge_binary", "whatsmeow-bridge")
        self.auto_reconnect: bool = self.extra.get("auto_reconnect", True)
        self.reconnect_interval: int = self.extra.get("reconnect_interval", 30)
        self.sync_history: bool = self.extra.get("sync_history", False)
