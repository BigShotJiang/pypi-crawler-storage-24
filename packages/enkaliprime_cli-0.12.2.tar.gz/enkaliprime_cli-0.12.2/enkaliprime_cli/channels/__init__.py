"""
Channels Framework for EnkaliPrime CLI.

Provides multi-channel messaging support for WhatsApp, Slack, Google Chat, etc.
"""

from .base import (
    Channel,
    ChannelType,
    ChannelConfig,
    ChannelMessage,
    MessageType,
    SendResult,
    ChannelManager,
    get_channel_manager,
)
from .whatsapp import WhatsAppChannel, WhatsAppConfig
from .slack import SlackChannel, SlackConfig, create_slack_channel_from_config
from .google_chat import GoogleChatChannel, GoogleChatConfig, create_google_chat_channel_from_config

__all__ = [
    # Base classes
    "Channel",
    "ChannelType",
    "ChannelConfig",
    "ChannelMessage",
    "MessageType",
    "SendResult",
    "ChannelManager",
    "get_channel_manager",
    # WhatsApp
    "WhatsAppChannel",
    "WhatsAppConfig",
    # Slack
    "SlackChannel",
    "SlackConfig",
    "create_slack_channel_from_config",
    # Google Chat
    "GoogleChatChannel",
    "GoogleChatConfig",
    "create_google_chat_channel_from_config",
]
