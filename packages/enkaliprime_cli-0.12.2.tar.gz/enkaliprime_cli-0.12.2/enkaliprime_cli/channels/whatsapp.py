"""
WhatsApp Channel - OpenClaw-style implementation.

OpenClaw links WhatsApp using Node + Baileys (@whiskeysockets/baileys) and a QR code.
This channel spawns a small Node bridge process and communicates via JSON lines.

Features:
- QR code authentication (scan with WhatsApp app)
- Session persistence on disk
- Real-time send/receive

Requires: Node.js + npm
"""

import asyncio
import json
import os
import random
import string
import subprocess
import threading
import uuid
import base64
from collections import deque
from datetime import datetime
from pathlib import Path
from typing import Optional, AsyncIterator, Dict, Any, Callable
from rich.console import Console
from rich.panel import Panel

from .base import Channel, ChannelType, ChannelConfig, ChannelMessage, MessageType, SendResult
from .baileys_bridge_manager import ensure_baileys_bridge

console = Console()


class WhatsAppChannel(Channel):
    """
    WhatsApp channel using Node + Baileys (OpenClaw-style approach).

    Connects directly to WhatsApp Web servers like the official WhatsApp Web.
    Uses QR code authentication - scan with your phone to link.
    """
    
    def __init__(self, config: ChannelConfig):
        super().__init__("whatsapp", config)
        self._message_queue: asyncio.Queue[ChannelMessage] = asyncio.Queue()
        self._bridge_process: Optional[subprocess.Popen] = None
        self._is_authenticated = False
        self._qr_code_data: Optional[str] = None
        self._connection_status = "disconnected"
        self._message_handler: Optional[Callable] = None
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._connected_event: Optional[asyncio.Event] = None
        self._qr_event: Optional[asyncio.Event] = None
        self._failed_event: Optional[asyncio.Event] = None
        self._failed_reason: Optional[str] = None
        self._failed_status_code: Optional[int] = None
        self._last_qr: Optional[str] = None
        self._warned_missing_qr_lib: bool = False
        self._scan_prompt_shown: bool = False
        self._connecting_prompt_shown: bool = False
        self._pending_sends: Dict[str, asyncio.Future] = {}
        self._recent_sent_message_ids: deque[str] = deque(maxlen=200)
        
        # Paths - session stored like OpenClaw
        self._session_path = Path(config.extra.get("session_path", "~/.enkaliprime/whatsapp")).expanduser()
        self._bridge_binary = config.extra.get("bridge_binary", "bridge.js")
        
        # Connection settings (OpenClaw-style)
        self._auto_reconnect = config.extra.get("auto_reconnect", True)
        self._reconnect_interval = config.extra.get("reconnect_interval", 30)
        self._sync_history = config.extra.get("sync_history", False)
        
        # Ensure session directory exists
        self._session_path.mkdir(parents=True, exist_ok=True)
    
    @property
    def channel_type(self) -> ChannelType:
        return ChannelType.WHATSAPP
    
    async def connect(self) -> bool:
        """Connect to WhatsApp using Node + Baileys (OpenClaw approach)."""
        self._loop = asyncio.get_running_loop()

        # OpenClaw-style: allow restarting the session on transient stream errors.
        max_attempts = 3
        for attempt in range(1, max_attempts + 1):
            self._connected_event = asyncio.Event()
            self._qr_event = asyncio.Event()
            self._failed_event = asyncio.Event()
            self._failed_reason = None
            self._failed_status_code = None
            self._scan_prompt_shown = False
            self._connecting_prompt_shown = False

            bridge_js_path = ensure_baileys_bridge()
            if not bridge_js_path:
                console.print("[red]Failed to prepare WhatsApp bridge (Node + Baileys)[/]")
                return False

            self._bridge_binary = str(bridge_js_path)

            try:
                await self._start_bridge()
            except Exception as e:
                console.print(f"[red]Failed to start WhatsApp bridge: {e}[/]")
                return False

            console.print("[green]Starting WhatsApp…[/]")
            console.print("[dim]Preparing link session…[/]")

            # IMPORTANT: keep the event loop alive so QR + connected events are processed.
            # First, wait briefly for either a QR to be produced OR a connection to open
            # (if already linked), or an immediate failure.
            try:
                await asyncio.wait_for(
                    asyncio.wait(
                        [
                            asyncio.create_task(self._qr_event.wait()),
                            asyncio.create_task(self._connected_event.wait()),
                            asyncio.create_task(self._failed_event.wait()),
                        ],
                        return_when=asyncio.FIRST_COMPLETED,
                    ),
                    timeout=30,
                )
            except asyncio.TimeoutError:
                console.print("[yellow]⏳ Still waiting for WhatsApp QR...[/]")

            if self._failed_event.is_set():
                if self._failed_status_code == 515 and attempt < max_attempts:
                    console.print("[yellow]Stream error detected. Restarting WhatsApp link…[/]")
                    await self._stop_bridge()
                    continue

                reason = self._failed_reason or "Unknown disconnect"
                console.print(f"[red]✗ Failed to connect WhatsApp: {reason}[/]")
                await self._stop_bridge()
                return False

            # Then, wait for the QR scan to complete (connection open) OR fail.
            try:
                await asyncio.wait_for(
                    asyncio.wait(
                        [
                            asyncio.create_task(self._connected_event.wait()),
                            asyncio.create_task(self._failed_event.wait()),
                        ],
                        return_when=asyncio.FIRST_COMPLETED,
                    ),
                    timeout=180,
                )
            except asyncio.TimeoutError:
                console.print("[yellow]⏳ Still waiting for QR scan. Run connect again after scanning.[/]")
                return False

            if self._failed_event.is_set() and not self._is_authenticated:
                if self._failed_status_code == 515 and attempt < max_attempts:
                    console.print("[yellow]Stream error detected. Restarting WhatsApp link…[/]")
                    await self._stop_bridge()
                    continue

                reason = self._failed_reason or "Disconnected"
                console.print(f"[red]✗ Failed to connect WhatsApp: {reason}[/]")
                await self._stop_bridge()
                return False

            return self._is_authenticated

        return False

    async def _stop_bridge(self) -> None:
        """Stop the bridge process if running."""
        proc = self._bridge_process
        self._bridge_process = None
        if not proc:
            return

        try:
            if proc.stdin:
                try:
                    proc.stdin.close()
                except Exception:
                    pass
            proc.terminate()
        except Exception:
            pass

        try:
            proc.wait(timeout=5)
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass
    
    def _check_bridge_binary(self) -> bool:
        """Check if the Node bridge is ready."""
        bridge_js_path = ensure_baileys_bridge()
        if bridge_js_path:
            self._bridge_binary = str(bridge_js_path)
            return True
        return False
    
    async def _start_bridge(self) -> None:
        """Start the Baileys bridge subprocess (Node)."""
        env = os.environ.copy()
        
        # Start bridge with JSON communication
        self._bridge_process = subprocess.Popen(
            [
                "node",
                self._bridge_binary,
                "--auth-dir",
                str(self._session_path),
            ],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            bufsize=1,
            env=env,
        )
        
        # Start reader thread
        reader_thread = threading.Thread(target=self._read_bridge_output, daemon=True)
        reader_thread.start()

        err_thread = threading.Thread(target=self._read_bridge_stderr, daemon=True)
        err_thread.start()
        
        self.is_connected = True
    
    def _read_bridge_output(self) -> None:
        """Read JSON lines from bridge stdout."""
        if not self._bridge_process or not self._bridge_process.stdout:
            return
        
        for line in self._bridge_process.stdout:
            line = line.strip()
            if not line:
                continue
            
            try:
                data = json.loads(line)
                if self._loop is not None:
                    self._loop.call_soon_threadsafe(
                        asyncio.create_task,
                        self._handle_bridge_message_async(data),
                    )
            except json.JSONDecodeError:
                pass
            except Exception:
                pass

    def _read_bridge_stderr(self) -> None:
        """Read stderr from bridge for diagnostics."""
        if not self._bridge_process or not self._bridge_process.stderr:
            return

        for line in self._bridge_process.stderr:
            msg = (line or "").strip()
            if not msg:
                continue
            # Only surface a minimal hint; full verbosity can be added later.
            if self._failed_reason is None:
                self._failed_reason = msg
                if self._loop is not None and self._failed_event is not None:
                    try:
                        self._loop.call_soon_threadsafe(self._failed_event.set)
                    except Exception:
                        pass
    
    async def _handle_bridge_message_async(self, data: Dict[str, Any]) -> None:
        """Async handler for bridge messages."""
        msg_type = data.get("type")
        
        # Debug: log all messages received
        if msg_type == "message":
            msg_info = data.get("message", {})
            sender = msg_info.get("from", "unknown")
            from_me = msg_info.get("fromMe", False)
            console.print(f"[dim]DEBUG: Bridge message from={sender} fromMe={from_me} type={msg_type}[/]")
        
        if msg_type == "qr":
            qr_data = data.get("code")
            if not qr_data:
                return

            # Debounce repeated QR refreshes
            if self._last_qr == qr_data:
                return
            self._last_qr = qr_data

            self._qr_code_data = qr_data
            self._display_qr_code(qr_data)
            if not self._scan_prompt_shown:
                self._scan_prompt_shown = True
                console.print("[yellow]Waiting for you to scan the QR code…[/]")
                console.print("[dim]WhatsApp > Settings > Linked Devices > Link a Device[/]")
            if self._qr_event is not None:
                self._qr_event.set()

        elif msg_type == "connecting":
            self._connection_status = "connecting"
            if not self._connecting_prompt_shown:
                self._connecting_prompt_shown = True
                console.print("[yellow]Connecting to your phone…[/]")
            
        elif msg_type == "connected":
            self._is_authenticated = True
            self.is_connected = True
            self._connection_status = "connected"
            console.print("[green]✓ WhatsApp connected successfully![/]")
            if self._connected_event is not None:
                self._connected_event.set()

        elif msg_type == "logged_out":
            self._connection_status = "disconnected"
            reason = data.get("reason") or "Logged out"
            self._failed_reason = reason
            try:
                self._failed_status_code = int(data.get("statusCode")) if data.get("statusCode") is not None else None
            except Exception:
                self._failed_status_code = None
            self._auto_reconnect = False
            console.print("[yellow]WhatsApp session is logged out.[/]")
            console.print("[dim]Delete the session folder and reconnect to re-link:[/dim]")
            console.print(f"[dim]  {self._session_path}[/dim]")
            if self._failed_event is not None and not self._failed_event.is_set():
                self._failed_event.set()
            
        elif msg_type == "disconnected":
            self._connection_status = "disconnected"
            self.is_connected = False
            reason = data.get("reason")
            status_code = data.get("statusCode")
            disconnect_reason = data.get("disconnectReason")
            try:
                self._failed_status_code = int(status_code) if status_code is not None else None
            except Exception:
                self._failed_status_code = None
            parts = []
            if reason:
                parts.append(str(reason))
            if disconnect_reason:
                parts.append(str(disconnect_reason))
            if status_code is not None:
                parts.append(f"statusCode={status_code}")
            self._failed_reason = " | ".join(parts) if parts else "Disconnected"
            
            console.print(f"[yellow]WhatsApp disconnected ({self._failed_reason})[/]")
            
            if self._auto_reconnect:
                console.print("[dim yellow]Bridge attempting automatic reconnection...[/]")
            
            if self._failed_event is not None and not self._failed_event.is_set():
                # Only set failed event if we are NOT auto-reconnecting
                # or if it's the initial connection phase.
                if not self._auto_reconnect or self._connection_status == "connecting":
                    self._failed_event.set()
            if self._auto_reconnect:
                await asyncio.sleep(self._reconnect_interval)
                if not self.is_connected:
                    await self.connect()
                    
        elif msg_type == "message":
            message = self._parse_incoming_message(data)
            if message:
                await self._message_queue.put(message)
                # Notify handlers
                for handler in self.message_handlers:
                    try:
                        if asyncio.iscoroutinefunction(handler):
                            await handler(message)
                        else:
                            handler(message)
                    except Exception as e:
                        console.print(f"[red]Handler error: {e}[/]")

        elif msg_type == "debug":
            # Debug messages from Bridge.js for tracing
            event = data.get("event", "")
            reason = data.get("reason", "")
            if event:
                console.print(f"[dim magenta]BRIDGE DEBUG: event={event} {data}[/]")
            elif reason:
                console.print(f"[dim yellow]BRIDGE DEBUG: {reason} {data}[/]")
            else:
                console.print(f"[dim magenta]BRIDGE DEBUG: {data}[/]")
                        
        elif msg_type == "error":
            error_msg = data.get("message", "Unknown error")
            request_id = data.get("request_id")
            if request_id and request_id in self._pending_sends:
                fut = self._pending_sends.pop(str(request_id), None)
                if fut is not None and not fut.done():
                    fut.set_result({"ok": False, "error": error_msg})
                return

            console.print(f"[red]WhatsApp error: {error_msg}[/]")
            self._failed_reason = error_msg
            if self._failed_event is not None and not self._failed_event.is_set():
                self._failed_event.set()

        elif msg_type == "sent":
            request_id = data.get("request_id")
            message_id = data.get("message_id")
            if isinstance(message_id, str) and message_id:
                self._recent_sent_message_ids.append(message_id)
            if request_id and str(request_id) in self._pending_sends:
                fut = self._pending_sends.pop(str(request_id), None)
                if fut is not None and not fut.done():
                    fut.set_result({"ok": True, "to": data.get("to"), "message_id": message_id})
        
        elif msg_type == "audio_downloaded":
            request_id = data.get("request_id")
            audio_b64 = data.get("audio_b64")
            message_id = data.get("message_id")
            if request_id and str(request_id) in self._pending_sends:
                fut = self._pending_sends.pop(str(request_id), None)
                if fut is not None and not fut.done():
                    fut.set_result({
                        "ok": True, 
                        "type": "audio_downloaded",
                        "audio_b64": audio_b64,
                        "message_id": message_id
                    })
    
    def _display_qr_code(self, qr_data: str) -> None:
        """Display QR code in terminal for scanning."""
        try:
            import qrcode
            import tempfile
            import webbrowser
            from io import StringIO

            qr = qrcode.QRCode(
                version=1,
                error_correction=qrcode.constants.ERROR_CORRECT_L,
                box_size=4,
                border=2
            )
            qr.add_data(qr_data)
            qr.make(fit=True)

            # Save PNG for reliable scanning
            try:
                img = qr.make_image(fill_color="black", back_color="white")
                tmp_path = Path(tempfile.gettempdir()) / "enkaliprime_whatsapp_qr.png"
                img.save(tmp_path)
                console.print(f"[dim]QR image saved to: {tmp_path}[/dim]")
                if os.name == "nt":
                    try:
                        os.startfile(str(tmp_path))
                    except Exception:
                        pass
                else:
                    try:
                        webbrowser.open(tmp_path.as_uri())
                    except Exception:
                        pass
            except Exception:
                pass

            # Generate ASCII QR
            f = StringIO()
            qr.print_ascii(out=f)
            f.seek(0)
            qr_ascii = f.read()
            
            panel = Panel(
                qr_ascii,
                title="[bold yellow]Scan with WhatsApp[/bold yellow]",
                subtitle="[dim]Settings > Linked Devices > Link a Device[/dim]",
                border_style="green"
            )
            console.print(panel)
            
        except ImportError:
            if not self._warned_missing_qr_lib:
                self._warned_missing_qr_lib = True
                console.print("[red]QR rendering library not installed.[/red]")
                console.print("[dim]Install it in your venv:[/dim]")
                console.print("[dim]  pip install qrcode[pil][/dim]")
                console.print("[dim]or, if installed editable:[/dim]")
                console.print("[dim]  pip install -e \".[channels]\"[/dim]")
    
    def _parse_incoming_message(self, data: Dict[str, Any]) -> Optional[ChannelMessage]:
        """Parse incoming WhatsApp message from bridge."""
        try:
            # Debug: Log the entire data structure
            console.print(f"[dim magenta]DEBUG: Full data keys: {list(data.keys()) if isinstance(data, dict) else 'not dict'}[/]")
            
            msg_info = data.get("message")
            
            # Safety check - ensure msg_info exists and is a dict
            if msg_info is None:
                console.print(f"[dim red]DEBUG: msg_info is None - data['message'] is missing[/]")
                return None
            if not isinstance(msg_info, dict):
                console.print(f"[dim red]DEBUG: msg_info is not a dict: {type(msg_info)}[/]")
                return None
            
            # Debug: Log msg_info keys
            console.print(f"[dim magenta]DEBUG: msg_info keys: {list(msg_info.keys())}[/]")
            
            # Debug: Log ALL incoming message data
            sender_raw = msg_info.get("from", "unknown")
            original_from = msg_info.get("originalFrom", sender_raw)
            from_me = msg_info.get("fromMe", False)
            is_lid = msg_info.get("isLid", False)
            msg_id = msg_info.get("id", "no-id")
            push_name = msg_info.get("pushName", "")
            
            # Group metadata
            is_group = msg_info.get("isGroup", False)
            is_mentioned = msg_info.get("isMentioned", False)
            is_reply_to_me = msg_info.get("isReplyToMe", False)
            participant = msg_info.get("participant", "")
            
            console.print(f"[dim cyan]DEBUG _parse_incoming_message: id={msg_id} from={sender_raw} isGroup={is_group} participant={participant} isMentioned={is_mentioned} isReplyToMe={is_reply_to_me}[/]")

            # Ignore echoed messages that originate from our own sends.
            if msg_info.get("fromMe") is True:
                mid = msg_info.get("id")
                if isinstance(mid, str) and mid and mid in self._recent_sent_message_ids:
                    console.print(f"[dim yellow]DEBUG: Ignoring echoed sent message id={mid}[/]")
                    try:
                        self._recent_sent_message_ids.remove(mid)
                    except ValueError:
                        pass
                    return None
                # Note: fromMe=True messages that are NOT in _recent_sent_message_ids 
                # are passed through. This includes self-chat messages when using --me flag.
                console.print(f"[dim]DEBUG: fromMe=True but not in recent sends, passing through[/]")
            
            # Extract sender - handle both regular JID and LID cases
            sender = sender_raw
            if sender.endswith("@s.whatsapp.net"):
                sender = sender.replace("@s.whatsapp.net", "")
            elif sender.endswith("@lid"):
                # LID address - we can't reply directly but we still process the message
                # The pushName is available for display
                console.print(f"[dim yellow]DEBUG: LID sender detected, pushName={push_name}[/]")
                # Keep the LID as sender_id - service.py will need to handle this
            
            content = ""
            message_type = MessageType.TEXT
            audio_data = None
            
            # Handle voice/audio messages first (they take priority)
            audio_msg = msg_info.get("audioMessage")
            voice_msg = msg_info.get("voiceMessage")
            
            if audio_msg:
                content = audio_msg.get("caption", "[Voice Note]")
                message_type = MessageType.AUDIO
                audio_data = audio_msg
                console.print(f"[dim yellow]DEBUG: audioMessage detected, caption={audio_msg.get('caption', 'None')}[/]")
            elif voice_msg:
                content = "[Voice Note]"
                message_type = MessageType.AUDIO
                audio_data = voice_msg
                console.print(f"[dim yellow]DEBUG: voiceMessage detected[/]")
            else:
                # Handle text messages
                conv = msg_info.get("conversation")
                ext_text = msg_info.get("extendedTextMessage")
                
                if conv:
                    content = conv
                    console.print(f"[dim yellow]DEBUG: conversation text found: {content[:50]}...[/]")
                elif ext_text:
                    content = ext_text.get("text", "")
                    console.print(f"[dim yellow]DEBUG: extendedTextMessage found: {content[:50]}...[/]")
                else:
                    console.print(f"[dim yellow]DEBUG: No text content found in msg_info keys: {list(msg_info.keys())}[/]")
            
            console.print(f"[dim cyan]DEBUG: Parsed content length={len(content)} sender={sender} type={message_type} audio={'yes' if audio_data else 'no'}[/]")
            
            if not content:
                console.print(f"[dim yellow]DEBUG: No content extracted, returning None[/]")
                return None
            
            console.print(f"[dim green]DEBUG: Creating ChannelMessage for sender={sender} isLid={is_lid} type={message_type}[/]")
            return ChannelMessage(
                id=msg_info.get("id", f"wa_{random.randint(100000, 999999)}"),
                channel="whatsapp",
                sender_id=sender,
                sender_name=push_name,
                content=content,
                message_type=message_type,
                timestamp=datetime.fromtimestamp(msg_info.get("timestamp", datetime.now().timestamp())),
                raw_data=msg_info  # Includes isLid, originalFrom, audioMessage/voiceMessage for service.py to use
            )
        except Exception as e:
            console.print(f"[dim red]DEBUG: Exception in _parse_incoming_message: {e}[/]")
            return None
    
    async def disconnect(self) -> None:
        """Disconnect from WhatsApp."""
        self.is_connected = False
        self._auto_reconnect = False

        # Use the shared stop helper to avoid subprocess I/O edge cases on Windows.
        try:
            if self._bridge_process:
                try:
                    await self._send_bridge_command({"action": "disconnect"})
                except Exception:
                    pass
            await self._stop_bridge()
        except Exception:
            pass

        console.print("[yellow]WhatsApp disconnected[/]")
    
    async def send_message(
        self,
        recipient: str,
        content: str,
        thread_id: Optional[str] = None,
        **kwargs
    ) -> SendResult:
        """Send WhatsApp message."""
        # Auto-reconnect if session exists but we're not connected
        if not self.is_connected or not self._is_authenticated:
            console.print("[yellow]WhatsApp not connected. Reconnecting…[/]")
            if not await self.connect():
                return SendResult(success=False, error="Failed to reconnect WhatsApp")
        
        # Normalize to JID format
        recipient = self._normalize_recipient(recipient)
        if recipient is None:
            return SendResult(success=False, error="Invalid recipient")
        
        try:
            request_id = uuid.uuid4().hex
            loop = asyncio.get_running_loop()
            fut: asyncio.Future = loop.create_future()
            self._pending_sends[request_id] = fut

            await self._send_bridge_command({
                "action": "send",
                "request_id": request_id,
                "to": recipient,
                "text": content,
            })

            resp = await asyncio.wait_for(fut, timeout=20)
            if not resp.get("ok"):
                return SendResult(success=False, error=str(resp.get("error") or "Send failed"))

            return SendResult(
                success=True,
                message_id=f"wa_{random.randint(1000000000, 9999999999)}",
                timestamp=datetime.now(),
            )
        except Exception as e:
            return SendResult(success=False, error=str(e))

    def _normalize_recipient(self, recipient: str) -> Optional[str]:
        if not recipient:
            return None
        r = str(recipient).strip()
        if "@" in r:
            return r
        norm = "".join(ch for ch in r if ch.isdigit())
        if not norm:
            return None
        return f"{norm}@s.whatsapp.net"

    async def send_voice_note(
        self,
        recipient: str,
        audio_bytes: bytes,
        mimetype: str = "audio/ogg; codecs=opus",
    ) -> SendResult:
        if not audio_bytes:
            return SendResult(success=False, error="Empty audio")

        # Auto-reconnect if session exists but we're not connected
        if not self.is_connected or not self._is_authenticated:
            console.print("[yellow]WhatsApp not connected. Reconnecting…[/]")
            if not await self.connect():
                return SendResult(success=False, error="Failed to reconnect WhatsApp")

        jid = self._normalize_recipient(recipient)
        if jid is None:
            return SendResult(success=False, error="Invalid recipient")

        try:
            request_id = uuid.uuid4().hex
            loop = asyncio.get_running_loop()
            fut: asyncio.Future = loop.create_future()
            self._pending_sends[request_id] = fut

            await self._send_bridge_command(
                {
                    "action": "send_audio",
                    "request_id": request_id,
                    "to": jid,
                    "audio_b64": base64.b64encode(audio_bytes).decode("ascii"),
                    "mimetype": mimetype,
                    "ptt": True,
                }
            )

            resp = await asyncio.wait_for(fut, timeout=30)
            if not resp.get("ok"):
                return SendResult(success=False, error=str(resp.get("error") or "Send failed"))

            return SendResult(
                success=True,
                message_id=f"wa_{random.randint(1000000000, 9999999999)}",
                timestamp=datetime.now(),
            )
        except Exception as e:
            return SendResult(success=False, error=str(e))
    
    async def download_voice_note(self, message_id: str, sender_jid: str) -> Optional[bytes]:
        """Download a voice note from WhatsApp."""
        if not self.is_connected or not self._is_authenticated:
            console.print("[yellow]WhatsApp not connected. Cannot download voice note.[/]")
            return None
        
        try:
            request_id = uuid.uuid4().hex
            loop = asyncio.get_running_loop()
            fut: asyncio.Future = loop.create_future()
            self._pending_sends[request_id] = fut

            await self._send_bridge_command({
                "action": "download_audio",
                "request_id": request_id,
                "message_key": {
                    "remoteJid": sender_jid,
                    "id": message_id
                }
            })

            resp = await asyncio.wait_for(fut, timeout=30)
            if not resp.get("ok") and resp.get("type") != "audio_downloaded":
                console.print(f"[red]Failed to download voice note: {resp.get('error', 'Unknown error')}[/]")
                return None

            audio_b64 = resp.get("audio_b64")
            if not audio_b64:
                console.print("[red]No audio data received[/]")
                return None

            return base64.b64decode(audio_b64)
        except Exception as e:
            console.print(f"[red]Error downloading voice note: {e}[/]")
            return None
    
    async def _send_bridge_command(self, command: Dict[str, Any]) -> None:
        """Send JSON command to bridge process."""
        if self._bridge_process and self._bridge_process.stdin:
            cmd_json = json.dumps(command) + "\n"
            self._bridge_process.stdin.write(cmd_json)
            self._bridge_process.stdin.flush()
    
    async def listen(self) -> AsyncIterator[ChannelMessage]:
        """Listen for incoming messages."""
        while self.is_connected:
            try:
                message = await asyncio.wait_for(
                    self._message_queue.get(),
                    timeout=1.0
                )
                yield message
            except asyncio.TimeoutError:
                continue
    
    def simulate_incoming_message(
        self,
        sender: str,
        content: str,
        message_type: MessageType = MessageType.TEXT
    ) -> None:
        """Simulate incoming message (for testing)."""
        message = ChannelMessage(
            id=f"wa_{random.randint(100000, 999999)}",
            channel="whatsapp",
            sender_id=sender,
            content=content,
            message_type=message_type,
            timestamp=datetime.now()
        )
        self._message_queue.put_nowait(message)
    
    def generate_pairing_code(self) -> str:
        """Generate pairing code (compatibility)."""
        code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
        self.config.pairing_code = code
        return code
    
    def get_qr_code(self) -> Optional[str]:
        """Get current QR code if waiting for scan."""
        return self._qr_code_data
    
    def get_status(self) -> Dict[str, Any]:
        """Get connection status."""
        return {
            "connected": self.is_connected,
            "authenticated": self._is_authenticated,
            "status": self._connection_status,
            "qr_pending": self._qr_code_data is not None and not self._is_authenticated
        }
    
    def get_setup_instructions(self) -> str:
        """Setup instructions (matching OpenClaw)."""
        return """
[bold]Setup WhatsApp (OpenClaw-style):[/bold]

1. Install Go: https://golang.org/dl/

2. Build whatsmeow bridge:
   [dim]git clone https://github.com/tulir/whatsmeow
   cd whatsmeow
   go build -o whatsmeow-bridge ./cmd[/dim]

3. Move to PATH:
   [dim]mv whatsmeow-bridge ~/.local/bin/[/dim]

4. Connect:
   [dim]enkaliprime channels connect whatsapp[/dim]

5. Scan QR code with WhatsApp app
   - Open WhatsApp on phone
   - Settings > Linked Devices > Link a Device
   - Scan the QR code shown in terminal

Session persists automatically for future connections.
        """.strip()


class WhatsAppConfig(ChannelConfig):
    """WhatsApp configuration matching OpenClaw."""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.provider = "whatsmeow"  # Match OpenClaw
        self.session_path: str = self.extra.get("session_path", "~/.enkaliprime/whatsapp")
        self.bridge_binary: str = self.extra.get("bridge_binary", "whatsmeow-bridge")
        self.auto_reconnect: bool = self.extra.get("auto_reconnect", True)
        self.reconnect_interval: int = self.extra.get("reconnect_interval", 30)
        self.sync_history: bool = self.extra.get("sync_history", False)
