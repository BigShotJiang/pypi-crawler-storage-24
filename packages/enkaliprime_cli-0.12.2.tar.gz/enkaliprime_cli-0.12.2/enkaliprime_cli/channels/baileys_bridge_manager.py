"""WhatsApp Baileys Bridge Manager.

OpenClaw uses Node + Baileys (@whiskeysockets/baileys) for WhatsApp Web linking.
This manager provisions a small Node bridge project under the user's home directory
and ensures dependencies are installed.
"""

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Optional

from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

console = Console()


_BRIDGE_JS = r"""import process from 'node:process';
import readline from 'node:readline';
import {
  makeWASocket,
  DisconnectReason,
  fetchLatestBaileysVersion,
  useMultiFileAuthState,
  makeCacheableSignalKeyStore,
  jidNormalizedUser,
  downloadMediaMessage,
} from '@whiskeysockets/baileys';
import pino from 'pino';


function emit(obj) {
  try {
    process.stdout.write(JSON.stringify(obj) + '\n');
  } catch {
    // ignore
  }
}

function parseArgs(argv) {
  const out = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--auth-dir') out.authDir = argv[++i];
    else if (a === '--verbose') out.verbose = true;
  }
  return out;
}

const args = parseArgs(process.argv.slice(2));
const authDir = args.authDir;
if (!authDir) {
  emit({ type: 'error', message: 'Missing --auth-dir' });
  process.exit(2);
}

const logger = pino({ level: args.verbose ? 'info' : 'silent' });

let sock;
let connected = false;

// Global LID to phone JID mapping - persisted across messages
const lidToPhoneJid = new Map();
const messageCache = new Map();

async function connectToWhatsApp() {
  const { state, saveCreds } = await useMultiFileAuthState(authDir);
  const { version } = await fetchLatestBaileysVersion();

  sock = makeWASocket({
    version,
    logger,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, logger),
    },
    printQRInTerminal: false,
    browser: ['enkaliprime', 'cli', '1.0'],
    syncFullHistory: false,
    markOnlineOnConnect: false,
    // Enable contact syncing to get LID-to-phone mappings
    getMessage: async (key) => undefined,
  });

  sock.ev.on('creds.update', saveCreds);

  // Listen for contact updates to build LID-to-phone mapping
  sock.ev.on('contacts.update', (contacts) => {
    for (const contact of contacts) {
      if (contact.id && contact.lid) {
        // Map LID to phone JID
        lidToPhoneJid.set(contact.lid, contact.id);
        emit({ type: 'debug', event: 'contact_lid_mapped', lid: contact.lid, jid: contact.id, name: contact.name });
      }
    }
  });

  sock.ev.on('contacts.upsert', (contacts) => {
    for (const contact of contacts) {
      if (contact.id && contact.lid) {
        lidToPhoneJid.set(contact.lid, contact.id);
        emit({ type: 'debug', event: 'contact_lid_upsert', lid: contact.lid, jid: contact.id, name: contact.name });
      }
    }
  });

  // Listen for chats to extract LID-to-JID mappings from chat metadata
  sock.ev.on('chats.upsert', (chats) => {
    for (const chat of chats) {
      // Check if chat has both id (phone JID) and lid
      if (chat.id && chat.lid) {
        lidToPhoneJid.set(chat.lid, chat.id);
        emit({ type: 'debug', event: 'chat_lid_mapped', lid: chat.lid, jid: chat.id });
      }
      // Also check for contact info in chat
      if (chat.id && chat.contact?.lid) {
        lidToPhoneJid.set(chat.contact.lid, chat.id);
        emit({ type: 'debug', event: 'chat_contact_lid_mapped', lid: chat.contact.lid, jid: chat.id });
      }
    }
  });

  // Handle messaging history sync - may contain contact info
  sock.ev.on('messaging-history.set', (data) => {
    const { chats, contacts, messages } = data;
    emit({ type: 'debug', event: 'history_sync', chatCount: chats?.length, contactCount: contacts?.length });
    
    if (contacts) {
      for (const contact of contacts) {
        if (contact.id && contact.lid) {
          lidToPhoneJid.set(contact.lid, contact.id);
          emit({ type: 'debug', event: 'history_contact_lid', lid: contact.lid, jid: contact.id, name: contact.name });
        }
      }
    }
    
    if (chats) {
      for (const chat of chats) {
        if (chat.id && chat.lid) {
          lidToPhoneJid.set(chat.lid, chat.id);
          emit({ type: 'debug', event: 'history_chat_lid', lid: chat.lid, jid: chat.id });
        }
      }
    }
  });

  sock.ev.on('connection.update', (update) => {
    const { connection, qr, lastDisconnect } = update ?? {};
    if (qr) {
      emit({ type: 'qr', code: qr });
    }
    if (connection === 'connecting') {
      emit({ type: 'connecting' });
    }
    if (connection === 'open') {
      connected = true;
      emit({ type: 'connected' });
      
      // Log the current state of LID mappings
      emit({ type: 'debug', event: 'connection_open_lid_count', count: lidToPhoneJid.size });
    }
    if (connection === 'close') {
      connected = false;
      const err = lastDisconnect?.error;
      const statusCode = err?.output?.statusCode;
      const disconnectReason = err?.output?.payload?.status || err?.output?.payload?.reason;
      const message = err?.output?.payload?.message || err?.message || String(err ?? '');

      if (statusCode === DisconnectReason.loggedOut) {
        emit({ type: 'logged_out', reason: message, statusCode });
      } else {
        emit({ type: 'disconnected', reason: message, statusCode, disconnectReason });
        // Attempt automatic reconnection for transient errors
        const shouldReconnect = statusCode !== DisconnectReason.loggedOut;
        if (shouldReconnect) {
          emit({ type: 'debug', event: 'auto_reconnecting', delay: 5000 });
          setTimeout(connectToWhatsApp, 5000);
        }
      }
    }
  });


  sock.ev.on('messages.upsert', async (m) => {
    try {
      // Debug: Log raw upsert event
      emit({ type: 'debug', event: 'messages.upsert', upsertType: m?.type, messageCount: m?.messages?.length || 0 });
      
      if (!m || !m.messages) {
        emit({ type: 'debug', reason: 'No messages in upsert' });
        return;
      }

      // Pre-calculate my own JIDs for mention checks (Phone + LID)
      const myJids = [];
      if (sock.user?.id) myJids.push(jidNormalizedUser(sock.user.id));
      if (sock.user?.lid) myJids.push(jidNormalizedUser(sock.user.lid));
      
      for (const msg of m.messages) {
        if (!msg.message) continue;
        
        // --- Message Caching for Media Download ---
        // Cache EVERY message that comes in, even if it's not a notification,
        // so we can download media for it later if needed.
        const cacheKey = `${msg.key?.remoteJid}_${msg.key?.id}`;
        messageCache.set(cacheKey, msg);
        // Evict old entries if cache grows too large
        if (messageCache.size > 500) {
          const firstKey = messageCache.keys().next().value;
          messageCache.delete(firstKey);
        }

        if (m.type !== 'notify') {
          // Skip emission for non-notify messages, but they are now cached!
          continue;
        }

        let from = msg.key?.remoteJid || '';
        const id = msg.key?.id || '';
        const fromMe = msg.key?.fromMe === true;
        let pushName = msg.pushName;
        const participant = msg.key?.participant || ''; // Sender in group

        // Determine if it's a group message
        const isGroup = from.endsWith('@g.us');
        
        let text = '';
        let audioData = null;
        const message = msg.message;
        if (message.conversation) text = message.conversation;
        else if (message.extendedTextMessage?.text) text = message.extendedTextMessage.text;
        else if (message.imageMessage?.caption) text = message.imageMessage.caption;
        else if (message.videoMessage?.caption) text = message.videoMessage.caption;
        
        // Handle voice/audio messages
        if (message.audioMessage) {
          audioData = message.audioMessage;
          // Use caption if available, otherwise indicate it's a voice note
          text = message.audioMessage.caption || '[Voice Note]';
        } else if (message.voiceMessage) {
          audioData = message.voiceMessage;
          text = '[Voice Note]';
        }

        // --- Group Mention / Reply Logic ---
        let isMentioned = false;
        let isReplyToMe = false;

        const contextInfo = message.extendedTextMessage?.contextInfo || 
                            message.imageMessage?.contextInfo || 
                            message.videoMessage?.contextInfo ||
                            message.audioMessage?.contextInfo ||
                            message.voiceMessage?.contextInfo;

        if (myJids.length > 0) {
            // Check mentions
            const mentions = contextInfo?.mentionedJid || [];
            if (mentions.some(jid => myJids.includes(jidNormalizedUser(jid)))) {
                isMentioned = true;
            }

            // Check reply
            const quotedParticipant = contextInfo?.participant;
            if (quotedParticipant && myJids.includes(jidNormalizedUser(quotedParticipant))) {
                isReplyToMe = true;
            }
        }
        
        emit({ 
            type: 'debug', 
            event: 'emitting_message', 
            from, 
            participant,
            isGroup,
            isMentioned, 
            isReplyToMe,
            myJids, 
            mentionedJids: contextInfo?.mentionedJid,
            textLength: text ? text.length : 0 
        });

        emit({
          type: 'message',
          message: {
            id,
            from: from, 
            participant: participant, // Valid for groups
            fromMe,
            pushName,
            timestamp: Number(msg.messageTimestamp ?? 0),
            conversation: text || '', // Send empty string if no text but maybe has other content?
            isLid: String(from).endsWith('@lid'),
            isGroup,
            isMentioned,
            isReplyToMe,
            audioMessage: audioData // Include audio data if present
          },
        });
      }
    } catch (err) {
      emit({ type: 'error', message: String(err) });
    }
  });
}



const rl = readline.createInterface({ input: process.stdin, crlfDelay: Infinity });
rl.on('line', async (line) => {
  let cmd;
  try {
    cmd = JSON.parse(String(line || '').trim());
  } catch {
    return;
  }
  if (!cmd || typeof cmd !== 'object') return;

  if (cmd.action === 'send') {
    try {
      if (!sock) throw new Error('Socket not initialized');
      const requestId = cmd.request_id;
      let to = cmd.to;
      const text = cmd.text;
      if (!to || !text) throw new Error('Missing to/text');
      
      // Resolve LID to phone JID if needed - DISABLED to prevent wrong mapping
      if (String(to).endsWith('@lid')) {
        emit({ type: 'debug', event: 'sending_to_lid_directly', lid: to });
      }
      
      // Only check onWhatsApp if NOT a LID address AND NOT a Group address
      if (!String(to).endsWith('@lid') && !String(to).endsWith('@g.us')) {
          const wa = await sock.onWhatsApp(to);
          if (!wa || !Array.isArray(wa) || wa.length === 0 || !wa[0]?.exists) {
            throw new Error(`Recipient is not on WhatsApp: ${to}`);
          }
      }

      const res = await sock.sendMessage(to, { text: String(text) });
      const messageId = res?.key?.id;
      emit({ type: 'sent', to, request_id: requestId, message_id: messageId });
    } catch (err) {
      emit({ type: 'error', message: String(err), request_id: cmd?.request_id });
    }
  } else if (cmd.action === 'disconnect') {
    try {
      sock?.ws?.close();
    } catch {
      // ignore
    }
    process.exit(0);
  } else if (cmd.action === 'send_audio') {
    try {
      if (!sock) throw new Error('Socket not initialized');
      const requestId = cmd.request_id;
      let to = cmd.to;
      const audioB64 = cmd.audio_b64;
      const mimetype = cmd.mimetype || 'audio/ogg; codecs=opus';
      const ptt = cmd.ptt === true;
      if (!to || !audioB64) throw new Error('Missing to/audio_b64');

      // Resolve LID to phone JID if needed - DISABLED
      if (String(to).endsWith('@lid')) {
           emit({ type: 'debug', event: 'sending_audio_to_lid_directly', lid: to });
      }

      // Only check onWhatsApp if NOT a LID address AND NOT a Group address
      if (!String(to).endsWith('@lid') && !String(to).endsWith('@g.us')) {
          const wa = await sock.onWhatsApp(to);
          if (!wa || !Array.isArray(wa) || wa.length === 0 || !wa[0]?.exists) {
            throw new Error(`Recipient is not on WhatsApp: ${to}`);
          }
      }

      const buffer = Buffer.from(String(audioB64), 'base64');
      if (!buffer || buffer.length === 0) throw new Error('Empty audio payload');

      const res = await sock.sendMessage(to, { audio: buffer, mimetype: String(mimetype), ptt });
      const messageId = res?.key?.id;
      emit({ type: 'sent', to, request_id: requestId, message_id: messageId });
    } catch (err) {
      emit({ type: 'error', message: String(err), request_id: cmd?.request_id });
    }
  } else if (cmd.action === 'download_audio') {
    try {
      if (!sock) throw new Error('Socket not initialized');
      const requestId = cmd.request_id;
      const messageKey = cmd.message_key; // { remoteJid: string, id: string }
      
      if (!messageKey || !messageKey.remoteJid || !messageKey.id) {
        throw new Error('Missing message_key with remoteJid and id');
      }

      const cacheKey = `${messageKey.remoteJid}_${messageKey.id}`;
      const cachedMsg = messageCache.get(cacheKey);
      
      if (!cachedMsg) {
        throw new Error(`Message ${messageKey.id} not found in bridge cache. Cannot download media.`);
      }

      const buffer = await downloadMediaMessage(
        cachedMsg,
        'buffer',
        {},
        { 
          logger,
          reuploadRequest: sock.updateMediaMessage
        }
      );

      if (!buffer) {
        throw new Error('Failed to download audio: empty buffer returned');
      }

      // Convert buffer to base64
      const audioB64 = Buffer.from(buffer).toString('base64');
      emit({ 
        type: 'audio_downloaded', 
        request_id: requestId,
        audio_b64: audioB64,
        message_id: messageKey.id
      });
    } catch (err) {
      emit({ type: 'error', message: String(err), request_id: cmd?.request_id });
    }
  }

});

connectToWhatsApp().catch((err) => {
  emit({ type: 'error', message: String(err) });
  process.exit(1);
});
"""


_PACKAGE_JSON = {
    "name": "enkaliprime-baileys-bridge",
    "private": True,
    "type": "module",
    "version": "0.0.0",
    "dependencies": {
        "@whiskeysockets/baileys": "^6.7.10",
        "pino": "^9.2.0"
    }
}


class BaileysBridgeManager:
    def __init__(self, root_dir: Optional[Path] = None):
        if root_dir is None:
            root_dir = Path.home() / ".enkaliprime" / "whatsapp" / "baileys-bridge"
        self.root_dir = Path(root_dir)
        self.root_dir.mkdir(parents=True, exist_ok=True)
        self.bridge_js_path = self.root_dir / "bridge.js"
        self.package_json_path = self.root_dir / "package.json"

    def _resolve_node(self) -> Optional[str]:
        return shutil.which("node") or shutil.which("node.exe")

    def _resolve_npm(self) -> Optional[str]:
        # On Windows npm is usually npm.cmd
        return shutil.which("npm") or shutil.which("npm.cmd") or shutil.which("npm.exe")

    def ensure_ready(self) -> Optional[Path]:
        """Ensure bridge files exist and dependencies installed.

        Returns path to bridge.js if successful.
        """
        node = self._resolve_node()
        npm = self._resolve_npm()
        if not node or not npm:
            console.print("[red]Node.js + npm are required for WhatsApp (OpenClaw/Baileys) mode[/]")
            console.print("[dim]Install Node.js LTS: https://nodejs.org/[/]")
            if not node:
                console.print("[dim]Missing executable: node[/]")
            if not npm:
                console.print("[dim]Missing executable: npm[/]")
            return None

        # Write files
        self.bridge_js_path.write_text(_BRIDGE_JS, encoding="utf-8")
        self.package_json_path.write_text(json.dumps(_PACKAGE_JSON, indent=2), encoding="utf-8")

        # Install deps if needed
        node_modules = self.root_dir / "node_modules"
        if node_modules.exists():
            return self.bridge_js_path

        console.print("[yellow]Setting up WhatsApp…[/]")
        try:
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                task = progress.add_task("Setting up WhatsApp…", total=None)

                cmd = [npm, "install", "--no-audit", "--no-fund"]
                result = subprocess.run(
                    cmd,
                    cwd=str(self.root_dir),
                    capture_output=True,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                    timeout=600,
                    env=os.environ.copy(),
                )

                if result.returncode != 0:
                    progress.update(task, description="[red]npm install failed[/]")
                    console.print("[red]npm install failed[/]")
                    console.print(f"[dim]cmd: {' '.join(cmd)}[/dim]")
                    console.print(f"[dim]cwd: {self.root_dir}[/dim]")
                    console.print(f"[dim]exit code: {result.returncode}[/dim]")
                    stderr = (result.stderr or "").strip()
                    stdout = (result.stdout or "").strip()
                    if stdout:
                        console.print("[dim]--- npm stdout ---[/dim]")
                        console.print(f"[dim]{stdout[-4000:]}[/dim]")
                    if stderr:
                        console.print("[dim]--- npm stderr ---[/dim]")
                        console.print(f"[dim]{stderr[-4000:]}[/dim]")
                    return None

                progress.update(task, description="[green]WhatsApp setup complete[/]")

            return self.bridge_js_path
        except subprocess.TimeoutExpired:
            console.print("[red]npm install timed out[/]")
            return None
        except Exception as e:
            console.print(f"[red]Failed to install WhatsApp bridge deps: {e}[/]")
            return None


def ensure_baileys_bridge() -> Optional[Path]:
    return BaileysBridgeManager().ensure_ready()
