import base64
import shutil
import subprocess
import tempfile
import wave
from pathlib import Path
from typing import Optional

from rich.console import Console

console = Console()


class PocketTTSEngine:
    def __init__(
        self,
        voice_wav_path: str,
        model_variant: str = "b6369a24",
    ):
        self.voice_wav_path = str(voice_wav_path)
        self.model_variant = model_variant

        self._tts_model = None
        self._voice_state = None

    def _ensure_loaded(self) -> None:
        if self._tts_model is not None and self._voice_state is not None:
            return

        from pocket_tts import TTSModel

        self._tts_model = TTSModel.load_model(self.model_variant)
        self._tts_model.to("cpu")
        self._voice_state = self._tts_model.get_state_for_audio_prompt(self.voice_wav_path)

    def synthesize_to_wav_path(self, text: str) -> Path:
        self._ensure_loaded()

        if not text or not text.strip():
            raise ValueError("Text cannot be empty")

        audio = self._tts_model.generate_audio(self._voice_state, text)
        sample_rate = int(self._tts_model.sample_rate)

        import numpy as np

        audio_np = audio.detach().cpu().numpy()
        audio_np = np.clip(audio_np, -1.0, 1.0)
        pcm16 = (audio_np * 32767.0).astype(np.int16)

        tmp_dir = Path(tempfile.gettempdir())
        out_path = tmp_dir / "enkaliprime_tts.wav"

        with wave.open(str(out_path), "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(sample_rate)
            wf.writeframes(pcm16.tobytes())

        return out_path

    def transcode_wav_to_opus_ogg(self, wav_path: Path) -> Optional[Path]:
        ffmpeg = shutil.which("ffmpeg") or shutil.which("ffmpeg.exe")
        if not ffmpeg:
            raise RuntimeError("ffmpeg not found on PATH")

        out_path = wav_path.with_suffix(".ogg")
        cmd = [
            ffmpeg,
            "-y",
            "-i",
            str(wav_path),
            "-ac",
            "1",
            "-c:a",
            "libopus",
            "-b:a",
            "48k",
            str(out_path),
        ]

        proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
        if proc.returncode != 0:
            stderr = (proc.stderr or "").strip()
            if len(stderr) > 500:
                stderr = stderr[:500] + "..."
            raise RuntimeError(f"ffmpeg failed (exit={proc.returncode}): {stderr or 'no stderr'}")

        if not out_path.exists() or out_path.stat().st_size == 0:
            raise RuntimeError("ffmpeg produced no output")
        return out_path

    @staticmethod
    def read_bytes(path: Path) -> bytes:
        return path.read_bytes()

    @staticmethod
    def to_b64(data: bytes) -> str:
        return base64.b64encode(data).decode("ascii")
