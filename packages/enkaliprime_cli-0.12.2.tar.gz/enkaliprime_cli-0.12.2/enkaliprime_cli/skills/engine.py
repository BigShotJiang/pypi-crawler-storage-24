"""
Skill Engine - Core execution engine for running skills.

Handles skill invocation, context management, and result processing.
"""

import os
import sys
import subprocess
import json
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass
from rich.console import Console

from .models import Skill, SkillContext, SkillResult, SkillResource
from .registry import SkillRegistry, get_registry

console = Console()


class SkillExecutionError(Exception):
    """Error executing a skill."""
    pass


class SkillEngine:
    """Engine for executing skills with proper context and sandboxing."""
    
    def __init__(self, registry: Optional[SkillRegistry] = None):
        """Initialize skill engine.
        
        Args:
            registry: Skill registry (uses global if not provided)
        """
        self.registry = registry or get_registry()
        self.execution_hooks: List[Callable] = []
    
    def execute(
        self,
        skill: Skill,
        context: SkillContext,
        script_name: Optional[str] = None,
        args: Optional[Dict[str, Any]] = None
    ) -> SkillResult:
        """Execute a skill with given context.
        
        Args:
            skill: Skill to execute
            context: Execution context
            script_name: Specific script to run (or use skill body)
            args: Additional arguments for script
            
        Returns:
            SkillResult with execution results
        """
        try:
            if script_name:
                # Execute specific script
                return self._execute_script(skill, script_name, context, args)
            else:
                # Return skill content for AI to use
                return self._execute_skill_content(skill, context)
                
        except Exception as e:
            console.print(f"[red]Skill execution error: {e}[/]")
            return SkillResult(
                success=False,
                message=f"Execution failed: {str(e)}",
                error=str(e)
            )
    
    def _execute_script(
        self,
        skill: Skill,
        script_name: str,
        context: SkillContext,
        args: Optional[Dict[str, Any]] = None
    ) -> SkillResult:
        """Execute a skill script.
        
        Args:
            skill: Parent skill
            script_name: Name of script to execute
            context: Execution context
            args: Script arguments
            
        Returns:
            SkillResult
        """
        resource = skill.get_script(script_name)
        if not resource:
            return SkillResult(
                success=False,
                message=f"Script not found: {script_name}",
                error="Script not found"
            )
        
        # Prepare environment
        env = os.environ.copy()
        env.update(context.env_vars)
        env.update({
            'SKILL_CONTEXT': json.dumps(context.to_dict()),
            'SKILL_NAME': skill.metadata.name,
            'SKILL_PATH': str(skill.skill_path),
        })
        
        # Build command based on script type
        script_path = resource.path
        
        if script_path.suffix == '.py':
            cmd = [sys.executable, str(script_path)]
        elif script_path.suffix in ['.sh', '.bash']:
            cmd = ['bash', str(script_path)]
        elif script_path.suffix == '.ps1':
            cmd = ['powershell', '-File', str(script_path)]
        else:
            cmd = [str(script_path)]
        
        # Add arguments if provided
        if args:
            for key, value in args.items():
                cmd.extend([f'--{key}', str(value)])
        
        # Execute with timeout and sandbox
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=60,
                cwd=str(context.working_directory),
                env=env
            )
            
            success = result.returncode == 0
            
            return SkillResult(
                success=success,
                message="Script executed successfully" if success else f"Exit code: {result.returncode}",
                output=result.stdout if success else None,
                error=result.stderr if not success else None,
                data={
                    'stdout': result.stdout,
                    'stderr': result.stderr,
                    'returncode': result.returncode
                }
            )
            
        except subprocess.TimeoutExpired:
            return SkillResult(
                success=False,
                message="Script execution timed out",
                error="Timeout after 60 seconds"
            )
        except Exception as e:
            return SkillResult(
                success=False,
                message=f"Script execution failed: {e}",
                error=str(e)
            )
    
    def _execute_skill_content(self, skill: Skill, context: SkillContext) -> SkillResult:
        """Execute skill by returning content for AI processing.
        
        This is the default execution mode - the skill content is loaded
        into the AI context for processing.
        
        Args:
            skill: Skill to execute
            context: Execution context
            
        Returns:
            SkillResult with skill content
        """
        # Build comprehensive skill content
        content_parts = [
            f"# Skill: {skill.metadata.name}",
            f"Version: {skill.metadata.version}",
            "",
            "## Description",
            skill.metadata.description,
            "",
            "## Instructions",
            skill.body_content,
        ]
        
        # Add available scripts
        scripts = [r for r in skill.resources.values() if r.resource_type == 'script']
        if scripts:
            content_parts.extend(["", "## Available Scripts"])
            for script in scripts:
                content_parts.append(f"- `{script.name}`")
        
        # Add available references
        references = [r for r in skill.resources.values() if r.resource_type == 'reference']
        if references:
            content_parts.extend(["", "## Available References"])
            for ref in references:
                content_parts.append(f"- `{ref.name}`")
        
        full_content = "\n".join(content_parts)
        
        return SkillResult(
            success=True,
            message=f"Skill {skill.metadata.name} loaded successfully",
            output=full_content,
            data={
                'skill_name': skill.metadata.name,
                'skill_version': skill.metadata.version,
                'has_scripts': len(scripts) > 0,
                'has_references': len(references) > 0
            }
        )
    
    def run_with_trigger(
        self,
        message: str,
        context: SkillContext,
        auto_execute: bool = False
    ) -> Optional[SkillResult]:
        """Find and run a skill based on message trigger.
        
        Args:
            message: User message to match
            context: Execution context
            auto_execute: Whether to auto-execute best match
            
        Returns:
            SkillResult if skill was triggered, None otherwise
        """
        match = self.registry.get_best_match(message)
        
        if not match:
            return None
        
        if auto_execute or match.confidence > 0.7:
            return self.execute(match.skill, context)
        
        # Return match info without execution
        return SkillResult(
            success=True,
            message=f"Matched skill: {match.skill.metadata.name} (confidence: {match.confidence:.2f})",
            data={
                'skill_name': match.skill.metadata.name,
                'confidence': match.confidence,
                'description': match.skill.metadata.description
            }
        )


# Global engine instance
_engine: Optional[SkillEngine] = None


def get_engine() -> SkillEngine:
    """Get or create global skill engine."""
    global _engine
    if _engine is None:
        _engine = SkillEngine()
    return _engine
