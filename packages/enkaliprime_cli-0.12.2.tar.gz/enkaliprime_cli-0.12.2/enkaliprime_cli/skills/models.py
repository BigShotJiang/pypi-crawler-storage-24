"""
Skills Framework for EnkaliPrime CLI.

Provides modular skill system compatible with OpenClaw SKILL.md format.
"""

from dataclasses import dataclass, field
from typing import Optional, Dict, List, Any, Callable
from pathlib import Path
from enum import Enum


class SkillTriggerType(Enum):
    """Types of skill triggers."""
    KEYWORD = "keyword"
    REGEX = "regex"
    INTENT = "intent"
    COMMAND = "command"


@dataclass
class SkillMetadata:
    """Skill metadata from YAML frontmatter."""
    name: str
    description: str
    version: str = "1.0.0"
    author: Optional[str] = None
    tags: List[str] = field(default_factory=list)
    requires: List[str] = field(default_factory=list)
    
    def __post_init__(self):
        if not self.name:
            raise ValueError("Skill name is required")
        if not self.description:
            raise ValueError("Skill description is required")


@dataclass
class SkillResource:
    """Represents a skill resource (script, reference, asset)."""
    name: str
    path: Path
    resource_type: str  # 'script', 'reference', 'asset'
    content: Optional[str] = None


@dataclass
class Skill:
    """Complete skill representation."""
    metadata: SkillMetadata
    skill_path: Path
    body_content: str
    resources: Dict[str, SkillResource] = field(default_factory=dict)
    triggers: List[Dict[str, Any]] = field(default_factory=list)
    is_loaded: bool = False
    
    def get_script(self, name: str) -> Optional[SkillResource]:
        """Get a script resource by name."""
        return self.resources.get(f"script:{name}")
    
    def get_reference(self, name: str) -> Optional[SkillResource]:
        """Get a reference resource by name."""
        return self.resources.get(f"reference:{name}")
    
    def get_asset(self, name: str) -> Optional[SkillResource]:
        """Get an asset resource by name."""
        return self.resources.get(f"asset:{name}")
    
    @property
    def full_content(self) -> str:
        """Get full skill content including metadata and body."""
        return f"---\n{self.metadata}---\n\n{self.body_content}"


@dataclass
class SkillResult:
    """Result of skill execution."""
    success: bool
    message: str
    data: Optional[Dict[str, Any]] = None
    output: Optional[str] = None
    error: Optional[str] = None


@dataclass
class SkillContext:
    """Context passed to skills during execution."""
    user_message: str
    conversation_history: List[Dict[str, str]] = field(default_factory=list)
    session_id: Optional[str] = None
    channel: Optional[str] = None
    working_directory: Path = field(default_factory=lambda: Path.cwd())
    env_vars: Dict[str, str] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert context to dictionary."""
        return {
            "user_message": self.user_message,
            "conversation_history": self.conversation_history,
            "session_id": self.session_id,
            "channel": self.channel,
            "working_directory": str(self.working_directory),
        }
