"""
Skill Registry - Manages skill discovery, registration, and lookup.

Provides skill indexing, search, and trigger matching capabilities.
"""

import re
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass
from rich.console import Console
from rich.table import Table

from .models import Skill, SkillMetadata
from .loader import SkillLoader, SkillLoaderError

console = Console()


@dataclass
class SkillMatch:
    """Represents a skill match with confidence score."""
    skill: Skill
    confidence: float
    matched_trigger: Optional[str] = None
    match_type: str = "unknown"


class SkillRegistry:
    """Registry for managing and querying skills."""
    
    def __init__(self, loader: Optional[SkillLoader] = None):
        """Initialize skill registry.
        
        Args:
            loader: SkillLoader instance (created if not provided)
        """
        self.loader = loader or SkillLoader()
        self.skills: Dict[str, Skill] = {}
        self.trigger_patterns: Dict[str, List[tuple]] = {}  # skill_name -> [(pattern, type)]
        self.is_initialized = False
    
    def initialize(self) -> None:
        """Load all available skills into registry."""
        if self.is_initialized:
            return
        
        skills = self.loader.load_all_skills()
        
        for skill in skills:
            self.register(skill)
        
        self.is_initialized = True
        console.print(f"[green]Loaded {len(self.skills)} skills[/]")
    
    def register(self, skill: Skill) -> None:
        """Register a skill in the registry.
        
        Args:
            skill: Skill to register
        """
        self.skills[skill.metadata.name] = skill
        
        # Extract trigger patterns from skill description
        self._extract_triggers(skill)
    
    def unregister(self, skill_name: str) -> bool:
        """Remove a skill from registry.
        
        Args:
            skill_name: Name of skill to remove
            
        Returns:
            True if removed, False if not found
        """
        if skill_name in self.skills:
            del self.skills[skill_name]
            if skill_name in self.trigger_patterns:
                del self.trigger_patterns[skill_name]
            return True
        return False
    
    def get(self, skill_name: str) -> Optional[Skill]:
        """Get a skill by name.
        
        Args:
            skill_name: Name of skill
            
        Returns:
            Skill if found, None otherwise
        """
        return self.skills.get(skill_name)
    
    def list_skills(self) -> List[Skill]:
        """Get list of all registered skills.
        
        Returns:
            List of Skill objects
        """
        return list(self.skills.values())
    
    def find_matching_skills(self, message: str, min_confidence: float = 0.3) -> List[SkillMatch]:
        """Find skills that match a user message.
        
        Args:
            message: User message to match
            min_confidence: Minimum confidence threshold (0-1)
            
        Returns:
            List of SkillMatch objects sorted by confidence
        """
        matches = []
        message_lower = message.lower()
        
        for skill_name, skill in self.skills.items():
            confidence, trigger_type = self._calculate_match(skill, message_lower)
            
            if confidence >= min_confidence:
                matches.append(SkillMatch(
                    skill=skill,
                    confidence=confidence,
                    matched_trigger=skill.metadata.description[:50] + "...",
                    match_type=trigger_type
                ))
        
        # Sort by confidence descending
        matches.sort(key=lambda x: x.confidence, reverse=True)
        return matches
    
    def get_best_match(self, message: str, min_confidence: float = 0.5) -> Optional[SkillMatch]:
        """Get the best matching skill for a message.
        
        Args:
            message: User message
            min_confidence: Minimum confidence threshold
            
        Returns:
            Best SkillMatch or None if no good match
        """
        matches = self.find_matching_skills(message, min_confidence)
        return matches[0] if matches else None
    
    def reload(self) -> None:
        """Reload all skills from disk."""
        self.skills.clear()
        self.trigger_patterns.clear()
        self.is_initialized = False
        self.initialize()
    
    def install_skill(self, source_path: Path, target_name: Optional[str] = None) -> bool:
        """Install a skill from a directory.
        
        Args:
            source_path: Path to skill directory
            target_name: Optional name override
            
        Returns:
            True if installed successfully
        """
        try:
            skill = self.loader.load_skill(source_path)
            
            if target_name:
                skill.metadata.name = target_name
            
            # Determine target path
            target_path = self.loader.user_path / skill.metadata.name
            
            # Copy skill to user directory
            import shutil
            if target_path.exists():
                shutil.rmtree(target_path)
            
            shutil.copytree(source_path, target_path)
            
            # Register the newly installed skill
            new_skill = self.loader.load_skill(target_path)
            self.register(new_skill)
            
            console.print(f"[green]Installed skill: {skill.metadata.name}[/]")
            return True
            
        except Exception as e:
            console.print(f"[red]Failed to install skill: {e}[/]")
            return False
    
    def uninstall_skill(self, skill_name: str) -> bool:
        """Uninstall a user skill.
        
        Args:
            skill_name: Name of skill to uninstall
            
        Returns:
            True if uninstalled, False otherwise
        """
        skill = self.get(skill_name)
        if not skill:
            console.print(f"[red]Skill not found: {skill_name}[/]")
            return False
        
        # Only uninstall user skills (not builtin)
        if self.loader.builtin_path in skill.skill_path.parents:
            console.print(f"[red]Cannot uninstall built-in skill: {skill_name}[/]")
            return False
        
        try:
            import shutil
            shutil.rmtree(skill.skill_path)
            self.unregister(skill_name)
            console.print(f"[green]Uninstalled skill: {skill_name}[/]")
            return True
        except Exception as e:
            console.print(f"[red]Failed to uninstall: {e}[/]")
            return False
    
    def display_skills_table(self) -> None:
        """Display a table of all registered skills."""
        table = Table(title="Available Skills")
        table.add_column("Name", style="cyan", no_wrap=True)
        table.add_column("Version", style="magenta")
        table.add_column("Type", style="green")
        table.add_column("Description", style="white")
        
        for skill in self.skills.values():
            skill_type = "Built-in" if self.loader.builtin_path in skill.skill_path.parents else "User"
            desc = skill.metadata.description[:60] + "..." if len(skill.metadata.description) > 60 else skill.metadata.description
            table.add_row(
                skill.metadata.name,
                skill.metadata.version,
                skill_type,
                desc
            )
        
        console.print(table)
    
    def _extract_triggers(self, skill: Skill) -> None:
        """Extract trigger patterns from skill description.
        
        Args:
            skill: Skill to extract triggers from
        """
        triggers = []
        desc_lower = skill.metadata.description.lower()
        
        # Extract keywords from description
        # Common action words that indicate skill usage
        action_patterns = [
            r'\b(use|create|manage|search|find|get|set|update|delete|list|show)\b',
            r'\b(github|notion|weather|spotify|summarize)\b',
        ]
        
        for pattern in action_patterns:
            matches = re.finditer(pattern, desc_lower)
            for match in matches:
                triggers.append((match.group(), "keyword"))
        
        # Add skill name itself as trigger
        triggers.append((skill.metadata.name.lower(), "name"))
        
        self.trigger_patterns[skill.metadata.name] = triggers
    
    def _calculate_match(self, skill: Skill, message: str) -> tuple:
        """Calculate match confidence between skill and message.
        
        Args:
            skill: Skill to check
            message: Lowercase message text
            
        Returns:
            Tuple of (confidence, trigger_type)
        """
        max_confidence = 0.0
        best_trigger = "none"
        
        # Check skill name exact match
        if skill.metadata.name.lower() in message:
            return 0.9, "name_exact"
        
        # Check trigger patterns
        patterns = self.trigger_patterns.get(skill.metadata.name, [])
        for pattern, ptype in patterns:
            if pattern in message:
                confidence = 0.7 if ptype == "name" else 0.5
                if confidence > max_confidence:
                    max_confidence = confidence
                    best_trigger = ptype
        
        # Check description similarity (simple word overlap)
        desc_words = set(skill.metadata.description.lower().split())
        message_words = set(message.split())
        if desc_words and message_words:
            overlap = len(desc_words & message_words) / len(desc_words)
            if overlap > 0.3:
                max_confidence = max(max_confidence, overlap * 0.6)
                best_trigger = "description_similarity"
        
        return max_confidence, best_trigger


# Global registry instance
_registry: Optional[SkillRegistry] = None


def get_registry() -> SkillRegistry:
    """Get or create global skill registry."""
    global _registry
    if _registry is None:
        _registry = SkillRegistry()
    return _registry
