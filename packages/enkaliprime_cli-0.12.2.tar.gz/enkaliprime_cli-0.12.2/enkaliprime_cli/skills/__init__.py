"""
Skills Framework for EnkaliPrime CLI.

Provides OpenClaw-compatible skill system for modular AI capabilities.
"""

from .models import (
    Skill,
    SkillMetadata,
    SkillResource,
    SkillResult,
    SkillContext,
    SkillTriggerType,
)
from .loader import SkillLoader, SkillLoaderError
from .registry import SkillRegistry, SkillMatch, get_registry
from .engine import SkillEngine, SkillExecutionError, get_engine

__all__ = [
    # Models
    "Skill",
    "SkillMetadata",
    "SkillResource",
    "SkillResult",
    "SkillContext",
    "SkillTriggerType",
    # Loader
    "SkillLoader",
    "SkillLoaderError",
    # Registry
    "SkillRegistry",
    "SkillMatch",
    "get_registry",
    # Engine
    "SkillEngine",
    "SkillExecutionError",
    "get_engine",
]
