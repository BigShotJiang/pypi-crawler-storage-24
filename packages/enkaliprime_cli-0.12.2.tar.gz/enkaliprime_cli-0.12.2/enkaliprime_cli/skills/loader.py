"""
Skill Loader - Parses SKILL.md files and loads skill resources.

Handles YAML frontmatter extraction, markdown body parsing,
and resource discovery (scripts, references, assets).
"""

import re
import yaml
from pathlib import Path
from typing import Optional, Dict, List, Any, Tuple
from rich.console import Console

from .models import Skill, SkillMetadata, SkillResource

console = Console()


class SkillLoaderError(Exception):
    """Error loading or parsing a skill."""
    pass


class SkillLoader:
    """Loads skills from SKILL.md files."""
    
    # Pattern to match YAML frontmatter: ---\n...\n---
    FRONTMATTER_PATTERN = re.compile(
        r'^---\s*\n(.*?)\n---\s*\n(.*)$',
        re.DOTALL
    )
    
    def __init__(self, builtin_path: Optional[Path] = None, user_path: Optional[Path] = None):
        """Initialize skill loader.
        
        Args:
            builtin_path: Path to built-in skills directory
            user_path: Path to user skills directory
        """
        self.builtin_path = builtin_path or self._get_default_builtin_path()
        self.user_path = user_path or self._get_default_user_path()
    
    def _get_default_builtin_path(self) -> Path:
        """Get default path for built-in skills."""
        import enkaliprime_cli
        return Path(enkaliprime_cli.__file__).parent / "builtin_skills"
    
    def _get_default_user_path(self) -> Path:
        """Get default path for user skills."""
        from pathlib import Path
        return Path.home() / ".enkaliprime" / "skills"
    
    def load_skill(self, skill_path: Path) -> Skill:
        """Load a skill from a directory containing SKILL.md.
        
        Args:
            skill_path: Path to skill directory
            
        Returns:
            Loaded Skill object
            
        Raises:
            SkillLoaderError: If skill cannot be loaded
        """
        skill_path = Path(skill_path)
        
        if not skill_path.exists():
            raise SkillLoaderError(f"Skill path does not exist: {skill_path}")
        
        skill_md_path = skill_path / "SKILL.md"
        if not skill_md_path.exists():
            raise SkillLoaderError(f"SKILL.md not found in: {skill_path}")
        
        try:
            content = skill_md_path.read_text(encoding='utf-8')
        except Exception as e:
            raise SkillLoaderError(f"Failed to read SKILL.md: {e}")
        
        # Parse frontmatter and body
        metadata, body = self._parse_skill_content(content, skill_path.name)
        
        # Create skill object
        skill = Skill(
            metadata=metadata,
            skill_path=skill_path,
            body_content=body,
            resources={},
            is_loaded=False
        )
        
        # Load resources
        skill.resources = self._load_resources(skill_path)
        skill.is_loaded = True
        
        return skill
    
    def _parse_skill_content(self, content: str, default_name: str) -> Tuple[SkillMetadata, str]:
        """Parse SKILL.md content into metadata and body.
        
        Args:
            content: Full SKILL.md content
            default_name: Default name if not in frontmatter
            
        Returns:
            Tuple of (metadata, body)
        """
        match = self.FRONTMATTER_PATTERN.match(content)
        
        if not match:
            # No frontmatter found - treat entire content as body
            console.print(f"[yellow]Warning: No YAML frontmatter found in {default_name}[/]")
            metadata = SkillMetadata(
                name=default_name,
                description="No description provided"
            )
            return metadata, content
        
        yaml_content = match.group(1)
        body = match.group(2).strip()
        
        try:
            frontmatter = yaml.safe_load(yaml_content) or {}
        except yaml.YAMLError as e:
            raise SkillLoaderError(f"Invalid YAML frontmatter: {e}")
        
        # Extract metadata fields
        name = frontmatter.get('name', default_name)
        description = frontmatter.get('description', 'No description provided')
        version = frontmatter.get('version', '1.0.0')
        author = frontmatter.get('author')
        tags = frontmatter.get('tags', [])
        requires = frontmatter.get('requires', [])
        
        metadata = SkillMetadata(
            name=name,
            description=description,
            version=version,
            author=author,
            tags=tags if isinstance(tags, list) else [],
            requires=requires if isinstance(requires, list) else []
        )
        
        return metadata, body
    
    def _load_resources(self, skill_path: Path) -> Dict[str, SkillResource]:
        """Load all resources from skill directory.
        
        Args:
            skill_path: Path to skill directory
            
        Returns:
            Dictionary of resources keyed by type:name
        """
        resources = {}
        
        # Resource directories to scan
        resource_dirs = {
            'scripts': 'script',
            'references': 'reference',
            'assets': 'asset'
        }
        
        for dir_name, resource_type in resource_dirs.items():
            dir_path = skill_path / dir_name
            if dir_path.exists() and dir_path.is_dir():
                for item in dir_path.iterdir():
                    if item.is_file():
                        try:
                            content = item.read_text(encoding='utf-8')
                        except UnicodeDecodeError:
                            # Binary file - don't read content
                            content = None
                        
                        resource = SkillResource(
                            name=item.name,
                            path=item,
                            resource_type=resource_type,
                            content=content
                        )
                        key = f"{resource_type}:{item.name}"
                        resources[key] = resource
        
        return resources
    
    def discover_skills(self) -> List[Path]:
        """Discover all skill directories.
        
        Returns:
            List of paths to skill directories containing SKILL.md
        """
        skill_paths = []
        
        # Scan built-in skills
        if self.builtin_path.exists():
            for item in self.builtin_path.iterdir():
                if item.is_dir() and (item / "SKILL.md").exists():
                    skill_paths.append(item)
        
        # Scan user skills
        if self.user_path.exists():
            for item in self.user_path.iterdir():
                if item.is_dir() and (item / "SKILL.md").exists():
                    skill_paths.append(item)
        
        return skill_paths
    
    def load_all_skills(self) -> List[Skill]:
        """Load all discoverable skills.
        
        Returns:
            List of loaded Skill objects
        """
        skills = []
        skill_paths = self.discover_skills()
        
        for path in skill_paths:
            try:
                skill = self.load_skill(path)
                skills.append(skill)
            except SkillLoaderError as e:
                console.print(f"[red]Failed to load skill from {path}: {e}[/]")
        
        return skills
