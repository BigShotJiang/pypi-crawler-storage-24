"""
Skills CLI commands for EnkaliPrime CLI.

Provides commands for managing and using skills.
"""

from pathlib import Path
from typing import Optional
import typer
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich import box

from ..skills import get_registry, get_engine, SkillContext
from ..skills.loader import SkillLoader

app = typer.Typer(help="🛠️  Manage and use skills")
console = Console()


@app.callback()
def skills_callback():
    """Skills management commands."""
    pass


@app.command()
def list(
    builtin_only: bool = typer.Option(False, "--builtin", "-b", help="Show only built-in skills"),
    user_only: bool = typer.Option(False, "--user", "-u", help="Show only user skills"),
):
    """List all available skills."""
    registry = get_registry()
    registry.initialize()
    
    if builtin_only:
        skills = [s for s in registry.list_skills() 
                 if registry.loader.builtin_path in s.skill_path.parents]
        title = "Built-in Skills"
    elif user_only:
        skills = [s for s in registry.list_skills() 
                 if registry.loader.user_path in s.skill_path.parents]
        title = "User Skills"
    else:
        skills = registry.list_skills()
        title = "Available Skills"
    
    if not skills:
        console.print(f"[yellow]No {title.lower()} found.[/]")
        return
    
    # Build display
    text = Text()
    text.append(f"\n{title}\n", style="bold cyan")
    text.append("=" * 50 + "\n\n", style="dim")
    
    for skill in skills:
        skill_type = "Built-in" if registry.loader.builtin_path in skill.skill_path.parents else "User"
        text.append(f"• {skill.metadata.name}", style="bold green")
        text.append(f" v{skill.metadata.version}", style="dim")
        text.append(f" [{skill_type}]\n", style="cyan")
        text.append(f"  {skill.metadata.description[:80]}\n", style="dim white")
        
        # Show scripts count
        scripts = [r for r in skill.resources.values() if r.resource_type == 'script']
        if scripts:
            text.append(f"  Scripts: {len(scripts)}\n", style="dim cyan")
        
        text.append("\n")
    
    panel = Panel(
        text,
        title=f"[bold]{title}[/bold]",
        border_style="cyan",
        box=box.ROUNDED
    )
    console.print(panel)


@app.command()
def info(
    skill_name: str = typer.Argument(..., help="Name of the skill to show info for")
):
    """Show detailed information about a skill."""
    registry = get_registry()
    registry.initialize()
    
    skill = registry.get(skill_name)
    if not skill:
        console.print(f"[red]Skill not found: {skill_name}[/]")
        console.print("[dim]Use 'enkaliprime skills list' to see available skills.[/]")
        raise typer.Exit(1)
    
    # Build info display
    text = Text()
    
    # Header
    text.append(f"{skill.metadata.name}\n", style="bold cyan")
    text.append(f"Version: {skill.metadata.version}\n", style="dim")
    if skill.metadata.author:
        text.append(f"Author: {skill.metadata.author}\n", style="dim")
    text.append("\n")
    
    # Description
    text.append("Description:\n", style="bold")
    text.append(f"{skill.metadata.description}\n\n", style="white")
    
    # Tags
    if skill.metadata.tags:
        text.append("Tags: ", style="bold")
        text.append(f"{', '.join(skill.metadata.tags)}\n\n", style="cyan")
    
    # Location
    skill_type = "Built-in" if registry.loader.builtin_path in skill.skill_path.parents else "User"
    text.append(f"Location: {skill.skill_path}\n", style="dim")
    text.append(f"Type: {skill_type}\n\n", style="dim")
    
    # Resources
    scripts = [r for r in skill.resources.values() if r.resource_type == 'script']
    references = [r for r in skill.resources.values() if r.resource_type == 'reference']
    assets = [r for r in skill.resources.values() if r.resource_type == 'asset']
    
    if scripts:
        text.append("Scripts:\n", style="bold")
        for script in scripts:
            text.append(f"  • {script.name}\n", style="green")
        text.append("\n")
    
    if references:
        text.append("References:\n", style="bold")
        for ref in references:
            text.append(f"  • {ref.name}\n", style="yellow")
        text.append("\n")
    
    if assets:
        text.append("Assets:\n", style="bold")
        for asset in assets:
            text.append(f"  • {asset.name}\n", style="magenta")
        text.append("\n")
    
    # Instructions preview
    text.append("Instructions Preview:\n", style="bold")
    preview = skill.body_content[:500] + "..." if len(skill.body_content) > 500 else skill.body_content
    text.append(preview, style="dim white")
    
    panel = Panel(
        text,
        title=f"[bold]Skill Info: {skill_name}[/bold]",
        border_style="cyan",
        box=box.ROUNDED
    )
    console.print(panel)


@app.command()
def install(
    path: Path = typer.Argument(..., help="Path to skill directory to install", exists=True),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Override skill name")
):
    """Install a skill from a directory."""
    registry = get_registry()
    
    success = registry.install_skill(path, name)
    if success:
        console.print(f"[green]✓ Skill installed successfully![/]")
    else:
        console.print(f"[red]✗ Failed to install skill.[/]")
        raise typer.Exit(1)


@app.command()
def uninstall(
    skill_name: str = typer.Argument(..., help="Name of skill to uninstall"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation")
):
    """Uninstall a user skill."""
    registry = get_registry()
    registry.initialize()
    
    skill = registry.get(skill_name)
    if not skill:
        console.print(f"[red]Skill not found: {skill_name}[/]")
        raise typer.Exit(1)
    
    # Check if built-in
    if registry.loader.builtin_path in skill.skill_path.parents:
        console.print(f"[red]Cannot uninstall built-in skill: {skill_name}[/]")
        console.print("[dim]Built-in skills are part of the CLI package.[/]")
        raise typer.Exit(1)
    
    # Confirm
    if not force:
        confirm = typer.confirm(f"Are you sure you want to uninstall '{skill_name}'?")
        if not confirm:
            console.print("[dim]Uninstall cancelled.[/]")
            raise typer.Exit(0)
    
    success = registry.uninstall_skill(skill_name)
    if success:
        console.print(f"[green]✓ Skill '{skill_name}' uninstalled.[/]")
    else:
        console.print(f"[red]✗ Failed to uninstall skill.[/]")
        raise typer.Exit(1)


@app.command()
def reload():
    """Reload all skills from disk."""
    registry = get_registry()
    registry.reload()
    console.print("[green]✓ Skills reloaded.[/]")


@app.command()
def test(
    message: str = typer.Argument(..., help="Test message to match against skills"),
    execute: bool = typer.Option(False, "--execute", "-e", help="Execute the best matching skill")
):
    """Test skill matching against a message."""
    registry = get_registry()
    registry.initialize()
    
    engine = get_engine()
    
    # Find matches
    matches = registry.find_matching_skills(message)
    
    if not matches:
        console.print("[yellow]No skills matched the message.[/]")
        return
    
    console.print(f"\n[bold]Message:[/] {message}\n")
    console.print("[bold]Matching Skills:[/]")
    
    for i, match in enumerate(matches[:5], 1):
        confidence_color = "green" if match.confidence > 0.7 else "yellow" if match.confidence > 0.4 else "red"
        console.print(f"  {i}. {match.skill.metadata.name} - [" + confidence_color + f"]{match.confidence:.2f}[/] ({match.match_type})")
    
    if execute and matches:
        best_match = matches[0]
        console.print(f"\n[cyan]Executing: {best_match.skill.metadata.name}...[/]")
        
        context = SkillContext(
            user_message=message,
            working_directory=Path.cwd()
        )
        
        result = engine.execute(best_match.skill, context)
        
        if result.success:
            console.print(f"[green]✓ Success:[/] {result.message}")
            if result.output:
                console.print("\n[dim]Output:[/]")
                console.print(result.output[:1000])  # Limit output
        else:
            console.print(f"[red]✗ Failed:[/] {result.message}")
            if result.error:
                console.print(f"[red]Error:[/] {result.error}")
