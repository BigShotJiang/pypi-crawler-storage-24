"""
Channels CLI commands for EnkaliPrime CLI.

Provides commands for managing messaging channels (WhatsApp, Slack, Google Chat).
"""

import asyncio
import builtins
import json
import shutil
import base64
from pathlib import Path
from typing import Optional
import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich import box
from rich.layout import Layout
from rich.live import Live
from rich.prompt import Prompt, Confirm
from rich.align import Align
from rich.text import Text

from ..channels import (
    get_channel_manager, 
    WhatsAppChannel, WhatsAppConfig,
    SlackChannel, SlackConfig,
    GoogleChatChannel, GoogleChatConfig
)

app = typer.Typer(help="📱 Manage messaging channels (WhatsApp, Slack, Google Chat)")
console = Console()


_PERSISTED_LOADED = False


def _default_pocket_tts_dir() -> Path:
    return Path(r"D:\Programming Workspace\AI Models\pocket-tts")


def _resolve_pocket_tts_dir(channel_obj, provided_dir: Optional[str] = None) -> Path:
    if isinstance(provided_dir, str) and provided_dir.strip():
        return Path(provided_dir).expanduser()

    extra = getattr(getattr(channel_obj, "config", None), "extra", {}) or {}
    if isinstance(extra, dict):
        saved_dir = extra.get("tts_pocket_tts_dir")
        if isinstance(saved_dir, str) and saved_dir.strip():
            return Path(saved_dir).expanduser()

    return _default_pocket_tts_dir()


def _resolve_pocket_tts_voices_dir(channel_obj, provided_dir: Optional[str] = None) -> Path:
    d = _resolve_pocket_tts_dir(channel_obj, provided_dir)
    if d.name.lower() == "custom_voices":
        return d
    return d / "custom_voices"


def _channels_store_path() -> Path:
    root = Path.home() / ".enkaliprime"
    root.mkdir(parents=True, exist_ok=True)
    return root / "channels.json"


def _load_persisted_channels(manager) -> None:
    path = _channels_store_path()
    if not path.exists():
        return

    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return

    channels = data.get("channels")
    if not isinstance(channels, dict):
        return

    for channel_id, cfg in channels.items():
        if manager.get_channel(channel_id):
            continue
        info = AVAILABLE_CHANNELS.get(channel_id)
        if not info:
            continue
        extra = {}
        default_recipient = None
        if isinstance(cfg, dict) and isinstance(cfg.get("extra"), dict):
            extra = cfg.get("extra")
        if isinstance(cfg, dict) and cfg.get("default_recipient"):
            default_recipient = str(cfg.get("default_recipient"))

        config = info["config_class"](enabled=True, extra=extra)
        if default_recipient:
            config.default_recipient = default_recipient
        channel = info["channel_class"](config)
        manager.register_channel(channel)


def _save_persisted_channels(manager) -> None:
    data = {"channels": {}}
    for channel in manager.list_channels():
        extra = getattr(channel.config, "extra", {}) or {}
        data["channels"][channel.name] = {
            "extra": extra,
            "default_recipient": getattr(channel.config, "default_recipient", None),
        }

    path = _channels_store_path()
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def _default_whatsapp_session_path() -> Path:
    return (Path.home() / ".enkaliprime" / "whatsapp").expanduser()


def _reset_whatsapp_session(session_path: Path) -> None:
    if session_path.exists():
        shutil.rmtree(session_path, ignore_errors=True)
    session_path.mkdir(parents=True, exist_ok=True)


@app.callback()
def channels_callback():
    """Channel management commands."""
    global _PERSISTED_LOADED
    if _PERSISTED_LOADED:
        return
    manager = get_channel_manager()
    _load_persisted_channels(manager)
    _PERSISTED_LOADED = True


@app.command(name="list")
def list_channels():
    """List all configured channels."""
    manager = get_channel_manager()
    
    channels = manager.list_channels()
    
    if not channels:
        console.print("[yellow]No channels configured.[/]")
        console.print("[dim]Use 'enkaliprime channels add <type>' to add channels.[/]")
        return
    
    table = Table(title="Configured Channels")
    table.add_column("Name", style="cyan")
    table.add_column("Type", style="green")
    table.add_column("Status", style="yellow")
    table.add_column("Enabled", style="magenta")
    table.add_column("Auto-start", style="blue")
    
    for channel in channels:
        status = "Connected" if channel.is_connected else "Disconnected"
        status_style = "green" if channel.is_connected else "red"
        
        table.add_row(
            channel.name,
            channel.channel_type.value,
            f"[{status_style}]{status}[/]",
            "Yes" if channel.config.enabled else "No",
            "Yes" if channel.config.auto_start else "No"
        )
    
    console.print(table)


@app.command()
def add(
    channel_type: str = typer.Argument(..., help="Channel type: whatsapp, slack, google-chat"),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Channel name (optional)")
):
    """Add a new channel."""
    manager = get_channel_manager()
    
    channel_type = channel_type.lower().replace("-", "_")
    
    if channel_type == "whatsapp":
        config = WhatsAppConfig(
            enabled=True,
            auto_start=False,
            require_pairing=True
        )
        channel = WhatsAppChannel(config)
        
    elif channel_type == "slack":
        config = SlackConfig(
            enabled=True,
            auto_start=False,
            require_pairing=False
        )
        channel = SlackChannel(config)
        
    elif channel_type in ["google_chat", "google-chat", "googlechat"]:
        config = GoogleChatConfig(
            enabled=True,
            auto_start=False,
            require_pairing=True
        )
        channel = GoogleChatChannel(config)
        
    else:
        console.print(f"[red]Unknown channel type: {channel_type}[/]")
        console.print("[dim]Supported: whatsapp, slack, google-chat[/]")
        raise typer.Exit(1)

    # Use provided name or default
    if name:
        channel.name = name

    manager.register_channel(channel)
    _save_persisted_channels(manager)

    console.print(f"[green]✓ Added {channel_type} channel: {channel.name}[/]")
    console.print(f"[dim]Configure with 'enkaliprime config' before using.[/]")


@app.command(name="reset-session")
def reset_session(
    channel: str = typer.Argument(..., help="Channel type/name to reset (e.g. whatsapp)"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
):
    """Reset a channel's local session/auth data (useful if logged out)."""
    channel_id = channel.lower().replace("-", "_")
    if channel_id != "whatsapp":
        console.print(f"[red]Session reset not supported for: {channel}[/]")
        raise typer.Exit(1)

    manager = get_channel_manager()
    ch = manager.get_channel("whatsapp")

    session_path = _default_whatsapp_session_path()
    if ch is not None:
        try:
            extra = getattr(ch.config, "extra", {}) or {}
            if isinstance(extra, dict) and extra.get("session_path"):
                session_path = Path(str(extra.get("session_path"))).expanduser()
        except Exception:
            pass

    if not force:
        if not Confirm.ask(f"Reset WhatsApp session at '{session_path}'?", default=False):
            console.print("[dim]Cancelled.[/]")
            raise typer.Exit(0)

    _reset_whatsapp_session(session_path)
    console.print("[green]✓ WhatsApp session reset.[/]")
    console.print("[dim]Now run: enkaliprime channels connect whatsapp[/]")


@app.command()
def remove(
    name: str = typer.Argument(..., help="Channel name to remove"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation")
):
    """Remove a channel."""
    manager = get_channel_manager()
    
    channel = manager.get_channel(name)
    if not channel:
        console.print(f"[red]Channel not found: {name}[/]")
        raise typer.Exit(1)
    
    if not force:
        confirm = typer.confirm(f"Remove channel '{name}'?")
        if not confirm:
            console.print("[dim]Cancelled.[/]")
            raise typer.Exit(0)
    
    # Disconnect if connected
    if channel.is_connected:
        asyncio.run(channel.disconnect())
    
    success = manager.unregister_channel(name)
    if success:
        _save_persisted_channels(manager)
        console.print(f"[green]✓ Removed channel: {name}[/]")
    else:
        console.print(f"[red]Failed to remove channel[/]")
        raise typer.Exit(1)


@app.command()
def connect(
    name: str = typer.Argument(..., help="Channel name to connect"),
    reset_session: bool = typer.Option(False, "--reset-session", help="Reset local session/auth data before connecting (WhatsApp only)"),
):
    """Connect to a channel."""
    manager = get_channel_manager()
    
    channel = manager.get_channel(name)
    if not channel:
        # Convenience: allow connecting to a known channel type even if not activated yet.
        channel_id = name.lower().replace("-", "_")
        info = AVAILABLE_CHANNELS.get(channel_id)
        if not info:
            console.print(f"[red]Channel not found: {name}[/]")
            raise typer.Exit(1)

        console.print(f"[yellow]Channel '{channel_id}' not activated. Activating now…[/]")
        config = info["config_class"](enabled=True, extra={})
        channel = info["channel_class"](config)
        manager.register_channel(channel)
        _save_persisted_channels(manager)

    # Optional: reset WhatsApp session before connect
    if reset_session:
        channel_id = name.lower().replace("-", "_")
        if channel_id != "whatsapp":
            console.print("[red]--reset-session is only supported for WhatsApp[/]")
            raise typer.Exit(1)

        session_path = _default_whatsapp_session_path()
        try:
            extra = getattr(channel.config, "extra", {}) or {}
            if isinstance(extra, dict) and extra.get("session_path"):
                session_path = Path(str(extra.get("session_path"))).expanduser()
        except Exception:
            pass

        console.print(f"[yellow]Resetting WhatsApp session at '{session_path}'…[/]")
        _reset_whatsapp_session(session_path)
    
    console.print(f"[cyan]Connecting to {name}...[/]")
    
    result = asyncio.run(channel.connect())
    
    if result:
        console.print(f"[green]✓ Connected to {name}[/]")
    else:
        console.print(f"[red]✗ Failed to connect to {name}[/]")
        console.print("[dim]Check configuration and credentials.[/]")
        raise typer.Exit(1)


@app.command()
def disconnect(name: str = typer.Argument(..., help="Channel name to disconnect")):
    """Disconnect from a channel."""
    manager = get_channel_manager()
    
    channel = manager.get_channel(name)
    if not channel:
        console.print(f"[red]Channel not found: {name}[/]")
        raise typer.Exit(1)
    
    asyncio.run(channel.disconnect())
    console.print(f"[yellow]Disconnected from {name}[/]")


@app.command()
def send(
    channel: str = typer.Argument(..., help="Channel name"),
    message: str = typer.Argument(..., help="Message to send"),
    to: Optional[str] = typer.Option(None, "--to", "-t", help="Recipient ID (uses default if not provided)"),
):
    """Send a message through a channel."""
    manager = get_channel_manager()
    
    channel_obj = manager.get_channel(channel)
    if not channel_obj:
        console.print(f"[red]Channel not found: {channel}[/]")
        raise typer.Exit(1)
    
    if not channel_obj.is_connected:
        # Auto-connect for WhatsApp and Slack
        if channel_obj.channel_type.value == "whatsapp":
             pass # WhatsApp handles its own connection logic internally or relies on session
        elif channel_obj.channel_type.value == "slack":
             console.print("[dim]Connecting to Slack...[/]")
             if not asyncio.run(channel_obj.connect()):
                 console.print("[red]Failed to connect to Slack.[/]")
                 raise typer.Exit(1)
        else:
            console.print(f"[red]Channel not connected: {channel}[/]")
            console.print(f"[dim]Run: enkaliprime channels connect {channel}[/]")
            raise typer.Exit(1)
    
    # Use default recipient if not provided
    recipient = to
    if not recipient:
        recipient = channel_obj.config.default_recipient
        if not recipient:
            console.print(f"[red]No recipient provided and no default set for {channel}[/]")
            console.print(f"[dim]Set default: enkaliprime channels set-recipient {channel} <number>[/]")
            raise typer.Exit(1)
        console.print(f"[dim]Using default recipient: {recipient}[/]")
    
    result = asyncio.run(channel_obj.send_message(recipient, message))
    
    if result.success:
        console.print(f"[green]✓ Message sent[/]")
        if result.message_id:
            console.print(f"[dim]Message ID: {result.message_id}[/]")
    else:
        console.print(f"[red]✗ Failed to send: {result.error}[/]")
        raise typer.Exit(1)


@app.command(name="send-voice")
def send_voice(
    channel: str = typer.Argument(..., help="Channel name (currently only 'whatsapp' is supported)"),
    audio_file: str = typer.Argument(..., help="Path to audio file (WAV, OGG, MP3, etc.)"),
    to: Optional[str] = typer.Option(None, "--to", "-t", help="Recipient ID (uses default if not provided)"),
):
    """Send a voice note through a channel."""
    manager = get_channel_manager()
    
    channel_obj = manager.get_channel(channel)
    if not channel_obj:
        console.print(f"[red]Channel not found: {channel}[/]")
        raise typer.Exit(1)
    
    # Check if channel supports voice notes
    if not hasattr(channel_obj, 'send_voice_note'):
        console.print(f"[red]Channel {channel} does not support voice notes[/]")
        console.print("[dim]Currently only WhatsApp supports voice notes[/]")
        raise typer.Exit(1)
    
    # Check if audio file exists
    audio_path = Path(audio_file)
    if not audio_path.exists():
        console.print(f"[red]Audio file not found: {audio_file}[/]")
        raise typer.Exit(1)
    
    # Use default recipient if not provided
    recipient = to
    if not recipient:
        recipient = channel_obj.config.default_recipient
        if not recipient:
            console.print(f"[red]No recipient provided and no default set for {channel}[/]")
            console.print(f"[dim]Set default: enkaliprime channels set-recipient {channel} <number>[/]")
            raise typer.Exit(1)
        console.print(f"[dim]Using default recipient: {recipient}[/]")
    
    try:
        # Read audio file
        console.print(f"[dim]Reading audio file: {audio_file}[/]")
        audio_bytes = audio_path.read_bytes()
        
        if not audio_bytes:
            console.print(f"[red]Audio file is empty: {audio_file}[/]")
            raise typer.Exit(1)
        
        console.print(f"[dim]Audio file size: {len(audio_bytes)} bytes[/]")
        
        # Send voice note
        console.print("[yellow]Sending voice note...[/]")
        result = asyncio.run(channel_obj.send_voice_note(recipient, audio_bytes))
        
        if result.success:
            console.print(f"[green]✓ Voice note sent[/]")
            if result.message_id:
                console.print(f"[dim]Message ID: {result.message_id}[/]")
        else:
            console.print(f"[red]✗ Failed to send voice note: {result.error}[/]")
            raise typer.Exit(1)
            
    except Exception as e:
        console.print(f"[red]Error processing audio file: {e}[/]")
        console.print("[dim]Make sure the file is a valid audio format (WAV, OGG, MP3, etc.)[/]")
        raise typer.Exit(1)


@app.command(name="download-voice")
def download_voice(
    channel: str = typer.Argument(..., help="Channel name (currently only 'whatsapp' is supported)"),
    message_id: str = typer.Argument(..., help="Message ID of the voice note to download"),
    sender_jid: str = typer.Argument(..., help="Sender JID (phone number with @s.whatsapp.net)"),
    output_file: str = typer.Argument(..., help="Output file path to save the voice note"),
):
    """Download a voice note from a channel."""
    manager = get_channel_manager()
    
    channel_obj = manager.get_channel(channel)
    if not channel_obj:
        console.print(f"[red]Channel not found: {channel}[/]")
        raise typer.Exit(1)
    
    # Check if channel supports voice note downloading
    if not hasattr(channel_obj, 'download_voice_note'):
        console.print(f"[red]Channel {channel} does not support voice note downloading[/]")
        console.print("[dim]Currently only WhatsApp supports voice note downloading[/]")
        raise typer.Exit(1)
    
    try:
        # Download voice note
        console.print(f"[yellow]Downloading voice note {message_id}...[/]")
        audio_bytes = asyncio.run(channel_obj.download_voice_note(message_id, sender_jid))
        
        if not audio_bytes:
            console.print(f"[red]Failed to download voice note[/]")
            raise typer.Exit(1)
        
        # Save to file
        output_path = Path(output_file)
        console.print(f"[dim]Saving to: {output_path}[/]")
        output_path.write_bytes(audio_bytes)
        
        console.print(f"[green]✓ Voice note downloaded successfully[/]")
        console.print(f"[dim]File: {output_path}[/]")
        console.print(f"[dim]Size: {len(audio_bytes)} bytes[/]")
        
    except Exception as e:
        console.print(f"[red]Error downloading voice note: {e}[/]")
        raise typer.Exit(1)


@app.command(name="set-recipient")
def set_recipient(
    channel: str = typer.Argument(..., help="Channel name"),
    recipient: str = typer.Argument(..., help="Default recipient ID/phone number"),
):
    """Set default recipient for a channel (stored in config)."""
    manager = get_channel_manager()
    
    channel_obj = manager.get_channel(channel)
    if not channel_obj:
        console.print(f"[red]Channel not found: {channel}[/]")
        raise typer.Exit(1)
    
    # Set the default recipient
    channel_obj.config.default_recipient = recipient
    
    # Save to persistence
    _save_persisted_channels(manager)
    
    console.print(f"[green]✓ Default recipient set for {channel}[/]")
    console.print(f"[dim]Number: {recipient}[/]")
    console.print(f"[dim]Now you can send without specifying recipient:[/]")
    console.print(f"[dim]  enkaliprime channels send {channel} \"Hello!\"[/]")


@app.command(name="slack-set-tokens")
def slack_set_tokens(
    bot_token: str = typer.Option(..., "--bot-token", help="Slack bot token (xoxb-...)", show_default=False),
    app_token: str = typer.Option(..., "--app-token", help="Slack app token for Socket Mode (xapp-...)", show_default=False),
):
    """Configure Slack tokens (persisted in channels.json)."""
    manager = get_channel_manager()
    channel_obj = manager.get_channel("slack")
    if not channel_obj:
        console.print("[yellow]Slack channel not configured yet. Run: enkaliprime channels add slack[/]")
        raise typer.Exit(1)

    extra = getattr(channel_obj.config, "extra", {}) or {}
    if not isinstance(extra, dict):
        extra = {}
    extra["bot_token"] = bot_token.strip()
    extra["app_token"] = app_token.strip()
    channel_obj.config.extra = extra
    channel_obj.config.api_token = bot_token.strip()

    _save_persisted_channels(manager)
    console.print("[green]✓ Slack tokens saved[/]")


@app.command(name="slack-allow-channel")
def slack_allow_channel(
    channel_id: str = typer.Argument(..., help="Slack channel ID to allow (C... or G...)")
):
    """Allow a Slack channel for inbound messages."""
    manager = get_channel_manager()
    channel_obj = manager.get_channel("slack")
    if not channel_obj:
        console.print("[yellow]Slack channel not configured yet. Run: enkaliprime channels add slack[/]")
        raise typer.Exit(1)

    cid = str(channel_id).strip()
    if not cid:
        console.print("[red]Invalid channel id[/]")
        raise typer.Exit(1)

    extra = getattr(channel_obj.config, "extra", {}) or {}
    if not isinstance(extra, dict):
        extra = {}
    allowed = extra.get("allowed_channels")
    if not isinstance(allowed, list):
        allowed = []
    if cid not in allowed:
        allowed.append(cid)
    extra["allowed_channels"] = allowed
    channel_obj.config.extra = extra
    _save_persisted_channels(manager)
    console.print(f"[green]✓ Allowed Slack channel: {cid}[/]")


@app.command(name="slack-disallow-channel")
def slack_disallow_channel(
    channel_id: str = typer.Argument(..., help="Slack channel ID to remove from allowlist")
):
    """Remove a Slack channel from the allowlist."""
    manager = get_channel_manager()
    channel_obj = manager.get_channel("slack")
    if not channel_obj:
        console.print("[yellow]Slack channel not configured yet. Run: enkaliprime channels add slack[/]")
        raise typer.Exit(1)

    cid = str(channel_id).strip()
    extra = getattr(channel_obj.config, "extra", {}) or {}
    if not isinstance(extra, dict):
        extra = {}
    allowed = extra.get("allowed_channels")
    if not isinstance(allowed, list):
        allowed = []
    allowed = [c for c in allowed if str(c) != cid]
    extra["allowed_channels"] = allowed
    channel_obj.config.extra = extra
    _save_persisted_channels(manager)
    console.print(f"[green]✓ Disallowed Slack channel: {cid}[/]")


@app.command(name="slack-require-mention")
def slack_require_mention(
    enabled: bool = typer.Argument(..., help="true/false")
):
    """Require mentioning the bot for allowlisted channel messages."""
    manager = get_channel_manager()
    channel_obj = manager.get_channel("slack")
    if not channel_obj:
        console.print("[yellow]Slack channel not configured yet. Run: enkaliprime channels add slack[/]")
        raise typer.Exit(1)

    extra = getattr(channel_obj.config, "extra", {}) or {}
    if not isinstance(extra, dict):
        extra = {}
    extra["require_mention"] = bool(enabled)
    channel_obj.config.extra = extra
    _save_persisted_channels(manager)
    console.print(f"[green]✓ Slack require_mention set to: {bool(enabled)}[/]")


@app.command(name="slack-thread-mode")
def slack_thread_mode(
    channel_id: str = typer.Argument(..., help="Slack channel ID (C... or G...)") ,
    mode: str = typer.Argument(..., help="auto|thread|channel"),
):
    """Set per-channel threading behavior for Slack replies."""
    m = str(mode).strip().lower()
    if m not in {"auto", "thread", "channel"}:
        console.print("[red]Invalid mode. Use: auto|thread|channel[/]")
        raise typer.Exit(1)

    manager = get_channel_manager()
    channel_obj = manager.get_channel("slack")
    if not channel_obj:
        console.print("[yellow]Slack channel not configured yet. Run: enkaliprime channels add slack[/]")
        raise typer.Exit(1)

    cid = str(channel_id).strip()
    extra = getattr(channel_obj.config, "extra", {}) or {}
    if not isinstance(extra, dict):
        extra = {}
    mapping = extra.get("channel_thread_mode")
    if not isinstance(mapping, dict):
        mapping = {}
    mapping[cid] = m
    extra["channel_thread_mode"] = mapping
    channel_obj.config.extra = extra
    _save_persisted_channels(manager)
    console.print(f"[green]✓ Slack thread mode for {cid} set to: {m}[/]")


@app.command(name="allow-user")
def allow_user(
    channel: str = typer.Argument(..., help="Channel name"),
    user: str = typer.Argument(..., help="WhatsApp user phone number to allow (digits)"),
):
    """Allow an additional WhatsApp sender to receive replies in owner-only mode."""
    manager = get_channel_manager()
    channel_obj = manager.get_channel(channel)
    if not channel_obj:
        console.print(f"[red]Channel not found: {channel}[/]")
        raise typer.Exit(1)

    digits = "".join(ch for ch in str(user) if ch.isdigit())
    if not digits:
        console.print("[red]Invalid user number[/]")
        raise typer.Exit(1)

    extra = getattr(channel_obj.config, "extra", {}) or {}
    if not isinstance(extra, dict):
        extra = {}
    allowed = extra.get("allowed_users")
    if not isinstance(allowed, builtins.list):
        allowed = []

    if digits not in allowed:
        allowed.append(digits)
    extra["allowed_users"] = allowed
    channel_obj.config.extra = extra
    _save_persisted_channels(manager)
    console.print(f"[green]✓ Allowed WhatsApp user for {channel}[/]")
    console.print(f"[dim]{digits}[/]")


@app.command(name="remove-user")
def remove_user(
    channel: str = typer.Argument(..., help="Channel name"),
    user: str = typer.Argument(..., help="WhatsApp user phone number to remove"),
):
    """Remove a WhatsApp sender from the allowlist."""
    manager = get_channel_manager()
    channel_obj = manager.get_channel(channel)
    if not channel_obj:
        console.print(f"[red]Channel not found: {channel}[/]")
        raise typer.Exit(1)

    digits = "".join(ch for ch in str(user) if ch.isdigit())
    if not digits:
        console.print("[red]Invalid user number[/]")
        raise typer.Exit(1)

    extra = getattr(channel_obj.config, "extra", {}) or {}
    if not isinstance(extra, dict):
        extra = {}
    allowed = extra.get("allowed_users")
    if not isinstance(allowed, builtins.list):
        allowed = []

    if digits in allowed:
        allowed = [u for u in allowed if u != digits]
    extra["allowed_users"] = allowed
    channel_obj.config.extra = extra
    _save_persisted_channels(manager)
    console.print(f"[green]✓ Removed WhatsApp user for {channel}[/]")
    console.print(f"[dim]{digits}[/]")


@app.command(name="list-users")
def list_users(
    channel: str = typer.Argument(..., help="Channel name"),
):
    """List WhatsApp allowlisted users for a channel."""
    manager = get_channel_manager()
    channel_obj = manager.get_channel(channel)
    if not channel_obj:
        console.print(f"[red]Channel not found: {channel}[/]")
        raise typer.Exit(1)

    extra = getattr(channel_obj.config, "extra", {}) or {}
    allowed = []
    if isinstance(extra, dict) and isinstance(extra.get("allowed_users"), builtins.list):
        allowed = list(extra.get("allowed_users"))

    console.print(f"[cyan]Allowed WhatsApp users for {channel}:[/]")
    if not allowed:
        console.print("[dim](none)[/]")
        return
    for u in allowed:
        console.print(f"[dim]- {u}[/]")


@app.command(name="tts-add-voice")
def tts_add_voice(
    channel: str = typer.Argument(..., help="Channel name"),
    name: str = typer.Argument(..., help="Voice name (e.g. auwanga)"),
    wav_path: str = typer.Argument(..., help="Path to voice conditioning wav file"),
):
    """Register a named TTS voice for WhatsApp voice replies."""
    manager = get_channel_manager()
    channel_obj = manager.get_channel(channel)
    if not channel_obj:
        console.print(f"[red]Channel not found: {channel}[/]")
        raise typer.Exit(1)

    voice_name = str(name).strip()
    if not voice_name:
        console.print("[red]Invalid voice name[/]")
        raise typer.Exit(1)

    wav = str(Path(str(wav_path)).expanduser())
    if not wav:
        console.print("[red]Invalid wav path[/]")
        raise typer.Exit(1)

    extra = getattr(channel_obj.config, "extra", {}) or {}
    if not isinstance(extra, dict):
        extra = {}
    voices = extra.get("tts_voices")
    if not isinstance(voices, dict):
        voices = {}

    voices[voice_name] = wav
    extra["tts_voices"] = voices
    channel_obj.config.extra = extra
    _save_persisted_channels(manager)

    console.print(f"[green]✓ Added TTS voice for {channel}[/]")
    console.print(f"[dim]{voice_name} -> {wav}[/]")


@app.command(name="tts-remove-voice")
def tts_remove_voice(
    channel: str = typer.Argument(..., help="Channel name"),
    name: str = typer.Argument(..., help="Voice name to remove"),
):
    """Remove a named TTS voice from the registry."""
    manager = get_channel_manager()
    channel_obj = manager.get_channel(channel)
    if not channel_obj:
        console.print(f"[red]Channel not found: {channel}[/]")
        raise typer.Exit(1)

    voice_name = str(name).strip()
    if not voice_name:
        console.print("[red]Invalid voice name[/]")
        raise typer.Exit(1)

    extra = getattr(channel_obj.config, "extra", {}) or {}
    if not isinstance(extra, dict):
        extra = {}
    voices = extra.get("tts_voices")
    if not isinstance(voices, dict):
        voices = {}

    if voice_name in voices:
        voices.pop(voice_name, None)
    extra["tts_voices"] = voices

    default_voice = extra.get("tts_default_voice")
    if default_voice == voice_name:
        extra.pop("tts_default_voice", None)

    channel_obj.config.extra = extra
    _save_persisted_channels(manager)

    console.print(f"[green]✓ Removed TTS voice for {channel}[/]")
    console.print(f"[dim]{voice_name}[/]")


@app.command(name="tts-list-voices")
def tts_list_voices(
    channel: str = typer.Argument(..., help="Channel name"),
):
    """List registered TTS voices and the current default."""
    manager = get_channel_manager()
    channel_obj = manager.get_channel(channel)
    if not channel_obj:
        console.print(f"[red]Channel not found: {channel}[/]")
        raise typer.Exit(1)

    extra = getattr(channel_obj.config, "extra", {}) or {}
    voices = {}
    default_voice = None
    if isinstance(extra, dict):
        if isinstance(extra.get("tts_voices"), dict):
            voices = dict(extra.get("tts_voices"))
        if isinstance(extra.get("tts_default_voice"), str):
            default_voice = extra.get("tts_default_voice")

    console.print(f"[cyan]TTS voices for {channel}:[/]")
    if not voices:
        console.print("[dim](none)[/]")
    else:
        for k, v in voices.items():
            mark = "[green]*[/]" if default_voice == k else " "
            console.print(f"[dim]{mark} {k} -> {v}[/]")

    if default_voice:
        console.print(f"[dim]Default: {default_voice}[/]")
    else:
        console.print("[dim]Default: (not set)[/]")


@app.command(name="tts-set-default-voice")
def tts_set_default_voice(
    channel: str = typer.Argument(..., help="Channel name"),
    name_or_path: str = typer.Argument(..., help="Voice name from registry, or a wav path"),
):
    """Set default TTS voice used by --voice replies (name or direct wav path)."""
    manager = get_channel_manager()
    channel_obj = manager.get_channel(channel)
    if not channel_obj:
        console.print(f"[red]Channel not found: {channel}[/]")
        raise typer.Exit(1)

    val = str(name_or_path).strip()
    if not val:
        console.print("[red]Invalid voice value[/]")
        raise typer.Exit(1)

    extra = getattr(channel_obj.config, "extra", {}) or {}
    if not isinstance(extra, dict):
        extra = {}

    extra["tts_default_voice"] = val
    channel_obj.config.extra = extra
    _save_persisted_channels(manager)

    console.print(f"[green]✓ Default TTS voice set for {channel}[/]")
    console.print(f"[dim]{val}[/]")


@app.command(name="tts-pick-default-voice")
def tts_pick_default_voice(
    channel: str = typer.Argument(..., help="Channel name"),
):
    """Interactively pick the default TTS voice from a numbered list."""
    manager = get_channel_manager()
    channel_obj = manager.get_channel(channel)
    if not channel_obj:
        console.print(f"[red]Channel not found: {channel}[/]")
        raise typer.Exit(1)

    extra = getattr(channel_obj.config, "extra", {}) or {}
    if not isinstance(extra, dict):
        extra = {}

    voices = extra.get("tts_voices")
    if not isinstance(voices, dict) or not voices:
        console.print("[yellow]No TTS voices registered.[/]")
        console.print(f"[dim]Add one with: enkaliprime channels tts-add-voice {channel} <name> <wav_path>[/]")
        raise typer.Exit(1)

    default_voice = extra.get("tts_default_voice")
    keys = sorted([str(k) for k in voices.keys()])

    console.print(f"[cyan]Pick default TTS voice for {channel}:[/]")
    for i, k in enumerate(keys, start=1):
        mark = "*" if default_voice == k else " "
        console.print(f"[dim]{i}. [{mark}] {k}[/]")

    choice = Prompt.ask("Enter number", default="1")
    try:
        idx = int(str(choice).strip())
    except Exception:
        console.print("[red]Invalid selection[/]")
        raise typer.Exit(1)

    if idx < 1 or idx > len(keys):
        console.print("[red]Selection out of range[/]")
        raise typer.Exit(1)

    picked = keys[idx - 1]
    extra["tts_default_voice"] = picked
    channel_obj.config.extra = extra
    _save_persisted_channels(manager)

    console.print(f"[green]✓ Default TTS voice set for {channel}[/]")
    console.print(f"[dim]{picked}[/]")


@app.command(name="tts-set-dir")
def tts_set_dir(
    channel: str = typer.Argument(..., help="Channel name"),
    pocket_tts_dir: str = typer.Argument(..., help="Path to the Pocket-TTS folder"),
):
    """Save a custom Pocket-TTS directory for this channel."""
    manager = get_channel_manager()
    channel_obj = manager.get_channel(channel)
    if not channel_obj:
        console.print(f"[red]Channel not found: {channel}[/]")
        raise typer.Exit(1)

    resolved_dir = Path(str(pocket_tts_dir)).expanduser()
    if not resolved_dir.exists() or not resolved_dir.is_dir():
        console.print(f"[red]Directory not found: {resolved_dir}[/]")
        raise typer.Exit(1)

    extra = getattr(channel_obj.config, "extra", {}) or {}
    if not isinstance(extra, dict):
        extra = {}

    extra["tts_pocket_tts_dir"] = str(resolved_dir)
    channel_obj.config.extra = extra
    _save_persisted_channels(manager)

    voices_dir = _resolve_pocket_tts_voices_dir(channel_obj)
    console.print(f"[green]✓ Pocket-TTS directory saved for {channel}[/]")
    console.print(f"[dim]Base directory: {resolved_dir}[/]")
    console.print(f"[dim]Voice import directory: {voices_dir}[/]")


@app.command(name="tts-import-voices")
def tts_import_voices(
    channel: str = typer.Argument(..., help="Channel name"),
    voices_dir: str = typer.Option(
        str(_default_pocket_tts_dir() / "custom_voices"),
        "--dir",
        help="Directory containing voice .wav files",
    ),
    include_predefined: bool = typer.Option(
        True,
        "--include-predefined/--no-include-predefined",
        help="Also import Pocket-TTS predefined voices (e.g. alba, marius) if pocket_tts is installed",
    ),
    set_default: Optional[str] = typer.Option(
        None,
        "--set-default",
        help="Optionally set default voice by name after import (e.g. auwanga)",
        show_default=False,
    ),
):
    """Bulk import all .wav voices from a directory into the TTS registry."""
    manager = get_channel_manager()
    channel_obj = manager.get_channel(channel)
    if not channel_obj:
        console.print(f"[red]Channel not found: {channel}[/]")
        raise typer.Exit(1)

    d = _resolve_pocket_tts_voices_dir(channel_obj, voices_dir)
    wavs = []
    if d.exists() and d.is_dir():
        wavs = sorted([p for p in d.iterdir() if p.is_file() and p.suffix.lower() == ".wav"])
    elif not include_predefined:
        console.print(f"[red]Directory not found: {d}[/]")
        raise typer.Exit(1)

    extra = getattr(channel_obj.config, "extra", {}) or {}
    if not isinstance(extra, dict):
        extra = {}
    voices = extra.get("tts_voices")
    if not isinstance(voices, dict):
        voices = {}

    added = 0
    for p in wavs:
        name = p.stem.strip()
        if not name:
            continue
        voices[name] = str(p)
        added += 1

    predefined_added = 0
    if include_predefined:
        try:
            from pocket_tts.utils.utils import PREDEFINED_VOICES

            for k in PREDEFINED_VOICES.keys():
                name = str(k).strip()
                if not name:
                    continue
                if name not in voices:
                    voices[name] = name
                    predefined_added += 1
        except Exception:
            predefined_added = 0

    extra["tts_voices"] = voices

    if isinstance(set_default, str) and set_default.strip():
        extra["tts_default_voice"] = set_default.strip()
    elif "tts_default_voice" not in extra and "auwanga" in voices:
        extra["tts_default_voice"] = "auwanga"

    channel_obj.config.extra = extra
    _save_persisted_channels(manager)

    total_added = int(added) + int(predefined_added)
    console.print(f"[green]✓ Imported {total_added} voice(s) for {channel}[/]")
    if wavs:
        console.print(f"[dim]From: {d}[/]")


@app.command()
def pairing(
    channel: str = typer.Argument(..., help="Channel name"),
    code: str = typer.Argument(..., help="Pairing code to approve"),
    user_id: str = typer.Option(..., "--user", "-u", help="User ID to approve")
):
    """Approve a pairing request."""
    manager = get_channel_manager()
    
    channel_obj = manager.get_channel(channel)
    if not channel_obj:
        console.print(f"[red]Channel not found: {channel}[/]")
        raise typer.Exit(1)
    
    result = asyncio.run(channel_obj.approve_pairing(code, user_id))
    
    if result:
        console.print(f"[green]✓ Approved pairing for {user_id}[/]")
    else:
        console.print(f"[red]✗ Invalid pairing code[/]")
        raise typer.Exit(1)


@app.command()
def info(name: str = typer.Argument(..., help="Channel name")):
    """Show channel information."""
    manager = get_channel_manager()
    
    channel = manager.get_channel(name)
    if not channel:
        console.print(f"[red]Channel not found: {name}[/]")
        raise typer.Exit(1)
    
    # Build info panel
    from rich.text import Text
    
    text = Text()
    text.append(f"Channel: {channel.name}\n", style="bold cyan")
    text.append(f"Type: {channel.channel_type.value}\n", style="green")
    text.append(f"Connected: {'Yes' if channel.is_connected else 'No'}\n", 
               style="green" if channel.is_connected else "red")
    text.append(f"Enabled: {'Yes' if channel.config.enabled else 'No'}\n")
    text.append(f"Auto-start: {'Yes' if channel.config.auto_start else 'No'}\n")
    text.append(f"Require pairing: {'Yes' if channel.config.require_pairing else 'No'}\n")
    
    if channel.config.default_recipient:
        text.append(f"Default recipient: {channel.config.default_recipient}\n", style="yellow")
    
    if channel.config.allow_from:
        text.append(f"\nAllowed senders: {len(channel.config.allow_from)}\n")
    
    panel = Panel(
        text,
        title=f"[bold]Channel Info: {name}[/bold]",
        border_style="cyan",
        box=box.ROUNDED
    )
    console.print(panel)


# Available channel types for the browser
AVAILABLE_CHANNELS = {
    "whatsapp": {
        "name": "WhatsApp",
        "description": "Connect via WhatsApp Web (QR code scan)",
        "features": ["Real-time messaging", "QR authentication", "Session persistence"],
        "icon": "💬",
        "color": "green",
        "channel_class": WhatsAppChannel,
        "config_class": WhatsAppConfig,
    },
    "slack": {
        "name": "Slack",
        "description": "Connect to Slack workspace via Bot Token",
        "features": ["Multi-channel support", "Thread handling", "Rich formatting"],
        "icon": "💼",
        "color": "purple",
        "channel_class": SlackChannel,
        "config_class": SlackConfig,
    },
    "google_chat": {
        "name": "Google Chat",
        "description": "Connect via Google Chat API",
        "features": ["Space support", "Thread replies", "Google Workspace"],
        "icon": "💻",
        "color": "blue",
        "channel_class": GoogleChatChannel,
        "config_class": GoogleChatConfig,
    },
}


@app.command(name="browse")
def browse_channels():
    """
    🌐 Interactive channel browser - view, select, and activate channels.
    
    Shows all available channel types with graphical display.
    Select a channel to activate (add) and optionally connect.
    """
    manager = get_channel_manager()
    
    console.print("\n[bold cyan]📡 Available Channels[/bold cyan]\n")
    
    # Create channel cards
    for idx, (channel_id, info) in enumerate(AVAILABLE_CHANNELS.items(), 1):
        # Check if already configured
        existing = manager.get_channel(channel_id)
        status = "[green]● Active[/green]" if existing else "[dim]○ Inactive[/dim]"
        
        # Build features list
        features_text = "  ".join([f"[dim]• {f}[/dim]" for f in info["features"]])
        
        # Create panel for each channel
        panel_content = f"""
[bold {info['color']}]{info['icon']} {info['name']}[/bold {info['color']}] {status}

{info['description']}

[dim]Features:[/dim] {features_text}
        """.strip()
        
        panel = Panel(
            panel_content,
            border_style=info["color"] if existing else "dim",
            box=box.ROUNDED,
            title=f"[bold][{idx}][/bold]",
            title_align="left"
        )
        console.print(panel)
        console.print()
    
    # Selection prompt
    console.print("[dim]Enter number to select, or 'q' to quit[/dim]")
    choice = Prompt.ask("Select channel", default="q")
    
    if choice.lower() == "q":
        console.print("[dim]Cancelled[/dim]")
        return
    
    # Validate choice
    try:
        idx = int(choice) - 1
        if idx < 0 or idx >= len(AVAILABLE_CHANNELS):
            console.print("[red]Invalid selection[/red]")
            return
    except ValueError:
        console.print("[red]Invalid input[/red]")
        return
    
    # Get selected channel
    channel_keys = [k for k in AVAILABLE_CHANNELS.keys()]
    channel_id = channel_keys[idx]
    info = AVAILABLE_CHANNELS[channel_id]
    
    # Check if already exists
    existing = manager.get_channel(channel_id)
    if existing:
        console.print(f"\n[yellow]⚠ {info['name']} is already configured[/yellow]")
        action = Prompt.ask(
            "Choose action",
            choices=["connect", "remove", "cancel"],
            default="connect"
        )
        
        if action == "connect":
            _connect_channel(channel_id, existing)
        elif action == "remove":
            remove(channel_id)
        return
    
    # Activate (add) new channel
    console.print(f"\n[bold {info['color']}]▶ Activating {info['name']}...[/bold {info['color']}]")
    
    # Create config with defaults
    config = info["config_class"](
        enabled=True,
        extra={}
    )
    
    # Create and register channel
    channel = info["channel_class"](config)
    manager.register_channel(channel)
    _save_persisted_channels(manager)
    
    console.print(f"[green]✓ {info['name']} activated![/green]\n")
    
    # Offer to connect immediately
    if Confirm.ask(f"Connect to {info['name']} now?"):
        _connect_channel(channel_id, channel)


def _connect_channel(channel_id: str, channel):
    """Helper to connect a channel with async support."""
    console.print(f"\n[bold cyan]Connecting to {channel_id}...[/bold cyan]\n")
    
    async def do_connect():
        success = await channel.connect()
        if success:
            console.print(f"\n[green]✓ {channel_id} connected successfully![/green]")
            
            # Show status if available
            if hasattr(channel, 'get_status'):
                status = channel.get_status()
                if status.get('qr_pending'):
                    console.print("[yellow]⏳ Waiting for QR code scan...[/yellow]")
        else:
            console.print(f"\n[red]✗ Failed to connect {channel_id}[/red]")
    
    asyncio.run(do_connect())
@app.command(name="slack-list-channels")
def slack_list_channels(
    types: str = typer.Option("public_channel,private_channel,im,mpim", help="Comma-separated types (public_channel,private_channel,im,mpim)"),
):
    """List available Slack conversations (channels/DMs) with IDs."""
    manager = get_channel_manager()
    channel_obj = manager.get_channel("slack")
    if not channel_obj:
        console.print("[yellow]Slack channel not configured yet. Run: enkaliprime channels add slack[/]")
        raise typer.Exit(1)
        
    # Ensure connected
    if not channel_obj.is_connected:
        console.print("[cyan]Connecting to Slack...[/]")
        if not asyncio.run(channel_obj.connect()):
            console.print("[red]Failed to connect to Slack.[/]")
            raise typer.Exit(1)
            
    console.print("[cyan]Fetching conversations...[/]")
    try:
        convs = asyncio.run(channel_obj.get_conversations(types=types))
    except Exception as e:
        console.print(f"[red]Error: {e}[/]")
        # Disconnect cleanly
        asyncio.run(channel_obj.disconnect())
        raise typer.Exit(1)
        
    asyncio.run(channel_obj.disconnect())
    
    if not convs:
        console.print("[yellow]No conversations found.[/]")
        return

    table = Table(title="Slack Conversations")
    table.add_column("ID", style="cyan")
    table.add_column("Name/User", style="green")
    table.add_column("Type", style="magenta")
    table.add_column("Status", style="dim")
    
    for c in convs:
        c_type = "Channel"
        if c.get("is_im"): c_type = "DM"
        elif c.get("is_group"): c_type = "Group"
        if c.get("is_private") and not c.get("is_im"): c_type += " (Private)"
        
        status = []
        if c.get("is_archived"): status.append("Archived")
        
        table.add_row(
            c.get("id"),
            c.get("name") or "Unknown",
            c_type,
            ", ".join(status)
        )
        
    console.print(table)
