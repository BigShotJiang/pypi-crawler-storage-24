"""
Gateway CLI commands for EnkaliPrime CLI.

Provides commands for managing the message gateway service.
"""

import asyncio
import inspect
from typing import Optional, Any
import typer
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich import box
from rich.live import Live
from rich.spinner import Spinner
import keyring
from pathlib import Path

from ..gateway import get_gateway
from ..channels import get_channel_manager

app = typer.Typer(help="🌐 Manage message gateway service")
console = Console()


SERVICE_NAME = "enkaliprime-cli"


def _default_pocket_tts_dir() -> Path:
    return Path(r"D:\Programming Workspace\AI Models\pocket-tts")


def _resolve_voice_wav_fallback(manager) -> str:
    default_path = _default_pocket_tts_dir() / "custom_voices" / "auwanga.wav"
    channel = manager.get_channel("whatsapp")
    if channel is None:
        return str(default_path)

    extra = getattr(channel.config, "extra", {}) or {}
    if not isinstance(extra, dict):
        return str(default_path)

    pocket_tts_dir = extra.get("tts_pocket_tts_dir")
    if not isinstance(pocket_tts_dir, str) or not pocket_tts_dir.strip():
        return str(default_path)

    return str(Path(pocket_tts_dir).expanduser() / "custom_voices" / "auwanga.wav")


# Store running gateway task
_gateway_task: Optional[asyncio.Task] = None


@app.callback()
def gateway_callback():
    """Gateway service management commands."""
    pass


@app.command()
def start(
    daemon: bool = typer.Option(False, "--daemon", "-d", help="Run as background daemon"),
    cloud: bool = typer.Option(True, "--cloud/--no-cloud", help="Use cloud model for auto-replies (default: on)"),
    model: Optional[str] = typer.Option(None, "--model", "-m", help="Cloud model name (defaults to configured default cloud model)"),
    whatsapp: bool = typer.Option(False, "--whatsapp", help="Auto-connect WhatsApp and reply to inbound messages"),
    slack: bool = typer.Option(False, "--slack", help="Auto-connect Slack (Socket Mode) and reply to inbound messages"),
    enkaliprime: bool = typer.Option(False, "--enkaliprime", help="Use EnkaliPrime hosted model for auto-replies (requires enkaliprime config set-api-key)"),
    voice: bool = typer.Option(False, "--voice", help="Reply with WhatsApp voice notes using pocket-tts (falls back to text if unavailable)"),
    usersall: bool = typer.Option(False, "--usersall", help="Reply to all WhatsApp senders (default: only reply to configured default recipient)"),
    user: Optional[list[str]] = typer.Option(None, "--user", help="Additional allowed WhatsApp sender number(s) to reply to (repeatable)", show_default=False),
    me: bool = typer.Option(False, "--me", help="Allow responding to your own self-chat messages for testing"),
    system_prompt: Optional[str] = typer.Option(
        None,
        "--system-prompt",
        help="System prompt to use for cloud replies (overrides saved behavior)",
        show_default=False,
    ),
):
    """Start the gateway service."""
    global _gateway_task

    if isinstance(system_prompt, str) and system_prompt.strip():
        try:
            keyring.set_password(SERVICE_NAME, "system_prompt", system_prompt.strip())
        except Exception as e:
            try:
                root = Path.home() / ".enkaliprime"
                root.mkdir(parents=True, exist_ok=True)
                prompt_path = root / "system_prompt.txt"
                prompt_path.write_text(system_prompt.strip(), encoding="utf-8")
                try:
                    keyring.set_password(SERVICE_NAME, "system_prompt", f"@file:{prompt_path}")
                except Exception as e2:
                    console.print(
                        f"[yellow]Warning: failed to persist system prompt to keyring: {e}; fallback failed: {e2}[/]"
                    )
            except Exception as e2:
                console.print(
                    f"[yellow]Warning: failed to persist system prompt to keyring: {e}; fallback failed: {e2}[/]"
                )

    # Ensure persisted channels (from `enkaliprime channels ...`) are loaded.
    try:
        from . import channels as channels_cmd
        channels_cmd.channels_callback()
    except Exception:
        pass

    _remote_client = None

    def _extract_text(resp: Any) -> str:
        if resp is None:
            return ""
        if isinstance(resp, str):
            return resp
        # Common dict response shapes
        if isinstance(resp, dict):
            msg = resp.get("message")
            if isinstance(msg, dict) and isinstance(msg.get("content"), str):
                return msg.get("content")
            for k in ("content", "text", "response", "output"):
                if isinstance(resp.get(k), str):
                    return resp.get(k)
            return str(resp)

        # Common object response shapes
        msg = getattr(resp, "message", None)
        if msg is not None:
            content = getattr(msg, "content", None)
            if isinstance(content, str):
                return content
        content = getattr(resp, "content", None)
        if isinstance(content, str):
            return content
        text = getattr(resp, "text", None)
        if isinstance(text, str):
            return text
        return str(resp)

    async def ai_callback(prompt: str, session_ctx) -> str:
        nonlocal _remote_client

        if enkaliprime:
            api_key = keyring.get_password(SERVICE_NAME, "api_key")
            if not api_key:
                return "No EnkaliPrime API key configured. Run: enkaliprime config set-api-key"

            if _remote_client is None:
                from enkaliprime import EnkaliPrimeClient

                _remote_client = EnkaliPrimeClient({
                    "unified_api_key": api_key,
                    "base_url": "https://sdk.enkaliprime.com",
                })

            # Create or reuse a remote session per WhatsApp sender
            try:
                remote_session_id = None
                if session_ctx is not None and isinstance(getattr(session_ctx, "metadata", None), dict):
                    remote_session_id = session_ctx.metadata.get("remote_session_id")

                if not remote_session_id and hasattr(_remote_client, "create_session"):
                    s = _remote_client.create_session(agent_name="WhatsApp")
                    remote_session_id = getattr(s, "id", None)
                    if remote_session_id and session_ctx is not None and isinstance(session_ctx.metadata, dict):
                        session_ctx.metadata["remote_session_id"] = remote_session_id

                if hasattr(_remote_client, "send_message"):
                    console.print("[dim]AI provider: EnkaliPrime[/]")
                    if inspect.iscoroutinefunction(_remote_client.send_message):
                        resp = await _remote_client.send_message(
                            message=prompt,
                            session_id=remote_session_id,
                            loading=False,
                        )
                    else:
                        resp = await asyncio.to_thread(
                            _remote_client.send_message,
                            message=prompt,
                            session_id=remote_session_id,
                            loading=False,
                        )

                    text = _extract_text(resp).strip()
                    if not text:
                        return "(Empty response from EnkaliPrime model)"
                    console.print(f"[dim]AI reply preview: {text[:120]}[/]")
                    return text
            except Exception as e:
                return f"EnkaliPrime AI error: {e}"

            return "EnkaliPrime AI error: unknown"

        # Default: Ollama cloud
        if not cloud:
            return "Cloud AI is disabled. Start gateway with --cloud or use --enkaliprime."

        api_key = keyring.get_password(SERVICE_NAME, "ollama_cloud_api_key")
        if not api_key:
            return "No cloud API key configured. Run: enkaliprime config set-ollama-cloud-key"

        # Default model selection aligns with chat command behavior
        used_model = model
        if not used_model:
            used_model = keyring.get_password(SERVICE_NAME, "default_cloud_model") or "gpt-oss:120b"

        # Import here to avoid importing chat command module at import-time
        from .chat import OllamaCloudProvider

        provider = OllamaCloudProvider(api_key)
        console.print(f"[dim]AI provider: Ollama Cloud | model={used_model}[/]")
        console.print("[dim]Cloud AI connecting...[/]")

        configured_system_prompt = system_prompt
        if configured_system_prompt is None:
            configured_system_prompt = keyring.get_password(SERVICE_NAME, "system_prompt")

        if isinstance(configured_system_prompt, str) and configured_system_prompt.startswith("@file:"):
            try:
                p = Path(configured_system_prompt.removeprefix("@file:")).expanduser()
                configured_system_prompt = p.read_text(encoding="utf-8")
            except Exception:
                pass
        ai_name = keyring.get_password(SERVICE_NAME, "ai_name")
        ai_personality = keyring.get_password(SERVICE_NAME, "ai_personality")

        try:
            resp = await asyncio.wait_for(
                asyncio.to_thread(
                    provider.generate,
                    prompt,
                    model=used_model,
                    system_prompt=configured_system_prompt,
                    ai_name=ai_name,
                    ai_personality=ai_personality,
                ),
                timeout=60,
            )
        except asyncio.TimeoutError:
            console.print("[red]Cloud AI request timed out (60s).[/]")
            return "Cloud AI timeout. Please try again."
        except Exception as e:
            console.print(f"[red]Cloud AI request failed: {e}[/]")
            return f"Cloud AI error: {e}"

        text = _extract_text(resp).strip()
        if not text:
            console.print("[yellow]Cloud AI returned empty response.[/]")
            return "(Empty response from cloud model)"
        console.print(f"[dim]AI reply preview: {text[:120]}[/]")
        return text

    gateway = get_gateway(ai_callback=ai_callback)
    # Attach voice configuration to gateway instance for use by GatewayService.
    setattr(gateway, "voice_enabled", bool(voice))
    setattr(gateway, "users_all", bool(usersall))
    setattr(gateway, "allow_me", bool(me))

    manager = get_channel_manager()
    allowed_users = set()
    if user:
        for u in user:
            if u is None:
                continue
            s = "".join(ch for ch in str(u) if ch.isdigit())
            if s:
                allowed_users.add(s)
    setattr(gateway, "allowed_users", allowed_users)
    setattr(
        gateway,
        "voice_wav_path_fallback",
        _resolve_voice_wav_fallback(manager),
    )
    
    # Check if any channels configured
    if not manager.list_channels():
        console.print("[yellow]Warning: No channels configured.[/]")
        console.print("[dim]Add channels with: enkaliprime channels add <type>[/]")
    
    console.print("[cyan]Starting gateway service...[/]")

    async def run_gateway():
        # Optionally auto-connect WhatsApp before starting listener tasks.
        if whatsapp:
            ch = manager.get_channel("whatsapp")
            if ch is None:
                console.print("[yellow]WhatsApp channel not configured. Run: enkaliprime channels connect whatsapp[/]")
            else:
                try:
                    console.print("[cyan]Connecting to WhatsApp...[/]")
                    await ch.connect()
                except Exception as e:
                    console.print(f"[red]Failed to connect WhatsApp: {e}[/]")

        # Optionally auto-connect Slack before starting listener tasks.
        if slack:
            ch = manager.get_channel("slack")
            if ch is None:
                console.print("[yellow]Slack channel not configured. Run: enkaliprime channels add slack && enkaliprime channels slack-set-tokens ...[/]")
            else:
                try:
                    console.print("[cyan]Connecting to Slack...[/]")
                    await ch.connect()
                except Exception as e:
                    console.print(f"[red]Failed to connect Slack: {e}[/]")

        await gateway.start()
        
        # Keep running
        while gateway.is_running:
            await asyncio.sleep(1)
    
    if daemon:
        # Run in background
        try:
            loop = asyncio.get_event_loop()
            _gateway_task = loop.create_task(run_gateway())
            console.print("[green]✓ Gateway started in background[/]")
            console.print(f"[dim]Stop with: enkaliprime gateway stop[/]")
        except Exception as e:
            console.print(f"[red]Failed to start gateway: {e}[/]")
            raise typer.Exit(1)
    else:
        # Run in foreground with status display
        try:
            console.print("[dim]Gateway running... Press Ctrl+C to stop[/]")
            asyncio.run(run_gateway())
        except KeyboardInterrupt:
            console.print("\n[yellow]Stopping gateway...[/]")
            asyncio.run(gateway.stop())
            console.print("[green]✓ Gateway stopped[/]")


@app.command()
def stop():
    """Stop the gateway service."""
    gateway = get_gateway()
    
    if not gateway.is_running:
        console.print("[yellow]Gateway is not running[/]")
        return
    
    asyncio.run(gateway.stop())
    console.print("[green]✓ Gateway stopped[/]")


@app.command()
def status():
    """Show gateway service status."""
    gateway = get_gateway()
    manager = get_channel_manager()
    
    text = Text()
    
    # Gateway status
    text.append("Gateway Status\n", style="bold cyan")
    text.append("=" * 30 + "\n\n", style="dim")
    
    status = "Running" if gateway.is_running else "Stopped"
    status_color = "green" if gateway.is_running else "red"
    text.append(f"Status: [", style="")
    text.append(status, style=status_color)
    text.append("]\n\n", style="")
    
    # Channels
    channels = manager.list_channels()
    text.append(f"Channels: {len(channels)}\n", style="bold")
    
    for channel in channels:
        conn_status = "Connected" if channel.is_connected else "Disconnected"
        conn_color = "green" if channel.is_connected else "red"
        text.append(f"  • {channel.name} (", style="")
        text.append(conn_status, style=conn_color)
        text.append(f")\n", style="")
    
    text.append("\n", style="")
    
    # Sessions
    sessions_info = gateway.get_session_info()
    text.append(f"Active Sessions: {sessions_info.get('total_sessions', 0)}\n", style="bold")
    
    if sessions_info.get('sessions'):
        for session in sessions_info['sessions'][:5]:
            text.append(f"  • {session['session_id']}\n", style="dim")
            text.append(f"    Messages: {session['message_count']}, Last: {session['last_activity'][:10]}\n", style="dim")
    
    panel = Panel(
        text,
        title="[bold]Gateway Status[/bold]",
        border_style="cyan",
        box=box.ROUNDED
    )
    console.print(panel)


@app.command()
def sessions(
    session_id: Optional[str] = typer.Option(None, "--id", help="Show specific session details"),
    all: bool = typer.Option(False, "--all", "-a", help="Show all sessions")
):
    """Show active gateway sessions."""
    gateway = get_gateway()
    
    if session_id:
        # Show specific session
        info = gateway.get_session_info(session_id)
        if not info:
            console.print(f"[red]Session not found: {session_id}[/]")
            raise typer.Exit(1)
        
        console.print(f"[bold]Session: {session_id}[/bold]")
        console.print_json(data=info)
    else:
        # Show all sessions summary
        info = gateway.get_session_info()
        
        console.print(f"[bold]Total Sessions: {info.get('total_sessions', 0)}[/bold]\n")
        
        if info.get('sessions'):
            from rich.table import Table
            
            table = Table()
            table.add_column("Session ID", style="cyan")
            table.add_column("Channel", style="green")
            table.add_column("User", style="yellow")
            table.add_column("Messages", style="magenta")
            table.add_column("Last Activity", style="blue")
            
            for session in info['sessions']:
                table.add_row(
                    session['session_id'][:30] + "..." if len(session['session_id']) > 30 else session['session_id'],
                    session['channel'],
                    session['user_id'],
                    str(session['message_count']),
                    session['last_activity'][:16]
                )
            
            console.print(table)


@app.command()
def logs(
    follow: bool = typer.Option(False, "--follow", "-f", help="Follow logs in real-time"),
    lines: int = typer.Option(50, "--lines", "-n", help="Number of lines to show")
):
    """Show gateway logs."""
    console.print("[yellow]Note: Logging to stdout. Use system logs for history.[/]")
    
    if follow:
        console.print("[cyan]Following logs... Press Ctrl+C to stop[/]")
        try:
            import time
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            console.print("\n[dim]Stopped.[/]")


@app.command()
def test(
    channel: str = typer.Argument(..., help="Channel name to test"),
    message: str = typer.Option("Hello from EnkaliPrime!", "--message", "-m", help="Test message")
):
    """Send a test message through a channel."""
    manager = get_channel_manager()
    
    channel_obj = manager.get_channel(channel)
    if not channel_obj:
        console.print(f"[red]Channel not found: {channel}[/]")
        raise typer.Exit(1)
    
    if not channel_obj.is_connected:
        console.print(f"[red]Channel not connected: {channel}[/]")
        raise typer.Exit(1)
    
    # Simulate incoming message to test the full flow
    console.print(f"[cyan]Simulating incoming message on {channel}...[/]")
    
    from ..channels.base import ChannelMessage, MessageType
    from datetime import datetime
    import random
    
    test_message = ChannelMessage(
        id=f"test_{random.randint(1000, 9999)}",
        channel=channel,
        sender_id="test_user",
        sender_name="Test User",
        content=message,
        message_type=MessageType.TEXT,
        timestamp=datetime.now()
    )
    
    gateway = get_gateway()
    
    async def test_flow():
        await gateway.handle_message(test_message)
    
    asyncio.run(test_flow())
    
    console.print("[green]✓ Test message processed[/]")
