from enum import Enum, unique


@unique
class BifurcationTypes(str, Enum):
    """Enumeration for bifurcation types."""

    # bifurcations
    SADDLENODE = "saddleNode"
    TRANSCRITICAL = "transcritical"
    HOPF = "hopf"
    # other
    FRONTIER = "frontier"
    INTERNAL_ERROR = "outOfParameters"
    EXTINCT = "extinction"

