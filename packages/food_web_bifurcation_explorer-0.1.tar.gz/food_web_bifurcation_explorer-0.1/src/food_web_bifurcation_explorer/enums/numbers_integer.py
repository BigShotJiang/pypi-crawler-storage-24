from enum import Enum


class NumbersInteger(int, Enum):
    """Enumeration for integer number parameters used in the application."""

    MAX_FIXED_PARAMETERS = 1001
    MAX_NUM_TRACES = 30 # update
    EIGENVALUE_SPECTRUM_MIN = 0
    EIGENVALUE_SPECTRUM_MAX = 2000
    EIGENVALUE_SPECTRUM_STEP = 1