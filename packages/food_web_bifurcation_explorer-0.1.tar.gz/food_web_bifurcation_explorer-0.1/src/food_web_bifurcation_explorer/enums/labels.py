from enum import Enum, unique


@unique
class Labels(str, Enum):
    """Enumeration for frontend element labels."""

    # parameters
    DONOR_CONTROL = "Donor control"
    RECIPIENT_CONTROL = "Recipient control"
    LOTKAVOLTERRA_CONTROL = "Lotka-Volterra control"
    # alias
    DONOR_ALIAS = "<i>s</i><sub>d</sub>"
    RECIPIENT_ALIAS = "<i>s</i><sub>r</sub>"
    LOTKAVOLTERRA_ALIAS = "<i>s</i><sub>l</sub>"
    # strength
    DONOR_CONTROL_STRENGTH = DONOR_CONTROL + " strength " + DONOR_ALIAS
    RECIPIENT_CONTROL_STRENGT = RECIPIENT_CONTROL + " strength " + RECIPIENT_ALIAS
    LOTKAVOLTERRA_CONTROL_STRENGT = LOTKAVOLTERRA_CONTROL + " strength " + LOTKAVOLTERRA_ALIAS
    # equilibria
    ALTERNATIVE_EQUILIBRIA = "Alternative equilibria"
    ALTERNATIVE_BRANCH = "Alternative branch"
    UNSTABLE_EQUILIBRIA = "Unstable equilibria"
    # biomass
    BIOMASS_COMPARTMENT_FIRST = "First biomass compartment"
    BIOMASS_COMPARTMENT_SECOND = "Second biomass compartment"
    BIOMASS_UNIT = "mg/m<sup>2</sup>"
    DRAW_LINES = "Draw lines"
    DRAW_POINTS = "Draw points"
    DRAWING_OPTIONS = "Drawing options"
    EIGENVALUE_SPECTRUM = "Eigenvalue Spectrum"
    EIGENVALUE_SPECTRUM_CENTERED = "Draw centered around 0"
    EIGENVALUE_SPECTRUM_INDEX_ALTERNATIVE = "Eigenvalue spectrum for alternative branch"
    EIGENVALUE_SPECTRUM_INDEX_EMPIRICAL = "Eigenvalue spectrum for empirical branch"
    EMPIRICAL_EQUILIBRIA = "Empirical equilibria"
    EMPIRICAL_BRANCH = "Empirical branch"
    EMPIRICAL_ENVELOPE = "Empirical envelope"
    EQUILIBRIA = "Equilibria"
    EXTINCT = "Extinct"
    FIXED_PARAMETER_TYPE = "Fixed parameter"
    FIXED_PARAMETER_VALUE = "Fixed parameter value [0,1]"
    HOPF_BIFURCATIONS = "Hopf bifurcations"
    INTERNAL_ERROR = "Internal error"
    MAIN_TITLE = "Food-web Dynamics: Bifurcation Explorer"
    NETWORK_SELECTOR = "Network"
    OTHERS = "Others"
    OVER_INFORMATION = "Show over information"
    ZOOM_LEVEL = "Zoom level"
    SADDLENODE_BIFURCATIONS = "Saddle-node bifurcations"
    STABILITY_AREA = "Stability area"
    STABLE_EQUILIBRIA = "Stable equilibria"
    TRANSCRITICAL_BIFURCATIONS = "Transcritical bifurcations"
    ALTERNATIVE_ENVELOPE = "Alternative envelope"

