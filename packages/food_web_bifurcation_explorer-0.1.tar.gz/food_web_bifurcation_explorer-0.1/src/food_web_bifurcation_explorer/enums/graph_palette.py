﻿from enum import Enum, unique


@unique
class GraphPalette(str, Enum):
    """Enumeration for color palette used in graphs."""

    # control wrapper
    DIV_CONTROL = "#f9f9f9"
    # equilibrium areas
    STABLE_AREA = "rgba(0, 0, 255, 0.1)"
    UNSTABLE_AREA = "rgba(255, 0, 0, 0.1)"
    # equilibrium traces
    STABLE = "blue"
    UNSTABLE = "red"
    # bifurcations
    SADDLENODE_EMPIRICAL = "yellow"
    SADDLENODE_ALTERNATIVE = "gold"
    TRANSCRITICAL_EMPIRICAL = "orange"
    TRANSCRITICAL_ALTERNATIVE = "darkorange"
    HOPF_EMPIRICAL = "limegreen"
    HOPF_ALTERNATIVE = "forestgreen"
    # other
    EXTINCT = "black"
    INTERNAL_ERROR = "magenta"
    EIGENVALUE_SPECTRUM_INDEX = "lightgreen"