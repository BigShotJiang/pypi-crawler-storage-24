from enum import Enum, unique


@unique
class DrawingTraces(str, Enum):
    """Enumeration for drawing trace types."""

    # ghost trace (needed to avoid errors when no area is drawn))
    GHOST_TRACE = "ghost trace"
    # envelope traces
    HOPF_ENVELOPE_BACKGROUND = "envelope background"
    # equilibria traces
    STABLE_EQUILIBRIA_AREA = "Stable equilibria area"
    UNSTABLE_EQUILIBRIA_AREA = "Unstable equilibria area"
    # equilibria traces
    STABLE_EQUILIBRIA = "Stable equilibria"
    UNSTABLE_EQUILIBRIA = "Unstable equilibria"
    # bifurcations
    SADDLENODE_EMPIRICAL = "Saddle-node empirical"
    SADDLENODE_ALTERNATIVE = "Saddle-node alternative"
    TRANSCRITICAL_EMPIRICAL = "Transcritical empirical"
    TRANSCRITICAL_ALTERNATIVE = "Transcritical alternative"
    HOPF_ENVELOPE_EMPIRICAL = "Hopf envelope empirical"
    HOPF_ENVELOPE_EMPIRICAL_TOP = "Hopf envelope empirical top"
    HOPF_ENVELOPE_EMPIRICAL_BOT = "Hopf envelope empirical bot"
    HOPF_ENVELOPE_ALTERNATIVE = "Hopf envelope alternative"
    HOPF_ENVELOPE_ALTERNATIVE_TOP = "Hopf envelope alternative top"
    HOPF_ENVELOPE_ALTERNATIVE_BOT = "Hopf envelope alternative bot"
    HOPF_EMPIRICAL = "Hopf empirical"
    HOPF_ALTERNATIVE = "Hopf alternative"
    # other
    EXTINCT = "Extinct"
    INTERNAL_ERROR = "Internal error"
    EIGENVALUE_SPECTRUM_INDEX_EMPIRICAL = "Eigenvalue spectrum index empirical"
    EIGENVALUE_SPECTRUM_INDEX_ALTERNATIVE = "Eigenvalue spectrum index alternative"
