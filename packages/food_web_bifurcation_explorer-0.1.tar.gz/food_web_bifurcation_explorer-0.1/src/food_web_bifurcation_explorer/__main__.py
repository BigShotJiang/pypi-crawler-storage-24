from food_web_bifurcation_explorer import FoodWebBifurcationExplorer


if __name__ == "__main__":
    """Entry point for the command line (python -m food_web_bifurcation_explorer)"""
    FoodWebBifurcationExplorer()