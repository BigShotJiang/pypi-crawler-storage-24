from dash import dcc, html

from food_web_bifurcation_explorer.enums.labels import Labels
from food_web_bifurcation_explorer.enums.numbers_integer import NumbersInteger
from food_web_bifurcation_explorer.frontend.ids import IDs
from food_web_bifurcation_explorer.enums.styles import Styles


# title
def title():
    """
    Returns a Dash HTML label for the eigenvalue spectrum index alternative title.
    """
    return html.Label(
        Labels.EIGENVALUE_SPECTRUM_INDEX_ALTERNATIVE, style=Styles.LABEL
    )


# build
def build():
    """
    Builds and returns a Dash HTML Div containing a number input for the eigenvalue spectrum index alternative.
    """
    # input number box
    return html.Div(
        dcc.Input(
            id=IDs.TEXTFIELD_EIGENVALUE_SPECTRUM_INDEX_ALTERNATIVE,
            type="number",
            min=NumbersInteger.EIGENVALUE_SPECTRUM_MIN,
            max=NumbersInteger.EIGENVALUE_SPECTRUM_MAX,
            step=NumbersInteger.EIGENVALUE_SPECTRUM_STEP,
            style={
                "width": "100%",
                "boxSizing": "border-box",
                "height": "36px",
                "borderRadius": "5px",
                "border": "1px solid #ccc",
                "padding": "0 10px",
            },
            value=0,  # default value
        ),
        style={"flex": "1", "marginRight": "10px"},
    )
