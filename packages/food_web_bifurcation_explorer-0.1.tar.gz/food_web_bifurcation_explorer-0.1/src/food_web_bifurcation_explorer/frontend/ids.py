from enum import Enum, unique


@unique
class IDs(str, Enum):
    """Enumeration for frontend IDs."""

    # control
    DROPDOWN_COMPARTMENT_FIRST = "dropdown-compartment-first"
    DROPDOWN_COMPARTMENT_SECOND = "dropdown-compartment-second"
    DROPDOWN_NETWORK = "dropdown-network"
    DROPDOWN_PARAMETER_TYPE = "parameter-type"
    DROPDOWN_SIZE = "dropdown-size"
    TEXTFIELD_FIXED_PARAMETER_VALUE = "textfield-fixed-parameter-value"
    # eigen values spectrum
    TEXTFIELD_EIGENVALUE_SPECTRUM_INDEX_ALTERNATIVE = "textfield-checkbox-eigenvalue-spectrum-index-alternative-input"
    TEXTFIELD_EIGENVALUE_SPECTRUM_INDEX_EMPIRICAL = "textfield-eigenvalue-spectrum-index-empirical-input"
    # branches
    CHECKBOX_EQUILIBRIA_AREA = "checkbox-equilibria-area"
    CHECKBOX_EQUILIBRIA_OVERINFORMATION = "checkbox-equilibria-overinformation"
    CHECKBOX_EQUILIBRIA_STABLE = "checkbox-equilibria-stable"
    CHECKBOX_EQUILIBRIA_UNSTABLE = "checkbox-equilibria-unstable"
    # bifurcations
    CHECKBOX_BIFURCATIONS_ENVELOPE_ALTERNATIVE = "checkbox-bifurcations-envelope-alternative"
    CHECKBOX_BIFURCATIONS_ENVELOPE_EMPIRICAL = "checkbox-bifurcations-envelope-empirical"
    CHECKBOX_BIFURCATIONS_HOPF_ALTERNATIVE = "checkbox-bifurcations-hopf-alternative"
    CHECKBOX_BIFURCATIONS_HOPF_EMPIRICAL = "checkbox-bifurcations-hopf-empirical"
    CHECKBOX_BIFURCATIONS_SADDLENODE_ALTERNATIVE = "checkbox-bifurcations-saddlenode-alternative"
    CHECKBOX_BIFURCATIONS_SADDLENODE_EMPIRICAL = "checkbox-bifurcations-saddlenode-empirical"
    CHECKBOX_BIFURCATIONS_TRANSCRITICAL_ALTERNATIVE = "checkbox-bifurcations-transcritical-alternative"
    CHECKBOX_BIFURCATIONS_TRANSCRITICAL_EMPIRICAL = "checkbox-bifurcations-transcritical-empirical"
    # others
    CHECKBOX_OTHERS_EIGENVALUE_SPECTRUM_INDEX = "checkbox-others-eigenvalue-spectrum-index"
    CHECKBOX_OTHERS_EXTINCT = "checkbox-others-extinct"
    CHECKBOX_OTHERS_INTERNALERROR = "checkbox-others-internalerror"
    # draw options
    CHECKBOX_DRAW_BRANCH_ALTERNATIVE = "checkbox-draw-branch-alternative"
    CHECKBOX_DRAW_BRANCH_EMPIRICAL = "checkbox-draw-branch-empirical"
    CHECKBOX_DRAW_LINES = "checkbox-draw-lines"
    CHECKBOX_DRAW_POINTS = "checkbox-draw-points"
    # eigen values centering
    CHECKBOX_EIGENVALUE_SPECTRUM_CENTERED_ALTERNATIVE = "eigenvalue-spectrum-centered-alternative"
    CHECKBOX_EIGENVALUE_SPECTRUM_CENTERED_EMPIRICAL = "eigenvalue-spectrum-centered-empirical"
    # graphs
    FIG_BIFURCATION_DIAGRAMM_FIRST = "figure-bifurcation-diagram-first"
    FIG_BIFURCATION_DIAGRAMM_SECOND = "figure-bifurcation-diagram-second"
    FIG_EIGENVALUE_SPECTRUM_ALTERNATIVE = "figure-eigenvalue-spectrum-alternative"
    FIG_EIGENVALUE_SPECTRUM_EMPIRICAL = "figure-eigenvalue-spectrum-empirical"
    FIG_PHASE_PORTRAIT_FIRST = "figure-phase-portrait-first"
    FIG_PHASE_PORTRAIT_SECOND = "figure-phase-portrait-second"
    FIG_TERNARY_GRAPH = "figure-ternary-graph"
    FIG_TIME_SERIES_FIRST = "figure-time-series-first"
    FIG_TIME_SERIES_SECOND = "figure-time-series-second"
    # divs
    DIV_GRAPH_PLOT_01 = "div-graph-plot-01"
    DIV_GRAPH_PLOT_02 = "div-graph-plot-02"
    DIV_GRAPH_PLOT_03 = "div-graph-plot-03"
    DIV_GRAPH_PLOT_04 = "div-graph-plot-04"
    DIV_GRAPH_PLOT_05 = "div-graph-plot-05"
    DIV_GRAPH_PLOT_06 = "div-graph-plot-06"
    DIV_GRAPH_PLOT_07 = "div-graph-plot-07"
    DIV_GRAPH_PLOT_08 = "div-graph-plot-08"
    DIV_GRAPH_TERNARY = "div-graph-ternary"
    DIV_GRAPHS = "div-graphs"
    DIV_RIGH_PANEL = "div-right-panel"
    DIV_SMALL_ROW_01 = "div-small-row-01"
    DIV_SMALL_ROW_02 = "div-small-row-02"
    DIV_SMALL_ROW_03 = "div-small-row-03"
    DIV_SMALL_ROW_04 = "div-small-row-04"
    # other
    ERROR_MESSAGE = "error-message"