﻿from dash import dcc, html

from food_web_bifurcation_explorer.enums.labels import Labels
from food_web_bifurcation_explorer.frontend.ids import IDs
from food_web_bifurcation_explorer.enums.check_box import CheckBox
from food_web_bifurcation_explorer.enums.font import Font
from food_web_bifurcation_explorer.enums.styles import Styles
from food_web_bifurcation_explorer.enums.graph_palette import GraphPalette
from food_web_bifurcation_explorer.enums.symbols import Symbols


# build
def build():
    """Build and return a checkbox component for displaying stable equilibria.

    Returns:
        dcc.Checklist: A Dash checklist component configured for stable equilibria display.
    """
    return dcc.Checklist(
        id=IDs.CHECKBOX_EQUILIBRIA_STABLE,
        options=[
            {
                "label": html.Span(
                    [
                        Labels.STABLE_EQUILIBRIA,
                        html.Span(
                            Symbols.CIRCLE,
                            style={
                                "color": GraphPalette.STABLE,
                                "fontSize": Font.SIZE,
                                "marginLeft": CheckBox.MARGING_LEFT,
                            },
                        ),
                    ]
                ),
                "value": True,
            }
        ],
        value=[True],
        inline=True,
        labelStyle=Styles.CHECKBOXLABEL,
    )
