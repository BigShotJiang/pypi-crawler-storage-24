from dash import Input, Output, callback

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes
from food_web_bifurcation_explorer.frontend.ids import IDs


# callback to update analyzed value
@callback(
    # outputs
    Output(IDs.TEXTFIELD_EIGENVALUE_SPECTRUM_INDEX_EMPIRICAL, "value"),
    # inputs
    Input(IDs.TEXTFIELD_EIGENVALUE_SPECTRUM_INDEX_EMPIRICAL, "value"),
    # we don't need an initial call
    prevent_initial_call=True,
)


def update_eigenvalue_spectrum_index_empirical(eigenvalue_spectrum_index: int):
    """Update the eigenvalue spectrum index for empirical data.

    Args:
        eigenvalue_spectrum_index: The index value to set for the eigenvalue spectrum.

    Returns:
        The eigenvalue spectrum index value.
    """
    # check that we introduced a valid number
    if eigenvalue_spectrum_index is not None:
        # update index
        glob.config.update_eigenvalue_spectrum_index(
            eigenvalue_spectrum_index, BranchTypes.EMPIRICAL
        )
    return eigenvalue_spectrum_index
