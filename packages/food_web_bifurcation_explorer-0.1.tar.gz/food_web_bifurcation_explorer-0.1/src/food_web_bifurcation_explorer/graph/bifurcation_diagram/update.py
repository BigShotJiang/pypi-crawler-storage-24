import plotly.graph_objects as go

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.types.plot_types import PlotTypes
from food_web_bifurcation_explorer.enums.types.bifurcation_types import BifurcationTypes
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes
from food_web_bifurcation_explorer.enums.drawing_traces import DrawingTraces
from food_web_bifurcation_explorer.enums.labels import Labels
from food_web_bifurcation_explorer.enums.numbers_integer import NumbersInteger
from food_web_bifurcation_explorer.enums.types.parameter_types import ParameterTypes
from food_web_bifurcation_explorer.common.exceptions import BifurcationDiagramTypeError
from food_web_bifurcation_explorer.data.bifurcation_data import BifurcationData
from food_web_bifurcation_explorer.data.branch_data import EnvelopeData
from food_web_bifurcation_explorer.data.plot_data import BranchData


def build_over_template(trace: DrawingTraces, show: bool):
    # check if show over template
    if show:
        # return formatted over template
        return (
            trace
            + "<br>"
            + "Parameter "
            + glob.config.dynamic_paramameter_type
            + ": %{x}<br>"
            + "Biomass: %{y} "
            + Labels.BIOMASS_UNIT
            + " <extra></extra>"
        )
    # skip template
    return None


def clear_branch(fig: go.Figure, name: str):
    """
    Clears the branch trace with the specified name in the given figure.

    Args:
        fig (go.Figure): The Plotly figure object.
        name (str): The name of the branch trace to clear.
    """
    fig.update_traces(selector={"name": name}, x=[], y=[])


def clear_branch_traces(fig: go.Figure, branch_type: BranchTypes):
    # stable
    clear_branch(fig, DrawingTraces.STABLE_EQUILIBRIA + "_" + branch_type)
    # unstable
    clear_branch(fig, DrawingTraces.UNSTABLE_EQUILIBRIA + "_" + branch_type)
    # stable (transition)
    clear_branch(fig, DrawingTraces.STABLE_EQUILIBRIA + "_transition_" + branch_type)
    # unstable (transition)
    clear_branch(fig, DrawingTraces.UNSTABLE_EQUILIBRIA + "_transition_" + branch_type)


def draw_branch_data(branch_data: BranchData, fig: go.Figure, compartment_index: int):
    """
    Draws branch data for the specified compartment index in the figure.

    Args:
        branch_data: The branch data object containing equilibrium nodes and x values.
        fig (go.Figure): The Plotly figure object.
        compartment_index (int): The index of the compartment to draw.
    """
    # check if show hoverinfo
    show_hoverinfo = "skip"
    if glob.config.drawing_options.equilibria_over_information:
        show_hoverinfo = "all"

    # get biomass column name
    biomass_column = f"b_{compartment_index + 1}"

    # check if there is data to draw
    if not branch_data.branch_dataframe.empty:
        # get parameter values
        parameter_values = branch_data.branch_dataframe["parameter_values"].tolist()

        # stable
        if glob.config.drawing_options.equilibria_stable:
            fig.update_traces(
                selector={"name": DrawingTraces.STABLE_EQUILIBRIA + "_" + branch_data.branch_type},
                x=parameter_values,
                y=branch_data.stablenodes_dataframe[biomass_column].tolist(),
                hoverinfo=show_hoverinfo,
                hovertemplate=build_over_template(
                    DrawingTraces.STABLE_EQUILIBRIA,
                    glob.config.drawing_options.equilibria_over_information,
                ),
            )
        else:
            clear_branch(fig, DrawingTraces.STABLE_EQUILIBRIA + "_" + branch_data.branch_type)

        # unstable
        if glob.config.drawing_options.equilibria_unstable:
            fig.update_traces(
                selector={"name": DrawingTraces.UNSTABLE_EQUILIBRIA + "_" + branch_data.branch_type},
                x=parameter_values,
                y=branch_data.unstablenodes_dataframe[biomass_column].tolist(),
                hoverinfo=show_hoverinfo,
                hovertemplate=build_over_template(
                    DrawingTraces.UNSTABLE_EQUILIBRIA,
                    glob.config.drawing_options.equilibria_over_information,
                ),
            )
        else:
            clear_branch(fig, DrawingTraces.UNSTABLE_EQUILIBRIA + "_" + branch_data.branch_type)

        # stable (transition)
        if glob.config.drawing_options.equilibria_stable:
            fig.update_traces(
                selector={"name": DrawingTraces.STABLE_EQUILIBRIA + "_transition_" + branch_data.branch_type},
                x=parameter_values,
                y=branch_data.transition_stabletounstablenodes_dataframe[biomass_column].tolist(),
                hoverinfo=show_hoverinfo,
                hovertemplate=build_over_template(
                    DrawingTraces.STABLE_EQUILIBRIA,
                    glob.config.drawing_options.equilibria_over_information,
                ),
            )
        else:
            clear_branch(fig, DrawingTraces.STABLE_EQUILIBRIA + "_transition_" + branch_data.branch_type)

        # unstable (transition)
        if glob.config.drawing_options.equilibria_unstable:
            fig.update_traces(
                selector={"name": DrawingTraces.UNSTABLE_EQUILIBRIA + "_transition_" + branch_data.branch_type},
                x=parameter_values,
                y=branch_data.transition_unstabletostablenodes_dataframe[biomass_column].tolist(),
                hoverinfo=show_hoverinfo,
                hovertemplate=build_over_template(
                    DrawingTraces.UNSTABLE_EQUILIBRIA,
                    glob.config.drawing_options.equilibria_over_information,
                ),
            )
        else:
            clear_branch(fig, DrawingTraces.UNSTABLE_EQUILIBRIA + "_transition_" + branch_data.branch_type)

    else:
        clear_branch_traces(fig, branch_data.branch_type)


def update_bifurcation_diagram(fig: go.Figure, plot_type: PlotTypes):
    """
    Updates the bifurcation diagram in the given figure based on the diagram type.

    Args:
        fig (go.Figure): The Plotly figure object.
        plot_type (PlotTypes): The type of bifurcation diagram to update.

    Returns:
        go.Figure: The updated Plotly figure object.
    """
    # get config.compartment_index
    if plot_type == PlotTypes.FIRST:
        compartment_index = glob.config.compartment_first_index
        compartment_name = glob.config.compartment_first
        redraw_bifurcation_diagram = glob.config.drawing_options.redraw_bifurcation_diagrams_first
    elif plot_type == PlotTypes.SECOND:
        compartment_index = glob.config.compartment_second_index
        compartment_name = glob.config.compartment_second
        redraw_bifurcation_diagram = glob.config.drawing_options.redraw_bifurcation_diagrams_second
    else:
        raise BifurcationDiagramTypeError("invalid bifurcation diagram type")

    # get branches
    empirical_branch = glob.plot_data.branch_datas[glob.config.fixed_parameter_type][BranchTypes.EMPIRICAL]
    alternative_branch = glob.plot_data.branch_datas[glob.config.fixed_parameter_type][BranchTypes.ALTERNATIVE]
    # branches
    if redraw_bifurcation_diagram.branches:
        # first clear both branches
        for branch_type in BranchTypes:
            clear_branch_traces(fig, branch_type)
        # draw empirical branch
        if glob.config.drawing_options.draw_branch_empirical:
            # draw branch data
            draw_branch_data(empirical_branch, fig, compartment_index)
        # draw alternative branch
        if glob.config.drawing_options.draw_branch_alternative:
            # draw branch data
            draw_branch_data(alternative_branch, fig, compartment_index)
        # reset flag
        redraw_bifurcation_diagram.branches = False

    # envelope empirical
    if redraw_bifurcation_diagram.envelope_empirical:
        # clear branches
        clear_branch(fig, DrawingTraces.HOPF_ENVELOPE_EMPIRICAL)
        clear_branch(fig, DrawingTraces.HOPF_ENVELOPE_EMPIRICAL_TOP)
        clear_branch(fig, DrawingTraces.HOPF_ENVELOPE_EMPIRICAL_BOT)
        # check if draw
        if glob.config.drawing_options.bifurcations_envelope_empirical:
            # get evelope empirical data
            envelope_empirical: EnvelopeData = empirical_branch.envelope_data
            # draw traces
            if False and glob.config.compartment_first_index < len(
                envelope_empirical.envelope_line_y
            ):
                fig.update_traces(
                    selector={"name": DrawingTraces.HOPF_ENVELOPE_EMPIRICAL},
                    x=envelope_empirical.envelope_line_x,
                    y=envelope_empirical.envelope_line_y[compartment_index],
                    hovertemplate=build_over_template(
                        DrawingTraces.HOPF_ENVELOPE_EMPIRICAL,
                        glob.config.drawing_options.equilibria_over_information,
                    ),
                )
            # draw traces
            if glob.config.compartment_first_index < len(envelope_empirical.envelope_top):
                fig.update_traces(
                    selector={"name": DrawingTraces.HOPF_ENVELOPE_EMPIRICAL_TOP},
                    x=envelope_empirical.x_values,
                    y=envelope_empirical.envelope_top[compartment_index],
                    hovertemplate=build_over_template(
                        DrawingTraces.HOPF_ENVELOPE_EMPIRICAL_TOP,
                        glob.config.drawing_options.equilibria_over_information,
                    ),
                )
            # draw traces
            if glob.config.compartment_first_index < len(envelope_empirical.envelope_bot):
                fig.update_traces(
                    selector={"name": DrawingTraces.HOPF_ENVELOPE_EMPIRICAL_BOT},
                    x=envelope_empirical.x_values,
                    y=envelope_empirical.envelope_bot[compartment_index],
                    hovertemplate=build_over_template(
                        DrawingTraces.HOPF_ENVELOPE_EMPIRICAL_BOT,
                        glob.config.drawing_options.equilibria_over_information,
                    ),
                )
    # bifurcation dataframes
    empirical_bifurcations = empirical_branch.bifurcations_dataframe
    alternative_bifurcations = alternative_branch.bifurcations_dataframe
    # get biomass column name
    biomass_column = f"b_{compartment_index + 1}"
    # saddle node empirical
    if redraw_bifurcation_diagram.saddlenode_empirical:
        # clear traces
        for index in range(0, NumbersInteger.MAX_NUM_TRACES):
            clear_branch(fig, f"{DrawingTraces.SADDLENODE_EMPIRICAL}_{index}")
            # check if draw
            if glob.config.drawing_options.bifurcations_saddlenode_empirical:
                # get all rows with the given index
                bifurcation_rows = empirical_bifurcations[empirical_bifurcations['index'] == index]
                bifurcation_rows = empirical_bifurcations[empirical_bifurcations['type'] == BifurcationTypes.SADDLENODE]
                if len(bifurcation_rows) > 0:
                    fig.update_traces(
                        selector={"name": f"{DrawingTraces.SADDLENODE_EMPIRICAL}_{index}"},
                        x=bifurcation_rows["parameter_values"].tolist(),
                        y=bifurcation_rows[biomass_column].tolist(),
                        hovertemplate=build_over_template(DrawingTraces.SADDLENODE_EMPIRICAL, True),
                    )
        # reset flag
        redraw_bifurcation_diagram.saddlenode_empirical = False
    # saddle node alternative
    if redraw_bifurcation_diagram.saddlenode_alternative:
        # clear traces
        for index in range(0, NumbersInteger.MAX_NUM_TRACES):
            clear_branch(fig, f"{DrawingTraces.SADDLENODE_ALTERNATIVE}_{index}")
            # check if draw
            if glob.config.drawing_options.bifurcations_saddlenode_alternative:
                # get all rows with the given index
                bifurcation_rows = alternative_bifurcations[alternative_bifurcations['index'] == index]
                bifurcation_rows = alternative_bifurcations[alternative_bifurcations['type'] == BifurcationTypes.SADDLENODE]
                if len(bifurcation_rows) > 0:
                    fig.update_traces(
                        selector={"name": f"{DrawingTraces.SADDLENODE_ALTERNATIVE}_{index}"},
                        x=bifurcation_rows["parameter_values"].tolist(),
                        y=bifurcation_rows[biomass_column].tolist(),
                        hovertemplate=build_over_template(DrawingTraces.SADDLENODE_ALTERNATIVE, True),
                    )
        # reset flag
        redraw_bifurcation_diagram.saddlenode_alternative = False
    # transcritical empirical
    if redraw_bifurcation_diagram.transcritical_empirical:
        # clear traces
        for index in range(0, NumbersInteger.MAX_NUM_TRACES):
            clear_branch(fig, f"{DrawingTraces.TRANSCRITICAL_EMPIRICAL}_{index}")
            # check if draw
            if glob.config.drawing_options.bifurcations_saddlenode_empirical:
                # get all rows with the given index
                bifurcation_rows = empirical_bifurcations[empirical_bifurcations['index'] == index]
                bifurcation_rows = empirical_bifurcations[empirical_bifurcations['type'] == BifurcationTypes.TRANSCRITICAL]
                if len(bifurcation_rows) > 0:
                    fig.update_traces(
                        selector={"name": f"{DrawingTraces.TRANSCRITICAL_EMPIRICAL}_{index}"},
                        x=bifurcation_rows["parameter_values"].tolist(),
                        y=bifurcation_rows[biomass_column].tolist(),
                        hovertemplate=build_over_template(DrawingTraces.TRANSCRITICAL_EMPIRICAL, True),
                    )
        # reset flag
        redraw_bifurcation_diagram.transcritical_empirical = False
    # transcritical alternative
    if redraw_bifurcation_diagram.transcritical_alternative:
        # clear traces
        for index in range(0, NumbersInteger.MAX_NUM_TRACES):
            clear_branch(fig, f"{DrawingTraces.TRANSCRITICAL_ALTERNATIVE}_{index}")
            # check if draw
            if glob.config.drawing_options.bifurcations_saddlenode_alternative:
                # get all rows with the given index
                bifurcation_rows = alternative_bifurcations[alternative_bifurcations['index'] == index]
                bifurcation_rows = alternative_bifurcations[alternative_bifurcations['type'] == BifurcationTypes.TRANSCRITICAL]
                if len(bifurcation_rows) > 0:
                    fig.update_traces(
                        selector={"name": f"{DrawingTraces.TRANSCRITICAL_ALTERNATIVE}_{index}"},
                        x=bifurcation_rows["parameter_values"].tolist(),
                        y=bifurcation_rows[biomass_column].tolist(),
                        hovertemplate=build_over_template(DrawingTraces.TRANSCRITICAL_ALTERNATIVE, True),
                    )
        # reset flag
        redraw_bifurcation_diagram.transcritical_alternative = False
    # hopf empirical
    if redraw_bifurcation_diagram.hopf_empirical:
        # clear traces
        for index in range(0, NumbersInteger.MAX_NUM_TRACES):
            clear_branch(fig, f"{DrawingTraces.HOPF_EMPIRICAL}_{index}")
            # check if draw
            if glob.config.drawing_options.bifurcations_saddlenode_empirical:
                # get all rows with the given index
                bifurcation_rows = empirical_bifurcations[empirical_bifurcations['index'] == index]
                bifurcation_rows = empirical_bifurcations[empirical_bifurcations['type'] == BifurcationTypes.HOPF]
                if len(bifurcation_rows) > 0:
                    fig.update_traces(
                        selector={"name": f"{DrawingTraces.HOPF_EMPIRICAL}_{index}"},
                        x=bifurcation_rows["parameter_values"].tolist(),
                        y=bifurcation_rows[biomass_column].tolist(),
                        hovertemplate=build_over_template(DrawingTraces.HOPF_EMPIRICAL, True),
                    )
        # reset flag
        redraw_bifurcation_diagram.hopf_empirical = False
    # hopf alternative
    if redraw_bifurcation_diagram.hopf_alternative:
        # clear traces
        for index in range(0, NumbersInteger.MAX_NUM_TRACES):
            clear_branch(fig, f"{DrawingTraces.HOPF_ALTERNATIVE}_{index}")
            # check if draw
            if glob.config.drawing_options.bifurcations_saddlenode_alternative:
                # get all rows with the given index
                bifurcation_rows = alternative_bifurcations[alternative_bifurcations['index'] == index]
                bifurcation_rows = alternative_bifurcations[alternative_bifurcations['type'] == BifurcationTypes.HOPF]
                if len(bifurcation_rows) > 0:
                    fig.update_traces(
                        selector={"name": f"{DrawingTraces.HOPF_ALTERNATIVE}_{index}"},
                        x=bifurcation_rows["parameter_values"].tolist(),
                        y=bifurcation_rows[biomass_column].tolist(),
                        hovertemplate=build_over_template(DrawingTraces.HOPF_ALTERNATIVE, True),
                    )
        # reset flag
        redraw_bifurcation_diagram.hopf_alternative = False
    # extinct
    if redraw_bifurcation_diagram.extinct:
        # clear traces
        for index in range(0, NumbersInteger.MAX_NUM_TRACES):
            clear_branch(fig, f"{DrawingTraces.EXTINCT}_{index}")
            # check if draw
            if glob.config.drawing_options.bifurcations_saddlenode_empirical:
                # get all rows with the given index
                bifurcation_rows = alternative_bifurcations[alternative_bifurcations['index'] == index]
                bifurcation_rows = alternative_bifurcations[alternative_bifurcations['type'] == BifurcationTypes.EXTINCT]
                if len(bifurcation_rows) > 0:
                    fig.update_traces(
                        selector={"name": f"{DrawingTraces.EXTINCT}_{index}"},
                        x=bifurcation_rows["parameter_values"].tolist(),
                        y=bifurcation_rows[biomass_column].tolist(),
                        hovertemplate=build_over_template(DrawingTraces.EXTINCT, True),
                    )
        # reset flag
        redraw_bifurcation_diagram.extinct = False
    # internal_error
    if redraw_bifurcation_diagram.internal_error:
        # clear traces
        for index in range(0, NumbersInteger.MAX_NUM_TRACES):
            clear_branch(fig, f"{DrawingTraces.INTERNAL_ERROR}_{index}")
            # check if draw
            if glob.config.drawing_options.bifurcations_saddlenode_empirical:
                # get all rows with the given index
                bifurcation_rows = alternative_bifurcations[alternative_bifurcations['index'] == index]
                bifurcation_rows = alternative_bifurcations[alternative_bifurcations['type'] == BifurcationTypes.INTERNAL_ERROR]
                if len(bifurcation_rows) > 0:
                    fig.update_traces(
                        selector={"name": f"{DrawingTraces.INTERNAL_ERROR}_{index}"},
                        x=bifurcation_rows["parameter_values"].tolist(),
                        y=bifurcation_rows[biomass_column].tolist(),
                        hovertemplate=build_over_template(DrawingTraces.INTERNAL_ERROR, True),
                    )
        # reset flag
        redraw_bifurcation_diagram.internal_error = False
    # eigenvalue spectrum index empirical
    if redraw_bifurcation_diagram.eigenvalue_spectrum_index:
        # clear traces
        clear_branch(fig, DrawingTraces.EIGENVALUE_SPECTRUM_INDEX_EMPIRICAL)
        clear_branch(fig, DrawingTraces.EIGENVALUE_SPECTRUM_INDEX_ALTERNATIVE)
        # update
        if glob.config.drawing_options.others_eigenvalue_spectrum_index and (
            plot_type == PlotTypes.FIRST
        ):
            # get empirical branch
            empirical_branch = glob.plot_data.branch_datas[glob.config.fixed_parameter_type][
                BranchTypes.EMPIRICAL
            ]
            fig.update_traces(
                selector={"name": DrawingTraces.EIGENVALUE_SPECTRUM_INDEX_EMPIRICAL},
                x=empirical_branch.get_eigenvalue_spectrum_x(),
                y=empirical_branch.get_eigenvalue_spectrum_y(),
                hovertemplate=build_over_template(
                    DrawingTraces.EIGENVALUE_SPECTRUM_INDEX_EMPIRICAL, True
                ),
            )
            # alternative
            alternative_branch = glob.plot_data.branch_datas[glob.config.fixed_parameter_type][
                BranchTypes.ALTERNATIVE
            ]
            fig.update_traces(
                selector={"name": DrawingTraces.EIGENVALUE_SPECTRUM_INDEX_ALTERNATIVE},
                x=alternative_branch.get_eigenvalue_spectrum_x(),
                y=alternative_branch.get_eigenvalue_spectrum_y(),
                hovertemplate=build_over_template(
                    DrawingTraces.EIGENVALUE_SPECTRUM_INDEX_ALTERNATIVE, True
                ),
            )
        # reset flag
        redraw_bifurcation_diagram.eigenvalue_spectrum_index = False
    # get x axis title
    if glob.config.dynamic_paramameter_type == ParameterTypes.DONOR:
        xaxis_title = Labels.DONOR_CONTROL_STRENGTH
    elif glob.config.dynamic_paramameter_type == ParameterTypes.RECIPIENT:
        xaxis_title = Labels.RECIPIENT_CONTROL_STRENGT
    elif glob.config.dynamic_paramameter_type == ParameterTypes.LOTKAVOLTERRA:
        xaxis_title = Labels.LOTKAVOLTERRA_CONTROL_STRENGT
    else:
        raise ValueError("Unknown fixed parameter type: " + glob.config.dynamic_paramameter_type)
    # update layout
    fig.update_layout(
        title="Evolution of biomass compartment '"
        + str(compartment_index + 1)
        + "' ("
        + compartment_name
        + ") for fixed "
        + glob.config.fixed_parameter_type
        + "="
        + glob.config.fixed_parameter_value_str,
        xaxis_title=xaxis_title,
        yaxis_title=compartment_name + " biomass (" + Labels.BIOMASS_UNIT + ")",
    )
    return fig
