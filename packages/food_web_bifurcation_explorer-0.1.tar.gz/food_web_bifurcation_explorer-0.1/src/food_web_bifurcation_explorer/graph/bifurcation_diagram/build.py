"""Build bifurcation diagram plots using Plotly."""

import plotly.graph_objects as go

from food_web_bifurcation_explorer.enums.types.plot_types import PlotTypes
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes
from food_web_bifurcation_explorer.enums.drawing_traces import DrawingTraces
from food_web_bifurcation_explorer.enums.graph_palette import GraphPalette
from food_web_bifurcation_explorer.enums.symbols import Symbols
from food_web_bifurcation_explorer.enums.numbers_integer import NumbersInteger
from food_web_bifurcation_explorer.common import glob


def build_bifurcation_diagram(plot_type: PlotTypes):
    # declare line width
    line_width = 4
    marker_width = 15
    # declare general figure
    fig = go.Figure()
    # iterate over branch datas
    for branch_type in BranchTypes:
        # stable
        fig.add_trace(
            go.Scattergl(
                name=DrawingTraces.STABLE_EQUILIBRIA + "_" + branch_type,
                x=[],
                y=[],
                mode="lines",
                line={"color": GraphPalette.STABLE, "width": line_width},
                marker={"size": marker_width},
                showlegend=False,
            )
        )
        # unstable
        fig.add_trace(
            go.Scattergl(
                name=DrawingTraces.UNSTABLE_EQUILIBRIA + "_" + branch_type,
                x=[],
                y=[],
                mode="lines",
                line={"color": GraphPalette.UNSTABLE, "width": line_width},
                marker={"size": marker_width},
                showlegend=False,
            )
        )
        # stable (transition)
        fig.add_trace(
            go.Scattergl(
                name=DrawingTraces.STABLE_EQUILIBRIA + "_transition_" + branch_type,
                x=[],
                y=[],
                mode="lines",
                line={"color": GraphPalette.STABLE, "width": line_width},
                marker={"size": marker_width},
                showlegend=False,
            )
        )
        # unstable (transition)
        fig.add_trace(
            go.Scattergl(
                name=DrawingTraces.UNSTABLE_EQUILIBRIA + "_transition_" + branch_type,
                x=[],
                y=[],
                mode="lines",
                line={"color": GraphPalette.UNSTABLE, "width": line_width},
                marker={"size": marker_width},
                showlegend=False,
            )
        )
        # envelope empirical
        fig.add_trace(
            go.Scattergl(
                name=DrawingTraces.HOPF_ENVELOPE_EMPIRICAL,
                x=[],
                y=[],
                mode="lines",
                line={"color": GraphPalette.HOPF_EMPIRICAL, "width": 1},
                marker={"size": marker_width},
                showlegend=False,
            )
        )
        # envelope empirical top
        fig.add_trace(
            go.Scattergl(
                name=DrawingTraces.HOPF_ENVELOPE_EMPIRICAL_TOP,
                x=[],
                y=[],
                mode="lines",
                line={"color": GraphPalette.HOPF_EMPIRICAL, "width": 1},
                marker={"size": marker_width},
                showlegend=False,
            )
        )
        # envelope empirical bot
        fig.add_trace(
            go.Scattergl(
                name=DrawingTraces.HOPF_ENVELOPE_EMPIRICAL_BOT,
                x=[],
                y=[],
                mode="lines",
                line={"color": GraphPalette.HOPF_EMPIRICAL, "width": 1},
                marker={"size": marker_width},
                showlegend=False,
            )
        )
        # envelope alternative
        fig.add_trace(
            go.Scattergl(
                name=DrawingTraces.HOPF_ENVELOPE_ALTERNATIVE,
                x=[],
                y=[],
                mode="lines",
                line={"color": GraphPalette.HOPF_ALTERNATIVE, "width": 1},
                marker={"size": marker_width},
                showlegend=False,
            )
        )
        # envelope alternative top
        fig.add_trace(
            go.Scattergl(
                name=DrawingTraces.HOPF_ENVELOPE_ALTERNATIVE_TOP,
                x=[],
                y=[],
                mode="lines",
                line={"color": GraphPalette.HOPF_ALTERNATIVE, "width": line_width},
                marker={"size": marker_width},
                showlegend=False,
            )
        )
        # envelope alternative bot
        fig.add_trace(
            go.Scattergl(
                name=DrawingTraces.HOPF_ENVELOPE_ALTERNATIVE_TOP,
                x=[],
                y=[],
                mode="lines",
                line={"color": GraphPalette.HOPF_ALTERNATIVE, "width": line_width},
                marker={"size": marker_width},
                showlegend=False,
            )
        )
    # extinct
    for index in range(0, NumbersInteger.MAX_NUM_TRACES):
        fig.add_trace(
            go.Scatter(  # here we need to use Scatter instead Scattergl due text labels
                name=f"{DrawingTraces.EXTINCT}_{index}",
                x=[],
                y=[],
                text=[],
                mode="markers+text",
                line={"color": GraphPalette.EXTINCT, "width": line_width},
                marker={"symbol": Symbols.CROSS, "size": marker_width},
                textposition="middle right",
                showlegend=False,
            )
        )
    # saddle node bifurcation
    for index in range(0, NumbersInteger.MAX_NUM_TRACES):
        fig.add_trace(
            go.Scattergl(
                name=f"{DrawingTraces.SADDLENODE_EMPIRICAL}_{index}",
                x=[],
                y=[],
                mode="markers",
                line={"color": GraphPalette.SADDLENODE_EMPIRICAL, "width": line_width},
                marker={"size": marker_width},
                showlegend=False,
            )
        )
    for index in range(0, NumbersInteger.MAX_NUM_TRACES):
        fig.add_trace(
            go.Scattergl(
                name=f"{DrawingTraces.SADDLENODE_ALTERNATIVE}_{index}",
                x=[],
                y=[],
                mode="markers",
                line={"color": GraphPalette.SADDLENODE_ALTERNATIVE, "width": line_width},
                marker={"size": marker_width},
                showlegend=False,
            )
        )
    # transcritical bifurcation
    for index in range(0, NumbersInteger.MAX_NUM_TRACES):
        fig.add_trace(
            go.Scattergl(
                name=f"{DrawingTraces.TRANSCRITICAL_EMPIRICAL}_{index}",
                x=[],
                y=[],
                mode="markers",
                line={"color": GraphPalette.TRANSCRITICAL_EMPIRICAL, "width": line_width},
                marker={"size": marker_width},
                showlegend=False,
            )
        )
    for index in range(0, NumbersInteger.MAX_NUM_TRACES):
        fig.add_trace(
            go.Scattergl(
                name=f"{DrawingTraces.TRANSCRITICAL_ALTERNATIVE}_{index}",
                x=[],
                y=[],
                mode="markers",
                line={"color": GraphPalette.TRANSCRITICAL_ALTERNATIVE, "width": line_width},
                marker={"size": marker_width},
                showlegend=False,
            )
        )
    # hopf bifurcation
    for index in range(0, NumbersInteger.MAX_NUM_TRACES):
        fig.add_trace(
            go.Scattergl(
                name=f"{DrawingTraces.HOPF_EMPIRICAL}_{index}",
                x=[],
                y=[],
                mode="markers",
                line={"color": GraphPalette.HOPF_EMPIRICAL, "width": line_width},
                marker={"size": marker_width},
                showlegend=False,
            )
        )
    for index in range(0, NumbersInteger.MAX_NUM_TRACES):
        fig.add_trace(
            go.Scattergl(
                name=f"{DrawingTraces.HOPF_ALTERNATIVE}_{index}",
                x=[],
                y=[],
                mode="markers",
                line={"color": GraphPalette.HOPF_ALTERNATIVE, "width": line_width},
                marker={"size": marker_width},
                showlegend=False,
            )
        )
    # internal_error
    for index in range(0, NumbersInteger.MAX_NUM_TRACES):
        fig.add_trace(
            go.Scattergl(
                name=f"{DrawingTraces.INTERNAL_ERROR}_{index}",
                x=[],
                y=[],
                mode="markers",
                line={"color": GraphPalette.INTERNAL_ERROR, "width": line_width},
                marker={"symbol": Symbols.CROSS, "size": marker_width},
                showlegend=False,
            )
        )
    # eigenvalue spectrum index empirical
    fig.add_trace(
        go.Scattergl(
            name=DrawingTraces.EIGENVALUE_SPECTRUM_INDEX_EMPIRICAL,
            x=[],
            y=[],
            mode="markers",
            line={"color": GraphPalette.EIGENVALUE_SPECTRUM_INDEX, "width": line_width},
            marker={"symbol": Symbols.DIAMOND_PLOTLY, "size": marker_width},
            showlegend=False,
        )
    )
    # eigenvalue spectrum index alternative
    fig.add_trace(
        go.Scattergl(
            name=DrawingTraces.EIGENVALUE_SPECTRUM_INDEX_ALTERNATIVE,
            x=[],
            y=[],
            mode="markers",
            line={"color": GraphPalette.EIGENVALUE_SPECTRUM_INDEX, "width": line_width},
            marker={"symbol": Symbols.DIAMOND_PLOTLY, "size": marker_width},
            showlegend=False,
        )
    )
    # draw extinct line
    fig.add_hline(
        y=0,
        line_dash="dot",
        line_color="black",
        annotation_text="Extinct",
        annotation_position="bottom left",
    )
    # update layout
    fig.update_layout(
        margin={"l": 0, "r": 0, "t": 50, "b": 0},
        showlegend=True,
        uirevision="bifurcation_diagram" + plot_type,
        # set sizes
        width=glob.config.resolution * 2,
        height=glob.config.resolution,
    )
    # force redraw bifurcation diagrams
    glob.config.drawing_options.redraw_bifurcation_diagrams_first.redraw_all()
    glob.config.drawing_options.redraw_bifurcation_diagrams_second.redraw_all()
    return fig
