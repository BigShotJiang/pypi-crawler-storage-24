import plotly.graph_objects as go
import copy

from food_web_bifurcation_explorer.data.ternary_data import BranchTypes
from food_web_bifurcation_explorer.enums.types.bifurcation_types import BifurcationTypes
from food_web_bifurcation_explorer.enums.drawing_traces import DrawingTraces
from food_web_bifurcation_explorer.common import glob


# update traces
def update_traces():
    # make a copy of ternary index for removing traces
    glob.figures.ternary_traces_remove = copy.deepcopy(glob.figures.ternary_traces_index)
    # clear all data
    for name in glob.figures.ternary_traces_index:
        glob.figures.ternary.data = tuple(trace for trace in glob.figures.ternary.data if trace.name != name)
    # reset ternary index
    glob.figures.ternary_traces_index = {}
    # declare trace index
    trace_index: int = 0
    # add ghost trace
    glob.figures.ternary_traces_index[DrawingTraces.GHOST_TRACE] = trace_index
    trace_index += 1
    # add trace for stable area
    glob.figures.ternary.add_trace(go.Scatterternary(a=[], b=[], c=[]))
    # save name in ternary index
    glob.figures.ternary_traces_index[DrawingTraces.STABLE_EQUILIBRIA_AREA] = trace_index
    trace_index += 1
    # add trace for unstable area
    glob.figures.ternary.add_trace(go.Scatterternary(a=[], b=[], c=[]))
    # save name in ternary index
    glob.figures.ternary_traces_index[DrawingTraces.UNSTABLE_EQUILIBRIA_AREA] = trace_index
    trace_index += 1
    # add trace for stable line
    glob.figures.ternary.add_trace(go.Scatterternary(a=[], b=[], c=[]))
    # save name in ternary index
    glob.figures.ternary_traces_index[DrawingTraces.STABLE_EQUILIBRIA] = trace_index
    trace_index += 1
    # add trace for unstable line
    glob.figures.ternary.add_trace(go.Scatterternary(a=[], b=[], c=[]))
    # save name in ternary index
    glob.figures.ternary_traces_index[DrawingTraces.UNSTABLE_EQUILIBRIA] = trace_index
    trace_index += 1
    # add traces for extinct
    for index in glob.plot_data.ternary_data.get_current_indexes(BranchTypes.ALTERNATIVE, BifurcationTypes.EXTINCT):
        glob.figures.ternary.add_trace(go.Scatterternary(a=[], b=[], c=[]))
        # save name in ternary index
        glob.figures.ternary_traces_index[f"{DrawingTraces.EXTINCT}_{index}"] = trace_index
        trace_index += 1
    # saddle nodes
    for index in glob.plot_data.ternary_data.get_current_indexes(BranchTypes.EMPIRICAL, BifurcationTypes.SADDLENODE):
        glob.figures.ternary.add_trace(go.Scatterternary(a=[], b=[], c=[]))
        # save name in ternary index
        glob.figures.ternary_traces_index[f"{DrawingTraces.SADDLENODE_EMPIRICAL}_{index}"] = trace_index
        trace_index += 1
    for index in glob.plot_data.ternary_data.get_current_indexes(BranchTypes.ALTERNATIVE, BifurcationTypes.SADDLENODE):
        glob.figures.ternary.add_trace(go.Scatterternary(a=[], b=[], c=[]))
        # save name in ternary index
        glob.figures.ternary_traces_index[f"{DrawingTraces.SADDLENODE_ALTERNATIVE}_{index}"] = trace_index
        trace_index += 1
    # transcritical
    for index in glob.plot_data.ternary_data.get_current_indexes(BranchTypes.EMPIRICAL, BifurcationTypes.TRANSCRITICAL):
        glob.figures.ternary.add_trace(go.Scatterternary(a=[], b=[], c=[]))
        # save name in ternary index
        glob.figures.ternary_traces_index[f"{DrawingTraces.TRANSCRITICAL_EMPIRICAL}_{index}"] = trace_index
        trace_index += 1
    for index in glob.plot_data.ternary_data.get_current_indexes(BranchTypes.ALTERNATIVE, BifurcationTypes.TRANSCRITICAL):
        glob.figures.ternary.add_trace(go.Scatterternary(a=[], b=[], c=[]))
        # save name in ternary index
        glob.figures.ternary_traces_index[f"{DrawingTraces.TRANSCRITICAL_ALTERNATIVE}_{index}"] = trace_index
        trace_index += 1
    # hopf
    for index in glob.plot_data.ternary_data.get_current_indexes(BranchTypes.EMPIRICAL, BifurcationTypes.HOPF):
        glob.figures.ternary.add_trace(go.Scatterternary(a=[], b=[], c=[]))
        # save name in ternary index
        glob.figures.ternary_traces_index[f"{DrawingTraces.HOPF_EMPIRICAL}_{index}"] = trace_index
        trace_index += 1
    for index in glob.plot_data.ternary_data.get_current_indexes(BranchTypes.ALTERNATIVE, BifurcationTypes.HOPF):
        glob.figures.ternary.add_trace(go.Scatterternary(a=[], b=[], c=[]))
        # save name in ternary index
        glob.figures.ternary_traces_index[f"{DrawingTraces.HOPF_ALTERNATIVE}_{index}"] = trace_index
        trace_index += 1
    # internal_error
    for index in glob.plot_data.ternary_data.get_current_indexes(BranchTypes.ALTERNATIVE, BifurcationTypes.INTERNAL_ERROR):
        glob.figures.ternary.add_trace(go.Scatterternary(a=[], b=[], c=[]))
        # save name in ternary index
        glob.figures.ternary_traces_index[f"{DrawingTraces.INTERNAL_ERROR}_{index}"] = trace_index
        trace_index += 1
    # force redraw ternary
    glob.config.drawing_options.redraw_ternary.redraw_all()
