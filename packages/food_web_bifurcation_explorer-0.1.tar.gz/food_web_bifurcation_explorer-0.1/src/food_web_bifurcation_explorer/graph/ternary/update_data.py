import uuid

from dash import Patch

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.data.ternary_data import TernaryData
from food_web_bifurcation_explorer.data.ternary_line import TernaryLine
from food_web_bifurcation_explorer.enums.drawing_traces import DrawingTraces
from food_web_bifurcation_explorer.enums.graph_palette import GraphPalette
from food_web_bifurcation_explorer.enums.labels import Labels
from food_web_bifurcation_explorer.enums.numbers_integer import NumbersInteger
from food_web_bifurcation_explorer.enums.types.area_types import AreaTypes
from food_web_bifurcation_explorer.enums.types.bifurcation_types import BifurcationTypes
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes
from food_web_bifurcation_explorer.enums.types.parameter_types import ParameterTypes


# add scatter data
def add_scatter_data(
    patched_figure,
    index,
    no_empty_data: bool,
    color: GraphPalette,
    drawing_mode,
    hover_template: str,
    show_overtemplate: bool,
    datas: list[list[float]],
):
    trace_index = glob.figures.ternary_traces_index[index]
    # check if add empty data
    if no_empty_data:
        # data
        patched_figure["data"][trace_index]["a"] = datas[2]
        patched_figure["data"][trace_index]["b"] = datas[0]
        patched_figure["data"][trace_index]["c"] = datas[1]
        # parameters
        patched_figure["data"][trace_index]["visible"] = True
        patched_figure["data"][trace_index]["showlegend"] = False
        patched_figure["data"][trace_index]["type"] = "scatterternary"
        patched_figure["data"][trace_index]["mode"] = drawing_mode
        # marker
        patched_figure["data"][trace_index]["marker"] = {"size": 6, "color": color, "opacity": 1}
        # hover template
        if show_overtemplate:
            patched_figure["data"][trace_index]["hovertemplate"] = (
                hover_template
                + "<br>"
                + Labels.DONOR_CONTROL + ": %{b:.2f}<br>"
                + Labels.RECIPIENT_CONTROL + ": %{c:.2f}<br>"
                + Labels.LOTKAVOLTERRA_CONTROL + ": %{a:.2f}<br>"
                + "<extra></extra>"
            )
        else:
            patched_figure["data"][trace_index]["hoverinfo"] = "skip"
            patched_figure["data"][trace_index]["hovertemplate"] = None
    else:
        # data
        patched_figure["data"][trace_index]["a"] = []
        patched_figure["data"][trace_index]["b"] = []
        patched_figure["data"][trace_index]["c"] = []
        # hide
        patched_figure["data"][trace_index]["visible"] = False
    return patched_figure


# add scatter area
def add_scatter_area(
    patched_figure, index, no_empty_data: bool, color: GraphPalette, area_type: AreaTypes
):
    trace_index = glob.figures.ternary_traces_index[index]
    # check if add empty data
    if no_empty_data:
        # data
        sd, sr, sl = glob.plot_data.ternary_data.shape_data.get_perimeter_coordinates(area_type)
        patched_figure["data"][trace_index]["a"] = sl
        patched_figure["data"][trace_index]["b"] = sd
        patched_figure["data"][trace_index]["c"] = sr
        # parameters
        patched_figure["data"][trace_index]["visible"] = True
        patched_figure["data"][trace_index]["showlegend"] = False
        patched_figure["data"][trace_index]["type"] = "scatterternary"
        patched_figure["data"][trace_index]["mode"] = "lines"
        patched_figure["data"][trace_index]["fill"] = "toself"
        patched_figure["data"][trace_index]["fillcolor"] = color
        # marker
        patched_figure["data"][trace_index]["line"] = {"width": 2, "color": color, "opacity": 1.0}
    else:
        # data
        patched_figure["data"][trace_index]["a"] = []
        patched_figure["data"][trace_index]["b"] = []
        patched_figure["data"][trace_index]["c"] = []
        # hide
        patched_figure["data"][trace_index]["visible"] = False
    return patched_figure


# clear previous traces
def clear_previous_traces(patched_figure):
    for name in glob.figures.ternary_traces_remove.keys():
        # get index
        index = glob.figures.ternary_traces_remove[name]
        # reset all valoues
        patched_figure["data"][index]["a"] = []
        patched_figure["data"][index]["b"] = []
        patched_figure["data"][index]["c"] = []
        patched_figure["data"][index]["visible"] = False
        # force reset trace giving a new uuid
        patched_figure["data"][index]["uid"] = str(uuid.uuid4())
    # reset ternary index remove
    glob.figures.ternary_traces_remove = {}
    return patched_figure


# update ternary data
def update_ternary_data():
    # declare patch
    patched_figure = Patch()
    # first update layout
    patched_figure["layout"]["width"] = glob.config.resolution * 2
    patched_figure["layout"]["height"] = glob.config.resolution * 2
    # check if we have to clear previous traces
    if glob.figures.ternary_traces_remove:
        patched_figure = clear_previous_traces(patched_figure)
    # declare drawing mode
    if glob.config.drawing_options.draw_lines and glob.config.drawing_options.draw_points:
        drawing_mode = "lines+markers"
    elif glob.config.drawing_options.draw_lines:
        drawing_mode = "lines"
    elif glob.config.drawing_options.draw_points:
        drawing_mode = "markers"
    else:
        drawing_mode = "none"
    # stable equilibria area
    patched_figure = add_scatter_area(
        patched_figure,
        DrawingTraces.STABLE_EQUILIBRIA_AREA,
        glob.config.drawing_options.equilibria_area,
        GraphPalette.STABLE_AREA,
        AreaTypes.STABLE,
    )
    # unstable equilibria area
    patched_figure = add_scatter_area(
        patched_figure,
        DrawingTraces.UNSTABLE_EQUILIBRIA_AREA,
        glob.config.drawing_options.equilibria_area,
        GraphPalette.UNSTABLE_AREA,
        AreaTypes.UNSTABLE,
    )
    # ternary line
    if glob.config.drawing_options.redraw_ternary.branches:
        ternary_line = TernaryLine()
        # update trace for stable line
        patched_figure = add_scatter_data(
            patched_figure,
            DrawingTraces.STABLE_EQUILIBRIA,
            True,
            GraphPalette.STABLE,
            "lines",
            "Empirical stable equilibrium",
            glob.config.drawing_options.equilibria_over_information,
            [ternary_line.stable_sd, ternary_line.stable_sr, ternary_line.stable_sl]
        )
        # update trace for unstable line
        patched_figure = add_scatter_data(
            patched_figure,
            DrawingTraces.UNSTABLE_EQUILIBRIA,
            True,
            GraphPalette.UNSTABLE,
            "lines",
            "Empirical unstable equilibrium",
            glob.config.drawing_options.equilibria_over_information,
            [ternary_line.unstable_sd, ternary_line.unstable_sr, ternary_line.unstable_sl]
        )
        # reset flag
        glob.config.drawing_options.redraw_ternary.branches = False
    # get ternary data (for code legibility)
    ternary_data: TernaryData = glob.plot_data.ternary_data
    # extinct
    if glob.config.drawing_options.redraw_ternary.extinct:
        # iterate over all indexes
        for index in ternary_data.get_current_indexes(BranchTypes.ALTERNATIVE, BifurcationTypes.EXTINCT):
            # update trace for extinctions
            patched_figure = add_scatter_data(
                patched_figure,
                f"{DrawingTraces.EXTINCT}_{index}",
                glob.config.drawing_options.others_extinct,
                GraphPalette.EXTINCT,
                drawing_mode,
                "Extinct",
                True,
                ternary_data.get_current_values(BranchTypes.ALTERNATIVE, BifurcationTypes.EXTINCT, index)
            )
        # reset flag
        glob.config.drawing_options.redraw_ternary.extinct = False
    # saddle node
    if glob.config.drawing_options.redraw_ternary.saddlenode_empirical:
        # iterate over all indexes
        for index in ternary_data.get_current_indexes(BranchTypes.EMPIRICAL, BifurcationTypes.SADDLENODE):
            # update trace for saddlenode empirical
            patched_figure = add_scatter_data(
                patched_figure,
                f"{DrawingTraces.SADDLENODE_EMPIRICAL}_{index}",
                glob.config.drawing_options.bifurcations_saddlenode_empirical,
                GraphPalette.SADDLENODE_EMPIRICAL,
                drawing_mode,
                "Empirical saddle-node bifurcation",
                True,
                ternary_data.get_current_values(BranchTypes.EMPIRICAL, BifurcationTypes.SADDLENODE, index)
            )
        # reset flag
        glob.config.drawing_options.redraw_ternary.saddlenode_empirical = False
    if glob.config.drawing_options.redraw_ternary.saddlenode_alternative:
        # iterate over all indexes
        for index in ternary_data.get_current_indexes(BranchTypes.ALTERNATIVE, BifurcationTypes.SADDLENODE):
            # update trace for saddlenode alternative
            patched_figure = add_scatter_data(
                patched_figure,
                f"{DrawingTraces.SADDLENODE_ALTERNATIVE}_{index}",
                glob.config.drawing_options.bifurcations_saddlenode_alternative,
                GraphPalette.SADDLENODE_ALTERNATIVE,
                drawing_mode,
                "Alternative saddle-node bifurcation",
                True,
                ternary_data.get_current_values(BranchTypes.ALTERNATIVE, BifurcationTypes.SADDLENODE, index)
            )
        # reset flag
        glob.config.drawing_options.redraw_ternary.saddlenode_alternative = False
    # transcritical traces
    if glob.config.drawing_options.redraw_ternary.transcritical_empirical:
        # iterate over all indexes
        for index in ternary_data.get_current_indexes(BranchTypes.EMPIRICAL, BifurcationTypes.TRANSCRITICAL):
            # update trace for transcritical empirical
            patched_figure = add_scatter_data(
                patched_figure,
                f"{DrawingTraces.TRANSCRITICAL_EMPIRICAL}_{index}",
                glob.config.drawing_options.bifurcations_transcritical_empirical,
                GraphPalette.TRANSCRITICAL_EMPIRICAL,
                drawing_mode,
                "Empirical transcritical bifurcation",
                True,
                ternary_data.get_current_values(BranchTypes.EMPIRICAL, BifurcationTypes.TRANSCRITICAL, index)
            )
        # reset flag
        glob.config.drawing_options.redraw_ternary.transcritical_empirical = False
    if glob.config.drawing_options.redraw_ternary.transcritical_alternative:
        # iterate over all indexes
        for index in ternary_data.get_current_indexes(BranchTypes.ALTERNATIVE, BifurcationTypes.TRANSCRITICAL):
            # update trace for transcritical alternative
            patched_figure = add_scatter_data(
                patched_figure,
                f"{DrawingTraces.TRANSCRITICAL_ALTERNATIVE}_{index}",
                glob.config.drawing_options.bifurcations_transcritical_alternative,
                GraphPalette.TRANSCRITICAL_ALTERNATIVE,
                drawing_mode,
                "Alternative transcritical bifurcation",
                True,
                ternary_data.get_current_values(BranchTypes.ALTERNATIVE, BifurcationTypes.TRANSCRITICAL, index)
            )
        # reset flag
        glob.config.drawing_options.redraw_ternary.transcritical_alternative = False
    # hop traces
    if glob.config.drawing_options.redraw_ternary.hopf_empirical:
        # iterate over all indexes
        for index in ternary_data.get_current_indexes(BranchTypes.EMPIRICAL, BifurcationTypes.HOPF):
            # update trace for hopf empirical
            patched_figure = add_scatter_data(
                patched_figure,
                f"{DrawingTraces.HOPF_EMPIRICAL}_{index}",
                glob.config.drawing_options.bifurcations_hopf_empirical,
                GraphPalette.HOPF_EMPIRICAL,
                drawing_mode,
                "Empirical hopf bifurcation",
                True,
                ternary_data.get_current_values(BranchTypes.EMPIRICAL, BifurcationTypes.HOPF, index)
            )
        # reset flag
        glob.config.drawing_options.redraw_ternary.hopf_empirical = False
    if glob.config.drawing_options.redraw_ternary.hopf_alternative:
        # iterate over all indexes
        for index in ternary_data.get_current_indexes(BranchTypes.ALTERNATIVE, BifurcationTypes.HOPF):
            # update trace for hopf alternative
            patched_figure = add_scatter_data(
                patched_figure,
                f"{DrawingTraces.HOPF_ALTERNATIVE}_{index}",
                glob.config.drawing_options.bifurcations_hopf_alternative,
                GraphPalette.HOPF_ALTERNATIVE,
                drawing_mode,
                "Alternative hopf bifurcation",
                True,
                ternary_data.get_current_values(BranchTypes.ALTERNATIVE, BifurcationTypes.HOPF, index)
            )
        # reset flag
        glob.config.drawing_options.redraw_ternary.hopf_alternative = False
    # internal_error
    if glob.config.drawing_options.redraw_ternary.internal_error:
        # iterate over all indexes
        for index in ternary_data.get_current_indexes(BranchTypes.ALTERNATIVE, BifurcationTypes.INTERNAL_ERROR):
            # update trace for internal error
            patched_figure = add_scatter_data(
                patched_figure,
                f"{DrawingTraces.INTERNAL_ERROR}_{index}",
                glob.config.drawing_options.others_internal_error,
                GraphPalette.INTERNAL_ERROR,
                drawing_mode,
                "Internal continuation error",
                True,
                ternary_data.get_current_values(BranchTypes.ALTERNATIVE, BifurcationTypes.INTERNAL_ERROR, index)
            )
        # reset flag
        glob.config.drawing_options.redraw_ternary.internal_error = False
    # return figure
    return patched_figure
