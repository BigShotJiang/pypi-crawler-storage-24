"""Module for building ternary plot figures with arrows and annotations."""

import plotly.graph_objects as go  # type: ignore

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.labels import Labels


# add ternary arrows
def add_ternary_arrows(fig: go.Figure):
    # sd coordinates
    sd_tip_x, sd_tip_y = 0, 0.2  # tip
    sd_tail_x, sd_tail_y = 0.375, 0.866  # tail
    # draw sd arrow
    fig.add_annotation(
        x=sd_tip_x,
        y=sd_tip_y,
        ax=sd_tail_x,
        ay=sd_tail_y,
        xref="x",
        yref="y",
        axref="x",
        ayref="y",
        showarrow=True,
        arrowhead=2,
        arrowwidth=1.5,
    )
    # draw sd text
    fig.add_annotation(
        x=(sd_tip_x + sd_tail_x) / 2,
        y=(sd_tip_y + sd_tail_y) / 2,
        text=Labels.DONOR_CONTROL_STRENGTH,
        showarrow=False,
        xref="x",
        yref="y",
        textangle=-60,
        font={"size": 15},
        bgcolor="white",
        opacity=1,
    )
    # sl coordinates
    sl_tip_x, sl_tip_y = 0.625, 0.866
    sl_tail_x, sl_tail_y = 1, 0.2
    # draw sl arrow
    fig.add_annotation(
        x=sl_tip_x,
        y=sl_tip_y,
        ax=sl_tail_x,
        ay=sl_tail_y,
        xref="x",
        yref="y",
        axref="x",
        ayref="y",
        showarrow=True,
        arrowhead=2,
        arrowwidth=1.5,
    )
    # draw sl text
    fig.add_annotation(
        x=(sl_tip_x + sl_tail_x) / 2,
        y=(sl_tip_y + sl_tail_y) / 2,
        text=Labels.LOTKAVOLTERRA_CONTROL_STRENGT,
        showarrow=False,
        xref="x",
        yref="y",
        textangle=60,
        font={"size": 15},
        bgcolor="white",
        opacity=1,
    )
    # sr coordinates
    sr_tip_x, sr_tip_y = 0.9, 0
    sr_tail_x, sr_tail_y = 0.1, 0
    # draw sr arrow
    fig.add_annotation(
        x=sr_tip_x,
        y=sr_tip_y,
        ax=sr_tail_x,
        ay=sr_tail_y,
        xref="x",
        yref="y",
        axref="x",
        ayref="y",
        showarrow=True,
        arrowhead=2,
        arrowwidth=1.5,
    )
    # draw sr text
    fig.add_annotation(
        x=(sr_tip_x + sr_tail_x) / 2,
        y=(sr_tip_y + sr_tail_y) / 2,
        text=Labels.RECIPIENT_CONTROL_STRENGT,
        showarrow=False,
        xref="x",
        yref="y",
        textangle=0,
        font={"size": 15},
        bgcolor="white",
        opacity=1,
    )
    return fig


# draw instability tuple
def build_ternary():
    # declare figure
    fig = go.Figure()
    # configure
    tick_vals_increase = [round(i * 0.1, 1) for i in range(11)]
    tick_vals_decrease = [round(i * 0.1, 1) for i in range(10, -1, -1)]
    tick_text_decrease = [f"{val:g}" for val in tick_vals_decrease]
    marging = 0.05
    # add ghost trace trace
    fig.add_trace(
        go.Scatterternary(
            a=[0], b=[0], c=[0], mode="markers", opacity=0, showlegend=False, hoverinfo="skip"
        )
    )
    # set layout
    fig.update_layout(
        ternary={
            # draw internal ternary smaller
            "domain": {"x": [marging, 1 - marging], "y": [marging, 1 - marging]},
            # ensure that the sum is 1
            "sum": 1,
            # set axis
            "aaxis": {
                "min": 0,
                "tickvals": tick_vals_increase,
                "ticktext": tick_text_decrease,
                "tickangle": 60,
                "title": "",
                "linecolor": "black",
                "gridcolor": "lightgray",
            },
            "baxis": {
                "min": 0,
                "tickvals": tick_vals_increase,
                "ticktext": tick_text_decrease,
                "tickangle": -60,
                "title": "",
                "linecolor": "black",
                "gridcolor": "lightgray",
            },
            "caxis": {
                "min": 0,
                "tickvals": tick_vals_increase,
                "ticktext": tick_text_decrease,
                "tickangle": 0,
                "title": "",
                "linecolor": "black",
                "gridcolor": "lightgray",
            },
            "bgcolor": "white",  # draw white background
        },
        # Fixed Cartesian axes to support annotations and square ratio
        xaxis={
            "range": [0, 1],  # range between 0 and 1
            "scaleanchor": "y",  # Link X and Y scales for 1:1 ratio
            "scaleratio": 1,  # 1 unit on X = 1 unit on Y (Perfect Square)
            "visible": False,  # Hide all axis elements
            "showgrid": False,  # Explicitly disable grid lines
            "zeroline": False,  # Disable the 0,0 line
            "showticklabels": False,  # Ensure no numbers are rendered
            "fixedrange": False,  # Allow zooming/panning
        },
        yaxis={
            "range": [0, 1],  # Covers triangle (0 to 0.866) + margins
            "visible": False,  # Hide all axis elements
            "showgrid": False,  # Explicitly disable grid lines
            "zeroline": False,  # Disable the 0,0 line
            "showticklabels": False,  # Ensure no numbers are rendered
            "fixedrange": False,  # Allow zooming/panning
        },
        # set background colors
        plot_bgcolor="rgba(0,0,0,0)",  # Set plotting area background to transparent
        paper_bgcolor="rgba(0,0,0,0)",  # Set entire canvas background to transparent
        # disable legend
        showlegend=False,
        # set UI revision (save modifications)
        uirevision="ternary",
        # set sizes
        width=glob.config.resolution * 2,
        height=glob.config.resolution * 2,
    )
    # add arrows
    fig = add_ternary_arrows(fig)
    # ensure that the new ternary is plotted
    glob.config.drawing_options.redraw_ternary.redraw_all()
    # return new figure
    return fig
