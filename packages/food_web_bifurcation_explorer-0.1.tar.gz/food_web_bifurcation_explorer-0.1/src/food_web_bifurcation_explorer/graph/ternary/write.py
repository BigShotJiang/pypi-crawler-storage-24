import os


# write full
def write(ternary, network_name):
    # check if create directory
    if not os.path.exists("results/" + network_name):
        os.makedirs("results/" + network_name)
    # html format
    ternary.write_html("results/" + network_name + "/tuple.html")
    # image format
    # ternary.write_image(folder + "/results/" + network_name + "/tuple_" + tupleName + ".png", width=1920, height=1080)
