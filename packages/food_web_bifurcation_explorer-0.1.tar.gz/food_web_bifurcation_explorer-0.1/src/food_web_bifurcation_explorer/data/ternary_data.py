from enum import Enum
import numpy as np
import pandas as pd
import zipfile
import os

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.common.exceptions import ParameterTypeError
from food_web_bifurcation_explorer.data.bifurcation_data import BifurcationTypes
from food_web_bifurcation_explorer.data.shape_data import ShapeData
from food_web_bifurcation_explorer.enums.numbers_integer import NumbersInteger
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes
from food_web_bifurcation_explorer.enums.types.parameter_types import ParameterTypes


class TernaryData:
    """Branch data container for storing and processing bifurcation analysis data."""

    def __init__(self):
        # declare dataframe
        self.ternary_dataframe: dict[BranchTypes, dict[ParameterTypes, dict[BifurcationTypes, pd.DataFrame]]] = {}
        # iterate over parameter types, branch types and bifurcation types to initialize nested dictionaries
        for branch_type in BranchTypes:
            self.ternary_dataframe[branch_type] = {}
            for parameter_type in ParameterTypes:
                self.ternary_dataframe[branch_type][parameter_type] = {}
                for bifurcation_type in BifurcationTypes:
                    self.ternary_dataframe[branch_type][parameter_type][bifurcation_type] = pd.DataFrame()
        # declare shape data
        self.shape_data: ShapeData = ShapeData()
        # declare array of MAX_FIXED_PARAMETERS elements between 0 and 1 for fixed parameter values
        self.parameters_array = np.linspace(0, 1, NumbersInteger.MAX_FIXED_PARAMETERS)
        # declare empty result (used in get_current_values when dataframe is empty))
        self.empty_result = [
            [None] * NumbersInteger.MAX_FIXED_PARAMETERS,
            [None] * NumbersInteger.MAX_FIXED_PARAMETERS,
            [None] * NumbersInteger.MAX_FIXED_PARAMETERS
        ]

    def clear_data(self):
        """reset all dataframes"""
        # simply reset all dataframes to empty
        for branch_type in BranchTypes:
            for parameter_type in ParameterTypes:
                for bifurcation_type in BifurcationTypes:
                    self.ternary_dataframe[branch_type][parameter_type][bifurcation_type] = pd.DataFrame()

    def get_current_values(self, branch_type: BranchTypes, bifurcation_type: BifurcationTypes, index_col: str):
        """Get the list of index columns for a given branch, parameter and bifurcation type."""
        # get dataframe for current branch, parameter and bifurcation type
        dataframe: pd.DataFrame = self.ternary_dataframe[branch_type][glob.config.fixed_parameter_type][bifurcation_type]
        if dataframe.empty:
            return self.empty_result
        # get rows that only have the value of the given row != Nan
        index_rows = dataframe[dataframe[index_col].notna()]
        if index_rows.empty:
            return self.empty_result
        # Map the parameter type to its corresponding column name
        type_to_column = {
            ParameterTypes.DONOR: 'sd',
            ParameterTypes.RECIPIENT: 'sr',
            ParameterTypes.LOTKAVOLTERRA: 'sl'
        }
        if glob.config.fixed_parameter_type not in type_to_column:
            raise ParameterTypeError("invalid parameter")
        # Get the target column we are going to search against
        target_column = type_to_column[glob.config.fixed_parameter_type]
        # Create a fast lookup dictionary: { target_value: (sd, sr, sl) }
        lookup_dict = {
            row[target_column]: (row['sd'], row['sr'], row['sl'])
            for _, row in index_rows.iterrows()
        }
        # declare values arrays
        sd_values = [None] * NumbersInteger.MAX_FIXED_PARAMETERS
        sr_values = [None] * NumbersInteger.MAX_FIXED_PARAMETERS
        sl_values = [None] * NumbersInteger.MAX_FIXED_PARAMETERS
        # Populate the arrays using the fast lookup dictionary
        for i, parameter_value in enumerate(self.parameters_array):
            if parameter_value in lookup_dict:
                # Unpack the tuple directly into the arrays
                sd_values[i], sr_values[i], sl_values[i] = lookup_dict[parameter_value]
        return [sd_values, sr_values, sl_values]

    def get_current_indexes(self, branch_type: BranchTypes, bifurcation_type: BifurcationTypes):
        """Get the list of index columns for a given branch, parameter and bifurcation type."""
        dataframe: pd.DataFrame = self.ternary_dataframe[branch_type][glob.config.fixed_parameter_type][bifurcation_type]
        if dataframe.empty:
            return []
        # filter columns that start with 'i_' and return their names as a list
        index_columns = [col for col in dataframe.columns if col.startswith('i_')]
        return index_columns

    def load_parquet_data(self, ternary_zip_file):
        """Load parquet data from a parquet file stream and set fixed parameter information."""
        for branch_type in BranchTypes:
            for parameter_type in ParameterTypes:
                for bifurcation_type in BifurcationTypes:
                    # load branch parquet file from zip
                    with ternary_zip_file.open(glob.files.get_ternary_parquet_file(branch_type, parameter_type, bifurcation_type)) as f:
                        self.ternary_dataframe[branch_type][parameter_type][bifurcation_type] = pd.read_parquet(f)

    def load_continuation_files(self, fixed_parameter_values: list[str]):
        """Read ternary data from continuation files."""
        # first clear data
        self.clear_data()
        # define the column structure ("bone") for every bifurcation type
        columns_definitions = {}
        for bifurcation_type in BifurcationTypes:
            # store the complete column layout for later use
            columns_definitions[bifurcation_type] = ['sd', 'sr', 'sl'] + [f'i_{i}' for i in range(NumbersInteger.MAX_NUM_TRACES)]
        # create a temporary nested dictionary to hold rows as native Python lists
        temporal_frame = {
            branch_type: {
                parameter_type: {
                    bifurcation_type: [] for bifurcation_type in BifurcationTypes
                } for parameter_type in ParameterTypes
            } for branch_type in BranchTypes
        }
        # now read data for every zip file
        for index, fixed_parameter_value in enumerate(fixed_parameter_values):
            # show current processed value
            print(fixed_parameter_value)
            # get continuation zip file path
            continuation_zip_file_path = glob.files.get_continuation_zip_file(fixed_parameter_value)
            # check if file exists
            if os.path.exists(continuation_zip_file_path):
                # open continuation zip file
                with zipfile.ZipFile(continuation_zip_file_path, "r") as continuation_zip_file:
                    # open CSV for every parameter and branch type
                    for branch_type in BranchTypes:
                        for parameter_type in ParameterTypes:
                            # parse CSV in temporal dataframe
                            file_name = f"bifurcations_{branch_type.value}_{parameter_type.value}_{fixed_parameter_value}.csv"
                            with continuation_zip_file.open(file_name) as file:
                                tmp_dataframe = pd.read_csv(file)
                            # iterate over bifurcation types
                            for bifurcation_type in BifurcationTypes:
                                # filter rows for current bifurcation type
                                bifurcation_type_rows = tmp_dataframe[tmp_dataframe['type'] == bifurcation_type.value]
                                # iterate over filtered rows (using itertuples is faster than iterrows)
                                for row in bifurcation_type_rows.itertuples(index=False):
                                    index_value = int(row.index)
                                    # create a dictionary representing the new row
                                    new_row_dict = {
                                        'sd': row.sd,
                                        'sr': row.sr,
                                        'sl': row.sl,
                                        f'i_{index_value}': index_value
                                    }
                                    # append dictionary to our temporary list
                                    temporal_frame[branch_type][parameter_type][bifurcation_type].append(new_row_dict)
            # load shape data for current fixed parameter value
            self.shape_data.load_shape_data(index, fixed_parameter_value)
        # now that all files are processed, update the ternary_dataframe with the complete data from temporal_frame
        for branch_type in BranchTypes:
            for parameter_type in ParameterTypes:
                for bifurcation_type in BifurcationTypes:
                    # Create the dataframe from the list of dictionaries
                    dataframe = pd.DataFrame(temporal_frame[branch_type][parameter_type][bifurcation_type])
                    # Force the dataframe to have the exact "bone" columns we defined at the beginning
                    base_columns = columns_definitions[bifurcation_type]
                    dataframe = dataframe.reindex(columns=base_columns)
                    # Drop columns that are completely empty
                    dataframe.dropna(axis=1, how='all', inplace=True)
                    # Assign the fully built dataframe to the class attribute
                    self.ternary_dataframe[branch_type][parameter_type][bifurcation_type] = dataframe
        # also process shape data
        self.shape_data.process_shape_data()
