import numpy as np
import pandas as pd

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes
from food_web_bifurcation_explorer.enums.types.bifurcation_types import BifurcationTypes
from food_web_bifurcation_explorer.enums.types.parameter_types import ParameterTypes


# instability data struct
class TernaryLine:

    # constructor
    def __init__(self):
        # declare values
        self.stable_sd = []
        self.stable_sr = []
        self.stable_sl = []
        self.unstable_sd = []
        self.unstable_sr = []
        self.unstable_sl = []
        # calculate points
        grid = np.linspace(0, 1, 1000 + 1)
        # get bifurcation data
        bifurcations_dataframe: pd.DataFrame = glob.plot_data.branch_datas[glob.config.fixed_parameter_type][BranchTypes.EMPIRICAL].bifurcations_dataframe
        # get frontier
        df_frontier: pd.DataFrame = bifurcations_dataframe[bifurcations_dataframe['type'] == BifurcationTypes.FRONTIER.value]
        # check frontier
        if len(df_frontier) > 0:
            # extract frontier value
            frontier_value = df_frontier["parameter_values"].iloc[0]
            # continue depending of fixed parameter
            if glob.config.fixed_parameter_type == ParameterTypes.DONOR:
                for sl in grid:
                    sr = 1 - sl - glob.config.fixed_parameter_value
                    if (sr >= 0) or (sr <= 1):
                        if sl < frontier_value:
                            self.stable_sd.append(glob.config.fixed_parameter_value)
                            self.stable_sr.append(sr)
                            self.stable_sl.append(sl)
                        else:
                            self.unstable_sd.append(glob.config.fixed_parameter_value)
                            self.unstable_sr.append(sr)
                            self.unstable_sl.append(sl)
            elif glob.config.fixed_parameter_type == ParameterTypes.RECIPIENT:
                for sd in grid:
                    sl = 1 - sd - glob.config.fixed_parameter_value
                    if (sl >= 0) or (sl <= 1):
                        if sd > frontier_value:
                            self.stable_sd.append(sd)
                            self.stable_sr.append(glob.config.fixed_parameter_value)
                            self.stable_sl.append(sl)
                        else:
                            self.unstable_sd.append(sd)
                            self.unstable_sr.append(glob.config.fixed_parameter_value)
                            self.unstable_sl.append(sl)
            elif glob.config.fixed_parameter_type == ParameterTypes.LOTKAVOLTERRA:
                for sr in grid:
                    sd = 1 - sr - glob.config.fixed_parameter_value
                    if (sd >= 0) or (sd <= 1):
                        if sr < frontier_value:
                            self.stable_sd.append(sd)
                            self.stable_sr.append(sr)
                            self.stable_sl.append(glob.config.fixed_parameter_value)
                        else:
                            self.unstable_sd.append(sd)
                            self.unstable_sr.append(sr)
                            self.unstable_sl.append(glob.config.fixed_parameter_value)
        else:
            # continue depending of fixed parameter
            if glob.config.fixed_parameter_type == ParameterTypes.DONOR:
                for sl in grid:
                    sr = 1 - sl - glob.config.fixed_parameter_value
                    if (sr >= 0) or (sr <= 1):
                        self.stable_sd.append(glob.config.fixed_parameter_value)
                        self.stable_sr.append(sr)
                        self.stable_sl.append(sl)
            elif glob.config.fixed_parameter_type == ParameterTypes.RECIPIENT:
                for sd in grid:
                    sl = 1 - sd - glob.config.fixed_parameter_value
                    if (sl >= 0) or (sl <= 1):
                        self.stable_sd.append(sd)
                        self.stable_sr.append(glob.config.fixed_parameter_value)
                        self.stable_sl.append(sl)
            elif glob.config.fixed_parameter_type == ParameterTypes.LOTKAVOLTERRA:
                for sr in grid:
                    sd = 1 - sr - glob.config.fixed_parameter_value
                    if (sd >= 0) or (sd <= 1):
                        self.stable_sd.append(sd)
                        self.stable_sr.append(sr)
                        self.stable_sl.append(glob.config.fixed_parameter_value)
