import numpy as np
import pandas as pd
import zipfile
from typing import IO

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes
from food_web_bifurcation_explorer.enums.numbers_float import NumbersFloat
from food_web_bifurcation_explorer.enums.types.parameter_types import ParameterTypes
from food_web_bifurcation_explorer.common.exceptions import ParameterTypeError
from food_web_bifurcation_explorer.data.envelope_data import EnvelopeData


class BranchData:
    """Branch data container for storing and processing bifurcation analysis data."""

    def __init__(self, branch_type: BranchTypes, parameter_type: ParameterTypes):
        # parameter associated with this branch
        self.fixed_parameter_type: ParameterTypes = parameter_type
        self.branch_type: BranchTypes = branch_type
        self.fixed_parameter_value: str | None = None
        self.n: int = 0
        self.envelope_data: EnvelopeData = EnvelopeData()

        # data frames
        self.branch_dataframe: pd.DataFrame = pd.DataFrame()
        self.bifurcations_dataframe: pd.DataFrame = pd.DataFrame()

        # Processed DataFrames: one column per biomass component
        self.stablenodes_dataframe: pd.DataFrame = pd.DataFrame()
        self.unstablenodes_dataframe: pd.DataFrame = pd.DataFrame()
        self.transition_stabletounstablenodes_dataframe: pd.DataFrame = pd.DataFrame()
        self.transition_unstabletostablenodes_dataframe: pd.DataFrame = pd.DataFrame()

    def load(self, fixed_parameter_value, stream: IO[bytes]):
        """Load branch data from a parquet file stream and set fixed parameter information."""
        self.branch_dataframe = pd.read_parquet(stream)
        self.fixed_parameter_value = fixed_parameter_value
        # process data after loading
        self.process_data()

    def clear_data(self):
        """Clear all data containers and reset to initial state."""
        self.branch_dataframe = pd.DataFrame()
        self.stablenodes_dataframe = pd.DataFrame()
        self.unstablenodes_dataframe = pd.DataFrame()
        self.transition_stabletounstablenodes_dataframe = pd.DataFrame()
        self.transition_unstabletostablenodes_dataframe = pd.DataFrame()
        self.n = 0

    def get_eigenvalue_spectrum_x(self):
        idx = glob.config.eigenvalue_spectrum_index[self.branch_type]
        if idx < len(self.branch_dataframe):
            return [self.branch_dataframe.at[idx, "parameter_values"]]
        return []

    def get_eigenvalue_spectrum_y(self):
        """Get eigenvalue spectrum Y values (first biomass component at current index)."""
        idx = glob.config.eigenvalue_spectrum_index[self.branch_type]
        if idx < len(self.branch_dataframe):
            return [self.branch_dataframe.at[idx, f"b_{glob.config.compartment_first_index + 1}"]]
        return []

    def get_eigenvalue_spectrum_values(self):
        """Get eigenvalue spectrum values including real/imaginary parts and their ranges."""
        real_parts = []
        imaginary_parts = []
        idx = glob.config.eigenvalue_spectrum_index[self.branch_type]

        if idx < len(self.branch_dataframe):
            real_parts = [self.branch_dataframe.at[idx, f"ev_r_{glob.config.compartment_first_index + 1}"]]
            imaginary_parts = [self.branch_dataframe.at[idx, f"ev_i_{glob.config.compartment_first_index + 1}"]]

        if len(real_parts) > 0:
            real_arr = np.array(real_parts)
            imag_arr = np.array(imaginary_parts)

            if glob.config.drawing_options.eigenvalue_spectrum_centered[self.branch_type]:
                min_real = NumbersFloat.EIGENVALUE_SPECTRUM_CENTER_MIN_X
                max_real = NumbersFloat.EIGENVALUE_SPECTRUM_CENTER_MAX_X
            else:
                min_real, max_real = real_arr.min(), real_arr.max()

            min_imaginary = imag_arr.min() if len(imag_arr) > 0 else -1
            max_imaginary = imag_arr.max() if len(imag_arr) > 0 else 1

            return [real_parts, imaginary_parts, min_real, max_real, min_imaginary, max_imaginary]

        return [real_parts, imaginary_parts, -1, 1, -1, 1]

    def read_branch_data(self, continuation_zip_file, fixed_parameter_type: ParameterTypes, fixed_parameter_value: str):
        """Read branch data from a continuation zip file and set fixed parameter information."""
        # first clear data
        self.clear_data()

        # set values
        self.fixed_parameter_type = fixed_parameter_type
        self.fixed_parameter_value = fixed_parameter_value
        
        # try to read data from zip file, if fail clear data
        try:
            # parse CSVs
            with continuation_zip_file.open(f"{self.branch_type.value}_{self.fixed_parameter_type.value}_{self.fixed_parameter_value}.csv") as file:
                self.branch_dataframe = pd.read_csv(file)
            with continuation_zip_file.open(f"bifurcations_{self.branch_type.value}_{self.fixed_parameter_type.value}_{self.fixed_parameter_value}.csv") as file:
                self.bifurcations_dataframe = pd.read_csv(file)
            # remove unnecesaria parameter columns
            if self.fixed_parameter_type == ParameterTypes.DONOR:
                self.branch_dataframe = self.branch_dataframe.drop(columns=['sd', 'sr'])
                self.bifurcations_dataframe = self.bifurcations_dataframe.drop(columns=['sd', 'sr'])
                self.branch_dataframe = self.branch_dataframe.rename(columns={'sl': 'parameter_values'})
                self.bifurcations_dataframe = self.bifurcations_dataframe.rename(columns={'sl': 'parameter_values'})
            elif self.fixed_parameter_type == ParameterTypes.RECIPIENT:
                self.branch_dataframe = self.branch_dataframe.drop(columns=['sr', 'sl'])
                self.bifurcations_dataframe = self.bifurcations_dataframe.drop(columns=['sr', 'sl'])
                self.branch_dataframe = self.branch_dataframe.rename(columns={'sd': 'parameter_values'})
                self.bifurcations_dataframe = self.bifurcations_dataframe.rename(columns={'sd': 'parameter_values'})
            elif self.fixed_parameter_type == ParameterTypes.LOTKAVOLTERRA:
                self.branch_dataframe = self.branch_dataframe.drop(columns=['sl', 'sd'])
                self.bifurcations_dataframe = self.bifurcations_dataframe.drop(columns=['sl', 'sd'])
                self.branch_dataframe = self.branch_dataframe.rename(columns={'sr': 'parameter_values'})
                self.bifurcations_dataframe = self.bifurcations_dataframe.rename(columns={'sr': 'parameter_values'})
            else:
                raise ParameterTypeError("invalid parameter")
        except Exception:
            self.clear_data()

        # process data after reading (needed to update n)
        self.process_data()

        # read envelope edata
        self.envelope_data.read_envelope_data(self.branch_type, self.fixed_parameter_type, self.fixed_parameter_value, self.n)

    def process_data(self):
        """Process loaded data to separate stable/unstable nodes and identify transitions."""
        
        # Check if branch_dataframe is empty before processing
        if self.branch_dataframe.empty:
            return
                
        # Update n using biomass columns
        biomass_columns = self.branch_dataframe.filter(regex='^b_')
        self.n = len(biomass_columns.columns)

        # get all biomass columns (those that start with 'b_')
        biomass_columns = [c for c in self.branch_dataframe.columns if c.startswith('b_')]
        
        # extract node types and biomass values as numpy arrays for efficient processing
        node_types = self.branch_dataframe["type"].to_numpy()
        biomass_matrix = self.branch_dataframe[biomass_columns].to_numpy()
        num_params = len(self.branch_dataframe)
        
        # declare mask for stable and unstable nodes
        stable_mask = (node_types == 0)
        unstable_mask = (node_types == 1)
        
        # create stable and unstable biomass matrices using masks, filling non-relevant rows with NaN
        stable_matrix = np.where(stable_mask[:, None], biomass_matrix, np.nan)
        unstable_matrix = np.where(unstable_mask[:, None], biomass_matrix, np.nan)
        
        # identify transitions between stable and unstable nodes
        transition_stabletounstable = np.full_like(biomass_matrix, np.nan, dtype=float)
        transition_ustabletostable = np.full_like(biomass_matrix, np.nan, dtype=float)
        
        # iterate over all params
        for i in range(1, num_params):
            # stable to unstable
            if node_types[i - 1] == 0 and node_types[i] == 1:
                transition_stabletounstable[i - 1] = biomass_matrix[i - 1]
                transition_stabletounstable[i] = biomass_matrix[i]
            # unstable to stable
            elif node_types[i - 1] == 1 and node_types[i] == 0:
                transition_ustabletostable[i - 1] = biomass_matrix[i - 1]
                transition_ustabletostable[i] = biomass_matrix[i]
        
        # save results in dataframes with appropriate column names
        cols = [f"b_{j+1}" for j in range(self.n)]
        self.stablenodes_dataframe = pd.DataFrame(stable_matrix, columns=cols)
        self.unstablenodes_dataframe = pd.DataFrame(unstable_matrix, columns=cols)
        self.transition_stabletounstablenodes_dataframe = pd.DataFrame(transition_stabletounstable, columns=cols)
        self.transition_unstabletostablenodes_dataframe = pd.DataFrame(transition_ustabletostable, columns=cols)