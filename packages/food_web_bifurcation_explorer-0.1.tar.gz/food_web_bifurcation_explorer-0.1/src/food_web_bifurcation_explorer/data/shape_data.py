import zipfile
import pandas as pd
import numpy as np

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.types.area_types import AreaTypes
from food_web_bifurcation_explorer.enums.numbers_integer import NumbersInteger
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes
from food_web_bifurcation_explorer.enums.types.parameter_types import ParameterTypes


class ShapeData:

    def __init__(self):
        # declare grids
        grid: np.ndarray = np.linspace(0, 1, NumbersInteger.MAX_NUM_TRACES)
        # declare perimeters
        self.perimeter_stable: pd.DataFrame = pd.DataFrame()
        self.perimeter_unstable: pd.DataFrame = pd.DataFrame()
        # create a left and right vertex of the perimeter for each area type
        self.left_vertex: list[list[float], list[float], list[float]] = [[],[],[]]
        self.right_vertex: list[list[float], list[float], list[float]] = [[],[],[]]
        # iterate over both grid and set the left and right vertex for each area type
        for sl in grid:
            # declare sr limits
            sr_limits: list[float] = []
            # calculate sr limits
            for sr in grid:
                # calculate sd
                sd = 1 - sl - sr
                # check if it's valid
                if (sd >= 0 and sd <= 1):
                    sr_limits.append(sr)
            # set left and right vertex
            self.left_vertex[0].append(float(1 - sl))
            self.left_vertex[1].append(0)
            self.left_vertex[2].append(float(sl))
            self.right_vertex[0].append(0)
            self.right_vertex[1].append(float(1 - sl))
            self.right_vertex[2].append(float(sl))
        # set vertex stable
        self.left_vertex_stable = list(self.left_vertex)
        self.right_vertex_stable = list(self.right_vertex)
        # we assume that the full system is stable, and therefore we put the stable and unstable hidden
        self.left_vertex_unstable = list(self.right_vertex)
        self.right_vertex_unstable = list(self.right_vertex)

    def load_shape_data(self, index: int, fixed_parameter_value: str):
        """Read branch data using Pandas vectorization and store 3D points."""
        try:
            with zipfile.ZipFile(glob.files.get_continuation_zip_file(fixed_parameter_value), "r") as zip_file:
                with zip_file.open(f"bifurcations_{BranchTypes.EMPIRICAL.value}_{ParameterTypes.LOTKAVOLTERRA.value}_{fixed_parameter_value}.csv") as file:
                    # read bifurcation dataframe
                    dataframe = pd.read_csv(file)           
                    # get sr value (this value mark the frontier)
                    sr_value = dataframe.loc[dataframe['type'] == 'frontier', 'sr'].item()
                    # update values in vertex list
                    self.right_vertex_stable[0][index] = 1 - sr_value
                    self.right_vertex_stable[1][index] = sr_value
                    self.left_vertex_unstable[0][index] = 1 - sr_value
                    self.left_vertex_unstable[1][index] = sr_value
                    
        except Exception as e:
            pass

    def process_shape_data(self):
        # transform to pandas
        perimeter_stable: pd.DataFrame = pd.DataFrame({
            'sd': self.left_vertex_stable[0] + self.right_vertex_stable[0][::-1],
            'sr': self.left_vertex_stable[1] + self.right_vertex_stable[1][::-1],
            'sl': self.left_vertex_stable[2] + self.right_vertex_stable[2][::-1]
        })
        perimeter_unstable: pd.DataFrame = pd.DataFrame({
            'sd': self.left_vertex_unstable[0] + self.right_vertex_unstable[0][::-1],
            'sr': self.left_vertex_unstable[1] + self.right_vertex_unstable[1][::-1],
            'sl': self.left_vertex_unstable[2] + self.right_vertex_unstable[2][::-1]
        })
        # close both perimeter
        self.perimeter_stable = pd.concat([perimeter_stable, perimeter_stable.iloc[[0]]], ignore_index=True)
        self.perimeter_unstable = pd.concat([perimeter_unstable, perimeter_unstable.iloc[[0]]], ignore_index=True)


    def get_perimeter_coordinates(self, area_type: AreaTypes):
        """
        Retrieve sd, sr, sl coordinates for the perimeter.
        """
        if (area_type == AreaTypes.STABLE):
            if (self.perimeter_stable.empty):
                return [[], [], []]
            return (
                self.perimeter_stable["sd"].tolist(), 
                self.perimeter_stable["sr"].tolist(), 
                self.perimeter_stable["sl"].tolist()
            )
        else:
            return [[], [], []]
            if (self.perimeter_unstable.empty):
                return [[], [], []]
            return (
                self.perimeter_unstable["sd"].tolist(), 
                self.perimeter_unstable["sr"].tolist(), 
                self.perimeter_unstable["sl"].tolist()
            )