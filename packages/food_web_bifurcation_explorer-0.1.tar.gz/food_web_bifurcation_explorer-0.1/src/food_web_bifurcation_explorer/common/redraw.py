# redraw flags
class Redraw:

    def __init__(self):
        """Initialize all redraw flags to True."""
        self.branches: bool = True
        self.extinct: bool = True
        self.saddlenode_empirical: bool = True
        self.saddlenode_alternative: bool = True
        self.transcritical_empirical: bool = True
        self.transcritical_alternative: bool = True
        self.hopf_empirical: bool = True
        self.hopf_alternative: bool = True
        self.envelope_empirical: bool = True
        self.envelope_alternative: bool = True
        self.internal_error: bool = True
        self.eigenvalue_spectrum_index: bool = True
        self.redraw_eigenvalue_spectrum_centered_empirical: bool = True
        self.redraw_eigenvalue_spectrum_centered_alternative: bool = True

    def redraw_all(self):
        """Set all redraw flags to True."""
        self.branches = True
        self.extinct = True
        self.saddlenode_empirical = True
        self.saddlenode_alternative = True
        self.transcritical_empirical = True
        self.transcritical_alternative = True
        self.hopf_empirical = True
        self.hopf_alternative = True
        self.envelope_empirical = True
        self.envelope_alternative = True
        self.internal_error = True
        self.eigenvalue_spectrum_index = True
        self.redraw_eigenvalue_spectrum_centered_empirical = True
        self.redraw_eigenvalue_spectrum_centered_alternative = True

    def require_redraw_all(self, original: bool, new: bool):
        """Redraw all if the original and new values differ."""
        if original != new:
            self.redraw_all()

    def require_redraw_branches(self, original: bool, new: bool):
        """Set branches redraw flag if the original and new values differ."""
        self.branches = self.branches or (original != new)

    def require_redraw_extinct(self, original: bool, new: bool):
        """Set extinct redraw flag if the original and new values differ."""
        self.extinct = self.extinct or (original != new)

    def require_redraw_saddlenode_empirical(self, original: bool, new: bool):
        """Set saddlenode_empirical redraw flag if the original and new values differ."""
        self.saddlenode_empirical = self.saddlenode_empirical or (original != new)

    def require_redraw_saddlenode_alternative(self, original: bool, new: bool):
        """Set saddlenode_alternative redraw flag if the original and new values differ."""
        self.saddlenode_alternative = self.saddlenode_alternative or (original != new)

    def require_redraw_transcritical_empirical(self, original: bool, new: bool):
        """Set transcritical_empirical redraw flag if the original and new values differ."""
        self.transcritical_empirical = self.transcritical_empirical or (original != new)

    def require_redraw_transcritical_alternative(self, original: bool, new: bool):
        """Set transcritical_alternative redraw flag if the original and new values differ."""
        self.transcritical_alternative = self.transcritical_alternative or (original != new)

    def require_redraw_hopf_empirical(self, original: bool, new: bool):
        """Set hopf_empirical redraw flag if the original and new values differ."""
        self.hopf_empirical = self.hopf_empirical or (original != new)

    def require_redraw_hopf_alternative(self, original: bool, new: bool):
        """Set hopf_alternative redraw flag if the original and new values differ."""
        self.hopf_alternative = self.hopf_alternative or (original != new)

    def require_redraw_envelope_empirical(self, original: bool, new: bool):
        """Set envelope_empirical redraw flag if the original and new values differ."""
        self.envelope_empirical = self.envelope_empirical or (original != new)

    def require_redraw_envelope_alternative(self, original: bool, new: bool):
        """Set envelope_alternative redraw flag if the original and new values differ."""
        self.envelope_alternative = self.envelope_alternative or (original != new)

    def require_redraw_internal_error(self, original: bool, new: bool):
        """Set internal_error redraw flag if the original and new values differ."""
        self.internal_error = self.internal_error or (original != new)

    def require_redraw_eigenvalue_spectrum_index(self, original: bool, new: bool):
        """Set eigenvalue_spectrum_index redraw flag if the original and new values differ."""
        self.eigenvalue_spectrum_index = self.eigenvalue_spectrum_index or (original != new)

    def require_redraw_eigenvalue_spectrum_centered_empirical(self, original: bool, new: bool):
        """Set redraw_eigenvalue_spectrum_centered_empirical redraw flag if the original and new values differ."""
        self.redraw_eigenvalue_spectrum_centered_empirical = (
            self.redraw_eigenvalue_spectrum_centered_empirical or (original != new)
        )

    def require_redraw_eigenvalue_spectrum_centered_alternative(self, original: bool, new: bool):
        """Set redraw_eigenvalue_spectrum_centered_alternative redraw flag if the original and new values differ."""
        self.redraw_eigenvalue_spectrum_centered_alternative = (
            self.redraw_eigenvalue_spectrum_centered_alternative or (original != new)
        )
