from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes
from food_web_bifurcation_explorer.common.redraw import Redraw


class DrawingOptions:

    def __init__(self):
        self.equilibria_area: bool = True
        self.equilibria_stable: bool = True
        self.equilibria_unstable: bool = True
        self.equilibria_over_information: bool = True
        self.bifurcations_saddlenode_empirical: bool = True
        self.bifurcations_saddlenode_alternative: bool = True
        self.bifurcations_transcritical_empirical: bool = True
        self.bifurcations_transcritical_alternative: bool = True
        self.bifurcations_hopf_empirical: bool = True
        self.bifurcations_envelope_empirical: bool = True
        self.bifurcations_hopf_alternative: bool = True
        self.bifurcations_envelope_alternative: bool = True
        self.others_internal_error: bool = True
        self.others_extinct: bool = True
        self.draw_branch_empirical: bool = True
        self.draw_branch_alternative: bool = True
        self.draw_lines: bool = True
        self.draw_points: bool = True
        self.others_eigenvalue_spectrum_index: bool = True
        # eigenValues spectrum options
        self.eigenvalue_spectrum_centered: dict[BranchTypes, bool] = {}
        for branch_type in BranchTypes:
            self.eigenvalue_spectrum_centered[branch_type] = True
        # redraw options
        self.redraw_ternary: Redraw = Redraw()
        self.redraw_bifurcation_diagrams_first: Redraw = Redraw()
        self.redraw_bifurcation_diagrams_second: Redraw = Redraw()

    def update_flags(
        self,
        equilibria_area: bool,
        equilibria_stable: bool,
        equilibria_unstable: bool,
        equilibria_over_information: bool,
        bifurcations_saddlenode_empirical: bool,
        bifurcations_saddlenode_alternative: bool,
        bifurcations_transcritical_empirical: bool,
        bifurcations_transcritical_alternative: bool,
        bifurcations_hopf_empirical: bool,
        bifurcations_envelope_empirical: bool,
        bifurcations_hopf_alternative: bool,
        bifurcations_envelope_alternative: bool,
        others_extinct: bool,
        others_internal_error: bool,
        others_eigenvalue_spectrum_index: bool,
        draw_branch_empirical: bool,
        draw_branch_alternative: bool,
        draw_lines: bool,
        draw_points: bool,
        eigenvalue_spectrum_centered_empirical: bool,
        eigenvalue_spectrum_centered_alternative: bool,
    ):
        """
        Update the display and calculation flags for various diagram elements and redraw targets.
        """
        # redraw
        redraw_targets = [
            self.redraw_ternary,
            self.redraw_bifurcation_diagrams_first,
            self.redraw_bifurcation_diagrams_second,
        ]
        for target in redraw_targets:
            # this both reset all
            target.require_redraw_all(self.draw_lines, draw_lines)
            target.require_redraw_all(self.draw_points, draw_points)
            # redraw branches
            target.require_redraw_branches(self.equilibria_stable, equilibria_stable)
            target.require_redraw_branches(self.equilibria_unstable, equilibria_unstable)
            target.require_redraw_branches(self.equilibria_area, equilibria_area)
            target.require_redraw_branches(
                self.equilibria_over_information, equilibria_over_information
            )
            target.require_redraw_branches(self.draw_branch_empirical, draw_branch_empirical)
            target.require_redraw_branches(self.draw_branch_alternative, draw_branch_alternative)
            # rest of elements
            target.require_redraw_extinct(self.others_extinct, others_extinct)
            target.require_redraw_saddlenode_empirical(
                self.bifurcations_saddlenode_empirical, bifurcations_saddlenode_empirical
            )
            target.require_redraw_saddlenode_alternative(
                self.bifurcations_saddlenode_alternative, bifurcations_saddlenode_alternative
            )
            # transcritical
            target.require_redraw_transcritical_empirical(
                self.bifurcations_transcritical_empirical, bifurcations_transcritical_empirical
            )
            target.require_redraw_transcritical_alternative(
                self.bifurcations_transcritical_alternative, bifurcations_transcritical_alternative
            )
            # hopf
            target.require_redraw_hopf_empirical(
                self.bifurcations_hopf_empirical, bifurcations_hopf_empirical
            )
            target.require_redraw_hopf_alternative(
                self.bifurcations_hopf_alternative, bifurcations_hopf_alternative
            )
            # envelope
            target.require_redraw_envelope_empirical(
                self.bifurcations_envelope_empirical, bifurcations_envelope_empirical
            )
            target.require_redraw_envelope_alternative(
                self.bifurcations_envelope_alternative, bifurcations_envelope_alternative
            )
            # other
            target.require_redraw_internal_error(self.others_internal_error, others_internal_error)
            target.require_redraw_eigenvalue_spectrum_index(
                self.others_eigenvalue_spectrum_index, others_eigenvalue_spectrum_index
            )
            # eigenvalue spectrum centered
            target.require_redraw_eigenvalue_spectrum_centered_empirical(
                self.eigenvalue_spectrum_centered[BranchTypes.EMPIRICAL],
                eigenvalue_spectrum_centered_empirical,
            )
            target.require_redraw_eigenvalue_spectrum_centered_alternative(
                self.eigenvalue_spectrum_centered[BranchTypes.ALTERNATIVE],
                eigenvalue_spectrum_centered_alternative,
            )
        # update values
        self.equilibria_area = equilibria_area
        self.equilibria_stable = equilibria_stable
        self.equilibria_unstable = equilibria_unstable
        self.equilibria_over_information = equilibria_over_information
        self.bifurcations_saddlenode_empirical = bifurcations_saddlenode_empirical
        self.bifurcations_saddlenode_alternative = bifurcations_saddlenode_alternative
        self.bifurcations_transcritical_empirical = bifurcations_transcritical_empirical
        self.bifurcations_transcritical_alternative = bifurcations_transcritical_alternative
        self.bifurcations_hopf_empirical = bifurcations_hopf_empirical
        self.bifurcations_envelope_empirical = bifurcations_envelope_empirical
        self.bifurcations_hopf_alternative = bifurcations_hopf_alternative
        self.bifurcations_envelope_alternative = bifurcations_envelope_alternative
        self.others_extinct = others_extinct
        self.others_internal_error = others_internal_error
        self.others_eigenvalue_spectrum_index = others_eigenvalue_spectrum_index
        self.draw_branch_empirical = draw_branch_empirical
        self.draw_branch_alternative = draw_branch_alternative
        self.draw_lines = draw_lines
        self.draw_points = draw_points
        self.eigenvalue_spectrum_centered[BranchTypes.EMPIRICAL] = (
            eigenvalue_spectrum_centered_empirical
        )
        self.eigenvalue_spectrum_centered[BranchTypes.ALTERNATIVE] = (
            eigenvalue_spectrum_centered_alternative
        )
