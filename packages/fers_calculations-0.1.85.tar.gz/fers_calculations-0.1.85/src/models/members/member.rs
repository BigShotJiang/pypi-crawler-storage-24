use crate::functions::geometry::{DOFS_PER_NODE, ELEMENT_DOFS};
use crate::models::members::enums::MemberType;
use crate::models::nodes::node::Node;
use serde::{Deserialize, Serialize};
use utoipa::ToSchema;

#[derive(Serialize, Deserialize, ToSchema, Debug, Clone)]
pub struct Member {
    pub id: u32,
    pub start_node: Node,
    pub end_node: Node,
    pub section: Option<u32>,
    pub rotation_angle: f64,
    pub start_hinge: Option<u32>,
    pub end_hinge: Option<u32>,
    pub classification: String,
    pub weight: f64,
    pub chi: Option<f64>,
    pub reference_member: Option<u32>,
    pub reference_node: Option<u32>,
    pub member_type: MemberType,
}

use crate::models::members::{material::Material, section::Section};
use nalgebra::{DMatrix, DVector, Matrix3, Vector3};
use std::collections::HashMap;

/// Build a 3×3 rotation matrix from an axis-angle rotation vector ω.
///
/// Uses Rodrigues' rotation formula: R = I + sin(θ)·K + (1−cos(θ))·K²
/// where θ = |ω| and K = skew(ω/θ).
/// For zero vector returns identity.
pub fn rotation_matrix_from_vector(omega: &Vector3<f64>) -> Matrix3<f64> {
    let angle = omega.norm();
    if angle < 1e-12 {
        return Matrix3::identity();
    }
    let k = omega / angle;
    let kx = Matrix3::new(
        0.0, -k.z, k.y,
        k.z, 0.0, -k.x,
        -k.y, k.x, 0.0,
    );
    Matrix3::identity() + kx * angle.sin() + kx * kx * (1.0 - angle.cos())
}

/// Extract the axis-angle rotation vector from a 3×3 rotation matrix.
///
/// Returns ω such that |ω| = rotation angle and ω/|ω| = rotation axis.
/// For identity (no rotation) returns the zero vector.
pub fn rotation_vector_from_matrix(r: &Matrix3<f64>) -> Vector3<f64> {
    let trace = r[(0, 0)] + r[(1, 1)] + r[(2, 2)];
    let cos_theta = ((trace - 1.0) / 2.0).clamp(-1.0, 1.0);
    let theta = cos_theta.acos();

    if theta.abs() < 1e-12 {
        // No rotation
        return Vector3::zeros();
    }

    if (std::f64::consts::PI - theta).abs() < 1e-6 {
        // θ ≈ π: use eigenvector of R corresponding to eigenvalue 1
        // R + I has rank 1; its largest-norm column is the axis
        let s = r + Matrix3::identity();
        let mut best = Vector3::zeros();
        let mut best_norm = 0.0;
        for col in 0..3 {
            let v = Vector3::new(s[(0, col)], s[(1, col)], s[(2, col)]);
            let n = v.norm();
            if n > best_norm {
                best = v;
                best_norm = n;
            }
        }
        if best_norm > 1e-15 {
            best /= best_norm;
        }
        return best * theta;
    }

    // General case: axis from skew-symmetric part of R
    let axis = Vector3::new(
        r[(2, 1)] - r[(1, 2)],
        r[(0, 2)] - r[(2, 0)],
        r[(1, 0)] - r[(0, 1)],
    );
    axis * (theta / (2.0 * theta.sin()))
}

impl Member {
    pub fn calculate_length(&self) -> f64 {
        self.start_node.distance_to(&self.end_node)
    }

    pub fn calculate_stiffness_matrix_2d(
        &self,
        material_map: &HashMap<u32, &Material>,
        section_map: &HashMap<u32, &Section>,
    ) -> Option<DMatrix<f64>> {
        let section_id = self.section.unwrap_or_else(|| {
            panic!(
                "Member {} ({:?}) missing section id required to compute axial force.",
                self.id, self.member_type
            )
        });

        let section = section_map.get(&section_id)?;
        let material = material_map.get(&section.material)?;

        let e = material.e_mod;
        let a = section.area;
        let i = section.i_y;
        let l = self.calculate_length();

        let axial = e * a / l;
        let bending = e * i / (l * l * l);

        Some(DMatrix::from_row_slice(
            6,
            6,
            &[
                axial,
                0.0,
                0.0,
                -axial,
                0.0,
                0.0,
                0.0,
                12.0 * bending,
                6.0 * l * bending,
                0.0,
                -12.0 * bending,
                6.0 * l * bending,
                0.0,
                6.0 * l * bending,
                4.0 * l * l * bending,
                0.0,
                -6.0 * l * bending,
                2.0 * l * l * bending,
                -axial,
                0.0,
                0.0,
                axial,
                0.0,
                0.0,
                0.0,
                -12.0 * bending,
                -6.0 * l * bending,
                0.0,
                12.0 * bending,
                -6.0 * l * bending,
                0.0,
                6.0 * l * bending,
                2.0 * l * l * bending,
                0.0,
                -6.0 * l * bending,
                4.0 * l * l * bending,
            ],
        ))
    }

    pub fn calculate_stiffness_matrix_3d(
        &self,
        material_map: &HashMap<u32, &Material>,
        section_map: &HashMap<u32, &Section>,
    ) -> Option<DMatrix<f64>> {
        let section_id = self.section.unwrap_or_else(|| {
            panic!(
                "Member {} ({:?}) missing section id required to compute axial force.",
                self.id, self.member_type
            )
        });

        let section = section_map.get(&section_id)?;
        let material = material_map.get(&section.material)?;

        let e = material.e_mod;
        let g = material.g_mod;
        let a = section.area;
        let i_y = section.i_y;
        let i_z = section.i_z;
        let j = section.j;
        let i_w = section.i_w.unwrap_or(0.0);
        let l = self.calculate_length();
        let l2 = l * l;
        let l3 = l2 * l;

        let mut k = DMatrix::<f64>::zeros(ELEMENT_DOFS, ELEMENT_DOFS);

        // Helper to set symmetric pair
        let set_sym = |m: &mut DMatrix<f64>, i: usize, j: usize, v: f64| {
            m[(i, j)] = v;
            m[(j, i)] = v;
        };

        // --- 1. Axial block (DOFs 0, 7) ---
        let axial = e * a / l;
        k[(0, 0)] = axial;
        k[(7, 7)] = axial;
        set_sym(&mut k, 0, 7, -axial);

        // --- 2. Y-bending block with Timoshenko shear (DOFs 1, 5, 8, 12) ---
        let phi_z = if let Some(a_sz) = section.a_sz {
            12.0 * e * i_z / (g * a_sz * l2)
        } else {
            0.0
        };
        let denom_z = 1.0 + phi_z;
        k[(1, 1)] = 12.0 * e * i_z / (l3 * denom_z);
        set_sym(&mut k, 1, 5, 6.0 * e * i_z / (l2 * denom_z));
        set_sym(&mut k, 1, 8, -12.0 * e * i_z / (l3 * denom_z));
        set_sym(&mut k, 1, 12, 6.0 * e * i_z / (l2 * denom_z));
        k[(5, 5)] = (4.0 + phi_z) * e * i_z / (l * denom_z);
        set_sym(&mut k, 5, 8, -6.0 * e * i_z / (l2 * denom_z));
        set_sym(&mut k, 5, 12, (2.0 - phi_z) * e * i_z / (l * denom_z));
        k[(8, 8)] = 12.0 * e * i_z / (l3 * denom_z);
        set_sym(&mut k, 8, 12, -6.0 * e * i_z / (l2 * denom_z));
        k[(12, 12)] = (4.0 + phi_z) * e * i_z / (l * denom_z);

        // --- 3. Z-bending block with Timoshenko shear (DOFs 2, 4, 9, 11) ---
        let phi_y = if let Some(a_sy) = section.a_sy {
            12.0 * e * i_y / (g * a_sy * l2)
        } else {
            0.0
        };
        let denom_y = 1.0 + phi_y;
        k[(2, 2)] = 12.0 * e * i_y / (l3 * denom_y);
        set_sym(&mut k, 2, 4, -6.0 * e * i_y / (l2 * denom_y));
        set_sym(&mut k, 2, 9, -12.0 * e * i_y / (l3 * denom_y));
        set_sym(&mut k, 2, 11, -6.0 * e * i_y / (l2 * denom_y));
        k[(4, 4)] = (4.0 + phi_y) * e * i_y / (l * denom_y);
        set_sym(&mut k, 4, 9, 6.0 * e * i_y / (l2 * denom_y));
        set_sym(&mut k, 4, 11, (2.0 - phi_y) * e * i_y / (l * denom_y));
        k[(9, 9)] = 12.0 * e * i_y / (l3 * denom_y);
        set_sym(&mut k, 9, 11, 6.0 * e * i_y / (l2 * denom_y));
        k[(11, 11)] = (4.0 + phi_y) * e * i_y / (l * denom_y);

        // --- 4. Torsion-Warping block (DOFs 3, 6, 10, 13) ---
        k[(3, 3)] = g * j / l + 12.0 * e * i_w / l3;
        set_sym(&mut k, 3, 6, 6.0 * e * i_w / l2);
        set_sym(&mut k, 3, 10, -(g * j / l + 12.0 * e * i_w / l3));
        set_sym(&mut k, 3, 13, 6.0 * e * i_w / l2);
        k[(6, 6)] = 4.0 * e * i_w / l;
        set_sym(&mut k, 6, 10, -6.0 * e * i_w / l2);
        set_sym(&mut k, 6, 13, 2.0 * e * i_w / l);
        k[(10, 10)] = g * j / l + 12.0 * e * i_w / l3;
        set_sym(&mut k, 10, 13, -6.0 * e * i_w / l2);
        k[(13, 13)] = 4.0 * e * i_w / l;

        // Stabilize warping DOFs when no warping stiffness exists to prevent singular matrix
        if i_w.abs() < 1e-30 {
            let stab = 1e-10 * e * a / l;
            k[(6, 6)] += stab;
            k[(13, 13)] += stab;
        }

        Some(k)
    }

    pub fn calculate_truss_stiffness_matrix_3d(
        &self,
        material_map: &std::collections::HashMap<u32, &Material>,
        section_map: &std::collections::HashMap<u32, &Section>,
    ) -> Option<nalgebra::DMatrix<f64>> {
        let section_id = self.section.unwrap_or_else(|| {
            panic!(
                "Member {} ({:?}) missing section id required to compute axial force.",
                self.id, self.member_type
            )
        });

        let section: &&Section = section_map.get(&section_id)?;
        let material: &&Material = material_map.get(&section.material)?;
        let e_modulus: f64 = material.e_mod;
        let area: f64 = section.area;
        let length: f64 = self.calculate_length();

        if length <= 0.0 {
            return None;
        }

        let axial: f64 = e_modulus * area / length;

        let mut k_local = nalgebra::DMatrix::<f64>::zeros(ELEMENT_DOFS, ELEMENT_DOFS);
        // Local translational x of start and end nodes (indices 0 and DOFS_PER_NODE) couple axially
        k_local[(0, 0)] = axial;
        k_local[(0, DOFS_PER_NODE)] = -axial;
        k_local[(DOFS_PER_NODE, 0)] = -axial;
        k_local[(DOFS_PER_NODE, DOFS_PER_NODE)] = axial;

        // Stabilize all non-axial DOFs to prevent singular global matrix
        let stab = 1e-10 * axial;
        for i in 1..DOFS_PER_NODE {
            k_local[(i, i)] += stab;
            k_local[(i + DOFS_PER_NODE, i + DOFS_PER_NODE)] += stab;
        }

        let t = self.calculate_transformation_matrix_3d();
        let k_global = t.transpose() * k_local * t;
        Some(k_global)
    }

    pub fn calculate_transformation_matrix_2d(&self) -> DMatrix<f64> {
        let dx = self.end_node.X - self.start_node.X;
        let dy = self.end_node.Y - self.start_node.Y;
        let l = (dx.powi(2) + dy.powi(2)).sqrt();

        let c = dx / l;
        let s = dy / l;

        DMatrix::from_row_slice(
            6,
            6,
            &[
                c, s, 0.0, 0.0, 0.0, 0.0, -s, c, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0,
                0.0, 0.0, 0.0, c, s, 0.0, 0.0, 0.0, 0.0, -s, c, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0,
            ],
        )
    }

    /// Build the 14×14 transformation matrix from undeformed node positions.
    pub fn calculate_transformation_matrix_3d(&self) -> DMatrix<f64> {
        let start = Vector3::new(self.start_node.X, self.start_node.Y, self.start_node.Z);
        let end = Vector3::new(self.end_node.X, self.end_node.Y, self.end_node.Z);
        self.calculate_transformation_matrix_3d_from_positions(&start, &end)
    }

    /// Build the 14×14 transformation matrix from explicit (e.g. deformed) positions.
    pub fn calculate_transformation_matrix_3d_from_positions(
        &self,
        start_pos: &Vector3<f64>,
        end_pos: &Vector3<f64>,
    ) -> DMatrix<f64> {
        let diff = end_pos - start_pos;
        let length = diff.norm();
        if length < 1e-12 {
            panic!("Start and end nodes are the same or too close to define a direction.");
        }
        let local_x = diff / length;

        let mut reference_vector = Vector3::new(0.0, 1.0, 0.0);
        let dot = local_x.dot(&reference_vector);
        if dot.abs() > 1.0 - 1e-6 {
            reference_vector = Vector3::new(0.0, 0.0, 1.0);
        }

        // Build right-handed frame
        let mut local_z = local_x.cross(&reference_vector);
        let norm_z = local_z.norm();
        if norm_z < 1e-12 {
            reference_vector = Vector3::new(1.0, 0.0, 0.0);
            local_z = local_x.cross(&reference_vector);
            if local_z.norm() < 1e-12 {
                panic!("Cannot define a valid local_z axis.");
            }
        }
        let local_z = local_z.normalize();
        let local_y = local_z.cross(&local_x).normalize();

        // Apply roll about local_x by rotation_angle
        let mut y_axis = local_y;
        let mut z_axis = local_z;
        let phi = self.rotation_angle;
        if phi.abs() > 0.0 {
            let c = phi.cos();
            let s = phi.sin();
            let y_rot = y_axis * c + z_axis * s;
            let z_rot = -y_axis * s + z_axis * c;
            y_axis = y_rot;
            z_axis = z_rot;
        }

        // Rotation R with rows [x; y; z] (global → local)
        let r = DMatrix::from_row_slice(
            3,
            3,
            &[
                local_x.x, local_x.y, local_x.z, y_axis.x, y_axis.y, y_axis.z, z_axis.x, z_axis.y,
                z_axis.z,
            ],
        );

        // Block-diagonal T = diag(R, R, 1, R, R, 1) for 14×14
        let mut transformation = DMatrix::<f64>::zeros(ELEMENT_DOFS, ELEMENT_DOFS);
        for node in 0..2 {
            let base = node * DOFS_PER_NODE;
            for i in 0..3 {
                for j in 0..3 {
                    transformation[(base + i, base + j)] = r[(i, j)];
                }
            }
            for i in 0..3 {
                for j in 0..3 {
                    transformation[(base + 3 + i, base + 3 + j)] = r[(i, j)];
                }
            }
            transformation[(base + 6, base + 6)] = 1.0;
        }
        transformation
    }

    /// Compute deformed node positions from the global displacement vector.
    /// Returns (start_deformed, end_deformed).
    pub fn deformed_positions(&self, global_displacement: &DMatrix<f64>) -> (Vector3<f64>, Vector3<f64>) {
        let si = (self.start_node.id as usize - 1) * DOFS_PER_NODE;
        let ei = (self.end_node.id as usize - 1) * DOFS_PER_NODE;
        let start = Vector3::new(
            self.start_node.X + global_displacement[(si, 0)],
            self.start_node.Y + global_displacement[(si + 1, 0)],
            self.start_node.Z + global_displacement[(si + 2, 0)],
        );
        let end = Vector3::new(
            self.end_node.X + global_displacement[(ei, 0)],
            self.end_node.Y + global_displacement[(ei + 1, 0)],
            self.end_node.Z + global_displacement[(ei + 2, 0)],
        );
        (start, end)
    }

    /// Corotational deformation extraction: decomposes the 14-DOF element
    /// displacement into a deformational part (rigid body motion removed)
    /// expressed in the deformed local frame.
    ///
    /// Returns `(d_local, T_def)` where:
    ///  - `d_local` is a 14×1 vector of deformational displacements in the
    ///    deformed local frame (translations at start = 0, extension at end,
    ///    rotations = total minus rigid, warping unchanged).
    ///  - `T_def` is the 14×14 transformation matrix built from deformed positions.
    pub fn extract_corotational_deformations(
        &self,
        u_member_global: &DVector<f64>,
    ) -> (DVector<f64>, DMatrix<f64>) {
        // 1) Original and deformed positions
        let p1_orig = Vector3::new(self.start_node.X, self.start_node.Y, self.start_node.Z);
        let p2_orig = Vector3::new(self.end_node.X, self.end_node.Y, self.end_node.Z);
        let l_orig = (p2_orig - p1_orig).norm();

        let p1_def = Vector3::new(
            p1_orig.x + u_member_global[0],
            p1_orig.y + u_member_global[1],
            p1_orig.z + u_member_global[2],
        );
        let p2_def = Vector3::new(
            p2_orig.x + u_member_global[DOFS_PER_NODE],
            p2_orig.y + u_member_global[DOFS_PER_NODE + 1],
            p2_orig.z + u_member_global[DOFS_PER_NODE + 2],
        );
        let l_def = (p2_def - p1_def).norm();

        // 2) R_orig from the standard transformation matrix
        let t_orig_full = self.calculate_transformation_matrix_3d();
        let r_orig = Matrix3::new(
            t_orig_full[(0, 0)], t_orig_full[(0, 1)], t_orig_full[(0, 2)],
            t_orig_full[(1, 0)], t_orig_full[(1, 1)], t_orig_full[(1, 2)],
            t_orig_full[(2, 0)], t_orig_full[(2, 1)], t_orig_full[(2, 2)],
        );

        // 3) Build R_def by rotating R_orig so its x-axis aligns with the deformed chord.
        //    This avoids the reference-vector instability in calculate_transformation_matrix_3d_from_positions.
        let x_orig = (p2_orig - p1_orig) / l_orig;
        let x_def = (p2_def - p1_def) / l_def;

        // Rotation from x_orig to x_def via Rodrigues' formula
        let cross = x_orig.cross(&x_def);
        let sin_a = cross.norm();
        let cos_a = x_orig.dot(&x_def);

        let r_chord: Matrix3<f64>;
        if sin_a > 1e-12 {
            // General rotation
            let k = cross / sin_a; // unit rotation axis
            let kx = Matrix3::new(
                0.0, -k.z, k.y,
                k.z, 0.0, -k.x,
                -k.y, k.x, 0.0,
            );
            r_chord = Matrix3::identity() + kx * sin_a + kx * kx * (1.0 - cos_a);
        } else if cos_a > 0.0 {
            // x_orig ≈ x_def (no rotation needed)
            r_chord = Matrix3::identity();
        } else {
            // x_orig ≈ -x_def (180° flip): pick any axis perpendicular to x_orig
            let perp = if x_orig.x.abs() < 0.9 {
                Vector3::new(1.0, 0.0, 0.0).cross(&x_orig).normalize()
            } else {
                Vector3::new(0.0, 1.0, 0.0).cross(&x_orig).normalize()
            };
            // 180° rotation about perp: R = 2*perp*perp^T - I
            r_chord = 2.0 * perp * perp.transpose() - Matrix3::identity();
        }

        // R_def = R_orig * R_chord^T  (R_chord rotates global vectors, R_orig maps global→local)
        // Actually: R_chord maps x_orig → x_def in global coords.
        // R_orig has rows [x_orig_local, y_orig_local, z_orig_local] in global coords.
        // The deformed local frame has its x-axis along x_def, and transverse axes
        // are the original transverse axes rotated by R_chord:
        //   x_def_local = R_chord * x_orig = x_def  ✓
        //   y_def_local = R_chord * y_orig
        //   z_def_local = R_chord * z_orig
        // R_def maps global → deformed local:
        //   R_def * v = R_orig * R_chord^T * v
        // because R_chord^T rotates from deformed global back to original global
        let r_def = r_orig * r_chord.transpose();

        // Build 14×14 T_def from r_def
        let mut t_def_full = DMatrix::<f64>::zeros(ELEMENT_DOFS, ELEMENT_DOFS);
        for node in 0..2 {
            let base = node * DOFS_PER_NODE;
            for i in 0..3 {
                for j in 0..3 {
                    t_def_full[(base + i, base + j)] = r_def[(i, j)];
                    t_def_full[(base + 3 + i, base + 3 + j)] = r_def[(i, j)];
                }
            }
            t_def_full[(base + 6, base + 6)] = 1.0;
        }

        // 5) Deformational rotations at each node (global, then to deformed local)
        let theta1_global = Vector3::new(
            u_member_global[3],
            u_member_global[4],
            u_member_global[5],
        );
        let theta2_global = Vector3::new(
            u_member_global[DOFS_PER_NODE + 3],
            u_member_global[DOFS_PER_NODE + 4],
            u_member_global[DOFS_PER_NODE + 5],
        );

        // 5) Deformational rotations: multiplicative SO(3) composition.
        //    For each node: remove the rigid chord rotation (R_chord) from the total
        //    nodal rotation to isolate the deformational part. This is correct at any
        //    rotation magnitude; additive subtraction (θ − ω) breaks above ~15°.
        let r_node1 = rotation_matrix_from_vector(&theta1_global);
        let r_deform1 = r_chord.transpose() * r_node1;
        let theta1_deform_global = rotation_vector_from_matrix(&r_deform1);

        let r_node2 = rotation_matrix_from_vector(&theta2_global);
        let r_deform2 = r_chord.transpose() * r_node2;
        let theta2_deform_global = rotation_vector_from_matrix(&r_deform2);

        let theta1_deform_local = r_def * theta1_deform_global;
        let theta2_deform_local = r_def * theta2_deform_global;

        // 6) Build 14-DOF deformational displacement vector in deformed local frame
        let mut d_local = DVector::<f64>::zeros(ELEMENT_DOFS);
        // Start node: translations = 0 (corotational frame origin)
        d_local[3] = theta1_deform_local.x;
        d_local[4] = theta1_deform_local.y;
        d_local[5] = theta1_deform_local.z;
        d_local[6] = u_member_global[6]; // warping DOF (scalar)

        // End node axial DOF: change in chord length.
        //
        // In the corotational framework the axial deformation is simply
        // l_def − l_orig.  This includes the geometric "bowing" contribution
        // from beam curvature, which is physically real: a bent beam is shorter
        // than its chord.  The tangent stiffness K_corot already accounts for
        // this through the K_geo term, so using the raw chord extension keeps
        // the internal forces consistent with the tangent — essential for
        // Newton convergence in the load-incremental corotational NR.
        d_local[DOFS_PER_NODE] = l_def - l_orig;

        // d_local[DOFS_PER_NODE+1..DOFS_PER_NODE+3] = 0
        d_local[DOFS_PER_NODE + 3] = theta2_deform_local.x;
        d_local[DOFS_PER_NODE + 4] = theta2_deform_local.y;
        d_local[DOFS_PER_NODE + 5] = theta2_deform_local.z;
        d_local[DOFS_PER_NODE + 6] = u_member_global[DOFS_PER_NODE + 6]; // warping DOF

        (d_local, t_def_full)
    }

    /// Build the deformed 14×14 transformation matrix by rotating the original
    /// frame so its x-axis aligns with the deformed chord direction.
    /// This avoids the reference-vector instability of `calculate_transformation_matrix_3d_from_positions`.
    pub fn calculate_transformation_matrix_3d_corotational(
        &self,
        p1_def: &Vector3<f64>,
        p2_def: &Vector3<f64>,
    ) -> DMatrix<f64> {
        let p1_orig = Vector3::new(self.start_node.X, self.start_node.Y, self.start_node.Z);
        let p2_orig = Vector3::new(self.end_node.X, self.end_node.Y, self.end_node.Z);
        let l_orig = (p2_orig - p1_orig).norm();
        let l_def = (p2_def - p1_def).norm();

        let x_orig = (p2_orig - p1_orig) / l_orig;
        let x_def = (p2_def - p1_def) / l_def;

        let t_orig_full = self.calculate_transformation_matrix_3d();
        let r_orig = Matrix3::new(
            t_orig_full[(0, 0)], t_orig_full[(0, 1)], t_orig_full[(0, 2)],
            t_orig_full[(1, 0)], t_orig_full[(1, 1)], t_orig_full[(1, 2)],
            t_orig_full[(2, 0)], t_orig_full[(2, 1)], t_orig_full[(2, 2)],
        );

        // Rodrigues' rotation from x_orig to x_def
        let cross = x_orig.cross(&x_def);
        let sin_a = cross.norm();
        let cos_a = x_orig.dot(&x_def);

        let r_chord: Matrix3<f64>;
        if sin_a > 1e-12 {
            let k = cross / sin_a;
            let kx = Matrix3::new(
                0.0, -k.z, k.y,
                k.z, 0.0, -k.x,
                -k.y, k.x, 0.0,
            );
            r_chord = Matrix3::identity() + kx * sin_a + kx * kx * (1.0 - cos_a);
        } else if cos_a > 0.0 {
            r_chord = Matrix3::identity();
        } else {
            let perp = if x_orig.x.abs() < 0.9 {
                Vector3::new(1.0, 0.0, 0.0).cross(&x_orig).normalize()
            } else {
                Vector3::new(0.0, 1.0, 0.0).cross(&x_orig).normalize()
            };
            r_chord = 2.0 * perp * perp.transpose() - Matrix3::identity();
        }

        let r_def = r_orig * r_chord.transpose();

        let mut t_def = DMatrix::<f64>::zeros(ELEMENT_DOFS, ELEMENT_DOFS);
        for node in 0..2 {
            let base = node * DOFS_PER_NODE;
            for i in 0..3 {
                for j in 0..3 {
                    t_def[(base + i, base + j)] = r_def[(i, j)];
                    t_def[(base + 3 + i, base + 3 + j)] = r_def[(i, j)];
                }
            }
            t_def[(base + 6, base + 6)] = 1.0;
        }
        t_def
    }

    pub fn calculate_axial_force_3d(
        &self,
        global_displacement: &DMatrix<f64>,
        material_map: &HashMap<u32, &Material>,
        section_map: &HashMap<u32, &Section>,
    ) -> f64 {
        self.calculate_axial_force_3d_impl(global_displacement, material_map, section_map, false)
    }

    /// Compute axial force; when `use_deformed_geometry` is true, the transformation matrix
    /// is built from deformed node positions (corotational update).
    pub fn calculate_axial_force_3d_impl(
        &self,
        global_displacement: &DMatrix<f64>,
        material_map: &HashMap<u32, &Material>,
        section_map: &HashMap<u32, &Section>,
        use_deformed_geometry: bool,
    ) -> f64 {
        // 1) Look up E and A
        let section_id = self.section.unwrap_or_else(|| {
            panic!(
                "Member {} ({:?}) missing section id required to compute axial force.",
                self.id, self.member_type
            )
        });
        let section: &&Section = section_map.get(&section_id).unwrap_or_else(|| {
            panic!(
                "Missing section data: member_id={}, section_id={}",
                self.id, section_id
            )
        });

        let material = material_map.get(&section.material).unwrap_or_else(|| {
            panic!(
                "Missing material for section: member_id={}, section_id={}, material_id={}",
                self.id, section_id, section.material
            )
        });
        let e_mod = material.e_mod;
        let area = section.area;

        // 2) Length and transformation
        let length = self.calculate_length();
        let t = if use_deformed_geometry {
            let (sp, ep) = self.deformed_positions(global_displacement);
            self.calculate_transformation_matrix_3d_from_positions(&sp, &ep)
        } else {
            self.calculate_transformation_matrix_3d()
        };

        // 3) Extract the ELEMENT_DOFS global DOFs for this member
        let start_index = (self.start_node.id as usize - 1) * DOFS_PER_NODE;
        let end_index = (self.end_node.id as usize - 1) * DOFS_PER_NODE;
        let mut u_elem = DMatrix::<f64>::zeros(ELEMENT_DOFS, 1);
        for i in 0..DOFS_PER_NODE {
            u_elem[(i, 0)] = global_displacement[(start_index + i, 0)];
        }
        for i in 0..DOFS_PER_NODE {
            u_elem[(i + DOFS_PER_NODE, 0)] = global_displacement[(end_index + i, 0)];
        }

        // 4) Transform to local coords: u_local = T * u_elem
        let u_local = &t * &u_elem;

        // 5) Axial extension = u_local[x_end] - u_local[x_start]
        let extension = u_local[(DOFS_PER_NODE, 0)] - u_local[(0, 0)];

        // 6) Axial force = (E·A/L) · extension
        e_mod * area / length * extension
    }

    /// Build the local geometric stiffness matrix for this member, given its axial force.
    pub fn calculate_geometric_stiffness_matrix_3d(
        &self,
        axial_force: f64,
        wagner_coeff: f64,
    ) -> DMatrix<f64> {
        let l = self.calculate_length();
        let p = axial_force;
        let p_over_l = p / l;
        let p_times_l = p * l;

        let mut k_geo = DMatrix::<f64>::zeros(ELEMENT_DOFS, ELEMENT_DOFS);

        // --- Axial terms (DOFs 0, 7) ---
        k_geo[(0, 0)] = p_over_l;
        k_geo[(0, 7)] = -p_over_l;
        k_geo[(7, 0)] = -p_over_l;
        k_geo[(7, 7)] = p_over_l;

        // --- Bending about local z (deflection in y) ---
        // DOFs: 1, 5, 8, 12
        // Standard consistent geometric stiffness (Przemieniecki / McGuire):
        //   K_geo = P/(30L) * [36, 3L, -36, 3L; 3L, 4L², -3L, -L²;
        //                      -36, -3L, 36, -3L; 3L, -L², -3L, 4L²]
        k_geo[(1, 1)] = 6.0 / 5.0 * p_over_l;
        k_geo[(1, 5)] = 1.0 / 10.0 * p;
        k_geo[(1, 8)] = -6.0 / 5.0 * p_over_l;
        k_geo[(1, 12)] = 1.0 / 10.0 * p;

        k_geo[(5, 1)] = 1.0 / 10.0 * p;
        k_geo[(5, 5)] = 2.0 / 15.0 * p_times_l;
        k_geo[(5, 8)] = -1.0 / 10.0 * p;
        k_geo[(5, 12)] = -1.0 / 30.0 * p_times_l;

        k_geo[(8, 1)] = -6.0 / 5.0 * p_over_l;
        k_geo[(8, 5)] = -1.0 / 10.0 * p;
        k_geo[(8, 8)] = 6.0 / 5.0 * p_over_l;
        k_geo[(8, 12)] = -1.0 / 10.0 * p;

        k_geo[(12, 1)] = 1.0 / 10.0 * p;
        k_geo[(12, 5)] = -1.0 / 30.0 * p_times_l;
        k_geo[(12, 8)] = -1.0 / 10.0 * p;
        k_geo[(12, 12)] = 2.0 / 15.0 * p_times_l;

        // --- Bending about local y (deflection in z) ---
        // DOFs: 2, 4, 9, 11
        k_geo[(2, 2)] = 6.0 / 5.0 * p_over_l;
        k_geo[(2, 4)] = 1.0 / 10.0 * p;
        k_geo[(2, 9)] = -6.0 / 5.0 * p_over_l;
        k_geo[(2, 11)] = 1.0 / 10.0 * p;

        k_geo[(4, 2)] = 1.0 / 10.0 * p;
        k_geo[(4, 4)] = 2.0 / 15.0 * p_times_l;
        k_geo[(4, 9)] = -1.0 / 10.0 * p;
        k_geo[(4, 11)] = -1.0 / 30.0 * p_times_l;

        k_geo[(9, 2)] = -6.0 / 5.0 * p_over_l;
        k_geo[(9, 4)] = -1.0 / 10.0 * p;
        k_geo[(9, 9)] = 6.0 / 5.0 * p_over_l;
        k_geo[(9, 11)] = -1.0 / 10.0 * p;

        k_geo[(11, 2)] = 1.0 / 10.0 * p;
        k_geo[(11, 4)] = -1.0 / 30.0 * p_times_l;
        k_geo[(11, 9)] = -1.0 / 10.0 * p;
        k_geo[(11, 11)] = 2.0 / 15.0 * p_times_l;

        // --- Wagner effect on torsion (DOFs 3, 10) ---
        let ip_s2 = wagner_coeff;
        k_geo[(3, 3)] += p_over_l * ip_s2;
        k_geo[(3, 10)] += -p_over_l * ip_s2;
        k_geo[(10, 3)] += -p_over_l * ip_s2;
        k_geo[(10, 10)] += p_over_l * ip_s2;

        k_geo
    }
}
