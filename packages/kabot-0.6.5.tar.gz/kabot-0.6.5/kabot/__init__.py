"""
kabot - A lightweight AI agent framework
"""

__version__ = "0.6.5"
__logo__ = "kabot"  # Changed from emoji to text for Windows console compatibility
