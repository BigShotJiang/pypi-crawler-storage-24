# eggnog-mapper-fixurl

Fix outdated URLs in [eggnog-mapper](https://github.com/eggnogdb/eggnog-mapper)'s `download_eggnog_data.py`.

## Installation

First, ensure that [eggnog-mapper](https://github.com/eggnogdb/eggnog-mapper) is installed in your environment. Then install the `eggnog-mapper-fixurl` package with pip:

```sh
pip install eggnog-mapper-fixurl
```

## Usage

You can confirm that `download_eggnog_data.py` is detected in your current environment by running:

```sh
which download_eggnog_data.py
```

If it's detected, you can make the fix by simply running

```sh
eggnog-mapper-fixurl
```

This will update the outdated URLs in `download_eggnog_data.py`, after which the script should work correctly.

The fix will also take place if this package is imported in a Python script

```python
import eggnog_mapper_fixurl
```

If you need to specify the location of `download_eggnog_data.py`, there are a few ways to do so:

1. By command line option: `eggnog-mapper-fixurl --pyscript <path/to/download_eggnog_data.py>`
1. By environment variable: `export EGGNOG_MAPPER_FIXURL_PYSCRIPT="<path/to/download_eggnog_data.py>"`
1. By configuration file, add `download_eggnog_data_pysript = "<path/to/download_eggnog_data.py>"` to `~/.eggnog-mapper-fixurl-config.toml`
1. In a Python script:

```python
import eggnog_mapper_fixurl
eggnog_mapper_fixurl.fixurl(
    download_eggnog_data_pysript="<path/to/download_eggnog_data.py>"
)
```
