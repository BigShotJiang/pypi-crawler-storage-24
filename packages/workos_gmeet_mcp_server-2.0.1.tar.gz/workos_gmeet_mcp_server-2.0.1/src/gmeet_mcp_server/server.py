"""
Google Meet & Calendar MCP Server — FastMCP instance with all tools registered.

This is the core server module. Tools are organized by domain
in the tools/ subpackage and registered here.
"""

import logging
import sys

from fastmcp import FastMCP

from gmeet_mcp_server.config import GMeetConfig
from gmeet_mcp_server.tools.events import register_event_tools
from gmeet_mcp_server.tools.meetings import register_meeting_tools
from gmeet_mcp_server.tools.calendars import register_calendar_tools
from gmeet_mcp_server.tools.recordings import register_recording_tools

# Ensure logging goes to stderr (required for stdio MCP transport)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    stream=sys.stderr,
)

logger = logging.getLogger("gmeet_mcp_server")


def create_server() -> FastMCP:
    """Create and configure the Google Meet & Calendar MCP server.

    Validates environment configuration on startup and registers
    all Calendar/Meet/Drive tools with the FastMCP instance.
    """
    config = GMeetConfig()
    config.validate_or_exit()

    app = FastMCP(
        name="gmeet-mcp-server",
        instructions=(
            "MCP server for Google Meet and Calendar operations. "
            "Create meetings with Google Meet links, manage calendar events, "
            "add attendees, browse calendars, and access meeting recordings, "
            "transcripts, and participant data."
        ),
        version="2.0.0",
    )

    # Register all tool groups
    register_event_tools(app, config)
    register_meeting_tools(app, config)
    register_calendar_tools(app, config)
    register_recording_tools(app, config)

    logger.info("Google Meet & Calendar MCP server configured with all tool groups")
    return app
