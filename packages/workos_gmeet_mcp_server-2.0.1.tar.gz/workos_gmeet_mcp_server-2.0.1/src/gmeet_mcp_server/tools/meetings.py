"""Meeting tools — create meetings with Google Meet links and manage attendees."""

from gmeet_mcp_server.client import GMeetClient, CalendarAPIError, CalendarAuthError
from gmeet_mcp_server.config import GMeetConfig


def register_meeting_tools(app, config: GMeetConfig):
    """Register meeting-related tools with the FastMCP app."""

    @app.tool()
    async def gmeet_create_meeting(
        title: str,
        start_time: str,
        duration_minutes: int = 30,
        attendees: str = "",
        description: str = "",
    ) -> dict:
        """Create a Google Calendar event with a Google Meet video conference link.

        This tool creates a calendar event with conferenceData that
        auto-generates a Meet link.

        Args:
            title: Meeting title / event summary.
            start_time: Start time in ISO 8601 format (e.g., '2025-06-20T10:00:00-07:00').
            duration_minutes: Meeting duration in minutes (default 30).
            attendees: Comma-separated email addresses of attendees. Optional.
            description: Optional meeting description or agenda.
        """
        try:
            client = GMeetClient(
                client_id=config.client_id,
                client_secret=config.client_secret,
                refresh_token=config.refresh_token,
            )
            attendee_list = (
                [e.strip() for e in attendees.split(",") if e.strip()]
                if attendees
                else None
            )
            result = client.create_event(
                title=title,
                start_time=start_time,
                duration_minutes=duration_minutes,
                attendees=attendee_list,
                description=description,
                add_meet_link=True,
            )
            return {"success": True, **result}
        except CalendarAuthError as exc:
            return {"error": f"Authentication failed: {exc}"}
        except CalendarAPIError as exc:
            return {"error": f"Calendar API error: {exc}"}
        except Exception as exc:
            return {"error": f"Unexpected error: {exc}"}

    @app.tool()
    async def gmeet_add_attendee(event_id: str, email: str) -> dict:
        """Add an attendee to an existing calendar event.

        Adds the specified email to the event's attendee list without
        removing existing attendees.

        Args:
            event_id: Google Calendar event ID.
            email: Email address of the attendee to add.
        """
        try:
            client = GMeetClient(
                client_id=config.client_id,
                client_secret=config.client_secret,
                refresh_token=config.refresh_token,
            )
            result = client.add_attendee(event_id=event_id, email=email)
            return {"success": True, "action": "attendee_added", **result}
        except CalendarAuthError as exc:
            return {"error": f"Authentication failed: {exc}"}
        except CalendarAPIError as exc:
            return {"error": f"Calendar API error: {exc}"}
        except Exception as exc:
            return {"error": f"Unexpected error: {exc}"}
