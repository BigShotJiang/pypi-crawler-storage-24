"""Calendar browsing tools — list available calendars."""

from gmeet_mcp_server.client import GMeetClient, CalendarAPIError, CalendarAuthError
from gmeet_mcp_server.config import GMeetConfig


def register_calendar_tools(app, config: GMeetConfig):
    """Register calendar browsing tools with the FastMCP app."""

    @app.tool()
    async def gmeet_list_calendars() -> dict:
        """List all Google Calendars accessible to the authenticated user.

        Returns calendar IDs, names, descriptions, and access roles.
        Use the calendar_id from results to target specific calendars
        in other tools.
        """
        try:
            client = GMeetClient(
                client_id=config.client_id,
                client_secret=config.client_secret,
                refresh_token=config.refresh_token,
            )
            calendars = client.list_calendars()
            return {"success": True, "count": len(calendars), "calendars": calendars}
        except CalendarAuthError as exc:
            return {"error": f"Authentication failed: {exc}"}
        except CalendarAPIError as exc:
            return {"error": f"Calendar API error: {exc}"}
        except Exception as exc:
            return {"error": f"Unexpected error: {exc}"}
