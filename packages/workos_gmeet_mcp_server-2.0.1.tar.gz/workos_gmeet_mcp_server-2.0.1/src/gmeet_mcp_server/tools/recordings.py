"""Recording & transcript tools — conference records, recordings, transcripts, participants."""

from gmeet_mcp_server.client import GMeetClient, CalendarAPIError, CalendarAuthError
from gmeet_mcp_server.config import GMeetConfig


def register_recording_tools(app, config: GMeetConfig):
    """Register Meet recording/transcript tools with the FastMCP app."""

    @app.tool()
    async def gmeet_list_conference_records(max_results: int = 25) -> dict:
        """List past Google Meet conference records with start/end times.

        Returns a list of conference records for meetings the authenticated
        user has organized or participated in.

        Args:
            max_results: Maximum number of records to return (default 25).
        """
        try:
            client = GMeetClient(
                client_id=config.client_id,
                client_secret=config.client_secret,
                refresh_token=config.refresh_token,
            )
            records = await client.list_conference_records(max_results)
            return {"success": True, "count": len(records), "records": records}
        except CalendarAuthError as exc:
            return {"error": f"Authentication failed: {exc}"}
        except CalendarAPIError as exc:
            return {"error": f"Meet API error: {exc}"}
        except Exception as exc:
            return {"error": f"Unexpected error: {exc}"}

    @app.tool()
    async def gmeet_get_meeting_participants(conference_record: str) -> dict:
        """Get participant details for a specific meeting.

        Returns the list of participants who joined a particular conference,
        including signed-in users, anonymous users, and phone users.

        Args:
            conference_record: Conference record name (e.g., "conferenceRecords/abc123").
        """
        try:
            client = GMeetClient(
                client_id=config.client_id,
                client_secret=config.client_secret,
                refresh_token=config.refresh_token,
            )
            participants = await client.get_conference_participants(conference_record)
            return {"success": True, "count": len(participants), "participants": participants}
        except CalendarAuthError as exc:
            return {"error": f"Authentication failed: {exc}"}
        except CalendarAPIError as exc:
            return {"error": f"Meet API error: {exc}"}
        except Exception as exc:
            return {"error": f"Unexpected error: {exc}"}

    @app.tool()
    async def gmeet_list_recordings(conference_record: str) -> dict:
        """List recordings for a specific meeting.

        Returns recording metadata including state, timestamps, and
        Google Drive destination info for downloading.

        Args:
            conference_record: Conference record name (e.g., "conferenceRecords/abc123").
        """
        try:
            client = GMeetClient(
                client_id=config.client_id,
                client_secret=config.client_secret,
                refresh_token=config.refresh_token,
            )
            recordings = await client.list_recordings(conference_record)
            return {"success": True, "count": len(recordings), "recordings": recordings}
        except CalendarAuthError as exc:
            return {"error": f"Authentication failed: {exc}"}
        except CalendarAPIError as exc:
            return {"error": f"Meet API error: {exc}"}
        except Exception as exc:
            return {"error": f"Unexpected error: {exc}"}

    @app.tool()
    async def gmeet_list_transcripts(conference_record: str) -> dict:
        """List transcripts for a specific meeting.

        Returns transcript metadata including state, timestamps, and
        Google Docs destination info for reading the transcript.

        Args:
            conference_record: Conference record name (e.g., "conferenceRecords/abc123").
        """
        try:
            client = GMeetClient(
                client_id=config.client_id,
                client_secret=config.client_secret,
                refresh_token=config.refresh_token,
            )
            transcripts = await client.list_transcripts(conference_record)
            return {"success": True, "count": len(transcripts), "transcripts": transcripts}
        except CalendarAuthError as exc:
            return {"error": f"Authentication failed: {exc}"}
        except CalendarAPIError as exc:
            return {"error": f"Meet API error: {exc}"}
        except Exception as exc:
            return {"error": f"Unexpected error: {exc}"}

    @app.tool()
    async def gmeet_download_recording(file_id: str) -> dict:
        """Get download information for a meeting recording from Google Drive.

        Returns file metadata including name, size, MIME type, and download links.
        Use the file_id from the driveDestination field in recording metadata.

        Args:
            file_id: The Google Drive file ID of the recording.
        """
        try:
            client = GMeetClient(
                client_id=config.client_id,
                client_secret=config.client_secret,
                refresh_token=config.refresh_token,
            )
            info = await client.download_recording_info(file_id)
            return {"success": True, "file": info}
        except CalendarAuthError as exc:
            return {"error": f"Authentication failed: {exc}"}
        except CalendarAPIError as exc:
            return {"error": f"Drive API error: {exc}"}
        except Exception as exc:
            return {"error": f"Unexpected error: {exc}"}

    @app.tool()
    async def gmeet_get_transcript_content(document_id: str) -> dict:
        """Get the text content of a meeting transcript.

        Exports the transcript from Google Docs as plain text.
        Use the document_id from the docsDestination field in transcript metadata.

        Args:
            document_id: The Google Docs document ID of the transcript.
        """
        try:
            client = GMeetClient(
                client_id=config.client_id,
                client_secret=config.client_secret,
                refresh_token=config.refresh_token,
            )
            content = await client.get_transcript_content(document_id)
            return {"success": True, "content": content}
        except CalendarAuthError as exc:
            return {"error": f"Authentication failed: {exc}"}
        except CalendarAPIError as exc:
            return {"error": f"Drive API error: {exc}"}
        except Exception as exc:
            return {"error": f"Unexpected error: {exc}"}
