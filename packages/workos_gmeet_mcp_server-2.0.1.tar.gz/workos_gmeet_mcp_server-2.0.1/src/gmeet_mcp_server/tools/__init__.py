"""Google Meet & Calendar MCP Server tools — organized by domain."""
