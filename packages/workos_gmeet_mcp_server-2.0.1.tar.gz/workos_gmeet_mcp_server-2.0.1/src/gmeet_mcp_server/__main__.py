"""Allow running as: python -m gmeet_mcp_server"""
from gmeet_mcp_server import main

main()
