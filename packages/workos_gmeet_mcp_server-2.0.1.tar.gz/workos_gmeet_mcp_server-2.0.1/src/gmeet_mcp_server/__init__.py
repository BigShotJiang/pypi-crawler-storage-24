"""
Google Meet & Calendar MCP Server — Model Context Protocol server for
Google Calendar, Meet, and Drive operations.

An independent, generalized MCP server that can connect to any AI agent
supporting the Model Context Protocol. Creates meetings with Google Meet
links, manages calendar events, coordinates schedules, and accesses
meeting recordings, transcripts, and participant data.

Quick start:
    pip install workos-gmeet-mcp-server
    GOOGLE_CLIENT_ID=your-client-id \\
    GOOGLE_CLIENT_SECRET=your-client-secret \\
    GOOGLE_REFRESH_TOKEN=your-refresh-token \\
    gmeet-mcp-server

Or run as a module:
    python -m gmeet_mcp_server
"""

__version__ = "2.0.0"

from gmeet_mcp_server.server import create_server


def main():
    """Entry point for the gmeet-mcp-server CLI command."""
    server = create_server()
    server.run()


__all__ = ["main", "create_server", "__version__"]
