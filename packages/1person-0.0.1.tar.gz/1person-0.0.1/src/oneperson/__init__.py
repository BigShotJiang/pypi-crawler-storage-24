"""1Person — AI-native development platform"""
