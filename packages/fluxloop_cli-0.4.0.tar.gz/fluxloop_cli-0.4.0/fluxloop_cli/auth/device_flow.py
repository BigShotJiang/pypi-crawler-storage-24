"""Device code authentication flow."""

from __future__ import annotations

import os
import sys
import time
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Optional

import httpx

from .token_store import AuthToken, load_token, save_token


@dataclass
class DeviceFlowSession:
    device_code: str
    user_code: str
    verification_url: str
    expires_in_sec: int
    interval_sec: int


def is_agent_environment() -> bool:
    if not sys.stdout.isatty():
        return True
    if os.getenv("CLAUDE_CODE") or os.getenv("CURSOR_AGENT"):
        return True
    if os.getenv("CI") or os.getenv("GITHUB_ACTIONS"):
        return True
    return False


def start_device_flow(
    api_url: str,
    device_name: str | None = None,
) -> DeviceFlowSession:
    url = api_url.rstrip("/") + "/api/cli-connect/start"
    payload: dict = {}
    if device_name:
        payload["device_name"] = device_name

    with httpx.Client(timeout=10.0) as client:
        resp = client.post(url, json=payload)
        resp.raise_for_status()
        data = resp.json()

    return DeviceFlowSession(
        device_code=data["device_code"],
        user_code=data["user_code"],
        verification_url=data["verification_url"],
        expires_in_sec=data.get("expires_in_sec", data.get("expires_in", 600)),
        interval_sec=data.get("interval_sec", data.get("interval", 5)),
    )


def poll_for_approval(
    api_url: str,
    device_code: str,
    interval_sec: int = 5,
    timeout_sec: int = 600,
) -> AuthToken:
    url = api_url.rstrip("/") + "/api/cli-connect/complete"
    start_time = time.time()

    with httpx.Client(timeout=10.0) as client:
        while True:
            elapsed = time.time() - start_time
            if elapsed > timeout_sec:
                raise TimeoutError("Authentication timeout exceeded")

            resp = client.post(url, json={"device_code": device_code})
            resp.raise_for_status()
            data = resp.json()

            status = data.get("status")
            if status == "pending":
                time.sleep(interval_sec)
                continue
            if status == "denied":
                raise ValueError("User denied authentication")
            if status == "expired":
                raise ValueError("Authentication code has expired")
            if status != "approved":
                raise ValueError(f"Authentication error: {status}")

            credential = data.get("credential") or {}
            access_token = credential.get("access_token")
            if not access_token:
                raise ValueError("Authentication response missing access token")

            expires_at = credential.get("expires_at")
            if not expires_at:
                expires_at = (
                    datetime.now(timezone.utc) + timedelta(seconds=3600)
                ).isoformat()

            return AuthToken(
                access_token=access_token,
                refresh_token=credential.get("refresh_token", ""),
                expires_at=expires_at,
                user_id=credential.get("user_id", ""),
                user_email=credential.get("user_email"),
            )


def refresh_access_token(api_url: str, refresh_token: str) -> AuthToken:
    url = api_url.rstrip("/") + "/api/cli-connect/refresh"

    with httpx.Client(timeout=10.0) as client:
        resp = client.post(url, json={"refresh_token": refresh_token})
        resp.raise_for_status()
        data = resp.json()

    credential = data.get("credential") or {}
    access_token = credential.get("access_token")
    if not access_token:
        raise ValueError("Token refresh failed. Please login again.")

    existing_token = load_token()
    user_id = credential.get("user_id") or (existing_token.user_id if existing_token else "")
    user_email = credential.get("user_email") or (
        existing_token.user_email if existing_token else None
    )

    expires_at = credential.get("expires_at")
    if not expires_at:
        expires_at = (datetime.now(timezone.utc) + timedelta(seconds=3600)).isoformat()

    return AuthToken(
        access_token=access_token,
        refresh_token=credential.get("refresh_token", refresh_token),
        expires_at=expires_at,
        user_id=user_id,
        user_email=user_email,
    )


def ensure_valid_token(api_url: str) -> Optional[AuthToken]:
    token = load_token()
    if not token:
        return None
    from .token_store import is_token_expired

    if not is_token_expired(token):
        return token
    try:
        refreshed = refresh_access_token(api_url, token.refresh_token)
        save_token(refreshed)
        return refreshed
    except Exception:
        return None
