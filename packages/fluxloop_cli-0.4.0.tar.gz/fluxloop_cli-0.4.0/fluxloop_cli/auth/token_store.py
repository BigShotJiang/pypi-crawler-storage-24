"""JWT token storage and management."""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Optional

from ..constants import AUTH_DIR, AUTH_FILE, FILE_PERMISSION, PENDING_FILE


@dataclass
class AuthToken:
    access_token: str
    refresh_token: str
    expires_at: str  # ISO 8601
    user_id: str
    user_email: str | None = None

    @classmethod
    def from_dict(cls, data: dict) -> AuthToken:
        return cls(
            access_token=data["access_token"],
            refresh_token=data["refresh_token"],
            expires_at=data["expires_at"],
            user_id=data["user_id"],
            user_email=data.get("user_email"),
        )

    def to_dict(self) -> dict:
        return {
            "access_token": self.access_token,
            "refresh_token": self.refresh_token,
            "expires_at": self.expires_at,
            "user_id": self.user_id,
            "user_email": self.user_email or "",
        }


def save_token(token: AuthToken) -> None:
    AUTH_DIR.mkdir(parents=True, exist_ok=True)
    AUTH_FILE.write_text(json.dumps(token.to_dict(), indent=2))
    AUTH_FILE.chmod(FILE_PERMISSION)


def load_token() -> Optional[AuthToken]:
    if not AUTH_FILE.exists():
        return None
    try:
        data = json.loads(AUTH_FILE.read_text())
        return AuthToken.from_dict(data)
    except (json.JSONDecodeError, KeyError, ValueError):
        return None


def delete_token() -> None:
    if AUTH_FILE.exists():
        AUTH_FILE.unlink()


def is_token_expired(token: AuthToken, buffer_minutes: int = 5) -> bool:
    try:
        expires_at = datetime.fromisoformat(token.expires_at.replace("Z", "+00:00"))
        if expires_at.tzinfo is None:
            expires_at = expires_at.replace(tzinfo=timezone.utc)
        now_with_buffer = datetime.now(timezone.utc) + timedelta(minutes=buffer_minutes)
        return expires_at <= now_with_buffer
    except (ValueError, AttributeError):
        return True


def format_expires_at(expires_at: str) -> str:
    try:
        expires = datetime.fromisoformat(expires_at.replace("Z", "+00:00"))
        if expires.tzinfo is None:
            expires = expires.replace(tzinfo=timezone.utc)
        delta = expires - datetime.now(timezone.utc)
        if delta.total_seconds() <= 0:
            return "expired"
        total_minutes = int(delta.total_seconds() // 60)
        hours, minutes = divmod(total_minutes, 60)
        if hours > 0:
            return f"{hours}h {minutes}m remaining"
        return f"{minutes}m remaining"
    except (ValueError, AttributeError):
        return "unknown"


# Pending login (--no-wait / --resume support)

def save_pending(data: dict) -> None:
    AUTH_DIR.mkdir(parents=True, exist_ok=True)
    PENDING_FILE.write_text(json.dumps(data, indent=2))
    PENDING_FILE.chmod(FILE_PERMISSION)


def load_pending() -> Optional[dict]:
    if not PENDING_FILE.exists():
        return None
    try:
        return json.loads(PENDING_FILE.read_text())
    except (json.JSONDecodeError, ValueError):
        return None


def delete_pending() -> None:
    if PENDING_FILE.exists():
        PENDING_FILE.unlink()
