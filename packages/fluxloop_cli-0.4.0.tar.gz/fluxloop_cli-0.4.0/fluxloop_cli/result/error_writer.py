"""Execution failure writer — generates errors.json from trace records."""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from ..config.schema import SimulationConfig

logger = logging.getLogger(__name__)


def _normalize_error(value: Any) -> dict[str, str | None]:
    if isinstance(value, dict):
        message = value.get("message")
        traceback = value.get("traceback")
        if isinstance(message, str) and message:
            return {
                "message": message,
                "traceback": traceback if isinstance(traceback, str) else None,
            }
    return {"message": "Unknown error", "traceback": None}


class ErrorWriter:
    def write(self, output_dir: Path, config: SimulationConfig) -> None:
        output_dir.mkdir(parents=True, exist_ok=True)
        trace_path = output_dir / "trace_summary.jsonl"
        created_at = datetime.now(timezone.utc).isoformat()
        failures: list[dict[str, Any]] = []

        if trace_path.exists():
            for line in trace_path.read_text().splitlines():
                if not line.strip():
                    continue
                try:
                    record = json.loads(line)
                except json.JSONDecodeError as e:
                    logger.warning(
                        "Skipping malformed trace record in %s: %s",
                        trace_path,
                        e,
                    )
                    continue
                if not isinstance(record, dict):
                    logger.warning("Skipping non-object trace record in %s", trace_path)
                    continue
                if record.get("success", True):
                    continue
                failures.append(
                    {
                        "run_id": str(record.get("run_id", "")),
                        "iteration": int(record.get("iteration", 0)),
                        "persona": record.get("persona"),
                        "input": str(record.get("input", "")),
                        "duration_ms": int(record.get("duration_ms", 0)),
                        "timestamp": str(record.get("timestamp") or created_at),
                        "error": _normalize_error(record.get("error")),
                    }
                )

        payload = {
            "experiment_name": config.name,
            "runner_type": config.runner.type,
            "failure_count": len(failures),
            "created_at": created_at,
            "failures": failures,
        }
        (output_dir / "errors.json").write_text(
            json.dumps(payload, indent=2, ensure_ascii=False)
        )
