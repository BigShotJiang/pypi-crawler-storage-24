"""Trace summary writer — appends JSONL records."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from ..core.executor import RunContext, RunResult
from .metadata import resolve_turn_count


def _serialize_conversation(conversation: list[Any]) -> list[dict[str, str]]:
    serialized: list[dict[str, str]] = []
    for message in conversation:
        if hasattr(message, "model_dump"):
            serialized.append(message.model_dump())
        elif isinstance(message, dict):
            serialized.append(message)
    return serialized


class TraceWriter:
    def __init__(self, output_dir: Path) -> None:
        self.output_dir = output_dir
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self._file = self.output_dir / "trace_summary.jsonl"

    def write(
        self,
        result: RunResult,
        context: RunContext,
        input_text: str,
        *,
        input_metadata: dict | None = None,
        static_results: dict | None = None,
        contract_results: dict | None = None,
    ) -> None:
        input_item_id = None
        if isinstance(input_metadata, dict):
            input_item_id = input_metadata.get("input_item_id") or input_metadata.get("id")

        record: dict = {
            "run_id": result.run_id,
            "iteration": context.iteration,
            "persona": context.persona,
            "input": input_text,
            "input_item_id": input_item_id,
            "input_metadata": input_metadata,
            "output": result.output,
            "success": result.success,
            "duration_ms": result.duration_ms,
            "turn_count": resolve_turn_count(result),
            "termination_reason": result.termination_reason,
            "token_usage": result.token_usage.model_dump() if result.token_usage else None,
            "conversation": _serialize_conversation(result.conversation)
            if result.conversation
            else None,
            "error": result.error.model_dump() if result.error else None,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "tool_calls": result.tool_calls if result.tool_calls else None,
            "skill_metadata": result.metadata.get("skill_metadata"),
            "static_results": static_results,
            "contract_results": contract_results,
        }
        record = {k: v for k, v in record.items() if v is not None}
        with open(self._file, "a") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
