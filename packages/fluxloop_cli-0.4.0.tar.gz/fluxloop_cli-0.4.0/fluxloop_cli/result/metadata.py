"""Shared helpers for extracting run metadata."""

from __future__ import annotations

from ..core.executor import RunResult


def resolve_turn_count(result: RunResult) -> int | None:
    if result.turn_count is not None:
        return result.turn_count
    skill_metadata = result.metadata.get("skill_metadata")
    if isinstance(skill_metadata, dict):
        turn_count = skill_metadata.get("turn_count")
        if isinstance(turn_count, int):
            return turn_count
    return None


def resolve_skill_cost(result: RunResult) -> float | None:
    skill_metadata = result.metadata.get("skill_metadata")
    if isinstance(skill_metadata, dict):
        total_cost = skill_metadata.get("total_cost_usd")
        if isinstance(total_cost, (int, float)):
            return float(total_cost)
    return None
