"""Experiment summary writer — generates summary.json."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from ..config.schema import SimulationConfig
from ..core.executor import RunResult
from .metadata import resolve_skill_cost, resolve_turn_count


class SummaryWriter:
    def write(
        self,
        output_dir: Path,
        config: SimulationConfig,
        results: list[RunResult],
        *,
        contract_summary: dict | None = None,
    ) -> None:
        total = len(results)
        success_count = sum(1 for r in results if r.success)
        failure_count = total - success_count
        total_duration_ms = sum(r.duration_ms for r in results)
        total_tokens = sum(
            r.token_usage.total_tokens for r in results if r.token_usage
        )

        summary: dict = {
            "experiment_name": config.name,
            "runner_type": config.runner.type,
            "total_runs": total,
            "success_count": success_count,
            "failure_count": failure_count,
            "success_rate": round(success_count / total, 4) if total > 0 else 0,
            "total_duration_ms": total_duration_ms,
            "total_tokens": total_tokens,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }

        turn_counts = [
            turn_count
            for result in results
            if (turn_count := resolve_turn_count(result)) is not None
        ]
        if turn_counts:
            summary["avg_turns"] = round(sum(turn_counts) / len(turn_counts), 2)

        if config.runner.type == "skill":
            if results:
                summary["avg_duration_ms"] = round(total_duration_ms / len(results))

            costs = [
                cost
                for result in results
                if (cost := resolve_skill_cost(result)) is not None
            ]
            if costs:
                summary["avg_cost_usd"] = round(sum(costs) / len(costs), 4)
                summary["total_cost_usd"] = round(sum(costs), 4)

        if contract_summary is not None:
            summary["contract_summary"] = contract_summary

        output_dir.mkdir(parents=True, exist_ok=True)
        (output_dir / "summary.json").write_text(
            json.dumps(summary, indent=2, ensure_ascii=False)
        )
