"""FluxLoop CLI — Agent evaluation framework."""

__version__ = "0.4.0"
