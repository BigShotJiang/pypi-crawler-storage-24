"""Helpers for safe path resolution and result directory naming."""

from __future__ import annotations

import re
from pathlib import Path

_INVALID_RESULT_NAME_CHARS = re.compile(r"[^A-Za-z0-9_-]+")
_REPEATED_DASHES = re.compile(r"-+")


def sanitize_result_name(name: str, *, default: str = "experiment") -> str:
    """Normalize user-controlled names before using them in result paths."""
    sanitized = _INVALID_RESULT_NAME_CHARS.sub("-", name).strip("-")
    sanitized = _REPEATED_DASHES.sub("-", sanitized)
    return sanitized or default


def resolve_path_within_root(root: Path, unsafe_path: str) -> Path | None:
    """Resolve a path and ensure it stays within the given root."""
    resolved_root = root.resolve()
    candidate = (resolved_root / unsafe_path).resolve(strict=False)

    if candidate == resolved_root or candidate.is_relative_to(resolved_root):
        return candidate
    return None
