"""Sandbox creation, isolation, and cleanup for skill execution."""

from __future__ import annotations

import glob as glob_mod
import os
import shutil
import tempfile
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class Sandbox:
    workspace_path: Path
    skill_installed: bool = False
    _temp_dir: tempfile.TemporaryDirectory | None = field(
        default=None, repr=False
    )

    def install_skill(self, skill_path: Path) -> Path:
        """Install SKILL.md into sandbox's .claude/skills/ directory.

        Returns:
            Path to the installed skill file.
        """
        skills_dir = self.workspace_path / ".claude" / "skills"
        skills_dir.mkdir(parents=True, exist_ok=True)
        dest = skills_dir / skill_path.name
        shutil.copy2(skill_path, dest)
        self.skill_installed = True
        return dest

    def cleanup(self) -> None:
        """Remove sandbox temporary directory."""
        if self._temp_dir:
            self._temp_dir.cleanup()
            self._temp_dir = None


class SandboxManager:
    def create_sandbox(
        self,
        *,
        copy_files: list[str] | None = None,
        source_dir: Path | None = None,
    ) -> Sandbox:
        """Create an isolated sandbox directory.

        1. Create a TemporaryDirectory
        2. Copy files/directories matching copy_files patterns from source_dir
        3. Initialize .claude/ directory structure

        Args:
            copy_files: Glob patterns of files/directories to copy.
            source_dir: Source directory (default: cwd).
        """
        source = source_dir or Path.cwd()
        temp_dir = tempfile.TemporaryDirectory(prefix="fluxloop-sandbox-")
        workspace = Path(temp_dir.name)

        if copy_files:
            for pattern in copy_files:
                _copy_pattern(source, workspace, pattern)

        return Sandbox(
            workspace_path=workspace,
            _temp_dir=temp_dir,
        )


def _copy_pattern(source: Path, dest: Path, pattern: str) -> None:
    """Copy files/directories matching a glob pattern, preserving relative paths."""
    source_root = source.resolve()
    src_path = source / pattern
    if src_path.exists() or src_path.is_symlink():
        _copy_entry(
            src_path=src_path,
            dest_path=dest / pattern,
            source_root=source_root,
            dest_root=dest,
        )
    else:
        for matched in glob_mod.glob(str(source / pattern)):
            matched_path = Path(matched)
            rel = matched_path.relative_to(source)
            _copy_entry(
                src_path=matched_path,
                dest_path=dest / rel,
                source_root=source_root,
                dest_root=dest,
            )


def _copy_entry(
    *,
    src_path: Path,
    dest_path: Path,
    source_root: Path,
    dest_root: Path,
) -> None:
    if src_path.is_symlink():
        _copy_symlink(
            src_path=src_path,
            dest_path=dest_path,
            source_root=source_root,
            dest_root=dest_root,
        )
        return

    if src_path.is_dir():
        dest_path.mkdir(parents=True, exist_ok=True)
        for child in src_path.iterdir():
            _copy_entry(
                src_path=child,
                dest_path=dest_path / child.name,
                source_root=source_root,
                dest_root=dest_root,
            )
        return

    dest_path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src_path, dest_path)


def _copy_symlink(
    *,
    src_path: Path,
    dest_path: Path,
    source_root: Path,
    dest_root: Path,
) -> None:
    raw_target = os.readlink(src_path)
    target_path = Path(raw_target)
    resolved_target = (
        target_path.resolve(strict=False)
        if target_path.is_absolute()
        else (src_path.parent / target_path).resolve(strict=False)
    )

    if not (
        resolved_target == source_root
        or resolved_target.is_relative_to(source_root)
    ):
        raise ValueError(
            f"Refusing to copy symlink outside source root: {src_path}"
        )

    dest_path.parent.mkdir(parents=True, exist_ok=True)
    if dest_path.exists() or dest_path.is_symlink():
        if dest_path.is_dir() and not dest_path.is_symlink():
            shutil.rmtree(dest_path)
        else:
            dest_path.unlink()

    link_target = raw_target
    if target_path.is_absolute():
        sandbox_target = dest_root / resolved_target.relative_to(source_root)
        link_target = os.path.relpath(sandbox_target, dest_path.parent)

    dest_path.symlink_to(link_target)
