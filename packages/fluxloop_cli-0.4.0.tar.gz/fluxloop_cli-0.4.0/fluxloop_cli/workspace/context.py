"""Local workspace context management (.fluxloop/ directory)."""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Optional

import typer
from rich.console import Console

from ..constants import (
    CONTEXT_JSON_FILENAME,
    FLUXLOOP_DIR_NAME,
    PROJECT_JSON_FILENAME,
    SCENARIOS_DIR_NAME,
)

console = Console()


@dataclass
class ProjectConnection:
    project_id: str
    project_name: str
    workspace_id: str = ""
    api_url: str = ""
    connected_at: str | None = None

    @classmethod
    def from_dict(cls, data: dict) -> ProjectConnection:
        return cls(
            project_id=data["project_id"],
            project_name=data["project_name"],
            workspace_id=data.get("workspace_id", ""),
            api_url=data.get("api_url", ""),
            connected_at=data.get("connected_at"),
        )

    def to_dict(self) -> dict:
        return {
            "project_id": self.project_id,
            "project_name": self.project_name,
            "workspace_id": self.workspace_id,
            "api_url": self.api_url,
            "connected_at": self.connected_at or datetime.now(timezone.utc).isoformat(),
        }


@dataclass
class LocalContext:
    current_scenario: str | None = None
    current_scenario_id: str | None = None
    current_dataset_version_id: str | None = None
    current_input_set_id: str | None = None
    current_bundle_version_id: str | None = None
    current_experiment_id: str | None = None

    @classmethod
    def from_dict(cls, data: dict) -> LocalContext:
        return cls(
            current_scenario=data.get("current_scenario"),
            current_scenario_id=data.get("current_scenario_id"),
            current_dataset_version_id=data.get("current_dataset_version_id"),
            current_input_set_id=data.get("current_input_set_id"),
            current_bundle_version_id=data.get("current_bundle_version_id"),
            current_experiment_id=data.get("current_experiment_id"),
        )

    def to_dict(self) -> dict:
        d: dict = {"current_scenario": self.current_scenario}
        if self.current_scenario_id is not None:
            d["current_scenario_id"] = self.current_scenario_id
        if self.current_dataset_version_id is not None:
            d["current_dataset_version_id"] = self.current_dataset_version_id
        if self.current_input_set_id is not None:
            d["current_input_set_id"] = self.current_input_set_id
        if self.current_bundle_version_id is not None:
            d["current_bundle_version_id"] = self.current_bundle_version_id
        if self.current_experiment_id is not None:
            d["current_experiment_id"] = self.current_experiment_id
        return d


def find_workspace_root(start_dir: Path | None = None) -> Path | None:
    """Walk up from start_dir to find a directory containing .fluxloop/.

    Stops before reaching home directory.
    """
    current = (start_dir or Path.cwd()).resolve()
    home = Path.home().resolve()

    while current != current.parent:
        if current == home:
            break
        if (current / FLUXLOOP_DIR_NAME).is_dir():
            return current
        current = current.parent

    return None


def resolve_fluxloop_dir(base_dir: Path | None = None) -> Path:
    """Return workspace_root/.fluxloop, creating it if needed."""
    root = find_workspace_root(base_dir)
    if root:
        fluxloop_dir = root / FLUXLOOP_DIR_NAME
    else:
        fluxloop_dir = (base_dir or Path.cwd()) / FLUXLOOP_DIR_NAME
    fluxloop_dir.mkdir(parents=True, exist_ok=True)
    return fluxloop_dir


def get_scenarios_dir(base_dir: Path | None = None) -> Path:
    return resolve_fluxloop_dir(base_dir) / SCENARIOS_DIR_NAME


def get_scenario_dir(scenario_name: str, base_dir: Path | None = None) -> Path:
    return get_scenarios_dir(base_dir) / scenario_name


# Project connection (.fluxloop/project.json)

def save_project_connection(conn: ProjectConnection, base_dir: Path | None = None) -> None:
    fluxloop_dir = resolve_fluxloop_dir(base_dir)
    path = fluxloop_dir / PROJECT_JSON_FILENAME
    path.write_text(json.dumps(conn.to_dict(), indent=2))


def load_project_connection(base_dir: Path | None = None) -> Optional[ProjectConnection]:
    root = find_workspace_root(base_dir)
    if not root:
        return None
    path = root / FLUXLOOP_DIR_NAME / PROJECT_JSON_FILENAME
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text())
        return ProjectConnection.from_dict(data)
    except (json.JSONDecodeError, KeyError):
        return None


def select_web_project(
    project_id: str,
    project_name: str,
    api_url: str = "",
    workspace_id: str = "",
    base_dir: Path | None = None,
) -> ProjectConnection:
    conn = ProjectConnection(
        project_id=project_id,
        project_name=project_name,
        workspace_id=workspace_id,
        api_url=api_url,
        connected_at=datetime.now(timezone.utc).isoformat(),
    )
    save_project_connection(conn, base_dir)
    return conn


def get_current_web_project_id(base_dir: Path | None = None) -> str | None:
    conn = load_project_connection(base_dir)
    return conn.project_id if conn else None


def require_current_web_project_id(
    project_id: str | None = None,
    *,
    base_dir: Path | None = None,
    resolver: Callable[..., str | None] | None = None,
) -> str:
    if project_id:
        return project_id

    lookup = resolver or get_current_web_project_id
    try:
        current_project_id = lookup(base_dir)
    except TypeError:
        current_project_id = lookup()

    if current_project_id:
        return current_project_id

    console.print("[red]✗[/red] No project selected.")
    console.print("[dim]Run 'fluxloop projects select <id>' first.[/dim]")
    raise typer.Exit(1)


# Local context (.fluxloop/context.json)

def save_context(ctx: LocalContext, base_dir: Path | None = None) -> None:
    fluxloop_dir = resolve_fluxloop_dir(base_dir)
    path = fluxloop_dir / CONTEXT_JSON_FILENAME
    path.write_text(json.dumps(ctx.to_dict(), indent=2))


def load_context(base_dir: Path | None = None) -> Optional[LocalContext]:
    root = find_workspace_root(base_dir)
    if not root:
        return None
    path = root / FLUXLOOP_DIR_NAME / CONTEXT_JSON_FILENAME
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text())
        return LocalContext.from_dict(data)
    except (json.JSONDecodeError, KeyError):
        return None


def update_context(
    updates: dict[str, str | None], base_dir: Path | None = None
) -> LocalContext:
    ctx = load_context(base_dir) or LocalContext()
    valid_fields = LocalContext.__dataclass_fields__

    for key, value in updates.items():
        if key not in valid_fields:
            raise ValueError(f"Unknown context field: {key}")
        setattr(ctx, key, value)

    if (
        "current_input_set_id" in updates
        and "current_dataset_version_id" not in updates
    ):
        # Keep the legacy field aligned so older callers still resolve the latest input set.
        ctx.current_dataset_version_id = updates["current_input_set_id"]

    save_context(ctx, base_dir)
    return ctx


def set_current_scenario(
    scenario_name: str, base_dir: Path | None = None
) -> LocalContext:
    return update_context({"current_scenario": scenario_name}, base_dir)


def set_current_scenario_id(
    scenario_id: str, base_dir: Path | None = None
) -> LocalContext:
    return update_context({"current_scenario_id": scenario_id}, base_dir)


def get_current_scenario_id(base_dir: Path | None = None) -> str | None:
    ctx = load_context(base_dir)
    return ctx.current_scenario_id if ctx else None


def set_dataset_version_id(
    dataset_version_id: str, base_dir: Path | None = None
) -> LocalContext:
    return update_context(
        {"current_dataset_version_id": dataset_version_id},
        base_dir,
    )


def set_input_set_id(
    input_set_id: str, base_dir: Path | None = None
) -> LocalContext:
    return update_context({"current_input_set_id": input_set_id}, base_dir)


def set_bundle_version_id(
    bundle_version_id: str, base_dir: Path | None = None
) -> LocalContext:
    return update_context(
        {"current_bundle_version_id": bundle_version_id},
        base_dir,
    )


def set_experiment_id(
    experiment_id: str, base_dir: Path | None = None
) -> LocalContext:
    return update_context({"current_experiment_id": experiment_id}, base_dir)


def get_pulled_dir(scenario_name: str, base_dir: Path | None = None) -> Path:
    from ..constants import PULLED_DIR_NAME

    return get_scenario_dir(scenario_name, base_dir) / PULLED_DIR_NAME
