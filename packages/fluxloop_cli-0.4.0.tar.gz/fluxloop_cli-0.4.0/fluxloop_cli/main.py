"""FluxLoop CLI — main entrypoint."""

from typing import Optional

import typer
from rich.console import Console

from . import __version__
from .commands import (
    apikeys,
    auth,
    bundles,
    context,
    data,
    evaluate,
    init,
    inputs,
    intent,
    manifests,
    personas,
    projects,
    run,
    scenarios,
    skill,
    sync_cmd,
    test_cmd,
)

app = typer.Typer(
    name="fluxloop",
    help="FluxLoop CLI — Agent evaluation framework",
    add_completion=True,
    rich_markup_mode="rich",
)
console = Console()

# Command groups
app.add_typer(auth.app, name="auth", help="Manage authentication")
app.add_typer(projects.app, name="projects", help="Manage projects")
app.add_typer(init.app, name="init", help="Initialize resources")
app.add_typer(context.app, name="context", help="Manage local context")
app.add_typer(skill.app, name="skill", help="Skill validation and testing")
app.add_typer(scenarios.app, name="scenarios", help="Manage scenarios")
app.add_typer(apikeys.app, name="apikeys", help="Manage API keys")
app.add_typer(personas.app, name="personas", help="Manage personas")
app.add_typer(inputs.app, name="inputs", help="Manage test inputs")
app.add_typer(bundles.app, name="bundles", help="Manage bundles")
app.add_typer(sync_cmd.app, name="sync", help="Sync data with server")
app.add_typer(test_cmd.app, name="test", help="Test workflow")
app.add_typer(evaluate.app, name="evaluate", help="Run evaluations")
app.add_typer(manifests.app, name="manifests", help="Manage manifests")
app.add_typer(data.app, name="data", help="Manage test data")
app.add_typer(intent.app, name="intent", help="Manage intents")

# Standalone commands
app.command(name="run")(run.run_command)


def _version_callback(value: bool):
    if value:
        console.print(f"fluxloop {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: Optional[bool] = typer.Option(
        None,
        "--version",
        "-v",
        help="Show version and exit",
        callback=_version_callback,
        is_eager=True,
    ),
    verbose: bool = typer.Option(False, "--verbose", help="Enable verbose output"),
):
    """FluxLoop CLI — Simulation and evaluation for AI agents."""
    pass


if __name__ == "__main__":
    app()
