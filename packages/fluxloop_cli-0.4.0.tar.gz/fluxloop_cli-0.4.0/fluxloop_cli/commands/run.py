"""Run command — execute agent function and produce results."""

from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional
from uuid import uuid4

import typer
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn

from ..config.loader import load_config, load_env_chain, revalidate_config
from ..constants import RESULTS_DIR_NAME
from ..core.conversation_runner import execute_conversation
from ..core.executor import RunContext, RunResult, create_executor
from ..path_safety import sanitize_result_name
from ..core.user_simulator import UserSimulator
from ..result.error_writer import ErrorWriter
from ..result.summary_writer import SummaryWriter
from ..result.trace_writer import TraceWriter
from ..workspace.context import get_scenario_dir, load_context, resolve_fluxloop_dir

console = Console()


def run_command(
    scenario: Optional[str] = typer.Option(
        None, "--scenario", "-s", help="Scenario name (default: current context)"
    ),
    iterations: Optional[int] = typer.Option(
        None, "--iterations", "-i", help="Override iteration count"
    ),
    verbose: bool = typer.Option(False, "--verbose", help="Verbose output"),
):
    """Run agent function with configured inputs."""
    # Resolve scenario
    scenario_name = scenario
    if not scenario_name:
        ctx = load_context()
        if ctx and ctx.current_scenario:
            scenario_name = ctx.current_scenario
    if not scenario_name:
        console.print("[red]✗[/red] No scenario specified.")
        console.print("[dim]Use --scenario <name> or run 'fluxloop init scenario <name>'[/dim]")
        raise typer.Exit(1)

    scenario_dir = get_scenario_dir(scenario_name)
    if not scenario_dir.exists():
        console.print(f"[red]✗[/red] Scenario not found: {scenario_dir}")
        raise typer.Exit(1)

    # Load .env files (before config so ${VAR} substitution works)
    load_env_chain(scenario_dir)

    # Load config
    try:
        config = load_config(scenario_dir)
    except (FileNotFoundError, ValueError) as e:
        console.print(f"[red]✗[/red] Config error: {e}")
        raise typer.Exit(1)

    if iterations is not None:
        try:
            config = revalidate_config(config, iterations=iterations)
        except ValueError as e:
            console.print(f"[red]✗[/red] Config error: {e}")
            raise typer.Exit(1)

    # Create output directory
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    fluxloop_dir = resolve_fluxloop_dir()
    result_name = sanitize_result_name(config.name)
    output_dir = fluxloop_dir / RESULTS_DIR_NAME / f"{result_name}-{timestamp}"

    # Create executor
    try:
        executor = create_executor(config.runner)
    except (ValueError, NotImplementedError) as e:
        console.print(f"[red]✗[/red] {e}")
        raise typer.Exit(1)

    # Prepare inputs
    inputs = config.input.items
    if not inputs:
        console.print("[red]✗[/red] No input items configured.")
        raise typer.Exit(1)

    total_runs = config.iterations * len(inputs)

    if verbose:
        console.print(f"  Scenario:    {scenario_name}")
        console.print(f"  Runner:      {config.runner.type} → {config.runner.target}")
        console.print(f"  Iterations:  {config.iterations}")
        console.print(f"  Inputs:      {len(inputs)}")
        console.print(f"  Total runs:  {total_runs}")
        console.print()

    # Run
    results = asyncio.run(
        _run_loop(executor, config, inputs, output_dir, total_runs, verbose)
    )

    # Summary
    summary_writer = SummaryWriter()
    summary_writer.write(output_dir, config, results)
    ErrorWriter().write(output_dir, config)

    success_count = sum(1 for r in results if r.success)
    avg_duration = sum(r.duration_ms for r in results) / len(results) if results else 0

    console.print()
    console.print(
        f"[green]✓[/green] Completed: {success_count}/{len(results)} successful "
        f"(avg {avg_duration / 1000:.1f}s)"
    )
    console.print(f"  Results: {output_dir}")


async def _run_loop(
    executor,
    config,
    inputs,
    output_dir: Path,
    total_runs: int,
    verbose: bool,
) -> list[RunResult]:
    trace_writer = TraceWriter(output_dir)
    results: list[RunResult] = []
    simulator = None

    if config.conversation.enabled:
        simulator = UserSimulator(config.conversation.simulator)
        simulator.validate_configuration()

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        console=console,
    ) as progress:
        task = progress.add_task("Running...", total=total_runs)

        for iteration in range(config.iterations):
            for input_item in inputs:
                input_metadata = (
                    input_item.metadata if isinstance(input_item.metadata, dict) else {}
                )
                persona = (
                    input_metadata.get("persona")
                    or input_metadata.get("persona_id")
                )
                run_id = str(uuid4())
                context = RunContext(
                    iteration=iteration,
                    scenario=config.name,
                    persona=str(persona) if persona else None,
                    environment_vars=config.runner.environment_vars,
                )

                if simulator is not None:
                    result = await execute_conversation(
                        executor=executor,
                        simulator=simulator,
                        initial_input=input_item.text,
                        context=context,
                        run_id=run_id,
                        max_turns=config.conversation.max_turns,
                    )
                else:
                    result = await executor.execute(
                        input_text=input_item.text,
                        context=context,
                        run_id=run_id,
                    )

                trace_writer.write(
                    result,
                    context,
                    input_item.text,
                    input_metadata=input_metadata or None,
                )
                results.append(result)
                progress.update(task, advance=1)

                if verbose and not result.success:
                    err_msg = result.error.message if result.error else "Unknown error"
                    console.print(f"  [red]✗[/red] Run {run_id[:8]}: {err_msg}")

    try:
        await executor.cleanup()
    except Exception:
        pass

    return results
