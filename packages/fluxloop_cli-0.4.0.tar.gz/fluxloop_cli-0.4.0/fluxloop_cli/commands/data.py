"""Data management commands."""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Optional

import httpx
import typer
from rich.console import Console
from rich.table import Table

from ..api_utils import resolve_api_url
from ..sync.client import FluxLoopAPIError, close_client, create_client
from ..sync import data_api
from .scenario_resolution import (
    NO_SCENARIO_SELECTED_ERROR,
    ScenarioResolutionError,
    resolve_scenario_selection,
)
from ..workspace.context import (
    get_current_web_project_id,
    require_current_web_project_id,
)

app = typer.Typer(help="Manage test data")
gt_app = typer.Typer(help="Ground-truth operations")
app.add_typer(gt_app, name="gt")
console = Console()


def _resolve_scenario(
    client: httpx.Client,
    *,
    project_id: str,
    scenario_id: str | None,
    scenario_name: str | None,
    require: bool = True,
) -> tuple[str | None, str | None, dict[str, Any] | None]:
    try:
        return resolve_scenario_selection(
            client,
            project_id=project_id,
            scenario_id=scenario_id,
            scenario_name=scenario_name,
            require=require,
        )
    except ScenarioResolutionError as exc:
        if str(exc) == NO_SCENARIO_SELECTED_ERROR:
            console.print("[red]✗[/red] No scenario selected.")
            console.print(
                "[dim]Use --scenario-id, --scenario, or run 'fluxloop scenarios select <id>'[/dim]"
            )
        else:
            console.print(f"[red]✗[/red] {exc}")
        raise typer.Exit(1) from exc


def _render_gt_status(items: list[dict[str, Any]]) -> None:
    if not items:
        console.print("[yellow]No ground-truth bindings found.[/yellow]")
        return

    table = Table(title="Ground Truth Status")
    table.add_column("Data ID", style="dim")
    table.add_column("Role")
    table.add_column("Split")
    table.add_column("Label")
    table.add_column("Processing")
    table.add_column("Materialization")

    for item in items:
        table.add_row(
            str(item.get("data_id", "")),
            str(item.get("role", "")),
            str(item.get("split", "—")),
            str(item.get("label_column", "—")),
            str(item.get("data_processing_status", "—")),
            str(item.get("materialization_status", "—")),
        )
    console.print(table)


def _is_gt_terminal(items: list[dict[str, Any]]) -> bool:
    return all(
        str(item.get("materialization_status", "")).lower() in {"ready", "failed"}
        for item in items
    )


@app.command("push")
def push_data(
    path: str = typer.Argument(..., help="Path to local file"),
    name: Optional[str] = typer.Option(None, "--name", help="Override uploaded filename"),
    usage: str = typer.Option("knowledge", "--usage", help="knowledge|ground-truth"),
    bind: bool = typer.Option(False, "--bind", help="Bind uploaded data to a scenario"),
    scenario_id: Optional[str] = typer.Option(None, "--scenario-id", help="Server scenario ID"),
    scenario: Optional[str] = typer.Option(None, "--scenario", help="Scenario name"),
    label_column: Optional[str] = typer.Option(
        None, "--label-column", help="Label column for ground-truth datasets"
    ),
    split: Optional[str] = typer.Option(None, "--split", help="train|eval|test"),
    project_id: Optional[str] = typer.Option(None, "--project-id", help="Project ID"),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="API base URL"),
    staging: bool = typer.Option(False, "--staging", help="Use staging API"),
) -> None:
    file_path = Path(path).resolve()
    if not file_path.exists() or not file_path.is_file():
        console.print(f"[red]✗[/red] File not found: {file_path}")
        raise typer.Exit(1)

    pid = require_current_web_project_id(
        project_id,
        resolver=get_current_web_project_id,
    )
    api_url_resolved = resolve_api_url(api_url, staging=staging)
    client = None

    try:
        client = create_client(api_url_resolved, use_jwt=True)
        create_data = data_api.create_project_data(
            client,
            project_id=pid,
            file_path=file_path,
            usage=usage,
            name=name,
        )
        upload = create_data.get("upload", {})
        data_row = create_data.get("data", {})
        data_id = str(data_row.get("id", ""))

        with console.status("Uploading data..."):
            data_api.upload_to_signed_url(
                upload_url=str(upload.get("upload_url", "")),
                file_path=file_path,
                headers=upload.get("headers") if isinstance(upload.get("headers"), dict) else None,
            )
            confirmed = data_api.confirm_project_data(
                client,
                project_id=pid,
                data_id=data_id,
                file_path=file_path,
            )

        binding_id = None
        materialization_id = None
        if bind:
            sid, _, _ = _resolve_scenario(
                client,
                project_id=pid,
                scenario_id=scenario_id,
                scenario_name=scenario,
                require=True,
            )
            binding = data_api.bind_scenario_data(
                client,
                scenario_id=str(sid),
                data_id=data_id,
                role=usage,
                label_column=label_column,
                split=split,
            )
            binding_id = (
                binding.get("binding", {}).get("id")
                if isinstance(binding.get("binding"), dict)
                else None
            )

            if data_api.normalize_usage(usage) == "ground-truth":
                status = str(confirmed.get("processing_status") or "")
                if status == "completed":
                    materialize_resp = data_api.materialize_ground_truth(
                        client,
                        scenario_id=str(sid),
                        data_id=data_id,
                        label_column=label_column,
                        split=split,
                    )
                    if materialize_resp.is_success:
                        payload = materialize_resp.json()
                        materialization_id = payload.get("profile", {}).get("id")
                    elif materialize_resp.status_code not in {400, 409}:
                        materialize_resp.raise_for_status()

        console.print(f"[green]✓[/green] Uploaded data: [dim]{data_id}[/dim]")
        console.print(f"  Status: {confirmed.get('processing_status', 'queued')}")
        if binding_id:
            console.print(f"  Binding: [dim]{binding_id}[/dim]")
        if materialization_id:
            console.print(f"  Materialization: [dim]{materialization_id}[/dim]")
        elif bind and data_api.normalize_usage(usage) == "ground-truth":
            console.print(
                "  [dim]Ground-truth materialization pending. Use 'fluxloop data gt status --watch'.[/dim]"
            )

    except (FluxLoopAPIError, httpx.HTTPError, ValueError) as e:
        console.print(f"[red]✗[/red] Failed to push data: {e}")
        raise typer.Exit(1)
    finally:
        close_client(client)


@app.command("bind")
def bind_data(
    data_id: str = typer.Argument(..., help="Existing data ID"),
    scenario_id: Optional[str] = typer.Option(None, "--scenario-id", help="Server scenario ID"),
    scenario: Optional[str] = typer.Option(None, "--scenario", help="Scenario name"),
    role: str = typer.Option("knowledge", "--role", help="knowledge|ground-truth"),
    label_column: Optional[str] = typer.Option(
        None, "--label-column", help="Label column for ground-truth datasets"
    ),
    split: Optional[str] = typer.Option(None, "--split", help="train|eval|test"),
    project_id: Optional[str] = typer.Option(None, "--project-id", help="Project ID"),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="API base URL"),
    staging: bool = typer.Option(False, "--staging", help="Use staging API"),
) -> None:
    pid = require_current_web_project_id(
        project_id,
        resolver=get_current_web_project_id,
    )
    api_url_resolved = resolve_api_url(api_url, staging=staging)
    client = None

    try:
        client = create_client(api_url_resolved, use_jwt=True)
        sid, _, _ = _resolve_scenario(
            client,
            project_id=pid,
            scenario_id=scenario_id,
            scenario_name=scenario,
            require=True,
        )
        binding = data_api.bind_scenario_data(
            client,
            scenario_id=str(sid),
            data_id=data_id,
            role=role,
            label_column=label_column,
            split=split,
        )
        binding_id = (
            binding.get("binding", {}).get("id")
            if isinstance(binding.get("binding"), dict)
            else None
        )

        materialization_id = None
        materialize_error: str | None = None
        if data_api.normalize_role(role) == "ground-truth":
            materialize_resp = data_api.materialize_ground_truth(
                client,
                scenario_id=str(sid),
                data_id=data_id,
                label_column=label_column,
                split=split,
            )
            if materialize_resp.is_success:
                payload = materialize_resp.json()
                materialization_id = payload.get("profile", {}).get("id")
            elif materialize_resp.status_code in {400, 409}:
                try:
                    materialize_error = materialize_resp.json().get("detail")
                except Exception:
                    materialize_error = materialize_resp.text
            else:
                materialize_resp.raise_for_status()

        console.print(f"[green]✓[/green] Bound data: [dim]{data_id}[/dim]")
        if binding_id:
            console.print(f"  Binding: [dim]{binding_id}[/dim]")
        if materialization_id:
            console.print(f"  Materialization: [dim]{materialization_id}[/dim]")
        elif materialize_error:
            console.print(f"  [dim]{materialize_error}[/dim]")

    except (FluxLoopAPIError, httpx.HTTPError, ValueError) as e:
        console.print(f"[red]✗[/red] Failed to bind data: {e}")
        raise typer.Exit(1)
    finally:
        close_client(client)


@gt_app.command("status")
def gt_status(
    scenario_id: Optional[str] = typer.Option(None, "--scenario-id", help="Server scenario ID"),
    scenario: Optional[str] = typer.Option(None, "--scenario", help="Scenario name"),
    data_id: Optional[str] = typer.Option(None, "--data-id", help="Filter by data ID"),
    watch: bool = typer.Option(False, "--watch", help="Poll until terminal state"),
    poll_interval: float = typer.Option(3.0, "--poll-interval", help="Polling interval in seconds"),
    project_id: Optional[str] = typer.Option(None, "--project-id", help="Project ID"),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="API base URL"),
    staging: bool = typer.Option(False, "--staging", help="Use staging API"),
) -> None:
    pid = require_current_web_project_id(
        project_id,
        resolver=get_current_web_project_id,
    )
    api_url_resolved = resolve_api_url(api_url, staging=staging)
    client = None

    try:
        client = create_client(api_url_resolved, use_jwt=True)
        sid, _, _ = _resolve_scenario(
            client,
            project_id=pid,
            scenario_id=scenario_id,
            scenario_name=scenario,
            require=True,
        )

        while True:
            payload = data_api.get_ground_truth_status(
                client,
                scenario_id=str(sid),
                data_id=data_id,
            )
            items = payload.get("items", [])
            if not isinstance(items, list):
                items = []
            _render_gt_status(items)

            if not watch or not items or _is_gt_terminal(items):
                break
            time.sleep(poll_interval)
            console.print()

    except (FluxLoopAPIError, httpx.HTTPError, ValueError) as e:
        console.print(f"[red]✗[/red] Failed to fetch GT status: {e}")
        raise typer.Exit(1)
    finally:
        close_client(client)
