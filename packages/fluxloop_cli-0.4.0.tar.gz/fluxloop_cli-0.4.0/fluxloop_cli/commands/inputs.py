"""Input management commands."""

from __future__ import annotations

import json
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from ..api_utils import handle_api_error, resolve_api_url
from ..sync.client import close_client, create_client, get_with_retry, post_with_retry
from ..sync.inputs_api import refine_inputs as refine_inputs_api
from ..workspace.context import get_current_scenario_id, get_current_web_project_id
from ..workspace.context import (
    load_context,
    require_current_web_project_id,
    update_context,
)

app = typer.Typer(help="Manage test inputs")
console = Console()


@app.command("list")
def list_inputs(
    scenario_id: Optional[str] = typer.Option(None, "--scenario-id", help="Scenario ID"),
    input_set_id: Optional[str] = typer.Option(None, "--input-set-id", help="Input set ID"),
    project_id: Optional[str] = typer.Option(None, "--project-id", help="Project ID"),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="API base URL"),
    staging: bool = typer.Option(False, "--staging", help="Use staging API"),
):
    """List input sets or items."""
    api_url = resolve_api_url(api_url, staging=staging)
    client = None

    try:
        client = create_client(api_url, use_jwt=True)

        params: dict = {}
        if input_set_id:
            params["input_set_id"] = input_set_id
        elif project_id or get_current_web_project_id():
            params["project_id"] = require_current_web_project_id(
                project_id,
                resolver=get_current_web_project_id,
            )

        resp = get_with_retry(client, "/api/inputs", params=params)
        handle_api_error(resp, "list inputs")

        data = resp.json()

        # If we got input sets (no specific set requested)
        input_sets = data.get("input_sets")
        if input_sets:
            table = Table(title="Input Sets")
            table.add_column("ID", style="dim")
            table.add_column("Version")
            table.add_column("Items")

            for s in input_sets:
                table.add_row(
                    s.get("id", ""),
                    str(s.get("version", "")),
                    str(s.get("input_count", s.get("item_count", "—"))),
                )
            console.print(table)
            return

        # If we got individual items
        items = data.get("items", [])
        if items:
            console.print(f"[bold]Input items ({len(items)}):[/bold]")
            for i, item in enumerate(items[:10]):
                messages = item.get("messages", [])
                preview = ""
                if messages:
                    first_msg = messages[0] if isinstance(messages, list) else {}
                    preview = str(first_msg.get("content", ""))[:80]
                console.print(f"  {i + 1}. {preview}")
            if len(items) > 10:
                console.print(f"  ... and {len(items) - 10} more")
        else:
            console.print("[yellow]No inputs found.[/yellow]")

    except Exception as e:
        console.print(f"[red]✗[/red] Failed to list inputs: {e}")
        raise typer.Exit(1)
    finally:
        close_client(client)


@app.command("synthesize")
def synthesize_inputs(
    scenario_id: Optional[str] = typer.Option(None, "--scenario-id", help="Scenario ID"),
    count: int = typer.Option(10, "--count", "-c", help="Total number of inputs"),
    project_id: Optional[str] = typer.Option(None, "--project-id", help="Project ID"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview without saving"),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="API base URL"),
    staging: bool = typer.Option(False, "--staging", help="Use staging API"),
):
    """Synthesize test inputs using AI."""
    pid = require_current_web_project_id(
        project_id,
        resolver=get_current_web_project_id,
    )
    sid = scenario_id or get_current_scenario_id()
    if not sid:
        console.print("[red]✗[/red] No scenario selected.")
        console.print("[dim]Use --scenario-id or run 'fluxloop scenarios select <id>'[/dim]")
        raise typer.Exit(1)

    api_url = resolve_api_url(api_url, staging=staging)
    client = None

    try:
        client = create_client(api_url, use_jwt=True)

        payload: dict = {
            "project_id": pid,
            "scenario_id": sid,
            "total_count": count,
            "dry_run": dry_run,
        }

        with console.status("Synthesizing inputs..."):
            resp = post_with_retry(client, "/api/inputs/synthesize", payload=payload)
        handle_api_error(resp, "synthesize inputs")

        data = resp.json()
        items = data.get("items", [])
        version = data.get("version", "")
        by_category = data.get("by_category", {})
        input_set = data.get("input_set", {})

        console.print(f"[green]✓[/green] Synthesized {len(items)} input(s) (version {version})")
        if by_category:
            parts = [f"{k}: {v}" for k, v in by_category.items() if v]
            if parts:
                console.print(f"  Categories: {', '.join(parts)}")

        if not dry_run:
            context_updates: dict[str, str | None] = {}
            if isinstance(input_set, dict) and input_set.get("id"):
                context_updates["current_input_set_id"] = str(input_set.get("id"))
            if (
                isinstance(data.get("bundle_version_id"), str)
                and data.get("bundle_version_id")
            ):
                context_updates["current_bundle_version_id"] = str(
                    data.get("bundle_version_id")
                )
            if context_updates:
                update_context(context_updates)

        if dry_run:
            console.print("  [dim]Dry run — inputs not saved.[/dim]")

    except Exception as e:
        console.print(f"[red]✗[/red] Failed to synthesize inputs: {e}")
        raise typer.Exit(1)
    finally:
        close_client(client)


@app.command("qc")
def qc_inputs(
    input_set_id: str = typer.Option(..., "--input-set-id", help="Input set ID"),
    scenario_id: Optional[str] = typer.Option(None, "--scenario-id", help="Scenario ID"),
    project_id: Optional[str] = typer.Option(None, "--project-id", help="Project ID"),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="API base URL"),
    staging: bool = typer.Option(False, "--staging", help="Use staging API"),
):
    """Run quality checks on an input set."""
    pid = require_current_web_project_id(
        project_id,
        resolver=get_current_web_project_id,
    )
    sid = scenario_id or get_current_scenario_id()
    if not sid:
        console.print("[red]✗[/red] No scenario selected.")
        raise typer.Exit(1)

    api_url = resolve_api_url(api_url, staging=staging)
    client = None

    try:
        client = create_client(api_url, use_jwt=True)

        payload = {
            "project_id": pid,
            "scenario_id": sid,
            "input_set_id": input_set_id,
        }

        with console.status("Running QC..."):
            resp = post_with_retry(client, "/api/inputs/qc", payload=payload)
        handle_api_error(resp, "QC inputs")

        data = resp.json()
        issues = data.get("issues", [])
        recommendations = data.get("recommendations", [])

        if not issues:
            console.print("[green]✓[/green] No issues found.")
        else:
            console.print(f"[yellow]Found {len(issues)} issue(s):[/yellow]")
            for issue in issues:
                console.print(f"  - {issue.get('message', issue)}")

        if recommendations:
            console.print("\n[bold]Recommendations:[/bold]")
            for rec in recommendations:
                console.print(f"  - {rec}")

    except Exception as e:
        console.print(f"[red]✗[/red] Failed to run QC: {e}")
        raise typer.Exit(1)
    finally:
        close_client(client)


@app.command("refine")
def refine_inputs(
    input_set_id: Optional[str] = typer.Option(None, "--input-set-id", help="Input set ID"),
    scenario_id: Optional[str] = typer.Option(None, "--scenario-id", help="Scenario ID"),
    bundle_version_id: Optional[str] = typer.Option(
        None, "--bundle-version-id", help="Bundle version ID"
    ),
    project_id: Optional[str] = typer.Option(None, "--project-id", help="Project ID"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview without saving"),
    output: str = typer.Option("table", "--output", help="table|json"),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="API base URL"),
    staging: bool = typer.Option(False, "--staging", help="Use staging API"),
):
    """Refine an existing input set."""
    pid = require_current_web_project_id(
        project_id,
        resolver=get_current_web_project_id,
    )
    sid = scenario_id or get_current_scenario_id()
    if not sid:
        console.print("[red]✗[/red] No scenario selected.")
        console.print("[dim]Use --scenario-id or run 'fluxloop scenarios select <id>'[/dim]")
        raise typer.Exit(1)

    ctx = load_context()
    resolved_input_set_id = input_set_id
    if not resolved_input_set_id and ctx:
        resolved_input_set_id = ctx.current_input_set_id or ctx.current_dataset_version_id
    if not resolved_input_set_id:
        console.print("[red]✗[/red] No input set selected.")
        console.print("[dim]Use --input-set-id or run 'fluxloop inputs synthesize' first.[/dim]")
        raise typer.Exit(1)
    resolved_bundle_version_id = bundle_version_id or (ctx.current_bundle_version_id if ctx else None)

    api_url = resolve_api_url(api_url, staging=staging)
    client = None

    try:
        client = create_client(api_url, use_jwt=True)
        data = refine_inputs_api(
            client,
            project_id=pid,
            scenario_id=sid,
            input_set_id=resolved_input_set_id,
            bundle_version_id=resolved_bundle_version_id,
            dry_run=dry_run,
        )

        input_set = data.get("input_set", {})
        if not dry_run:
            context_updates: dict[str, str | None] = {}
            if isinstance(input_set, dict) and input_set.get("id"):
                context_updates["current_input_set_id"] = str(input_set.get("id"))
            if (
                isinstance(data.get("bundle_version_id"), str)
                and data.get("bundle_version_id")
            ):
                context_updates["current_bundle_version_id"] = str(
                    data.get("bundle_version_id")
                )
            if context_updates:
                update_context(context_updates)

        if output == "json":
            console.print_json(json.dumps(data, ensure_ascii=False))
            return

        items = data.get("items", [])
        change_log = data.get("change_log", [])
        table = Table(title="Input Refinement")
        table.add_column("Field", style="bold")
        table.add_column("Value")
        table.add_row("Input Set", str(input_set.get("id", resolved_input_set_id)))
        table.add_row("Version", str(data.get("version", "—")))
        table.add_row("Items", str(len(items) if isinstance(items, list) else 0))
        if change_log:
            table.add_row(
                "Changes",
                "\n".join(str(item) for item in change_log[:5]),
            )
        if dry_run:
            table.add_row("Mode", "dry-run")
        console.print(table)

    except Exception as e:
        console.print(f"[red]✗[/red] Failed to refine inputs: {e}")
        raise typer.Exit(1)
    finally:
        close_client(client)
