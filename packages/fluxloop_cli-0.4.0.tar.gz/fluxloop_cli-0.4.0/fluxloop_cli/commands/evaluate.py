"""Evaluation commands."""

from __future__ import annotations

from typing import Any, Optional

import typer
from rich.console import Console

from ..api_utils import handle_api_error, resolve_api_url
from ..sync.client import close_client, create_client, get_with_retry, post_with_retry
from ..workspace.context import (
    get_current_web_project_id,
    load_context,
    require_current_web_project_id,
    set_experiment_id,
)

app = typer.Typer(help="Run evaluations", invoke_without_command=True)
console = Console()

def _resolve_scenario_id(
    explicit_scenario_id: str | None,
    *,
    require_current: bool,
) -> str | None:
    if explicit_scenario_id:
        return explicit_scenario_id
    if not require_current:
        return None

    ctx = load_context()
    if ctx and ctx.current_scenario_id:
        return ctx.current_scenario_id

    console.print("[red]✗[/red] No scenario selected.")
    console.print(
        "[dim]Use --scenario-id or run 'fluxloop scenarios select <id>' first.[/dim]"
    )
    raise typer.Exit(1)


def _resolve_experiment_id(
    client,
    *,
    project_id: str,
    explicit_experiment_id: str | None,
    scenario_id: str | None,
    run_id: str | None,
) -> str:
    if explicit_experiment_id:
        return explicit_experiment_id

    ctx = load_context()
    if ctx and ctx.current_experiment_id and not run_id and not scenario_id:
        return ctx.current_experiment_id

    if run_id:
        page_size = 200
        offset = 0

        while True:
            resp = get_with_retry(
                client,
                "/api/runs",
                params={
                    "project_id": project_id,
                    "limit": page_size,
                    "offset": offset,
                    **({"scenario_id": scenario_id} if scenario_id else {}),
                },
            )
            handle_api_error(resp, "list runs")

            runs = resp.json()
            if not isinstance(runs, list):
                break

            for run in runs:
                if not isinstance(run, dict):
                    continue
                if str(run.get("id") or "") != run_id:
                    continue

                experiment_id = run.get("experiment_id")
                if experiment_id:
                    return str(experiment_id)
                break

            if len(runs) < page_size:
                break
            offset += page_size

        raise RuntimeError(f"Run {run_id} was not found in the current project.")

    resp = get_with_retry(
        client,
        "/api/experiments",
        params={
            "project_id": project_id,
            "limit": 1,
            **({"scenario_id": scenario_id} if scenario_id else {}),
        },
    )
    handle_api_error(resp, "list experiments")

    experiments = resp.json()
    if isinstance(experiments, list) and experiments:
        experiment = experiments[0]
        if isinstance(experiment, dict):
            experiment_id = experiment.get("experiment_id")
            if experiment_id:
                return str(experiment_id)

    raise RuntimeError("No experiments found for the current selection.")


def _run_evaluation_command(
    *,
    experiment_id: str | None,
    scenario_id: str | None,
    run_id: str | None,
    project_id: str | None,
    config_id: str | None,
    wait: bool,
    timeout: float,
    poll_interval: float,
    api_url: str | None,
    staging: bool,
) -> None:
    pid = require_current_web_project_id(
        project_id,
        resolver=get_current_web_project_id,
    )
    api_url = resolve_api_url(api_url, staging=staging)
    client = None

    try:
        client = create_client(api_url, use_jwt=True)
        resolved_experiment_id = _resolve_experiment_id(
            client,
            project_id=pid,
            explicit_experiment_id=experiment_id,
            scenario_id=scenario_id,
            run_id=run_id,
        )

        payload: dict[str, Any] = {
            "project_id": pid,
            "experiment_id": resolved_experiment_id,
        }
        if config_id:
            payload["config_id"] = config_id
        if run_id:
            payload["run_ids"] = [run_id]

        resp = post_with_retry(client, "/api/evaluations", payload=payload)
        handle_api_error(resp, "create evaluation")

        data = resp.json()
        eval_id = data.get("evaluation_id", "")
        status = data.get("status", "")
        set_experiment_id(resolved_experiment_id)

        console.print(f"[green]✓[/green] Evaluation triggered: [dim]{eval_id}[/dim]")
        console.print(f"  Status: {status}")

        if wait and eval_id:
            job = _wait_for_evaluation(
                client,
                project_id=pid,
                experiment_id=resolved_experiment_id,
                eval_id=eval_id,
                timeout=timeout,
                poll_interval=poll_interval,
            )
            final_status = (job or {}).get("status", "unknown")
            if final_status in {"failed", "cancelled", "error"}:
                raise typer.Exit(1)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]✗[/red] Failed to create evaluation: {e}")
        raise typer.Exit(1)
    finally:
        close_client(client)


@app.callback(invoke_without_command=True)
def evaluate_root(
    ctx: typer.Context,
    experiment_id: Optional[str] = typer.Option(
        None, "--experiment-id", help="Experiment (run batch) ID"
    ),
    scenario_id: Optional[str] = typer.Option(None, "--scenario-id", help="Server scenario ID"),
    run_id: Optional[str] = typer.Option(None, "--run-id", help="Run ID to evaluate"),
    project_id: Optional[str] = typer.Option(None, "--project-id", help="Project ID"),
    config_id: Optional[str] = typer.Option(None, "--config-id", help="Evaluation config ID"),
    wait: bool = typer.Option(True, "--wait/--no-wait", help="Wait for completion"),
    timeout: float = typer.Option(300, "--timeout", help="Wait timeout in seconds"),
    poll_interval: float = typer.Option(5, "--poll-interval", help="Poll interval in seconds"),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="API base URL"),
    staging: bool = typer.Option(False, "--staging", help="Use staging API"),
) -> None:
    """Run an evaluation by default."""
    if ctx.invoked_subcommand:
        return

    resolved_scenario_id = _resolve_scenario_id(
        scenario_id,
        require_current=not experiment_id and not run_id,
    )
    _run_evaluation_command(
        experiment_id=experiment_id,
        scenario_id=resolved_scenario_id,
        run_id=run_id,
        project_id=project_id,
        config_id=config_id,
        wait=wait,
        timeout=timeout,
        poll_interval=poll_interval,
        api_url=api_url,
        staging=staging,
    )


@app.command("run")
def run_evaluation(
    experiment_id: Optional[str] = typer.Option(None, "--experiment-id", help="Experiment (run batch) ID"),
    scenario_id: Optional[str] = typer.Option(None, "--scenario-id", help="Server scenario ID"),
    run_id: Optional[str] = typer.Option(None, "--run-id", help="Run ID to evaluate"),
    project_id: Optional[str] = typer.Option(None, "--project-id", help="Project ID"),
    config_id: Optional[str] = typer.Option(None, "--config-id", help="Evaluation config ID"),
    wait: bool = typer.Option(True, "--wait/--no-wait", help="Wait for completion"),
    timeout: float = typer.Option(300, "--timeout", help="Wait timeout in seconds"),
    poll_interval: float = typer.Option(5, "--poll-interval", help="Poll interval in seconds"),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="API base URL"),
    staging: bool = typer.Option(False, "--staging", help="Use staging API"),
) -> None:
    """Trigger a server-side evaluation job."""
    resolved_scenario_id = _resolve_scenario_id(
        scenario_id,
        require_current=not experiment_id and not run_id,
    )
    _run_evaluation_command(
        experiment_id=experiment_id,
        scenario_id=resolved_scenario_id,
        run_id=run_id,
        project_id=project_id,
        config_id=config_id,
        wait=wait,
        timeout=timeout,
        poll_interval=poll_interval,
        api_url=api_url,
        staging=staging,
    )


def _wait_for_evaluation(
    client,
    *,
    project_id: str,
    experiment_id: str,
    eval_id: str,
    timeout: float,
    poll_interval: float,
) -> dict[str, Any] | None:
    from ..sync.poller import poll_job

    console.print("[dim]Waiting for evaluation to complete...[/dim]")

    def _select_status(data: Any) -> str | None:
        if not isinstance(data, list):
            return None
        for job in data:
            if isinstance(job, dict) and job.get("id") == eval_id:
                return job.get("status")
        return None

    try:
        data = poll_job(
            client,
            "/api/evaluations/jobs",
            params={"project_id": project_id, "experiment_ids": experiment_id},
            interval=poll_interval,
            timeout=timeout,
            select_status=_select_status,
        )

        jobs = data if isinstance(data, list) else [data]
        for job in jobs:
            if not isinstance(job, dict) or job.get("id") != eval_id:
                continue

            status = job.get("status", "unknown")
            style = "green" if status == "completed" else "yellow"
            console.print(f"[{style}]✓[/{style}] Evaluation {status}")
            if job.get("cost_usd") is not None:
                console.print(f"  Cost: ${job['cost_usd']:.4f}")
            return job

        console.print("[yellow]⚠[/yellow] Could not find evaluation job status.")
        return None
    except TimeoutError as exc:
        console.print(f"[yellow]⚠[/yellow] {exc}")
        console.print("[dim]Check status in the web dashboard.[/dim]")
        return None
