"""Scenario management commands."""

from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from ..api_utils import handle_api_error, resolve_api_url
from ..sync.client import close_client, create_client, get_with_retry, post_with_retry
from .init import ensure_scenario_scaffold
from ..workspace.context import (
    get_current_scenario_id,
    get_current_web_project_id,
    require_current_web_project_id,
    update_context,
)

app = typer.Typer(help="Manage scenarios")
console = Console()

@app.command("create")
def create_scenario(
    name: str = typer.Option(..., "--name", "-n", help="Scenario name"),
    goal: str = typer.Option("", "--goal", "-g", help="Scenario goal"),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="Description"),
    project_id: Optional[str] = typer.Option(None, "--project-id", help="Project ID"),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="API base URL"),
    staging: bool = typer.Option(False, "--staging", help="Use staging API"),
):
    """Create a new scenario on the server."""
    pid = require_current_web_project_id(
        project_id,
        resolver=get_current_web_project_id,
    )
    api_url = resolve_api_url(api_url, staging=staging)
    client = None

    try:
        client = create_client(api_url, use_jwt=True)

        config_snapshot: dict = {"goal": goal}
        if description:
            config_snapshot["description"] = description

        payload = {
            "project_id": pid,
            "name": name,
            "description": description or "",
            "config_snapshot": config_snapshot,
        }

        resp = post_with_retry(client, "/api/scenarios", payload=payload)
        handle_api_error(resp, "create scenario")

        data = resp.json()
        scenario_id = data.get("id", "")

        ensure_scenario_scaffold(name, config_snapshot=data.get("config_snapshot"))
        update_context(
            {
                "current_scenario": name,
                "current_scenario_id": str(scenario_id),
            }
        )

        console.print(f"[green]✓[/green] Scenario created: {name} ([dim]{scenario_id}[/dim])")
        console.print(f"  ID: [dim]{scenario_id}[/dim]")

    except Exception as e:
        console.print(f"[red]✗[/red] Failed to create scenario: {e}")
        raise typer.Exit(1)
    finally:
        close_client(client)


@app.command("select")
def select_scenario(
    scenario_id: str = typer.Argument(..., help="Scenario ID to select"),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="API base URL"),
    staging: bool = typer.Option(False, "--staging", help="Use staging API"),
):
    """Select a scenario (verify on server, store locally)."""
    api_url = resolve_api_url(api_url, staging=staging)
    client = None

    try:
        client = create_client(api_url, use_jwt=True)
        resp = get_with_retry(client, f"/api/scenarios/{scenario_id}")
        handle_api_error(resp, "get scenario")

        data = resp.json()
        name = data.get("name", scenario_id)

        ensure_scenario_scaffold(name, config_snapshot=data.get("config_snapshot"))
        update_context(
            {
                "current_scenario": str(name),
                "current_scenario_id": scenario_id,
            }
        )

        console.print(f"[green]✓[/green] Selected scenario: {name}")
        console.print(f"  ID: [dim]{scenario_id}[/dim]")

    except Exception as e:
        console.print(f"[red]✗[/red] Failed to select scenario: {e}")
        raise typer.Exit(1)
    finally:
        close_client(client)


@app.command("list")
def list_scenarios(
    project_id: Optional[str] = typer.Option(None, "--project-id", help="Project ID"),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="API base URL"),
    staging: bool = typer.Option(False, "--staging", help="Use staging API"),
):
    """List scenarios for the current project."""
    pid = require_current_web_project_id(
        project_id,
        resolver=get_current_web_project_id,
    )
    api_url = resolve_api_url(api_url, staging=staging)
    client = None

    try:
        client = create_client(api_url, use_jwt=True)
        resp = get_with_retry(client, "/api/scenarios", params={"project_id": pid})
        handle_api_error(resp, "list scenarios")

        scenarios = resp.json()
        if not scenarios:
            console.print("[yellow]No scenarios found.[/yellow]")
            return

        current_id = get_current_scenario_id()

        table = Table(title="Scenarios")
        table.add_column("ID", style="dim")
        table.add_column("Name", style="bold")
        table.add_column("Selected", style="green")

        for s in scenarios:
            sid = s.get("id", "")
            selected = "✓" if sid == current_id else ""
            table.add_row(sid, s.get("name", ""), selected)

        console.print(table)

    except Exception as e:
        console.print(f"[red]✗[/red] Failed to list scenarios: {e}")
        raise typer.Exit(1)
    finally:
        close_client(client)


@app.command("refine")
def refine_scenario(
    scenario_id: Optional[str] = typer.Option(None, "--scenario-id", help="Scenario ID"),
    project_id: Optional[str] = typer.Option(None, "--project-id", help="Project ID"),
    apply: bool = typer.Option(False, "--apply", help="Apply refinement to server"),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="API base URL"),
    staging: bool = typer.Option(False, "--staging", help="Use staging API"),
):
    """Refine a scenario using LLM."""
    pid = require_current_web_project_id(
        project_id,
        resolver=get_current_web_project_id,
    )
    sid = scenario_id or get_current_scenario_id()
    if not sid:
        console.print("[red]✗[/red] No scenario selected.")
        console.print("[dim]Use --scenario-id or run 'fluxloop scenarios select <id>'[/dim]")
        raise typer.Exit(1)

    api_url = resolve_api_url(api_url, staging=staging)
    client = None

    try:
        client = create_client(api_url, use_jwt=True)

        payload = {
            "project_id": pid,
            "scenario_id": sid,
            "apply": apply,
        }

        resp = post_with_retry(client, "/api/scenarios/refine", payload=payload)
        handle_api_error(resp, "refine scenario")

        data = resp.json()
        refined = data.get("refined", {})
        applied = data.get("applied", False)

        console.print("[green]✓[/green] Scenario refined")
        if refined.get("name"):
            console.print(f"  Name: {refined['name']}")
        if refined.get("goal"):
            console.print(f"  Goal: {refined['goal']}")
        if refined.get("description"):
            console.print(f"  Description: {refined['description']}")
        if applied:
            console.print("  [green]Applied to server[/green]")
        else:
            console.print("  [dim]Preview only. Use --apply to save.[/dim]")

    except Exception as e:
        console.print(f"[red]✗[/red] Failed to refine scenario: {e}")
        raise typer.Exit(1)
    finally:
        close_client(client)
