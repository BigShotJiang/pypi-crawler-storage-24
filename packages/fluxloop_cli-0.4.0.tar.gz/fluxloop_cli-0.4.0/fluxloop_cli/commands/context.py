"""Context display command."""

from __future__ import annotations

import typer
from rich.console import Console

from ..workspace.context import (
    find_workspace_root,
    get_scenario_dir,
    load_context,
    load_project_connection,
)

app = typer.Typer(help="Manage local context")
console = Console()


@app.command("show")
def show():
    """Show current project and scenario context."""
    root = find_workspace_root()

    conn = load_project_connection()
    ctx = load_context()

    if not conn and not ctx:
        console.print("[yellow]No context configured.[/yellow]")
        console.print("[dim]Run [bold]fluxloop projects select <id>[/bold] to set a project.[/dim]")
        return

    if conn:
        console.print(f"  Project:   {conn.project_name} ([dim]{conn.project_id}[/dim])")
        if conn.api_url:
            console.print(f"  API URL:   {conn.api_url}")

    if ctx and ctx.current_scenario:
        scenario_dir = get_scenario_dir(ctx.current_scenario)
        console.print(f"  Scenario:  {ctx.current_scenario}")
        console.print(f"  Path:      {scenario_dir}")

    if root:
        console.print(f"  Workspace: {root}")
