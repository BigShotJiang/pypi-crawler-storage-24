"""Bundle management commands."""

from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from ..api_utils import handle_api_error, resolve_api_url
from ..sync.client import close_client, create_client, get_with_retry, post_with_retry
from ..workspace.context import (
    get_current_scenario_id,
    get_current_web_project_id,
    require_current_web_project_id,
)

app = typer.Typer(help="Manage bundles")
console = Console()

@app.command("list")
def list_bundles(
    project_id: Optional[str] = typer.Option(None, "--project-id", help="Project ID"),
    scenario_id: Optional[str] = typer.Option(None, "--scenario-id", help="Filter by scenario"),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="API base URL"),
    staging: bool = typer.Option(False, "--staging", help="Use staging API"),
):
    """List bundles for the current project."""
    pid = require_current_web_project_id(
        project_id,
        resolver=get_current_web_project_id,
    )
    api_url = resolve_api_url(api_url, staging=staging)
    client = None

    try:
        client = create_client(api_url, use_jwt=True)

        params: dict = {"project_id": pid}
        if scenario_id:
            params["scenario_id"] = scenario_id

        resp = get_with_retry(client, "/api/bundles", params=params)
        handle_api_error(resp, "list bundles")

        bundles = resp.json()
        if not bundles:
            console.print("[yellow]No bundles found.[/yellow]")
            return

        table = Table(title="Bundles")
        table.add_column("ID", style="dim")
        table.add_column("Name", style="bold")
        table.add_column("Generation")
        table.add_column("Created", style="dim")

        for b in bundles:
            table.add_row(
                b.get("id", ""),
                b.get("name", "—"),
                str(b.get("generation", 1)),
                b.get("created_at", "")[:10] if b.get("created_at") else "—",
            )

        console.print(table)

    except Exception as e:
        console.print(f"[red]✗[/red] Failed to list bundles: {e}")
        raise typer.Exit(1)
    finally:
        close_client(client)


@app.command("publish")
def publish_bundle(
    scenario_id: Optional[str] = typer.Option(None, "--scenario-id", help="Scenario ID"),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Bundle name"),
    input_set_id: Optional[str] = typer.Option(None, "--input-set-id", help="Input set ID"),
    project_id: Optional[str] = typer.Option(None, "--project-id", help="Project ID"),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="API base URL"),
    staging: bool = typer.Option(False, "--staging", help="Use staging API"),
):
    """Publish a new bundle."""
    pid = require_current_web_project_id(
        project_id,
        resolver=get_current_web_project_id,
    )
    sid = scenario_id or get_current_scenario_id()

    api_url = resolve_api_url(api_url, staging=staging)
    client = None

    try:
        client = create_client(api_url, use_jwt=True)

        payload: dict = {"project_id": pid}
        if sid:
            payload["scenario_id"] = sid
        if name:
            payload["name"] = name
        if input_set_id:
            payload["input_set_id"] = input_set_id

        with console.status("Publishing bundle..."):
            resp = post_with_retry(client, "/api/bundles", payload=payload)
        handle_api_error(resp, "publish bundle")

        data = resp.json()
        bundle_id = data.get("id", "")
        bundle_name = data.get("name", "")

        console.print(f"[green]✓[/green] Bundle published: {bundle_name}")
        console.print(f"  ID: [dim]{bundle_id}[/dim]")
        console.print(f"  Generation: {data.get('generation', 1)}")

    except Exception as e:
        console.print(f"[red]✗[/red] Failed to publish bundle: {e}")
        raise typer.Exit(1)
    finally:
        close_client(client)
