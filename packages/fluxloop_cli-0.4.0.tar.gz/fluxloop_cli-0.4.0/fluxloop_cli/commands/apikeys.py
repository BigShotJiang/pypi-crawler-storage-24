"""API Key management commands."""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from ..api_utils import handle_api_error, resolve_api_url
from ..constants import FILE_PERMISSION
from ..sync.client import close_client, create_client, get_with_retry, post_with_retry
from ..workspace.context import (
    get_current_web_project_id,
    require_current_web_project_id,
    resolve_fluxloop_dir,
)

app = typer.Typer(help="Manage API keys")
console = Console()

@app.command("create")
def create_api_key(
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Key name"),
    project_id: Optional[str] = typer.Option(None, "--project-id", help="Project ID"),
    save_env: bool = typer.Option(True, "--save-env/--no-save-env", help="Save to .fluxloop/.env"),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="API base URL"),
    staging: bool = typer.Option(False, "--staging", help="Use staging API"),
):
    """Create a new API key for sync operations."""
    pid = require_current_web_project_id(
        project_id,
        resolver=get_current_web_project_id,
    )
    api_url = resolve_api_url(api_url, staging=staging)
    client = None

    try:
        client = create_client(api_url, use_jwt=True)

        payload: dict = {"project_id": pid}
        if name:
            payload["name"] = name

        resp = post_with_retry(client, "/api/api-keys", payload=payload)
        handle_api_error(resp, "create API key")

        data = resp.json()
        key_value = data.get("key", "")
        key_id = data.get("id", "")

        console.print(f"[green]✓[/green] API key created: [dim]{key_id}[/dim]")

        if key_value:
            console.print(f"  Key: [bold]{key_value}[/bold]")
            console.print("  [yellow]Save this key — it will not be shown again.[/yellow]")

        if save_env and key_value:
            _save_key_to_env(key_value)
            console.print("  [green]✓[/green] Saved to .fluxloop/.env")

    except Exception as e:
        console.print(f"[red]✗[/red] Failed to create API key: {e}")
        raise typer.Exit(1)
    finally:
        close_client(client)


@app.command("list")
def list_api_keys(
    project_id: Optional[str] = typer.Option(None, "--project-id", help="Project ID"),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="API base URL"),
    staging: bool = typer.Option(False, "--staging", help="Use staging API"),
):
    """List API keys for the current project."""
    pid = require_current_web_project_id(
        project_id,
        resolver=get_current_web_project_id,
    )
    api_url = resolve_api_url(api_url, staging=staging)
    client = None

    try:
        client = create_client(api_url, use_jwt=True)
        resp = get_with_retry(client, "/api/api-keys", params={"project_id": pid})
        handle_api_error(resp, "list API keys")

        keys = resp.json()
        if not keys:
            console.print("[yellow]No API keys found.[/yellow]")
            return

        table = Table(title="API Keys")
        table.add_column("ID", style="dim")
        table.add_column("Name")
        table.add_column("Created", style="dim")

        for k in keys:
            table.add_row(
                k.get("id", ""),
                k.get("name", "—"),
                k.get("created_at", "")[:10] if k.get("created_at") else "—",
            )

        console.print(table)

    except Exception as e:
        console.print(f"[red]✗[/red] Failed to list API keys: {e}")
        raise typer.Exit(1)
    finally:
        close_client(client)


def _save_key_to_env(key_value: str) -> None:
    fluxloop_dir = resolve_fluxloop_dir()
    env_path = fluxloop_dir / ".env"

    lines: list[str] = []
    replaced = False

    if env_path.exists():
        for line in env_path.read_text().splitlines():
            if line.startswith("FLUXLOOP_SYNC_API_KEY="):
                lines.append(f"FLUXLOOP_SYNC_API_KEY={key_value}")
                replaced = True
            else:
                lines.append(line)

    if not replaced:
        lines.append(f"FLUXLOOP_SYNC_API_KEY={key_value}")

    env_path.write_text("\n".join(lines) + "\n")
    env_path.chmod(FILE_PERMISSION)
