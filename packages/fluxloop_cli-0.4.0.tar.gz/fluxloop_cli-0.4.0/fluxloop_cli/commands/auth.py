"""Authentication commands."""

from __future__ import annotations

import sys
import webbrowser
from datetime import datetime, timezone
from typing import Optional

import typer
from rich.console import Console
from rich.live import Live
from rich.spinner import Spinner

from ..api_utils import resolve_api_url
from ..auth.device_flow import (
    DeviceFlowSession,
    ensure_valid_token,
    is_agent_environment,
    poll_for_approval,
    start_device_flow,
)
from ..auth.token_store import (
    delete_pending,
    delete_token,
    format_expires_at,
    is_token_expired,
    load_pending,
    load_token,
    save_pending,
    save_token,
)

app = typer.Typer(help="Manage authentication")
console = Console()


@app.command()
def login(
    api_url: Optional[str] = typer.Option(None, "--api-url", help="API base URL"),
    staging: bool = typer.Option(False, "--staging", help="Use staging API"),
    force: bool = typer.Option(False, "--force", "-f", help="Force re-login"),
    no_browser: bool = typer.Option(False, "--no-browser", help="Don't open browser"),
    no_wait: bool = typer.Option(
        False, "--no-wait", help="Print device code and exit without polling"
    ),
    resume: bool = typer.Option(False, "--resume", help="Resume pending login"),
):
    """Login to connect your FluxLoop account."""
    api_url = resolve_api_url(api_url, staging=staging)

    # Idempotent: skip if already logged in
    if not force:
        existing = load_token()
        if existing and not is_token_expired(existing):
            console.print(
                f"[green]✓[/green] Already logged in: [bold]{existing.user_email}[/bold]"
            )
            console.print(f"  Token expires: {format_expires_at(existing.expires_at)}")
            console.print("[dim]Use --force to re-login.[/dim]")
            return

    if resume:
        _handle_resume(api_url)
        return

    is_agent = is_agent_environment()

    try:
        session = start_device_flow(api_url)

        # Plain text output for agent compatibility
        print(flush=True)
        print("=" * 50, flush=True)
        print("FLUXLOOP LOGIN", flush=True)
        print("=" * 50, flush=True)
        print(f"URL:  {session.verification_url}", flush=True)
        print(f"CODE: {session.user_code}", flush=True)
        print("=" * 50, flush=True)
        print(flush=True)

        # Save pending login for --resume
        save_pending({
            "api_url": api_url,
            "device_code": session.device_code,
            "user_code": session.user_code,
            "verification_url": session.verification_url,
            "expires_in": session.expires_in_sec,
            "interval": session.interval_sec,
        })

        if not no_browser and not is_agent:
            try:
                webbrowser.open(session.verification_url)
                console.print("[dim]Browser opened automatically...[/dim]")
            except Exception:
                console.print("[dim]Please open the browser manually.[/dim]")

        if no_wait:
            console.print("[yellow]Login pending.[/yellow] Run:")
            console.print("[dim]  fluxloop auth login --resume[/dim]")
            return

        print("Waiting for approval...", flush=True)

        if sys.stdout.isatty() and not is_agent:
            spinner = Spinner("dots", text="Waiting for approval...")
            with Live(spinner, console=console, refresh_per_second=10):
                token = poll_for_approval(
                    api_url,
                    session.device_code,
                    interval_sec=session.interval_sec,
                    timeout_sec=session.expires_in_sec,
                )
        else:
            token = poll_for_approval(
                api_url,
                session.device_code,
                interval_sec=session.interval_sec,
                timeout_sec=session.expires_in_sec,
            )

        save_token(token)
        delete_pending()

        print(f"LOGIN_SUCCESS: {token.user_email}", flush=True)
        console.print(f"[green]✓[/green] Login successful: [bold]{token.user_email}[/bold]")
        console.print()
        console.print("[dim]Next steps:[/dim]")
        console.print("[dim]  fluxloop projects list[/dim]")
        console.print("[dim]  fluxloop projects select <id>[/dim]")

    except (TimeoutError, ValueError) as e:
        delete_pending()
        console.print(f"[red]✗[/red] {e}", style="bold red")
        raise typer.Exit(1)
    except Exception as e:
        delete_pending()
        console.print(f"[red]✗[/red] Login failed: {e}", style="bold red")
        raise typer.Exit(1)


def _handle_resume(api_url: str) -> None:
    pending = load_pending()
    if not pending:
        console.print("[red]✗[/red] No pending login. Run 'fluxloop auth login --no-wait' first.")
        raise typer.Exit(1)

    pending_api_url = pending.get("api_url") or api_url
    device_code = pending.get("device_code")
    if not device_code:
        console.print("[red]✗[/red] Pending login data is invalid.")
        delete_pending()
        raise typer.Exit(1)

    interval = pending.get("interval", 5)
    timeout = pending.get("expires_in", 300)

    try:
        token = poll_for_approval(
            pending_api_url, device_code, interval_sec=interval, timeout_sec=timeout
        )
        save_token(token)
        delete_pending()
        print(f"LOGIN_SUCCESS: {token.user_email}", flush=True)
        console.print(f"[green]✓[/green] Login successful: [bold]{token.user_email}[/bold]")
    except (TimeoutError, ValueError) as e:
        delete_pending()
        console.print(f"[red]✗[/red] {e}", style="bold red")
        raise typer.Exit(1)
    except Exception as e:
        delete_pending()
        console.print(f"[red]✗[/red] Login failed: {e}", style="bold red")
        raise typer.Exit(1)


@app.command()
def logout():
    """Logout and delete saved authentication."""
    token = load_token()
    if not token:
        console.print("[yellow]Already logged out.[/yellow]")
        return
    delete_token()
    console.print("[green]✓[/green] Logged out successfully")


@app.command()
def status():
    """Check current login status."""
    api_url = resolve_api_url()
    token = load_token()

    if not token:
        console.print("[yellow]Not logged in.[/yellow]")
        console.print("[dim]Run [bold]fluxloop auth login[/bold] to login.[/dim]")
        return

    if is_token_expired(token):
        console.print("[dim]Token expired, attempting refresh...[/dim]")
        refreshed = ensure_valid_token(api_url)
        if refreshed:
            token = refreshed
            console.print(
                f"[green]✓[/green] Logged in: [bold]{token.user_email}[/bold] (refreshed)"
            )
        else:
            console.print("[red]✗[/red] Token expired and refresh failed")
            console.print("[dim]Run [bold]fluxloop auth login[/bold] to login again.[/dim]")
            return
    else:
        console.print(f"[green]✓[/green] Logged in: [bold]{token.user_email}[/bold]")

    console.print(f"  Token expires: {format_expires_at(token.expires_at)}")

    from ..workspace.context import load_context, load_project_connection

    conn = load_project_connection()
    if conn:
        console.print(f"  Project: {conn.project_name} ([dim]{conn.project_id}[/dim])")

    ctx = load_context()
    if ctx and ctx.current_scenario:
        console.print(f"  Scenario: {ctx.current_scenario}")
