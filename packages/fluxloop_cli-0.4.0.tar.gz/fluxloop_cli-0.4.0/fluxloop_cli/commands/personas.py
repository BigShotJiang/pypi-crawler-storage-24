"""Persona management commands."""

from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from ..api_utils import handle_api_error, resolve_api_url
from ..sync.client import close_client, create_client, get_with_retry, post_with_retry
from ..workspace.context import (
    get_current_scenario_id,
    get_current_web_project_id,
    require_current_web_project_id,
)

app = typer.Typer(help="Manage personas")
console = Console()

@app.command("suggest")
def suggest_personas(
    scenario_id: Optional[str] = typer.Option(None, "--scenario-id", help="Scenario ID"),
    count: int = typer.Option(3, "--count", "-c", help="Number of personas to suggest"),
    project_id: Optional[str] = typer.Option(None, "--project-id", help="Project ID"),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="API base URL"),
    staging: bool = typer.Option(False, "--staging", help="Use staging API"),
):
    """Suggest personas for a scenario using LLM."""
    pid = require_current_web_project_id(
        project_id,
        resolver=get_current_web_project_id,
    )
    sid = scenario_id or get_current_scenario_id()
    if not sid:
        console.print("[red]✗[/red] No scenario selected.")
        console.print("[dim]Use --scenario-id or run 'fluxloop scenarios select <id>'[/dim]")
        raise typer.Exit(1)

    api_url = resolve_api_url(api_url, staging=staging)
    client = None

    try:
        client = create_client(api_url, use_jwt=True)

        payload = {
            "project_id": pid,
            "scenario_id": sid,
            "count": count,
        }

        with console.status("Suggesting personas..."):
            resp = post_with_retry(client, "/api/personas/suggest", payload=payload)
        handle_api_error(resp, "suggest personas")

        data = resp.json()
        personas = data.get("personas", [])
        persona_ids = data.get("persona_ids", [])

        console.print(f"[green]✓[/green] Suggested {len(personas)} persona(s)")

        for p in personas:
            name = p.get("name", "Unknown")
            pid_val = p.get("id", "")
            console.print(f"  - {name} ([dim]{pid_val}[/dim])")

        if persona_ids:
            console.print(f"\n  IDs: {', '.join(persona_ids)}")

    except Exception as e:
        console.print(f"[red]✗[/red] Failed to suggest personas: {e}")
        raise typer.Exit(1)
    finally:
        close_client(client)


@app.command("list")
def list_personas(
    project_id: Optional[str] = typer.Option(None, "--project-id", help="Project ID"),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="API base URL"),
    staging: bool = typer.Option(False, "--staging", help="Use staging API"),
):
    """List personas for the current project."""
    pid = require_current_web_project_id(
        project_id,
        resolver=get_current_web_project_id,
    )
    api_url = resolve_api_url(api_url, staging=staging)
    client = None

    try:
        client = create_client(api_url, use_jwt=True)
        resp = get_with_retry(client, "/api/personas", params={"project_id": pid})
        handle_api_error(resp, "list personas")

        personas = resp.json()
        if not personas:
            console.print("[yellow]No personas found.[/yellow]")
            return

        table = Table(title="Personas")
        table.add_column("ID", style="dim")
        table.add_column("Name", style="bold")
        table.add_column("Type")

        for p in personas:
            table.add_row(
                p.get("id", ""),
                p.get("name", ""),
                p.get("type", "—"),
            )

        console.print(table)

    except Exception as e:
        console.print(f"[red]✗[/red] Failed to list personas: {e}")
        raise typer.Exit(1)
    finally:
        close_client(client)
