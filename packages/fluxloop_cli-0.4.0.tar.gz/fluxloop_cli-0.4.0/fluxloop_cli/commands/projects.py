"""Project management commands."""

from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from ..api_utils import handle_api_error, resolve_api_url
from ..sync.client import close_client, create_client, post_with_retry
from ..workspace.context import (
    get_current_web_project_id,
    load_project_connection,
    select_web_project,
)

app = typer.Typer(help="Manage projects")
console = Console()


def _resolve_workspace_id(client, workspace_id: str | None) -> str:
    if workspace_id:
        return workspace_id

    resp = client.get("/api/workspaces")
    handle_api_error(resp, "list workspaces")
    data = resp.json()
    workspaces = data if isinstance(data, list) else data.get("workspaces", [])

    if not workspaces:
        raise typer.BadParameter("No workspaces found. Create one in the web app first.")

    if len(workspaces) == 1:
        return workspaces[0].get("id")

    console.print("[yellow]Multiple workspaces detected.[/yellow]")
    for ws in workspaces:
        console.print(f"  - {ws.get('id', '')}: {ws.get('name', '')}")
    raise typer.BadParameter("Please specify --workspace-id.")


@app.command("list")
def list_projects(
    format: str = typer.Option("table", "--format", help="Output format (table, json)"),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="API base URL"),
    staging: bool = typer.Option(False, "--staging", help="Use staging API"),
):
    """List all projects you have access to."""
    api_url = resolve_api_url(api_url, staging=staging)
    client = None

    try:
        client = create_client(api_url, use_jwt=True)
        resp = client.get("/api/projects")
        handle_api_error(resp, "list projects")

        data = resp.json()
        projects = data.get("projects", data) if isinstance(data, dict) else data

        if not projects:
            console.print("[yellow]No projects found.[/yellow]")
            console.print("[dim]Create one with: fluxloop projects create --name <name>[/dim]")
            return

        if format == "json":
            import json

            console.print_json(json.dumps(projects, ensure_ascii=False, default=str))
            return

        workspace_project_id = get_current_web_project_id()

        table = Table(title="Projects")
        table.add_column("ID", style="dim")
        table.add_column("Name", style="bold")
        table.add_column("Selected", style="green")

        for project in projects:
            pid = project.get("id", "")
            pname = project.get("name", "")
            selected = "✓" if pid == workspace_project_id else ""
            table.add_row(pid, pname, selected)

        console.print(table)

    except Exception as e:
        console.print(f"[red]✗[/red] Failed to list projects: {e}", style="bold red")
        raise typer.Exit(1)
    finally:
        close_client(client)


@app.command("create")
def create_project(
    name: str = typer.Option(..., "--name", "-n", help="Project name"),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="Description"),
    workspace_id: Optional[str] = typer.Option(
        None, "--workspace-id", help="Workspace ID (if multiple)"
    ),
    language: str = typer.Option("en", "--language", "-l", help="Default language (en, ko)"),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="API base URL"),
    staging: bool = typer.Option(False, "--staging", help="Use staging API"),
    select: bool = typer.Option(True, "--select/--no-select", help="Auto-select after creation"),
):
    """Create a new project."""
    api_url = resolve_api_url(api_url, staging=staging)
    client = None

    try:
        client = create_client(api_url, use_jwt=True)
        resolved_workspace_id = _resolve_workspace_id(client, workspace_id)

        payload: dict = {
            "name": name,
            "workspace_id": resolved_workspace_id,
            "settings": {"language": language},
        }
        if description:
            payload["description"] = description

        resp = post_with_retry(client, "/api/projects", payload=payload)
        handle_api_error(resp, "create project")

        data = resp.json()
        project_id = data.get("id", "")
        project_name = data.get("name", name)

        console.print(f"[green]✓[/green] Project created: {project_name} ([dim]{project_id}[/dim])")
        print(f"PROJECT_CREATED: {project_id}")

        if select:
            select_web_project(
                project_id, project_name, api_url, workspace_id=resolved_workspace_id
            )
            console.print("[green]✓[/green] Project selected for this workspace")

    except Exception as e:
        console.print(f"[red]✗[/red] Failed to create project: {e}", style="bold red")
        raise typer.Exit(1)
    finally:
        close_client(client)


@app.command("select")
def select_project_cmd(
    project_id: str = typer.Argument(..., help="Project ID to select"),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="API base URL"),
    staging: bool = typer.Option(False, "--staging", help="Use staging API"),
):
    """Select a project for this workspace."""
    api_url = resolve_api_url(api_url, staging=staging)
    client = None

    try:
        client = create_client(api_url, use_jwt=True)
        resp = client.get(f"/api/projects/{project_id}")
        handle_api_error(resp, "get project")

        data = resp.json()
        project_name = data.get("name", project_id)
        workspace_id = data.get("workspace_id", "")

        select_web_project(project_id, project_name, api_url, workspace_id=workspace_id)

        console.print(f"[green]✓[/green] Selected project: {project_name}")
        console.print(f"  Project ID: [dim]{project_id}[/dim]")
        print(f"PROJECT_SELECTED: {project_id}")

        console.print()
        console.print("[dim]Next: fluxloop init scenario <name>[/dim]")

    except Exception as e:
        console.print(f"[red]✗[/red] Failed to select project: {e}", style="bold red")
        raise typer.Exit(1)
    finally:
        close_client(client)
