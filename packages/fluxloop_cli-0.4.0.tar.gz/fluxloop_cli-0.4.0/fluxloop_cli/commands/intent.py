"""Intent management commands."""

from __future__ import annotations

import json
from typing import Any, Optional

import httpx
import typer
from rich.console import Console
from rich.table import Table

from ..api_utils import resolve_api_url
from ..sync.client import FluxLoopAPIError, close_client, create_client
from ..sync.intent_api import refine_intent as refine_intent_api
from .scenario_resolution import resolve_scenario_payload
from ..workspace.context import (
    get_current_scenario_id,
    get_current_web_project_id,
    get_scenario_dir,
    require_current_web_project_id,
)

app = typer.Typer(help="Manage intents")
console = Console()


def _resolve_scenario_payload(
    client: httpx.Client,
    *,
    project_id: str,
    scenario_id: str | None,
) -> tuple[str | None, dict[str, Any] | None]:
    return resolve_scenario_payload(
        client,
        project_id=project_id,
        scenario_id=scenario_id,
    )


def _resolve_intent_source(
    scenario_payload: dict[str, Any] | None,
    explicit_intent: str | None,
) -> str:
    if explicit_intent and explicit_intent.strip():
        return explicit_intent.strip()
    if scenario_payload:
        config_snapshot = scenario_payload.get("config_snapshot")
        if isinstance(config_snapshot, dict):
            goal = config_snapshot.get("goal")
            if isinstance(goal, str) and goal.strip():
                return goal.strip()
        description = scenario_payload.get("description")
        if isinstance(description, str) and description.strip():
            return description.strip()
        name = scenario_payload.get("name")
        if isinstance(name, str) and name.strip():
            return name.strip()
    raise typer.BadParameter(
        "No refinement intent available. Use --intent or select a scenario with a goal."
    )


def _persist_refinement(
    *,
    scenario_payload: dict[str, Any] | None,
    refinement: dict[str, Any],
    apply: bool,
) -> None:
    if not scenario_payload:
        return

    scenario_name = str(scenario_payload.get("name") or "").strip()
    if not scenario_name:
        return

    scenario_dir = get_scenario_dir(scenario_name)
    scenario_dir.mkdir(parents=True, exist_ok=True)
    refinement_path = scenario_dir / "intent_refinement.json"
    refinement_path.write_text(json.dumps(refinement, indent=2, ensure_ascii=False))

    if apply:
        scenario_json = scenario_dir / "scenario.json"
        current_payload = scenario_payload
        if scenario_json.exists():
            try:
                loaded = json.loads(scenario_json.read_text())
                if isinstance(loaded, dict):
                    current_payload = loaded
            except json.JSONDecodeError:
                pass
        current_payload = dict(current_payload)
        current_payload["intent_refinement"] = refinement
        scenario_json.write_text(json.dumps(current_payload, indent=2, ensure_ascii=False))


@app.command("refine")
def refine_intent(
    intent: Optional[str] = typer.Option(None, "--intent", help="Intent text override"),
    scenario_id: Optional[str] = typer.Option(None, "--scenario-id", help="Server scenario ID"),
    bundle_version_id: Optional[str] = typer.Option(
        None, "--bundle-version-id", help="Bundle version ID"
    ),
    project_id: Optional[str] = typer.Option(None, "--project-id", help="Project ID"),
    apply: bool = typer.Option(False, "--apply/--no-apply", help="Apply refinement remotely"),
    output: str = typer.Option("table", "--output", help="table|json"),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="API base URL"),
    staging: bool = typer.Option(False, "--staging", help="Use staging API"),
) -> None:
    pid = require_current_web_project_id(
        project_id,
        resolver=get_current_web_project_id,
    )
    api_url_resolved = resolve_api_url(api_url, staging=staging)
    client = None

    try:
        client = create_client(api_url_resolved, use_jwt=True)
        sid, scenario_payload = _resolve_scenario_payload(
            client,
            project_id=pid,
            scenario_id=scenario_id or get_current_scenario_id(),
        )
        intent_text = _resolve_intent_source(scenario_payload, intent)

        refinement = refine_intent_api(
            client,
            project_id=pid,
            intent=intent_text,
            scenario_id=sid,
            bundle_version_id=bundle_version_id,
            apply=apply,
        )

        _persist_refinement(
            scenario_payload=scenario_payload,
            refinement=refinement,
            apply=apply,
        )

        if output == "json":
            console.print_json(json.dumps(refinement, ensure_ascii=False))
            return

        table = Table(title="Intent Refinement")
        table.add_column("Field", style="bold")
        table.add_column("Value")
        table.add_row("Intent", str(refinement.get("intent", "")))
        constraints = refinement.get("constraints", [])
        if isinstance(constraints, list) and constraints:
            table.add_row("Constraints", "\n".join(str(item) for item in constraints))
        table.add_row("Applied", "yes" if refinement.get("applied") else "no")
        console.print(table)

    except (FluxLoopAPIError, httpx.HTTPError, ValueError, typer.BadParameter) as e:
        console.print(f"[red]✗[/red] Failed to refine intent: {e}")
        raise typer.Exit(1)
    finally:
        close_client(client)
