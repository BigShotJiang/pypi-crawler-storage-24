"""Test command — pull, run, push in one step."""

from __future__ import annotations

import asyncio
import json
from datetime import datetime
from pathlib import Path
from typing import Optional

import httpx
import typer
from rich.console import Console
from rich.table import Table

from ..api_utils import resolve_api_url
from ..config.loader import (
    load_config,
    load_env_chain as _load_env_chain,
    revalidate_config,
)
from ..constants import RESULTS_DIR_NAME
from ..core.executor import create_executor
from ..path_safety import sanitize_result_name
from ..result.error_writer import ErrorWriter
from ..result.summary_writer import SummaryWriter
from ..sync.client import close_client, create_client
from ..sync.puller import SyncPuller
from ..sync.uploader import SyncUploader
from .scenario_resolution import (
    NO_SCENARIO_SELECTED_ERROR,
    ScenarioResolutionError,
    resolve_scenario_selection,
)
from ..workspace.context import (
    get_current_web_project_id,
    load_context,
    require_current_web_project_id,
    resolve_fluxloop_dir,
    update_context,
)
from .init import ensure_scenario_scaffold
from .run import _run_loop
from .sync_cmd import _resolve_bundle_version_id, _resolve_scenario_name

app = typer.Typer(help="Test workflow", invoke_without_command=True)
console = Console()


def _format_date(value: str | None, fallback: datetime | None = None) -> str:
    if value:
        return value[:10]
    if fallback is not None:
        return fallback.strftime("%Y-%m-%d")
    return "-"


def _format_duration_ms(value: object) -> str:
    if isinstance(value, (int, float)):
        return f"{float(value) / 1000:.1f}s"
    return "-"


def _format_success_rate(success_count: int, total_runs: int) -> str:
    if total_runs <= 0:
        return "-"
    return f"{(success_count / total_runs) * 100:.1f}%"


def _resolve_results_scenario(
    client: httpx.Client,
    *,
    project_id: str,
    scenario_id: str | None,
    scenario_name: str | None,
) -> tuple[str, str | None]:
    try:
        resolved_id, resolved_name, _ = resolve_scenario_selection(
            client,
            project_id=project_id,
            scenario_id=scenario_id,
            scenario_name=scenario_name,
            require=True,
            fetch_current_payload=True,
        )
    except ScenarioResolutionError as exc:
        if str(exc) == NO_SCENARIO_SELECTED_ERROR:
            console.print("[red]✗[/red] No scenario selected.")
            console.print(
                "[dim]Use --scenario-id, --scenario, or run 'fluxloop scenarios select <id>'[/dim]"
            )
        else:
            console.print(f"[red]✗[/red] {exc}")
        raise typer.Exit(1) from exc

    if not resolved_id:
        console.print("[red]✗[/red] Failed to resolve scenario.")
        raise typer.Exit(1)
    return resolved_id, resolved_name


def _collect_local_result_rows(
    results_root: Path,
    *,
    scenario_name: str | None,
    limit: int,
) -> list[dict[str, object]]:
    if not results_root.exists():
        return []

    rows: list[dict[str, object]] = []
    subdirs = sorted(
        [item for item in results_root.iterdir() if item.is_dir()],
        key=lambda path: path.stat().st_mtime,
        reverse=True,
    )

    for directory in subdirs:
        if scenario_name and not directory.name.startswith(f"{scenario_name}-"):
            continue

        summary_path = directory / "summary.json"
        if not summary_path.exists():
            continue

        try:
            summary = json.loads(summary_path.read_text())
        except json.JSONDecodeError:
            continue
        if not isinstance(summary, dict):
            continue

        total_runs = int(summary.get("total_runs") or 0)
        success_count = int(summary.get("success_count") or 0)
        created_at = summary.get("created_at")
        rows.append(
            {
                "directory": directory.name,
                "runs": total_runs,
                "success": _format_success_rate(success_count, total_runs),
                "duration": _format_duration_ms(summary.get("total_duration_ms")),
                "created": _format_date(
                    created_at if isinstance(created_at, str) else None,
                    datetime.fromtimestamp(directory.stat().st_mtime),
                ),
                "raw": summary,
            }
        )
        if len(rows) >= limit:
            break

    return rows


def _render_local_results_table(results_root: Path, rows: list[dict[str, object]]) -> None:
    console.print(f"Results in [dim]{results_root}[/dim]")
    console.print()

    table = Table()
    table.add_column("Directory", style="bold")
    table.add_column("Runs", justify="right")
    table.add_column("Success", justify="right")
    table.add_column("Duration", justify="right")
    table.add_column("Created", style="dim")

    for row in rows:
        table.add_row(
            str(row["directory"]),
            str(row["runs"]),
            str(row["success"]),
            str(row["duration"]),
            str(row["created"]),
        )

    console.print(table)


def _render_remote_results_table(
    *,
    scenario_label: str,
    rows: list[dict[str, object]],
) -> None:
    console.print(f"Scenario: {scenario_label}")
    console.print()

    table = Table()
    table.add_column("Experiment ID", style="bold")
    table.add_column("Runs", justify="right")
    table.add_column("Success", justify="right")
    table.add_column("Verdict")
    table.add_column("Created", style="dim")

    for row in rows:
        table.add_row(
            str(row["experiment_id"]),
            str(row["runs"]),
            str(row["success"]),
            str(row["verdict"]),
            str(row["created"]),
        )

    console.print(table)


def _run_test_workflow(
    *,
    scenario: str | None,
    iterations: int | None,
    skip_pull: bool,
    skip_push: bool,
    project_id: str | None,
    bundle_version_id: str | None,
    verbose: bool,
    api_url: str | None,
    staging: bool,
) -> None:
    """Run a full test cycle: pull -> run -> push."""
    scenario_name = _resolve_scenario_name(scenario)
    scenario_dir = ensure_scenario_scaffold(scenario_name)
    update_context({"current_scenario": scenario_name})

    api_url_resolved = resolve_api_url(api_url, staging=staging)
    pid = project_id or get_current_web_project_id()

    # 1. Pull
    if not skip_pull:
        resolved_bundle_version_id = _resolve_bundle_version_id(
            api_url=api_url_resolved,
            scenario_name=scenario_name,
            project_id=pid,
            explicit_bundle_version_id=bundle_version_id,
        )
        client = None

        try:
            client = create_client(api_url_resolved, use_jwt=False)
            puller = SyncPuller(client)
            with console.status("Pulling data from server..."):
                pull_data = puller.pull(
                    scenario_dir,
                    bundle_version_id=resolved_bundle_version_id,
                    project_id=pid,
                )
            bv_id = pull_data.get("bundle_version", {}).get("id", "")
            scenario_payload = pull_data.get("scenario_context", {}).get("scenario", {})
            scenario_id = scenario_payload.get("id")
            pulled_scenario_name = scenario_payload.get("name")
            input_set_id = pull_data.get("input_set", {}).get("id", "")
            context_updates: dict[str, str | None] = {}
            if pulled_scenario_name:
                context_updates["current_scenario"] = str(pulled_scenario_name)
            if scenario_id:
                context_updates["current_scenario_id"] = str(scenario_id)
            if input_set_id:
                context_updates["current_input_set_id"] = str(input_set_id)
            if bv_id:
                context_updates["current_bundle_version_id"] = str(bv_id)
            if context_updates:
                update_context(context_updates)
            input_count = len(pull_data.get("input_items", []))
            console.print(f"[green]✓[/green] Pulled {input_count} inputs")
        except Exception as e:
            console.print(f"[red]✗[/red] Pull failed: {e}")
            raise typer.Exit(1)
        finally:
            close_client(client)

    # 2. Load config and run
    _load_env_chain(scenario_dir)

    try:
        config = load_config(scenario_dir, prefer_pulled=True)
    except (FileNotFoundError, ValueError) as e:
        console.print(f"[red]✗[/red] Config error: {e}")
        raise typer.Exit(1)

    if iterations is not None:
        try:
            config = revalidate_config(config, iterations=iterations)
        except ValueError as e:
            console.print(f"[red]✗[/red] Config error: {e}")
            raise typer.Exit(1)

    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    fluxloop_dir = resolve_fluxloop_dir()
    result_name = sanitize_result_name(config.name)
    output_dir = fluxloop_dir / RESULTS_DIR_NAME / f"{result_name}-{timestamp}"

    try:
        executor = create_executor(config.runner)
    except (ValueError, NotImplementedError) as e:
        console.print(f"[red]✗[/red] {e}")
        raise typer.Exit(1)

    inputs = config.input.items
    if not inputs:
        console.print("[red]✗[/red] No input items found.")
        raise typer.Exit(1)

    total_runs = config.iterations * len(inputs)
    if verbose:
        console.print(f"  Scenario:    {scenario_name}")
        console.print(f"  Inputs:      {len(inputs)}")
        console.print(f"  Total runs:  {total_runs}")
        console.print()

    results = asyncio.run(
        _run_loop(executor, config, inputs, output_dir, total_runs, verbose)
    )

    summary_writer = SummaryWriter()
    summary_writer.write(output_dir, config, results)
    ErrorWriter().write(output_dir, config)

    success_count = sum(1 for r in results if r.success)
    avg_duration = sum(r.duration_ms for r in results) / len(results) if results else 0

    console.print(
        f"[green]✓[/green] Completed: {success_count}/{len(results)} successful "
        f"(avg {avg_duration / 1000:.1f}s)"
    )
    console.print(f"  Results: {output_dir}")

    # 3. Push
    if not skip_push:
        client = None
        try:
            client = create_client(api_url_resolved, use_jwt=False)
            uploader = SyncUploader(client)
            with console.status("Uploading results..."):
                upload_data = uploader.upload_from_result_dir(output_dir, scenario_dir)
            run_batch_id = upload_data.get("run_batch_id", "")
            console.print(
                f"[green]✓[/green] Results uploaded (batch: [dim]{run_batch_id}[/dim])"
            )
        except Exception as e:
            console.print(f"[yellow]⚠[/yellow] Push failed: {e}")
            raise typer.Exit(1)
        finally:
            close_client(client)


@app.callback(invoke_without_command=True)
def test_root(
    ctx: typer.Context,
    scenario: Optional[str] = typer.Option(None, "--scenario", "-s", help="Scenario name"),
    iterations: Optional[int] = typer.Option(
        None, "--iterations", "-i", help="Override iterations"
    ),
    skip_pull: bool = typer.Option(False, "--skip-pull", help="Skip sync pull"),
    skip_push: bool = typer.Option(False, "--skip-push", help="Skip sync push"),
    project_id: Optional[str] = typer.Option(None, "--project-id", help="Project ID"),
    bundle_version_id: Optional[str] = typer.Option(
        None, "--bundle-version-id", help="Specific bundle version to pull"
    ),
    verbose: bool = typer.Option(False, "--verbose", help="Verbose output"),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="API base URL"),
    staging: bool = typer.Option(False, "--staging", help="Use staging API"),
) -> None:
    """Run a full test cycle by default."""
    if ctx.invoked_subcommand:
        return
    _run_test_workflow(
        scenario=scenario,
        iterations=iterations,
        skip_pull=skip_pull,
        skip_push=skip_push,
        project_id=project_id,
        bundle_version_id=bundle_version_id,
        verbose=verbose,
        api_url=api_url,
        staging=staging,
    )


@app.command("run")
def test_command(
    scenario: Optional[str] = typer.Option(None, "--scenario", "-s", help="Scenario name"),
    iterations: Optional[int] = typer.Option(
        None, "--iterations", "-i", help="Override iterations"
    ),
    skip_pull: bool = typer.Option(False, "--skip-pull", help="Skip sync pull"),
    skip_push: bool = typer.Option(False, "--skip-push", help="Skip sync push"),
    project_id: Optional[str] = typer.Option(None, "--project-id", help="Project ID"),
    bundle_version_id: Optional[str] = typer.Option(
        None, "--bundle-version-id", help="Specific bundle version to pull"
    ),
    verbose: bool = typer.Option(False, "--verbose", help="Verbose output"),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="API base URL"),
    staging: bool = typer.Option(False, "--staging", help="Use staging API"),
) -> None:
    """Run a full test cycle: pull -> run -> push."""
    _run_test_workflow(
        scenario=scenario,
        iterations=iterations,
        skip_pull=skip_pull,
        skip_push=skip_push,
        project_id=project_id,
        bundle_version_id=bundle_version_id,
        verbose=verbose,
        api_url=api_url,
        staging=staging,
    )


@app.command("results")
def test_results(
    scenario_id: Optional[str] = typer.Option(None, "--scenario-id", help="Server scenario ID"),
    scenario: Optional[str] = typer.Option(None, "--scenario", help="Local scenario folder name"),
    raw: bool = typer.Option(False, "--raw", help="Raw JSON output"),
    local: bool = typer.Option(False, "--local", help="Show local results only"),
    limit: int = typer.Option(10, "--limit", help="Limit number of results"),
) -> None:
    """Show test results."""
    if local:
        fluxloop_dir = resolve_fluxloop_dir()
        results_root = fluxloop_dir / RESULTS_DIR_NAME
        ctx = load_context()
        scenario_name = scenario or (ctx.current_scenario if ctx else None)
        rows = _collect_local_result_rows(results_root, scenario_name=scenario_name, limit=limit)
        if raw:
            console.print_json(json.dumps(rows, ensure_ascii=False))
            return
        if not rows:
            console.print("[yellow]No local results found.[/yellow]")
            return
        _render_local_results_table(results_root, rows)
        return

    project_id = require_current_web_project_id(
        resolver=get_current_web_project_id,
    )
    client = None

    try:
        client = create_client(resolve_api_url(None), use_jwt=True)
        resolved_scenario_id, resolved_scenario_name = _resolve_results_scenario(
            client,
            project_id=project_id,
            scenario_id=scenario_id,
            scenario_name=scenario,
        )
        response = client.get(
            "/api/experiments",
            params={
                "project_id": project_id,
                "scenario_id": resolved_scenario_id,
                "limit": limit,
                "offset": 0,
            },
        )
        response.raise_for_status()
        payload = response.json()
        if raw:
            console.print_json(json.dumps(payload, ensure_ascii=False))
            return
        if not isinstance(payload, list) or not payload:
            console.print("[yellow]No server results found.[/yellow]")
            return

        rows: list[dict[str, object]] = []
        for item in payload:
            if not isinstance(item, dict):
                continue
            summary = item.get("summary")
            evaluation = item.get("evaluation")
            if not isinstance(summary, dict):
                summary = {}
            if not isinstance(evaluation, dict):
                evaluation = {}
            total_runs = int(summary.get("total_runs") or 0)
            completed_runs = int(summary.get("completed_runs") or 0)
            rows.append(
                {
                    "experiment_id": str(item.get("experiment_id") or ""),
                    "runs": total_runs,
                    "success": f"{completed_runs}/{total_runs}" if total_runs > 0 else "-",
                    "verdict": str(evaluation.get("verdict") or "unknown"),
                    "created": _format_date(
                        item.get("created_at") if isinstance(item.get("created_at"), str) else None
                    ),
                }
            )

        if not rows:
            console.print("[yellow]No server results found.[/yellow]")
            return

        scenario_label = (
            f"{resolved_scenario_name} ({resolved_scenario_id})"
            if resolved_scenario_name
            else resolved_scenario_id
        )
        _render_remote_results_table(scenario_label=scenario_label, rows=rows)
    except (httpx.HTTPError, ValueError) as e:
        console.print(f"[red]✗[/red] Failed to fetch results: {e}")
        raise typer.Exit(1)
    finally:
        close_client(client)
