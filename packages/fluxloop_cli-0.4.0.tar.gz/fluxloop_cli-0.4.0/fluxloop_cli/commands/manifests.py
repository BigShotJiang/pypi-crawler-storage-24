"""Manifest management commands."""

from __future__ import annotations

import json
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from ..api_utils import handle_api_error, resolve_api_url
from ..sync.client import close_client, create_client, get_with_retry, post_with_retry
from ..workspace.context import get_current_scenario_id

app = typer.Typer(help="Manage manifests")
console = Console()


def _require_scenario_id(scenario_id: str | None) -> str:
    sid = scenario_id or get_current_scenario_id()
    if not sid:
        console.print("[red]✗[/red] No scenario selected.")
        console.print("[dim]Use --scenario-id or run 'fluxloop scenarios select <id>'[/dim]")
        raise typer.Exit(1)
    return sid


@app.command("show")
def show_manifest(
    scenario_id: Optional[str] = typer.Option(None, "--scenario-id", help="Scenario ID"),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="API base URL"),
    staging: bool = typer.Option(False, "--staging", help="Use staging API"),
):
    """Show the current manifest for a scenario."""
    sid = _require_scenario_id(scenario_id)
    api_url = resolve_api_url(api_url, staging=staging)
    client = None

    try:
        client = create_client(api_url, use_jwt=True)
        resp = get_with_retry(client, f"/api/scenarios/{sid}/manifest")
        handle_api_error(resp, "get manifest")

        data = resp.json()
        console.print_json(json.dumps(data, indent=2, ensure_ascii=False, default=str))

    except Exception as e:
        console.print(f"[red]✗[/red] Failed to get manifest: {e}")
        raise typer.Exit(1)
    finally:
        close_client(client)


@app.command("publish")
def publish_manifest(
    scenario_id: Optional[str] = typer.Option(None, "--scenario-id", help="Scenario ID"),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="API base URL"),
    staging: bool = typer.Option(False, "--staging", help="Use staging API"),
):
    """Publish the draft manifest as a versioned snapshot."""
    sid = _require_scenario_id(scenario_id)
    api_url = resolve_api_url(api_url, staging=staging)
    client = None

    try:
        client = create_client(api_url, use_jwt=True)
        resp = post_with_retry(client, f"/api/scenarios/{sid}/manifest/publish", payload={})
        handle_api_error(resp, "publish manifest")

        data = resp.json()
        version = data.get("version")
        manifest_id = data.get("id", "")

        console.print(f"[green]✓[/green] Manifest published")
        console.print(f"  ID: [dim]{manifest_id}[/dim]")
        if version is not None:
            console.print(f"  Version: {version}")

    except Exception as e:
        console.print(f"[red]✗[/red] Failed to publish manifest: {e}")
        raise typer.Exit(1)
    finally:
        close_client(client)


@app.command("changelog")
def manifest_changelog(
    scenario_id: Optional[str] = typer.Option(None, "--scenario-id", help="Scenario ID"),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="API base URL"),
    staging: bool = typer.Option(False, "--staging", help="Use staging API"),
):
    """Show manifest changelog."""
    sid = _require_scenario_id(scenario_id)
    api_url = resolve_api_url(api_url, staging=staging)
    client = None

    try:
        client = create_client(api_url, use_jwt=True)
        resp = get_with_retry(client, f"/api/scenarios/{sid}/manifest/changelog")
        handle_api_error(resp, "get changelog")

        entries = resp.json()
        if not entries:
            console.print("[yellow]No changelog entries.[/yellow]")
            return

        for entry in entries:
            version = entry.get("version", "?")
            summary = entry.get("summary", entry.get("change_summary", ""))
            console.print(f"  v{version}: {summary}")

    except Exception as e:
        console.print(f"[red]✗[/red] Failed to get changelog: {e}")
        raise typer.Exit(1)
    finally:
        close_client(client)


@app.command("versions")
def manifest_versions(
    scenario_id: Optional[str] = typer.Option(None, "--scenario-id", help="Scenario ID"),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="API base URL"),
    staging: bool = typer.Option(False, "--staging", help="Use staging API"),
):
    """List published manifest versions."""
    sid = _require_scenario_id(scenario_id)
    api_url = resolve_api_url(api_url, staging=staging)
    client = None

    try:
        client = create_client(api_url, use_jwt=True)
        resp = get_with_retry(client, f"/api/scenarios/{sid}/manifest/versions")
        handle_api_error(resp, "list manifest versions")

        versions = resp.json()
        if not versions:
            console.print("[yellow]No published versions.[/yellow]")
            return

        table = Table(title="Manifest Versions")
        table.add_column("Version")
        table.add_column("ID", style="dim")
        table.add_column("Published", style="dim")

        for v in versions:
            table.add_row(
                str(v.get("version", "")),
                v.get("id", ""),
                v.get("published_at", "")[:10] if v.get("published_at") else "—",
            )

        console.print(table)

    except Exception as e:
        console.print(f"[red]✗[/red] Failed to list versions: {e}")
        raise typer.Exit(1)
    finally:
        close_client(client)
