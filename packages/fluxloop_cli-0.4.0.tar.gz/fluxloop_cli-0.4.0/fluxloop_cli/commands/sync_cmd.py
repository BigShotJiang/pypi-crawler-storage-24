"""Sync commands — pull and push data between CLI and server."""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import typer
from rich.console import Console

from ..api_utils import handle_api_error, resolve_api_url
from ..sync.client import close_client, create_client, get_with_retry
from ..sync.puller import SyncPuller
from ..sync.uploader import SyncUploader
from .scenario_resolution import resolve_scenario_id_by_name
from .init import ensure_scenario_scaffold
from ..workspace.context import (
    get_current_web_project_id,
    get_scenario_dir,
    load_context,
    update_context,
)

app = typer.Typer(help="Sync data with server")
console = Console()


def _resolve_scenario_name(scenario: str | None) -> str:
    scenario_name = scenario
    if not scenario_name:
        ctx = load_context()
        if ctx and ctx.current_scenario:
            scenario_name = ctx.current_scenario
    if not scenario_name:
        console.print("[red]✗[/red] No scenario specified.")
        console.print("[dim]Use --scenario <name> or run 'fluxloop init scenario <name>'[/dim]")
        raise typer.Exit(1)
    return scenario_name


def _resolve_bundle_version_id(
    *,
    api_url: str,
    scenario_name: str,
    project_id: str | None,
    explicit_bundle_version_id: str | None,
) -> str:
    if explicit_bundle_version_id:
        return explicit_bundle_version_id

    scenario_dir = get_scenario_dir(scenario_name)
    previous_bundle_version = SyncPuller.get_bundle_version_id(scenario_dir)
    if previous_bundle_version:
        return previous_bundle_version

    if not project_id:
        console.print(
            "[red]✗[/red] Cannot resolve bundle version without a project context."
        )
        console.print(
            "[dim]Use --bundle-version-id, select a project, or run 'fluxloop auth login'.[/dim]"
        )
        raise typer.Exit(1)

    scenario_id = _lookup_scenario_id(api_url, project_id, scenario_name)
    if not scenario_id:
        console.print(
            f"[red]✗[/red] Could not resolve scenario '{scenario_name}' on the server."
        )
        console.print(
            "[dim]Run 'fluxloop scenarios select <id>' or pass --bundle-version-id.[/dim]"
        )
        raise typer.Exit(1)

    bundle_version_id = _lookup_latest_bundle_version_id(api_url, project_id, scenario_id)
    if not bundle_version_id:
        console.print(
            f"[red]✗[/red] No published bundle found for scenario '{scenario_name}'."
        )
        console.print("[dim]Publish a bundle first or pass --bundle-version-id.[/dim]")
        raise typer.Exit(1)

    return bundle_version_id


def _lookup_scenario_id(api_url: str, project_id: str, scenario_name: str) -> str | None:
    try:
        client = create_client(api_url, use_jwt=True)
    except Exception:
        return None
    try:
        return resolve_scenario_id_by_name(
            client,
            project_id=project_id,
            scenario_name=scenario_name,
        )
    except Exception:
        return None
    finally:
        close_client(client)


def _lookup_latest_bundle_version_id(
    api_url: str,
    project_id: str,
    scenario_id: str,
) -> str | None:
    try:
        client = create_client(api_url, use_jwt=True)
    except Exception:
        return None
    try:
        resp = get_with_retry(
            client,
            "/api/bundles",
            params={"project_id": project_id, "scenario_id": scenario_id, "limit": 1},
        )
        handle_api_error(resp, "list bundles")
        bundles = resp.json()
        if bundles:
            return bundles[0].get("id")
    except Exception:
        return None
    finally:
        close_client(client)
    return None


@app.command("pull")
def pull_command(
    scenario: Optional[str] = typer.Option(None, "--scenario", "-s", help="Scenario name"),
    bundle_version_id: Optional[str] = typer.Option(
        None, "--bundle-version-id", help="Specific bundle version"
    ),
    project_id: Optional[str] = typer.Option(None, "--project-id", help="Project ID"),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="API base URL"),
    staging: bool = typer.Option(False, "--staging", help="Use staging API"),
):
    """Pull test data from server to local pulled/ directory."""
    scenario_name = _resolve_scenario_name(scenario)
    scenario_dir = ensure_scenario_scaffold(scenario_name)
    pid = project_id or get_current_web_project_id()
    api_url = resolve_api_url(api_url, staging=staging)
    resolved_bundle_version_id = _resolve_bundle_version_id(
        api_url=api_url,
        scenario_name=scenario_name,
        project_id=pid,
        explicit_bundle_version_id=bundle_version_id,
    )
    client = None

    try:
        client = create_client(api_url, use_jwt=False)
        puller = SyncPuller(client)

        with console.status("Pulling data from server..."):
            data = puller.pull(
                scenario_dir,
                bundle_version_id=resolved_bundle_version_id,
                project_id=pid,
            )

        bv = data.get("bundle_version", {})
        bv_id = bv.get("id", "")
        scenario_payload = data.get("scenario_context", {}).get("scenario", {})
        scenario_id = scenario_payload.get("id")
        pulled_scenario_name = scenario_payload.get("name")
        input_set_id = data.get("input_set", {}).get("id", "")
        input_count = len(data.get("input_items", []))
        persona_count = len(data.get("personas", []))
        criteria_count = len(data.get("criteria_pack", []))

        context_updates = {
            "current_scenario": str(pulled_scenario_name or scenario_name),
        }
        if scenario_id:
            context_updates["current_scenario_id"] = str(scenario_id)
        if input_set_id:
            context_updates["current_input_set_id"] = str(input_set_id)
        if bv_id:
            context_updates["current_bundle_version_id"] = str(bv_id)
        update_context(context_updates)

        console.print("[green]✓[/green] Pulled successfully")
        console.print(f"  Bundle version: [dim]{bv_id}[/dim]")
        console.print(f"  Inputs: {input_count}, Personas: {persona_count}, Criteria: {criteria_count}")
        console.print(f"  Location: {scenario_dir / 'pulled'}")

    except Exception as e:
        console.print(f"[red]✗[/red] Failed to pull: {e}")
        raise typer.Exit(1)
    finally:
        close_client(client)


@app.command("push")
def push_command(
    scenario: Optional[str] = typer.Option(None, "--scenario", "-s", help="Scenario name"),
    result_dir: Optional[str] = typer.Option(None, "--result-dir", help="Result directory path"),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="API base URL"),
    staging: bool = typer.Option(False, "--staging", help="Use staging API"),
):
    """Push local results to server."""
    from ..constants import RESULTS_DIR_NAME
    from ..workspace.context import resolve_fluxloop_dir

    scenario_name = _resolve_scenario_name(scenario)
    scenario_dir = get_scenario_dir(scenario_name)

    # Resolve result directory
    if result_dir:
        rdir = Path(result_dir)
    else:
        fluxloop_dir = resolve_fluxloop_dir()
        results_root = fluxloop_dir / RESULTS_DIR_NAME
        if not results_root.exists():
            console.print("[red]✗[/red] No results directory found.")
            raise typer.Exit(1)
        # Find most recent result dir
        subdirs = sorted(results_root.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True)
        if not subdirs:
            console.print("[red]✗[/red] No result directories found.")
            raise typer.Exit(1)
        rdir = subdirs[0]

    if not rdir.exists():
        console.print(f"[red]✗[/red] Result directory not found: {rdir}")
        raise typer.Exit(1)

    api_url = resolve_api_url(api_url, staging=staging)
    client = None

    try:
        client = create_client(api_url, use_jwt=False)
        uploader = SyncUploader(client)

        with console.status("Uploading results..."):
            data = uploader.upload_from_result_dir(rdir, scenario_dir)

        run_batch_id = data.get("run_batch_id", "")
        run_count = len(data.get("run_ids", []))
        quick_gate = data.get("quick_gate")

        console.print("[green]✓[/green] Results uploaded")
        console.print(f"  Run batch: [dim]{run_batch_id}[/dim]")
        console.print(f"  Runs: {run_count}")

        if quick_gate:
            pass_rate = quick_gate.get("gate_pass_rate")
            if pass_rate is not None:
                console.print(f"  Gate pass rate: {pass_rate:.1%}")

    except Exception as e:
        console.print(f"[red]✗[/red] Failed to push: {e}")
        raise typer.Exit(1)
    finally:
        close_client(client)
