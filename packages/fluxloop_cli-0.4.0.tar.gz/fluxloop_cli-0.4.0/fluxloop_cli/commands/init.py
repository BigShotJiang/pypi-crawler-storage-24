"""Initialization commands."""

from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any

import typer
from rich.console import Console
from ruamel.yaml import YAML

from ..constants import CONFIG_DIRECTORY_NAME
from ..workspace.context import get_scenario_dir, set_current_scenario

app = typer.Typer(help="Initialize resources")
console = Console()

SIMULATION_TEMPLATE = {
    "name": None,  # replaced at runtime
    "runner": {
        "type": "function",
        "target": "my_agent:handler",
    },
    "iterations": 1,
    "input": {
        "source": "inline",
        "items": [
            {"text": "Hello"},
        ],
    },
}


def build_scenario_template(
    name: str,
    *,
    config_snapshot: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build a runnable local simulation template for a scenario."""
    template = deepcopy(SIMULATION_TEMPLATE)
    template["name"] = name

    if isinstance(config_snapshot, dict):
        for key in ("name", "runner", "iterations", "input"):
            if key in config_snapshot:
                template[key] = deepcopy(config_snapshot[key])

    return template


def ensure_scenario_scaffold(
    name: str,
    *,
    base_dir: Path | None = None,
    config_snapshot: dict[str, Any] | None = None,
) -> Path:
    """Ensure a scenario folder with configs/simulation.yaml exists."""
    scenario_dir = get_scenario_dir(name, base_dir)
    configs_dir = scenario_dir / CONFIG_DIRECTORY_NAME
    configs_dir.mkdir(parents=True, exist_ok=True)

    simulation_path = configs_dir / "simulation.yaml"
    if not simulation_path.exists():
        yaml = YAML()
        yaml.default_flow_style = False
        with open(simulation_path, "w", encoding="utf-8") as f:
            yaml.dump(
                build_scenario_template(name, config_snapshot=config_snapshot),
                f,
            )

    return scenario_dir


@app.command("scenario")
def init_scenario(
    name: str = typer.Argument(..., help="Scenario name"),
):
    """Initialize a new scenario folder with default config."""
    scenario_dir = get_scenario_dir(name)

    if scenario_dir.exists():
        console.print(f"[yellow]Scenario '{name}' already exists at {scenario_dir}[/yellow]")
        raise typer.Exit(1)

    scenario_dir = ensure_scenario_scaffold(name)
    simulation_path = scenario_dir / CONFIG_DIRECTORY_NAME / "simulation.yaml"

    set_current_scenario(name)

    console.print(f"[green]✓[/green] Initialized scenario: [bold]{name}[/bold]")
    console.print(f"  Path: {scenario_dir}")
    console.print()
    console.print("[dim]Edit the config:[/dim]")
    console.print(f"[dim]  {simulation_path}[/dim]")
    console.print()
    console.print("[dim]Then run:[/dim]")
    console.print("[dim]  fluxloop run[/dim]")
