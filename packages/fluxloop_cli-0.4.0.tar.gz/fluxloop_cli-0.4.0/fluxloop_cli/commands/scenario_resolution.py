"""Shared helpers for resolving scenario identifiers and payloads."""

from __future__ import annotations

from typing import Any

import httpx

from ..workspace.context import load_context

NO_SCENARIO_SELECTED_ERROR = "No scenario selected."
LIST_SCENARIOS_ERROR = "Failed to list scenarios."


class ScenarioResolutionError(RuntimeError):
    """Raised when a scenario selection cannot be resolved locally."""


def _fetch_scenario_payload(
    client: httpx.Client,
    scenario_id: str,
) -> dict[str, Any] | None:
    response = client.get(f"/api/scenarios/{scenario_id}")
    response.raise_for_status()
    payload = response.json()
    return payload if isinstance(payload, dict) else None


def _list_project_scenarios(
    client: httpx.Client,
    *,
    project_id: str,
) -> list[dict[str, Any]]:
    response = client.get("/api/scenarios", params={"project_id": project_id})
    response.raise_for_status()
    scenarios = response.json()
    if not isinstance(scenarios, list):
        raise ScenarioResolutionError(LIST_SCENARIOS_ERROR)
    return [item for item in scenarios if isinstance(item, dict)]


def _find_project_scenario_by_name(
    client: httpx.Client,
    *,
    project_id: str,
    scenario_name: str,
) -> dict[str, Any] | None:
    for item in _list_project_scenarios(client, project_id=project_id):
        if str(item.get("name") or "") == scenario_name:
            return item
    return None


def resolve_scenario_selection(
    client: httpx.Client,
    *,
    project_id: str,
    scenario_id: str | None,
    scenario_name: str | None,
    require: bool = True,
    fetch_current_payload: bool = False,
) -> tuple[str | None, str | None, dict[str, Any] | None]:
    if scenario_id:
        payload = _fetch_scenario_payload(client, scenario_id)
        name = payload.get("name") if payload else None
        return scenario_id, name if isinstance(name, str) else None, payload

    ctx = load_context()
    if scenario_name is None and ctx and ctx.current_scenario_id:
        if fetch_current_payload:
            payload = _fetch_scenario_payload(client, ctx.current_scenario_id)
            name = payload.get("name") if payload else None
            return (
                ctx.current_scenario_id,
                name if isinstance(name, str) else ctx.current_scenario,
                payload,
            )
        return ctx.current_scenario_id, ctx.current_scenario, None

    if scenario_name is None and not require:
        return None, None, None

    target_name = scenario_name or (ctx.current_scenario if ctx else None)
    if not target_name:
        if require:
            raise ScenarioResolutionError(NO_SCENARIO_SELECTED_ERROR)
        return None, None, None

    match = _find_project_scenario_by_name(
        client,
        project_id=project_id,
        scenario_name=target_name,
    )
    resolved_id = str(match.get("id") or "") if match else ""
    if resolved_id:
        return resolved_id, target_name, match

    if require:
        raise ScenarioResolutionError(f"Scenario not found: {target_name}")
    return None, None, None


def resolve_scenario_payload(
    client: httpx.Client,
    *,
    project_id: str,
    scenario_id: str | None,
) -> tuple[str | None, dict[str, Any] | None]:
    if scenario_id:
        return scenario_id, _fetch_scenario_payload(client, scenario_id)

    ctx = load_context()
    if ctx and ctx.current_scenario_id:
        return ctx.current_scenario_id, _fetch_scenario_payload(client, ctx.current_scenario_id)

    target_name = ctx.current_scenario if ctx else None
    if not target_name:
        return None, None

    match = _find_project_scenario_by_name(
        client,
        project_id=project_id,
        scenario_name=target_name,
    )
    if not match:
        return None, None

    resolved_id = str(match.get("id") or "") or None
    return resolved_id, match


def resolve_scenario_id_by_name(
    client: httpx.Client,
    *,
    project_id: str,
    scenario_name: str,
) -> str | None:
    ctx = load_context()
    if ctx and ctx.current_scenario == scenario_name and ctx.current_scenario_id:
        return ctx.current_scenario_id

    match = _find_project_scenario_by_name(
        client,
        project_id=project_id,
        scenario_name=scenario_name,
    )
    if not match:
        return None
    return str(match.get("id") or "") or None
