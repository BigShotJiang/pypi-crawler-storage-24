"""Skill validation, testing, and benchmarking commands."""

from __future__ import annotations

import asyncio
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional
from uuid import uuid4

import typer
from rich.console import Console
from rich.table import Table

from ..config.loader import load_config, load_env_chain, load_yaml, revalidate_config
from ..config.schema import BudgetConfig, RunnerConfig, SandboxConfig, SimulationConfig
from ..constants import RESULTS_DIR_NAME
from ..contract.behavior_matcher import BehaviorMatcher, BehaviorReport
from ..contract.static_linter import (
    DEFAULT_STATIC_RULES,
    Severity,
    StaticLintReport,
    StaticLinter,
)
from ..core.executor import RunContext, RunResult, create_executor
from ..result.error_writer import ErrorWriter
from ..result.summary_writer import SummaryWriter
from ..result.trace_writer import TraceWriter
from ..workspace.context import get_scenario_dir, load_context, resolve_fluxloop_dir

app = typer.Typer(name="skill", help="Skill validation and testing")
console = Console()

CONTRACTS_DIR_NAME = "contracts"
STATIC_CONTRACT_FILENAME = "skill-static.yaml"
BEHAVIOR_CONTRACT_FILENAME = "skill-behavior.yaml"


def _render_lint_table(report: StaticLintReport) -> None:
    """Render static lint results as a Rich table."""
    table = Table(show_header=True)
    table.add_column("Rule", style="cyan")
    table.add_column("Status", justify="center")
    table.add_column("Severity", justify="center")
    table.add_column("Message")

    for result in report.results:
        status = "[green]PASS[/green]" if result.passed else "[red]FAIL[/red]"
        sev_style = "red" if result.severity == Severity.ERROR else "yellow"
        msg = "-" if result.passed else result.message
        table.add_row(
            result.rule_type,
            status,
            f"[{sev_style}]{result.severity.value}[/{sev_style}]",
            msg,
        )

    console.print(table)


def _render_behavior_table(report: BehaviorReport) -> None:
    """Render behavior assertion results as a Rich table."""
    table = Table(show_header=True)
    table.add_column("Assertion", style="cyan")
    table.add_column("Status", justify="center")
    table.add_column("Severity", justify="center")
    table.add_column("Message")

    for result in report.results:
        status = "[green]PASS[/green]" if result.passed else "[red]FAIL[/red]"
        sev_style = "red" if result.severity == Severity.ERROR else "yellow"
        msg = "-" if result.passed else result.message
        if result.actual and not result.passed:
            msg += f" (actual: {result.actual})"
        table.add_row(
            result.assertion_type,
            status,
            f"[{sev_style}]{result.severity.value}[/{sev_style}]",
            msg,
        )

    console.print(table)


def _resolve_current_scenario_dir() -> Path | None:
    ctx = load_context()
    if not ctx or not ctx.current_scenario:
        return None

    scenario_dir = get_scenario_dir(ctx.current_scenario)
    return scenario_dir if scenario_dir.exists() else None


def _resolve_scenario_dir(name: str | None) -> Path | None:
    if not name:
        return None

    scenario_dir = get_scenario_dir(name)
    if not scenario_dir.exists():
        console.print(f"[red]✗[/red] Scenario not found: {scenario_dir}")
        raise typer.Exit(1)
    return scenario_dir


def _resolve_contract_path(
    *,
    explicit: str | None,
    scenario_dir: Path | None,
    filename: str,
) -> Path | None:
    if explicit:
        path = Path(explicit).resolve()
        if not path.exists():
            console.print(f"[red]✗[/red] Contract file not found: {path}")
            raise typer.Exit(1)
        return path

    if not scenario_dir:
        return None

    path = scenario_dir / CONTRACTS_DIR_NAME / filename
    return path if path.exists() else None


def _serialize_static_report(report: StaticLintReport) -> dict[str, Any]:
    return {
        "skill_path": report.skill_path,
        "overall_pass": report.overall_pass,
        "error_count": report.error_count,
        "warning_count": report.warning_count,
        "results": [
            {
                "rule_type": result.rule_type,
                "passed": result.passed,
                "severity": result.severity.value,
                "message": result.message,
            }
            for result in report.results
        ],
    }


def _serialize_behavior_report(report: BehaviorReport) -> dict[str, Any]:
    return {
        "overall_pass": report.overall_pass,
        "error_count": report.error_count,
        "warning_count": report.warning_count,
        "results": [
            {
                "assertion_type": result.assertion_type,
                "passed": result.passed,
                "severity": result.severity.value,
                "message": result.message,
                "actual": result.actual,
                "expected": result.expected,
            }
            for result in report.results
        ],
    }


def _build_contract_summary(reports: list[BehaviorReport]) -> dict[str, Any] | None:
    if not reports:
        return None

    assertion_stats: dict[str, dict[str, int]] = {}
    for report in reports:
        for result in report.results:
            stats = assertion_stats.setdefault(
                result.assertion_type,
                {"passed": 0, "total": 0},
            )
            stats["total"] += 1
            if result.passed:
                stats["passed"] += 1

    return {
        "overall_pass_rate": round(
            sum(1 for report in reports if report.overall_pass) / len(reports),
            4,
        ),
        "assertion_pass_rates": {
            assertion_type: round(stats["passed"] / stats["total"], 4)
            for assertion_type, stats in assertion_stats.items()
            if stats["total"] > 0
        },
    }


def _run_static_preflight(
    *,
    skill_path: Path,
    scenario_dir: Path | None,
    verbose: bool,
) -> dict[str, Any] | None:
    contract_path = _resolve_contract_path(
        explicit=None,
        scenario_dir=scenario_dir,
        filename=STATIC_CONTRACT_FILENAME,
    )
    if not contract_path:
        return None

    contract_data = load_yaml(contract_path) or {}
    rules = contract_data.get("rules", [])
    report = StaticLinter().lint(skill_path, rules)
    serialized = _serialize_static_report(report)

    if report.overall_pass:
        if verbose:
            console.print(
                f"[dim]Using static contract: {contract_path} "
                f"({len(report.results)} rules)[/dim]"
            )
        return serialized

    console.print(
        f"[yellow]![/yellow] Static validation found "
        f"{report.error_count} errors and {report.warning_count} warnings. "
        "Continuing with execution."
    )
    if verbose:
        console.print()
        _render_lint_table(report)
        console.print()
    return serialized


def _build_skill_simulation_config(
    *,
    skill_path: Path,
    scenario: str | None,
    copy_files: list[str] | None,
    allowed_tools: list[str] | None,
    max_turns: int | None,
    budget: float | None,
    no_cleanup: bool,
    default_name: str,
) -> tuple[SimulationConfig, Path | None]:
    scenario_dir = _resolve_scenario_dir(scenario)
    if scenario_dir:
        load_env_chain(scenario_dir)
        simulation = load_config(scenario_dir).model_copy(deep=True)
        if simulation.runner.type != "skill":
            console.print(
                "[red]✗[/red] Scenario runner.type must be 'skill' for skill commands."
            )
            raise typer.Exit(1)
    else:
        simulation = SimulationConfig(name=default_name, runner=RunnerConfig(type="skill"))

    runner = simulation.runner.model_copy(deep=True)
    runner.type = "skill"
    runner.skill_path = str(skill_path)

    if copy_files is not None:
        runner.sandbox = runner.sandbox.model_copy(deep=True)
        runner.sandbox.copy_files = list(copy_files)
    if allowed_tools is not None:
        runner.allowed_tools = list(allowed_tools)
    if max_turns is not None:
        runner.skill_max_turns = max_turns
    if budget is not None:
        runner.budget = runner.budget.model_copy(
            update={"max_budget_usd": budget}
        )
    if no_cleanup:
        runner.sandbox = runner.sandbox.model_copy(deep=True)
        runner.sandbox.cleanup = False

    simulation.runner = runner
    return revalidate_config(simulation), scenario_dir


def _load_behavior_assertions(
    *,
    explicit_contract: str | None,
    scenario_dir: Path | None,
) -> tuple[Path | None, list[dict[str, Any]]]:
    contract_path = _resolve_contract_path(
        explicit=explicit_contract,
        scenario_dir=scenario_dir,
        filename=BEHAVIOR_CONTRACT_FILENAME,
    )
    if not contract_path:
        return None, []

    contract_data = load_yaml(contract_path) or {}
    return contract_path, contract_data.get("assertions", [])


def _cleanup_executor(executor: Any, *, should_cleanup: bool) -> None:
    if not should_cleanup:
        return

    try:
        asyncio.run(executor.cleanup())
    except Exception:
        pass


async def _run_skill_benchmark(
    *,
    simulation: SimulationConfig,
    input_text: str,
    runs: int,
    scenario: str | None,
    trace_writer: TraceWriter,
    static_results: dict[str, Any] | None,
    matcher: BehaviorMatcher | None,
    assertions: list[dict[str, Any]],
) -> tuple[list[RunResult], list[BehaviorReport]]:
    results: list[RunResult] = []
    behavior_reports: list[BehaviorReport] = []

    for run_index in range(runs):
        executor = create_executor(simulation.runner)
        run_id = str(uuid4())
        context = RunContext(iteration=run_index, scenario=scenario)

        try:
            result = await executor.execute(
                input_text=input_text,
                context=context,
                run_id=run_id,
            )
            results.append(result)

            skill_meta = result.metadata.get("skill_metadata", {})
            duration_s = result.duration_ms / 1000
            cost = skill_meta.get("total_cost_usd")
            cost_str = f"${cost:.2f}" if cost is not None else "---"
            turns = skill_meta.get("turn_count", 0)

            if result.success:
                console.print(
                    f"    Run {run_index + 1}/{runs}  [green]✓[/green]  "
                    f"{duration_s:.1f}s  {cost_str}  {turns} turns"
                )
            else:
                error_message = result.error.message[:40] if result.error else "error"
                console.print(
                    f"    Run {run_index + 1}/{runs}  [red]✗[/red]  "
                    f"---   {cost_str}  {turns} turns ({error_message})"
                )

            behavior_report = None
            if matcher and result.success:
                sandbox_path = skill_meta.get("sandbox_path")
                behavior_report = matcher.evaluate(
                    assertions=assertions,
                    tool_calls=result.tool_calls,
                    response_text=result.output,
                    sandbox_path=Path(sandbox_path) if sandbox_path else None,
                    duration_ms=result.duration_ms,
                    turn_count=turns,
                    token_usage=result.token_usage.model_dump() if result.token_usage else None,
                    total_cost_usd=cost,
                )
                behavior_reports.append(behavior_report)

            trace_writer.write(
                result,
                context,
                input_text,
                static_results=static_results,
                contract_results=(
                    _serialize_behavior_report(behavior_report)
                    if behavior_report
                    else None
                ),
            )
        finally:
            if simulation.runner.sandbox.cleanup:
                try:
                    await executor.cleanup()
                except Exception:
                    pass

    return results, behavior_reports


def _render_contract_summary(report: BehaviorReport) -> None:
    passed = sum(1 for result in report.results if result.passed)
    total = len(report.results)

    if report.overall_pass:
        console.print(
            f"  Behavior Contract: [green]✓[/green] {passed}/{total} assertions passed"
        )
    else:
        console.print(
            f"  Behavior Contract: [red]✗[/red] "
            f"{report.error_count} errors, {report.warning_count} warnings"
        )

    console.print()
    _render_behavior_table(report)


@app.command()
def validate(
    skill_path: str = typer.Argument(..., help="Path to SKILL.md"),
    scenario: Optional[str] = typer.Option(
        None, "--scenario", help="Scenario name for static contract"
    ),
    contract: Optional[str] = typer.Option(
        None, "--contract", help="Static contract file path"
    ),
    format: str = typer.Option("table", "--format", help="Output format: table|json"),
) -> None:
    """Validate SKILL.md against static rules."""
    path = Path(skill_path).resolve()
    scenario_dir = (
        _resolve_scenario_dir(scenario)
        if scenario
        else _resolve_current_scenario_dir()
    )
    contract_path = _resolve_contract_path(
        explicit=contract,
        scenario_dir=scenario_dir,
        filename=STATIC_CONTRACT_FILENAME,
    )

    if contract_path:
        contract_data = load_yaml(contract_path) or {}
        rules = contract_data.get("rules", [])
    else:
        rules = DEFAULT_STATIC_RULES

    report = StaticLinter().lint(path, rules)

    if format == "json":
        console.print(json.dumps(_serialize_static_report(report), indent=2, ensure_ascii=False))
    else:
        passed = sum(1 for result in report.results if result.passed)
        total = len(report.results)

        if report.overall_pass:
            console.print(
                f"[green]✓[/green] Static validation passed ({passed}/{total} rules)"
            )
        else:
            console.print(
                f"[red]✗[/red] Static validation failed "
                f"({passed}/{total} passed, {report.error_count} errors)"
            )

        console.print()
        _render_lint_table(report)

    if not report.overall_pass:
        raise typer.Exit(1)


@app.command()
def test(
    skill_path: str = typer.Argument(..., help="Path to SKILL.md"),
    input: str = typer.Option(..., "--input", "-i", help="Input text"),
    contract: Optional[str] = typer.Option(
        None, "--contract", help="Behavior contract file path"
    ),
    scenario: Optional[str] = typer.Option(
        None, "--scenario", help="Scenario name for config"
    ),
    copy_files: Optional[list[str]] = typer.Option(
        None, "--copy-files", help="Files to copy into sandbox"
    ),
    allowed_tools: Optional[list[str]] = typer.Option(
        None, "--allowed-tools", help="Allowed tools"
    ),
    max_turns: Optional[int] = typer.Option(
        None, "--max-turns", help="Max turns (default: 20)"
    ),
    budget: Optional[float] = typer.Option(
        None, "--budget", help="Budget USD (default: 0.50)"
    ),
    no_cleanup: bool = typer.Option(
        False, "--no-cleanup", help="Keep sandbox for debugging"
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Test a skill in sandbox — execute + evaluate behavior contract."""
    path = Path(skill_path).resolve()
    if not path.exists():
        console.print(f"[red]✗[/red] Skill file not found: {path}")
        raise typer.Exit(1)

    try:
        simulation, scenario_dir = _build_skill_simulation_config(
            skill_path=path,
            scenario=scenario,
            copy_files=copy_files,
            allowed_tools=allowed_tools,
            max_turns=max_turns,
            budget=budget,
            no_cleanup=no_cleanup,
            default_name=f"skill-test-{path.stem}",
        )
    except ValueError as e:
        console.print(f"[red]✗[/red] Config error: {e}")
        raise typer.Exit(1)
    static_results = _run_static_preflight(
        skill_path=path,
        scenario_dir=scenario_dir,
        verbose=verbose,
    )
    behavior_contract_path, assertions = _load_behavior_assertions(
        explicit_contract=contract,
        scenario_dir=scenario_dir,
    )

    if verbose:
        console.print("[dim]⏳ Creating sandbox...[/dim]")
        console.print(f"[dim]⏳ Installing skill: {skill_path}[/dim]")
        console.print("[dim]⏳ Running Claude Agent SDK query...[/dim]")
        console.print()

    executor = create_executor(simulation.runner)
    run_id = str(uuid4())
    context = RunContext(iteration=0, scenario=scenario)

    try:
        result = asyncio.run(
            executor.execute(input_text=input, context=context, run_id=run_id)
        )

        skill_meta = result.metadata.get("skill_metadata", {})
        behavior_report = None
        if assertions and result.success:
            matcher = BehaviorMatcher()
            sandbox_path = skill_meta.get("sandbox_path")
            behavior_report = matcher.evaluate(
                assertions=assertions,
                tool_calls=result.tool_calls,
                response_text=result.output,
                sandbox_path=Path(sandbox_path) if sandbox_path else None,
                duration_ms=result.duration_ms,
                turn_count=skill_meta.get("turn_count", 0),
                token_usage=result.token_usage.model_dump() if result.token_usage else None,
                total_cost_usd=skill_meta.get("total_cost_usd"),
            )

        timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        output_dir = resolve_fluxloop_dir() / RESULTS_DIR_NAME / f"skill-test-{timestamp}"
        trace_writer = TraceWriter(output_dir)

        contract_results = (
            _serialize_behavior_report(behavior_report) if behavior_report else None
        )
        trace_writer.write(
            result,
            context,
            input,
            static_results=static_results,
            contract_results=contract_results,
        )
        SummaryWriter().write(
            output_dir,
            simulation,
            [result],
            contract_summary=_build_contract_summary([behavior_report])
            if behavior_report
            else None,
        )
        ErrorWriter().write(output_dir, simulation)

        if result.success:
            duration_s = result.duration_ms / 1000
            cost = skill_meta.get("total_cost_usd")
            cost_str = f"${cost:.2f}" if cost is not None else "N/A"
            console.print(
                f"[green]✓[/green] Skill test completed ({duration_s:.1f}s, {cost_str})"
            )

            if verbose:
                console.print()
                console.print(f"    Turn count:    {skill_meta.get('turn_count', 0)}")

                tool_counts: dict[str, int] = {}
                for tool_call in result.tool_calls:
                    tool_name = tool_call.get("tool", "unknown")
                    tool_counts[tool_name] = tool_counts.get(tool_name, 0) + 1
                tool_summary = ", ".join(
                    f"{tool_name}: {count}"
                    for tool_name, count in tool_counts.items()
                )
                console.print(
                    f"    Tool calls:    {len(result.tool_calls)} ({tool_summary})"
                    if tool_summary
                    else f"    Tool calls:    {len(result.tool_calls)}"
                )

                files = skill_meta.get("files_created", [])
                if files:
                    console.print(f"    Files created: {', '.join(files)}")

                if result.token_usage:
                    token_usage = result.token_usage
                    console.print(
                        f"    Tokens:        {token_usage.total_tokens:,} "
                        f"(in: {token_usage.input_tokens:,}, "
                        f"out: {token_usage.output_tokens:,})"
                    )

                console.print(f"    Cost:          {cost_str}")
                sandbox_path = skill_meta.get("sandbox_path", "")
                cleanup_status = (
                    "cleaned up"
                    if simulation.runner.sandbox.cleanup
                    else "kept"
                )
                if sandbox_path:
                    console.print(
                        f"    Sandbox:       {sandbox_path} ({cleanup_status})"
                    )
        else:
            error_message = result.error.message if result.error else "Unknown error"
            console.print(f"[red]✗[/red] Skill test failed: {error_message}")

        if behavior_contract_path and assertions and behavior_report:
            console.print()
            _render_contract_summary(behavior_report)

        console.print()
        console.print(f"  Results: {output_dir}")

        if not result.success:
            raise typer.Exit(1)
        if behavior_report and not behavior_report.overall_pass:
            raise typer.Exit(1)
    finally:
        _cleanup_executor(executor, should_cleanup=simulation.runner.sandbox.cleanup)


@app.command()
def benchmark(
    skill_path: str = typer.Argument(..., help="Path to SKILL.md"),
    input: str = typer.Option(..., "--input", "-i", help="Input text"),
    runs: int = typer.Option(5, "--runs", help="Number of runs"),
    contract: Optional[str] = typer.Option(
        None, "--contract", help="Behavior contract file path"
    ),
    scenario: Optional[str] = typer.Option(
        None, "--scenario", help="Scenario name for config"
    ),
    copy_files: Optional[list[str]] = typer.Option(
        None, "--copy-files", help="Files to copy into sandbox"
    ),
    allowed_tools: Optional[list[str]] = typer.Option(
        None, "--allowed-tools", help="Allowed tools"
    ),
    max_turns: Optional[int] = typer.Option(
        None, "--max-turns", help="Max turns (default: 20)"
    ),
    budget: Optional[float] = typer.Option(
        None, "--budget", help="Budget USD (default: 0.50)"
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Run N benchmark iterations of a skill."""
    path = Path(skill_path).resolve()
    if not path.exists():
        console.print(f"[red]✗[/red] Skill file not found: {path}")
        raise typer.Exit(1)

    try:
        simulation, scenario_dir = _build_skill_simulation_config(
            skill_path=path,
            scenario=scenario,
            copy_files=copy_files,
            allowed_tools=allowed_tools,
            max_turns=max_turns,
            budget=budget,
            no_cleanup=False,
            default_name=f"benchmark-{path.stem}",
        )
        simulation = revalidate_config(simulation, iterations=runs)
    except ValueError as e:
        console.print(f"[red]✗[/red] Config error: {e}")
        raise typer.Exit(1)
    static_results = _run_static_preflight(
        skill_path=path,
        scenario_dir=scenario_dir,
        verbose=verbose,
    )
    behavior_contract_path, assertions = _load_behavior_assertions(
        explicit_contract=contract,
        scenario_dir=scenario_dir,
    )
    matcher = BehaviorMatcher() if assertions else None

    console.print(f"[dim]⏳ Running benchmark: {runs} runs[/dim]")
    console.print()

    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    output_dir = resolve_fluxloop_dir() / RESULTS_DIR_NAME / f"benchmark-{timestamp}"
    trace_writer = TraceWriter(output_dir)

    results, behavior_reports = asyncio.run(
        _run_skill_benchmark(
            simulation=simulation,
            input_text=input,
            runs=runs,
            scenario=scenario,
            trace_writer=trace_writer,
            static_results=static_results,
            matcher=matcher,
            assertions=assertions,
        )
    )

    console.print()
    console.print("  " + "─" * 50)

    success_results = [result for result in results if result.success]
    success_count = len(success_results)
    success_rate = success_count / runs * 100 if runs > 0 else 0

    console.print("  Summary:")
    console.print(f"    Success rate:  {success_count}/{runs} ({success_rate:.1f}%)")

    if success_results:
        durations = [result.duration_ms / 1000 for result in success_results]
        console.print(
            f"    Duration:      avg {sum(durations) / len(durations):.1f}s "
            f"(min {min(durations):.1f}s, max {max(durations):.1f}s)"
        )

        costs = [
            result.metadata.get("skill_metadata", {}).get("total_cost_usd", 0) or 0
            for result in success_results
        ]
        total_cost = sum(costs)
        avg_cost = total_cost / len(costs) if costs else 0
        console.print(
            f"    Cost:          avg ${avg_cost:.2f} (total ${total_cost:.2f})"
        )

        turns_list = [
            result.metadata.get("skill_metadata", {}).get("turn_count", 0)
            for result in success_results
        ]
        avg_turns = sum(turns_list) / len(turns_list) if turns_list else 0
        console.print(
            f"    Turns:         avg {avg_turns:.1f} "
            f"(min {min(turns_list)}, max {max(turns_list)})"
        )

        tokens = [
            result.token_usage.total_tokens
            for result in success_results
            if result.token_usage
        ]
        if tokens:
            console.print(
                f"    Tokens:        avg {sum(tokens) // len(tokens):,} "
                f"(total {sum(tokens):,})"
            )

    if behavior_contract_path and behavior_reports:
        console.print()
        console.print(f"  Behavior Contract ({len(behavior_reports)} successful runs):")
        contract_summary = _build_contract_summary(behavior_reports) or {}
        assertion_pass_rates = contract_summary.get("assertion_pass_rates", {})

        table = Table(show_header=True)
        table.add_column("Assertion", style="cyan")
        table.add_column("Pass Rate", justify="center")
        table.add_column("Status", justify="center")

        for assertion_type, pass_rate in assertion_pass_rates.items():
            stats_total = len(behavior_reports)
            passed_count = round(pass_rate * stats_total)
            status = (
                "[green]PASS[/green]"
                if pass_rate == 1.0
                else "[yellow]WARN[/yellow]"
            )
            table.add_row(
                assertion_type,
                f"{passed_count}/{stats_total} {pass_rate * 100:.0f}%",
                status,
            )

        console.print(table)
    else:
        contract_summary = None

    SummaryWriter().write(
        output_dir,
        simulation,
        results,
        contract_summary=contract_summary,
    )
    ErrorWriter().write(output_dir, simulation)

    console.print()
    console.print(f"  Results: {output_dir}")

    if success_rate < 100:
        raise typer.Exit(1)
    if any(not report.overall_pass for report in behavior_reports):
        raise typer.Exit(1)
