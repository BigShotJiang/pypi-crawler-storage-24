"""Static validation of SKILL.md files against contract rules."""

from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum
from pathlib import Path


class Severity(str, Enum):
    ERROR = "error"
    WARNING = "warning"


@dataclass
class LintResult:
    rule_type: str
    passed: bool
    severity: Severity
    message: str


@dataclass
class StaticLintReport:
    skill_path: str
    results: list[LintResult]
    overall_pass: bool

    @property
    def error_count(self) -> int:
        return sum(
            1 for r in self.results
            if not r.passed and r.severity == Severity.ERROR
        )

    @property
    def warning_count(self) -> int:
        return sum(
            1 for r in self.results
            if not r.passed and r.severity == Severity.WARNING
        )


DEFAULT_STATIC_RULES: list[dict] = [
    {
        "type": "file_size",
        "params": {"min_bytes": 50, "max_bytes": 100000},
        "severity": "error",
        "message": "SKILL.md must be between 50 bytes and 100KB",
    },
    {
        "type": "encoding",
        "params": {"encoding": "utf-8"},
        "severity": "error",
    },
    {
        "type": "forbidden_pattern",
        "params": {"pattern": r"(?i)(api[_-]?key|secret|password)\s*[:=]\s*\S+"},
        "severity": "error",
        "message": "SKILL.md must not contain hardcoded secrets",
    },
]


class StaticLinter:
    """Validate SKILL.md structure without execution.

    Supported rule types:
      has_section, file_exists, file_size, forbidden_pattern,
      encoding, naming_convention, description_quality
    """

    def lint(self, skill_path: Path, rules: list[dict]) -> StaticLintReport:
        results: list[LintResult] = []

        if not skill_path.exists():
            return StaticLintReport(
                skill_path=str(skill_path),
                results=[LintResult(
                    rule_type="file_exists",
                    passed=False,
                    severity=Severity.ERROR,
                    message=f"Skill file not found: {skill_path}",
                )],
                overall_pass=False,
            )

        content = skill_path.read_text(encoding="utf-8", errors="replace")

        for rule in rules:
            rule_type = rule["type"]
            params = rule.get("params", {})
            severity = Severity(rule.get("severity", "error"))
            message = rule.get("message", "")

            result = self._evaluate_rule(
                skill_path, content, rule_type, params, severity, message
            )
            results.append(result)

        overall_pass = all(
            r.passed for r in results if r.severity == Severity.ERROR
        )

        return StaticLintReport(
            skill_path=str(skill_path),
            results=results,
            overall_pass=overall_pass,
        )

    def _evaluate_rule(
        self,
        skill_path: Path,
        content: str,
        rule_type: str,
        params: dict,
        severity: Severity,
        message: str,
    ) -> LintResult:
        match rule_type:
            case "has_section":
                section = params["section"]
                heading_text = section.lstrip("#").strip()
                pattern = rf"^#{{1,6}}\s+{re.escape(heading_text)}"
                passed = bool(re.search(pattern, content, re.MULTILINE))
                return LintResult(
                    rule_type=rule_type,
                    passed=passed,
                    severity=severity,
                    message=message or f"Missing section: {section}",
                )

            case "file_exists":
                raw_path = Path(params["path"])
                target = (
                    raw_path
                    if raw_path.is_absolute()
                    else skill_path.parent / raw_path
                )
                passed = target.exists()
                return LintResult(
                    rule_type=rule_type,
                    passed=passed,
                    severity=severity,
                    message=message or f"File must exist: {raw_path}",
                )

            case "file_size":
                size = skill_path.stat().st_size
                min_b = params.get("min_bytes", 0)
                max_b = params.get("max_bytes", float("inf"))
                passed = min_b <= size <= max_b
                return LintResult(
                    rule_type=rule_type,
                    passed=passed,
                    severity=severity,
                    message=message or f"File size {size}B outside [{min_b}, {max_b}]",
                )

            case "forbidden_pattern":
                pattern = params["pattern"]
                match_found = bool(re.search(pattern, content))
                return LintResult(
                    rule_type=rule_type,
                    passed=not match_found,
                    severity=severity,
                    message=message or f"Forbidden pattern found: {pattern}",
                )

            case "encoding":
                expected = params.get("encoding", "utf-8")
                try:
                    skill_path.read_text(encoding=expected)
                    passed = True
                except UnicodeDecodeError:
                    passed = False
                return LintResult(
                    rule_type=rule_type,
                    passed=passed,
                    severity=severity,
                    message=message or f"File is not {expected} encoded",
                )

            case "naming_convention":
                convention = params.get("convention", "UPPER_SNAKE")
                stem = skill_path.stem
                match convention:
                    case "UPPER_SNAKE":
                        passed = bool(re.match(r"^[A-Z][A-Z0-9_]*$", stem))
                    case "kebab-case":
                        passed = bool(re.match(r"^[a-z][a-z0-9-]*$", stem))
                    case _:
                        passed = True
                return LintResult(
                    rule_type=rule_type,
                    passed=passed,
                    severity=severity,
                    message=message or f"Filename doesn't follow {convention}",
                )

            case "description_quality":
                min_length = params.get("min_length", 50)
                lines = content.split("\n")
                desc_text = ""
                in_desc = False
                for line in lines:
                    if line.startswith("#") and not in_desc:
                        in_desc = True
                        continue
                    if in_desc:
                        if line.startswith("#"):
                            break
                        desc_text += line + " "
                passed = len(desc_text.strip()) >= min_length
                return LintResult(
                    rule_type=rule_type,
                    passed=passed,
                    severity=severity,
                    message=message or f"Description too short (min {min_length} chars)",
                )

            case _:
                return LintResult(
                    rule_type=rule_type,
                    passed=True,
                    severity=Severity.WARNING,
                    message=f"Unknown rule type: {rule_type}",
                )
