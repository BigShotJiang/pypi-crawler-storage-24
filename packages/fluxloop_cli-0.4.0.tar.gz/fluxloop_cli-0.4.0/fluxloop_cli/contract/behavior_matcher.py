"""Post-execution behavior contract evaluation."""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

from ..path_safety import resolve_path_within_root
from .safe_regex import safe_regex_search
from .static_linter import Severity


@dataclass
class AssertionResult:
    assertion_type: str
    passed: bool
    severity: Severity
    message: str
    actual: str | None = None
    expected: str | None = None


@dataclass
class BehaviorReport:
    results: list[AssertionResult]
    overall_pass: bool

    @property
    def error_count(self) -> int:
        return sum(
            1 for r in self.results
            if not r.passed and r.severity == Severity.ERROR
        )

    @property
    def warning_count(self) -> int:
        return sum(
            1 for r in self.results
            if not r.passed and r.severity == Severity.WARNING
        )


class BehaviorMatcher:
    """Evaluate post-execution behavior against contract assertions.

    Supported assertion types:
      tool_called, tool_not_called, tool_sequence, file_exists, file_contains,
      turn_count, token_budget, cost_budget, response_contains,
      response_not_contains, duration
    """

    def evaluate(
        self,
        *,
        assertions: list[dict],
        tool_calls: list[dict],
        response_text: str,
        sandbox_path: Path | None,
        duration_ms: int,
        turn_count: int,
        token_usage: dict | None,
        total_cost_usd: float | None,
    ) -> BehaviorReport:
        results: list[AssertionResult] = []

        for assertion in assertions:
            a_type = assertion["type"]
            params = assertion.get("params", {})
            severity = Severity(assertion.get("severity", "error"))
            message = assertion.get("message", "")

            result = self._evaluate_assertion(
                a_type=a_type,
                params=params,
                severity=severity,
                message=message,
                tool_calls=tool_calls,
                response_text=response_text,
                sandbox_path=sandbox_path,
                duration_ms=duration_ms,
                turn_count=turn_count,
                token_usage=token_usage,
                total_cost_usd=total_cost_usd,
            )
            results.append(result)

        overall_pass = all(
            r.passed for r in results if r.severity == Severity.ERROR
        )

        return BehaviorReport(results=results, overall_pass=overall_pass)

    def _evaluate_assertion(  # noqa: PLR0911
        self,
        *,
        a_type: str,
        params: dict,
        severity: Severity,
        message: str,
        tool_calls: list[dict],
        response_text: str,
        sandbox_path: Path | None,
        duration_ms: int,
        turn_count: int,
        token_usage: dict | None,
        total_cost_usd: float | None,
    ) -> AssertionResult:
        match a_type:
            case "tool_called":
                tool = params["tool"]
                min_count = params.get("min_count", 1)
                actual_count = sum(
                    1 for tc in tool_calls if tc.get("tool") == tool
                )
                passed = actual_count >= min_count
                return AssertionResult(
                    assertion_type=a_type,
                    passed=passed,
                    severity=severity,
                    message=message or f"{tool} must be called >= {min_count} times",
                    actual=str(actual_count),
                    expected=f">= {min_count}",
                )

            case "tool_not_called":
                tool = params["tool"]
                actual_count = sum(
                    1 for tc in tool_calls if tc.get("tool") == tool
                )
                passed = actual_count == 0
                return AssertionResult(
                    assertion_type=a_type,
                    passed=passed,
                    severity=severity,
                    message=message or f"{tool} must not be called",
                    actual=str(actual_count),
                    expected="0",
                )

            case "tool_sequence":
                expected_seq = params["sequence"]
                actual_tools = [tc.get("tool", "") for tc in tool_calls]
                idx = 0
                for tool in actual_tools:
                    if idx < len(expected_seq) and tool == expected_seq[idx]:
                        idx += 1
                passed = idx == len(expected_seq)
                return AssertionResult(
                    assertion_type=a_type,
                    passed=passed,
                    severity=severity,
                    message=message or f"Expected tool sequence: {expected_seq}",
                    actual=str(actual_tools[:20]),
                    expected=str(expected_seq),
                )

            case "file_exists":
                path = params["path"]
                if sandbox_path:
                    target = resolve_path_within_root(sandbox_path, path)
                    passed = bool(target and target.exists())
                else:
                    passed = False
                return AssertionResult(
                    assertion_type=a_type,
                    passed=passed,
                    severity=severity,
                    message=message or f"File must exist: {path}",
                )

            case "file_contains":
                path = params["path"]
                pattern = params["pattern"]
                passed = False
                if sandbox_path:
                    target = resolve_path_within_root(sandbox_path, path)
                    if target and target.exists():
                        content = target.read_text(errors="replace")
                        regex_result = safe_regex_search(pattern, content)
                        passed = regex_result.matched and regex_result.error is None
                    else:
                        regex_result = None
                return AssertionResult(
                    assertion_type=a_type,
                    passed=passed,
                    severity=severity,
                    message=message or f"File {path} must contain: {pattern}",
                    actual=regex_result.error if regex_result and regex_result.error else None,
                )

            case "turn_count":
                max_turns = params.get("max", 20)
                passed = turn_count <= max_turns
                return AssertionResult(
                    assertion_type=a_type,
                    passed=passed,
                    severity=severity,
                    message=message or f"Turn count must be <= {max_turns}",
                    actual=str(turn_count),
                    expected=f"<= {max_turns}",
                )

            case "token_budget":
                max_tokens = params["max_tokens"]
                total = (token_usage or {}).get("total_tokens", 0)
                passed = total <= max_tokens
                return AssertionResult(
                    assertion_type=a_type,
                    passed=passed,
                    severity=severity,
                    message=message or f"Token usage must be <= {max_tokens}",
                    actual=str(total),
                    expected=f"<= {max_tokens}",
                )

            case "cost_budget":
                max_usd = params["max_usd"]
                actual_cost = total_cost_usd or 0.0
                passed = actual_cost <= max_usd
                return AssertionResult(
                    assertion_type=a_type,
                    passed=passed,
                    severity=severity,
                    message=message or f"Cost must be <= ${max_usd}",
                    actual=f"${actual_cost:.4f}",
                    expected=f"<= ${max_usd}",
                )

            case "response_contains":
                pattern = params["pattern"]
                regex_result = safe_regex_search(pattern, response_text)
                passed = regex_result.matched and regex_result.error is None
                return AssertionResult(
                    assertion_type=a_type,
                    passed=passed,
                    severity=severity,
                    message=message or f"Response must contain: {pattern}",
                    actual=regex_result.error,
                )

            case "response_not_contains":
                pattern = params["pattern"]
                regex_result = safe_regex_search(pattern, response_text)
                passed = (
                    regex_result.error is None
                    and not regex_result.matched
                )
                return AssertionResult(
                    assertion_type=a_type,
                    passed=passed,
                    severity=severity,
                    message=message or f"Response must not contain: {pattern}",
                    actual=regex_result.error,
                )

            case "duration":
                max_ms = params["max_ms"]
                passed = duration_ms <= max_ms
                return AssertionResult(
                    assertion_type=a_type,
                    passed=passed,
                    severity=severity,
                    message=message or f"Duration must be <= {max_ms}ms",
                    actual=f"{duration_ms}ms",
                    expected=f"<= {max_ms}ms",
                )

            case _:
                return AssertionResult(
                    assertion_type=a_type,
                    passed=True,
                    severity=Severity.WARNING,
                    message=f"Unknown assertion type: {a_type}",
                )
