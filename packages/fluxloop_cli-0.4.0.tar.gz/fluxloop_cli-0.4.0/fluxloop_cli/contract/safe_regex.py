"""Regex evaluation helpers with timeout isolation."""

from __future__ import annotations

import multiprocessing
import queue
import re
from dataclasses import dataclass

DEFAULT_REGEX_TIMEOUT_MS = 500
_START_METHOD = (
    "fork" if "fork" in multiprocessing.get_all_start_methods() else "spawn"
)


@dataclass
class RegexSearchResult:
    matched: bool
    error: str | None = None


def _regex_worker(
    result_queue: multiprocessing.Queue,
    pattern: str,
    text: str,
) -> None:
    try:
        result_queue.put({"matched": bool(re.search(pattern, text))})
    except re.error as exc:
        result_queue.put({
            "matched": False,
            "error": f"Invalid regex: {exc}",
        })


def safe_regex_search(
    pattern: str,
    text: str,
    *,
    timeout_ms: int = DEFAULT_REGEX_TIMEOUT_MS,
) -> RegexSearchResult:
    ctx = multiprocessing.get_context(_START_METHOD)
    result_queue = ctx.Queue(maxsize=1)
    process = ctx.Process(
        target=_regex_worker,
        args=(result_queue, pattern, text),
    )
    process.daemon = True
    process.start()
    process.join(timeout_ms / 1000)

    try:
        if process.is_alive():
            process.kill()
            process.join()
            return RegexSearchResult(
                matched=False,
                error=f"Regex evaluation timed out after {timeout_ms}ms",
            )

        try:
            payload = result_queue.get_nowait()
        except queue.Empty:
            if process.exitcode not in (0, None):
                return RegexSearchResult(
                    matched=False,
                    error=f"Regex worker exited with code {process.exitcode}",
                )
            return RegexSearchResult(
                matched=False,
                error="Regex evaluation failed without a result",
            )

        return RegexSearchResult(
            matched=bool(payload.get("matched", False)),
            error=str(payload["error"]) if payload.get("error") else None,
        )
    finally:
        result_queue.close()
        result_queue.join_thread()
        process.close()
