"""Shared constants for the FluxLoop CLI."""

from pathlib import Path

# Workspace structure
FLUXLOOP_DIR_NAME = ".fluxloop"
SCENARIOS_DIR_NAME = "scenarios"
RESULTS_DIR_NAME = "results"
STATE_DIR_NAME = ".state"
PROJECT_JSON_FILENAME = "project.json"
CONTEXT_JSON_FILENAME = "context.json"

# Config files
CONFIG_DIRECTORY_NAME = "configs"
SCENARIO_CONFIG_FILENAME = "scenario.yaml"
INPUT_CONFIG_FILENAME = "input.yaml"
SIMULATION_CONFIG_FILENAME = "simulation.yaml"

CONFIG_SECTION_FILENAMES = {
    "scenario": SCENARIO_CONFIG_FILENAME,
    "input": INPUT_CONFIG_FILENAME,
    "simulation": SIMULATION_CONFIG_FILENAME,
}

CONFIG_SECTION_ORDER = ("scenario", "input", "simulation")

# Sync / Pulled data
PULLED_DIR_NAME = "pulled"
SYNC_META_FILENAME = "sync_meta.json"
PULLED_INPUTS_FILENAME = "inputs.json"
PULLED_PERSONAS_FILENAME = "personas.json"
PULLED_CRITERIA_FILENAME = "criteria.json"

# Auth
AUTH_DIR = Path.home() / ".fluxloop"
AUTH_FILE = AUTH_DIR / "auth.json"
PENDING_FILE = AUTH_DIR / "pending_login.json"
FILE_PERMISSION = 0o600

# API URLs
PRODUCTION_API_URL = "https://api.fluxloop.ai"
STAGING_API_URL = "https://staging.api.fluxloop.ai"
