"""SkillExecutor — Claude Agent SDK-based skill execution in sandbox."""

from __future__ import annotations

import os
import time
import traceback as tb_mod
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from ..config.schema import RunnerConfig
from ..workspace.sandbox import Sandbox, SandboxManager
from .executor import RunContext, RunError, RunResult, TokenUsage


MAX_CHILD_DEPTH = 3
ENV_CHILD_DEPTH = "FLUXLOOP_CHILD_DEPTH"


@dataclass
class ToolCall:
    turn: int
    tool: str
    input: dict[str, Any]
    output: str
    is_error: bool
    duration_ms: int


@dataclass
class SkillMetadata:
    skill_path: str
    harness: str
    sandbox_path: str
    turn_count: int = 0
    total_cost_usd: float | None = None
    files_created: list[str] = field(default_factory=list)
    commands_executed: list[str] = field(default_factory=list)


class EvidenceCollector:
    """Collect tool call evidence from SDK message stream."""

    def __init__(self) -> None:
        self.tool_calls: list[ToolCall] = []
        self.files_created: list[str] = []
        self.commands_executed: list[str] = []
        self._current_turn: int = 0

    def record_tool_use(
        self,
        tool_name: str,
        tool_input: dict[str, Any],
    ) -> None:
        self.tool_calls.append(ToolCall(
            turn=self._current_turn,
            tool=tool_name,
            input=tool_input,
            output="",
            is_error=False,
            duration_ms=0,
        ))

        if tool_name == "Write":
            path = tool_input.get("file_path", "")
            if path:
                self.files_created.append(path)
        elif tool_name == "Bash":
            cmd = tool_input.get("command", "")
            if cmd:
                self.commands_executed.append(cmd)

    def record_tool_result(
        self,
        output: str,
        is_error: bool,
        *,
        duration_ms: int = 0,
    ) -> None:
        if self.tool_calls:
            last = self.tool_calls[-1]
            last.output = output
            last.is_error = is_error
            last.duration_ms = duration_ms

    def increment_turn(self) -> None:
        self._current_turn += 1

    @property
    def turn_count(self) -> int:
        return self._current_turn


class SkillExecutor:
    """Execute skills via Claude Agent SDK in an isolated sandbox.

    Phase 2 supports claude harness only.
    codex/openclaw adapters are reserved for Phase 4+.
    """

    def __init__(self, config: RunnerConfig) -> None:
        self.config = config
        self.sandbox_manager = SandboxManager()
        self._sandbox: Sandbox | None = None
        self._sandboxes: list[Sandbox] = []
        if self.config.harness != "claude":
            raise NotImplementedError(
                f"Harness '{self.config.harness}' is not supported in Phase 2. "
                "Only 'claude' is supported."
            )

    def _check_recursion_depth(self) -> None:
        depth = int(os.environ.get(ENV_CHILD_DEPTH, "0"))
        if depth >= MAX_CHILD_DEPTH:
            raise RuntimeError(
                f"Recursion depth limit reached ({MAX_CHILD_DEPTH}). "
                "SkillExecutor detected nested execution."
            )

    def _resolve_skill_path(self) -> Path:
        if not self.config.skill_path:
            raise ValueError("runner.skill_path is required for type: skill")
        path = Path(self.config.skill_path).resolve()
        if not path.exists():
            raise FileNotFoundError(f"Skill file not found: {path}")
        return path

    async def execute(
        self, *, input_text: str, context: RunContext, run_id: str
    ) -> RunResult:
        self._check_recursion_depth()
        skill_path = self._resolve_skill_path()
        collector = EvidenceCollector()

        source_dir = Path(self.config.working_directory).resolve()
        sandbox = self.sandbox_manager.create_sandbox(
            copy_files=self.config.sandbox.copy_files or None,
            source_dir=source_dir,
        )
        self._sandbox = sandbox
        self._sandboxes.append(sandbox)

        sandbox.install_skill(skill_path)

        child_depth = int(os.environ.get(ENV_CHILD_DEPTH, "0")) + 1
        env = {
            **self.config.environment_vars,
            ENV_CHILD_DEPTH: str(child_depth),
        }

        start = time.monotonic()

        try:
            response_text, token_usage, cost = await self._run_sdk_query(
                input_text=input_text,
                sandbox=sandbox,
                collector=collector,
                env=env,
            )

            sandbox_files = self._list_sandbox_files(sandbox)

            skill_metadata = SkillMetadata(
                skill_path=str(skill_path),
                harness=self.config.harness,
                sandbox_path=str(sandbox.workspace_path),
                turn_count=collector.turn_count,
                total_cost_usd=cost,
                files_created=collector.files_created,
                commands_executed=collector.commands_executed,
            )

            return RunResult(
                run_id=run_id,
                success=True,
                output=response_text,
                duration_ms=int((time.monotonic() - start) * 1000),
                token_usage=token_usage,
                tool_calls=[
                    {
                        "turn": tc.turn,
                        "tool": tc.tool,
                        "input": tc.input,
                        "output": tc.output,
                        "is_error": tc.is_error,
                        "duration_ms": tc.duration_ms,
                    }
                    for tc in collector.tool_calls
                ],
                metadata={
                    "skill_metadata": {
                        "skill_path": skill_metadata.skill_path,
                        "harness": skill_metadata.harness,
                        "sandbox_path": skill_metadata.sandbox_path,
                        "turn_count": skill_metadata.turn_count,
                        "total_cost_usd": skill_metadata.total_cost_usd,
                        "files_created": skill_metadata.files_created,
                        "commands_executed": skill_metadata.commands_executed,
                    },
                    "sandbox_files": sandbox_files,
                },
            )

        except Exception as e:
            return RunResult(
                run_id=run_id,
                success=False,
                output="",
                duration_ms=int((time.monotonic() - start) * 1000),
                error=RunError(
                    message=str(e),
                    traceback=tb_mod.format_exc(),
                ),
                metadata={
                    "skill_metadata": {
                        "skill_path": str(skill_path),
                        "harness": self.config.harness,
                        "sandbox_path": str(sandbox.workspace_path),
                    }
                },
            )

    async def _run_sdk_query(
        self,
        *,
        input_text: str,
        sandbox: Sandbox,
        collector: EvidenceCollector,
        env: dict[str, str],
    ) -> tuple[str, TokenUsage | None, float | None]:
        """Call Claude Agent SDK query().

        Returns:
            (response_text, token_usage, total_cost_usd)
        """
        from claude_agent_sdk import (
            AssistantMessage,
            ClaudeAgentOptions,
            ResultMessage,
            TextBlock,
            ToolResultBlock,
            ToolUseBlock,
            query,
        )

        options = ClaudeAgentOptions(
            cwd=str(sandbox.workspace_path),
            allowed_tools=self.config.allowed_tools or None,
            disallowed_tools=self.config.disallowed_tools or None,
            max_turns=self.config.skill_max_turns,
            max_budget_usd=self.config.budget.max_budget_usd,
            permission_mode="bypassPermissions",
            setting_sources=[],
            env=env,
        )

        response_text = ""
        total_input_tokens = 0
        total_output_tokens = 0
        total_cost: float | None = None

        async for message in query(prompt=input_text, options=options):
            if isinstance(message, AssistantMessage):
                for block in message.content:
                    if isinstance(block, TextBlock):
                        response_text += block.text
                    elif isinstance(block, ToolUseBlock):
                        collector.record_tool_use(
                            tool_name=block.name,
                            tool_input=block.input if isinstance(block.input, dict) else {},
                        )
                    elif isinstance(block, ToolResultBlock):
                        output = block.content if isinstance(block.content, str) else str(block.content)
                        collector.record_tool_result(
                            output=output,
                            is_error=getattr(block, "is_error", False),
                            duration_ms=getattr(block, "duration_ms", 0) or 0,
                        )
                collector.increment_turn()

            elif isinstance(message, ResultMessage):
                total_input_tokens = getattr(message, "input_tokens", 0) or 0
                total_output_tokens = getattr(message, "output_tokens", 0) or 0
                total_cost = getattr(message, "total_cost_usd", None)

        token_usage = TokenUsage(
            input_tokens=total_input_tokens,
            output_tokens=total_output_tokens,
            total_tokens=total_input_tokens + total_output_tokens,
        )

        return response_text, token_usage, total_cost

    def _list_sandbox_files(self, sandbox: Sandbox) -> list[str]:
        """List all file paths in sandbox, relative to workspace root."""
        files = []
        for p in sandbox.workspace_path.rglob("*"):
            if p.is_file() and ".claude" not in p.parts:
                files.append(
                    str(p.relative_to(sandbox.workspace_path))
                )
        return sorted(files)

    async def cleanup(self) -> None:
        sandboxes = list(self._sandboxes)
        self._sandboxes.clear()
        self._sandbox = None
        for sandbox in sandboxes:
            sandbox.cleanup()
