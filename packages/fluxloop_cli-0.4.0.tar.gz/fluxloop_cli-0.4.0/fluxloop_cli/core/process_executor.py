"""ProcessExecutor — execute an external NDJSON-speaking process."""

from __future__ import annotations

import asyncio
import json
import os
import time
import traceback
from asyncio.subprocess import PIPE, Process
from typing import Any

from ..config.schema import RunnerConfig
from .executor import RunContext, RunError, RunResult, TokenUsage


class ProcessExecutor:
    def __init__(self, config: RunnerConfig) -> None:
        self.config = config
        self._process: Process | None = None

        if not self.config.command:
            raise ValueError(
                "runner.command is required for type: process "
                "(e.g., ['python', 'agent.py'])"
            )
        if self.config.protocol != "ndjson":
            raise ValueError(f"Unsupported process protocol: {self.config.protocol}")

    async def execute(
        self, *, input_text: str, context: RunContext, run_id: str
    ) -> RunResult:
        start = time.monotonic()

        try:
            response = await self._run_process(
                input_text=input_text,
                context=context,
                run_id=run_id,
            )
            duration_ms = int((time.monotonic() - start) * 1000)

            token_usage = _extract_token_usage(response.get("token_usage"))
            tool_calls = response.get("tool_calls")
            metadata = response.get("metadata") if isinstance(response.get("metadata"), dict) else {}

            return RunResult(
                run_id=run_id,
                success=bool(response.get("success")),
                output=str(response.get("output", "")),
                duration_ms=int(response.get("duration_ms", duration_ms)),
                token_usage=token_usage,
                tool_calls=tool_calls if isinstance(tool_calls, list) else [],
                error=_extract_error(response.get("error")),
                metadata={
                    **metadata,
                    "process_command": self.config.command,
                    "protocol": self.config.protocol,
                },
            )
        except Exception as exc:
            return RunResult(
                run_id=run_id,
                success=False,
                output="",
                duration_ms=int((time.monotonic() - start) * 1000),
                error=RunError(
                    message=str(exc),
                    traceback=traceback.format_exc(),
                ),
                metadata={
                    "process_command": self.config.command,
                    "protocol": self.config.protocol,
                },
            )

    async def _run_process(
        self, *, input_text: str, context: RunContext, run_id: str
    ) -> dict[str, Any]:
        command = self.config.command or []
        env = {
            **os.environ,
            **self.config.environment_vars,
            **context.environment_vars,
        }
        request = {
            "run_id": run_id,
            "input_text": input_text,
            "context": {
                "iteration": context.iteration,
                "persona": context.persona,
                "scenario": context.scenario,
            },
        }

        proc = await asyncio.create_subprocess_exec(
            *command,
            cwd=self.config.working_directory,
            env=env,
            stdin=PIPE,
            stdout=PIPE,
            stderr=PIPE,
        )
        self._process = proc

        try:
            stdout, stderr = await asyncio.wait_for(
                proc.communicate((json.dumps(request) + "\n").encode("utf-8")),
                timeout=self.config.timeout_seconds,
            )
        except asyncio.TimeoutError as exc:
            proc.terminate()
            try:
                await asyncio.wait_for(proc.wait(), timeout=5)
            except asyncio.TimeoutError:
                proc.kill()
                await proc.wait()
            raise TimeoutError(f"Timed out after {self.config.timeout_seconds}s") from exc
        finally:
            self._process = None

        response = _parse_ndjson_response(stdout.decode("utf-8", errors="replace"))
        stderr_text = stderr.decode("utf-8", errors="replace").strip()

        if response is not None:
            return response

        if proc.returncode not in (0, None):
            suffix = f": {stderr_text[:500]}" if stderr_text else ""
            raise RuntimeError(f"Process exited with code {proc.returncode}{suffix}")

        raise RuntimeError("No NDJSON response received from process")

    async def cleanup(self) -> None:
        if self._process and self._process.returncode is None:
            self._process.terminate()
            try:
                await asyncio.wait_for(self._process.wait(), timeout=5)
            except asyncio.TimeoutError:
                self._process.kill()
                await self._process.wait()
        self._process = None


def _parse_ndjson_response(stdout: str) -> dict[str, Any] | None:
    response: dict[str, Any] | None = None

    for line in stdout.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            parsed = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(parsed, dict):
            response = parsed

    return response


def _extract_token_usage(raw: Any) -> TokenUsage | None:
    if not isinstance(raw, dict):
        return None

    return TokenUsage(
        input_tokens=int(raw.get("input_tokens", 0) or 0),
        output_tokens=int(raw.get("output_tokens", 0) or 0),
        total_tokens=int(raw.get("total_tokens", 0) or 0),
    )


def _extract_error(raw: Any) -> RunError | None:
    if not isinstance(raw, dict) or not raw.get("message"):
        return None

    return RunError(
        message=str(raw.get("message", "")),
        traceback=str(raw["traceback"]) if raw.get("traceback") is not None else None,
    )
