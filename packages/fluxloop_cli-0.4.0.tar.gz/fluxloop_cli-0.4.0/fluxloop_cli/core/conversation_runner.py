"""Shared multi-turn orchestration for function/process runners."""

from __future__ import annotations

import traceback
from typing import Protocol

from ..config.schema import ConversationMessage
from .executor import RunContext, RunError, RunExecutor, RunResult, TokenUsage
from .user_simulator import SimulatorResult


class SupportsNextMessage(Protocol):
    async def next_message(
        self, conversation: list[ConversationMessage]
    ) -> SimulatorResult: ...


def _merge_token_usage(
    total: TokenUsage | None, delta: TokenUsage | None
) -> TokenUsage | None:
    if delta is None:
        return total
    if total is None:
        return TokenUsage(
            input_tokens=delta.input_tokens,
            output_tokens=delta.output_tokens,
            total_tokens=delta.total_tokens,
        )
    return TokenUsage(
        input_tokens=total.input_tokens + delta.input_tokens,
        output_tokens=total.output_tokens + delta.output_tokens,
        total_tokens=total.total_tokens + delta.total_tokens,
    )


def _build_result(
    *,
    run_id: str,
    success: bool,
    output: str,
    duration_ms: int,
    turn_count: int,
    termination_reason: str | None,
    conversation: list[ConversationMessage],
    token_usage: TokenUsage | None,
    tool_calls: list[dict],
    error: RunError | None,
    metadata: dict,
) -> RunResult:
    return RunResult(
        run_id=run_id,
        success=success,
        output=output,
        duration_ms=duration_ms,
        turn_count=turn_count,
        termination_reason=termination_reason,
        token_usage=token_usage,
        conversation=conversation,
        tool_calls=tool_calls,
        error=error,
        metadata=metadata,
    )


async def execute_conversation(
    *,
    executor: RunExecutor,
    simulator: SupportsNextMessage,
    initial_input: str,
    context: RunContext,
    run_id: str,
    max_turns: int,
) -> RunResult:
    conversation: list[ConversationMessage] = []
    current_input = initial_input
    total_duration_ms = 0
    total_token_usage: TokenUsage | None = None
    tool_calls: list[dict] = []
    metadata: dict = {}
    last_output = ""

    for turn_index in range(max_turns):
        conversation.append(ConversationMessage(role="user", content=current_input))
        result = await executor.execute(
            input_text=current_input,
            context=context,
            run_id=run_id,
        )

        total_duration_ms += result.duration_ms
        total_token_usage = _merge_token_usage(total_token_usage, result.token_usage)
        tool_calls.extend(result.tool_calls)
        metadata = result.metadata
        last_output = result.output

        if result.output:
            conversation.append(
                ConversationMessage(role="assistant", content=result.output)
            )

        turn_count = turn_index + 1
        if not result.success:
            return _build_result(
                run_id=run_id,
                success=False,
                output=result.output,
                duration_ms=total_duration_ms,
                turn_count=turn_count,
                termination_reason="execution_failed",
                conversation=conversation,
                token_usage=total_token_usage,
                tool_calls=tool_calls,
                error=result.error,
                metadata=metadata,
            )

        if turn_index == max_turns - 1:
            return _build_result(
                run_id=run_id,
                success=True,
                output=last_output,
                duration_ms=total_duration_ms,
                turn_count=turn_count,
                termination_reason="max_turns_reached",
                conversation=conversation,
                token_usage=total_token_usage,
                tool_calls=tool_calls,
                error=None,
                metadata=metadata,
            )

        try:
            simulator_result = await simulator.next_message(conversation)
        except Exception as exc:
            return _build_result(
                run_id=run_id,
                success=False,
                output=last_output,
                duration_ms=total_duration_ms,
                turn_count=turn_count,
                termination_reason="simulator_error",
                conversation=conversation,
                token_usage=total_token_usage,
                tool_calls=tool_calls,
                error=RunError(
                    message=str(exc),
                    traceback=traceback.format_exc(),
                ),
                metadata=metadata,
            )

        if not simulator_result.should_continue:
            return _build_result(
                run_id=run_id,
                success=True,
                output=last_output,
                duration_ms=total_duration_ms,
                turn_count=turn_count,
                termination_reason=simulator_result.termination_reason,
                conversation=conversation,
                token_usage=total_token_usage,
                tool_calls=tool_calls,
                error=None,
                metadata=metadata,
            )

        current_input = simulator_result.next_message or ""

    raise RuntimeError("conversation loop exited unexpectedly")
