"""FunctionExecutor — direct Python function invocation."""

from __future__ import annotations

import asyncio
import importlib
import multiprocessing
import os
import queue
import sys
import time
import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from ..config.schema import RunnerConfig
from .executor import RunContext, RunError, RunResult, TokenUsage

_START_METHOD = (
    "fork" if "fork" in multiprocessing.get_all_start_methods() else "spawn"
)


@dataclass(frozen=True)
class _TargetSpec:
    module_path: str
    func_name: str
    working_directory: str


class FunctionExecutor:
    def __init__(self, config: RunnerConfig) -> None:
        self.config = config
        self._handler: Callable | None = None

    def _parse_target(self) -> _TargetSpec:
        if not self.config.target:
            raise ValueError("runner.target is required for type: function")

        module_path, _, func_name = self.config.target.partition(":")
        if not func_name:
            raise ValueError("target must be 'module:function' format")

        return _TargetSpec(
            module_path=module_path,
            func_name=func_name,
            working_directory=str(Path(self.config.working_directory).resolve()),
        )

    def _load_handler(self) -> Callable:
        target = self._parse_target()
        return _load_handler(target)

    async def execute(
        self, *, input_text: str, context: RunContext, run_id: str
    ) -> RunResult:
        start = time.monotonic()

        try:
            target = self._parse_target()
        except Exception as e:
            return RunResult(
                run_id=run_id,
                success=False,
                output="",
                duration_ms=int((time.monotonic() - start) * 1000),
                error=RunError(
                    message=str(e),
                    traceback=traceback.format_exc(),
                ),
            )

        result_queue: multiprocessing.Queue = multiprocessing.get_context(
            _START_METHOD
        ).Queue(maxsize=1)
        process = multiprocessing.get_context(_START_METHOD).Process(
            target=_run_handler_in_subprocess,
            args=(
                result_queue,
                target,
                input_text,
                context.environment_vars,
            ),
        )
        process.daemon = True
        process.start()

        try:
            await asyncio.wait_for(
                asyncio.to_thread(process.join),
                timeout=self.config.timeout_seconds,
            )
        except asyncio.TimeoutError:
            try:
                if process.is_alive():
                    process.kill()
                    process.join()
                return RunResult(
                    run_id=run_id,
                    success=False,
                    output="",
                    duration_ms=int((time.monotonic() - start) * 1000),
                    error=RunError(
                        message=f"Timed out after {self.config.timeout_seconds}s",
                    ),
                )
            finally:
                result_queue.close()
                result_queue.join_thread()
                process.close()

        try:
            payload = result_queue.get_nowait()
        except queue.Empty:
            exit_code = process.exitcode
            return RunResult(
                run_id=run_id,
                success=False,
                output="",
                duration_ms=int((time.monotonic() - start) * 1000),
                error=RunError(
                    message=(
                        f"Function worker exited with code {exit_code}"
                        if exit_code not in (0, None)
                        else "Function worker exited without returning a result"
                    ),
                ),
            )
        finally:
            result_queue.close()
            result_queue.join_thread()
            process.close()

        if payload["success"]:
            return RunResult(
                run_id=run_id,
                success=True,
                output=str(payload["output"]),
                duration_ms=int((time.monotonic() - start) * 1000),
                token_usage=(
                    TokenUsage(**payload["token_usage"])
                    if payload.get("token_usage")
                    else None
                ),
            )

        return RunResult(
            run_id=run_id,
            success=False,
            output="",
            duration_ms=int((time.monotonic() - start) * 1000),
            error=RunError(
                message=str(payload["error"]["message"]),
                traceback=(
                    str(payload["error"]["traceback"])
                    if payload["error"].get("traceback") is not None
                    else None
                ),
            ),
        )

    async def cleanup(self) -> None:
        pass


def _load_handler(target: _TargetSpec) -> Callable:
    if target.working_directory not in sys.path:
        sys.path.insert(0, target.working_directory)

    module = importlib.import_module(target.module_path)
    handler = getattr(module, target.func_name)
    if not callable(handler):
        raise ValueError(f"{target.module_path}:{target.func_name} is not callable")
    return handler


def _run_handler_in_subprocess(
    result_queue: multiprocessing.Queue,
    target: _TargetSpec,
    input_text: str,
    environment_vars: dict[str, str],
) -> None:
    try:
        for key, value in environment_vars.items():
            os.environ[key] = value

        handler = _load_handler(target)
        if asyncio.iscoroutinefunction(handler):
            output = asyncio.run(handler(input_text))
        else:
            output = handler(input_text)

        token_usage = _extract_token_usage(output)
        result_queue.put(
            {
                "success": True,
                "output": str(output),
                "token_usage": (
                    token_usage.model_dump() if token_usage is not None else None
                ),
            }
        )
    except Exception as e:
        result_queue.put(
            {
                "success": False,
                "error": {
                    "message": str(e),
                    "traceback": traceback.format_exc(),
                },
            }
        )


def _extract_token_usage(output: Any) -> TokenUsage | None:
    """Try to extract token usage from output if it's a dict-like object."""
    if isinstance(output, dict):
        usage = output.get("token_usage") or output.get("usage")
        if isinstance(usage, dict):
            return TokenUsage(
                input_tokens=usage.get("input_tokens", 0),
                output_tokens=usage.get("output_tokens", 0),
                total_tokens=usage.get("total_tokens", 0),
            )
    return None
