"""RunExecutor protocol and factory."""

from __future__ import annotations

from typing import Any, Protocol

from pydantic import BaseModel, Field

from ..config.schema import ConversationMessage, RunnerConfig


class TokenUsage(BaseModel):
    input_tokens: int = 0
    output_tokens: int = 0
    total_tokens: int = 0


class RunError(BaseModel):
    message: str
    traceback: str | None = None


class RunContext(BaseModel):
    iteration: int = 0
    persona: str | None = None
    scenario: str | None = None
    environment_vars: dict[str, str] = Field(default_factory=dict)


class RunResult(BaseModel):
    run_id: str
    success: bool
    output: str
    duration_ms: int
    turn_count: int | None = None
    termination_reason: str | None = None
    token_usage: TokenUsage | None = None
    conversation: list[ConversationMessage] = Field(default_factory=list)
    tool_calls: list[dict[str, Any]] = Field(default_factory=list)
    error: RunError | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class RunExecutor(Protocol):
    async def execute(
        self, *, input_text: str, context: RunContext, run_id: str
    ) -> RunResult: ...

    async def cleanup(self) -> None: ...


def create_executor(config: RunnerConfig) -> RunExecutor:
    match config.type:
        case "function":
            from .function_executor import FunctionExecutor

            return FunctionExecutor(config)
        case "skill":
            from .skill_executor import SkillExecutor

            return SkillExecutor(config)
        case "process":
            from .process_executor import ProcessExecutor

            return ProcessExecutor(config)
        case _:
            raise ValueError(f"Unknown runner type: {config.type}")
