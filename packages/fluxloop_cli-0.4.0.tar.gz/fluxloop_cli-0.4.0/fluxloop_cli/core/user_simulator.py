"""LLM-backed user simulator for multi-turn orchestration."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass

import httpx

from ..config.schema import ConversationMessage, ConversationSimulatorConfig


SIMULATOR_RESPONSE_INSTRUCTIONS = (
    "Return only strict JSON with keys "
    "`should_continue` (boolean), `next_message` (string or null), "
    "and `termination_reason` (string or null). "
    "If `should_continue` is true, `next_message` must be a user message and "
    "`termination_reason` must be null. "
    "If `should_continue` is false, `next_message` must be null and "
    "`termination_reason` must be non-null. "
    "Do not include markdown fences."
)


@dataclass
class SimulatorResult:
    should_continue: bool
    next_message: str | None
    termination_reason: str | None


class UserSimulator:
    def __init__(self, config: ConversationSimulatorConfig) -> None:
        self.config = config

    def validate_configuration(self) -> None:
        match self.config.provider:
            case "anthropic":
                if not os.environ.get("ANTHROPIC_API_KEY"):
                    raise ValueError(
                        "ANTHROPIC_API_KEY is required for conversation simulator provider=anthropic"
                    )
            case "openai":
                if not os.environ.get("OPENAI_API_KEY"):
                    raise ValueError(
                        "OPENAI_API_KEY is required for conversation simulator provider=openai"
                    )
            case _:
                raise ValueError(
                    f"Unsupported conversation simulator provider: {self.config.provider}"
                )

    async def next_message(
        self, conversation: list[ConversationMessage]
    ) -> SimulatorResult:
        prompt = self._build_prompt(conversation)
        response_text = await self._complete(prompt)
        return self._parse_response(response_text)

    def _build_prompt(self, conversation: list[ConversationMessage]) -> str:
        conversation_payload = [
            message.model_dump() if hasattr(message, "model_dump") else message
            for message in conversation
        ]
        return (
            "Conversation history:\n"
            f"{json.dumps(conversation_payload, ensure_ascii=False, indent=2)}\n\n"
            f"{SIMULATOR_RESPONSE_INSTRUCTIONS}"
        )

    async def _complete(self, prompt: str) -> str:
        if self.config.provider == "anthropic":
            return await self._complete_anthropic(prompt)
        if self.config.provider == "openai":
            return await self._complete_openai(prompt)
        raise ValueError(
            f"Unsupported conversation simulator provider: {self.config.provider}"
        )

    async def _complete_anthropic(self, prompt: str) -> str:
        api_key = os.environ["ANTHROPIC_API_KEY"]
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                "https://api.anthropic.com/v1/messages",
                headers={
                    "x-api-key": api_key,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
                json={
                    "model": self.config.model,
                    "max_tokens": 256,
                    "temperature": self.config.temperature,
                    "system": self.config.system_prompt,
                    "messages": [
                        {
                            "role": "user",
                            "content": [{"type": "text", "text": prompt}],
                        }
                    ],
                },
            )
            response.raise_for_status()
            payload = response.json()

        content = payload.get("content", [])
        text_parts = []
        for item in content:
            if isinstance(item, dict) and item.get("type") == "text":
                text = item.get("text")
                if isinstance(text, str):
                    text_parts.append(text)
        return "\n".join(text_parts).strip()

    async def _complete_openai(self, prompt: str) -> str:
        api_key = os.environ["OPENAI_API_KEY"]
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                "https://api.openai.com/v1/chat/completions",
                headers={
                    "authorization": f"Bearer {api_key}",
                    "content-type": "application/json",
                },
                json={
                    "model": self.config.model,
                    "temperature": self.config.temperature,
                    "response_format": {"type": "json_object"},
                    "messages": [
                        {"role": "system", "content": self.config.system_prompt},
                        {"role": "user", "content": prompt},
                    ],
                },
            )
            response.raise_for_status()
            payload = response.json()

        choices = payload.get("choices", [])
        if not choices:
            raise ValueError("OpenAI simulator response did not include choices")
        message = choices[0].get("message", {})
        content = message.get("content")
        if not isinstance(content, str):
            raise ValueError("OpenAI simulator response content must be a string")
        return content.strip()

    def _parse_response(self, response_text: str) -> SimulatorResult:
        try:
            payload = json.loads(response_text)
        except json.JSONDecodeError as exc:
            raise ValueError("Simulator response was not valid JSON") from exc

        should_continue = payload.get("should_continue")
        next_message = payload.get("next_message")
        termination_reason = payload.get("termination_reason")

        if not isinstance(should_continue, bool):
            raise ValueError("Simulator response must include boolean should_continue")

        if should_continue:
            if not isinstance(next_message, str) or not next_message.strip():
                raise ValueError(
                    "Simulator response must include non-empty next_message when should_continue=true"
                )
            if termination_reason is not None:
                raise ValueError(
                    "Simulator response termination_reason must be null when should_continue=true"
                )
            return SimulatorResult(
                should_continue=True,
                next_message=next_message.strip(),
                termination_reason=None,
            )

        if next_message is not None:
            raise ValueError(
                "Simulator response next_message must be null when should_continue=false"
            )
        if not isinstance(termination_reason, str) or not termination_reason.strip():
            raise ValueError(
                "Simulator response must include termination_reason when should_continue=false"
            )
        return SimulatorResult(
            should_continue=False,
            next_message=None,
            termination_reason=termination_reason.strip(),
        )
