"""Backend helpers for input refinement."""

from __future__ import annotations

from typing import Any

import httpx


def refine_inputs(
    client: httpx.Client,
    *,
    project_id: str,
    scenario_id: str,
    input_set_id: str,
    bundle_version_id: str | None = None,
    dry_run: bool = False,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "project_id": project_id,
        "scenario_id": scenario_id,
        "input_set_id": input_set_id,
        "dry_run": dry_run,
    }
    if bundle_version_id:
        payload["bundle_version_id"] = bundle_version_id

    response = client.post("/api/inputs/refine", json=payload)
    response.raise_for_status()
    return response.json()
