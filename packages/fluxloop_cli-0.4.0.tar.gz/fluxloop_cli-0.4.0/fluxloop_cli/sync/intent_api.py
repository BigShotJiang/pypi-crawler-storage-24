"""Backend helpers for intent refinement."""

from __future__ import annotations

from typing import Any

import httpx


def refine_intent(
    client: httpx.Client,
    *,
    project_id: str,
    intent: str,
    scenario_id: str | None = None,
    bundle_version_id: str | None = None,
    apply: bool = False,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "project_id": project_id,
        "intent": intent,
        "apply": apply,
    }
    if scenario_id:
        payload["scenario_id"] = scenario_id
    if bundle_version_id:
        payload["bundle_version_id"] = bundle_version_id

    response = client.post("/api/intents/refine", json=payload)
    response.raise_for_status()
    return response.json()
