"""SyncUploader — upload local run results to server."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import httpx

from .client import post_with_retry
from .meta import read_bundle_version_id


class SyncUploader:
    def __init__(self, client: httpx.Client) -> None:
        self._client = client

    def upload_from_result_dir(
        self,
        result_dir: Path,
        scenario_dir: Path,
        *,
        cli_version: str | None = None,
    ) -> dict[str, Any]:
        """Read trace_summary.jsonl + summary.json from result_dir and upload."""
        bundle_version_id = self._read_bundle_version_id(scenario_dir)
        if not bundle_version_id:
            raise ValueError(
                "No bundle_version_id found. Run 'fluxloop sync pull' first."
            )

        traces = self._read_traces(result_dir)
        if not traces:
            raise ValueError(f"No trace data found in {result_dir}")

        payload = self._build_upload_payload(
            bundle_version_id, traces, cli_version=cli_version
        )

        resp = post_with_retry(
            self._client,
            "/api/sync/upload",
            payload=payload,
        )
        return resp.json()

    def _read_bundle_version_id(self, scenario_dir: Path) -> str | None:
        return read_bundle_version_id(scenario_dir)

    def _read_traces(self, result_dir: Path) -> list[dict[str, Any]]:
        trace_path = result_dir / "trace_summary.jsonl"
        if not trace_path.exists():
            return []
        traces = []
        for line in trace_path.read_text().splitlines():
            line = line.strip()
            if line:
                traces.append(json.loads(line))
        return traces

    def _build_upload_payload(
        self,
        bundle_version_id: str,
        traces: list[dict[str, Any]],
        *,
        cli_version: str | None = None,
    ) -> dict[str, Any]:
        now = datetime.now(timezone.utc).isoformat()

        runs: list[dict[str, Any]] = []
        run_results: list[dict[str, Any]] = []
        turns: list[dict[str, Any]] = []

        for trace in traces:
            run_id = trace.get("run_id", "")
            input_metadata = trace.get("input_metadata")
            if not isinstance(input_metadata, dict):
                input_metadata = {}
            input_item_id = (
                trace.get("input_item_id")
                or input_metadata.get("input_item_id")
                or input_metadata.get("id", "")
            )
            input_snapshot = self._build_input_snapshot(
                trace.get("input", ""),
                input_metadata,
            )
            persona_id = (
                trace.get("persona")
                or input_metadata.get("persona_id")
            )

            runs.append({
                "id": run_id,
                "input_item_id": input_item_id,
                "persona_id": persona_id,
                "status": "completed" if trace.get("success") else "failed",
                "input_snapshot": input_snapshot,
            })

            transcript = self._build_transcript(trace)
            metrics = self._build_metrics(trace)
            run_result = {
                "run_id": run_id,
                "status": "completed" if trace.get("success") else "failed",
                "transcript": transcript,
            }
            if metrics is not None:
                run_result["metrics"] = metrics
            run_results.append(run_result)

            for i, message in enumerate(self._build_turn_messages(trace)):
                turns.append({
                    "run_id": run_id,
                    "turn_id": f"{run_id}-t{i}",
                    "sequence": i,
                    "role": message["role"],
                    "content": message["content"],
                    "timestamp": str(trace.get("timestamp") or now),
                    "duration_ms": (
                        trace.get("duration_ms")
                        if i == len(transcript) - 1
                        else None
                    ),
                })

        run_batch: dict[str, Any] = {
            "execution_target": "local",
            "status": "completed",
            "started_at": now,
            "completed_at": now,
        }

        payload: dict[str, Any] = {
            "bundle_version_id": bundle_version_id,
            "run_batch": run_batch,
            "runs": runs,
            "turns": turns,
            "run_results": run_results,
        }

        if cli_version:
            payload["upload_meta"] = {"cli_version": cli_version}

        return payload

    def _build_metrics(self, trace: dict[str, Any]) -> dict[str, Any] | None:
        metrics: dict[str, Any] = {}
        if isinstance(trace.get("duration_ms"), int):
            metrics["duration_ms"] = trace["duration_ms"]
        if isinstance(trace.get("turn_count"), int):
            metrics["turn_count"] = trace["turn_count"]
        if "termination_reason" in trace:
            metrics["termination_reason"] = trace.get("termination_reason")
        return metrics or None

    def _build_turn_messages(self, trace: dict[str, Any]) -> list[dict[str, str]]:
        conversation = trace.get("conversation")
        if isinstance(conversation, list) and conversation:
            messages: list[dict[str, str]] = []
            for item in conversation:
                if not isinstance(item, dict):
                    continue
                role = item.get("role")
                content = item.get("content")
                if role in {"user", "assistant", "system"} and isinstance(content, str):
                    messages.append({"role": role, "content": content})
            if messages:
                return messages
        return []

    def _build_transcript(self, trace: dict[str, Any]) -> list[dict[str, str]]:
        transcript = self._build_turn_messages(trace)
        if transcript:
            return transcript

        fallback: list[dict[str, str]] = []
        input_text = trace.get("input")
        if isinstance(input_text, str) and input_text:
            fallback.append({"role": "user", "content": input_text})
        output_text = trace.get("output")
        if isinstance(output_text, str) and output_text:
            fallback.append({"role": "assistant", "content": output_text})
        elif isinstance(trace.get("error"), dict):
            message = trace["error"].get("message")
            if isinstance(message, str) and message:
                fallback.append({"role": "assistant", "content": message})
        return fallback

    def _build_input_snapshot(
        self,
        input_text: str,
        input_metadata: dict[str, Any],
    ) -> dict[str, Any]:
        metadata = input_metadata.get("metadata")
        if not isinstance(metadata, dict):
            metadata = {
                key: value
                for key, value in input_metadata.items()
                if key
                not in {
                    "id",
                    "input_item_id",
                    "persona_id",
                    "scenario_id",
                    "input_set_id",
                    "messages",
                    "text",
                    "content",
                    "metadata",
                }
            }

        messages = input_metadata.get("messages")
        if not isinstance(messages, list) or not messages:
            messages = [{"role": "user", "content": input_text}]

        snapshot: dict[str, Any] = {
            "messages": messages,
            "metadata": metadata,
        }
        for key in ("id", "persona_id", "scenario_id", "input_set_id"):
            value = input_metadata.get(key)
            if value:
                snapshot[key] = value
        return snapshot
