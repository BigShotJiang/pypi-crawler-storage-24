"""Synchronous job polling helper."""

from __future__ import annotations

import time
from typing import Any, Callable

import httpx

from .client import get_with_retry

TERMINAL_STATUSES = {"completed", "failed", "cancelled", "error"}


def poll_job(
    client: httpx.Client,
    endpoint: str,
    *,
    params: dict[str, Any] | None = None,
    interval: float = 3.0,
    timeout: float = 300.0,
    terminal_statuses: set[str] | None = None,
    select_status: Callable[[Any], str | None] | None = None,
) -> Any:
    """Poll an endpoint until a terminal status is reached or timeout."""
    statuses = terminal_statuses or TERMINAL_STATUSES
    elapsed = 0.0
    last_status = "unknown"

    while elapsed < timeout:
        resp = get_with_retry(client, endpoint, params=params)
        data = resp.json()

        if select_status:
            status = select_status(data)
        elif isinstance(data, dict):
            status = data.get("status")
        elif isinstance(data, list) and len(data) == 1 and isinstance(data[0], dict):
            status = data[0].get("status")
        else:
            status = None

        if status:
            last_status = status
        if status in statuses:
            return data

        time.sleep(interval)
        elapsed += interval

    raise TimeoutError(
        f"Job did not complete within {timeout}s (last status: {last_status})"
    )
