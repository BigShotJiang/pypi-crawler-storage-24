"""Authenticated HTTP client for FluxLoop API."""

from __future__ import annotations

import os
import time
from typing import Any

import httpx

from ..auth.device_flow import ensure_valid_token
from ..workspace.context import resolve_fluxloop_dir


class FluxLoopAPIError(Exception):
    def __init__(self, message: str, status_code: int | None = None):
        self.message = message
        self.status_code = status_code
        super().__init__(message)


def create_client(
    api_url: str,
    *,
    use_jwt: bool = True,
    timeout: float = 30.0,
) -> httpx.Client:
    """Create an HTTP client with authentication headers.

    Priority:
    1. JWT token (if use_jwt=True)
    2. API Key from environment variables
    3. Raise error
    """
    headers: dict[str, str] = {}
    _load_workspace_env()

    if use_jwt:
        token = ensure_valid_token(api_url)
        if token:
            headers["Authorization"] = f"Bearer {token.access_token}"
            return httpx.Client(base_url=api_url, timeout=timeout, headers=headers)

    api_key = os.getenv("FLUXLOOP_SYNC_API_KEY") or os.getenv("FLUXLOOP_API_KEY")
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
        return httpx.Client(base_url=api_url, timeout=timeout, headers=headers)

    if use_jwt:
        raise FluxLoopAPIError("Login required. Run 'fluxloop auth login'.")
    raise FluxLoopAPIError("API Key not set. Set FLUXLOOP_API_KEY environment variable.")


def close_client(client: Any) -> None:
    close = getattr(client, "close", None)
    if callable(close):
        close()


def _load_workspace_env() -> None:
    """Load workspace .env so persisted API keys are available across invocations."""
    try:
        from dotenv import load_dotenv
    except ImportError:
        return

    env_path = resolve_fluxloop_dir() / ".env"
    if env_path.exists():
        load_dotenv(env_path, override=False)


def post_with_retry(
    client: httpx.Client,
    endpoint: str,
    *,
    payload: dict[str, Any],
    max_retries: int = 3,
    backoff_seconds: float = 1.0,
) -> httpx.Response:
    return _request_with_retry(
        client,
        "post",
        endpoint,
        json=payload,
        max_retries=max_retries,
        backoff_seconds=backoff_seconds,
    )


def get_with_retry(
    client: httpx.Client,
    endpoint: str,
    *,
    params: dict[str, Any] | None = None,
    max_retries: int = 3,
    backoff_seconds: float = 1.0,
) -> httpx.Response:
    return _request_with_retry(
        client,
        "get",
        endpoint,
        params=params,
        max_retries=max_retries,
        backoff_seconds=backoff_seconds,
    )


def _request_with_retry(
    client: httpx.Client,
    method: str,
    endpoint: str,
    *,
    max_retries: int,
    backoff_seconds: float,
    **request_kwargs: Any,
) -> httpx.Response:
    request = getattr(client, method)
    attempt = 0
    last_exception: Exception | None = None

    while attempt <= max_retries:
        try:
            resp = request(endpoint, **request_kwargs)
            _handle_error_response(resp)
            resp.raise_for_status()
            return resp
        except FluxLoopAPIError:
            raise
        except httpx.HTTPStatusError as e:
            if not _is_retryable_status(e.response.status_code):
                raise
            last_exception = e
            attempt += 1
            if attempt > max_retries:
                break
            time.sleep(backoff_seconds * (2 ** (attempt - 1)))
        except httpx.RequestError as e:
            last_exception = e
            attempt += 1
            if attempt > max_retries:
                break
            time.sleep(backoff_seconds * (2 ** (attempt - 1)))

    if last_exception:
        raise last_exception
    raise httpx.HTTPError("Request failed after retries")


def _handle_error_response(resp: httpx.Response) -> None:
    if resp.status_code == 401:
        raise FluxLoopAPIError(
            "Authentication required. Run 'fluxloop auth login'.",
            status_code=401,
        )
    elif resp.status_code == 403:
        raise FluxLoopAPIError(
            "Permission denied. Check your project access permissions.",
            status_code=403,
        )


def _is_retryable_status(status_code: int) -> bool:
    return 500 <= status_code <= 599
