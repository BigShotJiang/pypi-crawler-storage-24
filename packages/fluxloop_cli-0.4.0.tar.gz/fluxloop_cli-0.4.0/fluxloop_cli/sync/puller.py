"""SyncPuller — pull bundle data from server to local pulled/ directory."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import httpx

from ..constants import (
    PULLED_CRITERIA_FILENAME,
    PULLED_DIR_NAME,
    PULLED_INPUTS_FILENAME,
    PULLED_PERSONAS_FILENAME,
    SYNC_META_FILENAME,
)
from .client import post_with_retry
from .meta import read_bundle_version_id


class SyncPuller:
    def __init__(self, client: httpx.Client) -> None:
        self._client = client

    def pull(
        self,
        scenario_dir: Path,
        *,
        bundle_version_id: str | None = None,
        project_id: str | None = None,
        include_inputs: bool = True,
        include_personas: bool = True,
        include_criteria: bool = True,
        cli_version: str | None = None,
    ) -> dict[str, Any]:
        """Pull bundle data from server and write to scenario_dir/pulled/."""
        payload: dict[str, Any] = {
            "include_inputs": include_inputs,
            "include_personas": include_personas,
            "include_criteria": include_criteria,
        }
        if bundle_version_id:
            payload["bundle_version_id"] = bundle_version_id
        if project_id:
            payload["project_id"] = project_id
        if cli_version:
            payload["client_meta"] = {"cli_version": cli_version}

        resp = post_with_retry(
            self._client,
            "/api/sync/pull",
            payload=payload,
        )
        data = resp.json()

        pulled_dir = scenario_dir / PULLED_DIR_NAME
        pulled_dir.mkdir(parents=True, exist_ok=True)

        # Write input items
        if data.get("input_items"):
            (pulled_dir / PULLED_INPUTS_FILENAME).write_text(
                json.dumps(data["input_items"], indent=2, ensure_ascii=False)
            )

        # Write personas
        if data.get("personas"):
            (pulled_dir / PULLED_PERSONAS_FILENAME).write_text(
                json.dumps(data["personas"], indent=2, ensure_ascii=False)
            )

        # Write criteria
        if data.get("criteria_pack"):
            (pulled_dir / PULLED_CRITERIA_FILENAME).write_text(
                json.dumps(data["criteria_pack"], indent=2, ensure_ascii=False)
            )

        # Write sync metadata
        sync_meta = {
            "bundle_version": data.get("bundle_version", {}),
            "run_spec_snapshot": data.get("run_spec_snapshot", {}),
            "scenario_context": data.get("scenario_context"),
            "input_set": data.get("input_set"),
            "sync_meta": data.get("sync_meta", {}),
        }
        (pulled_dir / SYNC_META_FILENAME).write_text(
            json.dumps(sync_meta, indent=2, ensure_ascii=False)
        )

        return data

    @staticmethod
    def get_bundle_version_id(scenario_dir: Path) -> str | None:
        """Read bundle_version_id from previously pulled sync_meta.json."""
        return read_bundle_version_id(scenario_dir)
