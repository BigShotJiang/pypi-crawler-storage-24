"""Helpers for reading pulled sync metadata."""

from __future__ import annotations

import json
from pathlib import Path

from ..constants import PULLED_DIR_NAME, SYNC_META_FILENAME


def read_bundle_version_id(scenario_dir: Path) -> str | None:
    meta_path = scenario_dir / PULLED_DIR_NAME / SYNC_META_FILENAME
    if not meta_path.exists():
        return None
    try:
        meta = json.loads(meta_path.read_text())
        return meta.get("bundle_version", {}).get("id")
    except (json.JSONDecodeError, KeyError):
        return None
