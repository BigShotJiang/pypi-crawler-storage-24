"""Backend helpers for data upload/bind/ground-truth commands."""

from __future__ import annotations

import hashlib
import mimetypes
from pathlib import Path
from typing import Any

import httpx


def normalize_usage(usage: str) -> str:
    lowered = usage.strip().lower()
    if lowered not in {"knowledge", "ground-truth"}:
        raise ValueError("usage must be one of: knowledge, ground-truth")
    return lowered


def normalize_role(role: str) -> str:
    lowered = role.strip().lower()
    if lowered not in {"knowledge", "ground-truth"}:
        raise ValueError("role must be one of: knowledge, ground-truth")
    return lowered


def normalize_split(split: str | None) -> str | None:
    if split is None:
        return None
    lowered = split.strip().lower()
    if lowered == "eval":
        return "dev"
    if lowered not in {"train", "dev", "test"}:
        raise ValueError("split must be one of: train, eval, test")
    return lowered


def infer_file_type(path: Path) -> str:
    extension = path.suffix.lower()
    if extension in {".csv", ".json", ".jsonl", ".xlsx", ".xls"}:
        return "structured"
    return "document"


def infer_mime_type(path: Path) -> str:
    guessed, _ = mimetypes.guess_type(path.name)
    if guessed:
        return guessed
    return "application/octet-stream"


def content_hash_for_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def upload_to_signed_url(
    *,
    upload_url: str,
    file_path: Path,
    headers: dict[str, str] | None = None,
) -> None:
    response = httpx.put(
        upload_url,
        content=file_path.read_bytes(),
        headers=headers or {},
        timeout=60.0,
    )
    response.raise_for_status()


def create_project_data(
    client: httpx.Client,
    *,
    project_id: str,
    file_path: Path,
    usage: str,
    name: str | None = None,
) -> dict[str, Any]:
    normalized_usage = normalize_usage(usage)
    response = client.post(
        f"/api/projects/{project_id}/data",
        json={
            "file_type": infer_file_type(file_path),
            "filename": name or file_path.name,
            "mime_type": infer_mime_type(file_path),
            "file_size": file_path.stat().st_size,
            "content_type": infer_mime_type(file_path),
            "data_category": "DATASET" if normalized_usage == "ground-truth" else "KNOWLEDGE",
        },
    )
    response.raise_for_status()
    return response.json()


def confirm_project_data(
    client: httpx.Client,
    *,
    project_id: str,
    data_id: str,
    file_path: Path,
) -> dict[str, Any]:
    response = client.post(
        f"/api/projects/{project_id}/data/{data_id}/confirm",
        json={
            "file_size": file_path.stat().st_size,
            "mime_type": infer_mime_type(file_path),
            "content_hash": content_hash_for_file(file_path),
        },
    )
    response.raise_for_status()
    return response.json()


def bind_scenario_data(
    client: httpx.Client,
    *,
    scenario_id: str,
    data_id: str,
    role: str,
    label_column: str | None = None,
    split: str | None = None,
) -> dict[str, Any]:
    normalized_role = normalize_role(role)
    binding_meta: dict[str, Any] = {
        "role": "validation" if normalized_role == "ground-truth" else "context"
    }
    normalized_split = normalize_split(split)
    if normalized_role == "ground-truth":
        if label_column:
            binding_meta["label_column"] = label_column
        if normalized_split:
            binding_meta["split"] = normalized_split

    response = client.post(
        f"/api/scenarios/{scenario_id}/data/bind",
        json={
            "data_id": data_id,
            "binding_meta": binding_meta,
        },
    )
    response.raise_for_status()
    return response.json()


def materialize_ground_truth(
    client: httpx.Client,
    *,
    scenario_id: str,
    data_id: str,
    label_column: str | None = None,
    split: str | None = None,
) -> httpx.Response:
    payload: dict[str, Any] = {
        "data_id": data_id,
    }
    normalized_split = normalize_split(split)
    if normalized_split:
        payload["split"] = normalized_split
    if label_column:
        payload["label_column"] = label_column
    return client.post(
        f"/api/scenarios/{scenario_id}/ground-truth/materialize",
        json=payload,
    )


def get_ground_truth_status(
    client: httpx.Client,
    *,
    scenario_id: str,
    data_id: str | None = None,
) -> dict[str, Any]:
    params: dict[str, str] | None = None
    if data_id:
        params = {"data_id": data_id}
    response = client.get(
        f"/api/scenarios/{scenario_id}/ground-truth/status",
        params=params,
    )
    response.raise_for_status()
    return response.json()
