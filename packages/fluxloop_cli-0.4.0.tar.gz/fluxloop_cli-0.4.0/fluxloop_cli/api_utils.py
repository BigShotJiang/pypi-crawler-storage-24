"""Common API utilities for FluxLoop CLI commands."""

from __future__ import annotations

import os
from typing import Optional

import httpx
import typer
from rich.console import Console

from .constants import PRODUCTION_API_URL, STAGING_API_URL

console = Console()


def _read_project_json_api_url() -> Optional[str]:
    try:
        from .workspace.context import load_project_connection

        conn = load_project_connection()
        if conn and conn.api_url:
            return conn.api_url
    except Exception:
        pass
    return None


def resolve_api_url(
    override: str | None = None,
    *,
    staging: bool = False,
) -> str:
    """Resolve API URL.

    Priority:
    1. override parameter (--api-url)
    2. FLUXLOOP_API_URL environment variable
    3. --staging flag → staging URL
    4. .fluxloop/project.json api_url
    5. Production URL (fallback)
    """
    url = (
        override
        or os.getenv("FLUXLOOP_API_URL")
        or (STAGING_API_URL if staging else None)
        or _read_project_json_api_url()
        or PRODUCTION_API_URL
    )
    return url.rstrip("/")


def handle_api_error(resp: httpx.Response, context: str) -> None:
    if resp.status_code == 401:
        console.print(
            "[red]✗[/red] Authentication required. Run [bold]fluxloop auth login[/bold].",
            style="bold red",
        )
        raise typer.Exit(1)
    elif resp.status_code == 403:
        console.print("[red]✗[/red] Permission denied.", style="bold red")
        raise typer.Exit(1)
    elif resp.status_code == 404:
        console.print(f"[red]✗[/red] Not found: {context}", style="bold red")
        raise typer.Exit(1)
    elif resp.status_code == 422:
        try:
            error_data = resp.json()
            detail = error_data.get("detail", resp.text)
            if isinstance(detail, list):
                console.print("[red]✗[/red] Invalid request:", style="bold red")
                for err in detail:
                    field = " -> ".join(str(loc) for loc in err.get("loc", []))
                    console.print(f"  - {field}: {err.get('msg', '')}")
            else:
                console.print(f"[red]✗[/red] Invalid request: {detail}", style="bold red")
        except Exception:
            console.print("[red]✗[/red] Invalid request", style="bold red")
        raise typer.Exit(1)
    elif resp.status_code >= 500:
        console.print("[red]✗[/red] Server error. Please try again later.", style="bold red")
        raise typer.Exit(1)
    elif not resp.is_success:
        console.print(f"[red]✗[/red] Request failed: {resp.status_code}", style="bold red")
        raise typer.Exit(1)
