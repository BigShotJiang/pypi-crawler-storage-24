"""YAML config loader with multi-file merge and env substitution."""

from __future__ import annotations

import os
import re
from collections.abc import Sequence
from pathlib import Path
from typing import Any

from pydantic import ValidationError
from ruamel.yaml import YAML

from ..constants import (
    CONFIG_DIRECTORY_NAME,
    CONFIG_SECTION_ORDER,
    CONFIG_SECTION_FILENAMES,
    PULLED_DIR_NAME,
    PULLED_INPUTS_FILENAME,
)
from .schema import InputItem, SimulationConfig

yaml = YAML()
yaml.preserve_quotes = True

_ENV_PATTERN = re.compile(r"\$\{([^}]+)\}")


def load_config(
    scenario_dir: Path,
    *,
    prefer_pulled: bool = False,
) -> SimulationConfig:
    """Load config from scenario_dir/configs/ by merging YAML files."""
    config_dir = scenario_dir / CONFIG_DIRECTORY_NAME

    if not config_dir.is_dir():
        raise FileNotFoundError(f"Config directory not found: {config_dir}")

    merged: dict[str, Any] = {}

    for section_key in CONFIG_SECTION_ORDER:
        filename = CONFIG_SECTION_FILENAMES[section_key]
        section_path = config_dir / filename
        if not section_path.exists():
            continue
        section_data = load_yaml(section_path)
        if section_data:
            deep_merge(merged, section_data)

    if not merged:
        raise ValueError(f"No configuration data found in {config_dir}")

    _substitute_env_vars(merged)

    config = _validate_simulation_config(merged)

    # Auto-detect pulled data
    pulled_dir = scenario_dir / PULLED_DIR_NAME
    if pulled_dir.is_dir() and (prefer_pulled or config.input.source != "inline"):
        pulled_items = _load_pulled_inputs(pulled_dir)
        if pulled_items:
            config.input.source = "pulled"
            config.input.pulled_path = str(pulled_dir)
            config.input.items = pulled_items

    return config


def revalidate_config(
    config: SimulationConfig,
    **updates: Any,
) -> SimulationConfig:
    payload = config.model_dump(mode="python")
    payload.update(updates)
    return _validate_simulation_config(payload)


def load_yaml(path: Path) -> dict[str, Any] | None:
    text = path.read_text()
    data = yaml.load(text)
    if data is None:
        return None
    if not isinstance(data, dict):
        raise ValueError(f"Expected mapping in {path}, got {type(data).__name__}")
    return dict(data)


def _validate_simulation_config(payload: Any) -> SimulationConfig:
    try:
        return SimulationConfig.model_validate(payload)
    except ValidationError as e:
        raise ValueError(f"Config validation failed:\n{e}") from e


def load_env_chain(scenario_dir: Path) -> None:
    """Load .env files with priority: workspace < scenario."""
    try:
        from dotenv import load_dotenv
    except ImportError:
        return

    from ..workspace.context import resolve_fluxloop_dir

    fluxloop_dir = resolve_fluxloop_dir()
    workspace_env = fluxloop_dir / ".env"
    scenario_env = scenario_dir / ".env"

    if workspace_env.exists():
        load_dotenv(workspace_env, override=False)
    if scenario_env.exists():
        load_dotenv(scenario_env, override=True)


def deep_merge(base: dict, override: dict) -> dict:
    """Recursively merge override into base. Override wins."""
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(base.get(key), dict):
            deep_merge(base[key], value)
        else:
            base[key] = value
    return base


def _load_pulled_inputs(pulled_dir: Path) -> list[InputItem]:
    """Load input items from pulled/inputs.json."""
    import json

    inputs_path = pulled_dir / PULLED_INPUTS_FILENAME
    if not inputs_path.exists():
        return []

    raw = json.loads(inputs_path.read_text())
    items: list[InputItem] = []
    for entry in raw:
        text = _extract_input_text(entry)
        if not text:
            continue
        metadata = {k: v for k, v in entry.items() if k not in ("text", "content")}
        items.append(InputItem(text=text, metadata=metadata))
    return items


def _extract_input_text(entry: dict[str, Any]) -> str:
    direct = entry.get("text") or entry.get("content")
    if isinstance(direct, str) and direct.strip():
        return direct

    messages = entry.get("messages")
    if not isinstance(messages, Sequence) or isinstance(messages, (str, bytes)):
        return ""

    user_parts: list[str] = []
    fallback_parts: list[str] = []
    for message in messages:
        if not isinstance(message, dict):
            continue
        content = message.get("content")
        content_text = _coerce_message_content(content)
        if not content_text:
            continue
        role = message.get("role")
        if role == "user":
            user_parts.append(content_text)
        else:
            fallback_parts.append(content_text)

    if user_parts:
        return "\n".join(user_parts)
    if fallback_parts:
        return "\n".join(fallback_parts)
    return ""


def _coerce_message_content(content: Any) -> str:
    if isinstance(content, str):
        return content.strip()
    if isinstance(content, Sequence) and not isinstance(content, (str, bytes)):
        parts: list[str] = []
        for item in content:
            if isinstance(item, str):
                if item.strip():
                    parts.append(item.strip())
                continue
            if not isinstance(item, dict):
                continue
            if item.get("type") == "text":
                text = item.get("text")
                if isinstance(text, str) and text.strip():
                    parts.append(text.strip())
        return "\n".join(parts)
    return ""


def _substitute_env_vars(data: Any) -> Any:
    """Replace ${VAR_NAME} patterns with environment variable values."""
    if isinstance(data, str):
        return _ENV_PATTERN.sub(lambda m: os.environ.get(m.group(1), m.group(0)), data)
    elif isinstance(data, dict):
        for key, value in data.items():
            data[key] = _substitute_env_vars(value)
    elif isinstance(data, list):
        for i, item in enumerate(data):
            data[i] = _substitute_env_vars(item)
    return data
