"""Pydantic models for simulation configuration."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field, model_validator


DEFAULT_CONVERSATION_SYSTEM_PROMPT = (
    "You are simulating an end user talking to the agent.\n"
    "Decide whether to continue and, if so, produce the next user message.\n"
)


class SandboxConfig(BaseModel):
    copy_files: list[str] = Field(default_factory=list)
    cleanup: bool = True


class BudgetConfig(BaseModel):
    max_budget_usd: float = 0.50


class ConversationSimulatorConfig(BaseModel):
    provider: Literal["anthropic", "openai"] = "anthropic"
    model: str = "claude-sonnet-4-5-20250929"
    system_prompt: str = DEFAULT_CONVERSATION_SYSTEM_PROMPT
    temperature: float = Field(default=0.2, ge=0, le=2)


class ConversationConfig(BaseModel):
    enabled: bool = False
    max_turns: int = Field(default=3, ge=1)
    simulator: ConversationSimulatorConfig = Field(
        default_factory=ConversationSimulatorConfig
    )


class ConversationMessage(BaseModel):
    role: Literal["user", "assistant", "system"]
    content: str


class RunnerConfig(BaseModel):
    type: Literal["function", "skill", "process"] = "function"

    # --- function ---
    target: str | None = None  # "module:function"
    timeout_seconds: int = 300

    # --- skill ---
    skill_path: str | None = None
    harness: Literal["claude", "codex", "openclaw"] = "claude"
    allowed_tools: list[str] = Field(default_factory=list)
    disallowed_tools: list[str] = Field(default_factory=list)
    skill_max_turns: int = 20
    sandbox: SandboxConfig = Field(default_factory=SandboxConfig)
    budget: BudgetConfig = Field(default_factory=BudgetConfig)

    # --- process ---
    command: list[str] | None = None
    protocol: Literal["ndjson"] = "ndjson"

    # --- common ---
    environment_vars: dict[str, str] = Field(default_factory=dict)
    working_directory: str = "."


class InputItem(BaseModel):
    text: str
    metadata: dict[str, Any] = Field(default_factory=dict)


class InputConfig(BaseModel):
    source: Literal["inline", "generated", "bundle", "pulled"] = "inline"
    items: list[InputItem] = Field(default_factory=list)
    pulled_path: str | None = None


class SimulationConfig(BaseModel):
    name: str = "experiment"
    runner: RunnerConfig = Field(default_factory=RunnerConfig)
    iterations: int = Field(default=1, ge=1)
    conversation: ConversationConfig = Field(default_factory=ConversationConfig)
    input: InputConfig = Field(default_factory=InputConfig)

    @model_validator(mode="after")
    def validate_conversation(self) -> SimulationConfig:
        if self.conversation.enabled and self.conversation.max_turns < 2:
            raise ValueError("conversation.max_turns must be >= 2 when enabled")
        if self.conversation.enabled and self.runner.type == "skill":
            raise ValueError("conversation.enabled=true is not supported for skill runner")
        return self
