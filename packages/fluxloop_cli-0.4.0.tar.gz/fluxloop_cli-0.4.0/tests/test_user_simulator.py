from __future__ import annotations

import pytest

from fluxloop_cli.config.schema import ConversationSimulatorConfig
from fluxloop_cli.core.user_simulator import UserSimulator


@pytest.mark.asyncio
async def test_user_simulator_parses_continue_response(monkeypatch):
    simulator = UserSimulator(ConversationSimulatorConfig())

    async def _fake_complete(prompt: str) -> str:
        assert "Conversation history" in prompt
        return (
            '{"should_continue": true, '
            '"next_message": "Can you clarify the refund timeline?", '
            '"termination_reason": null}'
        )

    monkeypatch.setattr(simulator, "_complete", _fake_complete)
    result = await simulator.next_message(
        [
            {"role": "user", "content": "I want a refund"},
            {"role": "assistant", "content": "I can help with that"},
        ]
    )

    assert result.should_continue is True
    assert result.next_message == "Can you clarify the refund timeline?"
    assert result.termination_reason is None


@pytest.mark.asyncio
async def test_user_simulator_parses_stop_response(monkeypatch):
    simulator = UserSimulator(ConversationSimulatorConfig())

    async def _fake_complete(prompt: str) -> str:
        return (
            '{"should_continue": false, '
            '"next_message": null, '
            '"termination_reason": "goal_completed"}'
        )

    monkeypatch.setattr(simulator, "_complete", _fake_complete)
    result = await simulator.next_message(
        [{"role": "user", "content": "thanks"}]
    )

    assert result.should_continue is False
    assert result.next_message is None
    assert result.termination_reason == "goal_completed"


def test_user_simulator_validate_configuration(monkeypatch):
    simulator = UserSimulator(
        ConversationSimulatorConfig(provider="anthropic")
    )
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)

    with pytest.raises(ValueError, match="ANTHROPIC_API_KEY"):
        simulator.validate_configuration()


@pytest.mark.asyncio
async def test_user_simulator_rejects_invalid_json(monkeypatch):
    simulator = UserSimulator(ConversationSimulatorConfig())

    async def _fake_complete(prompt: str) -> str:
        return "not-json"

    monkeypatch.setattr(simulator, "_complete", _fake_complete)

    with pytest.raises(ValueError, match="valid JSON"):
        await simulator.next_message([])
