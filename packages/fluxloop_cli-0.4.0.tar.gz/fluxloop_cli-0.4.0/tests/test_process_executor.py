"""Tests for ProcessExecutor."""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

from fluxloop_cli.config.schema import RunnerConfig
from fluxloop_cli.core.executor import RunContext
from fluxloop_cli.core.process_executor import ProcessExecutor


def _write_script(path: Path, content: str) -> None:
    path.write_text(content)


@pytest.mark.asyncio
async def test_process_executor_success(tmp_path: Path):
    script = tmp_path / "agent.py"
    _write_script(
        script,
        """
import json
import sys

line = sys.stdin.readline()
request = json.loads(line)
print(json.dumps({
    "run_id": request["run_id"],
    "success": True,
    "output": f"Echo: {request['input_text']}",
    "token_usage": {"input_tokens": 1, "output_tokens": 2, "total_tokens": 3}
}))
""".strip(),
    )

    executor = ProcessExecutor(
        RunnerConfig(
            type="process",
            command=[sys.executable, str(script)],
            timeout_seconds=5,
            protocol="ndjson",
        )
    )

    result = await executor.execute(
        input_text="hello",
        context=RunContext(iteration=1, scenario="demo"),
        run_id="run-1",
    )

    assert result.success is True
    assert result.output == "Echo: hello"
    assert result.token_usage is not None
    assert result.token_usage.total_tokens == 3
    assert result.metadata["protocol"] == "ndjson"


@pytest.mark.asyncio
async def test_process_executor_handles_missing_ndjson(tmp_path: Path):
    script = tmp_path / "agent.py"
    _write_script(
        script,
        """
print("plain log line")
""".strip(),
    )

    executor = ProcessExecutor(
        RunnerConfig(
            type="process",
            command=[sys.executable, str(script)],
            timeout_seconds=5,
        )
    )

    result = await executor.execute(
        input_text="hello",
        context=RunContext(),
        run_id="run-2",
    )

    assert result.success is False
    assert result.error is not None
    assert "No NDJSON response" in result.error.message


@pytest.mark.asyncio
async def test_process_executor_timeout(tmp_path: Path):
    script = tmp_path / "agent.py"
    _write_script(
        script,
        """
import time
time.sleep(2)
""".strip(),
    )

    executor = ProcessExecutor(
        RunnerConfig(
            type="process",
            command=[sys.executable, str(script)],
            timeout_seconds=1,
        )
    )

    result = await executor.execute(
        input_text="hello",
        context=RunContext(),
        run_id="run-3",
    )

    assert result.success is False
    assert result.error is not None
    assert "Timed out after 1s" in result.error.message
