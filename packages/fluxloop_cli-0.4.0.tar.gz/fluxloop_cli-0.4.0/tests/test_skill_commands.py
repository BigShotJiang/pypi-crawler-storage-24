"""Command-level tests for `fluxloop skill ...` workflows."""

from __future__ import annotations

import json
import shutil
import tempfile
from pathlib import Path

from typer.testing import CliRunner

from fluxloop_cli.commands import skill as skill_commands
from fluxloop_cli.core.executor import RunResult
from fluxloop_cli.main import app
from fluxloop_cli.workspace.context import set_current_scenario

runner = CliRunner()


class FakeExecutor:
    def __init__(self, result: RunResult, *, cleanup_path: Path | None = None) -> None:
        self._result = result
        self._cleanup_path = cleanup_path
        self.cleanup_calls = 0
        self.execute_calls: list[dict] = []

    async def execute(self, *, input_text: str, context, run_id: str) -> RunResult:
        self.execute_calls.append(
            {"input_text": input_text, "context": context, "run_id": run_id}
        )
        return self._result.model_copy(deep=True, update={"run_id": run_id})

    async def cleanup(self) -> None:
        self.cleanup_calls += 1
        if self._cleanup_path and self._cleanup_path.exists():
            shutil.rmtree(self._cleanup_path)


def _create_workspace(tmp_path: Path) -> Path:
    (tmp_path / ".fluxloop").mkdir()
    return tmp_path


def _write_skill_scenario(
    workspace: Path,
    *,
    name: str = "skill-scenario",
    simulation_yaml: str,
    static_contract: str | None = None,
    behavior_contract: str | None = None,
) -> Path:
    scenario_dir = workspace / ".fluxloop" / "scenarios" / name
    config_dir = scenario_dir / "configs"
    config_dir.mkdir(parents=True)
    (config_dir / "simulation.yaml").write_text(simulation_yaml)

    contracts_dir = scenario_dir / "contracts"
    if static_contract or behavior_contract:
        contracts_dir.mkdir(parents=True)
    if static_contract:
        (contracts_dir / "skill-static.yaml").write_text(static_contract)
    if behavior_contract:
        (contracts_dir / "skill-behavior.yaml").write_text(behavior_contract)

    return scenario_dir


def _read_single_result_dir(workspace: Path, prefix: str) -> Path:
    result_dirs = sorted((workspace / ".fluxloop" / "results").glob(f"{prefix}-*"))
    assert len(result_dirs) == 1
    return result_dirs[0]


class TestSkillValidateCommand:
    def test_uses_current_scenario_static_contract(self, tmp_path: Path, monkeypatch):
        workspace = _create_workspace(tmp_path)
        skill_path = workspace / "SKILL.md"
        skill_path.write_text("# Skill\n\nBody\n\n## Instructions\n\nDo the thing.\n")
        (workspace / "README.md").write_text("docs")

        _write_skill_scenario(
            workspace,
            simulation_yaml=(
                "name: skill-scenario\n"
                "runner:\n"
                "  type: skill\n"
                "  skill_path: ./SKILL.md\n"
            ),
            static_contract=(
                "rules:\n"
                "  - type: file_exists\n"
                "    params:\n"
                "      path: README.md\n"
                "    severity: error\n"
            ),
        )
        set_current_scenario("skill-scenario", base_dir=workspace)
        monkeypatch.chdir(workspace)

        result = runner.invoke(app, ["skill", "validate", str(skill_path)])

        assert result.exit_code == 0
        assert "Static validation passed" in result.stdout
        assert "file_exists" in result.stdout

    def test_uses_explicit_scenario_static_contract(self, tmp_path: Path, monkeypatch):
        workspace = _create_workspace(tmp_path)
        skill_path = workspace / "SKILL.md"
        skill_path.write_text("# Skill\n\nBody\n\n## Instructions\n\nDo the thing.\n")
        (workspace / "README.md").write_text("docs")

        _write_skill_scenario(
            workspace,
            simulation_yaml=(
                "name: skill-scenario\n"
                "runner:\n"
                "  type: skill\n"
                "  skill_path: ./SKILL.md\n"
            ),
            static_contract=(
                "rules:\n"
                "  - type: file_exists\n"
                "    params:\n"
                "      path: README.md\n"
                "    severity: error\n"
            ),
        )
        monkeypatch.chdir(workspace)

        result = runner.invoke(
            app,
            [
                "skill",
                "validate",
                str(skill_path),
                "--scenario",
                "skill-scenario",
            ],
        )

        assert result.exit_code == 0
        assert "Static validation passed" in result.stdout
        assert "file_exists" in result.stdout


class TestSkillTestCommand:
    def test_loads_scenario_config_and_applies_cli_override(
        self,
        tmp_path: Path,
        monkeypatch,
    ):
        workspace = _create_workspace(tmp_path)
        skill_path = workspace / "SKILL.md"
        skill_path.write_text("# Skill\n\n## Instructions\n\nDo the thing.\n")
        (workspace / "README.md").write_text("docs")

        _write_skill_scenario(
            workspace,
            simulation_yaml=(
                "name: scenario-skill\n"
                "runner:\n"
                "  type: skill\n"
                "  skill_path: ./SHOULD-NOT-BE-USED.md\n"
                "  allowed_tools: [Read]\n"
                "  skill_max_turns: 9\n"
                "  sandbox:\n"
                "    copy_files: [README.md]\n"
                "    cleanup: true\n"
                "  budget:\n"
                "    max_budget_usd: 1.25\n"
            ),
        )
        monkeypatch.chdir(workspace)

        captured: dict[str, object] = {}
        fake_executor = FakeExecutor(
            RunResult(
                run_id="seed",
                success=True,
                output="done",
                duration_ms=100,
                metadata={
                    "skill_metadata": {
                        "skill_path": str(skill_path),
                        "harness": "claude",
                        "sandbox_path": str(workspace / "sandbox"),
                        "turn_count": 2,
                        "total_cost_usd": 0.10,
                        "files_created": [],
                        "commands_executed": [],
                    }
                },
            )
        )

        def fake_create_executor(config):
            captured["config"] = config
            return fake_executor

        monkeypatch.setattr(skill_commands, "create_executor", fake_create_executor)

        result = runner.invoke(
            app,
            [
                "skill",
                "test",
                str(skill_path),
                "--scenario",
                "skill-scenario",
                "--input",
                "write docs",
                "--max-turns",
                "5",
            ],
        )

        assert result.exit_code == 0
        config = captured["config"]
        assert config.skill_path == str(skill_path)
        assert config.allowed_tools == ["Read"]
        assert config.sandbox.copy_files == ["README.md"]
        assert config.skill_max_turns == 5
        assert config.budget.max_budget_usd == 1.25

    def test_writes_summary_and_evaluates_file_contract_before_cleanup(
        self,
        tmp_path: Path,
        monkeypatch,
    ):
        workspace = _create_workspace(tmp_path)
        skill_path = workspace / "SKILL.md"
        skill_path.write_text("# Skill\n\n## Instructions\n\nDo the thing.\n")

        _write_skill_scenario(
            workspace,
            simulation_yaml=(
                "name: scenario-skill\n"
                "runner:\n"
                "  type: skill\n"
                "  skill_path: ./SKILL.md\n"
                "  sandbox:\n"
                "    cleanup: true\n"
            ),
            behavior_contract=(
                "assertions:\n"
                "  - type: file_exists\n"
                "    params:\n"
                "      path: README.md\n"
                "    severity: error\n"
            ),
        )
        monkeypatch.chdir(workspace)

        sandbox_dir = Path(tempfile.mkdtemp(prefix="skill-command-sandbox-"))
        (sandbox_dir / "README.md").write_text("generated")

        fake_executor = FakeExecutor(
            RunResult(
                run_id="seed",
                success=True,
                output="done",
                duration_ms=250,
                metadata={
                    "skill_metadata": {
                        "skill_path": str(skill_path),
                        "harness": "claude",
                        "sandbox_path": str(sandbox_dir),
                        "turn_count": 1,
                        "total_cost_usd": 0.05,
                        "files_created": ["README.md"],
                        "commands_executed": [],
                    }
                },
            ),
            cleanup_path=sandbox_dir,
        )
        monkeypatch.setattr(skill_commands, "create_executor", lambda config: fake_executor)

        result = runner.invoke(
            app,
            [
                "skill",
                "test",
                str(skill_path),
                "--scenario",
                "skill-scenario",
                "--input",
                "write docs",
            ],
        )

        assert result.exit_code == 0
        assert fake_executor.cleanup_calls == 1
        assert not sandbox_dir.exists()

        result_dir = _read_single_result_dir(workspace, "skill-test")
        assert (result_dir / "summary.json").exists()
        assert (result_dir / "trace_summary.jsonl").exists()
        assert (result_dir / "errors.json").exists()

        trace_record = json.loads((result_dir / "trace_summary.jsonl").read_text().strip())
        assert trace_record["contract_results"]["overall_pass"] is True


class TestSkillBenchmarkCommand:
    def test_rejects_invalid_run_override(self, tmp_path: Path, monkeypatch):
        workspace = _create_workspace(tmp_path)
        skill_path = workspace / "SKILL.md"
        skill_path.write_text("# Skill\n\n## Instructions\n\nDo the thing.\n")

        _write_skill_scenario(
            workspace,
            simulation_yaml=(
                "name: benchmark-skill\n"
                "runner:\n"
                "  type: skill\n"
                "  skill_path: ./SKILL.md\n"
            ),
        )
        monkeypatch.chdir(workspace)
        monkeypatch.setattr(
            skill_commands,
            "create_executor",
            lambda config: (_ for _ in ()).throw(AssertionError("should not execute")),
        )

        result = runner.invoke(
            app,
            [
                "skill",
                "benchmark",
                str(skill_path),
                "--scenario",
                "skill-scenario",
                "--input",
                "write docs",
                "--runs",
                "0",
            ],
        )

        assert result.exit_code == 1
        assert "Config error" in result.stdout

    def test_exits_nonzero_on_contract_error(self, tmp_path: Path, monkeypatch):
        workspace = _create_workspace(tmp_path)
        skill_path = workspace / "SKILL.md"
        skill_path.write_text("# Skill\n\n## Instructions\n\nDo the thing.\n")

        _write_skill_scenario(
            workspace,
            simulation_yaml=(
                "name: benchmark-skill\n"
                "runner:\n"
                "  type: skill\n"
                "  skill_path: ./SKILL.md\n"
            ),
            behavior_contract=(
                "assertions:\n"
                "  - type: file_exists\n"
                "    params:\n"
                "      path: README.md\n"
                "    severity: error\n"
            ),
        )
        monkeypatch.chdir(workspace)

        executors: list[FakeExecutor] = []

        def fake_create_executor(config):
            sandbox_dir = Path(tempfile.mkdtemp(prefix="skill-benchmark-sandbox-"))
            executor = FakeExecutor(
                RunResult(
                    run_id="seed",
                    success=True,
                    output="done",
                    duration_ms=150,
                    metadata={
                        "skill_metadata": {
                            "skill_path": str(skill_path),
                            "harness": "claude",
                            "sandbox_path": str(sandbox_dir),
                            "turn_count": 2,
                            "total_cost_usd": 0.04,
                            "files_created": [],
                            "commands_executed": [],
                        }
                    },
                ),
                cleanup_path=sandbox_dir,
            )
            executors.append(executor)
            return executor

        monkeypatch.setattr(skill_commands, "create_executor", fake_create_executor)

        result = runner.invoke(
            app,
            [
                "skill",
                "benchmark",
                str(skill_path),
                "--scenario",
                "skill-scenario",
                "--input",
                "write docs",
                "--runs",
                "2",
            ],
        )

        assert result.exit_code == 1
        assert all(executor.cleanup_calls == 1 for executor in executors)

        result_dir = _read_single_result_dir(workspace, "benchmark")
        summary = json.loads((result_dir / "summary.json").read_text())
        assert summary["contract_summary"]["overall_pass_rate"] == 0.0

    def test_warning_only_contract_failure_keeps_zero_exit(
        self,
        tmp_path: Path,
        monkeypatch,
    ):
        workspace = _create_workspace(tmp_path)
        skill_path = workspace / "SKILL.md"
        skill_path.write_text("# Skill\n\n## Instructions\n\nDo the thing.\n")

        _write_skill_scenario(
            workspace,
            simulation_yaml=(
                "name: benchmark-skill\n"
                "runner:\n"
                "  type: skill\n"
                "  skill_path: ./SKILL.md\n"
            ),
            behavior_contract=(
                "assertions:\n"
                "  - type: turn_count\n"
                "    params:\n"
                "      max: 1\n"
                "    severity: warning\n"
            ),
        )
        monkeypatch.chdir(workspace)

        monkeypatch.setattr(
            skill_commands,
            "create_executor",
            lambda config: FakeExecutor(
                RunResult(
                    run_id="seed",
                    success=True,
                    output="done",
                    duration_ms=150,
                    metadata={
                        "skill_metadata": {
                            "skill_path": str(skill_path),
                            "harness": "claude",
                            "sandbox_path": str(Path(tempfile.mkdtemp())),
                            "turn_count": 2,
                            "total_cost_usd": 0.04,
                            "files_created": [],
                            "commands_executed": [],
                        }
                    },
                )
            ),
        )

        result = runner.invoke(
            app,
            [
                "skill",
                "benchmark",
                str(skill_path),
                "--scenario",
                "skill-scenario",
                "--input",
                "write docs",
                "--runs",
                "1",
            ],
        )

        assert result.exit_code == 0
