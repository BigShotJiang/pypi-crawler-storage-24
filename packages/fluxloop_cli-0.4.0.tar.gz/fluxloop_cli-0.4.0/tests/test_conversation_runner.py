from __future__ import annotations

import pytest

from fluxloop_cli.core.conversation_runner import execute_conversation
from fluxloop_cli.core.executor import RunContext, RunError, RunResult, TokenUsage
from fluxloop_cli.core.user_simulator import SimulatorResult


class FakeExecutor:
    def __init__(self, results: list[RunResult]) -> None:
        self._results = list(results)
        self.inputs: list[str] = []

    async def execute(self, *, input_text: str, context, run_id: str) -> RunResult:
        self.inputs.append(input_text)
        result = self._results.pop(0)
        return result.model_copy(deep=True, update={"run_id": run_id})

    async def cleanup(self) -> None:
        pass


class FakeSimulator:
    def __init__(self, results: list[SimulatorResult]) -> None:
        self._results = list(results)
        self.conversations: list[list[dict[str, str]]] = []

    async def next_message(self, conversation):
        self.conversations.append([message.model_dump() for message in conversation])
        return self._results.pop(0)


@pytest.mark.asyncio
async def test_execute_conversation_accumulates_turns():
    executor = FakeExecutor(
        [
            RunResult(
                run_id="seed-1",
                success=True,
                output="Hello, how can I help?",
                duration_ms=100,
                token_usage=TokenUsage(input_tokens=10, output_tokens=5, total_tokens=15),
            ),
            RunResult(
                run_id="seed-2",
                success=True,
                output="Your refund should arrive tomorrow.",
                duration_ms=120,
                token_usage=TokenUsage(input_tokens=8, output_tokens=6, total_tokens=14),
            ),
        ]
    )
    simulator = FakeSimulator(
        [
            SimulatorResult(
                should_continue=True,
                next_message="When will it arrive?",
                termination_reason=None,
            ),
            SimulatorResult(
                should_continue=False,
                next_message=None,
                termination_reason="goal_completed",
            ),
        ]
    )

    result = await execute_conversation(
        executor=executor,
        simulator=simulator,
        initial_input="I need a refund",
        context=RunContext(iteration=0, scenario="demo"),
        run_id="run-1",
        max_turns=3,
    )

    assert result.success is True
    assert result.turn_count == 2
    assert result.termination_reason == "goal_completed"
    assert result.duration_ms == 220
    assert result.token_usage.total_tokens == 29
    assert executor.inputs == ["I need a refund", "When will it arrive?"]
    assert [message.role for message in result.conversation] == [
        "user",
        "assistant",
        "user",
        "assistant",
    ]


@pytest.mark.asyncio
async def test_execute_conversation_marks_execution_failure():
    executor = FakeExecutor(
        [
            RunResult(
                run_id="seed-1",
                success=True,
                output="Tell me more.",
                duration_ms=50,
            ),
            RunResult(
                run_id="seed-2",
                success=False,
                output="",
                duration_ms=75,
                error=RunError(message="Timeout"),
            ),
        ]
    )
    simulator = FakeSimulator(
        [
            SimulatorResult(
                should_continue=True,
                next_message="Here are more details.",
                termination_reason=None,
            )
        ]
    )

    result = await execute_conversation(
        executor=executor,
        simulator=simulator,
        initial_input="Help me",
        context=RunContext(iteration=0),
        run_id="run-2",
        max_turns=3,
    )

    assert result.success is False
    assert result.turn_count == 2
    assert result.termination_reason == "execution_failed"
    assert result.error is not None
    assert result.error.message == "Timeout"
