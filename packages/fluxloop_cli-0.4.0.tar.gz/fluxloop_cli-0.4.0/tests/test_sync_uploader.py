"""Tests for sync upload payload conversion."""

from __future__ import annotations

import json
from pathlib import Path

import jsonschema

from fluxloop_cli.sync.uploader import SyncUploader


class TestSyncUploader:
    def test_build_payload_preserves_input_lineage(self, load_schema):
        schema = load_schema("sync-payload.schema.json")
        uploader = SyncUploader(client=object())
        traces = [
            {
                "run_id": "run-1",
                "persona": "persona-1",
                "input": "hello",
                "success": True,
                "tool_calls": [],
                "input_item_id": "input-1",
                "input_metadata": {
                    "id": "input-1",
                    "persona_id": "persona-1",
                    "scenario_id": "scenario-1",
                    "input_set_id": "set-1",
                    "messages": [{"role": "user", "content": "hello"}],
                    "metadata": {"tag": "smoke"},
                },
            }
        ]

        payload = uploader._build_upload_payload("bundle-1", traces)
        assert payload["runs"][0]["input_item_id"] == "input-1"
        assert payload["runs"][0]["input_snapshot"]["messages"][0]["content"] == "hello"
        jsonschema.validate(payload, schema)

    def test_build_payload_falls_back_to_metadata_id(self):
        uploader = SyncUploader(client=object())
        traces = [
            {
                "run_id": "run-2",
                "input": "fallback input",
                "success": False,
                "tool_calls": [],
                "input_metadata": {
                    "id": "input-2",
                    "persona_id": "persona-2",
                    "metadata": {"source": "pulled"},
                },
            }
        ]

        payload = uploader._build_upload_payload("bundle-2", traces)
        assert payload["runs"][0]["input_item_id"] == "input-2"
        assert payload["runs"][0]["input_snapshot"]["messages"][0]["content"] == "fallback input"

    def test_upload_from_result_dir_reads_sync_meta(self, tmp_path: Path, monkeypatch):
        scenario_dir = tmp_path / "scenario"
        result_dir = tmp_path / "results"
        pulled_dir = scenario_dir / "pulled"
        pulled_dir.mkdir(parents=True)
        result_dir.mkdir()

        (pulled_dir / "sync_meta.json").write_text(
            json.dumps({"bundle_version": {"id": "bundle-3"}})
        )
        (result_dir / "trace_summary.jsonl").write_text(
            json.dumps(
                {
                    "run_id": "run-3",
                    "input": "hi",
                    "success": True,
                    "tool_calls": [],
                    "input_item_id": "input-3",
                    "input_metadata": {"id": "input-3"},
                }
            )
            + "\n"
        )

        captured = {}

        class _FakeResponse:
            def json(self):
                return {"status": "ok", "run_batch_id": "batch-1", "run_ids": ["run-3"]}

        def _fake_post(client, endpoint, payload):
            captured["endpoint"] = endpoint
            captured["payload"] = payload
            return _FakeResponse()

        monkeypatch.setattr("fluxloop_cli.sync.uploader.post_with_retry", _fake_post)

        uploader = SyncUploader(client=object())
        data = uploader.upload_from_result_dir(result_dir, scenario_dir)

        assert data["run_batch_id"] == "batch-1"
        assert captured["endpoint"] == "/api/sync/upload"
        assert captured["payload"]["bundle_version_id"] == "bundle-3"

    def test_build_payload_maps_conversation_to_turns_and_metrics(self, load_schema):
        schema = load_schema("sync-payload.schema.json")
        uploader = SyncUploader(client=object())
        traces = [
            {
                "run_id": "run-conv",
                "input": "hello",
                "output": "hi",
                "success": True,
                "duration_ms": 150,
                "turn_count": 2,
                "termination_reason": "goal_completed",
                "timestamp": "2026-03-09T00:00:00+00:00",
                "input_item_id": "input-9",
                "conversation": [
                    {"role": "user", "content": "hello"},
                    {"role": "assistant", "content": "hi"},
                    {"role": "user", "content": "thanks"},
                    {"role": "assistant", "content": "you're welcome"},
                ],
            }
        ]

        payload = uploader._build_upload_payload("bundle-9", traces)
        assert len(payload["turns"]) == 4
        assert payload["turns"][2]["content"] == "thanks"
        assert payload["run_results"][0]["transcript"][3]["role"] == "assistant"
        assert payload["run_results"][0]["metrics"]["turn_count"] == 2
        assert (
            payload["run_results"][0]["metrics"]["termination_reason"]
            == "goal_completed"
        )
        jsonschema.validate(payload, schema)
