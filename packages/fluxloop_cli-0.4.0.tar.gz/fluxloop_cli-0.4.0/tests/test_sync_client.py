"""Tests for sync client auth and environment loading."""

from __future__ import annotations

from pathlib import Path

import httpx
import pytest

from fluxloop_cli.sync.client import create_client, get_with_retry, post_with_retry


class TestCreateClient:
    def test_loads_sync_api_key_from_workspace_env(self, tmp_workspace: Path, monkeypatch):
        env_path = tmp_workspace / ".fluxloop" / ".env"
        env_path.write_text("FLUXLOOP_SYNC_API_KEY=file-key\n")
        monkeypatch.chdir(tmp_workspace)
        monkeypatch.delenv("FLUXLOOP_SYNC_API_KEY", raising=False)
        monkeypatch.delenv("FLUXLOOP_API_KEY", raising=False)

        client = create_client("https://api.example.com", use_jwt=False)
        try:
            assert client.headers["Authorization"] == "Bearer file-key"
        finally:
            client.close()

    def test_process_env_overrides_workspace_env(self, tmp_workspace: Path, monkeypatch):
        env_path = tmp_workspace / ".fluxloop" / ".env"
        env_path.write_text("FLUXLOOP_SYNC_API_KEY=file-key\n")
        monkeypatch.chdir(tmp_workspace)
        monkeypatch.setenv("FLUXLOOP_SYNC_API_KEY", "env-key")

        client = create_client("https://api.example.com", use_jwt=False)
        try:
            assert client.headers["Authorization"] == "Bearer env-key"
        finally:
            client.close()


class TestRetryPolicy:
    def test_post_does_not_retry_404(self):
        calls = 0

        def handler(request: httpx.Request) -> httpx.Response:
            nonlocal calls
            calls += 1
            return httpx.Response(404, json={"detail": "not found"}, request=request)

        client = httpx.Client(
            transport=httpx.MockTransport(handler),
            base_url="https://api.example.com",
        )
        try:
            with pytest.raises(httpx.HTTPStatusError):
                post_with_retry(client, "/api/items", payload={"name": "x"})
        finally:
            client.close()

        assert calls == 1

    def test_post_retries_500_then_succeeds(self):
        calls = 0

        def handler(request: httpx.Request) -> httpx.Response:
            nonlocal calls
            calls += 1
            if calls < 3:
                return httpx.Response(500, json={"detail": "server error"}, request=request)
            return httpx.Response(200, json={"ok": True}, request=request)

        client = httpx.Client(
            transport=httpx.MockTransport(handler),
            base_url="https://api.example.com",
        )
        try:
            resp = post_with_retry(
                client,
                "/api/items",
                payload={"name": "x"},
                max_retries=3,
                backoff_seconds=0,
            )
        finally:
            client.close()

        assert resp.status_code == 200
        assert calls == 3

    def test_get_retries_500_then_succeeds(self):
        calls = 0

        def handler(request: httpx.Request) -> httpx.Response:
            nonlocal calls
            calls += 1
            if calls < 3:
                return httpx.Response(500, json={"detail": "server error"}, request=request)
            return httpx.Response(200, json={"ok": True}, request=request)

        client = httpx.Client(
            transport=httpx.MockTransport(handler),
            base_url="https://api.example.com",
        )
        try:
            resp = get_with_retry(client, "/api/items", max_retries=3, backoff_seconds=0)
        finally:
            client.close()

        assert resp.status_code == 200
        assert calls == 3
