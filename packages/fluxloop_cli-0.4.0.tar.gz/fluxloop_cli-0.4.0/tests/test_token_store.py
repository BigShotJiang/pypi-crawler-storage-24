"""Tests for JWT token storage and management."""

from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from unittest.mock import patch

import pytest

from fluxloop_cli.auth.token_store import (
    AuthToken,
    delete_token,
    format_expires_at,
    is_token_expired,
    load_token,
    save_token,
)


def _make_token(expires_delta: timedelta | None = None) -> AuthToken:
    expires_at = datetime.now(timezone.utc) + (expires_delta or timedelta(hours=1))
    return AuthToken(
        access_token="access-123",
        refresh_token="refresh-456",
        expires_at=expires_at.isoformat(),
        user_id="user-789",
        user_email="test@example.com",
    )


class TestAuthToken:
    def test_from_dict(self):
        data = {
            "access_token": "a",
            "refresh_token": "r",
            "expires_at": "2026-01-01T00:00:00+00:00",
            "user_id": "u",
            "user_email": "e@e.com",
        }
        token = AuthToken.from_dict(data)
        assert token.access_token == "a"
        assert token.user_email == "e@e.com"

    def test_to_dict(self):
        token = _make_token()
        d = token.to_dict()
        assert "access_token" in d
        assert "refresh_token" in d
        assert "user_id" in d

    def test_roundtrip(self):
        original = _make_token()
        restored = AuthToken.from_dict(original.to_dict())
        assert restored.access_token == original.access_token
        assert restored.user_id == original.user_id


class TestTokenStorage:
    def test_save_and_load(self, tmp_path):
        auth_dir = tmp_path / ".fluxloop"
        auth_file = auth_dir / "auth.json"

        with (
            patch("fluxloop_cli.auth.token_store.AUTH_DIR", auth_dir),
            patch("fluxloop_cli.auth.token_store.AUTH_FILE", auth_file),
        ):
            token = _make_token()
            save_token(token)

            assert auth_file.exists()
            assert (auth_file.stat().st_mode & 0o777) == 0o600

            loaded = load_token()
            assert loaded is not None
            assert loaded.access_token == token.access_token

    def test_load_missing(self, tmp_path):
        auth_file = tmp_path / "nonexistent.json"
        with patch("fluxloop_cli.auth.token_store.AUTH_FILE", auth_file):
            assert load_token() is None

    def test_load_corrupt(self, tmp_path):
        auth_file = tmp_path / "bad.json"
        auth_file.write_text("not json")
        with patch("fluxloop_cli.auth.token_store.AUTH_FILE", auth_file):
            assert load_token() is None

    def test_delete(self, tmp_path):
        auth_file = tmp_path / "auth.json"
        auth_file.write_text("{}")
        with patch("fluxloop_cli.auth.token_store.AUTH_FILE", auth_file):
            delete_token()
            assert not auth_file.exists()

    def test_delete_missing(self, tmp_path):
        auth_file = tmp_path / "nonexistent.json"
        with patch("fluxloop_cli.auth.token_store.AUTH_FILE", auth_file):
            delete_token()  # should not raise


class TestTokenExpiry:
    def test_not_expired(self):
        token = _make_token(timedelta(hours=1))
        assert not is_token_expired(token)

    def test_expired(self):
        token = _make_token(timedelta(minutes=-1))
        assert is_token_expired(token)

    def test_within_buffer(self):
        token = _make_token(timedelta(minutes=3))
        assert is_token_expired(token, buffer_minutes=5)

    def test_invalid_format(self):
        token = AuthToken(
            access_token="a", refresh_token="r",
            expires_at="invalid", user_id="u",
        )
        assert is_token_expired(token)


class TestFormatExpiresAt:
    def test_hours_remaining(self):
        expires = datetime.now(timezone.utc) + timedelta(hours=2, minutes=30)
        result = format_expires_at(expires.isoformat())
        assert "2h" in result
        assert "remaining" in result

    def test_minutes_remaining(self):
        expires = datetime.now(timezone.utc) + timedelta(minutes=15)
        result = format_expires_at(expires.isoformat())
        assert "m remaining" in result

    def test_expired(self):
        expires = datetime.now(timezone.utc) - timedelta(minutes=5)
        assert format_expires_at(expires.isoformat()) == "expired"

    def test_invalid(self):
        assert format_expires_at("garbage") == "unknown"
