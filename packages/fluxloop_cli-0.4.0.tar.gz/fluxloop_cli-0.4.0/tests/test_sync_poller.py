"""Tests for sync polling helper."""

from __future__ import annotations

import pytest

from fluxloop_cli.sync.poller import poll_job


class _FakeResponse:
    def __init__(self, payload):
        self._payload = payload

    def json(self):
        return self._payload


class TestPollJob:
    def test_polls_dict_until_terminal_status(self, monkeypatch):
        responses = iter(
            [
                {"status": "running"},
                {"status": "completed", "id": "job-1"},
            ]
        )
        monkeypatch.setattr(
            "fluxloop_cli.sync.poller.get_with_retry",
            lambda client, endpoint, params=None: _FakeResponse(next(responses)),
        )
        monkeypatch.setattr("fluxloop_cli.sync.poller.time.sleep", lambda _: None)

        data = poll_job(object(), "/api/jobs", interval=0.01, timeout=0.1)
        assert data["status"] == "completed"

    def test_polls_list_with_status_selector(self, monkeypatch):
        responses = iter(
            [
                [{"id": "job-1", "status": "queued"}],
                [{"id": "job-1", "status": "completed"}],
            ]
        )
        monkeypatch.setattr(
            "fluxloop_cli.sync.poller.get_with_retry",
            lambda client, endpoint, params=None: _FakeResponse(next(responses)),
        )
        monkeypatch.setattr("fluxloop_cli.sync.poller.time.sleep", lambda _: None)

        data = poll_job(
            object(),
            "/api/jobs",
            params={"project_id": "proj-1"},
            interval=0.01,
            timeout=0.1,
            select_status=lambda payload: payload[0]["status"],
        )
        assert data[0]["status"] == "completed"

    def test_timeout_raises_with_last_status(self, monkeypatch):
        monkeypatch.setattr(
            "fluxloop_cli.sync.poller.get_with_retry",
            lambda client, endpoint, params=None: _FakeResponse({"status": "running"}),
        )
        monkeypatch.setattr("fluxloop_cli.sync.poller.time.sleep", lambda _: None)

        with pytest.raises(TimeoutError, match="last status: running"):
            poll_job(object(), "/api/jobs", interval=0.01, timeout=0.02)
