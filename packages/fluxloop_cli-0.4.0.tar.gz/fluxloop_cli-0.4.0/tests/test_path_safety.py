"""Tests for path safety helpers and API key persistence."""

from __future__ import annotations

import stat
from pathlib import Path

from fluxloop_cli.commands import apikeys
from fluxloop_cli.constants import FILE_PERMISSION
from fluxloop_cli.path_safety import resolve_path_within_root, sanitize_result_name


def test_sanitize_result_name_strips_path_control_characters():
    assert sanitize_result_name("../../evil run name") == "evil-run-name"


def test_resolve_path_within_root_rejects_traversal(tmp_path: Path):
    sandbox_root = tmp_path / "sandbox"
    sandbox_root.mkdir()

    assert resolve_path_within_root(sandbox_root, "../secret.txt") is None


def test_save_key_to_env_restricts_permissions(tmp_workspace: Path, monkeypatch):
    fluxloop_dir = tmp_workspace / ".fluxloop"
    monkeypatch.setattr(apikeys, "resolve_fluxloop_dir", lambda: fluxloop_dir)

    apikeys._save_key_to_env("secret-key")

    env_path = fluxloop_dir / ".env"
    assert env_path.read_text() == "FLUXLOOP_SYNC_API_KEY=secret-key\n"
    assert stat.S_IMODE(env_path.stat().st_mode) == FILE_PERMISSION
