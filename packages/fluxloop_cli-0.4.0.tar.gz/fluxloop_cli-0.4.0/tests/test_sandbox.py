"""Tests for sandbox creation, file copying, and cleanup."""

from __future__ import annotations

import os
from pathlib import Path

import pytest

from fluxloop_cli.workspace.sandbox import Sandbox, SandboxManager


class TestSandbox:
    def test_install_skill(self, tmp_path: Path):
        skill = tmp_path / "SKILL.md"
        skill.write_text("# My Skill\n\nSome content")

        workspace = tmp_path / "workspace"
        workspace.mkdir()
        sandbox = Sandbox(workspace_path=workspace)

        installed = sandbox.install_skill(skill)

        assert installed.exists()
        assert installed.name == "SKILL.md"
        assert ".claude/skills" in str(installed)
        assert installed.read_text() == "# My Skill\n\nSome content"
        assert sandbox.skill_installed is True

    def test_cleanup(self):
        import tempfile

        temp = tempfile.TemporaryDirectory(prefix="fluxloop-test-")
        workspace = Path(temp.name)
        sandbox = Sandbox(workspace_path=workspace, _temp_dir=temp)

        assert workspace.exists()
        sandbox.cleanup()
        assert not workspace.exists()
        assert sandbox._temp_dir is None

    def test_cleanup_idempotent(self, tmp_path: Path):
        sandbox = Sandbox(workspace_path=tmp_path)
        # No _temp_dir — cleanup should be a no-op
        sandbox.cleanup()
        sandbox.cleanup()


class TestSandboxManager:
    def test_create_empty_sandbox(self):
        manager = SandboxManager()
        sandbox = manager.create_sandbox()

        assert sandbox.workspace_path.exists()
        assert sandbox.workspace_path.is_dir()
        assert sandbox.skill_installed is False
        sandbox.cleanup()

    def test_copy_single_file(self, tmp_path: Path):
        src = tmp_path / "source"
        src.mkdir()
        (src / "data.txt").write_text("hello")

        manager = SandboxManager()
        sandbox = manager.create_sandbox(
            copy_files=["data.txt"], source_dir=src,
        )

        copied = sandbox.workspace_path / "data.txt"
        assert copied.exists()
        assert copied.read_text() == "hello"
        sandbox.cleanup()

    def test_copy_directory(self, tmp_path: Path):
        src = tmp_path / "source"
        sub = src / "subdir"
        sub.mkdir(parents=True)
        (sub / "a.txt").write_text("a")
        (sub / "b.txt").write_text("b")

        manager = SandboxManager()
        sandbox = manager.create_sandbox(
            copy_files=["subdir"], source_dir=src,
        )

        assert (sandbox.workspace_path / "subdir" / "a.txt").read_text() == "a"
        assert (sandbox.workspace_path / "subdir" / "b.txt").read_text() == "b"
        sandbox.cleanup()

    def test_copy_glob_pattern(self, tmp_path: Path):
        src = tmp_path / "source"
        src.mkdir()
        (src / "foo.py").write_text("# foo")
        (src / "bar.py").write_text("# bar")
        (src / "readme.md").write_text("# readme")

        manager = SandboxManager()
        sandbox = manager.create_sandbox(
            copy_files=["*.py"], source_dir=src,
        )

        assert (sandbox.workspace_path / "foo.py").exists()
        assert (sandbox.workspace_path / "bar.py").exists()
        assert not (sandbox.workspace_path / "readme.md").exists()
        sandbox.cleanup()

    def test_copy_nonexistent_pattern(self, tmp_path: Path):
        src = tmp_path / "source"
        src.mkdir()

        manager = SandboxManager()
        sandbox = manager.create_sandbox(
            copy_files=["*.xyz"], source_dir=src,
        )
        # Should not fail — just copy nothing
        assert sandbox.workspace_path.exists()
        sandbox.cleanup()

    def test_no_copy_files(self, tmp_path: Path):
        manager = SandboxManager()
        sandbox = manager.create_sandbox(source_dir=tmp_path)

        assert sandbox.workspace_path.exists()
        sandbox.cleanup()

    def test_preserves_internal_relative_symlink(self, tmp_path: Path):
        src = tmp_path / "source"
        src.mkdir()
        (src / "target.txt").write_text("hello")
        (src / "link.txt").symlink_to("target.txt")

        manager = SandboxManager()
        sandbox = manager.create_sandbox(
            copy_files=["target.txt", "link.txt"],
            source_dir=src,
        )

        copied_link = sandbox.workspace_path / "link.txt"
        assert copied_link.is_symlink()
        assert copied_link.read_text() == "hello"
        sandbox.cleanup()

    def test_rewrites_internal_absolute_symlink_to_sandbox(self, tmp_path: Path):
        src = tmp_path / "source"
        src.mkdir()
        target = src / "target.txt"
        target.write_text("hello")
        (src / "link.txt").symlink_to(target)

        manager = SandboxManager()
        sandbox = manager.create_sandbox(
            copy_files=["target.txt", "link.txt"],
            source_dir=src,
        )

        copied_link = sandbox.workspace_path / "link.txt"
        assert copied_link.is_symlink()
        assert copied_link.read_text() == "hello"
        assert copied_link.resolve().is_relative_to(sandbox.workspace_path.resolve())
        sandbox.cleanup()

    def test_rejects_symlink_escaping_source_root(self, tmp_path: Path):
        src = tmp_path / "source"
        src.mkdir()
        outside = tmp_path / "outside.txt"
        outside.write_text("secret")
        os.symlink(outside, src / "link.txt")

        manager = SandboxManager()
        with pytest.raises(ValueError, match="outside source root"):
            manager.create_sandbox(copy_files=["link.txt"], source_dir=src)
