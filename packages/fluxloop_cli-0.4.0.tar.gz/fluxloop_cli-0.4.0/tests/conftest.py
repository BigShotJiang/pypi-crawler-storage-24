"""Shared fixtures for FluxLoop CLI tests."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

SCHEMAS_DIR = Path(__file__).resolve().parent.parent.parent / "protocol" / "schemas"


@pytest.fixture
def tmp_workspace(tmp_path: Path) -> Path:
    """Create a minimal .fluxloop workspace structure."""
    fluxloop_dir = tmp_path / ".fluxloop"
    fluxloop_dir.mkdir()
    return tmp_path


@pytest.fixture
def tmp_scenario(tmp_workspace: Path) -> Path:
    """Create a scenario with a minimal simulation.yaml."""
    scenario_dir = tmp_workspace / ".fluxloop" / "scenarios" / "test-scenario"
    config_dir = scenario_dir / "configs"
    config_dir.mkdir(parents=True)

    yaml_content = """\
name: test-experiment
runner:
  type: function
  target: "my_agent:handler"
  timeout_seconds: 30
iterations: 2
input:
  source: inline
  items:
    - text: "hello"
    - text: "world"
"""
    (config_dir / "simulation.yaml").write_text(yaml_content)
    return scenario_dir


@pytest.fixture
def load_schema():
    """Factory fixture to load a protocol JSON schema by name."""

    def _load(name: str) -> dict:
        path = SCHEMAS_DIR / name
        return json.loads(path.read_text())

    return _load
