"""Command-level tests for Phase 6 backend command surfaces."""

from __future__ import annotations

import json
from pathlib import Path

from typer.testing import CliRunner

from fluxloop_cli.commands import data, inputs, intent
from fluxloop_cli.main import app
from fluxloop_cli.workspace.context import (
    load_context,
    set_bundle_version_id,
    set_current_scenario_id,
    set_input_set_id,
)

runner = CliRunner()


class _FakeMaterializeResponse:
    status_code = 200
    is_success = True
    text = ""

    def __init__(self, payload):
        self._payload = payload

    def json(self):
        return self._payload


class TestDataCommands:
    def test_push_binds_and_materializes_ground_truth(
        self,
        tmp_workspace: Path,
        monkeypatch,
    ):
        monkeypatch.chdir(tmp_workspace)
        source = tmp_workspace / "dataset.csv"
        source.write_text("question,label\nhi,ok\n")

        monkeypatch.setattr(data, "get_current_web_project_id", lambda: "proj-1")
        monkeypatch.setattr(data, "create_client", lambda *args, **kwargs: object())
        monkeypatch.setattr(
            data,
            "_resolve_scenario",
            lambda *args, **kwargs: ("sc-1", "demo", {"id": "sc-1"}),
        )

        captured: dict[str, object] = {}

        monkeypatch.setattr(
            data.data_api,
            "create_project_data",
            lambda client, **kwargs: {
                "data": {"id": "data-1"},
                "upload": {
                    "upload_url": "https://upload.test",
                    "headers": {"x-test": "1"},
                },
            },
        )
        monkeypatch.setattr(
            data.data_api,
            "upload_to_signed_url",
            lambda **kwargs: captured.setdefault("upload", kwargs),
        )
        monkeypatch.setattr(
            data.data_api,
            "confirm_project_data",
            lambda client, **kwargs: {"processing_status": "completed"},
        )
        monkeypatch.setattr(
            data.data_api,
            "bind_scenario_data",
            lambda client, **kwargs: {
                "binding": {"id": "binding-1"},
                "captured": captured.setdefault("bind", kwargs),
            },
        )
        monkeypatch.setattr(
            data.data_api,
            "materialize_ground_truth",
            lambda client, **kwargs: _FakeMaterializeResponse(
                {"profile": {"id": "gt-1"}}
            ),
        )

        result = runner.invoke(
            app,
            [
                "data",
                "push",
                str(source),
                "--usage",
                "ground-truth",
                "--bind",
                "--split",
                "eval",
                "--label-column",
                "label",
            ],
        )

        assert result.exit_code == 0
        assert captured["upload"] == {
            "upload_url": "https://upload.test",
            "file_path": source.resolve(),
            "headers": {"x-test": "1"},
        }
        assert captured["bind"] == {
            "scenario_id": "sc-1",
            "data_id": "data-1",
            "role": "ground-truth",
            "label_column": "label",
            "split": "eval",
        }
        assert "Materialization" in result.stdout


class TestIntentCommands:
    def test_refine_persists_local_artifacts(
        self,
        tmp_workspace: Path,
        monkeypatch,
    ):
        monkeypatch.chdir(tmp_workspace)
        monkeypatch.setattr(intent, "get_current_web_project_id", lambda: "proj-1")
        monkeypatch.setattr(intent, "create_client", lambda *args, **kwargs: object())
        monkeypatch.setattr(
            intent,
            "_resolve_scenario_payload",
            lambda *args, **kwargs: (
                "sc-1",
                {
                    "id": "sc-1",
                    "name": "demo",
                    "config_snapshot": {"goal": "Help customers"},
                },
            ),
        )
        monkeypatch.setattr(
            intent,
            "refine_intent_api",
            lambda *args, **kwargs: {
                "intent": "Help customers quickly",
                "constraints": ["be concise"],
                "applied": True,
            },
        )

        result = runner.invoke(app, ["intent", "refine", "--apply"])

        assert result.exit_code == 0
        refinement_path = (
            tmp_workspace
            / ".fluxloop"
            / "scenarios"
            / "demo"
            / "intent_refinement.json"
        )
        scenario_json_path = (
            tmp_workspace
            / ".fluxloop"
            / "scenarios"
            / "demo"
            / "scenario.json"
        )
        assert refinement_path.exists()
        assert scenario_json_path.exists()
        assert json.loads(refinement_path.read_text())["intent"] == "Help customers quickly"
        assert json.loads(scenario_json_path.read_text())["intent_refinement"]["applied"] is True


class TestInputsCommands:
    def test_refine_uses_saved_input_set_and_updates_context(
        self,
        tmp_workspace: Path,
        monkeypatch,
    ):
        monkeypatch.chdir(tmp_workspace)
        monkeypatch.setattr(inputs, "get_current_web_project_id", lambda: "proj-1")
        monkeypatch.setattr(inputs, "create_client", lambda *args, **kwargs: object())
        set_current_scenario_id("sc-1", tmp_workspace)
        set_input_set_id("set-1", tmp_workspace)
        set_bundle_version_id("bundle-1", tmp_workspace)

        captured: dict[str, object] = {}

        def _fake_refine_inputs_api(*args, **kwargs):
            captured["request"] = kwargs
            return {
                "input_set": {"id": "set-2"},
                "bundle_version_id": "bundle-2",
                "items": [{"id": "item-1"}],
                "version": 2,
                "change_log": ["tightened prompts"],
            }

        monkeypatch.setattr(
            inputs,
            "refine_inputs_api",
            _fake_refine_inputs_api,
        )

        result = runner.invoke(app, ["inputs", "refine", "--output", "json"])

        assert result.exit_code == 0
        assert captured["request"] == {
            "project_id": "proj-1",
            "scenario_id": "sc-1",
            "input_set_id": "set-1",
            "bundle_version_id": "bundle-1",
            "dry_run": False,
        }
        ctx = load_context(tmp_workspace)
        assert ctx is not None
        assert ctx.current_input_set_id == "set-2"
        assert ctx.current_dataset_version_id == "set-2"
        assert ctx.current_bundle_version_id == "bundle-2"
        assert '"version": 2' in result.stdout
