"""Tests for safe regex execution."""

from __future__ import annotations

from fluxloop_cli.contract.safe_regex import safe_regex_search


def test_safe_regex_search_matches_simple_pattern():
    result = safe_regex_search(r"hello\s+world", "hello   world")
    assert result.matched
    assert result.error is None


def test_safe_regex_search_reports_invalid_pattern():
    result = safe_regex_search("(", "hello world")
    assert not result.matched
    assert result.error is not None
    assert "Invalid regex" in result.error


def test_safe_regex_search_times_out_on_catastrophic_pattern():
    result = safe_regex_search("(a+)+b", "a" * 28, timeout_ms=100)
    assert not result.matched
    assert result.error is not None
    assert "timed out" in result.error
