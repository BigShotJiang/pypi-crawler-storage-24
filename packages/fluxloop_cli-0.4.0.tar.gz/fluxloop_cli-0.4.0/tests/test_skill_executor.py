"""Tests for SkillExecutor — sandbox setup, evidence collection, recursion guard."""

from __future__ import annotations

import os
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from fluxloop_cli.config.schema import BudgetConfig, RunnerConfig, SandboxConfig
from fluxloop_cli.core.executor import RunContext
from fluxloop_cli.core.skill_executor import (
    ENV_CHILD_DEPTH,
    MAX_CHILD_DEPTH,
    EvidenceCollector,
    SkillExecutor,
    ToolCall,
)


# ---------- EvidenceCollector ----------


class TestEvidenceCollector:
    def test_record_tool_use(self):
        ec = EvidenceCollector()
        ec.record_tool_use("Write", {"file_path": "/tmp/a.py", "content": "x"})

        assert len(ec.tool_calls) == 1
        assert ec.tool_calls[0].tool == "Write"
        assert ec.tool_calls[0].turn == 0

    def test_record_write_tracks_files(self):
        ec = EvidenceCollector()
        ec.record_tool_use("Write", {"file_path": "/tmp/a.py"})
        assert ec.files_created == ["/tmp/a.py"]

    def test_record_bash_tracks_commands(self):
        ec = EvidenceCollector()
        ec.record_tool_use("Bash", {"command": "ls -la"})
        assert ec.commands_executed == ["ls -la"]

    def test_record_tool_result(self):
        ec = EvidenceCollector()
        ec.record_tool_use("Read", {"file_path": "/tmp/x"})
        ec.record_tool_result("file contents here", is_error=False, duration_ms=42)

        assert ec.tool_calls[0].output == "file contents here"
        assert ec.tool_calls[0].is_error is False
        assert ec.tool_calls[0].duration_ms == 42

    def test_record_tool_result_error(self):
        ec = EvidenceCollector()
        ec.record_tool_use("Bash", {"command": "false"})
        ec.record_tool_result("command failed", is_error=True)

        assert ec.tool_calls[0].is_error is True

    def test_increment_turn(self):
        ec = EvidenceCollector()
        assert ec.turn_count == 0
        ec.increment_turn()
        assert ec.turn_count == 1

        ec.record_tool_use("Read", {})
        assert ec.tool_calls[0].turn == 1

    def test_multiple_turns(self):
        ec = EvidenceCollector()
        ec.record_tool_use("Read", {})
        ec.increment_turn()
        ec.record_tool_use("Write", {})
        ec.increment_turn()
        ec.record_tool_use("Bash", {})

        assert ec.tool_calls[0].turn == 0
        assert ec.tool_calls[1].turn == 1
        assert ec.tool_calls[2].turn == 2


# ---------- SkillExecutor unit tests ----------


class TestSkillExecutorInit:
    def test_creates_sandbox_manager(self):
        config = RunnerConfig(type="skill", skill_path="/tmp/test.md")
        executor = SkillExecutor(config)
        assert executor.sandbox_manager is not None

    def test_recursion_depth_check_passes(self):
        config = RunnerConfig(type="skill", skill_path="/tmp/test.md")
        executor = SkillExecutor(config)
        # No env var set — should not raise
        executor._check_recursion_depth()

    def test_recursion_depth_check_fails(self, monkeypatch):
        monkeypatch.setenv(ENV_CHILD_DEPTH, str(MAX_CHILD_DEPTH))
        config = RunnerConfig(type="skill", skill_path="/tmp/test.md")
        executor = SkillExecutor(config)
        with pytest.raises(RuntimeError, match="Recursion depth limit"):
            executor._check_recursion_depth()

    def test_recursion_depth_below_limit(self, monkeypatch):
        monkeypatch.setenv(ENV_CHILD_DEPTH, str(MAX_CHILD_DEPTH - 1))
        config = RunnerConfig(type="skill", skill_path="/tmp/test.md")
        executor = SkillExecutor(config)
        # Should not raise
        executor._check_recursion_depth()

    def test_unsupported_harness(self):
        config = RunnerConfig(
            type="skill",
            skill_path="/tmp/test.md",
            harness="codex",
        )
        with pytest.raises(NotImplementedError, match="Only 'claude' is supported"):
            SkillExecutor(config)


class TestResolveSkillPath:
    def test_resolve_existing(self, tmp_path: Path):
        skill = tmp_path / "SKILL.md"
        skill.write_text("# Test")

        config = RunnerConfig(type="skill", skill_path=str(skill))
        executor = SkillExecutor(config)
        resolved = executor._resolve_skill_path()
        assert resolved == skill.resolve()

    def test_resolve_missing_path(self):
        config = RunnerConfig(type="skill", skill_path="/nonexistent/SKILL.md")
        executor = SkillExecutor(config)
        with pytest.raises(FileNotFoundError):
            executor._resolve_skill_path()

    def test_resolve_no_skill_path(self):
        config = RunnerConfig(type="skill")
        executor = SkillExecutor(config)
        with pytest.raises(ValueError, match="skill_path is required"):
            executor._resolve_skill_path()


class TestListSandboxFiles:
    def test_lists_files(self, tmp_path: Path):
        from fluxloop_cli.workspace.sandbox import Sandbox

        workspace = tmp_path / "workspace"
        workspace.mkdir()
        (workspace / "a.txt").write_text("a")
        sub = workspace / "src"
        sub.mkdir()
        (sub / "b.py").write_text("b")
        # .claude dir should be excluded
        claude_dir = workspace / ".claude" / "skills"
        claude_dir.mkdir(parents=True)
        (claude_dir / "SKILL.md").write_text("skill")

        config = RunnerConfig(type="skill", skill_path="/tmp/test.md")
        executor = SkillExecutor(config)
        sandbox = Sandbox(workspace_path=workspace)

        files = executor._list_sandbox_files(sandbox)
        assert "a.txt" in files
        assert "src/b.py" in files
        # .claude files should be excluded
        assert not any(".claude" in f for f in files)


@pytest.mark.asyncio
class TestSkillExecutorExecute:
    async def test_execute_success(self, tmp_path: Path):
        """Integration test with mocked SDK query."""
        skill = tmp_path / "SKILL.md"
        skill.write_text("# Test Skill\n\nDo something")

        config = RunnerConfig(
            type="skill",
            skill_path=str(skill),
            working_directory=str(tmp_path),
            sandbox=SandboxConfig(cleanup=True),
            budget=BudgetConfig(max_budget_usd=0.50),
        )
        executor = SkillExecutor(config)

        # Mock _run_sdk_query
        from fluxloop_cli.core.executor import TokenUsage

        mock_token_usage = TokenUsage(input_tokens=100, output_tokens=50, total_tokens=150)

        async def mock_sdk_query(*, input_text, sandbox, collector, env):
            collector.record_tool_use("Write", {"file_path": "/tmp/out.py"})
            collector.record_tool_result("ok", is_error=False)
            collector.increment_turn()
            return "Task completed", mock_token_usage, 0.05

        with patch.object(executor, "_run_sdk_query", side_effect=mock_sdk_query):
            result = await executor.execute(
                input_text="do something",
                context=RunContext(),
                run_id="test-run-1",
            )

        assert result.success
        assert result.output == "Task completed"
        assert result.token_usage.total_tokens == 150
        assert len(result.tool_calls) == 1
        assert result.tool_calls[0]["tool"] == "Write"
        skill_meta = result.metadata["skill_metadata"]
        assert skill_meta["sandbox_path"]
        assert skill_meta["turn_count"] == 1
        assert skill_meta["total_cost_usd"] == 0.05
        assert skill_meta["files_created"] == ["/tmp/out.py"]

    async def test_execute_failure(self, tmp_path: Path):
        """SDK query raises an exception."""
        skill = tmp_path / "SKILL.md"
        skill.write_text("# Test Skill\n\nDo something")

        config = RunnerConfig(
            type="skill",
            skill_path=str(skill),
            working_directory=str(tmp_path),
            sandbox=SandboxConfig(cleanup=True),
        )
        executor = SkillExecutor(config)

        async def mock_sdk_query(*, input_text, sandbox, collector, env):
            raise RuntimeError("SDK connection failed")

        with patch.object(executor, "_run_sdk_query", side_effect=mock_sdk_query):
            result = await executor.execute(
                input_text="test",
                context=RunContext(),
                run_id="test-run-2",
            )

        assert not result.success
        assert result.error is not None
        assert "SDK connection failed" in result.error.message

    async def test_execute_recursion_guard(self, tmp_path: Path, monkeypatch):
        """Recursion guard blocks execution."""
        skill = tmp_path / "SKILL.md"
        skill.write_text("# Test")

        monkeypatch.setenv(ENV_CHILD_DEPTH, str(MAX_CHILD_DEPTH))

        config = RunnerConfig(
            type="skill",
            skill_path=str(skill),
            working_directory=str(tmp_path),
        )
        executor = SkillExecutor(config)

        with pytest.raises(RuntimeError, match="Recursion depth"):
            await executor.execute(
                input_text="test",
                context=RunContext(),
                run_id="test-run-3",
            )

    async def test_sandbox_cleanup_on_success(self, tmp_path: Path):
        """Sandbox is kept until cleanup() is called by the caller."""
        skill = tmp_path / "SKILL.md"
        skill.write_text("# Test Skill\n\nContent")

        config = RunnerConfig(
            type="skill",
            skill_path=str(skill),
            working_directory=str(tmp_path),
            sandbox=SandboxConfig(cleanup=True),
        )
        executor = SkillExecutor(config)

        async def mock_sdk_query(*, input_text, sandbox, collector, env):
            return "done", None, None

        with patch.object(executor, "_run_sdk_query", side_effect=mock_sdk_query):
            result = await executor.execute(
                input_text="test",
                context=RunContext(),
                run_id="test-run-4",
            )

        assert result.success
        assert executor._sandbox is not None
        await executor.cleanup()
        assert executor._sandbox is None

    async def test_sandbox_no_cleanup(self, tmp_path: Path):
        """Sandbox is kept when cleanup=False."""
        skill = tmp_path / "SKILL.md"
        skill.write_text("# Test Skill\n\nContent")

        config = RunnerConfig(
            type="skill",
            skill_path=str(skill),
            working_directory=str(tmp_path),
            sandbox=SandboxConfig(cleanup=False),
        )
        executor = SkillExecutor(config)

        async def mock_sdk_query(*, input_text, sandbox, collector, env):
            return "done", None, None

        with patch.object(executor, "_run_sdk_query", side_effect=mock_sdk_query):
            result = await executor.execute(
                input_text="test",
                context=RunContext(),
                run_id="test-run-5",
            )

        assert result.success
        assert executor._sandbox is not None
        assert result.metadata["skill_metadata"]["sandbox_path"]
        await executor.cleanup()
        assert executor._sandbox is None

    async def test_sequential_execute_keeps_previous_sandbox_until_cleanup(
        self,
        tmp_path: Path,
    ):
        skill = tmp_path / "SKILL.md"
        skill.write_text("# Test Skill\n\nContent")

        config = RunnerConfig(
            type="skill",
            skill_path=str(skill),
            working_directory=str(tmp_path),
            sandbox=SandboxConfig(cleanup=True),
        )
        executor = SkillExecutor(config)

        async def mock_sdk_query(*, input_text, sandbox, collector, env):
            return "done", None, None

        with patch.object(executor, "_run_sdk_query", side_effect=mock_sdk_query):
            first = await executor.execute(
                input_text="first",
                context=RunContext(),
                run_id="test-run-6",
            )
            second = await executor.execute(
                input_text="second",
                context=RunContext(),
                run_id="test-run-7",
            )

        first_path = Path(first.metadata["skill_metadata"]["sandbox_path"])
        second_path = Path(second.metadata["skill_metadata"]["sandbox_path"])

        assert first_path.exists()
        assert second_path.exists()
        await executor.cleanup()
        assert not first_path.exists()
        assert not second_path.exists()
