"""Tests for workspace context management."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from fluxloop_cli.workspace.context import (
    LocalContext,
    ProjectConnection,
    find_workspace_root,
    get_current_scenario_id,
    get_scenario_dir,
    load_context,
    load_project_connection,
    resolve_fluxloop_dir,
    save_context,
    save_project_connection,
    select_web_project,
    set_bundle_version_id,
    set_current_scenario_id,
    set_current_scenario,
    set_dataset_version_id,
    set_experiment_id,
    set_input_set_id,
    update_context,
)


class TestProjectConnection:
    def test_from_dict(self):
        data = {
            "project_id": "p1",
            "project_name": "My Project",
            "workspace_id": "w1",
            "api_url": "https://api.example.com",
        }
        conn = ProjectConnection.from_dict(data)
        assert conn.project_id == "p1"
        assert conn.project_name == "My Project"

    def test_to_dict(self):
        conn = ProjectConnection(project_id="p1", project_name="test")
        d = conn.to_dict()
        assert d["project_id"] == "p1"
        assert "connected_at" in d

    def test_roundtrip(self):
        original = ProjectConnection(
            project_id="p1", project_name="test",
            workspace_id="w1", api_url="https://api.test.com",
        )
        restored = ProjectConnection.from_dict(original.to_dict())
        assert restored.project_id == original.project_id
        assert restored.workspace_id == original.workspace_id


class TestLocalContext:
    def test_from_dict(self):
        ctx = LocalContext.from_dict(
            {
                "current_scenario": "my-scenario",
                "current_scenario_id": "sc-1",
                "current_dataset_version_id": "ds-1",
                "current_input_set_id": "set-1",
                "current_bundle_version_id": "bundle-1",
                "current_experiment_id": "exp-1",
            }
        )
        assert ctx.current_scenario == "my-scenario"
        assert ctx.current_scenario_id == "sc-1"
        assert ctx.current_dataset_version_id == "ds-1"
        assert ctx.current_input_set_id == "set-1"
        assert ctx.current_bundle_version_id == "bundle-1"
        assert ctx.current_experiment_id == "exp-1"

    def test_from_dict_empty(self):
        ctx = LocalContext.from_dict({})
        assert ctx.current_scenario is None
        assert ctx.current_scenario_id is None


class TestFindWorkspaceRoot:
    def test_finds_root(self, tmp_workspace):
        child = tmp_workspace / "a" / "b" / "c"
        child.mkdir(parents=True)
        root = find_workspace_root(child)
        assert root == tmp_workspace

    def test_returns_none_when_not_found(self, tmp_path):
        assert find_workspace_root(tmp_path) is None


class TestResolveFluxloopDir:
    def test_existing_workspace(self, tmp_workspace):
        fluxloop_dir = resolve_fluxloop_dir(tmp_workspace)
        assert fluxloop_dir == tmp_workspace / ".fluxloop"

    def test_creates_dir(self, tmp_path):
        target = tmp_path / "new_project"
        target.mkdir()
        fluxloop_dir = resolve_fluxloop_dir(target)
        assert fluxloop_dir.exists()
        assert fluxloop_dir.name == ".fluxloop"


class TestGetScenarioDir:
    def test_path(self, tmp_workspace):
        d = get_scenario_dir("my-test", tmp_workspace)
        assert d == tmp_workspace / ".fluxloop" / "scenarios" / "my-test"


class TestProjectConnectionStorage:
    def test_save_and_load(self, tmp_workspace):
        conn = ProjectConnection(project_id="p1", project_name="test")
        save_project_connection(conn, tmp_workspace)

        loaded = load_project_connection(tmp_workspace)
        assert loaded is not None
        assert loaded.project_id == "p1"

    def test_load_missing(self, tmp_path):
        assert load_project_connection(tmp_path) is None


class TestSelectWebProject:
    def test_creates_connection(self, tmp_workspace):
        conn = select_web_project("p1", "My Proj", base_dir=tmp_workspace)
        assert conn.project_id == "p1"
        assert conn.project_name == "My Proj"

        loaded = load_project_connection(tmp_workspace)
        assert loaded is not None
        assert loaded.project_id == "p1"


class TestContextStorage:
    def test_save_and_load(self, tmp_workspace):
        ctx = LocalContext(current_scenario="test-scenario")
        save_context(ctx, tmp_workspace)

        loaded = load_context(tmp_workspace)
        assert loaded is not None
        assert loaded.current_scenario == "test-scenario"

    def test_set_current_scenario(self, tmp_workspace):
        ctx = set_current_scenario("new-scenario", tmp_workspace)
        assert ctx.current_scenario == "new-scenario"

        loaded = load_context(tmp_workspace)
        assert loaded.current_scenario == "new-scenario"

    def test_set_current_scenario_id(self, tmp_workspace):
        ctx = set_current_scenario_id("sc-123", tmp_workspace)
        assert ctx.current_scenario_id == "sc-123"
        assert get_current_scenario_id(tmp_workspace) == "sc-123"

    def test_set_dataset_version_id(self, tmp_workspace):
        ctx = set_dataset_version_id("bv-123", tmp_workspace)
        assert ctx.current_dataset_version_id == "bv-123"

        loaded = load_context(tmp_workspace)
        assert loaded.current_dataset_version_id == "bv-123"

    def test_set_input_set_id_updates_legacy_dataset_slot(self, tmp_workspace):
        ctx = set_input_set_id("set-123", tmp_workspace)
        assert ctx.current_input_set_id == "set-123"
        assert ctx.current_dataset_version_id == "set-123"

        loaded = load_context(tmp_workspace)
        assert loaded.current_input_set_id == "set-123"
        assert loaded.current_dataset_version_id == "set-123"

    def test_set_bundle_version_id(self, tmp_workspace):
        ctx = set_bundle_version_id("bundle-123", tmp_workspace)
        assert ctx.current_bundle_version_id == "bundle-123"

        loaded = load_context(tmp_workspace)
        assert loaded.current_bundle_version_id == "bundle-123"

    def test_set_experiment_id(self, tmp_workspace):
        ctx = set_experiment_id("exp-123", tmp_workspace)
        assert ctx.current_experiment_id == "exp-123"

        loaded = load_context(tmp_workspace)
        assert loaded.current_experiment_id == "exp-123"

    def test_update_context_batches_multiple_fields(self, tmp_workspace):
        ctx = update_context(
            {
                "current_scenario": "demo",
                "current_scenario_id": "sc-123",
                "current_input_set_id": "set-123",
                "current_bundle_version_id": "bundle-123",
            },
            tmp_workspace,
        )
        assert ctx.current_scenario == "demo"
        assert ctx.current_scenario_id == "sc-123"
        assert ctx.current_input_set_id == "set-123"
        assert ctx.current_dataset_version_id == "set-123"
        assert ctx.current_bundle_version_id == "bundle-123"

        loaded = load_context(tmp_workspace)
        assert loaded is not None
        assert loaded.current_scenario == "demo"
        assert loaded.current_scenario_id == "sc-123"
        assert loaded.current_input_set_id == "set-123"
        assert loaded.current_dataset_version_id == "set-123"
        assert loaded.current_bundle_version_id == "bundle-123"

    def test_load_missing(self, tmp_path):
        assert load_context(tmp_path) is None
