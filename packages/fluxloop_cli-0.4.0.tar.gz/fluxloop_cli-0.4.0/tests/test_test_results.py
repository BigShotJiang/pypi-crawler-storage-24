"""Tests for `fluxloop test results` local/remote surfaces."""

from __future__ import annotations

import json
from pathlib import Path

from typer.testing import CliRunner

from fluxloop_cli.commands import test_cmd
from fluxloop_cli.main import app

runner = CliRunner()


class _FakeResponse:
    def __init__(self, payload, status_code: int = 200):
        self._payload = payload
        self.status_code = status_code

    def json(self):
        return self._payload

    def raise_for_status(self):
        if self.status_code >= 400:
            raise RuntimeError(f"HTTP {self.status_code}")


class _FakeClient:
    def __init__(self, responses: dict[str, object]):
        self._responses = responses

    def get(self, path: str, params=None):
        if path == "/api/experiments":
            return _FakeResponse(self._responses["experiments"])
        if path.startswith("/api/scenarios/"):
            return _FakeResponse(self._responses["scenario"])
        if path == "/api/scenarios":
            return _FakeResponse(self._responses["scenarios"])
        raise AssertionError(f"Unexpected GET {path} params={params}")

    def close(self):
        return None


class TestTestResults:
    def test_local_reads_summary_json(
        self,
        tmp_workspace: Path,
        monkeypatch,
    ):
        monkeypatch.chdir(tmp_workspace)
        result_dir = tmp_workspace / ".fluxloop" / "results" / "demo-20260308-150000"
        result_dir.mkdir(parents=True)
        (result_dir / "summary.json").write_text(
            json.dumps(
                {
                    "total_runs": 15,
                    "success_count": 15,
                    "total_duration_ms": 16500,
                    "created_at": "2026-03-08T15:00:00Z",
                }
            )
        )

        result = runner.invoke(app, ["test", "results", "--local"])

        assert result.exit_code == 0
        assert "demo-20260308-150000" in result.stdout
        assert "100.0%" in result.stdout
        assert "16.5s" in result.stdout

    def test_remote_uses_experiments_endpoint(
        self,
        tmp_workspace: Path,
        monkeypatch,
    ):
        monkeypatch.chdir(tmp_workspace)
        monkeypatch.setattr(test_cmd, "get_current_web_project_id", lambda: "proj-1")
        monkeypatch.setattr(
            test_cmd,
            "create_client",
            lambda *args, **kwargs: _FakeClient(
                {
                    "scenario": {"id": "sc-1", "name": "demo"},
                    "scenarios": [],
                    "experiments": [
                        {
                            "experiment_id": "exp-1",
                            "created_at": "2026-03-08T15:00:00Z",
                            "summary": {
                                "total_runs": 5,
                                "completed_runs": 4,
                            },
                            "evaluation": {
                                "verdict": "pass",
                            },
                        }
                    ],
                }
            ),
        )

        result = runner.invoke(app, ["test", "results", "--scenario-id", "sc-1"])

        assert result.exit_code == 0
        assert "Scenario: demo (sc-1)" in result.stdout
        assert "exp-1" in result.stdout
        assert "4/5" in result.stdout
        assert "pass" in result.stdout

    def test_remote_raw_prints_json(
        self,
        tmp_workspace: Path,
        monkeypatch,
    ):
        monkeypatch.chdir(tmp_workspace)
        monkeypatch.setattr(test_cmd, "get_current_web_project_id", lambda: "proj-1")
        monkeypatch.setattr(
            test_cmd,
            "create_client",
            lambda *args, **kwargs: _FakeClient(
                {
                    "scenario": {"id": "sc-1", "name": "demo"},
                    "scenarios": [],
                    "experiments": [{"experiment_id": "exp-1"}],
                }
            ),
        )

        result = runner.invoke(
            app,
            ["test", "results", "--scenario-id", "sc-1", "--raw"],
        )

        assert result.exit_code == 0
        assert '"experiment_id": "exp-1"' in result.stdout
