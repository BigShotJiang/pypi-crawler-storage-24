"""Tests for resolve_api_url priority chain."""

from __future__ import annotations

import os
from unittest.mock import patch

import pytest

from fluxloop_cli.api_utils import resolve_api_url
from fluxloop_cli.constants import PRODUCTION_API_URL, STAGING_API_URL


class TestResolveApiUrl:
    def test_default_production(self):
        with patch("fluxloop_cli.api_utils._read_project_json_api_url", return_value=None):
            url = resolve_api_url()
            assert url == PRODUCTION_API_URL

    def test_override_parameter(self):
        url = resolve_api_url("https://custom.api.com/")
        assert url == "https://custom.api.com"

    def test_env_variable(self, monkeypatch):
        monkeypatch.setenv("FLUXLOOP_API_URL", "https://env.api.com")
        with patch("fluxloop_cli.api_utils._read_project_json_api_url", return_value=None):
            url = resolve_api_url()
            assert url == "https://env.api.com"

    def test_staging_flag(self):
        with patch("fluxloop_cli.api_utils._read_project_json_api_url", return_value=None):
            url = resolve_api_url(staging=True)
            assert url == STAGING_API_URL

    def test_project_json(self):
        with patch(
            "fluxloop_cli.api_utils._read_project_json_api_url",
            return_value="https://project.api.com",
        ):
            url = resolve_api_url()
            assert url == "https://project.api.com"

    def test_staging_overrides_project_json(self):
        """--staging should take priority over project.json api_url."""
        with patch(
            "fluxloop_cli.api_utils._read_project_json_api_url",
            return_value="https://project.api.com",
        ):
            url = resolve_api_url(staging=True)
            assert url == STAGING_API_URL

    def test_env_overrides_staging(self, monkeypatch):
        monkeypatch.setenv("FLUXLOOP_API_URL", "https://env.api.com")
        url = resolve_api_url(staging=True)
        assert url == "https://env.api.com"

    def test_override_wins_all(self, monkeypatch):
        monkeypatch.setenv("FLUXLOOP_API_URL", "https://env.api.com")
        with patch(
            "fluxloop_cli.api_utils._read_project_json_api_url",
            return_value="https://project.api.com",
        ):
            url = resolve_api_url("https://override.api.com", staging=True)
            assert url == "https://override.api.com"

    def test_trailing_slash_stripped(self):
        url = resolve_api_url("https://api.example.com///")
        assert url == "https://api.example.com"
