"""Tests for sync pull file materialization."""

from __future__ import annotations

import json
from pathlib import Path

from fluxloop_cli.sync.puller import SyncPuller


class _FakeResponse:
    def __init__(self, payload):
        self._payload = payload

    def json(self):
        return self._payload


class TestSyncPuller:
    def test_pull_writes_pulled_files(self, tmp_path: Path, monkeypatch):
        scenario_dir = tmp_path / "scenario"
        response_payload = {
            "bundle_version": {"id": "bundle-1", "name": "bundle"},
            "run_spec_snapshot": {"runner": {"type": "function"}},
            "scenario_context": {"scenario": {"id": "sc-1", "name": "demo"}, "contracts": []},
            "input_set": {"id": "set-1"},
            "input_items": [
                {
                    "id": "input-1",
                    "persona_id": "persona-1",
                    "messages": [{"role": "user", "content": "hello"}],
                    "metadata": {"tag": "smoke"},
                }
            ],
            "personas": [{"id": "persona-1", "name": "Tester"}],
            "criteria_pack": [{"id": "criteria-1", "name": "Accuracy"}],
            "sync_meta": {"bundle_version_id": "bundle-1"},
        }

        monkeypatch.setattr(
            "fluxloop_cli.sync.puller.post_with_retry",
            lambda client, endpoint, payload: _FakeResponse(response_payload),
        )

        puller = SyncPuller(client=object())
        data = puller.pull(scenario_dir, bundle_version_id="bundle-1", project_id="proj-1")

        pulled_dir = scenario_dir / "pulled"
        assert data["bundle_version"]["id"] == "bundle-1"
        assert json.loads((pulled_dir / "inputs.json").read_text())[0]["id"] == "input-1"
        assert json.loads((pulled_dir / "personas.json").read_text())[0]["name"] == "Tester"
        assert json.loads((pulled_dir / "criteria.json").read_text())[0]["name"] == "Accuracy"
        assert SyncPuller.get_bundle_version_id(scenario_dir) == "bundle-1"
