from __future__ import annotations

from pathlib import Path

from fluxloop_cli.commands.scenario_resolution import (
    resolve_scenario_id_by_name,
    resolve_scenario_payload,
    resolve_scenario_selection,
)
from fluxloop_cli.workspace.context import update_context


class _FakeResponse:
    def __init__(self, payload):
        self._payload = payload

    def raise_for_status(self) -> None:
        return None

    def json(self):
        return self._payload


class _FakeClient:
    def __init__(self, responses: dict[str, object] | None = None):
        self.responses = responses or {}
        self.calls: list[tuple[str, object | None]] = []

    def get(self, url: str, params=None):
        self.calls.append((url, params))
        key = url
        if params is not None:
            key = f"{url}?{params!r}"
        if key not in self.responses:
            raise AssertionError(f"unexpected request: {key}")
        return _FakeResponse(self.responses[key])


def test_resolve_scenario_selection_uses_saved_context_id_without_fetching(
    tmp_workspace: Path,
    monkeypatch,
) -> None:
    monkeypatch.chdir(tmp_workspace)
    update_context(
        {
            "current_scenario": "demo",
            "current_scenario_id": "sc-1",
        },
        tmp_workspace,
    )
    client = _FakeClient()

    resolved = resolve_scenario_selection(
        client,
        project_id="proj-1",
        scenario_id=None,
        scenario_name=None,
    )

    assert resolved == ("sc-1", "demo", None)
    assert client.calls == []


def test_resolve_scenario_payload_falls_back_to_saved_context_name(
    tmp_workspace: Path,
    monkeypatch,
) -> None:
    monkeypatch.chdir(tmp_workspace)
    update_context({"current_scenario": "demo"}, tmp_workspace)
    client = _FakeClient(
        {
            "/api/scenarios?{'project_id': 'proj-1'}": [
                {"id": "sc-1", "name": "demo", "description": "Demo"},
            ]
        }
    )

    scenario_id, payload = resolve_scenario_payload(
        client,
        project_id="proj-1",
        scenario_id=None,
    )

    assert scenario_id == "sc-1"
    assert payload == {"id": "sc-1", "name": "demo", "description": "Demo"}
    assert client.calls == [
        ("/api/scenarios", {"project_id": "proj-1"}),
    ]


def test_resolve_scenario_id_by_name_prefers_saved_context_match(
    tmp_workspace: Path,
    monkeypatch,
) -> None:
    monkeypatch.chdir(tmp_workspace)
    update_context(
        {
            "current_scenario": "demo",
            "current_scenario_id": "sc-1",
        },
        tmp_workspace,
    )
    client = _FakeClient()

    resolved = resolve_scenario_id_by_name(
        client,
        project_id="proj-1",
        scenario_name="demo",
    )

    assert resolved == "sc-1"
    assert client.calls == []
