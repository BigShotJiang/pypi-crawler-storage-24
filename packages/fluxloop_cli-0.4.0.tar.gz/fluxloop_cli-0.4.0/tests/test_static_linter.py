"""Tests for SKILL.md static linter — all rule types."""

from __future__ import annotations

from pathlib import Path

from fluxloop_cli.contract.static_linter import (
    DEFAULT_STATIC_RULES,
    Severity,
    StaticLinter,
)

SAMPLE_SKILL = """\
# My Skill

A skill that does something useful for testing purposes. This description is long enough.

## Instructions

Do something step by step.

## Examples

Example 1: hello world
"""


class TestStaticLinterBasic:
    def test_file_not_found(self, tmp_path: Path):
        linter = StaticLinter()
        report = linter.lint(tmp_path / "missing.md", DEFAULT_STATIC_RULES)
        assert not report.overall_pass
        assert report.results[0].rule_type == "file_exists"

    def test_default_rules_pass(self, tmp_path: Path):
        skill = tmp_path / "SKILL.md"
        skill.write_text(SAMPLE_SKILL)

        linter = StaticLinter()
        report = linter.lint(skill, DEFAULT_STATIC_RULES)
        assert report.overall_pass
        assert report.error_count == 0

    def test_overall_pass_ignores_warnings(self, tmp_path: Path):
        skill = tmp_path / "SKILL.md"
        skill.write_text(SAMPLE_SKILL)

        rules = [
            {"type": "has_section", "params": {"section": "## Nonexistent"}, "severity": "warning"},
        ]
        linter = StaticLinter()
        report = linter.lint(skill, rules)
        # Warning failures don't block overall pass
        assert report.overall_pass
        assert report.warning_count == 1


class TestHasSectionRule:
    def test_section_exists(self, tmp_path: Path):
        skill = tmp_path / "SKILL.md"
        skill.write_text(SAMPLE_SKILL)

        linter = StaticLinter()
        rules = [{"type": "has_section", "params": {"section": "## Instructions"}, "severity": "error"}]
        report = linter.lint(skill, rules)
        assert report.results[0].passed

    def test_section_missing(self, tmp_path: Path):
        skill = tmp_path / "SKILL.md"
        skill.write_text(SAMPLE_SKILL)

        linter = StaticLinter()
        rules = [{"type": "has_section", "params": {"section": "## API Reference"}, "severity": "error"}]
        report = linter.lint(skill, rules)
        assert not report.results[0].passed

    def test_section_with_hash_prefix(self, tmp_path: Path):
        """Section param can include leading hashes."""
        skill = tmp_path / "SKILL.md"
        skill.write_text("# Title\n\n### Deep Section\n\nContent")

        linter = StaticLinter()
        rules = [{"type": "has_section", "params": {"section": "### Deep Section"}, "severity": "error"}]
        report = linter.lint(skill, rules)
        assert report.results[0].passed

    def test_h1_section(self, tmp_path: Path):
        skill = tmp_path / "SKILL.md"
        skill.write_text(SAMPLE_SKILL)

        linter = StaticLinter()
        rules = [{"type": "has_section", "params": {"section": "# My Skill"}, "severity": "error"}]
        report = linter.lint(skill, rules)
        assert report.results[0].passed


class TestFileExistsRule:
    def test_relative_file_present(self, tmp_path: Path):
        skill = tmp_path / "SKILL.md"
        skill.write_text(SAMPLE_SKILL)
        (tmp_path / "README.md").write_text("docs")

        report = StaticLinter().lint(
            skill,
            [
                {
                    "type": "file_exists",
                    "params": {"path": "README.md"},
                    "severity": "error",
                }
            ],
        )
        assert report.results[0].passed

    def test_relative_file_missing(self, tmp_path: Path):
        skill = tmp_path / "SKILL.md"
        skill.write_text(SAMPLE_SKILL)

        report = StaticLinter().lint(
            skill,
            [
                {
                    "type": "file_exists",
                    "params": {"path": "README.md"},
                    "severity": "error",
                }
            ],
        )
        assert not report.results[0].passed


class TestFileSizeRule:
    def test_within_bounds(self, tmp_path: Path):
        skill = tmp_path / "SKILL.md"
        skill.write_text("x" * 100)

        linter = StaticLinter()
        rules = [{"type": "file_size", "params": {"min_bytes": 50, "max_bytes": 200}, "severity": "error"}]
        report = linter.lint(skill, rules)
        assert report.results[0].passed

    def test_too_small(self, tmp_path: Path):
        skill = tmp_path / "SKILL.md"
        skill.write_text("hi")

        linter = StaticLinter()
        rules = [{"type": "file_size", "params": {"min_bytes": 50, "max_bytes": 200}, "severity": "error"}]
        report = linter.lint(skill, rules)
        assert not report.results[0].passed

    def test_too_large(self, tmp_path: Path):
        skill = tmp_path / "SKILL.md"
        skill.write_text("x" * 300)

        linter = StaticLinter()
        rules = [{"type": "file_size", "params": {"min_bytes": 50, "max_bytes": 200}, "severity": "error"}]
        report = linter.lint(skill, rules)
        assert not report.results[0].passed


class TestForbiddenPatternRule:
    def test_no_secrets(self, tmp_path: Path):
        skill = tmp_path / "SKILL.md"
        skill.write_text("# Safe content\n\nNo secrets here.")

        linter = StaticLinter()
        rules = [
            {"type": "forbidden_pattern", "params": {"pattern": r"(?i)api[_-]?key\s*[:=]\s*\S+"}, "severity": "error"},
        ]
        report = linter.lint(skill, rules)
        assert report.results[0].passed

    def test_secret_detected(self, tmp_path: Path):
        skill = tmp_path / "SKILL.md"
        skill.write_text("# Bad\n\napi_key = sk-12345abcde")

        linter = StaticLinter()
        rules = [
            {"type": "forbidden_pattern", "params": {"pattern": r"(?i)api[_-]?key\s*[:=]\s*\S+"}, "severity": "error"},
        ]
        report = linter.lint(skill, rules)
        assert not report.results[0].passed


class TestEncodingRule:
    def test_valid_utf8(self, tmp_path: Path):
        skill = tmp_path / "SKILL.md"
        skill.write_text("# Hello 안녕하세요", encoding="utf-8")

        linter = StaticLinter()
        rules = [{"type": "encoding", "params": {"encoding": "utf-8"}, "severity": "error"}]
        report = linter.lint(skill, rules)
        assert report.results[0].passed

    def test_invalid_encoding(self, tmp_path: Path):
        skill = tmp_path / "SKILL.md"
        skill.write_bytes(b"\x80\x81\x82\x83")

        linter = StaticLinter()
        rules = [{"type": "encoding", "params": {"encoding": "ascii"}, "severity": "error"}]
        report = linter.lint(skill, rules)
        assert not report.results[0].passed


class TestNamingConventionRule:
    def test_upper_snake(self, tmp_path: Path):
        skill = tmp_path / "SKILL.md"
        skill.write_text("content")

        linter = StaticLinter()
        rules = [{"type": "naming_convention", "params": {"convention": "UPPER_SNAKE"}, "severity": "warning"}]
        report = linter.lint(skill, rules)
        assert report.results[0].passed

    def test_upper_snake_fail(self, tmp_path: Path):
        skill = tmp_path / "my-skill.md"
        skill.write_text("content")

        linter = StaticLinter()
        rules = [{"type": "naming_convention", "params": {"convention": "UPPER_SNAKE"}, "severity": "warning"}]
        report = linter.lint(skill, rules)
        assert not report.results[0].passed

    def test_kebab_case(self, tmp_path: Path):
        skill = tmp_path / "my-skill.md"
        skill.write_text("content")

        linter = StaticLinter()
        rules = [{"type": "naming_convention", "params": {"convention": "kebab-case"}, "severity": "warning"}]
        report = linter.lint(skill, rules)
        assert report.results[0].passed


class TestDescriptionQualityRule:
    def test_adequate_description(self, tmp_path: Path):
        skill = tmp_path / "SKILL.md"
        skill.write_text("# Title\n\nThis is a long enough description for quality check purposes.\n\n## Next")

        linter = StaticLinter()
        rules = [{"type": "description_quality", "params": {"min_length": 20}, "severity": "warning"}]
        report = linter.lint(skill, rules)
        assert report.results[0].passed

    def test_too_short_description(self, tmp_path: Path):
        skill = tmp_path / "SKILL.md"
        skill.write_text("# Title\n\nShort.\n\n## Next")

        linter = StaticLinter()
        rules = [{"type": "description_quality", "params": {"min_length": 50}, "severity": "warning"}]
        report = linter.lint(skill, rules)
        assert not report.results[0].passed


class TestUnknownRule:
    def test_unknown_rule_passes_with_warning(self, tmp_path: Path):
        skill = tmp_path / "SKILL.md"
        skill.write_text("# Content")

        linter = StaticLinter()
        rules = [{"type": "nonexistent_rule", "params": {}, "severity": "error"}]
        report = linter.lint(skill, rules)
        assert report.results[0].passed
        assert report.results[0].severity == Severity.WARNING


class TestStaticLintReport:
    def test_error_and_warning_counts(self, tmp_path: Path):
        skill = tmp_path / "SKILL.md"
        skill.write_text("hi")  # Too small and no sections

        linter = StaticLinter()
        rules = [
            {"type": "file_size", "params": {"min_bytes": 100}, "severity": "error"},
            {"type": "has_section", "params": {"section": "## Missing"}, "severity": "warning"},
            {"type": "has_section", "params": {"section": "## Also Missing"}, "severity": "error"},
        ]
        report = linter.lint(skill, rules)
        assert report.error_count == 2
        assert report.warning_count == 1
        assert not report.overall_pass
