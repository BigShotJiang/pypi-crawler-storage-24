"""Tests for YAML config loader — merge, env substitution."""

from __future__ import annotations

import os
from pathlib import Path

import pytest

from fluxloop_cli.config.loader import (
    deep_merge,
    load_config,
    revalidate_config,
    _substitute_env_vars,
)


class TestDeepMerge:
    def test_flat_merge(self):
        base = {"a": 1, "b": 2}
        override = {"b": 3, "c": 4}
        result = deep_merge(base, override)
        assert result == {"a": 1, "b": 3, "c": 4}

    def test_nested_merge(self):
        base = {"runner": {"type": "function", "timeout_seconds": 300}}
        override = {"runner": {"timeout_seconds": 60, "target": "m:f"}}
        result = deep_merge(base, override)
        assert result["runner"]["type"] == "function"
        assert result["runner"]["timeout_seconds"] == 60
        assert result["runner"]["target"] == "m:f"

    def test_override_replaces_non_dict(self):
        base = {"items": [1, 2]}
        override = {"items": [3]}
        result = deep_merge(base, override)
        assert result["items"] == [3]


class TestSubstituteEnvVars:
    def test_replaces_existing_var(self, monkeypatch):
        monkeypatch.setenv("MY_VAR", "hello")
        data = {"key": "${MY_VAR}"}
        _substitute_env_vars(data)
        assert data["key"] == "hello"

    def test_keeps_missing_var(self):
        os.environ.pop("NONEXISTENT_VAR_12345", None)
        data = {"key": "${NONEXISTENT_VAR_12345}"}
        _substitute_env_vars(data)
        assert data["key"] == "${NONEXISTENT_VAR_12345}"

    def test_nested_substitution(self, monkeypatch):
        monkeypatch.setenv("DB_HOST", "localhost")
        data = {"runner": {"environment_vars": {"HOST": "${DB_HOST}"}}}
        _substitute_env_vars(data)
        assert data["runner"]["environment_vars"]["HOST"] == "localhost"

    def test_list_substitution(self, monkeypatch):
        monkeypatch.setenv("ITEM", "replaced")
        data = {"items": ["${ITEM}", "static"]}
        _substitute_env_vars(data)
        assert data["items"] == ["replaced", "static"]


class TestLoadConfig:
    def test_load_simulation_yaml(self, tmp_scenario):
        config = load_config(tmp_scenario)
        assert config.name == "test-experiment"
        assert config.runner.type == "function"
        assert config.runner.target == "my_agent:handler"
        assert config.iterations == 2
        assert len(config.input.items) == 2

    def test_multi_file_merge(self, tmp_workspace):
        scenario_dir = tmp_workspace / ".fluxloop" / "scenarios" / "merge-test"
        config_dir = scenario_dir / "configs"
        config_dir.mkdir(parents=True)

        (config_dir / "scenario.yaml").write_text("name: from-scenario\n")
        (config_dir / "simulation.yaml").write_text(
            "runner:\n  type: function\n  target: m:f\niterations: 3\n"
            "input:\n  items:\n    - text: hello\n"
        )
        config = load_config(scenario_dir)
        assert config.name == "from-scenario"
        assert config.iterations == 3

    def test_env_substitution_in_config(self, tmp_workspace, monkeypatch):
        monkeypatch.setenv("MY_TARGET", "agent:run")
        scenario_dir = tmp_workspace / ".fluxloop" / "scenarios" / "env-test"
        config_dir = scenario_dir / "configs"
        config_dir.mkdir(parents=True)

        (config_dir / "simulation.yaml").write_text(
            "runner:\n  type: function\n  target: '${MY_TARGET}'\n"
            "input:\n  items:\n    - text: hi\n"
        )
        config = load_config(scenario_dir)
        assert config.runner.target == "agent:run"

    def test_missing_config_dir(self, tmp_path):
        with pytest.raises(FileNotFoundError):
            load_config(tmp_path / "nonexistent")

    def test_empty_config_dir(self, tmp_path):
        config_dir = tmp_path / "configs"
        config_dir.mkdir()
        with pytest.raises((FileNotFoundError, ValueError)):
            load_config(tmp_path)

    def test_loads_pulled_inputs_from_messages(self, tmp_workspace):
        import json

        scenario_dir = tmp_workspace / ".fluxloop" / "scenarios" / "pulled-test"
        config_dir = scenario_dir / "configs"
        pulled_dir = scenario_dir / "pulled"
        config_dir.mkdir(parents=True)
        pulled_dir.mkdir(parents=True)

        (config_dir / "simulation.yaml").write_text(
            "runner:\n  type: function\n  target: agent:run\n"
            "input:\n  source: pulled\n"
        )
        (pulled_dir / "inputs.json").write_text(
            json.dumps(
                [
                    {
                        "id": "input-1",
                        "persona_id": "persona-1",
                        "messages": [
                            {"role": "system", "content": "context"},
                            {"role": "user", "content": "hello from pulled"},
                        ],
                        "metadata": {"tag": "smoke"},
                    }
                ]
            )
        )

        config = load_config(scenario_dir)
        assert config.input.source == "pulled"
        assert len(config.input.items) == 1
        assert config.input.items[0].text == "hello from pulled"
        assert config.input.items[0].metadata["id"] == "input-1"

    def test_prefer_pulled_overrides_inline_inputs(self, tmp_workspace):
        import json

        scenario_dir = tmp_workspace / ".fluxloop" / "scenarios" / "prefer-pulled"
        config_dir = scenario_dir / "configs"
        pulled_dir = scenario_dir / "pulled"
        config_dir.mkdir(parents=True)
        pulled_dir.mkdir(parents=True)

        (config_dir / "simulation.yaml").write_text(
            "runner:\n  type: function\n  target: agent:run\n"
            "input:\n  source: inline\n  items:\n    - text: local input\n"
        )
        (pulled_dir / "inputs.json").write_text(
            json.dumps(
                [
                    {
                        "id": "input-2",
                        "content": "pulled input",
                        "metadata": {"source": "server"},
                    }
                ]
            )
        )

        config = load_config(scenario_dir, prefer_pulled=True)
        assert config.input.source == "pulled"
        assert [item.text for item in config.input.items] == ["pulled input"]

    def test_revalidate_config_rejects_invalid_iteration_override(self, tmp_scenario):
        config = load_config(tmp_scenario)

        with pytest.raises(ValueError, match="iterations"):
            revalidate_config(config, iterations=0)
