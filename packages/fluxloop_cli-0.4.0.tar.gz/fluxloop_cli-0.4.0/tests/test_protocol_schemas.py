"""Tests for protocol schema conformance — Pydantic models match JSON schemas."""

from __future__ import annotations

import json

import jsonschema
import pytest

from fluxloop_cli.config.schema import BudgetConfig, RunnerConfig, SandboxConfig, SimulationConfig
from fluxloop_cli.core.executor import RunContext, RunError, RunResult, TokenUsage


class TestConfigSchema:
    def test_pydantic_output_validates(self, load_schema):
        schema = load_schema("config.schema.json")
        config = SimulationConfig(
            name="test",
            runner={"type": "function", "target": "m:f", "timeout_seconds": 30},
            iterations=5,
            input={"source": "inline", "items": [{"text": "hello"}]},
        )
        data = config.model_dump(exclude_none=True)
        jsonschema.validate(data, schema)

    def test_minimal_config_validates(self, load_schema):
        schema = load_schema("config.schema.json")
        config = SimulationConfig(
            runner={"type": "function"},
        )
        data = config.model_dump(exclude_none=True)
        jsonschema.validate(data, schema)

    def test_process_config_validates(self, load_schema):
        schema = load_schema("config.schema.json")
        config = SimulationConfig(
            name="process-test",
            runner={
                "type": "process",
                "command": ["python", "agent.py"],
                "protocol": "ndjson",
                "timeout_seconds": 30,
            },
            input={"source": "pulled", "pulled_path": "./pulled"},
        )
        data = config.model_dump(exclude_none=True)
        jsonschema.validate(data, schema)

    def test_conversation_config_validates(self, load_schema):
        schema = load_schema("config.schema.json")
        config = SimulationConfig(
            runner={"type": "function", "target": "m:f"},
            conversation={
                "enabled": True,
                "max_turns": 3,
                "simulator": {
                    "provider": "anthropic",
                    "model": "claude-sonnet-4-5-20250929",
                },
            },
        )
        data = config.model_dump(exclude_none=True)
        jsonschema.validate(data, schema)


class TestRunResultSchema:
    def test_success_result_validates(self, load_schema):
        schema = load_schema("run-result.schema.json")
        result = RunResult(
            run_id="550e8400-e29b-41d4-a716-446655440000",
            success=True,
            output="hello world",
            duration_ms=150,
            turn_count=2,
            termination_reason="goal_completed",
            token_usage=TokenUsage(input_tokens=10, output_tokens=5, total_tokens=15),
            conversation=[
                {"role": "user", "content": "hello"},
                {"role": "assistant", "content": "hello world"},
            ],
        )
        data = result.model_dump()
        jsonschema.validate(data, schema)

    def test_failure_result_validates(self, load_schema):
        schema = load_schema("run-result.schema.json")
        result = RunResult(
            run_id="550e8400-e29b-41d4-a716-446655440001",
            success=False,
            output="",
            duration_ms=50,
            error=RunError(message="something failed", traceback="Traceback..."),
        )
        data = result.model_dump()
        jsonschema.validate(data, schema)


class TestSummarySchema:
    def test_summary_validates(self, load_schema):
        schema = load_schema("summary.schema.json")
        summary = {
            "experiment_name": "test-exp",
            "runner_type": "function",
            "total_runs": 10,
            "success_count": 8,
            "failure_count": 2,
            "success_rate": 0.8,
            "total_duration_ms": 5000,
            "total_tokens": 1500,
            "created_at": "2026-03-08T15:00:00+00:00",
        }
        jsonschema.validate(summary, schema)

    def test_skill_summary_with_contract_validates(self, load_schema):
        schema = load_schema("summary.schema.json")
        summary = {
            "experiment_name": "skill-benchmark",
            "runner_type": "skill",
            "total_runs": 5,
            "success_count": 4,
            "failure_count": 1,
            "success_rate": 0.8,
            "total_duration_ms": 52600,
            "total_tokens": 20500,
            "total_cost_usd": 0.53,
            "avg_duration_ms": 10520,
            "avg_turns": 9.5,
            "avg_cost_usd": 0.133,
            "contract_summary": {
                "overall_pass_rate": 0.75,
                "assertion_pass_rates": {
                    "tool_called": 1.0,
                    "file_exists": 0.75,
                },
            },
            "created_at": "2026-03-08T15:00:00+00:00",
        }
        jsonschema.validate(summary, schema)


class TestErrorsSchema:
    def test_errors_file_validates(self, load_schema):
        schema = load_schema("errors.schema.json")
        payload = {
            "experiment_name": "test-exp",
            "runner_type": "function",
            "failure_count": 1,
            "created_at": "2026-03-08T15:00:00+00:00",
            "failures": [
                {
                    "run_id": "abc-123",
                    "iteration": 0,
                    "persona": "angry_customer",
                    "input": "refund me",
                    "duration_ms": 1820,
                    "timestamp": "2026-03-08T15:00:00+00:00",
                    "error": {
                        "message": "Timeout",
                        "traceback": "stack trace",
                    },
                }
            ],
        }
        jsonschema.validate(payload, schema)


class TestTraceSummarySchema:
    def test_trace_record_validates(self, load_schema):
        schema = load_schema("trace-summary.schema.json")
        record = {
            "run_id": "abc-123",
            "iteration": 0,
            "persona": None,
            "input": "hello",
            "input_item_id": "input-1",
            "input_metadata": {"id": "input-1", "messages": [{"role": "user", "content": "hello"}]},
            "output": "world",
            "success": True,
            "duration_ms": 100,
            "turn_count": 2,
            "termination_reason": "goal_completed",
            "conversation": [
                {"role": "user", "content": "hello"},
                {"role": "assistant", "content": "world"},
            ],
            "token_usage": None,
            "error": None,
            "timestamp": "2026-03-08T15:00:00+00:00",
        }
        jsonschema.validate(record, schema)

    def test_skill_trace_record_validates(self, load_schema):
        schema = load_schema("trace-summary.schema.json")
        record = {
            "run_id": "abc-123",
            "iteration": 0,
            "persona": None,
            "input": "hello",
            "input_item_id": "input-1",
            "input_metadata": {
                "id": "input-1",
                "persona_id": "persona-1",
                "messages": [{"role": "user", "content": "hello"}],
            },
            "output": "world",
            "success": True,
            "duration_ms": 100,
            "token_usage": {"input_tokens": 10, "output_tokens": 5, "total_tokens": 15},
            "timestamp": "2026-03-08T15:00:00+00:00",
            "tool_calls": [
                {
                    "turn": 0,
                    "tool": "Write",
                    "input": {"file_path": "README.md"},
                    "output": "ok",
                    "is_error": False,
                    "duration_ms": 30,
                }
            ],
            "skill_metadata": {
                "skill_path": "./SKILL.md",
                "harness": "claude",
                "sandbox_path": "/tmp/fluxloop-sandbox-123",
                "turn_count": 2,
                "total_cost_usd": 0.05,
                "files_created": ["README.md"],
                "commands_executed": ["ls"],
            },
            "static_results": {"overall_pass": True, "error_count": 0, "warning_count": 0},
            "contract_results": {"overall_pass": True, "error_count": 0, "warning_count": 0},
        }
        jsonschema.validate(record, schema)


# --- Phase 2: Skill config + contract schemas ---


class TestSkillConfigSchema:
    def test_skill_config_validates(self, load_schema):
        schema = load_schema("config.schema.json")
        config = SimulationConfig(
            name="skill-test",
            runner=RunnerConfig(
                type="skill",
                skill_path="/path/to/SKILL.md",
                harness="claude",
                allowed_tools=["Write", "Read"],
                skill_max_turns=10,
                sandbox=SandboxConfig(copy_files=["src/"], cleanup=True),
                budget=BudgetConfig(max_budget_usd=1.0),
            ),
            iterations=3,
        )
        data = config.model_dump(exclude_none=True)
        jsonschema.validate(data, schema)


class TestRunResultWithToolCalls:
    def test_result_with_tool_calls_validates(self, load_schema):
        schema = load_schema("run-result.schema.json")
        result = RunResult(
            run_id="550e8400-e29b-41d4-a716-446655440002",
            success=True,
            output="done",
            duration_ms=500,
            tool_calls=[
                {"turn": 0, "tool": "Write", "input": {"file_path": "/tmp/a.py"}, "output": "ok", "is_error": False, "duration_ms": 50},
                {"turn": 1, "tool": "Bash", "input": {"command": "ls"}, "output": "a.py", "is_error": False, "duration_ms": 30},
            ],
            metadata={"skill_metadata": {"turn_count": 2, "total_cost_usd": 0.05}},
        )
        data = result.model_dump()
        jsonschema.validate(data, schema)


class TestStaticContractSchema:
    def test_valid_contract(self, load_schema):
        schema = load_schema("skill-static-contract.schema.json")
        contract = {
            "rules": [
                {"type": "has_section", "params": {"section": "## Instructions"}, "severity": "error"},
                {"type": "file_size", "params": {"min_bytes": 50, "max_bytes": 100000}, "severity": "error"},
                {"type": "forbidden_pattern", "params": {"pattern": "api_key"}, "severity": "warning", "message": "No secrets"},
            ],
        }
        jsonschema.validate(contract, schema)

    def test_minimal_contract(self, load_schema):
        schema = load_schema("skill-static-contract.schema.json")
        contract = {"rules": [{"type": "encoding"}]}
        jsonschema.validate(contract, schema)


class TestBehaviorContractSchema:
    def test_valid_contract(self, load_schema):
        schema = load_schema("skill-behavior-contract.schema.json")
        contract = {
            "assertions": [
                {"type": "tool_called", "params": {"tool": "Write"}, "severity": "error"},
                {"type": "turn_count", "params": {"max": 10}, "severity": "warning"},
                {"type": "cost_budget", "params": {"max_usd": 0.50}, "severity": "error"},
                {"type": "response_contains", "params": {"pattern": "done"}, "severity": "error"},
            ],
        }
        jsonschema.validate(contract, schema)

    def test_minimal_contract(self, load_schema):
        schema = load_schema("skill-behavior-contract.schema.json")
        contract = {"assertions": [{"type": "duration"}]}
        jsonschema.validate(contract, schema)


class TestSyncPayloadSchema:
    def test_sync_payload_validates(self, load_schema):
        schema = load_schema("sync-payload.schema.json")
        payload = {
            "bundle_version_id": "bundle-1",
            "run_batch": {
                "execution_target": "local",
                "status": "completed",
                "started_at": "2026-03-08T15:00:00+00:00",
                "completed_at": "2026-03-08T15:01:00+00:00",
            },
            "runs": [
                {
                    "id": "run-1",
                    "input_item_id": "input-1",
                    "persona_id": "persona-1",
                    "status": "completed",
                    "input_snapshot": {
                        "id": "input-1",
                        "persona_id": "persona-1",
                        "messages": [{"role": "user", "content": "hello"}],
                        "metadata": {"source": "sync"},
                    },
                }
            ],
            "turns": [
                {
                    "run_id": "run-1",
                    "turn_id": "run-1-t0",
                    "sequence": 0,
                    "role": "assistant",
                    "content": "done",
                    "timestamp": "2026-03-08T15:00:30+00:00",
                }
            ],
            "run_results": [
                {
                    "run_id": "run-1",
                    "status": "completed",
                    "metrics": {
                        "duration_ms": 1000,
                        "turn_count": 2,
                        "termination_reason": "goal_completed",
                    },
                    "transcript": [
                        {"role": "user", "content": "hello"},
                        {"role": "assistant", "content": "done"},
                    ],
                }
            ],
        }
        jsonschema.validate(payload, schema)
