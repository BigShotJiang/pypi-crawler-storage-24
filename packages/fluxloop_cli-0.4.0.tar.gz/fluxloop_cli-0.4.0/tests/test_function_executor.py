"""Tests for FunctionExecutor — execute, timeout, env vars."""

from __future__ import annotations

import asyncio
import os
import sys
import time
from pathlib import Path

import pytest

from fluxloop_cli.config.schema import RunnerConfig
from fluxloop_cli.core.executor import RunContext
from fluxloop_cli.core.function_executor import FunctionExecutor, _extract_token_usage


@pytest.fixture
def agent_dir(tmp_path: Path) -> Path:
    """Create a temp directory with test agent modules."""
    agent_file = tmp_path / "test_agent.py"
    agent_file.write_text(
        "def echo(text):\n"
        "    return f'echo: {text}'\n"
        "\n"
        "async def async_echo(text):\n"
        "    return f'async: {text}'\n"
        "\n"
        "def env_reader(text):\n"
        "    import os\n"
        "    return os.environ.get('TEST_ENV_VAR', 'NOT_SET')\n"
        "\n"
        "def mutate_env(text):\n"
        "    import os\n"
        "    os.environ['TEST_ENV_VAR'] = 'mutated-in-child'\n"
        "    return os.environ['TEST_ENV_VAR']\n"
        "\n"
        "def slow_handler(text):\n"
        "    import time\n"
        "    time.sleep(3)\n"
        "    return 'done'\n"
        "\n"
        "def error_handler(text):\n"
        "    raise ValueError('test error')\n"
        "\n"
        "def dict_output(text):\n"
        "    return {\n"
        "        'result': text,\n"
        "        'token_usage': {'input_tokens': 10, 'output_tokens': 5, 'total_tokens': 15}\n"
        "    }\n"
        "\n"
        "not_callable = 'i am a string'\n"
    )
    return tmp_path


def _make_executor(agent_dir: Path, target: str, **kwargs) -> FunctionExecutor:
    config = RunnerConfig(
        type="function",
        target=target,
        working_directory=str(agent_dir),
        **kwargs,
    )
    return FunctionExecutor(config)


def _default_context(**kwargs) -> RunContext:
    return RunContext(iteration=0, scenario="test", **kwargs)


class TestFunctionExecutorExecute:
    @pytest.mark.asyncio
    async def test_sync_handler(self, agent_dir):
        executor = _make_executor(agent_dir, "test_agent:echo")
        result = await executor.execute(
            input_text="hi", context=_default_context(), run_id="r1",
        )
        assert result.success
        assert result.output == "echo: hi"
        assert result.duration_ms >= 0

    @pytest.mark.asyncio
    async def test_async_handler(self, agent_dir):
        executor = _make_executor(agent_dir, "test_agent:async_echo")
        result = await executor.execute(
            input_text="hi", context=_default_context(), run_id="r2",
        )
        assert result.success
        assert result.output == "async: hi"

    @pytest.mark.asyncio
    async def test_error_handler(self, agent_dir):
        executor = _make_executor(agent_dir, "test_agent:error_handler")
        result = await executor.execute(
            input_text="x", context=_default_context(), run_id="r3",
        )
        assert not result.success
        assert result.error is not None
        assert "test error" in result.error.message

    def test_missing_target(self):
        config = RunnerConfig(type="function", target=None)
        executor = FunctionExecutor(config)
        with pytest.raises(ValueError, match="target is required"):
            executor._load_handler()

    def test_invalid_target_format(self):
        config = RunnerConfig(type="function", target="no_colon")
        executor = FunctionExecutor(config)
        with pytest.raises(ValueError, match="module:function"):
            executor._load_handler()


class TestFunctionExecutorEnvVars:
    @pytest.mark.asyncio
    async def test_env_vars_applied(self, agent_dir):
        executor = _make_executor(agent_dir, "test_agent:env_reader")
        ctx = _default_context(environment_vars={"TEST_ENV_VAR": "injected"})
        result = await executor.execute(input_text="x", context=ctx, run_id="r6")
        assert result.success
        assert result.output == "injected"

    @pytest.mark.asyncio
    async def test_env_vars_restored_after_execution(self, agent_dir):
        os.environ.pop("TEST_ENV_VAR", None)
        executor = _make_executor(agent_dir, "test_agent:env_reader")
        ctx = _default_context(environment_vars={"TEST_ENV_VAR": "temp"})
        await executor.execute(input_text="x", context=ctx, run_id="r7")
        assert os.environ.get("TEST_ENV_VAR") is None

    @pytest.mark.asyncio
    async def test_env_vars_restored_on_error(self, agent_dir):
        os.environ.pop("TEST_ENV_VAR", None)
        executor = _make_executor(agent_dir, "test_agent:error_handler")
        ctx = _default_context(environment_vars={"TEST_ENV_VAR": "temp"})
        await executor.execute(input_text="x", context=ctx, run_id="r8")
        assert os.environ.get("TEST_ENV_VAR") is None

    @pytest.mark.asyncio
    async def test_child_env_mutation_does_not_leak(self, agent_dir):
        os.environ["TEST_ENV_VAR"] = "parent"
        executor = _make_executor(agent_dir, "test_agent:mutate_env")
        result = await executor.execute(
            input_text="x", context=_default_context(), run_id="r8b",
        )
        assert result.success
        assert result.output == "mutated-in-child"
        assert os.environ["TEST_ENV_VAR"] == "parent"
        os.environ.pop("TEST_ENV_VAR", None)


class TestFunctionExecutorTimeout:
    @pytest.mark.asyncio
    async def test_timeout(self, agent_dir):
        executor = _make_executor(agent_dir, "test_agent:slow_handler", timeout_seconds=1)
        result = await executor.execute(
            input_text="x", context=_default_context(), run_id="r9",
        )
        assert not result.success
        assert "Timed out" in result.error.message


class TestExtractTokenUsage:
    def test_dict_with_token_usage(self):
        output = {"token_usage": {"input_tokens": 10, "output_tokens": 5, "total_tokens": 15}}
        usage = _extract_token_usage(output)
        assert usage is not None
        assert usage.total_tokens == 15

    def test_dict_with_usage_key(self):
        output = {"usage": {"input_tokens": 1, "output_tokens": 2, "total_tokens": 3}}
        usage = _extract_token_usage(output)
        assert usage.total_tokens == 3

    def test_string_output(self):
        assert _extract_token_usage("hello") is None

    def test_dict_without_usage(self):
        assert _extract_token_usage({"result": "ok"}) is None
