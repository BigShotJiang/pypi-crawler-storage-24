"""Tests for behavior contract matcher — all assertion types."""

from __future__ import annotations

from pathlib import Path

from fluxloop_cli.contract.behavior_matcher import BehaviorMatcher, BehaviorReport
from fluxloop_cli.contract.static_linter import Severity


def _evaluate(assertions, **kwargs):
    """Helper to evaluate assertions with sensible defaults."""
    defaults = {
        "tool_calls": [],
        "response_text": "",
        "sandbox_path": None,
        "duration_ms": 100,
        "turn_count": 3,
        "token_usage": None,
        "total_cost_usd": None,
    }
    defaults.update(kwargs)
    return BehaviorMatcher().evaluate(assertions=assertions, **defaults)


class TestToolCalled:
    def test_tool_was_called(self):
        report = _evaluate(
            [{"type": "tool_called", "params": {"tool": "Write"}, "severity": "error"}],
            tool_calls=[{"tool": "Write"}, {"tool": "Bash"}],
        )
        assert report.results[0].passed

    def test_tool_not_called(self):
        report = _evaluate(
            [{"type": "tool_called", "params": {"tool": "Write"}, "severity": "error"}],
            tool_calls=[{"tool": "Bash"}],
        )
        assert not report.results[0].passed

    def test_min_count(self):
        report = _evaluate(
            [{"type": "tool_called", "params": {"tool": "Write", "min_count": 2}, "severity": "error"}],
            tool_calls=[{"tool": "Write"}, {"tool": "Write"}, {"tool": "Bash"}],
        )
        assert report.results[0].passed

    def test_min_count_not_met(self):
        report = _evaluate(
            [{"type": "tool_called", "params": {"tool": "Write", "min_count": 3}, "severity": "error"}],
            tool_calls=[{"tool": "Write"}, {"tool": "Write"}],
        )
        assert not report.results[0].passed


class TestToolNotCalled:
    def test_tool_absent(self):
        report = _evaluate(
            [{"type": "tool_not_called", "params": {"tool": "Bash"}, "severity": "error"}],
            tool_calls=[{"tool": "Write"}],
        )
        assert report.results[0].passed

    def test_tool_present(self):
        report = _evaluate(
            [{"type": "tool_not_called", "params": {"tool": "Bash"}, "severity": "error"}],
            tool_calls=[{"tool": "Bash"}],
        )
        assert not report.results[0].passed


class TestToolSequence:
    def test_correct_sequence(self):
        report = _evaluate(
            [{"type": "tool_sequence", "params": {"sequence": ["Read", "Write"]}, "severity": "error"}],
            tool_calls=[{"tool": "Read"}, {"tool": "Bash"}, {"tool": "Write"}],
        )
        assert report.results[0].passed

    def test_wrong_order(self):
        report = _evaluate(
            [{"type": "tool_sequence", "params": {"sequence": ["Write", "Read"]}, "severity": "error"}],
            tool_calls=[{"tool": "Read"}, {"tool": "Write"}],
        )
        assert not report.results[0].passed

    def test_missing_tool_in_sequence(self):
        report = _evaluate(
            [{"type": "tool_sequence", "params": {"sequence": ["Read", "Write", "Bash"]}, "severity": "error"}],
            tool_calls=[{"tool": "Read"}, {"tool": "Write"}],
        )
        assert not report.results[0].passed


class TestFileExists:
    def test_file_present(self, tmp_path: Path):
        (tmp_path / "output.txt").write_text("result")
        report = _evaluate(
            [{"type": "file_exists", "params": {"path": "output.txt"}, "severity": "error"}],
            sandbox_path=tmp_path,
        )
        assert report.results[0].passed

    def test_file_missing(self, tmp_path: Path):
        report = _evaluate(
            [{"type": "file_exists", "params": {"path": "missing.txt"}, "severity": "error"}],
            sandbox_path=tmp_path,
        )
        assert not report.results[0].passed

    def test_no_sandbox(self):
        report = _evaluate(
            [{"type": "file_exists", "params": {"path": "output.txt"}, "severity": "error"}],
            sandbox_path=None,
        )
        assert not report.results[0].passed

    def test_rejects_path_traversal(self, tmp_path: Path):
        sandbox_path = tmp_path / "sandbox"
        sandbox_path.mkdir()
        (tmp_path / "secret.txt").write_text("secret")

        report = _evaluate(
            [{"type": "file_exists", "params": {"path": "../secret.txt"}, "severity": "error"}],
            sandbox_path=sandbox_path,
        )
        assert not report.results[0].passed


class TestFileContains:
    def test_pattern_found(self, tmp_path: Path):
        (tmp_path / "output.txt").write_text("Hello World 123")
        report = _evaluate(
            [{"type": "file_contains", "params": {"path": "output.txt", "pattern": r"World \d+"}, "severity": "error"}],
            sandbox_path=tmp_path,
        )
        assert report.results[0].passed

    def test_pattern_not_found(self, tmp_path: Path):
        (tmp_path / "output.txt").write_text("Hello World")
        report = _evaluate(
            [{"type": "file_contains", "params": {"path": "output.txt", "pattern": r"\d+"}, "severity": "error"}],
            sandbox_path=tmp_path,
        )
        assert not report.results[0].passed

    def test_file_missing(self, tmp_path: Path):
        report = _evaluate(
            [{"type": "file_contains", "params": {"path": "missing.txt", "pattern": "x"}, "severity": "error"}],
            sandbox_path=tmp_path,
        )
        assert not report.results[0].passed

    def test_rejects_path_traversal(self, tmp_path: Path):
        sandbox_path = tmp_path / "sandbox"
        sandbox_path.mkdir()
        (tmp_path / "secret.txt").write_text("top secret")

        report = _evaluate(
            [{"type": "file_contains", "params": {"path": "../secret.txt", "pattern": "secret"}, "severity": "error"}],
            sandbox_path=sandbox_path,
        )
        assert not report.results[0].passed

    def test_invalid_regex_fails_without_crashing(self, tmp_path: Path):
        (tmp_path / "output.txt").write_text("Hello World")
        report = _evaluate(
            [{"type": "file_contains", "params": {"path": "output.txt", "pattern": "("}, "severity": "error"}],
            sandbox_path=tmp_path,
        )
        assert not report.results[0].passed
        assert "Invalid regex" in (report.results[0].actual or "")


class TestTurnCount:
    def test_within_limit(self):
        report = _evaluate(
            [{"type": "turn_count", "params": {"max": 5}, "severity": "error"}],
            turn_count=3,
        )
        assert report.results[0].passed

    def test_exceeds_limit(self):
        report = _evaluate(
            [{"type": "turn_count", "params": {"max": 2}, "severity": "error"}],
            turn_count=5,
        )
        assert not report.results[0].passed

    def test_exact_limit(self):
        report = _evaluate(
            [{"type": "turn_count", "params": {"max": 5}, "severity": "error"}],
            turn_count=5,
        )
        assert report.results[0].passed


class TestTokenBudget:
    def test_within_budget(self):
        report = _evaluate(
            [{"type": "token_budget", "params": {"max_tokens": 1000}, "severity": "error"}],
            token_usage={"total_tokens": 500},
        )
        assert report.results[0].passed

    def test_exceeds_budget(self):
        report = _evaluate(
            [{"type": "token_budget", "params": {"max_tokens": 100}, "severity": "error"}],
            token_usage={"total_tokens": 500},
        )
        assert not report.results[0].passed

    def test_no_token_usage(self):
        report = _evaluate(
            [{"type": "token_budget", "params": {"max_tokens": 100}, "severity": "error"}],
            token_usage=None,
        )
        # 0 tokens <= 100 budget → pass
        assert report.results[0].passed


class TestCostBudget:
    def test_within_budget(self):
        report = _evaluate(
            [{"type": "cost_budget", "params": {"max_usd": 1.0}, "severity": "error"}],
            total_cost_usd=0.5,
        )
        assert report.results[0].passed

    def test_exceeds_budget(self):
        report = _evaluate(
            [{"type": "cost_budget", "params": {"max_usd": 0.10}, "severity": "error"}],
            total_cost_usd=0.50,
        )
        assert not report.results[0].passed

    def test_no_cost(self):
        report = _evaluate(
            [{"type": "cost_budget", "params": {"max_usd": 1.0}, "severity": "error"}],
            total_cost_usd=None,
        )
        assert report.results[0].passed


class TestResponseContains:
    def test_pattern_found(self):
        report = _evaluate(
            [{"type": "response_contains", "params": {"pattern": r"hello\s+world"}, "severity": "error"}],
            response_text="say hello  world here",
        )
        assert report.results[0].passed

    def test_pattern_not_found(self):
        report = _evaluate(
            [{"type": "response_contains", "params": {"pattern": "goodbye"}, "severity": "error"}],
            response_text="hello world",
        )
        assert not report.results[0].passed

    def test_invalid_regex_fails_without_crashing(self):
        report = _evaluate(
            [{"type": "response_contains", "params": {"pattern": "("}, "severity": "error"}],
            response_text="hello world",
        )
        assert not report.results[0].passed
        assert "Invalid regex" in (report.results[0].actual or "")


class TestResponseNotContains:
    def test_pattern_absent(self):
        report = _evaluate(
            [{"type": "response_not_contains", "params": {"pattern": "error"}, "severity": "error"}],
            response_text="all good",
        )
        assert report.results[0].passed

    def test_pattern_present(self):
        report = _evaluate(
            [{"type": "response_not_contains", "params": {"pattern": "error"}, "severity": "error"}],
            response_text="an error occurred",
        )
        assert not report.results[0].passed


class TestDuration:
    def test_within_limit(self):
        report = _evaluate(
            [{"type": "duration", "params": {"max_ms": 5000}, "severity": "error"}],
            duration_ms=3000,
        )
        assert report.results[0].passed

    def test_exceeds_limit(self):
        report = _evaluate(
            [{"type": "duration", "params": {"max_ms": 100}, "severity": "error"}],
            duration_ms=200,
        )
        assert not report.results[0].passed


class TestUnknownAssertion:
    def test_unknown_passes_with_warning(self):
        report = _evaluate(
            [{"type": "custom_type", "params": {}, "severity": "error"}],
        )
        assert report.results[0].passed
        assert report.results[0].severity == Severity.WARNING


class TestBehaviorReport:
    def test_overall_pass_all_pass(self):
        report = _evaluate([
            {"type": "turn_count", "params": {"max": 10}, "severity": "error"},
            {"type": "duration", "params": {"max_ms": 5000}, "severity": "error"},
        ], turn_count=3, duration_ms=100)
        assert report.overall_pass
        assert report.error_count == 0

    def test_overall_fail_on_error(self):
        report = _evaluate([
            {"type": "turn_count", "params": {"max": 1}, "severity": "error"},
            {"type": "duration", "params": {"max_ms": 5000}, "severity": "warning"},
        ], turn_count=5, duration_ms=100)
        assert not report.overall_pass
        assert report.error_count == 1

    def test_overall_pass_with_warning_fail(self):
        report = _evaluate([
            {"type": "turn_count", "params": {"max": 10}, "severity": "error"},
            {"type": "duration", "params": {"max_ms": 50}, "severity": "warning"},
        ], turn_count=3, duration_ms=100)
        # Warning fail doesn't block overall pass
        assert report.overall_pass
        assert report.warning_count == 1

    def test_multiple_assertions_mixed(self):
        report = _evaluate(
            [
                {"type": "tool_called", "params": {"tool": "Write"}, "severity": "error"},
                {"type": "response_contains", "params": {"pattern": "done"}, "severity": "error"},
                {"type": "turn_count", "params": {"max": 10}, "severity": "warning"},
            ],
            tool_calls=[{"tool": "Write"}],
            response_text="done!",
            turn_count=3,
        )
        assert report.overall_pass
        assert len(report.results) == 3
        assert all(r.passed for r in report.results)
