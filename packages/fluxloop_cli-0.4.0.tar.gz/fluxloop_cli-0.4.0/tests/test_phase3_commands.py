"""Command-level tests for Phase 3 backend sync workflows."""

from __future__ import annotations

from pathlib import Path

from typer.testing import CliRunner

from fluxloop_cli.commands import evaluate, scenarios, sync_cmd, test_cmd
from fluxloop_cli.main import app
from fluxloop_cli.workspace.context import load_context, set_current_scenario_id

runner = CliRunner()


class _FakeResponse:
    status_code = 200
    is_success = True
    text = ""

    def __init__(self, payload):
        self._payload = payload

    def json(self):
        return self._payload


class TestScenariosCommand:
    def test_create_scaffolds_local_scenario(self, tmp_workspace: Path, monkeypatch):
        monkeypatch.chdir(tmp_workspace)
        monkeypatch.setattr(scenarios, "get_current_web_project_id", lambda: "proj-1")
        monkeypatch.setattr(scenarios, "create_client", lambda *args, **kwargs: object())
        monkeypatch.setattr(
            scenarios,
            "post_with_retry",
            lambda client, endpoint, payload: _FakeResponse(
                {
                    "id": "scenario-1",
                    "name": payload["name"],
                    "config_snapshot": {
                        "runner": {"type": "function", "target": "agent:run"},
                        "iterations": 2,
                    },
                }
            ),
        )

        result = runner.invoke(
            app,
            ["scenarios", "create", "--name", "happy-path", "--goal", "E2E"],
        )

        assert result.exit_code == 0
        simulation = (
            tmp_workspace
            / ".fluxloop"
            / "scenarios"
            / "happy-path"
            / "configs"
            / "simulation.yaml"
        )
        assert simulation.exists()
        ctx = load_context(tmp_workspace)
        assert ctx is not None
        assert ctx.current_scenario == "happy-path"
        assert ctx.current_scenario_id == "scenario-1"


class TestSyncCommand:
    def test_pull_updates_current_selection_and_lineage(
        self,
        tmp_workspace: Path,
        monkeypatch,
    ):
        monkeypatch.chdir(tmp_workspace)
        scenario_dir = tmp_workspace / ".fluxloop" / "scenarios" / "demo"
        scenario_dir.mkdir(parents=True, exist_ok=True)

        monkeypatch.setattr(sync_cmd, "get_current_web_project_id", lambda: "proj-1")
        monkeypatch.setattr(sync_cmd, "_resolve_bundle_version_id", lambda **kwargs: "bundle-1")
        monkeypatch.setattr(sync_cmd, "ensure_scenario_scaffold", lambda name: scenario_dir)
        monkeypatch.setattr(sync_cmd, "create_client", lambda *args, **kwargs: object())

        class _FakePuller:
            def __init__(self, client):
                pass

            def pull(self, scenario_dir, **kwargs):
                return {
                    "bundle_version": {"id": "bundle-1"},
                    "input_set": {"id": "set-1"},
                    "scenario_context": {
                        "scenario": {"id": "sc-1", "name": "demo"},
                    },
                    "input_items": [{"id": "input-1"}],
                    "personas": [{"id": "persona-1"}],
                    "criteria_pack": [{"id": "criteria-1"}],
                }

        monkeypatch.setattr(sync_cmd, "SyncPuller", _FakePuller)

        result = runner.invoke(app, ["sync", "pull", "--scenario", "demo"])

        assert result.exit_code == 0
        ctx = load_context(tmp_workspace)
        assert ctx is not None
        assert ctx.current_scenario == "demo"
        assert ctx.current_scenario_id == "sc-1"
        assert ctx.current_input_set_id == "set-1"
        assert ctx.current_dataset_version_id == "set-1"
        assert ctx.current_bundle_version_id == "bundle-1"

    def test_pull_fails_when_scenario_bundle_cannot_be_resolved(
        self,
        tmp_workspace: Path,
        monkeypatch,
    ):
        monkeypatch.chdir(tmp_workspace)
        monkeypatch.setattr(sync_cmd, "get_current_web_project_id", lambda: "proj-1")
        monkeypatch.setattr(sync_cmd, "_lookup_scenario_id", lambda *args, **kwargs: "sc-1")
        monkeypatch.setattr(
            sync_cmd,
            "_lookup_latest_bundle_version_id",
            lambda *args, **kwargs: None,
        )

        result = runner.invoke(app, ["sync", "pull", "--scenario", "demo"])

        assert result.exit_code == 1
        assert "No published bundle found" in result.stdout


class TestTestCommand:
    def test_root_invocation_runs_default_workflow(self, monkeypatch):
        captured = {}

        def fake_run(**kwargs):
            captured.update(kwargs)

        monkeypatch.setattr(test_cmd, "_run_test_workflow", fake_run)

        result = runner.invoke(
            app,
            ["test", "--scenario", "demo", "--skip-pull", "--skip-push"],
        )

        assert result.exit_code == 0
        assert captured["scenario"] == "demo"
        assert captured["skip_pull"] is True
        assert captured["skip_push"] is True

    def test_push_failure_exits_nonzero(self, tmp_workspace: Path, monkeypatch):
        monkeypatch.chdir(tmp_workspace)
        scenario_dir = tmp_workspace / ".fluxloop" / "scenarios" / "demo"
        scenario_dir.mkdir(parents=True, exist_ok=True)

        monkeypatch.setattr(test_cmd, "_resolve_scenario_name", lambda scenario: scenario or "demo")
        monkeypatch.setattr(test_cmd, "ensure_scenario_scaffold", lambda name: scenario_dir)
        monkeypatch.setattr(test_cmd, "_load_env_chain", lambda scenario_dir: None)
        monkeypatch.setattr(
            test_cmd,
            "load_config",
            lambda *args, **kwargs: type(
                "Config",
                (),
                {
                    "name": "demo",
                    "iterations": 1,
                    "input": type("Input", (), {"items": [type("Item", (), {"text": "hello", "metadata": {}})()]}),
                    "runner": type("Runner", (), {"type": "function", "environment_vars": {}, "target": "agent:run"})(),
                },
            )(),
        )
        monkeypatch.setattr(test_cmd, "create_executor", lambda config: object())
        async def _fake_run_loop(*args, **kwargs):
            return []

        monkeypatch.setattr(test_cmd, "_run_loop", _fake_run_loop)
        monkeypatch.setattr(
            test_cmd.SummaryWriter,
            "write",
            lambda self, output_dir, config, results: None,
        )
        monkeypatch.setattr(test_cmd, "resolve_api_url", lambda *args, **kwargs: "https://api.test")
        monkeypatch.setattr(test_cmd, "get_current_web_project_id", lambda: "proj-1")
        monkeypatch.setattr(test_cmd, "create_client", lambda *args, **kwargs: object())

        class _FailingUploader:
            def __init__(self, client):
                pass

            def upload_from_result_dir(self, output_dir, scenario_dir):
                raise RuntimeError("upload boom")

        monkeypatch.setattr(test_cmd, "SyncUploader", _FailingUploader)

        result = runner.invoke(
            app,
            ["test", "--scenario", "demo", "--skip-pull"],
        )

        assert result.exit_code == 1
        assert "Push failed: upload boom" in result.stdout


class TestEvaluateCommand:
    def test_root_invocation_runs_default_workflow(self, monkeypatch):
        captured = {}

        def fake_run(**kwargs):
            captured.update(kwargs)

        monkeypatch.setattr(evaluate, "_run_evaluation_command", fake_run)

        result = runner.invoke(
            app,
            ["evaluate", "--scenario-id", "sc-1"],
        )

        assert result.exit_code == 0
        assert captured["scenario_id"] == "sc-1"
        assert captured["wait"] is True
        assert captured["poll_interval"] == 5

    def test_evaluate_uses_current_scenario_to_resolve_latest_experiment(
        self,
        tmp_workspace: Path,
        monkeypatch,
    ):
        monkeypatch.chdir(tmp_workspace)
        set_current_scenario_id("sc-1", tmp_workspace)
        monkeypatch.setattr(evaluate, "get_current_web_project_id", lambda: "proj-1")
        monkeypatch.setattr(evaluate, "create_client", lambda *args, **kwargs: object())

        captured = {"get_calls": [], "post_payload": None}

        def fake_get_with_retry(client, endpoint, **kwargs):
            captured["get_calls"].append((endpoint, kwargs.get("params")))
            if endpoint == "/api/experiments":
                return _FakeResponse([{"experiment_id": "exp-latest"}])
            raise AssertionError(f"unexpected endpoint: {endpoint}")

        def fake_post_with_retry(client, endpoint, payload):
            captured["post_payload"] = payload
            return _FakeResponse({"evaluation_id": "eval-1", "status": "queued"})

        monkeypatch.setattr(evaluate, "get_with_retry", fake_get_with_retry)
        monkeypatch.setattr(evaluate, "post_with_retry", fake_post_with_retry)

        result = runner.invoke(app, ["evaluate", "--no-wait"])

        assert result.exit_code == 0
        assert captured["get_calls"] == [
            (
                "/api/experiments",
                {"project_id": "proj-1", "limit": 1, "scenario_id": "sc-1"},
            )
        ]
        assert captured["post_payload"] == {
            "project_id": "proj-1",
            "experiment_id": "exp-latest",
        }
        ctx = load_context(tmp_workspace)
        assert ctx is not None
        assert ctx.current_experiment_id == "exp-latest"

    def test_evaluate_resolves_experiment_from_run_id(
        self,
        monkeypatch,
    ):
        monkeypatch.setattr(evaluate, "get_current_web_project_id", lambda: "proj-1")
        monkeypatch.setattr(evaluate, "create_client", lambda *args, **kwargs: object())

        captured = {"get_calls": [], "post_payload": None}

        def fake_get_with_retry(client, endpoint, **kwargs):
            captured["get_calls"].append((endpoint, kwargs.get("params")))
            if endpoint == "/api/runs":
                return _FakeResponse([{"id": "run-2", "experiment_id": "exp-2"}])
            raise AssertionError(f"unexpected endpoint: {endpoint}")

        def fake_post_with_retry(client, endpoint, payload):
            captured["post_payload"] = payload
            return _FakeResponse({"evaluation_id": "eval-2", "status": "queued"})

        monkeypatch.setattr(evaluate, "get_with_retry", fake_get_with_retry)
        monkeypatch.setattr(evaluate, "post_with_retry", fake_post_with_retry)

        result = runner.invoke(app, ["evaluate", "--run-id", "run-2", "--no-wait"])

        assert result.exit_code == 0
        assert captured["get_calls"] == [
            (
                "/api/runs",
                {"project_id": "proj-1", "limit": 200, "offset": 0},
            )
        ]
        assert captured["post_payload"] == {
            "project_id": "proj-1",
            "experiment_id": "exp-2",
            "run_ids": ["run-2"],
        }

    def test_wait_for_evaluation_polls_with_project_and_experiment(self, monkeypatch):
        captured = {}

        def fake_poll_job(client, endpoint, **kwargs):
            captured["endpoint"] = endpoint
            captured["params"] = kwargs.get("params")
            captured["interval"] = kwargs.get("interval")
            return [{"id": "eval-1", "status": "completed", "cost_usd": 0.12}]

        monkeypatch.setattr("fluxloop_cli.sync.poller.poll_job", fake_poll_job)

        job = evaluate._wait_for_evaluation(
            object(),
            project_id="proj-1",
            experiment_id="exp-1",
            eval_id="eval-1",
            timeout=30,
            poll_interval=7,
        )

        assert job["status"] == "completed"
        assert captured["endpoint"] == "/api/evaluations/jobs"
        assert captured["params"] == {"project_id": "proj-1", "experiment_ids": "exp-1"}
        assert captured["interval"] == 7

    def test_wait_failure_exits_nonzero(self, monkeypatch):
        monkeypatch.setattr(evaluate, "get_current_web_project_id", lambda: "proj-1")
        monkeypatch.setattr(evaluate, "create_client", lambda *args, **kwargs: object())
        monkeypatch.setattr(
            evaluate,
            "post_with_retry",
            lambda client, endpoint, payload: _FakeResponse(
                {"evaluation_id": "eval-1", "status": "queued"}
            ),
        )
        monkeypatch.setattr(
            evaluate,
            "_wait_for_evaluation",
            lambda *args, **kwargs: {"id": "eval-1", "status": "failed"},
        )

        result = runner.invoke(app, ["evaluate", "--experiment-id", "exp-1", "--wait"])

        assert result.exit_code == 1
