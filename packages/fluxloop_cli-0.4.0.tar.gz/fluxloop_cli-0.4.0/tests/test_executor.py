"""Tests for RunExecutor protocol, models, and factory."""

from __future__ import annotations

import pytest

from fluxloop_cli.config.schema import RunnerConfig
from fluxloop_cli.core.executor import (
    RunContext,
    RunError,
    RunResult,
    TokenUsage,
    create_executor,
)
from fluxloop_cli.core.function_executor import FunctionExecutor
from fluxloop_cli.core.process_executor import ProcessExecutor


class TestRunResult:
    def test_success_result(self):
        result = RunResult(
            run_id="abc-123", success=True,
            output="hello", duration_ms=100,
        )
        assert result.success
        assert result.error is None
        assert result.token_usage is None

    def test_failure_result(self):
        result = RunResult(
            run_id="abc-123", success=False,
            output="", duration_ms=50,
            error=RunError(message="boom"),
        )
        assert not result.success
        assert result.error.message == "boom"

    def test_with_token_usage(self):
        result = RunResult(
            run_id="abc", success=True, output="ok", duration_ms=10,
            token_usage=TokenUsage(input_tokens=100, output_tokens=50, total_tokens=150),
        )
        assert result.token_usage.total_tokens == 150


class TestRunContext:
    def test_defaults(self):
        ctx = RunContext()
        assert ctx.iteration == 0
        assert ctx.persona is None
        assert ctx.environment_vars == {}

    def test_with_env_vars(self):
        ctx = RunContext(environment_vars={"KEY": "val"})
        assert ctx.environment_vars["KEY"] == "val"


class TestCreateExecutor:
    def test_function_executor(self):
        config = RunnerConfig(type="function", target="m:f")
        executor = create_executor(config)
        assert isinstance(executor, FunctionExecutor)

    def test_skill_executor(self):
        from fluxloop_cli.core.skill_executor import SkillExecutor

        config = RunnerConfig(type="skill", skill_path="/tmp/test.md")
        executor = create_executor(config)
        assert isinstance(executor, SkillExecutor)

    def test_process_executor(self):
        config = RunnerConfig(type="process", command=["python", "agent.py"])
        executor = create_executor(config)
        assert isinstance(executor, ProcessExecutor)
