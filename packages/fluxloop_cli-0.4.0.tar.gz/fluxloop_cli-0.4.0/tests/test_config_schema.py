"""Tests for Pydantic config schema models."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from fluxloop_cli.config.schema import (
    BudgetConfig,
    InputConfig,
    InputItem,
    RunnerConfig,
    SandboxConfig,
    SimulationConfig,
)


class TestRunnerConfig:
    def test_defaults(self):
        cfg = RunnerConfig()
        assert cfg.type == "function"
        assert cfg.target is None
        assert cfg.timeout_seconds == 300
        assert cfg.environment_vars == {}
        assert cfg.working_directory == "."

    def test_custom_values(self):
        cfg = RunnerConfig(
            type="skill",
            target="my_agent:handler",
            timeout_seconds=60,
            environment_vars={"KEY": "val"},
            working_directory="/tmp",
        )
        assert cfg.type == "skill"
        assert cfg.target == "my_agent:handler"
        assert cfg.timeout_seconds == 60
        assert cfg.environment_vars == {"KEY": "val"}

    def test_invalid_type(self):
        with pytest.raises(ValidationError):
            RunnerConfig(type="invalid")

    def test_process_fields(self):
        cfg = RunnerConfig(
            type="process",
            command=["python", "agent.py"],
            protocol="ndjson",
        )
        assert cfg.command == ["python", "agent.py"]
        assert cfg.protocol == "ndjson"


class TestInputItem:
    def test_minimal(self):
        item = InputItem(text="hello")
        assert item.text == "hello"
        assert item.metadata == {}

    def test_with_metadata(self):
        item = InputItem(text="hi", metadata={"key": "val"})
        assert item.metadata == {"key": "val"}


class TestInputConfig:
    def test_defaults(self):
        cfg = InputConfig()
        assert cfg.source == "inline"
        assert cfg.items == []

    def test_with_items(self):
        cfg = InputConfig(items=[{"text": "a"}, {"text": "b"}])
        assert len(cfg.items) == 2
        assert cfg.items[0].text == "a"


class TestSimulationConfig:
    def test_defaults(self):
        cfg = SimulationConfig()
        assert cfg.name == "experiment"
        assert cfg.iterations == 1
        assert cfg.runner.type == "function"
        assert cfg.conversation.enabled is False
        assert cfg.conversation.max_turns == 3

    def test_full_config(self):
        cfg = SimulationConfig(
            name="my-test",
            runner={"type": "function", "target": "mod:fn", "timeout_seconds": 10},
            iterations=5,
            conversation={"enabled": True, "max_turns": 4},
            input={"source": "inline", "items": [{"text": "x"}]},
        )
        assert cfg.name == "my-test"
        assert cfg.iterations == 5
        assert cfg.runner.timeout_seconds == 10
        assert cfg.conversation.enabled is True
        assert cfg.conversation.max_turns == 4
        assert len(cfg.input.items) == 1

    def test_invalid_conversation_turn_count(self):
        with pytest.raises(ValidationError):
            SimulationConfig(
                runner={"type": "function", "target": "mod:fn"},
                conversation={"enabled": True, "max_turns": 1},
            )

    def test_rejects_skill_runner_with_conversation(self):
        with pytest.raises(ValidationError):
            SimulationConfig(
                runner={"type": "skill", "skill_path": "/tmp/SKILL.md"},
                conversation={"enabled": True, "max_turns": 3},
            )

    def test_rejects_non_positive_iterations(self):
        with pytest.raises(ValidationError):
            SimulationConfig(
                runner={"type": "function", "target": "mod:fn"},
                iterations=0,
            )


# --- Phase 2: Skill config extensions ---


class TestSandboxConfig:
    def test_defaults(self):
        cfg = SandboxConfig()
        assert cfg.copy_files == []
        assert cfg.cleanup is True

    def test_custom(self):
        cfg = SandboxConfig(copy_files=["src/", "*.py"], cleanup=False)
        assert cfg.copy_files == ["src/", "*.py"]
        assert cfg.cleanup is False


class TestBudgetConfig:
    def test_defaults(self):
        cfg = BudgetConfig()
        assert cfg.max_budget_usd == 0.50

    def test_custom(self):
        cfg = BudgetConfig(max_budget_usd=2.0)
        assert cfg.max_budget_usd == 2.0


class TestRunnerConfigSkillFields:
    def test_skill_defaults(self):
        cfg = RunnerConfig(type="skill")
        assert cfg.skill_path is None
        assert cfg.harness == "claude"
        assert cfg.allowed_tools == []
        assert cfg.disallowed_tools == []
        assert cfg.skill_max_turns == 20
        assert cfg.sandbox.cleanup is True
        assert cfg.budget.max_budget_usd == 0.50

    def test_skill_custom(self):
        cfg = RunnerConfig(
            type="skill",
            skill_path="/path/to/SKILL.md",
            harness="claude",
            allowed_tools=["Write", "Read"],
            disallowed_tools=["Bash"],
            skill_max_turns=10,
            sandbox=SandboxConfig(copy_files=["src/"], cleanup=False),
            budget=BudgetConfig(max_budget_usd=1.0),
        )
        assert cfg.skill_path == "/path/to/SKILL.md"
        assert cfg.allowed_tools == ["Write", "Read"]
        assert cfg.disallowed_tools == ["Bash"]
        assert cfg.skill_max_turns == 10
        assert cfg.sandbox.copy_files == ["src/"]
        assert cfg.sandbox.cleanup is False
        assert cfg.budget.max_budget_usd == 1.0

    def test_invalid_harness(self):
        with pytest.raises(ValidationError):
            RunnerConfig(type="skill", harness="invalid")
