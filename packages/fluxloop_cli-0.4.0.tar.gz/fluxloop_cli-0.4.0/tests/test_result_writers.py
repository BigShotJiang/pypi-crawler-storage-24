"""Tests for TraceWriter and SummaryWriter + protocol schema validation."""

from __future__ import annotations

import json
from pathlib import Path

import jsonschema
import pytest

from fluxloop_cli.config.schema import SimulationConfig
from fluxloop_cli.core.executor import RunContext, RunError, RunResult, TokenUsage
from fluxloop_cli.result.error_writer import ErrorWriter
from fluxloop_cli.result.summary_writer import SummaryWriter
from fluxloop_cli.result.trace_writer import TraceWriter


from fluxloop_cli.config.schema import RunnerConfig


def _make_result(
    run_id: str = "r1", success: bool = True, output: str = "ok", duration_ms: int = 100,
    token_usage: TokenUsage | None = None, error: RunError | None = None,
    tool_calls: list | None = None, metadata: dict | None = None, **extra,
) -> RunResult:
    return RunResult(
        run_id=run_id, success=success, output=output,
        duration_ms=duration_ms, token_usage=token_usage, error=error,
        tool_calls=tool_calls or [], metadata=metadata or {}, **extra,
    )


class TestTraceWriter:
    def test_writes_jsonl(self, tmp_path):
        writer = TraceWriter(tmp_path / "output")
        ctx = RunContext(iteration=0, persona="tester", scenario="s1")
        writer.write(
            _make_result(),
            ctx,
            "input text",
            input_metadata={"id": "input-1", "persona_id": "persona-1"},
        )

        file = tmp_path / "output" / "trace_summary.jsonl"
        assert file.exists()

        record = json.loads(file.read_text().strip())
        assert record["run_id"] == "r1"
        assert record["input"] == "input text"
        assert record["input_item_id"] == "input-1"
        assert record["input_metadata"]["persona_id"] == "persona-1"
        assert record["success"] is True
        assert record["iteration"] == 0
        assert record["persona"] == "tester"
        assert "timestamp" in record

    def test_appends_multiple(self, tmp_path):
        writer = TraceWriter(tmp_path / "output")
        ctx = RunContext()
        writer.write(_make_result(run_id="r1"), ctx, "a")
        writer.write(_make_result(run_id="r2"), ctx, "b")

        file = tmp_path / "output" / "trace_summary.jsonl"
        lines = file.read_text().strip().split("\n")
        assert len(lines) == 2

    def test_with_error(self, tmp_path):
        writer = TraceWriter(tmp_path / "output")
        ctx = RunContext()
        result = _make_result(
            success=False, output="", error=RunError(message="boom"),
        )
        writer.write(result, ctx, "input")

        record = json.loads((tmp_path / "output" / "trace_summary.jsonl").read_text().strip())
        assert record["error"]["message"] == "boom"

    def test_validates_against_schema(self, tmp_path, load_schema):
        schema = load_schema("trace-summary.schema.json")
        writer = TraceWriter(tmp_path / "output")
        ctx = RunContext(iteration=1, persona="user-a")
        writer.write(
            _make_result(token_usage=TokenUsage(input_tokens=10, output_tokens=5, total_tokens=15)),
            ctx,
            "hello",
            input_metadata={"id": "input-2", "messages": [{"role": "user", "content": "hello"}]},
        )

        record = json.loads((tmp_path / "output" / "trace_summary.jsonl").read_text().strip())
        jsonschema.validate(record, schema)

    def test_writes_conversation_fields(self, tmp_path):
        writer = TraceWriter(tmp_path / "output")
        ctx = RunContext(iteration=2, persona="tester")
        writer.write(
            _make_result(
                turn_count=3,
                termination_reason="goal_completed",
                conversation=[
                    {"role": "user", "content": "hello"},
                    {"role": "assistant", "content": "hi"},
                ],
            ),
            ctx,
            "hello",
        )

        record = json.loads((tmp_path / "output" / "trace_summary.jsonl").read_text().strip())
        assert record["turn_count"] == 3
        assert record["termination_reason"] == "goal_completed"
        assert record["conversation"][0]["role"] == "user"

    def test_promotes_skill_turn_count_to_top_level(self, tmp_path):
        writer = TraceWriter(tmp_path / "output")
        ctx = RunContext()
        writer.write(
            _make_result(
                metadata={"skill_metadata": {"turn_count": 4}},
            ),
            ctx,
            "input",
        )

        record = json.loads((tmp_path / "output" / "trace_summary.jsonl").read_text().strip())
        assert record["turn_count"] == 4


class TestSummaryWriter:
    def test_writes_summary(self, tmp_path):
        config = SimulationConfig(
            name="test-exp",
            runner={"type": "function", "target": "m:f"},
        )
        results = [
            _make_result(run_id="r1", duration_ms=100),
            _make_result(run_id="r2", success=False, output="", duration_ms=50),
            _make_result(run_id="r3", duration_ms=200),
        ]

        writer = SummaryWriter()
        writer.write(tmp_path, config, results)

        summary = json.loads((tmp_path / "summary.json").read_text())
        assert summary["experiment_name"] == "test-exp"
        assert summary["runner_type"] == "function"
        assert summary["total_runs"] == 3
        assert summary["success_count"] == 2
        assert summary["failure_count"] == 1
        assert summary["success_rate"] == pytest.approx(0.6667, abs=0.001)
        assert summary["total_duration_ms"] == 350

    def test_with_tokens(self, tmp_path):
        config = SimulationConfig(name="t", runner={"type": "function", "target": "m:f"})
        results = [
            _make_result(token_usage=TokenUsage(input_tokens=10, output_tokens=5, total_tokens=15)),
            _make_result(token_usage=TokenUsage(input_tokens=20, output_tokens=10, total_tokens=30)),
        ]

        SummaryWriter().write(tmp_path, config, results)
        summary = json.loads((tmp_path / "summary.json").read_text())
        assert summary["total_tokens"] == 45

    def test_avg_turns_uses_all_runs_with_turn_count(self, tmp_path):
        config = SimulationConfig(name="turns", runner={"type": "function", "target": "m:f"})
        results = [
            _make_result(run_id="r1", turn_count=2),
            _make_result(run_id="r2", success=False, output="", turn_count=4),
            _make_result(run_id="r3"),
        ]

        SummaryWriter().write(tmp_path, config, results)
        summary = json.loads((tmp_path / "summary.json").read_text())

        assert summary["avg_turns"] == 3.0

    def test_validates_against_schema(self, tmp_path, load_schema):
        schema = load_schema("summary.schema.json")
        config = SimulationConfig(name="exp", runner={"type": "function", "target": "m:f"})
        results = [_make_result()]

        SummaryWriter().write(tmp_path, config, results)
        summary = json.loads((tmp_path / "summary.json").read_text())
        jsonschema.validate(summary, schema)


# --- Phase 2: Skill-specific fields ---


class TestTraceWriterPhase2:
    def test_tool_calls_in_trace(self, tmp_path):
        writer = TraceWriter(tmp_path / "output")
        ctx = RunContext()
        result = _make_result(
            tool_calls=[
                {"turn": 0, "tool": "Write", "input": {}, "output": "ok", "is_error": False},
                {"turn": 1, "tool": "Bash", "input": {}, "output": "done", "is_error": False},
            ],
            metadata={
                "skill_metadata": {
                    "sandbox_path": "/tmp/fluxloop-sandbox-123",
                    "turn_count": 2,
                    "total_cost_usd": 0.05,
                }
            },
        )
        writer.write(result, ctx, "test input")

        record = json.loads((tmp_path / "output" / "trace_summary.jsonl").read_text().strip())
        assert len(record["tool_calls"]) == 2
        assert record["tool_calls"][0]["tool"] == "Write"
        assert record["skill_metadata"]["turn_count"] == 2
        assert record["skill_metadata"]["total_cost_usd"] == 0.05
        assert record["skill_metadata"]["sandbox_path"] == "/tmp/fluxloop-sandbox-123"

    def test_static_results_in_trace(self, tmp_path):
        writer = TraceWriter(tmp_path / "output")
        ctx = RunContext()
        static_results = {
            "overall_pass": True,
            "error_count": 0,
            "results": [{"rule_type": "file_size", "passed": True}],
        }
        writer.write(_make_result(), ctx, "input", static_results=static_results)

        record = json.loads((tmp_path / "output" / "trace_summary.jsonl").read_text().strip())
        assert record["static_results"]["overall_pass"] is True

    def test_contract_results_in_trace(self, tmp_path):
        writer = TraceWriter(tmp_path / "output")
        ctx = RunContext()
        contract_results = {
            "overall_pass": False,
            "error_count": 1,
            "results": [{"assertion_type": "tool_called", "passed": False}],
        }
        writer.write(_make_result(), ctx, "input", contract_results=contract_results)

        record = json.loads((tmp_path / "output" / "trace_summary.jsonl").read_text().strip())
        assert record["contract_results"]["overall_pass"] is False
        assert record["contract_results"]["error_count"] == 1

    def test_none_extras_excluded(self, tmp_path):
        writer = TraceWriter(tmp_path / "output")
        ctx = RunContext()
        writer.write(_make_result(), ctx, "input")

        record = json.loads((tmp_path / "output" / "trace_summary.jsonl").read_text().strip())
        assert "static_results" not in record
        assert "contract_results" not in record
        assert "tool_calls" not in record
        assert "skill_metadata" not in record

    def test_skill_trace_validates_against_schema(self, tmp_path, load_schema):
        schema = load_schema("trace-summary.schema.json")
        writer = TraceWriter(tmp_path / "output")
        ctx = RunContext(iteration=1, scenario="skill-test")
        result = _make_result(
            token_usage=TokenUsage(input_tokens=10, output_tokens=5, total_tokens=15),
            tool_calls=[
                {
                    "turn": 0,
                    "tool": "Write",
                    "input": {"file_path": "README.md"},
                    "output": "ok",
                    "is_error": False,
                    "duration_ms": 30,
                }
            ],
            metadata={
                "skill_metadata": {
                    "skill_path": "./SKILL.md",
                    "harness": "claude",
                    "sandbox_path": "/tmp/fluxloop-sandbox-123",
                    "turn_count": 1,
                    "total_cost_usd": 0.05,
                    "files_created": ["README.md"],
                    "commands_executed": ["ls"],
                }
            },
        )
        writer.write(
            result,
            ctx,
            "input",
            input_metadata={"id": "input-3", "persona_id": "persona-3"},
            static_results={"overall_pass": True, "error_count": 0, "warning_count": 0},
            contract_results={"overall_pass": True, "error_count": 0, "warning_count": 0},
        )

        record = json.loads((tmp_path / "output" / "trace_summary.jsonl").read_text().strip())
        jsonschema.validate(record, schema)


class TestSummaryWriterPhase2:
    def test_skill_summary_stats(self, tmp_path):
        config = SimulationConfig(
            name="skill-test",
            runner=RunnerConfig(type="skill", skill_path="/tmp/SKILL.md"),
        )
        results = [
            _make_result(
                run_id="r1", duration_ms=1000,
                metadata={"skill_metadata": {"turn_count": 5, "total_cost_usd": 0.10}},
            ),
            _make_result(
                run_id="r2", duration_ms=2000,
                metadata={"skill_metadata": {"turn_count": 3, "total_cost_usd": 0.20}},
            ),
        ]

        SummaryWriter().write(tmp_path, config, results)
        summary = json.loads((tmp_path / "summary.json").read_text())

        assert summary["runner_type"] == "skill"
        assert summary["avg_duration_ms"] == 1500
        assert summary["avg_turns"] == 4.0
        assert summary["avg_cost_usd"] == pytest.approx(0.15, abs=0.001)
        assert summary["total_cost_usd"] == pytest.approx(0.30, abs=0.001)

    def test_skill_summary_no_success(self, tmp_path):
        config = SimulationConfig(
            name="skill-test",
            runner=RunnerConfig(type="skill", skill_path="/tmp/SKILL.md"),
        )
        results = [
            _make_result(run_id="r1", success=False, output="", duration_ms=100),
        ]

        SummaryWriter().write(tmp_path, config, results)
        summary = json.loads((tmp_path / "summary.json").read_text())

        assert summary["runner_type"] == "skill"
        assert summary["success_count"] == 0
        assert summary["avg_duration_ms"] == 100
        assert "avg_turns" not in summary
        assert "avg_cost_usd" not in summary
        assert "total_cost_usd" not in summary

    def test_skill_avg_duration_uses_all_runs(self, tmp_path):
        config = SimulationConfig(
            name="skill-test",
            runner=RunnerConfig(type="skill", skill_path="/tmp/SKILL.md"),
        )
        results = [
            _make_result(
                run_id="r1",
                duration_ms=1000,
                metadata={"skill_metadata": {"total_cost_usd": 0.10}},
            ),
            _make_result(run_id="r2", success=False, output="", duration_ms=3000),
        ]

        SummaryWriter().write(tmp_path, config, results)
        summary = json.loads((tmp_path / "summary.json").read_text())

        assert summary["avg_duration_ms"] == 2000
        assert summary["total_duration_ms"] == 4000

    def test_contract_summary_written(self, tmp_path, load_schema):
        config = SimulationConfig(
            name="skill-test",
            runner=RunnerConfig(type="skill", skill_path="/tmp/SKILL.md"),
        )
        results = [
            _make_result(
                run_id="r1",
                duration_ms=1000,
                metadata={"skill_metadata": {"turn_count": 2, "total_cost_usd": 0.10}},
            )
        ]

        SummaryWriter().write(
            tmp_path,
            config,
            results,
            contract_summary={
                "overall_pass_rate": 1.0,
                "assertion_pass_rates": {"file_exists": 1.0},
            },
        )
        summary = json.loads((tmp_path / "summary.json").read_text())
        assert summary["contract_summary"]["overall_pass_rate"] == 1.0

        schema = load_schema("summary.schema.json")
        jsonschema.validate(summary, schema)


class TestErrorWriter:
    def test_writes_execution_failures(self, tmp_path, load_schema):
        output_dir = tmp_path / "output"
        trace_writer = TraceWriter(output_dir)
        failure_result = _make_result(
            run_id="r-fail",
            success=False,
            output="",
            duration_ms=250,
            error=RunError(message="boom", traceback="Traceback..."),
        )
        trace_writer.write(
            _make_result(run_id="r-ok"),
            RunContext(iteration=0, persona="p1"),
            "safe input",
        )
        trace_writer.write(
            failure_result,
            RunContext(iteration=1, persona="p2"),
            "bad input",
        )

        config = SimulationConfig(
            name="error-test",
            runner={"type": "function", "target": "m:f"},
        )
        ErrorWriter().write(output_dir, config)

        payload = json.loads((output_dir / "errors.json").read_text())
        assert payload["experiment_name"] == "error-test"
        assert payload["failure_count"] == 1
        assert payload["failures"][0]["run_id"] == "r-fail"
        assert payload["failures"][0]["persona"] == "p2"
        assert payload["failures"][0]["error"]["message"] == "boom"

        schema = load_schema("errors.schema.json")
        jsonschema.validate(payload, schema)

    def test_writes_empty_failures_when_trace_missing(self, tmp_path):
        config = SimulationConfig(
            name="empty-errors",
            runner={"type": "function", "target": "m:f"},
        )
        ErrorWriter().write(tmp_path / "output", config)

        payload = json.loads((tmp_path / "output" / "errors.json").read_text())
        assert payload["failure_count"] == 0
        assert payload["failures"] == []

    def test_skips_malformed_trace_lines_with_warning(self, tmp_path, caplog):
        output_dir = tmp_path / "output"
        output_dir.mkdir()
        trace_path = output_dir / "trace_summary.jsonl"
        trace_path.write_text(
            "\n".join(
                [
                    json.dumps(
                        {
                            "run_id": "r-fail",
                            "success": False,
                            "iteration": 1,
                            "persona": "p2",
                            "input": "bad input",
                            "duration_ms": 250,
                            "timestamp": "2026-03-09T00:00:00+00:00",
                            "error": {"message": "boom"},
                        }
                    ),
                    "{not-json",
                ]
            )
        )
        config = SimulationConfig(
            name="warn-errors",
            runner={"type": "function", "target": "m:f"},
        )

        with caplog.at_level("WARNING"):
            ErrorWriter().write(output_dir, config)

        payload = json.loads((output_dir / "errors.json").read_text())
        assert payload["failure_count"] == 1
        assert payload["failures"][0]["run_id"] == "r-fail"
        assert "Skipping malformed trace record" in caplog.text
