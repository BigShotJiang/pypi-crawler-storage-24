"""Tests for ObShare CLI"""
