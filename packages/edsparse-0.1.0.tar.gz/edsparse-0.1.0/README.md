# edsParse

**Greetings!** Guys! Today it would be my pleasure to introduce to my new creation...
***The*** `edsParse`. Well... I know, I know, Sounds like... *"Who the heck is that... __edsParse__?"*
****************************************************************************************************

> So, `edsParse` is a Python Library which helps you to parse **EDS** files.
> EDS - Evaluable Data Set

**Yes!** *You heard it right.* It is almost like `JSON` but way more advanced than it.
Also, it removes the headache of those old boring fashioned braces/curly-bush brackets.

## Comparision

|   | EDS | JSON |
| --- | --- | --- |
| *__Arithmetics__* | Supported | Not Supported |
| *__Comments__* | Supported | Not Supported |
| *__Readability__* | Clean to Read & Write | Clean to Read but can be a bit messy to write |
| *__Quotes__* | Depends on DataType | Mandatory |
| *__Ecosystem__* | Brand New | 20+ Years of Tools |
| *__Language Support__* | Python Only (for now) | Every Language |
| *__IDE Support__* | Not Yet | Full Support |
| *__Strictness__* | Flexible | Strict & Predictable |
| *__Speed__* | To be Benchmarked | Hyper Optimized |
| *__Community__* | Growing | Massive |
| *__Spec Maturity__* | Still Evolving | Rock Solid RFC Standard |
| *__Expression Storage__* | Stored As-Is | Must be Pre-Computed |