from edsParse import Open

__author__ = "Swastik Bachhar"
__year__ = "2026"
__description__ = "A parser for EDS - Evaluable Data Set"

__all__ = ['Open']