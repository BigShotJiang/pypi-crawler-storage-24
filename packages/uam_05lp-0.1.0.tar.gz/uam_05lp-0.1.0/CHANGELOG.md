# Changelog

## 0.1.0 (2026-03-19)

- Initial release
- UAM protocol support (not SCIP)
- TCP/Ethernet and Serial/USB transports
- Handshake and continuous measurement modes
- Safety data, status, area, detection log commands
