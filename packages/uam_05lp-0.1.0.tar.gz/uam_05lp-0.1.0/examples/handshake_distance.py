#!/usr/bin/env python3
"""AR00 — Get a single distance scan (handshake mode, 1081 steps)."""

import sys

from uam_05lp import UAM05LP, DistanceValue

host = sys.argv[1] if len(sys.argv) > 1 else "192.168.0.10"

with UAM05LP(host) as sensor:
    scan = sensor.get_distance()

    sd = scan.safety
    print(f"Area: {sd.area_number}  Error: {sd.error_detected}  "
          f"Lockout: {sd.lockout}")
    print(f"OSSD1: {sd.ossd1}  OSSD2: {sd.ossd2}  "
          f"Warning1: {sd.warning1}  Warning2: {sd.warning2}")
    print(f"Timestamp: {sd.timestamp}")
    print()

    front = scan.distances[540]
    if front == DistanceValue.NO_DETECTION:
        print("Front-center: no detection")
    elif front == DistanceValue.ERROR:
        print("Front-center: measurement error")
    else:
        print(f"Front-center: {front} mm")

    print(f"Total steps: {len(scan.distances)}")
