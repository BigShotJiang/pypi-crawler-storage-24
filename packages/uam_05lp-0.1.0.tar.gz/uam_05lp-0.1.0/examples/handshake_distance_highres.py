#!/usr/bin/env python3
"""AR06 — Get a single high-resolution distance scan (handshake mode, 2161 steps)."""

import sys

from uam_05lp import UAM05LP

host = sys.argv[1] if len(sys.argv) > 1 else "192.168.0.10"

with UAM05LP(host) as sensor:
    scan = sensor.get_distance_highres()

    sd = scan.safety
    print(f"Area: {sd.area_number}  Timestamp: {sd.timestamp}")
    print()

    print(f"Steps (high-res): {len(scan.distances)}")
    # Center step for high-res is 1080
    print(f"Front-center distance: {scan.distances[1080]} mm")
