#!/usr/bin/env python3
"""Query and display extended sensor status."""

import sys

from uam_05lp import UAM05LP

host = sys.argv[1] if len(sys.argv) > 1 else "192.168.0.10"

with UAM05LP(host) as sensor:
    status = sensor.get_status()
    print(f"Mode: {'SETTING' if status.operating_mode else 'NORMAL'}")
    print(f"Area: {status.area_number}")
    print(f"Error: {status.error_detected} (code=0x{status.error_code:02X})")
    print(f"Lockout: {status.lockout}")
    print(f"Laser off: {status.laser_off}")
    print(f"Window contamination: {status.optical_window_contamination}")
    print()
    for i, slave in enumerate([status.slave1, status.slave2, status.slave3], 1):
        print(f"Slave {i}: OSSD12={slave.ossd12_on} OSSD34={slave.ossd34_on} "
              f"Error={slave.error_detected} Laser={slave.laser_off}")
