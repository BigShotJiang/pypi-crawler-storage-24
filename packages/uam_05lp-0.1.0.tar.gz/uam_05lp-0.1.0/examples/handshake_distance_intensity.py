#!/usr/bin/env python3
"""AR01 — Get a single distance + intensity scan (handshake mode, 1081 steps)."""

import sys

from uam_05lp import UAM05LP

host = sys.argv[1] if len(sys.argv) > 1 else "192.168.0.10"

with UAM05LP(host) as sensor:
    scan = sensor.get_distance_intensity()

    sd = scan.safety
    print(f"Area: {sd.area_number}  Timestamp: {sd.timestamp}")
    print()

    print(f"Steps: {len(scan.distances)}")
    assert scan.intensities is not None
    print(f"Front-center distance:  {scan.distances[540]} mm")
    print(f"Front-center intensity: {scan.intensities[540]}")
