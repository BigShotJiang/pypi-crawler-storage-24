#!/usr/bin/env python3
"""Query and display sensor version information."""

import sys

from uam_05lp import UAM05LP

host = sys.argv[1] if len(sys.argv) > 1 else "192.168.0.10"

with UAM05LP(host) as sensor:
    version = sensor.get_version()
    print(f"Product:  {version.product_type}")
    print(f"Firmware: {version.firmware_version}")
    print(f"Serial:   {version.serial_number}")
