#!/usr/bin/env python3
"""AR07/AR08 — Continuous high-res distance scanning (2161 steps, Ctrl+C to stop)."""

import signal
import sys

from uam_05lp import UAM05LP

host = sys.argv[1] if len(sys.argv) > 1 else "192.168.0.10"
running = True


def on_signal(signum: int, frame: object) -> None:
    global running  # noqa: PLW0603
    running = False
    print("\nStopping...")


signal.signal(signal.SIGINT, on_signal)

with UAM05LP(host) as sensor:
    print("Starting continuous high-res distance scan (Ctrl+C to stop)...")
    count = 0

    with sensor.iter_distance_highres() as stream:
        for scan in stream:
            count += 1
            front = scan.distances[1080]
            print(
                f"[{count:5d}] Area={scan.safety.area_number} "
                f"Front={front:5d}mm "
                f"Steps={len(scan.distances)} "
                f"Timestamp={scan.safety.timestamp}"
            )
            if not running:
                break

    print(f"Received {count} scans.")
