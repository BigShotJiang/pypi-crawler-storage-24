#!/usr/bin/env python3
"""Retrieve and display the error log."""

import sys

from uam_05lp import UAM05LP

host = sys.argv[1] if len(sys.argv) > 1 else "192.168.0.10"

with UAM05LP(host) as sensor:
    error_log = sensor.get_error_log()

    print("RAM errors:")
    if error_log.ram_errors:
        for code in error_log.ram_errors:
            print(f"  0x{code:02X}")
    else:
        print("  (none)")

    print("ROM errors:")
    if error_log.rom_errors:
        for code in error_log.rom_errors:
            print(f"  0x{code:02X}")
    else:
        print("  (none)")
