#!/usr/bin/env python3
"""AR04/AR05 — Continuous distance + intensity scanning (1081 steps, Ctrl+C to stop)."""

import signal
import sys

from uam_05lp import UAM05LP

host = sys.argv[1] if len(sys.argv) > 1 else "192.168.0.10"
running = True


def on_signal(signum: int, frame: object) -> None:
    global running  # noqa: PLW0603
    running = False
    print("\nStopping...")


signal.signal(signal.SIGINT, on_signal)

with UAM05LP(host) as sensor:
    print("Starting continuous distance+intensity scan (Ctrl+C to stop)...")
    count = 0

    with sensor.iter_distance_intensity() as stream:
        for scan in stream:
            count += 1
            front_dist = scan.distances[540]
            front_int = scan.intensities[540] if scan.intensities else 0
            print(
                f"[{count:5d}] Area={scan.safety.area_number} "
                f"Front={front_dist:5d}mm "
                f"Intensity={front_int:5d} "
                f"Timestamp={scan.safety.timestamp}"
            )
            if not running:
                break

    print(f"Received {count} scans.")
