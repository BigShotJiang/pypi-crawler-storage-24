"""Tests for TcpTransport using a mock TCP server."""

from __future__ import annotations

import builtins
import socket
import threading
import time

import pytest

from uam_05lp._constants import ETX, STX
from uam_05lp.exceptions import ConnectionError, TimeoutError
from uam_05lp.transport import TcpTransport


def _find_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class MockTcpServer:
    """Simple TCP server for testing."""

    def __init__(self, port: int) -> None:
        self.port = port
        self._server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._server.bind(("127.0.0.1", port))
        self._server.listen(1)
        self._client: socket.socket | None = None
        self._thread: threading.Thread | None = None
        self._responses: list[bytes] = []
        self._received: list[bytes] = []
        self._ready = threading.Event()

    def start(self) -> None:
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        self._ready.wait(timeout=2)

    def _run(self) -> None:
        self._ready.set()
        self._server.settimeout(5)
        try:
            self._client, _ = self._server.accept()
            self._client.settimeout(2)

            # Read from client
            try:
                data = self._client.recv(4096)
                if data:
                    self._received.append(data)
            except builtins.TimeoutError:
                pass

            # Send queued responses
            for resp in self._responses:
                self._client.send(resp)
                time.sleep(0.01)

        except builtins.TimeoutError:
            pass

    def queue_response(self, data: bytes) -> None:
        self._responses.append(data)

    def close(self) -> None:
        import contextlib

        if self._client:
            with contextlib.suppress(OSError):
                self._client.close()
        self._server.close()


class TestTcpTransport:
    def test_connect_and_close(self) -> None:
        port = _find_free_port()
        server = MockTcpServer(port)
        server.start()
        try:
            transport = TcpTransport("127.0.0.1", port)
            transport.open()
            assert transport.is_open
            transport.close()
            assert not transport.is_open
        finally:
            server.close()

    def test_connect_failure(self) -> None:
        transport = TcpTransport("127.0.0.1", 1, connect_timeout_s=0.5)
        with pytest.raises(ConnectionError):
            transport.open()

    def test_send_and_receive_frame(self) -> None:
        port = _find_free_port()
        server = MockTcpServer(port)
        # Queue a response frame
        frame = bytes([STX]) + b"000EVR0000ABCD" + bytes([ETX])
        server.queue_response(frame)
        server.start()
        try:
            transport = TcpTransport("127.0.0.1", port)
            transport.open()
            transport.send(b"test command")
            # Give server time to process
            time.sleep(0.1)
            received = transport.receive_frame(timeout_ms=2000)
            # Should have STX but not ETX
            assert received[0] == STX
            assert ETX not in received
            transport.close()
        finally:
            server.close()

    def test_receive_timeout(self) -> None:
        port = _find_free_port()
        server = MockTcpServer(port)
        server.start()
        try:
            transport = TcpTransport("127.0.0.1", port)
            transport.open()
            with pytest.raises(TimeoutError):
                transport.receive_frame(timeout_ms=200)
            transport.close()
        finally:
            server.close()
