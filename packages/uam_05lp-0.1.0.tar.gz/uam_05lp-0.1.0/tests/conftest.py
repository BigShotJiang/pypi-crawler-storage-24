"""Shared test fixtures and MockTransport."""

from __future__ import annotations

from collections import deque

import pytest

from uam_05lp._constants import STX
from uam_05lp._crc import compute_crc
from uam_05lp.transport import Transport


class MockTransport(Transport):
    """In-memory transport for unit testing.

    Queue response frames with :meth:`queue_response` or
    :meth:`queue_raw_frame` before calling client methods.
    Sent data is captured in :attr:`sent_data`.
    """

    def __init__(self) -> None:
        self._open = False
        self.sent_data: list[bytes] = []
        self._responses: deque[bytes] = deque()

    def open(self) -> None:
        self._open = True

    def close(self) -> None:
        self._open = False

    def send(self, data: bytes) -> int:
        self.sent_data.append(data)
        return len(data)

    def receive_frame(self, timeout_ms: int) -> bytes:
        if not self._responses:
            from uam_05lp.exceptions import TimeoutError

            raise TimeoutError("No response queued")
        return self._responses.popleft()

    @property
    def is_open(self) -> bool:
        return self._open

    def queue_raw_frame(self, frame: bytes) -> None:
        """Queue a raw frame (STX included, ETX excluded) for receive."""
        self._responses.append(frame)

    def queue_response(
        self,
        header: str,
        subheader: str,
        data: str = "",
        status: str = "00",
    ) -> None:
        """Build and queue a properly framed response.

        The frame format matches the real protocol::

            STX + Length(4) + Header(2) + SubHeader(2) + Status(2)
            + Data + CRC(4) + ETX

        Status is placed **right after** the SubHeader, before any data.
        """
        # Protocol: Header + SubHeader + Status + Data
        body = header + subheader + status + data
        length = 1 + 4 + len(body) + 4 + 1  # STX + len + body + CRC + ETX
        length_str = f"{length:04X}"
        crc_payload = (length_str + body).encode("ascii")
        crc = compute_crc(crc_payload)
        crc_str = f"{crc:04X}"
        frame = bytes([STX]) + f"{length_str}{body}{crc_str}".encode("ascii")
        self._responses.append(frame)


@pytest.fixture
def mock_transport() -> MockTransport:
    """Provide a fresh MockTransport instance."""
    transport = MockTransport()
    transport.open()
    return transport
