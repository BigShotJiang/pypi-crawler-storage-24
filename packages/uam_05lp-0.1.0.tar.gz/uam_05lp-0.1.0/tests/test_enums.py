"""Tests for enumerations."""

from uam_05lp.enums import AreaType, DistanceValue, OperatingMode, ReplyStatus


class TestOperatingMode:
    def test_values(self) -> None:
        assert OperatingMode.NORMAL == 0
        assert OperatingMode.SETTING == 1


class TestAreaType:
    def test_protection_values(self) -> None:
        assert AreaType.PROTECTION_1 == 0
        assert AreaType.PROTECTION_2 == 1
        assert AreaType.WARNING_1 == 2
        assert AreaType.WARNING_2 == 3

    def test_reference_min(self) -> None:
        assert AreaType.REFERENCE_MIN == 8


class TestDistanceValue:
    def test_special_values(self) -> None:
        assert DistanceValue.ERROR == 0xFFFF
        assert DistanceValue.NO_DETECTION == 0xFFFE
        assert DistanceValue.TOO_CLOSE == 0xFFFD
        assert DistanceValue.LASER_OFF == 0xFFFC


class TestReplyStatus:
    def test_ok(self) -> None:
        assert ReplyStatus.OK == 0x00

    def test_error_codes(self) -> None:
        assert ReplyStatus.SIZE_ERROR == 0x12
        assert ReplyStatus.UNDEFINED_COMMAND == 0x20
        assert ReplyStatus.BUSY == 0x31
