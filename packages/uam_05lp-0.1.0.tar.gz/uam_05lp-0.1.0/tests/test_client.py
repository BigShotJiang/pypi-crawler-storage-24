"""Tests for the UAM05LP client using MockTransport."""

from __future__ import annotations

import pytest
from tests.conftest import MockTransport

from uam_05lp import UAM05LP
from uam_05lp._constants import (
    SAFETY_RESERVED_LENGTH,
    STANDARD_STEPS,
)
from uam_05lp.exceptions import SensorError


def _make_safety_data_str() -> str:
    """Build a 33-char safety data string for testing."""
    return (
        "0"           # operating_mode = NORMAL
        "01"          # area_number = 1
        "0"           # error_detected = False
        "00"          # error_code = 0
        "0"           # lockout = False
        "11"          # ossd1=True, ossd2=True
        "00"          # warning1=False, warning2=False
        "11"          # ossd3=True, ossd4=True
        "00"          # reserved
        "00"          # muting_override1=False, muting_override2=False
        "00"          # reset_request1=False, reset_request2=False
        "0000"        # encoder_speed = 0
        "00000000"    # timestamp = 0
        "0"           # laser_off = False
        "0"           # contamination = False
    )


class TestUAM05LPConnection:
    def test_open_close(self, mock_transport: MockTransport) -> None:
        sensor = UAM05LP(transport=mock_transport)
        assert sensor.is_connected
        sensor.close()

    def test_context_manager(self, mock_transport: MockTransport) -> None:
        with UAM05LP(transport=mock_transport) as sensor:
            assert sensor.is_connected
        # After exiting context, transport should be closed
        assert not mock_transport.is_open


class TestGetVersion:
    def test_get_version(self, mock_transport: MockTransport) -> None:
        # Build VR00 response with product type, firmware, serial
        # Based on C code analysis:
        # Product type at data offset 0, space-terminated
        # Firmware at data offset 30, space-terminated
        # Serial at data offset 98, 8 chars
        product = "UAM-05LP"
        # Pad to offset 30
        data_str = product + " " + "X" * (30 - len(product) - 1)
        firmware = "2.4.0"
        # Pad to offset 98
        data_str += firmware + " " + "Y" * (98 - 30 - len(firmware) - 1)
        serial = "H1234567"
        data_str += serial

        mock_transport.queue_response("VR", "00", data_str)

        sensor = UAM05LP(transport=mock_transport)
        version = sensor.get_version()
        assert version.product_type == "UAM-05LP"
        assert version.firmware_version == "2.4.0"
        assert version.serial_number == "H1234567"


class TestGetDistance:
    def test_get_distance_basic(self, mock_transport: MockTransport) -> None:
        safety = _make_safety_data_str()
        reserved = "0" * SAFETY_RESERVED_LENGTH
        distances = "03E8" * STANDARD_STEPS  # 1000mm for all steps
        data = safety + reserved + distances

        mock_transport.queue_response("AR", "00", data)

        sensor = UAM05LP(transport=mock_transport)
        scan = sensor.get_distance()
        assert len(scan.distances) == STANDARD_STEPS
        assert scan.distances[0] == 1000
        assert scan.distances[540] == 1000
        assert scan.safety.area_number == 2  # protocol 0x01 + offset 1
        assert scan.safety.ossd1 is True
        assert scan.intensities is None

    def test_get_distance_intensity(self, mock_transport: MockTransport) -> None:
        safety = _make_safety_data_str()
        reserved = "0" * SAFETY_RESERVED_LENGTH
        distances = "03E8" * STANDARD_STEPS
        intensities = "0064" * STANDARD_STEPS  # intensity=100
        data = safety + reserved + distances + intensities

        mock_transport.queue_response("AR", "01", data)

        sensor = UAM05LP(transport=mock_transport)
        scan = sensor.get_distance_intensity()
        assert len(scan.distances) == STANDARD_STEPS
        assert scan.intensities is not None
        assert len(scan.intensities) == STANDARD_STEPS
        assert scan.intensities[0] == 100


class TestGetStatus:
    def test_get_status(self, mock_transport: MockTransport) -> None:
        data = (
            "0"           # operating_mode
            "01"          # area_number
            "0"           # error_detected
            "00"          # error_code
            "0"           # lockout
            "11"          # ossd1, ossd2
            "00"          # warning1, warning2
            "11"          # ossd3, ossd4
            "00"          # reserved
            "00"          # muting_override1, muting_override2
            "00"          # reset_request1, reset_request2
            "0000"        # encoder_speed
            "0"           # laser_off
            "100"         # slave1-3 ossd12
            "000"         # slave1-3 ossd34
            "000"         # slave1-3 warning1
            "000"         # slave1-3 warning2
            "000"         # slave1-3 error
            "000"         # slave1-3 laser_off
            "ABCDEF01"    # timestamp
            "0"           # contamination
        )
        mock_transport.queue_response("XR", "00", data)

        sensor = UAM05LP(transport=mock_transport)
        status = sensor.get_status()
        assert status.area_number == 2  # protocol 0x01 + offset 1
        assert status.slave1.ossd12_on is True
        assert status.slave2.ossd12_on is False
        assert status.timestamp == 0xABCDEF01


class TestGetArea:
    def test_get_area(self, mock_transport: MockTransport) -> None:
        # YR response echoes start_step(4) + end_step(4) + grouping(2) +
        # area_number(2) = 12 chars before the actual area distances.
        echo = "000004380100"  # start=0, end=1080, grouping=1, area=0
        area_data = "006400C80190"  # 100, 200, 400
        mock_transport.queue_response("YR", "00", echo + area_data)

        sensor = UAM05LP(transport=mock_transport)
        result = sensor.get_area(area_type=0, area_number=0)
        assert result == [100, 200, 400]


class TestGetDetectionLog:
    def test_get_detection_log(self, mock_transport: MockTransport) -> None:
        entry = (
            "0005"        # io: area=5
            "00C8"        # p1_min_dist = 200
            "021C"        # p1_min_step = 540
            "0064"        # p2_min_dist = 100
            "0100"        # p2_min_step = 256
            + "0000" * 9  # slave IOs + reserved
            + "AABBCCDD"  # timestamp
        )
        data = entry + "0" * 64 * 29
        mock_transport.queue_response("DL", "00", data)

        sensor = UAM05LP(transport=mock_transport)
        log = sensor.get_detection_log()
        assert len(log) == 30
        assert log[0].io.area_number == 6  # protocol 5 + offset 1
        assert log[0].protection1_min_dist == 200


class TestClearDetectionLog:
    def test_clear_detection_log(self, mock_transport: MockTransport) -> None:
        mock_transport.queue_response("DC", "00")
        sensor = UAM05LP(transport=mock_transport)
        sensor.clear_detection_log()  # Should not raise


class TestGetErrorLog:
    def test_get_error_log(self, mock_transport: MockTransport) -> None:
        ram = "0003" + "0000" * 63
        rom = "0000" * 64
        mock_transport.queue_response("ER", "01", ram + rom)

        sensor = UAM05LP(transport=mock_transport)
        error_log = sensor.get_error_log()
        assert error_log.ram_errors == (0x03 + 0x40,)
        assert error_log.rom_errors == ()


class TestClearErrorLog:
    def test_clear_error_log(self, mock_transport: MockTransport) -> None:
        mock_transport.queue_response("EC", "00")
        sensor = UAM05LP(transport=mock_transport)
        sensor.clear_error_log()  # Should not raise


class TestGetConfigId:
    def test_get_config_id(self, mock_transport: MockTransport) -> None:
        mock_transport.queue_response("ID", "00", "1234567890ABCDEF")
        sensor = UAM05LP(transport=mock_transport)
        cid = sensor.get_config_id()
        assert cid.id1 == "12345678"
        assert cid.id2 == "90ABCDEF"


class TestSensorError:
    def test_error_status_raises(self, mock_transport: MockTransport) -> None:
        mock_transport.queue_response("VR", "00", "", status="12")
        sensor = UAM05LP(transport=mock_transport)
        with pytest.raises(SensorError) as exc_info:
            sensor.get_version()
        assert exc_info.value.status_code == 0x12


class TestSendCommand:
    def test_raw_command(self, mock_transport: MockTransport) -> None:
        mock_transport.queue_response("VR", "00", "hello")
        sensor = UAM05LP(transport=mock_transport)
        result = sensor.send_command("VR", "00")
        assert "hello" in result
