"""Tests for data models."""

from uam_05lp.models import (
    ConfigId,
    DetectionLogIO,
    SafetyData,
    ScanData,
    SlaveDeviceState,
    VersionInfo,
)


class TestModelsAreFrozen:
    def test_safety_data_is_frozen(self) -> None:
        sd = SafetyData(
            operating_mode=0, area_number=0, error_detected=False,
            error_code=0, lockout=False, ossd1=True, ossd2=True,
            warning1=False, warning2=False, ossd3=True, ossd4=True,
            muting_override1=False,
            muting_override2=False, reset_request1=False, reset_request2=False,
            encoder_speed=0, timestamp=0, laser_off=False,
            optical_window_contamination=False,
        )
        import dataclasses
        assert dataclasses.fields(sd)  # Has fields
        import pytest

        with pytest.raises(dataclasses.FrozenInstanceError):
            sd.area_number = 5  # type: ignore[misc]

    def test_version_info(self) -> None:
        vi = VersionInfo(
            product_type="UAM-05LP",
            firmware_version="2.4.0",
            serial_number="12345678",
        )
        assert vi.product_type == "UAM-05LP"

    def test_scan_data_defaults(self) -> None:
        sd = SafetyData(
            operating_mode=0, area_number=0, error_detected=False,
            error_code=0, lockout=False, ossd1=True, ossd2=True,
            warning1=False, warning2=False, ossd3=True, ossd4=True,
            muting_override1=False,
            muting_override2=False, reset_request1=False, reset_request2=False,
            encoder_speed=0, timestamp=0, laser_off=False,
            optical_window_contamination=False,
        )
        scan = ScanData(safety=sd, distances=(100, 200, 300))
        assert scan.intensities is None

    def test_slave_device_state(self) -> None:
        s = SlaveDeviceState(
            ossd12_on=True, ossd34_on=False, warning1_on=False,
            warning2_on=False, error_detected=False, laser_off=False,
        )
        assert s.ossd12_on is True

    def test_config_id(self) -> None:
        cid = ConfigId(id1="ABCD1234", id2="EFGH5678")
        assert cid.id1 == "ABCD1234"

    def test_detection_log_io(self) -> None:
        io = DetectionLogIO(
            area_number=5, protection1_state=True, protection2_state=False,
        )
        assert io.area_number == 5
