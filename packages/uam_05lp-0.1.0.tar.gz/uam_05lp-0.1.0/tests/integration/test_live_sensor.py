"""Integration tests against real UAM-05LP hardware.

Run with: UAM_SENSOR_HOST=192.168.0.10 pytest tests/integration/ -m integration
"""

from __future__ import annotations

import pytest

from uam_05lp import UAM05LP
from uam_05lp._constants import STANDARD_STEPS


@pytest.mark.integration
class TestLiveSensor:
    def test_get_version(self, sensor: UAM05LP) -> None:
        version = sensor.get_version()
        assert len(version.product_type) > 0
        assert len(version.firmware_version) > 0
        assert len(version.serial_number) > 0

    def test_get_distance(self, sensor: UAM05LP) -> None:
        scan = sensor.get_distance()
        assert len(scan.distances) == STANDARD_STEPS
        assert scan.safety is not None

    def test_get_distance_intensity(self, sensor: UAM05LP) -> None:
        scan = sensor.get_distance_intensity()
        assert len(scan.distances) == STANDARD_STEPS
        assert scan.intensities is not None
        assert len(scan.intensities) == STANDARD_STEPS

    def test_get_status(self, sensor: UAM05LP) -> None:
        status = sensor.get_status()
        assert status.operating_mode in (0, 1)

    def test_continuous_distance(self, sensor: UAM05LP) -> None:
        count = 0
        with sensor.iter_distance() as stream:
            for scan in stream:
                assert len(scan.distances) == STANDARD_STEPS
                count += 1
                if count >= 5:
                    break
        assert count == 5

    def test_get_detection_log(self, sensor: UAM05LP) -> None:
        log = sensor.get_detection_log()
        assert isinstance(log, list)
        assert len(log) == 30
