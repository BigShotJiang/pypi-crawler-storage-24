"""Integration test fixtures for real sensor hardware."""

from __future__ import annotations

import os

import pytest

from uam_05lp import UAM05LP


def pytest_collection_modifyitems(
    config: pytest.Config,
    items: list[pytest.Item],
) -> None:
    """Skip integration tests unless UAM_SENSOR_HOST is set."""
    skip = pytest.mark.skip(
        reason="Set UAM_SENSOR_HOST to run integration tests",
    )
    for item in items:
        if "integration" in item.keywords and not os.environ.get(
            "UAM_SENSOR_HOST",
        ):
            item.add_marker(skip)


@pytest.fixture
def sensor() -> UAM05LP:
    """Provide a connected UAM05LP sensor instance."""
    host = os.environ.get("UAM_SENSOR_HOST", "192.168.0.10")
    port = int(os.environ.get("UAM_SENSOR_PORT", "10940"))
    s = UAM05LP(host, port, timeout_s=3.0)
    s.open()
    yield s  # type: ignore[misc]
    s.close()
