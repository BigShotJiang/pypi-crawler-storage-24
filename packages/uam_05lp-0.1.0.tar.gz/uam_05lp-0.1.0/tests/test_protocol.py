"""Tests for frame building, parsing, and data parsers."""

from __future__ import annotations

import pytest

from uam_05lp._constants import STX
from uam_05lp._crc import compute_crc
from uam_05lp._protocol import (
    build_frame,
    check_status,
    parse_area_reply,
    parse_config_id,
    parse_detection_log,
    parse_distance_data,
    parse_error_log,
    parse_frame,
    parse_safety_data,
    parse_status_data,
)
from uam_05lp.exceptions import CRCError, FrameError, SensorError


class TestBuildFrame:
    def test_vr00_command(self) -> None:
        """VR00 command should produce a 14-byte frame."""
        frame = build_frame("VR", "00")
        assert len(frame) == 14
        assert frame[0] == STX

    def test_frame_contains_command(self) -> None:
        frame = build_frame("AR", "00")
        frame_str = frame[1:-1].decode("ascii")
        assert "AR00" in frame_str

    def test_crc_is_valid(self) -> None:
        """Built response frame should pass CRC validation."""
        # Build a proper response frame (with status after subheader)
        body = "VR00" + "00"  # command + status
        length = 1 + 4 + len(body) + 4 + 1
        length_str = f"{length:04X}"
        crc = compute_crc((length_str + body).encode("ascii"))
        raw = bytes([STX]) + f"{length_str}{body}{crc:04X}".encode("ascii")
        parsed = parse_frame(raw)
        assert parsed.header == "VR"
        assert parsed.subheader == "00"
        assert parsed.status == "00"

    def test_vr00_crc_matches_spec(self) -> None:
        """The CRC in a VR00 command should be 0x3492."""
        frame = build_frame("VR", "00")
        frame_str = frame[1:-1].decode("ascii")
        crc_field = frame_str[-4:]
        assert crc_field == "3492", f"Expected '3492', got '{crc_field}'"

    def test_frame_with_data(self) -> None:
        frame = build_frame("YR", "00", "01000004380001")
        frame_str = frame[1:-1].decode("ascii")
        assert "01000004380001" in frame_str

    def test_ar00_length_is_14(self) -> None:
        frame = build_frame("AR", "00")
        assert len(frame) == 14


class TestParseFrame:
    def _make_response(
        self, header: str, subheader: str, data: str = "", status: str = "00"
    ) -> bytes:
        """Build a response with Status right after SubHeader (correct protocol)."""
        body = header + subheader + status + data
        length = 1 + 4 + len(body) + 4 + 1
        length_str = f"{length:04X}"
        crc_payload = (length_str + body).encode("ascii")
        crc = compute_crc(crc_payload)
        crc_str = f"{crc:04X}"
        return bytes([STX]) + f"{length_str}{body}{crc_str}".encode("ascii")

    def test_parse_simple_response(self) -> None:
        raw = self._make_response("VR", "00", "somedata")
        parsed = parse_frame(raw)
        assert parsed.header == "VR"
        assert parsed.subheader == "00"
        assert parsed.status == "00"
        assert parsed.data == "somedata"

    def test_status_position(self) -> None:
        """Status must be extracted from right after SubHeader, not end."""
        raw = self._make_response("DC", "00", "", status="00")
        parsed = parse_frame(raw)
        assert parsed.status == "00"
        assert parsed.data == ""

    def test_error_status(self) -> None:
        """Non-00 status at the correct position."""
        raw = self._make_response("AR", "00", "", status="12")
        parsed = parse_frame(raw)
        assert parsed.status == "12"

    def test_crc_mismatch_raises(self) -> None:
        raw = self._make_response("VR", "00")
        corrupted = raw[:-4] + b"FFFF"
        with pytest.raises(CRCError):
            parse_frame(corrupted)

    def test_too_short_raises(self) -> None:
        with pytest.raises(FrameError, match="too short"):
            parse_frame(b"\x02ABC")

    def test_wrong_stx_raises(self) -> None:
        with pytest.raises(FrameError, match="STX"):
            parse_frame(b"\x00" + b"0" * 14)

    def test_roundtrip(self) -> None:
        raw = self._make_response("DL", "00", "testdata")
        parsed = parse_frame(raw)
        assert parsed.header == "DL"
        assert parsed.subheader == "00"
        assert parsed.data == "testdata"

    def test_stop_response(self) -> None:
        """AR03 stop response has no data, just status."""
        raw = self._make_response("AR", "03", "", "00")
        parsed = parse_frame(raw)
        assert parsed.header == "AR"
        assert parsed.subheader == "03"
        assert parsed.status == "00"
        assert parsed.data == ""


class TestCheckStatus:
    def _make_parsed(self, status: str) -> object:
        from uam_05lp._protocol import ParsedFrame

        return ParsedFrame(header="VR", subheader="00", data="", status=status)

    def test_ok_status(self) -> None:
        check_status(self._make_parsed("00"))

    def test_error_status_raises(self) -> None:
        with pytest.raises(SensorError) as exc_info:
            check_status(self._make_parsed("12"))
        assert exc_info.value.status_code == 0x12


class TestParseSafetyData:
    def test_parse_normal_mode(self) -> None:
        data = (
            "0"           # [0]  operating_mode = NORMAL
            "03"          # [1:3] area_number = 0x03
            "0"           # [3]  error_detected = False
            "00"          # [4:6] error_code = 0x00
            "0"           # [6]  lockout = False
            "1"           # [7]  ossd1 = True
            "1"           # [8]  ossd2 = True
            "0"           # [9]  warning1 = False
            "0"           # [10] warning2 = False
            "1"           # [11] ossd3 = True
            "1"           # [12] ossd4 = True
            "0"           # [13] reserved
            "0"           # [14] reserved
            "0"           # [15] muting_override1 = False
            "0"           # [16] muting_override2 = False
            "0"           # [17] reset_request1 = False
            "0"           # [18] reset_request2 = False
            "0000"        # [19:23] encoder_speed = 0
            "12345678"    # [23:31] timestamp = 0x12345678
            "1"           # [31] laser_off = True
            "0"           # [32] optical_window_contamination = False
        )
        safety = parse_safety_data(data)
        assert safety.operating_mode == 0
        assert safety.area_number == 0x03 + 1
        assert not safety.error_detected
        assert safety.error_code == 0x40  # 0x00 + 0x40 offset
        assert not safety.lockout
        assert safety.ossd1 is True
        assert safety.ossd2 is True
        assert not safety.warning1
        assert not safety.warning2
        assert safety.ossd3 is True
        assert safety.ossd4 is True
        assert not safety.muting_override1
        assert not safety.muting_override2
        assert not safety.reset_request1
        assert not safety.reset_request2
        assert safety.encoder_speed == 0x0000
        assert safety.timestamp == 0x12345678
        assert safety.laser_off is True
        assert not safety.optical_window_contamination

    def test_parse_all_flags_set(self) -> None:
        data = "1FF1FF1111111111111FFFF0000000011"
        safety = parse_safety_data(data)
        assert safety.operating_mode == 1
        assert safety.area_number == 0xFF + 1
        assert safety.error_detected is True
        assert safety.error_code == 0xFF + 0x40
        assert safety.lockout is True
        assert safety.laser_off is True
        assert safety.optical_window_contamination is True


class TestParseDistanceData:
    def test_basic(self) -> None:
        data = "00640096012C"
        result = parse_distance_data(data, 3)
        assert result == (100, 150, 300)

    def test_special_values(self) -> None:
        data = "FFFFFFFEFFFD"
        result = parse_distance_data(data, 3)
        assert result == (0xFFFF, 0xFFFE, 0xFFFD)


class TestParseStatusData:
    def test_parse_basic(self) -> None:
        data = (
            "0"           # operating_mode
            "01"          # area_number
            "0"           # error_detected
            "00"          # error_code
            "0"           # lockout
            "11"          # ossd1, ossd2
            "00"          # warning1, warning2
            "11"          # ossd3, ossd4
            "00"          # reserved
            "00"          # muting_override1, muting_override2
            "00"          # reset_request1, reset_request2
            "0000"        # encoder_speed
            "0"           # laser_off
            "111"         # slave1-3 ossd12
            "111"         # slave1-3 ossd34
            "000"         # slave1-3 warning1
            "000"         # slave1-3 warning2
            "000"         # slave1-3 error
            "000"         # slave1-3 laser_off
            "DEADBEEF"    # timestamp
            "0"           # contamination
        )
        status = parse_status_data(data)
        assert status.operating_mode == 0
        assert status.area_number == 2  # protocol 0x01 + offset 1
        assert not status.error_detected
        assert status.ossd1 is True
        assert status.slave1.ossd12_on is True
        assert status.slave2.ossd12_on is True
        assert status.slave3.ossd12_on is True
        assert status.timestamp == 0xDEADBEEF
        assert not status.optical_window_contamination


class TestParseDetectionLog:
    def test_parse_single_entry(self) -> None:
        entry = (
            "0003"        # io: area=3
            "00C8"        # protection1_min_dist = 200
            "021C"        # protection1_min_dist_step = 540
            "0064"        # protection2_min_dist = 100
            "0100"        # protection2_min_dist_step = 256
            + "0000" * 9  # slave IOs + reserved
            + "12345678"  # timestamp
        )
        data = entry + "0" * 64 * 29
        entries = parse_detection_log(data)
        assert len(entries) == 30
        assert entries[0].io.area_number == 4  # protocol 3 + offset 1
        assert entries[0].protection1_min_dist == 200
        assert entries[0].protection1_min_dist_step == 540
        assert entries[0].protection2_min_dist == 100
        assert entries[0].timestamp == 0x12345678


class TestParseAreaReply:
    def test_basic(self) -> None:
        data = "006400C80190"
        result = parse_area_reply(data)
        assert result == [100, 200, 400]


class TestParseErrorLog:
    def test_parse_with_errors(self) -> None:
        """Non-zero values should have +0x40 offset applied."""
        # RAM: first slot = 0x0001, second = 0x000A, rest zero
        ram = "0001" + "000A" + "0000" * 62
        # ROM: first slot = 0x0005, rest zero
        rom = "0005" + "0000" * 63
        result = parse_error_log(ram + rom)
        assert result.ram_errors == (0x01 + 0x40, 0x0A + 0x40)
        assert result.rom_errors == (0x05 + 0x40,)

    def test_empty_log(self) -> None:
        """All-zero data should produce empty tuples."""
        data = "0000" * 128  # 64 RAM + 64 ROM, all zero
        result = parse_error_log(data)
        assert result.ram_errors == ()
        assert result.rom_errors == ()

    def test_full_log(self) -> None:
        """All 64 slots filled in both RAM and ROM."""
        ram = "0001" * 64
        rom = "0002" * 64
        result = parse_error_log(ram + rom)
        assert len(result.ram_errors) == 64
        assert all(v == 0x01 + 0x40 for v in result.ram_errors)
        assert len(result.rom_errors) == 64
        assert all(v == 0x02 + 0x40 for v in result.rom_errors)


class TestParseConfigId:
    def test_basic(self) -> None:
        data = "AABBCCDDEEFFFFGG"
        result = parse_config_id(data)
        assert result.id1 == "AABBCCDD"
        assert result.id2 == "EEFFFFGG"
