"""Tests for the CRC-16 Kermit implementation."""

from uam_05lp._crc import compute_crc


class TestComputeCRC:
    def test_spec_example_vr00(self) -> None:
        """Verify against the spec example: CRC of '000EVR00' should be 0x3492."""
        data = b"000EVR00"
        result = compute_crc(data)
        assert result == 0x3492, f"Expected 0x3492, got 0x{result:04X}"

    def test_empty_input(self) -> None:
        """CRC of empty data should be the init value (0x0000)."""
        assert compute_crc(b"") == 0x0000

    def test_single_byte(self) -> None:
        """CRC of a single byte should be deterministic."""
        result = compute_crc(b"\x00")
        assert isinstance(result, int)
        assert 0 <= result <= 0xFFFF

    def test_consistency(self) -> None:
        """Same input should always produce the same CRC."""
        data = b"test data for crc"
        assert compute_crc(data) == compute_crc(data)

    def test_different_inputs_different_crcs(self) -> None:
        """Different inputs should (very likely) produce different CRCs."""
        assert compute_crc(b"hello") != compute_crc(b"world")

    def test_all_bytes(self) -> None:
        """CRC should handle all possible byte values."""
        data = bytes(range(256))
        result = compute_crc(data)
        assert isinstance(result, int)
        assert 0 <= result <= 0xFFFF
