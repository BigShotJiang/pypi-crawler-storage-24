# Safety Data

Every scan response includes a `SafetyData` object with the sensor's safety state.

## Fields

| Field | Description |
|-------|-------------|
| `operating_mode` | 0=Normal, 1=Setting |
| `area_number` | Active area number |
| `error_detected` | Error flag |
| `error_code` | Error code (hex) |
| `lockout` | Lockout state |
| `ossd1`, `ossd2` | OSSD output 1 and 2 states |
| `ossd3`, `ossd4` | OSSD output 3 and 4 states |
| `warning1`, `warning2` | Warning output 1 and 2 states |
| `muting_override1`, `muting_override2` | Muting/override states |
| `reset_request1`, `reset_request2` | Reset request states |
| `encoder_speed` | Encoder speed value |
| `timestamp` | Sensor timestamp |
| `laser_off` | Laser off state (v2.0.0+) |
| `optical_window_contamination` | Window contamination warning (v2.1.0+) |

## Special Distance Values

| Value | Constant | Meaning |
|-------|----------|---------|
| 0xFFFF | `DistanceValue.ERROR` | Measurement error |
| 0xFFFE | `DistanceValue.NO_DETECTION` | No object detected |
| 0xFFFD | `DistanceValue.TOO_CLOSE` | Object too close |
| 0xFFFC | `DistanceValue.LASER_OFF` | Laser is off |

## Example

```python
from uam_05lp import UAM05LP, DistanceValue

with UAM05LP("192.168.0.10") as sensor:
    scan = sensor.get_distance()
    sd = scan.safety

    if sd.error_detected:
        print(f"Error: 0x{sd.error_code:02X}")
    if sd.lockout:
        print("Sensor in lockout!")

    for i, d in enumerate(scan.distances):
        if d == DistanceValue.NO_DETECTION:
            continue
        if d < 500:
            print(f"Step {i}: {d} mm (close!)")
```
