# Continuous Mode

Continuous mode provides a stream of scan data without per-scan request overhead.

## Usage

```python
from uam_05lp import UAM05LP

with UAM05LP("192.168.0.10") as sensor:
    # Use as a context manager — stop command is sent automatically on exit
    with sensor.iter_distance() as stream:
        for scan in stream:
            print(f"Front: {scan.distances[540]} mm")
            if should_stop():
                break
```

## Available Modes

| Method | Start | Stop | Steps | Intensity |
|--------|-------|------|-------|-----------|
| `iter_distance()` | AR02 | AR03 | 1081 | No |
| `iter_distance_intensity()` | AR04 | AR05 | 1081 | Yes |
| `iter_distance_highres()` | AR07 | AR08 | 2161 | No |

## How It Works

1. `__enter__` sends the start command (e.g., AR02) and reads the acknowledgement
2. `__next__` reads the next scan frame from the transport
3. `__exit__` sends the stop command (e.g., AR03) and drains any buffered frames

The stop sequence follows the C library's approach: drain buffered data, send stop, read until acknowledgement, with retry logic.
