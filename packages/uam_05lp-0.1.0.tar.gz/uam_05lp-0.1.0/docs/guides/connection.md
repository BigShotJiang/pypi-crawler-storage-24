# Connection Guide

## Ethernet (TCP)

The default and most common connection method:

```python
from uam_05lp import UAM05LP

# Default: 192.168.0.10:10940
sensor = UAM05LP()

# Custom address
sensor = UAM05LP("192.168.1.100", port=10940)

# With timeout
sensor = UAM05LP("192.168.0.10", timeout_s=2.0)
```

## Serial (USB)

Requires the `pyserial` package:

```bash
pip install uam-05lp[serial]
```

```python
from uam_05lp import UAM05LP, SerialTransport

transport = SerialTransport("/dev/ttyUSB0", baudrate=115200)
sensor = UAM05LP(transport=transport)
```

## Context Manager

Always use the context manager for automatic cleanup:

```python
with UAM05LP("192.168.0.10") as sensor:
    # Use sensor...
    pass
# Connection automatically closed
```

## Custom Transport

You can implement a custom transport by subclassing `Transport`:

```python
from uam_05lp.transport import Transport

class MyTransport(Transport):
    def open(self) -> None: ...
    def close(self) -> None: ...
    def send(self, data: bytes) -> int: ...
    def receive_frame(self, timeout_ms: int) -> bytes: ...

    @property
    def is_open(self) -> bool: ...

sensor = UAM05LP(transport=MyTransport())
```
