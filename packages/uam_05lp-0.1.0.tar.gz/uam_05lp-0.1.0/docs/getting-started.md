# Getting Started

## Installation

```bash
pip install uam-05lp
```

For serial/USB connections, install the optional `serial` extra:

```bash
pip install uam-05lp[serial]
```

## Basic Usage

### Ethernet Connection

```python
from uam_05lp import UAM05LP

with UAM05LP("192.168.0.10") as sensor:
    version = sensor.get_version()
    print(f"Product: {version.product_type}")
    print(f"Firmware: {version.firmware_version}")
    print(f"Serial: {version.serial_number}")

    scan = sensor.get_distance()
    print(f"Front distance: {scan.distances[540]} mm")
```

### Serial Connection

```python
from uam_05lp import UAM05LP, SerialTransport

transport = SerialTransport("/dev/ttyUSB0", baudrate=115200)
with UAM05LP(transport=transport) as sensor:
    scan = sensor.get_distance()
```

### Continuous Mode

```python
from uam_05lp import UAM05LP

with UAM05LP("192.168.0.10") as sensor:
    with sensor.iter_distance() as stream:
        for scan in stream:
            print(f"Area: {scan.safety.area_number}, "
                  f"Front: {scan.distances[540]} mm")
```

## Sensor Default Settings

| Setting | Default |
|---------|---------|
| IP Address | 192.168.0.10 |
| Port | 10940 |
| Steps (standard) | 1081 |
| Steps (high-res) | 2161 |
| Max distance | 40,000 mm |
