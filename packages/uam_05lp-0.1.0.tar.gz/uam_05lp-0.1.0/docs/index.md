# uam-05lp

Python communication library for the Hokuyo UAM-05LP safety laser scanner.

## Features

- **UAM protocol** support (not SCIP)
- **Ethernet (TCP)** and **USB/Serial** connections
- **Handshake** and **continuous** measurement modes
- **Zero dependencies** for Ethernet — only `pyserial` needed for serial
- **Fully typed** with `py.typed` marker

## Quick Start

```python
from uam_05lp import UAM05LP

with UAM05LP("192.168.0.10") as sensor:
    scan = sensor.get_distance()
    print(f"Front distance: {scan.distances[540]} mm")
```

## Installation

```bash
pip install uam-05lp

# For serial/USB connections:
pip install uam-05lp[serial]
```
