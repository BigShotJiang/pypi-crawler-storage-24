# uam-05lp

Python communication library for the Hokuyo UAM-05LP safety laser scanner (UAM protocol).

## Installation

```bash
pip install uam-05lp
```

For serial/USB connections:

```bash
pip install uam-05lp[serial]
```

## Quick Start

```python
from uam_05lp import UAM05LP

with UAM05LP("192.168.0.10") as sensor:
    # Single scan
    scan = sensor.get_distance()
    print(f"Got {len(scan.distances)} distance points")
    print(f"Area: {scan.safety.area_number}, Error: {scan.safety.error_detected}")

    # Continuous scanning
    with sensor.iter_distance() as stream:
        for scan in stream:
            print(scan.distances[540])  # Front-center distance
```

## Requirements

- Python 3.10+
- No dependencies for Ethernet (TCP) connections
- `pyserial` for USB/Serial connections (install with `[serial]` extra)

## License

BSD-3-Clause
