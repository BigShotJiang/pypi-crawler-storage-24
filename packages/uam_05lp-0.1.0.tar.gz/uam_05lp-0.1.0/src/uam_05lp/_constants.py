"""Protocol constants for the UAM-05LP safety laser scanner."""

from __future__ import annotations

# Frame delimiters
STX: int = 0x02
ETX: int = 0x03

# Frame field sizes (in characters)
LENGTH_SIZE: int = 4
CRC_SIZE: int = 4
HEADER_SIZE: int = 2
SUBHEADER_SIZE: int = 2
STATUS_SIZE: int = 2

# Default connection parameters
DEFAULT_HOST: str = "192.168.0.10"
DEFAULT_PORT: int = 10940

# Scan step counts
STANDARD_STEPS: int = 1081
HIGHRES_STEPS: int = 2161

# Distance limits
MAX_DISTANCE: int = 40000

# Special distance values
DISTANCE_ERROR: int = 0xFFFF
DISTANCE_NO_DETECTION: int = 0xFFFE
DISTANCE_TOO_CLOSE: int = 0xFFFD
DISTANCE_LASER_OFF: int = 0xFFFC

# Safety data field offset within response body
# Body starts after STX(1) + Length(4) + Header(2) + SubHeader(2) = offset 9
BODY_OFFSET: int = 1 + LENGTH_SIZE + HEADER_SIZE + SUBHEADER_SIZE

# Error code offset: protocol value + 0x40 = 7-seg display value
ERROR_CODE_OFFSET: int = 0x40

# Area number offset: protocol is 0-based, 7-seg display is 1-based
AREA_NUMBER_OFFSET: int = 1

# Safety data field length (chars in AR response body)
SAFETY_DATA_LENGTH: int = 33

# Reserved field between safety data and distance data
SAFETY_RESERVED_LENGTH: int = 6

# Detection log constants
MAX_DETECTION_LOG_ENTRIES: int = 30
DETECTION_LOG_ENTRY_SIZE: int = 64  # chars per log entry

# Error log constants
MAX_ERROR_LOG_ENTRIES: int = 64

# Status data XR00
STATUS_DATA_LENGTH: int = 90  # body chars before reserved

# AR stop return length (including STX, excluding ETX which is stripped)
AR_STOP_RETURN_LENGTH: int = 16
