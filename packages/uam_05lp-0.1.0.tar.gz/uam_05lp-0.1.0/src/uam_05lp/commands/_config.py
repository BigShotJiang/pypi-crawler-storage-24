"""ID00 — Configuration ID query."""

from __future__ import annotations

from typing import TYPE_CHECKING

from .._protocol import parse_config_id

if TYPE_CHECKING:
    from ..client import UAM05LP
    from ..models import ConfigId

__all__ = ["get_config_id"]


def get_config_id(client: UAM05LP) -> ConfigId:
    """Get configuration ID (ID00).

    Returns:
        :class:`ConfigId` with two 8-character ID strings.
    """
    data = client.send_command("ID", "00")
    return parse_config_id(data)
