"""ER01 / EC00 — Error log retrieval and clearing."""

from __future__ import annotations

from typing import TYPE_CHECKING

from .._protocol import parse_error_log

if TYPE_CHECKING:
    from ..client import UAM05LP
    from ..models import ErrorLogData

__all__ = ["clear_error_log", "get_error_log"]


def get_error_log(client: UAM05LP) -> ErrorLogData:
    """Get error log entries (ER01).

    Returns:
        :class:`ErrorLogData` with RAM and ROM error codes.
    """
    data = client.send_command("ER", "01")
    return parse_error_log(data)


def clear_error_log(client: UAM05LP) -> None:
    """Clear the error log (EC00)."""
    client.send_command("EC", "00")
