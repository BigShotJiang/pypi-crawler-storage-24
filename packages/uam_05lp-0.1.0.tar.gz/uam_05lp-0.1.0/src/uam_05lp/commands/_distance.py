"""AR00 / AR01 / AR06 — Handshake distance measurement."""

from __future__ import annotations

from typing import TYPE_CHECKING

from .._constants import HIGHRES_STEPS, STANDARD_STEPS
from .._protocol import build_frame, check_status, parse_frame

if TYPE_CHECKING:
    from ..client import UAM05LP
    from ..models import ScanData

__all__ = ["get_distance", "get_distance_highres", "get_distance_intensity"]


def _handshake_scan(
    client: UAM05LP,
    subheader: str,
    step_count: int,
    has_intensity: bool,
) -> ScanData:
    """Send a handshake AR command and parse the scan response."""
    client._ensure_connected()  # noqa: SLF001
    frame = build_frame("AR", subheader)
    client._transport.send(frame)  # noqa: SLF001
    raw = client._transport.receive_frame(client._timeout_ms)  # noqa: SLF001
    parsed = parse_frame(raw)
    check_status(parsed)
    return client._parse_scan_response(  # noqa: SLF001
        parsed, step_count, has_intensity,
    )


def get_distance(client: UAM05LP) -> ScanData:
    """Get a single distance scan with 1081 steps (AR00).

    Returns:
        :class:`ScanData` with distances and safety metadata.
    """
    return _handshake_scan(client, "00", STANDARD_STEPS, has_intensity=False)


def get_distance_intensity(client: UAM05LP) -> ScanData:
    """Get a single distance + intensity scan with 1081 steps (AR01).

    Returns:
        :class:`ScanData` with distances, intensities, and safety
        metadata.
    """
    return _handshake_scan(client, "01", STANDARD_STEPS, has_intensity=True)


def get_distance_highres(client: UAM05LP) -> ScanData:
    """Get a single high-resolution distance scan with 2161 steps (AR06).

    Returns:
        :class:`ScanData` with distances and safety metadata.
    """
    return _handshake_scan(client, "06", HIGHRES_STEPS, has_intensity=False)
