"""XR00 — Sensor status query."""

from __future__ import annotations

from typing import TYPE_CHECKING

from .._protocol import parse_status_data

if TYPE_CHECKING:
    from ..client import UAM05LP
    from ..models import StatusData

__all__ = ["get_status"]


def get_status(client: UAM05LP) -> StatusData:
    """Query extended sensor status (XR00).

    Returns:
        :class:`StatusData` with master and slave device states.
    """
    data = client.send_command("XR", "00")
    return parse_status_data(data)
