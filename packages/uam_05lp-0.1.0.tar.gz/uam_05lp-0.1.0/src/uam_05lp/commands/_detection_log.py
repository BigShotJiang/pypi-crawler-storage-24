"""DL00 / DC00 — Detection log retrieval and clearing."""

from __future__ import annotations

from typing import TYPE_CHECKING

from .._protocol import parse_detection_log

if TYPE_CHECKING:
    from ..client import UAM05LP
    from ..models import DetectionLogEntry

__all__ = ["clear_detection_log", "get_detection_log"]


def get_detection_log(client: UAM05LP) -> list[DetectionLogEntry]:
    """Get detection log entries (DL00).

    Returns:
        List of up to 30 :class:`DetectionLogEntry` instances.
    """
    data = client.send_command("DL", "00")
    return parse_detection_log(data)


def clear_detection_log(client: UAM05LP) -> None:
    """Clear the detection log (DC00)."""
    client.send_command("DC", "00")
