"""YR00–YR08 — Area distance data query."""

from __future__ import annotations

from typing import TYPE_CHECKING

from .._protocol import parse_area_reply

if TYPE_CHECKING:
    from ..client import UAM05LP

__all__ = ["get_area"]

# The YR response echoes the command parameters before the actual
# area distance data.  The echo consists of:
#   start_step(4) + end_step(4) + grouping(2) + area_number(2) = 12 chars
# Ref: C library body_offset = 1+4+4+2 + 4+4+2+2 = 23
_YR_ECHO_SIZE = 12


def get_area(
    client: UAM05LP,
    area_type: int,
    area_number: int = 0,
    start_step: int = 0,
    end_step: int = 1080,
    grouping: int = 1,
) -> list[int]:
    """Get area distance data (YR command).

    Args:
        client: The connected UAM05LP instance.
        area_type: Area type (0–8).  See :class:`AreaType`.
        area_number: Area number (0-based).
        start_step: Start step index.
        end_step: End step index.
        grouping: Step grouping factor.

    Returns:
        List of distance values in mm.
    """
    cmd_data = (
        f"{area_type:02X}{area_number:02X}"
        f"{start_step:04X}{end_step:04X}"
        f"{grouping:02X}"
    )
    data = client.send_command("YR", cmd_data[:2], cmd_data[2:])
    return parse_area_reply(data[_YR_ECHO_SIZE:])
