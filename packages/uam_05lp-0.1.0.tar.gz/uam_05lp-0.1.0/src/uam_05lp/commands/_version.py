"""VR00 — Sensor version information."""

from __future__ import annotations

from typing import TYPE_CHECKING

from .._protocol import parse_version_reply

if TYPE_CHECKING:
    from ..client import UAM05LP
    from ..models import VersionInfo

__all__ = ["get_version"]


def get_version(client: UAM05LP) -> VersionInfo:
    """Query sensor version information (VR00).

    Returns:
        :class:`VersionInfo` with product type, firmware version,
        and serial number.
    """
    data = client.send_command("VR", "00")
    return parse_version_reply(data)
