"""Command implementations for the UAM-05LP sensor.

Each module in this package implements one command group.  To add a new
command, create a new module and register it in the :class:`UAM05LP`
client.
"""
