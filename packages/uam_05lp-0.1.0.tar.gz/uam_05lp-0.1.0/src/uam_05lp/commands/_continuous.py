"""AR02–AR08 — Continuous distance measurement + ContinuousScanner."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from .._constants import HIGHRES_STEPS, STANDARD_STEPS
from .._protocol import (
    build_frame,
    check_status,
    parse_frame,
)
from ..exceptions import FrameError

if TYPE_CHECKING:
    from collections.abc import Iterator
    from types import TracebackType

    from ..client import UAM05LP
    from ..models import ScanData

__all__ = [
    "ContinuousScanner",
    "iter_distance",
    "iter_distance_highres",
    "iter_distance_intensity",
]

logger = logging.getLogger(__name__)

# Stop-sequence constants (from the C library)
_MAX_DRAIN_FRAMES = 15
_MAX_STOP_ATTEMPTS = 3
_MAX_READ_AFTER_STOP = 5
_DRAIN_TIMEOUT_MS = 100


class ContinuousScanner:
    """Context-manager iterator for continuous measurement mode.

    Do not instantiate directly; use :meth:`UAM05LP.iter_distance`,
    :meth:`UAM05LP.iter_distance_intensity`, or
    :meth:`UAM05LP.iter_distance_highres` instead.

    Example::

        with sensor.iter_distance() as stream:
            for scan in stream:
                process(scan)
                if done:
                    break  # __exit__ sends the stop command
    """

    def __init__(
        self,
        client: UAM05LP,
        start_header: str,
        start_subheader: str,
        stop_header: str,
        stop_subheader: str,
        step_count: int,
        has_intensity: bool,
    ) -> None:
        self._client = client
        self._start_header = start_header
        self._start_sub = start_subheader
        self._stop_header = stop_header
        self._stop_sub = stop_subheader
        self._step_count = step_count
        self._has_intensity = has_intensity
        self._active = False

    def __enter__(self) -> ContinuousScanner:
        """Send the start command and consume the status-only ACK.

        The sensor responds with a short acknowledgement frame
        (status only, no data) before it begins streaming data frames.
        This ACK is consumed here so that ``__next__`` receives only
        full data frames.
        """
        cmd = f"{self._start_header}{self._start_sub}"
        logger.info("Starting continuous mode (%s)", cmd)

        frame = build_frame(self._start_header, self._start_sub)
        self._client._transport.send(frame)  # noqa: SLF001

        # Read and validate the status-only ACK frame
        raw = self._client._transport.receive_frame(  # noqa: SLF001
            self._client._timeout_ms,  # noqa: SLF001
        )
        parsed = parse_frame(raw)
        check_status(parsed)

        self._active = True
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        """Send the stop command and drain buffered frames."""
        if not self._active:
            return
        self._active = False
        self._stop_continuous()

    def _stop_continuous(self) -> None:
        """Send the stop command and drain buffered frames.

        Follows the C library's retry logic: drain → send stop → read
        until stop acknowledgement, with up to three attempts.
        """
        transport = self._client._transport  # noqa: SLF001
        timeout_ms = self._client._timeout_ms  # noqa: SLF001
        stop_cmd = f"{self._stop_header}{self._stop_sub}"

        for attempt in range(1, _MAX_STOP_ATTEMPTS + 1):
            for _ in range(_MAX_DRAIN_FRAMES):
                try:
                    transport.receive_frame(_DRAIN_TIMEOUT_MS)
                except Exception:  # noqa: BLE001
                    break

            logger.debug(
                "Sending stop command %s (attempt %d)", stop_cmd, attempt,
            )
            frame = build_frame(self._stop_header, self._stop_sub)
            transport.send(frame)

            for _ in range(_MAX_READ_AFTER_STOP):
                try:
                    raw = transport.receive_frame(timeout_ms)
                except Exception:  # noqa: BLE001
                    break
                try:
                    parsed = parse_frame(raw)
                    if parsed.subheader == self._stop_sub:
                        logger.info("Continuous mode stopped (%s)", stop_cmd)
                        return
                except (FrameError, Exception):  # noqa: BLE001
                    continue

        logger.warning(
            "Failed to cleanly stop continuous mode (%s) "
            "after %d attempts",
            stop_cmd,
            _MAX_STOP_ATTEMPTS,
        )

    def __iter__(self) -> Iterator[ScanData]:
        """Return self as the iterator."""
        return self

    def __next__(self) -> ScanData:
        """Read the next scan from the continuous stream.

        Raises:
            StopIteration: If the stream has been stopped.
        """
        if not self._active:
            raise StopIteration

        raw = self._client._transport.receive_frame(  # noqa: SLF001
            self._client._timeout_ms  # noqa: SLF001
        )
        parsed = parse_frame(raw)

        return self._client._parse_scan_response(  # noqa: SLF001
            parsed, self._step_count, self._has_intensity
        )


# -- Factory functions (called by UAM05LP) --


def iter_distance(client: UAM05LP) -> ContinuousScanner:
    """Start continuous distance scanning — 1081 steps (AR02/AR03).

    Returns a context-manager iterator.
    """
    client._ensure_connected()  # noqa: SLF001
    return ContinuousScanner(
        client, "AR", "02", "AR", "03",
        step_count=STANDARD_STEPS, has_intensity=False,
    )


def iter_distance_intensity(client: UAM05LP) -> ContinuousScanner:
    """Start continuous distance + intensity scanning — 1081 steps (AR04/AR05).

    Returns a context-manager iterator.
    """
    client._ensure_connected()  # noqa: SLF001
    return ContinuousScanner(
        client, "AR", "04", "AR", "05",
        step_count=STANDARD_STEPS, has_intensity=True,
    )


def iter_distance_highres(client: UAM05LP) -> ContinuousScanner:
    """Start continuous high-res distance scanning — 2161 steps (AR07/AR08).

    Returns a context-manager iterator.
    """
    client._ensure_connected()  # noqa: SLF001
    return ContinuousScanner(
        client, "AR", "07", "AR", "08",
        step_count=HIGHRES_STEPS, has_intensity=False,
    )
