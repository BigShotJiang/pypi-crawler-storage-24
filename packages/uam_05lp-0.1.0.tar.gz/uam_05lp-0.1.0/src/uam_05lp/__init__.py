"""UAM-05LP safety laser scanner communication library.

Usage::

    from uam_05lp import UAM05LP

    with UAM05LP("192.168.0.10") as sensor:
        scan = sensor.get_distance()
"""

from __future__ import annotations

import logging
from importlib.metadata import PackageNotFoundError, version

from .client import UAM05LP, ContinuousScanner
from .enums import AreaType, DistanceValue, OperatingMode, ReplyStatus
from .exceptions import (
    ConnectionError,
    ContinuousModeError,
    CRCError,
    FrameError,
    SensorError,
    SerialNotAvailableError,
    TimeoutError,
    TransportError,
    UAMError,
)
from .models import (
    ConfigId,
    DetectionLogEntry,
    DetectionLogIO,
    ErrorLogData,
    SafetyData,
    ScanData,
    SlaveDeviceState,
    StatusData,
    VersionInfo,
)
from .transport import SerialTransport, TcpTransport, Transport

try:
    __version__ = version("uam-05lp")
except PackageNotFoundError:
    __version__ = "0.0.0"

logging.getLogger(__name__).addHandler(logging.NullHandler())

__all__ = [
    "AreaType",
    "ConfigId",
    "ConnectionError",
    "ContinuousModeError",
    "ContinuousScanner",
    "CRCError",
    "DetectionLogEntry",
    "DetectionLogIO",
    "DistanceValue",
    "ErrorLogData",
    "FrameError",
    "OperatingMode",
    "ReplyStatus",
    "SafetyData",
    "ScanData",
    "SensorError",
    "SerialNotAvailableError",
    "SerialTransport",
    "SlaveDeviceState",
    "StatusData",
    "TcpTransport",
    "TimeoutError",
    "Transport",
    "TransportError",
    "UAM05LP",
    "UAMError",
    "VersionInfo",
]
