"""Kermit CRC-16 implementation ported from safety_crc.c."""

from __future__ import annotations

__all__ = ["compute_crc"]

_POLYNOMIAL: int = 0x8408
_INIT_VAL: int = 0x0000

# Build 256-entry lookup table at module load
_CRC_TABLE: list[int] = []
for _u in range(256):
    _result = _u
    for _ in range(8):
        if _result & 1:
            _result = (_result >> 1) ^ _POLYNOMIAL
        else:
            _result >>= 1
    _CRC_TABLE.append(_result & 0xFFFF)


def compute_crc(data: bytes) -> int:
    """Compute CRC-16 (Kermit) over *data*.

    Matches the ``safety_calc_crc`` function from the C library.
    The CRC covers Length + Header + SubHeader + Data (everything between
    STX and the CRC field).
    """
    crc = _INIT_VAL
    for byte in data:
        temp = crc ^ (0x00FF & byte)
        crc = ((crc >> 8) & 0xFF) ^ _CRC_TABLE[temp & 0xFF]
    return crc & 0xFFFF
