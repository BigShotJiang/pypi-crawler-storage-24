"""Enumerations for the UAM-05LP protocol."""

from __future__ import annotations

from enum import IntEnum

__all__ = [
    "AreaType",
    "DistanceValue",
    "OperatingMode",
    "ReplyStatus",
]


class OperatingMode(IntEnum):
    """Sensor operating mode (from safety data field)."""

    NORMAL = 0
    SETTING = 1


class AreaType(IntEnum):
    """Area types for the YR command."""

    PROTECTION_1 = 0
    PROTECTION_2 = 1
    WARNING_1 = 2
    WARNING_2 = 3
    PROTECTION_1_ACTUAL = 4
    PROTECTION_2_ACTUAL = 5
    WARNING_1_ACTUAL = 6
    WARNING_2_ACTUAL = 7
    REFERENCE_MIN = 8


class DistanceValue(IntEnum):
    """Special distance values returned by the sensor."""

    ERROR = 0xFFFF
    NO_DETECTION = 0xFFFE
    TOO_CLOSE = 0xFFFD
    LASER_OFF = 0xFFFC


class ReplyStatus(IntEnum):
    """Reply status codes from the sensor (Section 7 of spec)."""

    OK = 0x00
    SIZE_ERROR = 0x12
    UNDEFINED_COMMAND = 0x20
    UNDEFINED_COMMAND_2 = 0x21
    FREQUENCY_ERROR = 0x22
    SETTING_MODE_MISMATCH = 0x30
    BUSY = 0x31
    SENSOR_MALFUNCTION = 0x40
    HARDWARE_ERROR = 0x50
    FIRMWARE_ERROR = 0x60
