"""Data models for the UAM-05LP protocol responses.

All models are frozen dataclasses (immutable) with ``__slots__`` for
memory efficiency.
"""

from __future__ import annotations

from dataclasses import dataclass

__all__ = [
    "ConfigId",
    "DetectionLogEntry",
    "DetectionLogIO",
    "ErrorLogData",
    "SafetyData",
    "ScanData",
    "SlaveDeviceState",
    "StatusData",
    "VersionInfo",
]


@dataclass(frozen=True, slots=True)
class VersionInfo:
    """Sensor version information from VR00 response."""

    product_type: str
    firmware_version: str
    serial_number: str


@dataclass(frozen=True, slots=True)
class SafetyData:
    """Safety metadata attached to every AR measurement response.

    Every field maps directly to the sensor's safety data block as
    described in the UAM-05LP communication specification.
    """

    operating_mode: int
    area_number: int
    error_detected: bool
    error_code: int
    lockout: bool
    ossd1: bool
    ossd2: bool
    warning1: bool
    warning2: bool
    ossd3: bool
    ossd4: bool
    muting_override1: bool
    muting_override2: bool
    reset_request1: bool
    reset_request2: bool
    encoder_speed: int
    timestamp: int
    laser_off: bool
    optical_window_contamination: bool


@dataclass(frozen=True, slots=True)
class ScanData:
    """Complete scan result: safety metadata + distances + optional intensity.

    Attributes:
        safety: Safety metadata for this scan.
        distances: Tuple of distance values in mm, one per step.
        intensities: Tuple of intensity values (only for AR01/AR04
            responses), or ``None``.
    """

    safety: SafetyData
    distances: tuple[int, ...]
    intensities: tuple[int, ...] | None = None


@dataclass(frozen=True, slots=True)
class SlaveDeviceState:
    """State of a slave device from XR00 status response."""

    ossd12_on: bool
    ossd34_on: bool
    warning1_on: bool
    warning2_on: bool
    error_detected: bool
    laser_off: bool


@dataclass(frozen=True, slots=True)
class StatusData:
    """Extended status from XR00 response.

    Includes master device fields plus up to three slave devices.
    """

    operating_mode: int
    area_number: int
    error_detected: bool
    error_code: int
    lockout: bool
    ossd1: bool
    ossd2: bool
    warning1: bool
    warning2: bool
    ossd3: bool
    ossd4: bool
    muting_override1: bool
    muting_override2: bool
    reset_request1: bool
    reset_request2: bool
    encoder_speed: int
    laser_off: bool
    slave1: SlaveDeviceState
    slave2: SlaveDeviceState
    slave3: SlaveDeviceState
    timestamp: int
    optical_window_contamination: bool


@dataclass(frozen=True, slots=True)
class DetectionLogIO:
    """I/O state from a detection log entry."""

    area_number: int
    protection1_state: bool
    protection2_state: bool


@dataclass(frozen=True, slots=True)
class DetectionLogEntry:
    """Single detection log entry from DL00 response."""

    io: DetectionLogIO
    protection1_min_dist: int
    protection1_min_dist_step: int
    protection2_min_dist: int
    protection2_min_dist_step: int
    slave1_io: DetectionLogIO
    slave2_io: DetectionLogIO
    slave3_io: DetectionLogIO
    timestamp: int


@dataclass(frozen=True, slots=True)
class ErrorLogData:
    """Error log data from ER01 response."""

    ram_errors: tuple[int, ...]
    rom_errors: tuple[int, ...]


@dataclass(frozen=True, slots=True)
class ConfigId:
    """Configuration ID from ID00 response."""

    id1: str
    id2: str
