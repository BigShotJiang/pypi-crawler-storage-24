"""High-level client for the UAM-05LP safety laser scanner.

The :class:`UAM05LP` class is the main entry point.  Each sensor
command is implemented in its own module under :mod:`uam_05lp.commands`;
the client simply delegates to those modules.  To add a new command:

1. Create ``src/uam_05lp/commands/_mycommand.py``
2. Add a thin wrapper method to this class.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from ._constants import (
    DEFAULT_HOST,
    DEFAULT_PORT,
    SAFETY_DATA_LENGTH,
    SAFETY_RESERVED_LENGTH,
)
from ._protocol import (
    ParsedFrame,
    build_frame,
    check_status,
    parse_distance_data,
    parse_frame,
    parse_safety_data,
)
from .commands._area import get_area as _get_area
from .commands._config import get_config_id as _get_config_id
from .commands._continuous import ContinuousScanner
from .commands._continuous import iter_distance as _iter_distance
from .commands._continuous import (
    iter_distance_highres as _iter_distance_highres,
)
from .commands._continuous import (
    iter_distance_intensity as _iter_distance_intensity,
)
from .commands._detection_log import (
    clear_detection_log as _clear_detection_log,
)
from .commands._detection_log import (
    get_detection_log as _get_detection_log,
)
from .commands._error_log import clear_error_log as _clear_error_log
from .commands._error_log import get_error_log as _get_error_log
from .commands._distance import get_distance as _get_distance
from .commands._distance import (
    get_distance_highres as _get_distance_highres,
)
from .commands._distance import (
    get_distance_intensity as _get_distance_intensity,
)
from .commands._status import get_status as _get_status
from .commands._version import get_version as _get_version
from .exceptions import TransportError
from .models import (
    ConfigId,
    DetectionLogEntry,
    ErrorLogData,
    ScanData,
    StatusData,
    VersionInfo,
)
from .transport import TcpTransport, Transport

if TYPE_CHECKING:
    from types import TracebackType

__all__ = ["ContinuousScanner", "UAM05LP"]

logger = logging.getLogger(__name__)


class UAM05LP:
    """High-level client for the UAM-05LP safety laser scanner.

    Supports Ethernet (TCP) connections by default and USB/Serial
    connections via a custom :class:`Transport`.

    Args:
        host: Sensor IP address (default ``192.168.0.10``).
        port: TCP port (default ``10940``).
        transport: Optional pre-configured :class:`Transport` instance.
            When provided, *host* and *port* are ignored.
        timeout_s: Command timeout in seconds (default ``1.0``).

    Example::

        with UAM05LP("192.168.0.10") as sensor:
            scan = sensor.get_distance()
            print(scan.distances[540])
    """

    def __init__(
        self,
        host: str = DEFAULT_HOST,
        port: int = DEFAULT_PORT,
        *,
        transport: Transport | None = None,
        timeout_s: float = 1.0,
    ) -> None:
        if transport is not None:
            self._transport = transport
        else:
            self._transport = TcpTransport(host, port)
        self._timeout_s = timeout_s

    @property
    def _timeout_ms(self) -> int:
        """Timeout in milliseconds (for internal use by commands)."""
        return int(self._timeout_s * 1000)

    # -- Context manager --

    def __enter__(self) -> UAM05LP:
        self.open()
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        self.close()

    # -- Connection lifecycle --

    def open(self) -> None:
        """Open the connection to the sensor."""
        self._transport.open()

    def close(self) -> None:
        """Close the connection to the sensor."""
        self._transport.close()

    @property
    def is_connected(self) -> bool:
        """Whether the transport is currently open."""
        return self._transport.is_open

    # -- Internal helpers (used by command modules) --

    def _ensure_connected(self) -> None:
        """Raise if the transport is not connected."""
        if not self._transport.is_open:
            raise TransportError(
                "Not connected. Call open() or use a context manager."
            )

    def _parse_scan_response(
        self,
        parsed: ParsedFrame,
        step_count: int,
        has_intensity: bool,
    ) -> ScanData:
        """Parse an AR response frame into :class:`ScanData`."""
        data = parsed.data
        safety = parse_safety_data(data[:SAFETY_DATA_LENGTH])

        dist_offset = SAFETY_DATA_LENGTH + SAFETY_RESERVED_LENGTH
        dist_data = data[dist_offset:]

        if has_intensity:
            dist_chars = step_count * 4
            distances = parse_distance_data(
                dist_data[:dist_chars], step_count,
            )
            int_data = dist_data[dist_chars:]
            intensities = parse_distance_data(int_data, step_count)
            return ScanData(
                safety=safety,
                distances=distances,
                intensities=intensities,
            )

        distances = parse_distance_data(dist_data, step_count)
        return ScanData(safety=safety, distances=distances)

    # -- Public command API --
    # Each method delegates to its command module.  To add a new command,
    # create a module in commands/ and add a one-line wrapper here.

    def send_command(
        self, header: str, subheader: str, data: str = "",
    ) -> str:
        """Send a raw command and return the reply data field.

        This is also the low-level building block used by all command
        modules.

        Args:
            header: Two-character command header.
            subheader: Two-character sub-header.
            data: Optional data payload.

        Returns:
            The data field (string) from the sensor's response.
        """
        self._ensure_connected()
        frame = build_frame(header, subheader, data)
        self._transport.send(frame)
        raw = self._transport.receive_frame(self._timeout_ms)
        parsed = parse_frame(raw)
        check_status(parsed)
        return parsed.data

    def get_version(self) -> VersionInfo:
        """Query sensor version information (VR00)."""
        return _get_version(self)

    def get_distance(self) -> ScanData:
        """Get a single distance scan — 1081 steps (AR00)."""
        return _get_distance(self)

    def get_distance_intensity(self) -> ScanData:
        """Get a single distance + intensity scan — 1081 steps (AR01)."""
        return _get_distance_intensity(self)

    def get_distance_highres(self) -> ScanData:
        """Get a single high-res distance scan — 2161 steps (AR06)."""
        return _get_distance_highres(self)

    def iter_distance(self) -> ContinuousScanner:
        """Start continuous distance scanning — 1081 steps (AR02/AR03)."""
        return _iter_distance(self)

    def iter_distance_intensity(self) -> ContinuousScanner:
        """Start continuous distance + intensity — 1081 steps (AR04/AR05)."""
        return _iter_distance_intensity(self)

    def iter_distance_highres(self) -> ContinuousScanner:
        """Start continuous high-res distance — 2161 steps (AR07/AR08)."""
        return _iter_distance_highres(self)

    def get_status(self) -> StatusData:
        """Query extended sensor status (XR00)."""
        return _get_status(self)

    def get_area(
        self,
        area_type: int,
        area_number: int = 0,
        start_step: int = 0,
        end_step: int = 1080,
        grouping: int = 1,
    ) -> list[int]:
        """Get area distance data (YR command)."""
        return _get_area(
            self, area_type, area_number, start_step, end_step, grouping,
        )

    def get_detection_log(self) -> list[DetectionLogEntry]:
        """Get detection log entries (DL00)."""
        return _get_detection_log(self)

    def clear_detection_log(self) -> None:
        """Clear the detection log (DC00)."""
        _clear_detection_log(self)

    def get_error_log(self) -> ErrorLogData:
        """Get error log entries (ER01)."""
        return _get_error_log(self)

    def clear_error_log(self) -> None:
        """Clear the error log (EC00)."""
        _clear_error_log(self)

    def get_config_id(self) -> ConfigId:
        """Get configuration ID (ID00)."""
        return _get_config_id(self)
