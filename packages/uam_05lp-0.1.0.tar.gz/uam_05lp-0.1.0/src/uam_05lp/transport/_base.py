"""Abstract base class for transport implementations."""

from __future__ import annotations

from abc import ABC, abstractmethod

__all__ = ["Transport"]


class Transport(ABC):
    """Transport abstraction for sensor communication.

    Subclass this to implement custom communication backends.
    The library ships with :class:`TcpTransport` and
    :class:`SerialTransport`.
    """

    @abstractmethod
    def open(self) -> None:
        """Open the transport connection."""

    @abstractmethod
    def close(self) -> None:
        """Close the transport connection."""

    @abstractmethod
    def send(self, data: bytes) -> int:
        """Send *data* and return the number of bytes written."""

    @abstractmethod
    def receive_frame(self, timeout_ms: int) -> bytes:
        """Read a complete frame (STX ... ETX) from the transport.

        Returns the frame bytes **including** STX but **excluding** ETX.

        Raises:
            TimeoutError: If no complete frame arrives within *timeout_ms*.
            TransportError: On I/O errors.
        """

    @property
    @abstractmethod
    def is_open(self) -> bool:
        """Whether the transport connection is currently open."""
