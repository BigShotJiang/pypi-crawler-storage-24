"""TCP transport using stdlib socket (zero external dependencies)."""

from __future__ import annotations

import builtins
import contextlib
import logging
import socket
import time

from .._constants import ETX, STX
from ..exceptions import ConnectionError, TimeoutError, TransportError
from ._base import Transport

__all__ = ["TcpTransport"]

logger = logging.getLogger(__name__)


class TcpTransport(Transport):
    """Transport over TCP/IP (Ethernet connection).

    Args:
        host: Sensor IP address.
        port: TCP port number.
        connect_timeout_s: Timeout for the initial TCP connection.
    """

    def __init__(
        self,
        host: str,
        port: int,
        *,
        connect_timeout_s: float = 3.0,
    ) -> None:
        self._host = host
        self._port = port
        self._connect_timeout = connect_timeout_s
        self._socket: socket.socket | None = None
        self._buffer = bytearray()

    def open(self) -> None:
        """Open a TCP connection to the sensor."""
        if self._socket is not None:
            return
        logger.info("Connecting to %s:%d", self._host, self._port)
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(self._connect_timeout)
            sock.connect((self._host, self._port))
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            self._socket = sock
            self._buffer.clear()
        except OSError as exc:
            raise ConnectionError(
                f"Failed to connect to {self._host}:{self._port}: {exc}"
            ) from exc
        logger.info("Connected to %s:%d", self._host, self._port)

    def close(self) -> None:
        """Close the TCP connection."""
        if self._socket is not None:
            logger.info(
                "Closing connection to %s:%d", self._host, self._port,
            )
            with contextlib.suppress(OSError):
                self._socket.close()
            self._socket = None
            self._buffer.clear()

    def send(self, data: bytes) -> int:
        """Send *data* over the TCP socket.

        Raises:
            TransportError: If not connected or send fails.
        """
        if self._socket is None:
            raise TransportError("Not connected")
        try:
            n = self._socket.send(data)
            logger.debug("Sent %d bytes", n)
            return n
        except OSError as exc:
            raise TransportError(f"Send failed: {exc}") from exc

    def receive_frame(self, timeout_ms: int) -> bytes:
        """Read bytes until a complete STX...ETX frame is found.

        Returns:
            Frame bytes including STX but excluding ETX.

        Raises:
            TimeoutError: If no complete frame arrives in time.
            TransportError: On socket errors or remote disconnect.
        """
        if self._socket is None:
            raise TransportError("Not connected")

        deadline = time.monotonic() + timeout_ms / 1000.0

        while True:
            stx_pos = self._buffer.find(STX)
            if stx_pos >= 0:
                etx_pos = self._buffer.find(ETX, stx_pos + 1)
                if etx_pos >= 0:
                    frame = bytes(self._buffer[stx_pos:etx_pos])
                    del self._buffer[: etx_pos + 1]
                    logger.debug("Received frame (%d bytes)", len(frame))
                    return frame

            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError(
                    f"No complete frame received within {timeout_ms}ms"
                )

            self._socket.settimeout(remaining)
            try:
                chunk = self._socket.recv(4096)
            except builtins.TimeoutError as exc:
                raise TimeoutError(
                    f"No complete frame received within {timeout_ms}ms"
                ) from exc
            except OSError as exc:
                raise TransportError(f"Receive failed: {exc}") from exc

            if not chunk:
                raise TransportError("Connection closed by remote")

            self._buffer.extend(chunk)

    @property
    def is_open(self) -> bool:
        """Whether the TCP socket is currently connected."""
        return self._socket is not None
