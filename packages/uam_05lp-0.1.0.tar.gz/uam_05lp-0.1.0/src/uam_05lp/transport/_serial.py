"""Serial transport using pyserial (optional dependency)."""

from __future__ import annotations

import contextlib
import logging
import time
from typing import Any

from .._constants import ETX, STX
from ..exceptions import SerialNotAvailableError, TimeoutError, TransportError
from ._base import Transport

__all__ = ["SerialTransport"]

logger = logging.getLogger(__name__)


def _import_serial() -> Any:
    """Import and return ``serial.Serial``, raising a helpful error if
    pyserial is not installed.
    """
    try:
        import serial  # type: ignore[import-untyped]  # noqa: F811

        return serial.Serial
    except ImportError as exc:
        raise SerialNotAvailableError(
            "pyserial is required for serial connections. "
            "Install it with: pip install uam-05lp[serial]"
        ) from exc


class SerialTransport(Transport):
    """Transport over USB/Serial (pyserial).

    Args:
        port: Serial port name (e.g. ``/dev/ttyUSB0`` or ``COM3``).
        baudrate: Communication baud rate.
        connect_timeout_s: Read timeout for the serial port.
    """

    def __init__(
        self,
        port: str,
        baudrate: int = 115200,
        *,
        connect_timeout_s: float = 3.0,
    ) -> None:
        self._port = port
        self._baudrate = baudrate
        self._connect_timeout = connect_timeout_s
        self._serial: Any | None = None
        self._buffer = bytearray()

    def open(self) -> None:
        """Open the serial port."""
        if self._serial is not None:
            return
        serial_cls = _import_serial()
        logger.info("Opening serial port %s at %d baud", self._port, self._baudrate)
        try:
            self._serial = serial_cls(
                port=self._port,
                baudrate=self._baudrate,
                timeout=self._connect_timeout,
            )
            self._buffer.clear()
        except OSError as exc:
            msg = f"Failed to open serial port {self._port}: {exc}"
            raise TransportError(msg) from exc
        logger.info("Serial port %s opened", self._port)

    def close(self) -> None:
        """Close the serial port."""
        if self._serial is not None:
            logger.info("Closing serial port %s", self._port)
            with contextlib.suppress(OSError):
                self._serial.close()
            self._serial = None
            self._buffer.clear()

    def send(self, data: bytes) -> int:
        """Send *data* over the serial port.

        Raises:
            TransportError: If not connected or write fails.
        """
        if self._serial is None:
            raise TransportError("Not connected")
        try:
            written = self._serial.write(data)
            n = written if written is not None else 0
            logger.debug("Sent %d bytes", n)
            return n
        except OSError as exc:
            raise TransportError(f"Send failed: {exc}") from exc

    def receive_frame(self, timeout_ms: int) -> bytes:
        """Read bytes until a complete STX...ETX frame is found.

        Returns:
            Frame bytes including STX but excluding ETX.

        Raises:
            TimeoutError: If no complete frame arrives in time.
            TransportError: On serial port errors.
        """
        if self._serial is None:
            raise TransportError("Not connected")

        deadline = time.monotonic() + timeout_ms / 1000.0

        while True:
            stx_pos = self._buffer.find(STX)
            if stx_pos >= 0:
                etx_pos = self._buffer.find(ETX, stx_pos + 1)
                if etx_pos >= 0:
                    frame = bytes(self._buffer[stx_pos:etx_pos])
                    del self._buffer[: etx_pos + 1]
                    logger.debug("Received frame (%d bytes)", len(frame))
                    return frame

            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError(
                    f"No complete frame received within {timeout_ms}ms"
                )

            self._serial.timeout = remaining
            try:
                chunk = self._serial.read(4096)
            except OSError as exc:
                raise TransportError(f"Receive failed: {exc}") from exc

            if not chunk:
                raise TimeoutError(
                    f"No complete frame received within {timeout_ms}ms"
                )

            self._buffer.extend(chunk)

    @property
    def is_open(self) -> bool:
        """Whether the serial port is currently open."""
        return self._serial is not None and self._serial.is_open
