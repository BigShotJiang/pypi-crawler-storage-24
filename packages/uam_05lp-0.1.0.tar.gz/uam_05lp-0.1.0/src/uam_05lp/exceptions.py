"""Exception hierarchy for the UAM-05LP library."""

from __future__ import annotations

__all__ = [
    "UAMError",
    "ConnectionError",
    "TimeoutError",
    "CRCError",
    "FrameError",
    "SensorError",
    "ContinuousModeError",
    "TransportError",
    "SerialNotAvailableError",
]


class UAMError(Exception):
    """Base exception for all UAM-05LP errors."""


class ConnectionError(UAMError):
    """Failed to connect to the sensor."""


class TimeoutError(UAMError):
    """No response received within the timeout period."""


class CRCError(UAMError):
    """CRC mismatch in received frame."""


class FrameError(UAMError):
    """Malformed frame received."""


class SensorError(UAMError):
    """Sensor returned a non-OK status code.

    Attributes:
        status_code: The numeric status code returned by the sensor.
    """

    def __init__(self, message: str, status_code: int) -> None:
        super().__init__(message)
        self.status_code = status_code


class ContinuousModeError(UAMError):
    """Failed to start or stop continuous mode."""


class TransportError(UAMError):
    """Low-level I/O error in the transport layer."""


class SerialNotAvailableError(UAMError):
    """pyserial package is not installed.

    Install it with: ``pip install uam-05lp[serial]``
    """
