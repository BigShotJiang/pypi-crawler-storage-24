"""Frame building, parsing, and CRC validation for the UAM protocol.

Frame format (command, no data)::

    STX(1) + Length(4hex) + Header(2) + SubHeader(2)
    + CRC(4hex) + ETX(1)   [total 14 bytes]

Frame format (reply)::

    STX(1) + Length(4hex) + Header(2) + SubHeader(2)
    + Status(2) + [Data(N)] + CRC(4hex) + ETX(1)

Note: Status comes immediately **after** the SubHeader, **before**
the data payload.  This is confirmed by the C reference library
(``body_offset = 1 + 4 + 4 + 2``, ``status1 = 9``, ``status2 = 10``).
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

from ._constants import (
    AREA_NUMBER_OFFSET,
    CRC_SIZE,
    ERROR_CODE_OFFSET,
    ETX,
    LENGTH_SIZE,
    MAX_DETECTION_LOG_ENTRIES,
    MAX_ERROR_LOG_ENTRIES,
    STX,
)
from ._crc import compute_crc
from .exceptions import CRCError, FrameError, SensorError
from .models import (
    ConfigId,
    DetectionLogEntry,
    DetectionLogIO,
    ErrorLogData,
    SafetyData,
    SlaveDeviceState,
    StatusData,
    VersionInfo,
)

__all__ = [
    "ParsedFrame",
    "build_frame",
    "check_status",
    "parse_area_reply",
    "parse_config_id",
    "parse_detection_log",
    "parse_distance_data",
    "parse_error_log",
    "parse_frame",
    "parse_safety_data",
    "parse_status_data",
    "parse_version_reply",
]

logger = logging.getLogger(__name__)

# Offsets within the frame string (after STX is removed):
#   [0:4]  = Length
#   [4:6]  = Header
#   [6:8]  = SubHeader
#   [8:10] = Status       <-- right after SubHeader
#   [10:]  = Data ... CRC
_HEADER_OFFSET = LENGTH_SIZE          # 4
_SUBHEADER_OFFSET = LENGTH_SIZE + 2   # 6
_STATUS_OFFSET = LENGTH_SIZE + 4      # 8
_DATA_OFFSET = LENGTH_SIZE + 6        # 10

# Minimum response: STX + Length(4) + Header(2) + Sub(2) + Status(2) + CRC(4)
_MIN_RESPONSE_SIZE = 1 + LENGTH_SIZE + 2 + 2 + 2 + CRC_SIZE  # 15


@dataclass(frozen=True, slots=True)
class ParsedFrame:
    """Result of parsing a raw response frame."""

    header: str
    subheader: str
    data: str
    status: str


def build_frame(header: str, subheader: str, data: str = "") -> bytes:
    """Build a command frame with CRC, ready to send.

    Args:
        header: Two-character command header (e.g. ``"AR"``).
        subheader: Two-character sub-header (e.g. ``"00"``).
        data: Optional data payload.

    Returns:
        Complete frame bytes including STX and ETX.
    """
    command = header + subheader + data
    message_size = 1 + LENGTH_SIZE + len(command) + CRC_SIZE + 1
    length_str = f"{message_size:04X}"

    crc_payload = (length_str + command).encode("ascii")
    crc = compute_crc(crc_payload)
    crc_str = f"{crc:04X}"

    body = f"{length_str}{command}{crc_str}".encode("ascii")
    frame = bytes([STX]) + body + bytes([ETX])
    logger.debug("Built frame: %s%s (%d bytes)", header, subheader, len(frame))
    return frame


def parse_frame(raw: bytes) -> ParsedFrame:
    """Validate CRC and extract fields from a response frame.

    The *raw* bytes must include STX but **not** ETX (the transport
    layer strips ETX before handing the frame to this function).

    The response format is::

        STX + Length(4) + Header(2) + SubHeader(2) + Status(2)
        + [Data] + CRC(4)

    Status is at positions 8–9 in the frame string (after STX),
    immediately after the SubHeader.

    Args:
        raw: Raw frame bytes (STX-inclusive, ETX-exclusive).

    Returns:
        Parsed frame with header, subheader, data, and status fields.

    Raises:
        FrameError: If the frame is malformed.
        CRCError: If the CRC does not match.
    """
    if len(raw) < _MIN_RESPONSE_SIZE:
        raise FrameError(
            f"Frame too short: {len(raw)} bytes (minimum {_MIN_RESPONSE_SIZE})"
        )

    if raw[0] != STX:
        raise FrameError(f"Expected STX (0x02), got 0x{raw[0]:02X}")

    frame_str = raw[1:].decode("ascii", errors="replace")

    # CRC validation
    crc_field = frame_str[-CRC_SIZE:]
    try:
        received_crc = int(crc_field, 16)
    except ValueError as exc:
        raise FrameError(f"Invalid CRC field: {crc_field!r}") from exc

    crc_data = raw[1 : len(raw) - CRC_SIZE]
    computed_crc = compute_crc(crc_data)

    if received_crc != computed_crc:
        raise CRCError(
            f"CRC mismatch: received 0x{received_crc:04X}, "
            f"computed 0x{computed_crc:04X}"
        )

    # Extract fields — Status is RIGHT AFTER SubHeader
    header = frame_str[_HEADER_OFFSET : _HEADER_OFFSET + 2]
    subheader = frame_str[_SUBHEADER_OFFSET : _SUBHEADER_OFFSET + 2]
    status = frame_str[_STATUS_OFFSET : _STATUS_OFFSET + 2]
    data = frame_str[_DATA_OFFSET : -CRC_SIZE]

    logger.debug(
        "Parsed frame: %s%s status=%s data_len=%d",
        header, subheader, status, len(data),
    )
    return ParsedFrame(
        header=header, subheader=subheader, data=data, status=status,
    )


def check_status(frame: ParsedFrame) -> None:
    """Raise :class:`SensorError` if the reply status is not ``"00"``.

    Args:
        frame: A parsed response frame.

    Raises:
        SensorError: With the numeric status code.
    """
    if frame.status != "00":
        code = int(frame.status, 16)
        raise SensorError(
            f"Sensor returned error status 0x{code:02X} "
            f"for command {frame.header}{frame.subheader}",
            status_code=code,
        )


# ---------------------------------------------------------------------------
# Data parsers
# ---------------------------------------------------------------------------

def parse_safety_data(data: str) -> SafetyData:
    """Parse the 33-character safety data block from AR responses.

    The field layout (character offsets) is documented in the UAM-05LP
    communication specification, Section 6.2, Table 6.2.2.

    Args:
        data: 33-character ASCII string from the AR response body.

    Returns:
        Populated :class:`SafetyData` instance.
    """
    return SafetyData(
        operating_mode=int(data[0]),
        area_number=int(data[1:3], 16) + AREA_NUMBER_OFFSET,
        error_detected=data[3] == "1",
        error_code=int(data[4:6], 16) + ERROR_CODE_OFFSET,
        lockout=data[6] == "1",
        ossd1=data[7] == "1",
        ossd2=data[8] == "1",
        warning1=data[9] == "1",
        warning2=data[10] == "1",
        ossd3=data[11] == "1",
        ossd4=data[12] == "1",
        # positions 13-14 are reserved
        muting_override1=data[15] == "1",
        muting_override2=data[16] == "1",
        reset_request1=data[17] == "1",
        reset_request2=data[18] == "1",
        encoder_speed=int(data[19:23], 16),
        timestamp=int(data[23:31], 16),
        laser_off=data[31] == "1",
        optical_window_contamination=data[32] == "1",
    )


def parse_distance_data(data: str, count: int) -> tuple[int, ...]:
    """Parse hex-encoded distance values (4 hex chars each).

    Args:
        data: Hex string of concatenated 4-char distance values.
        count: Number of distance values to parse.

    Returns:
        Tuple of integer distance values in mm.
    """
    return tuple(int(data[i * 4 : i * 4 + 4], 16) for i in range(count))


def parse_version_reply(data: str) -> VersionInfo:
    """Parse the VR00 response data into a :class:`VersionInfo`.

    The response is a fixed-layout string with fields at known offsets
    (derived from the C library: product_type at offset 0,
    firmware_version at offset 30, serial_number at offset 98).

    Args:
        data: Data field from the VR00 response frame.

    Returns:
        Populated :class:`VersionInfo` instance.
    """
    # Product type: offset 0, space-terminated
    pt_end = data.index(" ") if " " in data else len(data)
    product_type = data[:pt_end]

    # Firmware version: offset 30, space-terminated
    fw_start = 30
    fw_data = data[fw_start:]
    fw_end = fw_data.index(" ") if " " in fw_data else len(fw_data)
    firmware_version = fw_data[:fw_end]

    # Serial number: 8 chars starting at offset 98
    serial_number = data[98:106]

    return VersionInfo(
        product_type=product_type,
        firmware_version=firmware_version,
        serial_number=serial_number,
    )


def parse_status_data(data: str) -> StatusData:
    """Parse the XR00 response data into a :class:`StatusData`.

    Includes master device fields and up to three slave device states.
    Field offsets match the C library's ``safety_receive_status_data``.

    Args:
        data: Data field from the XR00 response frame.

    Returns:
        Populated :class:`StatusData` instance.
    """
    slave1 = SlaveDeviceState(
        ossd12_on=data[24] == "1",
        ossd34_on=data[27] == "1",
        warning1_on=data[30] == "1",
        warning2_on=data[33] == "1",
        error_detected=data[36] == "1",
        laser_off=data[39] == "1",
    )
    slave2 = SlaveDeviceState(
        ossd12_on=data[25] == "1",
        ossd34_on=data[28] == "1",
        warning1_on=data[31] == "1",
        warning2_on=data[34] == "1",
        error_detected=data[37] == "1",
        laser_off=data[40] == "1",
    )
    slave3 = SlaveDeviceState(
        ossd12_on=data[26] == "1",
        ossd34_on=data[29] == "1",
        warning1_on=data[32] == "1",
        warning2_on=data[35] == "1",
        error_detected=data[38] == "1",
        laser_off=data[41] == "1",
    )

    return StatusData(
        operating_mode=int(data[0]),
        area_number=int(data[1:3], 16) + AREA_NUMBER_OFFSET,
        error_detected=data[3] == "1",
        error_code=int(data[4:6], 16) + ERROR_CODE_OFFSET,
        lockout=data[6] == "1",
        ossd1=data[7] == "1",
        ossd2=data[8] == "1",
        warning1=data[9] == "1",
        warning2=data[10] == "1",
        ossd3=data[11] == "1",
        ossd4=data[12] == "1",
        muting_override1=data[15] == "1",
        muting_override2=data[16] == "1",
        reset_request1=data[17] == "1",
        reset_request2=data[18] == "1",
        encoder_speed=int(data[19:23], 16),
        laser_off=data[23] == "1",
        slave1=slave1,
        slave2=slave2,
        slave3=slave3,
        timestamp=int(data[42:50], 16),
        optical_window_contamination=data[50] == "1",
    )


def _parse_log_io(raw: int) -> DetectionLogIO:
    """Parse a 16-bit log I/O value into a :class:`DetectionLogIO`."""
    return DetectionLogIO(
        area_number=(raw & 0xFF) + AREA_NUMBER_OFFSET,
        protection1_state=bool((raw >> 12) & 1),
        protection2_state=bool((raw >> 13) & 1),
    )


def parse_detection_log(data: str) -> list[DetectionLogEntry]:
    """Parse 30 detection log entries from DL00 response data.

    Each entry occupies 64 hex characters in the data field.

    Args:
        data: Data field from the DL00 response frame.

    Returns:
        List of up to 30 :class:`DetectionLogEntry` instances.
    """
    entries: list[DetectionLogEntry] = []
    for i in range(MAX_DETECTION_LOG_ENTRIES):
        offset = i * 64
        entry_data = data[offset : offset + 64]
        if len(entry_data) < 64:
            break

        io_raw = int(entry_data[0:4], 16)
        slave1_raw = int(entry_data[20:24], 16)
        slave2_raw = int(entry_data[32:36], 16)
        slave3_raw = int(entry_data[44:48], 16)

        entries.append(
            DetectionLogEntry(
                io=_parse_log_io(io_raw),
                protection1_min_dist=int(entry_data[4:8], 16),
                protection1_min_dist_step=int(entry_data[8:12], 16),
                protection2_min_dist=int(entry_data[12:16], 16),
                protection2_min_dist_step=int(entry_data[16:20], 16),
                slave1_io=_parse_log_io(slave1_raw),
                slave2_io=_parse_log_io(slave2_raw),
                slave3_io=_parse_log_io(slave3_raw),
                timestamp=int(entry_data[56:64], 16),
            )
        )
    return entries


def parse_error_log(data: str) -> ErrorLogData:
    """Parse 64 RAM + 64 ROM error codes from ER01 response data.

    Each error is 4 hex characters.  Non-zero values have
    :data:`ERROR_CODE_OFFSET` (+0x40) applied; zero slots are filtered out.

    Args:
        data: Data field from the ER01 response frame (512 hex chars).

    Returns:
        :class:`ErrorLogData` with non-zero RAM and ROM error codes.
    """
    ram: list[int] = []
    for i in range(MAX_ERROR_LOG_ENTRIES):
        val = int(data[i * 4 : i * 4 + 4], 16)
        if val:
            ram.append(val + ERROR_CODE_OFFSET)

    rom_offset = MAX_ERROR_LOG_ENTRIES * 4
    rom: list[int] = []
    for i in range(MAX_ERROR_LOG_ENTRIES):
        val = int(data[rom_offset + i * 4 : rom_offset + i * 4 + 4], 16)
        if val:
            rom.append(val + ERROR_CODE_OFFSET)

    return ErrorLogData(ram_errors=tuple(ram), rom_errors=tuple(rom))


def parse_area_reply(data: str) -> list[int]:
    """Parse area distance data from a YR response.

    Args:
        data: Hex string of concatenated 4-char distance values.

    Returns:
        List of integer distance values in mm.
    """
    count = len(data) // 4
    return [int(data[i * 4 : i * 4 + 4], 16) for i in range(count)]


def parse_config_id(data: str) -> ConfigId:
    """Parse the ID00 response into a :class:`ConfigId`.

    Args:
        data: Data field from the ID00 response (16 hex chars).

    Returns:
        :class:`ConfigId` with two 8-character ID strings.
    """
    return ConfigId(id1=data[:8], id2=data[8:16])
