# Django management module
