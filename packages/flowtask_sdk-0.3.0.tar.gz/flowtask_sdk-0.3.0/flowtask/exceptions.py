class FlowTaskError(Exception):
    """Base exception for FlowTask SDK."""

    def __init__(self, message: str, code: str = "UNKNOWN", status: int = 500):
        self.message = message
        self.code = code
        self.status = status
        super().__init__(message)


class AuthenticationError(FlowTaskError):
    """Raised when authentication fails (invalid or missing token)."""
    pass


class ValidationError(FlowTaskError):
    """Raised when input validation fails."""
    pass


class NotFoundError(FlowTaskError):
    """Raised when a resource is not found."""
    pass


class CycleDetectedError(FlowTaskError):
    """Raised when creating a dependency would form a cycle."""
    pass
