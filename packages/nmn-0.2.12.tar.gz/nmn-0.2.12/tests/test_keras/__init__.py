# Test Keras implementations
