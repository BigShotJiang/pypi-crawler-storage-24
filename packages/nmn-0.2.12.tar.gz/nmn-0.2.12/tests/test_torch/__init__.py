# Test PyTorch implementations
