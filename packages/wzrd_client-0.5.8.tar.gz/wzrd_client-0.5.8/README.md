# wzrd-client

Python client for the **WZRD velocity oracle** — real-time AI model adoption signals on Solana.

```bash
pip install wzrd-client
```

### Read the oracle (1 line)
```python
model = wzrd.pick("code")  # → "Qwen/Qwen3.5-27B"
```

### Stream CCM by contributing (1 line)
```python
wzrd.run_loop(keypair="~/.solana/id.json")
# authenticates, picks models, reports, claims CCM — runs forever
```

WZRD is a velocity oracle for open-source AI models. It measures developer adoption across HuggingFace, GitHub, OpenRouter, and ArtificialAnalysis. 15 Switchboard feeds on Solana mainnet. Free to read. Agents stream CCM by contributing.

```text
GET https://api.twzrd.xyz/v1/signals/momentum
```

Verify on-chain (any Switchboard feed):
```bash
solana account AepiFwnbfCvXwA5gtAysMaxoqdwsGiYCN6gFBLGqZf1S --output json
```

Premium data (velocity_ema, acceleration, quality): set `WZRD_API_URL=https://api.twzrd.xyz/v1/signals/momentum/premium`

## Use as a routing prior

Read the oracle before calling an inference provider:

```python
model = wzrd.pick("code")
models = wzrd.shortlist("chat")
details = wzrd.pick_details("reasoning")
```

Works with any provider. Pass the result to OpenRouter, OpenAI, Anthropic, HuggingFace, or your own router.

## Candidate-aware routing

```python
model = wzrd.pick(
    "code",
    candidates=[
        "openrouter/qwen/qwen3.5-9b",
        "openrouter/qwen/qwen3.5-35b-a3b",
        "anthropic/claude-sonnet-4.6",
    ],
)
```

## Optional rewards while reporting

If you want an agent to authenticate, report routing decisions, and participate in WZRD rewards:

```python
import wzrd

choice = wzrd.pick_details("code")

agent = wzrd.WZRDAgent.from_env()
session = agent.authenticate()
receipt = agent.report_pick(choice, quality_score=0.9, latency_ms=1200)
reward_status = agent.earned()

print(session.pubkey)
print(receipt["contribution_id"])
print(reward_status["signup_bonus_ccm"])
```

No manual onboarding is required. Agents can authenticate with their own Solana keypair, report real routing decisions, and claim rewards through the gasless relay when available.

## Router wrapper

If you want a thin client wrapper, use `WZRDRouter` from `wzrd.router`.
It only wraps clients that expose `client.chat.completions.create(...)`.
Explicit model names pass through unchanged. To trigger WZRD routing, pass `model=None` or a task sentinel like `model="code"` or `model="chat"`.

## Automatic reward loop

```python
import wzrd

wzrd.run_loop()  # picks, reports, checks rewards, claims when available
```

`run_loop()` is the batteries-included path for unattended reporting. It uses the public momentum feed by default and can be pointed at premium explicitly via `WZRD_API_URL`.

## Agent auth

`WZRDAgent.authenticate()` signs the exact server challenge message and sends the signature in the Solana base58 format the API expects. Keypair loading supports:

- `~/.config/solana/id.json`
- `WZRD_AGENT_KEYPAIR_PATH` or `SOLANA_KEYPAIR_PATH`
- `WZRD_AGENT_KEYPAIR` or `SOLANA_KEYPAIR` as a base58 secret or JSON byte array

Authenticated helpers:

- `agent.challenge()` returns the nonce + message format
- `agent.authenticate()` stores the Bearer token on the client
- `agent.status()` reads `/v1/agent/status`
- `agent.earned()` reads `/v1/agent/earned` and surfaces signup bonus + reward status
- `agent.report(...)` posts a manual contribution
- `agent.report_pick(choice, ...)` reports a `pick_details()` result with WZRD metadata attached

The signup bonus is recorded on first auth, then becomes claimable after the next merkle publication cycle.

## Environment variables

- `WZRD_API_URL`: signal endpoint override. Defaults to the public momentum feed.
- `WZRD_API_BASE_URL`: API root for agent auth/report calls
- `WZRD_AGENT_TOKEN`: existing Bearer token for `WZRDAgent`
- `WZRD_AGENT_KEYPAIR_PATH`: path to Solana JSON keypair
- `WZRD_AGENT_KEYPAIR`: Solana base58 secret or JSON byte array
- `WZRD_TIMEOUT_SECONDS`: request timeout
- `WZRD_CACHE_TTL_SECONDS`: cache TTL for fetched signals
- `WZRD_FEED_LIMIT`: number of feed rows to request

## Verify on-chain

WZRD data is published to 15 Switchboard pull oracle feeds on Solana mainnet. You can verify any signal independently:

```bash
# Query the Qwen 3.5 9B velocity feed directly on-chain
solana account AepiFwnbfCvXwA5gtAysMaxoqdwsGiYCN6gFBLGqZf1S --output json

# Or view on Solscan:
# https://solscan.io/account/AepiFwnbfCvXwA5gtAysMaxoqdwsGiYCN6gFBLGqZf1S
```

Sample feeds (quote accounts):
| Model | Address |
|-------|---------|
| Qwen 3.5 9B | `AepiFwnbfCvXwA5gtAysMaxoqdwsGiYCN6gFBLGqZf1S` |
| Llama 3.3 70B | `6EgRwhE6db1Aqsxzmp9wj6QH2y5ZEji1xe1YdovwmD9g` |
| Kimi K2.5 | `5xmwRtTgcCz6R2KapxpEXVjCNcZCpe24DnCC295S769w` |
| Qwen3.5-397B MoE | `HYZBFKo944a6NzjeKWnfGUJnrHYjDDaRY3q42GW1ECik` |

Full feed registry with all 15 velocity + 2 price feeds is available via `wzrd.oracle.list_feeds()`.

## What it returns

- `pick()` returns a model name string
- `pick_details()` returns a structured record
- `shortlist()` returns ranked records
- `compare()` explains the relative signal strength between two models
- `WZRDAgent` authenticates an agent wallet and reports contributions for rewards
