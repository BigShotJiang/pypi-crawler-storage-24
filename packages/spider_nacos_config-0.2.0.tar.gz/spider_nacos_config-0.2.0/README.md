# spider_nacos_config

`spider_nacos_config` is a Python package for loading spider-related configs from Nacos and exposing them as Python variables.

## Install

```bash
pip install spider_nacos_config
```

## Quick Start

Direct import of config variables:

```python
from spider_nacos_config import PUBLIC_ENV, INNO_ENV, DATA_DB_HOST

print(PUBLIC_ENV, INNO_ENV, DATA_DB_HOST)
```

Use the settings object:

```python
from spider_nacos_config import nacos_settings

print(nacos_settings.PUBLIC_ENV)
print(nacos_settings.DATA_DB_HOST)
```

## Environment Variables

Set the following before import:

- `NACOS_ADDR`
- `NACOS_SPIDER_ACCESS_KEY`
- `NACOS_SPIDER_SECRET_KEY`
- `NACOS_NAMESPACE` (optional, default: `qa`)
- `NACOS_SPIDER_NAMESPACE` (optional, default: `qa-spider`)

## Add New Config Mapping

To add a new mysql/redis/rabbitmq config, update `spider_nacos_config/base_config.py` in `NACOS_CONFIG_MAP`.

For mysql entries, if the name follows `*_mysql`, mount prefix can be inferred automatically.

## Build And Upload (PyPI)

```bash
python -m pip install --upgrade build twine
python -m build
python -m twine check dist/*
python -m twine upload dist/*
```

## Version

Current package version: `0.2.0`
