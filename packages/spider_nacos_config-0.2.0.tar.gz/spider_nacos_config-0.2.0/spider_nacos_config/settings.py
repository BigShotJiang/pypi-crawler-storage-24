# -*- coding: utf-8 -*-
import logging
from functools import lru_cache

logger = logging.getLogger(__name__)
from .base_config import (
    LOCAL_ENV,
    NACOS_CONFIG_MAP,
    get_nacos_config_meta,
    spider_nacos_access_key,
    spider_nacos_secret_key,
)
from .nacos_tools import NacosSpiderPublicConfigLoader


class Settings:
    def __init__(self, local_env: bool = LOCAL_ENV):
        self.local_env = local_env

        self._loader = NacosSpiderPublicConfigLoader(
            spider_nacos_access_key,
            spider_nacos_secret_key,
        )
        self._config_cache = {}

        self._load_default_configs()

    def _fetch(self, name: str):
        if name not in self._config_cache:
            try:
                conf = self._loader.get_config_by_name(
                    name=name,
                    local_env=self.local_env,
                )
                if not conf:
                    logger.warning(f"[nacos] config '{name}' is empty")

                self._config_cache[name] = conf or {}

            except Exception as e:
                logger.warning(f"[nacos] load config '{name}' failed: {e}")
                self._config_cache[name] = {}
        return self._config_cache[name]

    def _load_default_configs(self):
        for config_name in NACOS_CONFIG_MAP.keys():
            self._mount_registered_config(config_name)

    @staticmethod
    def _guess_mount_prefix(name: str, config_type: str):
        if config_type == "mysql" and name.endswith("_mysql"):
            return f"{name[:-6].upper()}_DB"
        if config_type == "redis" and name.endswith("_redis"):
            return name[:-6].upper()
        if config_type == "rabbitmq" and name.endswith("_rabbitmq"):
            return name[:-9].upper()
        return None

    def _mount_registered_config(self, name: str):
        """
        按 base_config.NACOS_CONFIG_MAP 中的 type/mount_prefix 自动挂载。
        新增 mysql/redis/rabbitmq 时，只需在 NACOS_CONFIG_MAP 增加一项。
        """
        meta = get_nacos_config_meta(name)
        config_type = meta.get("type", "env")
        mount_prefix = meta.get("mount_prefix") or self._guess_mount_prefix(name, config_type)
        conf = self._fetch(name)

        if config_type == "env":
            self._load_public(conf)
            return

        if config_type == "mysql":
            if not mount_prefix:
                logger.warning(f"[nacos] config '{name}' missing mount_prefix")
                return
            self._load_mysql(mount_prefix, conf)
            return

        if config_type == "redis":
            if not mount_prefix:
                logger.warning(f"[nacos] config '{name}' missing mount_prefix")
                return
            self._load_redis(mount_prefix, conf)
            return

        if config_type == "rabbitmq":
            if not mount_prefix:
                logger.warning(f"[nacos] config '{name}' missing mount_prefix")
                return
            self._load_rabbitmq(mount_prefix, conf)
            return

        logger.warning(
            f"[nacos] config '{name}' type '{config_type}' is not auto-mounted"
        )

    def _load_public(self, spider_public: dict):
        self.PUBLIC_ENV = spider_public.get("PUBLIC_ENV")
        self.INNO_ENV = spider_public.get("INNO_ENV")

        self.SPIDER_NODE_SERVICE_URL = spider_public.get("SPIDER_NODE_SERVICE_URL")
        self.ONSHORE_FILE_SERVICE_URL = spider_public.get("ONSHORE_FILE_SERVICE_URL")
        self.ONSHORE_OFFICE_SERVICE_URL = spider_public.get("ONSHORE_OFFICE_SERVICE_URL")
        self.SPIDER_COMMON_API_SERVICE_URL = spider_public.get("SPIDER_COMMON_API_SERVICE_URL")
        self.SPIDER_PROXY_SERVICE_URL = spider_public.get("SPIDER_PROXY_SERVICE_URL")
        self.SPIDER_REDIS_MANAGER_SERVICE_URL = spider_public.get("SPIDER_REDIS_MANAGER_SERVICE_URL")
        self.SPIDER_RABBIT_MANAGER_SERVICE_URL = spider_public.get("SPIDER_RABBIT_MANAGER_SERVICE_URL")
        self.SPIDER_JS_ENV_URL = spider_public.get("SPIDER_JS_ENV_URL")
        self.REDIS_SPIDER_SERVICE_URL = spider_public.get("REDIS_SPIDER_SERVICE_URL")
        self.INTERNATIONAL_REDIS_SPIDER_SERVICE_URL = spider_public.get("INTERNATIONAL_REDIS_SPIDER_SERVICE_URL")
        self.NEWS_FORWARD_SERVER_URL = spider_public.get("NEWS_FORWARD_SERVER_URL")
        self.SPIDER_DRISSIONPAGE_SERVICE_URL = spider_public.get("SPIDER_DRISSIONPAGE_SERVICE_URL")
        self.SPIDER_SINGLE_PROXY_URL = spider_public.get("SPIDER_SINGLE_PROXY_URL")
        self.DEFAULT_BROWSER_PATH = spider_public.get("DEFAULT_BROWSER_PATH")
        self.INTERNATIONAL_FILE_SERVICE_URL = spider_public.get("INTERNATIONAL_FILE_SERVICE_URL")
        self.OSS_BUCKET_NAME = spider_public.get("OSS_BUCKET_NAME")

        self.SPIDER_EMAIL_RECEIVER = spider_public.get("SPIDER_EMAIL_RECEIVER") or []
        self.SPIDER_EMAIL_SENDER = spider_public.get("SPIDER_EMAIL_SENDER")
        self.SPIDER_EMAIL_PASSWORD = spider_public.get("SPIDER_EMAIL_PASSWORD")
        self.SPIDER_EMAIL_SMTP_SERVER = spider_public.get("SPIDER_EMAIL_SMTP_SERVER")
        self.SPIDER_PROD_RECEIVER = spider_public.get("SPIDER_PROD_RECEIVER")
        self.SPIDER_EMAIL_PORT = spider_public.get("SPIDER_EMAIL_PORT")
        self.SPIDER_RABBITMQ_DB_CONSUMER = spider_public.get("SPIDER_RABBITMQ_DB_CONSUMER")
        self.JIEMA_TOKEN = spider_public.get("JIEMA_TOKEN")
        self.AUTHOR_DICT = spider_public.get("AUTHOR_DICT") or {}

        # 自动补充公开配置中的新字段，避免每次新增变量都改代码
        for key, value in spider_public.items():
            if key.startswith("_"):
                continue
            setattr(self, key, value)

    def _load_mysql(self, prefix: str, conf: dict):
        setattr(self, f"{prefix}_HOST", conf.get("host"))
        setattr(self, f"{prefix}_PORT", conf.get("port"))
        setattr(self, f"{prefix}_USER", conf.get("user"))
        setattr(self, f"{prefix}_PASSWORD", conf.get("password"))
        setattr(self, f"{prefix}_NAME", conf.get("db"))

    def _load_redis(self, prefix: str, conf: dict):
        host = conf.get("host")
        port = conf.get("port")
        user = conf.get("user")
        password = conf.get("password")
        db = conf.get("db")

        # 你原来逻辑里 local_env 用不同 db，这里保留
        if db is None:
            db = 8 if self.local_env else 7

        setattr(self, f"{prefix}_HOST", host)
        setattr(self, f"{prefix}_PORT", port)
        setattr(self, f"{prefix}_USER", user)
        setattr(self, f"{prefix}_PASSWORD", password)
        setattr(self, f"{prefix}_DB", db)

        if user:
            redis_url = f"redis://{user}:{password}@{host}:{port}/{db}"
        elif password:
            redis_url = f"redis://:{password}@{host}:{port}/{db}"
        else:
            redis_url = f"redis://{host}:{port}/{db}"

        setattr(self, f"{prefix}_URL", redis_url)

    def _load_rabbitmq(self, prefix: str, conf: dict):
        setattr(self, f"{prefix}_HOST", conf.get("host"))
        setattr(self, f"{prefix}_PORT", conf.get("port"))
        setattr(self, f"{prefix}_USERNAME", conf.get("user"))
        setattr(self, f"{prefix}_PASSWORD", conf.get("password"))
        setattr(self, f"{prefix}_VHOST", conf.get("vhost", "/"))

        # 兼容一些项目里习惯用 RABBITMQ_ 前缀
        if prefix == "RABBIT":
            self.RABBITMQ_HOST = conf.get("host")
            self.RABBITMQ_PORT = conf.get("port")
            self.RABBITMQ_USERNAME = conf.get("user")
            self.RABBITMQ_PASSWORD = conf.get("password")
            self.RABBITMQ_VHOST = conf.get("vhost", "/")

    def get_config(self, name: str):
        """
        获取任意注册过的配置
        """
        return self._fetch(name)

    def mount_mysql(self, attr_prefix: str, config_name: str):
        """
        把新增 mysql 配置挂到 Settings 对象上
        例如：
            settings.mount_mysql("ARCHIVE_DB", "archive_mysql")
        """
        conf = self._fetch(config_name)
        self._load_mysql(attr_prefix, conf)

    def mount_redis(self, attr_prefix: str, config_name: str):
        """
        把新增 redis 配置挂到 Settings 对象上
        """
        conf = self._fetch(config_name)
        self._load_redis(attr_prefix, conf)

    def mount_rabbitmq(self, attr_prefix: str, config_name: str):
        """
        把新增 rabbitmq 配置挂到 Settings 对象上
        """
        conf = self._fetch(config_name)
        self._load_rabbitmq(attr_prefix, conf)

    def to_dict(self):
        return {
            k: v for k, v in self.__dict__.items()
            if not k.startswith("_")
        }

    def refresh(self, name: str = None):
        """
        刷新缓存：
        - name=None: 清空全部缓存并重载默认配置
        - name='spider_mysql': 只清某个配置缓存
        """
        if name is None:
            self._config_cache.clear()
            self._load_default_configs()
            return

        self._config_cache.pop(name, None)
        if name in NACOS_CONFIG_MAP:
            self._mount_registered_config(name)


@lru_cache(maxsize=2)
def get_settings(local_env: bool = LOCAL_ENV):
    return Settings(local_env=local_env)


nacos_settings = get_settings()
