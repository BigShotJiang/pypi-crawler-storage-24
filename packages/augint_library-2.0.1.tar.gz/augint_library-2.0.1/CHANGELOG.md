# CHANGELOG

<!-- version list -->

## v2.0.1 (2026-03-22)

### Bug Fixes

- Add setuptools to security group for semgrep compatibility
  ([#1](https://github.com/Augmenting-Integrations/augint-library/pull/1),
  [`2204356`](https://github.com/Augmenting-Integrations/augint-library/commit/220435602d77495b59b861bfa92344fe773a9e50))

- Handle uv export format in compliance report parsing
  ([#1](https://github.com/Augmenting-Integrations/augint-library/pull/1),
  [`2204356`](https://github.com/Augmenting-Integrations/augint-library/commit/220435602d77495b59b861bfa92344fe773a9e50))

- Resolve CI failures from ruff formatting and mutation testing permissions
  ([#1](https://github.com/Augmenting-Integrations/augint-library/pull/1),
  [`2204356`](https://github.com/Augmenting-Integrations/augint-library/commit/220435602d77495b59b861bfa92344fe773a9e50))

- Scope enforced security scans to production dependencies only
  ([#1](https://github.com/Augmenting-Integrations/augint-library/pull/1),
  [`2204356`](https://github.com/Augmenting-Integrations/augint-library/commit/220435602d77495b59b861bfa92344fe773a9e50))

- Use uvx for semgrep in CI to resolve version lock issue
  ([#1](https://github.com/Augmenting-Integrations/augint-library/pull/1),
  [`2204356`](https://github.com/Augmenting-Integrations/augint-library/commit/220435602d77495b59b861bfa92344fe773a9e50))


## v2.0.0 (2025-12-01)

### Chores

- Remove deprecated CUSTOMIZE.md file due to obsolescence and redundancy
  ([`fe57b2a`](https://github.com/Augmenting-Integrations/augint-library/commit/fe57b2a80a11427c4a84ccffdbb78ff28939988c))

### Breaking Changes

- Bump version for new repo


## v1.0.0 (2025-12-01)

- Initial Release

## v1.32.0 (2025-08-16)

### Features

- Add missing type hints and update dependencies
  ([#194](https://github.com/svange/augint-library/pull/194),
  [`8dd3199`](https://github.com/svange/augint-library/commit/8dd319958a8420ba2d7553ae3b0e4d33847ea742))

- Add missing type hints throughout codebase
  ([#194](https://github.com/svange/augint-library/pull/194),
  [`8dd3199`](https://github.com/svange/augint-library/commit/8dd319958a8420ba2d7553ae3b0e4d33847ea742))


## v1.31.0 (2025-08-10)

### Bug Fixes

- Resolve PT018 linting errors in PEP 561 compliance tests
  ([#188](https://github.com/svange/augint-library/pull/188),
  [`0526c06`](https://github.com/svange/augint-library/commit/0526c06fe9e3886a11d8ccfa7882f08bc056ebf1))

### Features

- Add pytest-watch for continuous testing and enhance Makefile with quick-test and watch targets
  ([#188](https://github.com/svange/augint-library/pull/188),
  [`0526c06`](https://github.com/svange/augint-library/commit/0526c06fe9e3886a11d8ccfa7882f08bc056ebf1))

- Update Makefile to improve watch mode for tests
  ([#188](https://github.com/svange/augint-library/pull/188),
  [`0526c06`](https://github.com/svange/augint-library/commit/0526c06fe9e3886a11d8ccfa7882f08bc056ebf1))


## v1.30.1 (2025-08-10)

### Documentation

- Add template stripping guide to CUSTOMIZE.md
  ([#187](https://github.com/svange/augint-library/pull/187),
  [`45d4969`](https://github.com/svange/augint-library/commit/45d4969b10a9db02597627ccf4d7ebb0f2eb8019))


## v1.30.0 (2025-08-10)

### Features

- Add sandbox environment variable and new Makefile target for Claude
  ([#185](https://github.com/svange/augint-library/pull/185),
  [`3dae09f`](https://github.com/svange/augint-library/commit/3dae09f7ef17a4d3ea73db7dc297ab4d02afd883))


## v1.29.6 (2025-08-08)

### Bug Fixes

- Resolve PT018 linting errors in PEP 561 compliance tests
  ([#184](https://github.com/svange/augint-library/pull/184),
  [`e04d4a5`](https://github.com/svange/augint-library/commit/e04d4a519919b0bc72d6337f070f3971b5aa33d4))


## v1.29.5 (2025-08-08)

### Bug Fixes

- Add return type annotations to test functions
  ([#183](https://github.com/svange/augint-library/pull/183),
  [`ef47e99`](https://github.com/svange/augint-library/commit/ef47e992ec52b6d5808c243747c7bd28fffd171c))


## v1.29.4 (2025-08-05)

### Bug Fixes

- Update test commands in Makefile and enhance README documentation
  ([#142](https://github.com/svange/augint-library/pull/142),
  [`b66491d`](https://github.com/svange/augint-library/commit/b66491dbd17fb9103f252296b56465eeff6c8af9))


## v1.29.3 (2025-08-04)

### Bug Fixes

- Add security workflow artifacts to .gitignore
  ([#141](https://github.com/svange/augint-library/pull/141),
  [`e20ed05`](https://github.com/svange/augint-library/commit/e20ed059de9a1c5ac6c3e68a6c9d5c2f1035dcfe))


## v1.29.2 (2025-08-04)

### Documentation

- Enhance documentation with comprehensive examples and Mermaid diagrams
  ([#139](https://github.com/svange/augint-library/pull/139),
  [`bbfd737`](https://github.com/svange/augint-library/commit/bbfd73790138f7b167e8b2b6c845ecca8a3a23e7))


## v1.29.1 (2025-08-04)

### Documentation

- Enhance documentation with comprehensive examples and Mermaid diagrams
  ([#136](https://github.com/svange/augint-library/pull/136),
  [`23c8762`](https://github.com/svange/augint-library/commit/23c87625bc5271059468bd921bfb57c759c9209f))


## v1.29.0 (2025-08-04)

### Bug Fixes

- Remove --print flag from semantic-release to enable actual releases
  ([#135](https://github.com/svange/augint-library/pull/135),
  [`943b57d`](https://github.com/svange/augint-library/commit/943b57dc83c3c6df967d71f4582399586a8b66c6))

- Update mutation testing workflow to use latest Poetry version
  ([#135](https://github.com/svange/augint-library/pull/135),
  [`943b57d`](https://github.com/svange/augint-library/commit/943b57dc83c3c6df967d71f4582399586a8b66c6))

### Features

- Add configurable merge strategy support
  ([#135](https://github.com/svange/augint-library/pull/135),
  [`943b57d`](https://github.com/svange/augint-library/commit/943b57dc83c3c6df967d71f4582399586a8b66c6))

- Replace Dependabot with Renovate for dependency management
  ([#135](https://github.com/svange/augint-library/pull/135),
  [`943b57d`](https://github.com/svange/augint-library/commit/943b57dc83c3c6df967d71f4582399586a8b66c6))

- Transform library from trivial examples to enterprise-ready modules
  ([#135](https://github.com/svange/augint-library/pull/135),
  [`943b57d`](https://github.com/svange/augint-library/commit/943b57dc83c3c6df967d71f4582399586a8b66c6))


## v1.28.0 (2025-08-03)

### Bug Fixes

- Remove --print flag from semantic-release to enable actual releases
  ([#134](https://github.com/svange/augint-library/pull/134),
  [`799d2a6`](https://github.com/svange/augint-library/commit/799d2a6bb425eae3f8e640d9ccdb66a1ea9e52ff))

- Update mutation testing workflow to use latest Poetry version
  ([#134](https://github.com/svange/augint-library/pull/134),
  [`799d2a6`](https://github.com/svange/augint-library/commit/799d2a6bb425eae3f8e640d9ccdb66a1ea9e52ff))

### Features

- Add configurable merge strategy support
  ([#134](https://github.com/svange/augint-library/pull/134),
  [`799d2a6`](https://github.com/svange/augint-library/commit/799d2a6bb425eae3f8e640d9ccdb66a1ea9e52ff))

- Replace Dependabot with Renovate for dependency management
  ([#134](https://github.com/svange/augint-library/pull/134),
  [`799d2a6`](https://github.com/svange/augint-library/commit/799d2a6bb425eae3f8e640d9ccdb66a1ea9e52ff))


## v1.27.0 (2025-08-03)

### Bug Fixes

- Remove --print flag from semantic-release to enable actual releases
  ([#133](https://github.com/svange/augint-library/pull/133),
  [`4e2a822`](https://github.com/svange/augint-library/commit/4e2a8226bcb3df7510e40cf0bb8d85078685e50a))

- Update mutation testing workflow to use latest Poetry version
  ([#133](https://github.com/svange/augint-library/pull/133),
  [`4e2a822`](https://github.com/svange/augint-library/commit/4e2a8226bcb3df7510e40cf0bb8d85078685e50a))

### Features

- Add configurable merge strategy support
  ([#133](https://github.com/svange/augint-library/pull/133),
  [`4e2a822`](https://github.com/svange/augint-library/commit/4e2a8226bcb3df7510e40cf0bb8d85078685e50a))


## v1.26.3 (2025-08-03)

### Bug Fixes

- Remove --print flag from semantic-release to enable actual releases
  ([#132](https://github.com/svange/augint-library/pull/132),
  [`4a894dd`](https://github.com/svange/augint-library/commit/4a894dd1bd96298f8ab06a416fe3ef65ea4fa066))

- Update mutation testing workflow to use latest Poetry version
  ([#132](https://github.com/svange/augint-library/pull/132),
  [`4a894dd`](https://github.com/svange/augint-library/commit/4a894dd1bd96298f8ab06a416fe3ef65ea4fa066))


## v1.26.2 (2025-08-03)

### Bug Fixes

- Remove --print flag from semantic-release to enable actual releases
  ([#131](https://github.com/svange/augint-library/pull/131),
  [`0f4668b`](https://github.com/svange/augint-library/commit/0f4668b655cccab323c691de6ac8285d4a4f6d4f))

- Update mutation testing workflow to use latest Poetry version
  ([#131](https://github.com/svange/augint-library/pull/131),
  [`0f4668b`](https://github.com/svange/augint-library/commit/0f4668b655cccab323c691de6ac8285d4a4f6d4f))


## v1.26.1 (2025-08-03)

### Bug Fixes

- Remove --print flag from semantic-release to enable actual releases
  ([#130](https://github.com/svange/augint-library/pull/130),
  [`67772f9`](https://github.com/svange/augint-library/commit/67772f91b8b41aa50cdd685a33404bf701ab3a00))

- Update mutation testing workflow to use latest Poetry version
  ([#130](https://github.com/svange/augint-library/pull/130),
  [`67772f9`](https://github.com/svange/augint-library/commit/67772f91b8b41aa50cdd685a33404bf701ab3a00))


## v1.26.0 (2025-08-02)

### Bug Fixes

- Add LoggingIntegration dummy for CI tests without sentry_sdk
  ([#128](https://github.com/svange/augint-library/pull/128),
  [`eed8390`](https://github.com/svange/augint-library/commit/eed83905d444072147c632786a4e17edbc7c29a3))

- Add missing newline to Dockerfile (pre-commit fix)
  ([#117](https://github.com/svange/augint-library/pull/117),
  [`edf692e`](https://github.com/svange/augint-library/commit/edf692e5e61881c389c66c66907be024fd205e29))

- Add missing newlines at end of files ([#117](https://github.com/svange/augint-library/pull/117),
  [`edf692e`](https://github.com/svange/augint-library/commit/edf692e5e61881c389c66c66907be024fd205e29))

- Add missing newlines at end of files ([#115](https://github.com/svange/augint-library/pull/115),
  [`828ea07`](https://github.com/svange/augint-library/commit/828ea07ee3169f9a603385730642f12f8b475218))

- Add missing newlines at end of files ([#113](https://github.com/svange/augint-library/pull/113),
  [`d6c5087`](https://github.com/svange/augint-library/commit/d6c50872e2f84fed38c106861c5a1d8da85397bc))

- Add missing newlines at end of files ([#111](https://github.com/svange/augint-library/pull/111),
  [`c1e47df`](https://github.com/svange/augint-library/commit/c1e47df5c7ff9ec80a7a25bbc9f24fef514f772e))

- Add missing newlines at end of files ([#110](https://github.com/svange/augint-library/pull/110),
  [`1dcfe0f`](https://github.com/svange/augint-library/commit/1dcfe0fb22d36c94d33cefc722f1cd210296a9a4))

- Add missing newlines at end of files ([#109](https://github.com/svange/augint-library/pull/109),
  [`a5f43db`](https://github.com/svange/augint-library/commit/a5f43db67d615a70d8909001fbe765ebf66ce85c))

- Add missing newlines to Dockerfile and docker-compose.yml
  ([#117](https://github.com/svange/augint-library/pull/117),
  [`edf692e`](https://github.com/svange/augint-library/commit/edf692e5e61881c389c66c66907be024fd205e29))

- Add missing newlines to Dockerfile and docker-compose.yml
  ([#115](https://github.com/svange/augint-library/pull/115),
  [`828ea07`](https://github.com/svange/augint-library/commit/828ea07ee3169f9a603385730642f12f8b475218))

- Add missing newlines to Dockerfile and docker-compose.yml
  ([#113](https://github.com/svange/augint-library/pull/113),
  [`d6c5087`](https://github.com/svange/augint-library/commit/d6c50872e2f84fed38c106861c5a1d8da85397bc))

- Add missing newlines to Dockerfile and docker-compose.yml
  ([#111](https://github.com/svange/augint-library/pull/111),
  [`c1e47df`](https://github.com/svange/augint-library/commit/c1e47df5c7ff9ec80a7a25bbc9f24fef514f772e))

- Add missing newlines to Dockerfile and docker-compose.yml
  ([#110](https://github.com/svange/augint-library/pull/110),
  [`1dcfe0f`](https://github.com/svange/augint-library/commit/1dcfe0fb22d36c94d33cefc722f1cd210296a9a4))

- Add type annotation for sentry_sdk to resolve CI mypy error
  ([#128](https://github.com/svange/augint-library/pull/128),
  [`eed8390`](https://github.com/svange/augint-library/commit/eed83905d444072147c632786a4e17edbc7c29a3))

- Address security scan and test failures
  ([#128](https://github.com/svange/augint-library/pull/128),
  [`eed8390`](https://github.com/svange/augint-library/commit/eed83905d444072147c632786a4e17edbc7c29a3))

- Address security scan and test failures
  ([#127](https://github.com/svange/augint-library/pull/127),
  [`85dc6ba`](https://github.com/svange/augint-library/commit/85dc6ba7cde0bff3cbb7cf22d39023fce63c217e))

- Align pipeline triggers with semantic-release configuration
  ([`c9a6d04`](https://github.com/svange/augint-library/commit/c9a6d04316034dfd2a886f815708a2a250874094))

- Auto-merge job fails with unstable PR status error
  ([#66](https://github.com/svange/augint-library/pull/66),
  [`2a3327a`](https://github.com/svange/augint-library/commit/2a3327a74ca69ac2ab518fc6eb963973bda7a69b))

- Clarify pipeline dependencies and update documentation
  ([#58](https://github.com/svange/augint-library/pull/58),
  [`c75f3dc`](https://github.com/svange/augint-library/commit/c75f3dc851327cc29176f78b62f3768bde2c2d55))

- Clean up auto-merge workflow for simplicity
  ([#56](https://github.com/svange/augint-library/pull/56),
  [`912bdc6`](https://github.com/svange/augint-library/commit/912bdc62a6bf43c9134a7bb6abe4116d7a620cb7))

- Consolidate auto-merge into main pipeline
  ([#58](https://github.com/svange/augint-library/pull/58),
  [`c75f3dc`](https://github.com/svange/augint-library/commit/c75f3dc851327cc29176f78b62f3768bde2c2d55))

- Consolidate auto-merge into main pipeline (closes #57)
  ([#58](https://github.com/svange/augint-library/pull/58),
  [`c75f3dc`](https://github.com/svange/augint-library/commit/c75f3dc851327cc29176f78b62f3768bde2c2d55))

- Correct protocol runtime_checkable test
  ([`9831ab6`](https://github.com/svange/augint-library/commit/9831ab6a54b78e58da6adf6b1c66910d056dd40d))

- Disable Dependabot Poetry updates due to resolver conflicts
  ([#82](https://github.com/svange/augint-library/pull/82),
  [`49c2077`](https://github.com/svange/augint-library/commit/49c207741982a39b88bc63fa512376da04b0d8ab))

- Eliminate DRY violation in stack naming logic
  ([#47](https://github.com/svange/augint-library/pull/47),
  [`49fb1a0`](https://github.com/svange/augint-library/commit/49fb1a04d9467a8a2d4b3073b0c6253fd6b48fa7))

- Enable security scanning and compliance reports on feature branches
  ([`f626b69`](https://github.com/svange/augint-library/commit/f626b69980d94f2e5f06bb9d7f328ebdbdc9e853))

- Extend OIDC trusted policy to include perf/*, docs/* and refactor/* branches
  ([`c4eef73`](https://github.com/svange/augint-library/commit/c4eef7384926d0bfe6bbc18b17b348a9a483bf51))

- Format test file for consistent style
  ([`9c2d257`](https://github.com/svange/augint-library/commit/9c2d25755bc082a88103aed566112b87c14d2576))

- Improve Git authentication in Docker environment
  ([#117](https://github.com/svange/augint-library/pull/117),
  [`edf692e`](https://github.com/svange/augint-library/commit/edf692e5e61881c389c66c66907be024fd205e29))

- Improve Git authentication in Docker environment
  ([#115](https://github.com/svange/augint-library/pull/115),
  [`828ea07`](https://github.com/svange/augint-library/commit/828ea07ee3169f9a603385730642f12f8b475218))

- Improve Git authentication in Docker environment
  ([#113](https://github.com/svange/augint-library/pull/113),
  [`d6c5087`](https://github.com/svange/augint-library/commit/d6c50872e2f84fed38c106861c5a1d8da85397bc))

- Improve Git authentication in Docker environment
  ([#111](https://github.com/svange/augint-library/pull/111),
  [`c1e47df`](https://github.com/svange/augint-library/commit/c1e47df5c7ff9ec80a7a25bbc9f24fef514f772e))

- Improve Git authentication in Docker environment
  ([#110](https://github.com/svange/augint-library/pull/110),
  [`1dcfe0f`](https://github.com/svange/augint-library/commit/1dcfe0fb22d36c94d33cefc722f1cd210296a9a4))

- Improve Git authentication in Docker environment
  ([#109](https://github.com/svange/augint-library/pull/109),
  [`a5f43db`](https://github.com/svange/augint-library/commit/a5f43db67d615a70d8909001fbe765ebf66ce85c))

- Improve Git authentication in Docker environment
  ([#108](https://github.com/svange/augint-library/pull/108),
  [`96a47ad`](https://github.com/svange/augint-library/commit/96a47ad1321613361184fbd04f4d9c116cf5f504))

- Improve test coverage to reach 90% threshold
  ([`c3db362`](https://github.com/svange/augint-library/commit/c3db3628e8278361a1fffce27e25f51bf227e5d2))

- Make GitHub release assets upload conditional on release creation
  ([`6d57868`](https://github.com/svange/augint-library/commit/6d578680991b57ec7d0581648e88f95af41ab8ac))

- Make telemetry imports optional for CI compatibility
  ([#128](https://github.com/svange/augint-library/pull/128),
  [`eed8390`](https://github.com/svange/augint-library/commit/eed83905d444072147c632786a4e17edbc7c29a3))

- Make telemetry package name dynamic for template compatibility
  ([#128](https://github.com/svange/augint-library/pull/128),
  [`eed8390`](https://github.com/svange/augint-library/commit/eed83905d444072147c632786a4e17edbc7c29a3))

- Make telemetry tests work in CI without sentry_sdk
  ([#128](https://github.com/svange/augint-library/pull/128),
  [`eed8390`](https://github.com/svange/augint-library/commit/eed83905d444072147c632786a4e17edbc7c29a3))

- Prevent dashboard pollution by limiting PR triggers
  ([#49](https://github.com/svange/augint-library/pull/49),
  [`d7fd35f`](https://github.com/svange/augint-library/commit/d7fd35fb56c845aef43897f930db553f41098058))

- Prevent dashboard pollution by limiting PR triggers
  ([#48](https://github.com/svange/augint-library/pull/48),
  [`9e5909f`](https://github.com/svange/augint-library/commit/9e5909fa3ac5c27b5cb93e44a919ba1a2ccb620c))

- Properly handle missing telemetry dependencies
  ([#128](https://github.com/svange/augint-library/pull/128),
  [`eed8390`](https://github.com/svange/augint-library/commit/eed83905d444072147c632786a4e17edbc7c29a3))

- Properly separate push vs pull_request events and fix stack name coupling
  ([#49](https://github.com/svange/augint-library/pull/49),
  [`d7fd35f`](https://github.com/svange/augint-library/commit/d7fd35fb56c845aef43897f930db553f41098058))

- Remove --print flag from semantic-release to enable actual releases
  ([#129](https://github.com/svange/augint-library/pull/129),
  [`067fa9a`](https://github.com/svange/augint-library/commit/067fa9a79c1ea06df1dcb50502df066de559f022))

- Remove branch filter from auto-merge workflow trigger
  ([`6111bd3`](https://github.com/svange/augint-library/commit/6111bd3a9ace43f79daf8cac7bfebea97845c5e6))

- Remove coverage measurement from integration tests
  ([#95](https://github.com/svange/augint-library/pull/95),
  [`379f73c`](https://github.com/svange/augint-library/commit/379f73ca3595558fb33cae7a52900574887ff449))

- Remove dashboard pollution by simplifying trigger events
  ([#50](https://github.com/svange/augint-library/pull/50),
  [`3564ac0`](https://github.com/svange/augint-library/commit/3564ac0443d0b5e782c9a005deae4ef67aee5018))

- Remove Dependabot configuration to prevent Poetry conflicts
  ([#87](https://github.com/svange/augint-library/pull/87),
  [`b4241f1`](https://github.com/svange/augint-library/commit/b4241f16f19de83b143d5dfcaff5f2a256ceccde))

- Remove examples directory to maintain clean template structure
  ([#119](https://github.com/svange/augint-library/pull/119),
  [`cd0902b`](https://github.com/svange/augint-library/commit/cd0902ba8fe24186ad5b031a817e0fc2acebcfc4))

- Remove GPL test dependency to restore pipeline
  ([#61](https://github.com/svange/augint-library/pull/61),
  [`60671df`](https://github.com/svange/augint-library/commit/60671df1011d2c26446d60b4f69afdfe6b8fd00d))

- Remove leftover branch sync validation code
  ([#61](https://github.com/svange/augint-library/pull/61),
  [`60671df`](https://github.com/svange/augint-library/commit/60671df1011d2c26446d60b4f69afdfe6b8fd00d))

- Remove matrix strategy from unit tests to match branch protection ruleset
  ([`2b66158`](https://github.com/svange/augint-library/commit/2b661588c1597974ac07694c5bebf9b9c728fcdb))

- Remove redundant auto-merge job from pipeline
  ([#95](https://github.com/svange/augint-library/pull/95),
  [`379f73c`](https://github.com/svange/augint-library/commit/379f73ca3595558fb33cae7a52900574887ff449))

- Remove redundant auto-merge job from pipeline
  ([#94](https://github.com/svange/augint-library/pull/94),
  [`bd82c88`](https://github.com/svange/augint-library/commit/bd82c8894495463a84fae2df3307e5ac72a49863))

- Remove redundant pull_request triggers ([#56](https://github.com/svange/augint-library/pull/56),
  [`912bdc6`](https://github.com/svange/augint-library/commit/912bdc62a6bf43c9134a7bb6abe4116d7a620cb7))

- Remove redundant tooling configuration
  ([`cc2a062`](https://github.com/svange/augint-library/commit/cc2a062772615f4f438a6c47ae2b67c6adbf9292))

- Remove trailing whitespace from pipeline.yaml
  ([`df3a6f7`](https://github.com/svange/augint-library/commit/df3a6f7a299fe57703515693c62e7dcdc587dbee))

- Remove unused variable and correct test structure
  ([`f125ce6`](https://github.com/svange/augint-library/commit/f125ce64f08f4ad6b9eeeafcf1024dc0372f686e))

- Remove useless exclude pattern from pre-commit config
  ([`8c5d24d`](https://github.com/svange/augint-library/commit/8c5d24d2f055e2ae73b596cc9f957168d6b032b3))

- Resolve auto-merge approval error ([#58](https://github.com/svange/augint-library/pull/58),
  [`c75f3dc`](https://github.com/svange/augint-library/commit/c75f3dc851327cc29176f78b62f3768bde2c2d55))

- Resolve CI mypy errors with proper dummy sentry_sdk implementation
  ([#128](https://github.com/svange/augint-library/pull/128),
  [`eed8390`](https://github.com/svange/augint-library/commit/eed83905d444072147c632786a4e17edbc7c29a3))

- Resolve mypy pre-commit hook module path issue
  ([`55727f9`](https://github.com/svange/augint-library/commit/55727f9484971a8e25613c5461be570dd8ee56b5))

- Resolve mypy type errors in telemetry module
  ([#128](https://github.com/svange/augint-library/pull/128),
  [`eed8390`](https://github.com/svange/augint-library/commit/eed83905d444072147c632786a4e17edbc7c29a3))

- Resolve pre-commit end-of-file-fixer failures
  ([#110](https://github.com/svange/augint-library/pull/110),
  [`1dcfe0f`](https://github.com/svange/augint-library/commit/1dcfe0fb22d36c94d33cefc722f1cd210296a9a4))

- Resolve test failures and improve telemetry test reliability
  ([#128](https://github.com/svange/augint-library/pull/128),
  [`eed8390`](https://github.com/svange/augint-library/commit/eed83905d444072147c632786a4e17edbc7c29a3))

- Restore pipeline functionality and fix regressions
  ([#54](https://github.com/svange/augint-library/pull/54),
  [`b54cfc8`](https://github.com/svange/augint-library/commit/b54cfc8a7a63b91447c2c48777a097b9f3d0eaf5))

- Restrict auto-merge to development branches only
  ([#56](https://github.com/svange/augint-library/pull/56),
  [`912bdc6`](https://github.com/svange/augint-library/commit/912bdc62a6bf43c9134a7bb6abe4116d7a620cb7))

- Restrict infrastructure deployment and integration tests to main/dev branches only
  ([`91ffb9c`](https://github.com/svange/augint-library/commit/91ffb9c96ad8098ce5d4bd1eb374b4b37252d7ac))

- Sanitize branch names for AWS CloudFormation stack naming
  ([`a0f45ea`](https://github.com/svange/augint-library/commit/a0f45ea158e7f29c46f3fce9a54d04a3f55624cf))

- Simplify pipeline by removing broken validation jobs
  ([#56](https://github.com/svange/augint-library/pull/56),
  [`912bdc6`](https://github.com/svange/augint-library/commit/912bdc62a6bf43c9134a7bb6abe4116d7a620cb7))

- Simplify pipeline workflows and eliminate race conditions
  ([#56](https://github.com/svange/augint-library/pull/56),
  [`912bdc6`](https://github.com/svange/augint-library/commit/912bdc62a6bf43c9134a7bb6abe4116d7a620cb7))

- Skip telemetry tests in CI environment ([#128](https://github.com/svange/augint-library/pull/128),
  [`eed8390`](https://github.com/svange/augint-library/commit/eed83905d444072147c632786a4e17edbc7c29a3))

- Strengthen pipeline against partial merges and restore CLAUDE.md
  ([#47](https://github.com/svange/augint-library/pull/47),
  [`49fb1a0`](https://github.com/svange/augint-library/commit/49fb1a04d9467a8a2d4b3073b0c6253fd6b48fa7))

- Strengthen pipeline against partial merges and restore CLAUDE.md (closes #45)
  ([#47](https://github.com/svange/augint-library/pull/47),
  [`49fb1a0`](https://github.com/svange/augint-library/commit/49fb1a04d9467a8a2d4b3073b0c6253fd6b48fa7))

- Update CLAUDE.md and settings.json to ensure proper formatting and compliance
  ([#89](https://github.com/svange/augint-library/pull/89),
  [`1926b01`](https://github.com/svange/augint-library/commit/1926b01faca324398a83393d453b3d13d8bb8268))

- Update test to match new AWS stack naming logic
  ([`d99f493`](https://github.com/svange/augint-library/commit/d99f493ed5901f05479a188adf920b0ba98f9195))

- Updated poetry.lock ([#128](https://github.com/svange/augint-library/pull/128),
  [`eed8390`](https://github.com/svange/augint-library/commit/eed83905d444072147c632786a4e17edbc7c29a3))

- Use ModuleType subclass for dummy sentry_sdk to resolve CI error
  ([#128](https://github.com/svange/augint-library/pull/128),
  [`eed8390`](https://github.com/svange/augint-library/commit/eed83905d444072147c632786a4e17edbc7c29a3))

- Verify license compliance gate enforcement (closes #36)
  ([#61](https://github.com/svange/augint-library/pull/61),
  [`60671df`](https://github.com/svange/augint-library/commit/60671df1011d2c26446d60b4f69afdfe6b8fd00d))

### Documentation

- Add Claude Code Windows optimization documentation
  ([`0c7e6a3`](https://github.com/svange/augint-library/commit/0c7e6a3784aef0cf04138406653f4b3e1306b137))

- Add comprehensive DevOps pipeline guide ([#58](https://github.com/svange/augint-library/pull/58),
  [`c75f3dc`](https://github.com/svange/augint-library/commit/c75f3dc851327cc29176f78b62f3768bde2c2d55))

- Add comprehensive documentation for feature flags system
  ([#127](https://github.com/svange/augint-library/pull/127),
  [`85dc6ba`](https://github.com/svange/augint-library/commit/85dc6ba7cde0bff3cbb7cf22d39023fce63c217e))

- Add comprehensive documentation for feature flags system
  ([#126](https://github.com/svange/augint-library/pull/126),
  [`77c3adc`](https://github.com/svange/augint-library/commit/77c3adce23fe6ec40fbbf94a8f645e6f8f54750b))

- Clean separation of guides vs generated documentation
  ([#44](https://github.com/svange/augint-library/pull/44),
  [`d9ef09b`](https://github.com/svange/augint-library/commit/d9ef09b6aeafd5e2c1d0801b02cf253564c63382))

- Configure /plan command to use guides/ directory
  ([#44](https://github.com/svange/augint-library/pull/44),
  [`d9ef09b`](https://github.com/svange/augint-library/commit/d9ef09b6aeafd5e2c1d0801b02cf253564c63382))

- Document repository setup with linear history and Dependabot
  ([#79](https://github.com/svange/augint-library/pull/79),
  [`7f647e0`](https://github.com/svange/augint-library/commit/7f647e01ecef610ac43dc061ea63e2dcf96fb22d))

- Enhance Claude command documentation ([#64](https://github.com/svange/augint-library/pull/64),
  [`1215284`](https://github.com/svange/augint-library/commit/12152842c725b3f5fcb42e537d8c340cfd8f1587))

- Fix broken branch protection documentation references
  ([`dd7509b`](https://github.com/svange/augint-library/commit/dd7509bbba879fd66b2756d7c004442034818cd4))

- Organize documentation and clean up repository structure
  ([#44](https://github.com/svange/augint-library/pull/44),
  [`d9ef09b`](https://github.com/svange/augint-library/commit/d9ef09b6aeafd5e2c1d0801b02cf253564c63382))

- Simplify CLAUDE.md command references ([#128](https://github.com/svange/augint-library/pull/128),
  [`eed8390`](https://github.com/svange/augint-library/commit/eed83905d444072147c632786a4e17edbc7c29a3))

- Update auto-merge documentation with working status and troubleshooting
  ([`26e2b7b`](https://github.com/svange/augint-library/commit/26e2b7bae492a4a18a893eff546ddd35e3c4c0a2))

- Update CLAUDE.md and README.md for library-specific guidelines and environment setup
  ([#89](https://github.com/svange/augint-library/pull/89),
  [`1926b01`](https://github.com/svange/augint-library/commit/1926b01faca324398a83393d453b3d13d8bb8268))

### Features

- Add /plan slash command for comprehensive project planning
  ([#44](https://github.com/svange/augint-library/pull/44),
  [`d9ef09b`](https://github.com/svange/augint-library/commit/d9ef09b6aeafd5e2c1d0801b02cf253564c63382))

- Add /plan slash command for comprehensive project planning
  ([#43](https://github.com/svange/augint-library/pull/43),
  [`0cc64a2`](https://github.com/svange/augint-library/commit/0cc64a2610ceccf6854423456bdb64b52e2c3c12))

- Add /plan slash command for comprehensive project planning
  ([#42](https://github.com/svange/augint-library/pull/42),
  [`e377b4e`](https://github.com/svange/augint-library/commit/e377b4e348bfcd310a2d38d791f7daf47927b6d5))

- Add automated Poetry security update workflow
  ([#90](https://github.com/svange/augint-library/pull/90),
  [`b07b24c`](https://github.com/svange/augint-library/commit/b07b24cee385bbcb42944ad4e68e9f7cf638d620))

- Add automatic poetry install to Dockerfile
  ([#117](https://github.com/svange/augint-library/pull/117),
  [`edf692e`](https://github.com/svange/augint-library/commit/edf692e5e61881c389c66c66907be024fd205e29))

- Add automatic poetry install to Dockerfile
  ([#115](https://github.com/svange/augint-library/pull/115),
  [`828ea07`](https://github.com/svange/augint-library/commit/828ea07ee3169f9a603385730642f12f8b475218))

- Add AWS trust policy management scripts
  ([#125](https://github.com/svange/augint-library/pull/125),
  [`38c0923`](https://github.com/svange/augint-library/commit/38c092323d2a3c5682332972d409b9a8f1cc5949))

- Add BRAVE_API_KEY environment variable to docker-compose
  ([#120](https://github.com/svange/augint-library/pull/120),
  [`ea299b5`](https://github.com/svange/augint-library/commit/ea299b5828466220c05b05255d31b7f624701c0f))

- Add clean Python-friendly Makefile with common developer commands
  ([`34b197b`](https://github.com/svange/augint-library/commit/34b197baff9949074bf0f5e7bbb6c45ef6351192))

- Add complete type system support with py.typed and mypy configuration
  ([`261f257`](https://github.com/svange/augint-library/commit/261f2576130360bbee596995b94f5bd2324bccb4))

- Add comprehensive unit tests and fix test artifact handling
  ([`95b19d0`](https://github.com/svange/augint-library/commit/95b19d06af118ad15dd066fc3a244245ecbfe5b4))

- Add debugging and dependency update documentation for CLI
  ([`18f51f9`](https://github.com/svange/augint-library/commit/18f51f95294c662579ddc4e7b0273578ac622f5a))

- Add Docker development environment with Claude Code integration
  ([#106](https://github.com/svange/augint-library/pull/106),
  [`03d74b0`](https://github.com/svange/augint-library/commit/03d74b0bee6fc2ab23a0f91638c681e87dca561b))

- Add enterprise git workflow automation commands
  ([#122](https://github.com/svange/augint-library/pull/122),
  [`3a34c0c`](https://github.com/svange/augint-library/commit/3a34c0c653efad39c13524b9e86ae7903e3a2101))

- Add git hooks disable to Dockerfile for container compatibility
  ([#113](https://github.com/svange/augint-library/pull/113),
  [`d6c5087`](https://github.com/svange/augint-library/commit/d6c50872e2f84fed38c106861c5a1d8da85397bc))

- Add git hooks disable to Dockerfile for container compatibility closes #112
  ([#117](https://github.com/svange/augint-library/pull/117),
  [`edf692e`](https://github.com/svange/augint-library/commit/edf692e5e61881c389c66c66907be024fd205e29))

- Add git hooks disable to Dockerfile for container compatibility closes #112
  ([#115](https://github.com/svange/augint-library/pull/115),
  [`828ea07`](https://github.com/svange/augint-library/commit/828ea07ee3169f9a603385730642f12f8b475218))

- Add git hooks disable to Dockerfile for container compatibility closes #112
  ([#113](https://github.com/svange/augint-library/pull/113),
  [`d6c5087`](https://github.com/svange/augint-library/commit/d6c50872e2f84fed38c106861c5a1d8da85397bc))

- Add git hygiene command and update gitignore
  ([#78](https://github.com/svange/augint-library/pull/78),
  [`571929e`](https://github.com/svange/augint-library/commit/571929e1eff53734c524d936daa2b4a10a3ba229))

- Add mutation testing with mutmut ([#118](https://github.com/svange/augint-library/pull/118),
  [`97e7b37`](https://github.com/svange/augint-library/commit/97e7b37f10535f7372167d58cfd599c5dd57bd82))

- Add mutation testing with mutmut closes #104
  ([#118](https://github.com/svange/augint-library/pull/118),
  [`97e7b37`](https://github.com/svange/augint-library/commit/97e7b37f10535f7372167d58cfd599c5dd57bd82))

- Add privacy-conscious telemetry system with Sentry integration
  ([#128](https://github.com/svange/augint-library/pull/128),
  [`eed8390`](https://github.com/svange/augint-library/commit/eed83905d444072147c632786a4e17edbc7c29a3))

- Add repository maintenance tools and improve Docker environment
  ([#108](https://github.com/svange/augint-library/pull/108),
  [`96a47ad`](https://github.com/svange/augint-library/commit/96a47ad1321613361184fbd04f4d9c116cf5f504))

- Add repository maintenance tools and update development environment
  ([#117](https://github.com/svange/augint-library/pull/117),
  [`edf692e`](https://github.com/svange/augint-library/commit/edf692e5e61881c389c66c66907be024fd205e29))

- Add repository maintenance tools and update development environment
  ([#115](https://github.com/svange/augint-library/pull/115),
  [`828ea07`](https://github.com/svange/augint-library/commit/828ea07ee3169f9a603385730642f12f8b475218))

- Add repository maintenance tools and update development environment
  ([#113](https://github.com/svange/augint-library/pull/113),
  [`d6c5087`](https://github.com/svange/augint-library/commit/d6c50872e2f84fed38c106861c5a1d8da85397bc))

- Add repository maintenance tools and update development environment
  ([#111](https://github.com/svange/augint-library/pull/111),
  [`c1e47df`](https://github.com/svange/augint-library/commit/c1e47df5c7ff9ec80a7a25bbc9f24fef514f772e))

- Add repository maintenance tools and update development environment
  ([#110](https://github.com/svange/augint-library/pull/110),
  [`1dcfe0f`](https://github.com/svange/augint-library/commit/1dcfe0fb22d36c94d33cefc722f1cd210296a9a4))

- Add repository maintenance tools and update development environment
  ([#109](https://github.com/svange/augint-library/pull/109),
  [`a5f43db`](https://github.com/svange/augint-library/commit/a5f43db67d615a70d8909001fbe765ebf66ce85c))

- Add repository maintenance tools and update development environment
  ([#108](https://github.com/svange/augint-library/pull/108),
  [`96a47ad`](https://github.com/svange/augint-library/commit/96a47ad1321613361184fbd04f4d9c116cf5f504))

- Clear changelog in bootstrap stage one
  ([`8c3ca99`](https://github.com/svange/augint-library/commit/8c3ca99f87ddb43edcfac81126abcc9232366def))

- Complete repository cleanup and documentation organization
  ([#44](https://github.com/svange/augint-library/pull/44),
  [`d9ef09b`](https://github.com/svange/augint-library/commit/d9ef09b6aeafd5e2c1d0801b02cf253564c63382))

- Comprehensive .gitignore optimization for all development tools
  ([#44](https://github.com/svange/augint-library/pull/44),
  [`d9ef09b`](https://github.com/svange/augint-library/commit/d9ef09b6aeafd5e2c1d0801b02cf253564c63382))

- Enhance AI developer experience with structured documentation and MCP servers
  ([#117](https://github.com/svange/augint-library/pull/117),
  [`edf692e`](https://github.com/svange/augint-library/commit/edf692e5e61881c389c66c66907be024fd205e29))

- Enhance Docker setup with Claude Code integration and localstack support
  ([#106](https://github.com/svange/augint-library/pull/106),
  [`03d74b0`](https://github.com/svange/augint-library/commit/03d74b0bee6fc2ab23a0f91638c681e87dca561b))

- Enhance Docker setup with flexible project directories and improved git handling
  ([#117](https://github.com/svange/augint-library/pull/117),
  [`edf692e`](https://github.com/svange/augint-library/commit/edf692e5e61881c389c66c66907be024fd205e29))

- Enhance Makefile and fix ruff/pre-commit consistency
  ([#111](https://github.com/svange/augint-library/pull/111),
  [`c1e47df`](https://github.com/svange/augint-library/commit/c1e47df5c7ff9ec80a7a25bbc9f24fef514f772e))

- Enhance Makefile and fix ruff/pre-commit consistency closes #97
  ([#117](https://github.com/svange/augint-library/pull/117),
  [`edf692e`](https://github.com/svange/augint-library/commit/edf692e5e61881c389c66c66907be024fd205e29))

- Enhance Makefile and fix ruff/pre-commit consistency closes #97
  ([#115](https://github.com/svange/augint-library/pull/115),
  [`828ea07`](https://github.com/svange/augint-library/commit/828ea07ee3169f9a603385730642f12f8b475218))

- Enhance Makefile and fix ruff/pre-commit consistency closes #97
  ([#113](https://github.com/svange/augint-library/pull/113),
  [`d6c5087`](https://github.com/svange/augint-library/commit/d6c50872e2f84fed38c106861c5a1d8da85397bc))

- Enhance Makefile and fix ruff/pre-commit consistency closes #97
  ([#111](https://github.com/svange/augint-library/pull/111),
  [`c1e47df`](https://github.com/svange/augint-library/commit/c1e47df5c7ff9ec80a7a25bbc9f24fef514f772e))

- Enhance testing toolkit with hypothesis and pytest-benchmark closes #13
  ([#92](https://github.com/svange/augint-library/pull/92),
  [`ea890b3`](https://github.com/svange/augint-library/commit/ea890b31b3c43f5fdd8c854379244907cc3e8906))

- Establish AI-optimized library development workflow
  ([`a98735e`](https://github.com/svange/augint-library/commit/a98735e47fa247aed00a5bb7163dd15f8faa05a7))

- Fix formatting in mutation testing documentation and YAML configuration
  ([#118](https://github.com/svange/augint-library/pull/118),
  [`97e7b37`](https://github.com/svange/augint-library/commit/97e7b37f10535f7372167d58cfd599c5dd57bd82))

- Implement comprehensive Docker support for development and testing environment
  ([#106](https://github.com/svange/augint-library/pull/106),
  [`03d74b0`](https://github.com/svange/augint-library/commit/03d74b0bee6fc2ab23a0f91638c681e87dca561b))

- Implement custom exception hierarchy with error codes
  ([#119](https://github.com/svange/augint-library/pull/119),
  [`cd0902b`](https://github.com/svange/augint-library/commit/cd0902ba8fe24186ad5b031a817e0fc2acebcfc4))

- Implement custom exception hierarchy with error codes closes #103
  ([#119](https://github.com/svange/augint-library/pull/119),
  [`cd0902b`](https://github.com/svange/augint-library/commit/cd0902ba8fe24186ad5b031a817e0fc2acebcfc4))

- Implement feature flags system ([#127](https://github.com/svange/augint-library/pull/127),
  [`85dc6ba`](https://github.com/svange/augint-library/commit/85dc6ba7cde0bff3cbb7cf22d39023fce63c217e))

- Implement feature flags system with gradual rollout support
  ([#127](https://github.com/svange/augint-library/pull/127),
  [`85dc6ba`](https://github.com/svange/augint-library/commit/85dc6ba7cde0bff3cbb7cf22d39023fce63c217e))

- Implement license exception override mechanism (closes #62)
  ([#63](https://github.com/svange/augint-library/pull/63),
  [`c02038f`](https://github.com/svange/augint-library/commit/c02038f87608f7df94ee9403ad53a7c17fda4fcd))

- Implement optimized Dependabot auto-merge configuration
  ([`8f967c4`](https://github.com/svange/augint-library/commit/8f967c409c05fe6b976c297ee32c4d10aee9811d))

- Implement PR-based pipeline triggers matching danger-rose pattern
  ([#86](https://github.com/svange/augint-library/pull/86),
  [`07f3f48`](https://github.com/svange/augint-library/commit/07f3f48b6720657d89fad900529ba630204108c2))

- Implement retry and circuit breaker patterns closes #101
  ([#121](https://github.com/svange/augint-library/pull/121),
  [`9fc6791`](https://github.com/svange/augint-library/commit/9fc6791044884dc6768aa95e936aad0dc9d3479b))

- Implement security-first pipeline with early security gate
  ([`7accfac`](https://github.com/svange/augint-library/commit/7accfac19811e9c345cc8aea12d4d0b8363c8f41))

- Implement test pipeline optimization and coverage threshold enforcement
  ([`0625f21`](https://github.com/svange/augint-library/commit/0625f21af4b88a6f99ce840ce1ffbd9d227c62b7))

- Make Claude commands repository-aware ([#67](https://github.com/svange/augint-library/pull/67),
  [`a72de05`](https://github.com/svange/augint-library/commit/a72de0523a0af5f04aa627d4773a165c60675779))

- Remove separate auto-merge workflow after consolidation
  ([#58](https://github.com/svange/augint-library/pull/58),
  [`c75f3dc`](https://github.com/svange/augint-library/commit/c75f3dc851327cc29176f78b62f3768bde2c2d55))

- Strengthen security gates to fail on vulnerabilities
  ([#43](https://github.com/svange/augint-library/pull/43),
  [`0cc64a2`](https://github.com/svange/augint-library/commit/0cc64a2610ceccf6854423456bdb64b52e2c3c12))

- Strengthen security gates to fail on vulnerabilities (closes #33)
  ([#44](https://github.com/svange/augint-library/pull/44),
  [`d9ef09b`](https://github.com/svange/augint-library/commit/d9ef09b6aeafd5e2c1d0801b02cf253564c63382))

- Strengthen security gates to fail on vulnerabilities (closes #33)
  ([#43](https://github.com/svange/augint-library/pull/43),
  [`0cc64a2`](https://github.com/svange/augint-library/commit/0cc64a2610ceccf6854423456bdb64b52e2c3c12))

- Update Docker configuration for improved project structure and Playwright setup
  ([#106](https://github.com/svange/augint-library/pull/106),
  [`03d74b0`](https://github.com/svange/augint-library/commit/03d74b0bee6fc2ab23a0f91638c681e87dca561b))

- Update settings.json for enhanced Docker and Poetry integration
  ([#106](https://github.com/svange/augint-library/pull/106),
  [`03d74b0`](https://github.com/svange/augint-library/commit/03d74b0bee6fc2ab23a0f91638c681e87dca561b))


## v1.25.0 (2025-07-21)


## v1.25.0-dev.1 (2025-07-21)

### Features

- Add issue-driven development workflow instructions to CLAUDE.md
  ([`278499f`](https://github.com/svange/augint-library/commit/278499ff1bdee886025c1abf77cba5035899c5cf))


## v1.24.0 (2025-07-21)

### Documentation

- Update print_hi function docstring for Dependabot testing
  ([`8891f03`](https://github.com/svange/augint-library/commit/8891f03f522aa2f66b49ee90268b2326a729aa0c))

### Features

- Add auto-merge configuration documentation and testing request for Dependabot
  ([`e1a2368`](https://github.com/svange/augint-library/commit/e1a2368ed2ac9c406922e843c6a3697a12671807))


## v1.23.2 (2025-07-19)

### Documentation

- Enhance CLI module documentation with template context
  ([`756e1f3`](https://github.com/svange/augint-library/commit/756e1f39a37df059c72de2999a123676d8e37d02))


## v1.23.1 (2025-07-18)

### Bug Fixes

- Add UTF-8 encoding to file operations and improve bootstrap command instructions
  ([`79f6782`](https://github.com/svange/augint-library/commit/79f67820928be9d7a84ab82bcbab6fcdb9d2fce3))


## v1.23.0 (2025-07-18)

### Bug Fixes

- Correct placement of ai-test-script in pyproject.toml
  ([`91a51ef`](https://github.com/svange/augint-library/commit/91a51efc0e2344fb8a3b98196cfaa3e0a6d1db54))

- Update poetry.lock to include 'main' group alongside 'security'
  ([`04291f2`](https://github.com/svange/augint-library/commit/04291f2231ce49b0ae23425fd19bf89559824379))

### Documentation

- Update README and BOOTSTRAP with improved two-stage process
  ([`6de052e`](https://github.com/svange/augint-library/commit/6de052e58c217d49d648a8856bddeaf9b07e5d74))

### Features

- Generate optimized CLAUDE.md and enhance bootstrap process
  ([`3c89969`](https://github.com/svange/augint-library/commit/3c89969bad5ba72184f825c5035b8fb5e9c12477))


## v1.22.1 (2025-07-18)

### Bug Fixes

- Filename consistency ugliness, prettified.
  ([`ae88120`](https://github.com/svange/augint-library/commit/ae88120417868b784fa7dd0690ecf335f8047356))

- Filename consistency ugliness, prettified.
  ([`f86b1f3`](https://github.com/svange/augint-library/commit/f86b1f34c96b3c9cdf78d6a6c78f3f41c3ae3b59))


## v1.22.0 (2025-07-18)

### Bug Fixes

- Update branch protection guidelines to clarify security scanning and compliance report
  requirements
  ([`c0dede3`](https://github.com/svange/augint-library/commit/c0dede3dca39c15d8884eac55453cce97ed8816a))

### Features

- Add Dependabot auto-merge configuration and repository setup instructions
  ([`9fd6764`](https://github.com/svange/augint-library/commit/9fd6764845a89a4f5f93f180bb9376572b9760e4))

- Enhance bootstrap script and documentation for project setup and AWS integration
  ([`fee94d0`](https://github.com/svange/augint-library/commit/fee94d0160391996d48a2b4de5d7a65e13bcef80))


## v1.21.0 (2025-07-18)

### Bug Fixes

- Finalizing pipeline fixes for compliance
  ([`0f30cd4`](https://github.com/svange/augint-library/commit/0f30cd4aedd976e8b91efd2781e524461752cc9f))

### Features

- Add branch protection guidelines and enhance pipeline license reporting
  ([`53e1705`](https://github.com/svange/augint-library/commit/53e17050b52c2c717bb142d1f8911a928b3b979e))

- Enhance license reporting by filtering runtime dependencies
  ([`3da685e`](https://github.com/svange/augint-library/commit/3da685e80c413da5bf6be9569bc90eecdd657a9a))


## v1.20.0 (2025-07-18)

### Features

- Enhance documentation with Windows environment notes and CI/CD optimization strategies
  ([`d9d724e`](https://github.com/svange/augint-library/commit/d9d724e0e84ae7cef0b39d5cb1f7e3c3539aa6a6))


## v1.19.0 (2025-07-18)

### Features

- Enhance security and compliance features in CI pipeline with new pre-commit hooks and reporting
  tools
  ([`799e260`](https://github.com/svange/augint-library/commit/799e2601df3b3c39fc5815c23eb52b0d60761a04))

- Enhance test result and coverage report uploads for multiple Python versions in CI pipeline
  ([`e366a8c`](https://github.com/svange/augint-library/commit/e366a8c940e1eeb47c783eeefd7b639018b0c39c))

- Improve formatting and consistency in bootstrap script and pipeline configuration
  ([`8850cdc`](https://github.com/svange/augint-library/commit/8850cdcade3a16bcd4f2184568bf3fdc490a8745))

- Simplify release version dependencies in CI pipeline
  ([`570d023`](https://github.com/svange/augint-library/commit/570d023d0f88fbe26947ed6611da2c49504bc4f6))

- Update pipeline dependencies to streamline security scanning and compliance report generation
  ([`d85c758`](https://github.com/svange/augint-library/commit/d85c7585f75963a81aad0321fa0bd0f7107f3f0e))


## v1.18.0 (2025-07-18)

### Features

- Enhance compliance reporting with license compatibility checks and update documentation
  ([`75cba5f`](https://github.com/svange/augint-library/commit/75cba5f22160763aaa34f32fb8a6999a7cb3ff57))


## v1.17.0 (2025-07-17)

### Features

- Improve Safety check output handling and update README for security scans
  ([`f96ee07`](https://github.com/svange/augint-library/commit/f96ee077f754389b15a6e52652c2b096d286fb62))


## v1.16.0 (2025-07-17)

### Features

- Add compliance reporting tools and update dependencies in CI pipeline
  ([`2dd1c28`](https://github.com/svange/augint-library/commit/2dd1c28ce0bbac8d3350efbff04f74b45916966c))

- Add security scanning to CI pipeline with Bandit, Safety, and pip-audit
  ([`76a1120`](https://github.com/svange/augint-library/commit/76a1120ef33afed905acd3739e4da5b93cb48e20))

- Add Semgrep and pip-licenses to CI pipeline for enhanced security and license reporting
  ([`6ef890b`](https://github.com/svange/augint-library/commit/6ef890b7e29ecd88d503fadf6d64317c238c4d76))

- Enhance security scanning setup with detailed installation and usage instructions
  ([`974d29c`](https://github.com/svange/augint-library/commit/974d29ccf45f90ec090701f043f63cbdb5d87e57))

- Update compliance reporting tools and remove SBOM generation from CI
  ([`b890be1`](https://github.com/svange/augint-library/commit/b890be13c1d0824f91f151fbb272d801521732b2))


## v1.15.0 (2025-07-17)

### Features

- Enhance dark mode support with improved styles and toggle functionality
  ([`c5f9ed7`](https://github.com/svange/augint-library/commit/c5f9ed715633e9e922b7f146e2e8fad7306287c3))


## v1.14.0 (2025-07-17)

### Features

- Enhance dark mode support with improved styles and toggle functionality
  ([`c922812`](https://github.com/svange/augint-library/commit/c9228124a7cfff1946bf21889398bc95cfb8682a))


## v1.13.0 (2025-07-17)

### Features

- Update pipeline configuration to limit Python versions and improve artifact naming
  ([`46c8b39`](https://github.com/svange/augint-library/commit/46c8b397507fc884ac3a3cb7f9a2475da06532b4))


## v1.12.0 (2025-07-17)

### Features

- Update documentation template to support multiple modules
  ([`526cd1f`](https://github.com/svange/augint-library/commit/526cd1f0578ce1ca21a6ffaf3211854315c84244))

- Update poetry.lock for dependency version adjustments and new packages
  ([`4597ead`](https://github.com/svange/augint-library/commit/4597eadbb1a024ce491b0214e78300b96d4e3351))


## v1.11.0 (2025-07-17)

### Features

- Update documentation template to support multiple modules
  ([`1bd749d`](https://github.com/svange/augint-library/commit/1bd749d91876b5c2295087048614f8ac4e550a6d))


## v1.10.0 (2025-07-17)

### Features

- Add HTML template for module documentation with theme toggle
  ([`f264324`](https://github.com/svange/augint-library/commit/f264324987e1575ad2529b8c32e2033ce04c1cf1))

- Enhance documentation and pipeline configuration for clarity and usability
  ([`b6bb688`](https://github.com/svange/augint-library/commit/b6bb688694c6dd9e7917b74f0e0b3c9302662a56))


## v1.9.0 (2025-07-17)

### Features

- Update .gitignore and pyproject.toml for improved configuration
  ([`5aa832f`](https://github.com/svange/augint-library/commit/5aa832fa9ba79d560bce70b6cb65ef554e4e29b5))


## v1.8.0 (2025-07-17)

### Features

- Streamline module name handling in bootstrap and pipeline scripts
  ([`f5932b0`](https://github.com/svange/augint-library/commit/f5932b0f77f45c0244998a3e95b5c8f5a0846021))


## v1.7.0 (2025-07-17)

### Documentation

- Updated CLAUDE.md
  ([`bc873a4`](https://github.com/svange/augint-library/commit/bc873a47ad661285d965434d36ad316c93e11cf7))

- Updating markdown files
  ([`500ea6b`](https://github.com/svange/augint-library/commit/500ea6b9c344f2b20f671174cc52dde9b08bab28))

### Features

- Adding fix and feature branch testing with isolated environments.
  ([`e549e11`](https://github.com/svange/augint-library/commit/e549e1141d87dcc46bcf6d4434d46c9c30d48a81))

- Adding fix and feature branch testing with isolated environments.
  ([`076f980`](https://github.com/svange/augint-library/commit/076f980188d51c969afb1dcf45be914c722e2d22))

- Bootstrap.py script
  ([`f88b604`](https://github.com/svange/augint-library/commit/f88b6044fbbb60a1b0d2a28e4f1ed0d2c7c24a64))

- Enhance pytest configuration and add dynamic stack name generation
  ([`cfe30f2`](https://github.com/svange/augint-library/commit/cfe30f2e1ff4083a22f9c3886e00018d118b5272))

- Graceful fail before secrets are in place less ugly pipeline pollution.
  ([`9768416`](https://github.com/svange/augint-library/commit/97684164dbcb8b165ce479bc10ba31b88bf2a3c8))


## v1.6.0 (2025-07-16)


## v1.5.0 (2025-07-11)

### Features

- Updated README.md
  ([`36b3ff7`](https://github.com/svange/augint-library/commit/36b3ff7d1c2ceeb25d5aa8fbf8a3a2a9938e53dc))


## v1.5.0-dev.1 (2025-07-16)

### Bug Fixes

- Cool new pipeline steps to auto create policy for testing and then use it and then destroy it
  after tests pass.
  ([`cae1bc9`](https://github.com/svange/augint-library/commit/cae1bc94b4ded172b784e762d820892e2f139e57))

### Features

- New docs only updates
  ([`4e5a3db`](https://github.com/svange/augint-library/commit/4e5a3db8aa599af534e298f7c3a5d1ef4ba9522d))

- Updated README.md
  ([`36b3ff7`](https://github.com/svange/augint-library/commit/36b3ff7d1c2ceeb25d5aa8fbf8a3a2a9938e53dc))


## v1.4.0 (2025-07-11)

### Features

- Polishing touches from augint-cosmic
  ([`8ccf68a`](https://github.com/svange/augint-library/commit/8ccf68ad43b7415f5d445364103663fdf1aad705))


## v1.3.1 (2025-07-10)

### Bug Fixes

- Finalizing pipeline
  ([`2a3da20`](https://github.com/svange/augint-library/commit/2a3da2057df6dbdb07dc4d05e49c9f9bf58b8f41))


## v1.3.1-dev.3 (2025-07-10)

### Bug Fixes

- Pipeline retest.
  ([`f9e8726`](https://github.com/svange/augint-library/commit/f9e8726395851bfa615257a1a0ee5b4eaddd2c98))


## v1.3.1-dev.2 (2025-07-10)

### Bug Fixes

- Skip pipeline runs on PSR commits.
  ([`5c4d5e5`](https://github.com/svange/augint-library/commit/5c4d5e5abc4bb361efd5693a709ebb9c80216a4f))


## v1.3.1-dev.1 (2025-07-10)

### Bug Fixes

- Added custom token to checkout step in release phase.
  ([`ccf69b5`](https://github.com/svange/augint-library/commit/ccf69b50b821c608390e25cf0a1dddc5558e63a3))

- Added dev branch to semantic release config.
  ([`12f2262`](https://github.com/svange/augint-library/commit/12f2262ff3899308353794cf1af10aceb1865bf2))

- Pyproject.toml setup env vars for pipeline more better.
  ([`34ecd3b`](https://github.com/svange/augint-library/commit/34ecd3ba5bd4783db4bff5dfc46615fd45818fd5))

- Testing branch protection and pipeline
  ([`24d6700`](https://github.com/svange/augint-library/commit/24d6700499184cf358e22bacfba129a87df4e1b2))


## v1.3.0 (2025-07-10)

### Bug Fixes

- Pipeline permissions to allow pipeline to work with branch protection in place.
  ([`61f7902`](https://github.com/svange/augint-library/commit/61f790225226eece7416272ef634084043dc9763))

- Reverting permission change
  ([`673dc28`](https://github.com/svange/augint-library/commit/673dc286655716043119217d55d5ea5716235df9))


## v1.2.0 (2025-07-10)

### Bug Fixes

- Bug in bootstrap script
  ([`7792c9d`](https://github.com/svange/augint-library/commit/7792c9df8de0cdcd53e0b2d91b6b4870f2a60fd7))

### Features

- Dark mode test-reports baby!
  ([`79db6c8`](https://github.com/svange/augint-library/commit/79db6c83135fdb054564d820cb07663ce023edad))


## v1.1.1 (2025-07-05)

### Bug Fixes

- Moving pytest-click to dev dependencies
  ([`6be0a07`](https://github.com/svange/augint-library/commit/6be0a079087bf5f0ec4bbe2b971ebb1c1d03ad29))


## v1.1.0 (2025-07-05)


## v1.0.3 (2025-07-05)

### Bug Fixes

- Applied black style
  ([`e795b1f`](https://github.com/svange/augint-library/commit/e795b1f120eac69582bde601b0d89ce5791d6897))


## v1.0.2 (2025-07-05)

### Bug Fixes

- Got rid of LICENSE_COMMERCIAL.md
  ([`caf8cba`](https://github.com/svange/augint-library/commit/caf8cbafe4cf2a73a950a727d5d72be171fea501))


## v1.0.1 (2025-07-05)

### Bug Fixes

- CHANGELOG.md does not change until after pages are deployed, so it's always behind one. Since
  CHANGELOG.md gets put in the published release and it's visible in the repo, we just remove the
  link from the README and we no longer host the CHANGELOG on gh pages.
  ([`79d186f`](https://github.com/svange/augint-library/commit/79d186fc48a82850d329fb70580356afa14e10f0))


## v1.0.0 (2025-07-05)

- Initial Release
