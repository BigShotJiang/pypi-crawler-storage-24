# Scripts Directory

This directory contains utility scripts for managing the augint-library project infrastructure and setup.

## Bootstrap Scripts

### bootstrap-stage1.py
**Purpose**: Initial project setup without dependencies
**When to run**: After cloning the repository, before `uv sync`

```bash
python scripts/bootstrap-stage1.py
```

This script:
- Creates initial `.env` file
- Detects GitHub repository information
- Sets up basic configuration
- Provides instructions for next steps

### bootstrap-stage2.py
**Purpose**: Complete setup after AWS SAM pipeline bootstrap
**When to run**: After running `sam pipeline bootstrap` and `uv sync`

```bash
python scripts/bootstrap-stage2.py
```

This script:
- Extracts AWS configuration from SAM pipeline
- Updates `.env` with pipeline execution roles
- Configures AWS account information

## Trust Policy Scripts

### update-trust-policies.sh
**Purpose**: Update IAM role trust policies to allow GitHub Actions access
**When to run**: After pipeline setup to enable CI/CD

```bash
./scripts/update-trust-policies.sh
```

This script:
- Reads configuration from `.env`
- Updates trust policies for all configured pipeline execution roles
- Supports augint-library branch patterns:
  - `main` - Production deployments
  - `feat/*` - Feature branches
  - `fix/*` - Bug fix branches
  - `docs/*` - Documentation branches
  - `refactor/*` - Code refactoring branches
  - `test/*` - Test improvement branches
  - `chore/*` - Maintenance branches
  - `perf/*` - Performance improvement branches
  - Pull requests from any branch

### verify-trust-policies.sh
**Purpose**: Check current IAM role trust policies
**When to run**: To verify GitHub Actions permissions are correctly configured

```bash
./scripts/verify-trust-policies.sh
```

This script:
- Shows current trust policies for all configured roles
- Highlights GitHub OIDC configuration
- Lists allowed branch patterns

## Setup Workflow

1. Clone repository
2. Run `python scripts/bootstrap-stage1.py`
3. Run `uv sync`
4. Run `sam pipeline bootstrap --stage augint-library-testing`
5. Run `python scripts/bootstrap-stage2.py`
6. Run `./scripts/update-trust-policies.sh`
7. Verify with `./scripts/verify-trust-policies.sh`

## Required Environment Variables

These scripts expect the following in `.env`:
- `GH_ACCOUNT` - GitHub account/organization
- `GH_REPO` - GitHub repository name
- `TESTING_PIPELINE_EXECUTION_ROLE` - Testing environment role ARN (optional)
- `STAGING_PIPELINE_EXECUTION_ROLE` - Staging environment role ARN (optional)
- `PROD_PIPELINE_EXECUTION_ROLE` - Production environment role ARN (optional)

## AWS Profile Configuration

The scripts use AWS profiles:
- `default` - For testing/staging environments
- `aillc` - For production environment

Ensure these profiles are configured in `~/.aws/config` and `~/.aws/credentials`.
