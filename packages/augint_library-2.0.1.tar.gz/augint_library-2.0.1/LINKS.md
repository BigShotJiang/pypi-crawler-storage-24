# AI Documentation Navigation - augint-library

This file provides Claude with efficient access to augint-library documentation. Each link includes context-optimized documentation designed for AI consumption.

## 🎯 Start Here - Common Tasks

### Creating a New Library
1. [Library Module Template](./guides/ai/templates/library-module.md) - Complete module structure (120 lines)
2. [Library APIs](./guides/ai/common-patterns/library-apis.md) - Exposing functions properly (180 lines)
3. [Package Structure](./guides/ai/architecture/package-structure.md) - Directory layout (40 lines)

### Building a CLI
1. [Creating CLIs](./guides/ai/common-patterns/creating-clis.md) - Click patterns & examples (150 lines)
2. [CLI Command Template](./guides/ai/templates/cli-command.md) - Ready-to-use templates (200 lines)

### Testing & Quality
1. [Testing Patterns](./guides/ai/common-patterns/testing-patterns.md) - TDD with 90%+ coverage (250 lines)
2. [Testing Requirements](./guides/ai/quick-reference/testing.md) - Quick testing reference (40 lines)

## 🚀 Quick References
- [Library Commands](./guides/ai/quick-reference/commands.md) - Essential make/uv commands (30 lines)
- [Publishing Guide](./guides/ai/quick-reference/publishing.md) - PyPI release process (35 lines)
- [Feature Flags Quick Ref](./guides/ai/quick-reference/feature-flags.md) - Feature flag commands (50 lines)

## 💡 Common Patterns
- **NEW** [Creating CLIs](./guides/ai/common-patterns/creating-clis.md) - Click CLI patterns (150 lines)
- **NEW** [Library APIs](./guides/ai/common-patterns/library-apis.md) - Exposing library functions (180 lines)
- **NEW** [Error Handling](./guides/ai/common-patterns/error-handling.md) - Production error patterns (200 lines)
- **NEW** [Configuration](./guides/ai/common-patterns/configuration.md) - Config management patterns (220 lines)
- **NEW** [Testing Patterns](./guides/ai/common-patterns/testing-patterns.md) - TDD patterns (250 lines)

## 🏗️ Architecture
- [Package Structure](./guides/ai/architecture/package-structure.md) - Directory layout (40 lines)
- [Module Design](./guides/ai/architecture/module-design.md) - Public API patterns (45 lines)
- [Error Handling](./guides/ai/architecture/error-handling.md) - Exception hierarchy (35 lines)

## 💻 Development
- [TDD Workflow](./guides/ai/development/tdd-workflow.md) - Test-first development (45 lines)
- [Type Hints](./guides/ai/development/type-hints.md) - Typing patterns (40 lines)
- [Documentation](./guides/ai/development/documentation.md) - Docstring standards (35 lines)
- [Fixtures](./guides/ai/development/fixtures.md) - pytest fixture patterns (40 lines)
- [Merge Strategy](./guides/development/merge-strategy.md) - Git merge configuration (80 lines)
- [Renovate](./guides/development/renovate.md) - Dependency management (150 lines)

## 📦 Publishing
- [Version Management](./guides/ai/publishing/versioning.md) - Semantic versioning (30 lines)
- [Release Process](./guides/ai/publishing/release.md) - Build and publish (40 lines)
- [Changelog](./guides/ai/publishing/changelog.md) - Changelog generation (35 lines)

## 🛡️ Quality
- [Coverage Requirements](./guides/ai/quality/coverage.md) - 90%+ enforcement (35 lines)
- [Security Scanning](./guides/ai/quality/security.md) - Bandit/safety usage (40 lines)
- [Linting Standards](./guides/ai/quality/linting.md) - Ruff configuration (35 lines)

## 🎯 Features
- [Feature Flags Guide](./guides/features/feature-flags.md) - Complete documentation (400 lines)
- [Feature Flags API](./guides/ai/api/feature-flags-api.md) - API reference (350 lines)
- [Feature Flag Patterns](./guides/patterns/feature-flag-patterns.md) - Advanced patterns (450 lines)

## 🔧 Troubleshooting
- [Import Errors](./guides/ai/troubleshooting/imports.md) - Module import issues (40 lines)
- [Test Failures](./guides/ai/troubleshooting/tests.md) - Common test problems (45 lines)
- [Publishing Issues](./guides/ai/troubleshooting/publishing.md) - PyPI upload errors (35 lines)

## 📋 Templates
- **NEW** [Library Module](./guides/ai/templates/library-module.md) - Complete module template (120 lines)
- **NEW** [CLI Command](./guides/ai/templates/cli-command.md) - CLI templates (200 lines)
- [Module Template](./guides/ai/templates/module.md) - Basic module structure (30 lines)
- [Test Template](./guides/ai/templates/test.md) - Test file structure (35 lines)
- [CLI Template](./guides/ai/templates/cli.md) - Basic Click patterns (40 lines)

---

## 📚 Full Documentation (Human-Readable)

For comprehensive guides and detailed explanations:

- [Contributing Guide](./CONTRIBUTING.md) - Complete contribution workflow
- [Architecture Documentation](./guides/architecture/) - Design principles and decisions
- [Setup Guides](./guides/setup/) - Environment setup and configuration
- [Development Guides](./guides/development/) - In-depth development topics
- [Troubleshooting Guide](./guides/troubleshooting/) - Detailed debugging help

---

## Usage Instructions for Claude

1. **Start with "Start Here"**: For common tasks, use the Start Here section
2. **Use Common Patterns**: New pattern guides have complete, working examples
3. **Templates are Ready-to-Use**: Copy and modify templates for quick starts
4. **90% Coverage**: All patterns assume 90%+ test coverage requirement
5. **Type Safety**: Heavy emphasis on type hints and mypy compliance

## Quick Decision Tree

- **Creating a new Python library?** → Start with Library Module Template
- **Need to add a CLI?** → Use Creating CLIs guide + CLI Command Template  
- **Writing tests?** → Check Testing Patterns for TDD approach
- **Handling errors?** → See Error Handling patterns
- **Managing config?** → Configuration patterns has you covered
