#!/bin/bash
export CI=true
export PYTHONDONTWRITEBYTECODE=1
export PYTEST_CURRENT_TEST=skip
uv run pytest -m 'not slow and not ci_only and not integration' \
    --tb=no \
    --no-header \
    -q \
    --maxfail=1 \
    -x \
    --no-cov \
    --disable-warnings \
    -p no:cacheprovider \
    -p no:stepwise \
    --quiet \
    2>/dev/null
