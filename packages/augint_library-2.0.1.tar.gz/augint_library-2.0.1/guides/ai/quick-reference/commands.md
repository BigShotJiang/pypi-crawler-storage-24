# Library Development Commands

Essential commands for augint-library development.

## Daily Development
```bash
# Setup
make install         # Install deps + pre-commit hooks

# Testing (90% coverage required)
make test           # Run all tests
make test-unit      # Unit tests only
make test-cov       # With coverage report

# Quality
make lint           # Ruff auto-fix
make format         # Code formatting
make security       # Bandit + safety scans
make typecheck      # mypy type checking
```

## Publishing Workflow
```bash
# Version bumps are handled by semantic-release

# Build and publish
make build          # Create dist/
make publish        # Upload to PyPI
```

## Common Patterns
```bash
# Add dependency
uv add requests
uv add --group dev pytest-mock

# Run specific test
pytest tests/test_core.py::test_function -v

# Check merge strategy
grep MERGE_STRATEGY .env

# Change merge strategy
# 1. Update .env: MERGE_STRATEGY=rebase
# 2. Run: gh repo edit --disable-squash-merge --enable-rebase-merge
```
