# Feature Flags Quick Reference

## Essential Commands

```python
# Import
from augint_library.feature_flags import FeatureFlags, feature_flag

# Initialize
flags = FeatureFlags()

# Register flag
flags.register("new_feature", default="disabled")

# Check flag
if flags.is_enabled("new_feature"):
    # new code
```

## CLI Commands
```bash
augint flags list                    # List all flags
augint flags set <name> <state>      # Set flag state
augint flags show <name>             # Show flag details
augint flags test <name>             # Test flag evaluation
```

## States
- `enabled` - Always on
- `disabled` - Always off
- `percentage:N` - On for N% of users (0-100)
- `conditional` - Based on custom logic

## Environment Variables
```bash
export FEATURE_FLAG_MY_FEATURE=enabled
export FEATURE_FLAG_API_V2=percentage:25
```

## Decorator Usage
```python
@feature_flag("new_algorithm", fallback=old_algorithm)
def process_data(data):
    return new_logic(data)
```

## Testing
```python
# Override in tests
with flags.override("feature", "enabled"):
    assert my_function() == "new_behavior"
```
