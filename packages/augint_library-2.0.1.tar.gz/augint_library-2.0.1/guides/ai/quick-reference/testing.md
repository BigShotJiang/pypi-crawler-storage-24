# Testing Requirements - 90% Coverage

augint-library enforces 90%+ test coverage for quality assurance.

## Coverage Configuration
```toml
# pyproject.toml
[tool.coverage.run]
source = ["src/augint_library"]
omit = ["*/tests/*", "*/__init__.py"]

[tool.coverage.report]
fail_under = 90
show_missing = true
```

## Test Structure
```python
# tests/test_core.py
import pytest
from augint_library.core import process_data

class TestProcessData:
    """Group related tests in classes."""

    def test_valid_input(self):
        """Test happy path."""
        assert process_data("valid") == "VALID"

    def test_empty_input(self):
        """Test edge case."""
        assert process_data("") == "DEFAULT"

    def test_none_input(self):
        """Test error case."""
        with pytest.raises(ValueError):
            process_data(None)
```

## Coverage Commands
```bash
# Check coverage
pytest --cov=augint_library --cov-report=term-missing

# HTML report
pytest --cov=augint_library --cov-report=html
# Open htmlcov/index.html
```
