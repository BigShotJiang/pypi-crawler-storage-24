# PyPI Publishing Quick Reference

## Prerequisites
```bash
# Verify setup
uv --version
uv sync --dry-run  # Validate pyproject.toml
```

## Local Testing
```bash
# Build distribution
uv build
ls dist/  # Should see .whl and .tar.gz files

# Test with TestPyPI
uv publish --publish-url https://test.pypi.org/legacy/
```

## Production Release
```bash
# Automatic via CI/CD (recommended)
git tag v1.0.0
git push origin v1.0.0

# Manual publish (if needed)
uv publish
```

## Troubleshooting
- **403 Forbidden**: Check PyPI token permissions
- **Version exists**: Bump version in pyproject.toml
- **Missing files**: Run `uv build` first

## CI/CD Publishing
Pipeline automatically publishes on:
- Tags matching `v*` pattern
- Uses trusted publishing (no API keys)
