# Coverage Requirements

## 90% Minimum Coverage
```toml
# pyproject.toml
[tool.coverage.report]
fail_under = 90
show_missing = true
```

## Running Coverage
```bash
# Quick check
uv run pytest --cov=src --cov-fail-under=90

# Detailed HTML report
uv run pytest --cov=src --cov-report=html
open htmlcov/index.html
```

## Coverage Exclusions
```python
# Defensive programming patterns
if TYPE_CHECKING:  # pragma: no cover
    from typing import Protocol

# Unreachable code
def _assert_never(x: Never) -> Never:  # pragma: no cover
    raise AssertionError(f"Unexpected {x}")
```

## Common Patterns
- Test all public functions
- Test error conditions
- Test edge cases
- Mock external dependencies
- Use parametrized tests

## CI/CD Enforcement
Pipeline fails if coverage < 90%
Check job: "Run pytest CI/CD tests"
