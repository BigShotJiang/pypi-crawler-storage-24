# Python Package Structure

Standard structure for augint-library packages.

## Directory Layout
```
augint-library/
├── src/
│   └── augint_library/         # Package root
│       ├── __init__.py         # Public API exports
│       ├── core.py             # Main functionality
│       ├── models.py           # Data models
│       ├── utils.py            # Helper functions
│       └── exceptions.py       # Custom exceptions
├── tests/
│   ├── conftest.py            # Shared fixtures
│   ├── test_core.py           # Core tests
│   └── test_utils.py          # Utility tests
├── pyproject.toml             # uv config
├── Makefile                   # Dev commands
└── .pre-commit-config.yaml    # Git hooks
```

## Public API Design
```python
# src/augint_library/__init__.py
"""Augint Library - Main package exports."""
from .core import Processor, analyze_data
from .models import DataModel, ConfigModel
from .exceptions import AugintError, ValidationError

__version__ = "1.0.0"
__all__ = [
    "Processor",
    "analyze_data",
    "DataModel",
    "ConfigModel",
    "AugintError",
    "ValidationError",
]
```

## Import Usage
```python
# Users import from top level
from augint_library import Processor, AugintError
```
