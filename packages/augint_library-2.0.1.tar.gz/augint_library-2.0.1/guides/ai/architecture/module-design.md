# Module Design Patterns

## Public API Structure
```python
# src/augint_library/__init__.py
from .core import main_function
from .exceptions import CustomError
from .feature_flags import FeatureFlags

__all__ = ["main_function", "CustomError", "FeatureFlags"]
__version__ = "1.0.0"
```

## Module Organization
```
src/augint_library/
├── __init__.py      # Public exports
├── core.py          # Main functionality
├── protocols.py     # Type protocols
├── exceptions.py    # Custom exceptions
└── _internal.py     # Private implementation
```

## Design Principles
1. **Single Responsibility**: One module = one concern
2. **Protocol-First**: Define interfaces before implementation
3. **Private by Default**: Use `_` prefix for internal modules
4. **Type Safety**: All public APIs must have type hints

## Example Module
```python
"""Module docstring."""
from typing import Protocol

class DataProcessor(Protocol):
    """Protocol for data processing."""
    def process(self, data: str) -> str: ...

def create_processor() -> DataProcessor:
    """Factory function with clear return type."""
    from ._internal import _ProcessorImpl
    return _ProcessorImpl()
```
