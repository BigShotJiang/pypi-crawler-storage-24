# Error Handling Architecture

## Exception Hierarchy
```python
# src/augint_library/exceptions.py
class AugintError(Exception):
    """Base exception for all library errors."""
    error_code: str = "AUGINT_ERROR"

class ValidationError(AugintError):
    """Invalid input or configuration."""
    error_code = "VALIDATION_ERROR"

class NetworkError(AugintError):
    """Network-related errors."""
    error_code = "NETWORK_ERROR"
```

## Usage Pattern
```python
try:
    result = risky_operation()
except ValidationError as e:
    logger.error(f"Validation failed: {e}", error_code=e.error_code)
    raise
except AugintError as e:
    # Catch all library errors
    logger.error(f"Operation failed: {e}")
    return None
```

## Best Practices
1. Always inherit from `AugintError`
2. Include descriptive error codes
3. Log errors with context
4. Re-raise for critical errors
5. Return None/default for recoverable errors

## Testing Errors
```python
def test_validation_error():
    with pytest.raises(ValidationError, match="Invalid input"):
        validate_input("")
```
