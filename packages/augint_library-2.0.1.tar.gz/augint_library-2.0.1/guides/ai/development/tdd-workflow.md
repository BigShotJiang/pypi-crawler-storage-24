# Test-Driven Development Workflow

## TDD Cycle
1. **Red**: Write failing test
2. **Green**: Minimal code to pass
3. **Refactor**: Improve implementation

## Example Workflow
```python
# Step 1: Write test first (test_feature.py)
def test_calculate_sum():
    assert calculate_sum(2, 3) == 5

# Step 2: Minimal implementation (feature.py)
def calculate_sum(a: int, b: int) -> int:
    return a + b

# Step 3: Run tests
uv run pytest tests/test_feature.py -v
```

## Coverage Requirements
```bash
# Check coverage
uv run pytest --cov=src --cov-report=term-missing

# Must maintain 90%+ coverage
# Add pragma comments for defensive code:
if TYPE_CHECKING:  # pragma: no cover
    from typing import Protocol
```

## Test Organization
```
tests/
├── unit/           # Isolated unit tests
├── integration/    # External dependencies
└── conftest.py     # Shared fixtures
```

## Quick Commands
```bash
make test           # Run all tests
make test-unit      # Unit tests only
make coverage       # Generate coverage report
```
