# AI Guide: Merge Strategy Configuration

Quick reference for Claude on handling merge strategies in augint-library projects.

## Current Configuration

Check `.env` for:
```bash
MERGE_STRATEGY=squash  # or rebase, merge
```

## Key Points

1. **Strategy is in .env**: Single source of truth
2. **Scripts read automatically**: `/ai-ship` uses it
3. **Default is squash**: Falls back if not set

## When User Wants to Change

```bash
# 1. Update .env
MERGE_STRATEGY=rebase

# 2. Update GitHub settings
gh repo edit --disable-squash-merge --enable-rebase-merge
```

## Strategy Characteristics

**squash**:
- One commit per PR
- Clean history
- Poor for bisect
- Good for beginners

**rebase**:
- Preserves commits
- Linear history
- Great for bisect
- Needs discipline

**merge**:
- Full history
- Merge commits
- Non-linear
- Audit trail

## In Scripts

The `/ai-ship` command handles it:
```bash
MERGE_STRATEGY=${MERGE_STRATEGY:-squash}
gh pr merge --auto --${MERGE_STRATEGY}
```

## Common Tasks

### Check current strategy
```bash
grep MERGE_STRATEGY .env
```

### Switch strategies
```bash
# Update .env then:
gh repo edit --disable-[old]-merge --enable-[new]-merge
```

## Remember

- Don't hardcode merge types
- Always use ${MERGE_STRATEGY}
- Default to squash if missing
- Document changes in CLAUDE.md
