# Type Hints Guide

## Basic Types
```python
from typing import Optional, Union, List, Dict, Any

def process_data(
    name: str,
    count: int = 0,
    tags: Optional[List[str]] = None
) -> Dict[str, Any]:
    """Process data with proper type hints."""
    return {"name": name, "count": count, "tags": tags or []}
```

## Protocol Types
```python
from typing import Protocol, runtime_checkable

@runtime_checkable
class Processor(Protocol):
    """Protocol for processors."""
    def process(self, data: str) -> str: ...

def handle_processor(proc: Processor) -> None:
    if isinstance(proc, Processor):
        result = proc.process("data")
```

## Generic Types
```python
from typing import TypeVar, Generic

T = TypeVar("T")

class Container(Generic[T]):
    def __init__(self, value: T) -> None:
        self._value = value

    def get(self) -> T:
        return self._value
```

## Mypy Configuration
```toml
# pyproject.toml
[tool.mypy]
strict = true
disallow_untyped_defs = true
```

## Common Patterns
- Use `Optional[T]` for nullable types
- Prefer `list[str]` over `List[str]` (Python 3.9+)
- Use `Protocol` for structural typing
- Add `py.typed` marker file
