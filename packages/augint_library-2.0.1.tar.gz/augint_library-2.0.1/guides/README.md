# 📚 augint-library Documentation Hub

Welcome to the comprehensive documentation for augint-library. This hub provides organized access to all guides, tutorials, and reference materials.

> **📋 Planning Documents**: When using `claude /plan`, project planning documents (PRD.md, TECHNICAL_SPECIFICATION.md, USER_STORIES.md) are generated in this guides directory for maximum Claude Code context inclusion.

## 🗺️ Documentation Map

```mermaid
graph TD
    A[Documentation Hub] --> B[Setup Guides]
    A --> C[Development]
    A --> D[Architecture]
    A --> E[AI Guides]
    A --> F[Troubleshooting]

    B --> G[Bootstrap]
    B --> H[Contributing]

    C --> I[Patterns]
    C --> J[Testing]

    D --> K[Design]
    D --> L[Decisions]

    E --> M[Templates]
    E --> N[Quick Refs]

    style A fill:#e3f2fd
    style E fill:#f3e5f5
```

## 🚀 Getting Started

### For New Users
1. **[Bootstrap Guide](./setup/bootstrap.md)** - Set up your project from scratch
2. **[Quick Start Examples](./ai/common-patterns/)** - Common patterns with code
3. **[Troubleshooting](./troubleshooting/README.md)** - Solve common issues

### For Contributors
1. **[Contributing Guide](../CONTRIBUTING.md)** - How to contribute
2. **[Development Workflow](./development/README.md)** - Development best practices
3. **[Architecture Overview](./architecture/README.md)** - System design

### For AI/Claude
1. **[LINKS.md](../LINKS.md)** - AI-optimized navigation
2. **[Common Patterns](./ai/common-patterns/)** - Ready-to-use patterns
3. **[Templates](./ai/templates/)** - Copy-paste templates

## 📚 Guide Categories

### 🚀 Setup & Getting Started
Essential guides for getting up and running with the project.

| Guide | Description |
|-------|-------------|
| **[Bootstrap Guide](setup/bootstrap.md)** | Complete project setup instructions |
| **[Contributing Guide](setup/contributing.md)** | How to contribute to the project |

### 🛠️ Development Guides
Resources for developers working on or with this project.

| Guide | Description |
|-------|-------------|
| **[Claude Development Guide](development/claude-guide.md)** | Comprehensive guide for AI-assisted development |
| **[Automation Testing](development/automation-test.md)** | Automated testing workflow documentation |
| **[Merge Strategy](development/merge-strategy.md)** | Configurable git merge approach for PRs |
| **[DevOps Pipeline](development/devops-pipeline.md)** | CI/CD pipeline architecture and workflows |
| **[Renovate](development/renovate.md)** | Automated dependency management configuration |

### 🏗️ Architecture
System design and architectural decisions.

| Guide | Description |
|-------|-------------|
| **[Architecture Overview](architecture/README.md)** | System design with diagrams |
| **[Design Patterns](architecture/design-patterns.md)** | Common patterns used |
| **[API Guidelines](architecture/api-guidelines.md)** | API design principles |

### 🤖 AI-Optimized Guides
Concise, example-rich guides optimized for AI consumption.

| Category | Guides |
|----------|--------|
| **[Common Patterns](ai/common-patterns/)** | CLIs, APIs, Error Handling, Config, Testing |
| **[Templates](ai/templates/)** | Library Module, CLI Command |
| **[Quick Reference](ai/quick-reference/)** | Commands, Publishing, Testing |

### 🔧 Troubleshooting
Solutions for common issues and platform-specific guidance.

| Guide | Description |
|-------|-------------|
| **[Troubleshooting Hub](troubleshooting/README.md)** | Visual troubleshooting guide |
| **[Claude Code on Windows](development/troubleshooting/claude-code-windows.md)** | Windows-specific setup |

### 📋 Project Resources
Project-specific documentation and templates.

| Guide | Description |
|-------|-------------|
| **[Augint Library README](project/augint-library-readme.md)** | Template-specific README content |

## 🔗 External Documentation

### Live Dashboards
- **[API Documentation](https://svange.github.io/augint-library)** - Auto-generated API docs
- **[Unit Test Reports](https://svange.github.io/augint-library/unit-test-report.html)** - Latest test results
- **[Integration Tests](https://svange.github.io/augint-library/integration-test-report.html)** - Integration test reports
- **[Code Coverage](https://svange.github.io/augint-library/htmlcov/index.html)** - Coverage analysis
- **[Security Reports](https://svange.github.io/augint-library/security-reports.html)** - Security scan results
- **[License Compliance](https://svange.github.io/augint-library/license-compatibility.html)** - License compatibility

### Development Tools
- **[GitHub Repository](https://github.com/svange/augint-library)** - Source code and issues
- **[CI/CD Pipeline](https://github.com/svange/augint-library/actions)** - Build and deployment status
- **[PyPI Package](https://pypi.org/project/augint-library/)** - Published package

## 📖 Quick Navigation

**New to the Project?**
1. Start with the [Bootstrap Guide](setup/bootstrap.md)
2. Review the [Contributing Guide](setup/contributing.md)
3. Check the [Claude Development Guide](development/claude-guide.md) for AI-assisted workflows

**Developing?**
- Use the [Claude Development Guide](development/claude-guide.md) for best practices
- Check [Troubleshooting](development/troubleshooting/) for platform-specific issues

**Contributing?**
- Follow the [Contributing Guide](setup/contributing.md)
- Review the development guides for coding standards and workflows

---

For the main project overview, return to the [main README](../README.md).
