"""Unit tests for augint-library."""
