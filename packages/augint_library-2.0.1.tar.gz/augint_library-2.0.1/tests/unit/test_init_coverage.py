"""Unit tests to ensure complete __init__.py coverage."""

import pytest


@pytest.mark.unit
def test_all_imports_from_init() -> None:
    """Test that all imports in __init__.py work correctly."""
    # Import everything from the main module
    from augint_library import (
        AdvancedProcessor,
        CacheProvider,
        ConfigurableClient,
        DataProcessor,
        EventHandler,
        ProcessingResult,
        __version__,
        print_hi,
    )

    # Test that the print_hi import from cli works
    assert callable(print_hi)

    # Test that version is a string
    assert isinstance(__version__, str)

    # Test that all protocol imports work (they should be types/classes)
    protocols = [
        DataProcessor,
        ProcessingResult,
        ConfigurableClient,
        EventHandler,
        CacheProvider,
        AdvancedProcessor,
    ]

    for protocol in protocols:
        assert protocol is not None
        # Protocol classes should have __name__ attribute
        assert hasattr(protocol, "__name__")


@pytest.mark.unit
def test_init_module_attributes() -> None:
    """Test that __init__.py module has the expected attributes."""
    import augint_library

    # Test module has version
    assert hasattr(augint_library, "__version__")

    # Test module has print_hi function
    assert hasattr(augint_library, "print_hi")
    assert callable(augint_library.print_hi)

    # Test that calling print_hi works (this exercises the import)
    import io
    from contextlib import redirect_stdout

    # Capture print output
    captured_output = io.StringIO()
    with redirect_stdout(captured_output):
        augint_library.print_hi("test")

    output = captured_output.getvalue()
    assert "Hi test" in output


@pytest.mark.unit
def test_init_all_list_coverage() -> None:
    """Test that __all__ list in __init__.py is complete."""
    import augint_library

    expected_all = [
        "print_hi",
        "__version__",
        # Protocols
        "DataProcessor",
        "ProcessingResult",
        "ConfigurableClient",
        "EventHandler",
        "CacheProvider",
        "AdvancedProcessor",
    ]

    # Check that __all__ is defined
    assert hasattr(augint_library, "__all__")

    # Check all expected items are in __all__
    module_all = augint_library.__all__
    for expected_item in expected_all:
        assert expected_item in module_all, f"Missing {expected_item} in __all__"
