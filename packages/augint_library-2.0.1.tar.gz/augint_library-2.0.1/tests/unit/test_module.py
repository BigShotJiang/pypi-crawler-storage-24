"""Unit tests for module imports and version."""

import pytest

import augint_library
from augint_library import (
    AdvancedProcessor,
    CacheProvider,
    ConfigurableClient,
    DataProcessor,
    EventHandler,
    ProcessingResult,
    __version__,
    print_hi,
)


@pytest.mark.unit
def test_version_is_defined() -> None:
    """Test that __version__ is defined and is a string."""
    assert hasattr(augint_library, "__version__")
    assert isinstance(__version__, str)
    assert len(__version__) > 0


@pytest.mark.unit
def test_print_hi_is_importable() -> None:
    """Test that print_hi function can be imported."""
    assert hasattr(augint_library, "print_hi")
    assert callable(print_hi)


@pytest.mark.unit
def test_all_protocols_importable() -> None:
    """Test that all protocols can be imported."""
    # Test that protocols are classes/types
    assert DataProcessor is not None
    assert ProcessingResult is not None
    assert ConfigurableClient is not None
    assert EventHandler is not None
    assert CacheProvider is not None
    assert AdvancedProcessor is not None


@pytest.mark.unit
def test_module_all_exports() -> None:
    """Test that __all__ contains expected exports."""
    expected_exports = [
        "print_hi",
        "__version__",
        "DataProcessor",
        "ProcessingResult",
        "ConfigurableClient",
        "EventHandler",
        "CacheProvider",
        "AdvancedProcessor",
    ]

    for export in expected_exports:
        assert hasattr(augint_library, export), f"Missing export: {export}"


@pytest.mark.unit
def test_version_format() -> None:
    """Test that version follows semantic versioning format."""
    import re

    # Basic semantic version pattern: major.minor.patch
    version_pattern = r"^\d+\.\d+\.\d+.*$"
    assert re.match(version_pattern, __version__), (
        f"Version {__version__} doesn't match semantic versioning"
    )
