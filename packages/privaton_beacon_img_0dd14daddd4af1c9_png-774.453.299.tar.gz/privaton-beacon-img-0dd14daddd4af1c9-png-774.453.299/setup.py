from setuptools import setup
setup(name='privaton-beacon-img-0dd14daddd4af1c9-png', version='774.453.299', py_modules=['data'])
