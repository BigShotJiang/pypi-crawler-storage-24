from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.crypto_compare_response import CryptoCompareResponse
from ...models.error_response import ErrorResponse
from ...models.historical_limit_error import HistoricalLimitError
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    symbols: str,
    days: int | Unset = 7,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    params["symbols"] = symbols

    params["days"] = days

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/reddit/crypto/v1/compare",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    Any
    | CryptoCompareResponse
    | ErrorResponse
    | HTTPValidationError
    | HistoricalLimitError
    | None
):
    if response.status_code == 200:
        response_200 = CryptoCompareResponse.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = cast(Any, None)
        return response_400

    if response.status_code == 401:
        response_401 = ErrorResponse.from_dict(response.json())

        return response_401

    if response.status_code == 403:
        response_403 = HistoricalLimitError.from_dict(response.json())

        return response_403

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 429:
        response_429 = ErrorResponse.from_dict(response.json())

        return response_429

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    Any
    | CryptoCompareResponse
    | ErrorResponse
    | HTTPValidationError
    | HistoricalLimitError
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    symbols: str,
    days: int | Unset = 7,
) -> Response[
    Any
    | CryptoCompareResponse
    | ErrorResponse
    | HTTPValidationError
    | HistoricalLimitError
]:
    """Compare multiple crypto tokens

     Compares up to 10 crypto symbols over the selected period using unified Reddit sentiment metrics.

    Args:
        symbols (str): Comma-separated symbols (e.g., BTC,ETH,SOL)
        days (int | Unset): Time period in days (1-30 free, 1-90 paid) Default: 7.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | CryptoCompareResponse | ErrorResponse | HTTPValidationError | HistoricalLimitError]
    """

    kwargs = _get_kwargs(
        symbols=symbols,
        days=days,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    symbols: str,
    days: int | Unset = 7,
) -> (
    Any
    | CryptoCompareResponse
    | ErrorResponse
    | HTTPValidationError
    | HistoricalLimitError
    | None
):
    """Compare multiple crypto tokens

     Compares up to 10 crypto symbols over the selected period using unified Reddit sentiment metrics.

    Args:
        symbols (str): Comma-separated symbols (e.g., BTC,ETH,SOL)
        days (int | Unset): Time period in days (1-30 free, 1-90 paid) Default: 7.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | CryptoCompareResponse | ErrorResponse | HTTPValidationError | HistoricalLimitError
    """

    return sync_detailed(
        client=client,
        symbols=symbols,
        days=days,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    symbols: str,
    days: int | Unset = 7,
) -> Response[
    Any
    | CryptoCompareResponse
    | ErrorResponse
    | HTTPValidationError
    | HistoricalLimitError
]:
    """Compare multiple crypto tokens

     Compares up to 10 crypto symbols over the selected period using unified Reddit sentiment metrics.

    Args:
        symbols (str): Comma-separated symbols (e.g., BTC,ETH,SOL)
        days (int | Unset): Time period in days (1-30 free, 1-90 paid) Default: 7.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | CryptoCompareResponse | ErrorResponse | HTTPValidationError | HistoricalLimitError]
    """

    kwargs = _get_kwargs(
        symbols=symbols,
        days=days,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    symbols: str,
    days: int | Unset = 7,
) -> (
    Any
    | CryptoCompareResponse
    | ErrorResponse
    | HTTPValidationError
    | HistoricalLimitError
    | None
):
    """Compare multiple crypto tokens

     Compares up to 10 crypto symbols over the selected period using unified Reddit sentiment metrics.

    Args:
        symbols (str): Comma-separated symbols (e.g., BTC,ETH,SOL)
        days (int | Unset): Time period in days (1-30 free, 1-90 paid) Default: 7.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | CryptoCompareResponse | ErrorResponse | HTTPValidationError | HistoricalLimitError
    """

    return (
        await asyncio_detailed(
            client=client,
            symbols=symbols,
            days=days,
        )
    ).parsed
