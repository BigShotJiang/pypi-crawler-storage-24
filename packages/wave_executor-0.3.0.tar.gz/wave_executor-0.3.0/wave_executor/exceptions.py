"""
Exceptions and state primitives for wave execution.
"""

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, Optional


class WaveCircularDependencyError(Exception):
    """Raised when a circular dependency is detected in a task or node graph."""

    def __init__(self, cycle_members: set):
        self.cycle_members = cycle_members
        super().__init__(
            f"Circular dependency detected involving: {', '.join(sorted(cycle_members))}"
        )


@dataclass
class WaveSignal:
    """Signal event for wave state changes."""

    signal_type: str   # "wave_complete" | "wave_failed" | "abort" | etc.
    wave_id: str
    data: Dict[str, Any]
    timestamp: Optional[datetime] = None

    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now()
