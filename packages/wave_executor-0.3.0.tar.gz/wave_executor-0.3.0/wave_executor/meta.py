"""
MetaDAG — DAG of DAGs.

Orchestrates multiple :class:`~wave_executor.dag.DAGExecutor` /
:class:`~wave_executor.reconciler.WaveReconciler` instances as nodes in a
higher-level dependency graph.  Each node runs its own task graph; when it
completes, its outputs become available to downstream nodes.

Diagram::

                 ┌─────────────┐
                 │   Node A    │  (DAGExecutor: fetch + preprocess)
                 │  a1, a2     │
                 └──────┬──────┘
                        │  outputs: {a1: …, a2: …}
                        ▼
        ┌───────────────┴───────────────┐
        │                               │
┌───────┴───────┐               ┌───────┴───────┐
│    Node B     │               │    Node C     │
│ (Reconciler:  │               │ (DAGExecutor: │
│ long-running) │               │  analysis)    │
└───────┬───────┘               └───────┬───────┘
        │                               │
        └───────────────┬───────────────┘
                        │
                 ┌──────┴──────┐
                 │   Node D    │  (DAGExecutor: aggregate + store)
                 └─────────────┘

Key design:
- ``asyncio.Event`` per node — zero-overhead dep signalling
- Cycle detection via :meth:`DAGExecutor._validate_acyclic`
- ``"dag"`` nodes: one-shot :class:`DAGExecutor` execution
- ``"reconciler"`` nodes: :class:`WaveReconciler` run until :meth:`wait_until_complete`
- Upstream outputs injected into downstream task specs under
  ``'_upstream_outputs'``: ``{node_id: {task_id: output}}``
- Global semaphore limits concurrent node execution
- ``on_event()`` sync/async callbacks for meta-level observability
"""

import asyncio
import logging
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Awaitable, Callable, Dict, List, Optional, Set

from .dag import AdaptiveSemaphore, DAGExecutionResult, DAGExecutor
from .config import WaveConfig
from .reconciler import WaveReconciler

logger = logging.getLogger(__name__)

_FAILED_STATUSES = frozenset({"failed", "timeout", "skipped"})


# ============================================================================
# Data classes
# ============================================================================

@dataclass
class MetaDAGNodeSpec:
    """
    Configuration for one node in the MetaDAG.

    A node encapsulates a complete task graph (DAGExecutor or WaveReconciler)
    that runs as a single unit within the meta-level dependency graph.
    """

    node_id: str
    """Unique identifier for this node."""

    tasks: Dict[str, Any]
    """Task specs for the executor inside this node: ``{task_id: task_spec}``."""

    task_executor: Callable[[str, Any], Awaitable[Any]]
    """Async callable ``(task_id, task_spec) → result`` for tasks within this node."""

    specialist: Optional[str] = None
    """Specialist name for budget carve-out (defaults to node_id when None).
    Used by MetaDAG to look up ``config.specialist_budgets[specialist]``."""

    node_type: str = "dag"
    """``'dag'`` (one-shot DAGExecutor) or ``'reconciler'`` (WaveReconciler until done)."""

    task_dependencies: Dict[str, Set[str]] = field(default_factory=dict)
    """Internal task-level dependency graph within this node."""

    config: Optional[WaveConfig] = None
    """Per-node WaveConfig (overrides MetaDAG default if set)."""

    inject_dep_outputs: bool = False
    """Pass completed dep task outputs into downstream task specs (node-internal)."""

    policies: Optional[Dict[str, str]] = None
    """Restart policies per task_id (reconciler nodes only)."""

    completion_timeout: float = 300.0
    """Max seconds to wait for a reconciler node to complete (default 5 min)."""

    completion_poll_interval: float = 0.1
    """How often to poll reconciler completion status (seconds)."""


@dataclass
class MetaDAGNodeResult:
    """Result of executing one MetaDAG node."""

    node_id: str
    status: str  # "success" | "failed" | "timeout" | "skipped"
    task_outputs: Dict[str, Any] = field(default_factory=dict)
    """Successful task outputs: ``{task_id: output}``."""

    dag_result: Optional[DAGExecutionResult] = None
    """Full DAGExecutionResult (dag nodes only)."""

    error: Optional[str] = None
    started_at: datetime = field(default_factory=datetime.now)
    completed_at: Optional[datetime] = None

    @property
    def duration_ms(self) -> float:
        if not self.completed_at:
            return 0.0
        return (self.completed_at - self.started_at).total_seconds() * 1000

    def to_dict(self) -> Dict[str, Any]:
        return {
            "node_id": self.node_id,
            "status": self.status,
            "error": self.error,
            "duration_ms": round(self.duration_ms, 2),
            "task_output_keys": list(self.task_outputs.keys()),
            "started_at": self.started_at.isoformat(),
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
        }


@dataclass
class MetaDAGResult:
    """Result of executing the full MetaDAG."""

    execution_id: str
    node_results: Dict[str, MetaDAGNodeResult] = field(default_factory=dict)
    started_at: datetime = field(default_factory=datetime.now)
    completed_at: Optional[datetime] = None

    @property
    def total_nodes(self) -> int:
        return len(self.node_results)

    @property
    def successful_nodes(self) -> int:
        return sum(1 for r in self.node_results.values() if r.status == "success")

    @property
    def failed_nodes(self) -> int:
        return sum(1 for r in self.node_results.values() if r.status in ("failed", "timeout"))

    @property
    def skipped_nodes(self) -> int:
        return sum(1 for r in self.node_results.values() if r.status == "skipped")

    @property
    def duration_ms(self) -> float:
        if not self.completed_at:
            return 0.0
        return (self.completed_at - self.started_at).total_seconds() * 1000

    def to_dict(self) -> Dict[str, Any]:
        return {
            "execution_id": self.execution_id,
            "total_nodes": self.total_nodes,
            "successful_nodes": self.successful_nodes,
            "failed_nodes": self.failed_nodes,
            "skipped_nodes": self.skipped_nodes,
            "duration_ms": round(self.duration_ms, 2),
            "started_at": self.started_at.isoformat(),
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "nodes": {nid: r.to_dict() for nid, r in self.node_results.items()},
        }


# ============================================================================
# MetaDAG
# ============================================================================

class MetaDAG:
    """
    DAG of DAGs — orchestrates multiple DAGExecutor / WaveReconciler instances.

    Each node in the meta-DAG is itself a task graph.  Nodes start as soon as
    all their upstream nodes complete; outputs are optionally injected into each
    downstream node's task specs.

    Usage::

        async def fetch(task_id, spec): ...
        async def analyze(task_id, spec): ...

        meta = MetaDAG()
        meta.add_node(MetaDAGNodeSpec(
            node_id="fetch",
            tasks={"page_a": url_a, "page_b": url_b},
            task_executor=fetch,
        ))
        meta.add_node(MetaDAGNodeSpec(
            node_id="analyze",
            tasks={"report": {}},
            task_executor=analyze,
        ), depends_on=["fetch"])

        result = await meta.execute()
        print(result.successful_nodes)
    """

    def __init__(
        self,
        config: Optional[WaveConfig] = None,
        inject_dep_outputs: bool = True,
    ):
        """
        Args:
            config:             Default WaveConfig for all nodes (overridable per-node).
            inject_dep_outputs: When True, upstream node outputs are injected into
                                downstream task specs under ``'_upstream_outputs'``.
        """
        self.config = config or WaveConfig()
        self._inject_dep_outputs = inject_dep_outputs
        self._nodes: Dict[str, MetaDAGNodeSpec] = {}
        self._node_dependencies: Dict[str, Set[str]] = {}
        self._event_callbacks: List[Callable] = []

    def add_node(
        self,
        spec: MetaDAGNodeSpec,
        depends_on: Optional[List[str]] = None,
    ) -> "MetaDAG":
        """Register a node. Returns self for method chaining."""
        self._nodes[spec.node_id] = spec
        self._node_dependencies[spec.node_id] = set(depends_on or [])
        return self

    def on_event(self, callback: Callable) -> None:
        """Register a callback ``(event_type, event_dict)`` for meta-level events."""
        self._event_callbacks.append(callback)

    async def execute(self) -> MetaDAGResult:
        """
        Execute all nodes following the dependency graph.

        Raises:
            :class:`~wave_executor.exceptions.WaveCircularDependencyError`: if the node graph has a cycle.
            ValueError: if a dep references an unknown node_id.
        """
        if not self._nodes:
            return MetaDAGResult(
                execution_id=str(uuid.uuid4()),
                completed_at=datetime.now(),
            )

        DAGExecutor._validate_acyclic(self._nodes, self._node_dependencies)

        execution_id = str(uuid.uuid4())
        meta_result = MetaDAGResult(execution_id=execution_id)

        await self._emit_event(
            "META_EXECUTION_STARTED",
            execution_id=execution_id,
            total_nodes=len(self._nodes),
        )

        node_events: Dict[str, asyncio.Event] = {
            nid: asyncio.Event() for nid in self._nodes
        }
        node_results: Dict[str, MetaDAGNodeResult] = {}
        semaphore = AdaptiveSemaphore(
            initial=self.config.max_parallel_per_wave,
            min_val=self.config.min_parallel,
            max_val=self.config.max_parallel_per_wave,
            saturation_threshold=self.config.saturation_threshold,
            adaptive=self.config.adaptive_batch_window,
        )

        # Per-worker-group budget semaphores
        _group_sems: Dict[str, AdaptiveSemaphore] = {}
        for spec in self._nodes.values():
            g_name = spec.specialist or spec.node_id
            if g_name not in _group_sems:
                budget = self.config.specialist_budgets.get(
                    g_name, self.config.default_specialist_budget
                )
                node_cfg = spec.config or self.config
                _group_sems[g_name] = AdaptiveSemaphore(
                    initial=budget,
                    min_val=max(1, node_cfg.min_parallel),
                    max_val=budget,
                    saturation_threshold=node_cfg.saturation_threshold,
                    adaptive=node_cfg.adaptive_batch_window,
                )

        async def run_node(node_id: str, spec: MetaDAGNodeSpec) -> None:
            deps = self._node_dependencies.get(node_id, set())

            for dep_id in deps:
                await node_events[dep_id].wait()

            failed_deps = [
                d for d in deps
                if node_results.get(d) is not None
                and node_results[d].status in _FAILED_STATUSES
            ]
            if failed_deps:
                node_result = MetaDAGNodeResult(
                    node_id=node_id,
                    status="skipped",
                    error=f"Upstream nodes did not succeed: {', '.join(sorted(failed_deps))}",
                    completed_at=datetime.now(),
                )
                node_results[node_id] = node_result
                meta_result.node_results[node_id] = node_result
                node_events[node_id].set()
                await self._emit_event(
                    "NODE_SKIPPED",
                    execution_id=execution_id,
                    node_id=node_id,
                    failed_deps=failed_deps,
                )
                return

            upstream_outputs: Dict[str, Any] = {}
            if self._inject_dep_outputs:
                for dep_id in deps:
                    if dep_id in node_results:
                        upstream_outputs[dep_id] = node_results[dep_id].task_outputs

            await self._emit_event(
                "NODE_STARTED",
                execution_id=execution_id,
                node_id=node_id,
                node_type=spec.node_type,
            )

            g_name = spec.specialist or spec.node_id
            group_sem = _group_sems[g_name]
            try:
                async with semaphore:
                    node_result = await self._execute_node(
                        execution_id, node_id, spec, upstream_outputs, group_sem
                    )
            except Exception as exc:
                logger.exception("MetaDAG node '%s' raised: %s", node_id, exc)
                node_result = MetaDAGNodeResult(
                    node_id=node_id,
                    status="failed",
                    error=f"Scheduler error: {exc}",
                    completed_at=datetime.now(),
                )

            node_results[node_id] = node_result
            meta_result.node_results[node_id] = node_result
            node_events[node_id].set()

            await self._emit_event(
                "NODE_COMPLETED",
                execution_id=execution_id,
                node_id=node_id,
                status=node_result.status,
                duration_ms=node_result.duration_ms,
            )
            logger.info(
                "MetaDAG[%s] node '%s' → %s  (%.0f ms)",
                execution_id[:8], node_id, node_result.status, node_result.duration_ms,
            )

        await asyncio.gather(
            *[run_node(nid, spec) for nid, spec in self._nodes.items()],
            return_exceptions=True,
        )

        meta_result.completed_at = datetime.now()
        await self._emit_event(
            "META_EXECUTION_COMPLETED",
            execution_id=execution_id,
            successful_nodes=meta_result.successful_nodes,
            failed_nodes=meta_result.failed_nodes,
            skipped_nodes=meta_result.skipped_nodes,
            duration_ms=meta_result.duration_ms,
        )
        return meta_result

    async def _execute_node(
        self,
        execution_id: str,
        node_id: str,
        spec: MetaDAGNodeSpec,
        upstream_outputs: Dict[str, Any],
        group_semaphore: Optional[AdaptiveSemaphore] = None,
    ) -> MetaDAGNodeResult:
        started_at = datetime.now()
        config = spec.config or self.config
        tasks = self._inject_upstream(spec.tasks, upstream_outputs)
        try:
            if spec.node_type == "dag":
                return await self._run_dag_node(
                    node_id, spec, tasks, config, started_at, group_semaphore
                )
            elif spec.node_type == "reconciler":
                return await self._run_reconciler_node(node_id, spec, tasks, config, started_at)
            else:
                raise ValueError(f"Unknown node_type: {spec.node_type!r}")
        except Exception as exc:
            return MetaDAGNodeResult(
                node_id=node_id,
                status="failed",
                error=str(exc),
                started_at=started_at,
                completed_at=datetime.now(),
            )

    async def _run_dag_node(
        self,
        node_id: str,
        spec: MetaDAGNodeSpec,
        tasks: Dict[str, Any],
        config: WaveConfig,
        started_at: datetime,
        group_semaphore: Optional[AdaptiveSemaphore] = None,
    ) -> MetaDAGNodeResult:
        executor = DAGExecutor(config=config)
        dag_result = await executor.execute(
            tasks=tasks,
            dependencies=spec.task_dependencies,
            task_executor=spec.task_executor,
            inject_dep_outputs=spec.inject_dep_outputs,
            specialist_semaphore=group_semaphore,
        )
        task_outputs = {
            tid: r.output
            for tid, r in dag_result.task_results.items()
            if r.status == "success" and r.output is not None
        }
        failed = dag_result.total_failed + dag_result.total_timeout
        status = "success" if failed == 0 else "failed"
        return MetaDAGNodeResult(
            node_id=node_id,
            status=status,
            task_outputs=task_outputs,
            dag_result=dag_result,
            error=f"{failed} task(s) failed" if status == "failed" else None,
            started_at=started_at,
            completed_at=datetime.now(),
        )

    async def _run_reconciler_node(
        self,
        node_id: str,
        spec: MetaDAGNodeSpec,
        tasks: Dict[str, Any],
        config: WaveConfig,
        started_at: datetime,
    ) -> MetaDAGNodeResult:
        reconciler = WaveReconciler(
            task_executor=spec.task_executor,
            config=config,
            inject_dep_outputs=spec.inject_dep_outputs,
        )
        await reconciler.start()
        try:
            await reconciler.update(
                tasks=tasks,
                dependencies=spec.task_dependencies,
                policies=spec.policies,
            )
            completed = await reconciler.wait_until_complete(
                timeout=spec.completion_timeout,
                poll_interval=spec.completion_poll_interval,
            )
        finally:
            await reconciler.stop()

        task_outputs = {
            tid: state.output
            for tid, state in reconciler._state.items()
            if state.status == "success" and state.output is not None
        }
        status = "success" if completed else "timeout"
        return MetaDAGNodeResult(
            node_id=node_id,
            status=status,
            task_outputs=task_outputs,
            error="Reconciler completion timeout" if not completed else None,
            started_at=started_at,
            completed_at=datetime.now(),
        )

    def _inject_upstream(
        self,
        tasks: Dict[str, Any],
        upstream_outputs: Dict[str, Any],
    ) -> Dict[str, Any]:
        if not self._inject_dep_outputs or not upstream_outputs:
            return tasks
        return {
            tid: (
                {**tspec, "_upstream_outputs": upstream_outputs}
                if isinstance(tspec, dict)
                else {"spec": tspec, "_upstream_outputs": upstream_outputs}
            )
            for tid, tspec in tasks.items()
        }

    async def _emit_event(self, event_type: str, **data) -> None:
        if not self.config.emit_events:
            return
        event = {"event_type": event_type, "timestamp": datetime.now().isoformat(), **data}
        for cb in self._event_callbacks:
            try:
                if asyncio.iscoroutinefunction(cb):
                    await cb(event_type, event)
                else:
                    cb(event_type, event)
            except Exception as exc:
                logger.warning("MetaDAG event callback error: %s", exc)
