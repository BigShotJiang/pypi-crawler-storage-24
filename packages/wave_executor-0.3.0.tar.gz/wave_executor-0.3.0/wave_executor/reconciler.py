"""
Wave Reconciler — desired-state reconciliation for long-running task supervision.

Inspired by agentd's reconciliation loop in stereOS:
- Holds desired task state (spec + dependencies)
- Continuously diffs running state against desired state
- Per-task restart policies: ``"no"`` / ``"on-failure"`` / ``"always"``
- Exponential backoff on restarts (base 3 s)
- Hot-update desired state via :meth:`update` without stopping everything
- Dependency-aware: tasks only start once all upstream deps succeed
- Tasks blocked once ``max_restart_attempts`` is exhausted

The key difference from DAGExecutor (one-shot)::

    DAGExecutor:    submit tasks → execute → return results → done

    WaveReconciler: set desired_state → run → diff on each poll cycle
                    → restart failures → update desired_state → diff again
                    → ... (runs until stop())

Use cases:
- Workers that must stay alive and restart on crash
- Hot-swapping task specs mid-run without a full restart
- Watchdog tasks with ALWAYS restart policy
- One-shot multi-stage pipelines with dependency ordering

Usage::

    async def run_job(task_id: str, spec: Any) -> Any:
        ...

    reconciler = WaveReconciler(task_executor=run_job)
    await reconciler.start()

    await reconciler.update(
        tasks={"fetch": fetch_spec, "process": process_spec},
        dependencies={"process": {"fetch"}},
        policies={"fetch": "on-failure", "process": "no"},
    )

    ok = await reconciler.wait_until_complete(timeout=60)
    await reconciler.stop()
"""

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Awaitable, Callable, Dict, List, Optional, Set

from .dag import DAGExecutor
from .config import WaveConfig

logger = logging.getLogger(__name__)

_FAILED_STATUSES: frozenset = frozenset({"failed", "timeout"})
_TERMINAL_STATUSES: frozenset = frozenset({"success", "failed", "timeout", "stopped", "blocked"})


class _NullSemaphore:
    """No-op async context manager — used before start() initialises the real semaphore."""
    async def __aenter__(self):
        return self

    async def __aexit__(self, *_):
        pass


# ============================================================================
# Enums & data classes
# ============================================================================

class RestartPolicy(str, Enum):
    """When to restart a task after it reaches a terminal status."""
    NO = "no"               # Never restart
    ON_FAILURE = "on-failure"   # Restart only on failed / timeout
    ALWAYS = "always"       # Restart after any terminal status (including success)


@dataclass
class ReconcileTaskSpec:
    """Desired state declaration for a single task."""
    task_id: str
    spec: Any
    restart_policy: RestartPolicy = RestartPolicy.ON_FAILURE
    max_restart_attempts: int = 5
    restart_backoff_base: float = 3.0  # seconds


@dataclass
class ReconcileTaskState:
    """Observed running state for a single task."""
    task_id: str
    status: str = "pending"   # pending | running | success | failed | timeout | stopped | blocked
    restart_count: int = 0
    last_started: Optional[datetime] = None
    next_start_after: Optional[datetime] = None
    last_error: Optional[str] = None
    output: Any = None

    @property
    def is_terminal(self) -> bool:
        return self.status in _TERMINAL_STATUSES

    @property
    def is_running(self) -> bool:
        return self.status == "running"


@dataclass
class ReconcileStatus:
    """Point-in-time snapshot of the reconciler's aggregate state."""
    desired_task_count: int
    running_count: int
    success_count: int
    failed_count: int
    pending_count: int
    stopped_count: int
    blocked_count: int
    task_states: Dict[str, str]   # task_id → status
    uptime_s: float
    reconcile_cycle: int


# ============================================================================
# Wave Reconciler
# ============================================================================

class WaveReconciler:
    """
    Continuously reconciles desired task state against observed running state.

    On each poll cycle:

    1. Reap finished asyncio tasks → update observed status
    2. Cancel tasks removed from desired state (stale)
    3. Evaluate restart policy for terminal-but-desired tasks
    4. Start tasks that are pending and whose dependencies have all succeeded

    Args:
        task_executor:      Async callable ``(task_id, task_spec) → result``.
        config:             WaveConfig (controls timeouts, concurrency).
        poll_interval_s:    How often to run the reconcile cycle (default 2 s).
        checkpoint_store:   Optional persistence backend. Must implement
                            ``save_reconciler_state`` / ``load_reconciler_state``
                            (see :class:`InMemoryCheckpointStore` for the interface).
        reconciler_id:      Stable name used for checkpoint persistence.
        inject_dep_outputs: Inject completed dep task outputs into downstream
                            task specs under ``'_dep_outputs'``.
    """

    def __init__(
        self,
        task_executor: Callable[[str, Any], Awaitable[Any]],
        config: Optional[WaveConfig] = None,
        poll_interval_s: float = 2.0,
        checkpoint_store=None,
        reconciler_id: str = "default",
        inject_dep_outputs: bool = False,
    ):
        self.task_executor = task_executor
        self.config = config or WaveConfig()
        self.poll_interval_s = poll_interval_s
        self._checkpoint_store = checkpoint_store
        self._reconciler_id = reconciler_id
        self._inject_dep_outputs = inject_dep_outputs

        self._desired: Dict[str, ReconcileTaskSpec] = {}
        self._dependencies: Dict[str, Set[str]] = {}
        self._state: Dict[str, ReconcileTaskState] = {}
        self._asyncio_tasks: Dict[str, asyncio.Task] = {}
        self._semaphore: Optional[asyncio.Semaphore] = None
        self._lock: asyncio.Lock = asyncio.Lock()
        self._loop_task: Optional[asyncio.Task] = None
        self._started_at: Optional[datetime] = None
        self._reconcile_cycle: int = 0
        self._event_callbacks: List[Callable] = []

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    async def start(self) -> None:
        """Start the background reconciliation loop."""
        if self._loop_task and not self._loop_task.done():
            return
        self._started_at = datetime.now()
        self._semaphore = asyncio.Semaphore(self.config.max_parallel_per_wave)
        self._loop_task = asyncio.create_task(
            self._reconcile_loop(), name="wave-reconciler"
        )
        logger.info(
            "WaveReconciler started (poll_interval=%.1fs max_parallel=%d inject_dep_outputs=%s)",
            self.poll_interval_s,
            self.config.max_parallel_per_wave,
            self._inject_dep_outputs,
        )

        if self._checkpoint_store:
            specs, states, deps = await self._checkpoint_store.load_reconciler_state(
                self._reconciler_id
            )
            for task_id, spec in specs.items():
                if task_id not in self._desired:
                    self._desired[task_id] = spec
                    self._state[task_id] = states.get(
                        task_id, ReconcileTaskState(task_id=task_id)
                    )
            for task_id, dep_set in deps.items():
                self._dependencies.setdefault(task_id, dep_set)
            if specs:
                logger.info(
                    "WaveReconciler[%s] restored %d task(s) from checkpoint",
                    self._reconciler_id, len(specs),
                )

    async def stop(self) -> None:
        """Stop the reconciliation loop and cancel all running tasks."""
        if self._loop_task:
            self._loop_task.cancel()
            try:
                await self._loop_task
            except asyncio.CancelledError:
                pass

        async with self._lock:
            for task_id in list(self._asyncio_tasks):
                await self._cancel_task(task_id)
                state = self._state.get(task_id)
                if state and state.status == "running":
                    state.status = "stopped"
            self._asyncio_tasks.clear()

        logger.info("WaveReconciler stopped after %d cycles", self._reconcile_cycle)

    # ── Desired-state API ─────────────────────────────────────────────────────

    async def update(
        self,
        tasks: Dict[str, Any],
        dependencies: Optional[Dict[str, Any]] = None,
        policies: Optional[Dict[str, str]] = None,
        max_restart_attempts: Optional[Dict[str, int]] = None,
        restart_backoff_base: float = 3.0,
    ) -> None:
        """
        Hot-update desired state.  Safe to call while the reconciler is running.

        - Added tasks are started on the next reconcile cycle.
        - Removed tasks are cancelled and marked ``"stopped"``.
        - Tasks whose spec changed are cancelled and restarted with the new spec
          (``restart_count`` is reset so they get a full quota of attempts).
        - Unchanged tasks continue running undisturbed.

        Args:
            tasks:                ``{task_id: task_spec}``
            dependencies:         ``{task_id: list|set of upstream task_ids}``
            policies:             ``{task_id: "no"|"on-failure"|"always"}``
            max_restart_attempts: ``{task_id: N}``  (default 5)
            restart_backoff_base: base seconds for exponential backoff (default 3.0)
        """
        if dependencies:
            normalized: Dict[str, Set[str]] = {
                tid: set(deps) for tid, deps in dependencies.items()
            }
            DAGExecutor._validate_acyclic(tasks, normalized)

        async with self._lock:
            new_desired: Dict[str, ReconcileTaskSpec] = {}
            for task_id, spec in tasks.items():
                raw_policy = (policies or {}).get(task_id, "on-failure")
                try:
                    policy = RestartPolicy(raw_policy)
                except ValueError:
                    policy = RestartPolicy.ON_FAILURE

                new_desired[task_id] = ReconcileTaskSpec(
                    task_id=task_id,
                    spec=spec,
                    restart_policy=policy,
                    max_restart_attempts=(max_restart_attempts or {}).get(task_id, 5),
                    restart_backoff_base=restart_backoff_base,
                )

            for task_id, new_spec in new_desired.items():
                old_spec = self._desired.get(task_id)
                if old_spec is not None and old_spec.spec != new_spec.spec:
                    await self._cancel_task(task_id)
                    state = self._state.get(task_id)
                    if state:
                        state.status = "pending"
                        state.restart_count = 0
                        state.next_start_after = None
                        state.last_error = None
                    logger.debug("Task '%s' spec changed — queued for restart", task_id)

            removed = set(self._desired) - set(new_desired)
            for task_id in removed:
                await self._cancel_task(task_id)
                state = self._state.get(task_id)
                if state:
                    state.status = "stopped"
                await self._emit_event(
                    "TASK_STOPPED", task_id=task_id, reason="removed_from_desired"
                )

            self._desired = new_desired
            self._dependencies = {
                tid: set(deps)
                for tid, deps in (dependencies or {}).items()
            }

            if self._checkpoint_store:
                for task_id, spec in new_desired.items():
                    state = self._state.get(task_id, ReconcileTaskState(task_id=task_id))
                    dep_set = self._dependencies.get(task_id, set())
                    await self._checkpoint_store.save_reconciler_state(
                        self._reconciler_id, task_id, spec, state, dep_set
                    )

        await self._emit_event("DESIRED_STATE_UPDATED", task_count=len(tasks))

    def on_event(self, callback: Callable) -> None:
        """Register a callback for reconciler lifecycle events."""
        self._event_callbacks.append(callback)

    def get_status(self) -> ReconcileStatus:
        """Return a point-in-time snapshot of the reconciler's aggregate status."""
        statuses = {tid: s.status for tid, s in self._state.items()}
        uptime = (
            (datetime.now() - self._started_at).total_seconds()
            if self._started_at
            else 0.0
        )
        return ReconcileStatus(
            desired_task_count=len(self._desired),
            running_count=sum(1 for s in statuses.values() if s == "running"),
            success_count=sum(1 for s in statuses.values() if s == "success"),
            failed_count=sum(1 for s in statuses.values() if s in _FAILED_STATUSES),
            pending_count=sum(1 for s in statuses.values() if s == "pending"),
            stopped_count=sum(1 for s in statuses.values() if s == "stopped"),
            blocked_count=sum(1 for s in statuses.values() if s == "blocked"),
            task_states=statuses,
            uptime_s=uptime,
            reconcile_cycle=self._reconcile_cycle,
        )

    # ── Reconcile Loop ─────────────────────────────────────────────────────────

    async def _reconcile_loop(self) -> None:
        while True:
            try:
                async with self._lock:
                    await self._reconcile_once()
                self._reconcile_cycle += 1
            except asyncio.CancelledError:
                raise
            except Exception as e:
                logger.error("Reconcile error on cycle %d: %s", self._reconcile_cycle, e)
            await asyncio.sleep(self.poll_interval_s)

    async def _reconcile_once(self) -> None:
        now = datetime.now()

        # 1. Reap finished asyncio tasks
        for task_id in [tid for tid, t in self._asyncio_tasks.items() if t.done()]:
            del self._asyncio_tasks[task_id]

        # 2. Cancel stale tasks (running but no longer desired)
        stale_ids = set(self._asyncio_tasks) - set(self._desired)
        for task_id in stale_ids:
            await self._cancel_task(task_id)
            state = self._state.get(task_id)
            if state:
                state.status = "stopped"
            await self._emit_event("TASK_STOPPED", task_id=task_id, reason="removed_from_desired")

        # 3. Evaluate restart policy for terminal desired tasks
        for task_id in set(self._desired):
            state = self._state.get(task_id)
            if state is None or task_id in self._asyncio_tasks:
                continue
            if not state.is_terminal:
                continue
            spec = self._desired[task_id]
            if self._should_restart(state, spec, now):
                state.status = "pending"
                state.last_error = None
                logger.debug(
                    "Task '%s' queued for restart (attempt %d/%d, policy=%s)",
                    task_id, state.restart_count, spec.max_restart_attempts, spec.restart_policy,
                )

        # 4. Start pending tasks whose dependencies are satisfied
        for task_id in set(self._desired):
            state = self._state.get(task_id)
            if state is None:
                self._state[task_id] = ReconcileTaskState(task_id=task_id, status="pending")
                state = self._state[task_id]

            if state.status != "pending":
                continue
            if task_id in self._asyncio_tasks:
                continue
            if state.next_start_after and now < state.next_start_after:
                continue

            deps = self._dependencies.get(task_id, set())
            if not self._deps_satisfied(deps):
                continue

            await self._start_task(task_id)

    # ── Task lifecycle ────────────────────────────────────────────────────────

    async def _start_task(self, task_id: str) -> None:
        spec = self._desired.get(task_id)
        if not spec:
            return

        state = self._state.setdefault(task_id, ReconcileTaskState(task_id=task_id))
        state.status = "running"
        state.last_started = datetime.now()
        state.restart_count += 1
        state.next_start_after = None

        task_spec = spec.spec
        if self._inject_dep_outputs:
            deps = self._dependencies.get(task_id, set())
            dep_outputs = {
                dep_id: self._state[dep_id].output
                for dep_id in deps
                if dep_id in self._state and self._state[dep_id].output is not None
            }
            if dep_outputs:
                if isinstance(task_spec, dict):
                    task_spec = {**task_spec, "_dep_outputs": dep_outputs}
                else:
                    task_spec = {"spec": task_spec, "_dep_outputs": dep_outputs}

        asyncio_task = asyncio.create_task(
            self._run_task_wrapper(task_id, task_spec),
            name=f"reconcile-{task_id}",
        )
        self._asyncio_tasks[task_id] = asyncio_task
        await self._emit_event("TASK_STARTED", task_id=task_id, restart_count=state.restart_count)
        logger.debug("Started task '%s' (run #%d)", task_id, state.restart_count)

    async def _cancel_task(self, task_id: str) -> None:
        asyncio_task = self._asyncio_tasks.pop(task_id, None)
        if asyncio_task and not asyncio_task.done():
            asyncio_task.cancel()
            try:
                await asyncio_task
            except (asyncio.CancelledError, Exception):
                pass

    async def _run_task_wrapper(self, task_id: str, task_spec: Any) -> None:
        state = self._state[task_id]
        try:
            async with (self._semaphore if self._semaphore is not None else _NullSemaphore()):
                output = await asyncio.wait_for(
                    self.task_executor(task_id, task_spec),
                    timeout=self.config.default_task_timeout,
                )
            state.status = "success"
            state.output = output
            state.last_error = None
            if self._checkpoint_store:
                await self._checkpoint_store.save_reconciler_state(
                    self._reconciler_id, task_id,
                    self._desired.get(task_id), state,
                    self._dependencies.get(task_id, set()),
                )
            await self._emit_event("TASK_COMPLETED", task_id=task_id, status="success")
            logger.debug("Task '%s' succeeded", task_id)

        except asyncio.TimeoutError:
            state.status = "timeout"
            state.last_error = f"Exceeded {self.config.default_task_timeout}s timeout"
            if self._checkpoint_store:
                await self._checkpoint_store.save_reconciler_state(
                    self._reconciler_id, task_id,
                    self._desired.get(task_id), state,
                    self._dependencies.get(task_id, set()),
                )
            await self._emit_event("TASK_FAILED", task_id=task_id, status="timeout", error=state.last_error)
            logger.warning("Task '%s' timed out", task_id)

        except asyncio.CancelledError:
            state.status = "stopped"
            raise

        except Exception as e:
            state.status = "failed"
            state.last_error = str(e)
            if self._checkpoint_store:
                await self._checkpoint_store.save_reconciler_state(
                    self._reconciler_id, task_id,
                    self._desired.get(task_id), state,
                    self._dependencies.get(task_id, set()),
                )
            await self._emit_event("TASK_FAILED", task_id=task_id, status="failed", error=str(e))
            logger.warning("Task '%s' failed: %s", task_id, e)

    # ── Helpers ───────────────────────────────────────────────────────────────

    async def wait_until_complete(
        self,
        timeout: float = 300.0,
        poll_interval: float = 0.1,
    ) -> bool:
        """
        Block until all desired tasks (except ALWAYS-restart) reach a terminal state.

        Args:
            timeout:       Maximum seconds to wait (default 5 min).
            poll_interval: How often to re-check (seconds).

        Returns:
            ``True`` if all non-ALWAYS tasks are terminal, ``False`` on timeout.
        """
        loop = asyncio.get_running_loop()
        deadline = loop.time() + timeout

        while loop.time() < deadline:
            if self._count_non_terminal() == 0:
                return True
            await asyncio.sleep(poll_interval)

        return self._count_non_terminal() == 0

    def _count_non_terminal(self) -> int:
        count = 0
        for task_id, spec in self._desired.items():
            if spec.restart_policy == RestartPolicy.ALWAYS:
                continue
            state = self._state.get(task_id)
            if state is None or not state.is_terminal:
                count += 1
        return count

    def _deps_satisfied(self, deps: Set[str]) -> bool:
        for dep_id in deps:
            dep_state = self._state.get(dep_id)
            if dep_state is None or dep_state.status != "success":
                return False
        return True

    def _should_restart(
        self,
        state: ReconcileTaskState,
        spec: ReconcileTaskSpec,
        now: datetime,
    ) -> bool:
        policy = spec.restart_policy

        if policy == RestartPolicy.NO:
            return False
        if policy == RestartPolicy.ON_FAILURE and state.status not in _FAILED_STATUSES:
            return False
        if state.restart_count >= spec.max_restart_attempts:
            if state.status != "blocked":
                state.status = "blocked"
                logger.warning(
                    "Task '%s' exceeded max_restart_attempts (%d), marked blocked",
                    state.task_id, spec.max_restart_attempts,
                )
            return False

        if state.restart_count > 0:
            backoff_s = spec.restart_backoff_base * (2.0 ** (state.restart_count - 1))
            earliest = (state.last_started or now) + timedelta(seconds=backoff_s)
            if now < earliest:
                state.next_start_after = earliest
                return False

        state.next_start_after = None
        return True

    async def _emit_event(self, event_type: str, **data) -> None:
        event = {"event_type": event_type, "timestamp": datetime.now().isoformat(), **data}
        for cb in self._event_callbacks:
            try:
                if asyncio.iscoroutinefunction(cb):
                    await cb(event_type, event)
                else:
                    cb(event_type, event)
            except Exception as e:
                logger.warning("Reconciler event callback error: %s", e)
