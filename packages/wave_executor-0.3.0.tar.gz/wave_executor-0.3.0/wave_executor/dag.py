"""
DAG Executor — true dependency-aware task scheduler.

Unlike level/wave-based executors, DAGExecutor starts each task the moment
its specific dependencies complete — no inter-level barriers.

The problem with level-based waves::

    A (10s) ─┐
              ├─→ C (1s)
    B  (1s) ─┘
    D  (1s) ─→ E (1s)   (fully independent chain)

    Level-based: depth-0 = {A, B, D}, depth-1 = {C, E}
    → E must wait for A (10 s) before it can start, even though E only needs D.

    DAGExecutor:
    t=0:  A, B, D all start
    t=1:  D done → E starts immediately
    t=2:  E done  ← 9 seconds earlier
    t=10: A done → C starts
    t=11: C done

Key features:
- ``asyncio.Event`` per task — zero-overhead dependency signalling
- ``AdaptiveSemaphore`` — AIMD-controlled concurrency window
- Dep-failure propagation: downstream tasks skipped when a dep fails/times out
- Optional dep-output injection into task_spec under ``'_dep_outputs'``
- Cycle detection (Kahn's algorithm) before execution starts
- Exponential-backoff retry with per-task timeout
"""

import asyncio
import logging
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Awaitable, Callable, Dict, List, Optional, Set

from .config import AggregationStrategy, TaskResult, WaveConfig
from .exceptions import WaveCircularDependencyError

logger = logging.getLogger(__name__)

_FAILED_STATUSES = frozenset({"failed", "timeout", "skipped"})


# ============================================================================
# Circuit Breaker
# ============================================================================

class CircuitBreakerOpenError(Exception):
    """Raised when a circuit breaker is open and the call is fast-failed."""


class CircuitState(Enum):
    CLOSED = "closed"        # Normal — all requests pass through
    OPEN = "open"            # Tripped — requests are fast-failed
    HALF_OPEN = "half_open"  # Recovery probe — one request allowed through


class CircuitBreaker:
    """
    Per-specialist circuit breaker with CLOSED → OPEN → HALF_OPEN → CLOSED lifecycle.

    The circuit_key is typically a specialist name or task category so that
    multiple tasks sharing the same specialist share one breaker.

    Thread safety: asyncio single-threaded; no locks needed.
    """

    __slots__ = (
        "key", "failure_threshold", "success_threshold", "recovery_timeout",
        "_state", "_failure_count", "_success_count", "_last_failure_time",
    )

    def __init__(
        self,
        key: str,
        failure_threshold: int,
        success_threshold: int,
        recovery_timeout: float,
    ) -> None:
        self.key = key
        self.failure_threshold = failure_threshold
        self.success_threshold = success_threshold
        self.recovery_timeout = recovery_timeout
        self._state = CircuitState.CLOSED
        self._failure_count: int = 0
        self._success_count: int = 0
        self._last_failure_time: float = 0.0

    @property
    def state(self) -> CircuitState:
        return self._state

    def allow_request(self) -> bool:
        """Return True if the request should proceed; False to fast-fail."""
        if self._state == CircuitState.CLOSED:
            return True
        if self._state == CircuitState.OPEN:
            if time.time() - self._last_failure_time >= self.recovery_timeout:
                self._state = CircuitState.HALF_OPEN
                self._success_count = 0
                logger.info("Circuit '%s': OPEN → HALF_OPEN (probing)", self.key)
                return True
            return False
        # HALF_OPEN — allow the probe through
        return True

    def record_success(self) -> None:
        if self._state == CircuitState.HALF_OPEN:
            self._success_count += 1
            if self._success_count >= self.success_threshold:
                self._state = CircuitState.CLOSED
                self._failure_count = 0
                logger.info("Circuit '%s': HALF_OPEN → CLOSED (recovered)", self.key)
        else:
            self._failure_count = 0

    def record_failure(self) -> None:
        self._failure_count += 1
        self._last_failure_time = time.time()
        if self._state == CircuitState.HALF_OPEN:
            self._state = CircuitState.OPEN
            logger.warning("Circuit '%s': HALF_OPEN → OPEN (probe failed)", self.key)
        elif self._failure_count >= self.failure_threshold:
            self._state = CircuitState.OPEN
            logger.warning(
                "Circuit '%s': CLOSED → OPEN (%d consecutive failures)",
                self.key, self._failure_count,
            )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "key": self.key,
            "state": self._state.value,
            "failure_count": self._failure_count,
            "success_count": self._success_count,
            "last_failure_age_s": round(time.time() - self._last_failure_time, 1)
            if self._last_failure_time else None,
        }


# ============================================================================
# AdaptiveSemaphore — AIMD-controlled concurrency window
# ============================================================================

class AdaptiveSemaphore:
    """
    Asyncio semaphore whose concurrency limit self-adjusts via AIMD.

    On every release:
    - If waiting > ``saturation_threshold``  → shrink limit by 25% (multiplicative decrease)
    - If waiting == 0 and active == limit    → grow limit by 1   (additive increase)

    The limit is bounded to ``[min_val, max_val]``.  When ``adaptive=False`` the
    semaphore behaves exactly like ``asyncio.Semaphore(initial)``.
    """

    __slots__ = (
        "_limit", "_min", "_max", "_threshold",
        "_active", "_waiting", "_adaptive", "_cond",
    )

    def __init__(
        self,
        initial: int,
        min_val: int = 2,
        max_val: int = 10_000,
        saturation_threshold: int = 20,
        adaptive: bool = True,
    ) -> None:
        self._limit = max(min_val, min(initial, max_val))
        self._min = min_val
        self._max = max_val
        self._threshold = saturation_threshold
        self._adaptive = adaptive
        self._active: int = 0
        self._waiting: int = 0
        self._cond: Optional[asyncio.Condition] = None

    def _ensure_cond(self) -> asyncio.Condition:
        if self._cond is None:
            self._cond = asyncio.Condition()
        return self._cond

    @property
    def limit(self) -> int:
        return self._limit

    @property
    def active(self) -> int:
        return self._active

    @property
    def waiting(self) -> int:
        return self._waiting

    async def acquire(self) -> None:
        cond = self._ensure_cond()
        async with cond:
            self._waiting += 1
            while self._active >= self._limit:
                await cond.wait()
            self._waiting -= 1
            self._active += 1

    async def release(self) -> None:
        cond = self._ensure_cond()
        async with cond:
            self._active -= 1
            if self._adaptive:
                self._adapt()
            cond.notify()

    def _adapt(self) -> None:
        """AIMD resize — called inside the condition lock on every release."""
        if self._waiting > self._threshold:
            new = max(self._min, int(self._limit * 0.75))
            if new != self._limit:
                logger.debug(
                    "AdaptiveSemaphore: window %d→%d (waiting=%d)",
                    self._limit, new, self._waiting,
                )
                self._limit = new
        elif self._waiting == 0 and self._active == self._limit - 1:
            new = min(self._max, self._limit + 1)
            if new != self._limit:
                self._limit = new

    async def __aenter__(self) -> "AdaptiveSemaphore":
        await self.acquire()
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.release()


# ============================================================================
# Result type
# ============================================================================

@dataclass
class DAGExecutionResult:
    """
    Result of a full DAG execution.

    Flat structure (no waves) — per-task results keyed by task_id.
    """

    execution_id: str
    task_results: Dict[str, TaskResult] = field(default_factory=dict)
    started_at: datetime = field(default_factory=datetime.now)
    completed_at: Optional[datetime] = None

    @property
    def total_tasks(self) -> int:
        return len(self.task_results)

    @property
    def total_successful(self) -> int:
        return sum(1 for r in self.task_results.values() if r.status == "success")

    @property
    def total_failed(self) -> int:
        return sum(1 for r in self.task_results.values() if r.status == "failed")

    @property
    def total_skipped(self) -> int:
        return sum(1 for r in self.task_results.values() if r.status == "skipped")

    @property
    def total_timeout(self) -> int:
        return sum(1 for r in self.task_results.values() if r.status == "timeout")

    @property
    def overall_success_rate(self) -> float:
        """Success rate excluding skipped tasks."""
        runnable = self.total_tasks - self.total_skipped
        if runnable == 0:
            return 0.0
        return self.total_successful / runnable

    @property
    def duration_ms(self) -> float:
        if not self.completed_at:
            return 0.0
        return (self.completed_at - self.started_at).total_seconds() * 1000

    def get_critical_path(self, dependencies: Dict[str, Set[str]]) -> List[str]:
        """
        Compute the critical path — the longest chain by actual wall-clock duration.

        Returns ordered list of task_ids from root to leaf on the critical path.
        """
        if not self.task_results:
            return []

        memo: Dict[str, float] = {}
        predecessor: Dict[str, Optional[str]] = {}

        def chain_duration(task_id: str) -> float:
            if task_id in memo:
                return memo[task_id]
            my_ms = self.task_results[task_id].duration_ms
            deps = dependencies.get(task_id, set()) & self.task_results.keys()
            if not deps:
                memo[task_id] = my_ms
                predecessor[task_id] = None
                return my_ms
            best_dep = max(deps, key=chain_duration)
            memo[task_id] = my_ms + chain_duration(best_dep)
            predecessor[task_id] = best_dep
            return memo[task_id]

        for task_id in self.task_results:
            chain_duration(task_id)

        end_task = max(self.task_results.keys(), key=lambda t: memo.get(t, 0))
        path: List[str] = []
        current: Optional[str] = end_task
        while current is not None:
            path.append(current)
            current = predecessor.get(current)
        return list(reversed(path))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "execution_id": self.execution_id,
            "total_tasks": self.total_tasks,
            "total_successful": self.total_successful,
            "total_failed": self.total_failed,
            "total_skipped": self.total_skipped,
            "total_timeout": self.total_timeout,
            "overall_success_rate": round(self.overall_success_rate, 3),
            "duration_ms": round(self.duration_ms, 2),
            "started_at": self.started_at.isoformat(),
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
        }


# ============================================================================
# Escalation Report
# ============================================================================

@dataclass
class EscalationReport:
    """
    Structured escalation report emitted after a task exhausts all retries.

    Stored under ``task_result.output["escalation"]`` so callers can inspect
    failure history and route to a human operator or fallback specialist.
    """
    task_id: str
    execution_id: str
    attempt_count: int
    failure_history: List[str]   # error message from each attempt
    root_cause: str = ""         # best-guess heuristic
    resolution_options: List[str] = field(default_factory=list)
    circuit_state: str = "unknown"
    escalated_at: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "task_id": self.task_id,
            "execution_id": self.execution_id,
            "attempt_count": self.attempt_count,
            "failure_history": self.failure_history,
            "root_cause": self.root_cause,
            "resolution_options": self.resolution_options,
            "circuit_state": self.circuit_state,
            "escalated_at": self.escalated_at.isoformat(),
        }


# ============================================================================
# DAG Executor
# ============================================================================

class DAGExecutor:
    """
    Executes tasks with true dependency-aware scheduling.

    Each task starts as soon as ALL of its specific dependencies complete,
    regardless of other tasks at the same dependency depth.

    Usage::

        async def my_fn(task_id: str, spec: Any) -> Any:
            ...

        executor = DAGExecutor(config=WaveConfig(max_parallel_per_wave=10))
        result = await executor.execute(
            tasks={"a": spec_a, "b": spec_b, "c": spec_c},
            dependencies={"c": {"a", "b"}},   # c waits for a and b
            task_executor=my_fn,
        )
        print(result.total_successful)
    """

    def __init__(self, config: Optional[WaveConfig] = None):
        self.config = config or WaveConfig()
        self._event_callbacks: List[Callable] = []
        self._circuit_breakers: Dict[str, CircuitBreaker] = {}

    def _get_circuit(self, key: str, config: WaveConfig) -> CircuitBreaker:
        if key not in self._circuit_breakers:
            self._circuit_breakers[key] = CircuitBreaker(
                key=key,
                failure_threshold=config.circuit_failure_threshold,
                success_threshold=config.circuit_success_threshold,
                recovery_timeout=config.circuit_recovery_timeout,
            )
        return self._circuit_breakers[key]

    def _check_circuit_breaker_state(
        self, circuit_key: str, config: WaveConfig
    ) -> Optional[str]:
        """
        Pre-entry circuit breaker validation for retry attempts.
        Returns an error string to fast-fail with, or None to allow the call through.

        Two fast-fail conditions:

        - ``HALF_OPEN``: a probe is already in flight from the first attempt;
          subsequent retries must not pile on as additional probes, since that
          defeats single-probe recovery semantics.
        - ``OPEN`` (timeout not elapsed): circuit still blocking; retrying wastes
          cycles and delays exponential backoff on the upstream caller.

        Called at the top of every retry iteration (``attempt > 0``) **before**
        the executor invocation and **before** any backoff sleep.
        """
        cb = self._get_circuit(circuit_key, config)
        state = cb.state
        if state == CircuitState.HALF_OPEN:
            return (
                f"circuit HALF_OPEN for '{circuit_key}' — probe already in flight; "
                f"aborting retry to preserve single-probe recovery semantics"
            )
        if not cb.allow_request():
            # OPEN and recovery timeout not yet elapsed
            return (
                f"circuit OPEN for '{circuit_key}' — recovery timeout not elapsed; "
                f"aborting retry"
            )
        return None

    def circuit_breaker_states(self) -> Dict[str, Any]:
        """Return current state of all circuit breakers (for observability)."""
        return {k: v.to_dict() for k, v in self._circuit_breakers.items()}

    def on_event(self, callback: Callable[[str, Dict[str, Any]], Awaitable[None]]) -> None:
        """Register callback for execution events."""
        self._event_callbacks.append(callback)

    async def _emit_event(
        self, event_type: str, execution_id: str, task_id: Optional[str] = None, **data
    ) -> None:
        if not self.config.emit_events:
            return
        event = {
            "event_type": event_type,
            "execution_id": execution_id,
            "task_id": task_id,
            "timestamp": datetime.now().isoformat(),
            **data,
        }
        for cb in self._event_callbacks:
            try:
                await cb(event_type, event)
            except Exception as e:
                logger.warning("Event callback error: %s", e)

    async def execute(
        self,
        tasks: Dict[str, Any],
        dependencies: Dict[str, Set[str]],
        task_executor: Callable[[str, Any], Awaitable[Any]],
        config: Optional[WaveConfig] = None,
        inject_dep_outputs: bool = False,
        specialist_semaphore: Optional["AdaptiveSemaphore"] = None,
    ) -> DAGExecutionResult:
        """
        Execute tasks following their dependency graph.

        Args:
            tasks:               Mapping of task_id → task_spec.
            dependencies:        Mapping of task_id → set of upstream task_ids.
                                 Tasks not listed are treated as having no deps.
            task_executor:       Async callable ``(task_id, task_spec) → result``.
            config:              Override WaveConfig for this execution.
            inject_dep_outputs:  When True, inject completed dep results into task_spec
                                 under key ``'_dep_outputs'`` = ``{dep_id: output, ...}``.
            specialist_semaphore: Optional pre-built AdaptiveSemaphore that caps
                                 concurrency for a specific worker category.

        Returns:
            :class:`DAGExecutionResult` with per-task results and aggregate metrics.

        Raises:
            :class:`WaveCircularDependencyError`: If the dependency graph has a cycle.
            ValueError: If a dependency references an unknown task_id.
        """
        config = config or self.config
        execution_id = str(uuid.uuid4())

        normalized_deps: Dict[str, Set[str]] = {
            task_id: set(dependencies.get(task_id, set()))
            for task_id in tasks
        }

        self._validate_acyclic(tasks, normalized_deps)

        dag_result = DAGExecutionResult(execution_id=execution_id)
        await self._emit_event("EXECUTION_STARTED", execution_id, total_tasks=len(tasks))

        task_events: Dict[str, asyncio.Event] = {
            task_id: asyncio.Event() for task_id in tasks
        }
        task_results: Dict[str, TaskResult] = {}

        semaphore = AdaptiveSemaphore(
            initial=config.max_parallel_per_wave,
            min_val=config.min_parallel,
            max_val=config.max_parallel_per_wave,
            saturation_threshold=config.saturation_threshold,
            adaptive=config.adaptive_batch_window,
        )

        async def run_task(task_id: str, task_spec: Any) -> None:
            deps = normalized_deps.get(task_id, set())
            task_result: TaskResult

            try:
                for dep_id in deps:
                    await task_events[dep_id].wait()

                failed_deps = [
                    dep_id for dep_id in deps
                    if task_results.get(dep_id, TaskResult(
                        task_id=dep_id, wave_id="dag", status="unknown"
                    )).status in _FAILED_STATUSES
                ]

                if failed_deps:
                    task_result = TaskResult(
                        task_id=task_id,
                        wave_id="dag",
                        status="skipped",
                        error=f"Skipped — upstream deps failed: {', '.join(sorted(failed_deps))}",
                        completed_at=datetime.now(),
                    )
                    task_results[task_id] = task_result
                    dag_result.task_results[task_id] = task_result
                    await self._emit_event(
                        "TASK_SKIPPED", execution_id,
                        task_id=task_id, failed_deps=failed_deps,
                    )
                    return

                effective_spec = task_spec
                if inject_dep_outputs and deps:
                    dep_outputs = {
                        dep_id: task_results[dep_id].output
                        for dep_id in deps
                        if task_results.get(dep_id) is not None
                        and task_results[dep_id].output is not None
                    }
                    if dep_outputs:
                        if isinstance(effective_spec, dict):
                            effective_spec = {**effective_spec, "_dep_outputs": dep_outputs}
                        else:
                            effective_spec = {"spec": effective_spec, "_dep_outputs": dep_outputs}

                if specialist_semaphore is not None:
                    async with specialist_semaphore:
                        async with semaphore:
                            task_result = await self._execute_with_retry(
                                execution_id, task_id, effective_spec, task_executor, config
                            )
                else:
                    async with semaphore:
                        task_result = await self._execute_with_retry(
                            execution_id, task_id, effective_spec, task_executor, config
                        )

                task_results[task_id] = task_result
                dag_result.task_results[task_id] = task_result

            except asyncio.CancelledError:
                task_result = TaskResult(
                    task_id=task_id,
                    wave_id="dag",
                    status="timeout",
                    error="Task cancelled (execution timeout)",
                    completed_at=datetime.now(),
                )
                task_results[task_id] = task_result
                dag_result.task_results[task_id] = task_result
                raise

            except Exception as e:
                logger.exception("Unexpected error in DAG task '%s': %s", task_id, e)
                task_result = TaskResult(
                    task_id=task_id,
                    wave_id="dag",
                    status="failed",
                    error=f"Internal scheduler error: {e}",
                    completed_at=datetime.now(),
                )
                task_results[task_id] = task_result
                dag_result.task_results[task_id] = task_result

            finally:
                task_events[task_id].set()

        try:
            await asyncio.wait_for(
                asyncio.gather(
                    *[run_task(task_id, spec) for task_id, spec in tasks.items()],
                    return_exceptions=True,
                ),
                timeout=config.total_execution_timeout,
            )
        except asyncio.TimeoutError:
            logger.error(
                "DAG execution '%s' exceeded total timeout %ss",
                execution_id, config.total_execution_timeout,
            )
            for task_id in tasks:
                if task_id not in dag_result.task_results:
                    dag_result.task_results[task_id] = TaskResult(
                        task_id=task_id,
                        wave_id="dag",
                        status="timeout",
                        error=f"Execution exceeded total timeout {config.total_execution_timeout}s",
                        completed_at=datetime.now(),
                    )
        finally:
            dag_result.completed_at = datetime.now()
            await self._emit_event(
                "EXECUTION_COMPLETED",
                execution_id,
                total_tasks=dag_result.total_tasks,
                total_successful=dag_result.total_successful,
                total_failed=dag_result.total_failed,
                total_skipped=dag_result.total_skipped,
                duration_ms=dag_result.duration_ms,
            )

        return dag_result

    def _log_task_result(
        self,
        task_id: str,
        task_spec: Any,
        status: str,
        latency_ms: float,
        attempt: int,
    ) -> None:
        """Emit a structured log line for specialist health tracking."""
        specialist_name = (
            task_spec.get("specialist_name") or task_spec.get("circuit_key") or task_id
            if isinstance(task_spec, dict) else task_id
        )
        tool_name = (
            task_spec.get("tool_name") or task_id
            if isinstance(task_spec, dict) else task_id
        )
        logger.info(
            "dag_task_result specialist=%s tool=%s latency_ms=%.1f status=%s attempt=%d ts=%s",
            specialist_name,
            tool_name,
            latency_ms,
            status,
            attempt,
            datetime.now().isoformat(),
            extra={
                "dag_metric": True,
                "specialist_name": specialist_name,
                "tool_name": tool_name,
                "latency_ms": round(latency_ms, 1),
                "status": status,
                "attempt": attempt,
                "timestamp": datetime.now().isoformat(),
            },
        )

    async def _execute_with_retry(
        self,
        execution_id: str,
        task_id: str,
        task_spec: Any,
        task_executor: Callable[[str, Any], Awaitable[Any]],
        config: WaveConfig,
    ) -> TaskResult:
        """Execute a single task with timeout, exponential-backoff retry, and circuit breaker."""
        task_result = TaskResult(
            task_id=task_id,
            wave_id="dag",
            status="pending",
            started_at=datetime.now(),
        )
        await self._emit_event("TASK_STARTED", execution_id, task_id=task_id)

        # Resolve circuit key: task_spec may advertise a shared specialist key
        circuit_key = (
            task_spec.get("circuit_key", task_id)
            if isinstance(task_spec, dict) else task_id
        )

        # Circuit breaker fast-fail — skip the retry loop entirely when open
        if config.circuit_breaker_enabled:
            circuit = self._get_circuit(circuit_key, config)
            if not circuit.allow_request():
                task_result.status = "failed"
                task_result.error = (
                    f"Circuit breaker open for '{circuit_key}' "
                    f"(will probe after {config.circuit_recovery_timeout}s)"
                )
                task_result.completed_at = datetime.now()
                await self._emit_event(
                    "TASK_FAILED", execution_id,
                    task_id=task_id, error=task_result.error,
                )
                return task_result

        failure_history: List[str] = []

        for attempt in range(config.max_retries + 1):
            # Pre-entry state validation at the top of every retry iteration.
            # Called BEFORE the executor invocation and BEFORE any backoff sleep
            # so that HALF_OPEN probes are never duplicated and OPEN circuits
            # don't waste retry budget.
            if config.circuit_breaker_enabled and attempt > 0:
                fast_fail_reason = self._check_circuit_breaker_state(circuit_key, config)
                if fast_fail_reason is not None:
                    state_label = self._get_circuit(circuit_key, config).state.value
                    task_result.status = "failed"
                    task_result.error = (
                        f"Circuit breaker {state_label} for '{circuit_key}' at retry {attempt} "
                        f"— aborting remaining {config.max_retries - attempt + 1} retries"
                    )
                    task_result.completed_at = datetime.now()
                    logger.warning(
                        "DAG task '%s': circuit %s at retry %d, fast-failing (%s)",
                        task_id, state_label.upper(), attempt, fast_fail_reason,
                    )
                    self._log_task_result(task_id, task_spec, "failed", task_result.duration_ms or 0.0, attempt)
                    await self._emit_event(
                        "TASK_FAILED", execution_id,
                        task_id=task_id, error=task_result.error,
                    )
                    break

            t0 = time.time()
            try:
                output = await asyncio.wait_for(
                    task_executor(task_id, task_spec),
                    timeout=config.default_task_timeout,
                )
                task_result.output = output
                task_result.status = "success"
                task_result.duration_ms = (time.time() - t0) * 1000
                task_result.retry_count = attempt
                task_result.completed_at = datetime.now()
                if config.circuit_breaker_enabled:
                    self._get_circuit(circuit_key, config).record_success()
                self._log_task_result(task_id, task_spec, "success", task_result.duration_ms, attempt)
                await self._emit_event(
                    "TASK_COMPLETED", execution_id,
                    task_id=task_id, status="success",
                    duration_ms=task_result.duration_ms,
                )
                break

            except asyncio.TimeoutError:
                _timeout_msg = f"Timeout after {config.default_task_timeout}s"
                failure_history.append(_timeout_msg)
                task_result.status = "timeout"
                task_result.error = f"Task exceeded {config.default_task_timeout}s timeout"
                task_result.duration_ms = (time.time() - t0) * 1000
                task_result.retry_count = attempt
                task_result.completed_at = datetime.now()
                logger.warning(
                    "DAG task '%s' timed out (attempt %d/%d)",
                    task_id, attempt + 1, config.max_retries + 1,
                )
                self._log_task_result(task_id, task_spec, "timeout", task_result.duration_ms, attempt)
                if config.circuit_breaker_enabled:
                    self._get_circuit(circuit_key, config).record_failure()
                escalation = EscalationReport(
                    task_id=task_id,
                    execution_id=execution_id,
                    attempt_count=attempt + 1,
                    failure_history=list(failure_history),
                    root_cause=(
                        f"Task exceeded {config.default_task_timeout}s timeout "
                        f"— may need timeout increase or task decomposition"
                    ),
                    resolution_options=[
                        "Retry with corrected task spec",
                        "Decompose into smaller subtasks",
                        "Reassign to a different executor",
                        "Defer and investigate root cause",
                    ],
                    circuit_state=(
                        self._get_circuit(circuit_key, config).state.value
                        if config.circuit_breaker_enabled else "disabled"
                    ),
                )
                task_result.output = {"escalation": escalation.to_dict()}
                logger.error(
                    "DAG task '%s' ESCALATED after %d attempt(s). Root cause: %s",
                    task_id, escalation.attempt_count, escalation.root_cause,
                )
                await self._emit_event(
                    "TASK_ESCALATED", execution_id,
                    task_id=task_id,
                    escalation=escalation.to_dict(),
                )
                break  # Timeouts are not retried

            except Exception as e:
                failure_history.append(str(e))
                task_result.error = str(e)
                task_result.duration_ms = (time.time() - t0) * 1000
                task_result.retry_count = attempt

                circuit_tripped = False
                if config.circuit_breaker_enabled:
                    cb = self._get_circuit(circuit_key, config)
                    cb.record_failure()
                    circuit_tripped = cb.state == CircuitState.OPEN

                if attempt < config.max_retries and not circuit_tripped:
                    backoff = min(config.retry_backoff_factor ** attempt, 32.0)
                    logger.warning(
                        "DAG task '%s' failed (attempt %d/%d), retrying in %.1fs: %s",
                        task_id, attempt + 1, config.max_retries + 1, backoff, e,
                    )
                    await asyncio.sleep(backoff)
                else:
                    task_result.status = "failed"
                    task_result.completed_at = datetime.now()
                    if circuit_tripped:
                        task_result.error = (
                            f"Circuit breaker opened for '{circuit_key}' after repeated failures "
                            f"— aborting retries (will probe after {config.circuit_recovery_timeout}s)"
                        )
                        logger.warning(
                            "DAG task '%s': circuit OPEN for '%s', aborting retries",
                            task_id, circuit_key,
                        )
                    else:
                        logger.error(
                            "DAG task '%s' failed after %d attempts: %s",
                            task_id, config.max_retries + 1, e,
                        )
                    self._log_task_result(task_id, task_spec, "failed", task_result.duration_ms, attempt)
                    await self._emit_event(
                        "TASK_FAILED", execution_id,
                        task_id=task_id, error=task_result.error or str(e),
                    )
                    # Determine root cause heuristic
                    if (
                        len(failure_history) > 1
                        and all(failure_history[0][:50] == f[:50] for f in failure_history)
                    ):
                        root_cause = (
                            "Consistent failure pattern — likely a code bug or bad input spec"
                        )
                    elif circuit_tripped:
                        root_cause = (
                            f"Circuit breaker opened for '{circuit_key}' "
                            f"— downstream service unavailable"
                        )
                    else:
                        root_cause = failure_history[-1] if failure_history else "Unknown"

                    escalation = EscalationReport(
                        task_id=task_id,
                        execution_id=execution_id,
                        attempt_count=config.max_retries + 1,
                        failure_history=list(failure_history),
                        root_cause=root_cause,
                        resolution_options=[
                            "Retry with corrected task spec",
                            "Decompose into smaller subtasks",
                            "Reassign to a different executor",
                            "Defer and investigate root cause",
                        ],
                        circuit_state=(
                            self._get_circuit(circuit_key, config).state.value
                            if config.circuit_breaker_enabled else "disabled"
                        ),
                    )
                    task_result.output = {"escalation": escalation.to_dict()}
                    logger.error(
                        "DAG task '%s' ESCALATED after %d attempts. Root cause: %s",
                        task_id, escalation.attempt_count, escalation.root_cause,
                    )
                    await self._emit_event(
                        "TASK_ESCALATED", execution_id,
                        task_id=task_id,
                        escalation=escalation.to_dict(),
                    )

        return task_result

    @staticmethod
    def _validate_acyclic(
        tasks: Dict[str, Any], dependencies: Dict[str, Set[str]]
    ) -> None:
        """
        Kahn's algorithm cycle detection.

        Raises:
            ValueError: If a dep references a task_id not in ``tasks``.
            :class:`WaveCircularDependencyError`: If the dependency graph has a cycle.
        """
        for task_id, deps in dependencies.items():
            for dep in deps:
                if dep not in tasks:
                    raise ValueError(
                        f"Task '{task_id}' depends on '{dep}', "
                        f"which is not defined in tasks"
                    )

        in_degree: Dict[str, int] = {task: 0 for task in tasks}
        dependents: Dict[str, List[str]] = {task: [] for task in tasks}

        for task_id, deps in dependencies.items():
            in_degree[task_id] = len(deps)
            for dep in deps:
                dependents[dep].append(task_id)

        queue = [t for t, d in in_degree.items() if d == 0]
        visited = 0

        while queue:
            node = queue.pop()
            visited += 1
            for dependent in dependents.get(node, []):
                in_degree[dependent] -= 1
                if in_degree[dependent] == 0:
                    queue.append(dependent)

        if visited != len(tasks):
            cycle_members = {t for t, d in in_degree.items() if d > 0}
            raise WaveCircularDependencyError(cycle_members=cycle_members)
