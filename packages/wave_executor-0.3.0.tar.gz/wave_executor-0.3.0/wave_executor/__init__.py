"""
wave-executor — dependency-aware async task scheduling with reconciliation.

Four-level execution hierarchy:

    Task (atomic) → DAGExecutor → WaveReconciler → MetaDAG
"""

from .config import AggregationStrategy, ExecutionContext, TaskResult, WaveConfig, WaveDefinition, WaveResult
from .dag import AdaptiveSemaphore, DAGExecutionResult, DAGExecutor, EscalationReport
from .exceptions import WaveCircularDependencyError, WaveSignal
from .meta import MetaDAG, MetaDAGNodeResult, MetaDAGNodeSpec, MetaDAGResult
from .reconciler import (
    ReconcileStatus,
    ReconcileTaskSpec,
    ReconcileTaskState,
    RestartPolicy,
    WaveReconciler,
)

__all__ = [
    # Config
    "WaveConfig",
    "TaskResult",
    "WaveResult",
    "WaveDefinition",
    "ExecutionContext",
    "AggregationStrategy",
    # DAG
    "DAGExecutor",
    "DAGExecutionResult",
    "AdaptiveSemaphore",
    "EscalationReport",
    # Reconciler
    "WaveReconciler",
    "RestartPolicy",
    "ReconcileTaskSpec",
    "ReconcileTaskState",
    "ReconcileStatus",
    # MetaDAG
    "MetaDAG",
    "MetaDAGNodeSpec",
    "MetaDAGNodeResult",
    "MetaDAGResult",
    # Exceptions
    "WaveCircularDependencyError",
    "WaveSignal",
]

__version__ = "0.3.0"
