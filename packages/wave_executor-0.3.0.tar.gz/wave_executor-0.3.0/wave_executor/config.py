"""
Wave Execution Configuration

Defines dataclasses for wave-based parallel execution:
- WaveConfig: Configuration parameters for wave execution
- TaskResult:  Individual task execution result
- WaveResult:  Results from executing a wave
- WaveDefinition: Specification of tasks and dependencies for a single wave
- ExecutionContext: Context for an entire wave execution run
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional, Set


class AggregationStrategy(Enum):
    """Strategies for aggregating results between waves."""
    SEMANTIC_MERGE = "semantic_merge"   # Intelligently merge based on structure
    APPEND = "append"                   # Append lists, merge dicts
    DEEP_MERGE = "deep_merge"           # Deep dict merge
    FIRST = "first"                     # Take first result
    LAST = "last"                       # Take last result


@dataclass
class WaveConfig:
    """Configuration for wave execution."""

    # Concurrency control
    max_parallel_per_wave: int = 10
    """Maximum parallel tasks per wave (default 10, up to 1000+)"""

    inter_wave_delay_ms: int = 0
    """Delay between waves in milliseconds (for rate limiting)"""

    # Timeouts
    default_task_timeout: float = 120.0
    """Default timeout per task in seconds"""

    per_wave_timeout: float = 300.0
    """Timeout per entire wave in seconds"""

    total_execution_timeout: float = 3600.0
    """Total execution timeout in seconds"""

    # Error handling
    allow_partial_success: bool = True
    """Allow proceeding even if some tasks fail"""

    min_success_rate: float = 0.7
    """Minimum success rate required (0.0-1.0, default 70%)"""

    max_retries: int = 3
    """Maximum retries for failed tasks"""

    retry_backoff_factor: float = 2.0
    """Exponential backoff factor for retries"""

    # Aggregation
    aggregation_strategy: AggregationStrategy = AggregationStrategy.SEMANTIC_MERGE
    """How to aggregate results between waves"""

    # Other
    emit_events: bool = True
    """Emit progress events during execution"""

    stop_on_first_error: bool = False
    """Stop entire wave execution on first error"""

    # ── Adaptive batch window (AIMD) ──────────────────────────────────────────
    adaptive_batch_window: bool = True
    """Dynamically resize the concurrency window based on observed queue depth."""

    min_parallel: int = 2
    """Floor for the adaptive window (never drops below this)."""

    saturation_threshold: int = 20
    """Tasks waiting for a slot that trigger multiplicative window decrease."""

    # ── Circuit breaker ───────────────────────────────────────────────────────
    circuit_breaker_enabled: bool = True
    """Trip a circuit breaker after consecutive specialist failures to fail-fast."""

    circuit_failure_threshold: int = 5
    """Consecutive failures before the circuit opens (per circuit key)."""

    circuit_success_threshold: int = 2
    """Consecutive successes in HALF_OPEN state needed to close the circuit."""

    circuit_recovery_timeout: float = 60.0
    """Seconds after tripping before allowing a probe request (OPEN → HALF_OPEN)."""

    # ── Per-specialist budget carve-out ───────────────────────────────────────
    specialist_budgets: Dict[str, int] = field(default_factory=dict)
    """Map of specialist_name → max concurrent tasks for that specialist.
    Example: {"scraper": 5, "analyzer": 8}.  Specialists not listed use
    default_specialist_budget."""

    default_specialist_budget: int = 10
    """Fallback concurrency cap for specialists not in specialist_budgets."""


@dataclass
class TaskResult:
    """Result from executing a single task."""

    task_id: str
    """Unique identifier for this task"""

    wave_id: str
    """Wave ID this task belonged to"""

    status: str
    """Status: 'success', 'failed', 'skipped', 'timeout'"""

    output: Any = None
    """Task output/result"""

    error: Optional[str] = None
    """Error message if failed"""

    duration_ms: float = 0.0
    """Time taken to execute in milliseconds"""

    retry_count: int = 0
    """Number of retries before success/final failure"""

    started_at: datetime = field(default_factory=datetime.now)
    """When task started"""

    completed_at: Optional[datetime] = None
    """When task completed"""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "task_id": self.task_id,
            "wave_id": self.wave_id,
            "status": self.status,
            "output": self.output,
            "error": self.error,
            "duration_ms": round(self.duration_ms, 2),
            "retry_count": self.retry_count,
            "started_at": self.started_at.isoformat(),
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
        }


@dataclass
class WaveResult:
    """Result from executing a single wave."""

    wave_id: str
    wave_index: int
    task_results: Dict[str, TaskResult] = field(default_factory=dict)
    merged_output: Any = None
    started_at: datetime = field(default_factory=datetime.now)
    completed_at: Optional[datetime] = None

    @property
    def success_count(self) -> int:
        return sum(1 for tr in self.task_results.values() if tr.status == "success")

    @property
    def failure_count(self) -> int:
        return sum(1 for tr in self.task_results.values() if tr.status == "failed")

    @property
    def timeout_count(self) -> int:
        return sum(1 for tr in self.task_results.values() if tr.status == "timeout")

    @property
    def skipped_count(self) -> int:
        return sum(1 for tr in self.task_results.values() if tr.status == "skipped")

    @property
    def total_tasks(self) -> int:
        return len(self.task_results)

    @property
    def success_rate(self) -> float:
        total = self.total_tasks
        return self.success_count / total if total > 0 else 0.0

    @property
    def duration_ms(self) -> float:
        if not self.completed_at:
            return 0.0
        return (self.completed_at - self.started_at).total_seconds() * 1000

    @property
    def failed_tasks(self) -> List[TaskResult]:
        return [tr for tr in self.task_results.values() if tr.status == "failed"]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "wave_id": self.wave_id,
            "wave_index": self.wave_index,
            "success_count": self.success_count,
            "failure_count": self.failure_count,
            "timeout_count": self.timeout_count,
            "skipped_count": self.skipped_count,
            "total_tasks": self.total_tasks,
            "success_rate": round(self.success_rate, 3),
            "duration_ms": round(self.duration_ms, 2),
            "started_at": self.started_at.isoformat(),
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "merged_output": self.merged_output,
        }


@dataclass
class WaveDefinition:
    """Definition of a single wave with tasks and dependencies."""

    wave_id: str
    wave_index: int
    tasks: Dict[str, Any] = field(default_factory=dict)
    task_ids: Set[str] = field(default_factory=set)
    dependencies_resolved: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "wave_id": self.wave_id,
            "wave_index": self.wave_index,
            "task_count": len(self.task_ids),
            "tasks": {tid: spec for tid, spec in self.tasks.items()},
        }


@dataclass
class ExecutionContext:
    """Context for an entire wave execution run."""

    execution_id: str
    waves: List[WaveDefinition] = field(default_factory=list)
    wave_results: Dict[str, WaveResult] = field(default_factory=dict)
    config: WaveConfig = field(default_factory=WaveConfig)
    current_wave_index: int = 0
    started_at: datetime = field(default_factory=datetime.now)
    completed_at: Optional[datetime] = None
    cancelled: bool = False
    checkpoint_results: Dict[str, Dict[str, "TaskResult"]] = field(default_factory=dict)

    @property
    def total_waves(self) -> int:
        return len(self.waves)

    @property
    def completed_waves(self) -> int:
        return len(self.wave_results)

    @property
    def progress(self) -> float:
        total = self.total_waves
        return self.completed_waves / total if total > 0 else 0.0

    @property
    def total_tasks(self) -> int:
        return sum(wave.total_tasks for wave in self.wave_results.values())

    @property
    def total_successful(self) -> int:
        return sum(wave.success_count for wave in self.wave_results.values())

    @property
    def total_failed(self) -> int:
        return sum(wave.failure_count for wave in self.wave_results.values())

    @property
    def overall_success_rate(self) -> float:
        total = self.total_tasks
        return self.total_successful / total if total > 0 else 0.0

    @property
    def duration_ms(self) -> float:
        if not self.completed_at:
            return 0.0
        return (self.completed_at - self.started_at).total_seconds() * 1000
