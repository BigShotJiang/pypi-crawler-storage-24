"""Tests for MetaDAG."""
from __future__ import annotations

import asyncio
import pytest

from wave_executor import WaveConfig, WaveCircularDependencyError
from wave_executor.meta import MetaDAG, MetaDAGNodeSpec


async def instant(task_id, spec):
    return f"out-{task_id}"


async def failing(task_id, spec):
    raise RuntimeError("boom")


class TestMetaDAGBasic:
    @pytest.mark.asyncio
    async def test_empty_dag(self):
        result = await MetaDAG().execute()
        assert result.total_nodes == 0

    @pytest.mark.asyncio
    async def test_single_node(self):
        meta = MetaDAG()
        meta.add_node(MetaDAGNodeSpec(
            node_id="fetch",
            tasks={"a": {}, "b": {}},
            task_executor=instant,
        ))
        result = await meta.execute()
        assert result.successful_nodes == 1
        assert result.node_results["fetch"].status == "success"
        assert "a" in result.node_results["fetch"].task_outputs
        assert "b" in result.node_results["fetch"].task_outputs

    @pytest.mark.asyncio
    async def test_chained_nodes(self):
        order = []

        async def track(task_id, spec):
            order.append(spec.get("node"))
            return task_id

        meta = MetaDAG(inject_dep_outputs=False)
        meta.add_node(MetaDAGNodeSpec(
            node_id="stage1",
            tasks={"t1": {"node": "stage1"}},
            task_executor=track,
        ))
        meta.add_node(MetaDAGNodeSpec(
            node_id="stage2",
            tasks={"t2": {"node": "stage2"}},
            task_executor=track,
        ), depends_on=["stage1"])

        result = await meta.execute()
        assert result.successful_nodes == 2
        assert order[0] == "stage1"
        assert order[1] == "stage2"

    @pytest.mark.asyncio
    async def test_parallel_nodes(self):
        started = []

        async def track(task_id, spec):
            started.append(task_id)
            await asyncio.sleep(0.02)
            return task_id

        meta = MetaDAG()
        for i in range(3):
            meta.add_node(MetaDAGNodeSpec(
                node_id=f"node{i}",
                tasks={f"t{i}": {}},
                task_executor=track,
            ))

        result = await meta.execute()
        assert result.successful_nodes == 3

    @pytest.mark.asyncio
    async def test_method_chaining(self):
        meta = (
            MetaDAG()
            .add_node(MetaDAGNodeSpec(node_id="a", tasks={"t": {}}, task_executor=instant))
            .add_node(MetaDAGNodeSpec(node_id="b", tasks={"t": {}}, task_executor=instant), depends_on=["a"])
        )
        result = await meta.execute()
        assert result.successful_nodes == 2


class TestMetaDAGFailureHandling:
    @pytest.mark.asyncio
    async def test_failed_node_skips_downstream(self):
        meta = MetaDAG()
        meta.add_node(MetaDAGNodeSpec(
            node_id="root",
            tasks={"t": {}},
            task_executor=failing,
            config=WaveConfig(max_retries=0),
        ))
        meta.add_node(MetaDAGNodeSpec(
            node_id="child",
            tasks={"t": {}},
            task_executor=instant,
        ), depends_on=["root"])

        result = await meta.execute()
        assert result.node_results["root"].status == "failed"
        assert result.node_results["child"].status == "skipped"

    @pytest.mark.asyncio
    async def test_failed_node_does_not_block_independent(self):
        meta = MetaDAG()
        meta.add_node(MetaDAGNodeSpec(
            node_id="bad",
            tasks={"t": {}},
            task_executor=failing,
            config=WaveConfig(max_retries=0),
        ))
        meta.add_node(MetaDAGNodeSpec(
            node_id="good",
            tasks={"t": {}},
            task_executor=instant,
        ))

        result = await meta.execute()
        assert result.node_results["bad"].status == "failed"
        assert result.node_results["good"].status == "success"


class TestUpstreamOutputInjection:
    @pytest.mark.asyncio
    async def test_upstream_outputs_injected(self):
        received = {}

        async def capture(task_id, spec):
            received[task_id] = spec
            return f"out-{task_id}"

        meta = MetaDAG(inject_dep_outputs=True)
        meta.add_node(MetaDAGNodeSpec(
            node_id="producer",
            tasks={"p1": {}, "p2": {}},
            task_executor=capture,
        ))
        meta.add_node(MetaDAGNodeSpec(
            node_id="consumer",
            tasks={"c1": {}},
            task_executor=capture,
        ), depends_on=["producer"])

        await meta.execute()

        assert "_upstream_outputs" in received["c1"]
        assert "producer" in received["c1"]["_upstream_outputs"]


class TestCycleDetection:
    @pytest.mark.asyncio
    async def test_cycle_raises(self):
        meta = MetaDAG()
        meta.add_node(MetaDAGNodeSpec(node_id="a", tasks={}, task_executor=instant))
        meta.add_node(MetaDAGNodeSpec(node_id="b", tasks={}, task_executor=instant), depends_on=["a"])
        meta._node_dependencies["a"] = {"b"}  # inject a cycle

        with pytest.raises(WaveCircularDependencyError):
            await meta.execute()


class TestReconcilerNode:
    @pytest.mark.asyncio
    async def test_reconciler_node_completes(self):
        meta = MetaDAG()
        meta.add_node(MetaDAGNodeSpec(
            node_id="worker",
            tasks={"job1": {}, "job2": {}},
            task_executor=instant,
            node_type="reconciler",
            completion_timeout=5.0,
            completion_poll_interval=0.05,
        ))
        result = await meta.execute()
        assert result.node_results["worker"].status == "success"
        assert len(result.node_results["worker"].task_outputs) == 2


class TestEvents:
    @pytest.mark.asyncio
    async def test_meta_events_emitted(self):
        events = []
        meta = MetaDAG()
        meta.on_event(lambda et, ev: events.append(et))
        meta.add_node(MetaDAGNodeSpec(node_id="a", tasks={"t": {}}, task_executor=instant))
        await meta.execute()

        assert "META_EXECUTION_STARTED" in events
        assert "NODE_STARTED" in events
        assert "NODE_COMPLETED" in events
        assert "META_EXECUTION_COMPLETED" in events
