"""Tests for DAGExecutor and AdaptiveSemaphore."""
from __future__ import annotations

import asyncio
import pytest

from wave_executor import DAGExecutor, EscalationReport, WaveConfig, WaveCircularDependencyError


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

async def instant(task_id, spec):
    return f"result-{task_id}"


async def slow(task_id, spec):
    await asyncio.sleep(spec.get("sleep", 0.01))
    return f"result-{task_id}"


async def failing(task_id, spec):
    raise ValueError(f"Task {task_id} failed deliberately")


# ---------------------------------------------------------------------------
# Basic execution
# ---------------------------------------------------------------------------

class TestDAGExecutorBasic:
    @pytest.mark.asyncio
    async def test_single_task(self):
        result = await DAGExecutor().execute(
            tasks={"a": {}},
            dependencies={},
            task_executor=instant,
        )
        assert result.total_tasks == 1
        assert result.total_successful == 1
        assert result.task_results["a"].status == "success"
        assert result.task_results["a"].output == "result-a"

    @pytest.mark.asyncio
    async def test_independent_tasks_all_succeed(self):
        tasks = {f"t{i}": {} for i in range(5)}
        result = await DAGExecutor().execute(
            tasks=tasks, dependencies={}, task_executor=instant
        )
        assert result.total_successful == 5
        assert result.total_failed == 0

    @pytest.mark.asyncio
    async def test_dependent_task_receives_output(self):
        outputs = {}

        async def capture(task_id, spec):
            outputs[task_id] = spec.get("_dep_outputs", {})
            return f"done-{task_id}"

        result = await DAGExecutor().execute(
            tasks={"a": {}, "b": {}},
            dependencies={"b": {"a"}},
            task_executor=capture,
            inject_dep_outputs=True,
        )
        assert result.task_results["a"].status == "success"
        assert result.task_results["b"].status == "success"
        assert "a" in outputs["b"]

    @pytest.mark.asyncio
    async def test_empty_tasks(self):
        result = await DAGExecutor().execute(
            tasks={}, dependencies={}, task_executor=instant
        )
        assert result.total_tasks == 0

    @pytest.mark.asyncio
    async def test_execution_id_is_unique(self):
        ex = DAGExecutor()
        r1 = await ex.execute(tasks={"a": {}}, dependencies={}, task_executor=instant)
        r2 = await ex.execute(tasks={"a": {}}, dependencies={}, task_executor=instant)
        assert r1.execution_id != r2.execution_id

    @pytest.mark.asyncio
    async def test_completed_at_is_set(self):
        result = await DAGExecutor().execute(
            tasks={"a": {}}, dependencies={}, task_executor=instant
        )
        assert result.completed_at is not None


# ---------------------------------------------------------------------------
# Dependency semantics
# ---------------------------------------------------------------------------

class TestDependencies:
    @pytest.mark.asyncio
    async def test_linear_chain(self):
        order = []

        async def ordered(task_id, spec):
            order.append(task_id)
            return task_id

        result = await DAGExecutor().execute(
            tasks={"a": {}, "b": {}, "c": {}},
            dependencies={"b": {"a"}, "c": {"b"}},
            task_executor=ordered,
        )
        assert result.total_successful == 3
        assert order.index("a") < order.index("b") < order.index("c")

    @pytest.mark.asyncio
    async def test_failed_dep_skips_downstream(self):
        result = await DAGExecutor(config=WaveConfig(max_retries=0)).execute(
            tasks={"a": {}, "b": {}},
            dependencies={"b": {"a"}},
            task_executor=failing,
        )
        assert result.task_results["a"].status == "failed"
        assert result.task_results["b"].status == "skipped"

    @pytest.mark.asyncio
    async def test_partial_dep_failure_skips_only_downstream(self):
        async def mixed(task_id, spec):
            if task_id == "bad":
                raise ValueError("boom")
            return task_id

        result = await DAGExecutor(config=WaveConfig(max_retries=0)).execute(
            tasks={"good": {}, "bad": {}, "child_of_good": {}, "child_of_bad": {}},
            dependencies={"child_of_good": {"good"}, "child_of_bad": {"bad"}},
            task_executor=mixed,
        )
        assert result.task_results["good"].status == "success"
        assert result.task_results["bad"].status == "failed"
        assert result.task_results["child_of_good"].status == "success"
        assert result.task_results["child_of_bad"].status == "skipped"

    @pytest.mark.asyncio
    async def test_fan_in(self):
        """C waits for A and B — starts only when both succeed."""
        start_times = {}

        async def timed(task_id, spec):
            start_times[task_id] = asyncio.get_running_loop().time()
            await asyncio.sleep(spec.get("sleep", 0))
            return task_id

        result = await DAGExecutor().execute(
            tasks={"a": {"sleep": 0.02}, "b": {"sleep": 0.02}, "c": {}},
            dependencies={"c": {"a", "b"}},
            task_executor=timed,
        )
        assert result.total_successful == 3
        assert start_times["c"] >= start_times["a"]
        assert start_times["c"] >= start_times["b"]


# ---------------------------------------------------------------------------
# Cycle detection
# ---------------------------------------------------------------------------

class TestCycleDetection:
    @pytest.mark.asyncio
    async def test_direct_cycle_raises(self):
        with pytest.raises(WaveCircularDependencyError) as exc_info:
            await DAGExecutor().execute(
                tasks={"a": {}, "b": {}},
                dependencies={"a": {"b"}, "b": {"a"}},
                task_executor=instant,
            )
        assert "a" in exc_info.value.cycle_members or "b" in exc_info.value.cycle_members

    @pytest.mark.asyncio
    async def test_self_loop_raises(self):
        with pytest.raises(WaveCircularDependencyError):
            await DAGExecutor().execute(
                tasks={"a": {}},
                dependencies={"a": {"a"}},
                task_executor=instant,
            )

    @pytest.mark.asyncio
    async def test_unknown_dep_raises(self):
        with pytest.raises(ValueError, match="not defined in tasks"):
            await DAGExecutor().execute(
                tasks={"a": {}},
                dependencies={"a": {"nonexistent"}},
                task_executor=instant,
            )


# ---------------------------------------------------------------------------
# Retries
# ---------------------------------------------------------------------------

class TestRetries:
    @pytest.mark.asyncio
    async def test_task_succeeds_after_retries(self):
        attempts = {}

        async def flaky(task_id, spec):
            attempts[task_id] = attempts.get(task_id, 0) + 1
            if attempts[task_id] < 3:
                raise RuntimeError("not yet")
            return "ok"

        result = await DAGExecutor(
            config=WaveConfig(max_retries=3, retry_backoff_factor=0)
        ).execute(tasks={"a": {}}, dependencies={}, task_executor=flaky)
        assert result.task_results["a"].status == "success"
        assert result.task_results["a"].retry_count == 2

    @pytest.mark.asyncio
    async def test_exhausted_retries_marks_failed(self):
        result = await DAGExecutor(
            config=WaveConfig(max_retries=2, retry_backoff_factor=0)
        ).execute(tasks={"a": {}}, dependencies={}, task_executor=failing)
        assert result.task_results["a"].status == "failed"


# ---------------------------------------------------------------------------
# Events
# ---------------------------------------------------------------------------

class TestEvents:
    @pytest.mark.asyncio
    async def test_events_emitted(self):
        events = []
        ex = DAGExecutor()
        ex.on_event(lambda et, ev: events.append(et))

        await ex.execute(tasks={"a": {}}, dependencies={}, task_executor=instant)

        assert "EXECUTION_STARTED" in events
        assert "TASK_STARTED" in events
        assert "TASK_COMPLETED" in events
        assert "EXECUTION_COMPLETED" in events

    @pytest.mark.asyncio
    async def test_no_events_when_disabled(self):
        events = []
        ex = DAGExecutor(config=WaveConfig(emit_events=False))
        ex.on_event(lambda et, ev: events.append(et))

        await ex.execute(tasks={"a": {}}, dependencies={}, task_executor=instant)
        assert events == []


# ---------------------------------------------------------------------------
# Metrics
# ---------------------------------------------------------------------------

class TestMetrics:
    @pytest.mark.asyncio
    async def test_success_rate(self):
        async def mixed(task_id, spec):
            if task_id == "fail":
                raise ValueError()
            return task_id

        result = await DAGExecutor(config=WaveConfig(max_retries=0)).execute(
            tasks={"ok1": {}, "ok2": {}, "fail": {}},
            dependencies={},
            task_executor=mixed,
        )
        assert result.total_successful == 2
        assert result.total_failed == 1
        assert abs(result.overall_success_rate - 2 / 3) < 0.01

    @pytest.mark.asyncio
    async def test_critical_path(self):
        result = await DAGExecutor().execute(
            tasks={"a": {}, "b": {}, "c": {}},
            dependencies={"b": {"a"}, "c": {"b"}},
            task_executor=instant,
        )
        path = result.get_critical_path({"b": {"a"}, "c": {"b"}})
        assert path == ["a", "b", "c"]


class TestEscalationReport:
    @pytest.mark.asyncio
    async def test_escalation_on_exhausted_retries(self):
        """Failed task with no retries left should populate output with escalation report."""
        result = await DAGExecutor().execute(
            tasks={"bad": {}},
            dependencies={},
            task_executor=failing,
            config=WaveConfig(max_retries=0, circuit_breaker_enabled=False),
        )
        assert result.task_results["bad"].status == "failed"
        esc = result.task_results["bad"].output.get("escalation")
        assert esc is not None
        assert esc["task_id"] == "bad"
        assert len(esc["failure_history"]) >= 1
        assert esc["root_cause"]
        assert isinstance(esc["resolution_options"], list)

    @pytest.mark.asyncio
    async def test_escalation_on_timeout(self):
        """Timed-out task should emit an escalation report."""
        async def sleepy(task_id, spec):
            await asyncio.sleep(10)

        result = await DAGExecutor().execute(
            tasks={"slow": {}},
            dependencies={},
            task_executor=sleepy,
            config=WaveConfig(default_task_timeout=0.05, circuit_breaker_enabled=False),
        )
        assert result.task_results["slow"].status == "timeout"
        esc = result.task_results["slow"].output.get("escalation")
        assert esc is not None
        assert "timeout" in esc["root_cause"].lower()
        assert esc["circuit_state"] == "disabled"

    @pytest.mark.asyncio
    async def test_escalation_consistent_failure_root_cause(self):
        """Consistent error messages across retries should be detected as a code bug."""
        result = await DAGExecutor().execute(
            tasks={"bad": {}},
            dependencies={},
            task_executor=failing,
            config=WaveConfig(max_retries=2, circuit_breaker_enabled=False),
        )
        esc = result.task_results["bad"].output.get("escalation")
        assert esc is not None
        assert "consistent" in esc["root_cause"].lower() or esc["attempt_count"] == 3

    def test_escalation_report_to_dict(self):
        """EscalationReport.to_dict() should be JSON-serialisable."""
        report = EscalationReport(
            task_id="t1",
            execution_id="ex1",
            attempt_count=3,
            failure_history=["err1", "err2", "err3"],
            root_cause="Something bad",
            resolution_options=["Try again"],
            circuit_state="closed",
        )
        d = report.to_dict()
        assert d["task_id"] == "t1"
        assert d["attempt_count"] == 3
        assert len(d["failure_history"]) == 3
        assert "escalated_at" in d


class TestCircuitBreakerHalfOpen:
    def test_check_state_blocks_when_half_open(self):
        """
        _check_circuit_breaker_state should return an error string when the
        circuit is already HALF_OPEN, preventing additional retry probes from
        piling on a probe that is already in flight.
        """
        from wave_executor.dag import CircuitState

        executor = DAGExecutor()
        config = WaveConfig(circuit_breaker_enabled=True)

        cb = executor._get_circuit("svc", config)
        # Drive circuit to OPEN
        for _ in range(config.circuit_failure_threshold):
            cb.record_failure()
        assert cb.state == CircuitState.OPEN

        # Manually set HALF_OPEN (simulates first probe already in flight)
        cb._state = CircuitState.HALF_OPEN  # type: ignore[attr-defined]

        reason = executor._check_circuit_breaker_state("svc", config)
        assert reason is not None
        assert "HALF_OPEN" in reason

    def test_check_state_allows_when_closed(self):
        """_check_circuit_breaker_state returns None (allow) for a healthy circuit."""
        executor = DAGExecutor()
        config = WaveConfig(circuit_breaker_enabled=True)
        executor._get_circuit("svc", config)
        reason = executor._check_circuit_breaker_state("svc", config)
        assert reason is None

    def test_check_state_blocks_when_open_timeout_not_elapsed(self):
        """_check_circuit_breaker_state blocks when OPEN and recovery timeout has not elapsed."""
        from wave_executor.dag import CircuitState

        executor = DAGExecutor()
        config = WaveConfig(
            circuit_breaker_enabled=True,
            circuit_recovery_timeout=9999,
        )
        cb = executor._get_circuit("svc", config)
        for _ in range(config.circuit_failure_threshold):
            cb.record_failure()
        assert cb.state == CircuitState.OPEN

        reason = executor._check_circuit_breaker_state("svc", config)
        assert reason is not None
        assert "OPEN" in reason
