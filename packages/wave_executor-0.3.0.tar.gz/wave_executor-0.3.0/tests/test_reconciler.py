"""Tests for WaveReconciler."""
from __future__ import annotations

import asyncio
import pytest

from wave_executor import WaveConfig, WaveCircularDependencyError
from wave_executor.reconciler import (
    ReconcileTaskState,
    RestartPolicy,
    WaveReconciler,
)


async def instant(task_id, spec):
    return f"result-{task_id}"


async def failing(task_id, spec):
    raise RuntimeError(f"Task {task_id} failed")


class TestReconcilerLifecycle:
    @pytest.mark.asyncio
    async def test_start_stop(self):
        r = WaveReconciler(task_executor=instant)
        await r.start()
        await r.stop()

    @pytest.mark.asyncio
    async def test_double_start_is_idempotent(self):
        r = WaveReconciler(task_executor=instant)
        await r.start()
        await r.start()  # should not raise or create a second loop
        await r.stop()

    @pytest.mark.asyncio
    async def test_tasks_complete(self):
        r = WaveReconciler(
            task_executor=instant,
            config=WaveConfig(max_parallel_per_wave=5),
            poll_interval_s=0.05,
        )
        await r.start()
        await r.update(tasks={"a": {}, "b": {}, "c": {}})
        ok = await r.wait_until_complete(timeout=5)
        await r.stop()

        assert ok
        status = r.get_status()
        assert status.success_count == 3

    @pytest.mark.asyncio
    async def test_dep_ordering(self):
        completions = []

        async def track(task_id, spec):
            completions.append(task_id)
            return task_id

        r = WaveReconciler(task_executor=track, poll_interval_s=0.05)
        await r.start()
        await r.update(
            tasks={"a": {}, "b": {}},
            dependencies={"b": {"a"}},
        )
        await r.wait_until_complete(timeout=5)
        await r.stop()

        assert completions.index("a") < completions.index("b")

    @pytest.mark.asyncio
    async def test_get_status(self):
        r = WaveReconciler(task_executor=instant, poll_interval_s=0.05)
        await r.start()
        await r.update(tasks={"x": {}})
        await r.wait_until_complete(timeout=5)
        status = r.get_status()
        await r.stop()

        assert status.desired_task_count == 1
        assert status.success_count == 1
        assert status.reconcile_cycle > 0


class TestRestartPolicies:
    @pytest.mark.asyncio
    async def test_no_restart_policy(self):
        call_counts = {}

        async def count(task_id, spec):
            call_counts[task_id] = call_counts.get(task_id, 0) + 1
            raise RuntimeError("fail")

        r = WaveReconciler(
            task_executor=count,
            config=WaveConfig(default_task_timeout=1.0),
            poll_interval_s=0.05,
        )
        await r.start()
        await r.update(tasks={"a": {}}, policies={"a": "no"})
        await asyncio.sleep(0.3)
        await r.stop()

        # Should only have run once (no restart)
        assert call_counts.get("a", 0) == 1

    @pytest.mark.asyncio
    async def test_on_failure_restarts(self):
        call_counts = {"n": 0}

        async def fail_twice(task_id, spec):
            call_counts["n"] += 1
            if call_counts["n"] < 3:
                raise RuntimeError("not yet")
            return "ok"

        r = WaveReconciler(
            task_executor=fail_twice,
            config=WaveConfig(default_task_timeout=5.0),
            poll_interval_s=0.02,
        )
        await r.start()
        await r.update(
            tasks={"a": {}},
            policies={"a": "on-failure"},
            max_restart_attempts={"a": 5},
            restart_backoff_base=0.01,
        )
        ok = await r.wait_until_complete(timeout=5)
        await r.stop()

        assert ok
        assert call_counts["n"] >= 3

    @pytest.mark.asyncio
    async def test_max_restart_blocks_task(self):
        r = WaveReconciler(
            task_executor=failing,
            config=WaveConfig(default_task_timeout=0.1),
            poll_interval_s=0.02,
        )
        await r.start()
        await r.update(
            tasks={"a": {}},
            policies={"a": "on-failure"},
            max_restart_attempts={"a": 2},
            restart_backoff_base=0.01,
        )
        await r.wait_until_complete(timeout=5)
        await r.stop()

        assert r._state["a"].status == "blocked"


class TestHotUpdate:
    @pytest.mark.asyncio
    async def test_hot_add_task(self):
        r = WaveReconciler(task_executor=instant, poll_interval_s=0.05)
        await r.start()
        await r.update(tasks={"a": {}})
        await asyncio.sleep(0.1)
        await r.update(tasks={"a": {}, "b": {}})
        ok = await r.wait_until_complete(timeout=5)
        await r.stop()
        assert ok

    @pytest.mark.asyncio
    async def test_hot_remove_task(self):
        running = asyncio.Event()

        async def long_task(task_id, spec):
            running.set()
            await asyncio.sleep(10)

        r = WaveReconciler(task_executor=long_task, poll_interval_s=0.05)
        await r.start()
        await r.update(tasks={"a": {}, "b": {}}, policies={"a": "no", "b": "no"})
        await running.wait()

        # Remove task b
        await r.update(tasks={"a": {}}, policies={"a": "no"})
        await asyncio.sleep(0.15)
        await r.stop()

        assert "b" not in r._desired or r._state.get("b", ReconcileTaskState("b")).status == "stopped"

    @pytest.mark.asyncio
    async def test_cycle_rejected_in_update(self):
        r = WaveReconciler(task_executor=instant, poll_interval_s=0.1)
        await r.start()
        with pytest.raises(WaveCircularDependencyError):
            await r.update(
                tasks={"a": {}, "b": {}},
                dependencies={"a": {"b"}, "b": {"a"}},
            )
        await r.stop()


class TestDepOutputInjection:
    @pytest.mark.asyncio
    async def test_dep_outputs_injected(self):
        received = {}

        async def capture(task_id, spec):
            received[task_id] = spec
            return f"out-{task_id}"

        r = WaveReconciler(
            task_executor=capture,
            inject_dep_outputs=True,
            poll_interval_s=0.05,
        )
        await r.start()
        await r.update(
            tasks={"a": {}, "b": {}},
            dependencies={"b": {"a"}},
        )
        await r.wait_until_complete(timeout=5)
        await r.stop()

        assert "_dep_outputs" in received["b"]
        assert "a" in received["b"]["_dep_outputs"]
