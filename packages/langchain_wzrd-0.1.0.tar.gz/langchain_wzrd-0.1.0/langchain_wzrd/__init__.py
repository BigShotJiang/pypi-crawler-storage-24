"""WZRD velocity-aware model selection for LangChain."""

from langchain_wzrd.chat import ChatWZRD

__all__ = ["ChatWZRD"]
__version__ = "0.1.0"
