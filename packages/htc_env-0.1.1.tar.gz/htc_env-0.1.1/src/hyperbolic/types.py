"""Core data types used throughout the library."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class EvalResult:
    """Return type for evaluators that need to provide metadata alongside a score."""

    score: float
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class Assessment:
    """Multi-dimensional evaluation of a trajectory.

    Attributes:
        dimensions: Named dimension scores (e.g. {"accuracy": 1.0, "tone": 0.7}).
        scalar: Weighted scalar collapse for GRPO/PPO compatibility.
        metadata: Per-dimension details — judge scores, agreement, confidence, etc.
    """

    dimensions: dict[str, float] = field(default_factory=dict)
    scalar: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "dimensions": self.dimensions,
            "scalar": self.scalar,
            "metadata": self.metadata,
        }


@dataclass
class Step:
    """One step/turn in an episode."""

    step_num: int
    observation: dict[str, Any] = field(default_factory=dict)
    action: dict[str, Any] | None = None
    timestamp: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "step_num": self.step_num,
            "observation": _strip_binary(self.observation),
            "action": self.action,
            "timestamp": self.timestamp,
            "metadata": self.metadata,
        }


@dataclass
class Trajectory:
    """Complete record of one episode.

    Attributes:
        episode_id: Unique identifier for this episode.
        task: The task dict from the dataset that produced this trajectory.
        steps: Ordered list of steps taken during the episode.
        completion: Full message history (OpenAI chat format).
        assessment: Evaluation result, populated after the rubric scores the trajectory.
        metadata: Episode-level metadata (model version, timing, config, etc.).
    """

    episode_id: str = ""
    task: dict[str, Any] = field(default_factory=dict)
    steps: list[Step] = field(default_factory=list)
    completion: list[dict[str, Any]] = field(default_factory=list)
    assessment: Assessment | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def scalar_reward(self) -> float:
        if self.assessment is not None:
            return self.assessment.scalar
        return 0.0

    def to_dict(self) -> dict[str, Any]:
        return {
            "episode_id": self.episode_id,
            "task": self.task,
            "steps": [s.to_dict() for s in self.steps],
            "completion": _strip_images(self.completion),
            "assessment": self.assessment.to_dict() if self.assessment else None,
            "metadata": self.metadata,
        }


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _strip_images(messages: list[dict]) -> list[dict]:
    """Replace base64 image data with placeholders for serialization."""
    stripped = []
    for msg in messages:
        content = msg.get("content")
        if isinstance(content, list):
            parts = []
            for part in content:
                if part.get("type") == "image_url":
                    parts.append({"type": "image_url", "image_url": {"url": "[screenshot]"}})
                else:
                    parts.append(part)
            stripped.append({**msg, "content": parts})
        else:
            stripped.append(msg)
    return stripped


def _strip_binary(d: dict) -> dict:
    """Remove bytes values from a dict for JSON serialization."""
    out = {}
    for k, v in d.items():
        if isinstance(v, bytes):
            out[k] = f"<{len(v)} bytes>"
        elif isinstance(v, dict):
            out[k] = _strip_binary(v)
        else:
            out[k] = v
    return out
