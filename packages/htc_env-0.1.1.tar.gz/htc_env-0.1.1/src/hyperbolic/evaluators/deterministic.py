"""Deterministic evaluators — ground-truth and rule-based scoring."""

from __future__ import annotations

import re
from typing import Any

from hyperbolic.utils import extract_last_text


class ExactMatch:
    """1.0 if the model's final response exactly equals the expected answer."""

    def __init__(self, strip: bool = True, case_sensitive: bool = False):
        self.strip = strip
        self.case_sensitive = case_sensitive

    def __call__(self, completion: list[dict], answer: str | None = None) -> float:
        if answer is None:
            return 0.0
        response = extract_last_text(completion)
        a, b = response, answer
        if self.strip:
            a, b = a.strip(), b.strip()
        if not self.case_sensitive:
            a, b = a.lower(), b.lower()
        return 1.0 if a == b else 0.0


class RegexMatch:
    """1.0 if a regex pattern matches the model's final response.

    If *pattern* is ``None``, the ``answer`` field from the dataset is used
    as the pattern.
    """

    def __init__(self, pattern: str | None = None):
        self.pattern = pattern

    def __call__(self, completion: list[dict], answer: str | None = None) -> float:
        pat = self.pattern or (answer if answer else "")
        if not pat:
            return 0.0
        return 1.0 if re.search(pat, extract_last_text(completion)) else 0.0


class MathVerify:
    """Check mathematical equivalence of \\boxed{} answers.

    Falls back to exact string comparison when ``math-verify`` is not
    installed.
    """

    def __init__(self, extract: str = "boxed"):
        self.extract = extract

    def __call__(self, completion: list[dict], answer: str | None = None) -> float:
        if answer is None:
            return 0.0
        response = extract_last_text(completion)

        predicted = _extract_boxed(response)
        expected = _extract_boxed(answer) if "\\boxed" in answer else answer.strip()

        if not predicted:
            return 0.0

        try:
            from math_verify import verify  # type: ignore[import-untyped]

            return 1.0 if verify(predicted, expected) else 0.0
        except ImportError:
            return 1.0 if predicted.strip() == expected.strip() else 0.0


class URLMatch:
    """1.0 if the current browser URL matches the given regex pattern.

    Designed for BrowserEnv — the ``url`` argument is injected from the
    evaluation context.
    """

    def __init__(self, pattern: str):
        self.pattern = pattern

    def __call__(self, url: str | None = None) -> float:
        if url is None:
            return 0.0
        return 1.0 if re.search(self.pattern, url) else 0.0


class ElementCheck:
    """1.0 if a CSS selector is present on the current page.

    Requires a live Playwright ``page`` object in the evaluation context
    (provided automatically by BrowserEnv).
    """

    def __init__(self, selector: str):
        self.selector = selector

    def __call__(self, page: Any = None) -> float:
        if page is None:
            return 0.0
        try:
            el = page.query_selector(self.selector)
            return 1.0 if el else 0.0
        except Exception:
            return 0.0


class HeuristicScorer:
    """Configurable heuristic checks (length, keywords, format).

    Parameters:
        min_length / max_length: Response character length bounds.
        required_keywords: All must appear (case-insensitive).
        forbidden_keywords: None may appear.
    """

    def __init__(
        self,
        min_length: int | None = None,
        max_length: int | None = None,
        required_keywords: list[str] | None = None,
        forbidden_keywords: list[str] | None = None,
    ):
        self.min_length = min_length
        self.max_length = max_length
        self.required_keywords = required_keywords or []
        self.forbidden_keywords = forbidden_keywords or []

    def __call__(self, completion: list[dict]) -> float:
        text = extract_last_text(completion).lower()
        score = 1.0

        if self.min_length is not None and len(text) < self.min_length:
            score *= 0.5
        if self.max_length is not None and len(text) > self.max_length:
            score *= 0.5

        if self.required_keywords:
            found = sum(1 for kw in self.required_keywords if kw.lower() in text)
            score *= found / len(self.required_keywords)

        for kw in self.forbidden_keywords:
            if kw.lower() in text:
                score *= 0.0
                break

        return score


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_boxed(text: str) -> str:
    """Extract the content inside \\boxed{...}, handling nested braces."""
    idx = text.rfind("\\boxed{")
    if idx == -1:
        return ""
    start = idx + len("\\boxed{")
    depth = 1
    i = start
    while i < len(text) and depth > 0:
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
        i += 1
    return text[start : i - 1] if depth == 0 else ""
