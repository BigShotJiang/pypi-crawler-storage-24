"""Probabilistic evaluators — LLM judges and judge panels."""

from __future__ import annotations

import re
from concurrent.futures import ThreadPoolExecutor
from typing import Any

from hyperbolic.config import resolve_api_key
from hyperbolic.types import EvalResult
from hyperbolic.utils import extract_last_text, extract_prompt_text


class LLMJudge:
    """Score a trajectory using a single LLM judge.

    The judge receives a formatted prompt containing the task, the model's
    response, and (optionally) the expected answer, then returns a numeric
    score between 0 and 1.

    API keys are resolved through a three-tier chain:

    1. Explicit ``api_key`` parameter (highest priority)
    2. ``.env`` file in the project root (auto-loaded)
    3. ``OPENAI_API_KEY`` system environment variable

    Parameters:
        model: Judge model name (default ``"gpt-4o-mini"``).
        prompt: Custom prompt template with ``{prompt}``, ``{response}``,
            and ``{answer_section}`` placeholders.
        api_key: Explicit API key.  Falls back to ``.env`` / env var.
        base_url: Override the API base URL for compatible providers.
    """

    DEFAULT_PROMPT = (
        "Evaluate the following response on a scale from 0.0 to 1.0.\n\n"
        "Task / Question:\n```\n{prompt}\n```\n\n"
        "Response:\n```\n{response}\n```\n\n"
        "{answer_section}\n"
        "Respond with ONLY a number between 0.0 and 1.0."
    )

    def __init__(
        self,
        model: str = "gpt-4o-mini",
        prompt: str | None = None,
        api_key: str | None = None,
        base_url: str | None = None,
    ):
        self.model = model
        self.prompt_template = prompt or self.DEFAULT_PROMPT
        self._api_key = api_key
        self._base_url = base_url
        self._client: Any = None

    @property
    def client(self) -> Any:
        if self._client is None:
            from openai import OpenAI

            resolved_key = resolve_api_key(self._api_key, "OPENAI_API_KEY")
            self._client = OpenAI(api_key=resolved_key, base_url=self._base_url)
        return self._client

    def __call__(
        self,
        completion: list[dict] | None = None,
        prompt: list[dict] | str | None = None,
        answer: str | None = None,
    ) -> float:
        response_text = extract_last_text(completion) if completion else ""
        prompt_text = extract_prompt_text(prompt)
        answer_section = f"Expected answer:\n```\n{answer}\n```" if answer else ""

        judge_input = self.prompt_template.format(
            prompt=prompt_text,
            response=response_text,
            answer_section=answer_section,
        )

        try:
            result = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": judge_input}],
                temperature=0.0,
                max_tokens=50,
            )
            score_text = result.choices[0].message.content or ""
            match = re.search(r"(\d+\.?\d*)", score_text.strip())
            if match:
                return min(max(float(match.group(1)), 0.0), 1.0)
            return 0.0
        except Exception as exc:
            print(f"[LLMJudge] Error calling {self.model}: {exc}")
            return 0.0


class JudgePanel:
    """Score a trajectory using multiple LLM judges with aggregation.

    Each judge scores independently; scores are aggregated (mean, median,
    min, max) and inter-judge agreement is tracked as metadata.

    Parameters:
        judges: Model name strings or ``LLMJudge`` instances.
        prompt: Shared judge prompt template (used only for string judges).
        aggregation: ``"mean"`` | ``"median"`` | ``"min"`` | ``"max"``.
    """

    def __init__(
        self,
        judges: list[str | LLMJudge],
        prompt: str | None = None,
        aggregation: str = "median",
    ):
        self._judges: list[LLMJudge] = []
        for j in judges:
            if isinstance(j, str):
                self._judges.append(LLMJudge(model=j, prompt=prompt))
            else:
                self._judges.append(j)
        self.aggregation = aggregation

    def __call__(
        self,
        completion: list[dict] | None = None,
        prompt: list[dict] | str | None = None,
        answer: str | None = None,
    ) -> EvalResult:
        def _score(judge: LLMJudge) -> float:
            return judge(completion=completion, prompt=prompt, answer=answer)

        with ThreadPoolExecutor(max_workers=len(self._judges)) as pool:
            scores = list(pool.map(_score, self._judges))

        agg_score = _aggregate(scores, self.aggregation)

        if len(scores) > 1:
            agreement = 1.0 - (max(scores) - min(scores))
        else:
            agreement = 1.0

        judge_scores: dict[str, float] = {}
        for i, (j, s) in enumerate(zip(self._judges, scores)):
            key = j.model if sum(1 for jj in self._judges if jj.model == j.model) == 1 else f"{j.model}_{i}"
            judge_scores[key] = s

        return EvalResult(
            score=agg_score,
            metadata={
                "judge_scores": judge_scores,
                "aggregation": self.aggregation,
                "agreement": round(agreement, 4),
            },
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _aggregate(scores: list[float], method: str) -> float:
    if not scores:
        return 0.0
    if method == "median":
        s = sorted(scores)
        n = len(s)
        return s[n // 2] if n % 2 else (s[n // 2 - 1] + s[n // 2]) / 2
    if method == "mean":
        return sum(scores) / len(scores)
    if method == "min":
        return min(scores)
    if method == "max":
        return max(scores)
    return sum(scores) / len(scores)


