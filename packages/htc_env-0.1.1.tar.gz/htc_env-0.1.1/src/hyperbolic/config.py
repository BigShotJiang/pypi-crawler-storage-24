"""Configuration and secret management.

Resolves API keys through a three-tier chain:

1. **Explicit parameter** — passed directly in code (highest priority)
2. **``.env`` file** — auto-loaded from the project root if present
3. **System environment variable** — standard ``export VAR=value``

The ``.env`` file is loaded once on first access so that keys are available
to all components without requiring manual ``load_dotenv()`` calls.
"""

from __future__ import annotations

import os
from pathlib import Path

_dotenv_loaded = False


def _load_dotenv_once() -> None:
    """Load the nearest ``.env`` file exactly once.

    Searches upward from the current working directory for a ``.env`` file.
    Existing environment variables are **not** overwritten — explicit exports
    always win.
    """
    global _dotenv_loaded
    if _dotenv_loaded:
        return
    _dotenv_loaded = True

    try:
        from dotenv import load_dotenv

        env_path = _find_dotenv()
        if env_path:
            load_dotenv(env_path, override=False)
    except ImportError:
        pass


def _find_dotenv() -> Path | None:
    """Walk upward from cwd looking for a ``.env`` file."""
    current = Path.cwd().resolve()
    for directory in (current, *current.parents):
        candidate = directory / ".env"
        if candidate.is_file():
            return candidate
    return None


def resolve_api_key(
    explicit: str | None,
    env_var: str = "OPENAI_API_KEY",
) -> str | None:
    """Resolve an API key through the three-tier chain.

    Args:
        explicit: A key passed directly in code.  Returned immediately if
            not ``None``.
        env_var: The environment variable name to check (after loading
            ``.env``).

    Returns:
        The resolved key, or ``None`` if no key was found at any tier.
    """
    if explicit is not None:
        return explicit

    _load_dotenv_once()
    return os.environ.get(env_var)


# Well-known environment variable names for supported providers.
ENV_VARS = {
    "openai": "OPENAI_API_KEY",
    "anthropic": "ANTHROPIC_API_KEY",
    "together": "TOGETHER_API_KEY",
    "deepseek": "DEEPSEEK_API_KEY",
}
