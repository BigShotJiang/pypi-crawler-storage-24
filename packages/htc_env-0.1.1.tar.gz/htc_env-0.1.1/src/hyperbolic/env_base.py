"""EnvBase — abstract base for all environment types.

Handles the outer episode runner loop (dataset iteration, rollouts,
evaluation, logging) while subclasses implement the world-specific
interaction loop via ``_run_episode``.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from hyperbolic.agents.base import AgentBase
from hyperbolic.dataset import Dataset
from hyperbolic.rubric import Rubric
from hyperbolic.trajectory import TrajectoryLogger
from hyperbolic.types import Trajectory


class EnvBase(ABC):
    """Abstract base class for all RL environments.

    Parameters:
        dataset: Tasks to iterate over.  Accepts a :class:`Dataset` instance,
            a ``list[dict]``, or a HuggingFace dataset ID string
            (e.g. ``"openai/gsm8k"``).
        rubric: Evaluation pipeline (can be ``None`` for data collection).
        system_prompt: Default system prompt prepended to conversations.
        max_turns: Maximum turns / steps per episode.
        rollouts_per_task: How many rollouts to run for each task.
        output_dir: If set, trajectories are saved to this directory.
    """

    def __init__(
        self,
        dataset: Dataset | list[dict[str, Any]] | str,
        rubric: Rubric | None = None,
        system_prompt: str | None = None,
        max_turns: int = 10,
        rollouts_per_task: int = 1,
        output_dir: str | None = None,
    ):
        self.dataset = _resolve_dataset(dataset)
        self.rubric = rubric or Rubric()
        self.system_prompt = system_prompt
        self.max_turns = max_turns
        self.rollouts_per_task = rollouts_per_task
        self.output_dir = output_dir

        self._logger: TrajectoryLogger | None = None
        if output_dir:
            self._logger = TrajectoryLogger(output_dir)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def set_logger(self, output_dir: str) -> None:
        """Set or replace the trajectory logger with a new output directory."""
        self.output_dir = output_dir
        self._logger = TrajectoryLogger(output_dir)

    def run(
        self,
        agent: AgentBase,
        rollouts_per_task: int | None = None,
        run_name: str | None = None,
    ) -> list[Trajectory]:
        """Run every task through the environment and evaluate.

        Args:
            agent: The agent to use for generating responses.
            rollouts_per_task: Override the default number of rollouts per task.
            run_name: Optional label for this run (used in the output directory
                name, e.g. ``"simple_math"`` → ``runs/2026-03-02_22-02_simple_math/``).

        Returns:
            The full list of assessed trajectories.
        """
        n_rollouts = rollouts_per_task or self.rollouts_per_task
        trajectories: list[Trajectory] = []
        n_tasks = len(self.dataset)

        if self._logger:
            run_dir = self._logger.create_run(run_name)
            print(f"  Run directory: {run_dir}")
            print()

        for task_idx, task in enumerate(self.dataset):
            for rollout_idx in range(n_rollouts):
                episode_id = f"task_{task_idx + 1}_rollout_{rollout_idx + 1}"

                task_label = self._task_label(task)
                print(
                    f"  [{task_idx + 1}/{n_tasks}] "
                    f"Task: {task_label}"
                )
                if n_rollouts > 1:
                    print(f"         Rollout {rollout_idx + 1}/{n_rollouts}")

                trajectory = self._run_episode(agent, task, episode_id)

                extra = self._get_eval_context()
                assessment = self.rubric.evaluate(trajectory, task, extra)
                trajectory.assessment = assessment

                response_preview = self._response_preview(trajectory)
                if response_preview:
                    print(f"         Response: {response_preview}")

                dim_strs = [f"{k}={v:.2f}" for k, v in assessment.dimensions.items()]
                print(f"         Reward: {assessment.scalar:.3f}  ({', '.join(dim_strs)})")

                self._post_episode_cleanup()

                if self._logger:
                    path = self._logger.save(trajectory)
                    print(f"         Saved: {path}")

                print()
                trajectories.append(trajectory)

        self._on_run_complete()
        return trajectories

    # ------------------------------------------------------------------
    # Display helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _task_label(task: dict[str, Any]) -> str:
        """Extract a short, readable label from a task dict."""
        for key in ("question", "task", "description", "prompt"):
            val = task.get(key)
            if isinstance(val, str):
                return val[:80] + ("…" if len(val) > 80 else "")
            if isinstance(val, list) and val:
                for msg in val:
                    if msg.get("role") == "user":
                        text = msg.get("content", "")
                        if isinstance(text, str):
                            return text[:80] + ("…" if len(text) > 80 else "")
        return "(no description)"

    @staticmethod
    def _response_preview(trajectory: Trajectory) -> str:
        """Extract a short preview of the model's final response."""
        if not trajectory.completion:
            return ""
        for msg in reversed(trajectory.completion):
            if msg.get("role") == "assistant":
                content = msg.get("content", "")
                if isinstance(content, str) and content.strip():
                    text = content.strip().replace("\n", " ")
                    return text[:120] + ("…" if len(text) > 120 else "")
        return ""

    # ------------------------------------------------------------------
    # Subclass interface
    # ------------------------------------------------------------------

    @abstractmethod
    def _run_episode(
        self,
        agent: AgentBase,
        task: dict[str, Any],
        episode_id: str,
    ) -> Trajectory:
        """Execute one full episode.  Must be implemented by world modules."""
        ...

    def _get_eval_context(self) -> dict[str, Any]:
        """Return extra context for the evaluator (e.g. browser page/url).

        Called *after* ``_run_episode`` but *before* ``_post_episode_cleanup``,
        so browser pages are still alive.
        """
        return {}

    def _post_episode_cleanup(self) -> None:
        """Called after evaluation of each episode.

        Use this to release per-episode resources (browser contexts, etc.).
        """

    def _on_run_complete(self) -> None:
        """Called once after all episodes have finished."""

    def close(self) -> None:
        """Release all resources held by the environment."""
        self._on_run_complete()


# ------------------------------------------------------------------
# Dataset coercion
# ------------------------------------------------------------------

def _resolve_dataset(dataset: Dataset | list[dict[str, Any]] | str) -> Dataset:
    """Accept a Dataset, a list of dicts, or a HuggingFace ID string."""
    if isinstance(dataset, Dataset):
        return dataset
    if isinstance(dataset, list):
        return Dataset.from_list(dataset)
    if isinstance(dataset, str):
        return Dataset.from_hf(dataset)
    raise TypeError(
        f"dataset must be a Dataset, list[dict], or HuggingFace ID string, "
        f"got {type(dataset).__name__}"
    )
