"""CLI entry point: ``htc run <env_file> --model <model>``."""

from __future__ import annotations

import argparse
import importlib.util
import subprocess
import sys
from pathlib import Path


def _load_env_from_file(path: str):
    """Import a Python file and call its ``load_environment()`` function."""
    path = str(Path(path).resolve())
    spec = importlib.util.spec_from_file_location("_env_module", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    if not hasattr(module, "load_environment"):
        raise RuntimeError(
            f"{path} does not export a load_environment() function"
        )
    return module.load_environment()


def _make_agent(
    model_str: str,
    tool_choice: str | None = None,
    temperature: float | None = None,
    max_tokens: int = 1024,
):
    """Create an agent from a ``provider/model`` string."""
    from hyperbolic.agents.openai import OpenAIAgent

    return OpenAIAgent(
        model=model_str,
        tool_choice=tool_choice,
        temperature=temperature,
        max_tokens=max_tokens,
    )


def _cmd_setup(args: argparse.Namespace) -> None:
    """Install optional runtime dependencies (Playwright browsers, etc.)."""
    print()
    print("  htc setup")
    print("  " + "-" * 40)
    print("  Installing Playwright browsers ...")
    print()

    result = subprocess.run(
        [sys.executable, "-m", "playwright", "install", "chromium"],
        capture_output=False,
    )

    print()
    if result.returncode == 0:
        print("  Setup complete. You're ready to run browser environments.")
    else:
        print("  Playwright install failed. Make sure the browser extra is installed:")
        print("    pip install htc-env")
    print()


def _cmd_run(args: argparse.Namespace) -> None:
    """Execute an environment file."""
    env = _load_env_from_file(args.env_file)

    is_browser = hasattr(env, "browser_config")
    tool_choice = args.tool_choice
    if tool_choice is None and is_browser:
        tool_choice = "required"

    agent = _make_agent(
        args.model,
        tool_choice=tool_choice,
        temperature=args.temperature,
        max_tokens=args.max_tokens,
    )

    if env.output_dir is None:
        env.set_logger(args.output)

    env_name = Path(args.env_file).stem
    n_tasks = len(env.dataset)
    n_rollouts = args.rollouts

    print()
    print("  htc")
    print("  " + "-" * 40)
    print(f"  Environment : {args.env_file}")
    print(f"  Model       : {args.model}")
    print(f"  Tasks       : {n_tasks}")
    print(f"  Rollouts    : {n_rollouts} per task ({n_tasks * n_rollouts} total)")
    print(f"  Output      : {args.output}")
    print("  " + "-" * 40)
    print()

    try:
        trajectories = env.run(
            agent,
            rollouts_per_task=n_rollouts,
            run_name=env_name,
        )
    finally:
        env.close()

    rewards = [t.scalar_reward for t in trajectories]

    print("  " + "-" * 40)
    print("  Results")
    print("  " + "-" * 40)
    print(f"  Episodes    : {len(trajectories)}")
    if rewards:
        mean = sum(rewards) / len(rewards)
        print(f"  Mean reward : {mean:.3f}")
        print(f"  Min / Max   : {min(rewards):.3f} / {max(rewards):.3f}")
    print("  " + "-" * 40)
    print()


def main(argv: list[str] | None = None) -> None:
    from hyperbolic import __version__

    parser = argparse.ArgumentParser(
        prog="htc",
        description="Hyperbolic - RL environment runner and toolkit.",
    )
    parser.add_argument(
        "-V", "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )

    sub = parser.add_subparsers(dest="command")

    # --- run ---
    run_p = sub.add_parser("run", help="Run an environment file")
    run_p.add_argument("env_file", help="Path to a Python file with load_environment()")
    run_p.add_argument("-m", "--model", default="gpt-4o", help="Model (e.g. openai/gpt-4o)")
    run_p.add_argument("-r", "--rollouts", type=int, default=1, help="Rollouts per task")
    run_p.add_argument("-o", "--output", default="./runs", help="Output directory")
    run_p.add_argument("--tool-choice", default=None,
                       choices=["auto", "required", "none"],
                       help="Tool selection strategy (default: API decides)")
    run_p.add_argument("--temperature", type=float, default=None,
                       help="Sampling temperature (default: API decides)")
    run_p.add_argument("--max-tokens", type=int, default=1024,
                       help="Max tokens for model response")

    # --- setup ---
    sub.add_parser("setup", help="Install runtime dependencies (Playwright browsers, etc.)")

    args = parser.parse_args(argv)

    if args.command is None:
        parser.print_help()
        sys.exit(1)

    if args.command == "run":
        _cmd_run(args)
    elif args.command == "setup":
        _cmd_setup(args)


if __name__ == "__main__":
    main()
