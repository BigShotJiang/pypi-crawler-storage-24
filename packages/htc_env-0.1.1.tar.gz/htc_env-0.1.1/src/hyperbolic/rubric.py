"""Rubric — composable, multi-dimensional evaluation of trajectories.

The Rubric combines multiple evaluators (plain callables or evaluator objects)
into a single scoring pipeline.  Each evaluator targets a named *dimension*
and carries a weight.  The final scalar reward is the weighted average of all
non-zero-weight dimensions, while the full dimension vector and per-dimension
metadata are preserved in the Assessment for downstream use.

Evaluator functions declare what data they need via argument names.  The Rubric
inspects the signature at call time and injects matching values from a context
dict (completion, answer, info, url, page, state, …).
"""

from __future__ import annotations

import inspect
import json
from typing import Any, Callable

from hyperbolic.types import Assessment, EvalResult, Trajectory


class Rubric:
    """Composable multi-dimensional scoring system."""

    def __init__(
        self,
        funcs: list[Callable] | None = None,
        weights: list[float] | None = None,
    ):
        self._evaluators: list[tuple[Any, float, str]] = []

        if funcs:
            for i, func in enumerate(funcs):
                w = weights[i] if weights and i < len(weights) else 1.0
                name = _evaluator_name(func)
                self.add(func, weight=w, dimension=name)

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def add(
        self,
        evaluator: Callable,
        weight: float = 1.0,
        dimension: str | None = None,
    ) -> Rubric:
        """Add an evaluator with a weight and named dimension."""
        if dimension is None:
            dimension = _evaluator_name(evaluator)
        self._evaluators.append((evaluator, weight, dimension))
        return self

    def add_metric(
        self,
        evaluator: Callable,
        dimension: str | None = None,
    ) -> Rubric:
        """Add a zero-weight evaluator that tracks a metric without affecting reward."""
        if dimension is None:
            dimension = _evaluator_name(evaluator)
        self._evaluators.append((evaluator, 0.0, dimension))
        return self

    # ------------------------------------------------------------------
    # Evaluation
    # ------------------------------------------------------------------

    def evaluate(
        self,
        trajectory: Trajectory,
        task: dict[str, Any],
        extra_context: dict[str, Any] | None = None,
    ) -> Assessment:
        """Score a trajectory using all registered evaluators.

        Returns an Assessment with per-dimension scores, a scalar collapse,
        and metadata from evaluators that return EvalResult objects.
        """
        ctx = self._build_context(trajectory, task, extra_context)

        dimensions: dict[str, float] = {}
        dim_weights: dict[str, float] = {}
        metadata: dict[str, Any] = {}

        for evaluator, weight, dimension in self._evaluators:
            result = _call_with_injection(evaluator, ctx)

            if isinstance(result, EvalResult):
                score = result.score
                if result.metadata:
                    metadata[dimension] = result.metadata
            else:
                score = float(result)

            dimensions[dimension] = score
            dim_weights[dimension] = weight

        total_weight = sum(w for w in dim_weights.values() if w > 0)
        if total_weight > 0:
            scalar = (
                sum(dimensions[d] * dim_weights[d] for d in dimensions if dim_weights[d] > 0)
                / total_weight
            )
        else:
            scalar = 0.0

        return Assessment(dimensions=dimensions, scalar=scalar, metadata=metadata)

    # ------------------------------------------------------------------
    # Context building
    # ------------------------------------------------------------------

    @staticmethod
    def _build_context(
        trajectory: Trajectory,
        task: dict[str, Any],
        extra: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        completion = trajectory.completion
        prompt_msgs = []
        for msg in completion:
            if msg.get("role") == "assistant":
                break
            prompt_msgs.append(msg)

        info = task.get("info", {})
        if isinstance(info, str):
            try:
                info = json.loads(info)
            except (json.JSONDecodeError, TypeError):
                pass

        ctx: dict[str, Any] = {
            "trajectory": trajectory,
            "completion": completion,
            "prompt": prompt_msgs,
            "answer": task.get("answer"),
            "info": info,
            "task": task,
            "state": {},
        }

        if extra:
            ctx.update(extra)

        return ctx


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _evaluator_name(evaluator: Any) -> str:
    if hasattr(evaluator, "__name__"):
        return evaluator.__name__
    cls_name = type(evaluator).__name__
    if cls_name != "function":
        return cls_name
    return "evaluator"


def _call_with_injection(func: Callable, context: dict[str, Any]) -> Any:
    """Call *func* by injecting context values that match its parameter names."""
    sig = inspect.signature(func)
    kwargs: dict[str, Any] = {}
    for name, param in sig.parameters.items():
        if param.kind in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD):
            continue
        if name in context:
            kwargs[name] = context[name]
    return func(**kwargs)
