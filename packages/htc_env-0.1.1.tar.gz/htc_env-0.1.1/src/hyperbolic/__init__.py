"""Hyperbolic - A Python framework for building RL environments with
objective and subjective evaluation.

Usage::

    import hyperbolic as htc

    dataset = htc.Dataset.from_list([
        {"question": "What is 2+2?", "answer": "4"},
    ])
    rubric = htc.Rubric(funcs=[lambda completion, answer: 1.0 if answer in completion[-1]["content"] else 0.0])
    env = htc.SingleTurnEnv(dataset=dataset, rubric=rubric)
    agent = htc.OpenAIAgent(model="gpt-4o-mini")
    trajectories = env.run(agent)
"""

__version__ = "0.1.1"

from hyperbolic.config import resolve_api_key as _resolve_api_key  # noqa: F401
from hyperbolic.config import _load_dotenv_once as _init_dotenv

_init_dotenv()
del _init_dotenv

from hyperbolic.types import Assessment, EvalResult, Step, Trajectory
from hyperbolic.dataset import Dataset
from hyperbolic.rubric import Rubric
from hyperbolic.evaluators.deterministic import (
    ExactMatch,
    RegexMatch,
    MathVerify,
    URLMatch,
    ElementCheck,
    HeuristicScorer,
)
from hyperbolic.evaluators.probabilistic import LLMJudge, JudgePanel
from hyperbolic.env_base import EnvBase
from hyperbolic.envs.text import TextEnv, SingleTurnEnv, ToolEnv, generate_tool_schema
from hyperbolic.envs.browser import BrowserEnv, BrowserConfig
from hyperbolic.agents.base import AgentBase
from hyperbolic.agents.openai import OpenAIAgent
from hyperbolic.trajectory import TrajectoryLogger

__all__ = [
    "Assessment",
    "EvalResult",
    "Step",
    "Trajectory",
    "Dataset",
    "Rubric",
    "ExactMatch",
    "RegexMatch",
    "MathVerify",
    "URLMatch",
    "ElementCheck",
    "HeuristicScorer",
    "LLMJudge",
    "JudgePanel",
    "EnvBase",
    "TextEnv",
    "SingleTurnEnv",
    "ToolEnv",
    "BrowserEnv",
    "BrowserConfig",
    "AgentBase",
    "OpenAIAgent",
    "TrajectoryLogger",
    "generate_tool_schema",
]
