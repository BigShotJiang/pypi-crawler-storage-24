"""Trajectory logging, serialization, and export utilities."""

from __future__ import annotations

import json
import os
from datetime import datetime
from typing import Any

from hyperbolic.types import Trajectory


class TrajectoryLogger:
    """Saves trajectories to organized run directories.

    Each call to :meth:`create_run` produces a timestamped parent directory
    (e.g. ``runs/2026-03-02_22-02_simple_math/``).  Individual episodes are
    saved inside as ``task_1_rollout_1/``, ``task_2_rollout_1/``, etc.
    """

    def __init__(self, output_dir: str = "./runs"):
        self.output_dir = output_dir
        self.run_dir: str | None = None

    def create_run(self, run_name: str | None = None) -> str:
        """Create a new timestamped run directory.  Returns the path."""
        ts = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        suffix = f"_{run_name}" if run_name else ""
        self.run_dir = os.path.join(self.output_dir, f"{ts}{suffix}")
        os.makedirs(self.run_dir, exist_ok=True)
        return self.run_dir

    def save(self, trajectory: Trajectory) -> str:
        """Persist a trajectory to disk.  Returns the episode directory path."""
        parent = self.run_dir or self.output_dir
        episode_dir = os.path.join(parent, trajectory.episode_id)
        os.makedirs(episode_dir, exist_ok=True)

        traj_path = os.path.join(episode_dir, "trajectory.json")
        with open(traj_path, "w") as f:
            json.dump(trajectory.to_dict(), f, indent=2, default=str)

        screenshots_dir = os.path.join(episode_dir, "screenshots")
        for step in trajectory.steps:
            raw_bytes = step.observation.get("screenshot_bytes")
            if isinstance(raw_bytes, bytes):
                os.makedirs(screenshots_dir, exist_ok=True)
                fname = f"{step.step_num:03d}.png"
                with open(os.path.join(screenshots_dir, fname), "wb") as f:
                    f.write(raw_bytes)

        return episode_dir

    # ------------------------------------------------------------------
    # Export helpers
    # ------------------------------------------------------------------

    @staticmethod
    def export_scalar(trajectories: list[Trajectory]) -> list[dict[str, Any]]:
        """Collapse each trajectory to (episode_id, task, scalar_reward).

        Suitable for feeding into GRPO / PPO training pipelines.
        """
        return [
            {
                "episode_id": t.episode_id,
                "task": t.task,
                "reward": t.scalar_reward,
            }
            for t in trajectories
        ]

    @staticmethod
    def export_assessments(trajectories: list[Trajectory]) -> list[dict[str, Any]]:
        """Export full multi-dimensional assessments for analysis."""
        return [
            {
                "episode_id": t.episode_id,
                "task": t.task,
                "assessment": t.assessment.to_dict() if t.assessment else None,
            }
            for t in trajectories
        ]

    @staticmethod
    def save_batch(
        trajectories: list[Trajectory],
        path: str,
        fmt: str = "json",
    ) -> None:
        """Write a list of trajectories to a single file."""
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)

        if fmt == "jsonl":
            with open(path, "w") as f:
                for t in trajectories:
                    f.write(json.dumps(t.to_dict(), default=str) + "\n")
        else:
            with open(path, "w") as f:
                json.dump(
                    [t.to_dict() for t in trajectories],
                    f,
                    indent=2,
                    default=str,
                )
