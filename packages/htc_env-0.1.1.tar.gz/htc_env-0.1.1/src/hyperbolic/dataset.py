"""Dataset abstraction for loading task data from various sources."""

from __future__ import annotations

import json
from typing import Any, Iterator


class Dataset:
    """A list of task dicts that an environment iterates over.

    Each task dict should contain at least one of:
      - ``prompt``: list of messages (OpenAI chat format)
      - ``question``: a string (will be wrapped in a user message)

    Optional fields consumed by evaluators:
      - ``answer``: ground-truth string
      - ``info``: structured metadata (dict or JSON string)

    For browser environments, tasks typically include:
      - ``start_url``, ``reset_url``, ``task`` / ``description``

    String shorthand — you can pass a HuggingFace dataset ID anywhere a
    ``Dataset`` is expected::

        env = TextEnv(dataset="openai/gsm8k")           # full train split
        env = TextEnv(dataset="openai/gsm8k:test[:50]")  # first 50 of test
    """

    def __init__(self, tasks: list[dict[str, Any]]):
        self.tasks = tasks

    # ------------------------------------------------------------------
    # Factory methods
    # ------------------------------------------------------------------

    @classmethod
    def from_list(cls, tasks: list[dict[str, Any]]) -> Dataset:
        return cls(tasks)

    @classmethod
    def from_hf(
        cls,
        name: str,
        split: str = "train",
        n: int = -1,
        subset: str | None = None,
        **kwargs: Any,
    ) -> Dataset:
        """Load from a HuggingFace dataset (requires ``datasets`` extra).

        Shorthand formats::

            "openai/gsm8k"              -> name="openai/gsm8k", split="train"
            "openai/gsm8k:test"         -> split="test"
            "openai/gsm8k:test:50"      -> split="test", n=50
            "openai/gsm8k:test[:50]"    -> split="test[:50]" (HF slice syntax)

        Parameters:
            name: HuggingFace dataset ID, optionally with ``:split[:N]``.
            split: Default split to load.
            n: Limit the number of rows (``-1`` = all).
            subset: Dataset config / subset name (forwarded to ``load_dataset``).
            **kwargs: Extra arguments for ``load_dataset``.
        """
        try:
            from datasets import load_dataset
        except ImportError:
            raise ImportError(
                "HuggingFace datasets not installed. "
                "Run: pip install htc-env"
            )

        name, split, n = _parse_hf_shorthand(name, split, n)

        load_kwargs: dict[str, Any] = {**kwargs}
        if subset is not None:
            load_kwargs["name"] = subset

        ds = load_dataset(name.strip(), split=split.strip(), **load_kwargs)
        if n > 0:
            ds = ds.select(range(min(n, len(ds))))
        return cls([dict(row) for row in ds])

    @classmethod
    def from_file(cls, path: str) -> Dataset:
        """Load from a local JSON, JSONL, or CSV file."""
        if path.endswith(".json"):
            with open(path) as f:
                data = json.load(f)
            if not isinstance(data, list):
                raise ValueError("JSON file must contain a list of task dicts")
            return cls(data)

        if path.endswith(".jsonl"):
            tasks: list[dict] = []
            with open(path) as f:
                for line in f:
                    line = line.strip()
                    if line:
                        tasks.append(json.loads(line))
            return cls(tasks)

        if path.endswith(".csv"):
            import csv

            with open(path, newline="") as f:
                reader = csv.DictReader(f)
                return cls([dict(row) for row in reader])

        raise ValueError(f"Unsupported file format: {path}")

    # ------------------------------------------------------------------
    # Sequence interface
    # ------------------------------------------------------------------

    def __len__(self) -> int:
        return len(self.tasks)

    def __getitem__(self, idx: int) -> dict[str, Any]:
        return self.tasks[idx]

    def __iter__(self) -> Iterator[dict[str, Any]]:
        return iter(self.tasks)

    def select(self, indices: range | list[int]) -> Dataset:
        return type(self)([self.tasks[i] for i in indices])


def _parse_hf_shorthand(
    name: str,
    default_split: str,
    default_n: int,
) -> tuple[str, str, int]:
    """Parse ``"repo/name:split:N"`` shorthand into (name, split, n).

    Handles the ambiguity between ``:`` as a split separator and HuggingFace's
    built-in ``[:N]`` slice syntax.  If the segment after the first ``:``
    contains ``[``, it is treated as HF slice syntax and kept in the split
    string verbatim.
    """
    if ":" not in name:
        return name, default_split, default_n

    first_colon = name.index(":")
    dataset_id = name[:first_colon]
    remainder = name[first_colon + 1:]

    if "[" in remainder:
        return dataset_id, remainder, default_n

    parts = remainder.split(":")
    split = parts[0] if parts[0] else default_split
    n = default_n
    if len(parts) >= 2 and parts[1].strip().isdigit():
        n = int(parts[1].strip())

    return dataset_id, split, n
