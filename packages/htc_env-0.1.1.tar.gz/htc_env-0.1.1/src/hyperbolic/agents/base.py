"""Base class / protocol for agents that connect models to environments."""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class AgentBase(Protocol):
    """Minimal contract that every agent adapter must satisfy.

    The environment calls ``act()`` once per turn, passing the current
    conversation history (OpenAI chat-message format) and optionally a list
    of tool schemas.  The agent returns the next assistant message dict.
    """

    def act(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        """Return the next assistant message given the conversation so far.

        The returned dict must have at minimum ``{"role": "assistant", "content": "..."}``.
        If the model invokes tools, include a ``"tool_calls"`` key with the
        standard OpenAI tool_calls structure.
        """
        ...
