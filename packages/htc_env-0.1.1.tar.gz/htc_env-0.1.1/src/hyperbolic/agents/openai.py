"""OpenAI-compatible agent adapter."""

from __future__ import annotations

from typing import Any

from hyperbolic.config import resolve_api_key


class OpenAIAgent:
    """Agent that uses any OpenAI-compatible API (GPT-4o, vLLM, etc.).

    API keys are resolved through a three-tier chain:

    1. Explicit ``api_key`` parameter (highest priority)
    2. ``.env`` file in the project root (auto-loaded)
    3. ``OPENAI_API_KEY`` system environment variable

    Parameters:
        model: Model name or ``"provider/model"`` string (default ``"gpt-4o"``).
            The provider prefix is stripped — only the model name is sent to
            the API.
        api_key: Explicit API key.  Falls back to ``.env`` / env var.
        base_url: Override the API base URL for compatible providers.
        max_tokens: Max tokens for the model response.
        temperature: Sampling temperature.  ``None`` (the default) lets the
            API use its own default (typically 1.0).
        tool_choice: Tool selection strategy when tools are provided.
            ``"auto"``, ``"required"``, ``"none"``, or a specific tool name
            dict.  ``None`` (the default) lets the API decide.
        **kwargs: Extra keyword arguments forwarded to ``chat.completions.create``.
    """

    def __init__(
        self,
        model: str = "gpt-4o",
        api_key: str | None = None,
        base_url: str | None = None,
        max_tokens: int = 1024,
        temperature: float | None = None,
        tool_choice: str | dict | None = None,
        **kwargs: Any,
    ):
        from openai import OpenAI

        resolved_key = resolve_api_key(api_key, "OPENAI_API_KEY")

        if "/" in model:
            _, model = model.split("/", 1)

        self.model = model
        self.max_tokens = max_tokens
        self.temperature = temperature
        self.tool_choice = tool_choice
        self.extra_kwargs = kwargs
        self._client = OpenAI(api_key=resolved_key, base_url=base_url)

    def act(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        """Send messages to the model and return the assistant response."""
        create_kwargs: dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "max_tokens": self.max_tokens,
            **self.extra_kwargs,
        }

        if self.temperature is not None:
            create_kwargs["temperature"] = self.temperature

        if tools:
            create_kwargs["tools"] = tools
            if self.tool_choice is not None:
                create_kwargs["tool_choice"] = self.tool_choice

        response = self._client.chat.completions.create(**create_kwargs)
        message = response.choices[0].message

        result: dict[str, Any] = {
            "role": "assistant",
            "content": message.content,
        }

        if message.tool_calls:
            result["tool_calls"] = [
                {
                    "id": tc.id,
                    "type": "function",
                    "function": {
                        "name": tc.function.name,
                        "arguments": tc.function.arguments,
                    },
                }
                for tc in message.tool_calls
            ]

        return result
