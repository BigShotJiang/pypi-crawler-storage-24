"""Text-based environments: single-turn, multi-turn, and tool-calling."""

from __future__ import annotations

import inspect
import json
from datetime import datetime
from typing import Any, Callable

from hyperbolic.agents.base import AgentBase
from hyperbolic.env_base import EnvBase
from hyperbolic.types import Step, Trajectory

_TYPE_MAP: dict[type, str] = {
    int: "integer",
    float: "number",
    bool: "boolean",
    str: "string",
}


# -----------------------------------------------------------------------
# Tool schema generation
# -----------------------------------------------------------------------

def generate_tool_schema(func: Callable) -> dict[str, Any]:
    """Build an OpenAI-compatible tool schema from a Python function.

    The function name becomes the tool name, type hints define parameter
    types, and the docstring provides descriptions (parsed from an
    ``Args:`` section if present).
    """
    sig = inspect.signature(func)
    doc = inspect.getdoc(func) or ""

    param_docs: dict[str, str] = {}
    if "Args:" in doc:
        args_section = doc.split("Args:", 1)[1]
        for marker in ("Returns:", "Raises:", "Example:", "Note:"):
            if marker in args_section:
                args_section = args_section.split(marker, 1)[0]
        for line in args_section.strip().splitlines():
            line = line.strip()
            if ":" in line:
                pname, pdesc = line.split(":", 1)
                pname = pname.strip().rstrip("()")
                param_docs[pname] = pdesc.strip()

    properties: dict[str, Any] = {}
    required: list[str] = []

    for name, param in sig.parameters.items():
        prop: dict[str, Any] = {"type": _TYPE_MAP.get(param.annotation, "string")}
        if name in param_docs:
            prop["description"] = param_docs[name]
        properties[name] = prop
        if param.default is inspect.Parameter.empty:
            required.append(name)

    description = doc.split("Args:", 1)[0].strip() if "Args:" in doc else doc.strip()

    return {
        "type": "function",
        "function": {
            "name": func.__name__,
            "description": description or func.__name__,
            "parameters": {
                "type": "object",
                "properties": properties,
                "required": required,
            },
        },
    }


# -----------------------------------------------------------------------
# TextEnv
# -----------------------------------------------------------------------

class TextEnv(EnvBase):
    """Multi-turn text environment with optional tool calling.

    Each episode is a conversation between the agent and (optionally) a
    set of callable tools.  The episode ends when the model responds
    without any tool calls, or when ``max_turns`` is reached.

    Parameters:
        tools: Python functions to expose as callable tools.  Schemas are
            auto-generated from signatures and docstrings.
        **kwargs: Forwarded to :class:`EnvBase`.
    """

    def __init__(
        self,
        tools: list[Callable] | None = None,
        **kwargs: Any,
    ):
        super().__init__(**kwargs)

        self._tools: dict[str, Callable] = {}
        self._tool_schemas: list[dict[str, Any]] = []

        if tools:
            for fn in tools:
                self._tools[fn.__name__] = fn
                self._tool_schemas.append(generate_tool_schema(fn))

    # ------------------------------------------------------------------
    # Episode loop
    # ------------------------------------------------------------------

    def _run_episode(
        self,
        agent: AgentBase,
        task: dict[str, Any],
        episode_id: str,
    ) -> Trajectory:
        messages = self._build_prompt(task)
        steps: list[Step] = []

        for turn in range(self.max_turns):
            step_ts = datetime.now().isoformat()
            obs_snapshot = {"messages_len": len(messages)}

            # --- Agent turn ---
            schemas = self._tool_schemas if self._tool_schemas else None
            response = agent.act(messages, tools=schemas)
            messages.append(response)

            step = Step(
                step_num=turn,
                observation=obs_snapshot,
                action={
                    "role": "assistant",
                    "content": response.get("content", ""),
                    "tool_calls": response.get("tool_calls"),
                },
                timestamp=step_ts,
            )
            steps.append(step)

            # --- Tool execution ---
            tool_calls = response.get("tool_calls", [])
            if not tool_calls:
                break

            for tc in tool_calls:
                func_name = tc["function"]["name"]
                try:
                    args = json.loads(tc["function"]["arguments"])
                except (json.JSONDecodeError, KeyError):
                    args = {}

                result_str = self._execute_tool(func_name, args)

                messages.append({
                    "role": "tool",
                    "tool_call_id": tc["id"],
                    "content": result_str,
                })

        return Trajectory(
            episode_id=episode_id,
            task=task,
            steps=steps,
            completion=list(messages),
            metadata={
                "num_turns": len(steps),
                "has_tools": bool(self._tool_schemas),
                "tool_names": list(self._tools.keys()),
            },
        )

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _build_prompt(self, task: dict[str, Any]) -> list[dict[str, Any]]:
        messages: list[dict[str, Any]] = []

        if self.system_prompt:
            messages.append({"role": "system", "content": self.system_prompt})

        if "prompt" in task:
            prompt = task["prompt"]
            if isinstance(prompt, list):
                if messages and prompt and prompt[0].get("role") == "system":
                    messages = list(prompt)
                else:
                    messages.extend(prompt)
            elif isinstance(prompt, str):
                messages.append({"role": "user", "content": prompt})
        elif "question" in task:
            messages.append({"role": "user", "content": task["question"]})

        return messages

    def _execute_tool(self, name: str, args: dict[str, Any]) -> str:
        if name not in self._tools:
            return f"Error: unknown tool '{name}'"
        try:
            result = self._tools[name](**args)
            return str(result)
        except Exception as exc:
            return f"Error: {exc}"


# -----------------------------------------------------------------------
# Convenience subclasses
# -----------------------------------------------------------------------

class SingleTurnEnv(TextEnv):
    """A TextEnv limited to a single model response (no tools, one turn)."""

    def __init__(self, **kwargs: Any):
        kwargs.setdefault("max_turns", 1)
        super().__init__(**kwargs)


class ToolEnv(TextEnv):
    """Alias for ``TextEnv(tools=...)`` — makes intent explicit."""

    def __init__(self, tools: list[Callable], **kwargs: Any):
        super().__init__(tools=tools, **kwargs)
