"""Browser environment — Playwright-based CUA interaction loop.

The agent receives screenshots and a status line, then responds with
vision-based tool calls (click coordinates, type_text, scroll, etc.).
This follows the standard CUA contract: pixels in, actions out.
No DOM access or CSS selectors — the model reasons from screenshots only.
"""

from __future__ import annotations

import base64
import json
import urllib.request
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from hyperbolic.agents.base import AgentBase
from hyperbolic.env_base import EnvBase
from hyperbolic.types import Step, Trajectory


# -----------------------------------------------------------------------
# Configuration
# -----------------------------------------------------------------------

@dataclass
class BrowserConfig:
    """Settings for the Playwright browser instance."""

    headless: bool = True
    slow_mo: int = 0
    viewport: tuple[int, int] = (1024, 768)


# -----------------------------------------------------------------------
# Tool schemas — pure CUA primitives (no CSS selectors)
# -----------------------------------------------------------------------

BROWSER_TOOLS: tuple[dict[str, Any], ...] = (
    {
        "type": "function",
        "function": {
            "name": "click",
            "description": "Click at pixel coordinates (x, y) on the page.",
            "parameters": {
                "type": "object",
                "properties": {
                    "x": {"type": "integer", "description": "X pixel coordinate"},
                    "y": {"type": "integer", "description": "Y pixel coordinate"},
                },
                "required": ["x", "y"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "type_text",
            "description": (
                "Type text into the currently focused element. "
                "Click on an input field first to focus it, then call type_text."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "text": {"type": "string", "description": "Text to type"},
                    "press_enter": {
                        "type": "boolean",
                        "description": "Press Enter after typing (default true)",
                    },
                },
                "required": ["text"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "keypress",
            "description": "Press a keyboard key (e.g. 'Enter', 'Tab', 'Escape', 'Backspace').",
            "parameters": {
                "type": "object",
                "properties": {
                    "key": {"type": "string", "description": "Key name to press"},
                },
                "required": ["key"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "scroll",
            "description": "Scroll the page to reveal content above or below the fold.",
            "parameters": {
                "type": "object",
                "properties": {
                    "direction": {
                        "type": "string",
                        "enum": ["up", "down"],
                        "description": "Scroll direction",
                    },
                    "amount": {
                        "type": "integer",
                        "description": "Pixels to scroll (default 500)",
                    },
                },
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "goto",
            "description": (
                "Navigate the browser to a URL. Only use this if you can see "
                "the exact URL on the page. Do NOT guess URLs."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "url": {"type": "string", "description": "Full URL to navigate to"},
                },
                "required": ["url"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "wait",
            "description": "Wait for the page to load or settle.",
            "parameters": {
                "type": "object",
                "properties": {
                    "ms": {"type": "integer", "description": "Milliseconds to wait (default 1000)"},
                },
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "done",
            "description": "Call this when you have completed the task.",
            "parameters": {
                "type": "object",
                "properties": {
                    "summary": {
                        "type": "string",
                        "description": "Summary of what was accomplished",
                    },
                },
            },
        },
    },
)


DEFAULT_BROWSER_SYSTEM_PROMPT = """\
You are a browser automation agent. You see screenshots of a web browser \
and must complete the given objective by browsing like a natural user.

Tools available:
- click(x, y): Click at pixel coordinates on the page. Study the \
screenshot to identify the element's position, then click it.
- type_text(text): Type text into the currently focused element. \
Click on an input field first, then call type_text.
- keypress(key): Press a keyboard key (Enter, Tab, Escape, etc.).
- scroll(direction, amount): Scroll up or down to reveal more content.
- goto(url): Navigate to a URL visible on screen. Do NOT guess URLs.
- wait(ms): Wait for the page to settle.
- done(): Call this when you have completed the task.

HOW TO BROWSE:
1. Call exactly ONE tool per turn.
2. Study the screenshot carefully. Identify buttons, links, cards, and \
input fields by their visual appearance and position.
3. Click on what you SEE using x,y coordinates from the screenshot. \
This is how a real user browses -- find the element visually, then click it.
4. To type into an input: first click on it, then call type_text.
5. After each action, check the new screenshot to see if it worked. \
If the page didn't change, try clicking a slightly different position.
6. If an action isn't working after two attempts, try a completely \
different approach -- scroll to reveal new content, or navigate a \
different path to reach the same goal.
7. Do NOT guess URLs. Navigate by clicking links on the page.
8. When the task is complete, call done()."""


# -----------------------------------------------------------------------
# BrowserEnv
# -----------------------------------------------------------------------

class BrowserEnv(EnvBase):
    """Playwright-based browser environment for CUA-style tasks.

    Each episode:
      1. Optionally POSTs to a ``reset_url`` to reset server-side state.
      2. Navigates to ``start_url``.
      3. Loops: screenshot → agent → tool call → execute → repeat.
      4. Ends when the agent sends a message without tool calls,
         calls ``done()``, or ``max_turns`` is reached.

    The agent receives observation messages with embedded screenshots
    (base64 PNG) so any vision-capable model can be used.
    """

    def __init__(
        self,
        browser_config: BrowserConfig | None = None,
        **kwargs: Any,
    ):
        self.browser_config = browser_config or BrowserConfig()
        if kwargs.get("system_prompt") is None:
            kwargs["system_prompt"] = DEFAULT_BROWSER_SYSTEM_PROMPT
        super().__init__(**kwargs)
        self._playwright: Any = None
        self._browser: Any = None
        self._page: Any = None
        self._context: Any = None

    # ------------------------------------------------------------------
    # Browser lifecycle
    # ------------------------------------------------------------------

    def _ensure_browser(self) -> None:
        if self._browser is not None:
            return
        from playwright.sync_api import sync_playwright

        self._playwright = sync_playwright().start()
        self._browser = self._playwright.chromium.launch(
            headless=self.browser_config.headless,
            slow_mo=self.browser_config.slow_mo,
        )

    def _take_screenshot(self) -> str:
        """Capture the current page as a base64-encoded PNG."""
        raw = self._page.screenshot(type="png")
        return base64.b64encode(raw).decode()

    def _take_screenshot_bytes(self) -> bytes:
        return self._page.screenshot(type="png")

    # ------------------------------------------------------------------
    # Status formatting (matches CUA contract)
    # ------------------------------------------------------------------

    def _format_status(self, success: bool, error: str | None = None) -> str:
        """Build a status line with URL and viewport for tool responses."""
        vp_w, vp_h = self.browser_config.viewport
        parts = [
            f"Status: {'Success' if success else 'Failed'}",
        ]
        if error:
            parts.append(f"Error: {error}")
        parts.append(f"URL: {self._page.url}")
        parts.append(f"Viewport: {vp_w}x{vp_h}")
        return "\n".join(parts)

    def _make_observation(self, status_text: str, screenshot_b64: str) -> list[dict]:
        """Build multipart content: [text status, screenshot image]."""
        return [
            {"type": "text", "text": status_text},
            {
                "type": "image_url",
                "image_url": {
                    "url": f"data:image/png;base64,{screenshot_b64}",
                },
            },
        ]

    # ------------------------------------------------------------------
    # Episode loop
    # ------------------------------------------------------------------

    SCREENSHOT_WINDOW: int = 2

    def _run_episode(
        self,
        agent: AgentBase,
        task: dict[str, Any],
        episode_id: str,
    ) -> Trajectory:
        self._ensure_browser()

        vp = self.browser_config.viewport
        self._context = self._browser.new_context(
            viewport={"width": vp[0], "height": vp[1]},
        )
        self._page = self._context.new_page()

        # --- Deterministic reset ---
        reset_url = task.get("reset_url")
        if reset_url:
            try:
                req = urllib.request.Request(
                    reset_url,
                    data=b"{}",
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                urllib.request.urlopen(req, timeout=5)
                print(f"         Reset: {reset_url}")
            except Exception as exc:
                print(f"         Reset failed: {exc}")

        # --- Navigate to start URL ---
        start_url = task.get("start_url", "about:blank")
        self._page.goto(start_url, wait_until="domcontentloaded")
        self._page.wait_for_timeout(1500)

        # --- Build initial messages ---
        task_desc = task.get("task", task.get("description", task.get("question", "")))
        screenshot_b64 = self._take_screenshot()
        vp_w, vp_h = self.browser_config.viewport

        messages: list[dict[str, Any]] = []
        if self.system_prompt:
            messages.append({"role": "system", "content": self.system_prompt})

        messages.append({
            "role": "user",
            "content": self._make_observation(
                f"Your objective: {task_desc}\n\n"
                f"URL: {self._page.url}\n"
                f"Viewport: {vp_w}x{vp_h}\n\n"
                "Look at the screenshot and decide your first action.",
                screenshot_b64,
            ),
        })

        screenshot_msg_indices: list[int] = [len(messages) - 1]
        steps: list[Step] = []
        recent_actions: list[str] = []

        for step_num in range(self.max_turns):
            step_ts = datetime.now().isoformat()

            self._apply_screenshot_window(messages, screenshot_msg_indices)

            # --- Agent turn ---
            response = agent.act(messages, tools=list(BROWSER_TOOLS))
            messages.append(response)

            tool_calls = response.get("tool_calls", [])

            step = Step(
                step_num=step_num,
                observation={
                    "url": self._page.url,
                    "screenshot_bytes": self._take_screenshot_bytes(),
                },
                action={
                    "content": response.get("content", ""),
                    "tool_calls": [
                        {"name": tc["function"]["name"], "args": tc["function"].get("arguments", "{}")}
                        for tc in tool_calls
                    ] if tool_calls else None,
                },
                timestamp=step_ts,
            )
            steps.append(step)

            if not tool_calls:
                break

            # --- Execute tool calls ---
            done_called = False
            last_success = True

            for tc in tool_calls:
                func_name = tc["function"]["name"]
                try:
                    args = json.loads(tc["function"]["arguments"])
                except (json.JSONDecodeError, KeyError):
                    args = {}

                if func_name == "done":
                    done_called = True
                    messages.append({
                        "role": "tool",
                        "tool_call_id": tc["id"],
                        "content": "Task marked as complete.",
                    })
                    continue

                success, result_text = self._execute_action(func_name, args)
                last_success = success

                messages.append({
                    "role": "tool",
                    "tool_call_id": tc["id"],
                    "content": self._format_status(success, result_text if not success else None),
                })

            if done_called:
                break

            # --- Post-action observation as user message ---
            self._page.wait_for_timeout(500)
            screenshot_b64 = self._take_screenshot()

            action_key = self._action_fingerprint(tool_calls)
            recent_actions.append(action_key)

            status = self._format_status(last_success)
            repeat_count = self._count_consecutive_repeats(recent_actions)
            if repeat_count >= 2:
                status += (
                    f"\n\nWARNING: You have repeated the same action {repeat_count} "
                    "times. It is NOT working. Try a completely different "
                    "approach -- click a different position, scroll to reveal "
                    "new content, or navigate a different path."
                )

            messages.append({
                "role": "user",
                "content": self._make_observation(status, screenshot_b64),
            })
            screenshot_msg_indices.append(len(messages) - 1)

        return Trajectory(
            episode_id=episode_id,
            task=task,
            steps=steps,
            completion=list(messages),
            metadata={
                "final_url": self._page.url,
                "num_steps": len(steps),
            },
        )

    # ------------------------------------------------------------------
    # Sliding window context management
    # ------------------------------------------------------------------

    def _apply_screenshot_window(
        self,
        messages: list[dict[str, Any]],
        screenshot_indices: list[int],
    ) -> None:
        """Strip images from messages outside the sliding window.

        Keeps the most recent ``SCREENSHOT_WINDOW`` screenshots as full
        base64 images.  Older messages are converted to text-only so the
        model retains action history without the token cost of stale images.
        """
        keep = self.SCREENSHOT_WINDOW
        if len(screenshot_indices) <= keep:
            return

        to_strip = screenshot_indices[:-keep]
        for idx in to_strip:
            msg = messages[idx]
            content = msg.get("content")
            if not isinstance(content, list):
                continue
            text_parts = [
                part["text"]
                for part in content
                if isinstance(part, dict) and part.get("type") == "text"
            ]
            msg["content"] = "\n".join(text_parts) + "\n[screenshot removed]"

    # ------------------------------------------------------------------
    # Retry / loop detection
    # ------------------------------------------------------------------

    @staticmethod
    def _action_fingerprint(tool_calls: list[dict]) -> str:
        parts = []
        for tc in tool_calls:
            name = tc["function"]["name"]
            args = tc["function"].get("arguments", "{}")
            parts.append(f"{name}:{args}")
        return "|".join(parts)

    @staticmethod
    def _count_consecutive_repeats(actions: list[str]) -> int:
        if not actions:
            return 0
        last = actions[-1]
        count = 0
        for a in reversed(actions):
            if a == last:
                count += 1
            else:
                break
        return count

    # ------------------------------------------------------------------
    # Action execution — pure coordinate-based
    # ------------------------------------------------------------------

    def _execute_action(self, name: str, params: dict[str, Any]) -> tuple[bool, str]:
        """Execute an action. Returns (success, detail_message)."""
        try:
            if name == "click":
                return self._exec_click(params)
            if name == "type_text":
                return self._exec_type_text(params)
            if name == "keypress":
                return self._exec_keypress(params)
            if name == "scroll":
                return self._exec_scroll(params)
            if name == "goto":
                return self._exec_goto(params)
            if name == "wait":
                return self._exec_wait(params)
            if name == "done":
                return True, "Task complete"
            return False, f"Unknown action: {name}"
        except Exception as exc:
            return False, str(exc)

    def _exec_click(self, p: dict) -> tuple[bool, str]:
        x, y = p.get("x"), p.get("y")
        if x is None or y is None:
            return False, "click requires x and y coordinates"
        self._page.mouse.click(int(x), int(y))
        self._page.wait_for_timeout(800)
        return True, f"Clicked ({x}, {y})"

    def _exec_type_text(self, p: dict) -> tuple[bool, str]:
        text = p.get("text", "")
        press_enter = p.get("press_enter", True)
        if not text:
            return False, "No text provided"
        self._page.keyboard.type(text, delay=30)
        if press_enter:
            self._page.keyboard.press("Enter")
            self._page.wait_for_timeout(1500)
        else:
            self._page.wait_for_timeout(500)
        return True, f"Typed '{text}'" + (" + Enter" if press_enter else "")

    def _exec_keypress(self, p: dict) -> tuple[bool, str]:
        key = p.get("key", "")
        if not key:
            return False, "No key provided"
        self._page.keyboard.press(key)
        self._page.wait_for_timeout(500)
        return True, f"Pressed '{key}'"

    def _exec_scroll(self, p: dict) -> tuple[bool, str]:
        direction = p.get("direction", "down")
        amount = int(p.get("amount", 500))
        delta = amount if direction == "down" else -amount
        self._page.evaluate(f"window.scrollBy(0, {delta})")
        self._page.wait_for_timeout(400)
        return True, f"Scrolled {direction} {abs(delta)}px"

    def _exec_goto(self, p: dict) -> tuple[bool, str]:
        url = p.get("url", "")
        if not url:
            return False, "No URL provided"
        self._page.goto(url, wait_until="domcontentloaded", timeout=15_000)
        self._page.wait_for_timeout(1500)
        return True, f"Navigated to {url}"

    def _exec_wait(self, p: dict) -> tuple[bool, str]:
        ms = min(int(p.get("ms", p.get("time_ms", 1000))), 5000)
        self._page.wait_for_timeout(ms)
        return True, f"Waited {ms}ms"

    # ------------------------------------------------------------------
    # Eval context & cleanup
    # ------------------------------------------------------------------

    def _get_eval_context(self) -> dict[str, Any]:
        return {
            "url": self._page.url if self._page else None,
            "page": self._page,
        }

    def _post_episode_cleanup(self) -> None:
        if self._context:
            self._context.close()
            self._context = None
        self._page = None

    def _on_run_complete(self) -> None:
        if self._browser:
            self._browser.close()
            self._browser = None
        if self._playwright:
            self._playwright.stop()
            self._playwright = None

    def close(self) -> None:
        self._post_episode_cleanup()
        super().close()
