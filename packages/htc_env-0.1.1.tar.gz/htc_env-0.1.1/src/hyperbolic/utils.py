"""Shared utilities used across evaluators and environments."""

from __future__ import annotations


def extract_last_text(completion: list[dict]) -> str:
    """Extract text content from the last message in a completion.

    Handles both plain string content and multipart content arrays
    (e.g. messages containing image_url parts alongside text).
    """
    if not completion:
        return ""
    last = completion[-1]
    content = last.get("content")
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return " ".join(
            p.get("text", "") for p in content if p.get("type") == "text"
        )
    return str(content)


def extract_prompt_text(prompt: list[dict] | str | None) -> str:
    """Extract the user's question text from a prompt.

    Accepts a plain string, a list of chat messages (returns the first
    user message's text), or ``None``.
    """
    if prompt is None:
        return ""
    if isinstance(prompt, str):
        return prompt
    for msg in prompt:
        if msg.get("role") == "user":
            content = msg.get("content", "")
            if isinstance(content, str):
                return content
            if isinstance(content, list):
                return " ".join(
                    p.get("text", "") for p in content if p.get("type") == "text"
                )
    return ""
