"""Browser environment: navigate a custom web app and verify state.

Requires:
  - The ShopNova marketplace running on localhost:5001
    (see ../../sites/marketplace/ and ../../start_sites.sh)
  - Playwright browsers installed: htc setup

Usage:
    htc run examples/browser_task.py -m gpt-4o
"""

import re

import hyperbolic as htc


def _visited_product_page(trajectory) -> float:
    """1.0 if the agent visited a product page at any point during the episode."""
    for step in trajectory.steps:
        url = step.observation.get("url", "")
        if re.search(r"/product/\d+", url):
            return 1.0
    return 0.0


def _reached_cart(url) -> float:
    """1.0 if the final page is the cart."""
    return 1.0 if url and "/cart" in url else 0.0


def _item_in_cart(page) -> float:
    """1.0 if 'Wireless Noise-Canceling Headphones' appears on the cart page."""
    if page is None:
        return 0.0
    try:
        url = page.url
        if "/cart" not in url:
            return 0.0
        html = page.content()
        if "Wireless Noise-Canceling Headphones" in html:
            return 1.0
    except Exception:
        pass
    return 0.0


def load_environment():
    dataset = htc.Dataset.from_list([
        {
            "task": (
                "You are on ShopNova, an online marketplace. Find the "
                "'Wireless Noise-Canceling Headphones' product and add it "
                "to your cart. Then navigate to the cart page to verify "
                "it was added."
            ),
            "start_url": "http://localhost:5001",
            "reset_url": "http://localhost:5001/api/reset",
        },
    ])

    rubric = htc.Rubric()
    rubric.add(_visited_product_page, weight=0.2, dimension="found_product")
    rubric.add(_reached_cart, weight=0.3, dimension="reached_cart")
    rubric.add(_item_in_cart, weight=0.5, dimension="item_in_cart")

    return htc.BrowserEnv(
        dataset=dataset,
        rubric=rubric,
        max_turns=15,
        browser_config=htc.BrowserConfig(headless=False, slow_mo=300),
        output_dir="./runs",
    )


if __name__ == "__main__":
    env = load_environment()
    agent = htc.OpenAIAgent(
        model="gpt-4o",
        tool_choice="required",
        max_tokens=512,
    )

    try:
        trajectories = env.run(agent)
        for t in trajectories:
            print(f"  Reward: {t.scalar_reward:.2f}  Dims: {t.assessment.dimensions}")
    finally:
        env.close()
