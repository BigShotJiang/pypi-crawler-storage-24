"""Minimal text environment: single-turn math Q&A with exact-match scoring.

Usage:
    htc run examples/simple_math.py -m gpt-4o-mini
"""

import hyperbolic as htc


def correct_answer(completion, answer):
    """1.0 if the expected answer appears anywhere in the response."""
    response = completion[-1]["content"]
    return 1.0 if answer in response else 0.0


def load_environment():
    dataset = htc.Dataset.from_list([
        {"question": "What is 2+2?", "answer": "4"},
        {"question": "What is 7*8?", "answer": "56"},
        {"question": "What is 100/4?", "answer": "25"},
    ])

    rubric = htc.Rubric(funcs=[correct_answer])

    return htc.SingleTurnEnv(
        dataset=dataset,
        rubric=rubric,
        system_prompt="You are a math tutor. Answer with just the number, nothing else.",
    )


if __name__ == "__main__":
    env = load_environment()
    agent = htc.OpenAIAgent(model="gpt-4o-mini")
    trajectories = env.run(agent)

    for t in trajectories:
        print(f"  {t.task['question']} -> reward={t.scalar_reward:.1f}")
