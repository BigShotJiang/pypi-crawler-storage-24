"""Browser environment: interact with the Chirper social media app.

Tasks involve composing posts, liking content, and navigating profiles
on the Twitter-like clone.

Requires:
  - The Chirper social app running on localhost:5002
  - Playwright browsers installed: htc setup

Usage:
    htc run examples/browser_social.py -m gpt-4o
"""

import hyperbolic as htc


def _check_task_completion(url: str | None = None, page=None) -> float:
    """Heuristic evaluator that checks the final page state."""
    if page is None or url is None:
        return 0.0

    try:
        html = page.content()

        if "Hello from the RL agent" in html:
            return 1.0

        if "/profile/wanderlust_mike" in url:
            return 1.0

        pink_hearts = page.query_selector_all("button.text-pink-500")
        if pink_hearts:
            return 1.0
    except Exception:
        pass

    if "/explore" in url or "/profile/" in url or "/compose" in url:
        return 0.5

    return 0.0


def load_environment():
    dataset = htc.Dataset.from_list([
        {
            "task": (
                "You are on Chirper, a social media site. Navigate to the "
                "Compose page and write a new post that says "
                "'Hello from the RL agent!' then submit it."
            ),
            "start_url": "http://localhost:5002",
            "reset_url": "http://localhost:5002/api/reset",
        },
        {
            "task": (
                "You are on Chirper, a social media site. Find the post by "
                "@techguru and like it by clicking the heart/like button."
            ),
            "start_url": "http://localhost:5002",
            "reset_url": "http://localhost:5002/api/reset",
        },
        {
            "task": (
                "You are on Chirper, a social media site. Navigate to the "
                "Explore page to browse users, then click on "
                "@wanderlust_mike's profile."
            ),
            "start_url": "http://localhost:5002",
            "reset_url": "http://localhost:5002/api/reset",
        },
    ])

    rubric = htc.Rubric()
    rubric.add(_check_task_completion, weight=1.0, dimension="task_done")

    return htc.BrowserEnv(
        dataset=dataset,
        rubric=rubric,
        max_turns=10,
        browser_config=htc.BrowserConfig(headless=False, slow_mo=300),
        output_dir="./runs",
    )


if __name__ == "__main__":
    env = load_environment()
    agent = htc.OpenAIAgent(model="gpt-4o", tool_choice="required", max_tokens=512)
    try:
        for t in env.run(agent):
            print(f"  Reward: {t.scalar_reward:.2f}")
    finally:
        env.close()
