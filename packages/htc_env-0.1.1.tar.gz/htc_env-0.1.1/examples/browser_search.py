"""Browser environment: search for a product on ShopNova.

A simpler task than add-to-cart -- just navigate to the correct product page
using the search bar.

Requires:
  - The ShopNova marketplace running on localhost:5001
  - Playwright browsers installed: htc setup

Usage:
    htc run examples/browser_search.py -m gpt-4o
"""

import hyperbolic as htc


def load_environment():
    dataset = htc.Dataset.from_list([
        {
            "task": (
                "You are on ShopNova. Use the search bar at the top of the "
                "page to search for 'yoga mat', then click on the "
                "'Premium Yoga Mat' product to view its details."
            ),
            "start_url": "http://localhost:5001",
            "reset_url": "http://localhost:5001/api/reset",
        },
        {
            "task": (
                "You are on ShopNova. Use the search bar to search for "
                "'coffee', then click on the 'Ceramic Pour-Over Coffee Set' "
                "product to view its details."
            ),
            "start_url": "http://localhost:5001",
            "reset_url": "http://localhost:5001/api/reset",
        },
    ])

    rubric = htc.Rubric()
    rubric.add(
        htc.URLMatch(pattern=r".*localhost:5001/product/\d+"),
        weight=1.0,
        dimension="found_product",
    )

    return htc.BrowserEnv(
        dataset=dataset,
        rubric=rubric,
        max_turns=8,
        browser_config=htc.BrowserConfig(headless=False, slow_mo=300),
        output_dir="./runs",
    )


if __name__ == "__main__":
    env = load_environment()
    agent = htc.OpenAIAgent(model="gpt-4o", tool_choice="required", max_tokens=512)
    try:
        for t in env.run(agent):
            print(f"  Reward: {t.scalar_reward:.2f}")
    finally:
        env.close()
