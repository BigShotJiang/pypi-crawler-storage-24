"""Subjective evaluation: multi-judge panel with disagreement tracking.

Demonstrates multi-dimensional scoring using a panel of LLM judges, with
per-dimension metadata and agreement metrics preserved in the trajectory.

Usage:
    htc run examples/subjective_eval.py -m gpt-4o-mini
"""

import hyperbolic as htc


def length_check(completion):
    """Heuristic: prefer responses between 50 and 300 characters."""
    text = completion[-1]["content"]
    if 50 < len(text) < 300:
        return 1.0
    return 0.5


def load_environment():
    dataset = htc.Dataset.from_list([
        {
            "question": (
                "Write a professional but warm email rejecting a job applicant. "
                "Keep it under 200 words."
            ),
            "info": {"context": "job_application", "company": "Acme Corp"},
        },
        {
            "question": (
                "Write a one-paragraph product description for a premium "
                "wireless keyboard that feels both technical and luxurious."
            ),
            "info": {"context": "product_copy", "brand": "Artisan Tech"},
        },
    ])

    rubric = htc.Rubric()

    rubric.add(length_check, weight=0.1, dimension="format")

    tone_panel = htc.JudgePanel(
        judges=["gpt-4o-mini", "gpt-4o-mini"],
        prompt=(
            "Rate the TONE of this response from 0.0 to 1.0.\n\n"
            "Task:\n```\n{prompt}\n```\n\n"
            "Response:\n```\n{response}\n```\n\n"
            "{answer_section}\n"
            "A score of 1.0 means the tone perfectly matches what was asked for "
            "(professional, warm, luxurious, technical -- whatever the task requires). "
            "Respond with ONLY a number."
        ),
        aggregation="median",
    )
    rubric.add(tone_panel, weight=0.5, dimension="tone")

    helpfulness_judge = htc.LLMJudge(
        model="gpt-4o-mini",
        prompt=(
            "Rate how HELPFUL and COMPLETE this response is from 0.0 to 1.0.\n\n"
            "Task:\n```\n{prompt}\n```\n\n"
            "Response:\n```\n{response}\n```\n\n"
            "{answer_section}\n"
            "Respond with ONLY a number."
        ),
    )
    rubric.add(helpfulness_judge, weight=0.4, dimension="helpfulness")

    return htc.SingleTurnEnv(
        dataset=dataset,
        rubric=rubric,
        system_prompt="You are a professional writer. Follow the instructions precisely.",
    )


if __name__ == "__main__":
    env = load_environment()
    agent = htc.OpenAIAgent(model="gpt-4o-mini")
    trajectories = env.run(agent)

    for t in trajectories:
        print(f"\n  Task: {t.task['question'][:60]}...")
        print(f"  Scalar reward: {t.scalar_reward:.3f}")
        if t.assessment:
            print(f"  Dimensions: {t.assessment.dimensions}")
            if t.assessment.metadata:
                print(f"  Metadata: {t.assessment.metadata}")
