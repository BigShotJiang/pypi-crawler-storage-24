"""Browser environment: navigate to specific pages on ShopNova.

The simplest possible browser task -- click category links and navigate
to specific pages. Great for verifying the CUA pipeline works end-to-end.

Requires:
  - The ShopNova marketplace running on localhost:5001
  - Playwright browsers installed: htc setup

Usage:
    htc run examples/browser_navigate.py -m gpt-4o
"""

import hyperbolic as htc


def load_environment():
    dataset = htc.Dataset.from_list([
        {
            "task": (
                "You are on ShopNova. Click on the 'Electronics' category "
                "filter to browse electronics products."
            ),
            "start_url": "http://localhost:5001",
            "reset_url": "http://localhost:5001/api/reset",
        },
        {
            "task": (
                "You are on ShopNova. Navigate to the shopping cart page "
                "by clicking the Cart link in the top-right corner."
            ),
            "start_url": "http://localhost:5001",
            "reset_url": "http://localhost:5001/api/reset",
        },
    ])

    rubric = htc.Rubric()
    rubric.add(
        htc.URLMatch(pattern=r".*localhost:5001/(category|cart|search).*"),
        weight=1.0,
        dimension="navigation",
    )

    return htc.BrowserEnv(
        dataset=dataset,
        rubric=rubric,
        max_turns=5,
        browser_config=htc.BrowserConfig(headless=False, slow_mo=300),
        output_dir="./runs",
    )


if __name__ == "__main__":
    env = load_environment()
    agent = htc.OpenAIAgent(model="gpt-4o", tool_choice="required", max_tokens=512)
    try:
        for t in env.run(agent):
            print(f"  Reward: {t.scalar_reward:.2f}")
    finally:
        env.close()
