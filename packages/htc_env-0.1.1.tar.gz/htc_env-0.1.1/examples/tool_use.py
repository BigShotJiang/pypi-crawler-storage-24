"""Tool-calling environment: model uses a calculator and dictionary.

Usage:
    htc run examples/tool_use.py -m gpt-4o-mini
"""

import hyperbolic as htc


def calculate(expression: str) -> str:
    """Evaluate a mathematical expression and return the result.

    Args:
        expression: A Python math expression (e.g. "2 + 2 * 3").

    Returns:
        The numeric result as a string.
    """
    try:
        result = eval(expression, {"__builtins__": {}})
        return str(result)
    except Exception as e:
        return f"Error: {e}"


def lookup(term: str) -> str:
    """Look up the definition of a term.

    Args:
        term: The term to look up.

    Returns:
        A short definition.
    """
    definitions = {
        "python": "A high-level programming language created by Guido van Rossum.",
        "gymnasium": "A Python library providing a standard API for RL environments.",
        "playwright": "A browser automation framework by Microsoft.",
    }
    return definitions.get(term.lower(), f"No definition found for '{term}'.")


def correct_answer(completion, answer):
    response = completion[-1]["content"]
    return 1.0 if answer.lower() in response.lower() else 0.0


def load_environment():
    dataset = htc.Dataset.from_list([
        {
            "question": "What is 17 * 23? Use the calculator tool.",
            "answer": "391",
        },
        {
            "question": "What is Python? Use the lookup tool, then summarize in one sentence.",
            "answer": "programming language",
        },
    ])

    rubric = htc.Rubric(funcs=[correct_answer])

    return htc.ToolEnv(
        dataset=dataset,
        rubric=rubric,
        tools=[calculate, lookup],
        system_prompt="Use the provided tools to answer questions. Give a final answer in plain text.",
        max_turns=5,
    )


if __name__ == "__main__":
    env = load_environment()
    agent = htc.OpenAIAgent(model="gpt-4o-mini")
    trajectories = env.run(agent)

    for t in trajectories:
        print(f"  {t.task['question'][:50]}... -> reward={t.scalar_reward:.1f}")
