# Architecture

This document explains every component of the `hyperbolic` library, how the classes relate to each other, and the data flow from task definition to training-ready output. It also covers the key design decisions and the reasoning behind them.

## Project Layout

```
rl_env/
├── pyproject.toml              # Package config (uv / PEP 621)
├── .env.example                # API key template
├── examples/
│   ├── simple_math.py          # Single-turn text Q&A
│   ├── tool_use.py             # Multi-turn with tool calling
│   ├── subjective_eval.py      # LLM judge panel + multi-dim scoring
│   ├── browser_navigate.py     # Click category links
│   ├── browser_search.py       # Search bar + type + navigate
│   ├── browser_task.py         # Multi-step: find → add to cart → verify
│   └── browser_social.py       # Social media interactions
├── docs/                       # Documentation (you are here)
└── src/hyperbolic/
    ├── __init__.py             # Public API surface
    ├── types.py                # Core data structures
    ├── utils.py                # Shared text extraction helpers
    ├── config.py               # API key resolution (layered: explicit > .env > env var)
    ├── dataset.py              # Task data loading
    ├── rubric.py               # Multi-dimensional evaluation engine
    ├── env_base.py             # Abstract base environment
    ├── trajectory.py           # Persistence & export
    ├── cli.py                  # Command-line interface
    ├── agents/
    │   ├── base.py             # AgentBase protocol
    │   └── openai.py           # OpenAI-compatible adapter
    ├── envs/
    │   ├── text.py             # TextEnv, SingleTurnEnv, ToolEnv
    │   └── browser.py          # BrowserEnv (Playwright CUA)
    └── evaluators/
        ├── deterministic.py    # Rule-based scorers (ExactMatch, URLMatch, etc.)
        └── probabilistic.py    # LLM judge & judge panel
```

## Data Flow

Here's how data moves through the system during a run:

```
                          ┌─────────────────┐
                          │    Dataset       │
                          │  (list of tasks) │
                          └────────┬────────┘
                                   │ iterates
                                   ▼
┌──────────┐    act()     ┌─────────────────┐   _run_episode()    ┌────────────┐
│  Agent   │◄────────────▶│    EnvBase       │──────────────────▶  │  Trajectory │
│(OpenAI,  │  messages +  │  (TextEnv or     │   steps, messages  │  (steps,    │
│ custom)  │  tool calls  │   BrowserEnv)    │                    │   completion│
└──────────┘              └────────┬────────┘                    │   metadata) │
                                   │ evaluate()                   └──────┬─────┘
                                   ▼                                     │
                          ┌─────────────────┐                            │
                          │     Rubric       │                            │
                          │ (evaluators with │                            │
                          │  weights/dims)   │                            │
                          └────────┬────────┘                            │
                                   │                                     │
                                   ▼                                     │
                          ┌─────────────────┐    attached to             │
                          │   Assessment    │◄───────────────────────────┘
                          │ (dimensions,    │
                          │  scalar, meta)  │
                          └────────┬────────┘
                                   │
                                   ▼
                          ┌─────────────────┐
                          │TrajectoryLogger  │──▶ disk (JSON + screenshots)
                          └─────────────────┘
```

1. **Dataset** holds task dicts → **EnvBase** iterates over them
2. For each task, **EnvBase** calls `_run_episode()` which loops: observation → **Agent** `.act()` → action → execute
3. The episode produces a **Trajectory** (ordered steps + full message history)
4. **Rubric** evaluates the trajectory → produces an **Assessment** (per-dimension scores + scalar)
5. The Assessment is attached to the Trajectory
6. **TrajectoryLogger** persists everything to disk

## Core Data Types (`types.py`)

These dataclasses are the currency of the library — every other component produces or consumes them.

### `EvalResult`

```python
@dataclass
class EvalResult:
    score: float                           # 0.0 to 1.0
    metadata: dict[str, Any] = {}          # extra info (judge scores, agreement, etc.)
```

Returned by evaluators that need to pass metadata alongside a score (e.g., `JudgePanel` returns agreement metrics). Simple evaluators can just return a `float` instead.

### `Assessment`

```python
@dataclass
class Assessment:
    dimensions: dict[str, float] = {}      # e.g. {"accuracy": 1.0, "tone": 0.72}
    scalar: float = 0.0                    # weighted average for GRPO/PPO
    metadata: dict[str, Any] = {}          # per-dimension details
```

The output of `Rubric.evaluate()`. Preserves the full multi-dimensional picture while providing a scalar collapse for training compatibility. The `scalar` is computed as the weighted average of all non-zero-weight dimensions.

### `Step`

```python
@dataclass
class Step:
    step_num: int                          # 0-indexed turn number
    observation: dict[str, Any] = {}       # what the env showed (URL, screenshot_bytes, etc.)
    action: dict[str, Any] | None = None   # what the agent did (content, tool_calls)
    timestamp: str = ""                    # ISO 8601
    metadata: dict[str, Any] = {}
```

One turn within an episode. For browser envs, `observation` includes `screenshot_bytes` (saved as separate PNGs by the logger, stripped from JSON).

### `Trajectory`

```python
@dataclass
class Trajectory:
    episode_id: str = ""
    task: dict[str, Any] = {}              # the original task from the dataset
    steps: list[Step] = []                 # ordered turn-by-turn record
    completion: list[dict[str, Any]] = []  # full OpenAI-format message history
    assessment: Assessment | None = None   # attached after evaluation
    metadata: dict[str, Any] = {}          # episode-level info (model, timing, etc.)
```

The complete record of one episode. The `scalar_reward` property is a convenience accessor:

```python
trajectory.scalar_reward  # returns assessment.scalar, or 0.0 if no assessment
```

## Dataset (`dataset.py`)

A thin wrapper around a list of task dicts with factory methods for common data sources.

```python
# From a Python list
dataset = htc.Dataset.from_list([{"question": "...", "answer": "..."}])

# From a local file (.json, .jsonl, .csv)
dataset = htc.Dataset.from_file("tasks.jsonl")

# From HuggingFace (requires `datasets` extra)
dataset = htc.Dataset.from_hf("gsm8k", split="test", n=50)

# Shorthand for HuggingFace — pass a string directly as the dataset parameter
env = htc.TextEnv(dataset="openai/gsm8k:test:50", rubric=rubric)

# Subset selection
subset = dataset.select(range(10))     # first 10 tasks
subset = dataset.select([0, 5, 12])    # specific indices
```

Implements Python's sequence protocol — `len(dataset)`, `dataset[0]`, `for task in dataset` all work.

### Task Dict Format

Text environments look for:

| Key | Type | Used by |
|-----|------|---------|
| `question` | `str` | Wrapped into a user message |
| `prompt` | `str` or `list[dict]` | Used directly as the conversation start |
| `answer` | `str` | Passed to evaluators for ground-truth comparison |
| `info` | `dict` or JSON `str` | Extra metadata available to evaluators |

Browser environments look for:

| Key | Type | Purpose |
|-----|------|---------|
| `task` or `description` | `str` | The task instruction shown to the agent |
| `start_url` | `str` | URL to navigate to at episode start |
| `reset_url` | `str` | URL to POST to for deterministic state reset |

## Agents (`agents/`)

### `AgentBase` (Protocol)

The minimal interface every agent must satisfy:

```python
class AgentBase(Protocol):
    def act(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]: ...
```

- **Input**: OpenAI-format message list + optional tool schemas
- **Output**: An assistant message dict: `{"role": "assistant", "content": "...", "tool_calls": [...]}`

Uses `@runtime_checkable`, so `isinstance(my_agent, AgentBase)` works.

### `OpenAIAgent`

The built-in adapter for any OpenAI-compatible API:

```python
agent = htc.OpenAIAgent(
    model="gpt-4o",
    api_key=None,           # falls back to .env → OPENAI_API_KEY env var
    base_url=None,          # override for vLLM, Together, Ollama, etc.
    max_tokens=1024,
    temperature=None,       # None = let the API use its default
    tool_choice=None,       # "auto", "required", "none", or None (API decides)
)
```

Works with GPT-4o, GPT-4o-mini, vLLM, Together AI, Ollama, or any provider that implements the OpenAI chat completions API.

The agent is **stateless** — each `act()` call sends the complete message history and receives one response. Multi-turn memory is simulated by the environment appending to the message list.

### Model ID shorthand

The `model` parameter accepts `"provider/model"` strings. The provider prefix is stripped:

```python
agent = htc.OpenAIAgent(model="openai/gpt-4o")   # → model="gpt-4o"
agent = htc.OpenAIAgent(model="gpt-4o")           # same
```

### Writing a Custom Agent

Any object with an `act()` method works:

```python
class MyAgent:
    def act(self, messages, tools=None):
        # your logic here
        return {"role": "assistant", "content": "my response"}
```

No need to inherit from anything — Python's structural typing (the Protocol) handles it.

## Evaluators (`evaluators/`)

Evaluators are callables that score a trajectory. They declare what data they need via argument names — the Rubric inspects the signature and injects matching values automatically.

### Deterministic Evaluators

| Class | What it checks | Key arguments |
|-------|---------------|---------------|
| `ExactMatch` | Response exactly equals expected answer | `completion`, `answer` |
| `RegexMatch` | Regex matches the response | `completion`, `answer` |
| `MathVerify` | `\boxed{}` math equivalence | `completion`, `answer` |
| `URLMatch` | Browser URL matches a pattern | `url` |
| `ElementCheck` | CSS selector exists on the page DOM | `page` |
| `HeuristicScorer` | Length, keyword, and format checks | `completion` |

### Probabilistic Evaluators

| Class | What it does | Returns |
|-------|-------------|---------|
| `LLMJudge` | Sends the response to an LLM for scoring | `float` |
| `JudgePanel` | Multiple LLM judges with aggregation | `EvalResult` (score + agreement metadata) |

### How Signature Injection Works

When you write an evaluator, just name your arguments after the context values you need:

```python
# Text evaluator — auto-receives `completion` and `answer`
def my_scorer(completion, answer):
    return 1.0 if answer in completion[-1]["content"] else 0.0

# Browser evaluator — auto-receives `url`
def url_check(url):
    return 1.0 if "/success" in url else 0.0

# Trajectory evaluator — auto-receives the full trajectory
def step_counter(trajectory):
    return min(len(trajectory.steps) / 10, 1.0)

# DOM evaluator — auto-receives the live Playwright page
def page_check(page):
    return 1.0 if page.query_selector(".success") else 0.0
```

Available context keys:

| Key | Type | Source |
|-----|------|--------|
| `completion` | `list[dict]` | Full message history |
| `prompt` | `list[dict]` | Messages before the first assistant reply |
| `answer` | `str \| None` | From the task dict |
| `info` | `dict` | From the task dict (auto-parsed if JSON string) |
| `task` | `dict` | The entire task dict |
| `trajectory` | `Trajectory` | The full trajectory object |
| `url` | `str` | Current browser URL (BrowserEnv only) |
| `page` | Playwright Page | Live page object (BrowserEnv only) |

## Rubric (`rubric.py`)

The Rubric is the evaluation engine. It combines multiple evaluators into a multi-dimensional scoring pipeline.

```python
rubric = htc.Rubric()

# Weighted evaluator — contributes to scalar reward
rubric.add(htc.ExactMatch(), weight=1.0, dimension="accuracy")

# Zero-weight metric — tracked but doesn't affect reward
rubric.add_metric(my_length_check, dimension="length")
```

When `rubric.evaluate()` is called, it:

1. Builds a context dict from the trajectory + task + environment state
2. Calls each evaluator, injecting matching context values
3. Collects per-dimension scores
4. Computes the weighted scalar average (only non-zero weights)
5. Returns an `Assessment` with everything preserved

The shorthand constructor works too:

```python
rubric = htc.Rubric(
    funcs=[exact_match, length_check],
    weights=[1.0, 0.5],
)
```

## Environments

### `EnvBase` (Abstract Base)

All environments inherit from `EnvBase`, which handles:

- Iterating over tasks in the dataset
- Running multiple rollouts per task
- Calling the rubric after each episode
- Logging trajectories to disk
- CLI output formatting

Subclasses implement one method:

```python
def _run_episode(self, agent, task, episode_id) -> Trajectory:
    # Your world-specific interaction loop
    ...
```

And can optionally override:

| Hook | When it's called | Use case |
|------|-----------------|----------|
| `_get_eval_context()` | After episode, before cleanup | Return live browser state for evaluators |
| `_post_episode_cleanup()` | After evaluation | Close per-episode resources |
| `_on_run_complete()` | After all episodes | Close shared resources |

### `TextEnv` / `SingleTurnEnv` / `ToolEnv`

See [Text Environments](text-environments.md) for the full guide.

### `BrowserEnv`

See [Browser Environments](browser-environments.md) for the full guide.

Key architectural decisions in `BrowserEnv`:

| Decision | Rationale |
|----------|-----------|
| **Pure coordinate CUA** | Agent sees screenshots, clicks with `(x,y)`. No CSS selectors in tools. Aligns with verifiers and modern CUA models. |
| **Text-only tool responses** | OpenAI API doesn't support images in `tool` messages. Tool responses are text status; screenshots go in `user` messages. |
| **Sliding window (2 screenshots)** | Keeps token cost manageable. Older screenshots become text summaries. Matches verifiers' default. |
| **No `image_detail` parameter** | Let OpenAI default to `"auto"`. At 1024x768, the API tiles at high detail anyway. |
| **Retry enforcement** | After 2 identical consecutive actions, a warning is injected. Prevents infinite loops without replacing model intelligence. |
| **Evaluators use DOM, agent doesn't** | The agent browses by pixels (CUA contract). Evaluators can query the live DOM to verify outcomes. These are independent concerns. |

## API Key Resolution (`config.py`)

API keys are resolved through a three-tier chain (highest priority first):

1. **Explicit parameter** — `OpenAIAgent(api_key="sk-...")`
2. **`.env` file** — auto-loaded from the project root via `python-dotenv`
3. **System environment variable** — `export OPENAI_API_KEY=sk-...`

The `.env` file is loaded once on import. The `resolve_api_key()` function handles the fallback chain and is used by both `OpenAIAgent` and `LLMJudge`.

## Trajectory Logger (`trajectory.py`)

Handles saving and exporting trajectory data.

### Saving to Disk

```python
env = htc.SingleTurnEnv(dataset=dataset, rubric=rubric, output_dir="./runs")
```

Creates a timestamped run directory with per-episode subdirectories:

```
runs/
└── 2026-03-04_15-16-25_simple_math/
    ├── task_1_rollout_1/
    │   └── trajectory.json
    ├── task_2_rollout_1/
    │   └── trajectory.json
    └── task_3_rollout_1/
        └── trajectory.json
```

Browser episodes additionally include screenshots:

```
task_1_rollout_1/
├── trajectory.json
└── screenshots/
    ├── 000.png
    ├── 001.png
    └── ...
```

### Exporting for Training

```python
# Scalar format for GRPO / PPO
scalar_data = htc.TrajectoryLogger.export_scalar(trajectories)
# [{"episode_id": "...", "task": {...}, "reward": 0.85}, ...]

# Full assessment format for analysis
assessment_data = htc.TrajectoryLogger.export_assessments(trajectories)
# [{"episode_id": "...", "task": {...}, "assessment": {"dimensions": ..., "scalar": ...}}, ...]

# Batch save to file
htc.TrajectoryLogger.save_batch(trajectories, "output.jsonl", fmt="jsonl")
```

## CLI (`cli.py`)

The `htc run` command loads an environment from a Python file, creates an agent, runs episodes, and prints a summary.

```bash
uv run htc run my_env.py -m gpt-4o-mini -r 3 -o ./runs
```

The Python file must export a `load_environment()` function that returns an environment instance. The CLI handles agent creation, output directory setup, and summary statistics.

For browser environments, the CLI automatically sets `tool_choice="required"` to prevent the model from responding without making a tool call (which would prematurely end the episode).

See [Getting Started](getting-started.md) for the full CLI flag reference.

## Design Decisions Log

This section captures the reasoning behind key architectural choices made during development.

### Why no CSS selectors in browser tools?

CUA models (GPT-4o, computer-use-preview, Claude computer use) are trained to reason from pixels, not HTML. When we gave GPT-4o CSS selectors, it invented plausible-looking selectors that didn't exist, leading to silent failures. We removed selectors and went to pure `click(x,y)` coordinates. This is the same approach `verifiers` uses.

### Why separate tool responses and user messages?

We initially tried embedding screenshots in `tool` messages (following `verifiers`' approach conceptually). The OpenAI API returned `BadRequestError` — image URLs are only allowed in `user` messages. So tool responses are text-only status messages, and the screenshot follows as a `user` message.

### Why a sliding window instead of full history?

Sending all screenshots grows linearly with episode length. At 10 steps with 1024x768 screenshots, the context window fills up quickly and cost becomes prohibitive. We keep the 2 most recent screenshots as images and convert older ones to text summaries. This matches `verifiers`' default window of 2.

### Why evaluators can access DOM but the agent can't?

These are separate concerns. The agent follows the CUA contract (pixels in, coordinates out). The evaluator needs to verify whether actions had the intended effect, and the most reliable way to do that is to query the actual DOM (e.g., "is the product name in the cart?"). This is like a grader checking the answer sheet while the student only sees the exam paper.

### Why `tool_choice="required"` for browser envs?

Without this setting, GPT-4o sometimes responds with text content instead of making a tool call. In a browser environment, there's nothing useful the agent can do with text — it needs to take actions. Setting `tool_choice="required"` prevents premature episode termination.
