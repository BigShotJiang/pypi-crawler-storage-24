# Browser Environments

`BrowserEnv` lets an agent interact with real web pages through Playwright following the standard **CUA (Computer Use Agent) contract**: the agent sees screenshots and responds with coordinate-based actions. No DOM access, no CSS selectors — the model reasons from pixels only, like a real user looking at a screen.

This design aligns with how modern CUA models (OpenAI's `computer-use-preview`, Anthropic's `claude-computer-use`) are built and evaluated. Libraries like Prime Intellect's `verifiers` use the same contract.

## Prerequisites

1. Install the browser extra:

```bash
uv sync --extra browser
```

2. Install the Chromium browser binary:

```bash
playwright install chromium
```

3. If you're testing against a local web app, make sure it's running before you start the environment.

---

## Quick Start

```python
import hyperbolic as htc

dataset = htc.Dataset.from_list([
    {
        "task": "Search for 'headphones' and click on the first result.",
        "start_url": "http://localhost:5001",
    },
])

rubric = htc.Rubric()
rubric.add(htc.URLMatch(pattern=r"/product/"), weight=1.0, dimension="navigation")

env = htc.BrowserEnv(
    dataset=dataset,
    rubric=rubric,
    max_turns=8,
    browser_config=htc.BrowserConfig(headless=False),
    output_dir="./runs",
)

agent = htc.OpenAIAgent(model="gpt-4o", tool_choice="required")

try:
    trajectories = env.run(agent)
finally:
    env.close()
```

---

## BrowserConfig

Control how Playwright launches and captures the browser:

```python
config = htc.BrowserConfig(
    headless=True,          # False to watch the browser visually
    slow_mo=0,              # ms delay between actions (useful for debugging)
    viewport=(1024, 768),   # browser window size in pixels
)
```

| Parameter | Default | Notes |
|-----------|---------|-------|
| `headless` | `True` | Set to `False` during development to watch the agent |
| `slow_mo` | `0` | Slows down every Playwright action for visual debugging |
| `viewport` | `(1024, 768)` | Standard CUA viewport. Matches verifiers' default. |

**Why no `image_detail` setting?** We don't set OpenAI's `image_detail` parameter on screenshots, letting the API default to `"auto"`. At 1024x768, the API will typically tile the image at high detail, which gives the model the best chance at accurate coordinate estimation. This matches how `verifiers` handles it — no explicit detail override.

---

## The CUA Contract

Our browser environment follows the standard CUA contract used by modern CUA models and evaluation frameworks:

| Principle | Implementation |
|-----------|---------------|
| **Pixels in, actions out** | Agent sees screenshots, responds with x,y coordinates |
| **No DOM access** | The model has no access to HTML, CSS selectors, or the accessibility tree |
| **Coordinate-based clicking** | `click(x, y)` is the only click mechanism |
| **Status feedback** | Every tool response includes `Status: Success/Failed`, current URL, and viewport dimensions |
| **Sliding window context** | Only the 2 most recent screenshots are sent as images; older ones are converted to text summaries |

### Why pure coordinates?

Early iterations of this library included CSS selectors in the tool set. We removed them after discovering that:

1. **CUA models aren't trained for CSS selectors.** GPT-4o and similar models reason from pixels. When given CSS selectors, they invent plausible-looking selectors that don't exist on the page, leading to silent failures.
2. **`verifiers` uses the same approach.** Their CUA mode provides only `click(x, y)` — no selectors at all.
3. **Honest feedback matters.** With coordinates, the click either hits the element or it doesn't. With CSS selectors, JS fallbacks could silently click nothing and report success, misleading the model.

---

## Task Dict Format

Browser tasks use these fields:

| Field | Required | Description |
|-------|----------|-------------|
| `task` | yes | The instruction given to the agent (can also use `description` or `question`) |
| `start_url` | yes | URL to navigate to at the start of the episode |
| `reset_url` | no | URL to POST to before each episode for deterministic resets |
| `answer` | no | Expected answer for evaluators that need ground truth |

### Example task dicts

```python
# Simple navigation
{
    "task": "Click on the Electronics category.",
    "start_url": "http://localhost:5001",
}

# Multi-step task with reset
{
    "task": "Find the 'Wireless Headphones' and add them to your cart.",
    "start_url": "http://localhost:5001",
    "reset_url": "http://localhost:5001/api/reset",
}
```

---

## Episode Flow

Here's what happens during each browser episode:

1. **Browser context**: A fresh Playwright browser context is created (clean cookies, storage, etc.)

2. **Deterministic reset**: If the task has a `reset_url`, the environment sends a POST request to reset server-side state (e.g., clear cart, reset database). This is essential for reproducible RL.

3. **Navigation**: The browser navigates to `start_url` and waits for the page to load.

4. **Initial observation**: A screenshot is taken and sent to the agent as a `user` message with the task description, current URL, and viewport dimensions.

5. **Agent loop** (repeats up to `max_turns`):
   - The agent sees the observation and responds with a tool call
   - The environment executes the action and sends a text-only `tool` response with `Status: Success/Failed`, URL, and viewport
   - A post-action screenshot is taken and sent as a `user` message with the updated status
   - Before each agent call, the **sliding window** strips images from older messages — only the 2 most recent screenshots are kept as images; older ones become text summaries
   - If the agent calls `done()` or responds without a tool call, the episode ends

6. **Retry enforcement**: If the agent repeats the exact same action 2+ times consecutively, a warning is injected telling it to try a different approach.

7. **Evaluation**: The rubric scores the trajectory using the live browser state (URL, page DOM, trajectory history)

8. **Cleanup**: The browser context is closed; the browser itself stays open for the next episode

---

## Available Browser Tools

The agent has access to these tools, defined as OpenAI function-calling schemas:

### `click(x, y)`

Click at pixel coordinates on the page. The model identifies elements visually from the screenshot and clicks their position.

```json
{"name": "click", "arguments": {"x": 450, "y": 320}}
```

Both `x` and `y` are required integers. Coordinates are relative to the viewport (0,0 is top-left).

### `type_text(text, press_enter?)`

Type text into the currently focused element. The model should `click()` on an input field first to focus it, then call `type_text`.

```json
{"name": "type_text", "arguments": {"text": "yoga mat"}}
{"name": "type_text", "arguments": {"text": "user@example.com", "press_enter": false}}
```

`press_enter` defaults to `true` — useful for search bars where typing + Enter triggers the search.

### `keypress(key)`

Press a single keyboard key. Useful for Enter, Tab, Escape, Backspace, etc.

```json
{"name": "keypress", "arguments": {"key": "Enter"}}
{"name": "keypress", "arguments": {"key": "Escape"}}
```

### `scroll(direction, amount?)`

Scroll the page to reveal content above or below the fold.

```json
{"name": "scroll", "arguments": {"direction": "down", "amount": 500}}
```

### `goto(url)`

Navigate to a URL. The agent should only use this for URLs it can see on the page — not guessed URLs.

```json
{"name": "goto", "arguments": {"url": "http://localhost:5001/products"}}
```

### `wait(ms?)`

Wait for the page to load or settle. Capped at 5000ms.

```json
{"name": "wait", "arguments": {"ms": 2000}}
```

### `done(summary?)`

Signal task completion. The agent should call this when it believes the task is finished.

```json
{"name": "done", "arguments": {"summary": "Added headphones to cart and navigated to cart page."}}
```

---

## Tool Response Format

Every tool response includes structured status information:

```
Status: Success
URL: http://localhost:5001/product/1
Viewport: 1024x768
```

If an action fails:

```
Status: Failed
Error: click requires x and y coordinates
URL: http://localhost:5001/
Viewport: 1024x768
```

This format gives the model consistent, machine-readable feedback about what happened after each action.

---

## Sliding Window Context Management

To keep token costs manageable and the model focused on the current state, only the **2 most recent screenshots** are kept as full images in the conversation. Older screenshot messages are converted to text-only summaries:

```
Status: Success
URL: http://localhost:5001/category/Electronics
Viewport: 1024x768
[screenshot removed]
```

This matches `verifiers`' approach (they default to a window of 2 recent screenshots).

The window size is configurable via `BrowserEnv.SCREENSHOT_WINDOW`:

```python
env = htc.BrowserEnv(...)
env.SCREENSHOT_WINDOW = 3  # keep 3 recent screenshots instead of 2
```

---

## Browser-Specific Evaluators

These evaluators use the live browser state injected by `BrowserEnv` after each episode. They are called with the browser still open, so they can query the actual DOM.

### `URLMatch`

Checks if the current URL matches a regex pattern:

```python
rubric.add(
    htc.URLMatch(pattern=r"/cart"),
    weight=0.5,
    dimension="reached_cart",
)
```

### `ElementCheck`

Checks if a CSS selector exists on the current page (evaluation-side only — the agent itself never sees CSS selectors):

```python
rubric.add(
    htc.ElementCheck(selector=".success-message"),
    weight=0.5,
    dimension="task_complete",
)
```

### Custom browser evaluators

You can write evaluators that use the live `page`, `url`, and `trajectory` from the evaluation context:

```python
def item_in_cart(page) -> float:
    """Check the actual DOM for the product name."""
    html = page.content()
    return 1.0 if "Wireless Headphones" in html else 0.0

def visited_product_page(trajectory) -> float:
    """1.0 if the agent visited a /product/ URL at any point."""
    for step in trajectory.steps:
        if "/product/" in step.observation.get("url", ""):
            return 1.0
    return 0.0

def reached_cart(url) -> float:
    """1.0 if the final page is the cart."""
    return 1.0 if url and "/cart" in url else 0.0
```

These three evaluation modes — **final URL**, **live DOM**, and **trajectory history** — give you much more nuanced evaluation than final-state-only checking. See the [Evaluation Guide](evaluation.md) for the full comparison with verifiers.

---

## Multi-Dimensional Browser Evaluation

Combine multiple evaluators into a rubric with named dimensions and weights:

```python
rubric = htc.Rubric()
rubric.add(visited_product_page, weight=0.2, dimension="found_product")
rubric.add(reached_cart,         weight=0.3, dimension="reached_cart")
rubric.add(item_in_cart,         weight=0.5, dimension="item_in_cart")
```

Output:

```
Reward: 0.200  (found_product=1.00, reached_cart=0.00, item_in_cart=0.00)
```

This tells you the agent found the product (partial credit) but never made it to the cart. With a flat scalar, you'd just see `0.2` and have no idea why.

---

## Deterministic Resets

For reproducible RL training, your web app should expose a reset endpoint. The environment calls this before each episode:

```python
{
    "reset_url": "http://localhost:5001/api/reset",
}
```

The environment sends a POST request with `Content-Type: application/json` and an empty body `{}`. Your web app should:

1. Reset any server-side state (cart contents, user session, database)
2. Return a 200 response

Example server-side handler (Express):

```javascript
app.post('/api/reset', (req, res) => {
    cart = [];
    userSession = {};
    res.json({ status: 'ok' });
});
```

If the reset URL fails, a warning is printed but the episode continues.

---

## Screenshots and Trajectory Data

Each step in a browser episode captures:

- **`observation.url`**: The browser URL at that step
- **`observation.screenshot_bytes`**: Raw PNG bytes of the screenshot

When saving to disk with `output_dir`, screenshots are extracted as individual PNG files:

```
runs/2026-03-04_15-16-25_browser_navigate/
├── task_1_rollout_1/
│   ├── trajectory.json
│   └── screenshots/
│       ├── 000.png
│       ├── 001.png
│       └── ...
└── task_2_rollout_1/
    └── ...
```

The JSON trajectory replaces base64 image data with `"[screenshot]"` placeholders to keep file sizes reasonable.

---

## Debugging Tips

### Watch the browser

```python
config = htc.BrowserConfig(headless=False, slow_mo=500)
```

### Check what the agent sees

Look at the saved screenshots in the `runs/` directory. If the agent is struggling, the screenshots will show you exactly what it saw at each step.

### Common issues

| Problem | Likely cause | Fix |
|---------|-------------|-----|
| Agent clicks wrong position | Coordinate estimation error | This is a model limitation — GPT-4o is not a specialized CUA model. Try `computer-use-preview` when available. |
| Agent gets stuck in a loop | Same action repeated | The retry enforcement warning triggers after 2 consecutive identical actions. Increase `max_turns` to give the model more room. |
| Same state every episode | Reset endpoint not working | Verify `reset_url` returns 200 and actually resets state |
| Browser crashes | Resource exhaustion | Make sure you call `env.close()` (use `try/finally`) |
| Agent never calls `done()` | `tool_choice` not set | Use `tool_choice="required"` to force tool calls. The CLI defaults to this for browser envs. |

### Always close the environment

```python
try:
    trajectories = env.run(agent)
finally:
    env.close()
```

This ensures the Playwright browser process is properly shut down. Without it, orphaned Chromium processes can accumulate.

---

## Model Selection for CUA Tasks

**GPT-4o** works for CUA tasks but has known limitations with coordinate accuracy, especially for:
- Small click targets near viewport edges
- Buttons below the visual center of the page

For best results on complex browser tasks, consider:
- **OpenAI `computer-use-preview`** — purpose-built for CUA with trained coordinate estimation
- **Anthropic `claude-computer-use`** — Anthropic's CUA-specialized model

GPT-4o is good enough for simpler navigation tasks (category clicks, search bar + type, product card clicks) and is excellent for development and testing.
