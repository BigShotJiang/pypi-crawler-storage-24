# Text Environments

Text environments handle conversation-based tasks — the agent receives text messages and responds with text (and optionally tool calls). There are three variants, all built on the same core loop.

## Environment Types

| Class | When to use |
|-------|------------|
| `SingleTurnEnv` | One-shot Q&A — the model responds once and the episode ends |
| `TextEnv` | Multi-turn conversation — the model can respond multiple times |
| `ToolEnv` | Multi-turn with tool calling — the model invokes Python functions |

All three share the same constructor parameters (inherited from `EnvBase`):

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `dataset` | `Dataset \| list[dict] \| str` | required | Tasks to iterate over. Accepts a `Dataset`, a list of dicts, or a HuggingFace ID string (e.g. `"openai/gsm8k:test:50"`) |
| `rubric` | `Rubric` | empty | Evaluation pipeline |
| `system_prompt` | `str` | `None` | Prepended to every conversation |
| `max_turns` | `int` | `10` | Max agent responses per episode |
| `rollouts_per_task` | `int` | `1` | Episodes per task |
| `output_dir` | `str` | `None` | Save trajectories to disk |

`TextEnv` and `ToolEnv` additionally accept:

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `tools` | `list[Callable]` | `None` | Python functions to expose as tools |

---

## SingleTurnEnv

The simplest environment. The model gets one chance to respond.

```python
import hyperbolic as htc

dataset = htc.Dataset.from_list([
    {"question": "What year did the Berlin Wall fall?", "answer": "1989"},
    {"question": "What is the chemical symbol for gold?", "answer": "Au"},
])

rubric = htc.Rubric(funcs=[htc.ExactMatch(strip=True, case_sensitive=False)])

env = htc.SingleTurnEnv(
    dataset=dataset,
    rubric=rubric,
    system_prompt="Answer with just the answer, no explanation.",
)

agent = htc.OpenAIAgent(model="gpt-4o-mini")
trajectories = env.run(agent)
```

Under the hood, `SingleTurnEnv` is just `TextEnv` with `max_turns=1`.

### When to use it

- Factual Q&A with ground-truth answers
- Classification tasks
- Any scenario where the model should respond in a single message

---

## TextEnv (Multi-Turn)

Allows the model to respond multiple times. The episode ends when the model responds without making any tool calls, or when `max_turns` is reached. Even without tools, this is useful for multi-step reasoning or chain-of-thought.

```python
env = htc.TextEnv(
    dataset=dataset,
    rubric=rubric,
    max_turns=5,
    system_prompt="Think step by step, then give your final answer.",
)
```

### Episode Flow

1. The system prompt and task question are assembled into the initial message list
2. The agent is called with the messages
3. If the agent responds with content (no tool calls), the episode ends
4. If the agent makes tool calls, they are executed and results appended
5. Repeat from step 2 until `max_turns`

---

## ToolEnv (Tool Calling)

`ToolEnv` is syntactic sugar for `TextEnv(tools=[...])`. It makes intent explicit and requires at least one tool.

### Defining Tools

Tools are plain Python functions. The library auto-generates OpenAI-compatible tool schemas from function signatures and docstrings:

```python
def search_database(query: str, limit: int = 10) -> str:
    """Search the product database for matching items.

    Args:
        query: Search query string.
        limit: Maximum number of results to return.

    Returns:
        JSON string of matching products.
    """
    # your implementation
    results = db.search(query, limit=limit)
    return json.dumps(results)
```

This automatically generates the schema:

```json
{
    "type": "function",
    "function": {
        "name": "search_database",
        "description": "Search the product database for matching items.",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search query string."},
                "limit": {"type": "integer", "description": "Maximum number of results to return."}
            },
            "required": ["query"]
        }
    }
}
```

**Schema generation rules**:
- Function name → tool name
- Type hints → parameter types (`str` → `"string"`, `int` → `"integer"`, `float` → `"number"`, `bool` → `"boolean"`)
- Parameters with defaults are optional; without defaults are required
- Docstring first paragraph → tool description
- `Args:` block → per-parameter descriptions

### Full Example

```python
import hyperbolic as htc

def calculate(expression: str) -> str:
    """Evaluate a math expression.

    Args:
        expression: A Python math expression (e.g. "2 + 2 * 3").
    """
    try:
        return str(eval(expression, {"__builtins__": {}}))
    except Exception as e:
        return f"Error: {e}"

def lookup(term: str) -> str:
    """Look up the definition of a term.

    Args:
        term: The term to look up.
    """
    definitions = {
        "python": "A high-level programming language.",
        "playwright": "A browser automation framework.",
    }
    return definitions.get(term.lower(), f"Unknown: '{term}'")

dataset = htc.Dataset.from_list([
    {"question": "What is 17 * 23?", "answer": "391"},
    {"question": "What is Python?", "answer": "programming language"},
])

def correct(completion, answer):
    return 1.0 if answer.lower() in completion[-1]["content"].lower() else 0.0

env = htc.ToolEnv(
    dataset=dataset,
    rubric=htc.Rubric(funcs=[correct]),
    tools=[calculate, lookup],
    system_prompt="Use tools to answer. Give a final answer in plain text.",
    max_turns=5,
)

agent = htc.OpenAIAgent(model="gpt-4o-mini")
trajectories = env.run(agent)
```

### What Happens During Tool Execution

1. The agent's response includes `tool_calls` with function name and JSON arguments
2. The environment looks up the function by name and calls it with the parsed arguments
3. The result (as a string) is appended as a `tool` message with the matching `tool_call_id`
4. The agent sees the tool result and can make more tool calls or give a final answer

If a tool function raises an exception, the environment catches it and returns `"Error: <message>"` so the agent can recover.

---

## Task Dict Format

Text environments understand several task dict formats:

### Simple question + answer

```python
{"question": "What is 2+2?", "answer": "4"}
```

The `question` string is wrapped into `{"role": "user", "content": "What is 2+2?"}`.

### Pre-formatted prompt

```python
{
    "prompt": [
        {"role": "system", "content": "You are a math tutor."},
        {"role": "user", "content": "Solve: 2x + 3 = 7"},
    ],
    "answer": "x = 2",
}
```

When `prompt` is a list of messages, it's used directly. If the first message has `role: "system"`, it overrides the environment's `system_prompt`.

### String prompt

```python
{"prompt": "Write a haiku about programming."}
```

When `prompt` is a plain string, it's wrapped into a user message (and the environment's `system_prompt` is still prepended).

### Extra metadata

```python
{
    "question": "Write a rejection email.",
    "info": {"context": "job_application", "company": "Acme Corp"},
}
```

The `info` field is available to evaluators via signature injection. If it's a JSON string, it's auto-parsed into a dict.

---

## Multiple Rollouts

Running multiple rollouts per task is useful for estimating reward variance or collecting diverse trajectories:

```python
# Run 5 rollouts per task
trajectories = env.run(agent, rollouts_per_task=5)
```

Each rollout gets a unique episode ID like `ep_20260226_143012_t0_r0` (task 0, rollout 0).

---

## Inspecting Results

```python
for t in trajectories:
    # The task that was given
    print(t.task["question"])

    # Scalar reward (weighted average of all dimensions)
    print(t.scalar_reward)

    # Per-dimension breakdown
    print(t.assessment.dimensions)
    # e.g. {"ExactMatch": 1.0, "length_check": 0.8}

    # Number of turns the agent took
    print(len(t.steps))

    # The full conversation (OpenAI message format)
    for msg in t.completion:
        print(f"  [{msg['role']}] {msg.get('content', '')[:80]}")
```
