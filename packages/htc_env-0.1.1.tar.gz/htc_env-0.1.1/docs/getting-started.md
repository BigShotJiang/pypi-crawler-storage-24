# Getting Started

This guide walks you through installing `hyperbolic`, configuring your environment, and running your first evaluation in under five minutes.

## Prerequisites

- **Python 3.10+**
- **uv** (package manager) — [install instructions](https://docs.astral.sh/uv/getting-started/installation/)
- An **OpenAI API key** (or any OpenAI-compatible endpoint)

## Installation

Clone the repo and install with `uv`:

```bash
cd rl_env
uv sync
```

This installs the core dependencies (`openai`, `Pillow`). For optional features:

```bash
# Browser environments (adds playwright)
uv sync --extra browser
playwright install chromium

# HuggingFace dataset loading
uv sync --extra datasets

# Both
uv sync --extra browser --extra datasets
playwright install chromium
```

## API Key Setup

API keys are resolved through a three-tier chain (highest priority first):

1. **Explicit parameter** — `OpenAIAgent(api_key="sk-...")`
2. **`.env` file** — auto-loaded from your project root
3. **System environment variable** — `export OPENAI_API_KEY=sk-...`

### Recommended: `.env` file

Copy the included template and fill in your key:

```bash
cp .env.example .env
```

Then edit `.env`:

```
OPENAI_API_KEY=sk-proj-...
```

The `.env` file is already in `.gitignore` — your keys will never be committed.

### Alternative: system environment variable

```bash
export OPENAI_API_KEY="sk-..."
```

### Alternative: pass directly in code

```python
agent = htc.OpenAIAgent(model="gpt-4o", api_key="sk-...")
```

This works for quick scripts but is not recommended for shared code.

## Your First Script

Create a file called `my_first_env.py`:

```python
import hyperbolic as htc

# 1. Define your tasks
dataset = htc.Dataset.from_list([
    {"question": "What is 2 + 2?", "answer": "4"},
    {"question": "What is the capital of France?", "answer": "Paris"},
])

# 2. Define how to score responses
def contains_answer(completion, answer):
    """1.0 if the expected answer appears in the model's response."""
    response = completion[-1]["content"]
    return 1.0 if answer.lower() in response.lower() else 0.0

rubric = htc.Rubric(funcs=[contains_answer])

# 3. Create the environment
env = htc.SingleTurnEnv(
    dataset=dataset,
    rubric=rubric,
    system_prompt="Answer concisely in one sentence.",
)

# 4. Create an agent and run
agent = htc.OpenAIAgent(model="gpt-4o-mini")
trajectories = env.run(agent)

# 5. Inspect results
for t in trajectories:
    print(f"  Q: {t.task['question']}")
    print(f"  Reward: {t.scalar_reward:.1f}")
    print()
```

Run it:

```bash
uv run python my_first_env.py
```

You should see output like:

```
  [1/2] Task: What is 2 + 2?
         Response: 4
         Reward: 1.000  (contains_answer=1.00)

  [2/2] Task: What is the capital of France?
         Response: The capital of France is Paris.
         Reward: 1.000  (contains_answer=1.00)
```

## Using the CLI

Every example (and any script you write) can also be run through the `htc` CLI. Your script needs to export a `load_environment()` function:

```python
def load_environment():
    # ... build dataset, rubric, env ...
    return env
```

Then run:

```bash
uv run htc run my_first_env.py -m gpt-4o-mini -r 1 -o ./runs
```

| Flag | Meaning | Default |
|------|---------|---------|
| `-m` / `--model` | Model name (e.g. `gpt-4o`, `gpt-4o-mini`) | `gpt-4o` |
| `-r` / `--rollouts` | Rollouts per task | `1` |
| `-o` / `--output` | Directory to save trajectories | `./runs` |
| `--tool-choice` | Tool selection strategy (`auto`, `required`, `none`) | Browser envs default to `required` |
| `--temperature` | Sampling temperature | API default |
| `--max-tokens` | Max tokens for model response | `1024` |

## Saving Trajectories

Pass `output_dir` when creating the environment to persist trajectories to disk:

```python
env = htc.SingleTurnEnv(
    dataset=dataset,
    rubric=rubric,
    output_dir="./my_runs",
)
```

Each run creates a timestamped directory, and each episode gets its own subdirectory:

```
my_runs/
└── 2026-03-04_15-16-25_simple_math/
    ├── task_1_rollout_1/
    │   └── trajectory.json
    └── task_2_rollout_1/
        └── trajectory.json
```

For browser episodes, screenshots are saved alongside the trajectory:

```
task_1_rollout_1/
├── trajectory.json
└── screenshots/
    ├── 000.png
    ├── 001.png
    └── ...
```

## Using a Different LLM Provider

Any OpenAI-compatible API works. Pass `base_url` and set the appropriate key in your `.env`:

```
# .env
OPENAI_API_KEY=sk-proj-...
TOGETHER_API_KEY=your-together-key
```

```python
# Local vLLM server (no key needed)
agent = htc.OpenAIAgent(
    model="meta-llama/Llama-3-8B-Instruct",
    base_url="http://localhost:8000/v1",
    api_key="not-needed",
)

# Together AI (key from .env or explicit)
agent = htc.OpenAIAgent(
    model="meta-llama/Llama-3-70B-Instruct",
    base_url="https://api.together.xyz/v1",
    api_key="your-together-key",
)

# Ollama (local, no real key needed)
agent = htc.OpenAIAgent(
    model="llama3",
    base_url="http://localhost:11434/v1",
    api_key="ollama",
)
```

## Next Steps

- [Text Environments](text-environments.md) — single-turn, multi-turn, and tool-calling
- [Browser Environments](browser-environments.md) — Playwright-based CUA web automation
- [Evaluation Guide](evaluation.md) — rubrics, evaluators, LLM judges, multi-dimensional scoring
- [Architecture](architecture.md) — how the pieces fit together under the hood
- [Examples Walkthrough](examples.md) — detailed breakdown of every example
