# Examples Walkthrough

This guide walks through each example in the `examples/` directory, explaining what it does, what you need to run it, and what to expect.

---

## 1. Simple Math (`examples/simple_math.py`)

**Concept**: The simplest possible use case — single-turn Q&A with a deterministic evaluator.

### What it does

- Defines 3 math questions with expected answers
- The agent answers each question in a single response
- A custom evaluator checks if the expected answer appears in the response

### Prerequisites

- OpenAI API key
- No extra dependencies

### How to run

```bash
cd rl_env

# Via CLI
uv run htc run examples/simple_math.py -m gpt-4o-mini

# As a script
uv run python examples/simple_math.py
```

### Code walkthrough

The evaluator is a plain function:

```python
def correct_answer(completion, answer):
    """1.0 if the expected answer appears anywhere in the response."""
    response = completion[-1]["content"]
    return 1.0 if answer in response else 0.0
```

It asks for `completion` (the message history) and `answer` (from the task dict) — the Rubric injects both automatically based on argument names.

### Expected output

```
  [1/3] Task: What is 2+2?
         Response: 4
         Reward: 1.000  (correct_answer=1.00)

  [2/3] Task: What is 7*8?
         Response: 56
         Reward: 1.000  (correct_answer=1.00)

  [3/3] Task: What is 100/4?
         Response: 25
         Reward: 1.000  (correct_answer=1.00)
```

### Key takeaway

This example shows the full flow in under 30 lines: data → evaluator → environment → agent → results.

---

## 2. Tool Use (`examples/tool_use.py`)

**Concept**: Multi-turn environment where the model calls Python functions as tools.

### What it does

- Defines 2 tasks: a math calculation and a term lookup
- Exposes two tools: `calculate()` (evaluates math expressions) and `lookup()` (dictionary lookup)
- The agent decides which tool to use, calls it, reads the result, and gives a final answer
- Scored by checking if the expected answer appears in the final response

### Prerequisites

- OpenAI API key
- No extra dependencies

### How to run

```bash
cd rl_env
uv run htc run examples/tool_use.py -m gpt-4o-mini
```

### Code walkthrough

Tools are regular Python functions with type hints and docstrings. The library automatically generates OpenAI-compatible tool schemas from the function signature:

```python
def calculate(expression: str) -> str:
    """Evaluate a mathematical expression and return the result.

    Args:
        expression: A Python math expression (e.g. "2 + 2 * 3").
    """
    try:
        result = eval(expression, {"__builtins__": {}})
        return str(result)
    except Exception as e:
        return f"Error: {e}"
```

### Key takeaway

This shows how tool calling works end-to-end. The model generates structured tool calls, the environment executes them, and tool results flow back into the conversation naturally. You don't write any JSON schemas — they're generated from your Python functions.

---

## 3. Browser Navigate (`examples/browser_navigate.py`)

**Concept**: The simplest browser task — click category links and navigate to specific pages.

### What it does

- 2 tasks: click the "Electronics" category filter, and navigate to the cart page
- Evaluated by checking if the final URL matches a pattern (`/category/`, `/cart/`, or `/search/`)
- Great for verifying the CUA pipeline works end-to-end

### Prerequisites

- ShopNova marketplace running on `localhost:5001`
- `playwright install chromium`

### How to run

```bash
cd rl_env
uv run htc run examples/browser_navigate.py -m gpt-4o
```

### Code walkthrough

The rubric uses a single `URLMatch` evaluator:

```python
rubric = htc.Rubric()
rubric.add(
    htc.URLMatch(pattern=r".*localhost:5001/(category|cart|search).*"),
    weight=1.0,
    dimension="navigation",
)
```

### Expected output

```
  [1/2] Task: You are on ShopNova. Click on the 'Electronics' category filter…
         Reward: 1.000  (navigation=1.00)

  [2/2] Task: You are on ShopNova. Navigate to the shopping cart page…
         Reward: 1.000  (navigation=1.00)
```

### Key takeaway

This validates the core CUA loop: screenshot → model interprets visually → `click(x, y)` → page changes → evaluation. No CSS selectors, no DOM — pure pixel-based browsing.

---

## 4. Browser Search (`examples/browser_search.py`)

**Concept**: Use the search bar to find products — tests click-to-focus, typing, and result navigation.

### What it does

- 2 tasks: search for "yoga mat" and click the result, search for "coffee" and find the coffee set
- Evaluated by checking if the final URL matches `/product/\d+`

### Prerequisites

- ShopNova marketplace running on `localhost:5001`
- `playwright install chromium`

### How to run

```bash
cd rl_env
uv run htc run examples/browser_search.py -m gpt-4o
```

### Code walkthrough

The agent needs to:
1. `click(x, y)` on the search bar to focus it
2. `type_text(text="yoga mat")` — this types and presses Enter
3. `click(x, y)` on the product card in the results

This is the natural CUA interaction pattern: click to focus, type, interact with results. No CSS selectors needed.

### Expected output

```
  [1/2] Task: Use the search bar to search for 'yoga mat'…
         Reward: 1.000  (found_product=1.00)

  [2/2] Task: Use the search bar to search for 'coffee'…
         Reward: 1.000  (found_product=1.00)
```

### Key takeaway

Interesting behavior: in one run, the model failed to find the search bar for the coffee task, so it **browsed through categories** (Clothing → Books → Home & Kitchen) until it found the coffee set. This adaptive problem-solving is exactly what the CUA approach enables.

---

## 5. Browser Task (`examples/browser_task.py`)

**Concept**: A complex multi-step task — find a product, add it to cart, and verify.

### What it does

- 1 task: find "Wireless Noise-Canceling Headphones", add to cart, navigate to cart to verify
- Evaluated on **three dimensions** with different weights:
  - `found_product` (20%): Did the agent visit a `/product/` page at any point? (trajectory-based)
  - `reached_cart` (30%): Is the final URL `/cart`? (URL-based)
  - `item_in_cart` (50%): Does the cart page DOM contain "Wireless Noise-Canceling Headphones"? (live DOM-based)

### Prerequisites

- ShopNova marketplace running on `localhost:5001`
- `playwright install chromium`

### How to run

```bash
cd rl_env
uv run htc run examples/browser_task.py -m gpt-4o
```

### Code walkthrough

This example showcases all three evaluation modes for browser tasks:

```python
def _visited_product_page(trajectory) -> float:
    """Check the trajectory history — did the agent ever visit a product page?"""
    for step in trajectory.steps:
        url = step.observation.get("url", "")
        if re.search(r"/product/\d+", url):
            return 1.0
    return 0.0

def _reached_cart(url) -> float:
    """Check the final URL."""
    return 1.0 if url and "/cart" in url else 0.0

def _item_in_cart(page) -> float:
    """Query the live DOM for the product name."""
    if page is None:
        return 0.0
    html = page.content()
    if "Wireless Noise-Canceling Headphones" in html:
        return 1.0
    return 0.0
```

Combined into a rubric with named dimensions:

```python
rubric = htc.Rubric()
rubric.add(_visited_product_page, weight=0.2, dimension="found_product")
rubric.add(_reached_cart, weight=0.3, dimension="reached_cart")
rubric.add(_item_in_cart, weight=0.5, dimension="item_in_cart")
```

### Expected output

```
  [1/1] Task: Find the 'Wireless Noise-Canceling Headphones'…
         Reward: 0.200  (found_product=1.00, reached_cart=0.00, item_in_cart=0.00)
```

The model found the product page (partial credit!) but couldn't click "Add to Cart" accurately. This is a **model limitation** — GPT-4o struggles with precise coordinate estimation for buttons below the visual center of the page. Specialized CUA models would perform better.

### Key takeaway

Multi-dimensional scoring lets you see *where* the agent succeeded and failed. A flat `0.2` tells you nothing; `found_product=1.00, reached_cart=0.00` tells you the navigation worked but the cart interaction didn't.

---

## 6. Browser Social (`examples/browser_social.py`)

**Concept**: Interact with a social media app — composing posts, liking content, navigating profiles.

### What it does

- 3 tasks on the Chirper app (Twitter clone):
  - Compose a post saying "Hello from the RL agent!"
  - Find @techguru's post and like it
  - Navigate to @wanderlust_mike's profile via the Explore page
- A single heuristic evaluator checks the final page state for task-specific signals

### Prerequisites

- Chirper social app running on `localhost:5002`
- `playwright install chromium`

### How to run

```bash
cd rl_env
uv run htc run examples/browser_social.py -m gpt-4o
```

### Code walkthrough

The evaluator checks multiple conditions based on the final page state:

```python
def _check_task_completion(url=None, page=None) -> float:
    html = page.content()

    if "Hello from the RL agent" in html:
        return 1.0  # post was created

    if "/profile/wanderlust_mike" in url:
        return 1.0  # profile was reached

    pink_hearts = page.query_selector_all("button.text-pink-500")
    if pink_hearts:
        return 1.0  # a post was liked

    if "/explore" in url or "/profile/" in url or "/compose" in url:
        return 0.5  # partial credit for being on the right page

    return 0.0
```

### Key takeaway

This shows evaluation using live DOM queries (`query_selector_all`) on the evaluation side. The agent itself never sees the DOM — it browses with screenshots and coordinates only. But the evaluator can inspect the actual page state to verify whether actions had the intended effect.

---

## 7. Subjective Evaluation (`examples/subjective_eval.py`)

**Concept**: Multi-dimensional subjective scoring using LLM judges with agreement tracking — the core philosophical differentiator of the library.

### What it does

- Two creative writing tasks: a rejection email and a product description
- Three evaluation dimensions:
  - **format** (weight 0.1): A free heuristic checking response length (no API cost)
  - **tone** (weight 0.5): A `JudgePanel` with 2 LLM judges scoring tone appropriateness
  - **helpfulness** (weight 0.4): A single `LLMJudge` scoring completeness

### Prerequisites

- OpenAI API key (the judges call `gpt-4o-mini`)
- No extra dependencies

### How to run

```bash
cd rl_env
uv run htc run examples/subjective_eval.py -m gpt-4o-mini
```

### Code walkthrough

The judge panel uses two instances of `gpt-4o-mini` scoring tone independently:

```python
tone_panel = htc.JudgePanel(
    judges=["gpt-4o-mini", "gpt-4o-mini"],
    prompt=(
        "Rate the TONE of this response from 0.0 to 1.0.\n\n"
        "Task:\n```\n{prompt}\n```\n\n"
        "Response:\n```\n{response}\n```\n\n"
        "{answer_section}\n"
        "A score of 1.0 means the tone perfectly matches what was asked for. "
        "Respond with ONLY a number."
    ),
    aggregation="median",
)
```

### Expected output

```
  [1/2] Task: Write a professional but warm email rejecting a job applicant…
         Reward: 0.870  (format=1.00, tone=0.85, helpfulness=0.90)

  Metadata: {'tone': {'judge_scores': {'gpt-4o-mini_0': 0.85, 'gpt-4o-mini_1': 0.85},
                       'aggregation': 'median', 'agreement': 1.0}}
```

### Key takeaway

This shows how `hyperbolic` handles tasks where there's no single right answer. The multi-dimensional Assessment preserves all the detail — which judges agreed, how each dimension scored, and what the final weighted scalar is.

---

## Running All Examples

### Text-based examples

```bash
cd rl_env

# Simple math (cheapest, fastest)
uv run htc run examples/simple_math.py -m gpt-4o-mini

# Tool use
uv run htc run examples/tool_use.py -m gpt-4o-mini

# Subjective evaluation (costs a bit more — 3 judge calls per task)
uv run htc run examples/subjective_eval.py -m gpt-4o-mini
```

### Browser-based examples (need local sites running)

```bash
cd rl_env

# Navigate (simplest browser task — 2 tasks, 5 turns max)
uv run htc run examples/browser_navigate.py -m gpt-4o

# Search (click + type + navigate — 2 tasks, 8 turns max)
uv run htc run examples/browser_search.py -m gpt-4o

# Full task (find + add to cart + verify — 1 task, 15 turns max)
uv run htc run examples/browser_task.py -m gpt-4o

# Social media (compose, like, navigate — 3 tasks, 10 turns max)
uv run htc run examples/browser_social.py -m gpt-4o
```

### Cost estimates (approximate)

| Example | Model | Approx. Cost |
|---------|-------|-------------|
| `simple_math.py` | `gpt-4o-mini` | < $0.01 |
| `tool_use.py` | `gpt-4o-mini` | < $0.01 |
| `subjective_eval.py` | `gpt-4o-mini` | ~$0.02-0.05 |
| `browser_navigate.py` | `gpt-4o` | ~$0.03-0.08 |
| `browser_search.py` | `gpt-4o` | ~$0.05-0.15 |
| `browser_task.py` | `gpt-4o` | ~$0.10-0.25 |
| `browser_social.py` | `gpt-4o` | ~$0.10-0.30 |
