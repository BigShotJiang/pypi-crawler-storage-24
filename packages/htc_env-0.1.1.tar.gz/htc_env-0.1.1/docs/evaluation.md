# Evaluation Guide

This guide covers everything about scoring trajectories — from simple exact-match checks to multi-judge LLM panels with agreement tracking — and explains how our evaluation system compares to other libraries in the space.

## Core Concepts

### The Evaluation Pipeline

```
Trajectory ──▶ Rubric ──▶ Assessment
                 │
                 ├── Evaluator 1 (weight=1.0, dim="accuracy")  → 1.0
                 ├── Evaluator 2 (weight=0.5, dim="tone")      → 0.8
                 └── Evaluator 3 (weight=0.0, dim="length")    → 0.6  (metric only)
                                                                   │
                                                     scalar = (1.0×1.0 + 0.8×0.5) / 1.5 = 0.933
```

- **Evaluators** are callables that score one dimension of quality
- **Rubric** combines evaluators with weights and dimension names
- **Assessment** holds the per-dimension scores, scalar collapse, and metadata

### Scalar Reward

The scalar reward is the **weighted average** of all evaluators with non-zero weights. Zero-weight evaluators are tracked as metrics but don't affect the scalar. This scalar is what gets passed to training algorithms (GRPO, PPO, etc.).

### Multi-Dimensional Scoring

The full Assessment preserves per-dimension scores for analysis, debugging, and downstream use:

```python
assessment.dimensions    # {"accuracy": 1.0, "tone": 0.8, "length": 0.6}
assessment.scalar        # 0.933
assessment.metadata      # {"tone": {"judge_scores": {...}, "agreement": 0.95}}
```

This is the core design difference from libraries like `verifiers`, which collapse to a single scalar immediately and discard per-dimension detail.

---

## Writing Evaluators

An evaluator is any callable that returns a `float` (0.0 to 1.0) or an `EvalResult`. It declares what data it needs via argument names — the Rubric inspects the function signature and injects matching values.

### Simple function evaluator

```python
def contains_answer(completion, answer):
    """1.0 if the expected answer appears in the response."""
    response = completion[-1]["content"]
    return 1.0 if answer.lower() in response.lower() else 0.0
```

### Class-based evaluator

```python
class KeywordChecker:
    def __init__(self, keywords):
        self.keywords = keywords

    def __call__(self, completion):
        text = completion[-1]["content"].lower()
        found = sum(1 for kw in self.keywords if kw.lower() in text)
        return found / len(self.keywords)
```

### Evaluator returning metadata

Return an `EvalResult` when you need to pass extra information:

```python
from hyperbolic import EvalResult

def detailed_scorer(completion, answer):
    response = completion[-1]["content"]
    exact = response.strip().lower() == answer.strip().lower()
    contains = answer.lower() in response.lower()

    score = 1.0 if exact else (0.5 if contains else 0.0)
    return EvalResult(
        score=score,
        metadata={"exact_match": exact, "contains_match": contains},
    )
```

### Available context keys

When the Rubric calls your evaluator, it builds a context dict and injects values matching your parameter names:

| Parameter name | Type | Description |
|---------------|------|-------------|
| `completion` | `list[dict]` | Full message history (OpenAI chat format) |
| `prompt` | `list[dict]` | Messages before the first assistant reply |
| `answer` | `str \| None` | From the task dict's `"answer"` field |
| `info` | `dict` | From the task dict's `"info"` field (auto-parsed if JSON) |
| `task` | `dict` | The entire task dict |
| `trajectory` | `Trajectory` | The full trajectory object (steps, metadata, etc.) |
| `url` | `str` | Current browser URL (BrowserEnv only) |
| `page` | Playwright `Page` | Live page object (BrowserEnv only) |
| `state` | `dict` | Empty dict (reserved for future use) |

You only need to include the parameters you actually use:

```python
# Text task — only needs the completion
def length_check(completion):
    return 1.0 if len(completion[-1]["content"]) > 50 else 0.5

# Browser task — uses the trajectory object for history-based evaluation
def efficiency_score(trajectory):
    return max(0.0, 1.0 - len(trajectory.steps) / 20)

# Browser task — checks the live DOM
def page_title_check(page):
    return 1.0 if "Success" in page.title() else 0.0
```

---

## Built-in Evaluators

### Deterministic (Zero-Cost)

These evaluators run locally with no API calls.

#### `ExactMatch`

Checks if the model's response exactly equals the expected answer.

```python
evaluator = htc.ExactMatch(
    strip=True,           # strip whitespace before comparing (default True)
    case_sensitive=False,  # case-insensitive comparison (default False)
)
```

#### `RegexMatch`

Checks if a regex pattern matches anywhere in the response.

```python
# Fixed pattern
evaluator = htc.RegexMatch(pattern=r"\d{4}-\d{2}-\d{2}")

# Dynamic pattern from the task's answer field
evaluator = htc.RegexMatch()  # uses task["answer"] as the pattern
```

#### `MathVerify`

Extracts `\boxed{...}` answers and checks mathematical equivalence. Falls back to string comparison when the `math-verify` package isn't installed.

```python
evaluator = htc.MathVerify()
```

#### `URLMatch` (BrowserEnv only)

Checks if the current browser URL matches a regex.

```python
evaluator = htc.URLMatch(pattern=r"/checkout")
```

The `url` value is injected by `BrowserEnv` after the episode — it's the browser's URL at the moment evaluation runs.

#### `ElementCheck` (BrowserEnv only)

Checks if a CSS selector exists on the current page. This queries the **live DOM** via Playwright — it's an evaluator-side capability, not something the agent has access to.

```python
evaluator = htc.ElementCheck(selector=".success-message")
```

#### `HeuristicScorer`

Configurable rule-based scorer combining multiple checks:

```python
evaluator = htc.HeuristicScorer(
    min_length=50,                    # penalize short responses
    max_length=500,                   # penalize long responses
    required_keywords=["therefore"],  # all must appear
    forbidden_keywords=["sorry"],     # none may appear
)
```

Scoring:
- Length violations multiply score by 0.5
- Required keywords: score multiplied by `(found / total)`
- Forbidden keywords: score set to 0.0 if any appear

---

### Probabilistic (LLM-Based)

These evaluators call an LLM to judge the response. They cost API tokens but can assess subjective qualities like tone, helpfulness, and coherence.

#### `LLMJudge`

A single LLM that scores a response on a 0-1 scale.

```python
judge = htc.LLMJudge(
    model="gpt-4o-mini",
    prompt=None,          # uses a sensible default; override for custom criteria
    api_key=None,         # falls back to OPENAI_API_KEY
    base_url=None,        # for non-OpenAI providers
)
```

**Custom prompt template** — use `{prompt}`, `{response}`, and `{answer_section}` placeholders:

```python
judge = htc.LLMJudge(
    model="gpt-4o-mini",
    prompt=(
        "Rate the PROFESSIONALISM of this response from 0.0 to 1.0.\n\n"
        "Task:\n```\n{prompt}\n```\n\n"
        "Response:\n```\n{response}\n```\n\n"
        "{answer_section}\n"
        "Respond with ONLY a number."
    ),
)
```

The judge lazily initializes its OpenAI client on first use.

#### `JudgePanel`

Multiple LLM judges scoring independently, with aggregation and agreement tracking.

```python
panel = htc.JudgePanel(
    judges=["gpt-4o-mini", "gpt-4o-mini", "gpt-4o"],
    prompt="...",              # shared prompt template
    aggregation="median",      # "mean", "median", "min", "max"
)
```

You can also pass pre-configured `LLMJudge` instances:

```python
panel = htc.JudgePanel(
    judges=[
        htc.LLMJudge(model="gpt-4o-mini", prompt="Rate tone..."),
        htc.LLMJudge(model="gpt-4o", prompt="Rate tone..."),
    ],
    aggregation="mean",
)
```

**Parallel execution**: Judges run concurrently via `ThreadPoolExecutor` — a panel of 3 judges takes roughly the same wall-clock time as a single judge.

**Agreement tracking**: The panel returns an `EvalResult` with metadata:

```python
result = panel(completion=messages, prompt=prompt_msgs)
result.score       # aggregated score
result.metadata    # {
                   #   "judge_scores": {"gpt-4o-mini_0": 0.8, "gpt-4o-mini_1": 0.7, "gpt-4o": 0.85},
                   #   "aggregation": "median",
                   #   "agreement": 0.85
                   # }
```

Agreement is `1.0 - (max_score - min_score)`. An agreement of 1.0 means all judges gave the same score.

---

## Using the Rubric

### Basic usage

```python
rubric = htc.Rubric(funcs=[contains_answer, length_check])
```

Evaluators are auto-named from their function/class name and given weight 1.0 by default.

### Explicit weights and dimensions

```python
rubric = htc.Rubric()
rubric.add(htc.ExactMatch(), weight=1.0, dimension="accuracy")
rubric.add(length_check, weight=0.2, dimension="format")
rubric.add(tone_panel, weight=0.5, dimension="tone")
```

### Tracking metrics without affecting reward

```python
rubric.add_metric(word_counter, dimension="word_count")
```

Zero-weight evaluators are tracked in `assessment.dimensions` but excluded from the scalar calculation. Useful for monitoring auxiliary signals.

### Chaining

`add()` and `add_metric()` return the rubric, so you can chain:

```python
rubric = (
    htc.Rubric()
    .add(htc.ExactMatch(), weight=1.0, dimension="accuracy")
    .add(length_check, weight=0.2, dimension="format")
    .add_metric(word_counter, dimension="word_count")
)
```

---

## Browser Evaluation — Three Modes

Browser tasks have access to evaluation modes that text tasks don't. Understanding these three modes is key to writing effective browser evaluators:

### Mode 1: Final URL checking

Check the browser's current URL at the end of the episode. Simple, fast, no DOM access needed.

```python
# Built-in
rubric.add(htc.URLMatch(pattern=r"/cart"), weight=0.3, dimension="reached_cart")

# Custom
def reached_checkout(url):
    return 1.0 if url and "/checkout" in url else 0.0
rubric.add(reached_checkout, weight=0.3, dimension="reached_checkout")
```

**Best for**: Navigation verification, page-level goal checking.

### Mode 2: Live DOM inspection

Query the actual page DOM via Playwright after the episode. The browser is still open at evaluation time, so you can run CSS selectors, read page content, and check element states.

```python
# Built-in
rubric.add(htc.ElementCheck(selector=".cart-item"), weight=0.5, dimension="item_in_cart")

# Custom — check for specific content in the DOM
def product_in_cart(page):
    html = page.content()
    return 1.0 if "Wireless Headphones" in html else 0.0
rubric.add(product_in_cart, weight=0.5, dimension="product_in_cart")

# Custom — count elements
def has_multiple_items(page):
    items = page.query_selector_all(".cart-item")
    return min(len(items) / 3, 1.0)  # partial credit scales to 3 items
rubric.add(has_multiple_items, weight=0.2, dimension="cart_quantity")
```

**Best for**: Verifying the effect of actions (item added, form submitted, state changed).

### Mode 3: Trajectory history

Inspect the full sequence of steps the agent took. Each step records the URL and action at that point in time. This lets you give partial credit for intermediate progress.

```python
def visited_product_page(trajectory):
    for step in trajectory.steps:
        if "/product/" in step.observation.get("url", ""):
            return 1.0
    return 0.0
rubric.add(visited_product_page, weight=0.2, dimension="found_product")

def used_search(trajectory):
    for step in trajectory.steps:
        if "/search" in step.observation.get("url", ""):
            return 1.0
    return 0.0
rubric.add_metric(used_search, dimension="search_usage")
```

**Best for**: Partial credit, intermediate goal checking, evaluating agent strategy.

### Combining all three modes

A real browser rubric typically combines all three for nuanced evaluation:

```python
rubric = htc.Rubric()
rubric.add(visited_product_page, weight=0.2, dimension="found_product")   # trajectory
rubric.add(htc.URLMatch(pattern=r"/cart"), weight=0.3, dimension="reached_cart")  # URL
rubric.add(product_in_cart, weight=0.5, dimension="item_in_cart")          # DOM
```

This yields rich per-dimension feedback:

```
Reward: 0.200  (found_product=1.00, reached_cart=0.00, item_in_cart=0.00)
```

---

## Common Patterns

### Objective task (verifiable)

```python
rubric = htc.Rubric(funcs=[htc.ExactMatch()])
env = htc.SingleTurnEnv(dataset=dataset, rubric=rubric)
```

### Subjective task with LLM judge

```python
rubric = htc.Rubric()
rubric.add(htc.LLMJudge(model="gpt-4o-mini"), weight=1.0, dimension="quality")
```

### Mixed objective + subjective

```python
rubric = htc.Rubric()
rubric.add(htc.ExactMatch(), weight=0.6, dimension="accuracy")
rubric.add(
    htc.JudgePanel(judges=["gpt-4o-mini", "gpt-4o-mini"], aggregation="median"),
    weight=0.4,
    dimension="quality",
)
```

### Data collection (no evaluation)

```python
env = htc.TextEnv(dataset=dataset, output_dir="./runs")
# No rubric — trajectories are saved with scalar_reward = 0.0
```

---

## Comparison with Verifiers

Our evaluation system was designed to address gaps we identified in Prime Intellect's `verifiers` library. Here's a detailed comparison:

### What we provide that verifiers doesn't

| Capability | hyperbolic | verifiers |
|-----------|--------|-----------|
| **Named dimensions** | Each evaluator targets a named dimension (`"accuracy"`, `"tone"`) | All evaluators contribute to a single unnamed scalar |
| **Per-dimension visibility** | Assessment shows `{accuracy: 1.0, tone: 0.8}` | Returns a single float |
| **Weighted aggregation** | Configurable weights per evaluator | Uniform combination |
| **Live DOM access** | Evaluators receive the Playwright `page` object | No DOM access for reward functions |
| **URL checking** | Built-in `URLMatch` evaluator | No equivalent |
| **Element checking** | Built-in `ElementCheck` evaluator | No equivalent |
| **Trajectory-based evaluation** | Evaluators can inspect the full step history | Reward functions see final state only |
| **JudgePanel with agreement** | Multi-judge panel with `agreement` metric and parallel execution | Single judge only |
| **Zero-weight metrics** | `add_metric()` tracks dimensions without affecting reward | No equivalent |
| **EvalResult metadata** | Evaluators can return arbitrary metadata alongside scores | No metadata pathway |

### What verifiers provides that we could learn from (post-MVP)

| Capability | verifiers | hyperbolic status |
|-----------|-----------|---------------|
| **Group-based rewards** | Evaluators can compare across rollouts from the same task | Not yet — would require `RolloutGroup` abstraction |
| **Shared mutable state** | `state` dict passed between evaluators for intermediate results | `state` key exists but is unused |
| **RubricGroup** | Combine multiple rubrics into one | Not yet |
| **Auto-monitor rubrics** | Built-in metric tracking for common signals | Manual via `add_metric()` |
| **Class-based resource injection** | `add_class_object()` for sharing parsers, clients, etc. | Not yet |

### The philosophical difference

`verifiers` is optimized as **RL training plumbing** — it produces scalar rewards efficiently for GRPO training loops. Evaluation is a step in the pipeline, not a first-class product.

`hyperbolic` treats evaluation as a **diagnostic and analysis framework**. The multi-dimensional assessment, per-evaluator metadata, and live DOM access are designed to answer the question *"why did the model get this score?"* — not just *"what is the score?"*

---

## Exporting Results

After a run, you can export trajectories in different formats:

```python
trajectories = env.run(agent)

# Scalar format for GRPO / PPO
scalar_data = htc.TrajectoryLogger.export_scalar(trajectories)
# [{"episode_id": "...", "task": {...}, "reward": 0.85}, ...]

# Full assessments for analysis
assessment_data = htc.TrajectoryLogger.export_assessments(trajectories)
# [{"episode_id": "...", "task": {...}, "assessment": {"dimensions": ..., "scalar": ...}}, ...]

# Save to file
htc.TrajectoryLogger.save_batch(trajectories, "batch.jsonl", fmt="jsonl")
htc.TrajectoryLogger.save_batch(trajectories, "batch.json", fmt="json")
```
