"""Tests for core data types."""

from hyperbolic.types import Assessment, EvalResult, Step, Trajectory


def test_eval_result_defaults():
    r = EvalResult(score=0.75)
    assert r.score == 0.75
    assert r.metadata == {}


def test_assessment_to_dict():
    a = Assessment(dimensions={"acc": 1.0, "tone": 0.5}, scalar=0.75)
    d = a.to_dict()
    assert d["scalar"] == 0.75
    assert d["dimensions"]["acc"] == 1.0
    assert d["metadata"] == {}


def test_step_strips_binary():
    s = Step(step_num=0, observation={"url": "http://x", "screenshot_bytes": b"\x89PNG"})
    d = s.to_dict()
    assert isinstance(d["observation"]["screenshot_bytes"], str)
    assert "bytes" in d["observation"]["screenshot_bytes"]


def test_trajectory_scalar_reward_without_assessment():
    t = Trajectory(episode_id="ep1", task={"q": "hi"})
    assert t.scalar_reward == 0.0


def test_trajectory_scalar_reward_with_assessment():
    t = Trajectory(
        episode_id="ep1",
        task={"q": "hi"},
        assessment=Assessment(scalar=0.9),
    )
    assert t.scalar_reward == 0.9


def test_trajectory_to_dict_strips_images():
    msgs = [
        {"role": "user", "content": [
            {"type": "text", "text": "look at this"},
            {"type": "image_url", "image_url": {"url": "data:image/png;base64,AAAA"}},
        ]},
        {"role": "assistant", "content": "I see it"},
    ]
    t = Trajectory(episode_id="ep1", task={}, completion=msgs)
    d = t.to_dict()
    img_part = d["completion"][0]["content"][1]
    assert img_part["image_url"]["url"] == "[screenshot]"
