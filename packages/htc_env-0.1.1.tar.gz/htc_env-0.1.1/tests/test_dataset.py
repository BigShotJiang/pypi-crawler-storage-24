"""Tests for Dataset loading and manipulation."""

from hyperbolic.dataset import Dataset, _parse_hf_shorthand


def test_from_list():
    ds = Dataset.from_list([{"q": "hi"}, {"q": "bye"}])
    assert len(ds) == 2
    assert ds[0]["q"] == "hi"


def test_iteration():
    ds = Dataset.from_list([{"a": 1}, {"a": 2}, {"a": 3}])
    assert [t["a"] for t in ds] == [1, 2, 3]


def test_select():
    ds = Dataset.from_list([{"i": i} for i in range(10)])
    sub = ds.select(range(3))
    assert len(sub) == 3
    assert sub[2]["i"] == 2


def test_parse_hf_shorthand_plain():
    name, split, n = _parse_hf_shorthand("openai/gsm8k", "train", -1)
    assert name == "openai/gsm8k"
    assert split == "train"
    assert n == -1


def test_parse_hf_shorthand_with_split():
    name, split, n = _parse_hf_shorthand("openai/gsm8k:test", "train", -1)
    assert name == "openai/gsm8k"
    assert split == "test"
    assert n == -1


def test_parse_hf_shorthand_with_split_and_n():
    name, split, n = _parse_hf_shorthand("openai/gsm8k:test:50", "train", -1)
    assert name == "openai/gsm8k"
    assert split == "test"
    assert n == 50


def test_parse_hf_shorthand_with_hf_slice():
    name, split, n = _parse_hf_shorthand("openai/gsm8k:test[:50]", "train", -1)
    assert name == "openai/gsm8k"
    assert split == "test[:50]"
    assert n == -1
