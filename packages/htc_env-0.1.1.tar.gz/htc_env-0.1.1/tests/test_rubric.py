"""Tests for Rubric evaluation pipeline."""

from hyperbolic.rubric import Rubric
from hyperbolic.types import EvalResult, Trajectory


def _make_trajectory(content: str = "hello") -> Trajectory:
    return Trajectory(
        episode_id="test",
        task={"question": "say hi", "answer": "hello"},
        completion=[
            {"role": "user", "content": "say hi"},
            {"role": "assistant", "content": content},
        ],
    )


def test_empty_rubric():
    rubric = Rubric()
    t = _make_trajectory()
    result = rubric.evaluate(t, t.task)
    assert result.scalar == 0.0
    assert result.dimensions == {}


def test_single_evaluator():
    def always_one(completion, answer):
        return 1.0

    rubric = Rubric(funcs=[always_one])
    t = _make_trajectory()
    result = rubric.evaluate(t, t.task)
    assert result.scalar == 1.0


def test_weighted_evaluators():
    def score_a(completion):
        return 1.0

    def score_b(completion):
        return 0.0

    rubric = Rubric()
    rubric.add(score_a, weight=0.5, dimension="a")
    rubric.add(score_b, weight=0.5, dimension="b")

    t = _make_trajectory()
    result = rubric.evaluate(t, t.task)
    assert abs(result.scalar - 0.5) < 1e-9
    assert result.dimensions["a"] == 1.0
    assert result.dimensions["b"] == 0.0


def test_zero_weight_metric():
    def track_length(completion):
        return len(completion[-1]["content"])

    rubric = Rubric()
    rubric.add_metric(track_length, dimension="length")

    t = _make_trajectory("hello world")
    result = rubric.evaluate(t, t.task)
    assert result.scalar == 0.0
    assert result.dimensions["length"] == 11


def test_eval_result_with_metadata():
    def fancy_eval(completion):
        return EvalResult(score=0.8, metadata={"detail": "nice"})

    rubric = Rubric()
    rubric.add(fancy_eval, weight=1.0, dimension="fancy")

    t = _make_trajectory()
    result = rubric.evaluate(t, t.task)
    assert result.scalar == 0.8
    assert result.metadata["fancy"]["detail"] == "nice"


def test_signature_injection():
    def needs_answer(answer):
        return 1.0 if answer == "hello" else 0.0

    def needs_trajectory(trajectory):
        return 1.0 if len(trajectory.steps) == 0 else 0.5

    rubric = Rubric()
    rubric.add(needs_answer, weight=0.5, dimension="answer_check")
    rubric.add(needs_trajectory, weight=0.5, dimension="traj_check")

    t = _make_trajectory()
    result = rubric.evaluate(t, t.task)
    assert result.dimensions["answer_check"] == 1.0
    assert result.dimensions["traj_check"] == 1.0
