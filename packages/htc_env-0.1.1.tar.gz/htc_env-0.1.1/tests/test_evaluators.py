"""Tests for deterministic evaluators."""

from hyperbolic.evaluators.deterministic import (
    ExactMatch,
    RegexMatch,
    MathVerify,
    URLMatch,
    HeuristicScorer,
)


def _msgs(text: str) -> list[dict]:
    return [{"role": "assistant", "content": text}]


def test_exact_match_case_insensitive():
    e = ExactMatch()
    assert e(_msgs("Hello"), "hello") == 1.0
    assert e(_msgs("world"), "hello") == 0.0


def test_exact_match_case_sensitive():
    e = ExactMatch(case_sensitive=True)
    assert e(_msgs("Hello"), "Hello") == 1.0
    assert e(_msgs("hello"), "Hello") == 0.0


def test_exact_match_strips():
    e = ExactMatch(strip=True)
    assert e(_msgs("  hello  "), "hello") == 1.0


def test_exact_match_no_answer():
    e = ExactMatch()
    assert e(_msgs("anything"), None) == 0.0


def test_regex_match():
    e = RegexMatch(pattern=r"\d{3}")
    assert e(_msgs("code is 123")) == 1.0
    assert e(_msgs("no digits")) == 0.0


def test_regex_match_uses_answer_as_pattern():
    e = RegexMatch()
    assert e(_msgs("hello world"), r"world") == 1.0


def test_math_verify_boxed():
    e = MathVerify()
    assert e(_msgs(r"The answer is \boxed{42}"), "42") == 1.0
    assert e(_msgs(r"The answer is \boxed{43}"), "42") == 0.0


def test_math_verify_no_boxed():
    e = MathVerify()
    assert e(_msgs("just text"), "42") == 0.0


def test_url_match():
    e = URLMatch(pattern=r"/product/\d+")
    assert e(url="/product/123") == 1.0
    assert e(url="/cart") == 0.0
    assert e(url=None) == 0.0


def test_heuristic_scorer_length():
    e = HeuristicScorer(min_length=5, max_length=20)
    assert e(_msgs("hello world")) == 1.0
    assert e(_msgs("hi")) < 1.0
    assert e(_msgs("a" * 30)) < 1.0


def test_heuristic_scorer_keywords():
    e = HeuristicScorer(required_keywords=["python", "code"])
    assert e(_msgs("python code is great")) == 1.0
    assert e(_msgs("python is great")) == 0.5


def test_heuristic_scorer_forbidden():
    e = HeuristicScorer(forbidden_keywords=["error"])
    assert e(_msgs("all good")) == 1.0
    assert e(_msgs("error occurred")) == 0.0
