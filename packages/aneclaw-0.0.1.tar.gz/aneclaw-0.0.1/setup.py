from setuptools import setup

setup(
    name="aneclaw",
    version="0.0.1",
    description="ANE-native AI agent for Apple Silicon. 100% local, 3W, zero cloud.",
    long_description="# ANEClaw\n\nANE-native AI agent for Apple Silicon. Coming soon.\n\nhttps://github.com/0xbrando/aneclaw",
    long_description_content_type="text/markdown",
    author="Hoshi Labs",
    author_email="yurimoraxo@gmail.com",
    url="https://github.com/0xbrando/aneclaw",
    py_modules=["aneclaw"],
    python_requires=">=3.10",
    license="MIT",
    classifiers=[
        "Development Status :: 1 - Planning",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Operating System :: MacOS",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
)
