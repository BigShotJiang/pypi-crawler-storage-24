﻿import sys

# Initialize first
sys.stdout.buffer.write(b'{"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": "2024-11-05", "capabilities": {}, "clientInfo": {"name": "test", "version": "1.0"}}}\n')
sys.stdout.flush()

import time
time.sleep(0.5)

# Send initialized notification
sys.stdout.buffer.write(b'{"jsonrpc": "2.0", "method": "notifications/initialized"}\n')
sys.stdout.flush()

time.sleep(0.5)

# Now send crash payload with invalid UTF-8 bytes
sys.stdout.buffer.write(b'{"jsonrpc": "2.0", "id": 2, "method": "tools/call", "params": {"name": "fetch", "arguments": {"url": "http://test\xef\xbf\xbd.com"}}}\n')
sys.stdout.flush()
