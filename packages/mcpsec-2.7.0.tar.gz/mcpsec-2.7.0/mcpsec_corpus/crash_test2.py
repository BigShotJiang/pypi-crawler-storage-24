﻿import sys
import time

# Initialize
sys.stdout.buffer.write(b'{"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": "2024-11-05", "capabilities": {}, "clientInfo": {"name": "test", "version": "1.0"}}}\n')
sys.stdout.flush()
time.sleep(1)

# Initialized notification
sys.stdout.buffer.write(b'{"jsonrpc": "2.0", "method": "notifications/initialized"}\n')
sys.stdout.flush()
time.sleep(0.5)

# Crash payload with invalid bytes
sys.stdout.buffer.write(b'{"jsonrpc": "2.0", "id": 2, "method": "tools/call", "params": {"name": "fetch", "arguments": {"url": "http://test\xff\xfe.com"}}}\n')
sys.stdout.flush()

# Wait for response
time.sleep(3)
