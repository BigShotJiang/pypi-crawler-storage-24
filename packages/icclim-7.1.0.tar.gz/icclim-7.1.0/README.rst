|logo|
======

|build| |pypi| |ruff| |docs| |conda| |coverage| |doi|

icclim is a Python library to compute climate indices.
icclim name stands for index, calculation, climate.

Installation
------------

From conda-forge (recommended): ``conda install -c conda-forge icclim``.

From pypi: ``pip install icclim``.

From sources:
    - Clone the repository ``git clone https://github.com/cerfacs-globc/icclim.git``
    - Install icclim ``pip install .``

Compatibility
-------------

icclim is designed to be highly compatible across the Python scientific ecosystem:

- **Python**: Supports **Python 3.10 and above**.
- **Backward Compatibility**: Supports older stable versions (e.g., ``numpy>=1.21``, ``xarray>=2022.6``, ``xclim>=0.45``).
- **Bleeding Edge**: Fully verified and recommended to run on the latest major versions, including **Zarr 3.x**, **Pandas 3.x**, and **Xarray 2026.x**.

For production environments, we recommend keeping your dependencies updated to their latest stable releases to benefit from the latest optimizations and features.

How to use icclim
-----------------

Let's count the number of days above 25°C for each year, which corresponds to the index ``SU``, from a `tasmax` variable scattered in multiple netcdf files.

`SU` is one of the many index that can be computed with icclim. See `the documentation <https://icclim.readthedocs.io/en/latest/explanation/climate_indices.html#icclim-capabilities>`_ to explore what other index you can compute with icclim.

.. code-block:: python

    import icclim

    summer_days = icclim.su(
        "netcdf_files/tasmax_1990-2100.nc", out_file="summer_days.nc"
    )

For more examples on how to use icclim, see icclim's `How to ... <https://icclim.readthedocs.io/en/latest/how_to/index.html>`_ documentation or
`our notebooks <https://icclim.readthedocs.io/en/latest/tutorials/index.html>`_.


Who use icclim
--------------

icclim is part of `C4I platform <https://www.climate4impact.eu>`_ backend and is integrated in `CLIPC Portal <http://www.clipc.eu>`_.
icclim is also used by independent researchers.


Who made icclim
---------------

icclim has always been an open source project and was successfully made thanks to the joint effort of all its contributors.
The lead development is made at `CERFACS <https://cerfacs.fr/en/>`_, a research institution located in Toulouse, France.

Grants
~~~~~~
This open-source project has been possible thanks to funding by the European Commission projects:

* FP7 CLIPC (2013-2016)
* FP7 IS-ENES2 (2013-2017)
* H2020 EUDAT2020 (2015-2018)
* H2020 IS-ENES3 (2019-2023)

This project also receives funding from Agence Nationale de la Recherche - France 2030 as part of the PEPR TRACCS programme under grant number ANR-22-EXTR-0003 (PC2-INVEST 2024-2032).

The beautiful icclim logo is a creation of `Carole Petetin <https://carolepetetin.com>`_ and has been funded by the H2020 `IS-ENES3 <https://is.enes.org>`_ project grant agreement No 824084 (2019-2023).


Indices
-------
For a detailed description of each ECA&D index, please visit: https://www.ecad.eu/documents/atbd.pdf

..
  Pytest Coverage Comment:Begin

.. |coverage| image:: https://img.shields.io/badge/Coverage-85%25-green.svg
        :target: https://github.com/cerfacs-globc/icclim/blob/master/README.rst#code-coverage
        :alt: Code coverage

..
  Pytest Coverage Comment:End


.. |docs| image:: https://readthedocs.org/projects/icclim/badge/?version=latest
        :target: https://icclim.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status

.. |pypi| image:: https://img.shields.io/pypi/v/icclim.svg
        :target: https://pypi.python.org/pypi/icclim
        :alt: Python Package Index Build

.. |build| image:: https://github.com/cerfacs-globc/icclim/actions/workflows/ci.yml/badge.svg?branch=master
        :target: https://github.com/cerfacs-globc/icclim/actions/workflows/ci.yml
        :alt: Build Status

.. |conda| image:: https://img.shields.io/conda/vn/conda-forge/icclim.svg
        :target: https://anaconda.org/conda-forge/icclim
        :alt: Conda-forge Build Version

.. |doi| image:: https://zenodo.org/badge/15936714.svg
        :target: https://zenodo.org/badge/latestdoi/15936714
        :alt: D.O.I link

.. |logo| image:: https://github.com/cerfacs-globc/icclim/raw/master/doc/source/_static/logo_icclim_colored__displayed.svg
        :target: https://github.com/cerfacs-globc/icclim
        :alt: icclim
        :width: 200px

.. |ruff| image:: https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json
        :target: https://github.com/astral-sh/ruff
        :alt: Ruff
