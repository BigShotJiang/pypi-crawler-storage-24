<!--
Copyright (C) 2023 Maxwell G <maxwell@gtmx.me>

SPDX-License-Identifier: GPL-2.0-or-later
-->

# fedrq.backends.libdnf5.backend

::: fedrq.backends.libdnf5.backend
    options:
        members:
            - BACKEND
            - BaseMaker
            - Package
            - PackageQuery
            - RepoError
            - Repoquery
            - StrIter
            - IntIter
            - _QueryFilterKwargs
            - NEVRAForms
            - get_releasever
        inherited_members: true
        group_by_category: false

## See also

- [`libdnf5.base.Base`][libdnf5.base.Base]
- [`libdnf5.rpm.Package`][libdnf5.rpm.Package]
- [`libdnf5.rpm.PackageQuery`][libdnf5.rpm.PackageQuery]
