"""ATP - Agent Transfer Protocol."""

__version__ = "1.0.0a3"
