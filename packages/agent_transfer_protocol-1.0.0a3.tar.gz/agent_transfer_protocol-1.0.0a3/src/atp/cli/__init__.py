"""ATP CLI package."""
