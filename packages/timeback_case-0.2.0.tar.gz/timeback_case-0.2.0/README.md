# timeback-case

Timeback CASE (Competency and Academic Standards Exchange) client for Python.

Provides an async client for managing CASE v1.1 framework documents, items, associations, and packages.

## Installation

```bash
pip install timeback-case
```

## Quick Start

```python
from timeback_case import CaseClient

async with CaseClient(env="staging", client_id="...", client_secret="...") as client:
    # List documents
    docs = await client.documents.list()

    # Get a single item
    item = await client.items.get("item-sourced-id")

    # Upload a CASE package
    result = await client.packages.create(package_input)

    # Upsert (create or replace) a package
    result = await client.packages.upsert("doc-id", package_input)
```
