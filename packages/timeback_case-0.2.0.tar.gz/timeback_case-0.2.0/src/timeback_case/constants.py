"""
CASE Constants

Configuration constants for the CASE client.
"""

SERVICE_NAME = "case"
