"""
CASE Exceptions

Re-exports common errors and adds CASE-specific exceptions.
"""

from timeback_common import (
    APIError,
    AuthenticationError,
    ForbiddenError,
    InputValidationError,
    NotFoundError,
    RateLimitError,
    ServerError,
    TimebackError,
    ValidationError,
    ValidationIssue,
    create_input_validation_error,
)

CaseError = TimebackError


__all__ = [
    "APIError",
    "AuthenticationError",
    "CaseError",
    "ForbiddenError",
    "InputValidationError",
    "NotFoundError",
    "RateLimitError",
    "ServerError",
    "TimebackError",
    "ValidationError",
    "ValidationIssue",
    "create_input_validation_error",
]
