"""
CASE Base Types

Common types shared across CASE resources.
"""
