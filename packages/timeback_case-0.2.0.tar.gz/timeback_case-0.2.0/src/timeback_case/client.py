"""
Timeback CASE Client

Async client for CASE (Competency and Academic Standards Exchange) v1.1 operations.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal, Protocol, cast

from .lib.transport import Transport
from .resources.associations import AssociationsResource
from .resources.documents import DocumentsResource
from .resources.items import ItemsResource
from .resources.packages import PackagesResource

if TYPE_CHECKING:
    from timeback_common import AuthCheckResult, CasePaths, Environment, TimebackProvider

Platform = Literal["BEYOND_AI", "LEARNWITH_AI"]


class CaseTransportLike(Protocol):
    """Duck-typed transport interface for custom transports."""

    base_url: str
    paths: CasePaths

    async def close(self) -> None: ...


class CaseClient:
    """
    CASE API client for Competency and Academic Standards Exchange management.

    Provides access to CASE framework documents, items, associations, and packages.
    """

    def __init__(
        self,
        *,
        platform: Platform | None = None,
        env: str | None = None,
        transport: CaseTransportLike | None = None,
        base_url: str | None = None,
        auth_url: str | None = None,
        client_id: str | None = None,
        client_secret: str | None = None,
        timeout: float = 30.0,
        provider: TimebackProvider | None = None,
    ) -> None:
        self._transport: Transport | CaseTransportLike
        if transport is not None:
            self._transport = transport
            self._provider = None
        else:
            from timeback_common import EnvVarNames, build_provider_env, build_provider_explicit

            env_vars = EnvVarNames(
                base_url=("TIMEBACK_API_BASE_URL", "TIMEBACK_BASE_URL", "CASE_BASE_URL"),
                auth_url=(
                    "TIMEBACK_API_AUTH_URL",
                    "TIMEBACK_AUTH_URL",
                    "CASE_TOKEN_URL",
                ),
                client_id=(
                    "TIMEBACK_API_CLIENT_ID",
                    "TIMEBACK_CLIENT_ID",
                    "CASE_CLIENT_ID",
                ),
                client_secret=(
                    "TIMEBACK_API_CLIENT_SECRET",
                    "TIMEBACK_CLIENT_SECRET",
                    "CASE_CLIENT_SECRET",
                ),
            )

            if provider is None:
                if env is not None:
                    provider = build_provider_env(
                        platform=platform,
                        env=cast("Environment", env),
                        client_id=client_id,
                        client_secret=client_secret,
                        timeout=timeout,
                        env_vars=env_vars,
                    )
                else:
                    provider = build_provider_explicit(
                        base_url=base_url,
                        auth_url=auth_url,
                        client_id=client_id,
                        client_secret=client_secret,
                        timeout=timeout,
                        env_vars=env_vars,
                    )

            self._provider = provider

            endpoint = provider.get_endpoint("case")
            paths = provider.get_paths("case")
            token_manager = provider.get_token_manager("case")

            self._transport = Transport(
                base_url=endpoint.base_url,
                token_manager=token_manager,
                paths=paths,
                timeout=provider.timeout,
                no_auth=token_manager is None,
            )

        if not hasattr(self._transport, "paths"):
            raise TypeError(
                "Custom transport must have a 'paths' attribute with CASE path "
                "configuration. Use the CASE Transport class or ensure your "
                "transport includes a CasePaths instance."
            )

        _transport = cast("Transport", self._transport)
        self.documents = DocumentsResource(_transport)
        self.items = ItemsResource(_transport)
        self.associations = AssociationsResource(_transport)
        self.packages = PackagesResource(_transport)

    def get_transport(self) -> Transport | CaseTransportLike:
        """Get the underlying transport for advanced use cases."""
        return self._transport

    async def check_auth(self) -> AuthCheckResult:
        """
        Verify that OAuth authentication is working.

        Raises:
            RuntimeError: If client was initialized without a provider
        """
        if self._provider is None:
            raise RuntimeError("Cannot check auth: client initialized without provider")
        return await self._provider.check_auth()

    async def close(self) -> None:
        """Close the HTTP client and release resources."""
        await self._transport.close()

    async def __aenter__(self) -> CaseClient:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: object | None,
    ) -> None:
        await self.close()
