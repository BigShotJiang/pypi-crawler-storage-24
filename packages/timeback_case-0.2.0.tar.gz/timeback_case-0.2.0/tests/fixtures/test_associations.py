"""Fixture-driven tests for CASE associations resource."""

from __future__ import annotations

from test_support.fixtures import fixtures_dir, make_resource_fixture_test
from timeback_case.lib.testing import create_recording_transport
from timeback_case.resources.associations import AssociationsResource

FIXTURES_DIR = fixtures_dir("case", "associations")


def _setup(
    fail_request: dict[str, object] | None, transport_config: dict[str, object] | None
) -> dict[str, object]:
    transport = create_recording_transport(fail_request, transport_config)
    return {"resource": AssociationsResource(transport), "calls": transport.calls}


test_case_associations_fixtures = make_resource_fixture_test(
    name="case > associations",
    fixtures_dir=FIXTURES_DIR,
    setup=_setup,
)
