"""
SimGen - High-Precision GPU Computing
======================================

Exact arithmetic on GPU with zero accumulation error.

Website: https://simgen.dev
License: Proprietary - All rights reserved
"""

from .vla import __version__
__author__ = "Clouthier Simulation Labs"

from . import vla

__all__ = [
    "vla",
    "__version__",
]
