"""
SimGen VLA - Pre-compiled CUDA Cubin Loader
============================================

Loads pre-compiled .cubin files for the user's GPU architecture.
No compilation needed on user's machine - just load and run.

Clouthier Simulation Labs | simgen.dev
"""

import os
import sys

try:
    import cupy as cp
    HAS_CUPY = True
except ImportError:
    HAS_CUPY = False
    cp = None

# Directory containing this file
_HERE = os.path.dirname(os.path.abspath(__file__))
_CUBIN_DIR = os.path.join(_HERE, 'cubin')
_CUBIN_DIR_LINUX = os.path.join(_HERE, 'cubin_linux')
_MODULE = None
_KERNELS = {}

# Supported architectures (in preference order - newest first)
SUPPORTED_ARCHS = [90, 89, 80, 75, 70, 60]


def _get_gpu_arch():
    """Get the compute capability of the current GPU."""
    if not HAS_CUPY:
        return None
    try:
        device = cp.cuda.Device()
        props = cp.cuda.runtime.getDeviceProperties(device.id)
        major = props['major']
        minor = props['minor']
        return major * 10 + minor
    except Exception:
        return None


def _find_cubin_dir():
    """Find the cubin directory (Windows or Linux)."""
    # Check platform-specific first
    if sys.platform.startswith('linux'):
        if os.path.isdir(_CUBIN_DIR_LINUX):
            return _CUBIN_DIR_LINUX

    # Fall back to generic cubin dir (Windows)
    if os.path.isdir(_CUBIN_DIR):
        return _CUBIN_DIR

    return None


def _find_compatible_cubin(gpu_arch):
    """Find the best compatible cubin for the GPU architecture."""
    cubin_dir = _find_cubin_dir()
    if not cubin_dir:
        return None, None

    # Look for exact match first
    exact_path = os.path.join(cubin_dir, f'fixedpoint_sm{gpu_arch}.cubin')
    if os.path.exists(exact_path):
        return exact_path, gpu_arch

    # Find best compatible (lower or equal arch)
    for arch in SUPPORTED_ARCHS:
        if arch <= gpu_arch:
            path = os.path.join(cubin_dir, f'fixedpoint_sm{arch}.cubin')
            if os.path.exists(path):
                return path, arch

    # Last resort: any cubin
    for arch in SUPPORTED_ARCHS:
        path = os.path.join(cubin_dir, f'fixedpoint_sm{arch}.cubin')
        if os.path.exists(path):
            return path, arch

    return None, None


def get_module():
    """Load the CUDA module from pre-compiled cubin."""
    global _MODULE

    if _MODULE is not None:
        return _MODULE

    if not HAS_CUPY:
        raise RuntimeError("CuPy is required. Install with: pip install cupy-cuda12x")

    gpu_arch = _get_gpu_arch()
    if gpu_arch is None:
        raise RuntimeError("No CUDA GPU detected")

    cubin_path, used_arch = _find_compatible_cubin(gpu_arch)

    if cubin_path is None:
        raise RuntimeError(
            f"No compatible cubin found for GPU sm_{gpu_arch}. "
            f"Available architectures: {SUPPORTED_ARCHS}"
        )

    # Load the cubin
    _MODULE = cp.RawModule(path=cubin_path)

    # Log info
    device = cp.cuda.Device()
    props = cp.cuda.runtime.getDeviceProperties(device.id)
    gpu_name = props['name'].decode() if isinstance(props['name'], bytes) else props['name']

    print(f"VLA: Loaded cubin sm_{used_arch} for {gpu_name} (sm_{gpu_arch})")

    return _MODULE


def get_kernel(name):
    """Get a kernel function by name."""
    global _KERNELS

    if name not in _KERNELS:
        module = get_module()
        _KERNELS[name] = module.get_function(name)

    return _KERNELS[name]


def list_available_cubins():
    """List all available cubin files."""
    cubin_dir = _find_cubin_dir()
    if not cubin_dir:
        return []

    cubins = []
    for f in os.listdir(cubin_dir):
        if f.endswith('.cubin'):
            cubins.append(os.path.join(cubin_dir, f))

    return cubins


# Kernel names available in the cubin
KERNEL_NAMES = [
    'fp_from_double_kernel',
    'fp_to_double_kernel',
    'fp_add_kernel',
    'fp_sub_kernel',
    'fp_mul_kernel',
    'fp_div_kernel',
    'fp_neg_kernel',
    'fp_abs_kernel',
    'fp_eq_kernel',
    'fp_lt_kernel',
    'fp_gt_kernel',
    'fp_le_kernel',
    'fp_ge_kernel',
    'fp_ne_kernel',
    'fp_sum_reduce_kernel',
    'fp_prod_reduce_kernel',
    'fp_max_reduce_kernel',
    'fp_min_reduce_kernel',
    'fp_dot_kernel',
    'fp_mm_kernel',
    'fp_mv_kernel',
    'fp_sign_kernel',
    'fp_square_kernel',
    'fp_reciprocal_kernel',
    'fp_relu_kernel',
    'fp_leaky_relu_kernel',
    'fp_pow_int_kernel',
    'fp_clamp_kernel',
    'fp_where_kernel',
    'fp_copy_kernel',
    'fp_transpose_kernel',
    'fp_add_scalar_kernel',
    'fp_sub_scalar_kernel',
    'fp_mul_scalar_kernel',
    'fp_div_scalar_kernel',
    'fp_cumsum_kernel',
    'fp_cumprod_kernel',
    'fp_zeros_kernel',
    'fp_ones_kernel',
    'fp_eye_kernel',
    'fp_arange_kernel',
    'fp_outer_kernel',
    'fp_trace_kernel',
    'fp_diag_kernel',
    'fp_kron_kernel',
    'fp_spmv_kernel',
    'fp_dense_to_csr_count_kernel',
    'fp_dense_to_csr_extract_kernel',
]
