"""
SimGen VLA - GPU Exact Arithmetic
==================================
Clouthier Simulation Labs | simgen.dev

Drop-in replacement with exact arithmetic.
99 GPU-accelerated operations. Zero accumulation error.
"""

__version__ = "6.2.5"  # Fix copy_from_host pointer

# All exports from vla.py (GPU fixed-point)
from .vla import (
    # Core
    Tensor, tensor, zeros, ones, eye, arange, linspace, rand, randn, manual_seed,
    # Arithmetic
    add, sub, mul, div, neg, abs, sign, pow, mod, reciprocal,
    # Comparison
    eq, lt, gt, le, ge, ne,
    # Reduction
    sum, prod, max, min, mean, std, var, norm,
    # Linear algebra
    dot, mm, mv, bmm, matmul, outer, kron, trace, diag, det, inv, lu, solve,
    # Sparse
    SparseTensor, sparse_mv,
    # Activations
    relu, leaky_relu, sigmoid, tanh, gelu, silu, softmax,
    # Transcendental
    exp, log, log2, log10, sqrt,
    sin, cos, tan, sinh, cosh,
    asin, acos, atan, atan2, asinh, acosh, atanh,
    # Rounding
    ceil, floor, round, trunc, frac,
    # Convolution
    conv2d,
    # Cumulative
    cumsum, cumprod, diff,
    # Index
    argmax, argmin,
    # Shape
    reshape, squeeze, unsqueeze, transpose, cat, stack,
    # Misc
    clamp, where, lerp,
    # Logical
    logical_and, logical_or, logical_not, logical_xor,
    # Verification
    checksum, checksums_match, verify,
    # Config
    SCALE_BITS, NUM_LIMBS, SCALE,
)

__all__ = [
    '__version__',
    # Core
    'Tensor', 'tensor', 'zeros', 'ones', 'eye', 'arange', 'linspace', 'rand', 'randn', 'manual_seed',
    # Arithmetic
    'add', 'sub', 'mul', 'div', 'neg', 'abs', 'sign', 'pow', 'mod', 'reciprocal',
    # Comparison
    'eq', 'lt', 'gt', 'le', 'ge', 'ne',
    # Reduction
    'sum', 'prod', 'max', 'min', 'mean', 'std', 'var', 'norm',
    # Linear algebra
    'dot', 'mm', 'mv', 'bmm', 'matmul', 'outer', 'kron', 'trace', 'diag', 'det', 'inv', 'lu', 'solve',
    # Sparse
    'SparseTensor', 'sparse_mv',
    # Activations
    'relu', 'leaky_relu', 'sigmoid', 'tanh', 'gelu', 'silu', 'softmax',
    # Transcendental
    'exp', 'log', 'log2', 'log10', 'sqrt',
    'sin', 'cos', 'tan', 'sinh', 'cosh',
    'asin', 'acos', 'atan', 'atan2', 'asinh', 'acosh', 'atanh',
    # Rounding
    'ceil', 'floor', 'round', 'trunc', 'frac',
    # Convolution
    'conv2d',
    # Cumulative
    'cumsum', 'cumprod', 'diff',
    # Index
    'argmax', 'argmin',
    # Shape
    'reshape', 'squeeze', 'unsqueeze', 'transpose', 'cat', 'stack',
    # Misc
    'clamp', 'where', 'lerp',
    # Logical
    'logical_and', 'logical_or', 'logical_not', 'logical_xor',
    # Verification
    'checksum', 'checksums_match', 'verify',
    # Config
    'SCALE_BITS', 'NUM_LIMBS', 'SCALE',
]
