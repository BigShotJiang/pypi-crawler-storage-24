"""Scanner module."""
