"""Report generation module."""
