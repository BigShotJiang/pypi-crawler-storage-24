"""Filesystem utilities."""

import logging
from pathlib import Path
from typing import List

logger = logging.getLogger(__name__)


def ensure_directories(dirs: List[Path]) -> None:
    """Create directories if they don't exist."""
    for directory in dirs:
        directory.mkdir(parents=True, exist_ok=True)
        logger.debug(f"Ensured directory exists: {directory}")


def find_files(root: Path, patterns: List[str]) -> List[Path]:
    """Recursively find files matching patterns."""
    found_files = []
    for pattern in patterns:
        found_files.extend(root.rglob(pattern))
    return found_files
