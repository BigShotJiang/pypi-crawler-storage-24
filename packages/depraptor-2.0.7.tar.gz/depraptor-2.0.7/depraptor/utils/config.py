"""Configuration and constants."""

from pathlib import Path
from typing import Dict, List

# Registry URLs
REGISTRIES: Dict[str, str] = {
    "pypi": "https://pypi.org/pypi/{package}/json",
    "npm": "https://registry.npmjs.org/{package}",
    "rubygems": "https://rubygems.org/api/v1/gems/{package}.json",
    "crates": "https://crates.io/api/v1/crates/{package}",
    "go": "https://proxy.golang.org/{package}/@v/list",
}

# Dependency file patterns
DEPENDENCY_FILES: Dict[str, List[str]] = {
    "python": ["requirements.txt", "setup.py", "pyproject.toml", "Pipfile"],
    "nodejs": ["package.json"],
    "ruby": ["Gemfile"],
    "go": ["go.mod"],
    "rust": ["Cargo.toml"],
}

# Working directories
def get_working_dirs() -> Dict[str, Path]:
    """Get working directory paths."""
    cwd = Path.cwd()
    return {
        "cwd": cwd,
        "repos": cwd / "repos",
        "results": cwd / "results",
        "pocs": cwd / "results" / "pocs",
        "logs": cwd / "results" / "logs",
    }
