"""Banner display utility."""

from rich.console import Console

BANNER = r"""
[bold cyan]
________                  __________                  __                  
\______ \    ____  ______ \______   \_____   ______ _/  |_  ____ _______  
 |    |  \ _/ __ \ \____ \ |       _/\__  \  \____ \\   __\/  _ \\_  __ \ 
 |    `   \\  ___/ |  |_> >|    |   \ / __ \_|  |_> >|  | (  <_> )|  | \/ 
/_______  / \___  >|   __/ |____|_  /(____  /|   __/ |__|  \____/ |__|    
        \/      \/ |__|           \/      \/ |__|                         
[/bold cyan]

[bold yellow]Dependency Confusion Scanner[/bold yellow]
[dim]Developer: LAKSHMIKANTHAN K (letchupkt)[/dim]
"""

def display_banner() -> None:
    """Display the DepRaptor banner."""
    console = Console()
    console.print(BANNER)
