"""
DepRaptor - Dependency Confusion Vulnerability Scanner
Developer: LAKSHMIKANTHAN K (letchupkt)
"""

__version__ = "2.0.0"
__author__ = "LAKSHMIKANTHAN K (letchupkt)"
