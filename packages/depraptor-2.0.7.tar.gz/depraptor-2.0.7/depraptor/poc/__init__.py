"""PoC generation module."""
