"""Modular payload system for PoC packages."""
