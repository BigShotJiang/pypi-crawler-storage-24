"""
Payload: custom
Placeholder for user-supplied payload code.
"""


def generate_payload(callback_url: str = "") -> str:
    """Return a minimal custom payload stub."""
    return f'''# Custom DepRaptor payload
# callback: {callback_url}
import os, socket
from pathlib import Path

def execute_payload():
    print("[DepRaptor] Custom payload executed.")
    print(f"  hostname : {{socket.gethostname()}}")
    print(f"  user     : {{os.getenv('USER') or os.getenv('USERNAME', 'unknown')}}")

execute_payload()
'''
