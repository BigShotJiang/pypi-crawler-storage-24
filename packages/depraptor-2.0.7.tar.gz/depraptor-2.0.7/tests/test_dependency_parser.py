"""Tests for dependency parser."""

import pytest
from pathlib import Path
from depraptor.scanner.dependency_parser import DependencyParser, Dependency


def test_dependency_creation():
    """Test Dependency object creation."""
    dep = Dependency("requests", "2.31.0", "pypi", "requirements.txt")
    assert dep.name == "requests"
    assert dep.version == "2.31.0"
    assert dep.ecosystem == "pypi"
    assert dep.source == "requirements.txt"


def test_dependency_to_dict():
    """Test Dependency to_dict method."""
    dep = Dependency("flask", "3.0.0", "pypi", "requirements.txt")
    result = dep.to_dict()
    assert result["name"] == "flask"
    assert result["version"] == "3.0.0"
    assert result["ecosystem"] == "pypi"
    assert result["source"] == "requirements.txt"
