"""Tests for confusion checker."""

import pytest
from depraptor.scanner.dependency_parser import Dependency
from depraptor.scanner.confusion_checker import VulnerableDependency, ConfusionChecker


def test_vulnerable_dependency_creation():
    """Test VulnerableDependency object creation."""
    dep = Dependency("test-package", "1.0.0", "pypi", "requirements.txt")
    vuln = VulnerableDependency(dep)
    assert vuln.dependency == dep
    assert vuln.is_vulnerable == False
    assert vuln.reason == ""


def test_vulnerable_dependency_to_dict():
    """Test VulnerableDependency to_dict method."""
    dep = Dependency("test-package", "1.0.0", "pypi", "requirements.txt")
    vuln = VulnerableDependency(dep)
    vuln.is_vulnerable = True
    vuln.reason = "Package not found"
    
    result = vuln.to_dict()
    assert result["name"] == "test-package"
    assert result["is_vulnerable"] == True
    assert result["reason"] == "Package not found"
