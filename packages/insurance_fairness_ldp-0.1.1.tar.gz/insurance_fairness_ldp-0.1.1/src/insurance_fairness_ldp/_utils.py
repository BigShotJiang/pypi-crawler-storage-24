"""
Internal utility functions for insurance-fairness-ldp.

Not part of the public API.
"""

from __future__ import annotations

import numpy as np


def pi_from_epsilon(epsilon: float, k: int) -> float:
    """Compute the k-RR truth probability pi from epsilon.

    For a k-category randomised response mechanism with privacy parameter
    epsilon, the probability of reporting the true category is::

        pi = exp(epsilon) / (k - 1 + exp(epsilon))

    Parameters
    ----------
    epsilon:
        Privacy budget (> 0).
    k:
        Number of categories.

    Returns
    -------
    float
        Truth probability pi in (1/k, 1).
    """
    exp_eps = np.exp(epsilon)
    return float(exp_eps / (k - 1 + exp_eps))


def epsilon_from_pi(pi: float, k: int) -> float:
    """Infer epsilon from a known truth probability pi.

    Inverse of :func:`pi_from_epsilon`::

        epsilon = ln(pi * (k - 1) / (1 - pi))

    Parameters
    ----------
    pi:
        Truth probability. Must be in (1/k, 1).
    k:
        Number of categories.

    Returns
    -------
    float
        Inferred epsilon.

    Raises
    ------
    ValueError
        If pi is outside the valid range.
    """
    lower = 1.0 / k
    if not (lower < pi < 1.0):
        raise ValueError(
            f"pi must be in (1/k, 1) = ({lower:.4f}, 1). Got pi={pi:.4f}. "
            "pi=1/k corresponds to eps=0 (pure noise, singular correction). "
            "pi=1 corresponds to eps=inf (no noise)."
        )
    return float(np.log(pi * (k - 1) / (1.0 - pi)))


def accuracy_constant(pi: float, k: int) -> float:
    """Compute the privacy-accuracy constant C1.

    C1 appears in the generalisation bound of Zhang/Liu/Shi Theorem 4.3::

        C1 = (pi + k - 2) / (k * pi - 1)

    C1 >= 1 always (equals 1 only when pi=1, i.e. no noise).
    C1 -> infinity as pi -> 1/k (maximum noise).

    Parameters
    ----------
    pi:
        Truth probability.
    k:
        Number of categories.

    Returns
    -------
    float
        Accuracy constant C1.
    """
    return float((pi + k - 2) / (k * pi - 1))


def clip_and_renormalise(probs: np.ndarray) -> np.ndarray:
    """Clip negative pseudo-probabilities to zero and renormalise.

    T^{-1} applied to empirical frequencies can produce negative entries
    (the correction matrix works with signed measures). This function clips
    negative values to zero and renormalises to a proper probability
    distribution.

    Parameters
    ----------
    probs:
        Array of pseudo-probabilities (may contain negative values).

    Returns
    -------
    np.ndarray
        Non-negative array summing to 1.
    """
    clipped = np.maximum(probs, 0.0)
    total = clipped.sum()
    if total <= 0.0:
        # Degenerate: return uniform distribution
        return np.ones(len(probs)) / len(probs)
    return clipped / total


def empirical_frequencies(s_private: np.ndarray, categories: list) -> np.ndarray:
    """Compute empirical frequency vector from privatised observations.

    Parameters
    ----------
    s_private:
        1-D array of observed (privatised) category values.
    categories:
        Ordered list of k category labels.

    Returns
    -------
    np.ndarray
        Array of shape (k,) with P_hat(S=j) for each j.
    """
    s_private = np.asarray(s_private)
    n = len(s_private)
    if n == 0:
        raise ValueError("s_private is empty.")
    freqs = np.array([np.sum(s_private == cat) / n for cat in categories])
    return freqs


def weighted_mean(values: np.ndarray, weights: np.ndarray) -> np.ndarray:
    """Compute weighted mean along axis 0.

    Parameters
    ----------
    values:
        2-D array of shape (k, n) where k is number of groups.
    weights:
        1-D array of shape (k,) with weights summing to 1.

    Returns
    -------
    np.ndarray
        1-D array of shape (n,) — weighted mixture of group predictions.
    """
    return np.einsum("k,kn->n", weights, values)


def safe_divide(numerator: np.ndarray, denominator: float) -> np.ndarray:
    """Divide by denominator, raising if denominator is near zero.

    Parameters
    ----------
    numerator:
        Array to divide.
    denominator:
        Scalar divisor.

    Returns
    -------
    np.ndarray
        Divided array.

    Raises
    ------
    ZeroDivisionError
        If |denominator| < 1e-12.
    """
    if abs(denominator) < 1e-12:
        raise ZeroDivisionError(
            f"Attempted division by near-zero denominator: {denominator}. "
            "This typically indicates an extremely small epsilon or degenerate "
            "group probability."
        )
    return numerator / denominator
