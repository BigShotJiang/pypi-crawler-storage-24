"""
Correction matrices for de-biasing LDP-perturbed distributions.

Two correction matrices are implemented:

**T^{-1}** (``T_inv``)
    Corrects the observed noisy frequency distribution back to an unbiased
    estimate of the true distribution P(D=k). Used to compute the reference
    distribution P*(D) in the Lindholm formula.

**Pi^{-1}** (``Pi_inv``)
    Corrects the group-specific empirical loss functions during model training.
    This is the heart of the Zhang/Liu/Shi method — instead of weighting losses
    by the true group indicator (which is unknown), we weight by privatised group
    indicators and apply Pi^{-1} to correct for the noise.

Mathematical background
-----------------------
Given true distribution p and noisy distribution q = T @ p (column-stochastic),
the correction is::

    p_hat = T^{-1} @ q_hat

where q_hat is the empirical noisy frequency vector.

T^{-1} has a closed form::

    T^{-1}_{ii} = (pi + k - 2) / (k * pi - 1)
    T^{-1}_{ij} = (pi - 1) / (k * pi - 1)  for i != j  (negative, since pi < 1)

Note: T^{-1} has unit row sums but may have negative off-diagonal entries. The
debiased pseudo-probabilities can be negative for small samples — this is
mathematically correct (a signed measure) but should be clipped if a proper
probability distribution is required.

References
----------
Zhang, Liu, Shi (2025). Discrimination-Free Insurance Pricing under Local
Differential Privacy. arXiv:2504.11775. Section 4.1, Equations (2)-(4).
"""

from __future__ import annotations

import warnings
from typing import Sequence

import numpy as np

from insurance_fairness_ldp._utils import accuracy_constant, clip_and_renormalise
from insurance_fairness_ldp._validators import (
    C1_WARN_THRESHOLD,
    validate_group_probs,
    validate_reference_dist,
)


class CorrectionMatrix:
    """Compute and apply the LDP correction matrices T^{-1} and Pi^{-1}.

    Given a k-RR mechanism (characterised by pi and k), this class provides
    the two correction matrices needed to implement the Zhang/Liu/Shi
    discrimination-free pricing estimator.

    Parameters
    ----------
    pi:
        Truth probability of the k-RR mechanism (P(S=d | D=d)).
        Must be in (1/k, 1).
    k:
        Number of categories.

    Attributes
    ----------
    pi:
        Truth probability.
    k:
        Number of categories.

    Examples
    --------
    >>> from insurance_fairness_ldp import KaryRandomisedResponse, CorrectionMatrix
    >>> krr = KaryRandomisedResponse(epsilon=1.0, categories=["A", "B", "C"])
    >>> cm = CorrectionMatrix(pi=krr.pi, k=krr.k)
    >>> T = krr.correction_matrix()
    >>> T_inv = cm.T_inv()
    >>> import numpy as np
    >>> np.allclose(T @ T_inv, np.eye(3), atol=1e-10)
    True
    """

    def __init__(self, pi: float, k: int) -> None:
        lower = 1.0 / k
        if not (lower < pi <= 1.0):
            raise ValueError(
                f"pi must be in (1/k, 1] = ({lower:.4f}, 1.0]. Got pi={pi:.4f}. "
                "pi <= 1/k means epsilon <= 0 and the correction matrix is singular."
            )
        self._pi = float(pi)
        self._k = int(k)

        # Check accuracy constant
        if pi < 1.0:
            c1 = accuracy_constant(pi, k)
            if c1 > C1_WARN_THRESHOLD:
                warnings.warn(
                    f"Accuracy constant C1={c1:.2f} > {C1_WARN_THRESHOLD}. "
                    "The correction will amplify noise substantially at this "
                    f"privacy level (pi={pi:.4f}, k={k}).",
                    UserWarning,
                    stacklevel=2,
                )

    @property
    def pi(self) -> float:
        """Truth probability."""
        return self._pi

    @property
    def k(self) -> int:
        """Number of categories."""
        return self._k

    def T_inv(self) -> np.ndarray:
        """Compute the inverse of the k-RR transition matrix T.

        The closed-form inverse of T is::

            T^{-1}_{ii} = (pi + k - 2) / (k * pi - 1)
            T^{-1}_{ij} = (pi - 1) / (k * pi - 1)  for i != j  (negative, since pi < 1)

        Returns
        -------
        np.ndarray
            Shape (k, k). May contain negative off-diagonal entries.

        Notes
        -----
        Row sums of T^{-1} equal 1, consistent with a signed measure on the
        simplex. When applied to a proper probability vector, the result may
        have negative entries — these are pseudo-probabilities that require
        clipping for use as a reference distribution.
        """
        k, pi = self._k, self._pi
        denom = k * pi - 1.0

        if abs(denom) < 1e-12:
            raise ZeroDivisionError(
                f"k*pi - 1 = {denom:.2e} is near zero. The correction matrix is "
                f"singular. Increase epsilon to ensure pi > 1/k strictly."
            )

        diag_val = (pi + k - 2.0) / denom
        off_val = (pi - 1.0) / denom

        T_inv = np.full((k, k), off_val)
        np.fill_diagonal(T_inv, diag_val)
        return T_inv

    def Pi_inv(self, group_probs: np.ndarray | Sequence[float]) -> np.ndarray:
        """Compute the group-reweighted correction matrix Pi^{-1}.

        Pi^{-1} extends T^{-1} to account for the marginal group distribution
        P(D=k). It is used to correct the group-specific empirical losses during
        model training.

        For each row i, column j of Pi^{-1}::

            Pi^{-1}_{ij} = T^{-1}_{ij} * w_{ij}

        where w_{ij} accounts for the reweighting by group probabilities. The
        precise formula from Zhang et al. Equation (4) ensures that when the
        corrected losses are summed over noisy group indicators, we recover the
        true group-conditional expected loss.

        In this implementation we use the row-normalised form::

            Pi^{-1}_{ij} = T^{-1}_{ij} * P(S=j) / P(D=i)

        where P(S=j) = sum_l T_{lj} * P(D=l) is the marginal noisy probability.

        Parameters
        ----------
        group_probs:
            Array of length k with P(D=j) (true marginal probabilities,
            estimated from debiased frequencies). Must be strictly positive.

        Returns
        -------
        np.ndarray
            Shape (k, k). Entry (i, j) is the correction weight applied to
            the empirical loss for group j when estimating group i's model.
        """
        p = validate_group_probs(np.asarray(group_probs, dtype=np.float64), self._k)
        T_inv = self.T_inv()

        # Reconstruct T from pi
        k, pi = self._k, self._pi
        pi_bar = (1.0 - pi) / (k - 1)
        T = np.full((k, k), pi_bar)
        np.fill_diagonal(T, pi)

        # Noisy marginal: P(S=j) = sum_i T[i,j] * p[i]  (column stochastic)
        # T[i,j] = P(S=j | D=i), so P(S=j) = sum_i T[i,j] * p[i]
        p_noisy = T.T @ p  # shape (k,)

        # Pi^{-1}_{ij} = T^{-1}_{ij} * p_noisy[j] / p[i]
        # Rows index the true group (i), columns index the noisy group (j)
        Pi_inv = T_inv * p_noisy[np.newaxis, :] / p[:, np.newaxis]
        return Pi_inv

    def debias_probs(
        self,
        noisy_probs: np.ndarray | Sequence[float],
        clip: bool = True,
    ) -> np.ndarray:
        """Apply T^{-1} to a noisy frequency vector to obtain debiased probabilities.

        Computes::

            p_hat = T^{-1} @ q_hat

        where q_hat is the observed noisy frequency vector.

        Parameters
        ----------
        noisy_probs:
            Array of shape (k,) with observed noisy frequencies P_hat(S=j).
            Must sum to 1.
        clip:
            If True (default), clip negative entries to zero and renormalise.
            If False, return the raw signed pseudo-probabilities. Negative values
            are mathematically valid but cannot be used as a reference distribution.

        Returns
        -------
        np.ndarray
            Debiased probability (or pseudo-probability) vector of shape (k,).

        Warns
        -----
        UserWarning
            If negative entries are clipped.
        """
        q = np.asarray(noisy_probs, dtype=np.float64)
        if q.shape != (self._k,):
            raise ValueError(
                f"noisy_probs must have shape ({self._k},). Got {q.shape}."
            )
        T_inv = self.T_inv()
        p_hat = T_inv @ q

        if clip and np.any(p_hat < 0):
            warnings.warn(
                f"Debiased probabilities contain {np.sum(p_hat < 0)} negative "
                "entries (minimum: {:.4f}). This can occur with small samples. "
                "Clipping to zero and renormalising. Set clip=False to return "
                "the raw signed pseudo-probabilities.".format(p_hat.min()),
                UserWarning,
                stacklevel=2,
            )
            p_hat = clip_and_renormalise(p_hat)

        return p_hat

    def accuracy_constant(self) -> float:
        """Return the privacy-accuracy constant C1.

        C1 = (pi + k - 2) / (k * pi - 1)

        C1 appears in the Zhang/Liu/Shi generalisation bound (Theorem 4.3).
        It measures how much the LDP correction inflates the generalisation
        error relative to the case where D is directly observed.

        - C1 = 1: no noise inflation (only when pi=1, i.e. epsilon=inf).
        - C1 = 5: bound is 5x worse than direct observation.
        - C1 -> inf: epsilon near 0, correction is unreliable.

        Returns
        -------
        float
            C1 value.
        """
        return accuracy_constant(self._pi, self._k)

    @classmethod
    def from_mechanism(cls, mechanism: "KaryRandomisedResponse") -> "CorrectionMatrix":
        """Construct from a KaryRandomisedResponse mechanism.

        Parameters
        ----------
        mechanism:
            Fitted k-RR mechanism.

        Returns
        -------
        CorrectionMatrix
        """
        return cls(pi=mechanism.pi, k=mechanism.k)

    def __repr__(self) -> str:
        return (
            f"CorrectionMatrix(pi={self._pi:.4f}, k={self._k}, "
            f"C1={self.accuracy_constant():.3f})"
        )
