"""
k-ary Randomised Response (k-RR) mechanism for Local Differential Privacy.

The k-RR mechanism perturbs a sensitive categorical attribute D to a privatised
version S, such that the mechanism satisfies epsilon-LDP. The insurer receives
only S — the true attribute D is never disclosed.

Privacy guarantee
-----------------
For any two true values d, d' and any reported value s::

    P(S=s | D=d) / P(S=s | D=d') <= exp(epsilon)

This holds for the transition probabilities::

    P(S=d | D=d) = pi  = exp(eps) / (k - 1 + exp(eps))
    P(S=j | D=d) = pi_bar = (1 - pi) / (k - 1)   for j != d

References
----------
Zhang, Liu, Shi (2025). Discrimination-Free Insurance Pricing under Local
Differential Privacy. arXiv:2504.11775.

Warner (1965). Randomized Response: A Survey Technique for Eliminating Evasive
Answer Bias. JASA 60(309), 63-69.
"""

from __future__ import annotations

import warnings
from typing import Any, Sequence

import numpy as np

from insurance_fairness_ldp._utils import (
    accuracy_constant,
    epsilon_from_pi,
    pi_from_epsilon,
)
from insurance_fairness_ldp._validators import (
    C1_WARN_THRESHOLD,
    validate_categories,
    validate_epsilon,
)


class KaryRandomisedResponse:
    """k-ary Randomised Response (k-RR) mechanism.

    Perturbs a sensitive categorical attribute D with k categories to a
    privatised response S satisfying epsilon-Local Differential Privacy.

    The mechanism keeps the true category with probability pi and reports a
    uniform random other category with probability 1 - pi.

    .. warning::
        **Privacy guarantee is architectural, not just algorithmic.**

        In a properly designed multi-party system (as per Zhang et al.),
        the data subject applies k-RR *before* submitting their attribute,
        and a Trusted Third Party (TTP) performs the correction. In a
        single-party setup (one organisation running this code), the formal
        LDP privacy guarantee does not hold in the same way — the insurer
        still controls the privatisation step. This library provides the
        correct *mathematical framework* for the multi-party case and is
        suitable for research, simulation, and compliance demonstration, but
        deploying it as a privacy guarantee requires proper TTP architecture.

    Parameters
    ----------
    epsilon:
        Privacy budget (> 0). Smaller values mean more noise (stronger privacy).
        Recommended range: 0.5 to 5. Hard minimum: 0.1 (below this the
        correction matrix is numerically unstable).
    categories:
        Ordered sequence of k unique category labels for the sensitive attribute.
        Labels can be strings, integers, or any hashable type.

    Attributes
    ----------
    epsilon:
        The privacy parameter.
    categories:
        Ordered list of category labels.
    k:
        Number of categories.

    Examples
    --------
    >>> import numpy as np
    >>> from insurance_fairness_ldp import KaryRandomisedResponse
    >>> krr = KaryRandomisedResponse(epsilon=1.0, categories=["White", "Asian", "Black", "Other"])
    >>> true_ethnicity = np.array(["White"] * 500 + ["Asian"] * 200 + ["Black"] * 200 + ["Other"] * 100)
    >>> privatised = krr.privatise(true_ethnicity, random_state=42)
    >>> privatised.shape
    (1000,)
    """

    def __init__(
        self,
        epsilon: float,
        categories: Sequence[Any],
    ) -> None:
        validate_epsilon(epsilon)
        self._epsilon = float(epsilon)
        self._categories = validate_categories(categories)
        self._k = len(self._categories)
        self._pi = pi_from_epsilon(self._epsilon, self._k)
        self._pi_bar = (1.0 - self._pi) / (self._k - 1)

        # Warn on poor privacy-accuracy balance
        c1 = accuracy_constant(self._pi, self._k)
        if c1 > C1_WARN_THRESHOLD:
            warnings.warn(
                f"Accuracy constant C1={c1:.2f} > {C1_WARN_THRESHOLD}. "
                f"At epsilon={self._epsilon:.2f} with k={self._k} categories, "
                "the correction amplifies noise substantially. Pricing estimates "
                "will have wide confidence intervals. Consider increasing epsilon.",
                UserWarning,
                stacklevel=2,
            )

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def epsilon(self) -> float:
        """Privacy budget epsilon."""
        return self._epsilon

    @property
    def categories(self) -> list[Any]:
        """Ordered list of category labels."""
        return list(self._categories)

    @property
    def k(self) -> int:
        """Number of categories."""
        return self._k

    @property
    def pi(self) -> float:
        """Truth probability: P(S=d | D=d)."""
        return self._pi

    @property
    def pi_bar(self) -> float:
        """Confusion probability: P(S=j | D=d) for j != d."""
        return self._pi_bar

    # ------------------------------------------------------------------
    # Core methods
    # ------------------------------------------------------------------

    def privatise(
        self,
        s: np.ndarray | list | Any,
        random_state: int | np.random.Generator | None = None,
    ) -> np.ndarray:
        """Apply k-RR to an array of true sensitive attribute values.

        Each observation is independently perturbed: with probability pi the
        true category is reported; with probability 1-pi a uniformly random
        other category is reported.

        Parameters
        ----------
        s:
            1-D array-like of true category values. Must contain only values
            from ``self.categories``.
        random_state:
            Seed or Generator for reproducibility.

        Returns
        -------
        np.ndarray
            1-D array of privatised category values (same dtype as input).

        Raises
        ------
        ValueError
            If s contains values not in categories.
        """
        from insurance_fairness_ldp._validators import validate_privatised_array

        s_arr = np.asarray(s)
        validate_privatised_array(s_arr, self._categories)

        rng = np.random.default_rng(random_state)
        n = len(s_arr)
        result = s_arr.copy()

        # Map categories to integer indices for vectorised sampling
        cat_array = np.array(self._categories)
        idx_map = {cat: i for i, cat in enumerate(self._categories)}
        true_idx = np.array([idx_map[v] for v in s_arr])

        # Draw uniform [0, 1) for each observation
        u = rng.uniform(size=n)
        # If u > pi, randomise
        randomise_mask = u > self._pi
        n_randomise = int(randomise_mask.sum())

        if n_randomise > 0:
            # Draw random category indices for those to be randomised
            rand_idx = rng.integers(0, self._k - 1, size=n_randomise)
            # Shift by 1 to avoid the true category
            true_idx_rand = true_idx[randomise_mask]
            # Map: 0..k-2 -> all categories except true
            # Indices 0..(true_idx-1) stay; true_idx..k-2 map to true_idx+1..k-1
            shifted = rand_idx.copy()
            shifted[rand_idx >= true_idx_rand] += 1
            result[randomise_mask] = cat_array[shifted]

        return result

    def correction_matrix(self) -> np.ndarray:
        """Return the k-RR transition matrix T.

        T is the k x k stochastic matrix where::

            T[i, i] = pi         (diagonal: true category reported)
            T[i, j] = pi_bar     (off-diagonal: wrong category reported, i != j)

        T relates the true distribution p_true to the noisy distribution
        p_noisy via::

            p_noisy = T^T @ p_true    (column stochastic convention)

        or equivalently::

            p_noisy[j] = sum_i T[i, j] * p_true[i]

        Returns
        -------
        np.ndarray
            Shape (k, k). Rows index the true category; columns index the
            reported category.
        """
        T = np.full((self._k, self._k), self._pi_bar)
        np.fill_diagonal(T, self._pi)
        return T

    def privacy_param(self) -> float:
        """Return pi — the truth probability.

        Convenience alias for the :attr:`pi` property.
        """
        return self._pi

    def __repr__(self) -> str:
        return (
            f"KaryRandomisedResponse(epsilon={self._epsilon:.4f}, "
            f"k={self._k}, pi={self._pi:.4f}, "
            f"categories={self._categories})"
        )


def privatise(
    s: np.ndarray | list,
    epsilon: float,
    categories: Sequence[Any],
    random_state: int | np.random.Generator | None = None,
) -> np.ndarray:
    """Convenience function: apply k-RR to a sensitive attribute array.

    Creates a :class:`KaryRandomisedResponse` and applies it in one step.

    Parameters
    ----------
    s:
        1-D array-like of true category values.
    epsilon:
        Privacy budget.
    categories:
        Ordered sequence of unique category labels.
    random_state:
        Seed or Generator for reproducibility.

    Returns
    -------
    np.ndarray
        Privatised attribute array.

    Examples
    --------
    >>> import numpy as np
    >>> from insurance_fairness_ldp import privatise
    >>> s = np.array(["A", "A", "B", "B", "B"])
    >>> s_private = privatise(s, epsilon=1.0, categories=["A", "B"], random_state=0)
    """
    krr = KaryRandomisedResponse(epsilon=epsilon, categories=categories)
    return krr.privatise(s, random_state=random_state)


def epsilon_from_pi(pi: float, k: int) -> float:
    """Re-export for convenience.

    Compute epsilon from a known truth probability pi and number of categories k.

    Parameters
    ----------
    pi:
        Truth probability (1/k < pi < 1).
    k:
        Number of categories.

    Returns
    -------
    float
        Inferred epsilon.
    """
    from insurance_fairness_ldp._utils import epsilon_from_pi as _efp
    return _efp(pi, k)


def pi_from_epsilon_public(epsilon: float, k: int) -> float:
    """Compute pi from epsilon and k.

    Parameters
    ----------
    epsilon:
        Privacy budget.
    k:
        Number of categories.

    Returns
    -------
    float
        Truth probability pi.
    """
    return pi_from_epsilon(epsilon, k)
