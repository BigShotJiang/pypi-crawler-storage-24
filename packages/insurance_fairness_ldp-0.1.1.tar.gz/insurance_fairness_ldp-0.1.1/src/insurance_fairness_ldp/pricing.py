"""
LDP Discrimination-Free Pricing.

This module implements the Zhang/Liu/Shi (2025) discrimination-free premium
estimator under Local Differential Privacy. The key insight is the Lindholm
(2022) formula::

    h*(X) = sum_k f_k(X) * P*(D=k)

where f_k(X) is the group-specific expected cost model, trained on the
LDP-corrected loss, and P*(D) is a reference distribution over the protected
attribute. Neither f_k nor P*(D) require direct observation of the true
sensitive attribute D — everything is derived from the privatised S.

.. warning::
    **Single-party vs. multi-party privacy.** The formal LDP privacy
    guarantee of Zhang/Liu/Shi requires a *Trusted Third Party* (TTP)
    architecture: policyholders submit privatised responses directly to the TTP,
    not to the insurer. In a single-party implementation (insurer runs this
    code), the insurer controls the privatisation step and the formal privacy
    guarantee does not apply in the same way. This library provides the correct
    mathematical framework and is suitable for research and compliance
    demonstration. Deploying as a live privacy guarantee requires proper TTP
    infrastructure.

References
----------
Zhang, Liu, Shi (2025). Discrimination-Free Insurance Pricing under Local
Differential Privacy. arXiv:2504.11775.

Lindholm, Richman, Tsanakas, Wüthrich (2022). Discrimination-Free Insurance
Pricing. ASTIN Bulletin 52(1), 55-89.
"""

from __future__ import annotations

import warnings
from typing import Any, Sequence

import numpy as np
from sklearn.base import BaseEstimator, clone, is_classifier, is_regressor

from insurance_fairness_ldp._utils import empirical_frequencies
from insurance_fairness_ldp._validators import (
    validate_group_sizes,
    validate_reference_dist,
    validate_X_y,
)
from insurance_fairness_ldp.correction import CorrectionMatrix
from insurance_fairness_ldp.mechanisms import KaryRandomisedResponse


class _SignedWeightLinearModel:
    """Direct WLS solver for LDP-corrected linear regression.

    Solves (X^T W X + lambda I) beta = X^T W y using the normal equations.
    Supports negative weights (signed measure), which sklearn Ridge does not.

    This is the mathematically correct solver for the LDP group model when
    the Pi^{-1} correction produces negative sample weights. For squared loss,
    (X^T W X + lambda I) is positive definite for any lambda > 0 regardless
    of the signs of the diagonal elements of W.
    """

    def __init__(self, alpha: float = 1.0, fit_intercept: bool = True):
        self.alpha = alpha
        self.fit_intercept = fit_intercept
        self.coef_: np.ndarray | None = None
        self.intercept_: float = 0.0

    def fit(
        self, X: np.ndarray, y: np.ndarray, sample_weight: np.ndarray | None = None
    ) -> "_SignedWeightLinearModel":
        X_arr = np.asarray(X, dtype=np.float64)
        y_arr = np.asarray(y, dtype=np.float64)
        n = X_arr.shape[0]

        if self.fit_intercept:
            X_aug = np.column_stack([X_arr, np.ones(n)])
        else:
            X_aug = X_arr

        if sample_weight is not None:
            w = np.asarray(sample_weight, dtype=np.float64)
            XtW = X_aug.T * w  # shape (p+1, n)
            XtWX = XtW @ X_aug  # shape (p+1, p+1)
            XtWy = XtW @ y_arr  # shape (p+1,)
        else:
            XtWX = X_aug.T @ X_aug
            XtWy = X_aug.T @ y_arr

        # Add L2 regularisation (not on intercept)
        reg = self.alpha * np.eye(X_aug.shape[1])
        if self.fit_intercept:
            reg[-1, -1] = 0.0  # Do not regularise intercept
        XtWX += reg

        beta = np.linalg.solve(XtWX, XtWy)

        if self.fit_intercept:
            self.coef_ = beta[:-1]
            self.intercept_ = float(beta[-1])
        else:
            self.coef_ = beta
            self.intercept_ = 0.0

        return self

    def predict(self, X: np.ndarray) -> np.ndarray:
        X_arr = np.asarray(X, dtype=np.float64)
        return X_arr @ self.coef_ + self.intercept_


class LDPDiscriminationFreePrice(BaseEstimator):
    """Discrimination-free premium estimator under Local Differential Privacy.

    Trains a separate group-specific model f_k(X) for each category k of the
    sensitive attribute, using the Zhang/Liu/Shi LDP-corrected loss. The final
    prediction is the Lindholm formula::

        h*(X_i) = sum_k f_k(X_i) * P*(D=k)

    where P*(D) is a reference distribution that is independent of X, removing
    the indirect discrimination signal.

    .. warning::
        See module-level warning about single-party vs. multi-party privacy.

    Parameters
    ----------
    base_estimator:
        Any sklearn-compatible regressor (or classifier for frequency models).
        One clone is fitted per category. For regression (severity/pure premium),
        use e.g. ``LinearRegression()``, ``GradientBoostingRegressor()``.
        The estimator must support sample weights via ``fit(X, y, sample_weight=...)``.
    mechanism:
        A fitted :class:`KaryRandomisedResponse` describing the LDP mechanism
        used to generate S_private.
    reference_dist:
        How to compute P*(D), the reference distribution over the sensitive
        attribute:

        - ``'marginal'`` (default): estimate P*(D) from the debiased empirical
          frequencies using T^{-1}. This is the Zhang/Liu/Shi recommendation.
        - 1-D array of length k: use a fixed user-specified distribution.
          Must be non-negative and sum to 1.

    Attributes
    ----------
    group_models_:
        Dict mapping category label -> fitted estimator f_k.
    reference_dist_:
        1-D array of shape (k,) with the reference distribution P*(D).
    correction_matrix_:
        The :class:`CorrectionMatrix` used during fitting.
    categories_:
        Ordered list of category labels (from mechanism).
    n_samples_:
        Number of training observations.

    Examples
    --------
    >>> import numpy as np
    >>> from sklearn.linear_model import Ridge
    >>> from insurance_fairness_ldp import KaryRandomisedResponse, LDPDiscriminationFreePrice
    >>> rng = np.random.default_rng(42)
    >>> n = 1000
    >>> X = rng.normal(size=(n, 3))
    >>> D = rng.choice(["A", "B"], size=n)
    >>> y = X[:, 0] + rng.normal(scale=0.5, size=n)
    >>> krr = KaryRandomisedResponse(epsilon=1.0, categories=["A", "B"])
    >>> S_private = krr.privatise(D, random_state=42)
    >>> model = LDPDiscriminationFreePrice(
    ...     base_estimator=Ridge(),
    ...     mechanism=krr,
    ... )
    >>> model.fit(X, S_private, y)
    LDPDiscriminationFreePrice(...)
    >>> predictions = model.predict(X)
    >>> predictions.shape
    (1000,)
    """

    def __init__(
        self,
        base_estimator: BaseEstimator,
        mechanism: KaryRandomisedResponse,
        reference_dist: str | np.ndarray | Sequence[float] = "marginal",
    ) -> None:
        self.base_estimator = base_estimator
        self.mechanism = mechanism
        self.reference_dist = reference_dist

    def fit(
        self,
        X: np.ndarray,
        S_private: np.ndarray,
        y: np.ndarray,
        exposure: np.ndarray | None = None,
    ) -> "LDPDiscriminationFreePrice":
        """Fit group-specific models using LDP-corrected sample weights.

        For each category k, fit f_k by minimising the LDP-corrected empirical
        risk. The correction uses Pi^{-1} applied to the per-observation losses,
        implemented via sample weights::

            w_i(k) = sum_j Pi^{-1}_{kj} * I[S_i = j]

        Note: The LDP correction matrix Pi^{-1} has negative off-diagonal
        entries, so sample weights will contain negative values. For linear
        models this is handled via a direct signed-weight normal equations solver.
        For non-linear estimators the weights are clipped to the positive part
        with a warning.

        Parameters
        ----------
        X:
            Feature matrix of shape (n, p). Can be a numpy array or any
            array-like accepted by the base_estimator.
        S_private:
            1-D array of privatised sensitive attribute values of length n.
            Must contain values from ``mechanism.categories``.
        y:
            Target array of shape (n,). For insurance regression: claim costs
            or pure premiums. For classification: binary claim indicators.
        exposure:
            Optional 1-D array of shape (n,) with exposure weights (e.g.,
            policy years). Multiplied into the sample weights.

        Returns
        -------
        self

        Raises
        ------
        ValueError
            If X, S_private, or y have inconsistent lengths or invalid values.
        """
        from insurance_fairness_ldp._validators import validate_privatised_array

        X_arr = np.asarray(X, dtype=np.float64)
        y_arr = np.asarray(y, dtype=np.float64)
        S_arr = np.asarray(S_private)

        validate_X_y(X_arr, y_arr)
        if len(S_arr) != len(y_arr):
            raise ValueError(
                f"S_private and y must have the same length. "
                f"Got S_private: {len(S_arr)}, y: {len(y_arr)}."
            )

        validate_privatised_array(S_arr, self.mechanism.categories)
        validate_group_sizes(S_arr, self.mechanism.categories)

        n = len(y_arr)
        categories = self.mechanism.categories
        k = self.mechanism.k
        self.categories_ = categories
        self.n_samples_ = n

        # Build correction matrix
        # First estimate debiased group probabilities from noisy frequencies
        noisy_freqs = empirical_frequencies(S_arr, categories)
        cm = CorrectionMatrix(pi=self.mechanism.pi, k=k)
        debiased_freqs = cm.debias_probs(noisy_freqs, clip=True)
        self.correction_matrix_ = cm

        # Compute Pi^{-1}
        Pi_inv = cm.Pi_inv(debiased_freqs)  # shape (k, k)

        # Compute reference distribution P*(D)
        if isinstance(self.reference_dist, str) and self.reference_dist == "marginal":
            self.reference_dist_ = debiased_freqs
        else:
            ref = np.asarray(self.reference_dist, dtype=np.float64)
            self.reference_dist_ = validate_reference_dist(ref, k)

        # Build one-hot indicator matrix: shape (n, k)
        cat_to_idx = {cat: i for i, cat in enumerate(categories)}
        S_idx = np.array([cat_to_idx[v] for v in S_arr])
        S_onehot = np.zeros((n, k), dtype=np.float64)
        S_onehot[np.arange(n), S_idx] = 1.0

        # Exposure weights
        exp_weights = (
            np.asarray(exposure, dtype=np.float64) if exposure is not None else np.ones(n)
        )
        if len(exp_weights) != n:
            raise ValueError(
                f"exposure must have length {n}. Got {len(exp_weights)}."
            )

        # Fit one model per group
        self.group_models_: dict[Any, BaseEstimator] = {}
        used_fallback = False

        for ki, cat in enumerate(categories):
            # Sample weights for group ki:
            # w_i(ki) = sum_j Pi^{-1}[ki, j] * I[S_i = j]
            sample_weights = S_onehot @ Pi_inv[ki, :]  # shape (n,)
            sample_weights = sample_weights * exp_weights

            # Check for degenerate all-zero weights
            if not np.any(sample_weights != 0):
                warnings.warn(
                    f"All LDP-corrected sample weights for group '{cat}' are "
                    "zero. Fitting with uniform weights as fallback.",
                    UserWarning,
                    stacklevel=2,
                )
                sample_weights = np.ones(n)

            estimator = clone(self.base_estimator)
            fitted = False

            # First attempt: pass weights directly (works for sklearn if all positive,
            # or for any estimator that accepts negative weights)
            try:
                estimator.fit(X_arr, y_arr, sample_weight=sample_weights)
                fitted = True
            except (TypeError, ValueError):
                pass

            if not fitted:
                # Second attempt: use _SignedWeightLinearModel which solves the
                # normal equations directly and supports negative weights.
                try:
                    alpha_val = float(getattr(self.base_estimator, "alpha", 1.0))
                    fit_intercept = bool(
                        getattr(self.base_estimator, "fit_intercept", True)
                    )
                    linear_model = _SignedWeightLinearModel(
                        alpha=alpha_val, fit_intercept=fit_intercept
                    )
                    linear_model.fit(X_arr, y_arr, sample_weight=sample_weights)
                    estimator = linear_model
                    fitted = True
                except Exception:
                    pass

            if not fitted:
                # Last resort: absolute weights with bias warning
                used_fallback = True
                abs_weights = np.abs(sample_weights)
                if not np.any(abs_weights > 0):
                    abs_weights = np.ones(n)
                warnings.warn(
                    "base_estimator does not support negative LDP sample weights. "
                    f"Fitting group '{cat}' with absolute weights. "
                    "Results will be biased.",
                    UserWarning,
                    stacklevel=2,
                )
                try:
                    estimator.fit(X_arr, y_arr, sample_weight=abs_weights)
                except TypeError:
                    estimator.fit(X_arr, y_arr)

            self.group_models_[cat] = estimator

        if used_fallback:
            warnings.warn(
                "One or more group models were fitted with absolute weights as a "
                "fallback because the base_estimator does not support negative "
                "sample weights. For full LDP correctness, use a linear "
                "base_estimator (e.g. Ridge, LinearRegression).",
                UserWarning,
                stacklevel=2,
            )

        return self

    def predict(self, X: np.ndarray) -> np.ndarray:
        """Compute discrimination-free premiums h*(X).

        Applies the Lindholm formula::

            h*(X_i) = sum_k f_k(X_i) * P*(D=k)

        Parameters
        ----------
        X:
            Feature matrix of shape (m, p).

        Returns
        -------
        np.ndarray
            1-D array of shape (m,) with discrimination-free premium estimates.

        Raises
        ------
        RuntimeError
            If ``fit`` has not been called.
        """
        if not hasattr(self, "group_models_"):
            raise RuntimeError(
                "LDPDiscriminationFreePrice has not been fitted. Call fit() first."
            )
        X_arr = np.asarray(X, dtype=np.float64)
        categories = self.categories_
        k = len(categories)

        # Collect group predictions: shape (k, m)
        group_preds = np.zeros((k, X_arr.shape[0]))
        for ki, cat in enumerate(categories):
            model = self.group_models_[cat]
            if hasattr(model, "predict_proba"):
                # Classifier — use probability of positive class
                pred = model.predict_proba(X_arr)[:, -1]
            else:
                pred = model.predict(X_arr)
            group_preds[ki, :] = pred

        # Weighted sum: h*(X) = sum_k f_k(X) * P*(D=k)
        h_star = group_preds.T @ self.reference_dist_  # shape (m,)
        return h_star

    def predict_group(self, X: np.ndarray, category: Any) -> np.ndarray:
        """Return the group-specific prediction f_k(X) for a single category.

        Parameters
        ----------
        X:
            Feature matrix of shape (m, p).
        category:
            Category label (must be in ``self.categories_``).

        Returns
        -------
        np.ndarray
            1-D array of shape (m,) with f_k(X) for the specified group.

        Raises
        ------
        ValueError
            If category is not in the fitted categories.
        """
        if not hasattr(self, "group_models_"):
            raise RuntimeError(
                "LDPDiscriminationFreePrice has not been fitted. Call fit() first."
            )
        if category not in self.group_models_:
            raise ValueError(
                f"category={category!r} not found. "
                f"Available categories: {self.categories_}."
            )
        X_arr = np.asarray(X, dtype=np.float64)
        model = self.group_models_[category]
        if hasattr(model, "predict_proba"):
            return model.predict_proba(X_arr)[:, -1]
        return model.predict(X_arr)

    def get_accuracy_constant(self) -> float:
        """Return the privacy-accuracy constant C1 for this mechanism.

        Returns
        -------
        float
        """
        if not hasattr(self, "correction_matrix_"):
            raise RuntimeError("Model not yet fitted. Call fit() first.")
        return self.correction_matrix_.accuracy_constant()

    def __repr__(self) -> str:
        return (
            f"LDPDiscriminationFreePrice("
            f"base_estimator={self.base_estimator!r}, "
            f"mechanism={self.mechanism!r}, "
            f"reference_dist={self.reference_dist!r})"
        )
