"""
LDP Fairness Report.

Produces structured summaries of the LDP discrimination-free pricing workflow,
suitable for regulatory documentation (FCA Consumer Duty, GDPR Article 9).

The report documents:
- The privacy mechanism used (epsilon, k, pi, C1)
- Reference distribution P*(D) before and after LDP correction
- Group-specific model performance on LDP-corrected losses
- Discrimination index: how much h*(X) differs from a naive baseline
- Calibration by noisy group
- Privacy-accuracy trade-off narrative

References
----------
Zhang, Liu, Shi (2025). arXiv:2504.11775.
FCA CP25/2 (2025). Ethnicity pricing analysis.
GDPR Article 9 / DPA 2018 Schedule 1.
"""

from __future__ import annotations

import warnings
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Sequence

import numpy as np


@dataclass
class LDPFairnessReport:
    """Structured report on LDP discrimination-free pricing results.

    Attributes
    ----------
    epsilon:
        Privacy budget used.
    k:
        Number of sensitive attribute categories.
    categories:
        Category labels.
    pi:
        Truth probability of the k-RR mechanism.
    accuracy_constant:
        C1 — privacy-accuracy constant from Theorem 4.3.
    reference_dist:
        P*(D) reference distribution (after LDP debiasing).
    noisy_dist:
        P_hat(S) observed noisy distribution before correction.
    group_predictions:
        Dict of {category: np.ndarray} with group predictions f_k(X).
    reference_premiums:
        1-D array h*(X) — discrimination-free premiums.
    group_losses:
        Dict of {category: float} with LDP-corrected group losses (optional).
    calibration:
        Dict from ``calibration_by_group_ldp`` (optional).
    discrimination_index:
        Scalar distance between h*(X) and h_naive(X) (optional).
    h_naive:
        Naive predictions used to compute discrimination_index (optional).
    n_samples:
        Number of observations in the training data.
    generated_at:
        ISO timestamp when the report was created.
    notes:
        Free-text notes for the regulatory narrative.
    """

    epsilon: float
    k: int
    categories: list[Any]
    pi: float
    accuracy_constant: float
    reference_dist: np.ndarray
    noisy_dist: np.ndarray
    group_predictions: dict[Any, np.ndarray]
    reference_premiums: np.ndarray
    n_samples: int
    group_losses: dict[Any, float] = field(default_factory=dict)
    calibration: dict[str, Any] = field(default_factory=dict)
    discrimination_index: float | None = None
    h_naive: np.ndarray | None = None
    generated_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    notes: str = ""

    def summary(self) -> str:
        """Return a concise text summary of the report.

        Returns
        -------
        str
        """
        lines = [
            "LDP Discrimination-Free Pricing Report",
            "=" * 40,
            f"Generated:             {self.generated_at}",
            f"Privacy parameter:     epsilon={self.epsilon:.4f}",
            f"Categories (k):        {self.k} — {self.categories}",
            f"Truth probability:     pi={self.pi:.4f}",
            f"Accuracy constant C1:  {self.accuracy_constant:.4f}",
            "",
            "Reference distribution P*(D):",
        ]
        for cat, p in zip(self.categories, self.reference_dist):
            lines.append(f"  P*(D={cat!r}) = {p:.4f}")

        lines += [
            "",
            "Noisy distribution P_hat(S):",
        ]
        for cat, p in zip(self.categories, self.noisy_dist):
            lines.append(f"  P_hat(S={cat!r}) = {p:.4f}")

        lines += [
            "",
            f"Training observations: {self.n_samples}",
            f"Premium summary:",
            f"  mean h*(X)   = {np.mean(self.reference_premiums):.4f}",
            f"  std  h*(X)   = {np.std(self.reference_premiums):.4f}",
            f"  min  h*(X)   = {np.min(self.reference_premiums):.4f}",
            f"  max  h*(X)   = {np.max(self.reference_premiums):.4f}",
        ]

        if self.discrimination_index is not None:
            lines += [
                "",
                f"Discrimination index:  {self.discrimination_index:.4f}",
                "(distance between LDP-corrected and naive predictions)",
            ]

        if self.group_losses:
            lines += ["", "LDP-corrected group losses:"]
            for cat, loss in self.group_losses.items():
                lines.append(f"  Group {cat!r}: {loss:.6f}")

        if self.calibration:
            lines += ["", "Calibration by noisy group S:"]
            groups = self.calibration.get("group", [])
            ns = self.calibration.get("n", [])
            ma = self.calibration.get("mean_actual", [])
            mp = self.calibration.get("mean_predicted", [])
            cr = self.calibration.get("calibration_ratio", [])
            for g, n, a, p, r in zip(groups, ns, ma, mp, cr):
                lines.append(
                    f"  S={g!r}: n={n}, "
                    f"actual={a:.4f}, predicted={p:.4f}, ratio={r:.4f}"
                )

        if self.notes:
            lines += ["", "Notes:", self.notes]

        return "\n".join(lines)

    def to_markdown(self, path: str | Path) -> None:
        """Write the report to a Markdown file.

        Parameters
        ----------
        path:
            Output file path. Parent directories must exist.
        """
        path = Path(path)
        content = self._build_markdown()
        path.write_text(content, encoding="utf-8")

    def _build_markdown(self) -> str:
        lines = [
            "# LDP Discrimination-Free Pricing Report",
            "",
            f"*Generated: {self.generated_at}*",
            "",
            "## Privacy Mechanism",
            "",
            f"| Parameter | Value |",
            f"|-----------|-------|",
            f"| Privacy budget (epsilon) | {self.epsilon:.4f} |",
            f"| Categories (k) | {self.k} |",
            f"| Category labels | {self.categories} |",
            f"| Truth probability (pi) | {self.pi:.4f} |",
            f"| Accuracy constant C1 | {self.accuracy_constant:.4f} |",
            f"| Training observations | {self.n_samples} |",
            "",
        ]

        # C1 interpretation
        c1 = self.accuracy_constant
        if c1 > 5:
            c1_note = (
                "> **Warning:** C1 > 5. The LDP correction inflates the "
                "generalisation error bound more than 5-fold relative to direct "
                "observation of the sensitive attribute. Results are "
                "research-quality only at this privacy level."
            )
        elif c1 > 2:
            c1_note = (
                f"> C1={c1:.2f}: Moderate error inflation. "
                "Adequate for research use; review before production deployment."
            )
        else:
            c1_note = (
                f"> C1={c1:.2f}: Good privacy-accuracy balance."
            )
        lines += [c1_note, ""]

        lines += [
            "## Distributions",
            "",
            "| Category | P*(D) reference | P_hat(S) noisy |",
            "|----------|----------------|----------------|",
        ]
        for cat, p_ref, p_noisy in zip(self.categories, self.reference_dist, self.noisy_dist):
            lines.append(f"| {cat!r} | {p_ref:.4f} | {p_noisy:.4f} |")

        lines += [
            "",
            "## Premium Summary",
            "",
            f"| Statistic | h\\*(X) |",
            "|-----------|--------|",
            f"| Mean | {np.mean(self.reference_premiums):.4f} |",
            f"| Std | {np.std(self.reference_premiums):.4f} |",
            f"| Min | {np.min(self.reference_premiums):.4f} |",
            f"| Max | {np.max(self.reference_premiums):.4f} |",
            "",
        ]

        if self.discrimination_index is not None:
            lines += [
                "## Discrimination Index",
                "",
                f"Distance between LDP-corrected h\\*(X) and naive predictions: "
                f"**{self.discrimination_index:.4f}**",
                "",
                "A value near zero indicates the LDP correction has minimal "
                "practical effect. A large value indicates the correction is "
                "materially changing premium estimates.",
                "",
            ]

        if self.group_losses:
            lines += [
                "## LDP-Corrected Group Losses",
                "",
                "| Group | Corrected Loss |",
                "|-------|----------------|",
            ]
            for cat, loss in self.group_losses.items():
                lines.append(f"| {cat!r} | {loss:.6f} |")
            lines.append("")

        if self.calibration:
            lines += [
                "## Calibration by Noisy Group",
                "",
                "| Group (S) | n | Mean Actual | Mean Predicted | Ratio |",
                "|-----------|---|-------------|----------------|-------|",
            ]
            groups = self.calibration.get("group", [])
            ns = self.calibration.get("n", [])
            ma = self.calibration.get("mean_actual", [])
            mp = self.calibration.get("mean_predicted", [])
            cr = self.calibration.get("calibration_ratio", [])
            for g, n, a, p, r in zip(groups, ns, ma, mp, cr):
                lines.append(f"| {g!r} | {n} | {a:.4f} | {p:.4f} | {r:.4f} |")
            lines.append("")

        lines += [
            "## Regulatory Context",
            "",
            "This report supports compliance with:",
            "",
            "- **GDPR Article 9 / DPA 2018 Schedule 1**: The insurer processes "
            "only privatised responses S (epsilon-LDP), not true sensitive "
            "attribute D.",
            "- **FCA Consumer Duty**: Pricing model is demonstrably "
            "discrimination-free via the Lindholm (2022) formula applied to "
            "LDP-corrected group models.",
            "- **Equality Act 2010, Section 19**: Indirect discrimination is "
            "mitigated by the reference distribution P*(D) being independent of X.",
            "",
            "> **Architecture note**: The formal LDP privacy guarantee requires "
            "a Trusted Third Party (TTP) architecture in which policyholders "
            "submit privatised responses directly to the TTP, not to the insurer. "
            "In a single-party deployment, the insurer controls the privatisation "
            "step and the guarantee is a mathematical property of the correction "
            "framework, not a formal LDP guarantee. See Zhang, Liu, Shi (2025) "
            "Section 3 for the full multi-party protocol.",
            "",
        ]

        if self.notes:
            lines += ["## Notes", "", self.notes, ""]

        lines += [
            "---",
            "*Generated by insurance-fairness-ldp. "
            "Reference: Zhang, Liu, Shi (2025). "
            "Discrimination-Free Insurance Pricing under Local Differential Privacy. "
            "arXiv:2504.11775.*",
        ]

        return "\n".join(lines)

    @classmethod
    def from_model(
        cls,
        model: "LDPDiscriminationFreePrice",
        X: np.ndarray,
        S_private: np.ndarray,
        y: np.ndarray | None = None,
        h_naive: np.ndarray | None = None,
        notes: str = "",
    ) -> "LDPFairnessReport":
        """Construct a report from a fitted LDPDiscriminationFreePrice model.

        Parameters
        ----------
        model:
            A fitted :class:`~insurance_fairness_ldp.pricing.LDPDiscriminationFreePrice`.
        X:
            Feature matrix (used to compute group predictions and premiums).
        S_private:
            Privatised sensitive attribute array.
        y:
            Optional targets for calibration and group loss computation.
        h_naive:
            Optional naive predictions for discrimination index computation.
        notes:
            Free-text notes.

        Returns
        -------
        LDPFairnessReport
        """
        from insurance_fairness_ldp._utils import empirical_frequencies
        from insurance_fairness_ldp.metrics import (
            calibration_by_group_ldp,
            discrimination_free_indicator,
            group_loss_corrected,
        )

        if not hasattr(model, "group_models_"):
            raise RuntimeError("Model must be fitted before creating a report.")

        mech = model.mechanism
        cm = model.correction_matrix_
        categories = model.categories_
        k = mech.k

        # Reference and noisy distributions
        S_arr = np.asarray(S_private)
        noisy_dist = empirical_frequencies(S_arr, categories)
        ref_dist = model.reference_dist_

        # Group predictions and discrimination-free premiums
        group_preds = {
            cat: model.predict_group(X, cat) for cat in categories
        }
        h_star = model.predict(X)

        # Discrimination index
        disc_idx = None
        if h_naive is not None:
            disc_idx = discrimination_free_indicator(h_star, np.asarray(h_naive))

        # Group losses and calibration (require y)
        group_losses_dict: dict[Any, float] = {}
        calibration_dict: dict[str, Any] = {}
        if y is not None:
            Pi_inv = cm.Pi_inv(ref_dist)
            group_losses_dict = group_loss_corrected(
                y_true=y,
                y_pred=h_star,
                S_private=S_arr,
                categories=categories,
                Pi_inv=Pi_inv,
            )
            calibration_dict = calibration_by_group_ldp(
                y_true=y,
                y_pred=h_star,
                S_private=S_arr,
                categories=categories,
            )

        return cls(
            epsilon=mech.epsilon,
            k=k,
            categories=categories,
            pi=mech.pi,
            accuracy_constant=cm.accuracy_constant(),
            reference_dist=ref_dist,
            noisy_dist=noisy_dist,
            group_predictions=group_preds,
            reference_premiums=h_star,
            n_samples=model.n_samples_,
            group_losses=group_losses_dict,
            calibration=calibration_dict,
            discrimination_index=disc_idx,
            h_naive=np.asarray(h_naive) if h_naive is not None else None,
            notes=notes,
        )
