"""
Fairness metrics computable under LDP noise.

These metrics quantify the degree of discrimination and accuracy of a
discrimination-free pricing model, given that we only have access to the
privatised sensitive attribute S rather than the true D.

Key metrics
-----------
- **Discrimination index**: distance between LDP-corrected predictions h*(X)
  and a naive model h_naive(X) that ignores privacy. Large values indicate the
  LDP correction is doing meaningful work.
- **Group-conditional loss**: the LDP-corrected group loss R_hat^{LDP}_k for
  each group — how well f_k fits observations nominally assigned to group k.
- **Calibration by noisy group**: mean predicted vs. mean actual, grouped by
  privatised category S. An imperfect proxy for true calibration (since S != D)
  but measurable without seeing D.
- **C1-adjusted bound**: upper bound on pricing error inflation from Theorem 4.3.

References
----------
Zhang, Liu, Shi (2025). arXiv:2504.11775.
Makhlouf et al. (2024). arXiv:2405.14725 (LDP reduces CSD).
"""

from __future__ import annotations

import warnings
from typing import Any, Sequence

import numpy as np


def discrimination_free_indicator(
    h_star: np.ndarray,
    h_naive: np.ndarray,
    norm: str = "l2",
) -> float:
    """Measure the distance between LDP-corrected and naive predictions.

    A large value indicates the privacy correction is meaningfully changing the
    premium estimates. Near zero means the correction has little effect (either
    because the attribute has no predictive power, or because epsilon is large).

    Parameters
    ----------
    h_star:
        1-D array of LDP discrimination-free predictions h*(X).
    h_naive:
        1-D array of naive predictions (model trained without LDP correction,
        typically using privatised S directly as a feature or ignoring groups).
    norm:
        Distance metric: ``'l2'`` (default, RMSE), ``'l1'`` (MAE),
        ``'max'`` (L-infinity / max absolute difference).

    Returns
    -------
    float
        Scalar distance measure.
    """
    h_star = np.asarray(h_star, dtype=np.float64)
    h_naive = np.asarray(h_naive, dtype=np.float64)
    if h_star.shape != h_naive.shape:
        raise ValueError(
            f"h_star and h_naive must have the same shape. "
            f"Got {h_star.shape} vs {h_naive.shape}."
        )
    diff = h_star - h_naive
    if norm == "l2":
        return float(np.sqrt(np.mean(diff ** 2)))
    elif norm == "l1":
        return float(np.mean(np.abs(diff)))
    elif norm == "max":
        return float(np.max(np.abs(diff)))
    else:
        raise ValueError(f"norm must be 'l2', 'l1', or 'max'. Got {norm!r}.")


def group_loss_corrected(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    S_private: np.ndarray,
    categories: Sequence[Any],
    Pi_inv: np.ndarray,
    loss: str = "squared",
) -> dict[Any, float]:
    """Compute the LDP-corrected group loss R_hat^{LDP}_k for each group.

    This computes the Zhang/Liu/Shi corrected risk::

        R_hat^{LDP}_k = sum_j Pi^{-1}_{kj} * mean(L(y_pred, y_true) * I[S=j])
                        / P_hat(S=k)

    Parameters
    ----------
    y_true:
        1-D array of observed targets (claim costs).
    y_pred:
        1-D array of model predictions.
    S_private:
        1-D array of privatised group labels.
    categories:
        Ordered list of k category labels.
    Pi_inv:
        Shape (k, k) correction matrix from ``CorrectionMatrix.Pi_inv()``.
    loss:
        Loss function: ``'squared'`` (default, MSE) or ``'absolute'`` (MAE).

    Returns
    -------
    dict[category, float]
        LDP-corrected loss per true group.
    """
    cats = list(categories)
    k = len(cats)
    y_true = np.asarray(y_true, dtype=np.float64)
    y_pred = np.asarray(y_pred, dtype=np.float64)
    S_arr = np.asarray(S_private)
    n = len(y_true)

    if y_pred.shape != y_true.shape:
        raise ValueError(
            f"y_true and y_pred must have the same shape. "
            f"Got {y_true.shape} vs {y_pred.shape}."
        )

    # Compute per-observation loss
    if loss == "squared":
        per_obs_loss = (y_pred - y_true) ** 2
    elif loss == "absolute":
        per_obs_loss = np.abs(y_pred - y_true)
    else:
        raise ValueError(f"loss must be 'squared' or 'absolute'. Got {loss!r}.")

    # Empirical noisy group frequencies P_hat(S=j)
    p_noisy = np.array([np.mean(S_arr == cat) for cat in cats])

    # Group-conditional mean loss: E_hat[L | S=j] * P_hat(S=j)
    # This is the unnormalised version: sum_i L_i * I[S_i=j] / n
    group_loss_unnorm = np.array([
        np.mean(per_obs_loss * (S_arr == cat)) for cat in cats
    ])  # shape (k,)

    # Corrected loss per true group k:
    # R_hat^{LDP}_k = sum_j Pi^{-1}_{kj} * group_loss_unnorm[j] / p_noisy[k]
    results = {}
    for ki, cat in enumerate(cats):
        if p_noisy[ki] < 1e-9:
            warnings.warn(
                f"Group '{cat}' has near-zero noisy frequency. "
                "Corrected loss is undefined.",
                UserWarning,
                stacklevel=2,
            )
            results[cat] = float("nan")
        else:
            corrected = float(np.dot(Pi_inv[ki, :], group_loss_unnorm) / p_noisy[ki])
            results[cat] = corrected

    return results


def calibration_by_group_ldp(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    S_private: np.ndarray,
    categories: Sequence[Any],
) -> dict[str, Any]:
    """Calibration check grouped by privatised category S.

    Computes mean predicted and mean actual values for each noisy group S=j.
    This is an imperfect proxy for true group calibration (since S != D), but
    it can be measured without accessing D.

    Parameters
    ----------
    y_true:
        1-D array of observed targets.
    y_pred:
        1-D array of predictions.
    S_private:
        1-D array of privatised group labels.
    categories:
        Ordered list of category labels.

    Returns
    -------
    dict
        Keys: 'group', 'n', 'mean_actual', 'mean_predicted', 'calibration_ratio'.
        Each value is a list of length k (one per noisy group).
    """
    cats = list(categories)
    y_true = np.asarray(y_true, dtype=np.float64)
    y_pred = np.asarray(y_pred, dtype=np.float64)
    S_arr = np.asarray(S_private)

    groups, ns, mean_act, mean_pred, cal_ratio = [], [], [], [], []
    for cat in cats:
        mask = S_arr == cat
        n_cat = int(mask.sum())
        if n_cat == 0:
            groups.append(cat)
            ns.append(0)
            mean_act.append(float("nan"))
            mean_pred.append(float("nan"))
            cal_ratio.append(float("nan"))
        else:
            ma = float(np.mean(y_true[mask]))
            mp = float(np.mean(y_pred[mask]))
            ratio = mp / ma if abs(ma) > 1e-9 else float("nan")
            groups.append(cat)
            ns.append(n_cat)
            mean_act.append(ma)
            mean_pred.append(mp)
            cal_ratio.append(ratio)

    return {
        "group": groups,
        "n": ns,
        "mean_actual": mean_act,
        "mean_predicted": mean_pred,
        "calibration_ratio": cal_ratio,
    }


def c1_adjusted_error_bound(
    base_bound: float,
    c1: float,
    k: int,
    p_s_k_star: float,
    M: float = 1.0,
) -> float:
    """Compute the LDP-inflated generalisation error bound.

    From Zhang/Liu/Shi Theorem 4.3, the LDP-adjusted bound inflates the
    non-private bound by::

        inflation = 2 * C1 * M * k / P(S=k*)

    where k* is the reference category (typically the most frequent).

    Parameters
    ----------
    base_bound:
        The non-private generalisation bound (e.g. from cross-validation error).
    c1:
        Privacy-accuracy constant C1.
    k:
        Number of categories.
    p_s_k_star:
        Empirical probability P_hat(S=k*) of the reference category.
    M:
        Bound on the loss function (default 1.0 for normalised losses).

    Returns
    -------
    float
        LDP-inflated error bound.
    """
    if p_s_k_star <= 0:
        raise ValueError(
            f"p_s_k_star must be positive. Got {p_s_k_star}."
        )
    inflation = 2.0 * c1 * M * k / p_s_k_star
    return float(base_bound * inflation)


def debiased_group_means(
    y: np.ndarray,
    S_private: np.ndarray,
    categories: Sequence[Any],
    T_inv: np.ndarray,
) -> dict[Any, float]:
    """Estimate debiased conditional means E[Y | D=k] using T^{-1} correction.

    Computes an unbiased estimate of E[Y | D=k] from noisy group assignments,
    without directly observing D.

    Method: E[Y | D=k] = sum_j T^{-1}_{kj} * E_hat[Y | S=j] * P_hat(S=j) / P_hat(D=k)

    Parameters
    ----------
    y:
        Target array.
    S_private:
        Privatised group labels.
    categories:
        Ordered category labels.
    T_inv:
        T^{-1} matrix of shape (k, k).

    Returns
    -------
    dict[category, float]
        Debiased conditional mean per true group.
    """
    cats = list(categories)
    k = len(cats)
    y = np.asarray(y, dtype=np.float64)
    S_arr = np.asarray(S_private)

    # Noisy conditional means E_hat[Y | S=j] and P_hat(S=j)
    p_noisy = np.array([np.mean(S_arr == cat) for cat in cats])
    cond_means = np.array([
        float(np.mean(y[S_arr == cat])) if np.any(S_arr == cat) else 0.0
        for cat in cats
    ])

    # Unnormalised: E_hat[Y | S=j] * P_hat(S=j)
    unnorm = cond_means * p_noisy  # shape (k,)

    # Debiased P_hat(D=k) and debiased E[Y|D=k]*P(D=k)
    p_debiased = T_inv @ p_noisy  # shape (k,)
    ey_debiased_unnorm = T_inv @ unnorm  # shape (k,)

    results = {}
    for ki, cat in enumerate(cats):
        if abs(p_debiased[ki]) < 1e-9:
            results[cat] = float("nan")
        else:
            results[cat] = float(ey_debiased_unnorm[ki] / p_debiased[ki])

    return results
