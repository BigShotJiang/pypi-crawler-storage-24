"""
Input validation for insurance-fairness-ldp.

Internal module — not part of the public API.
"""

from __future__ import annotations

import warnings
from typing import Any, Sequence

import numpy as np


# Minimum epsilon below which T^{-1} becomes numerically unsafe.
EPSILON_HARD_MIN = 0.1
# Epsilon below which we warn loudly about accuracy/stability.
EPSILON_WARN_THRESHOLD = 0.5
# C1 above which we warn about poor privacy-accuracy balance.
C1_WARN_THRESHOLD = 5.0
# Minimum group size below which group model estimates are unreliable.
GROUP_SIZE_MIN = 30


def validate_epsilon(epsilon: float) -> None:
    """Validate the privacy parameter epsilon.

    Parameters
    ----------
    epsilon:
        Privacy budget. Must be > EPSILON_HARD_MIN (0.1).

    Raises
    ------
    ValueError
        If epsilon <= 0.1.
    """
    if not isinstance(epsilon, (int, float)):
        raise TypeError(f"epsilon must be a float, got {type(epsilon).__name__}")
    if epsilon < EPSILON_HARD_MIN:
        raise ValueError(
            f"epsilon={epsilon:.4f} is too small. The correction matrix T^{{-1}} "
            f"is numerically unstable below epsilon={EPSILON_HARD_MIN}. "
            "At epsilon=0 the mechanism is pure noise and the correction is singular. "
            f"Use epsilon >= {EPSILON_HARD_MIN}."
        )
    if epsilon < EPSILON_WARN_THRESHOLD:
        warnings.warn(
            f"epsilon={epsilon:.4f} < {EPSILON_WARN_THRESHOLD}. This provides strong "
            "privacy but very poor accuracy — the accuracy constant C1 will be large. "
            "Pricing estimates at this epsilon level should be treated as research-only.",
            UserWarning,
            stacklevel=3,
        )


def validate_categories(categories: Sequence[Any]) -> list[Any]:
    """Validate and normalise the categories list.

    Parameters
    ----------
    categories:
        Sequence of unique category labels for the sensitive attribute.

    Returns
    -------
    list
        Deduplicated, ordered list of categories.

    Raises
    ------
    ValueError
        If fewer than 2 categories, or if duplicates are present.
    """
    cats = list(categories)
    if len(cats) < 2:
        raise ValueError(
            f"At least 2 categories are required for k-RR. Got {len(cats)}."
        )
    if len(cats) != len(set(cats)):
        raise ValueError(
            f"categories contains duplicates. Got: {cats}. "
            "All category labels must be unique."
        )
    return cats


def validate_privatised_array(s_private: np.ndarray, categories: list[Any]) -> None:
    """Validate a privatised sensitive attribute array.

    Parameters
    ----------
    s_private:
        1-D array of privatised category values.
    categories:
        Expected category labels.

    Raises
    ------
    ValueError
        If s_private contains values outside categories.
    """
    s_private = np.asarray(s_private)
    if s_private.ndim != 1:
        raise ValueError(
            f"s_private must be 1-D. Got shape {s_private.shape}."
        )
    unknown = set(s_private.tolist()) - set(categories)
    if unknown:
        raise ValueError(
            f"s_private contains values not in categories: {unknown}. "
            f"Expected categories: {categories}."
        )


def validate_group_sizes(s_private: np.ndarray, categories: list[Any]) -> None:
    """Warn if any group has fewer than GROUP_SIZE_MIN observations.

    Parameters
    ----------
    s_private:
        1-D array of privatised category values.
    categories:
        Category labels.
    """
    s_private = np.asarray(s_private)
    for cat in categories:
        n_cat = int(np.sum(s_private == cat))
        if n_cat < GROUP_SIZE_MIN:
            warnings.warn(
                f"Group '{cat}' has only {n_cat} observations in s_private "
                f"(minimum recommended: {GROUP_SIZE_MIN}). "
                "The group-specific model f_k for this group will be unreliable.",
                UserWarning,
                stacklevel=3,
            )


def validate_X_y(X: Any, y: np.ndarray) -> None:
    """Validate feature matrix and target array consistency.

    Parameters
    ----------
    X:
        Feature matrix (array-like).
    y:
        Target array.

    Raises
    ------
    ValueError
        If lengths differ.
    """
    X_arr = np.asarray(X)
    y_arr = np.asarray(y)
    if X_arr.shape[0] != y_arr.shape[0]:
        raise ValueError(
            f"X and y must have the same number of rows. "
            f"Got X: {X_arr.shape[0]}, y: {y_arr.shape[0]}."
        )


def validate_reference_dist(ref_dist: np.ndarray, k: int) -> np.ndarray:
    """Validate a user-supplied reference distribution P*(D).

    Parameters
    ----------
    ref_dist:
        Array of length k summing to 1.
    k:
        Number of categories.

    Returns
    -------
    np.ndarray
        Validated distribution as float64 array.

    Raises
    ------
    ValueError
        If shape or normalisation is wrong, or if any entry is negative.
    """
    ref = np.asarray(ref_dist, dtype=np.float64)
    if ref.shape != (k,):
        raise ValueError(
            f"reference_dist must have shape ({k},). Got {ref.shape}."
        )
    if np.any(ref < 0):
        raise ValueError(
            "reference_dist must be non-negative. Got negative entries: "
            f"{ref[ref < 0]}."
        )
    total = ref.sum()
    if not np.isclose(total, 1.0, atol=1e-6):
        raise ValueError(
            f"reference_dist must sum to 1. Got sum={total:.6f}."
        )
    return ref


def validate_group_probs(group_probs: np.ndarray, k: int) -> np.ndarray:
    """Validate group probability vector for Pi^{-1} computation.

    Parameters
    ----------
    group_probs:
        Array of length k with P(D=j) estimates. Must be positive and sum to 1.
    k:
        Number of categories.

    Returns
    -------
    np.ndarray
        Validated array as float64.

    Raises
    ------
    ValueError
        If any entry is zero or negative (Pi would be singular).
    """
    probs = np.asarray(group_probs, dtype=np.float64)
    if probs.shape != (k,):
        raise ValueError(
            f"group_probs must have shape ({k},). Got {probs.shape}."
        )
    if np.any(probs <= 0):
        raise ValueError(
            "group_probs must be strictly positive. Zero or negative entries "
            f"make Pi singular. Got: {probs}."
        )
    total = probs.sum()
    if not np.isclose(total, 1.0, atol=1e-4):
        raise ValueError(
            f"group_probs must sum to 1. Got sum={total:.6f}."
        )
    return probs
