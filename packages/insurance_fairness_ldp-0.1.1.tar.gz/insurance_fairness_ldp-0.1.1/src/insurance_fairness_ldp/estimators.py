"""
Noise rate estimation for the unknown-epsilon setting.

In the known-epsilon case (Phase 1), the insurer or TTP knows the privacy
parameter epsilon that was used to privatise the sensitive attribute. In the
unknown-epsilon case (Phase 2), epsilon must be estimated from data using an
*anchor-point* method.

Anchor-point estimation
-----------------------
An anchor point is a subset of observations where the true category is known
with near-certainty for some category j*. For example, if a binary attribute
is "disability status" and there is a sub-group of policyholders with a
documented disability (e.g., from a third-party register), then for that
sub-group P(D=j* | X*) ≈ 1.

At anchor points, the observed noisy frequency P(S=j* | X*) approximates pi
(since almost all true values are j*, so P(S=j*) ≈ P(S=j* | D=j*) = pi).

Procedure 4.5 from Zhang/Liu/Shi
---------------------------------
1. Identify a reference category j* with known or near-certain membership.
2. Filter to the anchor subset A = {i : X_i in anchor region}.
3. Estimate pi_hat = P_hat(S=j* | X_i in A) = mean(S_i == j* for i in A).
4. Infer epsilon_hat = ln(pi_hat * (k-1) / (1 - pi_hat)).

Asymmetry note
--------------
Underestimating pi (thinking noise is less than it is) amplifies residual noise
in the correction. Overestimating pi under-corrects but fails more gracefully.
When uncertain, err toward higher pi (lower epsilon). See Zhang et al. p.10.

References
----------
Zhang, Liu, Shi (2025). Discrimination-Free Insurance Pricing under Local
Differential Privacy. arXiv:2504.11775. Section 4.3, Procedure 4.5, Theorem 4.5.
"""

from __future__ import annotations

import warnings
from typing import Any, Callable, Sequence

import numpy as np

from insurance_fairness_ldp._utils import epsilon_from_pi
from insurance_fairness_ldp._validators import (
    EPSILON_WARN_THRESHOLD,
    validate_categories,
    validate_privatised_array,
)


class NoiseRateEstimator:
    """Estimate the k-RR noise parameter pi from data using anchor points.

    This implements Procedure 4.5 from Zhang/Liu/Shi. Use this when the
    privacy budget epsilon is not known to the analyst (e.g., the privatisation
    was performed by a third party or the data subject).

    Parameters
    ----------
    categories:
        Ordered sequence of k unique category labels for the sensitive attribute.
    anchor_category:
        The reference category j* for anchor-point estimation. Should be the
        category for which you can identify a sub-population where membership
        is near-certain.
    anchor_selector:
        A callable ``f(X) -> bool_array`` that selects the anchor observations.
        If None, a default based on X being None is used and the entire dataset
        is used as anchor (only valid if anchor_category dominates the dataset).
    min_anchor_size:
        Minimum number of anchor observations required for reliable estimation.
        Raises a warning if fewer are found.

    Attributes
    ----------
    pi_:
        Estimated truth probability (fitted after calling ``fit``).
    epsilon_:
        Inferred epsilon from pi_ (fitted after calling ``fit``).
    std_error_:
        Bootstrap standard error of pi_ (fitted if bootstrap=True).
    n_anchor_:
        Number of anchor observations used.

    Examples
    --------
    >>> import numpy as np
    >>> from insurance_fairness_ldp import NoiseRateEstimator
    >>> # Simulate: true D=0 for first 200, then mix; anchor is first 200
    >>> rng = np.random.default_rng(42)
    >>> D_true = np.array([0]*200 + [0, 1, 2]*200)
    >>> # Apply k-RR with pi=0.7, k=3
    >>> S = D_true.copy().astype(object)
    >>> S_private = S  # placeholder — use KaryRandomisedResponse in practice
    >>> estimator = NoiseRateEstimator(
    ...     categories=[0, 1, 2],
    ...     anchor_category=0,
    ...     anchor_selector=lambda X: np.arange(len(X)) < 200,
    ... )
    """

    def __init__(
        self,
        categories: Sequence[Any],
        anchor_category: Any,
        anchor_selector: Callable[[np.ndarray], np.ndarray] | None = None,
        min_anchor_size: int = 50,
    ) -> None:
        self._categories = validate_categories(categories)
        self._k = len(self._categories)

        if anchor_category not in self._categories:
            raise ValueError(
                f"anchor_category={anchor_category!r} is not in categories: "
                f"{self._categories}."
            )
        self._anchor_category = anchor_category
        self._anchor_selector = anchor_selector
        self._min_anchor_size = int(min_anchor_size)

        # Fitted attributes
        self.pi_: float | None = None
        self.epsilon_: float | None = None
        self.std_error_: float | None = None
        self.n_anchor_: int | None = None

    @property
    def categories(self) -> list[Any]:
        """Ordered category labels."""
        return list(self._categories)

    @property
    def anchor_category(self) -> Any:
        """Reference anchor category j*."""
        return self._anchor_category

    @property
    def k(self) -> int:
        """Number of categories."""
        return self._k

    def fit(
        self,
        S_private: np.ndarray,
        X: np.ndarray | None = None,
        bootstrap: bool = True,
        n_bootstrap: int = 200,
        random_state: int | None = None,
    ) -> "NoiseRateEstimator":
        """Estimate pi from privatised observations.

        Parameters
        ----------
        S_private:
            1-D array of privatised category values. Must use categories from
            ``self.categories``.
        X:
            Feature matrix passed to ``anchor_selector``. Can be None if
            ``anchor_selector`` is None (use all observations).
        bootstrap:
            If True, compute bootstrap standard error of pi.
        n_bootstrap:
            Number of bootstrap samples for standard error.
        random_state:
            Seed for bootstrap reproducibility.

        Returns
        -------
        self

        Raises
        ------
        RuntimeError
            If no anchor observations are found.
        """
        S_arr = np.asarray(S_private)
        validate_privatised_array(S_arr, self._categories)

        n = len(S_arr)

        # Select anchor observations
        if self._anchor_selector is not None:
            X_arr = np.asarray(X) if X is not None else np.arange(n)
            anchor_mask = np.asarray(self._anchor_selector(X_arr), dtype=bool)
            if anchor_mask.shape != (n,):
                raise ValueError(
                    f"anchor_selector must return a boolean array of length {n}. "
                    f"Got shape {anchor_mask.shape}."
                )
        else:
            # Default: use all observations
            anchor_mask = np.ones(n, dtype=bool)

        n_anchor = int(anchor_mask.sum())
        self.n_anchor_ = n_anchor

        if n_anchor == 0:
            raise RuntimeError(
                "anchor_selector returned no observations. Cannot estimate pi. "
                "Check your anchor_selector function."
            )
        if n_anchor < self._min_anchor_size:
            warnings.warn(
                f"Only {n_anchor} anchor observations found (minimum recommended: "
                f"{self._min_anchor_size}). Pi estimate may be unreliable.",
                UserWarning,
                stacklevel=2,
            )

        S_anchor = S_arr[anchor_mask]

        # Estimate pi as fraction of anchor obs reporting anchor_category
        pi_hat = float(np.mean(S_anchor == self._anchor_category))

        # Clip to valid range with small buffer
        lower = 1.0 / self._k + 1e-6
        pi_hat = float(np.clip(pi_hat, lower, 1.0 - 1e-9))

        self.pi_ = pi_hat
        self.epsilon_ = epsilon_from_pi(pi_hat, self._k)

        if self.epsilon_ < EPSILON_WARN_THRESHOLD:
            warnings.warn(
                f"Estimated epsilon={self.epsilon_:.3f} < {EPSILON_WARN_THRESHOLD}. "
                "The implied noise level is high. "
                "Consider whether the anchor assumption is valid.",
                UserWarning,
                stacklevel=2,
            )

        # Bootstrap standard error
        if bootstrap and n_anchor >= 2:
            rng = np.random.default_rng(random_state)
            pi_boot = np.zeros(n_bootstrap)
            for b in range(n_bootstrap):
                boot_idx = rng.integers(0, n_anchor, size=n_anchor)
                boot_sample = S_anchor[boot_idx]
                pi_b = float(np.mean(boot_sample == self._anchor_category))
                pi_b = float(np.clip(pi_b, lower, 1.0 - 1e-9))
                pi_boot[b] = pi_b
            self.std_error_ = float(np.std(pi_boot, ddof=1))
        else:
            self.std_error_ = None

        return self

    def to_mechanism(self, categories: Sequence[Any] | None = None):
        """Convert estimated noise rate to a KaryRandomisedResponse mechanism.

        Parameters
        ----------
        categories:
            Category labels. If None, uses ``self.categories``.

        Returns
        -------
        KaryRandomisedResponse
            Mechanism with the estimated epsilon.

        Raises
        ------
        RuntimeError
            If ``fit`` has not been called.
        """
        from insurance_fairness_ldp.mechanisms import KaryRandomisedResponse

        if self.epsilon_ is None:
            raise RuntimeError(
                "NoiseRateEstimator has not been fitted. Call fit() first."
            )
        cats = categories if categories is not None else self._categories
        return KaryRandomisedResponse(epsilon=self.epsilon_, categories=cats)

    def summary(self) -> str:
        """Return a text summary of the estimation result.

        Returns
        -------
        str
        """
        if self.pi_ is None:
            return "NoiseRateEstimator: not yet fitted."
        se_str = (
            f"  Standard error of pi:   {self.std_error_:.4f}\n"
            if self.std_error_ is not None
            else ""
        )
        return (
            f"NoiseRateEstimator — Anchor-point estimation\n"
            f"  Anchor category:        {self._anchor_category!r}\n"
            f"  Anchor observations:    {self.n_anchor_}\n"
            f"  Estimated pi:           {self.pi_:.4f}\n"
            f"{se_str}"
            f"  Inferred epsilon:       {self.epsilon_:.4f}\n"
            f"  k (categories):         {self._k}\n"
        )

    def __repr__(self) -> str:
        fitted = f"pi={self.pi_:.4f}, eps={self.epsilon_:.4f}" if self.pi_ else "not fitted"
        return f"NoiseRateEstimator(anchor={self._anchor_category!r}, {fitted})"
