"""
insurance-fairness-ldp
======================

Local Differential Privacy for discrimination-free insurance pricing.

Implements the Zhang/Liu/Shi (2025) correction matrix framework for training
pricing models when the insurer never sees the true sensitive attribute (e.g.
ethnicity, disability status). Policyholders submit privatised responses via
k-ary Randomised Response; the insurer corrects for the noise mathematically to
produce discrimination-free premiums.

.. warning::
    **Architecture matters.** The formal LDP privacy guarantee requires a
    Trusted Third Party (TTP) architecture: policyholders submit privatised
    responses directly to the TTP, not to the insurer. In a single-party
    deployment (one organisation running this code), the formal guarantee does
    not hold in the same way. This library provides the correct mathematical
    framework for the multi-party case and is suitable for research, simulation,
    and compliance demonstration. See Zhang, Liu, Shi (2025) Section 3.

Quick start::

    import numpy as np
    from sklearn.linear_model import Ridge
    from insurance_fairness_ldp import (
        KaryRandomisedResponse,
        LDPDiscriminationFreePrice,
        LDPFairnessReport,
    )

    # Define the LDP mechanism
    krr = KaryRandomisedResponse(epsilon=1.0, categories=["White", "Asian", "Black", "Other"])

    # In practice, policyholders privatise their own attribute before submission.
    # In simulation, we apply it ourselves:
    true_ethnicity = np.array(["White"] * 600 + ["Asian"] * 200 + ["Black"] * 150 + ["Other"] * 50)
    S_private = krr.privatise(true_ethnicity, random_state=42)

    # Fit discrimination-free pricing model
    model = LDPDiscriminationFreePrice(
        base_estimator=Ridge(),
        mechanism=krr,
        reference_dist="marginal",
    )
    model.fit(X_train, S_private, y_train)

    # Predict discrimination-free premiums
    premiums = model.predict(X_test)

    # Generate regulatory report
    report = LDPFairnessReport.from_model(model, X_test, S_private_test, y_test)
    report.to_markdown("ldp_report.md")

UK Regulatory Context
---------------------
- GDPR Article 9 / DPA 2018 Schedule 1: Only privatised S is processed.
- FCA EP25/2 (2025): £28 residual ethnicity gap in motor pricing.
- Equality Act 2010, Section 19: Indirect discrimination via postcodes.
- FCA Consumer Duty: Demonstrable fair value requirement.

References
----------
Zhang, Liu, Shi (2025). Discrimination-Free Insurance Pricing under Local
Differential Privacy. arXiv:2504.11775.

Lindholm, Richman, Tsanakas, Wüthrich (2022). Discrimination-Free Insurance
Pricing. ASTIN Bulletin 52(1), 55-89.

Makhlouf et al. (2024). A Systematic and Formal Study of the Impact of Local
Differential Privacy on Fairness. arXiv:2405.14725.
"""

from insurance_fairness_ldp.mechanisms import (
    KaryRandomisedResponse,
    privatise,
)
from insurance_fairness_ldp.correction import CorrectionMatrix
from insurance_fairness_ldp.estimators import NoiseRateEstimator
from insurance_fairness_ldp.pricing import LDPDiscriminationFreePrice
from insurance_fairness_ldp.metrics import (
    calibration_by_group_ldp,
    c1_adjusted_error_bound,
    debiased_group_means,
    discrimination_free_indicator,
    group_loss_corrected,
)
from insurance_fairness_ldp.report import LDPFairnessReport

__version__ = "0.1.0"

__all__ = [
    # Core mechanism
    "KaryRandomisedResponse",
    "privatise",
    # Correction
    "CorrectionMatrix",
    # Estimation
    "NoiseRateEstimator",
    # Pricing
    "LDPDiscriminationFreePrice",
    # Metrics
    "calibration_by_group_ldp",
    "c1_adjusted_error_bound",
    "debiased_group_means",
    "discrimination_free_indicator",
    "group_loss_corrected",
    # Reporting
    "LDPFairnessReport",
]
