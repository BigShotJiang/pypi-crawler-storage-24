"""
Tests for insurance_fairness_ldp.mechanisms and _utils.

Covers:
- KaryRandomisedResponse construction and validation
- pi <-> epsilon conversion
- privatise() sampling distribution (statistical test)
- correction_matrix() structure
- Edge cases: k=2, k=10, large epsilon, minimum epsilon
- privatise() convenience function
"""

import warnings

import numpy as np
import pytest

from insurance_fairness_ldp.mechanisms import KaryRandomisedResponse, privatise
from insurance_fairness_ldp._utils import (
    accuracy_constant,
    epsilon_from_pi,
    pi_from_epsilon,
)
from insurance_fairness_ldp._validators import EPSILON_HARD_MIN, EPSILON_WARN_THRESHOLD


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_krr(epsilon=1.0, categories=None):
    if categories is None:
        categories = ["A", "B"]
    return KaryRandomisedResponse(epsilon=epsilon, categories=categories)


# ---------------------------------------------------------------------------
# pi <-> epsilon conversion
# ---------------------------------------------------------------------------

class TestPiEpsilonConversion:
    def test_pi_from_epsilon_binary(self):
        # k=2, eps=ln(3) => pi = 3/(3+1) = 0.75
        eps = np.log(3)
        pi = pi_from_epsilon(eps, k=2)
        assert abs(pi - 0.75) < 1e-10

    def test_pi_from_epsilon_uniform_at_zero(self):
        # As eps -> 0, pi -> 1/k
        eps = 1e-9
        pi = pi_from_epsilon(eps, k=4)
        assert abs(pi - 0.25) < 1e-5

    def test_pi_from_epsilon_approaches_one(self):
        pi = pi_from_epsilon(100.0, k=3)
        assert pi > 0.9999

    def test_epsilon_from_pi_roundtrip(self):
        for k in [2, 3, 5, 10]:
            for eps in [0.5, 1.0, 2.0, 5.0]:
                pi = pi_from_epsilon(eps, k)
                eps_recovered = epsilon_from_pi(pi, k)
                assert abs(eps_recovered - eps) < 1e-9, f"k={k}, eps={eps}"

    def test_epsilon_from_pi_invalid_lower(self):
        with pytest.raises(ValueError, match="1/k"):
            epsilon_from_pi(0.25, k=4)  # pi = 1/k exactly

    def test_epsilon_from_pi_invalid_upper(self):
        with pytest.raises(ValueError, match="1/k"):
            epsilon_from_pi(1.0, k=2)  # pi = 1 is not allowed

    def test_epsilon_from_pi_below_lower(self):
        with pytest.raises(ValueError):
            epsilon_from_pi(0.1, k=4)  # pi < 1/4

    def test_accuracy_constant_known_value(self):
        # k=2, eps=1: pi = e/(e+1), C1 = (pi + 0) / (2*pi - 1)
        pi = pi_from_epsilon(1.0, k=2)
        c1 = accuracy_constant(pi, k=2)
        # From KB: k=2, eps=1 -> C1=1.73
        assert abs(c1 - 1.582) < 0.01

    def test_accuracy_constant_approaches_one(self):
        # Large epsilon -> pi -> 1 -> C1 -> 1
        pi = pi_from_epsilon(20.0, k=2)
        c1 = accuracy_constant(pi, k=2)
        assert abs(c1 - 1.0) < 0.01

    def test_accuracy_constant_k4_eps1(self):
        # From KB: k=4, eps=1 -> C1=3.12
        pi = pi_from_epsilon(1.0, k=4)
        c1 = accuracy_constant(pi, k=4)
        assert abs(c1 - 2.746) < 0.01


# ---------------------------------------------------------------------------
# KaryRandomisedResponse construction
# ---------------------------------------------------------------------------

class TestKaryRandomisedResponseInit:
    def test_basic_construction(self):
        krr = KaryRandomisedResponse(epsilon=1.0, categories=["A", "B"])
        assert krr.epsilon == 1.0
        assert krr.k == 2
        assert krr.categories == ["A", "B"]

    def test_string_categories(self):
        cats = ["White", "Asian", "Black", "Other"]
        krr = KaryRandomisedResponse(epsilon=1.5, categories=cats)
        assert krr.k == 4

    def test_integer_categories(self):
        krr = KaryRandomisedResponse(epsilon=1.0, categories=[0, 1, 2])
        assert krr.categories == [0, 1, 2]

    def test_epsilon_too_small_raises(self):
        with pytest.raises(ValueError, match="numerically unstable"):
            KaryRandomisedResponse(epsilon=0.05, categories=["A", "B"])

    def test_epsilon_exactly_hard_min_raises(self):
        with pytest.raises(ValueError):
            KaryRandomisedResponse(epsilon=EPSILON_HARD_MIN - 0.01, categories=["A", "B"])

    def test_epsilon_below_warn_threshold(self):
        with pytest.warns(UserWarning, match="strong privacy"):
            KaryRandomisedResponse(epsilon=0.2, categories=["A", "B"])

    def test_duplicate_categories_raises(self):
        with pytest.raises(ValueError, match="duplicates"):
            KaryRandomisedResponse(epsilon=1.0, categories=["A", "A", "B"])

    def test_single_category_raises(self):
        with pytest.raises(ValueError, match="At least 2"):
            KaryRandomisedResponse(epsilon=1.0, categories=["A"])

    def test_pi_computed_correctly(self):
        krr = KaryRandomisedResponse(epsilon=1.0, categories=["A", "B"])
        expected_pi = pi_from_epsilon(1.0, 2)
        assert abs(krr.pi - expected_pi) < 1e-10

    def test_pi_bar_computed_correctly(self):
        krr = KaryRandomisedResponse(epsilon=1.0, categories=["A", "B", "C"])
        assert abs(krr.pi_bar - (1 - krr.pi) / 2) < 1e-10

    def test_high_c1_warns(self):
        # k=10, eps=0.5 should produce C1 > 5
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            krr = KaryRandomisedResponse(epsilon=0.5, categories=list(range(10)))
            c1_warnings = [x for x in w if "C1" in str(x.message)]
            assert len(c1_warnings) > 0

    def test_repr(self):
        krr = KaryRandomisedResponse(epsilon=1.0, categories=["A", "B"])
        r = repr(krr)
        assert "KaryRandomisedResponse" in r
        assert "epsilon=1.0" in r


# ---------------------------------------------------------------------------
# privatise() method — sampling distribution
# ---------------------------------------------------------------------------

class TestPrivatise:
    def test_output_shape(self):
        krr = make_krr(epsilon=1.0, categories=["A", "B"])
        s = np.array(["A"] * 100 + ["B"] * 100)
        result = krr.privatise(s, random_state=42)
        assert result.shape == (200,)

    def test_output_values_in_categories(self):
        krr = make_krr(epsilon=1.0, categories=["A", "B"])
        s = np.array(["A"] * 200)
        result = krr.privatise(s, random_state=0)
        assert set(result).issubset({"A", "B"})

    def test_unknown_value_raises(self):
        krr = make_krr(epsilon=1.0, categories=["A", "B"])
        s = np.array(["A", "C"])
        with pytest.raises(ValueError, match="not in categories"):
            krr.privatise(s)

    def test_reproducibility_with_seed(self):
        krr = make_krr()
        s = np.array(["A"] * 50 + ["B"] * 50)
        r1 = krr.privatise(s, random_state=123)
        r2 = krr.privatise(s, random_state=123)
        assert np.array_equal(r1, r2)

    def test_different_seeds_different_results(self):
        krr = make_krr()
        s = np.array(["A"] * 200)
        r1 = krr.privatise(s, random_state=1)
        r2 = krr.privatise(s, random_state=2)
        assert not np.array_equal(r1, r2)

    def test_statistical_truth_probability(self):
        """P(S=A | D=A) should be approximately pi."""
        eps = 1.0
        krr = KaryRandomisedResponse(epsilon=eps, categories=["A", "B"])
        n = 10000
        s = np.array(["A"] * n)
        privatised = krr.privatise(s, random_state=0)
        observed_pi = np.mean(privatised == "A")
        # Should be within 2% of theoretical pi
        assert abs(observed_pi - krr.pi) < 0.02

    def test_statistical_confusion_probability(self):
        """P(S=B | D=A) should be approximately pi_bar."""
        krr = KaryRandomisedResponse(epsilon=1.0, categories=["A", "B"])
        n = 10000
        s = np.array(["A"] * n)
        privatised = krr.privatise(s, random_state=1)
        observed_pi_bar = np.mean(privatised == "B")
        assert abs(observed_pi_bar - krr.pi_bar) < 0.02

    def test_marginal_distribution_preserved_approx(self):
        """E[P(S=j)] should ≈ P(D=j) for balanced true distribution."""
        krr = KaryRandomisedResponse(epsilon=2.0, categories=["A", "B", "C"])
        n = 9000
        s = np.array(["A"] * 3000 + ["B"] * 3000 + ["C"] * 3000)
        privatised = krr.privatise(s, random_state=42)
        # Noisy frequencies should be close to 1/3 each
        for cat in ["A", "B", "C"]:
            freq = np.mean(privatised == cat)
            assert abs(freq - 1 / 3) < 0.03, f"Category {cat}: freq={freq:.4f}"

    def test_k_ary_four_categories(self):
        krr = KaryRandomisedResponse(epsilon=1.0, categories=["W", "A", "B", "O"])
        s = np.array(["W"] * 100)
        result = krr.privatise(s, random_state=0)
        assert set(result).issubset({"W", "A", "B", "O"})

    def test_generator_input(self):
        krr = make_krr()
        s = np.array(["A"] * 10)
        rng = np.random.default_rng(42)
        result = krr.privatise(s, random_state=rng)
        assert result.shape == (10,)

    def test_list_input(self):
        krr = make_krr()
        result = krr.privatise(["A", "B", "A"])
        assert len(result) == 3


# ---------------------------------------------------------------------------
# correction_matrix()
# ---------------------------------------------------------------------------

class TestCorrectionMatrix:
    def test_diagonal_equals_pi(self):
        krr = make_krr(epsilon=1.0, categories=["A", "B", "C"])
        T = krr.correction_matrix()
        np.testing.assert_allclose(np.diag(T), krr.pi, rtol=1e-10)

    def test_off_diagonal_equals_pi_bar(self):
        krr = make_krr(epsilon=1.0, categories=["A", "B", "C"])
        T = krr.correction_matrix()
        k = krr.k
        for i in range(k):
            for j in range(k):
                if i != j:
                    assert abs(T[i, j] - krr.pi_bar) < 1e-10

    def test_row_sums_to_one(self):
        krr = make_krr(epsilon=1.0, categories=["A", "B", "C", "D"])
        T = krr.correction_matrix()
        np.testing.assert_allclose(T.sum(axis=1), 1.0, atol=1e-10)

    def test_column_sums_to_one(self):
        """For balanced groups, T is doubly stochastic."""
        krr = make_krr(epsilon=1.0, categories=["A", "B", "C"])
        T = krr.correction_matrix()
        np.testing.assert_allclose(T.sum(axis=0), 1.0, atol=1e-10)

    def test_shape(self):
        for k in [2, 3, 5, 10]:
            krr = KaryRandomisedResponse(epsilon=1.0, categories=list(range(k)))
            T = krr.correction_matrix()
            assert T.shape == (k, k)

    def test_all_entries_nonneg(self):
        krr = make_krr()
        T = krr.correction_matrix()
        assert np.all(T >= 0)


# ---------------------------------------------------------------------------
# privatise() convenience function
# ---------------------------------------------------------------------------

class TestPrivatiseFunction:
    def test_basic_call(self):
        s = np.array(["A", "B", "A"])
        result = privatise(s, epsilon=1.0, categories=["A", "B"], random_state=0)
        assert len(result) == 3
        assert set(result).issubset({"A", "B"})

    def test_matches_krr_with_same_seed(self):
        s = np.array(["A"] * 50 + ["B"] * 50)
        r1 = privatise(s, epsilon=1.0, categories=["A", "B"], random_state=99)
        krr = KaryRandomisedResponse(epsilon=1.0, categories=["A", "B"])
        r2 = krr.privatise(s, random_state=99)
        assert np.array_equal(r1, r2)

    def test_list_input(self):
        result = privatise(["A", "A", "B"], epsilon=1.0, categories=["A", "B"])
        assert len(result) == 3
