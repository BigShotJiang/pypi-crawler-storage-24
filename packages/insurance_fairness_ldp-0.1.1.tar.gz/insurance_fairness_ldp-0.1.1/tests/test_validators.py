"""
Tests for insurance_fairness_ldp._validators.

Covers edge cases in input validation not captured by other test modules.
"""

import warnings

import numpy as np
import pytest

from insurance_fairness_ldp._validators import (
    validate_categories,
    validate_epsilon,
    validate_group_probs,
    validate_group_sizes,
    validate_privatised_array,
    validate_reference_dist,
    validate_X_y,
    EPSILON_HARD_MIN,
    EPSILON_WARN_THRESHOLD,
    GROUP_SIZE_MIN,
)


class TestValidateEpsilon:
    def test_valid_epsilon(self):
        # Should not raise
        validate_epsilon(1.0)
        validate_epsilon(0.5)
        validate_epsilon(10.0)

    def test_too_small_raises(self):
        with pytest.raises(ValueError, match="numerically unstable"):
            validate_epsilon(EPSILON_HARD_MIN - 0.01)

    def test_warn_below_threshold(self):
        with pytest.warns(UserWarning, match="strong privacy"):
            validate_epsilon(EPSILON_WARN_THRESHOLD - 0.01)

    def test_no_warn_at_threshold(self):
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            validate_epsilon(EPSILON_WARN_THRESHOLD)
            warn_msgs = [x for x in w if "strong privacy" in str(x.message)]
            assert len(warn_msgs) == 0

    def test_non_numeric_raises(self):
        with pytest.raises(TypeError):
            validate_epsilon("one")


class TestValidateCategories:
    def test_valid_list(self):
        result = validate_categories(["A", "B", "C"])
        assert result == ["A", "B", "C"]

    def test_single_category_raises(self):
        with pytest.raises(ValueError, match="At least 2"):
            validate_categories(["A"])

    def test_duplicates_raises(self):
        with pytest.raises(ValueError, match="duplicates"):
            validate_categories([1, 1, 2])

    def test_integer_categories(self):
        result = validate_categories([0, 1, 2, 3])
        assert result == [0, 1, 2, 3]

    def test_mixed_types_raises_on_duplicate(self):
        # 0 != "0", no duplicate — should pass
        result = validate_categories([0, "0"])
        assert len(result) == 2


class TestValidatePrivatisedArray:
    def test_valid_array(self):
        s = np.array(["A", "B", "A"])
        validate_privatised_array(s, ["A", "B"])  # no raise

    def test_2d_array_raises(self):
        s = np.array([["A", "B"]])
        with pytest.raises(ValueError, match="1-D"):
            validate_privatised_array(s, ["A", "B"])

    def test_unknown_values_raises(self):
        s = np.array(["A", "C"])
        with pytest.raises(ValueError, match="not in categories"):
            validate_privatised_array(s, ["A", "B"])


class TestValidateGroupSizes:
    def test_warns_if_small_group(self):
        s = np.array(["A"] * 5 + ["B"] * 100)
        with pytest.warns(UserWarning, match="only"):
            validate_group_sizes(s, ["A", "B"])

    def test_no_warn_if_adequate(self):
        s = np.array(["A"] * 50 + ["B"] * 50)
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            validate_group_sizes(s, ["A", "B"])
            size_warns = [x for x in w if "observations" in str(x.message)]
            assert len(size_warns) == 0


class TestValidateXY:
    def test_valid_arrays(self):
        X = np.zeros((10, 3))
        y = np.ones(10)
        validate_X_y(X, y)  # no raise

    def test_length_mismatch(self):
        X = np.zeros((10, 3))
        y = np.ones(8)
        with pytest.raises(ValueError, match="same number of rows"):
            validate_X_y(X, y)


class TestValidateReferenceDist:
    def test_valid_dist(self):
        result = validate_reference_dist(np.array([0.3, 0.7]), k=2)
        np.testing.assert_allclose(result, [0.3, 0.7])

    def test_wrong_shape(self):
        with pytest.raises(ValueError, match="shape"):
            validate_reference_dist(np.array([0.5, 0.3, 0.2]), k=2)

    def test_negative_raises(self):
        with pytest.raises(ValueError, match="non-negative"):
            validate_reference_dist(np.array([-0.1, 1.1]), k=2)

    def test_doesnt_sum_to_one(self):
        with pytest.raises(ValueError, match="sum to 1"):
            validate_reference_dist(np.array([0.2, 0.3]), k=2)


class TestValidateGroupProbs:
    def test_valid(self):
        result = validate_group_probs(np.array([0.5, 0.5]), k=2)
        np.testing.assert_allclose(result, [0.5, 0.5])

    def test_zero_entry_raises(self):
        with pytest.raises(ValueError, match="strictly positive"):
            validate_group_probs(np.array([0.0, 1.0]), k=2)

    def test_negative_entry_raises(self):
        with pytest.raises(ValueError, match="strictly positive"):
            validate_group_probs(np.array([-0.1, 1.1]), k=2)

    def test_wrong_shape_raises(self):
        with pytest.raises(ValueError, match="shape"):
            validate_group_probs(np.array([0.5, 0.3, 0.2]), k=2)

    def test_doesnt_sum_to_one_raises(self):
        with pytest.raises(ValueError, match="sum to 1"):
            validate_group_probs(np.array([0.2, 0.3]), k=2)
