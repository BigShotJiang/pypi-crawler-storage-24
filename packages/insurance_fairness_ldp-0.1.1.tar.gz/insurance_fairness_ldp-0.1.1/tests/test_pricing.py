"""
Tests for insurance_fairness_ldp.pricing.

Covers:
- LDPDiscriminationFreePrice fit/predict with various base estimators
- Exposure weighting
- reference_dist options ('marginal' and user-specified)
- predict_group()
- Unfitted model raises RuntimeError
- Inconsistent input shapes
- Integration: discrimination-free property (h* independent of group under large eps)
"""

import warnings

import numpy as np
import pytest
from sklearn.linear_model import LinearRegression, Ridge, LogisticRegression
from sklearn.dummy import DummyRegressor

from insurance_fairness_ldp import KaryRandomisedResponse, LDPDiscriminationFreePrice
from insurance_fairness_ldp._utils import pi_from_epsilon


# ---------------------------------------------------------------------------
# Fixtures / helpers
# ---------------------------------------------------------------------------

def make_dataset(n=500, k=2, seed=42, epsilon=1.5):
    rng = np.random.default_rng(seed)
    categories = [f"G{i}" for i in range(k)]
    X = rng.normal(size=(n, 4))
    D = rng.choice(categories, size=n)
    # y = X[:,0] + group effect + noise
    group_effect = np.array([i * 0.5 for i, cat in enumerate(categories)])
    D_idx = np.array([categories.index(d) for d in D])
    y = X[:, 0] + group_effect[D_idx] + rng.normal(scale=0.5, size=n)
    krr = KaryRandomisedResponse(epsilon=epsilon, categories=categories)
    S_private = krr.privatise(D, random_state=seed)
    return X, S_private, y, D, krr, categories


# ---------------------------------------------------------------------------
# Basic fit/predict
# ---------------------------------------------------------------------------

class TestLDPDiscriminationFreePriceFitPredict:
    def test_fit_returns_self(self):
        X, S, y, _, krr, _ = make_dataset()
        model = LDPDiscriminationFreePrice(
            base_estimator=Ridge(), mechanism=krr
        )
        result = model.fit(X, S, y)
        assert result is model

    def test_predict_shape(self):
        X, S, y, _, krr, _ = make_dataset()
        model = LDPDiscriminationFreePrice(base_estimator=Ridge(), mechanism=krr)
        model.fit(X, S, y)
        preds = model.predict(X[:100])
        assert preds.shape == (100,)

    def test_group_models_populated(self):
        X, S, y, _, krr, cats = make_dataset(k=3)
        model = LDPDiscriminationFreePrice(base_estimator=Ridge(), mechanism=krr)
        model.fit(X, S, y)
        assert set(model.group_models_.keys()) == set(cats)

    def test_reference_dist_shape(self):
        X, S, y, _, krr, _ = make_dataset(k=4)
        model = LDPDiscriminationFreePrice(base_estimator=Ridge(), mechanism=krr)
        model.fit(X, S, y)
        assert model.reference_dist_.shape == (4,)

    def test_reference_dist_sums_to_one(self):
        X, S, y, _, krr, _ = make_dataset()
        model = LDPDiscriminationFreePrice(base_estimator=Ridge(), mechanism=krr)
        model.fit(X, S, y)
        assert abs(model.reference_dist_.sum() - 1.0) < 1e-6

    def test_predict_finite(self):
        X, S, y, _, krr, _ = make_dataset()
        model = LDPDiscriminationFreePrice(base_estimator=Ridge(), mechanism=krr)
        model.fit(X, S, y)
        preds = model.predict(X)
        assert np.all(np.isfinite(preds))

    def test_linear_regression_base(self):
        X, S, y, _, krr, _ = make_dataset()
        model = LDPDiscriminationFreePrice(
            base_estimator=LinearRegression(), mechanism=krr
        )
        model.fit(X, S, y)
        preds = model.predict(X)
        assert preds.shape == (len(y),)

    def test_dummy_regressor_base(self):
        X, S, y, _, krr, _ = make_dataset()
        model = LDPDiscriminationFreePrice(
            base_estimator=DummyRegressor(strategy="mean"), mechanism=krr
        )
        model.fit(X, S, y)
        preds = model.predict(X[:50])
        # DummyRegressor returns constant
        assert len(np.unique(preds)) == 1


# ---------------------------------------------------------------------------
# Unfitted model errors
# ---------------------------------------------------------------------------

class TestUnfittedModelErrors:
    def test_predict_raises_if_not_fitted(self):
        krr = KaryRandomisedResponse(epsilon=1.0, categories=["A", "B"])
        model = LDPDiscriminationFreePrice(base_estimator=Ridge(), mechanism=krr)
        with pytest.raises(RuntimeError, match="not been fitted"):
            model.predict(np.zeros((5, 3)))

    def test_predict_group_raises_if_not_fitted(self):
        krr = KaryRandomisedResponse(epsilon=1.0, categories=["A", "B"])
        model = LDPDiscriminationFreePrice(base_estimator=Ridge(), mechanism=krr)
        with pytest.raises(RuntimeError, match="not been fitted"):
            model.predict_group(np.zeros((5, 3)), "A")

    def test_accuracy_constant_raises_if_not_fitted(self):
        krr = KaryRandomisedResponse(epsilon=1.0, categories=["A", "B"])
        model = LDPDiscriminationFreePrice(base_estimator=Ridge(), mechanism=krr)
        with pytest.raises(RuntimeError, match="not yet fitted"):
            model.get_accuracy_constant()


# ---------------------------------------------------------------------------
# Input validation
# ---------------------------------------------------------------------------

class TestInputValidation:
    def test_X_y_length_mismatch(self):
        krr = KaryRandomisedResponse(epsilon=1.0, categories=["A", "B"])
        model = LDPDiscriminationFreePrice(base_estimator=Ridge(), mechanism=krr)
        X = np.zeros((10, 3))
        S = np.array(["A"] * 10)
        y = np.ones(12)
        with pytest.raises(ValueError):
            model.fit(X, S, y)

    def test_S_y_length_mismatch(self):
        krr = KaryRandomisedResponse(epsilon=1.0, categories=["A", "B"])
        model = LDPDiscriminationFreePrice(base_estimator=Ridge(), mechanism=krr)
        X = np.zeros((10, 3))
        S = np.array(["A"] * 8)
        y = np.ones(10)
        with pytest.raises(ValueError):
            model.fit(X, S, y)

    def test_unknown_category_in_S(self):
        krr = KaryRandomisedResponse(epsilon=1.0, categories=["A", "B"])
        model = LDPDiscriminationFreePrice(base_estimator=Ridge(), mechanism=krr)
        X = np.zeros((5, 3))
        S = np.array(["A", "B", "C", "A", "B"])
        y = np.ones(5)
        with pytest.raises(ValueError, match="not in categories"):
            model.fit(X, S, y)

    def test_exposure_wrong_length(self):
        krr = KaryRandomisedResponse(epsilon=1.0, categories=["A", "B"])
        model = LDPDiscriminationFreePrice(base_estimator=Ridge(), mechanism=krr)
        X = np.zeros((10, 3))
        S = np.array(["A"] * 5 + ["B"] * 5)
        y = np.ones(10)
        with pytest.raises(ValueError, match="exposure"):
            model.fit(X, S, y, exposure=np.ones(8))

    def test_invalid_category_predict_group(self):
        X, S, y, _, krr, _ = make_dataset()
        model = LDPDiscriminationFreePrice(base_estimator=Ridge(), mechanism=krr)
        model.fit(X, S, y)
        with pytest.raises(ValueError, match="not found"):
            model.predict_group(X[:5], "UNKNOWN")

    def test_invalid_reference_dist_shape(self):
        krr = KaryRandomisedResponse(epsilon=1.0, categories=["A", "B"])
        model = LDPDiscriminationFreePrice(
            base_estimator=Ridge(),
            mechanism=krr,
            reference_dist=np.array([0.3, 0.4, 0.3]),  # wrong shape for k=2
        )
        with pytest.raises(ValueError):
            model.fit(np.zeros((10, 3)), np.array(["A"]*5+["B"]*5), np.ones(10))

    def test_invalid_reference_dist_doesnt_sum_to_one(self):
        krr = KaryRandomisedResponse(epsilon=1.0, categories=["A", "B"])
        model = LDPDiscriminationFreePrice(
            base_estimator=Ridge(),
            mechanism=krr,
            reference_dist=np.array([0.3, 0.3]),  # sums to 0.6
        )
        with pytest.raises(ValueError):
            model.fit(np.zeros((10, 3)), np.array(["A"]*5+["B"]*5), np.ones(10))


# ---------------------------------------------------------------------------
# Reference distribution options
# ---------------------------------------------------------------------------

class TestReferenceDistOptions:
    def test_marginal_reference(self):
        X, S, y, _, krr, cats = make_dataset()
        model = LDPDiscriminationFreePrice(
            base_estimator=Ridge(), mechanism=krr, reference_dist="marginal"
        )
        model.fit(X, S, y)
        # Should have set reference_dist_ from debiased frequencies
        assert model.reference_dist_.shape == (2,)
        assert abs(model.reference_dist_.sum() - 1.0) < 1e-6

    def test_user_specified_reference(self):
        X, S, y, _, krr, cats = make_dataset()
        ref = np.array([0.6, 0.4])
        model = LDPDiscriminationFreePrice(
            base_estimator=Ridge(), mechanism=krr, reference_dist=ref
        )
        model.fit(X, S, y)
        np.testing.assert_allclose(model.reference_dist_, ref)

    def test_uniform_reference(self):
        X, S, y, _, krr, _ = make_dataset()
        ref = np.array([0.5, 0.5])
        model = LDPDiscriminationFreePrice(
            base_estimator=Ridge(), mechanism=krr, reference_dist=ref
        )
        model.fit(X, S, y)
        np.testing.assert_allclose(model.reference_dist_, ref)


# ---------------------------------------------------------------------------
# Exposure weighting
# ---------------------------------------------------------------------------

class TestExposureWeighting:
    def test_exposure_accepted(self):
        X, S, y, _, krr, _ = make_dataset()
        exposure = np.random.default_rng(0).uniform(0.5, 1.0, size=len(y))
        model = LDPDiscriminationFreePrice(base_estimator=Ridge(), mechanism=krr)
        model.fit(X, S, y, exposure=exposure)
        preds = model.predict(X)
        assert preds.shape == (len(y),)

    def test_unit_exposure_same_as_no_exposure(self):
        X, S, y, _, krr, _ = make_dataset()
        exposure = np.ones(len(y))
        model1 = LDPDiscriminationFreePrice(base_estimator=Ridge(), mechanism=krr)
        model1.fit(X, S, y)
        model2 = LDPDiscriminationFreePrice(base_estimator=Ridge(), mechanism=krr)
        model2.fit(X, S, y, exposure=exposure)
        np.testing.assert_allclose(model1.predict(X), model2.predict(X), atol=1e-8)


# ---------------------------------------------------------------------------
# predict_group()
# ---------------------------------------------------------------------------

class TestPredictGroup:
    def test_predict_group_shape(self):
        X, S, y, _, krr, cats = make_dataset(k=3)
        model = LDPDiscriminationFreePrice(base_estimator=Ridge(), mechanism=krr)
        model.fit(X, S, y)
        for cat in cats:
            pred = model.predict_group(X[:50], cat)
            assert pred.shape == (50,)

    def test_predict_group_finite(self):
        X, S, y, _, krr, cats = make_dataset()
        model = LDPDiscriminationFreePrice(base_estimator=Ridge(), mechanism=krr)
        model.fit(X, S, y)
        for cat in cats:
            pred = model.predict_group(X, cat)
            assert np.all(np.isfinite(pred))

    def test_h_star_is_weighted_avg_of_group_preds(self):
        """h*(X) should equal sum_k f_k(X) * P*(D=k)."""
        X, S, y, _, krr, cats = make_dataset()
        model = LDPDiscriminationFreePrice(base_estimator=Ridge(), mechanism=krr)
        model.fit(X, S, y)
        h_star = model.predict(X)
        h_manual = sum(
            model.predict_group(X, cat) * model.reference_dist_[i]
            for i, cat in enumerate(cats)
        )
        np.testing.assert_allclose(h_star, h_manual, atol=1e-8)


# ---------------------------------------------------------------------------
# Three-category dataset
# ---------------------------------------------------------------------------

class TestThreeCategories:
    def test_k3_fit_predict(self):
        X, S, y, _, krr, cats = make_dataset(k=3, n=600)
        model = LDPDiscriminationFreePrice(base_estimator=Ridge(), mechanism=krr)
        model.fit(X, S, y)
        preds = model.predict(X)
        assert preds.shape == (600,)
        assert np.all(np.isfinite(preds))

    def test_k3_three_group_models(self):
        X, S, y, _, krr, cats = make_dataset(k=3, n=600)
        model = LDPDiscriminationFreePrice(base_estimator=Ridge(), mechanism=krr)
        model.fit(X, S, y)
        assert len(model.group_models_) == 3


# ---------------------------------------------------------------------------
# n_samples_ attribute
# ---------------------------------------------------------------------------

class TestAttributes:
    def test_n_samples_attr(self):
        X, S, y, _, krr, _ = make_dataset(n=300)
        model = LDPDiscriminationFreePrice(base_estimator=Ridge(), mechanism=krr)
        model.fit(X, S, y)
        assert model.n_samples_ == 300

    def test_categories_attr(self):
        X, S, y, _, krr, cats = make_dataset(k=3)
        model = LDPDiscriminationFreePrice(base_estimator=Ridge(), mechanism=krr)
        model.fit(X, S, y)
        assert model.categories_ == cats
