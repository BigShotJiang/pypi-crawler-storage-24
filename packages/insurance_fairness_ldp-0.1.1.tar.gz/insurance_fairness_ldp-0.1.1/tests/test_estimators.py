"""
Tests for insurance_fairness_ldp.estimators (NoiseRateEstimator).

Covers:
- Construction and validation
- fit() on known-pi data
- Bootstrap standard error
- anchor_selector usage
- Unfitted model access raises RuntimeError
- to_mechanism() conversion
- Anchor-point assumption: pi estimate recovers true pi
- Underestimation asymmetry awareness
"""

import warnings

import numpy as np
import pytest

from insurance_fairness_ldp import KaryRandomisedResponse
from insurance_fairness_ldp.estimators import NoiseRateEstimator
from insurance_fairness_ldp._utils import pi_from_epsilon, epsilon_from_pi


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def simulate_anchor_data(pi, k=2, n=1000, anchor_n=200, seed=42):
    """
    Create privatised data where first ``anchor_n`` obs have true D = cat 0.
    """
    rng = np.random.default_rng(seed)
    cats = list(range(k))
    pi_bar = (1 - pi) / (k - 1)
    n_rest = n - anchor_n

    # Privatise anchor observations (true = 0)
    def privatise_one(true_cat, rng):
        if rng.uniform() < pi:
            return true_cat
        choices = [c for c in cats if c != true_cat]
        return rng.choice(choices)

    S_anchor = np.array([privatise_one(0, rng) for _ in range(anchor_n)])
    S_rest = rng.choice(cats, size=n_rest)
    S_all = np.concatenate([S_anchor, S_rest])
    return S_all, cats, anchor_n


# ---------------------------------------------------------------------------
# Construction
# ---------------------------------------------------------------------------

class TestNoiseRateEstimatorInit:
    def test_basic_construction(self):
        est = NoiseRateEstimator(categories=[0, 1], anchor_category=0)
        assert est.anchor_category == 0
        assert est.k == 2

    def test_anchor_category_not_in_categories_raises(self):
        with pytest.raises(ValueError, match="not in categories"):
            NoiseRateEstimator(categories=[0, 1], anchor_category=2)

    def test_duplicate_categories_raises(self):
        with pytest.raises(ValueError, match="duplicates"):
            NoiseRateEstimator(categories=[0, 0, 1], anchor_category=0)

    def test_repr_unfitted(self):
        est = NoiseRateEstimator(categories=[0, 1], anchor_category=0)
        r = repr(est)
        assert "not fitted" in r


# ---------------------------------------------------------------------------
# fit()
# ---------------------------------------------------------------------------

class TestNoiseRateEstimatorFit:
    def test_fit_returns_self(self):
        S, cats, anchor_n = simulate_anchor_data(pi=0.7, k=2, n=500)
        anchor_sel = lambda X: np.arange(len(X)) < anchor_n
        est = NoiseRateEstimator(
            categories=cats,
            anchor_category=0,
            anchor_selector=anchor_sel,
        )
        result = est.fit(S, X=np.arange(500))
        assert result is est

    def test_pi_estimate_close_to_true_pi(self):
        """With large anchor, estimate should be close to true pi."""
        true_pi = 0.7
        S, cats, anchor_n = simulate_anchor_data(pi=true_pi, k=2, n=2000, anchor_n=500)
        anchor_sel = lambda X: X < anchor_n
        est = NoiseRateEstimator(
            categories=cats,
            anchor_category=0,
            anchor_selector=anchor_sel,
            min_anchor_size=10,
        )
        est.fit(S, X=np.arange(len(S)))
        # Within 5% of true pi
        assert abs(est.pi_ - true_pi) < 0.05

    def test_epsilon_positive(self):
        S, cats, anchor_n = simulate_anchor_data(pi=0.8, k=2, n=1000, anchor_n=300)
        anchor_sel = lambda X: X < anchor_n
        est = NoiseRateEstimator(categories=cats, anchor_category=0, anchor_selector=anchor_sel)
        est.fit(S, X=np.arange(len(S)))
        assert est.epsilon_ > 0

    def test_std_error_computed_with_bootstrap(self):
        S, cats, anchor_n = simulate_anchor_data(pi=0.7, k=2, n=500, anchor_n=100)
        anchor_sel = lambda X: X < anchor_n
        est = NoiseRateEstimator(categories=cats, anchor_category=0, anchor_selector=anchor_sel)
        est.fit(S, X=np.arange(len(S)), bootstrap=True, n_bootstrap=50, random_state=42)
        assert est.std_error_ is not None
        assert est.std_error_ >= 0

    def test_no_bootstrap_gives_none_std_error(self):
        S, cats, anchor_n = simulate_anchor_data(pi=0.7, k=2, n=500, anchor_n=100)
        anchor_sel = lambda X: X < anchor_n
        est = NoiseRateEstimator(categories=cats, anchor_category=0, anchor_selector=anchor_sel)
        est.fit(S, X=np.arange(len(S)), bootstrap=False)
        assert est.std_error_ is None

    def test_n_anchor_correct(self):
        S, cats, anchor_n = simulate_anchor_data(pi=0.7, k=2, n=500, anchor_n=150)
        anchor_sel = lambda X: X < anchor_n
        est = NoiseRateEstimator(categories=cats, anchor_category=0, anchor_selector=anchor_sel)
        est.fit(S, X=np.arange(500))
        assert est.n_anchor_ == anchor_n

    def test_no_anchor_selector_uses_all(self):
        """Without anchor_selector, all observations are used as anchor."""
        # All observations are category 0, so pi_hat should be high
        cats = [0, 1]
        S = np.zeros(100, dtype=int)
        est = NoiseRateEstimator(categories=cats, anchor_category=0)
        est.fit(S)
        assert est.n_anchor_ == 100
        assert est.pi_ > 0.9

    def test_empty_anchor_raises(self):
        S = np.array([0, 1, 0, 1])
        est = NoiseRateEstimator(
            categories=[0, 1],
            anchor_category=0,
            anchor_selector=lambda X: np.zeros(len(X), dtype=bool),
        )
        with pytest.raises(RuntimeError, match="no observations"):
            est.fit(S, X=np.arange(4))

    def test_small_anchor_warns(self):
        S, cats, anchor_n = simulate_anchor_data(pi=0.7, k=2, n=200, anchor_n=10)
        anchor_sel = lambda X: X < anchor_n
        est = NoiseRateEstimator(
            categories=cats, anchor_category=0,
            anchor_selector=anchor_sel, min_anchor_size=50
        )
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            est.fit(S, X=np.arange(len(S)))
            size_warns = [x for x in w if "anchor" in str(x.message).lower()]
            assert len(size_warns) > 0

    def test_wrong_anchor_selector_shape_raises(self):
        S = np.array([0, 1, 0])
        est = NoiseRateEstimator(
            categories=[0, 1],
            anchor_category=0,
            anchor_selector=lambda X: np.ones(5, dtype=bool),  # wrong size
        )
        with pytest.raises(ValueError, match="shape"):
            est.fit(S, X=np.arange(3))

    def test_unknown_value_in_S_raises(self):
        cats = [0, 1]
        S = np.array([0, 1, 2])
        est = NoiseRateEstimator(categories=cats, anchor_category=0)
        with pytest.raises(ValueError, match="not in categories"):
            est.fit(S)

    def test_k3_estimation(self):
        """Test anchor-point estimation with 3 categories."""
        true_pi = 0.7
        k = 3
        rng = np.random.default_rng(99)
        cats = [0, 1, 2]
        pi_bar = (1 - true_pi) / (k - 1)
        n_anchor = 300
        n_total = 1000
        # Anchor: all true = 0
        S_anchor = np.where(rng.uniform(size=n_anchor) < true_pi, 0, rng.integers(1, k, size=n_anchor))
        S_rest = rng.choice(cats, size=n_total - n_anchor)
        S = np.concatenate([S_anchor, S_rest])
        anchor_sel = lambda X: X < n_anchor
        est = NoiseRateEstimator(categories=cats, anchor_category=0, anchor_selector=anchor_sel)
        est.fit(S, X=np.arange(n_total))
        assert abs(est.pi_ - true_pi) < 0.07


# ---------------------------------------------------------------------------
# Unfitted access
# ---------------------------------------------------------------------------

class TestUnfittedAccess:
    def test_to_mechanism_raises_if_not_fitted(self):
        est = NoiseRateEstimator(categories=[0, 1], anchor_category=0)
        with pytest.raises(RuntimeError, match="not been fitted"):
            est.to_mechanism()

    def test_summary_unfitted(self):
        est = NoiseRateEstimator(categories=[0, 1], anchor_category=0)
        s = est.summary()
        assert "not yet fitted" in s


# ---------------------------------------------------------------------------
# to_mechanism()
# ---------------------------------------------------------------------------

class TestToMechanism:
    def test_returns_krr(self):
        S, cats, anchor_n = simulate_anchor_data(pi=0.75, k=2, n=500, anchor_n=100)
        anchor_sel = lambda X: X < anchor_n
        est = NoiseRateEstimator(
            categories=cats, anchor_category=0, anchor_selector=anchor_sel
        )
        est.fit(S, X=np.arange(500))
        krr = est.to_mechanism()
        assert isinstance(krr, KaryRandomisedResponse)
        assert krr.k == 2

    def test_krr_epsilon_matches_estimated(self):
        S, cats, anchor_n = simulate_anchor_data(pi=0.75, k=2, n=500, anchor_n=100)
        anchor_sel = lambda X: X < anchor_n
        est = NoiseRateEstimator(
            categories=cats, anchor_category=0, anchor_selector=anchor_sel
        )
        est.fit(S, X=np.arange(500))
        krr = est.to_mechanism(categories=[0, 1])
        assert abs(krr.epsilon - est.epsilon_) < 1e-6

    def test_custom_categories(self):
        S, cats_int, anchor_n = simulate_anchor_data(pi=0.7, k=2, n=300, anchor_n=60)
        anchor_sel = lambda X: X < anchor_n
        est = NoiseRateEstimator(
            categories=cats_int, anchor_category=0, anchor_selector=anchor_sel
        )
        est.fit(S, X=np.arange(300))
        krr = est.to_mechanism(categories=["White", "Asian"])
        assert krr.categories == ["White", "Asian"]


# ---------------------------------------------------------------------------
# summary()
# ---------------------------------------------------------------------------

class TestSummary:
    def test_summary_fitted(self):
        S, cats, anchor_n = simulate_anchor_data(pi=0.7, k=2, n=500, anchor_n=100)
        anchor_sel = lambda X: X < anchor_n
        est = NoiseRateEstimator(categories=cats, anchor_category=0, anchor_selector=anchor_sel)
        est.fit(S, X=np.arange(500))
        s = est.summary()
        assert "Estimated pi" in s
        assert "Inferred epsilon" in s
        assert "Anchor observations" in s
