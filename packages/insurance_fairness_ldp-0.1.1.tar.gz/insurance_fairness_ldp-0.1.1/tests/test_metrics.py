"""
Tests for insurance_fairness_ldp.metrics.

Covers:
- discrimination_free_indicator: L1/L2/max norms
- group_loss_corrected: shape, correctness with known inputs
- calibration_by_group_ldp: structure and values
- c1_adjusted_error_bound: formula check
- debiased_group_means: roundtrip test
"""

import numpy as np
import pytest

from insurance_fairness_ldp.metrics import (
    calibration_by_group_ldp,
    c1_adjusted_error_bound,
    debiased_group_means,
    discrimination_free_indicator,
    group_loss_corrected,
)
from insurance_fairness_ldp.correction import CorrectionMatrix
from insurance_fairness_ldp._utils import pi_from_epsilon


# ---------------------------------------------------------------------------
# discrimination_free_indicator
# ---------------------------------------------------------------------------

class TestDiscriminationFreeIndicator:
    def test_zero_when_identical(self):
        h = np.array([1.0, 2.0, 3.0])
        assert discrimination_free_indicator(h, h) == 0.0
        assert discrimination_free_indicator(h, h, norm="l1") == 0.0
        assert discrimination_free_indicator(h, h, norm="max") == 0.0

    def test_l2_norm(self):
        h_star = np.array([1.0, 2.0, 3.0])
        h_naive = np.array([2.0, 3.0, 4.0])
        result = discrimination_free_indicator(h_star, h_naive, norm="l2")
        expected = np.sqrt(np.mean(np.ones(3)))  # each diff = 1.0
        assert abs(result - expected) < 1e-10

    def test_l1_norm(self):
        h_star = np.array([1.0, 2.0, 3.0])
        h_naive = np.array([2.0, 4.0, 6.0])
        result = discrimination_free_indicator(h_star, h_naive, norm="l1")
        expected = np.mean([1.0, 2.0, 3.0])
        assert abs(result - expected) < 1e-10

    def test_max_norm(self):
        h_star = np.array([0.0, 0.0, 0.0])
        h_naive = np.array([1.0, 5.0, 3.0])
        result = discrimination_free_indicator(h_star, h_naive, norm="max")
        assert abs(result - 5.0) < 1e-10

    def test_invalid_norm_raises(self):
        h = np.array([1.0, 2.0])
        with pytest.raises(ValueError, match="norm must be"):
            discrimination_free_indicator(h, h, norm="l3")

    def test_shape_mismatch_raises(self):
        h1 = np.array([1.0, 2.0])
        h2 = np.array([1.0, 2.0, 3.0])
        with pytest.raises(ValueError, match="same shape"):
            discrimination_free_indicator(h1, h2)

    def test_nonnegative_always(self):
        rng = np.random.default_rng(0)
        h1 = rng.normal(size=100)
        h2 = rng.normal(size=100)
        for norm in ["l1", "l2", "max"]:
            result = discrimination_free_indicator(h1, h2, norm=norm)
            assert result >= 0


# ---------------------------------------------------------------------------
# group_loss_corrected
# ---------------------------------------------------------------------------

class TestGroupLossCorrected:
    def _make_pi_inv(self, eps=1.0, k=2, group_probs=None):
        pi = pi_from_epsilon(eps, k)
        cm = CorrectionMatrix(pi=pi, k=k)
        if group_probs is None:
            group_probs = np.full(k, 1.0 / k)
        return cm.Pi_inv(group_probs)

    def test_returns_dict_with_all_keys(self):
        cats = ["A", "B"]
        y_true = np.ones(100)
        y_pred = np.ones(100)
        S = np.array(["A"] * 50 + ["B"] * 50)
        Pi_inv = self._make_pi_inv(k=2)
        result = group_loss_corrected(y_true, y_pred, S, cats, Pi_inv)
        assert set(result.keys()) == set(cats)

    def test_zero_loss_when_perfect_predictions(self):
        cats = ["A", "B"]
        y = np.ones(100)
        S = np.array(["A"] * 50 + ["B"] * 50)
        Pi_inv = self._make_pi_inv(k=2)
        result = group_loss_corrected(y, y, S, cats, Pi_inv)
        # Perfect predictions -> loss = 0 for all groups
        for cat in cats:
            assert abs(result[cat]) < 1e-10

    def test_shape_mismatch_raises(self):
        cats = ["A", "B"]
        y_true = np.ones(10)
        y_pred = np.ones(8)
        S = np.array(["A"] * 10)
        Pi_inv = self._make_pi_inv(k=2)
        with pytest.raises(ValueError, match="same shape"):
            group_loss_corrected(y_true, y_pred, S, cats, Pi_inv)

    def test_absolute_loss_option(self):
        cats = ["A", "B"]
        y_true = np.zeros(100)
        y_pred = np.ones(100)
        S = np.array(["A"] * 50 + ["B"] * 50)
        Pi_inv = self._make_pi_inv(k=2)
        result = group_loss_corrected(y_true, y_pred, S, cats, Pi_inv, loss="absolute")
        assert all(np.isfinite(v) for v in result.values())

    def test_invalid_loss_raises(self):
        cats = ["A", "B"]
        Pi_inv = self._make_pi_inv(k=2)
        with pytest.raises(ValueError, match="loss must be"):
            group_loss_corrected(
                np.ones(10), np.ones(10),
                np.array(["A"] * 10), cats, Pi_inv,
                loss="huber"
            )

    def test_finite_results_with_noisy_data(self):
        rng = np.random.default_rng(42)
        cats = ["A", "B", "C"]
        k = len(cats)
        n = 300
        y_true = rng.uniform(100, 500, size=n)
        y_pred = y_true + rng.normal(scale=20, size=n)
        S = rng.choice(cats, size=n)
        pi = pi_from_epsilon(1.0, k)
        cm = CorrectionMatrix(pi=pi, k=k)
        Pi_inv = cm.Pi_inv(np.array([1/3, 1/3, 1/3]))
        result = group_loss_corrected(y_true, y_pred, S, cats, Pi_inv)
        for cat in cats:
            assert np.isfinite(result[cat]) or np.isnan(result[cat])


# ---------------------------------------------------------------------------
# calibration_by_group_ldp
# ---------------------------------------------------------------------------

class TestCalibrationByGroupLdp:
    def test_returns_all_keys(self):
        cats = ["A", "B"]
        y = np.ones(100)
        pred = np.ones(100)
        S = np.array(["A"] * 50 + ["B"] * 50)
        result = calibration_by_group_ldp(y, pred, S, cats)
        assert "group" in result
        assert "n" in result
        assert "mean_actual" in result
        assert "mean_predicted" in result
        assert "calibration_ratio" in result

    def test_correct_n_per_group(self):
        cats = ["A", "B"]
        S = np.array(["A"] * 60 + ["B"] * 40)
        y = np.ones(100)
        result = calibration_by_group_ldp(y, y, S, cats)
        assert result["n"] == [60, 40]

    def test_calibration_ratio_one_when_perfect(self):
        cats = ["A", "B"]
        S = np.array(["A"] * 50 + ["B"] * 50)
        y = np.full(100, 5.0)
        result = calibration_by_group_ldp(y, y, S, cats)
        for r in result["calibration_ratio"]:
            assert abs(r - 1.0) < 1e-9

    def test_empty_group_returns_nan(self):
        cats = ["A", "B", "C"]
        S = np.array(["A"] * 50 + ["B"] * 50)  # no C
        y = np.ones(100)
        result = calibration_by_group_ldp(y, y, S, cats)
        idx_C = result["group"].index("C")
        assert np.isnan(result["mean_actual"][idx_C])

    def test_mean_actual_correct(self):
        cats = ["A", "B"]
        S = np.array(["A"] * 50 + ["B"] * 50)
        y = np.concatenate([np.full(50, 2.0), np.full(50, 4.0)])
        pred = np.ones(100)
        result = calibration_by_group_ldp(y, pred, S, cats)
        assert abs(result["mean_actual"][0] - 2.0) < 1e-9
        assert abs(result["mean_actual"][1] - 4.0) < 1e-9


# ---------------------------------------------------------------------------
# c1_adjusted_error_bound
# ---------------------------------------------------------------------------

class TestC1AdjustedErrorBound:
    def test_known_value(self):
        # base=0.1, c1=2, k=3, p=0.5, M=1 -> inflation = 2*2*1*3/0.5 = 24, bound=2.4
        result = c1_adjusted_error_bound(
            base_bound=0.1, c1=2.0, k=3, p_s_k_star=0.5, M=1.0
        )
        assert abs(result - 2.4) < 1e-9

    def test_zero_p_raises(self):
        with pytest.raises(ValueError, match="positive"):
            c1_adjusted_error_bound(0.1, 2.0, 3, 0.0)

    def test_bound_increases_with_c1(self):
        b1 = c1_adjusted_error_bound(0.1, 1.0, 2, 0.5)
        b2 = c1_adjusted_error_bound(0.1, 3.0, 2, 0.5)
        assert b2 > b1


# ---------------------------------------------------------------------------
# debiased_group_means
# ---------------------------------------------------------------------------

class TestDebiasedGroupMeans:
    def test_returns_all_categories(self):
        cats = ["A", "B"]
        pi = pi_from_epsilon(2.0, 2)
        cm = CorrectionMatrix(pi=pi, k=2)
        T_inv = cm.T_inv()
        y = np.ones(100)
        S = np.array(["A"] * 50 + ["B"] * 50)
        result = debiased_group_means(y, S, cats, T_inv)
        assert set(result.keys()) == set(cats)

    def test_constant_y_returns_constant(self):
        """If y is constant, debiased mean should equal that constant regardless of group."""
        cats = ["A", "B"]
        pi = pi_from_epsilon(1.0, 2)
        cm = CorrectionMatrix(pi=pi, k=2)
        T_inv = cm.T_inv()
        y = np.full(100, 5.0)
        S = np.array(["A"] * 50 + ["B"] * 50)
        result = debiased_group_means(y, S, cats, T_inv)
        for cat in cats:
            assert abs(result[cat] - 5.0) < 0.1  # small tolerance due to correction

    def test_finite_results(self):
        rng = np.random.default_rng(0)
        cats = ["A", "B", "C"]
        k = 3
        pi = pi_from_epsilon(1.5, k)
        cm = CorrectionMatrix(pi=pi, k=k)
        T_inv = cm.T_inv()
        y = rng.uniform(0, 1000, size=300)
        S = rng.choice(cats, size=300)
        result = debiased_group_means(y, S, cats, T_inv)
        for cat in cats:
            assert np.isfinite(result[cat]) or np.isnan(result[cat])
