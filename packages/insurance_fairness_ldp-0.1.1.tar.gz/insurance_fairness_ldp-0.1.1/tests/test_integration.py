"""
Integration tests for insurance_fairness_ldp.

End-to-end workflow tests:
1. Privatise -> Correct -> Price -> Report (known epsilon, binary attribute)
2. Privatise -> Correct -> Price -> Report (known epsilon, 4-category attribute)
3. Unknown epsilon: anchor estimation -> pricing
4. Comparison with naive model: h* vs h_naive
5. Report markdown generation
6. Discrimination-free property under perfect LDP (high epsilon limit)
"""

import tempfile
from pathlib import Path

import numpy as np
import pytest
from sklearn.linear_model import Ridge, LinearRegression

from insurance_fairness_ldp import (
    KaryRandomisedResponse,
    CorrectionMatrix,
    LDPDiscriminationFreePrice,
    LDPFairnessReport,
    NoiseRateEstimator,
    privatise,
    discrimination_free_indicator,
    calibration_by_group_ldp,
)
from insurance_fairness_ldp._utils import pi_from_epsilon


# ---------------------------------------------------------------------------
# Synthetic dataset
# ---------------------------------------------------------------------------

def synthetic_insurance_dataset(n=1500, k=2, epsilon=1.5, seed=0):
    """
    Simulate a UK motor insurance portfolio with privatised ethnicity.

    X: age_norm, ncb_norm, mileage_norm, vehicle_value_norm (4 features)
    D: true protected category (k groups)
    y: pure premium (log-normal)
    S: privatised D via k-RR(epsilon)
    """
    rng = np.random.default_rng(seed)
    cats = [f"Group_{i}" for i in range(k)]

    # Features
    age = rng.uniform(18, 70, size=n)
    ncb = rng.integers(0, 9, size=n).astype(float)
    mileage = rng.uniform(3000, 30000, size=n)
    value = rng.uniform(5000, 50000, size=n)
    X = np.column_stack([
        (age - 40) / 15,
        ncb / 8,
        (mileage - 15000) / 10000,
        (value - 20000) / 15000,
    ])

    # True group
    group_sizes = rng.dirichlet(np.ones(k) * 5)
    D = rng.choice(cats, size=n, p=group_sizes)

    # Premium: base risk + group effect + feature effects
    group_effects = {cat: i * 0.3 for i, cat in enumerate(cats)}
    D_effect = np.array([group_effects[d] for d in D])
    log_premium = (
        5.5
        + 0.3 * X[:, 0]   # age effect
        - 0.2 * X[:, 1]   # NCB discount
        + 0.1 * X[:, 2]   # mileage
        + D_effect
        + rng.normal(scale=0.4, size=n)
    )
    y = np.exp(log_premium)

    # Privatise
    krr = KaryRandomisedResponse(epsilon=epsilon, categories=cats)
    S_private = krr.privatise(D, random_state=seed)

    return X, D, S_private, y, krr, cats


# ---------------------------------------------------------------------------
# Test 1: Full workflow, binary attribute
# ---------------------------------------------------------------------------

class TestFullWorkflowBinary:
    def test_end_to_end_binary(self):
        X, D, S, y, krr, cats = synthetic_insurance_dataset(n=1000, k=2)
        model = LDPDiscriminationFreePrice(
            base_estimator=Ridge(), mechanism=krr
        )
        model.fit(X, S, y)
        preds = model.predict(X)

        assert preds.shape == (1000,)
        assert np.all(preds > 0)  # premiums should be positive (log-normal data)
        assert np.all(np.isfinite(preds))

    def test_binary_report_generation(self):
        X, D, S, y, krr, cats = synthetic_insurance_dataset(n=1000, k=2)
        model = LDPDiscriminationFreePrice(base_estimator=Ridge(), mechanism=krr)
        model.fit(X, S, y)
        report = LDPFairnessReport.from_model(model, X, S, y=y)
        assert report.epsilon == krr.epsilon
        assert len(report.group_losses) == 2

    def test_binary_markdown_output(self):
        X, D, S, y, krr, cats = synthetic_insurance_dataset(n=800, k=2)
        model = LDPDiscriminationFreePrice(base_estimator=Ridge(), mechanism=krr)
        model.fit(X, S, y)
        report = LDPFairnessReport.from_model(model, X, S, y=y)
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "test_report.md"
            report.to_markdown(path)
            assert path.exists()
            content = path.read_text()
            assert "## Privacy Mechanism" in content
            assert "## Regulatory Context" in content


# ---------------------------------------------------------------------------
# Test 2: Four-category attribute
# ---------------------------------------------------------------------------

class TestFullWorkflowFourCategories:
    def test_k4_workflow(self):
        X, D, S, y, krr, cats = synthetic_insurance_dataset(n=2000, k=4, epsilon=1.5)
        model = LDPDiscriminationFreePrice(base_estimator=Ridge(), mechanism=krr)
        model.fit(X, S, y)
        preds = model.predict(X)
        assert preds.shape == (2000,)
        assert np.all(np.isfinite(preds))

    def test_k4_group_models(self):
        X, D, S, y, krr, cats = synthetic_insurance_dataset(n=2000, k=4)
        model = LDPDiscriminationFreePrice(base_estimator=Ridge(), mechanism=krr)
        model.fit(X, S, y)
        assert len(model.group_models_) == 4

    def test_k4_reference_dist_sums_to_one(self):
        X, D, S, y, krr, cats = synthetic_insurance_dataset(n=2000, k=4)
        model = LDPDiscriminationFreePrice(base_estimator=Ridge(), mechanism=krr)
        model.fit(X, S, y)
        assert abs(model.reference_dist_.sum() - 1.0) < 1e-6


# ---------------------------------------------------------------------------
# Test 3: Unknown epsilon via anchor estimation
# ---------------------------------------------------------------------------

class TestUnknownEpsilonWorkflow:
    def test_anchor_estimation_then_pricing(self):
        """Full Phase 2 workflow: estimate epsilon from anchor, then price."""
        rng = np.random.default_rng(77)
        cats = ["Group_0", "Group_1"]
        n = 1500
        epsilon = 1.5
        krr_true = KaryRandomisedResponse(epsilon=epsilon, categories=cats)

        # True group: first 300 are all Group_0 (anchor), rest are mixed
        anchor_n = 300
        D_true = np.array(["Group_0"] * anchor_n + list(rng.choice(cats, size=n-anchor_n)))

        X = rng.normal(size=(n, 4))
        y = X[:, 0] + rng.normal(scale=0.5, size=n)
        S = krr_true.privatise(D_true, random_state=77)

        # Anchor selector: first 300 observations
        anchor_sel = lambda X_: np.arange(len(X_)) < anchor_n

        estimator = NoiseRateEstimator(
            categories=cats,
            anchor_category="Group_0",
            anchor_selector=anchor_sel,
            min_anchor_size=10,
        )
        estimator.fit(S, X=np.arange(n), bootstrap=False)

        # Should have estimated pi close to true pi
        assert estimator.pi_ is not None
        assert estimator.epsilon_ > 0.1  # valid epsilon

        # Get mechanism from estimator
        krr_est = estimator.to_mechanism()

        model = LDPDiscriminationFreePrice(
            base_estimator=Ridge(), mechanism=krr_est
        )
        model.fit(X, S, y)
        preds = model.predict(X)
        assert preds.shape == (n,)
        assert np.all(np.isfinite(preds))


# ---------------------------------------------------------------------------
# Test 4: Discrimination-free property check
# ---------------------------------------------------------------------------

class TestDiscriminationFreeProperty:
    def test_h_star_differs_from_naive(self):
        """When LDP correction matters, h*(X) should differ from naive mean."""
        X, D, S, y, krr, cats = synthetic_insurance_dataset(n=1500, k=2, epsilon=1.5)
        model = LDPDiscriminationFreePrice(base_estimator=Ridge(), mechanism=krr)
        model.fit(X, S, y)
        h_star = model.predict(X)
        h_naive = np.full(len(X), np.mean(y))
        disc_idx = discrimination_free_indicator(h_star, h_naive)
        # There should be some difference (model learns from features)
        assert disc_idx > 0

    def test_h_star_weighted_avg_of_group_models(self):
        """h*(X) = sum_k f_k(X) * P*(D=k) — verify this algebraic identity."""
        X, D, S, y, krr, cats = synthetic_insurance_dataset(n=800, k=3)
        model = LDPDiscriminationFreePrice(base_estimator=Ridge(), mechanism=krr)
        model.fit(X, S, y)
        h_star = model.predict(X)
        h_manual = sum(
            model.predict_group(X, cat) * model.reference_dist_[i]
            for i, cat in enumerate(cats)
        )
        np.testing.assert_allclose(h_star, h_manual, atol=1e-8)


# ---------------------------------------------------------------------------
# Test 5: Calibration check
# ---------------------------------------------------------------------------

class TestCalibrationCheck:
    def test_calibration_structure(self):
        X, D, S, y, krr, cats = synthetic_insurance_dataset(n=1000, k=2)
        model = LDPDiscriminationFreePrice(base_estimator=Ridge(), mechanism=krr)
        model.fit(X, S, y)
        h_star = model.predict(X)
        cal = calibration_by_group_ldp(y, h_star, S, cats)
        assert len(cal["group"]) == 2
        assert all(n > 0 for n in cal["n"])


# ---------------------------------------------------------------------------
# Test 6: T @ T_inv = I across multiple epsilon/k combinations
# ---------------------------------------------------------------------------

class TestCorrectionMatrixConsistency:
    @pytest.mark.parametrize("epsilon,k", [
        (0.5, 2), (1.0, 2), (2.0, 3), (3.0, 4), (5.0, 5),
    ])
    def test_T_T_inv_identity(self, epsilon, k):
        krr = KaryRandomisedResponse(epsilon=epsilon, categories=list(range(k)))
        T = krr.correction_matrix()
        cm = CorrectionMatrix.from_mechanism(krr)
        T_inv = cm.T_inv()
        product = T @ T_inv
        np.testing.assert_allclose(product, np.eye(k), atol=1e-8)
