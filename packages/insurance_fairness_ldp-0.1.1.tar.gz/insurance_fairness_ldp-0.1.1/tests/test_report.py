"""
Tests for insurance_fairness_ldp.report.

Covers:
- LDPFairnessReport construction
- summary() text output
- to_markdown() file writing
- from_model() factory method
- Regulatory section present in markdown
"""

import tempfile
from pathlib import Path

import numpy as np
import pytest
from sklearn.linear_model import Ridge

from insurance_fairness_ldp import (
    KaryRandomisedResponse,
    LDPDiscriminationFreePrice,
    LDPFairnessReport,
)
from insurance_fairness_ldp.report import LDPFairnessReport


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_fitted_model(n=400, k=2, epsilon=1.5, seed=42):
    rng = np.random.default_rng(seed)
    cats = [f"G{i}" for i in range(k)]
    X = rng.normal(size=(n, 4))
    D = rng.choice(cats, size=n)
    y = X[:, 0] + rng.normal(scale=0.5, size=n)
    krr = KaryRandomisedResponse(epsilon=epsilon, categories=cats)
    S_private = krr.privatise(D, random_state=seed)
    model = LDPDiscriminationFreePrice(base_estimator=Ridge(), mechanism=krr)
    model.fit(X, S_private, y)
    return model, X, S_private, y, krr, cats


def make_report_direct(k=2, n=100):
    cats = [f"G{i}" for i in range(k)]
    rng = np.random.default_rng(0)
    eps = 1.5
    pi = np.exp(eps) / (k - 1 + np.exp(eps))
    from insurance_fairness_ldp._utils import pi_from_epsilon
    pi = pi_from_epsilon(eps, k)
    from insurance_fairness_ldp._utils import accuracy_constant
    c1 = accuracy_constant(pi, k)
    h_star = rng.uniform(100, 500, size=n)
    return LDPFairnessReport(
        epsilon=eps,
        k=k,
        categories=cats,
        pi=pi,
        accuracy_constant=c1,
        reference_dist=np.full(k, 1 / k),
        noisy_dist=np.full(k, 1 / k),
        group_predictions={c: rng.uniform(100, 500, size=n) for c in cats},
        reference_premiums=h_star,
        n_samples=500,
    )


# ---------------------------------------------------------------------------
# Direct construction
# ---------------------------------------------------------------------------

class TestLDPFairnessReportDirect:
    def test_construction(self):
        report = make_report_direct()
        assert report.epsilon == 1.5
        assert report.k == 2
        assert len(report.categories) == 2

    def test_summary_returns_string(self):
        report = make_report_direct()
        s = report.summary()
        assert isinstance(s, str)
        assert len(s) > 100

    def test_summary_contains_epsilon(self):
        report = make_report_direct()
        s = report.summary()
        assert "epsilon" in s.lower()

    def test_summary_contains_pi(self):
        report = make_report_direct()
        s = report.summary()
        assert "pi" in s.lower()

    def test_summary_contains_c1(self):
        report = make_report_direct()
        s = report.summary()
        assert "C1" in s or "c1" in s.lower()

    def test_summary_contains_premium_stats(self):
        report = make_report_direct()
        s = report.summary()
        assert "mean" in s.lower()

    def test_summary_with_discrimination_index(self):
        report = make_report_direct()
        report.discrimination_index = 12.5
        s = report.summary()
        assert "12.5" in s or "Discrimination" in s

    def test_summary_with_notes(self):
        report = make_report_direct()
        report.notes = "Test note for regulatory file."
        s = report.summary()
        assert "Test note" in s

    def test_generated_at_is_iso(self):
        report = make_report_direct()
        # Should be parseable as datetime
        from datetime import datetime
        datetime.fromisoformat(report.generated_at)


# ---------------------------------------------------------------------------
# to_markdown()
# ---------------------------------------------------------------------------

class TestToMarkdown:
    def test_creates_file(self):
        report = make_report_direct()
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "report.md"
            report.to_markdown(path)
            assert path.exists()
            content = path.read_text()
            assert len(content) > 100

    def test_markdown_contains_heading(self):
        report = make_report_direct()
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "report.md"
            report.to_markdown(path)
            content = path.read_text()
            assert "# LDP Discrimination-Free Pricing Report" in content

    def test_markdown_contains_privacy_mechanism_section(self):
        report = make_report_direct()
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "report.md"
            report.to_markdown(path)
            content = path.read_text()
            assert "## Privacy Mechanism" in content

    def test_markdown_contains_regulatory_section(self):
        report = make_report_direct()
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "report.md"
            report.to_markdown(path)
            content = path.read_text()
            assert "Regulatory" in content

    def test_markdown_contains_gdpr_mention(self):
        report = make_report_direct()
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "report.md"
            report.to_markdown(path)
            content = path.read_text()
            assert "GDPR" in content

    def test_markdown_contains_architecture_warning(self):
        report = make_report_direct()
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "report.md"
            report.to_markdown(path)
            content = path.read_text()
            assert "Trusted Third Party" in content or "TTP" in content

    def test_markdown_with_discrimination_index(self):
        report = make_report_direct()
        report.discrimination_index = 42.7
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "report.md"
            report.to_markdown(path)
            content = path.read_text()
            assert "Discrimination" in content

    def test_markdown_string_path(self):
        report = make_report_direct()
        with tempfile.TemporaryDirectory() as tmpdir:
            path = str(Path(tmpdir) / "report.md")
            report.to_markdown(path)
            assert Path(path).exists()


# ---------------------------------------------------------------------------
# from_model() factory
# ---------------------------------------------------------------------------

class TestFromModel:
    def test_from_model_basic(self):
        model, X, S, y, krr, cats = make_fitted_model()
        report = LDPFairnessReport.from_model(model, X, S)
        assert report.epsilon == krr.epsilon
        assert report.k == krr.k
        assert report.categories == cats
        assert report.reference_premiums.shape == (len(X),)

    def test_from_model_with_y(self):
        model, X, S, y, krr, cats = make_fitted_model()
        report = LDPFairnessReport.from_model(model, X, S, y=y)
        assert len(report.group_losses) == krr.k
        assert len(report.calibration) > 0

    def test_from_model_with_naive(self):
        model, X, S, y, krr, cats = make_fitted_model()
        h_naive = np.mean(y) * np.ones(len(X))
        report = LDPFairnessReport.from_model(model, X, S, y=y, h_naive=h_naive)
        assert report.discrimination_index is not None
        assert report.discrimination_index >= 0

    def test_from_model_unfitted_raises(self):
        krr = KaryRandomisedResponse(epsilon=1.0, categories=["A", "B"])
        model = LDPDiscriminationFreePrice(base_estimator=Ridge(), mechanism=krr)
        with pytest.raises(RuntimeError, match="fitted"):
            LDPFairnessReport.from_model(model, np.zeros((5, 3)), np.array(["A"] * 5))

    def test_from_model_summary_callable(self):
        model, X, S, y, krr, cats = make_fitted_model()
        report = LDPFairnessReport.from_model(model, X, S, y=y)
        s = report.summary()
        assert isinstance(s, str)
        assert len(s) > 50

    def test_from_model_k3(self):
        model, X, S, y, krr, cats = make_fitted_model(k=3, n=600)
        report = LDPFairnessReport.from_model(model, X, S)
        assert report.k == 3
        assert len(report.categories) == 3
