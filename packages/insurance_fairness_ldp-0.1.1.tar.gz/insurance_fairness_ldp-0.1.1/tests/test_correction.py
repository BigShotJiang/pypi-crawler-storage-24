"""
Tests for insurance_fairness_ldp.correction.

Covers:
- CorrectionMatrix construction and validation
- T_inv() correctness: T @ T_inv = I
- Pi_inv() shape, row behaviour
- debias_probs() correctness and clipping
- accuracy_constant()
- Numerical stability concerns at low epsilon
- from_mechanism() factory
"""

import warnings

import numpy as np
import pytest

from insurance_fairness_ldp.correction import CorrectionMatrix
from insurance_fairness_ldp.mechanisms import KaryRandomisedResponse
from insurance_fairness_ldp._utils import pi_from_epsilon, accuracy_constant


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_cm(epsilon=1.0, k=2):
    pi = pi_from_epsilon(epsilon, k)
    return CorrectionMatrix(pi=pi, k=k)


# ---------------------------------------------------------------------------
# CorrectionMatrix construction
# ---------------------------------------------------------------------------

class TestCorrectionMatrixInit:
    def test_basic_construction(self):
        pi = pi_from_epsilon(1.0, 2)
        cm = CorrectionMatrix(pi=pi, k=2)
        assert abs(cm.pi - pi) < 1e-10
        assert cm.k == 2

    def test_pi_equal_to_one_over_k_raises(self):
        with pytest.raises(ValueError, match="1/k"):
            CorrectionMatrix(pi=0.5, k=2)  # exactly 1/2

    def test_pi_below_one_over_k_raises(self):
        with pytest.raises(ValueError):
            CorrectionMatrix(pi=0.2, k=4)  # 0.2 < 0.25 = 1/4

    def test_pi_one_allowed(self):
        # pi=1 means no noise, C1=1 — should not raise
        cm = CorrectionMatrix(pi=1.0, k=2)
        assert cm.pi == 1.0

    def test_high_c1_warns(self):
        # k=10, small epsilon => large C1
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            pi = pi_from_epsilon(0.3, k=10)
            CorrectionMatrix(pi=pi, k=10)
            c1_warns = [x for x in w if "C1" in str(x.message)]
            assert len(c1_warns) > 0

    def test_repr(self):
        cm = make_cm(epsilon=1.0, k=2)
        r = repr(cm)
        assert "CorrectionMatrix" in r
        assert "C1=" in r


# ---------------------------------------------------------------------------
# T_inv() correctness
# ---------------------------------------------------------------------------

class TestTInv:
    def test_T_times_T_inv_equals_identity_k2(self):
        krr = KaryRandomisedResponse(epsilon=1.0, categories=["A", "B"])
        T = krr.correction_matrix()
        cm = CorrectionMatrix.from_mechanism(krr)
        T_inv = cm.T_inv()
        product = T @ T_inv
        np.testing.assert_allclose(product, np.eye(2), atol=1e-10)

    def test_T_times_T_inv_equals_identity_k4(self):
        krr = KaryRandomisedResponse(epsilon=1.5, categories=list(range(4)))
        T = krr.correction_matrix()
        cm = CorrectionMatrix.from_mechanism(krr)
        T_inv = cm.T_inv()
        product = T @ T_inv
        np.testing.assert_allclose(product, np.eye(4), atol=1e-9)

    def test_T_inv_row_sums_to_one(self):
        """T^{-1} row sums = 1 (signed measure property)."""
        for k in [2, 3, 5]:
            cm = make_cm(epsilon=1.0, k=k)
            T_inv = cm.T_inv()
            np.testing.assert_allclose(T_inv.sum(axis=1), 1.0, atol=1e-10)

    def test_T_inv_shape(self):
        for k in [2, 3, 5, 10]:
            cm = make_cm(epsilon=1.0, k=k)
            T_inv = cm.T_inv()
            assert T_inv.shape == (k, k)

    def test_T_inv_diagonal_greater_than_one(self):
        """Diagonal of T^{-1} > 1 for epsilon < inf."""
        cm = make_cm(epsilon=1.0, k=3)
        T_inv = cm.T_inv()
        assert np.all(np.diag(T_inv) > 1.0)

    def test_T_inv_off_diagonal_negative(self):
        """Off-diagonal of T^{-1} should be negative (signed measure)."""
        cm = make_cm(epsilon=1.0, k=3)
        T_inv = cm.T_inv()
        k = 3
        for i in range(k):
            for j in range(k):
                if i != j:
                    assert T_inv[i, j] < 0

    def test_T_inv_large_epsilon_near_identity(self):
        """Large epsilon -> T near I -> T^{-1} near I."""
        cm = make_cm(epsilon=20.0, k=3)
        T_inv = cm.T_inv()
        np.testing.assert_allclose(T_inv, np.eye(3), atol=0.01)

    def test_T_inv_known_formula_k2(self):
        """Test against closed-form for k=2."""
        eps = 1.0
        pi = pi_from_epsilon(eps, k=2)
        k = 2
        denom = k * pi - 1
        diag_expected = (pi + k - 2) / denom
        off_expected = (pi - 1) / denom
        cm = CorrectionMatrix(pi=pi, k=k)
        T_inv = cm.T_inv()
        assert abs(T_inv[0, 0] - diag_expected) < 1e-10
        assert abs(T_inv[0, 1] - off_expected) < 1e-10

    def test_singular_at_pi_equals_one_over_k(self):
        """pi = 1/k + small epsilon should produce large entries, not crash."""
        pi = 0.5 + 1e-4  # just above 1/2 for k=2
        cm = CorrectionMatrix(pi=pi, k=2)
        T_inv = cm.T_inv()
        # Should produce large but finite values
        assert np.all(np.isfinite(T_inv))
        assert T_inv[0, 0] > 1000


# ---------------------------------------------------------------------------
# Pi_inv()
# ---------------------------------------------------------------------------

class TestPiInv:
    def test_shape(self):
        cm = make_cm(epsilon=1.0, k=3)
        group_probs = np.array([0.5, 0.3, 0.2])
        Pi_inv = cm.Pi_inv(group_probs)
        assert Pi_inv.shape == (3, 3)

    def test_invalid_group_probs_negative(self):
        cm = make_cm(epsilon=1.0, k=2)
        with pytest.raises(ValueError, match="strictly positive"):
            cm.Pi_inv(np.array([-0.1, 1.1]))

    def test_invalid_group_probs_zero(self):
        cm = make_cm(epsilon=1.0, k=2)
        with pytest.raises(ValueError, match="strictly positive"):
            cm.Pi_inv(np.array([0.0, 1.0]))

    def test_invalid_group_probs_dont_sum_to_one(self):
        cm = make_cm(epsilon=1.0, k=2)
        with pytest.raises(ValueError, match="sum to 1"):
            cm.Pi_inv(np.array([0.3, 0.3]))

    def test_balanced_groups(self):
        """For balanced groups and high epsilon, Pi_inv should be close to T_inv."""
        eps = 5.0
        k = 3
        cm = make_cm(epsilon=eps, k=k)
        p = np.array([1/3, 1/3, 1/3])
        Pi_inv = cm.Pi_inv(p)
        # At high eps, T is near I, so Pi_inv should be near I / p diagonal
        assert Pi_inv.shape == (k, k)
        # All finite
        assert np.all(np.isfinite(Pi_inv))

    def test_pi_inv_different_from_t_inv_unbalanced(self):
        """Pi_inv != T_inv when groups are unbalanced."""
        cm = make_cm(epsilon=1.0, k=2)
        T_inv = cm.T_inv()
        # Unbalanced
        Pi_inv = cm.Pi_inv(np.array([0.8, 0.2]))
        assert not np.allclose(Pi_inv, T_inv)


# ---------------------------------------------------------------------------
# debias_probs()
# ---------------------------------------------------------------------------

class TestDebiasProbs:
    def test_identity_roundtrip(self):
        """Apply T to a distribution then debias should recover the original."""
        eps = 2.0
        k = 3
        cm = make_cm(epsilon=eps, k=k)
        pi = pi_from_epsilon(eps, k)
        pi_bar = (1 - pi) / (k - 1)

        # True distribution
        p_true = np.array([0.5, 0.3, 0.2])

        # Apply T (column stochastic: noisy[j] = sum_i T[i,j]*p[i])
        T = np.full((k, k), pi_bar)
        np.fill_diagonal(T, pi)
        p_noisy = T.T @ p_true

        # Debias should recover p_true
        p_recovered = cm.debias_probs(p_noisy, clip=False)
        np.testing.assert_allclose(p_recovered, p_true, atol=1e-10)

    def test_wrong_shape_raises(self):
        cm = make_cm(epsilon=1.0, k=3)
        with pytest.raises(ValueError, match="shape"):
            cm.debias_probs(np.array([0.5, 0.5]))  # wrong length

    def test_clipping_warns(self):
        """Small sample noisy frequencies can produce negative debiased probs."""
        eps = 0.5
        k = 3
        cm = make_cm(epsilon=eps, k=k)
        # Extreme noisy distribution that will produce negative after T^{-1}
        q = np.array([0.9, 0.05, 0.05])
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            p_hat = cm.debias_probs(q, clip=True)
            clip_warns = [x for x in w if "negative" in str(x.message).lower()]
            # Result should be non-negative and sum to 1
            assert np.all(p_hat >= 0)
            assert abs(p_hat.sum() - 1.0) < 1e-9

    def test_no_clip_can_return_negative(self):
        eps = 0.5
        k = 3
        cm = make_cm(epsilon=eps, k=k)
        q = np.array([0.9, 0.05, 0.05])
        # Without clipping, may have negative entries
        p_hat = cm.debias_probs(q, clip=False)
        # Should have unit sum
        assert abs(p_hat.sum() - 1.0) < 1e-9

    def test_uniform_input_returns_uniform(self):
        """T applied to uniform stays uniform, so T^{-1} of uniform = uniform."""
        k = 4
        cm = make_cm(epsilon=1.0, k=k)
        q = np.full(k, 0.25)
        p_hat = cm.debias_probs(q, clip=False)
        np.testing.assert_allclose(p_hat, q, atol=1e-10)


# ---------------------------------------------------------------------------
# accuracy_constant()
# ---------------------------------------------------------------------------

class TestAccuracyConstant:
    def test_k2_eps1(self):
        cm = make_cm(epsilon=1.0, k=2)
        c1 = cm.accuracy_constant()
        assert abs(c1 - 1.582) < 0.01

    def test_k4_eps1(self):
        cm = make_cm(epsilon=1.0, k=4)
        c1 = cm.accuracy_constant()
        assert abs(c1 - 2.746) < 0.01

    def test_large_epsilon_approaches_one(self):
        cm = make_cm(epsilon=20.0, k=2)
        c1 = cm.accuracy_constant()
        assert abs(c1 - 1.0) < 0.01

    def test_always_geq_one(self):
        for eps in [0.5, 1.0, 2.0, 5.0]:
            for k in [2, 3, 5]:
                cm = make_cm(epsilon=eps, k=k)
                assert cm.accuracy_constant() >= 1.0 - 1e-9


# ---------------------------------------------------------------------------
# from_mechanism() factory
# ---------------------------------------------------------------------------

class TestFromMechanism:
    def test_from_mechanism_matches_direct(self):
        krr = KaryRandomisedResponse(epsilon=1.5, categories=["A", "B", "C"])
        cm_from = CorrectionMatrix.from_mechanism(krr)
        cm_direct = CorrectionMatrix(pi=krr.pi, k=krr.k)
        assert abs(cm_from.pi - cm_direct.pi) < 1e-10
        assert cm_from.k == cm_direct.k

    def test_T_inv_matches(self):
        krr = KaryRandomisedResponse(epsilon=2.0, categories=list(range(4)))
        cm = CorrectionMatrix.from_mechanism(krr)
        T_inv = cm.T_inv()
        T = krr.correction_matrix()
        product = T @ T_inv
        np.testing.assert_allclose(product, np.eye(4), atol=1e-9)
