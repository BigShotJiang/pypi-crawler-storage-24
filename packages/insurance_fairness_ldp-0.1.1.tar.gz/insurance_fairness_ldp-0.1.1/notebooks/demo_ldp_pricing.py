# Databricks notebook source
# insurance-fairness-ldp: Full Workflow Demo
#
# This notebook demonstrates the complete LDP discrimination-free pricing
# workflow on a synthetic UK motor insurance portfolio.
#
# Sections:
# 1. Installation and imports
# 2. Synthetic portfolio generation
# 3. Phase 1: Known epsilon — privatise, correct, price
# 4. Phase 2: Unknown epsilon — anchor-point estimation
# 5. Fairness report generation
# 6. Comparison with naive pricing
# 7. Privacy-accuracy trade-off visualisation

# COMMAND ----------

# MAGIC %pip install insurance-fairness-ldp scikit-learn polars numpy scipy --quiet

# COMMAND ----------

import numpy as np
import polars as pl
from sklearn.linear_model import Ridge
from sklearn.ensemble import GradientBoostingRegressor

from insurance_fairness_ldp import (
    KaryRandomisedResponse,
    CorrectionMatrix,
    LDPDiscriminationFreePrice,
    LDPFairnessReport,
    NoiseRateEstimator,
    privatise,
    discrimination_free_indicator,
    calibration_by_group_ldp,
)
from insurance_fairness_ldp._utils import pi_from_epsilon, accuracy_constant

print("insurance-fairness-ldp loaded successfully.")

# COMMAND ----------

# =============================================================================
# SECTION 1: Synthetic UK motor insurance portfolio
# =============================================================================
#
# We simulate a portfolio of 5,000 UK motor policies with:
# - Features: age, NCB level, annual mileage, vehicle value
# - True ethnicity D (4 groups, GDPR Art. 9 data — never given to insurer)
# - Claim cost y (log-normal, group-varying baseline risk)
# - Privatised ethnicity S via k-RR(epsilon=1.5)
#
# In a real deployment, policyholders apply k-RR themselves before submitting.

rng = np.random.default_rng(42)
n = 5000
cats = ["White", "Asian", "Black", "Other"]
k = len(cats)

# Portfolio features
age = rng.uniform(18, 75, size=n)
ncb = rng.integers(0, 9, size=n).astype(float)
mileage = rng.uniform(3000, 30000, size=n)
value = rng.uniform(5000, 60000, size=n)

X = np.column_stack([
    (age - 40) / 15,        # age_norm
    ncb / 8,                # ncb_norm
    (mileage - 15000) / 10000,  # mileage_norm
    (value - 25000) / 20000,    # value_norm
])

# True ethnicity (GDPR Art. 9 — insurer never sees this)
group_probs = np.array([0.60, 0.20, 0.12, 0.08])
D_true = rng.choice(cats, size=n, p=group_probs)

# Claim cost: actuarially driven (age, NCB, mileage) + small group baseline
# Group effects represent underlying risk differences, NOT discrimination
group_risk = {"White": 0.0, "Asian": 0.15, "Black": 0.20, "Other": 0.10}
D_risk = np.array([group_risk[d] for d in D_true])

log_premium = (
    5.8
    + 0.4 * np.abs(X[:, 0])     # age has nonlinear risk effect
    - 0.25 * X[:, 1]             # NCB discount
    + 0.15 * X[:, 2]             # mileage loading
    + D_risk                      # group baseline (actuarial, not discriminatory)
    + rng.normal(scale=0.45, size=n)
)
y = np.exp(log_premium)

print(f"Portfolio: n={n}, k={k} groups")
print(f"True group distribution: {dict(zip(cats, group_probs))}")
print(f"Claim cost: mean=£{y.mean():.0f}, std=£{y.std():.0f}")

# COMMAND ----------

# =============================================================================
# SECTION 2: Phase 1 — Known epsilon
# =============================================================================
#
# The insurer knows the privacy parameter epsilon used by policyholders.
# Typical scenario: the insurer specifies epsilon in their data collection
# protocol (e.g. in their DSAR/privacy notice).

EPSILON = 1.5
print(f"\nPrivacy parameter: epsilon={EPSILON}")

# Instantiate the k-RR mechanism
krr = KaryRandomisedResponse(epsilon=EPSILON, categories=cats)
print(f"Truth probability pi = {krr.pi:.4f}")
print(f"Confusion probability pi_bar = {krr.pi_bar:.4f}")

# Privacy-accuracy constant
from insurance_fairness_ldp._utils import accuracy_constant
c1 = accuracy_constant(krr.pi, k)
print(f"Accuracy constant C1 = {c1:.3f} (bound inflated by {(c1-1)*100:.1f}% vs direct observation)")

# In a real deployment: policyholders apply privatise() themselves.
# In simulation: we apply it on their behalf.
S_private = krr.privatise(D_true, random_state=42)

print(f"\nNoisy group distribution (what insurer sees):")
for cat in cats:
    noisy_freq = np.mean(S_private == cat)
    true_freq = np.mean(np.array(D_true) == cat)
    print(f"  P_hat(S={cat!r}) = {noisy_freq:.3f}  (true: {true_freq:.3f})")

# COMMAND ----------

# =============================================================================
# SECTION 3: Correction matrix and debiased distribution
# =============================================================================

cm = CorrectionMatrix.from_mechanism(krr)
T_inv = cm.T_inv()

print("T^{-1} matrix (corrects frequency distributions):")
print(np.round(T_inv, 4))

# Verify: T @ T_inv = I
T = krr.correction_matrix()
product = T @ T_inv
print(f"\nT @ T^{{-1}} = I? Max deviation: {np.max(np.abs(product - np.eye(k))):.2e}")

# Debiased group probabilities
from insurance_fairness_ldp._utils import empirical_frequencies
noisy_freqs = empirical_frequencies(S_private, cats)
debiased_freqs = cm.debias_probs(noisy_freqs, clip=True)

print("\nDebiased vs true group distribution:")
df_compare = pl.DataFrame({
    "Category": cats,
    "True P(D)": group_probs.tolist(),
    "Noisy P_hat(S)": noisy_freqs.tolist(),
    "Debiased P_hat*(D)": debiased_freqs.tolist(),
})
print(df_compare)

# COMMAND ----------

# =============================================================================
# SECTION 4: Fit discrimination-free pricing model
# =============================================================================
#
# Split into train/test

n_train = 4000
X_train, X_test = X[:n_train], X[n_train:]
S_train, S_test = S_private[:n_train], S_private[n_train:]
D_test = np.array(D_true[n_train:])
y_train, y_test = y[:n_train], y[n_train:]

# Fit LDP discrimination-free model
model = LDPDiscriminationFreePrice(
    base_estimator=Ridge(alpha=1.0),
    mechanism=krr,
    reference_dist="marginal",
)
model.fit(X_train, S_train, y_train)

print(f"Fitted model with {k} group-specific Ridge regressors.")
print(f"Reference distribution P*(D): {dict(zip(cats, model.reference_dist_.round(4)))}")

# Predict discrimination-free premiums
h_star = model.predict(X_test)

print(f"\nDiscrimination-free premiums h*(X):")
print(f"  mean = £{h_star.mean():.0f}")
print(f"  std  = £{h_star.std():.0f}")
print(f"  min  = £{h_star.min():.0f}")
print(f"  max  = £{h_star.max():.0f}")

# COMMAND ----------

# =============================================================================
# SECTION 5: Comparison with naive pricing
# =============================================================================
#
# Naive model: trained ignoring the LDP structure (using uniform weights).
# If S is used as a feature directly, discrimination leaks through.
# Here we compare against a simple mean-baseline.

h_naive = np.full(len(X_test), y_train.mean())

disc_idx = discrimination_free_indicator(h_star, h_naive)
print(f"Discrimination index (L2 distance h* vs naive): {disc_idx:.2f}")

# Group-conditional means to show h* is not systematically different by group
for cat in cats:
    mask = D_test == cat
    if mask.sum() > 0:
        print(f"  Group {cat!r}: true y_mean=£{y_test[mask].mean():.0f}, "
              f"h*_mean=£{h_star[mask].mean():.0f}")

# COMMAND ----------

# =============================================================================
# SECTION 6: Calibration by noisy group
# =============================================================================

cal = calibration_by_group_ldp(y_test, h_star, S_test, cats)
cal_df = pl.DataFrame({
    "Group (S)": cal["group"],
    "n": cal["n"],
    "Mean Actual (£)": [round(v, 1) for v in cal["mean_actual"]],
    "Mean Predicted (£)": [round(v, 1) for v in cal["mean_predicted"]],
    "Calibration Ratio": [round(v, 4) for v in cal["calibration_ratio"]],
})
print("Calibration by noisy group (imperfect proxy for true group calibration):")
print(cal_df)

# COMMAND ----------

# =============================================================================
# SECTION 7: Phase 2 — Unknown epsilon (anchor-point estimation)
# =============================================================================
#
# Scenario: epsilon was not disclosed by the data provider.
# We have a subset of policyholders known to be in the "White" category
# (e.g. from a third-party demographic register, or verified declarations).
# We estimate pi from the fraction reporting "White" in that subset.

# Simulate anchor: first 200 test observations happen to be known White
anchor_n = 200

anchor_estimator = NoiseRateEstimator(
    categories=cats,
    anchor_category="White",
    anchor_selector=lambda X: np.arange(len(X)) < anchor_n,
    min_anchor_size=30,
)
anchor_estimator.fit(S_test, X=np.arange(len(S_test)), bootstrap=True, n_bootstrap=200, random_state=42)

print(anchor_estimator.summary())

print(f"True epsilon: {EPSILON:.4f}")
print(f"Estimated epsilon: {anchor_estimator.epsilon_:.4f}")
print(f"True pi: {krr.pi:.4f}")
print(f"Estimated pi: {anchor_estimator.pi_:.4f}")
if anchor_estimator.std_error_:
    print(f"Bootstrap SE(pi): {anchor_estimator.std_error_:.4f}")

# Use estimated epsilon for pricing
krr_estimated = anchor_estimator.to_mechanism()
model_phase2 = LDPDiscriminationFreePrice(
    base_estimator=Ridge(alpha=1.0),
    mechanism=krr_estimated,
)
model_phase2.fit(X_train, S_train, y_train)
h_star_phase2 = model_phase2.predict(X_test)

print(f"\nPhase 2 predictions: mean=£{h_star_phase2.mean():.0f}, std=£{h_star_phase2.std():.0f}")
print(f"Phase 1 vs Phase 2 RMSE: {np.sqrt(np.mean((h_star - h_star_phase2)**2)):.2f}")

# COMMAND ----------

# =============================================================================
# SECTION 8: Privacy-accuracy trade-off
# =============================================================================

print("Privacy-accuracy trade-off (k=4 categories):")
print(f"{'epsilon':>8} {'pi':>8} {'C1':>8} {'Bound inflation':>16}")
print("-" * 45)
for eps in [0.5, 1.0, 1.5, 2.0, 3.0, 5.0]:
    pi = pi_from_epsilon(eps, k)
    c1 = accuracy_constant(pi, k)
    inflation = f"{(c1-1)*100:.1f}%"
    print(f"{eps:>8.1f} {pi:>8.4f} {c1:>8.3f} {inflation:>16}")

# COMMAND ----------

# =============================================================================
# SECTION 9: Fairness report
# =============================================================================

report = LDPFairnessReport.from_model(
    model,
    X_test,
    S_test,
    y=y_test,
    h_naive=h_naive,
    notes=(
        "Synthetic UK motor insurance portfolio. "
        "Epsilon=1.5 selected to balance FCA scrutiny and model accuracy. "
        "Full multi-party TTP architecture required for formal privacy guarantee."
    ),
)

print(report.summary())

# COMMAND ----------

# Save report to Databricks FileStore (for download)
report_path = "/tmp/ldp_fairness_report.md"
report.to_markdown(report_path)
print(f"Report saved to: {report_path}")

# Display key metrics
print("\nKey regulatory metrics:")
print(f"  epsilon (privacy budget):     {report.epsilon}")
print(f"  pi (truth probability):       {report.pi:.4f}")
print(f"  C1 (accuracy constant):       {report.accuracy_constant:.4f}")
print(f"  Discrimination index:         {report.discrimination_index:.2f}")
print(f"  Reference distribution P*(D): {dict(zip(report.categories, report.reference_dist.round(4)))}")

# COMMAND ----------

print("Demo complete. insurance-fairness-ldp is working correctly.")
print()
print("Summary:")
print(f"  - Privatised {n} policy records with epsilon={EPSILON}")
print(f"  - Trained {k} group-specific Ridge models with LDP correction")
print(f"  - Generated discrimination-free premiums h*(X)")
print(f"  - Demonstrated anchor-point epsilon estimation")
print(f"  - Generated FCA-ready markdown report")
