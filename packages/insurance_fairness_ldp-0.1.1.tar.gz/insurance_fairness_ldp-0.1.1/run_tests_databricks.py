"""
Run insurance-fairness-ldp tests on Databricks using the REST API.

Usage:
    python run_tests_databricks.py
"""

import os
import sys
import time
import base64
import requests
from pathlib import Path

# Load Databricks credentials
env_path = os.path.expanduser("~/.config/burning-cost/databricks.env")
with open(env_path) as f:
    for line in f:
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            os.environ[k.strip()] = v.strip()

HOST = os.environ["DATABRICKS_HOST"].rstrip("/")
TOKEN = os.environ["DATABRICKS_TOKEN"]
HEADERS = {"Authorization": f"Bearer {TOKEN}", "Content-Type": "application/json"}

WORKSPACE_PATH = "/Workspace/insurance-fairness-ldp"
NOTEBOOK_PATH = f"{WORKSPACE_PATH}/run_tests"
PROJECT_ROOT = Path(__file__).parent


# ---------------------------------------------------------------------------
# Upload utilities
# ---------------------------------------------------------------------------

def mkdirs(path):
    requests.post(f"{HOST}/api/2.0/workspace/mkdirs", headers=HEADERS, json={"path": path})


def upload_file(local_path: Path, remote_path: str):
    content = local_path.read_bytes()
    encoded = base64.b64encode(content).decode()
    mkdirs(str(Path(remote_path).parent))
    resp = requests.post(
        f"{HOST}/api/2.0/workspace/import",
        headers=HEADERS,
        json={"path": remote_path, "content": encoded, "format": "AUTO", "overwrite": True},
    )
    if not resp.ok:
        print(f"  WARNING: Upload failed for {remote_path}: {resp.status_code}")
    else:
        print(f"  Uploaded: {remote_path}")


def upload_directory(local_dir: Path, remote_base: str):
    for f in sorted(local_dir.rglob("*")):
        if f.is_file() and "__pycache__" not in str(f) and ".egg-info" not in str(f):
            relative = f.relative_to(local_dir.parent)
            remote = f"{remote_base}/{relative}"
            upload_file(f, remote)


# ---------------------------------------------------------------------------
# Upload project
# ---------------------------------------------------------------------------

print("Uploading package files...")
mkdirs(WORKSPACE_PATH)
upload_directory(PROJECT_ROOT / "src", WORKSPACE_PATH)
upload_directory(PROJECT_ROOT / "tests", WORKSPACE_PATH)
upload_file(PROJECT_ROOT / "pyproject.toml", f"{WORKSPACE_PATH}/pyproject.toml")


# ---------------------------------------------------------------------------
# Create test notebook
# The notebook result field captures the last value returned by dbutils.notebook.exit()
# We use that to return the test output.
# ---------------------------------------------------------------------------

NOTEBOOK_SOURCE = '''import subprocess, sys

%pip install numpy scipy scikit-learn polars --quiet

import sys
sys.path.insert(0, "/Workspace/insurance-fairness-ldp/src")

result = subprocess.run(
    [sys.executable, "-m", "pytest",
     "/Workspace/insurance-fairness-ldp/tests/",
     "-v", "--tb=short", "--no-header",
     "-p", "no:cacheprovider"],
    capture_output=True,
    text=True,
    cwd="/Workspace/insurance-fairness-ldp",
)

output = result.stdout
if result.stderr:
    output += "\\nSTDERR:\\n" + result.stderr[:2000]

# Return via dbutils so it appears in notebook_output.result
exit_marker = f"RETURNCODE={result.returncode}"
full_result = output + "\\n" + exit_marker

# Truncate to stay within Databricks 1MB limit
if len(full_result) > 900000:
    full_result = full_result[-900000:]

dbutils.notebook.exit(full_result)
'''

encoded_nb = base64.b64encode(NOTEBOOK_SOURCE.encode()).decode()
resp = requests.post(
    f"{HOST}/api/2.0/workspace/import",
    headers=HEADERS,
    json={
        "path": NOTEBOOK_PATH,
        "content": encoded_nb,
        "format": "SOURCE",
        "language": "PYTHON",
        "overwrite": True,
    },
)
if resp.ok:
    print(f"Uploaded test notebook: {NOTEBOOK_PATH}")
else:
    print(f"Notebook upload error: {resp.status_code} {resp.text[:500]}")
    sys.exit(1)


# ---------------------------------------------------------------------------
# Submit job
# ---------------------------------------------------------------------------

payload = {
    "run_name": "insurance-fairness-ldp-tests",
    "tasks": [{
        "task_key": "run_tests",
        "notebook_task": {
            "notebook_path": NOTEBOOK_PATH,
            "source": "WORKSPACE",
        },
    }],
}

print("\nSubmitting test job...")
resp = requests.post(f"{HOST}/api/2.1/jobs/runs/submit", headers=HEADERS, json=payload)
if not resp.ok:
    print(f"Submit error: {resp.status_code} {resp.text[:2000]}")
    sys.exit(1)

run_id = resp.json()["run_id"]
print(f"Run ID: {run_id}")

# Poll for completion
start = time.time()
while True:
    r = requests.get(f"{HOST}/api/2.1/jobs/runs/get", headers=HEADERS, params={"run_id": run_id})
    data = r.json()
    state = data["state"]
    lc = state["life_cycle_state"]
    elapsed = time.time() - start
    print(f"  {lc} ({elapsed:.0f}s)")
    if lc in ("TERMINATED", "INTERNAL_ERROR", "SKIPPED"):
        result_state = state.get("result_state", "")
        tasks = data.get("tasks", [])
        task_run_id = tasks[0]["run_id"] if tasks else None
        break
    if elapsed > 900:
        print("Timed out after 15 minutes")
        sys.exit(1)
    time.sleep(15)

print(f"Final result_state: {result_state}")

# Get output
full_output = ""
if task_run_id:
    r = requests.get(
        f"{HOST}/api/2.1/jobs/runs/get-output",
        headers=HEADERS,
        params={"run_id": task_run_id},
    )
    out = r.json()
    nb_out = out.get("notebook_output", {})
    if nb_out.get("result"):
        full_output = nb_out["result"]
        print("\n=== TEST OUTPUT ===")
        print(full_output)
    if out.get("error"):
        print(f"\nERROR: {out['error'][:1000]}")

# Parse return code from output
if "RETURNCODE=0" in full_output:
    print("\nAll tests passed on Databricks.")
    sys.exit(0)
else:
    print(f"\nTest run FAILED on Databricks.")
    sys.exit(1)
