# ai-agent-proxy

`ai-agent-proxy` is an inbox-backed FastAPI proxy.

Install:

```bash
make install
```

Run:

```bash
ai-agent-proxy --host 0.0.0.0 --workspace /path/to/workspace --api-key your-token
```

Options:

- `--workspace` sets the workspace.
- `--host` sets the HTTP bind address.
- `--ip` is accepted as a compatibility alias for the bind address.
- `--api-key` requires `Authorization: Bearer <api-key>` on API requests.
- `-f, --config` loads `KEY=VALUE` settings from a config file. Default: `./.ai-agent-proxy.conf`.

Runtime model:

- `POST /chat/completions` and `POST /v1/chat/completions` enqueue only the raw JSON request body into the local agent inbox and return immediately.
- `POST /agent-inbox` enqueues the raw JSON body into the local agent inbox and returns an acknowledgement.
- The worker listens to the inbox folder and replies according to the message instructions, using `ai_agent_proxy/skills/` for project guidance.

Config example:

```env
WORKSPACE=/home/li/.openclaw
HOST=0.0.0.0
PORT=7011
API_KEY=your-token
```
