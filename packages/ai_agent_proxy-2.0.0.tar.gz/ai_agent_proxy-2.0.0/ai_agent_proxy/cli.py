import argparse
from dataclasses import dataclass
from pathlib import Path

from ai_agent_proxy import __version__
from ai_agent_proxy.server import DEFAULT_WORKSPACE


@dataclass(frozen=True)
class CliSettings:
    workspace: Path
    host: str
    port: int
    public_url: str | None
    api_key: str | None
    a2a_key: str | None


def load_config_file(path: Path) -> dict[str, str]:
    config: dict[str, str] = {}
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip().upper()
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
            value = value[1:-1]
        config[key] = value
    return config


def build_parser() -> argparse.ArgumentParser:
    default_config = Path("./.ai-agent-proxy.conf")
    parser = argparse.ArgumentParser(
        prog="ai-agent-proxy",
        description=f"ai-agent-proxy {__version__}",
    )
    parser.add_argument(
        "-f",
        "--config",
        type=Path,
        default=default_config,
        help=f"Load KEY=VALUE settings from a config file (default: {default_config})",
    )
    parser.add_argument("--workspace", type=Path, default=None)
    parser.add_argument("--host", default=None, help="HTTP bind host")
    parser.add_argument("--ip", default=None, help="Compatibility alias for the HTTP bind host")
    parser.add_argument("--port", type=int, default=None)
    parser.add_argument("--public-url", default=None, help="Public base URL other agents can use to call this proxy")
    parser.add_argument("--api-key", default=None, help="Require Authorization: Bearer <api-key> on API requests")
    parser.add_argument("--a2a-key", default=None, help="Require matching a2a_key on /agent-inbox requests")
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    return parser


def parse_settings() -> CliSettings:
    parser = build_parser()
    args = parser.parse_args()

    config: dict[str, str] = {}
    if args.config is not None:
        config_path = args.config.expanduser()
        if config_path.exists():
            config = load_config_file(config_path)

    workspace = (
        args.workspace
        or Path(config.get("WORKSPACE") or config.get("WORKDIR") or DEFAULT_WORKSPACE)
    ).expanduser()
    host = args.host or config.get("HOST") or args.ip or config.get("IP") or "0.0.0.0"
    port = args.port if args.port is not None else int(config.get("PORT", 7011))
    public_url = args.public_url if args.public_url is not None else config.get("PUBLIC_URL")
    api_key = args.api_key if args.api_key is not None else config.get("API_KEY")
    a2a_key = args.a2a_key if args.a2a_key is not None else config.get("A2A_KEY")

    return CliSettings(
        workspace=workspace,
        host=host,
        port=port,
        public_url=public_url,
        api_key=api_key,
        a2a_key=a2a_key,
    )


__all__ = ["CliSettings", "build_parser", "load_config_file", "parse_settings"]
