from ai_agent_proxy.cli import CliSettings, parse_settings
from ai_agent_proxy.agentwork import AgentWorker
from ai_agent_proxy.server import (
    Proxy,
    apply_runtime_config,
    configure_logging,
    prepare_workspace,
    print_env,
)


def validate_settings(settings: CliSettings) -> None:
    if settings.port <= 0 or settings.port > 65535:
        raise SystemExit(f"invalid port: {settings.port}")


def prepare_runtime(settings: CliSettings) -> AgentWorker:
    validate_settings(settings)
    apply_runtime_config(
        workspace=settings.workspace,
        api_key=settings.api_key,
        a2a_key=settings.a2a_key,
    )
    configure_logging()
    prepare_workspace()
    agent = AgentWorker()
    agent.init(workspace=settings.workspace)
    return agent


def main() -> None:
    settings = parse_settings()
    agent = prepare_runtime(settings)
    proxy = Proxy(
        host=settings.host,
        port=settings.port,
        api_key=settings.api_key,
        a2a_key=settings.a2a_key,
        worker=agent,
    )
    print_env(proxy)
    proxy.run()

__all__ = ["main", "prepare_runtime", "validate_settings"]


if __name__ == "__main__":
    main()
