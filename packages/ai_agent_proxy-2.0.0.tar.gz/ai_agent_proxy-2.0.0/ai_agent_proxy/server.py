from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import shutil
import subprocess
import sys
import time
import uuid
from pathlib import Path
from typing import Literal

import uvicorn
from fastapi import FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from pydantic import BaseModel, ConfigDict, Field
from starlette.responses import JSONResponse, StreamingResponse

from ai_agent_proxy.agentwork import AgentWorker

LOGGER = logging.getLogger("ai_agent_proxy.server")

MODEL_ID = "manager"
MODEL_CREATED = int(time.time())
DEFAULT_WORKSPACE = Path.home() / ".openclaw" / "workspace"
PACKAGE_DIR = Path(__file__).resolve().parent
WORKSPACE = Path(os.environ.get("AI_AGENT_PROXY_WORKSPACE", str(DEFAULT_WORKSPACE))).expanduser()


class Proxy:
    def __init__(
        self,
        *,
        host: str,
        port: int,
        api_key: str | None,
        a2a_key: str | None,
        worker: AgentWorker,
    ) -> None:
        self.host = host
        self.port = port
        self.api_key = api_key
        self.a2a_key = a2a_key
        self.worker = worker
        self.app = FastAPI(title="ai-agent-proxy")
        self._register_routes()

    def init(self) -> None:
        configure_logging()
        prepare_workspace()

    def run(self) -> None:
        self.init()
        uvicorn.run(self.app, host=self.host, port=self.port)

    def worker_inbox_dir(self) -> Path:
        return self.worker.inbox()

    def is_authorized(self, request: Request) -> bool:
        if not self.api_key:
            return True
        authorization = request.headers.get("authorization", "")
        return authorization == f"Bearer {self.api_key}"

    def is_a2a_authorized(self, request: AgentInboxRequest) -> bool:
        if not self.a2a_key:
            return True
        return request.a2a_key == self.a2a_key

    def trigger_agent_worker(self) -> None:
        LOGGER.info("trigger_agent_worker workspace=%s", WORKSPACE)
        subprocess.Popen(
            [
                sys.executable,
                "-m",
                "ai_agent_proxy.agentwork",
                "work",
                "--workspace",
                str(WORKSPACE),
                "--waiting-seconds",
                str(self.worker.waiting_seconds),
            ],
            cwd=str(WORKSPACE),
        )

    async def enqueue_mailbox_request(
        self,
        *,
        endpoint: str,
        payload: object,
        channel_id: str | None = None,
    ) -> str:
        request_id = uuid.uuid4().hex
        inbox_root = self.worker_inbox_dir()
        LOGGER.info(
            "mailbox_request enqueue endpoint=%s channel_id=%s inbox_root=%s",
            endpoint,
            channel_id or "",
            inbox_root,
        )
        await asyncio.to_thread(
            write_inbox_request,
            request_id,
            endpoint=endpoint,
            payload=payload,
            channel_id=channel_id,
            receiver_inbox_path=inbox_root,
        )
        await asyncio.to_thread(self.trigger_agent_worker)
        return request_id

    def _register_routes(self) -> None:
        @self.app.exception_handler(HTTPException)
        async def http_exception_handler(request: Request, exc: HTTPException):
            return unauthorized_response()

        @self.app.exception_handler(RequestValidationError)
        async def request_validation_exception_handler(request: Request, exc: RequestValidationError):
            LOGGER.warning(
                "validation_error path=%s errors=%s",
                request.url.path,
                exc.errors(),
            )
            return unauthorized_response()

        @self.app.exception_handler(Exception)
        async def unhandled_exception_handler(request: Request, exc: Exception):
            return unauthorized_response()

        @self.app.middleware("http")
        async def require_api_key(request: Request, call_next):
            client_host = request.client.host if request.client else "-"
            LOGGER.info("request method=%s path=%s client=%s", request.method, request.url.path, client_host)
            if not self.is_authorized(request):
                LOGGER.info("response method=%s path=%s status=%s", request.method, request.url.path, 401)
                return unauthorized_response()
            response = await call_next(request)
            LOGGER.info("response method=%s path=%s status=%s", request.method, request.url.path, response.status_code)
            return response

        @self.app.api_route("/", methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "HEAD"])
        async def root_fallback():
            return unauthorized_response()

        @self.app.get("/v1/models", response_model=ModelListResponse)
        async def list_models():
            return ModelListResponse(object="list", data=[model_payload()])

        @self.app.get("/v1/models/{model_id}", response_model=ModelResponse)
        async def get_model(model_id: str):
            return model_payload(model_id)

        @self.app.post("/chat/completions")
        @self.app.post("/v1/chat/completions")
        async def create_chat_completion(request: Request):
            try:
                payload = await request.json()
            except Exception:
                LOGGER.warning("chat_completion invalid_json path=%s", request.url.path)
                return error_response("invalid json body", "invalid_request_error", 400)

            model = payload.get("model", MODEL_ID) if isinstance(payload, dict) else MODEL_ID
            stream = bool(payload.get("stream", False)) if isinstance(payload, dict) else False
            LOGGER.info("chat_completion begin model=%s stream=%s", model, stream)
            await self.enqueue_mailbox_request(
                endpoint=request.url.path,
                payload=payload,
            )
            response = empty_chat_completion_response(model if isinstance(model, str) else MODEL_ID)
            LOGGER.info("chat_completion end enqueued_only=true")
            if stream:
                return sse_chat_completion_response(response)
            payload = response.model_dump()
            LOGGER.info("chat_completion response mode=json")
            return JSONResponse(status_code=200, content=payload)

        @self.app.post("/agent-inbox", response_model=AgentInboxResponse)
        async def agent_inbox(req: AgentInboxRequest):
            LOGGER.info("agent_inbox begin agent_id=%s reply_instruction=%s", req.agent_id, req.reply_instruction or "")
            if not self.is_a2a_authorized(req):
                return unauthorized_response()
            await self.enqueue_mailbox_request(
                endpoint="/agent-inbox",
                payload=req.model_dump(mode="json"),
                channel_id=req.agent_id,
            )
            payload = AgentInboxResponse(
                status="ok",
                agent_id=req.agent_id,
                reply_instruction=req.reply_instruction,
                system_instruction=req.system_instruction,
                reply="",
            ).model_dump()
            LOGGER.info("agent_inbox end agent_id=%s reply_instruction=%s", req.agent_id, req.reply_instruction or "")
            return JSONResponse(status_code=200, content=payload)

        @self.app.api_route("/{path:path}", methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "HEAD"])
        async def path_fallback(path: str):
            return unauthorized_response()


class TextContentPart(BaseModel):
    model_config = ConfigDict(extra="forbid")

    type: Literal["text"]
    text: str


class ChatMessage(BaseModel):
    model_config = ConfigDict(extra="forbid")

    role: Literal["system", "user", "assistant"]
    content: str | list[TextContentPart]


class ChatCompletionRequest(BaseModel):
    model_config = ConfigDict(extra="allow")

    conversation_id: str | None = None
    model: str = MODEL_ID
    messages: list[ChatMessage] = Field(default_factory=list)
    temperature: float | None = None
    max_tokens: int | None = None
    max_completion_tokens: int | None = None
    stream: bool = False
    store: bool | None = None
    user: str | None = None
    user_id: str | None = None
    tools: list[dict] = Field(default_factory=list)
    tool_choice: str | dict | None = None
    parallel_tool_calls: bool | None = None
    metadata: dict | None = None
    response_format: dict | None = None


class ModelResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: str
    object: Literal["model"]
    created: int
    owned_by: str


class ModelListResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    object: Literal["list"]
    data: list[ModelResponse]


class AssistantMessage(BaseModel):
    model_config = ConfigDict(extra="forbid")

    role: Literal["assistant"]
    content: str


class ChatChoice(BaseModel):
    model_config = ConfigDict(extra="forbid")

    index: int
    message: AssistantMessage
    finish_reason: Literal["stop"]


class Usage(BaseModel):
    model_config = ConfigDict(extra="forbid")

    prompt_tokens: int
    completion_tokens: int
    total_tokens: int


class ChatCompletionResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: str
    object: Literal["chat.completion"]
    created: int
    model: str
    choices: list[ChatChoice]
    usage: Usage


class ErrorBody(BaseModel):
    model_config = ConfigDict(extra="forbid")

    status: Literal["error"]
    error: dict[str, str | int]


class AgentInboxRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    agent_id: str
    reply_instruction: str | None = None
    system_instruction: str | None = None
    prompt: str | None = None
    a2a_key: str


class AgentInboxResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    status: Literal["ok"]
    agent_id: str
    reply_instruction: str | None = None
    system_instruction: str | None = None
    reply: str


def error_response(message: str, error_type: str, status_code: int) -> JSONResponse:
    return JSONResponse(
        status_code=status_code,
        content=ErrorBody(
            status="error",
            error={"message": message, "type": error_type, "code": status_code},
        ).model_dump(),
    )


def unauthorized_response() -> JSONResponse:
    return error_response("unauthorized", "authentication_error", 401)


def empty_chat_completion_response(model: str = MODEL_ID) -> ChatCompletionResponse:
    return ChatCompletionResponse(
        id=f"chatcmpl-{uuid.uuid4().hex}",
        object="chat.completion",
        created=unix_now(),
        model=model,
        choices=[
            ChatChoice(
                index=0,
                message=AssistantMessage(role="assistant", content=""),
                finish_reason="stop",
            )
        ],
        usage=Usage(
            prompt_tokens=0,
            completion_tokens=0,
            total_tokens=0,
        ),
    )


def mailbox_dir() -> Path:
    return WORKSPACE / ".mailbox"


def inbox_dir() -> Path:
    return mailbox_dir() / "inbox"


def scratch_dir() -> Path:
    return mailbox_dir() / "scratch"


def unix_now() -> int:
    return int(time.time())


def model_payload(model_id: str = MODEL_ID) -> ModelResponse:
    return ModelResponse(
        id=model_id,
        object="model",
        created=MODEL_CREATED,
        owned_by="openclaw",
    )


def flatten_message_content(content: str | list[TextContentPart]) -> str:
    if isinstance(content, str):
        return content
    return "\n".join(part.text for part in content if part.text)


def extract_inbound_context(messages: list[ChatMessage]) -> dict[str, object]:
    for message in messages:
        if message.role != "system":
            continue
        content = flatten_message_content(message.content)
        match = re.search(
            r"## Inbound Context \(trusted metadata\).*?```json\s*(\{.*?\})\s*```",
            content,
            flags=re.DOTALL,
        )
        if not match:
            continue
        try:
            return json.loads(match.group(1))
        except json.JSONDecodeError:
            return {}
    return {}


def json_dumps(value: object) -> str:
    return json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True)


def chat_completion_chunk(response: ChatCompletionResponse) -> dict[str, object]:
    content = response.choices[0].message.content
    return {
        "id": response.id,
        "object": "chat.completion.chunk",
        "created": response.created,
        "model": response.model,
        "choices": [
            {
                "index": 0,
                "delta": {"role": "assistant", "content": content},
                "finish_reason": "stop",
            }
        ],
    }


def sse_chat_completion_response(response: ChatCompletionResponse) -> StreamingResponse:
    chunk = chat_completion_chunk(response)
    LOGGER.info("chat_completion response mode=sse")

    async def event_stream():
        yield f"data: {json.dumps(chunk, ensure_ascii=False)}\n\n"
        yield "data: [DONE]\n\n"

    return StreamingResponse(event_stream(), media_type="text/event-stream")


def ensure_mailbox() -> None:
    mailbox_root = mailbox_dir()
    inbox_root = inbox_dir()
    scratch_root = scratch_dir()
    mailbox_root.mkdir(parents=True, exist_ok=True)
    inbox_root.mkdir(parents=True, exist_ok=True)
    scratch_root.mkdir(parents=True, exist_ok=True)


def install_packaged_skills() -> Path:
    source_dir = PACKAGE_DIR / "skills"
    target_dir = mailbox_dir() / "skill"
    target_dir.mkdir(parents=True, exist_ok=True)
    shutil.copytree(source_dir, target_dir, dirs_exist_ok=True)
    return target_dir


def prepare_workspace() -> None:
    WORKSPACE.mkdir(parents=True, exist_ok=True)
    os.chdir(WORKSPACE)
    ensure_mailbox()
    install_packaged_skills()


def configure_logging() -> None:
    if LOGGER.handlers:
        return
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s"))
    LOGGER.addHandler(handler)
    LOGGER.setLevel(logging.INFO)
    LOGGER.propagate = False


def apply_runtime_config(*, workspace: Path, api_key: str | None, a2a_key: str | None) -> None:
    global WORKSPACE

    WORKSPACE = workspace.expanduser()

    os.environ["AI_AGENT_PROXY_WORKSPACE"] = str(WORKSPACE)
    if api_key:
        os.environ["AI_AGENT_PROXY_API_KEY"] = api_key
    else:
        os.environ.pop("AI_AGENT_PROXY_API_KEY", None)
    if a2a_key:
        os.environ["AI_AGENT_PROXY_A2A_KEY"] = a2a_key
    else:
        os.environ.pop("AI_AGENT_PROXY_A2A_KEY", None)


def print_env(proxy: Proxy) -> None:
    print(f"WORKSPACE: {WORKSPACE}", flush=True)
    print(f"CWD: {Path.cwd()}", flush=True)
    print(f"MAILBOX_DIR: {mailbox_dir()}", flush=True)
    print(f"INBOX_DIR: {inbox_dir()}", flush=True)
    print(f"AGENT_INBOX_DIR: {proxy.worker_inbox_dir()}", flush=True)
    print(f"SCRATCH_DIR: {scratch_dir()}", flush=True)
    print(f"SKILL_DIR: {mailbox_dir() / 'skill'}", flush=True)
    print(f"API_KEY_AUTH: {'enabled' if proxy.api_key else 'disabled'}", flush=True)
    print(f"A2A_KEY_AUTH: {'enabled' if proxy.a2a_key else 'disabled'}", flush=True)


def write_inbox_request(
    request_id: str,
    *,
    endpoint: str,
    payload: object,
    channel_id: str | None = None,
    receiver_inbox_path: Path | None = None,
) -> Path:
    ensure_mailbox()
    inbox_root = receiver_inbox_path or inbox_dir()
    inbox_root.mkdir(parents=True, exist_ok=True)
    inbox_path = inbox_root / request_id
    tmp_path = scratch_dir() / f"{request_id}.json.tmp"
    LOGGER.info(
        "mailbox_request write request_id=%s endpoint=%s channel_id=%s path=%s",
        request_id,
        endpoint,
        channel_id or "",
        inbox_path,
    )
    tmp_path.write_text(json_dumps(payload) + "\n", encoding="utf-8")
    shutil.copyfile(tmp_path, inbox_path)
    tmp_path.unlink(missing_ok=True)
    LOGGER.info("mailbox_request put request_id=%s into inbox_path=%s", request_id, inbox_path)
    return inbox_path
