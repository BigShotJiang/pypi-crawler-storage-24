---
name: openclaw-message-cli-skill
description: Use when the user explicitly wants to send outbound messages with the OpenClaw CLI rather than built-in tools, especially for `openclaw message send` commands with a specific channel, target, and message body.
---

# OpenClaw Message CLI Skill

Use this skill when the task is specifically about sending a message with the OpenClaw CLI.

When you are replying to an inbox JSON message:

- get `channel` from the JSON body
- the `channel` value should be things like `whatsapp`, `discord`, and similar transport names
- get `target` from the JSON body
- the `target` value is the user identifier on that channel, such as the user's phone number or account id

Prefer the built-in messaging tool when available. Use this skill only when the user explicitly asks for CLI usage, shell commands, scripting, or automation around `openclaw message send`.

## Command Pattern

Use:

```bash
openclaw message send --channel <channel> --target <target> --message "..."
```

## Examples

```bash
openclaw message send --channel whatsapp --target 6580000000 --message "hi"
openclaw message send --channel discord --target 123456789012345678 --message "hi"
```

## Checks

- read `channel` and `target` from the JSON body before sending
- verify the requested channel exists before sending
- verify the target format matches the selected channel
- quote message text safely, especially when it contains shell-sensitive characters

## Scope

Use this skill for direct outbound client delivery with the OpenClaw CLI.
When the ai-agent-proxy worker decides a reply should be sent outward to the user, use this skill for that delivery step.
