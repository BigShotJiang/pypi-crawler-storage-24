# Context Cache Example

Use `=======` to separate content blocks.

```text
BLOCK_ID: 001
Project: ai-agent-proxy
Topic: mailbox routing
Summary: The proxy writes mailbox requests into .mailbox/inbox and reads replies from .mailbox/proxy.

=======
BLOCK_ID: 002
Project: ai-agent-proxy
Topic: channel handling update
Summary: Update to BLOCK_ID: 001 on mailbox routing. Requests in the same chat should preserve a stable CHANNEL_ID such as whatsapp:+6580961337.

=======
BLOCK_ID: 003
Project: ai-agent-proxy
Topic: worker behavior
Summary: Refers to BLOCK_ID: 002 about channel handling. The worker may read multiple pending inbox items for context, but it should reply one message at a time.

=======
BLOCK_ID: 004
Summary: Correction to BLOCK_ID: 003. The worker should keep existing BLOCK_ID values stable in cached context files and append corrective blocks instead of renumbering earlier ones.

=======
BLOCK_ID: 005
Session: 2026-03-20-debug
Summary: Update to BLOCK_ID: 001 and BLOCK_ID: 002. This block uses session-based grouping instead of project/topic metadata because the context is tied to one debugging session.
```
