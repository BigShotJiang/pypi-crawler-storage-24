"""dfcode-remote: Feishu bridge for dfcode."""

__version__ = "0.2.0"
