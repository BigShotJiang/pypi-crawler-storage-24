"""Entry point for the dfcode Feishu bridge.

Usage:
    dfcode-remote
    dfcode-remote --dfcode-url http://host:4096
    python -m dfcode_remote
"""

import argparse
import asyncio
import logging
import signal
import sys

from dfcode_remote.dfcode_client.client import DfcodeClient
from dfcode_remote.lark_client.bot import start_bot_async
from dfcode_remote.lark_client.card_service import CardService
from dfcode_remote.lark_client.event_listener import EventListener
from dfcode_remote.lark_client.handler import Handler
from dfcode_remote.utils.config import Config
from dfcode_remote.utils.persistence import Persistence

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="dfcode Feishu bridge")
    parser.add_argument(
        "--dfcode-url", default=None, help="Override DFCODE_URL from env"
    )
    parser.add_argument("--debug", action="store_true", help="Enable debug logging")
    return parser.parse_args()


async def _run(config: Config) -> None:
    client = DfcodeClient(
        base_url=config.dfcode_url,
        directory=config.dfcode_directory,
        username=config.dfcode_username or None,
        password=config.dfcode_password or None,
    )
    card_service = CardService(config.feishu_app_id, config.feishu_app_secret)
    persistence = Persistence()
    handler = Handler(config, client, card_service, persistence)
    listener = EventListener(
        dfcode_url=config.dfcode_url,
        client=client,
        card_service=card_service,
        persistence=persistence,
        handler=handler,
        enable_urgent=config.enable_urgent,
    )

    logger.info("dfcode URL: %s", config.dfcode_url)
    logger.info("Feishu app_id: %s", config.feishu_app_id)

    async def sse_task() -> None:
        await listener.run()

    async def bot_task() -> None:
        await start_bot_async(
            config.feishu_app_id,
            config.feishu_app_secret,
            handler.handle_message,
            handler.handle_card_action,
        )

    loop = asyncio.get_running_loop()

    def _shutdown(sig: signal.Signals) -> None:
        logger.info("Received %s — shutting down", sig.name)
        for task in asyncio.all_tasks(loop):
            task.cancel()

    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, lambda s=sig: _shutdown(s))

    try:
        await asyncio.gather(sse_task(), bot_task())
    except asyncio.CancelledError:
        logger.info("Shutdown complete")
    finally:
        await client.close()
        await card_service.close()


def main() -> None:
    args = _parse_args()

    if args.debug:
        logging.getLogger().setLevel(logging.DEBUG)

    config = Config.load()

    if args.dfcode_url:
        config.dfcode_url = args.dfcode_url

    if not config.feishu_app_id or not config.feishu_app_secret:
        logger.error("FEISHU_APP_ID and FEISHU_APP_SECRET must be set")
        sys.exit(1)

    asyncio.run(_run(config))
