"""Command routing and card action handling for Feishu messages."""

import asyncio
import json
import logging
import time
from typing import Optional

from lark_oapi.api.im.v1.model.p2_im_message_receive_v1 import P2ImMessageReceiveV1
from lark_oapi.event.callback.model.p2_card_action_trigger import P2CardActionTrigger

from dfcode_remote.dfcode_client.client import DfcodeClient, DfcodeAPIError
from dfcode_remote.lark_client.card_builder import (
    build_command_response_card,
    build_menu_card,
    ACTION_TYPE_PERMISSION,
    ACTION_TYPE_QUESTION,
    ACTION_TYPE_ABORT,
)
from dfcode_remote.lark_client.card_service import CardService, CardServiceError
from dfcode_remote.utils.config import Config
from dfcode_remote.utils.persistence import Persistence

logger = logging.getLogger(__name__)


def _extract_text(event: P2ImMessageReceiveV1) -> str:
    """Extract plain text from a message receive event."""
    try:
        envelope = getattr(event, "event", None)
        msg = getattr(envelope, "message", None)
        raw = getattr(msg, "content", None)
        if not isinstance(raw, str):
            return ""
        content = json.loads(raw)
        return content.get("text", "").strip()
    except Exception:
        return ""


def _extract_chat_id(event: P2ImMessageReceiveV1) -> str:
    try:
        envelope = getattr(event, "event", None)
        msg = getattr(envelope, "message", None)
        chat_id = getattr(msg, "chat_id", "")
        return chat_id or ""
    except Exception:
        return ""


def _extract_sender_id(event: P2ImMessageReceiveV1) -> str:
    try:
        envelope = getattr(event, "event", None)
        sender = getattr(envelope, "sender", None)
        sender_id = getattr(sender, "sender_id", None)
        open_id = getattr(sender_id, "open_id", "")
        return open_id or ""
    except Exception:
        return ""


def _extract_message_id(event: P2ImMessageReceiveV1) -> str:
    try:
        envelope = getattr(event, "event", None)
        msg = getattr(envelope, "message", None)
        message_id = getattr(msg, "message_id", "")
        return message_id or ""
    except Exception:
        return ""


class Handler:
    """Routes Feishu messages and card actions to dfcode API calls."""

    def __init__(
        self,
        config: Config,
        client: DfcodeClient,
        card_service: CardService,
        persistence: Persistence,
    ):
        self._config = config
        self._client = client
        self._card_service = card_service
        self._persistence = persistence
        self._pending_replies: dict[str, dict] = {}
        self._list_cache: dict[str, list[str]] = {}
        self._seen_messages: dict[str, float] = {}

    def _clear_pending(self, chat_id: str, session_id: Optional[str] = None) -> None:
        stale = []
        for sid, pending in self._pending_replies.items():
            if pending.get("chat_id") != chat_id:
                continue
            if session_id and sid != session_id:
                continue
            stale.append(sid)
        for sid in stale:
            self._pending_replies.pop(sid, None)

    def _allowed(self, open_id: str) -> bool:
        if not self._config.allowed_users:
            return True
        return open_id in self._config.allowed_users

    async def _sessions(self) -> list:
        return await self._client.list_active_sessions()

    async def handle_message(self, event: P2ImMessageReceiveV1) -> None:
        chat_id = _extract_chat_id(event)
        sender = _extract_sender_id(event)
        text = _extract_text(event)
        message_id = _extract_message_id(event)

        if not chat_id or not text:
            return

        now = time.time()
        self._seen_messages = {
            k: v for k, v in self._seen_messages.items() if now - v < 300
        }
        if message_id and message_id in self._seen_messages:
            logger.info("Skip duplicate Feishu message %s in %s", message_id, chat_id)
            return
        if message_id:
            self._seen_messages[message_id] = now

        if not self._allowed(sender):
            logger.warning("Blocked message from %s (not in allowed_users)", sender)
            return

        logger.info(
            "Message from %s in %s id=%s: %r",
            sender,
            chat_id,
            message_id or "-",
            text[:80],
        )

        if text.startswith("/"):
            await self._handle_command(chat_id, text)
        else:
            await self._handle_prompt(chat_id, text)

    async def _handle_command(self, chat_id: str, text: str) -> None:
        parts = text.split(None, 1)
        cmd = parts[0].lower()
        arg = parts[1].strip() if len(parts) > 1 else ""

        if cmd == "/menu":
            await self._send_card(chat_id, build_menu_card())
        elif cmd == "/list":
            await self._cmd_list(chat_id)
        elif cmd == "/new":
            await self._cmd_new(chat_id, arg)
        elif cmd == "/attach":
            await self._cmd_attach(chat_id, arg)
        elif cmd == "/detach":
            await self._cmd_detach(chat_id)
        elif cmd == "/status":
            await self._cmd_status(chat_id)
        elif cmd == "/kill":
            await self._cmd_kill(chat_id, arg)
        else:
            await self._card_service.send_text(
                chat_id, f"未知命令: {cmd}，发送 /menu 查看帮助"
            )

    async def _handle_prompt(self, chat_id: str, text: str) -> None:
        session_id = self._persistence.get_binding(chat_id)
        if not session_id:
            await self._card_service.send_text(
                chat_id, "当前未绑定会话，请先发送 /new 或 /attach <session_id>"
            )
            return

        # Check if session is busy before sending
        try:
            active = await self._client.get_active_session(session_id)
            if active.status.type != "idle":
                await self._card_service.send_text(
                    chat_id, "⏳ 会话正在处理中，请等待完成或回答待处理的问题"
                )
                return
            project_root = active.projectRoot or active.directory

            # Record last message id before sending prompt
            try:
                messages_before = await self._client.get_messages(session_id)
                last_id = messages_before[-1].id if messages_before else ""
            except Exception:
                last_id = ""

            if project_root:
                logger.info(
                    "Prompt route=session endpoint=/session/%s/prompt_async directory=%s chat=%s text_len=%d",
                    session_id,
                    project_root,
                    chat_id,
                    len(text),
                )
                await self._client.prompt_async_in_project(
                    session_id, text, project_root
                )
            else:
                logger.info(
                    "Prompt route=active endpoint=/session/active/%s/prompt_async chat=%s text_len=%d",
                    session_id,
                    chat_id,
                    len(text),
                )
                await self._client.prompt_active_async(session_id, text)
            logger.info("Sent prompt to session %s", session_id)

            # Register pending reply — event_listener will handle the rest
            self._pending_replies[session_id] = {
                "chat_id": chat_id,
                "last_id": last_id,
            }

        except DfcodeAPIError as exc:
            logger.error("prompt_async failed: %s", exc)
            await self._card_service.send_text(chat_id, f"发送失败: {exc}")

    async def _cmd_list(self, chat_id: str) -> None:
        try:
            sessions = await self._sessions()
        except DfcodeAPIError as exc:
            await self._card_service.send_text(chat_id, f"获取会话列表失败: {exc}")
            return

        if not sessions:
            await self._card_service.send_text(chat_id, "暂无活跃会话")
            return

        self._list_cache[chat_id] = [s.id for s in sessions]

        lines = ["**活跃会话列表**", ""]
        for idx, s in enumerate(sessions, start=1):
            lines.append(f"{idx}. {s.title or '(无标题)'}")
            lines.append(f"   id: `{s.id}`")
            lines.append(f"   project: {s.projectRoot or s.directory or '/'}")
            if s.directory and s.directory != s.projectRoot:
                lines.append(f"   dir: {s.directory}")
            lines.append(f"   status: {s.status.type}")
            if s.activity.get("summary"):
                lines.append(f"   activity: {s.activity['summary']}")
            lines.append("")

        await self._send_card(
            chat_id, build_command_response_card("会话列表", "\n".join(lines))
        )

    async def _cmd_new(self, chat_id: str, title: str) -> None:
        try:
            session = await self._client.create_session(title or None)
        except DfcodeAPIError as exc:
            await self._card_service.send_text(chat_id, f"创建会话失败: {exc}")
            return
        self._clear_pending(chat_id)
        self._persistence.set_binding(chat_id, session.id)
        await self._card_service.send_text(
            chat_id,
            f"✅ 已创建并绑定会话\nid: `{session.id}`\ntitle: {session.title or '(无标题)'}\ndir: {session.directory or '/'}",
        )
        logger.info("Created session %s for chat %s", session.id, chat_id)

    async def _cmd_attach(self, chat_id: str, session_id: str) -> None:
        if not session_id:
            await self._card_service.send_text(
                chat_id, "用法: /attach <序号|session_id>"
            )
            return

        try:
            if session_id.isdigit():
                ids = self._list_cache.get(chat_id, [])
                if not ids:
                    sessions = await self._sessions()
                    ids = [s.id for s in sessions]
                else:
                    sessions = None
                idx = int(session_id) - 1
                if idx < 0 or idx >= len(ids):
                    await self._card_service.send_text(
                        chat_id, f"无效序号: {session_id}"
                    )
                    return
                session = (
                    sessions[idx]
                    if sessions
                    else await self._client.get_active_session(ids[idx])
                )
            else:
                session = await self._client.get_active_session(session_id)
        except DfcodeAPIError as exc:
            await self._card_service.send_text(
                chat_id, f"找不到会话 {session_id}: {exc}"
            )
            return
        self._clear_pending(chat_id)
        self._persistence.set_binding(chat_id, session.id)
        await self._card_service.send_text(
            chat_id,
            f"✅ 已绑定会话\nid: `{session.id}`\ntitle: {session.title or '(无标题)'}\ndir: {session.directory or '/'}",
        )

    async def _cmd_detach(self, chat_id: str) -> None:
        self._clear_pending(chat_id)
        self._persistence.remove_binding(chat_id)
        await self._card_service.send_text(chat_id, "✅ 已解绑当前会话")

    async def _cmd_status(self, chat_id: str) -> None:
        session_id = self._persistence.get_binding(chat_id)
        if not session_id:
            await self._card_service.send_text(chat_id, "当前未绑定会话")
            return
        try:
            sessions = await self._sessions()
            item = next((s for s in sessions if s.id == session_id), None)
            if item:
                await self._card_service.send_text(
                    chat_id,
                    "\n".join(
                        [
                            f"id: `{item.id}`",
                            f"title: {item.title or '(无标题)'}",
                            f"project: {item.projectRoot or item.directory or '/'}",
                            *(
                                [f"dir: {item.directory}"]
                                if item.directory and item.directory != item.projectRoot
                                else []
                            ),
                            f"status: **{item.status.type}**",
                            f"activity: {item.activity.get('summary', 'unknown')}",
                        ]
                    ),
                )
                return
            await self._card_service.send_text(
                chat_id, f"会话 `{session_id}` 当前不在活跃列表中"
            )
        except DfcodeAPIError as exc:
            await self._card_service.send_text(chat_id, f"获取状态失败: {exc}")

    async def _cmd_kill(self, chat_id: str, session_id: str) -> None:
        target = session_id or self._persistence.get_binding(chat_id)
        if not target:
            await self._card_service.send_text(
                chat_id, "当前未绑定会话，请指定 session_id"
            )
            return
        try:
            await self._client.abort(target)
            await self._client.delete_session(target)
        except DfcodeAPIError as exc:
            logger.warning("kill session %s: %s", target, exc)
        self._clear_pending(chat_id, target)
        if self._persistence.get_binding(chat_id) == target:
            self._persistence.remove_binding(chat_id)
        await self._card_service.send_text(chat_id, f"✅ 已终止会话 `{target[:8]}`")

    async def _send_card(self, chat_id: str, content: dict) -> Optional[str]:
        try:
            # Skip CardKit, send card content directly
            return await self._card_service.send_card_direct(chat_id, content)
        except CardServiceError as exc:
            logger.error("send_card failed: %s", exc)
            return None

    # --- Card action callbacks ---

    async def handle_card_action(self, event: P2CardActionTrigger) -> None:
        try:
            envelope = getattr(event, "event", None)
            action = getattr(envelope, "action", None)
            value = getattr(action, "value", None) or {}
            logger.info("Parsed card action value: %r", value)
        except Exception:
            logger.warning("Could not parse card action value")
            return

        # Handle form submissions (multi-select or custom text input)
        form_value = getattr(action, "form_value", None)
        if form_value is not None:
            logger.info("Form submission: %r, button value: %r", form_value, value)
            action_type = value.get("type")
            if action_type == ACTION_TYPE_QUESTION:
                req_id = value.get("id", "")
                if not req_id:
                    return
                # Collect selected options + custom input together
                selected = form_value.get("selected_options") or []
                if not isinstance(selected, list):
                    selected = []
                custom_answer = (form_value.get("custom_answer") or "").strip()
                if custom_answer:
                    selected.append(custom_answer)
                if selected:
                    try:
                        await self._client.reply_question(req_id, [selected])
                        logger.info("Replied to question %s with %r", req_id, selected)
                    except DfcodeAPIError as exc:
                        logger.error("reply_question (form) failed: %s", exc)
            return

        action_type = value.get("type")
        logger.info("Card action: %s", action_type)

        if action_type == ACTION_TYPE_PERMISSION:
            await self._handle_permission_action(value)
        elif action_type == ACTION_TYPE_QUESTION:
            await self._handle_question_action(value)
        elif action_type == ACTION_TYPE_ABORT:
            await self._handle_abort_action(value)
        else:
            logger.warning("Unknown card action type: %s", action_type)

    async def _handle_permission_action(self, value: dict) -> None:
        req_id = value.get("id", "")
        reply = value.get("reply", "once")
        if not req_id:
            return
        try:
            await self._client.reply_permission(req_id, reply)
            logger.info("Replied to permission %s with %s", req_id, reply)
        except DfcodeAPIError as exc:
            logger.error("reply_permission failed: %s", exc)

    async def _handle_question_action(self, value: dict) -> None:
        req_id = value.get("id", "")
        answer = value.get("answer", "")
        if not req_id:
            return
        try:
            # dfcode expects answers as list[list[str]]: one list per question
            await self._client.reply_question(req_id, [[answer]])
            logger.info("Replied to question %s with %r", req_id, answer)
        except DfcodeAPIError as exc:
            logger.error("reply_question failed: %s", exc)

    async def _handle_abort_action(self, value: dict) -> None:
        session_id = value.get("session_id", "")
        if not session_id:
            return
        try:
            await self._client.abort(session_id)
            logger.info("Aborted session %s", session_id)
        except DfcodeAPIError as exc:
            logger.error("abort failed: %s", exc)
