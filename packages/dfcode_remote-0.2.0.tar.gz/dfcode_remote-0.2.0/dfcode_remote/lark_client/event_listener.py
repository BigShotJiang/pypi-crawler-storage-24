"""SSE event listener — bridges dfcode events to Feishu card updates.

One EventListener instance handles all chats. It subscribes to the global
dfcode SSE stream and routes events to per-chat state machines that
debounce card updates and handle card splitting.
"""

import asyncio
import json
import logging
import time
from dataclasses import dataclass, field
from typing import Optional

from dfcode_remote.dfcode_client.client import DfcodeClient
from dfcode_remote.dfcode_client.sse import sse_stream
from dfcode_remote.dfcode_client.types import PartInfo, SSEEvent
from dfcode_remote.lark_client.card_builder import (
    MAX_CARD_BLOCKS,
    build_frozen_card,
    build_streaming_card,
)
from dfcode_remote.lark_client.card_service import CardService, CardServiceError
from dfcode_remote.utils.persistence import Persistence

logger = logging.getLogger(__name__)

_DEBOUNCE_SECS = 0.5
_DIRECT_MIN_INTERVAL_SECS = 5.0


@dataclass
class ChatState:
    """Per-chat rendering state."""

    chat_id: str
    session_id: str
    parts: list[PartInfo] = field(default_factory=list)
    card_id: Optional[str] = None
    message_id: Optional[str] = None
    sequence: int = 0
    pending_permission: Optional[dict] = None
    pending_question: Optional[dict] = None
    status: str = "busy"
    direct_mode: bool = False
    last_card_digest: str = ""
    last_direct_send_time: float = 0.0
    completed: bool = False
    _dirty: bool = False

    def mark_dirty(self) -> None:
        self._dirty = True

    def clear_dirty(self) -> bool:
        was = self._dirty
        self._dirty = False
        return was

    def upsert_part(self, part: PartInfo) -> None:
        """Insert or replace a part by id/callID, otherwise append."""
        if part.id:
            for i, existing in enumerate(self.parts):
                if existing.id == part.id:
                    self.parts[i] = part
                    return
        if part.type == "tool" and part.callID:
            for i, p in enumerate(self.parts):
                if p.type == "tool" and p.callID == part.callID:
                    self.parts[i] = part
                    return
        self.parts.append(part)

    def content_block_count(self) -> int:
        return len(self.parts)


class EventListener:
    """Subscribes to dfcode SSE and updates Feishu cards per chat."""

    def __init__(
        self,
        dfcode_url: str,
        client: DfcodeClient,
        card_service: CardService,
        persistence: Persistence,
        handler=None,
        enable_urgent: bool = True,
    ):
        self._url = f"{dfcode_url.rstrip('/')}/global/event"
        self._client = client
        self._card_service = card_service
        self._persistence = persistence
        self._handler = handler
        self._enable_urgent = enable_urgent
        # session_id -> ChatState
        self._states: dict[str, ChatState] = {}
        self._debounce_tasks: dict[str, asyncio.Task] = {}

    def _get_or_create_state(self, session_id: str) -> Optional[ChatState]:
        if session_id in self._states:
            return self._states[session_id]
        # Look up which chat is bound to this session
        for chat_id, sid in self._persistence.list_bindings().items():
            if sid == session_id:
                state = ChatState(chat_id=chat_id, session_id=session_id)
                self._states[session_id] = state
                return state
        return None

    async def run(self) -> None:
        """Main loop — consume SSE events forever (auto-reconnects)."""
        logger.info("Starting SSE listener on %s", self._url)
        async for event in sse_stream(self._url):
            await self._dispatch(event)

    async def _dispatch(self, event: SSEEvent) -> None:
        t = event.type
        props = event.properties

        if t in ("server.connected", "server.heartbeat"):
            return

        if t not in (
            "permission.asked",
            "question.asked",
            "session.idle",
            "session.status",
        ):
            return

        session_id = props.get("sessionID", "")
        if not session_id:
            return

        # Handle session.idle: send final reply to Feishu
        if t == "session.idle" or (
            t == "session.status" and props.get("status", {}).get("type") == "idle"
        ):
            await self._on_session_idle(session_id)
            return

        state = self._get_or_create_state(session_id)
        if state is None:
            return

        logger.debug(
            "SSE routed event=%s session=%s chat=%s", t, session_id, state.chat_id
        )

        if t == "permission.asked":
            await self._on_permission_asked(state, props)
        elif t == "question.asked":
            await self._on_question_asked(state, props)

    async def _on_part_updated(self, state: ChatState, props: dict) -> None:
        part_data = props.get("part", {})
        part = PartInfo.from_dict(part_data)
        state.upsert_part(part)
        state.status = "busy"
        state.mark_dirty()

        # Check if we need to split the card
        if state.content_block_count() >= MAX_CARD_BLOCKS - 5:
            await self._freeze_and_split(state)
        else:
            self._schedule_update(state)

    async def _on_permission_asked(self, state: ChatState, props: dict) -> None:
        permission = {
            "id": props.get("id", ""),
            "permission": props.get("permission", ""),
            "tool": props.get("tool", ""),
            "patterns": props.get("patterns", []),
        }
        card = build_streaming_card(
            [], permission=permission, session_id=state.session_id
        )
        try:
            await self._card_service.send_card_direct(state.chat_id, card)
            logger.info("Sent permission card for session %s", state.session_id)
        except CardServiceError as exc:
            logger.error("send permission card failed: %s", exc)

    async def _on_question_asked(self, state: ChatState, props: dict) -> None:
        question = {
            "id": props.get("id", ""),
            "questions": props.get("questions", []),
        }
        card = build_streaming_card([], question=question, session_id=state.session_id)
        try:
            await self._card_service.send_card_direct(state.chat_id, card)
            logger.info("Sent question card for session %s", state.session_id)
        except CardServiceError as exc:
            logger.error("send question card failed: %s", exc)

    async def _on_session_idle(self, session_id: str) -> None:
        """Session finished — check for pending reply and send final text to Feishu."""
        if not self._handler:
            return
        pending = self._handler._pending_replies.pop(session_id, None)
        if not pending:
            return

        chat_id = pending["chat_id"]
        last_id = pending["last_id"]

        try:
            messages = await self._client.get_messages(session_id)

            # Find latest assistant message after last_id
            found_marker = not last_id
            candidate = None
            for msg in messages:
                if msg.id == last_id:
                    found_marker = True
                    continue
                if found_marker and msg.role == "assistant" and msg.parts:
                    candidate = msg

            if not candidate:
                return

            texts = [p.text for p in candidate.parts if p.type == "text" and p.text]
            if not texts:
                return

            reply = "\n\n".join(texts)
            await self._card_service.send_text(chat_id, reply)
            logger.info("Replied to chat %s with %d chars", chat_id, len(reply))
        except Exception as exc:
            logger.error("_on_session_idle reply failed: %s", exc)

    async def _on_session_error(self, state: ChatState, props: dict) -> None:
        msg = props.get("error", {}).get("message", "Unknown error")
        logger.error("Session %s error: %s", state.session_id, msg)
        try:
            await self._card_service.send_text(state.chat_id, f"❌ 会话错误: {msg}")
        except CardServiceError as exc:
            logger.warning("send_text failed: %s", exc)
        self._states.pop(state.session_id, None)

    def _schedule_update(self, state: ChatState) -> None:
        key = state.session_id
        existing = self._debounce_tasks.get(key)
        if existing and not existing.done():
            existing.cancel()
        task = asyncio.create_task(self._debounced_update(state))
        self._debounce_tasks[key] = task

    async def _debounced_update(self, state: ChatState) -> None:
        await asyncio.sleep(_DEBOUNCE_SECS)
        if state.clear_dirty():
            await self._flush_update(state)

    async def _flush_update(self, state: ChatState) -> None:
        if state.completed:
            return
        content = build_streaming_card(
            state.parts,
            status=state.status,
            permission=state.pending_permission,
            question=state.pending_question,
            session_id=state.session_id,
        )
        digest = json.dumps(content, ensure_ascii=False, sort_keys=True)

        if state.card_id is None:
            if state.direct_mode:
                # In direct_mode we can't update cards in-place, so only send
                # on completion (idle) or when user interaction is needed.
                is_urgent = (
                    state.status == "idle"
                    or state.pending_permission is not None
                    or state.pending_question is not None
                )
                if not is_urgent:
                    state.last_card_digest = digest
                    return
                if state.last_card_digest == digest:
                    return

            # First update — create card and send it
            try:
                card_id = await self._card_service.create_card(content)
                msg_id = await self._card_service.send_card(state.chat_id, card_id)
                state.card_id = card_id
                state.message_id = msg_id
                state.sequence = 1
                state.last_card_digest = digest
                logger.info("Created card %s for session %s", card_id, state.session_id)
            except CardServiceError as exc:
                # CardKit unavailable — enter direct_mode silently.
                # Don't send anything now; _send_final_card will send on idle.
                logger.debug(
                    "CardKit unavailable, entering direct_mode for session %s",
                    state.session_id,
                )
                state.direct_mode = True
                state.last_card_digest = digest
        else:
            ok = await self._card_service.update_card(
                state.card_id, state.sequence, content
            )
            if ok:
                state.sequence += 1
                state.last_card_digest = digest
            else:
                logger.warning(
                    "update_card failed for %s seq %d", state.card_id, state.sequence
                )

    async def _freeze_and_split(self, state: ChatState) -> None:
        """Freeze the current card and start a new one."""
        if state.card_id:
            frozen = build_frozen_card(state.parts)
            await self._card_service.update_card(state.card_id, state.sequence, frozen)
            logger.info("Froze card %s (split)", state.card_id)

        # Reset state for new card
        state.parts = []
        state.card_id = None
        state.message_id = None
        state.sequence = 0

    async def _send_final_card(self, state: ChatState) -> None:
        """Send one final frozen card on completion. No streaming, no duplicates."""
        parts = await self._final_parts(state)
        frozen = build_frozen_card(parts)
        if state.card_id:
            # CardKit mode — update existing card to frozen
            await self._card_service.update_card(state.card_id, state.sequence, frozen)
            logger.info("Froze card %s (complete)", state.card_id)
        else:
            # Direct mode — send one message with the final result
            try:
                msg_id = await self._card_service.send_card_direct(
                    state.chat_id, frozen
                )
                state.message_id = msg_id
                logger.info("Sent final card for session %s", state.session_id)
            except CardServiceError as exc:
                logger.error("send final card failed: %s", exc)
                # Last resort: send plain text summary
                texts = [p.text for p in parts if p.type == "text" and p.text]
                if texts:
                    try:
                        await self._card_service.send_text(
                            state.chat_id, "\n\n".join(texts)
                        )
                    except CardServiceError:
                        pass

    async def _final_parts(self, state: ChatState) -> list[PartInfo]:
        try:
            messages = await self._client.get_messages(state.session_id)
            assistants = [
                msg for msg in messages if msg.role == "assistant" and msg.parts
            ]
            if assistants:
                parts = [
                    part
                    for part in assistants[-1].parts
                    if part.type == "text" and part.text
                ]
                if parts:
                    return parts
        except Exception as exc:
            logger.debug(
                "get_messages failed for session %s: %s", state.session_id, exc
            )

        return [part for part in state.parts if part.type == "text" and part.text]

    async def _notify_complete(self, state: ChatState) -> None:
        try:
            if self._enable_urgent and state.message_id:
                await self._card_service.send_urgent(state.message_id, [])
                await asyncio.sleep(5)
                await self._card_service.cancel_urgent(state.message_id)
        except CardServiceError as exc:
            logger.warning("notify_complete failed: %s", exc)
