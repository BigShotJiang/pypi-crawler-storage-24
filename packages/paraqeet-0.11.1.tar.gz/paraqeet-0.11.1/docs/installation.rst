Usage
=====
.. _install:

Installation
------------

To use ParaQeet, first install it using pip:

.. code-block:: console

   $ pip install paraqeet