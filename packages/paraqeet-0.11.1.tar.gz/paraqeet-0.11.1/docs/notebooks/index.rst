Examples
========

We introduce the usage of the package with some examples. These are also available as interactive notebooks.

.. toctree::
   :maxdepth: 1

   01_OptimizationMap
   02A_Single_qubit_state_preparation
   02B_Single_qubit_gate
   02C_Qubit-bayesian-optimization
   02D_GOAToverGRAPE_TLS
   02E_GOAToverGRAPE_dCRAB
   03_DRAG_pulses
   04A_GRAPE_TLS
   04B_Single_qubit_gate_GRAPE
   04C_Single_qubit_gate_GOAToverGRAPE
   05_Two-qubit-cross-resonance
   06_Resonator_decay
   07_Custom_Hamiltonian
   08A_Smoothness_measure
   08B_Bosonic_grape_state_preparation
   08C_Bosonic_grape_with_smooth_pulses