"""Signal generation model module."""
