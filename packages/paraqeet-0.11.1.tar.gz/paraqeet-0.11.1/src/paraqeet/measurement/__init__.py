"""Measurement model module."""
