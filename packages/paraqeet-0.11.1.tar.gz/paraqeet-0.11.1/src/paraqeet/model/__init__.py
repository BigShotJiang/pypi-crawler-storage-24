"""Base model module."""
