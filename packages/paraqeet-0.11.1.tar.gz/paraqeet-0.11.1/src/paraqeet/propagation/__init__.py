"""Propagation model module."""
