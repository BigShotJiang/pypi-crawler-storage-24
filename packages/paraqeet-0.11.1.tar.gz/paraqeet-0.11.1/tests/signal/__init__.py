"""Signal model module for the testing suite."""
