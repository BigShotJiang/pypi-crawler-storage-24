"""Propagation module for the testing suite."""
