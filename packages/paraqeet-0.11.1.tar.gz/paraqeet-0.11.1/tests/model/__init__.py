"""Model module for the testing suite."""
