"""Examples for the usage of the library."""
