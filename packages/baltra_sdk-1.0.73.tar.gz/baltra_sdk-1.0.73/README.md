# Baltra SDK — Release Notes

## v1.0.72 — Current

| Table | Column | Change |
|-------|--------|--------|
| `candidates` | `application_reminders_sent` | Updated default value |

### Details

**`candidates.application_reminders_sent`**
Default changed from `{"windows": {}}` to explicit boolean keys matching the three reminder types:
```json
{
  "application_reminder_02utc": false,
  "application_reminder_20utc": false,
  "application_reminder_final": false
}
```

### Migration Status

| Database | Applied |
|----------|---------|
| `baltra-chatbot-nonprod-db-instance.cdyoauyystls.us-east-2.rds.amazonaws.com` | ⬜ Pending |
| `chatbot-db-instance.cdyoauyystls.us-east-2.rds.amazonaws.com` | ⬜ Pending |

