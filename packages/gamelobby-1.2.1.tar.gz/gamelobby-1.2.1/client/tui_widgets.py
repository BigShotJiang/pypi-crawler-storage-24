"""
TUI 面板组件 — ChatPanel / CommandPanel / InfoPanel
"""

from __future__ import annotations

from textual.app import ComposeResult
from textual.widgets import Static, Input, RichLog, Label, TabbedContent, TabPane
from textual.containers import Vertical, Horizontal
from textual.widget import Widget


# ═══════════════════════════════════════════════════════
#  ChatPanel — 聊天面板（左栏）
# ═══════════════════════════════════════════════════════

class ChatPanel(Widget):
    """聊天面板：频道标签 + 消息日志 + 在线用户 + 输入框"""

    DEFAULT_CSS = """
    ChatPanel { width: 1fr; min-width: 24; }
    """

    CHANNEL_NAMES = {1: "世界", 2: "房间"}

    def __init__(self, **kw):
        super().__init__(**kw)
        self.current_channel = 1

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Static("[b]世界[/b] │ 房间", id="chat-tabs", classes="panel-title")
            yield RichLog(id="chat-log", wrap=True, highlight=True, markup=True, max_lines=500)
            yield Static("", id="online-list")
            with Vertical(id="chat-input-box"):
                yield Input(placeholder="输入消息… (i 进入输入)", id="chat-input")

    def add_message(self, name: str, text: str, channel: int = 1, time_str: str = ""):
        if channel != self.current_channel:
            return
        log: RichLog = self.query_one("#chat-log", RichLog)
        prefix = f"[#808080]{time_str}[/] " if time_str else ""
        log.write(f"{prefix}[b]{name}[/b]: {text}")

    def add_system_message(self, text: str):
        log: RichLog = self.query_one("#chat-log", RichLog)
        log.write(f"[#808080]>>> {text}[/]")

    def show_history(self, messages: list, channel: int):
        if channel != self.current_channel:
            return
        log: RichLog = self.query_one("#chat-log", RichLog)
        log.clear()
        for m in messages:
            name = m.get("name", "???")
            text = m.get("text", "")
            time_str = m.get("time", "")
            prefix = f"[#808080]{time_str}[/] " if time_str else ""
            log.write(f"{prefix}[b]{name}[/b]: {text}")

    def switch_channel(self, channel_id: int):
        self.current_channel = channel_id
        tabs = self.query_one("#chat-tabs", Static)
        labels = []
        for cid, cname in self.CHANNEL_NAMES.items():
            if cid == channel_id:
                labels.append(f"[b]{cname}[/b]")
            else:
                labels.append(cname)
        tabs.update(" │ ".join(labels))

    def update_online_users(self, users: list):
        label = self.query_one("#online-list", Static)
        if not users:
            label.update("")
            return
        names = ", ".join(u if isinstance(u, str) else u.get("name", "?") for u in users)
        label.update(f"[#808080]在线({len(users)}): {names}[/]")

    @property
    def input_widget(self) -> Input:
        return self.query_one("#chat-input", Input)


# ═══════════════════════════════════════════════════════
#  CommandPanel — 指令面板（中栏）
# ═══════════════════════════════════════════════════════

class CommandPanel(Widget):
    """指令面板：多 Tab 窗口 + 游戏输出 + 指令输入"""

    DEFAULT_CSS = """
    CommandPanel { width: 2fr; min-width: 36; }
    """

    def __init__(self, **kw):
        super().__init__(**kw)
        self._cmd_prefix = "/"

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Static("[b]指令[/b]", id="cmd-tabs", classes="panel-title")
            yield RichLog(id="cmd-log", wrap=True, highlight=True, markup=True, max_lines=1000)
            yield Static("", id="action-bar")
            with Vertical(id="cmd-input-box"):
                yield Input(placeholder="/command", id="cmd-input")

    def add_message(self, text: str, update_last: bool = False):
        log: RichLog = self.query_one("#cmd-log", RichLog)
        if update_last:
            # RichLog 没有原生 update_last，直接追加
            log.write(text)
        else:
            log.write(text)

    def clear(self):
        log: RichLog = self.query_one("#cmd-log", RichLog)
        log.clear()

    def set_action_bar(self, text: str):
        bar = self.query_one("#action-bar", Static)
        bar.update(text)

    def clear_action_bar(self):
        bar = self.query_one("#action-bar", Static)
        bar.update("")

    @property
    def input_widget(self) -> Input:
        return self.query_one("#cmd-input", Input)


# ═══════════════════════════════════════════════════════
#  InfoPanel — 信息面板（右栏）
# ═══════════════════════════════════════════════════════

class InfoPanel(Widget):
    """信息面板：地图/状态/牌桌（根据 location 切换）"""

    DEFAULT_CSS = """
    InfoPanel { width: 1fr; min-width: 24; }
    """

    def __init__(self, **kw):
        super().__init__(**kw)
        self.current_location = "lobby"

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Static("[b]信息[/b]", id="info-title", classes="panel-title")
            yield RichLog(id="info-content", wrap=True, highlight=True, markup=True, max_lines=500)
            yield Static("", id="hand-area")
            yield Static("", id="status-bar")

    def set_location(self, location: str):
        self.current_location = location
        title = self.query_one("#info-title", Static)
        loc_display = {
            "lobby": "大厅",
            "mahjong": "麻将",
            "mahjong_room": "麻将房间",
            "mahjong_playing": "麻将对局",
            "chess": "象棋",
            "chess_room": "象棋房间",
            "chess_playing": "象棋对局",
            "jrpg": "JRPG",
        }
        title.update(f"[b]{loc_display.get(location, location)}[/b]")

    def update_map(self, map_text: str):
        content: RichLog = self.query_one("#info-content", RichLog)
        content.clear()
        for line in map_text.split("\n"):
            content.write(line)

    def update_status(self, player_data: dict):
        bar = self.query_one("#status-bar", Static)
        name = player_data.get("name", "?")
        level = player_data.get("level", 1)
        gold = player_data.get("gold", 0)
        bar.update(f"[b]{name}[/b] Lv.{level}  {gold}G")

    def update_table(self, room_data: dict | None):
        """更新牌桌/棋盘视图"""
        content: RichLog = self.query_one("#info-content", RichLog)
        if room_data is None:
            content.clear()
            self.clear_hand()
            return

        game_type = room_data.get("game_type", "mahjong")
        if game_type == "chess":
            self._render_chess(room_data)
        else:
            self._render_mahjong_table(room_data)

    def _render_mahjong_table(self, room_data: dict):
        content: RichLog = self.query_one("#info-content", RichLog)
        content.clear()

        state = room_data.get("state", "waiting")
        players = room_data.get("players", [])
        room_id = room_data.get("room_id", "?")

        content.write(f"房间: {room_id}  状态: {state}")
        content.write("─" * 30)

        wind_names = ["东", "南", "西", "北"]
        for i, p in enumerate(players):
            name = p.get("name", f"空位{i}")
            score = p.get("score", 25000)
            is_riichi = p.get("riichi", False)
            wind = wind_names[i] if i < 4 else "?"
            riichi_mark = " [立直]" if is_riichi else ""
            content.write(f"{wind} {name} {score}点{riichi_mark}")

            # 弃牌堆
            discards = p.get("discards", [])
            if discards:
                discard_str = " ".join(discards[-12:])
                content.write(f"  弃: {discard_str}")

            # 副露
            melds = p.get("melds", [])
            if melds:
                meld_strs = []
                for m in melds:
                    mtype = m.get("type", "?")
                    tiles = " ".join(m.get("tiles", []))
                    meld_strs.append(f"[{mtype} {tiles}]")
                content.write(f"  副: {' '.join(meld_strs)}")

        # 宝牌和剩余牌数
        dora = room_data.get("dora_indicators", [])
        remaining = room_data.get("remaining_tiles", "?")
        content.write("─" * 30)
        if dora:
            content.write(f"宝牌指示: {' '.join(dora)}")
        content.write(f"剩余: {remaining}张")

    def _render_chess(self, room_data: dict):
        content: RichLog = self.query_one("#info-content", RichLog)
        content.clear()

        board = room_data.get("board")
        if not board:
            players = room_data.get("players", [])
            for p in players:
                name = p.get("name", "空位")
                color = p.get("color", "?")
                content.write(f"{color}: {name}")
            return

        # 渲染棋盘
        pieces = {
            "K": "♔", "Q": "♕", "R": "♖", "B": "♗", "N": "♘", "P": "♙",
            "k": "♚", "q": "♛", "r": "♜", "b": "♝", "n": "♞", "p": "♟",
        }
        content.write("  a b c d e f g h")
        for rank in range(8, 0, -1):
            row = f"{rank} "
            for file in range(8):
                idx = (8 - rank) * 8 + file
                piece = board[idx] if idx < len(board) else "."
                row += pieces.get(piece, piece) + " "
            content.write(row)
        content.write("  a b c d e f g h")

    def update_hand(self, hand: list, drawn: str | None = None,
                    tenpai: object = None, need_discard: bool = False):
        area = self.query_one("#hand-area", Static)
        if not hand:
            area.update("")
            return

        tiles = " ".join(hand)
        drawn_str = f" | [b]{drawn}[/b] ←摸" if drawn else ""
        line = f"手牌: {tiles}{drawn_str}"

        if tenpai:
            if isinstance(tenpai, list):
                waits = ", ".join(str(t) for t in tenpai)
                line += f"\n听: {waits}"
            elif isinstance(tenpai, dict):
                parts = []
                for tile, info in tenpai.items():
                    pts = info if isinstance(info, (int, str)) else ""
                    parts.append(f"{tile}({pts})")
                line += f"\n听: {', '.join(parts)}"

        if need_discard:
            line += "\n[b]请出牌[/b] (d + 牌名)"

        area.update(line)

    def clear_hand(self):
        area = self.query_one("#hand-area", Static)
        area.update("")
