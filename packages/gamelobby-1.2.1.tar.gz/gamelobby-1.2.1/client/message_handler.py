"""
服务器消息解析与分发 — 与 UI 解耦。
将 chat_client.py 中 _display_message() 的逻辑提取到此处。
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any


# ── 消息数据类 ──

@dataclass
class LoginPrompt:
    text: str

@dataclass
class RequestAvatar:
    text: str

@dataclass
class LoginSuccess:
    text: str

@dataclass
class SystemMessage:
    text: str

@dataclass
class GameMessage:
    text: str
    update_last: bool = False
    clear_discard: bool = False

@dataclass
class ChatMessage:
    name: str
    text: str
    channel: int = 1
    time: str = ""

@dataclass
class ChatHistory:
    channel: int
    messages: list = field(default_factory=list)

@dataclass
class StatusUpdate:
    data: dict = field(default_factory=dict)
    map_data: str | None = None

@dataclass
class OnlineUsers:
    users: list = field(default_factory=list)

@dataclass
class GameInvite:
    raw: dict = field(default_factory=dict)

@dataclass
class RoomUpdate:
    room_data: dict | None = None
    message: str | None = None

@dataclass
class RoomLeave:
    location: str | None = None

@dataclass
class GameQuit:
    location: str | None = None

@dataclass
class LocationUpdate:
    location: str

@dataclass
class HandUpdate:
    hand: list = field(default_factory=list)
    drawn: str | None = None
    tenpai_analysis: Any = None
    need_discard: bool = False

@dataclass
class ActionPrompt:
    actions: dict = field(default_factory=dict)
    tile: str = ""
    from_player: str = ""

@dataclass
class SelfActionPrompt:
    actions: dict = field(default_factory=dict)

@dataclass
class WinAnimation:
    winner: str = ""
    win_type: str = "tsumo"
    tile: str = ""
    loser: str = ""
    yakus: list = field(default_factory=list)
    han: int = 0
    fu: int = 0
    score: int = 0
    is_yakuman: bool = False

@dataclass
class ActionCommand:
    action: str = ""
    raw: dict = field(default_factory=dict)


def parse_server_message(msg: dict):
    """将原始 JSON dict 解析为对应的数据类实例。"""
    msg_type = msg.get("type", "chat")

    if msg_type == "login_prompt":
        return LoginPrompt(text=msg.get("text", ""))

    if msg_type == "request_avatar":
        return RequestAvatar(text=msg.get("text", ""))

    if msg_type == "login_success":
        return LoginSuccess(text=msg.get("text", ""))

    if msg_type == "system":
        return SystemMessage(text=msg.get("text", ""))

    if msg_type == "game":
        return GameMessage(
            text=msg.get("text", ""),
            update_last=msg.get("update_last", False),
            clear_discard=msg.get("clear_discard", False),
        )

    if msg_type == "chat":
        return ChatMessage(
            name=msg.get("name", "???"),
            text=msg.get("text", ""),
            channel=msg.get("channel", 1),
            time=msg.get("time", ""),
        )

    if msg_type == "chat_history":
        return ChatHistory(
            channel=msg.get("channel", 1),
            messages=msg.get("messages", []),
        )

    if msg_type == "status":
        return StatusUpdate(
            data=msg.get("data", {}),
            map_data=msg.get("map"),
        )

    if msg_type == "online_users":
        return OnlineUsers(users=msg.get("users", []))

    if msg_type == "game_invite":
        return GameInvite(raw=msg)

    if msg_type == "room_update":
        return RoomUpdate(
            room_data=msg.get("room_data"),
            message=msg.get("message"),
        )

    if msg_type == "room_leave":
        return RoomLeave(location=msg.get("location"))

    if msg_type == "game_quit":
        return GameQuit(location=msg.get("location"))

    if msg_type == "location_update":
        return LocationUpdate(location=msg.get("location", "lobby"))

    if msg_type == "hand_update":
        return HandUpdate(
            hand=msg.get("hand", []),
            drawn=msg.get("drawn"),
            tenpai_analysis=msg.get("tenpai_analysis"),
            need_discard=msg.get("need_discard", False),
        )

    if msg_type == "action_prompt":
        return ActionPrompt(
            actions=msg.get("actions", {}),
            tile=msg.get("tile", ""),
            from_player=msg.get("from_player", ""),
        )

    if msg_type == "self_action_prompt":
        return SelfActionPrompt(actions=msg.get("actions", {}))

    if msg_type == "win_animation":
        return WinAnimation(
            winner=msg.get("winner", "?"),
            win_type=msg.get("win_type", "tsumo"),
            tile=msg.get("tile", "?"),
            loser=msg.get("loser", ""),
            yakus=msg.get("yakus", []),
            han=msg.get("han", 0),
            fu=msg.get("fu", 0),
            score=msg.get("score", 0),
            is_yakuman=msg.get("is_yakuman", False),
        )

    if msg_type == "action":
        return ActionCommand(action=msg.get("action", ""), raw=msg)

    # 未识别消息，包装为 GameMessage 以便显示
    text = msg.get("text", str(msg))
    return GameMessage(text=text)
