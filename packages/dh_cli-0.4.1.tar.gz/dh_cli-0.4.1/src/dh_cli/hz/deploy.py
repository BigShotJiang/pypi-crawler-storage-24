"""Deploy API server, docking service, or frontend."""

import typer

from dh_cli.hz import require_repo, run_script

deploy_app = typer.Typer(context_settings={"help_option_names": ["-h", "--help"]})


@deploy_app.command("api")
def deploy_api(
    env: str = typer.Option("prod", "--env", "-e", help="Environment: prod or dev."),
):
    """Build and deploy the Horizyn API server."""
    repo = require_repo("horizyn-api")
    script = repo / f"server/build-and-push-{env}.sh"
    run_script(script, cwd=repo)


@deploy_app.command("docking")
def deploy_docking(
    env: str = typer.Option("prod", "--env", "-e", help="Environment: prod or dev."),
):
    """Build and deploy the docking service."""
    repo = require_repo("horizyn-api")
    script = repo / f"docking_service/build-and-push-{env}.sh"
    run_script(script, cwd=repo)


@deploy_app.command("frontend")
def deploy_frontend(
    env: str = typer.Option("prod", "--env", "-e", help="Environment: prod or dev."),
):
    """Build and deploy the Horizyn frontend."""
    repo = require_repo("horizyn-frontend")
    script = repo / "scripts/deploy.sh"
    run_script(script, args=[env], cwd=repo)
