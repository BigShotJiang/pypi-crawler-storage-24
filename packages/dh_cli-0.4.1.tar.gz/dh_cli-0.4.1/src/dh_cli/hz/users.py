"""User management via SSM parameters."""

import typer

users_app = typer.Typer(context_settings={"help_option_names": ["-h", "--help"]})

SSM_PARAMS = {
    "allowed_emails": "/horizyn/{env}/auth/allowed_emails",
    "allowed_domains": "/horizyn/{env}/auth/allowed_domains",
    "admin_domains": "/horizyn/{env}/auth/admin_domains",
    "admin_emails": "/horizyn/{env}/auth/admin_emails",
    "alpha_emails": "/horizyn/{env}/auth/alpha_emails",
}


def _ssm_client():
    import boto3

    return boto3.client("ssm", region_name="us-east-1")


def _get_param(ssm, name: str) -> str:
    try:
        resp = ssm.get_parameter(Name=name)
        return resp["Parameter"]["Value"]
    except ssm.exceptions.ParameterNotFound:
        return ""


def _put_param(ssm, name: str, value: str) -> None:
    ssm.put_parameter(Name=name, Value=value, Type="String", Overwrite=True)
    typer.echo(f"Updated {name}")


def _parse_csv(raw: str) -> set[str]:
    return {e.strip().lower() for e in raw.split(",") if e.strip()}


def _format_csv(emails: set[str]) -> str:
    return ",".join(sorted(emails))


@users_app.command("list")
def list_users(
    env: str = typer.Option("prod", "--env", "-e", help="Environment: prod or dev."),
):
    """Show all authorized users and their tiers."""
    ssm = _ssm_client()

    admin_domains = _parse_csv(_get_param(ssm, SSM_PARAMS["admin_domains"].format(env=env)))
    admin_emails = _parse_csv(_get_param(ssm, SSM_PARAMS["admin_emails"].format(env=env)))
    alpha_emails = _parse_csv(_get_param(ssm, SSM_PARAMS["alpha_emails"].format(env=env)))
    allowed_domains = _parse_csv(_get_param(ssm, SSM_PARAMS["allowed_domains"].format(env=env)))
    allowed_emails = _parse_csv(_get_param(ssm, SSM_PARAMS["allowed_emails"].format(env=env)))

    typer.echo(f"\n  Horizyn users ({env})\n")

    def _print_section(label: str, items: set[str]) -> None:
        typer.echo(f"  {label}:")
        if not items:
            typer.echo("    (none)")
        else:
            for item in sorted(items):
                typer.echo(f"    {item}")

    _print_section("Admin domains", admin_domains)
    _print_section("Admin emails", admin_emails)
    _print_section("Alpha emails", alpha_emails)
    _print_section("Allowed domains", allowed_domains)
    _print_section("Allowed emails", allowed_emails)
    typer.echo()


@users_app.command("add")
def add_user(
    email: str = typer.Argument(help="Email address to add."),
    env: str = typer.Option("prod", "--env", "-e", help="Environment: prod or dev."),
    tier: str = typer.Option("beta", "--tier", "-t", help="Tier: beta or alpha."),
):
    """Add a user to the authorized emails list (and optionally set tier)."""
    email = email.strip().lower()
    ssm = _ssm_client()

    allowed = _parse_csv(_get_param(ssm, SSM_PARAMS["allowed_emails"].format(env=env)))
    if email in allowed:
        typer.echo(f"{email} is already in allowed_emails for {env}.")
    else:
        allowed.add(email)
        _put_param(ssm, SSM_PARAMS["allowed_emails"].format(env=env), _format_csv(allowed))

    if tier == "alpha":
        alphas = _parse_csv(_get_param(ssm, SSM_PARAMS["alpha_emails"].format(env=env)))
        if email in alphas:
            typer.echo(f"{email} is already in alpha_emails for {env}.")
        else:
            alphas.add(email)
            _put_param(ssm, SSM_PARAMS["alpha_emails"].format(env=env), _format_csv(alphas))


@users_app.command("remove")
def remove_user(
    email: str = typer.Argument(help="Email address to remove."),
    env: str = typer.Option("prod", "--env", "-e", help="Environment: prod or dev."),
):
    """Remove a user from all email lists for the given environment."""
    email = email.strip().lower()
    ssm = _ssm_client()

    for param_key in ("allowed_emails", "admin_emails", "alpha_emails"):
        param_name = SSM_PARAMS[param_key].format(env=env)
        current = _parse_csv(_get_param(ssm, param_name))
        if email in current:
            current.discard(email)
            _put_param(ssm, param_name, _format_csv(current))
            typer.echo(f"  Removed {email} from {param_key}")


@users_app.command("promote")
def promote_user(
    email: str = typer.Argument(help="Email address to promote."),
    tier: str = typer.Option(..., "--tier", "-t", help="Target tier: alpha."),
    env: str = typer.Option("prod", "--env", "-e", help="Environment: prod or dev."),
):
    """Promote a user to a higher tier."""
    email = email.strip().lower()

    if tier not in ("alpha",):
        typer.echo("Only --tier alpha is supported. Admin is domain-based.", err=True)
        raise typer.Exit(1)

    ssm = _ssm_client()

    allowed = _parse_csv(_get_param(ssm, SSM_PARAMS["allowed_emails"].format(env=env)))
    if email not in allowed:
        typer.echo(f"{email} is not in allowed_emails for {env}. Add them first.", err=True)
        raise typer.Exit(1)

    alphas = _parse_csv(_get_param(ssm, SSM_PARAMS["alpha_emails"].format(env=env)))
    if email in alphas:
        typer.echo(f"{email} is already alpha in {env}.")
    else:
        alphas.add(email)
        _put_param(ssm, SSM_PARAMS["alpha_emails"].format(env=env), _format_csv(alphas))


@users_app.command("find")
def find_user(
    email: str = typer.Argument(help="Email address to search for."),
):
    """Search for a user across both prod and dev environments."""
    email = email.strip().lower()
    ssm = _ssm_client()

    domain = email.split("@")[-1] if "@" in email else ""

    typer.echo(f"\n  Searching for: {email}\n")

    for env in ("prod", "dev"):
        matches: list[str] = []

        for param_key in SSM_PARAMS:
            param_name = SSM_PARAMS[param_key].format(env=env)
            values = _parse_csv(_get_param(ssm, param_name))

            if param_key.endswith("_domains"):
                if domain and domain in values:
                    matches.append(f"{param_key} (via @{domain})")
            else:
                if email in values:
                    matches.append(param_key)

        if matches:
            typer.echo(f"  {env}: found")
            for m in matches:
                typer.echo(f"    - {m}")
        else:
            typer.echo(f"  {env}: not found")

    typer.echo()
