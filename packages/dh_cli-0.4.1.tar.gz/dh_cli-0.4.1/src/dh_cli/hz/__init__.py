"""dh hz — Horizyn API management commands."""

import os
from pathlib import Path

import typer

hz_app = typer.Typer(
    help="Manage Horizyn API: users, deployments, local servers, and tests.",
    context_settings={"help_option_names": ["-h", "--help"]},
)


def _find_workspace_root() -> Path:
    root = os.environ.get("WORKSPACE_ROOT")
    if root:
        p = Path(root)
        if p.is_dir():
            return p

    for child in Path("/workspaces").iterdir():
        if child.is_dir() and not child.name.startswith("."):
            return child

    typer.echo("Cannot determine workspace root. Set $WORKSPACE_ROOT.", err=True)
    raise typer.Exit(1)


def require_repo(name: str) -> Path:
    """Return the path to a cloned repo, or exit with a helpful error."""
    root = _find_workspace_root()
    repo = root / name
    if not repo.is_dir():
        typer.echo(
            f"Repository '{name}' not found at {repo}.\n"
            f"Clone it with: dc clone {name}",
            err=True,
        )
        raise typer.Exit(1)
    return repo


def run_script(script: Path, args: list[str] | None = None, cwd: Path | None = None) -> None:
    """Run a shell script, streaming output. Exit on failure."""
    import subprocess

    if not script.exists():
        typer.echo(f"Script not found: {script}", err=True)
        raise typer.Exit(1)

    cmd = ["bash", str(script)] + (args or [])
    result = subprocess.run(cmd, cwd=cwd)
    if result.returncode != 0:
        raise typer.Exit(result.returncode)


from dh_cli.hz.users import users_app  # noqa: E402
from dh_cli.hz.deploy import deploy_app  # noqa: E402
from dh_cli.hz.local import local_app  # noqa: E402
from dh_cli.hz.test import test_app  # noqa: E402
from dh_cli.hz.tf import tf_app  # noqa: E402

hz_app.add_typer(users_app, name="users", help="Manage authorized users and tiers.")
hz_app.add_typer(deploy_app, name="deploy", help="Deploy API, docking, or frontend.")
hz_app.add_typer(local_app, name="local", help="Run local development servers.")
hz_app.add_typer(test_app, name="test", help="Run integration test suites.")
hz_app.add_typer(tf_app, name="tf", help="Terraform apply for Horizyn infrastructure.")
