"""Run integration test suites."""

import re
from pathlib import Path
from typing import Optional

import typer

from dh_cli.hz import require_repo, run_script

test_app = typer.Typer(context_settings={"help_option_names": ["-h", "--help"]})


def _discover_suites(test_dir: Path) -> list[tuple[int, str, Path]]:
    """Return sorted list of (number, name, path) for numbered test scripts."""
    suites = []
    for f in test_dir.glob("*.sh"):
        m = re.match(r"^(\d+)_(.+)\.sh$", f.name)
        if m:
            suites.append((int(m.group(1)), m.group(2), f))
    return sorted(suites, key=lambda t: t[0])


def _resolve_suites(
    available: list[tuple[int, str, Path]], selectors: list[str]
) -> list[tuple[int, str, Path]]:
    """Match selectors (numbers or name substrings) to available suites."""
    matched = []
    for sel in selectors:
        sel = sel.strip()
        found = False
        if sel.isdigit():
            num = int(sel)
            for suite in available:
                if suite[0] == num:
                    matched.append(suite)
                    found = True
                    break
        if not found:
            for suite in available:
                if sel.lower() in suite[1].lower():
                    matched.append(suite)
                    found = True
                    break
        if not found:
            typer.echo(f"No suite matching '{sel}'.", err=True)
            raise typer.Exit(1)
    return matched


@test_app.command("list")
def list_tests(
    target: str = typer.Option("local", "--target", "-t", help="local or deployed."),
):
    """Show available test suites."""
    repo = require_repo("horizyn-api")
    test_dir = repo / f"test/server/{target}"
    if not test_dir.is_dir():
        typer.echo(f"Test directory not found: {test_dir}", err=True)
        raise typer.Exit(1)

    suites = _discover_suites(test_dir)
    typer.echo(f"\n  {target} test suites:\n")
    for num, name, path in suites:
        typer.echo(f"  {num:3d}  {name}")
    typer.echo()


@test_app.command("local")
def test_local(
    suites: Optional[list[str]] = typer.Argument(None, help="Suite numbers or names. Omit to run all."),
):
    """Run local integration tests."""
    repo = require_repo("horizyn-api")
    test_dir = repo / "test/server/local"

    if not suites:
        run_script(test_dir / "run_all_tests.sh", cwd=test_dir)
        return

    available = _discover_suites(test_dir)
    selected = _resolve_suites(available, suites)

    for num, name, path in selected:
        typer.echo(f"\n{'='*60}")
        typer.echo(f"  Running: {num}_{name}")
        typer.echo(f"{'='*60}\n")
        run_script(path, cwd=test_dir)


@test_app.command("deployed")
def test_deployed(
    suites: Optional[list[str]] = typer.Argument(None, help="Suite numbers or names. Omit to run all."),
    env: str = typer.Option("dev", "--env", "-e", help="Environment: dev or prod."),
):
    """Run deployed integration tests."""
    repo = require_repo("horizyn-api")
    test_dir = repo / "test/server/deployed"

    if not suites:
        run_script(test_dir / "run_all_tests.sh", args=[env], cwd=test_dir)
        return

    available = _discover_suites(test_dir)
    selected = _resolve_suites(available, suites)

    for num, name, path in selected:
        typer.echo(f"\n{'='*60}")
        typer.echo(f"  Running: {num}_{name}")
        typer.echo(f"{'='*60}\n")
        run_script(path, args=[env], cwd=test_dir)
