"""Run local development servers."""

import typer

from dh_cli.hz import require_repo, run_script

local_app = typer.Typer(context_settings={"help_option_names": ["-h", "--help"]})


@local_app.command("api")
def local_api():
    """Start the local Horizyn API server in Docker."""
    repo = require_repo("horizyn-api")
    run_script(repo / "server/run_local_server.sh", cwd=repo)


@local_app.command("docking")
def local_docking():
    """Start the local docking service in Docker."""
    repo = require_repo("horizyn-api")
    run_script(repo / "docking_service/run_local_server.sh", cwd=repo)
