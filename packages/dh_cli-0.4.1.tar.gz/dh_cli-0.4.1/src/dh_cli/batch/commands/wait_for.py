"""Wait-for command for polling job completion."""

import click

from ..aws_batch import BatchClient
from ..manifest import BATCH_JOBS_BASE, JobStatus, load_manifest
from .status import _parse_retry_job_id


@click.command()
@click.argument("job_ids", nargs=-1, required=True)
@click.option("--poll-interval", default=30, type=int, help="Seconds between status checks")
@click.option("--timeout", default=86400, type=int, help="Maximum seconds to wait per job")
@click.option("--base-path", default=BATCH_JOBS_BASE, help="Base path for job data")
def wait_for(job_ids, poll_interval, timeout, base_path):
    """Wait for one or more batch jobs to complete.

    Accepts Dayhoff job IDs or retry IDs (e.g. job-r1). Exits 0 if all
    jobs succeeded, 1 if any failed.
    """
    any_failed = False

    for job_id in job_ids:
        parent_job_id, retry_id = _parse_retry_job_id(job_id)

        manifest = load_manifest(parent_job_id, base_path)

        if retry_id:
            retry_info = None
            for r in manifest.retries or []:
                if r.retry_id == retry_id:
                    retry_info = r
                    break
            if not retry_info or not retry_info.batch_job_id:
                click.echo(f"No batch job for retry {retry_id}", err=True)
                any_failed = True
                continue
            batch_job_id = retry_info.batch_job_id
        else:
            if manifest.status == JobStatus.SUCCEEDED:
                click.echo(f"{job_id}: already succeeded", err=True)
                continue
            if manifest.status == JobStatus.FAILED:
                click.echo(f"{job_id}: already failed", err=True)
                any_failed = True
                continue
            batch_job_id = manifest.batch.job_id if manifest.batch else None
            if not batch_job_id:
                click.echo(f"No batch job ID for {job_id}", err=True)
                any_failed = True
                continue

        client = BatchClient()
        status = client.wait_for_job(
            batch_job_id,
            poll_interval=poll_interval,
            timeout=timeout,
        )
        click.echo(f"{job_id}: {status}", err=True)
        if status == "FAILED":
            any_failed = True

    raise SystemExit(1 if any_failed else 0)
