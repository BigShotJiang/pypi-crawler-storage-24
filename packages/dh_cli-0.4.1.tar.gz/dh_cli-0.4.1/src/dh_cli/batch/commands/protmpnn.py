"""ProtMPNN/LigandMPNN sequence design pipeline command."""

import math
import os
import shutil
from pathlib import Path

import click

from ..aws_batch import BatchClient, BatchError, resolve_dependency
from ..job_id import generate_job_id, get_aws_username
from ..manifest import (
    BATCH_JOBS_BASE,
    BatchConfig,
    InputConfig,
    JobManifest,
    JobStatus,
    OutputConfig,
    create_job_directory,
    get_job_dir,
    save_manifest,
)

DEFAULT_QUEUE = "t4-1x-spot"
MAX_WORKERS = 50
FILES_PER_WORKER = 10
DEFAULT_JOB_DEFINITION = "dayhoff-protmpnn"
DEFAULT_IMAGE_URI = (
    "074735440724.dkr.ecr.us-east-1.amazonaws.com/dayhoff:protmpnn-latest"
)


@click.command()
@click.argument("input_dir", type=click.Path(exists=True))
@click.option(
    "--workers",
    default=None,
    type=int,
    help="Number of parallel workers [default: ~1 per 10 files]",
)
@click.option(
    "--queue",
    default=DEFAULT_QUEUE,
    help=f"Batch queue [default: {DEFAULT_QUEUE}]",
)
@click.option("--dry-run", is_flag=True, help="Show plan without submitting")
@click.option(
    "--local",
    "run_local",
    is_flag=True,
    help="Force local execution via Docker",
)
@click.option(
    "--remote",
    "run_remote",
    is_flag=True,
    help="Force Batch submission (override auto-detect)",
)
@click.option(
    "--shell",
    "run_shell",
    is_flag=True,
    help="Drop into container shell for debugging",
)
@click.option("--base-path", default=BATCH_JOBS_BASE, help="Base path for job data")
@click.option("--after", "after", multiple=True, help="Job ID(s) to wait for before starting")
@click.option(
    "--auto-validate-top",
    type=int,
    default=None,
    help="Auto-submit Boltz validation for top N variants after completion",
)
def protmpnn(input_dir, workers, queue, dry_run, run_local, run_remote, run_shell, base_path, after, auto_validate_top):
    """Design protein sequences with ProtMPNN/LigandMPNN.

    Processes a directory of YAML config files, each specifying a PDB
    structure and design parameters. Generates variant sequences ranked
    by confidence.

    \b
    Examples:
      # Run on a GPU engine (auto-detects GPU, runs locally)
      dh batch protmpnn input/

      # Force remote Batch submission
      dh batch protmpnn input/ --remote

      # Preview what would run
      dh batch protmpnn input/ --dry-run

      # Run locally via Docker
      dh batch protmpnn input/ --local

    \b
    After remote job completes:
      dh batch status <job-id>
      dh batch finalize <job-id> --output ./results/

    \b
    YAML config format:
      version: 1
      pdb_path: 6DHI.pdb
      model_type: ligand_mpnn
      num_sequences: 20
      seed: 42
      temperature: 0.1
      fixed_residues: "A42 A181 A217 A218"
    """
    input_path = Path(input_dir).resolve()

    if run_shell:
        _run_shell_mode(input_path)
        return

    if run_local:
        _run_local_mode(input_path, auto_validate_top, base_path)
        return

    # Auto-detect GPU for smart defaulting
    if not run_remote and not dry_run:
        if _has_local_gpu():
            click.echo("GPU detected — running locally (use --remote to override)")
            _run_local_mode(input_path, auto_validate_top, base_path)
            return

    _submit_batch_job(input_path, workers, queue, dry_run, base_path, after, auto_validate_top)


def _has_local_gpu() -> bool:
    """Check if a local NVIDIA GPU is available."""
    import subprocess

    try:
        result = subprocess.run(
            ["nvidia-smi"],
            capture_output=True,
            timeout=5,
        )
        return result.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False


def _count_yaml_files(input_path: Path) -> int:
    return len(list(input_path.glob("*.yaml")))


def _copy_inputs_to_job_dir(input_path: Path, job_dir: Path) -> int:
    """Copy input YAML and PDB files to job directory."""
    input_dir = job_dir / "input"
    input_dir.mkdir(parents=True, exist_ok=True)

    count = 0
    for yaml_file in sorted(input_path.glob("*.yaml")):
        shutil.copy2(yaml_file, input_dir / yaml_file.name)
        count += 1

    # Copy PDB files alongside YAMLs
    for pdb_file in sorted(input_path.glob("*.pdb")):
        shutil.copy2(pdb_file, input_dir / pdb_file.name)

    return count


def _submit_batch_job(
    input_path: Path,
    workers: int | None,
    queue: str,
    dry_run: bool,
    base_path: str,
    after: tuple[str, ...] = (),
    auto_validate_top: int | None = None,
):
    """Submit ProtMPNN job to AWS Batch."""
    click.echo(f"Scanning {input_path} for YAML files...")
    num_files = _count_yaml_files(input_path)

    if num_files == 0:
        click.echo(
            click.style("Error: No YAML files found in input directory", fg="red"),
            err=True,
        )
        raise SystemExit(1)

    click.echo(f"Found {num_files} config(s) to process")

    if workers is None:
        workers = max(1, min(math.ceil(num_files / FILES_PER_WORKER), MAX_WORKERS))
    array_size = min(num_files, workers)

    job_id = generate_job_id("protmpnn")

    click.echo()
    click.echo(f"Job ID:           {job_id}")
    click.echo(f"Input:            {input_path}")
    click.echo(f"Configs:          {num_files}")
    click.echo(f"Workers:          {array_size}")
    files_per_worker = math.ceil(num_files / array_size)
    click.echo(f"Files per worker: ~{files_per_worker}")
    click.echo(f"Queue:            {queue}")
    click.echo(f"Job definition:   {DEFAULT_JOB_DEFINITION}")

    if dry_run:
        click.echo()
        click.echo(click.style("Dry run - job not submitted", fg="yellow"))
        return

    if not click.confirm("\nSubmit job?", default=True):
        click.echo("Cancelled.")
        raise SystemExit(0)
    click.echo()

    job_dir = create_job_directory(job_id, base_path)
    click.echo(f"Created job directory: {job_dir}")

    click.echo("Copying input files...")
    copied = _copy_inputs_to_job_dir(input_path, job_dir)
    click.echo(f"Copied {copied} YAML files")

    manifest = JobManifest(
        job_id=job_id,
        user=job_id.split("-")[0],
        pipeline="protmpnn",
        status=JobStatus.PENDING,
        image_uri=DEFAULT_IMAGE_URI,
        input=InputConfig(
            source=str(input_path),
            num_sequences=num_files,
            num_chunks=array_size,
        ),
        batch=BatchConfig(
            queue=queue,
            job_definition=DEFAULT_JOB_DEFINITION,
            array_size=array_size,
        ),
        output=OutputConfig(
            destination=None,
            finalized=False,
        ),
        depends_on=list(after) if after else None,
    )

    save_manifest(manifest, base_path)

    try:
        resolved = [resolve_dependency(jid, base_path) for jid in after]
        depends_on = [{"jobId": aws_id} for aws_id in resolved if aws_id is not None] or None

        client = BatchClient()

        environment = {
            "JOB_DIR": str(job_dir),
            "JOB_ID": job_id,
            "BATCH_ARRAY_SIZE": str(array_size),
            "BATCH_NUM_FILES": str(num_files),
        }

        batch_job_id = client.submit_job(
            job_name=job_id,
            job_definition=DEFAULT_JOB_DEFINITION,
            job_queue=queue,
            array_size=array_size,
            environment=environment,
            timeout_seconds=1 * 3600,  # 1 hour
            retry_attempts=5,
            depends_on=depends_on,
            share_identifier=get_aws_username(),
        )

        manifest.status = JobStatus.SUBMITTED
        manifest.batch.job_id = batch_job_id
        save_manifest(manifest, base_path)

        click.echo()
        click.echo(click.style("Job submitted successfully!", fg="green"))
        click.echo()
        click.echo(f"AWS Batch Job ID: {batch_job_id}")
        if depends_on:
            click.echo(f"Waiting on:       {', '.join(after)}")
        click.echo()
        click.echo("Next steps:")
        click.echo(f"  Check status:  dh batch status {job_id}")
        click.echo(f"  View logs:     dh batch logs {job_id}")
        click.echo(f"  Cancel:        dh batch cancel {job_id}")
        click.echo()
        click.echo("After completion:")
        click.echo(
            f"  Finalize:      dh batch finalize {job_id} --output ./results/"
        )

        if auto_validate_top:
            _submit_boltz_validation(
                job_id, batch_job_id, job_dir, auto_validate_top, base_path
            )

    except BatchError as e:
        manifest.status = JobStatus.FAILED
        manifest.error_message = str(e)
        save_manifest(manifest, base_path)
        click.echo(click.style(f"Failed to submit job: {e}", fg="red"), err=True)
        raise SystemExit(1)


def _run_local_mode(input_path: Path, auto_validate_top: int | None = None, base_path: str = BATCH_JOBS_BASE):
    """Run ProtMPNN locally in a Docker container."""
    import subprocess

    click.echo("Running ProtMPNN locally in container...")
    click.echo(f"Input directory: {input_path}")

    yaml_files = list(input_path.glob("*.yaml"))
    if not yaml_files:
        click.echo(click.style("Error: No YAML files found", fg="red"), err=True)
        raise SystemExit(1)

    click.echo(f"Found {len(yaml_files)} config file(s)")

    temp_job_dir = input_path / ".local_protmpnn_job"
    temp_input_dir = temp_job_dir / "input"
    temp_output_dir = temp_job_dir / "output"

    if temp_job_dir.exists():
        shutil.rmtree(temp_job_dir)

    temp_input_dir.mkdir(parents=True)
    temp_output_dir.mkdir(parents=True)

    for yaml_file in yaml_files:
        shutil.copy2(yaml_file, temp_input_dir / yaml_file.name)
    for pdb_file in input_path.glob("*.pdb"):
        shutil.copy2(pdb_file, temp_input_dir / pdb_file.name)

    click.echo(f"Output will be at: {temp_output_dir}/")
    click.echo()

    cmd = [
        "docker",
        "run",
        "--rm",
        "--gpus",
        "all",
        "-v",
        "/primordial:/primordial",
        "-v",
        f"{temp_job_dir}:{temp_job_dir}",
        "-e",
        f"JOB_DIR={temp_job_dir}",
        "-e",
        "AWS_BATCH_JOB_ARRAY_INDEX=0",
        "-e",
        "BATCH_ARRAY_SIZE=1",
        "-e",
        f"BATCH_NUM_FILES={len(yaml_files)}",
        DEFAULT_IMAGE_URI,
    ]

    click.echo(f"Running: {' '.join(cmd)}")
    click.echo()

    try:
        result = subprocess.run(cmd)
        if result.returncode != 0:
            click.echo(
                click.style(
                    f"Container exited with code {result.returncode}", fg="red"
                ),
                err=True,
            )
            raise SystemExit(result.returncode)

        csv_files = list(temp_output_dir.glob("results_worker_*.csv"))
        if csv_files:
            # Merge worker CSVs into results.csv for local mode
            import pandas as pd

            dfs = [pd.read_csv(f) for f in csv_files]
            merged = pd.concat(dfs, ignore_index=True)
            merged = merged.sort_values("overall_confidence", ascending=False)
            merged.to_csv(temp_output_dir / "results.csv", index=False)

            click.echo()
            click.echo(click.style("Design complete!", fg="green"))
            click.echo(f"Results: {temp_output_dir / 'results.csv'}")
            click.echo(f"  {len(merged)} variants generated")

            if auto_validate_top:
                _run_local_boltz_validation(
                    temp_output_dir, input_path, auto_validate_top
                )
        else:
            click.echo(click.style("Warning: No results CSV found", fg="yellow"))

    except FileNotFoundError:
        click.echo(
            click.style(
                "Error: Docker not found. Is Docker installed and running?",
                fg="red",
            ),
            err=True,
        )
        raise SystemExit(1)


def _run_shell_mode(input_path: Path):
    """Drop into container shell for debugging."""
    import subprocess

    click.echo("Dropping into container shell...")
    click.echo(f"Input will be available at: /input/")
    click.echo()

    cmd = [
        "docker",
        "run",
        "--rm",
        "-it",
        "--gpus",
        "all",
        "-v",
        "/primordial:/primordial",
        "-v",
        f"{input_path}:/input",
        "-e",
        "JOB_DIR=/input",
        "-e",
        "AWS_BATCH_JOB_ARRAY_INDEX=0",
        "--entrypoint",
        "/bin/bash",
        DEFAULT_IMAGE_URI,
    ]

    click.echo(f"Running: {' '.join(cmd)}")
    click.echo()

    try:
        subprocess.run(cmd)
    except FileNotFoundError:
        click.echo(
            click.style(
                "Error: Docker not found. Is Docker installed and running?",
                fg="red",
            ),
            err=True,
        )
        raise SystemExit(1)


def _convert_to_boltz(results_dir: Path, config_dir: Path, top_n: int) -> Path:
    """Run protmpnn-to-boltz conversion, return the output directory."""
    from .protmpnn_to_boltz import (
        _build_boltz_yaml,
        _load_ligand_smiles,
        _write_pymol_script,
    )

    import pandas as pd
    import yaml

    csv_path = results_dir / "results.csv"
    if not csv_path.exists():
        worker_csvs = sorted(results_dir.glob("results_worker_*.csv"))
        if not worker_csvs:
            raise FileNotFoundError(f"No results CSV in {results_dir}")
        dfs = [pd.read_csv(f) for f in worker_csvs]
        df = pd.concat(dfs, ignore_index=True).sort_values(
            "overall_confidence", ascending=False
        )
    else:
        df = pd.read_csv(csv_path)

    top_n = min(top_n, len(df))
    top_variants = df.head(top_n)
    ligand_map = _load_ligand_smiles(str(config_dir), results_dir)

    boltz_dir = results_dir.parent / "boltz_input"
    boltz_dir.mkdir(parents=True, exist_ok=True)

    generated = []
    for _idx, row in top_variants.iterrows():
        config_name = row.get("config_name", "unknown")
        variant_id = int(row.get("variant_id", _idx))
        sequence = row["sequence"]
        confidence = row.get("overall_confidence", float("nan"))

        boltz_yaml = _build_boltz_yaml(
            sequence=sequence,
            config_name=config_name,
            variant_id=variant_id,
            ligand_smiles=ligand_map.get(config_name),
        )

        filename = f"{config_name}_var{variant_id:03d}.yaml"
        with open(boltz_dir / filename, "w") as f:
            yaml.dump(boltz_yaml, f, default_flow_style=False, sort_keys=False)
        generated.append((filename, confidence))

    _write_pymol_script(boltz_dir, results_dir, generated, ligand_map)
    return boltz_dir


def _run_local_boltz_validation(
    results_dir: Path, original_input_path: Path, top_n: int
):
    """Convert top variants to Boltz YAMLs and run Boltz locally."""
    click.echo()
    click.echo(f"Auto-validating top {top_n} variants with Boltz...")

    boltz_dir = _convert_to_boltz(results_dir, original_input_path, top_n)
    num_yamls = len(list(boltz_dir.glob("*.yaml")))
    click.echo(f"Generated {num_yamls} Boltz configs at {boltz_dir}/")
    click.echo()

    from .boltz import _run_local_mode as boltz_local

    boltz_local(boltz_dir)


def _submit_boltz_validation(
    protmpnn_job_id: str,
    protmpnn_aws_job_id: str,
    job_dir: Path,
    top_n: int,
    base_path: str,
):
    """Pre-register a dependent Boltz Batch job that runs after ProtMPNN completes.

    The ProtMPNN worker writes results to job_dir/output/. The Boltz conversion
    happens at finalize time — we set up a post-finalize hook via an environment
    variable that tells the ProtMPNN finalizer to convert and submit Boltz.
    """
    click.echo()
    click.echo(
        f"Boltz validation for top {top_n} will run after ProtMPNN finalize."
    )
    click.echo(
        "After ProtMPNN completes, finalize will auto-convert and submit Boltz:"
    )
    click.echo(f"  dh batch finalize {protmpnn_job_id} --auto-validate-top {top_n}")
    click.echo()
    click.echo(
        "Or manually: dh batch protmpnn-to-boltz <results_dir> --top "
        f"{top_n} && dh batch boltz <boltz_dir>"
    )
