"""Convert ProtMPNN results to Boltz input YAMLs for structural validation."""

import shutil
from pathlib import Path

import click
import pandas as pd
import yaml


@click.command("protmpnn-to-boltz")
@click.argument("results_dir", type=click.Path(exists=True))
@click.option("--top", default=10, type=int, help="Number of top variants to convert")
@click.option(
    "--output",
    "-o",
    default=None,
    type=click.Path(),
    help="Output directory for Boltz YAMLs [default: boltz_input/]",
)
@click.option(
    "--config",
    "config_dir",
    default=None,
    type=click.Path(exists=True),
    help="Directory containing original ProtMPNN config YAMLs (for ligand_smiles)",
)
def protmpnn_to_boltz(results_dir, top, output, config_dir):
    """Convert top ProtMPNN variants to Boltz YAML configs.

    Takes a ProtMPNN results directory (containing results.csv) and generates
    Boltz-format YAML files for structural validation of the top-N variants.

    \b
    Examples:
      # Convert top 10 from local run
      dh batch protmpnn-to-boltz input/.local_protmpnn_job/output/ --output boltz_in/

      # Convert top 20, pull ligand SMILES from original configs
      dh batch protmpnn-to-boltz results/ --top 20 --config input/ -o boltz_in/

    \b
    The generated Boltz YAMLs can be used directly:
      dh batch boltz boltz_in/
      dh batch boltz --local boltz_in/
    """
    results_path = Path(results_dir).resolve()
    csv_path = results_path / "results.csv"

    if not csv_path.exists():
        # Try worker CSVs if results.csv not found (e.g. raw output before finalize)
        worker_csvs = sorted(results_path.glob("results_worker_*.csv"))
        if worker_csvs:
            dfs = [pd.read_csv(f) for f in worker_csvs]
            df = pd.concat(dfs, ignore_index=True)
            df = df.sort_values("overall_confidence", ascending=False)
        else:
            click.echo(
                click.style(
                    "Error: No results.csv or results_worker_*.csv found", fg="red"
                ),
                err=True,
            )
            raise SystemExit(1)
    else:
        df = pd.read_csv(csv_path)

    if len(df) == 0:
        click.echo(click.style("Error: Results CSV is empty", fg="red"), err=True)
        raise SystemExit(1)

    top_n = min(top, len(df))
    top_variants = df.head(top_n)

    # Resolve ligand SMILES from original config YAMLs
    ligand_map = _load_ligand_smiles(config_dir, results_path)

    output_path = Path(output or "boltz_input").resolve()
    output_path.mkdir(parents=True, exist_ok=True)

    click.echo(f"Converting top {top_n} variants to Boltz format...")

    generated = []
    for idx, row in top_variants.iterrows():
        config_name = row.get("config_name", "unknown")
        variant_id = int(row.get("variant_id", idx))
        sequence = row["sequence"]
        confidence = row.get("overall_confidence", float("nan"))

        boltz_yaml = _build_boltz_yaml(
            sequence=sequence,
            config_name=config_name,
            variant_id=variant_id,
            ligand_smiles=ligand_map.get(config_name),
        )

        filename = f"{config_name}_var{variant_id:03d}.yaml"
        yaml_path = output_path / filename

        with open(yaml_path, "w") as f:
            yaml.dump(boltz_yaml, f, default_flow_style=False, sort_keys=False)

        generated.append((filename, confidence))

    # Copy PDB files for reference if available
    pdbs_src = results_path / "pdbs"
    if pdbs_src.exists():
        pdbs_dest = output_path / "reference_pdbs"
        pdbs_dest.mkdir(exist_ok=True)
        for pdb in pdbs_src.glob("*.pdb"):
            shutil.copy2(pdb, pdbs_dest / pdb.name)

    # Generate PyMOL visualization script
    _write_pymol_script(output_path, results_path, generated, ligand_map)

    click.echo()
    click.echo(click.style(f"Generated {len(generated)} Boltz configs", fg="green"))
    click.echo(f"Output: {output_path}/")
    click.echo()
    click.echo("Next steps:")
    click.echo(f"  dh batch boltz {output_path}/")
    click.echo(f"  dh batch boltz --local {output_path}/")


def _load_ligand_smiles(
    config_dir: str | None, results_path: Path
) -> dict[str, str | None]:
    """Load ligand_smiles from original ProtMPNN config YAMLs.

    Searches config_dir first, then falls back to the input/ sibling
    of the results directory (common in local runs).
    """
    smiles_map: dict[str, str | None] = {}

    search_dirs = []
    if config_dir:
        search_dirs.append(Path(config_dir))

    # For local runs: results are at input/.local_protmpnn_job/output/
    # Config YAMLs are at input/
    if results_path.name == "output":
        job_dir = results_path.parent
        input_dir = job_dir / "input"
        if input_dir.exists():
            search_dirs.append(input_dir)

    for search_dir in search_dirs:
        for yaml_file in search_dir.glob("*.yaml"):
            try:
                with open(yaml_file) as f:
                    data = yaml.safe_load(f)
                if isinstance(data, dict) and data.get("ligand_smiles"):
                    smiles_map[yaml_file.stem] = data["ligand_smiles"]
            except Exception:
                continue

    return smiles_map


def _build_boltz_yaml(
    sequence: str,
    config_name: str,
    variant_id: int,
    ligand_smiles: str | None = None,
) -> dict:
    """Build a Boltz-format YAML dict for a single variant."""
    sequences = [
        {
            "protein": {
                "id": "A",
                "sequence": sequence,
            }
        }
    ]

    if ligand_smiles:
        sequences.append(
            {
                "ligand": {
                    "id": "B",
                    "smiles": ligand_smiles,
                }
            }
        )

    return {
        "version": 1,
        "sequences": sequences,
    }


def _write_pymol_script(
    output_path: Path,
    results_path: Path,
    generated: list[tuple[str, float]],
    ligand_map: dict[str, str | None],
):
    """Generate a PyMOL script for visualizing WT + variant structures.

    This script is designed to be run after Boltz validation completes,
    loading the predicted structures and aligning them to the WT.
    """
    pdbs_dir = results_path / "pdbs"
    wt_pdbs = sorted(pdbs_dir.glob("*.pdb")) if pdbs_dir.exists() else []

    lines = [
        "# PyMOL visualization script for ProtMPNN variants",
        "# Generated by: dh batch protmpnn-to-boltz",
        "#",
        "# Usage: pymol view_variants.pml",
        "#   or:  pymol -r view_variants.pml",
        "",
        "from pymol import cmd",
        "",
    ]

    if wt_pdbs:
        wt_pdb = wt_pdbs[0]
        lines.append(f'cmd.load("reference_pdbs/{wt_pdb.name}", "wildtype")')
        lines.append('cmd.color("gray80", "wildtype")')
        lines.append("")

    lines.append("# Load variant structures after Boltz validation")
    lines.append("# Boltz outputs will be in the finalized results directory")
    for filename, confidence in generated:
        obj_name = filename.replace(".yaml", "")
        lines.append(f"# {obj_name}: confidence={confidence:.3f}")

    lines.extend([
        "",
        "# Align all objects to wildtype",
        'for obj in cmd.get_object_list():',
        '    if obj != "wildtype":',
        '        cmd.align(obj, "wildtype")',
        "",
        "# Show cartoon representation",
        "cmd.show('cartoon')",
        "cmd.hide('lines')",
        "",
        "# Highlight mutations (after loading Boltz results)",
        "# cmd.select('mutations', 'wildtype and not (same sequence as variant)')",
        "",
        "cmd.zoom()",
        "print('Loaded variant structures. Align Boltz results manually.')",
    ])

    script_path = output_path / "view_variants.pml"
    with open(script_path, "w") as f:
        f.write("\n".join(lines) + "\n")
