"""
Servicio de backup y restore para TAI-SQL.
Orquesta herramientas nativas de BD con tai-storage para almacenamiento.
"""
import os
import re
import shutil
import subprocess
import tempfile
from datetime import datetime
from typing import List, Optional

from tai_sql.schema import SchemaManager


def _parse_stderr(stderr: str, operation: str) -> str:
    """
    Analiza el stderr de herramientas nativas y genera un mensaje
    claro y accionable para el usuario.
    """
    lower = stderr.lower()

    # --- Errores de conexión ---
    if 'connection refused' in lower:
        return (
            f"No se pudo conectar al servidor de base de datos.\n"
            f"   Verifica que el servidor esté corriendo y que host/puerto sean correctos."
        )
    if 'could not connect' in lower or 'connection to server' in lower:
        return (
            f"Error de conexión al servidor de base de datos.\n"
            f"   Revisa las credenciales y parámetros de conexión en datasource()."
        )

    # --- Autenticación ---
    if 'password authentication failed' in lower or 'authentication failed' in lower:
        return (
            f"Falló la autenticación.\n"
            f"   Verifica usuario y contraseña en datasource()."
        )

    # --- Base de datos no existe ---
    match = re.search(r'database "(.+?)" does not exist', lower)
    if match:
        db_name = match.group(1)
        return (
            f"La base de datos '{db_name}' no existe.\n"
            f"   Créala antes de ejecutar {operation}, o revisa la configuración en datasource()."
        )

    # --- Objetos ya existen (restore sin --clean) ---
    already_exists = re.findall(r'relation "(.+?)" already exists', stderr)
    constraint_exists = re.findall(r'constraint "(.+?)" .* already exists', stderr)
    duplicate_keys = re.findall(r'duplicate key.*constraint "(.+?)"', stderr)
    conflicts = set(already_exists + constraint_exists)

    if conflicts or duplicate_keys:
        n_total = len(conflicts) + len(duplicate_keys)
        lines = [f"El restore encontró {n_total} conflicto(s) con objetos existentes:"]

        if conflicts:
            shown = sorted(conflicts)[:5]
            lines.append(f"   Objetos que ya existen: {', '.join(shown)}" +
                         (f" (+{len(conflicts) - 5} más)" if len(conflicts) > 5 else ""))
        if duplicate_keys:
            lines.append(f"   Datos duplicados en: {', '.join(sorted(set(duplicate_keys)))}")

        lines.append("")
        lines.append("   Soluciones:")
        lines.append("   • Usa --clean para eliminar objetos antes de restaurar")
        lines.append("   • O restaura sobre una base de datos vacía")
        return "\n".join(lines)

    # --- Permisos ---
    if 'permission denied' in lower:
        return (
            f"Permisos insuficientes para ejecutar {operation}.\n"
            f"   Verifica que el usuario tenga los privilegios necesarios."
        )

    # --- Fallback: resumen compacto ---
    error_lines = [l.strip() for l in stderr.strip().splitlines()
                   if 'error:' in l.lower() or 'fatal:' in l.lower()]
    if error_lines:
        summary = error_lines[0]
        if len(error_lines) > 1:
            summary += f"\n   (+{len(error_lines) - 1} error(es) adicionales)"
        return summary

    return stderr.strip()[:300]


class BackupService:
    """Servicio centralizado de backup/restore usando herramientas nativas + tai-storage."""

    def __init__(self, schema_manager: SchemaManager):
        self.sm = schema_manager

    def _verify_tool(self, tool_name: str) -> None:
        """Verifica que la herramienta nativa esté disponible en PATH."""
        if not shutil.which(tool_name):
            raise FileNotFoundError(
                f"No se encontró '{tool_name}' en el PATH. "
                f"Instálalo para poder usar backup/restore con {self.sm.driver.name}."
            )

    def _build_filename(self, fmt: str) -> str:
        """Genera nombre de archivo con convención: {database}_{schema}_{timestamp}.{ext}"""
        ext = self.sm.driver.backup_file_extension(fmt)
        ts = datetime.now().strftime('%Y%m%d_%H%M%S')
        return f"{self.sm.provider.database}_{self.sm.schema_name}_{ts}.{ext}"

    def backup(self, data_only: bool = False, schema_only: bool = False,
               fmt: Optional[str] = None) -> str:
        """
        Ejecuta un backup nativo y lo sube al storage configurado.

        Args:
            data_only: Solo datos, sin estructura DDL
            schema_only: Solo estructura, sin datos
            fmt: Formato de backup (override del configurado en datasource)

        Returns:
            Nombre del archivo de backup creado
        """
        fmt = fmt or self.sm.backup_format
        tool = self.sm.driver.backup_tool_name()
        self._verify_tool(tool)

        filename = self._build_filename(fmt)
        origin = self.sm.backup_storage

        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = os.path.join(tmpdir, filename)

            cmd = self.sm.driver.backup_command(
                host=self.sm.provider.host,
                port=self.sm.provider.port,
                username=self.sm.provider.username,
                database=self.sm.provider.database,
                output_path=tmp_path,
                schema=self.sm.schema_name,
                fmt=fmt,
                data_only=data_only,
                schema_only=schema_only,
            )

            backup_env = self.sm.driver.backup_env(self.sm.provider.password)
            env = {**os.environ, **{k: v for k, v in backup_env.items() if v is not None}}

            result = subprocess.run(cmd, env=env, capture_output=True, text=True)
            if result.returncode != 0:
                msg = _parse_stderr(result.stderr, 'backup')
                raise RuntimeError(f"Falló el backup con {tool}:\n   {msg}")

            # Subir al storage
            folder = origin.get_folder('.')
            with open(tmp_path, 'rb') as f:
                folder.upload_file(f.read(), filename)

        # Aplicar retención
        if self.sm.backup_retention is not None:
            self._apply_retention()

        return filename

    def restore(self, filename: str, clean: bool = False) -> None:
        """
        Descarga un backup del storage y lo restaura en la base de datos.

        Args:
            filename: Nombre del archivo de backup a restaurar
            clean: Si True, elimina objetos existentes antes de restaurar
        """
        is_sql = filename.endswith('.sql')
        tool = 'psql' if (is_sql and self.sm.driver.name == 'postgresql') else self.sm.driver.restore_tool_name()
        self._verify_tool(tool)

        origin = self.sm.backup_storage
        folder = origin.get_folder('.')
        file = folder.get_file(filename)

        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = os.path.join(tmpdir, filename)

            data = file.read()
            with open(tmp_path, 'wb') as f:
                f.write(data)

            target = self.sm.restore_provider

            cmd = self.sm.driver.restore_command(
                host=target.host,
                port=target.port,
                username=target.username,
                database=target.database,
                input_path=tmp_path,
                schema=self.sm.schema_name,
                clean=clean,
            )

            restore_env = self.sm.driver.backup_env(target.password)
            env = {**os.environ, **{k: v for k, v in restore_env.items() if v is not None}}

            result = subprocess.run(cmd, env=env, capture_output=True, text=True)
            if result.returncode != 0:
                msg = _parse_stderr(result.stderr, 'restore')
                raise RuntimeError(f"Falló el restore con {tool}:\n   {msg}")

    def list_backups(self) -> List[dict]:
        """
        Lista los backups disponibles en el storage configurado.

        Returns:
            Lista de dicts con info de cada backup: name, size, modified_time
        """
        origin = self.sm.backup_storage
        folder = origin.get_folder('.')
        files = folder.list_files()

        backups = []
        for file in sorted(files, key=lambda f: f.filename, reverse=True):
            info = {'name': file.filename}
            if hasattr(file, 'size'):
                info['size'] = file.size
            if hasattr(file, 'modified_time'):
                info['modified_time'] = file.modified_time
            backups.append(info)

        return backups

    def get_latest_backup(self) -> Optional[str]:
        """Retorna el nombre del backup más reciente, o None si no hay."""
        backups = self.list_backups()
        return backups[0]['name'] if backups else None

    def _apply_retention(self) -> None:
        """Elimina backups antiguos para respetar backup_retention."""
        retention = self.sm.backup_retention
        if retention is None:
            return

        backups = self.list_backups()
        if len(backups) <= retention:
            return

        folder = self.sm.backup_storage.get_folder('.')
        for backup in backups[retention:]:
            file = folder.get_file(backup['name'])
            file.delete()
