from __future__ import annotations
import sys
import click
from dataclasses import dataclass, field
from typing import List, Union, Dict, Optional, TYPE_CHECKING
from sqlalchemy import Column, text
from sqlalchemy.schema import Table, ForeignKeyConstraint

from tai_sql import pm, View

if TYPE_CHECKING:
    from tai_sql.drivers import DatabaseDriver
    from .drift import DriftManager

@dataclass
class Statement:
    """
    Clase para representar una sentencia DDL
    """
    text: str | List[str]
    table_name: str

@dataclass
class CreateStatement(Statement):
    """
    Clase para representar una sentencia CREATE TABLE
    """
    columns: List[Column] = field(default_factory=list)

@dataclass
class DropTableStatement(Statement):
    """
    Clase para representar una sentencia DROP TABLE
    """
    pass

@dataclass
class AlterColumnStatement(Statement):
    """
    Clase para representar una sentencia ALTER TABLE ADD COLUMN
    """
    column_name: str
    column: Column

    def check_unique_constraints(self) -> None:

        """
        Verifica y muestra las restricciones únicas de una tabla
        """
        # Verificar si hay datos duplicados antes de añadir constraint UNIQUE
        check_duplicates_query = f"""
        SELECT {self.column_name}, COUNT(*) as count
        FROM {self.table_name}
        GROUP BY {self.column_name}
        HAVING COUNT(*) > 1
        """

        with pm.db.engine.connect() as connection:
            result = connection.execute(text(check_duplicates_query))
        
        return result.first()

@dataclass
class ForeignKeyStatement(Statement):
    """
    Clase para representar una sentencia ALTER TABLE ADD FOREIGN KEY
    """
    fk: ForeignKeyConstraint
    local: Table
    target: Table

@dataclass
class CreateViewStatement(Statement):
    """
    Clase para representar una sentencia CREATE VIEW
    """
    view: View
    view_name: str

@dataclass
class AlterViewStatement(Statement):
    """
    Clase para representar una sentencia CREATE OR REPLACE VIEW
    """
    view: View
    view_name: str

@dataclass
class DropViewStatement(Statement):
    """
    Clase para representar una sentencia DROP VIEW
    """
    view_name: str

@dataclass
class DropForeignKeyStatement(Statement):
    """
    Clase para representar una sentencia DROP CONSTRAINT (Foreign Key)
    """
    constraint_name: str
    fk: ForeignKeyConstraint

@dataclass
class AlterForeignKeyStatement(Statement):
    """
    Clase para representar una sentencia de modificación de Foreign Key (DROP + ADD)
    """
    fk_old: ForeignKeyConstraint
    fk_new: ForeignKeyConstraint
    local: Table
    target: Table

DDLStatements = List[
    Union[CreateStatement, DropTableStatement, AlterColumnStatement, ForeignKeyStatement,
    CreateViewStatement, AlterViewStatement, DropViewStatement,
    DropForeignKeyStatement, AlterForeignKeyStatement]
]

class DDLManager:
    """
    Clase para gestionar las sentencias DDL generadas
    """
    def __init__(self, driver: DatabaseDriver):
        self.driver = driver
        self.statements: DDLStatements = []
        self._dependent_views: list[tuple[str, str]] = []  # (view_name, view_definition)
        self._deferred_fks: list[ForeignKeyStatement] = []
    
    def add_statement(self, statement: Statement):
        """Añade una sentencia DDL a la lista"""
        self.statements.append(statement)

    def clear(self):
        """Limpia todas las sentencias DDL"""
        self.statements.clear()
    
    def generate(self, drift: DriftManager) -> list[DDLStatements]:

        self.generate_table_creations(drift.tables_to_create.values())
        self.generate_table_drops(drift.tables_to_drop.values())
        self.generate_column_modifications(
            drift.columns_to_add,
            drift.columns_to_drop,
            drift.columns_to_modify,
        )
        self.generate_fk_drops(drift.fks_to_drop)
        self.generate_fk_additions(drift.fks_to_add)
        self.generate_fk_modifications(drift.fks_to_modify)
        self.generate_view_drops(drift.views_to_drop)
        self.generate_view_creations(drift.views_to_create)
        self.generate_view_modifications(drift.modified_views)

        return self.statements
    
    def resolve_view_dependencies(self, drift: DriftManager) -> None:
        """
        Detecta vistas que dependen de tablas siendo modificadas y las almacena
        para DROP/CREATE automático durante la ejecución.
        
        Consulta el catálogo del motor para encontrar dependencias directas y
        transitivas (vistas sobre vistas). Las vistas ya gestionadas por el drift
        (creaciones, modificaciones, eliminaciones) se excluyen.
        """
        # Solo nos interesan tablas con cambios en columnas (ALTER TABLE)
        modified_tables: set[str] = set()
        modified_tables.update(drift.columns_to_add.keys())
        modified_tables.update(drift.columns_to_drop.keys())
        modified_tables.update(drift.columns_to_modify.keys())
        
        if not modified_tables:
            return
        
        # Limpiar prefijo de schema (las claves vienen como "schema.table")
        clean_names = [t.split('.')[-1] if '.' in t else t for t in modified_tables]
        
        # Obtener la consulta específica del driver
        query = self.driver.get_dependent_views_statement(pm.db.schema_name, clean_names)
        if not query:
            return
        
        try:
            with pm.db.engine.connect() as conn:
                if pm.db.provider.drivername == 'postgresql':
                    conn.execute(text(f"SET search_path TO {pm.db.schema_name}, public"))
                
                result = conn.execute(text(query))
                all_deps = [(row.view_name, row.view_definition) for row in result]
        except Exception as e:
            click.echo(f"   ⚠️  No se pudieron resolver dependencias de vistas: {e}")
            return
        
        if not all_deps:
            return
        
        # Excluir vistas ya gestionadas por el drift
        drift_views: set[str] = set()
        drift_views.update(drift.views_to_drop.keys())
        drift_views.update(drift.views_to_create.keys())
        drift_views.update(drift.modified_views.keys())
        
        self._dependent_views = [
            (name, defn) for name, defn in all_deps
            if name not in drift_views
        ]
        
        if self._dependent_views:
            click.echo(f"🔗 Vistas dependientes detectadas ({len(self._dependent_views)}):")
            for name, _ in self._dependent_views:
                click.echo(f"   📋 {name} → se eliminará y recreará automáticamente")
            click.echo()

    @property
    def has_dependent_views(self) -> bool:
        """Indica si hay vistas dependientes que gestionar"""
        return bool(self._dependent_views)

    def show(self) -> None:
        """Muestra las sentencias DDL que se van a ejecutar"""
        click.echo()
        click.echo("📄 DDLs:")
        click.echo("=" * 30)
        click.echo()
        
        # Mostrar DROP de vistas dependientes (si las hay)
        if self._dependent_views:
            click.echo("-- Vistas dependientes (DROP temporal) --")
            for name, _ in self._dependent_views:
                drop_stmt = self.driver.drop_view_statement(name, pm.db.schema_name, view_definition="")
                click.echo(drop_stmt)
                click.echo()
        
        for i, statement in enumerate(self.statements, 1):
            if isinstance(statement.text, List):
                for line in statement.text:
                    click.echo(line)
                    click.echo()
            else:
                click.echo(statement.text)
                click.echo()
        
        # Mostrar CREATE de vistas dependientes (si las hay)
        if self._dependent_views:
            click.echo("-- Vistas dependientes (recreación) --")
            for name, defn in reversed(self._dependent_views):
                create_stmt = self.driver.recreate_view_from_definition(name, defn, pm.db.schema_name)
                click.echo(create_stmt)
                click.echo()
        
        click.echo("=" * 30)
        click.echo()
    
    @property
    def has_deferred_fks(self) -> bool:
        """Indica si hay FK constraints diferidas pendientes de ejecución"""
        return bool(self._deferred_fks)

    def execute(self, defer_fks: bool = False) -> Optional[int]:
        """Ejecuta las sentencias DDL en la base de datos
        
        Args:
            defer_fks: Si True, las ForeignKeyStatement no se ejecutan inmediatamente
                       sino que se almacenan para ejecución posterior con execute_deferred_fks().
                       Útil con --with-feed para poblar tablas antes de aplicar FK constraints.
        """
        executed_count = 0

        if not self.statements:
            click.echo("ℹ️  No hay cambios para aplicar")
            return executed_count
            
        click.echo("⚙️  Ejecutando sentencias DDL...")
        
        try:
            
            with pm.db.engine.connect() as conn:
                # Usar transacción para todas las operaciones
                trans = conn.begin()
                
                try:

                    if pm.db.provider.drivername == 'postgresql':
                        conn.execute(text(f"SET search_path TO {pm.db.schema_name}, public"))

                    # ── 1. DROP de vistas dependientes ──
                    if self._dependent_views:
                        click.echo("   🔗 Eliminando vistas dependientes...")
                        for name, _ in self._dependent_views:
                            drop_sql = self.driver.drop_view_statement(name, pm.db.schema_name, view_definition="")
                            conn.execute(text(drop_sql))
                            executed_count += 1
                            click.echo(f"   ⚙️  Eliminar vista dependiente → {name}")

                    # ── 2. Ejecutar DDL statements ──
                    for stmt in self.statements:

                        if isinstance(stmt, CreateStatement):
                            # Ejecutar CREATE TABLE
                            conn.execute(text(stmt.text))
                            executed_count += 1
                            click.echo(f"   ⚙️  Crear tabla → {stmt.table_name}")
                            
                        elif isinstance(stmt, AlterColumnStatement):
                            # Ejecutar ALTER TABLE

                            if stmt.column.unique:
                                result = stmt.check_unique_constraints()

                                if result:
                                    click.echo("   ❌  UniqueConstraint error:")
                                    click.echo(f'   ⚠️  Columna "{stmt.column_name}" tiene valores duplicados en {stmt.table_name}, se omitirá la modificación')
                                    continue

                            if isinstance(stmt.text, List):
                                for sub_stmt in stmt.text:
                                    conn.execute(text(sub_stmt))
                            else:

                                conn.execute(text(stmt.text))

                            executed_count += 1

                            if stmt.column_name:
                                click.echo(f"   ⚙️  Añadir/modificar columna → {stmt.column_name} en {stmt.table_name}")

                        elif isinstance(stmt, ForeignKeyStatement):

                            if defer_fks:
                                self._deferred_fks.append(stmt)
                                local_columns_names = sorted([col.name for col in stmt.fk.columns])
                                target_columns_names = sorted([element.column.name for element in stmt.fk.elements])
                                click.echo(f'   ⏳ FK diferida: {stmt.local.name}[{", ".join(local_columns_names)}] → {stmt.target.name}[{", ".join(target_columns_names)}]')
                                continue

                            # Ejecutar ALTER TABLE
                            try:
                                conn.execute(text(stmt.text))
                            except Exception as fk_err:
                                err_msg = str(fk_err).lower()
                                if 'foreign key' in err_msg or 'violates' in err_msg or 'constraint' in err_msg or 'reference' in err_msg:
                                    local_cols = sorted([col.name for col in stmt.fk.columns])
                                    target_cols = sorted([elem.column.name for elem in stmt.fk.elements])
                                    click.echo(click.style(
                                        f"\n   ❌ Error al aplicar FK: {stmt.local.name}[{', '.join(local_cols)}] → {stmt.target.name}[{', '.join(target_cols)}]",
                                        fg="red",
                                    ))
                                    click.echo(click.style(
                                        "   💡 Si la tabla referenciada necesita datos iniciales antes de aplicar la FK,",
                                        fg="yellow",
                                    ))
                                    click.echo(click.style(
                                        "      usa: tai-sql push --with-feed",
                                        fg="yellow", bold=True,
                                    ))
                                    click.echo()
                                sys.exit(1)

                            executed_count += 1

                            # Mostrar información de la ForeignKey
                            local_columns_names = [col.name for col in stmt.fk.columns]
                            target_columns_names = [element.column.name for element in stmt.fk.elements]
                            # Asegurar el mismo orden
                            local_columns_names.sort()
                            target_columns_names.sort()

                            click.echo(f'   ⚙️  Declarar ForeignKey: {stmt.local.name}[{", ".join(local_columns_names)}] → {stmt.target.name}[{", ".join(target_columns_names)}] en {stmt.local.name}')
                        
                        elif isinstance(stmt, CreateViewStatement):
                            conn.execute(text(stmt.text))
                            executed_count += 1
                            click.echo(f"   ⚙️   Crear vista → {stmt.view_name}")
                            
                        elif isinstance(stmt, AlterViewStatement):
                            conn.execute(text(stmt.text))
                            executed_count += 1
                            click.echo(f"   ⚙️   Modificar vista → {stmt.view_name}")
                            
                        elif isinstance(stmt, DropViewStatement):
                            conn.execute(text(stmt.text))
                            executed_count += 1
                            click.echo(f"   ⚙️   Eliminar vista → {stmt.view_name}")
                        
                        elif isinstance(stmt, DropForeignKeyStatement):
                            conn.execute(text(stmt.text))
                            executed_count += 1
                            click.echo(f"   ⚙️  Eliminar FK → {stmt.constraint_name} en {stmt.table_name}")
                        
                        elif isinstance(stmt, AlterForeignKeyStatement):
                            # Ejecutar DROP + ADD
                            if isinstance(stmt.text, List):
                                for sub_stmt in stmt.text:
                                    conn.execute(text(sub_stmt))
                            else:
                                conn.execute(text(stmt.text))
                            executed_count += 1
                            local_cols = sorted([col.name for col in stmt.fk_new.columns])
                            click.echo(f'   ⚙️  Modificar FK en {stmt.table_name}: [{", ".join(local_cols)}]')
                    
                    # ── 3. Recrear vistas dependientes ──
                    if self._dependent_views:
                        click.echo("   🔗 Recreando vistas dependientes...")
                        for name, defn in reversed(self._dependent_views):
                            create_sql = self.driver.recreate_view_from_definition(name, defn, pm.db.schema_name)
                            conn.execute(text(create_sql))
                            executed_count += 1
                            click.echo(f"   ⚙️  Recrear vista dependiente → {name}")

                    trans.commit()
                    click.echo()
                    click.echo(f"   🎉 {executed_count} operación(es) ejecutada(s) exitosamente")

                    return executed_count
                    
                except Exception as e:
                    trans.rollback()
                    raise e
                
                finally:
                    # Restaurar search_path por defecto
                    if pm.db.provider.drivername == 'postgresql':
                        conn.execute(text("SET search_path TO public"))
                    
        except Exception as e:
            raise Exception(f"Error al ejecutar DDL: {e}")

    def execute_deferred_fks(self) -> int:
        """
        Ejecuta las Foreign Key constraints que fueron diferidas durante execute(defer_fks=True).
        Diseñado para ejecutarse después de poblar las tablas con tai-sql feed.
        """
        if not self._deferred_fks:
            return 0

        click.echo("⚙️  Aplicando Foreign Keys diferidas...")
        executed = 0

        try:
            with pm.db.engine.connect() as conn:
                trans = conn.begin()

                try:
                    if pm.db.provider.drivername == 'postgresql':
                        conn.execute(text(f"SET search_path TO {pm.db.schema_name}, public"))

                    for stmt in self._deferred_fks:
                        conn.execute(text(stmt.text))
                        executed += 1

                        local_cols = sorted([col.name for col in stmt.fk.columns])
                        target_cols = sorted([elem.column.name for elem in stmt.fk.elements])
                        click.echo(f'   ⚙️  FK: {stmt.local.name}[{", ".join(local_cols)}] → {stmt.target.name}[{", ".join(target_cols)}]')

                    trans.commit()
                    self._deferred_fks.clear()
                    click.echo()
                    click.echo(f"   🎉 {executed} FK(s) aplicada(s) exitosamente")
                    return executed

                except Exception as e:
                    trans.rollback()
                    raise e

                finally:
                    if pm.db.provider.drivername == 'postgresql':
                        conn.execute(text("SET search_path TO public"))

        except Exception as e:
            raise Exception(f"Error al ejecutar FK diferida: {e}")

    def generate_table_creations(self, tables: list[Table]) -> None:
        """
        Genera sentencias DDL para crear tablas nuevas con manejo mejorado de DEFAULT
        
        Returns:
            Lista de sentencias DDL de creación
        """
        if not tables:
            return self.statements
        
        click.echo("🛠️  Generando sentencias CREATE TABLE...")
        
        for table in tables:
            
            stmt = CreateStatement(
                text=self.create_table_statement(table),
                table_name=table.name,
                columns=list(table.columns.values())
            )
            self.add_statement(stmt)
            click.echo(f"   🆕 Nueva tabla: {table.name}")
        
        click.echo()
        
        # Generar Foreign Keys como statements separados
        self.generate_foreign_key_statements(tables)
    
    def generate_table_drops(self, tables_to_drop: list[Table]) -> None:
        """
        Genera sentencias DDL para eliminar tablas
        
        Args:
            tables_to_drop: Lista de nombres de tablas a eliminar
        """
        if not tables_to_drop:
            return
            
        click.echo("🛠️  Generando sentencias DROP TABLE...")
        
        for table in tables_to_drop:
            stmt = DropTableStatement(
                text=self.drop_table_statement(table.name),
                table_name=table.name
            )
            self.add_statement(stmt)
            click.echo(f"   🗑️  Tabla a eliminar: {table.name}")
        
        click.echo()

    def generate_foreign_key_statements(self, tables: list[Table]) -> None:
        """
        Genera statements ALTER TABLE ADD CONSTRAINT para todas las Foreign Keys
        """
        if not tables:
            return
            
        click.echo("🛠️  Generando sentencias FOREIGNKEY CONTRAINT...")
        
        for table in tables:
            
            for fk in table.foreign_key_constraints:
                fk_statement = self.foreign_key_statement(table, fk)

                local = fk.parent
                target = fk.referred_table
                local_columns_names = [col.name for col in fk.columns]
                target_columns_names = [element.column.name for element in fk.elements]

                # Asegurar el mismo orden
                local_columns_names.sort()
                target_columns_names.sort()

                if fk_statement:
                    stmt = ForeignKeyStatement(
                        text=fk_statement,
                        table_name=table.name,
                        fk=fk,
                        local=local,
                        target=target,
                    )
                    self.add_statement(stmt)
                    click.echo(f'   🔗 Foreign Key: {local.name}[{", ".join(local_columns_names)}] → {target.name}[{", ".join(target_columns_names)}]')

        click.echo()
    
    def generate_view_creations(self, views: dict[str, 'View']) -> None:
        """
        Genera sentencias DDL para crear vistas nuevas
        
        Args:
            views: Diccionario de vistas nuevas
        """
        if not views:
            return
            
        click.echo("🛠️  Generando sentencias CREATE VIEW...")
        
        for view_name, view in views.items():
            stmt = CreateViewStatement(
                text=self.create_view_statement(view),
                table_name=view_name,
                view=view,
                view_name=view_name
            )
            self.add_statement(stmt)
            click.echo(f"   🆕 Nueva vista: {view_name}")
        
        click.echo()

    def generate_view_modifications(self, views: dict[str, 'View']) -> None:
        """
        Genera sentencias DDL para modificar vistas existentes
        
        Args:
            views: Diccionario de vistas modificadas
        """
        if not views:
            return
            
        click.echo("🛠️  Generando sentencias ALTER VIEW...")
        
        for view_name, view in views.items():
            # Para vistas materializadas, generar múltiples statements
            if view.materialized:
                statements = self.recreate_materialized_view_statement(view)
                for stmt_text in statements:
                    stmt = AlterViewStatement(
                        text=stmt_text,
                        table_name=view_name,
                        view=view,
                        view_name=view_name
                    )
                    self.add_statement(stmt)
            else:
                stmt = AlterViewStatement(
                    text=self.alter_view_statement(view),
                    table_name=view_name,
                    view=view,
                    view_name=view_name
                )
                self.add_statement(stmt)
            
            click.echo(f"   🔄 Vista modificada: {view_name}")
        
        click.echo()

    def generate_view_drops(self, views_to_drop: dict[str, str]) -> None:
        """
        Genera sentencias DDL para eliminar vistas
        
        Args:
            views_to_drop: Diccionario {view_name: drop_statement}
        """
        if not views_to_drop:
            return
            
        click.echo("🛠️  Generando sentencias DROP VIEW...")
        
        for view_name, drop_statement in views_to_drop.items():
            stmt = DropViewStatement(
                text=drop_statement,
                table_name=view_name,
                view_name=view_name
            )
            self.add_statement(stmt)
            click.echo(f"   🗑️  Vista a eliminar: {view_name}")
        
        click.echo()
    
        click.echo()
    
    def generate_fk_drops(self, fks_to_drop: dict[str, list[ForeignKeyConstraint]]) -> None:
        """
        Genera sentencias DDL para eliminar Foreign Keys
        """
        if not fks_to_drop:
            return
            
        click.echo("🛠️  Generando sentencias DROP CONSTRAINT (FK)...")
        
        for table_name, fks in fks_to_drop.items():
            for fk in fks:
                constraint_name = fk.name or f"fk_{table_name}_unknown"
                drop_stmt = self.drop_foreign_key_statement(table_name, constraint_name)
                
                stmt = DropForeignKeyStatement(
                    text=drop_stmt,
                    table_name=table_name,
                    constraint_name=constraint_name,
                    fk=fk
                )
                self.add_statement(stmt)
                local_cols = [col.name for col in fk.columns]
                cols_str = ', '.join(local_cols)
                click.echo(f'   🗑️  Eliminar FK: {constraint_name} en {table_name} [{cols_str}]')
        
        click.echo()
    
    def generate_fk_additions(self, fks_to_add: dict[str, list[ForeignKeyConstraint]]) -> None:
        """
        Genera sentencias DDL para añadir Foreign Keys en tablas existentes
        """
        if not fks_to_add:
            return
            
        click.echo("🛠️  Generando sentencias ADD CONSTRAINT (FK)...")
        
        for table_name, fks in fks_to_add.items():
            for fk in fks:
                # Obtener la tabla local del metadata
                local_table = fk.parent
                fk_statement = self.foreign_key_statement(local_table, fk)
                
                if fk_statement:
                    local = fk.parent
                    target = fk.referred_table
                    local_columns_names = sorted([col.name for col in fk.columns])
                    target_columns_names = sorted([element.column.name for element in fk.elements])
                    
                    stmt = ForeignKeyStatement(
                        text=fk_statement,
                        table_name=table_name,
                        fk=fk,
                        local=local,
                        target=target,
                    )
                    self.add_statement(stmt)
                    click.echo(f'   🔗 Añadir FK: {local.name}[{", ".join(local_columns_names)}] → {target.name}[{", ".join(target_columns_names)}]')
        
        click.echo()

    def generate_fk_modifications(self, fks_to_modify: dict[str, list[tuple[ForeignKeyConstraint, ForeignKeyConstraint]]]) -> None:
        """
        Genera sentencias DDL para modificar Foreign Keys existentes (DROP vieja + ADD nueva).
        Cada entrada es (target_fk, local_fk).
        """
        if not fks_to_modify:
            return
            
        click.echo("🛠️  Generando sentencias ALTER FOREIGN KEY...")
        
        for table_name, fk_pairs in fks_to_modify.items():
            for target_fk, local_fk in fk_pairs:
                # 1) DROP la FK vieja
                old_constraint_name = target_fk.name or f"fk_{table_name}_unknown"
                drop_stmt = self.drop_foreign_key_statement(table_name, old_constraint_name)
                
                # 2) ADD la FK nueva
                local_table = local_fk.parent
                add_stmt = self.foreign_key_statement(local_table, local_fk)
                
                if add_stmt:
                    local = local_fk.parent
                    target = local_fk.referred_table
                    
                    stmt = AlterForeignKeyStatement(
                        text=[drop_stmt, add_stmt],
                        table_name=table_name,
                        fk_old=target_fk,
                        fk_new=local_fk,
                        local=local,
                        target=target,
                    )
                    self.add_statement(stmt)
                    
                    local_cols = sorted([col.name for col in local_fk.columns])
                    changes = []
                    old_ondelete = (target_fk.ondelete or 'NO ACTION').upper()
                    new_ondelete = (local_fk.ondelete or 'NO ACTION').upper()
                    old_onupdate = (target_fk.onupdate or 'NO ACTION').upper()
                    new_onupdate = (local_fk.onupdate or 'NO ACTION').upper()
                    if old_ondelete != new_ondelete:
                        changes.append(f"ON DELETE: {old_ondelete} → {new_ondelete}")
                    if old_onupdate != new_onupdate:
                        changes.append(f"ON UPDATE: {old_onupdate} → {new_onupdate}")
                    
                    click.echo(f'   🔄 Modificar FK en {table_name}: [{", ".join(local_cols)}] — {"; ".join(changes)}')
        
        click.echo()

    def generate_column_modifications(
            self,
            new_cols: Dict[str, list[Column]],
            delete_cols: Dict[str, list[Column]],
            modified_cols: Dict[str, list[Column]]
    ) -> list[Statement]:
        """
        Genera sentencias DDL para las migraciones incrementales
        """
        if new_cols or delete_cols or modified_cols:
            click.echo("🛠️  Generando sentencias de migración...")
        
        else:
            return
        
        # Añadir columnas nuevas
        if new_cols:
            for table_name, columns in new_cols.items():
                for column in columns:
                    # Usar el mismo método para generar definición de columna
                    column_def = self.get_column_definition(column)
                    stmt = AlterColumnStatement(
                        text=f"ALTER TABLE {column.table.name} ADD COLUMN {column_def}",
                        table_name=column.table.name,
                        column_name=column.name,
                        column=column
                    )
                    self.add_statement(stmt)
                    click.echo(f'   ➕ Añadir columna "{column.name}" a "{column.table.name}"')
        
        # Eliminar columnas
        if delete_cols:
            for table_name, columns in delete_cols.items():
                for column in columns:
                    stmt = AlterColumnStatement(
                        text=f"ALTER TABLE {column.table.name} DROP COLUMN {self.reserved_word_mapper(column.name)}",
                        table_name=column.table.name,
                        column_name=column.name,
                        column=column
                    )
                    self.add_statement(stmt)
                    click.echo(f'   ➖ Eliminar columna "{column.name}" de "{column.table.name}"')

        if modified_cols:
            for table_name, columns in modified_cols.items():
                for column in columns:
                    # Generar nueva definición de columna
                    alter_statements = self.alter_column_statements(column.table.name, column)

                    stmt = AlterColumnStatement(
                        text=alter_statements,
                        table_name=column.table.name,
                        column_name=column.name,
                        column=column
                    )

                    self.add_statement(stmt)
                    click.echo(f'   ✏️  Modificar columna "{column.name}" en "{column.table.name}"')
        
        click.echo()
        
        return self.statements

    def create_table_statement(self, table: Table) -> str:
        """Delega al driver específico"""
        return self.driver.create_table_statement(table)
    
    def drop_table_statement(self, table_name: str) -> str:
        """Delega al driver específico pero adaptando la interfaz"""
        # Usar el método existente del driver con parámetros apropiados
        return self.driver.drop_table_statement(
            table_name=table_name,
            schema_name=pm.db.schema_name
        )
    
    def foreign_key_statement(self, table: Table, fk: ForeignKeyConstraint) -> str:
        """Delega al driver específico"""
        return self.driver.foreign_key_statement(table, fk)
    
    def get_column_definition(self, column: Column) -> str:
        """Delega al driver específico"""
        return self.driver.get_column_definition(column)
    
    def alter_column_statements(self, table_name: str, column: Column) -> list[str]:
        """Delega al driver específico"""
        return self.driver.alter_column_statements(table_name, column)
    
    def get_default_value(self, default) -> str:
        """Delega al driver específico"""
        return self.driver.get_default_value(default)
    
    def reserved_word_mapper(self, identifier: str) -> str:
        """Delega al driver específico"""
        return self.driver.reserved_word_mapper(identifier)
    
    def create_view_statement(self, view: 'View') -> str:
        """Delega al driver específico"""
        return self.driver.create_view_statement(view)
    
    def alter_view_statement(self, view: 'View') -> str:
        """Delega al driver específico"""
        return self.driver.alter_view_statement(view)
    
    def recreate_materialized_view_statement(self, view: 'View') -> list[str]:
        """Delega al driver específico"""
        return self.driver.recreate_materialized_view_statement(view)
    
    def drop_view_statement(self, view_name: str, is_materialized: bool = False) -> str:
        """Delega al driver específico pero adaptando la interfaz"""
        # Usar el método existente del driver con parámetros apropiados
        return self.driver.drop_view_statement(
            view_name=view_name,
            schema_name=pm.db.schema_name,
            view_definition="materialized" if is_materialized else ""
        )
    
    def drop_foreign_key_statement(self, table_name: str, constraint_name: str) -> str:
        """Delega al driver específico"""
        return self.driver.drop_foreign_key_statement(
            table_name=table_name,
            constraint_name=constraint_name,
            schema_name=pm.db.schema_name
        )

