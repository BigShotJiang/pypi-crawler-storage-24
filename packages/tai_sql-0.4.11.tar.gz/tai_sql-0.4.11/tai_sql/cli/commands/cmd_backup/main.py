import sys
import click

from tai_sql import pm
from ..utils import verify_server_connection
from ...services.backup import BackupService


@click.command()
@click.option('--schema', '-s', help='Nombre del esquema')
@click.option('--format', '-F', 'fmt', type=click.Choice(['custom', 'sql']), default=None,
              help="Formato del backup: 'custom' (binario) o 'sql' (texto plano)")
@click.option('--data-only', is_flag=True, help='Solo datos, sin estructura DDL')
@click.option('--schema-only', is_flag=True, help='Solo estructura, sin datos')
@click.option('--list', '-l', 'list_backups', is_flag=True, help='Listar backups disponibles')
def backup(schema: str = None, fmt: str = None, data_only: bool = False,
           schema_only: bool = False, list_backups: bool = False):
    """Crea un backup de la base de datos o lista los backups disponibles"""

    if schema:
        pm.set_current_schema(schema)

    if not schema and not pm.db:
        click.echo("❌ No existe ningún esquema por defecto", err=True)
        click.echo("   Puedes definir uno con: tai-sql set-default-schema <nombre>", err=True)
        click.echo("   O usar la opción: --schema <nombre_esquema>", err=True)
        sys.exit(1)

    try:
        service = BackupService(pm.db)

        if list_backups:
            _show_backups(service)
            return

        click.echo()
        click.echo(f"💾 Backup schema: {pm.db.schema_name}")
        click.echo()

        if not verify_server_connection(pm.db.provider.host, pm.db.provider.port):
            sys.exit(1)

        effective_fmt = fmt or pm.db.backup_format
        click.echo(f"   Motor: {pm.db.driver.name}")
        click.echo(f"   Base de datos: {pm.db.provider.database}")
        click.echo(f"   Formato: {effective_fmt}")

        if data_only:
            click.echo("   Modo: solo datos")
        elif schema_only:
            click.echo("   Modo: solo estructura")

        click.echo()
        click.echo("🚀 Ejecutando backup...")

        filename = service.backup(data_only=data_only, schema_only=schema_only, fmt=fmt)

        click.echo()
        click.echo(f"✅ Backup creado exitosamente: {filename}")

        if pm.db.backup_retention:
            click.echo(f"   Retención: últimos {pm.db.backup_retention} backups")

    except FileNotFoundError as e:
        click.echo(f"❌ {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"❌ Error durante backup: {e}", err=True)
        sys.exit(1)


def _show_backups(service: BackupService):
    """Muestra la lista de backups disponibles."""
    click.echo()
    click.echo(f"📋 Backups disponibles para schema: {service.sm.schema_name}")
    click.echo()

    backups = service.list_backups()

    if not backups:
        click.echo("   No se encontraron backups")
        return

    for i, b in enumerate(backups, 1):
        size_str = ""
        if b.get('size') is not None:
            size_mb = b['size'] / (1024 * 1024)
            size_str = f" ({size_mb:.1f} MB)"

        date_str = ""
        if b.get('modified_time'):
            date_str = f" - {b['modified_time']}"

        click.echo(f"   {i}. {b['name']}{size_str}{date_str}")

    click.echo()
