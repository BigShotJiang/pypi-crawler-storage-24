# py-forge-studio

Python client for the Forge Studio API.

## Install

```bash
pip install py-forge-studio
```

## Quick start

```python
from py_forge import Client

client = Client()  # uses FORGE_API_KEY env var

repo = client.repositories.create(name="my-repo", repo_type_key="TST")
branch = client.branches.create(repo.id, name="main-work")
node = client.nodes.create(repo.id, branch.id, node_data={
    "@type": "Folder",
    "@id": "Folder_1",
    "doc_string": "My first node",
})
print(f"Created node {node.id} on branch {branch.id}")
```

## Authentication

Set `FORGE_API_KEY` and `FORGE_BASE_URL` as environment variables:

```bash
export FORGE_API_KEY="your-api-key"
export FORGE_BASE_URL="https://your-instance.forge-studio.tech/api"
```

Or pass them directly:

```python
client = Client(
    api_key="your-api-key",
    base_url="https://your-instance.forge-studio.tech/api",
)
```

Each Forge instance has its own URL in the form `https://<instance>.forge-studio.tech/api`. Contact your Forge account team if you don't know your instance name.

## Usage highlights

| Topic | Example |
|---|---|
| Quick start | [`examples/quickstart.py`](examples/quickstart.py) |
| Repositories | [`examples/repositories.py`](examples/repositories.py) |
| Branches | [`examples/branches.py`](examples/branches.py) |
| Nodes | [`examples/nodes.py`](examples/nodes.py) |
| Merge & rebase | [`examples/merge_and_rebase.py`](examples/merge_and_rebase.py) |
| Async usage | [`examples/async_usage.py`](examples/async_usage.py) |

## Requirements

Python >= 3.9
