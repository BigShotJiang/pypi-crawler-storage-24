from __future__ import annotations

from py_forge._utils import join_url, strip_none


class TestStripNone:
    def test_removes_none_values(self) -> None:
        assert strip_none({"a": 1, "b": None}) == {"a": 1}

    def test_preserves_non_none(self) -> None:
        assert strip_none({"a": 1, "b": 2}) == {"a": 1, "b": 2}

    def test_empty_dict(self) -> None:
        assert strip_none({}) == {}

    def test_all_none(self) -> None:
        assert strip_none({"a": None, "b": None}) == {}

    def test_recursive(self) -> None:
        result = strip_none({"a": {"b": None, "c": 1}, "d": None})
        assert result == {"a": {"c": 1}}

    def test_preserves_falsy_values(self) -> None:
        assert strip_none({"a": 0, "b": "", "c": False, "d": []}) == {
            "a": 0,
            "b": "",
            "c": False,
            "d": [],
        }

    def test_nested_all_none(self) -> None:
        assert strip_none({"a": {"b": None}}) == {"a": {}}


class TestJoinUrl:
    def test_basic_join(self) -> None:
        assert join_url("https://api.example.com", "/v1/repos") == "https://api.example.com/v1/repos"

    def test_trailing_slash_on_base(self) -> None:
        assert join_url("https://api.example.com/", "/v1/repos") == "https://api.example.com/v1/repos"

    def test_no_leading_slash_on_path(self) -> None:
        assert join_url("https://api.example.com", "v1/repos") == "https://api.example.com/v1/repos"

    def test_both_slashes(self) -> None:
        assert join_url("https://api.example.com/", "/v1/repos") == "https://api.example.com/v1/repos"

    def test_no_slashes(self) -> None:
        assert join_url("https://api.example.com", "v1/repos") == "https://api.example.com/v1/repos"

    def test_empty_path(self) -> None:
        assert join_url("https://api.example.com", "") == "https://api.example.com/"

    def test_base_with_path(self) -> None:
        assert join_url("https://api.example.com/api", "/graph/repo") == "https://api.example.com/api/graph/repo"
