from __future__ import annotations

import os

import pytest

from py_forge import (
    AuthenticationError,
    Client,
    NotFoundError,
    Repository,
    SyncPage,
    User,
)

pytestmark = pytest.mark.integration

_BASE_URL = os.environ.get("FORGE_BASE_URL", "")
_SKIP_SSL = "localhost" in _BASE_URL


class TestSmokeHappyPath:
    def test_auth_me_returns_user(self, client: Client) -> None:
        user = client.auth.me()
        assert isinstance(user, User)
        assert user.id
        assert user.email

    def test_list_repositories_returns_page(self, client: Client) -> None:
        page = client.repositories.list()
        assert isinstance(page, SyncPage)
        assert page.total_count >= 1
        assert page.page == 1
        assert isinstance(page.data, list)
        assert len(page.data) >= 1
        assert isinstance(page.data[0], Repository)


class TestSmokeErrors:
    def test_invalid_api_key_raises_auth_error(self) -> None:
        bad_client = Client(
            api_key="invalid",
            base_url=_BASE_URL,
            verify=not _SKIP_SSL,
            max_retries=0,
        )
        try:
            with pytest.raises(AuthenticationError) as exc_info:
                bad_client.auth.me()
            assert exc_info.value.status_code == 401
        finally:
            bad_client.close()

    def test_get_nonexistent_repo_raises_not_found(self, client: Client) -> None:
        with pytest.raises(NotFoundError) as exc_info:
            client.repositories.get("nonexistent-uuid")
        assert exc_info.value.status_code == 404
        assert exc_info.value.message

    def test_detail_error_format_handled(self) -> None:
        bad_client = Client(
            api_key="invalid",
            base_url=_BASE_URL,
            verify=not _SKIP_SSL,
            max_retries=0,
        )
        try:
            with pytest.raises(AuthenticationError) as exc_info:
                bad_client.auth.me()
            assert exc_info.value.message
            assert isinstance(exc_info.value.message, str)
            assert len(exc_info.value.message) > 0
        finally:
            bad_client.close()


class TestSmokeEdgeCases:
    def test_client_context_manager(self) -> None:
        with Client(
            api_key=os.environ["FORGE_API_KEY"],
            base_url=_BASE_URL,
            verify=not _SKIP_SSL,
        ) as c:
            user = c.auth.me()
            assert isinstance(user, User)

    def test_extra_fields_on_response_preserved(self, client: Client) -> None:
        user = client.auth.me()
        assert isinstance(user, User)
        # extra="allow" means any extra fields returned by the API are available
        # via model_extra. We just verify the mechanism works (dict, possibly empty).
        assert isinstance(user.model_extra, dict)
