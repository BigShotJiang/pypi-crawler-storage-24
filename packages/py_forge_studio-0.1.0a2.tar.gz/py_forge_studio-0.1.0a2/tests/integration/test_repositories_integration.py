from __future__ import annotations

import uuid

import pytest

from py_forge import (
    BadRequestError,
    DeleteResponse,
    Client,
    NotFoundError,
    Repository,
    SyncPage,
)

pytestmark = pytest.mark.integration


@pytest.fixture
def temp_repo(client: Client):
    """Create a temporary repository for testing and delete it on teardown."""
    unique_name = f"sdk-test-{uuid.uuid4()}"
    repo = client.repositories.create(
        name=unique_name,
        repo_type_key="TST",
        description="SDK integration test repo",
    )
    yield repo
    try:
        client.repositories.delete(repo.id)
    except Exception:
        pass


class TestRepositoryHappyPath:
    def test_create_repository(self, client: Client) -> None:
        unique_name = f"sdk-test-{uuid.uuid4()}"
        repo = None
        try:
            repo = client.repositories.create(
                name=unique_name,
                repo_type_key="TST",
                description="Test repo for create",
            )
            assert isinstance(repo, Repository)
            assert repo.id
            assert repo.name == unique_name
            assert repo.created_at
            assert repo.default_branch == "main"
            assert repo.branches is not None
            assert len(repo.branches) >= 1
        finally:
            if repo is not None:
                client.repositories.delete(repo.id)

    def test_get_repository(self, client: Client, temp_repo: Repository) -> None:
        fetched = client.repositories.get(temp_repo.id)
        assert isinstance(fetched, Repository)
        assert fetched.id == temp_repo.id
        assert fetched.name == temp_repo.name
        assert fetched.description == temp_repo.description
        assert fetched.repo_type_key == temp_repo.repo_type_key

    def test_update_repository(self, client: Client, temp_repo: Repository) -> None:
        updated = client.repositories.update(
            temp_repo.id,
            name=f"updated-{temp_repo.name}",
            description="Updated description",
        )
        assert isinstance(updated, Repository)
        assert updated.name == f"updated-{temp_repo.name}"
        assert updated.description == "Updated description"
        # Verify persistence
        fetched = client.repositories.get(temp_repo.id)
        assert fetched.name == updated.name
        assert fetched.description == updated.description

    def test_list_repositories(self, client: Client, temp_repo: Repository) -> None:
        page = client.repositories.list()
        assert isinstance(page, SyncPage)
        assert page.total_count >= 1
        repo_ids = [r.id for r in page.data]
        assert temp_repo.id in repo_ids

    def test_delete_repository(self, client: Client) -> None:
        unique_name = f"sdk-test-{uuid.uuid4()}"
        repo = client.repositories.create(
            name=unique_name,
            repo_type_key="TST",
        )
        result = client.repositories.delete(repo.id)
        assert isinstance(result, DeleteResponse)
        assert result.deleted is True


class TestRepositoryErrors:
    def test_get_nonexistent_repository(self, client: Client) -> None:
        with pytest.raises(NotFoundError) as exc_info:
            client.repositories.get("00000000-0000-0000-0000-000000000000")
        assert exc_info.value.status_code == 404
        assert exc_info.value.message

    def test_delete_nonexistent_repository(self, client: Client) -> None:
        with pytest.raises(NotFoundError) as exc_info:
            client.repositories.delete("00000000-0000-0000-0000-000000000000")
        assert exc_info.value.status_code == 404
        assert exc_info.value.message

    def test_create_repository_missing_required_field(self, client: Client) -> None:
        # repo_type_key is required by the method signature, so we test
        # via the API by sending an empty name (invalid)
        with pytest.raises(BadRequestError) as exc_info:
            client.repositories.create(
                name="",
                repo_type_key="TST",
            )
        assert exc_info.value.status_code == 400
        assert exc_info.value.message


class TestRepositoryEdgeCases:
    def test_create_repository_with_custom_default_branch(self, client: Client) -> None:
        unique_name = f"sdk-test-{uuid.uuid4()}"
        repo = None
        try:
            repo = client.repositories.create(
                name=unique_name,
                repo_type_key="TST",
                default_branch_name="develop",
            )
            assert repo.default_branch == "develop"
        finally:
            if repo is not None:
                client.repositories.delete(repo.id)

    def test_list_repositories_pagination(self, client: Client, temp_repo: Repository) -> None:
        page = client.repositories.list(page_size=2)
        assert page.page == 1
        assert page.page_size == 2
        if page.total_count > 2:
            assert page.has_next_page
            page2 = page.next_page()
            assert page2.page == 2
            # Pages should have different items
            ids_p1 = {r.id for r in page.data}
            ids_p2 = {r.id for r in page2.data}
            assert ids_p1.isdisjoint(ids_p2)

    def test_list_repositories_auto_pagination(self, client: Client) -> None:
        page = client.repositories.list(page_size=2)
        all_repos = list(page)
        assert len(all_repos) == page.total_count

    def test_update_repository_partial(self, client: Client, temp_repo: Repository) -> None:
        original_name = temp_repo.name
        updated = client.repositories.update(
            temp_repo.id,
            description="Partially updated",
        )
        assert updated.description == "Partially updated"
        assert updated.name == original_name
