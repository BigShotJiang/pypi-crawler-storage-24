from __future__ import annotations

import os
import uuid

import pytest

from py_forge import (
    AuthenticationError,
    Client,
    NotFoundError,
    User,
)
from py_forge.types.auth import ApiKey, ApiKeyCreated
from py_forge.types.shared import MessageResponse

pytestmark = pytest.mark.integration

_BASE_URL = os.environ.get("FORGE_BASE_URL", "")
_SKIP_SSL = "localhost" in _BASE_URL


class TestAuthHappyPath:
    def test_me_returns_user(self, client: Client) -> None:
        user = client.auth.me()
        assert isinstance(user, User)
        assert user.id
        assert user.email
        assert isinstance(user.is_superuser, bool)
        assert isinstance(user.email_verified, bool)

    def test_update_profile(self, client: Client) -> None:
        # Get original name
        original = client.auth.me()
        original_name = original.name

        try:
            updated = client.auth.update_profile(display_name="SDK Test")
            assert isinstance(updated, User)
            assert updated.name == "SDK Test"
        finally:
            # Restore original name
            if original_name is not None:
                client.auth.update_profile(display_name=original_name)

    def test_get_public_user(self, client: Client) -> None:
        me = client.auth.me()
        user = client.auth.get_public_user(me.id)
        assert isinstance(user, User)
        assert user.id == me.id

    def test_api_key_lifecycle(self, client: Client) -> None:
        key_name = f"sdk-test-key-{uuid.uuid4()}"
        created_key = None
        try:
            # Create
            created_key = client.auth.create_api_key(name=key_name)
            assert isinstance(created_key, ApiKeyCreated)
            assert created_key.api_key  # full key shown once
            assert created_key.id
            assert created_key.name == key_name

            # List and verify it appears
            keys = client.auth.list_api_keys()
            assert isinstance(keys, list)
            key_ids = [k.id for k in keys]
            assert created_key.id in key_ids

            # Revoke
            result = client.auth.revoke_api_key(created_key.id)
            assert isinstance(result, MessageResponse)
            created_key = None  # already cleaned up
        finally:
            # Cleanup if revoke wasn't reached
            if created_key is not None:
                try:
                    client.auth.revoke_api_key(created_key.id)
                except Exception:
                    pass

    def test_logout(self, client: Client) -> None:
        result = client.auth.logout()
        assert isinstance(result, MessageResponse)
        assert result.message


class TestAuthErrors:
    def test_me_with_invalid_token(self) -> None:
        bad_client = Client(
            api_key="invalid-key",
            base_url=_BASE_URL,
            verify=not _SKIP_SSL,
            max_retries=0,
        )
        try:
            with pytest.raises(AuthenticationError) as exc_info:
                bad_client.auth.me()
            assert exc_info.value.status_code == 401
            assert exc_info.value.message
        finally:
            bad_client.close()

    def test_get_public_user_nonexistent(self, client: Client) -> None:
        with pytest.raises(NotFoundError) as exc_info:
            client.auth.get_public_user("nonexistent-uid")
        assert exc_info.value.status_code == 404
        assert exc_info.value.message

    def test_revoke_nonexistent_api_key(self, client: Client) -> None:
        with pytest.raises(NotFoundError) as exc_info:
            client.auth.revoke_api_key("nonexistent-id")
        assert exc_info.value.status_code == 404
        assert exc_info.value.message


class TestAuthEdgeCases:
    def test_create_api_key_and_use_it(self, client: Client) -> None:
        key_name = f"sdk-test-usable-{uuid.uuid4()}"
        created_key = None
        try:
            created_key = client.auth.create_api_key(name=key_name)

            # Use the new key to make a request
            second_client = Client(
                api_key=created_key.api_key,
                base_url=_BASE_URL,
                verify=not _SKIP_SSL,
                max_retries=0,
            )
            try:
                user = second_client.auth.me()
                assert isinstance(user, User)
                assert user.id
            finally:
                second_client.close()

            # Revoke the key
            client.auth.revoke_api_key(created_key.id)

            # Verify the revoked key no longer works
            revoked_client = Client(
                api_key=created_key.api_key,
                base_url=_BASE_URL,
                verify=not _SKIP_SSL,
                max_retries=0,
            )
            try:
                with pytest.raises(AuthenticationError) as exc_info:
                    revoked_client.auth.me()
                assert exc_info.value.status_code == 401
                assert exc_info.value.message
            finally:
                revoked_client.close()

            created_key = None  # already revoked
        finally:
            if created_key is not None:
                try:
                    client.auth.revoke_api_key(created_key.id)
                except Exception:
                    pass

    def test_list_api_keys_returns_list(self, client: Client) -> None:
        keys = client.auth.list_api_keys()
        assert isinstance(keys, list)
        for key in keys:
            assert isinstance(key, ApiKey)
            assert key.id
            assert key.name
            assert key.key_prefix
            assert key.created_at
            assert isinstance(key.is_active, bool)
