from __future__ import annotations

import uuid

import pytest

from py_forge import (
    BadRequestError,
    BranchDiff,
    Client,
    MergeResponse,
    RebaseResponse,
    Repository,
)

pytestmark = pytest.mark.integration


FOLDER_SCHEMA = {
    "classes": [
        {
            "@type": "Class",
            "@id": "Folder",
            "@inherits": "Node",
            "@metadata": {
                "node_type_key": "FLD",
                "displayname": {"singular": "Folder", "plural": "Folders"},
                "NodeOptions": {"type": "structure"},
                "ui": {"icon": {"name": "mdi:folder", "color": "#FFB300"}},
            },
        }
    ]
}


@pytest.fixture
def temp_repo(client: Client):
    """Create a temporary repository for testing and delete it on teardown."""
    unique_name = f"sdk-test-merge-{uuid.uuid4()}"
    repo = client.repositories.create(
        name=unique_name,
        repo_type_key="EVC",
        description="SDK merge integration test repo",
    )
    # Add concrete Folder class so we can create nodes
    page = client.branches.list(repo.id)
    default_bid = page.data[0].id
    client.schemas.update(repo.id, default_bid, schema_data=FOLDER_SCHEMA, commit_msg="Add Folder class")
    yield repo
    try:
        client.repositories.delete(repo.id)
    except Exception:
        pass


@pytest.fixture
def default_branch_id(client: Client, temp_repo: Repository) -> str:
    """Resolve the default (main) branch ID from the temp repo."""
    page = client.branches.list(temp_repo.id)
    for branch in page.data:
        if branch.is_default:
            return branch.id
    assert page.data, "Repository should have at least one branch"
    return page.data[0].id


def _make_node_data(suffix: str | None = None) -> dict:
    """Create unique node data for testing."""
    uid = suffix or uuid.uuid4().hex[:8]
    return {
        "@type": "Folder",
        "doc_string": f"merge test node {uid}",
        "@id": f"Folder_mergetest_{uid}",
    }


class TestMergeHappyPath:
    def test_diff_no_changes(
        self, client: Client, temp_repo: Repository, default_branch_id: str
    ) -> None:
        """Diff a fresh feature branch against main with no changes."""
        feature = client.branches.create(temp_repo.id, name="feature-diff-noop")
        try:
            diff = client.branches.diff(
                temp_repo.id, feature.id, target_branch_id=default_branch_id
            )
            assert isinstance(diff, BranchDiff)
            assert diff.diverged is False
            assert diff.can_fast_forward is False
            assert diff.requires_rebase is False
            assert diff.source_ahead == 0
            assert diff.target_ahead == 0
        finally:
            try:
                client.branches.delete(temp_repo.id, feature.id)
            except Exception:
                pass

    def test_diff_with_changes_and_merge(
        self, client: Client, temp_repo: Repository, default_branch_id: str
    ) -> None:
        """Add node on feature branch, diff, then merge into main."""
        feature = client.branches.create(temp_repo.id, name="feature-merge-test")
        try:
            # Add a node on feature branch
            client.nodes.create(
                temp_repo.id,
                feature.id,
                node_data=_make_node_data(),
            )

            # Diff: feature should be ahead of main
            diff = client.branches.diff(
                temp_repo.id, feature.id, target_branch_id=default_branch_id
            )
            assert isinstance(diff, BranchDiff)
            assert diff.source_ahead >= 1
            assert diff.can_fast_forward is True

            # Merge feature into main
            result = client.repositories.merge(
                temp_repo.id,
                source_branch_id=feature.id,
                target_branch_id=default_branch_id,
                message="Merge feature into main",
            )
            assert isinstance(result, MergeResponse)
            assert result.success is True
            assert result.merge_commit_id is not None
            assert isinstance(result.merge_commit_id, str)
            assert result.merged_at is not None
        finally:
            try:
                client.branches.delete(temp_repo.id, feature.id)
            except Exception:
                pass

    def test_rebase(
        self, client: Client, temp_repo: Repository, default_branch_id: str
    ) -> None:
        """Create divergence between main and feature, then rebase feature onto main."""
        feature = client.branches.create(temp_repo.id, name="feature-rebase-test")
        try:
            # Add a node on main to create divergence
            client.nodes.create(
                temp_repo.id,
                default_branch_id,
                node_data=_make_node_data("main1"),
            )

            # Add a node on feature
            client.nodes.create(
                temp_repo.id,
                feature.id,
                node_data=_make_node_data("feat1"),
            )

            # Rebase feature onto main
            result = client.repositories.rebase(
                temp_repo.id,
                source_branch=feature.id,
                onto_branch=default_branch_id,
            )
            assert isinstance(result, RebaseResponse)
            assert result.success is True
            assert result.message is not None
        finally:
            try:
                client.branches.delete(temp_repo.id, feature.id)
            except Exception:
                pass


class TestMergeErrors:
    def test_merge_nonexistent_branch(
        self, client: Client, temp_repo: Repository, default_branch_id: str
    ) -> None:
        """Merge with a fake source_branch_id returns MergeResponse(success=False)."""
        result = client.repositories.merge(
            temp_repo.id,
            source_branch_id="00000000-0000-0000-0000-000000000000",
            target_branch_id=default_branch_id,
            message="Should fail",
        )
        assert isinstance(result, MergeResponse)
        assert result.success is False

    def test_merge_identical_branches(
        self, client: Client, temp_repo: Repository, default_branch_id: str
    ) -> None:
        """Merge main into main (same branch) — should error or no-op."""
        # The API may reject this or return a no-op response
        try:
            result = client.repositories.merge(
                temp_repo.id,
                source_branch_id=default_branch_id,
                target_branch_id=default_branch_id,
                message="Self-merge",
            )
            # If it succeeds, it's a no-op
            assert isinstance(result, MergeResponse)
        except BadRequestError as exc:
            # Expected: API rejects self-merge
            assert exc.status_code == 400
            assert exc.message


class TestMergeEdgeCases:
    def test_diff_after_merge(
        self, client: Client, temp_repo: Repository, default_branch_id: str
    ) -> None:
        """After merging, diff should show no divergence."""
        feature = client.branches.create(temp_repo.id, name="feature-diff-after-merge")
        try:
            # Add a node on feature
            client.nodes.create(
                temp_repo.id,
                feature.id,
                node_data=_make_node_data("aftermerge"),
            )

            # Merge feature into main
            client.repositories.merge(
                temp_repo.id,
                source_branch_id=feature.id,
                target_branch_id=default_branch_id,
                message="Merge for diff-after test",
            )

            # Diff again: after merge, target is ahead by the merge commit
            # so the branches are diverged (feature has the original commit,
            # target has the merge commit)
            diff = client.branches.diff(
                temp_repo.id, feature.id, target_branch_id=default_branch_id
            )
            assert isinstance(diff, BranchDiff)
            # The merge created a commit on target, so target_ahead >= 1
            assert diff.target_ahead >= 1
        finally:
            try:
                client.branches.delete(temp_repo.id, feature.id)
            except Exception:
                pass

    def test_rebase_already_up_to_date(
        self, client: Client, temp_repo: Repository, default_branch_id: str
    ) -> None:
        """Rebase feature onto main when no divergence — should succeed with empty forwarded_commits."""
        feature = client.branches.create(temp_repo.id, name="feature-rebase-noop")
        try:
            result = client.repositories.rebase(
                temp_repo.id,
                source_branch=feature.id,
                onto_branch=default_branch_id,
            )
            assert isinstance(result, RebaseResponse)
            assert result.success is True
            # No commits to forward
            assert result.forwarded_commits is None or len(result.forwarded_commits) == 0
        finally:
            try:
                client.branches.delete(temp_repo.id, feature.id)
            except Exception:
                pass
