from __future__ import annotations

import uuid

import pytest

from py_forge import (
    Branch,
    BranchDiff,
    BranchHead,
    DeleteResponse,
    Client,
    NotFoundError,
    Repository,
    SyncPage,
)

pytestmark = pytest.mark.integration


@pytest.fixture
def temp_repo(client: Client):
    """Create a temporary repository for testing and delete it on teardown."""
    unique_name = f"sdk-test-branch-{uuid.uuid4()}"
    repo = client.repositories.create(
        name=unique_name,
        repo_type_key="TST",
        description="SDK branch integration test repo",
    )
    yield repo
    try:
        client.repositories.delete(repo.id)
    except Exception:
        pass


@pytest.fixture
def default_branch_id(client: Client, temp_repo: Repository) -> str:
    """Resolve the default (main) branch ID from the temp repo."""
    page = client.branches.list(temp_repo.id)
    for branch in page.data:
        if branch.is_default:
            return branch.id
    # Fallback: return first branch
    assert page.data, "Repository should have at least one branch"
    return page.data[0].id


class TestBranchHappyPath:
    def test_create_branch(self, client: Client, temp_repo: Repository) -> None:
        branch = client.branches.create(temp_repo.id, name="feature-test")
        try:
            assert isinstance(branch, Branch)
            assert branch.name == "feature-test"
            assert branch.repository_id == temp_repo.id
            assert branch.is_default is False
        finally:
            try:
                client.branches.delete(temp_repo.id, branch.id)
            except Exception:
                pass

    def test_list_branches(self, client: Client, temp_repo: Repository) -> None:
        branch = client.branches.create(temp_repo.id, name="feature-list-test")
        try:
            page = client.branches.list(temp_repo.id)
            assert isinstance(page, SyncPage)
            assert page.total_count == 2  # main + feature
            names = [b.name for b in page.data]
            assert "feature-list-test" in names
        finally:
            try:
                client.branches.delete(temp_repo.id, branch.id)
            except Exception:
                pass

    def test_get_branch(self, client: Client, temp_repo: Repository, default_branch_id: str) -> None:
        branch = client.branches.get(temp_repo.id, default_branch_id)
        assert isinstance(branch, Branch)
        assert branch.id == default_branch_id
        assert branch.repository_id == temp_repo.id

    def test_update_branch(self, client: Client, temp_repo: Repository) -> None:
        branch = client.branches.create(temp_repo.id, name="feature-update-test")
        try:
            updated = client.branches.update(
                temp_repo.id, branch.id, description="Updated description"
            )
            assert isinstance(updated, Branch)
            assert updated.description == "Updated description"
        finally:
            try:
                client.branches.delete(temp_repo.id, branch.id)
            except Exception:
                pass

    def test_delete_branch(self, client: Client, temp_repo: Repository) -> None:
        branch = client.branches.create(temp_repo.id, name="feature-delete-test")
        result = client.branches.delete(temp_repo.id, branch.id)
        assert isinstance(result, DeleteResponse)
        assert result.deleted is True

    def test_get_head(self, client: Client, temp_repo: Repository, default_branch_id: str) -> None:
        head = client.branches.get_head(temp_repo.id, default_branch_id)
        assert isinstance(head, BranchHead)
        # head.head is either a commit hash string or None for an empty branch
        assert head.head is None or isinstance(head.head, str)


class TestBranchErrors:
    def test_get_nonexistent_branch(self, client: Client, temp_repo: Repository) -> None:
        with pytest.raises(NotFoundError) as exc_info:
            client.branches.get(temp_repo.id, "00000000-0000-0000-0000-000000000000")
        assert exc_info.value.status_code == 404
        assert exc_info.value.message

    def test_create_branch_on_nonexistent_repo(self, client: Client) -> None:
        with pytest.raises(NotFoundError) as exc_info:
            client.branches.create(
                "00000000-0000-0000-0000-000000000000", name="feature-bad"
            )
        assert exc_info.value.status_code == 404
        assert exc_info.value.message

    def test_delete_default_branch(
        self, client: Client, temp_repo: Repository, default_branch_id: str
    ) -> None:
        result = client.branches.delete(temp_repo.id, default_branch_id)
        assert isinstance(result, DeleteResponse)
        assert result.deleted is True


class TestBranchEdgeCases:
    def test_create_branch_from_source(
        self, client: Client, temp_repo: Repository, default_branch_id: str
    ) -> None:
        branch_a = client.branches.create(
            temp_repo.id, name="branch-a", source_branch_id=default_branch_id
        )
        branch_b = None
        try:
            branch_b = client.branches.create(
                temp_repo.id, name="branch-b", source_branch_id=branch_a.id
            )
            assert isinstance(branch_b, Branch)
            assert branch_b.name == "branch-b"
            # Both should have same head since branch-b forked from branch-a
            head_a = client.branches.get_head(temp_repo.id, branch_a.id)
            head_b = client.branches.get_head(temp_repo.id, branch_b.id)
            assert head_a.head == head_b.head
        finally:
            for b in [branch_b, branch_a]:
                if b is not None:
                    try:
                        client.branches.delete(temp_repo.id, b.id)
                    except Exception:
                        pass

    def test_diff_identical_branches(
        self, client: Client, temp_repo: Repository, default_branch_id: str
    ) -> None:
        feature = client.branches.create(temp_repo.id, name="feature-diff-identical")
        try:
            diff = client.branches.diff(
                temp_repo.id, feature.id, target_branch_id=default_branch_id
            )
            assert isinstance(diff, BranchDiff)
            assert diff.diverged is False
            assert diff.source_ahead == 0
            assert diff.target_ahead == 0
            assert diff.can_fast_forward is False
        finally:
            try:
                client.branches.delete(temp_repo.id, feature.id)
            except Exception:
                pass

    def test_diff_diverged_branches(
        self, client: Client, temp_repo: Repository, default_branch_id: str
    ) -> None:
        # Need EVC repo with concrete Folder class for node creation
        folder_schema = {
            "classes": [
                {
                    "@type": "Class",
                    "@id": "Folder",
                    "@inherits": "Node",
                    "@metadata": {
                        "node_type_key": "FLD",
                        "displayname": {"singular": "Folder", "plural": "Folders"},
                        "NodeOptions": {"type": "structure"},
                        "ui": {"icon": {"name": "mdi:folder", "color": "#FFB300"}},
                    },
                }
            ]
        }
        evc_repo = client.repositories.create(
            name=f"sdk-test-branch-evc-{uuid.uuid4()}",
            repo_type_key="EVC",
            description="SDK branch diff diverged test repo",
        )
        try:
            evc_page = client.branches.list(evc_repo.id)
            evc_main_id = evc_page.data[0].id
            client.schemas.update(
                evc_repo.id, evc_main_id, schema_data=folder_schema, commit_msg="Add Folder class"
            )
            feature = client.branches.create(evc_repo.id, name="feature-diff-diverged")
            try:
                # Add a Folder node on the feature branch to create divergence
                client.nodes.create(
                    evc_repo.id,
                    feature.id,
                    node_data={
                        "@type": "Folder",
                        "doc_string": "diff test node",
                    },
                )
                diff = client.branches.diff(
                    evc_repo.id, feature.id, target_branch_id=evc_main_id
                )
                assert isinstance(diff, BranchDiff)
                assert diff.source_ahead >= 1
            finally:
                try:
                    client.branches.delete(evc_repo.id, feature.id)
                except Exception:
                    pass
        finally:
            try:
                client.repositories.delete(evc_repo.id)
            except Exception:
                pass

    def test_list_branches_pagination(self, client: Client, temp_repo: Repository) -> None:
        branches = []
        try:
            for i in range(3):
                b = client.branches.create(temp_repo.id, name=f"feature-page-{i}")
                branches.append(b)

            page = client.branches.list(temp_repo.id, page_size=1)
            assert page.page == 1
            assert page.page_size == 1
            # total_count should be at least 4 (main + 3 created)
            assert page.total_count >= 4
            assert page.has_next_page
        finally:
            for b in branches:
                try:
                    client.branches.delete(temp_repo.id, b.id)
                except Exception:
                    pass
