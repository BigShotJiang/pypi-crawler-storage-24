from __future__ import annotations

import io
import uuid

import pytest

from py_forge import (
    Client,
    NotFoundError,
)
from py_forge.types.attachment import (
    AttachmentExists,
    AttachmentMetadata,
    AttachmentUrl,
    NodeMediaUpload,
)

pytestmark = pytest.mark.integration


@pytest.fixture
def temp_repo(client: Client):
    """Create a temporary repository for testing and delete it on teardown."""
    unique_name = f"sdk-test-attach-{uuid.uuid4()}"
    repo = client.repositories.create(
        name=unique_name,
        repo_type_key="TST",
        description="SDK attachment integration test repo",
    )
    yield repo
    try:
        client.repositories.delete(repo.id)
    except Exception:
        pass


class TestAttachmentHappyPath:
    def test_upload_attachment(self, client: Client, temp_repo) -> None:
        """Upload a small test file and verify metadata."""
        content = b"test content for attachment upload"
        file_tuple = ("test-file.txt", io.BytesIO(content), "text/plain")
        result = client.attachments.upload(file=file_tuple, repo_id=temp_repo.id)

        assert isinstance(result, AttachmentMetadata)
        assert result.filename == "test-file.txt"
        assert result.mime_type == "text/plain"
        assert result.size_bytes > 0
        assert result.storage_path  # non-empty string

    def test_get_attachment_url(self, client: Client, temp_repo) -> None:
        """Upload a file, then get a signed download URL."""
        content = b"url test content"
        file_tuple = ("url-test.txt", io.BytesIO(content), "text/plain")
        uploaded = client.attachments.upload(file=file_tuple, repo_id=temp_repo.id)

        result = client.attachments.get_url(
            attachment_id=uploaded.storage_path,
        )

        assert isinstance(result, AttachmentUrl)
        assert result.download_url  # non-empty URL string
        assert result.expires_in_minutes > 0

    def test_check_attachment_exists(self, client: Client, temp_repo) -> None:
        """Upload a file, then check it exists."""
        content = b"exists test content"
        file_tuple = ("exists-test.txt", io.BytesIO(content), "text/plain")
        uploaded = client.attachments.upload(file=file_tuple, repo_id=temp_repo.id)

        result = client.attachments.exists(
            attachment_id=uploaded.storage_path,
        )

        assert isinstance(result, AttachmentExists)
        assert result.exists is True

    def test_upload_node_media(self, client: Client, temp_repo) -> None:
        """Upload an image-like file via node_media endpoint."""
        # Create a minimal PNG-like payload (just bytes with an image name)
        content = b"\x89PNG\r\n\x1a\n" + b"\x00" * 100  # minimal PNG header + padding
        file_tuple = ("test-image.png", io.BytesIO(content), "image/png")
        result = client.node_media.upload(file=file_tuple, repo_id=temp_repo.id)

        assert isinstance(result, NodeMediaUpload)
        assert result.storage_path  # non-empty
        assert result.filename == "test-image.png"
        assert result.mime_type == "image/png"
        assert result.size_bytes > 0


class TestAttachmentErrors:
    def test_get_url_nonexistent_attachment(self, client: Client) -> None:
        """Get URL for a non-existent attachment — should raise or return a pre-signed URL."""
        try:
            result = client.attachments.get_url(
                attachment_id="nonexistent/path/to/file.txt",
            )
            # Some storage backends return a pre-signed URL even for missing objects
            assert isinstance(result, AttachmentUrl)
        except NotFoundError as exc:
            assert exc.status_code == 404
            assert exc.message

    def test_check_nonexistent_attachment(self, client: Client) -> None:
        """Check existence of a non-existent attachment — should return exists=False."""
        result = client.attachments.exists(
            attachment_id="nonexistent/path/to/file.txt",
        )
        assert isinstance(result, AttachmentExists)
        assert result.exists is False


class TestAttachmentEdgeCases:
    def test_upload_different_mime_types(self, client: Client, temp_repo) -> None:
        """Upload files with different MIME types and verify they're set correctly."""
        # Upload a .txt file
        txt_content = b"plain text content"
        txt_file = ("test.txt", io.BytesIO(txt_content), "text/plain")
        txt_result = client.attachments.upload(file=txt_file, repo_id=temp_repo.id)

        assert isinstance(txt_result, AttachmentMetadata)
        assert txt_result.mime_type == "text/plain"
        assert txt_result.filename == "test.txt"

        # Upload a .png file
        png_content = b"\x89PNG\r\n\x1a\n" + b"\x00" * 50
        png_file = ("image.png", io.BytesIO(png_content), "image/png")
        png_result = client.attachments.upload(file=png_file, repo_id=temp_repo.id)

        assert isinstance(png_result, AttachmentMetadata)
        assert png_result.mime_type == "image/png"
        assert png_result.filename == "image.png"
