from __future__ import annotations

import pytest

from py_forge import Client, NotFoundError, PermissionDeniedError

pytestmark = pytest.mark.integration


class TestAdminHappyPath:
    def test_list_users(self, client: Client) -> None:
        with pytest.raises(PermissionDeniedError) as exc_info:
            client.admin.list_users()
        assert exc_info.value.status_code == 403
        assert exc_info.value.message


class TestAdminErrors:
    def test_set_superuser_nonexistent_user(self, client: Client) -> None:
        with pytest.raises(NotFoundError) as exc_info:
            client.admin.set_superuser("nonexistent-uid")
        assert exc_info.value.status_code == 404
        assert exc_info.value.message
