from __future__ import annotations

import uuid

import pytest

from py_forge import (
    BadRequestError,
    Client,
    NotFoundError,
    Repository,
)
from py_forge.types.commit import Commit, CommitHistory, CommitResponse, OperationResult

pytestmark = pytest.mark.integration


FOLDER_SCHEMA = {
    "classes": [
        {
            "@type": "Class",
            "@id": "Folder",
            "@inherits": "Node",
            "@metadata": {
                "node_type_key": "FLD",
                "displayname": {"singular": "Folder", "plural": "Folders"},
                "NodeOptions": {"type": "structure"},
                "ui": {"icon": {"name": "mdi:folder", "color": "#FFB300"}},
            },
        }
    ]
}


@pytest.fixture
def temp_repo(client: Client):
    """Create a temporary repository for testing and delete it on teardown."""
    unique_name = f"sdk-test-commit-{uuid.uuid4()}"
    repo = client.repositories.create(
        name=unique_name,
        repo_type_key="EVC",
        description="SDK commit integration test repo",
    )
    # Add concrete Folder class so we can create nodes
    page = client.branches.list(repo.id)
    default_bid = page.data[0].id
    client.schemas.update(repo.id, default_bid, schema_data=FOLDER_SCHEMA, commit_msg="Add Folder class")
    yield repo
    try:
        client.repositories.delete(repo.id)
    except Exception:
        pass


@pytest.fixture
def default_branch_id(client: Client, temp_repo: Repository) -> str:
    """Resolve the default (main) branch ID from the temp repo."""
    page = client.branches.list(temp_repo.id)
    for branch in page.data:
        if branch.is_default:
            return branch.id
    assert page.data, "Repository should have at least one branch"
    return page.data[0].id


def _make_node_data(suffix: str | None = None) -> dict:
    """Helper to create valid node data with unique @id."""
    tag = suffix or uuid.uuid4().hex[:8]
    return {
        "@type": "Folder",
        "doc_string": f"test node {tag}",
        "@id": f"Folder_test_{tag}",
    }


class TestCommitHappyPath:
    def test_create_commit_with_node_create_op(
        self, client: Client, temp_repo: Repository, default_branch_id: str
    ) -> None:
        node_data = _make_node_data()
        operations = [
            {
                "type": "node_create",
                "data": {"node_data": node_data},
            }
        ]
        result = client.commits.create(
            temp_repo.id,
            default_branch_id,
            message="Create test node via commit",
            operations=operations,
        )
        assert isinstance(result, CommitResponse)
        assert result.id is not None
        assert result.message == "Create test node via commit"
        assert result.created_at
        assert result.created_by
        assert result.operations_results is not None
        assert len(result.operations_results) == 1
        op_result = result.operations_results[0]
        assert isinstance(op_result, OperationResult)
        assert op_result.success is True
        assert op_result.entity_id

    def test_list_commit_history(
        self, client: Client, temp_repo: Repository, default_branch_id: str
    ) -> None:
        # Create a commit first
        client.commits.create(
            temp_repo.id,
            default_branch_id,
            message="History test commit",
            operations=[{"type": "node_create", "data": {"node_data": _make_node_data()}}],
        )
        history = client.commits.list_history(temp_repo.id, default_branch_id)
        assert isinstance(history, CommitHistory)
        assert history.total_count >= 1
        assert len(history.commits) >= 1
        commit = history.commits[0]
        assert isinstance(commit, Commit)
        assert commit.identifier
        assert commit.author
        assert commit.message
        assert commit.timestamp

    def test_commit_with_multiple_operations(
        self, client: Client, temp_repo: Repository, default_branch_id: str
    ) -> None:
        operations = [
            {"type": "node_create", "data": {"node_data": _make_node_data()}},
            {"type": "node_create", "data": {"node_data": _make_node_data()}},
        ]
        result = client.commits.create(
            temp_repo.id,
            default_branch_id,
            message="Multi-op commit",
            operations=operations,
        )
        assert isinstance(result, CommitResponse)
        assert result.operations_results is not None
        assert len(result.operations_results) == 2
        for op_result in result.operations_results:
            assert op_result.success is True
            assert op_result.entity_id


class TestCommitErrors:
    def test_commit_with_invalid_operation(
        self, client: Client, temp_repo: Repository, default_branch_id: str
    ) -> None:
        operations = [
            {
                "type": "node_update",
                "node_id": "Folder_nonexistent_node",
                "data": {"node_data": _make_node_data()},
            }
        ]
        # The API may either raise an error or return a CommitResponse with
        # a failed operation result, depending on the implementation.
        try:
            result = client.commits.create(
                temp_repo.id,
                default_branch_id,
                message="Invalid op commit",
                operations=operations,
            )
            # If we get a response, check the operation result
            assert result.operations_results is not None
            assert len(result.operations_results) >= 1
            op_result = result.operations_results[0]
            assert op_result.success is False
            assert op_result.error_message
        except BadRequestError as exc:
            # Also acceptable — the API rejected the entire commit
            assert exc.status_code == 400
            assert exc.message

    def test_commit_on_nonexistent_branch(
        self, client: Client, temp_repo: Repository
    ) -> None:
        with pytest.raises(NotFoundError) as exc_info:
            client.commits.create(
                temp_repo.id,
                "00000000-0000-0000-0000-000000000000",
                message="Should fail",
                operations=[{"type": "node_create", "data": {"node_data": _make_node_data()}}],
            )
        assert exc_info.value.status_code == 404
        assert exc_info.value.message


class TestCommitEdgeCases:
    def test_commit_with_node_delete_operation(
        self, client: Client, temp_repo: Repository, default_branch_id: str
    ) -> None:
        # Create a node via commit
        create_result = client.commits.create(
            temp_repo.id,
            default_branch_id,
            message="Create node for delete test",
            operations=[{"type": "node_create", "data": {"node_data": _make_node_data()}}],
        )
        assert create_result.operations_results
        entity_id = create_result.operations_results[0].entity_id
        assert entity_id

        # Delete the node via commit
        delete_result = client.commits.create(
            temp_repo.id,
            default_branch_id,
            message="Delete node via commit",
            operations=[{"type": "node_delete", "node_id": entity_id}],
        )
        assert isinstance(delete_result, CommitResponse)
        assert delete_result.operations_results is not None
        assert len(delete_result.operations_results) >= 1
        assert delete_result.operations_results[0].success is True

    def test_commit_with_schema_update_operation(
        self, client: Client, temp_repo: Repository, default_branch_id: str
    ) -> None:
        schema_data = {
            "classes": [
                {
                    "@type": "Class",
                    "@id": "CommitSchemaTestClass",
                    "@inherits": "Node",
                    "@metadata": {
                        "node_type_key": "CST",
                        "displayname": {"singular": "CommitSchemaTest", "plural": "CommitSchemaTests"},
                        "NodeOptions": {"type": "structure"},
                        "ui": {"icon": {"name": "mdi:test-tube", "color": "#4CAF50"}},
                    },
                }
            ]
        }
        operations = [{"type": "schema_update", "data": {"schema_data": schema_data}}]
        result = client.commits.create(
            temp_repo.id,
            default_branch_id,
            message="Schema update via commit",
            operations=operations,
        )
        assert isinstance(result, CommitResponse)
        assert result.operations_results is not None
        assert len(result.operations_results) >= 1

    def test_commit_history_pagination(
        self, client: Client, temp_repo: Repository, default_branch_id: str
    ) -> None:
        # Create 3 commits
        for i in range(3):
            client.commits.create(
                temp_repo.id,
                default_branch_id,
                message=f"Pagination test commit {i}",
                operations=[{"type": "node_create", "data": {"node_data": _make_node_data()}}],
            )
        # Fetch full history first to confirm commits exist
        full_history = client.commits.list_history(temp_repo.id, default_branch_id)
        assert isinstance(full_history, CommitHistory)
        assert full_history.total_count >= 3

        # Fetch with page_size=1 to test pagination
        history = client.commits.list_history(
            temp_repo.id, default_branch_id, page_size=1
        )
        assert isinstance(history, CommitHistory)
        assert len(history.commits) == 1

        # Fetch page 2
        history2 = client.commits.list_history(
            temp_repo.id, default_branch_id, start_offset=1, page_size=1
        )
        assert len(history2.commits) == 1
        assert history2.start_offset == 1

    def test_commit_with_client_ref_id(
        self, client: Client, temp_repo: Repository, default_branch_id: str
    ) -> None:
        ref_id = f"ref-{uuid.uuid4().hex[:8]}"
        operations = [
            {
                "type": "node_create",
                "data": {"node_data": _make_node_data()},
                "client_ref_id": ref_id,
            }
        ]
        result = client.commits.create(
            temp_repo.id,
            default_branch_id,
            message="Commit with client_ref_id",
            operations=operations,
        )
        assert isinstance(result, CommitResponse)
        assert result.operations_results is not None
        assert len(result.operations_results) == 1
        op_result = result.operations_results[0]
        assert op_result.client_ref_id == ref_id
