from __future__ import annotations

import uuid

import pytest

from py_forge import (
    Client,
    NotFoundError,
    Repository,
)
from py_forge.types.schema import SchemaResponse

pytestmark = pytest.mark.integration


@pytest.fixture
def temp_repo(client: Client):
    """Create a temporary repository for testing and delete it on teardown."""
    unique_name = f"sdk-test-schema-{uuid.uuid4()}"
    repo = client.repositories.create(
        name=unique_name,
        repo_type_key="EVC",
        description="SDK schema integration test repo",
    )
    yield repo
    try:
        client.repositories.delete(repo.id)
    except Exception:
        pass


@pytest.fixture
def default_branch_id(client: Client, temp_repo: Repository) -> str:
    """Resolve the default (main) branch ID from the temp repo."""
    page = client.branches.list(temp_repo.id)
    for branch in page.data:
        if branch.is_default:
            return branch.id
    assert page.data, "Repository should have at least one branch"
    return page.data[0].id


class TestSchemaHappyPath:
    def test_get_schema(
        self, client: Client, temp_repo: Repository, default_branch_id: str
    ) -> None:
        """Get schema on default branch."""
        schema = client.schemas.get(temp_repo.id, default_branch_id)
        assert isinstance(schema, SchemaResponse)
        assert schema.repository_id == temp_repo.id
        assert schema.branch_id == default_branch_id
        assert isinstance(schema.schema_data, dict)

    def test_update_schema(
        self, client: Client, temp_repo: Repository, default_branch_id: str
    ) -> None:
        """Update schema with a new class using classes array format."""
        sample_schema = {
            "classes": [
                {
                    "@type": "Class",
                    "@id": "TestUpdateClass",
                    "@inherits": "Node",
                    "@metadata": {
                        "node_type_key": "TUC",
                        "displayname": {"singular": "TestUpdate", "plural": "TestUpdates"},
                        "NodeOptions": {"type": "structure"},
                        "ui": {"icon": {"name": "mdi:test-tube", "color": "#4CAF50"}},
                    },
                }
            ]
        }
        result = client.schemas.update(
            temp_repo.id,
            default_branch_id,
            schema_data=sample_schema,
            commit_msg="SDK test: update schema",
        )
        assert isinstance(result, SchemaResponse)
        assert result.repository_id == temp_repo.id
        assert result.branch_id == default_branch_id
        assert isinstance(result.schema_data, dict)
        # Verify the class was actually added
        class_ids = [c["@id"] for c in result.schema_data.get("classes", [])]
        assert "TestUpdateClass" in class_ids

    def test_delete_schema(
        self, client: Client, temp_repo: Repository, default_branch_id: str
    ) -> None:
        """Update schema then delete it."""
        # First, add a schema class so there's something to delete
        sample_schema = {
            "classes": [
                {
                    "@type": "Class",
                    "@id": "TestDeleteClass",
                    "@inherits": "Node",
                    "@metadata": {
                        "node_type_key": "TDC",
                        "displayname": {"singular": "TestDelete", "plural": "TestDeletes"},
                        "NodeOptions": {"type": "structure"},
                        "ui": {"icon": {"name": "mdi:delete", "color": "#F44336"}},
                    },
                }
            ]
        }
        client.schemas.update(
            temp_repo.id,
            default_branch_id,
            schema_data=sample_schema,
        )
        # Now delete it — API returns SchemaResponse
        delete_schema = {
            "@type": "Class",
            "@id": "TestDeleteClass",
        }
        result = client.schemas.delete(
            temp_repo.id,
            default_branch_id,
            schema_data=delete_schema,
            force=True,
            commit_msg="SDK test: delete schema",
        )
        assert isinstance(result, SchemaResponse)


class TestSchemaErrors:
    def test_get_schema_nonexistent_branch(
        self, client: Client, temp_repo: Repository
    ) -> None:
        """Get schema on a nonexistent branch should raise an error."""
        with pytest.raises(NotFoundError) as exc_info:
            client.schemas.get(
                temp_repo.id, "00000000-0000-0000-0000-000000000000"
            )
        assert exc_info.value.status_code == 404
        assert exc_info.value.message


class TestSchemaEdgeCases:
    def test_update_schema_idempotent(
        self, client: Client, temp_repo: Repository, default_branch_id: str
    ) -> None:
        """Update schema twice with same data, verify both succeed."""
        sample_schema = {
            "classes": [
                {
                    "@type": "Class",
                    "@id": "IdempotentClass",
                    "@inherits": "Node",
                    "@metadata": {
                        "node_type_key": "IDM",
                        "displayname": {"singular": "Idempotent", "plural": "Idempotents"},
                        "NodeOptions": {"type": "structure"},
                        "ui": {"icon": {"name": "mdi:sync", "color": "#2196F3"}},
                    },
                }
            ]
        }
        result1 = client.schemas.update(
            temp_repo.id,
            default_branch_id,
            schema_data=sample_schema,
        )
        assert isinstance(result1, SchemaResponse)

        result2 = client.schemas.update(
            temp_repo.id,
            default_branch_id,
            schema_data=sample_schema,
        )
        assert isinstance(result2, SchemaResponse)

    def test_schema_roundtrip(
        self, client: Client, temp_repo: Repository, default_branch_id: str
    ) -> None:
        """Update with a new class, get it back, verify it appears."""
        schema_data = {
            "classes": [
                {
                    "@type": "Class",
                    "@id": "RoundtripClass",
                    "@inherits": "Node",
                    "@metadata": {
                        "node_type_key": "RTC",
                        "displayname": {"singular": "Roundtrip", "plural": "Roundtrips"},
                        "NodeOptions": {"type": "structure"},
                        "ui": {"icon": {"name": "mdi:rotate-right", "color": "#9C27B0"}},
                    },
                }
            ]
        }
        client.schemas.update(
            temp_repo.id,
            default_branch_id,
            schema_data=schema_data,
            commit_msg="SDK test: roundtrip schema",
        )

        fetched = client.schemas.get(temp_repo.id, default_branch_id)
        assert isinstance(fetched, SchemaResponse)
        assert isinstance(fetched.schema_data, dict)
        class_ids = [c["@id"] for c in fetched.schema_data.get("classes", [])]
        assert "RoundtripClass" in class_ids
