from __future__ import annotations

import os

import pytest

from py_forge import Client

FORGE_API_KEY = os.environ.get("FORGE_API_KEY", "")
if not FORGE_API_KEY:
    pytest.skip("FORGE_API_KEY not set", allow_module_level=True)

FORGE_BASE_URL = os.environ.get("FORGE_BASE_URL", "")
if not FORGE_BASE_URL:
    pytest.skip("FORGE_BASE_URL not set", allow_module_level=True)

_SKIP_SSL = "localhost" in FORGE_BASE_URL


@pytest.fixture(scope="session")
def client():
    c = Client(
        api_key=FORGE_API_KEY,
        base_url=FORGE_BASE_URL,
        verify=not _SKIP_SSL,
    )
    yield c
    c.close()
