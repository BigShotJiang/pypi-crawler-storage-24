from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from py_forge.pagination import SyncPage
from py_forge.types import Repository


class TestHasNextPage:
    def test_has_next_page_true(self):
        page = SyncPage(data=["a", "b", "c"], total_count=10, page=1, page_size=3)
        assert page.has_next_page is True

    def test_has_next_page_false(self):
        page = SyncPage(data=["a", "b", "c"], total_count=3, page=1, page_size=5)
        assert page.has_next_page is False

    def test_has_next_page_exact_boundary(self):
        page = SyncPage(data=["a", "b", "c"], total_count=6, page=2, page_size=3)
        assert page.has_next_page is False


class TestPageIteration:
    def test_empty_page(self):
        page = SyncPage(data=[], total_count=0, page=1, page_size=10)
        assert page.has_next_page is False
        assert list(page) == []

    def test_iter_single_page(self):
        page = SyncPage(data=["a", "b"], total_count=2, page=1, page_size=10)
        assert list(page) == ["a", "b"]

    def test_iter_multi_page(self):
        """Mock client to return page 2 when next_page is called."""
        mock_client = MagicMock()
        page2 = SyncPage(data=["c", "d"], total_count=4, page=2, page_size=2)
        mock_client._request.return_value = page2

        page1 = SyncPage(
            data=["a", "b"],
            total_count=4,
            page=1,
            page_size=2,
            client=mock_client,
            path="/test",
            cast_to=str,
        )

        result = list(page1)
        assert result == ["a", "b", "c", "d"]
        mock_client._request.assert_called_once()

    def test_next_page_raises_on_last(self):
        page = SyncPage(data=["a"], total_count=1, page=1, page_size=10)
        with pytest.raises(StopIteration):
            page.next_page()


class TestPageAttributes:
    def test_page_attributes(self):
        page = SyncPage(data=[1, 2], total_count=5, page=2, page_size=2)
        assert page.data == [1, 2]
        assert page.total_count == 5
        assert page.page == 2
        assert page.page_size == 2
        assert page.has_next_page is True

    def test_page_data_is_typed(self):
        """Verify page.data contains correctly typed model instances."""
        repo = Repository(
            id="r1",
            name="test",
            default_branch="main",
            repo_type_key="TST",
            created_at="2024-01-01",
        )
        page: SyncPage[Repository] = SyncPage(
            data=[repo],
            total_count=1,
            page=1,
            page_size=10,
        )
        assert isinstance(page.data, list)
        assert len(page.data) == 1
        assert isinstance(page.data[0], Repository)
        assert page.data[0].name == "test"
