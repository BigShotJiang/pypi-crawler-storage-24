from __future__ import annotations

from unittest.mock import patch

import httpx
import pytest
import respx

from py_forge import Client
from py_forge._exceptions import (
    AuthenticationError,
    BadRequestError,
    InternalServerError,
    NotFoundError,
)
from py_forge.types import User

BASE_URL = "http://test-host"

SUCCESS_ENVELOPE = {
    "success": True,
    "data": {
        "id": "user-1", "email": "test@example.com", "name": "Test",
        "is_superuser": False, "email_verified": True,
    },
    "error": None,
}


@pytest.fixture()
def client() -> Client:
    c = Client(api_key="test-key", base_url=BASE_URL, max_retries=2)
    yield c  # type: ignore[misc]
    c.close()


class TestRetryOnStatusCodes:
    @respx.mock
    @patch("py_forge._base_client.time.sleep")
    def test_retry_on_429_then_success(self, mock_sleep, client: Client) -> None:
        route = respx.get(f"{BASE_URL}/auth/me").mock(
            side_effect=[
                httpx.Response(429, json={"error": "rate limited"}),
                httpx.Response(200, json=SUCCESS_ENVELOPE),
            ]
        )
        user = client.auth.me()
        assert isinstance(user, User)
        assert user.id == "user-1"
        assert route.call_count == 2
        assert mock_sleep.call_count == 1

    @respx.mock
    @patch("py_forge._base_client.time.sleep")
    def test_retry_on_500_then_success(self, mock_sleep, client: Client) -> None:
        route = respx.get(f"{BASE_URL}/auth/me").mock(
            side_effect=[
                httpx.Response(500, json={"error": "internal"}),
                httpx.Response(200, json=SUCCESS_ENVELOPE),
            ]
        )
        user = client.auth.me()
        assert isinstance(user, User)
        assert route.call_count == 2

    @respx.mock
    @patch("py_forge._base_client.time.sleep")
    def test_retry_on_connection_error_then_success(self, mock_sleep, client: Client) -> None:
        route = respx.get(f"{BASE_URL}/auth/me").mock(
            side_effect=[
                httpx.ConnectError("connection refused"),
                httpx.Response(200, json=SUCCESS_ENVELOPE),
            ]
        )
        user = client.auth.me()
        assert isinstance(user, User)
        assert route.call_count == 2

    @respx.mock
    @patch("py_forge._base_client.time.sleep")
    def test_retry_exhausted_raises(self, mock_sleep, client: Client) -> None:
        route = respx.get(f"{BASE_URL}/auth/me").mock(
            side_effect=[
                httpx.Response(500, json={"error": "internal"}),
                httpx.Response(500, json={"error": "internal"}),
                httpx.Response(500, json={"error": "internal"}),
            ]
        )
        with pytest.raises(InternalServerError):
            client.auth.me()
        assert route.call_count == 3  # 1 initial + 2 retries

    @respx.mock
    @patch("py_forge._base_client.time.sleep")
    def test_retry_on_408(self, mock_sleep, client: Client) -> None:
        route = respx.get(f"{BASE_URL}/auth/me").mock(
            side_effect=[
                httpx.Response(408, json={"error": "request timeout"}),
                httpx.Response(200, json=SUCCESS_ENVELOPE),
            ]
        )
        user = client.auth.me()
        assert isinstance(user, User)
        assert route.call_count == 2

    @respx.mock
    @patch("py_forge._base_client.time.sleep")
    def test_retry_on_409(self, mock_sleep, client: Client) -> None:
        route = respx.get(f"{BASE_URL}/auth/me").mock(
            side_effect=[
                httpx.Response(409, json={"error": "conflict"}),
                httpx.Response(200, json=SUCCESS_ENVELOPE),
            ]
        )
        user = client.auth.me()
        assert isinstance(user, User)
        assert route.call_count == 2


class TestNoRetryOnClientErrors:
    @respx.mock
    def test_no_retry_on_400(self) -> None:
        client = Client(api_key="test-key", base_url=BASE_URL, max_retries=2)
        try:
            route = respx.get(f"{BASE_URL}/auth/me").mock(
                return_value=httpx.Response(400, json={"error": "bad request"})
            )
            with pytest.raises(BadRequestError):
                client.auth.me()
            assert route.call_count == 1
        finally:
            client.close()

    @respx.mock
    def test_no_retry_on_401(self) -> None:
        client = Client(api_key="test-key", base_url=BASE_URL, max_retries=2)
        try:
            route = respx.get(f"{BASE_URL}/auth/me").mock(
                return_value=httpx.Response(401, json={"detail": "unauthorized"})
            )
            with pytest.raises(AuthenticationError):
                client.auth.me()
            assert route.call_count == 1
        finally:
            client.close()

    @respx.mock
    def test_no_retry_on_404(self) -> None:
        client = Client(api_key="test-key", base_url=BASE_URL, max_retries=2)
        try:
            route = respx.get(f"{BASE_URL}/graph/repository/x").mock(
                return_value=httpx.Response(404, json={"detail": "not found"})
            )
            with pytest.raises(NotFoundError):
                client.repositories.get("x")
            assert route.call_count == 1
        finally:
            client.close()


class TestRetryBehavior:
    @respx.mock
    @patch("py_forge._base_client.time.sleep")
    def test_retry_respects_retry_after_header(self, mock_sleep, client: Client) -> None:
        route = respx.get(f"{BASE_URL}/auth/me").mock(
            side_effect=[
                httpx.Response(429, json={"error": "rate limited"}, headers={"Retry-After": "1"}),
                httpx.Response(200, json=SUCCESS_ENVELOPE),
            ]
        )
        user = client.auth.me()
        assert isinstance(user, User)
        assert route.call_count == 2
        # The sleep should have been called with the Retry-After value (1.0)
        mock_sleep.assert_called_once_with(1.0)

    @respx.mock
    def test_max_retries_zero(self) -> None:
        client = Client(api_key="test-key", base_url=BASE_URL, max_retries=0)
        try:
            route = respx.get(f"{BASE_URL}/auth/me").mock(
                return_value=httpx.Response(500, json={"error": "internal"})
            )
            with pytest.raises(InternalServerError):
                client.auth.me()
            assert route.call_count == 1
        finally:
            client.close()
