"""
Async usage — async mirror of the quickstart example.

Usage:
    export FORGE_API_KEY="your-api-key"
    python examples/async_usage.py
"""

import asyncio
from py_forge import AsyncClient

async def main():
    client = AsyncClient()
    repo = None

    try:
        # Create a repository
        repo = await client.repositories.create(
            name="async-example-repo",
            repo_type_key="TST",
            description="Created by async example",
        )
        print(f"Repository: {repo.id} ({repo.name})")

        # Create a branch
        branch = await client.branches.create(repo.id, name="async-branch")
        print(f"Branch: {branch.id} ({branch.name})")

        # Create a node
        node = await client.nodes.create(
            repo.id,
            branch.id,
            node_data={
                "@type": "Folder",
                "@id": "Folder_async",
                "doc_string": "Created asynchronously",
            },
        )
        print(f"Node: {node.id}")

        # List nodes with async pagination
        page = await client.nodes.list(repo.id, branch.id)
        async for n in page:
            print(f"  - {n.id}")

    finally:
        if repo:
            await client.repositories.delete(repo.id)
            print("Cleaned up repository")


if __name__ == "__main__":
    asyncio.run(main())
