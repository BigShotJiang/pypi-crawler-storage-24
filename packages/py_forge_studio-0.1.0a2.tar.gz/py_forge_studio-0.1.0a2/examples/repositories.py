"""
Repositories — full CRUD lifecycle.

Usage:
    export FORGE_API_KEY="your-api-key"
    python examples/repositories.py
"""

from py_forge import Client

def main():
    client = Client()
    repo = None

    try:
        # Create
        repo = client.repositories.create(
            name="example-repo",
            repo_type_key="TST",
            description="Demonstrating repository CRUD",
        )
        print(f"Created: {repo.id} — {repo.name}")

        # Read
        fetched = client.repositories.get(repo.id)
        print(f"Fetched: {fetched.name} (default branch: {fetched.default_branch})")

        # Update
        updated = client.repositories.update(
            repo.id,
            name="example-repo-renamed",
            description="Updated description",
        )
        print(f"Updated: {updated.name} — {updated.description}")

        # List
        page = client.repositories.list()
        print(f"Total repositories: {page.total_count}")
        for r in page.data:
            print(f"  - {r.name} ({r.id})")

    finally:
        # Delete
        if repo:
            result = client.repositories.delete(repo.id)
            print(f"Deleted: {result.deleted}")


if __name__ == "__main__":
    main()
