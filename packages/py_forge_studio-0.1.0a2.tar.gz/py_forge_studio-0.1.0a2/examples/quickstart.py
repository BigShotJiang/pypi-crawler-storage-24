"""
Quickstart — create a repo, branch, and node, then clean up.

Usage:
    export FORGE_API_KEY="your-api-key"
    python examples/quickstart.py
"""

from py_forge import Client

def main():
    client = Client()
    repo = None

    try:
        # Create a repository
        repo = client.repositories.create(
            name="quickstart-repo",
            repo_type_key="TST",
            description="Created by quickstart example",
        )
        print(f"Repository: {repo.id} ({repo.name})")

        # Create a branch
        branch = client.branches.create(repo.id, name="my-branch")
        print(f"Branch: {branch.id} ({branch.name})")

        # Create a node
        node = client.nodes.create(
            repo.id,
            branch.id,
            node_data={
                "@type": "Folder",
                "@id": "Folder_quickstart",
                "doc_string": "Hello from quickstart",
            },
        )
        print(f"Node: {node.id}")

        # Read it back
        fetched = client.nodes.get(repo.id, branch.id, node.id)
        print(f"Fetched node data: {fetched.node}")

    finally:
        if repo:
            client.repositories.delete(repo.id)
            print("Cleaned up repository")


if __name__ == "__main__":
    main()
