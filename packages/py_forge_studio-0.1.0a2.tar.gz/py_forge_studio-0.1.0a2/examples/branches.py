"""
Branches — CRUD operations and diff.

Usage:
    export FORGE_API_KEY="your-api-key"
    python examples/branches.py
"""

from py_forge import Client

def main():
    client = Client()
    repo = None

    try:
        repo = client.repositories.create(
            name="branches-example",
            repo_type_key="TST",
        )
        print(f"Repository: {repo.id}")

        # Create two branches
        branch_a = client.branches.create(repo.id, name="branch-a", description="First branch")
        branch_b = client.branches.create(repo.id, name="branch-b", description="Second branch")
        print(f"Created: {branch_a.name}, {branch_b.name}")

        # Get a single branch
        fetched = client.branches.get(repo.id, branch_a.id)
        print(f"Fetched: {fetched.name} (is_default: {fetched.is_default})")

        # Update
        updated = client.branches.update(
            repo.id, branch_a.id, description="Updated description"
        )
        print(f"Updated: {updated.name} — {updated.description}")

        # List all branches
        page = client.branches.list(repo.id)
        print(f"Total branches: {page.total_count}")
        for b in page.data:
            print(f"  - {b.name} ({b.id})")

        # Get branch head
        head = client.branches.get_head(repo.id, branch_a.id)
        print(f"Branch head: {head}")

        # Add a node to branch_a so there's something to diff
        client.nodes.create(
            repo.id,
            branch_a.id,
            node_data={"@type": "Folder", "@id": "Folder_diff", "doc_string": "For diff"},
        )

        # Diff between branches
        diff = client.branches.diff(
            repo.id, branch_a.id, target_branch_id=branch_b.id
        )
        print(f"Diff: {diff}")

        # Delete a branch
        client.branches.delete(repo.id, branch_b.id)
        print(f"Deleted {branch_b.name}")

    finally:
        if repo:
            client.repositories.delete(repo.id)
            print("Cleaned up repository")


if __name__ == "__main__":
    main()
