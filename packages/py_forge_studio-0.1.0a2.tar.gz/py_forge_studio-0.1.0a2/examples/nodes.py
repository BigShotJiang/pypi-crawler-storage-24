"""
Nodes — CRUD, history, and commit with batched operations.

Usage:
    export FORGE_API_KEY="your-api-key"
    python examples/nodes.py
"""

from py_forge import Client

def main():
    client = Client()
    repo = None

    try:
        repo = client.repositories.create(
            name="nodes-example",
            repo_type_key="TST",
        )
        branch = client.branches.create(repo.id, name="work")
        print(f"Repository: {repo.id}, Branch: {branch.id}")

        # Create a node directly
        node = client.nodes.create(
            repo.id,
            branch.id,
            node_data={
                "@type": "Folder",
                "@id": "Folder_1",
                "doc_string": "First folder",
            },
        )
        print(f"Created node: {node.id}")

        # Read it back
        fetched = client.nodes.get(repo.id, branch.id, node.id)
        print(f"Fetched: {fetched.node}")

        # Update the node
        updated = client.nodes.update(
            repo.id,
            branch.id,
            node.id,
            node_data={
                "@type": "Folder",
                "@id": "Folder_1",
                "doc_string": "Updated folder",
            },
        )
        print(f"Updated: {updated.node}")

        # List nodes
        page = client.nodes.list(repo.id, branch.id)
        print(f"Total nodes: {page.total_count}")
        for n in page.data:
            print(f"  - {n.id}")

        # Node history
        history = client.nodes.get_history(repo.id, branch.id, node.id)
        print(f"History: {history}")

        # Single commit with multiple operations (create, update, delete)
        commit = client.commits.create(
            repo.id,
            branch.id,
            message="Batch: create, update, and delete nodes",
            operations=[
                {
                    "type": "node_create",
                    "data": {
                        "node_data": {
                            "@type": "Folder",
                            "@id": "Folder_batch_1",
                            "doc_string": "Created in batch",
                        }
                    },
                },
                {
                    "type": "node_update",
                    "data": {
                        "node_id": node.id,
                        "node_data": {
                            "@type": "Folder",
                            "@id": "Folder_1",
                            "doc_string": "Updated in batch",
                        },
                    },
                },
                {
                    "type": "node_delete",
                    "data": {
                        "node_id": node.id,
                    },
                },
            ],
        )
        print(f"Commit: {commit.id} — {commit.message}")

    finally:
        if repo:
            client.repositories.delete(repo.id)
            print("Cleaned up repository")


if __name__ == "__main__":
    main()
