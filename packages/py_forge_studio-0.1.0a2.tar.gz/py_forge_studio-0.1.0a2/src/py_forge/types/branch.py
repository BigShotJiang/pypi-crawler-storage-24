from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel, ConfigDict


class Branch(BaseModel):
    model_config = ConfigDict(extra="allow")

    id: str
    name: str
    description: Optional[str] = None
    repository_id: str
    created_at: str
    is_default: bool


class BranchList(BaseModel):
    model_config = ConfigDict(extra="allow")

    branches: Optional[List[Branch]] = None
    total_count: int
    page: int = 1
    page_size: int = 50


class BranchHead(BaseModel):
    model_config = ConfigDict(extra="allow")

    head: Optional[str] = None


class BranchDiff(BaseModel):
    model_config = ConfigDict(extra="allow")

    diverged: bool
    common_ancestor: Optional[str] = None
    source_ahead: int = 0
    target_ahead: int = 0
    source_commits: Optional[List[str]] = None
    target_commits: Optional[List[str]] = None
    requires_rebase: bool
    can_fast_forward: bool
