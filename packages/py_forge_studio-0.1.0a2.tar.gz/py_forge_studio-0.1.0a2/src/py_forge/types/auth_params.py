from __future__ import annotations

from typing import Optional

from typing_extensions import Required, TypedDict


class LoginParams(TypedDict, total=False):
    email: Required[str]
    password: Required[str]


class RefreshParams(TypedDict, total=False):
    refresh_token: Required[str]


class ProfileUpdateParams(TypedDict, total=False):
    display_name: Optional[str]


class PasswordChangeParams(TypedDict, total=False):
    current_password: Required[str]
    new_password: Required[str]


class ApiKeyCreateParams(TypedDict, total=False):
    name: Required[str]
