from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, ConfigDict


class LoginResponse(BaseModel):
    model_config = ConfigDict(extra="allow")

    id_token: str
    refresh_token: str
    expires_in: int
    user_id: str
    email: Optional[str] = None


class User(BaseModel):
    model_config = ConfigDict(extra="allow")

    id: str
    email: Optional[str] = None
    name: Optional[str] = None
    is_superuser: bool = False
    email_verified: bool = False


class ApiKey(BaseModel):
    model_config = ConfigDict(extra="allow")

    id: str
    name: str
    key_prefix: str
    created_at: str
    is_active: bool


class ApiKeyCreated(BaseModel):
    model_config = ConfigDict(extra="allow")

    id: str
    name: str
    key_prefix: str
    api_key: str
    created_at: str


class PasswordChangeResponse(BaseModel):
    model_config = ConfigDict(extra="allow")

    id_token: str
    refresh_token: str
    message: str
