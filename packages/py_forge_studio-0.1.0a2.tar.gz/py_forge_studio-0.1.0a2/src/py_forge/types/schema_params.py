from __future__ import annotations

from typing import Any, Dict

from typing_extensions import Required, TypedDict


class SchemaUpdateParams(TypedDict, total=False):
    schema_data: Required[Dict[str, Any]]
