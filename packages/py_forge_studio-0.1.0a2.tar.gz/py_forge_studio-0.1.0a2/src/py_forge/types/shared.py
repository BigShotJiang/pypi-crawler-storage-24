from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class DeleteResponse(BaseModel):
    model_config = ConfigDict(extra="allow")

    deleted: bool


class MessageResponse(BaseModel):
    model_config = ConfigDict(extra="allow")

    message: str
