from __future__ import annotations

from typing import Optional

from typing_extensions import Required, TypedDict


class BranchCreateParams(TypedDict, total=False):
    name: Required[str]
    description: Optional[str]
    source_branch_id: Optional[str]


class BranchUpdateParams(TypedDict, total=False):
    name: Optional[str]
    description: Optional[str]
