from __future__ import annotations

from typing import Any, Dict, List, Optional

from typing_extensions import Required, TypedDict


class NodeCreateOperation(TypedDict, total=False):
    type: str
    data: Required[Dict[str, Any]]
    client_ref_id: Optional[str]


class NodeUpdateOperation(TypedDict, total=False):
    type: str
    node_id: Required[str]
    data: Required[Dict[str, Any]]
    client_ref_id: Optional[str]


class NodeDeleteOperation(TypedDict, total=False):
    type: str
    node_id: Required[str]


class SchemaUpdateOperation(TypedDict, total=False):
    type: str
    data: Required[Dict[str, Any]]


class CommitCreateParams(TypedDict, total=False):
    message: Required[str]
    operations: Optional[List[Any]]


class MergeParams(TypedDict, total=False):
    source_branch_id: Required[str]
    target_branch_id: Required[str]
    message: Required[str]


class RebaseParams(TypedDict, total=False):
    source_branch: Required[str]
    onto_branch: Optional[str]
    onto_commit: Optional[str]
    message: Optional[str]
