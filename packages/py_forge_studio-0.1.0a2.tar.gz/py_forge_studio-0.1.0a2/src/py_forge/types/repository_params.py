from __future__ import annotations

from typing import Optional

from typing_extensions import Required, TypedDict


class RepositoryCreateParams(TypedDict, total=False):
    name: Required[str]
    repo_type_key: Required[str]
    description: Optional[str]
    default_branch_name: Optional[str]


class RepositoryUpdateParams(TypedDict, total=False):
    name: Optional[str]
    description: Optional[str]
    default_branch_name: Optional[str]
    repo_type_key: Optional[str]
