from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel, ConfigDict


class Repository(BaseModel):
    model_config = ConfigDict(extra="allow")

    id: str
    name: str
    description: Optional[str] = None
    default_branch: str
    repo_type_key: str
    created_at: str
    branches: Optional[List[str]] = None


class RepositoryList(BaseModel):
    model_config = ConfigDict(extra="allow")

    repositories: Optional[List[Repository]] = None
    total_count: int
    page: int = 1
    page_size: int = 50
