from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class AttachmentMetadata(BaseModel):
    model_config = ConfigDict(extra="allow")

    filename: str
    mime_type: str
    size_bytes: int
    storage_path: str


class AttachmentUrl(BaseModel):
    model_config = ConfigDict(extra="allow")

    download_url: str
    expires_in_minutes: int


class AttachmentExists(BaseModel):
    model_config = ConfigDict(extra="allow")

    exists: bool
    id: str


class NodeMediaUpload(BaseModel):
    model_config = ConfigDict(extra="allow")

    storage_path: str
    filename: str
    mime_type: str
    size_bytes: int
