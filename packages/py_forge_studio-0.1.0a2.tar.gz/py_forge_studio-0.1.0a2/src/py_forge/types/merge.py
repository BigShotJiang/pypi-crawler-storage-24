from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel, ConfigDict


class MergeResponse(BaseModel):
    model_config = ConfigDict(extra="allow")

    success: bool
    merge_commit_id: Optional[str] = None
    message: str
    merged_at: Optional[str] = None


class RebaseReportEntry(BaseModel):
    model_config = ConfigDict(extra="allow")

    origin_commit: str
    applied_commits: Optional[List[str]] = None
    commit_type: str


class RebaseResponse(BaseModel):
    model_config = ConfigDict(extra="allow")

    success: bool
    forwarded_commits: Optional[List[str]] = None
    common_commit_id: Optional[str] = None
    rebase_report: Optional[List[RebaseReportEntry]] = None
    message: str
    rebased_at: Optional[str] = None
    error: Optional[str] = None
