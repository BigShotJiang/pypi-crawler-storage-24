from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict


class Node(BaseModel):
    model_config = ConfigDict(extra="allow")

    id: str
    repository_id: str
    branch_id: str
    node: Dict[str, Any]


class NodeList(BaseModel):
    model_config = ConfigDict(extra="allow")

    repository_id: str
    branch_id: str
    nodes: Optional[List[Dict[str, Any]]] = None
    total_count: int
    page: int = 1
    page_size: int = 50


class NodeHistory(BaseModel):
    model_config = ConfigDict(extra="allow")

    commits: List[Any]
    total_count: int
    start_offset: int = 0
