from __future__ import annotations

from typing import Any, Dict

from pydantic import BaseModel, ConfigDict


class SchemaResponse(BaseModel):
    model_config = ConfigDict(extra="allow")

    repository_id: str
    branch_id: str
    schema_data: Dict[str, Any]
