from __future__ import annotations

from typing import Any, Dict

from typing_extensions import Required, TypedDict


class NodeCreateParams(TypedDict, total=False):
    node_data: Required[Dict[str, Any]]


class NodeUpdateParams(TypedDict, total=False):
    node_data: Required[Dict[str, Any]]
