from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field


class Commit(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    type_: Optional[str] = Field(default="ValidCommit", alias="@type")
    identifier: str
    author: str
    message: str
    timestamp: str
    migration: Optional[List[Any]] = None


class CommitResponse(BaseModel):
    model_config = ConfigDict(extra="allow")

    id: Optional[str] = None
    message: str
    repository_id: str
    branch_id: str
    created_at: str
    created_by: str
    operations_results: Optional[List[OperationResult]] = None


class OperationResult(BaseModel):
    model_config = ConfigDict(extra="allow")

    operation_type: str
    success: bool
    entity_id: Optional[str] = None
    entity_data: Optional[Dict[str, Any]] = None
    error_message: Optional[str] = None
    client_ref_id: Optional[str] = None


class CommitHistory(BaseModel):
    model_config = ConfigDict(extra="allow")

    commits: List[Commit]
    total_count: int
    start_offset: int = 0


# Rebuild CommitResponse to resolve forward reference to OperationResult
CommitResponse.model_rebuild()
