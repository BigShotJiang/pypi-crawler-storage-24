from __future__ import annotations

from typing import Any, Optional

import httpx


class ForgeError(Exception):
    """Base exception for all Forge SDK errors."""


class APIError(ForgeError):
    """Base class for API-related errors."""

    message: str

    def __init__(self, message: str) -> None:
        self.message = message
        super().__init__(message)


class APIConnectionError(APIError):
    """Raised when the client cannot connect to the API."""

    def __init__(self, message: str = "Connection error", *, cause: Optional[Exception] = None) -> None:
        super().__init__(message)
        self.__cause__ = cause


class APITimeoutError(APIConnectionError):
    """Raised when a request times out."""

    def __init__(self, message: str = "Request timed out", *, cause: Optional[Exception] = None) -> None:
        super().__init__(message, cause=cause)


class APIStatusError(APIError):
    """Raised when the API returns a non-success status code."""

    status_code: int
    response: httpx.Response
    body: Any

    def __init__(self, message: str, *, status_code: int, response: httpx.Response, body: Any) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.response = response
        self.body = body


class BadRequestError(APIStatusError):
    """400 Bad Request."""


class AuthenticationError(APIStatusError):
    """401 Unauthorized."""


class PermissionDeniedError(APIStatusError):
    """403 Forbidden."""


class NotFoundError(APIStatusError):
    """404 Not Found."""


class ConflictError(APIStatusError):
    """409 Conflict."""


class UnprocessableEntityError(APIStatusError):
    """422 Unprocessable Entity."""


class RateLimitError(APIStatusError):
    """429 Too Many Requests."""


class InternalServerError(APIStatusError):
    """500+ Internal Server Error."""


_STATUS_CODE_MAP = {
    400: BadRequestError,
    401: AuthenticationError,
    403: PermissionDeniedError,
    404: NotFoundError,
    409: ConflictError,
    422: UnprocessableEntityError,
    429: RateLimitError,
}


def _make_status_error(response: httpx.Response, body: Any) -> APIStatusError:
    """Create the appropriate APIStatusError subclass for the given response."""
    status_code = response.status_code

    if isinstance(body, dict):
        message = body.get("error") or body.get("detail") or body.get("message") or str(body)
        if isinstance(message, list):
            message = str(message)
    else:
        message = str(body) if body else f"HTTP {status_code}"

    error_class = _STATUS_CODE_MAP.get(status_code)
    if error_class is None:
        if status_code >= 500:
            error_class = InternalServerError
        else:
            error_class = APIStatusError

    return error_class(message, status_code=status_code, response=response, body=body)
