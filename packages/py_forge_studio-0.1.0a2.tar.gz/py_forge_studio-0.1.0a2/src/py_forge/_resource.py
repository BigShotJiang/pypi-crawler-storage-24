from __future__ import annotations

from typing import Optional, Type, TypeVar

from ._base_client import AsyncAPIClient, SyncAPIClient
from ._types import Body, Headers, Query, RequestFiles

T = TypeVar("T")


class SyncAPIResource:
    _client: SyncAPIClient

    def __init__(self, client: SyncAPIClient) -> None:
        self._client = client

    def _get(
        self,
        path: str,
        *,
        query: Optional[Query] = None,
        headers: Optional[Headers] = None,
        cast_to: Type[T],
    ) -> T:
        return self._client._request("GET", path, query=query, headers=headers, cast_to=cast_to)

    def _post(
        self,
        path: str,
        *,
        body: Optional[Body] = None,
        query: Optional[Query] = None,
        headers: Optional[Headers] = None,
        files: Optional[RequestFiles] = None,
        cast_to: Type[T],
        no_auth: bool = False,
    ) -> T:
        return self._client._request(
            "POST", path, body=body, query=query, headers=headers, files=files, cast_to=cast_to, no_auth=no_auth
        )

    def _put(
        self,
        path: str,
        *,
        body: Optional[Body] = None,
        query: Optional[Query] = None,
        headers: Optional[Headers] = None,
        cast_to: Type[T],
    ) -> T:
        return self._client._request("PUT", path, body=body, query=query, headers=headers, cast_to=cast_to)

    def _patch(
        self,
        path: str,
        *,
        body: Optional[Body] = None,
        query: Optional[Query] = None,
        headers: Optional[Headers] = None,
        cast_to: Type[T],
    ) -> T:
        return self._client._request("PATCH", path, body=body, query=query, headers=headers, cast_to=cast_to)

    def _delete(
        self,
        path: str,
        *,
        body: Optional[Body] = None,
        query: Optional[Query] = None,
        headers: Optional[Headers] = None,
        cast_to: Type[T],
    ) -> T:
        return self._client._request("DELETE", path, body=body, query=query, headers=headers, cast_to=cast_to)


class AsyncAPIResource:
    _client: AsyncAPIClient

    def __init__(self, client: AsyncAPIClient) -> None:
        self._client = client

    async def _get(
        self,
        path: str,
        *,
        query: Optional[Query] = None,
        headers: Optional[Headers] = None,
        cast_to: Type[T],
    ) -> T:
        return await self._client._request("GET", path, query=query, headers=headers, cast_to=cast_to)

    async def _post(
        self,
        path: str,
        *,
        body: Optional[Body] = None,
        query: Optional[Query] = None,
        headers: Optional[Headers] = None,
        files: Optional[RequestFiles] = None,
        cast_to: Type[T],
        no_auth: bool = False,
    ) -> T:
        return await self._client._request(
            "POST", path, body=body, query=query, headers=headers, files=files, cast_to=cast_to, no_auth=no_auth
        )

    async def _put(
        self,
        path: str,
        *,
        body: Optional[Body] = None,
        query: Optional[Query] = None,
        headers: Optional[Headers] = None,
        cast_to: Type[T],
    ) -> T:
        return await self._client._request("PUT", path, body=body, query=query, headers=headers, cast_to=cast_to)

    async def _patch(
        self,
        path: str,
        *,
        body: Optional[Body] = None,
        query: Optional[Query] = None,
        headers: Optional[Headers] = None,
        cast_to: Type[T],
    ) -> T:
        return await self._client._request("PATCH", path, body=body, query=query, headers=headers, cast_to=cast_to)

    async def _delete(
        self,
        path: str,
        *,
        body: Optional[Body] = None,
        query: Optional[Query] = None,
        headers: Optional[Headers] = None,
        cast_to: Type[T],
    ) -> T:
        return await self._client._request("DELETE", path, body=body, query=query, headers=headers, cast_to=cast_to)
