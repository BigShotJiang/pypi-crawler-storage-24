from __future__ import annotations

import random
import time
from typing import Any, Dict, Optional, Type, TypeVar

import httpx

from ._constants import (
    DEFAULT_CONNECTION_LIMITS,
    DEFAULT_MAX_RETRIES,
    DEFAULT_TIMEOUT,
    INITIAL_RETRY_DELAY,
    MAX_RETRY_DELAY,
)
from ._exceptions import (
    APIConnectionError,
    APITimeoutError,
    _make_status_error,
)
from ._types import Body, Headers, HttpMethod, Query, RequestFiles
from ._utils import join_url, strip_none

T = TypeVar("T")

_RETRYABLE_STATUS_CODES = {408, 409, 429, 500, 502, 503, 504}


def _should_retry_status(status_code: int) -> bool:
    return status_code in _RETRYABLE_STATUS_CODES or status_code >= 500


class _BaseClient:
    _base_url: str
    _api_key: Optional[str]
    _timeout: httpx.Timeout
    _max_retries: int
    _verify: bool

    def __init__(
        self,
        *,
        base_url: str,
        api_key: Optional[str] = None,
        timeout: Optional[httpx.Timeout] = None,
        max_retries: int = DEFAULT_MAX_RETRIES,
        verify: bool = True,
    ) -> None:
        self._base_url = base_url
        self._api_key = api_key
        self._timeout = timeout or DEFAULT_TIMEOUT
        self._max_retries = max_retries
        self._verify = verify

    def _build_headers(self, *, extra_headers: Optional[Headers] = None, no_auth: bool = False) -> Dict[str, str]:
        headers: Dict[str, str] = {
            "Accept": "application/json",
        }
        if self._api_key and not no_auth:
            headers["Authorization"] = f"Bearer {self._api_key}"
        if extra_headers:
            headers.update(extra_headers)
        return headers

    def _build_url(self, path: str) -> str:
        return join_url(self._base_url, path)

    def _calculate_retry_delay(self, attempt: int, response: Optional[httpx.Response] = None) -> float:
        if response is not None:
            retry_after = response.headers.get("Retry-After")
            if retry_after is not None:
                try:
                    return float(retry_after)
                except (ValueError, TypeError):
                    pass

        delay = INITIAL_RETRY_DELAY * (2 ** attempt)
        delay = min(delay, MAX_RETRY_DELAY)
        jitter = random.random() * 0.25 * delay  # noqa: S311
        return delay + jitter

    @staticmethod
    def _process_response(response: httpx.Response, cast_to: Type[T]) -> T:
        if response.status_code >= 400:
            try:
                body = response.json()
            except Exception:
                body = response.text
            raise _make_status_error(response, body)

        try:
            data = response.json()
        except Exception:
            raise _make_status_error(response, response.text)

        # Handle detail errors (framework layer)
        if isinstance(data, dict) and "detail" in data:
            raise _make_status_error(response, data)

        # Handle envelope responses
        if isinstance(data, dict) and "success" in data:
            if not data["success"]:
                raise _make_status_error(response, data)
            # Unwrap data from envelope
            data = data.get("data", data)

        # Cast to target type
        if cast_to is dict or cast_to is Any:
            return data  # type: ignore[return-value]

        if hasattr(cast_to, "model_validate"):
            return cast_to.model_validate(data)  # type: ignore[union-attr,return-value]

        if isinstance(data, cast_to):  # type: ignore[arg-type]
            return data  # type: ignore[return-value]

        return cast_to(data)  # type: ignore[call-arg,return-value]


class SyncAPIClient(_BaseClient):
    _client: httpx.Client

    def __init__(
        self,
        *,
        base_url: str,
        api_key: Optional[str] = None,
        timeout: Optional[httpx.Timeout] = None,
        max_retries: int = DEFAULT_MAX_RETRIES,
        http_client: Optional[httpx.Client] = None,
        verify: bool = True,
    ) -> None:
        super().__init__(
            base_url=base_url,
            api_key=api_key,
            timeout=timeout,
            max_retries=max_retries,
            verify=verify,
        )
        if http_client is not None:
            self._client = http_client
        else:
            self._client = httpx.Client(
                timeout=self._timeout,
                limits=DEFAULT_CONNECTION_LIMITS,
                verify=verify,
            )

    def _request(
        self,
        method: HttpMethod,
        path: str,
        *,
        body: Optional[Body] = None,
        query: Optional[Query] = None,
        headers: Optional[Headers] = None,
        files: Optional[RequestFiles] = None,
        cast_to: Type[T],
        no_auth: bool = False,
    ) -> T:
        url = self._build_url(path)
        merged_headers = self._build_headers(extra_headers=headers, no_auth=no_auth)

        if body is not None:
            body = strip_none(body)
        if query is not None:
            query = strip_none(query)

        kwargs: Dict[str, Any] = {
            "method": method,
            "url": url,
            "headers": merged_headers,
        }

        if files is not None:
            kwargs["files"] = files
            if body is not None:
                kwargs["data"] = body
        elif body is not None:
            kwargs["headers"]["Content-Type"] = "application/json"
            kwargs["json"] = body

        if query:
            kwargs["params"] = query

        last_exc: Optional[Exception] = None
        for attempt in range(self._max_retries + 1):
            try:
                response = self._client.request(**kwargs)
            except httpx.TimeoutException as exc:
                last_exc = exc
                if attempt < self._max_retries:
                    time.sleep(self._calculate_retry_delay(attempt))
                    continue
                raise APITimeoutError(cause=exc) from exc
            except httpx.ConnectError as exc:
                last_exc = exc
                if attempt < self._max_retries:
                    time.sleep(self._calculate_retry_delay(attempt))
                    continue
                raise APIConnectionError(cause=exc) from exc

            if _should_retry_status(response.status_code) and attempt < self._max_retries:
                time.sleep(self._calculate_retry_delay(attempt, response))
                continue

            return self._process_response(response, cast_to)

        # Should not reach here, but just in case
        if last_exc is not None:
            if isinstance(last_exc, httpx.TimeoutException):
                raise APITimeoutError(cause=last_exc) from last_exc
            raise APIConnectionError(cause=last_exc) from last_exc
        raise APIConnectionError("Max retries exhausted")

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> SyncAPIClient:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


class AsyncAPIClient(_BaseClient):
    _client: httpx.AsyncClient

    def __init__(
        self,
        *,
        base_url: str,
        api_key: Optional[str] = None,
        timeout: Optional[httpx.Timeout] = None,
        max_retries: int = DEFAULT_MAX_RETRIES,
        http_client: Optional[httpx.AsyncClient] = None,
        verify: bool = True,
    ) -> None:
        super().__init__(
            base_url=base_url,
            api_key=api_key,
            timeout=timeout,
            max_retries=max_retries,
            verify=verify,
        )
        if http_client is not None:
            self._client = http_client
        else:
            self._client = httpx.AsyncClient(
                timeout=self._timeout,
                limits=DEFAULT_CONNECTION_LIMITS,
                verify=verify,
            )

    async def _request(
        self,
        method: HttpMethod,
        path: str,
        *,
        body: Optional[Body] = None,
        query: Optional[Query] = None,
        headers: Optional[Headers] = None,
        files: Optional[RequestFiles] = None,
        cast_to: Type[T],
        no_auth: bool = False,
    ) -> T:
        url = self._build_url(path)
        merged_headers = self._build_headers(extra_headers=headers, no_auth=no_auth)

        if body is not None:
            body = strip_none(body)
        if query is not None:
            query = strip_none(query)

        kwargs: Dict[str, Any] = {
            "method": method,
            "url": url,
            "headers": merged_headers,
        }

        if files is not None:
            kwargs["files"] = files
            if body is not None:
                kwargs["data"] = body
        elif body is not None:
            kwargs["headers"]["Content-Type"] = "application/json"
            kwargs["json"] = body

        if query:
            kwargs["params"] = query

        last_exc: Optional[Exception] = None
        for attempt in range(self._max_retries + 1):
            try:
                response = await self._client.request(**kwargs)
            except httpx.TimeoutException as exc:
                last_exc = exc
                if attempt < self._max_retries:
                    import asyncio
                    await asyncio.sleep(self._calculate_retry_delay(attempt))
                    continue
                raise APITimeoutError(cause=exc) from exc
            except httpx.ConnectError as exc:
                last_exc = exc
                if attempt < self._max_retries:
                    import asyncio
                    await asyncio.sleep(self._calculate_retry_delay(attempt))
                    continue
                raise APIConnectionError(cause=exc) from exc

            if _should_retry_status(response.status_code) and attempt < self._max_retries:
                import asyncio
                await asyncio.sleep(self._calculate_retry_delay(attempt, response))
                continue

            return self._process_response(response, cast_to)

        if last_exc is not None:
            if isinstance(last_exc, httpx.TimeoutException):
                raise APITimeoutError(cause=last_exc) from last_exc
            raise APIConnectionError(cause=last_exc) from last_exc
        raise APIConnectionError("Max retries exhausted")

    async def close(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> AsyncAPIClient:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()
