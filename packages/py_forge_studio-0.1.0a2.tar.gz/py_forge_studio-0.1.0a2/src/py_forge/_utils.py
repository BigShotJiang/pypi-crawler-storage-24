from __future__ import annotations

from typing import Any, Dict


def strip_none(d: Dict[str, Any]) -> Dict[str, Any]:
    """Recursively remove keys with None values from dicts."""
    result: Dict[str, Any] = {}
    for key, value in d.items():
        if value is None:
            continue
        if isinstance(value, dict):
            result[key] = strip_none(value)
        else:
            result[key] = value
    return result


def join_url(base: str, path: str) -> str:
    """Join base URL with path, handling trailing/leading slashes."""
    return base.rstrip("/") + "/" + path.lstrip("/")
