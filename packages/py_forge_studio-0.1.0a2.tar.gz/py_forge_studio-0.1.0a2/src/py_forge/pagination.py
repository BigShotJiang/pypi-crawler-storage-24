from __future__ import annotations

from typing import Any, Generic, Iterator, List, Optional, Type, TypeVar

from ._base_client import AsyncAPIClient, SyncAPIClient
from ._types import Query

T = TypeVar("T")


class SyncPage(Generic[T]):
    data: List[T]
    total_count: int
    page: int
    page_size: int

    _client: SyncAPIClient
    _path: str
    _params: Query
    _cast_to: Type[T]
    _list_model: Optional[Type[Any]]
    _data_key: Optional[str]

    def __init__(
        self,
        *,
        data: List[T],
        total_count: int,
        page: int,
        page_size: int,
        client: Optional[SyncAPIClient] = None,
        path: str = "",
        params: Optional[Query] = None,
        cast_to: Optional[Type[T]] = None,
        list_model: Optional[Type[Any]] = None,
        data_key: Optional[str] = None,
    ) -> None:
        self.data = data
        self.total_count = total_count
        self.page = page
        self.page_size = page_size
        self._client = client  # type: ignore[assignment]
        self._path = path
        self._params = params or {}
        self._cast_to = cast_to  # type: ignore[assignment]
        self._list_model = list_model
        self._data_key = data_key

    @property
    def has_next_page(self) -> bool:
        return self.page * self.page_size < self.total_count

    def next_page(self) -> SyncPage[T]:
        if not self.has_next_page:
            raise StopIteration("No more pages")
        next_params = {**self._params, "page": self.page + 1, "page_size": self.page_size}
        if self._list_model is not None and self._data_key is not None:
            raw = self._client._request(
                "GET",
                self._path,
                query=next_params,
                cast_to=self._list_model,
            )
            items = getattr(raw, self._data_key, None) or []
            return SyncPage(
                data=items,
                total_count=getattr(raw, "total_count", self.total_count),
                page=getattr(raw, "page", self.page + 1),
                page_size=getattr(raw, "page_size", self.page_size),
                client=self._client,
                path=self._path,
                params=next_params,
                cast_to=self._cast_to,
                list_model=self._list_model,
                data_key=self._data_key,
            )
        return self._client._request(
            "GET",
            self._path,
            query=next_params,
            cast_to=self._cast_to,  # type: ignore[arg-type]
        )

    def __iter__(self) -> Iterator[T]:
        page = self
        while True:
            yield from page.data
            if not page.has_next_page:
                break
            page = page.next_page()


class AsyncPage(Generic[T]):
    data: List[T]
    total_count: int
    page: int
    page_size: int

    _client: AsyncAPIClient
    _path: str
    _params: Query
    _cast_to: Type[T]
    _list_model: Optional[Type[Any]]
    _data_key: Optional[str]

    def __init__(
        self,
        *,
        data: List[T],
        total_count: int,
        page: int,
        page_size: int,
        client: Optional[AsyncAPIClient] = None,
        path: str = "",
        params: Optional[Query] = None,
        cast_to: Optional[Type[T]] = None,
        list_model: Optional[Type[Any]] = None,
        data_key: Optional[str] = None,
    ) -> None:
        self.data = data
        self.total_count = total_count
        self.page = page
        self.page_size = page_size
        self._client = client  # type: ignore[assignment]
        self._path = path
        self._params = params or {}
        self._cast_to = cast_to  # type: ignore[assignment]
        self._list_model = list_model
        self._data_key = data_key

    @property
    def has_next_page(self) -> bool:
        return self.page * self.page_size < self.total_count

    async def next_page(self) -> AsyncPage[T]:
        if not self.has_next_page:
            raise StopIteration("No more pages")
        next_params = {**self._params, "page": self.page + 1, "page_size": self.page_size}
        if self._list_model is not None and self._data_key is not None:
            raw = await self._client._request(
                "GET",
                self._path,
                query=next_params,
                cast_to=self._list_model,
            )
            items = getattr(raw, self._data_key, None) or []
            return AsyncPage(
                data=items,
                total_count=getattr(raw, "total_count", self.total_count),
                page=getattr(raw, "page", self.page + 1),
                page_size=getattr(raw, "page_size", self.page_size),
                client=self._client,
                path=self._path,
                params=next_params,
                cast_to=self._cast_to,
                list_model=self._list_model,
                data_key=self._data_key,
            )
        return await self._client._request(
            "GET",
            self._path,
            query=next_params,
            cast_to=self._cast_to,  # type: ignore[arg-type]
        )

    async def __aiter__(self):  # type: ignore[override]
        page = self
        while True:
            for item in page.data:
                yield item
            if not page.has_next_page:
                break
            page = await page.next_page()
