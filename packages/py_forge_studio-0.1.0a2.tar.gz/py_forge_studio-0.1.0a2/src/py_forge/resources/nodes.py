from __future__ import annotations

from typing import Any, Dict

from .._resource import AsyncAPIResource, SyncAPIResource
from ..pagination import AsyncPage, SyncPage
from ..types.node import Node, NodeHistory, NodeList
from ..types.shared import DeleteResponse


class Nodes(SyncAPIResource):
    """Manage nodes within branches."""

    def create(
        self,
        repo_id: str,
        branch_id: str,
        *,
        node_data: Dict[str, Any],
    ) -> Node:
        """Create a new node in a branch."""
        body = {"node_data": node_data}
        return self._post(
            f"/graph/repository/{repo_id}/branch/{branch_id}/node",
            body=body,
            cast_to=Node,
        )

    def list(
        self,
        repo_id: str,
        branch_id: str,
        *,
        page: int = 1,
        page_size: int = 50,
    ) -> SyncPage[Node]:
        """List all nodes in a branch with pagination."""
        path = f"/graph/repository/{repo_id}/branch/{branch_id}/node"
        query = {"page": page, "page_size": page_size}
        raw = self._get(path, query=query, cast_to=NodeList)
        # NodeList.nodes contains raw dicts, not Node objects
        # We wrap them as Node-like items for pagination
        nodes = []
        for n in raw.nodes or []:
            nodes.append(
                Node(
                    id=n.get("@id", ""),
                    repository_id=raw.repository_id,
                    branch_id=raw.branch_id,
                    node=n,
                )
            )
        return SyncPage(
            data=nodes,
            total_count=raw.total_count,
            page=raw.page,
            page_size=raw.page_size,
            client=self._client,
            path=path,
            params=query,
            cast_to=Node,  # type: ignore[arg-type]
            list_model=NodeList,
            data_key="nodes",
        )

    def get(self, repo_id: str, branch_id: str, node_id: str) -> Node:
        """Get a specific node by ID."""
        return self._get(
            f"/graph/repository/{repo_id}/branch/{branch_id}/node/{node_id}",
            cast_to=Node,
        )

    def update(
        self,
        repo_id: str,
        branch_id: str,
        node_id: str,
        *,
        node_data: Dict[str, Any],
    ) -> Node:
        """Update a node. Requires ALL node fields including @id, @type, and doc_string."""
        body = {"node_data": node_data}
        return self._put(
            f"/graph/repository/{repo_id}/branch/{branch_id}/node/{node_id}",
            body=body,
            cast_to=Node,
        )

    def delete(
        self,
        repo_id: str,
        branch_id: str,
        node_id: str,
        *,
        force: bool = False,
    ) -> DeleteResponse:
        """Delete a node."""
        query = {"force": force} if force else None
        return self._delete(
            f"/graph/repository/{repo_id}/branch/{branch_id}/node/{node_id}",
            query=query,
            cast_to=DeleteResponse,
        )

    def get_history(
        self,
        repo_id: str,
        branch_id: str,
        node_id: str,
        *,
        page: int = 1,
        page_size: int = 50,
    ) -> NodeHistory:
        """Get commit history for a specific node."""
        return self._get(
            f"/graph/repository/{repo_id}/branch/{branch_id}/node/{node_id}/history",
            query={"start": (page - 1) * page_size, "count": page_size},
            cast_to=NodeHistory,
        )


class AsyncNodes(AsyncAPIResource):
    """Manage nodes within branches."""

    async def create(
        self,
        repo_id: str,
        branch_id: str,
        *,
        node_data: Dict[str, Any],
    ) -> Node:
        """Create a new node in a branch."""
        body = {"node_data": node_data}
        return await self._post(
            f"/graph/repository/{repo_id}/branch/{branch_id}/node",
            body=body,
            cast_to=Node,
        )

    async def list(
        self,
        repo_id: str,
        branch_id: str,
        *,
        page: int = 1,
        page_size: int = 50,
    ) -> AsyncPage[Node]:
        """List all nodes in a branch with pagination."""
        path = f"/graph/repository/{repo_id}/branch/{branch_id}/node"
        query = {"page": page, "page_size": page_size}
        raw = await self._get(path, query=query, cast_to=NodeList)
        nodes = []
        for n in raw.nodes or []:
            nodes.append(
                Node(
                    id=n.get("@id", ""),
                    repository_id=raw.repository_id,
                    branch_id=raw.branch_id,
                    node=n,
                )
            )
        return AsyncPage(
            data=nodes,
            total_count=raw.total_count,
            page=raw.page,
            page_size=raw.page_size,
            client=self._client,
            path=path,
            params=query,
            cast_to=Node,  # type: ignore[arg-type]
            list_model=NodeList,
            data_key="nodes",
        )

    async def get(self, repo_id: str, branch_id: str, node_id: str) -> Node:
        """Get a specific node by ID."""
        return await self._get(
            f"/graph/repository/{repo_id}/branch/{branch_id}/node/{node_id}",
            cast_to=Node,
        )

    async def update(
        self,
        repo_id: str,
        branch_id: str,
        node_id: str,
        *,
        node_data: Dict[str, Any],
    ) -> Node:
        """Update a node. Requires ALL node fields including @id, @type, and doc_string."""
        body = {"node_data": node_data}
        return await self._put(
            f"/graph/repository/{repo_id}/branch/{branch_id}/node/{node_id}",
            body=body,
            cast_to=Node,
        )

    async def delete(
        self,
        repo_id: str,
        branch_id: str,
        node_id: str,
        *,
        force: bool = False,
    ) -> DeleteResponse:
        """Delete a node."""
        query = {"force": force} if force else None
        return await self._delete(
            f"/graph/repository/{repo_id}/branch/{branch_id}/node/{node_id}",
            query=query,
            cast_to=DeleteResponse,
        )

    async def get_history(
        self,
        repo_id: str,
        branch_id: str,
        node_id: str,
        *,
        page: int = 1,
        page_size: int = 50,
    ) -> NodeHistory:
        """Get commit history for a specific node."""
        return await self._get(
            f"/graph/repository/{repo_id}/branch/{branch_id}/node/{node_id}/history",
            query={"start": (page - 1) * page_size, "count": page_size},
            cast_to=NodeHistory,
        )
