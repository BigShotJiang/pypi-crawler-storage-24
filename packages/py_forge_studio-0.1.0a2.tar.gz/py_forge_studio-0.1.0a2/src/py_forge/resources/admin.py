from __future__ import annotations

from typing import List

from .._resource import AsyncAPIResource, SyncAPIResource
from ..types.auth import User
from ..types.shared import MessageResponse


class Admin(SyncAPIResource):
    """Admin user management. Requires superuser privileges."""

    def list_users(self, *, max_results: int = 100) -> List[User]:
        """List all users."""
        raw = self._get("/auth/admin/users", query={"max_results": max_results}, cast_to=dict)  # type: ignore[arg-type]
        if isinstance(raw, list):
            return [User.model_validate(item) for item in raw]
        return []

    def set_superuser(self, user_id: str, *, is_superuser: bool = True) -> MessageResponse:
        """Set or remove superuser status for a user."""
        return self._post(
            f"/auth/admin/users/{user_id}/superuser",
            query={"is_superuser": is_superuser},
            cast_to=MessageResponse,
        )


class AsyncAdmin(AsyncAPIResource):
    """Admin user management. Requires superuser privileges."""

    async def list_users(self, *, max_results: int = 100) -> List[User]:
        """List all users."""
        raw = await self._get("/auth/admin/users", query={"max_results": max_results}, cast_to=dict)  # type: ignore[arg-type]
        if isinstance(raw, list):
            return [User.model_validate(item) for item in raw]
        return []

    async def set_superuser(self, user_id: str, *, is_superuser: bool = True) -> MessageResponse:
        """Set or remove superuser status for a user."""
        return await self._post(
            f"/auth/admin/users/{user_id}/superuser",
            query={"is_superuser": is_superuser},
            cast_to=MessageResponse,
        )
