from __future__ import annotations

from .._resource import AsyncAPIResource, SyncAPIResource
from .._types import FileTypes
from ..types.attachment import NodeMediaUpload


class NodeMedia(SyncAPIResource):
    """Upload media for node rich-text fields."""

    def upload(self, *, file: FileTypes, repo_id: str) -> NodeMediaUpload:
        """Upload an image for use in node rich-text fields."""
        files = {"file": file}
        data = {"repo_id": repo_id}
        return self._post("/graph/node-media/upload", files=files, body=data, cast_to=NodeMediaUpload)


class AsyncNodeMedia(AsyncAPIResource):
    """Upload media for node rich-text fields."""

    async def upload(self, *, file: FileTypes, repo_id: str) -> NodeMediaUpload:
        """Upload an image for use in node rich-text fields."""
        files = {"file": file}
        data = {"repo_id": repo_id}
        return await self._post("/graph/node-media/upload", files=files, body=data, cast_to=NodeMediaUpload)
