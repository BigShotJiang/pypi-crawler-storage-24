from __future__ import annotations

from typing import Optional

from .._resource import AsyncAPIResource, SyncAPIResource
from ..pagination import AsyncPage, SyncPage
from ..types.merge import MergeResponse, RebaseResponse
from ..types.repository import Repository, RepositoryList
from ..types.shared import DeleteResponse


class Repositories(SyncAPIResource):
    """Manage repositories."""

    def create(
        self,
        *,
        name: str,
        repo_type_key: str,
        description: Optional[str] = None,
        default_branch_name: Optional[str] = None,
    ) -> Repository:
        """Create a new repository with a default branch."""
        body = {
            "name": name,
            "repo_type_key": repo_type_key,
            "description": description,
            "default_branch_name": default_branch_name,
        }
        return self._post("/graph/repository", body=body, cast_to=Repository)

    def list(self, *, page: int = 1, page_size: int = 50) -> SyncPage[Repository]:
        """List all repositories with pagination."""
        path = "/graph/repository"
        query = {"page": page, "page_size": page_size}
        raw = self._get(path, query=query, cast_to=RepositoryList)
        return SyncPage(
            data=raw.repositories or [],
            total_count=raw.total_count,
            page=raw.page,
            page_size=raw.page_size,
            client=self._client,
            path=path,
            params=query,
            cast_to=Repository,  # type: ignore[arg-type]
            list_model=RepositoryList,
            data_key="repositories",
        )

    def get(self, repo_id: str) -> Repository:
        """Get a specific repository by ID."""
        return self._get(f"/graph/repository/{repo_id}", cast_to=Repository)

    def update(
        self,
        repo_id: str,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
        default_branch_name: Optional[str] = None,
        repo_type_key: Optional[str] = None,
    ) -> Repository:
        """Update a repository's name, description, or default branch."""
        body = {
            "name": name,
            "description": description,
            "default_branch_name": default_branch_name,
            "repo_type_key": repo_type_key,
        }
        return self._put(f"/graph/repository/{repo_id}", body=body, cast_to=Repository)

    def delete(self, repo_id: str) -> DeleteResponse:
        """Delete a repository and all its branches, nodes, and commits."""
        return self._delete(f"/graph/repository/{repo_id}", cast_to=DeleteResponse)

    def merge(
        self,
        repo_id: str,
        *,
        source_branch_id: str,
        target_branch_id: str,
        message: str,
    ) -> MergeResponse:
        """Merge a source branch into a target branch."""
        body = {
            "source_branch_id": source_branch_id,
            "target_branch_id": target_branch_id,
            "message": message,
        }
        return self._post(f"/graph/repository/{repo_id}/merge", body=body, cast_to=MergeResponse)

    def rebase(
        self,
        repo_id: str,
        *,
        source_branch: str,
        onto_branch: Optional[str] = None,
        onto_commit: Optional[str] = None,
        message: Optional[str] = None,
    ) -> RebaseResponse:
        """Rebase a branch onto a target branch or commit."""
        body = {
            "source_branch": source_branch,
            "onto_branch": onto_branch,
            "onto_commit": onto_commit,
            "message": message,
        }
        return self._post(f"/graph/repository/{repo_id}/rebase", body=body, cast_to=RebaseResponse)


class AsyncRepositories(AsyncAPIResource):
    """Manage repositories."""

    async def create(
        self,
        *,
        name: str,
        repo_type_key: str,
        description: Optional[str] = None,
        default_branch_name: Optional[str] = None,
    ) -> Repository:
        """Create a new repository with a default branch."""
        body = {
            "name": name,
            "repo_type_key": repo_type_key,
            "description": description,
            "default_branch_name": default_branch_name,
        }
        return await self._post("/graph/repository", body=body, cast_to=Repository)

    async def list(self, *, page: int = 1, page_size: int = 50) -> AsyncPage[Repository]:
        """List all repositories with pagination."""
        path = "/graph/repository"
        query = {"page": page, "page_size": page_size}
        raw = await self._get(path, query=query, cast_to=RepositoryList)
        return AsyncPage(
            data=raw.repositories or [],
            total_count=raw.total_count,
            page=raw.page,
            page_size=raw.page_size,
            client=self._client,
            path=path,
            params=query,
            cast_to=Repository,  # type: ignore[arg-type]
            list_model=RepositoryList,
            data_key="repositories",
        )

    async def get(self, repo_id: str) -> Repository:
        """Get a specific repository by ID."""
        return await self._get(f"/graph/repository/{repo_id}", cast_to=Repository)

    async def update(
        self,
        repo_id: str,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
        default_branch_name: Optional[str] = None,
        repo_type_key: Optional[str] = None,
    ) -> Repository:
        """Update a repository's name, description, or default branch."""
        body = {
            "name": name,
            "description": description,
            "default_branch_name": default_branch_name,
            "repo_type_key": repo_type_key,
        }
        return await self._put(f"/graph/repository/{repo_id}", body=body, cast_to=Repository)

    async def delete(self, repo_id: str) -> DeleteResponse:
        """Delete a repository and all its branches, nodes, and commits."""
        return await self._delete(f"/graph/repository/{repo_id}", cast_to=DeleteResponse)

    async def merge(
        self,
        repo_id: str,
        *,
        source_branch_id: str,
        target_branch_id: str,
        message: str,
    ) -> MergeResponse:
        """Merge a source branch into a target branch."""
        body = {
            "source_branch_id": source_branch_id,
            "target_branch_id": target_branch_id,
            "message": message,
        }
        return await self._post(f"/graph/repository/{repo_id}/merge", body=body, cast_to=MergeResponse)

    async def rebase(
        self,
        repo_id: str,
        *,
        source_branch: str,
        onto_branch: Optional[str] = None,
        onto_commit: Optional[str] = None,
        message: Optional[str] = None,
    ) -> RebaseResponse:
        """Rebase a branch onto a target branch or commit."""
        body = {
            "source_branch": source_branch,
            "onto_branch": onto_branch,
            "onto_commit": onto_commit,
            "message": message,
        }
        return await self._post(f"/graph/repository/{repo_id}/rebase", body=body, cast_to=RebaseResponse)
