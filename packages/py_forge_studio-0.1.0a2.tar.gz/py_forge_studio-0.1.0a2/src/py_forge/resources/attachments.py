from __future__ import annotations

from typing import Any, Dict, Optional

from .._resource import AsyncAPIResource, SyncAPIResource
from .._types import FileTypes
from ..types.attachment import AttachmentExists, AttachmentMetadata, AttachmentUrl


class Attachments(SyncAPIResource):
    """Manage file attachments."""

    def upload(self, *, file: FileTypes, repo_id: str) -> AttachmentMetadata:
        """Upload a file attachment."""
        files = {"file": file}
        data = {"repo_id": repo_id}
        return self._post("/graph/attachment/upload", files=files, body=data, cast_to=AttachmentMetadata)

    def get_url(
        self,
        *,
        attachment_id: str,
        repo_id: Optional[str] = None,
        expiration_minutes: Optional[int] = None,
    ) -> AttachmentUrl:
        """Get a signed download URL for an attachment."""
        query: Dict[str, Any] = {"id": attachment_id}
        if expiration_minutes is not None:
            query["expiration_minutes"] = expiration_minutes
        return self._get("/graph/attachment/url", query=query, cast_to=AttachmentUrl)

    def exists(self, *, attachment_id: str, repo_id: Optional[str] = None) -> AttachmentExists:
        """Check if an attachment file exists in storage."""
        query = {"id": attachment_id}
        return self._get("/graph/attachment/exists", query=query, cast_to=AttachmentExists)


class AsyncAttachments(AsyncAPIResource):
    """Manage file attachments."""

    async def upload(self, *, file: FileTypes, repo_id: str) -> AttachmentMetadata:
        """Upload a file attachment."""
        files = {"file": file}
        data = {"repo_id": repo_id}
        return await self._post("/graph/attachment/upload", files=files, body=data, cast_to=AttachmentMetadata)

    async def get_url(
        self,
        *,
        attachment_id: str,
        repo_id: Optional[str] = None,
        expiration_minutes: Optional[int] = None,
    ) -> AttachmentUrl:
        """Get a signed download URL for an attachment."""
        query: Dict[str, Any] = {"id": attachment_id}
        if expiration_minutes is not None:
            query["expiration_minutes"] = expiration_minutes
        return await self._get("/graph/attachment/url", query=query, cast_to=AttachmentUrl)

    async def exists(self, *, attachment_id: str, repo_id: Optional[str] = None) -> AttachmentExists:
        """Check if an attachment file exists in storage."""
        query = {"id": attachment_id}
        return await self._get("/graph/attachment/exists", query=query, cast_to=AttachmentExists)
