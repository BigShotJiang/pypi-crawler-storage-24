from __future__ import annotations

from typing import Any, Dict, Optional

from .._resource import AsyncAPIResource, SyncAPIResource
from ..types.schema import SchemaResponse


class Schemas(SyncAPIResource):
    """Manage branch schemas."""

    def get(self, repo_id: str, branch_id: str) -> SchemaResponse:
        """Get the schema definition for a branch."""
        return self._get(
            f"/graph/repository/{repo_id}/branch/{branch_id}/schema",
            cast_to=SchemaResponse,
        )

    def update(
        self,
        repo_id: str,
        branch_id: str,
        *,
        schema_data: Dict[str, Any],
        commit_msg: Optional[str] = None,
    ) -> SchemaResponse:
        """Update the schema definition for a branch. Creates a commit."""
        body = {"schema_data": schema_data}
        query: Dict[str, Any] = {}
        if commit_msg is not None:
            query["commit_msg"] = commit_msg
        return self._put(
            f"/graph/repository/{repo_id}/branch/{branch_id}/schema",
            body=body,
            query=query or None,
            cast_to=SchemaResponse,
        )

    def delete(
        self,
        repo_id: str,
        branch_id: str,
        *,
        schema_data: Optional[Dict[str, Any]] = None,
        force: bool = False,
        commit_msg: Optional[str] = None,
    ) -> SchemaResponse:
        """Delete schema classes from a branch."""
        body: Dict[str, Any] = {"schema_data": schema_data or {}}
        query: Dict[str, Any] = {}
        if force:
            query["force"] = True
        if commit_msg is not None:
            query["commit_msg"] = commit_msg
        return self._delete(
            f"/graph/repository/{repo_id}/branch/{branch_id}/schema",
            body=body,
            query=query or None,
            cast_to=SchemaResponse,
        )


class AsyncSchemas(AsyncAPIResource):
    """Manage branch schemas."""

    async def get(self, repo_id: str, branch_id: str) -> SchemaResponse:
        """Get the schema definition for a branch."""
        return await self._get(
            f"/graph/repository/{repo_id}/branch/{branch_id}/schema",
            cast_to=SchemaResponse,
        )

    async def update(
        self,
        repo_id: str,
        branch_id: str,
        *,
        schema_data: Dict[str, Any],
        commit_msg: Optional[str] = None,
    ) -> SchemaResponse:
        """Update the schema definition for a branch. Creates a commit."""
        body = {"schema_data": schema_data}
        query: Dict[str, Any] = {}
        if commit_msg is not None:
            query["commit_msg"] = commit_msg
        return await self._put(
            f"/graph/repository/{repo_id}/branch/{branch_id}/schema",
            body=body,
            query=query or None,
            cast_to=SchemaResponse,
        )

    async def delete(
        self,
        repo_id: str,
        branch_id: str,
        *,
        schema_data: Optional[Dict[str, Any]] = None,
        force: bool = False,
        commit_msg: Optional[str] = None,
    ) -> SchemaResponse:
        """Delete schema classes from a branch."""
        body: Dict[str, Any] = {"schema_data": schema_data or {}}
        query: Dict[str, Any] = {}
        if force:
            query["force"] = True
        if commit_msg is not None:
            query["commit_msg"] = commit_msg
        return await self._delete(
            f"/graph/repository/{repo_id}/branch/{branch_id}/schema",
            body=body,
            query=query or None,
            cast_to=SchemaResponse,
        )
