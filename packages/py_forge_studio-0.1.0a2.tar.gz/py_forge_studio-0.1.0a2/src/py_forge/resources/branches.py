from __future__ import annotations

from typing import Optional

from .._resource import AsyncAPIResource, SyncAPIResource
from ..pagination import AsyncPage, SyncPage
from ..types.branch import Branch, BranchDiff, BranchHead, BranchList
from ..types.shared import DeleteResponse


class Branches(SyncAPIResource):
    """Manage branches within repositories."""

    def create(
        self,
        repo_id: str,
        *,
        name: str,
        description: Optional[str] = None,
        source_branch_id: Optional[str] = None,
    ) -> Branch:
        """Create a new branch in a repository."""
        body = {
            "name": name,
            "description": description,
            "source_branch_id": source_branch_id,
        }
        return self._post(f"/graph/repository/{repo_id}/branch", body=body, cast_to=Branch)

    def list(self, repo_id: str, *, page: int = 1, page_size: int = 50) -> SyncPage[Branch]:
        """List all branches in a repository with pagination."""
        path = f"/graph/repository/{repo_id}/branch"
        query = {"page": page, "page_size": page_size}
        raw = self._get(path, query=query, cast_to=BranchList)
        return SyncPage(
            data=raw.branches or [],
            total_count=raw.total_count,
            page=raw.page,
            page_size=raw.page_size,
            client=self._client,
            path=path,
            params=query,
            cast_to=Branch,  # type: ignore[arg-type]
            list_model=BranchList,
            data_key="branches",
        )

    def get(self, repo_id: str, branch_id: str) -> Branch:
        """Get a specific branch by ID."""
        return self._get(f"/graph/repository/{repo_id}/branch/{branch_id}", cast_to=Branch)

    def update(
        self,
        repo_id: str,
        branch_id: str,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
    ) -> Branch:
        """Update a branch's name or description."""
        body = {
            "name": name,
            "description": description,
        }
        return self._put(f"/graph/repository/{repo_id}/branch/{branch_id}", body=body, cast_to=Branch)

    def delete(self, repo_id: str, branch_id: str) -> DeleteResponse:
        """Delete a branch. Cannot delete the default branch."""
        return self._delete(f"/graph/repository/{repo_id}/branch/{branch_id}", cast_to=DeleteResponse)

    def get_head(self, repo_id: str, branch_id: str) -> BranchHead:
        """Get the head commit ID of a branch."""
        return self._get(f"/graph/repository/{repo_id}/branch/{branch_id}/head", cast_to=BranchHead)

    def diff(self, repo_id: str, branch_id: str, *, target_branch_id: str) -> BranchDiff:
        """Compare a source branch against a target branch."""
        return self._get(
            f"/graph/repository/{repo_id}/branch/{branch_id}/diff",
            query={"target": target_branch_id},
            cast_to=BranchDiff,
        )


class AsyncBranches(AsyncAPIResource):
    """Manage branches within repositories."""

    async def create(
        self,
        repo_id: str,
        *,
        name: str,
        description: Optional[str] = None,
        source_branch_id: Optional[str] = None,
    ) -> Branch:
        """Create a new branch in a repository."""
        body = {
            "name": name,
            "description": description,
            "source_branch_id": source_branch_id,
        }
        return await self._post(f"/graph/repository/{repo_id}/branch", body=body, cast_to=Branch)

    async def list(self, repo_id: str, *, page: int = 1, page_size: int = 50) -> AsyncPage[Branch]:
        """List all branches in a repository with pagination."""
        path = f"/graph/repository/{repo_id}/branch"
        query = {"page": page, "page_size": page_size}
        raw = await self._get(path, query=query, cast_to=BranchList)
        return AsyncPage(
            data=raw.branches or [],
            total_count=raw.total_count,
            page=raw.page,
            page_size=raw.page_size,
            client=self._client,
            path=path,
            params=query,
            cast_to=Branch,  # type: ignore[arg-type]
            list_model=BranchList,
            data_key="branches",
        )

    async def get(self, repo_id: str, branch_id: str) -> Branch:
        """Get a specific branch by ID."""
        return await self._get(f"/graph/repository/{repo_id}/branch/{branch_id}", cast_to=Branch)

    async def update(
        self,
        repo_id: str,
        branch_id: str,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
    ) -> Branch:
        """Update a branch's name or description."""
        body = {
            "name": name,
            "description": description,
        }
        return await self._put(f"/graph/repository/{repo_id}/branch/{branch_id}", body=body, cast_to=Branch)

    async def delete(self, repo_id: str, branch_id: str) -> DeleteResponse:
        """Delete a branch. Cannot delete the default branch."""
        return await self._delete(f"/graph/repository/{repo_id}/branch/{branch_id}", cast_to=DeleteResponse)

    async def get_head(self, repo_id: str, branch_id: str) -> BranchHead:
        """Get the head commit ID of a branch."""
        return await self._get(f"/graph/repository/{repo_id}/branch/{branch_id}/head", cast_to=BranchHead)

    async def diff(self, repo_id: str, branch_id: str, *, target_branch_id: str) -> BranchDiff:
        """Compare a source branch against a target branch."""
        return await self._get(
            f"/graph/repository/{repo_id}/branch/{branch_id}/diff",
            query={"target": target_branch_id},
            cast_to=BranchDiff,
        )
