from __future__ import annotations

from typing import List, Optional

from .._resource import AsyncAPIResource, SyncAPIResource
from ..types.auth import (
    ApiKey,
    ApiKeyCreated,
    LoginResponse,
    PasswordChangeResponse,
    User,
)
from ..types.shared import MessageResponse


class Auth(SyncAPIResource):
    """Authentication and user management."""

    def login(self, *, email: str, password: str) -> LoginResponse:
        """Authenticate with email and password."""
        body = {"email": email, "password": password}
        return self._post("/auth/login", body=body, cast_to=LoginResponse, no_auth=True)

    def refresh(self, *, refresh_token: str) -> LoginResponse:
        """Refresh an expired ID token."""
        body = {"refresh_token": refresh_token}
        return self._post("/auth/refresh", body=body, cast_to=LoginResponse, no_auth=True)

    def me(self) -> User:
        """Get the current authenticated user's information."""
        return self._get("/auth/me", cast_to=User)

    def update_profile(self, *, display_name: Optional[str] = None) -> User:
        """Update current user's profile."""
        body = {"display_name": display_name}
        return self._patch("/auth/me", body=body, cast_to=User)

    def change_password(self, *, current_password: str, new_password: str) -> PasswordChangeResponse:
        """Change current user's password."""
        body = {"current_password": current_password, "new_password": new_password}
        return self._post("/auth/me/password", body=body, cast_to=PasswordChangeResponse)

    def logout(self) -> MessageResponse:
        """Logout the current user."""
        return self._post("/auth/logout", cast_to=MessageResponse)

    def list_api_keys(self) -> List[ApiKey]:
        """List all active API keys for the current user."""
        raw = self._get("/auth/api-keys", cast_to=dict)  # type: ignore[arg-type]
        if isinstance(raw, list):
            return [ApiKey.model_validate(item) for item in raw]
        return []

    def create_api_key(self, *, name: str) -> ApiKeyCreated:
        """Create a new API key. The full key is returned only once."""
        body = {"name": name}
        return self._post("/auth/api-keys", body=body, cast_to=ApiKeyCreated)

    def revoke_api_key(self, key_id: str) -> MessageResponse:
        """Revoke an API key by ID."""
        return self._delete(f"/auth/api-keys/{key_id}", cast_to=MessageResponse)

    def get_public_user(self, user_id: str) -> User:
        """Get public user information by user ID."""
        return self._get(f"/auth/public/{user_id}", cast_to=User)

    def create_docs_session(self) -> MessageResponse:
        """Create an authenticated docs session."""
        return self._post("/auth/docs-session", cast_to=MessageResponse)


class AsyncAuth(AsyncAPIResource):
    """Authentication and user management."""

    async def login(self, *, email: str, password: str) -> LoginResponse:
        """Authenticate with email and password."""
        body = {"email": email, "password": password}
        return await self._post("/auth/login", body=body, cast_to=LoginResponse, no_auth=True)

    async def refresh(self, *, refresh_token: str) -> LoginResponse:
        """Refresh an expired ID token."""
        body = {"refresh_token": refresh_token}
        return await self._post("/auth/refresh", body=body, cast_to=LoginResponse, no_auth=True)

    async def me(self) -> User:
        """Get the current authenticated user's information."""
        return await self._get("/auth/me", cast_to=User)

    async def update_profile(self, *, display_name: Optional[str] = None) -> User:
        """Update current user's profile."""
        body = {"display_name": display_name}
        return await self._patch("/auth/me", body=body, cast_to=User)

    async def change_password(self, *, current_password: str, new_password: str) -> PasswordChangeResponse:
        """Change current user's password."""
        body = {"current_password": current_password, "new_password": new_password}
        return await self._post("/auth/me/password", body=body, cast_to=PasswordChangeResponse)

    async def logout(self) -> MessageResponse:
        """Logout the current user."""
        return await self._post("/auth/logout", cast_to=MessageResponse)

    async def list_api_keys(self) -> List[ApiKey]:
        """List all active API keys for the current user."""
        raw = await self._get("/auth/api-keys", cast_to=dict)  # type: ignore[arg-type]
        if isinstance(raw, list):
            return [ApiKey.model_validate(item) for item in raw]
        return []

    async def create_api_key(self, *, name: str) -> ApiKeyCreated:
        """Create a new API key. The full key is returned only once."""
        body = {"name": name}
        return await self._post("/auth/api-keys", body=body, cast_to=ApiKeyCreated)

    async def revoke_api_key(self, key_id: str) -> MessageResponse:
        """Revoke an API key by ID."""
        return await self._delete(f"/auth/api-keys/{key_id}", cast_to=MessageResponse)

    async def get_public_user(self, user_id: str) -> User:
        """Get public user information by user ID."""
        return await self._get(f"/auth/public/{user_id}", cast_to=User)

    async def create_docs_session(self) -> MessageResponse:
        """Create an authenticated docs session."""
        return await self._post("/auth/docs-session", cast_to=MessageResponse)
