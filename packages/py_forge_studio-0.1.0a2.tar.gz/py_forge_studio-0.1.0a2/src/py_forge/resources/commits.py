from __future__ import annotations

from typing import Any, Dict, List, Optional

from .._resource import AsyncAPIResource, SyncAPIResource
from ..types.commit import CommitHistory, CommitResponse


class Commits(SyncAPIResource):
    """Manage commits."""

    def create(
        self,
        repo_id: str,
        branch_id: str,
        *,
        message: str,
        operations: Optional[List[Dict[str, Any]]] = None,
    ) -> CommitResponse:
        """Create a new commit with one or more operations."""
        body: Dict[str, Any] = {"message": message}
        if operations is not None:
            body["operations"] = operations
        return self._post(
            f"/graph/repository/{repo_id}/branch/{branch_id}/commit",
            body=body,
            cast_to=CommitResponse,
        )

    def list_history(
        self,
        repo_id: str,
        branch_id: str,
        *,
        start_offset: int = 0,
        page_size: int = 50,
    ) -> CommitHistory:
        """Get commit history for a branch with optional pagination."""
        query: Dict[str, Any] = {"start": start_offset, "count": page_size}
        return self._get(
            f"/graph/repository/{repo_id}/branch/{branch_id}/commit",
            query=query,
            cast_to=CommitHistory,
        )


class AsyncCommits(AsyncAPIResource):
    """Manage commits."""

    async def create(
        self,
        repo_id: str,
        branch_id: str,
        *,
        message: str,
        operations: Optional[List[Dict[str, Any]]] = None,
    ) -> CommitResponse:
        """Create a new commit with one or more operations."""
        body: Dict[str, Any] = {"message": message}
        if operations is not None:
            body["operations"] = operations
        return await self._post(
            f"/graph/repository/{repo_id}/branch/{branch_id}/commit",
            body=body,
            cast_to=CommitResponse,
        )

    async def list_history(
        self,
        repo_id: str,
        branch_id: str,
        *,
        start_offset: int = 0,
        page_size: int = 50,
    ) -> CommitHistory:
        """Get commit history for a branch with optional pagination."""
        query: Dict[str, Any] = {"start": start_offset, "count": page_size}
        return await self._get(
            f"/graph/repository/{repo_id}/branch/{branch_id}/commit",
            query=query,
            cast_to=CommitHistory,
        )
