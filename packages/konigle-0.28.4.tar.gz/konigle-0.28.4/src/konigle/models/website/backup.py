"""
Backup models for the Konigle SDK.

This module provides models for website backups including creation
and resource representations.
"""

from datetime import datetime
from typing import Any, Dict, Literal, Optional

from pydantic import Field

from konigle.models.base import CreateModel, Resource

# Type aliases for backup fields
BackupType = Literal[
    "page", "folder", "blog", "product", "site_template", "site_foundation"
]
BackupStatus = Literal["in_progress", "completed", "failed"]
BackupTrigger = Literal[
    "manual", "auto_pre_edit", "auto_pre_publish", "scheduled", "auto"
]
BackupKind = Literal["transient", "durable"]


class Backup(Resource):
    """
    Backup resource model.
    """

    created_at: datetime = Field(
        ...,
        title="Created At",
        description="Creation timestamp.",
    )
    """Creation timestamp."""

    kind: BackupKind = Field(
        ...,
        title="Kind",
        description=(
            "Type of backup. Transient backups are created during editing "
            "flow/AI chat and normally restored during the same session. "
            "Durable backups are meant for long term storage and can be "
            "restored weeks or months later"
        ),
    )
    """Type of backup - transient or durable."""

    site: str = Field(
        ...,
        title="Site ID",
        description="ID of the site this backup belongs to",
    )
    """ID of the site this backup belongs to."""

    backup_type: BackupType = Field(
        ...,
        title="Backup Type",
        description="Type of resource being backed up",
    )
    """Type of resource being backed up."""

    target_id: Optional[str] = Field(
        ...,
        max_length=64,
        title="Target ID",
        description=(
            "Page ID, Blog ID, Folder ID, Product ID etc. NULL for "
            "site-level backups like site_foundation "
            "that aren't tied to a specific page or folder"
        ),
    )
    """ID of the target resource. NULL for site-level backups."""

    target_description: str = Field(
        default="",
        max_length=255,
        title="Target Description",
        description=(
            "Human readable description of the target. Can be used to "
            "store page name, pathname etc."
        ),
    )
    """Human readable description of the target."""

    description: str = Field(
        default="",
        max_length=255,
        title="Description",
        description=(
            "Optional user-provided description at backup time. Can be "
            "used to capture additional context, e.g. 'before major "
            "redesign' or 'before editing product description'"
        ),
    )
    """Optional user-provided description of the backup."""

    file_size_bytes: Optional[int] = Field(
        default=None,
        title="File Size",
        description=(
            "Size of the backup file in bytes. Can be null if the file "
            "hasn't been created yet"
        ),
    )
    """Size of the backup file in bytes."""

    status: BackupStatus = Field(
        ...,
        title="Status",
        description="Current status of the backup",
    )
    """Current status of the backup."""

    trigger: BackupTrigger = Field(
        ...,
        title="Trigger",
        description="What triggered the backup creation",
    )
    """What triggered the backup creation."""

    error_message: str = Field(
        default="",
        title="Error Message",
        description="Error message if status is FAILED",
    )
    """Error message if status is FAILED."""

    metadata: Dict[str, Any] = Field(
        default_factory=dict,
        title="Metadata",
        description=(
            "Additional metadata about the backup that might be useful "
            "for display, searching, or restoration logic"
        ),
    )
    """Additional metadata about the backup."""

    def __str__(self) -> str:
        return (
            f"Backup(id={self.id}, type={self.backup_type}, "
            f"status={self.status})"
        )


class BackupCreate(CreateModel):
    """
    Model for creating a new backup.

    Contains fields required for backup creation.
    """

    backup_type: BackupType = Field(
        ...,
        title="Backup Type",
        description="Type of resource being backed up",
    )
    """Type of resource being backed up."""

    target_id: Optional[str] = Field(
        default=None,
        max_length=64,
        title="Target ID",
        description=(
            "ID of the target resource (Page, Folder, Blog, Product). "
            "NULL for site-level backups like site_foundation or "
            "site_template"
        ),
    )
    """ID of the target resource. NULL for site-level backups."""

    description: str = Field(
        default="",
        max_length=255,
        title="Description",
        description=(
            "Optional user-provided description of the backup. Can be "
            "used to capture additional context"
        ),
    )
    """Optional user-provided description of the backup."""

    trigger: BackupTrigger = Field(
        ...,
        title="Trigger",
        description="What triggered the backup creation",
    )
    """What triggered the backup creation."""


__all__ = [
    "BackupType",
    "BackupStatus",
    "BackupTrigger",
    "BackupKind",
    "Backup",
    "BackupCreate",
]
