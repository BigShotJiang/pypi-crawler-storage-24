# toklog

> `htop` for your LLM spend.

Coming soon.
