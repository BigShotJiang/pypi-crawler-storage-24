"""toklog — htop for your LLM spend."""
__version__ = "0.0.1"
