# When a task is completed
- Do not execute tests or launch Python interpreters automatically unless the user explicitly asks; AGENTS says testing is handled manually by humans.
- Instead, report the relevant commands the human should run, typically `pytest` or a targeted test file.
- If changing runtime behavior or dependencies, check whether `README.md` and related docs need updates.
- Preserve the state/cache schema unless the task explicitly requires changing it.