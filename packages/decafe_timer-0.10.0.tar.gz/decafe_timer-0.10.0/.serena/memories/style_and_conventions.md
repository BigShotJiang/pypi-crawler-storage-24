# Style and conventions
- Code is small, functional, and split by responsibility: CLI normalization, duration parsing, rendering, and app/state logic are in separate modules.
- Python style uses type hints on public helpers and dataclasses for structured values (`CliRequest`, `BarStyle`).
- Naming is straightforward snake_case for functions/variables, UPPER_CASE for constants.
- Error handling favors returning `(result, error)` from CLI normalization and raising `ValueError` from duration parsing helpers.
- Rendering code isolates style-specific behavior behind a `BarStyle` dataclass and a `BAR_STYLES` registry.
- Keep persistence format backward compatible: `finish_at`, `mem_sec`, `last_saved_at`, plus optional render settings in the cache payload.
- README currently reflects the newer command model more accurately than older notes that describe only `--start` style cooldown behavior.