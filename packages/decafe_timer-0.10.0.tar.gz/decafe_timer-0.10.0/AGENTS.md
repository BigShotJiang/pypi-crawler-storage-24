# AGENTS

## Repository Overview
- Python package providing a CLI caffeine-clearance tracker; exposes the `decafe-timer` entry point defined in `pyproject.toml`.
- Current behavior is not the original `--start` countdown design. The CLI centers on `mem`, `intake`, `run`, `clear`, and `config`.
- Core logic lives in `src/decafe_timer/main.py`, which persists JSON state with `appdirs` (`timer_state.json` under the user cache dir) and renders a live updating ASCII/Unicode bar.
- `aichat/20251202.md` captures the original conversation/spec, but the current code has evolved beyond it. Treat the implementation and README as the source of truth when they differ from that note.

## How To Run
- Install deps (system Python 3.10+): `pip install -e .`
- Install dev deps: `pip install -e '.[dev]'`
- Show current status: `decafe-timer`
- Set memory scale: `decafe-timer mem 3h`
- Add intake: `decafe-timer intake 45m` or `decafe-timer +45m`
- Reuse the saved memory as the intake amount: `decafe-timer intake`
- Run the live updating display: `decafe-timer run`
- Show or persist UI settings: `decafe-timer config`, `decafe-timer config --bar-style blocks`, `decafe-timer config --layout one-line`
- Clear the active timer while preserving saved settings: `decafe-timer clear`

## Implementation Notes
- State payload uses `finish_at`, `mem_sec`, and `last_saved_at`. The loader still accepts the older `duration_sec` key for backward compatibility.
- Render settings are also stored in the same cache payload: `bar_style`, `one_line`, and `graph_only`.
- `clear_state()` removes the active timer but keeps persisted configuration when any saved settings exist.
- `run_timer_loop()` and `_run_live_loop()` print a single terminal line that updates once per second; snapshot rendering and live rendering are delegated to `src/decafe_timer/render.py`.
- Expiry messaging is plain terminal output (`Expired` plus a selected message), not Rich UI.

## Testing & Tooling
- Automated tests exist in `tests/test_cli.py` and `tests/test_render.py`.
- Development extras live under `.[dev]` and currently include `pytest`, `ruff`, and `pyright`.
- Humans handle testing manually in this repo. Describe relevant commands, but do not execute tests or start Python interpreters unless explicitly asked.

## Future Agent Tips
- Respect the cached state format if you extend features. Preserve `finish_at` and `mem_sec`, and keep support for older `duration_sec` data unless removal is intentional.
- UI behavior is split across `main.py` and `render.py`; bar-style work belongs in `render.py`, while persistence and command dispatch belong in `main.py`.
- Before adding new dependencies, update `pyproject.toml`, `README.md`, and `README-ja_JP.md`.
- Follow the current implementation for state persistence (uses `appdirs` user cache dir); do not relocate cache files to the project root unless explicitly requested.
- Use semantic commit messages (`feat: ...`, `fix: ...`, etc.) when committing changes.
- `README.md` is currently aligned with the implemented command model more closely than historical notes in this file or `aichat/20251202.md`.
