"""Fort Spy — Pixel-Level Video Encryption & Decryption"""

from setuptools import setup, find_packages
from pathlib import Path

long_description = Path("README.md").read_text(encoding="utf-8")

setup(
    name="fortspy",
    version="1.0.0",
    author="Fort Spy Contributors",
    description="Pixel-level AES video encryption with real-time GPU-accelerated decryption",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/your-username/fort-spy",
    project_urls={
        "Bug Tracker": "https://github.com/your-username/fort-spy/issues",
        "Documentation": "https://github.com/your-username/fort-spy#readme",
    },
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "numpy>=1.21.0",
        "opencv-python>=4.5.0",
        "cryptography>=41.0.0",
    ],
    extras_require={
        "gpu-opencl": ["pyopencl>=2022.1"],
        "gpu-cuda": ["cupy>=12.0.0"],
        "dev": [
            "pytest>=7.0",
            "pytest-cov>=4.0",
            "flake8>=6.0",
            "black>=23.0",
        ],
        "full": [
            "pyopencl>=2022.1",
            "cupy>=12.0.0",
            "pytest>=7.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "fortspy=fortspy.cli:main",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Multimedia :: Video",
        "Topic :: Security :: Cryptography",
    ],
    keywords="video encryption aes pixel decryption player gpu",
    license="MIT",
)
