"""
Fort Spy - Pixel-Level Video Encryption & Decryption Technology
================================================================

Fort Spy provides military-grade, pixel-level AES encryption for video frames
at the RGB level, with real-time GPU-accelerated decryption for seamless playback.

Modules:
    core.encryptor  - Video frame encryption engine
    core.decryptor  - Real-time frame decryption engine
    core.key_manager - Secure key generation & exchange
    player.fort_player - Dedicated video player with live decryption
    utils.gpu_accelerator - GPU/OpenCL acceleration utilities
"""

__version__ = "1.0.0"
__author__ = "Fort Spy Contributors"
__license__ = "MIT"

from fortspy.core.encryptor import FortSpyEncryptor
from fortspy.core.decryptor import FortSpyDecryptor
from fortspy.core.key_manager import KeyManager
from fortspy.player.fort_player import FortSpyPlayer

__all__ = [
    "FortSpyEncryptor",
    "FortSpyDecryptor",
    "KeyManager",
    "FortSpyPlayer",
]
