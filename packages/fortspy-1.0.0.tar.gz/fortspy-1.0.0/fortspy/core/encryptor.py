"""
Fort Spy Encryptor
==================
Pixel-level AES encryption engine for video frames.
Operates directly on RGB pixel data for maximum security.
"""

import os
import struct
import hashlib
import logging
from typing import Optional, Tuple, Generator
from pathlib import Path

import cv2
import numpy as np
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend

from fortspy.core.key_manager import KeyManager

logger = logging.getLogger("fortspy.encryptor")


class EncryptionHeader:
    """
    Binary header for encrypted .fortspy video files.

    Format (48 bytes):
        - Magic bytes: 8 bytes (FORTSPY1)
        - Version: 2 bytes (uint16)
        - Key size: 2 bytes (uint16, in bits)
        - Mode: 2 bytes (uint16, 0=CBC, 1=CTR, 2=GCM)
        - Width: 4 bytes (uint32)
        - Height: 4 bytes (uint32)
        - FPS numerator: 4 bytes (uint32)
        - FPS denominator: 4 bytes (uint32)
        - Total frames: 4 bytes (uint32)
        - IV: 16 bytes
        - HMAC of header: 32 bytes
    """

    MAGIC = b"FORTSPY1"
    FORMAT = "<8sHHH II II I 16s"
    HEADER_SIZE = struct.calcsize(FORMAT)  # 62 bytes without HMAC
    MODES = {"CBC": 0, "CTR": 1, "GCM": 2}
    MODE_NAMES = {v: k for k, v in MODES.items()}

    def __init__(
        self,
        width: int,
        height: int,
        fps: float,
        total_frames: int,
        iv: bytes,
        key_size: int = 256,
        mode: str = "CTR",
        version: int = 1,
    ):
        self.width = width
        self.height = height
        self.fps_num = int(fps * 1000)
        self.fps_den = 1000
        self.total_frames = total_frames
        self.iv = iv
        self.key_size = key_size
        self.mode = mode
        self.version = version

    def to_bytes(self, hmac_key: Optional[bytes] = None) -> bytes:
        """Serialize header to bytes with optional HMAC."""
        header_data = struct.pack(
            self.FORMAT,
            self.MAGIC,
            self.version,
            self.key_size,
            self.MODES[self.mode],
            self.width,
            self.height,
            self.fps_num,
            self.fps_den,
            self.total_frames,
            self.iv,
        )
        if hmac_key:
            km = KeyManager()
            mac = km.generate_hmac(hmac_key, header_data)
            return header_data + mac
        return header_data + b"\x00" * 32

    @classmethod
    def from_bytes(cls, data: bytes, hmac_key: Optional[bytes] = None) -> "EncryptionHeader":
        """Deserialize header from bytes."""
        header_data = data[: cls.HEADER_SIZE]
        stored_hmac = data[cls.HEADER_SIZE : cls.HEADER_SIZE + 32]

        fields = struct.unpack(cls.FORMAT, header_data)
        magic = fields[0]
        if magic != cls.MAGIC:
            raise ValueError("Invalid Fort Spy file: bad magic bytes")

        header = cls(
            width=fields[4],
            height=fields[5],
            fps=fields[7] and fields[6] / fields[7] or 30.0,
            total_frames=fields[8],
            iv=fields[9],
            key_size=fields[2],
            mode=cls.MODE_NAMES.get(fields[3], "CTR"),
            version=fields[1],
        )
        header.fps_num = fields[6]
        header.fps_den = fields[7]

        if hmac_key and stored_hmac != b"\x00" * 32:
            km = KeyManager()
            if not km.verify_hmac(hmac_key, header_data, stored_hmac):
                raise ValueError("Header HMAC verification failed — key mismatch or tampering")

        return header

    @property
    def total_header_size(self) -> int:
        return self.HEADER_SIZE + 32


class FortSpyEncryptor:
    """
    Pixel-level video frame encryptor using AES.

    Encrypts each video frame's raw RGB pixel data, producing
    a .fortspy encrypted video file with embedded metadata.

    Supports AES-CBC, AES-CTR, and AES-GCM modes.
    """

    def __init__(
        self,
        key: bytes,
        mode: str = "CTR",
        key_size: int = 256,
    ):
        """
        Initialize encryptor.

        Args:
            key: AES encryption key bytes.
            mode: Cipher mode — 'CBC', 'CTR', or 'GCM'.
            key_size: Key size in bits (128, 192, 256).
        """
        self.key = key
        self.mode = mode.upper()
        self.key_size = key_size
        self._km = KeyManager(key_size)

        if self.mode not in EncryptionHeader.MODES:
            raise ValueError(f"Unsupported mode: {self.mode}. Use CBC, CTR, or GCM.")
        if len(key) != KeyManager.SUPPORTED_KEY_SIZES.get(key_size, -1):
            raise ValueError(f"Key length {len(key)*8} bits doesn't match key_size {key_size}")

    def _create_cipher(self, iv: bytes, nonce_offset: int = 0):
        """Create an AES cipher instance for the given mode."""
        if self.mode == "CTR":
            # Use a per-frame nonce derived from base IV + frame offset
            ctr_nonce = int.from_bytes(iv, "big") + nonce_offset
            ctr_bytes = ctr_nonce.to_bytes(16, "big")
            return Cipher(algorithms.AES(self.key), modes.CTR(ctr_bytes), default_backend())
        elif self.mode == "CBC":
            return Cipher(algorithms.AES(self.key), modes.CBC(iv), default_backend())
        elif self.mode == "GCM":
            return Cipher(algorithms.AES(self.key), modes.GCM(iv[:12]), default_backend())

    def _pad(self, data: bytes) -> bytes:
        """PKCS7 padding for CBC mode."""
        pad_len = 16 - (len(data) % 16)
        return data + bytes([pad_len]) * pad_len

    def encrypt_frame(self, frame: np.ndarray, iv: bytes, frame_index: int = 0) -> bytes:
        """
        Encrypt a single video frame at the pixel level.

        Args:
            frame: BGR/RGB numpy array from OpenCV (H, W, 3).
            iv: Base initialization vector.
            frame_index: Frame number for CTR nonce derivation.

        Returns:
            Encrypted frame bytes with 4-byte length prefix.
        """
        # Flatten RGB pixels to raw bytes
        raw_pixels = frame.tobytes()

        cipher = self._create_cipher(iv, nonce_offset=frame_index)
        encryptor = cipher.encryptor()

        if self.mode == "CBC":
            raw_pixels = self._pad(raw_pixels)

        ciphertext = encryptor.update(raw_pixels) + encryptor.finalize()

        if self.mode == "GCM":
            # Append GCM authentication tag
            ciphertext += encryptor.tag

        # Prefix with frame data length (4 bytes, big-endian)
        return struct.pack(">I", len(ciphertext)) + ciphertext

    def encrypt_video(
        self,
        input_path: str,
        output_path: str,
        progress_callback=None,
    ) -> dict:
        """
        Encrypt an entire video file frame-by-frame.

        Args:
            input_path: Path to the source video (mp4, avi, mkv, etc.).
            output_path: Path for the encrypted .fortspy output file.
            progress_callback: Optional callable(current_frame, total_frames).

        Returns:
            Dictionary with encryption metadata.
        """
        cap = cv2.VideoCapture(input_path)
        if not cap.isOpened():
            raise IOError(f"Cannot open video: {input_path}")

        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

        iv = self._km.generate_iv()

        header = EncryptionHeader(
            width=width,
            height=height,
            fps=fps,
            total_frames=total_frames,
            iv=iv,
            key_size=self.key_size,
            mode=self.mode,
        )

        logger.info(
            f"Encrypting {input_path}: {width}x{height} @ {fps:.2f}fps, "
            f"{total_frames} frames, mode={self.mode}"
        )

        frame_checksums = []

        with open(output_path, "wb") as fout:
            # Write header with HMAC
            fout.write(header.to_bytes(hmac_key=self.key))

            frame_idx = 0
            while True:
                ret, frame = cap.read()
                if not ret:
                    break

                encrypted = self.encrypt_frame(frame, iv, frame_idx)
                fout.write(encrypted)

                # Track frame integrity
                frame_checksums.append(hashlib.md5(encrypted).hexdigest())

                frame_idx += 1
                if progress_callback:
                    progress_callback(frame_idx, total_frames)

                if frame_idx % 100 == 0:
                    logger.debug(f"Encrypted frame {frame_idx}/{total_frames}")

        cap.release()

        # Update total frames in header if it differed
        if frame_idx != total_frames:
            header.total_frames = frame_idx
            with open(output_path, "r+b") as fout:
                fout.seek(0)
                fout.write(header.to_bytes(hmac_key=self.key))

        metadata = {
            "input": input_path,
            "output": output_path,
            "width": width,
            "height": height,
            "fps": fps,
            "total_frames": frame_idx,
            "mode": self.mode,
            "key_size": self.key_size,
            "key_fingerprint": self._km.compute_key_fingerprint(self.key),
            "iv": iv.hex(),
        }
        logger.info(f"Encryption complete: {frame_idx} frames written to {output_path}")
        return metadata

    def encrypt_frame_stream(
        self, input_path: str, iv: Optional[bytes] = None
    ) -> Generator[Tuple[bytes, int], None, None]:
        """
        Generator that yields encrypted frames one at a time.
        Useful for streaming encryption pipelines.

        Yields:
            Tuple of (encrypted_frame_bytes, frame_index).
        """
        if iv is None:
            iv = self._km.generate_iv()

        cap = cv2.VideoCapture(input_path)
        if not cap.isOpened():
            raise IOError(f"Cannot open video: {input_path}")

        frame_idx = 0
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            encrypted = self.encrypt_frame(frame, iv, frame_idx)
            yield encrypted, frame_idx
            frame_idx += 1

        cap.release()
