"""
Fort Spy Decryptor
==================
Real-time pixel-level AES decryption engine for video frames.
Supports GPU acceleration via OpenCL/NumPy vectorization for low-latency playback.
"""

import struct
import logging
import time
from typing import Optional, Generator, Tuple

import cv2
import numpy as np
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend

from fortspy.core.encryptor import EncryptionHeader
from fortspy.core.key_manager import KeyManager
from fortspy.utils.gpu_accelerator import GPUAccelerator

logger = logging.getLogger("fortspy.decryptor")


class DecryptionStats:
    """Track real-time decryption performance metrics."""

    def __init__(self):
        self.frames_decrypted = 0
        self.total_decrypt_time = 0.0
        self.total_bytes = 0
        self.frame_times = []

    @property
    def avg_frame_time_ms(self) -> float:
        if not self.frame_times:
            return 0.0
        return (sum(self.frame_times) / len(self.frame_times)) * 1000

    @property
    def throughput_mbps(self) -> float:
        if self.total_decrypt_time == 0:
            return 0.0
        return (self.total_bytes / (1024 * 1024)) / self.total_decrypt_time

    @property
    def effective_fps(self) -> float:
        if self.total_decrypt_time == 0:
            return 0.0
        return self.frames_decrypted / self.total_decrypt_time

    def record(self, elapsed: float, data_size: int):
        self.frames_decrypted += 1
        self.total_decrypt_time += elapsed
        self.total_bytes += data_size
        self.frame_times.append(elapsed)
        # Keep a sliding window for recent stats
        if len(self.frame_times) > 300:
            self.frame_times = self.frame_times[-300:]

    def __repr__(self):
        return (
            f"DecryptionStats(frames={self.frames_decrypted}, "
            f"avg={self.avg_frame_time_ms:.2f}ms, "
            f"fps={self.effective_fps:.1f}, "
            f"throughput={self.throughput_mbps:.2f}MB/s)"
        )


class FortSpyDecryptor:
    """
    Real-time pixel-level video frame decryptor.

    Reads .fortspy encrypted files and decrypts frames on-the-fly,
    reconstructing original RGB pixel data for seamless playback.

    Features:
        - AES-CBC/CTR/GCM decryption
        - Per-frame nonce derivation (CTR mode)
        - GPU-accelerated pixel reconstruction
        - Frame buffering for smooth playback
        - Performance statistics tracking
    """

    def __init__(
        self,
        key: bytes,
        use_gpu: bool = True,
        buffer_size: int = 30,
    ):
        """
        Initialize decryptor.

        Args:
            key: AES decryption key bytes.
            use_gpu: Enable GPU acceleration if available.
            buffer_size: Number of frames to pre-decrypt for buffering.
        """
        self.key = key
        self.buffer_size = buffer_size
        self.stats = DecryptionStats()
        self._gpu = GPUAccelerator() if use_gpu else None
        self._header: Optional[EncryptionHeader] = None

    def _create_cipher(self, iv: bytes, mode: str, nonce_offset: int = 0, tag: bytes = None):
        """Create AES cipher for decryption."""
        if mode == "CTR":
            ctr_nonce = int.from_bytes(iv, "big") + nonce_offset
            ctr_bytes = ctr_nonce.to_bytes(16, "big")
            return Cipher(algorithms.AES(self.key), modes.CTR(ctr_bytes), default_backend())
        elif mode == "CBC":
            return Cipher(algorithms.AES(self.key), modes.CBC(iv), default_backend())
        elif mode == "GCM":
            return Cipher(
                algorithms.AES(self.key), modes.GCM(iv[:12], tag), default_backend()
            )

    def _unpad(self, data: bytes) -> bytes:
        """Remove PKCS7 padding."""
        pad_len = data[-1]
        if pad_len < 1 or pad_len > 16:
            return data
        if all(b == pad_len for b in data[-pad_len:]):
            return data[:-pad_len]
        return data

    def read_header(self, filepath: str) -> EncryptionHeader:
        """Read and validate the encryption header from a .fortspy file."""
        with open(filepath, "rb") as f:
            header_data = f.read(EncryptionHeader.HEADER_SIZE + 32)

        self._header = EncryptionHeader.from_bytes(header_data, hmac_key=self.key)
        logger.info(
            f"Header: {self._header.width}x{self._header.height}, "
            f"mode={self._header.mode}, frames={self._header.total_frames}"
        )
        return self._header

    def decrypt_frame(
        self,
        encrypted_data: bytes,
        iv: bytes,
        mode: str,
        frame_index: int,
        width: int,
        height: int,
    ) -> np.ndarray:
        """
        Decrypt a single encrypted frame back to a numpy pixel array.

        Args:
            encrypted_data: Raw ciphertext bytes for this frame.
            iv: Base initialization vector.
            mode: Encryption mode used.
            frame_index: Frame number for CTR nonce derivation.
            width: Frame width in pixels.
            height: Frame height in pixels.

        Returns:
            Numpy array of shape (height, width, 3) with uint8 BGR pixels.
        """
        t0 = time.perf_counter()

        tag = None
        if mode == "GCM":
            tag = encrypted_data[-16:]
            encrypted_data = encrypted_data[:-16]

        cipher = self._create_cipher(iv, mode, nonce_offset=frame_index, tag=tag)
        decryptor = cipher.decryptor()
        raw_pixels = decryptor.update(encrypted_data) + decryptor.finalize()

        if mode == "CBC":
            raw_pixels = self._unpad(raw_pixels)

        # Reconstruct frame from raw pixel bytes
        expected_size = height * width * 3
        raw_pixels = raw_pixels[:expected_size]  # Trim any padding bytes

        frame = np.frombuffer(raw_pixels, dtype=np.uint8).reshape((height, width, 3))

        # GPU-accelerated post-processing if available
        if self._gpu and self._gpu.available:
            frame = self._gpu.process_frame(frame)

        elapsed = time.perf_counter() - t0
        self.stats.record(elapsed, len(encrypted_data))

        return frame

    def decrypt_video_stream(
        self, filepath: str
    ) -> Generator[Tuple[np.ndarray, int], None, None]:
        """
        Generator that yields decrypted frames from a .fortspy file.

        Yields:
            Tuple of (frame_array, frame_index).
        """
        header = self.read_header(filepath)
        header_total_size = header.total_header_size

        with open(filepath, "rb") as f:
            f.seek(header_total_size)

            frame_idx = 0
            while True:
                # Read frame length prefix (4 bytes)
                len_data = f.read(4)
                if not len_data or len(len_data) < 4:
                    break

                frame_len = struct.unpack(">I", len_data)[0]
                encrypted_data = f.read(frame_len)
                if len(encrypted_data) < frame_len:
                    logger.warning(f"Truncated frame {frame_idx}, skipping")
                    break

                try:
                    frame = self.decrypt_frame(
                        encrypted_data,
                        header.iv,
                        header.mode,
                        frame_idx,
                        header.width,
                        header.height,
                    )
                    yield frame, frame_idx
                except Exception as e:
                    logger.error(f"Decryption failed at frame {frame_idx}: {e}")
                    # Yield a black frame on error to maintain sync
                    yield np.zeros((header.height, header.width, 3), dtype=np.uint8), frame_idx

                frame_idx += 1

    def decrypt_to_video(
        self,
        input_path: str,
        output_path: str,
        codec: str = "mp4v",
        progress_callback=None,
    ) -> dict:
        """
        Decrypt a .fortspy file and save as a standard video file.

        Args:
            input_path: Path to the .fortspy encrypted file.
            output_path: Path for the decrypted output video.
            codec: FourCC codec string (default mp4v).
            progress_callback: Optional callable(current_frame, total_frames).

        Returns:
            Dictionary with decryption metadata and performance stats.
        """
        header = self.read_header(input_path)
        fps = header.fps_num / header.fps_den if header.fps_den else 30.0

        fourcc = cv2.VideoWriter_fourcc(*codec)
        writer = cv2.VideoWriter(output_path, fourcc, fps, (header.width, header.height))

        if not writer.isOpened():
            raise IOError(f"Cannot open output video writer: {output_path}")

        logger.info(f"Decrypting to {output_path}: {header.width}x{header.height} @ {fps:.2f}fps")

        for frame, idx in self.decrypt_video_stream(input_path):
            writer.write(frame)
            if progress_callback:
                progress_callback(idx + 1, header.total_frames)
            if (idx + 1) % 100 == 0:
                logger.debug(f"Decrypted frame {idx + 1}/{header.total_frames}")

        writer.release()

        return {
            "input": input_path,
            "output": output_path,
            "total_frames": header.total_frames,
            "stats": str(self.stats),
            "avg_frame_time_ms": self.stats.avg_frame_time_ms,
            "effective_fps": self.stats.effective_fps,
            "throughput_mbps": self.stats.throughput_mbps,
        }

    def verify_key(self, filepath: str) -> bool:
        """
        Verify if the current key can decrypt the given file.

        Returns:
            True if the key appears valid (header HMAC passes).
        """
        try:
            self.read_header(filepath)
            return True
        except ValueError:
            return False
