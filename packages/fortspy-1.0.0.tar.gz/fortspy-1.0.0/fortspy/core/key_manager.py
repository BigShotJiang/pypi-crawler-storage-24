"""
Fort Spy Key Manager
====================
Handles secure key generation, derivation, storage, and exchange
using industry-standard cryptographic primitives.
"""

import os
import json
import hashlib
import hmac
import base64
import secrets
from typing import Optional, Tuple
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec, padding
from cryptography.hazmat.backends import default_backend


class KeyManager:
    """
    Manages encryption keys for Fort Spy.

    Supports:
        - AES-128/192/256 key generation
        - Password-based key derivation (PBKDF2)
        - ECDH key exchange for secure key sharing
        - Key serialization and secure storage
        - HMAC-based key verification
    """

    SUPPORTED_KEY_SIZES = {128: 16, 192: 24, 256: 32}

    def __init__(self, key_size: int = 256):
        """
        Initialize KeyManager.

        Args:
            key_size: AES key size in bits (128, 192, or 256).
        """
        if key_size not in self.SUPPORTED_KEY_SIZES:
            raise ValueError(f"Key size must be one of {list(self.SUPPORTED_KEY_SIZES.keys())}")
        self.key_size = key_size
        self.key_bytes = self.SUPPORTED_KEY_SIZES[key_size]
        self._private_key: Optional[ec.EllipticCurvePrivateKey] = None
        self._public_key: Optional[ec.EllipticCurvePublicKey] = None

    def generate_key(self) -> bytes:
        """Generate a cryptographically secure random AES key."""
        return secrets.token_bytes(self.key_bytes)

    def generate_iv(self) -> bytes:
        """Generate a random 16-byte IV for AES-CBC/CTR."""
        return secrets.token_bytes(16)

    def derive_key_from_password(
        self, password: str, salt: Optional[bytes] = None, iterations: int = 600_000
    ) -> Tuple[bytes, bytes]:
        """
        Derive an AES key from a password using PBKDF2-HMAC-SHA256.

        Args:
            password: User-provided password string.
            salt: Optional salt bytes; generated if not provided.
            iterations: PBKDF2 iteration count (default 600k per OWASP).

        Returns:
            Tuple of (derived_key, salt).
        """
        if salt is None:
            salt = os.urandom(32)
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=self.key_bytes,
            salt=salt,
            iterations=iterations,
            backend=default_backend(),
        )
        key = kdf.derive(password.encode("utf-8"))
        return key, salt

    def generate_ecdh_keypair(self) -> ec.EllipticCurvePublicKey:
        """
        Generate an ECDH keypair for secure key exchange.

        Returns:
            The public key to share with the peer.
        """
        self._private_key = ec.generate_private_key(ec.SECP384R1(), default_backend())
        self._public_key = self._private_key.public_key()
        return self._public_key

    def derive_shared_key(self, peer_public_key: ec.EllipticCurvePublicKey) -> bytes:
        """
        Derive a shared AES key from ECDH exchange.

        Args:
            peer_public_key: The other party's public key.

        Returns:
            Derived AES key bytes.
        """
        if self._private_key is None:
            raise RuntimeError("Must call generate_ecdh_keypair() first")
        shared_secret = self._private_key.exchange(ec.ECDH(), peer_public_key)
        derived_key = HKDF(
            algorithm=hashes.SHA256(),
            length=self.key_bytes,
            salt=None,
            info=b"fortspy-video-encryption-v1",
            backend=default_backend(),
        ).derive(shared_secret)
        return derived_key

    def export_public_key_pem(self) -> bytes:
        """Export the ECDH public key in PEM format."""
        if self._public_key is None:
            raise RuntimeError("No public key generated yet")
        return self._public_key.public_bytes(
            serialization.Encoding.PEM,
            serialization.PublicFormat.SubjectPublicKeyInfo,
        )

    def import_public_key_pem(self, pem_data: bytes) -> ec.EllipticCurvePublicKey:
        """Import a peer's public key from PEM format."""
        return serialization.load_pem_public_key(pem_data, default_backend())

    def compute_key_fingerprint(self, key: bytes) -> str:
        """Compute a SHA-256 fingerprint for key verification."""
        digest = hashlib.sha256(key).hexdigest()
        return ":".join(digest[i : i + 2] for i in range(0, 16, 2))

    def generate_hmac(self, key: bytes, data: bytes) -> bytes:
        """Generate HMAC-SHA256 for data integrity verification."""
        return hmac.new(key, data, hashlib.sha256).digest()

    def verify_hmac(self, key: bytes, data: bytes, expected_hmac: bytes) -> bool:
        """Verify HMAC-SHA256 tag."""
        computed = hmac.new(key, data, hashlib.sha256).digest()
        return hmac.compare_digest(computed, expected_hmac)

    def save_key_to_file(self, key: bytes, filepath: str, password: Optional[str] = None):
        """
        Save an encryption key to a .fortkey file.

        Args:
            key: The AES key bytes.
            filepath: Output file path.
            password: Optional password to protect the key file.
        """
        if password:
            # Encrypt the key with the password
            enc_key, salt = self.derive_key_from_password(password, iterations=600_000)
            from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
            iv = self.generate_iv()
            cipher = Cipher(algorithms.AES(enc_key), modes.GCM(iv), backend=default_backend())
            encryptor = cipher.encryptor()
            ct = encryptor.update(key) + encryptor.finalize()
            payload = {
                "version": 1,
                "protected": True,
                "salt": base64.b64encode(salt).decode(),
                "iv": base64.b64encode(iv).decode(),
                "ciphertext": base64.b64encode(ct).decode(),
                "tag": base64.b64encode(encryptor.tag).decode(),
                "key_size": self.key_size,
            }
        else:
            payload = {
                "version": 1,
                "protected": False,
                "key": base64.b64encode(key).decode(),
                "key_size": self.key_size,
            }

        with open(filepath, "w") as f:
            json.dump(payload, f, indent=2)

    def load_key_from_file(self, filepath: str, password: Optional[str] = None) -> bytes:
        """
        Load an encryption key from a .fortkey file.

        Args:
            filepath: Path to the key file.
            password: Password if the key file is protected.

        Returns:
            The AES key bytes.
        """
        with open(filepath, "r") as f:
            payload = json.load(f)

        if payload.get("protected"):
            if password is None:
                raise ValueError("Key file is password-protected; provide a password")
            salt = base64.b64decode(payload["salt"])
            iv = base64.b64decode(payload["iv"])
            ct = base64.b64decode(payload["ciphertext"])
            tag = base64.b64decode(payload["tag"])
            enc_key, _ = self.derive_key_from_password(password, salt=salt, iterations=600_000)
            from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
            cipher = Cipher(
                algorithms.AES(enc_key), modes.GCM(iv, tag), backend=default_backend()
            )
            decryptor = cipher.decryptor()
            return decryptor.update(ct) + decryptor.finalize()
        else:
            return base64.b64decode(payload["key"])

    @staticmethod
    def key_from_hex(hex_string: str) -> bytes:
        """Convert a hex string to key bytes."""
        return bytes.fromhex(hex_string.replace(":", "").replace(" ", ""))

    @staticmethod
    def key_to_hex(key: bytes) -> str:
        """Convert key bytes to a hex string."""
        return key.hex()
