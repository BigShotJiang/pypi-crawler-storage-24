"""
Fort Spy Player
================
Dedicated video player with real-time pixel-level decryption.
Supports seamless playback of .fortspy encrypted video files.

Features:
    - Real-time AES decryption during playback
    - Frame buffering for smooth viewing
    - Play/Pause/Seek controls
    - Performance overlay (FPS, decode time)
    - Secure key input dialog
    - Fullscreen support
    - GPU-accelerated rendering
"""

import sys
import time
import logging
import threading
import queue
from typing import Optional
from pathlib import Path

import cv2
import numpy as np

from fortspy.core.decryptor import FortSpyDecryptor, DecryptionStats
from fortspy.core.key_manager import KeyManager

logger = logging.getLogger("fortspy.player")

# Try to import tkinter for GUI dialogs
try:
    import tkinter as tk
    from tkinter import filedialog, simpledialog, messagebox
    HAS_TK = True
except ImportError:
    HAS_TK = False


class FrameBuffer:
    """Thread-safe frame buffer for smooth playback."""

    def __init__(self, max_size: int = 60):
        self._queue = queue.Queue(maxsize=max_size)
        self._stop = threading.Event()

    def put(self, frame: np.ndarray, frame_idx: int, timeout: float = 1.0) -> bool:
        try:
            self._queue.put((frame, frame_idx), timeout=timeout)
            return True
        except queue.Full:
            return False

    def get(self, timeout: float = 0.1) -> Optional[tuple]:
        try:
            return self._queue.get(timeout=timeout)
        except queue.Empty:
            return None

    def clear(self):
        while not self._queue.empty():
            try:
                self._queue.get_nowait()
            except queue.Empty:
                break

    @property
    def size(self) -> int:
        return self._queue.qsize()

    def stop(self):
        self._stop.set()

    @property
    def stopped(self) -> bool:
        return self._stop.is_set()


class FortSpyPlayer:
    """
    Dedicated Fort Spy video player with real-time decryption.

    Plays .fortspy encrypted video files by decrypting frames
    on-the-fly using a background thread and displaying them
    via OpenCV's highgui or a Tkinter-based GUI.

    Controls:
        Space  - Play/Pause
        Q/Esc  - Quit
        F      - Toggle fullscreen
        S      - Show/hide stats overlay
        Right  - Skip forward 5 seconds
        Left   - Skip backward 5 seconds
        +/-    - Adjust playback speed
    """

    WINDOW_NAME = "Fort Spy Player"

    def __init__(
        self,
        key: Optional[bytes] = None,
        use_gpu: bool = True,
        buffer_frames: int = 30,
        show_stats: bool = False,
    ):
        """
        Initialize Fort Spy Player.

        Args:
            key: AES decryption key. If None, user will be prompted.
            use_gpu: Enable GPU acceleration.
            buffer_frames: Number of frames to pre-decrypt.
            show_stats: Show performance overlay by default.
        """
        self.key = key
        self.use_gpu = use_gpu
        self.buffer_frames = buffer_frames
        self.show_stats = show_stats

        self._decryptor: Optional[FortSpyDecryptor] = None
        self._buffer: Optional[FrameBuffer] = None
        self._playing = False
        self._paused = False
        self._fullscreen = False
        self._speed = 1.0
        self._current_frame = 0
        self._total_frames = 0
        self._fps = 30.0

    def _prompt_key(self) -> bytes:
        """Prompt the user for a decryption key."""
        if HAS_TK:
            root = tk.Tk()
            root.withdraw()
            key_input = simpledialog.askstring(
                "Fort Spy Player",
                "Enter decryption key (hex):",
                show="*",
                parent=root,
            )
            root.destroy()
            if key_input:
                return KeyManager.key_from_hex(key_input)
            raise ValueError("No key provided")
        else:
            key_input = input("Enter decryption key (hex): ").strip()
            return KeyManager.key_from_hex(key_input)

    def _prompt_file(self) -> str:
        """Prompt the user to select a .fortspy file."""
        if HAS_TK:
            root = tk.Tk()
            root.withdraw()
            filepath = filedialog.askopenfilename(
                title="Open Fort Spy Encrypted Video",
                filetypes=[
                    ("Fort Spy Video", "*.fortspy"),
                    ("All Files", "*.*"),
                ],
                parent=root,
            )
            root.destroy()
            if filepath:
                return filepath
            raise ValueError("No file selected")
        else:
            filepath = input("Enter path to .fortspy file: ").strip()
            return filepath

    def _draw_stats_overlay(self, frame: np.ndarray, stats: DecryptionStats) -> np.ndarray:
        """Draw performance stats overlay on the frame."""
        overlay = frame.copy()
        h, w = overlay.shape[:2]

        # Semi-transparent background bar
        cv2.rectangle(overlay, (0, 0), (w, 80), (0, 0, 0), -1)
        frame = cv2.addWeighted(overlay, 0.6, frame, 0.4, 0)

        # Stats text
        font = cv2.FONT_HERSHEY_SIMPLEX
        color = (0, 255, 0)  # Green text
        lines = [
            f"Frame: {self._current_frame}/{self._total_frames}  |  "
            f"Decrypt: {stats.avg_frame_time_ms:.1f}ms  |  "
            f"FPS: {stats.effective_fps:.1f}  |  "
            f"Speed: {self._speed:.1f}x",
            f"Throughput: {stats.throughput_mbps:.2f} MB/s  |  "
            f"Buffer: {self._buffer.size if self._buffer else 0}  |  "
            f"{'PAUSED' if self._paused else 'PLAYING'}",
        ]
        for i, line in enumerate(lines):
            cv2.putText(frame, line, (10, 25 + i * 25), font, 0.5, color, 1, cv2.LINE_AA)

        return frame

    def _draw_progress_bar(self, frame: np.ndarray) -> np.ndarray:
        """Draw a playback progress bar at the bottom."""
        h, w = frame.shape[:2]
        bar_h = 4
        progress = self._current_frame / max(self._total_frames, 1)

        # Background bar
        cv2.rectangle(frame, (0, h - bar_h), (w, h), (60, 60, 60), -1)
        # Progress fill
        fill_w = int(w * progress)
        cv2.rectangle(frame, (0, h - bar_h), (fill_w, h), (0, 180, 255), -1)

        return frame

    def _decrypt_thread(self, filepath: str):
        """Background thread for pre-decrypting frames into the buffer."""
        try:
            for frame, idx in self._decryptor.decrypt_video_stream(filepath):
                if self._buffer.stopped:
                    break
                while self._paused and not self._buffer.stopped:
                    time.sleep(0.01)
                self._buffer.put(frame, idx)
        except Exception as e:
            logger.error(f"Decrypt thread error: {e}")
        finally:
            logger.info("Decrypt thread finished")

    def play(self, filepath: Optional[str] = None):
        """
        Play an encrypted .fortspy video file.

        Args:
            filepath: Path to .fortspy file. If None, a file dialog opens.
        """
        # Get file path
        if filepath is None:
            filepath = self._prompt_file()

        if not Path(filepath).exists():
            raise FileNotFoundError(f"File not found: {filepath}")

        # Get key
        if self.key is None:
            self.key = self._prompt_key()

        # Initialize decryptor
        self._decryptor = FortSpyDecryptor(
            key=self.key,
            use_gpu=self.use_gpu,
            buffer_size=self.buffer_frames,
        )

        # Verify key
        if not self._decryptor.verify_key(filepath):
            raise ValueError("Invalid decryption key for this file")

        header = self._decryptor.read_header(filepath)
        self._total_frames = header.total_frames
        self._fps = header.fps_num / header.fps_den if header.fps_den else 30.0

        logger.info(
            f"Playing: {filepath} ({header.width}x{header.height} "
            f"@ {self._fps:.1f}fps, {self._total_frames} frames)"
        )

        # Start frame buffer
        self._buffer = FrameBuffer(max_size=self.buffer_frames * 2)
        self._playing = True
        self._paused = False

        # Start background decryption thread
        decrypt_thread = threading.Thread(
            target=self._decrypt_thread, args=(filepath,), daemon=True
        )
        decrypt_thread.start()

        # Create display window
        cv2.namedWindow(self.WINDOW_NAME, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(self.WINDOW_NAME, header.width, header.height)

        frame_delay = 1.0 / self._fps
        last_frame_time = time.perf_counter()

        try:
            while self._playing:
                # Handle keyboard input
                key = cv2.waitKey(1) & 0xFF
                self._handle_key(key)

                if self._paused:
                    time.sleep(0.01)
                    continue

                # Timing control for correct playback speed
                now = time.perf_counter()
                elapsed = now - last_frame_time
                target_delay = frame_delay / self._speed

                if elapsed < target_delay:
                    time.sleep(target_delay - elapsed)

                # Get next frame from buffer
                result = self._buffer.get(timeout=0.5)
                if result is None:
                    # Check if decryption is done
                    if not decrypt_thread.is_alive() and self._buffer.size == 0:
                        logger.info("Playback complete")
                        break
                    continue

                frame, frame_idx = result
                self._current_frame = frame_idx

                # Apply overlays
                display_frame = frame.copy()
                if self.show_stats:
                    display_frame = self._draw_stats_overlay(
                        display_frame, self._decryptor.stats
                    )
                display_frame = self._draw_progress_bar(display_frame)

                cv2.imshow(self.WINDOW_NAME, display_frame)
                last_frame_time = time.perf_counter()

                # Check if window was closed
                if cv2.getWindowProperty(self.WINDOW_NAME, cv2.WND_PROP_VISIBLE) < 1:
                    break

        except KeyboardInterrupt:
            logger.info("Playback interrupted")
        finally:
            self._buffer.stop()
            self._playing = False
            cv2.destroyAllWindows()
            decrypt_thread.join(timeout=2.0)

    def _handle_key(self, key: int):
        """Handle keyboard input during playback."""
        if key == ord("q") or key == 27:  # Q or Esc
            self._playing = False
        elif key == ord(" "):  # Space — play/pause
            self._paused = not self._paused
            logger.info("Paused" if self._paused else "Resumed")
        elif key == ord("f"):  # F — fullscreen
            self._fullscreen = not self._fullscreen
            if self._fullscreen:
                cv2.setWindowProperty(
                    self.WINDOW_NAME, cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN
                )
            else:
                cv2.setWindowProperty(
                    self.WINDOW_NAME, cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_NORMAL
                )
        elif key == ord("s"):  # S — toggle stats
            self.show_stats = not self.show_stats
        elif key == ord("+") or key == ord("="):
            self._speed = min(self._speed + 0.25, 4.0)
            logger.info(f"Speed: {self._speed}x")
        elif key == ord("-"):
            self._speed = max(self._speed - 0.25, 0.25)
            logger.info(f"Speed: {self._speed}x")

    def play_headless(self, filepath: str, output_path: Optional[str] = None) -> dict:
        """
        Decrypt and optionally save video without GUI display.
        Useful for batch processing or server environments.

        Args:
            filepath: Path to .fortspy file.
            output_path: Optional output path for decrypted video.

        Returns:
            Decryption metadata and performance stats.
        """
        if self.key is None:
            raise ValueError("Key must be provided for headless mode")

        self._decryptor = FortSpyDecryptor(
            key=self.key, use_gpu=self.use_gpu
        )

        if output_path:
            return self._decryptor.decrypt_to_video(filepath, output_path)
        else:
            # Just decrypt frames to verify integrity
            count = 0
            for frame, idx in self._decryptor.decrypt_video_stream(filepath):
                count += 1
            return {
                "frames_verified": count,
                "stats": str(self._decryptor.stats),
            }
