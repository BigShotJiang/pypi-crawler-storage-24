from fortspy.utils.gpu_accelerator import GPUAccelerator
