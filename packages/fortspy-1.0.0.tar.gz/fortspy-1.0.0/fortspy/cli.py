"""
Fort Spy CLI
=============
Command-line interface for encrypting, decrypting, and playing Fort Spy videos.

Usage:
    fortspy encrypt -i input.mp4 -o output.fortspy -p "mypassword"
    fortspy decrypt -i input.fortspy -o output.mp4 -p "mypassword"
    fortspy play input.fortspy -p "mypassword"
    fortspy keygen -o mykey.fortkey
    fortspy info input.fortspy
"""

import argparse
import sys
import os
import logging
import getpass
import json
from pathlib import Path

from fortspy.core.encryptor import FortSpyEncryptor
from fortspy.core.decryptor import FortSpyDecryptor
from fortspy.core.key_manager import KeyManager
from fortspy.player.fort_player import FortSpyPlayer
from fortspy.utils.gpu_accelerator import GPUAccelerator
from fortspy import __version__


def setup_logging(verbose: bool = False):
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
        datefmt="%H:%M:%S",
    )


def progress_bar(current, total, bar_len=50):
    pct = current / max(total, 1)
    filled = int(bar_len * pct)
    bar = "█" * filled + "░" * (bar_len - filled)
    sys.stdout.write(f"\r  [{bar}] {current}/{total} frames ({pct*100:.1f}%)")
    sys.stdout.flush()
    if current >= total:
        print()


def cmd_encrypt(args):
    """Handle encrypt command."""
    km = KeyManager(args.key_size)

    if args.keyfile:
        password = args.password or getpass.getpass("Key file password: ")
        key = km.load_key_from_file(args.keyfile, password=password)
    elif args.password:
        key, salt = km.derive_key_from_password(args.password)
        print(f"  Key derived from password (salt: {salt.hex()[:16]}...)")
    elif args.hex_key:
        key = KeyManager.key_from_hex(args.hex_key)
    else:
        key = km.generate_key()
        print(f"  Generated key: {KeyManager.key_to_hex(key)}")
        print(f"  ⚠ Save this key! You need it for decryption.")

    output = args.output or str(Path(args.input).with_suffix(".fortspy"))

    encryptor = FortSpyEncryptor(key=key, mode=args.mode, key_size=args.key_size)

    print(f"\n🔒 Encrypting: {args.input}")
    print(f"   Output: {output}")
    print(f"   Mode: AES-{args.key_size}-{args.mode}\n")

    metadata = encryptor.encrypt_video(
        args.input, output, progress_callback=progress_bar
    )

    print(f"\n✅ Encryption complete!")
    print(f"   Frames: {metadata['total_frames']}")
    print(f"   Resolution: {metadata['width']}x{metadata['height']}")
    print(f"   Key fingerprint: {metadata['key_fingerprint']}")

    # Optionally save key
    if args.save_key:
        key_path = args.save_key
        key_password = args.password or getpass.getpass("Protect key file with password: ")
        km.save_key_to_file(key, key_path, password=key_password)
        print(f"   Key saved to: {key_path}")


def cmd_decrypt(args):
    """Handle decrypt command."""
    km = KeyManager(args.key_size)

    if args.keyfile:
        password = args.password or getpass.getpass("Key file password: ")
        key = km.load_key_from_file(args.keyfile, password=password)
    elif args.password:
        if not args.salt:
            print("Error: --salt is required when using --password for decryption")
            sys.exit(1)
        salt = bytes.fromhex(args.salt)
        key, _ = km.derive_key_from_password(args.password, salt=salt)
    elif args.hex_key:
        key = KeyManager.key_from_hex(args.hex_key)
    else:
        hex_key = getpass.getpass("Enter decryption key (hex): ")
        key = KeyManager.key_from_hex(hex_key)

    output = args.output or str(Path(args.input).with_suffix(".mp4"))

    decryptor = FortSpyDecryptor(key=key, use_gpu=not args.no_gpu)

    print(f"\n🔓 Decrypting: {args.input}")
    print(f"   Output: {output}\n")

    result = decryptor.decrypt_to_video(
        args.input, output, progress_callback=progress_bar
    )

    print(f"\n✅ Decryption complete!")
    print(f"   Frames: {result['total_frames']}")
    print(f"   Avg decrypt time: {result['avg_frame_time_ms']:.2f}ms/frame")
    print(f"   Effective FPS: {result['effective_fps']:.1f}")
    print(f"   Throughput: {result['throughput_mbps']:.2f} MB/s")


def cmd_play(args):
    """Handle play command."""
    km = KeyManager()

    if args.keyfile:
        password = args.password or getpass.getpass("Key file password: ")
        key = km.load_key_from_file(args.keyfile, password=password)
    elif args.password:
        if not args.salt:
            print("Error: --salt required with --password for decryption")
            sys.exit(1)
        salt = bytes.fromhex(args.salt)
        key, _ = km.derive_key_from_password(args.password, salt=salt)
    elif args.hex_key:
        key = KeyManager.key_from_hex(args.hex_key)
    else:
        key = None  # Player will prompt

    player = FortSpyPlayer(
        key=key,
        use_gpu=not args.no_gpu,
        buffer_frames=args.buffer,
        show_stats=args.stats,
    )

    print(f"\n🎬 Fort Spy Player v{__version__}")
    print(f"   File: {args.input}")
    print(f"   GPU: {'Disabled' if args.no_gpu else 'Auto'}")
    print(f"   Buffer: {args.buffer} frames\n")
    print("   Controls: Space=Pause  F=Fullscreen  S=Stats  Q=Quit\n")

    player.play(args.input)


def cmd_keygen(args):
    """Handle keygen command."""
    km = KeyManager(args.key_size)
    key = km.generate_key()

    print(f"\n🔑 Fort Spy Key Generator")
    print(f"   Algorithm: AES-{args.key_size}")
    print(f"   Key (hex): {KeyManager.key_to_hex(key)}")
    print(f"   Fingerprint: {km.compute_key_fingerprint(key)}")

    if args.output:
        password = args.password or getpass.getpass("Protect key file with password (Enter to skip): ")
        km.save_key_to_file(key, args.output, password=password or None)
        print(f"   Saved to: {args.output}")


def cmd_info(args):
    """Handle info command — show file metadata."""
    from fortspy.core.encryptor import EncryptionHeader

    with open(args.input, "rb") as f:
        data = f.read(EncryptionHeader.HEADER_SIZE + 32)

    try:
        header = EncryptionHeader.from_bytes(data)
    except ValueError as e:
        print(f"Error: {e}")
        sys.exit(1)

    fps = header.fps_num / header.fps_den if header.fps_den else 0

    print(f"\n📄 Fort Spy File Info")
    print(f"   File: {args.input}")
    print(f"   Size: {os.path.getsize(args.input) / (1024*1024):.2f} MB")
    print(f"   Version: {header.version}")
    print(f"   Resolution: {header.width}x{header.height}")
    print(f"   FPS: {fps:.2f}")
    print(f"   Total Frames: {header.total_frames}")
    print(f"   Duration: {header.total_frames / max(fps, 1):.2f}s")
    print(f"   Encryption: AES-{header.key_size}-{header.mode}")
    print(f"   IV: {header.iv.hex()}")


def cmd_gpu_info(args):
    """Show GPU acceleration info."""
    gpu = GPUAccelerator()
    info = gpu.get_device_info()
    print(f"\n🖥  GPU Acceleration Info")
    for k, v in info.items():
        print(f"   {k}: {v}")


def main():
    parser = argparse.ArgumentParser(
        prog="fortspy",
        description=f"Fort Spy v{__version__} — Pixel-Level Video Encryption",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  fortspy encrypt -i video.mp4 -o secure.fortspy -p "mypassword"
  fortspy decrypt -i secure.fortspy -o video.mp4 --keyfile mykey.fortkey
  fortspy play secure.fortspy --hex-key abcdef0123456789...
  fortspy keygen -o mykey.fortkey --key-size 256
  fortspy info secure.fortspy
        """,
    )
    parser.add_argument("-v", "--verbose", action="store_true", help="Verbose logging")
    parser.add_argument("--version", action="version", version=f"Fort Spy v{__version__}")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # --- encrypt ---
    enc = subparsers.add_parser("encrypt", help="Encrypt a video file")
    enc.add_argument("-i", "--input", required=True, help="Input video file")
    enc.add_argument("-o", "--output", help="Output .fortspy file")
    enc.add_argument("-p", "--password", help="Derive key from password")
    enc.add_argument("--hex-key", help="AES key as hex string")
    enc.add_argument("--keyfile", help="Load key from .fortkey file")
    enc.add_argument("--save-key", help="Save generated key to .fortkey file")
    enc.add_argument("--mode", default="CTR", choices=["CBC", "CTR", "GCM"], help="AES mode")
    enc.add_argument("--key-size", type=int, default=256, choices=[128, 192, 256])

    # --- decrypt ---
    dec = subparsers.add_parser("decrypt", help="Decrypt a .fortspy file to video")
    dec.add_argument("-i", "--input", required=True, help="Input .fortspy file")
    dec.add_argument("-o", "--output", help="Output video file")
    dec.add_argument("-p", "--password", help="Password for key derivation")
    dec.add_argument("--salt", help="Salt hex for password derivation")
    dec.add_argument("--hex-key", help="AES key as hex string")
    dec.add_argument("--keyfile", help="Load key from .fortkey file")
    dec.add_argument("--key-size", type=int, default=256, choices=[128, 192, 256])
    dec.add_argument("--no-gpu", action="store_true", help="Disable GPU acceleration")

    # --- play ---
    pla = subparsers.add_parser("play", help="Play an encrypted .fortspy file")
    pla.add_argument("input", help="Path to .fortspy file")
    pla.add_argument("-p", "--password", help="Password for key derivation")
    pla.add_argument("--salt", help="Salt hex for password derivation")
    pla.add_argument("--hex-key", help="AES key as hex string")
    pla.add_argument("--keyfile", help="Load key from .fortkey file")
    pla.add_argument("--no-gpu", action="store_true", help="Disable GPU acceleration")
    pla.add_argument("--buffer", type=int, default=30, help="Frame buffer size")
    pla.add_argument("--stats", action="store_true", help="Show stats overlay")

    # --- keygen ---
    kg = subparsers.add_parser("keygen", help="Generate an encryption key")
    kg.add_argument("-o", "--output", help="Save key to .fortkey file")
    kg.add_argument("-p", "--password", help="Password to protect key file")
    kg.add_argument("--key-size", type=int, default=256, choices=[128, 192, 256])

    # --- info ---
    inf = subparsers.add_parser("info", help="Show .fortspy file metadata")
    inf.add_argument("input", help="Path to .fortspy file")

    # --- gpu-info ---
    subparsers.add_parser("gpu-info", help="Show GPU acceleration status")

    args = parser.parse_args()
    setup_logging(args.verbose if hasattr(args, "verbose") else False)

    if args.command is None:
        parser.print_help()
        sys.exit(0)

    commands = {
        "encrypt": cmd_encrypt,
        "decrypt": cmd_decrypt,
        "play": cmd_play,
        "keygen": cmd_keygen,
        "info": cmd_info,
        "gpu-info": cmd_gpu_info,
    }

    try:
        commands[args.command](args)
    except KeyboardInterrupt:
        print("\nAborted.")
        sys.exit(1)
    except Exception as e:
        logging.error(f"Error: {e}")
        if args.verbose if hasattr(args, "verbose") else False:
            import traceback
            traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
