"""
Fort Spy Test Suite
====================
Comprehensive tests for encryption, decryption, key management,
and the full video pipeline.
"""

import os
import tempfile
import struct
import pytest
import numpy as np

from fortspy.core.key_manager import KeyManager
from fortspy.core.encryptor import FortSpyEncryptor, EncryptionHeader
from fortspy.core.decryptor import FortSpyDecryptor
from fortspy.utils.gpu_accelerator import GPUAccelerator


# ──────────────────────────────────────────────
#  Key Manager Tests
# ──────────────────────────────────────────────

class TestKeyManager:
    def test_generate_key_default(self):
        km = KeyManager(256)
        key = km.generate_key()
        assert len(key) == 32

    def test_generate_key_128(self):
        km = KeyManager(128)
        key = km.generate_key()
        assert len(key) == 16

    def test_generate_key_192(self):
        km = KeyManager(192)
        key = km.generate_key()
        assert len(key) == 24

    def test_invalid_key_size(self):
        with pytest.raises(ValueError):
            KeyManager(512)

    def test_generate_iv(self):
        km = KeyManager()
        iv = km.generate_iv()
        assert len(iv) == 16

    def test_password_derivation(self):
        km = KeyManager(256)
        key1, salt = km.derive_key_from_password("test_password")
        key2, _ = km.derive_key_from_password("test_password", salt=salt)
        assert key1 == key2
        assert len(key1) == 32

    def test_different_passwords_yield_different_keys(self):
        km = KeyManager(256)
        key1, salt = km.derive_key_from_password("password1")
        key2, _ = km.derive_key_from_password("password2", salt=salt)
        assert key1 != key2

    def test_ecdh_key_exchange(self):
        alice = KeyManager(256)
        bob = KeyManager(256)

        alice_pub = alice.generate_ecdh_keypair()
        bob_pub = bob.generate_ecdh_keypair()

        shared_a = alice.derive_shared_key(bob_pub)
        shared_b = bob.derive_shared_key(alice_pub)
        assert shared_a == shared_b
        assert len(shared_a) == 32

    def test_key_file_roundtrip_unprotected(self):
        km = KeyManager(256)
        key = km.generate_key()
        with tempfile.NamedTemporaryFile(suffix=".fortkey", delete=False) as f:
            path = f.name
        try:
            km.save_key_to_file(key, path)
            loaded = km.load_key_from_file(path)
            assert key == loaded
        finally:
            os.unlink(path)

    def test_key_file_roundtrip_protected(self):
        km = KeyManager(256)
        key = km.generate_key()
        with tempfile.NamedTemporaryFile(suffix=".fortkey", delete=False) as f:
            path = f.name
        try:
            km.save_key_to_file(key, path, password="secret")
            loaded = km.load_key_from_file(path, password="secret")
            assert key == loaded
        finally:
            os.unlink(path)

    def test_key_hex_roundtrip(self):
        km = KeyManager()
        key = km.generate_key()
        hex_str = KeyManager.key_to_hex(key)
        restored = KeyManager.key_from_hex(hex_str)
        assert key == restored

    def test_hmac_verify(self):
        km = KeyManager()
        key = km.generate_key()
        data = b"test data for hmac"
        mac = km.generate_hmac(key, data)
        assert km.verify_hmac(key, data, mac)
        assert not km.verify_hmac(key, b"tampered data", mac)

    def test_fingerprint_deterministic(self):
        km = KeyManager()
        key = b"\x00" * 32
        fp1 = km.compute_key_fingerprint(key)
        fp2 = km.compute_key_fingerprint(key)
        assert fp1 == fp2
        assert ":" in fp1


# ──────────────────────────────────────────────
#  Encryption Header Tests
# ──────────────────────────────────────────────

class TestEncryptionHeader:
    def test_header_roundtrip(self):
        iv = os.urandom(16)
        header = EncryptionHeader(
            width=1920, height=1080, fps=30.0,
            total_frames=100, iv=iv, key_size=256, mode="CTR",
        )
        data = header.to_bytes()
        restored = EncryptionHeader.from_bytes(data)
        assert restored.width == 1920
        assert restored.height == 1080
        assert restored.total_frames == 100
        assert restored.mode == "CTR"
        assert restored.key_size == 256
        assert restored.iv == iv

    def test_header_hmac(self):
        km = KeyManager(256)
        key = km.generate_key()
        iv = os.urandom(16)
        header = EncryptionHeader(
            width=640, height=480, fps=24.0,
            total_frames=50, iv=iv,
        )
        data = header.to_bytes(hmac_key=key)
        # Should not raise with correct key
        EncryptionHeader.from_bytes(data, hmac_key=key)

    def test_header_bad_magic(self):
        data = b"BADMAGIC" + b"\x00" * 100
        with pytest.raises(ValueError, match="bad magic"):
            EncryptionHeader.from_bytes(data)


# ──────────────────────────────────────────────
#  Frame Encryption/Decryption Tests
# ──────────────────────────────────────────────

class TestFrameEncryption:
    @pytest.fixture
    def sample_frame(self):
        """Create a 64x48 test frame with known pixel pattern."""
        frame = np.zeros((48, 64, 3), dtype=np.uint8)
        frame[:, :, 0] = 100  # Blue channel
        frame[:, :, 1] = 150  # Green channel
        frame[:, :, 2] = 200  # Red channel
        return frame

    @pytest.fixture
    def key_and_iv(self):
        km = KeyManager(256)
        return km.generate_key(), km.generate_iv()

    def test_ctr_frame_roundtrip(self, sample_frame, key_and_iv):
        key, iv = key_and_iv
        enc = FortSpyEncryptor(key=key, mode="CTR")
        dec = FortSpyDecryptor(key=key, use_gpu=False)

        encrypted = enc.encrypt_frame(sample_frame, iv, frame_index=0)
        # Strip 4-byte length prefix
        frame_len = struct.unpack(">I", encrypted[:4])[0]
        ct = encrypted[4:]

        decrypted = dec.decrypt_frame(ct, iv, "CTR", 0, 64, 48)
        np.testing.assert_array_equal(sample_frame, decrypted)

    def test_cbc_frame_roundtrip(self, sample_frame, key_and_iv):
        key, iv = key_and_iv
        enc = FortSpyEncryptor(key=key, mode="CBC")
        dec = FortSpyDecryptor(key=key, use_gpu=False)

        encrypted = enc.encrypt_frame(sample_frame, iv, frame_index=0)
        frame_len = struct.unpack(">I", encrypted[:4])[0]
        ct = encrypted[4:]

        decrypted = dec.decrypt_frame(ct, iv, "CBC", 0, 64, 48)
        np.testing.assert_array_equal(sample_frame, decrypted)

    def test_gcm_frame_roundtrip(self, sample_frame, key_and_iv):
        key, iv = key_and_iv
        enc = FortSpyEncryptor(key=key, mode="GCM")
        dec = FortSpyDecryptor(key=key, use_gpu=False)

        encrypted = enc.encrypt_frame(sample_frame, iv, frame_index=0)
        frame_len = struct.unpack(">I", encrypted[:4])[0]
        ct = encrypted[4:]

        decrypted = dec.decrypt_frame(ct, iv, "GCM", 0, 64, 48)
        np.testing.assert_array_equal(sample_frame, decrypted)

    def test_wrong_key_fails(self, sample_frame, key_and_iv):
        key, iv = key_and_iv
        wrong_key = os.urandom(32)
        enc = FortSpyEncryptor(key=key, mode="CTR")
        dec = FortSpyDecryptor(key=wrong_key, use_gpu=False)

        encrypted = enc.encrypt_frame(sample_frame, iv, frame_index=0)
        ct = encrypted[4:]

        decrypted = dec.decrypt_frame(ct, iv, "CTR", 0, 64, 48)
        # Decrypted with wrong key should NOT match original
        assert not np.array_equal(sample_frame, decrypted)

    def test_encrypted_differs_from_original(self, sample_frame, key_and_iv):
        key, iv = key_and_iv
        enc = FortSpyEncryptor(key=key, mode="CTR")
        encrypted = enc.encrypt_frame(sample_frame, iv, frame_index=0)
        # Ciphertext should be different from plaintext
        assert encrypted[4:] != sample_frame.tobytes()

    def test_multiple_frames_unique(self, sample_frame, key_and_iv):
        key, iv = key_and_iv
        enc = FortSpyEncryptor(key=key, mode="CTR")
        e1 = enc.encrypt_frame(sample_frame, iv, frame_index=0)
        e2 = enc.encrypt_frame(sample_frame, iv, frame_index=1)
        # Same frame encrypted at different positions should differ (unique nonces)
        assert e1 != e2


# ──────────────────────────────────────────────
#  Full Video Pipeline Tests
# ──────────────────────────────────────────────

class TestVideoPipeline:
    @pytest.fixture
    def test_video(self, tmp_path):
        """Create a small test video file."""
        import cv2
        path = str(tmp_path / "test_video.mp4")
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        writer = cv2.VideoWriter(path, fourcc, 10.0, (64, 48))
        for i in range(30):
            frame = np.full((48, 64, 3), fill_value=i * 8, dtype=np.uint8)
            writer.write(frame)
        writer.release()
        return path

    def test_encrypt_decrypt_pipeline(self, test_video, tmp_path):
        km = KeyManager(256)
        key = km.generate_key()

        enc_path = str(tmp_path / "encrypted.fortspy")
        dec_path = str(tmp_path / "decrypted.mp4")

        # Encrypt
        enc = FortSpyEncryptor(key=key, mode="CTR")
        meta = enc.encrypt_video(test_video, enc_path)
        assert meta["total_frames"] == 30
        assert os.path.exists(enc_path)

        # Decrypt
        dec = FortSpyDecryptor(key=key, use_gpu=False)
        result = dec.decrypt_to_video(enc_path, dec_path)
        assert result["total_frames"] == 30
        assert os.path.exists(dec_path)

    def test_stream_decryption(self, test_video, tmp_path):
        km = KeyManager(256)
        key = km.generate_key()
        enc_path = str(tmp_path / "stream_test.fortspy")

        enc = FortSpyEncryptor(key=key, mode="CTR")
        enc.encrypt_video(test_video, enc_path)

        dec = FortSpyDecryptor(key=key, use_gpu=False)
        frames = list(dec.decrypt_video_stream(enc_path))
        assert len(frames) == 30

    def test_key_verification(self, test_video, tmp_path):
        km = KeyManager(256)
        key = km.generate_key()
        wrong_key = km.generate_key()
        enc_path = str(tmp_path / "verify_test.fortspy")

        enc = FortSpyEncryptor(key=key, mode="CTR")
        enc.encrypt_video(test_video, enc_path)

        # Correct key should verify
        dec_ok = FortSpyDecryptor(key=key, use_gpu=False)
        assert dec_ok.verify_key(enc_path)


# ──────────────────────────────────────────────
#  GPU Accelerator Tests
# ──────────────────────────────────────────────

class TestGPUAccelerator:
    def test_numpy_fallback(self):
        gpu = GPUAccelerator()
        frame = np.random.randint(0, 256, (48, 64, 3), dtype=np.uint8)
        result = gpu.process_frame(frame)
        np.testing.assert_array_equal(frame, result)

    def test_batch_process(self):
        gpu = GPUAccelerator()
        frames = [
            np.random.randint(0, 256, (48, 64, 3), dtype=np.uint8) for _ in range(5)
        ]
        results = gpu.batch_process_frames(frames)
        assert len(results) == 5

    def test_device_info(self):
        gpu = GPUAccelerator()
        info = gpu.get_device_info()
        assert "backend" in info


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
