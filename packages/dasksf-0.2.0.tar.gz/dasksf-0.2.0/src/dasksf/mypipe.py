import fits2tmp as f2t 
import subprocess
import configparser
import logging 
import time
from dask.distributed import performance_report, get_task_stream
from dask import delayed
from dask.diagnostics import Profiler, ResourceProfiler, CacheProfiler, visualize
from datetime import timedelta
import tempfile
import shutil
from functools import reduce

class Pipeline:
    def __init__(self, client, n_nodes, n_workers, n_threads, worker_mem, platform, workflow, outputdir, data, header_loc, tmpdir, sofia_params, n_dims, im_shape, chunk_size, overlap):
        # TODO get dask version, fits2tmp version and dasksf version and log
        self.client = client
        self.nodes = n_nodes
        self.n_workers = n_workers
        self.n_threads = n_threads
        self.platform = platform
        self.worker_mem = int(worker_mem)
        #self.dask_version = subprocess.run(["dask", "--version"])
        # create a config reader to allow us to provide values to the program
        self.n_dims = n_dims
        self.outputdir = outputdir
        self.workflow = workflow
        self.data = data
        self.header_loc = header_loc
        self.tmpdir = tmpdir
        self.sofia_params = sofia_params
        self.im_shape = [int(x) for x in im_shape.split(",")]
        print(self.im_shape)
        self.overlap = [int(x) for x in overlap.split(",")]
        self.im_as_slice = []
        for i in range(len(self.im_shape)):
            self.im_as_slice.append(slice(0, self.im_shape[i]))
        self.im_pix = 1
        for i in range(int(self.n_dims)):
            self.im_pix = self.im_shape[i] * self.im_pix 
        self.chunk_info = chunk_size
        if self.chunk_info != "auto":
            self.chunks = tuple([int(x) for x in self.chunk_info.split(",")])
            self.ch_pix = 1
            for i in range(int(self.n_dims)):
                self.ch_pix = self.chunks[i] * self.im_pix 
        else:
            self.chunks = self.chunk_info
            self.ch_pix = "auto"
        if "fits" in self.data:
            self.filetype = "fits"
        elif "zarr" in self.data:
            self.filetype = "zarr"
        elif "h5" in self.data:
            self.filetype = "hdf5"
        standard_formatter = logging.Formatter("%(asctime)s p%(process)s {%(pathname)s:%(lineno)d} %(levelname)s - %(message)s", datefmt="%Y-%m-%d %H:%M:%S")
        output_formatter = logging.Formatter('%(asctime)s %(message)s', datefmt="%Y-%m-%d %H:%M:%S")
        standard_handler = logging.FileHandler(self.outputdir + "dsf.log")
        output_handler = logging.FileHandler(self.outputdir + "timings.csv")
        standard_handler.setFormatter(standard_formatter)
        output_handler.setFormatter(output_formatter)
        self.mainlog = logging.getLogger("mainlog")
        self.mainlog.setLevel("INFO")
        self.mainlog.addHandler(standard_handler)
        self.outputlog = logging.getLogger("outputlog")
        self.outputlog.setLevel("INFO")
        self.outputlog.addHandler(output_handler)
    
    def run_sof(self, filename):
        subprocess.run(["sofia", self.sofia_params, "input.data="+filename, "output.directory="+self.tmpdir])

    def dedupe(self, file1, file2):
        if "_cat.xml" not in file1:
            file1 = file1 + "_cat.xml"
        if "_cat.xml" not in file2:
            file2 = file2 + "_cat.xml"
        f = tempfile.NamedTemporaryFile(delete=False)
        subprocess.run(["stilts", "tskymatch2", "in1="+file1, "in2="+file2, "join=1or2", "out="+f.name + "_cat.xml", "error=1"])
        return f.name
        
    def run_sofia_pipeline(self):
        print(self.im_as_slice)
        client = self.client
        start_time = time.monotonic()
        #print(type(self.data), type(self.tmpdir), self.chunks)
        with performance_report(filename=self.outputdir + "perf_report.html"), Profiler() as prof, ResourceProfiler(dt=0.05) as rprof, CacheProfiler() as cprof, get_task_stream(plot="save", filename=(self.outputdir + "task_stream.html")) as ts:
            #filelist = f2t.fits2tmp.fakefits2tmpfiles(self.filetype, self.data, self.tmpdir, tuple(self.im_as_slice), self.header_loc, self.chunks, self.overlap)
            filelist = f2t.fits2tmp.fakefits2tmpfiles(self.filetype, self.data, self.tmpdir, self.im_shape, self.header_loc, self.chunks, self.overlap)
            print(filelist)
            scatter_files = client.scatter(filelist)
            load_time = time.monotonic() 
            outlist = []
            for i in filelist:
                a = self.run_sof(i)
                outlist.append(i[i.index('/'):])
            calc_done = time.monotonic()
            output = client.gather(outlist)
            print(outlist)
            fin_cat = reduce(self.dedupe, output)
            end_time = time.monotonic()
            print(fin_cat)
            with open(fin_cat + "_cat.xml", 'rb') as tf, open(self.outputdir + "/combined_catalogue.xml", 'wb') as destfil:
                shutil.copyfileobj(tf, destfil)
            self.outputlog.info(
                ", %s, %s,%s, %s, %s, %s, %s, %s, %s,%s, %s, %s, %s, %s", 
                #%s, %s, %s",
                str(self.platform),
                ##str(self.dask_version),
                str(self.workflow),
                str(self.nodes),
                str(self.n_workers),
                str(self.n_threads),
                str(self.worker_mem),
                self.n_dims,
                self.im_pix,
                self.ch_pix,
                self.filetype,
                str(timedelta(seconds = calc_done - start_time)),
                str(timedelta(seconds = load_time - start_time)),
                str(timedelta(seconds = calc_done - load_time)),
                timedelta(seconds = end_time - calc_done),
                #mem_used,
                )
            visualize([prof, rprof, cprof], filename=(self.outputdir + "profile.html"), save=True)

