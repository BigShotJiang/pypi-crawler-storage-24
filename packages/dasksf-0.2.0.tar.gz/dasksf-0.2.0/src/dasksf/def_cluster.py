import subprocess
import dask
import logging
import configparser
import argparse
import dasksf.mypipe as mypipe
from distributed import Client, LocalCluster

class ClusterD():
    """
    Collects the definition of the Dask cluster that is running, or if there is not a cluster running, creates a local cluster."
    """
    def __init__(self, config_read="/home/vla22/programs/dasksf/config/config.ini"):
        # params can be passed on the command line, to override defaults
        config = configparser.ConfigParser()
        config.read(config_read)
        parser = argparse.ArgumentParser()
        parser.add_argument("--platform", help="specify the platform on which you are running this code", default=config['DEFAULT']['platform'])
        parser.add_argument("--workflow", help="specify the workflow used", default=config['DEFAULT']['workflow'])
        parser.add_argument("--n_nodes", help="number of nodes", default=config['DEFAULT']['n_nodes'], type=int)
        parser.add_argument("--n_workers", help="number of workers", default=config['DEFAULT']['n_workers'], type=int)
        parser.add_argument("--worker_mem", help="RAM per worker", default=config['DEFAULT']['worker_mem'])
        parser.add_argument("--n_threads", help="threads per worker", default=config['DEFAULT']['n_threads'], type=int)
        parser.add_argument("--scheduler", help="dask scheduler")
        parser.add_argument("--image_config", help="tell us about the dataset to use, based on the config file", default="image-default")
        args = parser.parse_args()
        platform = args.platform
        workflow = args.workflow
        n_nodes = args.n_nodes
        n_workers = args.n_workers
        worker_mem = args.worker_mem[:-3]
        n_threads = args.n_threads
        image_config = args.image_config
        data = config[platform]['data']
        header_loc = config[platform]['header_loc']
        tmpdir = config[platform]['tmpdir']
        outputdir = config[platform]['outputdir']
        sofia_params = config[platform]['sofia_params']
        n_dims = config[image_config]['n_dims']
        im_shape = config[image_config]['im_shape']
        chunk_size = config[image_config]['chunk_size']
        overlap = config[image_config]['overlap']
        logging.basicConfig(filename=config[platform]['outputdir']+"cluster.log", level=logging.INFO,format="%(asctime)s p%(process)s {%(pathname)s:%(lineno)d} %(levelname)s - %(message)s", datefmt="%Y-%m-%d %H:%M:%S")
        if config['DEFAULT']['csd3'] == "True":
            # This is for connecting to a client on a self-defined cluster, using a local variable to connect to the scheduler
            scheduler = args.scheduler
            client = Client(scheduler)
            logging.info("client connected")
            logging.info(client.scheduler_info())
            a = mypipe.Pipeline(client=client, n_nodes=n_nodes, n_workers=n_workers, n_threads=n_threads, worker_mem=worker_mem, platform=platform, workflow=workflow, outputdir=outputdir, data=data, header_loc=header_loc, tmpdir=tmpdir, sofia_params=sofia_params, n_dims=n_dims, im_shape=im_shape, chunk_size=chunk_size, overlap=overlap)
            a.run_sofia_pipeline()
        elif config['DEFAULT']['k8s'] == "True":
            # we use a bare client. If in a k8s environment, the config should connect to the scheduler automatically; otherwise it should fall back to a LocalCluster, suitable for local/single node testing.
            client = Client()
            a = mypipe.Pipeline(client=client, worker_mem=worker_mem, n_threads=n_threads, n_workers=n_workers, n_nodes=n_nodes, platform=platform, workflow=workflow, outputdir=outputdir, data=data, header_loc=header_loc, tmpdir=tmpdir, sofia_params=sofia_params, n_dims=n_dims, im_shape=im_shape, chunk_size=chunk_size, overlap=overlap)
            a.run_sofia_pipeline()
        else:
            with LocalCluster(threads_per_worker=n_threads, n_workers=n_workers, memory_limit=(worker_mem + "GB")) as cluster, Client(cluster) as client:

            # we configure a local cluster
                a = mypipe.Pipeline(client=client, worker_mem=worker_mem, n_threads=n_threads, n_workers=n_workers, n_nodes=n_nodes, platform=platform, workflow=workflow, outputdir=outputdir, data=data, header_loc=header_loc, tmpdir=tmpdir, sofia_params=sofia_params, n_dims=n_dims, im_shape=im_shape, chunk_size=chunk_size, overlap=overlap)
                a.run_sofia_pipeline()

def main():
    a = ClusterD()

if __name__ == "__main__":
    main()

