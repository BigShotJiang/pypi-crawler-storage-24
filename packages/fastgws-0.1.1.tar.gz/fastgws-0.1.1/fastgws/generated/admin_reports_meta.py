"""Generated service metadata."""

SERVICE = {'alias': 'admin_reports',
 'api_name': 'admin',
 'version': 'reports_v1',
 'title': 'Admin SDK API',
 'description': 'Admin SDK lets administrators of enterprise domains to view and manage resources like user, groups '
                'etc. It also provides audit and usage reports of domain.',
 'documentation_link': 'https://developers.google.com/workspace/admin/',
 'root_url': 'https://admin.googleapis.com/',
 'base_url': 'https://admin.googleapis.com/',
 'service_path': '',
 'methods': [{'dotted_path': 'admin_reports.activities.list',
              'api_dotted_path': 'admin_reports.activities.list',
              'resource_path': 'activities',
              'py_name': 'list',
              'api_name': 'list',
              'http_method': 'GET',
              'path': 'admin/reports/v1/activity/users/{userKey}/applications/{applicationName}',
              'flat_path': 'admin/reports/v1/activity/users/{userKey}/applications/{applicationName}',
              'description': "Retrieves a list of activities for a specific customer's account and application such as "
                             'the Admin console application or the Google Drive application. For more information, see '
                             'the guides for administrator and Google Drive activity reports. For more information '
                             "about the activity report's parameters, see the activity parameters reference guides. ",
              'path_params': [{'py_name': 'application_name',
                               'api_name': 'applicationName',
                               'location': 'path',
                               'required': True,
                               'repeated': False,
                               'type': 'string',
                               'enum_values': ['access_transparency',
                                               'admin',
                                               'calendar',
                                               'chat',
                                               'drive',
                                               'gcp',
                                               'gmail',
                                               'gplus',
                                               'groups',
                                               'groups_enterprise',
                                               'jamboard',
                                               'login',
                                               'meet',
                                               'mobile',
                                               'rules',
                                               'saml',
                                               'token',
                                               'user_accounts',
                                               'context_aware_access',
                                               'chrome',
                                               'data_studio',
                                               'keep',
                                               'vault',
                                               'gemini_in_workspace_apps',
                                               'classroom',
                                               'assignments',
                                               'cloud_search',
                                               'tasks',
                                               'data_migration',
                                               'meet_hardware',
                                               'directory_sync',
                                               'ldap',
                                               'profile',
                                               'access_evaluation',
                                               'admin_data_action',
                                               'contacts',
                                               'takeout',
                                               'graduation'],
                               'description': 'Application name for which the events are to be retrieved.',
                               'default': None},
                              {'py_name': 'user_key',
                               'api_name': 'userKey',
                               'location': 'path',
                               'required': True,
                               'repeated': False,
                               'type': 'string',
                               'enum_values': [],
                               'description': 'Represents the profile ID or the user email for which the data should '
                                              'be filtered. Can be `all` for all information, or `userKey` for a '
                                              "user's unique Google Workspace profile ID or their primary email "
                                              'address. Must not be a deleted user. For a deleted user, call '
                                              '`users.list` in Directory API with `showDeleted=true`, then use the '
                                              'returned `ID` as the `userKey`.',
                               'default': None}],
              'query_params': [{'py_name': 'actor_ip_address',
                                'api_name': 'actorIpAddress',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'string',
                                'enum_values': [],
                                'description': 'The Internet Protocol (IP) Address of host where the event was '
                                               "performed. This is an additional way to filter a report's summary "
                                               'using the IP address of the user whose activity is being reported. '
                                               "This IP address may or may not reflect the user's physical location. "
                                               "For example, the IP address can be the user's proxy server's address "
                                               'or a virtual private network (VPN) address. This parameter supports '
                                               'both IPv4 and IPv6 address versions.',
                                'default': None},
                               {'py_name': 'application_info_filter',
                                'api_name': 'applicationInfoFilter',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'string',
                                'enum_values': [],
                                'description': 'Optional. Used to filter on the `oAuthClientId` field present in '
                                               '[`ApplicationInfo`](#applicationinfo) message. **Usage** ``` '
                                               'GET...&applicationInfoFilter=oAuthClientId="clientId" '
                                               'GET...&applicationInfoFilter=oAuthClientId=%22clientId%22 ```',
                                'default': None},
                               {'py_name': 'customer_id',
                                'api_name': 'customerId',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'string',
                                'enum_values': [],
                                'description': 'The unique ID of the customer to retrieve data for.',
                                'default': None},
                               {'py_name': 'end_time',
                                'api_name': 'endTime',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'string',
                                'enum_values': [],
                                'description': 'Sets the end of the range of time shown in the report. The date is in '
                                               'the RFC 3339 format, for example 2010-10-28T10:26:35.000Z. The default '
                                               'value is the approximate time of the API request. An API report has '
                                               "three basic time concepts: - *Date of the API's request for a report*: "
                                               "When the API created and retrieved the report. - *Report's start "
                                               'time*: The beginning of the timespan shown in the report. The '
                                               '`startTime` must be before the `endTime` (if specified) and the '
                                               'current time when the request is made, or the API returns an error. - '
                                               "*Report's end time*: The end of the timespan shown in the report. For "
                                               'example, the timespan of events summarized in a report can start in '
                                               'April and end in May. The report itself can be requested in August. If '
                                               'the `endTime` is not specified, the report returns all activities from '
                                               'the `startTime` until the current time or the most recent 180 days if '
                                               'the `startTime` is more than 180 days in the past. For Gmail requests, '
                                               '`startTime` and `endTime` must be provided and the difference must not '
                                               'be greater than 30 days.',
                                'default': None},
                               {'py_name': 'event_name',
                                'api_name': 'eventName',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'string',
                                'enum_values': [],
                                'description': 'The name of the event being queried by the API. Each `eventName` is '
                                               'related to a specific Google Workspace service or feature which the '
                                               'API organizes into types of events. An example is the Google Calendar '
                                               "events in the Admin console application's reports. The Calendar "
                                               'Settings `type` structure has all of the Calendar `eventName` '
                                               'activities reported by the API. When an administrator changes a '
                                               'Calendar setting, the API reports this activity in the Calendar '
                                               'Settings `type` and `eventName` parameters. For more information about '
                                               '`eventName` query strings and parameters, see the list of event names '
                                               'for various applications above in `applicationName`.',
                                'default': None},
                               {'py_name': 'filters',
                                'api_name': 'filters',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'string',
                                'enum_values': [],
                                'description': 'The `filters` query string is a comma-separated list composed of event '
                                               'parameters manipulated by relational operators. Event parameters are '
                                               'in the form `{parameter1 name}{relational operator}{parameter1 '
                                               'value},{parameter2 name}{relational operator}{parameter2 value},...` '
                                               'These event parameters are associated with a specific `eventName`. An '
                                               "empty report is returned if the request's parameter doesn't belong to "
                                               'the `eventName`. For more information about the available `eventName` '
                                               'fields for each application and their associated parameters, go to the '
                                               '[ApplicationName](#applicationname) table, then click through to the '
                                               'Activity Events page in the Appendix for the application you want. In '
                                               'the following Drive activity examples, the returned list consists of '
                                               'all `edit` events where the `doc_id` parameter value matches the '
                                               'conditions defined by the relational operator. In the first example, '
                                               'the request returns all edited documents with a `doc_id` value equal '
                                               'to `12345`. In the second example, the report returns any edited '
                                               'documents where the `doc_id` value is not equal to `98765`. The `<>` '
                                               "operator is URL-encoded in the request's query string (`%3C%3E`): ``` "
                                               'GET...&eventName=edit&filters=doc_id==12345 '
                                               'GET...&eventName=edit&filters=doc_id%3C%3E98765 ``` A `filters` query '
                                               "supports these relational operators: * `==`—'equal to'. * `<>`—'not "
                                               "equal to'. Must be URL-encoded (%3C%3E). * `<`—'less than'. Must be "
                                               "URL-encoded (%3C). * `<=`—'less than or equal to'. Must be URL-encoded "
                                               "(%3C=). * `>`—'greater than'. Must be URL-encoded (%3E). * "
                                               "`>=`—'greater than or equal to'. Must be URL-encoded (%3E=). **Note:** "
                                               "The API doesn't accept multiple values of the same parameter. If a "
                                               'parameter is supplied more than once in the API request, the API only '
                                               'accepts the last value of that parameter. In addition, if an invalid '
                                               'parameter is supplied in the API request, the API ignores that '
                                               'parameter and returns the response corresponding to the remaining '
                                               'valid parameters. If no parameters are requested, all parameters are '
                                               'returned.',
                                'default': None},
                               {'py_name': 'group_id_filter',
                                'api_name': 'groupIdFilter',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'string',
                                'enum_values': [],
                                'description': 'Comma separated group ids (obfuscated) on which user activities are '
                                               'filtered, i.e. the response will contain activities for only those '
                                               'users that are a part of at least one of the group ids mentioned here. '
                                               'Format: "id:abc123,id:xyz456" *Important:* To filter by groups, you '
                                               'must explicitly add the groups to your filtering groups allowlist. For '
                                               'more information about adding groups to filtering groups allowlist, '
                                               'see [Filter results by Google '
                                               'Group](https://support.google.com/a/answer/11482175)',
                                'default': None},
                               {'py_name': 'max_results',
                                'api_name': 'maxResults',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'integer',
                                'enum_values': [],
                                'description': 'Determines how many activity records are shown on each response page. '
                                               'For example, if the request sets `maxResults=1` and the report has two '
                                               "activities, the report has two pages. The response's `nextPageToken` "
                                               'property has the token to the second page. The `maxResults` query '
                                               'string is optional in the request. The default value is 1000.',
                                'default': '1000'},
                               {'py_name': 'network_info_filter',
                                'api_name': 'networkInfoFilter',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'string',
                                'enum_values': [],
                                'description': 'Optional. Used to filter on the `regionCode` field present in '
                                               '[`NetworkInfo`](#networkinfo) message. **Usage** ``` '
                                               'GET...&networkInfoFilter=regionCode="IN" '
                                               'GET...&networkInfoFilter=regionCode=%22IN%22 ```',
                                'default': None},
                               {'py_name': 'org_unit_id',
                                'api_name': 'orgUnitID',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'string',
                                'enum_values': [],
                                'description': 'ID of the organizational unit to report on. Activity records will be '
                                               'shown only for users who belong to the specified organizational unit. '
                                               "Data before Dec 17, 2018 doesn't appear in the filtered results.",
                                'default': ''},
                               {'py_name': 'page_token',
                                'api_name': 'pageToken',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'string',
                                'enum_values': [],
                                'description': 'The token to specify next page. A report with multiple pages has a '
                                               '`nextPageToken` property in the response. In your follow-on request '
                                               'getting the next page of the report, enter the `nextPageToken` value '
                                               'in the `pageToken` query string.',
                                'default': None},
                               {'py_name': 'resource_details_filter',
                                'api_name': 'resourceDetailsFilter',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'string',
                                'enum_values': [],
                                'description': 'Optional. The `resourceDetailsFilter` query string is an AND separated '
                                               'list composed of [Resource Details](#resourcedetails) fields '
                                               'manipulated by relational operators. Resource Details Filters are in '
                                               'the form `{resourceDetails.field1}{relational operator}{field1 value} '
                                               'AND {resourceDetails.field2}{relational operator}{field2 value}...` '
                                               'All the inner fields are traversed using the `.` operator, as shown in '
                                               'the following example: ``` resourceDetails.id = "resourceId" AND '
                                               'resourceDetails.appliedLabels.id = "appliedLabelId" AND '
                                               'resourceDetails.appliedLabels.fieldValue.id = "fieldValueId" ``` '
                                               '`resourceDetailsFilter` query supports these relational operators: * '
                                               "`=`—'equal to'. * `!=`—'not equal to'. * `:`—'exists'. This is used "
                                               'for filtering on repeated fields. [`FieldValue`](#fieldvalue) types '
                                               'that are repeated in nature uses `exists` operator for filtering. The '
                                               'following [`FieldValue`](#fieldvalue) types are repeated: * '
                                               '[`TextListValue`](#textlistvalue) * '
                                               '[`SelectionListValue`](#selectionlistvalue) * '
                                               '[`UserListValue`](#userlistvalue) For example, in the following '
                                               'filter, [`SelectionListValue`](#selectionlistvalue), is a repeated '
                                               'field. The filter checks whether '
                                               '[`SelectionListValue`](#selectionlistvalue) contains `selection_id`: '
                                               '``` resourceDetails.id = "resourceId" AND '
                                               'resourceDetails.appliedLabels.id = "appliedLabelId" AND '
                                               'resourceDetails.appliedLabels.fieldValue.id = "fieldValueId" AND '
                                               'resourceDetails.appliedLabels.fieldValue.type = "SELECTION_LIST_VALUE" '
                                               'AND resourceDetails.appliedLabels.fieldValue.selectionListValue.id: '
                                               '"id" ``` **Usage** ``` GET...&resourceDetailsFilter=resourceDetails.id '
                                               '= "resourceId" AND resourceDetails.appliedLabels.id = "appliedLabelId" '
                                               'GET...&resourceDetailsFilter=resourceDetails.id=%22resourceId%22%20AND%20resourceDetails.appliedLabels.id=%22appliedLabelId%22 '
                                               '``` **Note the following**: * You must URL encode the query string '
                                               'before sending the request. * The API supports a maximum of 5 fields '
                                               'separated by the AND operator. - When filtering on deeper levels '
                                               '(e.g., [`AppliedLabel`](#appliedlabel), [`FieldValue`](#fieldvalue)), '
                                               'the IDs of all preceding levels in the hierarchy must be included in '
                                               'the filter. For example: Filtering on [`FieldValue`](#fieldvalue) '
                                               'requires [`AppliedLabel`](#appliedlabel) ID and resourceDetails ID to '
                                               'be present. *Sample Query*: ``` resourceDetails.id = "resourceId" AND '
                                               'resourceDetails.appliedLabels.id = "appliedLabelId" AND '
                                               'resourceDetails.appliedLabels.fieldValue.id = "fieldValueId" ``` * '
                                               'Filtering on inner [`FieldValue`](#fieldvalue) types like '
                                               '`longTextValue` and `textValue` requires '
                                               '`resourceDetails.appliedLabels.fieldValue.type` to be present. * Only '
                                               'Filtering on a single [`AppliedLabel`](#appliedlabel) id and '
                                               '[`FieldValue`](#fieldvalue) id is supported.',
                                'default': None},
                               {'py_name': 'start_time',
                                'api_name': 'startTime',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'string',
                                'enum_values': [],
                                'description': 'Sets the beginning of the range of time shown in the report. The date '
                                               'is in the RFC 3339 format, for example 2010-10-28T10:26:35.000Z. The '
                                               'report returns all activities from `startTime` until `endTime`. The '
                                               '`startTime` must be before the `endTime` (if specified) and the '
                                               'current time when the request is made, or the API returns an error. '
                                               'For Gmail requests, `startTime` and `endTime` must be provided and the '
                                               'difference must not be greater than 30 days.',
                                'default': None},
                               {'py_name': 'status_filter',
                                'api_name': 'statusFilter',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'string',
                                'enum_values': [],
                                'description': 'Optional. Used to filter on the `statusCode` field present in '
                                               '[`Status`](#status) message. **Usage** ``` '
                                               'GET...&statusFilter=statusCode="200" '
                                               'GET...&statusFilter=statusCode=%22200%22 ```',
                                'default': None}],
              'request_schema_ref': None,
              'response_schema_ref': 'Activities',
              'scopes': ['https://www.googleapis.com/auth/admin.reports.audit.readonly'],
              'supports_media_upload': False,
              'media_upload_path': None,
              'supports_media_download': False},
             {'dotted_path': 'admin_reports.activities.watch',
              'api_dotted_path': 'admin_reports.activities.watch',
              'resource_path': 'activities',
              'py_name': 'watch',
              'api_name': 'watch',
              'http_method': 'POST',
              'path': 'admin/reports/v1/activity/users/{userKey}/applications/{applicationName}/watch',
              'flat_path': 'admin/reports/v1/activity/users/{userKey}/applications/{applicationName}/watch',
              'description': 'Start receiving notifications for account activities. For more information, see '
                             'Receiving Push Notifications.',
              'path_params': [{'py_name': 'application_name',
                               'api_name': 'applicationName',
                               'location': 'path',
                               'required': True,
                               'repeated': False,
                               'type': 'string',
                               'enum_values': ['access_transparency',
                                               'admin',
                                               'calendar',
                                               'chat',
                                               'drive',
                                               'gcp',
                                               'gplus',
                                               'groups',
                                               'groups_enterprise',
                                               'jamboard',
                                               'login',
                                               'meet',
                                               'mobile',
                                               'rules',
                                               'saml',
                                               'token',
                                               'user_accounts',
                                               'context_aware_access',
                                               'chrome',
                                               'data_studio',
                                               'keep',
                                               'classroom'],
                               'description': 'Application name for which the events are to be retrieved.',
                               'default': None},
                              {'py_name': 'user_key',
                               'api_name': 'userKey',
                               'location': 'path',
                               'required': True,
                               'repeated': False,
                               'type': 'string',
                               'enum_values': [],
                               'description': 'Represents the profile ID or the user email for which the data should '
                                              'be filtered. Can be `all` for all information, or `userKey` for a '
                                              "user's unique Google Workspace profile ID or their primary email "
                                              'address. Must not be a deleted user. For a deleted user, call '
                                              '`users.list` in Directory API with `showDeleted=true`, then use the '
                                              'returned `ID` as the `userKey`.',
                               'default': None}],
              'query_params': [{'py_name': 'actor_ip_address',
                                'api_name': 'actorIpAddress',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'string',
                                'enum_values': [],
                                'description': 'The Internet Protocol (IP) Address of host where the event was '
                                               "performed. This is an additional way to filter a report's summary "
                                               'using the IP address of the user whose activity is being reported. '
                                               "This IP address may or may not reflect the user's physical location. "
                                               "For example, the IP address can be the user's proxy server's address "
                                               'or a virtual private network (VPN) address. This parameter supports '
                                               'both IPv4 and IPv6 address versions.',
                                'default': None},
                               {'py_name': 'customer_id',
                                'api_name': 'customerId',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'string',
                                'enum_values': [],
                                'description': 'The unique ID of the customer to retrieve data for.',
                                'default': None},
                               {'py_name': 'end_time',
                                'api_name': 'endTime',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'string',
                                'enum_values': [],
                                'description': 'Sets the end of the range of time shown in the report. The date is in '
                                               'the RFC 3339 format, for example 2010-10-28T10:26:35.000Z. The default '
                                               'value is the approximate time of the API request. An API report has '
                                               "three basic time concepts: - *Date of the API's request for a report*: "
                                               "When the API created and retrieved the report. - *Report's start "
                                               'time*: The beginning of the timespan shown in the report. The '
                                               '`startTime` must be before the `endTime` (if specified) and the '
                                               'current time when the request is made, or the API returns an error. - '
                                               "*Report's end time*: The end of the timespan shown in the report. For "
                                               'example, the timespan of events summarized in a report can start in '
                                               'April and end in May. The report itself can be requested in August. If '
                                               'the `endTime` is not specified, the report returns all activities from '
                                               'the `startTime` until the current time or the most recent 180 days if '
                                               'the `startTime` is more than 180 days in the past.',
                                'default': None},
                               {'py_name': 'event_name',
                                'api_name': 'eventName',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'string',
                                'enum_values': [],
                                'description': 'The name of the event being queried by the API. Each `eventName` is '
                                               'related to a specific Google Workspace service or feature which the '
                                               'API organizes into types of events. An example is the Google Calendar '
                                               "events in the Admin console application's reports. The Calendar "
                                               'Settings `type` structure has all of the Calendar `eventName` '
                                               'activities reported by the API. When an administrator changes a '
                                               'Calendar setting, the API reports this activity in the Calendar '
                                               'Settings `type` and `eventName` parameters. For more information about '
                                               '`eventName` query strings and parameters, see the list of event names '
                                               'for various applications above in `applicationName`.',
                                'default': None},
                               {'py_name': 'filters',
                                'api_name': 'filters',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'string',
                                'enum_values': [],
                                'description': 'The `filters` query string is a comma-separated list composed of event '
                                               'parameters manipulated by relational operators. Event parameters are '
                                               'in the form `{parameter1 name}{relational operator}{parameter1 '
                                               'value},{parameter2 name}{relational operator}{parameter2 value},...` '
                                               'These event parameters are associated with a specific `eventName`. An '
                                               "empty report is returned if the request's parameter doesn't belong to "
                                               'the `eventName`. For more information about the available `eventName` '
                                               'fields for each application and their associated parameters, go to the '
                                               '[ApplicationName](#applicationname) table, then click through to the '
                                               'Activity Events page in the Appendix for the application you want. In '
                                               'the following Drive activity examples, the returned list consists of '
                                               'all `edit` events where the `doc_id` parameter value matches the '
                                               'conditions defined by the relational operator. In the first example, '
                                               'the request returns all edited documents with a `doc_id` value equal '
                                               'to `12345`. In the second example, the report returns any edited '
                                               'documents where the `doc_id` value is not equal to `98765`. The `<>` '
                                               "operator is URL-encoded in the request's query string (`%3C%3E`): ``` "
                                               'GET...&eventName=edit&filters=doc_id==12345 '
                                               'GET...&eventName=edit&filters=doc_id%3C%3E98765 ``` A `filters` query '
                                               "supports these relational operators: * `==`—'equal to'. * `<>`—'not "
                                               "equal to'. Must be URL-encoded (%3C%3E). * `<`—'less than'. Must be "
                                               "URL-encoded (%3C). * `<=`—'less than or equal to'. Must be URL-encoded "
                                               "(%3C=). * `>`—'greater than'. Must be URL-encoded (%3E). * "
                                               "`>=`—'greater than or equal to'. Must be URL-encoded (%3E=). **Note:** "
                                               "The API doesn't accept multiple values of the same parameter. If a "
                                               'parameter is supplied more than once in the API request, the API only '
                                               'accepts the last value of that parameter. In addition, if an invalid '
                                               'parameter is supplied in the API request, the API ignores that '
                                               'parameter and returns the response corresponding to the remaining '
                                               'valid parameters. If no parameters are requested, all parameters are '
                                               'returned.',
                                'default': None},
                               {'py_name': 'group_id_filter',
                                'api_name': 'groupIdFilter',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'string',
                                'enum_values': [],
                                'description': '`Deprecated`. This field is deprecated and is no longer supported. '
                                               'Comma separated group ids (obfuscated) on which user activities are '
                                               'filtered, i.e. the response will contain activities for only those '
                                               'users that are a part of at least one of the group ids mentioned here. '
                                               'Format: "id:abc123,id:xyz456" *Important:* To filter by groups, you '
                                               'must explicitly add the groups to your filtering groups allowlist. For '
                                               'more information about adding groups to filtering groups allowlist, '
                                               'see [Filter results by Google '
                                               'Group](https://support.google.com/a/answer/11482175)',
                                'default': None},
                               {'py_name': 'max_results',
                                'api_name': 'maxResults',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'integer',
                                'enum_values': [],
                                'description': 'Determines how many activity records are shown on each response page. '
                                               'For example, if the request sets `maxResults=1` and the report has two '
                                               "activities, the report has two pages. The response's `nextPageToken` "
                                               'property has the token to the second page. The `maxResults` query '
                                               'string is optional in the request. The default value is 1000.',
                                'default': '1000'},
                               {'py_name': 'org_unit_id',
                                'api_name': 'orgUnitID',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'string',
                                'enum_values': [],
                                'description': '`Deprecated`. This field is deprecated and is no longer supported. ID '
                                               'of the organizational unit to report on. Activity records will be '
                                               'shown only for users who belong to the specified organizational unit. '
                                               "Data before Dec 17, 2018 doesn't appear in the filtered results.",
                                'default': ''},
                               {'py_name': 'page_token',
                                'api_name': 'pageToken',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'string',
                                'enum_values': [],
                                'description': 'The token to specify next page. A report with multiple pages has a '
                                               '`nextPageToken` property in the response. In your follow-on request '
                                               'getting the next page of the report, enter the `nextPageToken` value '
                                               'in the `pageToken` query string.',
                                'default': None},
                               {'py_name': 'start_time',
                                'api_name': 'startTime',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'string',
                                'enum_values': [],
                                'description': 'Sets the beginning of the range of time shown in the report. The date '
                                               'is in the RFC 3339 format, for example 2010-10-28T10:26:35.000Z. The '
                                               'report returns all activities from `startTime` until `endTime`. The '
                                               '`startTime` must be before the `endTime` (if specified) and the '
                                               'current time when the request is made, or the API returns an error.',
                                'default': None}],
              'request_schema_ref': 'Channel',
              'response_schema_ref': 'Channel',
              'scopes': ['https://www.googleapis.com/auth/admin.reports.audit.readonly'],
              'supports_media_upload': False,
              'media_upload_path': None,
              'supports_media_download': False},
             {'dotted_path': 'admin_reports.channels.stop',
              'api_dotted_path': 'admin_reports.channels.stop',
              'resource_path': 'channels',
              'py_name': 'stop',
              'api_name': 'stop',
              'http_method': 'POST',
              'path': 'admin/reports_v1/channels/stop',
              'flat_path': 'admin/reports_v1/channels/stop',
              'description': 'Stop watching resources through this channel.',
              'path_params': [],
              'query_params': [],
              'request_schema_ref': 'Channel',
              'response_schema_ref': None,
              'scopes': ['https://www.googleapis.com/auth/admin.reports.audit.readonly'],
              'supports_media_upload': False,
              'media_upload_path': None,
              'supports_media_download': False},
             {'dotted_path': 'admin_reports.customer_usage_reports.get',
              'api_dotted_path': 'admin_reports.customerUsageReports.get',
              'resource_path': 'customer_usage_reports',
              'py_name': 'get',
              'api_name': 'get',
              'http_method': 'GET',
              'path': 'admin/reports/v1/usage/dates/{date}',
              'flat_path': 'admin/reports/v1/usage/dates/{date}',
              'description': 'Retrieves a report which is a collection of properties and statistics for a specific '
                             "customer's account. For more information, see the Customers Usage Report guide. For more "
                             "information about the customer report's parameters, see the Customers Usage parameters "
                             'reference guides. ',
              'path_params': [{'py_name': 'date',
                               'api_name': 'date',
                               'location': 'path',
                               'required': True,
                               'repeated': False,
                               'type': 'string',
                               'enum_values': [],
                               'description': 'Represents the date the usage occurred, based on UTC-8:00 (Pacific '
                                              'Standard Time). The timestamp is in the [ISO 8601 '
                                              'format](https://en.wikipedia.org/wiki/ISO_8601), `yyyy-mm-dd`.',
                               'default': None}],
              'query_params': [{'py_name': 'customer_id',
                                'api_name': 'customerId',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'string',
                                'enum_values': [],
                                'description': 'The unique ID of the customer to retrieve data for.',
                                'default': None},
                               {'py_name': 'page_token',
                                'api_name': 'pageToken',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'string',
                                'enum_values': [],
                                'description': 'Token to specify next page. A report with multiple pages has a '
                                               '`nextPageToken` property in the response. For your follow-on requests '
                                               "getting all of the report's pages, enter the `nextPageToken` value in "
                                               'the `pageToken` query string.',
                                'default': None},
                               {'py_name': 'parameters',
                                'api_name': 'parameters',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'string',
                                'enum_values': [],
                                'description': 'The `parameters` query string is a comma-separated list of event '
                                               "parameters that refine a report's results. The parameter is associated "
                                               'with a specific application. The application values for the Customers '
                                               'usage report include `accounts`, `app_maker`, `apps_scripts`, '
                                               '`calendar`, `chat`, `classroom`, `cros`, `docs`, `gmail`, `gplus`, '
                                               '`device_management`, `meet`, and `sites`. A `parameters` query string '
                                               'is in the CSV form of `app_name1:param_name1, app_name2:param_name2`. '
                                               "*Note:* The API doesn't accept multiple values of a parameter. If a "
                                               'particular parameter is supplied more than once in the API request, '
                                               'the API only accepts the last value of that request parameter. In '
                                               'addition, if an invalid request parameter is supplied in the API '
                                               'request, the API ignores that request parameter and returns the '
                                               'response corresponding to the remaining valid request parameters. An '
                                               'example of an invalid request parameter is one that does not belong to '
                                               'the application. If no parameters are requested, all parameters are '
                                               'returned. ',
                                'default': None}],
              'request_schema_ref': None,
              'response_schema_ref': 'UsageReports',
              'scopes': ['https://www.googleapis.com/auth/admin.reports.usage.readonly'],
              'supports_media_upload': False,
              'media_upload_path': None,
              'supports_media_download': False},
             {'dotted_path': 'admin_reports.entity_usage_reports.get',
              'api_dotted_path': 'admin_reports.entityUsageReports.get',
              'resource_path': 'entity_usage_reports',
              'py_name': 'get',
              'api_name': 'get',
              'http_method': 'GET',
              'path': 'admin/reports/v1/usage/{entityType}/{entityKey}/dates/{date}',
              'flat_path': 'admin/reports/v1/usage/{entityType}/{entityKey}/dates/{date}',
              'description': 'Retrieves a report which is a collection of properties and statistics for entities used '
                             'by users within the account. For more information, see the Entities Usage Report guide. '
                             "For more information about the entities report's parameters, see the Entities Usage "
                             'parameters reference guides.',
              'path_params': [{'py_name': 'date',
                               'api_name': 'date',
                               'location': 'path',
                               'required': True,
                               'repeated': False,
                               'type': 'string',
                               'enum_values': [],
                               'description': 'Represents the date the usage occurred, based on UTC-8:00 (Pacific '
                                              'Standard Time). The timestamp is in the [ISO 8601 '
                                              'format](https://en.wikipedia.org/wiki/ISO_8601), `yyyy-mm-dd`.',
                               'default': None},
                              {'py_name': 'entity_key',
                               'api_name': 'entityKey',
                               'location': 'path',
                               'required': True,
                               'repeated': False,
                               'type': 'string',
                               'enum_values': [],
                               'description': 'Represents the key of the object to filter the data with. It is a '
                                              'string which can take the value `all` to get activity events for all '
                                              'users, or any other value for an app-specific entity. For details on '
                                              'how to obtain the `entityKey` for a particular `entityType`, see the '
                                              'Entities Usage parameters reference guides.',
                               'default': None},
                              {'py_name': 'entity_type',
                               'api_name': 'entityType',
                               'location': 'path',
                               'required': True,
                               'repeated': False,
                               'type': 'string',
                               'enum_values': ['gplus_communities'],
                               'description': 'Represents the type of entity for the report.',
                               'default': None}],
              'query_params': [{'py_name': 'customer_id',
                                'api_name': 'customerId',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'string',
                                'enum_values': [],
                                'description': 'The unique ID of the customer to retrieve data for.',
                                'default': None},
                               {'py_name': 'filters',
                                'api_name': 'filters',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'string',
                                'enum_values': [],
                                'description': 'The `filters` query string is a comma-separated list of an '
                                               "application's event parameters where the parameter's value is "
                                               'manipulated by a relational operator. The `filters` query string '
                                               'includes the name of the application whose usage is returned in the '
                                               'report. The application values for the Entities usage report include '
                                               '`accounts`, `docs`, and `gmail`. Filters are in the form `[application '
                                               'name]:parameter name[parameter value],...`. In this example, the `<>` '
                                               "'not equal to' operator is URL-encoded in the request's query string "
                                               '(%3C%3E): GET '
                                               'https://www.googleapis.com/admin/reports/v1/usage/gplus_communities/all/dates/2017-12-01 '
                                               '?parameters=gplus:community_name,gplus:num_total_members '
                                               '&filters=gplus:num_total_members%3C%3E0 The relational operators '
                                               "include: - `==` - 'equal to'. - `<>` - 'not equal to'. It is "
                                               "URL-encoded (%3C%3E). - `<` - 'less than'. It is URL-encoded (%3C). - "
                                               "`<=` - 'less than or equal to'. It is URL-encoded (%3C=). - `>` - "
                                               "'greater than'. It is URL-encoded (%3E). - `>=` - 'greater than or "
                                               "equal to'. It is URL-encoded (%3E=). Filters can only be applied to "
                                               'numeric parameters.',
                                'default': None},
                               {'py_name': 'max_results',
                                'api_name': 'maxResults',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'integer',
                                'enum_values': [],
                                'description': 'Determines how many activity records are shown on each response page. '
                                               'For example, if the request sets `maxResults=1` and the report has two '
                                               "activities, the report has two pages. The response's `nextPageToken` "
                                               'property has the token to the second page.',
                                'default': '1000'},
                               {'py_name': 'page_token',
                                'api_name': 'pageToken',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'string',
                                'enum_values': [],
                                'description': 'Token to specify next page. A report with multiple pages has a '
                                               '`nextPageToken` property in the response. In your follow-on request '
                                               'getting the next page of the report, enter the `nextPageToken` value '
                                               'in the `pageToken` query string.',
                                'default': None},
                               {'py_name': 'parameters',
                                'api_name': 'parameters',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'string',
                                'enum_values': [],
                                'description': 'The `parameters` query string is a comma-separated list of event '
                                               "parameters that refine a report's results. The parameter is associated "
                                               'with a specific application. The application values for the Entities '
                                               'usage report are only `gplus`. A `parameter` query string is in the '
                                               'CSV form of `[app_name1:param_name1], [app_name2:param_name2]...`. '
                                               "*Note:* The API doesn't accept multiple values of a parameter. If a "
                                               'particular parameter is supplied more than once in the API request, '
                                               'the API only accepts the last value of that request parameter. In '
                                               'addition, if an invalid request parameter is supplied in the API '
                                               'request, the API ignores that request parameter and returns the '
                                               'response corresponding to the remaining valid request parameters. An '
                                               'example of an invalid request parameter is one that does not belong to '
                                               'the application. If no parameters are requested, all parameters are '
                                               'returned. ',
                                'default': None}],
              'request_schema_ref': None,
              'response_schema_ref': 'UsageReports',
              'scopes': ['https://www.googleapis.com/auth/admin.reports.usage.readonly'],
              'supports_media_upload': False,
              'media_upload_path': None,
              'supports_media_download': False},
             {'dotted_path': 'admin_reports.user_usage_report.get',
              'api_dotted_path': 'admin_reports.userUsageReport.get',
              'resource_path': 'user_usage_report',
              'py_name': 'get',
              'api_name': 'get',
              'http_method': 'GET',
              'path': 'admin/reports/v1/usage/users/{userKey}/dates/{date}',
              'flat_path': 'admin/reports/v1/usage/users/{userKey}/dates/{date}',
              'description': 'Retrieves a report which is a collection of properties and statistics for a set of users '
                             'with the account. For more information, see the User Usage Report guide. For more '
                             "information about the user report's parameters, see the Users Usage parameters reference "
                             'guides.',
              'path_params': [{'py_name': 'date',
                               'api_name': 'date',
                               'location': 'path',
                               'required': True,
                               'repeated': False,
                               'type': 'string',
                               'enum_values': [],
                               'description': 'Represents the date the usage occurred, based on UTC-8:00 (Pacific '
                                              'Standard Time). The timestamp is in the [ISO 8601 '
                                              'format](https://en.wikipedia.org/wiki/ISO_8601), `yyyy-mm-dd`.',
                               'default': None},
                              {'py_name': 'user_key',
                               'api_name': 'userKey',
                               'location': 'path',
                               'required': True,
                               'repeated': False,
                               'type': 'string',
                               'enum_values': [],
                               'description': 'Represents the profile ID or the user email for which the data should '
                                              'be filtered. Can be `all` for all information, or `userKey` for a '
                                              "user's unique Google Workspace profile ID or their primary email "
                                              'address. Must not be a deleted user. For a deleted user, call '
                                              '`users.list` in Directory API with `showDeleted=true`, then use the '
                                              'returned `ID` as the `userKey`.',
                               'default': None}],
              'query_params': [{'py_name': 'customer_id',
                                'api_name': 'customerId',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'string',
                                'enum_values': [],
                                'description': 'The unique ID of the customer to retrieve data for.',
                                'default': None},
                               {'py_name': 'filters',
                                'api_name': 'filters',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'string',
                                'enum_values': [],
                                'description': 'The `filters` query string is a comma-separated list of an '
                                               "application's event parameters where the parameter's value is "
                                               'manipulated by a relational operator. The `filters` query string '
                                               'includes the name of the application whose usage is returned in the '
                                               'report. The application values for the Users Usage Report include '
                                               '`accounts`, `chat`, `docs`, and `gmail`. Filters are in the form '
                                               '`[application name]:parameter name[parameter value],...`. In this '
                                               "example, the `<>` 'not equal to' operator is URL-encoded in the "
                                               "request's query string (%3C%3E): GET "
                                               'https://www.googleapis.com/admin/reports/v1/usage/users/all/dates/2013-03-03 '
                                               '?parameters=accounts:last_login_time '
                                               '&filters=accounts:last_login_time%3C%3E2010-10-28T10:26:35.000Z The '
                                               "relational operators include: - `==` - 'equal to'. - `<>` - 'not equal "
                                               "to'. It is URL-encoded (%3C%3E). - `<` - 'less than'. It is "
                                               "URL-encoded (%3C). - `<=` - 'less than or equal to'. It is URL-encoded "
                                               "(%3C=). - `>` - 'greater than'. It is URL-encoded (%3E). - `>=` - "
                                               "'greater than or equal to'. It is URL-encoded (%3E=). ",
                                'default': None},
                               {'py_name': 'group_id_filter',
                                'api_name': 'groupIdFilter',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'string',
                                'enum_values': [],
                                'description': 'Comma separated group ids (obfuscated) on which user activities are '
                                               'filtered, i.e. the response will contain activities for only those '
                                               'users that are a part of at least one of the group ids mentioned here. '
                                               'Format: "id:abc123,id:xyz456"',
                                'default': None},
                               {'py_name': 'max_results',
                                'api_name': 'maxResults',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'integer',
                                'enum_values': [],
                                'description': 'Determines how many activity records are shown on each response page. '
                                               'For example, if the request sets `maxResults=1` and the report has two '
                                               "activities, the report has two pages. The response's `nextPageToken` "
                                               'property has the token to the second page. The `maxResults` query '
                                               'string is optional.',
                                'default': '1000'},
                               {'py_name': 'org_unit_id',
                                'api_name': 'orgUnitID',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'string',
                                'enum_values': [],
                                'description': 'ID of the organizational unit to report on. User activity will be '
                                               'shown only for users who belong to the specified organizational unit. '
                                               "Data before Dec 17, 2018 doesn't appear in the filtered results.",
                                'default': ''},
                               {'py_name': 'page_token',
                                'api_name': 'pageToken',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'string',
                                'enum_values': [],
                                'description': 'Token to specify next page. A report with multiple pages has a '
                                               '`nextPageToken` property in the response. In your follow-on request '
                                               'getting the next page of the report, enter the `nextPageToken` value '
                                               'in the `pageToken` query string.',
                                'default': None},
                               {'py_name': 'parameters',
                                'api_name': 'parameters',
                                'location': 'query',
                                'required': False,
                                'repeated': False,
                                'type': 'string',
                                'enum_values': [],
                                'description': 'The `parameters` query string is a comma-separated list of event '
                                               "parameters that refine a report's results. The parameter is associated "
                                               'with a specific application. The application values for the Customers '
                                               'Usage report include `accounts`, `app_maker`, `apps_scripts`, '
                                               '`calendar`, `chat`, `classroom`, `cros`, `docs`, `gmail`, `gplus`, '
                                               '`device_management`, `meet`, and `sites`. A `parameters` query string '
                                               'is in the CSV form of `app_name1:param_name1, app_name2:param_name2`. '
                                               "*Note:* The API doesn't accept multiple values of a parameter. If a "
                                               'particular parameter is supplied more than once in the API request, '
                                               'the API only accepts the last value of that request parameter. In '
                                               'addition, if an invalid request parameter is supplied in the API '
                                               'request, the API ignores that request parameter and returns the '
                                               'response corresponding to the remaining valid request parameters. An '
                                               'example of an invalid request parameter is one that does not belong to '
                                               'the application. If no parameters are requested, all parameters are '
                                               'returned. ',
                                'default': None}],
              'request_schema_ref': None,
              'response_schema_ref': 'UsageReports',
              'scopes': ['https://www.googleapis.com/auth/admin.reports.usage.readonly'],
              'supports_media_upload': False,
              'media_upload_path': None,
              'supports_media_download': False}],
 'schemas': {'Activities': {'description': 'JSON template for a collection of activities.',
                            'id': 'Activities',
                            'properties': {'etag': {'description': 'ETag of the resource.', 'type': 'string'},
                                           'items': {'description': 'Each activity record in the response.',
                                                     'items': {'$ref': 'Activity'},
                                                     'type': 'array'},
                                           'kind': {'default': 'admin#reports#activities',
                                                    'description': 'The type of API resource. For an activity report, '
                                                                   'the value is `reports#activities`.',
                                                    'type': 'string'},
                                           'nextPageToken': {'description': 'Token for retrieving the follow-on next '
                                                                            'page of the report. The `nextPageToken` '
                                                                            "value is used in the request's "
                                                                            '`pageToken` query string.',
                                                             'type': 'string'}},
                            'type': 'object'},
             'Activity': {'description': 'JSON template for the activity resource.',
                          'id': 'Activity',
                          'properties': {'actor': {'description': 'User doing the action.',
                                                   'properties': {'applicationInfo': {'description': 'Details of the '
                                                                                                     'application that '
                                                                                                     'was the actor '
                                                                                                     'for the '
                                                                                                     'activity.',
                                                                                      'properties': {'applicationName': {'description': 'Name '
                                                                                                                                        'of '
                                                                                                                                        'the '
                                                                                                                                        'application '
                                                                                                                                        'used '
                                                                                                                                        'to '
                                                                                                                                        'perform '
                                                                                                                                        'the '
                                                                                                                                        'action.',
                                                                                                                         'type': 'string'},
                                                                                                     'impersonation': {'description': 'Whether '
                                                                                                                                      'the '
                                                                                                                                      'application '
                                                                                                                                      'was '
                                                                                                                                      'impersonating '
                                                                                                                                      'a '
                                                                                                                                      'user.',
                                                                                                                       'type': 'boolean'},
                                                                                                     'oauthClientId': {'description': 'OAuth '
                                                                                                                                      'client '
                                                                                                                                      'id '
                                                                                                                                      'of '
                                                                                                                                      'the '
                                                                                                                                      'third '
                                                                                                                                      'party '
                                                                                                                                      'application '
                                                                                                                                      'used '
                                                                                                                                      'to '
                                                                                                                                      'perform '
                                                                                                                                      'the '
                                                                                                                                      'action.',
                                                                                                                       'type': 'string'}},
                                                                                      'type': 'object'},
                                                                  'callerType': {'description': 'The type of actor.',
                                                                                 'type': 'string'},
                                                                  'email': {'description': 'The primary email address '
                                                                                           'of the actor. May be '
                                                                                           'absent if there is no '
                                                                                           'email address associated '
                                                                                           'with the actor.',
                                                                            'type': 'string'},
                                                                  'key': {'description': 'Only present when '
                                                                                         '`callerType` is `KEY`. Can '
                                                                                         'be the `consumer_key` of the '
                                                                                         'requestor for OAuth 2LO API '
                                                                                         'requests or an identifier '
                                                                                         'for robot accounts.',
                                                                          'type': 'string'},
                                                                  'profileId': {'description': 'The unique Google '
                                                                                               'Workspace profile ID '
                                                                                               'of the actor. This '
                                                                                               'value might be absent '
                                                                                               'if the actor is not a '
                                                                                               'Google Workspace user, '
                                                                                               'or may be the number '
                                                                                               '105250506097979753968 '
                                                                                               'which acts as a '
                                                                                               'placeholder ID.',
                                                                                'type': 'string'}},
                                                   'type': 'object'},
                                         'etag': {'description': 'ETag of the entry.', 'type': 'string'},
                                         'events': {'description': 'Activity events in the report.',
                                                    'items': {'properties': {'name': {'description': 'Name of the '
                                                                                                     'event. This is '
                                                                                                     'the specific '
                                                                                                     'name of the '
                                                                                                     'activity '
                                                                                                     'reported by the '
                                                                                                     'API. And each '
                                                                                                     '`eventName` is '
                                                                                                     'related to a '
                                                                                                     'specific Google '
                                                                                                     'Workspace '
                                                                                                     'service or '
                                                                                                     'feature which '
                                                                                                     'the API '
                                                                                                     'organizes into '
                                                                                                     'types of events. '
                                                                                                     'For `eventName` '
                                                                                                     'request '
                                                                                                     'parameters in '
                                                                                                     'general: - If no '
                                                                                                     '`eventName` is '
                                                                                                     'given, the '
                                                                                                     'report returns '
                                                                                                     'all possible '
                                                                                                     'instances of an '
                                                                                                     '`eventName`. - '
                                                                                                     'When you request '
                                                                                                     'an `eventName`, '
                                                                                                     "the API's "
                                                                                                     'response returns '
                                                                                                     'all activities '
                                                                                                     'which contain '
                                                                                                     'that '
                                                                                                     '`eventName`. For '
                                                                                                     'more information '
                                                                                                     'about '
                                                                                                     '`eventName` '
                                                                                                     'properties, see '
                                                                                                     'the list of '
                                                                                                     'event names for '
                                                                                                     'various '
                                                                                                     'applications '
                                                                                                     'above in '
                                                                                                     '`applicationName`.',
                                                                                      'type': 'string'},
                                                                             'parameters': {'description': 'Parameter '
                                                                                                           'value '
                                                                                                           'pairs for '
                                                                                                           'various '
                                                                                                           'applications. '
                                                                                                           'For more '
                                                                                                           'information '
                                                                                                           'about '
                                                                                                           '`eventName` '
                                                                                                           'parameters, '
                                                                                                           'see the '
                                                                                                           'list of '
                                                                                                           'event '
                                                                                                           'names for '
                                                                                                           'various '
                                                                                                           'applications '
                                                                                                           'above in '
                                                                                                           '`applicationName`.',
                                                                                            'items': {'properties': {'boolValue': {'description': 'Boolean '
                                                                                                                                                  'value '
                                                                                                                                                  'of '
                                                                                                                                                  'the '
                                                                                                                                                  'parameter.',
                                                                                                                                   'type': 'boolean'},
                                                                                                                     'intValue': {'description': 'Integer '
                                                                                                                                                 'value '
                                                                                                                                                 'of '
                                                                                                                                                 'the '
                                                                                                                                                 'parameter.',
                                                                                                                                  'format': 'int64',
                                                                                                                                  'type': 'string'},
                                                                                                                     'messageValue': {'description': 'Nested '
                                                                                                                                                     'parameter '
                                                                                                                                                     'value '
                                                                                                                                                     'pairs '
                                                                                                                                                     'associated '
                                                                                                                                                     'with '
                                                                                                                                                     'this '
                                                                                                                                                     'parameter. '
                                                                                                                                                     'Complex '
                                                                                                                                                     'value '
                                                                                                                                                     'type '
                                                                                                                                                     'for '
                                                                                                                                                     'a '
                                                                                                                                                     'parameter '
                                                                                                                                                     'are '
                                                                                                                                                     'returned '
                                                                                                                                                     'as '
                                                                                                                                                     'a '
                                                                                                                                                     'list '
                                                                                                                                                     'of '
                                                                                                                                                     'parameter '
                                                                                                                                                     'values. '
                                                                                                                                                     'For '
                                                                                                                                                     'example, '
                                                                                                                                                     'the '
                                                                                                                                                     'address '
                                                                                                                                                     'parameter '
                                                                                                                                                     'may '
                                                                                                                                                     'have '
                                                                                                                                                     'a '
                                                                                                                                                     'value '
                                                                                                                                                     'as '
                                                                                                                                                     '`[{parameter: '
                                                                                                                                                     '[{name: '
                                                                                                                                                     'city, '
                                                                                                                                                     'value: '
                                                                                                                                                     'abc}]}]`',
                                                                                                                                      'properties': {'parameter': {'description': 'Parameter '
                                                                                                                                                                                  'values',
                                                                                                                                                                   'items': {'$ref': 'NestedParameter'},
                                                                                                                                                                   'type': 'array'}},
                                                                                                                                      'type': 'object'},
                                                                                                                     'multiIntValue': {'description': 'Integer '
                                                                                                                                                      'values '
                                                                                                                                                      'of '
                                                                                                                                                      'the '
                                                                                                                                                      'parameter.',
                                                                                                                                       'items': {'format': 'int64',
                                                                                                                                                 'type': 'string'},
                                                                                                                                       'type': 'array'},
                                                                                                                     'multiMessageValue': {'description': 'List '
                                                                                                                                                          'of '
                                                                                                                                                          '`messageValue` '
                                                                                                                                                          'objects.',
                                                                                                                                           'items': {'properties': {'parameter': {'description': 'Parameter '
                                                                                                                                                                                                 'values',
                                                                                                                                                                                  'items': {'$ref': 'NestedParameter'},
                                                                                                                                                                                  'type': 'array'}},
                                                                                                                                                     'type': 'object'},
                                                                                                                                           'type': 'array'},
                                                                                                                     'multiValue': {'description': 'String '
                                                                                                                                                   'values '
                                                                                                                                                   'of '
                                                                                                                                                   'the '
                                                                                                                                                   'parameter.',
                                                                                                                                    'items': {'type': 'string'},
                                                                                                                                    'type': 'array'},
                                                                                                                     'name': {'description': 'The '
                                                                                                                                             'name '
                                                                                                                                             'of '
                                                                                                                                             'the '
                                                                                                                                             'parameter.',
                                                                                                                              'type': 'string'},
                                                                                                                     'value': {'description': 'String '
                                                                                                                                              'value '
                                                                                                                                              'of '
                                                                                                                                              'the '
                                                                                                                                              'parameter.',
                                                                                                                               'type': 'string'}},
                                                                                                      'type': 'object'},
                                                                                            'type': 'array'},
                                                                             'resourceIds': {'description': 'Resource '
                                                                                                            'ids '
                                                                                                            'associated '
                                                                                                            'with the '
                                                                                                            'event.',
                                                                                             'items': {'type': 'string'},
                                                                                             'type': 'array'},
                                                                             'status': {'$ref': 'ActivityEventsStatus',
                                                                                        'description': 'Status of the '
                                                                                                       'event. Note: '
                                                                                                       'Not all events '
                                                                                                       'have status.'},
                                                                             'type': {'description': 'Type of event. '
                                                                                                     'The Google '
                                                                                                     'Workspace '
                                                                                                     'service or '
                                                                                                     'feature that an '
                                                                                                     'administrator '
                                                                                                     'changes is '
                                                                                                     'identified in '
                                                                                                     'the `type` '
                                                                                                     'property which '
                                                                                                     'identifies an '
                                                                                                     'event using the '
                                                                                                     '`eventName` '
                                                                                                     'property. For a '
                                                                                                     'full list of the '
                                                                                                     "API's `type` "
                                                                                                     'categories, see '
                                                                                                     'the list of '
                                                                                                     'event names for '
                                                                                                     'various '
                                                                                                     'applications '
                                                                                                     'above in '
                                                                                                     '`applicationName`.',
                                                                                      'type': 'string'}},
                                                              'type': 'object'},
                                                    'type': 'array'},
                                         'id': {'description': 'Unique identifier for each activity record.',
                                                'properties': {'applicationName': {'description': 'Application name to '
                                                                                                  'which the event '
                                                                                                  'belongs. For '
                                                                                                  'possible values see '
                                                                                                  'the list of '
                                                                                                  'applications above '
                                                                                                  'in '
                                                                                                  '`applicationName`.',
                                                                                   'type': 'string'},
                                                               'customerId': {'description': 'The unique identifier '
                                                                                             'for a Google Workspace '
                                                                                             'account.',
                                                                              'type': 'string'},
                                                               'time': {'description': 'Time of occurrence of the '
                                                                                       'activity. This is in UNIX '
                                                                                       'epoch time in seconds.',
                                                                        'format': 'date-time',
                                                                        'type': 'string'},
                                                               'uniqueQualifier': {'description': 'Unique qualifier if '
                                                                                                  'multiple events '
                                                                                                  'have the same time.',
                                                                                   'format': 'int64',
                                                                                   'type': 'string'}},
                                                'type': 'object'},
                                         'ipAddress': {'description': 'IP address of the user doing the action. This '
                                                                      'is the Internet Protocol (IP) address of the '
                                                                      'user when logging into Google Workspace, which '
                                                                      "may or may not reflect the user's physical "
                                                                      'location. For example, the IP address can be '
                                                                      "the user's proxy server's address or a virtual "
                                                                      'private network (VPN) address. The API supports '
                                                                      'IPv4 and IPv6.',
                                                       'type': 'string'},
                                         'kind': {'default': 'admin#reports#activity',
                                                  'description': 'The type of API resource. For an activity report, '
                                                                 'the value is `audit#activity`.',
                                                  'type': 'string'},
                                         'networkInfo': {'$ref': 'ActivityNetworkInfo',
                                                         'description': 'Network information of the user doing the '
                                                                        'action.'},
                                         'ownerDomain': {'description': 'This is the domain that is affected by the '
                                                                        "report's event. For example domain of Admin "
                                                                        "console or the Drive application's document "
                                                                        'owner.',
                                                         'type': 'string'},
                                         'resourceDetails': {'description': 'Details of the resource on which the '
                                                                            'action was performed.',
                                                             'items': {'$ref': 'ResourceDetails'},
                                                             'type': 'array'}},
                          'type': 'object'},
             'ActivityEventsStatus': {'description': 'Status of the event. Note: Not all events have status.',
                                      'id': 'ActivityEventsStatus',
                                      'properties': {'errorCode': {'description': 'Error code of the event. Note: '
                                                                                  'Field can be empty.',
                                                                   'type': 'string'},
                                                     'errorMessage': {'description': 'Error message of the event. '
                                                                                     'Note: Field can be empty.',
                                                                      'type': 'string'},
                                                     'eventStatus': {'description': 'Status of the event. Possible '
                                                                                    'values if not empty: - '
                                                                                    'UNKNOWN_EVENT_STATUS - SUCCEEDED '
                                                                                    '- SUCCEEDED_WITH_WARNINGS - '
                                                                                    'FAILED - SKIPPED ',
                                                                     'type': 'string'},
                                                     'httpStatusCode': {'description': 'Status code of the event. '
                                                                                       'Note: Field can be empty.',
                                                                        'format': 'int32',
                                                                        'type': 'integer'}},
                                      'type': 'object'},
             'ActivityNetworkInfo': {'description': 'Network information of the user doing the action.',
                                     'id': 'ActivityNetworkInfo',
                                     'properties': {'ipAsn': {'description': 'IP Address of the user doing the action.',
                                                              'items': {'format': 'int32', 'type': 'integer'},
                                                              'type': 'array'},
                                                    'regionCode': {'description': 'ISO 3166-1 alpha-2 region code of '
                                                                                  'the user doing the action.',
                                                                   'type': 'string'},
                                                    'subdivisionCode': {'description': 'ISO 3166-2 region code (states '
                                                                                       'and provinces) for countries '
                                                                                       'of the user doing the action.',
                                                                        'type': 'string'}},
                                     'type': 'object'},
             'AppliedLabel': {'description': 'Details of the label applied on the resource.',
                              'id': 'AppliedLabel',
                              'properties': {'fieldValues': {'description': 'List of fields which are part of the '
                                                                            'label and have been set by the user. If '
                                                                            'label has a field which was not set by '
                                                                            'the user, it would not be present in this '
                                                                            'list.',
                                                             'items': {'$ref': 'FieldValue'},
                                                             'type': 'array'},
                                             'id': {'description': 'Identifier of the label - Only the label id, not '
                                                                   'the full OnePlatform resource name.',
                                                    'type': 'string'},
                                             'reason': {'$ref': 'Reason',
                                                        'description': 'The reason why the label was applied on the '
                                                                       'resource.'},
                                             'title': {'description': 'Title of the label', 'type': 'string'}},
                              'type': 'object'},
             'Channel': {'description': 'A notification channel used to watch for resource changes.',
                         'id': 'Channel',
                         'properties': {'address': {'description': 'The address where notifications are delivered for '
                                                                   'this channel.',
                                                    'type': 'string'},
                                        'expiration': {'description': 'Date and time of notification channel '
                                                                      'expiration, expressed as a Unix timestamp, in '
                                                                      'milliseconds. Optional.',
                                                       'format': 'int64',
                                                       'type': 'string'},
                                        'id': {'description': 'A UUID or similar unique string that identifies this '
                                                              'channel.',
                                               'type': 'string'},
                                        'kind': {'default': 'api#channel',
                                                 'description': 'Identifies this as a notification channel used to '
                                                                'watch for changes to a resource, which is '
                                                                '"`api#channel`".',
                                                 'type': 'string'},
                                        'params': {'additionalProperties': {'type': 'string'},
                                                   'description': 'Additional parameters controlling delivery channel '
                                                                  'behavior. Optional.',
                                                   'type': 'object'},
                                        'payload': {'description': 'A Boolean value to indicate whether payload is '
                                                                   'wanted. A payload is data that is sent in the body '
                                                                   'of an HTTP POST, PUT, or PATCH message and '
                                                                   'contains important information about the request. '
                                                                   'Optional.',
                                                    'type': 'boolean'},
                                        'resourceId': {'description': 'An opaque ID that identifies the resource being '
                                                                      'watched on this channel. Stable across '
                                                                      'different API versions.',
                                                       'type': 'string'},
                                        'resourceUri': {'description': 'A version-specific identifier for the watched '
                                                                       'resource.',
                                                        'type': 'string'},
                                        'token': {'description': 'An arbitrary string delivered to the target address '
                                                                 'with each notification delivered over this channel. '
                                                                 'Optional.',
                                                  'type': 'string'},
                                        'type': {'description': 'The type of delivery mechanism used for this channel. '
                                                                'The value should be set to `"web_hook"`.',
                                                 'type': 'string'}},
                         'type': 'object'},
             'CustomerIdentity': {'description': 'Identity of the Google Workspace customer who owns the resource.',
                                  'id': 'CustomerIdentity',
                                  'properties': {'id': {'description': 'Customer id.', 'type': 'string'}},
                                  'type': 'object'},
             'Date': {'description': 'Represents a whole or partial calendar date, such as a birthday. The time of day '
                                     'and time zone are either specified elsewhere or are insignificant. The date is '
                                     'relative to the Gregorian Calendar. This can represent one of the following: * A '
                                     'full date, with non-zero year, month, and day values. * A month and day, with a '
                                     'zero year (for example, an anniversary). * A year on its own, with a zero month '
                                     'and a zero day. * A year and month, with a zero day (for example, a credit card '
                                     'expiration date). Related types: * google.type.TimeOfDay * google.type.DateTime '
                                     '* google.protobuf.Timestamp',
                      'id': 'Date',
                      'properties': {'day': {'description': 'Day of a month. Must be from 1 to 31 and valid for the '
                                                            'year and month, or 0 to specify a year by itself or a '
                                                            "year and month where the day isn't significant.",
                                             'format': 'int32',
                                             'type': 'integer'},
                                     'month': {'description': 'Month of a year. Must be from 1 to 12, or 0 to specify '
                                                              'a year without a month and day.',
                                               'format': 'int32',
                                               'type': 'integer'},
                                     'year': {'description': 'Year of the date. Must be from 1 to 9999, or 0 to '
                                                             'specify a date without a year.',
                                              'format': 'int32',
                                              'type': 'integer'}},
                      'type': 'object'},
             'FieldValue': {'description': 'Details of the field value set by the user for the particular label.',
                            'id': 'FieldValue',
                            'properties': {'dateValue': {'$ref': 'Date', 'description': 'Setting a date value.'},
                                           'displayName': {'description': 'Display name of the field',
                                                           'type': 'string'},
                                           'id': {'description': 'Identifier of the field', 'type': 'string'},
                                           'integerValue': {'description': 'Setting an integer value.',
                                                            'format': 'int64',
                                                            'type': 'string'},
                                           'longTextValue': {'description': 'Setting a long text value.',
                                                             'type': 'string'},
                                           'reason': {'$ref': 'Reason',
                                                      'description': 'The reason why the field was applied to the '
                                                                     'label.'},
                                           'selectionListValue': {'$ref': 'FieldValueSelectionListValue',
                                                                  'description': 'Setting a selection list value by '
                                                                                 'selecting multiple values from a '
                                                                                 'dropdown.'},
                                           'selectionValue': {'$ref': 'FieldValueSelectionValue',
                                                              'description': 'Setting a selection value by selecting a '
                                                                             'single value from a dropdown.'},
                                           'textListValue': {'$ref': 'FieldValueTextListValue',
                                                             'description': 'Setting a text list value.'},
                                           'textValue': {'description': 'Setting a text value.', 'type': 'string'},
                                           'type': {'description': 'Type of the field', 'type': 'string'},
                                           'unsetValue': {'description': 'If the field is unset, this will be true.',
                                                          'type': 'boolean'},
                                           'userListValue': {'$ref': 'FieldValueUserListValue',
                                                             'description': 'Setting a user list value by selecting '
                                                                            'multiple users.'},
                                           'userValue': {'$ref': 'FieldValueUserValue',
                                                         'description': 'Setting a user value by selecting a single '
                                                                        'user.'}},
                            'type': 'object'},
             'FieldValueSelectionListValue': {'description': 'Setting a selection list value by selecting multiple '
                                                             'values from a dropdown.',
                                              'id': 'FieldValueSelectionListValue',
                                              'properties': {'values': {'description': 'List of selections.',
                                                                        'items': {'$ref': 'FieldValueSelectionValue'},
                                                                        'type': 'array'}},
                                              'type': 'object'},
             'FieldValueSelectionValue': {'description': 'Setting a selection value by selecting a single value from a '
                                                         'dropdown.',
                                          'id': 'FieldValueSelectionValue',
                                          'properties': {'badged': {'description': 'Whether the selection is badged.',
                                                                    'type': 'boolean'},
                                                         'displayName': {'description': 'Display name of the '
                                                                                        'selection.',
                                                                         'type': 'string'},
                                                         'id': {'description': 'Identifier of the selection.',
                                                                'type': 'string'}},
                                          'type': 'object'},
             'FieldValueTextListValue': {'description': 'Setting a text list value.',
                                         'id': 'FieldValueTextListValue',
                                         'properties': {'values': {'description': 'List of text values.',
                                                                   'items': {'type': 'string'},
                                                                   'type': 'array'}},
                                         'type': 'object'},
             'FieldValueUserListValue': {'description': 'Setting a user list value by selecting multiple users.',
                                         'id': 'FieldValueUserListValue',
                                         'properties': {'values': {'description': 'List of users.',
                                                                   'items': {'$ref': 'FieldValueUserValue'},
                                                                   'type': 'array'}},
                                         'type': 'object'},
             'FieldValueUserValue': {'description': 'Setting a user value by selecting a single user.',
                                     'id': 'FieldValueUserValue',
                                     'properties': {'email': {'description': 'Email of the user.', 'type': 'string'}},
                                     'type': 'object'},
             'GroupIdentity': {'description': 'Identity of the group who owns the resource.',
                               'id': 'GroupIdentity',
                               'properties': {'groupEmail': {'description': 'Group email.', 'type': 'string'},
                                              'id': {'description': 'Group gaia id.', 'type': 'string'}},
                               'type': 'object'},
             'NestedParameter': {'description': 'JSON template for a parameter used in various reports.',
                                 'id': 'NestedParameter',
                                 'properties': {'boolValue': {'description': 'Boolean value of the parameter.',
                                                              'type': 'boolean'},
                                                'intValue': {'description': 'Integer value of the parameter.',
                                                             'format': 'int64',
                                                             'type': 'string'},
                                                'multiBoolValue': {'description': 'Multiple boolean values of the '
                                                                                  'parameter.',
                                                                   'items': {'type': 'boolean'},
                                                                   'type': 'array'},
                                                'multiIntValue': {'description': 'Multiple integer values of the '
                                                                                 'parameter.',
                                                                  'items': {'format': 'int64', 'type': 'string'},
                                                                  'type': 'array'},
                                                'multiValue': {'description': 'Multiple string values of the '
                                                                              'parameter.',
                                                               'items': {'type': 'string'},
                                                               'type': 'array'},
                                                'name': {'description': 'The name of the parameter.', 'type': 'string'},
                                                'value': {'description': 'String value of the parameter.',
                                                          'type': 'string'}},
                                 'type': 'object'},
             'OwnerDetails': {'description': 'Details of the owner of the resource.',
                              'id': 'OwnerDetails',
                              'properties': {'ownerIdentity': {'description': 'Identity details of the owner(s) of the '
                                                                              'resource.',
                                                               'items': {'$ref': 'OwnerIdentity'},
                                                               'type': 'array'},
                                             'ownerType': {'description': 'Type of the owner of the resource.',
                                                           'type': 'string'}},
                              'type': 'object'},
             'OwnerIdentity': {'description': 'Identity details of the owner of the resource.',
                               'id': 'OwnerIdentity',
                               'properties': {'customerIdentity': {'$ref': 'CustomerIdentity',
                                                                   'description': 'Identity of the Google Workspace '
                                                                                  'customer who owns the resource.'},
                                              'groupIdentity': {'$ref': 'GroupIdentity',
                                                                'description': 'Identity of the group who owns the '
                                                                               'resource.'},
                                              'userIdentity': {'$ref': 'UserIdentity',
                                                               'description': 'Identity of the user who owns the '
                                                                              'resource.'}},
                               'type': 'object'},
             'Reason': {'description': 'The reason why the label/field was applied.',
                        'id': 'Reason',
                        'properties': {'reasonType': {'description': 'The type of the reason.', 'type': 'string'}},
                        'type': 'object'},
             'ResourceDetails': {'description': 'Details of the resource on which the action was performed.',
                                 'id': 'ResourceDetails',
                                 'properties': {'appliedLabels': {'description': 'List of labels applied on the '
                                                                                 'resource',
                                                                  'items': {'$ref': 'AppliedLabel'},
                                                                  'type': 'array'},
                                                'id': {'description': 'Identifier of the resource, such as a doc_id '
                                                                      'for a Drive document, a conference_id for a '
                                                                      'Meet conference, or a '
                                                                      '"gaia_id/rfc2822_message_id" for an email.',
                                                       'type': 'string'},
                                                'ownerDetails': {'$ref': 'OwnerDetails',
                                                                 'description': 'Owner details of the resource.'},
                                                'relation': {'description': 'Defines relationship of the resource to '
                                                                            'the events',
                                                             'type': 'string'},
                                                'title': {'description': 'Title of the resource. For instance, in case '
                                                                         'of a drive document, this would be the title '
                                                                         'of the document. In case of an email, this '
                                                                         'would be the subject.',
                                                          'type': 'string'},
                                                'type': {'description': 'Type of the resource - document, email, chat '
                                                                        'message',
                                                         'type': 'string'}},
                                 'type': 'object'},
             'UsageReport': {'description': 'JSON template for a usage report.',
                             'id': 'UsageReport',
                             'properties': {'date': {'description': 'Output only. The date of the report request.',
                                                     'readOnly': True,
                                                     'type': 'string'},
                                            'entity': {'description': 'Output only. Information about the type of the '
                                                                      'item.',
                                                       'properties': {'customerId': {'description': 'Output only. The '
                                                                                                    'unique identifier '
                                                                                                    "of the customer's "
                                                                                                    'account.',
                                                                                     'readOnly': True,
                                                                                     'type': 'string'},
                                                                      'entityId': {'description': 'Output only. Object '
                                                                                                  'key. Only relevant '
                                                                                                  'if entity.type = '
                                                                                                  '"OBJECT" Note: '
                                                                                                  'external-facing '
                                                                                                  'name of report is '
                                                                                                  '"Entities" rather '
                                                                                                  'than "Objects".',
                                                                                   'readOnly': True,
                                                                                   'type': 'string'},
                                                                      'profileId': {'description': 'Output only. The '
                                                                                                   "user's immutable "
                                                                                                   'Google Workspace '
                                                                                                   'profile '
                                                                                                   'identifier.',
                                                                                    'readOnly': True,
                                                                                    'type': 'string'},
                                                                      'type': {'description': 'Output only. The type '
                                                                                              'of item. The value is '
                                                                                              '`user`.',
                                                                               'readOnly': True,
                                                                               'type': 'string'},
                                                                      'userEmail': {'description': 'Output only. The '
                                                                                                   "user's email "
                                                                                                   'address. Only '
                                                                                                   'relevant if '
                                                                                                   'entity.type = '
                                                                                                   '"USER"',
                                                                                    'readOnly': True,
                                                                                    'type': 'string'}},
                                                       'readOnly': True,
                                                       'type': 'object'},
                                            'etag': {'description': 'ETag of the resource.', 'type': 'string'},
                                            'kind': {'default': 'admin#reports#usageReport',
                                                     'description': 'The type of API resource. For a usage report, the '
                                                                    'value is `admin#reports#usageReport`.',
                                                     'type': 'string'},
                                            'parameters': {'description': 'Output only. Parameter value pairs for '
                                                                          'various applications. For the Entity Usage '
                                                                          'Report parameters and values, see [the '
                                                                          'Entity Usage parameters '
                                                                          'reference](https://developers.google.com/workspace/admin/reports/v1/reference/usage-ref-appendix-a/entities).',
                                                           'items': {'properties': {'boolValue': {'description': 'Output '
                                                                                                                 'only. '
                                                                                                                 'Boolean '
                                                                                                                 'value '
                                                                                                                 'of '
                                                                                                                 'the '
                                                                                                                 'parameter.',
                                                                                                  'readOnly': True,
                                                                                                  'type': 'boolean'},
                                                                                    'datetimeValue': {'description': 'The '
                                                                                                                     'RFC '
                                                                                                                     '3339 '
                                                                                                                     'formatted '
                                                                                                                     'value '
                                                                                                                     'of '
                                                                                                                     'the '
                                                                                                                     'parameter, '
                                                                                                                     'for '
                                                                                                                     'example '
                                                                                                                     '2010-10-28T10:26:35.000Z.',
                                                                                                      'format': 'date-time',
                                                                                                      'readOnly': True,
                                                                                                      'type': 'string'},
                                                                                    'intValue': {'description': 'Output '
                                                                                                                'only. '
                                                                                                                'Integer '
                                                                                                                'value '
                                                                                                                'of '
                                                                                                                'the '
                                                                                                                'parameter.',
                                                                                                 'format': 'int64',
                                                                                                 'readOnly': True,
                                                                                                 'type': 'string'},
                                                                                    'msgValue': {'description': 'Output '
                                                                                                                'only. '
                                                                                                                'Nested '
                                                                                                                'message '
                                                                                                                'value '
                                                                                                                'of '
                                                                                                                'the '
                                                                                                                'parameter.',
                                                                                                 'items': {'additionalProperties': {'description': 'Properties '
                                                                                                                                                   'of '
                                                                                                                                                   'the '
                                                                                                                                                   'object.',
                                                                                                                                    'type': 'any'},
                                                                                                           'type': 'object'},
                                                                                                 'readOnly': True,
                                                                                                 'type': 'array'},
                                                                                    'name': {'description': 'The name '
                                                                                                            'of the '
                                                                                                            'parameter. '
                                                                                                            'For the '
                                                                                                            'User '
                                                                                                            'Usage '
                                                                                                            'Report '
                                                                                                            'parameter '
                                                                                                            'names, '
                                                                                                            'see the '
                                                                                                            'User '
                                                                                                            'Usage '
                                                                                                            'parameters '
                                                                                                            'reference.',
                                                                                             'type': 'string'},
                                                                                    'stringValue': {'description': 'Output '
                                                                                                                   'only. '
                                                                                                                   'String '
                                                                                                                   'value '
                                                                                                                   'of '
                                                                                                                   'the '
                                                                                                                   'parameter.',
                                                                                                    'readOnly': True,
                                                                                                    'type': 'string'}},
                                                                     'type': 'object'},
                                                           'readOnly': True,
                                                           'type': 'array'}},
                             'type': 'object'},
             'UsageReports': {'id': 'UsageReports',
                              'properties': {'etag': {'description': 'ETag of the resource.', 'type': 'string'},
                                             'kind': {'default': 'admin#reports#usageReports',
                                                      'description': 'The type of API resource. For a usage report, '
                                                                     'the value is `admin#reports#usageReports`.',
                                                      'type': 'string'},
                                             'nextPageToken': {'description': 'Token to specify next page. A report '
                                                                              'with multiple pages has a '
                                                                              '`nextPageToken` property in the '
                                                                              'response. For your follow-on requests '
                                                                              "getting all of the report's pages, "
                                                                              'enter the `nextPageToken` value in the '
                                                                              '`pageToken` query string.',
                                                               'type': 'string'},
                                             'usageReports': {'description': 'Various application parameter records.',
                                                              'items': {'$ref': 'UsageReport'},
                                                              'type': 'array'},
                                             'warnings': {'description': 'Warnings, if any.',
                                                          'items': {'properties': {'code': {'description': 'Machine '
                                                                                                           'readable '
                                                                                                           'code or '
                                                                                                           'warning '
                                                                                                           'type. The '
                                                                                                           'warning '
                                                                                                           'code value '
                                                                                                           'is `200`.',
                                                                                            'type': 'string'},
                                                                                   'data': {'description': 'Key-value '
                                                                                                           'pairs to '
                                                                                                           'give '
                                                                                                           'detailed '
                                                                                                           'information '
                                                                                                           'on the '
                                                                                                           'warning.',
                                                                                            'items': {'properties': {'key': {'description': 'Key '
                                                                                                                                            'associated '
                                                                                                                                            'with '
                                                                                                                                            'a '
                                                                                                                                            'key-value '
                                                                                                                                            'pair '
                                                                                                                                            'to '
                                                                                                                                            'give '
                                                                                                                                            'detailed '
                                                                                                                                            'information '
                                                                                                                                            'on '
                                                                                                                                            'the '
                                                                                                                                            'warning.',
                                                                                                                             'type': 'string'},
                                                                                                                     'value': {'description': 'Value '
                                                                                                                                              'associated '
                                                                                                                                              'with '
                                                                                                                                              'a '
                                                                                                                                              'key-value '
                                                                                                                                              'pair '
                                                                                                                                              'to '
                                                                                                                                              'give '
                                                                                                                                              'detailed '
                                                                                                                                              'information '
                                                                                                                                              'on '
                                                                                                                                              'the '
                                                                                                                                              'warning.',
                                                                                                                               'type': 'string'}},
                                                                                                      'type': 'object'},
                                                                                            'type': 'array'},
                                                                                   'message': {'description': 'The '
                                                                                                              'human '
                                                                                                              'readable '
                                                                                                              'messages '
                                                                                                              'for a '
                                                                                                              'warning '
                                                                                                              'are: - '
                                                                                                              'Data is '
                                                                                                              'not '
                                                                                                              'available '
                                                                                                              'warning '
                                                                                                              '- '
                                                                                                              'Sorry, '
                                                                                                              'data '
                                                                                                              'for '
                                                                                                              'date '
                                                                                                              'yyyy-mm-dd '
                                                                                                              'for '
                                                                                                              'application '
                                                                                                              '"`application '
                                                                                                              'name`" '
                                                                                                              'is not '
                                                                                                              'available. '
                                                                                                              '- '
                                                                                                              'Partial '
                                                                                                              'data is '
                                                                                                              'available '
                                                                                                              'warning '
                                                                                                              '- Data '
                                                                                                              'for '
                                                                                                              'date '
                                                                                                              'yyyy-mm-dd '
                                                                                                              'for '
                                                                                                              'application '
                                                                                                              '"`application '
                                                                                                              'name`" '
                                                                                                              'is not '
                                                                                                              'available '
                                                                                                              'right '
                                                                                                              'now, '
                                                                                                              'please '
                                                                                                              'try '
                                                                                                              'again '
                                                                                                              'after a '
                                                                                                              'few '
                                                                                                              'hours. ',
                                                                                               'type': 'string'}},
                                                                    'type': 'object'},
                                                          'type': 'array'}},
                              'type': 'object'},
             'UserIdentity': {'description': 'Identity of the user who owns the resource.',
                              'id': 'UserIdentity',
                              'properties': {'id': {'description': 'User gaia id.', 'type': 'string'},
                                             'userEmail': {'description': 'User email.', 'type': 'string'}},
                              'type': 'object'}},
 'auth_scopes': {'https://www.googleapis.com/auth/admin.reports.audit.readonly': 'View audit reports for your Google '
                                                                                 'Workspace domain',
                 'https://www.googleapis.com/auth/admin.reports.usage.readonly': 'View usage reports for your Google '
                                                                                 'Workspace domain'}}
