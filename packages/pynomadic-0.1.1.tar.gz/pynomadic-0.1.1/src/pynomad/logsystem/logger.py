"""日志记录器"""

from inspect import currentframe, getmodule
import io
import json
from logging import getLoggerClass
import logging
import traceback
from types import FrameType
from typing import Any, cast, override

from pynomad.common.types import Level

type _Level = int | str | Level
type CallerInfo = tuple[str, int, str, str | None]


class Logger(getLoggerClass()):
    """自定义的日志记录器"""

    def __init__(
        self,
        name: str,
        level: _Level = Level.UNSET,
        remove_pytest_handler: bool = True,
    ):
        super().__init__(self.get_name(name), self.get_integer_level(level))
        self._filter_pytest_handler = remove_pytest_handler

    @staticmethod
    def get_integer_level(level: _Level) -> int:
        """将各种形式的日志级别转换为整数

        Args:
            level: 日志级别，可以是整数、字符串或 Level 枚举

        Returns:
            对应的整数日志级别
        """
        if isinstance(level, Level):
            return level.value
        if isinstance(level, int):
            return level
        try:
            return Level.parse_level(level)
        except Exception:
            return 0

    @staticmethod
    def get_name(name: str) -> str:
        """从调用栈中获取调用者的模块完整名称"""
        if name:
            return name

        f = currentframe()
        if f is None:
            return "unset"

        try:
            while f.f_back is not None:
                f = f.f_back
                if not Logger._is_internal_frame(f):
                    module = getmodule(f)
                    if module is not None and module.__name__:
                        return module.__name__
            return "unset"
        finally:
            del f

    def is_enabled_for(self, level: _Level) -> bool:
        """检查是否处理指定级别的消息

        Args:
            level: 日志级别，可以是整数、字符串或 Level 枚举

        Returns:
            如果记录器将处理该级别的消息，返回 True
        """
        level = self.get_integer_level(level)
        return self.isEnabledFor(level)

    def get_effective_level(self) -> int:
        """获取记录器的有效级别

        如果记录器的级别设置为 NOTSET，则向上遍历层次结构，
        直到找到非 NOTSET 的级别或到达根记录器。

        Returns:
            有效的日志级别整数
        """
        return self.getEffectiveLevel()

    def get_child(self, suffix: str):
        """获取子记录器

        通过附加后缀获取当前记录器的后代记录器。

        Args:
            suffix: 要附加的子名称后缀

        Returns:
            子记录器实例
        """
        return self.getChild(suffix)

    def get_children(self):
        """获取直接下级记录器集合

        只返回直接子记录器，不包括更深层级的后代。

        Returns:
            直接子记录器的集合
        """
        return self.getChildren()

    def add_filter(self, filter: logging.Filter) -> None:
        """添加过滤器

        Args:
            filter: 要添加的过滤器对象
        """
        self.addFilter(filter)

    def remove_filter(self, filter: logging.Filter) -> None:
        """移除过滤器

        Args:
            filter: 要移除的过滤器对象
        """
        self.removeFilter(filter)

    def add_handler(self, handler: logging.Handler) -> None:
        """添加处理器

        Args:
            handler: 要添加的处理器对象
        """
        self.addHandler(handler)

    @override
    def addHandler(self, hdlr: logging.Handler):
        """添加处理器时过滤 pytest 相关的 handler

        当启用 _filter_pytest_handler 时，会自动过滤掉 pytest 相关的日志处理器：
        1. LogCaptureHandler：pytest 用于捕获日志的处理器，用于测试断言
        2. 来自 _pytest 模块的 formatter：避免 pytest 格式化器干扰正常日志输出

        这样可以避免日志被 pytest 重复捕获，导致输出格式混乱或日志丢失。

        Args:
            hdlr: 要添加的日志处理器
        """
        if (
            self._filter_pytest_handler
            and hdlr.__class__.__name__ == "LogCaptureHandler"
        ):
            return
        if hdlr.formatter.__module__.startswith("_pytest"):
            return
        super().addHandler(hdlr)

    def remove_handler(self, handler: logging.Handler) -> None:
        """移除处理器

        Args:
            handler: 要移除的处理器对象
        """
        self.removeHandler(handler)

    def has_handlers(self) -> bool:
        """检查是否配置了处理器

        在当前记录器及其祖先记录器中查找处理器。

        Returns:
            如果找到处理器返回 True，否则返回 False
        """
        return self.hasHandlers()

    @staticmethod
    def _is_internal_frame(frame: FrameType) -> bool:
        """判断帧是否为内部帧

        基于模块的 __package__ 属性判断，不受文件路径影响。

        内部帧包括：
        1. pynomad.logsystem 模块及其子模块
        2. logging 模块
        3. importlib 内部帧

        Args:
            frame: 堆栈帧对象

        Returns:
            如果是内部帧返回 True，否则返回 False
        """
        current_package_name: str = __package__ or "pynomad.logsystem"
        module = getmodule(frame)
        if module is not None:
            package_name = module.__package__
            if package_name is not None:
                # 跳过当前包及其子包
                if (
                    package_name == current_package_name
                    or package_name.startswith(current_package_name + ".")
                ):
                    return True
                # 跳过 logging 包
                if package_name == "logging" or package_name.startswith(
                    "logging."
                ):
                    return True
        # 跳过 importlib 内部帧
        filename = frame.f_code.co_filename
        if "importlib" in filename and "_bootstrap" in filename:
            return True
        return False

    @override
    def findCaller(
        self, stack_info: bool = False, stacklevel: int = 1
    ) -> CallerInfo:
        """查找调用源

        返回调用日志记录方法的文件名、行号、函数名和堆栈信息。

        Args:
            stack_info: 是否包含堆栈信息
            stacklevel: 要跳过的堆栈帧数量

        Returns:
            四元素元组：(文件名, 行号, 函数名, 堆栈信息)
        """

        f = currentframe()
        if f is None:
            return "(unknown file)", 0, "(unknown function)", None
        try:
            while stacklevel > 0:
                next_f = f.f_back
                if next_f is None:
                    break
                f = next_f
                if not self._is_internal_frame(f):
                    stacklevel -= 1
            co = f.f_code
            sinfo: str | None = None
            if stack_info:
                with io.StringIO() as sio:
                    _ = sio.write("Stack (most recent call last):\n")
                    traceback.print_stack(f, file=sio)
                    sinfo = sio.getvalue()
                    if sinfo[-1] == "\n":
                        sinfo = sinfo[:-1]
            return co.co_filename, f.f_lineno, co.co_name, sinfo
        finally:
            del f

    def find_caller(
        self, stack_info: bool = False, stacklevel: int = 1
    ) -> CallerInfo:
        """查找调用源

        返回调用日志记录方法的文件名、行号、函数名和堆栈信息。

        Args:
            stack_info: 是否包含堆栈信息
            stacklevel: 要跳过的堆栈帧数量

        Returns:
            四元素元组：(文件名, 行号, 函数名, 堆栈信息)
        """
        return self.findCaller(stack_info, stacklevel)

    def make_record(
        self,
        name: str,
        level: int,
        fn: str,
        lno: int,
        msg: object,
        args: Any,
        exc_info: Any,
        func: str | None = None,
        extra: Any | None = None,
        sinfo: str | None = None,
    ) -> logging.LogRecord:
        """创建日志记录

        工厂方法，可在子类中重写以创建专门的 LogRecord 实例。

        Args:
            name: 记录器名称
            level: 日志级别
            fn: 文件名
            lno: 行号
            msg: 消息
            args: 参数
            exc_info: 异常信息
            func: 函数名
            extra: 额外属性
            sinfo: 堆栈信息

        Returns:
            日志记录对象
        """
        return self.makeRecord(
            name, level, fn, lno, msg, args, exc_info, func, extra, sinfo
        )

    @override
    def log(
        self,
        level: _Level,
        msg: object,
        *args: object,
        pretty_print: bool = False,
        **kwargs: Any,
    ) -> None:
        """记录指定级别的消息

        Args:
            level: 日志级别，可以是整数、字符串或 Level 枚举
            msg: 日志消息格式字符串
            *args: 用于格式化字符串的参数，或要拼接的额外消息
            pretty_print: 是否美化打印字典和列表
            **kwargs: 关键字参数，支持:
                - exc_info: 添加异常信息
                - stack_info: 添加堆栈信息
                - stacklevel: 跳过指定数量的堆栈帧
                - extra: 自定义属性字典
        """
        level = self.get_integer_level(level)

        # 提前检查级别是否启用，避免不必要的处理
        if not self.is_enabled_for(level):
            return

        # 判断是否为格式化字符串模式
        msg_str: str = str(msg) if not isinstance(msg, str) else msg
        is_format_mode: bool = "%" in msg_str and any(
            fmt in msg_str for fmt in ["%s", "%d", "%f", "%r", "%x", "%o"]
        )

        # 预处理消息
        if pretty_print:
            # 处理 msg
            if isinstance(msg, dict | list):
                try:
                    msg = json.dumps(msg, ensure_ascii=False, indent=4)
                except Exception:
                    pass

            # 处理 args
            if args:
                processed_args: list[str] = []
                for arg in args:
                    if isinstance(arg, dict | list):
                        try:
                            arg = json.dumps(arg, ensure_ascii=False, indent=4)
                        except Exception:
                            pass
                    processed_args.append(str(cast(object, arg)))

                if not is_format_mode:
                    all_parts: list[str] = [msg_str]
                    all_parts.extend(processed_args)
                    msg = "\n".join(all_parts)
                    args = ()
                else:
                    args = tuple(processed_args)
        elif args and not is_format_mode:
            all_parts: list[str] = [msg_str]
            all_parts.extend(str(arg) for arg in args)
            msg = " ".join(all_parts)
            args = ()

        super()._log(level, cast(object, msg), args, **kwargs)

    def trace(self, msg: object, *args: object, **kwargs: Any) -> None:
        """记录 TRACE 级别的消息

        Args:
            msg: 日志消息格式字符串
            *args: 用于格式化字符串的参数
            **kwargs: 关键字参数，支持:
                - exc_info: 添加异常信息
                - stack_info: 添加堆栈信息
                - stacklevel: 跳过指定数量的堆栈帧
                - extra: 自定义属性字典
        """
        self.log(Level.TRACE, msg, *args, **kwargs)

    @override
    def debug(self, msg: object, *args: object, **kwargs: Any) -> None:
        """记录 DEBUG 级别的消息

        Args:
            msg: 日志消息格式字符串
            *args: 用于格式化字符串的参数
            **kwargs: 关键字参数，支持:
                - exc_info: 添加异常信息
                - stack_info: 添加堆栈信息
                - stacklevel: 跳过指定数量的堆栈帧
                - extra: 自定义属性字典
        """
        self.log(Level.DEBUG, msg, *args, **kwargs)

    @override
    def info(self, msg: object, *args: object, **kwargs: Any) -> None:
        """记录 INFO 级别的消息

        Args:
            msg: 日志消息格式字符串
            *args: 用于格式化字符串的参数
            **kwargs: 关键字参数，支持:
                - exc_info: 添加异常信息
                - stack_info: 添加堆栈信息
                - stacklevel: 跳过指定数量的堆栈帧
                - extra: 自定义属性字典
        """
        self.log(Level.INFO, msg, *args, **kwargs)

    @override
    def warn(self, msg: object, *args: object, **kwargs: Any) -> None:
        """记录 WARNING 级别的消息

        Args:
            msg: 日志消息格式字符串
            *args: 用于格式化字符串的参数
            **kwargs: 关键字参数，支持:
                - exc_info: 添加异常信息
                - stack_info: 添加堆栈信息
                - stacklevel: 跳过指定数量的堆栈帧
                - extra: 自定义属性字典
        """
        self.log(Level.WARN, msg, *args, **kwargs)

    @override
    def warning(self, msg: object, *args: object, **kwargs: Any):
        return self.warn(msg, *args, **kwargs)

    @override
    def error(self, msg: object, *args: object, **kwargs: Any) -> None:
        """记录 ERROR 级别的消息

        Args:
            msg: 日志消息格式字符串
            *args: 用于格式化字符串的参数
            **kwargs: 关键字参数，支持:
                - exc_info: 添加异常信息
                - stack_info: 添加堆栈信息
                - stacklevel: 跳过指定数量的堆栈帧
                - extra: 自定义属性字典
        """
        self.log(Level.ERROR, msg, *args, **kwargs)

    @override
    def critical(self, msg: object, *args: object, **kwargs: Any):
        return self.fatal(msg, *args, **kwargs)

    @override
    def fatal(self, msg: object, *args: object, **kwargs: Any) -> None:
        """记录 FATAL (CRITICAL) 级别的消息

        Args:
            msg: 日志消息格式字符串
            *args: 用于格式化字符串的参数
            **kwargs: 关键字参数，支持:
                - exc_info: 添加异常信息
                - stack_info: 添加堆栈信息
                - stacklevel: 跳过指定数量的堆栈帧
                - extra: 自定义属性字典
        """
        self.log(Level.FATAL, msg, *args, **kwargs)


class RootLogger(Logger):
    """根日志记录器"""

    def __init__(self, level: _Level = Level.TRACE):
        super().__init__("root", level)
