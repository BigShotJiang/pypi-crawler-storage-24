"""日志格式字符串构建器"""

import re
from pynomad.common.ansi import AnsiStyle, Color
from pynomad.logsystem.logtypes import (
    AlignType,
    ColorConfig,
    FormatStrings,
    FmtStyle,
    parse_color_config,
    parse_style_config,
    StrFmtFlag,
    StyleConfig,
)


class FormatBuilder:
    """日志格式字符串构建器

    提供链式API构建日志格式字符串,支持多种格式化风格(%、{、$)
    内部统一使用f-string(大括号)风格构建,输出时自动转换为指定风格
    支持ANSI颜色设置
    """

    def __init__(
        self,
        fmtstyle: FmtStyle = "{",
        datefmt: str = "%Y-%m-%d %H:%M:%S",
    ) -> None:
        """初始化格式构建器

        Args:
            fmtstyle: 格式化风格，支持 "%" (percent)、"{" (f-string)、"$" (template)
            datefmt: 时间格式化字符串
        """
        # 该字段用于存储用于期望的格式化风格,但是内部始终使用f-string构造
        self._fmtstyle: FmtStyle = fmtstyle
        # 时间格式化字符串,用于设置format的datefmt
        self._datefmt: str = datefmt
        # 无颜色支持的格式化字符串
        self._plainfmt: str = ""
        # 带静态ANSI颜色的格式化字符串 (不含动态级别颜色)
        self._colorfmt_static: str = ""
        # 带动态级别颜色的格式化字符串 (含 !c 转换)
        self._colorfmt_dynamic: str = ""
        # ANSI重置代码,用于开头和结尾强制重置颜色和样式
        self._reset_code: str = f"\033[{AnsiStyle.RESET}m"

    @staticmethod
    def _build_format_spec(
        align: AlignType | None = None,
        width: int = 0,
        fill: str = " ",
        format_type: str | None = None,
    ) -> str:
        """构建格式规范字符串

        Args:
            align: 对齐方式 ("<"=左对齐, ">"=右对齐, "^"=居中, "="=填充)
            width: 最小宽度
            fill: 填充字符
            format_type: 格式类型 (如 "f", "d", "s" 等)

        Returns:
            格式规范字符串 (如 ">10.2f", "<20s")

        Example:
            >>> _build_format_spec(">", 10, "0", "f")
            ">0f"
            >>> _build_format_spec("<", 20)
            "<20"
        """
        parts: list[str] = []

        # 如果指定了宽度,才有意义添加对齐和填充
        if width > 0:
            # fill 必须单独字符,长度为1
            if len(fill) != 1:
                fill = " "

            # 如果 align 为 None,字符串默认左对齐,数字默认右对齐
            if align is None:
                align = "<"

            parts.append(fill)
            parts.append(align)
            parts.append(str(width))

        # 添加格式类型 (如 f, d, s, .2f 等)
        if format_type:
            parts.append(format_type)

        return "".join(parts)

    @staticmethod
    def percent_to_fstring(fmtstr: str) -> str:
        """将%号形式的格式化字符串转化为大括号形式

        Args:
            fmtstr: 百分号格式的字符串 (如 "%(name)s %(levelname)s")

        Returns:
            转换后的大括号格式字符串 (如 "{name} {levelname}")
        """
        # 将 %(name)s 转换为 {name}
        return re.sub(
            r"%\((\w+)\)([diouxXeEfFgGcrsa%])",
            lambda m: f"{{{m.group(1)}}}",
            fmtstr,
        )

    @staticmethod
    def template_to_fstring(fmtstr: str) -> str:
        """将$号形式的格式化字符串转化为大括号形式

        Args:
            fmtstr: Template格式的字符串 (如 "$name $levelname")

        Returns:
            转换后的大括号格式字符串 (如 "{name} {levelname}")
        """
        # 将 $name 或 ${name} 转换为 {name}
        return re.sub(
            r"\$(\w+|\{(\w+)\})",
            lambda m: f"{{{m.group(2) or m.group(1)}}}",
            fmtstr,
        )

    @staticmethod
    def fstring_to_percent(fmtstr: str) -> str:
        """将大括号形式的格式化字符串转化%形式

        Args:
            fmtstr: 大括号格式的字符串 (如 "{name} {levelname}")

        Returns:
            转换后的百分号格式字符串 (如 "%(name)s %(levelname)s")
        """
        # 将 {name} 转换为 %(name)s
        return re.sub(r"\{(\w+)\}", lambda m: f"%({m.group(1)})s", fmtstr)

    @staticmethod
    def fstring_to_template(fmtstr: str) -> str:
        """将大括号形式的转化为$符号形式

        Args:
            fmtstr: 大括号格式的字符串 (如 "{name} {levelname}")

        Returns:
            转换后的Template格式字符串 (如 "$name $levelname")
        """
        # 将 {name} 转换为 $name
        return re.sub(r"\{(\w+)\}", lambda m: f"${m.group(1)}", fmtstr)

    @property
    def fmtstyle(self) -> FmtStyle:
        """获取当前的格式化风格"""
        return self._fmtstyle

    @property
    def datafmt(self) -> str:
        """日期格式化字符串"""
        return self._datefmt

    def set_datefmt(self, datefmt: str) -> "FormatBuilder":
        """设置时间格式化字符串

        Args:
            datefmt: 时间格式字符串,如 "%Y-%m-%d %H:%M:%S"

        Returns:
            self,支持链式调用

        Example:
            >>> builder = FormatBuilder()
            >>> builder.set_datefmt("%H:%M:%S").add_asctime()
            >>> formatter = Formatter(fmt, datefmt=builder.datafmt, style="{")

        Note:
            时间格式化字符串通过 builder.datafmt 属性获取,
            在创建 Formatter 时传递给 datefmt 参数。
        """
        self._datefmt = datefmt
        return self

    def _to_str_format(
        self,
        var_name: str,
        flag: StrFmtFlag | None = None,
        format_spec: str | None = None,
    ) -> str:
        """生成大括号格式的字段字符串

        该方法用于内部的add通用方法,构造符合Python格式规范的字段字符串

        Args:
            var_name: 字段名 (如 "asctime", "levelname")
            flag: 转换标志 ("s"=str, "r"=repr, "a"=ascii)
            format_spec: 格式化规范 (如 ">10", ".2f")

        Returns:
            构造好的大括号格式字符串

        Note:
            替换语法:
            replacement_field: "{" [field_name] ["!" conversion] [":" format_spec] "}"
            conversion: "r" | "s" | "a"
            format_spec的详细规范参考:
            https://docs.python.org/zh-cn/3.14/library/string.html#formatstrings
        """
        parts: list[str] = ["{"]
        parts.append(var_name)

        if flag:
            parts.append("!")
            parts.append(flag)

        if format_spec:
            parts.append(":")
            parts.append(format_spec)

        parts.append("}")

        return "".join(parts)

    def _to_str_format_with_conversion(
        self,
        var_name: str,
        format_spec: str | None = None,
    ) -> str:
        """生成带颜色转换的大括号格式字符串

        生成如 "{levelname!c:<8}" 的格式,其中 "c" 是颜色转换标记

        Args:
            var_name: 字段名 (如 "levelname", "levelno")
            format_spec: 格式化规范 (如 ">10", "<8")

        Returns:
            构造好的大括号格式字符串,带有 "c" 转换标记

        Example:
            >>> builder._to_str_format_with_conversion("levelname", "<8")
            "{levelname!c:<8}"
        """
        parts: list[str] = ["{"]
        parts.append(var_name)
        parts.append("!c")

        if format_spec:
            parts.append(":")
            parts.append(format_spec)

        parts.append("}")

        return "".join(parts)

    def _add_field(
        self,
        field_name: str,
        flag: StrFmtFlag | None = None,
        format_spec: str | None = None,
    ) -> "FormatBuilder":
        """内部通用方法:添加一个日志字段到格式字符串

        Args:
            field_name: LogRecord字段名 (如 "asctime", "levelname")
            flag: 转换标志 ("s"=str, "r"=repr, "a"=ascii)
            format_spec: 格式化规范 (如 ">10", ".2f")

        Returns:
            self,支持链式调用
        """
        field_format: str = self._to_str_format(field_name, flag, format_spec)
        return self.add_string(field_format)

    def _add_field_with_color(
        self,
        field_name: str,
        use_level_color: bool = False,
        format_spec: str | None = None,
        flag: StrFmtFlag | None = None,
    ) -> "FormatBuilder":
        """内部方法:添加日志字段,支持动态级别颜色

        Args:
            field_name: LogRecord字段名 (如 "levelname", "levelno")
            use_level_color: 是否使用动态级别颜色
            format_spec: 格式化规范 (如 ">10", "<8")
            flag: 转换标志 ("s"=str, "r"=repr, "a"=ascii)

        Returns:
            self,支持链式调用

        Note:
            当 use_level_color=True 时,在 colorfmt_dynamic 中使用 "!c" 转换
            当 use_level_color=False 时,三个格式字符串都使用普通格式
        """
        if use_level_color:
            # colorfmt_dynamic 使用 !c 转换
            field_format_dynamic: str = self._to_str_format_with_conversion(
                field_name, format_spec
            )
            self._colorfmt_dynamic += field_format_dynamic
        else:
            # colorfmt_dynamic 不使用 !c 转换
            field_format_normal: str = self._to_str_format(
                field_name, flag, format_spec
            )
            self._colorfmt_dynamic += field_format_normal

        # plainfmt 和 colorfmt_static 始终使用普通格式
        field_format_normal: str = self._to_str_format(
            field_name, flag, format_spec
        )
        self._plainfmt += field_format_normal
        self._colorfmt_static += field_format_normal

        return self

    def add_string(self, text: str) -> "FormatBuilder":
        """添加固定文本到格式字符串

        用于在日志格式中添加分隔符、标点符号等固定文本。

        Args:
            text: 要添加的固定文本

        Returns:
            self,支持链式调用
        """
        self._plainfmt += text
        self._colorfmt_static += text
        self._colorfmt_dynamic += text

        return self

    def add_fore(self, fore: ColorConfig) -> "FormatBuilder":
        """添加前景色代码到 colorfmt_static 和 colorfmt_dynamic

        Args:
            fore: 前景色配置,支持 None/int/str

        Returns:
            self,支持链式调用

        Example:
            builder = FormatBuilder()
            builder.add_fore("bright_blue").add_string("text")

        Note:
            - colorfmt_static: 包含所有静态颜色
            - colorfmt_dynamic: 也包含静态颜色，但字段内部的 !c 转换会覆盖
        """
        color_code: int = parse_color_config(fore, is_foreground=True)
        self._colorfmt_static += f"\033[{color_code}m"
        self._colorfmt_dynamic += f"\033[{color_code}m"
        return self

    def add_back(self, back: ColorConfig) -> "FormatBuilder":
        """添加背景色代码到 colorfmt_static 和 colorfmt_dynamic

        Args:
            back: 背景色配置,支持 None/int/str

        Returns:
            self,支持链式调用

        Example:
            builder = FormatBuilder()
            builder.add_back(None).add_string("text")

        Note:
            - colorfmt_static: 包含所有静态颜色
            - colorfmt_dynamic: 也包含静态颜色，但字段内部的 !c 转换会覆盖
        """
        color_code: int = parse_color_config(back, is_foreground=False)
        self._colorfmt_static += f"\033[{color_code}m"
        self._colorfmt_dynamic += f"\033[{color_code}m"
        return self

    def add_style(self, style: StyleConfig) -> "FormatBuilder":
        """添加样式代码到 colorfmt_static 和 colorfmt_dynamic

        Args:
            style: 样式配置,支持 None/int/str

        Returns:
            self,支持链式调用

        Example:
            builder = FormatBuilder()
            builder.add_style("bold").add_levelname()

        Note:
            - colorfmt_static: 包含所有静态样式
            - colorfmt_dynamic: 也包含静态样式，但字段内部的 !c 转换会覆盖
        """
        style_code: int = parse_style_config(style)
        self._colorfmt_static += f"\033[{style_code}m"
        self._colorfmt_dynamic += f"\033[{style_code}m"
        return self

    def rest_fore(self) -> "FormatBuilder":
        """重置前景色为默认值

        Returns:
            self,支持链式调用

        Example:
            builder.add_fore("red").add_asctime().rest_fore()

        Note:
            同时更新 colorfmt_static 和 colorfmt_dynamic
        """
        self._colorfmt_static += f"\033[{Color.DEFAULT.fore}m"
        self._colorfmt_dynamic += f"\033[{Color.DEFAULT.fore}m"
        return self

    def rest_back(self) -> "FormatBuilder":
        """重置背景色为默认值

        Returns:
            self,支持链式调用

        Example:
            builder.add_back(41).add_asctime().rest_back()

        Note:
            同时更新 colorfmt_static 和 colorfmt_dynamic
        """
        self._colorfmt_static += f"\033[{Color.DEFAULT.back}m"
        self._colorfmt_dynamic += f"\033[{Color.DEFAULT.back}m"
        return self

    def rest_style(self) -> "FormatBuilder":
        """重置样式为默认值

        Returns:
            self,支持链式调用

        Example:
            builder.add_style("bold").add_levelname().rest_style()

        Note:
            同时更新 colorfmt_static 和 colorfmt_dynamic
        """
        self._colorfmt_static += self._reset_code
        self._colorfmt_dynamic += self._reset_code
        return self

    def reset_color(self) -> "FormatBuilder":
        """重置前景和背景颜色，不重置样式

        Returns:
            self,支持链式调用

        Example:
            builder = FormatBuilder()
            builder.add_fore("red").add_back(41).add_string("text").reset_color()

        Note:
            同时更新 colorfmt_static 和 colorfmt_dynamic
        """
        fore_code: str = f"\033[{Color.DEFAULT.fore}m"
        back_code: str = f"\033[{Color.DEFAULT.back}m"
        self._colorfmt_static += fore_code + back_code
        self._colorfmt_dynamic += fore_code + back_code
        return self

    def reset_style(self) -> "FormatBuilder":
        """重置所有颜色和样式（前景、背景、样式）

        Returns:
            self,支持链式调用

        Example:
            builder = FormatBuilder()
            builder.add_fore("red").add_back(41).add_style("bold").add_string("text").reset_style()

        Note:
            同时更新 colorfmt_static 和 colorfmt_dynamic
        """
        self._colorfmt_static += self._reset_code
        self._colorfmt_dynamic += self._reset_code
        return self

    def add_asctime(
        self,
        align: AlignType | None = None,
        width: int = 0,
        fill: str = " ",
        use_level_color: bool = False,
    ) -> "FormatBuilder":
        """添加时间戳字段

        表示人类易读的 LogRecord 生成时间。
        默认形式为 '2003-07-08 16:49:45,896'
        （逗号之后的数字为时间的毫秒部分）。

        Args:
            align: 对齐方式 ("<"=左对齐, ">"=右对齐, "^"=居中, "="=填充)
            width: 最小宽度 (0表示不限制宽度)
            fill: 填充字符 (默认为空格)
            use_level_color: 是否使用动态级别颜色

        Returns:
            self,支持链式调用

        Example:
            >>> builder = FormatBuilder()
            >>> builder.set_datefmt("%H:%M:%S").add_asctime(width=20)  # 左对齐,宽度20
            >>> builder.add_asctime(width=20, use_level_color=True)  # 使用动态颜色
            >>> plainfmt, colorfmt = builder.build()
            >>> formatter = Formatter(colorfmt, datefmt=builder.datafmt, style="{")

        Note:
            时间格式通过 set_datefmt() 方法设置,通过 builder.datafmt 属性获取。
        """
        format_spec: str = self._build_format_spec(align, width, fill)
        return self._add_field_with_color(
            "asctime", use_level_color, format_spec
        )

    def add_created(
        self,
        align: AlignType | None = None,
        width: int = 0,
        fill: str = " ",
        use_level_color: bool = False,
    ) -> "FormatBuilder":
        """添加创建时间字段

        当 LogRecord 被创建的时间（即 time.time_ns() / 1e9 所返回的值）。

        Args:
            align: 对齐方式 ("<"=左对齐, ">"=右对齐, "^"=居中, "="=填充)
            width: 最小宽度 (0表示不限制宽度)
            fill: 填充字符 (默认为空格)
            use_level_color: 是否使用动态级别颜色

        Returns:
            self,支持链式调用
        """
        format_spec: str = self._build_format_spec(align, width, fill, "f")
        return self._add_field_with_color(
            "created", use_level_color, format_spec
        )

    def add_filename(
        self,
        align: AlignType | None = None,
        width: int = 0,
        fill: str = " ",
        truncate: bool = False,
        use_level_color: bool = False,
    ) -> "FormatBuilder":
        """添加文件名字段

        pathname 的文件名部分。

        Args:
            align: 对齐方式 ("<"=左对齐, ">"=右对齐, "^"=居中, "="=填充)
            width: 最小宽度 (0表示不限制宽度)
            fill: 填充字符 (默认为空格)
            truncate: 是否中间截断超长字符串
            use_level_color: 是否使用动态级别颜色

        Returns:
            self,支持链式调用
        """
        format_spec: str = self._build_format_spec(align, width, fill)
        if truncate and width > 0:
            format_spec += f".{width}"
        return self._add_field_with_color(
            "filename", use_level_color, format_spec
        )

    def add_funcname(
        self,
        align: AlignType | None = None,
        width: int = 0,
        fill: str = " ",
        truncate: bool = False,
        use_level_color: bool = False,
    ) -> "FormatBuilder":
        """添加函数名字段

        函数名包括调用日志记录。

        Args:
            align: 对齐方式 ("<"=左对齐, ">"=右对齐, "^"=居中, "="=填充)
            width: 最小宽度 (0表示不限制宽度)
            fill: 填充字符 (默认为空格)
            truncate: 是否中间截断超长字符串
            use_level_color: 是否使用动态级别颜色

        Returns:
            self,支持链式调用
        """
        format_spec: str = self._build_format_spec(align, width, fill)
        if truncate and width > 0:
            format_spec += f".{width}"
        return self._add_field_with_color(
            "funcName", use_level_color, format_spec
        )

    def add_levelname(
        self,
        align: AlignType | None = None,
        width: int = 0,
        fill: str = " ",
        use_level_color: bool = False,
    ) -> "FormatBuilder":
        """添加日志级别名字段

        消息文本记录级别（'DEBUG'，'INFO'，'WARNING'，'ERROR'，'CRITICAL'）。

        Args:
            align: 对齐方式 ("<"=左对齐, ">"=右对齐, "^"=居中, "="=填充)
            width: 最小宽度 (0表示不限制宽度)
            fill: 填充字符 (默认为空格)
            use_level_color: 是否使用动态级别颜色

        Returns:
            self,支持链式调用

        Example:
            >>> builder.add_levelname(width=8)  # 左对齐,宽度8
            >>> builder.add_levelname(align=">", width=8)  # 右对齐,宽度8
            >>> builder.add_levelname(align="^", width=10)  # 居中,宽度10
            >>> builder.add_levelname(width=8, use_level_color=True)  # 使用动态颜色
        """
        format_spec: str = self._build_format_spec(align, width, fill)
        return self._add_field_with_color(
            "levelname", use_level_color, format_spec
        )

    def add_levelno(
        self,
        align: AlignType | None = None,
        width: int = 0,
        fill: str = " ",
        use_level_color: bool = False,
    ) -> "FormatBuilder":
        """添加日志级别数字字段

        消息数字的记录级别 (DEBUG=10, INFO=20, WARNING=30, ERROR=40, CRITICAL=50).

        Args:
            align: 对齐方式 ("<"=左对齐, ">"=右对齐, "^"=居中, "="=填充)
            width: 最小宽度 (0表示不限制宽度)
            fill: 填充字符 (默认为空格)
            use_level_color: 是否使用动态级别颜色

        Returns:
            self,支持链式调用

        Example:
            >>> builder.add_levelno(align=">", width=3)  # 右对齐,宽度3
            >>> builder.add_levelno(width=2)  # 左对齐,宽度2
            >>> builder.add_levelno(width=3, use_level_color=True)  # 使用动态颜色
        """
        format_spec: str = self._build_format_spec(align, width, fill, "d")
        return self._add_field_with_color(
            "levelno", use_level_color, format_spec
        )

    def add_lineno(
        self,
        align: AlignType | None = None,
        width: int = 0,
        fill: str = " ",
        use_level_color: bool = False,
    ) -> "FormatBuilder":
        """添加行号字段

        发出日志记录调用所在的源行号（如果可用）。

        Args:
            align: 对齐方式 ("<"=左对齐, ">"=右对齐, "^"=居中, "="=填充)
            width: 最小宽度 (0表示不限制宽度)
            fill: 填充字符 (默认为空格)
            use_level_color: 是否使用动态级别颜色

        Returns:
            self,支持链式调用
        """
        format_spec: str = self._build_format_spec(align, width, fill, "d")
        return self._add_field_with_color(
            "lineno", use_level_color, format_spec
        )

    def add_message(
        self,
        align: AlignType | None = None,
        width: int = 0,
        fill: str = " ",
        use_level_color: bool = False,
    ) -> "FormatBuilder":
        """添加日志消息字段

        记入日志的消息，即 msg % args 的结果。
        这是在唤起 Formatter.format() 时设置的。

        Args:
            align: 对齐方式 ("<"=左对齐, ">"=右对齐, "^"=居中, "="=填充)
            width: 最小宽度 (0表示不限制宽度)
            fill: 填充字符 (默认为空格)
            use_level_color: 是否使用动态级别颜色

        Returns:
            self,支持链式调用
        """
        format_spec: str = self._build_format_spec(align, width, fill)
        return self._add_field_with_color(
            "message", use_level_color, format_spec
        )

    def add_module(
        self,
        align: AlignType | None = None,
        width: int = 0,
        fill: str = " ",
        truncate: bool = False,
        use_level_color: bool = False,
    ) -> "FormatBuilder":
        """添加模块名字段

        模块 (filename 的名称部分)。

        Args:
            align: 对齐方式 ("<"=左对齐, ">"=右对齐, "^"=居中, "="=填充)
            width: 最小宽度 (0表示不限制宽度)
            fill: 填充字符 (默认为空格)
            truncate: 是否截断超长字符串 (True时字符串不会超过width)
            use_level_color: 是否使用动态级别颜色

        Returns:
            self,支持链式调用
        """
        format_spec: str = self._build_format_spec(align, width, fill)
        if truncate and width > 0:
            format_spec += f".{width}"
        return self._add_field_with_color(
            "module", use_level_color, format_spec
        )

    def add_msecs(
        self,
        align: AlignType | None = None,
        width: int = 0,
        fill: str = " ",
        use_level_color: bool = False,
    ) -> "FormatBuilder":
        """添加毫秒字段

        LogRecord 被创建的时间的毫秒部分。

        Args:
            align: 对齐方式 ("<"=左对齐, ">"=右对齐, "^"=居中, "="=填充)
            width: 最小宽度 (0表示不限制宽度)
            fill: 填充字符 (默认为空格)
            use_level_color: 是否使用动态级别颜色

        Returns:
            self,支持链式调用
        """
        format_spec: str = self._build_format_spec(align, width, fill, ".3f")
        return self._add_field_with_color("msecs", use_level_color, format_spec)

    def add_name(
        self,
        align: AlignType | None = None,
        width: int = 0,
        fill: str = " ",
        truncate: bool = False,
        use_level_color: bool = False,
    ) -> "FormatBuilder":
        """添加日志记录器名字段

        用于记录调用的日志记录器名称。

        Args:
            align: 对齐方式 ("<"=左对齐, ">"=右对齐, "^"=居中, "="=填充)
            width: 最小宽度 (0表示不限制宽度)
            fill: 填充字符 (默认为空格)
            truncate: 是否中间截断超长字符串
            use_level_color: 是否使用动态级别颜色

        Returns:
            self,支持链式调用
        """
        format_spec: str = self._build_format_spec(align, width, fill)
        if truncate and width > 0:
            format_spec += f".{width}"
        return self._add_field_with_color("name", use_level_color, format_spec)

    def add_pathname(
        self,
        align: AlignType | None = None,
        width: int = 0,
        fill: str = " ",
        truncate: bool = False,
        use_level_color: bool = False,
    ) -> "FormatBuilder":
        """添加完整路径名字段

        发出日志记录调用的源文件的完整路径名（如果可用）。

        Args:
            align: 对齐方式 ("<"=左对齐, ">"=右对齐, "^"=居中, "="=填充)
            width: 最小宽度 (0表示不限制宽度)
            fill: 填充字符 (默认为空格)
            truncate: 是否中间截断超长字符串
            use_level_color: 是否使用动态级别颜色

        Returns:
            self,支持链式调用
        """
        format_spec: str = self._build_format_spec(align, width, fill)
        if truncate and width > 0:
            format_spec += f".{width}"
        return self._add_field_with_color(
            "pathname", use_level_color, format_spec
        )

    def add_process(
        self,
        align: AlignType | None = None,
        width: int = 0,
        fill: str = " ",
        use_level_color: bool = False,
    ) -> "FormatBuilder":
        """添加进程ID字段

        进程ID（如果可用）。

        Args:
            align: 对齐方式 ("<"=左对齐, ">"=右对齐, "^"=居中, "="=填充)
            width: 最小宽度 (0表示不限制宽度)
            fill: 填充字符 (默认为空格)
            use_level_color: 是否使用动态级别颜色

        Returns:
            self,支持链式调用
        """
        format_spec: str = self._build_format_spec(align, width, fill, "d")
        return self._add_field_with_color(
            "process", use_level_color, format_spec
        )

    def add_processname(
        self,
        align: AlignType | None = None,
        width: int = 0,
        fill: str = " ",
        truncate: bool = False,
        use_level_color: bool = False,
    ) -> "FormatBuilder":
        """添加进程名字段

        进程名（如果可用）。

        Args:
            align: 对齐方式 ("<"=左对齐, ">"=右对齐, "^"=居中, "="=填充)
            width: 最小宽度 (0表示不限制宽度)
            fill: 填充字符 (默认为空格)
            truncate: 是否中间截断超长字符串
            use_level_color: 是否使用动态级别颜色

        Returns:
            self,支持链式调用
        """
        format_spec: str = self._build_format_spec(align, width, fill)
        if truncate and width > 0:
            format_spec += f".{width}"
        return self._add_field_with_color(
            "processName", use_level_color, format_spec
        )

    def add_relative_created(
        self,
        align: AlignType | None = None,
        width: int = 0,
        fill: str = " ",
        use_level_color: bool = False,
    ) -> "FormatBuilder":
        """添加相对创建时间字段

        以毫秒数表示的 LogRecord 被创建的时间，
        即相对于 logging 模块被加载时间的差值。

        Args:
            align: 对齐方式 ("<"=左对齐, ">"=右对齐, "^"=居中, "="=填充)
            width: 最小宽度 (0表示不限制宽度)
            fill: 填充字符 (默认为空格)
            use_level_color: 是否使用动态级别颜色

        Returns:
            self,支持链式调用
        """
        format_spec: str = self._build_format_spec(align, width, fill, "d")
        return self._add_field_with_color(
            "relativeCreated", use_level_color, format_spec
        )

    def add_thread(
        self,
        align: AlignType | None = None,
        width: int = 0,
        fill: str = " ",
        use_level_color: bool = False,
    ) -> "FormatBuilder":
        """添加线程ID字段

        线程ID（如果可用）。

        Args:
            align: 对齐方式 ("<"=左对齐, ">"=右对齐, "^"=居中, "="=填充)
            width: 最小宽度 (0表示不限制宽度)
            fill: 填充字符 (默认为空格)
            use_level_color: 是否使用动态级别颜色

        Returns:
            self,支持链式调用
        """
        format_spec: str = self._build_format_spec(align, width, fill, "d")
        return self._add_field_with_color(
            "thread", use_level_color, format_spec
        )

    def add_threadname(
        self,
        align: AlignType | None = None,
        width: int = 0,
        fill: str = " ",
        truncate: bool = False,
        use_level_color: bool = False,
    ) -> "FormatBuilder":
        """添加线程名字段

        线程名(如果可用)。

        Args:
            align: 对齐方式 ("<"=左对齐, ">"=右对齐, "^"=居中, "="=填充)
            width: 最小宽度 (0表示不限制宽度)
            fill: 填充字符 (默认为空格)
            truncate: 是否中间截断超长字符串
            use_level_color: 是否使用动态级别颜色

        Returns:
            self,支持链式调用
        """
        format_spec: str = self._build_format_spec(align, width, fill)
        if truncate and width > 0:
            format_spec += f".{width}"
        return self._add_field_with_color(
            "threadName", use_level_color, format_spec
        )

    def add_taskname(
        self,
        align: AlignType | None = None,
        width: int = 0,
        fill: str = " ",
        truncate: bool = False,
        use_level_color: bool = False,
    ) -> "FormatBuilder":
        """添加任务名字段

        asyncio.Task 名称（如果可用）。

        Args:
            align: 对齐方式 ("<"=左对齐, ">"=右对齐, "^"=居中, "="=填充)
            width: 最小宽度 (0表示不限制宽度)
            fill: 填充字符 (默认为空格)
            truncate: 是否中间截断超长字符串
            use_level_color: 是否使用动态级别颜色

        Returns:
            self,支持链式调用
        """
        format_spec: str = self._build_format_spec(align, width, fill)
        if truncate and width > 0:
            format_spec += f".{width}"
        return self._add_field_with_color(
            "taskName", use_level_color, format_spec
        )

    def build(self) -> FormatStrings:
        """根据用户传入的fmtstyle构建最终的格式字符串

        Returns:
            元组 (plainfmt, colorfmt_static, colorfmt_dynamic):
            - plainfmt: 无ANSI颜色支持的格式字符串
            - colorfmt_static: 带静态ANSI颜色代码的格式字符串
            - colorfmt_dynamic: 带动态级别颜色的格式字符串 (含 !c 转换)
            返回的格式字符串会自动转换为fmtstyle指定的风格
        """
        plainfmt: str = self._plainfmt.strip()
        colorfmt_static: str = self._colorfmt_static.strip()
        colorfmt_dynamic: str = self._colorfmt_dynamic.strip()

        if self._fmtstyle == "%":
            plainfmt = self.fstring_to_percent(plainfmt)
            colorfmt_static = self.fstring_to_percent(colorfmt_static)
            # colorfmt_dynamic 保留 !c 转换，不做转换
        elif self._fmtstyle == "$":
            plainfmt = self.fstring_to_template(plainfmt)
            colorfmt_static = self.fstring_to_template(colorfmt_static)
            # colorfmt_dynamic 保留 !c 转换，不做转换

        # 开头结尾都追加重置代码,确保不影响其他输出
        colorfmt_static = self._reset_code + colorfmt_static + self._reset_code
        colorfmt_dynamic = (
            self._reset_code + colorfmt_dynamic + self._reset_code
        )

        return (plainfmt, colorfmt_static, colorfmt_dynamic)

    def build_as_percent(self) -> FormatStrings:
        """构建百分号格式的字符串

        Returns:
            元组 (plainfmt, colorfmt_static, colorfmt_dynamic):
            - plainfmt: 无颜色的百分号格式字符串
            - colorfmt_static: 带静态颜色的百分号格式字符串
            - colorfmt_dynamic: 带动态级别颜色的百分号格式字符串 (含 !c 转换)
        """
        plainfmt: str = self.fstring_to_percent(self._plainfmt.strip())
        colorfmt_static: str = self.fstring_to_percent(
            self._colorfmt_static.strip()
        )
        colorfmt_dynamic: str = self._colorfmt_dynamic.strip()  # 不转换,保留 !c
        # 开头结尾都追加重置代码,确保不影响其他输出
        colorfmt_static = self._reset_code + colorfmt_static + self._reset_code
        colorfmt_dynamic = (
            self._reset_code + colorfmt_dynamic + self._reset_code
        )
        return (plainfmt, colorfmt_static, colorfmt_dynamic)

    def build_as_fstring(self) -> FormatStrings:
        """构建大括号(f-string)格式的字符串

        Returns:
            元组 (plainfmt, colorfmt_static, colorfmt_dynamic):
            - plainfmt: 无颜色的大括号格式字符串
            - colorfmt_static: 带静态颜色的大括号格式字符串
            - colorfmt_dynamic: 带动态级别颜色的大括号格式字符串 (含 !c 转换)
        """
        plainfmt: str = self._plainfmt.strip()
        colorfmt_static: str = self._colorfmt_static.strip()
        colorfmt_dynamic: str = self._colorfmt_dynamic.strip()
        # 开头结尾都追加重置代码,确保不影响其他输出
        colorfmt_static = self._reset_code + colorfmt_static + self._reset_code
        colorfmt_dynamic = (
            self._reset_code + colorfmt_dynamic + self._reset_code
        )
        return (plainfmt, colorfmt_static, colorfmt_dynamic)

    def build_as_template(self) -> FormatStrings:
        """构建Template($符号)格式的字符串

        Returns:
            元组 (plainfmt, colorfmt_static, colorfmt_dynamic):
            - plainfmt: 无颜色的Template格式字符串
            - colorfmt_static: 带静态颜色的Template格式字符串
            - colorfmt_dynamic: 带动态级别颜色的Template格式字符串 (含 !c 转换)
        """
        plainfmt: str = self.fstring_to_template(self._plainfmt.strip())
        colorfmt_static: str = self.fstring_to_template(
            self._colorfmt_static.strip()
        )
        colorfmt_dynamic: str = self._colorfmt_dynamic.strip()  # 不转换,保留 !c
        # 开头结尾都追加重置代码,确保不影响其他输出
        colorfmt_static = self._reset_code + colorfmt_static + self._reset_code
        colorfmt_dynamic = (
            self._reset_code + colorfmt_dynamic + self._reset_code
        )
        return (plainfmt, colorfmt_static, colorfmt_dynamic)

    def reset(self) -> "FormatBuilder":
        """重置内部构造的格式字符串

        使builder可以重新构建新的格式字符串,同时保留配置(颜色、风格等)。
        如需清除已构造的内容,请手动调用此方法。

        Returns:
            self,支持链式调用
        """
        self._plainfmt = ""
        self._colorfmt_static = ""
        self._colorfmt_dynamic = ""
        return self
