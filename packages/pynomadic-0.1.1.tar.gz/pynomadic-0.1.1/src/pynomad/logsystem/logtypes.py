"""日志格式化相关的类型定义和工具函数"""

from typing import Literal, TypeAlias

from pynomad.common.ansi import AnsiStyle, Color
from pynomad.common.types import Level

type FmtStyle = Literal["%", "{", "$"]
type PercentFlag = Literal["#", "0", "-", " ", "+"]
# fmt: off
type Mark = Literal[
    "d","i","o","u","x","X","e","E","f","F","g","G","c","r","s","a","%",
]
# fmt: on
type StrFmtFlag = Literal["s", "r", "a", "c"]

# 对齐类型定义
type AlignType = Literal["<", ">", "^", "="]

# 配置类型定义
type ColorConfig = None | int | str | Color
type StyleConfig = None | int | str | AnsiStyle
# 支持多个样式的类型：可以是单个样式、样式列表、样式元组，或用逗号分隔的字符串
type Styles = (AnsiStyle | tuple[AnsiStyle, ...] | list[AnsiStyle] | str)
type LevelStyleMap = dict[int | Level, tuple[Styles, int | Color, int | Color]]
# 格式字符串三元组类型别名
FormatStrings: TypeAlias = tuple[str, str, str]


def parse_color_config(
    color_config: ColorConfig, is_foreground: bool = True
) -> int:
    """解析颜色配置为ANSI颜色代码

    Args:
        color_config: 颜色配置,支持:
            - None: 使用默认颜色 (39/49)
            - int: 直接使用ANSI颜色代码 (30-37, 40-47, 90-97, 100-107)
            - str: 颜色名称,如 "black", "bright_black", "cyan" 等
            - Color: Color枚举值,如 Color.RED, Color.BLUE
        is_foreground: True解析为前景色,False解析为背景色

    Returns:
        ANSI颜色代码，无效配置时返回默认颜色
    """
    if color_config is None:
        return Color.DEFAULT.fore if is_foreground else Color.DEFAULT.back

    # 必须先判断Color类型,因为Color继承自int
    if isinstance(color_config, Color):
        if is_foreground:
            return color_config.fore
        return color_config.back

    if isinstance(color_config, int):
        return color_config

    color_name: str = color_config.upper().strip()
    prefix: str = "BRIGHT_"
    is_bright: bool = color_name.startswith(prefix)
    if is_bright:
        color_name = color_name[len(prefix) :]

    try:
        color = Color[color_name]
        if is_bright:
            if is_foreground:
                return color.bright_fore
            return color.bright_back
        if is_foreground:
            return color.fore
        return color.back
    except KeyError:
        return Color.DEFAULT.fore if is_foreground else Color.DEFAULT.back


def parse_style_config(style_config: StyleConfig) -> int:
    """解析样式配置为ANSI样式代码

    Args:
        style_config: 样式配置,支持:
            - None: 使用默认样式 (0 - RESET)
            - int: 直接使用ANSI样式代码 (0-21)
            - str: 样式名称,如 "bold", "italic", "underline" 等
            - AnsiStyle: AnsiStyle枚举值,如 AnsiStyle.BOLD, AnsiStyle.UNDERLINE

    Returns:
        ANSI样式代码，无效配置时返回默认样式
    """
    if style_config is None:
        return AnsiStyle.RESET.value

    # 必须先判断AnsiStyle类型,因为AnsiStyle继承自IntEnum
    if isinstance(style_config, AnsiStyle):
        return style_config.value

    if isinstance(style_config, int):
        return style_config

    style_name: str = style_config.upper().strip()

    try:
        style_enum: AnsiStyle = AnsiStyle[style_name]
        return style_enum.value
    except KeyError:
        return AnsiStyle.RESET.value


def parse_styles_config(styles_config: Styles) -> tuple[AnsiStyle, ...]:
    """解析样式配置为样式元组

    Args:
        styles_config: 样式配置,支持:
            - AnsiStyle: 单个样式
            - tuple[AnsiStyle, ...]: 样式元组
            - list[AnsiStyle]: 样式列表
            - str: 用逗号分隔的样式名称,如 "bold,underline" 或 "bold, underline"

    Returns:
        样式元组,包含所有解析出的AnsiStyle枚举值
        空元组表示无样式
    """
    if isinstance(styles_config, AnsiStyle):
        return (styles_config,)

    if isinstance(styles_config, tuple):
        return styles_config

    if isinstance(styles_config, list):
        return tuple(styles_config)

    # 解析逗号分隔的样式字符串
    style_names: list[str] = [
        name.strip() for name in styles_config.split(",") if name.strip()
    ]
    styles: list[AnsiStyle] = []
    for name in style_names:
        try:
            style_enum: AnsiStyle = AnsiStyle[name.upper()]
            styles.append(style_enum)
        except KeyError:
            # 忽略无效的样式名称
            continue
    return tuple(styles)
