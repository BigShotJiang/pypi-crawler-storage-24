"""日志格式化器"""

from collections.abc import Mapping
from logging import Formatter, LogRecord
import re
from typing import Any, cast, override

from pynomad.common.ansi import AnsiStyle, Color
from pynomad.common.types import Level
from pynomad.logsystem.builder import FormatBuilder
from pynomad.logsystem.logtypes import (
    FormatStrings,
    LevelStyleMap,
    parse_color_config,
    parse_styles_config,
)


class BaseFormatter(Formatter):
    """基础日志格式化器

    继承自 logging.Formatter,默认使用大括号风格
    """

    DEFAULT_DATEFMT: str = "%H:%M:%S"

    @staticmethod
    def _get_default_format_strings() -> FormatStrings:
        """使用 FormatBuilder 生成默认格式字符串"""
        # fmt:off
        builder=FormatBuilder()\
               .add_fore(Color.MAGENTA)\
               .add_asctime(width=9, align="<")\
               .reset_style()\
               .add_fore(Color.CYAN.bright_fore)\
               .add_name(align="<", width=25, truncate=True)\
               .reset_style()\
               .add_string(":")\
               .add_style(AnsiStyle.DIM)\
               .add_fore(Color.BLUE)\
               .add_lineno(width=4, align=">", fill="0")\
               .reset_style()\
               .add_string(" [")\
               .add_style(AnsiStyle.BOLD)\
               .add_levelname(width=5, fill="*", align="^", use_level_color=True)\
               .reset_style()\
               .add_string("] ")\
               .add_message(use_level_color=True)
        # fmt:on
        return builder.build()

    DEFAULT_FORMAT_STRINGS: FormatStrings = _get_default_format_strings()

    def __init__(
        self,
        fmt: str | None = None,
        datefmt: str | None = None,
        validate: bool = True,
        *,
        defaults: Mapping[str, Any] | None = None,
    ):
        """初始化基础格式化器

        Args:
            fmt: 格式字符串
            datefmt: 时间格式字符串
            validate: 是否验证格式字符串
            defaults: 默认值字典
        """
        super().__init__(fmt, datefmt, "{", validate, defaults=defaults)


class ColorFormatter(BaseFormatter):
    """支持动态级别颜色和样式的日志格式化器

    处理带有 "!c" 转换标记的格式字符串,根据日志级别自动应用颜色和样式。
    支持中间截断功能：当字段有精度限制时（如 {module:>30.30}），
    超长字符串会在中间被截断为省略号。

    Attributes:
        LEVEL_STYLE_MAP: 日志级别到颜色和样式的映射表

    Example:
        >>> builder = FormatBuilder()
        >>> builder.add_levelname(width=8, use_level_color=True)
        >>> _, _, colorfmt_dynamic = builder.build()
        >>> formatter = ColorFormatter(colorfmt_dynamic, datefmt=builder.datafmt)
        >>> logger.setFormatter(formatter)
    """

    # 日志级别样式映射：样式元组, 前景色, 背景色
    LEVEL_STYLE_MAP: LevelStyleMap = {
        Level.TRACE: (AnsiStyle.DIM, Color.CYAN.bright_fore, Color.DEFAULT),
        Level.DEBUG: ((), Color.WHITE.bright_fore, Color.DEFAULT),
        Level.INFO: ((), Color.GREEN.fore, Color.DEFAULT),
        Level.WARN: ((), Color.YELLOW.fore, Color.DEFAULT),
        Level.ERROR: ((), Color.RED.fore, Color.DEFAULT),
        # Level.FATAL: ((AnsiStyle.BOLD), Color.RED.bright_fore, Color.DEFAULT),
        Level.FATAL: (
            (AnsiStyle.BOLD, AnsiStyle.UNDERLINE),
            Color.RED.bright_fore,
            Color.DEFAULT,
        ),
    }

    def __init__(
        self,
        fmt: str = BaseFormatter.DEFAULT_FORMAT_STRINGS[2],
        datefmt: str = BaseFormatter.DEFAULT_DATEFMT,
        validate: bool = True,
        *,
        defaults: Mapping[str, Any] | None = None,
        level_style_map: LevelStyleMap | None = None,
    ) -> None:
        """初始化颜色格式化器

        Args:
            fmt: 格式字符串,可包含 "{fieldname!c:format}" 这样的字段
            datefmt: 时间格式字符串
            validate: 是否验证格式字符串
            defaults: 默认值字典
            level_style_map: 自定义日志级别样式映射 (样式元组, 前景色, 背景色)
        """
        if not fmt:
            fmt = BaseFormatter.DEFAULT_FORMAT_STRINGS[2]
        if not datefmt:
            datefmt = BaseFormatter.DEFAULT_DATEFMT
        # 保存原始格式字符串
        self._original_fmt: str | None = fmt

        # 将 !c 替换为 !s 作为默认格式字符串
        plaintext_fmt: str | None = fmt
        if fmt and "!c" in fmt:
            plaintext_fmt = fmt.replace("!c", "!s")

        if level_style_map is not None:
            self._level_style_map: LevelStyleMap = level_style_map
        else:
            self._level_style_map = self.LEVEL_STYLE_MAP.copy()

        # 使用 plaintext 格式字符串初始化基类
        super().__init__(plaintext_fmt, datefmt, validate, defaults=defaults)

    @override
    def format(self, record: LogRecord) -> str:
        """格式化日志记录,处理 !c 转换

        Args:
            record: 日志记录对象

        Returns:
            格式化后的日志字符串
        """
        # 准备消息
        record.message = record.getMessage()
        if self.usesTime():
            record.asctime = self.formatTime(record, self.datefmt)

        # 确定要使用的格式字符串
        if self._original_fmt and "!c" in self._original_fmt:
            fmt_str: str = self._apply_color_conversion(
                self._original_fmt, record
            )
        else:
            fmt_str = getattr(self._style, "_fmt")

        # 获取格式化所需的值
        style = self._style
        defaults = getattr(style, "_defaults", None)
        if isinstance(defaults, Mapping):
            # 将 Mapping 转换为 dict 以支持 | 运算符
            defaults = cast(dict[str, Any], defaults)
            defaults_dict: dict[str, Any] = dict(defaults)
            values = defaults_dict | record.__dict__
        else:
            values = record.__dict__

        # 格式化消息
        s = fmt_str.format(**values)

        # 应用中间截断处理
        s = self._apply_truncation(s, fmt_str, record)

        # 处理异常信息
        if record.exc_info:
            if not record.exc_text:
                record.exc_text = self.formatException(record.exc_info)
        if record.exc_text:
            if s[-1:] != "\n":
                s = s + "\n"
            s = s + record.exc_text

        # 处理堆栈信息
        if record.stack_info:
            if s[-1:] != "\n":
                s = s + "\n"
            s = s + self.formatStack(record.stack_info)

        return s

    def _apply_color_conversion(self, fmt: str, record: LogRecord) -> str:
        """应用颜色和样式转换到格式字符串

        将 {name!c:format} 替换为带有样式和颜色代码的格式

        Args:
            fmt: 原始格式字符串
            record: 日志记录对象

        Returns:
            应用样式和颜色后的格式字符串
        """

        # 匹配 {name!c:format} 模式
        pattern: str = r"\{(\w+)!c(:.*?)?\}"

        def replace_color(match: re.Match[str]) -> str:
            field_name: str = match.group(1)
            format_spec: str = match.group(2) or ""

            # 获取样式、前景色、背景色配置
            styles_config, fore_color_config, back_color_config = (
                self._level_style_map.get(
                    record.levelno,
                    ((), Color.DEFAULT, Color.DEFAULT),
                )
            )

            # 解析样式配置为样式元组
            styles: tuple[AnsiStyle, ...] = parse_styles_config(styles_config)

            # 解析颜色配置
            fore_color: int = parse_color_config(
                fore_color_config, is_foreground=True
            )
            back_color: int = parse_color_config(
                back_color_config, is_foreground=False
            )

            # 构建样式代码序列
            style_codes: list[int] = [style.value for style in styles]

            # 如果有样式,应用样式代码
            style_prefix: str = ""
            if style_codes:
                style_prefix = f"\033[{';'.join(map(str, style_codes))}m"

            # 如果有背景色,应用背景色
            back_color_prefix: str = ""
            if back_color != Color.DEFAULT.back:
                back_color_prefix = f"\033[{back_color}m"

            # 使用 + 拼接 f-string 方便阅读
            return (
                style_prefix
                + f"\033[{fore_color}m"
                + back_color_prefix
                + f"{{{field_name}{format_spec}}}"
                + f"\033[{Color.DEFAULT.fore}m"
                + f"\033[{Color.DEFAULT.back}m"
                + f"\033[{AnsiStyle.RESET.value}m"
            )

        return re.sub(pattern, replace_color, fmt)

    def _apply_truncation(
        self,
        formatted_str: str,
        fmt_str: str,
        record: LogRecord,
    ) -> str:
        """应用中间截断处理

        检测格式字符串中的精度限制，对格式化后的字符串进行中间截断。
        由于 Python 的格式化会先进行尾部截断，我们需要重新截断为中间省略号。

        Args:
            formatted_str: 已格式化的字符串
            fmt_str: 格式字符串
            record: 日志记录对象

        Returns:
            处理截断后的字符串
        """
        # 匹配格式字符串中的字段名和精度限制
        # 例如: {name:>15.15} 匹配到 name 和 15
        pattern: str = r"\{(\w+)(:[^}]*?\.(\d+))?\}"

        fields_to_truncate: dict[str, int] = {}
        for match in re.finditer(pattern, fmt_str):
            field_name: str = match.group(1)
            precision: str = match.group(3)
            if precision:
                fields_to_truncate[field_name] = int(precision)

        # 如果没有需要截断的字段，直接返回
        if not fields_to_truncate:
            return formatted_str

        # 对格式化后的字符串应用中间截断
        result: str = formatted_str
        for field_name, max_len in fields_to_truncate.items():
            # 获取原始值
            value = getattr(record, field_name, None)
            if value is None:
                continue

            value_str = str(value)
            if len(value_str) <= max_len:
                continue

            # 前面固定保留3个字符，使用2-3个省略号，更多保留后半部分
            prefix_len: int = 3
            ellipsis: str = (
                ".."
                if max_len - prefix_len - 1 <= len(value_str) - prefix_len - 2
                else "..."
            )
            suffix_len: int = max_len - prefix_len - len(ellipsis)
            truncated: str = (
                value_str[:prefix_len] + ellipsis + value_str[-suffix_len:]
            )

            # Python 的格式化会先进行尾部截断，所以我们需要找到并替换那个被截断的值
            # 被截断的值 = 原始值的前 max_len 个字符
            tail_truncated = value_str[:max_len]

            # 如果格式化后的字符串包含尾部截断的值，替换为中间截断的值
            if tail_truncated in result and tail_truncated != truncated:
                result = result.replace(tail_truncated, truncated, 1)

        return result
