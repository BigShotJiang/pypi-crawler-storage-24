"""命名风格枚举模块

定义所有支持的命名风格枚举类型，使用 IntFlag 支持位或运算，
可以同时表示多种命名风格（用于检测所有可能的风格）。
"""

from enum import IntFlag, auto


class NameStyle(IntFlag):
    """名称风格枚举

    使用 IntFlag 支持位或运算，可以同时表示多种命名风格。
    例如：detect_possible_styles 可能返回 PASCAL | UPPER_KEBAB | UPPER_SNAKE
    """

    # 驼峰/帕斯卡风格
    PASCAL = auto()  # 大驼峰命名 (PascalCase)
    CAMEL = auto()  # 小驼峰命名 (camelCase)

    # 短横线风格
    KEBAB = auto()  # 短横线命名 (kebab-case)
    STANDARD_KEBAB = auto()  # 标准短横线命名
    UPPER_KEBAB = auto()  # 大写短横线命名 (UPPER-KEBAB-CASE)
    PASCAL_KEBAB = auto()  # 帕斯卡短横线命名 (Pascal-Kebab-Case)

    # 蛇形风格
    SNAKE = auto()  # 蛇形命名 (snake_case)
    UPPER_SNAKE = auto()  # 大写蛇形命名 (UPPER_SNAKE_CASE)
    PASCAL_SNAKE = auto()  # 帕斯卡蛇形命名 (Pascal_Snake_Case)
    STANDARD_SNAKE = auto()  # 标准蛇形命名
    MAGIC_SNAKE = auto()  # 魔术蛇形命名 (__magic_method__)
    PROTECTED_SNAKE = auto()  # Python保护蛇形命名 (_protected_var)
    PRIVATE_SNAKE = auto()  # Python私有蛇形命名 (__private_var)
    END_SNAKE = (
        auto()
    )  # Python尾蛇形变量 (end_snake_)，在Pydantic中用于给关键字命名

    # 其他风格
    HUNGARIAN = auto()  # 匈牙利命名 (HungarianNotation)
    UNKNOWN = auto()  # 未知命名风格（存在歧义的合法命名）
    INVALID = auto()  # 无效命名（语法错误）


NAMEING_PACKAGE_NAME = "pynomad.naming"
