"""命名系统模式模块"""

import re
from re import Pattern

from pynomad.common.decorator import singleton


@singleton
class PatternManager:
    """正则表达式模式管理器 - 单例模式"""

    # 实例变量 - 正则表达式模式
    # 这些变量会在 __init__ 中初始化，避免未定义错误
    _valid_identifier_pattern: Pattern[str] | None = None
    _valid_general_identifier_pattern: Pattern[str] | None = None
    _camel_pattern: Pattern[str] | None = None
    _pascal_pattern: Pattern[str] | None = None
    _kebab_pattern: Pattern[str] | None = None
    _standard_kebab_pattern: Pattern[str] | None = None
    _upper_kebab_pattern: Pattern[str] | None = None
    _pascal_kebab_pattern: Pattern[str] | None = None
    _snake_pattern: Pattern[str] | None = None
    _standard_snake_pattern: Pattern[str] | None = None
    _upper_snake_pattern: Pattern[str] | None = None
    _pascal_snake_pattern: Pattern[str] | None = None
    _magic_snake_pattern: Pattern[str] | None = None
    _protected_snake_pattern: Pattern[str] | None = None
    _private_snake_pattern: Pattern[str] | None = None
    _end_snake_pattern: Pattern[str] | None = None

    def __init__(self):
        super().__init__()
        self._init_patterns()

    def _init_patterns(self) -> None:
        """初始化正则表达式模式"""
        # 基础模式
        self._valid_identifier_pattern = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*$")
        self._valid_general_identifier_pattern = re.compile(
            r"^[a-zA-Z_-][a-zA-Z0-9_-]*$"
        )

        # 驼峰模式
        self._camel_pattern = re.compile(r"^[a-z][a-zA-Z0-9]*$")
        self._pascal_pattern = re.compile(r"^[A-Z][a-zA-Z0-9]*$")

        # 短横线模式
        self._kebab_pattern = re.compile(r"^[a-z][a-z0-9]*(-[a-z0-9]+)*$")
        self._standard_kebab_pattern = re.compile(
            r"^[a-z][a-z0-9]*(-[a-z0-9]+)*$"
        )
        self._upper_kebab_pattern = re.compile(r"^[A-Z][A-Z0-9]*(-[A-Z0-9]+)*$")
        self._pascal_kebab_pattern = re.compile(
            r"^[A-Z][a-z0-9]*(?:-[A-Z][a-z0-9]*|-[0-9]+[a-z0-9]*)*$"
        )

        # 蛇形模式
        self._snake_pattern = re.compile(r"^[a-z][a-z0-9]*(_[a-z0-9]+)*$")
        self._standard_snake_pattern = re.compile(
            r"^[a-z][a-z0-9]*(_[a-z0-9]+)*$"
        )
        self._upper_snake_pattern = re.compile(r"^[A-Z][A-Z0-9]*(_[A-Z0-9]+)*$")
        self._pascal_snake_pattern = re.compile(
            r"^[A-Z][a-z0-9]*(?:_[A-Z][a-z0-9]*|_[0-9]+[a-z0-9]*)*$"
        )

        # Python特有模式
        self._magic_snake_pattern = re.compile(
            r"^__[a-z][a-z0-9]*(_[a-z0-9]+)*__$"
        )
        self._protected_snake_pattern = re.compile(
            r"^_[a-z][a-z0-9]*(_[a-z0-9]+)*$"
        )
        self._private_snake_pattern = re.compile(
            r"^__[a-z][a-z0-9]*(?:_[a-z0-9]+)*$"
        )
        # Pydantic尾蛇形变量：要求至少3个字符且是有效的标识符结构
        # 例如: end_, field_, value_ 等
        self._end_snake_pattern = re.compile(r"^[a-z]{2,}_(?:[a-z0-9]+_)*$")

    @property
    def valid_identifier_pattern(self) -> Pattern[str]:
        """有效标识符模式"""
        assert self._valid_identifier_pattern is not None
        return self._valid_identifier_pattern

    @property
    def valid_general_identifier_pattern(self) -> Pattern[str]:
        """有效通用标识符模式"""
        assert self._valid_general_identifier_pattern is not None
        return self._valid_general_identifier_pattern

    @property
    def camel_pattern(self) -> Pattern[str]:
        """驼峰命名模式"""
        assert self._camel_pattern is not None
        return self._camel_pattern

    @property
    def pascal_pattern(self) -> Pattern[str]:
        """帕斯卡命名模式"""
        assert self._pascal_pattern is not None
        return self._pascal_pattern

    @property
    def kebab_pattern(self) -> Pattern[str]:
        """短横线命名模式"""
        assert self._kebab_pattern is not None
        return self._kebab_pattern

    @property
    def standard_kebab_pattern(self) -> Pattern[str]:
        """标准短横线命名模式"""
        assert self._standard_kebab_pattern is not None
        return self._standard_kebab_pattern

    @property
    def upper_kebab_pattern(self) -> Pattern[str]:
        """大写短横线命名模式"""
        assert self._upper_kebab_pattern is not None
        return self._upper_kebab_pattern

    @property
    def pascal_kebab_pattern(self) -> Pattern[str]:
        """帕斯卡短横线命名模式"""
        assert self._pascal_kebab_pattern is not None
        return self._pascal_kebab_pattern

    @property
    def snake_pattern(self) -> Pattern[str]:
        """蛇形命名模式"""
        assert self._snake_pattern is not None
        return self._snake_pattern

    @property
    def standard_snake_pattern(self) -> Pattern[str]:
        """标准蛇形命名模式"""
        assert self._standard_snake_pattern is not None
        return self._standard_snake_pattern

    @property
    def upper_snake_pattern(self) -> Pattern[str]:
        """大写蛇形命名模式"""
        assert self._upper_snake_pattern is not None
        return self._upper_snake_pattern

    @property
    def pascal_snake_pattern(self) -> Pattern[str]:
        """帕斯卡蛇形命名模式"""
        assert self._pascal_snake_pattern is not None
        return self._pascal_snake_pattern

    @property
    def magic_snake_pattern(self) -> Pattern[str]:
        """魔术蛇形命名模式"""
        assert self._magic_snake_pattern is not None
        return self._magic_snake_pattern

    @property
    def protected_snake_pattern(self) -> Pattern[str]:
        """保护蛇形命名模式"""
        assert self._protected_snake_pattern is not None
        return self._protected_snake_pattern

    @property
    def private_snake_pattern(self) -> Pattern[str]:
        """私有蛇形命名模式"""
        assert self._private_snake_pattern is not None
        return self._private_snake_pattern

    @property
    def end_snake_pattern(self) -> Pattern[str]:
        """尾蛇形命名模式（以_结尾，用于Pydantic关键字）"""
        assert self._end_snake_pattern is not None
        return self._end_snake_pattern
