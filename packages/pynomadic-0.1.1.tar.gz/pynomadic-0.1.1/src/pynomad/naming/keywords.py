"""命名系统关键字模块

使用 importlib.resources 从包内加载关键字数据。
支持 Python、Java、JavaScript/TypeScript、C/C++、C#、PHP 等语言的关键字检测。
"""

import json
from typing import Any

from importlib import resources as importlib_resources

from pynomad.common.decorator import singleton
from pynomad.naming.naming_types import NAMEING_PACKAGE_NAME


@singleton
class KeywordManager:
    """关键字管理器 - 单例模式

    从 keywords.json 文件加载各种编程语言的关键字数据。
    使用 importlib.resources 确保在打包后仍能正确读取资源文件。
    """

    # 实例变量 - 关键字集合
    # 这些变量会在 __init__ 中从 JSON 文件加载
    _py_keywords: set[str] | None = None
    _py_soft_keywords: set[str] | None = None
    _java_keywords: set[str] | None = None
    _js_keywords: set[str] | None = None
    _ts_keywords: set[str] | None = None
    _c_keywords: set[str] | None = None
    _cpp_keywords: set[str] | None = None
    _csharp_keywords: set[str] | None = None
    _php_keywords: set[str] | None = None
    _all_keywords: set[str] | None = None

    def __init__(self):
        super().__init__()
        self._init_keywords()

    def _init_keywords(self) -> None:
        """从 keywords.json 文件加载各语言关键字"""
        # 使用 importlib.resources 读取包内资源文件
        try:
            # Python 3.9+ 使用 files API
            with (
                importlib_resources.files(NAMEING_PACKAGE_NAME)
                .joinpath("keywords.json")
                .open("r", encoding="utf-8") as f
            ):
                data = self._load_keywords_from_json(f)
        except (AttributeError, TypeError):
            # Python 3.8 或更早版本回退到 read_text
            content = importlib_resources.read_text(
                NAMEING_PACKAGE_NAME, "keywords.json"
            )
            data = self._load_keywords_from_json_str(content)

        # 解析并存储关键字集合
        languages = data.get("languages", {})
        self._py_keywords = set(languages.get("python", {}).get("keywords", []))
        self._py_soft_keywords = set(
            languages.get("python", {}).get("soft_keywords", [])
        )
        self._java_keywords = set(languages.get("java", {}).get("keywords", []))
        self._js_keywords = set(
            languages.get("javascript", {}).get("keywords", [])
        )
        self._ts_keywords = set(
            languages.get("typescript", {}).get("keywords", [])
        )
        self._c_keywords = set(languages.get("c", {}).get("keywords", []))
        self._cpp_keywords = set(languages.get("cpp", {}).get("keywords", []))
        self._csharp_keywords = set(
            languages.get("csharp", {}).get("keywords", [])
        )
        self._php_keywords = set(languages.get("php", {}).get("keywords", []))

        # 预计算所有关键字的并集，提高查询性能
        self._all_keywords = (
            self._py_keywords
            | self._py_soft_keywords
            | self._java_keywords
            | self._js_keywords
            | self._ts_keywords
            | self._c_keywords
            | self._cpp_keywords
            | self._csharp_keywords
            | self._php_keywords
        )

    def _load_keywords_from_json(self, file_obj: Any) -> dict[str, Any]:
        """从文件对象加载 JSON 数据

        Args:
            file_obj: 文件对象（支持 read() 方法）

        Returns:
            解析后的 JSON 数据字典
        """

        content = file_obj.read()
        return json.loads(content)

    def _load_keywords_from_json_str(self, content: str) -> dict[str, Any]:
        """从 JSON 字符串加载数据

        Args:
            content: JSON 字符串

        Returns:
            解析后的 JSON 数据字典
        """
        return json.loads(content)

    @property
    def py_keywords(self) -> set[str]:
        """Python关键字"""
        assert self._py_keywords is not None
        return self._py_keywords

    @property
    def py_soft_keywords(self) -> set[str]:
        """Python软关键字"""
        assert self._py_soft_keywords is not None
        return self._py_soft_keywords

    @property
    def java_keywords(self) -> set[str]:
        """Java关键字"""
        assert self._java_keywords is not None
        return self._java_keywords

    @property
    def js_keywords(self) -> set[str]:
        """JavaScript关键字"""
        assert self._js_keywords is not None
        return self._js_keywords

    @property
    def ts_keywords(self) -> set[str]:
        """TypeScript关键字"""
        assert self._ts_keywords is not None
        return self._ts_keywords

    @property
    def c_keywords(self) -> set[str]:
        """C关键字"""
        assert self._c_keywords is not None
        return self._c_keywords

    @property
    def cpp_keywords(self) -> set[str]:
        """C++关键字"""
        assert self._cpp_keywords is not None
        return self._cpp_keywords

    @property
    def csharp_keywords(self) -> set[str]:
        """C#关键字"""
        assert self._csharp_keywords is not None
        return self._csharp_keywords

    @property
    def php_keywords(self) -> set[str]:
        """PHP关键字"""
        assert self._php_keywords is not None
        return self._php_keywords

    def is_py_keyword(self, name: str) -> bool:
        """检查是否是Python关键字"""
        return name in self.py_keywords

    def is_py_softkeyword(self, name: str) -> bool:
        """检查是否是Python软关键字"""
        return name in self.py_soft_keywords

    def is_java_keyword(self, name: str) -> bool:
        """检查是否是Java关键字"""
        return name in self.java_keywords

    def is_js_keyword(self, name: str) -> bool:
        """检查是否是JavaScript关键字"""
        return name in self.js_keywords

    def is_ts_keyword(self, str_name: str) -> bool:
        """检查是否是TypeScript关键字"""
        return str_name in self.ts_keywords

    def is_c_keyword(self, name: str) -> bool:
        """检查是否是C关键字"""
        return name in self.c_keywords

    def is_cpp_keyword(self, name: str) -> bool:
        """检查是否是C++关键字"""
        return name in self.cpp_keywords

    def is_csharp_keyword(self, name: str) -> bool:
        """检查是否是C#关键字"""
        return name in self.csharp_keywords

    def is_php_keyword(self, name: str) -> bool:
        """检查是否是PHP关键字"""
        return name in self.php_keywords

    def is_keyword(self, name: str) -> bool:
        """检查是否是任何语言的关键字 - 使用预计算的并集提高性能"""
        assert self._all_keywords is not None
        return name in self._all_keywords
