from dataclasses import dataclass
from pathlib import Path

from pynomad.cache.core.types import EvictionPolicy
from pynomad.config.auto.autoconfig import inject
from pynomad.config.auto.field_info import field


@dataclass
class CacheProperties:
    name: str = field(default="cache")
    maxsize: int = field(default=0)
    eviction_policy: EvictionPolicy = field(default="none")
    ttl: int = field(default=0)  # 缓存存活时间（秒），0 表示永不过期


@inject(prefix="cache.memory")
class MemoryCacheProperties(CacheProperties): ...


@inject(prefix="cache.dfmemory")
class DataFrameMemoryCacheProperties(MemoryCacheProperties): ...


@inject(prefix="cache.redis")
class RedisCacheProperties(CacheProperties):
    host: str = field(default="localhost")
    port: int = field(default=6379)
    db: int = field(default=0)
    username: str= field(default="")
    password: str= field(default="")
    enable_encryption: bool = field(default=False)
    salt: str = field(default="pynomad_cache_v1")


@inject(prefix="cache.dfredis")
class DataFrameRedisCacheProperties(RedisCacheProperties): ...


@inject(prefix="cache.pickle")
class PickleCacheProperties(CacheProperties):
    cache_dir: Path = field(default="{workspace}/cache")
    maxsize: int = field(default=0)  # PickleCache 默认无限制
    enable_encryption: bool = field(default=False)
    salt: str = field(default="pynomad_pickle_cache_v1")
    enable_background_cleanup: bool = field(default=True)
    cleanup_interval: int = field(default=300)  # seconds


@inject(prefix="cache.dfpickle")
class DataFramePickleCacheProperties(PickleCacheProperties): ...


@inject(prefix="cache.sql")
class SQLCacheProperties(CacheProperties):
    second_name: str = field(default="")
    db_type: str = field(default="sqlite")
    db_url: str = field(default=None)
    host: str = field(default="localhost")
    port: int = field(default=3306)
    db_name: str = field(default="cache")
    username: str = field(default="root")
    password: str | None = field(default=None)
    pool_size: int = field(default=5)
    max_overflow: int = field(default=10)
    pool_timeout: int = field(default=30)
    pool_recycle: int = field(default=3600)
    pool_pre_ping: bool = field(default=True)
    max_retry_attempts: int = field(default=3)
    retry_delay: float = field(default=1.0)


@inject(prefix="cache.dfsql")
class DataFrameSQLCacheProperties(SQLCacheProperties): ...
