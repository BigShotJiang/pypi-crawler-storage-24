import random
import time
from typing import cast, override


from pynomad.cache.core.cache_interface import Cache
from pynomad.cache.core.cache_registry import CacheRegistry
from pynomad.cache.core.meta import MetaInfo
from pynomad.cache.core.types import EvictionPolicy, ValueLoader
from pynomad.cache.properties import MemoryCacheProperties
from pynomad.result.result import Result, ResultAny

# 缓存entry的常量key
_VALUE_KEY: str = "value"
_META_KEY: str = "meta"


@CacheRegistry.register("memory")
class MemoryCache(Cache):
    # 缓存名,缓存key,value|meta
    _memory_cache_stores: dict[str, dict[str, dict[str, object]]] = {}

    @staticmethod
    def get_store(name: str) -> dict[str, dict[str, object]]:
        if name in MemoryCache._memory_cache_stores:
            return MemoryCache._memory_cache_stores[name]
        MemoryCache._memory_cache_stores[name] = {}
        return MemoryCache._memory_cache_stores[name]

    @staticmethod
    def remove_store(name: str) -> None:
        if name in MemoryCache._memory_cache_stores:
            del MemoryCache._memory_cache_stores[name]

    def __init__(
        self,
        name: str = "",
        maxsize: int | None = None,
        eviction_policy: EvictionPolicy | None = None,
    ):
        props = MemoryCacheProperties()
        name = name if name else props.name
        maxsize = maxsize if maxsize is not None and maxsize != 0 else props.maxsize
        eviction_policy = (
            eviction_policy if eviction_policy else props.eviction_policy
        )
        super().__init__(
            name=name, maxsize=maxsize, eviction_policy=eviction_policy
        )
        # 缓存存储器
        self._store = self.get_store(name)

    def _clean(self):
        """自动清理"""
        # 清理过期的key
        _ = self._clean_expired_keys()
        # 检查是否需要根据策略清理
        _ = self._clean_if_needed()

    def _clean_if_needed(self) -> int:
        """根据策略和容量判断是否需要清理

        Returns:
            清理的key数量
        """
        current_size: int = len(self._store)
        # 当达到或超过 maxsize 的 133% 时才触发清理
        overflow_threshold: float = self.maxsize * 4 / 3
        if current_size < overflow_threshold:
            return 0

        # 根据策略清理到 maxsize
        if self.eviction_policy == "lru":
            return self._clean_lru_keys()
        if self.eviction_policy == "lfu":
            return self._clean_lfu_keys()
        if self.eviction_policy == "fifo":
            return self._clean_fifo_keys()
        if self.eviction_policy == "rr":
            return self._clean_rr_keys()
        if self.eviction_policy == "mru":
            return self._clean_mru_keys()
        return 0

    def _clean_lfu_keys(self) -> int:
        """清理LFU多余的key

        Returns:
            清理的key数量
        """
        key_access_count: list[tuple[str, int]] = []

        for key, entry in self._store.items():
            meta_obj: object = entry.get(_META_KEY, {})
            if not isinstance(meta_obj, MetaInfo):
                # 脏数据，直接删除
                del self._store[key]
                continue
            meta: MetaInfo = meta_obj
            key_access_count.append((key, meta.access_count))

        # 按access_count降序排序
        key_access_count.sort(key=lambda x: x[1], reverse=True)

        # 保留前maxsize-1条，多删除一个确保有空间
        keep_keys: set[str] = set()
        max_size: int = self.maxsize
        keep_count: int = max(0, max_size - 1)
        for i, (key, _) in enumerate(key_access_count):
            if i < keep_count:
                keep_keys.add(key)

        # 删除不在保留列表中的key
        removed_keys: list[str] = []
        for key in list(self._store.keys()):
            if key not in keep_keys:
                removed_keys.append(key)

        for key in removed_keys:
            del self._store[key]

        return len(removed_keys)

    def _clean_lru_keys(self) -> int:
        """清理LRU多余的key

        Returns:
            清理的key数量
        """
        key_last_accessed: list[tuple[str, float]] = []

        for key, entry in self._store.items():
            meta_obj: object = entry.get(_META_KEY, {})
            if not isinstance(meta_obj, MetaInfo):
                # 脏数据，直接删除
                del self._store[key]
                continue
            meta: MetaInfo = meta_obj
            key_last_accessed.append((key, meta.last_accessed_at))

        # 按last_accessed_at降序排序（最近访问的在前面）
        key_last_accessed.sort(key=lambda x: x[1], reverse=True)

        # 保留前maxsize-1条，多删除一个确保有空间
        keep_keys: set[str] = set()
        max_size: int = self.maxsize
        keep_count: int = max(0, max_size - 1)
        for i, (key, _) in enumerate(key_last_accessed):
            if i < keep_count:
                keep_keys.add(key)

        # 删除不在保留列表中的key
        removed_keys: list[str] = []
        for key in list(self._store.keys()):
            if key not in keep_keys:
                removed_keys.append(key)

        for key in removed_keys:
            del self._store[key]

        return len(removed_keys)

    def _clean_fifo_keys(self) -> int:
        """清理FIFO多余的key（先进先出）

        Returns:
            清理的key数量
        """
        key_create_time: list[tuple[str, float]] = []

        for key, entry in self._store.items():
            meta_obj: object = entry.get(_META_KEY, {})
            if not isinstance(meta_obj, MetaInfo):
                # 脏数据，直接删除
                del self._store[key]
                continue
            meta: MetaInfo = meta_obj
            key_create_time.append((key, meta.create_at))

        # 按create_at升序排序（最先创建的在前面，应该被淘汰）
        key_create_time.sort(key=lambda x: x[1])

        # 删除最早的keys（淘汰最旧的），保留最新的maxsize-1个
        removed_keys: list[str] = []
        max_size: int = self.maxsize
        keep_count: int = max(0, max_size - 1)
        total_count: int = len(key_create_time)
        remove_count: int = total_count - keep_count
        for i, (key, _) in enumerate(key_create_time):
            if i < remove_count:
                # 前面的key是最旧的，需要被淘汰
                removed_keys.append(key)

        for key in removed_keys:
            del self._store[key]

        return len(removed_keys)

    def _clean_rr_keys(self) -> int:
        """清理RR多余的key（随机替换）

        Returns:
            清理的key数量
        """
        current_size: int = len(self._store)
        max_size: int = self.maxsize

        if current_size <= max_size:
            return 0

        # 随机选择要删除的keys，多删除一个确保有空间
        remove_count: int = max(0, current_size - max_size + 1)
        all_keys: list[str] = list(self._store.keys())

        # 随机抽取要删除的keys
        removed_keys: list[str] = random.sample(all_keys, remove_count)

        for key in removed_keys:
            del self._store[key]

        return remove_count

    def _clean_mru_keys(self) -> int:
        """清理MRU多余的key（最近使用）

        Returns:
            清理的key数量
        """
        key_last_accessed: list[tuple[str, float]] = []

        for key, entry in self._store.items():
            meta_obj: object = entry.get(_META_KEY, {})
            if not isinstance(meta_obj, MetaInfo):
                # 脏数据，直接删除
                del self._store[key]
                continue
            meta: MetaInfo = meta_obj
            key_last_accessed.append((key, meta.last_accessed_at))

        # 按last_accessed_at升序排序（最早访问的在前面）
        key_last_accessed.sort(key=lambda x: x[1])

        # 保留前maxsize-1条（保留最旧的maxsize-1条，删除最近使用的），多删除一个确保有空间
        keep_keys: set[str] = set()
        max_size: int = self.maxsize
        keep_count: int = max(0, max_size - 1)
        for i, (key, _) in enumerate(key_last_accessed):
            if i < keep_count:
                keep_keys.add(key)

        # 删除不在保留列表中的key
        removed_keys: list[str] = []
        for key in list(self._store.keys()):
            if key not in keep_keys:
                removed_keys.append(key)

        for key in removed_keys:
            del self._store[key]

        return len(removed_keys)

    def _clean_expired_keys(self) -> int:
        """清理过期的key

        Returns:
            清理的key数量
        """
        current_time: int = int(time.time())
        expired_keys: list[str] = []

        for key, entry in self._store.items():
            meta_obj: object = entry.get(_META_KEY, {})
            if not isinstance(meta_obj, MetaInfo):
                # 脏数据，直接删除
                expired_keys.append(key)
                continue
            meta: MetaInfo = meta_obj
            time_to_live: float = meta.time_to_live
            if time_to_live <= 0:
                continue

            create_at: float = meta.create_at
            if current_time - create_at > time_to_live:
                expired_keys.append(key)

        for key in expired_keys:
            del self._store[key]

        return len(expired_keys)

    @override
    def get[T](
        self,
        key: str,
        default: T | None = None,
        valueloader: ValueLoader[T] | None = None,
    ) -> ResultAny[T]:
        """获取缓存

        Args:
            key: 缓存键
            default: 默认值，当缓存不存在时返回
            valueloader: 缓存加载器，当缓存不存在时自动加载并缓存

        Returns:
            ResultAny[T]: 缓存结果
        """
        # get只清理过期的key
        _ = self._clean_expired_keys()

        # 检查key是否存在
        if key not in self._store:
            # 如果提供了valueloader，则加载并缓存
            if valueloader is not None:
                try:
                    value: T = valueloader(key)
                    _ = self.put(key, value)
                    return Result[T].success(value)
                except Exception as e:
                    return Result[T].client_error(e)
            # 返回默认值
            return Result[T].success(data=default)

        entry: dict[str, object] = self._store[key]
        meta_obj: object = entry.get(_META_KEY, {})

        if not isinstance(meta_obj, MetaInfo):
            # 脏数据，删除并返回默认值
            del self._store[key]
            if valueloader is not None:
                try:
                    value: T = valueloader(key)
                    _ = self.put(key, value)
                    return Result[T].success(value)
                except Exception as e:
                    return Result[T].client_error(e)
            return Result[T].success(data=default)

        meta: MetaInfo = meta_obj

        # 更新访问统计
        meta.last_accessed_at = int(time.time())
        meta.access_count += 1

        # 返回值
        value_obj: object = entry.get(_VALUE_KEY)
        value_obj = cast(T, value_obj)
        return Result[T].success(data=value_obj)

    @override
    def put(
        self,
        key: str,
        value: object,
        ttl: int = 0,
        only_absent: bool = False,
        extra_params: dict[str, object] | None = None,
    ) -> bool:
        """存放缓存

        Args:
            key: 缓存键
            value: 缓存值
            ttl: 存活时间（秒），0 表示永不过期
            only_absent: 是否仅当key不存在时才设置
            extra_params: 扩展参数（如请求参数等）

        Returns:
            bool: 是否成功
        """
        # 处理 extra_params 默认值
        if extra_params is None:
            extra_params = {}
        # 清理过期的key和超量的key
        _ = self._clean()

        # 检查key是否已存在
        if key in self._store:
            if only_absent:
                return False
            # 更新现有key
            entry: dict[str, object] = self._store[key]
            meta_obj: object = entry.get(_META_KEY, {})
            if isinstance(meta_obj, MetaInfo):
                meta: MetaInfo = meta_obj
                meta.last_update_at = time.time()
                if ttl > 0:
                    meta.time_to_live = ttl
                # 更新扩展信息
                if extra_params:
                    if meta.extra_params is None:
                        meta.extra_params = {}
                    meta.extra_params.update(extra_params)
            entry[_VALUE_KEY] = value
            return True

        # 创建新的meta
        meta: MetaInfo = MetaInfo()
        current_time: float = time.time()
        meta.create_at = current_time
        meta.last_update_at = current_time
        # 根据 eviction_policy 决定是否设置访问时间
        if self.eviction_policy == "lru":
            # LRU 策略：新 key 应该被视为"最近访问"的
            meta.last_accessed_at = current_time
        else:
            # 其他策略：put 操作不更新访问时间
            meta.last_accessed_at = 0.0
        meta.access_count = 0
        if ttl > 0:
            meta.time_to_live = ttl
        # 保存扩展信息
        if extra_params:
            meta.extra_params = extra_params

        # 存储新key
        self._store[key] = {_VALUE_KEY: value, _META_KEY: meta}

        return True

    @override
    def evict(self, key: str) -> bool:
        """从缓存中移除指定key

        Args:
            key: 缓存键

        Returns:
            bool: 是否成功移除
        """
        if key in self._store:
            del self._store[key]
            return True
        return False

    @override
    def refresh_ttl(self, key: str, ttl: int = 0) -> bool:
        """刷新缓存过期时间

        Args:
            key: 缓存键
            ttl: 新的过期时间（秒），0 表示永不过期

        Returns:
            bool: 是否成功刷新
        """
        if key not in self._store:
            return False

        entry: dict[str, object] = self._store[key]
        meta_obj: object = entry.get(_META_KEY, {})

        if not isinstance(meta_obj, MetaInfo):
            # 脏数据，删除
            del self._store[key]
            return False

        meta: MetaInfo = meta_obj
        meta.time_to_live = ttl

        return True

    @override
    def clear(self) -> bool:
        self.remove_store(self.name)
        # 移除字典后需要重新获取
        self._store = self.get_store(self.name)
        return True

    @override
    def size(self) -> int:
        """获取缓存大小

        Returns:
            缓存中的条目数量
        """
        return len(self._store)

    @override
    def get_meta(self, key: str) -> MetaInfo | None:
        """获取缓存元数据

        Args:
            key: 缓存键

        Returns:
            MetaInfo 对象，如果 key 不存在或元数据无效则返回 None
        """
        if key not in self._store:
            return None

        entry: dict[str, object] = self._store[key]
        meta_obj: object = entry.get(_META_KEY, {})

        if not isinstance(meta_obj, MetaInfo):
            # 脏数据，删除
            del self._store[key]
            return None

        return meta_obj
