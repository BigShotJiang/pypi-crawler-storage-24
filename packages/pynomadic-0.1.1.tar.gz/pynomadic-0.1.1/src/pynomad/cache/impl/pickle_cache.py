import pickle
import time
from pathlib import Path
from threading import Lock, Thread
from typing import Any, override
from weakref import WeakSet

from cryptography.fernet import Fernet

from pynomad.cache.core.cache_interface import Cache
from pynomad.cache.core.cache_registry import CacheRegistry
from pynomad.cache.core.meta import MetaInfo
from pynomad.cache.core.types import EvictionPolicy, ValueLoader
from pynomad.cache.properties import PickleCacheProperties
from pynomad.logsystem.manager import get_logger
from pynomad.result.result import Result, ResultAny
from pynomad.common.environment import environ
from pynomad.common.exceptions import CacheException

logger = get_logger()


class _BackgroundCleanupManager:
    """后台清理线程管理器（单例）

    所有 PickleCache 实例共享同一个后台清理线程，避免创建过多线程。
    """

    _instance: "_BackgroundCleanupManager | None" = None
    _lock: Lock = Lock()

    def __new__(cls) -> "_BackgroundCleanupManager":
        with cls._lock:
            if cls._instance is None:
                cls._instance = super().__new__(cls)
            return cls._instance

    def __init__(self) -> None:
        # 避免重复初始化
        if hasattr(self, "_initialized"):
            return

        self._initialized = True
        self._thread: Thread | None = None
        self._stop_event = False
        self._cleanup_interval = 300  # 默认 5 分钟
        self._registered_instances: WeakSet[PickleCache] = WeakSet()
        self._manager_lock = Lock()

    def register_instance(self, instance: "PickleCache") -> None:
        """注册一个需要清理的缓存实例

        Args:
            instance: PickleCache 实例
        """
        with self._manager_lock:
            self._registered_instances.add(instance)

            # 更新清理间隔（使用最小的间隔）
            cleanup_interval = getattr(instance, "_cleanup_interval", 300)
            if cleanup_interval < self._cleanup_interval:
                self._cleanup_interval = cleanup_interval

            # 启动线程
            self._start_thread_if_needed()

    def unregister_instance(self, instance: "PickleCache") -> None:
        """注销一个缓存实例

        Args:
            instance: PickleCache 实例
        """
        with self._manager_lock:
            self._registered_instances.discard(instance)

            # 如果没有实例了，停止线程
            if not self._registered_instances:
                self._stop_thread()

    def _start_thread_if_needed(self) -> None:
        """如果线程未运行，启动它"""
        if self._thread is not None and self._thread.is_alive():
            return

        self._stop_event = False
        self._thread = Thread(
            target=self._background_cleanup_loop,
            daemon=True,
            name="PickleCache-BackgroundCleanup",
        )
        self._thread.start()
        logger.info(
            f"共享后台清理线程已启动，间隔: {self._cleanup_interval} 秒"
        )

    def _stop_thread(self) -> None:
        """停止后台清理线程"""
        if self._thread is not None and self._thread.is_alive():
            self._stop_event = True
            self._thread.join(timeout=2)
            logger.info("共享后台清理线程已停止")
            self._thread = None

    def _background_cleanup_loop(self) -> None:
        """后台清理循环"""
        while not self._stop_event:
            try:
                self._cleanup_all_instances()
            except Exception as e:
                logger.error(f"后台清理失败: {e}")

            # 等待下一次清理
            time.sleep(self._cleanup_interval)

    def _cleanup_all_instances(self) -> None:
        """清理所有注册的缓存实例"""
        with self._manager_lock:
            instances = list(self._registered_instances)

        for instance in instances:
            try:
                clean_method = getattr(instance, "_clean_expired_keys", None)
                if clean_method is not None:
                    _ = clean_method()
            except Exception as e:
                name = getattr(instance, "_name", "unknown")
                logger.error(f"清理缓存实例 {name} 失败: {e}")


@CacheRegistry.register("pickle")
class PickleCache(Cache):
    """基于文件的 Pickle 缓存实现

    使用文件系统存储缓存数据，支持持久化和离线访问。
    缓存数据以 pickle 格式存储在文件中，元数据存储在单独的 .meta 文件中。

    Attributes:
        name: 缓存实例名称
        maxsize: 缓存最大容量
        eviction_policy: 缓存淘汰策略
        cache_dir: 缓存文件存储目录
        enable_encryption: 是否启用加密
        salt: 加密盐值
        enable_background_cleanup: 是否启用后台清理过期缓存
        cleanup_interval: 后台清理间隔（秒）
    """

    def __init__(
        self,
        name: str = "",
        maxsize: int | None = None,
        eviction_policy: EvictionPolicy | None = None,
        cache_dir: str | Path = "",
        enable_encryption: bool | None = None,
        salt: str = "",
        enable_background_cleanup: bool | None = None,
        cleanup_interval: int = 0,
    ) -> None:
        """初始化 Pickle 缓存

        Args:
            name: 缓存实例名称
            maxsize: 缓存最大容量（None 或 0 表示无限制）
            eviction_policy: 缓存淘汰策略
            cache_dir: 缓存文件存储目录
            enable_encryption: 是否启用加密（使用 get_machine_key）
            salt: 加密盐值，用于生成机器派生密钥
            enable_background_cleanup: 是否启用后台清理过期缓存
            cleanup_interval: 后台清理间隔（秒）
        """
        props = PickleCacheProperties()
        name = name if name else props.name
        maxsize = maxsize if maxsize is not None and maxsize != 0 else props.maxsize
        eviction_policy = eviction_policy if eviction_policy else props.eviction_policy
        cache_dir = cache_dir if cache_dir else props.cache_dir
        enable_encryption = (
            enable_encryption if enable_encryption is not None else props.enable_encryption
        )
        salt = salt if salt else props.salt
        enable_background_cleanup = (
            enable_background_cleanup
            if enable_background_cleanup is not None
            else props.enable_background_cleanup
        )
        cleanup_interval = (
            cleanup_interval if cleanup_interval else props.cleanup_interval
        )
        super().__init__(name, maxsize, eviction_policy)
        self._cache_dir = Path(cache_dir)
        self._enable_encryption = enable_encryption
        self._salt = salt
        self._enable_background_cleanup = enable_background_cleanup
        self._cleanup_interval = cleanup_interval
        self._lock = Lock()

        # 加密配置
        self._fernet: Fernet | None = None
        if enable_encryption:
            key_bytes = environ.get_machine_key(salt=salt)
            self._fernet = Fernet(key_bytes)

        # 创建缓存目录
        self._cache_dir.mkdir(parents=True, exist_ok=True)

        # 注册到共享的后台清理管理器
        if self._enable_background_cleanup:
            _BackgroundCleanupManager().register_instance(self)

    def _get_cache_file_path(self, key: str) -> Path:
        """获取缓存文件路径

        Args:
            key: 缓存键

        Returns:
            缓存文件路径
        """
        # 对 key 进行 hash，避免文件名过长或包含非法字符
        import hashlib

        key_hash = hashlib.md5(key.encode()).hexdigest()
        return self._cache_dir / f"{key_hash}.pickle"

    def _get_meta_file_path(self, key: str) -> Path:
        """获取元数据文件路径

        Args:
            key: 缓存键

        Returns:
            元数据文件路径
        """
        import hashlib

        key_hash = hashlib.md5(key.encode()).hexdigest()
        return self._cache_dir / f"{key_hash}.meta.pickle"

    def _encrypt(self, data: bytes) -> bytes:
        """加密数据

        Args:
            data: 原始数据

        Returns:
            加密后的数据
        """
        if self._enable_encryption and self._fernet is not None:
            return self._fernet.encrypt(data)
        return data

    def _decrypt(self, encrypted_data: bytes) -> bytes:
        """解密数据

        Args:
            encrypted_data: 加密的数据

        Returns:
            解密后的数据
        """
        if self._enable_encryption and self._fernet is not None:
            return self._fernet.decrypt(encrypted_data)
        return encrypted_data

    def _load_cache_from_file(self, cache_file: Path) -> dict[str, Any]:
        """从缓存文件加载数据

        Args:
            cache_file: 缓存文件路径

        Returns:
            缓存数据字典，包含 data 和 meta
        """
        if not cache_file.exists():
            logger.error(f"缓存文件不存在: {cache_file}")
            raise CacheException(f"缓存文件不存在: {cache_file}")

        try:
            with cache_file.open("rb") as f:
                encrypted_data = f.read()

            decrypted_data = self._decrypt(encrypted_data)
            result: dict[str, Any] = pickle.loads(decrypted_data)
            return result
        except Exception as e:
            logger.error(f"加载缓存文件失败: {e}")
            raise CacheException(f"加载缓存文件失败: {e}") from e

    def _save_cache_to_file(
        self, cache_file: Path, data: dict[str, Any]
    ) -> None:
        """保存缓存数据到文件

        Args:
            cache_file: 缓存文件路径
            data: 缓存数据字典
        """
        try:
            serialized_data = pickle.dumps(data)
            encrypted_data = self._encrypt(serialized_data)

            # 原子写入：先写入临时文件，然后重命名
            temp_file = cache_file.with_suffix(".tmp")
            with temp_file.open("wb") as f:
                _ = f.write(encrypted_data)

            # Windows 下需要先删除目标文件
            if cache_file.exists():
                _ = cache_file.unlink()

            _ = temp_file.rename(cache_file)
        except Exception as e:
            logger.error(f"保存缓存文件失败: {e}")
            raise CacheException(f"保存缓存文件失败: {e}") from e

    def _load_meta_from_file(self, meta_file: Path) -> MetaInfo:
        """从元数据文件加载 MetaInfo

        Args:
            meta_file: 元数据文件路径

        Returns:
            MetaInfo 对象
        """
        if not meta_file.exists():
            logger.error(f"元数据文件不存在: {meta_file}")
            raise CacheException(f"元数据文件不存在: {meta_file}")

        try:
            with meta_file.open("rb") as f:
                encrypted_data = f.read()

            decrypted_data = self._decrypt(encrypted_data)
            meta_info: MetaInfo = pickle.loads(decrypted_data)
            return meta_info
        except Exception as e:
            logger.error(f"加载元数据文件失败: {e}")
            raise CacheException(f"加载元数据文件失败: {e}") from e

    def _save_meta_to_file(self, meta_file: Path, meta: MetaInfo) -> None:
        """保存 MetaInfo 到文件

        Args:
            meta_file: 元数据文件路径
            meta: MetaInfo 对象
        """
        try:
            serialized_data = pickle.dumps(meta)
            encrypted_data = self._encrypt(serialized_data)

            temp_file = meta_file.with_suffix(".tmp")
            with temp_file.open("wb") as f:
                _ = f.write(encrypted_data)

            if meta_file.exists():
                _ = meta_file.unlink()

            _ = temp_file.rename(meta_file)
        except Exception as e:
            logger.error(f"保存元数据文件失败: {e}")
            raise CacheException(f"保存元数据文件失败: {e}") from e

    def _get_file_timestamp(self, file_path: Path) -> float | None:
        """获取文件时间戳（优先级：创建时间 > 修改时间 > 访问时间）

        使用"邪修方式"获取文件时间：
        - 优先使用文件创建时间（st_ctime）
        - 其次使用文件修改时间（st_mtime）
        - 最后使用文件访问时间（st_atime）

        Args:
            file_path: 缓存文件路径

        Returns:
            文件时间戳，如果无法获取则返回 None
        """
        try:
            stat_info = file_path.stat()

            # 优先级：创建时间 > 修改时间 > 访问时间
            # 注意：st_ctime 在 Windows 上是创建时间，Linux 上是状态改变时间
            timestamp: float = 0

            # 尝试获取创建时间（st_ctime）
            if hasattr(stat_info, "st_birthtime"):
                # FreeBSD/macOS 特有
                timestamp = stat_info.st_birthtime
            else:
                # 其他系统尝试使用 st_ctime
                # 注意：在 Python 中直接使用 st_ctime 可能会有弃用警告
                timestamp = getattr(stat_info, "st_ctime", 0)

            # 如果创建时间不可用，使用修改时间
            if timestamp == 0:
                timestamp = stat_info.st_mtime

            # 如果修改时间也不可用（极端情况），使用访问时间
            if timestamp == 0:
                timestamp = stat_info.st_atime

            return timestamp if timestamp > 0 else None

        except Exception:
            return None

    def _is_expired(
        self, meta: MetaInfo, cache_file: Path | None = None
    ) -> bool:
        """检查缓存是否过期

        策略：文件时间戳优先，Meta 兜底
        1. 优先使用文件的创建/修改/访问时间来计算过期
        2. 如果无法获取文件时间，使用 MetaInfo 中的 create_at
        3. 如果 MetaInfo 中也没有有效时间，视为不过期

        Args:
            meta: 缓存元数据
            cache_file: 缓存文件路径（可选，用于获取文件时间戳）

        Returns:
            是否过期
        """
        if meta.time_to_live <= 0:
            return False

        # 优先使用文件时间戳（邪修方式）
        if cache_file and cache_file.exists():
            file_timestamp = self._get_file_timestamp(cache_file)
            if file_timestamp is not None:
                current_time: float = time.time()
                return current_time - file_timestamp > meta.time_to_live

        # 兜底：使用 MetaInfo 中的创建时间
        if meta.create_at and meta.create_at > 0:
            current_time: float = time.time()
            return current_time - meta.create_at > meta.time_to_live

        # 无法获取有效时间，视为不过期
        return False

    def _update_meta_from_file_time(
        self, key: str, meta: MetaInfo, cache_file: Path
    ) -> MetaInfo:
        """从文件时间戳更新 MetaInfo

        当获取 meta 时，如果文件时间戳可用，以文件属性为准更新 meta 中的时间字段。
        这确保了时间的一致性和准确性。

        Args:
            key: 缓存键
            meta: 当前的 MetaInfo 对象
            cache_file: 缓存文件路径

        Returns:
            更新后的 MetaInfo
        """
        if not cache_file.exists():
            return meta

        file_timestamp = self._get_file_timestamp(cache_file)
        if file_timestamp is None:
            return meta  # 文件时间不可用，保持原样

        # 以文件时间戳为准更新 MetaInfo
        # 注意：只有在首次创建或时间明显不一致时才更新

        # 如果 meta 中没有有效的创建时间，或者文件是新建的，则更新时间
        if meta.create_at <= 0:
            meta.create_at = file_timestamp

        # 如果文件的修改时间比 meta 中的更新时间更新，说明文件被外部修改过
        try:
            mtime = cache_file.stat().st_mtime
            if mtime > meta.last_update_at:
                meta.last_update_at = mtime
        except Exception:
            pass

        # 如果 meta 中的时间与文件时间差异过大，以文件时间为准
        # 这种情况可能是文件被复制、恢复等操作导致的
        if abs(meta.create_at - file_timestamp) > 1:  # 1秒容差
            # 记录日志警告
            logger.debug(f"Meta 时间与文件时间不一致，以文件时间为准: {key}")

        return meta

    def _check_capacity_and_evict(self) -> None:
        """检查容量并执行淘汰策略

        逻辑顺序：
        1. 先清理 TTL 过期的缓存文件
        2. 如果仍然超过容量，删除最早创建的缓存文件
        """
        if self.maxsize <= 0:
            return  # 无限制

        # 第一步：清理过期的缓存文件
        _ = self._clean_expired_keys()

        # 第二步：检查容量是否仍然超限
        current_size = self.size()
        if current_size <= self.maxsize:
            return

        # 如果超过容量，执行淘汰
        logger.warn(
            f"缓存容量不足，当前: {current_size}, 最大: {self.maxsize}, "
            + "需要执行淘汰策略"
        )

        # PickleCache 简单实现：删除最旧的缓存
        # TODO: 实现更复杂的淘汰策略（LRU、LFU 等）
        cache_files: list[Path] = list(self._cache_dir.glob("*.pickle"))
        cache_files.sort(key=lambda f: f.stat().st_mtime)

        # 删除最旧的缓存，直到容量满足要求
        to_delete: list[Path] = []
        while len(cache_files) - len(to_delete) > self.maxsize and cache_files:
            oldest_file = cache_files.pop(0)
            if not oldest_file.name.endswith(".meta.pickle"):
                to_delete.append(oldest_file)

        for cache_file in to_delete:
            try:
                meta_file = self._get_meta_file_path_from_file(cache_file)
                if meta_file.exists():
                    meta_file.unlink()
                cache_file.unlink()
                logger.info(f"淘汰缓存文件: {cache_file.name}")
            except Exception as e:
                logger.error(f"淘汰缓存文件失败: {cache_file}, 错误: {e}")

    def _get_meta_file_path_from_file(self, cache_file: Path) -> Path:
        """从缓存文件路径推导元数据文件路径

        Args:
            cache_file: 缓存文件路径

        Returns:
            元数据文件路径
        """
        # cache_file: xxx.pickle -> meta_file: xxx.meta.pickle
        base_name = cache_file.stem
        return self._cache_dir / f"{base_name}.meta.pickle"

    def _clean_expired_keys(self) -> int:
        """清理 TTL 过期的 key

        使用文件时间戳优先策略检查过期。

        Returns:
            清理的键数量
        """
        expired_keys: list[str] = []

        for cache_file in self._cache_dir.glob("*.pickle"):
            # 跳过 .meta.pickle 文件
            if cache_file.name.endswith(".meta.pickle"):
                continue

            try:
                data = self._load_cache_from_file(cache_file)
                meta: MetaInfo = data["meta"]

                if meta.time_to_live <= 0:
                    continue

                # 使用文件时间戳优先策略检查过期
                if self._is_expired(meta, cache_file):
                    # 提取原始键（通过元数据中的 extra_params 或其他方式）
                    # 这里简化处理，直接删除文件
                    _ = cache_file.unlink()
                    meta_file = self._get_meta_file_path_from_file(cache_file)
                    if meta_file.exists():
                        _ = meta_file.unlink()
                    expired_keys.append(cache_file.name)

            except Exception as e:
                logger.error(f"检查缓存过期失败: {e}")

        if expired_keys:
            logger.info(f"清理了 {len(expired_keys)} 个过期的缓存")

        return len(expired_keys)

    @override
    def get[T](
        self,
        key: str,
        default: T | None = None,
        valueloader: ValueLoader[T] | None = None,
    ) -> ResultAny[T]:
        """获取缓存

        Args:
            key: 缓存键
            default: 默认值
            valueloader: 值加载器（如果缓存不存在且提供此函数，则调用加载）

        Returns:
            缓存值结果
        """
        # 第一阶段：检查缓存是否存在（持有锁）
        cache_file = self._get_cache_file_path(key)
        meta_file = self._get_meta_file_path(key)
        cache_exists: bool = False
        load_error: Exception | None = None

        with self._lock:
            # 检查缓存文件是否存在
            if cache_file.exists():
                cache_exists = True
                try:
                    data = self._load_cache_from_file(cache_file)
                    cache_value = data["data"]

                    # 从 meta 文件加载最新的 meta（包含最新的访问计数）
                    if meta_file.exists():
                        meta: MetaInfo = self._load_meta_from_file(meta_file)
                    else:
                        # 如果 meta 文件不存在，使用缓存文件中的 meta
                        meta = data["meta"]

                    # 检查是否过期
                    if self._is_expired(meta, cache_file):
                        logger.debug(f"缓存已过期: {key}")
                        # 删除过期缓存
                        _ = cache_file.unlink()
                        if meta_file.exists():
                            _ = meta_file.unlink()
                        cache_exists = False
                    else:
                        # 更新访问时间（使用 MetaInfo 中的 last_accessed_at）
                        meta.last_accessed_at = time.time()
                        meta.access_count += 1
                        _ = self._save_meta_to_file(meta_file, meta)

                        logger.trace(
                            f"缓存命中: {key}, 访问计数: {meta.access_count}"
                        )
                        return Result.success(cache_value)  # type: ignore[return-value]
                except Exception as e:
                    logger.error(f"获取缓存失败: {key}, 错误: {e}")
                    load_error = e

        # 第二阶段：处理错误（不持有锁）
        if load_error is not None:
            return Result.server_error(CacheException(f"获取缓存失败: {load_error}"))  # type: ignore[return-value]

        # 第三阶段：缓存不存在或过期，调用 valueloader 或返回默认值（不持有锁）
        if not cache_exists:
            if valueloader is not None:
                value = valueloader(key)
                _ = self.put(key, value)
                return Result.success(value)  # type: ignore[return-value]
            if default is not None:
                return Result.success(default)  # type: ignore[return-value]
            return Result.success(None)  # type: ignore[return-value]

        # 不应该到达这里
        return Result.success(None)  # type: ignore[return-value]

    @override
    def put(
        self,
        key: str,
        value: object,
        ttl: int = 0,
        only_absent: bool = False,
        extra_params: dict[str, object] | None = None,
    ) -> bool:
        """存放缓存

        Args:
            key: 缓存键
            value: 缓存值
            ttl: 缓存存活时间（秒），0 表示永不过期
            only_absent: 仅在键不存在时设置
            extra_params: 扩展参数

        Returns:
            是否成功
        """
        with self._lock:
            cache_file = self._get_cache_file_path(key)
            meta_file = self._get_meta_file_path(key)

            # 检查是否已存在
            if only_absent and cache_file.exists():
                logger.debug(f"缓存已存在，跳过设置: {key}")
                return False

            try:
                # 检查并执行淘汰
                self._check_capacity_and_evict()

                # 创建元数据
                current_time: float = time.time()
                meta = MetaInfo()
                meta.create_at = current_time
                meta.last_update_at = current_time
                meta.last_accessed_at = current_time
                meta.access_count = 0
                meta.time_to_live = ttl
                meta.extra_params = extra_params or {}

                # 保存缓存数据
                data: dict[str, Any] = {
                    "data": value,
                    "meta": meta,
                }

                _ = self._save_cache_to_file(cache_file, data)
                _ = self._save_meta_to_file(meta_file, meta)

                logger.debug(f"缓存已保存: {key}, TTL: {ttl}")
                return True

            except Exception as e:
                logger.error(f"保存缓存失败: {key}, 错误: {e}")
                return False

    @override
    def evict(self, key: str) -> bool:
        """从缓存中移除指定 key

        Args:
            key: 缓存键

        Returns:
            是否成功
        """
        with self._lock:
            cache_file = self._get_cache_file_path(key)
            meta_file = self._get_meta_file_path(key)

            try:
                deleted: bool = False

                if cache_file.exists():
                    cache_file.unlink()
                    deleted = True
                    logger.debug(f"缓存文件已删除: {key}")

                if meta_file.exists():
                    meta_file.unlink()
                    deleted = True
                    logger.debug(f"元数据文件已删除: {key}")

                if deleted:
                    return True

                logger.debug(f"缓存不存在: {key}")
                return False

            except Exception as e:
                logger.error(f"删除缓存失败: {key}, 错误: {e}")
                return False

    @override
    def refresh_ttl(self, key: str, ttl: int = 0) -> bool:
        """刷新缓存过期时间

        Args:
            key: 缓存键
            ttl: 新的过期时间（秒），0 表示永不过期

        Returns:
            是否成功
        """
        with self._lock:
            cache_file = self._get_cache_file_path(key)
            meta_file = self._get_meta_file_path(key)

            # 检查缓存文件是否存在
            if not cache_file.exists():
                logger.debug(f"缓存不存在: {key}")
                return False

            try:
                data = self._load_cache_from_file(cache_file)
                meta: MetaInfo = data["meta"]

                # 更新 TTL
                meta.time_to_live = ttl

                # 更新元数据文件
                _ = self._save_meta_to_file(meta_file, meta)

                logger.debug(f"缓存 TTL 已刷新: {key}, 新 TTL: {ttl}")
                return True

            except Exception as e:
                logger.error(f"刷新 TTL 失败: {key}, 错误: {e}")
                return False

    @override
    def clear(self) -> bool:
        """清除缓存

        Returns:
            是否成功
        """
        with self._lock:
            try:
                deleted_count: int = 0

                # 删除所有缓存文件
                for cache_file in self._cache_dir.glob("*.pickle"):
                    if cache_file.name.endswith(".meta.pickle"):
                        continue

                    try:
                        _ = cache_file.unlink()
                        deleted_count += 1
                    except Exception as e:
                        logger.error(
                            f"删除缓存文件失败: {cache_file}, 错误: {e}"
                        )

                # 删除所有元数据文件
                for meta_file in self._cache_dir.glob("*.meta.pickle"):
                    try:
                        _ = meta_file.unlink()
                    except Exception as e:
                        logger.error(
                            f"删除元数据文件失败: {meta_file}, 错误: {e}"
                        )

                logger.info(
                    f"已清除所有缓存，共删除 {deleted_count} 个缓存文件"
                )
                return True

            except Exception as e:
                logger.error(f"清除缓存失败: {e}")
                return False

    @override
    def size(self) -> int:
        """获取缓存大小

        Returns:
            缓存条目数量
        """
        count: int = 0
        for cache_file in self._cache_dir.glob("*.pickle"):
            if not cache_file.name.endswith(".meta.pickle"):
                count += 1
        return count

    @override
    def get_meta(self, key: str) -> MetaInfo | None:
        """获取缓存元数据

        Args:
            key: 缓存键

        Returns:
            MetaInfo 对象，如果不存在则返回 None
        """
        with self._lock:
            meta_file = self._get_meta_file_path(key)
            cache_file = self._get_cache_file_path(key)

            if not meta_file.exists():
                return None

            try:
                meta: MetaInfo = self._load_meta_from_file(meta_file)
                # 以文件时间戳为准更新 meta 中的时间字段
                meta = self._update_meta_from_file_time(key, meta, cache_file)
                return meta
            except Exception as e:
                logger.error(f"获取元数据失败: {key}, 错误: {e}")
                return None

    def __del__(self) -> None:
        """析构函数，清理资源"""
        # 从共享的后台清理管理器注销
        if self._enable_background_cleanup:
            _BackgroundCleanupManager().unregister_instance(self)
