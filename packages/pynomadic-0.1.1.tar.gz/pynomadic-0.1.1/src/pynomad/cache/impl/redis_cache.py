# pyright:reportUnknownMemberType=false
# pyright:reportOperatorIssue=false
# pyright:reportArgumentType=false
# pyright:reportUnknownVariableType=false
# pyright:reportGeneralTypeIssues=false
# pyright:reportUnknownArgumentType=false
# pyright:reportReturnType=false
import pickle
import random
import time
from typing import cast, override

from cryptography.fernet import Fernet

import redis
from redis import Redis
from redis.client import Pipeline
from redis.connection import ConnectionPool

from pynomad.cache.core.cache_interface import Cache
from pynomad.cache.core.cache_registry import CacheRegistry
from pynomad.cache.core.meta import MetaInfo
from pynomad.cache.core.types import EvictionPolicy, ValueLoader
from pynomad.cache.properties import RedisCacheProperties
from pynomad.result.result import Result, ResultAny
from pynomad.logsystem.manager import get_logger
from pynomad.common.environment import Environment

logger = get_logger()


@CacheRegistry.register("redis")
class RedisCache(Cache):
    """Redis 缓存实现

    实现分布式缓存功能，支持多种淘汰策略和元数据管理。
    使用 Hash 结构存储，支持 pickle 序列化和机器密钥加密。
    """

    # Hash 字段名
    _VALUE_FIELD: str = "value"
    _META_FIELD: str = "meta"

    # 淘汰策略有序集合后缀
    _KEYS_LRU_SUFFIX: str = "keys:lru"
    _KEYS_LFU_SUFFIX: str = "keys:lfu"
    _KEYS_FIFO_SUFFIX: str = "keys:fifo"
    _KEYS_MRU_SUFFIX: str = "keys:mru"

    def __init__(
        self,
        name: str = "",
        maxsize: int | None = None,
        eviction_policy: EvictionPolicy | None = None,
        redis_client: Redis | None = None,
        connection_pool: ConnectionPool | None = None,
        host: str = "",
        port: int = 0,
        db: int = 0,
        username: str = "",
        password: str | None = None,
        enable_encryption: bool | None = None,
        salt: str = "",
    ) -> None:
        """初始化 Redis 缓存

        Args:
            name: 缓存名称，用作 Redis key 前缀
            maxsize: 缓存最大容量，None 或 0 表示不限制
            eviction_policy: 缓存淘汰策略
            redis_client: 自定义 Redis 客户端（优先使用）
            connection_pool: 自定义连接池
            host: Redis 主机地址
            port: Redis 端口
            db: Redis 数据库编号
            username: Redis 用户名
            password: Redis 密码
            enable_encryption: 是否启用加密（使用 get_machine_key）
            salt: 加密盐值，用于生成机器派生密钥
        """
        props = RedisCacheProperties()
        name = name if name else props.name
        maxsize = maxsize if maxsize is not None and maxsize != 0 else props.maxsize
        eviction_policy = eviction_policy if eviction_policy else props.eviction_policy
        host = host if host else props.host
        port = port if port else props.port
        db = db if db else props.db
        username = username if username else props.username or ""
        password = password if password is not None else props.password
        enable_encryption = (
            enable_encryption if enable_encryption is not None else props.enable_encryption
        )
        salt = salt if salt else props.salt
        super().__init__(
            name=name,
            maxsize=maxsize,
            eviction_policy=eviction_policy,
        )

        # 优先使用提供的 Redis 客户端
        if redis_client is not None:
            self._redis: Redis = redis_client
        else:
            # 创建连接池或客户端
            if connection_pool is not None:
                self._redis = Redis(connection_pool=connection_pool)
            else:
                # 构建 Redis 连接参数，处理四种认证情况
                # (仅用户名, 仅密码, 用户名+密码, 无用户名无密码)
                redis_kwargs = {
                    "host": host,
                    "port": port,
                    "db": db,
                    "decode_responses": False,  # 使用 bytes 模式以便 pickle 序列化
                }
                # 根据用户名和密码情况添加认证参数
                if username:
                    redis_kwargs["username"] = username
                if password:
                    redis_kwargs["password"] = password

                self._redis = Redis(**redis_kwargs)

        # 缓存键前缀
        self._key_prefix: str = f"{self.name}:"

        # 加密配置
        self._enable_encryption: bool = enable_encryption
        self._salt: str = salt
        self._fernet: Fernet | None = None
        if enable_encryption:
            env = Environment()
            key_bytes = env.get_machine_key(salt=salt)
            self._fernet = Fernet(key_bytes)

    def _make_redis_key(self, cache_key: str | bytes) -> str:
        """生成 Redis Hash 键

        格式: {cache_name}:{cache_key}

        Args:
            cache_key: 缓存键（支持 str 或 bytes）

        Returns:
            完整的 Redis Hash 键
        """
        if isinstance(cache_key, bytes):
            cache_key = cache_key.decode("utf-8")
        return f"{self._key_prefix}{cache_key}"

    def _make_eviction_key(self, policy: EvictionPolicy) -> str:
        """生成淘汰策略的有序集合 key

        Args:
            policy: 淘汰策略

        Returns:
            有序集合键
        """
        suffix_map: dict[str, str] = {
            "lru": self._KEYS_LRU_SUFFIX,
            "lfu": self._KEYS_LFU_SUFFIX,
            "fifo": self._KEYS_FIFO_SUFFIX,
            "mru": self._KEYS_MRU_SUFFIX,
        }
        suffix: str = suffix_map.get(policy, "")
        return f"{self._key_prefix}{suffix}"

    def _serialize_value(self, value: object) -> bytes:
        """序列化缓存值

        使用 pickle 序列化，如果启用加密则进行加密。

        Args:
            value: 要序列化的值

        Returns:
            序列化后的字节数据
        """
        try:
            data: bytes = pickle.dumps(value)
            if self._enable_encryption and self._fernet is not None:
                data = self._fernet.encrypt(data)
            return data
        except Exception as e:
            logger.error(f"序列化缓存值失败: {e}")
            raise

    def _deserialize_value(self, data: bytes) -> object:
        """反序列化缓存值

        先解密（如果启用），再 pickle 反序列化。

        Args:
            data: 序列化的字节数据

        Returns:
            反序列化后的对象
        """
        try:
            if self._enable_encryption and self._fernet is not None:
                data = self._fernet.decrypt(data)
            return pickle.loads(data)
        except Exception as e:
            logger.error(f"反序列化缓存值失败: {e}")
            raise

    def _serialize_meta(self, meta: MetaInfo) -> bytes:
        """序列化 MetaInfo

        使用 pickle 序列化，如果启用加密则进行加密。

        Args:
            meta: MetaInfo 对象

        Returns:
            序列化后的字节数据
        """
        try:
            data: bytes = pickle.dumps(meta)
            if self._enable_encryption and self._fernet is not None:
                data = self._fernet.encrypt(data)
            return data
        except Exception as e:
            logger.error(f"序列化元数据失败: {e}")
            raise

    def _deserialize_meta(self, data: bytes) -> MetaInfo:
        """反序列化 MetaInfo

        先解密（如果启用），再 pickle 反序列化。

        Args:
            data: 序列化的字节数据

        Returns:
            MetaInfo 对象
        """
        try:
            if self._enable_encryption and self._fernet is not None:
                data = self._fernet.decrypt(data)
            return pickle.loads(data)
        except Exception as e:
            logger.error(f"反序列化元数据失败: {e}")
            raise

    @override
    def get[T](
        self,
        key: str,
        default: T | None = None,
        valueloader: ValueLoader[T] | None = None,
    ) -> ResultAny[T]:
        """获取缓存"""
        try:
            # 自动清理超量缓存（过期数据由 Redis 内置 TTL 自动处理）,get不需要处理
           # _ = self._clean_if_needed()

            # 获取缓存值和元数据
            redis_key = self._make_redis_key(key)

            pipe: Pipeline = self._redis.pipeline()
            _ = pipe.hget(redis_key, self._VALUE_FIELD)
            _ = pipe.hget(redis_key, self._META_FIELD)
            _ = pipe.hexists(redis_key, self._VALUE_FIELD)
            value_result, meta_result, key_exists = pipe.execute()

            # 缓存不存在
            if not key_exists or value_result is None:
                if valueloader is not None:
                    try:
                        value: T = valueloader(key)
                        _ = self.put(key, value)
                        return Result[T].success(value)
                    except Exception as e:
                        return Result[T].client_error(e)
                return Result[T].success(data=default)

            # 元数据不存在（脏数据），删除整个 Hash 并返回默认值
            if meta_result is None:
                _ = self._redis.delete(redis_key)
                if valueloader is not None:
                    try:
                        value = valueloader(key)
                        _ = self.put(key, value)
                        return Result[T].success(value)
                    except Exception as e:
                        return Result[T].client_error(e)
                return Result[T].success(data=default)

            # 反序列化
            try:
                meta = self._deserialize_meta(meta_result)
                value_obj = self._deserialize_value(value_result)
            except Exception as e:
                logger.error(f"反序列化缓存数据失败: {e}")
                _ = self._redis.delete(redis_key)
                return Result[T].success(data=default)

            # 更新访问统计
            current_time = int(time.time())
            meta.last_accessed_at = current_time
            meta.access_count += 1

            # 更新 Redis 中的元数据
            pipe = self._redis.pipeline()
            _ = pipe.hset(
                redis_key, self._META_FIELD, self._serialize_meta(meta)
            )
            # 更新淘汰策略的有序集合
            if self.eviction_policy == "lru":
                _ = pipe.zadd(
                    self._make_eviction_key("lru"), {key: current_time}
                )
            elif self.eviction_policy == "lfu":
                _ = pipe.zadd(
                    self._make_eviction_key("lfu"), {key: meta.access_count}
                )
            elif self.eviction_policy == "mru":
                _ = pipe.zadd(
                    self._make_eviction_key("mru"), {key: current_time}
                )
            _ = pipe.execute()

            return Result[T].success(data=cast(T, value_obj))

        except redis.ConnectionError as e:
            logger.error(f"Redis 连接失败: {e}")
            # 连接失败时尝试使用 valueloader 或返回默认值
            if valueloader is not None:
                try:
                    value = valueloader(key)
                    return Result[T].success(value)
                except Exception:
                    pass
            return Result[T].success(data=default)
        except Exception as e:
            logger.error(f"获取缓存失败: {e}")
            return Result[T].client_error(e)

    @override
    def put(
        self,
        key: str,
        value: object,
        ttl: int = 0,
        only_absent: bool = False,
        extra_params: dict[str, object] | None = None,
    ) -> bool:
        """存放缓存"""
        try:
            # 自动清理超量缓存（过期数据由 Redis 内置 TTL 自动处理）
            _ = self._clean_if_needed()

            # 处理 extra_params 默认值
            if extra_params is None:
                extra_params = {}

            redis_key = self._make_redis_key(key)

            # 检查 key 是否已存在
            exists = self._redis.hexists(redis_key, self._VALUE_FIELD)
            logger.debug(f"put: key={key}, exists={exists}")
            if exists and only_absent:
                return False

            current_time = time.time()

            # 序列化数据
            value_bytes = self._serialize_value(value)

            if exists:
                # 更新现有 key
                # 获取现有元数据
                meta_result = self._redis.hget(redis_key, self._META_FIELD)
                if meta_result is not None:
                    try:
                        assert isinstance(meta_result, bytes)
                        meta = self._deserialize_meta(meta_result)
                        meta.last_update_at = current_time
                        if ttl > 0:
                            meta.time_to_live = ttl
                        # 更新扩展信息
                        if extra_params:
                            if meta.extra_params is None:
                                meta.extra_params = {}
                            meta.extra_params.update(extra_params)
                    except Exception as e:
                        logger.error(f"反序列化元数据失败: {e}")
                        meta = MetaInfo()
                else:
                    meta = MetaInfo()

                # 更新 Redis
                pipe = self._redis.pipeline()
                _ = pipe.hset(redis_key, self._VALUE_FIELD, value_bytes)
                _ = pipe.hset(
                    redis_key, self._META_FIELD, self._serialize_meta(meta)
                )
                if ttl > 0:
                    # 更新 Redis 内置 TTL
                    _ = pipe.expire(redis_key, ttl)
                elif ttl == 0:
                    # ttl=0 表示永不过期，清除之前的过期时间
                    _ = pipe.persist(redis_key)
                _ = pipe.execute()

                # 更新淘汰策略的有序集合
                self._update_eviction_zset(key, meta)

            else:
                # 创建新 key
                # 创建元数据
                meta = MetaInfo()
                meta.create_at = current_time
                meta.last_update_at = current_time
                # 根据 eviction_policy 决定是否设置访问时间
                if self.eviction_policy == "lru":
                    # LRU 策略：新 key 应该被视为"最近访问"的
                    meta.last_accessed_at = current_time
                else:
                    # 其他策略：put 操作不更新访问时间
                    meta.last_accessed_at = 0.0
                meta.access_count = 0
                if ttl > 0:
                    meta.time_to_live = ttl
                if extra_params:
                    meta.extra_params = extra_params

                # 先检查容量限制并清理（预留空间）
                if self.maxsize > 0:
                    _ = self._clean_if_needed()

                # 添加到 FIFO zset，用于容量检查
                _ = self._redis.zadd(
                    self._make_eviction_key("fifo"), {key: meta.create_at}
                )

                # 添加到策略对应的 zset（用于淘汰决策）
                if self.eviction_policy == "lru":
                    _ = self._redis.zadd(
                        self._make_eviction_key("lru"), {key: meta.last_accessed_at}
                    )
                elif self.eviction_policy == "lfu":
                    _ = self._redis.zadd(
                        self._make_eviction_key("lfu"), {key: meta.access_count}
                    )
                elif self.eviction_policy == "mru":
                    _ = self._redis.zadd(
                        self._make_eviction_key("mru"), {key: meta.last_accessed_at}
                    )

                # 存储到 Redis Hash
                pipe = self._redis.pipeline()
                _ = pipe.hset(redis_key, self._VALUE_FIELD, value_bytes)
                _ = pipe.hset(
                    redis_key, self._META_FIELD, self._serialize_meta(meta)
                )
                if ttl > 0:
                    # 设置 Redis 内置 TTL，过期后自动删除整个 Hash
                    _ = pipe.expire(redis_key, ttl)
                elif ttl == 0:
                    # ttl=0 表示永不过期，清除之前的过期时间
                    _ = pipe.persist(redis_key)
                _ = pipe.execute()

            return True

        except redis.ConnectionError as e:
            logger.error(f"Redis 连接失败: {e}")
            return False
        except Exception as e:
            logger.error(f"存放缓存失败: {e}")
            return False

    @override
    def evict(self, key: str) -> bool:
        """从缓存中移除指定 key"""
        try:
            redis_key = self._make_redis_key(key)

            # 删除 Hash
            pipe = self._redis.pipeline()
            _ = pipe.delete(redis_key)

            # 从淘汰策略的有序集合中删除
            for policy in ["lru", "lfu", "fifo", "mru"]:
                _ = pipe.zrem(
                    self._make_eviction_key(cast(EvictionPolicy, policy)), key
                )

            _ = pipe.execute()
            return True

        except redis.ConnectionError as e:
            logger.error(f"Redis 连接失败: {e}")
            return False
        except Exception as e:
            logger.error(f"移除缓存失败: {e}")
            return False

    @override
    def clear(self) -> bool:
        """清除缓存"""
        try:
            # 获取所有缓存键
            fifo_zset_key = self._make_eviction_key("fifo")
            all_keys = self._redis.zrange(fifo_zset_key, 0, -1)

            if not all_keys:
                return True

            # 批量删除 Hash
            pipe = self._redis.pipeline()

            # 删除所有 Hash
            for cache_key in all_keys:
                redis_key = self._make_redis_key(cache_key)
                _ = pipe.delete(redis_key)

            # 删除所有有序集合
            for policy in ["lru", "lfu", "fifo", "mru"]:
                _ = pipe.delete(
                    self._make_eviction_key(cast(EvictionPolicy, policy))
                )

            _ = pipe.execute()
            return True

        except redis.ConnectionError as e:
            logger.error(f"Redis 连接失败: {e}")
            return False
        except Exception as e:
            logger.error(f"清除缓存失败: {e}")
            return False

    @override
    def refresh_ttl(self, key: str, ttl: int = 0) -> bool:
        """刷新缓存过期时间"""
        try:
            redis_key = self._make_redis_key(key)

            # 检查 key 是否存在
            if not self._redis.hexists(redis_key, self._VALUE_FIELD):
                return False

            # 获取元数据
            meta_result = self._redis.hget(redis_key, self._META_FIELD)
            if meta_result is None:
                return False
            assert isinstance(meta_result, bytes)
            try:
                meta = self._deserialize_meta(meta_result)
                meta.time_to_live = ttl

                # 更新 Redis
                pipe = self._redis.pipeline()
                _ = pipe.hset(
                    redis_key, self._META_FIELD, self._serialize_meta(meta)
                )
                if ttl > 0:
                    _ = pipe.expire(redis_key, ttl)
                _ = pipe.execute()

                return True

            except Exception as e:
                logger.error(f"反序列化元数据失败: {e}")
                return False

        except redis.ConnectionError as e:
            logger.error(f"Redis 连接失败: {e}")
            return False
        except Exception as e:
            logger.error(f"刷新过期时间失败: {e}")
            return False

    @override
    def size(self) -> int:
        """获取缓存大小"""
        try:
            # 使用 FIFO 有序集合统计键数量
            fifo_zset_key = self._make_eviction_key("fifo")
            return self._redis.zcard(fifo_zset_key)
        except redis.ConnectionError as e:
            logger.error(f"Redis 连接失败: {e}")
            return 0
        except Exception as e:
            logger.error(f"获取缓存大小失败: {e}")
            return 0

    @override
    def get_meta(self, key: str) -> MetaInfo | None:
        """获取缓存元数据"""
        try:
            redis_key = self._make_redis_key(key)
            meta_result = self._redis.hget(redis_key, self._META_FIELD)

            if meta_result is None:
                return None

            return self._deserialize_meta(meta_result)

        except redis.ConnectionError as e:
            logger.error(f"Redis 连接失败: {e}")
            return None
        except Exception as e:
            logger.error(f"获取元数据失败: {e}")
            return None

    def _clean_if_needed(self) -> int:
        """根据策略和容量判断是否需要清理

        Returns:
            清理的键数量
        """
        try:
            if self.maxsize <= 0:
                return 0

            fifo_zset_key = self._make_eviction_key("fifo")
            current_size = self._redis.zcard(fifo_zset_key)
            logger.debug(f"_clean_if_needed: FIFO zset 大小={current_size}, 策略={self.eviction_policy}")

            # 当达到或超过 maxsize 的 133% 时才触发清理
            overflow_threshold: float = self.maxsize * 4 / 3
            if current_size < overflow_threshold:
                logger.debug(f"_clean_if_needed: current_size={current_size} < threshold={overflow_threshold}, 不清理")
                return 0

            logger.debug(f"_clean_if_needed: 触发清理 (current_size={current_size} > threshold={overflow_threshold})")
            # 根据策略清理到 maxsize
            if self.eviction_policy == "lru":
                logger.debug("_clean_if_needed: 调用 _clean_lru_keys")
                return self._clean_lru_keys()
            if self.eviction_policy == "lfu":
                logger.debug("_clean_if_needed: 调用 _clean_lfu_keys")
                return self._clean_lfu_keys()
            if self.eviction_policy == "fifo":
                return self._clean_fifo_keys()
            if self.eviction_policy == "mru":
                return self._clean_mru_keys()

            # 随机替换
            return self._clean_rr_keys()

        except Exception as e:
            logger.error(f"清理超量 key 失败: {e}")
            return 0

    def _cleanup_zset_keys(self) -> int:
        """清理无效的 ZSET 键

        由于 Redis 内置 TTL 会自动删除 Hash，但不会自动删除对应的 ZSET 成员，
        因此需要定期清理 ZSET 中不存在的键。

        Returns:
            清理的键数量
        """
        try:
            fifo_zset_key = self._make_eviction_key("fifo")
            all_keys = self._redis.zrange(fifo_zset_key, 0, -1)

            invalid_keys: list[bytes] = []
            pipe = self._redis.pipeline()
            for cache_key in all_keys:
                redis_key = self._make_redis_key(cache_key)
                _ = pipe.exists(redis_key)

            results = pipe.execute()

            for cache_key, exists in zip(all_keys, results):
                if not exists:
                    invalid_keys.append(cache_key)

            # 从所有 ZSET 中删除无效键
            if invalid_keys:
                pipe = self._redis.pipeline()
                for policy in ["lru", "lfu", "fifo", "mru"]:
                    zset_key = self._make_eviction_key(
                        cast(EvictionPolicy, policy)
                    )
                    for invalid_key in invalid_keys:
                        _ = pipe.zrem(zset_key, invalid_key)
                _ = pipe.execute()

            return len(invalid_keys)

        except Exception as e:
            logger.error(f"清理无效 ZSET 键失败: {e}")
            return 0

    def _clean_lru_keys(self) -> int:
        """清理 LRU 多余的 key"""
        try:
            zset_key = self._make_eviction_key("lru")
            current_size = self._redis.zcard(zset_key)
            logger.debug(f"_clean_lru_keys: LRU zset 大小={current_size}, type={type(current_size)}, maxsize={self.maxsize}")

            if current_size <= self.maxsize:
                logger.debug(f"_clean_lru_keys: current_size <= maxsize，不清理")
                return 0

            # 删除最旧的（score 最小的），多删除一个确保有空间
            remove_count = max(0, current_size - self.maxsize + 1)
            logger.debug(f"_clean_lru_keys: 需要删除 {remove_count} 个 key, type={type(remove_count)}")
            try:
                # 获取所有 key 和 score，用于调试
                all_items = self._redis.zrange(zset_key, 0, -1, withscores=True)
                logger.debug(f"_clean_lru_keys: LRU zset 所有元素: {all_items}")

                keys_to_remove = self._redis.zrange(zset_key, 0, remove_count - 1)
                logger.debug(f"_clean_lru_keys: 要删除 {remove_count} 个 key: {keys_to_remove}")
            except Exception as e:
                logger.error(f"_clean_lru_keys: zrange 失败: {e}")
                return 0

            removed_count = 0
            for key in keys_to_remove:
                key_str = key if isinstance(key, str) else key.decode("utf-8")
                logger.debug(f"_clean_lru_keys: 删除 key: {key_str}")
                if self.evict(key_str):
                    removed_count += 1

            logger.debug(f"_clean_lru_keys: 实际删除了 {removed_count} 个 key")
            return removed_count

        except Exception as e:
            logger.error(f"清理 LRU key 失败: {e}")
            return 0

    def _clean_lfu_keys(self) -> int:
        """清理 LFU 多余的 key"""
        try:
            zset_key = self._make_eviction_key("lfu")
            current_size = self._redis.zcard(zset_key)

            if current_size <= self.maxsize:
                return 0

            # 删除访问次数最少的（score 最小的），多删除一个确保有空间
            remove_count = max(0, current_size - self.maxsize + 1)
            # 调试：打印所有 key 和 score
            all_keys_with_scores = self._redis.zrange(zset_key, 0, -1, withscores=True)
            logger.debug(f"_clean_lfu_keys: 所有键和分数={all_keys_with_scores}")
            keys_to_remove = self._redis.zrange(zset_key, 0, remove_count - 1)
            logger.debug(f"_clean_lfu_keys: 将删除的键={keys_to_remove}")

            removed_count = 0
            for key in keys_to_remove:
                key_str = key if isinstance(key, str) else key.decode("utf-8")
                logger.debug(f"_clean_lfu_keys: 删除 key: {key_str}")
                evict_result = self.evict(key_str)
                logger.debug(f"_clean_lfu_keys: 删除 key={key_str}, 结果={evict_result}")
                if evict_result:
                    removed_count += 1

            return removed_count

        except Exception as e:
            logger.error(f"清理 LFU key 失败: {e}")
            return 0

    def _clean_fifo_keys(self) -> int:
        """清理 FIFO 多余的 key"""
        try:
            zset_key = self._make_eviction_key("fifo")
            current_size = self._redis.zcard(zset_key)

            if current_size <= self.maxsize:
                return 0

            # FIFO 有序集合已按 create_at 排序
            # 删除最早的（score 最小的），多删除一个确保有空间
            remove_count = max(0, current_size - self.maxsize + 1)
            # 调试：打印所有 key 和 score
            all_keys_with_scores = self._redis.zrange(zset_key, 0, -1, withscores=True)
            logger.debug(f"_clean_fifo_keys: 所有键和分数={all_keys_with_scores}")
            keys_to_remove = self._redis.zrange(zset_key, 0, remove_count - 1)
            logger.debug(f"_clean_fifo_keys: 将删除的键={keys_to_remove}")

            removed_count = 0
            for key in keys_to_remove:
                key_str = key if isinstance(key, str) else key.decode("utf-8")
                logger.debug(f"_clean_fifo_keys: 尝试删除 key={key_str}")
                evict_result = self.evict(key_str)
                logger.debug(f"_clean_fifo_keys: 删除 key={key_str}, 结果={evict_result}")
                if evict_result:
                    removed_count += 1

            return removed_count

        except Exception as e:
            logger.error(f"清理 FIFO key 失败: {e}")
            return 0

    def _clean_rr_keys(self) -> int:
        """随机清理 key"""
        try:
            zset_key = self._make_eviction_key("fifo")
            current_size = self._redis.zcard(zset_key)

            if current_size <= self.maxsize:
                return 0

            remove_count = max(0, current_size - self.maxsize + 1)
            all_keys = self._redis.zrange(zset_key, 0, -1)

            # 随机选择要删除的 keys
            keys_to_remove = random.sample(all_keys, remove_count)

            removed_count = 0
            for key in keys_to_remove:
                key_str = key if isinstance(key, str) else key.decode("utf-8")
                logger.debug(f"_clean_rr_keys: 尝试删除 key={key_str}")
                evict_result = self.evict(key_str)
                logger.debug(f"_clean_mru_keys: 删除 key={key_str}, 结果={evict_result}")
                if evict_result:
                    removed_count += 1

            return removed_count

        except Exception as e:
            logger.error(f"随机清理 key 失败: {e}")
            return 0

    def _clean_mru_keys(self) -> int:
        """清理 MRU 多余的 key"""
        try:
            zset_key = self._make_eviction_key("mru")
            current_size = self._redis.zcard(zset_key)

            if current_size <= self.maxsize:
                return 0

            # 删除最近使用的（score 最大的）
            remove_count = max(0, current_size - self.maxsize + 1)
            # 调试：打印所有 key 和 score
            all_keys_with_scores = self._redis.zrange(zset_key, 0, -1, withscores=True)
            logger.debug(f"_clean_mru_keys: 所有键和分数={all_keys_with_scores}")
            # zrevrange 从大到小排序
            keys_to_remove = self._redis.zrevrange(zset_key, 0, remove_count - 1)
            logger.debug(f"_clean_mru_keys: 将删除的键={keys_to_remove}")

            removed_count = 0
            for key in keys_to_remove:
                key_str = key if isinstance(key, str) else key.decode("utf-8")
                logger.debug(f"_clean_mru_keys: 尝试删除 key={key_str}")
                evict_result = self.evict(key_str)
                logger.debug(f"_clean_mru_keys: 删除 key={key_str}, 结果={evict_result}")
                if evict_result:
                    removed_count += 1

            return removed_count

        except Exception as e:
            logger.error(f"清理 MRU key 失败: {e}")
            return 0

    def _add_to_eviction_zset(
        self, pipe: Pipeline, key: str, meta: MetaInfo
    ) -> None:
        """添加到淘汰策略的有序集合"""
        # 添加到策略对应的有序集合（用于淘汰决策）
        if self.eviction_policy == "lru":
            _ = pipe.zadd(
                self._make_eviction_key("lru"), {key: meta.last_accessed_at}
            )
        elif self.eviction_policy == "lfu":
            _ = pipe.zadd(
                self._make_eviction_key("lfu"), {key: meta.access_count}
            )
        elif self.eviction_policy == "fifo":
            _ = pipe.zadd(
                self._make_eviction_key("fifo"), {key: meta.create_at}
            )
        elif self.eviction_policy == "mru":
            _ = pipe.zadd(
                self._make_eviction_key("mru"), {key: meta.last_accessed_at}
            )

        # 始终添加到 FIFO 用于追踪所有键（用于 size() 统计）
        _ = pipe.zadd(self._make_eviction_key("fifo"), {key: meta.create_at})

    def _update_eviction_zset(self, key: str, meta: MetaInfo) -> None:
        """更新淘汰策略的有序集合"""
        if self.eviction_policy == "lru":
            _ = self._redis.zadd(
                self._make_eviction_key("lru"), {key: meta.last_accessed_at}
            )
        if self.eviction_policy == "lfu":
            _ = self._redis.zadd(
                self._make_eviction_key("lfu"), {key: meta.access_count}
            )
        if self.eviction_policy == "mru":
            _ = self._redis.zadd(
                self._make_eviction_key("mru"), {key: meta.last_accessed_at}
            )
