import hashlib
import inspect
from typing import Any, Literal

from collections.abc import Callable



class ConfigableKeygenerator:
    """可配置的缓存键生成器

    通过配置参数控制缓存键的生成逻辑，支持灵活的键生成策略。
    对于复杂场景，可以通过继承此类并重写相关方法来实现自定义逻辑。

    Attributes:
        include_module: 是否包含模块名
        include_class: 是否包含类名
        include_function: 是否包含函数名
        include_args: 是否包含位置参数
        include_kwargs: 是否包含关键字参数
        show_args_names: 是否显示位置参数的参数名
        include_params: 包含的参数名集合，如果指定则只包含这些参数
        exclude_params: 排除的参数名集合，排除这些参数
        hash_params: 是否对参数进行哈希处理
        hash_key: 是否对整个键进行哈希处理
        hash_algorithm: 哈希算法，支持 md5, sha1, sha256, sha512
        hash_truncate: 哈希值截断长度，None 表示不截断
        separator: 键各部分之间的分隔符
    """

    def __init__(
        self,
        include_module: bool = True,
        include_class: bool = True,
        include_function: bool = True,
        include_args: bool = True,
        include_kwargs: bool = True,
        show_args_names: bool = True,
        include_params: set[str] | None = None,
        exclude_params: set[str] | None = None,
        hash_params: bool = False,
        hash_key: bool = False,
        hash_algorithm: Literal["md5", "sha1", "sha256", "sha512"] = "md5",
        hash_truncate: int | None = 16,
        separator: str = ":",
    ) -> None:
        """初始化可配置的键生成器

        Args:
            include_module: 是否包含模块名
            include_class: 是否包含类名
            include_function: 是否包含函数名
            include_args: 是否包含位置参数
            include_kwargs: 是否包含关键字参数
            show_args_names: 是否显示位置参数的参数名
            include_params: 包含的参数名集合，如果指定则只包含这些参数
            exclude_params: 排除的参数名集合，排除这些参数
            hash_params: 是否对参数进行哈希处理
            hash_key: 是否对整个键进行哈希处理
            hash_algorithm: 哈希算法
            hash_truncate: 哈希值截断长度
            separator: 键各部分之间的分隔符
        """
        self._include_module: bool = include_module
        self._include_class: bool = include_class
        self._include_function: bool = include_function
        self._include_args: bool = include_args
        self._include_kwargs: bool = include_kwargs
        self._show_args_names: bool = show_args_names
        self._include_params: set[str] | None = include_params
        self._exclude_params: set[str] | None = exclude_params
        self._hash_params: bool = hash_params
        self._hash_key: bool = hash_key
        self._hash_algorithm: Literal["md5", "sha1", "sha256", "sha512"] = (
            hash_algorithm
        )
        self._hash_truncate: int | None = hash_truncate
        self._separator: str = separator

    def __call__(
        self,
        func: Callable[..., Any],
        instance_or_class: Any | None,
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> str:
        """生成缓存键

        Args:
            func: 被装饰的函数对象
            instance_or_class: self (实例方法)、cls (类方法) 或 None (普通函数)
            args: 函数的位置参数 (args，不包含 self/cls)
            kwargs: 函数的关键字参数

        Returns:
            生成的缓存键
        """
        return self.generate(func, instance_or_class, args, kwargs)

    def generate(
        self,
        func: Callable[..., Any],
        instance_or_class: Any | None,
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> str:
        """生成缓存键

        Args:
            func: 被装饰的函数对象
            instance_or_class: self (实例方法)、cls (类方法) 或 None (普通函数)
            args: 函数的位置参数 (args，不包含 self/cls)
            kwargs: 函数的关键字参数

        Returns:
            生成的缓存键
        """
        parts: list[str] = []

        # 添加模块名
        if self._include_module:
            module_name: str = self._get_module_name(func)
            if module_name:
                parts.append(module_name)

        # 添加类名
        if self._include_class and instance_or_class is not None:
            class_name: str = self._get_class_name(instance_or_class)
            if class_name:
                parts.append(class_name)

        # 添加函数名
        if self._include_function:
            function_name: str = self._get_function_name(func)
            if function_name:
                parts.append(function_name)

        # 添加参数
        params_str: str = self.build_params(func, args, kwargs)
        if params_str:
            parts.append(params_str)

        # 拼接最终键
        final_key: str = self._separator.join(parts)

        # 如果需要对整个键进行哈希
        if self._hash_key:
            final_key = self._hash(final_key)

        return final_key

    def build_params(
        self,
        func: Callable[..., Any],
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> str:
        """构建参数字符串

        Args:
            func: 函数对象
            args: 位置参数
            kwargs: 关键字参数

        Returns:
            参数字符串
        """
        parts: list[str] = []

        # 过滤并处理位置参数
        if self._include_args and args:
            if self._show_args_names:
                # 获取函数的参数名
                param_names: list[str] = self.get_param_names(func)
                # 将位置参数与参数名关联
                args_dict: dict[str, Any] = {}
                for i, arg_value in enumerate(args):
                    if i < len(param_names):
                        args_dict[param_names[i]] = arg_value
                args_str: str = f"args={args_dict}"
            else:
                args_str = f"args={args}"

            if self._hash_params:
                args_str = self._hash(args_str)
            parts.append(args_str)

        # 过滤并处理关键字参数
        if self._include_kwargs and kwargs:
            filtered_kwargs: dict[str, Any] = self._filter_kwargs(kwargs)
            if filtered_kwargs:
                kwargs_str: str = f"kwargs={filtered_kwargs}"
                if self._hash_params:
                    kwargs_str = self._hash(kwargs_str)
                parts.append(kwargs_str)

        return ":".join(parts)

    def _filter_kwargs(self, kwargs: dict[str, Any]) -> dict[str, Any]:
        """过滤关键字参数

        Args:
            kwargs: 原始关键字参数

        Returns:
            过滤后的关键字参数
        """
        filtered: dict[str, Any] = {}

        for key, value in kwargs.items():
            # 如果指定了 include_params，只包含这些参数
            if self._include_params is not None:
                if key not in self._include_params:
                    continue

            # 如果指定了 exclude_params，排除这些参数
            if self._exclude_params is not None:
                if key in self._exclude_params:
                    continue

            filtered[key] = value

        return filtered

    def _hash(self, value: str) -> str:
        """对字符串进行哈希处理

        Args:
            value: 要哈希的字符串

        Returns:
            哈希值字符串
        """
        hash_func = getattr(hashlib, self._hash_algorithm)
        hashed: str = hash_func(value.encode()).hexdigest()

        if self._hash_truncate is not None:
            hashed = hashed[: self._hash_truncate]

        return hashed

    def _get_module_name(self, func: Callable[..., Any]) -> str:
        """获取函数的模块名

        Args:
            func: 函数对象

        Returns:
            模块名
        """
        module_name: str = ""
        if hasattr(func, "__module__") and func.__module__:
            module_name = func.__module__
        return module_name

    def _get_class_name(self, instance_or_class: Any | None) -> str:
        """获取类名

        Args:
            instance_or_class: 实例或类对象

        Returns:
            类名
        """
        class_name: str = ""
        if instance_or_class is None:
            return class_name

        if hasattr(instance_or_class, "__class__"):
            class_name = instance_or_class.__class__.__name__
        elif hasattr(instance_or_class, "__name__"):
            class_name = instance_or_class.__name__

        return class_name

    def _get_function_name(self, func: Callable[..., Any]) -> str:
        """获取函数名

        Args:
            func: 函数对象

        Returns:
            函数名
        """
        function_name: str = ""
        if hasattr(func, "__name__"):
            function_name = func.__name__
        return function_name

    def get_param_names(self, func: Callable[..., Any]) -> list[str]:
        """获取函数的参数名列表

        Args:
            func: 函数对象

        Returns:
            参数名列表
        """
        param_names: list[str] = []
        signature = inspect.signature(func)
        for param in signature.parameters.values():
            param_names.append(param.name)
        return param_names


# 默认的键生成器实例
default_key_generator: ConfigableKeygenerator = ConfigableKeygenerator()
"""
默认键生成器：包含完整信息（模块名、类名、函数名、参数）

示例输出：
    module.submodule.ClassName.function_name:args=(1,2):kwargs={'a':1,'b':2}
"""


# 参数哈希的键生成器
hashed_params_key_generator: ConfigableKeygenerator = ConfigableKeygenerator(
    hash_params=True,
    hash_algorithm="md5",
    hash_truncate=16,
)
"""
参数哈希键生成器：函数信息可见，参数部分哈希处理

示例输出：
    module.submodule.ClassName.function_name:args=(1,2):kwargs=a1b2c3d4...
"""


# 全部哈希的键生成器
full_hash_key_generator: ConfigableKeygenerator = ConfigableKeygenerator(
    hash_key=True,
    hash_algorithm="md5",
    hash_truncate=16,
)
"""
全部哈希键生成器：整个键进行哈希处理，生成固定长度

示例输出：
    a1b2c3d4e5f6789...
"""


# 仅函数名键生成器
function_only_key_generator: ConfigableKeygenerator = ConfigableKeygenerator(
    include_module=False,
    include_class=False,
    include_function=True,
    include_args=True,
    include_kwargs=True,
)
"""
仅函数名键生成器：只包含函数名和参数

示例输出：
    function_name:args=(1,2):kwargs={'a':1,'b':2}
"""


# 紧凑键生成器
compact_key_generator: ConfigableKeygenerator = ConfigableKeygenerator(
    include_module=False,
    include_class=False,
    include_function=True,
    include_args=False,
    include_kwargs=True,
    hash_params=True,
    hash_algorithm="md5",
    hash_truncate=8,
)
"""
紧凑键生成器：只包含函数名和哈希后的关键字参数，生成较短的键

示例输出：
    function_name:a1b2c3d4
"""


# 不显示位置参数名的键生成器
no_args_names_key_generator: ConfigableKeygenerator = ConfigableKeygenerator(
    show_args_names=False,
)
"""
不显示位置参数名的键生成器：位置参数以元组形式显示，不带参数名

示例输出：
    module.submodule.ClassName.function_name:args=('user123', 2):kwargs={'page': 2}
"""


# 模块方法键生成器（不含参数）
module_function_key_generator: ConfigableKeygenerator = ConfigableKeygenerator(
    include_module=True,
    include_class=False,
    include_function=True,
    include_args=False,
    include_kwargs=False,
)
"""
模块方法键生成器：只包含模块名和方法名，不包含任何参数

适用场景：
- 方法的返回值不依赖参数，每次调用都返回相同结果
- 希望所有调用共享同一个缓存结果

示例输出：
    module.submodule.function_name
"""

