from collections.abc import Callable
from functools import wraps
from inspect import signature
from typing import Any, cast

from pynomad.cache.core.cache_interface import Cache
from pynomad.cache.core.cache_registry import CacheRegistry
from pynomad.cache.core.types import (
    DecoratorTarget,
    KeyGenerator,
)
from pynomad.cache.decorator.keygenerator import default_key_generator
from pynomad.logsystem.manager import get_logger

logger = get_logger()


class MultiLevelDecorator:
    """多级缓存装饰器

    支持三级缓存（L1, L2, L3），其中 L1 为必选项，L2 和 L3 为可选项。
    实现写穿透（write-through）和读穿透（read-through）策略。

    写穿透策略:
    - put 操作同步到所有启用的缓存层级

    读穿透策略:
    - get 操作优先从 L1 获取
    - L1 未命中则从 L2 获取，并将结果缓存到 L1
    - L2 未命中则从 L3 获取，并将结果缓存到 L2 和 L1
    - 所有层级都未命中则返回 None

    每个缓存层级维护独立的 TTL 和淘汰策略。

    Attributes:
        name: 缓存实例名称
        keygenerator: 缓存键生成器
        ttl: 全局 TTL（秒），0 表示永不过期
        l1_code: L1 缓存类型代码（默认为 "memory"）
        l1_name: L1 缓存名称
        l1_keygenerator: L1 缓存键生成器
        l1_ttl: L1 缓存 TTL
        l2_code: L2 缓存类型代码（None 表示不启用 L2）
        l2_name: L2 缓存名称
        l2_keygenerator: L2 缓存键生成器
        l2_ttl: L2 缓存 TTL
        l3_code: L3 缓存类型代码（None 表示不启用 L3）
        l3_name: L3 缓存名称
        l3_keygenerator: L3 缓存键生成器
        l3_ttl: L3 缓存 TTL
    """

    def __init__(
        self,
        name: str,
        keygenerator: KeyGenerator = default_key_generator,
        ttl: int = 0,
        l1_code: str = "memory",
        l1_name: str | None = None,
        l1_keygenerator: KeyGenerator | None = None,
        l1_ttl: int = 0,
        l2_code: str | None = None,
        l2_name: str | None = None,
        l2_keygenerator: KeyGenerator | None = None,
        l2_ttl: int = 0,
        l3_code: str | None = None,
        l3_name: str | None = None,
        l3_keygenerator: KeyGenerator | None = None,
        l3_ttl: int = 0,
    ) -> None:
        """初始化多级缓存装饰器

        Args:
            name: 缓存实例名称
            keygenerator: 缓存键生成器
            ttl: 全局 TTL（秒），0 表示永不过期
            l1_code: L1 缓存类型代码，默认为 "memory"
            l1_name: L1 缓存名称
            l1_keygenerator: L1 缓存键生成器
            l1_ttl: L1 缓存 TTL，0 表示使用全局 ttl
            l2_code: L2 缓存类型代码，None 表示不启用 L2
            l2_name: L2 缓存名称
            l2_keygenerator: L2 缓存键生成器
            l2_ttl: L2 缓存 TTL，0 表示使用全局 ttl
            l3_code: L3 缓存类型代码，None 表示不启用 L3
            l3_name: L3 缓存名称
            l3_keygenerator: L3 缓存键生成器
            l3_ttl: L3 缓存 TTL，0 表示使用全局 ttl
        """
        self._name = name
        self._keygenerator = keygenerator or default_key_generator
        self._ttl = ttl

        # L1 配置
        self._l1_code = l1_code
        self._l1_name = l1_name or f"{name}_l1"
        self._l1_keygenerator = l1_keygenerator or self._keygenerator
        self._l1_ttl = l1_ttl or ttl

        # L2 配置
        self._l2_code = l2_code
        self._l2_name = l2_name or f"{name}_l2"
        self._l2_keygenerator = l2_keygenerator or self._keygenerator
        self._l2_ttl = l2_ttl or ttl
        self._l2_enabled = l2_code is not None

        # L3 配置
        self._l3_code = l3_code
        self._l3_name = l3_name or f"{name}_l3"
        self._l3_keygenerator = l3_keygenerator or self._keygenerator
        self._l3_ttl = l3_ttl or ttl
        self._l3_enabled = l3_code is not None

        # 缓存实例（延迟初始化）
        self._l1_cache: Cache | None = None
        self._l2_cache: Cache | None = None
        self._l3_cache: Cache | None = None
        self._func: DecoratorTarget | None = None

    def __call__(self, func: DecoratorTarget) -> DecoratorTarget:
        """装饰器调用方法

        Args:
            func: 被装饰的函数

        Returns:
            包装后的函数
        """
        self._func = func

        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            # 初始化缓存实例
            caches = self._get_caches()

            # 解析参数并生成缓存键
            instance_or_class, args_for_key = self._parse_args(func, args)
            cache_key = self._keygenerator(func, instance_or_class, args_for_key, kwargs)

            # 尝试从多级缓存获取数据（读穿透）
            cached_data = self._get_from_cache(caches, cache_key)
            if cached_data is not None:
                logger.trace(
                    f"多级缓存命中 - 函数: {func.__qualname__}, "
                    + f"缓存键: {cache_key}"
                )
                return cached_data

            # 缓存未命中，执行函数并缓存结果
            logger.trace(
                f"多级缓存未命中 - 函数: {func.__qualname__}, "
                + f"缓存键: {cache_key}"
            )
            result = func(*args, **kwargs)

            # 缓存结果到所有层级（写穿透）
            self._put_to_all_levels(caches, cache_key, result, args_for_key, kwargs)

            return result

        wrapper.__signature__ = signature(func)  # type: ignore[attr-defined]
        return cast(DecoratorTarget, wrapper)

    def _get_caches(self) -> dict[str, Cache]:
        """获取所有缓存实例（延迟初始化）

        Returns:
            缓存实例字典，包含 "l1", "l2", "l3" 键（如果启用）
        """
        if self._func is None:
            msg = "缓存实例尚未初始化，请确保装饰器已应用到函数"
            raise RuntimeError(msg)

        # L1 必须初始化
        if self._l1_cache is None:
            self._l1_cache = self._create_cache(self._l1_code, self._l1_name)

        # L2 可选
        if self._l2_enabled and self._l2_cache is None:
            self._l2_cache = self._create_cache(self._l2_code, self._l2_name)  # type: ignore[arg-type]

        # L3 可选
        if self._l3_enabled and self._l3_cache is None:
            self._l3_cache = self._create_cache(self._l3_code, self._l3_name)  # type: ignore[arg-type]

        caches: dict[str, Cache] = {"l1": self._l1_cache}
        if self._l2_enabled and self._l2_cache:
            caches["l2"] = self._l2_cache
        if self._l3_enabled and self._l3_cache:
            caches["l3"] = self._l3_cache

        return caches

    def _create_cache(self, code: str, name: str) -> Cache:
        """创建缓存实例

        Args:
            code: 缓存类型代码
            name: 缓存名称

        Returns:
            Cache 实例
        """
        # 使用注册器创建缓存实例
        return CacheRegistry.create(code, name=name)

    def _get_from_cache(self, caches: dict[str, Cache], cache_key: str) -> Any | None:
        """从多级缓存获取数据（读穿透）

        优先级: L1 > L2 > L3

        Args:
            caches: 缓存实例字典
            cache_key: 缓存键

        Returns:
            缓存数据，未命中返回 None
        """
        l1_cache = caches["l1"]

        # 尝试从 L1 获取
        result_l1 = l1_cache.get(cache_key) # type: ignore
        if result_l1.is_success() and result_l1.data is not None: # type: ignore
            logger.trace(f"L1 缓存命中，缓存键: {cache_key}")
            return result_l1.data # type: ignore

        # L1 未命中，尝试 L2
        if "l2" in caches:
            l2_cache = caches["l2"]
            result_l2 = l2_cache.get(cache_key) # type: ignore
            if result_l2.is_success() and result_l2.data is not None: # type: ignore
                logger.trace(f"L2 缓存命中，缓存键: {cache_key}")
                data_l2 = result_l2.data # type: ignore
                # 回填到 L1
                self._put_to_cache(l1_cache, cache_key, data_l2, self._l1_ttl) # type: ignore
                return data_l2 # type: ignore

        # L2 未命中（或未启用），尝试 L3
        if "l3" in caches:
            l3_cache = caches["l3"]
            result_l3 = l3_cache.get(cache_key) # type: ignore
            if result_l3.is_success() and result_l3.data is not None: # type: ignore
                logger.trace(f"L3 缓存命中，缓存键: {cache_key}")
                data_l3 = result_l3.data # type: ignore
                # 回填到 L2 和 L1
                if "l2" in caches:
                    self._put_to_cache(caches["l2"], cache_key, data_l3, self._l2_ttl) # type: ignore
                self._put_to_cache(l1_cache, cache_key, data_l3, self._l1_ttl) # type: ignore
                return data_l3 # type: ignore

        # 所有层级都未命中
        logger.trace(f"所有缓存层级都未命中，缓存键: {cache_key}")
        return None

    def _put_to_all_levels(
        self,
        caches: dict[str, Cache],
        cache_key: str,
        value: object,
        args_for_key: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> None:
        """将数据缓存到所有层级（写穿透）

        Args:
            caches: 缓存实例字典
            cache_key: 缓存键
            value: 要缓存的值
            args_for_key: 用于生成键的参数
            kwargs: 关键字参数
        """
        extra_params: dict[str, Any] = {
            "args": args_for_key,
            "kwargs": kwargs,
        }

        # 写入 L1
        self._put_to_cache(caches["l1"], cache_key, value, self._l1_ttl, extra_params)

        # 写入 L2（如果启用）
        if "l2" in caches:
            self._put_to_cache(caches["l2"], cache_key, value, self._l2_ttl, extra_params)

        # 写入 L3（如果启用）
        if "l3" in caches:
            self._put_to_cache(caches["l3"], cache_key, value, self._l3_ttl, extra_params)

    def _put_to_cache(
        self,
        cache: Cache,
        cache_key: str,
        value: object,
        ttl: int,
        extra_params: dict[str, Any] | None = None,
    ) -> None:
        """写入单个缓存层级

        Args:
            cache: 缓存实例
            cache_key: 缓存键
            value: 要缓存的值
            ttl: TTL
            extra_params: 额外参数
        """
        _ = cache.put(cache_key, value, ttl=ttl, extra_params=extra_params)
        logger.trace(
            f"已写入缓存 {cache.name}，" + f"缓存键: {cache_key}，TTL: {ttl}"
        )

    def _parse_args(
        self,
        func: DecoratorTarget,
        args: tuple[Any, ...],
    ) -> tuple[Any | None, tuple[Any, ...]]:
        """解析函数参数，分离 self/cls

        Args:
            func: 被装饰的函数
            args: 函数的位置参数

        Returns:
            (instance_or_class, args_for_key) 元组
        """
        instance_or_class: Any | None = None

        if args and hasattr(args[0], func.__name__):
            instance_or_class = args[0]
            args_for_key = args[1:]
        else:
            args_for_key = args

        return instance_or_class, args_for_key

    def clear(self) -> None:
        """清空所有缓存层级"""
        caches = self._get_caches()
        for cache_name, cache in caches.items():
            _ = cache.clear()
            logger.trace(f"已清空 {cache_name} 缓存")

    def get_stats(self) -> dict[str, dict[str, int]]:
        """获取所有缓存层级的统计信息

        Returns:
            统计信息字典，键为 "l1", "l2", "l3"，值为各自的统计信息
        """
        caches = self._get_caches()
        stats: dict[str, dict[str, int]] = {}
        for cache_name, cache in caches.items():
            stats[cache_name] = {
                "size": cache.size(),
            }
        return stats


def multi_level_cached(
    name: Callable[..., Any] | str,
    keygenerator: KeyGenerator | None = None,
    ttl: int = 0,
    l1_code: str = "memory",
    l1_name: str | None = None,
    l1_keygenerator: KeyGenerator | None = None,
    l1_ttl: int = 0,
    l2_code: str | None = None,
    l2_name: str | None = None,
    l2_keygenerator: KeyGenerator | None = None,
    l2_ttl: int = 0,
    l3_code: str | None = None,
    l3_name: str | None = None,
    l3_keygenerator: KeyGenerator | None = None,
    l3_ttl: int = 0,
) -> Any:
    """多级缓存装饰器

    支持两种用法:
    1. @multi_level_cached("cache_name") - 简单用法
    2. @multi_level_cached(...) - 带参数的完整用法

    Args:
        name: 缓存名称（必选）
        keygenerator: 缓存键生成器
        ttl: 全局 TTL（秒），0 表示永不过期
        l1_code: L1 缓存类型代码，默认为 "memory"
        l1_name: L1 缓存名称
        l1_keygenerator: L1 缓存键生成器
        l1_ttl: L1 缓存 TTL，0 表示使用全局 ttl
        l2_code: L2 缓存类型代码，None 表示不启用 L2
        l2_name: L2 缓存名称
        l2_keygenerator: L2 缓存键生成器
        l2_ttl: L2 缓存 TTL，0 表示使用全局 ttl
        l3_code: L3 缓存类型代码，None 表示不启用 L3
        l3_name: L3 缓存名称
        l3_keygenerator: L3 缓存键生成器
        l3_ttl: L3 缓存 TTL，0 表示使用全局 ttl

    Returns:
        装饰器或装饰后的函数

    注意:
        多级缓存是通用缓存实现，不支持 DataFrame 三阶段处理。
        如需 DataFrame 三阶段缓存支持，请使用专用的装饰器，如 @sqlcached、@rediscached 等。
        这是因为 AI 助手太懒，没有实现多级缓存的 DataFrame 扩展支持。

    示例:
        双级缓存（L1: memory, L2: pickle）：
        @multi_level_cached(
            name="my_cache",
            l1_code="memory",
            l2_code="pickle",
        @multi_level_cached(
            name="my_cache",
            l1_code="memory",
            l2_code="sql",
            ttl=60
        )
        def get_data(key: str) -> str:
            return fetch_from_db(key)

        三级缓存（L1: memory, L2: pickle, L3: redis）：
        @multi_level_cached(
            name="my_cache",
            l1_code="memory",
            l2_code="pickle",
            l3_code="redis",
            l1_ttl=10,
            l2_ttl=60,
            l3_ttl=300
        )
        def get_data(key: str) -> str:
            return fetch_from_db(key)
    """
    # 如果 name 是可调用的（直接装饰函数）
    if callable(name):
        msg = "multi_level_cached 必须提供 name 参数"
        raise ValueError(msg)

    cache_name: str = name

    def decorator_inner(func: DecoratorTarget) -> DecoratorTarget:
        decorator = MultiLevelDecorator(
            name=cache_name,
            keygenerator=keygenerator or default_key_generator,
            ttl=ttl,
            l1_code=l1_code,
            l1_name=l1_name,
            l1_keygenerator=l1_keygenerator,
            l1_ttl=l1_ttl,
            l2_code=l2_code,
            l2_name=l2_name,
            l2_keygenerator=l2_keygenerator,
            l2_ttl=l2_ttl,
            l3_code=l3_code,
            l3_name=l3_name,
            l3_keygenerator=l3_keygenerator,
            l3_ttl=l3_ttl,
        )
        return decorator(func)

    return decorator_inner
