from typing import Any, override

from pynomad.cache.core.cache_interface import Cache
from pynomad.cache.core.types import (
    DecoratorTarget,
    EvictionPolicy,
    KeyGenerator,
)
from pynomad.cache.decorator.base_decorator import BaseCacheDecorator
from pynomad.cache.decorator.keygenerator import default_key_generator
from pynomad.cache.impl.pickle_cache import PickleCache


class PickleCacheDecorator(BaseCacheDecorator):
    """Pickle 缓存装饰器

    通过装饰器的方式为函数添加缓存功能，使用文件系统持久化缓存数据。
    支持离线访问和数据迁移，适合需要持久化且不要求高并发的场景。

    Attributes:
        name: 缓存实例名称，如果为 None 则自动生成（格式：module.function_name）
        maxsize: 缓存最大容量
        eviction_policy: 缓存淘汰策略
        keygenerator: 缓存键生成器
        cache_dir: 缓存文件存储目录
        enable_encryption: 是否启用加密（使用 get_machine_key）
        salt: 加密盐值
        enable_background_cleanup: 是否启用后台清理过期缓存
        cleanup_interval: 后台清理间隔（秒）
    """

    def __init__(
        self,
        name: str | None = None,
        maxsize: int | None = None,
        eviction_policy: EvictionPolicy | None = None,
        keygenerator: KeyGenerator | None = None,
        ttl: int = 0,
        cache_dir: str | None = None,
        enable_encryption: bool | None = None,
        salt: str = "",
        enable_background_cleanup: bool | None = None,
        cleanup_interval: int = 0,
    ) -> None:
        """初始化 Pickle 缓存装饰器

        Args:
            name: 缓存实例名称，None 表示使用配置默认值
            maxsize: 缓存最大容量，None 表示使用配置默认值
            eviction_policy: 缓存淘汰策略，None 表示使用配置默认值
            keygenerator: 缓存键生成器，None 表示使用配置默认值
            ttl: 缓存存活时间（秒），0 表示永不过期
            cache_dir: 缓存文件存储目录，None 表示使用配置默认值
            enable_encryption: 是否启用加密，None 表示使用配置默认值
            salt: 加密盐值
            enable_background_cleanup: 是否启用后台清理，None 表示使用配置默认值
            cleanup_interval: 后台清理间隔（秒）
        """
        # 参数都交给 PickleCache 处理，这里直接传递
        self._name = name
        self._maxsize = maxsize
        self._eviction_policy = eviction_policy
        self._keygenerator = keygenerator or default_key_generator
        self._ttl = ttl
        self._cache_dir = cache_dir
        self._enable_encryption = enable_encryption
        self._salt = salt
        self._enable_background_cleanup = enable_background_cleanup
        self._cleanup_interval = cleanup_interval
        self._cache_instance: Cache | None = None
        self._func: DecoratorTarget | None = None

    @override
    def _create_cache(self) -> Cache:
        """创建 PickleCache 实例

        Returns:
            PickleCache 实例
        """
        return PickleCache(
            name=self._name or "",
            maxsize=self._maxsize if self._maxsize is not None else 0,
            eviction_policy=self._eviction_policy,
            cache_dir=self._cache_dir or "",
            enable_encryption=self._enable_encryption,
            salt=self._salt,
            enable_background_cleanup=self._enable_background_cleanup,
            cleanup_interval=self._cleanup_interval,
        )


def pickled(
    name: Any = None,
    maxsize: int | None = None,
    eviction_policy: EvictionPolicy | None = None,
    keygenerator: KeyGenerator | None = None,
    ttl: int = 0,
    cache_dir: str | None = None,
    enable_encryption: bool | None = None,
    salt: str = "",
    enable_background_cleanup: bool | None = None,
    cleanup_interval: int = 0,
) -> Any:
    """Pickle 缓存装饰器

    支持两种用法：
    1. @pickled - 无参数直接装饰函数
    2. @pickled(...) - 带参数装饰函数

    Args:
        name: 被装饰的函数（无参模式）或缓存名称（带参模式），None 表示使用配置默认值
        maxsize: 缓存最大容量（仅带参模式有效），None 表示使用配置默认值
        eviction_policy: 缓存淘汰策略（仅带参模式有效），None 表示使用配置默认值
        keygenerator: 缓存键生成器（仅带参模式有效），None 表示使用配置默认值
        ttl: 缓存存活时间（秒）（仅带参模式有效），None 表示使用配置默认值
        cache_dir: 缓存文件存储目录，None 表示使用配置默认值
        enable_encryption: 是否启用加密，None 表示使用配置默认值
        salt: 加密盐值，None 表示使用配置默认值
        enable_background_cleanup: 是否启用后台清理，None 表示使用配置默认值
        cleanup_interval: 后台清理间隔（秒），None 表示使用配置默认值

    Returns:
        装饰器或装饰后的函数

    优先级：
        用户传入参数 > 配置数据 > 硬编码默认值

    示例:
        无参数装饰（使用配置默认值）：
        @pickled
        def expensive_function(x: int, y: int) -> int:
            return x + y

        带参数装饰（覆盖配置值）：
        @pickled(
            name="my_cache",
            maxsize=100,
            cache_dir="./my_cache",
            ttl=3600
        )
        def another_function(x: int) -> int:
            return x * 2

        启用加密：
        @pickled(enable_encryption=True, salt="my_project_v1")
        def secure_function(data: str) -> str:
            return process_data(data)

        使用场景：
        - 需要持久化缓存的离线场景
        - 数据迁移和备份
        - 数据分析和审计
        - 跨进程共享（通过共享目录）
    """
    # 如果直接用作 @pickled 装饰函数（第一个参数是可调用的）
    if callable(name):
        func: DecoratorTarget = name
        decorator = PickleCacheDecorator(
            name=None,
            maxsize=maxsize,
            eviction_policy=eviction_policy,
            keygenerator=keygenerator,
            ttl=ttl,
            cache_dir=cache_dir,
            enable_encryption=enable_encryption,
            salt=salt,
            enable_background_cleanup=enable_background_cleanup,
            cleanup_interval=cleanup_interval,
        )
        return decorator(func)

    # 用作 @pickled(...) 带参数装饰
    cache_name: str | None = name

    def decorator_inner(func: DecoratorTarget) -> DecoratorTarget:
        decorator = PickleCacheDecorator(
            name=cache_name,
            maxsize=maxsize,
            eviction_policy=eviction_policy,
            keygenerator=keygenerator,
            ttl=ttl,
            cache_dir=cache_dir,
            enable_encryption=enable_encryption,
            salt=salt,
            enable_background_cleanup=enable_background_cleanup,
            cleanup_interval=cleanup_interval,
        )
        return decorator(func)

    return decorator_inner
