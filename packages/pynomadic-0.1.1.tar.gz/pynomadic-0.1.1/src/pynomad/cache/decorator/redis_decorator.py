from typing import Any, override

from redis import Redis
from redis.connection import ConnectionPool

from pynomad.cache.core.cache_interface import Cache
from pynomad.cache.core.types import (
    DecoratorTarget,
    EvictionPolicy,
    KeyGenerator,
)
from pynomad.cache.decorator.base_decorator import BaseCacheDecorator
from pynomad.cache.decorator.keygenerator import default_key_generator
from pynomad.cache.impl.redis_cache import RedisCache


class RedisCacheDecorator(BaseCacheDecorator):
    """Redis 缓存装饰器

    通过装饰器的方式为函数添加缓存功能，使用 Redis 缓存实现，提供分布式缓存能力。

    Attributes:
        name: 缓存实例名称，如果为 None 则自动生成（格式：module.function_name）
        maxsize: 缓存最大容量
        eviction_policy: 缓存淘汰策略
        keygenerator: 缓存键生成器
        redis_client: 自定义 Redis 客户端（优先使用）
        connection_pool: 自定义连接池
        host: Redis 主机地址
        port: Redis 端口
        db: Redis 数据库编号
        password: Redis 密码
        enable_encryption: 是否启用加密（使用 get_machine_key）
        salt: 加密盐值，用于生成机器派生密钥
    """

    def __init__(
        self,
        name: str | None = None,
        maxsize: int | None = None,
        eviction_policy: EvictionPolicy | None = None,
        keygenerator: KeyGenerator | None = None,
        ttl: int = 0,
        redis_client: Redis | None = None,
        connection_pool: ConnectionPool | None = None,
        host: str = "",
        port: int = 0,
        db: int = 0,
        username: str = "",
        password: str | None = None,
        enable_encryption: bool | None = None,
        salt: str = "",
    ) -> None:
        """初始化 Redis 缓存装饰器

        Args:
            name: 缓存实例名称，None 表示使用配置默认值
            maxsize: 缓存最大容量，None 表示使用配置默认值
            eviction_policy: 缓存淘汰策略，None 表示使用配置默认值
            keygenerator: 缓存键生成器，None 表示使用配置默认值
            ttl: 缓存存活时间（秒），0 表示永不过期
            redis_client: 自定义 Redis 客户端（优先使用）
            connection_pool: 自定义连接池
            host: Redis 主机地址
            port: Redis 端口
            db: Redis 数据库编号
            username: Redis 用户名
            password: Redis 密码
            enable_encryption: 是否启用加密，None 表示使用配置默认值
            salt: 加密盐值
        """
        # 参数都交给 RedisCache 处理，这里直接传递
        self._name = name
        self._maxsize = maxsize
        self._eviction_policy = eviction_policy
        self._keygenerator = keygenerator or default_key_generator
        self._ttl = ttl
        self._redis_client = redis_client
        self._connection_pool = connection_pool
        self._host = host
        self._port = port
        self._db = db
        self._username = username
        self._password = password
        self._enable_encryption = enable_encryption
        self._salt = salt
        self._cache_instance: Cache | None = None
        self._func: DecoratorTarget | None = None

    @override
    def _create_cache(self) -> Cache:
        """创建 RedisCache 实例

        Returns:
            RedisCache 实例
        """
        # 导入 RedisCache 避免循环导入

        return RedisCache(
            name=self._name or "",
            maxsize=self._maxsize if self._maxsize is not None else 0,
            eviction_policy=self._eviction_policy,
            redis_client=self._redis_client,
            connection_pool=self._connection_pool,
            host=self._host,
            port=self._port,
            db=self._db,
            username=self._username,
            password=self._password,
            enable_encryption=self._enable_encryption,
            salt=self._salt,
        )


def rediscached(
    name: Any = None,
    maxsize: int | None = None,
    eviction_policy: EvictionPolicy | None = None,
    keygenerator: KeyGenerator | None = None,
    ttl: int = 0,
    redis_client: Redis | None = None,
    connection_pool: ConnectionPool | None = None,
    host: str = "",
    port: int = 0,
    db: int = 0,
    username: str = "",
    password: str | None = None,
    enable_encryption: bool | None = None,
    salt: str = "",
) -> Any:
    """Redis 缓存装饰器

    支持两种用法：
    1. @rediscached - 无参数直接装饰函数
    2. @rediscached(...) - 带参数装饰函数

    Args:
        name: 被装饰的函数（无参模式）或缓存名称（带参模式），None 表示使用配置默认值
        maxsize: 缓存最大容量（仅带参模式有效），None 表示使用配置默认值
        eviction_policy: 缓存淘汰策略（仅带参模式有效），None 表示使用配置默认值
        keygenerator: 缓存键生成器（仅带参模式有效），None 表示使用配置默认值
        ttl: 缓存存活时间（秒）（仅带参模式有效），None 表示使用配置默认值
        redis_client: 自定义 Redis 客户端（优先使用）
        connection_pool: 自定义连接池
        host: Redis 主机地址，None 表示使用配置默认值
        port: Redis 端口，None 表示使用配置默认值
        db: Redis 数据库编号，None 表示使用配置默认值
        password: Redis 密码，None 表示使用配置默认值
        enable_encryption: 是否启用加密，None 表示使用配置默认值
        salt: 加密盐值，None 表示使用配置默认值

    Returns:
        装饰器或装饰后的函数

    优先级：
        用户传入参数 > 配置数据 > 硬编码默认值

    示例:
        无参数装饰（使用配置默认值）：
        @rediscached
        def expensive_function(x: int, y: int) -> int:
            return x + y

        带参数装饰（覆盖配置值）：
        @rediscached(name="my_cache", maxsize=100, host="localhost", ttl=60)
        def another_function(x: int) -> int:
            return x * 2

        启用加密：
        @rediscached(enable_encryption=True, salt="my_project_v1")
        def secure_function(data: str) -> str:
            return process_data(data)
    """
    # 如果直接用作 @rediscached 装饰函数（第一个参数是可调用的）
    if callable(name):
        func: DecoratorTarget = name
        decorator = RedisCacheDecorator(
            name=None,
            maxsize=maxsize,
            eviction_policy=eviction_policy,
            keygenerator=keygenerator,
            ttl=ttl,
            redis_client=redis_client,
            connection_pool=connection_pool,
            host=host,
            port=port,
            db=db,
            username=username,
            password=password,
            enable_encryption=enable_encryption,
            salt=salt,
        )
        return decorator(func)

    # 用作 @rediscached(...) 带参数装饰
    cache_name: str | None = name

    def decorator_inner(func: DecoratorTarget) -> DecoratorTarget:
        decorator = RedisCacheDecorator(
            name=cache_name,
            maxsize=maxsize,
            eviction_policy=eviction_policy,
            keygenerator=keygenerator,
            ttl=ttl,
            redis_client=redis_client,
            connection_pool=connection_pool,
            host=host,
            port=port,
            db=db,
            username=username,
            password=password,
            enable_encryption=enable_encryption,
            salt=salt,
        )
        return decorator(func)

    return decorator_inner
