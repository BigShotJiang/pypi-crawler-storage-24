"""SQL 缓存装饰器

提供基于 SQL 数据库的 DataFrame 缓存装饰器实现。
"""

from typing import override

import pandas as pd
from pynomad.cache.core.cache_interface import Cache
from pynomad.cache.core.types import (
    EvictionPolicy,
    KeyGenerator,
)
from pynomad.cache.dataframe.base_df_decorator import BaseDataFrameDecorator
from pynomad.cache.dataframe.types import DataFrameValueLoader
from pynomad.cache.decorator.keygenerator import module_function_key_generator
from pynomad.logsystem.manager import get_logger

logger = get_logger()
DataFrame = pd.DataFrame


class SQLCacheDecorator(BaseDataFrameDecorator):
    """SQL DataFrame 缓存装饰器

    使用 SQL 数据库作为 DataFrame 缓存存储，支持多种数据库类型（SQLite、MySQL、PostgreSQL）。
    继承 BaseDataFrameDecorator 以获得 DataFrame 特定的三阶段处理逻辑。
    """

    def __init__(
        self,
        name: str | None = None,
        second_name: str | None = None,
        maxsize: int | None = None,
        eviction_policy: EvictionPolicy | None = None,
        keygenerator: KeyGenerator= module_function_key_generator,
        value_loader: DataFrameValueLoader | None = None,
        ttl: int = 0,
        db_type: str | None = None,
        db_url: str | None = None,
        host: str | None = None,
        port: int | None = None,
        db_name: str | None = None,
        username: str | None = None,
        password: str | None = None,
        pool_size: int | None = None,
        max_overflow: int | None = None,
        pool_timeout: int | None = None,
        pool_recycle: int | None = None,
        pool_pre_ping: bool | None = None,
        max_retry_attempts: int | None = None,
        retry_delay: float | None = None,
    ) -> None:
        """初始化 SQL DataFrame 缓存装饰器

        Args:
            name: 缓存实例名称，如果为 None 则自动生成
            second_name: 二级名称（用于区分具体方法或数据），None 表示使用配置默认值
            maxsize: 缓存最大容量，None 表示使用配置默认值
            eviction_policy: 缓存淘汰策略，None 表示使用配置默认值
            keygenerator: 缓存键生成器
            value_loader: DataFrame 值加载器
            ttl: 缓存存活时间（秒），0 表示永不过期
            db_type: 数据库类型（sqlite、mysql、postgresql），None 表示使用配置默认值
            db_url: 数据库连接 URL（完整格式），None 表示使用配置默认值
            host: 数据库主机地址（与 db_url 互斥），None 表示使用配置默认值
            port: 数据库端口（与 db_url 互斥），None 表示使用配置默认值
            db_name: 数据库名称（与 db_url 互斥），None 表示使用配置默认值
            username: 数据库用户名（与 db_url 互斥），None 表示使用配置默认值
            password: 数据库密码（与 db_url 互斥），None 表示使用配置默认值
            pool_size: 连接池大小，None 表示使用配置默认值
            max_overflow: 连接池最大溢出数，None 表示使用配置默认值
            pool_timeout: 连接池超时时间（秒），None 表示使用配置默认值
            pool_recycle: 连接回收时间（秒），None 表示使用配置默认值
            pool_pre_ping: 是否在每次连接前测试连接，None 表示使用配置默认值
            max_retry_attempts: 最大重试次数，None 表示使用配置默认值
            retry_delay: 重试延迟（秒），None 表示使用配置默认值
        """
        # 调用父类初始化基础参数
        super().__init__(
            name=name,
            maxsize=maxsize or 128,
            eviction_policy=eviction_policy or "none",
            keygenerator=keygenerator,
            value_loader=value_loader,
            ttl=ttl,
        )
        # SQL 特有参数
        self._second_name = second_name or ""
        self._db_type = db_type
        self._db_url = db_url
        self._host = host
        self._port = port
        self._db_name = db_name
        self._username = username
        self._password = password
        self._pool_size = pool_size
        self._max_overflow = max_overflow
        self._pool_timeout = pool_timeout
        self._pool_recycle = pool_recycle
        self._pool_pre_ping = pool_pre_ping
        self._max_retry_attempts = max_retry_attempts
        self._retry_delay = retry_delay

    @override
    def _create_cache(self) -> Cache:
        """创建 SQL 缓存实例

        Returns:
            SQLCache 实例
        """
        from pynomad.cache.impl.sql_cache import SQLCache

        return SQLCache(
            name=self._name,
            second_name=self._second_name,
            maxsize=self._maxsize,
            eviction_policy=self._eviction_policy,
            db_type=self._db_type,
            db_url=self._db_url,
            host=self._host,
            port=self._port,
            db_name=self._db_name,
            username=self._username,
            password=self._password,
            pool_size=self._pool_size,
            max_overflow=self._max_overflow,
            pool_timeout=self._pool_timeout,
            pool_recycle=self._pool_recycle,
            pool_pre_ping=self._pool_pre_ping,
            max_retry_attempts=self._max_retry_attempts,
            retry_delay=self._retry_delay,
        )


def sqlcached(
    name: str | None = None,
    second_name: str | None = None,
    maxsize: int | None = None,
    eviction_policy: EvictionPolicy | None = None,
    keygenerator: KeyGenerator = module_function_key_generator,
    value_loader: DataFrameValueLoader | None = None,
    ttl: int = 0,
    db_type: str | None = None,
    db_url: str | None = None,
    host: str | None = None,
    port: int | None = None,
    db_name: str | None = None,
    username: str | None = None,
    password: str | None = None,
    pool_size: int | None = None,
    max_overflow: int | None = None,
    pool_timeout: int | None = None,
    pool_recycle: int | None = None,
    pool_pre_ping: bool | None = None,
    max_retry_attempts: int | None = None,
    retry_delay: float | None = None,
) -> SQLCacheDecorator:
    """SQL DataFrame 缓存装饰器便捷函数

    Args:
        name: 缓存实例名称，如果为 None 则自动生成
        second_name: 二级名称（用于区分具体方法或数据），None 表示使用配置默认值
        maxsize: 缓存最大容量，None 表示使用配置默认值
        eviction_policy: 缓存淘汰策略，None 表示使用配置默认值
        keygenerator: 缓存键生成器
        value_loader: DataFrame 值加载器
        ttl: 缓存存活时间（秒），0 表示永不过期
        db_type: 数据库类型（sqlite、mysql、postgresql），None 表示使用配置默认值
        db_url: 数据库连接 URL（完整格式），None 表示使用配置默认值
        host: 数据库主机地址（与 db_url 互斥），None 表示使用配置默认值
        port: 数据库端口（与 db_url 互斥），None 表示使用配置默认值
        db_name: 数据库名称（与 db_url 互斥），None 表示使用配置默认值
        username: 数据库用户名（与 db_url 互斥），None 表示使用配置默认值
        password: 数据库密码（与 db_url 互斥），None 表示使用配置默认值
        pool_size: 连接池大小，None 表示使用配置默认值
        max_overflow: 连接池最大溢出数，None 表示使用配置默认值
        pool_timeout: 连接池超时时间（秒），None 表示使用配置默认值
        pool_recycle: 连接回收时间（秒），None 表示使用配置默认值
        pool_pre_ping: 是否在每次连接前测试连接，None 表示使用配置默认值
        max_retry_attempts: 最大重试次数，None 表示使用配置默认值
        retry_delay: 重试延迟（秒），None 表示使用配置默认值

    Returns:
        SQLCacheDecorator 装饰器实例

    **重要规范**：
        所有使用 @sqlcached 装饰的函数必须显式声明返回类型注解为 Result[DataFrame]，
        否则装饰器无法正确处理返回值的装箱和缓存一致性。
        这是由 Python 动态类型系统的局限性决定的。

    Example:
        ```python
        from pynomad.cache import sqlcached
        from pandas import DataFrame
        from pynomad.result.result import Result

        @sqlcached(db_type="sqlite", db_url="sqlite:///cache.db", ttl=3600)
        def fetch_data(symbol: str) -> Result[DataFrame]:
            # 返回 DataFrame 的函数
            return Result.success(DataFrame())
        ```
    """
    return SQLCacheDecorator(
        name=name,
        second_name=second_name,
        maxsize=maxsize,
        eviction_policy=eviction_policy,
        keygenerator=keygenerator,
        value_loader=value_loader,
        ttl=ttl,
        db_type=db_type,
        db_url=db_url,
        host=host,
        port=port,
        db_name=db_name,
        username=username,
        password=password,
        pool_size=pool_size,
        max_overflow=max_overflow,
        pool_timeout=pool_timeout,
        pool_recycle=pool_recycle,
        pool_pre_ping=pool_pre_ping,
        max_retry_attempts=max_retry_attempts,
        retry_delay=retry_delay,
    )

