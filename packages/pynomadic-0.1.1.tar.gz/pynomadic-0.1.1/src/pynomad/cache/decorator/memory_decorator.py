from typing import Any, override

from pynomad.cache.core.cache_interface import Cache
from pynomad.cache.core.types import (
    DecoratorTarget,
    EvictionPolicy,
    KeyGenerator,
)
from pynomad.cache.decorator.base_decorator import BaseCacheDecorator
from pynomad.cache.decorator.keygenerator import default_key_generator
from pynomad.cache.impl.memory_cache import MemoryCache


class MemoryCacheDecorator(BaseCacheDecorator):
    """内存缓存装饰器

    通过装饰器的方式为函数添加缓存功能，使用内存缓存实现。

    Attributes:
        name: 缓存实例名称，如果为 None 则自动生成（格式：module.function_name）
        maxsize: 缓存最大容量
        eviction_policy: 缓存淘汰策略
        keygenerator: 缓存键生成器
    """

    def __init__(
        self,
        name: str | None = None,
        maxsize: int | None = None,
        eviction_policy: EvictionPolicy | None = None,
        keygenerator: KeyGenerator | None = None,
        ttl: int = 0,
    ) -> None:
        """初始化内存缓存装饰器

        Args:
            name: 缓存实例名称，None 表示使用配置默认值
            maxsize: 缓存最大容量，None 表示使用配置默认值
            eviction_policy: 缓存淘汰策略，None 表示使用配置默认值
            keygenerator: 缓存键生成器，None 表示使用配置默认值
            ttl: 缓存存活时间（秒），0 表示永不过期
        """
        # 参数都交给 MemoryCache 处理，这里直接传递
        self._name = name
        self._maxsize = maxsize
        self._eviction_policy = eviction_policy
        self._keygenerator = keygenerator or default_key_generator
        self._ttl = ttl
        self._cache_instance: Cache | None = None
        self._func: DecoratorTarget | None = None

    @override
    def _create_cache(self) -> Cache:
        """创建 MemoryCache 实例

        Returns:
            MemoryCache 实例
        """
        return MemoryCache(
            name=self._name or "",
            maxsize=self._maxsize if self._maxsize is not None else 0,
            eviction_policy=self._eviction_policy,
        )


def memcached(
    name: Any = None,
    maxsize: int | None = None,
    eviction_policy: EvictionPolicy | None = None,
    keygenerator: KeyGenerator | None = None,
    ttl: int = 0,
) -> Any:
    """内存缓存装饰器

    支持两种用法：
    1. @memcached - 无参数直接装饰函数
    2. @memcached(...) - 带参数装饰函数

    Args:
        name: 被装饰的函数（无参模式）或缓存名称（带参模式），None 表示使用配置默认值
        maxsize: 缓存最大容量（仅带参模式有效），None 表示使用配置默认值
        eviction_policy: 缓存淘汰策略（仅带参模式有效），None 表示使用配置默认值
        keygenerator: 缓存键生成器（仅带参模式有效），None 表示使用配置默认值
        ttl: 缓存存活时间（秒）（仅带参模式有效），None 表示使用配置默认值

    Returns:
        装饰器或装饰后的函数

    优先级：
        用户传入参数 > 配置数据 > 硬编码默认值

    示例:
        无参数装饰（使用配置默认值）：
        @memcached
        def expensive_function(x: int, y: int) -> int:
            return x + y

        带参数装饰（覆盖配置值）：
        @memcached(name="my_cache", maxsize=100, ttl=60)
        def another_function(x: int) -> int:
            return x * 2
    """
    # 如果直接用作 @memcached 装饰函数（第一个参数是可调用的）
    if callable(name):
        func: DecoratorTarget = name
        decorator = MemoryCacheDecorator(
            name=None,
            maxsize=maxsize,
            eviction_policy=eviction_policy,
            keygenerator=keygenerator,
            ttl=ttl,
        )
        return decorator(func)

    # 用作 @memcached(...) 带参数装饰
    cache_name: str | None = name

    def decorator_inner(func: DecoratorTarget) -> DecoratorTarget:
        decorator = MemoryCacheDecorator(
            name=cache_name,
            maxsize=maxsize,
            eviction_policy=eviction_policy,
            keygenerator=keygenerator,
            ttl=ttl,
        )
        return decorator(func)

    return decorator_inner
