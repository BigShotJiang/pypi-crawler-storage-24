from collections.abc import Callable
from typing import Any, override


from pynomad.cache.core.types import (
    DecoratorTarget,
    EvictionPolicy,
    KeyGenerator,
)
from pynomad.cache.dataframe.types import (
    DataFrameValueLoader,
)
from pynomad.cache.dataframe.base_df_decorator import (
    BaseDataFrameDecorator,
)
from pynomad.cache.properties import DataFrameMemoryCacheProperties
from pynomad.cache.decorator.keygenerator import (
            module_function_key_generator,
        )
from pynomad.cache.impl.memory_cache import MemoryCache
from pynomad.logsystem.manager import get_logger

logger = get_logger()


class DataFrameMemoryDecorator(BaseDataFrameDecorator):
    """DataFrame 内存缓存装饰器

    通过装饰器的方式为返回 DataFrame 的函数添加缓存功能，使用内存缓存实现。
    支持三阶段数据处理：GET、PUT、EXTRACT。

    Attributes:
        name: 缓存实例名称，如果为 None 则自动生成（格式：module.function_name）
        maxsize: 缓存最大容量
        eviction_policy: 缓存淘汰策略
        keygenerator: 缓存键生成器
        value_loader: DataFrame 值加载器，实现三阶段数据处理逻辑
    """

    def __init__(
        self,
        name: str | None = None,
        maxsize: int | None = None,
        eviction_policy: EvictionPolicy | None = None,
        keygenerator: KeyGenerator | None = None,
        value_loader: DataFrameValueLoader | None = None,
        ttl: int | None = None,
    ) -> None:
        """初始化 DataFrame 内存缓存装饰器

        Args:
            name: 缓存实例名称，None 表示使用配置默认值
            maxsize: 缓存最大容量，None 表示使用配置默认值
            eviction_policy: 缓存淘汰策略，None 表示使用配置默认值
            keygenerator: 缓存键生成器，None 表示使用默认生成器
            value_loader: DataFrame 值加载器
            ttl: 缓存存活时间（秒），None 表示使用配置默认值
        """
        # 从配置获取默认值
        props = DataFrameMemoryCacheProperties()

        actual_name = name if name is not None else props.name
        actual_maxsize = maxsize if maxsize is not None else props.maxsize
        actual_eviction = (
            eviction_policy if eviction_policy is not None else props.eviction_policy
        )
        actual_ttl = ttl if ttl is not None else props.ttl

        super().__init__(
            name=actual_name,
            maxsize=actual_maxsize,
            eviction_policy=actual_eviction,
            keygenerator=keygenerator or module_function_key_generator,
            value_loader=value_loader,
            ttl=actual_ttl,
        )

    @override
    def _create_cache(self) -> MemoryCache:
        """创建 MemoryCache 实例

        Returns:
            MemoryCache 实例
        """
        return MemoryCache(
            name=self._name or "",
            maxsize=self._maxsize,
            eviction_policy=self._eviction_policy,
        )


def df_memcached(
    name: Callable[..., Any] | str | None = None,
    maxsize: int | None = None,
    eviction_policy: EvictionPolicy | None = None,
    keygenerator: KeyGenerator | None = None,
    value_loader: DataFrameValueLoader | None = None,
    ttl: int | None = None,
) -> Any:
    """DataFrame 内存缓存装饰器

    支持两种用法：
    1. @df_memcached - 无参数直接装饰函数
    2. @df_memcached(...) - 带参数装饰函数

    Args:
        name: 被装饰的函数（无参模式）或缓存名称（带参模式），None 表示使用配置默认值
        maxsize: 缓存最大容量（仅带参模式有效），None 表示使用配置默认值
        eviction_policy: 缓存淘汰策略（仅带参模式有效），None 表示使用配置默认值
        keygenerator: 缓存键生成器（仅带参模式有效），None 表示使用配置默认值
        value_loader: DataFrame 值加载器（仅带参模式有效）
        ttl: 缓存存活时间（秒）（仅带参模式有效），None 表示使用配置默认值

    Returns:
        装饰器或装饰后的函数

    **重要规范**：
        所有使用 @df_memcached 装饰的函数必须显式声明返回类型注解为 DataFrame，
        否则装饰器无法正确处理返回值的装箱和缓存一致性。
        这是由 Python 动态类型系统的局限性决定的。

    优先级：
        用户传入参数 > 配置数据 > 硬编码默认值

    示例:
        无参数装饰（使用配置默认值）：
        @df_memcached
        def get_data(x: int) -> DataFrame:
            return DataFrame({"x": [x]})

        带参数装饰（覆盖配置值）：
        @df_memcached(name="my_df_cache", maxsize=10, ttl=60)
        def another_data(x: int) -> DataFrame:
            return DataFrame({"x": [x] * 10})
    """
    from pynomad.cache.decorator.keygenerator import (
        module_function_key_generator,
    )

    # 如果直接用作 @df_memcached 装饰函数（第一个参数是可调用的）
    if callable(name):
        func: DecoratorTarget = name
        decorator = DataFrameMemoryDecorator(
            name=None,
            maxsize=maxsize,
            eviction_policy=eviction_policy,
            keygenerator=keygenerator or module_function_key_generator,
            value_loader=value_loader,
            ttl=ttl,
        )
        return decorator(func)

    # 用作 @df_memcached(...) 带参数装饰
    cache_name: str | None = name

    def decorator_inner(func: DecoratorTarget) -> DecoratorTarget:
        decorator = DataFrameMemoryDecorator(
            name=cache_name,
            maxsize=maxsize,
            eviction_policy=eviction_policy,
            keygenerator=keygenerator or module_function_key_generator,
            value_loader=value_loader,
            ttl=ttl,
        )
        return decorator(func)

    return decorator_inner
