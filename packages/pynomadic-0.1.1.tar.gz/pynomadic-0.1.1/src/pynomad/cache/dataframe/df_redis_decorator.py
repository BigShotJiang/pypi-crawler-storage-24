from collections.abc import Callable
from typing import Any, override
from redis import Redis
from redis.connection import ConnectionPool
from pynomad.cache.core.cache_interface import Cache
from pynomad.cache.core.types import (
    DecoratorTarget,
    EvictionPolicy,
    KeyGenerator,
)
from pynomad.cache.dataframe.types import (
    DataFrameValueLoader,
)
from pynomad.cache.dataframe.base_df_decorator import (
    BaseDataFrameDecorator,
)
from pynomad.cache.properties import DataFrameRedisCacheProperties
from pynomad.logsystem.manager import get_logger

logger = get_logger()


class DataFrameRedisDecorator(BaseDataFrameDecorator):
    """DataFrame Redis 缓存装饰器

    通过装饰器的方式为返回 DataFrame 的函数添加缓存功能，使用 Redis 缓存实现。
    支持三阶段数据处理：GET、PUT、EXTRACT。

    Attributes:
        name: 缓存实例名称，如果为 None 则自动生成（格式：module.function_name）
        maxsize: 缓存最大容量
        eviction_policy: 缓存淘汰策略
        keygenerator: 缓存键生成器
        value_loader: DataFrame 值加载器，实现三阶段数据处理逻辑
        redis_client: 自定义 Redis 客户端（优先使用）
        connection_pool: 自定义连接池
        host: Redis 主机地址
        port: Redis 端口
        db: Redis 数据库编号
        password: Redis 密码
        enable_encryption: 是否启用加密（使用 get_machine_key）
        salt: 加密盐值，用于生成机器派生密钥
    """

    def __init__(
        self,
        name: str | None = None,
        maxsize: int | None = None,
        eviction_policy: EvictionPolicy | None = None,
        keygenerator: KeyGenerator | None = None,
        value_loader: DataFrameValueLoader | None = None,
        ttl: int | None = None,
        redis_client: Redis | None = None,
        connection_pool: ConnectionPool | None = None,
        host: str | None = None,
        port: int | None = None,
        db: int | None = None,
        username: str = "",
        password: str | None = None,
        enable_encryption: bool | None = None,
        salt: str | None = None,
    ) -> None:
        """初始化 DataFrame Redis 缓存装饰器

        Args:
            name: 缓存实例名称，None 表示使用配置默认值
            maxsize: 缓存最大容量，None 表示使用配置默认值
            eviction_policy: 缓存淘汰策略，None 表示使用配置默认值
            keygenerator: 缓存键生成器，None 表示使用默认生成器
            value_loader: DataFrame 值加载器
            ttl: 缓存存活时间（秒），None 表示使用配置默认值
            redis_client: 自定义 Redis 客户端（优先使用）
            connection_pool: 自定义连接池
            host: Redis 主机地址，None 表示使用配置默认值
            port: Redis 端口，None 表示使用配置默认值
            db: Redis 数据库编号，None 表示使用配置默认值
            username: Redis 用户名，None 表示使用配置默认值
            password: Redis 密码，None 表示使用配置默认值
            enable_encryption: 是否启用加密，None 表示使用配置默认值
            salt: 加密盐值，None 表示使用配置默认值
        """
        from pynomad.cache.decorator.keygenerator import (
            module_function_key_generator,
        )

        # 从配置获取默认值
        props = DataFrameRedisCacheProperties()

        actual_name = name if name is not None else props.name
        actual_maxsize = maxsize if maxsize is not None else props.maxsize
        actual_eviction = (
            eviction_policy if eviction_policy is not None else props.eviction_policy
        )
        actual_ttl = ttl if ttl is not None else props.ttl
        actual_host = host if host is not None else props.host
        actual_port = port if port is not None else props.port
        actual_db = db if db is not None else props.db
        actual_username = username if username else props.username or ""
        actual_password = password if password is not None else props.password
        actual_enable_encryption = (
            enable_encryption
            if enable_encryption is not None
            else props.enable_encryption
        )
        actual_salt = salt if salt is not None else props.salt

        super().__init__(
            name=actual_name,
            maxsize=actual_maxsize,
            eviction_policy=actual_eviction,
            keygenerator=keygenerator or module_function_key_generator,
            value_loader=value_loader,
            ttl=actual_ttl,
        )

        # Redis 相关配置
        self._redis_client = redis_client
        self._connection_pool = connection_pool
        self._host = actual_host
        self._port = actual_port
        self._db = actual_db
        self._username = actual_username
        self._password = actual_password
        self._enable_encryption = actual_enable_encryption
        self._salt = actual_salt

    @override
    def _create_cache(self) -> Cache:
        """创建 RedisCache 实例

        Returns:
            RedisCache 实例
        """
        # 导入 RedisCache 避免循环导入
        from pynomad.cache.impl.redis_cache import RedisCache

        return RedisCache(
            name=self._name or "",
            maxsize=self._maxsize,
            eviction_policy=self._eviction_policy,
            redis_client=self._redis_client,
            connection_pool=self._connection_pool,
            host=self._host,
            port=self._port,
            db=self._db,
            username=self._username,
            password=self._password,
            enable_encryption=self._enable_encryption,
            salt=self._salt,
        )


def df_rediscached(
    name: Callable[..., Any] | str | None = None,
    maxsize: int | None = None,
    eviction_policy: EvictionPolicy | None = None,
    keygenerator: KeyGenerator | None = None,
    value_loader: DataFrameValueLoader | None = None,
    ttl: int | None = None,
    redis_client: Redis | None = None,
    connection_pool: ConnectionPool | None = None,
    host: str | None = None,
    port: int | None = None,
    db: int | None = None,
    username: str = "",
    password: str | None = None,
    enable_encryption: bool | None = None,
    salt: str | None = None,
) -> Any:
    """DataFrame Redis 缓存装饰器

    支持两种用法：
    1. @df_rediscached - 无参数直接装饰函数
    2. @df_rediscached(...) - 带参数装饰函数

    Args:
        name: 被装饰的函数（无参模式）或缓存名称（带参模式），None 表示使用配置默认值
        maxsize: 缓存最大容量（仅带参模式有效），None 表示使用配置默认值
        eviction_policy: 缓存淘汰策略（仅带参模式有效），None 表示使用配置默认值
        keygenerator: 缓存键生成器（仅带参模式有效），None 表示使用配置默认值
        value_loader: DataFrame 值加载器（仅带参模式有效）
        ttl: 缓存存活时间（秒）（仅带参模式有效），None 表示使用配置默认值
        redis_client: 自定义 Redis 客户端（优先使用）
        connection_pool: 自定义连接池
        host: Redis 主机地址，None 表示使用配置默认值
        port: Redis 端口，None 表示使用配置默认值
        db: Redis 数据库编号，None 表示使用配置默认值
        password: Redis 密码，None 表示使用配置默认值
        enable_encryption: 是否启用加密，None 表示使用配置默认值
        salt: 加密盐值，None 表示使用配置默认值

    Returns:
        装饰器或装饰后的函数

    **重要规范**：
        所有使用 @df_rediscached 装饰的函数必须显式声明返回类型注解为 DataFrame，
        否则装饰器无法正确处理返回值的装箱和缓存一致性。
        这是由 Python 动态类型系统的局限性决定的。

    优先级：
        用户传入参数 > 配置数据 > 硬编码默认值

    示例:
        无参数装饰（使用配置默认值）：
        @df_rediscached
        def get_data(x: int) -> DataFrame:
            return DataFrame({"x": [x]})

        带参数装饰（覆盖配置值）：
        @df_rediscached(name="my_df_cache", maxsize=10, host="localhost", ttl=60)
        def another_data(x: int) -> DataFrame:
            return DataFrame({"x": [x] * 10})

        启用加密：
        @df_rediscached(enable_encryption=True, salt="my_project_v1")
        def secure_data() -> DataFrame:
            return DataFrame({"data": [1, 2, 3]})
    """
    from pynomad.cache.decorator.keygenerator import (
        module_function_key_generator,
    )

    # 如果直接用作 @df_rediscached 装饰函数（第一个参数是可调用的）
    if callable(name):
        func: DecoratorTarget = name
        decorator = DataFrameRedisDecorator(
            name=None,
            maxsize=maxsize,
            eviction_policy=eviction_policy,
            keygenerator=keygenerator or module_function_key_generator,
            value_loader=value_loader,
            ttl=ttl,
            redis_client=redis_client,
            connection_pool=connection_pool,
            host=host,
            port=port,
            db=db,
            username=username,
            password=password,
            enable_encryption=enable_encryption,
            salt=salt,
        )
        return decorator(func)

    # 用作 @df_rediscached(...) 带参数装饰
    cache_name: str | None = name

    def decorator_inner(func: DecoratorTarget) -> DecoratorTarget:
        decorator = DataFrameRedisDecorator(
            name=cache_name,
            maxsize=maxsize,
            eviction_policy=eviction_policy,
            keygenerator=keygenerator or module_function_key_generator,
            value_loader=value_loader,
            ttl=ttl,
            redis_client=redis_client,
            connection_pool=connection_pool,
            host=host,
            port=port,
            db=db,
            username=username,
            password=password,
            enable_encryption=enable_encryption,
            salt=salt,
        )
        return decorator(func)

    return decorator_inner
