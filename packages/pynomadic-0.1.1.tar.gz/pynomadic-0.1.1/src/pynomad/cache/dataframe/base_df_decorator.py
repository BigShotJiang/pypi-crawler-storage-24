from typing import Any, cast, get_type_hints, override

from pandas import DataFrame

from pynomad.cache.core.types import DecoratorTarget, EvictionPolicy, KeyGenerator
from pynomad.cache.decorator.base_decorator import BaseCacheDecorator
from pynomad.cache.dataframe.types import DataFrameValueLoader
from pynomad.logsystem.manager import get_logger
from pynomad.cache.decorator.keygenerator import module_function_key_generator
from pynomad.cache.dataframe.types import DefaultDataFrameValueLoader
from pynomad.result.result import Result, ResultAny
logger = get_logger()


class BaseDataFrameDecorator(BaseCacheDecorator):
    """DataFrame 缓存装饰器基类

    在 BaseCacheDecorator 的基础上扩展 DataFrame 三阶段处理逻辑：
    - GET: 从缓存提取数据
    - PUT: 合并数据并缓存
    - EXTRACT: 提取返回数据

    子类需要实现：
    - _create_cache(): 创建缓存实例（必须实现）

    以下方法有默认实现，子类可选重写：
    - _try_get_from_cache(): GET 阶段实现
    - _extract_dataframe_from_result(): 从函数结果提取 DataFrame
    - _merge_and_cache_data(): PUT 和 EXTRACT 阶段实现

    **重要规范**：
        所有使用本类子类装饰器装饰的函数必须显式声明返回类型注解，
        否则装饰器无法正确处理返回值的装箱和缓存一致性。
        这是由 Python 动态类型系统的局限性决定的。
        例如：
        - @sqlcached 装饰的函数需要声明返回类型为 Result[DataFrame]
        - @df_memcached/@df_pickled/@df_rediscached 装饰的函数需要声明返回类型为 DataFrame
    """

    def __init__(
        self,
        name: str | None = None,
        maxsize: int = 0,
        eviction_policy:EvictionPolicy|None = None,
        keygenerator: KeyGenerator=module_function_key_generator,
        value_loader: DataFrameValueLoader | None = None,
        ttl: int = 0,
    ) -> None:
        """初始化 DataFrame 缓存装饰器

        Args:
            name: 缓存实例名称
            maxsize: 缓存最大容量
            eviction_policy: 缓存淘汰策略
            keygenerator: 缓存键生成器
            value_loader: DataFrame 值加载器
            ttl: 缓存存活时间（秒），0 表示永不过期
        """


        super().__init__(
            name=name,
            maxsize=maxsize,
            eviction_policy=eviction_policy,
            keygenerator=keygenerator,
            ttl=ttl,
        )

        self._value_loader: DataFrameValueLoader = (
            value_loader or DefaultDataFrameValueLoader()
        )
        self._return_type: Any = None

    @override
    def __call__(self, func: DecoratorTarget) -> DecoratorTarget:
        """装饰器调用方法

        Args:
            func: 被装饰的函数

        Returns:
            包装后的函数
        """
        # 保存函数引用用于延迟初始化
        self._func = func
        # 初始化时获取返回值类型并缓存
        self._return_type = self._get_return_type(func)

        from functools import wraps
        from inspect import signature
        from typing import cast

        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            # 获取缓存实例（会自动延迟初始化）
            cache_instance = self.get_cache()

            # 获取实例对象（如果是实例方法或类方法），并填充默认值
            instance_or_class, args_for_key, full_params = self._parse_args(func, args, kwargs)

            # 生成缓存键
            cache_key = self._keygenerator(
                func, instance_or_class, args_for_key, full_params
            )

            # 尝试从缓存获取（GET 阶段）
            cached_data, refresh_params = self._try_get_from_cache(
                func, cache_instance, cache_key, args_for_key, full_params
            )
            if cached_data is not None:
                return cached_data

            # 缓存未命中或不可用，执行函数
            # 如果 GET 阶段返回了刷新参数，使用这些参数调用原方法
            call_kwargs = refresh_params if refresh_params is not None else kwargs
            logger.trace(
                f"缓存未命中或不可用 - 函数: {func.__qualname__}, " +
                f"缓存键: {cache_key}"
            )
            result = func(*args, **call_kwargs)

            # 从函数返回结果中提取 DataFrame
            new_data, original_result = self._extract_dataframe_from_result(
                func, cache_key, result
            )
            if new_data is None:
                return original_result

            # 获取缓存结果用于合并（PUT 阶段）
            cached_result: ResultAny[DataFrame] = cache_instance.get(cache_key)

            # 合并数据并缓存（PUT + EXTRACT 阶段）
            # 使用刷新参数（如果有）来构建 extra_params，但传递原始 kwargs 给 extract
            merge_kwargs = refresh_params if refresh_params is not None else full_params
            final_data = self._merge_and_cache_data(
                func,
                cache_instance,
                cache_key,
                cached_result,
                new_data,
                args_for_key,
                merge_kwargs,
                full_params,  # 原始 kwargs（含默认值），用于 extract 阶段
            )
            if final_data is None:
                return original_result

            # 根据原函数返回类型决定是否需要装箱
            return self._wrap_result_if_needed(final_data)

        # 保留原始函数的签名和类型信息
        wrapper.__signature__ = signature(func)  # type: ignore[attr-defined]
        # 保留类型注解
        if hasattr(func, '__annotations__'):
            wrapper.__annotations__ = func.__annotations__

        # 类型转换以保留类型提示
        return cast(DecoratorTarget, wrapper)

    def _get_return_type(self, func: DecoratorTarget) -> Any:
        """获取被装饰函数的返回值类型

        Args:
            func: 被装饰的函数

        Returns:
            返回值类型注解

        Raises:
            TypeError: 如果函数没有显式声明返回类型注解
        """
        try:
            type_hints = get_type_hints(func)
            return_type = type_hints.get("return")

            if return_type is None:
                raise TypeError(
                    f"被装饰函数 {func.__qualname__} 必须显式声明返回类型注解。\n"
                    f"例如：\n"
                    f"  - @sqlcached 装饰的函数需要声明返回类型为 'Result[DataFrame]'\n"
                    f"  - @df_memcached/@df_pickled/@df_rediscached 装饰的函数需要声明返回类型为 'DataFrame'"
                )

            return return_type
        except Exception as e:
            if isinstance(e, TypeError):
                raise  # 重新抛出我们自己的 TypeError
            raise TypeError(
                f"获取函数 {func.__qualname__} 的返回值类型失败: {e}"
            )

    def _wrap_result_if_needed(self, data: DataFrame) -> Any:
        """根据原函数返回类型，包装返回值

        Args:
            data: 要返回的 DataFrame 数据

        Returns:
            如果原函数返回 Result 类型，返回装箱后的 Result，否则直接返回 data
        """
        # 检查返回类型是否为 Result 或 ResultAny
        return_type_str: str = str(self._return_type)

        # 简单的字符串匹配判断
        is_result_type: bool = (
            "Result" in return_type_str
            and "DataFrame" in return_type_str
        )

        if is_result_type:
            # 需要装箱成 Result
            return Result.success(data) # type: ignore
        return data

    def _try_get_from_cache(
        self,
        func: DecoratorTarget,
        cache_instance: Any,
        cache_key: str,
        args_for_key: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> tuple[Any | None, dict[str, Any] | None]:
        """尝试从缓存获取数据（GET 阶段）

        默认实现，子类可选重写。

        Args:
            func: 被装饰的函数
            cache_instance: 缓存实例
            cache_key: 缓存键
            args_for_key: 用于生成键的参数
            kwargs: 关键字参数

        Returns:
            (cached_data, refresh_params)
            - cached_data: 缓存命中且 GET 阶段成功则返回数据，否则返回 None
            - refresh_params: 缓存不可用时的刷新参数，否则返回 None
        """
        cached_result: ResultAny[DataFrame] = cache_instance.get(cache_key)
        cache_hit = (
            cached_result.is_success() and cached_result.data is not None
        )

        # 如果缓存未命中，使用空 DataFrame 调用 ValueLoader.get()，让它有机会返回刷新参数
        if not cache_hit:
            get_result = self._value_loader.get(
                DataFrame(), {}, args_for_key, kwargs
            )
            if get_result.is_success():
                # 不应该成功，返回数据为空
                return (None, None)
            # 返回刷新参数
            return (None, get_result.data) # type: ignore

        logger.trace(
            f"缓存命中 - 函数: {func.__qualname__}, "
            + f"缓存键: {cache_key}, "
            + f"返回类型: {self._return_type}"
        )

        # 执行 GET 阶段
        cache_data: Any = cached_result.data

        # 如果缓存中存储的不是 DataFrame，可能是普通缓存数据，直接返回
        if not isinstance(cache_data, DataFrame):
            logger.warn(
                f"缓存数据类型非 DataFrame - 函数: {func.__qualname__}, "
                + f"缓存键: {cache_key}, "
                + f"实际类型: {type(cache_data)}"
            )
            # 需要根据原函数返回类型决定是否装箱
            return (self._wrap_result_if_needed(cache_data), None) # type: ignore

        # 从缓存元数据中获取 extra_params
        meta = cache_instance.get_meta(cache_key)
        extra_params: dict[str, Any] = {}
        if meta is not None and meta.extra_params is not None:
            extra_params = meta.extra_params

        get_result = self._value_loader.get(
            cache_data, extra_params, args_for_key, kwargs
        )

        if get_result.is_success():
            # 缓存可用，根据原函数返回类型包装后返回
            logger.trace(
                f"GET 阶段成功 - 函数: {func.__qualname__}, "
                + f"缓存键: {cache_key}"
            )
            return (self._wrap_result_if_needed(get_result.data), None) # type: ignore

        # 缓存不可用，需要刷新数据
        logger.trace(
            f"GET 阶段失败 - 函数: {func.__qualname__}, "
            + f"缓存键: {cache_key}, 原因: {get_result.msg}"
        )
        # 返回刷新参数
        return (None, get_result.data) # type: ignore

    def _extract_dataframe_from_result(
        self,
        func: DecoratorTarget,
        cache_key: str,
        result: Any,
    ) -> tuple[DataFrame | None, Any]:
        """从函数返回结果中提取 DataFrame

        默认实现，子类可选重写。

        Args:
            func: 被装饰的函数
            cache_key: 缓存键
            result: 函数返回结果

        Returns:
            (DataFrame, original_result)
            - DataFrame: 提取到的 DataFrame，如果无法提取则为 None
            - original_result: 原始返回结果，用于错误时返回
        """
        if isinstance(result, DataFrame):
            # 直接返回 DataFrame
            return result, result

        if isinstance(result, Result):
            result_obj = cast(ResultAny[object], result)
            # 调用方法返回结果错误,直接返回错误结果
            if result_obj.is_error():
                logger.error(
                    f"被装饰方法返回错误 - 函数: {func.__qualname__}, "
                    + f"缓存键: {cache_key}, "
                    + f"错误信息: {result_obj.msg}"
                )
                return None, result_obj

            # Result 类型，解包后检查 data 是否为 DataFrame
            result_data = result_obj.data
            if isinstance(result_data, DataFrame):
                return result_data, result_obj

            msg = f"Result.data 不是 DataFrame 类型，实际类型: {type(result_data)}"
            logger.error(msg)
            return None, result_obj

        # 不支持的类型
        msg = f"不支持的返回值类型: {type(result)}，期望 DataFrame 或 Result[DataFrame]"
        logger.error(msg)
        return None, result

    def _merge_and_cache_data(
        self,
        func: DecoratorTarget,
        cache_instance: Any,
        cache_key: str,
        cached_result: Any,
        new_data: DataFrame,
        args_for_key: tuple[Any, ...],
        merge_kwargs: dict[str, Any],
        original_kwargs: dict[str, Any],
    ) -> DataFrame | None:
        """合并数据并缓存（PUT + EXTRACT 阶段）

        默认实现，子类可选重写。

        Args:
            func: 被装饰的函数
            cache_instance: 缓存实例
            cache_key: 缓存键
            cached_result: 缓存结果
            new_data: 新获取的数据
            args_for_key: 用于生成键的参数
            merge_kwargs: 用于构建 extra_params 的关键字参数（可能是刷新参数）
            original_kwargs: 原始关键字参数（用于 extract 阶段）

        Returns:
            合并后缓存的数据，如果失败则返回 None
        """
        # 构建扩展参数（使用 merge_kwargs，用于下次缓存命中时的参数比较）
        extra_params: dict[str, Any] = {
            "args": args_for_key,
            "kwargs": merge_kwargs,
        }

        # PUT 阶段：合并数据
        cache_data_for_put: DataFrame = (
            cached_result.data
            if cached_result.data is not None
            else DataFrame()
        )
        put_result: ResultAny[DataFrame] = self._value_loader.put(
            cache_data_for_put, new_data, extra_params, args_for_key, merge_kwargs
        )

        if put_result.is_error():
            logger.error(
                f"PUT 阶段失败 - 函数: {func.__qualname__}, "
                + f"缓存键: {cache_key}, 原因: {put_result.msg}"
            )
            return None

        # 缓存合并后的数据
        put_data = put_result.data
        if put_data is None:
            logger.error(
                f"PUT 阶段返回数据为空 - 函数: {func.__qualname__}, "
                + f"缓存键: {cache_key}"
            )
            return None

        _ = cache_instance.put(cache_key, put_data, ttl=self._ttl, extra_params=extra_params)

        # EXTRACT 阶段：提取返回数据（使用原始 kwargs 来过滤数据）
        extract_result: ResultAny[DataFrame] = self._value_loader.extract(
            put_data, extra_params, args_for_key, original_kwargs
        )

        if extract_result.is_error():
            logger.error(
                f"EXTRACT 阶段失败 - 函数: {func.__qualname__}, "
                + f"缓存键: {cache_key}, 原因: {extract_result.msg}"
            )
            return None

        logger.trace(
            f"缓存已更新 - 函数: {func.__qualname__}, " + f"缓存键: {cache_key}"
        )

        extract_data = extract_result.data
        if extract_data is None:
            return None

        return extract_data
