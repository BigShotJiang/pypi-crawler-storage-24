from enum import Enum, auto
from typing import Any, Protocol

from pandas import DataFrame

from pynomad.common.exceptions import NeedsRefreshException
from pynomad.result.result import Result, ResultAny


class CacheStage(Enum):
    """缓存阶段枚举

    定义 DataFrame 缓存装饰器的三个处理阶段：
    - GET: 从缓存提取数据
    - PUT: 合并数据并缓存
    - EXTRACT: 提取返回数据
    """

    GET = auto()  # 从缓存提取
    PUT = auto()  # 合并数据并缓存
    EXTRACT = auto()  # 提取返回数据


class DataFrameValueLoader(Protocol):
    """DataFrame 值加载器协议

    用于 DataFrame 缓存装饰器的三阶段数据处理：
    1. GET: 从缓存中提取数据，失败时抛出 NeedsRefreshException
    2. PUT: 合并缓存数据和新数据
    3. EXTRACT: 从合并后的数据中提取最终返回数据

    注意：缓存的数据和返回的数据可能不同
    """

    def get(
        self,
        cache_data: DataFrame,
        extra_params: dict[str, Any],
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> Result[DataFrame | dict[str, Any]]:
        """GET 阶段：从缓存提取数据

        Args:
            cache_data: 从缓存获取的 DataFrame
            extra_params: 装饰器传递的额外参数
            args: 被装饰方法的位置参数
            kwargs: 被装饰方法的关键字参数

        Returns:
            缓存可用返回 DataFrame 或 dict[str, Any]
            缓存不可用返回 client_error（携带 NeedsRefreshException）
        """
        ...

    def put(
        self,
        cache_data: DataFrame,
        new_data: DataFrame,
        extra_params: dict[str, Any],
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> ResultAny[DataFrame]:
        """PUT 阶段：合并缓存数据和新数据

        Args:
            cache_data: 原缓存中的 DataFrame
            new_data: 新获取的 DataFrame
            extra_params: 装饰器传递的额外参数
            args: 被装饰方法的位置参数
            kwargs: 被装饰方法的关键字参数

        Returns:
            合并后的需要缓存的 DataFrame
        """
        ...

    def extract(
        self,
        merged_data: DataFrame,
        extra_params: dict[str, Any],
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> ResultAny[DataFrame]:
        """EXTRACT 阶段：从合并数据中提取返回数据

        Args:
            merged_data: 合并后的 DataFrame（将被缓存）
            extra_params: 装饰器传递的额外参数
            args: 被装饰方法的位置参数
            kwargs: 被装饰方法的关键字参数

        Returns:
            最终返回给调用方的 DataFrame（可能与 merged_data 不同）
        """
        ...


class DefaultDataFrameValueLoader:
    """默认的 DataFrame 值加载器

    提供最简单的缓存逻辑：
    - GET: 参数相同返回缓存，不同抛出 NeedsRefreshException
    - PUT: 直接返回新数据（不合并）
    - EXTRACT: 直接返回传入数据

    适用于不需要复杂合并逻辑的场景。
    """

    def get(
        self,
        cache_data: DataFrame,
        extra_params: dict[str, Any],
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> Result[DataFrame | dict[str, Any]]:
        """GET 阶段：比较参数，相同则返回缓存

        Args:
            cache_data: 从缓存获取的 DataFrame
            extra_params: 装饰器传递的额外参数
            args: 被装饰方法的位置参数
            kwargs: 被装饰方法的关键字参数

        Returns:
            参数相同返回缓存的 DataFrame
            参数不同返回 client_error
        """
        # 获取上次缓存的参数
        last_args: tuple[Any, ...] = ()
        last_kwargs: dict[str, Any] = {}
        if extra_params and "args" in extra_params:
            # extra_params 中的 args 是 list 类型（JSON 反序列化），需要转换为 tuple
            last_args = tuple(extra_params["args"])
        if extra_params and "kwargs" in extra_params:
            last_kwargs = extra_params["kwargs"]

        # 比较参数是否相同
        if last_args == args and last_kwargs == kwargs:
            # 参数相同，返回缓存数据
            return Result[DataFrame | dict[str, Any]].success(data=cache_data)

        # 参数不同，返回客户端错误
        return Result[DataFrame | dict[str, Any]].client_error(
            exception=NeedsRefreshException(message="参数已变化，需要刷新数据"),
            data={"args": args, "kwargs": kwargs},
        )

    def put(
        self,
        cache_data: DataFrame,
        new_data: DataFrame,
        extra_params: dict[str, Any],
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> ResultAny[DataFrame]:
        """PUT 阶段：直接返回新数据

        Args:
            _cache_data: 原缓存中的 DataFrame（未使用）
            new_data: 新获取的 DataFrame
            _extra_params: 装饰器传递的额外参数（未使用）
            _args: 被装饰方法的位置参数（未使用）
            _kwargs: 被装饰方法的关键字参数（未使用）

        Returns:
            新获取的 DataFrame（直接覆盖缓存）
        """
        _ = cache_data
        _ = extra_params
        _ = args
        _ = kwargs
        return Result[DataFrame].success(data=new_data)

    def extract(
        self,
        merged_data: DataFrame,
        extra_params: dict[str, Any],
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> ResultAny[DataFrame]:
        """EXTRACT 阶段：直接返回传入数据

        Args:
            merged_data: 合并后的 DataFrame（将被缓存）
            _extra_params: 装饰器传递的额外参数（未使用）
            _args: 被装饰方法的位置参数（未使用）
            _kwargs: 被装饰方法的关键字参数（未使用）

        Returns:
            直接返回传入的 DataFrame
        """
        _ = extra_params
        _ = args
        _ = kwargs
        return Result[DataFrame].success(data=merged_data)
