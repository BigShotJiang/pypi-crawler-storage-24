"""缓存注册器

提供缓存类的注册和创建功能，支持动态注册新的缓存类型。
"""

from collections.abc import Callable
from typing import Any


class CacheRegistry:
    """缓存注册器

    用于管理不同类型缓存的注册和创建。
    缓存类通过类装饰器 `@register_cache` 注册到注册器中。
    """

    # 存储缓存类型代码到缓存类的映射
    _registry: dict[str, type[Any]] = {}

    @classmethod
    def register(cls, code: str) -> Callable[[type[Any]], type[Any]]:
        """注册缓存类

        Args:
            code: 缓存类型代码（如 "memory", "pickle", "redis", "sql"）

        Returns:
            类装饰器

        Example:
            ```python
            @CacheRegistry.register("memory")
            class MemoryCache(Cache):
                pass
            ```
        """

        def decorator(cache_class: type[Any]) -> type[Any]:
            cls._registry[code] = cache_class
            return cache_class

        return decorator

    @classmethod
    def create(cls, code: str, **kwargs: Any) -> Any:
        """创建缓存实例

        Args:
            code: 缓存类型代码
            **kwargs: 传递给缓存类构造函数的参数

        Returns:
            缓存实例

        Raises:
            ValueError: 如果缓存类型未注册
        """
        cache_class = cls._registry.get(code)
        if cache_class is None:
            msg = f"不支持的缓存类型: {code}"
            raise ValueError(msg)

        return cache_class(**kwargs)

    @classmethod
    def is_registered(cls, code: str) -> bool:
        """检查缓存类型是否已注册

        Args:
            code: 缓存类型代码

        Returns:
            是否已注册
        """
        return code in cls._registry

    @classmethod
    def get_registered_codes(cls) -> list[str]:
        """获取所有已注册的缓存类型代码

        Returns:
            已注册的缓存类型代码列表
        """
        return list(cls._registry.keys())
