import time
from typing import cast


class MetaInfo:
    create_at: float = time.time()  # 创建时间
    last_update_at: float = time.time()  # 最后更新时间
    last_accessed_at: float = 0  # 最后访问时间
    access_count: int = 0  # 被访问的次数
    time_to_live: float = 0  # 缓存存活时间,单位秒

    # 扩展信息：存储额外的元数据信息（如上次请求的参数、自定义字段等）
    extra_params: dict[str, object] | None = None

    def to_dict(self) -> dict[str, object]:
        """转换为字典

        Returns:
            包含所有元数据的字典
        """
        return {
            "create_at": self.create_at,
            "last_update_at": self.last_update_at,
            "last_accessed_at": self.last_accessed_at,
            "access_count": self.access_count,
            "time_to_live": self.time_to_live,
            "extra_params": self.extra_params,
        }

    @classmethod
    def from_dict(cls, data: dict[str, object]) -> "MetaInfo":
        """从字典创建 MetaInfo

        Args:
            data: 包含元数据的字典

        Returns:
            MetaInfo 实例
        """
        meta = cls()
        create_at = data.get("create_at", 0)
        create_at = create_at if isinstance(create_at, int) else 0
        meta.create_at = create_at

        last_update_at = data.get("last_update_at", 0)
        last_update_at = (
            last_update_at if isinstance(last_update_at, int) else 0
        )
        meta.last_update_at = last_update_at

        last_accessed_at = data.get("last_accessed_at", 0)
        last_accessed_at = (
            last_accessed_at if isinstance(last_accessed_at, int) else 0
        )
        meta.last_accessed_at = last_accessed_at

        access_count = data.get("access_count", 0)
        access_count = access_count if isinstance(access_count, int) else 0
        meta.access_count = access_count

        time_to_live = data.get("time_to_live", 0)
        time_to_live = time_to_live if isinstance(time_to_live, int) else 0
        meta.time_to_live = time_to_live

        extra_params = data.get("extra_params", None)
        extra_params = (
            cast(dict[str, object], extra_params)
            if isinstance(extra_params, dict)
            else None
        )
        meta.extra_params = extra_params

        return meta
