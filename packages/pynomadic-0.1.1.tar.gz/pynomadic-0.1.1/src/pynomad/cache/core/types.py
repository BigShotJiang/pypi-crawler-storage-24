from typing import Any, Literal

from collections.abc import Callable


type DecoratorTarget = Callable[..., Any]
"""
DecoratorTarget: 装饰器目标函数类型
- 参数: 任意参数
- 返回值: 任意类型
- 用途：可被装饰的函数类型
"""
type ValueLoader[T] = Callable[[str], T]
"""
ValueLoader: 缓存加载器类型
- 参数 str: 缓存键 (key)
- 返回值 T: 要缓存的值
- 用途：当缓存不存在时，通过此加载器获取值并自动缓存
"""
type KeyGenerator = Callable[
    [Callable[..., Any], Any | None, tuple[Any, ...], dict[str, Any]], str
]
"""
KeyGenerator: 缓存键生成器类型
- 参数 Callable[..., Any]: 被装饰的函数对象
- 参数 Any | None: self (实例方法)、cls (类方法) 或 None (普通函数)
- 参数 tuple[Any, ...]: 函数的位置参数 (args，不包含 self/cls)
- 参数 dict[str, Any]: 函数的关键字参数 (kwargs)
- 返回值 str: 生成的缓存键
- 用途：自定义缓存键的生成逻辑

示例:
    >>> def default_key_generator(
    ...     func: Callable[..., Any],
    ...     instance_or_class: Any | None,
    ...     args: tuple[Any, ...],
    ...     kwargs: dict[str, Any],
    ... ) -> str:
    ...     parts: list[str] = []
    ...     # 模块名
    ...     if hasattr(func, "__module__") and func.__module__:
    ...         parts.append(func.__module__)
    ...     # 类名 (如果是实例方法或类方法)
    ...     if instance_or_class is not None:
    ...         class_name: str = ""
    ...         if hasattr(instance_or_class, "__class__"):
    ...             class_name = instance_or_class.__class__.__name__
    ...         elif hasattr(instance_or_class, "__name__"):
    ...             class_name = instance_or_class.__name__
    ...         if class_name:
    ...             parts.append(class_name)
    ...     # 函数名
    ...     if hasattr(func, "__name__"):
    ...         parts.append(func.__name__)
    ...     # 参数
    ...     if args or kwargs:
    ...         args_str: str = f"args={args}" if args else ""
    ...         kwargs_str: str = f"kwargs={kwargs}" if kwargs else ""
    ...         params: str = ":".join(filter(None, [args_str, kwargs_str]))
    ...         parts.append(params)
    ...     return ".".join(parts)
"""
type EvictionPolicy = Literal["lru", "lfu", "fifo", "rr", "mru", "none"]
"""
EvictionPolicy: 缓存淘汰策略类型
- "lru" (Least Recently Used): 最近最少使用，移除最长时间未被访问的条目
- "lfu" (Least Frequently Used): 最少频率使用，移除访问频率最低的条目
- "fifo" (First In First Out): 先进先出，移除最早添加的条目
- "rr" (Random Replacement): 随机替换，随机选择一个条目移除
- "mru" (Most Recently Used): 最近最多使用，移除最近被访问的条目
- "none": 不淘汰，缓存满后不再添加新条目或报错
- 用途：定义缓存满了时的淘汰策略
"""
