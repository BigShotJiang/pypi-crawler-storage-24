"""Result 装饰器模块

本模块提供了自动包装返回值的装饰器，支持：
- 自动捕获异常并转换为 Result
- 自动将普通返回值包装为 Result.success()
- 支持类装饰器和方法装饰器
- 支持多种返回格式（result、dict、json）
- 支持异常分类自动识别

Examples:
    >>> # 方法装饰器
    >>> @result(exception_category="client")
    >>> def get_user(user_id: int) -> dict:
    ...     return {"id": user_id, "name": "John"}
    >>> result = get_user(1)
    >>> print(result.is_success())
    True

    >>> # 类装饰器
    >>> @result(exception_category="server")
    >>> class UserService:
    ...     def get_user(self, user_id: int) -> dict:
    ...         return {"id": user_id}

    >>> # 排除特定方法
    >>> @result(exception_category="server")
    >>> class UserService:
    ...     @ignore_result
    ...     def get_raw_data(self) -> dict:
    ...         return {"key": "value"}
"""

from collections.abc import Callable
from functools import wraps
from typing import Any, cast
from inspect import ismethod, isfunction, isclass

from pynomad.result.result import Result, StatusCategory
from pynomad.common.exceptions import (
    ClientException,
    NetworkException,
    ServerException,
    ThirdPartyException,
)




def _get_exception_category(
    exception: Exception,
    exception_category: str,
) -> StatusCategory:
    """根据异常类型或配置获取异常分类

    Args:
        exception: 异常对象
        exception_category: 配置的异常分类（auto | client | network | server | third_party | unknown）

    Returns:
        StatusCategory: 对应的状态分类
    """
    if exception_category != "auto":
        category_map: dict[str, StatusCategory] = {
            "client": StatusCategory.CLIENT_ERROR,
            "network": StatusCategory.NETWORK_ERROR,
            "server": StatusCategory.SERVER_ERROR,
            "third_party": StatusCategory.THIRD_PARTY_ERROR,
            "unknown": StatusCategory.UNKNOWN,
        }
        return category_map.get(exception_category, StatusCategory.UNKNOWN)

    # 自动识别异常类型
    if isinstance(exception, ClientException):
        return StatusCategory.CLIENT_ERROR
    if isinstance(exception, NetworkException):
        return StatusCategory.NETWORK_ERROR
    if isinstance(exception, ServerException):
        return StatusCategory.SERVER_ERROR
    if isinstance(exception, ThirdPartyException):
        return StatusCategory.THIRD_PARTY_ERROR
    return StatusCategory.UNKNOWN


def _convert_return_value(
    value: Result[Any],
    return_type: str,
) -> Any:
    """根据配置转换返回值

    Args:
        value: Result 对象
        return_type: 返回类型配置（result | dict | json）

    Returns:
        Any: 转换后的返回值
    """
    if return_type == "result":
        return value

    if return_type == "dict":
        return value.to_dict()

    if return_type == "json":
        return value.to_json()

    return value


def result(
    return_type: str = "result",
    exception_category: str = "auto",
    handle_exception: bool = True,
) -> Callable[..., Any]:
    """Result 装饰器，自动包装返回值

    Args:
        return_type: 返回类型（result | dict | json）
            - result: 返回 Result 对象（默认）
            - dict: 返回字典格式
            - json: 返回 JSON 字符串
        exception_category: 异常分类（auto | client | network | server | third_party | unknown）
            - auto: 根据异常类型自动识别（默认）
            - client: 客户端错误
            - network: 网络错误
            - server: 服务端错误
            - third_party: 第三方服务错误
            - unknown: 未知错误
        handle_exception: 是否自动捕获异常（默认为 True）

    Returns:
        装饰器函数

    Examples:
        >>> # 方法装饰器 - 返回 Result
        >>> @result()
        >>> def get_user(user_id: int) -> dict:
        ...     return {"id": user_id, "name": "John"}
        >>> result = get_user(1)
        >>> print(result.is_success())
        True

        >>> # 方法装饰器 - 返回 dict
        >>> @result(return_type="dict")
        >>> def get_user_dict(user_id: int) -> dict:
        ...     return {"id": user_id, "name": "John"}
        >>> data = get_user_dict(1)
        >>> print(data["code"])
        10000000

        >>> # 类装饰器 - 只作用于公共方法
        >>> @result(exception_category="server")
        >>> class UserService:
        ...     def get_user(self, user_id: int) -> dict:
        ...         return {"id": user_id}
    """

    def decorator(fn_or_class: Any) -> Any:
        # 判断是装饰类还是函数/方法
        if isclass(fn_or_class):
            return _decorate_class(
                fn_or_class,
                return_type=return_type,
                exception_category=exception_category,
                handle_exception=handle_exception,
            )

        # 装饰函数或方法
        return _decorate_function(
            fn_or_class,
            return_type=return_type,
            exception_category=exception_category,
            handle_exception=handle_exception,
        )

    return decorator


def _decorate_function[T](
    fn: Callable[..., T],
    return_type: str,
    exception_category: str,
    handle_exception: bool,
) -> Callable[..., Any]:
    """装饰函数或方法

    Args:
        fn: 要装饰的函数
        return_type: 返回类型
        exception_category: 异常分类
        handle_exception: 是否自动捕获异常

    Returns:
        装饰后的函数
    """
    # 检查是否被 ignore_result 标记
    if getattr(fn, "_ignore_result", False):
        return fn

    @wraps(fn)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        if not handle_exception:
            # 不捕获异常，直接执行
            value: Any = fn(*args, **kwargs)
        else:
            try:
                value: Any = fn(*args, **kwargs)
            except Exception as e:
                # 捕获异常，转换为 Result
                category: StatusCategory = _get_exception_category(
                    e, exception_category
                )
                error_result: Result[None] = Result[None](
                    data=None, category=category, exception=e
                )
                return _convert_return_value(error_result, return_type)

        # 处理返回值
        if isinstance(value, Result):
            # 已经是 Result，直接返回
            result_value: Result[Any] = cast(Result[Any], value)
            return _convert_return_value(result_value, return_type)

        # 普通返回值，包装为 success
        success_result: Result[T] = Result[T].success(value)
        return _convert_return_value(success_result, return_type)

    return wrapper


def _decorate_class(
    cls: type,
    return_type: str,
    exception_category: str,
    handle_exception: bool,
) -> type:
    """装饰类，只作用于公共方法

    Args:
        cls: 要装饰的类
        return_type: 返回类型
        exception_category: 异常分类
        handle_exception: 是否自动捕获异常

    Returns:
        装饰后的类
    """
    # 遍历类的所有属性
    for name in dir(cls):
        # 跳过私有方法
        if name.startswith("_"):
            continue

        # 获取属性
        attr: Any = getattr(cls, name)

        # 只装饰方法（排除类和静态属性）
        if ismethod(attr) or isfunction(attr):
            # 检查是否被 ignore_result 标记
            if getattr(attr, "_ignore_result", False):
                continue

            # 装饰方法
            decorated_attr: Callable[..., Any] = _decorate_function(
                attr,
                return_type=return_type,
                exception_category=exception_category,
                handle_exception=handle_exception,
            )
            setattr(cls, name, decorated_attr)

    return cls


def ignore_result[T](
    fn: Callable[..., T],
) -> Callable[..., T]:
    """标记方法不被 @result 装饰器包装

    主要用于类装饰器场景，排除特定方法。

    Args:
        fn: 要标记的函数或方法

    Returns:
        原始函数（添加了 _ignore_result 标记）

    Examples:
        >>> @result(exception_category="server")
        >>> class UserService:
        ...     def get_user(self, user_id: int) -> dict:
        ...         # 会被装饰
        ...         return {"id": user_id}
        ...
        ...     @ignore_result
        ...     def get_raw_data(self) -> dict:
        ...         # 不会被装饰
        ...         return {"key": "value"}
    """
    setattr(fn, "_ignore_result", True)
    return fn


# 便捷装饰器
def client_result(
    return_type: str = "result",
    handle_exception: bool = True,
) -> Callable[..., Any]:
    """客户端错误便捷装饰器

    等同于 @result(exception_category="client")

    Args:
        return_type: 返回类型
        handle_exception: 是否自动捕获异常

    Returns:
        装饰器函数
    """
    return result(
        return_type=return_type,
        exception_category="client",
        handle_exception=handle_exception,
    )


def network_result(
    return_type: str = "result",
    handle_exception: bool = True,
) -> Callable[..., Any]:
    """网络错误便捷装饰器

    等同于 @result(exception_category="network")

    Args:
        return_type: 返回类型
        handle_exception: 是否自动捕获异常

    Returns:
        装饰器函数
    """
    return result(
        return_type=return_type,
        exception_category="network",
        handle_exception=handle_exception,
    )


def server_result(
    return_type: str = "result",
    handle_exception: bool = True,
) -> Callable[..., Any]:
    """服务端错误便捷装饰器

    等同于 @result(exception_category="server")

    Args:
        return_type: 返回类型
        handle_exception: 是否自动捕获异常

    Returns:
        装饰器函数
    """
    return result(
        return_type=return_type,
        exception_category="server",
        handle_exception=handle_exception,
    )


def third_party_result(
    return_type: str = "result",
    handle_exception: bool = True,
) -> Callable[..., Any]:
    """第三方服务错误便捷装饰器

    等同于 @result(exception_category="third_party")

    Args:
        return_type: 返回类型
        handle_exception: 是否自动捕获异常

    Returns:
        装饰器函数
    """
    return result(
        return_type=return_type,
        exception_category="third_party",
        handle_exception=handle_exception,
    )


def json_result(
    exception_category: str = "auto",
    handle_exception: bool = True,
) -> Callable[..., Any]:
    """JSON 返回类型便捷装饰器

    等同于 @result(return_type="json")

    Args:
        exception_category: 异常分类
        handle_exception: 是否自动捕获异常

    Returns:
        装饰器函数
    """
    return result(
        return_type="json",
        exception_category=exception_category,
        handle_exception=handle_exception,
    )


def dict_result(
    exception_category: str = "auto",
    handle_exception: bool = True,
) -> Callable[..., Any]:
    """字典返回类型便捷装饰器

    等同于 @result(return_type="dict")

    Args:
        exception_category: 异常分类
        handle_exception: 是否自动捕获异常

    Returns:
        装饰器函数
    """
    return result(
        return_type="dict",
        exception_category=exception_category,
        handle_exception=handle_exception,
    )
