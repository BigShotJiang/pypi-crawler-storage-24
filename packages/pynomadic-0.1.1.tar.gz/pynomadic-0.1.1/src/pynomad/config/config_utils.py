"""配置工具函数模块

提供配置处理相关的工具函数。
"""

from collections.abc import Callable
from dataclasses import Field
import os
from pathlib import Path
import re
import sys
from typing import Any, cast

from pynomad.common import strings
from pynomad.common.types import AnyDict
from pynomad.config.auto.field_info import FieldInfo, is_field_info
from pynomad.common.environment import environ


type Converter = Callable[[object], object] | None
type TargetType = type | str | object


def parse_value(value: str) -> Any:
    """解析配置值，支持多种格式转换

    当前支持：
    - 逗号分隔的列表：按逗号分割并转换每个元素
    - 基本类型：自动转换为 int、float、bool、str

    Args:
        value: 字符串值

    Returns:
        解析后的值：支持列表或基本类型

    Example:
        >>> parse_value("default,test,dev")
        ["default", "test", "dev"]
        >>> parse_value("42,true,3.14")
        [42, True, 3.14]
        >>> parse_value("localhost")
        "localhost"
    """
    if "," not in value:
        return strings.convert(value)

    items = [
        strings.convert(item.strip())
        for item in value.split(",")
        if item.strip()
    ]

    if len(items) == 1:
        return items[0]

    return items


def get_custom_converter[T](f: Field[T]) -> Converter:
    """获取自定义数据转换器

    从 dataclass Field 中提取自定义转换器，支持多种使用方式：
    - 直接使用 ConfigField 作为 default
    - 使用 default_factory 返回 ConfigField
    - 使用 Annotated[Type, ConfigField(...)]

    Args:
        f: dataclass Field 对象

    Returns:
        Converter | None: 自定义转换器函数，不存在则返回 None
    """
    custom_converter = None

    # 检查是否使用 Annotated（Python 3.9+）

    if sys.version_info >= (3, 9):

        attr_type: type[T] | str | object = f.type
        # 检查是否为 Annotated 类型
        if hasattr(attr_type, "__metadata__"):
            # 从 Annotated 的 metadata 中查找 FieldInfo
            metadatas: list[object] = getattr(attr_type, "__metadata__")
            for metadata in metadatas:
                if isinstance(metadata, FieldInfo):
                    custom_converter = metadata.converter
                    break

    # 传统方式：检查 default 和 default_factory
    if custom_converter is None:
        if is_field_info(f.default):
            custom_converter = getattr(f.default, "converter")
        elif callable(f.default_factory):
            try:
                result = f.default_factory()
                if is_field_info(result):
                    custom_converter = getattr(result, "converter")
            except Exception:
                pass

    return custom_converter


def resolve_nested_value(config_dict: AnyDict, key_path: str) -> object | None:
    """从嵌套字典中解析值

    Args:
        config_dict: 配置字典
        key_path: 键路径，如 "database.host" 或 "pynomad.logging"

    Returns:
        object | None: 找到的值，未找到返回 None

    Examples:
        >>> config_dict = {"database": {"host": "localhost"}}
        >>> resolve_nested_value(config_dict, "database.host")
        'localhost'
        >>> config_dict = {"pynomad.logging": "trace"}
        >>> resolve_nested_value(config_dict, "pynomad.logging")
        'trace'
        >>> config_dict = {"level": {"root": "debug", "pynomad.logging": "trace"}}
        >>> resolve_nested_value(config_dict, "level.pynomad.logging")
        'trace'

    Note:
        解析策略:
        1. 优先尝试嵌套路径查找（如 "database.host" -> config_dict["database"]["host"]）
        2. 如果嵌套查找失败，尝试直接键名查找（如 "pynomad.logging" -> config_dict["pynomad.logging"]）
        3. 在每层遍历时，优先检查剩余路径的完整键名是否存在
    """
    # 首先尝试按嵌套路径逐层查找（适用于大多数配置格式）
    keys = key_path.split(".")
    value: object | dict[Any, Any] = config_dict

    for i, key in enumerate(keys):
        if isinstance(value, dict):
            # 检查是否存在剩余路径的完整键名（如 "pynomad.logging"）
            remaining_keys = ".".join(keys[i:])
            if remaining_keys in value:
                return value[remaining_keys]  # type: ignore
            # 否则继续嵌套查找
            if key in value:
                value = cast(object, value[key])
            else:
                # 嵌套查找失败，尝试顶层直接键名查找
                if key_path in config_dict:
                    return config_dict[key_path]
                return None
        else:
            # 值不是字典，无法继续嵌套查找
            # 尝试顶层直接键名查找
            if key_path in config_dict:
                return config_dict[key_path]
            return None

    return value


def unwrap_annotated(t: TargetType) -> type | str | object:
    """解包 Annotated 类型，获取实际的类型

    Args:
        t: 可能包含 Annotated 的类型

    Returns:
        type | str | object: 解包后的实际类型
    """
    if sys.version_info < (3, 9):
        return t

    try:
        from typing import Annotated as annotated  # pylint:disable=c0415

        _ = annotated
    except ImportError:
        return t

    # 检查是否为 Annotated 类型
    if hasattr(t, "__origin__") and hasattr(t, "__metadata__"):
        # Annotated[type, ...]，返回第一个参数（实际类型）
        return getattr(t, "__origin__")

    return t


def expand_path_variables(path_str: str) -> Path:
    """展开路径中的内置变量

    支持的内置变量：
    - {workspace} 或 {projectdir}: 项目根目录
    - {projectname}: 项目名称
    - {homedir} 或 {home}: 用户主目录
    - {localdata}: 本地数据目录
    - {roamingdata}: 漫游数据目录 (仅 Windows)
    - {config}: 配置目录
    - {cache}: 缓存目录
    - {state}: 状态目录
    - {tmp}: 临时目录
    - {app}: 应用安装目录
    - {env:VAR_NAME}: 环境变量

    Args:
        path_str: 包含变量的路径字符串

    Returns:
        Path: 展开后的路径对象（自动规范化分隔符）

    Raises:
        ValueError: 遇到未知变量时抛出

    Examples:
        >>> _expand_path_variables("{workspace}/data")
        Path('/path/to/project/data')
        >>> _expand_path_variables("{home}/.config/app")
        Path('/home/user/.config/app')
        >>> _expand_path_variables("{cache}/{projectname}")
        Path('/home/user/.cache/myapp')
    """
    result = path_str

    # 定义内置变量映射
    var_map = {
        # 项目相关
        "workspace": str(environ.project_dir),
        "projectdir": str(environ.project_dir),
        "projectname": environ.project_name,
        # 用户目录
        "homedir": str(environ.home),
        "home": str(environ.home),
        # 数据目录
        "localdata": str(environ.localdata),
        "roamingdata": str(environ.roamingappdata),
        # 系统目录
        "config": str(environ.config_home),
        "cache": str(environ.cache_home),
        "state": str(environ.state_home),
        "tmp": str(environ.tmp_dir),
        "app": str(environ.application),
    }

    # 展开内置变量
    for var_name, var_value in var_map.items():
        pattern = f"{{{var_name}}}"
        if pattern in result:
            result = result.replace(pattern, var_value)

    # 展开环境变量 {env:VAR_NAME}
    env_pattern = re.compile(r"\{env:([^}]+)\}")
    match = env_pattern.search(result)
    while match:
        env_var = match.group(1)
        env_value = os.getenv(env_var, "")
        if env_value:
            result = result.replace(match.group(0), env_value)
        else:
            raise ValueError(f"环境变量 {env_var} 未定义")
        match = env_pattern.search(result)

    # 检查是否还有未展开的 {variable} 模式
    unmatched_pattern = re.compile(r"\{([^}]+)\}")
    unmatched_match = unmatched_pattern.search(result)
    if unmatched_match:
        unknown_var = unmatched_match.group(1)
        raise ValueError(f"未知的路径变量: {unknown_var}")

    return Path(result)
