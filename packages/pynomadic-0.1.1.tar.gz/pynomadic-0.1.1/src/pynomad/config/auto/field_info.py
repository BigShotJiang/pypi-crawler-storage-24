"""配置字段信息模块

提供类似 Pydantic 的 Field 功能，用于定义带有自定义转换器的配置字段。
"""

from collections.abc import Callable
from typing import Any, TypeVar, overload

_T = TypeVar("_T", bound=object)


class FieldInfo:
    """字段信息类，存储配置字段的元数据

    类似 Pydantic 的 FieldInfo，存储字段的默认值、工厂函数、转换器等信息。

    Attributes:
        default: 默认值
        default_factory: 默认值工厂函数
        converter: 自定义类型转换器
        alias: 配置文件中的别名(如 class_ -> class)
    """

    def __init__(
        self,
        default: Any | None = None,
        default_factory: Callable[[], Any] | None = None,
        converter: Callable[[Any], Any] | None = None,
        alias: str | None = None,
    ):
        """初始化字段信息

        Args:
            default: 默认值
            default_factory: 默认值工厂函数
            converter: 自定义类型转换器
            alias: 配置文件中的别名
        """
        self.default = default
        self.default_factory = default_factory
        self.converter = converter
        self.alias = alias


# ConfigField 工厂函数，使用 @overload 实现类型推断
@overload
def field(
    default: Any,
    *,
    default_factory: Callable[[], Any] | None = None,
    converter: Callable[[Any], Any] | None = None,
    alias: str | None = None,
) -> Any: ...


@overload
def field(
    *,
    default: Any | None = None,
    default_factory: Callable[[], Any],
    converter: Callable[[Any], Any] | None = None,
    alias: str | None = None,
) -> Any: ...


@overload
def field(
    *,
    default: Any | None = None,
    default_factory: Callable[[], Any] | None = None,
    converter: Callable[[Any], Any],
    alias: str | None = None,
) -> Any: ...


@overload
def field(
    *,
    default: Any | None = None,
    default_factory: Callable[[], Any] | None = None,
    converter: Callable[[Any], Any] | None = None,
    alias: str | None = None,
) -> Any: ...


def field(
    default: Any | None = None,
    *,
    default_factory: Callable[[], Any] | None = None,
    converter: Callable[[Any], Any] | None = None,
    alias: str | None = None,
) -> Any:
    """创建配置字段

    这是 ConfigField 的工厂函数，返回类型根据 default 参数推断。

    Args:
        default: 默认值。根据此值的类型，类型检查器会推断返回类型
        default_factory: 默认值工厂函数
        converter: 自定义类型转换器
        alias: 配置文件中的别名(如 class_ -> class)，用于解决 Python 关键字冲突

    Returns:
        FieldInfo 实例，但类型检查器会根据 default 参数推断出对应的类型

    Notes:
        - 当提供 default 值时，返回类型推断为 default 的类型
        - 类型检查器会认为 `name: str = ConfigField("")` 是正确的
        - 这与 Pydantic 的 Field() 行为一致

    Examples:
        >>> # 类型检查器不会报错
        >>> class Config:
        ...     basedir: str = ConfigField("")
        ...     port: int = ConfigField(8080)
        ...     enabled: bool = ConfigField(True)
        >>> # 使用 alias 解决 Python 关键字冲突
        >>> class Config:
        ...     class_: str = ConfigField(alias="class")  # 配置文件中使用 "class"
    """
    return FieldInfo(
        default=default,
        default_factory=default_factory,
        converter=converter,
        alias=alias,
    )


def is_field_info(value: Any) -> bool:
    """检查值是否为 FieldInfo 实例

    Args:
        value: 要检查的值

    Returns:
        bool: 是否为 FieldInfo 实例
    """
    return isinstance(value, FieldInfo)
