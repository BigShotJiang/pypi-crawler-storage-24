"""通用属性"""

from pathlib import Path
from pynomad.config.auto.autoconfig import inject
from pynomad.config.auto.field_info import field


@inject()
class BuiltinProperties:
    """内建属性"""

    basedir: Path = field()
    datadir: Path = field()
    config_uris: list[str] = field()
    projectname: str = field()
    active: list[str] = field()
    environments: list[str] = field()
