"""自动配置生成器模块

本模块提供从配置文件自动生成TypedDict或dataclass类型的配置类的功能。
主要包含两个核心类：

- AttributeInfo: 配置属性信息类，描述配置树中的单个属性节点
- ConfigGenerator: 配置生成器，负责从配置文件生成代码

主要功能：
- 类型推断：自动推断配置值的类型（基本类型、序列类型、映射类型）
- 路径处理：识别并处理文件路径，支持路径变量展开
- 动态key检测：智能判断是否需要作为字典处理
- 包装类型支持：支持自定义包装类型配置
- 通配符匹配：支持使用通配符模式匹配配置路径
"""

from dataclasses import is_dataclass, fields
import fnmatch
import inspect
from pathlib import Path
from types import GenericAlias
from typing import Literal
import warnings
from pynomad.common import strings
from pynomad.common.environment import environ
from pynomad.common.types import AnyDict
from pynomad.config.auto.generate.attributeInfo import AttributeInfo
from pynomad.config.auto.properties import BuiltinProperties
from pynomad.config.loader.manager import LoaderManager

# 动态获取 inject、alias、field 的导入路径
from pynomad.config.auto import autoconfig as autoconfig_module
from pynomad.config.auto import field_info as field_info_module


class ConfigGenerator:
    """配置生成器

    从配置文件自动生成TypedDict或dataclass类型的配置类。
    支持类型推断、路径处理、动态key检测等高级功能。
    """

    def __init__(
        self,
        output_path: Path | None = None,
        class_suffix: str = "Record",
        class_prefix: str = "Cfg",
        default_source_file: str = "properties.py",
        root_class_name: str = "ProjectRecord",
        root_class_parent: type | None = BuiltinProperties,
        dict_type: Literal["EnhancedDict", "dict"] = "EnhancedDict",
        wrap_types: dict[str, str | type | GenericAlias] | None = None,
    ):
        """初始化配置生成器

        Args:
            output_path: 输出文件路径，None时自动检测
            class_suffix: 生成的类名后缀
            class_prefix: 生成的类名前缀
            default_source_file: 默认源文件名
            root_class_name: 根类名
            root_class_parent: 根类的父类
            dict_type: 字典类型，"EnhancedDict" 或 "dict"
            wrap_types: 路径到类型的映射配置
        """
        self._output_path = self._get_out_path(output_path, default_source_file)
        self._class_suffix = class_suffix
        self._class_prefix = class_prefix
        self._root_class_name = root_class_name
        self._root_class_parent: type | None = root_class_parent
        self._dict_type: Literal["EnhancedDict", "dict"] = dict_type
        self._config_dict = self._get_config_dict()
        self._wrap_types = wrap_types

    @property
    def wrap_types(self) -> dict[str, str]:
        """获取包装类型配置

        将类型对象或GenericAlias转换为字符串表示。

        Returns:
            路径到类型字符串的映射字典
        """
        wrap_types: dict[str, str] = {}
        if self._wrap_types is None:
            return wrap_types
        for key, value in self._wrap_types.items():
            if isinstance(value, type):
                wrap_types[key] = value.__name__
                continue
            if isinstance(value, GenericAlias):
                wrap_types[key] = str(value)
                continue
            wrap_types[key] = value
        return wrap_types

    @property
    def out_path(self) -> Path:
        """获取输出文件路径

        Returns:
            生成的代码输出路径
        """
        return self._output_path

    @property
    def class_suffix(self) -> str:
        """获取类名后缀

        Returns:
            生成的类名后缀，如 "Record"
        """
        return self._class_suffix

    def _get_out_path(
        self, output_path: Path | None, default_source_file: str
    ) -> Path:
        """获取输出文件路径

        Args:
            output_path: 用户指定的输出路径
            default_source_file: 默认源文件名

        Returns:
            最终的输出文件路径
        """
        if output_path is None:
            return self._get_default_outpath(default_source_file)
        if output_path.is_file():
            return output_path
        return output_path / default_source_file

    def _get_default_outpath(self, default_source_file: str) -> Path:
        """获取默认输出路径

        按优先级依次查找：src/{project_name}、{project_name}、{root}/__init__.py所在的包。

        Args:
            default_source_file: 默认源文件名

        Returns:
            默认的输出文件路径
        """
        out_path: Path = environ.project_dir / "src" / environ.project_name
        if out_path.exists():
            return out_path / default_source_file
        out_path = environ.project_dir / environ.project_name
        if out_path.exists():
            return out_path / default_source_file
        out_path = environ.project_dir
        for path in out_path.iterdir():
            if path.is_dir() and (path / "__init__.py").exists():
                return path / default_source_file
        return environ.project_dir / default_source_file

    def _get_config_dict(self) -> AnyDict:
        """获取配置字典

        Returns:
            从LoaderManager加载的配置字典
        """
        manager = LoaderManager()
        config_dict = manager.get_environment_config()
        return config_dict

    def _get_attribute_infos(
        self,
        parent: AttributeInfo | None = None,
        attrbuteinfos: list[AttributeInfo] | None = None,
        wrap_type: str | type = "",
    ) -> list[AttributeInfo]:
        """递归获取所有属性信息

        Args:
            parent: 父级属性节点
            attrbuteinfos: 属性信息列表（递归时使用）
            wrap_type: 包装类型

        Returns:
            所有属性信息的列表
        """
        configs: AnyDict | str | None = None
        if attrbuteinfos is None:
            attrbuteinfos = []
        configs = (
            parent.value if parent is not None else self._get_config_dict()
        )
        # 如果不是字典,则不需要再遍历
        if not isinstance(configs, dict):
            return attrbuteinfos
        for key, value in configs.items():
            attr: AttributeInfo = AttributeInfo(
                key,
                value,
                parent,
                wrap_type,
                self._class_prefix,
                self._class_suffix,
                self._dict_type,
            )
            attrbuteinfos.append(attr)
            # 如果是字典就继续遍历
            if isinstance(value, dict):
                _ = self._get_attribute_infos(
                    parent=attr, attrbuteinfos=attrbuteinfos
                )
        return attrbuteinfos

    def add_wrap_type(
        self, wrap_types: list[tuple[str, str | type | GenericAlias]]
    ):
        """添加包装类型配置

        Args:
            wrap_types: 类型配置列表,每个元素是 (路径, 类型) 的元组
                       类型可以是字符串、Python类型或GenericAlias
        """
        if not wrap_types:
            return

        if self._wrap_types is None:
            self._wrap_types = {}

        for item in wrap_types:
            if len(item) != 2:
                warnings.warn(f"类型配置项格式错误,需要(path, type): {item}")
                continue

            path: str = item[0]
            wrap_type: str | type | GenericAlias = item[1]
            self._wrap_types[path] = wrap_type

    def _apply_wrap_types_to_attributes(
        self, attributes: list[AttributeInfo]
    ) -> list[AttributeInfo]:
        """将用户设置的 wrap_type 应用到匹配的 AttributeInfo 上

        支持通配符模式匹配路径，如 "database.*" 或 "*.host"。

        Args:
            attributes: AttributeInfo 列表

        Returns:
            应用了 wrap_type 的 AttributeInfo 列表
        """
        if not self._wrap_types:
            return attributes

        for attr in attributes:
            str_path: str = attr.key_path
            for pattern, wrap_type in self._wrap_types.items():
                if fnmatch.fnmatch(str_path, pattern):
                    attr.set_wrap_type(wrap_type)

                    break

        return attributes

    def _collect_imports(
        self,
        attributes: list[AttributeInfo],
        class_type: Literal["dataclass", "typeddict"] = "dataclass",
    ) -> list[str]:
        """收集所有需要的导入语句

        Args:
            attributes: 属性信息列表
            class_type: 生成类型

        Returns:
            导入语句列表
        """
        imports: list[str] = []
        if class_type == "dataclass":
            # 添加 dataclass、inject 和 field 的导入
            imports.append("from dataclasses import dataclass")
            imports.append(
                f"from {autoconfig_module.inject.__module__} "
                + f"import {autoconfig_module.inject.__name__}"
            )
            imports.append(
                f"from {field_info_module.field.__module__} import "
                + f"{field_info_module.field.__name__}"
            )
        else:
            # TypedDict 和 alias
            imports.append("from typing_extensions import TypedDict")
            imports.append(
                f"from {autoconfig_module.alias.__module__} import "
                + f"{autoconfig_module.alias.__name__}"
            )
        # 去重
        if self._root_class_parent:
            imports.append(
                f"from {self._root_class_parent.__module__} "
                + f"import {self._root_class_parent.__name__}"
            )
        # 收集所有属性需要的导入
        for attr in attributes:
            imports.extend(attr.required_imports)

        return self._sort_imports(imports)

    def _sort_imports(self, imports: list[str]) -> list[str]:
        """对导入语句进行排序，标准库导入放前面

        Args:
            imports: 导入语句列表

        Returns:
            排序后的导入语句列表
        """
        # 去重并保持顺序
        unique_imports: list[str] = list(dict.fromkeys(imports))

        # 标准库模块集合
        stdlib_modules: set[str] = {
            "typing",
            "pathlib",
            "os",
            "sys",
            "json",
            "re",
            "datetime",
            "collections",
            "functools",
            "itertools",
            "abc",
            "enum",
            "types",
            "inspect",
        }

        def is_stdlib(stmt: str) -> bool:
            """判断是否为标准库导入"""
            if not stmt.startswith(("from ", "import ")):
                return False
            module: str = stmt.split()[1] if len(stmt.split()) > 1 else ""
            # 处理 from xxx.yyy import zzz 的情况，只取顶层模块
            top_module: str = module.split(".")[0]
            return top_module in stdlib_modules

        # 排序：标准库在前（False < True），然后按字母排序
        unique_imports.sort(key=lambda s: (not is_stdlib(s), s.lower()))

        return unique_imports

    def _collect_records(self, attributes: list[AttributeInfo]):
        records: dict[str, AttributeInfo] = {}
        for attr in attributes:
            if attr.should_generate_independent_class:
                records[attr.wrap_type] = attr
        record_list: list[AttributeInfo] = list(records.values())
        record_list.sort(key=lambda x: x.dept, reverse=True)
        return record_list

    def _get_root_attrs(self, attributes: list[AttributeInfo]):
        """获取根属性列表"""
        parent_fields = self._get_parent_fields()
        top_level_attrs: dict[str, AttributeInfo] = {}
        for attr in attributes:
            if attr.parent is None and attr.key not in parent_fields:
                top_level_attrs[attr.key] = attr
        return top_level_attrs

    def _get_parent_fields(self):
        parent_fields: list[str] = []
        if self._root_class_parent and inspect.isclass(self._root_class_parent):
            annotations = self._root_class_parent.__annotations__
            parent_fields = list(annotations.keys())
        if self._root_class_parent and is_dataclass(self._root_class_parent):
            parent_fields = [
                field.name for field in fields(self._root_class_parent)
            ]

        return parent_fields

    def _create_root_class_code(self, attributes: list[AttributeInfo]):
        root_attrs = self._get_root_attrs(attributes)
        root_codes: list[str] = ["\r"]
        root_codes.append("@inject()")
        if self._root_class_parent:
            root_codes.append(
                f"class {self._root_class_name}({self._root_class_parent.__name__}):"
            )
        else:
            root_codes.append(f"class {self._root_class_name}:")
        root_codes.append('    "自动生成类,如果有不符合要求请手动更改"')
        for _, attr in root_attrs.items():
            line = self._create_line_attr(attr)
            root_codes.append(line)
        return root_codes

    def _collect_record_attrs(self, attr: AttributeInfo) -> list[AttributeInfo]:
        """收集 record 的属性"""
        attrs_dict: dict[str, AttributeInfo] = {}
        # 将自身的属性添加到属性列表
        if attr.parent is not None and attr.parent.is_dynamic_key:
            attr = attr.parent
            for child in attr.children:
                for child_child in child.children:
                    attrs_dict[child_child.wrap_attr_name] = child_child
            return list(attrs_dict.values())
        for child in attr.children:
            attrs_dict[child.wrap_attr_name] = child
        # 查找兄弟节点,将兄弟节点的属性也添加到属性列表
        return list(attrs_dict.values())

    def _create_record_class_code(self, attributes: list[AttributeInfo]):
        """创建记录类代码"""
        records = self._collect_records(attributes)
        lines: list[str] = []
        for record in records:
            if record.inject_key_path is not None:
                lines.append(f'@inject(prefix="{record.key_path}")')
            else:
                lines.append("@dataclass")
            lines.append(f"class {record.wrap_type}:")
            lines.append(f'    """{record.wrap_type}"""')
            attrs = self._collect_record_attrs(record)
            for attr in attrs:
                attr_line = self._create_line_attr(attr)
                lines.append(attr_line)
        return lines

    def _create_line_attr(self, attr: AttributeInfo):
        line: str = f"    {attr.wrap_attr_name}:{attr.wrap_type} = "
        default = strings.convert(str(attr.value))
        if isinstance(default, str):
            default = f'"{default}"'
        default_value: str = f"default={default}" if attr.is_basic else ""
        alias_name: str = ""
        if attr.key != attr.wrap_attr_name:
            alias_name = f',alias="{attr.key}"'
        line = f"{line}field({default_value}{alias_name})"
        return line

    def _write_code(self, code: str) -> None:
        """将生成的代码写入文件

        Args:
            code: 生成的代码字符串
        """
        output_path: Path = self._output_path

        # 确保父目录存在
        output_path.parent.mkdir(parents=True, exist_ok=True)

        # 写入文件
        with open(output_path, "w", encoding="utf-8") as f:
            _ = f.write(code)

    def _generate_dataclass(self, attributes: list[AttributeInfo]) -> str:
        lines: list[str] = []
        lines.append('"""该代码由生成器自动生成"""\n')
        imports: list[str] = self._collect_imports(attributes)
        record_codes: list[str] = self._create_record_class_code(attributes)
        root_codes: list[str] = self._create_root_class_code(attributes)
        lines.extend(imports)
        lines.extend(record_codes)
        lines.extend(root_codes)
        return "\n".join(lines)

    def generate(
        self, class_type: Literal["dataclass", "typeddict"] = "dataclass"
    ) -> None:
        """生成配置类代码

        从配置文件自动生成TypedDict或dataclass类型的配置类代码，
        并写入到输出文件中。

        Args:
            class_type: 生成类型，"dataclass" 或 "typeddict"
        """
        # 获取所有属性信息
        attributes = self._get_attribute_infos()

        # 应用用户设置的 wrap_type
        attributes = self._apply_wrap_types_to_attributes(attributes)
        code: str = ""
        if class_type == "dataclass":
            # 生成代码
            code: str = self._generate_dataclass(attributes)
        # 写入文件
        else:
            raise NotImplementedError("尚不支持除dataclass外的其它类型")
        self._write_code(code)
