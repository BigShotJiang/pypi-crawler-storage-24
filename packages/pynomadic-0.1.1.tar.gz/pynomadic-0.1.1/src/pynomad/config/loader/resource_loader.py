"""配置资源加载器模块
从项目内部资源中加载配置文件，支持多种配置格式。
"""

from functools import cached_property
from importlib.resources import files
from importlib.resources.abc import Traversable
from pathlib import Path
from typing import final, override
import warnings
from pynomad.common.environment import environ
from pynomad.common.types import AnyDict
from pynomad.config.loader.base import BaseLoader, LoadOrder
from pynomad.config.parser.file_parser import FileParser


# 递归最大深度限制,防止堆栈溢出
MaxDepth: int = 20

# Anchor 类型定义: 多级元组格式的路径锚点
# 格式: (package_name, path_part1, path_part2, ..., file_name)
# 示例: ('pynomad', 'config', 'loader', 'test.json')
# 这种格式让 importlib.resources.abc.Traversable 自行处理路径分隔符问题
type Anchor = tuple[str, ...]


@final
class ResourceLoader(BaseLoader):
    """加载项目内的配置文件

    从 Python 包内部资源中加载配置文件，支持自动完成文件扩展名、
    去重、过滤无效资源等功能。

    Args:
        use_builtins_anchor: 是否使用内置的 anchor，默认为 True
        anchors: 用户自定义的 anchor 列表，格式为 [(模块名, 文件名), ...]
        order: 加载优先级，默认为 20

    Examples:
        >>> # 加载指定模块的配置文件
        >>> loader = ResourceLoader(
        ...     anchors=[("mypackage", "config"), ("myapp", "settings")]
        ... )
        >>> config = loader.load()

        >>> # 使用内置 anchor
        >>> loader = ResourceLoader(use_builtins_anchor=True)
        >>> config = loader.load()
    """

    def __init__(
        self,
        use_builtins_anchor: bool = True,
        anchors: list[Anchor] | None = None,
        load_order: int = LoadOrder.RESOURCE,
        name: str = "",
    ):
        # 优先级较低
        self._order: int = load_order
        self._use_builtins_anchor: int = use_builtins_anchor
        self._user_anchors = anchors
        self._parser = FileParser()
        self._anchors = self._build_anchors()
        self._name = (
            name if name else f"ResourceLoader(anchors={len(self._anchors)})"
        )
        self._uri = self._build_uri()

    @property
    @override
    def name(self) -> str:
        """获取加载器名称"""
        return self._name

    @property
    @override
    def config_uri(self) -> str:
        """获取配置 URI

        Returns:
            str: 配置资源的 URI，格式为 resource://package/path/to/file
        """
        return self._uri

    @property
    def anchors(self) -> list[Anchor]:
        """获取所有 anchor"""
        return self._anchors

    def _build_uri(self) -> str:
        """构建配置 URI

        Returns:
            str: 配置 URI
        """
        uris: list[str] = []
        for anchor in self._anchors:
            uris.append("resource://" + "/".join(anchor))
        return ";".join(uris)

    @cached_property
    def resources(self) -> list[Traversable]:
        """获取所有资源"""
        resources: list[Traversable] = []
        for anchor in self._anchors:
            resource = self._build_resource_from_anchor(anchor)
            if resource is not None:
                resources.append(resource)
        return resources

    def _build_anchors(self) -> list[Anchor]:
        """构建并处理所有 anchor（补全、去重、过滤）

        Returns:
            处理后的 anchor 列表
        """
        all_anchors: list[Anchor] = []
        # 处理内置 anchor (在前,优先级低)
        if self._use_builtins_anchor:
            all_anchors.extend(self._generate_builtin_anchors())
            # 处理用户自定义的 anchor (在后,优先级高)
        if self._user_anchors:
            user_anchors: list[Anchor] = self._normalize_anchors(
                self._user_anchors
            )
            filter_anchors: list[Anchor] = self.filter_anchors(user_anchors)
            all_anchors.extend(filter_anchors)
        return all_anchors

    def _normalize_anchors(self, anchors: list[Anchor]) -> list[Anchor]:
        """规范化用户提供的 anchor 列表

        执行以下操作:
        1. 添加文件扩展名（如果缺失）
        2. 去重（保持顺序）
        3. 转换为标准多级元组格式

        支持旧格式 (package, 'path/to/file') 和新格式 (package, 'path', 'to', 'file')

        Args:
            anchors: 原始 anchor 列表

        Returns:
            规范化后的 anchor 列表
        """
        # 首先扩展扩展名
        expanded_anchors = self._expand_extensions(anchors)

        # 去重（保持顺序，后面的覆盖前面的）
        seen: dict[Anchor, int] = {}
        for idx, item in enumerate(expanded_anchors):
            seen[item] = idx

        # 按照索引排序,保持原始顺序
        sorted_anchors = [
            item for item, _ in sorted(seen.items(), key=lambda x: x[1])
        ]

        return sorted_anchors

    def filter_anchors(self, anchors: list[Anchor]) -> list[Anchor]:
        """过滤掉包内部不存在的anchor"""
        valid_anchors: list[Anchor] = []

        for anchor in anchors:
            # 构建路径并检查资源是否存在
            try:
                resource = self._build_resource_from_anchor(anchor)
                if resource and resource.is_file():
                    valid_anchors.append(anchor)
            except (
                ModuleNotFoundError,
                AttributeError,
                ValueError,
                FileNotFoundError,
            ):
                # 模块不存在或资源无效，跳过
                continue

        return valid_anchors

    def _build_resource_from_anchor(self, anchor: Anchor) -> Traversable | None:
        """从 anchor 构建 Traversable 资源对象

        Args:
            anchor: 路径锚点元组

        Returns:
            Traversable 资源对象，如果构建失败返回 None
        """
        try:
            package = anchor[0]
            path_parts = anchor[1:] if len(anchor) > 1 else ()

            # 使用链式 joinpath 构建路径,避免使用路径分隔符
            resource: Traversable = files(package)
            for part in path_parts:
                if part and part != ".":
                    resource = resource.joinpath(part)
            return resource
        except (ModuleNotFoundError, AttributeError, ValueError):
            return None

    def _expand_extensions(self, anchors: list[Anchor]) -> list[Anchor]:
        """扩展 anchor 的文件扩展名

        如果文件名没有扩展名，尝试添加常见扩展名。
        扩展名按不推荐到推荐的顺序排列,因为后面加载的会覆盖前面的。

        Args:
            anchors: 原始 anchor 列表

        Returns:
            扩展扩展名后的 anchor 列表
        """
        expanded_anchors: list[Anchor] = []

        for anchor in anchors:
            if len(anchor) < 2:
                # anchor 至少需要有 package 和 filename
                continue

            package = anchor[0]
            second_part = anchor[1]

            # 使用 pathlib 统一处理各种路径格式
            # 新格式或简单格式: (package, filename) 或 (package, path1, path2, filename)
            if len(anchor) == 2:
                # 旧格式: (package, "path1/path2/file.ext")
                # 或简单格式: (package, "filename.ext")
                path_obj = Path(second_part)
                filename = path_obj.name
                path_parts = (
                    tuple(path_obj.parent.parts)
                    if path_obj.parent != Path(".")
                    else ()
                )
            else:
                # 多级格式: (package, path1, path2, filename)
                filename = anchor[-1]
                path_parts = anchor[1:-1]

            if "." in filename:
                # 已有扩展名，直接添加
                if path_parts:
                    expanded_anchors.append(
                        (package,) + path_parts + (filename,)
                    )
                else:
                    expanded_anchors.append((package, filename))
            else:
                # 尝试所有支持的扩展名 (按优先级顺序,最后的会覆盖前面的)
                # 从 FileParser 获取支持的扩展名(带点号格式,如 .json)
                for ext_with_dot in self._parser.extensions:
                    ext = ext_with_dot.lstrip(".")
                    new_filename = f"{filename}.{ext}"
                    if path_parts:
                        expanded_anchors.append(
                            (package,) + path_parts + (new_filename,)
                        )
                    else:
                        expanded_anchors.append((package, new_filename))

        return expanded_anchors

    def _generate_builtin_anchors(self) -> list[Anchor]:
        """生成内置的 anchor

        使用 importlib.resources.files 在根包中搜索配置文件。
        类似 Spring Boot 的资源搜索策略:
        - 在根包的 data/ 和 config/ 目录中查找
        - 支持多级目录结构
        - 按优先级排序,后面的配置会覆盖前面的

        Returns:
            内置 anchor 列表
        """
        # 根包列表 (按从通用到具体的顺序,后面的优先级高)
        root_packages = [
            "pynomad",  # 框架默认配置
            environ.project_name,  # 项目特定配置 (优先级最高)
        ]
        # 去重，避免重复搜索相同的包
        root_packages = list(dict.fromkeys(root_packages))
        found_anchors: set[Anchor] = set()
        for package in root_packages:
            package_anchors = self._generate_builtin_package_anchors(package)
            found_anchors = found_anchors.union(package_anchors)
        return self._sorted_anchors(file_anchors=found_anchors)

    def _generate_builtin_package_anchors(self, package: str) -> set[Anchor]:
        """生成指定包的内置 anchor

        先递归查找所有目录,然后在每个目录中查找配置文件。

        Args:
            package: 包名

        Returns:
            该包内的所有配置文件 anchor 集合
        """
        # 先使用set去重,之后再排序
        dir_anchors: set[Anchor] = set()
        self._find_dir_anchors(dir_anchors, package, ".")
        # 先使用set去重,之后再排序
        file_anchors: set[Anchor] = self._find_file_anchors(dir_anchors)
        return file_anchors

    def _sorted_anchors(
        self, file_anchors: list[Anchor] | set[Anchor]
    ) -> list[Anchor]:
        sorted_anchors: list[Anchor] = list(file_anchors)
        sorted_anchors = sorted(
            sorted_anchors, key=self._sorted_rules, reverse=True
        )
        return sorted_anchors

    def _sorted_rules(self, anchor: Anchor) -> tuple[int, int]:
        """计算 anchor 的排序键值

        排序规则:
        - 路径深度（不包括包名）: 越深优先级越高
        - 扩展名类型: 按支持的扩展名列表顺序,越靠前优先级越高

        Args:
            anchor: 待排序的 anchor 元组

        Returns:
            (深度, 扩展名索引) 元组,用于排序比较
        """
        # anchor 格式: (package, path_part1, path_part2, ..., file_name)
        # 计算路径深度（不包括包名）
        deep: int = len(anchor) - 1
        # 获取文件名（最后一个元素）
        file_name = anchor[-1] if len(anchor) > 1 else ""

        # 扩展名优先级列表 (从 FileParser 获取)
        extensions = list(
            reversed([ext.lstrip(".") for ext in self._parser.extensions])
        )
        index: int = 0
        try:
            index = extensions.index(Path(file_name).suffix.lstrip("."))
        except (ValueError, AttributeError):
            ...
        return (deep, index)

    def _is_valid_config_file(self, file_name: str, package: str) -> bool:
        """判断文件是否为有效的配置文件

        Args:
            file_name: 文件名
            package: 包名

        Returns:
            如果是有效的配置文件返回 True，否则返回 False
        """
        file_name_lower = file_name.lower()

        # 跳过特定的非配置文件（精确匹配）
        if file_name_lower == "keywords.json" and package == "pynomad":
            return False

        # 跳过指定模式的文件（如 schema.json）
        if file_name_lower.endswith(".schema.json"):
            return False

        # 跳过不带扩展名的文件
        if "." not in file_name_lower:
            return False

        # 取最后一个点号后的部分作为扩展名
        extension = file_name_lower.split(".")[-1]
        extension = f".{extension}"

        # 跳过 Python 源文件
        if extension in [".py", ".pyi", ".pyc"]:
            return False

        # 检查解析器是否支持该格式
        return self._parser.supports(format_hint=extension)

    def _find_file_anchors(self, dir_anchors: set[Anchor]) -> set[Anchor]:
        """在指定的目录 anchor 集合中查找所有配置文件

        Args:
            dir_anchors: 目录 anchor 集合

        Returns:
            找到的所有配置文件 anchor 集合
        """
        file_anchors: set[Anchor] = set()
        for anchor in dir_anchors:
            package = anchor[0]
            path_parts = anchor[1:] if len(anchor) > 1 else ()

            # 使用链式 joinpath 构建路径,避免使用路径分隔符
            dir_resource = self._build_resource_from_anchor(anchor)
            if not dir_resource or dir_resource.is_file():
                continue

            for res in dir_resource.iterdir():
                # 跳过目录和非文件
                if not res.is_file():
                    continue

                res_name = res.name

                # 判断是否为有效的配置文件
                if not self._is_valid_config_file(res_name, package):
                    continue

                # 添加到 file_anchors (保持多级元组格式)
                filtered_parts = tuple(p for p in path_parts if p != ".")
                if filtered_parts:
                    file_anchors.add((package,) + filtered_parts + (res_name,))
                else:
                    file_anchors.add((package, res_name))
        return file_anchors

    def _find_dir_anchors(
        self,
        dir_anchors: set[Anchor],
        anchor: str,
        *path_name: str,
        depth: int = 0,
    ):
        """递归查找包内的所有目录

        注意: 如果传递像 'pynomad.config' 这样的子模块作为 anchor,
        如果没有传递 path_name,files() 返回的结果是 config 的同级目录,
        所以只使用根目录作为 anchor。

        Args:
            dir_anchors: 用于存储找到的目录 anchor 集合
            anchor: 包名
            *path_name: 路径部分（可变参数）
            depth: 当前递归深度,用于防止堆栈溢出
        """
        # 防止递归过深导致堆栈溢出
        if depth >= MaxDepth:
            warnings.warn(
                f"Reached maximum recursion depth {MaxDepth} for anchor: {anchor}"
            )
            return

        # 构建标准的 anchor 元组：(package, path_part1, path_part2, ...)
        anchor_tuple: Anchor = (anchor,) + path_name if path_name else (anchor,)
        dir_anchors.add(anchor_tuple)

        # 使用链式 joinpath 构建路径,避免使用路径分隔符
        try:
            resource = files(anchor)
        except (ModuleNotFoundError, ValueError) as e:
            warnings.warn(f"无法找到模块 '{anchor}'，跳过配置搜索: {e}")
            return
        for part in path_name:
            if part and part != ".":
                resource = resource.joinpath(part)

        # 如果资源是一个文件,则不再执行,跳出递归
        if not resource.is_dir():
            return
        for res in resource.iterdir():
            # 跳过文件
            if res.is_file():
                continue
            # 跳过缓存目录和非关键目录
            res_name = res.name  # 保留原始目录名
            res_name_lower = res_name.lower()  # 用于比较
            if res_name_lower in ["__pycache__"]:
                continue
            # 将目录添加进anchor中
            # 将路径部分拆分并添加新的目录名
            # 过滤掉 "." 只保留实际的路径部分
            filtered_path = tuple(p for p in path_name if p != ".")
            sub_path_parts = (
                list(filtered_path) + [res_name]
                if filtered_path
                else [res_name]
            )
            # 添加anchor (保持多级元组格式)
            dir_anchors.add((anchor,) + tuple(sub_path_parts))
            # 递归执行下一次查找,传递路径部分,深度加1
            self._find_dir_anchors(
                dir_anchors, anchor, *sub_path_parts, depth=depth + 1
            )

    @property
    @override
    def order(self) -> int:
        """获取加载优先级"""
        return self._order

    @override
    def supports(self) -> bool:
        """检查是否有可用的资源

        Returns:
            如果存在至少一个可用资源返回 True，否则返回 False
        """
        return len(self._anchors) > 0

    @override
    def load(self) -> AnyDict:
        """从项目资源中加载配置数据

        按顺序加载所有可用的配置文件，后加载的配置会覆盖先加载的配置。
        加载后的配置键名会自动转换为 snake_case，字符串值会自动推断类型。

        Returns:
            合并后的配置字典

        Examples:
            >>> loader = ResourceLoader(anchors=[("mypackage", "config")])
            >>> config = loader.load()
            >>> print(config)
        """
        merged_config: AnyDict = {}

        for resource in self.resources:
            try:
                # 读取文件内容
                with resource.open("rb") as f:
                    content = f.read()

                # 使用 FileParser 的 parse_text 方法解析
                # 根据扩展名选择解析器
                ext = (
                    "." + resource.name.split(".")[-1]
                    if "." in resource.name
                    else None
                )
                if ext:
                    config = self._parser.parse_text(
                        content.decode("utf-8"), format_hint=ext
                    )

                    # 转换键名为 snake_case，并推断值类型
                    # config = snakeize_dict(config)

                    # 合并配置（后加载的覆盖先加载的）
                    merged_config.update(config)
            except (
                OSError,
                ValueError,
                KeyError,
                UnicodeDecodeError,
                AttributeError,
            ):
                # 解析失败，跳过该文件
                warnings.warn(f"Failed to load resource: {resource}")
                continue

        return merged_config
