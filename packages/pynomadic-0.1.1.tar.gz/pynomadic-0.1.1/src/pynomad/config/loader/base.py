"""配置加载器模块

该模块提供了配置加载的抽象基类和具体实现，支持从不同来源加载配置数据。

示例:
    >>> loader = EnvironmentLoader(order=LoadOrder.ENVIRONMENT, prefix="MYAPP")
    >>> if loader.supports():
    ...     config = loader.load()
"""

from functools import singledispatchmethod
import hashlib
import os
import re
import sys
from enum import IntEnum
from typing import final, override
from abc import ABC, abstractmethod
import warnings

from pynomad.common.environment import environ
from pynomad.common.types import AnyDict
from pynomad.config.config_utils import parse_value
from pynomad.naming import naming
from pynomad.naming.naming_types import NameStyle

# 常量区
BASEDIR = "basedir"
DATADIR = "datadir"
PROJECTNAME = "projectname"
CONFIG_URIS = "config_uris"
ACTIVE = "active"
ENVIRONMENTS = "environments"
DEFAULT = "default"
# 敏感环境变量名称模式（大小写不敏感）
SENSITIVE_KEY_PATTERNS = [
    re.compile(r"password", re.IGNORECASE),
    re.compile(r"passwd", re.IGNORECASE),
    re.compile(r"secret", re.IGNORECASE),
    re.compile(r"token", re.IGNORECASE),
    re.compile(r"api_key", re.IGNORECASE),
    re.compile(r"secret_key", re.IGNORECASE),
    re.compile(r"private_key", re.IGNORECASE),
    re.compile(r"access_key", re.IGNORECASE),
    re.compile(r"credential", re.IGNORECASE),
    re.compile(r"private", re.IGNORECASE),
]

# 命令行参数键名白名单模式（仅允许字母、数字、下划线、连字符）
CMD_KEY_PATTERN = re.compile(r"^[a-zA-Z0-9_-]+$")


class LoadOrder(IntEnum):
    """配置加载优先级常量

    优先级数值越小,加载顺序越靠前,后加载的配置会覆盖先加载的配置。

    优先级范围:
    - 0-19: 用户级配置 (命令行参数等)
    - 20-39: 环境级配置 (环境变量等)
    - 40-79: 外部文件级配置 (外部配置文件等)
    - 80-99: 应用级配置 (资源文件等)
    - 100+: 保留扩展 (可用于插件或特殊场景)

    Attributes:
        COMMAND: 命令行参数加载优先级,默认为 10
        ENVIRONMENT: 环境变量加载优先级,默认为 20
        FILE: 外部配置文件加载优先级,默认为 50
        RESOURCE: 资源文件加载优先级,默认为 90
    """

    # 用户级配置 (0-19)
    COMMAND = 10  # 命令行参数,用户直接输入

    # 环境级配置 (20-39)
    ENVIRONMENT = 20  # 环境变量,运行环境配置

    # 外部文件级配置 (40-79)
    FILE = 50  # 外部配置文件,用户自定义配置

    # 应用级配置 (80-99)
    RESOURCE = 90  # 资源文件,应用内置配置

    @override
    def __int__(self):
        """支持转换为 int 类型"""
        return self.value


class BaseLoader(ABC):
    """配置加载器抽象基类

    定义了所有配置加载器必须实现的接口。加载器按照 `order` 属性
    决定优先级，数值越小优先级越高。

    Attributes:
        order: 加载优先级，数值越小越先加载，类型为 int
        name: 加载器名称，便于调试和日志记录
        config_uri: 配置来源的 URI
    """

    @property
    @abstractmethod
    def order(self) -> int:
        """加载优先级

        返回 int 类型，允许用户设置自定义的优先级值。
        可以使用 LoadOrder 枚举常量，也可以直接传入整数。

        Returns:
            int: 优先级数值，数值越小优先级越高

        Example:
            >>> # 使用 LoadOrder 枚举
            >>> loader.order = LoadOrder.ENVIRONMENT
            >>> # 使用自定义整数
            >>> loader.order = 15
        """
        return 0

    @property
    @abstractmethod
    def name(self) -> str:
        """加载器名称

        Returns:
            str: 加载器名称，用于调试和日志输出
        """
        return ""

    @property
    @abstractmethod
    def config_uri(self) -> str:
        """配置来源的 URI

        Returns:
            str: 配置来源的 URI，用于标识和去重
        """
        return ""

    @property
    def default_section_names(self) -> list[str]:
        """默认节名称列表

        配置中哪些节点会被认为是默认节点。
        子类可以重写此属性以指定自己的默认节。

        Returns:
            list[str]: 默认节名称列表，默认为空列表
        """
        return []

    @property
    def dedupe_key(self) -> str:
        """去重键

        默认使用 config_uri 的 SHA256 哈希值作为去重键，可以：
        - 缩短键的长度，特别是对于长的 URI（如文件路径）
        - 统一格式，避免路径格式差异导致重复判断失败
        - 提高性能，较短的字符串作为字典键更高效

        子类可以重写此方法以实现自定义的去重逻辑。

        Returns:
            str: 去重键，用于防止重复加载相同的配置来源
        """
        return hashlib.sha256(self.config_uri.encode()).hexdigest()

    def create_child_loaders(self) -> list["BaseLoader"]:
        """创建子加载器

        允许加载器基于已加载的配置动态创建子加载器。
        例如，文件加载器可以从配置文件中读取 basedir/datadir
        等路径，并创建对应的文件加载器。

        Returns:
            list[BaseLoader]: 子加载器列表，默认为空列表
        """
        return []

    @abstractmethod
    def supports(self) -> bool:
        """检查是否支持当前环境或数据源

        如果返回 True，则会调用 `load` 方法加载配置数据。

        Returns:
            bool: 如果支持当前环境返回 True，否则返回 False
        """

    @abstractmethod
    def load(self) -> AnyDict:
        """加载配置数据

        Returns:
            AnyDict: 加载的配置数据字典
        """


@final
class EnvironmentLoader(BaseLoader):
    """环境变量配置加载器

    从系统环境变量中加载配置数据。支持自定义前缀和优先级。

    环境变量会自动转换为 snake_case 命名风格，并根据字符串内容
    自动推断并转换为合适的数据类型（如 int、float、bool、str）。

    示例:
        >>> # 环境变量: MYAPP_DATABASE_HOST=localhost
        >>> # 环境变量: MYAPP_PORT=8080
        >>> loader = EnvironmentLoader(prefix="MYAPP")
        >>> config = loader.load()
        >>> print(config)  # {'database_host': 'localhost', 'port': 8080}
    """

    def __init__(
        self,
        order: int | LoadOrder = LoadOrder.ENVIRONMENT,
        prefix: str = "",
        name: str = "",
    ) -> None:
        """初始化环境变量加载器

        Args:
            order: 加载优先级，默认为 LoadOrder.ENVIRONMENT (20)。
                  类型为 int 或 LoadOrder，数值越小优先级越高
            prefix: 环境变量前缀。如果为空，则使用项目名称作为前缀。
                   前缀会自动转换为大写，并确保以下划线结尾
            name: 加载器名称。如果为空，则自动生成名称。

        Example:
            >>> # 使用 LoadOrder 枚举
            >>> loader = EnvironmentLoader(order=LoadOrder.ENVIRONMENT)
            >>> # 使用自定义整数
            >>> loader = EnvironmentLoader(order=15)
        """
        # 范围通常在11-20之间
        self._order = int(order)
        self._prefix = self._get_prefix(prefix)
        self._name = (
            name if name else f"EnvironmentLoader(prefix={self._prefix})"
        )
        self._uri = f"env://{self._prefix.rstrip('_').lower()}"

    def _get_prefix(self, prefix: str) -> str:
        """规范化环境变量前缀

        确保前缀为大写格式，并以以下划线结尾。

        Args:
            prefix: 原始前缀字符串

        Returns:
            str: 规范化后的前缀
        """
        prefix = prefix if prefix else environ.project_name
        prefix = f"{prefix}_" if not prefix.endswith("_") else prefix
        return prefix.upper()

    def _is_sensitive_key(self, key: str) -> bool:
        """检查环境变量键名是否为敏感字段

        Args:
            key: 环境变量键名

        Returns:
            bool: 如果键名包含敏感关键词则为 True
        """
        return any(pattern.search(key) for pattern in SENSITIVE_KEY_PATTERNS)

    @property
    @override
    def order(self) -> int:
        """获取加载优先级"""
        return self._order

    @property
    def prefix(self) -> str:
        """获取环境变量前缀"""
        return self._prefix

    @property
    @override
    def name(self) -> str:
        """获取加载器名称"""
        return self._name

    @property
    @override
    def config_uri(self) -> str:
        """获取配置 URI"""
        return self._uri

    @override
    def supports(self) -> bool:
        """环境变量加载器始终支持任何环境

        Returns:
            bool: 永远返回 True
        """
        return True

    @override
    def load(self) -> AnyDict:
        """从环境变量中加载配置数据

        加载所有以指定前缀开头的环境变量，并将键名转换为 snake_case。
        根据字符串内容自动推断并转换为合适的数据类型。

        Returns:
            AnyDict: 环境变量配置字典

        Example:
            >>> # 假设环境变量:
            >>> # MYAPP_ENABLED=true
            >>> # MYAPP_COUNT=42
            >>> # MYAPP_RATE=3.14
            >>> loader = EnvironmentLoader(prefix="MYAPP")
            >>> config = loader.load()
            >>> # config = {'enabled': True, 'count': 42, 'rate': 3.14}
        """
        envs = os.environ
        config: AnyDict = {}
        key_start_index = len(self._prefix)

        for key, value in envs.items():
            upper_key = key.upper()

            # 跳过不以指定前缀开头的环境变量
            if not upper_key.startswith(self._prefix):
                continue

            # 去除前缀，保留剩余部分作为配置键
            key = key[key_start_index:]

            # 根据操作系统转换键名为 snake_case
            if environ.is_windows():
                # Windows 环境变量可能是 UPPER_SNAKE 格式
                key = naming.snakeize(key, from_style=NameStyle.UPPER_SNAKE)
            else:
                key = naming.snakeize(key)
            # 解析值（支持列表和基本类型）
            config[key] = parse_value(value)

        return config


@final
class CommandLoader(BaseLoader):
    """命令行参数配置加载器

    从命令行参数中加载配置数据。支持自定义前缀和优先级。

    支持两种参数格式：
    1. 键值对格式：`--key=value` 或 `--key value`
    2. 布尔标志：`--flag`（解析为
    3. 不支持简写

    参数名会自动转换为 snake_case 命名风格，并根据字符串内容
    自动推断并转换为合适的数据类型（如 int、float、bool、str）。

    示例:
        >>> # 命令行: python app.py --host=localhost --port=8080 --verbose
        >>> loader = CommandLoader(order=5, prefix="--")
        >>> config = loader.load()
        >>> print(config)  # {'host': 'localhost', 'port': 8080, 'verbose': True}
    """

    def __init__(
        self,
        order: int | LoadOrder = LoadOrder.COMMAND,
        prefix: str = "--",
        name: str = "",
    ) -> None:
        """初始化命令行参数加载器

        Args:
            order: 加载优先级，默认为 LoadOrder.COMMAND (10)。
                  类型为 int 或 LoadOrder，数值越小优先级越高。
                  默认比环境变量加载器优先级更高，因为命令行参数更直接
            prefix: 参数前缀，默认为 "--"。支持常见的命令行参数前缀格式
            name: 加载器名称。如果为空，则自动生成名称。

        Example:
            >>> # 使用 LoadOrder 枚举
            >>> loader = CommandLoader(order=LoadOrder.COMMAND)
            >>> # 使用自定义整数
            >>> loader = CommandLoader(order=5)
        """
        # 范围通常在1-10之间
        self._order = int(order)
        self._prefix = prefix
        self._prefix_len = len(prefix)
        self._name = name if name else f"CommandLoader(prefix={prefix})"
        self._uri = f"args://{self._prefix}"

    @property
    @override
    def order(self) -> int:
        """获取加载优先级"""
        return self._order

    @property
    def prefix(self) -> str:
        """获取环境变量前缀"""
        return self._prefix

    @property
    @override
    def name(self) -> str:
        """获取加载器名称"""
        return self._name

    @property
    @override
    def config_uri(self) -> str:
        """获取配置 URI"""
        return self._uri

    @override
    def supports(self) -> bool:
        """检查是否存在命令行参数

        Returns:
            bool: 当命令行参数数量大于 1（脚本名本身）时返回 True
        """
        return len(sys.argv) > 1

    @override
    def load(self) -> AnyDict:
        """从命令行参数中加载配置数据

        支持以下参数格式：
        - `--key=value`：键值对格式
        - `--key value`：空格分隔的键值对
        - `--flag`：布尔标志，解析为 True

        Returns:
            AnyDict: 命令行参数配置字典

        Example:
            >>> # 命令行: python app.py --host=localhost --port=8080 --verbose --debug
            >>> loader = CommandLoader(prefix="--")
            >>> config = loader.load()
            >>> # config = {'host': 'localhost', 'port': 8080, 'verbose': True, 'debug': True}
        """
        config: AnyDict = {}
        args = sys.argv[1:]  # 跳过脚本名

        i = 0
        while i < len(args):
            arg = args[i]

            # 跳过不带前缀的参数
            if not arg.startswith(self._prefix):
                i += 1
                continue

            # 去除前缀
            key = arg[self._prefix_len :]

            # 验证键名格式（防止注入攻击）
            if "=" in key:
                key, value = key.split("=", 1)
                if not CMD_KEY_PATTERN.fullmatch(key):
                    warnings.warn(f"跳过无效的命令行参数键: {key}")
                    i += 1
                    continue
                # 将 kebab-case 转换为 snake_case
                key = naming.snakeize(key, from_style=NameStyle.KEBAB)
                # 解析值（支持列表和基本类型）
                config[key] = parse_value(value)
            # 检查是否为空格分隔的键值对（--key value）
            elif i + 1 < len(args) and not args[i + 1].startswith(self._prefix):
                if not CMD_KEY_PATTERN.fullmatch(key):
                    warnings.warn(f"跳过无效的命令行参数键: {key}")
                    i += 1
                    continue
                # 将 kebab-case 转换为 snake_case
                key = naming.snakeize(key, from_style=NameStyle.KEBAB)
                value = args[i + 1]
                # 解析值（支持列表和基本类型）
                config[key] = parse_value(value)
                i += 1  # 跳过下一个参数（已作为值处理）
            # 布尔标志（--flag）
            else:
                if not CMD_KEY_PATTERN.fullmatch(key):
                    warnings.warn(f"跳过无效的命令行参数键: {key}")
                    i += 1
                    continue
                # 将 kebab-case 转换为 snake_case
                key = naming.snakeize(key, from_style=NameStyle.KEBAB)
                config[key] = True

            i += 1

        return config


class EnvironmentContext:
    """环境配置"""

    def __init__(self, name: str = "default", active: bool = False):
        """初始化环境

        Args:
            name: 环境名称，默认为 "default"
            active: 是否为活动环境，默认为 False
        """
        self._name = name
        self._is_active: bool = active

    @property
    def name(self) -> str:
        """获取环境名称"""
        return self._name

    @property
    def is_active(self) -> bool:
        """是否为活动环境"""
        return self._is_active

    @property
    def is_default(self) -> bool:
        """是否为默认环境"""
        return self._name == "default"

    @override
    def __repr__(self) -> str:
        return (
            f"EnvironmentContext(name={self._name}, active={self._is_active})"
        )


class ConfigContext:
    """配置上下文"""

    def __init__(
        self,
        loaders: list[BaseLoader] | None = None,
    ):
        """初始化配置上下文

        Args:
            loaders: 初始加载器列表
        """
        self._loaders: list[BaseLoader] = []
        if loaders:
            self.add_loaders(loaders)

    @property
    def loaders(self):
        """获取存储的加载器列表"""
        return self._loaders

    @staticmethod
    def _sort_and_dedupe(
        items: list[BaseLoader],
    ) -> list[BaseLoader]:
        """对 BaseLoader 列表进行排序和去重

        先按 order 降序排序(高优先级在前),然后基于 dedupe_key 去重。
        由于已排序,字典去重时会自动保留高优先级的项。

        Args:
            items: 待排序和去重的 BaseLoader 列表

        Returns:
            list[BaseLoader]: 排序去重后的 BaseLoader 列表
        """

        def _get_order(item: BaseLoader) -> int:
            """获取排序键"""
            return item.order

        def _get_dedupe_key(item: BaseLoader) -> str:
            """获取去重键"""
            return item.dedupe_key

        # 第一步: 按 order 降序排序(高优先级在前)
        items.sort(key=_get_order, reverse=True)

        # 第二步: 使用字典去重,保留高优先级的项
        item_map: dict[str, BaseLoader] = {}
        for item in items:
            key = _get_dedupe_key(item)
            # 高优先级在前,直接赋值会保留第一个(高优先级)
            item_map[key] = item

        # 转换为列表
        result = list(item_map.values())
        return result

    @singledispatchmethod
    def add_loaders(self, loaders: list[BaseLoader]):
        """添加加载器"""
        if loaders:
            self._loaders.extend(loaders)
            self._loaders = self._sort_and_dedupe(self._loaders)

    @add_loaders.register
    def _(self, *loaders: BaseLoader):
        if loaders:
            self._loaders.extend(loaders)
            self._loaders = self._sort_and_dedupe(self._loaders)

    @singledispatchmethod
    def remove_loaders(self, loaders: list[BaseLoader]):
        """移除加载器"""
        if loaders:
            dedupe_keys: set[str] = {loader.dedupe_key for loader in loaders}
            self._loaders = [
                loader
                for loader in self._loaders
                if loader.dedupe_key not in dedupe_keys
            ]

    @remove_loaders.register
    def _(self, *loaders: BaseLoader):
        if loaders:
            dedupe_keys: set[str] = {loader.dedupe_key for loader in loaders}
            self._loaders = [
                loader
                for loader in self._loaders
                if loader.dedupe_key not in dedupe_keys
            ]

    def clear_loaders(self) -> None:
        """清空所有加载器"""
        self._loaders = []
