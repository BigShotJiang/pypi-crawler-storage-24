"""外部配置文件加载器模块

从项目外部加载配置文件,支持从指定目录搜索配置文件。
"""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import override

from pynomad.common.dict_utils import deep_merge
from pynomad.common.environment import environ
from pynomad.common.types import AnyDict
from pynomad.config.loader.base import BASEDIR, BaseLoader, DATADIR, LoadOrder
from pynomad.config.parser.file_parser import FileParser
from pynomad.config.config_utils import expand_path_variables
from pynomad.console.logger import get_console_logger, Level

# from pynomad.naming.naming import snakeize_dict

logger = get_console_logger(level=Level.DEBUG)


class FileLocator(ABC):
    """文件定位器抽象基类

    负责在不同目录中查找配置文件,并返回路径及其优先级。
    """

    @abstractmethod
    def locate(self, patterns: list[str]) -> dict[Path, int]:
        """定位配置文件

        Args:
            patterns: 文件名模式列表,如 ["config", "settings"]

        Returns:
            dict[Path, int]: 路径到优先级的映射,优先级越小越先加载
        """

    def manages_path(self, path: Path | str) -> bool:
        """判断指定路径是否由该定位器管理

        检查给定路径是否在该定位器管理的目录或文件范围内。

        Args:
            path: 要检查的路径，可以是 Path 对象或字符串

        Returns:
            bool: 如果该路径由该定位器管理返回 True，否则返回 False
        """
        path = Path(path) if isinstance(path, str) else path
        path = path.resolve()

        # 获取所有管理的文件路径
        managed_paths = self.locate([])

        # 检查给定路径是否在管理的文件中
        if path in [p.resolve() for p in managed_paths]:
            return True

        return False


class RootDirLocator(FileLocator):
    """根目录文件定位器

    从项目根目录及其子目录中查找配置文件。
    """

    def __init__(
        self,
        root_dir: Path,
        subdirs: list[str] | None = None,
    ):
        """初始化根目录定位器

        Args:
            root_dir: 根目录路径
            subdirs: 子目录列表,默认为 ["config", "data"]
        """
        self._root = Path(root_dir)
        self._subdirs = subdirs or [
            "config",
            ".config",
            "data",
            ".data",
            ".data/config",
        ]

    @override
    def locate(self, patterns: list[str]) -> dict[Path, int]:
        """定位配置文件

        优先级顺序:
        1. 根目录 (优先级 0)
        2. config 子目录 (优先级 1)
        3. data 子目录 (优先级 2)

        Args:
            patterns: 文件名模式列表

        Returns:
            dict[Path, int]: 路径到优先级的映射
        """
        paths: dict[Path, int] = {}
        priority = 0

        # 1. 根目录
        for pattern in patterns:
            found = self._search_in_dir(self._root, pattern)
            # _search_in_dir 按扩展名优先级顺序查找 (toml > yaml > json > ini)
            # 反转列表，让低优先级的文件先添加（获得低优先级值）
            for path in reversed(found):
                paths[path] = priority
                priority += 1

        # 2. 子目录
        for subdir in self._subdirs:
            dir_path = self._root / subdir
            if dir_path.exists() and dir_path.is_dir():
                for pattern in patterns:
                    found = self._search_in_dir(dir_path, pattern)
                    # _search_in_dir 按扩展名优先级顺序查找 (toml > yaml > json > ini)
                    # 反转列表，让低优先级的文件先添加（获得低优先级值）
                    for path in reversed(found):
                        paths[path] = priority
                        priority += 1

        return paths

    @override
    def manages_path(self, path: Path | str) -> bool:
        """判断指定路径是否由该定位器管理

        检查给定路径是否在根目录或其管理的子目录中。

        Args:
            path: 要检查的路径，可以是 Path 对象或字符串

        Returns:
            bool: 如果该路径由该定位器管理返回 True，否则返回 False
        """
        path = Path(path) if isinstance(path, str) else path
        path = path.resolve()

        root = self._root.resolve()

        # 检查是否在根目录下
        try:
            _ = path.relative_to(root)
            return True
        except ValueError:
            return False

    def _search_in_dir(self, dir_path: Path, pattern: str) -> list[Path]:
        """在指定目录中搜索配置文件

        Args:
            dir_path: 目录路径
            pattern: 文件名模式

        Returns:
            list[Path]: 找到的文件路径列表
        """
        found: list[Path] = []
        parser = FileParser()

        # 如果文件名已包含扩展名,直接查找
        if "." in pattern:
            path = dir_path / pattern
            if path.exists() and path.is_file():
                if parser.supports(format_hint=path.suffix):
                    found.append(path)
        else:
            # 尝试所有支持的扩展名,按优先级顺序 (toml > yaml > json > ini)
            extensions = list(reversed(parser.get_supported_extensions()))
            for ext in extensions:
                path = dir_path / f"{pattern}{ext}"
                if path.exists() and path.is_file():
                    found.append(path)

        return found


class ExplicitFileLocator(FileLocator):
    """显式文件定位器

    定位指定的单个配置文件。
    """

    def __init__(
        self,
        file_path: Path,
    ):
        """初始化显式文件定位器

        Args:
            file_path: 配置文件路径
        """
        self._file = Path(file_path).resolve()

    @override
    def locate(self, patterns: list[str]) -> dict[Path, int]:
        """定位配置文件

        Args:
            patterns: 文件名模式列表（忽略，使用指定的文件路径）

        Returns:
            dict[Path, int]: 如果文件存在则返回路径及优先级 0，否则返回空字典
        """
        if self._file.exists() and self._file.is_file():
            return {self._file: 0}
        return {}

    @override
    def manages_path(self, path: Path | str) -> bool:
        """判断指定路径是否由该定位器管理

        检查给定路径是否为该定位器指定的文件。

        Args:
            path: 要检查的路径，可以是 Path 对象或字符串

        Returns:
            bool: 如果该路径是定位器指定的文件返回 True，否则返回 False
        """
        path = Path(path) if isinstance(path, str) else path
        path = path.resolve()
        return path == self._file


class CompositeFileLocator(FileLocator):
    """复合文件定位器

    组合多个定位器,返回所有定位器找到的配置文件。
    """

    def __init__(self, locators: list[FileLocator]):
        """初始化复合定位器

        Args:
            locators: 定位器列表,按优先级从高到低排序
        """
        self._locators = locators

    @override
    def locate(self, patterns: list[str]) -> dict[Path, int]:
        """定位配置文件

        为不同来源的配置文件添加优先级偏移,确保正确覆盖。

        Args:
            patterns: 文件名模式列表

        Returns:
            dict[Path, int]: 所有定位器找到的文件路径及优先级
        """
        all_paths: dict[Path, int] = {}
        base_offset = 0

        for locator in self._locators:
            paths = locator.locate(patterns)
            # 添加基础偏移,确保不同来源的配置能正确覆盖
            for path, priority in paths.items():
                all_paths[path] = base_offset + priority
            # 来源之间增加较大的优先级差距
            base_offset += 1000

        return all_paths

    @override
    def manages_path(self, path: Path | str) -> bool:
        """判断指定路径是否由该复合定位器管理

        检查给定路径是否被任意一个子定位器管理。

        Args:
            path: 要检查的路径，可以是 Path 对象或字符串

        Returns:
            bool: 如果该路径被任意子定位器管理返回 True，否则返回 False
        """
        for locator in self._locators:
            if locator.manages_path(path):
                return True
        return False


class FileLoader(BaseLoader):
    """外部配置文件加载器

    从项目外部加载配置文件,支持从指定目录搜索配置文件。

    Args:
        locator: 文件定位器,用于查找配置文件
        patterns: 配置文件名模式列表,默认为 ["config", "settings"]
        order: 加载优先级,默认为 LoadOrder.FILE (50)

    Examples:
        >>> from pathlib import Path
        >>> locator = RootDirLocator(Path.cwd())
        >>> loader = FileLoader(locator=locator)
        >>> config = loader.load()
    """

    def __init__(
        self,
        locator: FileLocator | None = None,
        patterns: list[str] | None = None,
        load_order: int = LoadOrder.FILE,
        name: str = "",
    ):
        """初始化文件加载器

        Args:
            locator: 文件定位器,如果为 None 则使用默认定位器
            patterns: 配置文件名模式列表
            load_order: 加载优先级
            name: 加载器名称。如果为空，则自动生成名称。
        """
        self._order = load_order

        # 如果没有提供定位器,使用默认的根目录定位器
        if locator is None:
            root_dir = Path(environ.project_dir)
            locator = RootDirLocator(root_dir)

        self._locator = locator

        # 默认配置文件名
        if patterns is None:
            project_name = environ.project_name.lower()
            patterns = [
                "pynomad",
                ".pynomad",
                "config",
                ".config",
                "setting",
                ".setting",
                "settings",
                ".settings",
                project_name,
                f".{project_name}",
            ]
        self._patterns = patterns
        self._parser = FileParser()
        self._name = name if name else f"FileLoader(patterns={self._patterns})"
        self._uri = self._build_uri()

    @property
    @override
    def order(self) -> int:
        """获取加载优先级"""
        return self._order

    @property
    @override
    def name(self) -> str:
        """获取加载器名称"""
        return self._name

    @property
    @override
    def config_uri(self) -> str:
        """获取配置 URI

        Returns:
            str: 配置文件的 URI，格式为 file://path/to/config
        """
        return self._uri

    def _build_uri(self) -> str:
        """构建配置 URI

        根据定位器类型构建相应的 URI。

        Returns:
            str: 配置 URI
        """
        if isinstance(self._locator, RootDirLocator):
            root = getattr(self._locator, "_root", None)
            if root:
                return f"file://{root.resolve()}"
        if isinstance(self._locator, ExplicitFileLocator):
            file = getattr(self._locator, "_file", None)
            if file:
                return f"file://{file.resolve()}"
        if isinstance(self._locator, CompositeFileLocator):
            uris: list[str] = []
            locators = getattr(self._locator, "_locators", [])
            for loc in locators:
                if isinstance(loc, RootDirLocator):
                    root = getattr(loc, "_root", None)
                    if root:
                        uris.append(f"file://{root.resolve()}")
                elif isinstance(loc, ExplicitFileLocator):
                    file = getattr(loc, "_file", None)
                    if file:
                        uris.append(f"file://{file.resolve()}")
            if uris:
                return ";".join(uris)
        return "file://unknown"

    @property
    def locator(self) -> FileLocator:
        """获取文件定位器

        Returns:
            FileLocator: 文件定位器实例
        """
        return self._locator

    @property
    def patterns(self) -> list[str]:
        """获取配置文件模式列表

        Returns:
            list[str]: 配置文件名模式列表
        """
        return self._patterns

    def prepend_patterns(self, new_patterns: list[str]) -> None:
        """在现有 patterns 前面添加新的模式

        注意：在 locator 中,前面的 patterns 会获得更小的 priority 值,
        意味着它们会先被加载。先加载的配置会被后加载的配置覆盖。
        如果想让新 patterns 的配置覆盖现有 patterns,请使用 append_patterns。

        Args:
            new_patterns: 要添加的新模式列表
        """
        self._patterns = new_patterns + self._patterns

    def append_patterns(self, new_patterns: list[str]) -> None:
        """在现有 patterns 后面添加新的模式

        注意：后面的 patterns 会获得更大的 priority 值,
        意味着它们会后加载。后加载的配置会覆盖先加载的配置。
        如果想让新 patterns 的配置覆盖现有 patterns,请使用此方法。

        Args:
            new_patterns: 要添加的新模式列表
        """
        self._patterns = self._patterns + new_patterns

    @override
    def supports(self) -> bool:
        """检查是否有可用的配置文件

        Returns:
            bool: 如果存在至少一个配置文件返回 True,否则返回 False
        """
        paths = self._locator.locate(self._patterns)
        return len(paths) > 0

    def manages_path(self, path: Path | str) -> bool:
        """判断指定路径是否由该 loader 管理

        委托给 locator 进行实际判断。

        Args:
            path: 要检查的路径，可以是 Path 对象或字符串

        Returns:
            bool: 如果该路径由该 loader 管理返回 True，否则返回 False

        Examples:
            >>> loader = FileLoader()
            >>> loader.manages_path("/path/to/config.toml")
            >>> # 如果该路径在 locator 管理的范围内，返回 True
        """
        return self._locator.manages_path(path)

    @override
    def load(self) -> AnyDict:
        """加载配置文件

        按优先级加载所有配置文件,后加载的配置会覆盖先加载的配置。
        加载后的配置键名会自动转换为 snake_case。

        Returns:
            AnyDict: 合并后的配置字典
        """
        merged_config: AnyDict = {}

        # 获取所有配置文件路径及优先级
        paths = self._locator.locate(self._patterns)

        # 按优先级排序
        sorted_paths = sorted(paths.items(), key=lambda x: x[1])

        for path, _ in sorted_paths:
            try:
                # 解析配置文件
                config = self._parser.parse(path)

                # 转换键名为 snake_case
                # config = snakeize_dict(config)

                # 使用深度合并配置
                merged_config = deep_merge(merged_config, config)

            except (
                FileNotFoundError,  # 文件不存在
                ValueError,  # 格式错误、不支持的格式等
                OSError,  # 文件读取错误
                KeyError,  # 配置键错误
                UnicodeDecodeError,  # 编码错误
            ) as e:
                logger.warn(f"加载配置文件失败: {path}, 错误: {e}")

        return merged_config

    @override
    def create_child_loaders(self) -> list["BaseLoader"]:
        """创建子加载器

        从已加载的配置中读取 basedir 和 datadir 配置,
        并为这些目录创建对应的文件加载器。

        Returns:
            list[BaseLoader]: 子加载器列表
        """
        config = self.load()
        child_loaders: list["BaseLoader"] = []

        # 检查 basedir 配置
        if BASEDIR in config:
            basedir_path = self._resolve_dir_path(config[BASEDIR], "basedir")
            if basedir_path is not None and basedir_path.exists():
                loader = FileLoader(
                    locator=RootDirLocator(root_dir=basedir_path),
                    load_order=self._order - 10,
                    name=f"{self._name}.basedir",
                )
                child_loaders.append(loader)
            elif basedir_path is not None:
                logger.warn(f"basedir 指定的目录不存在: {basedir_path}")

        # 检查 datadir 配置
        if DATADIR in config:
            datadir_path = self._resolve_dir_path(config[DATADIR], "datadir")
            if datadir_path is not None and datadir_path.exists():
                loader = FileLoader(
                    locator=RootDirLocator(root_dir=datadir_path),
                    load_order=self._order - 5,
                    name=f"{self._name}.datadir",
                )
                child_loaders.append(loader)
            elif datadir_path is not None:
                logger.warn(f"datadir 指定的目录不存在: {datadir_path}")

        return child_loaders

    def _resolve_dir_path(
        self, dir_config: str | list[str] | None, key: str
    ) -> Path | None:
        """解析目录路径配置

        Args:
            dir_config: 目录配置,可以是字符串或列表
            key: 配置键名(用于日志)

        Returns:
            Path | None: 解析后的路径,如果无效则返回 None
        """
        if not dir_config:
            return None

        # 如果是列表,取第一个有效路径
        if isinstance(dir_config, list):
            if not dir_config:
                return None
            dir_config = dir_config[0]

        # 展开路径变量
        try:
            path_str = str(dir_config)
            return expand_path_variables(path_str)
        except (ValueError, OSError) as e:
            logger.warn(f"解析 {key} 路径失败: {dir_config}, 错误: {e}")
            return None
