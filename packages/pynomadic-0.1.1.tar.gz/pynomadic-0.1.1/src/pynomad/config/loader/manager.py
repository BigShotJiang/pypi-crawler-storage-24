from pathlib import Path
from pynomad.common.decorator import singleton
from pynomad.common.environment import environ
from pynomad.common.types import AnyDict
from pynomad.config.loader.base import (
    ConfigContext,
    BaseLoader,
    CommandLoader,
    EnvironmentContext,
    EnvironmentLoader,
    LoadOrder,
)
from pynomad.config.loader.env_manager import EnvironmentManager
from pynomad.config.loader.file_loader import FileLoader, RootDirLocator
from pynomad.config.loader.resource_loader import ResourceLoader


@singleton
class LoaderManager:
    def __init__(self):
        """初始化加载器管理器"""
        self._context = self._collect_loaders()
        self._environment_manager = EnvironmentManager(self._context)

    # ==============================    属性区域    =============================

    @property
    def loaders(self) -> list[BaseLoader]:
        """获取加载器列表"""
        return self._context.loaders

    # ======================环境管理包装方法================================

    def get_environment_config(
        self, env_name: str | tuple[str, ...] | None = None
    ) -> AnyDict:
        """获取环境配置

        Args:
            env_name: 环境名称或环境元组,如果为 None 则使用当前活动环境

        Returns:
            AnyDict: 合并后的环境配置
        """
        return self._environment_manager.get_environment_config(env_name)

    def get_active_environment(self) -> list[EnvironmentContext]:
        """获取当前活动环境列表

        Returns:
            list[EnvironmentContext]: 活动环境对象列表
        """
        return self._environment_manager.get_active_environment()

    def get_available_environments(self) -> list[str]:
        """获取所有可用环境列表

        Returns:
            list[str]: 环境名称列表
        """
        return self._environment_manager.get_available_environments()

    def set_environment(self, env_name: str | list[str]) -> None:
        """设置活动环境

        支持设置单个或多个环境,获取配置时会按顺序合并。

        Args:
            env_name: 环境名称(字符串或列表),例如 "development" 或 ["default", "development"]
        """
        self._environment_manager.set_environment(env_name)

    @property
    def active_envs(self) -> list[str]:
        """获取活动环境列表"""
        return self._environment_manager.active_envs

    @property
    def env_configs(self) -> dict[str, AnyDict]:
        """获取所有环境配置"""
        return self._environment_manager.env_configs

    @property
    def basedir(self) -> Path:
        """获取项目基本目录

        Returns:
            Path: 项目基本目录路径
        """
        return self._environment_manager.basedir

    @property
    def datadir(self) -> Path:
        """获取数据目录

        Returns:
            Path: 数据目录路径
        """
        return self._environment_manager.datadir

    @property
    def config_uris(self) -> list[str]:
        """获取配置 URI 列表

        Returns:
            list[str]: 配置 URI 列表
        """
        return self._environment_manager.config_uris

    # ============================加载器收集=====================================
    def _create_default_loaders(self) -> list[BaseLoader]:
        """初始化默认加载器列表

        按优先级顺序初始化各种配置加载器：
        1. 命令行加载器 (优先级 10) - 用户级配置
        2. 环境变量加载器 (优先级 19-20) - 环境级配置
        3. 文件加载器 (优先级 40-50) - 外部文件级配置
        4. 资源加载器 (优先级 sys.maxsize) - 应用级配置，保底手段

        Returns:
            list[BaseLoader]: 加载器列表
        """
        loaders: list[BaseLoader] = []

        # 1. 命令行加载器 (优先级: 10)
        loaders.append(CommandLoader(name="默认命令行"))
        # 2. 环境变量加载器 (优先级: 19-20)
        loaders.extend(self._create_default_environment_loaders())

        # 3. 文件加载器 (优先级: 40-50)
        loaders.extend(self._create_default_file_loaders())

        # 4. 资源加载器 (优先级: sys.maxsize) - 保底手段，应用内置配置
        loaders.append(
            ResourceLoader(
                use_builtins_anchor=True,
                load_order=LoadOrder.RESOURCE,
                name="内置资源",
            )
        )

        return loaders

    def _create_default_environment_loaders(self) -> list[EnvironmentLoader]:
        """创建环境变量加载器

        Returns:
            list[EnvironmentLoader]: 环境变量加载器列表
        """
        loaders: list[EnvironmentLoader] = []

        # 框架级环境变量加载器 (优先级: 20)
        loaders.append(
            EnvironmentLoader(
                prefix="PYNOMAD_",
                order=LoadOrder.ENVIRONMENT,
                name="pynomad环境变量",
            )
        )

        # 项目级环境变量加载器 (优先级: 19)
        loaders.append(
            EnvironmentLoader(
                prefix=f"{environ.project_name}_".upper(),
                order=LoadOrder.ENVIRONMENT - 1,
                name=f"{environ.project_name}环境变量",
            )
        )

        return loaders

    def _create_default_file_loaders(self) -> list[FileLoader]:
        """创建文件加载器

        包括项目内部加载器和外部配置目录加载器。

        Returns:
            list[FileLoader]: 文件加载器列表
        """
        loaders: list[FileLoader] = []
        load_order = LoadOrder.FILE

        # 项目内部加载器 (优先级: 50)
        loaders.append(
            FileLoader(
                load_order=load_order,
                name=f"{environ.project_name}工作区",
            )
        )
        load_order -= 1

        # 外部配置目录加载器 (优先级: 40-49)
        for root_dir, desc in self._get_default_config_dirs():
            loader = self._create_file_loader(root_dir, desc, load_order)
            loaders.append(loader)
            load_order -= 1
        return loaders

    def _get_default_config_dirs(self) -> list[tuple[Path, str]]:
        """获取配置目录列表

        Returns:
            list[tuple[Path, str]]: (目录路径, 描述) 元组列表
        """
        return [
            (environ.home / environ.project_name, "用户目录"),
            (environ.localdata / environ.project_name, "本地数据目录"),
            (environ.config_home / environ.project_name, "配置目录"),
        ]

    def _create_file_loader(
        self, root_dir: Path, desc: str, load_order: int
    ) -> FileLoader:
        """创建文件加载器

        Args:
            root_dir: 根目录
            desc: 描述
            load_order: 加载优先级

        Returns:
            FileLoader: 文件加载器实例
        """
        subdirs = [
            "pynomad",
            ".pynomad",
            environ.project_name,
            f".{environ.project_name}",
        ]
        locator = RootDirLocator(root_dir=root_dir, subdirs=subdirs)
        return FileLoader(
            load_order=load_order,
            locator=locator,
            name=desc,
        )

    def _discover_loaders(self, loaders: list[BaseLoader]) -> list[BaseLoader]:
        """动态发现子加载器

        遍历所有加载器,调用它们的 create_child_loaders() 方法,
        收集所有子加载器,不做去重判断(去重在 _collect_loaders 中统一处理)。

        Args:
            loaders: 现有的加载器列表

        Returns:
            list[BaseLoader]: 发现的子加载器列表
        """
        # 简单收集所有子加载器,不做任何去重判断
        child_loaders: list[BaseLoader] = []

        for loader in loaders:
            discovered = loader.create_child_loaders()

            if not discovered:
                continue

            # 直接添加所有子加载器,不做任何去重判断
            child_loaders.extend(discovered)
        return child_loaders

    def _collect_loaders(self) -> ConfigContext:
        """收集所有加载器并添加到 ConfigContext

        包括:
        1. 初始化默认加载器
        2. 动态发现子加载器
        3. 添加到 ConfigContext (自动去重和排序)
        """
        # 第一步: 初始化默认加载器
        loaders: list[BaseLoader] = self._create_default_loaders()

        # 第二步: 动态发现子加载器(简单收集,不去重)
        loaders.extend(self._discover_loaders(loaders))

        # 第三步: 添加到 ConfigContext (自动去重和排序)
        return ConfigContext(loaders)


loadermanager = LoaderManager()


def get_config():
    """获取配置"""
    return loadermanager.get_environment_config()
