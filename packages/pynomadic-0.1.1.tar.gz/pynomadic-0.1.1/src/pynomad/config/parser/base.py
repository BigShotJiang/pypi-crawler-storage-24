"""配置文件解析器基类模块

定义配置文件解析器的抽象基类和统一接口。

解析器架构：
- ConfigParser: 抽象基类，定义统一接口

设计原则：
1. 统一的解析接口，便于扩展和使用
2. 优雅降级，解析失败时返回空字典或抛出有意义的异常
3. 类型注解完整，支持静态类型检查

Note:
    - JSON 和 INI 解析器已移至 common_parser.py
    - TOML 相关的解析器已移至 toml_parser.py
"""

from abc import ABC, abstractmethod
from pathlib import Path

from pynomad.common.types import AnyDict


class ConfigParser(ABC):
    """配置文件解析器抽象基类

    定义了所有配置文件解析器必须实现的接口，支持扩展不同格式的配置文件。

    Attributes:
        extensions: 支持的文件扩展名列表

    Notes:
        解析器设计原则：
        1. 每个解析器负责处理特定格式的配置文件
        2. 通过注册机制实现解析器的动态扩展
        3. 支持文件不存在时的优雅降级
        4. 统一的解析接口，便于使用和测试

    Examples:
        >>> from pynomad.config.parser.base import ConfigParser
        >>>
        >>> class MyParser(ConfigParser):
        ...     extensions = [".custom"]
        ...
        ...     def parse(self, file_path: Path) -> AnyDict:
        ...         # 实现自定义格式的解析逻辑
        ...         return {"key": "value"}
    """

    @property
    @abstractmethod
    def extensions(self) -> list[str]:
        """获取支持的文件扩展名列表

        Returns:
            list[str]: 支持的文件扩展名，如 [".json", ".yaml"]

        Notes:
            - 扩展名应包含点号前缀
            - 比较时不区分大小写
            - 一个解析器可以支持多个扩展名

        Examples:
            >>> class MyParser(ConfigParser):
            ...     @property
            ...     def extensions(self) -> list[str]:
            ...         return [".custom", ".cfg"]
        """

    @abstractmethod
    def parse(self, file_path: Path) -> AnyDict:
        """解析配置文件

        Args:
            file_path: 配置文件路径

        Returns:
            AnyDict: 解析后的配置字典

        Raises:
            FileNotFoundError: 当配置文件不存在时
            ValueError: 当配置文件格式错误时
            NotImplementedError: 子类必须实现此方法

        Notes:
            - 解析器应该处理文件不存在的情况
            - 建议使用 try-except 捕获文件读取异常
            - 解析失败时应抛出有意义的异常信息

        Examples:
            >>> parser = MyParser()
            >>> config = parser.parse(Path("config.json"))
            >>> print(config["key"])  # 输出: value
        """

    @abstractmethod
    def parse_text(
        self, text: str, *, format_hint: str | None = None
    ) -> AnyDict:
        """解析配置文本内容

        从字符串中解析配置数据，无需读取文件。

        Args:
            text: 配置文件文本内容
            format_hint: 格式提示（如 '.json', '.yaml'），用于代理类选择解析器，
                       具体解析器可以忽略此参数

        Returns:
            AnyDict: 解析后的配置字典

        Raises:
            ValueError: 当配置文本格式错误时
            NotImplementedError: 子类必须实现此方法

        Notes:
            - 该方法与 parse 方法功能类似，但直接处理字符串
            - 适用于配置内容已在内存中的场景
            - format_hint 参数主要用于 FileParser 等代理类选择合适的解析器
            - 具体解析器（如 JsonParser、YamlParser）可以忽略此参数

        Examples:
            >>> parser = JsonParser()
            >>> text = '{"key": "value"}'
            >>> config = parser.parse_text(text)
            >>> print(config["key"])  # 输出: value
        """

    def supports(
        self, file_path: Path | None = None, *, format_hint: str | None = None
    ) -> bool:
        """检查是否支持该文件格式

        Args:
            file_path: 文件路径，通过扩展名检查是否支持
            format_hint: 格式提示（如 '.json', '.yaml'），通过扩展名检查是否支持

        Returns:
            bool: 如果支持该文件格式返回 True，否则返回 False

        Notes:
            - file_path 和 format_hint 至少需要提供一个
            - 两个都提供时，使用 file_path 的扩展名
            - 具体解析器通过扩展名判断是否支持

        Examples:
            >>> parser = MyParser()
            >>> print(parser.supports(Path("config.custom")))  # 输出: True
            >>> print(parser.supports(Path("config.json")))    # 输出: False
            >>> print(parser.supports(format_hint=".custom"))    # 输出: True
        """
        if file_path is None and format_hint is None:
            raise ValueError("至少需要提供 file_path 或 format_hint 参数")

        # 优先使用 file_path 的扩展名
        if file_path is not None:
            return file_path.suffix.lower() in self.extensions

        # 使用 format_hint（需要包含点号）
        hint = format_hint.lower() if format_hint else ""
        if not hint.startswith("."):
            hint = f".{hint}"
        return hint in self.extensions
