"""文件解析器工厂模块

提供统一的文件解析器注册和获取接口，支持多种配置文件格式。

设计原则：
1. 统一的注册机制，便于扩展新的解析器
2. 自动根据文件扩展名选择合适的解析器
3. 支持解析器的优先级管理
4. 类型注解完整，支持静态类型检查

使用示例：
    >>> from pynomad.config.parser import FileParser
    >>>
    >>> # 方式1：作为工厂使用
    >>> parser = FileParser.get_parser(Path("config.json"))
    >>> config = parser.parse(Path("config.json"))
    >>>
    >>> # 方式2：直接作为解析器使用（代理模式）
    >>> parser = FileParser()
    >>> config = parser.parse(Path("config.json"))
"""

from pathlib import Path
from typing import override

from pynomad.common.types import AnyDict
from pynomad.config.parser.base import ConfigParser


# 解析器注册表
_PARSER_REGISTRY: dict[str, ConfigParser] = {}


def register_parser(parser: ConfigParser) -> None:
    """注册解析器

    Args:
        parser: 解析器实例

    Notes:
        - 自动注册解析器支持的所有扩展名
        - 如果扩展名已被注册，会覆盖原有解析器

    Examples:
        >>> from pynomad.config.parser import JsonParser, register_parser
        >>>
        >>> parser = JsonParser()
        >>> register_parser(parser)
    """
    for ext in parser.extensions:
        normalized_ext = ext.lower()
        _PARSER_REGISTRY[normalized_ext] = parser


def unregister_parser(extension: str) -> None:
    """注销解析器

    Args:
        extension: 要注销的文件扩展名

    Examples:
        >>> from pynomad.config.parser import unregister_parser
        >>>
        >>> unregister_parser(".json")
    """
    normalized_ext = extension.lower()
    _ = _PARSER_REGISTRY.pop(normalized_ext, None)


def get_parser(file_path: Path) -> ConfigParser:
    """根据文件路径获取解析器

    Args:
        file_path: 配置文件路径

    Returns:
        ConfigParser: 解析器实例

    Raises:
        ValueError: 没有找到合适的解析器

    Notes:
        - 根据文件扩展名查找注册的解析器
        - 扩展名匹配不区分大小写

    Examples:
        >>> from pynomad.config.parser import get_parser
        >>> from pathlib import Path
        >>>
        >>> parser = get_parser(Path("config.json"))
        >>> config = parser.parse(Path("config.json"))
    """
    ext = file_path.suffix.lower()
    parser = _PARSER_REGISTRY.get(ext)
    if parser is None:
        raise ValueError(
            f"不支持的配置文件格式: {ext}。"  # pyright: ignore[reportImplicitStringConcatenation]
            f"支持的格式: {list(_PARSER_REGISTRY.keys())}"
        )
    return parser


def get_supported_extensions() -> list[str]:
    """获取所有支持的文件扩展名

    Returns:
        list[str]: 支持的文件扩展名列表

    Examples:
        >>> from pynomad.config.parser import get_supported_extensions
        >>>
        >>> extensions = get_supported_extensions()
        >>> print(extensions)  # 输出: ['.json', '.yaml', '.yml', '.tom', '.toml', '.ini']
    """
    return list(_PARSER_REGISTRY.keys())


def is_supported(file_path: Path) -> bool:
    """检查文件格式是否支持

    Args:
        file_path: 文件路径

    Returns:
        bool: 如果支持返回 True，否则返回 False

    Examples:
        >>> from pynomad.config.parser import is_supported
        >>> from pathlib import Path
        >>>
        >>> print(is_supported(Path("config.json")))  # 输出: True
        >>> print(is_supported(Path("config.xml")))  # 输出: False
    """
    return file_path.suffix.lower() in _PARSER_REGISTRY


class FileParser(ConfigParser):
    """文件解析器工厂类（代理模式）

    提供统一的解析器管理接口，同时自身也可以作为解析器使用。

    设计模式：
    - 工厂模式：提供静态方法创建和管理解析器实例
    - 代理模式：自身作为 ConfigParser 的代理，自动委托给合适的解析器

    Notes:
        - 使用注册表模式管理解析器
        - 自动初始化默认解析器
        - 可直接作为解析器使用，自动根据文件扩展名选择合适的解析器

    Examples:
        >>> from pynomad.config.parser import FileParser
        >>> from pathlib import Path
        >>>
        >>> # 方式1：作为工厂使用
        >>> parser = FileParser.get_parser(Path("config.json"))
        >>> config = parser.parse(Path("config.json"))
        >>>
        >>> # 方式2：直接作为解析器使用
        >>> parser = FileParser()
        >>> config = parser.parse(Path("config.yaml"))
    """

    @staticmethod
    def register(parser: ConfigParser) -> None:
        """注册解析器

        Args:
            parser: 解析器实例

        Examples:
            >>> from pynomad.config.parser import FileParser, JsonParser
            >>>
            >>> parser = JsonParser()
            FileParser.register(parser)
        """
        register_parser(parser)

    @staticmethod
    def unregister(extension: str) -> None:
        """注销解析器

        Args:
            extension: 要注销的文件扩展名

        Examples:
            >>> from pynomad.config.parser import FileParser
            >>>
            FileParser.unregister(".json")
        """
        unregister_parser(extension)

    @staticmethod
    def get_parser(file_path: Path) -> ConfigParser:
        """根据文件路径获取解析器

        Args:
            file_path: 配置文件路径

        Returns:
            ConfigParser: 解析器实例

        Raises:
            ValueError: 没有找到合适的解析器

        Examples:
            >>> from pynomad.config.parser import FileParser
            >>> from pathlib import Path
            >>>
            >>> parser = FileParser.get_parser(Path("config.json"))
            >>> config = parser.parse(Path("config.json"))
        """
        return get_parser(file_path)

    @staticmethod
    def get_supported_extensions() -> list[str]:
        """获取所有支持的文件扩展名

        Returns:
            list[str]: 支持的文件扩展名列表

        Examples:
            >>> from pynomad.config.parser import FileParser
            >>>
            >>> extensions = FileParser.get_supported_extensions()
            >>> print(extensions)
        """
        return get_supported_extensions()

    @staticmethod
    def is_supported(file_path: Path) -> bool:
        """检查文件格式是否支持

        Args:
            file_path: 文件路径

        Returns:
            bool: 如果支持返回 True，否则返回 False

        Examples:
            >>> from pynomad.config.parser import FileParser
            >>> from pathlib import Path
            >>>
            >>> print(FileParser.is_supported(Path("config.json")))
        """
        return is_supported(file_path)

    @property
    @override
    def extensions(self) -> list[str]:
        """获取支持的文件扩展名

        Returns:
            list[str]: 所有注册解析器支持的扩展名

        Examples:
            >>> parser = FileParser()
            >>> print(parser.extensions)  # 输出: ['.json', '.yaml', '.yml', '.tom', '.toml', '.ini']
        """
        return self.get_supported_extensions()

    @override
    def parse_text(
        self, text: str, *, format_hint: str | None = None
    ) -> AnyDict:
        """解析配置文本内容（代理模式）

        自动根据文件格式选择合适的解析器进行解析。

        Args:
            text: 配置文件文本内容
            format_hint: 格式提示（如 '.json', '.yaml'），必须提供此参数以确定使用哪个解析器

        Returns:
            AnyDict: 解析后的配置字典

        Raises:
            ValueError: 文件格式不支持

        Notes:
            - 必须提供 format_hint 参数以确定使用哪个解析器
            - 如果不提供 format_hint，无法从纯文本推断格式

        Examples:
            >>> parser = FileParser()
            >>> text = '{"key": "value"}'
            >>> config = parser.parse_text(text, format_hint=".json")
            >>> print(config["key"])  # 输出: value
        """
        if not format_hint:
            raise ValueError("配置文件类型不能为空")
        # 根据扩展名获取解析器
        parser = _PARSER_REGISTRY.get(format_hint.lower())
        if parser is None:
            raise ValueError(f"不支持的配置文件格式: {format_hint}")

        # 使用解析器的 parse_text 方法，不传递 format_hint（具体解析器不需要）
        return parser.parse_text(text)

    @override
    def parse(self, file_path: Path) -> AnyDict:
        """解析配置文件（代理模式）

        自动根据文件扩展名选择合适的解析器进行解析。

        Args:
            file_path: 配置文件路径

        Returns:
            AnyDict: 解析后的配置字典

        Raises:
            ValueError: 文件格式不支持

        Examples:
            >>> parser = FileParser()
            >>> config = parser.parse(Path("config.json"))
            >>> print(config)
        """
        parser = self.get_parser(file_path)
        return parser.parse(file_path)


def _init_default_parsers() -> None:
    """初始化默认解析器

    Notes:
        - 注册所有内置的解析器
        - 在模块导入时自动调用
    """
    # 延迟导入以避免循环依赖
    from pynomad.config.parser.common_parser import (  # pylint:disable=C0415
        IniParser,
        JsonParser,
    )
    from pynomad.config.parser.toml_parser import (  # pylint:disable=C0415
        TomlParser,
    )
    from pynomad.config.parser.yaml_parser import (  # pylint:disable=C0415
        YamlParser,
    )

    # 注册默认解析器 (按优先级从低到高注册,方便通过 reversed 获取正确顺序)
    # 优先级顺序: toml > yaml > json > ini
    register_parser(IniParser())
    register_parser(JsonParser())
    register_parser(YamlParser())
    register_parser(TomlParser())


# 自动初始化默认解析器
_init_default_parsers()
