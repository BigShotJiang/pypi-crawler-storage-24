"""常用配置文件解析器模块

提供 JSON、INI 等常见格式的配置文件解析器。

解析器架构：
- JsonParser: JSON 格式解析器
- IniParser: INI 格式解析器

设计原则：
1. 统一的解析接口，便于扩展和使用
2. 优雅降级，解析失败时返回空字典或抛出有意义的异常
3. 类型注解完整，支持静态类型检查
"""

import configparser
import json
from pathlib import Path
from typing import override

from pynomad.common.serializer import load_dict_from_ini
from pynomad.common.types import AnyDict
from pynomad.config.parser.base import ConfigParser


class JsonParser(ConfigParser):
    """JSON 配置文件解析器

    解析 JSON (JavaScript Object Notation) 格式的配置文件。

    Notes:
        - 支持 UTF-8 编码
        - 标准 JSON 格式，不支持注释
        - 支持嵌套对象和数组

    Examples:
        >>> from pynomad.config.parser.common_parser import JsonParser
        >>>
        >>> parser = JsonParser()
        >>> config = parser.parse(Path("config.json"))
        >>> print(parser.extensions)  # 输出: ['.json']
        >>> print(parser.supports(Path("config.json")))  # 输出: True
    """

    @property
    @override
    def extensions(self) -> list[str]:
        """获取支持的文件扩展名

        Returns:
            list[str]: [".json"]

        Examples:
            >>> parser = JsonParser()
            >>> print(parser.extensions)  # 输出: ['.json']
        """
        return [".json"]

    @override
    def parse(self, file_path: Path) -> AnyDict:
        """解析 JSON 配置文件

        Args:
            file_path: JSON 文件路径

        Returns:
            AnyDict: 解析后的配置字典

        Raises:
            FileNotFoundError: 文件不存在
            ValueError: JSON 格式错误

        Notes:
            - 文件必须使用 UTF-8 编码
            - 格式错误时会抛出包含详细信息的异常

        Examples:
            >>> parser = JsonParser()
            >>> # 假设 config.json 内容: {"database": {"host": "localhost"}}
            >>> config = parser.parse(Path("config.json"))
            >>> print(config["database"]["host"])  # 输出: localhost
        """
        if not file_path.exists():
            raise FileNotFoundError(f"配置文件不存在: {file_path}")
        try:
            with open(file_path, encoding="utf-8") as f:
                return json.load(f)
        except json.JSONDecodeError as e:
            raise ValueError(f"JSON 格式错误: {file_path} - {e}") from e

    @override
    def parse_text(
        self, text: str, *, format_hint: str | None = None
    ) -> AnyDict:
        """解析 JSON 配置文本

        Args:
            text: JSON 格式的字符串
            format_hint: 格式提示，用于代理类选择解析器（此解析器忽略此参数）

        Returns:
            AnyDict: 解析后的配置字典

        Raises:
            ValueError: JSON 格式错误

        Notes:
            - 字符串必须是有效的 JSON 格式
            - 使用 json.loads 进行解析
            - format_hint 参数在此解析器中未使用

        Examples:
            >>> parser = JsonParser()
            >>> text = '{"database": {"host": "localhost"}}'
            >>> config = parser.parse_text(text)
            >>> print(config["database"]["host"])  # 输出: localhost
        """
        _ = format_hint
        try:
            return json.loads(text)
        except json.JSONDecodeError as e:
            raise ValueError(f"JSON 格式错误: {e}") from e

    @override
    def supports(
        self, file_path: Path | None = None, *, format_hint: str | None = None
    ) -> bool:
        """检查是否支持该文件格式

        Args:
            file_path: 文件路径
            format_hint: 格式提示（如 '.json'）

        Returns:
            bool: 如果支持该文件格式返回 True，否则返回 False

        Notes:
            - file_path 和 format_hint 至少需要提供一个

        Examples:
            >>> parser = JsonParser()
            >>> print(parser.supports(Path("config.json")))  # 输出: True
            >>> print(parser.supports(Path("config.toml")))  # 输出: False
            >>> print(parser.supports(format_hint=".json"))  # 输出: True
        """
        # 优先使用 file_path 的扩展名
        if file_path is not None:
            return file_path.suffix.lower() in self.extensions

        # 使用 format_hint（需要包含点号）
        hint = format_hint.lower() if format_hint else ""
        if not hint.startswith("."):
            hint = f".{hint}"
        return hint in self.extensions


class IniParser(ConfigParser):
    """INI 配置文件解析器

    解析 INI (Initialization) 格式的配置文件。

    INI 文件格式示例：
        [DEFAULT]
        key1 = value1

        [section1]
        key2 = value2

        [section1.subsection]
        key3 = value3

    Notes:
        - INI 文件的层级结构会被转换为嵌套字典
        - 支持 [section.subsection] 这种嵌套节名
        - 支持键名中使用点号分隔，如 key.subkey = value
        - DEFAULT 部分的值作为顶层键
        - 支持注释（分号 ; 或井号 # 开头）
        - 键名和值会自动去除首尾空格
        - 复用 common.serializer 中的实现逻辑

    Examples:
        >>> from pynomad.config.parser.common_parser import IniParser
        >>>
        >>> parser = IniParser()
        >>> config = parser.parse(Path("config.ini"))
        >>> print(parser.extensions)  # 输出: ['.ini']
    """

    @property
    @override
    def extensions(self) -> list[str]:
        """获取支持的文件扩展名

        Returns:
            list[str]: [".ini"]

        Examples:
            >>> parser = IniParser()
            >>> print(parser.extensions)  # 输出: ['.ini']
        """
        return [".ini"]

    def _parse_ini_string(self, text: str) -> AnyDict:
        """解析 INI 格式字符串为嵌套字典

        复用 serializer.load_dict_from_ini 的核心逻辑。

        Args:
            text: INI 格式的字符串

        Returns:
            AnyDict: 解析后的嵌套字典
                - DEFAULT section 的值作为顶层键
                - [section.subsection] 转换为嵌套字典
                - 键名中的点号也转换为嵌套字典

        Raises:
            ValueError: INI 格式错误

        Notes:
            - 支持嵌套节名，如 [database.primary]
            - 支持嵌套键名，如 host.ip = 127.0.0.1
        """
        config = configparser.ConfigParser()
        try:
            config.read_string(text)
        except (configparser.Error, OSError) as e:
            raise ValueError(f"INI 格式错误: {e}") from e

        result: AnyDict = {}

        # 处理 DEFAULT section
        if "DEFAULT" in config:
            for key, value in config["DEFAULT"].items():
                result[key] = value

        # 处理其他 sections
        for section_name in config.sections():
            # 处理 section 名称中的点号分隔，转换为嵌套字典
            if "." in section_name:
                section_keys = section_name.split(".")
                current = result
                for k in section_keys[:-1]:
                    if k not in current:
                        current[k] = {}
                    current = current[k]
                # 在最深层级创建字典
                if section_keys[-1] not in current:
                    current[section_keys[-1]] = {}
                section_dict = current[section_keys[-1]]
            else:
                if section_name not in result:
                    result[section_name] = {}
                section_dict = result[section_name]

            # 处理 section 中的键值对
            for key, value in config[section_name].items():
                # 处理点号分隔的键
                if "." in key:
                    # 将点号分隔的键转换为嵌套字典
                    keys = key.split(".")
                    current = section_dict
                    for k in keys[:-1]:
                        if k not in current:
                            current[k] = {}
                        current = current[k]
                    current[keys[-1]] = value
                else:
                    section_dict[key] = value

        return result

    def _preprocess_ini_text(self, text: str) -> str:
        """预处理 INI 文本，增强容错能力

        处理以下情况:
        - 去除每行的前导空白字符(容忍键名前有空格的格式)
        - 保留空行和只包含空白的行
        - 保留节标记的原有格式

        Args:
            text: 原始 INI 文本

        Returns:
            str: 预处理后的 INI 文本

        Examples:
            >>> parser = IniParser()
            >>> text = "  key = value"
            >>> cleaned = parser._preprocess_ini_text(text)
            >>> assert cleaned == "key = value"
        """
        lines: list[str] = []
        for line in text.split("\n"):
            # 跳过空行或只包含空白的行
            if not line or line.isspace():
                lines.append(line)
                continue

            # 检查是否为节标记
            stripped = line.lstrip()
            if stripped.startswith("["):
                # 节标记，保持原样
                lines.append(stripped)
            else:
                # 其他行去除前导空白
                lines.append(stripped)

        return "\n".join(lines)

    @override
    def parse(self, file_path: Path) -> AnyDict:
        """解析 INI 配置文件

        Args:
            file_path: INI 文件路径

        Returns:
            AnyDict: 解析后的配置字典
                - DEFAULT section 的值作为顶层键
                - [section.subsection] 转换为嵌套字典
                - 键名中的点号也转换为嵌套字典

        Raises:
            FileNotFoundError: 文件不存在
            ValueError: INI 格式错误

        Notes:
            - 文件必须使用 UTF-8 编码
            - 支持嵌套节名，如 [database.primary]
            - 支持嵌套键名，如 host.ip = 127.0.0.1
            - 增强容错：自动去除键名前的空白字符

        Examples:
            >>> parser = IniParser()
            >>> # 假设 config.ini 内容:
            >>> # [DEFAULT]
            >>> # app_name = myapp
            >>> # [database.primary]
            >>> # host = localhost
            >>> config = parser.parse(Path("config.ini"))
            >>> print(config["database"]["primary"]["host"])  # 输出: localhost
        """
        return load_dict_from_ini(file_path)

    @override
    def parse_text(
        self, text: str, *, format_hint: str | None = None
    ) -> AnyDict:
        """解析 INI 配置文本

        Args:
            text: INI 格式的字符串
            format_hint: 格式提示，用于代理类选择解析器（此解析器忽略此参数）

        Returns:
            AnyDict: 解析后的配置字典
                - DEFAULT section 的值作为顶层键
                - [section.subsection] 转换为嵌套字典
                - 键名中的点号也转换为嵌套字典

        Raises:
            ValueError: INI 格式错误

        Notes:
            - 支持嵌套节名，如 [database.primary]
            - 支持嵌套键名，如 host.ip = 127.0.0.1
            - 与 parse 方法行为一致
            - format_hint 参数在此解析器中未使用
            - 增强容错：自动去除键名前的空白字符

        Examples:
            >>> parser = IniParser()
            >>> text = '''
            ... [DEFAULT]
            ... app_name = myapp
            ... [database.primary]
            ... host = localhost
            ... '''
            >>> config = parser.parse_text(text)
            >>> print(config["database"]["primary"]["host"])  # 输出: localhost
        """
        _ = format_hint

        # 预处理文本，增强容错能力
        text = self._preprocess_ini_text(text)

        # 使用内部解析方法
        return self._parse_ini_string(text)

    @override
    def supports(
        self, file_path: Path | None = None, *, format_hint: str | None = None
    ) -> bool:
        """检查是否支持该文件格式

        Args:
            file_path: 文件路径
            format_hint: 格式提示（如 '.ini'）

        Returns:
            bool: 如果支持该文件格式返回 True，否则返回 False

        Notes:
            - file_path 和 format_hint 至少需要提供一个

        Examples:
            >>> parser = IniParser()
            >>> print(parser.supports(Path("config.ini")))  # 输出: True
            >>> print(parser.supports(Path("config.json")))  # 输出: False
            >>> print(parser.supports(format_hint=".ini"))  # 输出: True
        """
        # 优先使用 file_path 的扩展名
        if file_path is not None:
            return file_path.suffix.lower() in self.extensions

        # 使用 format_hint（需要包含点号）
        hint = format_hint.lower() if format_hint else ""
        if not hint.startswith("."):
            hint = f".{hint}"
        return hint in self.extensions
