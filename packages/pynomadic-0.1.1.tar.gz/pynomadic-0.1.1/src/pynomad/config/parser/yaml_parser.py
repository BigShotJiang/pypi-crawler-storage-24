"""YAML 配置文件解析器模块

提供 YAML (YAML Ain't Markup Language) 格式的配置文件解析器。

解析器架构：
- BaseYamlParser: YAML 格式解析器基类
- YamlParser: YAML 工厂解析器，自动选择最佳实现
- PyYamlParser: 使用 PyYAML 库的 YAML 解析器
- RuamelYamlParser: 使用 ruamel.yaml 库的 YAML 解析器

设计原则：
1. 统一的解析接口，便于扩展和使用
2. 环境感知，根据运行环境自动选择解析器
3. 优雅降级，解析失败时返回空字典或抛出有意义的异常
4. 类型注解完整，支持静态类型检查

YAML 解析器选择策略：
- 优先使用 PyYamlParser（广泛使用）
- 降级使用 RuamelYamlParser（需要安装 ruamel.yaml）
- 两者都不可用时返回空字典或抛出异常
"""

from abc import abstractmethod
from functools import cached_property
from pathlib import Path
from types import ModuleType
from typing import final, IO, override

from pynomad.common.types import AnyDict
from pynomad.config.parser.base import ConfigParser


class BaseYamlParser(ConfigParser):
    """YAML 解析器基类

    提供了所有 YAML 解析器的通用接口和基础实现。

    YAML (YAML Ain't Markup Language) 是一种人类可读的数据序列化格式。

    Notes:
        - 抽象基类，不能直接实例化
        - 子类必须实现 support_environment、load 和 loads 方法
        - 根据运行环境自动判断是否可用（依赖库是否安装）
        - extensions 和 supports 方法已提供最终实现，子类不能重写

    Examples:
        >>> # PyYamlParser 是 BaseYamlParser 的实现
        >>> from pynomad.config.parser.yaml_parser import PyYamlParser
        >>>
        >>> parser = PyYamlParser()
        >>> if parser.support_environment:
        ...     print("YAML 解析器可用")
    """

    @property
    @final
    @override
    def extensions(self) -> list[str]:
        """获取支持的文件扩展名

        Returns:
            list[str]: [".yaml", ".yml"]

        Notes:
            - @final 装饰器表示子类不能重写此方法
            - 同时支持 .yaml 和 .yml 两种扩展名

        Examples:
            >>> class MyYamlParser(BaseYamlParser):
            ...     pass
            >>> print(MyYamlParser().extensions)  # 输出: ['.yaml', '.yml']
        """
        return [".yaml", ".yml"]

    @property
    @abstractmethod
    def support_environment(self) -> bool:
        """检查是否支持当前运行环境

        Returns:
            bool: 如果支持当前运行环境返回 True，否则返回 False

        Notes:
            - 用于检查所需的依赖是否可用
            - 例如：PyYamlParser 需要 PyYAML 库
            - 不支持时 supports 方法会返回 False

        Examples:
            >>> parser = PyYamlParser()
            >>> print(parser.support_environment)  # 已安装 PyYAML 输出: True
        """
        return True

    @final
    @override
    def supports(
        self, file_path: Path | None = None, *, format_hint: str | None = None
    ) -> bool:
        """检查是否支持该文件格式

        Args:
            file_path: 文件路径
            format_hint: 格式提示（如 '.yaml', '.yml'）

        Returns:
            bool: 如果支持当前环境且文件扩展名匹配返回 True，否则返回 False

        Notes:
            - @final 装饰器表示子类不能重写此方法
            - 先检查环境支持，再检查文件扩展名
            - file_path 和 format_hint 至少需要提供一个

        Examples:
            >>> parser = PyYamlParser()
            >>> parser.supports(Path("config.yaml"))  # 已安装 PyYAML 输出: True
            >>> parser.supports(Path("config.json"))  # 输出: False
            >>> parser.supports(format_hint=".yaml"))  # 输出: True
        """
        if not self.support_environment:
            return False

        # 优先使用 file_path 的扩展名
        if file_path is not None:
            return file_path.suffix.lower() in self.extensions

        # 使用 format_hint（需要包含点号）
        hint = format_hint.lower() if format_hint else ""
        if not hint.startswith("."):
            hint = f".{hint}"
        return hint in self.extensions

    @abstractmethod
    def load(self, fp: IO[str], /) -> AnyDict:
        """从文件对象加载 YAML 配置

        Args:
            fp: 文件对象（文本模式）

        Returns:
            AnyDict: 解析后的配置字典

        Notes:
            - 文件对象必须以文本模式打开
            - 子类必须实现此方法

        Examples:
            >>> parser = PyYamlParser()
            >>> with open("config.yaml", "r", encoding="utf-8") as f:
            ...     config = parser.load(f)
        """

    @abstractmethod
    def loads(self, s: str, /) -> AnyDict:
        """从字符串加载 YAML 配置

        Args:
            s: YAML 格式的字符串

        Returns:
            AnyDict: 解析后的配置字典

        Notes:
            - 字符串必须是有效的 YAML 格式
            - 子类必须实现此方法

        Examples:
            >>> parser = PyYamlParser()
            >>> yaml_str = '''
            ... database:
            ...   host: localhost
            ...   port: 5432
            ... '''
            >>> config = parser.loads(yaml_str)
            >>> print(config["database"]["host"])  # 输出: localhost
        """

    @override
    def parse(self, file_path: Path) -> AnyDict:
        """解析 YAML 配置文件

        Args:
            file_path: YAML 文件路径

        Returns:
            AnyDict: 解析后的配置字典

        Raises:
            FileNotFoundError: 文件不存在
            ValueError: YAML 格式错误或环境不支持

        Notes:
            - 使用 load 方法实现文件解析
            - 子类应实现 load 方法提供实际解析逻辑
            - 如果环境不支持，子类的 load 方法应抛出异常

        Examples:
            >>> parser = PyYamlParser()
            >>> config = parser.parse(Path("config.yaml"))
            >>> print(config["database"]["host"])
        """
        if not file_path.exists():
            raise FileNotFoundError(f"配置文件不存在: {file_path}")

        try:
            with open(file_path, encoding="utf-8") as f:
                return self.load(f)
        except FileNotFoundError:
            raise  # noqa: B904
        except OSError as e:
            raise ValueError(f"文件读取错误: {file_path} - {e}") from e


@final
class PyYamlParser(BaseYamlParser):
    """使用 PyYAML 库加载 YAML 配置

    使用 PyYAML 库解析 YAML 配置文件，这是最广泛使用的 YAML 解析库。

    Notes:
        - 需要安装 PyYAML: pip install PyYAML
        - PyYAML 是快速、标准的 YAML 解析库
        - 使用缓存属性延迟导入，避免启动时的依赖检查
        - 不支持环境时返回空字典，实现优雅降级

    Examples:
        >>> from pynomad.config.parser.yaml_parser import PyYamlParser
        >>>
        >>> parser = PyYamlParser()
        >>> if parser.support_environment:
        ...     with open("config.yaml", "r", encoding="utf-8") as f:
        ...         config = parser.load(f)
    """

    @property
    @override
    def support_environment(self) -> bool:
        """检查是否支持当前运行环境

        Returns:
            bool: 如果 PyYAML 可用返回 True，否则返回 False

        Examples:
            >>> parser = PyYamlParser()
            >>> print(parser.support_environment)  # 已安装 PyYAML 输出: True
        """
        return self.yaml is not None

    @cached_property
    def yaml(self) -> ModuleType | None:
        """导入 yaml 模块

        Returns:
            ModuleType | None: yaml 模块对象，不可用时返回 None

        Notes:
            - 使用 @cached_property 缓存导入结果
            - 延迟导入，避免模块初始化时的依赖问题
            - 只在首次访问时尝试导入

        Examples:
            >>> parser = PyYamlParser()
            >>> print(parser.yaml)  # 已安装 PyYAML 输出: <module 'yaml'>
        """
        try:
            import yaml  # pylint: disable=C0415

            return yaml
        except ImportError:
            return None

    @override
    def load(self, fp: IO[str], /) -> AnyDict:
        """从文件对象加载 YAML 配置

        Args:
            fp: 文件对象（文本模式）

        Returns:
            AnyDict: 解析后的配置字典，环境不支持时返回空字典

        Notes:
            - 如果 yaml 不可用，返回空字典而不是抛出异常
            - 强制使用 SafeLoader 以防止 YAML 反序列化攻击
            - 文件对象必须以文本模式打开
            - 出于安全考虑，不允许传入自定义 Loader

        Examples:
            >>> parser = PyYamlParser()
            >>> with open("config.yaml", "r", encoding="utf-8") as f:
            ...     config = parser.load(f)
            >>> print(config["database"]["host"])
        """
        if self.yaml is None:
            return {}
        return self.yaml.load(fp, Loader=self.yaml.SafeLoader)

    @override
    def loads(self, s: str, /) -> AnyDict:
        """从字符串加载 YAML 配置

        Args:
            s: YAML 格式的字符串

        Returns:
            AnyDict: 解析后的配置字典，环境不支持时返回空字典

        Notes:
            - 如果 yaml 不可用，返回空字典而不是抛出异常
            - 强制使用 SafeLoader 以防止 YAML 反序列化攻击
            - 字符串必须是有效的 YAML 格式
            - 出于安全考虑，不允许传入自定义 Loader

        Examples:
            >>> parser = PyYamlParser()
            >>> yaml_str = '''
            ... database:
            ...   host: localhost
            ...   port: 5432
            ... '''
            >>> config = parser.loads(yaml_str)
            >>> print(config["database"]["host"])  # 输出: localhost
        """
        if self.yaml is None:
            return {}
        return self.yaml.load(s, Loader=self.yaml.SafeLoader)

    @override
    def parse_text(
        self, text: str, *, format_hint: str | None = None
    ) -> AnyDict:
        """解析 YAML 配置文本

        Args:
            text: YAML 格式的字符串
            format_hint: 格式提示，用于代理类选择解析器（此解析器忽略此参数）

        Returns:
            AnyDict: 解析后的配置字典，环境不支持时返回空字典

        Notes:
            - 如果 yaml 不可用，返回空字典而不是抛出异常
            - 字符串必须是有效的 YAML 格式
            - 使用 loads 方法实现
            - format_hint 参数在此解析器中未使用

        Examples:
            >>> parser = PyYamlParser()
            >>> yaml_str = '''
            ... database:
            ...   host: localhost
            ...   port: 5432
            ... '''
            >>> config = parser.parse_text(yaml_str)
            >>> print(config["database"]["host"])  # 输出: localhost
        """
        _ = format_hint
        return self.loads(text)

    @override
    def parse(self, file_path: Path) -> AnyDict:
        """解析 YAML 配置文件

        Args:
            file_path: YAML 文件路径

        Returns:
            AnyDict: 解析后的配置字典

        Raises:
            FileNotFoundError: 文件不存在
            ValueError: PyYAML 不可用时抛出此异常

        Notes:
            - 继承自 BaseYamlParser 的实现，使用 load 方法
            - load 方法在 PyYAML 不可用时返回空字典
            - 如果需要明确的环境检查，应先调用 support_environment

        Examples:
            >>> parser = PyYamlParser()
            >>> if parser.support_environment:
            ...     config = parser.parse(Path("config.yaml"))
            ...     print(config["database"]["host"])
        """
        if not self.yaml:
            raise ValueError(
                "YAML 解析器不可用，需要安装 PyYAML 库: pip install PyYAML"
            )
        return super().parse(file_path)


@final
class RuamelYamlParser(BaseYamlParser):
    """使用 ruamel.yaml 库加载 YAML 配置

    使用 ruamel.yaml 库解析 YAML 配置文件，支持更多高级功能如注释保留。

    Notes:
        - 需要安装 ruamel.yaml: pip install ruamel.yaml
        - ruamel.yaml 是 PyYAML 的增强版本
        - 使用缓存属性延迟导入，避免启动时的依赖检查
        - 不支持环境时返回空字典，实现优雅降级

    Examples:
        >>> from pynomad.config.parser.yaml_parser import RuamelYamlParser
        >>>
        >>> parser = RuamelYamlParser()
        >>> if parser.support_environment:
        ...     with open("config.yaml", "r", encoding="utf-8") as f:
        ...         config = parser.load(f)
    """

    @property
    @override
    def support_environment(self) -> bool:
        """检查是否支持当前运行环境

        Returns:
            bool: 如果 ruamel.yaml 可用返回 True，否则返回 False

        Examples:
            >>> parser = RuamelYamlParser()
            >>> print(parser.support_environment)  # 已安装 ruamel.yaml 输出: True
        """
        return self.yaml is not None

    @cached_property
    def yaml(self) -> ModuleType | None:
        """导入 ruamel.yaml 模块

        Returns:
            ModuleType | None: ruamel.yaml 模块对象，不可用时返回 None

        Notes:
            - 使用 @cached_property 缓存导入结果
            - 延迟导入，避免模块初始化时的依赖问题
            - 只在首次访问时尝试导入

        Examples:
            >>> parser = RuamelYamlParser()
            >>> print(parser.yaml)  # 已安装 ruamel.yaml 输出: <module 'ruamel.yaml'>
        """
        try:
            from ruamel import yaml  # pylint: disable=C0415
            return yaml
        except ImportError:
            return None

    @override
    def load(self, fp: IO[str], /) -> AnyDict:
        """从文件对象加载 YAML 配置

        Args:
            fp: 文件对象（文本模式）

        Returns:
            AnyDict: 解析后的配置字典，环境不支持时返回空字典

        Notes:
            - 如果 ruamel.yaml 不可用，返回空字典而不是抛出异常
            - 强制使用 safe 模式以防止 YAML 反序列化攻击
            - 文件对象必须以文本模式打开

        Examples:
            >>> parser = RuamelYamlParser()
            >>> with open("config.yaml", "r", encoding="utf-8") as f:
            ...     config = parser.load(f)
            >>> print(config["database"]["host"])
        """
        if self.yaml is None:
            return {}
        yaml_instance = self.yaml.YAML(typ="safe")
        return yaml_instance.load(fp)

    @override
    def loads(self, s: str, /) -> AnyDict:
        """从字符串加载 YAML 配置

        Args:
            s: YAML 格式的字符串

        Returns:
            AnyDict: 解析后的配置字典，环境不支持时返回空字典

        Notes:
            - 如果 ruamel.yaml 不可用，返回空字典而不是抛出异常
            - 强制使用 safe 模式以防止 YAML 反序列化攻击
            - 字符串必须是有效的 YAML 格式

        Examples:
            >>> parser = RuamelYamlParser()
            >>> yaml_str = '''
            ... database:
            ...   host: localhost
            ...   port: 5432
            ... '''
            >>> config = parser.loads(yaml_str)
            >>> print(config["database"]["host"])  # 输出: localhost
        """
        if self.yaml is None:
            return {}
        yaml_instance = self.yaml.YAML(typ="safe")
        return yaml_instance.load(s)

    @override
    def parse_text(
        self, text: str, *, format_hint: str | None = None
    ) -> AnyDict:
        """解析 YAML 配置文本

        Args:
            text: YAML 格式的字符串
            format_hint: 格式提示，用于代理类选择解析器（此解析器忽略此参数）

        Returns:
            AnyDict: 解析后的配置字典，环境不支持时返回空字典

        Notes:
            - 如果 ruamel.yaml 不可用，返回空字典而不是抛出异常
            - 字符串必须是有效的 YAML 格式
            - 使用 loads 方法实现
            - format_hint 参数在此解析器中未使用

        Examples:
            >>> parser = RuamelYamlParser()
            >>> yaml_str = '''
            ... database:
            ...   host: localhost
            ...   port: 5432
            ... '''
            >>> config = parser.parse_text(yaml_str)
            >>> print(config["database"]["host"])  # 输出: localhost
        """
        _ = format_hint
        return self.loads(text)

    @override
    def parse(self, file_path: Path) -> AnyDict:
        """解析 YAML 配置文件

        Args:
            file_path: YAML 文件路径

        Returns:
            AnyDict: 解析后的配置字典

        Raises:
            FileNotFoundError: 文件不存在
            ValueError: ruamel.yaml 不可用时抛出此异常

        Notes:
            - 继承自 BaseYamlParser 的实现，使用 load 方法
            - load 方法在 ruamel.yaml 不可用时返回空字典
            - 如果需要明确的环境检查，应先调用 support_environment

        Examples:
            >>> parser = RuamelYamlParser()
            >>> if parser.support_environment:
            ...     config = parser.parse(Path("config.yaml"))
            ...     print(config["database"]["host"])
        """
        if not self.yaml:
            raise ValueError(
                "YAML 解析器不可用，需要安装 PyYAML 或 ruamel.yaml 库: \
                    pip install PyYAML 或 pip install ruamel.yaml"
            )
        return super().parse(file_path)


@final
class YamlParser(ConfigParser):
    """YAML 工厂解析器

    自动选择最佳的 YAML 解析器实现：
    - 优先使用 PyYamlParser（广泛使用）
    - 降级使用 RuamelYamlParser（需要安装 ruamel.yaml）

    Notes:
        - 提供统一的 YAML 解析接口
        - 自动检测运行环境并选择合适的解析器
        - 支持 parse、load 和 loads 方法
        - 环境检查通过 support_environment 属性

    Examples:
        >>> from pynomad.config.parser.yaml_parser import YamlParser
        >>>
        >>> parser = YamlParser()
        >>> if parser.support_environment:
        ...     config = parser.parse(Path("config.yaml"))
        ...     print(config["database"]["host"])
    """

    def __init__(self) -> None:
        """初始化 YAML 工厂解析器

        自动选择可用的 YAML 解析器：
        1. 优先尝试使用 PyYamlParser
        2. 降级使用 RuamelYamlParser
        3. 如果都不可用，解析器将处于不可用状态
        """
        self._pyyaml_parser = PyYamlParser()
        self._ruamel_parser = RuamelYamlParser()
        self._parser: BaseYamlParser | None = None

    @property
    @override
    def extensions(self) -> list[str]:
        """获取支持的文件扩展名

        Returns:
            list[str]: [".yaml", ".yml"]

        Examples:
            >>> parser = YamlParser()
            >>> print(parser.extensions)  # 输出: ['.yaml', '.yml']
        """
        return [".yaml", ".yml"]

    @property
    def support_environment(self) -> bool:
        """检查是否支持当前运行环境

        Returns:
            bool: 如果至少一个解析器可用返回 True，否则返回 False

        Notes:
            - PyYamlParser 优先级高于 RuamelYamlParser
            - 只要有一个解析器可用就返回 True

        Examples:
            >>> parser = YamlParser()
            >>> print(parser.support_environment)  # 已安装 PyYAML 或 ruamel.yaml 输出: True
        """
        return (
            self._pyyaml_parser.support_environment
            or self._ruamel_parser.support_environment
        )

    @override
    def supports(
        self, file_path: Path | None = None, *, format_hint: str | None = None
    ) -> bool:
        """检查是否支持该文件格式

        Args:
            file_path: 文件路径
            format_hint: 格式提示（如 '.yaml', '.yml'）

        Returns:
            bool: 如果支持当前环境且文件扩展名匹配返回 True，否则返回 False

        Notes:
            - 先检查环境支持，再检查文件扩展名
            - 至少需要一个底层解析器可用
            - file_path 和 format_hint 至少需要提供一个

        Examples:
            >>> parser = YamlParser()
            >>> parser.supports(Path("config.yaml"))  # 输出: True
            >>> parser.supports(Path("config.json"))  # 输出: False
            >>> parser.supports(format_hint=".yaml"))  # 输出: True
        """
        if not self.support_environment:
            return False

        # 优先使用 file_path 的扩展名
        if file_path is not None:
            return file_path.suffix.lower() in self.extensions

        # 使用 format_hint（需要包含点号）
        hint = format_hint.lower() if format_hint else ""
        if not hint.startswith("."):
            hint = f".{hint}"
        return hint in self.extensions

    @override
    def parse_text(
        self, text: str, *, format_hint: str | None = None
    ) -> AnyDict:
        """解析 YAML 配置文本

        Args:
            text: YAML 格式的字符串
            format_hint: 格式提示，用于代理类选择解析器（此解析器忽略此参数）

        Returns:
            AnyDict: 解析后的配置字典

        Raises:
            ValueError: YAML 格式错误或环境不支持

        Notes:
            - 自动选择可用的解析器进行解析
            - 优先使用 PyYamlParser，降级使用 RuamelYamlParser
            - format_hint 参数在此解析器中未使用

        Examples:
            >>> parser = YamlParser()
            >>> yaml_str = '''
            ... database:
            ...   host: localhost
            ...   port: 5432
            ... '''
            >>> config = parser.parse_text(yaml_str)
            >>> print(config["database"]["host"])  # 输出: localhost
        """
        _ = format_hint
        parser = self._get_parser()
        if parser is None:
            raise ValueError(
                "YAML 解析器不可用，需要安装 PyYAML 或 ruamel.yaml 库:\
                      pip install PyYAML 或 pip install ruamel.yaml"
            )
        return parser.loads(text)

    @override
    def parse(self, file_path: Path) -> AnyDict:
        """解析 YAML 配置文件

        Args:
            file_path: YAML 文件路径

        Returns:
            AnyDict: 解析后的配置字典

        Raises:
            FileNotFoundError: 文件不存在
            ValueError: YAML 格式错误或环境不支持

        Notes:
            - 自动选择可用的解析器进行解析
            - 优先使用 PyYamlParser，降级使用 RuamelYamlParser

        Examples:
            >>> parser = YamlParser()
            >>> config = parser.parse(Path("config.yaml"))
            >>> print(config["database"]["host"])
        """
        parser = self._get_parser()
        if parser is None:
            raise ValueError(
                "YAML 解析器不可用，需要安装 PyYAML 或 ruamel.yaml 库:、\
                    pip install PyYAML 或 pip install ruamel.yaml"
            )
        return parser.parse(file_path)

    def load(self, fp: IO[str], /) -> AnyDict:
        """从文件对象加载 YAML 配置

        Args:
            fp: 文件对象（文本模式）

        Returns:
            AnyDict: 解析后的配置字典

        Raises:
            ValueError: 环境不支持

        Notes:
            - 自动选择可用的解析器进行加载
            - 优先使用 PyYamlParser，降级使用 RuamelYamlParser

        Examples:
            >>> parser = YamlParser()
            >>> with open("config.yaml", "r", encoding="utf-8") as f:
            ...     config = parser.load(f)
            >>> print(config["database"]["host"])
        """
        parser = self._get_parser()
        if parser is None:
            raise ValueError(
                "YAML 解析器不可用，需要安装 PyYAML 或 ruamel.yaml 库:\
                      pip install PyYAML 或 pip install ruamel.yaml"
            )
        return parser.load(fp)

    def loads(self, s: str, /) -> AnyDict:
        """从字符串加载 YAML 配置

        Args:
            s: YAML 格式的字符串

        Returns:
            AnyDict: 解析后的配置字典

        Raises:
            ValueError: 环境不支持

        Notes:
            - 自动选择可用的解析器进行加载
            - 优先使用 PyYamlParser，降级使用 RuamelYamlParser

        Examples:
            >>> parser = YamlParser()
            >>> yaml_str = '''
            ... database:
            ...   host: localhost
            ...   port: 5432
            ... '''
            >>> config = parser.loads(yaml_str)
            >>> print(config["database"]["host"])  # 输出: localhost
        """
        parser = self._get_parser()
        if parser is None:
            raise ValueError(
                "YAML 解析器不可用，需要安装 PyYAML 或 ruamel.yaml 库:\
                      pip install PyYAML 或 pip install ruamel.yaml"
            )
        return parser.loads(s)

    def _get_parser(self) -> BaseYamlParser | None:
        """获取可用的解析器

        Returns:
            BaseYamlParser | None: 可用的解析器，无可用解析器时返回 None

        Notes:
            - 优先返回 PyYamlParser
            - 降级返回 RuamelYamlParser
            - 缓存结果以提高性能
        """
        if self._parser is not None:
            return self._parser

        # 优先使用 PyYamlParser
        if self._pyyaml_parser.support_environment:
            self._parser = self._pyyaml_parser
        # 降级使用 RuamelYamlParser
        elif self._ruamel_parser.support_environment:
            self._parser = self._ruamel_parser
        else:
            self._parser = None

        return self._parser
