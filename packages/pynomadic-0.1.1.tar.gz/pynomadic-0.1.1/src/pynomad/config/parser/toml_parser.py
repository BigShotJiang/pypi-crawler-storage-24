"""TOML 配置文件解析器模块

提供 TOML (Tom's Obvious Minimal Language) 格式的配置文件解析器。

解析器架构：
- BaseTomlParser: TOML 格式解析器基类
- TomlParser: TOML 工厂解析器，自动选择最佳实现
- TomlibParser: 使用 Python 标准库的 TOML 解析器（Python 3.11+）
- TomliParser: 使用 tomli 库的 TOML 解析器（Python < 3.11）

设计原则：
1. 统一的解析接口，便于扩展和使用
2. 环境感知，根据运行环境自动选择解析器
3. 优雅降级，解析失败时返回空字典或抛出有意义的异常
4. 类型注解完整，支持静态类型检查

TOML 解析器选择策略：
- 优先使用 TomlibParser（Python 3.11+ 内置）
- 降级使用 TomliParser（需要安装 tomli）
- 两者都不可用时返回空字典或抛出异常
"""

from abc import abstractmethod
from collections.abc import Callable
from functools import cached_property
from pathlib import Path
from types import ModuleType
from typing import BinaryIO, final, override

from pynomad.common.types import AnyDict
from pynomad.config.parser.base import ConfigParser


ParseFloat = Callable[[str], object]


class BaseTomlParser(ConfigParser):
    """TOML 解析器基类

    提供了所有 TOML 解析器的通用接口和基础实现。

    TOML (Tom's Obvious Minimal Language) 是一种简洁的配置文件格式。

    Notes:
        - 抽象基类，不能直接实例化
        - 子类必须实现 support_environment、load 和 loads 方法
        - 根据运行环境自动判断是否可用（如 Python 版本）
        - extensions 和 supports 方法已提供最终实现，子类不能重写

    Examples:
        >>> # TomlibParser 是 BaseTomParser 的实现
        >>> from pynomad.config.parser.toml_parser import TomlibParser
        >>>
        >>> parser = TomlibParser()
        >>> if parser.support_environment:
        ...     print("TOML 解析器可用")
    """

    @property
    @final
    @override
    def extensions(self) -> list[str]:
        """获取支持的文件扩展名

        Returns:
            list[str]: [".tom", ".toml"]

        Notes:
            - @final 装饰器表示子类不能重写此方法
            - 同时支持 .tom 和 .toml 两种扩展名

        Examples:
            >>> class MyTomParser(BaseTomParser):
            ...     pass
            >>> print(MyTomParser().extensions)  # 输出: ['.tom', '.toml']
        """
        return [".tom", ".toml"]

    @property
    @abstractmethod
    def support_environment(self) -> bool:
        """检查是否支持当前运行环境

        Returns:
            bool: 如果支持当前运行环境返回 True，否则返回 False

        Notes:
            - 用于检查所需的依赖是否可用
            - 例如：tomllib 需要 Python 3.11+
            - 不支持时 supports 方法会返回 False

        Examples:
            >>> parser = TomlibParser()
            >>> print(parser.support_environment)  # Python 3.11+ 输出: True
        """
        return True

    @final
    @override
    def supports(
        self, file_path: Path | None = None, *, format_hint: str | None = None
    ) -> bool:
        """检查是否支持该文件格式

        Args:
            file_path: 文件路径
            format_hint: 格式提示（如 '.tom', '.toml'）

        Returns:
            bool: 如果支持当前环境且文件扩展名匹配返回 True，否则返回 False

        Notes:
            - @final 装饰器表示子类不能重写此方法
            - 先检查环境支持，再检查文件扩展名
            - file_path 和 format_hint 至少需要提供一个

        Examples:
            >>> parser = TomlibParser()
            >>> parser.supports(Path("config.toml"))  # Python 3.11+ 输出: True
            >>> parser.supports(Path("config.json"))  # 输出: False
            >>> parser.supports(format_hint=".toml"))  # 输出: True
        """
        if not self.support_environment:
            return False

        # 优先使用 file_path 的扩展名
        if file_path is not None:
            return file_path.suffix.lower() in self.extensions

        # 使用 format_hint（需要包含点号）
        hint = format_hint.lower() if format_hint else ""
        if not hint.startswith("."):
            hint = f".{hint}"
        return hint in self.extensions

    @abstractmethod
    def load(
        self, fp: BinaryIO, /, *, parse_float: ParseFloat = float
    ) -> AnyDict:
        """从二进制文件对象加载 TOML 配置

        Args:
            fp: 二进制文件对象（只读模式）
            parse_float: 浮点数解析函数，默认为 float

        Returns:
            AnyDict: 解析后的配置字典

        Notes:
            - 文件对象必须以二进制模式打开
            - parse_float 参数允许自定义浮点数解析逻辑
            - 子类必须实现此方法

        Examples:
            >>> parser = TomlibParser()
            >>> with open("config.toml", "rb") as f:
            ...     config = parser.load(f)
        """

    @abstractmethod
    def loads(
        self, s: str, /, *, parse_float: ParseFloat = float
    ) -> AnyDict:
        """从字符串加载 TOML 配置

        Args:
            s: TOML 格式的字符串
            parse_float: 浮点数解析函数，默认为 float

        Returns:
            AnyDict: 解析后的配置字典

        Notes:
            - 字符串必须是有效的 TOML 格式
            - parse_float 参数允许自定义浮点数解析逻辑
            - 子类必须实现此方法

        Examples:
            >>> parser = TomlibParser()
            >>> toml_str = '''
            ... [database]
            ... host = "localhost"
            ... port = 5432
            ... '''
            >>> config = parser.loads(toml_str)
            >>> print(config["database"]["host"])  # 输出: localhost
        """

    @override
    def parse(self, file_path: Path) -> AnyDict:
        """解析 TOML 配置文件

        Args:
            file_path: TOML 文件路径

        Returns:
            AnyDict: 解析后的配置字典

        Raises:
            FileNotFoundError: 文件不存在
            ValueError: TOML 格式错误或环境不支持

        Notes:
            - 使用 load 方法实现文件解析
            - 子类应实现 load 方法提供实际解析逻辑
            - 如果环境不支持，子类的 load 方法应抛出异常

        Examples:
            >>> parser = TomlibParser()
            >>> config = parser.parse(Path("config.toml"))
            >>> print(config["database"]["host"])
        """
        if not file_path.exists():
            raise FileNotFoundError(f"配置文件不存在: {file_path}")

        try:
            with open(file_path, "rb") as f:
                return self.load(f)
        except FileNotFoundError:
            raise  # noqa: B904
        except OSError as e:
            raise ValueError(f"文件读取错误: {file_path} - {e}") from e


@final
class TomlibParser(BaseTomlParser):
    """使用 Python 标准库加载 TOML 配置

    使用 Python 内置的 tomllib 模块解析 TOML 配置文件。

    Notes:
        - 需要 Python 3.11+ 版本
        - tomllib 是 Python 标准库的一部分，无需额外安装
        - 使用缓存属性延迟导入，避免启动时的依赖检查
        - 不支持环境时返回空字典，实现优雅降级

    Examples:
        >>> from pynomad.config.parser.toml_parser import TomlibParser
        >>>
        >>> parser = TomlibParser()
        >>> if parser.support_environment:
        ...     with open("config.toml", "rb") as f:
        ...         config = parser.load(f)
    """

    @property
    @override
    def support_environment(self) -> bool:
        """检查是否支持当前运行环境

        Returns:
            bool: 如果 Python >= 3.11 且 tomllib 可用返回 True，否则返回 False

        Examples:
            >>> parser = TomlibParser()
            >>> print(parser.support_environment)  # Python 3.11+ 输出: True
        """
        return self.tomllib is not None

    @cached_property
    def tomllib(self) -> ModuleType | None:
        """导入 tomllib 模块

        Returns:
            ModuleType | None: tomllib 模块对象，不可用时返回 None

        Notes:
            - 使用 @cached_property 缓存导入结果
            - 延迟导入，避免模块初始化时的依赖问题
            - 只在首次访问时尝试导入

        Examples:
            >>> parser = TomlibParser()
            >>> print(parser.tomllib)  # Python 3.11+ 输出: <module 'tomllib'>
        """
        try:
            import tomllib  # pylint: disable=C0415

            return tomllib
        except ImportError:
            return None

    @override
    def load(
        self, fp: BinaryIO, /, *, parse_float: ParseFloat = float
    ) -> AnyDict:
        """从二进制文件对象加载 TOML 配置

        Args:
            fp: 二进制文件对象（只读模式）
            parse_float: 浮点数解析函数，默认为 float

        Returns:
            AnyDict: 解析后的配置字典，环境不支持时返回空字典

        Notes:
            - 如果 tomllib 不可用，返回空字典而不是抛出异常
            - parse_float 参数传递给 tomllib.load 方法
            - 文件对象必须以二进制模式打开

        Examples:
            >>> parser = TomlibParser()
            >>> with open("config.toml", "rb") as f:
            ...     config = parser.load(f)
            >>> print(config["database"]["host"])
        """
        if self.tomllib is None:
            return {}
        return self.tomllib.load(fp, parse_float=parse_float)

    @override
    def loads(
        self, s: str, /, *, parse_float: ParseFloat = float
    ) -> AnyDict:
        """从字符串加载 TOML 配置

        Args:
            s: TOML 格式的字符串
            parse_float: 浮点数解析函数，默认为 float

        Returns:
            AnyDict: 解析后的配置字典，环境不支持时返回空字典

        Notes:
            - 如果 tomllib 不可用，返回空字典而不是抛出异常
            - parse_float 参数传递给 tomllib.loads 方法
            - 字符串必须是有效的 TOML 格式

        Examples:
            >>> parser = TomlibParser()
            >>> toml_str = '''
            ... [database]
            ... host = "localhost"
            ... port = 5432
            ... '''
            >>> config = parser.loads(toml_str)
            >>> print(config["database"]["host"])  # 输出: localhost
        """
        if self.tomllib is None:
            return {}
        return self.tomllib.loads(s, parse_float=parse_float)

    @override
    def parse_text(
        self, text: str, *, format_hint: str | None = None
    ) -> AnyDict:
        """解析 TOML 配置文本

        Args:
            text: TOML 格式的字符串
            format_hint: 格式提示，用于代理类选择解析器（此解析器忽略此参数）

        Returns:
            AnyDict: 解析后的配置字典，环境不支持时返回空字典

        Notes:
            - 如果 tomllib 不可用，返回空字典而不是抛出异常
            - 字符串必须是有效的 TOML 格式
            - 使用 loads 方法实现
            - format_hint 参数在此解析器中未使用

        Examples:
            >>> parser = TomlibParser()
            >>> toml_str = '''
            ... [database]
            ... host = "localhost"
            ... port = 5432
            ... '''
            >>> config = parser.parse_text(toml_str)
            >>> print(config["database"]["host"])  # 输出: localhost
        """
        _ = format_hint
        return self.loads(text)

    @override
    def parse(self, file_path: Path) -> AnyDict:
        """解析 TOML 配置文件

        Args:
            file_path: TOML 文件路径

        Returns:
            AnyDict: 解析后的配置字典

        Raises:
            FileNotFoundError: 文件不存在
            ValueError: tomllib 不可用时抛出此异常

        Notes:
            - 继承自 BaseTomlParser 的实现，使用 load 方法
            - load 方法在 tomllib 不可用时返回空字典
            - 如果需要明确的环境检查，应先调用 support_environment

        Examples:
            >>> parser = TomlibParser()
            >>> if parser.support_environment:
            ...     config = parser.parse(Path("config.toml"))
            ...     print(config["database"]["host"])
        """
        if not self.tomllib:
            raise ValueError(
                "TOML 解析器不可用，需要 Python 3.11+ 版本或安装 tomli 库"
            )
        return super().parse(file_path)


@final
class TomliParser(BaseTomlParser):
    """使用 tomli 库加载 TOML 配置

    使用第三方 tomli 库解析 TOML 配置文件，适用于 Python 3.11 以下版本。

    Notes:
        - 需要安装 tomli: pip install tomli
        - tomli 是 tomllib 的第三方实现，功能完全兼容
        - 使用缓存属性延迟导入，避免启动时的依赖检查
        - 不支持环境时返回空字典，实现优雅降级

    Examples:
        >>> from pynomad.config.parser.toml_parser import TomliParser
        >>>
        >>> parser = TomliParser()
        >>> if parser.support_environment:
        ...     with open("config.toml", "rb") as f:
        ...         config = parser.load(f)
    """

    @property
    @override
    def support_environment(self) -> bool:
        """检查是否支持当前运行环境

        Returns:
            bool: 如果 tomli 可用返回 True，否则返回 False

        Examples:
            >>> parser = TomliParser()
            >>> print(parser.support_environment)  # 已安装 tomli 输出: True
        """
        return self.tomli is not None

    @cached_property
    def tomli(self) -> ModuleType | None:
        """导入 tomli 模块

        Returns:
            ModuleType | None: tomli 模块对象，不可用时返回 None

        Notes:
            - 使用 @cached_property 缓存导入结果
            - 延迟导入，避免模块初始化时的依赖问题
            - 只在首次访问时尝试导入

        Examples:
            >>> parser = TomliParser()
            >>> print(parser.tomli)  # 已安装 tomli 输出: <module 'tomli'>
        """
        try:
            import tomli  # pylint: disable=C0415

            return tomli
        except ImportError:
            return None

    @override
    def load(
        self, fp: BinaryIO, /, *, parse_float: ParseFloat = float
    ) -> AnyDict:
        """从二进制文件对象加载 TOML 配置

        Args:
            fp: 二进制文件对象（只读模式）
            parse_float: 浮点数解析函数，默认为 float

        Returns:
            AnyDict: 解析后的配置字典，环境不支持时返回空字典

        Notes:
            - 如果 tomli 不可用，返回空字典而不是抛出异常
            - parse_float 参数传递给 tomli.load 方法
            - 文件对象必须以二进制模式打开

        Examples:
            >>> parser = TomliParser()
            >>> with open("config.toml", "rb") as f:
            ...     config = parser.load(f)
            >>> print(config["database"]["host"])
        """
        if self.tomli is None:
            return {}
        return self.tomli.load(fp, parse_float=parse_float)

    @override
    def loads(
        self, s: str, /, *, parse_float: ParseFloat = float
    ) -> AnyDict:
        """从字符串加载 TOML 配置

        Args:
            s: TOML 格式的字符串
            parse_float: 浮点数解析函数，默认为 float

        Returns:
            AnyDict: 解析后的配置字典，环境不支持时返回空字典

        Notes:
            - 如果 tomli 不可用，返回空字典而不是抛出异常
            - parse_float 参数传递给 tomli.loads 方法
            - 字符串必须是有效的 TOML 格式

        Examples:
            >>> parser = TomliParser()
            >>> toml_str = '''
            ... [database]
            ... host = "localhost"
            ... port = 5432
            ... '''
            >>> config = parser.loads(toml_str)
            >>> print(config["database"]["host"])  # 输出: localhost
        """
        if self.tomli is None:
            return {}
        return self.tomli.loads(s, parse_float=parse_float)

    @override
    def parse_text(
        self, text: str, *, format_hint: str | None = None
    ) -> AnyDict:
        """解析 TOML 配置文本

        Args:
            text: TOML 格式的字符串
            format_hint: 格式提示，用于代理类选择解析器（此解析器忽略此参数）

        Returns:
            AnyDict: 解析后的配置字典，环境不支持时返回空字典

        Notes:
            - 如果 tomli 不可用，返回空字典而不是抛出异常
            - 字符串必须是有效的 TOML 格式
            - 使用 loads 方法实现
            - format_hint 参数在此解析器中未使用

        Examples:
            >>> parser = TomliParser()
            >>> toml_str = '''
            ... [database]
            ... host = "localhost"
            ... port = 5432
            ... '''
            >>> config = parser.parse_text(toml_str)
            >>> print(config["database"]["host"])  # 输出: localhost
        """
        _ = format_hint
        return self.loads(text)

    @override
    def parse(self, file_path: Path) -> AnyDict:
        """解析 TOML 配置文件

        Args:
            file_path: TOML 文件路径

        Returns:
            AnyDict: 解析后的配置字典

        Raises:
            FileNotFoundError: 文件不存在
            ValueError: tomli 不可用时抛出此异常

        Notes:
            - 继承自 BaseTomlParser 的实现，使用 load 方法
            - load 方法在 tomli 不可用时返回空字典
            - 如果需要明确的环境检查，应先调用 support_environment

        Examples:
            >>> parser = TomliParser()
            >>> if parser.support_environment:
            ...     config = parser.parse(Path("config.toml"))
            ...     print(config["database"]["host"])
        """
        if not self.tomli:
            raise ValueError(
                "TOML 解析器不可用，需要安装 tomli 库: pip install tomli"
            )
        return super().parse(file_path)


@final
class TomlParser(ConfigParser):
    """TOML 工厂解析器

    自动选择最佳的 TOML 解析器实现：
    - 优先使用 TomlibParser（Python 3.11+ 内置）
    - 降级使用 TomliParser（需要安装 tomli）

    Notes:
        - 提供统一的 TOML 解析接口
        - 自动检测运行环境并选择合适的解析器
        - 支持 parse、load 和 loads 方法
        - 环境检查通过 support_environment 属性

    Examples:
        >>> from pynomad.config.parser.toml_parser import TomlParser
        >>>
        >>> parser = TomlParser()
        >>> if parser.support_environment:
        ...     config = parser.parse(Path("config.toml"))
        ...     print(config["database"]["host"])
    """

    def __init__(self) -> None:
        """初始化 TOML 工厂解析器

        自动选择可用的 TOML 解析器：
        1. 优先尝试使用 TomlibParser（Python 3.11+）
        2. 降级使用 TomliParser
        3. 如果都不可用，解析器将处于不可用状态
        """
        self._tomlib_parser = TomlibParser()
        self._tomli_parser = TomliParser()
        self._parser: BaseTomlParser | None = None

    @property
    @override
    def extensions(self) -> list[str]:
        """获取支持的文件扩展名

        Returns:
            list[str]: [".tom", ".toml"]

        Examples:
            >>> parser = TomlParser()
            >>> print(parser.extensions)  # 输出: ['.tom', '.toml']
        """
        return [".tom", ".toml"]

    @property
    def support_environment(self) -> bool:
        """检查是否支持当前运行环境

        Returns:
            bool: 如果至少一个解析器可用返回 True，否则返回 False

        Notes:
            - TomlibParser 优先级高于 TomliParser
            - 只要有一个解析器可用就返回 True

        Examples:
            >>> parser = TomlParser()
            >>> print(parser.support_environment)  # Python 3.11+ 或已安装 tomli 输出: True
        """
        return (
            self._tomlib_parser.support_environment
            or self._tomli_parser.support_environment
        )

    @override
    def supports(
        self, file_path: Path | None = None, *, format_hint: str | None = None
    ) -> bool:
        """检查是否支持该文件格式

        Args:
            file_path: 文件路径
            format_hint: 格式提示（如 '.tom', '.toml'）

        Returns:
            bool: 如果支持当前环境且文件扩展名匹配返回 True，否则返回 False

        Notes:
            - 先检查环境支持，再检查文件扩展名
            - 至少需要一个底层解析器可用
            - file_path 和 format_hint 至少需要提供一个

        Examples:
            >>> parser = TomlParser()
            >>> parser.supports(Path("config.toml"))  # 输出: True
            >>> parser.supports(Path("config.json"))  # 输出: False
            >>> parser.supports(format_hint=".toml"))  # 输出: True
        """
        if not self.support_environment:
            return False

        # 优先使用 file_path 的扩展名
        if file_path is not None:
            return file_path.suffix.lower() in self.extensions

        # 使用 format_hint（需要包含点号）
        hint = format_hint.lower() if format_hint else ""
        if not hint.startswith("."):
            hint = f".{hint}"
        return hint in self.extensions

    @override
    def parse_text(
        self, text: str, *, format_hint: str | None = None
    ) -> AnyDict:
        """解析 TOML 配置文本

        Args:
            text: TOML 格式的字符串
            format_hint: 格式提示，用于代理类选择解析器（此解析器忽略此参数）

        Returns:
            AnyDict: 解析后的配置字典

        Raises:
            ValueError: TOML 格式错误或环境不支持

        Notes:
            - 自动选择可用的解析器进行解析
            - 优先使用 TomlibParser，降级使用 TomliParser
            - format_hint 参数在此解析器中未使用

        Examples:
            >>> parser = TomlParser()
            >>> toml_str = '''
            ... [database]
            ... host = "localhost"
            ... port = 5432
            ... '''
            >>> config = parser.parse_text(toml_str)
            >>> print(config["database"]["host"])  # 输出: localhost
        """
        _ = format_hint
        parser = self._get_parser()
        if parser is None:
            raise ValueError(
                "TOML 解析器不可用，需要 Python 3.11+ 版本或安装 tomli 库: pip install tomli"
            )
        return parser.loads(text)

    @override
    def parse(self, file_path: Path) -> AnyDict:
        """解析 TOML 配置文件

        Args:
            file_path: TOML 文件路径

        Returns:
            AnyDict: 解析后的配置字典

        Raises:
            FileNotFoundError: 文件不存在
            ValueError: TOML 格式错误或环境不支持

        Notes:
            - 自动选择可用的解析器进行解析
            - 优先使用 TomlibParser，降级使用 TomliParser

        Examples:
            >>> parser = TomlParser()
            >>> config = parser.parse(Path("config.toml"))
            >>> print(config["database"]["host"])
        """
        parser = self._get_parser()
        if parser is None:
            raise ValueError(
                "TOML 解析器不可用，需要 Python 3.11+ 版本或安装 tomli 库: pip install tomli"
            )
        return parser.parse(file_path)

    def load(
        self, fp: BinaryIO, /, *, parse_float: ParseFloat = float
    ) -> AnyDict:
        """从二进制文件对象加载 TOML 配置

        Args:
            fp: 二进制文件对象（只读模式）
            parse_float: 浮点数解析函数，默认为 float

        Returns:
            AnyDict: 解析后的配置字典

        Raises:
            ValueError: 环境不支持

        Notes:
            - 自动选择可用的解析器进行加载
            - 优先使用 TomlibParser，降级使用 TomliParser

        Examples:
            >>> parser = TomlParser()
            >>> with open("config.toml", "rb") as f:
            ...     config = parser.load(f)
            >>> print(config["database"]["host"])
        """
        parser = self._get_parser()
        if parser is None:
            raise ValueError(
                "TOML 解析器不可用，需要 Python 3.11+ 版本或安装 tomli 库: pip install tomli"
            )
        return parser.load(fp, parse_float=parse_float)

    def loads(
        self, s: str, /, *, parse_float: ParseFloat = float
    ) -> AnyDict:
        """从字符串加载 TOML 配置

        Args:
            s: TOML 格式的字符串
            parse_float: 浮点数解析函数，默认为 float

        Returns:
            AnyDict: 解析后的配置字典

        Raises:
            ValueError: 环境不支持

        Notes:
            - 自动选择可用的解析器进行加载
            - 优先使用 TomlibParser，降级使用 TomliParser

        Examples:
            >>> parser = TomlParser()
            >>> toml_str = '''
            ... [database]
            ... host = "localhost"
            ... port = 5432
            ... '''
            >>> config = parser.loads(toml_str)
            >>> print(config["database"]["host"])  # 输出: localhost
        """
        parser = self._get_parser()
        if parser is None:
            raise ValueError(
                "TOML 解析器不可用，需要 Python 3.11+ 版本或安装 tomli 库: pip install tomli"
            )
        return parser.loads(s, parse_float=parse_float)

    def _get_parser(self) -> BaseTomlParser | None:
        """获取可用的解析器

        Returns:
            BaseTomlParser | None: 可用的解析器，无可用解析器时返回 None

        Notes:
            - 优先返回 TomlibParser
            - 降级返回 TomliParser
            - 缓存结果以提高性能
        """
        if self._parser is not None:
            return self._parser

        # 优先使用 TomlibParser
        if self._tomlib_parser.support_environment:
            self._parser = self._tomlib_parser
        # 降级使用 TomliParser
        elif self._tomli_parser.support_environment:
            self._parser = self._tomli_parser
        else:
            self._parser = None

        return self._parser
