"""字符串转化包"""

from types import NoneType
from typing import Literal
import unicodedata


def strip_diacritics(text: str) -> str:
    """将字符串标准化,去除组合字符,比如去掉拼音中的声调等"""
    # 返回 Unicode 字符串 unistr 的规范形式 form
    text = unicodedata.normalize("NFD", text)
    # 去掉text中的组合字符
    text = "".join(char for char in text if not unicodedata.combining(char))
    return text


def detect_convert_type(text: str) -> type:
    """诊断字符串可转化的类型"""
    text = str(text)
    try:
        _ = int(text)
        return int
    except ValueError:
        ...
    try:
        _ = float(text)
        return float
    except ValueError:
        ...
    text = text.lower()
    if text in ["true", "false", "yes", "no"]:
        return bool
    if text in ["none", "null", "undefined"]:
        return NoneType
    return str


def convert(
    text: str, strip: bool = False
) -> bool | int | float | str | NoneType:
    """转化字符串到对应类型

    Args:
        text: 待转换的字符串
        strip: 是否去除首尾空格，默认为 False
    """
    if not strip and (text != text.strip()):
        return text
    if strip:
        text = text.strip()
    try:
        return int(text)
    except ValueError:
        ...
    try:
        return float(text)
    except ValueError:
        ...
    orgin_text: str = text
    text = text.lower()
    if text in ["none", "null", "undefined"]:
        return None
    if text in ["true", "yes"]:
        return True
    if text in ["false", "no"]:
        return False
    return str(orgin_text)


def shorten(
    text: str,
    width: int = 50,
    split: str = " ",
    placeholder: str = "...",
    ellipsis: Literal["center", "end"] = "center",
) -> str:
    """截断字符串，支持中间或末尾省略，尽量保持单词完整

    Args:
        text: 要截断的原始文本
        width: 最大字符宽度，0 表示不限制
        split: 分隔符，截断时尽量保持单词完整
        placeholder: 省略标记，默认"..."
        ellipsis: 省略位置，"center"中间省略，"end"末尾省略

    Returns:
        截断后的字符串，长度不会超过 width

    Examples:
        >>> shorten("app.config.name.value", 15, split=".")
        'app...value'
        >>> shorten("app.config.name.value", 15, split=".", ellipsis="end")
        'app.config...'
    """
    if width <= 0:
        return text
    if len(text) <= width:
        return text

    placeholder_len: int = len(placeholder)
    if placeholder_len >= width:
        return placeholder[:width]

    if ellipsis == "end":
        return _shorten_end(text, width, split, placeholder)

    return _shorten_center(text, width, split, placeholder)


def _shorten_end(
    text: str,
    width: int,
    split: str,
    placeholder: str,
) -> str:
    """末尾省略，尽量在分隔符处截断"""
    max_content_width: int = width - len(placeholder)
    candidate: str = text[:max_content_width]

    if not split:
        return candidate + placeholder

    # 在候选范围内找最后一个分隔符
    last_split_pos: int = candidate.rfind(split)
    if last_split_pos <= 0:
        return candidate + placeholder

    # 在分隔符处截断，去掉末尾分隔符
    candidate = candidate[:last_split_pos].rstrip(split)
    if not candidate:
        return text[:max_content_width] + placeholder

    return candidate + placeholder


def _shorten_center(
    text: str,
    width: int,
    split: str,
    placeholder: str,
) -> str:
    """中间省略，前后部分尽量在分隔符处截断"""
    text_len: int = len(text)
    placeholder_len: int = len(placeholder)
    keep_len: int = width - placeholder_len

    keep_start: int = keep_len // 2
    keep_end: int = keep_len - keep_start

    # 前部：从开头取 keep_start，尝试在分隔符处对齐
    prefix_raw: str = text[:keep_start]
    prefix: str = _adjust_to_split_boundary(prefix_raw, split, is_prefix=True)

    # 后部：从结尾取 keep_end，尝试在分隔符处对齐
    suffix_start: int = text_len - keep_end
    suffix_raw: str = text[suffix_start:]
    suffix: str = _adjust_to_split_boundary(suffix_raw, split, is_prefix=False)

    # 重新计算实际长度，确保总长度不超过 width
    total_len: int = len(prefix) + placeholder_len + len(suffix)
    if total_len > width:
        # 超长了，需要缩减
        overflow: int = total_len - width
        if len(prefix) > len(suffix):
            prefix = prefix[: len(prefix) - overflow]
        else:
            suffix = suffix[overflow:]

    return prefix + placeholder + suffix


def _adjust_to_split_boundary(
    candidate: str,
    split: str,
    is_prefix: bool = True,
) -> str:
    """调整字符串到分隔符边界

    Args:
        candidate: 候选字符串
        full_text: 完整文本
        split: 分隔符
        is_prefix: True 表示前部（找末尾分隔符），False 表示后部（找开头分隔符）
    """
    if not split or not candidate:
        return candidate

    if is_prefix:
        # 前部：去掉末尾不完整单词
        # 如果候选串末尾是分隔符或在分隔符后，直接返回
        if candidate.endswith(split):
            return candidate.rstrip(split)
        # 找最后一个分隔符
        last_split: int = candidate.rfind(split)
        if last_split > 0:
            return candidate[:last_split]
        return candidate
    else:
        # 后部：去掉开头不完整单词
        if candidate.startswith(split):
            return candidate.lstrip(split)
        # 找第一个分隔符
        first_split: int = candidate.find(split)
        if first_split >= 0:
            return candidate[first_split + len(split) :]
        return candidate
