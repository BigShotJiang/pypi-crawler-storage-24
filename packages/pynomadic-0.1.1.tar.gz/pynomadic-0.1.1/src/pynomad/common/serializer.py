"""通用数据操作模块

提供数据转换和文件写入等通用功能。
"""

import configparser
from collections.abc import Mapping
from pathlib import Path
from typing import cast

from pynomad.common.dict_utils import (
    flatten_dict,
    serialize,
    deserialize,
    dict_to_object,
)
from pynomad.common.types import AnyDict


def _extract_default_dict(data: AnyDict) -> AnyDict:
    """提取并处理 DEFAULT section 内容

    Args:
        data: 原始数据字典（会被修改）

    Returns:
        DEFAULT section 字典
    """
    default_value: AnyDict | str | None = data.pop("DEFAULT", {})

    if isinstance(default_value, dict):
        return default_value

    default_dict: AnyDict = {}
    default_dict["DEFAULT"] = (
        str(default_value) if default_value is not None else ""
    )
    return default_dict


def _build_sections_dict(data: AnyDict, default_dict: AnyDict) -> AnyDict:
    """构建 sections 字典

    将展平的数据分为：
    - 根节点值归入 DEFAULT
    - 嵌套节点作为 section

    Args:
        data: 展平后的数据
        default_dict: DEFAULT 字典（会被修改）

    Returns:
        sections 字典
    """
    sections: AnyDict = {}

    for key, value in data.items():
        if "." not in key:
            default_dict[key] = str(value) if value is not None else ""
            continue

        parent_key: str
        sub_key: str
        parent_key, sub_key = key.rsplit(".", 1)
        if parent_key not in sections:
            sections[parent_key] = {}
        sections[parent_key][sub_key] = str(value) if value is not None else ""

    return sections


def write_dict_to_ini(data: AnyDict, file_path: Path) -> None:
    """将嵌套字典写入 INI 文件

    将嵌套字典结构转换为 INI 格式文件：
    - 顶层键作为 section
    - 嵌套字典使用点号分隔（如 level2b.level3）
    - 根层非字典值自动归入 DEFAULT section
    - 美化输出（空行分隔 sections）

    Args:
        data: 要写入的嵌套字典，支持任意类型值
        file_path: 目标 INI 文件路径

    Examples:
        >>> data = {
        ...     "DEFAULT": {"app_name": "myapp", "version": "1.0"},
        ...     "database": {"host": "localhost", "port": 3306},
        ...     "debug": True,  # 非字典值，归入 DEFAULT
        ... }
        >>> write_dict_to_ini(data, Path("config.ini"))
        # 生成内容:
        # [DEFAULT]
        # app_name = myapp
        # version = 1.0
        # debug = True
        #
        # [database]
        # host = localhost
        # port = 3306
    """
    default_dict = _extract_default_dict(data)

    data = flatten_dict(data)

    sections = _build_sections_dict(data, default_dict)

    config = configparser.ConfigParser()
    if default_dict:
        config["DEFAULT"] = default_dict
    if sections:
        config.read_dict(sections)
    with open(file_path, "w", encoding="utf-8") as configfile:
        config.write(configfile)


def _create_nested_dict(result: AnyDict, keys: list[str]) -> AnyDict:
    """在 result 中创建嵌套字典结构

    Args:
        result: 目标字典
        keys: 嵌套键列表

    Returns:
        最深层级的字典
    """
    current: AnyDict = result
    for k in keys[:-1]:
        if k not in current:
            current[k] = {}
        current = cast(AnyDict, current[k])
    if keys[-1] not in current:
        current[keys[-1]] = {}
    return cast(AnyDict, current[keys[-1]])


def _get_section_dict(result: AnyDict, section_name: str) -> AnyDict:
    """获取 section 对应的字典

    Args:
        result: 结果字典
        section_name: section 名称

    Returns:
        section 对应的字典
    """
    if "." not in section_name:
        if section_name in result and not isinstance(
            result[section_name], dict
        ):
            result[section_name] = {}
        return result.setdefault(section_name, {})

    section_keys = section_name.split(".")
    return _create_nested_dict(result, section_keys)


def _process_section_keys(
    section_dict: AnyDict, config: configparser.ConfigParser, section_name: str
) -> None:
    """处理 section 中的键值对

    Args:
        section_dict: section 对应的字典
        config: ConfigParser 实例
        section_name: section 名称
    """
    # 获取 DEFAULT section 的所有键
    defaults: Mapping[str, str] = config.defaults()
    default_keys: set[str] = set(defaults.keys()) if defaults else set()

    # 获取该 section 自己定义的原始键（不包括 DEFAULT 继承的）
    # 使用 getattr 访问 ConfigParser 的内部 _sections 属性
    sections_dict: AnyDict = getattr(config, "_sections", {})
    if section_name in sections_dict:
        section_keys: set[str] = set(sections_dict[section_name].keys())

        for key in section_keys:
            value = config[section_name][key]

            if "." not in key:
                section_dict[key] = value
                continue

            keys: list[str] = key.split(".")
            current: AnyDict = section_dict
            for k in keys[:-1]:
                if k not in current:
                    current[k] = {}
                current = cast(AnyDict, current[k])
            current[keys[-1]] = value
    else:
        # 如果无法访问内部结构，使用 options() 并跳过 DEFAULT 键
        for key in config.options(section_name):
            value = config[section_name][key]

            if key in default_keys:
                continue

            if "." not in key:
                section_dict[key] = value
                continue

            keys: list[str] = key.split(".")
            current: AnyDict = section_dict
            for k in keys[:-1]:
                if k not in current:
                    current[k] = {}
                current = cast(AnyDict, current[k])
            current[keys[-1]] = value


def load_dict_from_ini(file_path: Path) -> AnyDict:
    """从 INI 文件读取嵌套字典

    将 INI 格式文件还原为嵌套字典结构：
    - DEFAULT section 作为名为 "DEFAULT" 的独立节点
    - 其他 section 的键使用点号分隔还原为嵌套字典

    Args:
        file_path: INI 文件路径

    Returns:
        AnyDict: 嵌套字典结构

    Raises:
        FileNotFoundError: 文件不存在
        ValueError: INI 格式错误

    Examples:
        >>> data = load_dict_from_ini(Path("config.ini"))
        # 返回类似:
        # {
        #     "DEFAULT": {
        #         "app_name": "myapp",
        #         "version": "1.0"
        #     },
        #     "database": {
        #         "host": "localhost",
        #         "port": "3306"
        #     }
        # }
    """
    if not file_path.exists():
        raise FileNotFoundError(f"配置文件不存在: {file_path}")

    try:
        config = configparser.ConfigParser()
        _ = config.read(file_path, encoding="utf-8")
    except (configparser.Error, OSError) as e:
        raise ValueError(f"INI 格式错误: {file_path} - {e}") from e

    result: AnyDict = {}

    # 处理 DEFAULT section，作为独立的 "DEFAULT" 节点
    defaults = config.defaults()
    if defaults:
        default_dict: AnyDict = {}
        for key, value in defaults.items():
            if "." not in key:
                default_dict[key] = value
                continue

            keys = key.split(".")
            current = default_dict
            for k in keys[:-1]:
                if k not in current:
                    current[k] = {}
                current = cast(AnyDict, current[k])
            current[keys[-1]] = value
        result["DEFAULT"] = default_dict

    # 处理其他 sections
    for section_name in config.sections():
        section_dict = _get_section_dict(result, section_name)
        _process_section_keys(section_dict, config, section_name)

    return result


__all__ = [
    "write_dict_to_ini",
    "load_dict_from_ini",
    "serialize",
    "deserialize",
    "dict_to_object",
]
