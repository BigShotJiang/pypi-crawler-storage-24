"""字典工具模块

提供字典相关的工具函数,包括类型检查、转换、合并等操作。
"""

from collections.abc import Callable
from types import ModuleType
from typing import Any, cast, get_origin, get_args
from datetime import date, datetime, time, timedelta
from pathlib import Path, PurePath
from urllib.parse import ParseResult
from enum import Enum
from decimal import Decimal
from base64 import b64encode
from uuid import UUID
from re import Pattern as RePattern
import json
from pynomad.common.types import (
    AnyDict,
    StrDict,
    EmptyStrPolicy,
    NonePolicy,
    OnUnconvertible,
)


# ==================== 类型检查 ====================


def is_dict(value: Any) -> bool:
    """检查值是否为字典类型

    Args:
        value: 要检查的值

    Returns:
        bool: 如果是字典返回 True,否则返回 False
    """
    return isinstance(value, dict)


# ==================== 类型确保 ====================


def ensure_dict(value: Any) -> AnyDict | None:
    """确保值为字典类型

    Args:
        value: 要转换的值

    Returns:
        AnyDict | None: 如果是字典返回 AnyDict 类型,否则返回 None
    """
    if is_dict(value):
        return cast(AnyDict, value)
    return None


def ensure_str_dict(value: object) -> StrDict | None:
    """确保值为字符串字典类型

    尝试将字典转换为字符串键值对的字典。

    Args:
        value: 要转换的值

    Returns:
        StrDict | None: 如果转换成功返回 StrDict,否则返回 None
    """
    if not isinstance(value, dict):
        return None
    try:
        result: dict[str, str] = {}
        value = cast(dict[object, object], value)
        for k, v in value.items():
            result[str(k)] = str(v) if v is not None else ""
        return result
    except (TypeError, ValueError):
        return None


# ==================== 字典转换 ====================


def convert_dict_value_to_str(data: AnyDict) -> AnyDict:
    """递归将字典中的所有值转换为字符串

    Args:
        data: 要转换的字典

    Returns:
        AnyDict: 所有值都转换为字符串的字典
    """
    result: AnyDict = {}
    for key, value in data.items():
        dict_value = ensure_dict(value)
        if dict_value:
            result[key] = convert_dict_value_to_str(dict_value)
        else:
            result[key] = str(value) if value is not None else ""
    return result


def flatten_dict(data: AnyDict, prefix: str = "") -> dict[str, str]:
    """将嵌套字典展平为单层字典,用点号分隔键

    Args:
        data: 要展平的嵌套字典
        prefix: 键前缀(用于递归调用)

    Returns:
        dict[str, str]: 展平后的单层字典

    Examples:
        >>> data = {"a": {"x": 1, "y": 2}, "b": 3}
        >>> flatten_dict(data)
        {"a.x": "1", "a.y": "2", "b": "3"}
    """
    result: dict[str, str] = {}
    for key, value in data.items():
        new_key = f"{prefix}.{key}" if prefix else str(key)
        dict_value = ensure_dict(value)
        if dict_value:
            result.update(flatten_dict(dict_value, new_key))
        else:
            result[new_key] = str(value) if value is not None else ""
    return result


# ==================== 字典合并 ====================


def deep_merge(base: AnyDict, override_dict: AnyDict) -> AnyDict:
    """深度合并两个字典

    对于嵌套字典进行深度合并,而不是简单覆盖。

    合并规则:
    - 如果两个值都是字典,则递归合并
    - 否则,override_dict 的值覆盖 base 的值

    Args:
        base: 基础字典
        override_dict: 覆盖字典

    Returns:
        AnyDict: 合并后的字典

    Examples:
        >>> base = {"a": {"x": 1, "y": 2}, "b": 3}
        >>> override = {"a": {"x": 10, "z": 30}, "b": 4}
        >>> deep_merge(base, override)
        {"a": {"x": 10, "y": 2, "z": 30}, "b": 4}
    """
    result: AnyDict = {}
    result.update(base)

    for key, value in override_dict.items():
        base_value = result.get(key)
        base_dict = ensure_dict(base_value)
        override_dict_value = ensure_dict(value)

        if base_value is not None and base_dict and override_dict_value:
            # 递归深度合并嵌套字典
            result[key] = deep_merge(base_dict, override_dict_value)
        else:
            # 直接覆盖
            result[key] = value

    return result


def object_to_dict(
    obj: object,
    on_unconvertible: OnUnconvertible = "raise",
    none_policy: NonePolicy = "keep",
    empty_str_policy: EmptyStrPolicy = "keep",
) -> dict[str, Any]:
    """将非值类型实例转换为字典

    支持递归转换嵌套对象和集合类型。

    Args:
        obj: 要转换的对象
        on_unconvertible: 遇到不可转换值时的处理方式
            - "raise": 抛出异常（默认）
            - "skip": 跳过该值
            - "str": 使用 str() 转换
        none_policy: None 值的处理方式
            - "keep": 保留 None 值（默认）
            - "skip": 抛弃 None 值
        empty_str_policy: 空字符串的处理方式
            - "keep": 保留空字符串（默认）
            - "skip": 抛弃空字符串

    Returns:
        dict[str, Any]: 转换后的字典

    Raises:
        TypeError: 不支持的转换类型（当 on_unconvertible="raise" 时）
        ValueError: 无效的参数值

    Examples:
        >>> class Person:
        ...     def __init__(self, name, age):
        ...         self.name = name
        ...         self.age = age
        >>> person = Person("Alice", 30)
        >>> object_to_dict(person)
        {"name": "Alice", "age": 30}

        >>> # 跳过 None 值
        >>> person.name = None
        >>> object_to_dict(person, none_policy="skip")
        {"age": 30}
    """
    # 参数验证
    valid_on_unconvertible = ["raise", "skip", "str"]
    if on_unconvertible not in valid_on_unconvertible:
        raise ValueError(f"on_unconvertible 必须是 {valid_on_unconvertible}")

    valid_none_policy = ["keep", "skip"]
    if none_policy not in valid_none_policy:
        raise ValueError(f"none_policy 必须是 {valid_none_policy}")

    valid_empty_str_policy = ["keep", "skip"]
    if empty_str_policy not in valid_empty_str_policy:
        raise ValueError(f"empty_str_policy 必须是 {valid_empty_str_policy}")

    # 检查对象是否可转换（dict 等基本类型是可转换的）
    # 只有当对象是 Callable 或 ModuleType 且没有 __dict__ 时才不支持
    is_dict_type = isinstance(obj, dict)
    is_list_type = isinstance(obj, list)
    is_set_type = isinstance(obj, set)
    is_tuple_type = isinstance(obj, tuple)
    is_callable_or_module = isinstance(obj, (Callable, ModuleType))
    has_dict = hasattr(obj, "__dict__")

    # 支持 dict, list, set, tuple 类型
    if is_dict_type or is_list_type or is_set_type or is_tuple_type:
        return cast(
            dict[str, Any],
            serialize(
                obj, None, on_unconvertible, none_policy, empty_str_policy
            ),
        )

    if is_callable_or_module or not has_dict:
        raise ValueError(f"传入的参数{obj}必须是可序列化对象实例")

    return cast(
        dict[str, Any],
        serialize(obj, None, on_unconvertible, none_policy, empty_str_policy),
    )


def serialize(
    value: Any,
    seen: set[int] | None = None,
    on_unconvertible: OnUnconvertible = "raise",
    none_policy: NonePolicy = "keep",
    empty_str_policy: EmptyStrPolicy = "keep",
    mark_type: bool = False,
) -> Any:
    """将对象转换为可序列化的类型

    支持递归转换嵌套对象和集合类型。

    Args:
        value: 要转换的值
        seen: 用于检测循环引用的 ID 集合（内部使用）
        on_unconvertible: 遇到不可转换值时的处理方式
            - "raise": 抛出异常（默认）
            - "skip": 跳过该值
            - "str": 使用 str() 转换
        none_policy: None 值的处理方式
            - "keep": 保留 None 值（默认）
            - "skip": 抛弃 None 值
        empty_str_policy: 空字符串的处理方式
            - "keep": 保留空字符串（默认）
            - "skip": 抛弃空字符串
        mark_type: 是否为 set 和 tuple 添加类型标记
            - False: 不添加标记，set/tuple 转换为 list（默认）
            - True: 添加类型标记，返回 {"__type__": "set|tuple", "__data__": [...]}

    Returns:
        Any: 转换后的值

    Raises:
        ValueError: 检测到循环引用或参数无效
        KeyError: 字典键非字符串类型
        TypeError: 不支持的转换类型
    """
    # 初始化 seen 集合
    if seen is None:
        seen = set()

    def _should_skip_value(v: Any) -> bool:
        """判断是否应该跳过某个值

        Args:
            v: 要判断的值

        Returns:
            bool: True 表示应该跳过
        """
        if v is None and none_policy == "skip":
            return True
        if v == "" and empty_str_policy == "skip":
            return True
        return False

    # 处理循环引用
    if id(value) in seen:
        if on_unconvertible == "raise":
            raise ValueError(f"检测到循环引用: {type(value).__name__}")
        if on_unconvertible == "skip":
            return None
        return str(value)

    # 处理字典
    if isinstance(value, dict):
        value = cast(dict[Any, Any], value)
        seen.add(id(value))
        # 检查所有键是否为 str 类型
        for key in value.keys():
            if not isinstance(key, str):
                if on_unconvertible == "raise":
                    raise KeyError(
                        f"字典键必须为 str 类型，当前键类型为: {type(key).__name__}"
                    )
                if on_unconvertible == "skip":
                    continue
                key = str(key)
        dict_result: dict[str, Any] = {}
        for k, v in value.items():
            if isinstance(k, str):
                converted_v = serialize(
                    v, seen, on_unconvertible, none_policy, empty_str_policy, mark_type
                )
                if not _should_skip_value(converted_v):
                    dict_result[k] = converted_v
        seen.remove(id(value))
        return dict_result

    # 处理列表
    if isinstance(value, list):
        value = cast(list[Any], value)
        seen.add(id(value))
        list_result: list[Any] = []
        for item in value:
            converted_item: Any = serialize(
                item, seen, on_unconvertible, none_policy, empty_str_policy, mark_type
            )
            if _should_skip_value(converted_item):
                # 在列表中，None 和空字符串被替换为 None 或 "" 以保持位置
                list_result.append(None if converted_item is None else "")
            else:
                list_result.append(converted_item)
        seen.remove(id(value))
        return list_result

    # 处理特殊类型（必须在对象转换和 tuple 之前）
    # URI 相关类型 (ParseResult 继承自 tuple，需要优先检查)
    if isinstance(value, ParseResult):
        return value.geturl()
    # datetime -> 毫秒时间戳
    if isinstance(value, datetime):
        return int(value.timestamp() * 1000)
    # date -> 日期字符串
    if isinstance(value, date):
        return value.isoformat()
    # time -> 时分秒字符串
    if isinstance(value, time):
        return value.isoformat()
    # timedelta -> 总秒数
    if isinstance(value, timedelta):
        return value.total_seconds()
    # 路径类型
    if isinstance(value, Path | PurePath):
        return str(value)
    # Enum -> 枚举值
    if isinstance(value, Enum):
        return value.value
    # UUID -> 字符串
    if isinstance(value, UUID):
        return str(value)
    # Decimal -> 字符串（避免精度丢失）
    if isinstance(value, Decimal):
        return str(value)
    # 复数 -> [实部, 虚部]
    if isinstance(value, complex):
        return [value.real, value.imag]
    # bytes/bytearray -> base64 字符串
    if isinstance(value, bytes | bytearray):
        return b64encode(value).decode("utf-8")
    # re.Pattern -> 模式字符串
    if isinstance(value, RePattern):
        value = cast(RePattern[Any], value)
        pattern: str = getattr(value, "pattern", "")
        return pattern

    # 处理元组
    if isinstance(value, tuple):
        value = cast(tuple[Any, ...], value)
        seen.add(id(value))
        tuple_result: list[Any] = []
        for item in value:
            converted_item: Any = serialize(
                item, seen, on_unconvertible, none_policy, empty_str_policy, mark_type
            )
            if _should_skip_value(converted_item):
                # 在元组中，None 和空字符串被替换为 None 或 "" 以保持位置
                tuple_result.append(None if converted_item is None else "")
            else:
                tuple_result.append(converted_item)
        seen.remove(id(value))
        if mark_type:
            return {"__type__": "tuple", "__data__": tuple_result}
        return tuple_result

    # 处理集合
    if isinstance(value, set):
        value = cast(set[Any], value)
        seen.add(id(value))
        set_result: list[Any] = []
        for item in value:
            converted_item: Any = serialize(
                item, seen, on_unconvertible, none_policy, empty_str_policy, mark_type
            )
            if _should_skip_value(converted_item):
                # 在集合中，None 和空字符串被替换为 None 或 "" 以保持位置
                set_result.append(None if converted_item is None else "")
            else:
                set_result.append(converted_item)
        seen.remove(id(value))
        if mark_type:
            return {"__type__": "set", "__data__": set_result}
        return set_result

    # 处理对象（有 __dict__ 但不是 Callable 或 ModuleType）
    if hasattr(value, "__dict__") and not isinstance(
        value, (Callable, ModuleType)
    ):
        seen.add(id(value))
        result: dict[str, Any] = {}
        for key in dir(value):
            # 跳过私有属性和特殊方法
            if key.startswith("_"):
                continue
            try:
                attr = getattr(value, key)
                # 处理方法和属性
                if isinstance(attr, Callable | ModuleType):
                    # 根据策略处理方法
                    if on_unconvertible == "skip":
                        continue
                    if on_unconvertible == "str":
                        result[key] = str(cast(object, attr))
                    # on_unconvertible == "raise" 时跳过方法（默认行为）
                else:
                    converted_attr: Any = serialize(
                        attr,
                        seen,
                        on_unconvertible,
                        none_policy,
                        empty_str_policy,
                        mark_type,
                    )
                    if not _should_skip_value(converted_attr):
                        result[key] = converted_attr
            except AttributeError:
                continue
        seen.remove(id(value))
        return result

    # 处理 Callable 和 ModuleType（顶层对象）
    if isinstance(value, Callable | ModuleType):
        if on_unconvertible == "raise":
            raise TypeError(f"不支持的类型: {value.__name__}")
        if on_unconvertible == "skip":
            return None
        return str(cast(object, value))

    # 基本类型直接返回
    return value


# ==================== 反序列化 ====================


def deserialize[T](
    data: Any,
    target_type: type[T],
) -> T:
    """将数据反序列化为目标类型

    支持以下转换策略（按优先级）:
    1. 如果目标类型有 `from_dict` 类方法，使用 from_dict(data)
    2. 如果目标类型是 dict 类型，验证并返回字典
    3. 如果目标是类实例，尝试通过构造函数创建
    4. 如果目标是类实例，尝试通过 setattr 设置属性

    Args:
        data: 要反序列化的数据
        target_type: 目标类型

    Returns:
        T: 反序列化后的目标类型实例

    Raises:
        TypeError: 当数据无法转换为目标类型时
        ValueError: 当 JSON 解析失败或 dict 转换失败时

    Examples:
        >>> class Person:
        ...     def __init__(self, name: str, age: int):
        ...         self.name = name
        ...         self.age = age
        >>> data = {"name": "Alice", "age": 30}
        >>> deserialize(data, Person)
        Person(name="Alice", age=30)

        >>> # 使用 from_dict 方法
        >>> class Config:
        ...     @classmethod
        ...     def from_dict(cls, data: dict):
        ...         return cls(**data)
        >>> deserialize({"key": "value"}, Config)
        Config(key="value")
    """
    def _convert_value(value: Any, target_field_type: type[Any] | None) -> Any:
        """根据目标字段类型转换值

        Args:
            value: 要转换的值
            target_field_type: 目标字段类型

        Returns:
            转换后的值
        """
        # 处理带类型标记的结构
        if isinstance(value, dict) and "__type__" in value and "__data__" in value:
            value_dict: dict[str, Any] = cast(dict[str, Any], value)
            type_name: str = value_dict["__type__"]
            data_value: Any = value_dict["__data__"]
            if type_name == "set":
                if isinstance(data_value, list):
                    return set(data_value)  # type: ignore[arg-type]
            if type_name == "tuple":
                if isinstance(data_value, list):
                    return tuple(data_value)  # type: ignore[arg-type]
            # 递归处理嵌套结构
            if isinstance(data_value, dict):
                return _convert_value(data_value, target_field_type)
            if isinstance(data_value, list):
                return [_convert_value(item, target_field_type) for item in data_value]  # type: ignore[reportUnknownVariableType]
            return data_value

        # 如果没有指定目标类型，直接返回
        if target_field_type is None:
            return value # type: ignore

        # 获取原始类型（处理泛型如 set[str], list[int] 等）
        origin_type: type[Any] | None = get_origin(target_field_type)
        if origin_type is None:
            origin_type = target_field_type

        # list 转 set
        if origin_type is set and isinstance(value, list):
            return set(value)  # type: ignore[arg-type]

        # list 转 tuple
        if origin_type is tuple and isinstance(value, list):
            return tuple(value)  # type: ignore[arg-type]

        # 递归处理列表元素
        if isinstance(value, list) and origin_type is list:
            args: tuple[Any, ...] = get_args(target_field_type)
            item_type: type[Any] = args[0] if args else Any  # type: ignore[assignment]
            return [_convert_value(item, item_type) for item in value]  # type: ignore[reportUnknownVariableType]

        # 递归处理字典值
        if isinstance(value, dict) and origin_type is dict:
            args: tuple[Any, ...] = get_args(target_field_type)
            value_type: type[Any] = args[1] if len(args) > 1 else Any  # type: ignore[assignment]
            return {
                k: _convert_value(v, value_type)
                for k, v in cast(dict[str, Any], value).items()
            }

        # 递归处理带类型标记的结构
        if isinstance(value, dict) and "__type__" in value:
            return _convert_value(value, target_field_type)

        return value # type: ignore

    # 1. 处理 JSON 字符串
    if isinstance(data, str):
        try:
            data = json.loads(data)
        except json.JSONDecodeError as e:
            raise TypeError(f"无法解析 JSON 字符串: {data}") from e

    # 2. 检查 data 是否为字典类型
    if not isinstance(data, dict):
        raise TypeError(f"数据必须是字典类型，当前类型: {type(data).__name__}")

    data_dict: dict[str, Any] = cast(dict[str, Any], data)

    # 3. 检查目标类型是否为 dict 类型
    if get_origin(target_type) is dict:
        # 目标是字典类型，直接返回
        return cast(T, data_dict)

    # 4. 尝试使用 from_dict 类方法
    if hasattr(target_type, "from_dict"):
        from_dict_method = getattr(target_type, "from_dict")
        if callable(from_dict_method):
            try:
                result: T = from_dict_method(data_dict)  # type: ignore[return-value]
                return result
            except Exception as e:
                raise TypeError(f"from_dict 方法调用失败: {e}") from e

    # 5. 尝试通过构造函数创建
    try:
        result: T = target_type(**data_dict)
        return result
    except TypeError:
        # 构造函数失败，尝试 setattr 方式
        pass
    except Exception as e:
        raise TypeError(f"构造函数创建失败: {e}") from e

    # 6. 尝试通过 setattr 设置属性
    try:
        instance: T = object.__new__(target_type)
        # 获取目标类型的注解信息
        annotations: dict[str, Any] = getattr(target_type, "__annotations__", {})
        for key, value in data_dict.items():
            target_field_type: type[Any] | None = annotations.get(key, None)
            converted_value: Any = _convert_value(value, target_field_type)
            setattr(instance, key, converted_value)
        return instance
    except Exception as e:
        raise TypeError(f"setattr 方式转换失败: {e}") from e


def dict_to_object[T](
    data: dict[str, Any],
    target_type: type[T],
) -> T:
    """将字典转换为目标类型对象（alias for deserialize）

    这是一个便利函数，与 deserialize 功能相同。

    Args:
        data: 要转换的字典
        target_type: 目标类型

    Returns:
        T: 转换后的目标类型实例

    Raises:
        TypeError: 当数据无法转换为目标类型时
        ValueError: 当 dict 转换失败时

    See Also:
        deserialize: 更通用的反序列化函数
    """
    result: T = deserialize(data, target_type)
    return result
