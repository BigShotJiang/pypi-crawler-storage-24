"""
类型定义
"""

from abc import ABCMeta
from collections.abc import Buffer
from enum import EnumMeta, IntEnum, IntFlag
import sys
from typing import (
    Any,
    Literal,
    Protocol,
    SupportsFloat,
    SupportsIndex,
    SupportsInt,
    runtime_checkable,
)


# ===========================================================================#
# 类型别名
# ===========================================================================#
@runtime_checkable
class SupportsTrunc(Protocol):
    """支持截断行为"""

    def __trunc__(self) -> int: ...


if sys.version_info >= (3, 14):
    ConvertibleToInt = str | Buffer | SupportsInt | SupportsIndex
else:
    ConvertibleToInt = str | Buffer | int | SupportsIndex | SupportsTrunc
ConvertibleToFloat = str | Buffer | SupportsFloat | SupportsIndex

type AnyDict = dict[str, Any]
type ObjectKeyDict = dict[object, object]
type ObjectDict = dict[str, object]
type GenericDict[T] = dict[str, T]
type StrDict = dict[str, str]
type ObjectList = list[object]
type StrList = list[str]
type AnyList = list[Any]

# 序列化策略类型
type OnUnconvertible = Literal["raise", "skip", "str"]
type NonePolicy = Literal["keep", "skip"]
type EmptyStrPolicy = Literal["keep", "skip"]


# ============================================================================#
# 类型定义
# ============================================================================#
class EnumABCMeta(EnumMeta, ABCMeta):
    """结合枚举元类和抽象基类元类的功能的元类。"""


class Level(IntEnum):
    """日志级别枚举类

    遵循常见的日志级别设计，包括未设置状态和所有标准级别。
    数值越小，级别越详细（优先级越低）。
    """

    UNSET = 0  # 未设置级别 - 用于继承和表示未配置状态
    ALL = 1  # 输出所有日志
    TRACE = 5  # 调试级别
    VERBOSE = 8  # 可选的详细级别，介于 TRACE 和 DEBUG 之间
    DEBUG = 10  # 调试级别
    INFO = 20  # 标准级别
    NOTICE = 25  # 可选的通知级别，介于 INFO 和 WARNING 之间
    WARN = 30  # 警告级别
    ERROR = 40  # 错误级别
    FATAL = 50  # 严重级别
    ALERT = 55  # 可选的警报级别，介于 CRITICAL 和 EMERGENCY 之间
    EMERGENCY = 60  # 最高紧急级别
    OFF = 100  # 关闭所有日志输出

    @classmethod
    def is_valid_level(cls, level: int) -> bool:
        """检查是否为有效的日志级别

        Args:
            level: 日志级别值

        Returns:
            bool: 是否为有效级别
        """
        return any(level == member.value for member in cls)

    @classmethod
    def get_level_name(cls, level: int) -> str:
        """获取日志级别名称

        Args:
            level: 日志级别值

        Returns:
            str: 级别名称，如果不是有效级别则返回 "UNKNOWN"
        """
        for member in cls:
            if level == member.value:
                return member.name
        return "UNKNOWN"

    @classmethod
    def parse_level(
        cls,
        level_input: str | int,
    ) -> "Level":
        """从字符串或整数解析日志级别

        Args:
            level_input: 级别字符串（不区分大小写）或整数

        Returns:
            LoggerLevel: 对应的日志级别

        Raises:
            ValueError: 如果输入不能解析为有效级别
        """
        # 如果已经是整数，直接尝试转换
        if isinstance(level_input, int):
            try:
                return cls(level_input)
            except ValueError as e:
                raise ValueError(f"Invalid log level: {level_input}") from e

        # 处理字符串输入
        try:
            return cls[level_input.upper()]
        except (AttributeError, KeyError):
            # 如果不是字符串或枚举值不存在，尝试解析为数字
            try:
                level_int = int(level_input)
                return cls(level_int)
            except (ValueError, TypeError) as e:
                raise ValueError(f"Invalid log level: {level_input}") from e

    def is_enabled_for(self, other_level: "Level") -> bool:
        """检查当前级别是否启用指定的其他级别

        Args:
            other_level: 要检查的级别

        Returns:
            bool: 如果当前级别会记录 other_level 级别的日志则返回 True
        """
        if self == self.OFF:
            return False
        if self == self.ALL:
            # ALL 级别启用所有日志
            return True
        if self == self.UNSET:
            # NOTSET 表示未设置，通常会继承父级配置，这里假设启用所有级别
            return True
        return self.value <= other_level.value or other_level == self.UNSET

    @property
    def is_debug(self) -> bool:
        """是否为调试级别（DEBUG 或更低）"""
        return self.value <= self.DEBUG.value and self.value not in (
            self.UNSET.value,
            self.ALL.value,
        )

    @property
    def is_info(self) -> bool:
        """是否为信息级别"""
        return self.value == self.INFO.value

    @property
    def is_warning(self) -> bool:
        """是否为警告级别及以上"""
        return self.value >= self.WARN.value

    @property
    def is_error(self) -> bool:
        """是否为错误级别及以上"""
        return self.value >= self.ERROR.value

    @property
    def is_critical(self) -> bool:
        """是否为严重级别及以上"""
        return self.value >= self.FATAL.value

    @property
    def is_all(self) -> bool:
        """是否为输出所有日志级别"""
        return self.value == self.ALL.value

    @property
    def is_notset(self) -> bool:
        """是否为未设置级别"""
        return self.value == self.UNSET.value

    @property
    def is_off(self) -> bool:
        """是否为关闭日志级别"""
        return self.value == self.OFF.value


class OutputTarget(IntFlag):
    """日志输出目标枚举 - 支持位运算"""

    CONSOLE = 1  # 仅控制台输出
    FILE = 2  # 仅文件输出
    BOTH = CONSOLE | FILE  # 同时输出到控制台和文件 (3)