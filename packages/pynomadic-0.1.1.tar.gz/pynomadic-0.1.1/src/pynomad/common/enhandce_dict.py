"""增强型字典类，支持属性访问、嵌套字典自动转换、脱敏等功能"""

from __future__ import annotations
from types import UnionType
from typing import (
    Any,
    Self,
    Union,  # pyright: ignore[reportDeprecated]
    cast,
    override,
    get_origin,
    get_args,
)

import copy

from pynomad.common.converter import ensure_list
from pynomad.common.dict_utils import ensure_dict, is_dict


def _check_type(value: Any, expected_type: Any) -> tuple[bool, str | None]:
    """检查值是否符合预期类型

    Args:
        value: 要检查的值
        expected_type: 预期类型

    Returns:
        (是否匹配, 错误信息)
    """
    # Any 类型
    if expected_type is Any:
        return True, None

    # Union 类型 (包括 Optional[T] 和 int | None 语法)
    origin = get_origin(expected_type)
    if origin is Union or origin is UnionType:  # pyright: ignore[reportDeprecated]
        for arg in get_args(expected_type):
            is_valid, _ = _check_type(value, arg)
            if is_valid:
                return True, None
        return (
            False,
            f"Expected one of {get_args(expected_type)}, got {type(value).__name__}",
        )

    # None 值特殊处理
    if value is None:
        return True, None

    # List[T]
    if origin is list:
        if not isinstance(value, list):
            return False, f"Expected list, got {type(value).__name__}"
        args = get_args(expected_type)
        if not args:
            return True, None
        item_type = args[0]
        value = cast(list[Any], value)
        for i, item in enumerate(value):
            is_valid, error = _check_type(item, item_type)
            if not is_valid:
                return False, f"List item {i}: {error}"
        return True, None

    # Dict[K, V]
    if origin is dict:
        if not isinstance(value, dict):
            return False, f"Expected dict, got {type(value).__name__}"
        args = get_args(expected_type)
        if not args or len(args) < 2:
            return True, None
        key_type = args[0]
        value_type = args[1]
        value = cast(dict[Any, Any], value)
        for k, v in value.items():
            is_valid, error = _check_type(k, key_type)
            if not is_valid:
                return False, f"Key {k}: {error}"
            is_valid, error = _check_type(v, value_type)
            if not is_valid:
                return False, f"Value for key {k}: {error}"
        return True, None

    # 基本类型检查
    if isinstance(value, expected_type):
        return True, None

    # 构建类型名称,处理没有 __name__ 属性的类型
    type_name = getattr(expected_type, "__name__", str(expected_type))
    return (
        False,
        f"Expected {type_name}, got {type(value).__name__}",
    )


class EnhancedDict(dict[str, Any]):
    """增强型字典类，支持属性访问和设置

    特性：
    - 支持点语法访问和设置：config.key = value
    - 自动转换嵌套字典和列表中的字典
    - 提供 from_dict 工厂方法
    - 支持敏感信息脱敏
    - 完全兼容所有字典操作
    - 处理循环引用问题
    - 可选的类型检查功能
    """

    def __init__(
        self,
        *args: Any,
        _skip_auto_convert: bool = False,
        _type_hints: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        """初始化增强字典

        可以通过位置参数或关键字参数初始化

        Args:
            *args: 位置参数
            _skip_auto_convert: 是否跳过自动转换（内部使用）
            _type_hints: 类型提示字典，用于类型验证
            **kwargs: 关键字参数
        """
        super().__init__(*args, **kwargs)
        self._type_hints = _type_hints
        self._enable_type_check = _type_hints is not None
        # 只在非跳过模式时自动转换
        if not _skip_auto_convert:
            self._auto_convert()

    def _auto_convert(self) -> None:
        """自动转换嵌套字典和列表中的字典为 EnhancedDict"""
        visited: set[int] = set()

        def _convert(obj: Any) -> Any:
            """递归转换对象"""
            obj_id = id(obj)
            if obj_id in visited:
                return obj
            visited.add(obj_id)

            if is_dict(obj) and not isinstance(obj, EnhancedDict):
                # 使用 _skip_auto_convert=True 避免递归调用 __init__ 中的 _auto_convert
                converted: EnhancedDict = EnhancedDict(
                    obj, _skip_auto_convert=True
                )
                for key, value in converted.items():
                    converted[key] = _convert(value)
                return converted
            if list_obj := ensure_list(obj):
                return [_convert(item) for item in list_obj]
            if dict_obj := ensure_dict(obj):
                # 已经是 EnhancedDict，继续递归转换其值
                for key, value in dict_obj.items():
                    dict_obj[key] = _convert(value)
                return dict_obj
            return cast(Any, obj)

        for key, value in self.items():
            self[key] = _convert(value)

    def __getattr__(self, key: str) -> Any:
        """支持点语法访问字典属性

        Args:
            key: 属性名/字典键

        Returns:
            对应的值

        Raises:
            AttributeError: 如果键不存在且不是字典方法
        """
        try:
            return self[key]
        except KeyError as e:
            # 检查是否是字典的内置方法
            if key.startswith("_") and key in dir(dict):
                raise AttributeError(
                    f"'{type(self).__name__}' object has no attribute '{key}'"
                ) from e
            raise AttributeError(
                f"'{type(self).__name__}' object has no attribute '{key}'"
            ) from e

    @override
    def __setattr__(self, key: str, value: Any) -> None:
        """支持点语法设置字典属性

        Args:
            key: 属性名/字典键
            value: 要设置的值
        """
        # 保护内部属性
        if key.startswith("_") and key in {
            "_auto_convert",
            "_type_hints",
            "_enable_type_check",
        }:
            super().__setattr__(key, value)
        else:
            # 类型检查（如果启用）
            if (
                hasattr(self, "_enable_type_check")
                and self._enable_type_check
                and hasattr(self, "_type_hints")
                and self._type_hints
                and key in self._type_hints
            ):
                expected_type = self._type_hints[key]
                is_valid, error = _check_type(value, expected_type)
                if not is_valid:
                    raise TypeError(f"Key '{key}': {error}")
            # 自动转换嵌套字典
            converted_value = self._convert_value(value)
            self[key] = converted_value

    @override
    def __delattr__(self, key: str) -> None:
        """支持点语法删除字典属性

        Args:
            key: 属性名/字典键

        Raises:
            AttributeError: 如果键不存在
        """
        try:
            del self[key]
        except KeyError as e:
            raise AttributeError(
                f"'{type(self).__name__}' object has no attribute '{key}'"
            ) from e

    def _convert_value(self, value: Any) -> Any:
        """转换单个值，处理嵌套字典和列表

        Args:
            value: 要转换的值

        Returns:
            转换后的值
        """
        if is_dict(value) and not isinstance(value, EnhancedDict):
            value = cast(dict[str, Any], value)
            return EnhancedDict(value)
        if list_value := ensure_list(value):
            return [self._convert_value(item) for item in list_value]
        return value

    @classmethod
    def from_dict(cls, data: dict[str, Any] | EnhancedDict) -> Self:
        """从普通字典创建 EnhancedDict 实例

        Args:
            data: 源字典

        Returns:
            EnhancedDict 实例
        """
        if isinstance(data, cls):
            return data
        return cls(data)

    @classmethod
    def ensure_enhanced(cls, data: Any) -> Any:
        """确保数据是 EnhancedDict 实例

        如果是普通字典则转换，如果是列表则递归转换列表中的字典，
        如果是 None 则返回 None

        Args:
            data: 要转换的数据

        Returns:
            转换后的数据
        """
        if data is None:
            return None
        if isinstance(data, cls):
            return data
        if is_dict(data):
            return cls(data)
        if list_data := ensure_list(data):
            return [cls.ensure_enhanced(item) for item in list_data]
        return data

    def mask_sensitive(
        self,
        sensitive_keys: set[str] | None = None,
        mask_char: str = "*",
        preserve_length: bool = True,
    ) -> dict[str, Any]:
        """脱敏敏感信息

        Args:
            sensitive_keys: 需要脱敏的键名集合，默认包含常见敏感字段
            mask_char: 脱敏字符，默认为 '*'
            preserve_length: 是否保持原字符串长度，默认为 True

        Returns:
            脱敏后的字典副本
        """
        if sensitive_keys is None:
            sensitive_keys = {
                "password",
                "passwd",
                "pwd",
                "secret",
                "token",
                "api_key",
                "apikey",
                "access_token",
                "refresh_token",
                "private_key",
                "auth",
                "credential",
            }

        def _mask_value(value: Any) -> Any:
            """脱敏单个值（处理嵌套结构）"""
            if isinstance(value, EnhancedDict):
                return value.mask_sensitive(
                    sensitive_keys, mask_char, preserve_length
                )
            if dict_value := ensure_dict(value):
                # 递归处理字典：对每个键值对，如果键敏感则脱敏值
                masked_dict = {}
                for k, v in dict_value.items():
                    if k.lower() in sensitive_keys and isinstance(v, str):
                        masked_dict[k] = (
                            mask_char * len(v)
                            if preserve_length
                            else mask_char * 6
                        )
                    else:
                        masked_dict[k] = _mask_value(v)
                return cast(dict[str, Any], EnhancedDict(masked_dict))
            if list_value := ensure_list(value):
                return [_mask_value(item) for item in list_value]
            return value

        result: EnhancedDict = EnhancedDict()
        for key, value in self.items():
            if key.lower() in sensitive_keys and isinstance(value, str):
                result[key] = (
                    mask_char * len(value) if preserve_length else mask_char * 6
                )
            else:
                result[key] = _mask_value(value)
        return result

    def to_dict(self) -> dict[str, Any]:
        """转换为普通字典（递归转换所有嵌套结构）

        Returns:
            普通字典，所有嵌套的 EnhancedDict 和列表中的 EnhancedDict 都会被转换
        """

        def _convert_value(value: Any) -> Any:
            """递归转换值"""
            if isinstance(value, EnhancedDict):
                # 递归转换 EnhancedDict
                return value.to_dict()
            if list_value := ensure_list(value):
                # 递归转换列表中的 EnhancedDict
                return [_convert_value(item) for item in list_value]
            return value

        result: dict[str, Any] = {}
        for key, value in self.items():
            result[key] = _convert_value(value)
        return result

    def __deepcopy__(self, memo: dict[int, Any] | None = None) -> Self:
        """支持深拷贝

        Args:
            memo: 拷贝备忘录

        Returns:
            深拷贝后的实例
        """
        if memo is None:
            memo = {}
        obj_id = id(self)
        if obj_id in memo:
            return memo[obj_id]

        # 创建新实例
        cls = self.__class__
        result = cls.__new__(cls)
        memo[obj_id] = result

        # 深拷贝所有键值对
        for key, value in self.items():
            result[copy.deepcopy(key, memo)] = copy.deepcopy(value, memo)

        return result

    @override
    def copy(self) -> Self:
        """返回浅拷贝

        Returns:
            浅拷贝的实例
        """
        return cast(Self, EnhancedDict(super().copy()))

    def get_nested(self, *keys: str, default: Any = None) -> Any:
        """获取嵌套字典的值

        Args:
            *keys: 嵌套的键路径
            default: 默认值

        Returns:
            找到的值或默认值

        Examples:
            >>> d = EnhancedDict({'a': {'b': {'c': 1}}})
            >>> d.get_nested('a', 'b', 'c')
            1
        """
        current: Any = self
        for key in keys:
            if dict_current := ensure_dict(current):
                if key in dict_current:
                    current = dict_current[key]
                else:
                    return default
            else:
                return default
        return current

    def set_nested(self, *keys: str, value: Any) -> None:
        """设置嵌套字典的值

        Args:
            *keys: 嵌套的键路径
            value: 要设置的值

        Examples:
            >>> d = EnhancedDict()
            >>> d.set_nested('a', 'b', 'c', value=1)
            >>> d
            {'a': {'b': {'c': 1}}}
        """
        if not keys:
            return

        current: Any = self
        for key in keys[:-1]:
            if key not in current or not ensure_dict(current[key]):
                current[key] = EnhancedDict()
            current = current[key]

        final_key = keys[-1]

        # 类型检查（如果启用且是顶层键）
        if (
            hasattr(self, "_enable_type_check")
            and self._enable_type_check
            and hasattr(self, "_type_hints")
            and self._type_hints
            and len(keys) == 1
            and final_key in self._type_hints
        ):
            expected_type = self._type_hints[final_key]
            is_valid, error = _check_type(value, expected_type)
            if not is_valid:
                raise TypeError(f"Key '{final_key}': {error}")

        current[final_key] = self._convert_value(value)

    def validate_types(self, type_hints: dict[str, Any] | None = None) -> Self:
        """验证当前字典的值是否符合类型提示

        Args:
            type_hints: 类型提示字典，如果为 None 则使用实例的 _type_hints

        Returns:
            self (支持链式调用)

        Raises:
            TypeError: 如果类型不匹配
        """
        hints = (
            type_hints
            if type_hints is not None
            else getattr(self, "_type_hints", None)
        )
        if hints is None:
            return self

        for key, expected_type in hints.items():
            if key in self:
                is_valid, error = _check_type(self[key], expected_type)
                if not is_valid:
                    raise TypeError(f"Key '{key}': {error}")
        return self

    def enable_type_check(self, type_hints: dict[str, Any]) -> Self:
        """启用类型检查功能

        Args:
            type_hints: 类型提示字典

        Returns:
            self (支持链式调用)
        """
        self._type_hints = type_hints
        self._enable_type_check = True
        return self

    def disable_type_check(self) -> Self:
        """禁用类型检查功能

        Returns:
            self (支持链式调用)
        """
        self._enable_type_check = False
        return self

    # 以下是确保兼容所有字典操作的方法重写
    @override
    def update(self, m: Any = None, **kwargs: Any) -> None:
        """更新字典，自动转换嵌套字典"""
        if m is not None:
            if hasattr(m, "items"):
                for key, value in m.items():
                    self[key] = self._convert_value(value)
            else:
                for key, value in m:
                    self[key] = self._convert_value(value)

        for key, value in kwargs.items():
            self[key] = self._convert_value(value)

    @override
    def setdefault(self, key: str, default: Any = None) -> Any:
        """设置默认值，自动转换"""
        if key not in self:
            self[key] = self._convert_value(default)
        return self[key]

    @override
    def __repr__(self) -> str:
        """使用父类的 __repr__ 方法"""
        return super().__repr__()

    @override
    def __str__(self) -> str:
        """使用父类的 __str__ 方法"""
        return super().__str__()
