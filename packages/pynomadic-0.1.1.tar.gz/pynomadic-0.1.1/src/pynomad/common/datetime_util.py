"""时间处理工具模块"""

from datetime import date, datetime, time


def parse_date(value: date | datetime | str, format: str = "") -> date:
    """解析日期字符串为 date 对象

    Args:
        value: 日期字符串或日期对象
        format: 日期格式,如果为空则尝试智能识别常用格式

    Returns:
        解析后的 date 对象

    Raises:
        ValueError: 当无法解析日期时

    Examples:
        >>> parse_date("2024-01-15")
        datetime.date(2024, 1, 15)
        >>> parse_date("2024/01/15")
        datetime.date(2024, 1, 15)
        >>> parse_date("2024年01月15日")
        datetime.date(2024, 1, 15)
        >>> parse_date("01/15/2024", "%m/%d/%Y")
        datetime.date(2024, 1, 15)
        >>> parse_date(datetime(2024, 1, 15, 10, 30, 45))
        datetime.date(2024, 1, 15)
        >>> parse_date(date(2024, 1, 15))
        datetime.date(2024, 1, 15)
    """
    # 如果已经是 date 或 datetime 对象,直接返回 date 部分
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value

    common_formats: list[str] = [
        "%Y-%m-%d",  # 2024-01-15
        "%Y/%m/%d",  # 2024/01/15
        "%Y%m%d",  # 20240115
        "%Y年%m月%d日",  # 2024年01月15日
        "%d-%m-%Y",  # 15-01-2024
        "%d/%m/%Y",  # 15/01/2024
        "%m/%d/%Y",  # 01/15/2024
        "%b %d, %Y",  # Jan 15, 2024
        "%B %d, %Y",  # January 15, 2024
    ]

    if format:
        dt = datetime.strptime(value, format)
        return dt.date()

    for fmt in common_formats:
        try:
            dt = datetime.strptime(value, fmt)
            return dt.date()
        except ValueError:
            continue

    raise ValueError(f"无法解析日期字符串: {value}")


def parse_datetime(value: datetime | str, format: str = "") -> datetime:
    """解析日期时间字符串为 datetime 对象

    Args:
        value: 日期时间字符串或 datetime 对象
        format: 日期时间格式,如果为空则尝试智能识别常用格式

    Returns:
        解析后的 datetime 对象

    Raises:
        ValueError: 当无法解析日期时间时

    Examples:
        >>> parse_datetime("2024-01-15 10:30:45")
        datetime.datetime(2024, 1, 15, 10, 30, 45)
        >>> parse_datetime("2024/01/15 10:30:45")
        datetime.datetime(2024, 1, 15, 10, 30, 45)
        >>> parse_datetime("2024年01月15日 10时30分45秒")
        datetime.datetime(2024, 1, 15, 10, 30, 45)
        >>> parse_datetime("01/15/2024 10:30", "%m/%d/%Y %H:%M")
        datetime.datetime(2024, 1, 15, 10, 30, 0)
        >>> parse_datetime(datetime(2024, 1, 15, 10, 30, 45))
        datetime.datetime(2024, 1, 15, 10, 30, 45)
    """
    # 如果已经是 datetime 对象,直接返回
    if isinstance(value, datetime):
        return value

    common_formats: list[str] = [
        "%Y-%m-%d %H:%M:%S",  # 2024-01-15 10:30:45
        "%Y/%m/%d %H:%M:%S",  # 2024/01/15 10:30:45
        "%Y年%m月%d日 %H时%M分%S秒",  # 2024年01月15日 10时30分45秒
        "%Y-%m-%d %H:%M",  # 2024-01-15 10:30
        "%Y/%m/%d %H:%M",  # 2024/01/15 10:30
        "%Y%m%d%H%M%S",  # 20240115103045
        "%Y%m%d %H%M%S",  # 20240115 103045
        "%d-%m-%Y %H:%M:%S",  # 15-01-2024 10:30:45
        "%d/%m/%Y %H:%M:%S",  # 15/01/2024 10:30:45
        "%m/%d/%Y %H:%M:%S",  # 01/15/2024 10:30:45
        "%b %d, %Y %H:%M:%S",  # Jan 15, 2024 10:30:45
        "%B %d, %Y %H:%M:%S",  # January 15, 2024 10:30:45
    ]

    if format:
        return datetime.strptime(value, format)

    for fmt in common_formats:
        try:
            return datetime.strptime(value, fmt)
        except ValueError:
            continue

    raise ValueError(f"无法解析日期时间字符串: {value}")


def parse_time(value: datetime | time | str, format: str = "") -> time:
    """解析时间字符串为 time 对象

    Args:
        value: 时间字符串或时间对象
        format: 时间格式,如果为空则尝试智能识别常用格式

    Returns:
        解析后的 time 对象

    Raises:
        ValueError: 当无法解析时间时

    Examples:
        >>> parse_time("10:30:45")
        datetime.time(10, 30, 45)
        >>> parse_time("10:30")
        datetime.time(10, 30, 0)
        >>> parse_time("10时30分45秒")
        datetime.time(10, 30, 45)
        >>> parse_time("10:30:45 AM", "%I:%M:%S %p")
        datetime.time(10, 30, 45)
        >>> parse_time(time(10, 30, 45))
        datetime.time(10, 30, 45)
        >>> parse_time(datetime(2024, 1, 15, 10, 30, 45))
        datetime.time(10, 30, 45)
    """
    # 如果已经是 time 对象,直接返回
    if isinstance(value, time):
        return value
    # 如果是 datetime 对象,返回 time 部分
    if isinstance(value, datetime):
        return value.time()

    common_formats: list[str] = [
        "%H:%M:%S",  # 10:30:45
        "%H:%M:%S.%f",  # 10:30:45.123456
        "%H:%M",  # 10:30
        "%I:%M:%S %p",  # 10:30:45 AM/PM
        "%I:%M %p",  # 10:30 AM/PM
        "%H时%M分%S秒",  # 10时30分45秒
        "%H时%M分",  # 10时30分
        "%H%M%S",  # 103045
        "%H%M",  # 1030
    ]

    if format:
        return datetime.strptime(value, format).time()

    for fmt in common_formats:
        try:
            return datetime.strptime(value, fmt).time()
        except ValueError:
            continue

    raise ValueError(f"无法解析时间字符串: {value}")


def format_date(value: date | datetime | str, format: str = "%Y-%m-%d") -> str:
    """将日期对象或字符串转换为格式化字符串

    注意：对于字符串输入，会使用智能模式自动识别常用日期格式，然后按指定的 format 输出。

    Args:
        value: 日期对象 (date 或 datetime) 或日期字符串
        format: 输出的日期格式,默认使用 "%Y-%m-%d"

    Returns:
        格式化后的日期字符串

    Raises:
        ValueError: 当无法解析日期字符串时

    Examples:
        >>> from datetime import date, datetime
        >>> format_date(date(2024, 1, 15))
        '2024-01-15'
        >>> format_date(datetime(2024, 1, 15, 10, 30, 45))
        '2024-01-15'
        >>> format_date(date(2024, 1, 15), "%Y/%m/%d")
        '2024/01/15'
        >>> format_date(date(2024, 1, 15), "%Y年%m月%d日")
        '2024年01月15日'
        >>> format_date("2024-01-15")
        '2024-01-15'
        >>> format_date("2024/01/15", "%Y-%m-%d")
        '2024-01-15'
    """
    # 如果是字符串,先解析为 date 对象（使用智能模式）
    if isinstance(value, str):
        parsed_date = parse_date(value, "")
        return parsed_date.strftime(format)

    # 如果是 datetime 对象,先转换为 date
    if isinstance(value, datetime):
        value = value.date()

    return value.strftime(format)


def format_datetime(value: datetime | str, format: str = "%Y-%m-%d %H:%M:%S") -> str:
    """将日期时间对象或字符串转换为格式化字符串

    注意：对于字符串输入，会使用智能模式自动识别常用日期时间格式，然后按指定的 format 输出。

    Args:
        value: 日期时间对象或日期时间字符串
        format: 输出的日期时间格式,默认使用 "%Y-%m-%d %H:%M:%S"

    Returns:
        格式化后的日期时间字符串

    Raises:
        ValueError: 当无法解析日期时间字符串时

    Examples:
        >>> from datetime import datetime
        >>> format_datetime(datetime(2024, 1, 15, 10, 30, 45))
        '2024-01-15 10:30:45'
        >>> format_datetime(datetime(2024, 1, 15, 10, 30, 45), "%Y/%m/%d %H:%M")
        '2024/01/15 10:30'
        >>> format_datetime(datetime(2024, 1, 15, 10, 30, 45), "%Y年%m月%d日 %H时%M分%S秒")
        '2024年01月15日 10时30分45秒'
        >>> format_datetime("2024-01-15 10:30:45")
        '2024-01-15 10:30:45'
        >>> format_datetime("2024/01/15 10:30", "%Y-%m-%d %H:%M:%S")
        '2024-01-15 10:30:00'
    """
    # 如果是字符串,先解析为 datetime 对象（使用智能模式）
    if isinstance(value, str):
        parsed_datetime = parse_datetime(value, "")
        return parsed_datetime.strftime(format)

    return value.strftime(format)


def format_time(value: time | datetime | str, format: str = "%H:%M:%S") -> str:
    """将时间对象或字符串转换为格式化字符串

    注意：对于字符串输入，会使用智能模式自动识别常用时间格式，然后按指定的 format 输出。

    Args:
        value: 时间对象 (time 或 datetime) 或时间字符串
        format: 输出的时间格式,默认使用 "%H:%M:%S"

    Returns:
        格式化后的时间字符串

    Raises:
        ValueError: 当无法解析时间字符串时

    Examples:
        >>> from datetime import time, datetime
        >>> format_time(time(10, 30, 45))
        '10:30:45'
        >>> format_time(time(10, 30, 0), "%H:%M")
        '10:30'
        >>> format_time(time(10, 30, 45), "%H时%M分%S秒")
        '10时30分45秒'
        >>> format_time("10:30:45")
        '10:30:45'
        >>> format_time("10:30", "%H:%M:%S")
        '10:30:00'
        >>> format_time(datetime(2024, 1, 15, 10, 30, 45))
        '10:30:45'
    """
    # 如果是字符串,先解析为 time 对象（使用智能模式）
    if isinstance(value, str):
        parsed_time = parse_time(value, "")
        return parsed_time.strftime(format)

    # 如果是 datetime 对象,提取 time 部分
    if isinstance(value, datetime):
        value = value.time()

    return value.strftime(format)


def year_end(value: date | datetime | str = "", format: str = "") -> date:
    """获取指定日期的年末日期（12月31日）

    Args:
        value: 日期字符串、date 或 datetime 对象
        format: 日期格式,如果为空则尝试智能识别常用格式

    Returns:
        该年的年末日期（12月31日）

    Raises:
        ValueError: 当无法解析日期时

    Examples:
        >>> year_end("2024-06-15")
        datetime.date(2024, 12, 31)
        >>> year_end("2024-01-01")
        datetime.date(2024, 12, 31)
        >>> year_end(date(2024, 12, 31))
        datetime.date(2024, 12, 31)
        >>> year_end(datetime(2024, 8, 15, 10, 30, 45))
        datetime.date(2024, 12, 31)
    """
    value = value if value else date.today()
    dt = parse_date(value, format)
    return date(dt.year, 12, 31)


def year_start(value: date | datetime | str = "", format: str = "") -> date:
    """获取指定日期的年初日期（1月1日）

    Args:
        value: 日期字符串、date 或 datetime 对象
        format: 日期格式,如果为空则尝试智能识别常用格式

    Returns:
        该年的年初日期（1月1日）

    Raises:
        ValueError: 当无法解析日期时

    Examples:
        >>> year_start("2024-06-15")
        datetime.date(2024, 1, 1)
        >>> year_start("2024-01-01")
        datetime.date(2024, 1, 1)
        >>> year_start(date(2024, 12, 31))
        datetime.date(2024, 1, 1)
        >>> year_start(datetime(2024, 8, 15, 10, 30, 45))
        datetime.date(2024, 1, 1)
    """
    value = value if value else date.today()
    dt = parse_date(value, format)
    return date(dt.year, 1, 1)


def datetime_to_timestamp(value: datetime | date | int | float) -> float:
    """将 datetime/date 对象或时间戳转换为时间戳（浮点数）

    Args:
        value: datetime 对象、date 对象或时间戳

    Returns:
        时间戳（秒，浮点数）

    Examples:
        >>> dt = datetime(2024, 1, 15, 10, 30, 45)
        >>> datetime_to_timestamp(dt)  # doctest: +SKIP
        1705297845.0
        >>> d = date(2024, 1, 15)
        >>> datetime_to_timestamp(d)  # doctest: +SKIP
        1705267200.0
        >>> datetime_to_timestamp(1705297845)
        1705297845.0
    """
    # 如果已经是数字（时间戳），直接返回
    if isinstance(value, (int, float)):
        return float(value)

    # 如果是 datetime 对象
    if isinstance(value, datetime):
        return value.timestamp()

    # 剩下的是 date 对象
    dt = datetime.combine(value, datetime.min.time())
    return dt.timestamp()


def timestamp_to_datetime(value: int | float | str) -> datetime:
    """将时间戳转换为 datetime 对象

    Args:
        value: 时间戳（秒，可以是 int、float 或 str）

    Returns:
        datetime 对象

    Raises:
        ValueError: 当时间戳无效时

    Examples:
        >>> timestamp_to_datetime(1705297845)
        datetime.datetime(2024, 1, 15, 10, 30, 45)
        >>> timestamp_to_datetime("1705297845")
        datetime.datetime(2024, 1, 15, 10, 30, 45)
    """
    # 如果是字符串，先转换为 float
    if isinstance(value, str):
        value = float(value)

    return datetime.fromtimestamp(value)


def today() -> datetime:
    return datetime.today()
