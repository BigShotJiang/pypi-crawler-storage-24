"""ANSI颜色和样式枚举类定义"""

from abc import abstractmethod
from enum import IntEnum
from typing import override

from pynomad.common.types import EnumABCMeta


class AnsiBase(IntEnum, metaclass=EnumABCMeta):
    """ANSI基础枚举类"""

    @property
    def reset_all(self) -> int:
        """重置所有属性"""
        return 0


class AnsiColorBase(AnsiBase, metaclass=EnumABCMeta):
    """ANSI颜色基础枚举类"""

    @property
    def reset_foreground(self) -> int:
        """重置前景色"""
        return 39

    @property
    def reset_background(self) -> int:
        """重置背景色"""
        return 49

    @property
    @abstractmethod
    def back(self) -> int:
        """获取对应的背景色代码"""

    @property
    @abstractmethod
    def fore(self) -> int:
        """获取对应的前景色代码"""

    @property
    @abstractmethod
    def bright_fore(self) -> int:
        """获取对应的高亮前景色代码"""

    @property
    @abstractmethod
    def bright_back(self) -> int:
        """获取对应的高亮背景色代码"""


class Color(AnsiColorBase):
    """统一的ANSI颜色枚举类

    这个类替代了原来的6个颜色类，通过不同的属性方法提供所有颜色功能。
    基础颜色值使用0-7和9（默认），然后通过计算得到各种ANSI代码。

    Attributes:
        BLACK (int): 黑色，对应值0
        RED (int): 红色，对应值1
        GREEN (int): 绿色，对应值2
        YELLOW (int): 黄色，对应值3
        BLUE (int): 蓝色，对应值4
        MAGENTA (int): 品红色，对应值5
        CYAN (int): 青色，对应值6
        WHITE (int): 白色，对应值7
        DEFAULT (int): 默认颜色，对应值9
    """

    # 基础颜色值
    BLACK = 0  # 黑色
    RED = 1  # 红色
    GREEN = 2  # 绿色
    YELLOW = 3  # 黄色
    BLUE = 4  # 蓝色
    MAGENTA = 5  # 品红色
    CYAN = 6  # 青色
    WHITE = 7  # 白色
    DEFAULT = 9  # 默认颜色

    @property
    @override
    def back(self) -> int:
        """获取标准背景色代码 (40-47, 49)"""
        if self.value == Color.DEFAULT:
            return 49
        return 40 + self.value

    @property
    @override
    def fore(self) -> int:
        """获取标准前景色代码 (30-37, 39)"""
        if self.value == Color.DEFAULT:
            return 39
        return 30 + self.value

    @property
    @override
    def bright_fore(self) -> int:
        """获取高亮前景色代码 (90-97, 39)"""
        if self.value == Color.DEFAULT:
            return 39
        return 90 + self.value

    @property
    @override
    def bright_back(self) -> int:
        """获取高亮背景色代码 (100-107, 49)"""
        if self.value == Color.DEFAULT:
            return 49
        return 100 + self.value

    # 类方法用于从不同的ANSI代码创建Color实例
    @classmethod
    def from_foreground_code(cls, code: int) -> "Color":
        """从前景色代码创建Color实例

        Args:
            code: 前景色代码 (30-37, 90-97, 39)

        Returns:
            对应的Color枚举实例

        Raises:
            ValueError: 如果代码无效
        """
        if 30 <= code <= 37:
            return Color(code - 30)
        if 90 <= code <= 97:
            return Color(code - 90)
        if code == 39:
            return Color.DEFAULT
        raise ValueError(f"Invalid foreground color code: {code}")

    @classmethod
    def from_background_code(cls, code: int) -> "Color":
        """从背景色代码创建Color实例

        Args:
            code: 背景色代码 (40-47, 100-107, 49)

        Returns:
            对应的Color枚举实例

        Raises:
            ValueError: 如果代码无效
        """
        if 40 <= code <= 47:
            return Color(code - 40)
        if 100 <= code <= 107:
            return Color(code - 100)
        if code == 49:
            return Color.DEFAULT
        raise ValueError(f"Invalid background color code: {code}")

    @classmethod
    def from_any_code(cls, code: int) -> "Color":
        """从任意颜色代码创建Color实例

        Args:
            code: 任意ANSI颜色代码

        Returns:
            对应的Color枚举实例

        Raises:
            ValueError: 如果代码无效
        """
        foreground_exception: ValueError | None = None
        background_exception: ValueError | None = None
        try:
            return cls.from_foreground_code(code)
        except ValueError as e:
            foreground_exception = e
        try:
            return cls.from_background_code(code)
        except ValueError as e:
            background_exception = e
        raise ValueError(
            f"Invalid color code: {code}"
        ) from foreground_exception or background_exception

    def to_ansi_sequence(
        self, color_type: str = "foreground", bright: bool = False
    ) -> str:
        """转换为ANSI转义序列

        Args:
            color_type: 'foreground' 或 'background'
            bright: 是否使用高亮颜色

        Returns:
            ANSI转义序列字符串，如 '\\033[31m'
        """
        if color_type == "foreground":
            code = self.bright_fore if bright else self.fore
        elif color_type == "background":
            code = self.bright_back if bright else self.back
        else:
            raise ValueError(f"Invalid color_type: {color_type}")

        return f"\033[{code}m"


class AnsiStyle(AnsiBase):
    """ANSI样式枚举类"""

    RESET = 0
    """重置所有属性"""
    BOLD = 1
    """加粗"""
    DIM = 2
    """暗淡"""
    ITALIC = 3
    """斜体"""
    UNDERLINE = 4
    """下划线"""
    BLINK = 5
    """闪烁"""
    REVERSE = 7
    """反转"""
    HIDDEN = 8
    """隐藏"""
    STRIKETHROUGH = 9
    """删除线"""
    DOUBLE_UNDERLINE = 21
    """双下划线"""

    @property
    def reset(self):
        """重置样式"""
        if self.value == AnsiStyle.RESET:
            return AnsiStyle.RESET
        if self.value == AnsiStyle.BOLD:
            return 22
        if self.value == AnsiStyle.DOUBLE_UNDERLINE:
            return 24
        return self.value + 20
