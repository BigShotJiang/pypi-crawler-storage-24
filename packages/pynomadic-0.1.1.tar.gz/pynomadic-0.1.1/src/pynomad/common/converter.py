"""确保类型,用于处理类型检查器无法确定类型的情况

注意: 字典相关函数已迁移到 dict_utils.py,此处重新导出以保持向后兼容。
"""

from typing import Any, cast

from pynomad.common.types import AnyList

# 从 dict_utils 导入字典相关函数,保持向后兼容
from pynomad.common.dict_utils import (
    convert_dict_value_to_str,
    deep_merge,
    ensure_dict,
    ensure_str_dict,
    flatten_dict,
    is_dict,
)

_ = convert_dict_value_to_str
_ = deep_merge
_ = ensure_dict
_ = ensure_str_dict
_ = flatten_dict
_ = is_dict


def ensure_str(value: object) -> str | None:
    """确保值为字符串类型

    Args:
        value: 待检查的值

    Returns:
        str | None: 如果是字符串则返回，否则返回 None
    """
    if isinstance(value, str):
        return value
    return None


def is_list(value: Any) -> bool:
    """检查值是否为列表类型

    Args:
        value: 待检查的值

    Returns:
        bool: 如果是列表则返回 True，否则返回 False
    """
    return isinstance(value, list)


def ensure_list(value: Any) -> AnyList | None:
    """确保值为列表类型

    Args:
        value: 待检查的值

    Returns:
        list[object] | None: 如果是列表则返回，否则返回 None
    """
    if is_list(value):
        return cast(AnyList, value)
    return None
