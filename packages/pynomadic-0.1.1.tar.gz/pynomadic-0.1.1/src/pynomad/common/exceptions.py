"""公共异常模块

定义常用的异常类型，用于与 Result 的错误分类对应。
"""

from __future__ import annotations

from typing import Any


class ClientException(Exception):
    """客户端异常

    用于表示客户端传入的参数错误、无效输入等。
    对应 Result.client_error()
    """

    def __init__(self, message: str = "客户端错误") -> None:
        super().__init__(message)


class NetworkException(Exception):
    """网络异常

    用于表示网络连接问题，如超时、DNS 解析失败等。
    对应 Result.network_error()
    """

    def __init__(self, message: str = "网络错误") -> None:
        super().__init__(message)


class RequestException(Exception):
    """请求异常"""

    def __init__(self, message: str = "请求网络失败") -> None:
        super().__init__(message)


class LoginException(RequestException):
    """登录异常"""

    def __init__(self, message: str = "登录失败") -> None:
        super().__init__(message)


class ServerException(Exception):
    """服务端异常

    用于表示服务器内部错误、服务不可用等。
    对应 Result.server_error()
    """

    def __init__(self, message: str = "服务端错误") -> None:
        super().__init__(message)


class ThirdPartyException(Exception):
    """第三方服务异常

    用于表示外部 API 调用失败等第三方服务问题。
    对应 Result.third_party_error()
    """

    def __init__(self, message: str = "第三方服务错误") -> None:
        super().__init__(message)


class ValidationException(ClientException):
    """验证异常

    用于表示数据验证失败，如必填字段缺失、格式不正确等。
    """

    def __init__(self, message: str = "验证失败") -> None:
        super().__init__(message)


class NotFoundException(ClientException):
    """未找到异常

    用于表示资源不存在的情况，如用户不存在、文件不存在等。
    """

    def __init__(self, message: str = "资源未找到") -> None:
        super().__init__(message)


class ConflictException(ClientException):
    """冲突异常

    用于表示资源冲突，如重复创建、状态冲突等。
    """

    def __init__(self, message: str = "资源冲突") -> None:
        super().__init__(message)


class PermissionException(ClientException):
    """权限异常

    用于表示权限不足或未授权访问。
    """

    def __init__(self, message: str = "权限不足") -> None:
        super().__init__(message)


class TimeoutException(NetworkException):
    """超时异常

    用于表示操作超时的情况。
    """

    def __init__(self, message: str = "操作超时") -> None:
        super().__init__(message)


class RateLimitException(NetworkException):
    """限流异常

    用于表示触发了速率限制。
    """

    def __init__(self, message: str = "请求过于频繁") -> None:
        super().__init__(message)


class CacheMissException(ClientException):
    """缓存未命中异常

    用于表示缓存中找不到指定的键。
    """

    def __init__(self, message: str = "缓存未命中") -> None:
        super().__init__(message)


class CacheExpiredException(ClientException):
    """缓存已过期异常

    用于表示缓存项已过期。
    """

    def __init__(self, message: str = "缓存已过期") -> None:
        super().__init__(message)


class CacheValueException(ClientException):
    """缓存值异常

    用于表示缓存值格式不正确或类型不匹配的情况。
    """

    def __init__(self, message: str = "缓存值异常") -> None:
        super().__init__(message)


class CacheTypeNotInitializedException(ClientException):
    """缓存类型未初始化异常

    用于表示缓存类型无法推导或未初始化的情况。
    例如：在调用 append 或 extend 方法时，无法确定缓存应该使用的数据类型。
    """

    def __init__(self, message: str = "缓存类型未初始化") -> None:
        super().__init__(message)


class CacheException(ServerException):
    """缓存操作异常

    用于表示缓存操作失败的情况，如文件读写失败、序列化失败等。
    """

    def __init__(self, message: str = "缓存操作失败") -> None:
        super().__init__(message)


class NeedsRefreshException(Exception):
    """缓存刷新需求异常

    用于 DataFrame 缓存装饰器的 value_loader 中，当从缓存提取数据失败时抛出。
    可携带新的参数用于重新调用被装饰的方法。

    示例场景：
    - 缓存存储了 2024-01-01 到 2024-12-31 的股票数据
    - 查询 2024-05-01 到 2025-05-01 时，部分命中、部分未命中
    - value_loader 提取失败后抛出此异常，返回调整后的日期范围参数
    """

    def __init__(
        self,
        message: str = "缓存未命中，需要刷新数据",
        new_args: tuple[Any, ...] | None = None,
        new_kwargs: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.new_args = new_args
        self.new_kwargs = new_kwargs
