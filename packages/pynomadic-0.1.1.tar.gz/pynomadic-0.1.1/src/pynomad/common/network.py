"""网络连接"""

import socket
import threading
import time

from pynomad.common.decorator import singleton


@singleton
class NetworkChecker:
    """网络检查器（单例）

    使用后台线程定期检查网络状态，避免每次调用都进行网络检查。
    """

    def __init__(
        self,
        check_interval: float = 30.0,
        host: str = "8.8.8.8",
        port: int = 53,
        timeout: float = 3.0,
    ) -> None:
        """初始化网络检查器

        Args:
            check_interval: 检查间隔（秒）
            host: 要测试的主机地址
            port: 端口号
            timeout: 超时时间（秒）
        """
        self._check_interval = check_interval
        self._host = host
        self._port = port
        self._timeout = timeout
        self._is_online: bool = True
        self._running: bool = False
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        """启动后台检查线程"""
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._check_loop, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        """停止后台检查线程"""
        if not self._running:
            return
        self._running = False
        if self._thread:
            self._thread.join(timeout=5.0)
            self._thread = None

    def _check_loop(self) -> None:
        """后台检查循环"""
        while self._running:
            self._is_online = self._do_check()
            time.sleep(self._check_interval)

    def _do_check(self) -> bool:
        """执行网络检查

        Returns:
            网络是否可用
        """
        try:
            socket.setdefaulttimeout(self._timeout)
            socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect(
                (self._host, self._port)
            )
            return True
        except socket.error:
            return False

    @property
    def is_online(self) -> bool:
        """获取网络状态"""
        if not self._running:
            self.start()
        return self._is_online


def check_network(
    check_interval: float = 30.0,
    host: str = "8.8.8.8",
    port: int = 53,
    timeout: float = 3.0,
) -> bool:
    """检查网络是否可用（带缓存）

    使用后台线程定期检查网络状态，避免每次调用都进行网络检查。

    Args:
        check_interval: 检查间隔（秒）
        host: 要测试的主机地址
        port: 端口号
        timeout: 超时时间（秒）

    Returns:
        网络是否可用
    """
    checker = NetworkChecker(
        check_interval=check_interval,
        host=host,
        port=port,
        timeout=timeout,
    )
    return checker.is_online


def stop_check_network() -> None:
    """停止后台网络检查线程"""
    checker = NetworkChecker()
    checker.stop()
