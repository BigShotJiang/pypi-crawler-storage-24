# -*- coding: utf-8 -*-
"""
通用装饰器模块

提供各种实用的装饰器，包括单例模式装饰器等。
"""
from __future__ import annotations
import functools
import threading
import time
from collections.abc import Callable
from typing import Any
import warnings


# 定义通用的返回类型变量
type AnyFunc = Callable[..., Any]
type Decorator = Callable[[AnyFunc], AnyFunc]
type ExceptionTypes = tuple[type[Exception], ...]


def singleton[T](cls: type[T]) -> type[T]:
    """单例模式装饰器

    使用线程安全的双重检查锁定模式实现单例。

    Args:
        cls: 要装饰的类

    Returns:
        Type[T]: 装饰后的类

    Example:
        @singleton
        class MyClass:
            def __init__(self):
                self.value = 0

        # 所有实例都是同一个对象
        a = MyClass()
        b = MyClass()
        assert a is b  # True
    """

    original_init = cls.__init__

    setattr(cls, "_instance", None)
    setattr(cls, "_lock", threading.Lock())

    def __new__(cls: type[T], *args: object, **kwargs: object) -> T:
        """重写__new__方法实现单例"""
        instance = getattr(cls, "_instance", None)
        if instance is None:
            lock = getattr(cls, "_lock")
            if not lock:
                warnings.warn("单例锁未初始化，无法创建实例")
                return object.__new__(cls)
            with lock:
                instance = getattr(cls, "_instance", None)
                if instance is None:
                    instance = object.__new__(cls)
                    setattr(cls, "_instance", instance)

        return instance

    def __init__(self: T, *args: object, **kwargs: object) -> None:
        """重写__init__方法，只在第一次创建时调用原始__init__"""
        initialized = getattr(cls, "_instance_initialized", False)
        if not initialized:
            lock = getattr(cls, "_lock")
            if not lock:
                warnings.warn("单例锁未初始化，无法初始化实例")
                return
            with lock:
                initialized = getattr(cls, "_instance_initialized", False)
                if not initialized:
                    if original_init is not object.__init__:
                        original_init(self, *args, **kwargs)
                    setattr(cls, "_instance_initialized", True)

    cls.__new__ = __new__
    cls.__init__ = __init__

    @classmethod
    def get_instance(cls: type[T], *args: object, **kwargs: object) -> T:
        """获取单例实例，如果不存在则创建"""
        return cls(*args, **kwargs)

    @classmethod
    def has_instance(cls: type[T]) -> bool:
        """检查是否已存在实例"""
        return getattr(cls, "_instance", None) is not None

    @classmethod
    def clear_instance(cls: type[T]) -> None:
        """清除单例实例（主要用于测试）"""
        lock = getattr(cls, "_lock")
        if not lock:
            warnings.warn("单例锁未初始化，无法清除实例")
            return
        with lock:
            setattr(cls, "_instance", None)
            setattr(cls, "_instance_initialized", False)

    cls.get_instance = get_instance
    cls.has_instance = has_instance
    cls.clear_instance = clear_instance

    return cls


def thread_safe(
    max_workers: int | None = None,
) -> Decorator:
    """线程安全装饰器

    确保被装饰的函数在多线程环境下的安全性。

    Args:
        max_workers: 最大并发线程数，None表示不限制

    Returns:
        Callable: 装饰器函数

    Example:
        @thread_safe(max_workers=5)
        def process_data(data):
            # 处理数据的逻辑
            pass
    """

    def decorator(func: AnyFunc) -> AnyFunc:
        # 使用RLock支持可重入
        lock = threading.RLock()
        semaphore = threading.Semaphore(max_workers) if max_workers else None

        @functools.wraps(func)
        def wrapper(*args: object, **kwargs: object) -> object:
            # 如果没有指定max_workers，使用锁保证互斥访问
            if semaphore is None:
                with lock:
                    return func(*args, **kwargs)
            # 如果指定了max_workers，使用信号量限制并发数
            else:
                with semaphore:
                    return func(*args, **kwargs)

        return wrapper

    return decorator


def retry(
    max_attempts: int = 3,
    delay: float = 1.0,
    exceptions: ExceptionTypes = (Exception,),
    operate: str = "",
) -> Decorator:
    """重试装饰器

    当函数抛出指定异常时，自动重试指定次数。

    Args:
        max_attempts: 最大重试次数
        delay: 重试间隔（秒）
        exceptions: 需要重试的异常类型

    Returns:
        Callable: 装饰器函数

    Example:
        @retry(max_attempts=3, delay=2.0, exceptions=(ConnectionError,))
        def connect_server():
            # 连接服务器的逻辑
            pass
    """

    def decorator(func: AnyFunc) -> AnyFunc:
        @functools.wraps(func)
        def wrapper(*args: object, **kwargs: object) -> object:
            last_exception = None

            for attempt in range(max_attempts):
                try:
                    if operate:
                        from pynomad.logsystem.manager import (  # pylint:disable=c0415
                            get_logger,
                        )

                        logger = get_logger()
                        logger.info(f"正在对{operate}操作进行第{attempt+1}次重试")
                    return func(*args, **kwargs)
                except exceptions as e:
                    last_exception = e
                    if attempt < max_attempts - 1:

                        time.sleep(delay)
                    else:
                        break

            # 重试次数用完，抛出最后一个异常
            if last_exception is not None:
                raise last_exception
            raise RuntimeError("重试次数用完，但没有捕获到异常")

        return wrapper

    return decorator
