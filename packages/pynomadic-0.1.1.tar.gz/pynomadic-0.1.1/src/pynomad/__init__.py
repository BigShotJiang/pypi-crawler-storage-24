# import warnings

import pynomad.common.datetime_util as dt
import pynomad.cache.properties as cp
import pynomad.common.exceptions as ex
from pynomad.common.network import check_network
from pynomad.common.decorator import singleton, retry
from pynomad.common.environment import environ
from pynomad.result.result import Result, ResultAny
from pynomad.logsystem.manager import get_logger
from pynomad.cache.core.cache_registry import CacheRegistry
from pynomad.config.auto.properties import BuiltinProperties

__all__ = [
    # 模块导入
    "dt",
    "ex",
    "cp",
    # 通用装饰器导入
    "singleton",
    "retry",
    # 通用方法导入
    "get_logger",
    "check_network",
    # 返回类导入
    "Result",
    "ResultAny",
    # 属性类注入
    "BuiltinProperties",
    # 属性注入
    "environ",
    # 类导出
    "CacheRegistry",
]

# 动态导入基础缓存装饰器（使用加密系统，需要延迟导入）
try:
    # 手动注册缓存实现（确保在装饰器惰性导入前就完成注册）
    # 基础缓存实现（必需）
    from pynomad.cache.impl.memory_cache import MemoryCache
    from pynomad.cache.impl.pickle_cache import PickleCache

    CacheRegistry._registry["memory"] = MemoryCache  # type: ignore
    CacheRegistry._registry["pickle"] = PickleCache  # type: ignore
    from pynomad.cache.decorator.memory_decorator import memcached
    from pynomad.cache.decorator.pickle_decorator import pickled
    from pynomad.cache.decorator.multi_level import multi_level_cached

    __all__.extend(["memcached", "pickled", "multi_level_cached"])
except ImportError as e:
    # warnings.warn(f"无法导入基础缓存装饰器: {e}")
    pass
logger = get_logger()
# 动态添加可选依赖的导入
try:
    from pynomad.cache.decorator.redis_decorator import rediscached  # type: ignore
    from pynomad.cache.impl.redis_cache import RedisCache  # 添加导入

    CacheRegistry._registry["redis"] = RedisCache  # type: ignore # 手动注册

    __all__.append("rediscached")
except ImportError as e:
    # warnings.warn(f"无法导入 redis 缓存装饰器: {e}。如需使用，请安装 redis 依赖")
    pass
try:
    from pynomad.cache.dataframe.df_redis_decorator import df_rediscached  # type: ignore

    __all__.append("df_rediscached")
except ImportError as e:
    # warnings.warn(
    #     f"无法导入 df_rediscached 缓存装饰器: {e}。如需使用，请安装 redis和pandas 依赖"
    # )
    pass
try:
    import sqlalchemy  # type: ignore # 检查 sqlalchemy 是否安装
    from pynomad.cache.decorator.sql_decorator import sqlcached
    from pynomad.cache.impl.sql_cache import SQLCache  # type: ignore # 添加导入

    __all__.append("sqlcached")
except ImportError as e:
    # warnings.warn(f"无法导入 SQL 缓存装饰器: {e}。如需使用，请安装 sqlalchemy 依赖")
    pass

try:

    from pynomad.cache.dataframe.df_memory_decorator import df_memcached
    from pynomad.cache.dataframe.df_pickle_decorator import df_pickled

    __all__.extend(["df_memcached", "df_pickled"])
except ImportError as e:
    # warnings.warn(f"无法导入 DataFrame 缓存装饰器: {e}。如需使用，请安装 pandas 依赖")
    pass
