"""进度条模块，提供非阻塞的进度显示功能"""

import threading
import time
from types import TracebackType
from pynomad.common.ansi import AnsiStyle, Color
from pynomad.console.base import BasePrint


class ProgressBar:
    """进度条类，支持非阻塞的进度显示"""

    def __init__(
        self,
        total: int,
        description: str = "",
        width: int = 50,
        fill_char: str = "█",
        empty_char: str = "░",
        show_percent: bool = True,
        show_eta: bool = True,
        color: Color = Color.BLUE,
        auto_refresh: bool = True,
        refresh_interval: float = 0.1,
    ) -> None:
        """
        初始化进度条

        Args:
            total: 总进度数
            description: 进度条描述文字
            width: 进度条宽度（字符数）
            fill_char: 已填充部分的字符
            empty_char: 未填充部分的字符
            show_percent: 是否显示百分比
            show_eta: 是否显示预计剩余时间
            color: 进度条颜色
            auto_refresh: 是否自动刷新
            refresh_interval: 自动刷新间隔（秒）
        """
        super().__init__()
        self.total = total
        self.current = 0
        self.description = description
        self.width = width
        self.fill_char = fill_char
        self.empty_char = empty_char
        self.show_percent = show_percent
        self.show_eta = show_eta
        self.color = color
        self.auto_refresh = auto_refresh
        self.refresh_interval = refresh_interval

        self._start_time = time.time()
        self._last_update_time = self._start_time
        self._is_running = False
        self._thread: threading.Thread | None = None
        self._lock: threading.Lock = threading.Lock()
        self._printer_instance: BasePrint | None = None

    def set_printer(self, printer: BasePrint) -> None:
        """设置关联的Printer实例"""
        self._printer_instance = printer

    def _render_bar(self) -> str:
        """渲染进度条字符串"""
        if self.total <= 0:
            percentage = 1.0
        else:
            percentage = min(1.0, self.current / self.total)

        filled_length = int(self.width * percentage)
        progressbar = self.fill_char * filled_length + self.empty_char * (
            self.width - filled_length
        )

        # 构建完整显示文本
        parts: list[str] = []
        if self.description:
            parts.append(f"{self.description}:")
        parts.append(f"[{progressbar}]")

        if self.show_percent:
            parts.append(f"{percentage:.1%}")

        if self.show_eta and self.current > 0:
            elapsed = time.time() - self._start_time
            if self.current < self.total:
                rate = self.current / elapsed
                if rate > 0:
                    remaining = (self.total - self.current) / rate
                    parts.append(f"ETA: {remaining:.1f}s")
            else:
                parts.append(f"Time: {elapsed:.1f}s")

        return " ".join(parts)

    def _display(self) -> None:
        """显示进度条（使用回车符覆盖当前行）"""
        bar_text = self._render_bar()

        if (
            not self._printer_instance
            or not self._printer_instance.should_use_colors()
        ):
            # 清除当前行并输出新的进度条
            print(f"\r\033[K{bar_text}", end="", flush=True)
        else:
            # 使用carriage return回到行首并清除整行
            print("\r\033[K", end="", flush=True)
            self._printer_instance.printcolor(
                bar_text, foreground=self.color, style=AnsiStyle.BOLD, end=""
            )

    def _auto_refresh_loop(self) -> None:
        """自动刷新循环（在单独线程中运行）"""
        while self._is_running:
            with self._lock:
                if self._is_running:
                    self._display()
            time.sleep(self.refresh_interval)

    def start(self) -> None:
        """启动进度条"""
        with self._lock:
            if self._is_running:
                return

            self._is_running = True
            self._start_time = time.time()
            self._last_update_time = self._start_time

            if self.auto_refresh:
                self._thread = threading.Thread(
                    target=self._auto_refresh_loop, daemon=True
                )
                self._thread.start()
            else:
                self._display()

    def update(self, value: int = 1) -> None:
        """更新进度

        Args:
            value: 增加的进度值，默认为1
        """
        with self._lock:
            # 允许在未启动状态下更新进度（用于手动模式）
            if not self._is_running and self.auto_refresh:
                return

            self.current = min(self.total, self.current + value)

            if not self.auto_refresh:
                self._display()

            # 如果达到了100%且是自动模式，则完成进度条
            should_finish = (
                self.current >= self.total
                and self.auto_refresh
                and self._is_running
            )

        # 在锁外调用finish()，避免死锁
        if should_finish:
            self.finish()

    def set_progress(self, value: int) -> None:
        """设置当前进度

        Args:
            value: 当前进度值
        """
        with self._lock:
            # 允许在未启动状态下设置进度（用于手动模式）
            if not self._is_running and self.auto_refresh:
                return

            self.current = min(self.total, max(0, value))

            if not self.auto_refresh:
                self._display()

            # 如果达到了100%且是自动模式，则完成进度条
            should_finish = (
                self.current >= self.total
                and self.auto_refresh
                and self._is_running
            )
        # 在锁外调用finish()，避免死锁
        if should_finish:
            self.finish()

    def finish(self) -> None:
        """完成进度条显示"""
        # 先停止运行标志，这样线程就会退出循环
        with self._lock:
            if not self._is_running:
                return
            self._is_running = False

        # 在锁外进行最终显示，避免死锁
        self._display()
        print()  # 换行

        # 等待线程结束
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=0.5)

    def reset(self, new_total: int | None = None) -> None:
        """重置进度条

        Args:
            new_total: 新的总进度数，None表示保持不变
        """
        # 先完成当前进度，避免在锁内调用finish()
        self.finish()

        with self._lock:
            if new_total is not None:
                self.total = new_total
            self.current = 0
            self._start_time = time.time()
            self._last_update_time = self._start_time

    def __enter__(self):
        """上下文管理器入口"""
        self.start()
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: Exception | None,
        exc_tb: TracebackType | None,
    ):
        """上下文管理器出口"""
        self.finish()
