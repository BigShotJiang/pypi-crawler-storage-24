"""
日志打印类
"""

import inspect
import json
import os
import sys
from pathlib import Path
from typing import TextIO, cast
from pynomad.common.ansi import AnsiStyle, Color
from pynomad.common.types import Level, OutputTarget
from pynomad.console.base import BasePrint


class PrintLogger(BasePrint):
    """日志打印类,受级别控制

    提供基于日志级别的彩色打印功能，只有达到或超过当前级别的日志才会被输出。
    每个级别都有预设的颜色和样式配置。支持控制台、文件或两者同时输出。
    """

    def __init__(  # pylint: disable=R0913
        self,
        level: Level = Level.INFO,
        output_target: OutputTarget = OutputTarget.CONSOLE,
        file_path: str | None = None,
        append_to_file: bool = True,
        enable_new_line: bool = True,
        pretty_print: bool = False,
        enable_caller_info: bool = False,
    ) -> None:
        super().__init__()
        self.level = level
        self._output_target = output_target
        self._file_path = file_path
        self._append_to_file = append_to_file
        self._file_handle: TextIO | None = None
        self._enable_new_line: bool = enable_new_line
        self._pretty_print: bool = pretty_print
        self._enable_caller_info: bool = enable_caller_info

        # 如果需要文件输出但没有提供文件路径，回退到控制台输出
        if self._output_target & OutputTarget.FILE and not file_path:
            print(
                "警告: 设置文件输出但未提供文件路径，回退到控制台输出",
                file=sys.stderr,
            )
            self._output_target = OutputTarget.CONSOLE
            self._file_path = None

        # 如果需要文件输出，初始化文件句柄
        if self._output_target & OutputTarget.FILE and file_path:
            self._init_file_handle()

        # 定义各级别的颜色配置
        self._level_colors = {
            Level.TRACE: (Color.CYAN, Color.DEFAULT, AnsiStyle.DIM),
            Level.VERBOSE: (Color.BLUE, Color.DEFAULT, AnsiStyle.DIM),
            Level.DEBUG: (Color.MAGENTA, Color.DEFAULT, AnsiStyle.DIM),
            Level.INFO: (Color.GREEN, Color.DEFAULT, AnsiStyle.RESET),
            Level.NOTICE: (Color.CYAN, Color.DEFAULT, AnsiStyle.BOLD),
            Level.WARN: (Color.YELLOW, Color.DEFAULT, AnsiStyle.BOLD),
            Level.ERROR: (Color.RED, Color.DEFAULT, AnsiStyle.BOLD),
            Level.FATAL: (Color.RED, Color.YELLOW, AnsiStyle.BOLD),
            Level.ALERT: (Color.MAGENTA, Color.YELLOW, AnsiStyle.BOLD),
            Level.EMERGENCY: (Color.WHITE, Color.RED, AnsiStyle.BOLD),
        }

    def _init_file_handle(self) -> None:
        """初始化文件句柄"""
        if not self._file_path:
            return

        try:
            mode = "a" if self._append_to_file else "w"
            # 确保目录存在
            dir_path = os.path.dirname(self._file_path)
            if dir_path:
                os.makedirs(dir_path, exist_ok=True)
            self._file_handle = open(self._file_path, mode, encoding="utf-8")
        except (OSError, IOError) as e:
            # 如果文件打开失败，回退到仅控制台输出
            print(
                f"警告: 无法打开日志文件 {self._file_path}: {e}",
                file=sys.stderr,
            )
            self._output_target = OutputTarget.CONSOLE
            self._file_handle = None

    def _close_file_handle(self) -> None:
        """关闭文件句柄"""
        if self._file_handle:
            try:
                self._file_handle.close()
            except (OSError, IOError):
                pass
            finally:
                self._file_handle = None

    def _get_caller_info(self) -> str:
        """获取调用者信息

        Returns:
            str: 格式为 "文件名:行号" 的字符串，例如 "main:42"
        """
        if not self._enable_caller_info:
            return ""

        # 获取调用堆栈
        stack = inspect.stack()
        if len(stack) <= 2:
            return ""

        # 跳过内部方法，找到真正的调用者
        # 堆栈: [0]=_get_caller_info, [1]=_log_if_enabled, [2]=日志方法(debug/info等), [3+]=真正的调用者
        for i, frame_info in enumerate(stack):
            # 跳过 _get_caller_info 和 _log_if_enabled
            if i <= 1:
                continue

            # 跳过日志方法
            # （trace, verbose, debug, info, notice, warn, error, critical, alert, emergency, log）
            method_name = frame_info.function
            if method_name in (
                "trace",
                "verbose",
                "debug",
                "info",
                "notice",
                "warn",
                "error",
                "critical",
                "alert",
                "emergency",
                "log",
            ):
                continue

            # 找到真正的调用者
            filename = Path(frame_info.filename).stem
            lineno = frame_info.lineno
            return f"[{filename}:{lineno}]"

        return ""

    def set_output_target(
        self,
        output_target: OutputTarget,
        file_path: str | None = None,
        append_to_file: bool = True,
    ) -> None:
        """设置输出目标

        Args:
            output_target: 输出目标类型
            file_path: 文件路径（如果输出到文件）
            append_to_file: 是否追加到文件末尾
        """
        # 关闭现有文件句柄
        self._close_file_handle()

        # 更新配置
        self._output_target = output_target
        self._file_path = file_path
        self._append_to_file = append_to_file

        # 如果需要文件输出，初始化新的文件句柄
        if self._output_target & OutputTarget.FILE:
            if file_path:
                self._init_file_handle()
            else:
                # 如果需要文件输出但没有提供路径，回退到控制台输出
                print(
                    "警告: 设置文件输出但未提供文件路径，回退到控制台输出",
                    file=sys.stderr,
                )
                self._output_target = OutputTarget.CONSOLE
                self._file_path = None
                self._file_handle = None

    def get_output_target(self) -> OutputTarget:
        """获取当前输出目标"""
        return self._output_target

    def get_file_path(self) -> str | None:
        """获取当前文件路径"""
        return self._file_path

    def _log_if_enabled(
        self,
        msg_level: Level,
        *msg: object,
        sep: str = " ",
        end: str = "\n",
        file: TextIO | None = None,
        flush: bool = True,
        pretty_print: bool | None = None,
    ) -> None:
        """如果级别启用则打印日志

        Args:
            msg_level: 日志级别
            *msg: 日志消息
            sep: 分隔符
            end: 结束符
            file: 输出文件
            flush: 是否刷新缓冲区，默认为 True
            pretty_print: 是否美化打印字典和列表，None 时使用全局配置
        """
        if pretty_print is None:
            pretty_print = self._pretty_print

        if not self.level.is_enabled_for(msg_level):
            return

        # 预处理消息，美化字典和列表
        if pretty_print:
            processed_msgs: list[object] = []
            for m in msg:
                if isinstance(m, dict | list):
                    try:
                        m = json.dumps(m, ensure_ascii=False, indent=4)
                        processed_msgs.append(m)
                    except Exception:
                        # 如果序列化失败，原样保留对象
                        processed_msgs.append(cast(object, m))
                else:
                    processed_msgs.append(m)
            msg = tuple(processed_msgs)

        # 获取级别的颜色配置
        foreground, background, style = self._level_colors.get(
            msg_level, (Color.DEFAULT, Color.DEFAULT, AnsiStyle.RESET)
        )

        # 构建级别前缀 (左对齐到最大长度9字符)
        level_name = msg_level.name  # 左对齐，9字符宽度
        caller_info = self._get_caller_info()
        prefix = f"[{level_name}]{caller_info}"

        # 合并消息内容
        message_content = sep.join(str(m) for m in msg)

        # 控制台输出
        if self._output_target & OutputTarget.CONSOLE:
            self.printcolor(
                prefix,
                message_content,
                foreground=foreground,
                background=background,
                style=style,
                sep=" ",  # 使用空格分隔前缀和消息
                end=end,
                file=file,  # 如果用户指定了file，使用用户的file
                flush=flush,
            )

        # 文件输出
        if self._output_target & OutputTarget.FILE and self._file_handle:
            # 文件输出不包含ANSI颜色代码
            plain_text = f"{prefix} {message_content}{end}"
            try:
                _ = self._file_handle.write(plain_text)
                if flush:
                    self._file_handle.flush()
            except (OSError, IOError) as e:
                # 如果写入失败，输出错误到stderr
                print(f"错误: 无法写入日志文件: {e}", file=sys.stderr)

    def newline(self):
        """换行"""
        if self._enable_new_line:
            self.printcolor("\n")

    def trace(
        self,
        *msg: object,
        sep: str = " ",
        end: str = "\n",
        file: TextIO | None = None,
        flush: bool = True,
        pretty_print: bool | None = None,
    ) -> None:
        """跟踪级别日志"""
        self._log_if_enabled(
            Level.TRACE,
            *msg,
            sep=sep,
            end=end,
            file=file,
            flush=flush,
            pretty_print=pretty_print,
        )

    def verbose(
        self,
        *msg: object,
        sep: str = " ",
        end: str = "\n",
        file: TextIO | None = None,
        flush: bool = True,
        pretty_print: bool | None = None,
    ) -> None:
        """详细级别日志"""
        self._log_if_enabled(
            Level.VERBOSE,
            *msg,
            sep=sep,
            end=end,
            file=file,
            flush=flush,
            pretty_print=pretty_print,
        )

    def debug(
        self,
        *msg: object,
        sep: str = " ",
        end: str = "\n",
        file: TextIO | None = None,
        flush: bool = True,
        pretty_print: bool | None = None,
    ) -> None:
        """调试级别日志"""
        self._log_if_enabled(
            Level.DEBUG,
            *msg,
            sep=sep,
            end=end,
            file=file,
            flush=flush,
            pretty_print=pretty_print,
        )

    def info(
        self,
        *msg: object,
        sep: str = " ",
        end: str = "\n",
        file: TextIO | None = None,
        flush: bool = True,
        pretty_print: bool | None = None,
    ) -> None:
        """信息级别日志"""
        self._log_if_enabled(
            Level.INFO,
            *msg,
            sep=sep,
            end=end,
            file=file,
            flush=flush,
            pretty_print=pretty_print,
        )

    def notice(
        self,
        *msg: object,
        sep: str = " ",
        end: str = "\n",
        file: TextIO | None = None,
        flush: bool = True,
        pretty_print: bool | None = None,
    ) -> None:
        """通知级别日志"""
        self._log_if_enabled(
            Level.NOTICE,
            *msg,
            sep=sep,
            end=end,
            file=file,
            flush=flush,
            pretty_print=pretty_print,
        )

    def warn(
        self,
        *msg: object,
        sep: str = " ",
        end: str = "\n",
        file: TextIO | None = None,
        flush: bool = True,
        pretty_print: bool | None = None,
    ) -> None:
        """警告级别日志"""
        self._log_if_enabled(
            Level.WARN,
            *msg,
            sep=sep,
            end=end,
            file=file,
            flush=flush,
            pretty_print=pretty_print,
        )

    def error(
        self,
        *msg: object,
        sep: str = " ",
        end: str = "\n",
        file: TextIO | None = None,
        flush: bool = True,
        pretty_print: bool | None = None,
    ) -> None:
        """错误级别日志"""
        self._log_if_enabled(
            Level.ERROR,
            *msg,
            sep=sep,
            end=end,
            file=file,
            flush=flush,
            pretty_print=pretty_print,
        )

    def critical(
        self,
        *msg: object,
        sep: str = " ",
        end: str = "\n",
        file: TextIO | None = None,
        flush: bool = True,
        pretty_print: bool | None = None,
    ) -> None:
        """严重级别日志"""
        self._log_if_enabled(
            Level.FATAL,
            *msg,
            sep=sep,
            end=end,
            file=file,
            flush=flush,
            pretty_print=pretty_print,
        )

    def alert(
        self,
        *msg: object,
        sep: str = " ",
        end: str = "\n",
        file: TextIO | None = None,
        flush: bool = True,
        pretty_print: bool | None = None,
    ) -> None:
        """警报级别日志"""
        self._log_if_enabled(
            Level.ALERT,
            *msg,
            sep=sep,
            end=end,
            file=file,
            flush=flush,
            pretty_print=pretty_print,
        )

    def emergency(
        self,
        *msg: object,
        sep: str = " ",
        end: str = "\n",
        file: TextIO | None = None,
        flush: bool = True,
        pretty_print: bool | None = None,
    ) -> None:
        """紧急级别日志"""
        self._log_if_enabled(
            Level.EMERGENCY,
            *msg,
            sep=sep,
            end=end,
            file=file,
            flush=flush,
            pretty_print=pretty_print,
        )

    def log(
        self,
        msg_level: Level,
        *msg: object,
        sep: str = " ",
        end: str = "\n",
        file: TextIO | None = None,
        flush: bool = True,
        pretty_print: bool | None = None,
    ) -> None:
        """通用日志方法

        Args:
            msg_level: 日志级别
            *msg: 日志消息
            sep: 分隔符
            end: 结束符
            file: 输出文件
            flush: 是否刷新缓冲区，默认为 True
            pretty_print: 是否美化打印字典和列表，None 时使用全局配置
        """
        self._log_if_enabled(
            msg_level,
            *msg,
            sep=sep,
            end=end,
            file=file,
            flush=flush,
            pretty_print=pretty_print,
        )

    def set_level(self, level: Level) -> None:
        """设置日志级别

        Args:
            level: 新的日志级别
        """
        self.level = level

    def get_level(self) -> Level:
        """获取当前日志级别

        Returns:
            Level: 当前日志级别
        """
        return self.level

    def set_pretty_print(self, pretty_print: bool) -> None:
        """设置是否美化打印字典和列表

        Args:
            pretty_print: 是否美化打印
        """
        self._pretty_print = pretty_print

    def get_pretty_print(self) -> bool:
        """获取当前美化打印配置

        Returns:
            bool: 当前美化打印配置
        """
        return self._pretty_print

    def set_enable_caller_info(self, enable: bool) -> None:
        """设置是否显示调用者信息

        Args:
            enable: 是否显示调用者信息
        """
        self._enable_caller_info = enable

    def get_enable_caller_info(self) -> bool:
        """获取当前调用者信息配置

        Returns:
            bool: 是否显示调用者信息
        """
        return self._enable_caller_info

    def set_enable_new_line(self, enable: bool) -> None:
        """设置是否启用换行

        Args:
            enable: 是否启用换行
        """
        self._enable_new_line = enable

    def get_enable_new_line(self) -> bool:
        """获取当前换行配置

        Returns:
            bool: 当前换行配置
        """
        return self._enable_new_line

    def is_enabled_for(self, level: Level) -> bool:
        """检查指定级别是否会被记录

        Args:
            level: 要检查的级别

        Returns:
            bool: 如果指定级别会被记录则返回 True
        """
        return self.level.is_enabled_for(level)

    def __del__(self) -> None:
        """析构函数，确保文件句柄被关闭"""
        self._close_file_handle()


class DefaultFactoryConfig:
    """为工厂方法类配置默认参数

    集中管理所有工厂函数的默认参数，方便统一修改。
    """

    # get_print_logger 默认值
    enable_new_line: bool = False
    print_logger_level: Level = Level.INFO
    print_logger_output_target: OutputTarget = OutputTarget.CONSOLE
    print_logger_append_to_file: bool = True

    # get_console_logger 默认值
    console_logger_level: Level = Level.DEBUG
    console_enable_new_line: bool = True
    console_use_global: bool = True
    console_enable_caller_info: bool = False

    # 全局日志器实例缓存
    console_logger_instance: PrintLogger | None = None

    # get_file_logger 默认值
    file_logger_level: Level = Level.INFO
    file_logger_path: str = "app.log"
    file_logger_append: bool = True

    # get_dual_logger 默认值
    dual_logger_level: Level = Level.INFO
    dual_logger_path: str = "app.log"
    dual_logger_append: bool = True

    # get_debug_logger 默认值
    debug_logger_path: str | None = None
    debug_logger_output_target: OutputTarget = OutputTarget.BOTH

    # get_production_logger 默认值
    production_logger_path: str = "logs/production.log"
    production_logger_min_level: Level = Level.INFO


def get_print_logger(
    level: Level = DefaultFactoryConfig.print_logger_level,
    output_target: OutputTarget = DefaultFactoryConfig.print_logger_output_target,
    file_path: str | None = None,
    append_to_file: bool = DefaultFactoryConfig.print_logger_append_to_file,
    enable_new_line: bool = DefaultFactoryConfig.enable_new_line,
    enable_caller_info: bool = False,
) -> PrintLogger:
    """快捷创建 PrintLogger 实例的工厂函数

    提供常用的日志配置预设，简化 PrintLogger 的创建过程。

    Args:
        level: 日志级别，默认使用 DefaultFactoryConfig.print_logger_level
        output_target: 输出目标，默认使用 DefaultFactoryConfig.print_logger_output_target
        file_path: 日志文件路径，可选
        append_to_file: 是否追加到文件，默认使用 DefaultFactoryConfig.print_logger_append_to_file
        enable_caller_info: 是否显示调用者信息（文件名:行号），默认为 False

    Returns:
        PrintLogger: 配置好的 PrintLogger 实例

    Examples:
        >>> # 创建默认的 INFO 级别控制台日志
        >>> logger = get_print_logger()

        >>> # 创建 DEBUG 级别，同时输出到控制台和文件
        >>> logger = get_print_logger(
        ...     level=Level.DEBUG,
        ...     output_target=OutputTarget.BOTH,
        ...     file_path="logs/debug.log"
        ... )

        >>> # 创建仅文件输出的 ERROR 级别日志
        >>> logger = get_print_logger(
        ...     level=Level.ERROR,
        ...     output_target=OutputTarget.FILE,
        ...     file_path="logs/error.log"
        ... )

        >>> # 启用调用者信息
        >>> logger = get_print_logger(enable_caller_info=True)
        >>> logger.info("信息")
        # 输出: [INFO][main:42] 信息
    """
    return PrintLogger(
        level=level,
        output_target=output_target,
        file_path=file_path,
        append_to_file=append_to_file,
        enable_new_line=enable_new_line,
        enable_caller_info=enable_caller_info,
    )


def get_console_logger(
    level: Level = DefaultFactoryConfig.console_logger_level,
    enable_new_line: bool = DefaultFactoryConfig.console_enable_new_line,
    use_global: bool = DefaultFactoryConfig.console_use_global,
    enable_caller_info: bool = DefaultFactoryConfig.console_enable_caller_info,
) -> PrintLogger:
    """创建仅输出到控制台的日志器

    Args:
        level: 日志级别，默认使用 DefaultFactoryConfig.console_logger_level
        enable_new_line: 是否启用换行，默认使用 DefaultFactoryConfig.console_enable_new_line
        use_global: 是否使用全局实例，默认使用 DefaultFactoryConfig.console_use_global
            - True: 返回全局单例实例（首次创建后会缓存）
            - False: 创建并返回新实例
        enable_caller_info: 是否显示调用者信息（文件名:行号），默认为 False

    Returns:
        PrintLogger: 配置为控制台输出的日志器

    Examples:
        >>> # 使用全局实例（默认）
        >>> logger1 = get_console_logger()
        >>> logger2 = get_console_logger()
        >>> assert logger1 is logger2  # True

        >>> # 修改全局实例的配置，所有引用该实例的地方都会生效
        >>> logger1.set_level(Level.DEBUG)
        >>> logger2.info("这条会用 DEBUG 级别")

        >>> # 创建新实例（不使用全局）
        >>> logger3 = get_console_logger(use_global=False)
        >>> logger4 = get_console_logger(use_global=False)
        >>> assert logger3 is not logger4  # True

        >>> # 启用调用者信息
        >>> logger = get_console_logger(enable_caller_info=True)
        >>> logger.debug("调试信息")
        # 输出: [DEBUG][main:42] 调试信息
    """
    if use_global:
        if DefaultFactoryConfig.console_logger_instance is None:
            DefaultFactoryConfig.console_logger_instance = PrintLogger(
                level=level,
                output_target=OutputTarget.CONSOLE,
                enable_new_line=enable_new_line,
                enable_caller_info=enable_caller_info,
            )
        else:
            instance = DefaultFactoryConfig.console_logger_instance
            if instance.get_level() != level:
                instance.set_level(level)
            if instance.get_enable_new_line() != enable_new_line:
                instance.set_enable_new_line(enable_new_line)
            if instance.get_enable_caller_info() != enable_caller_info:
                instance.set_enable_caller_info(enable_caller_info)
        return DefaultFactoryConfig.console_logger_instance
    return PrintLogger(
        level=level,
        output_target=OutputTarget.CONSOLE,
        enable_new_line=enable_new_line,
        enable_caller_info=enable_caller_info,
    )


def get_file_logger(
    level: Level = DefaultFactoryConfig.file_logger_level,
    file_path: str = DefaultFactoryConfig.file_logger_path,
    append_to_file: bool = DefaultFactoryConfig.file_logger_append,
    enable_caller_info: bool = False,
) -> PrintLogger:
    """创建仅输出到文件的日志器

    Args:
        level: 日志级别，默认使用 DefaultFactoryConfig.file_logger_level
        file_path: 日志文件路径，默认使用 DefaultFactoryConfig.file_logger_path
        append_to_file: 是否追加到文件，默认使用 DefaultFactoryConfig.file_logger_append
        enable_caller_info: 是否显示调用者信息（文件名:行号），默认为 False

    Returns:
        PrintLogger: 配置为文件输出的日志器

    Examples:
        >>> logger = get_file_logger(Level.DEBUG, "logs/debug.log")
        >>> logger.debug("调试信息将写入文件")

        >>> # 启用调用者信息
        >>> logger = get_file_logger(enable_caller_info=True)
        >>> logger.debug("调试信息")
        # 输出: [DEBUG][main:42] 调试信息
    """
    return get_print_logger(
        level=level,
        output_target=OutputTarget.FILE,
        file_path=file_path,
        append_to_file=append_to_file,
        enable_caller_info=enable_caller_info,
    )


def get_dual_logger(
    level: Level = DefaultFactoryConfig.dual_logger_level,
    file_path: str = DefaultFactoryConfig.dual_logger_path,
    append_to_file: bool = DefaultFactoryConfig.dual_logger_append,
    enable_caller_info: bool = False,
) -> PrintLogger:
    """创建同时输出到控制台和文件的日志器

    Args:
        level: 日志级别，默认使用 DefaultFactoryConfig.dual_logger_level
        file_path: 日志文件路径，默认使用 DefaultFactoryConfig.dual_logger_path
        append_to_file: 是否追加到文件，默认使用 DefaultFactoryConfig.dual_logger_append
        enable_caller_info: 是否显示调用者信息（文件名:行号），默认为 False

    Returns:
        PrintLogger: 配置为双重输出的日志器

    Examples:
        >>> logger = get_dual_logger(Level.DEBUG, "full.log")
        >>> logger.debug("同时显示在控制台和写入文件")

        >>> # 启用调用者信息
        >>> logger = get_dual_logger(enable_caller_info=True)
        >>> logger.debug("调试信息")
        # 输出: [DEBUG][main:42] 调试信息
    """
    return get_print_logger(
        level=level,
        output_target=OutputTarget.BOTH,
        file_path=file_path,
        append_to_file=append_to_file,
        enable_caller_info=enable_caller_info,
    )


def get_debug_logger(
    file_path: str | None = DefaultFactoryConfig.debug_logger_path,
    output_target: OutputTarget = DefaultFactoryConfig.debug_logger_output_target,
    enable_caller_info: bool = False,
) -> PrintLogger:
    """创建 DEBUG 级别的日志器

    Args:
        file_path: 日志文件路径，如果为 None 则不输出到文件，默认使用 DefaultFactoryConfig.debug_logger_path
        output_target: 输出目标，默认使用 DefaultFactoryConfig.debug_logger_output_target
        enable_caller_info: 是否显示调用者信息（文件名:行号），默认为 False

    Returns:
        PrintLogger: 配置为 DEBUG 级别的日志器

    Examples:
        >>> # 仅控制台的 DEBUG 日志
        >>> logger = get_debug_logger()
        >>>
        >>> # 控制台+文件的 DEBUG 日志
        >>> logger = get_debug_logger("logs/debug.log", OutputTarget.BOTH)
        >>>
        >>> # 启用调用者信息
        >>> logger = get_debug_logger(enable_caller_info=True)
        >>> logger.debug("调试信息")
        # 输出: [DEBUG][main:42] 调试信息
    """
    if file_path:
        return get_print_logger(
            level=Level.DEBUG,
            output_target=output_target,
            file_path=file_path,
            enable_caller_info=enable_caller_info,
        )
    else:
        return get_print_logger(
            level=Level.DEBUG,
            output_target=OutputTarget.CONSOLE,
            enable_caller_info=enable_caller_info,
        )


def get_production_logger(
    file_path: str = DefaultFactoryConfig.production_logger_path,
    min_level: Level = DefaultFactoryConfig.production_logger_min_level,
    enable_caller_info: bool = False,
) -> PrintLogger:
    """创建生产环境的日志器

    生产环境通常需要文件输出，日志级别不低于 INFO。

    Args:
        file_path: 生产日志文件路径，默认使用 DefaultFactoryConfig.production_logger_path
        min_level: 最小日志级别，默认使用 DefaultFactoryConfig.production_logger_min_level
        enable_caller_info: 是否显示调用者信息（文件名:行号），默认为 False

    Returns:
        PrintLogger: 配置用于生产环境的日志器

    Examples:
        >>> logger = get_production_logger("app.log", Level.WARN)
        >>> logger.error("生产环境错误")

        >>> # 启用调用者信息
        >>> logger = get_production_logger(enable_caller_info=True)
        >>> logger.error("错误信息")
        # 输出: [ERROR][main:42] 错误信息
    """
    return get_print_logger(
        level=min_level,
        output_target=OutputTarget.FILE,
        file_path=file_path,
        append_to_file=True,
        enable_caller_info=enable_caller_info,
    )
