"""
彩色打印和格式化实现模块
"""

from pynomad.common.decorator import singleton
from pynomad.common.ansi import AnsiStyle, Color
from pynomad.console.base import BasePrint
from pynomad.console.progress import ProgressBar


@singleton
class Printer(BasePrint):
    """简单的彩色打印类，用于输出到控制台

    提供类似Bootstrap的彩色打印功能，不支持文件输出和日志级别。
    每个方法对应一种预定义的颜色方案。支持进度条功能。

    此类使用@singleton装饰器实现单例模式，确保全局只有一个Printer实例。
    """

    def primary(self, *msg: object, sep: str = " ", end: str = "\n") -> None:
        """主要信息 - 蓝底白字"""
        self.printcolor(
            *msg,
            foreground=Color.WHITE,
            background=Color.BLUE,
            style=AnsiStyle.BOLD,
            sep=sep,
            end=end,
        )

    def secondary(self, *msg: object, sep: str = " ", end: str = "\n") -> None:
        """次要信息 - 灰底白字"""
        self.printcolor(
            *msg,
            foreground=Color.WHITE,
            background=Color.BLACK.bright_back,
            style=AnsiStyle.BOLD,
            sep=sep,
            end=end,
        )

    def success(self, *msg: object, sep: str = " ", end: str = "\n") -> None:
        """成功信息 - 绿底白字"""
        self.printcolor(
            *msg,
            foreground=Color.WHITE,
            background=Color.GREEN,
            style=AnsiStyle.BOLD,
            sep=sep,
            end=end,
        )

    def success_text(
        self, *msg: object, sep: str = " ", end: str = "\n"
    ) -> None:
        """成功信息 - 绿色"""
        self.printcolor(
            *msg,
            foreground=Color.GREEN,
            background=Color.DEFAULT,
            style=AnsiStyle.BOLD,
            sep=sep,
            end=end,
        )

    def info(self, *msg: object, sep: str = " ", end: str = "\n") -> None:
        """信息提示 - 亮蓝底白字"""
        self.printcolor(
            *msg,
            foreground=Color.WHITE,
            background=Color.BLUE.bright_back,
            style=AnsiStyle.BOLD,
            sep=sep,
            end=end,
        )

    def info_text(self, *msg: object, sep: str = " ", end: str = "\n") -> None:
        """信息提示 - 亮蓝色"""
        self.printcolor(
            *msg,
            foreground=Color.BLUE.bright_fore,
            background=Color.DEFAULT,
            style=AnsiStyle.BOLD,
            sep=sep,
            end=end,
        )

    def warning(self, *msg: object, sep: str = " ", end: str = "\n") -> None:
        """警告信息 - 黄底白字"""
        self.printcolor(
            *msg,
            foreground=Color.WHITE,
            background=Color.YELLOW,
            style=AnsiStyle.BOLD,
            sep=sep,
            end=end,
        )

    def warning_text(
        self, *msg: object, sep: str = " ", end: str = "\n"
    ) -> None:
        """警告信息 - 黄色"""
        self.printcolor(
            *msg,
            foreground=Color.YELLOW,
            background=Color.DEFAULT,
            style=AnsiStyle.BOLD,
            sep=sep,
            end=end,
        )

    def danger(self, *msg: object, sep: str = " ", end: str = "\n") -> None:
        """危险信息 - 红底白字"""
        self.printcolor(
            *msg,
            foreground=Color.WHITE,
            background=Color.RED,
            style=AnsiStyle.BOLD,
            sep=sep,
            end=end,
        )

    def danger_text(
        self, *msg: object, sep: str = " ", end: str = "\n"
    ) -> None:
        """危险信息 - 红色"""
        self.printcolor(
            *msg,
            foreground=Color.RED,
            background=Color.DEFAULT,
            style=AnsiStyle.BOLD,
            sep=sep,
            end=end,
        )

    def light(self, *msg: object, sep: str = " ", end: str = "\n") -> None:
        """轻度信息 - 白底黑字"""
        self.printcolor(
            *msg,
            foreground=Color.BLACK,
            background=Color.WHITE,
            style=AnsiStyle.BOLD,
            sep=sep,
            end=end,
        )

    def light_text(self, *msg: object, sep: str = " ", end: str = "\n") -> None:
        """轻度信息 - 浅灰色"""
        self.printcolor(
            *msg,
            foreground=Color.WHITE.bright_fore,
            background=Color.DEFAULT,
            style=AnsiStyle.DIM,
            sep=sep,
            end=end,
        )

    def secondary_text(
        self, *msg: object, sep: str = " ", end: str = "\n"
    ) -> None:
        """次要信息 - 灰色文本"""
        self.printcolor(
            *msg,
            foreground=Color.BLACK.bright_fore,
            background=Color.DEFAULT,
            style=AnsiStyle.DIM,
            sep=sep,
            end=end,
        )

    def dark_text(self, *msg: object, sep: str = " ", end: str = "\n") -> None:
        """深色文本 - 深灰色"""
        self.printcolor(
            *msg,
            foreground=Color.BLACK,
            background=Color.DEFAULT,
            style=AnsiStyle.BOLD,
            sep=sep,
            end=end,
        )

    def muted_text(self, *msg: object, sep: str = " ", end: str = "\n") -> None:
        """静音文本 - 暗灰色"""
        self.printcolor(
            *msg,
            foreground=Color.BLACK.bright_fore,
            background=Color.DEFAULT,
            style=AnsiStyle.DIM,
            sep=sep,
            end=end,
        )

    def primary_text(
        self, *msg: object, sep: str = " ", end: str = "\n"
    ) -> None:
        """主要信息 - 蓝色文本"""
        self.printcolor(
            *msg,
            foreground=Color.BLUE,
            background=Color.DEFAULT,
            style=AnsiStyle.BOLD,
            sep=sep,
            end=end,
        )

    def progress_bar(
        self,
        total: int,
        description: str = "",
        width: int = 50,
        fill_char: str = "█",
        empty_char: str = "░",
        show_percent: bool = True,
        show_eta: bool = True,
        color: Color = Color.BLUE,
        auto_refresh: bool = True,
        refresh_interval: float = 0.1,
    ) -> ProgressBar:
        """创建进度条实例

        Args:
            total: 总进度数
            description: 进度条描述文字
            width: 进度条宽度（字符数）
            fill_char: 已填充部分的字符
            empty_char: 未填充部分的字符
            show_percent: 是否显示百分比
            show_eta: 是否显示预计剩余时间
            color: 进度条颜色
            auto_refresh: 是否自动刷新
            refresh_interval: 自动刷新间隔（秒）

        Returns:
            ProgressBar: 进度条实例
        """
        progress = ProgressBar(
            total=total,
            description=description,
            width=width,
            fill_char=fill_char,
            empty_char=empty_char,
            show_percent=show_percent,
            show_eta=show_eta,
            color=color,
            auto_refresh=auto_refresh,
            refresh_interval=refresh_interval,
        )
        progress.set_printer(self)
        return progress


# 创建全局默认的Printer实例
printer = Printer()
