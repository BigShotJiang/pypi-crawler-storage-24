"""
彩色打印基础类
提供跨平台的彩色打印功能，自动检测系统兼容性并选择合适的实现方式。
"""

from abc import ABC
import os
import sys
from typing import TextIO

from pynomad.common.environment import environ
from pynomad.common.ansi import AnsiStyle, Color


class BasePrint(ABC):
    """
    彩色打印基础类

    提供跨平台的彩色打印功能，自动检测系统兼容性并选择合适的实现方式。
    如果有colorama包则使用其进行兼容性处理，否则根据操作系统选择原生ANSI支持。
    """

    def __init__(self) -> None:
        super().__init__()
        self.__colorama_initialized = False
        self.__init_colorama()

    def __init_colorama(self):
        try:
            import colorama  # pylint: disable=C0415

            colorama.just_fix_windows_console()
            self.__colorama_initialized = True
        except ImportError:
            pass

    @property
    def colorama_initialized(self) -> bool:
        """是否初始化了colorama"""
        return self.__colorama_initialized

    def should_use_colors(self, file: TextIO | None = None) -> bool:
        """判断是否应该使用颜色输出

        Args:
            file: 输出文件对象

        Returns:
            bool: 是否支持颜色输出
        """
        # 如果输出到文件（非控制台），不使用颜色
        if file is not None and not self._is_console(file):
            return False
        # 如果有colorama初始化，可以使用颜色
        if self.colorama_initialized:
            return True
        # Windows 10以上原生支持ANSI颜色
        if environ.is_windows10():
            return True
        # Windows 7/8/Server 2008/Server 2012不支持ANSI颜色
        if environ.is_windows():
            return False
        # 其他平台（Linux, macOS等）原生支持ANSI颜色
        return True

    def _is_console(self, file: TextIO) -> bool:
        """检查文件是否为控制台输出

        Args:
            file: 文件对象

        Returns:
            bool: 是否为控制台输出
        """
        # 检查文件描述符
        if hasattr(file, "fileno"):
            try:
                return os.isatty(file.fileno())
            except (OSError, AttributeError):
                pass

        # 检查是否为标准输出/错误流
        return file in (sys.stdout, sys.stderr)

    def _format_with_colors(
        self,
        text: str,
        foreground: int|Color = Color.DEFAULT,
        background: int|Color = Color.DEFAULT,
        style: int|AnsiStyle = AnsiStyle.RESET,
    ) -> str:
        """为文本添加ANSI颜色代码

        Args:
            text: 原始文本
            foreground: 前景色代码，支持Color枚举或ANSI代码
            background: 背景色代码，支持Color枚举或ANSI代码
            style: 样式代码，支持AnsiStyle枚举或ANSI代码

        Returns:
            str: 带ANSI代码的文本
        """
        codes: list[str] = []

        # 始终以重置样式开始，确保不受之前样式影响
        codes.append("0")

        # 处理样式参数类型转换
        if isinstance(style, AnsiStyle):
            style_code = style.value
        else:
            style_code = style

        # 添加样式代码
        if style != AnsiStyle.RESET:
            codes.append(str(style_code))

        # 处理前景色参数类型转换
        if isinstance(foreground, Color):
            fg_code = foreground.fore
        else:
            fg_code = foreground

        # 添加前景色代码
        if fg_code != Color.DEFAULT:
            codes.append(str(fg_code))

        # 处理背景色参数类型转换
        if isinstance(background, Color):
            bg_code = background.back
        else:
            bg_code = background

        # 添加背景色代码
        if bg_code != Color.DEFAULT:
            codes.append(str(bg_code))

        # 构建ANSI转义序列，始终以\033[0;开头重置样式
        start_seq = f"\033[{';'.join(codes)}m"
        end_seq = f"\033[{AnsiStyle.RESET}m"

        return f"{start_seq}{text}{end_seq}"

    def printcolor(  # pylint: disable=R0913
        self,
        *values: object,
        foreground: Color | int = Color.DEFAULT,
        background: Color | int = Color.DEFAULT,
        style: AnsiStyle | int = AnsiStyle.RESET,
        sep: str = " ",
        end: str = "\n",
        file: TextIO | None = None,
        flush: bool = False,
    ) -> None:
        """打印彩色文本

        Args:
            *values: 要打印的值，类似print函数
            foreground: 前景色，支持Color枚举或ANSI代码，默认为默认颜色
            background: 背景色，支持Color枚举或ANSI代码，默认为默认颜色
            style: 样式，支持AnsiStyle枚举或ANSI代码，默认为无样式
            sep: 分隔符，默认为空格
            end: 结束符，默认为换行
            file: 输出文件，None则使用print方法
            flush: 是否立即刷新缓冲区
        """
        # 处理参数类型转换，支持Color和AnsiStyle枚举
        if isinstance(foreground, Color):
            fg_color = foreground.fore
        else:
            fg_color = foreground

        if isinstance(background, Color):
            bg_color = background.back
        else:
            bg_color = background

        if isinstance(style, AnsiStyle):
            style_code = style.value
        else:
            style_code = style

        # 将值转换为字符串并合并
        text = sep.join(str(v) for v in values)

        # 判断是否使用颜色
        if self.should_use_colors(file):
            # 需要颜色输出，添加ANSI代码
            # 将end追加到文本中，这样重置样式代码会在text+end之后
            text_with_end = text + end
            formatted_text = self._format_with_colors(
                text_with_end, fg_color, bg_color, style_code
            )
        else:
            # 不支持颜色，直接输出原文本
            formatted_text = text

        # 根据file参数选择输出方式
        if file is None:
            # 使用print函数，因为end已经包含在formatted_text中，所以end=''
            if flush:
                print(formatted_text, end='', flush=True)
            else:
                print(formatted_text, end='')
        else:
            # 直接写入文件
            _ = file.write(formatted_text + end)
            if flush:
                file.flush()
