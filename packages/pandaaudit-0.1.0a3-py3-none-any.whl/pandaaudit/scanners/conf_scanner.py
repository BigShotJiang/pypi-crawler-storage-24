"""PA-CONF* — Configuration security scanner."""

import hashlib
import os
import re
import stat
from pathlib import Path
from typing import List, Optional

from pandaaudit.scanners.base import BaseScanner
from pandaaudit.models.finding import Finding
from pandaaudit.models.severity import Severity, Category


class ConfScanner(BaseScanner):
    category = Category.CONF
    mode = "local"

    def run(self, checks: Optional[List[str]] = None) -> List[Finding]:
        self.findings = []
        all_checks = {
            "PA-CONF01": self._conf01_file_permissions,
            "PA-CONF02": self._conf02_dangerous_flags,
            "PA-CONF03": self._conf03_shell_allowlist,
            "PA-CONF04": self._conf04_baseline_drift,
            "PA-CONF05": self._conf05_mcp_excessive,
        }
        if not self.discovery.config_files:
            for check_id in all_checks:
                if checks and check_id not in checks:
                    continue
                self.skip(check_id, check_id, Severity.HIGH,
                          "No OpenClaw config files found")
            return self.findings
        for check_id, fn in all_checks.items():
            if checks and check_id not in checks:
                continue
            fn()
        return self.findings

    # ------------------------------------------------------------------
    # PA-CONF01: Config file permissions too open
    # ------------------------------------------------------------------
    def _conf01_file_permissions(self):
        check_id = "PA-CONF01"
        title = "Config file permissions too open"
        bad_files = []

        for f in self.discovery.config_files:
            if not f.is_file():
                continue
            try:
                st = f.stat()
                mode = st.st_mode
                # Check if group or others have any read/write/execute
                if mode & (stat.S_IRGRP | stat.S_IWGRP | stat.S_IXGRP |
                           stat.S_IROTH | stat.S_IWOTH | stat.S_IXOTH):
                    perm = oct(mode & 0o777)
                    bad_files.append(f"{f.name} ({perm})")
            except OSError:
                continue

        if bad_files:
            self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                             detail=f"Loose permissions: {', '.join(bad_files)}",
                             remediation="chmod 600 on config files")
        elif self.discovery.config_files:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS")
        else:
            self.skip(check_id, title, Severity.CRITICAL, "No config files found")

    # ------------------------------------------------------------------
    # PA-CONF02: dangerously*/insecure* flags
    # ------------------------------------------------------------------
    def _conf02_dangerous_flags(self):
        check_id = "PA-CONF02"
        title = "Dangerous configuration flags enabled"

        pattern = r'["\']?(dangerously\w+|insecure\w+)["\']?\s*[:=]\s*["\']?(true|yes|1|enabled)["\']?'
        found_flags = []

        for f in self.discovery.config_files:
            try:
                text = f.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            matches = re.findall(pattern, text, re.IGNORECASE)
            for m in matches:
                found_flags.append(f"{m[0]}={m[1]} in {f.name}")

        if found_flags:
            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail="; ".join(found_flags),
                             remediation="Disable all dangerously*/insecure* flags")
        else:
            self.add_finding(check_id, title, Severity.HIGH, "PASS")

    # ------------------------------------------------------------------
    # PA-CONF03: Shell command allowlist missing
    # ------------------------------------------------------------------
    def _conf03_shell_allowlist(self):
        check_id = "PA-CONF03"
        title = "Shell command allowlist (safeBins) not configured"

        if self.discovery.config_grep(r'["\']?(safeBins|safeBinProfiles)["\']?\s*[:=]'):
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS",
                             detail="Shell command allowlist found in config")
        else:
            self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                             remediation="Configure safeBins under tools.exec to restrict shell execution")

    # ------------------------------------------------------------------
    # PA-CONF04: Config baseline drift
    # ------------------------------------------------------------------
    def _conf04_baseline_drift(self):
        check_id = "PA-CONF04"
        title = "Configuration baseline drift"

        if not self.discovery.install_dir:
            self.skip(check_id, title, Severity.HIGH, "Install directory not found")
            return

        baseline_file = self.discovery.install_dir / ".config-baseline.sha256"
        if not baseline_file.is_file():
            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail="No baseline file (.config-baseline.sha256) found",
                             remediation="Generate a config baseline: pandaaudit baseline init")
            return

        # Compare current hashes to baseline
        baseline_data = {}
        for line in baseline_file.read_text().splitlines():
            parts = line.split(maxsplit=1)
            if len(parts) == 2:
                baseline_data[parts[1]] = parts[0]

        drifted = []
        for path_str, expected_hash in baseline_data.items():
            p = Path(path_str)
            if not p.is_file():
                drifted.append(f"missing: {path_str}")
                continue
            actual = hashlib.sha256(p.read_bytes()).hexdigest()
            if actual != expected_hash:
                drifted.append(f"changed: {path_str}")

        if drifted:
            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail="; ".join(drifted[:5]),
                             remediation="Review config changes and update baseline")
        else:
            self.add_finding(check_id, title, Severity.HIGH, "PASS",
                             detail="Config matches baseline")

    # ------------------------------------------------------------------
    # PA-CONF05: Excessive MCP servers (>10)
    # ------------------------------------------------------------------
    def _conf05_mcp_excessive(self):
        check_id = "PA-CONF05"
        title = "Excessive MCP server configuration (>10)"

        mcp_count = 0
        for f in self.discovery.config_files:
            try:
                text = f.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue

            # Count MCP server entries in JSON
            if f.suffix == ".json":
                try:
                    import json
                    data = json.loads(text)
                    # Top-level mcpServers
                    servers = data.get("mcpServers", data.get("mcp_servers", {}))
                    if isinstance(servers, dict):
                        mcp_count += len(servers)
                    # Nested under agents.*.mcpServers
                    agents = data.get("agents", {})
                    if isinstance(agents, dict):
                        for agent_cfg in agents.values():
                            if isinstance(agent_cfg, dict):
                                nested = agent_cfg.get("mcpServers", {})
                                if isinstance(nested, dict):
                                    mcp_count += len(nested)
                except Exception:
                    pass

        if mcp_count > 10:
            self.add_finding(check_id, title, Severity.MEDIUM, "FAIL",
                             detail=f"{mcp_count} MCP servers configured",
                             remediation="Reduce attack surface by removing unused MCP servers")
        else:
            self.add_finding(check_id, title, Severity.MEDIUM, "PASS",
                             detail=f"{mcp_count} MCP servers configured")
