"""PA-EXEC* — Execution & sandbox scanner."""

import os
import re
import subprocess
from pathlib import Path
from typing import List, Optional

from pandaaudit.scanners.base import BaseScanner
from pandaaudit.models.finding import Finding
from pandaaudit.models.severity import Severity, Category


class ExecScanner(BaseScanner):
    category = Category.EXEC
    mode = "local"

    def run(self, checks: Optional[List[str]] = None) -> List[Finding]:
        self.findings = []
        all_checks = {
            "PA-EXEC01": self._exec01_command_injection,
            "PA-EXEC02": self._exec02_sandbox,
            "PA-EXEC03": self._exec03_unsafe_exec,
            "PA-EXEC04": self._exec04_sql_injection,
            "PA-EXEC05": self._exec05_tool_input,
            "PA-EXEC06": self._exec06_tool_output,
            "PA-EXEC07": self._exec07_prompt_injection,
            "PA-EXEC08": self._exec08_circuit_breaker,
            "PA-EXEC09": self._exec09_self_modify,
        }
        if not self.discovery.install_dir:
            for check_id in all_checks:
                if checks and check_id not in checks:
                    continue
                self.skip(check_id, check_id, Severity.HIGH,
                          "No OpenClaw installation found")
            return self.findings
        for check_id, fn in all_checks.items():
            if checks and check_id not in checks:
                continue
            fn()
        return self.findings

    def _get_source_files(self) -> List[Path]:
        """Get Python/JS/TS source files from workspace."""
        source_files = []
        if not self.discovery.install_dir:
            return source_files
        workspace = self.discovery.install_dir / "workspace"
        if not workspace.is_dir():
            workspace = self.discovery.install_dir
        for ext in ("*.py", "*.js", "*.ts"):
            source_files.extend(workspace.rglob(ext))
        # Limit to avoid scanning massive codebases
        return source_files[:500]

    # ------------------------------------------------------------------
    # PA-EXEC01: Command injection
    # ------------------------------------------------------------------
    def _exec01_command_injection(self):
        check_id = "PA-EXEC01"
        title = "Command injection via unsanitized input"
        patterns = [
            r"subprocess\.(call|run|Popen)\s*\(\s*f['\"]",
            r"subprocess\.(call|run|Popen)\s*\(.*\+\s*",
            r"os\.system\s*\(\s*f['\"]",
            r"os\.popen\s*\(\s*f['\"]",
            r"shell\s*=\s*True",
            r"exec\s*\(\s*(user|input|request|data)",
        ]
        hits = self._scan_source_patterns(patterns)
        if hits:
            self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                             detail=f"Potential injection in: {', '.join(hits[:3])}",
                             remediation="Use parameterized commands, avoid shell=True with user input")
        else:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS")

    # ------------------------------------------------------------------
    # PA-EXEC02: Sandbox not enabled
    # ------------------------------------------------------------------
    def _exec02_sandbox(self):
        check_id = "PA-EXEC02"
        title = "Sandbox/container isolation not detected"

        is_isolated = False

        # Check Docker
        if Path("/.dockerenv").exists():
            is_isolated = True

        # Check cgroup
        cgroup = Path("/proc/1/cgroup")
        if cgroup.is_file():
            try:
                text = cgroup.read_text()
                if "docker" in text.lower() or "kubepods" in text.lower():
                    is_isolated = True
            except OSError:
                pass

        # Check VM
        try:
            result = subprocess.run(
                ["systemd-detect-virt"],
                capture_output=True, text=True, timeout=3,
            )
            if result.returncode == 0 and result.stdout.strip() != "none":
                is_isolated = True
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

        if is_isolated:
            self.add_finding(check_id, title, Severity.WARNING, "PASS",
                             detail="Running in isolated environment")
        else:
            self.add_finding(check_id, title, Severity.WARNING, "FAIL",
                             remediation="Run OpenClaw in Docker/VM for isolation")

    # ------------------------------------------------------------------
    # PA-EXEC03: Unsafe code execution (eval/exec/os.system)
    # ------------------------------------------------------------------
    def _exec03_unsafe_exec(self):
        check_id = "PA-EXEC03"
        title = "Unsafe code execution (eval/exec/os.system)"
        patterns = [
            r"\beval\s*\(",
            r"\bexec\s*\(",
            r"\bos\.system\s*\(",
            r"\bcompile\s*\(.*exec",
        ]
        hits = self._scan_source_patterns(patterns)
        if hits:
            self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                             detail=f"Found in: {', '.join(hits[:3])}",
                             remediation="Replace eval/exec with safe alternatives")
        else:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS")

    # ------------------------------------------------------------------
    # PA-EXEC04: SQL injection
    # ------------------------------------------------------------------
    def _exec04_sql_injection(self):
        check_id = "PA-EXEC04"
        title = "SQL injection via string interpolation"
        patterns = [
            r'f["\'].*SELECT.*\{',
            r'f["\'].*INSERT.*\{',
            r'f["\'].*UPDATE.*\{',
            r'f["\'].*DELETE.*\{',
            r'["\'].*SELECT.*["\']\s*\+',
            r'\.execute\s*\(\s*f["\']',
        ]
        hits = self._scan_source_patterns(patterns)
        if hits:
            self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                             detail=f"Found in: {', '.join(hits[:3])}",
                             remediation="Use parameterized queries instead of string interpolation")
        else:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS")

    # ------------------------------------------------------------------
    # PA-EXEC05: Tool input not validated
    # ------------------------------------------------------------------
    def _exec05_tool_input(self):
        check_id = "PA-EXEC05"
        title = "Tool function input not validated"
        # Look for @tool decorated functions with string/Any params and no validation
        patterns = [
            r"@tool.*\n.*def\s+\w+\(.*:\s*(str|Any)",
        ]
        hits = self._scan_source_patterns(patterns)
        if hits:
            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail=f"Unvalidated tool inputs in: {', '.join(hits[:3])}",
                             remediation="Add input validation (length, format, allowlist)")
        else:
            self.add_finding(check_id, title, Severity.HIGH, "PASS")

    # ------------------------------------------------------------------
    # PA-EXEC06: Tool output injected into prompt
    # ------------------------------------------------------------------
    def _exec06_tool_output(self):
        check_id = "PA-EXEC06"
        title = "Tool output directly injected into prompt"
        patterns = [
            r"(system|user|assistant)\s*[:=].*tool.*output",
            r"prompt.*\+.*result",
            r"messages\.append.*tool.*response",
        ]
        hits = self._scan_source_patterns(patterns)
        if hits:
            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail=f"Found in: {', '.join(hits[:3])}",
                             remediation="Sanitize tool outputs before injecting into prompts")
        else:
            self.add_finding(check_id, title, Severity.HIGH, "PASS")

    # ------------------------------------------------------------------
    # PA-EXEC07: System prompt injection
    # ------------------------------------------------------------------
    def _exec07_prompt_injection(self):
        check_id = "PA-EXEC07"
        title = "System prompt injection: user input in SystemMessage"
        patterns = [
            r"SystemMessage\s*\(.*\+.*user",
            r"SystemMessage\s*\(.*f['\"].*\{",
            r"SystemMessage\s*\(.*\.format\s*\(",
            r"system_prompt.*=.*f['\"].*\{",
            r"system_prompt.*=.*\.format\s*\(",
            r"system_prompt.*=.*\+.*user",
            r"system_prompt.*%\s*\(",
        ]
        hits = self._scan_source_patterns(patterns)
        if hits:
            self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                             detail=f"Found in: {', '.join(hits[:3])}",
                             remediation="Never concatenate user input into system prompts")
        else:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS")

    # ------------------------------------------------------------------
    # PA-EXEC08: No circuit breaker / max iterations
    # ------------------------------------------------------------------
    def _exec08_circuit_breaker(self):
        check_id = "PA-EXEC08"
        title = "Missing circuit breaker / max iteration limit"
        loop_patterns = [
            r"while\s+(True|1)",
            r"for\s+\w+\s+in\s+range\s*\(\s*\d{4,}",
        ]
        guard_patterns = [
            r"(max_iter|max_steps|max_turns|circuit.?breaker|timeout|break\s+if)",
        ]
        loop_found = self._scan_source_patterns(loop_patterns)
        guard_found = self._scan_source_patterns(guard_patterns)

        if loop_found and not guard_found:
            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             remediation="Add max_iterations/circuit_breaker to prevent infinite loops")
        else:
            self.add_finding(check_id, title, Severity.HIGH, "PASS")

    # ------------------------------------------------------------------
    # PA-EXEC09: Plugin code self-modification
    # ------------------------------------------------------------------
    def _exec09_self_modify(self):
        check_id = "PA-EXEC09"
        title = "Plugin code self-modification risk"
        patterns = [
            r"open\s*\(.*\.py.*['\"]w['\"]",
            r"importlib.*reload",
            r"exec\s*\(.*compile",
        ]
        hits = self._scan_source_patterns(patterns)
        if hits:
            self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                             detail=f"Self-modification risk in: {', '.join(hits[:3])}",
                             remediation="Prevent plugins from modifying their own code")
        else:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS")

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _scan_source_patterns(self, patterns: List[str]) -> List[str]:
        """Scan source files for regex patterns, return list of filenames with hits."""
        hits = []
        for src in self._get_source_files():
            try:
                text = src.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            for pat in patterns:
                if re.search(pat, text, re.IGNORECASE | re.MULTILINE):
                    hits.append(src.name)
                    break
        return hits
