"""PA-SC* — Supply chain security scanner."""

import hashlib
import json
import re
from pathlib import Path
from typing import List, Optional

from pandaaudit.scanners.base import BaseScanner
from pandaaudit.models.finding import Finding
from pandaaudit.models.severity import Severity, Category


class ScScanner(BaseScanner):
    category = Category.SC
    mode = "local"

    def run(self, checks: Optional[List[str]] = None) -> List[Finding]:
        self.findings = []
        all_checks = {
            "PA-SC01": self._sc01_skill_source,
            "PA-SC02": self._sc02_mcp_version,
            "PA-SC03": self._sc03_file_integrity,
            "PA-SC04": self._sc04_tool_description_poison,
        }
        if not self.discovery.config_files and not self.discovery.install_dir:
            for check_id in all_checks:
                if checks and check_id not in checks:
                    continue
                self.skip(check_id, check_id, Severity.HIGH,
                          "No OpenClaw installation found")
            return self.findings
        for check_id, fn in all_checks.items():
            if checks and check_id not in checks:
                continue
            fn()
        return self.findings

    def _skills_dir(self) -> Optional[Path]:
        if self.discovery.install_dir:
            # OpenClaw stores skills in workspace/skills or directly in skills/
            for sub in ("workspace/skills", "skills"):
                d = self.discovery.install_dir / sub
                if d.is_dir():
                    return d
        return None

    # ------------------------------------------------------------------
    # PA-SC01: Skill source not verified
    # ------------------------------------------------------------------
    def _sc01_skill_source(self):
        check_id = "PA-SC01"
        title = "Third-party skill from unverified source"

        skills_dir = self._skills_dir()
        if not skills_dir:
            self.add_finding(check_id, title, Severity.HIGH, "PASS",
                             detail="No skills directory found")
            return

        unverified = []
        for skill in skills_dir.iterdir():
            if not skill.is_dir():
                continue
            git_dir = skill / ".git"
            if not git_dir.exists():
                unverified.append(skill.name)

        if unverified:
            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail=f"Skills without git source: {', '.join(unverified[:5])}",
                             remediation="Only install skills from verified Git repositories")
        else:
            self.add_finding(check_id, title, Severity.HIGH, "PASS")

    # ------------------------------------------------------------------
    # PA-SC02: MCP server version not pinned
    # ------------------------------------------------------------------
    def _sc02_mcp_version(self):
        check_id = "PA-SC02"
        title = "MCP server version not pinned"

        unpinned = []
        for f in self.discovery.config_files:
            if f.suffix != ".json":
                continue
            try:
                data = json.loads(f.read_text(encoding="utf-8", errors="ignore"))
            except Exception:
                continue

            # Collect all mcpServers (top-level and under agents.*)
            all_servers = {}
            if isinstance(data.get("mcpServers"), dict):
                all_servers.update(data["mcpServers"])
            agents = data.get("agents", {})
            if isinstance(agents, dict):
                for agent_cfg in agents.values():
                    if isinstance(agent_cfg, dict) and isinstance(agent_cfg.get("mcpServers"), dict):
                        all_servers.update(agent_cfg["mcpServers"])

            for name, cfg in all_servers.items():
                if not isinstance(cfg, dict):
                    continue
                cmd = cfg.get("command", "")
                args = cfg.get("args", [])
                if cmd not in ("npx", "npx.cmd"):
                    continue
                # Find the package arg (skip flags like -y, --yes)
                pkg = None
                for arg in args:
                    if isinstance(arg, str) and not arg.startswith("-"):
                        pkg = arg
                        break
                if not pkg:
                    continue
                if "@latest" in pkg:
                    unpinned.append(f"{name}: uses @latest")
                elif "@" not in pkg or pkg.endswith("@"):
                    unpinned.append(f"{name}: no version specified")

        if unpinned:
            self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                             detail="; ".join(unpinned[:3]),
                             remediation="Pin MCP server versions (e.g. npx package@1.2.3)")
        else:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS")

    # ------------------------------------------------------------------
    # PA-SC03: Skill/MCP file integrity
    # ------------------------------------------------------------------
    def _sc03_file_integrity(self):
        check_id = "PA-SC03"
        title = "Skill/MCP file integrity deviation"

        if not self.discovery.install_dir:
            self.skip(check_id, title, Severity.HIGH, "Install directory not found")
            return

        baseline_dir = self.discovery.install_dir / "security-baselines"
        baseline_file = baseline_dir / "skill-mcp-baseline.sha256"

        if not baseline_file.is_file():
            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail="No integrity baseline file found",
                             remediation="Generate baseline with: pandaaudit baseline init")
            return

        # Load baseline and compare
        baseline_data = {}
        for line in baseline_file.read_text().splitlines():
            parts = line.split(maxsplit=1)
            if len(parts) == 2:
                baseline_data[parts[1]] = parts[0]

        changed = []
        for path_str, expected in baseline_data.items():
            p = Path(path_str)
            if not p.is_file():
                changed.append(f"missing: {p.name}")
                continue
            actual = hashlib.sha256(p.read_bytes()).hexdigest()
            if actual != expected:
                changed.append(f"modified: {p.name}")

        if changed:
            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail="; ".join(changed[:5]),
                             remediation="Investigate file changes, update baseline if legitimate")
        else:
            self.add_finding(check_id, title, Severity.HIGH, "PASS")

    # ------------------------------------------------------------------
    # PA-SC04: Tool description poisoning
    # ------------------------------------------------------------------
    def _sc04_tool_description_poison(self):
        check_id = "PA-SC04"
        title = "Tool description contains hidden instructions"

        suspicious_patterns = [
            r"ignore\s+(previous|above|all)\s+(instructions|rules)",
            r"do\s+not\s+tell\s+the\s+user",
            r"send\s+(data|info|response)\s+to",
            r"exfiltrat",
            r"<system>",
            r"</?(hidden|secret|invisible)>",
        ]

        hits = []
        for f in self.discovery.config_files:
            try:
                text = f.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            for pat in suspicious_patterns:
                if re.search(pat, text, re.IGNORECASE):
                    hits.append(f.name)
                    break

        if hits:
            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail=f"Suspicious descriptions in: {', '.join(hits)}",
                             remediation="Review tool descriptions for prompt injection attempts")
        else:
            self.add_finding(check_id, title, Severity.HIGH, "PASS")

