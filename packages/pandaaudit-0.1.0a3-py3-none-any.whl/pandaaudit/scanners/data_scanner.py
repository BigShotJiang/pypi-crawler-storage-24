"""PA-DATA* — Data security scanner."""

import os
import re
from pathlib import Path
from typing import List, Optional

from pandaaudit.scanners.base import BaseScanner
from pandaaudit.models.finding import Finding
from pandaaudit.models.severity import Severity, Category


class DataScanner(BaseScanner):
    category = Category.DATA
    mode = "local"

    def run(self, checks: Optional[List[str]] = None) -> List[Finding]:
        self.findings = []
        all_checks = {
            "PA-DATA01": self._data01_api_keys,
            "PA-DATA02": self._data02_private_keys,
            "PA-DATA03": self._data03_mcp_hardcoded,
            "PA-DATA04": self._data04_log_leakage,
            "PA-DATA05": self._data05_env_vars,
            "PA-DATA06": self._data06_sensitive_dirs,
            "PA-DATA07": self._data07_exfil_chain,
            "PA-DATA08": self._data08_memory_poison,
        }
        if not self.discovery.config_files and not self.discovery.install_dir:
            for check_id in all_checks:
                if checks and check_id not in checks:
                    continue
                self.skip(check_id, check_id, Severity.HIGH,
                          "No OpenClaw installation found")
            return self.findings
        for check_id, fn in all_checks.items():
            if checks and check_id not in checks:
                continue
            fn()
        return self.findings

    # ------------------------------------------------------------------
    # PA-DATA01: API key plaintext exposure
    # ------------------------------------------------------------------
    def _data01_api_keys(self):
        check_id = "PA-DATA01"
        title = "API keys exposed in plaintext"
        patterns = [
            r"sk-ant-[a-zA-Z0-9_-]{20,}",
            r"sk-[a-zA-Z0-9]{20,}",
            r"ghp_[a-zA-Z0-9]{30,}",
            r"AKIA[A-Z0-9]{16}",
            r"xoxb-[0-9]+-[a-zA-Z0-9]+",
        ]
        hits = []

        for f in self.discovery.config_files:
            # Skip .env (that's where keys should be)
            if f.name == ".env":
                continue
            try:
                text = f.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            for pat in patterns:
                if re.search(pat, text):
                    hits.append(f.name)
                    break

        if hits:
            self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                             detail=f"API keys found in: {', '.join(hits)}",
                             remediation="Move API keys to .env or secret manager, use ${VAR} references")
        else:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS")

    # ------------------------------------------------------------------
    # PA-DATA02: Private key / mnemonic plaintext
    # ------------------------------------------------------------------
    def _data02_private_keys(self):
        check_id = "PA-DATA02"
        title = "Private key or mnemonic in plaintext"

        scan_root = None
        if self.discovery.install_dir:
            workspace = self.discovery.install_dir / "workspace"
            scan_root = workspace if workspace.is_dir() else self.discovery.install_dir

        if not scan_root or not scan_root.is_dir():
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS",
                             detail="No workspace directory to scan")
            return

        eth_pattern = re.compile(r"\b0x[a-fA-F0-9]{64}\b")
        pem_pattern = re.compile(r"-----BEGIN\s+(RSA\s+)?PRIVATE KEY-----")
        mnemonic_pattern = re.compile(r"\b([a-z]{3,12}\s+){11,23}[a-z]{3,12}\b")

        skip_exts = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".zip", ".gz", ".tar", ".bin"}
        hits = []

        for fpath in scan_root.rglob("*"):
            if not fpath.is_file() or fpath.suffix in skip_exts:
                continue
            if ".git" in fpath.parts:
                continue
            try:
                text = fpath.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            if eth_pattern.search(text) or pem_pattern.search(text) or mnemonic_pattern.search(text):
                hits.append(fpath.name)
            if len(hits) >= 5:
                break

        if hits:
            self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                             detail=f"Sensitive material in: {', '.join(hits)}",
                             remediation="Remove plaintext keys/mnemonics, use vault/encrypted storage")
        else:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS")

    # ------------------------------------------------------------------
    # PA-DATA03: MCP config with hardcoded secrets
    # ------------------------------------------------------------------
    def _data03_mcp_hardcoded(self):
        check_id = "PA-DATA03"
        title = "MCP config contains hardcoded sensitive values"

        hits = []
        for f in self.discovery.config_files:
            try:
                text = f.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            # Look for env/secret/token/key with literal values (not ${VAR} references)
            if re.search(r"(mcpServers|mcp_servers)", text, re.IGNORECASE):
                # Find key/token/secret with literal string values
                for match in re.finditer(
                    r'["\']?(api[_-]?key|token|secret|password)["\']?\s*[:=]\s*["\']([^"\'$\{][^"\']{5,})["\']',
                    text, re.IGNORECASE
                ):
                    hits.append(f"{f.name}: {match.group(1)}")
                    break

        if hits:
            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail="; ".join(hits[:3]),
                             remediation="Use environment variable references (${SECRET}) instead of hardcoded values")
        else:
            self.add_finding(check_id, title, Severity.HIGH, "PASS")

    # ------------------------------------------------------------------
    # PA-DATA04: Sensitive data in logs
    # ------------------------------------------------------------------
    def _data04_log_leakage(self):
        check_id = "PA-DATA04"
        title = "Sensitive data logged in output"
        patterns = [
            r"(log|print|console)\w*\(.*\b(password|token|secret|api.?key)\b",
            r"logger\.\w+\(.*\b(password|token|secret|api.?key)\b",
        ]

        if not self.discovery.install_dir:
            self.add_finding(check_id, title, Severity.HIGH, "PASS")
            return

        workspace = self.discovery.install_dir / "workspace"
        if not workspace.is_dir():
            workspace = self.discovery.install_dir

        hits = []
        for ext in ("*.py", "*.js", "*.ts"):
            for src in list(workspace.rglob(ext))[:500]:
                try:
                    text = src.read_text(encoding="utf-8", errors="ignore")
                except OSError:
                    continue
                for pat in patterns:
                    if re.search(pat, text, re.IGNORECASE):
                        hits.append(src.name)
                        break
                if len(hits) >= 5:
                    break

        if hits:
            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail=f"Logging sensitive data in: {', '.join(hits)}",
                             remediation="Redact sensitive values before logging")
        else:
            self.add_finding(check_id, title, Severity.HIGH, "PASS")

    # ------------------------------------------------------------------
    # PA-DATA05: Environment variable leakage
    # ------------------------------------------------------------------
    def _data05_env_vars(self):
        check_id = "PA-DATA05"
        title = "Sensitive environment variables exposed"

        import subprocess
        try:
            result = subprocess.run(
                ["pgrep", "-f", "openclaw"],
                capture_output=True, text=True, timeout=5,
            )
            if result.returncode != 0 or not result.stdout.strip():
                self.skip(check_id, title, Severity.WARNING, "OpenClaw process not found")
                return

            pid = result.stdout.strip().split("\n")[0]
            environ_file = Path(f"/proc/{pid}/environ")
            if not environ_file.exists():
                self.skip(check_id, title, Severity.WARNING, "Cannot read process environment")
                return

            env_data = environ_file.read_text(encoding="utf-8", errors="ignore")
            sensitive = []
            for entry in env_data.split("\x00"):
                if entry:
                    var_name = entry.split("=")[0].upper()
                    for kw in ("SECRET", "TOKEN", "PASSWORD", "KEY", "PRIVATE"):
                        if kw in var_name:
                            sensitive.append(var_name)
                            break

            if sensitive:
                self.add_finding(check_id, title, Severity.WARNING, "FAIL",
                                 detail=f"Sensitive env vars: {', '.join(sensitive[:5])}",
                                 remediation="Use secret manager instead of environment variables for sensitive data")
            else:
                self.add_finding(check_id, title, Severity.WARNING, "PASS")

        except (FileNotFoundError, subprocess.TimeoutExpired):
            self.skip(check_id, title, Severity.WARNING, "pgrep not available")

    # ------------------------------------------------------------------
    # PA-DATA06: Sensitive directories accessible
    # ------------------------------------------------------------------
    def _data06_sensitive_dirs(self):
        check_id = "PA-DATA06"
        title = "Sensitive directories accessible without exclusion"

        home = Path.home()
        dirs_to_check = [home / ".ssh", home / ".gnupg", home / ".aws"]
        accessible = [str(d) for d in dirs_to_check if d.is_dir() and os.access(d, os.R_OK)]

        # Check if config excludes these
        excluded = self.discovery.config_grep(r"(exclude|deny|block).*(\.ssh|\.gnupg|\.aws)")

        if accessible and not excluded:
            self.add_finding(check_id, title, Severity.WARNING, "FAIL",
                             detail=f"Accessible: {', '.join(accessible)}",
                             remediation="Add exclusion rules for sensitive directories in OpenClaw config")
        else:
            self.add_finding(check_id, title, Severity.WARNING, "PASS")

    # ------------------------------------------------------------------
    # PA-DATA07: Data exfiltration chain
    # ------------------------------------------------------------------
    def _data07_exfil_chain(self):
        check_id = "PA-DATA07"
        title = "Potential data exfiltration chain"
        patterns_read = [r"(file_read|read_file|open\(|Path.*read)"]
        patterns_net = [r"(requests\.(get|post)|urllib|httpx|fetch|http\.client)"]

        read_files = set(self._scan_source_patterns(patterns_read))
        net_files = set(self._scan_source_patterns(patterns_net))
        overlap = read_files & net_files

        if overlap:
            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail=f"File+network in same module: {', '.join(list(overlap)[:3])}",
                             remediation="Separate file access and network access into different modules")
        else:
            self.add_finding(check_id, title, Severity.HIGH, "PASS")

    # ------------------------------------------------------------------
    # PA-DATA08: Memory poisoning
    # ------------------------------------------------------------------
    def _data08_memory_poison(self):
        check_id = "PA-DATA08"
        title = "Unsanitized input to persistent memory"
        patterns = [
            r"(memory|vector_store|knowledge_base)\.(add|insert|store|upsert)\s*\(.*user",
            r"(memory|vector_store|knowledge_base)\.(add|insert|store|upsert)\s*\(.*input",
            r"(memory|vector_store|knowledge_base)\.(add|insert|store|upsert)\s*\(.*message",
            r"(chromadb|pinecone|qdrant|weaviate).*\.(add|upsert)\s*\(.*(user|input|message|query)",
        ]
        hits = self._scan_source_patterns(patterns)
        if hits:
            self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                             detail=f"Found in: {', '.join(hits[:3])}",
                             remediation="Sanitize user input before writing to persistent memory")
        else:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS")

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _scan_source_patterns(self, patterns: list) -> list:
        """Scan workspace source files for regex patterns."""
        if not self.discovery.install_dir:
            return []
        workspace = self.discovery.install_dir / "workspace"
        if not workspace.is_dir():
            workspace = self.discovery.install_dir
        hits = []
        for ext in ("*.py", "*.js", "*.ts"):
            for src in list(workspace.rglob(ext))[:500]:
                try:
                    text = src.read_text(encoding="utf-8", errors="ignore")
                except OSError:
                    continue
                for pat in patterns:
                    if re.search(pat, text, re.IGNORECASE | re.MULTILINE):
                        hits.append(src.name)
                        break
        return hits
