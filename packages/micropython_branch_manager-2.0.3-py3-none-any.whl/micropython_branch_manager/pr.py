"""PR addition workflow for micropython-branch-manager."""

import re
from pathlib import Path

from .config import BranchConfig, MBMConfig, SubmoduleConfig
from .exceptions import ConfigError, GitError
from .git import GitRepo
from .github import GitHubClient, PRInfo
from .trailers import format_merge_message
from .update_branch import (
    create_update_branch,
    find_gitlab_remote,
    format_mr_description,
    get_gitlab_mr_url,
    git_url_to_https,
)

PR_URL_PATTERN = re.compile(r"https?://github\.com/micropython/micropython/pull/(\d+)")


class PRManager:
    """Manages adding PRs to integration branch."""

    def __init__(
        self,
        submodule_path: Path,
        submodule_config: SubmoduleConfig,
        config_path: Path | None = None,
        mbm_config: MBMConfig | None = None,
    ):
        self.submodule_path = submodule_path
        self.sub = submodule_config
        self.config_path = config_path
        self.mbm_config = mbm_config
        self.git = GitRepo(submodule_path)
        self.github = GitHubClient()

    def parse_identifier(self, value: str) -> str | int:
        """Parse PR identifier to number or branch name."""
        match = PR_URL_PATTERN.match(value)
        if match:
            return int(match.group(1))
        if value.isdigit():
            return int(value)
        return value

    def add_pr(self, identifier: str) -> None:
        """Add PR to integration branch."""
        if not self.config_path or not self.mbm_config:
            raise ConfigError("No config file. Run 'mbm init' first or use --config.")

        integration = self.sub.integration_branch

        # Parse identifier and get PR info
        print(f"Fetching PR info for: {identifier}")
        parsed = self.parse_identifier(identifier)
        pr_info = self.github.get_pr(parsed)
        print(f"Found PR #{pr_info.number}: {pr_info.title}")
        print(f"Branch: {pr_info.branch}")
        print(f"State: {pr_info.state}")

        # Check not already in config
        if self.sub.has_branch(pr_info.branch):
            raise ConfigError(f"Branch {pr_info.branch} already in config")

        self.git.require_clean()

        # Create update branch
        print(f"\nCreating update branch from {integration}...")
        update_branch = create_update_branch(self.git, integration)

        # Fetch PR from upstream
        print(f"Fetching PR #{pr_info.number} from upstream...")
        self._fetch_pr(pr_info)

        # Update config
        print("\nUpdating config...")
        self.sub.branches.append(
            BranchConfig(
                name=pr_info.branch,
                pr_url=pr_info.url,
                pr_number=pr_info.number,
                title=pr_info.title,
            )
        )
        self.mbm_config.save(self.config_path)

        # Merge into update branch with trailers
        merge_msg = format_merge_message(
            branch_name=pr_info.branch,
            title=pr_info.title,
            pr_number=pr_info.number,
            pr_url=pr_info.url,
            author=pr_info.author,
        )
        print(f"Merging {pr_info.branch} into {update_branch}...")
        self.git.merge(pr_info.branch, merge_msg)
        print("Merge completed successfully")

        # Push update branch to GitLab
        gitlab_remote = find_gitlab_remote(self.git)
        if gitlab_remote:
            print(f"\nPushing {update_branch} to {gitlab_remote}...")
            try:
                self.git.push(gitlab_remote, update_branch, force=True)
            except GitError as e:
                print(f"WARNING: Failed to push {update_branch} to {gitlab_remote}: {e}")

        # Print summary
        self._print_summary(update_branch, pr_info)

    def _fetch_pr(self, pr_info: PRInfo) -> None:
        """Fetch PR branch from upstream, always getting fresh content."""
        self.git.run("fetch", "upstream", f"+pull/{pr_info.number}/head:{pr_info.branch}")

    def _print_summary(self, update_branch: str, pr_info: PRInfo) -> None:
        """Print summary with MR URL."""
        print("\n=== PR ADDED SUCCESSFULLY ===")
        print(f"PR #{pr_info.number}: {pr_info.title}")
        print(f"Branch: {pr_info.branch}")

        gitlab_remote = find_gitlab_remote(self.git)
        if gitlab_remote:
            remotes = self.git.list_remotes()
            url = remotes[gitlab_remote]
            base = git_url_to_https(url)
            mr_title = f"{self.sub.integration_branch}: Add micropython PR #{pr_info.number}"
            mr_description = format_mr_description(self.sub, remotes)
            mr_url = get_gitlab_mr_url(
                base,
                update_branch,
                self.sub.integration_branch,
                title=mr_title,
                description=mr_description,
            )
            print(f"\nCreate MR: {mr_url}")
