"""Configuration models for micropython-branch-manager."""

import tomllib
from pathlib import Path

import tomli_w
from pydantic import BaseModel, ConfigDict, Field

from .exceptions import ConfigError

CONFIG_FILENAME = "mbm.toml"

TOML_HEADER = """\
# micropython-branch-manager (mbm)
# Install: pip install micropython-branch-manager
#          or: uv tool install micropython-branch-manager
# Usage:   mbm --help

"""


class BranchConfig(BaseModel):
    """Configuration for a single feature branch."""

    name: str
    pr_url: str | None = None
    pr_number: int | None = None
    title: str | None = None


class SubmoduleConfig(BaseModel):
    """Configuration for a single managed submodule."""

    model_config = ConfigDict(extra="ignore")

    path: str = "."
    integration_branch: str = "main"
    branches: list[BranchConfig] = Field(default_factory=list)

    def get_branch(self, name: str) -> BranchConfig | None:
        """Get branch config by name."""
        return next((b for b in self.branches if b.name == name), None)

    def has_branch(self, name: str) -> bool:
        """Check if branch exists in config."""
        return any(b.name == name for b in self.branches)

    def resolve_path(self, config_path: Path) -> Path:
        """Resolve the submodule path relative to the config file location."""
        return (config_path.parent / self.path).resolve()


class MBMConfig(BaseModel):
    """Root configuration for mbm.toml, supporting multiple submodules."""

    model_config = ConfigDict(extra="ignore")

    submodules: list[SubmoduleConfig] = Field(default_factory=list)

    @classmethod
    def load(cls, config_path: Path, require_exists: bool = False) -> "MBMConfig":
        """Load from mbm.toml.

        Handles both multi-submodule format (submodules array) and legacy
        single-submodule format (top-level path/integration_branch/branches).
        """
        try:
            data = tomllib.loads(config_path.read_text())
        except FileNotFoundError:
            if require_exists:
                raise ConfigError(
                    f"No config file found at {config_path}. "
                    f"Run 'mbm init' first to create {CONFIG_FILENAME}"
                ) from None
            return cls()

        # Legacy single-submodule format: top-level has path or submodule_path
        if "submodules" not in data and (
            "path" in data
            or "submodule_path" in data
            or "integration_branch" in data
            or "branches" in data
        ):
            # Normalize submodule_path -> path
            if "submodule_path" in data and "path" not in data:
                data["path"] = data.pop("submodule_path")
            sub = SubmoduleConfig.model_validate(data)
            return cls(submodules=[sub])

        return cls.model_validate(data)

    def save(self, config_path: Path) -> None:
        """Save to mbm.toml."""
        data = self.model_dump(exclude_none=True)
        toml_str = tomli_w.dumps(data)
        config_path.write_text(TOML_HEADER + toml_str)

    def get_submodule(
        self,
        selector: str | None = None,
        config_path: Path | None = None,
    ) -> SubmoduleConfig:
        """Get a submodule config by selector or auto-detect from CWD.

        Resolution order when selector is None:
        1. If only one submodule, return it.
        2. If CWD is within a configured submodule path, return that one.
        3. Raise ConfigError listing available submodules.

        Selector matching: exact path, then partial/suffix match.
        """
        if not self.submodules:
            raise ConfigError("No submodules configured. Run 'mbm init' first.")

        if selector is None:
            if len(self.submodules) == 1:
                return self.submodules[0]

            # Try CWD-based detection
            if config_path:
                cwd = Path.cwd().resolve()
                for sub in self.submodules:
                    sub_resolved = sub.resolve_path(config_path)
                    if cwd == sub_resolved or _is_within(cwd, sub_resolved):
                        return sub

            paths = [s.path for s in self.submodules]
            raise ConfigError(
                f"Multiple submodules configured ({', '.join(paths)}). "
                "Use -s/--submodule to select one."
            )

        # Exact match
        for sub in self.submodules:
            if sub.path == selector:
                return sub

        # Partial/suffix match
        for sub in self.submodules:
            if sub.path.endswith(selector) or selector.endswith(sub.path):
                return sub

        paths = [s.path for s in self.submodules]
        raise ConfigError(f"No submodule matching '{selector}'. Available: {', '.join(paths)}")


def _is_within(child: Path, parent: Path) -> bool:
    """Check if child path is within parent path."""
    try:
        child.relative_to(parent)
        return True
    except ValueError:
        return False


def find_config(start: Path | None = None) -> Path | None:
    """Walk up from start looking for mbm.toml.

    Returns the path to the config file, or None if not found.
    """
    current = (start or Path.cwd()).resolve()
    while True:
        candidate = current / CONFIG_FILENAME
        if candidate.exists():
            return candidate
        parent = current.parent
        if parent == current:
            return None
        current = parent
