"""Git trailer support for merge commit metadata."""

from __future__ import annotations

import contextlib
import re
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .config import BranchConfig
    from .git import GitRepo

TRAILER_PR = "MBM-PR"
TRAILER_URL = "MBM-URL"
TRAILER_AUTHOR = "MBM-Author"

MERGE_PATTERN = re.compile(r"Merge branch '([^']+)'")


def format_merge_message(
    branch_name: str,
    title: str | None = None,
    pr_number: int | None = None,
    pr_url: str | None = None,
    author: str | None = None,
) -> str:
    """Build merge commit message with MBM trailers."""
    lines = [f"Merge branch '{branch_name}'"]

    if title:
        lines.append("")
        lines.append(title)

    # Add trailers
    trailers = []
    if pr_number is not None:
        trailers.append(f"{TRAILER_PR}: {pr_number}")
    if pr_url:
        trailers.append(f"{TRAILER_URL}: {pr_url}")
    if author:
        trailers.append(f"{TRAILER_AUTHOR}: {author}")

    if trailers:
        lines.append("")
        lines.extend(trailers)

    return "\n".join(lines)


def parse_trailers_from_message(message: str) -> dict[str, str]:
    """Extract MBM trailers from a commit message string."""
    trailers: dict[str, str] = {}
    for line in message.split("\n"):
        line = line.strip()
        for key in (TRAILER_PR, TRAILER_URL, TRAILER_AUTHOR):
            if line.startswith(f"{key}: "):
                trailers[key] = line[len(key) + 2 :]
                break
    return trailers


def extract_branches_with_metadata(
    git: GitRepo, target: str, integration: str
) -> list[BranchConfig]:
    """Walk merge commits between target and integration, return BranchConfigs from trailers.

    Returns branches in merge order (oldest first).
    """
    from .config import BranchConfig

    branches: list[BranchConfig] = []
    seen: set[str] = set()

    raw = git.run("log", "--merges", "--format=%H%x1e%B%x1e", f"{target}..{integration}")
    if not raw:
        return []

    commits = [c.strip() for c in raw.split("\x1e\n") if c.strip()]
    for entry in commits:
        parts = entry.split("\x1e", 1)
        if len(parts) < 2:
            continue
        body = parts[1].strip()

        # Extract branch name from subject line
        first_line = body.split("\n", 1)[0]
        match = MERGE_PATTERN.search(first_line)
        if not match:
            continue

        branch_name = match.group(1)
        if branch_name in seen:
            continue
        seen.add(branch_name)

        # Extract title (second paragraph, before trailers)
        title = None
        body_lines = body.split("\n")
        if len(body_lines) > 2 and body_lines[1] == "":
            # Find the title — first non-empty line after the blank line
            for line in body_lines[2:]:
                stripped = line.strip()
                if not stripped:
                    break
                # Skip trailer lines
                if any(
                    stripped.startswith(f"{k}: ") for k in (TRAILER_PR, TRAILER_URL, TRAILER_AUTHOR)
                ):
                    break
                title = stripped
                break

        # Parse trailers
        trailers = parse_trailers_from_message(body)

        pr_number = None
        if TRAILER_PR in trailers:
            with contextlib.suppress(ValueError):
                pr_number = int(trailers[TRAILER_PR])

        branches.append(
            BranchConfig(
                name=branch_name,
                pr_url=trailers.get(TRAILER_URL),
                pr_number=pr_number,
                title=title,
            )
        )

    branches.reverse()  # Oldest first
    return branches
