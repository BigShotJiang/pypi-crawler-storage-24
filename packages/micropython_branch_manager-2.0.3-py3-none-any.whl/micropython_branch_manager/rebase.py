"""Rebase workflow orchestration for micropython-branch-manager."""

import contextlib
import sys
from pathlib import Path

from .config import MBMConfig, SubmoduleConfig
from .exceptions import GitError, RebaseConflictError, RemoteDivergenceError
from .git import GitRepo
from .trailers import format_merge_message
from .update_branch import (
    find_gitlab_remote,
    format_mr_description,
    get_gitlab_mr_url,
    get_update_branch_name,
    git_url_to_https,
)


class RebaseManager:
    """Orchestrates the rebase workflow."""

    def __init__(
        self,
        submodule_path: Path,
        submodule_config: SubmoduleConfig,
        config_path: Path | None = None,
        mbm_config: MBMConfig | None = None,
    ):
        self.submodule_path = submodule_path
        self.sub = submodule_config
        self.config_path = config_path
        self.mbm_config = mbm_config
        self.git = GitRepo(submodule_path)
        self._cached_state: dict[str, object] = {}

    def execute(
        self,
        target: str = "upstream/master",
        local_only: bool = False,
        dry_run: bool = False,
        force_push: bool = False,
        resume: bool = False,
    ) -> None:
        """Execute sequential PR integration workflow."""
        if resume:
            return self._resume_rebase(target, local_only, dry_run, force_push)

        self._preflight(local_only)

        # Train rerere from existing branch stack before rebuilding
        if not dry_run and self.git.is_rerere_enabled():
            self._train_rerere(target)

        # Sequential integration
        update_branch = get_update_branch_name(self.sub.integration_branch)
        if dry_run:
            print(f"DRY RUN: Would create update branch: {update_branch}")
        else:
            print(f"Creating update branch from {target}...")
            self.git.checkout(update_branch, create=True, force=True)
            self.git.run("reset", "--hard", target)

        for idx, branch_config in enumerate(self.sub.branches):
            if not dry_run:
                self._save_progress(idx, update_branch, target)
            self._integrate_pr(branch_config, target, update_branch, dry_run)

        # Push
        push_results: dict[str, bool] = {}
        divergence_errors: list[RemoteDivergenceError] = []
        if not local_only and not dry_run:
            push_results, divergence_errors = self._push_branches(update_branch, force_push)

        # Summary
        self._print_summary(update_branch, target, dry_run, push_results, divergence_errors)
        if not dry_run:
            self._cleanup_progress()

    def _preflight(self, local_only: bool) -> None:
        """Fetch and verify clean working tree."""
        if not local_only:
            print("Fetching from remotes...")
            self.git.fetch()
        self.git.require_clean()

    def _integrate_pr(
        self,
        branch: SubmoduleConfig | object,
        target: str,
        update_branch: str,
        dry_run: bool = False,
    ) -> None:
        """Fetch fresh PR, rebase onto target, merge into update branch."""
        from .config import BranchConfig

        if not isinstance(branch, BranchConfig):
            return
        print(f"\n{'=' * 60}")
        print(f"Integrating: {branch.name}")
        if branch.title:
            print(f"  {branch.title}")
        print(f"{'=' * 60}")

        if dry_run:
            print(f"  DRY RUN: Would integrate {branch.name}")
            return

        # Step A: Fetch fresh content
        source_branch = self._fetch_pr_branch(branch)

        # Step B: Rebase PR onto target
        rebase_branch = f"rebase-{branch.name}"
        self.git.checkout(rebase_branch, create=True, force=True)
        self.git.run("reset", "--hard", source_branch)

        try:
            self.git.rebase(target, update_refs=False, auto_continue=True)
        except RebaseConflictError as e:
            e.pr_context = {
                "pr_number": branch.pr_number,
                "branch_name": branch.name,
                "branch_title": branch.title,
            }
            print(f"\nConflict while rebasing {branch.name}.")
            print("Resolve conflicts manually, then run:")
            print(f"  cd {self.submodule_path}")
            print("  git rebase --continue")
            print("  mbm rebase --resume")
            raise

        self._complete_integration(branch, update_branch)
        print(f"  Integrated {branch.name}")

    def _complete_integration(self, branch: object, update_branch: str) -> None:
        """Complete PR integration after rebase: merge, update refs, cleanup."""
        from .config import BranchConfig

        if not isinstance(branch, BranchConfig):
            return
        rebase_branch = f"rebase-{branch.name}"

        # Merge into integration with trailers
        self.git.checkout(update_branch)
        merge_msg = format_merge_message(
            branch_name=branch.name,
            title=branch.title,
            pr_number=branch.pr_number,
            pr_url=branch.pr_url,
        )
        self.git.merge(rebase_branch, merge_msg, no_ff=True)

        # Update feature branch ref
        self.git.run("branch", "-f", branch.name, rebase_branch)

        # Try to set upstream tracking (non-fatal if remote branch doesn't exist)
        remote = self.git.resolve_remote_for_pr(branch.pr_url)
        if remote:
            upstream_ref = f"{remote}/{branch.name}"
            with contextlib.suppress(GitError):
                self.git.set_branch_upstream(branch.name, upstream_ref)

        # Cleanup
        self.git.run("branch", "-D", rebase_branch, check=False)
        if branch.pr_number:
            temp_branch = f"pr-{branch.pr_number}-temp"
            self.git.run("branch", "-D", temp_branch, check=False)

    def _fetch_pr_branch(self, branch: object) -> str:
        """Fetch PR or local branch, return source branch name."""
        from .config import BranchConfig

        if not isinstance(branch, BranchConfig):
            raise GitError("Invalid branch config")
        if branch.pr_number:
            temp_branch = f"pr-{branch.pr_number}-temp"
            print(f"  Fetching PR #{branch.pr_number} from upstream...")
            self.git.run("fetch", "upstream", f"+pull/{branch.pr_number}/head:{temp_branch}")
            return temp_branch
        else:
            remote = self.git.resolve_remote_for_pr(branch.pr_url)
            if remote:
                print(f"  Fetching {branch.name} from {remote}...")
                self.git.run("fetch", remote, branch.name)
                remote_ref = f"{remote}/{branch.name}"
                if not self.git.branch_exists(branch.name):
                    self.git.create_branch(branch.name, remote_ref)
            return branch.name

    def _train_rerere(self, target: str) -> None:
        """Train rerere from existing integration branch before rebuilding."""
        from .rerere import RerereTrainer

        trainer = RerereTrainer(self.git)
        trainer.train(target, self.sub.branches, self.sub.integration_branch)

    def _save_progress(
        self,
        index: int,
        update_branch: str,
        target: str,
    ) -> None:
        """Save rebase progress state."""
        import json

        # Cache persistent fields on first save
        if index == 0:
            self._cached_state["config_path"] = str(self.config_path) if self.config_path else None
            self._cached_state["submodule_path"] = self.sub.path

        state: dict[str, object] = {
            "index": index,
            "update_branch": update_branch,
            "target": target,
            **self._cached_state,
        }

        state_file = self.git.git_dir() / "mbm-rebase-state.json"
        state_file.write_text(json.dumps(state))

    def _cleanup_progress(self) -> None:
        """Remove progress state file."""
        state_file = self.git.git_dir() / "mbm-rebase-state.json"
        state_file.unlink(missing_ok=True)

    def _push_branches(
        self, update_branch: str, force_push: bool
    ) -> tuple[dict[str, bool], list[RemoteDivergenceError]]:
        """Push all branches to their remotes with safety checks."""
        print("\nPushing branches...")
        push_results: dict[str, bool] = {}
        divergence_errors: list[RemoteDivergenceError] = []
        remotes = self.git.list_remotes()

        for branch in self.sub.branches:
            remote = self.git.resolve_remote_for_pr(branch.pr_url, remotes)
            if not remote:
                print(f"WARNING: No remote found for {branch.name}, skipping push")
                push_results[branch.name] = False
                continue

            remote_ref = f"{remote}/{branch.name}"
            try:
                self.git.check_divergence(branch.name, remote_ref, force_push)
                print(f"Pushing {branch.name} to {remote}...")
                self.git.push(remote, branch.name, force=True)
                push_results[branch.name] = True
            except RemoteDivergenceError as e:
                divergence_errors.append(e)
                push_results[branch.name] = False
            except GitError as e:
                print(f"WARNING: Failed to push {branch.name} to {remote}: {e}")
                push_results[branch.name] = False

        # Push update branch to GitLab
        gitlab_remote = find_gitlab_remote(self.git)
        if gitlab_remote:
            try:
                print(f"Pushing {update_branch} to {gitlab_remote}...")
                self.git.push(gitlab_remote, update_branch, force=True)
                push_results[update_branch] = True
            except GitError as e:
                print(f"WARNING: Failed to push {update_branch} to {gitlab_remote}: {e}")
                push_results[update_branch] = False

        return push_results, divergence_errors

    def _print_summary(
        self,
        update_branch: str,
        target: str,
        dry_run: bool,
        push_results: dict[str, bool] | None = None,
        divergence_errors: list[RemoteDivergenceError] | None = None,
    ) -> None:
        """Print summary with MR URL and push results."""
        if push_results is None:
            push_results = {}
        if divergence_errors is None:
            divergence_errors = []

        if dry_run:
            print("\n=== DRY RUN SUMMARY ===")
            print(f"Would rebase onto {target}")
            print(f"Would integrate {len(self.sub.branches)} branches")
        else:
            print("\n=== REBASE COMPLETE ===")
            print(f"Rebased onto {target}")
            print(f"Integrated {len(self.sub.branches)} branches")

            if push_results:
                pushed = [name for name, success in push_results.items() if success]
                failed = [name for name, success in push_results.items() if not success]

                if pushed:
                    print(f"\n  Successfully pushed {len(pushed)} branch(es):")
                    for name in pushed:
                        print(f"  - {name}")

                if failed:
                    print(f"\n  Failed to push {len(failed)} branch(es):")
                    for name in failed:
                        print(f"  - {name}")

        gitlab_remote = find_gitlab_remote(self.git)
        remotes = self.git.list_remotes()

        if gitlab_remote:
            url = remotes[gitlab_remote]
            base = git_url_to_https(url)
            target_hash = self.git.run("rev-parse", "--short", target)
            mr_title = f"{self.sub.integration_branch}: Rebase to {target} @ {target_hash}"
            mr_description = format_mr_description(self.sub, remotes)
            mr_url = get_gitlab_mr_url(
                base,
                update_branch,
                self.sub.integration_branch,
                title=mr_title,
                description=mr_description,
            )
            print(f"\nCreate MR: {mr_url}")

        if divergence_errors:
            print("\n=== DIVERGENCE ERRORS ===", file=sys.stderr)
            print(
                "The following branches have diverged from their remotes.",
                file=sys.stderr,
            )
            print("Use --force-push to override.\n", file=sys.stderr)
            for i, err in enumerate(divergence_errors):
                if i > 0:
                    print("---", file=sys.stderr)
                print(
                    f"{err.branch}: remote has {err.remote_commits} commit(s) "
                    f"not in local, local has {err.local_commits} commit(s) not in remote",
                    file=sys.stderr,
                )

    def _resume_rebase(
        self, target: str, local_only: bool, dry_run: bool, force_push: bool
    ) -> None:
        """Resume interrupted rebase."""
        import json

        git_dir = self.git.git_dir()
        state_file = git_dir / "mbm-rebase-state.json"
        if not state_file.exists():
            raise GitError(
                "No rebase in progress to resume. Use 'mbm rebase' to start a new rebase."
            )

        state = json.loads(state_file.read_text())

        # Reload submodule config from config file if available
        config_path_str = state.get("config_path")
        sub_path_str = state.get("submodule_path")
        if config_path_str:
            from .config import MBMConfig

            mbm = MBMConfig.load(Path(config_path_str), require_exists=True)
            self.sub = mbm.get_submodule(sub_path_str)
        # Otherwise use the submodule config we were constructed with

        update_branch = state["update_branch"]

        # Check if there's an in-progress git rebase
        rebase_dir = git_dir / "rebase-merge"
        if rebase_dir.exists():
            try:
                self.git.run("rebase", "--continue")
            except GitError as e:
                raise RebaseConflictError(
                    "Rebase conflicts still exist. "
                    "Resolve them and run 'mbm rebase --resume' again."
                ) from e

            current_idx = state["index"]
            branch = self.sub.branches[current_idx]
            print(f"Completing integration of {branch.name}...")
            self._complete_integration(branch, update_branch)
            print(f"  Integrated {branch.name}")
            start_idx = current_idx + 1
        else:
            start_idx = state["index"] + 1

        if start_idx >= len(self.sub.branches):
            print("All branches integrated.")
        else:
            print(f"Resuming from branch {start_idx + 1}/{len(self.sub.branches)}...")
            for idx in range(start_idx, len(self.sub.branches)):
                self._save_progress(idx, update_branch, state["target"])
                self._integrate_pr(
                    self.sub.branches[idx],
                    state["target"],
                    update_branch,
                    dry_run=False,
                )

        push_results: dict[str, bool] = {}
        divergence_errors: list[RemoteDivergenceError] = []
        if not local_only and not dry_run:
            push_results, divergence_errors = self._push_branches(update_branch, force_push)
        self._print_summary(
            update_branch, state["target"], dry_run, push_results, divergence_errors
        )
        self._cleanup_progress()
