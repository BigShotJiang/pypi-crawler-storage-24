"""Rerere (reuse recorded resolution) training for micropython-branch-manager."""

import tempfile
from pathlib import Path

from .config import BranchConfig
from .exceptions import GitError
from .git import GitRepo
from .trailers import MERGE_PATTERN


class RerereTrainer:
    """Trains git rerere from an existing integration branch's merge resolutions."""

    def __init__(self, git: GitRepo):
        self.git = git

    def train(
        self,
        target: str,
        branches: list[BranchConfig],
        integration_branch: str,
    ) -> None:
        """Train rerere by replaying merges from the existing integration branch.

        Creates a temporary worktree, replays each merge, and uses the existing
        integration branch's tree to resolve any conflicts — letting rerere
        record each resolution for future reuse.

        No-op if there are no merge commits in the integration branch.
        """
        if not branches:
            return

        pairs = self._get_merge_commit_pairs(target, integration_branch, branches)
        if not pairs:
            return

        print("Training rerere from existing merge resolutions...")
        worktree_path = Path(tempfile.mkdtemp(prefix="mbm-rerere-"))
        try:
            wt_git = self.git.create_worktree(worktree_path, target)
            self._replay_merges(wt_git, pairs)
        finally:
            self.git.remove_worktree(worktree_path, force=True)
            # Clean up if directory still exists
            if worktree_path.exists():
                import shutil

                shutil.rmtree(worktree_path, ignore_errors=True)

        print("  Rerere training complete.")

    def _get_merge_commit_pairs(
        self,
        target: str,
        integration: str,
        branches: list[BranchConfig],
    ) -> list[tuple[BranchConfig, str]]:
        """Get merge commits matched to branches, oldest first.

        Uses a single git log call to get both hashes and subjects.
        """
        output = self.git.run("log", "--merges", "--format=%H %s", f"{target}..{integration}")
        if not output:
            return []

        # Build a map from branch name to merge commit hash
        hash_map: dict[str, str] = {}
        for line in output.split("\n"):
            if not line:
                continue
            commit_hash, subject = line.split(" ", 1)
            match = MERGE_PATTERN.search(subject)
            if match:
                hash_map[match.group(1)] = commit_hash

        pairs = []
        for branch in branches:
            if branch.name in hash_map:
                pairs.append((branch, hash_map[branch.name]))

        pairs.reverse()  # Oldest first
        return pairs

    def _replay_merges(
        self,
        wt_git: GitRepo,
        pairs: list[tuple[BranchConfig, str]],
    ) -> None:
        """Replay merges in the worktree, resolving conflicts from the integration branch."""
        for branch, merge_hash in pairs:
            # Ensure branch ref is available in worktree
            if not wt_git.branch_exists(branch.name):
                try:
                    wt_git.run("branch", branch.name, merge_hash, check=False)
                except GitError:
                    continue

            try:
                wt_git.run(
                    "merge",
                    "--no-ff",
                    branch.name,
                    "-m",
                    f"Merge branch '{branch.name}'",
                )
            except GitError:
                # Conflict — resolve using the known-good merge commit
                if not self._resolve_from_commit(wt_git, merge_hash):
                    # Could not resolve — abort and skip this branch
                    wt_git.run("merge", "--abort", check=False)
                    continue

    def _resolve_from_commit(self, wt_git: GitRepo, merge_hash: str) -> bool:
        """Resolve conflicts using file contents from the merge commit.

        Returns True if all conflicts were resolved.
        """
        status = wt_git.run("status", "--porcelain", check=False)
        if not status:
            return True

        for line in status.split("\n"):
            if not line:
                continue

            prefix = line[:2]
            filepath = line[3:]

            if prefix in ("UU", "AA"):
                # Both modified or both added — checkout from merge commit
                try:
                    wt_git.run("checkout", merge_hash, "--", filepath)
                    wt_git.run("add", filepath)
                except GitError:
                    return False
            elif prefix == "DD":
                # Both deleted
                wt_git.run("rm", filepath, check=False)
            elif prefix.startswith("D") or prefix.endswith("D"):
                # One side deleted — use merge commit's resolution
                try:
                    wt_git.run("checkout", merge_hash, "--", filepath)
                    wt_git.run("add", filepath)
                except GitError:
                    wt_git.run("rm", filepath, check=False)

        # Commit to record the rerere resolution
        try:
            wt_git.run("commit", "--no-edit")
            return True
        except GitError:
            return False
