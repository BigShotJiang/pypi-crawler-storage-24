"""Git operations wrapper for micropython-branch-manager."""

import re
import subprocess
from pathlib import Path

from .exceptions import (
    GitError,
    MergeConflictError,
    RebaseConflictError,
    RemoteDivergenceError,
    WorkingTreeDirtyError,
)


class GitRepo:
    """Wrapper for git operations in a specific directory."""

    def __init__(self, repo_path: Path):
        self.repo_path = repo_path
        self._git_dir: Path | None = None

    def git_dir(self) -> Path:
        """Resolve and cache the .git directory path."""
        if self._git_dir is None:
            git_dir = Path(self.run("rev-parse", "--git-dir"))
            if not git_dir.is_absolute():
                git_dir = self.repo_path / git_dir
            self._git_dir = git_dir
        return self._git_dir

    def run(self, *args: str, check: bool = True, capture: bool = True) -> str:
        """Execute git command, return stdout."""
        cmd = ["git", *args]
        result = subprocess.run(
            cmd,
            cwd=self.repo_path,
            capture_output=capture,
            text=True,
        )
        if check and result.returncode != 0:
            raise GitError(f"git {args[0]} failed: {result.stderr}")
        return result.stdout.strip() if result.stdout else ""

    def is_clean(self) -> bool:
        """Check if working tree is clean."""
        return self.run("status", "--porcelain") == ""

    def require_clean(self) -> None:
        """Raise if working tree has uncommitted changes."""
        if not self.is_clean():
            raise WorkingTreeDirtyError(
                "Working tree has uncommitted changes. Please commit or stash changes first."
            )

    _CONFLICT_PREFIXES = ("UU ", "AA ", "DD ")

    def _get_conflicting_files(self) -> list[str]:
        """Parse git status --porcelain for conflict markers."""
        status = self.run("status", "--porcelain", check=False)
        return [line[3:] for line in status.split("\n") if line.startswith(self._CONFLICT_PREFIXES)]

    def fetch(self, remote: str = "--all") -> None:
        """Fetch from remote(s)."""
        self.run("submodule", "sync", "--recursive", check=False)

        cmd = ["git", "fetch", remote]
        result = subprocess.run(
            cmd,
            cwd=self.repo_path,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            stderr = result.stderr.lower()
            if "submodule" not in stderr or (
                "fatal" in stderr and "submodule" not in stderr.split("fatal")[0]
            ):
                raise GitError(f"git fetch failed: {result.stderr}")

    def checkout(self, ref: str, create: bool = False, force: bool = False) -> None:
        """Checkout branch or ref."""
        args = ["checkout"]
        if create:
            args.append("-B" if force else "-b")
        args.append(ref)
        self.run(*args)

    def rebase(self, onto: str, update_refs: bool = True, auto_continue: bool = False) -> None:
        """Rebase with merge commit preservation.

        Args:
            onto: Target ref to rebase onto.
            update_refs: Whether to use --update-refs.
            auto_continue: If True, auto-continue when rerere resolves all conflicts.

        Raises:
            RebaseConflictError: If conflicts require manual resolution.
        """
        args = ["rebase", "--rebase-merges"]
        if update_refs:
            args.append("--update-refs")
        args.append(onto)

        try:
            self.run(*args)
        except GitError as e:
            if auto_continue and self._try_auto_continue_rebase():
                return

            conflicting = self._get_conflicting_files()
            if conflicting:
                raise RebaseConflictError(
                    "Rebase stopped due to conflicts.\n"
                    "Conflicting files:\n  " + "\n  ".join(conflicting) + "\n\n"
                    "Please resolve conflicts manually, then run:\n"
                    "  git rebase --continue\n\n"
                    "Or to abort:\n"
                    "  git rebase --abort",
                    conflicting_files=conflicting,
                ) from e
            raise

    def _try_auto_continue_rebase(self) -> bool:
        """Loop rebase --continue while rerere resolves all conflicts.

        Returns True if rebase completed successfully.
        """
        for _ in range(100):  # safety bound
            if self._get_conflicting_files():
                return False
            try:
                self.run("rebase", "--continue")
                return True
            except GitError:
                continue
        return False

    def merge(self, branch: str, message: str, no_ff: bool = True) -> None:
        """Merge branch with optional no-ff.

        Raises:
            MergeConflictError: If conflicts require manual resolution
        """
        args = ["merge"]
        if no_ff:
            args.append("--no-ff")
        args.extend([branch, "-m", message])

        try:
            self.run(*args)
        except GitError as e:
            conflicting = self._get_conflicting_files()
            if conflicting:
                raise MergeConflictError(
                    "Merge stopped due to conflicts.\n"
                    "Conflicting files:\n  " + "\n  ".join(conflicting) + "\n\n"
                    "Please resolve conflicts manually, then run:\n"
                    "  git merge --continue\n\n"
                    "Or to abort:\n"
                    "  git merge --abort",
                    conflicting_files=conflicting,
                ) from e
            raise

    def push(self, remote: str, branch: str, force: bool = False) -> None:
        """Push branch to remote."""
        args = ["push"]
        if force:
            args.append("--force")
        args.extend([remote, branch])
        self.run(*args)

    def get_merge_base(self, ref1: str, ref2: str) -> str:
        """Get merge base commit."""
        return self.run("merge-base", ref1, ref2)

    def rev_parse(self, ref: str) -> str:
        """Resolve ref to commit hash."""
        return self.run("rev-parse", ref)

    def branch_exists(self, branch: str, remote: bool = False) -> bool:
        """Check if branch exists."""
        ref = f"refs/remotes/{branch}" if remote else f"refs/heads/{branch}"
        try:
            self.run("rev-parse", "--verify", ref)
            return True
        except GitError:
            return False

    def create_branch(self, name: str, start_point: str) -> None:
        """Create branch from start point."""
        self.run("branch", name, start_point)

    def set_branch_upstream(self, branch: str, upstream: str) -> None:
        """Set upstream tracking for a branch."""
        self.run("branch", f"--set-upstream-to={upstream}", branch)

    def ensure_remote(self, name: str, url: str) -> None:
        """Ensure remote exists with correct URL."""
        try:
            current = self.run("config", f"remote.{name}.url")
            if current != url:
                self.run("remote", "set-url", name, url)
        except GitError:
            self.run("remote", "add", name, url)

    def list_remotes(self) -> dict[str, str]:
        """List all remotes with URLs."""
        output = self.run("remote", "-v")
        remotes = {}
        for line in output.split("\n"):
            if line and "(fetch)" in line:
                parts = line.split()
                if len(parts) >= 2:
                    remotes[parts[0]] = parts[1]
        return remotes

    def get_log_subjects(self, range_spec: str) -> list[str]:
        """Get commit subjects in range."""
        output = self.run("log", "--format=%s", range_spec)
        return [line for line in output.split("\n") if line]

    def check_divergence(
        self, local_branch: str, remote_branch: str, force_push: bool = False
    ) -> None:
        """Check if remote branch has diverged from local branch."""
        if force_push:
            return

        try:
            self.run("rev-parse", "--verify", remote_branch)
        except GitError:
            return

        try:
            remote_only = self.run("rev-list", "--count", f"{local_branch}..{remote_branch}")
            local_only = self.run("rev-list", "--count", f"{remote_branch}..{local_branch}")

            remote_count = int(remote_only) if remote_only else 0
            local_count = int(local_only) if local_only else 0

            if remote_count > 0:
                raise RemoteDivergenceError(
                    f"Remote branch '{remote_branch}' has {remote_count} commit(s) "
                    f"not in local branch '{local_branch}'.\n"
                    f"Local branch has {local_count} commit(s) not in remote.\n\n"
                    "This may indicate that the remote has been updated since your last fetch.\n"
                    "Options:\n"
                    "  1. Fetch and review remote changes first\n"
                    "  2. Use --force-push to overwrite remote (USE WITH CAUTION)\n"
                    "  3. Abort and investigate the divergence",
                    branch=local_branch,
                    remote_commits=remote_count,
                    local_commits=local_count,
                )
        except ValueError:
            pass

    _PR_URL_RE = re.compile(r"https?://github\.com/([^/]+)/([^/]+)/pull/\d+")

    def resolve_remote_for_pr(
        self, pr_url: str | None, remotes: dict[str, str] | None = None
    ) -> str | None:
        """Find a local remote matching a GitHub PR URL's repository.

        Args:
            pr_url: GitHub PR URL.
            remotes: Pre-fetched remotes dict to avoid repeated git calls.
        """
        if not pr_url:
            return None

        match = self._PR_URL_RE.match(pr_url)
        if not match:
            return None

        owner = match.group(1)
        repo = match.group(2)

        if remotes is None:
            remotes = self.list_remotes()
        for name, url in remotes.items():
            if f"/{owner}/{repo}" in url or f":{owner}/{repo}" in url:
                return name

        return None

    def resolve_remote_for_owner(
        self, owner: str, remotes: dict[str, str] | None = None
    ) -> str | None:
        """Find a local remote for a GitHub user/org by scanning remote URLs."""
        if remotes is None:
            remotes = self.list_remotes()
        for name, url in remotes.items():
            if f"/{owner}/" in url or f":{owner}/" in url:
                return name
        return None

    # Rerere support

    def configure_rerere(self) -> None:
        """Enable git rerere with auto-update."""
        self.run("config", "rerere.enabled", "true")
        self.run("config", "rerere.autoUpdate", "true")

    def is_rerere_enabled(self) -> bool:
        """Check if rerere is enabled."""
        try:
            return self.run("config", "--get", "rerere.enabled") == "true"
        except GitError:
            return False

    # Worktree support

    def create_worktree(self, path: Path, ref: str, detach: bool = True) -> "GitRepo":
        """Create a worktree and return a GitRepo for it."""
        args = ["worktree", "add"]
        if detach:
            args.append("--detach")
        args.extend([str(path), ref])
        self.run(*args)
        return GitRepo(path)

    def remove_worktree(self, path: Path, force: bool = False) -> None:
        """Remove a worktree."""
        args = ["worktree", "remove"]
        if force:
            args.append("--force")
        args.append(str(path))
        self.run(*args, check=False)
