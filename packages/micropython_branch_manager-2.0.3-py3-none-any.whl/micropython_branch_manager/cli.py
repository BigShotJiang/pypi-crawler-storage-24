"""CLI interface for micropython-branch-manager."""

import os
import sys
from pathlib import Path
from typing import Annotated

import cyclopts

from .branch_sync import extract_branches_from_merges, sync_config_with_branches
from .config import CONFIG_FILENAME, MBMConfig, SubmoduleConfig, find_config
from .exceptions import GitHubCLINotFound, MBMError
from .git import GitRepo
from .github import GitHubClient
from .pr import PRManager
from .rebase import RebaseManager

app = cyclopts.App(
    name="mbm",
    help="Manage MicroPython fork integration branches.",
)

# Common parameter types
SubmoduleSelector = Annotated[
    str | None,
    cyclopts.Parameter(
        name=["--submodule", "-s"],
        help="Submodule to operate on (auto-detected from CWD if unambiguous)",
    ),
]

ConfigPathParam = Annotated[
    Path | None,
    cyclopts.Parameter(
        name="--config",
        help=f"Path to {CONFIG_FILENAME} (default: auto-detect)",
    ),
]

_SUBMODULE_CANDIDATES = [Path("src/micropython"), Path("micropython"), Path(".")]

_GITHUB_URL_RE = __import__("re").compile(
    r"(?:https?://github\.com/|git@github\.com:)([^/]+/[^/]+?)(?:\.git)?$"
)


def _github_repo_from_remotes(remotes: dict[str, str]) -> str | None:
    """Extract GitHub owner/repo from the 'upstream' remote URL."""
    url = remotes.get("upstream", "")
    match = _GITHUB_URL_RE.match(url)
    return match.group(1) if match else None


def _detect_submodule() -> Path | None:
    """Try common submodule locations, return resolved path or None."""
    for candidate in _SUBMODULE_CANDIDATES:
        if (candidate / ".git").exists():
            return candidate.resolve()
    return None


def _find_config_path(config_flag: Path | None) -> Path | None:
    """Resolve config path from flag or auto-detect."""
    if config_flag:
        config_path = config_flag.resolve()
        if not config_path.exists():
            raise ValueError(f"Config file not found: {config_path}")
        return config_path
    return find_config()


def resolve_context(
    config_flag: Path | None = None,
    submodule_flag: str | None = None,
) -> tuple[Path | None, MBMConfig, SubmoduleConfig, Path]:
    """Resolve config path, config, selected submodule, and submodule filesystem path.

    Returns (config_path, mbm_config, submodule_config, submodule_resolved_path).
    config_path may be None in standalone mode.
    """
    config_path = _find_config_path(config_flag)

    if config_path:
        mbm_config = MBMConfig.load(config_path, require_exists=True)
        sub = mbm_config.get_submodule(submodule_flag, config_path)
        return config_path, mbm_config, sub, sub.resolve_path(config_path)

    # Standalone fallback: no config file
    if submodule_flag:
        sub_path = Path(submodule_flag).resolve()
    else:
        sub_path_opt = _detect_submodule()
        if not sub_path_opt:
            raise ValueError(
                f"Could not find {CONFIG_FILENAME} or detect submodule path. "
                "Use --config or --submodule."
            )
        sub_path = sub_path_opt

    sub = SubmoduleConfig(path=str(sub_path))
    return None, MBMConfig(submodules=[sub]), sub, sub_path


@app.command
def init(
    submodule: Annotated[
        str | None,
        cyclopts.Parameter(
            name="--submodule",
            help="Path to submodule to manage",
        ),
    ] = None,
    config_path: ConfigPathParam = None,
    integration_branch: Annotated[
        str | None,
        cyclopts.Parameter(name=["--integration-branch", "-b"]),
    ] = None,
) -> None:
    """Initialize or add a submodule to configuration."""
    # Determine submodule path
    if submodule:
        sub_path = Path(submodule).resolve()
    else:
        detected = _detect_submodule()
        if not detected:
            raise ValueError("Could not detect submodule path. Use --submodule.")
        sub_path = detected

    if not (sub_path / ".git").exists():
        raise ValueError(f"Not a git repository: {sub_path}")

    git = GitRepo(sub_path)

    # If integration branch not specified, detect current branch
    if integration_branch is None:
        integration_branch = git.run("branch", "--show-current")
        if not integration_branch:
            integration_branch = "main"
        print(f"Using current branch as integration branch: {integration_branch}")

    # Detect existing git remotes
    remotes = git.list_remotes()
    if remotes:
        print(f"\nDetected {len(remotes)} remote(s):")
        for name, url in remotes.items():
            print(f"  - {name}: {url}")

    # Determine config file location
    out_path = config_path.resolve() if config_path else Path.cwd().resolve() / CONFIG_FILENAME

    # Compute relative submodule path from config file location
    try:
        rel_sub = os.path.relpath(sub_path, out_path.parent)
    except ValueError:
        rel_sub = str(sub_path)

    # Load existing config or create new
    if out_path.exists():
        mbm_config = MBMConfig.load(out_path)
        # Check if submodule already configured
        for existing in mbm_config.submodules:
            if existing.path == rel_sub:
                raise ValueError(
                    f"Submodule '{rel_sub}' already configured in {out_path}. "
                    "Use 'mbm sync' to update."
                )
        print(f"\nAdding submodule to existing config: {out_path}")
    else:
        mbm_config = MBMConfig()

    mbm_config.submodules.append(
        SubmoduleConfig(
            path=rel_sub,
            integration_branch=integration_branch,
        )
    )
    mbm_config.save(out_path)

    # Enable git rerere in the submodule
    git.configure_rerere()

    print(f"\nConfig: {out_path}")
    print(f"Submodule path: {rel_sub}")
    if len(mbm_config.submodules) > 1:
        print(f"Total submodules: {len(mbm_config.submodules)}")


@app.command
def rebase(
    target: str = "upstream/master",
    submodule: SubmoduleSelector = None,
    config_path: ConfigPathParam = None,
    local: Annotated[bool, cyclopts.Parameter(name="--local")] = False,
    dry_run: Annotated[bool, cyclopts.Parameter(name="--dry-run")] = False,
    force_push: Annotated[bool, cyclopts.Parameter(name="--force-push")] = False,
    resume: Annotated[bool, cyclopts.Parameter(name="--resume")] = False,
) -> None:
    """Rebase integration branch by rebuilding from fresh PRs."""
    cfg_path, mbm_config, sub, sub_path = resolve_context(config_path, submodule)
    manager = RebaseManager(sub_path, sub, cfg_path, mbm_config)
    manager.execute(
        target=target,
        local_only=local,
        dry_run=dry_run,
        force_push=force_push,
        resume=resume,
    )


@app.command
def add_pr(
    pr_identifier: str,
    submodule: SubmoduleSelector = None,
    config_path: ConfigPathParam = None,
) -> None:
    """Add PR to integration branch."""
    cfg_path, mbm_config, sub, sub_path = resolve_context(config_path, submodule)
    manager = PRManager(sub_path, sub, cfg_path, mbm_config)
    manager.add_pr(pr_identifier)


@app.command
def sync(
    gh_author: Annotated[
        str,
        cyclopts.Parameter(
            help="GitHub username to look up PR metadata for branches",
        ),
    ],
    submodule: SubmoduleSelector = None,
    config_path: ConfigPathParam = None,
) -> None:
    """Sync config with current branch state.

    Detects branches from merge commits and updates config with PR metadata.
    """
    cfg_path, mbm_config, sub, sub_path = resolve_context(config_path, submodule)
    if not cfg_path:
        raise ValueError("sync requires a config file. Run 'mbm init' first.")
    git = GitRepo(sub_path)

    # Detect branches
    detected = extract_branches_from_merges(git, "upstream/master", sub.integration_branch)

    # Detect upstream GitHub repo from remote URL
    from .github import PRInfo

    remotes = git.list_remotes()
    gh_repo = _github_repo_from_remotes(remotes)

    pr_cache: dict[str, PRInfo] = {}
    github: GitHubClient | None = None
    try:
        github = GitHubClient(repo=gh_repo) if gh_repo else GitHubClient()
        pr_cache = github.get_pr_info_by_branches(gh_author)
    except GitHubCLINotFound:
        pass

    # Look up individual branches not found in author cache
    if github:
        all_branches = set(detected) | {b.name for b in sub.branches}
        for branch_name in all_branches:
            if branch_name not in pr_cache:
                pr = github.find_pr_by_branch(branch_name)
                if pr:
                    pr_cache[branch_name] = pr

    # Sync
    if sync_config_with_branches(sub, detected, pr_cache):
        mbm_config.save(cfg_path)
        print(f"Updated {cfg_path}")
    else:
        print("Config already in sync")


@app.command
def config(
    submodule: SubmoduleSelector = None,
    config_path: ConfigPathParam = None,
) -> None:
    """Show current configuration."""
    cfg_path, mbm_config, sub, sub_path = resolve_context(config_path, submodule)
    if not cfg_path:
        raise ValueError("No config file found. Run 'mbm init' first.")

    print(f"Config file: {cfg_path}")
    if len(mbm_config.submodules) > 1:
        print(f"Submodules: {len(mbm_config.submodules)}")
    print(f"Submodule path: {sub.path}")
    print(f"Integration branch: {sub.integration_branch}")

    # Show branches
    print(f"\nBranches ({len(sub.branches)}):")
    for b in sub.branches:
        title = b.title or "(no title)"
        print(f"  {b.name}: {title}")
        if b.pr_url:
            print(f"    - {b.pr_url}")
        print()

    # Show remotes from git
    git = GitRepo(sub_path)
    remotes = git.list_remotes()
    if remotes:
        print(f"Remotes ({len(remotes)}):")
        for name, url in remotes.items():
            print(f"  {name}: {url}")


def main() -> None:
    """Entry point."""
    try:
        app()
    except MBMError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
