import argparse
from pathlib import Path

from pydantic import ValidationError

from .config import DEFAULT_CONFIG_FILENAME, init_config, load_config
from .generator import generate_project


def build_parser():
    parser = argparse.ArgumentParser(
        prog="genxcode",
        description="Initialize or apply a YAML config for PyTorch boilerplate.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    init_parser = subparsers.add_parser(
        "init",
        help="Create a default YAML config file",
    )
    init_parser.add_argument(
        "name",
        nargs="?",
        default="pytorch",
        help="Project name used in the config and output folder",
    )
    init_parser.add_argument(
        "--force",
        action="store_true",
        help="Overwrite an existing config file",
    )

    apply_parser = subparsers.add_parser(
        "apply",
        help="Generate boilerplate from a YAML config file",
    )

    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)

    try:
        config_path = Path(DEFAULT_CONFIG_FILENAME)

        if args.command == "init":
            created_path = init_config(
                name=args.name,
                path=config_path,
                force=args.force,
            )
            print(f"Created {created_path}")
            return 0

        config = load_config(config_path)
        generate_project(
            config,
            output_dir=config_path.resolve().parent / config.name,
        )
        return 0
    except (FileExistsError, FileNotFoundError, ValidationError, ValueError) as exc:
        parser.exit(status=1, message=f"error: {exc}\n")


if __name__ == "__main__":
    raise SystemExit(main())
