from pathlib import Path

import torch

from ..config import GenerationConfig
from .archs import build_mlp
from .templates import (
    render_config,
    render_data,
    render_init,
    render_model,
    render_main,
    render_predict,
    render_requirements,
    render_train,
)


def detect_device():
    if torch.backends.mps.is_available():
        return "mps"
    if torch.cuda.is_available():
        return "cuda"
    return "cpu"


def generate_project(config: GenerationConfig, output_dir: str | Path = "."):
    device = detect_device()
    has_amp = device == "cuda"

    if config.arch == "mlp":
        layers_code = build_mlp(
            config.input_dim,
            config.hidden,
            config.output_dim,
            config.activation,
        )
    else:
        raise ValueError(f"Unsupported arch: {config.arch}. Supported: 'mlp'")

    root_dir = Path(output_dir)
    src_dir = root_dir / "src"
    src_dir.mkdir(parents=True, exist_ok=True)

    files = {
        src_dir / "__init__.py": render_init(config.name),
        src_dir / "config.py": render_config(
            config.name,
            config.input_dim,
            config.hidden,
            config.output_dim,
            config.lr,
            config.epochs,
            config.batch_size,
            device,
        ),
        src_dir / "models.py": render_model(config.name, layers_code),
        src_dir / "data.py": render_data(config.name),
        src_dir / "train.py": render_train(
            config.name,
            device,
            config.prod,
            config.metrics,
            has_amp,
        ),
        src_dir / "predict.py": render_predict(config.name),
        root_dir / "requirements.txt": render_requirements(
            config.prod,
            config.metrics,
        ),
        root_dir / "main.py": render_main(),
    }

    for path, content in files.items():
        path.write_text(content, encoding="utf-8")
        print(f"  {path.relative_to(root_dir)}")

    print(f"\nGenerated {config.name} ({config.arch}) in {root_dir} on {device}")
    if config.prod:
        print("  View metrics: mlflow ui")
    else:
        print("  View metrics: tensorboard --logdir=runs")
