from .core import generate_project

__all__ = ["generate_project"]
