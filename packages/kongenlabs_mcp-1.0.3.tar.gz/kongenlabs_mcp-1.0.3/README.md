# kongen-mcp

MCP (Model Context Protocol) server for the [Kongen Labs](https://kongenlabs.life) SCI Pattern Intelligence API.

Connects Claude Code, Cursor, Windsurf, and any MCP-compatible client to Kongen's cross-domain pattern intelligence — reasoning regime detection, structural transfer scoring, and intelligent model routing.

## Tools

| Tool | Description | Cost |
|------|-------------|------|
| `score_prompt` | Detect reasoning regime and optimal token budget for a prompt | 1 KT |
| `transfer_score` | Score a structural signature against 2.8M+ cross-domain patterns | 50 KT |
| `check_usage` | Check your token balance and usage | 0 KT |
| `route_model` | Recommend Haiku/Sonnet/Opus based on prompt complexity | 1 KT |

## Installation

```bash
pip install kongenlabs-mcp
```

Or install from source:

```bash
git clone https://github.com/kongenlabs/kongen-mcp.git
cd kongen-mcp
pip install .
```

## Configuration

Get your API key at [kongenlabs.life](https://kongenlabs.life).

### Claude Code

Add with the CLI:

```bash
claude mcp add kongen -- kongen-mcp
```

Then set your API key when prompted, or add it manually to `.claude/mcp.json`:

```json
{
  "mcpServers": {
    "kongen": {
      "command": "kongen-mcp",
      "env": {
        "KONGEN_API_KEY": "kl_live_..."
      }
    }
  }
}
```

### Cursor

1. Open **Settings** > **MCP** > **Add Server**
2. Name: `kongen`
3. Command: `kongen-mcp`
4. Environment variables:
   - `KONGEN_API_KEY`: your API key

### Windsurf

Add to your MCP configuration:

```json
{
  "mcpServers": {
    "kongen": {
      "command": "kongen-mcp",
      "env": {
        "KONGEN_API_KEY": "kl_live_..."
      }
    }
  }
}
```

### Custom base URL

To point at staging or a local instance, set `KONGEN_API_BASE_URL`:

```json
{
  "mcpServers": {
    "kongen": {
      "command": "kongen-mcp",
      "env": {
        "KONGEN_API_KEY": "kl_test_...",
        "KONGEN_API_BASE_URL": "https://staging-api.kongenlabs.life"
      }
    }
  }
}
```

## Usage examples

Once configured, the tools are available to your AI assistant. Examples of what you can ask:

**Prompt scoring:**
> "Score this prompt for complexity: Prove that the square root of 2 is irrational using proof by contradiction."

**Model routing:**
> "Which Claude model should I use for this task: Summarize this 3-line email."

**Transfer scoring:**
> "Score this structural signature: activator 0.7, inhibitor 0.3, boundary 0.8, scale_coherence 0.6, field_magnitude 1.5, a_i_ratio 2.33, gradient 0.5"

**Usage check:**
> "How many Kongen tokens do I have left?"

## Environment variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `KONGEN_API_KEY` | Yes | — | Your Kongen API key (`kl_live_...` or `kl_test_...`) |
| `KONGEN_API_BASE_URL` | No | `https://api.kongenlabs.life` | API base URL override |

## License

MIT

<!-- mcp-name: io.github.kongen-labs/kongen-mcp -->
