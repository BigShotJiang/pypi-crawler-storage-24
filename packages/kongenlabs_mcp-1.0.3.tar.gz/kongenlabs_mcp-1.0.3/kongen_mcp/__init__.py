"""Kongen Labs MCP server for SCI Pattern Intelligence."""

__version__ = "1.0.0"
