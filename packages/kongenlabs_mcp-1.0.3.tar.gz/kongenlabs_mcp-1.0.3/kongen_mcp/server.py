"""Kongen Labs MCP server — SCI Pattern Intelligence for LLM agents.

Exposes Kongen API capabilities as MCP tools for use with Claude Code,
Cursor, Windsurf, and any other MCP-compatible client.

Tools:
    score_prompt    — Chiryu reasoning regime detection (1 KT)
    transfer_score  — Cross-domain pattern transfer scoring (50 KT)
    check_usage     — Token balance and plan info (0 KT)
    route_model     — Model recommendation based on prompt complexity (1 KT)
"""

from __future__ import annotations

import json
import os
import sys
from typing import Any

import httpx
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

_DEFAULT_BASE_URL = "https://api.kongenlabs.life"
_TIMEOUT = 30.0
_USER_AGENT = "kongen-mcp/1.0.0"

# Regime-to-model mapping for route_model tool
_REGIME_MODEL_MAP: dict[str, dict[str, Any]] = {
    "trivial": {
        "model": "claude-haiku",
        "savings_pct": 90,
        "reasoning": "Simple recall — Haiku handles this instantly at ~1/60th the cost of Opus.",
    },
    "fast": {
        "model": "claude-haiku",
        "savings_pct": 85,
        "reasoning": "Low-complexity task — Haiku is sufficient and dramatically cheaper.",
    },
    "moderate": {
        "model": "claude-sonnet",
        "savings_pct": 50,
        "reasoning": "Moderate reasoning required — Sonnet balances quality and cost.",
    },
    "deep": {
        "model": "claude-sonnet",
        "savings_pct": 30,
        "reasoning": "Deep analytical task — Sonnet handles most cases; consider Opus for critical work.",
    },
    "exhaustive": {
        "model": "claude-opus",
        "savings_pct": 0,
        "reasoning": "Maximum reasoning depth required — Opus is recommended for correctness.",
    },
}

# ---------------------------------------------------------------------------
# HTTP client
# ---------------------------------------------------------------------------


class KongenAPIClient:
    """Thin async HTTP client for the Kongen Labs API."""

    def __init__(self) -> None:
        api_key = os.environ.get("KONGEN_API_KEY")
        if not api_key:
            raise RuntimeError(
                "KONGEN_API_KEY environment variable is required. "
                "Get your key at https://kongenlabs.life"
            )
        self._api_key = api_key
        self._base_url = os.environ.get("KONGEN_API_BASE_URL", _DEFAULT_BASE_URL).rstrip("/")
        self._client = httpx.AsyncClient(
            base_url=self._base_url,
            timeout=_TIMEOUT,
            headers={
                "X-API-Key": self._api_key,
                "User-Agent": _USER_AGENT,
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
        )

    async def request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        """Send authenticated request with error handling."""
        try:
            response = await self._client.request(method, path, **kwargs)
        except httpx.TransportError as exc:
            raise RuntimeError(f"Network error connecting to Kongen API: {exc}") from exc

        if response.status_code == 200:
            return response.json()

        # Map HTTP errors to readable messages
        detail = self._extract_detail(response)

        if response.status_code in (401, 403):
            raise RuntimeError(
                f"Authentication failed: {detail or 'Invalid or missing API key.'} "
                f"Check your KONGEN_API_KEY."
            )

        if response.status_code == 402:
            raise RuntimeError(
                "Insufficient Kongen Tokens. "
                "Upgrade your plan at https://kongenlabs.life/pricing"
            )

        if response.status_code == 429:
            retry_after = response.headers.get("Retry-After", "unknown")
            raise RuntimeError(
                f"Rate limit exceeded. Retry after {retry_after} seconds."
            )

        raise RuntimeError(
            f"API error {response.status_code}: {detail or response.text}"
        )

    @staticmethod
    def _extract_detail(response: httpx.Response) -> str | None:
        try:
            body = response.json()
            if isinstance(body, dict):
                return body.get("detail") or body.get("error") or body.get("message")
        except Exception:
            pass
        return None

    async def close(self) -> None:
        await self._client.aclose()


# ---------------------------------------------------------------------------
# MCP Server
# ---------------------------------------------------------------------------

server = Server("kongen")


def _tools() -> list[Tool]:
    """Define the MCP tools exposed by this server."""
    return [
        Tool(
            name="score_prompt",
            description=(
                "Score a text prompt for reasoning complexity using Kongen's Chiryu engine. "
                "Returns the detected reasoning regime (trivial/fast/moderate/deep/exhaustive), "
                "a cross-domain boost factor, activator/inhibitor ratio, and recommended "
                "token budget. Costs 1 Kongen Token."
            ),
            inputSchema={
                "type": "object",
                "required": ["text"],
                "properties": {
                    "text": {
                        "type": "string",
                        "description": "The prompt text to analyze for reasoning complexity.",
                    },
                    "model_hint": {
                        "type": "string",
                        "description": (
                            "Optional model identifier for calibration "
                            "(e.g., 'haiku', 'sonnet', 'opus')."
                        ),
                    },
                },
            },
        ),
        Tool(
            name="transfer_score",
            description=(
                "Score a UAF structural signature against 2.8M+ cross-domain reference "
                "patterns from 6 organisms (capital markets, Go, genetics, language, "
                "locomotion, LLM). Returns universal pattern classification, confidence, "
                "boost factor, and cross-domain evidence. Costs 50 Kongen Tokens."
            ),
            inputSchema={
                "type": "object",
                "required": [
                    "activator_strength",
                    "inhibitor_strength",
                    "boundary_strength",
                    "scale_coherence",
                    "field_magnitude",
                    "a_i_ratio",
                    "gradient_strength",
                ],
                "properties": {
                    "activator_strength": {
                        "type": "number",
                        "description": "Strength of activating force (growth, expansion). Range [0, 1].",
                    },
                    "inhibitor_strength": {
                        "type": "number",
                        "description": "Strength of inhibiting force (boundaries, suppression). Range [0, 1].",
                    },
                    "boundary_strength": {
                        "type": "number",
                        "description": "Sharpness of boundary formation between regions. Range [0, 1].",
                    },
                    "scale_coherence": {
                        "type": "number",
                        "description": "Pattern consistency across multiple scales. Range [0, 1].",
                    },
                    "field_magnitude": {
                        "type": "number",
                        "description": "Overall morphogenetic field energy magnitude.",
                    },
                    "a_i_ratio": {
                        "type": "number",
                        "description": "Activator-to-inhibitor ratio. Goldilocks zone: 0.55-0.70.",
                    },
                    "gradient_strength": {
                        "type": "number",
                        "description": "Strength of spatial/temporal gradient. Range [0, 1].",
                    },
                    "source_domain": {
                        "type": "string",
                        "description": (
                            "Originating domain hint. Excludes same-domain patterns from evidence. "
                            "One of: genetics, language, capital, locomotion, go, llm."
                        ),
                        "enum": ["genetics", "language", "capital", "locomotion", "go", "llm"],
                    },
                },
            },
        ),
        Tool(
            name="check_usage",
            description=(
                "Check your Kongen Token balance, usage in the current billing cycle, "
                "and active plan. No token cost."
            ),
            inputSchema={
                "type": "object",
                "properties": {},
            },
        ),
        Tool(
            name="route_model",
            description=(
                "Recommend which Claude model (Haiku/Sonnet/Opus) to use for a given "
                "prompt based on its reasoning complexity. Internally scores the prompt "
                "with Chiryu, then maps the detected regime to a model recommendation "
                "with estimated cost savings. Costs 1 Kongen Token."
            ),
            inputSchema={
                "type": "object",
                "required": ["text"],
                "properties": {
                    "text": {
                        "type": "string",
                        "description": "The prompt text to evaluate for model routing.",
                    },
                },
            },
        ),
    ]


@server.list_tools()
async def list_tools() -> list[Tool]:
    return _tools()


@server.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    """Dispatch MCP tool calls to the appropriate handler."""
    try:
        if name == "score_prompt":
            return await _handle_score_prompt(arguments)
        elif name == "transfer_score":
            return await _handle_transfer_score(arguments)
        elif name == "check_usage":
            return await _handle_check_usage(arguments)
        elif name == "route_model":
            return await _handle_route_model(arguments)
        else:
            return [TextContent(type="text", text=f"Unknown tool: {name}")]
    except RuntimeError as exc:
        return [TextContent(type="text", text=f"Error: {exc}")]
    except Exception as exc:
        return [TextContent(type="text", text=f"Unexpected error: {type(exc).__name__}: {exc}")]


# ---------------------------------------------------------------------------
# Tool handlers
# ---------------------------------------------------------------------------


async def _handle_score_prompt(arguments: dict[str, Any]) -> list[TextContent]:
    """Score a prompt for reasoning complexity."""
    text = arguments.get("text")
    if not text:
        return [TextContent(type="text", text="Error: 'text' parameter is required.")]

    payload: dict[str, Any] = {"text": text}
    model_hint = arguments.get("model_hint")
    if model_hint:
        payload["model_hint"] = model_hint

    client = KongenAPIClient()
    try:
        data = await client.request("POST", "/v1/logic/score", json=payload)
    finally:
        await client.close()

    result = {
        "regime": data.get("regime"),
        "boost_factor": data.get("boost_factor"),
        "activator_strength": data.get("activator_strength"),
        "inhibitor_strength": data.get("inhibitor_strength"),
        "a_i_ratio": data.get("a_i_ratio"),
        "recommended_tokens": data.get("recommended_tokens"),
        "tokens_used": data.get("tokens_used"),
        "tokens_remaining": data.get("tokens_remaining"),
    }

    return [TextContent(type="text", text=json.dumps(result, indent=2))]


async def _handle_transfer_score(arguments: dict[str, Any]) -> list[TextContent]:
    """Score a structural signature against cross-domain patterns."""
    signature_keys = [
        "activator_strength",
        "inhibitor_strength",
        "boundary_strength",
        "scale_coherence",
        "field_magnitude",
        "a_i_ratio",
        "gradient_strength",
    ]

    missing = [k for k in signature_keys if k not in arguments]
    if missing:
        return [TextContent(
            type="text",
            text=f"Error: Missing required signature fields: {', '.join(missing)}",
        )]

    signature = {k: float(arguments[k]) for k in signature_keys}
    payload: dict[str, Any] = {"signature": signature}

    source_domain = arguments.get("source_domain")
    if source_domain:
        payload["source_domain"] = source_domain

    client = KongenAPIClient()
    try:
        data = await client.request("POST", "/v1/transfer/score", json=payload)
    finally:
        await client.close()

    result = {
        "classification": data.get("classification"),
        "confidence": data.get("confidence"),
        "boost_factor": data.get("boost_factor"),
        "cross_domain_evidence": data.get("cross_domain_evidence", []),
        "tokens_used": data.get("tokens_used"),
        "tokens_remaining": data.get("tokens_remaining"),
    }

    return [TextContent(type="text", text=json.dumps(result, indent=2))]


async def _handle_check_usage(arguments: dict[str, Any]) -> list[TextContent]:
    """Check token balance and plan info."""
    client = KongenAPIClient()
    try:
        data = await client.request("GET", "/v1/billing/usage")
    finally:
        await client.close()

    result = {
        "plan": data.get("plan"),
        "tokens_used": data.get("tokens_used"),
        "tokens_remaining": data.get("tokens_remaining"),
        "tokens_total": data.get("tokens_total"),
        "cycle": data.get("cycle"),
    }

    return [TextContent(type="text", text=json.dumps(result, indent=2))]


async def _handle_route_model(arguments: dict[str, Any]) -> list[TextContent]:
    """Recommend a Claude model based on prompt complexity."""
    text = arguments.get("text")
    if not text:
        return [TextContent(type="text", text="Error: 'text' parameter is required.")]

    client = KongenAPIClient()
    try:
        data = await client.request("POST", "/v1/logic/score", json={"text": text})
    finally:
        await client.close()

    regime = data.get("regime", "moderate")
    mapping = _REGIME_MODEL_MAP.get(regime, _REGIME_MODEL_MAP["moderate"])

    result = {
        "recommended_model": mapping["model"],
        "regime": regime,
        "estimated_savings_pct": mapping["savings_pct"],
        "reasoning": mapping["reasoning"],
        "boost_factor": data.get("boost_factor"),
        "recommended_tokens": data.get("recommended_tokens"),
        "tokens_used": data.get("tokens_used"),
        "tokens_remaining": data.get("tokens_remaining"),
    }

    return [TextContent(type="text", text=json.dumps(result, indent=2))]


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    """Run the Kongen MCP server over stdio."""
    # Validate API key early so the user gets a clear error on startup
    if not os.environ.get("KONGEN_API_KEY"):
        print(
            "Error: KONGEN_API_KEY environment variable is required.\n"
            "Set it in your MCP config or export it:\n"
            "  export KONGEN_API_KEY=kl_live_...\n"
            "\n"
            "Get your API key at https://kongenlabs.life",
            file=sys.stderr,
        )
        sys.exit(1)

    import asyncio

    asyncio.run(_run_server())


async def _run_server() -> None:
    """Start the MCP server with stdio transport."""
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options(),
        )


if __name__ == "__main__":
    main()
