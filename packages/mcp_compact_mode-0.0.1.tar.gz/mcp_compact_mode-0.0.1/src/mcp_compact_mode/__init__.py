"""MCP Compact Mode - Reduce MCP tool sprawl by summarizing schemas and routing calls through a single tool."""

__version__ = "0.0.1"
