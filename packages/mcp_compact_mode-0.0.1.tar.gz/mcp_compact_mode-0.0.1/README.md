# mcp-compact-mode

Reduce MCP tool sprawl by summarizing schemas and routing calls through a single tool.

Python version of [mcp-compact-mode](https://github.com/nicobailon/mcp-compact-mode). Coming soon.

## Installation

```bash
pip install mcp-compact-mode
```
