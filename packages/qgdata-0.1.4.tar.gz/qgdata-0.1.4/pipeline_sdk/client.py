"""Backward-compatible re-exports for qgdata.client."""

from qgdata.client import *  # noqa: F403
