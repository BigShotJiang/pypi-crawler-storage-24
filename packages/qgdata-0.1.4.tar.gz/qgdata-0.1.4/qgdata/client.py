from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any
from urllib.parse import urljoin

import pandas as pd
import requests

DEFAULT_BASE_URL = "http://api.quantgo.com.cn/api"
DEFAULT_QUERY_ENDPOINT = "/api/v1/query"
DEFAULT_APIS_ENDPOINT = "/api/v1/apis"
_GLOBAL_TOKEN: str = ""
_SUPPORTED_SORT = {"asc", "desc"}


class PipelineSDKError(RuntimeError):
    """HTTP SDK error raised for request failures and API errors."""

    def __init__(self, message: str, code: int | str | None = None, detail: Any = None) -> None:
        super().__init__(message)
        self.code = code
        self.detail = detail


@dataclass(frozen=True)
class SDKEndpoints:
    query: str = DEFAULT_QUERY_ENDPOINT
    apis: str = DEFAULT_APIS_ENDPOINT


def set_token(token: str) -> None:
    """Compatibility API with Tushare style usage."""
    global _GLOBAL_TOKEN  # noqa: PLW0603
    _GLOBAL_TOKEN = str(token or "").strip()


def pro_api(
    token: str | None = None,
    *,
    timeout: float = 30.0,
    query_endpoint: str = DEFAULT_QUERY_ENDPOINT,
    apis_endpoint: str = DEFAULT_APIS_ENDPOINT,
    default_limit: int = 5000,
    extra_headers: dict[str, str] | None = None,
) -> "PipelineProClient":
    """
    Return an HTTP-based Tushare-like client.

    The remote service should expose:
    - POST {DEFAULT_BASE_URL}{query_endpoint}
    - GET  {DEFAULT_BASE_URL}{apis_endpoint} (optional, for list_apis)
    """
    effective_token = str(token or _GLOBAL_TOKEN or os.environ.get("QGDATA_TOKEN", "") or "").strip()
    return PipelineProClient(
        token=effective_token,
        base_url=DEFAULT_BASE_URL,
        timeout=timeout,
        endpoints=SDKEndpoints(query=query_endpoint, apis=apis_endpoint),
        default_limit=default_limit,
        extra_headers=extra_headers or {},
    )


class PipelineProClient:
    """Tushare-like client over HTTP APIs."""

    def __init__(
        self,
        *,
        token: str,
        base_url: str,
        timeout: float,
        endpoints: SDKEndpoints,
        default_limit: int = 5000,
        extra_headers: dict[str, str] | None = None,
    ) -> None:
        self.token = str(token or "").strip()
        self.base_url = _normalize_base_url(base_url)
        self.timeout = float(timeout)
        self.endpoints = endpoints
        self.default_limit = max(1, int(default_limit))
        self.session = requests.Session()
        self.extra_headers = dict(extra_headers or {})

    def __getattr__(self, name: str) -> Any:
        if name.startswith("_"):
            raise AttributeError(name)
        return lambda **kwargs: self.query(name, **kwargs)

    def list_apis(self, enabled_only: bool = True) -> list[str]:
        params = {"enabled_only": str(bool(enabled_only)).lower()}
        payload = self._request("GET", self.endpoints.apis, params=params)

        if isinstance(payload, list):
            return sorted(str(v) for v in payload)
        if isinstance(payload, dict):
            apis = payload.get("apis", payload.get("data", []))
            if isinstance(apis, list):
                return sorted(str(v) for v in apis)
        raise PipelineSDKError("invalid list_apis response format", detail=payload)

    def query(self, api_name: str, **kwargs: Any) -> pd.DataFrame:
        fields_arg = kwargs.pop("fields", None)
        limit = int(kwargs.pop("limit", self.default_limit) or self.default_limit)
        offset = int(kwargs.pop("offset", 0) or 0)
        order_by = kwargs.pop("order_by", None)
        sort = str(kwargs.pop("sort", "desc")).strip().lower() or "desc"
        if sort not in _SUPPORTED_SORT:
            raise ValueError("sort must be 'asc' or 'desc'")
        if limit <= 0:
            raise ValueError("limit must be > 0")
        if offset < 0:
            raise ValueError("offset must be >= 0")

        payload: dict[str, Any] = {
            "api_name": str(api_name).strip(),
            "params": kwargs,
            "limit": limit,
            "offset": offset,
            "sort": sort,
        }
        if fields_arg not in (None, ""):
            payload["fields"] = fields_arg
        if order_by not in (None, ""):
            payload["order_by"] = order_by

        data = self._request("POST", self.endpoints.query, json=payload)
        rows, columns = _extract_rows_and_columns(data)
        if columns:
            return pd.DataFrame(rows, columns=columns)
        return pd.DataFrame(rows)

    def _request(
        self,
        method: str,
        endpoint: str,
        *,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
    ) -> Any:
        url = urljoin(self.base_url + "/", endpoint.lstrip("/"))
        headers = {
            "Accept": "application/json",
            **self.extra_headers,
        }
        if self.token:
            headers["X-Token"] = self.token

        try:
            resp = self.session.request(
                method=method,
                url=url,
                params=params,
                json=json,
                headers=headers,
                timeout=self.timeout,
            )
        except requests.RequestException as exc:
            raise PipelineSDKError(f"http request failed: {exc}") from exc

        try:
            body = resp.json()
        except ValueError:
            body = None

        if resp.status_code >= 400:
            msg = _extract_error_message(body) or f"http {resp.status_code}"
            raise PipelineSDKError(msg, code=resp.status_code, detail=body)

        if isinstance(body, dict):
            if not _is_success(body):
                msg = _extract_error_message(body) or "api request failed"
                raise PipelineSDKError(msg, code=body.get("code"), detail=body)
            if "data" in body:
                return body["data"]
        return body


def _normalize_base_url(base_url: str) -> str:
    value = str(base_url or "").strip().rstrip("/")
    if not value:
        raise ValueError("base_url is required")
    if not (value.startswith("http://") or value.startswith("https://")):
        raise ValueError("base_url must start with http:// or https://")
    return value


def _is_success(payload: dict[str, Any]) -> bool:
    if "success" in payload:
        return bool(payload["success"])
    if "code" in payload:
        return payload["code"] in (0, "0", 200, "200")
    return True


def _extract_error_message(payload: Any) -> str:
    if not isinstance(payload, dict):
        return ""
    for key in ("message", "msg", "error", "detail"):
        val = payload.get(key)
        if isinstance(val, str) and val.strip():
            return val.strip()
    return ""


def _extract_rows_and_columns(data: Any) -> tuple[list[dict[str, Any]], list[str] | None]:
    if data is None:
        return [], None

    if isinstance(data, list):
        if not data:
            return [], None
        if all(isinstance(item, dict) for item in data):
            return [dict(item) for item in data], None
        return [], None

    if isinstance(data, dict):
        # Format A: {"rows":[{...}], "columns":[...]}
        if isinstance(data.get("rows"), list):
            rows = data.get("rows", [])
            cols = data.get("columns")
            if isinstance(cols, list):
                return [dict(item) for item in rows if isinstance(item, dict)], [str(c) for c in cols]
            return [dict(item) for item in rows if isinstance(item, dict)], None

        # Format B: {"items":[{...}], "fields":[...]} or {"data":[...]}
        for rows_key, cols_key in (("items", "fields"), ("data", "columns")):
            rows = data.get(rows_key)
            if isinstance(rows, list):
                cols = data.get(cols_key)
                if isinstance(cols, list):
                    return [dict(item) for item in rows if isinstance(item, dict)], [str(c) for c in cols]
                return [dict(item) for item in rows if isinstance(item, dict)], None

    raise PipelineSDKError("invalid query response format", detail=data)
