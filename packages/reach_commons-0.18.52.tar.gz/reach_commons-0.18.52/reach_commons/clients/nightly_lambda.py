import os

import requests


class NightlyLambdaClient:
    def __init__(self, environment=None):
        self.environment = environment or os.environ.get("ENV", "Staging")

    @property
    def base_url(self):
        return os.environ.get("NIGHTLY_LAMBDA_URL")

    @property
    def gateway_headers(self):
        auth_token = {
            "Staging": "Bearer 6c6adc18-22a9-929f-648d-786eb20ebcf4",
            "Prod": "Bearer a57a82c0-0493-563b-ba1d-6c63c201ce20",
        }.get(self.environment)
        return {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": auth_token,
        }

    def meevo_reactivate(self, business_id: int):
        return requests.post(
            self.base_url,
            headers=self.gateway_headers,
            json={
                "event": "onboard",
                "override_status": True,
                "business_ids": [business_id],
            },
            timeout=30,
        )
