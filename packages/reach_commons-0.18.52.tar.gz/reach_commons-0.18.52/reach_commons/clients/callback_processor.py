import os

import requests


class CallbackProcessorClient:
    def __init__(self, environment=None):
        self.environment = environment or os.environ.get("ENV", "Staging")

    @property
    def base_url(self):
        return os.environ.get("CALLBACK_PROCESSOR_URL")

    @property
    def gateway_headers(self):
        auth_token = {
            "Staging": "Bearer 6c6adc18-22a9-929f-648d-786eb20ebcf4",
            "Prod": "Bearer a57a82c0-0493-563b-ba1d-6c63c201ce20",
        }.get(self.environment)
        return {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": auth_token,
        }

    def meevo_soft_disable(self, business_id: int):
        return requests.post(
            f"{self.base_url}/callbacks/internal/meevo/soft-disable",
            headers=self.gateway_headers,
            json={"business_id": business_id},
            timeout=30,
        )
