(
    42,
    3.14,
    True,
    False,
    "hello \"world\"",
)
