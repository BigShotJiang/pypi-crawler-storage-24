# Middleware for various frameworks
