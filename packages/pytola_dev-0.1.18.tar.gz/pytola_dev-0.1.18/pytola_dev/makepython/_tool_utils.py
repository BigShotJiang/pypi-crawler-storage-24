"""Shared utilities and constants for MakePython."""

import sys
from pathlib import Path
from typing import Final

# Platform detection
IS_WINDOWS: Final[bool] = sys.platform == "win32"

# File and directory constants
CONFIG_DIR_NAME: Final[str] = ".pytola"
CONFIG_FILE_NAME: Final[str] = "makepython.json"
PYPROJECT_FILE_NAME: Final[str] = "pyproject.toml"

# Default constants
DEFAULT_TIMEOUT_SECONDS: Final[int] = 300
DEFAULT_MAX_RETRIES: Final[int] = 3
DEFAULT_ENCODING: Final[str] = "utf-8"
DEFAULT_SHELL_CONFIG: Final[str] = ".bashrc"
DEFAULT_CACHE_SIZE: Final[int] = 100
DEFAULT_CACHE_EXPIRY: Final[int] = 300  # 5 minutes

# Logging setup
LOG_FORMAT: Final[str] = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
LOG_DATE_FORMAT: Final[str] = "%Y-%m-%d %H:%M:%S"

# File paths
CURRENT_WORKING_DIR: Final[Path] = Path.cwd()
CONFIG_FILE: Final[Path] = Path.home() / CONFIG_DIR_NAME / CONFIG_FILE_NAME
