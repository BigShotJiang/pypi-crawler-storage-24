"""性能分析数据模型定义."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class CallerInfo:
    """调用者信息.

    Attributes
    ----------
    filename (str): 文件名.
    lineno (int): 行号.
    func_name (str): 函数名.
    ncalls (str): 调用次数.
    tottime (float): 自身耗时.
    cumtime (float): 累计耗时.
    """

    filename: str
    lineno: int
    func_name: str
    ncalls: str
    tottime: float
    cumtime: float


@dataclass
class CalleeInfo:
    """被调用者信息.

    Attributes.
    ----------
    filename (str): 文件名.
    lineno (int): 行号.
    func_name (str): 函数名.
    ncalls (str): 调用次数.
    tottime (float): 自身耗时.
    cumtime (float): 累计耗时.
    """

    filename: str
    lineno: int
    func_name: str
    ncalls: str
    tottime: float
    cumtime: float


@dataclass
class FunctionStat:
    """单个函数的性能统计数据.

    Attributes
    ----------
    filename (str): 文件名.
    lineno (int): 行号.
    func_name (str): 函数名.
    ncalls (str): 调用次数.
    tottime (float): 自身耗时.
    cumtime (float): 累计耗时.
    tottime_percall (float): 每次调用的自身耗时.
    cumtime_percall (float): 每次调用的累计耗时.
    callers (list[CallerInfo]): 调用者信息.
    callees (list[CalleeInfo]): 被调用者信息.
    origin (str): 来源.
    """

    filename: str
    lineno: int
    func_name: str
    ncalls: str
    tottime: float
    cumtime: float
    tottime_percall: float
    cumtime_percall: float
    callers: list[CallerInfo] = field(default_factory=list)
    callees: list[CalleeInfo] = field(default_factory=list)
    origin: str = ""  # "user", "stdlib", "third_party", "builtin"

    @property
    def full_name(self) -> str:
        """返回函数的完整标识名."""
        return f"{self.filename}:{self.lineno}({self.func_name})"

    @property
    def func_id(self) -> str:
        """返回 HTML 安全的唯一 ID."""
        raw = f"{self.filename}_{self.lineno}_{self.func_name}"
        return "fn_" + "".join(c if c.isalnum() or c == "_" else "_" for c in raw)

    @property
    def display_name(self) -> str:
        """返回适合显示的函数名."""
        if self.filename.startswith("<") or self.filename.startswith("{"):
            return f"{self.filename}:{self.func_name}"
        fname = Path(self.filename).name
        return f"{fname}:{self.lineno} {self.func_name}"


@dataclass
class FlameNode:
    """火焰图节点.

    表示调用栈中的一帧, 构成自顶向下的调用树.

    Attributes
    ----------
    name (str): 函数名.
    filename (str): 文件名.
    lineno (int): 行号.
    value (float): 累计耗时.
    self_time (float): 自身耗时.
    origin (str): 来源.
    children (list[FlameNode]): 子节点.
    """

    name: str
    filename: str
    lineno: int
    value: float  # cumtime, 该调用路径上的累计耗时
    self_time: float  # tottime, 该调用路径上的自身耗时
    origin: str = ""
    children: list[FlameNode] = field(default_factory=list)


@dataclass
class ModuleStat:
    """模块级聚合统计.

    Attributes
    ----------
    filename (str): 文件名.
    display_name (str): 显示名.
    total_tottime (float): 总自身耗时.
    total_cumtime (float): 总累计耗时.
    call_count (int): 调用次数.
    func_count (int): 函数数.
    origin (str): 来源.
    functions (list[FunctionStat]): 函数统计信息.
    """

    filename: str
    display_name: str
    total_tottime: float
    total_cumtime: float
    call_count: int
    func_count: int
    origin: str = ""
    functions: list[FunctionStat] = field(default_factory=list)


@dataclass
class TimeSlice:
    """时间分布数据切片, 用于柱状图可视化.

    Attributes
    ----------
    func_name (str): 函数名.
    display_name (str): 显示名.
    tottime (float): 自身耗时.
    cumtime (float): 累计耗时.
    percentage (float): 占总耗时的百分比.
    """

    func_name: str
    display_name: str
    tottime: float
    cumtime: float
    percentage: float


@dataclass
class ProfileReport:
    """完整的性能分析报告数据.

    Attributes
    ----------
    total_calls (int): 总调用次数.
    primitive_calls (int): 原始调用次数.
    total_time (float): 总耗时.
    unique_functions (int): 唯一函数数.
    function_stats (list[FunctionStat]): 函数统计信息.
    hotspots (list[FunctionStat]): 热点函数信息.
    time_distribution (list[TimeSlice]): 时间分布信息.
    flame_roots (list[FlameNode]): 火焰图根节点.
    module_stats (list[ModuleStat]): 模块统计信息.
    generated_at (str): 生成时间.
    target_name (str): 目标名称.
    sort_by (str): 排序依据.
    """

    total_calls: int
    primitive_calls: int
    total_time: float
    unique_functions: int
    function_stats: list[FunctionStat]
    hotspots: list[FunctionStat]
    time_distribution: list[TimeSlice]
    flame_roots: list[FlameNode]
    module_stats: list[ModuleStat]
    generated_at: str
    target_name: str
    sort_by: str


@dataclass
class ProfilerConfig:
    """CLI 配置.

    Attributes
    ----------
    mode (str): 性能分析模式, 可选值有 "run" 和 "load".
    script (Path | None): 脚本文件路径, 仅在模式为 "run" 时有效.
    module (str | None): 模块名称, 仅在模式为 "run" 时有效.
    script_args (list[str]): 脚本参数, 仅在模式为 "run" 时有效.
    profile_file (Path | None): 性能分析文件路径, 仅在模式为 "load" 时有效.
    output (Path): 输出文件路径.
    open_browser (bool): 是否自动打开浏览器.
    top_n (int): 顶部 N 个函数.
    sort_by (str): 排序依据.
    """

    mode: str
    script: Path | None = None
    module: str | None = None
    script_args: list[str] = field(default_factory=list)
    profile_file: Path | None = None
    output: Path = field(default_factory=lambda: Path("profile_report.html"))
    open_browser: bool = False
    top_n: int = 50
    sort_by: str = "tottime"
