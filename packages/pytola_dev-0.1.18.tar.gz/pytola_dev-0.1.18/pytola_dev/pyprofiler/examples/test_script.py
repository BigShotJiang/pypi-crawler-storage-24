"""测试用脚本 - 用于验证 pyprofiler 工具."""

from __future__ import annotations

import random


def fibonacci(n: int) -> int:
    """计算斐波那契数列的第 n 个数.

    Returns
    -------
        int: 斐波那契数列的第 n 个数
    """
    if n <= 1:
        return n
    return fibonacci(n - 1) + fibonacci(n - 2)


def bubble_sort(arr: list[int]) -> list[int]:
    """对数组进行冒泡排序.

    Parameters
    ----------
    arr : list
        待排序的数组

    Returns
    -------
    list
        排序后的数组
    """
    n = len(arr)
    for i in range(n):
        for j in range(n - i - 1):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
    return arr


def string_operations() -> str:
    """进行字符串操作.

    Returns
    -------
    str
        操作结果
    """
    result = ""
    for i in range(1000):
        result += str(i)
    return result


def list_comprehension() -> list[int]:
    """生成一个包含 10000 个平方数的列表.

    Returns
    -------
    list
        包含 10000 个平方数的列表
    """
    return [x**2 for x in range(10000)]


def dict_operations() -> dict[str, int]:
    """进行字典操作.

    Returns
    -------
    dict
        操作结果
    """
    d = {}
    for i in range(5000):
        d[str(i)] = i * 2
    return d


def main() -> None:
    """主函数."""
    fibonacci(25)

    arr = [random.randint(0, 1000) for _ in range(500)]
    bubble_sort(arr)

    string_operations()

    list_comprehension()

    dict_operations()


if __name__ == "__main__":
    main()
