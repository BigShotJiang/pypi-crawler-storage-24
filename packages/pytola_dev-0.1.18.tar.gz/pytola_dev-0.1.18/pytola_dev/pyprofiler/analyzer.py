"""性能数据分析引擎.

从 pstats.Stats 对象中提取、转换、分析数据, 生成结构化的 ProfileReport。
"""

from __future__ import annotations

import datetime
import os
import pstats
import sysconfig
from collections import defaultdict
from dataclasses import dataclass
from itertools import starmap
from pathlib import Path
from typing import Tuple

from .models import (
    CalleeInfo,
    CallerInfo,
    FlameNode,
    FunctionStat,
    ModuleStat,
    ProfileReport,
    TimeSlice,
)

_FuncKey = Tuple[str, int, str]

# 预先计算标准库和 site-packages 路径, 用于来源分类
_STDLIB_PATH: str | None = None
_SITE_PACKAGES_PATH: str | None = None


def _get_stdlib_path() -> str | None:
    global _STDLIB_PATH  # noqa: PLW0603
    if _STDLIB_PATH is None:
        p = sysconfig.get_path("stdlib")
        _STDLIB_PATH = os.path.normpath(p) if p else ""
    return _STDLIB_PATH or None


def _get_site_packages_path() -> str | None:
    global _SITE_PACKAGES_PATH  # noqa: PLW0603
    if _SITE_PACKAGES_PATH is None:
        p = sysconfig.get_path("purelib")
        _SITE_PACKAGES_PATH = os.path.normpath(p) if p else ""
    return _SITE_PACKAGES_PATH or None


def _classify_origin(filename: str) -> str:
    """根据文件路径分类代码来源.

    Returns
    -------
    str
        "user", "stdlib", "third_party", "builtin"
    """
    if filename.startswith(("<", "{", "~")):
        return "builtin"

    try:
        filepath = os.path.normpath(Path(filename).resolve())
    except (ValueError, OSError):
        return "builtin"

    stdlib = _get_stdlib_path()
    if stdlib and filepath.startswith(stdlib):
        return "stdlib"

    site_pkg = _get_site_packages_path()
    if site_pkg and filepath.startswith(site_pkg):
        return "third_party"

    if "site-packages" in filepath or "dist-packages" in filepath:
        return "third_party"

    return "user"


def _format_ncalls(nc: int, cc: int) -> str:
    """将原始调用次数格式化为字符串.

    Parameters
    ----------
    nc : int
        总调用次数
    cc : int
        原始调用次数

    Returns
    -------
    str
        格式化后的调用次数字符串
    """
    if nc != cc:
        return f"{nc}/{cc}"
    return str(nc)


@dataclass
class AnalyzeConfig:
    """分析配置参数."""

    top_n: int = 50
    sort_by: str = "tottime"
    target_name: str = ""


class ProfileAnalyzer:
    """性能数据分析引擎."""

    @staticmethod
    def analyze(
        stats: pstats.Stats,
        config: AnalyzeConfig | None = None,
    ) -> ProfileReport:
        """分析 pstats.Stats 数据, 生成 ProfileReport.

        Parameters
        ----------
        stats : pstats.Stats
            pstats 统计对象
        config : AnalyzeConfig | None
            分析配置, 默认使用 AnalyzeConfig() 的默认值

        Returns
        -------
        ProfileReport
            性能分析报告
        """
        if config is None:
            config = AnalyzeConfig()

        return ProfileAnalyzer._do_analyze(stats, config)

    @staticmethod
    def _do_analyze(stats: pstats.Stats, config: AnalyzeConfig) -> ProfileReport:
        """执行实际分析逻辑.

        Parameters
        ----------
        stats : pstats.Stats
            pstats 统计对象
        config : AnalyzeConfig
            分析配置

        Returns
        -------
        ProfileReport
            性能分析报告
        """
        raw_stats: dict = stats.stats  # type: ignore[attr-defined]

        # 计算总体统计
        total_calls, primitive_calls, total_time = _calc_totals(raw_stats)

        # 构建函数统计
        stats.calc_callees()
        all_callees: dict = stats.all_callees  # type: ignore[attr-defined]
        func_stats, func_map = _build_function_stats(raw_stats)
        _populate_call_relations(func_map, all_callees)

        # 来源分类
        for fs in func_stats:
            fs.origin = _classify_origin(fs.filename)

        _sort_stats(func_stats, config.sort_by)

        # 构建各类分析结果
        hotspots = _get_hotspots(func_stats, config.top_n)
        time_distribution = _build_time_distribution(func_stats, total_time, max_items=20)
        flame_roots = _build_flame_graph(raw_stats, all_callees, total_time)
        module_stats = _build_module_stats(func_stats)

        return ProfileReport(
            total_calls=total_calls,
            primitive_calls=primitive_calls,
            total_time=total_time,
            unique_functions=len(func_stats),
            function_stats=func_stats,
            hotspots=hotspots,
            time_distribution=time_distribution,
            flame_roots=flame_roots,
            module_stats=module_stats,
            generated_at=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),  # noqa: DTZ005
            target_name=config.target_name,
            sort_by=config.sort_by,
        )


# ---------------------------------------------------------------------------
# 热点分析
# ---------------------------------------------------------------------------


def _get_hotspots(func_stats: list[FunctionStat], top_n: int) -> list[FunctionStat]:
    """获取性能热点函数.

    Returns
    -------
    list[FunctionStat]
        性能热点函数列表
    """
    return sorted(func_stats, key=lambda s: s.tottime, reverse=True)[:top_n]


# ---------------------------------------------------------------------------
# 基础统计
# ---------------------------------------------------------------------------


def _calc_totals(raw_stats: dict) -> tuple[int, int, float]:
    total_calls = 0
    primitive_calls = 0
    total_time = 0.0
    for cc, nc, tt, _, _ in raw_stats.values():
        total_calls += nc
        primitive_calls += cc
        total_time += tt
    return total_calls, primitive_calls, total_time


# ---------------------------------------------------------------------------
# 函数统计构建
# ---------------------------------------------------------------------------


def _extract_call_data(data: object) -> tuple[int, int, float, float]:
    if isinstance(data, tuple) and len(data) >= 4:  # noqa: PLR2004
        return data[0], data[1], data[2], data[3]
    nc = data if isinstance(data, int) else 0
    return nc, nc, 0.0, 0.0


def _build_caller_info(caller_key: _FuncKey, caller_data: object) -> CallerInfo:
    """从调用者数据构建 CallerInfo 对象.

    Parameters
    ----------
    caller_key : _FuncKey
        调用者标识 (filename, lineno, func_name)
    caller_data : object
        调用者数据

    Returns
    -------
    CallerInfo
        构建的 CallerInfo 对象
    """
    c_filename, c_lineno, c_func_name = caller_key
    c_nc, c_cc, c_tt, c_ct = _extract_call_data(caller_data)
    return CallerInfo(
        filename=c_filename,
        lineno=c_lineno,
        func_name=c_func_name,
        ncalls=_format_ncalls(c_nc, c_cc),
        tottime=c_tt,
        cumtime=c_ct,
    )


def _build_function_stats(
    raw_stats: dict,
) -> tuple[list[FunctionStat], dict[_FuncKey, FunctionStat]]:
    func_stats: list[FunctionStat] = []
    func_map: dict[_FuncKey, FunctionStat] = {}

    for key, stat_tuple in raw_stats.items():
        cc, nc, tt, ct, callers = stat_tuple
        filename, lineno, func_name = key
        ncalls_str = _format_ncalls(nc, cc)
        tottime_percall = tt / nc if nc > 0 else 0.0
        cumtime_percall = ct / cc if cc > 0 else 0.0

        caller_list = list(starmap(_build_caller_info, callers.items()))

        fs = FunctionStat(
            filename=filename,
            lineno=lineno,
            func_name=func_name,
            ncalls=ncalls_str,
            tottime=tt,
            cumtime=ct,
            tottime_percall=tottime_percall,
            cumtime_percall=cumtime_percall,
            callers=caller_list,
        )
        func_stats.append(fs)
        func_map[key] = fs

    return func_stats, func_map


def _get_callee_info(callee_key: _FuncKey, callee_data: object) -> CalleeInfo:
    """从被调用者数据构建 CalleeInfo 对象.

    Parameters
    ----------
    callee_key : _FuncKey
        被调用者标识 (filename, lineno, func_name)
    callee_data : object
        被调用者数据

    Returns
    -------
    CalleeInfo
        构建的 CalleeInfo 对象
    """
    c_filename, c_lineno, c_func_name = callee_key
    c_nc, c_cc, c_tt, c_ct = _extract_call_data(callee_data)
    return CalleeInfo(
        filename=c_filename,
        lineno=c_lineno,
        func_name=c_func_name,
        ncalls=_format_ncalls(c_nc, c_cc),
        tottime=c_tt,
        cumtime=c_ct,
    )


def _populate_call_relations(
    func_map: dict[_FuncKey, FunctionStat],
    all_callees: dict,
) -> None:
    for key, callees_dict in all_callees.items():
        fs = func_map.get(key)
        if fs is None:
            continue
        fs.callees = list(starmap(_get_callee_info, callees_dict.items()))


def _sort_stats(func_stats: list[FunctionStat], sort_by: str) -> None:
    if sort_by == "cumtime":
        func_stats.sort(key=lambda s: s.cumtime, reverse=True)
    elif sort_by == "calls":
        func_stats.sort(key=lambda s: _parse_ncalls_for_sort(s.ncalls), reverse=True)
    else:
        func_stats.sort(key=lambda s: s.tottime, reverse=True)


def _parse_ncalls_for_sort(ncalls: str) -> int:
    if "/" in ncalls:
        return int(ncalls.split("/", maxsplit=1)[0])
    return int(ncalls)


# ---------------------------------------------------------------------------
# 时间分布
# ---------------------------------------------------------------------------


def _build_time_distribution(
    func_stats: list[FunctionStat],
    total_time: float,
    max_items: int = 20,
) -> list[TimeSlice]:
    if total_time <= 0:
        return []

    sorted_by_time = sorted(func_stats, key=lambda s: s.tottime, reverse=True)
    top_funcs = sorted_by_time[:max_items]

    slices: list[TimeSlice] = []
    shown_time = 0.0
    for fs in top_funcs:
        if fs.tottime <= 0:
            continue
        pct = (fs.tottime / total_time) * 100
        slices.append(
            TimeSlice(
                func_name=fs.full_name,
                display_name=_truncate(fs.display_name, 40),
                tottime=fs.tottime,
                cumtime=fs.cumtime,
                percentage=pct,
            ),
        )
        shown_time += fs.tottime

    other_time = total_time - shown_time
    if other_time > 0 and slices:
        pct = (other_time / total_time) * 100
        slices.append(
            TimeSlice(
                func_name="<其他>",
                display_name="其他",
                tottime=other_time,
                cumtime=0.0,
                percentage=pct,
            ),
        )
    return slices


def _truncate(name: str, max_len: int = 40) -> str:
    if len(name) <= max_len:
        return name
    return name[: max_len - 3] + "..."


# ---------------------------------------------------------------------------
# 火焰图构建
# ---------------------------------------------------------------------------


@dataclass
class FlameGraphContext:
    """火焰图构建上下文."""

    raw_stats: dict
    all_callees: dict
    total_time: float


def _build_flame_graph(
    raw_stats: dict,
    all_callees: dict,
    total_time: float,
) -> list[FlameNode]:
    """从 pstats 数据构建火焰图树.

    从根函数出发, 沿 callees 递归构建树.
    每条边使用 caller-specific 的耗时数据, 确保层级时间分配准确.

    Returns
    -------
    list[FlameNode]
        火焰图节点列表
    """
    if not raw_stats:
        return []

    # 找出根函数, 不被任何其他函数调用的函数
    all_funcs = set(raw_stats.keys())
    called_funcs: set[_FuncKey] = set()
    for callees_dict in all_callees.values():
        called_funcs.update(callees_dict)

    roots = all_funcs - called_funcs

    # 如果没有找到根函数, 可能存在循环, 取 cumtime 最大的函数
    if not roots:
        roots = set(
            sorted(raw_stats.keys(), key=lambda k: raw_stats[k][3], reverse=True)[:3],
        )

    ctx = FlameGraphContext(raw_stats=raw_stats, all_callees=all_callees, total_time=total_time)
    flame_roots: list[FlameNode] = []
    for root_key in sorted(roots, key=lambda k: raw_stats.get(k, (0, 0, 0, 0, {}))[3], reverse=True):
        node = _build_flame_node(ctx, root_key, visited=set())
        if node is not None and node.value > 0:
            flame_roots.append(node)

    # 只保留有意义的根节点, cumtime > 总时间的 0.1%
    if total_time > 0:
        threshold = total_time * 0.001
        flame_roots = [r for r in flame_roots if r.value >= threshold]

    # 按 cumtime 降序排列
    flame_roots.sort(key=lambda n: n.value, reverse=True)
    return flame_roots[:10]  # 最多 10 个根


def _build_flame_children(
    ctx: FlameGraphContext,
    key: _FuncKey,
    visited: set[_FuncKey],
) -> list[FlameNode]:
    """递归构建火焰图子节点.

    Parameters
    ----------
    ctx : FlameGraphContext
        火焰图构建上下文
    key : _FuncKey
        函数标识 (filename, lineno, func_name)
    visited : set
        已访问节点集合, 防止循环

    Returns
    -------
    list[FlameNode]
        火焰图子节点列表
    """
    children: list[FlameNode] = []
    callees_dict = ctx.all_callees.get(key, {})

    for callee_key, callee_data in callees_dict.items():
        _c_nc, _c_cc, c_tt, c_ct = _extract_call_data(callee_data)
        child = _build_flame_node(
            ctx,
            callee_key,
            visited,
            override_ct=c_ct,
            override_tt=c_tt,
        )
        if child is not None and child.value > 0:
            children.append(child)

    children.sort(key=lambda c: c.value, reverse=True)
    return children


def _build_flame_node(
    ctx: FlameGraphContext,
    key: _FuncKey,
    visited: set[_FuncKey],
    *,
    override_ct: float | None = None,
    override_tt: float | None = None,
) -> FlameNode | None:
    """递归构建火焰图节点.

    Parameters
    ----------
    key : _FuncKey
        函数标识 (filename, lineno, func_name)
    ctx : FlameGraphContext
        火焰图构建上下文
    visited : set
        已访问节点集合, 防止循环
    override_ct : float | None
        覆盖的 cumtime, 从父节点 callee 数据获取
    override_tt : float | None
        覆盖的 tottime, 从父节点 callee 数据获取

    Returns
    -------
    FlameNode | None
        火焰图节点或 None
    """
    if key in visited:
        return None

    visited |= {key}  # 不修改原集合, 每条路径独立

    entry = ctx.raw_stats.get(key)
    if entry is None:
        return None

    _cc, _nc, tt, ct, _callers = entry

    # 如果父节点提供了 caller-specific 数据, 使用它
    node_ct = override_ct if override_ct is not None else ct
    node_tt = override_tt if override_tt is not None else tt

    filename, lineno, func_name = key
    origin = _classify_origin(filename)
    children = _build_flame_children(ctx, key, visited)
    return FlameNode(
        name=func_name,
        filename=filename,
        lineno=lineno,
        value=node_ct,
        self_time=node_tt,
        origin=origin,
        children=children,
    )


# ---------------------------------------------------------------------------
# 模块聚合
# ---------------------------------------------------------------------------


def _build_module_stats(func_stats: list[FunctionStat]) -> list[ModuleStat]:
    """按文件聚合函数统计, 生成模块级视图.

    Parameters
    ----------
    func_stats : list[FunctionStat]
        函数统计信息列表

    Returns
    -------
    list[ModuleStat]
        模块统计信息列表
    """
    groups: dict[str, list[FunctionStat]] = defaultdict(list)
    for fs in func_stats:
        groups[fs.filename].append(fs)

    module_stats: list[ModuleStat] = []
    for filename, funcs in groups.items():
        total_tottime = sum(f.tottime for f in funcs)
        total_cumtime = max((f.cumtime for f in funcs), default=0.0)
        call_count = sum(_parse_ncalls_for_sort(f.ncalls) for f in funcs)
        origin = funcs[0].origin if funcs else "user"

        # 生成显示名
        display = filename if filename.startswith(("<", "{", "~")) else Path(filename).name

        # 排序模块内函数
        sorted_funcs = sorted(funcs, key=lambda f: f.tottime, reverse=True)

        module_stats.append(
            ModuleStat(
                filename=filename,
                display_name=display,
                total_tottime=total_tottime,
                total_cumtime=total_cumtime,
                call_count=call_count,
                func_count=len(funcs),
                origin=origin,
                functions=sorted_funcs,
            ),
        )

    module_stats.sort(key=lambda m: m.total_tottime, reverse=True)
    return module_stats
