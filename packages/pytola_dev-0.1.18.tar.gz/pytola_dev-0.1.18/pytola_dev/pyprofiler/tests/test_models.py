"""Tests for the models module."""

from pathlib import Path

from pytola_dev.pyprofiler.models import (
    CalleeInfo,
    CallerInfo,
    FlameNode,
    FunctionStat,
    ModuleStat,
    ProfilerConfig,
    ProfileReport,
    TimeSlice,
)


class TestCallerInfo:
    """Test cases for CallerInfo dataclass."""

    def test_caller_info_creation(self) -> None:
        """Test basic CallerInfo creation."""
        caller = CallerInfo(
            filename="/path/to/file.py",
            lineno=10,
            func_name="test_func",
            ncalls="100",
            tottime=0.5,
            cumtime=1.2,
        )
        assert caller.filename == "/path/to/file.py"
        assert caller.lineno == 10
        assert caller.func_name == "test_func"
        assert caller.ncalls == "100"
        assert caller.tottime == 0.5
        assert caller.cumtime == 1.2


class TestCalleeInfo:
    """Test cases for CalleeInfo dataclass."""

    def test_callee_info_creation(self) -> None:
        """Test basic CalleeInfo creation."""
        callee = CalleeInfo(
            filename="/path/to/module.py",
            lineno=25,
            func_name="helper",
            ncalls="50/5",
            tottime=0.3,
            cumtime=0.8,
        )
        assert callee.filename == "/path/to/module.py"
        assert callee.lineno == 25
        assert callee.func_name == "helper"
        assert callee.ncalls == "50/5"
        assert callee.tottime == 0.3
        assert callee.cumtime == 0.8


class TestFunctionStat:
    """Test cases for FunctionStat dataclass."""

    def test_function_stat_creation(self) -> None:
        """Test basic FunctionStat creation."""
        stat = FunctionStat(
            filename="/path/to/file.py",
            lineno=10,
            func_name="my_func",
            ncalls="100",
            tottime=0.5,
            cumtime=1.2,
            tottime_percall=0.005,
            cumtime_percall=0.012,
        )
        assert stat.filename == "/path/to/file.py"
        assert stat.lineno == 10
        assert stat.func_name == "my_func"
        assert stat.ncalls == "100"
        assert stat.tottime == 0.5
        assert stat.cumtime == 1.2
        assert stat.tottime_percall == 0.005
        assert stat.cumtime_percall == 0.012
        assert stat.callers == []
        assert stat.callees == []
        assert not stat.origin

    def test_full_name_property(self) -> None:
        """Test full_name property returns correct format."""
        stat = FunctionStat(
            filename="/path/to/file.py",
            lineno=42,
            func_name="compute",
            ncalls="10",
            tottime=0.1,
            cumtime=0.5,
            tottime_percall=0.01,
            cumtime_percall=0.05,
        )
        assert stat.full_name == "/path/to/file.py:42(compute)"

    def test_func_id_property(self) -> None:
        """Test func_id property generates valid HTML ID."""
        stat = FunctionStat(
            filename="/path/to/file.py",
            lineno=10,
            func_name="special<func>",
            ncalls="5",
            tottime=0.1,
            cumtime=0.2,
            tottime_percall=0.02,
            cumtime_percall=0.04,
        )
        func_id = stat.func_id
        assert func_id.startswith("fn_")
        # Should only contain alphanumeric and underscore
        assert all(c.isalnum() or c == "_" for c in func_id)
        # Should not contain special chars from original name
        assert "<" not in func_id
        assert ">" not in func_id

    def test_display_name_builtin(self) -> None:
        """Test display_name for built-in functions."""
        stat = FunctionStat(
            filename="<built-in method nt.stat>",
            lineno=0,
            func_name="stat",
            ncalls="10",
            tottime=0.01,
            cumtime=0.05,
            tottime_percall=0.001,
            cumtime_percall=0.005,
        )
        assert "<built-in method nt.stat>" in stat.display_name
        assert "stat" in stat.display_name

    def test_display_name_user_code(self) -> None:
        """Test display_name for user code."""
        stat = FunctionStat(
            filename="/home/user/project/main.py",
            lineno=15,
            func_name="main",
            ncalls="1",
            tottime=0.0,
            cumtime=1.5,
            tottime_percall=0.0,
            cumtime_percall=1.5,
        )
        assert "main.py" in stat.display_name
        assert "15" in stat.display_name
        assert "main" in stat.display_name

    def test_with_callers_and_callees(self) -> None:
        """Test FunctionStat with callers and callees populated."""
        caller = CallerInfo(
            filename="/path/to/caller.py",
            lineno=5,
            func_name="caller_func",
            ncalls="10",
            tottime=0.1,
            cumtime=0.5,
        )
        callee = CalleeInfo(
            filename="/path/to/callee.py",
            lineno=20,
            func_name="callee_func",
            ncalls="50",
            tottime=0.2,
            cumtime=0.3,
        )
        stat = FunctionStat(
            filename="/path/to/file.py",
            lineno=10,
            func_name="my_func",
            ncalls="100",
            tottime=0.5,
            cumtime=1.2,
            tottime_percall=0.005,
            cumtime_percall=0.012,
            callers=[caller],
            callees=[callee],
        )
        assert len(stat.callers) == 1
        assert len(stat.callees) == 1
        assert stat.callers[0].func_name == "caller_func"
        assert stat.callees[0].func_name == "callee_func"


class TestFlameNode:
    """Test cases for FlameNode dataclass."""

    def test_flame_node_creation(self) -> None:
        """Test basic FlameNode creation."""
        node = FlameNode(
            name="compute",
            filename="/path/to/file.py",
            lineno=10,
            value=1.5,
            self_time=0.5,
            origin="user",
        )
        assert node.name == "compute"
        assert node.filename == "/path/to/file.py"
        assert node.lineno == 10
        assert node.value == 1.5
        assert node.self_time == 0.5
        assert node.origin == "user"
        assert node.children == []

    def test_flame_node_with_children(self) -> None:
        """Test FlameNode with child nodes."""
        child1 = FlameNode(name="child1", filename="a.py", lineno=1, value=0.5, self_time=0.2)
        child2 = FlameNode(name="child2", filename="b.py", lineno=2, value=0.3, self_time=0.1)
        parent = FlameNode(
            name="parent",
            filename="parent.py",
            lineno=0,
            value=1.0,
            self_time=0.2,
            children=[child1, child2],
        )
        assert len(parent.children) == 2
        assert parent.children[0].name == "child1"
        assert parent.children[1].name == "child2"


class TestModuleStat:
    """Test cases for ModuleStat dataclass."""

    def test_module_stat_creation(self) -> None:
        """Test basic ModuleStat creation."""
        module = ModuleStat(
            filename="/path/to/module.py",
            display_name="module.py",
            total_tottime=1.5,
            total_cumtime=3.0,
            call_count=100,
            func_count=5,
            origin="user",
        )
        assert module.filename == "/path/to/module.py"
        assert module.display_name == "module.py"
        assert module.total_tottime == 1.5
        assert module.total_cumtime == 3.0
        assert module.call_count == 100
        assert module.func_count == 5
        assert module.origin == "user"
        assert module.functions == []

    def test_module_stat_with_functions(self) -> None:
        """Test ModuleStat with function list."""
        func1 = FunctionStat(
            filename="/path/to/module.py",
            lineno=10,
            func_name="func1",
            ncalls="50",
            tottime=0.5,
            cumtime=1.0,
            tottime_percall=0.01,
            cumtime_percall=0.02,
        )
        func2 = FunctionStat(
            filename="/path/to/module.py",
            lineno=20,
            func_name="func2",
            ncalls="30",
            tottime=0.3,
            cumtime=0.6,
            tottime_percall=0.01,
            cumtime_percall=0.02,
        )
        module = ModuleStat(
            filename="/path/to/module.py",
            display_name="module.py",
            total_tottime=0.8,
            total_cumtime=1.6,
            call_count=80,
            func_count=2,
            origin="user",
            functions=[func1, func2],
        )
        assert len(module.functions) == 2
        assert module.functions[0].func_name == "func1"
        assert module.functions[1].func_name == "func2"


class TestTimeSlice:
    """Test cases for TimeSlice dataclass."""

    def test_time_slice_creation(self) -> None:
        """Test basic TimeSlice creation."""
        slice_data = TimeSlice(
            func_name="compute_heavy",
            display_name="compute_heavy",
            tottime=0.8,
            cumtime=1.2,
            percentage=53.33,
        )
        assert slice_data.func_name == "compute_heavy"
        assert slice_data.display_name == "compute_heavy"
        assert slice_data.tottime == 0.8
        assert slice_data.cumtime == 1.2
        assert slice_data.percentage == 53.33


class TestProfileReport:
    """Test cases for ProfileReport dataclass."""

    def test_profile_report_creation(self) -> None:
        """Test basic ProfileReport creation."""
        report = ProfileReport(
            total_calls=1000,
            primitive_calls=500,
            total_time=2.5,
            unique_functions=50,
            function_stats=[],
            hotspots=[],
            time_distribution=[],
            flame_roots=[],
            module_stats=[],
            generated_at="2024-01-01 12:00:00",
            target_name="test_script.py",
            sort_by="tottime",
        )
        assert report.total_calls == 1000
        assert report.primitive_calls == 500
        assert report.total_time == 2.5
        assert report.unique_functions == 50
        assert report.function_stats == []
        assert report.hotspots == []
        assert report.time_distribution == []
        assert report.flame_roots == []
        assert report.module_stats == []
        assert report.generated_at == "2024-01-01 12:00:00"
        assert report.target_name == "test_script.py"
        assert report.sort_by == "tottime"


class TestProfilerConfig:
    """Test cases for ProfilerConfig dataclass."""

    def test_profiler_config_run_mode(self) -> None:
        """Test ProfilerConfig in run mode."""
        config = ProfilerConfig(
            mode="run",
            script=Path("/path/to/script.py"),
            script_args=["arg1", "arg2"],
            output=Path("report.html"),
            open_browser=True,
            top_n=100,
            sort_by="cumtime",
        )
        assert config.mode == "run"
        assert config.script == Path("/path/to/script.py")
        assert config.script_args == ["arg1", "arg2"]
        assert config.output == Path("report.html")
        assert config.open_browser is True
        assert config.top_n == 100
        assert config.sort_by == "cumtime"

    def test_profiler_config_load_mode(self) -> None:
        """Test ProfilerConfig in load mode."""
        config = ProfilerConfig(
            mode="load",
            profile_file=Path("/path/to/profile.prof"),
            output=Path("report.html"),
            open_browser=False,
        )
        assert config.mode == "load"
        assert config.profile_file == Path("/path/to/profile.prof")
        assert config.output == Path("report.html")
        assert config.open_browser is False

    def test_profiler_config_defaults(self) -> None:
        """Test ProfilerConfig default values."""
        config = ProfilerConfig(mode="run", script=Path("script.py"))
        assert config.script_args == []
        assert config.output == Path("profile_report.html")
        assert config.open_browser is False
        assert config.top_n == 50
        assert config.sort_by == "tottime"

    def test_profiler_config_module_mode(self) -> None:
        """Test ProfilerConfig for module execution."""
        config = ProfilerConfig(
            mode="run",
            module="json.tool",
            script_args=["--help"],
        )
        assert config.module == "json.tool"
        assert config.script is None
        assert config.script_args == ["--help"]
