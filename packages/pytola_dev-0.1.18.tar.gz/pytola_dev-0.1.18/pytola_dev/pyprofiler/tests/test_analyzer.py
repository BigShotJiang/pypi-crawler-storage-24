"""Tests for the analyzer module."""

import cProfile
import io
import pstats

import pytest

from pytola_dev.pyprofiler.analyzer import (
    AnalyzeConfig,
    ProfileAnalyzer,
    _build_flame_graph,
    _build_module_stats,
    _build_time_distribution,
    _calc_totals,
    _classify_origin,
    _format_ncalls,
    _get_hotspots,
    _parse_ncalls_for_sort,
)
from pytola_dev.pyprofiler.models import FunctionStat


class TestClassifyOrigin:
    """Test cases for _classify_origin function."""

    def test_builtin_with_angle_brackets(self) -> None:
        """Test built-in methods with angle bracket filenames."""
        assert _classify_origin("<built-in method nt.stat>") == "builtin"
        assert _classify_origin("<built-in method _imp.create_dynamic>") == "builtin"
        assert _classify_origin("<frozen importlib._bootstrap>") == "builtin"

    def test_builtin_with_curly_braces(self) -> None:
        """Test built-in methods with curly brace filenames."""
        assert _classify_origin("{built-in}") == "builtin"

    def test_builtin_with_tilde(self) -> None:
        """Test built-in methods with tilde filenames."""
        assert _classify_origin("~") == "builtin"
        assert _classify_origin("~:method_name") == "builtin"

    def test_invalid_path_returns_builtin(self) -> None:
        """Test that invalid paths are classified as builtin."""
        # Paths that can't be resolved should return builtin
        assert _classify_origin("\x00invalid\x00path") == "builtin"

    def test_stdlib_detection(self) -> None:
        """Test standard library detection."""
        # These should be detected as stdlib based on path
        import sysconfig

        stdlib_path = sysconfig.get_path("stdlib")
        if stdlib_path:
            result = _classify_origin(stdlib_path + "/os.py")
            assert result == "stdlib"

    def test_third_party_detection(self) -> None:
        """Test third-party package detection."""
        # Paths containing site-packages or dist-packages
        assert _classify_origin("/home/user/.venv/lib/python3.8/site-packages/requests/api.py") == "third_party"
        assert _classify_origin("/usr/lib/python3/dist-packages/numpy/core.py") == "third_party"

    def test_user_code_detection(self) -> None:
        """Test user code detection."""
        # Regular paths not in stdlib or site-packages
        assert _classify_origin("/home/user/project/main.py") == "user"
        assert _classify_origin("./script.py") == "user"
        assert _classify_origin("C:\\Users\\dev\\myapp\\app.py") == "user"


class TestFormatNcalls:
    """Test cases for _format_ncalls function."""

    def test_equal_calls(self) -> None:
        """Test when total and primitive calls are equal."""
        assert _format_ncalls(100, 100) == "100"
        assert _format_ncalls(1, 1) == "1"

    def test_different_calls(self) -> None:
        """Test when total and primitive calls differ."""
        assert _format_ncalls(150, 50) == "150/50"
        assert _format_ncalls(1000, 100) == "1000/100"

    def test_zero_calls(self) -> None:
        """Test edge case with zero calls."""
        assert _format_ncalls(0, 0) == "0"


class TestCalcTotals:
    """Test cases for _calc_totals function."""

    def test_empty_stats(self) -> None:
        """Test with empty statistics."""
        raw_stats = {}
        total_calls, primitive_calls, total_time = _calc_totals(raw_stats)
        assert total_calls == 0
        assert primitive_calls == 0
        assert total_time == 0.0

    def test_single_function(self) -> None:
        """Test with single function stats."""
        raw_stats = {
            ("file.py", 1, "func"): (1, 1, 0.5, 1.0, {}),  # cc, nc, tt, ct, callers
        }
        total_calls, primitive_calls, total_time = _calc_totals(raw_stats)
        assert total_calls == 1
        assert primitive_calls == 1
        assert total_time == 0.5

    def test_multiple_functions(self) -> None:
        """Test with multiple functions."""
        raw_stats = {
            ("file1.py", 1, "func1"): (1, 2, 0.5, 1.0, {}),
            ("file2.py", 2, "func2"): (2, 3, 0.3, 0.8, {}),
        }
        total_calls, primitive_calls, total_time = _calc_totals(raw_stats)
        assert total_calls == 5  # 2 + 3
        assert primitive_calls == 3  # 1 + 2
        assert total_time == 0.8  # 0.5 + 0.3


class TestParseNcallsForSort:
    """Test cases for _parse_ncalls_for_sort function."""

    def test_simple_number(self) -> None:
        """Test parsing simple number string."""
        assert _parse_ncalls_for_sort("100") == 100
        assert _parse_ncalls_for_sort("1") == 1

    def test_slash_format(self) -> None:
        """Test parsing slash format (total/primitive)."""
        assert _parse_ncalls_for_sort("150/50") == 150
        assert _parse_ncalls_for_sort("1000/100") == 1000

    def test_zero(self) -> None:
        """Test parsing zero."""
        assert _parse_ncalls_for_sort("0") == 0


class TestGetHotspots:
    """Test cases for _get_hotspots function."""

    def test_get_top_n_hotspots(self) -> None:
        """Test getting top N hotspots by tottime."""
        funcs = [
            FunctionStat(
                filename=f"file{i}.py",
                lineno=i,
                func_name=f"func{i}",
                ncalls="10",
                tottime=float(i),
                cumtime=float(i * 2),
                tottime_percall=0.1,
                cumtime_percall=0.2,
            )
            for i in range(10)
        ]
        # Sort by tottime descending: func9 (9.0), func8 (8.0), ..., func0 (0.0)
        hotspots = _get_hotspots(funcs, top_n=3)
        assert len(hotspots) == 3
        assert hotspots[0].tottime == 9.0
        assert hotspots[1].tottime == 8.0
        assert hotspots[2].tottime == 7.0

    def test_get_more_than_available(self) -> None:
        """Test requesting more hotspots than available."""
        funcs = [
            FunctionStat(
                filename="file.py",
                lineno=1,
                func_name="func",
                ncalls="5",
                tottime=0.5,
                cumtime=1.0,
                tottime_percall=0.1,
                cumtime_percall=0.2,
            ),
        ]
        hotspots = _get_hotspots(funcs, top_n=10)
        assert len(hotspots) == 1


class TestBuildTimeDistribution:
    """Test cases for _build_time_distribution function."""

    def test_build_distribution(self) -> None:
        """Test building time distribution slices."""
        funcs = [
            FunctionStat(
                filename="file.py",
                lineno=1,
                func_name="func1",
                ncalls="10",
                tottime=0.5,
                cumtime=1.0,
                tottime_percall=0.05,
                cumtime_percall=0.1,
            ),
            FunctionStat(
                filename="file.py",
                lineno=2,
                func_name="func2",
                ncalls="5",
                tottime=0.3,
                cumtime=0.6,
                tottime_percall=0.06,
                cumtime_percall=0.12,
            ),
        ]
        total_time = 1.0
        slices = _build_time_distribution(funcs, total_time, max_items=20)
        assert len(slices) > 0
        # First slice should have highest tottime
        assert "func1" in slices[0].func_name
        assert slices[0].percentage == 50.0  # 0.5 / 1.0 * 100

    def test_empty_total_time(self) -> None:
        """Test with zero total time."""
        funcs = []
        slices = _build_time_distribution(funcs, 0.0, max_items=20)
        assert slices == []


class TestBuildModuleStats:
    """Test cases for _build_module_stats function."""

    def test_group_by_filename(self) -> None:
        """Test grouping functions by filename."""
        funcs = [
            FunctionStat(
                filename="/path/to/module.py",
                lineno=1,
                func_name="func1",
                ncalls="10",
                tottime=0.5,
                cumtime=1.0,
                tottime_percall=0.05,
                cumtime_percall=0.1,
                origin="user",
            ),
            FunctionStat(
                filename="/path/to/module.py",
                lineno=2,
                func_name="func2",
                ncalls="5",
                tottime=0.3,
                cumtime=0.6,
                tottime_percall=0.06,
                cumtime_percall=0.12,
                origin="user",
            ),
            FunctionStat(
                filename="/path/to/other.py",
                lineno=1,
                func_name="other_func",
                ncalls="2",
                tottime=0.1,
                cumtime=0.2,
                tottime_percall=0.05,
                cumtime_percall=0.1,
                origin="user",
            ),
        ]
        modules = _build_module_stats(funcs)
        assert len(modules) == 2
        # module.py should have 2 functions
        module_py = next(m for m in modules if m.filename.endswith("module.py"))
        assert module_py.func_count == 2
        assert module_py.call_count == 15  # 10 + 5

    def test_module_aggregation(self) -> None:
        """Test that module stats aggregate correctly."""
        funcs = [
            FunctionStat(
                filename="/path/to/mod.py",
                lineno=1,
                func_name="f1",
                ncalls="10",
                tottime=0.5,
                cumtime=1.0,
                tottime_percall=0.05,
                cumtime_percall=0.1,
                origin="user",
            ),
        ]
        modules = _build_module_stats(funcs)
        assert len(modules) == 1
        assert modules[0].total_tottime == 0.5
        assert modules[0].total_cumtime == 1.0
        assert modules[0].call_count == 10
        assert modules[0].func_count == 1


class TestAnalyzeConfig:
    """Test cases for AnalyzeConfig dataclass."""

    def test_default_config(self) -> None:
        """Test default configuration values."""
        config = AnalyzeConfig()
        assert config.top_n == 50
        assert config.sort_by == "tottime"
        assert not config.target_name

    def test_custom_config(self) -> None:
        """Test custom configuration."""
        config = AnalyzeConfig(top_n=100, sort_by="cumtime", target_name="test.py")
        assert config.top_n == 100
        assert config.sort_by == "cumtime"
        assert config.target_name == "test.py"


class TestProfileAnalyzer:
    """Test cases for ProfileAnalyzer class."""

    @pytest.fixture
    def sample_profile(self) -> pstats.Stats:
        """Create a sample profile for testing.

        Returns
        -------
            pstats.Stats: Sample profile data.
        """
        pr = cProfile.Profile()
        pr.enable()
        # Generate some profile data
        data = [i**2 for i in range(1000)]
        sorted(data, reverse=True)
        pr.disable()
        stream = io.StringIO()
        return pstats.Stats(pr, stream=stream)

    def test_analyze_sample_data(self, sample_profile: pstats.Stats) -> None:
        """Test analyzing sample profile data."""
        config = AnalyzeConfig(top_n=10, sort_by="tottime", target_name="test")
        report = ProfileAnalyzer.analyze(sample_profile, config)

        assert report.total_calls > 0
        assert report.primitive_calls > 0
        assert report.total_time > 0
        assert report.unique_functions > 0
        assert len(report.function_stats) > 0
        assert len(report.hotspots) <= 10
        assert report.target_name == "test"
        assert report.sort_by == "tottime"

    def test_analyze_with_cumtime_sort(self, sample_profile: pstats.Stats) -> None:
        """Test analyzing with cumtime sorting."""
        config = AnalyzeConfig(top_n=20, sort_by="cumtime", target_name="test2")
        report = ProfileAnalyzer.analyze(sample_profile, config)

        assert report.sort_by == "cumtime"
        assert len(report.hotspots) <= 20

    def test_analyze_default_config(self, sample_profile: pstats.Stats) -> None:
        """Test analyzing with default config."""
        report = ProfileAnalyzer.analyze(sample_profile)

        assert not report.target_name
        assert report.sort_by == "tottime"


class TestBuildFlameGraph:
    """Test cases for _build_flame_graph function."""

    def test_build_from_empty_stats(self) -> None:
        """Test building flame graph from empty stats."""
        raw_stats = {}
        all_callees = {}
        total_time = 0.0
        roots = _build_flame_graph(raw_stats, all_callees, total_time)
        assert roots == []

    def test_build_from_simple_stats(self) -> None:
        """Test building flame graph from simple stats."""
        # Create minimal valid profile data
        pr = cProfile.Profile()
        pr.enable()
        sum(range(100))  # Simple operation
        pr.disable()
        stream = io.StringIO()
        stats = pstats.Stats(pr, stream=stream)

        # Need to call calc_callees to populate all_callees
        stats.calc_callees()
        all_callees = stats.all_callees

        roots = _build_flame_graph(stats.stats, all_callees, stats.total_tt)  # type: ignore[attr-defined]
        # Should have at least one root node
        assert isinstance(roots, list)
