"""Tests for pyprofiler."""
