"""Tests for the reporter module."""

import io
import tempfile
from pathlib import Path

import pytest

from pytola_dev.pyprofiler.models import (
    FlameNode,
    FunctionStat,
    ModuleStat,
    ProfileReport,
    TimeSlice,
)
from pytola_dev.pyprofiler.reporter import (
    ReportGenerator,
    _flame_node_to_dict,
    _func_stat_to_dict,
    _module_stat_to_dict,
)


class TestOriginOfFilter:
    """Test cases for the origin_of Jinja2 filter."""

    def test_origin_of_builtin_angle(self) -> None:
        """Test origin_of filter with angle bracket builtins."""
        gen = ReportGenerator()
        assert gen._env.filters["origin_of"]("<built-in method nt.stat>") == "builtin"
        assert gen._env.filters["origin_of"]("<frozen importlib>") == "builtin"

    def test_origin_of_builtin_tilde(self) -> None:
        """Test origin_of filter with tilde builtins."""
        gen = ReportGenerator()
        assert gen._env.filters["origin_of"]("~") == "builtin"

    def test_origin_of_user_code(self) -> None:
        """Test origin_of filter with user code."""
        gen = ReportGenerator()
        assert gen._env.filters["origin_of"]("/home/user/project/main.py") == "user"

    def test_origin_of_stdlib(self) -> None:
        """Test origin_of filter with stdlib."""
        gen = ReportGenerator()
        import sysconfig

        stdlib_path = sysconfig.get_path("stdlib")
        if stdlib_path:
            result = gen._env.filters["origin_of"](stdlib_path + "/os.py")
            assert result == "stdlib"


class TestFlameNodeToJson:
    """Test cases for _flame_node_to_dict function."""

    def test_simple_node_conversion(self) -> None:
        """Test converting a simple flame node to JSON."""
        node = FlameNode(
            name="compute",
            filename="/path/to/file.py",
            lineno=10,
            value=1.5,
            self_time=0.5,
            origin="user",
        )
        result = _flame_node_to_dict(node)

        assert result["n"] == "compute"
        assert result["f"] == "file.py"
        assert result["fp"] == "/path/to/file.py"
        assert result["l"] == 10
        assert result["v"] == 1.5
        assert result["s"] == 0.5
        assert result["o"] == "user"
        assert result["c"] == []

    def test_node_with_children(self) -> None:
        """Test converting a node with children to JSON."""
        child = FlameNode(name="child", filename="child.py", lineno=1, value=0.5, self_time=0.2)
        parent = FlameNode(
            name="parent",
            filename="parent.py",
            lineno=0,
            value=1.0,
            self_time=0.3,
            children=[child],
        )
        result = _flame_node_to_dict(parent)

        assert len(result["c"]) == 1
        assert result["c"][0]["n"] == "child"
        assert result["c"][0]["v"] == 0.5

    def test_builtin_filename_preserved(self) -> None:
        """Test that builtin filenames are preserved."""
        node = FlameNode(
            name="stat",
            filename="<built-in method nt.stat>",
            lineno=0,
            value=0.1,
            self_time=0.1,
            origin="builtin",
        )
        result = _flame_node_to_dict(node)

        assert result["f"] == "<built-in method nt.stat>"
        assert result["fp"] == "<built-in method nt.stat>"

    def test_rounding_precision(self) -> None:
        """Test that values are rounded to 6 decimal places."""
        node = FlameNode(
            name="func",
            filename="file.py",
            lineno=1,
            value=1.123456789,
            self_time=0.987654321,
        )
        result = _flame_node_to_dict(node)

        assert result["v"] == 1.123457  # Rounded to 6 decimals
        assert result["s"] == 0.987654


class TestFunctionStatToJson:
    """Test cases for _function_stat_to_dict function."""

    def test_function_stat_conversion(self) -> None:
        """Test converting FunctionStat to JSON."""
        stat = FunctionStat(
            filename="/path/to/file.py",
            lineno=10,
            func_name="my_func",
            ncalls="100/10",
            tottime=0.5,
            cumtime=1.2,
            tottime_percall=0.005,
            cumtime_percall=0.012,
            origin="user",
        )
        result = _func_stat_to_dict(stat)

        assert result["filename"] == "/path/to/file.py"
        assert result["lineno"] == 10
        assert result["func_name"] == "my_func"
        assert result["ncalls"] == "100/10"
        assert result["tottime"] == 0.5
        assert result["cumtime"] == 1.2
        assert result["origin"] == "user"
        assert "full_name" in result
        assert "display_name" in result
        assert "id" in result

    def test_with_callers_and_callees(self) -> None:
        """Test conversion with callers and callees."""
        from pytola_dev.pyprofiler.models import CalleeInfo, CallerInfo

        caller = CallerInfo(
            filename="/caller.py",
            lineno=1,
            func_name="caller_func",
            ncalls="10",
            tottime=0.1,
            cumtime=0.2,
        )
        callee = CalleeInfo(
            filename="/callee.py",
            lineno=2,
            func_name="callee_func",
            ncalls="50",
            tottime=0.3,
            cumtime=0.4,
        )
        stat = FunctionStat(
            filename="/path/to/file.py",
            lineno=10,
            func_name="my_func",
            ncalls="100",
            tottime=0.5,
            cumtime=1.0,
            tottime_percall=0.005,
            cumtime_percall=0.01,
            callers=[caller],
            callees=[callee],
        )
        result = _func_stat_to_dict(stat)

        assert len(result["callers"]) == 1
        assert result["callers"][0]["func_name"] == "caller_func"
        assert len(result["callees"]) == 1
        assert result["callees"][0]["func_name"] == "callee_func"


class TestModuleStatToJson:
    """Test cases for _module_stat_to_dict function."""

    def test_module_stat_conversion(self) -> None:
        """Test converting ModuleStat to JSON."""
        module = ModuleStat(
            filename="/path/to/module.py",
            display_name="module.py",
            total_tottime=1.5,
            total_cumtime=3.0,
            call_count=100,
            func_count=5,
            origin="user",
        )
        result = _module_stat_to_dict(module)

        assert result["filename"] == "/path/to/module.py"
        assert result["display_name"] == "module.py"
        assert result["total_tottime"] == 1.5
        assert result["total_cumtime"] == 3.0
        assert result["call_count"] == 100
        assert result["func_count"] == 5
        assert result["origin"] == "user"


class TestReportGenerator:
    """Test cases for ReportGenerator class."""

    @pytest.fixture
    def sample_report(self) -> ProfileReport:
        """Create a sample report for testing.

        Returns
        -------
            ProfileReport: A sample report object.
        """
        return ProfileReport(
            total_calls=1000,
            primitive_calls=500,
            total_time=2.5,
            unique_functions=50,
            function_stats=[],
            hotspots=[],
            time_distribution=[],
            flame_roots=[],
            module_stats=[],
            generated_at="2024-01-01 12:00:00",
            target_name="test_script.py",
            sort_by="tottime",
        )

    def test_generate_report(self, sample_report: ProfileReport) -> None:
        """Test generating HTML report."""
        gen = ReportGenerator()
        with tempfile.NamedTemporaryFile(encoding="utf-8", mode="w", suffix=".html", delete=False) as f:
            output_path = Path(f.name)

        try:
            result_path = gen.generate(sample_report, output_path, top_n=50)
            assert result_path.exists()
            assert result_path.suffix == ".html"

            # Verify HTML content
            content = Path(result_path).read_text(encoding="utf-8")
            assert "<!DOCTYPE html>" in content
            assert "性能分析报告" in content
            assert str(sample_report.total_time) in content
        finally:
            output_path.unlink()

    def test_generate_with_data(self) -> None:
        """Test generating report with actual data."""
        from pytola_dev.pyprofiler.models import FlameNode, FunctionStat

        func_stat = FunctionStat(
            filename="/test.py",
            lineno=1,
            func_name="test_func",
            ncalls="10",
            tottime=0.5,
            cumtime=1.0,
            tottime_percall=0.05,
            cumtime_percall=0.1,
            origin="user",
        )
        time_slice = TimeSlice(
            func_name="test_func",
            display_name="test_func",
            tottime=0.5,
            cumtime=1.0,
            percentage=20.0,
        )
        flame_node = FlameNode(name="root", filename="root.py", lineno=0, value=2.5, self_time=0.5)
        module_stat = ModuleStat(
            filename="/test.py",
            display_name="test.py",
            total_tottime=0.5,
            total_cumtime=1.0,
            call_count=10,
            func_count=1,
            origin="user",
        )

        report = ProfileReport(
            total_calls=100,
            primitive_calls=50,
            total_time=2.5,
            unique_functions=1,
            function_stats=[func_stat],
            hotspots=[func_stat],
            time_distribution=[time_slice],
            flame_roots=[flame_node],
            module_stats=[module_stat],
            generated_at="2024-01-01 12:00:00",
            target_name="test.py",
            sort_by="tottime",
        )

        gen = ReportGenerator()
        with tempfile.NamedTemporaryFile(encoding="utf-8", mode="w", suffix=".html", delete=False) as f:
            output_path = Path(f.name)

        try:
            result_path = gen.generate(report, output_path, top_n=50)
            content = Path(result_path).read_text(encoding="utf-8")
            assert "test_func" in content
            assert "test.py" in content
        finally:
            output_path.unlink()


class TestIntegration:
    """Integration tests for the reporter module."""

    def test_full_report_generation(self) -> None:
        """Test complete report generation workflow."""
        import cProfile
        import pstats

        # Generate profile data
        pr = cProfile.Profile()
        pr.enable()
        data = [i**2 for i in range(1000)]
        sorted(data, reverse=True)
        pr.disable()

        stream = io.StringIO()
        stats = pstats.Stats(pr, stream=stream)

        # Analyze
        from pytola_dev.pyprofiler.analyzer import AnalyzeConfig, ProfileAnalyzer

        config = AnalyzeConfig(top_n=10, sort_by="tottime", target_name="test")
        report = ProfileAnalyzer.analyze(stats, config)

        # Generate report
        gen = ReportGenerator()
        with tempfile.NamedTemporaryFile(encoding="utf-8", mode="w", suffix=".html", delete=False) as f:
            output_path = Path(f.name)

        try:
            result_path = gen.generate(report, output_path, top_n=10)
            assert result_path.exists()
            assert result_path.stat().st_size > 0

            # Verify key sections exist
            content = Path(result_path).read_text(encoding="utf-8")
            assert "火焰图" in content
            assert "调用关系" in content
            assert "热点详情" in content
        finally:
            output_path.unlink()
