"""Command-line interface for autofmt."""

import argparse
import logging
from pathlib import Path

from pytola_core.registry import DefaultRegistry

from .logger import logger


def parse_args() -> argparse.Namespace:
    """Parse command-line arguments.

    Returns
    -------
        argparse.Namespace: Parsed command-line arguments namespace
    """
    parser = argparse.ArgumentParser(description="Pytola autofmt tool")
    parser.add_argument("root_dir", type=Path, default=Path.cwd(), nargs="?", help="Root directory to run autofmt on")
    parser.add_argument("--list", "-l", action="store_true", help="List all available actions")
    parser.add_argument("--verbose", "-v", action="store_true", help="Enable verbose output")
    parser.add_argument("--dry-run", "-D", action="store_true", help="Enable dry run mode")
    parser.add_argument("--check", "-C", action="store_true", help="Enable check mode")

    return parser.parse_args()


def main() -> None:
    """Run the autofmt tool."""
    args = parse_args()

    if args.verbose:
        logger.setLevel(logging.DEBUG)

    if not args.root_dir.exists():
        logger.error(f"Root directory {args.root_dir} does not exist")
        return

    action_registry = DefaultRegistry.get_instance()

    if args.list:
        logger.info("Available actions:")
        actions = action_registry.list_all()
        for action in actions:
            logger.info(f"  - {action}")
    else:
        logger.info("Executing default action...")
        classes = action_registry.get_classes()
        for klass in classes:
            logger.info(f"Executing {klass.__name__}...")
            class_instance = klass(root_dir=args.root_dir, check_only=args.check, dry_run=args.dry_run)
            class_instance.run()
