"""自动同步 ruff 配置到所有子项目的 pyproject.toml.

此脚本将主项目的 ruff 配置同步到所有子文件夹的 pyproject.toml 中。
"""

from __future__ import annotations

import argparse
import fnmatch
import logging
import subprocess
import sys
from dataclasses import dataclass, field
from functools import cached_property
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

try:
    import tomllib  # Python 3.11+
except ImportError:
    import tomli as tomllib  # Python 3.10 及以下

from pytola_core.registry import register

from pytola_dev.autofmt.formatters.base import BaseFormatter

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# 行宽限制常量
MAX_LINE_LENGTH = 120
MAX_INLINE_LIST_LENGTH = 80  # 列表内联格式的最大长度


@dataclass
class TomlSectionConfig:
    """TOML 段落配置.

    Attributes
    ----------
    name : str
        段落名称（如 'lint', 'format'）
    sync_all : bool
        是否同步所有配置项
    sync_keys : Set[str]
        需要同步的键集合（sync_all=False 时使用）
    ignore_keys : Set[str]
        需要忽略的键集合
    """

    name: str
    sync_all: bool = False
    sync_keys: Set[str] = field(default_factory=set)
    ignore_keys: Set[str] = field(default_factory=set)


@dataclass
class TomlSyncConfig:
    """TOML 同步配置.

    Attributes
    ----------
    name : str
        配置段名称（用于显示）
    top_key : str
        顶级键路径（如 'tool.ruff'）
    sync_keys : Set[str]
        需要同步的顶级键集合
    ignore_keys : Set[str]
        需要忽略的顶级键集合
    subsections : Dict[str, TomlSectionConfig]
        子段落配置
    """

    name: str
    top_key: str
    sync_keys: Set[str]
    ignore_keys: Optional[Set[str]] = None
    subsections: Dict[str, TomlSectionConfig] = field(default_factory=dict)


# ==================== 配置区域 ====================
# 在此处配置需要同步的 TOML 配置项
SYNC_CONFIG: dict[str, TomlSyncConfig] = {
    "build-system": TomlSyncConfig(
        name="build-system",
        top_key="build-system",
        sync_keys={"requires", "build-backend"},
    ),
    "ruff": TomlSyncConfig(
        name="ruff",
        top_key="tool.ruff",
        sync_keys={"*"},
        subsections={
            "lint": TomlSectionConfig(
                name="lint",
                sync_all=True,
            ),
            "format": TomlSectionConfig(
                name="format",
                sync_all=True,
            ),
        },
    ),
    "pytest": TomlSyncConfig(
        name="pytest",
        top_key="tool.pytest.ini_options",
        sync_keys={"*"},
    ),
}


@register(
    name="pyproject",
    aliases=["pyproj", "toml"],
    description="Auto-sync ruff configuration to all sub-projects' pyproject.toml",
    help_text="Auto-sync ruff configuration to all sub-projects' pyproject.toml",
)
class PyProjectFormatter(BaseFormatter):
    """自动同步 pyproject.toml 配置的格式化器."""

    def __init__(
        self,
        root_dir: Path | None = None,
        *,
        check_only: bool = False,
        dry_run: bool = True,
        sync_config: dict[str, TomlSyncConfig] | None = None,
    ) -> None:
        super().__init__(root_dir, check_only=check_only, dry_run=dry_run)
        self.sync_config = sync_config or SYNC_CONFIG
        self.main_config: Dict[str, Any] = {}
        self.sub_projects: List[Path] = []

    def run(self, *, dry_run: bool = True, check_only: bool = False) -> bool:
        """运行配置同步.

        Args:
            dry_run: 如果为 True，只报告更改而不写入
            check_only: 如果为 True，只检查是否需要转换

        Returns
        -------
            成功返回 True，失败返回 False
        """
        logger.info("Starting pyproject.toml configuration sync...")
        logger.info(f"Dry run: {dry_run}, Check only: {check_only}")

        self._load_main_config()
        self._find_sub_projects()

        if check_only:
            logger.info("Check mode: would sync configurations but not writing changes")
        else:
            self._sync_configs()

        return True

    @cached_property
    def main_toml(self) -> Path:
        """获取主项目的 pyproject.toml 文件路径."""
        return self.root_dir / "pyproject.toml"

    def _load_main_config(self) -> None:
        """加载主项目配置."""
        if not self.main_toml.exists():
            logger.error(f"Error: Main pyproject.toml not found at {self.main_toml}")
            return

        logger.info(f"Loading main configuration from: {self.main_toml}")
        self.main_config = load_toml(self.main_toml)

    def _find_sub_projects(self) -> None:
        """查找所有子项目."""
        self.sub_projects = find_all_pyproject_files(self.root_dir)
        logger.info(f"Found {len(self.sub_projects)} sub-project pyproject.toml files")

    def _format_pyproject_files(self) -> None:
        """对所有子项目的 pyproject.toml 调用 ruff format 格式化."""
        if not self.sub_projects:
            logger.warning("No sub-project pyproject.toml files found to format")
            return

        # 提前检查 ruff 是否可用，避免在循环中抛出异常
        try:
            subprocess.run(["ruff", "--version"], capture_output=True, check=False)
        except FileNotFoundError:
            logger.warning("ruff command not found, skipping format for all files")
            return

        formatted_count = 0
        for pyproject in self.sub_projects:
            logger.debug(f"Formatting: {pyproject}")
            # 调用 ruff format 命令，设置缩进宽度为 2
            result = subprocess.run(
                ["ruff", "format", str(pyproject)],
                capture_output=True,
                text=True,
                check=False,
                encoding="utf-8",
            )

            if result.returncode == 0:
                formatted_count += 1
                logger.debug(f"Successfully formatted: {pyproject}")
            elif result.stderr:
                logger.warning(f"Format failed for {pyproject}: {result.stderr}")
            else:
                logger.debug(f"Format completed for {pyproject} (no changes)")

        logger.info(f"Formatted {formatted_count}/{len(self.sub_projects)} pyproject.toml files successfully")

    def _sync_configs(self) -> None:
        """同步所有配置."""
        for config_key, sync_cfg in self.sync_config.items():
            logger.info(f"\nProcessing {config_key} configuration...")

            # 提取并生成配置
            extracted_config = extract_toml_config(self.main_config, sync_cfg)
            if not extracted_config:
                logger.warning(f"No {config_key} configuration found, skipping...")
                continue

            logger.info(f"Found {config_key} configuration with {len(extracted_config)} top-level keys")
            config_section = generate_toml_section(extracted_config, sync_cfg)

            # 更新每个子项目
            success_count = sum(
                update_pyproject_toml(pyproject, sync_cfg.name, sync_cfg.top_key, config_section)
                for pyproject in self.sub_projects
            )

            logger.info(f"Completed: {success_count}/{len(self.sub_projects)} files updated successfully")

        # 同步完成后，对所有子项目的 pyproject.toml 调用 ruff format 格式化
        logger.info("\nFormatting all updated pyproject.toml files...")
        self._format_pyproject_files()


def load_toml(file_path: Path) -> Dict[str, Any]:
    """加载 TOML 文件."""
    logger.info(f"Loading TOML file: {file_path}")

    try:
        with file_path.open("rb") as f:
            toml_data = tomllib.load(f)
    except Exception:
        logger.exception(f"Error loading TOML file: {file_path}")
    else:
        logger.info(f"Successfully loaded TOML file: {file_path}")
        return toml_data


def _get_nested_key(config: Dict[str, Any], key_path: str) -> Optional[Dict[str, Any]]:
    """从嵌套字典中获取值.

    Parameters
    ----------
    config : Dict[str, Any]
        配置字典
    key_path : str
        点分隔的键路径（如 'tool.ruff'）

    Returns
    -------
    Optional[Dict[str, Any]]
        获取的值，如果不存在则返回 None
    """
    keys = key_path.split(".")
    current = config
    for key in keys:
        if not isinstance(current, dict) or key not in current:
            return None
        current = current[key]
    return current if isinstance(current, dict) else None


def _matches_sync_keys(key: str, sync_keys: Set[str]) -> bool:
    """检查键是否匹配同步键集合（支持通配符）.

    Parameters
    ----------
    key : str
        需要检查的键
    sync_keys : Set[str]
        同步键集合（可能包含通配符）

    Returns
    -------
    bool
        如果匹配返回 True
    """
    # 直接匹配
    if key in sync_keys:
        return True

    # 通配符匹配
    return any(("*" in pattern or "?" in pattern) and fnmatch.fnmatch(key, pattern) for pattern in sync_keys)


def _extract_section_config(
    full_config: Dict[str, Any],
    section_config: TomlSectionConfig,
) -> Dict[str, Any]:
    """根据配置提取段落配置.

    Parameters
    ----------
    full_config : Dict[str, Any]
        完整的配置字典
    section_config : TomlSectionConfig
        段落配置对象

    Returns
    -------
    Dict[str, Any]
        提取的配置
    """
    if section_config.name not in full_config or not isinstance(
        full_config[section_config.name],
        dict,
    ):
        return {}

    # 如果同步所有配置项
    if section_config.sync_all:
        result = dict(full_config[section_config.name])
        # 移除需要忽略的键
        if section_config.ignore_keys:
            for key in section_config.ignore_keys:
                result.pop(key, None)
        return result

    # 否则只提取指定的配置键
    result = {}
    for key in full_config[section_config.name]:
        if _matches_sync_keys(key, section_config.sync_keys):
            result[key] = full_config[section_config.name][key]

    return result


def extract_toml_config(toml_data: Dict[str, Any], sync_config: TomlSyncConfig) -> Dict[str, Any]:
    """从 TOML 数据中提取配置.

    Parameters
    ----------
    toml_data : Dict[str, Any]
        TOML 数据
    sync_config : TomlSyncConfig
        同步配置对象

    Returns
    -------
    Dict[str, Any]
        提取的配置
    """
    # 获取顶级配置
    top_config = _get_nested_key(toml_data, sync_config.top_key)
    if not top_config:
        return {}

    result = {}

    # 提取顶级键（支持通配符匹配）
    for key in top_config:
        if _matches_sync_keys(key, sync_config.sync_keys):
            result[key] = top_config[key]

    # 提取子段落
    for subsection_name, subsection_config in sync_config.subsections.items():
        if subsection_name in top_config and isinstance(top_config[subsection_name], dict):
            extracted = _extract_section_config(top_config, subsection_config)
            if extracted:
                result[subsection_name] = extracted

    # 对提取的配置进行排序
    return _sort_dict_keys(result)


def extract_ruff_config(toml_data: Dict[str, Any]) -> Dict[str, Any]:
    """从 TOML 数据中提取 ruff 配置（兼容接口）."""
    ruff_config = SYNC_CONFIG.get("ruff")
    return extract_toml_config(toml_data, ruff_config) if ruff_config else {}


def _sort_value(value: object) -> object:
    """对值进行排序处理.

    Parameters
    ----------
    value : Any
        需要排序的值

    Returns
    -------
    Any
        排序后的值
    """
    if isinstance(value, dict):
        return _sort_dict_keys(value)
    if isinstance(value, list):
        # 对列表中的每个元素递归排序
        sorted_items = [_sort_value(item) for item in value]
        # 如果列表元素都是可比较的类型（如字符串、数字），则对列表本身排序
        if sorted_items and all(isinstance(item, (str, int, float)) for item in sorted_items):
            try:
                return sorted(sorted_items)
            except TypeError:
                # 如果无法排序（类型不一致），返回原列表
                return sorted_items
        return sorted_items
    return value


def _sort_dict_keys(d: Dict[str, Any]) -> Dict[str, Any]:
    """递归地对字典键进行排序.

    Parameters
    ----------
    d : Dict[str, Any]
        需要排序的字典

    Returns
    -------
    Dict[str, Any]
        排序后的字典
    """
    if not isinstance(d, dict):
        return d

    result = {}
    # 先排序普通键，再处理嵌套字典
    for key in sorted(d.keys()):
        value = d[key]
        result[key] = _sort_value(value)

    return result


def _format_simple_value(value: object) -> str:
    """格式化简单类型的 TOML 值."""
    if isinstance(value, bool):
        return str(value).lower()
    if isinstance(value, str):
        return f'"{value}"'
    if isinstance(value, (int, float)):
        return str(value)
    return str(value)


def _format_list_value(value: list, indent: int = 0) -> str:
    """格式化列表类型的 TOML 值."""
    if not value:
        return "[]"

    indent_str = "  " * indent

    # 简单字符串列表
    if all(isinstance(item, str) for item in value):
        items = ", ".join(f'"{item}"' for item in value)
        line_content = f"[{items}]"
        # 检查是否需要多行格式
        if len(line_content) <= MAX_INLINE_LIST_LENGTH:
            return line_content
        # 多行格式
        lines = ["["]
        for i, item in enumerate(value):
            comma = "," if i < len(value) - 1 else ""
            lines.append(f'{indent_str}  "{item}"{comma}')
        lines.append(f"{indent_str}]")
        return "\n".join(lines)

    # 短列表且元素都是简单类型 - 单行格式
    if len(value) <= 3 and all(not isinstance(item, (list, dict)) for item in value):  # noqa: PLR2004
        formatted_items = [format_toml_value(item, 0) for item in value]
        result = f"[{', '.join(formatted_items)}]"
        if len(result) <= MAX_INLINE_LIST_LENGTH:
            return result

    # 复杂列表 - 多行格式
    lines = ["["]
    for item in value:
        formatted_item = format_toml_value(item, indent + 1)
        lines.append(f"{indent_str}  {formatted_item},")
    lines.append(f"{indent_str}]")
    return "\n".join(lines)


def _format_dict_value(value: dict, indent: int = 0) -> str:
    """格式化字典类型的 TOML 值."""
    # 内联表格格式
    items = []
    for k in sorted(value.keys()):
        v = value[k]
        formatted_v = format_toml_value(v, 0)
        items.append(f"{k} = {formatted_v}")
    return "{ " + ", ".join(items) + " }"


def format_toml_value(value: object, indent: int = 0) -> str:
    """格式化 TOML 值."""
    if isinstance(value, (bool, str, int, float)):
        return _format_simple_value(value)
    if isinstance(value, list):
        return _format_list_value(value, indent)
    if isinstance(value, dict):
        return _format_dict_value(value, indent)
    return str(value)


def _get_per_file_ignores_comment(pattern: str, rules: List[str]) -> str:
    """根据模式和规则推断 per-file-ignores 行注释."""
    if "gui" in pattern or "ui" in pattern or "views" in pattern:
        return " # Allow Qt naming conventions"
    if "tests" in pattern:
        if "D1" in rules:
            return " # Do not require documentation for tests."
        return " # Allow pytest fixtures in tests."
    return ""


def _generate_per_file_ignores(subsection_data: Dict[str, Any]) -> List[str]:
    """生成 [tool.ruff.lint.per-file-ignores] 段."""
    lines = ["\n[tool.ruff.lint.per-file-ignores]"]
    for pattern, rules in subsection_data["per-file-ignores"].items():
        if isinstance(rules, list) and rules:
            # 检查是否需要多行格式
            rules_str = ", ".join(f'"{r}"' for r in rules)
            line_content = f'"{pattern}" = [{rules_str}]'

            if len(line_content) <= MAX_LINE_LENGTH:
                # 单行格式
                comment = _get_per_file_ignores_comment(pattern, rules)
                lines.append(f"{line_content}{comment}")
            else:
                # 多行格式
                lines.append(f'"{pattern}" = [')
                for i, rule in enumerate(rules):
                    comma = "," if i < len(rules) - 1 else ""
                    lines.append(f'  "{rule}"{comma}')
                lines.append("]")
    return lines


def _format_rules_multiline(items: List[str], indent: str = "  ") -> List[str]:
    """多行格式化规则列表."""
    lines = ["["]
    for i, item in enumerate(items):
        comma = "," if i < len(items) - 1 else ""
        lines.append(f'{indent}"{item}"{comma}')
    lines.append("]")
    return lines


def _add_select_section(lines: List[str], items: List[str]) -> None:
    """添加 select 配置段."""
    items_str = ", ".join(f'"{item}"' for item in items)
    if len(items_str) <= MAX_INLINE_LIST_LENGTH:
        lines.extend(
            (
                "# See list of rules at: https://docs.astral.sh/ruff/rules/",
                f"select = [{items_str}]",
            ),
        )
    else:
        lines.extend(("# See list of rules at: https://docs.astral.sh/ruff/rules/", "select = ["))
        for i, item in enumerate(items):
            comma = "," if i < len(items) - 1 else ""
            lines.append(f'  "{item}"{comma}')
        lines.append("]")


def _add_ignore_section(lines: List[str], items: List[str]) -> None:
    """添加 ignore 配置段."""
    items_str = ", ".join(f'"{item}"' for item in items)
    if len(items_str) <= MAX_INLINE_LIST_LENGTH:
        lines.append(f"\nignore = [{items_str}]")
    else:
        lines.append("\nignore = [")
        for i, item in enumerate(items):
            comma = "," if i < len(items) - 1 else ""
            lines.append(f'  "{item}"{comma}')
        lines.append("]")


def _generate_lint_section(subsection_data: Dict[str, Any]) -> List[str]:
    """生成 [tool.ruff.lint] 段."""
    lines = []

    if "select" in subsection_data:
        _add_select_section(lines, subsection_data["select"])

    if "ignore" in subsection_data:
        _add_ignore_section(lines, subsection_data["ignore"])

    if "per-file-ignores" in subsection_data:
        lines.extend(_generate_per_file_ignores(subsection_data))

    for subkey in ("pycodestyle", "pydocstyle"):
        if subkey in subsection_data:
            lines.append(f"\n[tool.ruff.lint.{subkey}]")
            data = subsection_data[subkey]
            if isinstance(data, dict):
                for k, v in data.items():
                    sep = '"' if isinstance(v, str) else ""
                    lines.append(f"{k} = {sep}{v}{sep}")

    return lines


def _generate_format_section(subsection_data: Dict[str, Any]) -> List[str]:
    """生成 [tool.ruff.format] 段."""
    lines = ["# 确保格式化行为一致"]

    if "docstring-code-format" in subsection_data:
        lines.append("# 控制换行行为")

    for key, value in subsection_data.items():
        if isinstance(value, bool):
            lines.append(f"{key} = {str(value).lower()}")
        else:
            lines.append(f'{key} = "{value}"')

    return lines


def _generate_subsection_lines(subsection_name: str, subsection_data: Dict[str, Any]) -> List[str]:
    """生成子段落的 TOML 文本.

    Parameters
    ----------
    subsection_name : str
        子段落名称
    subsection_data : Dict[str, Any]
        子段落数据

    Returns
    -------
    List[str]
        生成的行列表
    """
    generators = {
        "lint": _generate_lint_section,
        "format": _generate_format_section,
    }

    generator = generators.get(subsection_name)
    if generator:
        return generator(subsection_data)

    # 通用处理 - 对键进行排序
    return [f"{key} = {format_toml_value(value)}" for key, value in sorted(subsection_data.items())]


def generate_toml_section(config_data: Dict[str, Any], sync_config: TomlSyncConfig) -> str:
    """生成 TOML 配置段的文本.

    Parameters
    ----------
    config_data : Dict[str, Any]
        配置数据
    sync_config : TomlSyncConfig
        同步配置对象

    Returns
    -------
    str
        生成的 TOML 文本
    """
    if not config_data:
        return ""

    lines = [
        f"# ------------------------ {sync_config.name} ------------------------- #",
        f"[{sync_config.top_key}]",
    ]

    # 添加顶级配置项 - 按排序顺序（只输出在 config_data 中存在的键）
    lines.extend(
        f"{key} = {format_toml_value(config_data[key])}"
        for key in sorted(config_data.keys())
        if key not in sync_config.subsections
    )

    # 添加子段落 - 按排序顺序
    for subsection_name in sorted(sync_config.subsections.keys()):
        if subsection_name in config_data:
            lines.append(f"\n[{sync_config.top_key}.{subsection_name}]")
            lines.extend(_generate_subsection_lines(subsection_name, config_data[subsection_name]))

    return "\n".join(lines) + "\n"


def generate_ruff_section(ruff_config: Dict[str, Any]) -> str:
    """生成 ruff 配置段的 TOML 文本（兼容接口）."""
    ruff_sync_config = SYNC_CONFIG.get("ruff")
    return generate_toml_section(ruff_config, ruff_sync_config) if ruff_sync_config else ""


def update_pyproject_toml(
    file_path: Path,
    section_name: str,
    top_key: str,
    new_section: str,
) -> bool:
    """更新 pyproject.toml 文件中的配置段.

    Parameters
    ----------
    file_path : Path
        pyproject.toml 文件路径
    section_name : str
        配置段名称（用于日志）
    top_key : str
        顶级键路径（如 'tool.ruff'）
    new_section : str
        新的配置段

    Returns
    -------
    bool
        是否成功更新
    """
    try:
        logger.info(f"Updating pyproject.toml file: {file_path}")
        with file_path.open("r", encoding="utf-8") as f:
            content = f.read()

        # 查找并删除现有的配置段
        lines = content.split("\n")
        new_lines = []
        in_target_section = False
        skip_next_blank = False

        # 将点分隔的键路径转换为 TOML 段前缀
        section_prefix = f"[{top_key}"

        i = 0
        while i < len(lines):
            line = lines[i]

            # 检测目标段开始
            if line.strip().startswith(section_prefix):
                in_target_section = True
                # 检查前一行是否是注释
                if new_lines and new_lines[-1].strip().startswith("# ----"):
                    new_lines.pop()
                i += 1
                continue

            # 在目标段中
            if in_target_section:
                # 检测下一个段的开始
                if line.strip().startswith("[") and not line.strip().startswith(section_prefix):
                    in_target_section = False
                    skip_next_blank = True
                else:
                    i += 1
                    continue

            # 跳过目标段后的第一个空行
            if skip_next_blank and not line.strip():
                skip_next_blank = False
                i += 1
                continue

            new_lines.append(line)
            i += 1

        # 添加新的配置
        # 找到合适的位置插入
        while new_lines and not new_lines[-1].strip():
            new_lines.pop()

        new_lines.append("")
        new_lines.extend(new_section.rstrip().split("\n"))
        new_lines.append("")

        # 写回文件
        new_content = "\n".join(new_lines)
        logger.info(f"Writing updated content to: {file_path}")
        with file_path.open("w", encoding="utf-8") as f:
            f.write(new_content)
    except Exception:
        logger.exception(f"Error updating {file_path}")
        return False
    else:
        logger.info(f"Successfully updated {file_path}")
        return True


def update_ruff_pyproject(file_path: Path, ruff_section: str) -> bool:
    """更新 pyproject.toml 文件中的 ruff 配置（兼容接口）."""
    ruff_sync_config = SYNC_CONFIG.get("ruff")
    return (
        update_pyproject_toml(
            file_path,
            "ruff",
            ruff_sync_config.top_key,
            ruff_section,
        )
        if ruff_sync_config
        else False
    )


def find_all_pyproject_files(root_dir: Path) -> List[Path]:
    """查找所有子文件夹中的 pyproject.toml 文件."""
    pyproject_files = []
    # 排除主项目根目录和 dist 目录
    for pyproject in root_dir.rglob("pyproject.toml"):
        # 跳过主项目的 pyproject.toml
        if pyproject.parent == root_dir:
            continue
        # 跳过 dist 目录下的文件
        if "dist" in pyproject.parts:
            continue
        pyproject_files.append(pyproject)

    return sorted(pyproject_files)


def _format_sorted_toml(data: Dict[str, Any], parent_key: str = "") -> str:
    """将排序后的字典格式化为 TOML 字符串.

    Parameters
    ----------
    data : Dict[str, Any]
        排序后的字典
    parent_key : str
        父级键路径（用于构建段名称）

    Returns
    -------
    str
        格式化的 TOML 字符串
    """
    lines = []

    # 分离普通键值对和嵌套字典
    simple_items = {}
    nested_items = {}

    for key in sorted(data.keys()):
        value = data[key]
        if isinstance(value, dict):
            nested_items[key] = value
        else:
            simple_items[key] = value

    # 先输出普通键值对
    for key in simple_items:
        value = data[key]
        formatted_value = format_toml_value(value)
        lines.append(f"{key} = {formatted_value}")

    # 处理嵌套字典
    for key in nested_items:
        value = data[key]
        # 构建完整的段路径
        current_key = f"{parent_key}.{key}" if parent_key else key

        # 添加空行分隔
        if lines:
            lines.append("")

        # 添加段标题 - 如果键包含特殊字符，需要用引号括起来
        if any(c in key for c in ["*", "?", "[", "]", "\\", "/", ".", "-"]):
            lines.append(f'["{current_key}"]')
        else:
            lines.append(f"[{current_key}]")

        # 递归处理子内容
        child_content = _format_sorted_toml(value, current_key)
        if child_content:
            lines.append(child_content)

    return "\n".join(lines)


def parse_args() -> argparse.Namespace:
    """解析命令行参数."""
    parser = argparse.ArgumentParser(description="Sync configuration to all sub-projects")
    parser.add_argument("directory", nargs="?", default=Path.cwd(), help="Root directory to sync configuration")
    parser.add_argument("--verbose", "-v", action="store_true", help="Enable verbose output")
    parser.add_argument("--dry-run", action="store_true", help="Run in dry-run mode")
    parser.add_argument("--check", action="store_true", help="Check only, do not make changes")
    return parser.parse_args()


def main() -> None:
    """主函数：同步配置到所有子项目."""
    args = parse_args()

    if args.verbose:
        logger.setLevel(logging.DEBUG)

    root_dir = Path(args.directory) if not isinstance(args.directory, Path) else args.directory
    if not root_dir.exists():
        logger.error(f"Error: Directory not found at {root_dir}")
        sys.exit(1)

    formatter = PyProjectFormatter(
        root_dir=root_dir,
        check_only=args.check,
        dry_run=args.dry_run,
    )
    logger.info(f"Loading configuration from: {root_dir}")
    logger.info(f"Main pyproject.toml: {formatter.main_toml}")

    formatter.run(dry_run=args.dry_run, check_only=args.check)


if __name__ == "__main__":
    main()
