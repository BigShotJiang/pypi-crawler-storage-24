#!/usr/bin/env python3
"""简化版自动化docstring生成工具."""

from __future__ import annotations

import ast
from pathlib import Path
from typing import List

from pytola_core.registry import register

from pytola_dev.autofmt.logger import logger
from pytola_dev.autofmt.parsers.module import MainFunctionInfo, ModuleInfo, ModuleParser

from .base import BaseFormatter


@register(
    name="docstring",
    aliases=["doc"],
    description="Auto-generate docstrings for Python files",
    help_text="Auto-generate docstrings for Python files",
)
class DocstringFormatter(BaseFormatter):
    """Auto-generate docstrings for Python files."""

    def __init__(self, root_dir: Path | None = None, *, check_only: bool = False, dry_run: bool = True) -> None:
        super().__init__(root_dir, check_only=check_only, dry_run=dry_run)

        self.modules: List[ModuleInfo] = []
        self.general_files: List[ModuleInfo] = []
        self.main_functions: List[MainFunctionInfo] = []

    def run(self) -> bool:
        """Run the docstring formatter."""
        logger.info("This is a placeholder for the DocstringFormatter run method.")

        self._analyze()
        self._process()

        return True

    def _analyze(self) -> None:
        parser = ModuleParser(self)

        for py_file in self.python_files:
            is_init_file = py_file.name == "__init__.py"

            try:
                parser.current_file = str(py_file.relative_to(self.root_dir))
                tree = ast.parse(py_file.read_text(encoding="utf-8"))
                parser.visit(tree)

                if is_init_file:
                    self.modules.append(parser.module_info)
                else:
                    self.general_files.extend(parser.general_files)

                self.main_functions.extend(parser.main_functions)

                # 重置解析器状态
                parser.main_functions = []
                parser.general_files = []
                parser.has_module_docstring = False
            except (OSError, UnicodeDecodeError, SyntaxError):
                logger.exception(f"Error processing {py_file}")

        logger.info("Analysis complete.")
        logger.info(
            f"Found {len(self.modules)} modules, {len(self.general_files)} "
            f"general files, {len(self.main_functions)} main functions",
        )

    def _find_missing_docstrings(self) -> None:
        """Find missing docstrings in the project."""
        logger.info("Finding missing docstrings...")

        missing_modules = [m for m in self.modules if not m.has_docstring]
        if missing_modules:
            logger.info(f"Missing docstring modules: {missing_modules}")

        missing_files = [f for f in self.general_files if not f.has_docstring]
        if missing_files:
            logger.info(f"Missing docstring files: {missing_files}")

        missing_functions = [f for f in self.main_functions if not f.has_docstring]
        if missing_functions:
            logger.info(f"Missing docstring functions: {missing_functions}")

    def _process(self) -> None:
        total_added = 0

        for module in (m for m in self.modules if not m.has_docstring):
            file_path = self.root_dir / module.file
            if self.add_docstring(file_path, self.generate_module_docstring(module)):
                logger.info(f"✓ Added docstring to {module.file}")
                total_added += 1

        for file_info in (f for f in self.general_files if not f.has_docstring):
            file_path = self.root_dir / file_info.file
            if self.add_docstring(file_path, self.generate_general_docstring(file_info)):
                logger.info(f"✓ Added docstring to {file_info.file}")
                total_added += 1

        for func in (f for f in self.main_functions if not f.has_docstring):
            file_path = self.root_dir / func.file
            if self.add_main_function_docstring(file_path, func.lineno, self.generate_main_docstring(func)):
                logger.info(f"✓ Added docstring to {func.file}")
                total_added += 1

        logger.info(f"Total: {total_added} docstrings added")

    @staticmethod
    def generate_module_docstring(file_info: ModuleInfo) -> str:
        """生成模块docstring."""
        module_path = Path(file_info.module_path)

        if module_path.name == "pytola":
            desc = "Pytola - Python Tools and Applications"
        elif len(module_path.parts) == 1:
            descriptions = {
                "core": "Core functionality and tools",
                "dev": "Development tools and utilities",
                "llm": "Large Language Model tools",
                "office": "Office productivity tools",
                "simulation": "Simulation and modeling tools",
                "system": "System utilities and tools",
            }
            desc = descriptions.get(module_path.name, f"{module_path.name.title()} module")
        else:
            parent = module_path.parts[0]
            name = module_path.name.replace("_", " ").title()
            desc = f"{name} {parent} tools"

        return f'"""{desc}."""'

    @staticmethod
    def generate_main_docstring(func_info: MainFunctionInfo) -> str:
        """生成main函数docstring."""
        file_path = Path(func_info.file)
        stem, parent = file_path.stem, file_path.parent.name
        template_type = "gui" if "gui" in stem.lower() else "cli"

        if template_type == "cli":
            return f'''"""Run entry point for the command-line interface.

    Command-line interface for {parent}

    Examples:
    {stem} [options] <arguments>
    """'''
        return f'''"""Run entry point for the GUI application.

    Graphical interface for {parent}
    """'''

    @staticmethod
    def generate_general_docstring(file_info: ModuleInfo) -> str:
        """生成普通文件docstring."""
        file_path = Path(file_info.file)
        stem, parent = file_path.stem, file_path.parent.name

        # 关键词匹配
        keywords = {
            "cli": f"Command-line interface for {parent}",
            "gui": f"Graphical user interface for {parent}",
            "core": f"Core functionality for {parent}",
            "util": f"Utility functions for {parent}",
            "model": f"Data models for {parent}",
            "component": f"Components for {parent}",
            "tool": f"Tools for {parent}",
            "config": f"Configuration for {parent}",
        }

        for key, desc in keywords.items():
            if key in stem.lower():
                return f'"""{desc}."""'

        return f'"""{stem.replace("_", " ").title()} module for {parent}."""'

    @staticmethod
    def add_docstring(file_path: Path, docstring: str, *, backup: bool = True) -> bool:
        """为文件添加docstring."""
        try:
            content = file_path.read_text(encoding="utf-8")
            tree = ast.parse(content)

            # 检查是否已有docstring
            first_node = tree.body[0] if tree.body else None
            if first_node and isinstance(first_node, ast.Expr) and isinstance(first_node.value, ast.Constant):
                return False

            # 添加docstring
            lines = content.splitlines()
            doc_lines = docstring.splitlines()
            doc_lines.append("")
            new_content = "\n".join(doc_lines + lines)

            # 备份和写入
            if backup:
                file_path.with_suffix(".py.backup").write_text(content, encoding="utf-8")
            file_path.write_text(new_content, encoding="utf-8")

        except (OSError, UnicodeDecodeError, SyntaxError):
            logger.exception(f"Error processing {file_path}")
            return False
        else:
            return True

    @staticmethod
    def add_main_function_docstring(file_path: Path, func_lineno: int, docstring: str, *, backup: bool = True) -> bool:
        """为main函数添加docstring."""
        try:
            content = file_path.read_text(encoding="utf-8")
            lines = content.splitlines()

            # 在指定行后插入docstring
            indent = "    "
            doc_lines = [f"{indent}{line}" for line in docstring.splitlines()]
            doc_lines.append("")

            new_lines = lines[:func_lineno] + doc_lines + lines[func_lineno:]

            if backup:
                file_path.with_suffix(".py.backup").write_text(content, encoding="utf-8")
            file_path.write_text("\n".join(new_lines), encoding="utf-8")
        except (OSError, UnicodeDecodeError, SyntaxError):
            logger.exception(f"Error processing {file_path}")
            return False
        else:
            return True
