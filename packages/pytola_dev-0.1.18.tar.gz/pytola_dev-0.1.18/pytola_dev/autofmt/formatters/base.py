"""Base module for formatters."""

from __future__ import annotations

from abc import ABC, abstractmethod
from functools import cached_property
from pathlib import Path

# 需要跳过的文件夹
SKIP_FOLDERS: set[str] = {"__pycache__", "dist", "build", ".venv", "venv", "env", ".env", "tests"}


def check_exclude_folder(file_path: Path, excludes: set[str] | None = None) -> bool:
    """Check if a file is excluded based on its name or parent directories.

    Args:
        file_path: Path of the file to check
        exclude_dirs: Directories to exclude from search

    Returns
    -------
        True if the file is excluded, False otherwise

    Examples
    --------
    >>> check_exclude_folder(Path("path/to/file.py"))
    False
    >>> check_exclude_folder(Path("path/to/__file.py"))
    False
    >>> check_exclude_folder(Path("path/to/__init__.py"))
    False
    >>> check_exclude_folder(Path("path/to/file.py"), excludes={"path/to"})
    False
    >>> check_exclude_folder(Path("path/build/file.py"), excludes={"build"})
    True
    """
    # 快速检查：文件名是否以 . 开头（隐藏文件），但不是 __init__.py
    if excludes is None:
        excludes = SKIP_FOLDERS

    if file_path.name.startswith(".") and file_path.name != "__init__.py":
        return True

    # 检查路径中是否包含排除的目录
    return any(part in excludes for part in file_path.parts)


class BaseFormatter(ABC):
    """Base class for auto-formatting tools."""

    def __init__(self, root_dir: Path | None = None, *, check_only: bool = False, dry_run: bool = True) -> None:
        self.root_dir = root_dir or Path.cwd()
        self.check_only = check_only
        self.dry_run = dry_run

    @abstractmethod
    def run(self, *, dry_run: bool = True, check_only: bool = False) -> bool:
        """Run the formatter on all Python files.

        Args:
            dry_run: If True, only report changes without writing
            check_only: If True, only check if conversion is needed

        Returns
        -------
            True if successful, False otherwise
        """

    @cached_property
    def python_files(self) -> set[Path]:
        """Get a set of Python files in the root directory, excluding certain folders."""
        py_files = self.root_dir.rglob("*.py")
        return {py_file for py_file in py_files if not check_exclude_folder(py_file)}

    @cached_property
    def init_files(self) -> set[Path]:
        """Get a set of __init__.py files in the root directory, excluding certain folders."""
        return {f for f in self.python_files if f.name == "__init__.py"}
