"""Module module for parsers."""

from __future__ import annotations

import ast
from dataclasses import dataclass
from typing import List

from pytola_dev.autofmt.formatters.base import BaseFormatter

from .base import BaseParser


@dataclass
class ModuleInfo:
    """模块信息."""

    file: str
    has_docstring: bool
    module_path: str = ""


@dataclass
class MainFunctionInfo:
    """Main函数信息."""

    name: str
    lineno: int
    file: str
    has_docstring: bool
    args: List[str]


class ModuleParser(BaseParser):
    """统一的文件分析器，处理模块、普通文件和 main 函数."""

    def __init__(self, formatter: BaseFormatter) -> None:
        super().__init__(formatter)

        self.has_module_docstring: bool = False
        self.current_file: str = ""
        self.main_functions: List[MainFunctionInfo] = []
        self.general_files: List[ModuleInfo] = []

    @property
    def module_info(self) -> ModuleInfo:
        """获取当前模块信息."""
        return ModuleInfo(
            file=self.current_file,
            has_docstring=self.has_module_docstring,
            module_path=self.current_file,
        )

    def visit_Module(self, node: ast.Module) -> None:
        """检查模块 docstring."""
        self.has_module_docstring = bool(ast.get_docstring(node))
        # 遍历模块的所有子节点
        for child in ast.iter_child_nodes(node):
            self.visit(child)

        # 如果是普通文件（非__init__.py），添加到 general_files
        if not self.current_file.endswith("__init__.py"):
            self.general_files.append(
                ModuleInfo(
                    file=self.current_file,
                    has_docstring=self.has_module_docstring,
                    module_path=self.current_file,
                ),
            )

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        """查找 main 函数."""
        if node.name == "main":
            self.main_functions.append(
                MainFunctionInfo(
                    name=node.name,
                    lineno=node.lineno,
                    file=self.current_file,
                    has_docstring=bool(ast.get_docstring(node)),
                    args=[arg.arg for arg in node.args.args],
                ),
            )
        # 遍历函数的子节点，但不递归处理嵌套的 FunctionDef
        for child in ast.iter_child_nodes(node):
            if not isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
                self.visit(child)
