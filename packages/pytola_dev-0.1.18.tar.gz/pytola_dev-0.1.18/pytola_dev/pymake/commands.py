"""Pymake commands module.

This module defines all CLI commands for the pymake tool.
Commands are automatically registered using the @register decorator
from pytola_core.registry.
"""

from __future__ import annotations

import logging
import shutil
import subprocess
from pathlib import Path
from typing import Callable, ClassVar, List, Union

from pytola_core.registry import register

from pytola_dev.pypack.models.project import Project
from pytola_dev.pypack.models.solution import Solution

logger = logging.getLogger(__name__)

# Type alias for command actions: either a shell command list or a callable
Action = Union[List[str], Callable[[], bool]]


class BaseCommand:
    """Abstract base class for all pymake commands.

    Subclasses must implement the run() method to execute the command.
    Commands can define COMMANDS class variable for automatic execution,
    or override run() for custom logic.

    Attributes
    ----------
        COMMANDS: List of actions to execute. Can be shell command lists
            or callable functions returning bool.
    """

    COMMANDS: ClassVar[list[Action]] = []

    def run(self) -> bool:
        """Execute the command.

        Iterates through COMMANDS and executes each one.
        For custom behavior, override this method.

        Returns
        -------
            True if all commands succeeded, False otherwise.

        Raises
        ------
            TypeError: If a command is not a list or callable.
        """
        logger.info(f"Running command: `{self.__class__.__name__}`")
        for command in self.COMMANDS:
            if callable(command):
                if not command():
                    logger.error(f"Callable command failed: `{command}`")
                    return False
            elif isinstance(command, list):
                if not self._run_command(command):
                    logger.error(f"Shell command failed: `{command}`")
                    return False
            else:
                msg = f"Invalid command type: {type(command)}"
                raise TypeError(msg)
        return True

    def __hash__(self) -> int:
        """Return a hash based on the class name and commands.

        Returns
        -------
            int: Hash value based on class name and commands.
        """
        return hash((self.__class__.__name__, tuple(self.COMMANDS)))

    @property
    def solution(self) -> Solution:
        """Get the solution instance."""
        return Solution.from_directory(Path.cwd())

    @property
    def projects(self) -> list[Project]:
        """Get a list of all Pytola projects in the solution."""
        return [p for p in self.solution.projects.values() if p.name.startswith("pytola")]

    def _run_command(self, command: list[str], cwd: Path | None = None) -> bool:
        """Run a single shell command with real-time console output.

        Args:
            command: Command to run as a list of strings.
            cwd: Working directory for the command. Defaults to current directory.

        Returns
        -------
            True if command succeeded (exit code 0), False otherwise.
        """
        cmd_str = " ".join(command)
        logger.info(f"Running: {cmd_str}")
        try:
            # Run command with real-time output to console
            result = subprocess.run(command, cwd=cwd, check=True)
        except FileNotFoundError:
            logger.exception(f"Command not found: `{command[0]}`")
            return False
        except Exception:
            logger.exception("Command failed unexpectedly")
            return False
        else:
            if result.returncode != 0:
                logger.error(f"Command failed (exit {result.returncode}): {cmd_str}")
                return False
            return True


@register(
    name="build",
    aliases=["b"],
    description="Build all projects",
    help_text="Compile and package all projects using hatch",
)
class BuildCommand(BaseCommand):
    """Build action for packages."""

    def run(self) -> bool:
        """Run the build action using PytolaBuilder.

        Returns
        -------
            True if all projects were built successfully.
        """
        super().run()

        return all(self._build_project(project.root_dir) for project in self.projects)

    def _build_project(self, package_path: Path) -> bool:
        """Build a project using hatch.

        Args:
            package_path: Path to the project directory.

        Returns
        -------
            True if build succeeded, False otherwise.
        """
        logger.info(f"Building project: {package_path}")
        if self._run_command(["hatch", "build"], cwd=package_path):
            logger.info(f"Successfully built: {package_path}")
            return True
        return False


@register(
    name="clean",
    aliases=["c"],
    description="Clean build artifacts",
    help_text="Remove build directories and generated files",
)
class CleanCommand(BaseCommand):
    """Clean command to remove build artifacts."""

    # Patterns to clean in each project
    CLEAN_PATTERNS: ClassVar[list[str]] = ["build", "dist", "*.egg-info", "__pycache__", ".pytest_cache", ".ruff_cache"]

    def run(self) -> bool:
        """Clean all projects.

        Returns
        -------
            True if all projects were cleaned successfully.
        """
        logger.info("Starting clean action")
        for project in self.projects:
            logger.info(f"Cleaning project: {project.name}")
            self._clean_project(project.root_dir)
        logger.info("Clean action completed")
        return True

    def _clean_project(self, package_path: Path) -> None:
        """Clean a project's build artifacts.

        Args:
            package_path: Path to the project directory.
        """
        for pattern in self.CLEAN_PATTERNS:
            for item in package_path.glob(pattern):
                try:
                    if item.is_dir():
                        shutil.rmtree(item)
                        logger.info(f"Removed directory: {item.relative_to(package_path)}")
                    else:
                        item.unlink()
                        logger.info(f"Removed file: {item.relative_to(package_path)}")
                except Exception as e:  # noqa: BLE001, PERF203
                    logger.warning(f"Failed to remove {item}: {e}")


@register(
    name="lint",
    aliases=["l"],
    description="Lint all projects",
    help_text="Check code quality with ruff and auto-fix issues",
)
class LintCommand(BaseCommand):
    """Lint command to check and fix code quality."""

    COMMANDS: ClassVar[list[Action]] = [["ruff", "check", ".", "--fix", "--unsafe-fixes"]]


@register(
    name="list",
    aliases=["list", "ls"],
    description="List all projects",
    help_text="Display all Pytola projects in the solution",
)
class ListCommand(BaseCommand):
    """List command to display all projects."""

    def run(self) -> bool:
        """List all projects in the solution.

        Returns
        -------
            True if successful.
        """
        if not self.projects:
            logger.info("No pytola projects found in the solution")
            return True

        logger.info(f"Found {len(self.projects)} project(s):")
        for project in self.projects:
            logger.info(f"  - {project.name} (v{project.version})")
        return True


@register(
    name="publish",
    aliases=["p"],
    description="Publish all projects",
    help_text="Upload packages to PyPI using hatch",
)
class PublishCommand(BaseCommand):
    """Publish command to upload packages to PyPI."""

    def run(self) -> bool:
        """Publish all projects using hatch.

        Returns
        -------
            True if all projects were published successfully.
        """
        super().run()

        return all(self._publish_project(project.root_dir) for project in self.projects)

    def _publish_project(self, package_path: Path) -> bool:
        """Publish a project using hatch.

        Args:
            package_path: Path to the project directory.

        Returns
        -------
            True if publish succeeded, False otherwise.
        """
        logger.info(f"Publishing project: {package_path}")
        if self._run_command(["hatch", "publish"], cwd=package_path):
            logger.info(f"Successfully published: {package_path}")
            return True
        return False


@register(
    name="test",
    aliases=["t"],
    description="Test all projects",
    help_text="Run tests with pytest (8 parallel workers)",
)
class TestCommand(BaseCommand):
    """Test command to run pytest with parallel execution."""

    COMMANDS: ClassVar[list[Action]] = [["pytest", "-n", "8"]]


@register(
    name="test-benchmark",
    aliases=["tb"],
    description="Test all projects with benchmarking",
    help_text="Run tests with pytest (8 parallel workers) and benchmarking",
)
class TestBenchmarkCommand(BaseCommand):
    """Test command to run pytest with parallel execution."""

    COMMANDS: ClassVar[list[Action]] = [["pytest", "-m", "benchmark"]]


@register(
    name="test-single-worker",
    aliases=["td"],
    description="Test all projects with single worker",
    help_text="Run tests with with single worker",
)
class TestSingleWorkerCommand(TestCommand):
    """Test command to run pytest with a single worker."""

    COMMANDS: ClassVar[list[Action]] = [["pytest"]]
