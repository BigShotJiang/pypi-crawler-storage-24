"""Pymake CLI module.

This module provides the command-line interface for pymake,
a build and management tool for Pytola projects.
"""

from __future__ import annotations

import argparse
import logging
import sys

from pytola_core.registry import DefaultRegistry

__version__ = "0.1.0"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)


def parse_args() -> tuple[argparse.ArgumentParser, argparse.Namespace]:
    """Parse command line arguments.

    Dynamically creates subcommands based on registered actions.

    Returns
    -------
        Tuple of (parser, args)
    """
    parser = argparse.ArgumentParser(
        description="Pytola project build and management tool",
        prog="pymake",
    )
    parser.add_argument(
        "--version",
        "-v",
        action="version",
        version=f"pymake {__version__}",
        help="Show version information",
    )
    parser.add_argument(
        "--debug",
        "-d",
        action="store_true",
        help="Enable debug mode for enhanced logging",
    )

    # Create subparsers for dynamic commands
    subparsers = parser.add_subparsers(dest="action", help="Available commands")

    # Get all registered actions from registry
    registry = DefaultRegistry.get_instance()

    for action_name, metadata in registry.list_all().items():
        # Get aliases if they exist
        aliases = metadata.get("aliases", [])
        help_text = metadata.get("help_text", metadata.get("description", ""))

        # Create subparser with name and aliases
        subparsers.add_parser(action_name, aliases=aliases, help=help_text)

    return parser, parser.parse_args()


def main() -> None:
    """Run the script."""
    parser, args = parse_args()

    # Configure debug mode
    if args.debug:
        logger.setLevel("DEBUG")
        logger.debug("Debug mode enabled")
        logger.debug(f"Arguments: {vars(args)}")

    # Get registry instance
    registry = DefaultRegistry.get_instance()

    # No action specified
    if not args.action:
        parser.print_help()
        sys.exit(1)

    action_class = registry.get(args.action)

    if action_class is None:
        logger.error(f"Unknown action: {args.action}")
        parser.print_help()
        sys.exit(1)

    try:
        action = action_class()
        result = action.run()
        sys.exit(0 if result else 1)
    except Exception:
        logger.exception(f"Action '{args.action}' failed")
        logger.exception("Stack trace:")
        sys.exit(1)


if __name__ == "__main__":
    main()
