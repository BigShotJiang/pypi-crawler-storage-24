"""Base module for envtool."""

from pytola_core.logger import get_logger

logger = get_logger(__name__)


class BaseEnvTool:
    """环境工具基类."""

    desc = ""

    def run(self, *args: object, **kwargs: object) -> None:
        """运行."""
        super().run(*args, **kwargs)

        if self.desc:
            logger.info(f"{self.desc}")
