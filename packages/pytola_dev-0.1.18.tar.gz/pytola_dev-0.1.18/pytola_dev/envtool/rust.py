"""功能: 初始化 Rust 环境变量."""

from __future__ import annotations

import platform
import subprocess
from pathlib import Path
from typing import ClassVar

from pytola_core.config import TomlConfigMixin

from .base import BaseEnvTool, logger
from .python import add_env_to_bashrc

IS_WINDOWS = platform.system() == "Windows"
HOME_DIR = Path.home()


class EnvRustConfig(TomlConfigMixin):
    """Rust 环境配置."""

    # rust 环境配置内容
    CONFIG_CONTENT = """[source.crates-io]
replace-with = 'ustc'

[source.ustc]
registry = "https://mirrors.ustc.edu.cn/crates.io-index"
"""

    RUSTUP_UPDATE_ROOT: ClassVar[str] = "https://mirrors.ustc.edu.cn/rust-static/rustup"
    RUSTUP_DIST_SERVER: ClassVar[str] = "https://mirrors.ustc.edu.cn/rust-static"

    DOWNLOAD_CMD_WINDOWS: ClassVar[list[str]] = ["wget", "https://win.rustup.rs", "-O", "rustup-init.exe"]
    DOWNLOAD_CMD_LINUX: ClassVar[list[str]] = ["curl", "--proto", "=https", "--tlsv1.2", "-sSf", "https://sh.rustup.rs"]

    def get_default_host(self) -> str:
        """获取 rustup 默认主机地址.

        Returns
        -------
            str: 默认主机地址
        """
        return "x86_64-pc-windows-msvc" if IS_WINDOWS else "x86_64-unknown-linux-gnu"


conf = EnvRustConfig(show_logging=False)


class RustEnvTool(BaseEnvTool):
    """Rust 环境工具."""

    def setup_env(self, *, override: bool = True) -> None:
        """设置 Rust 环境变量."""
        logger.info("配置 Rust 环境变量")

        rustup_envs: dict[str, object] = {k: v for k, v in conf.get_fileattrs().items() if k.startswith("RUSTUP_")}

        if IS_WINDOWS:
            for k, v in rustup_envs.items():
                logger.info(f"设置环境变量: {k}={v}")
                subprocess.run(["setx", str(k), str(v)], check=True)
        else:
            for k, v in rustup_envs.items():
                add_env_to_bashrc(str(k), str(v), override=override)

    def setup_cargo_config(self) -> None:
        """配置 Cargo 配置文件."""
        cargo_dir = HOME_DIR / ".cargo"
        cargo_conf = cargo_dir / "config.toml"

        if not cargo_dir.exists():
            logger.info(f"创建 Cargo 文件夹: [green bold]{cargo_dir}")
            cargo_dir.mkdir(parents=True)
        else:
            logger.info(f"已存在 Cargo 文件夹: [green bold]{cargo_dir}")

        logger.info(f"写入文件: [green bold]{cargo_conf}")
        cargo_conf.write_text(conf.CONFIG_CONTENT)

    def _check_rustup_callable(self) -> bool:
        """检查 rustup 是否可执行.

        Returns
        -------
            bool: 是否可执行
        """
        try:
            result = subprocess.run(
                ["rustup", "--version"],
                capture_output=True,
                text=True,
                timeout=5,
                check=False,
            )
        except (subprocess.TimeoutExpired, FileNotFoundError):
            logger.exception("rustup 未安装")
            return False
        else:
            return result.returncode == 0

    def _run_rustup(self, install_version: str) -> None:
        try:
            logger.info("运行 rustup-init.exe")
            subprocess.run(
                [
                    "rustup-init.exe",
                    f"--default-toolchain={install_version}",
                    "--no-modify-path",
                    "--default-host",
                    conf.get_default_host(),
                ],
                check=True,
            )
        except OSError:
            logger.exception("运行 rustup-init.exe 失败")
            logger.info(
                "请手动运行 rustup-init.exe 进行安装, 或者删除该文件后重新下载",
            )

    def _download_rustup(self) -> None:
        """下载 rustup."""
        ext = ".exe" if IS_WINDOWS else ""
        rustup_init_name = f"rustup-init{ext}"
        rustup_init_file = Path.cwd() / rustup_init_name

        if rustup_init_file.exists():
            logger.info(
                f"已存在 rustup 安装文件: [green bold]{rustup_init_file}",
            )
            return

        if IS_WINDOWS:
            logger.info("下载 rustup-init.exe")
            subprocess.run(conf.DOWNLOAD_CMD_WINDOWS, check=True)
        else:
            logger.info("下载 rustup-init.sh")
            # For Linux, we need to handle the pipe separately
            import tempfile
            import urllib.request
            from urllib.parse import urlparse

            # SECURITY: Validate URL scheme to prevent SSRF and local file access (CWE-22)
            # Only http/https schemes are permitted for downloading rustup script
            rustup_url = "https://sh.rustup.rs"
            parsed = urlparse(rustup_url)
            if parsed.scheme.lower() not in {"http", "https"}:
                logger.error(f"Invalid URL scheme: {rustup_url}")
                return

            # Download the script first (URL scheme validated above - safe to use)
            with urllib.request.urlopen(rustup_url) as response:
                script_content = response.read()

            # Save to temp file and execute
            with tempfile.NamedTemporaryFile(mode="wb", delete=False, suffix=".sh") as f:
                f.write(script_content)
                temp_script_path = f.name

            try:
                subprocess.run(["sh", temp_script_path], check=True)
            finally:
                Path(temp_script_path).unlink()

        rustup_path = Path.cwd() / "rustup-init.exe"
        if rustup_path.exists():
            logger.info(f"下载完成, 保存到: [green bold]{rustup_path}")
        else:
            logger.error(f"下载失败, 请手动下载到当前目录: [red bold]{rustup_path}")

    def run(self, install_version: str = "nightly", *, override: bool = True) -> None:
        """安装 Rust."""
        self.setup_env(override=override)
        self.setup_cargo_config()

        if self._check_rustup_callable():
            logger.info("rustup 已安装, 跳过安装步骤")
            logger.info("设置 rustup 默认host")
            subprocess.run(["rustup", "set", "default-host", conf.get_default_host()], check=True)
            subprocess.run(["rustup", "default", install_version], check=True)
        else:
            self._download_rustup()
            self._run_rustup(install_version)

        logger.info("查看 rustup 安装信息")
        subprocess.run(["rustup", "show"], check=True)
