"""Command-line interface for envtool."""

from __future__ import annotations

import argparse
from typing import ClassVar, Dict

from pytola_core.config import TomlConfigMixin

from .base import BaseEnvTool
from .python import PythonEnvtool
from .rust import RustEnvTool


class EnvToolConfig(TomlConfigMixin):
    """环境配置工具配置."""

    NODE_VERSIONS: ClassVar[Dict[str, str]] = {
        "V20": "curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -",
        "V18": "curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -",
    }


class _Config:
    python = "python"
    rust = "rust"


_tools: dict[str, BaseEnvTool] = {
    _Config.python: PythonEnvtool(),
    _Config.rust: RustEnvTool(),
}


conf = EnvToolConfig()


def get_env_tool(tool_name: str) -> BaseEnvTool:
    """获取环境配置工具.

    Args:
        tool_name (str): 环境配置工具名称

    Returns
    -------
        BaseEnvTool: 环境配置工具对象

    Raises
    ------
        ValueError: 未找到环境配置工具
    """
    tool = _tools.get(tool_name.lower())
    if not tool:
        msg = f"未找到环境配置工具: {tool_name}"
        raise ValueError(msg)
    return tool


def parse_args() -> argparse.Namespace:
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(description="Environment Tool")
    subparser = parser.add_subparsers(dest="tool")

    py_parser = subparser.add_parser("python", help="Python 环境配置工具")
    py_parser.add_argument("pypi_token", type=str, default="", nargs="?", help="PyPI token值")
    py_parser.add_argument("--override", help="是否覆盖已存在选项", action="store_true")

    return parser.parse_args()


def main() -> None:
    """Run entry point for the command-line interface.

    Command-line interface for envtool

    Examples
    --------
      cli [options] <arguments>
    """
    args = parse_args()
    tool = get_env_tool(args.tool)

    if args.tool == "python":
        tool.run(pypi_token=args.pypi_token, override=args.override)
