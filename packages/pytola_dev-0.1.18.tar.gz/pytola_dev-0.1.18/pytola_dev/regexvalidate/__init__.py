"""Regexvalidate module."""

from .gui import main

__all__ = ["main"]
