"""Command-line interface for checksum."""

from __future__ import annotations

import argparse
import hashlib
import logging
import sys
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Final

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)


class HashAlgorithm(Enum):
    """Supported hash algorithms."""

    MD5 = "md5"
    SHA1 = "sha1"
    SHA256 = "sha256"
    SHA384 = "sha384"
    SHA512 = "sha512"
    BLAKE2B = "blake2b"
    BLAKE2S = "blake2s"


@dataclass
class ChecksumResult:
    """Checksum calculation result."""

    algorithm: HashAlgorithm
    hash_value: str
    input_type: str  # "string" or "file"
    input_source: str
    comparison_passed: bool | None = None


@dataclass
class ChecksumConfig:
    """Checksum tool configuration."""

    default_algorithm: HashAlgorithm = HashAlgorithm.MD5
    enable_comparison: bool = False
    output_format: str = "hex"


class ChecksumCalculator:
    """Core checksum calculation engine."""

    SUPPORTED_ALGORITHMS: Final[set[HashAlgorithm]] = set(HashAlgorithm)

    def __init__(self, config: ChecksumConfig | None = None) -> None:
        """Initialize checksum calculator with configuration."""
        self.config = config or ChecksumConfig()
        self._current_algorithm = self.config.default_algorithm

    def calculate_string_checksum(self, content: str, algorithm: HashAlgorithm | None = None) -> str:
        """Calculate checksum for string content."""
        if not content:
            msg = "Content cannot be empty"
            raise ValueError(msg)

        alg = algorithm or self._current_algorithm
        hash_func = getattr(hashlib, alg.value)
        return hash_func(content.encode("utf-8")).hexdigest()

    def calculate_file_checksum(self, file_path: Path, algorithm: HashAlgorithm | None = None) -> str:
        """Calculate checksum for file content."""
        if not file_path.exists():
            msg = f"File not found: {file_path}"
            raise FileNotFoundError(msg)

        alg = algorithm or self._current_algorithm
        hash_func = getattr(hashlib, alg.value)
        hasher = hash_func()

        with Path(file_path).open("rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                hasher.update(chunk)

        return hasher.hexdigest()

    def verify_checksum(self, calculated: str, expected: str) -> bool:
        """Verify calculated checksum against expected value."""
        return calculated.lower() == expected.lower()

    def set_algorithm(self, algorithm: HashAlgorithm) -> None:
        """Set current hash algorithm."""
        if algorithm not in self.SUPPORTED_ALGORITHMS:
            msg = f"Unsupported algorithm: {algorithm}"
            raise ValueError(msg)
        self._current_algorithm = algorithm

    @property
    def current_algorithm(self) -> HashAlgorithm:
        """Get current hash algorithm."""
        return self._current_algorithm


def parse_cli_arguments() -> argparse.Namespace:
    """Parse command line arguments for checksum tool."""
    parser = argparse.ArgumentParser(
        description="Calculate and verify file/string checksums",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  checksum --algorithm sha256 --string "hello world"
  checksum --algorithm md5 --file document.pdf
  checksum --algorithm sha256 --file data.zip --compare "expected_hash_value"
        """,
    )

    parser.add_argument(
        "--algorithm",
        "-a",
        choices=[alg.value for alg in HashAlgorithm],
        default=HashAlgorithm.MD5.value,
        help="Hash algorithm to use (default: md5)",
    )

    input_group = parser.add_mutually_exclusive_group(required=True)
    input_group.add_argument("--string", "-s", help="Calculate checksum for string content")
    input_group.add_argument("--file", "-f", type=Path, help="Calculate checksum for file")

    parser.add_argument("--compare", "-c", help="Verify calculated checksum against expected value")

    return parser.parse_args()


def run_cli_mode(args: argparse.Namespace) -> int:
    """Run checksum tool in command line mode."""
    try:
        # Initialize calculator
        algorithm = HashAlgorithm(args.algorithm)
        config = ChecksumConfig(default_algorithm=algorithm)
        calculator = ChecksumCalculator(config)

        # Calculate checksum
        if args.string is not None:
            result = calculator.calculate_string_checksum(args.string)
            input_desc = f'string "{args.string}"'
        elif args.file is not None:
            if not args.file.exists():
                logger.error(f"Error: File not found: {args.file}")
                return 1
            result = calculator.calculate_file_checksum(args.file)
            input_desc = f'file "{args.file}"'
        else:
            logger.error("Error: Either --string or --file must be specified")
            return 1

        # Output result
        logger.info(f"Algorithm: {algorithm.value.upper()}")
        logger.info(f"Input: {input_desc}")
        logger.info(f"Checksum: {result}")

        # Verify if comparison requested
        if args.compare:
            is_valid = calculator.verify_checksum(result, args.compare)
            logger.info(f"Verification: {'PASSED' if is_valid else 'FAILED'}")
            return 0 if is_valid else 1
    except Exception:
        logger.exception("Error")
        return 1
    else:
        return 0


def main() -> None:
    """Run main entry point for checksum tool."""
    args = parse_cli_arguments()

    sys.exit(run_cli_mode(args))


if __name__ == "__main__":
    main()
