import os as os
from importlib import resources
from json import load

import rich_click as click

from .utils.lazy_group import LazyGroup
from .utils.logging.loggit import get_version_info, setup_logging
from .utils.various import flat_dict

click.rich_click.TEXT_MARKUP = "rich"
click.rich_click.GROUP_ARGUMENTS_OPTIONS = True
click.rich_click.SHOW_ARGUMENTS = True
click.rich_click.GROUP_ARGUMENTS_OPTIONS = True
click.rich_click.STYLE_COMMANDS_TABLE_PAD_EDGE = True
click.rich_click.STYLE_COMMANDS_TABLE_PADDING = (0, 2)

# load rolypoly config
with resources.files("rolypoly").joinpath("rpconfig.json").open("r") as conff:
    config = load(conff)


def resolve_data_dir(configured_path: str) -> str:
    """Resolve data dir only when path starts with a leading $ENV_VAR token."""
    if not configured_path.startswith("$"):
        return configured_path

    if configured_path.startswith("${"):
        closing = configured_path.find("}")
        if closing == -1:
            return configured_path
        var_name = configured_path[2:closing]
        suffix = configured_path[closing + 1 :]
    else:
        slash_index = configured_path.find("/")
        if slash_index == -1:
            var_name = configured_path[1:]
            suffix = ""
        else:
            var_name = configured_path[1:slash_index]
            suffix = configured_path[slash_index:]

    env_value = os.environ.get(var_name)
    if not env_value:
        return configured_path
    return f"{env_value}{suffix}"


data_dir = resolve_data_dir(config["ROLYPOLY_DATA"])
os.environ["ROLYPOLY_DATA"] = data_dir  # export to env just in case
os.environ["ROLYPOLY_DATA_DIR"] = data_dir  # export to env just in case x2
ROLYPOLY_REMIND_CITATIONS = config["ROLYPOLY_REMIND_CITATIONS"]
os.environ["ROLYPOLY_REMIND_CITATIONS"] = ROLYPOLY_REMIND_CITATIONS
os.environ["citation_file"] = str(
    resources.files("rolypoly").joinpath(
        "../../misc/all_used_tools_dbs_citations.json"
    )
)

CONTEXT_SETTINGS = dict(
    help_option_names=["-h", "--help", "-help", "--hepl"], show_default=True
)


@click.group(
    cls=LazyGroup,
    context_settings=CONTEXT_SETTINGS,
    lazy_subcommands={
        "data": {
            "name": "Setup and Data",
            "commands": {
                "get-data": "rolypoly.commands.misc.get_external_data.get_data",
                # "build-data": "rolypoly.commands.misc.build_data.build_data", # this is for dev work.
            },
        },
        "reads": {
            "name": "Raw Reads Processing",
            "commands": {
                "filter-reads": "rolypoly.commands.reads.filter_reads.filter_reads",
                "shrink-reads": "rolypoly.commands.reads.shrink_reads.shrink_reads",
                "mask-dna": "rolypoly.commands.reads.mask_dna.mask_dna",
            },
        },
        "annotation": {
            "name": "Genome Annotation",
            "commands": {
                "annotate": "rolypoly.commands.annotation.annotate.annotate",
                "annotate-rna": "rolypoly.commands.annotation.annotate_RNA.annotate_RNA",
                "annotate-prot": "rolypoly.commands.annotation.annotate_prot.annotate_prot",
            },
        },
        "assembly": {
            "name": "Meta/Genome Assembly",
            "commands": {
                "assemble": "rolypoly.commands.assembly.assemble.assembly",
                "filter-contigs": "rolypoly.commands.assembly.filter_contigs.filter_contigs",
                "extend": "rolypoly.commands.assembly.extend.extend",
                # Commenting out unimplemented commands
                # "co-assembly": "rolypoly.commands.assembly.co_assembly.co_assembly",
                # "refine": "rolypoly.commands.assembly.refinement.refine"
            },
        },
        "misc": {
            "name": "Miscellaneous",
            "commands": {
                "roll": "rolypoly.commands.misc.end_2_end.roll",
                # "add-command": "hidden:rolypoly.commands.misc.add_command.add_command",
                "fetch-sra": "rolypoly.commands.misc.fetch_sra_fastq.fetch_sra",  # Not  a click command (yet?)
                "fastx-stats": "rolypoly.commands.misc.fastx_stats.fastx_stats",
                "fastx-calc": "rolypoly.commands.misc.fastx_calc.fastx_calc",
                "rename-seqs": "rolypoly.commands.misc.rename_seqs.rename_seqs",
                "help": "rolypoly.rolypoly.rolypoly",
            },
        },
        "bining": {
            "name": "Binning",
            "commands": {
                "termini": "rolypoly.commands.bining.termini.termini",
                "correlate": "rolypoly.commands.bining.correlate.correlate",
                "cluster": "rolypoly.commands.bining.cluster.cluster",
                "binit": "rolypoly.commands.bining.binit.binit",
            },
        },
        # "characterise": {
        #     "name": "Characterisation",
        #     "commands": {
        #         "characterise": "hidden:rolypoly.commands.virotype.predict_characteristics.predict_characteristics",
        #         # Commenting out unimplemented/broken commands
        #         # "summarize": "rolypoly.commands.virotype.summarize.summarize"
        #     },
        # },
        "identify": {
            "name": "RNA Virus Identification",
            "commands": {
                "marker-search": "rolypoly.commands.identify_virus.marker_search.marker_search",
                "virus-mapping": "rolypoly.commands.identify_virus.search_viruses.virus_mapping",
                "rdrp-motif-search": "rolypoly.commands.identify_virus.rdrp_motif_search.rdrp_motif_search",
            },
        },
    },
)
@click.version_option(
    version=flat_dict(get_version_info(), sep="\n"), prog_name="rolypoly"
)
def rolypoly():
    """RolyPoly: RNA Virus analysis tookit.\n
    Use rolypoly `command` --help for more details \n"""
    pass


@rolypoly.command(panel="Setup and Data")
@click.option(
    "-ll", "--log-level", hidden=True, default="INFO", help="Log level"
)
def version(log_level):
    """
    Print RolyPoly code and data version details.

    This is a command-form wrapper around top-level `--version` output, useful
    in scripted workflows that call `rolypoly version` explicitly.
    """
    setup_logging(None, log_level)
    # click wrapper for version/data information, so it could be called vai rolypoly version (on top of rolypoly --version)
    print(flat_dict(get_version_info(), sep="\n"))


if __name__ == "__main__":
    rolypoly()
