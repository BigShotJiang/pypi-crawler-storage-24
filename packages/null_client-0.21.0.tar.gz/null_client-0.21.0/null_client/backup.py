from __future__ import annotations

import os
import socket
import stat
from pathlib import Path
from typing import IO, Any, Required, TypedDict, cast

from null_client._chunker import chunk_file, MAX_TREE_ENTRIES

from .client import Client, Hash, RecordResponse


def build_content_tree(client: Client, hashes: list[Hash]) -> Hash:
    """Build a tree from an ordered list of blob hashes (same layering as null-cli).

    An empty ``hashes`` list produces an empty tree via ``POST /trees`` with
    ``hashes: []``, matching null-cli empty directories.
    """
    if not hashes:
        return client.create_tree([]).hash

    if len(hashes) <= MAX_TREE_ENTRIES:
        return client.create_tree(hashes).hash

    subtree_hashes: list[Hash] = []
    for i in range(0, len(hashes), MAX_TREE_ENTRIES):
        batch = hashes[i : i + MAX_TREE_ENTRIES]
        subtree_hashes.append(client.create_tree(batch).hash)

    return build_content_tree(client, subtree_hashes)


class BackupFsMetadata(TypedDict, total=False):
    """Hints for the optional ``metadata=`` keyword **only** (partial overrides).

    Helpers start from a base dict (path stat fields for a filesystem path, or
    ``{"xattrs": {}}`` for a file-like source / dir without ``dir_path``), then
    merge ``metadata=`` on top. Every key here is optional in that merge input:
    you only pass the fields you want to set or override.

    This is **not** the full record payload. Required fields such as final
    ``size`` (files), ``name`` (when not implied by ``dir_path``), and
    ``logical_size`` (dirs) are supplied by function parameters or by stat, not
    documented as required on this type. See :class:`BackupFileRecordMetadata` and
    :class:`BackupDirRecordMetadata` for the shape of metadata **after** a
    successful :func:`backup_file` / :func:`create_dir_record` (e.g. when reading
    ``RecordResponse.metadata``).

    You may still pass a plain ``dict[str, Any]`` for ``metadata=``; this
    ``TypedDict`` is for autocomplete and static checking of common keys.
    """

    name: str
    mode: int
    mtime: int
    uid: int
    gid: int
    size: int
    xattrs: dict[str, Any]


class BackupDirRecordMetadata(TypedDict, total=False):
    """Directory record metadata after merge (``logical_size`` and ``name`` are always present)."""

    logical_size: Required[int]
    name: Required[str]
    mode: int
    mtime: int
    uid: int
    gid: int
    size: int
    xattrs: dict[str, Any]


class BackupFileRecordMetadata(TypedDict, total=False):
    """File backup record metadata after merge (``size`` and ``name`` are always present).

    Path-based :func:`backup_file` also sets ``path`` and ``hostname``; file-like
    sources omit them unless supplied in ``metadata=``.
    """

    size: Required[int]
    name: Required[str]
    mode: int
    mtime: int
    uid: int
    gid: int
    xattrs: dict[str, Any]
    path: str
    hostname: str


def _path_fs_metadata(
    path: Path,
    *,
    st: os.stat_result | None = None,
    follow_symlinks: bool = True,
) -> dict[str, Any]:
    st = st if st is not None else os.stat(path, follow_symlinks=follow_symlinks)
    meta: dict[str, Any] = {
        "name": path.name,
        "size": st.st_size,
        "mtime": int(st.st_mtime),
        "xattrs": {},
    }
    if os.name != "nt":
        meta["uid"] = st.st_uid
        meta["gid"] = st.st_gid
        meta["mode"] = st.st_mode
    return meta


def _merge_metadata(
    base: dict[str, Any],
    extra: BackupFsMetadata | dict[str, Any] | None,
) -> dict[str, Any]:
    out = dict(base)
    if extra:
        out.update(cast(dict[str, Any], extra))
    return out


def _upload_chunked_content(
    client: Client, chunk_source: str | IO[bytes]
) -> tuple[Hash, int]:
    current_batch: list[Hash] = []
    tree_hashes: list[Hash] = []
    total_bytes = 0

    for chunk in chunk_file(chunk_source):
        total_bytes += chunk.length
        chunk_hash = client.put_blob(chunk.data)
        current_batch.append(chunk_hash)
        if len(current_batch) >= MAX_TREE_ENTRIES:
            tree_hashes.append(client.create_tree(current_batch).hash)
            current_batch = []

    if current_batch:
        tree_hashes.append(client.create_tree(current_batch).hash)

    if not tree_hashes:
        # Zero-byte content: same as null-cli (empty tree, no data blobs).
        return build_content_tree(client, []), total_bytes

    if len(tree_hashes) == 1:
        root_hash = tree_hashes[0]
    else:
        root_hash = build_content_tree(client, tree_hashes)

    return root_hash, total_bytes


def _backup_file_impl(
    client: Client,
    *,
    chunk_source: str | IO[bytes],
    canonical_size: int,
    source_path: Path | None,
    path_stat: os.stat_result | None,
    namespace: str | None,
    metadata: BackupFsMetadata | dict[str, Any] | None,
    immutable: bool,
    require_name: bool,
) -> RecordResponse:
    base: dict[str, Any] = {}
    if source_path is not None:
        base = _path_fs_metadata(source_path, st=path_stat)

    meta = _merge_metadata(base, metadata)
    if require_name and not meta.get("name"):
        raise ValueError(
            "metadata must include 'name' when backing up from a file-like object"
        )

    root_hash, streamed = _upload_chunked_content(client, chunk_source)
    if streamed != canonical_size:
        raise ValueError(
            f"Size mismatch: expected {canonical_size} bytes, streamed content is {streamed} bytes"
        )

    meta["size"] = canonical_size

    if source_path is not None:
        meta["path"] = str(source_path.resolve())
        meta["hostname"] = socket.gethostname()

    return client.create_record(
        kind="file",
        content=root_hash,
        metadata=meta,
        namespace=namespace,
        immutable=immutable,
    )


def backup_file(
    source: str | Path | IO[bytes],
    *,
    client: Client,
    namespace: str | None = None,
    metadata: BackupFsMetadata | dict[str, Any] | None = None,
    size: int | None = None,
    immutable: bool = True,
) -> RecordResponse:
    """Chunk-upload content and create a ``file`` record (same chunking as null-cli).

    Every created record has metadata ``name`` and ``size`` (see below).

    * If ``source`` is a **path** (``str`` / ``Path``): nothing extra. ``name``
      and ``size`` come from the file path and ``stat()``; optional ``size=``
      only checks equality with ``stat().st_size``.
    * If ``source`` is **file-like** (anything ``chunk_file`` accepts): you
      **must** pass ``size=`` (exact byte length of the stream). You **must**
      pass ``metadata={"name": "...", ...}`` with a non-empty ``name`` (no stat
      path to infer it from).

    The canonical ``size`` written to the record is always the value above; it
    cannot be overridden via ``metadata=`` after merge.

    For a **path** ``source``, metadata also includes ``path`` (absolute path
    string) and ``hostname`` (``socket.gethostname()``). File-like sources do not
    add those keys unless you pass them via ``metadata=``.

    Args:
        source: Filesystem path or binary stream (anything ``chunk_file`` accepts).
        client: API client; caller manages its lifetime (e.g. ``with Client(url) as client:``).
        namespace: Optional record namespace.
        metadata: Optional fields merged on top of auto-filled FS metadata. For
            file-like ``source``, **must** include ``name``.
        size: **Required** for file-like ``source`` (must match bytes read).
            For a path, optional; if set, must equal ``Path.stat().st_size``.
        immutable: Passed to :meth:`Client.create_record` (default ``True``, CLI-style).

    Returns:
        The created record response.

    Raises:
        TypeError: File-like ``source`` without ``size``.
        ValueError: File-like ``source`` without ``name`` in merged metadata; or path
            ``size=`` does not match stat; or streamed length ≠ ``size``.
        FileNotFoundError: Path does not exist.
        IsADirectoryError: Path is not a regular file.
    """
    path_like = isinstance(source, (str, Path))

    if path_like:
        path = Path(cast(str | Path, source)).resolve()
        try:
            st = path.stat()
        except FileNotFoundError as e:
            raise FileNotFoundError(f"File not found: {path}") from e
        if not stat.S_ISREG(st.st_mode):
            raise IsADirectoryError(f"Not a regular file: {path}")
        canonical = st.st_size if size is None else size
        if size is not None and st.st_size != size:
            raise ValueError(f"size={size} does not match path stat size {st.st_size}")
        return _backup_file_impl(
            client,
            chunk_source=str(path),
            canonical_size=canonical,
            source_path=path,
            path_stat=st,
            namespace=namespace,
            metadata=metadata,
            immutable=immutable,
            require_name=False,
        )

    if size is None:
        raise TypeError("size is required when source is a file-like object")
    return _backup_file_impl(
        client,
        chunk_source=cast(IO[bytes], source),
        canonical_size=size,
        source_path=None,
        path_stat=None,
        namespace=namespace,
        metadata=metadata,
        immutable=immutable,
        require_name=True,
    )


def create_dir_record(
    client: Client,
    child_record_hashes: list[Hash],
    *,
    logical_size: int,
    namespace: str | None = None,
    metadata: BackupFsMetadata | dict[str, Any] | None = None,
    dir_path: str | Path | None = None,
    immutable: bool = True,
) -> RecordResponse:
    """Create an immutable ``dir`` record whose content is a tree of child **record** hashes.

    Every created record has metadata ``logical_size`` and ``name`` (see below).

    * ``logical_size`` (**required** keyword): stored in metadata — typically the
      sum of file payload bytes under this directory (same idea as null-cli).
    * ``name`` (**required** in the merged metadata one way or another):
        * If ``dir_path`` is set: ``name`` defaults to the directory basename (and
          directory ``size``/mode/uid/gid/mtime come from ``stat``). You may
          override ``name`` via ``metadata=``.
        * If ``dir_path`` is ``None``: you **must** pass ``metadata={"name": "...", ...}``
          with a non-empty ``name``.

    Empty ``child_record_hashes`` produces an empty content tree (null-cli behavior).

    Args:
        client: API client.
        child_record_hashes: Ordered list of **child record** hashes (immutable
            record blobs), not raw file chunk hashes from another tree.
        logical_size: **Required.** Written to ``metadata["logical_size"]``.
        namespace: Optional record namespace.
        metadata: Optional fields merged on top of stat-based defaults when
            ``dir_path`` is set, or the primary source of fields when it is not.
            When ``dir_path`` is ``None``, **must** include ``name``.
        dir_path: Optional directory on disk; if set, used to fill ``name`` and FS fields.
        immutable: Passed to :meth:`Client.create_record` (default ``True``).

    Returns:
        The created record response.

    Raises:
        ValueError: No non-empty ``name`` after merge (usually missing from
            ``metadata`` when ``dir_path`` is ``None``).
        FileNotFoundError: ``dir_path`` does not exist.
        NotADirectoryError: ``dir_path`` is not a directory.
    """
    if dir_path is not None:
        p = Path(dir_path).resolve()
        if not p.exists():
            raise FileNotFoundError(f"Directory not found: {p}")
        if not p.is_dir():
            raise NotADirectoryError(f"Not a directory: {p}")
        base = _path_fs_metadata(p)
    else:
        base = {"xattrs": {}}

    meta = _merge_metadata(base, metadata)
    if not meta.get("name"):
        raise ValueError(
            "metadata must include 'name' when dir_path is None; "
            "with dir_path, the directory basename is used automatically"
        )

    root_hash = build_content_tree(client, child_record_hashes)

    meta["logical_size"] = logical_size
    if "xattrs" not in meta:
        meta["xattrs"] = {}

    return client.create_record(
        kind="dir",
        content=root_hash,
        metadata=meta,
        namespace=namespace,
        immutable=immutable,
    )
