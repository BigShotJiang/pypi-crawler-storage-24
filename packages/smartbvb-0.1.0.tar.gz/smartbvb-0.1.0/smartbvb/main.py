import asyncio
from playwright.async_api import async_playwright
from bs4 import BeautifulSoup
import json
import re
import sys
import os
from pathlib import Path

# ANSI Color codes
class Colors:
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'
    GRAY = '\033[90m'
    BOLD = '\033[1m'
    END = '\033[0m'
    BG_RED = '\033[41m'
    BG_GREEN = '\033[42m'
    BG_YELLOW = '\033[43m'

CONFIG_FILE = Path.home() / ".smartbvb_config.json"

def load_config():
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, 'r') as f:
                return json.load(f)
        except:
            return None
    return None

def save_config(usn, dob):
    with open(CONFIG_FILE, 'w') as f:
        json.dump({'usn': usn, 'dob': dob}, f)

def delete_config():
    if CONFIG_FILE.exists():
        try:
            CONFIG_FILE.unlink()
        except:
            pass

class KLEScraper:
    def __init__(self):
        self.base_url = "https://parents.kletech.ac.in/"
        self.usn = None
        self.dob = None
        self.student_name = None
        
        self.playwright = None
        self.browser = None
        self.page = None
        
    async def start_browser(self):
        self.playwright = await async_playwright().start()
        self.browser = await self.playwright.chromium.launch(
            headless=True,
            args=['--disable-blink-features=AutomationControlled', '--disable-sync']
        )
        self.page = await self.browser.new_page()

    async def close_browser(self):
        if self.browser:
            await self.browser.close()
        if self.playwright:
            await self.playwright.stop()

    async def check_site_status(self):
        try:
            response = await self.page.goto(self.base_url, wait_until='load', timeout=5000)
            return response and response.status == 200
        except:
            return False

    async def login(self, usn, dob):
        try:
            await self.page.goto(self.base_url, wait_until='load', timeout=10000)
            
            parts = dob.split('-')
            day, month, year = parts[0], parts[1], parts[2]
            
            await asyncio.gather(
                self.page.fill('#username', usn),
                self.page.select_option('#dd', day),
                self.page.select_option('#mm', month),
            )
            await self.page.select_option('#yyyy', year)
            await self.page.click('.cn-landing-login1')
            
            await self.page.wait_for_function(
                'document.querySelector(".cn-pay-table") !== null',
                timeout=8000
            )
            
            self.usn = usn
            self.dob = dob
            
            html = await self.page.content()
            result = self._parse_attendance(html)
            self.student_name = result.get('name', 'Unknown')
            
            return True
        except Exception as e:
            return False

    async def fetch_attendance(self):
        try:
            await self.page.goto(self.base_url, wait_until='load', timeout=10000)
            
            html = await self.page.content()
            if "cn-pay-table" not in html:
                if not await self.login(self.usn, self.dob):
                    return {'error': 'Session expired. Please try again.'}
                html = await self.page.content()
                
            result = self._parse_attendance(html)
            self.student_name = result.get('name', 'Unknown')
            return result
        except Exception as e:
            return {'error': str(e)}

    async def fetch_results(self):
        try:
            history_url = f"{self.base_url}index.php?option=com_history&task=getResult&usn={self.usn}"
            await self.page.goto(history_url, wait_until='networkidle', timeout=10000)
            
            try:
                await self.page.wait_for_selector('.credits-sec1', timeout=5000)
            except:
                pass
            
            try:
                await self.page.wait_for_selector('.result-table', timeout=5000)
            except:
                pass
            
            await asyncio.sleep(1)
            
            html = await self.page.content()
            result = self._parse_results(html)
            return result
        except Exception as e:
            return {'error': str(e)}

    def _parse_attendance(self, html):
        soup = BeautifulSoup(html, 'html.parser')
        try:
            student_name = soup.find('h3').get_text(strip=True) if soup.find('h3') else "Unknown"
            
            attendance_map = {}
            scripts = soup.find_all('script')
            
            script_count = 0
            for script in scripts:
                content = script.string
                if content and 'bb.generate' in content and 'columns' in content:
                    script_count += 1
                    if 'gauge' in content or script_count == 2:
                        regex = r'\["([A-Z0-9]+)",\s*(\d+)\]'
                        matches = re.findall(regex, content)
                        for code, percentage in matches:
                            attendance_map[code] = int(percentage)
                        break
            
            courses_list = []
            course_table = soup.find('table', {'class': 'cn-pay-table'})
            
            if course_table:
                for row in course_table.find_all('tr')[1:]:
                    cols = row.find_all('td')
                    if len(cols) >= 2:
                        code = cols[0].get_text(strip=True)
                        name = cols[1].get_text(strip=True)
                        attendance = attendance_map.get(code)
                        
                        if code and name and attendance is not None:
                            courses_list.append({
                                'code': code,
                                'name': name,
                                'attendance': attendance
                            })
            
            return {
                'usn': self.usn,
                'name': student_name,
                'courses': courses_list,
                'course_count': len(courses_list)
            }
        except Exception as e:
            return {'error': f'Parse error: {str(e)}'}

    def _parse_results(self, html):
        soup = BeautifulSoup(html, 'html.parser')
        try:
            overall_stats = self._parse_overall_stats(soup)
            semesters = []
            result_tables = soup.find_all('div', class_='result-table')
            
            for table_div in result_tables:
                header = table_div.find('h6')
                if not header:
                    continue
                
                header_text = header.get_text(strip=True)
                sem_match = re.search(r'(.*?)\s*-\s*Semester', header_text)
                sgpa_match = re.search(r'SGPA:\s*([\d.]+)', header_text)
                credits_reg_match = re.search(r'Credits\s+Registered\s*:\s*([\d.]+)', header_text)
                credits_earned_match = re.search(r'Credits\s+Earned\s*:\s*([\d.]+)', header_text)
                
                semester_name = sem_match.group(1).strip() if sem_match else "Unknown"
                sgpa = float(sgpa_match.group(1)) if sgpa_match else 0
                credits_reg = credits_reg_match.group(1) if credits_reg_match else "0"
                credits_earned = credits_earned_match.group(1) if credits_earned_match else "0"
                
                courses = []
                table = table_div.find('table', class_='uk-table')
                if table:
                    for row in table.find_all('tr')[1:]:
                        cols = row.find_all('td')
                        if len(cols) >= 6:
                            course_code = cols[0].get_text(strip=True)
                            course_name = cols[1].get_text(strip=True)
                            credits_reg_course = cols[2].get_text(strip=True)
                            credits_earned_course = cols[3].get_text(strip=True)
                            gpa = cols[4].get_text(strip=True)
                            grade = cols[5].get_text(strip=True)
                            
                            courses.append({
                                'code': course_code,
                                'name': course_name,
                                'credits_reg': credits_reg_course,
                                'credits_earned': credits_earned_course,
                                'gpa': gpa,
                                'grade': grade
                            })
                
                semesters.append({
                    'semester': semester_name,
                    'sgpa': sgpa,
                    'credits_reg': credits_reg,
                    'credits_earned': credits_earned,
                    'courses': courses
                })
            
            return {
                'usn': self.usn,
                'overall_stats': overall_stats,
                'semesters': semesters
            }
        except Exception as e:
            return {'error': f'Parse error: {str(e)}'}

    def _parse_overall_stats(self, soup):
        try:
            stats = {'cgpa': 0, 'credits_earned': 0, 'credits_to_earn': 0}
            cards = soup.find_all('div', class_='credits-sec1')
            
            for card in cards:
                header = card.find('h3')
                value_p = card.find('p')
                
                if header and value_p:
                    header_text = ' '.join(header.get_text(strip=True).lower().split())
                    value_text = value_p.get_text(strip=True)
                    
                    value = re.search(r'[\d.]+', value_text)
                    if value:
                        value_num = float(value.group())
                        if 'earned' in header_text and 'so far' in header_text:
                            stats['credits_earned'] = value_num
                        elif 'to be earned' in header_text:
                            stats['credits_to_earn'] = value_num
                        elif 'cgpa' in header_text:
                            stats['cgpa'] = value_num
            
            if stats['credits_earned'] == 0 and stats['credits_to_earn'] == 0:
                all_text = soup.get_text()
                earned_match = re.search(r'Credits\s+Earned\s+So\s+Far\s*[\s\S]*?(\d+(?:\.\d+)?)', all_text)
                if earned_match: stats['credits_earned'] = float(earned_match.group(1))
                
                to_earn_match = re.search(r'Credits\s+to\s+be\s+Earned\s*[\s\S]*?(\d+(?:\.\d+)?)', all_text)
                if to_earn_match: stats['credits_to_earn'] = float(to_earn_match.group(1))
                
                cgpa_match = re.search(r'CGPA\s*[\s\S]*?(\d+(?:\.\d+)?)', all_text)
                if cgpa_match: stats['cgpa'] = float(cgpa_match.group(1))
            
            return stats
        except Exception as e:
            return {'cgpa': 0, 'credits_earned': 0, 'credits_to_earn': 0, 'error': str(e)}

def print_header():
    print("\n" + "=" * 80)
    print(f"{Colors.BOLD}{Colors.CYAN}╔════════════════════════════════════════════════════════════════════════════════╗{Colors.END}")
    print(f"{Colors.BOLD}{Colors.CYAN}║           KLE ACADEMIC PORTAL - ATTENDANCE & RESULTS VIEWER                      ║{Colors.END}")
    print(f"{Colors.BOLD}{Colors.CYAN}╚════════════════════════════════════════════════════════════════════════════════╝{Colors.END}")
    print("=" * 80)

def print_attendance(result):
    if 'error' in result:
        print(f"\n{Colors.RED}✗ Error: {result['error']}{Colors.END}\n")
        return
    if not result.get('courses'):
        print(f"\n{Colors.RED}✗ No attendance data found{Colors.END}\n")
        return
    
    print(f"\n{Colors.BOLD}{Colors.GREEN}✓ Attendance Report{Colors.END}")
    print(f"Student: {Colors.BOLD}{result['name']}{Colors.END}")
    print(f"USN: {Colors.CYAN}{result['usn']}{Colors.END}\n")
    
    print(f"{Colors.BOLD}Course Attendance Overview:{Colors.END}\n")
    max_name_len = 45
    print(f"{'CODE':<15} {'COURSE NAME':<{max_name_len}} {'ATT':<6} {'Status'}")
    print("-" * 80)
    
    low_count = 0
    for course in result['courses']:
        code = course['code']
        name = course['name'][:max_name_len]
        att = course['attendance']
        
        if att < 75:
            color = Colors.RED + Colors.BOLD
            status = f"🔴 CRITICAL (<75%)"
            low_count += 1
        elif att < 85:
            color = Colors.YELLOW
            status = f"🟡 WARNING (75-84%)"
        else:
            color = Colors.GREEN
            status = f"🟢 GOOD (≥85%)"
        
        print(f"{code:<15} {name:<{max_name_len}} {color}{att:>3}%{Colors.END} {status}")
    
    print("-" * 80)
    print(f"Total Courses: {result['course_count']}")
    
    if low_count > 0:
        print(f"\n{Colors.BG_RED}{Colors.WHITE} ⚠️  ALERT: {low_count} subject(s) below 75% attendance {Colors.END}")
        print(f"{Colors.RED}You may NOT be eligible to write exams in these subjects!{Colors.END}\n")
    else:
        print(f"\n{Colors.GREEN}✓ All subjects have adequate attendance!{Colors.END}\n")

def print_results(result):
    if 'error' in result:
        print(f"\n{Colors.RED}✗ Error: {result['error']}{Colors.END}\n")
        return
    
    overall_stats = result.get('overall_stats', {})
    semesters = result.get('semesters', [])
    
    if not semesters:
        print(f"\n{Colors.RED}✗ No results found{Colors.END}\n")
        return
    
    print(f"\n{Colors.BOLD}{Colors.GREEN}✓ Cumulative Academic History{Colors.END}")
    print(f"USN: {Colors.CYAN}{result['usn']}{Colors.END}\n")
    
    print(f"{Colors.BOLD}{Colors.YELLOW}━━━━ OVERALL STATISTICS ━━━━{Colors.END}")
    print(f"  {Colors.BOLD}CGPA:{Colors.END} {Colors.GREEN}{overall_stats.get('cgpa', 0)}{Colors.END}")
    print(f"  {Colors.BOLD}Credits Earned So Far:{Colors.END} {Colors.CYAN}{overall_stats.get('credits_earned', 0)}{Colors.END}")
    print(f"  {Colors.BOLD}Credits to be Earned:{Colors.END} {Colors.YELLOW}{overall_stats.get('credits_to_earn', 0)}{Colors.END}")
    print(f"{Colors.YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━{Colors.END}\n")
    
    for sem in semesters:
        print(f"\n{Colors.BOLD}{Colors.CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━{Colors.END}")
        print(f"{Colors.BOLD}{Colors.YELLOW}{sem['semester']}{Colors.END}")
        print(f"{Colors.BOLD}SGPA: {Colors.GREEN}{sem['sgpa']}{Colors.END} | {Colors.BOLD}Credits Reg: {Colors.CYAN}{sem['credits_reg']}{Colors.END} | {Colors.BOLD}Credits Earned: {Colors.CYAN}{sem['credits_earned']}{Colors.END}")
        print(f"{Colors.CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━{Colors.END}")
        
        courses = sem['courses']
        if not courses:
            print(f"{Colors.GRAY}No courses found for this semester{Colors.END}\n")
            continue
        
        print(f"{'CODE':<12} {'COURSE NAME':<35} {'C.R':<5} {'C.E':<5} {'GPA':<5} {'Grade':<8}")
        print("-" * 80)
        
        for course in courses:
            code = course['code']
            name = course['name'][:33]
            cred_reg = course['credits_reg']
            cred_earned = course['credits_earned']
            gpa = course['gpa']
            grade = course['grade']
            
            grade_color = Colors.GREEN if grade == 'S' else (Colors.CYAN if grade in ['A', 'B'] else (Colors.YELLOW if grade == 'C' else (Colors.RED if grade == 'D' else Colors.GRAY)))
            print(f"{code:<12} {name:<35} {cred_reg:<5} {cred_earned:<5} {gpa:<5} {grade_color}{grade}{Colors.END}")
        print()

async def async_main():
    print_header()
    
    config = load_config()
    if not config:
        print(f"\n{Colors.BOLD}{Colors.CYAN}--- First Time Setup ---{Colors.END}")
        usn = input(f"[?] Enter USN: ").strip().upper()
        print(f"[i] Enter Date of Birth (numerical):")
        day = input(f"[?] Day (DD): ").strip().zfill(2)
        month = input(f"[?] Month (MM): ").strip().zfill(2)
        year = input(f"[?] Year (YYYY): ").strip()
        dob = f"{day}-{month}-{year}"
        
        save_config(usn, dob)
        config = {'usn': usn, 'dob': dob}
        print(f"{Colors.GREEN}✓ Credentials saved securely.{Colors.END}\n")

    scraper = KLEScraper()
    scraper.usn = config['usn']
    scraper.dob = config['dob']
    
    print(f"\n{Colors.GRAY}[*] Connecting to KLE Portal in background...{Colors.END}")
    
    await scraper.start_browser()
    
    site_up = False
    logged_in = False
    
    async def check_and_login():
        nonlocal site_up, logged_in
        if await scraper.check_site_status():
            site_up = True
            if await scraper.login(scraper.usn, scraper.dob):
                logged_in = True

    status_task = asyncio.create_task(check_and_login())
    
    chars = "/-\\|"
    i = 0
    while not status_task.done():
        sys.stdout.write(f"\r{Colors.CYAN}Setting up session... {chars[i % 4]}{Colors.END}")
        sys.stdout.flush()
        await asyncio.sleep(0.1)
        i += 1
    sys.stdout.write("\r" + " " * 40 + "\r")
    
    if not site_up:
        print(f"{Colors.BG_RED}{Colors.WHITE} ⚠️  SERVER DOWN {Colors.END}")
        print(f"{Colors.YELLOW}The KLE portal is currently unavailable.{Colors.END}")
    elif not logged_in:
        print(f"{Colors.RED}✗ Login failed! Invalid credentials or site changed.{Colors.END}")
        delete_config()
        print(f"{Colors.YELLOW}Cache cleared. Please restart the app.{Colors.END}")
        await scraper.close_browser()
        return
    else:
        print(f"{Colors.GREEN}✓ Session Established successfully!{Colors.END}")

    # Main menu loop
    while True:
        if site_up and logged_in:
            print(f"\n{Colors.BOLD}{Colors.GREEN}✓ Welcome {scraper.student_name} ({scraper.usn}){Colors.END}\n")
            print(f"{Colors.BOLD}Select an option:{Colors.END}")
            print(f"  {Colors.CYAN}1{Colors.END}. View Attendance")
            print(f"  {Colors.CYAN}2{Colors.END}. View Exam Results")
            print(f"  {Colors.CYAN}3{Colors.END}. Logout (Clear Cache)")
            print(f"  {Colors.CYAN}4{Colors.END}. Exit")
        else:
            print(f"\n{Colors.BOLD}Select an option:{Colors.END}")
            print(f"  {Colors.GRAY}1. View Attendance (Unavailable){Colors.END}")
            print(f"  {Colors.GRAY}2. View Exam Results (Unavailable){Colors.END}")
            print(f"  {Colors.CYAN}3{Colors.END}. Logout (Clear Cache)")
            print(f"  {Colors.CYAN}4{Colors.END}. Exit")

        print("-" * 80)
        
        choice = input(f"\n[?] Enter your choice (1-4): ").strip()
        
        if choice == '1':
            if not site_up or not logged_in:
                print(f"{Colors.RED}Option unavailable.{Colors.END}")
                continue
            print(f"\n{Colors.GRAY}[*] Fetching attendance data...{Colors.END}")
            result = await scraper.fetch_attendance()
            print_attendance(result)
            
        elif choice == '2':
            if not site_up or not logged_in:
                print(f"{Colors.RED}Option unavailable.{Colors.END}")
                continue
            print(f"\n{Colors.GRAY}[*] Fetching exam results...{Colors.END}")
            result = await scraper.fetch_results()
            print_results(result)
            
        elif choice == '3':
            delete_config()
            print(f"\n{Colors.GREEN}✓ Logged out successfully.{Colors.END}")
            print(f"{Colors.YELLOW}Credentials have been removed from cache.{Colors.END}")
            break
            
        elif choice == '4':
            print(f"\n{Colors.GREEN}✓ Thank you for using KLE Academic Portal!{Colors.END}")
            print("=" * 80 + "\n")
            break
            
        else:
            print(f"{Colors.RED}✗ Invalid choice.{Colors.END}")
            
        print("\n")
        
    await scraper.close_browser()

def run():
    if sys.platform == 'win32':
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    try:
        asyncio.run(async_main())
    except KeyboardInterrupt:
        print(f"\n\033[93mOperation cancelled\033[0m\n")
        sys.exit(0)
    except Exception as e:
        print(f"An error occurred: {e}")
        sys.exit(1)

if __name__ == "__main__":
    run()
