TEMPLATES_DIR = 'templates'
