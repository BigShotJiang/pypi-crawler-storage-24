"""Local job dispatcher for ReflowManager."""

import asyncio
from typing import Dict, Any, List, Optional

from reflowfy.reflow_manager.dispatcher import BaseDispatcher
from reflowfy.reflow_manager.rate_limiter import RateLimiter




class LocalDispatcher(BaseDispatcher):
    """
    Dispatches jobs locally by running them in-process.
    
    Creates a fresh WorkerExecutor for each batch to avoid asyncpg
    connection issues across event loop boundaries (each batch runs
    in its own asyncio.run() via _run_async).
    """
    
    def __init__(self, rate_limiter: RateLimiter, db_session=None):
        super().__init__(rate_limiter)
        
    def _create_executor(self):
        """Create a fresh WorkerExecutor instance."""
        from reflowfy.worker.executor import WorkerExecutor
        return WorkerExecutor()

    async def dispatch_job(
        self,
        job_payload: Dict[str, Any],
        pipeline_name: str,
        rate_limit: Optional[float] = None,
    ) -> bool:
        """Dispatch single job locally."""
        executor = self._create_executor()
        try:
            await executor.execute_job(job_payload)
            return True
        except Exception as e:
            print(f"❌ Local dispatch failed: {e}")
            return False
        finally:
            await executor.close()

    async def dispatch_jobs_batch(
        self,
        jobs: List[Dict[str, Any]],
        pipeline_name: str,
        rate_limit: Optional[float] = None,
    ) -> int:
        """Dispatch batch locally with a fresh executor."""
        executor = self._create_executor()
        count = 0
        
        try:
            for job in jobs:
                try:
                    await executor.execute_job(job)
                    count += 1
                except Exception as e:
                    print(f"❌ Local job execution failed: {e}")
        finally:
            await executor.close()
            
        return count
    
    async def close(self):
        """No persistent resources to close."""
        pass

