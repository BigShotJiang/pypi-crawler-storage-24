# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class VpcEgressRequestBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'api_version': 'ApiVersionObj',
        'kind': 'VpcEgressKindObj',
        'spec': 'VpcEgressRequestBodySpec'
    }

    attribute_map = {
        'api_version': 'api_version',
        'kind': 'kind',
        'spec': 'spec'
    }

    def __init__(self, api_version=None, kind=None, spec=None):
        r"""VpcEgressRequestBody

        The model defined in huaweicloud sdk

        :param api_version: 
        :type api_version: :class:`huaweicloudsdkcae.v1.ApiVersionObj`
        :param kind: 
        :type kind: :class:`huaweicloudsdkcae.v1.VpcEgressKindObj`
        :param spec: 
        :type spec: :class:`huaweicloudsdkcae.v1.VpcEgressRequestBodySpec`
        """
        
        

        self._api_version = None
        self._kind = None
        self._spec = None
        self.discriminator = None

        if api_version is not None:
            self.api_version = api_version
        if kind is not None:
            self.kind = kind
        if spec is not None:
            self.spec = spec

    @property
    def api_version(self):
        r"""Gets the api_version of this VpcEgressRequestBody.

        :return: The api_version of this VpcEgressRequestBody.
        :rtype: :class:`huaweicloudsdkcae.v1.ApiVersionObj`
        """
        return self._api_version

    @api_version.setter
    def api_version(self, api_version):
        r"""Sets the api_version of this VpcEgressRequestBody.

        :param api_version: The api_version of this VpcEgressRequestBody.
        :type api_version: :class:`huaweicloudsdkcae.v1.ApiVersionObj`
        """
        self._api_version = api_version

    @property
    def kind(self):
        r"""Gets the kind of this VpcEgressRequestBody.

        :return: The kind of this VpcEgressRequestBody.
        :rtype: :class:`huaweicloudsdkcae.v1.VpcEgressKindObj`
        """
        return self._kind

    @kind.setter
    def kind(self, kind):
        r"""Sets the kind of this VpcEgressRequestBody.

        :param kind: The kind of this VpcEgressRequestBody.
        :type kind: :class:`huaweicloudsdkcae.v1.VpcEgressKindObj`
        """
        self._kind = kind

    @property
    def spec(self):
        r"""Gets the spec of this VpcEgressRequestBody.

        :return: The spec of this VpcEgressRequestBody.
        :rtype: :class:`huaweicloudsdkcae.v1.VpcEgressRequestBodySpec`
        """
        return self._spec

    @spec.setter
    def spec(self, spec):
        r"""Sets the spec of this VpcEgressRequestBody.

        :param spec: The spec of this VpcEgressRequestBody.
        :type spec: :class:`huaweicloudsdkcae.v1.VpcEgressRequestBodySpec`
        """
        self._spec = spec

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, VpcEgressRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
