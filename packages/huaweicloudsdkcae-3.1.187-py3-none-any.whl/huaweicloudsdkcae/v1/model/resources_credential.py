# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ResourcesCredential:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'access': 'str',
        'secret': 'str'
    }

    attribute_map = {
        'access': 'access',
        'secret': 'secret'
    }

    def __init__(self, access=None, secret=None):
        r"""ResourcesCredential

        The model defined in huaweicloud sdk

        :param access: 用户access key，当前access key应该包含访问授权云存储的权限。
        :type access: str
        :param secret: 用户secret key，当前secret key应该包含访问授权云存储的权限。
        :type secret: str
        """
        
        

        self._access = None
        self._secret = None
        self.discriminator = None

        if access is not None:
            self.access = access
        if secret is not None:
            self.secret = secret

    @property
    def access(self):
        r"""Gets the access of this ResourcesCredential.

        用户access key，当前access key应该包含访问授权云存储的权限。

        :return: The access of this ResourcesCredential.
        :rtype: str
        """
        return self._access

    @access.setter
    def access(self, access):
        r"""Sets the access of this ResourcesCredential.

        用户access key，当前access key应该包含访问授权云存储的权限。

        :param access: The access of this ResourcesCredential.
        :type access: str
        """
        self._access = access

    @property
    def secret(self):
        r"""Gets the secret of this ResourcesCredential.

        用户secret key，当前secret key应该包含访问授权云存储的权限。

        :return: The secret of this ResourcesCredential.
        :rtype: str
        """
        return self._secret

    @secret.setter
    def secret(self, secret):
        r"""Sets the secret of this ResourcesCredential.

        用户secret key，当前secret key应该包含访问授权云存储的权限。

        :param secret: The secret of this ResourcesCredential.
        :type secret: str
        """
        self._secret = secret

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ResourcesCredential):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
