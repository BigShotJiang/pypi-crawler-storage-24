import argparse
import sys
from pathlib import Path


def _validate_output_path(path_str: str) -> Path:
    """Validate output path is safe (no traversal, writable location)."""
    path = Path(path_str).resolve()
    # Reject paths that try to escape via '..'
    if ".." in Path(path_str).parts:
        print(f"Error: Output path must not contain '..': {path_str}")
        sys.exit(1)
    # Ensure parent directory exists or can be created
    parent = path.parent
    if not parent.exists():
        print(f"Error: Output directory does not exist: {parent}")
        sys.exit(1)
    return path


def _validate_weights_dir(path_str: str) -> Path:
    """Validate weights directory exists and contains expected files."""
    path = Path(path_str).resolve()
    if not path.exists():
        print(f"Error: Weights directory does not exist: {path_str}")
        sys.exit(1)
    if not path.is_dir():
        print(f"Error: Weights path is not a directory: {path_str}")
        sys.exit(1)
    return path


def main():
    parser = argparse.ArgumentParser(description="MLX Audio Generate")
    parser.add_argument(
        "--model",
        type=str,
        required=True,
        choices=["musicgen", "stable_audio"],
        help="Model to use for generation",
    )
    parser.add_argument(
        "--prompt",
        type=str,
        required=True,
        help="Text prompt describing desired audio",
    )
    parser.add_argument(
        "--negative-prompt",
        type=str,
        default="",
        help="Negative prompt (stable_audio only)",
    )
    parser.add_argument(
        "--seconds",
        type=float,
        default=5.0,
        help="Duration in seconds",
    )
    parser.add_argument(
        "--output",
        type=str,
        default=None,
        help="Output WAV path (auto-generated if not specified)",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=None,
        help="Random seed for reproducibility",
    )
    # MusicGen-specific
    parser.add_argument("--temperature", type=float, default=1.0)
    parser.add_argument("--top-k", type=int, default=250)
    parser.add_argument("--top-p", type=float, default=0.0)
    parser.add_argument(
        "--guidance-coef",
        type=float,
        default=3.0,
        help="Classifier-free guidance coefficient (musicgen only)",
    )
    # Stable Audio-specific
    parser.add_argument(
        "--steps",
        type=int,
        default=8,
        help="Diffusion steps (stable_audio only)",
    )
    parser.add_argument(
        "--cfg-scale",
        type=float,
        default=6.0,
        help="CFG scale (stable_audio only)",
    )
    parser.add_argument(
        "--sampler",
        type=str,
        default="euler",
        choices=["euler", "rk4"],
        help="ODE sampler (stable_audio only)",
    )
    # MusicGen melody-specific
    parser.add_argument(
        "--melody",
        type=str,
        default=None,
        help="Path to audio file for melody conditioning "
        "(musicgen melody variants only)",
    )
    # MusicGen style-specific
    parser.add_argument(
        "--style-audio",
        type=str,
        default=None,
        help="Path to audio file for style conditioning (musicgen style variants only)",
    )
    parser.add_argument(
        "--style-coef",
        type=float,
        default=5.0,
        help="Style dual-CFG text influence coefficient "
        "(musicgen style variants only, default 5.0)",
    )
    # Audio-to-audio (Phase 9f)
    parser.add_argument(
        "--reference-audio",
        type=str,
        default=None,
        help="Reference audio path for audio-to-audio (stable_audio)",
    )
    parser.add_argument(
        "--reference-strength",
        type=float,
        default=0.7,
        help="Deviation from reference (0=copy, 1=random, default 0.7)",
    )
    # General
    parser.add_argument(
        "--weights-dir",
        type=str,
        default=None,
        help="Path to converted weights directory",
    )
    parser.add_argument(
        "--lora",
        type=str,
        default=None,
        help="LoRA adapter name (from ~/.mlx-audiogen/loras/)",
    )
    parser.add_argument(
        "--lora-path",
        type=str,
        default=None,
        help="Explicit path to LoRA adapter directory",
    )

    args = parser.parse_args()

    # --- Validate inputs ---
    # C3: Validate weights directory
    if args.weights_dir is not None:
        weights_dir = str(_validate_weights_dir(args.weights_dir))
    else:
        weights_dir = None

    # M2: Validate numeric ranges
    if args.seconds <= 0 or args.seconds > 300:
        print("Error: --seconds must be between 0 and 300")
        sys.exit(1)
    if args.temperature <= 0:
        print("Error: --temperature must be positive")
        sys.exit(1)
    if args.top_k < 1:
        print("Error: --top-k must be at least 1")
        sys.exit(1)
    if args.steps < 1 or args.steps > 1000:
        print("Error: --steps must be between 1 and 1000")
        sys.exit(1)
    if args.cfg_scale < 0:
        print("Error: --cfg-scale must be non-negative")
        sys.exit(1)
    if args.guidance_coef < 0:
        print("Error: --guidance-coef must be non-negative")
        sys.exit(1)

    # Validate melody path if provided
    if args.melody is not None:
        melody_file = Path(args.melody).resolve()
        if not melody_file.is_file():
            print(f"Error: Melody audio file not found: {args.melody}")
            sys.exit(1)
        if ".." in Path(args.melody).parts:
            print("Error: Melody path must not contain '..'")
            sys.exit(1)

    # Validate style audio path if provided
    if args.style_audio is not None:
        style_file = Path(args.style_audio).resolve()
        if not style_file.is_file():
            print(f"Error: Style audio file not found: {args.style_audio}")
            sys.exit(1)
        if ".." in Path(args.style_audio).parts:
            print("Error: Style audio path must not contain '..'")
            sys.exit(1)
    if args.style_coef < 0:
        print("Error: --style-coef must be non-negative")
        sys.exit(1)

    # Validate reference audio path if provided
    if args.reference_audio is not None:
        ref_file = Path(args.reference_audio).resolve()
        if not ref_file.is_file():
            print(f"Error: Reference audio file not found: {args.reference_audio}")
            sys.exit(1)
        if ".." in Path(args.reference_audio).parts:
            print("Error: Reference audio path must not contain '..'")
            sys.exit(1)
    if args.reference_strength < 0 or args.reference_strength > 1:
        print("Error: --reference-strength must be between 0.0 and 1.0")
        sys.exit(1)

    if args.model == "stable_audio":
        from mlx_audiogen.models.stable_audio import StableAudioPipeline

        pipe = StableAudioPipeline.from_pretrained(weights_dir)

        # Load reference audio for audio-to-audio
        ref_audio_mx = None
        if args.reference_audio:
            import mlx.core as mx

            from mlx_audiogen.shared.audio_io import load_wav

            ref_np, ref_sr = load_wav(args.reference_audio)
            # Simple resample to 44.1kHz if needed
            if ref_sr != 44100:
                import numpy as np

                target_len = int(len(ref_np) * 44100 / ref_sr)
                ref_np = np.interp(
                    np.linspace(0, len(ref_np) - 1, target_len),
                    np.arange(len(ref_np)),
                    ref_np,
                )
            ref_audio_mx = mx.array(ref_np).reshape(1, 1, -1)

        audio = pipe.generate(
            prompt=args.prompt,
            negative_prompt=args.negative_prompt,
            seconds_total=args.seconds,
            steps=args.steps,
            cfg_scale=args.cfg_scale,
            seed=args.seed,
            sampler=args.sampler,
            reference_audio=ref_audio_mx,
            reference_strength=args.reference_strength,
        )
        sample_rate = 44100
        channels = 2
    elif args.model == "musicgen":
        from mlx_audiogen.models.musicgen import MusicGenPipeline

        pipe = MusicGenPipeline.from_pretrained(weights_dir)

        # Load LoRA if specified
        if args.lora or args.lora_path:
            from mlx_audiogen.lora.config import DEFAULT_LORAS_DIR
            from mlx_audiogen.lora.inject import apply_lora
            from mlx_audiogen.lora.trainer import load_lora_config
            from mlx_audiogen.shared.hub import load_safetensors

            if args.lora_path:
                lora_dir = Path(args.lora_path)
            else:
                lora_dir = DEFAULT_LORAS_DIR / args.lora

            if not lora_dir.is_dir():
                print(f"Error: LoRA directory not found: {lora_dir}")
                sys.exit(1)

            lora_config = load_lora_config(lora_dir)

            # Validate compatibility
            model_hidden = pipe.config.decoder.hidden_size
            if lora_config.hidden_size != model_hidden:
                print(
                    f"Error: LoRA hidden_size "
                    f"({lora_config.hidden_size}) doesn't match "
                    f"model ({model_hidden})."
                )
                sys.exit(1)

            print(f"Loading LoRA: {lora_config.name} (rank={lora_config.rank})")
            apply_lora(
                pipe.model,
                targets=lora_config.targets,
                rank=lora_config.rank,
                alpha=lora_config.alpha,
            )
            lora_weights = load_safetensors(lora_dir / "lora.safetensors")
            pipe.model.load_weights(
                [(k, mx.array(v)) for k, v in lora_weights.items()],
                strict=False,
            )
            print(f"LoRA loaded: {lora_config.name}")

        audio = pipe.generate(
            prompt=args.prompt,
            seconds=args.seconds,
            temperature=args.temperature,
            top_k=args.top_k,
            guidance_coef=args.guidance_coef,
            seed=args.seed,
            melody_path=args.melody,
            style_audio_path=args.style_audio,
            style_coef=args.style_coef,
        )
        sample_rate = pipe.sample_rate
        channels = 1

    # C1: Validate output path
    output_str = args.output or f"{args.model}_output.wav"
    output_path = _validate_output_path(output_str)

    from mlx_audiogen.shared.audio_io import save_wav

    save_wav(str(output_path), audio, sample_rate=sample_rate, channels=channels)
    print(f"Saved audio to {output_path}")


if __name__ == "__main__":
    main()
