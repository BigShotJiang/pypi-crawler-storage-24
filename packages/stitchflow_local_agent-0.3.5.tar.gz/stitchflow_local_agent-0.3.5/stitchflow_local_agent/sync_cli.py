#!/usr/bin/env python3
"""Stitchflow data-sync CLI (setup, run, daemon, status)."""

from __future__ import annotations

import asyncio
import json
import os
import pathlib
import platform
import shutil
import signal
import subprocess
import sys
from datetime import datetime, timezone
from typing import Any

from stitchflow_local_agent.common import config
from stitchflow_local_agent.common.browser import BrowserManager
from stitchflow_local_agent.common.daemon import (
    acquire_pid_file,
    release_pid_file,
)
from stitchflow_local_agent.common.logging import append_jsonl
from stitchflow_local_agent.sync.calendly.export import (
    CALENDLY_ADMIN_USERS_URL,
    CALENDLY_DOWNLOAD_DIR,
    EXPORT_LOG_PATH as CALENDLY_EXPORT_LOG_PATH,
    cleanup_old_csvs as cleanup_old_calendly_csvs,
    export_calendly_users,
)
from stitchflow_local_agent.sync.chatgpt.export import (
    CHATGPT_ADMIN_URL,
    CHATGPT_DOWNLOAD_DIR,
    EXPORT_LOG_PATH as CHATGPT_EXPORT_LOG_PATH,
    cleanup_old_csvs as cleanup_old_chatgpt_csvs,
    export_chatgpt_users,
)
from stitchflow_local_agent.sync.linear.export import (
    LINEAR_DOWNLOAD_DIR,
    LINEAR_MEMBERS_URL,
    EXPORT_LOG_PATH as LINEAR_EXPORT_LOG_PATH,
    cleanup_old_csvs as cleanup_old_linear_csvs,
    export_linear_users,
)
from stitchflow_local_agent.sync.stitchflow_upload import (
    get_sync_app_base_url,
    get_workspace_connections_url,
    upload_csv_to_stitchflow,
)

SYNC_LOG_PATH = config.LOGS_DIR / "data-sync.log"
AUDIT_LOG_PATH = config.LOGS_DIR / "data-sync-audit.jsonl"
DAEMON_LOG_PATH = config.LOGS_DIR / "data-sync-daemon.log"
PID_FILE_PATH = config.STITCHFLOW_HOME_DIR / "data-sync-daemon.pid"
SYNC_CONFIG_DIR = config.STITCHFLOW_HOME_DIR / "sync"
SYNC_ENV_FILE = SYNC_CONFIG_DIR / "sync.env"
LAUNCHD_LABEL = "com.stitchflow.data-sync"

_LAUNCHD_PLIST_TEMPLATE = """<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>{label}</string>
  <key>ProgramArguments</key>
  <array>
    <string>/bin/zsh</string>
    <string>-lc</string>
    <string>[ -f "{sync_env}" ] &amp;&amp; source "{sync_env}"; "{python_bin}" -m stitchflow_local_agent.sync_cli run &gt;&gt; "{sync_log}" 2&gt;&amp;1</string>
  </array>
  <key>StartInterval</key>
  <integer>{interval_seconds}</integer>
  <key>RunAtLoad</key>
  <true/>
  <key>StandardOutPath</key>
  <string>{stdout_log}</string>
  <key>StandardErrorPath</key>
  <string>{stderr_log}</string>
</dict>
</plist>
"""


def _format_interval(seconds: int) -> str:
    if seconds >= 3600:
        return f"{seconds}s ({seconds // 3600}h)"
    return f"{seconds}s ({seconds // 60}m)"


def _ensure_dirs() -> None:
    config.ensure_dirs()
    SYNC_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CALENDLY_DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    CHATGPT_DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    LINEAR_DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)


def _load_sync_env_into_environ() -> None:
    """Load sync-specific env vars before config.init_config()."""
    if not SYNC_ENV_FILE.exists():
        return
    try:
        for raw_line in SYNC_ENV_FILE.read_text().splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("export "):
                line = line[len("export ") :]
            if "=" not in line:
                continue
            key, value = line.split("=", 1)
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            if key and key not in os.environ:
                os.environ[key] = value
    except Exception as exc:
        print(f"WARNING: Could not load sync env file: {exc}")


def _normalize_app_url(url_value: str) -> str:
    value = (url_value or "").strip()
    if not value:
        return get_sync_app_base_url()
    if "://" not in value:
        value = f"https://{value}"
    return value.rstrip("/")


def _persist_sync_env(workspace_id: str, app_url: str) -> None:
    """Persist sync-specific config independent from agent.env."""
    SYNC_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    lines = [
        f'export STITCHFLOW_WORKSPACE_ID="{workspace_id}"',
        f'export STITCHFLOW_SYNC_APP_URL="{app_url}"',
        f'export STITCHFLOW_SYNC_INTERVAL_SECONDS="{config.SYNC_INTERVAL_SECONDS}"',
    ]
    SYNC_ENV_FILE.write_text("\n".join(lines) + "\n")
    os.chmod(SYNC_ENV_FILE, 0o600)


def _prompt_sync_target() -> tuple[str, str]:
    workspace_default = config.WORKSPACE_ID.strip()
    while True:
        prompt = (
            f"  STITCHFLOW_WORKSPACE_ID [{workspace_default}]: "
            if workspace_default
            else "  STITCHFLOW_WORKSPACE_ID [required]: "
        )
        workspace_input = input(prompt).strip()
        workspace_id = (workspace_input or workspace_default).strip().strip("/")
        if workspace_id:
            break
        print("  STITCHFLOW_WORKSPACE_ID is required for data sync uploads.")

    app_url_default = get_sync_app_base_url()
    app_url_input = input(f"  STITCHFLOW_SYNC_APP_URL [{app_url_default}]: ").strip()
    app_url = _normalize_app_url(app_url_input or app_url_default)
    return workspace_id, app_url


def configure_target() -> None:
    """Update sync target URL/workspace without rerunning full setup."""
    _ensure_dirs()
    print("Configure sync target (Stitchflow URL + workspace)...")
    workspace_id, app_url = _prompt_sync_target()
    config.WORKSPACE_ID = workspace_id
    os.environ["STITCHFLOW_WORKSPACE_ID"] = workspace_id
    os.environ["STITCHFLOW_SYNC_APP_URL"] = app_url
    _persist_sync_env(workspace_id, app_url)
    print("\nSaved sync target configuration.")
    print(f"  Workspace ID:     {workspace_id}")
    print(f"  Stitchflow URL:   {app_url}")
    print(f"  Sync env file:    {SYNC_ENV_FILE}")
    print("\nRun 'stitchflow-sync setup' to refresh logins for this target if needed.")


def _auto_enable_scheduler() -> bool:
    """Auto-enable OS scheduler for data sync after setup."""
    if platform.system() == "Darwin":
        launchctl_bin = shutil.which("launchctl") or ("/bin/launchctl" if pathlib.Path("/bin/launchctl").exists() else None)
        if not launchctl_bin:
            print("\nWARNING: launchctl is not available on this macOS host.")
            print("  launchd is built into macOS and cannot be installed by stitchflow-sync.")
            print("  Ask IT to enable launchctl access or run foreground mode: stitchflow-sync daemon")
            return False

        plist_path = pathlib.Path.home() / "Library" / "LaunchAgents" / f"{LAUNCHD_LABEL}.plist"
        plist_path.parent.mkdir(parents=True, exist_ok=True)

        try:
            content = _LAUNCHD_PLIST_TEMPLATE.format(
                label=LAUNCHD_LABEL,
                sync_env=SYNC_ENV_FILE,
                python_bin=sys.executable,
                sync_log=SYNC_LOG_PATH,
                interval_seconds=config.SYNC_INTERVAL_SECONDS,
                stdout_log=config.LOGS_DIR / "data-sync.out.log",
                stderr_log=config.LOGS_DIR / "data-sync.err.log",
            )
            plist_path.write_text(content)

            # Reload if already present.
            subprocess.run([launchctl_bin, "unload", str(plist_path)], check=False, capture_output=True)
            subprocess.run([launchctl_bin, "load", str(plist_path)], check=True)

            print("\nAuto-enabled launchd scheduler for data sync.")
            print(f"  LaunchAgent: {plist_path}")
            print("  It runs in background automatically at login and every sync interval.")
            return True
        except Exception as exc:
            print(f"\nWARNING: Failed to auto-enable launchd scheduler: {exc}")
            return False

    if platform.system() == "Windows":
        root_dir = pathlib.Path(__file__).resolve().parent.parent
        script = root_dir / "windows" / "register-task-data-sync.ps1"
        if not script.exists():
            print("\nWARNING: Task Scheduler script not found; skipping auto scheduler install.")
            return False
        try:
            subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-ExecutionPolicy",
                    "Bypass",
                    "-File",
                    str(script),
                ],
                input="\n",
                text=True,
                check=True,
            )
            print("\nAuto-enabled Task Scheduler for data sync.")
            return True
        except Exception as exc:
            print(f"\nWARNING: Failed to auto-enable Task Scheduler: {exc}")
            print("  You can run windows/register-task-data-sync.ps1 manually.")
            return False

    print("\nScheduler auto-install is not implemented for this OS.")
    return False


def _print_scheduler_status() -> None:
    """Print OS scheduler status for data sync."""
    system = platform.system()
    if system == "Darwin":
        launchctl_bin = shutil.which("launchctl") or ("/bin/launchctl" if pathlib.Path("/bin/launchctl").exists() else None)
        if not launchctl_bin:
            print("Scheduler:           launchd unavailable (launchctl not found)")
            return
        try:
            result = subprocess.run(
                [launchctl_bin, "list", LAUNCHD_LABEL],
                capture_output=True,
                text=True,
                check=False,
            )
            if result.returncode == 0:
                print(f"Scheduler:           launchd loaded ({LAUNCHD_LABEL})")
            else:
                print(f"Scheduler:           launchd not loaded ({LAUNCHD_LABEL})")
        except Exception:
            print("Scheduler:           launchd status check failed")
        return

    if system == "Windows":
        print("Scheduler:           Task Scheduler (check task: StitchflowDataSync)")
        return

    print("Scheduler:           not configured for this OS")


def _send_system_notification(title: str, message: str) -> None:
    """Best-effort desktop notification across supported OSes."""
    system = platform.system()
    try:
        if system == "Darwin":
            safe_title = title.replace('"', '\\"')
            safe_msg = message.replace('"', '\\"')
            subprocess.run(
                ["osascript", "-e", f'display notification "{safe_msg}" with title "{safe_title}"'],
                check=False,
                capture_output=True,
            )
            return
        if system == "Linux" and shutil.which("notify-send"):
            subprocess.run(["notify-send", title, message], check=False, capture_output=True)
            return
        if system == "Windows":
            ps_script = (
                "Add-Type -AssemblyName System.Windows.Forms; "
                f"[System.Windows.Forms.MessageBox]::Show('{message}', '{title}') | Out-Null"
            )
            subprocess.run(
                ["powershell", "-NoProfile", "-Command", ps_script],
                check=False,
                capture_output=True,
            )
            return
    except Exception:
        pass


def _notify_sync_failure(app_name: str, reason: str) -> None:
    title = f"Stitchflow sync failed: {app_name}"
    message = (
        f"{app_name} data sync failed ({reason}). Please contact Stitchflow support, "
        "or re-login by running 'stitchflow-sync setup' (auth may be expired)."
    )
    _send_system_notification(title, message)


def _sync_app(
    app_name: str,
    export_fn: Any,
    cleanup_fn: Any,
    started_at: str,
    driver: Any,
) -> bool:
    """Run export -> upload -> log for a single app. Returns True on success."""
    app_lower = app_name.lower()

    csv_path = export_fn(driver)
    if not csv_path:
        ended_at = datetime.now(timezone.utc).isoformat()
        append_jsonl(
            SYNC_LOG_PATH,
            {
                "started_at": started_at,
                "ended_at": ended_at,
                "status": "failed",
                "step": f"{app_lower}_export",
                "app": app_lower,
                "error": f"Failed to export CSV from {app_name}",
            },
        )
        append_jsonl(
            AUDIT_LOG_PATH,
            {
                "timestamp": ended_at,
                "app": app_lower,
                "status": "failed",
                "error": f"Failed to export CSV from {app_name}",
            },
        )
        _notify_sync_failure(app_name, "export failed")
        return False

    upload_result = upload_csv_to_stitchflow(driver, csv_path, app_name=app_name)
    ended_at = datetime.now(timezone.utc).isoformat()

    if upload_result.get("status") == "connected":
        cleanup_fn()
        append_jsonl(
            SYNC_LOG_PATH,
            {
                "started_at": started_at,
                "ended_at": ended_at,
                "status": "success",
                "csv_path": csv_path,
                "app": app_lower,
            },
        )
        append_jsonl(
            AUDIT_LOG_PATH,
            {
                "timestamp": ended_at,
                "app": app_lower,
                "status": "success",
                "csv_uploaded": csv_path,
            },
        )
        print(f"\n{app_name} sync completed successfully")
        return True

    error_msg = upload_result.get("error", "Unknown upload failure")
    append_jsonl(
        SYNC_LOG_PATH,
        {
            "started_at": started_at,
            "ended_at": ended_at,
            "status": "failed",
            "step": "stitchflow_upload",
            "csv_path": csv_path,
            "app": app_lower,
            "error": error_msg,
        },
    )
    append_jsonl(
        AUDIT_LOG_PATH,
        {
            "timestamp": ended_at,
            "app": app_lower,
            "status": "failed",
            "error": error_msg,
        },
    )
    _notify_sync_failure(app_name, error_msg)
    print(f"\n{app_name} sync failed: {error_msg}")
    return False


def run_sync() -> bool:
    """Execute one full sync cycle for all configured apps."""
    started_at = datetime.now(timezone.utc).isoformat()
    print(f"\n{'=' * 60}")
    print(f"Data sync started at {started_at}")
    print(f"{'=' * 60}")

    mgr = BrowserManager()

    try:
        driver = mgr.initialize(
            integration="sync",
            profile_dir=config.BROWSER_PROFILE_DIR,
            headless=False,
            download_dir=str(CALENDLY_DOWNLOAD_DIR),
        )

        results: list[bool] = []

        results.append(
            _sync_app(
                "Calendly",
                export_calendly_users,
                cleanup_old_calendly_csvs,
                started_at,
                driver,
            )
        )

        results.append(
            _sync_app(
                "ChatGPT",
                export_chatgpt_users,
                cleanup_old_chatgpt_csvs,
                started_at,
                driver,
            )
        )
        results.append(
            _sync_app(
                "Linear",
                export_linear_users,
                cleanup_old_linear_csvs,
                started_at,
                driver,
            )
        )

        all_ok = all(results)
        print(f"\nSync cycle finished — {sum(results)}/{len(results)} succeeded")
        return all_ok
    finally:
        mgr.shutdown()


async def run_daemon() -> None:
    if not config.WORKSPACE_ID:
        print("ERROR: STITCHFLOW_WORKSPACE_ID not set. Run 'stitchflow-sync setup'.")
        sys.exit(1)
    if not acquire_pid_file(PID_FILE_PATH):
        sys.exit(1)
    _ensure_dirs()

    loop = asyncio.get_running_loop()
    shutdown_event = asyncio.Event()

    def _handle_sigterm() -> None:
        print("\nReceived shutdown signal, stopping daemon...")
        shutdown_event.set()

    loop.add_signal_handler(signal.SIGTERM, _handle_sigterm)
    loop.add_signal_handler(signal.SIGINT, _handle_sigterm)

    interval_label = _format_interval(config.SYNC_INTERVAL_SECONDS)
    print(f"Sync daemon started (interval: {interval_label}). Press Ctrl+C to stop.")
    cycle = 0
    try:
        while not shutdown_event.is_set():
            cycle += 1
            print(f"\n-- sync cycle {cycle} --")
            try:
                await asyncio.to_thread(run_sync)
            except Exception as exc:
                print(f"Sync cycle error: {exc}")
            print(f"Sleeping {config.SYNC_INTERVAL_SECONDS}s until next sync...")
            try:
                await asyncio.wait_for(shutdown_event.wait(), timeout=config.SYNC_INTERVAL_SECONDS)
            except asyncio.TimeoutError:
                pass
        print("Daemon stopped.")
    finally:
        release_pid_file(PID_FILE_PATH)


def run_once() -> None:
    if not config.WORKSPACE_ID:
        print("ERROR: STITCHFLOW_WORKSPACE_ID not set. Run 'stitchflow-sync setup'.")
        sys.exit(1)
    _ensure_dirs()
    success = run_sync()
    sys.exit(0 if success else 1)


def setup() -> None:
    print("Running data sync setup...")
    _ensure_dirs()
    workspace_id, app_url = _prompt_sync_target()

    config.WORKSPACE_ID = workspace_id
    os.environ["STITCHFLOW_WORKSPACE_ID"] = workspace_id
    os.environ["STITCHFLOW_SYNC_APP_URL"] = app_url
    _persist_sync_env(workspace_id, app_url)
    print(f"Saved sync config to: {SYNC_ENV_FILE}")

    mgr = BrowserManager()

    step = 1

    print(f"\nStep {step}: Log into Calendly")
    print("A browser will open. Please log into your Calendly admin account.")
    driver = mgr.initialize(integration="sync", profile_dir=config.BROWSER_PROFILE_DIR, headless=False)
    driver.get(CALENDLY_ADMIN_USERS_URL)
    input("Press Enter after you have logged into Calendly and see the admin users page...")
    step += 1

    print(f"\nStep {step}: Log into ChatGPT")
    print("The browser will navigate to the ChatGPT admin page. Please log in if needed.")
    print("(The account/workspace ID will be auto-discovered from the admin page.)")
    driver.get(CHATGPT_ADMIN_URL)
    input("Press Enter after you have logged into ChatGPT...")
    step += 1

    print(f"\nStep {step}: Log into Linear")
    print("The browser will navigate to the Linear members page. Please log in if needed.")
    driver.get(LINEAR_MEMBERS_URL)
    input("Press Enter after you have logged into Linear and see the members page...")
    step += 1

    print(f"\nStep {step}: Log into Stitchflow")
    workspace_connections_url = get_workspace_connections_url()
    print("The browser will now navigate to your selected Stitchflow workspace.")
    print(f"Target workspace URL: {workspace_connections_url}")
    driver.get(workspace_connections_url)
    input("Press Enter after you have logged into Stitchflow and see the connections page...")

    mgr.shutdown()
    scheduler_enabled = _auto_enable_scheduler()

    print("\nSetup complete. Sessions saved to browser profile.")
    print(f"  Profile:         {config.BROWSER_PROFILE_DIR}")
    print(f"  Sync env file:   {SYNC_ENV_FILE}")
    print(f"  Stitchflow URL:  {get_sync_app_base_url()}")
    print(f"  Workspace ID:    {config.WORKSPACE_ID}")
    print(f"  Calendly CSVs:   {CALENDLY_DOWNLOAD_DIR}")
    print(f"  ChatGPT CSVs:    {CHATGPT_DOWNLOAD_DIR}")
    print(f"  Linear CSVs:     {LINEAR_DOWNLOAD_DIR}")
    print("\nRun 'stitchflow-sync run' for a one-time sync.")
    if scheduler_enabled:
        print("Background daily sync is enabled via the OS scheduler.")
    else:
        print("Background daily sync was not auto-enabled; run 'stitchflow-sync daemon' in foreground for now.")
    print("Use 'stitchflow-sync status' to verify daemon status and recent audit logs.")


def _print_export_log(log_path: pathlib.Path, label: str) -> None:
    """Print the last 5 entries from a JSONL export log."""
    if not log_path.exists():
        return
    try:
        lines = log_path.read_text().strip().splitlines()
        if not lines:
            return
        print(f"\n{label} (last 5 of {len(lines)}):")
        for line in lines[-5:]:
            entry = json.loads(line)
            ts = entry.get("timestamp", "?")
            st = entry.get("status", "?")
            if st == "success":
                csv_f = pathlib.Path(entry.get("csv_path", "")).name
                size = entry.get("csv_size_bytes", "?")
                extra = ""
                if entry.get("user_count"):
                    extra = f", {entry['user_count']} users"
                print(f"  [{ts}] {st} - {csv_f} ({size} bytes{extra})")
            else:
                err = entry.get("error", "unknown error")
                print(f"  [{ts}] {st} - {err}")
    except Exception:
        pass


def status() -> None:
    _ensure_dirs()
    print(f"Profile path:        {config.BROWSER_PROFILE_DIR}")
    print(f"Profile exists:      {config.BROWSER_PROFILE_DIR.exists()}")
    print(f"Stitchflow URL:      {get_sync_app_base_url()}")
    print(f"Workspace ID:        {config.WORKSPACE_ID or '(not set)'}")
    print(f"Sync env file:       {SYNC_ENV_FILE} (exists={SYNC_ENV_FILE.exists()})")
    print(f"ChatGPT account ID:  {config.CHATGPT_ACCOUNT_ID or '(auto-discovered)'}")
    print(f"Sync interval:       {_format_interval(config.SYNC_INTERVAL_SECONDS)}")
    print(f"Calendly CSV dir:    {CALENDLY_DOWNLOAD_DIR}")
    print(f"ChatGPT CSV dir:     {CHATGPT_DOWNLOAD_DIR}")
    print(f"Log file:            {SYNC_LOG_PATH}")
    print(f"Daemon log:          {DAEMON_LOG_PATH}")
    print(f"Audit log:           {AUDIT_LOG_PATH}")
    print(f"PID file:            {PID_FILE_PATH}")
    _print_scheduler_status()

    if SYNC_LOG_PATH.exists():
        try:
            lines = SYNC_LOG_PATH.read_text().strip().splitlines()
            if lines:
                last = json.loads(lines[-1])
                print("\nLast sync:")
                print(f"  App:       {last.get('app', 'unknown')}")
                print(f"  Status:    {last.get('status', 'unknown')}")
                print(f"  Started:   {last.get('started_at', 'unknown')}")
                print(f"  Ended:     {last.get('ended_at', 'unknown')}")
                if last.get("csv_path"):
                    print(f"  CSV:       {last['csv_path']}")
                if last.get("error"):
                    print(f"  Error:     {last['error']}")
        except Exception:
            pass

    _print_export_log(CALENDLY_EXPORT_LOG_PATH, "Calendly export log")
    _print_export_log(CHATGPT_EXPORT_LOG_PATH, "ChatGPT export log")
    _print_export_log(LINEAR_EXPORT_LOG_PATH, "Linear export log")

    if AUDIT_LOG_PATH.exists():
        try:
            lines = AUDIT_LOG_PATH.read_text().strip().splitlines()
            if lines:
                print(f"\nStitchflow upload audit (last 5 of {len(lines)}):")
                for line in lines[-5:]:
                    entry = json.loads(line)
                    ts = entry.get("timestamp", "?")
                    st = entry.get("status", "?")
                    app = entry.get("app", "?")
                    if st == "success":
                        csv_f = pathlib.Path(entry.get("csv_uploaded", "")).name
                        print(f"  [{ts}] {app} {st} - uploaded {csv_f}")
                    else:
                        err = entry.get("error", "unknown error")
                        print(f"  [{ts}] {app} {st} - {err}")
        except Exception:
            pass

    for label, directory, pattern in [
        ("Calendly", CALENDLY_DOWNLOAD_DIR, "calendly_users_*.csv"),
        ("ChatGPT", CHATGPT_DOWNLOAD_DIR, "chatgpt_users_*.csv"),
        ("Linear", LINEAR_DOWNLOAD_DIR, "linear_users_*.csv"),
    ]:
        csv_files = sorted(
            directory.glob(pattern),
            key=lambda f: f.stat().st_mtime,
            reverse=True,
        )
        if csv_files:
            print(f"\nRecent {label} CSVs ({len(csv_files)}):")
            for f in csv_files[:5]:
                print(f"  {f.name} ({f.stat().st_size} bytes)")

    if PID_FILE_PATH.exists():
        try:
            pid = int(PID_FILE_PATH.read_text().strip())
            try:
                os.kill(pid, 0)
                print(f"\nDaemon: running (pid {pid})")
            except OSError:
                print(f"\nDaemon: stale PID file (pid {pid} not running)")
        except (ValueError, OSError):
            print("\nDaemon: invalid PID file")
    else:
        print("\nDaemon: not running")
        print("  Note: this PID check reflects foreground daemon mode.")
        print("  If Scheduler shows loaded, background sync is still active via OS scheduler.")


def main() -> None:
    try:
        sys.stdout.reconfigure(line_buffering=True)  # type: ignore[attr-defined]
        sys.stderr.reconfigure(line_buffering=True)  # type: ignore[attr-defined]
    except Exception:
        pass

    _load_sync_env_into_environ()
    config.init_config()

    if len(sys.argv) < 2:
        print("Stitchflow Data Sync v0.1")
        print("Usage:")
        print("  stitchflow-sync setup   One-time login to Calendly, ChatGPT, Linear & Stitchflow")
        print("  stitchflow-sync target  Update Stitchflow URL and workspace ID")
        print("  stitchflow-sync run     Run a single sync cycle")
        print("  stitchflow-sync daemon  Start the daily sync daemon")
        print("  stitchflow-sync status  Show config and last sync info")
        return

    command = sys.argv[1]
    if command == "setup":
        setup()
    elif command == "target":
        configure_target()
    elif command == "run":
        run_once()
    elif command == "daemon":
        try:
            asyncio.run(run_daemon())
        except KeyboardInterrupt:
            print("\nDaemon stopped.")
    elif command == "status":
        status()
    else:
        print(f"Unknown command: {command}")
        sys.exit(1)


if __name__ == "__main__":
    main()
