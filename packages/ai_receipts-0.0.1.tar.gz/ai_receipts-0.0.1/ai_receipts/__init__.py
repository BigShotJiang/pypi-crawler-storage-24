"""
ai-receipts — this package has been renamed to `aiir`.

Install the real package:
    pip install aiir

Usage:
    import aiir
    # or: from aiir import ReceiptEmitter, verify_receipt, verify_chain
"""

import warnings as _w

_w.warn(
    "ai-receipts has been renamed to 'aiir'. "
    "Please run: pip install aiir && pip uninstall ai-receipts",
    DeprecationWarning,
    stacklevel=2,
)

try:
    from aiir import *  # noqa: F401, F403
    from aiir import __version__
except ImportError:
    __version__ = "0.0.1"
