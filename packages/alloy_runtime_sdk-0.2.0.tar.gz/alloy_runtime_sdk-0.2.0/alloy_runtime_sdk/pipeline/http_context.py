"""HttpPipelineContext - HTTP-based implementation of PipelineContext.

This context implementation uses the ApiClient to make HTTP calls
to the Alloy Runtime server. It runs inside Modal sandboxes.
"""

import re

from collections.abc import Awaitable
from typing import Any, cast
from uuid import UUID

from alloy_runtime_sdk.api_client.client import ApiClient
from alloy_runtime_types.dtos.generation import (
    AgentSource,
    DirectModelSource,
    GenerateTextRequest,
    GenerationParameters,
    SchemaReference,
)
from alloy_runtime_types.enums.provider import Provider

from alloy_runtime_sdk.pipeline.exceptions import ApprovalPendingException
from alloy_runtime_sdk.pipeline.types import (
    ApprovalResult,
    CostBreakdown,
    GenerateTextResult,
    TokenUsage,
)


_ID_COMPONENT_PATTERN = re.compile(r"^[a-zA-Z0-9_.-]+$")


class ConfigNamespace:
    """Converts a dict to a namespace object for dot-access.

    Allows users to access config like: config.synthesis.agents
    instead of: config["synthesis"]["agents"]
    """

    def __init__(self, data: dict[str, Any]):
        for key, value in data.items():
            if isinstance(value, dict):
                setattr(self, key, ConfigNamespace(cast(dict[str, Any], value)))
            else:
                setattr(self, key, value)

    def __repr__(self) -> str:
        return f"ConfigNamespace({vars(self)})"


class HttpPipelineContext:
    """HTTP-based implementation of PipelineContext.

    This context runs inside Modal sandboxes and uses the ApiClient
    to make HTTP calls back to the Alloy Runtime server.

    Attributes:
        config: Runtime configuration converted to dot-access namespace.
        execution_id: UUID of this pipeline execution.
    """

    def __init__(
        self,
        *,
        api_key: str,
        server_url: str,
        execution_id: UUID,
        config: dict[str, Any],
    ):
        self._api_key = api_key
        self._server_url = server_url
        self._execution_id = execution_id
        self._config = ConfigNamespace(config) if config else ConfigNamespace({})
        self._client = ApiClient(base_url=server_url, api_key=api_key)
        self._step_counter: int = 0
        self._used_step_ids: set[str] = set()
        self._approval_counter: int = 0
        self._used_approval_ids: set[str] = set()

    @property
    def config(self) -> ConfigNamespace:
        """Runtime configuration passed at execution.

        Converted to namespace for dot-access: config.synthesis.agents
        """
        return self._config

    @property
    def execution_id(self) -> UUID:
        """Unique identifier for this pipeline execution."""
        return self._execution_id

    async def generate_text(
        self,
        *,
        step_id: str | None = None,
        agent: str | UUID | None = None,
        model_source: dict[str, Any] | None = None,
        user_message: str | None = None,
        user_message_template: str | UUID | None = None,
        user_message_variables: dict[str, Any] | None = None,
        system_instruction: str | None = None,
        system_instruction_template: str | UUID | None = None,
        system_instruction_variables: dict[str, Any] | None = None,
        output_schema: str | UUID | None = None,
        tags: list[str] | None = None,
    ) -> GenerateTextResult:
        """Generate text using an agent or direct model.

        Makes an HTTP request to the server's generate_text endpoint.
        """
        if step_id is None:
            step_id = f"auto_{self._step_counter}"
            self._step_counter += 1
            while step_id in self._used_step_ids:
                step_id = f"auto_{self._step_counter}"
                self._step_counter += 1
        else:
            if step_id in self._used_step_ids:
                raise ValueError(
                    f"Duplicate step_id '{step_id}' in pipeline execution. "
                    "Each generate_text() call must have a unique step_id."
                )
        self._used_step_ids.add(step_id)

        if not _ID_COMPONENT_PATTERN.match(step_id):
            raise ValueError(
                f"step_id '{step_id}' contains invalid characters. "
                "Only alphanumeric characters, hyphens, underscores, and dots are allowed."
            )
        external_id = f"pe:{self._execution_id}:step:{step_id}"

        if agent is not None:
            request_model_source = AgentSource(agent=agent)
        elif model_source is not None:
            request_model_source = DirectModelSource(
                provider_key=Provider(model_source["provider_key"]),
                provider_model_name=model_source["provider_model_name"],
                generation_params=GenerationParameters(
                    **model_source.get("generation_params", {})
                )
                if model_source.get("generation_params")
                else None,
            )
        else:
            raise ValueError("Either agent or model_source must be provided")

        request_data: dict[str, Any] = {
            "model_source": request_model_source,
            "user_message": user_message,
            "user_message_template": user_message_template,
            "user_message_variables": user_message_variables,
            "system_instruction": system_instruction,
            "system_instruction_template": system_instruction_template,
            "system_instruction_variables": system_instruction_variables,
            "output_schema": SchemaReference(schema_id=output_schema)
            if output_schema
            else None,
            "tags": tags or [],
            "stream": False,
            "external_id": external_id,
            "pipeline_execution_id": self._execution_id,
            "execution_purpose": "pipeline_step",
        }
        request = GenerateTextRequest(**request_data)

        response = await self._client.generate_text(request)

        return GenerateTextResult(
            execution_id=response.execution_id,
            output_text=response.output_text,
            structured_output=response.structured_output,
            usage=TokenUsage(
                input_tokens=response.usage.input_tokens,
                output_tokens=response.usage.output_tokens,
                cache_creation_tokens=response.usage.cache_creation_tokens,
                cache_read_tokens=response.usage.cache_read_tokens,
            ),
            cost=CostBreakdown(
                input_cost_usd=response.cost.input_cost_usd,
                output_cost_usd=response.cost.output_cost_usd,
                cache_cost_usd=response.cost.cache_cost_usd,
                total_cost_usd=response.cost.total_cost_usd,
            ),
            provider_key=response.provider_key,
            provider_model_name=response.provider_model_name,
            finish_reason=response.finish_reason,
            metadata=response.metadata,
        )

    async def parallel(
        self,
        coroutines: list[Awaitable[Any]],
        *,
        max_concurrency: int = 10,
    ) -> list[Any]:
        """Execute multiple operations concurrently.

        Uses asyncio.gather with a semaphore to limit concurrency.
        Results are returned in the same order as input coroutines.
        """
        from alloy_runtime_sdk.concurrency import parallel as _parallel

        return await _parallel(coroutines, max_concurrency=max_concurrency)

    async def wait_for_approval(
        self,
        prompt: str | None = None,
        *,
        approval_id: str | None = None,
    ) -> ApprovalResult:
        """Pause execution until human approval is received.

        On first encounter, creates a pending checkpoint and raises
        ApprovalPendingException. On re-run, if the checkpoint has been
        decided, returns the ApprovalResult immediately.
        """
        if approval_id is None:
            approval_id = f"auto_{self._approval_counter}"
            self._approval_counter += 1
            while approval_id in self._used_approval_ids:
                approval_id = f"auto_{self._approval_counter}"
                self._approval_counter += 1
        elif approval_id in self._used_approval_ids:
            raise ValueError(
                f"Duplicate approval_id '{approval_id}' in pipeline execution"
            )

        if not _ID_COMPONENT_PATTERN.match(approval_id):
            raise ValueError(
                f"approval_id '{approval_id}' contains invalid characters. "
                "Only alphanumeric characters, hyphens, underscores, and dots are allowed."
            )

        self._used_approval_ids.add(approval_id)
        approval_key = f"pe:{self._execution_id}:approval:{approval_id}"

        decision = await self._client.get_approval_checkpoint(
            self._execution_id, approval_key
        )
        if decision and decision.status != "pending":
            return ApprovalResult(
                approved=bool(decision.approved),
                decision_data=decision.decision_data or {},
                approved_by_user_id=decision.decided_by_user_id,
                decided_at=decision.decided_at,
            )

        if decision is None:
            await self._client.create_approval_checkpoint(
                self._execution_id, approval_key
            )

        raise ApprovalPendingException(approval_key=approval_key, prompt=prompt)

    async def close(self) -> None:
        """Close the HTTP client."""
        await self._client.close()
