"""Pipeline runner for Modal sandbox execution.

This module is the entry point for running pipelines inside Modal sandboxes.
It reads environment variables for configuration and outputs results as JSON.

Usage from Modal:
    python -m alloy_runtime_sdk.pipeline.runner

Environment Variables:
    ALLOY_RUNTIME_API_KEY: API key for authenticating with the server
    ALLOY_RUNTIME_SERVER_URL: Base URL of the Alloy Runtime server
    ALLOY_RUNTIME_EXECUTION_ID: UUID of this pipeline execution
    ALLOY_RUNTIME_MODULE_CONTENT: Base64-encoded Python source code
    ALLOY_RUNTIME_PIPELINE_NAME: Name of the @pipeline function to run (optional)
    ALLOY_RUNTIME_CONFIG: JSON-encoded runtime configuration
"""

import asyncio
import base64
import json
import os
import sys
import traceback
from typing import Any, cast
from uuid import UUID

from alloy_runtime_sdk.pipeline.decorators import (
    clear_pipeline_registry,
    get_pipeline_registry,
)
from alloy_runtime_sdk.pipeline.exceptions import ApprovalPendingException
from alloy_runtime_sdk.pipeline.http_context import HttpPipelineContext


class PipelineRunnerError(Exception):
    """Raised when pipeline runner encounters an error."""

    pass


def load_pipeline_module(module_content: str) -> None:
    """Load and execute the pipeline module to register @pipeline functions.

    Args:
        module_content: Python source code containing @pipeline decorated functions.

    Raises:
        PipelineRunnerError: If module cannot be loaded or has no pipelines.
    """
    # Clear any existing registrations
    clear_pipeline_registry()

    # Create a module namespace with necessary imports
    namespace: dict[str, Any] = {
        "__name__": "__pipeline_module__",
        "__builtins__": __builtins__,
    }

    try:
        # Execute the module code to register @pipeline functions
        exec(module_content, namespace)
    except SyntaxError as e:
        raise PipelineRunnerError(f"Syntax error in pipeline module: {e}") from e
    except Exception as e:
        raise PipelineRunnerError(f"Failed to load pipeline module: {e}") from e

    # Verify at least one pipeline was registered
    registry = get_pipeline_registry()
    if not registry:
        raise PipelineRunnerError(
            "No @pipeline decorated functions found in module. "
            "Make sure your function is decorated with @pipeline."
        )


def get_pipeline_function(pipeline_name: str | None):
    """Get the pipeline function from the registry.

    Args:
        pipeline_name: Name of the pipeline to run, or None for the only/first one.

    Returns:
        The pipeline function.

    Raises:
        PipelineRunnerError: If pipeline not found.
    """
    registry = get_pipeline_registry()

    if pipeline_name:
        if pipeline_name not in registry:
            available = list(registry.keys())
            raise PipelineRunnerError(
                f"Pipeline '{pipeline_name}' not found. Available: {available}"
            )
        return registry[pipeline_name]

    # No name specified - use the only one or first one
    if len(registry) == 1:
        return list(registry.values())[0]

    # Multiple pipelines - need to specify which one
    available = list(registry.keys())
    raise PipelineRunnerError(
        f"Multiple pipelines found: {available}. "
        f"Specify which one to run with pipeline_function_name."
    )


async def run_pipeline(
    api_key: str,
    server_url: str,
    execution_id: UUID,
    module_content: str,
    pipeline_name: str | None,
    config: dict[str, Any],
) -> dict[str, Any]:
    """Run a pipeline with the given configuration.

    Args:
        api_key: API key for server authentication.
        server_url: Base URL of the Alloy Runtime server.
        execution_id: UUID of this pipeline execution.
        module_content: Python source code of the pipeline.
        pipeline_name: Name of the @pipeline function to run.
        config: Runtime configuration dict.

    Returns:
        The pipeline result as a dict.

    Raises:
        PipelineRunnerError: If execution fails.
        ApprovalPendingException: If pipeline pauses for approval.
    """
    # Load the module
    load_pipeline_module(module_content)

    # Get the pipeline function
    pipeline_func = get_pipeline_function(pipeline_name)

    # Create the HTTP context
    ctx = HttpPipelineContext(
        api_key=api_key,
        server_url=server_url,
        execution_id=execution_id,
        config=config,
    )

    try:
        # Execute the pipeline
        result = await pipeline_func(ctx)

        # Ensure result is serializable
        if result is None:
            return {"result": None}
        elif isinstance(result, dict):
            return cast(dict[str, Any], result)
        elif isinstance(result, list):
            return {"results": result}
        else:
            # Try to convert to dict if it's a Pydantic model
            if hasattr(result, "model_dump"):
                return result.model_dump()
            return {"result": str(result)}

    finally:
        await ctx.close()


def main() -> None:
    """Main entry point for Modal sandbox execution.

    Reads configuration from environment variables, runs the pipeline,
    and outputs the result as JSON to stdout.
    """
    # Read required environment variables
    api_key = os.environ.get("ALLOY_RUNTIME_API_KEY")
    if not api_key:
        print(
            json.dumps(
                {
                    "success": False,
                    "error": "ALLOY_RUNTIME_API_KEY environment variable is required",
                }
            )
        )
        sys.exit(1)

    server_url = os.environ.get("ALLOY_RUNTIME_SERVER_URL")
    if not server_url:
        print(
            json.dumps(
                {
                    "success": False,
                    "error": "ALLOY_RUNTIME_SERVER_URL environment variable is required",
                }
            )
        )
        sys.exit(1)

    execution_id_str = os.environ.get("ALLOY_RUNTIME_EXECUTION_ID")
    if not execution_id_str:
        print(
            json.dumps(
                {
                    "success": False,
                    "error": "ALLOY_RUNTIME_EXECUTION_ID environment variable is required",
                }
            )
        )
        sys.exit(1)

    try:
        execution_id = UUID(execution_id_str)
    except ValueError:
        print(
            json.dumps(
                {
                    "success": False,
                    "error": f"Invalid execution ID: {execution_id_str}",
                }
            )
        )
        sys.exit(1)

    module_content_b64 = os.environ.get("ALLOY_RUNTIME_MODULE_CONTENT")
    if not module_content_b64:
        print(
            json.dumps(
                {
                    "success": False,
                    "error": "ALLOY_RUNTIME_MODULE_CONTENT environment variable is required",
                }
            )
        )
        sys.exit(1)

    try:
        module_content = base64.b64decode(module_content_b64).decode("utf-8")
    except Exception as e:
        print(
            json.dumps(
                {
                    "success": False,
                    "error": f"Failed to decode module content: {e}",
                }
            )
        )
        sys.exit(1)

    # Optional variables
    pipeline_name = os.environ.get("ALLOY_RUNTIME_PIPELINE_NAME")

    config_json = os.environ.get("ALLOY_RUNTIME_CONFIG", "{}")
    try:
        config = json.loads(config_json)
    except json.JSONDecodeError as e:
        print(
            json.dumps(
                {
                    "success": False,
                    "error": f"Invalid config JSON: {e}",
                }
            )
        )
        sys.exit(1)

    # Run the pipeline
    try:
        result = asyncio.run(
            run_pipeline(
                api_key=api_key,
                server_url=server_url,
                execution_id=execution_id,
                module_content=module_content,
                pipeline_name=pipeline_name,
                config=config,
            )
        )

        # Output success result
        print(
            json.dumps(
                {
                    "success": True,
                    "result": result,
                }
            )
        )

    except ApprovalPendingException as e:
        # Pipeline paused for approval
        print(
            json.dumps(
                {
                    "success": True,
                    "waiting_for_approval": True,
                    "approval_key": e.approval_key,
                    "prompt": e.prompt,
                }
            )
        )

    except PipelineRunnerError as e:
        print(
            json.dumps(
                {
                    "success": False,
                    "error": str(e),
                }
            )
        )
        sys.exit(1)

    except Exception as e:
        print(
            json.dumps(
                {
                    "success": False,
                    "error": str(e),
                    "traceback": traceback.format_exc(),
                }
            )
        )
        sys.exit(1)


if __name__ == "__main__":
    main()
