"""Logger protocol for dependency injection in ApiClient.

This module defines a Protocol that any logger can implement, allowing users
to inject their own logging configuration (JSON, console, custom formatters, etc.).

The protocol is compatible with:
- structlog bound loggers
- stdlib logging.Logger
- Any custom logger with info/debug/warning/error methods

Usage:
    # With structlog (JSON or console based on configuration)
    from alloy_runtime_sdk.logging.config import configure, get_logger, LogConfig, LogFormat
    configure(LogConfig(format=LogFormat.JSON))
    logger = get_logger()

    async with ApiClient(base_url="...", api_key="...", logger=logger) as client:
        await client.list_agents()

    # With stdlib logging
    import logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger("my_app")

    async with ApiClient(base_url="...", api_key="...", logger=logger) as client:
        await client.list_agents()

    # Without logging (default - uses NullLogger)
    async with ApiClient(base_url="...", api_key="...") as client:
        await client.list_agents()
"""

import secrets
from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class ClientLogger(Protocol):
    """Protocol for loggers compatible with ApiClient.

    Any logger implementing these methods can be injected into ApiClient.
    The logger is responsible for its own formatting (JSON, console, etc.).

    All methods accept structured kwargs which will be:
    - Rendered as JSON fields if using a JSON formatter
    - Rendered as key=value pairs if using console formatter
    """

    def info(self, __event: str, **__kwargs: Any) -> None:
        """Log an info-level message with structured data."""
        ...

    def debug(self, __event: str, **__kwargs: Any) -> None:
        """Log a debug-level message with structured data."""
        ...

    def warning(self, __event: str, **__kwargs: Any) -> None:
        """Log a warning-level message with structured data."""
        ...

    def error(self, __event: str, **__kwargs: Any) -> None:
        """Log an error-level message with structured data."""
        ...


class NullLogger:
    """No-op logger implementation.

    Used as the default when no logger is provided to ApiClient.
    All methods are no-ops with minimal overhead.
    """

    __slots__ = ()

    def info(self, _event: str, **_kwargs: Any) -> None:
        """No-op info log."""

    def debug(self, _event: str, **_kwargs: Any) -> None:
        """No-op debug log."""

    def warning(self, _event: str, **_kwargs: Any) -> None:
        """No-op warning log."""

    def error(self, _event: str, **_kwargs: Any) -> None:
        """No-op error log."""


# Singleton instance for efficiency
_null_logger = NullLogger()


def get_null_logger() -> NullLogger:
    """Get the singleton NullLogger instance."""
    return _null_logger


def generate_request_id() -> str:
    """Generate a short unique request ID for log correlation.

    Returns:
        8-character hex string (e.g., "a1b2c3d4")

    This ID is used to correlate request and response log entries,
    making it easy to trace a request through the logs.
    """
    return secrets.token_hex(4)
