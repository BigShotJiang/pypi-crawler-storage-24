# alloy-runtime-sdk

Python SDK for Alloy Runtime.

## Install

```bash
pip install alloy-runtime-sdk
```

## Quick start

```python
from alloy_runtime_sdk.api_client.client import ApiClient

async def main() -> None:
    async with ApiClient(
        base_url="https://your-alloy-runtime-host",
        api_key="your_api_key",
    ) as client:
        models = await client.list_models()
        print(models)
```

## What it includes

- Authenticated HTTP client methods for the Alloy Runtime API.
- Pipeline runtime helpers for Python-based pipeline steps.
- Structured logging helpers used by runtime integrations.

The SDK depends on `alloy-runtime-types`, which is published separately for stable,
versioned cross-package compatibility.
