from __future__ import annotations

from textual import on, work
from textual.app import ComposeResult
from textual.containers import Vertical, VerticalScroll
from textual.events import Key
from textual.screen import ModalScreen
from textual.widgets import Input, Label, Static


def _escape_rich(text: str) -> str:
    return text.replace("[", r"\[")


def _name_color(name: str) -> str:
    colors = [
        "#7aa2f7", "#bb9af7", "#7dcfff", "#73daca",
        "#9ece6a", "#e0af68", "#f7768e", "#ff9e64",
    ]
    return colors[sum(ord(c) for c in name) % len(colors)]


class ThreadMessage(Static):
    def __init__(self, msg: dict, is_root: bool = False) -> None:
        self.msg_data = msg
        sender = msg.get("sender_username", "?")
        content = msg.get("content", "")
        is_deleted = msg.get("is_deleted", False)
        color = _name_color(sender)
        tag = _escape_rich(sender.upper())

        ts = msg.get("created_at", "")
        time_str = ""
        if ts:
            try:
                from datetime import datetime
                dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
                time_str = dt.strftime("%H:%M")
            except Exception:
                pass

        if is_deleted:
            text = f"[dim]{time_str}[/] [{color}]{tag}[/] [dim]> -- deleted --[/]"
        else:
            rendered = _escape_rich(content)
            text = f"[dim]{time_str}[/] [{color}]{tag}[/] > {rendered}"

        cls = "thread-root" if is_root else "thread-reply"
        super().__init__(text, classes=cls)


class ThreadScreen(ModalScreen[dict | None]):
    """View a message thread — root message + all replies."""

    def __init__(self, conversation_id: str, message_id: str, message: dict | None = None) -> None:
        super().__init__()
        self._conversation_id = conversation_id
        self._message_id = message_id
        self._root_msg = message

    def compose(self) -> ComposeResult:
        with Vertical(id="thread-modal"):
            yield Label("THREAD", id="modal-title")
            yield VerticalScroll(id="thread-messages")
            yield Input(placeholder="reply in thread...", id="thread-input")

    def on_mount(self) -> None:
        self._load_thread()

    @work(exclusive=True)
    async def _load_thread(self) -> None:
        container = self.query_one("#thread-messages", VerticalScroll)
        await container.remove_children()

        api = self.app.api
        messages = None

        # Try dedicated thread endpoint first
        try:
            messages = await api.get_thread(self._conversation_id, self._message_id)
        except Exception:
            pass

        # Fallback: fetch all messages and filter replies locally
        if not messages:
            try:
                all_msgs = await api.get_messages(self._conversation_id, limit=100)
                root = None
                replies = []
                for m in all_msgs:
                    if m.get("id") == self._message_id:
                        root = m
                    elif m.get("reply_to_id") == self._message_id:
                        replies.append(m)
                if root:
                    messages = [root] + replies
                elif self._root_msg:
                    messages = [self._root_msg] + replies
            except Exception:
                if self._root_msg:
                    messages = [self._root_msg]

        if not messages:
            await container.mount(Static("[dim]failed to load thread[/]"))
            return

        for i, msg in enumerate(messages):
            await container.mount(ThreadMessage(msg, is_root=(i == 0)))

        title = self.query_one("#modal-title", Label)
        reply_count = len(messages) - 1
        title.update(f"THREAD  [dim]{reply_count} {'reply' if reply_count == 1 else 'replies'}[/]")

        container.scroll_end(animate=False)
        self.query_one("#thread-input", Input).focus()

    @on(Input.Submitted, "#thread-input")
    def on_submit(self, event: Input.Submitted) -> None:
        content = event.value.strip()
        if content:
            self._send_reply(content)
            event.input.clear()

    @work(exclusive=False)
    async def _send_reply(self, content: str) -> None:
        try:
            api = self.app.api
            await api.send_message(
                self._conversation_id,
                content,
                reply_to_id=self._message_id,
            )
            self._load_thread()
        except Exception as exc:
            self.notify(f"failed to send reply: {exc}", severity="error")

    def on_key(self, event: Key) -> None:
        if event.key == "escape":
            event.stop()
            event.prevent_default()
            self.dismiss(None)
