"""TUI screens for GoldenMatch."""
