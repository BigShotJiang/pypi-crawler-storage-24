#  Copyright 2023 Adobe. All rights reserved.
#  This file is licensed to you under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License. You may obtain a copy
#  of the License at http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software distributed under
#  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
#  OF ANY KIND, either express or implied. See the License for the specific language
#  governing permissions and limitations under the License.

# internal library
from configparser import ConfigParser

class Utils:

    @staticmethod
    def check_if_exists(section, field_name, config_path):
        config = ConfigParser()
        config.read(config_path)
        return config.get(section, field_name) or None


    @staticmethod
    def save_field_in_config(section, field_name, value, config_path):
        config = ConfigParser()
        config.read(config_path)
        config.set(section, field_name, value)
        with open(config_path, "w") as configfile:
            config.write(configfile)