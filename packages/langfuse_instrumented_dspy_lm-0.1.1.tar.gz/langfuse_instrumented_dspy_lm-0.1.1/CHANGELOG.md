# Changelog

## 0.1.1

### Fixed

- Token usage (especially input/prompt tokens) now correctly tracked when using `dspy.streamify()` for streaming. Previously, streaming calls reported `prompt_tokens` as 0 because the underlying LiteLLM request did not include `stream_options={"include_usage": True}`.

### Added

- Streaming support documentation with `dspy.streamify()` example.
- Setup guide for initializing the Langfuse client before DSPy instrumentation.
- Guide for flushing traces in scripts and short-lived processes.

## 0.1.0

Initial release.

- Drop-in replacement for `dspy.LM` that captures token usage in Langfuse.
- Tracks prompt tokens, completion tokens, total tokens, cost, reasoning tokens, and cached tokens.
- Supports both synchronous (`forward`) and asynchronous (`aforward`) execution.
