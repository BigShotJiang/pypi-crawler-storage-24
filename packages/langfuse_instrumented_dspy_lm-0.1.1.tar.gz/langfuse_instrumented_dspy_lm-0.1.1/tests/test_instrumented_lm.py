"""Tests for LangfuseInstrumentedLm."""

import asyncio
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from openinference.semconv.trace import SpanAttributes

from langfuse_instrumented_dspy_lm import LangfuseInstrumentedLm


def _make_usage(
    prompt_tokens=10,
    completion_tokens=20,
    total_tokens=30,
    cost=None,
    reasoning_tokens=None,
    cached_tokens=None,
):
    """Build a mock usage object matching LiteLLM's structure."""
    usage = SimpleNamespace(
        prompt_tokens=prompt_tokens,
        completion_tokens=completion_tokens,
        total_tokens=total_tokens,
    )
    if cost is not None:
        usage.cost = cost

    if reasoning_tokens is not None:
        usage.completion_tokens_details = SimpleNamespace(
            reasoning_tokens=reasoning_tokens
        )
    else:
        usage.completion_tokens_details = None

    if cached_tokens is not None:
        usage.prompt_tokens_details = SimpleNamespace(cached_tokens=cached_tokens)
    else:
        usage.prompt_tokens_details = None

    return usage


def _make_response(usage=None):
    """Build a mock LiteLLM ModelResponse."""
    resp = SimpleNamespace()
    if usage is not None:
        resp.usage = usage
    return resp


# ---------------------------------------------------------------------------
# stream_options injection
# ---------------------------------------------------------------------------


class TestStreamOptionsInjection:
    """Verify stream_options is injected into kwargs for streaming support."""

    @patch.object(LangfuseInstrumentedLm, "_set_span_attributes")
    def test_forward_injects_stream_options(self, mock_set_attrs):
        """forward() should add stream_options to kwargs."""
        lm = LangfuseInstrumentedLm.__new__(LangfuseInstrumentedLm)
        response = _make_response(_make_usage())

        captured_kwargs = {}

        def fake_forward(prompt=None, messages=None, **kwargs):
            captured_kwargs.update(kwargs)
            return response

        with patch("dspy.LM.forward", side_effect=fake_forward):
            lm.forward(messages=[{"role": "user", "content": "hi"}])

        assert captured_kwargs["stream_options"] == {"include_usage": True}

    @patch.object(LangfuseInstrumentedLm, "_set_span_attributes")
    def test_aforward_injects_stream_options(self, mock_set_attrs):
        """aforward() should add stream_options to kwargs."""
        lm = LangfuseInstrumentedLm.__new__(LangfuseInstrumentedLm)
        response = _make_response(_make_usage())

        captured_kwargs = {}

        async def fake_aforward(prompt=None, messages=None, **kwargs):
            captured_kwargs.update(kwargs)
            return response

        with patch("dspy.LM.aforward", side_effect=fake_aforward):
            asyncio.run(
                lm.aforward(messages=[{"role": "user", "content": "hi"}])
            )

        assert captured_kwargs["stream_options"] == {"include_usage": True}

    @patch.object(LangfuseInstrumentedLm, "_set_span_attributes")
    def test_forward_does_not_overwrite_user_stream_options(self, mock_set_attrs):
        """User-provided stream_options should not be overwritten."""
        lm = LangfuseInstrumentedLm.__new__(LangfuseInstrumentedLm)
        response = _make_response(_make_usage())
        user_opts = {"include_usage": False}

        captured_kwargs = {}

        def fake_forward(prompt=None, messages=None, **kwargs):
            captured_kwargs.update(kwargs)
            return response

        with patch("dspy.LM.forward", side_effect=fake_forward):
            lm.forward(
                messages=[{"role": "user", "content": "hi"}],
                stream_options=user_opts,
            )

        assert captured_kwargs["stream_options"] == {"include_usage": False}

    @patch.object(LangfuseInstrumentedLm, "_set_span_attributes")
    def test_aforward_does_not_overwrite_user_stream_options(self, mock_set_attrs):
        """User-provided stream_options should not be overwritten in async path."""
        lm = LangfuseInstrumentedLm.__new__(LangfuseInstrumentedLm)
        response = _make_response(_make_usage())
        user_opts = {"include_usage": False}

        captured_kwargs = {}

        async def fake_aforward(prompt=None, messages=None, **kwargs):
            captured_kwargs.update(kwargs)
            return response

        with patch("dspy.LM.aforward", side_effect=fake_aforward):
            asyncio.run(
                lm.aforward(
                    messages=[{"role": "user", "content": "hi"}],
                    stream_options=user_opts,
                )
            )

        assert captured_kwargs["stream_options"] == {"include_usage": False}


# ---------------------------------------------------------------------------
# _set_span_attributes
# ---------------------------------------------------------------------------


class TestSetSpanAttributes:
    """Verify span attributes are set correctly from response usage."""

    def _call_with_mock_span(self, response, recording=True):
        """Helper: call _set_span_attributes with a mock span and return it."""
        mock_span = MagicMock()
        mock_span.is_recording.return_value = recording

        lm = LangfuseInstrumentedLm.__new__(LangfuseInstrumentedLm)

        with patch("langfuse_instrumented_dspy_lm.instrumented_lm.trace") as mock_trace:
            mock_trace.get_current_span.return_value = mock_span
            lm._set_span_attributes(response)

        return mock_span

    def test_sets_primary_token_counts(self):
        usage = _make_usage(prompt_tokens=15, completion_tokens=25, total_tokens=40)
        response = _make_response(usage)
        span = self._call_with_mock_span(response)

        span.set_attribute.assert_any_call(SpanAttributes.LLM_TOKEN_COUNT_PROMPT, 15)
        span.set_attribute.assert_any_call(
            SpanAttributes.LLM_TOKEN_COUNT_COMPLETION, 25
        )
        span.set_attribute.assert_any_call(SpanAttributes.LLM_TOKEN_COUNT_TOTAL, 40)

    def test_sets_cost(self):
        usage = _make_usage(cost=0.005)
        response = _make_response(usage)
        span = self._call_with_mock_span(response)

        span.set_attribute.assert_any_call(SpanAttributes.LLM_COST_TOTAL, 0.005)

    def test_sets_reasoning_tokens(self):
        usage = _make_usage(reasoning_tokens=100)
        response = _make_response(usage)
        span = self._call_with_mock_span(response)

        span.set_attribute.assert_any_call(
            SpanAttributes.LLM_TOKEN_COUNT_COMPLETION_DETAILS_REASONING, 100
        )

    def test_sets_cached_tokens(self):
        usage = _make_usage(cached_tokens=50)
        response = _make_response(usage)
        span = self._call_with_mock_span(response)

        span.set_attribute.assert_any_call(
            SpanAttributes.LLM_TOKEN_COUNT_PROMPT_DETAILS_CACHE_READ, 50
        )

    def test_skips_non_recording_span(self):
        usage = _make_usage()
        response = _make_response(usage)
        span = self._call_with_mock_span(response, recording=False)

        span.set_attribute.assert_not_called()

    def test_skips_missing_usage(self):
        response = SimpleNamespace()  # no usage attribute
        span = self._call_with_mock_span(response)

        span.set_attribute.assert_not_called()

    def test_handles_none_token_values(self):
        usage = _make_usage(
            prompt_tokens=None, completion_tokens=None, total_tokens=None
        )
        response = _make_response(usage)
        span = self._call_with_mock_span(response)

        # Should not set attributes for None values
        for call_args in span.set_attribute.call_args_list:
            attr_name = call_args[0][0]
            assert attr_name not in (
                SpanAttributes.LLM_TOKEN_COUNT_PROMPT,
                SpanAttributes.LLM_TOKEN_COUNT_COMPLETION,
                SpanAttributes.LLM_TOKEN_COUNT_TOTAL,
            )

    def test_exception_is_caught_and_logged(self):
        """Errors in _set_span_attributes should be logged, not raised."""
        lm = LangfuseInstrumentedLm.__new__(LangfuseInstrumentedLm)
        mock_span = MagicMock()
        mock_span.is_recording.return_value = True
        mock_span.set_attribute.side_effect = RuntimeError("boom")

        # Response with usage that will trigger set_attribute
        response = _make_response(_make_usage())

        with patch(
            "langfuse_instrumented_dspy_lm.instrumented_lm.trace"
        ) as mock_trace:
            mock_trace.get_current_span.return_value = mock_span
            # Should not raise
            lm._set_span_attributes(response)


# ---------------------------------------------------------------------------
# forward / aforward return value passthrough
# ---------------------------------------------------------------------------


class TestResponsePassthrough:
    """Verify forward/aforward return the response unchanged."""

    def test_forward_returns_response(self):
        lm = LangfuseInstrumentedLm.__new__(LangfuseInstrumentedLm)
        expected = _make_response(_make_usage())

        with (
            patch("dspy.LM.forward", return_value=expected),
            patch.object(lm, "_set_span_attributes"),
        ):
            result = lm.forward(messages=[{"role": "user", "content": "hi"}])

        assert result is expected

    def test_aforward_returns_response(self):
        lm = LangfuseInstrumentedLm.__new__(LangfuseInstrumentedLm)
        expected = _make_response(_make_usage())

        async def fake_aforward(prompt=None, messages=None, **kwargs):
            return expected

        with (
            patch("dspy.LM.aforward", side_effect=fake_aforward),
            patch.object(lm, "_set_span_attributes"),
        ):
            result = asyncio.run(
                lm.aforward(messages=[{"role": "user", "content": "hi"}])
            )

        assert result is expected
