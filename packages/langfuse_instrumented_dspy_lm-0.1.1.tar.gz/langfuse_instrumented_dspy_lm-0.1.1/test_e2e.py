"""End-to-end test script: run non-streaming and streaming calls, then check Langfuse dashboard."""

import asyncio
import os

from dotenv import load_dotenv

load_dotenv()

import dspy
from langfuse import get_client
from openinference.instrumentation.dspy import DSPyInstrumentor
from opentelemetry import trace as otel_trace

from langfuse_instrumented_dspy_lm import LangfuseInstrumentedLm

# Verify Langfuse connection
langfuse = get_client()
if langfuse.auth_check():
    print("Langfuse client is authenticated and ready!")
else:
    print("ERROR: Langfuse authentication failed!")
    exit(1)

# Enable DSPy tracing
DSPyInstrumentor().instrument()

# Configure DSPy with instrumented LM
lm = LangfuseInstrumentedLm(
    "openrouter/google/gemini-3.1-flash-lite-preview",
    max_tokens=1000,
    temperature=1.0,
    cache=False,
)
dspy.configure(lm=lm)

# --- Non-streaming test ---
print("=== Non-streaming test ===")
predict = dspy.Predict("question -> answer")
result = predict(question="What is the capital of France?")
print(f"Answer: {result.answer}\n")

# --- Streaming test ---
print("=== Streaming test ===")
stream_predict = dspy.streamify(
    dspy.Predict("question -> answer"),
    stream_listeners=[dspy.streaming.StreamListener(signature_field_name="answer")],
)


async def run_stream():
    output = stream_predict(question="What is the largest ocean on Earth?")
    final = None
    async for chunk in output:
        if isinstance(chunk, dspy.streaming.StreamResponse):
            print(chunk.chunk, end="", flush=True)
        elif isinstance(chunk, dspy.Prediction):
            final = chunk
    print()
    return final


result = asyncio.run(run_stream())
print(f"Answer: {result.answer}\n")

# Force flush OTel spans and Langfuse
provider = otel_trace.get_tracer_provider()
if hasattr(provider, "force_flush"):
    provider.force_flush()

langfuse.flush()
langfuse.shutdown()
print("Done — check your Langfuse dashboard for token counts.")
