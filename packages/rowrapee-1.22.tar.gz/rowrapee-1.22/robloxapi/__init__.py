"""
robloxapi - A Python wrapper for the Roblox web APIs.

Quickstart:
    >>> from robloxapi import RobloxClient
    >>> client = RobloxClient()                        # unauthenticated
    >>> client = RobloxClient(cookie="ROBLOSECURITY")  # authenticated

Sub-APIs:
    client.users      - User lookups, search, username history
    client.games      - Game details, visits, servers, votes, game page
    client.catalog    - Item search, details, resale data, bundles
    client.groups     - Group info, members, wall, audit log
    client.friends    - Friends, followers, followings
    client.thumbnails - Avatar, game, asset, group thumbnail URLs
    client.badges     - Badge details, user badges, award dates
"""

from .client import RobloxClient

__all__ = ["RobloxClient"]
__version__ = "1.0.0"
