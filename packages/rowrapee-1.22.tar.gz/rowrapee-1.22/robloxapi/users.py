"""
Roblox Users API - https://users.roblox.com
"""

from typing import List, Optional


class UsersAPI:
    BASE = "https://users.roblox.com/v1"

    def __init__(self, client):
        self._c = client

    def get_user(self, user_id: int) -> dict:
        """
        Get user info by ID.

        Returns:
            dict: {id, name, displayName, description, created,
                   isBanned, externalAppDisplayName, hasVerifiedBadge}
        """
        return self._c._get(f"{self.BASE}/users/{user_id}")

    def get_authenticated_user(self) -> dict:
        """
        Get the currently authenticated user's info (requires cookie).

        Returns:
            dict: {id, name, displayName}
        """
        return self._c._get(f"{self.BASE}/users/authenticated")

    def search_users(self, keyword: str, limit: int = 10) -> dict:
        """
        Search for users by keyword.

        Args:
            keyword: Search term.
            limit: Max results (10, 25, 50, 100).

        Returns:
            dict: {previousPageCursor, nextPageCursor, data: [...]}
        """
        return self._c._get(
            f"{self.BASE}/users/search",
            params={"keyword": keyword, "limit": limit},
        )

    def get_users_by_ids(self, user_ids: List[int], exclude_banned: bool = False) -> dict:
        """
        Get multiple users by their IDs (up to 100).

        Returns:
            dict: {data: [{id, name, displayName, hasVerifiedBadge}, ...]}
        """
        return self._c._post(
            f"{self.BASE}/users",
            json={"userIds": user_ids, "excludeBannedUsers": exclude_banned},
        )

    def get_users_by_usernames(self, usernames: List[str], exclude_banned: bool = False) -> dict:
        """
        Get multiple users by their usernames (up to 100).

        Returns:
            dict: {data: [{requestedUsername, id, name, displayName}, ...]}
        """
        return self._c._post(
            f"{self.BASE}/usernames/users",
            json={"usernames": usernames, "excludeBannedUsers": exclude_banned},
        )

    def get_username_history(self, user_id: int, limit: int = 10) -> dict:
        """
        Get a user's previous usernames.

        Returns:
            dict: {previousPageCursor, nextPageCursor, data: [{name}, ...]}
        """
        return self._c._get(
            f"{self.BASE}/users/{user_id}/username-history",
            params={"limit": limit},
        )

    def validate_username(self, username: str) -> dict:
        """
        Validate if a username is available/valid.

        Returns:
            dict: {code, message} — code 0 means valid.
        """
        return self._c._get(
            "https://auth.roblox.com/v1/usernames/validate",
            params={"Username": username, "Birthday": "2000-01-01"},
        )
