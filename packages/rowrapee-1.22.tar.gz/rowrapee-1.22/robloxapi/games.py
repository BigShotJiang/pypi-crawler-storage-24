"""
Roblox Games API - https://games.roblox.com
Covers game details, visits, active players, game passes, servers, etc.
"""

from typing import List, Optional


class GamesAPI:
    BASE = "https://games.roblox.com/v1"
    BASE2 = "https://games.roblox.com/v2"

    def __init__(self, client):
        self._c = client

    # ------------------------------------------------------------------ #
    #  Game details                                                        #
    # ------------------------------------------------------------------ #

    def get_games(self, universe_ids: List[int]) -> dict:
        """
        Get details for one or more games by universe ID.

        Returns:
            dict: {data: [{id, rootPlaceId, name, description, creator,
                            price, allowedGearGenres, allowedGearCategories,
                            playing, visits, maxPlayers, created, updated,
                            genre, isFavoritedByUser, favoritedCount}, ...]}
        """
        return self._c._get(
            f"{self.BASE}/games",
            params={"universeIds": ",".join(str(i) for i in universe_ids)},
        )

    def get_game_by_place_id(self, place_id: int) -> dict:
        """
        Get the universe ID and basic info from a place ID.

        Returns:
            dict: {universeId}
        """
        return self._c._get(
            f"https://apis.roblox.com/universes/v1/places/{place_id}/universe"
        )

    def get_game_visits(self, universe_ids: List[int]) -> dict:
        """
        Convenience wrapper — returns visit counts for given universe IDs.
        Calls get_games() and extracts visit data.

        Returns:
            list of dicts: [{universeId, visits}]
        """
        data = self.get_games(universe_ids)
        return [
            {"universeId": g["id"], "visits": g.get("visits", 0)}
            for g in data.get("data", [])
        ]

    def get_game_stats(self, universe_id: int, stat_type: str = "Visits",
                       start_time: Optional[str] = None,
                       end_time: Optional[str] = None,
                       granularity: str = "Daily") -> dict:
        """
        Get a game's time-series stats.

        Args:
            universe_id: Universe ID.
            stat_type: "Visits", "Revenue", "Favorites", "ArPU", "ArPDAU",
                       "PlayerHours", "ConcurrentPlayers" (etc.)
            granularity: "Hourly", "Daily", "Monthly"
            start_time / end_time: ISO 8601 strings (optional).

        Returns:
            dict: {data: [{value, date}, ...]}
        """
        params = {"universeId": universe_id, "type": stat_type,
                  "granularity": granularity}
        if start_time:
            params["startTime"] = start_time
        if end_time:
            params["endTime"] = end_time
        return self._c._get(
            f"https://develop.roblox.com/v1/universes/{universe_id}/stats",
            params=params,
        )

    # ------------------------------------------------------------------ #
    #  Games list / discovery                                              #
    # ------------------------------------------------------------------ #

    def get_games_page(self, sort_token: Optional[str] = None,
                       genre: str = "All", limit: int = 6,
                       country_region_id: int = 1) -> dict:
        """
        Retrieve the public games page (like the Roblox home page listing).

        Args:
            sort_token: Sort algorithm token (e.g. from a previous response).
            genre: Genre filter string.
            limit: Number of games per sort (6, 10, etc.)
            country_region_id: 1 = US.

        Returns:
            dict with sorts[] each containing games[].
        """
        params = {
            "genre": genre,
            "GameFilter": "All",
            "SortFilter": "default",
            "countryRegionId": country_region_id,
            "browserType": "chrome",
            "GameSetTargetId": 1,
        }
        if sort_token:
            params["sortToken"] = sort_token
        return self._c._get(
            "https://games.roblox.com/v1/games/list",
            params=params,
        )

    def search_games(self, keyword: str, limit: int = 10,
                     cursor: Optional[str] = None) -> dict:
        """
        Search for games by keyword.

        Returns:
            dict: {previousPageCursor, nextPageCursor, data: [...]}
        """
        params = {"keyword": keyword, "limit": limit}
        if cursor:
            params["cursor"] = cursor
        return self._c._get(f"{self.BASE}/games/list", params=params)

    def get_recommended_games(self, universe_id: int, limit: int = 10) -> dict:
        """
        Get games recommended based on a given universe.

        Returns:
            dict: {games: [...]}
        """
        return self._c._get(
            f"{self.BASE}/games/recommendations/game/{universe_id}",
            params={"maxRows": limit},
        )

    def get_games_by_user(self, user_id: int, access_filter: str = "Public",
                          limit: int = 50, cursor: Optional[str] = None) -> dict:
        """
        Get games created by a user.

        Args:
            access_filter: "Public", "Private", "All"

        Returns:
            dict: {previousPageCursor, nextPageCursor, data: [...]}
        """
        params = {"accessFilter": access_filter, "limit": limit}
        if cursor:
            params["cursor"] = cursor
        return self._c._get(
            f"{self.BASE2}/users/{user_id}/games",
            params=params,
        )

    def get_games_by_group(self, group_id: int, limit: int = 50,
                           cursor: Optional[str] = None) -> dict:
        """
        Get games created by a group.

        Returns:
            dict: {previousPageCursor, nextPageCursor, data: [...]}
        """
        params = {"limit": limit}
        if cursor:
            params["cursor"] = cursor
        return self._c._get(
            f"{self.BASE2}/groups/{group_id}/games",
            params=params,
        )

    # ------------------------------------------------------------------ #
    #  Servers                                                             #
    # ------------------------------------------------------------------ #

    def get_game_servers(self, place_id: int, server_type: str = "Public",
                         limit: int = 10, cursor: Optional[str] = None,
                         sort_order: str = "Asc") -> dict:
        """
        List active servers for a place.

        Args:
            server_type: "Public" or "Friend"

        Returns:
            dict: {previousPageCursor, nextPageCursor, data: [{id, maxPlayers,
                   playing, fps, ping, ...}, ...]}
        """
        params = {"serverType": server_type, "limit": limit,
                  "sortOrder": sort_order}
        if cursor:
            params["cursor"] = cursor
        return self._c._get(
            f"{self.BASE}/games/{place_id}/servers/{server_type}",
            params=params,
        )

    # ------------------------------------------------------------------ #
    #  Game passes                                                         #
    # ------------------------------------------------------------------ #

    def get_game_passes(self, universe_id: int, limit: int = 10,
                        cursor: Optional[str] = None) -> dict:
        """
        Get game passes for a universe.

        Returns:
            dict: {previousPageCursor, nextPageCursor, data: [...]}
        """
        params = {"limit": limit}
        if cursor:
            params["cursor"] = cursor
        return self._c._get(
            f"{self.BASE}/games/{universe_id}/game-passes",
            params=params,
        )

    def get_user_game_passes(self, user_id: int, universe_id: int) -> dict:
        """
        Check which game passes a user owns for a universe (requires auth).

        Returns:
            dict: {gamePassIds: [...]}
        """
        return self._c._get(
            f"{self.BASE}/users/{user_id}/games/{universe_id}/votes"
        )

    # ------------------------------------------------------------------ #
    #  Votes / favourites                                                  #
    # ------------------------------------------------------------------ #

    def get_game_votes(self, universe_ids: List[int]) -> dict:
        """
        Get upvote / downvote counts for universes.

        Returns:
            dict: {data: [{id, upVotes, downVotes}, ...]}
        """
        return self._c._get(
            f"{self.BASE}/games/votes",
            params={"universeIds": ",".join(str(i) for i in universe_ids)},
        )

    def get_user_vote(self, universe_id: int) -> dict:
        """
        Get the authenticated user's vote on a game (requires auth).

        Returns:
            dict: {id, userVote}
        """
        return self._c._get(f"{self.BASE}/games/{universe_id}/votes/user")

    def get_game_favorite_count(self, universe_id: int) -> dict:
        """
        Get favorite count for a game.

        Returns:
            dict: {favoritesCount}
        """
        return self._c._get(
            f"{self.BASE}/games/{universe_id}/favorites/count"
        )

    # ------------------------------------------------------------------ #
    #  Place details                                                       #
    # ------------------------------------------------------------------ #

    def get_place_details(self, place_ids: List[int]) -> dict:
        """
        Get details for one or more places.

        Returns:
            dict: {data: [{placeId, name, sourceName, sourceDescription,
                            url, builder, builderId, hasVerifiedBadge,
                            isPlayable, reasonProhibited, universeId,
                            universeRootPlaceId, price, imageToken}, ...]}
        """
        return self._c._get(
            "https://games.roblox.com/v1/games/multiget-place-details",
            params={"placeIds": ",".join(str(i) for i in place_ids)},
        )
