"""
Roblox Friends API - https://friends.roblox.com
"""

from typing import Optional


class FriendsAPI:
    BASE = "https://friends.roblox.com/v1"

    def __init__(self, client):
        self._c = client

    def get_friends(self, user_id: int) -> dict:
        """
        Get a user's full friends list.

        Returns:
            dict: {data: [{id, name, displayName, hasVerifiedBadge,
                            isOnline, presenceType, isDeleted,
                            friendFrequentScore, friendFrequentRank}, ...]}
        """
        return self._c._get(f"{self.BASE}/users/{user_id}/friends")

    def get_friend_count(self, user_id: int) -> dict:
        """
        Get the number of friends a user has.

        Returns:
            dict: {count}
        """
        return self._c._get(f"{self.BASE}/users/{user_id}/friends/count")

    def get_followers(self, user_id: int, limit: int = 10,
                      cursor: Optional[str] = None,
                      sort_order: str = "Asc") -> dict:
        """
        Get users who follow a given user.

        Returns:
            dict: {previousPageCursor, nextPageCursor, data: [...]}
        """
        params = {"limit": limit, "sortOrder": sort_order}
        if cursor:
            params["cursor"] = cursor
        return self._c._get(
            f"{self.BASE}/users/{user_id}/followers",
            params=params,
        )

    def get_follower_count(self, user_id: int) -> dict:
        """
        Get the follower count for a user.

        Returns:
            dict: {count}
        """
        return self._c._get(f"{self.BASE}/users/{user_id}/followers/count")

    def get_followings(self, user_id: int, limit: int = 10,
                       cursor: Optional[str] = None,
                       sort_order: str = "Asc") -> dict:
        """
        Get users that a given user follows.

        Returns:
            dict: {previousPageCursor, nextPageCursor, data: [...]}
        """
        params = {"limit": limit, "sortOrder": sort_order}
        if cursor:
            params["cursor"] = cursor
        return self._c._get(
            f"{self.BASE}/users/{user_id}/followings",
            params=params,
        )

    def get_following_count(self, user_id: int) -> dict:
        """
        Get how many users a user is following.

        Returns:
            dict: {count}
        """
        return self._c._get(f"{self.BASE}/users/{user_id}/followings/count")

    def get_friend_requests(self, limit: int = 10,
                            cursor: Optional[str] = None) -> dict:
        """
        Get pending friend requests for the authenticated user (requires auth).

        Returns:
            dict: {previousPageCursor, nextPageCursor, data: [...]}
        """
        params = {"limit": limit}
        if cursor:
            params["cursor"] = cursor
        return self._c._get(
            f"{self.BASE}/my/friends/requests",
            params=params,
        )

    def get_friend_request_count(self) -> dict:
        """
        Get the number of pending friend requests (requires auth).

        Returns:
            dict: {count}
        """
        return self._c._get(f"{self.BASE}/user/friend-requests/count")

    def are_friends(self, user_id: int) -> dict:
        """
        Check if the authenticated user is friends with user_id (requires auth).

        Returns:
            dict: {isFriend}
        """
        return self._c._get(f"{self.BASE}/users/{user_id}/friends/statuses")
