# This file exists for editable installs (pip install -e .) compatibility.
# All package metadata lives in pyproject.toml.
from setuptools import setup
setup()
