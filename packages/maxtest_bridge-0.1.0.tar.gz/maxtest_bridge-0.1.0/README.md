# Maxtest Bridge - Python

Bridge package to integrate test results with Maxtest test management system.

## Installation

```bash
pip install maxtest-bridge
```

## Quick Start

### CLI Usage

```bash
# Set environment variables
export MAXTEST_BASE_URL=https://maxtest.example.com
export MAXTEST_API_KEY=your-api-key

# Upload results
maxtest-upload --results-dir ./allure-results --launch-name "Nightly Run"
```

### Programmatic Usage

```python
from maxtest_bridge import upload_results

result = upload_results(
    results_dir="./allure-results",
    base_url="https://maxtest.example.com",
    api_key="your-api-key",
    launch_name="Regression Tests",
    environment="staging"
)

print(result)
```

### Pytest Plugin

Install the package and enable the plugin:

```bash
# Run tests with automatic upload
pytest --maxtest-upload \
       --maxtest-launch-name "CI Pipeline" \
       --maxtest-environment "production"
```

Or configure in `pytest.ini`:

```ini
[pytest]
addopts = 
    --maxtest-upload
    --maxtest-launch-name "Automated Tests"
```

## Configuration

Configuration can be provided via:
1. **Function arguments** (highest priority)
2. **Environment variables**
3. **CLI arguments**

### Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `MAXTEST_BASE_URL` | Base URL of Maxtest API | Yes |
| `MAXTEST_API_KEY` | API key for authentication | Yes |
| `MAXTEST_PROJECT_ID` | Project identifier | No |
| `MAXTEST_LAUNCH_NAME` | Test launch name | No |
| `MAXTEST_ENVIRONMENT` | Test environment (e.g., staging) | No |
| `MAXTEST_FAIL_ON_ERROR` | Fail pipeline on upload error (default: false) | No |

### CLI Arguments

```bash
maxtest-upload \
  --results-dir ./allure-results \
  --base-url https://maxtest.example.com \
  --api-key your-api-key \
  --project-id my-project \
  --launch-name "Nightly Tests" \
  --environment staging \
  --fail-on-error \
  --timeout 60 \
  --verbose
```

## Features

- ✅ **Framework Agnostic**: Works with any test framework that generates allure-results
- ✅ **Cross-Platform**: Works on Windows, Linux, and macOS
- ✅ **Pytest Integration**: Optional plugin for automatic uploads
- ✅ **Configurable Error Handling**: Choose whether upload failures should break the pipeline
- ✅ **Clean Code**: Separation of concerns with dedicated modules
- ✅ **Type Safe**: Full type hints with Pydantic validation

## Error Handling

By default, upload failures will NOT break your CI/CD pipeline. This is intentional - your tests should pass/fail based on test results, not reporting issues.

To change this behavior:

```bash
# CLI
maxtest-upload --results-dir ./allure-results --fail-on-error

# Programmatic
upload_results(results_dir="./allure-results", fail_on_upload_error=True)

# Environment variable
export MAXTEST_FAIL_ON_ERROR=true
```

## Development

```bash
# Install in development mode
pip install -e ".[dev]"

# Run tests
pytest

# Run linting
black maxtest_bridge/
flake8 maxtest_bridge/
mypy maxtest_bridge/
```

## License

MIT
