# Examples

Focused examples showing individual Caliper SDK features.

## Prerequisites

- Python 3.12+
- SDK installed: `make install-dev` (from the repo root — installs all extras including S3)
- Environment variables loaded — copy `.env.example` to `.env`, fill in your values, then:
  ```bash
  set -a && source .env && set +a
  ```

## Examples

| File | Description |
|------|-------------|
| `anthropic_development.py` | Full feature walkthrough (Anthropic) — basic calls, streaming, metadata, linking, annotations |
| `openai_development.py` | Full feature walkthrough (OpenAI) — same features using the OpenAI SDK |
| `dev_export.py` | Dev target quick start — basic call and streaming with local JSONL output |
| `s3_export.py` | S3 target quick start — basic call and streaming with S3 export |
| `tool_use.py` | Tool capture — `capture_tools=True`, define tools, inspect captured data |

## Running

```bash
uv run python examples/anthropic_development.py
uv run python examples/openai_development.py
uv run python examples/dev_export.py
uv run python examples/s3_export.py
uv run python examples/tool_use.py
```
