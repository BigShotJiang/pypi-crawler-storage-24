"""S3 target quick start — basic call and streaming with S3 export."""

import anthropic

import caliper

######################################################################
# Basic non-streaming call
######################################################################


def basic_call(client: anthropic.Anthropic) -> None:
    response = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=128,
        messages=[{"role": "user", "content": "Say hello in exactly 5 words."}],
    )
    print(response.content[0].text)


######################################################################
# Streaming call
######################################################################


def streaming_call(client: anthropic.Anthropic) -> None:
    with client.messages.stream(
        model="claude-sonnet-4-20250514",
        max_tokens=128,
        messages=[{"role": "user", "content": "Tell me a one-sentence joke."}],
    ) as stream:
        for chunk in stream.text_stream:
            print(chunk, end="", flush=True)
        print()


######################################################################
# Main
######################################################################


def main() -> None:
    # Reads credentials from environment variables — see .env.example for the full list.
    # Load them before running: set -a && source .env && set +a
    caliper.init(target="s3", batch_size=1, s3_partition="none")

    # For S3-compatible stores (MinIO, R2, etc.), add s3_endpoint:
    #   caliper.init(target="s3", s3_endpoint="http://localhost:9000", s3_partition="none")

    client = anthropic.Anthropic()

    print("=== Basic call ===")
    basic_call(client)

    print("\n=== Streaming call ===")
    streaming_call(client)

    # Flush remaining records to S3 before exit
    caliper.shutdown()

    # Records land in S3 at keys like:
    #   records/batch_<ulid>.json
    #   annotations/batch_<ulid>.json
    print("\nRecords exported to S3. Check your bucket for new batch files.")


if __name__ == "__main__":
    main()
