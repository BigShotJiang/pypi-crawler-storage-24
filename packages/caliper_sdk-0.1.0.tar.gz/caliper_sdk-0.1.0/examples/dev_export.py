"""Dev target quick start — basic call and streaming with local JSONL output."""

import anthropic

import caliper
from caliper._export import DevHandler

######################################################################
# Basic non-streaming call
######################################################################


def basic_call(client: anthropic.Anthropic) -> None:
    response = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=128,
        messages=[{"role": "user", "content": "Say hello in exactly 5 words."}],
    )
    print(response.content[0].text)


######################################################################
# Streaming call
######################################################################


def streaming_call(client: anthropic.Anthropic) -> None:
    with client.messages.stream(
        model="claude-sonnet-4-20250514",
        max_tokens=128,
        messages=[{"role": "user", "content": "Tell me a one-sentence joke."}],
    ) as stream:
        for chunk in stream.text_stream:
            print(chunk, end="", flush=True)
        print()


######################################################################
# Inspect captured records (dev target only)
######################################################################


def inspect_records() -> None:
    handler = DevHandler()
    print("\n--- Captured records ---")
    for record in handler.get_records():
        print(
            f"  model={record['model']}"
            f"  in={record['tokens_input']}"
            f"  out={record['tokens_output']}"
            f"  status={record['status']}"
            f"  request_id={record['request_id']}"
        )


######################################################################
# Main
######################################################################


def main() -> None:
    caliper.init(target="dev")
    client = anthropic.Anthropic()

    print("=== Basic call ===")
    basic_call(client)

    print("\n=== Streaming call ===")
    streaming_call(client)

    caliper.shutdown()
    inspect_records()


if __name__ == "__main__":
    main()
