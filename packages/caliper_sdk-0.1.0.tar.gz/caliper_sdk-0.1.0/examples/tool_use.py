"""Tool capture — record which tools are provided and invoked."""

import json

import anthropic

import caliper
from caliper._export import DevHandler

######################################################################
# Define a tool
######################################################################

WEATHER_TOOL = {
    "name": "get_weather",
    "description": "Get the current weather for a city.",
    "input_schema": {
        "type": "object",
        "properties": {
            "city": {"type": "string", "description": "City name"},
        },
        "required": ["city"],
    },
}


######################################################################
# Make a tool-use call
######################################################################


def tool_use_call(client: anthropic.Anthropic) -> None:
    response = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=256,
        tools=[WEATHER_TOOL],
        messages=[{"role": "user", "content": "What's the weather in Paris?"}],
    )

    for block in response.content:
        if block.type == "text":
            print(block.text)
        elif block.type == "tool_use":
            print(f"Tool call: {block.name}({json.dumps(block.input)})")


######################################################################
# Inspect the captured record
######################################################################


def inspect_records() -> None:
    handler = DevHandler()
    print("\n--- Captured records ---")
    for record in handler.get_records():
        print(f"  tools_provided={record.get('tools_provided')}")
        print(f"  tool_calls={record.get('tool_calls')}")


######################################################################
# Main
######################################################################


def main() -> None:
    # capture_tools=True records tool names and invocations in the record
    caliper.init(target="dev", capture_tools=True)
    client = anthropic.Anthropic()

    print("=== Tool use call ===")
    tool_use_call(client)

    caliper.shutdown()
    inspect_records()


if __name__ == "__main__":
    main()
