"""Record dataclass matching the ingestion API schema."""

import platform
from dataclasses import asdict, dataclass, field

_PYTHON_RUNTIME = f"python {platform.python_version()}"


@dataclass(slots=True)
class Record:
    request_id: str
    timestamp: str
    provider: str
    model: str
    endpoint: str
    duration_ms: int
    tokens_input: int
    tokens_output: int
    tokens_total: int
    status: str
    cached: bool
    sdk_version: str
    sdk_language: str = _PYTHON_RUNTIME
    ttft_ms: int | None = None
    http_status: int | None = None
    error_code: str | None = None
    provider_request_id: str | None = None
    linked_request_id: str | None = None
    tools_provided: list[str] | None = None
    tool_calls: str | None = None
    metadata: dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> dict:
        """Serialize to dict, omitting None values for clean JSON output."""
        return {k: v for k, v in asdict(self).items() if v is not None}
