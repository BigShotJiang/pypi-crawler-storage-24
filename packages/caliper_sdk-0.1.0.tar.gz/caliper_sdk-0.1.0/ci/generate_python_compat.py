"""Generate a GitLab CI child pipeline for Python version compat testing."""

import yaml

versions = yaml.safe_load(open("compat.yaml"))["python"]["versions"]
images = [f"ghcr.io/astral-sh/uv:python{v}-bookworm" for v in versions]

pipeline = {
    "workflow": {"rules": [{"when": "always"}]},
    "python-compat-test": {
        "image": "$PYTHON_IMAGE",
        "parallel": {"matrix": [{"PYTHON_IMAGE": images}]},
        "script": [
            "uv sync --all-extras",
            "uv run pytest tests/ -v --junitxml=report.xml",
        ],
        "artifacts": {
            "reports": {"junit": "report.xml"},
            "when": "always",
        },
    },
}

print(yaml.dump(pipeline, default_flow_style=False))
