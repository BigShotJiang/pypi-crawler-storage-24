## Description

<!-- What changed and why? Link to the relevant issue if one exists. -->

## Checklist

- [ ] `make lint` passes
- [ ] `make test` passes
- [ ] New or changed behavior has test coverage
- [ ] CHANGELOG updated under `## Unreleased`
- [ ] No credentials or `.env` files committed
