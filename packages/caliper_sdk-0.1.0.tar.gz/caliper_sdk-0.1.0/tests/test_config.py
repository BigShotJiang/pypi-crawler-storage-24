"""Tests for per-target config models and build_config."""

import pytest

from caliper._config import BaseConfig, DevConfig, S3Config, build_config

# ---------------------------------------------------------------------------
# Default values per model
# ---------------------------------------------------------------------------


def test_base_config_defaults():
    config = BaseConfig()
    assert config.flush_interval == 2.0
    assert config.batch_size == 250
    assert config.max_queue_size == 10_000
    assert config.max_retries == 3
    assert config.capture_tools is False
    assert config.patch_anthropic is True
    assert config.patch_openai is True
    assert config.debug is False


def test_dev_config_defaults():
    config = DevConfig()
    assert config.file_path == "caliper_records.jsonl"
    assert config.annotations_file_path is None
    # inherits base defaults
    assert config.flush_interval == 2.0


def test_s3_config_defaults(monkeypatch):
    monkeypatch.delenv("CALIPER_S3_BUCKET", raising=False)
    monkeypatch.delenv("CALIPER_S3_REGION", raising=False)
    monkeypatch.delenv("CALIPER_S3_ACCESS_KEY", raising=False)
    monkeypatch.delenv("CALIPER_S3_SECRET_KEY", raising=False)
    monkeypatch.delenv("CALIPER_S3_ENDPOINT", raising=False)
    monkeypatch.delenv("CALIPER_S3_PARTITION", raising=False)
    config = S3Config()
    assert config.s3_bucket is None
    assert config.s3_prefix == ""
    assert config.s3_region == "us-east-1"
    assert config.s3_access_key is None
    assert config.s3_secret_key is None
    assert config.s3_endpoint is None
    assert config.s3_partition == "hour"


# ---------------------------------------------------------------------------
# Env var overrides
# ---------------------------------------------------------------------------


def test_s3_config_env_var_override(monkeypatch):
    monkeypatch.setenv("CALIPER_S3_BUCKET", "my-bucket")
    monkeypatch.setenv("CALIPER_S3_REGION", "eu-west-1")

    config = S3Config()
    assert config.s3_bucket == "my-bucket"
    assert config.s3_region == "eu-west-1"


# ---------------------------------------------------------------------------
# build_config
# ---------------------------------------------------------------------------


def test_build_config_dev():
    config = build_config("dev", file_path="custom.jsonl")
    assert isinstance(config, DevConfig)
    assert config.file_path == "custom.jsonl"


def test_build_config_s3(monkeypatch):
    monkeypatch.delenv("CALIPER_S3_BUCKET", raising=False)
    config = build_config("s3", s3_bucket="my-bucket")
    assert isinstance(config, S3Config)
    assert config.s3_bucket == "my-bucket"


def test_build_config_unknown_target():
    with pytest.raises(ValueError, match="Unknown export target"):
        build_config("kafka")


def test_build_config_ignores_irrelevant_kwargs():
    """s3_bucket is not a field on DevConfig — should be silently dropped."""
    config = build_config("dev", s3_bucket="irrelevant")
    assert isinstance(config, DevConfig)
    assert not hasattr(config, "s3_bucket")


def test_build_config_env_var_regression(monkeypatch):
    """Regression: build_config("s3", s3_prefix="x") with CALIPER_S3_BUCKET in env
    should pick up the env var for s3_bucket because it was not explicitly passed."""
    monkeypatch.setenv("CALIPER_S3_BUCKET", "from-env")

    config = build_config("s3", s3_prefix="x")
    assert isinstance(config, S3Config)
    assert config.s3_bucket == "from-env"
    assert config.s3_prefix == "x"


def test_build_config_env_overrides_explicit(monkeypatch):
    """Env var wins over kwarg passed to build_config."""
    monkeypatch.setenv("CALIPER_S3_BUCKET", "from-env")

    config = build_config("s3", s3_bucket="from-kwarg")
    assert isinstance(config, S3Config)
    assert config.s3_bucket == "from-env"


def test_build_config_kwargs_used_when_no_env(monkeypatch):
    """Kwarg applies when the corresponding env var is absent."""
    monkeypatch.delenv("CALIPER_S3_BUCKET", raising=False)
    config = build_config("s3", s3_bucket="from-kwarg")
    assert isinstance(config, S3Config)
    assert config.s3_bucket == "from-kwarg"
