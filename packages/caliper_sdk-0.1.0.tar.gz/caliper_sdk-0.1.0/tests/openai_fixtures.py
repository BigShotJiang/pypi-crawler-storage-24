"""Factory functions that build real OpenAI SDK types for tests.

Using real Pydantic models instead of SimpleNamespace means tests fail at
construction time if the SDK renames or removes fields — exactly the signal
we want from compatibility testing.
"""

from __future__ import annotations

import time

from openai.types import CompletionUsage
from openai.types.chat import ChatCompletion, ChatCompletionChunk, ChatCompletionMessage
from openai.types.chat.chat_completion import Choice
from openai.types.chat.chat_completion_chunk import Choice as ChunkChoice
from openai.types.chat.chat_completion_chunk import ChoiceDelta, ChoiceDeltaToolCall, ChoiceDeltaToolCallFunction
from openai.types.chat.chat_completion_message_tool_call import ChatCompletionMessageToolCall, Function

try:
    from openai.types.completion_usage import PromptTokensDetails
except ImportError:
    PromptTokensDetails = None


def make_usage(prompt_tokens: int = 100, completion_tokens: int = 50, cached_tokens: int = 0) -> CompletionUsage:
    kwargs: dict = {
        "prompt_tokens": prompt_tokens,
        "completion_tokens": completion_tokens,
        "total_tokens": prompt_tokens + completion_tokens,
    }
    if cached_tokens and PromptTokensDetails is not None:
        kwargs["prompt_tokens_details"] = PromptTokensDetails(cached_tokens=cached_tokens)
    return CompletionUsage(**kwargs)


def make_tool_call(
    tool_id: str = "call_1",
    name: str = "get_weather",
    arguments: str = '{"city": "NYC"}',
) -> ChatCompletionMessageToolCall:
    return ChatCompletionMessageToolCall(
        id=tool_id,
        function=Function(name=name, arguments=arguments),
        type="function",
    )


def make_response(
    model: str = "gpt-4o",
    prompt_tokens: int = 100,
    completion_tokens: int = 50,
    cached_tokens: int = 0,
    tool_calls: list[ChatCompletionMessageToolCall] | None = None,
    content: str = "Hello!",
    finish_reason: str = "stop",
) -> ChatCompletion:
    usage = make_usage(prompt_tokens, completion_tokens, cached_tokens)
    msg = ChatCompletionMessage(role="assistant", content=content, tool_calls=tool_calls)
    choice = Choice(finish_reason=finish_reason, index=0, message=msg)
    cc = ChatCompletion(
        id="chatcmpl-abc",
        choices=[choice],
        created=int(time.time()),
        model=model,
        object="chat.completion",
        usage=usage,
    )
    cc._request_id = "req_xyz123"
    return cc


def make_chunk(
    content: str | None = None,
    model: str | None = None,
    finish_reason: str | None = None,
    tool_calls: list[ChoiceDeltaToolCall] | None = None,
    usage: CompletionUsage | None = None,
) -> ChatCompletionChunk:
    has_choice = content is not None or finish_reason or tool_calls
    choices = []
    if has_choice:
        delta = ChoiceDelta(content=content, tool_calls=tool_calls)
        choices = [ChunkChoice(delta=delta, index=0, finish_reason=finish_reason)]

    chunk = ChatCompletionChunk(
        id="chatcmpl-abc",
        choices=choices,
        created=int(time.time()),
        model=model or "gpt-4o",
        object="chat.completion.chunk",
        usage=usage,
    )
    chunk._request_id = "req_stream_123"
    return chunk


def make_delta_tool_call(
    index: int = 0,
    tool_id: str | None = None,
    name: str = "",
    arguments: str = "",
) -> ChoiceDeltaToolCall:
    fn = ChoiceDeltaToolCallFunction(name=name, arguments=arguments)
    return ChoiceDeltaToolCall(index=index, id=tool_id, function=fn)
