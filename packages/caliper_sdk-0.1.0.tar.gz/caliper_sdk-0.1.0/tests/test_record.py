"""Tests for Record dataclass."""

from caliper._record import Record


def _make_record(**overrides) -> Record:
    defaults = {
        "request_id": "test-uuid",
        "timestamp": "2026-02-20T10:00:00+00:00",
        "provider": "anthropic",
        "model": "claude-sonnet-4-20250514",
        "endpoint": "chat",
        "duration_ms": 150,
        "tokens_input": 100,
        "tokens_output": 50,
        "tokens_total": 150,
        "status": "success",
        "cached": False,
        "sdk_version": "0.1.0",
    }
    defaults.update(overrides)
    return Record(**defaults)


def test_to_dict_omits_none():
    record = _make_record()
    d = record.to_dict()
    assert "ttft_ms" not in d
    assert "http_status" not in d
    assert "error_code" not in d
    assert "provider_request_id" not in d
    assert "linked_request_id" not in d


def test_to_dict_includes_zero_values():
    record = _make_record(tokens_input=0, tokens_output=0, tokens_total=0, duration_ms=0)
    d = record.to_dict()
    assert d["tokens_input"] == 0
    assert d["tokens_output"] == 0
    assert d["tokens_total"] == 0
    assert d["duration_ms"] == 0


def test_to_dict_includes_false_values():
    record = _make_record(cached=False)
    d = record.to_dict()
    assert d["cached"] is False


def test_to_dict_includes_all_set_fields():
    record = _make_record(
        ttft_ms=45,
        http_status=200,
        provider_request_id="req_abc123",
        metadata={"user_id": "42"},
    )
    d = record.to_dict()
    assert d["ttft_ms"] == 45
    assert d["http_status"] == 200
    assert d["provider_request_id"] == "req_abc123"
    assert d["metadata"] == {"user_id": "42"}


def test_field_names_match_api_schema():
    record = _make_record()
    d = record.to_dict()
    expected_fields = {
        "timestamp",
        "provider",
        "model",
        "endpoint",
        "duration_ms",
        "tokens_input",
        "tokens_output",
        "tokens_total",
        "status",
        "cached",
        "sdk_version",
        "sdk_language",
        "metadata",
    }
    assert expected_fields.issubset(d.keys())


def test_sdk_language_includes_python_version():
    import platform

    expected = f"python {platform.python_version()}"
    record = _make_record()
    assert record.sdk_language == expected
    assert record.to_dict()["sdk_language"] == expected


def test_empty_metadata_serialized():
    record = _make_record()
    d = record.to_dict()
    assert d["metadata"] == {}


def test_request_id_in_to_dict():
    record = _make_record(request_id="my-uuid-123")
    d = record.to_dict()
    assert d["request_id"] == "my-uuid-123"


def test_linked_request_id_in_to_dict():
    record = _make_record(linked_request_id="prev-uuid-456")
    d = record.to_dict()
    assert d["linked_request_id"] == "prev-uuid-456"


def test_tools_provided_round_trip():
    record = _make_record(tools_provided=["get_weather", "search"])
    d = record.to_dict()
    assert d["tools_provided"] == ["get_weather", "search"]


def test_tool_calls_round_trip():
    tool_calls_json = '[{"name": "get_weather", "id": "tu_1", "input": {"city": "NYC"}}]'
    record = _make_record(tool_calls=tool_calls_json)
    d = record.to_dict()
    assert d["tool_calls"] == tool_calls_json


def test_tools_omitted_when_none():
    record = _make_record()
    d = record.to_dict()
    assert "tools_provided" not in d
    assert "tool_calls" not in d
