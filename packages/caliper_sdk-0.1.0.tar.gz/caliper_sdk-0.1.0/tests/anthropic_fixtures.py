"""Factory functions that build real Anthropic SDK types for tests.

Using real Pydantic models instead of SimpleNamespace means tests fail at
construction time if the SDK renames or removes fields — exactly the signal
we want from compatibility testing.
"""

from __future__ import annotations

from anthropic.types import (
    Message,
    MessageDeltaUsage,
    RawContentBlockDeltaEvent,
    RawMessageDeltaEvent,
    RawMessageStartEvent,
    TextBlock,
    TextDelta,
    ToolUseBlock,
    Usage,
)
from anthropic.types.raw_message_delta_event import Delta


def make_usage(input_tokens: int = 100, output_tokens: int = 50, cache_read: int = 0) -> Usage:
    try:
        return Usage(
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cache_creation_input_tokens=0,
            cache_read_input_tokens=cache_read,
        )
    except TypeError:
        # Older SDK versions may not have cache fields
        return Usage(input_tokens=input_tokens, output_tokens=output_tokens)


def make_response(
    model: str = "claude-sonnet-4-20250514",
    input_tokens: int = 100,
    output_tokens: int = 50,
    cache_read: int = 0,
    content: list | None = None,
) -> Message:
    usage = make_usage(input_tokens, output_tokens, cache_read)
    msg = Message(
        id="msg_abc",
        content=content or [],
        model=model,
        role="assistant",
        stop_reason="end_turn",
        stop_sequence=None,
        type="message",
        usage=usage,
    )
    msg._request_id = "req_xyz123"
    return msg


def make_text_block(text: str = "Hello!") -> TextBlock:
    return TextBlock(text=text, type="text")


def make_tool_use_block(
    name: str = "get_weather",
    tool_id: str = "tu_1",
    tool_input: dict | None = None,
) -> ToolUseBlock:
    return ToolUseBlock(id=tool_id, name=name, input=tool_input or {}, type="tool_use")


def make_message_start_event(model: str = "claude-sonnet-4-20250514", input_tokens: int = 80) -> RawMessageStartEvent:
    usage = make_usage(input_tokens=input_tokens, output_tokens=0)
    msg = Message(
        id="msg_abc",
        content=[],
        model=model,
        role="assistant",
        stop_reason=None,
        stop_sequence=None,
        type="message",
        usage=usage,
    )
    msg._request_id = "req_abc"
    return RawMessageStartEvent(message=msg, type="message_start")


def make_content_block_delta_event(text: str = "Hello") -> RawContentBlockDeltaEvent:
    delta = TextDelta(text=text, type="text_delta")
    return RawContentBlockDeltaEvent(delta=delta, index=0, type="content_block_delta")


def make_message_delta_event(output_tokens: int = 42, stop_reason: str = "end_turn") -> RawMessageDeltaEvent:
    usage = MessageDeltaUsage(output_tokens=output_tokens)
    delta = Delta(stop_reason=stop_reason, stop_sequence=None, type="message_delta")
    return RawMessageDeltaEvent(delta=delta, type="message_delta", usage=usage)
