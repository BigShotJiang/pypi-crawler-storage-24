"""Tests for Anthropic SDK patching and record generation."""

from unittest.mock import MagicMock, patch

import anthropic

from caliper._anthropic import (
    _build_record_from_error,
    _build_record_from_response,
    _classify_error,
    _extract_tool_calls,
    _extract_tools_provided,
    _process_event,
)
from caliper._features import features
from caliper._patch_helpers import set_capture_tools
from tests.anthropic_fixtures import (
    make_content_block_delta_event,
    make_message_delta_event,
    make_message_start_event,
    make_response,
    make_text_block,
    make_tool_use_block,
)

# ---------------------------------------------------------------------------
# _classify_error
# ---------------------------------------------------------------------------


def test_classify_rate_limit():
    exc = anthropic.RateLimitError(
        message="rate limited",
        response=MagicMock(status_code=429),
        body=None,
    )
    status, http_status, error_code = _classify_error(exc)
    assert status == "rate_limited"
    assert http_status == 429


def test_classify_timeout():
    exc = anthropic.APITimeoutError(request=MagicMock())
    status, http_status, _ = _classify_error(exc)
    assert status == "timeout"
    assert http_status is None


def test_classify_connection_error():
    exc = anthropic.APIConnectionError(request=MagicMock())
    status, http_status, _ = _classify_error(exc)
    assert status == "api_conn_error"
    assert http_status is None


def test_classify_api_status_error():
    exc = anthropic.APIStatusError(
        message="server error",
        response=MagicMock(status_code=500),
        body=None,
    )
    status, http_status, _ = _classify_error(exc)
    assert status == "error"
    assert http_status == 500


def test_classify_generic_error():
    status, http_status, _ = _classify_error(RuntimeError("boom"))
    assert status == "error"
    assert http_status is None


# ---------------------------------------------------------------------------
# _build_record_from_response
# ---------------------------------------------------------------------------


def test_build_record_from_response():
    response = make_response(input_tokens=100, output_tokens=50)
    record = _build_record_from_response(
        response, {"model": "test"}, duration_ms=150, request_meta={}, request_id="test-uuid"
    )

    assert record.provider == "anthropic"
    assert record.model == "claude-sonnet-4-20250514"
    assert record.endpoint == "chat"
    assert record.tokens_input == 100
    assert record.tokens_output == 50
    assert record.tokens_total == 150
    assert record.status == "success"
    assert record.http_status == 200
    assert record.provider_request_id == "req_xyz123"
    assert record.cached is False


def test_build_record_from_response_cached():
    response = make_response(cache_read=50)
    record = _build_record_from_response(response, {}, duration_ms=100, request_meta={}, request_id="test-uuid")
    assert record.cached is True


# ---------------------------------------------------------------------------
# _build_record_from_error
# ---------------------------------------------------------------------------


def test_build_record_from_error():
    exc = anthropic.RateLimitError(
        message="rate limited",
        response=MagicMock(status_code=429),
        body=None,
    )
    record = _build_record_from_error(
        exc, {"model": "test-model"}, duration_ms=50, request_meta={}, request_id="test-uuid"
    )

    assert record.status == "rate_limited"
    assert record.http_status == 429
    assert record.tokens_input == 0
    assert record.tokens_output == 0
    assert record.model == "test-model"


# ---------------------------------------------------------------------------
# _process_event (streaming)
# ---------------------------------------------------------------------------


def test_process_event_message_start():
    state = {}
    event = make_message_start_event(model="claude-sonnet-4-20250514", input_tokens=80)
    result = _process_event(event, state)

    assert result is None
    assert state["model"] == "claude-sonnet-4-20250514"
    assert state["input_tokens"] == 80
    assert state["provider_request_id"] == "req_abc"


def test_process_event_content_block_delta():
    state = {}
    event = make_content_block_delta_event(text="Hello")
    result = _process_event(event, state)

    assert result == "Hello"
    assert "first_token_time" in state


def test_process_event_message_delta():
    state = {}
    event = make_message_delta_event(output_tokens=42, stop_reason="end_turn")
    result = _process_event(event, state)

    assert result is None
    assert state["output_tokens"] == 42
    assert state["stop_reason"] == "end_turn"


# ---------------------------------------------------------------------------
# Tracking never crashes user code
# ---------------------------------------------------------------------------


def test_tracking_failure_does_not_crash():
    """If _push_record fails, the user's call should still succeed."""
    response = make_response()

    with patch("caliper._patch_helpers.push_record", side_effect=RuntimeError("buffer broken")):
        record = _build_record_from_response(response, {}, duration_ms=100, request_meta={}, request_id="test-uuid")
        assert record is not None


def test_metadata_attached_to_record():
    """Feature metadata should be merged into the record."""
    response = make_response()
    with features(feature="chat", user_id="42"):
        record = _build_record_from_response(
            response, {}, duration_ms=100, request_meta={"campaign": "q4"}, request_id="test-uuid"
        )
    assert record.metadata == {"feature": "chat", "user_id": "42", "campaign": "q4"}


def test_build_record_includes_request_id():
    response = make_response()
    record = _build_record_from_response(response, {}, duration_ms=100, request_meta={}, request_id="my-req-id")
    assert record.request_id == "my-req-id"


def test_linked_request_id_from_features_context():
    """When previous_request is set in features, records should include linked_request_id."""
    response = make_response()
    with features(previous_request="prev-req-id"):
        record = _build_record_from_response(response, {}, duration_ms=100, request_meta={}, request_id="test-uuid")
    assert record.linked_request_id == "prev-req-id"


def test_linked_request_id_none_without_features():
    response = make_response()
    record = _build_record_from_response(response, {}, duration_ms=100, request_meta={}, request_id="test-uuid")
    assert record.linked_request_id is None


# ---------------------------------------------------------------------------
# _extract_tools_provided
# ---------------------------------------------------------------------------


def test_extract_tools_provided_with_tools():
    kwargs = {"tools": [{"name": "get_weather", "description": "..."}, {"name": "search", "description": "..."}]}
    result = _extract_tools_provided(kwargs)
    assert result == ["get_weather", "search"]


def test_extract_tools_provided_no_tools():
    assert _extract_tools_provided({}) is None
    assert _extract_tools_provided({"tools": []}) is None
    assert _extract_tools_provided({"tools": None}) is None


# ---------------------------------------------------------------------------
# _extract_tool_calls
# ---------------------------------------------------------------------------


def test_extract_tool_calls_with_tool_use():
    response = make_response(
        content=[
            make_text_block("Let me check the weather."),
            make_tool_use_block(name="get_weather", tool_id="tu_1", tool_input={"city": "NYC"}),
        ]
    )
    result = _extract_tool_calls(response)
    assert result is not None
    import json

    parsed = json.loads(result)
    assert len(parsed) == 1
    assert parsed[0]["name"] == "get_weather"
    assert parsed[0]["id"] == "tu_1"
    assert parsed[0]["input"] == {"city": "NYC"}


def test_extract_tool_calls_no_tool_use():
    response = make_response(content=[make_text_block("Hello!")])
    assert _extract_tool_calls(response) is None


def test_extract_tool_calls_no_content():
    response = make_response(content=[])
    assert _extract_tool_calls(response) is None


# ---------------------------------------------------------------------------
# capture_tools integration with _build_record_from_response
# ---------------------------------------------------------------------------


def test_build_record_capture_tools_enabled():
    set_capture_tools(True)
    try:
        response = make_response(
            content=[
                make_tool_use_block(name="get_weather", tool_id="tu_1", tool_input={"city": "NYC"}),
            ]
        )
        kwargs = {"model": "claude-sonnet-4-20250514", "tools": [{"name": "get_weather", "description": "..."}]}
        record = _build_record_from_response(response, kwargs, duration_ms=100, request_meta={}, request_id="test-uuid")
        assert record.tools_provided == ["get_weather"]
        assert record.tool_calls is not None
    finally:
        set_capture_tools(False)


def test_build_record_capture_tools_disabled():
    set_capture_tools(False)
    response = make_response(
        content=[
            make_tool_use_block(name="get_weather", tool_id="tu_1", tool_input={"city": "NYC"}),
        ]
    )
    kwargs = {"model": "claude-sonnet-4-20250514", "tools": [{"name": "get_weather", "description": "..."}]}
    record = _build_record_from_response(response, kwargs, duration_ms=100, request_meta={}, request_id="test-uuid")
    assert record.tools_provided is None
    assert record.tool_calls is None
