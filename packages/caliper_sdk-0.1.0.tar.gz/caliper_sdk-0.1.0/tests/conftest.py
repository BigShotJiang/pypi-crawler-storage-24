"""Pytest configuration and shared fixtures."""

import random


def pytest_addoption(parser):
    parser.addoption("--sample-percentage", type=int, default=100)


def pytest_collection_modifyitems(config, items):
    pct = config.getoption("--sample-percentage")
    if pct >= 100:
        return
    k = max(1, len(items) * pct // 100)
    items[:] = random.sample(items, k)
