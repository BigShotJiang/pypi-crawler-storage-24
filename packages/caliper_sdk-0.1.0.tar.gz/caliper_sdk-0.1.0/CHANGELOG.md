# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/).

## Unreleased

## v0.1.0 - 2026-03-08

- Add GitLab repo as the Source URL to the toml file
- Fix: APIConnectionError as `api_conn_error` rather than `timeout`
- Feat: API compatability testing
- Feat: Better error handeling within the `make_tracked_call` and `make_tracked_async_call` functions
- Feat: Python versions in compat.yaml and Python version compatability tests run locally via `make test`
- Support: Python versions 3.11 

## v0.0.0 - 2026-02-23

- First release of Caliper 🚀