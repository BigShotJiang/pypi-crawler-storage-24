def main():
    print("Hello from buildingdb!")


if __name__ == "__main__":
    main()
