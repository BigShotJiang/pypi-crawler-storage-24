from __future__ import annotations

import json
import sqlite3
from pathlib import Path

from suvra.core.service import SuvraError, SuvraService


def write_policy(root: Path) -> None:
    root.joinpath("policy.yaml").write_text(
        json.dumps(
            {
                "defaults": {"mode": "deny"},
                "rules": [
                    {
                        "id": "allow_workspace_writes",
                        "effect": "allow",
                        "type": "fs.write_file",
                        "constraints": {"path_prefix": "workspace/", "max_bytes": 1024},
                    },
                    {
                        "id": "allow_http_example",
                        "effect": "allow",
                        "type": "http.request",
                        "constraints": {
                            "method": "GET",
                            "allow_domains": ["example.com"],
                            "timeout_seconds": 2,
                        },
                    },
                ],
            }
        )
    )


def write_policy_with_write_approval(root: Path) -> None:
    root.joinpath("policy.yaml").write_text(
        json.dumps(
            {
                "defaults": {"mode": "deny"},
                "rules": [
                    {
                        "id": "write_requires_approval",
                        "effect": "needs_approval",
                        "type": "fs.write_file",
                        "constraints": {"path_prefix": "workspace/", "max_bytes": 1024},
                    }
                ],
            }
        )
    )


def write_policy_with_unknown_approval(root: Path) -> None:
    root.joinpath("policy.yaml").write_text(
        json.dumps(
            {
                "defaults": {"mode": "deny"},
                "rules": [
                    {
                        "id": "unknown_requires_approval",
                        "effect": "needs_approval",
                        "type": "unknown.action",
                        "constraints": {},
                    }
                ],
            }
        )
    )


def write_policy_with_delete_approval(root: Path) -> None:
    root.joinpath("policy.yaml").write_text(
        json.dumps(
            {
                "defaults": {"mode": "deny"},
                "rules": [
                    {
                        "id": "allow_workspace_writes",
                        "effect": "allow",
                        "type": "fs.write_file",
                        "constraints": {"path_prefix": "workspace/", "max_bytes": 1024},
                    },
                    {
                        "id": "delete_requires_approval",
                        "effect": "needs_approval",
                        "type": "fs.delete_file",
                        "constraints": {"path_prefix": "workspace/"},
                    },
                ],
            }
        )
    )


def write_policy_with_delete_allow(root: Path) -> None:
    root.joinpath("policy.yaml").write_text(
        json.dumps(
            {
                "defaults": {"mode": "deny"},
                "rules": [
                    {
                        "id": "allow_delete",
                        "effect": "allow",
                        "type": "fs.delete_file",
                        "constraints": {"path_prefix": "workspace/"},
                    },
                ],
            }
        )
    )


def count_approvals(root: Path) -> int:
    with sqlite3.connect(root / "data" / "audit.db") as conn:
        row = conn.execute("SELECT COUNT(*) FROM approvals").fetchone()
        return int(row[0]) if row else 0


def test_service_initializes_root_audit_db_with_approvals_table(tmp_path: Path) -> None:
    write_policy(tmp_path)
    SuvraService(tmp_path)
    db_path = tmp_path / "data" / "audit.db"
    assert db_path.exists()
    with sqlite3.connect(db_path) as conn:
        row = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='approvals'"
        ).fetchone()
        assert row is not None


def test_denies_by_default(tmp_path: Path) -> None:
    write_policy(tmp_path)
    service = SuvraService(tmp_path)
    action = {
        "action_id": "a1",
        "actor": "test",
        "type": "unknown.action",
        "params": {},
    }

    result = service.validate(action)
    assert result["decision"] == "deny"
    assert result["code"] == "POLICY_DENY"


def test_allows_fs_write_inside_workspace(tmp_path: Path) -> None:
    write_policy(tmp_path)
    service = SuvraService(tmp_path)
    action = {
        "action_id": "a2",
        "actor": "test",
        "type": "fs.write_file",
        "params": {"path": "workspace/out.txt", "content": "hello"},
    }

    result = service.execute(action)
    assert result["decision"] == "allow"
    assert tmp_path.joinpath("workspace/out.txt").read_text() == "hello"


def test_blocks_path_traversal(tmp_path: Path) -> None:
    write_policy(tmp_path)
    service = SuvraService(tmp_path)
    action = {
        "action_id": "a3",
        "actor": "test",
        "type": "fs.write_file",
        "params": {"path": "workspace/../evil.txt", "content": "blocked"},
    }

    try:
        service.execute(action)
        assert False, "expected path traversal to raise SuvraError"
    except SuvraError as exc:
        assert exc.code == "EXECUTION_ERROR"
        assert "within workspace" in exc.message


def test_blocks_http_domain_not_allowlist(tmp_path: Path) -> None:
    write_policy(tmp_path)
    service = SuvraService(tmp_path)
    action = {
        "action_id": "a4",
        "actor": "test",
        "type": "http.request",
        "params": {"method": "GET", "url": "https://notallowed.invalid"},
    }

    result = service.execute(action, dry_run=True)
    assert result["decision"] == "deny"
    assert result["code"] == "POLICY_DENY"


def test_needs_approval_returned_when_configured(tmp_path: Path) -> None:
    write_policy_with_write_approval(tmp_path)
    service = SuvraService(tmp_path)
    action = {
        "action_id": "na1",
        "actor": "test",
        "type": "fs.write_file",
        "params": {"path": "workspace/approval.txt", "content": "hi"},
    }

    result = service.validate(action)
    assert result["decision"] == "needs_approval"
    assert result["code"] == "POLICY_NEEDS_APPROVAL"


def test_execute_has_no_side_effect_without_approval(tmp_path: Path) -> None:
    write_policy_with_write_approval(tmp_path)
    service = SuvraService(tmp_path)
    action = {
        "action_id": "na2",
        "actor": "test",
        "type": "fs.write_file",
        "params": {"path": "workspace/pending.txt", "content": "blocked"},
    }

    result = service.execute(action)
    assert result["decision"] == "needs_approval"
    assert result["code"] == "APPROVAL_PENDING"
    assert "approval_id" in result
    assert not tmp_path.joinpath("workspace/pending.txt").exists()


def test_execute_succeeds_after_approval(tmp_path: Path) -> None:
    write_policy_with_write_approval(tmp_path)
    service = SuvraService(tmp_path)
    action = {
        "action_id": "na3",
        "actor": "test",
        "type": "fs.write_file",
        "params": {"path": "workspace/approved.txt", "content": "allowed"},
    }

    pending = service.execute(action)
    approval_id = pending["approval_id"]
    service.approve_approval(approval_id=approval_id, decided_by="admin", note="ok")

    approved_action = {**action, "meta": {"approval_id": approval_id}}
    result = service.execute(approved_action)
    assert result["decision"] == "allow"
    assert tmp_path.joinpath("workspace/approved.txt").read_text() == "allowed"


def test_approval_mismatch_fails_when_params_change(tmp_path: Path) -> None:
    write_policy_with_write_approval(tmp_path)
    service = SuvraService(tmp_path)
    action = {
        "action_id": "na4",
        "actor": "test",
        "type": "fs.write_file",
        "params": {"path": "workspace/mismatch.txt", "content": "v1"},
    }

    pending = service.execute(action)
    approval_id = pending["approval_id"]
    service.approve_approval(approval_id=approval_id, decided_by="admin")

    mismatched_action = {
        **action,
        "params": {"path": "workspace/mismatch.txt", "content": "v2"},
        "meta": {"approval_id": approval_id},
    }
    try:
        service.execute(mismatched_action)
        assert False, "expected approval mismatch to raise"
    except SuvraError as exc:
        assert exc.code == "APPROVAL_MISMATCH"


def test_backward_compatible_top_level_actor_and_approval_id_work(tmp_path: Path) -> None:
    write_policy_with_write_approval(tmp_path)
    service = SuvraService(tmp_path)
    action = {
        "action_id": "legacy1",
        "actor": "legacy-user",
        "type": "fs.write_file",
        "params": {"path": "workspace/legacy.txt", "content": "legacy"},
    }

    pending = service.execute(action)
    approval_id = pending["approval_id"]
    service.approve_approval(approval_id=approval_id, decided_by="admin")
    result = service.execute({**action, "approval_id": approval_id})

    assert result["decision"] == "allow"
    assert tmp_path.joinpath("workspace/legacy.txt").read_text() == "legacy"


def test_approved_approval_id_proceeds_to_execution_path(tmp_path: Path) -> None:
    write_policy_with_unknown_approval(tmp_path)
    service = SuvraService(tmp_path)
    action = {
        "action_id": "legacy2",
        "actor": "legacy-user",
        "type": "unknown.action",
        "params": {},
    }

    pending = service.execute(action)
    approval_id = pending["approval_id"]
    service.approve_approval(approval_id=approval_id, decided_by="admin")

    try:
        service.execute({**action, "approval_id": approval_id})
        assert False, "expected execution path to fail on unsupported action"
    except SuvraError as exc:
        assert exc.code == "EXECUTION_ERROR"


def test_request_approval_dedupes_by_actor_type_params_hash(tmp_path: Path) -> None:
    write_policy_with_write_approval(tmp_path)
    service = SuvraService(tmp_path)
    action = {
        "action_id": "dedupe-1",
        "type": "fs.write_file",
        "params": {"path": "workspace/same.txt", "content": "same"},
        "meta": {"actor": "same-user"},
    }

    first = service.request_approval(action)
    second = service.request_approval({**action, "action_id": "dedupe-2"})

    assert first["approval_id"] == second["approval_id"]
    assert second["status"] == "pending"


def test_execute_twice_without_approval_id_reuses_same_pending_approval(tmp_path: Path) -> None:
    write_policy_with_write_approval(tmp_path)
    service = SuvraService(tmp_path)
    action = {
        "action_id": "exec-dedupe-1",
        "meta": {"actor": "same-user"},
        "type": "fs.write_file",
        "params": {"path": "workspace/same-pending.txt", "content": "hello"},
    }

    first = service.execute(action)
    second = service.execute({**action, "action_id": "exec-dedupe-2"})

    assert first["decision"] == "needs_approval"
    assert second["decision"] == "needs_approval"
    assert first["approval_id"] == second["approval_id"]
    assert count_approvals(tmp_path) == 1


def test_execute_without_approval_id_reuses_existing_approved_without_new_pending(tmp_path: Path) -> None:
    write_policy_with_write_approval(tmp_path)
    service = SuvraService(tmp_path)
    action = {
        "action_id": "approved-reuse-1",
        "meta": {"actor": "same-user"},
        "type": "fs.write_file",
        "params": {"path": "workspace/reuse.txt", "content": "hello"},
    }

    pending = service.execute(action)
    approval_id = pending["approval_id"]
    service.approve_approval(approval_id=approval_id, decided_by="admin")

    result = service.execute({**action, "action_id": "approved-reuse-2"})

    assert result["decision"] == "needs_approval"
    assert result["code"] == "APPROVAL_PENDING"
    assert result.get("approved_approval_id") == approval_id
    assert "approval_id" not in result
    assert count_approvals(tmp_path) == 1


def test_delete_file_after_approval_and_rollback_restores_content(tmp_path: Path) -> None:
    write_policy_with_delete_approval(tmp_path)
    service = SuvraService(tmp_path)
    target = tmp_path / "workspace" / "demo" / "hello.txt"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(b"hello delete rollback")

    action = {
        "action_id": "del-1",
        "meta": {"actor": "deleter"},
        "type": "fs.delete_file",
        "params": {"path": "workspace/demo/hello.txt"},
    }

    pending = service.execute(action)
    assert pending["decision"] == "needs_approval"
    approval_id = pending["approval_id"]
    service.approve_approval(approval_id=approval_id, decided_by="admin")

    executed = service.execute({**action, "meta": {"actor": "deleter", "approval_id": approval_id}})
    assert executed["decision"] == "allow"
    assert not target.exists()
    delete_events = service.list_audit(action_type="fs.delete_file", status="executed", limit=1)
    assert delete_events
    rollback_payload = json.loads(delete_events[0]["rollback_payload"])
    assert rollback_payload["type"] == "fs.delete_file"
    assert rollback_payload["path"] == "workspace/demo/hello.txt"

    rolled_back = service.rollback("del-1")
    assert rolled_back["status"] == "rolled_back"
    assert target.read_bytes() == b"hello delete rollback"


def test_rollback_survives_restart(tmp_path: Path) -> None:
    write_policy(tmp_path)
    service = SuvraService(tmp_path)
    action = {
        "action_id": "restart-1",
        "actor": "test",
        "type": "fs.write_file",
        "params": {"path": "workspace/restart.txt", "content": "hello"},
    }

    executed = service.execute(action)
    assert executed["status"] == "executed"

    restarted_service = SuvraService(tmp_path, db_path=tmp_path / "data" / "audit.db")
    rolled_back = restarted_service.rollback("restart-1")

    assert rolled_back["status"] == "rolled_back"


def test_rollback_selects_latest_valid_payload_among_multiple_audit_rows(tmp_path: Path) -> None:
    write_policy(tmp_path)
    service = SuvraService(tmp_path)
    target = tmp_path / "workspace" / "rb-demo.txt"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text("rollback me")

    service.engine.audit.log_event(
        {
            "action_id": "rb-delete-1",
            "actor": "tester",
            "action_type": "fs.delete_file",
            "decision": "needs_approval",
            "dry_run": False,
            "params_hash": "p1",
            "status": "awaiting_approval",
            "result_summary": "pending approval",
            "rollback_available": False,
        }
    )
    service.engine.audit.log_event(
        {
            "action_id": "rb-delete-1",
            "actor": "tester",
            "action_type": "fs.delete_file",
            "decision": "needs_approval",
            "dry_run": False,
            "params_hash": "p1",
            "status": "awaiting_approval",
            "result_summary": "still pending approval",
            "rollback_available": False,
        }
    )
    service.engine.audit.log_event(
        {
            "action_id": "rb-delete-1",
            "actor": "tester",
            "action_type": "fs.delete_file",
            "decision": "allow",
            "dry_run": False,
            "params_hash": "p1",
            "status": "executed",
            "result_summary": "deleted file",
            "rollback_payload": {
                "type": "fs.delete_file",
                "path": "workspace/rb-demo.txt",
                "restore_b64": "cm9sbGJhY2sgbWU=",
                "restore_mode": 420,
            },
            "rollback_available": True,
        }
    )

    target.unlink()
    rolled_back = service.rollback("rb-delete-1")

    assert rolled_back["status"] == "rolled_back"
    assert target.read_text() == "rollback me"


def test_rollback_not_found_without_db_payload(tmp_path: Path) -> None:
    write_policy(tmp_path)
    service = SuvraService(tmp_path)

    rolled_back = service.rollback("missing-action")

    assert rolled_back["status"] == "not_found"
    assert rolled_back["summary"] == "no rollback payload available"


def test_rollback_not_found_when_only_non_rollback_audit_rows_exist(tmp_path: Path) -> None:
    write_policy(tmp_path)
    service = SuvraService(tmp_path)

    service.engine.audit.log_event(
        {
            "action_id": "missing-valid-payload",
            "actor": "tester",
            "action_type": "fs.write_file",
            "decision": "allow",
            "dry_run": False,
            "params_hash": "p2",
            "status": "executed",
            "result_summary": "executed without rollback payload",
            "rollback_available": False,
        }
    )
    service.engine.audit.log_event(
        {
            "action_id": "missing-valid-payload",
            "actor": "tester",
            "action_type": "fs.write_file",
            "decision": "allow",
            "dry_run": False,
            "params_hash": "p2",
            "status": "executed",
            "result_summary": "null rollback payload",
            "rollback_payload": None,
            "rollback_available": False,
        }
    )

    rolled_back = service.rollback("missing-valid-payload")

    assert rolled_back["status"] == "not_found"
    assert rolled_back["summary"] == "no rollback payload available"


def test_rollback_corrupt_payload(tmp_path: Path) -> None:
    write_policy(tmp_path)
    service = SuvraService(tmp_path)
    action = {
        "action_id": "corrupt-1",
        "actor": "test",
        "type": "fs.write_file",
        "params": {"path": "workspace/corrupt.txt", "content": "hello"},
    }

    executed = service.execute(action)
    assert executed["status"] == "executed"

    with sqlite3.connect(tmp_path / "data" / "audit.db") as conn:
        conn.execute(
            "UPDATE audit_events SET rollback_payload = 'not-valid-json' WHERE action_id = ?",
            ("corrupt-1",),
        )

    rolled_back = service.rollback("corrupt-1")

    assert rolled_back["status"] == "rollback_payload_corrupt"
    assert rolled_back["summary"] == "rollback payload is corrupt"


def test_delete_file_blocks_path_traversal(tmp_path: Path) -> None:
    write_policy_with_delete_allow(tmp_path)
    service = SuvraService(tmp_path)
    action = {
        "action_id": "del-traversal",
        "meta": {"actor": "deleter"},
        "type": "fs.delete_file",
        "params": {"path": "workspace/../evil.txt"},
    }

    try:
        service.execute(action)
        assert False, "expected delete traversal to raise SuvraError"
    except SuvraError as exc:
        assert exc.code == "EXECUTION_ERROR"
        assert "workspace/" in exc.message


def test_delete_file_non_existent_raises_execution_error(tmp_path: Path) -> None:
    write_policy_with_delete_allow(tmp_path)
    service = SuvraService(tmp_path)
    action = {
        "action_id": "del-missing",
        "meta": {"actor": "deleter"},
        "type": "fs.delete_file",
        "params": {"path": "workspace/demo/missing.txt"},
    }

    try:
        service.execute(action)
        assert False, "expected missing delete target to raise SuvraError"
    except SuvraError as exc:
        assert exc.code == "EXECUTION_ERROR"
        assert "does not exist" in exc.message
