from __future__ import annotations

from suvra.cli import main


if __name__ == "__main__":
    main()
