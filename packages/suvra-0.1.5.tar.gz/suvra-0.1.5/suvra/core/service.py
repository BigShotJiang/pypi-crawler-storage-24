from __future__ import annotations

from pathlib import Path
from typing import Any, Optional, Union

from suvra.core.engine import EnforcementEngine, SuvraError


class SuvraService:
    def __init__(self, root: Union[str, Path] = ".", db_path: Optional[Union[str, Path]] = None) -> None:
        resolved_root = Path(root)
        resolved_db_path = Path(db_path) if db_path is not None else resolved_root / "data" / "audit.db"
        self.engine = EnforcementEngine(root=resolved_root, db_path=resolved_db_path)

    def validate(self, action: dict[str, Any], dry_run: bool = True) -> dict[str, Any]:
        del dry_run
        return self.engine.validate(action)

    def simulate(self, action: dict[str, Any], policy_override: Optional[dict[str, Any]] = None) -> dict[str, Any]:
        return self.engine.simulate(action, policy_override=policy_override)

    def request_approval(self, action: dict[str, Any]) -> dict[str, Any]:
        return self.engine.request_approval(action)

    def get_approval(self, approval_id: str) -> dict[str, Any]:
        return self.engine.get_approval(approval_id)

    def approve_approval(self, approval_id: str, decided_by: str, note: Optional[str] = None) -> dict[str, Any]:
        return self.engine.approve(approval_id=approval_id, decided_by=decided_by, note=note)

    def deny_approval(self, approval_id: str, decided_by: str, note: Optional[str] = None) -> dict[str, Any]:
        return self.engine.deny(approval_id=approval_id, decided_by=decided_by, note=note)

    def execute(self, action: dict[str, Any], dry_run: Optional[bool] = None) -> dict[str, Any]:
        return self.engine.execute(action, dry_run=dry_run)

    def rollback(self, action_id: str, dry_run: bool = False) -> dict[str, Any]:
        return self.engine.rollback(action_id, dry_run=dry_run)

    def list_audit(self, **filters: Any) -> list[dict[str, Any]]:
        return self.engine.list_audit(**filters)
