from __future__ import annotations

from contextvars import ContextVar, Token
from typing import Optional

_REQUEST_ID: ContextVar[Optional[str]] = ContextVar("suvra_request_id", default=None)


def set_request_id(request_id: str) -> Token[Optional[str]]:
    return _REQUEST_ID.set(request_id)


def reset_request_id(token: Token[Optional[str]]) -> None:
    _REQUEST_ID.reset(token)


def get_request_id() -> Optional[str]:
    return _REQUEST_ID.get()
