# AGA Python SDK - Interop Tests
# Patent: USPTO App. No. 19/433,835
# Copyright (c) 2026 Attested Intelligence Holdings LLC
# SPDX-License-Identifier: Apache-2.0

"""Verify REAL TypeScript gateway bundle in Python."""

import json
from pathlib import Path

import pytest

from aga.bundle.verify import verify_bundle, verify_bundle_file


TS_BUNDLE_PATH = Path(__file__).parent / "fixtures" / "ts-evidence-bundle.json"


class TestTypeScriptInterop:
    def test_ts_bundle_exists(self):
        assert TS_BUNDLE_PATH.exists(), f"TS bundle not found at {TS_BUNDLE_PATH}"

    def test_ts_bundle_verifies(self):
        """The REAL TS gateway evidence bundle must verify in Python."""
        result = verify_bundle_file(str(TS_BUNDLE_PATH))
        assert result["algorithm_valid"], f"Algorithm check failed: {result}"
        assert result["receipt_signatures_valid"], f"Signature check failed: {result}"
        assert result["chain_integrity_valid"], f"Chain check failed: {result}"
        assert result["merkle_proofs_valid"], f"Merkle check failed: {result}"
        assert result["bundle_consistent"], f"Consistency check failed: {result}"
        assert result["overall_valid"], f"Overall verification failed: {result}"

    def test_ts_bundle_has_four_receipts(self):
        with open(TS_BUNDLE_PATH) as f:
            bundle = json.load(f)
        assert len(bundle["receipts"]) == 4
        assert len(bundle["merkle_proofs"]) == 4

    def test_ts_bundle_schema(self):
        with open(TS_BUNDLE_PATH) as f:
            bundle = json.load(f)
        assert bundle["schema_version"] == "1.0"
        assert bundle["algorithm"] == "Ed25519-SHA256-JCS"
        assert bundle["offline_capable"] is True

    def test_ts_bundle_chain_links(self):
        """Verify chain linking matches expected pattern."""
        with open(TS_BUNDLE_PATH) as f:
            bundle = json.load(f)
        receipts = bundle["receipts"]
        assert receipts[0]["previous_receipt_hash"] == ""
        for i in range(1, len(receipts)):
            assert receipts[i]["previous_receipt_hash"] != ""

    def test_verify_bundle_file_api(self):
        """Test the file-based verification API."""
        result = verify_bundle_file(str(TS_BUNDLE_PATH))
        assert result["overall_valid"]
        assert result["receipts_checked"] == 4
