# AGA Python SDK - Receipt Tests
# Patent: USPTO App. No. 19/433,835
# Copyright (c) 2026 Attested Intelligence Holdings LLC
# SPDX-License-Identifier: Apache-2.0

"""Receipt generation, chain linking, and verification tests."""

import hashlib

import pytest

from aga.receipt.model import GovernanceReceipt, ALGORITHM
from aga.receipt.generator import generate_receipt
from aga.receipt.chain import compute_receipt_hash, verify_chain
from aga.crypto.canonicalize import canonicalize
from aga.crypto.ed25519 import get_public_key, sign, verify
from aga.crypto.sha256 import sha256_hex, hex_to_bytes, bytes_to_hex


# Deterministic test seed
SEED = hashlib.sha256(b"aga-test-vector-seed-do-not-use-in-production").digest()
POLICY_REF = "de7b447c291b43a0bb683a3c2abd4fea638ae0884c77924b5c18e63fca7a1ae2"
GATEWAY_ID = "test-gateway"


class TestReceiptGeneration:
    def test_basic_generation(self):
        receipt = generate_receipt(
            tool_name="read_file",
            decision="PERMITTED",
            reason="allowed",
            request_id="req-001",
            policy_reference=POLICY_REF,
            previous_receipt_hash="",
            gateway_id=GATEWAY_ID,
            signing_key_seed=SEED,
        )
        assert receipt.tool_name == "read_file"
        assert receipt.decision == "PERMITTED"
        assert receipt.algorithm == ALGORITHM
        assert receipt.receipt_version == "1.0"
        assert receipt.method == "tools/call"
        assert receipt.previous_receipt_hash == ""
        assert len(receipt.signature) == 128  # 64 bytes hex

    def test_signature_verifies(self):
        receipt = generate_receipt(
            tool_name="read_file",
            decision="PERMITTED",
            reason="allowed",
            request_id="req-001",
            policy_reference=POLICY_REF,
            previous_receipt_hash="",
            gateway_id=GATEWAY_ID,
            signing_key_seed=SEED,
        )
        # Verify signature
        pub = hex_to_bytes(receipt.public_key)
        sig = hex_to_bytes(receipt.signature)
        from aga.crypto.canonicalize import canonicalize_bytes
        canonical = canonicalize_bytes(receipt.to_signing_dict())
        assert verify(pub, canonical, sig)

    def test_tampered_signature_fails(self):
        receipt = generate_receipt(
            tool_name="read_file",
            decision="PERMITTED",
            reason="allowed",
            request_id="req-001",
            policy_reference=POLICY_REF,
            previous_receipt_hash="",
            gateway_id=GATEWAY_ID,
            signing_key_seed=SEED,
        )
        # Tamper with decision
        receipt.decision = "DENIED"
        pub = hex_to_bytes(receipt.public_key)
        sig = hex_to_bytes(receipt.signature)
        from aga.crypto.canonicalize import canonicalize_bytes
        canonical = canonicalize_bytes(receipt.to_signing_dict())
        assert not verify(pub, canonical, sig)


class TestArgumentsHashTriState:
    def test_absent_arguments(self):
        """arguments=None -> arguments_hash=""."""
        receipt = generate_receipt(
            tool_name="test",
            decision="PERMITTED",
            reason="test",
            request_id="req-1",
            policy_reference=POLICY_REF,
            previous_receipt_hash="",
            gateway_id=GATEWAY_ID,
            signing_key_seed=SEED,
            arguments=None,
        )
        assert receipt.arguments_hash == ""

    def test_empty_object_arguments(self):
        """arguments={} -> arguments_hash=SHA-256("{}")."""
        receipt = generate_receipt(
            tool_name="test",
            decision="PERMITTED",
            reason="test",
            request_id="req-1",
            policy_reference=POLICY_REF,
            previous_receipt_hash="",
            gateway_id=GATEWAY_ID,
            signing_key_seed=SEED,
            arguments={},
        )
        expected = sha256_hex(b"{}")
        assert receipt.arguments_hash == expected

    def test_content_arguments(self):
        """arguments with content -> arguments_hash=SHA-256(canonicalize(arguments))."""
        args = {"path": "/data/report.csv", "encoding": "utf-8"}
        receipt = generate_receipt(
            tool_name="test",
            decision="PERMITTED",
            reason="test",
            request_id="req-1",
            policy_reference=POLICY_REF,
            previous_receipt_hash="",
            gateway_id=GATEWAY_ID,
            signing_key_seed=SEED,
            arguments=args,
        )
        expected = sha256_hex(canonicalize(args).encode("utf-8"))
        assert receipt.arguments_hash == expected


class TestRequestIdTypes:
    def test_string_request_id(self):
        receipt = generate_receipt(
            tool_name="test",
            decision="PERMITTED",
            reason="test",
            request_id="req-001",
            policy_reference=POLICY_REF,
            previous_receipt_hash="",
            gateway_id=GATEWAY_ID,
            signing_key_seed=SEED,
        )
        d = receipt.to_dict()
        assert isinstance(d["request_id"], str)
        assert d["request_id"] == "req-001"

    def test_numeric_request_id(self):
        receipt = generate_receipt(
            tool_name="test",
            decision="PERMITTED",
            reason="test",
            request_id=42,
            policy_reference=POLICY_REF,
            previous_receipt_hash="",
            gateway_id=GATEWAY_ID,
            signing_key_seed=SEED,
        )
        d = receipt.to_dict()
        assert isinstance(d["request_id"], int)
        assert d["request_id"] == 42

    def test_null_request_id(self):
        receipt = generate_receipt(
            tool_name="test",
            decision="PERMITTED",
            reason="test",
            request_id=None,
            policy_reference=POLICY_REF,
            previous_receipt_hash="",
            gateway_id=GATEWAY_ID,
            signing_key_seed=SEED,
        )
        d = receipt.to_dict()
        assert d["request_id"] is None


class TestChainLinking:
    def test_two_receipt_chain(self):
        r1 = generate_receipt(
            tool_name="read_file",
            decision="PERMITTED",
            reason="allowed",
            request_id="req-1",
            policy_reference=POLICY_REF,
            previous_receipt_hash="",
            gateway_id=GATEWAY_ID,
            signing_key_seed=SEED,
        )
        r1_hash = compute_receipt_hash(r1)

        r2 = generate_receipt(
            tool_name="write_file",
            decision="DENIED",
            reason="blocked",
            request_id="req-2",
            policy_reference=POLICY_REF,
            previous_receipt_hash=r1_hash,
            gateway_id=GATEWAY_ID,
            signing_key_seed=SEED,
        )
        assert r2.previous_receipt_hash == r1_hash

        valid, broken_at = verify_chain([r1, r2])
        assert valid
        assert broken_at is None

    def test_broken_chain(self):
        r1 = generate_receipt(
            tool_name="read_file",
            decision="PERMITTED",
            reason="allowed",
            request_id="req-1",
            policy_reference=POLICY_REF,
            previous_receipt_hash="",
            gateway_id=GATEWAY_ID,
            signing_key_seed=SEED,
        )
        r2 = generate_receipt(
            tool_name="write_file",
            decision="DENIED",
            reason="blocked",
            request_id="req-2",
            policy_reference=POLICY_REF,
            previous_receipt_hash="0000000000000000000000000000000000000000000000000000000000000000",
            gateway_id=GATEWAY_ID,
            signing_key_seed=SEED,
        )
        valid, broken_at = verify_chain([r1, r2])
        assert not valid
        assert broken_at == 1

    def test_unknown_algorithm_rejected(self):
        r1 = generate_receipt(
            tool_name="test",
            decision="PERMITTED",
            reason="test",
            request_id="req-1",
            policy_reference=POLICY_REF,
            previous_receipt_hash="",
            gateway_id=GATEWAY_ID,
            signing_key_seed=SEED,
        )
        r1.algorithm = "UNKNOWN-ALG"
        valid, broken_at = verify_chain([r1])
        assert not valid
        assert broken_at == 0
