# AGA Python SDK - Edge Case Tests
# Patent: USPTO App. No. 19/433,835
# Copyright (c) 2026 Attested Intelligence Holdings LLC
# SPDX-License-Identifier: Apache-2.0

"""Edge case tests for canonicalization, verification, and error handling."""

import hashlib
import json
import math

import pytest

from aga.crypto.canonicalize import canonicalize, canonicalize_bytes
from aga.crypto.ed25519 import get_public_key, sign, verify
from aga.crypto.sha256 import sha256_hex, hex_to_bytes
from aga.crypto.timestamp import normalize_timestamp
from aga.bundle.verify import verify_bundle
from aga.bundle.merkle import merkle_root, verify_merkle_proof, generate_merkle_proof
from aga import AgentSession


SEED = hashlib.sha256(b"aga-test-vector-seed-do-not-use-in-production").digest()


class TestCanonicalizationECMAScriptBoundaries:
    """Test that Python canonicalization matches ECMAScript Number.toString() exactly."""

    def test_positive_exponent_below_21_expands(self):
        """1e20 should expand to decimal, not scientific notation."""
        assert canonicalize({"n": 1e20}) == '{"n":100000000000000000000}'

    def test_positive_exponent_at_21_uses_sci(self):
        """1e21 should use scientific notation with e+."""
        assert canonicalize({"n": 1e21}) == '{"n":1e+21}'

    def test_positive_exponent_with_mantissa_below_21(self):
        """1.5e20 should expand to decimal."""
        assert canonicalize({"n": 1.5e20}) == '{"n":150000000000000000000}'

    def test_positive_exponent_with_mantissa_at_21(self):
        """1.5e21 should use scientific notation."""
        assert canonicalize({"n": 1.5e21}) == '{"n":1.5e+21}'

    def test_negative_exponent_at_minus_6_expands(self):
        """1e-6 should expand to 0.000001."""
        assert canonicalize({"n": 1e-6}) == '{"n":0.000001}'

    def test_negative_exponent_below_minus_6_uses_sci(self):
        """1e-7 should use scientific notation."""
        assert canonicalize({"n": 1e-7}) == '{"n":1e-7}'

    def test_1_23e20_expands(self):
        """1.23e20 should expand to decimal."""
        assert canonicalize({"n": 1.23e20}) == '{"n":123000000000000000000}'

    def test_1_23e21_uses_sci(self):
        """1.23e21 should use scientific notation."""
        assert canonicalize({"n": 1.23e21}) == '{"n":1.23e+21}'

    def test_1_23e15_integer_like(self):
        """1.23e15 should be handled as integer since it fits."""
        assert canonicalize({"n": 1.23e15}) == '{"n":1230000000000000}'

    def test_negative_scientific(self):
        """Negative numbers in scientific notation."""
        assert canonicalize({"n": -1e21}) == '{"n":-1e+21}'
        assert canonicalize({"n": -1e-7}) == '{"n":-1e-7}'

    def test_very_small_decimal(self):
        """Very small decimal that should expand."""
        assert canonicalize({"n": 5e-6}) == '{"n":0.000005}'

    def test_very_large_decimal(self):
        """Large number that should expand."""
        assert canonicalize({"n": 9e20}) == '{"n":900000000000000000000}'


class TestCanonicalizationEdgeCases:
    def test_non_finite_raises(self):
        with pytest.raises(ValueError):
            canonicalize({"n": float("inf")})
        with pytest.raises(ValueError):
            canonicalize({"n": float("-inf")})
        with pytest.raises(ValueError):
            canonicalize({"n": float("nan")})

    def test_unsupported_type_raises(self):
        with pytest.raises(TypeError):
            canonicalize({"n": set([1, 2])})

    def test_deeply_nested_objects(self):
        """Test 10 levels of nesting."""
        obj = {"a": 1}
        for _ in range(10):
            obj = {"nested": obj}
        result = canonicalize(obj)
        assert '"a":1' in result

    def test_empty_array(self):
        assert canonicalize({"a": []}) == '{"a":[]}'

    def test_nested_arrays(self):
        assert canonicalize({"a": [[1, 2], [3]]}) == '{"a":[[1,2],[3]]}'

    def test_unicode_string(self):
        assert canonicalize({"k": "hello"}) == '{"k":"hello"}'

    def test_control_characters_escaped(self):
        result = canonicalize({"k": "\x00\x01\x1f"})
        assert "\\u0000" in result
        assert "\\u0001" in result
        assert "\\u001f" in result

    def test_tuple_treated_as_array(self):
        """Tuples serialize the same as lists."""
        assert canonicalize({"a": (1, 2, 3)}) == canonicalize({"a": [1, 2, 3]})


class TestVerifyBundleMalformed:
    """Test verification with malformed bundles."""

    def test_empty_bundle(self):
        result = verify_bundle({})
        assert not result["overall_valid"]

    def test_empty_receipts_vacuously_valid(self):
        """Empty receipt list is vacuously valid (matches TS gateway behavior)."""
        result = verify_bundle({
            "algorithm": "Ed25519-SHA256-JCS",
            "receipts": [],
            "merkle_proofs": [],
            "merkle_root": "",
        })
        assert result["overall_valid"]

    def test_receipt_with_bad_signature(self):
        """A receipt with an invalid signature should fail."""
        with AgentSession(gateway_id="test", signing_key_seed=SEED) as s:
            s.record_tool_call("test", "PERMITTED", "ok", "1")
            bundle = s.export_bundle()
        bundle["receipts"][0]["signature"] = "ff" * 64
        result = verify_bundle(bundle)
        assert not result["overall_valid"]
        assert not result["receipt_signatures_valid"]

    def test_wrong_algorithm(self):
        result = verify_bundle({
            "algorithm": "RSA-SHA512",
            "receipts": [],
            "merkle_proofs": [],
            "merkle_root": "",
        })
        assert not result["overall_valid"]
        assert not result["algorithm_valid"]

    def test_mismatched_proof_count(self):
        """Build a valid bundle then add an extra proof."""
        with AgentSession(gateway_id="test", signing_key_seed=SEED) as s:
            s.record_tool_call("test", "PERMITTED", "ok", "1")
            bundle = s.export_bundle()
        # Add a duplicate proof
        bundle["merkle_proofs"].append(bundle["merkle_proofs"][0])
        result = verify_bundle(bundle)
        assert not result["overall_valid"]
        assert not result["bundle_consistent"]


class TestMerkleEdgeCases:
    def test_single_leaf(self):
        """Single leaf: root is the leaf itself."""
        root = merkle_root(["aabb" * 8])
        assert root == "aabb" * 8

    def test_empty_leaves_raises(self):
        with pytest.raises(ValueError):
            merkle_root([])

    def test_odd_leaf_counts(self):
        """Test various odd leaf counts (3, 5, 7)."""
        for n in [3, 5, 7]:
            leaves = [hashlib.sha256(str(i).encode()).hexdigest() for i in range(n)]
            root = merkle_root(leaves)
            assert len(root) == 64
            # Verify proofs for all leaves
            for i in range(n):
                proof = generate_merkle_proof(leaves, i)
                assert verify_merkle_proof(
                    proof["leaf_hash"],
                    proof["siblings"],
                    proof["directions"],
                    root,
                )

    def test_merkle_proof_detects_wrong_root(self):
        leaves = [hashlib.sha256(str(i).encode()).hexdigest() for i in range(4)]
        root = merkle_root(leaves)
        proof = generate_merkle_proof(leaves, 0)
        # Wrong root
        assert not verify_merkle_proof(
            proof["leaf_hash"],
            proof["siblings"],
            proof["directions"],
            "00" * 32,
        )


class TestEd25519EdgeCases:
    def test_verify_wrong_key_returns_false(self):
        seed1 = b"\x01" * 32
        seed2 = b"\x02" * 32
        msg = b"test message"
        sig = sign(seed1, msg)
        pub2 = get_public_key(seed2)
        assert not verify(pub2, msg, sig)

    def test_verify_empty_message(self):
        msg = b""
        sig = sign(SEED, msg)
        pub = get_public_key(SEED)
        assert verify(pub, msg, sig)

    def test_verify_invalid_signature_bytes(self):
        pub = get_public_key(SEED)
        assert not verify(pub, b"test", b"\x00" * 64)

    def test_verify_short_key_returns_false(self):
        """Short key should not crash, just return False."""
        assert not verify(b"\x00" * 16, b"test", b"\x00" * 64)


class TestTimestampEdgeCases:
    def test_positive_offset(self):
        result = normalize_timestamp("2026-03-18T17:22:09+02:00")
        assert result == "2026-03-18T15:22:09Z"

    def test_half_hour_offset(self):
        result = normalize_timestamp("2026-03-18T15:52:09+00:30")
        assert result == "2026-03-18T15:22:09Z"

    def test_microsecond_precision(self):
        result = normalize_timestamp("2026-03-18T15:22:09.123456Z")
        assert result == "2026-03-18T15:22:09.123456Z"

    def test_trailing_zeros_in_subseconds(self):
        result = normalize_timestamp("2026-03-18T15:22:09.100000Z")
        assert result == "2026-03-18T15:22:09.1Z"


class TestSessionEdgeCases:
    def test_large_chain(self):
        """Test a 50-receipt chain."""
        with AgentSession(gateway_id="test", signing_key_seed=SEED) as s:
            for i in range(50):
                s.record_tool_call(f"tool_{i}", "PERMITTED", "ok", str(i))
            result = s.verify()
            assert result["overall_valid"]
            assert result["receipts_checked"] == 50

    def test_all_denied(self):
        """Bundle of all-denied receipts should still verify."""
        with AgentSession(gateway_id="test", signing_key_seed=SEED) as s:
            s.record_tool_call("tool_a", "DENIED", "blocked", "1")
            s.record_tool_call("tool_b", "DENIED", "blocked", "2")
            result = s.verify()
            assert result["overall_valid"]

    def test_mixed_request_id_types(self):
        """Mix string, int, and null request IDs in one chain."""
        with AgentSession(gateway_id="test", signing_key_seed=SEED) as s:
            s.record_tool_call("tool_a", "PERMITTED", "ok", "string-id")
            s.record_tool_call("tool_b", "PERMITTED", "ok", 42)
            s.record_tool_call("tool_c", "PERMITTED", "ok", None)
            result = s.verify()
            assert result["overall_valid"]
