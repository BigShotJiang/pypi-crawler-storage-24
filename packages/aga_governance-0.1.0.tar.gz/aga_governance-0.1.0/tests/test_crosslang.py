# AGA Python SDK - Cross-Language Contract Tests
# Patent: USPTO App. No. 19/433,835
# Copyright (c) 2026 Attested Intelligence Holdings LLC
# SPDX-License-Identifier: Apache-2.0

"""
Tests against shared vectors from aga-receipt-spec.
37 vectors across 9 categories must all pass.
"""

import json
import hashlib
import struct
from pathlib import Path

import pytest

from aga.crypto.canonicalize import canonicalize, canonicalize_bytes
from aga.crypto.sha256 import sha256_hex, sha256_fields, hex_to_bytes, bytes_to_hex
from aga.crypto.ed25519 import get_public_key, sign, verify
from aga.crypto.timestamp import normalize_timestamp

VECTORS_PATH = Path(__file__).parent / "vectors" / "aga_test_vectors.json"


@pytest.fixture(scope="module")
def vectors():
    with open(VECTORS_PATH) as f:
        return json.load(f)


# --- Leaf Hash Vectors ---

def compute_leaf_hash(inputs):
    """Compute leaf hash using length-prefixed fields."""
    schema_version = inputs["schema_version"].encode("utf-8")
    protocol_version = inputs["protocol_version"].encode("utf-8")
    event_type = inputs["event_type"].encode("utf-8")
    event_id = inputs["event_id"].encode("utf-8")
    sequence_number = str(inputs["sequence_number"]).encode("utf-8")
    timestamp = inputs["timestamp"].encode("utf-8")
    previous_leaf_hash = bytes.fromhex(inputs["previous_leaf_hash_hex"])

    return sha256_fields(
        schema_version,
        protocol_version,
        event_type,
        event_id,
        sequence_number,
        timestamp,
        previous_leaf_hash,
    )


class TestLeafHashVectors:
    @pytest.mark.parametrize("vec_id", [
        "collision-prevention-A",
        "collision-prevention-B",
        "payload-exclusion",
        "timestamp-normalized",
        "timestamp-subseconds",
    ])
    def test_leaf_hash(self, vectors, vec_id):
        vec = next(v for v in vectors["leaf_hash_vectors"] if v["id"] == vec_id)
        result = compute_leaf_hash(vec["inputs"])
        assert result == vec["expected_leaf_hash_hex"], (
            f"Leaf hash mismatch for {vec_id}: got {result}"
        )

    def test_collision_prevention(self, vectors):
        vecs = vectors["leaf_hash_vectors"]
        hash_a = compute_leaf_hash(next(v for v in vecs if v["id"] == "collision-prevention-A")["inputs"])
        hash_b = compute_leaf_hash(next(v for v in vecs if v["id"] == "collision-prevention-B")["inputs"])
        assert hash_a != hash_b, "Collision prevention failed"


# --- Seal Vectors ---

class TestSealVectors:
    def test_seal_basic(self, vectors):
        vec = vectors["seal_vectors"][0]
        inputs = vec["inputs"]
        result = sha256_fields(
            bytes.fromhex(inputs["bytes_hash_hex"]),
            bytes.fromhex(inputs["metadata_hash_hex"]),
            bytes.fromhex(inputs["policy_reference_hex"]),
            bytes.fromhex(inputs["salt_hex"]),
        )
        assert result == vec["expected_sealed_hash_hex"]


# --- Merkle Vectors ---

def compute_merkle_root(leaves_hex):
    """Binary Merkle tree with odd-node promotion."""
    if len(leaves_hex) == 1:
        return leaves_hex[0]

    current_level = list(leaves_hex)
    while len(current_level) > 1:
        next_level = []
        for i in range(0, len(current_level), 2):
            if i + 1 < len(current_level):
                left = bytes.fromhex(current_level[i])
                right = bytes.fromhex(current_level[i + 1])
                node_hash = hashlib.sha256(left + right).hexdigest()
                next_level.append(node_hash)
            else:
                next_level.append(current_level[i])
        current_level = next_level
    return current_level[0]


class TestMerkleVectors:
    def test_merkle_4_leaves(self, vectors):
        vec = next(v for v in vectors["merkle_vectors"] if v["id"] == "merkle-4-leaves")
        leaves = vec["inputs"]["leaves_hex"]

        # Check intermediate nodes
        left = bytes.fromhex(leaves[0])
        right = bytes.fromhex(leaves[1])
        node_0_1 = hashlib.sha256(left + right).hexdigest()
        assert node_0_1 == vec["expected"]["node_0_1_hex"]

        left = bytes.fromhex(leaves[2])
        right = bytes.fromhex(leaves[3])
        node_2_3 = hashlib.sha256(left + right).hexdigest()
        assert node_2_3 == vec["expected"]["node_2_3_hex"]

        root = compute_merkle_root(leaves)
        assert root == vec["expected"]["merkle_root_hex"]

    def test_merkle_3_leaves_odd(self, vectors):
        vec = next(v for v in vectors["merkle_vectors"] if v["id"] == "merkle-3-leaves-odd")
        leaves = vec["inputs"]["leaves_hex"]

        # Check intermediate node
        left = bytes.fromhex(leaves[0])
        right = bytes.fromhex(leaves[1])
        node_0_1 = hashlib.sha256(left + right).hexdigest()
        assert node_0_1 == vec["expected"]["node_0_1_hex"]

        root = compute_merkle_root(leaves)
        assert root == vec["expected"]["merkle_root_hex"]

    def test_merkle_inclusion_proof(self, vectors):
        vec = next(v for v in vectors["merkle_vectors"] if v["id"] == "merkle-4-leaves")
        proof = vec["inclusion_proof_for_leaf_0"]
        leaves = vec["inputs"]["leaves_hex"]

        current = leaves[0]
        for sibling_hex, direction in zip(proof["sibling_hashes_hex"], proof["directions"]):
            left_bytes = bytes.fromhex(current if direction == "right" else sibling_hex)
            right_bytes = bytes.fromhex(sibling_hex if direction == "right" else current)
            current = hashlib.sha256(left_bytes + right_bytes).hexdigest()

        assert current == vec["expected"]["merkle_root_hex"]


# --- Canonicalization Vectors ---

class TestCanonicalizationVectors:
    @pytest.mark.parametrize("vec_id", [
        "canonical-key-order",
        "canonical-nested",
        "canonical-empty",
        "canonical-mixed-types",
        "canonical-floats-rfc8785",
    ])
    def test_canonical(self, vectors, vec_id):
        vec = next(v for v in vectors["canonicalization_vectors"] if v["id"] == vec_id)
        result = canonicalize(vec["input_json"])
        assert result == vec["expected_canonical_string"], (
            f"Canonical mismatch for {vec_id}: got {result!r}, expected {vec['expected_canonical_string']!r}"
        )

    @pytest.mark.parametrize("vec_id", [
        "canonical-key-order",
        "canonical-nested",
        "canonical-empty",
        "canonical-mixed-types",
        "canonical-floats-rfc8785",
    ])
    def test_canonical_sha256(self, vectors, vec_id):
        vec = next(v for v in vectors["canonicalization_vectors"] if v["id"] == vec_id)
        canonical_bytes = canonicalize(vec["input_json"]).encode("utf-8")
        result = hashlib.sha256(canonical_bytes).hexdigest()
        assert result == vec["expected_sha256"]


# --- Canonicalization Edge Vectors ---

class TestCanonicalizationEdgeVectors:
    @pytest.mark.parametrize("vec_id", [
        "edge-large-integer",
        "edge-integer-100",
        "edge-negative-zero",
        "edge-empty-string-key",
        "edge-escaped-chars-key",
        "edge-deeply-nested",
        "edge-mixed-types",
        "edge-array-values",
    ])
    def test_edge_canonical(self, vectors, vec_id):
        vec = next(v for v in vectors["canonicalization_edge_vectors"] if v["id"] == vec_id)
        result = canonicalize(vec["input_json"])
        assert result == vec["expected_canonical_string"], (
            f"Edge canonical mismatch for {vec_id}: got {result!r}, expected {vec['expected_canonical_string']!r}"
        )

    @pytest.mark.parametrize("vec_id", [
        "edge-large-integer",
        "edge-integer-100",
        "edge-negative-zero",
        "edge-empty-string-key",
        "edge-escaped-chars-key",
        "edge-deeply-nested",
        "edge-mixed-types",
        "edge-array-values",
    ])
    def test_edge_sha256(self, vectors, vec_id):
        vec = next(v for v in vectors["canonicalization_edge_vectors"] if v["id"] == vec_id)
        canonical_bytes = canonicalize(vec["input_json"]).encode("utf-8")
        result = hashlib.sha256(canonical_bytes).hexdigest()
        assert result == vec["expected_sha256"]


# --- Timestamp Normalization Vectors ---

class TestTimestampVectors:
    @pytest.mark.parametrize("vec_id", [
        "tz-offset-to-z",
        "already-z",
        "zero-subseconds-stripped",
        "nonzero-subseconds-preserved",
        "trailing-zero-stripped",
        "negative-offset-converted",
    ])
    def test_timestamp_normalization(self, vectors, vec_id):
        vec = next(v for v in vectors["timestamp_normalization_vectors"] if v["id"] == vec_id)
        result = normalize_timestamp(vec["input"])
        assert result == vec["expected_normalized"], (
            f"Timestamp mismatch for {vec_id}: got {result!r}"
        )


# --- Ed25519 Test Data ---

class TestEd25519:
    def test_deterministic_signature(self, vectors):
        ed_data = vectors["ed25519_test_data"]
        seed = bytes.fromhex(ed_data["seed_hex"])
        message = ed_data["test_message_utf8"].encode("utf-8")

        # Verify seed derivation
        import hashlib as hl
        expected_seed = hl.sha256(b"aga-test-vector-seed-do-not-use-in-production").digest()
        assert seed == expected_seed, "Seed derivation mismatch"

        # Verify message hash
        msg_hash = hl.sha256(message).hexdigest()
        assert msg_hash == ed_data["test_message_sha256"]

        # Sign and verify determinism (sign twice, must be identical)
        sig1 = sign(seed, message)
        sig2 = sign(seed, message)
        assert sig1 == sig2, "Ed25519 signatures not deterministic"
        assert len(sig1) == 64, "Signature must be 64 bytes"

        # Verify with public key
        pub = get_public_key(seed)
        assert verify(pub, message, sig1), "Signature verification failed"

    def test_verify_rejects_tampered(self, vectors):
        ed_data = vectors["ed25519_test_data"]
        seed = bytes.fromhex(ed_data["seed_hex"])
        message = ed_data["test_message_utf8"].encode("utf-8")

        sig = sign(seed, message)
        pub = get_public_key(seed)

        # Tamper with message
        tampered = message + b"x"
        assert not verify(pub, tampered, sig), "Should reject tampered message"


# --- Agent Governance Vectors ---

class TestAgentGovernanceVectors:
    def test_system_prompt_normalization(self, vectors):
        vec = next(v for v in vectors["agent_governance_vectors"]
                   if v["id"] == "system-prompt-normalization")
        for input_str in vec["inputs"]:
            normalized = input_str.strip()
            assert normalized == vec["expected_normalized"]
            result = hashlib.sha256(normalized.encode("utf-8")).hexdigest()
            assert result == vec["expected_sha256"]

    def test_tool_call_arguments_hash(self, vectors):
        vec = next(v for v in vectors["agent_governance_vectors"]
                   if v["id"] == "tool-call-arguments-hash")
        canonical = canonicalize(vec["input_arguments"])
        assert canonical == vec["expected_canonical"]
        result = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
        assert result == vec["expected_sha256"]

    def test_model_identity_hash(self, vectors):
        vec = next(v for v in vectors["agent_governance_vectors"]
                   if v["id"] == "model-identity-hash")
        inputs = vec["inputs"]
        concat = inputs["provider"] + inputs["model_id"] + inputs["endpoint"]
        result = hashlib.sha256(concat.encode("utf-8")).hexdigest()
        assert result == vec["expected_sha256"]


# --- Receipt Vectors ---

class TestReceiptVectors:
    @pytest.mark.parametrize("vec_id", [
        "receipt-string-request-id",
        "receipt-numeric-request-id",
        "receipt-null-request-id",
    ])
    def test_receipt_canonical(self, vectors, vec_id):
        vec = next(v for v in vectors["receipt_vectors"] if v["id"] == vec_id)
        fields = vec["fields"]
        canonical = canonicalize(fields)
        assert canonical == vec["expected_canonical_without_signature"], (
            f"Receipt canonical mismatch for {vec_id}: got {canonical!r}"
        )

    @pytest.mark.parametrize("vec_id", [
        "receipt-string-request-id",
        "receipt-numeric-request-id",
        "receipt-null-request-id",
    ])
    def test_receipt_signature(self, vectors, vec_id):
        vec = next(v for v in vectors["receipt_vectors"] if v["id"] == vec_id)
        seed = bytes.fromhex(vec["signing_key_seed_hex"])
        fields = vec["fields"]
        canonical_bytes = canonicalize(fields).encode("utf-8")
        sig = sign(seed, canonical_bytes)
        sig_hex = sig.hex()
        assert sig_hex == vec["expected_signature_hex"], (
            f"Signature mismatch for {vec_id}: got {sig_hex}"
        )

    @pytest.mark.parametrize("vec_id", [
        "receipt-string-request-id",
        "receipt-numeric-request-id",
        "receipt-null-request-id",
    ])
    def test_receipt_chain_hash(self, vectors, vec_id):
        vec = next(v for v in vectors["receipt_vectors"] if v["id"] == vec_id)
        seed = bytes.fromhex(vec["signing_key_seed_hex"])
        fields = vec["fields"]
        sig = sign(seed, canonicalize(fields).encode("utf-8"))
        sig_hex = sig.hex()

        # Chain hash = SHA256(canonical(fields + signature))
        full_receipt = dict(fields)
        full_receipt["signature"] = sig_hex
        chain_canonical = canonicalize(full_receipt).encode("utf-8")
        chain_hash = hashlib.sha256(chain_canonical).hexdigest()
        assert chain_hash == vec["expected_chain_hash"], (
            f"Chain hash mismatch for {vec_id}: got {chain_hash}"
        )
