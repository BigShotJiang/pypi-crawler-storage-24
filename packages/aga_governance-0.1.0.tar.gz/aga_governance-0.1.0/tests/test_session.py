# AGA Python SDK - Session Tests
# Patent: USPTO App. No. 19/433,835
# Copyright (c) 2026 Attested Intelligence Holdings LLC
# SPDX-License-Identifier: Apache-2.0

"""Session, decorator, and CLI tests."""

import hashlib
import json
import os
import tempfile

import pytest

from aga import AgentSession, governed, current_session, set_current_session
from aga.bundle.verify import verify_bundle


SEED = hashlib.sha256(b"aga-test-vector-seed-do-not-use-in-production").digest()


class TestAgentSession:
    def test_context_manager(self):
        with AgentSession(gateway_id="test-gw", signing_key_seed=SEED) as session:
            assert session.gateway_id == "test-gw"
            assert len(session.receipts) == 0

    def test_record_tool_call(self):
        with AgentSession(gateway_id="test-gw", signing_key_seed=SEED) as session:
            receipt = session.record_tool_call(
                tool_name="read_file",
                decision="PERMITTED",
                reason="allowed",
                request_id="req-1",
            )
            assert receipt.tool_name == "read_file"
            assert len(session.receipts) == 1

    def test_chain_builds(self):
        with AgentSession(gateway_id="test-gw", signing_key_seed=SEED) as session:
            session.record_tool_call("tool_a", "PERMITTED", "ok", "1")
            session.record_tool_call("tool_b", "DENIED", "blocked", "2")
            session.record_tool_call("tool_c", "PERMITTED", "ok", "3")

            assert len(session.receipts) == 3
            assert session.receipts[0].previous_receipt_hash == ""
            assert session.receipts[1].previous_receipt_hash != ""
            assert session.receipts[2].previous_receipt_hash != ""

    def test_export_bundle(self):
        with AgentSession(gateway_id="test-gw", signing_key_seed=SEED) as session:
            session.record_tool_call("tool_a", "PERMITTED", "ok", "1")
            session.record_tool_call("tool_b", "DENIED", "blocked", "2")

            bundle = session.export_bundle()
            assert bundle["schema_version"] == "1.0"
            assert len(bundle["receipts"]) == 2
            assert len(bundle["merkle_proofs"]) == 2

    def test_verify(self):
        with AgentSession(gateway_id="test-gw", signing_key_seed=SEED) as session:
            session.record_tool_call("tool_a", "PERMITTED", "ok", "1")
            session.record_tool_call("tool_b", "DENIED", "blocked", "2")

            result = session.verify()
            assert result["overall_valid"]

    def test_verify_chain(self):
        with AgentSession(gateway_id="test-gw", signing_key_seed=SEED) as session:
            session.record_tool_call("tool_a", "PERMITTED", "ok", "1")
            session.record_tool_call("tool_b", "DENIED", "blocked", "2")

            valid, broken_at = session.verify_chain()
            assert valid
            assert broken_at is None

    def test_empty_export_raises(self):
        with AgentSession(gateway_id="test-gw", signing_key_seed=SEED) as session:
            with pytest.raises(ValueError):
                session.export_bundle()

    def test_arguments_recorded(self):
        with AgentSession(gateway_id="test-gw", signing_key_seed=SEED) as session:
            receipt = session.record_tool_call(
                tool_name="read_file",
                decision="PERMITTED",
                reason="allowed",
                request_id="req-1",
                arguments={"path": "/data/file.txt"},
            )
            assert receipt.arguments_hash != ""


class TestDecorator:
    def test_governed_decorator(self):
        session = AgentSession(gateway_id="test-gw", signing_key_seed=SEED)
        set_current_session(session)

        @governed(tool_name="my_tool")
        def my_tool(x):
            return x * 2

        result = my_tool(5)
        assert result == 10
        assert len(session.receipts) == 1
        assert session.receipts[0].tool_name == "my_tool"

        set_current_session(None)

    def test_governed_without_session(self):
        set_current_session(None)

        @governed(tool_name="my_tool")
        def my_tool(x):
            return x * 2

        result = my_tool(5)
        assert result == 10

    def test_current_session_thread_local(self):
        assert current_session() is None
        session = AgentSession(gateway_id="test-gw", signing_key_seed=SEED)
        set_current_session(session)
        assert current_session() is session
        set_current_session(None)
        assert current_session() is None


class TestStorage:
    def test_save_and_load(self):
        with AgentSession(gateway_id="test-gw", signing_key_seed=SEED) as session:
            session.record_tool_call("test", "PERMITTED", "ok", "1")

            with tempfile.NamedTemporaryFile(suffix=".json", delete=False, mode="w") as f:
                tmppath = f.name

            try:
                from aga.storage import save_session, load_bundle
                save_session(session, path=tmppath)
                bundle = load_bundle(tmppath)
                result = verify_bundle(bundle)
                assert result["overall_valid"]
            finally:
                os.unlink(tmppath)
