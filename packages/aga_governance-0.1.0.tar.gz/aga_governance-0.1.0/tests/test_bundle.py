# AGA Python SDK - Bundle Tests
# Patent: USPTO App. No. 19/433,835
# Copyright (c) 2026 Attested Intelligence Holdings LLC
# SPDX-License-Identifier: Apache-2.0

"""Bundle compose and verify tests."""

import hashlib

import pytest

from aga.receipt.generator import generate_receipt
from aga.receipt.chain import compute_receipt_hash
from aga.bundle.compose import compose_bundle, receipt_leaf_hash
from aga.bundle.verify import verify_bundle
from aga.bundle.merkle import merkle_root, verify_merkle_proof
from aga.crypto.ed25519 import get_public_key
from aga.crypto.sha256 import bytes_to_hex


SEED = hashlib.sha256(b"aga-test-vector-seed-do-not-use-in-production").digest()
POLICY_REF = "de7b447c291b43a0bb683a3c2abd4fea638ae0884c77924b5c18e63fca7a1ae2"
GATEWAY_ID = "test-gateway"
PUB_KEY_HEX = bytes_to_hex(get_public_key(SEED))


def _make_chain(n):
    """Generate a chain of n receipts."""
    receipts = []
    prev_hash = ""
    for i in range(n):
        r = generate_receipt(
            tool_name=f"tool_{i}",
            decision="PERMITTED" if i % 2 == 0 else "DENIED",
            reason=f"reason_{i}",
            request_id=f"req-{i}",
            policy_reference=POLICY_REF,
            previous_receipt_hash=prev_hash,
            gateway_id=GATEWAY_ID,
            signing_key_seed=SEED,
        )
        prev_hash = compute_receipt_hash(r)
        receipts.append(r)
    return receipts


class TestBundleCompose:
    def test_compose_single(self):
        receipts = _make_chain(1)
        bundle = compose_bundle(receipts, GATEWAY_ID, PUB_KEY_HEX, POLICY_REF)
        assert bundle["schema_version"] == "1.0"
        assert bundle["algorithm"] == "Ed25519-SHA256-JCS"
        assert len(bundle["receipts"]) == 1
        assert len(bundle["merkle_proofs"]) == 1
        assert bundle["offline_capable"] is True

    def test_compose_four(self):
        receipts = _make_chain(4)
        bundle = compose_bundle(receipts, GATEWAY_ID, PUB_KEY_HEX, POLICY_REF)
        assert len(bundle["receipts"]) == 4
        assert len(bundle["merkle_proofs"]) == 4
        # All proofs should point to same root
        for proof in bundle["merkle_proofs"]:
            assert proof["merkle_root"] == bundle["merkle_root"]

    def test_compose_empty_raises(self):
        with pytest.raises(ValueError):
            compose_bundle([], GATEWAY_ID, PUB_KEY_HEX, POLICY_REF)


class TestBundleVerify:
    def test_verify_single(self):
        receipts = _make_chain(1)
        bundle = compose_bundle(receipts, GATEWAY_ID, PUB_KEY_HEX, POLICY_REF)
        result = verify_bundle(bundle)
        assert result["overall_valid"], f"Verification failed: {result}"

    def test_verify_four(self):
        receipts = _make_chain(4)
        bundle = compose_bundle(receipts, GATEWAY_ID, PUB_KEY_HEX, POLICY_REF)
        result = verify_bundle(bundle)
        assert result["overall_valid"], f"Verification failed: {result}"

    def test_verify_ten(self):
        receipts = _make_chain(10)
        bundle = compose_bundle(receipts, GATEWAY_ID, PUB_KEY_HEX, POLICY_REF)
        result = verify_bundle(bundle)
        assert result["overall_valid"], f"Verification failed: {result}"

    def test_tampered_signature_rejected(self):
        receipts = _make_chain(2)
        bundle = compose_bundle(receipts, GATEWAY_ID, PUB_KEY_HEX, POLICY_REF)
        # Tamper with first receipt's signature
        bundle["receipts"][0]["signature"] = "00" * 64
        result = verify_bundle(bundle)
        assert not result["overall_valid"]
        assert not result["receipt_signatures_valid"]

    def test_tampered_chain_rejected(self):
        receipts = _make_chain(3)
        bundle = compose_bundle(receipts, GATEWAY_ID, PUB_KEY_HEX, POLICY_REF)
        # Tamper with chain link
        bundle["receipts"][1]["previous_receipt_hash"] = "00" * 32
        result = verify_bundle(bundle)
        assert not result["overall_valid"]

    def test_tampered_merkle_rejected(self):
        receipts = _make_chain(2)
        bundle = compose_bundle(receipts, GATEWAY_ID, PUB_KEY_HEX, POLICY_REF)
        # Tamper with merkle root
        bundle["merkle_root"] = "00" * 32
        result = verify_bundle(bundle)
        assert not result["overall_valid"]
        assert not result["merkle_proofs_valid"]

    def test_unknown_algorithm_rejected(self):
        receipts = _make_chain(1)
        bundle = compose_bundle(receipts, GATEWAY_ID, PUB_KEY_HEX, POLICY_REF)
        bundle["algorithm"] = "UNKNOWN-ALG"
        result = verify_bundle(bundle)
        assert not result["overall_valid"]
        assert not result["algorithm_valid"]


class TestMerkleProofVerification:
    def test_proof_round_trip(self):
        receipts = _make_chain(4)
        leaf_hashes = [receipt_leaf_hash(r) for r in receipts]
        root = merkle_root(leaf_hashes)

        from aga.bundle.merkle import generate_merkle_proof
        for i in range(4):
            proof = generate_merkle_proof(leaf_hashes, i)
            assert verify_merkle_proof(
                proof["leaf_hash"],
                proof["siblings"],
                proof["directions"],
                root,
            )
