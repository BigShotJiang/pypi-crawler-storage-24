# AGA Python SDK

Cryptographic governance receipts for AI agent tool calls.

## Install

```bash
pip install aga-governance
```

## Quick Start

```python
from aga import AgentSession

async with AgentSession(gateway_id="my-gateway") as session:
    receipt = await session.record_tool_call(
        tool_name="read_file",
        decision="PERMITTED",
        reason="allowed by policy",
        request_id="req-001",
    )
    bundle = await session.export_bundle()
```

## License

Apache-2.0. Patent: USPTO App. No. 19/433,835.
