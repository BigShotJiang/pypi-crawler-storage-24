# AGA Python SDK - Session Persistence
# Patent: USPTO App. No. 19/433,835
# Copyright (c) 2026 Attested Intelligence Holdings LLC
# SPDX-License-Identifier: Apache-2.0

"""Session persistence to ~/.aga/sessions/."""

import json
import os
from pathlib import Path
from typing import Optional

from .session import AgentSession


def get_storage_dir() -> Path:
    """Get the AGA storage directory."""
    return Path.home() / ".aga" / "sessions"


def save_session(session: AgentSession, path: Optional[str] = None) -> str:
    """Save a session's bundle to disk. Returns the file path."""
    if path is None:
        storage_dir = get_storage_dir()
        storage_dir.mkdir(parents=True, exist_ok=True)
        path = str(storage_dir / f"{session.session_id}.json")

    bundle = session.export_bundle()
    with open(path, "w") as f:
        json.dump(bundle, f, indent=2)
    return path


def load_bundle(path: str) -> dict:
    """Load a bundle from disk."""
    with open(path) as f:
        return json.load(f)


def list_sessions() -> list:
    """List all saved session files."""
    storage_dir = get_storage_dir()
    if not storage_dir.exists():
        return []
    return sorted(storage_dir.glob("*.json"))
