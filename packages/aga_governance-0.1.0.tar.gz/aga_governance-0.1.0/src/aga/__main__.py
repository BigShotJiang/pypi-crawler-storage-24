# AGA Python SDK - Module entry point
from .cli import main
import sys

sys.exit(main() or 0)
