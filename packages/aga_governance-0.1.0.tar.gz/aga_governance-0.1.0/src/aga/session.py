# AGA Python SDK - Agent Session
# Patent: USPTO App. No. 19/433,835
# Copyright (c) 2026 Attested Intelligence Holdings LLC
# SPDX-License-Identifier: Apache-2.0

"""AgentSession context manager for recording tool calls."""

import hashlib
import json
import os
import uuid
from datetime import datetime, timezone
from typing import List, Optional, Union

from .crypto.ed25519 import get_public_key
from .crypto.sha256 import bytes_to_hex
from .receipt.model import GovernanceReceipt
from .receipt.generator import generate_receipt
from .receipt.chain import compute_receipt_hash, verify_chain
from .bundle.compose import compose_bundle
from .bundle.verify import verify_bundle


class AgentSession:
    """
    Context manager for recording AI agent tool calls as governance receipts.

    Usage:
        with AgentSession(gateway_id="my-gw") as session:
            session.record_tool_call("read_file", "PERMITTED", "allowed", "req-1")
            bundle = session.export_bundle()
    """

    def __init__(
        self,
        gateway_id: str,
        signing_key_seed: Optional[bytes] = None,
        policy_reference: Optional[str] = None,
        session_id: Optional[str] = None,
    ):
        self.gateway_id = gateway_id
        self.session_id = session_id or str(uuid.uuid4())

        # Generate or use provided signing key
        if signing_key_seed is None:
            self._seed = os.urandom(32)
        else:
            self._seed = signing_key_seed

        self._public_key = get_public_key(self._seed)
        self.public_key_hex = bytes_to_hex(self._public_key)

        # Policy reference (hash of policy config)
        if policy_reference is None:
            self.policy_reference = hashlib.sha256(
                f"aga-session-{self.session_id}".encode()
            ).hexdigest()
        else:
            self.policy_reference = policy_reference

        self.receipts: List[GovernanceReceipt] = []
        self._previous_hash = ""

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        return False

    def record_tool_call(
        self,
        tool_name: str,
        decision: str,
        reason: str,
        request_id: Union[str, int, None],
        arguments: Optional[dict] = None,
    ) -> GovernanceReceipt:
        """Record a tool call and return the signed receipt."""
        receipt = generate_receipt(
            tool_name=tool_name,
            decision=decision,
            reason=reason,
            request_id=request_id,
            policy_reference=self.policy_reference,
            previous_receipt_hash=self._previous_hash,
            gateway_id=self.gateway_id,
            signing_key_seed=self._seed,
            arguments=arguments,
        )
        self._previous_hash = compute_receipt_hash(receipt)
        self.receipts.append(receipt)
        return receipt

    def export_bundle(self) -> dict:
        """Export an evidence bundle from all recorded receipts."""
        if not self.receipts:
            raise ValueError("no receipts to export")
        return compose_bundle(
            self.receipts,
            self.gateway_id,
            self.public_key_hex,
            self.policy_reference,
        )

    def verify(self) -> dict:
        """Verify the current session's receipts as a bundle."""
        bundle = self.export_bundle()
        return verify_bundle(bundle)

    def verify_chain(self):
        """Verify the receipt chain integrity."""
        return verify_chain(self.receipts)
