# AGA Python SDK - Receipt Generation
# Patent: USPTO App. No. 19/433,835
# Copyright (c) 2026 Attested Intelligence Holdings LLC
# SPDX-License-Identifier: Apache-2.0

"""Receipt generation with Ed25519 signing."""

import uuid
from datetime import datetime, timezone
from typing import Optional, Union

from ..crypto.canonicalize import canonicalize, canonicalize_bytes
from ..crypto.sha256 import sha256_hex, bytes_to_hex
from ..crypto.ed25519 import get_public_key, sign
from .model import GovernanceReceipt, ALGORITHM


def generate_receipt(
    tool_name: str,
    decision: str,
    reason: str,
    request_id: Union[str, int, None],
    policy_reference: str,
    previous_receipt_hash: str,
    gateway_id: str,
    signing_key_seed: bytes,
    arguments: Optional[dict] = None,
    receipt_id: Optional[str] = None,
    timestamp: Optional[str] = None,
) -> GovernanceReceipt:
    """
    Generate a governance receipt with Ed25519 signature.

    Arguments hash tri-state per Section 3.5:
    - arguments is None (absent): hash = ""
    - arguments is empty object {}: hash = SHA-256("{}")
    - arguments has content: hash = SHA-256(canonicalize(arguments))
    """
    # Compute arguments_hash per tri-state rules
    if arguments is None:
        arguments_hash = ""
    else:
        canonical = canonicalize(arguments)
        arguments_hash = sha256_hex(canonical.encode("utf-8"))

    # Derive public key
    pub_key = get_public_key(signing_key_seed)
    public_key_hex = bytes_to_hex(pub_key)

    # Construct receipt without signature
    receipt = GovernanceReceipt(
        receipt_id=receipt_id or str(uuid.uuid4()),
        receipt_version="1.0",
        algorithm=ALGORITHM,
        timestamp=timestamp or datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        request_id=request_id,
        method="tools/call",
        tool_name=tool_name,
        decision=decision,
        reason=reason,
        policy_reference=policy_reference,
        arguments_hash=arguments_hash,
        previous_receipt_hash=previous_receipt_hash,
        gateway_id=gateway_id,
        signature="",
        public_key=public_key_hex,
    )

    # Canonicalize receipt WITHOUT signature field
    signing_dict = receipt.to_signing_dict()
    canonical_bytes = canonicalize_bytes(signing_dict)

    # Sign
    sig = sign(signing_key_seed, canonical_bytes)
    receipt.signature = bytes_to_hex(sig)

    return receipt
