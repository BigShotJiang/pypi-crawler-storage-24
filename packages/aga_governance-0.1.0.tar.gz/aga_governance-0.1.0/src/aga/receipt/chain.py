# AGA Python SDK - Receipt Chain
# Patent: USPTO App. No. 19/433,835
# Copyright (c) 2026 Attested Intelligence Holdings LLC
# SPDX-License-Identifier: Apache-2.0

"""Receipt chain linking and verification."""

import hmac
from typing import List, Optional, Tuple

from ..crypto.canonicalize import canonicalize_bytes
from ..crypto.sha256 import sha256_hex, hex_to_bytes
from ..crypto.ed25519 import verify as ed25519_verify
from .model import GovernanceReceipt, ALGORITHM


def compute_receipt_hash(receipt: GovernanceReceipt) -> str:
    """
    Compute the hash of a receipt for chain linking.
    SHA-256(canonicalize(receipt)) - INCLUDES the signature field.
    This is the ChainDigest.
    """
    canonical = canonicalize_bytes(receipt.to_dict())
    return sha256_hex(canonical)


def verify_chain(receipts: List[GovernanceReceipt]) -> Tuple[bool, Optional[int]]:
    """
    Verify an ordered chain of governance receipts.

    Returns (valid, broken_at) where broken_at is the index of the
    first broken receipt, or None if all valid.

    Checks:
    1. Algorithm field must be "Ed25519-SHA256-JCS" (fail closed on unknown)
    2. First receipt's previous_receipt_hash must be ""
    3. Each subsequent receipt's previous_receipt_hash must match
       computeReceiptHash(previousReceipt)
    4. Each receipt's Ed25519 signature must be valid
    """
    for i, receipt in enumerate(receipts):
        # Check algorithm (fail closed)
        if receipt.algorithm != ALGORITHM:
            return (False, i)

        # Check chain linkage
        if i == 0:
            if receipt.previous_receipt_hash != "":
                return (False, 0)
        else:
            expected_hash = compute_receipt_hash(receipts[i - 1])
            if not _constant_time_equal(receipt.previous_receipt_hash, expected_hash):
                return (False, i)

        # Verify signature
        signing_dict = receipt.to_signing_dict()
        canonical_bytes = canonicalize_bytes(signing_dict)
        sig_bytes = hex_to_bytes(receipt.signature)
        pub_bytes = hex_to_bytes(receipt.public_key)

        if not ed25519_verify(pub_bytes, canonical_bytes, sig_bytes):
            return (False, i)

    return (True, None)


def _constant_time_equal(a: str, b: str) -> bool:
    """Constant-time comparison of two strings."""
    if len(a) != len(b):
        return False
    return hmac.compare_digest(a.encode("utf-8"), b.encode("utf-8"))
