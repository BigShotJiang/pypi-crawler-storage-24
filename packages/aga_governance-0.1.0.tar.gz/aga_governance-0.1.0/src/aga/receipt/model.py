# AGA Python SDK - Governance Receipt Model
# Patent: USPTO App. No. 19/433,835
# Copyright (c) 2026 Attested Intelligence Holdings LLC
# SPDX-License-Identifier: Apache-2.0

"""GovernanceReceipt dataclass with 15 fields."""

from dataclasses import dataclass, field
from typing import Optional, Union


ALGORITHM = "Ed25519-SHA256-JCS"


@dataclass
class GovernanceReceipt:
    receipt_id: str
    receipt_version: str
    algorithm: str
    timestamp: str
    request_id: Union[str, int, None]
    method: str
    tool_name: str
    decision: str  # "PERMITTED" or "DENIED"
    reason: str
    policy_reference: str
    arguments_hash: str
    previous_receipt_hash: str
    gateway_id: str
    signature: str
    public_key: str

    def to_dict(self) -> dict:
        """Convert to dict preserving request_id type (string/int/null)."""
        return {
            "algorithm": self.algorithm,
            "arguments_hash": self.arguments_hash,
            "decision": self.decision,
            "gateway_id": self.gateway_id,
            "method": self.method,
            "policy_reference": self.policy_reference,
            "previous_receipt_hash": self.previous_receipt_hash,
            "public_key": self.public_key,
            "receipt_id": self.receipt_id,
            "receipt_version": self.receipt_version,
            "reason": self.reason,
            "request_id": self.request_id,
            "signature": self.signature,
            "timestamp": self.timestamp,
            "tool_name": self.tool_name,
        }

    def to_signing_dict(self) -> dict:
        """Convert to dict WITHOUT signature field (for SigningDigest)."""
        d = self.to_dict()
        del d["signature"]
        return d
