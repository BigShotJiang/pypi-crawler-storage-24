# AGA Python SDK - Agent Governance Auditor
# Patent: USPTO App. No. 19/433,835
# Copyright (c) 2026 Attested Intelligence Holdings LLC
# SPDX-License-Identifier: Apache-2.0

"""AGA Python SDK for cryptographic governance receipts."""

__version__ = "0.1.0"

from .session import AgentSession
from .decorator import governed, current_session, set_current_session
from .receipt.model import GovernanceReceipt
from .receipt.generator import generate_receipt
from .receipt.chain import compute_receipt_hash, verify_chain
from .bundle.compose import compose_bundle
from .bundle.verify import verify_bundle, verify_bundle_file
from .storage import save_session, load_bundle, list_sessions

__all__ = [
    "AgentSession",
    "GovernanceReceipt",
    "governed",
    "current_session",
    "set_current_session",
    "generate_receipt",
    "compute_receipt_hash",
    "verify_chain",
    "compose_bundle",
    "verify_bundle",
    "verify_bundle_file",
    "save_session",
    "load_bundle",
    "list_sessions",
]
