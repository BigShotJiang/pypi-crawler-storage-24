# AGA Python SDK - CLI
# Patent: USPTO App. No. 19/433,835
# Copyright (c) 2026 Attested Intelligence Holdings LLC
# SPDX-License-Identifier: Apache-2.0

"""CLI: aga init, aga verify, aga sessions, aga export, aga receipts."""

import argparse
import json
import os
import sys
from pathlib import Path

from . import __version__


def cmd_verify(args):
    """Verify an evidence bundle."""
    from .bundle.verify import verify_bundle_file

    path = args.bundle
    if not os.path.exists(path):
        print(f"Error: file not found: {path}", file=sys.stderr)
        return 1

    result = verify_bundle_file(path)

    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print(f"Bundle: {path}")
        print(f"Algorithm: {result['algorithm']}")
        print(f"Receipts checked: {result['receipts_checked']}")
        print(f"  Algorithm valid:    {result['algorithm_valid']}")
        print(f"  Signatures valid:   {result['receipt_signatures_valid']}")
        print(f"  Chain integrity:    {result['chain_integrity_valid']}")
        print(f"  Merkle proofs:      {result['merkle_proofs_valid']}")
        print(f"  Bundle consistent:  {result['bundle_consistent']}")
        print()
        if result["overall_valid"]:
            print("Verification: PASSED")
        else:
            print("Verification: FAILED")
            if result.get("error"):
                print(f"Error: {result['error']}")

    return 0 if result["overall_valid"] else 1


def cmd_init(args):
    """Initialize AGA in the current directory."""
    storage_dir = Path.home() / ".aga"
    storage_dir.mkdir(parents=True, exist_ok=True)
    (storage_dir / "sessions").mkdir(parents=True, exist_ok=True)
    print(f"AGA initialized. Storage: {storage_dir}")
    return 0


def cmd_sessions(args):
    """List saved sessions."""
    from .storage import list_sessions

    sessions = list_sessions()
    if not sessions:
        print("No saved sessions.")
        return 0

    for s in sessions:
        print(f"  {s.stem}  ({s})")
    print(f"\n{len(sessions)} session(s) found.")
    return 0


def cmd_export(args):
    """Export a session bundle."""
    from .storage import load_bundle

    path = args.session
    if not os.path.exists(path):
        print(f"Error: file not found: {path}", file=sys.stderr)
        return 1

    bundle = load_bundle(path)
    if args.output:
        with open(args.output, "w") as f:
            json.dump(bundle, f, indent=2)
        print(f"Exported to {args.output}")
    else:
        print(json.dumps(bundle, indent=2))
    return 0


def cmd_receipts(args):
    """Show receipts from a bundle."""
    if not os.path.exists(args.bundle):
        print(f"Error: file not found: {args.bundle}", file=sys.stderr)
        return 1

    with open(args.bundle) as f:
        bundle = json.load(f)

    receipts = bundle.get("receipts", [])
    print(f"Bundle: {args.bundle}")
    print(f"Receipts: {len(receipts)}\n")

    for i, r in enumerate(receipts):
        print(f"  [{i}] {r.get('tool_name', '?')} - {r.get('decision', '?')}")
        print(f"      ID: {r.get('receipt_id', '?')}")
        print(f"      Request: {r.get('request_id', '?')}")
        print(f"      Time: {r.get('timestamp', '?')}")
        if r.get("reason"):
            print(f"      Reason: {r['reason']}")
        print()
    return 0


def main():
    parser = argparse.ArgumentParser(
        prog="aga",
        description="AGA - Agent Governance Auditor CLI",
    )
    parser.add_argument("--version", action="version", version=f"aga {__version__}")

    subparsers = parser.add_subparsers(dest="command")

    # aga init
    subparsers.add_parser("init", help="Initialize AGA storage")

    # aga verify
    verify_parser = subparsers.add_parser("verify", help="Verify an evidence bundle")
    verify_parser.add_argument("bundle", help="Path to evidence bundle JSON")
    verify_parser.add_argument("--json", action="store_true", help="Output as JSON")

    # aga sessions
    subparsers.add_parser("sessions", help="List saved sessions")

    # aga export
    export_parser = subparsers.add_parser("export", help="Export a session bundle")
    export_parser.add_argument("session", help="Path to session file")
    export_parser.add_argument("-o", "--output", help="Output file path")

    # aga receipts
    receipts_parser = subparsers.add_parser("receipts", help="Show receipts from a bundle")
    receipts_parser.add_argument("bundle", help="Path to evidence bundle JSON")

    args = parser.parse_args()
    if args.command is None:
        parser.print_help()
        return 0

    commands = {
        "init": cmd_init,
        "verify": cmd_verify,
        "sessions": cmd_sessions,
        "export": cmd_export,
        "receipts": cmd_receipts,
    }
    return commands[args.command](args)


if __name__ == "__main__":
    sys.exit(main() or 0)
