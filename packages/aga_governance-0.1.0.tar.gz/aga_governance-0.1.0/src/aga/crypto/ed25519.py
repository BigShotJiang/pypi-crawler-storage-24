# AGA Python SDK - Ed25519 Signatures
# Patent: USPTO App. No. 19/433,835
# Copyright (c) 2026 Attested Intelligence Holdings LLC
# SPDX-License-Identifier: Apache-2.0

"""Ed25519 sign/verify via PyNaCl."""

from nacl.signing import SigningKey, VerifyKey
from nacl.exceptions import BadSignatureError


def get_public_key(seed: bytes) -> bytes:
    """Derive an Ed25519 public key from a 32-byte seed."""
    sk = SigningKey(seed)
    return bytes(sk.verify_key)


def sign(seed: bytes, message: bytes) -> bytes:
    """Sign a message with a 32-byte Ed25519 seed. Returns 64-byte signature."""
    sk = SigningKey(seed)
    signed = sk.sign(message)
    return signed.signature


def verify(public_key: bytes, message: bytes, signature: bytes) -> bool:
    """Verify an Ed25519 signature. Returns True if valid, False otherwise."""
    try:
        vk = VerifyKey(public_key)
        vk.verify(message, signature)
        return True
    except (BadSignatureError, ValueError, TypeError):
        return False
