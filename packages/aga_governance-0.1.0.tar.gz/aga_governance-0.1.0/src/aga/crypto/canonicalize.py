# AGA Python SDK - RFC 8785 JSON Canonicalization Scheme (JCS)
# Patent: USPTO App. No. 19/433,835
# Copyright (c) 2026 Attested Intelligence Holdings LLC
# SPDX-License-Identifier: Apache-2.0

"""
RFC 8785 JSON Canonicalization Scheme (JCS).
Produces deterministic JSON output with sorted keys and
ECMAScript-compliant number serialization.

Critical interop rules:
- bool checked BEFORE int (Python subclass trap)
- -0 serializes as "0"
- Key sort by Unicode code point
- No Unicode normalization
- Floats: 1.0 -> "1", 1e-10 -> "1e-10" (ECMAScript Number.toString())
"""

import math


def canonicalize(value):
    """RFC 8785 JSON Canonicalization."""
    return _serialize_value(value)


def canonicalize_bytes(value):
    """Canonicalize a value and return as UTF-8 bytes."""
    return canonicalize(value).encode("utf-8")


def _serialize_value(value):
    if value is None:
        return "null"
    # bool MUST be checked before int (bool is subclass of int in Python)
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        return _serialize_number(value)
    if isinstance(value, str):
        return _serialize_string(value)
    if isinstance(value, (list, tuple)):
        return "[" + ",".join(_serialize_value(v) for v in value) + "]"
    if isinstance(value, dict):
        return _serialize_object(value)
    raise TypeError(f"unsupported type: {type(value).__name__}")


def _serialize_number(n):
    """Serialize a number per RFC 8785 / ECMAScript Number.toString() rules."""
    # Negative zero becomes positive zero
    if n == 0.0 and math.copysign(1.0, n) == -1.0:
        return "0"
    if not math.isfinite(n):
        raise ValueError("non-finite number")
    # If the float is an exact integer, serialize without decimal point
    if n == int(n) and abs(n) < 2**53:
        return str(int(n))
    # ECMAScript Number.toString() serialization for all other floats
    return _ecmascript_number_to_string(n)


def _ecmascript_number_to_string(n):
    """
    Replicate ECMAScript Number.toString() for IEEE 754 doubles.

    ECMAScript spec (ECMA-262 7.1.12.1) rules for scientific notation:
    - Negative exponent < -6: use scientific notation (e.g., 1e-7)
    - Negative exponent >= -6: expand to decimal (e.g., 0.000001)
    - Positive exponent < 21: expand to decimal (e.g., 100000000000000000000)
    - Positive exponent >= 21: use scientific notation (e.g., 1e+21)
    - Scientific notation uses 'e+' for positive, 'e-' for negative exponents
    """
    # Use repr to get the shortest round-trippable representation
    s = repr(n)

    if "e" in s or "E" in s:
        # Python produced scientific notation - we need to decide whether
        # ECMAScript would also use scientific notation or expand to decimal
        s = s.lower()
        mantissa_str, exp_str = s.split("e")
        exp_val = int(exp_str)

        # Strip trailing zeros from mantissa for clean representation
        if "." in mantissa_str:
            mantissa_str = mantissa_str.rstrip("0").rstrip(".")

        # Get the significant digits without the decimal point
        negative = mantissa_str.startswith("-")
        abs_mantissa = mantissa_str.lstrip("-")
        if "." in abs_mantissa:
            integer_part, frac_part = abs_mantissa.split(".")
            digits = integer_part + frac_part
            # Adjust exponent: mantissa "1.23" means digits "123" with exp adjusted
            exp_adjusted = exp_val - len(frac_part)
        else:
            digits = abs_mantissa
            exp_adjusted = exp_val

        # Total number of digits
        k = len(digits)
        # n = (digits) * 10^(exp_adjusted), and the "ECMAScript exponent" e = k + exp_adjusted - 1
        # which equals the position of the leading digit
        e = k + exp_adjusted - 1  # this is the ECMAScript 'e' (power of 10 of leading digit)

        sign = "-" if negative else ""

        if e >= 0 and e < 21:
            # Expand to decimal (no scientific notation)
            # We need e+1 digits before the decimal point
            digits_needed = e + 1
            if digits_needed >= k:
                # Pad with zeros: e.g., digits="15" e=20 -> "150000000000000000000"
                return sign + digits + "0" * (digits_needed - k)
            else:
                # Insert decimal point: e.g., digits="123" e=1 -> "12.3"
                return sign + digits[:digits_needed] + "." + digits[digits_needed:]
        elif e < 0 and e >= -6:
            # Expand to decimal with leading zeros: e.g., e=-6 -> "0.000001..."
            return sign + "0." + "0" * (-(e + 1)) + digits
        else:
            # Use scientific notation
            if k == 1:
                return sign + digits + "e" + ("+" if e >= 0 else "") + str(e)
            else:
                return sign + digits[0] + "." + digits[1:] + "e" + ("+" if e >= 0 else "") + str(e)
    else:
        # Python did not use scientific notation - check if ECMAScript would
        # For numbers Python renders as plain decimal, ECMAScript also uses plain
        # decimal in the same range, so just return as-is
        return s


def _serialize_string(s):
    """Serialize a string with JSON escaping per RFC 8785."""
    result = ['"']
    for ch in s:
        code = ord(ch)
        if ch == '"':
            result.append('\\"')
        elif ch == '\\':
            result.append('\\\\')
        elif ch == '\b':
            result.append('\\b')
        elif ch == '\f':
            result.append('\\f')
        elif ch == '\n':
            result.append('\\n')
        elif ch == '\r':
            result.append('\\r')
        elif ch == '\t':
            result.append('\\t')
        elif code < 0x20:
            result.append(f'\\u{code:04x}')
        else:
            result.append(ch)
    result.append('"')
    return "".join(result)


def _serialize_object(obj):
    """Serialize an object with keys sorted by Unicode code point order (RFC 8785)."""
    keys = sorted(obj.keys())
    pairs = [_serialize_string(k) + ":" + _serialize_value(obj[k]) for k in keys]
    return "{" + ",".join(pairs) + "}"
