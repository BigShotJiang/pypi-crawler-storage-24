# AGA Python SDK - SHA-256 and Encoding
# Patent: USPTO App. No. 19/433,835
# Copyright (c) 2026 Attested Intelligence Holdings LLC
# SPDX-License-Identifier: Apache-2.0

"""SHA-256 hashing, hex encoding, and length-prefixed field hashing."""

import hashlib
import struct


def sha256(data: bytes) -> bytes:
    """Compute SHA-256 hash of raw bytes."""
    return hashlib.sha256(data).digest()


def sha256_hex(data: bytes) -> str:
    """Compute SHA-256 hash and return as lowercase hex string."""
    return hashlib.sha256(data).hexdigest()


def hex_to_bytes(hex_str: str) -> bytes:
    """Convert a hex string to bytes."""
    return bytes.fromhex(hex_str)


def bytes_to_hex(data: bytes) -> str:
    """Convert bytes to a lowercase hex string."""
    return data.hex()


def write_field(data: bytes) -> bytes:
    """Encode a field as a 4-byte big-endian length prefix followed by the data."""
    return struct.pack(">I", len(data)) + data


def sha256_fields(*fields: bytes) -> str:
    """Concatenate length-prefixed fields, then SHA-256 hash. Returns hex string."""
    h = hashlib.sha256()
    for field in fields:
        h.update(write_field(field))
    return h.hexdigest()
