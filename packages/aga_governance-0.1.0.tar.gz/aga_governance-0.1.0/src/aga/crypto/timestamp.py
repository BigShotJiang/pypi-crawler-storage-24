# AGA Python SDK - Timestamp Normalization
# Patent: USPTO App. No. 19/433,835
# Copyright (c) 2026 Attested Intelligence Holdings LLC
# SPDX-License-Identifier: Apache-2.0

"""
Normalize ISO 8601 timestamps to AGA canonical form:
- Convert any timezone offset to UTC (Z suffix)
- Strip trailing ".000" (all-zero) sub-seconds
- Preserve non-zero sub-seconds but strip trailing zeros
- Always use "Z" suffix, never "+00:00"
"""

import re
from datetime import datetime, timezone


def normalize_timestamp(ts: str) -> str:
    """Normalize an ISO 8601 timestamp to AGA canonical form."""
    # Extract sub-seconds from original string before parsing
    # (datetime parsing may lose precision beyond microseconds)
    sub_second_match = re.search(r"\.(\d+)", ts)

    # Parse the timestamp to handle timezone conversion
    # Replace Z with +00:00 for fromisoformat compatibility
    parse_str = ts.replace("Z", "+00:00")
    dt = datetime.fromisoformat(parse_str)

    # Convert to UTC
    dt_utc = dt.astimezone(timezone.utc)

    # Format base: YYYY-MM-DDTHH:MM:SS
    result = dt_utc.strftime("%Y-%m-%dT%H:%M:%S")

    # Handle sub-second precision from the original string
    if sub_second_match:
        sub_seconds = sub_second_match.group(1)
        # Strip trailing zeros
        trimmed = sub_seconds.rstrip("0")
        if trimmed:
            result += "." + trimmed

    result += "Z"
    return result
