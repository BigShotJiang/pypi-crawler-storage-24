# AGA Python SDK - Decorator
# Patent: USPTO App. No. 19/433,835
# Copyright (c) 2026 Attested Intelligence Holdings LLC
# SPDX-License-Identifier: Apache-2.0

"""@governed decorator and current_session() thread-local."""

import functools
import threading
from typing import Optional

from .session import AgentSession

_thread_local = threading.local()


def current_session() -> Optional[AgentSession]:
    """Get the current thread-local AgentSession, or None."""
    return getattr(_thread_local, "session", None)


def set_current_session(session: Optional[AgentSession]):
    """Set the current thread-local AgentSession."""
    _thread_local.session = session


def governed(tool_name: str = "", decision: str = "PERMITTED", reason: str = "decorator"):
    """
    Decorator that records a governance receipt for each call.

    Usage:
        @governed(tool_name="read_file")
        def read_file(path):
            ...
    """
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            session = current_session()
            name = tool_name or func.__name__
            if session is not None:
                session.record_tool_call(
                    tool_name=name,
                    decision=decision,
                    reason=reason,
                    request_id=None,
                    arguments=kwargs if kwargs else None,
                )
            return func(*args, **kwargs)
        return wrapper
    return decorator
