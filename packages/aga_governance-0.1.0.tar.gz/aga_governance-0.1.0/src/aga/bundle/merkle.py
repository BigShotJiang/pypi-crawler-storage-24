# AGA Python SDK - Merkle Tree
# Patent: USPTO App. No. 19/433,835
# Copyright (c) 2026 Attested Intelligence Holdings LLC
# SPDX-License-Identifier: Apache-2.0

"""Binary Merkle tree with odd-node promotion."""

import hashlib
import hmac
from typing import List


def merkle_node_hash(left_hex: str, right_hex: str) -> str:
    """SHA-256(left || right) for two 32-byte hash values."""
    left = bytes.fromhex(left_hex)
    right = bytes.fromhex(right_hex)
    return hashlib.sha256(left + right).hexdigest()


def merkle_root(leaves_hex: List[str]) -> str:
    """
    Compute the Merkle root of a list of leaf hashes (hex strings).
    Binary tree: pairs hashed together, odd nodes promoted (not duplicated).
    """
    if not leaves_hex:
        raise ValueError("cannot compute Merkle root of empty list")
    if len(leaves_hex) == 1:
        return leaves_hex[0]

    current_level = list(leaves_hex)
    while len(current_level) > 1:
        next_level = []
        for i in range(0, len(current_level), 2):
            if i + 1 < len(current_level):
                node_hash = merkle_node_hash(current_level[i], current_level[i + 1])
                next_level.append(node_hash)
            else:
                next_level.append(current_level[i])
        current_level = next_level
    return current_level[0]


def generate_merkle_proof(
    leaves_hex: List[str], leaf_index: int
) -> dict:
    """
    Generate a Merkle inclusion proof for a specific leaf index.
    Returns dict with leaf_hash, leaf_index, siblings, directions, merkle_root.
    """
    siblings = []
    directions = []

    current_level = list(leaves_hex)
    idx = leaf_index

    while len(current_level) > 1:
        next_level = []
        for i in range(0, len(current_level), 2):
            if i + 1 < len(current_level):
                node_hash = merkle_node_hash(current_level[i], current_level[i + 1])
                next_level.append(node_hash)
            else:
                next_level.append(current_level[i])

        if idx % 2 == 0:
            if idx + 1 < len(current_level):
                siblings.append(current_level[idx + 1])
                directions.append("right")
        else:
            siblings.append(current_level[idx - 1])
            directions.append("left")

        idx = idx // 2
        current_level = next_level

    root = current_level[0]
    return {
        "leaf_hash": leaves_hex[leaf_index],
        "leaf_index": leaf_index,
        "siblings": siblings,
        "directions": directions,
        "merkle_root": root,
    }


def verify_merkle_proof(
    leaf_hash: str,
    siblings: List[str],
    directions: List[str],
    expected_root: str,
) -> bool:
    """Verify a Merkle inclusion proof. Constant-time root comparison."""
    current = leaf_hash
    for sibling, direction in zip(siblings, directions):
        if direction == "left":
            current = merkle_node_hash(sibling, current)
        else:
            current = merkle_node_hash(current, sibling)

    return hmac.compare_digest(
        current.encode("utf-8"),
        expected_root.encode("utf-8"),
    )
