# AGA Python SDK - Bundle Verification
# Patent: USPTO App. No. 19/433,835
# Copyright (c) 2026 Attested Intelligence Holdings LLC
# SPDX-License-Identifier: Apache-2.0

"""5-step evidence bundle verification."""

import hmac
from typing import Optional

from ..crypto.canonicalize import canonicalize, canonicalize_bytes
from ..crypto.sha256 import sha256_hex, hex_to_bytes
from ..crypto.ed25519 import verify as ed25519_verify
from .merkle import merkle_node_hash


SUPPORTED_ALGORITHMS = ["Ed25519-SHA256-JCS"]


def _constant_time_equal(a: str, b: str) -> bool:
    if len(a) != len(b):
        return False
    return hmac.compare_digest(a.encode("utf-8"), b.encode("utf-8"))


def verify_bundle(bundle: dict) -> dict:
    """
    Verify an evidence bundle per directive Section 14.
    Five verification steps, all must pass for overall validity.

    Returns a VerificationResult dict.
    """
    result = {
        "algorithm_valid": False,
        "receipt_signatures_valid": False,
        "chain_integrity_valid": False,
        "merkle_proofs_valid": False,
        "bundle_consistent": False,
        "overall_valid": False,
        "receipts_checked": len(bundle.get("receipts", [])),
        "algorithm": bundle.get("algorithm", ""),
        "error": None,
    }

    # Step 1: Algorithm check (fail closed on unknown)
    if not _check_algorithm(bundle):
        result["error"] = f"unsupported algorithm: {bundle.get('algorithm', '')}"
        return result
    result["algorithm_valid"] = True

    # Step 2: Receipt signatures
    try:
        result["receipt_signatures_valid"] = _check_receipt_signatures(bundle)
    except Exception as e:
        result["error"] = f"signature verification error: {e}"
        return result

    # Step 3: Chain integrity
    try:
        result["chain_integrity_valid"] = _check_chain_integrity(bundle)
    except Exception as e:
        result["error"] = f"chain integrity error: {e}"
        return result

    # Step 4: Merkle proofs
    try:
        result["merkle_proofs_valid"] = _check_merkle_proofs(bundle)
    except Exception as e:
        result["error"] = f"merkle proof error: {e}"
        return result

    # Step 5: Bundle consistency
    try:
        result["bundle_consistent"] = _check_bundle_consistency(bundle)
    except Exception as e:
        result["error"] = f"consistency check error: {e}"
        return result

    result["overall_valid"] = (
        result["algorithm_valid"]
        and result["receipt_signatures_valid"]
        and result["chain_integrity_valid"]
        and result["merkle_proofs_valid"]
        and result["bundle_consistent"]
    )
    return result


def verify_bundle_file(path: str) -> dict:
    """Verify an evidence bundle from a JSON file."""
    import json
    with open(path) as f:
        bundle = json.load(f)
    return verify_bundle(bundle)


def _check_algorithm(bundle: dict) -> bool:
    if bundle.get("algorithm") not in SUPPORTED_ALGORITHMS:
        return False
    for receipt in bundle.get("receipts", []):
        if receipt.get("algorithm") != "Ed25519-SHA256-JCS":
            return False
    return True


def _check_receipt_signatures(bundle: dict) -> bool:
    for receipt in bundle.get("receipts", []):
        receipt_without_sig = {k: v for k, v in receipt.items() if k != "signature"}
        canonical = canonicalize_bytes(receipt_without_sig)
        sig_bytes = hex_to_bytes(receipt["signature"])
        pub_bytes = hex_to_bytes(receipt["public_key"])
        if not ed25519_verify(pub_bytes, canonical, sig_bytes):
            return False
    return True


def _check_chain_integrity(bundle: dict) -> bool:
    receipts = bundle.get("receipts", [])
    if not receipts:
        return True
    if receipts[0].get("previous_receipt_hash", "") != "":
        return False
    for i in range(1, len(receipts)):
        prev_canonical = canonicalize_bytes(receipts[i - 1])
        expected_hash = sha256_hex(prev_canonical)
        if not _constant_time_equal(
            receipts[i].get("previous_receipt_hash", ""), expected_hash
        ):
            return False
    return True


def _check_merkle_proofs(bundle: dict) -> bool:
    for proof in bundle.get("merkle_proofs", []):
        current_hash = proof["leaf_hash"]
        for sibling, direction in zip(proof["siblings"], proof["directions"]):
            if direction == "left":
                current_hash = merkle_node_hash(sibling, current_hash)
            else:
                current_hash = merkle_node_hash(current_hash, sibling)
        if not _constant_time_equal(current_hash, bundle["merkle_root"]):
            return False
        if not _constant_time_equal(proof["merkle_root"], bundle["merkle_root"]):
            return False
    return True


def _check_bundle_consistency(bundle: dict) -> bool:
    receipts = bundle.get("receipts", [])
    proofs = bundle.get("merkle_proofs", [])
    if len(proofs) != len(receipts):
        return False
    for i, receipt in enumerate(receipts):
        leaf_hash = sha256_hex(canonicalize_bytes(receipt))
        if not _constant_time_equal(proofs[i]["leaf_hash"], leaf_hash):
            return False
        if proofs[i]["leaf_index"] != i:
            return False
    return True
