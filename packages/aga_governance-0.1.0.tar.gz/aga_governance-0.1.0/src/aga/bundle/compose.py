# AGA Python SDK - Bundle Composition
# Patent: USPTO App. No. 19/433,835
# Copyright (c) 2026 Attested Intelligence Holdings LLC
# SPDX-License-Identifier: Apache-2.0

"""Bundle composition matching TS gateway format exactly."""

import uuid
from datetime import datetime, timezone
from typing import List

from ..crypto.canonicalize import canonicalize_bytes
from ..crypto.sha256 import sha256_hex
from ..receipt.model import GovernanceReceipt, ALGORITHM
from .merkle import merkle_root, generate_merkle_proof


def receipt_leaf_hash(receipt: GovernanceReceipt) -> str:
    """SHA-256(canonicalize(receipt)) where receipt includes the signature field."""
    return sha256_hex(canonicalize_bytes(receipt.to_dict()))


def compose_bundle(
    receipts: List[GovernanceReceipt],
    gateway_id: str,
    public_key_hex: str,
    policy_reference: str,
) -> dict:
    """
    Compose an evidence bundle from a list of governance receipts.
    Computes the Merkle root and generates inclusion proofs for each receipt.
    Output format matches TS gateway exactly.
    """
    if not receipts:
        raise ValueError("cannot compose bundle with zero receipts")

    # Compute leaf hashes
    leaf_hashes = [receipt_leaf_hash(r) for r in receipts]

    # Compute Merkle root
    root = merkle_root(leaf_hashes)

    # Generate inclusion proofs for each receipt
    proofs = [generate_merkle_proof(leaf_hashes, i) for i in range(len(leaf_hashes))]

    return {
        "schema_version": "1.0",
        "bundle_id": str(uuid.uuid4()),
        "algorithm": ALGORITHM,
        "generated_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "gateway_id": gateway_id,
        "public_key": public_key_hex,
        "policy_reference": policy_reference,
        "receipts": [r.to_dict() for r in receipts],
        "merkle_root": root,
        "merkle_proofs": proofs,
        "offline_capable": True,
    }
