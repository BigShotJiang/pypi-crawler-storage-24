"""
axel/cli.py — Command-line interface for the AXEL network.

Entry point: ``axel``

Sub-commands
------------
  axel setup                        Interactive API key setup wizard
  axel status                       Show server status & agent count
  axel agents                       List all registered agents
  axel send <to> <action> [opts]    Send a TASK message
  axel memory search <query>        Search shared memory
  axel memory list                  List all lessons
  axel discover <capability>        Find the best agent for a capability
  axel monitor                      Open the dashboard in a browser
  axel models [--free]              List available OpenRouter models

Global flags
------------
  --server URL    Server base URL (default: http://localhost:7331 or
                  $AXEL_SERVER env var)
  --key KEY       API key (default: $AXEL_KEY env var)
  --json          Output raw JSON (machine-readable)

Examples
--------
  axel setup
  axel status
  axel agents
  axel send writer draft_content --args '{"topic": "AI safety"}'
  axel memory search "multi-hop queries"
  axel discover code_review
  axel monitor
  axel models --free
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.request as _ur
import urllib.error
from pathlib import Path
from typing import Any, Optional


# ──────────────────────────────────────────────────────────────────────────────
# HTTP helper
# ──────────────────────────────────────────────────────────────────────────────

def _req(
    method: str,
    url: str,
    body: Optional[dict] = None,
    key: Optional[str] = None,
    timeout: int = 10,
) -> Any:
    data = json.dumps(body).encode() if body is not None else None
    headers = {"Content-Type": "application/json", "Accept": "application/json"}
    if key:
        headers["X-AXEL-Key"] = key
    req = _ur.Request(url, data=data, headers=headers, method=method)
    try:
        with _ur.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        try:
            detail = json.loads(e.read().decode()).get("detail", str(e))
        except Exception:
            detail = str(e)
        print(f"Error {e.code}: {detail}", file=sys.stderr)
        sys.exit(1)
    except urllib.error.URLError as e:
        print(f"Cannot connect to server: {e.reason}", file=sys.stderr)
        print("Is the AXEL server running? Try: axel-server", file=sys.stderr)
        sys.exit(1)


# ──────────────────────────────────────────────────────────────────────────────
# Formatters
# ──────────────────────────────────────────────────────────────────────────────

def _fmt_json(data: Any) -> str:
    return json.dumps(data, indent=2)


def _status_table(data: dict) -> str:
    lines = [
        f"  AXEL Server  {data.get('version', '?')}",
        f"  Agents      {data['agents']['count']}",
        f"  Uptime      {data.get('uptime_s', 0):.0f}s",
        f"  Memory      {data.get('memory', {}).get('count', 0)} lessons",
        f"  Auth        {'enabled' if data.get('auth') else 'disabled'}",
    ]
    if data.get("db"):
        lines.append(f"  DB          {data['db']}")
    return "\n".join(lines)


def _agents_table(agents: list) -> str:
    if not agents:
        return "  (no agents registered)"
    rows = []
    for a in agents:
        aid   = a.get("agent_id") or a.get("agent") or "?"
        model = a.get("model", "?")[:20]
        score = a.get("score", 0)
        tasks = a.get("tasks_done", 0)
        caps  = ", ".join(a.get("caps") or [])[:40]
        online = "●" if a.get("online", True) else "○"
        rows.append(f"  {online} {aid:<20} {model:<22} score={score:<6.1f} tasks={tasks:<5} [{caps}]")
    return "\n".join(rows)


def _memory_table(lessons: list) -> str:
    if not lessons:
        return "  (no lessons in memory)"
    rows = []
    for l in lessons:
        key   = str(l.get("key", "?"))[:20]
        conf  = l.get("confidence", 0)
        insight = str(l.get("insight", ""))[:60]
        rows.append(f"  [{key:<20}] conf={conf:.2f}  {insight}")
    return "\n".join(rows)


# ──────────────────────────────────────────────────────────────────────────────
# Sub-command implementations
# ──────────────────────────────────────────────────────────────────────────────

def cmd_status(args):
    data = _req("GET", f"{args.server}/status", key=args.key)
    if args.json:
        print(_fmt_json(data))
    else:
        print(_status_table(data))


def cmd_agents(args):
    data = _req("GET", f"{args.server}/agents", key=args.key)
    agents = data.get("agents", [])
    if args.json:
        print(_fmt_json(agents))
    else:
        print(f"Agents ({len(agents)}):")
        print(_agents_table(agents))


def cmd_send(args):
    import uuid as _uuid
    body = {
        "v":   "1",
        "t":   "TK",
        "id":  f"msg_{_uuid.uuid4().hex[:12]}",
        "cid": f"cnv_{_uuid.uuid4().hex[:12]}",
        "fr":  args.from_agent or "axel-cli",
        "to":  args.to,
        "ts":  int(__import__("time").time() * 1000),
        "pri": args.priority,
        "body": {
            "act":  args.action,
            "args": json.loads(args.args) if args.args else {},
        },
    }
    if args.ttl:
        body["ttl"] = args.ttl

    data = _req("POST", f"{args.server}/send", body=body, key=args.key)
    if args.json:
        print(_fmt_json(data))
    else:
        status = "queued" if data.get("ok") else "failed"
        print(f"  Message {body['id']} → {args.to}  [{status}]")
        if data.get("recipients"):
            print(f"  Delivered to: {data['recipients']}")


def cmd_memory_search(args):
    data = _req(
        "GET",
        f"{args.server}/memory/search?q={_ur_quote(args.query)}&n={args.n}",
        key=args.key,
    )
    lessons = data.get("results", [])
    if args.json:
        print(_fmt_json(lessons))
    else:
        print(f"Memory search: '{args.query}'  ({len(lessons)} results)")
        print(_memory_table(lessons))


def cmd_memory_list(args):
    data = _req(
        "GET",
        f"{args.server}/memory?top={args.top}",
        key=args.key,
    )
    lessons = data.get("lessons", data.get("results", []))
    if args.json:
        print(_fmt_json(lessons))
    else:
        print(f"Shared memory ({len(lessons)} lessons):")
        print(_memory_table(lessons))


def cmd_discover(args):
    data = _req(
        "GET",
        f"{args.server}/discover?cap={_ur_quote(args.capability)}",
        key=args.key,
    )
    if args.json:
        print(_fmt_json(data))
    else:
        best = data.get("best")
        if best:
            score   = data.get("score", 0)
            caps    = ", ".join(data.get("caps", []))
            print(f"  Best agent for '{args.capability}': {best}")
            print(f"  Score: {score:.1f}  Capabilities: {caps}")
        else:
            print(f"  No agent found for capability '{args.capability}'")


def cmd_models(args):
    """List models available on OpenRouter (optionally filtered to free tier)."""
    try:
        from axel.universal import OpenRouterAdapter
        key = os.environ.get("OPENROUTER_API_KEY") or _load_config().get("OPENROUTER_API_KEY")
        models = OpenRouterAdapter.list_models(key=key, free_only=getattr(args, "free", False))
    except Exception as exc:
        _die(f"Could not fetch models: {exc}")
        return

    if getattr(args, "json", False):
        print(json.dumps(models, indent=2))
        return

    if not models:
        print("No models found.")
        return

    print(f"\n{'MODEL ID':<52} {'CONTEXT':>8}  PRICING (per 1M tok)")
    print("─" * 80)
    for m in sorted(models, key=lambda x: x["id"]):
        ctx    = f"{m['context_length'] // 1000}k" if m["context_length"] else "?"
        pr_in  = m["pricing"].get("prompt",     "?")
        pr_out = m["pricing"].get("completion", "?")
        try:
            pr_in  = f"${float(pr_in)  * 1_000_000:.2f}" if float(pr_in)  else "free"
            pr_out = f"${float(pr_out) * 1_000_000:.2f}" if float(pr_out) else "free"
        except (TypeError, ValueError):
            pr_in = pr_out = "?"
        print(f"  {m['id']:<50} {ctx:>8}  in:{pr_in}  out:{pr_out}")
    print(f"\n{len(models)} model(s) listed. Sign up free at https://openrouter.ai\n")


# ──────────────────────────────────────────────────────────────────────────────
# Setup wizard
# ──────────────────────────────────────────────────────────────────────────────

_CONFIG_FILE = Path.home() / ".axel" / "config.json"


def _load_config() -> dict:
    if _CONFIG_FILE.exists():
        try:
            return json.loads(_CONFIG_FILE.read_text())
        except Exception:
            pass
    return {}


def _save_config(cfg: dict) -> None:
    _CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    _CONFIG_FILE.write_text(json.dumps(cfg, indent=2))


def _test_openrouter_key(key: str) -> bool:
    """Returns True if the key works (lists at least one model)."""
    try:
        import urllib.request as _req
        req = _req.Request(
            "https://openrouter.ai/api/v1/models",
            headers={"Authorization": f"Bearer {key}"},
        )
        with _req.urlopen(req, timeout=8) as r:
            data = json.loads(r.read())
        return bool(data.get("data"))
    except Exception:
        return False


def _test_provider_key(provider: str, key: str) -> bool:
    """Quick smoke-test for Anthropic / OpenAI keys."""
    try:
        if provider == "anthropic":
            import urllib.request as _req
            req = _req.Request(
                "https://api.anthropic.com/v1/models",
                headers={"x-api-key": key, "anthropic-version": "2023-06-01"},
            )
            with _req.urlopen(req, timeout=8) as r:
                return r.status == 200
        elif provider == "openai":
            import urllib.request as _req
            req = _req.Request(
                "https://api.openai.com/v1/models",
                headers={"Authorization": f"Bearer {key}"},
            )
            with _req.urlopen(req, timeout=8) as r:
                return r.status == 200
    except Exception:
        pass
    return False


def cmd_setup(args):  # noqa: C901
    """Interactive setup wizard — configure API keys and save to ~/.axel/config.json."""
    cfg = _load_config()

    print("\n" + "═" * 60)
    print("  AXEL Setup Wizard")
    print("═" * 60)
    print("\nThis wizard configures your API keys for LLM providers.")
    print("Keys are saved to ~/.axel/config.json\n")

    # ── Option 1: OpenRouter (recommended) ───────────────────────
    print("┌─ OpenRouter (RECOMMENDED) ─────────────────────────────────")
    print("│  One API key → 100+ models (GPT-4o, Claude, Gemini, Llama,")
    print("│  Mistral, and more). Free tier available — no credit card.")
    print("│  Sign up at: https://openrouter.ai")
    print("└────────────────────────────────────────────────────────────")
    existing_or = cfg.get("OPENROUTER_API_KEY", os.environ.get("OPENROUTER_API_KEY", ""))
    if existing_or:
        hint = existing_or[:8] + "…" + existing_or[-4:]
        print(f"\n  Current key: {hint}")
        inp = input("  New key (press Enter to keep current): ").strip()
        or_key = inp or existing_or
    else:
        or_key = input("\n  Paste your OpenRouter key (or Enter to skip): ").strip()

    if or_key:
        print("  Testing key…", end=" ", flush=True)
        if _test_openrouter_key(or_key):
            print("✓ Valid!")
            cfg["OPENROUTER_API_KEY"] = or_key
        else:
            print("✗ Could not verify — saved anyway (check your key).")
            cfg["OPENROUTER_API_KEY"] = or_key

    # ── Option 2: Direct provider keys ───────────────────────────
    print("\n┌─ Direct Provider Keys (optional) ──────────────────────────")
    print("│  Skip these if you're using OpenRouter above.")
    print("└────────────────────────────────────────────────────────────")

    providers = [
        ("Anthropic (Claude)",  "ANTHROPIC_API_KEY",  "https://console.anthropic.com",  "anthropic"),
        ("OpenAI (GPT)",        "OPENAI_API_KEY",      "https://platform.openai.com",    "openai"),
        ("Google (Gemini)",     "GOOGLE_API_KEY",      "https://aistudio.google.com",    None),
    ]

    for label, env_var, url, test_provider in providers:
        existing = cfg.get(env_var, os.environ.get(env_var, ""))
        hint     = (existing[:8] + "…" + existing[-4:]) if existing else "not set"
        print(f"\n  {label} — {url}")
        print(f"  Current: {hint}")
        inp = input(f"  Paste key (Enter to keep): ").strip()
        if inp:
            if test_provider:
                print("  Testing…", end=" ", flush=True)
                ok = _test_provider_key(test_provider, inp)
                print("✓ Valid!" if ok else "✗ Could not verify — saved anyway.")
            cfg[env_var] = inp
        elif existing:
            cfg[env_var] = existing  # keep existing

    # ── AXEL server key ───────────────────────────────────────────
    print("\n┌─ AXEL Server Auth Key (optional) ──────────────────────────")
    print("│  Protects your local AXEL server with an API key.")
    print("│  Leave blank if running locally without auth.")
    print("└────────────────────────────────────────────────────────────")
    existing_axel = cfg.get("AXEL_KEY", os.environ.get("AXEL_KEY", ""))
    if existing_axel:
        print(f"  Current: {existing_axel[:8]}…{existing_axel[-4:]}")
    inp = input("  AXEL server key (Enter to skip): ").strip()
    if inp:
        cfg["AXEL_KEY"] = inp

    # ── Save ──────────────────────────────────────────────────────
    _save_config(cfg)
    print(f"\n  ✓ Config saved to {_CONFIG_FILE}")

    # Print export snippet
    print("\n  To export keys in your shell session, run:\n")
    for k, v in cfg.items():
        if k.endswith("_KEY") or k.endswith("_API_KEY"):
            masked = v[:8] + "…" if len(v) > 8 else v
            print(f"    export {k}={masked}")
    print()

    # Suggest next steps
    if cfg.get("OPENROUTER_API_KEY"):
        print("  Next steps:")
        print("    axel-server &          # start the AXEL server")
        print("    axel status            # verify it's running")
        print("    axel models --free     # browse free models")
        print()
    elif not any(cfg.get(k) for k in ["ANTHROPIC_API_KEY", "OPENAI_API_KEY"]):
        print("  ⚠  No API keys configured. Visit https://openrouter.ai for a")
        print("     free key that unlocks all major LLMs at once.\n")


def cmd_demo(args):  # noqa: C901
    """Run a live two-agent demo against a running AXEL server."""
    import webbrowser

    server = getattr(args, "server", "http://localhost:7331")
    key    = os.environ.get("OPENROUTER_API_KEY") or _load_config().get("OPENROUTER_API_KEY")

    if not key:
        print("\n  AXEL Demo needs an OpenRouter key (free at https://openrouter.ai)")
        print("  Run:  axel setup   — to save your key, then try again.\n")
        return

    # Check server is reachable
    try:
        import urllib.request as _ur
        _ur.urlopen(f"{server}/status", timeout=3)
    except Exception:
        print(f"\n  ❌  Cannot reach AXEL server at {server}")
        print("  Start it first:  python3 -m axel.server\n")
        return

    print(f"\n  🚀  AXEL Demo — opening dashboard...")
    webbrowser.open(f"{server}/ui")

    print("  Registering agents: researcher (Llama) + writer (Gemma)…\n")

    try:
        from axel.client import AXELClient
        from axel.universal import OpenRouterAdapter, AXELBridge
        from axel.core import AXELBuilder
        import time

        researcher = AXELClient(server, agent_id="researcher",
                                model="meta-llama/llama-3.1-8b-instruct:free",
                                provider="openrouter", caps=["research", "summarize"])
        writer = AXELClient(server, agent_id="writer",
                            model="google/gemma-2-9b-it:free",
                            provider="openrouter", caps=["write", "draft_content"])
        researcher.announce()
        writer.announce()
        print("  ✓  Both agents registered — check the dashboard!")
        time.sleep(1)

        bridge = AXELBridge()
        bridge.add_openrouter("researcher", ["research", "summarize"],
                              model="llama-free", key=key)
        bridge.add_openrouter("writer", ["write", "draft_content"],
                              model="gemma-free", key=key)

        topic = "Why multi-agent AI beats single models"
        print(f"\n  📋  Task: research + write about '{topic}'\n")

        print("  🔍  Researcher working…")
        r1 = bridge.execute(AXELBuilder("demo").task(
            "researcher", "research",
            {"topic": topic, "format": "3 bullet points"}))

        if r1.t != "OK":
            print(f"  ❌  Research failed: {r1.body}"); return

        findings = r1.body.get("text", str(r1.body))
        print(f"\n{findings}\n")

        researcher.learn("multi-agent-ai",
                         "Multi-agent systems distribute cognitive load across specialised models",
                         confidence=0.9)

        print("  ✍️   Writer working…")
        r2 = bridge.execute(AXELBuilder("demo").task(
            "writer", "draft_content",
            {"research": findings, "format": "2-sentence intro", "tone": "punchy"}))

        if r2.t != "OK":
            print(f"  ❌  Writing failed: {r2.body}"); return

        draft = r2.body.get("text", str(r2.body))
        print(f"\n{draft}\n")

        writer.learn("copywriting", "2-sentence intros work best for punchy AI content",
                     confidence=0.8)

        print("  ✅  Done! Refresh the dashboard to see agents + memory.\n")

    except Exception as exc:
        print(f"  ❌  Demo failed: {exc}\n")


def cmd_monitor(args):
    import webbrowser
    url = f"{args.server}/ui"
    webbrowser.open(url)
    print(f"  Opening dashboard: {url}")


# ──────────────────────────────────────────────────────────────────────────────
# URL quoting (stdlib only)
# ──────────────────────────────────────────────────────────────────────────────

def _ur_quote(s: str) -> str:
    from urllib.parse import quote
    return quote(s, safe="")


# ──────────────────────────────────────────────────────────────────────────────
# Argument parser
# ──────────────────────────────────────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    default_server = os.environ.get("AXEL_SERVER", "http://localhost:7331")
    default_key    = os.environ.get("AXEL_KEY", "")

    p = argparse.ArgumentParser(
        prog="axel",
        description="AXEL network CLI — inspect and interact with a running AXEL server.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p.add_argument("--server", default=default_server,
                   help=f"Server base URL (default: {default_server})")
    p.add_argument("--key",    default=default_key,
                   help="API key (or set AXEL_KEY env var)")
    p.add_argument("--json",   action="store_true",
                   help="Output raw JSON")

    sub = p.add_subparsers(dest="command", metavar="COMMAND")
    sub.required = True

    # status
    sub.add_parser("status", help="Show server status and agent count")

    # agents
    sub.add_parser("agents", help="List all registered agents")

    # send
    ps = sub.add_parser("send", help="Send a TASK message to an agent")
    ps.add_argument("to",     help="Recipient agent ID")
    ps.add_argument("action", help="Action name (body.act)")
    ps.add_argument("--args", default="{}",
                    help='JSON args dict, e.g. \'{"topic": "AI"}\'')
    ps.add_argument("--from", dest="from_agent", default="axel-cli",
                    help="Sender agent ID (default: axel-cli)")
    ps.add_argument("--priority", type=int, default=2,
                    help="Priority 1-5 (default: 2 = NORMAL)")
    ps.add_argument("--ttl",  type=int, default=0,
                    help="Time-to-live in seconds (default: 0 = no expiry)")

    # memory
    pm = sub.add_parser("memory", help="Query shared memory")
    msub = pm.add_subparsers(dest="memory_cmd", metavar="CMD")
    msub.required = True

    pms = msub.add_parser("search", help="Search lessons by keyword")
    pms.add_argument("query", help="Search query")
    pms.add_argument("--n", type=int, default=10, help="Max results (default: 10)")

    pml = msub.add_parser("list", help="List all lessons")
    pml.add_argument("--top", type=int, default=20, help="Max results (default: 20)")

    # discover
    pd = sub.add_parser("discover", help="Find the best agent for a capability")
    pd.add_argument("capability", help="Capability name to search for")

    # monitor
    sub.add_parser("monitor", help="Open the dashboard in a browser")

    # setup
    sub.add_parser("setup", help="Interactive API key setup wizard")

    # models
    pm2 = sub.add_parser("models", help="List available OpenRouter models")
    pm2.add_argument("--free", action="store_true",
                     help="Show only free-tier models")

    # demo
    sub.add_parser("demo", help="Run a live two-agent demo (needs OPENROUTER_API_KEY)")

    return p


# ──────────────────────────────────────────────────────────────────────────────
# Entry point
# ──────────────────────────────────────────────────────────────────────────────

def main():
    parser = build_parser()
    args = parser.parse_args()

    dispatch = {
        "setup":    cmd_setup,
        "demo":     cmd_demo,
        "status":   cmd_status,
        "agents":   cmd_agents,
        "send":     cmd_send,
        "memory":   _memory_dispatch,
        "discover": cmd_discover,
        "monitor":  cmd_monitor,
        "models":   cmd_models,
    }
    dispatch[args.command](args)


def _memory_dispatch(args):
    if args.memory_cmd == "search":
        cmd_memory_search(args)
    elif args.memory_cmd == "list":
        cmd_memory_list(args)


if __name__ == "__main__":
    main()
