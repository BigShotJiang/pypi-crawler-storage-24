"""module for curator blocks."""
