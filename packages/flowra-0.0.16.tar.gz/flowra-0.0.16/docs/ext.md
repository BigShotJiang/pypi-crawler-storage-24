# Package `flowra.ext`

Provider-specific extensions and optional integrations.

- **[Anthropic prompt caching](ext/anthropic.md)** — composable hook bundles
  for `cache_control` placement via `PrepareLLMRequestEvent`
- **[MLflow tracing](ext/mlflow.md)** — span-hook integration for observability
