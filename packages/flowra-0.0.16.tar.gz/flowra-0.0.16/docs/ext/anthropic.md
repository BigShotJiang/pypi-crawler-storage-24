# Anthropic prompt caching (`flowra.ext.anthropic`)

Composable hook bundles that set `cache_control: {"type": "ephemeral"}` on blocks
and tools via the `PrepareLLMRequestEvent` hook. Each bundle handles one caching
slot (system, tools, or messages). The `NonTransient*` bundles respect the
`transient` hint — transient content is not cached. The `*All*` bundles cache
the last block regardless of `transient`.

## Usage

```python
from flowra.agent import HookSubscription
from flowra.ext.anthropic import ANTHROPIC_CACHE_ALL

hooks = HookSubscription()
ANTHROPIC_CACHE_ALL.install(hooks)
# pass hooks to AgentRuntime via services={HookSubscription: hooks, ...}
```

## Available bundles

| Bundle                                     | What it caches                                                                           |
|--------------------------------------------|------------------------------------------------------------------------------------------|
| `AnthropicCacheAllSystemMessages`          | Last block of the last system message                                                    |
| `AnthropicCacheNonTransientSystemMessages` | Last non-transient block of the last non-transient system message                        |
| `AnthropicCacheAllTools`                   | Last tool definition                                                                     |
| `AnthropicCacheAllMessages`                | Last block of the last message                                                           |
| `AnthropicCacheNonTransientMessages`       | Last non-transient block of the last non-transient message                               |
| `AnthropicCacheHistoryMessages`            | Last message that was in history before the current turn (via `SaveHistoryEvent` marker) |

## Presets

- **`ANTHROPIC_CACHE_ALL`** — composite of `AnthropicCacheAllSystemMessages` +
  `AnthropicCacheAllTools` + `AnthropicCacheAllMessages`. Caches all three slots.
- **`ANTHROPIC_CACHE_SESSION`** — composite of `AnthropicCacheAllSystemMessages` +
  `AnthropicCacheAllTools` + `AnthropicCacheHistoryMessages`. Caches system and tools,
  plus the last history message (excludes current turn). Requires `ChatAgent`.

## `transient` hint

Bundles with "NonTransient" in the name skip blocks and messages where
`transient=True`. This is useful when hooks inject temporary context (e.g.
iteration-specific instructions) that changes on every LLM call — caching such
content would cause cache invalidation.

```python
from flowra.llm import TextBlock

# This block will be skipped by NonTransient caching bundles
TextBlock(text="Current time: 12:00", transient=True)
```

## Custom bundles

To implement your own caching logic, subscribe to `PrepareLLMRequestEvent`
and modify `event.data.request`:

```python
from flowra.lib.tool_loop import PrepareLLMRequestEvent

def my_cache_hook(event):
    request = event.data.request
    # modify request.system, request.tools, request.messages
    # set extra={"cache_control": {"type": "ephemeral"}} on target blocks
    event.data.request = modified_request

hooks.on(PrepareLLMRequestEvent, my_cache_hook)
```
