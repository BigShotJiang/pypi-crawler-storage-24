from typing import Any

from flowra.agent import HookSubscription
from flowra.ext.anthropic import (
    ANTHROPIC_CACHE_ALL,
    ANTHROPIC_CACHE_SESSION,
    AnthropicCacheAllMessages,
    AnthropicCacheAllSystemMessages,
    AnthropicCacheAllTools,
    AnthropicCacheHistoryMessages,
    AnthropicCacheNonTransientMessages,
    AnthropicCacheNonTransientSystemMessages,
)
from flowra.lib.chat import SaveHistoryEvent
from flowra.lib.tool_loop import PrepareLLMRequestEvent
from flowra.llm import AssistantMessage, LLMRequest, SystemMessage, TextBlock, Tool, ToolUseBlock, UserMessage

_CC = {"cache_control": {"type": "ephemeral"}}


def _sys(text: str, *, transient: bool = False) -> SystemMessage:
    return SystemMessage(blocks=[TextBlock(text=text, transient=transient)], transient=transient)


def _user(text: str, *, transient: bool = False) -> UserMessage:
    return UserMessage(blocks=[TextBlock(text=text, transient=transient)], transient=transient)


def _assistant(text: str, *, transient: bool = False) -> AssistantMessage:
    return AssistantMessage(blocks=[TextBlock(text=text, transient=transient)], transient=transient)


def _tool(name: str) -> Tool:
    return Tool(name=name, description="", input_schema=None)


def _request(
    system: list[SystemMessage] | None = None,
    messages: list[UserMessage | AssistantMessage] | None = None,
    tools: list[Tool] | None = None,
) -> LLMRequest:
    return LLMRequest(model="test", system=system or [], messages=messages or [], tools=tools)


def _apply(ext: Any, request: LLMRequest) -> LLMRequest:
    """Simulate the hook pipeline."""
    event_data = PrepareLLMRequestEvent(request=request)

    class FakeEvent:
        def __init__(self, data: PrepareLLMRequestEvent) -> None:
            self.data = data

    fake = FakeEvent(event_data)
    ext.on_prepare(fake)
    return fake.data.request


# -- System message caching --


class TestCacheAllSystemMessages:
    def test_caches_last_system_block(self) -> None:
        ext = AnthropicCacheAllSystemMessages()
        req = _request(system=[_sys("a"), _sys("b")])
        result = _apply(ext, req)
        assert "cache_control" not in result.system[0].blocks[0].extra
        assert result.system[1].blocks[0].extra.get("cache_control") == {"type": "ephemeral"}

    def test_empty_system(self) -> None:
        ext = AnthropicCacheAllSystemMessages()
        req = _request(system=[])
        result = _apply(ext, req)
        assert result.system == []

    def test_clears_old_cache(self) -> None:
        ext = AnthropicCacheAllSystemMessages()
        req = _request(
            system=[
                SystemMessage(blocks=[TextBlock(text="a", extra=_CC)]),
                _sys("b"),
            ]
        )
        result = _apply(ext, req)
        assert "cache_control" not in result.system[0].blocks[0].extra
        assert result.system[1].blocks[0].extra.get("cache_control") == {"type": "ephemeral"}


class TestCacheNonTransientSystemMessages:
    def test_caches_last_non_transient(self) -> None:
        ext = AnthropicCacheNonTransientSystemMessages()
        req = _request(system=[_sys("stable"), _sys("dynamic", transient=True)])
        result = _apply(ext, req)
        assert result.system[0].blocks[0].extra.get("cache_control") == {"type": "ephemeral"}
        assert "cache_control" not in result.system[1].blocks[0].extra

    def test_all_non_transient_caches_last(self) -> None:
        ext = AnthropicCacheNonTransientSystemMessages()
        req = _request(system=[_sys("a"), _sys("b")])
        result = _apply(ext, req)
        assert "cache_control" not in result.system[0].blocks[0].extra
        assert result.system[1].blocks[0].extra.get("cache_control") == {"type": "ephemeral"}

    def test_all_transient_no_cache(self) -> None:
        ext = AnthropicCacheNonTransientSystemMessages()
        req = _request(system=[_sys("a", transient=True)])
        result = _apply(ext, req)
        assert "cache_control" not in result.system[0].blocks[0].extra

    def test_multi_block_system_message(self) -> None:
        ext = AnthropicCacheNonTransientSystemMessages()
        req = _request(
            system=[
                SystemMessage(
                    blocks=[
                        TextBlock(text="stable"),
                        TextBlock(text="dynamic", transient=True),
                    ]
                ),
            ]
        )
        result = _apply(ext, req)
        # Last non-transient block is the first one
        assert result.system[0].blocks[0].extra.get("cache_control") == {"type": "ephemeral"}
        assert "cache_control" not in result.system[0].blocks[1].extra


# -- Tool caching --


class TestCacheAllTools:
    def test_caches_last_tool(self) -> None:
        ext = AnthropicCacheAllTools()
        req = _request(tools=[_tool("a"), _tool("b")])
        result = _apply(ext, req)
        assert result.tools is not None
        assert "cache_control" not in result.tools[0].extra
        assert result.tools[1].extra.get("cache_control") == {"type": "ephemeral"}

    def test_empty_tools(self) -> None:
        ext = AnthropicCacheAllTools()
        req = _request(tools=None)
        result = _apply(ext, req)
        assert result.tools is None

    def test_clears_old_cache(self) -> None:
        ext = AnthropicCacheAllTools()
        req = _request(tools=[Tool(name="a", description="", extra=_CC), _tool("b")])
        result = _apply(ext, req)
        assert result.tools is not None
        assert "cache_control" not in result.tools[0].extra
        assert result.tools[1].extra.get("cache_control") == {"type": "ephemeral"}


# -- Message caching --


class TestCacheAllMessages:
    def test_caches_last_message_block(self) -> None:
        ext = AnthropicCacheAllMessages()
        req = _request(messages=[_user("hello"), _assistant("hi")])
        result = _apply(ext, req)
        assert "cache_control" not in result.messages[0].blocks[0].extra
        assert result.messages[1].blocks[0].extra.get("cache_control") == {"type": "ephemeral"}

    def test_empty_messages(self) -> None:
        ext = AnthropicCacheAllMessages()
        req = _request(messages=[])
        result = _apply(ext, req)
        assert result.messages == []

    def test_tool_use_block(self) -> None:
        ext = AnthropicCacheAllMessages()
        req = _request(
            messages=[
                AssistantMessage(blocks=[ToolUseBlock(id="1", name="t", input={})]),
            ]
        )
        result = _apply(ext, req)
        assert result.messages[0].blocks[0].extra.get("cache_control") == {"type": "ephemeral"}


class TestCacheNonTransientMessages:
    def test_caches_last_non_transient(self) -> None:
        ext = AnthropicCacheNonTransientMessages()
        req = _request(messages=[_user("history"), _user("current", transient=True)])
        result = _apply(ext, req)
        assert result.messages[0].blocks[0].extra.get("cache_control") == {"type": "ephemeral"}
        assert "cache_control" not in result.messages[1].blocks[0].extra

    def test_all_non_transient_caches_last(self) -> None:
        ext = AnthropicCacheNonTransientMessages()
        req = _request(messages=[_user("a"), _assistant("b")])
        result = _apply(ext, req)
        assert "cache_control" not in result.messages[0].blocks[0].extra
        assert result.messages[1].blocks[0].extra.get("cache_control") == {"type": "ephemeral"}


# -- History message caching --


def _simulate_save_history(ext: AnthropicCacheHistoryMessages, messages: list[Any]) -> list[Any]:
    """Simulate SaveHistoryEvent."""
    event_data = SaveHistoryEvent(messages=list(messages))

    class FakeEvent:
        def __init__(self, data: SaveHistoryEvent) -> None:
            self.data = data

    fake = FakeEvent(event_data)
    ext.on_save_history(fake)
    return fake.data.messages


class TestCacheHistoryMessages:
    def test_caches_history_breakpoint(self) -> None:
        ext = AnthropicCacheHistoryMessages()
        # Simulate: turn 1 messages saved with breakpoint marker
        turn1: list[UserMessage | AssistantMessage] = [_user("q1"), _assistant("a1")]
        marked = _simulate_save_history(ext, turn1)

        # Turn 2: history (marked) + new turn
        req = _request(messages=[marked[0], marked[1], _user("q2")])
        result = _apply(ext, req)

        # Breakpoint message (a1) cached
        assert result.messages[1].blocks[0].extra.get("cache_control") == {"type": "ephemeral"}
        # New turn message NOT cached
        assert "cache_control" not in result.messages[2].blocks[0].extra

    def test_no_breakpoint_no_cache(self) -> None:
        ext = AnthropicCacheHistoryMessages()
        req = _request(messages=[_user("hello"), _assistant("hi")])
        result = _apply(ext, req)
        assert "cache_control" not in result.messages[0].blocks[0].extra
        assert "cache_control" not in result.messages[1].blocks[0].extra

    def test_breakpoint_moves_with_each_turn(self) -> None:
        ext = AnthropicCacheHistoryMessages()
        # Turn 1
        marked1 = _simulate_save_history(ext, [_user("q1"), _assistant("a1")])
        # Turn 2
        marked2 = _simulate_save_history(ext, [_user("q2"), _assistant("a2")])

        # Turn 3: history = marked1 + marked2, new turn = user
        req = _request(messages=[marked1[0], marked1[1], marked2[0], marked2[1], _user("q3")])
        result = _apply(ext, req)

        # Last breakpoint is on marked2's last message (a2)
        assert result.messages[3].blocks[0].extra.get("cache_control") == {"type": "ephemeral"}
        # marked1's last message NOT cached
        assert "cache_control" not in result.messages[1].blocks[0].extra
        # New turn NOT cached
        assert "cache_control" not in result.messages[4].blocks[0].extra


# -- Composite --


class TestAnthropicCacheSession:
    def test_caches_system_tools_and_history(self) -> None:
        ext = AnthropicCacheHistoryMessages()
        marked = _simulate_save_history(ext, [_user("q1"), _assistant("a1")])

        req = _request(
            system=[_sys("system")],
            messages=[marked[0], marked[1], _user("q2")],
            tools=[_tool("a")],
        )
        result = _apply_composite(ANTHROPIC_CACHE_SESSION, req)

        # System cached
        assert result.system[0].blocks[0].extra.get("cache_control") == {"type": "ephemeral"}
        # Tools cached
        assert result.tools is not None
        assert result.tools[0].extra.get("cache_control") == {"type": "ephemeral"}
        # History breakpoint cached
        assert result.messages[1].blocks[0].extra.get("cache_control") == {"type": "ephemeral"}
        # New turn NOT cached
        assert "cache_control" not in result.messages[2].blocks[0].extra


class TestAnthropicCacheAll:
    def test_caches_system_tools_and_messages(self) -> None:
        req = _request(
            system=[_sys("system")],
            messages=[_user("hello"), _assistant("hi")],
            tools=[_tool("a"), _tool("b")],
        )
        result = _apply_composite(ANTHROPIC_CACHE_ALL, req)

        # System cached
        assert result.system[0].blocks[0].extra.get("cache_control") == {"type": "ephemeral"}
        # Last tool cached
        assert result.tools is not None
        assert "cache_control" not in result.tools[0].extra
        assert result.tools[1].extra.get("cache_control") == {"type": "ephemeral"}
        # Last message cached
        assert "cache_control" not in result.messages[0].blocks[0].extra
        assert result.messages[1].blocks[0].extra.get("cache_control") == {"type": "ephemeral"}

    def test_does_not_mutate_original(self) -> None:
        system = [_sys("system")]
        messages: list[UserMessage | AssistantMessage] = [_user("hello")]
        tools = [_tool("a")]
        req = _request(system=system, messages=messages, tools=tools)
        _apply_composite(ANTHROPIC_CACHE_ALL, req)
        assert "cache_control" not in system[0].blocks[0].extra
        assert "cache_control" not in tools[0].extra


class TestInstall:
    def test_install_registers_hooks(self) -> None:
        hooks = HookSubscription()
        ANTHROPIC_CACHE_ALL.install(hooks)
        assert hooks.has_handlers(PrepareLLMRequestEvent)


def _apply_composite(composite: Any, request: LLMRequest) -> LLMRequest:
    """Apply all extensions in a composite by simulating install + dispatch."""
    hooks = HookSubscription()
    composite.install(hooks)
    event_data = PrepareLLMRequestEvent(request=request)

    class FakeEvent:
        def __init__(self, data: PrepareLLMRequestEvent) -> None:
            self.data = data
            self.context = None

    fake = FakeEvent(event_data)
    handlers = hooks.get_handlers()
    for handler in handlers.get(PrepareLLMRequestEvent, []):
        handler(fake)
    return fake.data.request
