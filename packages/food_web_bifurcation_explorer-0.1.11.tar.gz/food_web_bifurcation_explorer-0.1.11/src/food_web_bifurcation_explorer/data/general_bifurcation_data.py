from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor, as_completed
from plotly.subplots import make_subplots
import numpy as np
import os
import pandas as pd
import plotly.graph_objects as go
import shutil
import zipfile
import math

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.types.bifurcation_types import BifurcationTypes
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes
from food_web_bifurcation_explorer.enums.types.parameter_types import ParameterTypes
from food_web_bifurcation_explorer.enums.numbers.float_numbers import FloatNumbers
from food_web_bifurcation_explorer.enums.numbers.integer_numbers import IntegerNumbers    

class GeneralBifurcationData:

    def __init__(self):
        # declare a set of pandas divided by branch types and bifurcation types
        self.data: dict[BranchTypes, dict[BifurcationTypes, pd.DataFrame]] = {}
        for branch_type in BranchTypes:
            self.data[branch_type] = {}
            for bifurcation_type in BifurcationTypes:
                self.data[branch_type][bifurcation_type] = pd.DataFrame()
        # declare a dataframe for ternary grid counts
        columns_grid_counts = ['sd', 'sr', 'sl'] + [bifurcation_type.value for bifurcation_type in BifurcationTypes]
        self.data_ternary_grid_counts: dict[BranchTypes, pd.DataFrame] = {}
        for branch_type in BranchTypes:
            self.data_ternary_grid_counts[branch_type] = pd.DataFrame(columns=columns_grid_counts)

    def generate(self):
        # show info
        print("generating bifurcation data")
        # get all networks
        networks = glob.files.get_continuation_subfolders()
        # declare a temporal dictionary to save readed bifurcation types, this will be used to concat and save in parquet files 
        temp_data = {
            branch_type: {bifurcation_type: [] for bifurcation_type in BifurcationTypes}
            for branch_type in BranchTypes
        }
        # run in pararell the reading of the continuation zip files and the extraction of the bifurcation types
        with ProcessPoolExecutor() as executor:
            # run the process for each network and fixed parameter value
            futures = {
                executor.submit(self._process_network_param, network, fixed_parameter_value): (network, fixed_parameter_value)
                for network in networks
                for fixed_parameter_value in glob.plot_data.fixed_parameter_values
            }
            # iterate over the results and save them in the temporal data
            for future in as_completed(futures):
                result_data = future.result()
                for branch_type in BranchTypes:
                    for bifurcation_type in BifurcationTypes:
                        if result_data[branch_type][bifurcation_type]:
                            temp_data[branch_type][bifurcation_type].extend(result_data[branch_type][bifurcation_type])
        # create directory
        os.makedirs(glob.files.get_data_folder(), exist_ok=True)
        temporal_dir = os.path.join(glob.files.get_data_folder(), "temp_parquet_general_bifurcation_data")
        os.makedirs(temporal_dir, exist_ok=True)
        # function to concat and save in parquet files, this will be used to run in pararell the concat and save of the parquet files
        def _concat_and_save(branch_type, bifurcation_type):
            dfs = temp_data[branch_type][bifurcation_type]
            if dfs:
                # avoid copy when concatenating to save memory
                df = pd.concat(dfs, ignore_index=True, copy=False)
            else:
                df = pd.DataFrame(columns=['sd', 'sr', 'sl'])
            # get parquet file
            parquet_file = glob.files.get_general_bifurcation_data_parquet_file(branch_type, bifurcation_type)
            temp_path = os.path.join(temporal_dir, parquet_file)
            # use snappy compression for parquet (more fast)
            df.to_parquet(temp_path, compression='snappy')
            # set data
            self.data[branch_type][bifurcation_type] = df
            # return temporal path and parquet file name to write in zip
            return temp_path, parquet_file
        # paralelice concatenate and save
        temporal_files = []
        with ThreadPoolExecutor() as executor:
            futures = {
                executor.submit(_concat_and_save, bt, bift): (bt, bift)
                for bt in BranchTypes
                for bift in BifurcationTypes
            }
            for future in as_completed(futures):
                temporal_files.append(future.result())
        # generate grid counts
        self.generate_grid_counts()
        # save it in parquet format
        for branch_type in BranchTypes:
            # define filename
            temp_path = os.path.join(temporal_dir, glob.files.get_ternary_grid_counts_file(branch_type))
            # save in temporal folder
            self.data_ternary_grid_counts[branch_type].to_parquet(temp_path, compression='snappy')
            # add to zip file path
            temporal_files.append((temp_path, glob.files.get_ternary_grid_counts_file(branch_type)))
        # write zip
        with zipfile.ZipFile(
            glob.files.get_general_bifurcation_data_zip_file(), "w", compression=zipfile.ZIP_DEFLATED) as data_zip_file:
            for temporal_path, archive_name in temporal_files:
                data_zip_file.write(temporal_path, archive_name)
        # remove temporal dir
        shutil.rmtree(temporal_dir)

    def generate_grid_counts(self):
        # show info
        print("generating grid counts")
        # get bifurcation columns
        bifurcation_columns = [b.value for b in BifurcationTypes]
        # snap to grid with precision 3
        def _snap_to_grid(series: pd.Series) -> pd.Series:
            return ((series / FloatNumbers.FIXED_PARAMETER_STEP).round() * FloatNumbers.FIXED_PARAMETER_STEP).round(3)
        # Iterate over every branch type
        for branch_type in BranchTypes:
            list_of_counts = []
            # iterate over bifurcation types
            for bifurcation_type in BifurcationTypes:
                # get dataframe associated with bifurcation type
                df = self.data[branch_type][bifurcation_type]
                # check that isn't empty
                if df is None or df.empty:
                    continue
                # create temporal dataframe
                temp_df = pd.DataFrame({
                    'sd': _snap_to_grid(df['sd']),
                    'sr': _snap_to_grid(df['sr']),
                    'sl': _snap_to_grid(df['sl'])
                })
                # group by bifurcation type
                counts = temp_df.groupby(['sd', 'sr', 'sl']).size().reset_index(name=bifurcation_type.value)
                list_of_counts.append(counts)
            
            # if we don't have counts, create empty dataframe
            if not list_of_counts:
                empty_cols = ['sd', 'sr', 'sl'] + bifurcation_columns
                self.data_ternary_grid_counts[branch_type] = pd.DataFrame(columns=empty_cols)
            else:
                # merge all dataframes
                from functools import reduce
                merged_df = reduce(
                    lambda left, right: pd.merge(left, right, on=['sd', 'sr', 'sl'], how='outer'), 
                    list_of_counts
                )
                # fill with none values all empty columns
                for col in bifurcation_columns:
                    if col not in merged_df.columns:
                        merged_df[col] = 0
                merged_df[bifurcation_columns] = merged_df[bifurcation_columns].fillna(0).astype(int)
                # save dataframe
                self.data_ternary_grid_counts[branch_type] = merged_df

    def load(self):
        # simply open the general bifurcation data zip and load every parquet file
        with zipfile.ZipFile(glob.files.get_general_bifurcation_data_zip_file(), "r", compression=zipfile.ZIP_DEFLATED) as data_zip_file:
            # load data parquets
            for branch_type in BranchTypes:
                for bifurcation_type in BifurcationTypes:
                    with data_zip_file.open(glob.files.get_general_bifurcation_data_parquet_file(branch_type, bifurcation_type)) as f:
                        self.data[branch_type][bifurcation_type] = pd.read_parquet(f)
            # aso load grid count parquets
            for branch_type in BranchTypes:
                with data_zip_file.open(glob.files.get_ternary_grid_counts_file(branch_type)) as f:
                    self.data[branch_type][bifurcation_type] = pd.read_parquet(f)
        # plot files
        self.plot_data(ParameterTypes.DONOR, ParameterTypes.RECIPIENT)
        self.plot_data(ParameterTypes.RECIPIENT, ParameterTypes.LOTKAVOLTERRA)
        self.plot_data(ParameterTypes.LOTKAVOLTERRA, ParameterTypes.DONOR)
        self.plot_grid_counts_ternary_heatmap()

    # function to process each network and fixed parameter value
    @staticmethod
    def _process_network_param(network, fixed_parameter_value):
        # declare two temporal dictionary to save readed bifurcation types
        local_temp_data = {
            branch_type: {bifurcation_type: [] for bifurcation_type in BifurcationTypes}
            for branch_type in BranchTypes
        }
        # get continuation zip file correspond to this fixed parameter
        continuation_zip_file_path = os.path.join(glob.files.get_continuation_folder(), network, fixed_parameter_value + ".zip")
        # ignore errors
        try:
            # open continuation zip file
            with zipfile.ZipFile(continuation_zip_file_path, "r") as continuation_zip_file:
                # iterate over both branches
                for branch_type in BranchTypes:
                    # open continuation file
                    with continuation_zip_file.open(f"bifurcations_{branch_type.value}_{ParameterTypes.LOTKAVOLTERRA.value}_{fixed_parameter_value}.csv") as file:
                        # read CSV
                        bifurcations_dataframe = pd.read_csv(file)
                        # iterate over bifurcation types
                        for bifurcation_type in BifurcationTypes:
                            # extract bifurcation type
                            bifurcations_dataframe_filtered = bifurcations_dataframe[bifurcations_dataframe['type'] == bifurcation_type.value]
                            # filter by sd, sr and sl
                            bifurcations_dataframe_filtered = bifurcations_dataframe_filtered[['sd', 'sr', 'sl']]
                            # save it in temporal data
                            local_temp_data[branch_type][bifurcation_type].append(bifurcations_dataframe_filtered)
        except Exception:
            pass
        return local_temp_data

    def load_grid_counts(self):
        """Carga los DataFrames de grid counts desde el ZIP existente."""
        zip_path = glob.files.get_general_bifurcation_data_zip_file()
        names = ['grid_sd_sr', 'grid_sr_sl', 'grid_sl_sd', 'grid_sd_sr_sl']

        self.grid_counts = {}
        with zipfile.ZipFile(zip_path, "r") as data_zip_file:
            for name in names:
                parquet_name = f"{name}.parquet"
                with data_zip_file.open(parquet_name) as f:
                    self.grid_counts[name] = pd.read_parquet(f)



    def plot_data(self, paramA: ParameterTypes, paramB: ParameterTypes):
        """
        Genera y abre en el navegador diagramas de densidad (KDE 2D) 
        para cada tipo de bifurcación y rama.
        """
        branch_types = list(BranchTypes)
        bifurcation_types = list(BifurcationTypes)

        # Verificar si hay algún dato real
        has_data = any(
            not self.data[bt][bift].empty
            for bt in branch_types
            for bift in bifurcation_types
        )

        if not has_data:
            print("No hay datos suficientes para generar los diagramas de densidad.")
            return

        fig = make_subplots(
            rows=len(branch_types),
            cols=len(bifurcation_types),
            subplot_titles=[
                f"{bt.name} - {bift.name}"
                for bt in branch_types
                for bift in bifurcation_types
            ],
            vertical_spacing=0.1,
            horizontal_spacing=0.05
        )

        for i, bt in enumerate(branch_types, 1):
            for j, bift in enumerate(bifurcation_types, 1):
                df = self.data[bt][bift]

                if not df.empty:
                    # Usar go.Histogram2dContour en lugar de px.density_contour
                    # para compatibilidad directa con make_subplots
                    trace = go.Histogram2dContour(
                        x=df[paramA.value],
                        y=df[paramB.value],
                        colorscale="Blues",
                        contours_coloring="heatmap",  # antes "contours_filling", incorrecto
                        showscale=False,
                        ncontours=20,
                    )
                    fig.add_trace(trace, row=i, col=j)

        fig.update_layout(
            title_text=f"Bifurcation density ({paramA.value} vs {paramB.value})",
            height=500 * len(branch_types),
            width=500 * len(bifurcation_types),
            showlegend=False,
            template="plotly_white"
        )
        axis_ticks = [round(i * 0.1, 1) for i in range(11)]

        fig.update_xaxes(title_text=paramA.value, tickvals=axis_ticks, range=[0, 1])
        fig.update_yaxes(title_text=paramB.value, tickvals=axis_ticks, range=[0, 1])

        fig.update_xaxes(title_text=paramA.value)
        fig.update_yaxes(title_text=paramB.value)

        fig.show()


    def plot_grid_counts_ternary_heatmap(self):
        if self.grid_sd_sr_sl.empty:
            print("No hay datos de grid counts ternarios para mostrar.")
            return

        def _ternary_to_cartesian(a: np.ndarray, b: np.ndarray, c: np.ndarray):
            total = a + b + c
            x = 0.5 * (2 * b + c) / total
            y = (np.sqrt(3) / 2) * c / total
            return x, y

        def _build_heatmap_grid(resolution: int):
            step = 1.0 / resolution
            points_a, points_b, points_c = [], [], []
            for i in range(resolution + 1):
                for j in range(resolution + 1 - i):
                    k = resolution - i - j
                    if k < 0:
                        continue
                    points_a.append(i * step)
                    points_b.append(j * step)
                    points_c.append(k * step)
            return np.array(points_a), np.array(points_b), np.array(points_c)

        HEATMAP_RESOLUTION = 101
        N_GROUPS = 10

        grid_a, grid_b, grid_c = _build_heatmap_grid(HEATMAP_RESOLUTION)
        cart_x, cart_y = _ternary_to_cartesian(grid_a, grid_b, grid_c)

        group_colors = [
            f'hsl(0, 100%, {int(100 - 50 * i / (N_GROUPS - 1))}%)'
            for i in range(N_GROUPS)
        ]

        for bifurcation_type in BifurcationTypes:

            df_filtered = self.grid_sd_sr_sl[self.grid_sd_sr_sl[bifurcation_type.value] > 0].copy()

            cell_counts = np.zeros(len(grid_a))

            if not df_filtered.empty:
                sds    = df_filtered[ParameterTypes.DONOR.value].values.astype(float)
                srs    = df_filtered[ParameterTypes.RECIPIENT.value].values.astype(float)
                sls    = df_filtered[ParameterTypes.LOTKAVOLTERRA.value].values.astype(float)
                counts = df_filtered[bifurcation_type.value].values.astype(float)

                for sd, sr, sl, count in zip(sds, srs, sls, counts):
                    distances = (grid_a - sd) ** 2 + (grid_b - sr) ** 2 + (grid_c - sl) ** 2
                    nearest = np.argmin(distances)
                    cell_counts[nearest] += count

            local_max = cell_counts.max()

            # assign each cell to one of N_GROUPS bins: 0 = empty, 1..N_GROUPS = data bins
            # bins are evenly spaced between 1 and local_max
            bin_edges = np.linspace(0, local_max, N_GROUPS + 1)

            # group_idx: 0 for empty cells, 1..N_GROUPS for populated cells
            group_idx = np.digitize(cell_counts, bin_edges, right=True)
            group_idx = np.clip(group_idx, 0, N_GROUPS)

            fig = go.Figure()

            # triangle frame
            fig.add_trace(go.Scatter(
                x=[0.0, 1.0, 0.5, 0.0],
                y=[0.0, 0.0, np.sqrt(3) / 2, 0.0],
                mode='lines',
                line=dict(color='black', width=2),
                showlegend=False,
                hoverinfo='skip',
            ))

            # one trace per group (skip group 0 = empty cells)
            for g in range(1, N_GROUPS + 1):
                mask = group_idx == g
                if not mask.any():
                    continue

                low  = bin_edges[g - 1]
                high = bin_edges[g]
                label = f'{int(low)}–{int(high)}'

                fig.add_trace(go.Scatter(
                    x=cart_x[mask].tolist(),
                    y=cart_y[mask].tolist(),
                    mode='markers',
                    name=label,
                    marker=dict(
                        size=8,
                        color=group_colors[g - 1],
                        symbol='circle',
                        opacity=0.9,
                        line=dict(width=0),
                    ),
                    hovertemplate=(
                        f"<b>{bifurcation_type.name}</b> [{label}]<br>"
                        f"{ParameterTypes.DONOR.value}: %{{customdata[0]:.3f}}<br>"
                        f"{ParameterTypes.RECIPIENT.value}: %{{customdata[1]:.3f}}<br>"
                        f"{ParameterTypes.LOTKAVOLTERRA.value}: %{{customdata[2]:.3f}}<br>"
                        f"count: %{{customdata[3]:.0f}}<extra></extra>"
                    ),
                    customdata=np.stack([
                        grid_a[mask],
                        grid_b[mask],
                        grid_c[mask],
                        cell_counts[mask],
                    ], axis=1).tolist(),
                ))

            # vertex labels
            fig.add_trace(go.Scatter(
                x=[0.5,   -0.05,  1.05],
                y=[np.sqrt(3) / 2 + 0.05, -0.05, -0.05],
                mode='text',
                text=[
                    ParameterTypes.LOTKAVOLTERRA.value,
                    ParameterTypes.DONOR.value,
                    ParameterTypes.RECIPIENT.value,
                ],
                textfont=dict(size=14, color='black'),
                showlegend=False,
                hoverinfo='skip',
            ))

            fig.update_layout(
                title_text=f"Ternary Heatmap — {bifurcation_type.name}",
                height=1200,
                width=1200,
                template="plotly_white",
                xaxis=dict(visible=False, range=[-0.1, 1.1]),
                yaxis=dict(visible=False, scaleanchor='x', range=[-0.1, 1.0]),
                legend=dict(
                    title="count range",
                    itemsizing='constant',
                ),
            )

            fig.show()