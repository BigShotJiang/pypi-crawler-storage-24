import zipfile
from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes
from food_web_bifurcation_explorer.enums.types.parameter_types import ParameterTypes
from food_web_bifurcation_explorer.common.exceptions import ParameterTypeError


class EnvelopeData:

    def __init__(self):
        """Initialize an EnvelopeData instance with empty data structures."""
        # used as ID
        self.fixed_parameter_type: ParameterTypes = None
        self.fixed_parameter_value: str = None
        # data
        self.n: int = 0
        self.x_values: list[float] = []
        self.envelope_top: list[float] = []
        self.envelope_bot: list[float] = []
        self.limit_cycle: bool = False
        self.time_serie: list[float] = []
        self.biomass_serie: list[list[float]] = []
        # used in process data
        self.envelope_line_x: list[float] = []
        self.envelope_line_y: list[float] = []

    def add_data(self, line_parts: list[str], n: int):
        """Add data from food_web_bifurcation_explorer.a parsed line to the envelope data structures.

        Args:
            line_parts: List of strings containing parameter values split by delimiter.
        """
        # extract x value depending on fixed parameter
        if self.fixed_parameter_type == ParameterTypes.DONOR:
            self.x_values.append(float(line_parts[2]))
        elif self.fixed_parameter_type == ParameterTypes.RECIPIENT:
            self.x_values.append(float(line_parts[0]))
        elif self.fixed_parameter_type == ParameterTypes.LOTKAVOLTERRA:
            self.x_values.append(float(line_parts[1]))
        else:
            raise ParameterTypeError("invalid parameter")
        # get values
        envelope_top_serie = [float(x) for x in line_parts[3].split("_")]
        envelope_bot_serie = [float(x) for x in line_parts[4].split("_")]
        self.limit_cycle = line_parts[5] == "1"
        # parse rest of parameters
        for i in range(n):
            self.envelope_top[i].append(envelope_top_serie[i])
            self.envelope_bot[i].append(envelope_bot_serie[i])

    def clear_data(self):
        """Clear all data structures and reset to initial state."""
        self.x_values = []
        self.envelope_exist = []
        self.envelope_top = []
        self.envelope_bot = []
        self.envelope_center = []
        self.n = 0
        # used in process data
        self.envelope_line_x = []
        self.envelope_line_y = []

    def read_envelope_data(
        self,
        branch_type: BranchTypes,
        fixed_parameter_type: ParameterTypes,
        fixed_parameter_value: str,
        n: int,
    ):
        """Read envelope data from food_web_bifurcation_explorer.a zip file and process it.

        Args:
            branch_type: Type of branch to read data for.
            fixed_parameter_type: Type of the fixed parameter.
            fixed_parameter_value: Value of the fixed parameter.
        """
        self.clear_data()
        # set ID values
        self.fixed_parameter_type = fixed_parameter_type
        self.fixed_parameter_value = fixed_parameter_value
        # prepare containers
        self.envelope_top = [[] for _ in range(n)]
        self.envelope_bot = [[] for _ in range(n)]
        # open zip
        try:
            with zipfile.ZipFile(glob.files.get_envelope_zip_file(fixed_parameter_value), "r") as zip_file:
                # open txt file
                with zip_file.open(branch_type + "_" + self.fixed_parameter_type + "_" + self.fixed_parameter_value + ".txt") as file:
                    # iterate over every line
                    for line_bytes in file:
                        # decode and strip line
                        line = line_bytes.decode("utf-8").strip()
                        print(line)
                        # check that line exist
                        if not line:
                            continue
                        # add data
                        self.add_data(line.split(";"), n)
        except Exception as e:
            """"""
        # process data
        self.process_data()

    def process_data(self):
        return
        """Process the raw data to create envelope line coordinates."""
        # fill y values
        for i in range(self.n):
            self.envelope_line_y.append([])
        # Iterate over each time step (row)
        for i, current_x in enumerate(self.x_values):

            # 1. Add the TOP point X coordinate
            self.envelope_line_x.append(current_x)

            # 2. Add the BOTTOM point X coordinate
            self.envelope_line_x.append(current_x)

            # 3. Add the None point X coordinate (to break the line)
            self.envelope_line_x.append(None)

            # Now fill the Y values for each envelope index (column)
            for j in range(self.n):
                if self.envelope_exist[i][j]:
                    # Append Top
                    self.envelope_line_y[j].append(self.envelope_top[i][j])
                    # Append Bottom
                    self.envelope_line_y[j].append(self.envelope_bot[i][j])
                    # Append None (break)
                    self.envelope_line_y[j].append(None)
                else:
                    # If it doesn't exist, we still need to fill the slots
                    # to match the length of envelope_line_x
                    self.envelope_line_y[j].append(None)
                    self.envelope_line_y[j].append(None)
                    self.envelope_line_y[j].append(None)
