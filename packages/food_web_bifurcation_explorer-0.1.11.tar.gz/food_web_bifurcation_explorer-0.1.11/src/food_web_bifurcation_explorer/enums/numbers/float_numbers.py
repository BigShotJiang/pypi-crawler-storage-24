from enum import Enum


class FloatNumbers(float, Enum):
    """Enumeration for float number parameters used in the application."""

    FIXED_PARAMETER_MIN = 0
    FIXED_PARAMETER_MAX = 1.0
    FIXED_PARAMETER_STEP = 0.001
    EIGENVALUE_SPECTRUM_CENTER_MIN_X = -0.05
    EIGENVALUE_SPECTRUM_CENTER_MAX_X = 0.05
