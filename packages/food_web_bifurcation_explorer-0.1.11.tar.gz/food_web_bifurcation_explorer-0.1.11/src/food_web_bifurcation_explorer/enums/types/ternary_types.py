from enum import Enum, unique


@unique
class TernaryTypes(str, Enum):
    """Enumeration for ternary types."""

    SINGLE = "single"
    MULTIPLE = "multiple"
