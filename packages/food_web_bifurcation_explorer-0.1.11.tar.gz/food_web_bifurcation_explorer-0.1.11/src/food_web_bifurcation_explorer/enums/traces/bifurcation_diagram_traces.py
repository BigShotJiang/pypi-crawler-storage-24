from enum import Enum, unique


@unique
class BifurcationDiagramTraces(str, Enum):
    """Enumeration for drawing trace types."""

    # envelope traces
    HOPF_ENVELOPE_BACKGROUND = "envelope background"
    # equilibria traces
    STABLE_EQUILIBRIA_AREA = "Stable equilibria area"
    UNSTABLE_EQUILIBRIA_AREA = "Unstable equilibria area"
    # equilibria traces
    STABLE_EQUILIBRIA = "Stable equilibria"
    UNSTABLE_EQUILIBRIA = "Unstable equilibria"
    # bifurcations
    HOPF_ENVELOPE_ALTERNATIVE = "Hopf envelope alternative"
    HOPF_ENVELOPE_ALTERNATIVE_BOT = "Hopf envelope alternative bot"
    HOPF_ENVELOPE_ALTERNATIVE_TOP = "Hopf envelope alternative top"
    HOPF_ENVELOPE_EMPIRICAL = "Hopf envelope empirical"
    HOPF_ENVELOPE_EMPIRICAL_BOT = "Hopf envelope empirical bot"
    HOPF_ENVELOPE_EMPIRICAL_TOP = "Hopf envelope empirical top"
    HOPF_SUBCRITICAL_ALTERNATIVE = "Hopf subcritical alternative"
    HOPF_SUBCRITICAL_EMPIRICAL = "Hopf subcritical empirical"
    HOPF_SUPERCRITICAL_ALTERNATIVE = "Hopf supercritical alternative"
    HOPF_SUPERCRITICAL_EMPIRICAL = "Hopf supercritical empirical"
    SADDLENODE_ALTERNATIVE = "Saddle-node alternative"
    SADDLENODE_EMPIRICAL = "Saddle-node empirical"
    TRANSCRITICAL_ALTERNATIVE = "Transcritical alternative"
    TRANSCRITICAL_EMPIRICAL = "Transcritical empirical"
    # other
    EXTINCT = "Extinct"
    INTERNAL_ERROR = "Internal error"
    EIGENVALUE_SPECTRUM_INDEX_EMPIRICAL = "Eigenvalue spectrum index empirical"
    EIGENVALUE_SPECTRUM_INDEX_ALTERNATIVE = "Eigenvalue spectrum index alternative"
