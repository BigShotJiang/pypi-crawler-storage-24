﻿from enum import Enum, unique


@unique
class Font(str, Enum):
    """Enumeration for font options."""

    FONT = "sans-serif"
    SIZE = "15px"
    SIZE_TITLE = "24px"
