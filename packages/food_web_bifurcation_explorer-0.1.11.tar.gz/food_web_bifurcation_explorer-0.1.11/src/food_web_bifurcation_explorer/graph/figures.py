"""Module for managing graph figures used in the food web bifurcation explorer."""
import plotly.graph_objects as go

from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes
from food_web_bifurcation_explorer.enums.types.bifurcation_diagram_types import BifurcationDiagramTypes
from food_web_bifurcation_explorer.enums.types.bifurcation_distribution_types import BifurcationDistributionTypes
from food_web_bifurcation_explorer.enums.types.ternary_types import TernaryTypes
from food_web_bifurcation_explorer.graph.bifurcation_diagram.build import build_bifurcation_diagram
from food_web_bifurcation_explorer.graph.eigenvalue_spectrum.build import build_eigenvalue_spectrum
from food_web_bifurcation_explorer.graph.ternary.build import build_ternary
from food_web_bifurcation_explorer.graph.bifurcation_distribution.build_2d import build_bifurcation_distribution_2d
from food_web_bifurcation_explorer.graph.bifurcation_distribution.build_3d import build_bifurcation_distribution_3d


class Figures:

    def __init__(self):
        # empty figure used if case of errors
        self.empty_figure: go.Figure = go.Figure()

        # ternary single
        self.ternary_single: go.Figure = build_ternary(TernaryTypes.SINGLE)

        # ternary multiple
        self.ternary_multiple: go.Figure = build_ternary(TernaryTypes.MULTIPLE)

        # ternary index to know which trace corresponds to which index in the data
        self.ternary_traces_index: dict[str, str] = {}

        # ternary index to know which trace to remove when updating the ternary diagram
        self.ternary_traces_remove: dict[str, str] = {}

        # first bifurcation diagram
        self.bifurcation_diagram_first: go.Figure = build_bifurcation_diagram(BifurcationDiagramTypes.FIRST)

        # second bifurcation diagram
        self.bifurcation_diagram_second: go.Figure = build_bifurcation_diagram(BifurcationDiagramTypes.SECOND)

        # eigenvalue spectrum for empirical branch
        self.eigenvalue_spectrum_empirical: go.Figure = build_eigenvalue_spectrum(BranchTypes.EMPIRICAL)

        # eigenvalue spectrum for alternative branch
        self.eigenvalue_spectrum_alternative: go.Figure = build_eigenvalue_spectrum(BranchTypes.ALTERNATIVE)

        # eigenvalue spectrum for alternative branch
        self.bifurcation_distribution_sdsr: go.Figure = build_bifurcation_distribution_2d(BifurcationDistributionTypes.SD_SR)

        # eigenvalue spectrum for alternative branch
        self.bifurcation_distribution_srsl: go.Figure = build_bifurcation_distribution_2d(BifurcationDistributionTypes.SR_SL)

        # eigenvalue spectrum for alternative branch
        self.bifurcation_distribution_slsd: go.Figure = build_bifurcation_distribution_2d(BifurcationDistributionTypes.SL_SD)

        # eigenvalue spectrum for alternative branch
        self.bifurcation_distribution_3d: go.Figure = build_bifurcation_distribution_3d()