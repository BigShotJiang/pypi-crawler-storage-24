
import plotly.graph_objects as go

from food_web_bifurcation_explorer.common import glob


def build_bifurcation_distribution_3d():

    # declare general figure
    fig = go.Figure()
    
    # update layout
    fig.update_layout(
        margin={"l": 0, "r": 0, "t": 50, "b": 0},
        showlegend=True,
        uirevision="bifurcation_distribution_3d",
        # set sizes
        width=glob.config.resolution * 2,
        height=glob.config.resolution,
    )
    return fig
