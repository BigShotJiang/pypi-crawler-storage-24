from dash import Input, Output, callback

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.frontend.ids import IDs


# callback to update fixed value
@callback(
    # outputs
    Output(IDs.TEXTFIELD_FIXED_PARAMETER_VALUE, "value"),
    # inputs
    Input(IDs.TEXTFIELD_FIXED_PARAMETER_VALUE, "value"),
    # we don't need an initial call
    prevent_initial_call=True,
)

# update fixed value
def update_fixed_parameter_value(fixed_parameter_value: float) -> float:
    # check that we introduced a valid number
    if fixed_parameter_value is not None:
        # set new value
        fixed_parameter_value = glob.config.update_fixed_parameter_value(fixed_parameter_value)
        # read branch datas
        glob.plot_data.load_branch_datas()
        # update only ternary branches
        glob.config.drawing_options.redraw_ternary.branches = True
        # redraw full bifurcation diagrams
        glob.config.drawing_options.redraw_bifurcation_diagrams_first.redraw_all()
        glob.config.drawing_options.redraw_bifurcation_diagrams_second.redraw_all()
    return fixed_parameter_value
