from dash import Input, Output, callback

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes
from food_web_bifurcation_explorer.frontend.ids import IDs


# callback to update analyzed value
@callback(
    # outputs
    Output(IDs.TEXTFIELD_EIGENVALUE_SPECTRUM_INDEX_ALTERNATIVE, "value"),
    # inputs
    Input(IDs.TEXTFIELD_EIGENVALUE_SPECTRUM_INDEX_ALTERNATIVE, "value"),
    # we don't need an initial call
    prevent_initial_call=True,
)

# update analyzed value
def update_eigenvalue_spectrum_index_alternative(eigenvalue_spectrum_index: int):
    # check that we introduced a valid number
    if eigenvalue_spectrum_index is not None:
        # update index
        glob.config.update_eigenvalue_spectrum_index(eigenvalue_spectrum_index, BranchTypes.ALTERNATIVE)
    return eigenvalue_spectrum_index
