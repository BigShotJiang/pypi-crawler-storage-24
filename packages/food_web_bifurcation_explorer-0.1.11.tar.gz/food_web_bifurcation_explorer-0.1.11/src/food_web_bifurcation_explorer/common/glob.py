import dash

from food_web_bifurcation_explorer.enums.labels import Labels

# static options
from food_web_bifurcation_explorer.enums.static_options import StaticOptions

static_options: StaticOptions = StaticOptions()

# config
from food_web_bifurcation_explorer.common.config import Config

config: Config = Config()

# files
from food_web_bifurcation_explorer.common.files import Files

files: Files = Files()

# plot data
from food_web_bifurcation_explorer.data.plot_data import PlotData

plot_data: PlotData = PlotData()

# figures
from food_web_bifurcation_explorer.graph.figures import Figures

figures: Figures = Figures()

# general bifurcation data
from food_web_bifurcation_explorer.data.general_bifurcation_data import GeneralBifurcationData

general_bifurcation_data: GeneralBifurcationData = GeneralBifurcationData()

# Init dash app
app = dash.Dash(__name__)
app.title = Labels.MAIN_TITLE
