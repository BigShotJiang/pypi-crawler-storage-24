"""Module for building empirical branch drawing components."""

from dash import dcc

from food_web_bifurcation_explorer.enums.labels import Labels
from food_web_bifurcation_explorer.frontend.ids import IDs
from food_web_bifurcation_explorer.enums.styles import Styles


def build() -> dcc.Checklist:
    return dcc.Checklist(
        id=IDs.CHECKBOX_DRAW_BRANCH_EMPIRICAL,
        options=[{"label": Labels.EMPIRICAL_BRANCH, "value": True}],
        value=[True],
        inline=True,
        labelStyle=Styles.CHECKBOXLABEL,
    )
