from dash import dcc, html

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.labels import Labels
from food_web_bifurcation_explorer.frontend.ids import IDs
from food_web_bifurcation_explorer.enums.styles import Styles


# title
def title():
    return html.Label(Labels.BIOMASS_COMPARTMENT_SECOND, style=Styles.LABEL)


# build
def build():
    # get compartments
    compartments: list[str] = glob.config.get_current_compartments()
    return dcc.Dropdown(
        id=IDs.DROPDOWN_COMPARTMENT_SECOND,
        options=[{"label": compartments[index] + " (" + str(index) + ")", "value": str(index)} for index in range(0, len(compartments))],
        value="0",  # default compartment
        clearable=False,  # prevents the user from food_web_bifurcation_explorer.clearing the selection (removes the X)
    )


# update
def update():
    # get compartments
    compartments: list[str] = glob.config.get_current_compartments()
    # set new options
    options = [{"label": compartments[index] + " (" + str(index) + ")", "value": str(index)} for index in range(0, len(compartments))]
    return options
