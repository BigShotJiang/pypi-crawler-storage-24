﻿"""Module for building transcritical empirical multiple bifurcations checkbox component."""
from dash import dcc, html

from food_web_bifurcation_explorer.enums.labels import Labels
from food_web_bifurcation_explorer.frontend.ids import IDs
from food_web_bifurcation_explorer.enums.check_box import CheckBox
from food_web_bifurcation_explorer.enums.font import Font
from food_web_bifurcation_explorer.enums.styles import Styles
from food_web_bifurcation_explorer.enums.graph_palette import GraphPalette
from food_web_bifurcation_explorer.enums.symbols import Symbols


def build() -> dcc.Checklist:
    return dcc.Checklist(
        id=IDs.CHECKBOX_MULTIPLE_BIFURCATIONS_TRANSCRITICAL_EMPIRICAL,
        options=[
            {
                "label": html.Span(
                    [
                        Labels.EMPIRICAL_EQUILIBRIA,
                        html.Span(
                            Symbols.CIRCLE,
                            style={
                                "color": GraphPalette.TRANSCRITICAL_EMPIRICAL,
                                "fontSize": Font.SIZE,
                                "marginLeft": CheckBox.MARGING_LEFT,
                            },
                        ),
                    ]
                ),
                "value": True,
            }
        ],
        value=[True],
        inline=True,
        labelStyle=Styles.CHECKBOXLABEL,
    )
