# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class PageParticipant:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'data': 'list[ParticipantInfo]',
        'offset': 'int',
        'limit': 'int',
        'count': 'int'
    }

    attribute_map = {
        'data': 'data',
        'offset': 'offset',
        'limit': 'limit',
        'count': 'count'
    }

    def __init__(self, data=None, offset=None, limit=None, count=None):
        r"""PageParticipant

        The model defined in huaweicloud sdk

        :param data: 被邀请的与会者信息。包含预约会议时邀请的与会者和会中主持人邀请的与会者。
        :type data: list[:class:`huaweicloudsdkmeeting.v1.ParticipantInfo`]
        :param offset: 查询偏移量。
        :type offset: int
        :param limit: 每页的记录数。
        :type limit: int
        :param count: 总记录数。
        :type count: int
        """
        
        

        self._data = None
        self._offset = None
        self._limit = None
        self._count = None
        self.discriminator = None

        if data is not None:
            self.data = data
        if offset is not None:
            self.offset = offset
        if limit is not None:
            self.limit = limit
        if count is not None:
            self.count = count

    @property
    def data(self):
        r"""Gets the data of this PageParticipant.

        被邀请的与会者信息。包含预约会议时邀请的与会者和会中主持人邀请的与会者。

        :return: The data of this PageParticipant.
        :rtype: list[:class:`huaweicloudsdkmeeting.v1.ParticipantInfo`]
        """
        return self._data

    @data.setter
    def data(self, data):
        r"""Sets the data of this PageParticipant.

        被邀请的与会者信息。包含预约会议时邀请的与会者和会中主持人邀请的与会者。

        :param data: The data of this PageParticipant.
        :type data: list[:class:`huaweicloudsdkmeeting.v1.ParticipantInfo`]
        """
        self._data = data

    @property
    def offset(self):
        r"""Gets the offset of this PageParticipant.

        查询偏移量。

        :return: The offset of this PageParticipant.
        :rtype: int
        """
        return self._offset

    @offset.setter
    def offset(self, offset):
        r"""Sets the offset of this PageParticipant.

        查询偏移量。

        :param offset: The offset of this PageParticipant.
        :type offset: int
        """
        self._offset = offset

    @property
    def limit(self):
        r"""Gets the limit of this PageParticipant.

        每页的记录数。

        :return: The limit of this PageParticipant.
        :rtype: int
        """
        return self._limit

    @limit.setter
    def limit(self, limit):
        r"""Sets the limit of this PageParticipant.

        每页的记录数。

        :param limit: The limit of this PageParticipant.
        :type limit: int
        """
        self._limit = limit

    @property
    def count(self):
        r"""Gets the count of this PageParticipant.

        总记录数。

        :return: The count of this PageParticipant.
        :rtype: int
        """
        return self._count

    @count.setter
    def count(self, count):
        r"""Sets the count of this PageParticipant.

        总记录数。

        :param count: The count of this PageParticipant.
        :type count: int
        """
        self._count = count

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, PageParticipant):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
