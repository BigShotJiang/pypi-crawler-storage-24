# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class InviteShareDTO:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'share': 'int'
    }

    attribute_map = {
        'share': 'share'
    }

    def __init__(self, share=None):
        r"""InviteShareDTO

        The model defined in huaweicloud sdk

        :param share: 邀请标志。 * 0：取消邀请 * 1：邀请 
        :type share: int
        """
        
        

        self._share = None
        self.discriminator = None

        self.share = share

    @property
    def share(self):
        r"""Gets the share of this InviteShareDTO.

        邀请标志。 * 0：取消邀请 * 1：邀请 

        :return: The share of this InviteShareDTO.
        :rtype: int
        """
        return self._share

    @share.setter
    def share(self, share):
        r"""Sets the share of this InviteShareDTO.

        邀请标志。 * 0：取消邀请 * 1：邀请 

        :param share: The share of this InviteShareDTO.
        :type share: int
        """
        self._share = share

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, InviteShareDTO):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
