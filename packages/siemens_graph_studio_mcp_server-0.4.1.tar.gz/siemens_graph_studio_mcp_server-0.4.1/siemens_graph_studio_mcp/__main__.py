#!/usr/bin/env python3
"""
Allow running the package directly with python -m siemens_graph_studio_mcp

Usage:
    python -m siemens_graph_studio_mcp
    python -m siemens_graph_studio_mcp --verify
    python -m siemens_graph_studio_mcp --help
"""
from siemens_graph_studio_mcp.server import main

if __name__ == "__main__":
    main()
