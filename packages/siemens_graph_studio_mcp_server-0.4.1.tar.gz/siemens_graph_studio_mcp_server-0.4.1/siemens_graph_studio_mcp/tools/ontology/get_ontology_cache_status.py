"""
Get Ontology Cache Status tool for the AGS SPARQL Agent.

This tool handles get ontology cache status operations.
"""

import os
import sys
from datetime import datetime

from ..base_tool import BaseToolMixin, handle_tool_errors, ToolError
from ...utils.agent_utils import get_agent, get_graphmart_uri
from ...ontology_cache import OntologyCacheManager


async def get_ontology_cache_status() -> str:
    """Get information about ontology caches.
    
    This tool provides status information about the ontology cache system
    including cache entries, sizes, and last update times.
    
    Returns:
        JSON response with cache status information
    """
    from ontology_cache import OntologyCacheManager
    
    cache_manager = OntologyCacheManager()
    cache_info = cache_manager.get_cache_info()
    
    return BaseToolMixin.create_success_response({
        "cache_info": cache_info
    })