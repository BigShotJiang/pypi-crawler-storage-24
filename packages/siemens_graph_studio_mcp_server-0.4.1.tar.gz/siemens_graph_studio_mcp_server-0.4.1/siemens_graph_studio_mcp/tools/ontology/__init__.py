"""
Ontology tools for the AGS SPARQL Agent.

This module provides modular ontology management tools organized by functionality.
Each tool is in its own file for better maintainability.
"""

# File operations
from .load_ontology_from_file import load_ontology_from_file

# Ontology lifecycle
from .register_ontology import register_ontology
from .create_ontology import create_ontology
from .delete_ontology import delete_ontology

# Cache management
from .get_ontology_cache_status import get_ontology_cache_status
from .clear_ontology_cache import clear_ontology_cache
from .refresh_ontology_cache import refresh_ontology_cache

# Import management
from .add_ontology_import import add_ontology_import
from .remove_ontology_import import remove_ontology_import
from .list_ontology_imports import list_ontology_imports

# Class management
from .add_ontology_class import add_ontology_class
from .remove_ontology_class import remove_ontology_class

# Property management
from .add_ontology_property import add_ontology_property
from .remove_ontology_property import remove_ontology_property

# Structure listing
from .list_ontology_structure_classes import list_ontology_structure_classes
from .list_ontology_structure_properties import list_ontology_structure_properties

__all__ = [
    # File operations
    "load_ontology_from_file",
    
    # Ontology lifecycle
    "register_ontology",
    "create_ontology", 
    "delete_ontology",
    
    # Cache management
    "get_ontology_cache_status",
    "clear_ontology_cache",
    "refresh_ontology_cache",
    
    # Import management
    "add_ontology_import",
    "remove_ontology_import", 
    "list_ontology_imports",
    
    # Class management
    "add_ontology_class",
    "remove_ontology_class",
    
    # Property management
    "add_ontology_property",
    "remove_ontology_property",
    
    # Structure listing
    "list_ontology_structure_classes",
    "list_ontology_structure_properties",
]