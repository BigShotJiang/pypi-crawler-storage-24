"""
Clear Ontology Cache tool for the AGS SPARQL Agent.

This tool handles clear ontology cache operations.
"""

import os
import sys
from datetime import datetime

from ..base_tool import BaseToolMixin, handle_tool_errors, ToolError
from ...utils.agent_utils import get_agent, get_graphmart_uri
from ...ontology_cache import OntologyCacheManager


async def clear_ontology_cache(graphmart_uri: str = None) -> str:
    """Clear ontology cache for specific graphmart or all caches.
    
    This tool clears cached ontology information to force fresh discovery
    from the graphmart on next access.
    
    Args:
        graphmart_uri: URI of graphmart to clear cache for (optional, clears all if not provided)
        
    Returns:
        JSON response with cache clearing results
    """
    from ontology_cache import OntologyCacheManager
    
    cache_manager = OntologyCacheManager()
    success = cache_manager.clear_cache(graphmart_uri)
    
    message = f"Cleared cache for {graphmart_uri}" if graphmart_uri else "Cleared all caches"
    
    return BaseToolMixin.create_success_response({
        "graphmart_uri": graphmart_uri,
        "cache_cleared": success
    }, message)