"""
Tool registry and imports for the Siemens Graph Studio MCP server.

This module provides centralized registration and management of all MCP tools.
"""

from .system import test_system_connection, get_session_logs
from .query import execute_sparql_query, query_ags_configuration, update_ags_configuration  
from .discovery import (
    discover_knowledge_overview,
    discover_available_ontologies,
    discover_ontology_classes,
    discover_class_data_properties,
    discover_class_object_properties
)
from .ontology import (
    load_ontology_from_file,
    register_ontology,
    get_ontology_cache_status,
    clear_ontology_cache,
    refresh_ontology_cache,
    create_ontology,
    delete_ontology,
    add_ontology_import,
    remove_ontology_import,
    list_ontology_imports,
    add_ontology_class,
    remove_ontology_class,
    add_ontology_property,
    remove_ontology_property,
    list_ontology_structure_classes,
    list_ontology_structure_properties
)
from .graphmart import (
    create_transformation_layer,
    add_transformation_step,
    add_select_step,
    add_direct_load_step,
    update_transformation_layer,
    update_transformation_step,
    update_direct_load_step,
    delete_transformation_layer,
    delete_transformation_step,
    list_transformation_layers,
    list_transformation_steps,
    refresh_graphmart,
    reload_graphmart,
    get_layer_status,
    get_step_status
)

# Tool registry - function names match MCP tool names exactly
TOOL_REGISTRY = {
    # System tools
    "test_system_connection": test_system_connection,
    "get_session_logs": get_session_logs,
    
    # Query tools  
    "execute_sparql_query": execute_sparql_query,
    "query_ags_configuration": query_ags_configuration,
    "update_ags_configuration": update_ags_configuration,
    
    # Discovery tools
    "discover_knowledge_overview": discover_knowledge_overview,
    "discover_available_ontologies": discover_available_ontologies,
    "discover_ontology_classes": discover_ontology_classes,  # from discovery tools - works with graphmart data
    "discover_class_data_properties": discover_class_data_properties,
    "discover_class_object_properties": discover_class_object_properties,
    
    # Ontology tools
    "load_ontology_from_file": load_ontology_from_file,
    "register_ontology": register_ontology,
    "get_ontology_cache_status": get_ontology_cache_status,
    "clear_ontology_cache": clear_ontology_cache,
    "refresh_ontology_cache": refresh_ontology_cache,
    "create_ontology": create_ontology,
    "delete_ontology": delete_ontology,
    "add_ontology_import": add_ontology_import,
    "remove_ontology_import": remove_ontology_import,
    "list_ontology_imports": list_ontology_imports,
    "add_ontology_class": add_ontology_class,
    "remove_ontology_class": remove_ontology_class,
    "add_ontology_property": add_ontology_property,
    "remove_ontology_property": remove_ontology_property,
    
    # Ontology structure listing tools (AGS configuration)
    "list_ontology_structure_classes": list_ontology_structure_classes,  # from ontology_tools - works with AGS configuration
    "list_ontology_structure_properties": list_ontology_structure_properties,  # from ontology_tools - works with AGS configuration
    
    # Graphmart tools
    "create_transformation_layer": create_transformation_layer,
    "add_transformation_step": add_transformation_step,
    "add_select_step": add_select_step,
    "add_direct_load_step": add_direct_load_step,
    "update_transformation_layer": update_transformation_layer,
    "update_transformation_step": update_transformation_step,
    "update_direct_load_step": update_direct_load_step,
    "delete_transformation_layer": delete_transformation_layer,
    "delete_transformation_step": delete_transformation_step,
    "list_transformation_layers": list_transformation_layers,
    "list_transformation_steps": list_transformation_steps,
    "refresh_graphmart": refresh_graphmart,
    "reload_graphmart": reload_graphmart,
    "get_layer_status": get_layer_status,
    "get_step_status": get_step_status,
}

def register_tools(mcp_server):
    """Register all tools with the MCP server."""
    for tool_name, tool_func in TOOL_REGISTRY.items():
        # Set the function name for MCP registration
        tool_func.__name__ = tool_name
        mcp_server.tool()(tool_func)
    
    return len(TOOL_REGISTRY)

def get_tool_categories():
    """Get organized tool categories for documentation."""
    return {
        "System & Monitoring": [
            "test_system_connection", 
            "get_session_logs"
        ],
        "SPARQL Query Execution": [
            "execute_sparql_query",
            "query_ags_configuration", 
            "update_ags_configuration"
        ],
        "Knowledge Discovery": [
            "discover_knowledge_overview",
            "discover_available_ontologies",
            "discover_ontology_classes",
            "discover_class_data_properties",
            "discover_class_object_properties"
        ],
        "Ontology Management": [
            "load_ontology_from_file",
            "register_ontology", 
            "create_ontology",
            "delete_ontology",
            "add_ontology_import",
            "remove_ontology_import",
            "list_ontology_imports",
            "get_ontology_cache_status",
            "clear_ontology_cache", 
            "refresh_ontology_cache"
        ],
        "Graphmart Construction": [
            "create_transformation_layer",
            "update_transformation_layer",
            "delete_transformation_layer",
            "list_transformation_layers",
            "add_transformation_step",
            "add_select_step",
            "update_transformation_step", 
            "delete_transformation_step",  # Works for both transformation and direct load steps
            "list_transformation_steps",   # Lists both transformation and direct load steps
            "add_direct_load_step",
            "update_direct_load_step"
        ],
        "Graphmart Management": [
            "refresh_graphmart",  # Lightweight refresh of changed layers only
            "reload_graphmart"    # Complete reprocessing of all layers
        ],
        "Graphmart Diagnostics": [
            "get_layer_status",   # RECOMMENDED: Comprehensive layer and step error information  
            "get_step_status"     # Specific step debugging (use get_layer_status for general debugging)
        ]
    }