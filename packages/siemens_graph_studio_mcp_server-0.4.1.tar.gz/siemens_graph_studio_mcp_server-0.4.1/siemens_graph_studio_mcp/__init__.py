"""
Siemens Graph Studio MCP Server

An MCP (Model Context Protocol) server that enables AI agents to interact with
Siemens Graph Studio knowledge graphs via SPARQL queries.

Features:
- Execute SPARQL queries against GraphMarts
- Discover ontologies and classes
- Manage GraphMart transformations
- Cache and load ontologies
- Natural language to SPARQL translation (with OpenAI)

Basic Usage:
    # Install
    pip install siemens-graph-studio-mcp-server
    
    # Configure
    export ANZO_SERVER=your-server.example.com
    export ANZO_PORT=8443
    export ANZO_USERNAME=your-username
    export ANZO_PASSWORD=your-password
    export GRAPHMART_URI=http://example.com/Graphmart/your-graphmart
    
    # Run
    siemens-graph-studio-mcp

Programmatic Usage:
    from siemens_graph_studio_mcp import GraphmartConfig, SPARQLAgent
    
    config = GraphmartConfig(
        ags_server="your-server.example.com",
        ags_port=8443,
        graphmart_uri="http://example.com/Graphmart/your-graphmart",
        username="your-username",
        password="your-password"
    )
    
    agent = SPARQLAgent(config)
    await agent.initialize()
"""

__version__ = "0.4.0"
__author__ = "Siemens Graph Studio Team"
__license__ = "Apache-2.0"

from .models import (
    GraphmartConfig,
    ClassInfo,
    PropertyInfo,
    OntologyInfo,
    QueryResult,
    SPARQLQuery,
    QuestionResponse,
    KnowledgeExploration,
    ExamplesResponse,
    AgentInsights,
)

from .server import main

# Lazy imports for optional components
def __getattr__(name):
    if name == "SPARQLAgent":
        from .sparql_agent_core import SPARQLAgent
        return SPARQLAgent
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = [
    # Version info
    "__version__",
    "__author__",
    "__license__",
    # Core models
    "GraphmartConfig",
    "ClassInfo",
    "PropertyInfo",
    "OntologyInfo",
    "QueryResult",
    "SPARQLQuery",
    "QuestionResponse",
    "KnowledgeExploration",
    "ExamplesResponse",
    "AgentInsights",
    # Main entry point
    "main",
    # Lazy imports
    "SPARQLAgent",
]
