"""
Example: Programmatic usage of siemens-graph-studio-mcp

This example shows how to use the package programmatically in Python code.
"""

import asyncio
import os

from siemens_graph_studio_mcp import GraphmartConfig, SPARQLAgent


async def main():
    """Example usage of the SPARQL Agent."""
    
    # Method 1: Create config from environment variables
    # (requires ANZO_SERVER, ANZO_PORT, ANZO_USERNAME, ANZO_PASSWORD, GRAPHMART_URI)
    # config = GraphmartConfig.from_env()
    
    # Method 2: Create config explicitly
    config = GraphmartConfig(
        ags_server=os.environ.get("ANZO_SERVER", "graph-studio.example.com"),
        ags_port=int(os.environ.get("ANZO_PORT", "8443")),
        graphmart_uri=os.environ.get("GRAPHMART_URI", "http://example.com/Graphmart/demo"),
        username=os.environ.get("ANZO_USERNAME", "admin"),
        password=os.environ.get("ANZO_PASSWORD", ""),
    )
    
    print(f"Connecting to: {config.ags_server}:{config.ags_port}")
    print(f"GraphMart: {config.graphmart_uri}")
    
    # Initialize the agent
    agent = SPARQLAgent(config)
    await agent.initialize()
    
    print("Agent initialized successfully!")
    
    # Example: Discover available ontologies
    # result = await agent.discover_ontologies()
    # print(f"Found {len(result.classes)} classes")
    
    # Example: Execute a SPARQL query
    # query = "SELECT ?s ?p ?o WHERE { ?s ?p ?o } LIMIT 10"
    # result = await agent.execute_query(query)
    # print(f"Query returned {len(result.data)} rows")


if __name__ == "__main__":
    asyncio.run(main())
