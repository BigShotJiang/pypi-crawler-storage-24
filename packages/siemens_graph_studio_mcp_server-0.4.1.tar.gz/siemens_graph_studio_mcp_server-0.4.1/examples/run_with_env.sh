# Example: Using siemens-graph-studio-mcp with environment variables

# ====================================
# Required Environment Variables
# ====================================

# Graph Studio server hostname (without protocol)
export ANZO_SERVER="graph-studio.example.com"

# HTTPS port (typically 8443)
export ANZO_PORT="8443"

# Authentication credentials
export ANZO_USERNAME="your-username"
export ANZO_PASSWORD="your-password"

# Target GraphMart URI
# Find this in Graph Studio UI: GraphMarts > Your GraphMart > Properties
export GRAPHMART_URI="http://example.com/Graphmart/your-graphmart-id"

# ====================================
# Optional Environment Variables
# ====================================

# OpenAI API key for natural language query generation
# If not provided, only direct SPARQL queries will work
export API_KEY="sk-your-openai-api-key"

# Enable debug output (set to "true" for verbose logging)
# export ENABLE_AGENT_DEBUG="true"
# export ENABLE_LOGGING_DEBUG="true"

# ====================================
# Run the MCP Server
# ====================================

# Option 1: Default stdio transport (for Claude Desktop)
siemens-graph-studio-mcp

# Option 2: SSE transport (for web clients)
# siemens-graph-studio-mcp --transport sse --port 8000

# Option 3: Using a config file instead of env vars
# siemens-graph-studio-mcp --config my-config.json

# ====================================
# Verify Connection (optional)
# ====================================
# After starting, the server will output connection status to stderr.
# Look for "✅ All required environment variables configured"
