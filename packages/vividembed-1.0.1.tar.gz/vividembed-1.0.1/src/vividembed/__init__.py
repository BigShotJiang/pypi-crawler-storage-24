"""
VividEmbed — Neuroscience-Inspired Memory Embeddings for AI Companions
======================================================================

    pip install vividembed
    pip install vividembed[viz]      # for visual reports
    pip install vividembed[all]      # everything

Quick start::

    from vividembed import VividEmbed

    ve = VividEmbed()
    ve.add("Scott took me to the beach", emotion="peaceful", importance=8)
    ve.add("We had an argument about money", emotion="angry", importance=7)

    results = ve.query("tell me about a good day", mood="happy", top_k=3)
    for r in results:
        print(f"  [{r.emotion}] {r.content}")
"""

from .vividembed import (
    VividEntry,
    VividEmbed,
    CoreMemory,
    VividCortex,
    ARC_POSITIONS,
    EMBED_DIM,
    EMOTION_VECTORS,
    _infer_arc_position,
)

__all__ = [
    "VividEmbed",
    "VividEntry",
    "CoreMemory",
    "VividCortex",
    "ARC_POSITIONS",
    "EMBED_DIM",
    "EMOTION_VECTORS",
    "_infer_arc_position",
]
__version__ = "1.0.1"
