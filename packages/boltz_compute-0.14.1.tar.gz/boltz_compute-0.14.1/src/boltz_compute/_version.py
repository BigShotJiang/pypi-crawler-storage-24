# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "boltz_compute"
__version__ = "0.14.1"  # x-release-please-version
