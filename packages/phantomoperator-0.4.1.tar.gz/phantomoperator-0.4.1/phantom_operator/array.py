import numpy as np
from absence_calculator import AbsentNumber, Void, VOID, Unresolved
from absence_calculator.core import ErasedExcess, _collect_terms, _build_result


class AbsentArray:
    def __init__(self, values, states=None):
        if isinstance(values, AbsentArray):
            self._present = values._present.copy()
            self._absent = values._absent.copy()
            self._is_void = values._is_void.copy()
            self._excesses = {k: v.copy() for k, v in values._excesses.items()}
            self._unresolvable = [list(u) for u in values._unresolvable]
            return

        if isinstance(values, list):
            self._init_from_list(values, states)
            return

        if isinstance(values, np.ndarray):
            self._init_from_numpy(values, states)
            return

        raise TypeError(f"Cannot create AbsentArray from {type(values).__name__}")

    def _init_from_list(self, items, states_override=None):
        pres = []
        abse = []
        voids = []
        raw_excesses = []
        raw_unresolvable = []
        has_any_excess = False
        has_any_unresolvable = False

        for item in items:
            if isinstance(item, Void):
                pres.append(0.0)
                abse.append(0.0)
                voids.append(True)
                raw_excesses.append({})
                raw_unresolvable.append([])
            elif isinstance(item, (int, float)):
                pres.append(float(item))
                abse.append(0.0)
                voids.append(False)
                raw_excesses.append({})
                raw_unresolvable.append([])
            elif isinstance(item, list):
                sub = AbsentArray(item)
                pres.append(sub._present)
                abse.append(sub._absent)
                voids.append(sub._is_void)
                raw_excesses.append({})
                raw_unresolvable.append([])
            else:
                p, a, ex, un = _collect_terms(item)
                pres.append(float(p))
                abse.append(float(a))
                voids.append(False)
                raw_excesses.append(dict(ex))
                raw_unresolvable.append(list(un))
                if ex:
                    has_any_excess = True
                if un:
                    has_any_unresolvable = True

        self._present = np.array(pres, dtype=np.float64)
        self._absent = np.array(abse, dtype=np.float64)
        self._is_void = np.array(voids, dtype=bool)

        if has_any_excess:
            all_keys = set()
            for ex in raw_excesses:
                all_keys.update(ex.keys())
            self._excesses = {}
            for key in all_keys:
                vals = [ex.get(key, 0.0) for ex in raw_excesses]
                arr = np.array(vals, dtype=np.float64)
                if np.any(arr != 0):
                    self._excesses[key] = arr
        else:
            self._excesses = {}

        self._unresolvable = raw_unresolvable if has_any_unresolvable else [[] for _ in items]

        if states_override is not None:
            sts = np.array(states_override, dtype=np.int8)
            raw = self._present + self._absent
            self._present = np.zeros_like(raw)
            self._absent = np.zeros_like(raw)
            self._is_void = sts == -1
            self._present[sts == 0] = raw[sts == 0]
            self._absent[sts == 1] = raw[sts == 1]
            self._excesses = {}
            self._unresolvable = [[] for _ in items]

    def _init_from_numpy(self, values, states):
        vals = values.astype(np.float64)
        if states is not None:
            if isinstance(states, np.ndarray):
                sts = states.astype(np.int8)
            else:
                sts = np.full(vals.shape, states, dtype=np.int8)
        else:
            sts = np.zeros(vals.shape, dtype=np.int8)

        self._present = np.zeros(vals.shape, dtype=np.float64)
        self._absent = np.zeros(vals.shape, dtype=np.float64)
        self._is_void = sts == -1
        self._excesses = {}
        self._unresolvable = [[] for _ in range(vals.size)]

        p_mask = (sts == 0) & ~self._is_void
        a_mask = (sts == 1) & ~self._is_void
        self._present[p_mask] = vals[p_mask]
        self._absent[a_mask] = vals[a_mask]

    @classmethod
    def _from_pa(cls, present, absent, is_void, excesses=None, unresolvable=None):
        arr = cls.__new__(cls)
        arr._present = present.astype(np.float64) if present.dtype != np.float64 else present
        arr._absent = absent.astype(np.float64) if absent.dtype != np.float64 else absent
        arr._is_void = is_void.astype(bool) if is_void.dtype != bool else is_void
        arr._excesses = excesses if excesses is not None else {}
        size = arr._present.size
        arr._unresolvable = unresolvable if unresolvable is not None else [[] for _ in range(size)]
        return arr

    @property
    def has_excesses(self):
        return bool(self._excesses)

    @property
    def has_unresolvable(self):
        return any(u for u in self._unresolvable)

    def _get_scalar(self, flat_idx):
        if self._is_void.flat[flat_idx]:
            return VOID
        p = float(self._present.flat[flat_idx])
        a = float(self._absent.flat[flat_idx])
        ex = {}
        for key, earr in self._excesses.items():
            v = float(earr.flat[flat_idx])
            if v != 0:
                ex[key] = v
        un = self._unresolvable[flat_idx]
        return _build_result(p, a, ex, un)

    @property
    def present_values(self):
        return self._present

    @property
    def absent_values(self):
        return self._absent

    @property
    def values(self):
        result = np.where(self._present != 0, self._present, self._absent)
        result[self._is_void] = 0.0
        return result

    @property
    def states(self):
        result = np.where(
            self._present != 0, 0,
            np.where(self._absent != 0, 1, 0)
        ).astype(np.int8)
        result[self._is_void] = -1
        return result

    @property
    def shape(self):
        return self._present.shape

    @property
    def size(self):
        return self._present.size

    @property
    def ndim(self):
        return self._present.ndim

    @property
    def dtype(self):
        return self._present.dtype

    def __len__(self):
        return len(self._present)

    def __getitem__(self, key):
        if isinstance(key, (int, np.integer)):
            return self._get_scalar(key)

        p = self._present[key]
        a = self._absent[key]
        v = self._is_void[key]

        if isinstance(p, np.ndarray):
            ex = {k: arr[key].copy() for k, arr in self._excesses.items()}
            ex = {k: v2 for k, v2 in ex.items() if np.any(v2 != 0)}
            flat_indices = np.arange(self.size).reshape(self.shape)[key].ravel()
            un = [self._unresolvable[i] for i in flat_indices]
            return AbsentArray._from_pa(p.copy(), a.copy(), v.copy(), ex, un)

        return self._get_scalar(key)

    def __setitem__(self, key, value):
        if isinstance(value, Void):
            self._present[key] = 0
            self._absent[key] = 0
            self._is_void[key] = True
            for earr in self._excesses.values():
                earr[key] = 0
        elif isinstance(value, (int, float)):
            self._present[key] = value
            self._absent[key] = 0
            self._is_void[key] = False
            for earr in self._excesses.values():
                earr[key] = 0
        elif isinstance(value, AbsentArray):
            self._present[key] = value._present
            self._absent[key] = value._absent
            self._is_void[key] = value._is_void
            for k, earr in value._excesses.items():
                if k not in self._excesses:
                    self._excesses[k] = np.zeros_like(self._present)
                self._excesses[k][key] = earr
        else:
            p, a, ex, un = _collect_terms(value)
            self._present[key] = p
            self._absent[key] = a
            self._is_void[key] = False
            for earr in self._excesses.values():
                earr[key] = 0
            for k, v in ex.items():
                if k not in self._excesses:
                    self._excesses[k] = np.zeros_like(self._present)
                self._excesses[k][key] = v
            flat_key = key if isinstance(key, int) else key
            self._unresolvable[flat_key] = list(un)

    def to_list(self):
        result = [self._get_scalar(i) for i in range(self.size)]
        if self.ndim == 1:
            return result
        shape = self.shape
        def reshape(flat, dims):
            if len(dims) == 1:
                return flat[:dims[0]]
            chunk = 1
            for d in dims[1:]:
                chunk *= d
            return [reshape(flat[i*chunk:(i+1)*chunk], dims[1:]) for i in range(dims[0])]
        return reshape(result, list(shape))

    def copy(self):
        return AbsentArray._from_pa(
            self._present.copy(), self._absent.copy(), self._is_void.copy(),
            {k: v.copy() for k, v in self._excesses.items()},
            [list(u) for u in self._unresolvable]
        )

    def reshape(self, *shape):
        if len(shape) == 1 and isinstance(shape[0], tuple):
            shape = shape[0]
        return AbsentArray._from_pa(
            self._present.reshape(shape),
            self._absent.reshape(shape),
            self._is_void.reshape(shape),
            {k: v.reshape(shape) for k, v in self._excesses.items()},
            list(self._unresolvable)
        )

    def flatten(self):
        return AbsentArray._from_pa(
            self._present.ravel().copy(),
            self._absent.ravel().copy(),
            self._is_void.ravel().copy(),
            {k: v.ravel().copy() for k, v in self._excesses.items()},
            list(self._unresolvable)
        )

    def _format_element_at(self, idx):
        if self._is_void.flat[idx]:
            return "void"
        p = self._present.flat[idx]
        a = self._absent.flat[idx]

        def _fmt(v):
            if isinstance(v, float) and v == int(v):
                return str(int(v))
            return str(v)

        parts = []
        if p != 0:
            parts.append(_fmt(p))
        if a != 0:
            parts.append(f"{_fmt(a)}(0)")

        for (state, level) in sorted(self._excesses.keys(), key=lambda k: (k[1], k[0])):
            val = self._excesses[(state, level)].flat[idx]
            if val != 0:
                prefix = "erased " * level
                if state == 1:
                    parts.append(f"{prefix}{_fmt(val)}(0)")
                else:
                    parts.append(f"{prefix}{_fmt(val)}")

        for term in self._unresolvable[idx]:
            parts.append(str(term))

        if not parts:
            return "0"
        return " + ".join(parts)

    def __repr__(self):
        if self.ndim == 1:
            items = [self._format_element_at(i) for i in range(self.size)]
            return f"AbsentArray([{', '.join(items)}])"
        return f"AbsentArray(shape={self.shape})"

    def __eq__(self, other):
        if isinstance(other, AbsentArray):
            if not (np.array_equal(self._present, other._present) and
                    np.array_equal(self._absent, other._absent) and
                    np.array_equal(self._is_void, other._is_void)):
                return False
            if set(self._excesses.keys()) != set(other._excesses.keys()):
                return False
            for k in self._excesses:
                if not np.array_equal(self._excesses[k], other._excesses[k]):
                    return False
            return True
        return False

    @property
    def void_mask(self):
        return self._is_void.copy()


def absent_array(data, states=None):
    return AbsentArray(data, states)


def zeros(shape, state=0):
    if isinstance(shape, int):
        shape = (shape,)
    vals = np.zeros(shape, dtype=np.float64)
    sts = np.full(shape, state, dtype=np.int8)
    return AbsentArray(vals, sts)


def ones(shape, state=0):
    if isinstance(shape, int):
        shape = (shape,)
    vals = np.ones(shape, dtype=np.float64)
    sts = np.full(shape, state, dtype=np.int8)
    return AbsentArray(vals, sts)


def full(shape, value, state=0):
    if isinstance(shape, int):
        shape = (shape,)
    vals = np.full(shape, value, dtype=np.float64)
    sts = np.full(shape, state, dtype=np.int8)
    return AbsentArray(vals, sts)


def empty(shape, state=0):
    if isinstance(shape, int):
        shape = (shape,)
    vals = np.empty(shape, dtype=np.float64)
    sts = np.full(shape, state, dtype=np.int8)
    return AbsentArray(vals, sts)


def voids(shape):
    if isinstance(shape, int):
        shape = (shape,)
    return AbsentArray._from_pa(
        np.zeros(shape, dtype=np.float64),
        np.zeros(shape, dtype=np.float64),
        np.ones(shape, dtype=bool)
    )


def arange(start, stop=None, step=1, state=0):
    if stop is None:
        stop = start
        start = 1
    vals = np.arange(start, stop + 1, step, dtype=np.float64)
    sts = np.full(vals.shape, state, dtype=np.int8)
    return AbsentArray(vals, sts)
