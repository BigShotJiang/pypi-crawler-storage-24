import numpy as np
from phantom_operator.array import AbsentArray


def _ensure_array(x):
    if isinstance(x, AbsentArray):
        return x
    from absence_calculator import Void, VOID
    if isinstance(x, Void) or x is VOID:
        return AbsentArray._from_pa(
            np.array([0.0]), np.array([0.0]), np.array([True])
        )
    if isinstance(x, (int, float)):
        return AbsentArray._from_pa(
            np.array([float(x)]), np.array([0.0]), np.array([False])
        )
    if isinstance(x, list):
        return AbsentArray(x)
    return AbsentArray([x])


def _broadcast(a, b):
    a = _ensure_array(a)
    b = _ensure_array(b)
    if a.shape != b.shape:
        try:
            v = np.broadcast_shapes(a.shape, b.shape)
            new_size = 1
            for d in v:
                new_size *= d

            ap = np.broadcast_to(a._present, v).copy()
            aa = np.broadcast_to(a._absent, v).copy()
            av = np.broadcast_to(a._is_void, v).copy()
            a_ex = {k: np.broadcast_to(arr, v).copy() for k, arr in a._excesses.items()}
            a_un = _broadcast_list(a._unresolvable, a.size, new_size)

            bp = np.broadcast_to(b._present, v).copy()
            ba = np.broadcast_to(b._absent, v).copy()
            bv = np.broadcast_to(b._is_void, v).copy()
            b_ex = {k: np.broadcast_to(arr, v).copy() for k, arr in b._excesses.items()}
            b_un = _broadcast_list(b._unresolvable, b.size, new_size)

            a = AbsentArray._from_pa(ap, aa, av, a_ex, a_un)
            b = AbsentArray._from_pa(bp, ba, bv, b_ex, b_un)
        except ValueError:
            raise ValueError(f"Cannot broadcast shapes {a.shape} and {b.shape}")
    return a, b


def _broadcast_list(lst, old_size, new_size):
    if old_size == new_size:
        return lst
    if old_size == 1:
        return [lst[0]] * new_size
    return lst + [[] for _ in range(new_size - old_size)]


def _merge_excesses_add(x, y, x_void, y_void, both_void, neither):
    all_keys = set(x._excesses.keys()) | set(y._excesses.keys())
    if not all_keys:
        return {}
    result = {}
    for key in all_keys:
        xv = x._excesses.get(key, np.zeros_like(x._present))
        yv = y._excesses.get(key, np.zeros_like(y._present))
        rv = np.zeros_like(x._present)
        rv[neither] = xv[neither] + yv[neither]
        rv[x_void] = yv[x_void]
        rv[y_void] = xv[y_void]
        if np.any(rv != 0):
            result[key] = rv
    return result


def _merge_unresolvable_add(x_un, y_un, x_void, y_void, size):
    result = []
    x_void_flat = x_void.ravel()
    y_void_flat = y_void.ravel()
    for i in range(size):
        if x_void_flat[i]:
            result.append(list(y_un[i]))
        elif y_void_flat[i]:
            result.append(list(x_un[i]))
        else:
            result.append(x_un[i] + y_un[i])
    return result


def arr_add(x, y):
    x, y = _broadcast(x, y)
    both_void = x._is_void & y._is_void
    x_void = x._is_void & ~y._is_void
    y_void = y._is_void & ~x._is_void
    neither = ~x._is_void & ~y._is_void

    rp = np.zeros_like(x._present)
    ra = np.zeros_like(x._absent)
    rv = np.zeros(x._present.shape, dtype=bool)

    rv[both_void] = True
    rp[x_void] = y._present[x_void]
    ra[x_void] = y._absent[x_void]
    rp[y_void] = x._present[y_void]
    ra[y_void] = x._absent[y_void]
    rp[neither] = x._present[neither] + y._present[neither]
    ra[neither] = x._absent[neither] + y._absent[neither]

    rex = _merge_excesses_add(x, y, x_void, y_void, both_void, neither)

    has_un = x.has_unresolvable or y.has_unresolvable
    if has_un:
        run = _merge_unresolvable_add(x._unresolvable, y._unresolvable, x_void, y_void, x.size)
    else:
        run = None

    return AbsentArray._from_pa(rp, ra, rv, rex, run)


def arr_subtract(x, y):
    x, y = _broadcast(x, y)

    if y.has_unresolvable:
        return _elementwise_op(x, y, 'subtract')

    both_void = x._is_void & y._is_void
    x_void = x._is_void & ~y._is_void
    y_void = y._is_void & ~x._is_void
    neither = ~x._is_void & ~y._is_void

    rp = np.zeros_like(x._present)
    ra = np.zeros_like(x._absent)
    rv = np.zeros(x._present.shape, dtype=bool)

    rv[both_void] = True
    rv[x_void] = True
    rp[y_void] = x._present[y_void]
    ra[y_void] = x._absent[y_void]

    rp[neither] = x._present[neither] - y._present[neither]
    ra[neither] = x._absent[neither] - y._absent[neither]

    is_zero = neither & (rp == 0) & (ra == 0)
    no_excesses_at_zero = is_zero.copy()
    for earr in x._excesses.values():
        no_excesses_at_zero &= (earr == 0)
    for earr in y._excesses.values():
        no_excesses_at_zero &= (earr == 0)
    rv[no_excesses_at_zero] = True

    rex = {}
    all_keys = set(x._excesses.keys()) | set(y._excesses.keys())
    for key in all_keys:
        xv = x._excesses.get(key, np.zeros_like(x._present))
        yv = y._excesses.get(key, np.zeros_like(y._present))
        vals = np.zeros_like(x._present)
        vals[neither] = xv[neither] - yv[neither]
        vals[y_void] = xv[y_void]
        if np.any(vals != 0):
            rex[key] = vals

    run = [list(u) for u in x._unresolvable] if x.has_unresolvable else None

    return AbsentArray._from_pa(rp, ra, rv, rex, run)


def arr_multiply(x, y):
    x, y = _broadcast(x, y)
    any_void = x._is_void | y._is_void

    if not x._excesses and not y._excesses and not x.has_unresolvable and not y.has_unresolvable:
        rp = (x._present * y._present) + (x._absent * y._absent)
        ra = (x._present * y._absent) + (x._absent * y._present)

        rv = np.zeros(x._present.shape, dtype=bool)
        rv[any_void] = True
        rp[any_void] = 0
        ra[any_void] = 0

        return AbsentArray._from_pa(rp, ra, rv)
    else:
        return _elementwise_op(x, y, 'multiply')


def arr_divide(x, y):
    x, y = _broadcast(x, y)
    any_void = x._is_void | y._is_void

    if not x._excesses and not y._excesses and not x.has_unresolvable and not y.has_unresolvable:
        yp = y._present
        ya = y._absent
        xp = x._present
        xa = x._absent

        denom = yp ** 2 - ya ** 2
        with np.errstate(divide='ignore', invalid='ignore'):
            safe_denom = np.where(denom != 0, denom, 1.0)
            rp = np.where(denom != 0, (xp * yp - xa * ya) / safe_denom, 0.0)
            ra = np.where(denom != 0, (xa * yp - xp * ya) / safe_denom, 0.0)

        rp = np.round(rp, 10)
        ra = np.round(ra, 10)
        int_mask_p = rp == np.floor(rp)
        int_mask_a = ra == np.floor(ra)
        rp = np.where(int_mask_p, np.floor(rp), rp)
        ra = np.where(int_mask_a, np.floor(ra), ra)

        rv = np.zeros(x._present.shape, dtype=bool)
        rv[any_void] = True
        rp[any_void] = 0
        ra[any_void] = 0

        return AbsentArray._from_pa(rp, ra, rv)
    else:
        return _elementwise_op(x, y, 'divide')


def _elementwise_op(x, y, op_name):
    from absence_calculator import add as pt_add, subtract as pt_sub
    from absence_calculator import multiply as pt_mul, divide as pt_div
    from absence_calculator import VOID

    ops = {'add': pt_add, 'subtract': pt_sub, 'multiply': pt_mul, 'divide': pt_div}
    op_fn = ops[op_name]

    results = []
    for i in range(x.size):
        xv = x._is_void.flat[i]
        yv = y._is_void.flat[i]
        if xv and yv:
            results.append(VOID)
        elif xv:
            if op_name == 'add':
                results.append(y._get_scalar(i))
            else:
                results.append(VOID)
        elif yv:
            if op_name in ('add', 'subtract'):
                results.append(x._get_scalar(i))
            else:
                results.append(VOID)
        else:
            xe = x._get_scalar(i)
            ye = y._get_scalar(i)
            results.append(op_fn(xe, ye))
    return AbsentArray(results)


def arr_erase(x, y):
    from absence_calculator import erase as pt_erase, VOID
    x, y = _broadcast(x, y)
    results = []
    for i in range(x.size):
        if x._is_void.flat[i] and y._is_void.flat[i]:
            results.append(VOID)
        elif y._is_void.flat[i]:
            results.append(x._get_scalar(i))
        elif x._is_void.flat[i]:
            results.append(VOID)
        else:
            results.append(pt_erase(x._get_scalar(i), y._get_scalar(i)))
    return AbsentArray(results)


def arr_toggle(arr):
    arr = _ensure_array(arr)

    if arr.has_unresolvable:
        return _elementwise_toggle(arr)

    rp = arr._absent.copy()
    ra = arr._present.copy()
    rv = arr._is_void.copy()
    rp[rv] = 0
    ra[rv] = 0

    rex = {}
    for (state, level), earr in arr._excesses.items():
        new_state = 1 - state
        rex[(new_state, level)] = earr.copy()

    return AbsentArray._from_pa(rp, ra, rv, rex)


def _elementwise_toggle(arr):
    from absence_calculator import toggle as pt_toggle, VOID
    results = []
    for i in range(arr.size):
        if arr._is_void.flat[i]:
            results.append(VOID)
        else:
            results.append(pt_toggle(arr._get_scalar(i)))
    return AbsentArray(results)


def arr_combine(x, y):
    from absence_calculator import combine as pt_combine, VOID
    x, y = _broadcast(x, y)
    results = []
    for i in range(x.size):
        if x._is_void.flat[i] and y._is_void.flat[i]:
            results.append(VOID)
        elif x._is_void.flat[i]:
            results.append(pt_combine(VOID, y._get_scalar(i)))
        elif y._is_void.flat[i]:
            results.append(pt_combine(x._get_scalar(i), VOID))
        else:
            results.append(pt_combine(x._get_scalar(i), y._get_scalar(i)))
    return AbsentArray(results)


def arr_join(x, y):
    x = _ensure_array(x)
    y = _ensure_array(y)
    rp = np.concatenate([x._present.ravel(), y._present.ravel()])
    ra = np.concatenate([x._absent.ravel(), y._absent.ravel()])
    rv = np.concatenate([x._is_void.ravel(), y._is_void.ravel()])
    all_keys = set(x._excesses.keys()) | set(y._excesses.keys())
    rex = {}
    for key in all_keys:
        xv = x._excesses.get(key, np.zeros(x.size))
        yv = y._excesses.get(key, np.zeros(y.size))
        rex[key] = np.concatenate([xv.ravel(), yv.ravel()])
    run = x._unresolvable + y._unresolvable
    return AbsentArray._from_pa(rp, ra, rv, rex if rex else None, run if any(u for u in run) else None)


def arr_compare(x, y):
    x, y = _broadcast(x, y)
    both_void = x._is_void & y._is_void
    one_void = x._is_void ^ y._is_void
    if np.any(one_void):
        raise ValueError("Cannot compare void with a number — void has no magnitude")
    neither = ~x._is_void & ~y._is_void
    if np.any(neither):
        x_total = x._present[neither] + x._absent[neither]
        y_total = y._present[neither] + y._absent[neither]
        if not np.allclose(x_total, y_total):
            mismatched = np.where(neither)[0] if neither.ndim == 1 else np.argwhere(neither)
            for i, idx in enumerate(mismatched):
                if not np.isclose(x_total[i], y_total[i]):
                    raise ValueError(
                        f"Cannot compare: total magnitudes differ at position {idx} "
                        f"({x_total[i]} vs {y_total[i]}). "
                        f"compare() only works on inputs with the same total magnitude."
                    )

    diff = y._present - x._present

    rp = np.where(diff > 0, diff, 0.0)
    ra = np.where(diff < 0, np.abs(diff), 0.0)
    rv = np.zeros(x._present.shape, dtype=bool)
    rv[both_void] = True
    eq = neither & (diff == 0)
    rv[eq] = True
    rp[rv] = 0
    ra[rv] = 0

    return AbsentArray._from_pa(rp, ra, rv)


def arr_where(arr, condition_fn=None):
    arr = _ensure_array(arr)
    if condition_fn is None:
        return np.where((arr._present > 0) & (arr._absent == 0) & ~arr._is_void)
    vals = arr._present
    sts = arr.states
    mask = condition_fn(vals, sts)
    return np.where(mask)


def arr_count_present(arr):
    arr = _ensure_array(arr)
    return int(np.sum((arr._present > 0) & (arr._absent == 0) & ~arr._is_void))


def arr_present_mask(arr):
    arr = _ensure_array(arr)
    return (arr._present > 0) & (arr._absent == 0) & ~arr._is_void


def arr_absent_mask(arr):
    arr = _ensure_array(arr)
    return (arr._absent > 0) & (arr._present == 0) & ~arr._is_void


def arr_void_mask(arr):
    arr = _ensure_array(arr)
    return arr._is_void.copy()


def arr_trace(fn, start, end, order=None):
    from absence_calculator import trace as pt_trace
    results = pt_trace(fn, start, end, order=order)
    return AbsentArray(results)
