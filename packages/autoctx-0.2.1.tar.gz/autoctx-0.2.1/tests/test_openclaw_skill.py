"""Tests for AC-192: ClawHub skill wrapper for MTS scenarios and artifacts."""
from __future__ import annotations

import json
from typing import Any
from unittest.mock import MagicMock, patch

import pytest
from pydantic import ValidationError

from autocontext.openclaw.models import (
    ArtifactSummary,
    EvaluationResult,
    ScenarioInfo,
    ScenarioRecommendation,
    SkillManifest,
)
from autocontext.openclaw.skill import MtsSkillWrapper
from autocontext.scenarios.agent_task import AgentTaskInterface, AgentTaskResult
from autocontext.scenarios.base import Observation, Result, ScenarioInterface
from autocontext.scenarios.simulation import (
    ActionResult,
    ActionSpec,
    EnvironmentSpec,
    SimulationInterface,
    SimulationResult,
)

_REG = "autocontext.openclaw.skill.SCENARIO_REGISTRY"


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


class _GameScenario(ScenarioInterface):
    name = "grid_ctf"

    def describe_rules(self) -> str:
        return "Capture the flag on a grid."

    def describe_strategy_interface(self) -> str:
        return '{"aggression": float, "defense": float}'

    def describe_evaluation_criteria(self) -> str:
        return "Score = captures + survival"

    def initial_state(self, seed: int | None = None) -> dict[str, Any]:
        return {}

    def get_observation(self, state: Any, player_id: str) -> Observation:
        return Observation(narrative="observe")

    def validate_actions(self, state: Any, player_id: str, actions: Any) -> tuple[bool, str]:
        return True, ""

    def step(self, state: Any, actions: Any) -> dict[str, Any]:
        return {"terminal": True}

    def is_terminal(self, state: Any) -> bool:
        return True

    def get_result(self, state: Any) -> Result:
        return Result(score=1.0, summary="ok")

    def replay_to_narrative(self, replay: list[dict[str, Any]]) -> str:
        return ""

    def render_frame(self, state: Any) -> dict[str, Any]:
        return {}


class _TaskScenario(AgentTaskInterface):
    def describe_task(self) -> str:
        return "Write a summary of the document."

    def get_task_prompt(self, state: dict) -> str:
        return "Summarize the following..."

    def evaluate_output(
        self,
        output: str,
        state: dict,
        reference_context: str | None = None,
        required_concepts: list[str] | None = None,
        calibration_examples: list[dict[Any, Any]] | None = None,
        pinned_dimensions: list[str] | None = None,
    ) -> AgentTaskResult:
        return AgentTaskResult(score=0.8, reasoning="ok")

    def get_rubric(self) -> str:
        return "Clarity, completeness, accuracy"

    def initial_state(self, seed: int | None = None) -> dict:
        return {}


class _SimulationScenario(SimulationInterface):
    name = "travel_workflow"

    def describe_scenario(self) -> str:
        return "Run a stateful workflow simulation."

    def describe_environment(self) -> EnvironmentSpec:
        return EnvironmentSpec(
            name="travel",
            description="travel workflow",
            available_actions=[ActionSpec(name="noop", description="noop", parameters={})],
            initial_state_description="empty",
            success_criteria=["done"],
        )

    def initial_state(self, seed: int | None = None) -> dict[str, Any]:
        return {"step": 0}

    def get_available_actions(self, state: dict[str, Any]) -> list[ActionSpec]:
        return [ActionSpec(name="noop", description="noop", parameters={})]

    def execute_action(self, state: dict[str, Any], action: Any) -> tuple[ActionResult, dict[str, Any]]:
        return ActionResult(success=True, output="ok", state_changes={}), {"step": 1}

    def is_terminal(self, state: Any) -> bool:
        return True

    def evaluate_trace(self, trace: Any, final_state: dict[str, Any]) -> SimulationResult:
        return SimulationResult(
            score=1.0,
            reasoning="ok",
            dimension_scores={},
            workflow_complete=True,
            actions_taken=1,
            actions_successful=1,
        )

    def get_rubric(self) -> str:
        return "Score action ordering and recovery."


def _game() -> _GameScenario:
    return _GameScenario()


def _task() -> _TaskScenario:
    return _TaskScenario()


def _simulation() -> _SimulationScenario:
    return _SimulationScenario()


def _ctx() -> MagicMock:
    ctx = MagicMock()
    ctx.sqlite = MagicMock()
    ctx.artifacts = MagicMock()
    ctx.settings = MagicMock()
    return ctx


@pytest.fixture()
def reg() -> dict[str, Any]:
    return {
        "grid_ctf": lambda: _game(),
        "summarize_doc": lambda: _task(),
        "travel_workflow": lambda: _simulation(),
    }


# ---------------------------------------------------------------------------
# TestModels
# ---------------------------------------------------------------------------


class TestModels:
    def test_scenario_info_minimal(self) -> None:
        info = ScenarioInfo(
            name="grid_ctf", display_name="Grid CTF",
            scenario_type="parametric", description="Capture flags", strategy_interface="{}",
        )
        assert info.name == "grid_ctf"
        assert info.scenario_type == "parametric"

    def test_scenario_info_rejects_bad_type(self) -> None:
        with pytest.raises(ValidationError):
            ScenarioInfo(
                name="x", display_name="X", scenario_type="bad_type",  # type: ignore[arg-type]
                description="", strategy_interface="",
            )

    def test_scenario_info_accepts_simulation_type(self) -> None:
        info = ScenarioInfo(
            name="travel_workflow",
            display_name="Travel Workflow",
            scenario_type="simulation",
            description="Stateful workflow simulation",
            strategy_interface="{}",
        )
        assert info.scenario_type == "simulation"

    def test_evaluation_result_defaults(self) -> None:
        r = EvaluationResult(scenario_name="grid_ctf", strategy={"a": 1}, valid=True)
        assert r.scores == []
        assert r.mean_score == 0.0
        assert r.harness_passed is None

    def test_artifact_summary_validation(self) -> None:
        s = ArtifactSummary(id="abc", name="bounds", artifact_type="harness", scenario="grid_ctf", version=1)
        assert s.tags == []
        assert s.created_at == ""

    def test_skill_manifest_roundtrip(self) -> None:
        m = SkillManifest(
            version="0.1.0", description="test",
            scenarios=[ScenarioInfo(
                name="grid_ctf", display_name="Grid CTF",
                scenario_type="parametric", description="Flags", strategy_interface="{}",
            )],
            mcp_tools=["mts_list_scenarios"],
        )
        data = json.loads(m.model_dump_json())
        restored = SkillManifest.model_validate(data)
        assert restored.name == "autocontext"
        assert len(restored.scenarios) == 1

    def test_scenario_recommendation_fields(self) -> None:
        rec = ScenarioRecommendation(
            scenario_name="grid_ctf", confidence=0.85, reasoning="match", alternatives=[],
        )
        assert rec.confidence == 0.85


# ---------------------------------------------------------------------------
# TestSkillManifest
# ---------------------------------------------------------------------------


class TestSkillManifest:
    def test_manifest_has_version_and_name(self, reg: dict[str, Any]) -> None:
        with patch(_REG, reg):
            m = MtsSkillWrapper(_ctx()).manifest()
        assert m.name == "autocontext"
        assert m.version != ""
        assert "scenario_evaluation" in m.capabilities

    def test_manifest_lists_scenarios_with_types(self, reg: dict[str, Any]) -> None:
        with patch(_REG, reg):
            m = MtsSkillWrapper(_ctx()).manifest()
        names = {s.name for s in m.scenarios}
        assert "grid_ctf" in names
        assert "summarize_doc" in names
        assert "travel_workflow" in names
        assert next(s for s in m.scenarios if s.name == "grid_ctf").scenario_type == "parametric"
        assert next(s for s in m.scenarios if s.name == "summarize_doc").scenario_type == "agent_task"
        assert next(s for s in m.scenarios if s.name == "travel_workflow").scenario_type == "simulation"

    def test_manifest_includes_mcp_tools(self, reg: dict[str, Any]) -> None:
        with patch(_REG, reg):
            m = MtsSkillWrapper(_ctx()).manifest()
        assert len(m.mcp_tools) > 0
        assert "mts_list_scenarios" in m.mcp_tools

    def test_manifest_game_has_strategy_interface(self, reg: dict[str, Any]) -> None:
        with patch(_REG, reg):
            m = MtsSkillWrapper(_ctx()).manifest()
        game = next(s for s in m.scenarios if s.name == "grid_ctf")
        assert "aggression" in game.strategy_interface

    def test_manifest_empty_registry(self) -> None:
        with patch(_REG, {}):
            m = MtsSkillWrapper(_ctx()).manifest()
        assert m.scenarios == []


# ---------------------------------------------------------------------------
# TestDiscoverScenarios
# ---------------------------------------------------------------------------


class TestDiscoverScenarios:
    def test_all_scenarios_when_no_query(self, reg: dict[str, Any]) -> None:
        with patch(_REG, reg):
            results = MtsSkillWrapper(_ctx()).discover_scenarios()
        assert len(results) == 3

    def test_results_have_correct_types(self, reg: dict[str, Any]) -> None:
        with patch(_REG, reg):
            results = MtsSkillWrapper(_ctx()).discover_scenarios()
        types = {r.scenario_type for r in results}
        assert "parametric" in types
        assert "agent_task" in types
        assert "simulation" in types

    def test_query_filters_by_relevance(self, reg: dict[str, Any]) -> None:
        with patch(_REG, reg), \
             patch("autocontext.openclaw.skill.search_strategies") as mock_search:
            mock_search.return_value = [MagicMock(scenario_name="grid_ctf", relevance_score=0.8)]
            results = MtsSkillWrapper(_ctx()).discover_scenarios(query="grid capture flag")
        assert results[0].name == "grid_ctf"

    def test_query_ranks_unsolved_registry_scenarios(self, reg: dict[str, Any]) -> None:
        with patch(_REG, reg), \
             patch("autocontext.openclaw.skill.search_strategies") as mock_search:
            mock_search.return_value = []
            results = MtsSkillWrapper(_ctx()).discover_scenarios(query="summary document writing")
        assert results[0].name == "summarize_doc"

    def test_query_no_match_returns_all(self, reg: dict[str, Any]) -> None:
        with patch(_REG, reg), \
             patch("autocontext.openclaw.skill.search_strategies") as mock_search:
            mock_search.return_value = []
            results = MtsSkillWrapper(_ctx()).discover_scenarios(query="zzz_unknown")
        assert len(results) == 3


# ---------------------------------------------------------------------------
# TestSelectScenario
# ---------------------------------------------------------------------------


class TestSelectScenario:
    def test_returns_best_match(self, reg: dict[str, Any]) -> None:
        with patch(_REG, reg), \
             patch("autocontext.openclaw.skill.search_strategies") as mock_search:
            mock_search.return_value = [
                MagicMock(scenario_name="grid_ctf", relevance_score=0.9, match_reason="'grid' in name"),
            ]
            rec = MtsSkillWrapper(_ctx()).select_scenario("grid based game")
        assert rec.scenario_name == "grid_ctf"
        assert rec.confidence > 0

    def test_alternatives_populated(self, reg: dict[str, Any]) -> None:
        with patch(_REG, reg), \
             patch("autocontext.openclaw.skill.search_strategies") as mock_search:
            mock_search.return_value = [
                MagicMock(scenario_name="grid_ctf", relevance_score=0.9, match_reason="match"),
                MagicMock(scenario_name="summarize_doc", relevance_score=0.3, match_reason="match"),
            ]
            rec = MtsSkillWrapper(_ctx()).select_scenario("grid based game")
        assert rec.scenario_name == "grid_ctf"
        assert len(rec.alternatives) >= 1

    def test_fallback_when_no_results(self, reg: dict[str, Any]) -> None:
        with patch(_REG, reg), \
             patch("autocontext.openclaw.skill.search_strategies") as mock_search:
            mock_search.return_value = []
            rec = MtsSkillWrapper(_ctx()).select_scenario("something unknown")
        assert rec.scenario_name in ("grid_ctf", "summarize_doc")
        assert rec.confidence == 0.0

    def test_confidence_from_relevance(self, reg: dict[str, Any]) -> None:
        with patch(_REG, reg), \
             patch("autocontext.openclaw.skill.search_strategies") as mock_search:
            mock_search.return_value = [
                MagicMock(scenario_name="grid_ctf", relevance_score=0.75, match_reason="keyword"),
            ]
            rec = MtsSkillWrapper(_ctx()).select_scenario("grid")
        assert rec.confidence == pytest.approx(0.75)

    def test_select_scenario_uses_registry_ranking_when_search_index_empty(self, reg: dict[str, Any]) -> None:
        with patch(_REG, reg), \
             patch("autocontext.openclaw.skill.search_strategies") as mock_search:
            mock_search.return_value = []
            rec = MtsSkillWrapper(_ctx()).select_scenario("write a summary of a document")
        assert rec.scenario_name == "summarize_doc"
        assert rec.confidence > 0.0


# ---------------------------------------------------------------------------
# TestEvaluate
# ---------------------------------------------------------------------------


class TestEvaluate:
    def test_valid_strategy_returns_scores(self, reg: dict[str, Any]) -> None:
        with patch(_REG, reg), \
             patch("autocontext.openclaw.skill.validate_strategy_against_harness") as mv, \
             patch("autocontext.openclaw.skill.evaluate_strategy") as me:
            mv.return_value = {"valid": True, "reason": "ok", "harness_passed": True, "harness_errors": []}
            me.return_value = {"scores": [0.7, 0.8, 0.9], "mean_score": 0.8, "best_score": 0.9}
            result = MtsSkillWrapper(_ctx()).evaluate("grid_ctf", {"aggression": 0.5})
        assert result.valid is True
        assert result.mean_score == pytest.approx(0.8)
        assert result.best_score == pytest.approx(0.9)
        assert result.scores == [0.7, 0.8, 0.9]

    def test_invalid_strategy(self, reg: dict[str, Any]) -> None:
        with patch(_REG, reg), \
             patch("autocontext.openclaw.skill.validate_strategy_against_harness") as mv:
            mv.return_value = {
                "valid": False, "reason": "aggression out of range",
                "harness_passed": None, "harness_errors": [],
            }
            result = MtsSkillWrapper(_ctx()).evaluate("grid_ctf", {"aggression": 99.0})
        assert result.valid is False
        assert "aggression" in result.validation_errors[0]
        assert result.scores == []

    def test_harness_results_included(self, reg: dict[str, Any]) -> None:
        with patch(_REG, reg), \
             patch("autocontext.openclaw.skill.validate_strategy_against_harness") as mv, \
             patch("autocontext.openclaw.skill.evaluate_strategy") as me:
            mv.return_value = {
                "valid": True, "reason": "ok",
                "harness_passed": False, "harness_errors": ["bounds_check failed"],
            }
            me.return_value = {"scores": [0.5], "mean_score": 0.5, "best_score": 0.5}
            result = MtsSkillWrapper(_ctx()).evaluate("grid_ctf", {"aggression": 0.5})
        assert result.harness_passed is False
        assert "bounds_check failed" in result.harness_errors

    def test_unknown_scenario_error(self) -> None:
        with patch(_REG, {}):
            result = MtsSkillWrapper(_ctx()).evaluate("nonexistent", {"a": 1})
        assert result.valid is False
        assert any("not found" in e.lower() for e in result.validation_errors)

    def test_agent_task_evaluation_returns_explicit_error(self, reg: dict[str, Any]) -> None:
        with patch(_REG, reg):
            result = MtsSkillWrapper(_ctx()).evaluate("summarize_doc", {"output": "summary"})
        assert result.valid is False
        assert any("agent task" in e.lower() for e in result.validation_errors)

    def test_result_has_all_fields(self, reg: dict[str, Any]) -> None:
        with patch(_REG, reg), \
             patch("autocontext.openclaw.skill.validate_strategy_against_harness") as mv, \
             patch("autocontext.openclaw.skill.evaluate_strategy") as me:
            mv.return_value = {"valid": True, "reason": "", "harness_passed": True, "harness_errors": []}
            me.return_value = {"scores": [0.6], "mean_score": 0.6, "best_score": 0.6}
            result = MtsSkillWrapper(_ctx()).evaluate("grid_ctf", {"x": 1})
        assert isinstance(result, EvaluationResult)
        data = result.model_dump()
        assert "scenario_name" in data
        assert "scores" in data

    def test_evaluate_propagates_runtime_errors(self, reg: dict[str, Any]) -> None:
        with patch(_REG, reg), \
             patch("autocontext.openclaw.skill.validate_strategy_against_harness") as mv, \
             patch("autocontext.openclaw.skill.evaluate_strategy") as me:
            mv.return_value = {"valid": True, "reason": "", "harness_passed": True, "harness_errors": []}
            me.return_value = {"error": "evaluation failed"}
            result = MtsSkillWrapper(_ctx()).evaluate("grid_ctf", {"x": 1})
        assert result.valid is False
        assert result.validation_errors == ["evaluation failed"]


# ---------------------------------------------------------------------------
# TestDiscoverArtifacts
# ---------------------------------------------------------------------------


class TestDiscoverArtifacts:
    def test_returns_all_when_no_filters(self) -> None:
        with patch("autocontext.openclaw.skill.list_artifacts") as ml:
            ml.return_value = [
                {"id": "a1", "name": "bounds", "artifact_type": "harness", "scenario": "grid_ctf",
                 "version": 1, "tags": ["v1"], "created_at": "2026-01-01"},
                {"id": "a2", "name": "policy1", "artifact_type": "policy", "scenario": "othello",
                 "version": 2, "tags": [], "created_at": "2026-01-02"},
            ]
            results = MtsSkillWrapper(_ctx()).discover_artifacts()
        assert len(results) == 2
        assert all(isinstance(r, ArtifactSummary) for r in results)

    def test_passes_filters(self) -> None:
        with patch("autocontext.openclaw.skill.list_artifacts") as ml:
            ml.return_value = [
                {"id": "a1", "name": "bounds", "artifact_type": "harness", "scenario": "grid_ctf",
                 "version": 1, "tags": [], "created_at": ""},
            ]
            wrapper = MtsSkillWrapper(_ctx())
            wrapper.discover_artifacts(scenario="grid_ctf", artifact_type="harness")
            ml.assert_called_once_with(wrapper.ctx, scenario="grid_ctf", artifact_type="harness")

    def test_empty_list(self) -> None:
        with patch("autocontext.openclaw.skill.list_artifacts") as ml:
            ml.return_value = []
            results = MtsSkillWrapper(_ctx()).discover_artifacts()
        assert results == []
