from setuptools import setup, find_packages

setup(
    name="vecsai",
    version="0.1.1",
    author="Vecsai Team",
    packages=find_packages(),
    install_requires=[
        "requests>=2.25.1",
    ],
    description="Vecsai: vector db for everyone",
    long_description="A Python client for vecsai-db",
    python_requires='>=3.6',
)