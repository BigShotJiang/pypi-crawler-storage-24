# agentrace-ai

Lightweight OpenTelemetry-native tracing for LLM and AI agent applications.

```bash
pip install agentrace-ai
```

## Quick Start

```python
import agentrace
from agentrace import trace_llm, trace_tool, trace_agent

agentrace.init(service_name="my-agent")

@trace_tool(tool_name="search")
def search(query):
    return ["result1", "result2"]

@trace_llm(model="gpt-4o")
def call_llm(messages):
    return client.chat.completions.create(model="gpt-4o", messages=messages)

@trace_agent(name="research-agent")
def run(question):
    results = search(question)
    return call_llm([{"role": "user", "content": str(results)}])

run("What is OpenTelemetry?")
agentrace.shutdown()
```

## Features

- **Decorators**: `@observe`, `@trace_llm`, `@trace_tool`, `@trace_agent`, `@trace_chain`, `@trace_retrieval`
- **Context Managers**: `trace_span()`, `trace_llm_call()` with `.record_response()`
- **Session Tracking**: `set_session()`, `set_user()`, `session_context()`
- **Cost Tracking**: Auto-calculates cost from token usage for OpenAI and Anthropic models
- **Auto-Instrumentation**: Monkey-patch OpenAI/Anthropic SDKs with one line
- **LangChain Callback**: `AgentraceCallbackHandler` for LangChain/LangGraph
- **Export Anywhere**: Console, OTLP (gRPC/HTTP), or build your own exporter
- **Lightweight**: Only 2 dependencies (opentelemetry-api + opentelemetry-sdk)

## Integrations

```bash
pip install agentrace-ai[openai]      # OpenAI auto-instrumentation
pip install agentrace-ai[anthropic]   # Anthropic auto-instrumentation
pip install agentrace-ai[langchain]   # LangChain callback handler
pip install agentrace-ai[otlp]       # OTLP exporter (Jaeger, Grafana, etc.)
pip install agentrace-ai[all]        # Everything
```

### Auto-instrument OpenAI

```python
from agentrace.integrations import openai_patch
openai_patch.instrument()
# All OpenAI calls are now traced automatically
```

### Auto-instrument Anthropic

```python
from agentrace.integrations import anthropic_patch
anthropic_patch.instrument()
```

### LangChain / LangGraph

```python
from agentrace.integrations.langchain_cb import AgentraceCallbackHandler
chain.invoke({"input": "..."}, config={"callbacks": [AgentraceCallbackHandler()]})
```

## Export to OTLP (Jaeger, Grafana Tempo, etc.)

```python
agentrace.init(
    service_name="my-agent",
    exporters=["console", "otlp"],
    otlp_endpoint="http://localhost:4317",
)
```

## License

MIT
