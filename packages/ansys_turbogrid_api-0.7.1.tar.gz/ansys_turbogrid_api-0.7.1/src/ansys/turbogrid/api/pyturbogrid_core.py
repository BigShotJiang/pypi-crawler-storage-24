# Copyright (C) 2023 - 2026 ANSYS, Inc. and/or its affiliates.
# SPDX-FileCopyrightText: 2023 ANSYS, Inc. All rights reserved
# SPDX-License-Identifier: MIT
#
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import ast as ast
from enum import IntEnum
from typing import Optional

from ansys.turbogrid.api.CCL.ccl_object import CCLObject
from ansys.turbogrid.api.CCL.ccl_object_db import CCLObjectDB
from ansys.turbogrid.api.cueengine_core import _CUEEngineInterface

from .server_log_level import ServerLogLevel


class PyTurboGrid(_CUEEngineInterface):
    """
    This class enables you to launch, interact with, and quit, a session of TurboGrid.
    Refer to the :py:mod:`launcher` module to see how to create an instance of this class.
    """

    class TurboGridLocationType(IntEnum):
        """
        Specifies whether the PyTurboGrid class should launch TurboGrid from the given location, or connect to a running session of TurboGrid.
        :member-order: bysource
        """

        TURBOGRID_INSTALL = _CUEEngineInterface.AppLocationType.APP_INSTALL
        """
        Launch TurboGrid from the given location.
        """
        TURBOGRID_RUNNING_CONTAINER = _CUEEngineInterface.AppLocationType.APP_RUNNING_CONTAINER
        """
        Connect to a running session of TurboGrid using the given port.
        """
        TURBOGRID_ANSYS_LABS = _CUEEngineInterface.AppLocationType.APP_ANSYS_LABS
        """
        From within the Ansys Labs environment, launch TurboGrid.
        """

    class TurboGridLogLevel(IntEnum):
        """
        Controls which logging messages are reported. The higher values report the fewest messages.
        :member-order: bysource
        """

        CRITICAL = ServerLogLevel.CRITICAL._value_
        """
        Report critical errors only.
        """
        ERROR = ServerLogLevel.ERROR._value_
        """
        Report all errors.
        """
        WARNING = ServerLogLevel.WARNING._value_
        """
        Report all warnings and errors.
        """
        INFO = ServerLogLevel.INFO._value_
        """
        Report all information, warning and error messages.
        """
        NETWORK_DEBUG = ServerLogLevel.NETWORK_DEBUG._value_
        """
        Report extra information which should help with diagnosing connection errors.
        """
        DEBUG = ServerLogLevel.DEBUG._value_
        """
        Report the most detailed logging messages.
        """
        NOTSET = ServerLogLevel.NOTSET._value_
        """
        The log level has not been set; report all messages.
        """

    def __init__(
        self,
        socket_port: Optional[int],
        turbogrid_location_type: TurboGridLocationType,
        cfxtg_location,
        additional_args_str: Optional[str],
        additional_kw_args: Optional[dict],
        log_level=TurboGridLogLevel.INFO,
        host_ip: str = "127.0.0.1",
        pim_app_name: str = "turbogrid",
        pim_app_ver: str = "241",
        log_filename_suffix: str = "",
    ):

        if turbogrid_location_type == self.TurboGridLocationType.TURBOGRID_ANSYS_LABS:
            super().__init__(
                "TurboGrid",
                socket_port,
                _CUEEngineInterface.AppLocationType(int(turbogrid_location_type)),
                cfxtg_location,
                additional_args_str,
                additional_kw_args,
                ServerLogLevel(int(log_level)),
                host_ip,
                pim_app_name,
                pim_app_ver,
                log_filename_suffix,
            )
        else:
            super().__init__(
                "TurboGrid",
                socket_port,
                _CUEEngineInterface.AppLocationType(int(turbogrid_location_type)),
                cfxtg_location,
                additional_args_str,
                additional_kw_args,
                ServerLogLevel(int(log_level)),
                host_ip,
                "",
                "",
                log_filename_suffix,
            )

    # This destructor is not needed.
    # If it becomes needed in the future, make sure to forward the dtor call to the base class.
    # A weakref-finalize may also be needed in the same style as the base class.
    # def __del__(self):
    #     print(f"del {sys.getrefcount(self)=}")
    #     print("PyTurboGrid __del__")
    #     super(type(self), self).__del__()

    def get_hotfix_functions_dict(self):
        return {
            "23.2": """{
                "read_ndf": lambda self, ndffilename, cadfilename="", flowpath="", bladerow="", bladename="": self.perform_action(
                    "importndf",
                    f" ndf={ndffilename}, geom={cadfilename}, flowpath={flowpath}, bladerow={bladerow}, bladename={bladename}",
                ),
                "save_mesh": lambda self, filename, onefile="true", onedomain="true": self.perform_action(
                    "savemesh", f" filename={filename}, onefile={onefile}, onedomain={onedomain}"
                ),
                "read_tginit": lambda self, path, bladerow="": self.perform_action(
                    "readtginit",
                    f" path={path}, bladerow={bladerow}",
                ),
                'save_mesh': lambda self, filename, onefile = True, onedomain = True, addsecondary = True : self.perform_action(
                    'savemesh',
                    f' filename = {filename}, onefile = {onefile}, onedomain = {onedomain}, addsecondary = {addsecondary},'
                    f' solver = {"cgns" if (ext := filename.split(".")[-1].lower()) == "cgns" else "cfx5"}'
                ),
            }""",
            "24.1": """{
                "read_tginit": lambda self, path, bladerow="": self.perform_action(
                    "readtginit",
                    f" path={path}, bladerow={bladerow}",
                ),
                'save_mesh': lambda self, filename, onefile = True, onedomain = True, addsecondary = True : self.perform_action(
                    'savemesh',
                    f' filename = {filename}, onefile = {onefile}, onedomain = {onedomain}, addsecondary = {addsecondary},'
                    f' solver = {"cgns" if (ext := filename.split(".")[-1].lower()) == "cgns" else "cfx5"}'
                ),
            }""",
            "24.2": """{
                "read_tginit": lambda self, path, bladerow="": self.perform_action(
                    "readtginit",
                    f" path={path}, bladerow={bladerow}",
                ),
                'save_mesh': lambda self, filename, onefile = True, onedomain = True, addsecondary = True : self.perform_action(
                    'savemesh',
                    f' filename = {filename}, onefile = {onefile}, onedomain = {onedomain}, addsecondary = {addsecondary},'
                    f' solver = {"cgns" if (ext := filename.split(".")[-1].lower()) == "cgns" else "cfx5"}'
                ),
            }""",
            "25.1": """{
                "read_tginit": lambda self, path, bladerow="": self.perform_action(
                    "readtginit",
                    f" path={path}, bladerow={bladerow}",
                ),
                'save_mesh': lambda self, filename, onefile = True, onedomain = True, addsecondary = True : self.perform_action(
                    'savemesh',
                    f' filename = {filename}, onefile = {onefile}, onedomain = {onedomain}, addsecondary = {addsecondary},'
                    f' solver = {"cgns" if (ext := filename.split(".")[-1].lower()) == "cgns" else "cfx5"}'
                ),
            }""",
            "25.2": """{
                'save_mesh': lambda self, filename, onefile = True, onedomain = True, addsecondary = True : self.perform_action(
                    'savemesh',
                    f' filename = {filename}, onefile = {onefile}, onedomain = {onedomain}, addsecondary = {addsecondary},'
                    f' solver = {"cgns" if (ext := filename.split(".")[-1].lower()) == "cgns" else "cfx5"}'
                ),
                'set_inlet_hub_axial_position': lambda self, axial_hub_location: (
                    self.set_obj_param("/GEOMETRY/INLET", f"Opening Mode = Points"),
                    self.set_obj_param(
                        "/GEOMETRY/INLET/GEO POINT:Low Hub Point",
                        f"AR Location Method = Set A, Requested ART ={axial_hub_location} " r"[m]\\,0.0 [m]\\,0.0 [deg]",
                    ),
                ),
                'set_outlet_hub_axial_position': lambda self, axial_hub_location: (
                    self.set_obj_param("/GEOMETRY/OUTLET", f"Opening Mode = Points"),
                    self.set_obj_param(
                        "/GEOMETRY/OUTLET/GEO POINT:Low Hub Point",
                        f"AR Location Method = Set A, Requested ART ={axial_hub_location} " r"[m]\\,0.0 [m]\\,0.0 [deg]",
                    ),
                ),
                'set_inlet_shroud_axial_position': lambda self, axial_shroud_location: (
                    self.set_obj_param("/GEOMETRY/INLET", f"Opening Mode = Points"),
                    self.set_obj_param(
                        "/GEOMETRY/INLET/GEO POINT:Low Shroud Point",
                        f"AR Location Method = Set A, Requested ART ={axial_shroud_location} " r"[m]\\,0.0 [m]\\,0.0 [deg]",
                    ),
                ),
                'set_outlet_shroud_axial_position': lambda self, axial_shroud_location: (
                    self.set_obj_param("/GEOMETRY/OUTLET", f"Opening Mode = Points"),
                    self.set_obj_param(
                        "/GEOMETRY/OUTLET/GEO POINT:Low Shroud Point",
                        f"AR Location Method = Set A, Requested ART ={axial_shroud_location} " r"[m]\\,0.0 [m]\\,0.0 [deg]",
                    ),
                ),
            }""",
            "26.1": """{
                'save_mesh': lambda self, filename, onefile = True, onedomain = True, addsecondary = True : self.perform_action(
                    'savemesh',
                    f' filename = {filename}, onefile = {onefile}, onedomain = {onedomain}, addsecondary = {addsecondary},'
                    f' solver = {"cgns" if (ext := filename.split(".")[-1].lower()) == "cgns" else "cfx5"}'
                ),
                'set_inlet_hub_axial_position': lambda self, axial_hub_location: (
                    self.set_obj_param("/GEOMETRY/INLET", f"Opening Mode = Points"),
                    self.set_obj_param(
                        "/GEOMETRY/INLET/GEO POINT:Low Hub Point",
                        f"AR Location Method = Set A, Requested ART ={axial_hub_location} " r"[m]\\,0.0 [m]\\,0.0 [deg]",
                    ),
                ),
                'set_outlet_hub_axial_position': lambda self, axial_hub_location: (
                    self.set_obj_param("/GEOMETRY/OUTLET", f"Opening Mode = Points"),
                    self.set_obj_param(
                        "/GEOMETRY/OUTLET/GEO POINT:Low Hub Point",
                        f"AR Location Method = Set A, Requested ART ={axial_hub_location} " r"[m]\\,0.0 [m]\\,0.0 [deg]",
                    ),
                ),
                'set_inlet_shroud_axial_position': lambda self, axial_shroud_location: (
                    self.set_obj_param("/GEOMETRY/INLET", f"Opening Mode = Points"),
                    self.set_obj_param(
                        "/GEOMETRY/INLET/GEO POINT:Low Shroud Point",
                        f"AR Location Method = Set A, Requested ART ={axial_shroud_location} " r"[m]\\,0.0 [m]\\,0.0 [deg]",
                    ),
                ),
                'set_outlet_shroud_axial_position': lambda self, axial_shroud_location: (
                    self.set_obj_param("/GEOMETRY/OUTLET", f"Opening Mode = Points"),
                    self.set_obj_param(
                        "/GEOMETRY/OUTLET/GEO POINT:Low Shroud Point",
                        f"AR Location Method = Set A, Requested ART ={axial_shroud_location} " r"[m]\\,0.0 [m]\\,0.0 [deg]",
                    ),
                ),
            }""",
            "27.1": """{
                'save_mesh': lambda self, filename, onefile = True, onedomain = True, addsecondary = True : self.perform_action(
                    'savemesh',
                    f' filename = {filename}, onefile = {onefile}, onedomain = {onedomain}, addsecondary = {addsecondary},'
                    f' solver = {"cgns" if (ext := filename.split(".")[-1].lower()) == "cgns" else "cfx5"}'
                ),
                'set_inlet_hub_axial_position': lambda self, axial_hub_location: (
                    self.set_obj_param("/GEOMETRY/INLET", f"Opening Mode = Points"),
                    self.set_obj_param(
                        "/GEOMETRY/INLET/GEO POINT:Low Hub Point",
                        f"AR Location Method = Set A, Requested ART ={axial_hub_location} " r"[m]\\,0.0 [m]\\,0.0 [deg]",
                    ),
                ),
                'set_outlet_hub_axial_position': lambda self, axial_hub_location: (
                    self.set_obj_param("/GEOMETRY/OUTLET", f"Opening Mode = Points"),
                    self.set_obj_param(
                        "/GEOMETRY/OUTLET/GEO POINT:Low Hub Point",
                        f"AR Location Method = Set A, Requested ART ={axial_hub_location} " r"[m]\\,0.0 [m]\\,0.0 [deg]",
                    ),
                ),
                'set_inlet_shroud_axial_position': lambda self, axial_shroud_location: (
                    self.set_obj_param("/GEOMETRY/INLET", f"Opening Mode = Points"),
                    self.set_obj_param(
                        "/GEOMETRY/INLET/GEO POINT:Low Shroud Point",
                        f"AR Location Method = Set A, Requested ART ={axial_shroud_location} " r"[m]\\,0.0 [m]\\,0.0 [deg]",
                    ),
                ),
                'set_outlet_shroud_axial_position': lambda self, axial_shroud_location: (
                    self.set_obj_param("/GEOMETRY/OUTLET", f"Opening Mode = Points"),
                    self.set_obj_param(
                        "/GEOMETRY/OUTLET/GEO POINT:Low Shroud Point",
                        f"AR Location Method = Set A, Requested ART ={axial_shroud_location} " r"[m]\\,0.0 [m]\\,0.0 [deg]",
                    ),
                ),
            }""",
            "26.2": """{}""",
            "27.1": """{}""",
        }

    def get_app_version(self) -> str:
        object_db = CCLObjectDB(self)
        command_file: CCLObject = object_db.get_object_by_type_and_name("COMMAND FILE", None)
        if command_file is not None:
            param_value = command_file.get_value("TurboGrid Version")
            if param_value is not None:
                return param_value
        return ""

    # Adds a secondary flow path to a normal (non SaaS) TG session.
    # The families must exist in that TG session's CAD
    def addSecondaryFlowPath(
        self,
        name: str,
        wall_families: list[str],
        hub_interface_families: list[str] = [],
        shroud_interface_families: list[str] = [],
    ) -> dict[str, any]:

        self.perform_action(
            "addsecondarypassage",
            f"name={name}, "
            f"wallfamilies={':'.join(wall_families)}, "
            f"hubinterfacefamilies={':'.join(hub_interface_families)}, "
            f"shroudinterfacefamilies={':'.join(shroud_interface_families)}, "
            f"autoregions=true, "
            f"includemesh=false, ",
        ),

    # -> list[pv.PolyData]
    def getBoundaryGeometry(self, prefix_string: str = "") -> list[any]:

        import numpy as np
        import pyvista as pv

        boundary_meshes: list[pv.PolyData] = []
        mesh_boundary_dict = eval(self.perform_query("Get Mesh Boundaries"))
        for boundary_name, boundary_dict in mesh_boundary_dict.items():
            self.log_core(
                f"{boundary_name=}",
                self.TurboGridLogLevel.DEBUG,
            )
            v_pos = ast.literal_eval(boundary_dict["vertex positions"])
            self.log_core(
                f"v_pos size {len(v_pos)}",
                self.TurboGridLogLevel.DEBUG,
            )
            f_v = ast.literal_eval(boundary_dict["face vertices"])
            self.log_core(
                f"f_v size {len(f_v)}",
                self.TurboGridLogLevel.DEBUG,
            )
            points = np.array(v_pos)
            faces = np.array(f_v)
            boundary_meshes.append(pv.PolyData(points, faces, deep=True))
        return boundary_meshes

    def processTGInitTopology(
        self, transformIOToLines: bool, tginit_topology: dict[str, any], tginit_topo_dict
    ):

        import numpy as np
        import pyvista as pv

        # This will have the form
        # {'A_Rotor_Inlet': {'Flowpath Space': 'Inlet',
        #                    'face vertices': '[(122,0,1,...,121)]', <--- Notice the single poly face (2d face)
        #                    'vertex positions': '[(0, 0.0374435, -0.0635),...,(0, 0.0374558, -0.061892) ]'},
        #  'A_Stator_Inlet': {'Flowpath Space': 'Inlet',
        #                     'face vertices': '[ (22,0,...,21 ) ]',
        #                     'vertex positions': '[(0, 0.0330378, 0.0156358),...,(0, 0.0330378, 0.0205552) ]'},
        #  'B_Rotor_Outlet': {'Flowpath Space': 'Outlet',
        #                     'face vertices': '[ (43,0,1,...,42 ) ]',
        #                     'vertex positions': '[(0, 0.0330378, 0.0106719),...,(0, 0.0330378, 0.0156358) ]'},
        #  'B_Stator_Outlet': {'Flowpath Space': 'Outlet',
        #                      'face vertices': '[ (5,0,1,2,3,4 ) ]',
        #                      'vertex positions': '[(0, 0.0330378, 0.0455929),(0, 0.01778, 0.0400302),(0, 0.01778, 0.0424434),(0, 0.01778, 0.06604),(0, 0.0330378, 0.06604) ]'},
        #  'Rotor': {'Display Surfaces': {'FACE224': {'face vertices': '[ 3, 0,1,2, 3, 3,2,4, ... , 3, 994,988,996 ]', <--- Notice the many triangles (3d faces)
        #                                             'vertex positions': '[(0.00488485, 0.0123055, -0.00986106),...,(-0.0138183, 0.0288369, 0.0101528) ]'},
        #            'Flowpath Space': 'Blade',
        #            'face vertices': '[ (65,0,1,2,...,62,63,64) ]',
        #            'vertex positions': '[(0, 0.0330378, -0.00852053),...,(0, 0.0330378, 0.0106719) ]'},
        # {'sfp_a': {'Flowpath Space': 'Secondary Flow Path',
        #                    'vertex positions': '[(0, 0.0374435, -0.0635),...,(0, 0.0374558, -0.061892) ]'},
        for br_name, br_dict in tginit_topo_dict.items():
            v_pos = ast.literal_eval(br_dict["vertex positions"])
            f_v = ast.literal_eval(br_dict["face vertices"])
            points = np.array(v_pos)
            faces = np.array(f_v)
            if transformIOToLines and (
                br_dict["Flowpath Space"] == "Inlet" or br_dict["Flowpath Space"] == "Outlet"
            ):
                # Create 2-vertex faces out of the face vertex data
                face_vertices = []
                for i in range(0, faces.size - 2):
                    face_vertices.append([2, i, i + 1])

                face_vertices.append([2, faces.size - 2, 0])
                line_faces = pv.PolyData(points, np.array(face_vertices), deep=True)
                tginit_topology["line_faces"][br_name] = line_faces
            else:
                # if replace_faces_with_display_surfaces and "Display Surfaces" in br_dict:
                if "Display Surfaces" in br_dict:
                    # Find 'Display Surfaces' in the dict for this blade row.
                    # The triangulated faces will be there
                    display_surfaces = br_dict["Display Surfaces"]
                    polyfaces: list[pv.PolyData] = []
                    for surf_name in display_surfaces:
                        surf = display_surfaces[surf_name]
                        surf_v_pos = ast.literal_eval(surf["vertex positions"])
                        surf_f_v = ast.literal_eval(surf["face vertices"])
                        surf_points = np.array(surf_v_pos)
                        surf_faces = np.array(surf_f_v)
                        polyfaces.append(pv.PolyData(surf_points, surf_faces, deep=True))

                    tginit_topology["3d"][br_name] = pv.merge(polyfaces)

                polyface = pv.PolyData(points, faces, deep=True)

                # If pyvista's triangulate stops working, we'll need another approach.
                # pyvista's delaunay2D was not working for even the first case I tried.
                # just sending the polyface kinda works but the resulting triangle fan (for some rederers, esp webui) may not represent the geometry well.
                # pyvista seems to play nice with the polyface, likely it's using 'triangulate'.
                if br_dict["Flowpath Space"] == "Secondary Flow Path":
                    tginit_topology["secondary_fp"][br_name] = polyface.triangulate()
                else:
                    tginit_topology["2d"][br_name] = polyface.triangulate()
        # t3 = time.time()
        # print(f"getTGInitTopology profiling: {t1-t0:.2f} {t2-t1:.2f} {t3-t2:.2f} seconds")

    def getTGInitTopologyView(
        self,
        tginit_path: str,
        transformIOToLines: bool = False,
        name: str = "machine_topo",
    ) -> dict[str, any]:

        # import time
        from pprint import pformat

        tginit_topology: dict[str, any] = {"2d": {}, "3d": {}, "line_faces": {}, "secondary_fp": {}}
        result = self.perform_query(
            f"SaaS Get TGInit Topology View, path={tginit_path}, name={name}"
        )
        self.log_core(
            pformat(result, width=200, compact=True),
            self.TurboGridLogLevel.DEBUG,
        )
        tginit_topo_dict = eval(result)
        self.processTGInitTopology(transformIOToLines, tginit_topology, tginit_topo_dict)

        return tginit_topology

    def getTGInitTopology(
        self,
        tginit_path: str,
        transformIOToLines: bool = False,
    ) -> dict[str, any]:

        # import time
        from pprint import pformat

        tginit_topology: dict[str, any] = {"2d": {}, "3d": {}, "line_faces": {}, "secondary_fp": {}}
        result = self.perform_query(f"SaaS Get TGInit Topology, path={tginit_path}")
        self.log_core(
            pformat(result, width=200, compact=True),
            self.TurboGridLogLevel.DEBUG,
        )
        # t1 = time.time()
        # from pprint import pprint

        # print(f"getTGInitTopology result\n {result}")
        tginit_topo_dict = eval(result)

        # pprint(tginit_topo_dict)
        self.processTGInitTopology(transformIOToLines, tginit_topology, tginit_topo_dict)
        return tginit_topology

    def getTGInitContents(
        self,
        tginit_path: str,
    ) -> dict[str, any]:

        return ast.literal_eval(self.perform_query(f"Get TGInit Contents, path={tginit_path}"))

    # SaaS
    def generateThetaMesh(
        self,
        name: str,
        axis: str,
        cad_path: str,
        wall_families: list[str],
        hubinterfacefamilies: list[str] = [],
        shroudinterfacefamilies: list[str] = [],
        hubcurvefamily: str = "",
        shroudcurvefamily: str = "",
        units: str = "",
    ) -> dict[str, any]:

        self.perform_action(
            "saas_thetamesh",
            f"action=create, name={name}, axis={axis}, cadfile={cad_path}, "
            f"wallfamilies={':'.join(wall_families)}, "
            f"hubinterfacefamilies={':'.join(hubinterfacefamilies)}, "
            f"shroudinterfacefamilies={':'.join(shroudinterfacefamilies)}, "
            f"hubcurvefamily={hubcurvefamily}, "
            f"shroudcurvefamily={shroudcurvefamily},"
            f"units={units}",
        )

    # SaaS
    def deleteThetaMesh(self, name: str):

        self.perform_action("saas_thetamesh", f"action=delete, name={name}")

    def write_theta_mesh(self, name: str, filename_no_ext: str):
        self.perform_action(
            "saas_thetamesh", f"action=write, name = {name}, filenamenoext={filename_no_ext}"
        ),

    def getAvailableThetaMeshes(self) -> list[str]:
        import ast

        result = self.perform_query(f"SaaS Get Available SFPs")
        return ast.literal_eval(result)

    def getThetaMesh(self, name: str) -> list[any]:
        import ast

        import numpy as np
        import pyvista as pv

        result = self.perform_query(f"SaaS Get SFP Boundaries, sfpname={name}")
        sfp_topo_dict = eval(result)
        sfp_meshes: list[pv.PolyData] = []
        for sfp_name, sfp_dict in sfp_topo_dict.items():
            v_pos = ast.literal_eval(sfp_dict["vertex positions"])
            f_v = ast.literal_eval(sfp_dict["face vertices"])
            points = np.array(v_pos)
            faces = np.array(f_v)
            polyface = pv.PolyData(points, faces, deep=True)
            # sfp_meshes.append(polyface.triangulate())
            sfp_meshes.append(polyface)
        return sfp_meshes

    def getThetaMeshHistogram(self, sfp_name, variable: str) -> dict[str, any]:
        import ast

        return ast.literal_eval(
            self.perform_query(f"SaaS Get SFP Statistics, sfpname={sfp_name}, variable={variable}")
        )

    def evalCurveConstArclength(self, points, params) -> list[any]:
        import ast

        pt_list_as_str = "| ".join(f"({ ' '.join(map(str, pt)) })" for pt in points)
        params_as_str = "| ".join(str(p) for p in params)
        return ast.literal_eval(
            self.perform_query(
                f"SaaS Eval Curve Constant Arclength, points={pt_list_as_str}, params={params_as_str}"
            )
        )

    def getAvailableDomains(self) -> list[str]:
        object_db = CCLObjectDB(self)
        return [obj.get_name() for obj in object_db.get_objects_by_type("DOMAIN")]
