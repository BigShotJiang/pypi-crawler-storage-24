# Copyright (C) 2023 - 2026 ANSYS, Inc. and/or its affiliates.
# SPDX-FileCopyrightText: 2023 ANSYS, Inc. All rights reserved
# SPDX-License-Identifier: MIT
#
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from ansys.turbogrid.api import pyturbogrid_core


def add_engine_functions_for_doc():
    try:
        import os

        import sphinx

        sphinx_build = hasattr(sphinx, "application")
        if not sphinx_build:
            return

        socket_port = os.getenv("PYTURBOGRID_DOC_ENGINE_CONNECTION")
        if socket_port is None:
            return
        else:
            socket_port = int(socket_port)

        debug_output = os.getenv("PYTURBOGRID_DOC_ENGINE_DEBUG")

        print(f"Connecting to TurboGrid to get PyTurboGrid function documentation")

        tg = pyturbogrid_core.PyTurboGrid(
            socket_port=socket_port,
            turbogrid_location_type=pyturbogrid_core.PyTurboGrid.TurboGridLocationType.TURBOGRID_RUNNING_CONTAINER,
            cfxtg_location="",
            log_level=pyturbogrid_core.PyTurboGrid.TurboGridLogLevel.DEBUG,
            additional_args_str="",
            additional_kw_args={},
        )

        print(f"Connected to TurboGrid version {tg.get_version()}")

        functions = tg.query_functions()
        doc_strings = tg.query_doc_strings()
        doc_annotations = tg.query_doc_annotations()
        doc_defaults = tg.query_doc_defaults()

        if debug_output is not None:
            print(functions.keys())

        tg.quit()

        print(f"Got documentation for {len(functions)} functions from TurboGrid")

        for key, value in functions.items():
            tmp_func = value
            if key in doc_strings:
                tmp_func.__doc__ = doc_strings[key]
            else:
                continue
            if key in doc_annotations:
                tmp_func.__annotations__ = doc_annotations[key]
            if key in doc_defaults:
                tmp_func.__defaults__ = doc_defaults[key]
            setattr(pyturbogrid_core.PyTurboGrid, key, tmp_func)

    except Exception as e:
        print(f"Engine function documentation process failed:")
        print(e)
