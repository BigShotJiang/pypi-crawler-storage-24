import{b as r}from"./graph-D32J-mD5.js";var e=4;function a(o){return r(o,e)}export{a as c};
