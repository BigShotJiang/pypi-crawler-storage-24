import{ap as o,aq as n}from"./index-aZThev8k.js";const t=(a,r)=>o.lang.round(n.parse(a)[r]);export{t as c};
