from swane.nipype_pipeline.engine.CustomWorkflow import CustomWorkflow
from swane.nipype_pipeline.nodes.CustomDcm2niix import CustomDcm2niix
from swane.nipype_pipeline.nodes.ForceOrient import ForceOrient
from swane.nipype_pipeline.nodes.CropFov import CropFov
from swane.nipype_pipeline.nodes.N4BiasFieldCorrection import N4BiasFieldCorrection
from swane.nipype_pipeline.nodes.ZIntNorm import ZIntNorm
from swane.nipype_pipeline.nodes.utils import get_deskull_node
from configparser import SectionProxy
from nipype.interfaces.fsl import RobustFOV, ApplyMask
from nipype.interfaces.utility import IdentityInterface
from nipype import Node


def ref_workflow(
    name: str,
    dicom_dir: str,
    config: SectionProxy,
    synth_config: SectionProxy,
    base_dir: str = "/",
) -> CustomWorkflow:
    """
    T13D workflow to use as reference.

    Parameters
    ----------
    name : str
        The workflow name.
    dicom_dir : path
        The file path of the DICOM files.
    config: SectionProxy
        workflow settings.
    synth_config: SectionProxy
        Synth tools settings.
    base_dir : path, optional
        The base directory path relative to parent workflow. The default is "/".

    Input Node Fields
    ----------
    -

    Returns
    -------
    workflow : CustomWorkflow
        The T13D reference workflow.

    Output Node Fields
    ----------
    reference : path
        T13D.
    reference_brain : path
        Betted T13D.
    reference_mask : path
        Brain mask from T13D bet command.
    uncorrected_reference : path
        Uncorrected T13D.
    uncorrected_reference_brain : path
        Uncorrected betted T13D.

    """

    workflow = CustomWorkflow(name=name, base_dir=base_dir)

    # Output Node
    outputnode = Node(
        IdentityInterface(
            fields=[
                "reference",
                "reference_brain",
                "ref_mask",
                "uncorrected_reference",
                "uncorrected_reference_brain",
            ]
        ),
        name="outputnode",
    )

    # NODE 1: Conversion dicom -> nifti
    conversion = Node(CustomDcm2niix(), name="%s_conv" % name)
    conversion.inputs.source_dir = dicom_dir
    conversion.inputs.bids_format = False
    conversion.inputs.out_filename = "converted"
    conversion.inputs.name_conflicts = 1
    conversion.inputs.merge_imgs = 2

    # NODE 2: Orienting in radiological convention
    ref_reOrient = Node(ForceOrient(), name="%s_reOrient" % name)
    workflow.connect(conversion, "converted_files", ref_reOrient, "in_file")

    # NODE 3: Crop neck
    ref_robustfov = Node(RobustFOV(), name="%s_robustfov" % name)
    ref_robustfov.inputs.out_roi = "ref_robustfov.nii.gz"
    workflow.connect(ref_reOrient, "out_file", ref_robustfov, "in_file")

    # NODE 4: Crop FOV larger than 256mm for subsequent freesurfer
    ref_reScale = Node(CropFov(), name="%s_reScale" % name)
    ref_reScale.long_name = "Crop large FOV"
    ref_reScale.inputs.max_dim = 256
    ref_reScale.inputs.out_file = "ref_uncorrected.nii.gz"
    workflow.connect(ref_robustfov, "out_roi", ref_reScale, "in_file")

    # NODE 5: Scalp removal
    ref_deskull = get_deskull_node(
        name="ref_deskull_biased",
        use_synth=synth_config.getboolean_safe("strip"),
        mask=True,
        bet_thr=config.getfloat_safe("bet_thr"),
        bet_robust=True,
        bet_bias_correction=config.getboolean_safe("bet_bias_correction"),
        synth_exclude_csf=True,
    )
    workflow.connect(ref_reScale, "out_file", ref_deskull, "in_file")

    ref_bias_correction = Node(
        N4BiasFieldCorrection(), name="ref_bias_correction", mem_gb=2
    )
    ref_bias_correction.inputs.out_file = "ref.nii.gz"
    workflow.connect(ref_reScale, "out_file", ref_bias_correction, "in_file")
    workflow.connect(ref_deskull, "mask_file", ref_bias_correction, "mask_file")

    ref_corrected_deskull = Node(ApplyMask(), name="ref_corrected_deskull")
    ref_corrected_deskull.inputs.out_file = "ref_brain.nii.gz"
    workflow.connect(ref_bias_correction, "out_file", ref_corrected_deskull, "in_file")
    workflow.connect(ref_deskull, "mask_file", ref_corrected_deskull, "mask_file")

    workflow.connect(ref_bias_correction, "out_file", outputnode, "reference")
    workflow.connect(ref_corrected_deskull, "out_file", outputnode, "reference_brain")
    workflow.connect(ref_deskull, "mask_file", outputnode, "ref_mask")
    workflow.connect(ref_reScale, "out_file", outputnode, "uncorrected_reference")
    workflow.connect(ref_deskull, "out_file", outputnode, "uncorrected_reference_brain")

    return workflow
