"""FlameIQ CLI."""
