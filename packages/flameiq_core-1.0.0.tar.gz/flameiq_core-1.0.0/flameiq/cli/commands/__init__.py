"""FlameIQ CLI commands."""
