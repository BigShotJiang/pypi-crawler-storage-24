import json
from erclient import ERClient

er_client = ERClient(service_root="https://gundi-dev.staging.pamdas.org", 
client_id="das_web_client", username="chrisd", password="Handle8im$")
subjects = er_client.get_subjects()

subject_ids = [{'id':subject.get('id')} for subject in subjects]

found_group = None
subject_groups = er_client.get_subjectgroups()
for subject_group in subject_groups:
    if subject_group.get("name") == "Fancy Group":
        found_group = subject_group


if found_group:
    print(json.dumps(found_group, indent=2))

remove_these = []
for subject in found_group.get("subjects"):
    if 'canary' in subject.get("name").lower():
        remove_these.append({'id':subject.get("id")})

if remove_these and found_group:
    print(f"Removing {len(remove_these)} subjects from {found_group.get('name')}")
    er_client.remove_subjects_from_subjectgroup(group_id=found_group.get("id"), subjects=remove_these)
else:
    print("No subjects to remove")
