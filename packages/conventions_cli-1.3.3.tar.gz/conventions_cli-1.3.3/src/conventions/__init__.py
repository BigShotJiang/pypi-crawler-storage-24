"""Conventions detection library."""

from .schemas import (
    ConventionRule,
    ConventionsOutput,
    DetectorWarning,
    EvidenceSnippet,
    Language,
    RepoMetadata,
)

__version__ = "0.1.0"

__all__ = [
    "ConventionRule",
    "ConventionsOutput",
    "DetectorWarning",
    "EvidenceSnippet",
    "Language",
    "RepoMetadata",
]
