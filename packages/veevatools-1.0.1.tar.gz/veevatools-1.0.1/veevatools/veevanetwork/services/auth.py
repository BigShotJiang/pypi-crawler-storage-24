"""Veeva Network authentication service."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from ..exceptions import AuthenticationError

if TYPE_CHECKING:
    from ..client import NetworkClient

logger = logging.getLogger(__name__)


class AuthService:
    """Handles authentication and API version discovery for Veeva Network."""

    def __init__(self, client: NetworkClient):
        self.client = client

    def authenticate(self) -> dict:
        """Authenticate with Veeva Network and populate client session state.

        If the client already has a ``session_id`` and ``network_id`` (e.g.
        passed via the constructor for session reuse), the login POST is
        skipped and only version discovery is performed to validate the
        session.

        Otherwise performs two requests:
        1. POST ``/api/{version}/auth`` with username/password
        2. GET ``/api`` to discover available API versions

        Returns:
            The authentication response dict from the API, or a synthetic
            dict when reusing an existing session.

        Raises:
            AuthenticationError: If authentication fails or the reused
                session is invalid.
        """
        # Session reuse path — skip login POST, just validate
        if self.client.session_id and self.client.network_id:
            logger.info(
                "Reusing existing session — network_id=%s",
                self.client.network_id,
            )
            try:
                self._discover_versions()
            except Exception as exc:
                raise AuthenticationError(
                    401,
                    {"responseStatus": "FAILURE", "errors": [
                        {"type": "INVALID_SESSION_ID",
                         "message": f"Session validation failed: {exc}"},
                    ]},
                ) from exc
            return {
                "responseStatus": "SUCCESS",
                "sessionId": self.client.session_id,
                "networkId": self.client.network_id,
            }

        # Standard username/password authentication
        if not self.client.username or not self.client.password:
            raise AuthenticationError(
                400,
                {"responseStatus": "FAILURE", "errors": [
                    {"type": "MISSING_CREDENTIALS",
                     "message": "Either username/password or session_id/network_id must be provided."},
                ]},
            )

        payload = {
            "username": self.client.username,
            "password": self.client.password,
        }
        headers = {"Content-Type": "application/x-www-form-urlencoded"}

        response = self.client.api_call(
            endpoint="auth",
            method="POST",
            data=payload,
            headers=headers,
            raw_response=True,
        )
        body = response.json()

        if body.get("responseStatus") != "SUCCESS":
            raise AuthenticationError(
                response.status_code,
                body,
            )

        self.client.session_id = body["sessionId"]
        self.client.user_id = body["userId"]
        self.client.network_id = body["networkId"]

        logger.info(
            "Authenticated — network_id=%s user_id=%s",
            self.client.network_id,
            self.client.user_id,
        )

        # Discover available API versions
        self._discover_versions()

        return body

    def get_available_versions(self) -> dict:
        """Retrieve available API versions.

        GET ``/api``

        Returns:
            API response with version information.
        """
        return self.client.api_call("/api", method="GET")

    def _discover_versions(self) -> None:
        """Fetch available API versions and store on client."""
        versions_response = self.client.api_call("/api", method="GET")
        version_keys = versions_response.get("values", {}).keys()
        self.client.available_versions = sorted(
            version_keys,
            key=lambda v: float(v.lstrip("v")),
        )
        if self.client.available_versions:
            latest = self.client.available_versions[-1]
            logger.info(
                "API versions available: %s (latest: %s, using: %s)",
                len(self.client.available_versions),
                latest,
                self.client.api_version,
            )
