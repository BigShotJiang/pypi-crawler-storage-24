"""Veeva Vault API error types and exception hierarchy.

Based on Vault API v25R2 error documentation (Section 38).
"""

from enum import Enum


class VaultResponseStatus(str, Enum):
    """Response status values returned by the Vault API."""
    SUCCESS = "SUCCESS"
    WARNING = "WARNING"
    FAILURE = "FAILURE"
    EXCEPTION = "EXCEPTION"


class VaultErrorType(str, Enum):
    """Error types returned by the Vault API."""
    UNEXPECTED_ERROR = "UNEXPECTED_ERROR"
    MALFORMED_URL = "MALFORMED_URL"
    METHOD_NOT_SUPPORTED = "METHOD_NOT_SUPPORTED"
    INACTIVE_USER = "INACTIVE_USER"
    NO_PASSWORD_PROVIDED = "NO_PASSWORD_PROVIDED"
    USERNAME_OR_PASSWORD_INCORRECT = "USERNAME_OR_PASSWORD_INCORRECT"
    USER_LOCKED_OUT = "USER_LOCKED_OUT"
    PASSWORD_CHANGE_REQUIRED = "PASSWORD_CHANGE_REQUIRED"
    INVALID_SESSION_ID = "INVALID_SESSION_ID"
    PARAMETER_REQUIRED = "PARAMETER_REQUIRED"
    INVALID_DATA = "INVALID_DATA"
    INSUFFICIENT_ACCESS = "INSUFFICIENT_ACCESS"
    OPERATION_NOT_ALLOWED = "OPERATION_NOT_ALLOWED"
    ATTRIBUTE_NOT_SUPPORTED = "ATTRIBUTE_NOT_SUPPORTED"
    INVALID_FILTER = "INVALID_FILTER"
    INCORRECT_QUERY_SYNTAX_ERROR = "INCORRECT_QUERY_SYNTAX_ERROR"
    RACE_CONDITION = "RACE_CONDITION"
    EXCEEDS_FILE_MAX_SIZE = "EXCEEDS_FILE_MAX_SIZE"
    API_LIMIT_EXCEEDED = "API_LIMIT_EXCEEDED"
    CONFIGURATION_MODE_ENABLED = "CONFIGURATION_MODE_ENABLED"
    SDK_ERROR = "SDK_ERROR"
    OPERATION_IN_PROGRESS = "OPERATION_IN_PROGRESS"
    ITEM_NAME_EXISTS = "ITEM_NAME_EXISTS"
    USER_NOT_FOUND = "USER_NOT_FOUND"
    FEDERATED_ID_ALREADY_EXISTS = "FEDERATED_ID_ALREADY_EXISTS"


class VaultAPIError(Exception):
    """Base exception for Vault API errors."""

    def __init__(self, message, response_status=None, error_type=None, raw_response=None):
        self.response_status = response_status
        self.error_type = error_type
        self.raw_response = raw_response
        super().__init__(f"[{error_type}] {message}" if error_type else message)


class VaultAuthenticationError(VaultAPIError):
    """Authentication-related errors (INACTIVE_USER, NO_PASSWORD_PROVIDED, USERNAME_OR_PASSWORD_INCORRECT, USER_LOCKED_OUT, PASSWORD_CHANGE_REQUIRED, INVALID_SESSION_ID)."""
    pass


class VaultPermissionError(VaultAPIError):
    """Permission errors (INSUFFICIENT_ACCESS, OPERATION_NOT_ALLOWED)."""
    pass


class VaultQueryError(VaultAPIError):
    """Query errors (INCORRECT_QUERY_SYNTAX_ERROR, INVALID_FILTER)."""
    pass


class VaultRateLimitError(VaultAPIError):
    """Rate limit errors (API_LIMIT_EXCEEDED)."""
    pass


class VaultValidationError(VaultAPIError):
    """Validation errors (PARAMETER_REQUIRED, INVALID_DATA, ATTRIBUTE_NOT_SUPPORTED)."""
    pass
