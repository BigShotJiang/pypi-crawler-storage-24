# archflow 구현 계획

> Context Hub: Jira + Draw.io (Google Drive) 통합 MCP Integration Server
> 생성일: 2026-03-25

---

## 요구사항 정리

### 핵심 목표
누군가 작업 관련해서 물어보면, `/명령어`로 Jira 이슈 + draw.io 아키텍처 다이어그램 정보를 한번에 조회

### 슬래시 명령어
| 명령어 | 기능 |
|--------|------|
| `/arch <이슈키>` | Jira 이슈 상세 + 관련 다이어그램 컴포넌트 매칭 |
| `/diagram <검색어>` | Google Drive의 draw.io 파일에서 검색어와 관련된 노드/연결 정보 |
| `/context` | 현재 스프린트 이슈 목록 + 전체 아키텍처 다이어그램 요약 |

### 기술 구성
- **타입**: MCP Integration Server + Claude Code Skills
- **언어**: TypeScript (Node.js)
- **패키지 매니저**: npm
- **외부 의존성**: Google Drive API (OAuth 2.0), Jira Cloud REST API

---

## 프로젝트 구조

```
archflow/
├── package.json
├── tsconfig.json
├── archflow.config.example.yml    # 매핑 설정 예시
├── archflow.config.yml            # 사용자 매핑 설정 (gitignore)
├── .env.example                   # 환경변수 예시
├── .gitignore
├── README.md
│
├── src/                           # MCP 서버 소스
│   ├── index.ts                   # MCP 서버 엔트리포인트
│   ├── server.ts                  # MCP 서버 정의 (tools 등록)
│   │
│   ├── providers/                 # 외부 시스템 연결
│   │   ├── jira.ts               # Jira Cloud REST API 클라이언트
│   │   ├── gdrive.ts             # Google Drive API 클라이언트
│   │   └── drawio-parser.ts      # draw.io XML → 구조화 데이터
│   │
│   ├── core/                      # 핵심 로직
│   │   ├── matcher.ts            # Jira ↔ draw.io 매칭 엔진
│   │   ├── config.ts             # archflow.config.yml 로더
│   │   └── types.ts              # 공유 타입 정의
│   │
│   └── tools/                     # MCP Tool 핸들러
│       ├── arch.ts               # arch 도구 (이슈 + 다이어그램)
│       ├── diagram.ts            # diagram 도구 (다이어그램 검색)
│       └── context.ts            # context 도구 (스프린트 + 아키텍처)
│
├── skills/                        # Claude Code Skills (복사해서 사용)
│   ├── arch/
│   │   └── SKILL.md
│   ├── diagram/
│   │   └── SKILL.md
│   └── context/
│       └── SKILL.md
│
└── tests/
    ├── providers/
    │   ├── jira.test.ts
    │   ├── gdrive.test.ts
    │   └── drawio-parser.test.ts
    ├── core/
    │   └── matcher.test.ts
    └── tools/
        ├── arch.test.ts
        ├── diagram.test.ts
        └── context.test.ts
```

---

## 구현 Phase

### Phase 1: 프로젝트 초기화 + draw.io 파서 (복잡도: LOW)

| # | 작업 | 파일 |
|---|------|------|
| 1-1 | 레포 생성, package.json, tsconfig.json, .gitignore | 루트 |
| 1-2 | 타입 정의 (DiagramNode, DiagramEdge, JiraIssue 등) | `src/core/types.ts` |
| 1-3 | draw.io XML 파서 구현 (mxGraphModel → 노드/엣지 추출) | `src/providers/drawio-parser.ts` |
| 1-4 | draw.io 파서 테스트 (샘플 .drawio 파일로) | `tests/providers/drawio-parser.test.ts` |

**검증**: 샘플 .drawio XML 입력 → 노드 이름/연결 정보 JSON 출력 확인

### Phase 2: Google Drive 연동 (복잡도: MEDIUM)

| # | 작업 | 파일 |
|---|------|------|
| 2-1 | Google OAuth 2.0 인증 흐름 구현 | `src/providers/gdrive.ts` |
| 2-2 | .drawio 파일 검색/다운로드 기능 | `src/providers/gdrive.ts` |
| 2-3 | 환경변수 설정 (.env.example) | `.env.example` |
| 2-4 | Google Drive 테스트 | `tests/providers/gdrive.test.ts` |

**리스크**: OAuth 설정 필요 (Google Cloud Console에서 프로젝트 생성, OAuth 동의 화면 설정)
**검증**: Google Drive에서 .drawio 파일 목록 조회 + 파일 내용 읽기 성공

### Phase 3: Jira 연동 (복잡도: LOW)

| # | 작업 | 파일 |
|---|------|------|
| 3-1 | Jira REST API 클라이언트 (이슈 조회, 검색, 스프린트) | `src/providers/jira.ts` |
| 3-2 | Jira 테스트 | `tests/providers/jira.test.ts` |

**참고**: 기존 jira-extended MCP의 API 패턴 참고 가능
**검증**: JQL 검색 → 이슈 목록 반환 확인

### Phase 4: 매칭 엔진 + 설정 (복잡도: MEDIUM)

| # | 작업 | 파일 |
|---|------|------|
| 4-1 | archflow.config.yml 스키마 정의 + 로더 | `src/core/config.ts` |
| 4-2 | 매칭 엔진 (설정 기반 + 라벨 유사도 매칭) | `src/core/matcher.ts` |
| 4-3 | 매칭 테스트 | `tests/core/matcher.test.ts` |
| 4-4 | 예시 설정 파일 | `archflow.config.example.yml` |

**설정 파일 구조**:
```yaml
# archflow.config.yml
jira:
  host: "your-domain.atlassian.net"
  project: "KAN"

gdrive:
  folder_id: "1abc..."  # draw.io 파일이 있는 폴더

mappings:
  # 명시적 매핑
  - diagram: "system-architecture.drawio"
    nodes:
      - label: "Auth Service"
        jira_component: "auth"
        jira_labels: ["authentication"]
      - label: "API Gateway"
        jira_component: "api"

  # 자동 매칭 규칙
auto_match:
  enabled: true
  strategy: "label_similarity"  # 노드 라벨 ↔ Jira 컴포넌트/라벨 유사도
  threshold: 0.7
```

**검증**: 매핑 설정 + draw.io 노드 → Jira 이슈 매칭 결과 확인

### Phase 5: MCP 서버 + Tools (복잡도: MEDIUM)

| # | 작업 | 파일 |
|---|------|------|
| 5-1 | MCP 서버 프레임워크 설정 (@modelcontextprotocol/sdk) | `src/server.ts`, `src/index.ts` |
| 5-2 | `archflow_arch` 도구 구현 | `src/tools/arch.ts` |
| 5-3 | `archflow_diagram` 도구 구현 | `src/tools/diagram.ts` |
| 5-4 | `archflow_context` 도구 구현 | `src/tools/context.ts` |
| 5-5 | 통합 테스트 | `tests/tools/*.test.ts` |

**MCP 도구 정의**:
```typescript
// archflow_arch: 이슈 키로 이슈 + 관련 다이어그램 조회
{ name: "archflow_arch", inputSchema: { issueKey: string } }

// archflow_diagram: 검색어로 다이어그램 노드/연결 검색
{ name: "archflow_diagram", inputSchema: { query: string } }

// archflow_context: 스프린트 + 아키텍처 종합
{ name: "archflow_context", inputSchema: { sprintId?: string } }
```

**검증**: Claude Code에서 MCP 서버 연결 → 각 도구 호출 → 결과 반환 확인

### Phase 6: Claude Code Skills (복잡도: LOW)

| # | 작업 | 파일 |
|---|------|------|
| 6-1 | `/arch` Skill 작성 | `skills/arch/SKILL.md` |
| 6-2 | `/diagram` Skill 작성 | `skills/diagram/SKILL.md` |
| 6-3 | `/context` Skill 작성 | `skills/context/SKILL.md` |

**Skill은 MCP 도구를 호출하는 프롬프트 래퍼**:
```yaml
---
name: arch
description: Jira 이슈와 관련 아키텍처 다이어그램을 함께 조회합니다
allowed-tools: ["mcp__archflow__archflow_arch"]
---
# /arch <이슈키>
archflow MCP의 archflow_arch 도구를 호출하여 결과를 표시합니다.
...
```

**검증**: Claude Code에서 `/arch KAN-123` 입력 → Jira 이슈 + 다이어그램 정보 표시

---

## 의존성

### npm 패키지
```json
{
  "dependencies": {
    "@modelcontextprotocol/sdk": "latest",
    "googleapis": "latest",
    "fast-xml-parser": "latest",
    "pako": "latest",
    "yaml": "latest",
    "zod": "latest"
  },
  "devDependencies": {
    "typescript": "latest",
    "vitest": "latest",
    "@types/node": "latest",
    "@types/pako": "latest"
  }
}
```

### 외부 설정 (사용자가 직접)
- Google Cloud Console: OAuth 2.0 클라이언트 ID 생성
- Jira: API 토큰 생성 (https://id.atlassian.com/manage-profile/security/api-tokens)

---

## 리스크

| 리스크 | 등급 | 대응 |
|--------|------|------|
| Google OAuth 설정 복잡도 | HIGH | 상세 가이드 README 제공 + 첫 실행 시 인증 흐름 안내 |
| draw.io 압축 포맷 다양성 | MEDIUM | pako(deflate) + Base64 디코딩 모두 지원 |
| Jira Cloud vs Server 차이 | LOW | Cloud 우선, Server는 나중에 |
| 매칭 정확도 | MEDIUM | 명시적 매핑 우선, 자동 매칭은 보조 |

---

## 실행 순서 요약

```
Phase 1 → Phase 3 → Phase 2 → Phase 4 → Phase 5 → Phase 6
(파서)   (Jira)    (GDrive)   (매칭)    (MCP서버)  (Skills)
```

Phase 1, 3은 병렬 가능. Phase 2는 OAuth 설정이 필요하므로 약간 후순위.

---

**확인 요청**: 이 계획대로 진행할까요?
