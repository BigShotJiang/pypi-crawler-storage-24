"""Tests for citedhealth.api — client initialization and context manager."""

from __future__ import annotations

from citedhealth.api import CitedHealth


class TestCitedHealthInit:
    def test_default_base_url(self) -> None:
        client = CitedHealth()
        assert str(client._client.base_url) == "https://citedhealth.com"
        client.close()

    def test_custom_base_url(self) -> None:
        client = CitedHealth(base_url="https://haircited.com")
        assert str(client._client.base_url) == "https://haircited.com"
        client.close()

    def test_default_timeout(self) -> None:
        client = CitedHealth()
        assert client._client.timeout.connect == 10.0
        client.close()

    def test_custom_timeout(self) -> None:
        client = CitedHealth(timeout=30.0)
        assert client._client.timeout.connect == 30.0
        client.close()

    def test_context_manager(self) -> None:
        with CitedHealth() as api:
            assert isinstance(api, CitedHealth)
            assert not api._client.is_closed
        assert api._client.is_closed

    def test_close(self) -> None:
        client = CitedHealth()
        assert not client._client.is_closed
        client.close()
        assert client._client.is_closed

    def test_repr(self) -> None:
        client = CitedHealth()
        assert "citedhealth.com" in repr(client)
        client.close()


class TestCitedHealthVersion:
    def test_version(self) -> None:
        from citedhealth import __version__

        assert __version__ == "0.1.0"

    def test_version_format(self) -> None:
        from citedhealth import __version__

        parts = __version__.split(".")
        assert len(parts) == 3
        assert all(p.isdigit() for p in parts)
