"""Command-line interface for citedhealth.

Requires the ``cli`` extra: ``pip install citedhealth[cli]``

Usage::

    citedhealth ingredients --query biotin
    citedhealth evidence --ingredient biotin --condition hair-loss
    citedhealth papers --query "melatonin sleep"
    citedhealth badge biotin hair-loss
"""

from __future__ import annotations

import typer
from rich.console import Console
from rich.table import Table

app = typer.Typer(
    name="citedhealth",
    help="Evidence-based supplement research — search ingredients, evidence, and papers.",
    no_args_is_help=True,
)
console = Console()


@app.command()
def ingredients(
    query: str | None = typer.Option(None, "--query", "-q", help="Search by name"),
    category: str | None = typer.Option(None, "--category", "-c", help="Filter by category"),
    page: int = typer.Option(1, "--page", "-p", help="Page number"),
) -> None:
    """List ingredients with optional search and category filter."""
    from citedhealth.api import CitedHealth

    with CitedHealth() as api:
        data = api.ingredients(q=query, category=category, page=page)

    results = data.get("results", [])
    if not results:
        console.print("[yellow]No ingredients found.[/yellow]")
        return

    table = Table(title="Ingredients")
    table.add_column("Name", style="cyan")
    table.add_column("Slug")
    table.add_column("Category")
    table.add_column("Featured", justify="center")

    for item in results:
        table.add_row(
            str(item.get("name", "")),
            str(item.get("slug", "")),
            str(item.get("category", "")),
            "Y" if item.get("is_featured") else "",
        )

    console.print(table)
    console.print(f"[dim]{data.get('count', 0)} total[/dim]")


@app.command()
def evidence(
    ingredient: str | None = typer.Option(None, "--ingredient", "-i", help="Ingredient slug"),
    condition: str | None = typer.Option(None, "--condition", "-c", help="Condition slug"),
    page: int = typer.Option(1, "--page", "-p", help="Page number"),
) -> None:
    """List evidence links with grades (A-F)."""
    from citedhealth.api import CitedHealth

    with CitedHealth() as api:
        data = api.evidence(ingredient=ingredient, condition=condition, page=page)

    results = data.get("results", [])
    if not results:
        console.print("[yellow]No evidence links found.[/yellow]")
        return

    table = Table(title="Evidence Links")
    table.add_column("Grade", style="bold", justify="center")
    table.add_column("Ingredient", style="cyan")
    table.add_column("Condition")
    table.add_column("Studies", justify="right")
    table.add_column("Participants", justify="right")

    for item in results:
        grade = str(item.get("grade", ""))
        grade_style = {
            "A": "[green]A[/green]",
            "B": "[blue]B[/blue]",
            "C": "[yellow]C[/yellow]",
            "D": "[dim]D[/dim]",
            "F": "[red]F[/red]",
        }.get(grade, grade)
        table.add_row(
            grade_style,
            str(item.get("ingredient", {}).get("name", "")),
            str(item.get("condition", {}).get("name", "")),
            str(item.get("total_studies", "")),
            str(item.get("total_participants", "")),
        )

    console.print(table)
    console.print(f"[dim]{data.get('count', 0)} total[/dim]")


@app.command()
def papers(
    query: str | None = typer.Option(None, "--query", "-q", help="Search in title"),
    year: int | None = typer.Option(None, "--year", "-y", help="Filter by year"),
    page: int = typer.Option(1, "--page", "-p", help="Page number"),
) -> None:
    """Search PubMed-indexed papers."""
    from citedhealth.api import CitedHealth

    with CitedHealth() as api:
        data = api.papers(q=query, year=year, page=page)

    results = data.get("results", [])
    if not results:
        console.print("[yellow]No papers found.[/yellow]")
        return

    table = Table(title="Papers")
    table.add_column("PMID", style="dim")
    table.add_column("Title", max_width=60)
    table.add_column("Year", justify="center")
    table.add_column("Citations", justify="right")

    for item in results:
        table.add_row(
            str(item.get("pmid", "")),
            str(item.get("title", ""))[:60],
            str(item.get("publication_year", "")),
            str(item.get("citation_count", "")),
        )

    console.print(table)
    console.print(f"[dim]{data.get('count', 0)} total[/dim]")


@app.command()
def badge(
    ingredient_slug: str = typer.Argument(help="Ingredient slug (e.g. 'biotin')"),
    condition_slug: str = typer.Argument(help="Condition slug (e.g. 'hair-loss')"),
) -> None:
    """Get evidence badge data for an ingredient-condition pair."""
    from citedhealth.api import CitedHealth

    with CitedHealth() as api:
        data = api.badge_data(ingredient_slug, condition_slug)

    table = Table(title=f"Evidence Badge: {ingredient_slug} for {condition_slug}")
    table.add_column("Property", style="cyan")
    table.add_column("Value")

    table.add_row("Grade", str(data.get("grade", "")))
    table.add_row("Label", str(data.get("grade_label", "")))
    table.add_row("Ingredient", str(data.get("ingredient", "")))
    table.add_row("Condition", str(data.get("condition", "")))
    table.add_row("Studies", str(data.get("studies", "")))
    table.add_row("Participants", str(data.get("participants", "")))
    table.add_row("Direction", str(data.get("direction", "")))
    table.add_row("URL", str(data.get("url", "")))

    console.print(table)


if __name__ == "__main__":
    app()
