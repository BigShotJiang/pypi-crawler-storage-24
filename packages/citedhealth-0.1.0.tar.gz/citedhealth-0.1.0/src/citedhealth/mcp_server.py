"""MCP server for citedhealth -- supplement evidence tools for AI assistants.

Requires the ``mcp`` extra: ``pip install citedhealth[mcp]``

Run as a standalone server::

    uvx --from "citedhealth[mcp]" python -m citedhealth.mcp_server

Or configure in ``claude_desktop_config.json``::

    {
        "mcpServers": {
            "citedhealth": {
                "command": "uvx",
                "args": ["--from", "citedhealth[mcp]", "python", "-m", "citedhealth.mcp_server"]
            }
        }
    }
"""

from __future__ import annotations

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("citedhealth")


@mcp.tool()
def search_ingredients(query: str) -> str:
    """Search supplement ingredients from Cited Health.

    Returns ingredients matching the search term with their categories
    and mechanisms of action.

    Args:
        query: Search term (e.g. "biotin", "melatonin", "saw palmetto").
    """
    from citedhealth.api import CitedHealth

    with CitedHealth() as api:
        data = api.ingredients(q=query)

    results = data.get("results", [])
    if not results:
        return f"No ingredients found for '{query}'."

    lines = [
        f"## Ingredients matching '{query}'",
        "",
        f"Found {data.get('count', len(results))} ingredient(s):",
        "",
        "| Name | Category | Mechanism |",
        "|------|----------|-----------|",
    ]
    for item in results:
        lines.append(
            f"| {item.get('name', '')} "
            f"| {item.get('category', '')} "
            f"| {item.get('mechanism', '')[:60]} |"
        )
    return "\n".join(lines)


@mcp.tool()
def check_evidence(ingredient: str, condition: str) -> str:
    """Check evidence for a supplement-condition pair from Cited Health.

    Returns the evidence grade (A-F), study count, participant count,
    and a link to the full evidence review.

    Args:
        ingredient: Ingredient slug (e.g. "biotin", "melatonin").
        condition: Condition slug (e.g. "hair-loss", "sleep-quality").
    """
    from citedhealth.api import CitedHealth

    with CitedHealth() as api:
        try:
            data = api.badge_data(ingredient, condition)
        except Exception:
            return (
                f"No evidence found for '{ingredient}' and '{condition}'. "
                "Check spelling or try the search_ingredients tool first."
            )

    grade = data.get("grade", "?")
    label = data.get("grade_label", "")
    studies = data.get("studies", 0)
    participants = data.get("participants", 0)
    direction = data.get("direction", "")
    url = data.get("url", "")

    grade_desc = {
        "A": "Strong evidence from multiple RCTs/meta-analyses",
        "B": "Moderate evidence from at least one RCT",
        "C": "Limited evidence from small studies",
        "D": "Preliminary evidence (in vitro, case reports)",
        "F": "Negative - most studies show no positive effect",
    }.get(grade, "Unknown")

    lines = [
        f"## {data.get('ingredient', ingredient)} for {data.get('condition', condition)}",
        "",
        f"**Evidence Grade: {grade}** ({label})",
        "",
        f"- {grade_desc}",
        f"- {studies} studies with {participants:,} total participants",
        f"- Effect direction: {direction}",
        "",
        f"Full evidence review: {url}",
    ]
    return "\n".join(lines)


@mcp.tool()
def search_papers(query: str, year: int | None = None) -> str:
    """Search PubMed-indexed papers from Cited Health.

    Returns papers matching the search term, ordered by year and citations.

    Args:
        query: Search in title (e.g. "melatonin sleep", "biotin hair").
        year: Optional filter by publication year.
    """
    from citedhealth.api import CitedHealth

    with CitedHealth() as api:
        data = api.papers(q=query, year=year)

    results = data.get("results", [])
    if not results:
        return f"No papers found for '{query}'."

    lines = [
        f"## Papers matching '{query}'",
        "",
        f"Found {data.get('count', len(results))} paper(s):",
        "",
        "| PMID | Title | Year | Citations |",
        "|------|-------|------|-----------|",
    ]
    for item in results[:10]:
        title = str(item.get("title", ""))[:80]
        lines.append(
            f"| {item.get('pmid', '')} "
            f"| {title} "
            f"| {item.get('publication_year', '')} "
            f"| {item.get('citation_count', '')} |"
        )
    return "\n".join(lines)


if __name__ == "__main__":
    mcp.run()
