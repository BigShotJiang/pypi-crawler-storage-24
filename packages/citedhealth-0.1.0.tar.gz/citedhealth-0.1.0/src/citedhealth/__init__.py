"""citedhealth -- Evidence-based supplement research API client.

Search ingredients, conditions, evidence grades, and PubMed papers
from Cited Health (citedhealth.com). Free, no authentication required.

Usage::

    from citedhealth.api import CitedHealth

    with CitedHealth() as api:
        ingredients = api.ingredients(q="biotin")
        evidence = api.evidence(ingredient="biotin", condition="hair-loss")
        papers = api.papers(q="melatonin sleep")
"""

__version__ = "0.1.0"
