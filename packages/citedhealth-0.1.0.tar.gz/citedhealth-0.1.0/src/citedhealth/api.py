"""HTTP API client for Cited Health REST endpoints.

Requires the ``api`` extra: ``pip install citedhealth[api]``

Usage::

    from citedhealth.api import CitedHealth

    with CitedHealth() as api:
        # List ingredients with optional search
        data = api.ingredients(q="biotin", category="vitamins")

        # List evidence links filtered by ingredient and/or condition
        evidence = api.evidence(ingredient="biotin", condition="hair-loss")

        # Search PubMed-indexed papers
        papers = api.papers(q="melatonin", year=2024)

        # Get embeddable badge data for an ingredient-condition pair
        badge = api.badge_data("biotin", "hair-loss")
"""

from __future__ import annotations

from typing import Any

import httpx


class CitedHealth:
    """API client for the Cited Health REST API.

    Provides access to evidence-based supplement research data including
    ingredients, conditions, evidence links with grades (A-F), and
    PubMed-indexed papers.

    Args:
        base_url: API base URL. Defaults to ``https://citedhealth.com``.
        timeout: Request timeout in seconds. Defaults to ``10.0``.
    """

    def __init__(
        self,
        base_url: str = "https://citedhealth.com",
        timeout: float = 10.0,
    ) -> None:
        self._client = httpx.Client(base_url=base_url, timeout=timeout)

    # -- HTTP helpers ----------------------------------------------------------

    def _get(self, path: str, **params: Any) -> dict[str, Any]:
        """Send GET request, raise on HTTP errors, return JSON."""
        resp = self._client.get(path, params={k: v for k, v in params.items() if v is not None})
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    # -- List endpoints --------------------------------------------------------

    def ingredients(
        self,
        *,
        q: str | None = None,
        category: str | None = None,
        page: int | None = None,
        page_size: int | None = None,
    ) -> dict[str, Any]:
        """List ingredients with optional search and category filter.

        Args:
            q: Search by name (case-insensitive).
            category: Filter by category (e.g. ``"vitamins"``, ``"herbs"``).
            page: Page number (default 1).
            page_size: Results per page (default 20, max 100).

        Returns:
            Paginated response with ``count``, ``next``, ``previous``, ``results``.
        """
        return self._get(
            "/api/ingredients/", q=q, category=category, page=page, page_size=page_size
        )

    def papers(
        self,
        *,
        q: str | None = None,
        year: int | None = None,
        page: int | None = None,
        page_size: int | None = None,
    ) -> dict[str, Any]:
        """List PubMed-indexed papers with optional search.

        Args:
            q: Search in title (case-insensitive).
            year: Filter by publication year.
            page: Page number (default 1).
            page_size: Results per page (default 20, max 100).

        Returns:
            Paginated response with ``count``, ``next``, ``previous``, ``results``.
        """
        return self._get("/api/papers/", q=q, year=year, page=page, page_size=page_size)

    def evidence(
        self,
        *,
        ingredient: str | None = None,
        condition: str | None = None,
        page: int | None = None,
        page_size: int | None = None,
    ) -> dict[str, Any]:
        """List evidence links with grades.

        Each evidence link represents the research relationship between
        an ingredient and a condition, including an evidence grade (A-F),
        study count, participant count, and effect direction.

        Args:
            ingredient: Filter by ingredient slug (e.g. ``"biotin"``).
            condition: Filter by condition slug (e.g. ``"hair-loss"``).
            page: Page number (default 1).
            page_size: Results per page (default 20, max 100).

        Returns:
            Paginated response with ``count``, ``next``, ``previous``, ``results``.
        """
        return self._get(
            "/api/evidence/",
            ingredient=ingredient,
            condition=condition,
            page=page,
            page_size=page_size,
        )

    # -- Detail endpoints ------------------------------------------------------

    def badge_data(self, ingredient_slug: str, condition_slug: str) -> dict[str, Any]:
        """Get embeddable badge data for an ingredient-condition pair.

        Returns grade, label, study stats, and URLs for rendering an
        evidence badge widget on external sites.

        Args:
            ingredient_slug: Ingredient slug (e.g. ``"biotin"``).
            condition_slug: Condition slug (e.g. ``"hair-loss"``).

        Returns:
            Badge data dict with ``grade``, ``grade_label``, ``grade_color``,
            ``ingredient``, ``condition``, ``studies``, ``participants``,
            ``direction``, ``url``, ``cite_url``, ``logo_url``.
        """
        return self._get(f"/embed/{ingredient_slug}/for/{condition_slug}/data.json")

    def openapi_spec(self) -> dict[str, Any]:
        """Get the OpenAPI 3.1.0 specification for the API.

        Returns:
            Complete OpenAPI spec dict.
        """
        return self._get("/api/openapi.json")

    # -- Context manager -------------------------------------------------------

    def close(self) -> None:
        """Close the underlying HTTP connection."""
        self._client.close()

    def __enter__(self) -> CitedHealth:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def __repr__(self) -> str:
        return f"CitedHealth(base_url={str(self._client.base_url)!r})"
