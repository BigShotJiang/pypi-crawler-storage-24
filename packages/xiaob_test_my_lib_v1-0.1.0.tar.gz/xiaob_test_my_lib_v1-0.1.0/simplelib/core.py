def greet(name: str) -> str:
    """返回问候语"""
    return f"Hello, {name}!"