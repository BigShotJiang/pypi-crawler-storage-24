# 将核心功能暴露到包级别
from .core import greet

__all__ = ["greet"]