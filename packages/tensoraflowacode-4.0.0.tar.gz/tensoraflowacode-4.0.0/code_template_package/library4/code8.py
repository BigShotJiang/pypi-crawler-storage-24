def template():
    code = """
SARIMA Model

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from statsmodels.tsa.statespace.sarimax import SARIMAX
from pmdarima import auto_arima
from sklearn.metrics import mean_absolute_error

# Load dataset
df = pd.read_csv("AirPassengers.csv", parse_dates=['Month'], index_col='Month')

# ORIGINAL TIME SERIES PLOT  (this should not be removed)
plt.figure(figsize=(7,4))
plt.plot(df.index, df['#Passengers'], label='Original Time Series', color='green')
plt.xlabel("Year")
plt.ylabel("Number of Passengers")
plt.title("Air Passengers Dataset")
plt.legend()
plt.show()

# Auto ARIMA to find best parameters
stepwise_fit = auto_arima(df['#Passengers'],
                          seasonal=True,
                          m=12,
                          trace=True)

print(stepwise_fit.summary())

# Build SARIMA model
model = SARIMAX(df['#Passengers'],
                order=(2,1,1),
                seasonal_order=(0,1,0,12))

sarima_result = model.fit()

print(sarima_result.summary())

# Forecast next 12 months
forecast = sarima_result.get_forecast(steps=12)
conf_int = forecast.conf_int()

# Plot forecast
plt.figure(figsize=(10,5))
plt.plot(df, label="Observed")
plt.plot(forecast.predicted_mean, label="Forecast", color='red')

plt.fill_between(conf_int.index,
                 conf_int.iloc[:,0],
                 conf_int.iloc[:,1],
                 color='pink',
                 alpha=0.3)

plt.title("SARIMA Forecast")
plt.legend()
plt.show()
"""
    return code