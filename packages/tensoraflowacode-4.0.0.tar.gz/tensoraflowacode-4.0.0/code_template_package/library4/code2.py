def template():
    code = """
Convert Non-Stationary to Stationary


from statsmodels.tsa.stattools import adfuller

np.random.seed(42)
n = 100
data = np.cumsum(np.random.normal(size=n))
time_series = pd.Series(data)

plt.figure(figsize=(10,4))
plt.plot(time_series,label="Original Series")
plt.title("Original Non-Stationary Time Series")
plt.legend()
plt.show()

diff_series = time_series.diff().dropna()

plt.figure(figsize=(10,4))
plt.plot(diff_series,label="Differenced Series")
plt.title("Stationary Time Series After Differencing")
plt.legend()
plt.show()

def adf_test(series):
    result = adfuller(series)
    print("ADF Statistic:", result[0])
    print("p-value:", result[1])
    print("Critical Values:")

    for key,value in result[4].items():
        print(f"{key}: {value}")

    if result[1] <= 0.05:
        print("Time series is stationary.")
    else:
        print("The series is not stationary")

print("ADF Test for Original Series:")
adf_test(time_series)

print("\nADF Test for Differenced Series:")
adf_test(diff_series)
"""
    return code