def template():
    code = """
Autoregressive Model

from sklearn.metrics import mean_squared_error

np.random.seed(42)

n=100
data=[50+0.8*i+np.random.normal(scale=5) for i in range(n)]

ts=pd.Series(data)

train_size=int(len(ts)*0.8)

train,test=ts[:train_size],ts[train_size:]

lag=5

model=AutoReg(train,lags=lag)
model_fit=model.fit()

predictions=model_fit.predict(start=len(train),end=len(train)+len(test)-1,dynamic=False)

mse=mean_squared_error(test,predictions)

plt.figure(figsize=(10,5))
plt.plot(test.index,test,label='Actual',marker='o')
plt.plot(test.index,predictions,label='predicted',linestyle='dashed',marker='x')
plt.legend()
plt.title('autoregressive model prediction')
plt.xlabel('time')
plt.ylabel('value')
plt.show()

"""
    return code