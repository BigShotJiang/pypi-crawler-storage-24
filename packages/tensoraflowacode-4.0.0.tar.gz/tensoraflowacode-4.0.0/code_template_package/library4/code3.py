def template():
    code = """
Dickey Fuller Test

data = {
"data": pd.date_range(start="2020-01-01",periods=100,freq="D"),
"value":[x + (x*0.1) for x in range(100)]
}

df3 = pd.DataFrame(data)
print(df3.head())

adf_result = adfuller(df3["value"])

print("ADF Statistic:",adf_result[0])
print("p-value:",adf_result[1])
print("Critical Values:")

for key,value in adf_result[4].items():
    print(f"{key}: {value}")

if adf_result[1] <= 0.05:
    print("The Series is Stationary.")
else:
    print("The Series is not Stationary.")
"""
    return code