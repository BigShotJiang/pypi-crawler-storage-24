def template():
    code = """
Exponential Smoothing

data = pd.read_csv("AirPassengers.csv",parse_dates=['Month'],index_col='Month')

plt.plot(data)
plt.xlabel('Year')
plt.ylabel('Number of passengers')
plt.show()

# Single Exponential Smoothing
from statsmodels.tsa.api import SimpleExpSmoothing

model = SimpleExpSmoothing(data)
model_single_fit = model.fit()

forecast_single = model_single_fit.forecast(40)

plt.plot(data,label="Original Data")
plt.plot(model_single_fit.fittedvalues,label="Fitted Values")
plt.plot(forecast_single,label="forecast")
plt.title("Single Exponential Smoothing")
plt.legend()
plt.show()


# Double Exponential Smoothing
from statsmodels.tsa.api import Holt

model_double = Holt(data)
model_double_fit = model_double.fit()

forecast_double = model_double_fit.forecast(40)

plt.plot(data,label="Original Data")
plt.plot(model_double_fit.fittedvalues,label="Fitted Values")
plt.plot(forecast_double,label="forecast")
plt.title("Double Exponential Smoothing")
plt.legend()
plt.show()


# Triple Exponential Smoothing
from statsmodels.tsa.api import ExponentialSmoothing

model_triple = ExponentialSmoothing(
    data,
    seasonal_periods=12,
    trend='add',
    seasonal='add'
)

model_triple_fit = model_triple.fit()

forecast_triple = model_triple_fit.forecast(40)

plt.plot(data,label="Original Data")
plt.plot(model_triple_fit.fittedvalues,label="Fitted Values")
plt.plot(forecast_triple,label="forecast")
plt.title("Triple Exponential Smoothing")
plt.legend()
plt.show()
"""
    return code