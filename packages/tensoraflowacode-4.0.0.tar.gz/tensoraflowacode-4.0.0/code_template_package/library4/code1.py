def template():
    code = """
Decompose time series data (Trend, Seasonal, Residual)

import warnings
warnings.filterwarnings("ignore")
!pip install pandas numpy matplotlib statsmodels scikit-learn pmdarima

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from statsmodels.tsa.seasonal import STL

df = pd.read_csv("AirPassengers.csv")

plt.figure(figsize=(7,4))
plt.plot(df.index, df['#Passengers'], label='Original Time Series', color='green')
plt.title('Air Passengers Dataset')
plt.xlabel('Year')
plt.ylabel('Number of Passengers')
plt.legend()
plt.show()

# STL decomposition
stl = STL(df['#Passengers'], period=13, robust=True)
result = stl.fit()

fig, (ax1, ax2, ax3) = plt.subplots(3,1,figsize=(7,4))
ax1.plot(df.index, result.trend, color='red')
ax1.set_title('Trend Component')

ax2.plot(df.index, result.seasonal, color='blue')
ax2.set_title('Seasonal Component')

ax3.plot(df.index, result.resid)
ax3.set_title('Residual Component')

plt.tight_layout()
plt.show()

"""
    return code