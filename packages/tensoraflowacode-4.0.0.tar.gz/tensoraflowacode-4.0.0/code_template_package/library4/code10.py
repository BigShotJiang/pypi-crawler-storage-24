def template():
    code = """
________________________________________
Practical 1 – Single Layer Perceptron
Theory
A Perceptron is one of the simplest types of artificial neural networks introduced by Frank Rosenblatt in 1957. It is used for binary classification problems.
A perceptron consists of:
•	Input layer
•	Weights
•	Bias
•	Activation function
The perceptron computes a weighted sum of inputs and applies an activation function to produce the output.
[
y = f(\sum w_i x_i + b)
]
Where
•	(x_i) = input
•	(w_i) = weight
•	(b) = bias
The weights are updated using the perceptron learning rule:
[
w = w + \eta (t - y)x
]
where
•	( \eta ) = learning rate
•	( t ) = target output
•	( y ) = predicted output
Perceptrons can only solve linearly separable problems.
________________________________________
Practical 2 – Multi-Layer Perceptron (MLP)
Theory
A Multi-Layer Perceptron is an extension of a single layer perceptron that contains one or more hidden layers between input and output layers.
Structure of MLP:
•	Input Layer
•	Hidden Layer(s)
•	Output Layer
Each neuron in one layer is connected to neurons in the next layer through weighted connections.
MLPs use non-linear activation functions such as:
•	Sigmoid
•	ReLU
•	Tanh
Unlike a single perceptron, MLP can solve non-linearly separable problems.
MLP is widely used for:
•	Image recognition
•	Speech recognition
•	Classification tasks
Training is usually performed using the backpropagation algorithm.
________________________________________
Practical 3 – Backpropagation Neural Network
Theory
Backpropagation is a supervised learning algorithm used for training multi-layer neural networks.
It works by:
1.	Forward propagation
2.	Error calculation
3.	Backward propagation
4.	Weight update
Steps of the algorithm:
1.	Inputs are passed through the network to compute output.
2.	Error is calculated between predicted output and target output.
3.	Error is propagated backward through the network.
4.	Weights are updated using gradient descent.
Weight update formula:
[
w = w - \eta \frac{\partial E}{\partial w}
]
where
•	(E) = error function
•	( \eta ) = learning rate
Backpropagation helps neural networks learn complex patterns.
________________________________________
Practical 4 – Fuzzy Logic
Theory
Fuzzy Logic is a form of logic that deals with reasoning that is approximate rather than exact.
It was introduced by Lotfi A. Zadeh in 1965.
In classical logic:
•	True = 1
•	False = 0
In fuzzy logic:
•	Truth values range between 0 and 1.
Example:
Temperature classification
Temperature	Membership
Cold	0.2
Warm	0.7
Hot	0.4
Main components of fuzzy systems:
1.	Fuzzification
2.	Rule Base
3.	Inference Engine
4.	Defuzzification
Applications:
•	Washing machines
•	Air conditioners
•	Decision systems
•	Control systems
________________________________________
Practical 5 – Hebbian Learning Rule
Theory
Hebbian learning is one of the earliest neural learning rules proposed by Donald Hebb.
It is based on the principle:
“Neurons that fire together wire together.”
The rule states that if two neurons are activated at the same time, the connection between them becomes stronger.
Weight update rule:
[
\Delta w = \eta \cdot x \cdot y
]
where
•	(x) = input
•	(y) = output
•	( \eta ) = learning rate
Hebbian learning is an unsupervised learning technique.
Applications:
•	Pattern association
•	Memory models
•	Feature learning
________________________________________
Practical 6 – Self Organizing Map (SOM)
Theory
Self Organizing Map is an unsupervised neural network proposed by Teuvo Kohonen.
It is used for clustering and dimensionality reduction.
SOM maps high-dimensional data into a two-dimensional grid of neurons.
Working steps:
1.	Initialize weight vectors
2.	Select input vector
3.	Find Best Matching Unit (BMU)
4.	Update BMU and neighboring neurons
5.	Repeat for multiple iterations
Weight update formula:
[
W(t+1) = W(t) + \alpha(t) (X - W(t))
]
Advantages:
•	Visualization of complex data
•	Clustering similar data points
•	Feature mapping
________________________________________
Practical 7 – Delta Rule Learning
Theory
The Delta Rule is a supervised learning rule used to minimize the error between predicted and target outputs.
It is also known as the Widrow-Hoff rule.
Error is calculated as:
[
Error = Target - Output
]
Weight update formula:
[
\Delta w = \eta (t - y)x
]
where
•	(t) = target output
•	(y) = predicted output
•	(x) = input
The delta rule adjusts weights gradually to minimize the error.
Applications:
•	Linear classifiers
•	Adaptive filters
•	Neural network training
________________________________________
Practical 8 – Genetic Algorithm
Theory
A Genetic Algorithm is an optimization technique inspired by natural selection and evolution.
It was introduced by John Holland.
Key concepts of Genetic Algorithms:
1.	Population – Set of candidate solutions
2.	Chromosome – Representation of solution
3.	Fitness Function – Measures quality of solution
4.	Selection – Choosing best individuals
5.	Crossover – Combining parents to produce offspring
6.	Mutation – Random change to maintain diversity
Steps of the algorithm:
1.	Initialize population
2.	Evaluate fitness
3.	Select parents
4.	Perform crossover
5.	Apply mutation
6.	Generate new population
7.	Repeat until optimal solution is found
Applications:
•	Optimization problems
•	Machine learning
•	Scheduling
•	Path finding
________________________________________

 
"""
    return code