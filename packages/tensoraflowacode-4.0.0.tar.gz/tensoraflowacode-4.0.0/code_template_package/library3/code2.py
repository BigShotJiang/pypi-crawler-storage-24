def template():
    code = """
%pip install --upgrade pip
%pip install torch matplotlib

import torch
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt

class MLP(nn.Module):
    def __init__(self, input_size, hidden_sizes, output_size):
        super().__init__()

        layers = []
        last_size = input_size

        for hidden_size in hidden_sizes:
            layers.append(nn.Linear(last_size, hidden_size))
            layers.append(nn.ReLU())
            last_size = hidden_size

        layers.append(nn.Linear(last_size, output_size))
        self.network = nn.Sequential(*layers)

    def forward(self, x):
        return self.network(x)

x = torch.randn(100,3)
y = torch.randint(0,2,(100,))

mlp = MLP(3,[16,16],2)

criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(mlp.parameters(),lr=0.01)

epochs = 200
losses = []

for epoch in range(epochs):
    optimizer.zero_grad()
    outputs = mlp(x)
    loss = criterion(outputs,y)

    loss.backward()
    optimizer.step()

    losses.append(loss.item())

    if (epoch+1)%5==0:
        print(f"Epoch {epoch+1}, Loss {loss.item():.4f}")

plt.plot(losses)
plt.title("MLP Training Loss")
plt.show()

with torch.no_grad():
    predictions = torch.argmax(mlp(x),dim=1)
    accuracy = (predictions==y).sum().item()/y.size(0)

print("Training Accuracy:",accuracy)
"""
    return code