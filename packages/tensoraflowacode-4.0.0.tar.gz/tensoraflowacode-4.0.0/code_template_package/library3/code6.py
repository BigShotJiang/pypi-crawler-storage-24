def template():
    code = """
pr 5a
import numpy as np

# Hebbian Learning Rule
def hebbian_learning(X, y, learning_rate=0.1):

    weights = np.zeros(X.shape[1])

    print("Initial Weights:", weights)

    for i in range(len(X)):
        x_i = X[i]
        y_i = y[i]

        delta_w = learning_rate * x_i * y_i
        weights = weights + delta_w

        print("Updated Weights:", weights)

    return weights


# Input data
X = np.array([
    [1, 0],
    [0, 1],
    [1, 1],
    [0, 0]
])

# Target output
y = np.array([0, 0, 1, 0])

# Train using Hebbian rule
final_weights = hebbian_learning(X, y)

print("Final Weights:", final_weights)
"""
    return code