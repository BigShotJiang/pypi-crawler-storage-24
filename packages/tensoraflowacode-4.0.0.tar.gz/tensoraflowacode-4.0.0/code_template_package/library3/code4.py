def template():
    code = """
pr 4

def fuzzy_logic(temperature, humidity):

    def temp_low(x):
        if x <= 25: return 1
        elif x<50: return (50-x)/25
        else: return 0

    def temp_med(x):
        if x<=25 or x>=75: return 0
        elif x<=50: return (x-25)/25
        else: return (75-x)/25

    def temp_high(x):
        if x<=50: return 0
        elif x<75: return (x-50)/25
        else: return 1

    def humid_low(x):
        if x<=25: return 1
        elif x<50: return (50-x)/25
        else: return 0

    def humid_med(x):
        if x<=25 or x>=75: return 0
        elif x<=50: return (50-x)/25
        else: return (75-x)/25

    def humid_high(x):
        if x<=50: return 0
        elif x<75: return (x-50)/25
        else: return 1

    low = (temp_low(temperature)+humid_low(humidity))/2
    med = (temp_med(temperature)+humid_med(humidity))/2
    high = (temp_high(temperature)+humid_high(humidity))/2

    return [low,med,high]

temps=[23,45,56,78]
humids=[56,45,78,78]

for t,h in zip(temps,humids):

    result=fuzzy_logic(t,h)

    print("Temp",t,"Humidity",h)
    print("Fan speed Low",result[0],"Med",result[1],"High",result[2])
"""
    return code