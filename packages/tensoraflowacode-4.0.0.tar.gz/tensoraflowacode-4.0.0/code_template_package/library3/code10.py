def template():
    code = """
pr 7,8
import numpy as np

def delta_rule_learning(X, t, lr=0.1, epochs=20):

    weights = np.zeros(X.shape[1])
    print("Initial Weights:", weights)

    for epoch in range(epochs):

        print(f"\nEpoch {epoch+1}")

        for i in range(len(X)):

            x_i = X[i]
            target = t[i]

            y = np.dot(x_i, weights)

            error = target - y

            delta_w = lr * error * x_i

            weights += delta_w

            print(f"Sample {i+1}: Input={x_i}, Target={target}, Output={y:.2f}, Error={error:.2f}")
            print("Weight Update:", delta_w)
            print("New Weights:", weights)

    return weights


# Dataset
X = np.array([
    [1, 2],
    [2, 1],
    [3, 4],
    [4, 3]
])

t = np.array([1, 1, -1, -1])


# Train network
final_weights = delta_rule_learning(X, t, lr=0.1, epochs=5)

print("\nFinal Learned Weights:", final_weights)
------------------------------------------------------
import random

POPULATION_SIZE = 1000

GENES = '''abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ 1234567890'''

TARGET = "I love MSCDSAI with RJColleges"


class Individual:

    def __init__(self, chromosome):
        self.chromosome = chromosome
        self.fitness = self.cal_fitness()

    @classmethod
    def mutated_genes(cls):
        return random.choice(GENES)

    @classmethod
    def create_gnome(cls):
        return [cls.mutated_genes() for _ in range(len(TARGET))]

    def mate(self, par2):

        child_chromosome = []

        for gp1, gp2 in zip(self.chromosome, par2.chromosome):

            prob = random.random()

            if prob < 0.45:
                child_chromosome.append(gp1)

            elif prob < 0.90:
                child_chromosome.append(gp2)

            else:
                child_chromosome.append(self.mutated_genes())

        return Individual(child_chromosome)

    def cal_fitness(self):

        fitness = 0

        for gs, gt in zip(self.chromosome, TARGET):

            if gs != gt:
                fitness += 1

        return fitness


def main():

    generation = 1
    found = False
    population = []

    for _ in range(POPULATION_SIZE):
        gnome = Individual.create_gnome()
        population.append(Individual(gnome))

    while not found:

        population = sorted(population, key=lambda x: x.fitness)

        if population[0].fitness == 0:
            found = True
            break

        new_generation = []

        s = int(0.1 * POPULATION_SIZE)
        new_generation.extend(population[:s])

        s = int(0.9 * POPULATION_SIZE)

        for _ in range(s):
            parent1 = random.choice(population[:50])
            parent2 = random.choice(population[:50])
            child = parent1.mate(parent2)
            new_generation.append(child)

        population = new_generation

        print("Generation:", generation,
              "String:", "".join(population[0].chromosome),
              "Fitness:", population[0].fitness)

        generation += 1

    print("\nFinal Generation:", generation)
    print("String:", "".join(population[0].chromosome))
    print("Fitness:", population[0].fitness)


if __name__ == "__main__":
    main()
"""
    return code