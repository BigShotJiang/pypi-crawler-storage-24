def template():
    code = """
pr 5b
from sklearn.datasets import load_iris
import numpy as np

# Step 1: Load Iris data
iris = load_iris()
X = iris.data
y = iris.target   # Classes: 0, 1, 2


# Step 2: Convert to +1 / -1 target for Hebbian rule
# Here: class 1 becomes -1, all others become +1
y_heb = np.where(y == 1, -1, 1)


# Step 3: Normalize input (min-max normalization)
X_norm = (X - X.min(axis=0)) / (X.max(axis=0) - X.min(axis=0))


# Step 4: Initialize weights
weights = np.zeros(X_norm.shape[1])
learning_rate = 0.1

print("Initial weights:", weights)


# Step 5: Hebbian Learning
for i in range(len(X_norm)):

    x_i = X_norm[i]
    y_i = y_heb[i]

    # Hebbian update
    delta_w = learning_rate * x_i * y_i
    weights += delta_w

    # Show step-by-step for first 5 samples
    if i < 5:
        print(f"\nSample {i+1}")
        print("Input:", x_i)
        print("Output (Hebbian label):", y_i)
        print("Delta w:", delta_w)
        print("Updated weights:", weights)


print("\nFinal learned weights:", weights)
"""
    return code