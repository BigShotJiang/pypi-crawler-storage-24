def template():
    code = """
4b

!pip install numpy pandas scikit-fuzzy matplotlib

import numpy as np
import pandas as pd

data = pd.read_csv("imdb_movies.csv")
df = pd.DataFrame(data)

ratings = np.array(df['score'].values)   # Ratings for clustering
X = ratings.reshape(1, -1)               # (features, samples)

import skfuzzy as fuzz

# Number of Clusters: Flop, Average, Hit
n_clusters = 3

# Apply FCM
cntr, u, u0, d, jm, p, fpc = fuzz.cluster.cmeans(
    X,
    c=n_clusters,
    m=2,
    error=0.005,
    maxiter=1000,
    init=None
)

# Cluster membership for each movie
cluster_membership = np.argmax(u, axis=0)

# Map cluster centers to labels
cluster_centers = cntr.flatten()
sorted_indices = np.argsort(cluster_centers)

labels_map = {
    sorted_indices[0]: 'Flop',
    sorted_indices[1]: 'Average',
    sorted_indices[2]: 'Hit'
}

# Assign labels
df['Cluster'] = cluster_membership
df['Category'] = df['Cluster'].map(labels_map)

print(df[['names', 'score', 'Category']])

import matplotlib.pyplot as plt

plt.figure(figsize=(8, 4))

colors = ['red', 'orange', 'green']

plt.plot(ratings, u[1], label=f'{labels_map[1]} Membership', color=colors[1])

plt.title('Fuzzy C-Means Membership for IMDb Ratings')
plt.xlabel('Movie Index')
plt.ylabel('Membership Grade')

plt.legend()
plt.grid(True)
plt.show()
"""
    return code