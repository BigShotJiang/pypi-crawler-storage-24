def template():
    code = """
6b
import numpy as np
from sklearn.datasets import load_iris
from sklearn.preprocessing import MinMaxScaler

class SOM:

    def __init__(self, grid_size, input_dim, learning_rate=0.5, radius=2):
        self.grid_size = grid_size
        self.input_dim = input_dim
        self.lr = learning_rate
        self.radius = radius
        self.weights = np.random.rand(grid_size, grid_size, input_dim)

    def find_bmu(self, x):
        diff = self.weights - x
        dist = np.linalg.norm(diff, axis=2)
        return np.unravel_index(np.argmin(dist), dist.shape)

    def train(self, data, epochs=200):

        for epoch in range(epochs):

            for x in data:

                bmu = self.find_bmu(x)

                for i in range(self.grid_size):
                    for j in range(self.grid_size):

                        dist = np.sqrt((i - bmu[0])**2 + (j - bmu[1])**2)

                        if dist <= self.radius:
                            influence = np.exp(-(dist**2) / (2 * (self.radius**2)))
                            self.weights[i, j] += influence * self.lr * (x - self.weights[i, j])


# Load dataset
iris = load_iris()
X = iris.data
y = iris.target

# Normalize
scaler = MinMaxScaler()
X_norm = scaler.fit_transform(X)

# Train SOM
som = SOM(grid_size=20, input_dim=4, learning_rate=0.5, radius=2)
som.train(X_norm, epochs=300)

print("Training completed!")

# Mapping samples to SOM grid
mapping = np.zeros((20, 20), dtype=int)

for i, x in enumerate(X_norm):
    bmu = som.find_bmu(x)
    mapping[bmu] = y[i] + 1

print("\nSOM Mapping of Iris Classes:")
print("(1=setosa, 2=versicolor, 3=virginica)")
print(mapping)
"""
    return code