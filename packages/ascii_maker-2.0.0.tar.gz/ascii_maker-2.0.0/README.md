# ascii-maker

**Ultimate ASCII art designer for the terminal.**
Text banners · gradient effects · neon glow · animations · animals · logos · 9 export formats · favorites

```
     _  _  _  _  _  _  _                 _
    / \/ \/ \/ \/ \/ \/ \               / \
   | a  s  c  i  i  -  m  a  k  e  r |
    \_/\_/\_/\_/\_/\_/\_/               \_/
```

## Install

```bash
pip install ascii-maker
```

## Quick start

```bash
# Text art
am text "Hello World" --font slant       # Render with pyfiglet font
am text "Hello" --pick                   # Interactive font + color picker
am text "Hello" --preview                # Preview in all favorite fonts

# Effects
am rainbow "HELLO" --gradient fire       # Gradient color sweep
am neon "GLOW" --color bright_cyan       # Neon glow shadow effect
am animate "HELLO" --gradient rainbow    # Live animated color cycling

# Compositions
am banner "MyApp" --theme neon           # ASCII art banner with box + theme
am combo cat "Hello World"               # Animal + text side by side
am signature "Alice" --title "Dev Lead"  # Signature block with name art

# Art library
am animals                               # Browse 30 built-in animals
am logo python                           # 15 brand logos (python, docker, git…)
am logo --generate "My Company"          # Generate any text as a logo

# Export
am export html "banner MyApp --theme fire"   # Colored HTML file
am export bash "combo dragon DOOM"           # Runnable bash script
am export py "logo python"                   # Python script with art
am export md "signature Alice --title Dev"   # Markdown code fence
am export shellrc "banner MyApp"             # Shell config snippet
am export inject myscript.sh "banner MyApp"  # Inject into existing file

# Favorites
am fav list                              # List saved favorites
am fav show myart                        # Display a saved favorite
am banner "MyApp" --theme fire --save myapp  # Save any art to favorites

# Interactive designer
am design                                # 14-option grouped menu
```

## Commands

### Text Art

| Command | Description |
|---------|-------------|
| `am text TEXT` | Render text with pyfiglet fonts (`--font`, `--pick`, `--preview`, `--theme`) |
| `am rainbow TEXT` | Gradient color sweep (`--gradient rainbow/fire/ocean/sunset`, `--vertical`) |
| `am neon TEXT` | Neon glow shadow effect (`--color`, `--glow`, `--theme`) |
| `am animate TEXT` | Live animated color cycling (`--gradient`, `--speed`, `--frames`) |
| `am signature NAME` | Name art + title divider + box + animal (`--title`, `--animal`, `--theme`) |

### Compositions

| Command | Description |
|---------|-------------|
| `am banner TITLE` | Banner with box frame, animal, logo, themes (`--subtitle`, `--theme`, `--animal`, `--logo`, `--corner`) |
| `am combo ANIMAL TEXT` | Animal + text side by side or stacked (`--layout side/stack`, `--flip`) |
| `am logo BRAND` | Built-in brand logos: python, docker, github, linux, rust, nodejs, git, aws, react… |

### Classic Tools

| Command | Description |
|---------|-------------|
| `am box TEXT` | Wrap text in a Unicode/ASCII box (`--style`, `--title`) |
| `am divider STYLE` | Divider line (`thin`, `thick`, `double`, `dots`, …) |
| `am table` | Box-drawing table from `--header` / `--row` flags |
| `am tree PATH` | Directory tree structure |
| `am chart bar` | Vertical bar chart |
| `am chart hbar` | Horizontal bar chart |
| `am chart spark` | Single-line sparkline (▁▂▃▄▅▆▇█) |
| `am chart pie` | ASCII pie chart |
| `am mermaid TEMPLATE` | Mermaid diagram template |
| `am readme` | Generate README sections and badges |

### Export (9 formats)

```bash
am export html  "COMMAND"  [--out file.html]   # Colored standalone HTML
am export svg   "COMMAND"  [--out file.svg]    # Scalable SVG
am export text  "COMMAND"  [--out file.txt]    # Plain text, no ANSI
am export bash  "COMMAND"  [--out file.sh]     # Runnable bash heredoc
am export py    "COMMAND"  [--out file.py]     # Python script
am export md    "COMMAND"  [--no-fence]        # Markdown ```ansi fence
am export shellrc "COMMAND" [--shell zsh] [--install]  # ~/.bashrc snippet
am export motd  "COMMAND"  [--install]         # /etc/motd (MOTD)
am export inject FILE "COMMAND" [--position bottom]    # Inject into script
```

### Favorites

```bash
am fav list                     # List all saved favorites
am fav show NAME                # Display a favorite
am fav copy NAME                # Copy to clipboard
am fav delete NAME              # Delete a favorite
am banner "X" --save myname     # Save from any art command
```

## Color themes

`fire` · `ocean` · `neon` · `forest` · `gold` · `royal` · `mono` · `retro`

```bash
am rainbow "FIRE" --gradient fire
am neon "GLOW" --theme neon
am banner "APP" --theme ocean
am combo dragon "DOOM" --theme fire
```

## Gradient presets

`rainbow` · `fire` · `ocean` · `sunset`

```bash
am rainbow "SUNSET" --gradient sunset --vertical
am animate "WAVE" --gradient ocean --speed 0.05
```

## Animals (30 built-in)

```bash
am animals                      # List all animals
am animals --search dragon      # Search by name
am animals --random             # Print a random animal
am combo fox "Hello World"      # Side by side with text
```

## Box styles

```bash
am box --list-styles             # see all styles
am box "text" --style heavy      # heavy, rounded, double, ascii, ...
```

## Font picker

```bash
am text "Hello" --pick           # interactive picker
am text "Hello" --preview        # preview in favorite fonts
am text "Hello" --list-fonts     # list all pyfiglet fonts
```

## Piping

```bash
echo "output" | am box
cat notes.txt | am box --style double --title "Notes"
```

## Global flags

Add `--copy` to any command to copy the result to the clipboard.
Add `--save NAME` to `am banner`, `am combo`, `am logo`, `am signature` to save to favorites.

## Requirements

- Python ≥ 3.10
- `click`, `rich`, `pyfiglet`, `httpx`, `beautifulsoup4`, `pyperclip`

## License

MIT
