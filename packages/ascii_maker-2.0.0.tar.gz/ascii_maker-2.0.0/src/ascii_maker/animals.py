"""Built-in ASCII art animal and symbol library."""
from __future__ import annotations
import random
from ascii_maker.compose import Block, from_string

ANIMALS: dict[str, dict] = {
    "cat": {
        "art": " /\\_/\\ \n( o.o )\n > ^ < ",
        "tags": ["cute", "small", "classic"],
    },
    "dog": {
        "art": "  / \\__\n (    @\\___\n /         O\n/   (_____/\n/_____/   U",
        "tags": ["cute", "classic"],
    },
    "rabbit": {
        "art": " (\\(\\ \n( -.-)o\no_(\")(\")",
        "tags": ["cute", "small"],
    },
    "snake": {
        "art": "    /^\\/^\\\n  _|__|  O|\n\\/     /  \\/ \\\n \\____|__________/  \\\n          \\_______  \\",
        "tags": ["cool", "reptile"],
    },
    "dragon": {
        "art": "    / \\  //\\\n  |\\_/ |// \\\\\n  | \\_/   \\_/\n  \\  \\   /  /\n   \\  \\_/ /\n    \\  _ /\n     \\(O)/",
        "tags": ["cool", "fantasy", "big"],
    },
    "owl": {
        "art": "  ,___,\n  [O.O]\n  /)__)\n  -\"--\"-",
        "tags": ["cute", "bird", "small"],
    },
    "fox": {
        "art": "      /\\   /\\\n     /  \\_/  \\\n    |  (0 0)  |\n     \\  ___  /\n      \\_/-\\_/",
        "tags": ["cool", "cute"],
    },
    "bear": {
        "art": "  _   _\n \\( )/\n (o o)\n  |---|",
        "tags": ["cute", "classic"],
    },
    "shark": {
        "art": "         /\\\n        /  \\\n       / /\\ \\\n______/ /  \\_\\______",
        "tags": ["cool", "dangerous"],
    },
    "penguin": {
        "art": "   _~_\n  (o o)\n /|=||=|\\\n  d     b",
        "tags": ["cute", "linux", "classic"],
    },
    "unicorn": {
        "art": "       /)\n  ,-\"(('-||\n (      \\ \\\n  \\     /  |\n   `---'  /\n    ||\\  /\n    || \\/ ",
        "tags": ["cute", "fantasy", "cool"],
    },
    "wolf": {
        "art": "         __\n        / _)\n   _.---/_(__\n /'           \\\n /   ,-\"^\"-.  \\\n|   /       \\  |\n \\  \\       /  /\n  `-._____.-'",
        "tags": ["cool", "big"],
    },
    "octopus": {
        "art": "  _____\n /     \\\n| () () |\n \\  ^  /\n  ||||||\n  ||||||\n  ||||||",
        "tags": ["cute", "ocean"],
    },
    "bee": {
        "art": "   / \\\n  ( o )\n /|_||\\\n| |   | |\n |_____|\n  \\___/",
        "tags": ["cute", "small", "insect"],
    },
    "butterfly": {
        "art": "  __  __\n /  \\/  \\\n|  \\/\\/ |\n \\  /\\  /\n  \\/  \\/",
        "tags": ["cute", "small", "insect"],
    },
    "turtle": {
        "art": "   __\n.-'  '-.._\n|  .-. |  |\n'. '_' .--'\n  '-...-'",
        "tags": ["cute", "slow"],
    },
    "eagle": {
        "art": "    _\n  _/ \\\n /    \\___\n|    /  .-\\\n |  / ,-'  |\n  --'      |",
        "tags": ["cool", "bird", "big"],
    },
    "dino": {
        "art": "      __\n     / _)\n_.--/ /\n(_(_/ (",
        "tags": ["cool", "big", "classic"],
    },
    "fish": {
        "art": "    o\n >=>====>\n    o",
        "tags": ["cute", "small", "ocean"],
    },
    "frog": {
        "art": "  @..@\n (---)\n(.>__<.)\n^^^  ^^^",
        "tags": ["cute", "small"],
    },
    "skull": {
        "art": "  ___\n /   \\\n| () |\n|  A  |\n|_____|\n |___|",
        "tags": ["cool", "dark", "symbol"],
    },
    "crown": {
        "art": "| \\/ |\n\\_/\\_/",
        "tags": ["symbol", "cool"],
    },
    "star": {
        "art": "  *\n***\n *",
        "tags": ["symbol", "small"],
    },
    "lightning": {
        "art": " /|\n/ |\n  |\\\n  | \\",
        "tags": ["symbol", "cool"],
    },
    "flame": {
        "art": "  ) )\n )) ))\n(  ( ))\n )\\  /(\n(__\\/",
        "tags": ["symbol", "cool", "fire"],
    },
    "robot": {
        "art": " _____\n|     |\n| o o |\n|  _  |\n|_|_|_|",
        "tags": ["symbol", "cool", "tech"],
    },
    "rocket": {
        "art": "   /\\\n  /  \\\n |    |\n  \\  /\n  /  \\\n /____\\",
        "tags": ["symbol", "cool", "space"],
    },
    "heart": {
        "art": " _  _\n( \\/ )\n \\  /\n  \\/",
        "tags": ["symbol", "cute", "love"],
    },
    "ghost": {
        "art": "  .--.\n / .. \\\n|      |\n|  __  |\n /    \\ \n/||  ||\\ ",
        "tags": ["symbol", "cool", "spooky"],
    },
    "sword": {
        "art": "    |\n    |\n    |\n   /|\n  / |\n /  |\n/____|",
        "tags": ["symbol", "cool", "weapon"],
    },
}


def get_animal(name: str) -> Block:
    """Retrieve an animal/symbol Block by name. Raises KeyError if not found."""
    if name not in ANIMALS:
        raise KeyError(f"Unknown animal/symbol: {name!r}. Use 'am animals' to list all.")
    return from_string(ANIMALS[name]["art"])


def list_animals() -> list[str]:
    """Return all animal/symbol names."""
    return list(ANIMALS.keys())


def search_animals(tag: str) -> list[str]:
    """Return names of animals/symbols that have the given tag."""
    return [name for name, data in ANIMALS.items() if tag in data.get("tags", [])]


def random_animal() -> Block:
    """Return a random animal Block."""
    name = random.choice(list(ANIMALS.keys()))
    return get_animal(name)
