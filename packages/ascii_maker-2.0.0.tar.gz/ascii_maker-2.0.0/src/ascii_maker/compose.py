"""Composition pipeline for ascii-maker — Block dataclass and layout operations."""
from __future__ import annotations
from dataclasses import dataclass, field


THEMES: dict[str, list[str]] = {
    "fire":   ["bright_red", "red", "yellow"],
    "ocean":  ["bright_blue", "blue", "cyan"],
    "neon":   ["bright_cyan", "bright_magenta", "bright_green"],
    "forest": ["green", "bright_green", "yellow"],
    "gold":   ["yellow", "bright_yellow", "white"],
    "royal":  ["magenta", "bright_magenta", "cyan"],
    "mono":   ["white", "bright_white"],
    "retro":  ["bright_yellow", "yellow", "bright_red"],
}


@dataclass
class Block:
    """A rectangular piece of ASCII art — raw lines with no Rich markup."""
    lines: list[str] = field(default_factory=list)
    color: str = ""
    label: str = ""


def from_string(s: str, color: str = "") -> Block:
    """Build a Block from a multi-line string."""
    return Block(lines=s.splitlines(), color=color)


def to_string(block: Block) -> str:
    """Join block lines into a single string."""
    return "\n".join(block.lines)


def block_width(block: Block) -> int:
    """Max line width of the block."""
    return max((len(line) for line in block.lines), default=0)


def block_height(block: Block) -> int:
    """Number of lines in the block."""
    return len(block.lines)


def pad_to_height(block: Block, height: int) -> Block:
    """Pad block with empty lines at bottom to reach target height."""
    lines = list(block.lines)
    while len(lines) < height:
        lines.append("")
    return Block(lines=lines, color=block.color, label=block.label)


def pad_to_width(block: Block, width: int) -> Block:
    """Pad each line to target width with spaces."""
    lines = [line.ljust(width) for line in block.lines]
    return Block(lines=lines, color=block.color, label=block.label)


def side_by_side(left: Block, right: Block, gap: int = 2) -> Block:
    """Merge two blocks horizontally, vertically centered."""
    height = max(block_height(left), block_height(right))
    l = pad_to_height(pad_to_width(left, block_width(left)), height)
    r = pad_to_height(right, height)
    spacer = " " * gap
    lines = [l.lines[i] + spacer + r.lines[i] for i in range(height)]
    return Block(lines=lines)


def stack(top: Block, bottom: Block, gap: int = 1, divider: str = "") -> Block:
    """Merge two blocks vertically."""
    lines = list(top.lines)
    if divider:
        lines.append(divider)
    else:
        lines.extend([""] * gap)
    lines.extend(bottom.lines)
    return Block(lines=lines)


def colorize(block: Block, color: str) -> str:
    """Return block as a Rich-markup string with color applied."""
    text = to_string(block)
    if not color:
        return text
    return f"[{color}]{text}[/{color}]"


def embed(outer: Block, inner: "Block | str", position: str = "corners") -> Block:
    """Place inner element inside or around outer block.

    Positions:
      "corners"   — place inner[0] char at all 4 corners (inner must be str or 1-char)
      "top-left"  — place inner[0] char at top-left corner only
      "top-right" — place inner[0] char at top-right corner only
      "header"    — prepend inner Block above outer (inner must be Block)
      "footer"    — append inner Block below outer (inner must be Block)
    """
    lines = [list(line) for line in outer.lines]

    if position in ("corners", "top-left", "top-right"):
        char = inner[0] if isinstance(inner, str) else to_string(inner)[0]
        h = len(lines)
        if h == 0:
            return outer

        def _set(row: int, col: int, c: str) -> None:
            if 0 <= row < len(lines) and 0 <= col < len(lines[row]):
                lines[row][col] = c

        if position in ("corners", "top-left"):
            _set(0, 0, char)
        if position in ("corners", "top-right"):
            _set(0, len(lines[0]) - 1, char)
        if position == "corners":
            _set(h - 1, 0, char)
            _set(h - 1, len(lines[h - 1]) - 1, char)

        return Block(lines=["".join(row) for row in lines],
                     color=outer.color, label=outer.label)

    if position == "header":
        assert isinstance(inner, Block), "header position requires a Block"
        return Block(lines=inner.lines + outer.lines,
                     color=outer.color, label=outer.label)

    if position == "footer":
        assert isinstance(inner, Block), "footer position requires a Block"
        return Block(lines=outer.lines + inner.lines,
                     color=outer.color, label=outer.label)

    raise ValueError(f"Unknown embed position: {position!r}")


GRADIENTS: dict[str, list[str]] = {
    "rainbow": ["red", "yellow", "green", "cyan", "blue", "magenta"],
    "fire":    ["red", "bright_red", "yellow", "bright_yellow"],
    "ocean":   ["blue", "bright_blue", "cyan", "bright_cyan"],
    "sunset":  ["red", "magenta", "bright_red", "yellow"],
}


def apply_gradient(block: Block, gradient: str = "rainbow", vertical: bool = False) -> str:
    """Apply a left-to-right (or top-to-bottom) color gradient to a Block.

    Returns a Rich markup string — use with console.print().
    Space characters are not wrapped (preserves spacing).
    """
    colors = GRADIENTS.get(gradient, GRADIENTS["rainbow"])
    result_lines = []

    for row_idx, line in enumerate(block.lines):
        parts = []
        for col_idx, char in enumerate(line):
            if char == " ":
                parts.append(" ")
            else:
                idx = row_idx if vertical else col_idx
                color = colors[idx % len(colors)]
                parts.append(f"[{color}]{char}[/{color}]")
        result_lines.append("".join(parts))

    return "\n".join(result_lines)


def apply_neon(block: Block, color: str = "bright_cyan", glow: str = "magenta") -> str:
    """Apply neon glow effect — bright primary art with dim shadow offset by 1 char.

    Output is H+1 rows tall and W+1 cols wide (shadow extends right and down by 1).
    Returns a Rich markup string.
    """
    src_lines = block.lines
    H = len(src_lines)
    W = max((len(line) for line in src_lines), default=0)
    out_H = H + 1
    out_W = W + 1

    # Build output grid as list of lists of (char, style) pairs
    grid: list[list[tuple[str, str]]] = [[(" ", "") for _ in range(out_W)] for _ in range(out_H)]

    # Place shadow layer first (can be overwritten by primary)
    for row, line in enumerate(src_lines):
        for col, char in enumerate(line):
            if char != " " and col + 1 < out_W and row + 1 < out_H:
                grid[row + 1][col + 1] = (char, glow)

    # Place primary art on top (takes priority)
    for row, line in enumerate(src_lines):
        for col, char in enumerate(line):
            if char != " " and col < out_W and row < out_H:
                grid[row][col] = (char, color)

    # Build Rich markup string
    result_lines = []
    for row in grid:
        parts = []
        for char, style in row:
            if style:
                parts.append(f"[{style}]{char}[/{style}]")
            else:
                parts.append(char)
        result_lines.append("".join(parts))

    return "\n".join(result_lines)
