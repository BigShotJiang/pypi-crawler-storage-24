"""Favorites storage — save, list, retrieve, and delete named ASCII art creations."""
from __future__ import annotations
import json
from datetime import datetime
from pathlib import Path

FAV_FILE: Path = Path.home() / ".ascii_maker_favs.json"


def _load() -> list[dict]:
    if not FAV_FILE.exists():
        return []
    try:
        return json.loads(FAV_FILE.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return []


def _save_all(entries: list[dict]) -> None:
    FAV_FILE.write_text(json.dumps(entries, indent=2, ensure_ascii=False), encoding="utf-8")


def save_fav(name: str, command: str, output: str) -> None:
    """Save or overwrite a favorite entry."""
    entries = [e for e in _load() if e.get("name") != name]
    entries.append({
        "name": name,
        "command": command,
        "output": output,
        "created_at": datetime.now().isoformat(timespec="seconds"),
    })
    _save_all(entries)


def list_favs() -> list[dict]:
    """Return all saved favorites as a list of dicts."""
    return _load()


def get_fav(name: str) -> dict | None:
    """Return a single favorite by name, or None if not found."""
    return next((e for e in _load() if e.get("name") == name), None)


def delete_fav(name: str) -> None:
    """Delete a favorite by name. Raises KeyError if not found."""
    entries = _load()
    filtered = [e for e in entries if e.get("name") != name]
    if len(filtered) == len(entries):
        raise KeyError(f"No favorite named {name!r}")
    _save_all(filtered)
