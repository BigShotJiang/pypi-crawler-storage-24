"""ascii-maker CLI — `am` entry point."""
from __future__ import annotations

import sys
from datetime import datetime
from pathlib import Path

import click
from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax
from rich.table import Table
from rich import box as rbox

console = Console()


# ─── Root group ───────────────────────────────────────────────────────────────

@click.group()
@click.version_option("1.0.0", prog_name="ascii-maker")
def cli():
    """ascii-maker (am) — ASCII art designer, chart builder, and README toolkit."""


# ─── TEXT command ──────────────────────────────────────────────────────────────

@cli.command("text")
@click.argument("text")
@click.option("-f", "--font", default="slant", show_default=True, help="Figlet font name")
@click.option("-p", "--pick", is_flag=True, help="Interactive font/color picker")
@click.option("--preview", is_flag=True, help="Preview text in all favorite fonts")
@click.option("--list-fonts", is_flag=True, help="List all available fonts")
@click.option("-g", "--group", default=None, help="Font group for --list-fonts or --preview")
@click.option("--copy", is_flag=True, help="Copy result to clipboard")
@click.option("--theme", default="", help="Color theme for preview (fire/ocean/neon/etc.)")
@click.option("--color", "color", default="", help="Color for preview or rendered output")
@click.option("--animal", "preview_animal", default="", help="Show this animal beside each preview")
@click.option("--no-pager", is_flag=True, help="Disable pause every 5 entries in preview")
@click.option("--limit", default=30, show_default=True, help="Max fonts in --preview")
def cmd_text(text, font, pick, preview, list_fonts, group, copy, theme, color, preview_animal, no_pager, limit):
    """Render TEXT as ASCII art using pyfiglet fonts."""
    from ascii_maker.text_art import render, render_colored, interactive_font_picker, list_fonts as lf

    if list_fonts:
        lf(group)
        return

    if preview:
        import pyfiglet
        from ascii_maker.text_art import FAVORITE_FONTS, FONT_GROUPS
        from ascii_maker.compose import side_by_side, colorize, from_string, THEMES

        use_fonts = FONT_GROUPS.get(group, FAVORITE_FONTS) if group else FAVORITE_FONTS
        effective_color = color or (THEMES.get(theme, [""])[0] if theme else "")

        # Load animal block once if requested
        animal_block = None
        if preview_animal:
            try:
                from ascii_maker.animals import get_animal
                animal_block = get_animal(preview_animal)
            except KeyError as e:
                console.print(f"[yellow]Warning: {e}[/]")

        for i, f in enumerate(use_fonts[:limit], 1):
            try:
                art_str = pyfiglet.figlet_format(text, font=f)
                art_block = from_string(art_str.rstrip())

                if animal_block:
                    composed = side_by_side(animal_block, art_block, gap=2)
                    display = colorize(composed, effective_color) if effective_color else "\n".join(composed.lines)
                else:
                    display = colorize(art_block, effective_color) if effective_color else art_str.rstrip()

                console.print(Panel(display, title=f"[yellow]{f}[/]", border_style="dim"))
            except Exception:
                pass

            if not no_pager and i % 5 == 0 and i < len(use_fonts[:limit]):
                try:
                    cont = console.input("[dim]── Enter for more, q to quit ──[/] ").strip()
                    if cont.lower() == "q":
                        break
                except EOFError:
                    break
        return

    if pick:
        art, chosen_font, chosen_color = interactive_font_picker(text)
        console.print(render_colored(text, chosen_font, chosen_color))
        console.print(f"[dim]Font: {chosen_font}[/]")
    else:
        art = render(text, font)
        console.print(art)

    if copy:
        try:
            import pyperclip
            pyperclip.copy(art)
            console.print("[dim]Copied to clipboard.[/]")
        except Exception:
            console.print("[yellow]pyperclip not available; install it to enable clipboard.[/]")


# ─── BROWSE command ────────────────────────────────────────────────────────────

@cli.command("browse")
@click.argument("category", default="")
@click.option("-n", "--limit", default=20, show_default=True, help="Max results to show")
@click.option("--no-pager", is_flag=True, help="Disable interactive pager")
@click.option("--copy-last", is_flag=True, help="Copy last displayed art to clipboard")
def cmd_browse(category, limit, no_pager, copy_last):
    """Browse ASCII art from asciiart.eu by CATEGORY.

    Leave CATEGORY blank to see all available categories.
    """
    from ascii_maker.browser import fetch_category, browse_interactive, display_arts, search_online

    if not category:
        browse_interactive()
        return

    arts = fetch_category(category, limit=limit)
    last = display_arts(arts, pager=not no_pager)

    if copy_last and last:
        try:
            import pyperclip
            pyperclip.copy(last)
            console.print("[dim]Last art copied to clipboard.[/]")
        except Exception:
            console.print("[yellow]pyperclip not available.[/]")


@cli.command("search")
@click.argument("query")
@click.option("-n", "--limit", default=10, show_default=True)
def cmd_search(query, limit):
    """Search ASCII art by keyword."""
    from ascii_maker.browser import search_online, display_arts
    arts = search_online(query)
    display_arts(arts[:limit])


# ─── ANIMALS command ───────────────────────────────────────────────────────────

@cli.command("animals")
@click.argument("name", default="")
@click.option("--search", "tag", default="", help="Filter by tag (e.g. cute, cool, symbol)")
@click.option("--symbols", is_flag=True, help="Show only symbol/icon entries")
@click.option("--copy", is_flag=True, help="Copy art to clipboard")
def cmd_animals(name, tag, symbols, copy):
    """Browse the built-in animal and symbol art library.

    Leave NAME blank to show all. Use --search TAG to filter by tag.

    Examples:
      am animals
      am animals cat
      am animals --search cute
      am animals --symbols
    """
    from ascii_maker.animals import get_animal, list_animals, search_animals, ANIMALS
    from ascii_maker.compose import to_string

    if name:
        try:
            block = get_animal(name)
            console.print(Panel(to_string(block), title=f"[yellow]{name}[/]", border_style="cyan"))
            if copy:
                try:
                    import pyperclip; pyperclip.copy(to_string(block))
                    console.print("[dim]Copied.[/]")
                except Exception:
                    pass
        except KeyError as e:
            console.print(f"[red]{e}[/]")
            raise SystemExit(1)
        return

    if tag:
        names = search_animals(tag)
    elif symbols:
        names = [n for n, d in ANIMALS.items() if "symbol" in d.get("tags", [])]
    else:
        names = list_animals()

    if not names:
        console.print(f"[yellow]No entries found.[/]")
        return

    for i, n in enumerate(names, 1):
        block = get_animal(n)
        tags_str = ", ".join(ANIMALS[n].get("tags", []))
        console.print(Panel(
            to_string(block),
            title=f"[yellow]{n}[/] [dim]({tags_str})[/]",
            border_style="dim",
        ))
        if i % 5 == 0 and i < len(names):
            try:
                cont = console.input("[dim]── Enter for more, q to quit ──[/] ").strip()
            except (EOFError, Exception):
                break
            if cont.lower() == "q":
                break


# ─── LOGO command ──────────────────────────────────────────────────────────────

@cli.command("logo")
@click.argument("brand", default="")
@click.option("--list", "list_logos_flag", is_flag=True, help="List all built-in brands")
@click.option("--browse", is_flag=True, help="Browse logos from asciiart.eu")
@click.option("--filter", "filter_kw", default="", help="Filter online browse by keyword")
@click.option("--generate", "generate_text", default="", help="Generate logo from text")
@click.option("--font", default="", help="Font for --generate")
@click.option("--style", default="double", show_default=True, help="Box style for --generate")
@click.option("--theme", default="", help="Color theme name")
@click.option("--tagline", default="", help="Subtitle for --generate")
@click.option("--corner", default="", help="Corner character for --generate (e.g. ★)")
@click.option("--copy", is_flag=True)
@click.option("--save", "save_name", default="", help="Save to favorites")
def cmd_logo(brand, list_logos_flag, browse, filter_kw, generate_text,
             font, style, theme, tagline, corner, copy, save_name):
    """Built-in brand logos, online logo browser, and logo generator.

    Examples:
      am logo python
      am logo python --theme fire
      am logo --list
      am logo --browse --filter docker
      am logo --generate "MyApp" --theme neon --tagline "v2.0" --corner "★"
    """
    from ascii_maker.logos import get_logo, list_logos, LOGOS, generate_logo
    from ascii_maker.compose import to_string, colorize, THEMES

    def _display(block, label=""):
        color = THEMES.get(theme, [""])[0] if theme else ""
        text = colorize(block, color) if color else to_string(block)
        console.print(Panel(text, title=f"[yellow]{label}[/]" if label else "", border_style="cyan"))
        if copy:
            try:
                import pyperclip; pyperclip.copy(to_string(block))
                console.print("[dim]Copied.[/]")
            except Exception:
                pass

    if list_logos_flag:
        table = Table(title="Built-in Logos", box=rbox.SIMPLE)
        table.add_column("Brand", style="cyan")
        table.add_column("Tags", style="dim")
        table.add_column("Default Theme")
        for name, data in LOGOS.items():
            table.add_row(name, ", ".join(data.get("tags", [])), data.get("default_theme", ""))
        console.print(table)
        return

    if browse:
        from ascii_maker.browser import fetch_category, display_arts
        try:
            arts = fetch_category("logos", limit=20)
            if filter_kw:
                arts = [a for a in arts if filter_kw.lower() in a.get("title", "").lower()]
            display_arts(arts)
        except Exception as e:
            console.print(f"[yellow]Browse failed: {e}[/]")
        return

    if generate_text:
        block = generate_logo(generate_text, font=font, style=style,
                              theme=theme, tagline=tagline, corner=corner)
        _display(block, label=f"Generated: {generate_text}")
        if save_name:
            from ascii_maker.fav import save_fav
            save_fav(save_name, f"logo {brand or generate_text}", to_string(block))
            console.print(f"[dim]Saved as '{save_name}'.[/]")
        return

    if brand:
        try:
            block = get_logo(brand)
            auto_theme = LOGOS[brand].get("default_theme", "")
            effective_theme = theme or auto_theme
            color = THEMES.get(effective_theme, [""])[0] if effective_theme else ""
            text = colorize(block, color) if color else to_string(block)
            console.print(Panel(text, title=f"[yellow]{brand}[/]", border_style="cyan"))
            if copy:
                try:
                    import pyperclip; pyperclip.copy(to_string(block))
                    console.print("[dim]Copied.[/]")
                except Exception:
                    pass
        except KeyError as e:
            console.print(f"[red]{e}[/]")
            raise SystemExit(1)
        if save_name:
            from ascii_maker.fav import save_fav
            save_fav(save_name, f"logo {brand or generate_text}", to_string(block))
            console.print(f"[dim]Saved as '{save_name}'.[/]")
        return

    console.print("[dim]Use 'am logo --list' to see built-in brands, or 'am logo --generate TEXT' to create one.[/]")


# ─── BOX command ──────────────────────────────────────────────────────────────

@cli.command("box")
@click.argument("text", nargs=-1)
@click.option("-s", "--style", default="rounded", show_default=True, help="Box style")
@click.option("-t", "--title", default="", help="Box title")
@click.option("-p", "--padding", default=1, show_default=True)
@click.option("--list-styles", is_flag=True, help="List all available box styles")
@click.option("--copy", is_flag=True)
def cmd_box(text, style, title, padding, list_styles, copy):
    """Wrap TEXT in an ASCII/Unicode box.

    Pipe input or pass words as arguments.
    Example:  am box "Hello world"  or  echo "hi" | am box
    """
    from ascii_maker.boxes import make_box, list_styles as ls

    if list_styles:
        console.print(ls())
        return

    if not text and not sys.stdin.isatty():
        content = sys.stdin.read()
    else:
        content = " ".join(text)

    lines = content.splitlines() if content else [""]
    result = make_box(lines, style=style, title=title, padding=padding)
    console.print(result)

    if copy:
        try:
            import pyperclip; pyperclip.copy(result)
            console.print("[dim]Copied.[/]")
        except Exception:
            pass


@cli.command("divider")
@click.argument("style", default="thin")
@click.option("-l", "--label", default="", help="Optional center label")
@click.option("-w", "--width", default=60, show_default=True)
@click.option("--list", "list_divs", is_flag=True, help="List all divider styles")
def cmd_divider(style, label, width, list_divs):
    """Print a divider line.

    STYLE can be: thin, thick, double, dash, dots, shade, flowers, etc.
    """
    from ascii_maker.boxes import make_divider, DIVIDERS, SECTION_DIVIDERS

    if list_divs:
        table = Table(title="Divider Styles", box=rbox.SIMPLE)
        table.add_column("Key", style="cyan")
        table.add_column("Preview")
        for k, v in DIVIDERS.items():
            table.add_row(k, v[:50])
        for k in SECTION_DIVIDERS:
            table.add_row(f"{k} (label)", f"← use with -l 'My Label'")
        console.print(table)
        return

    result = make_divider(style, label=label, width=width)
    console.print(result)


@cli.command("table")
@click.option("-s", "--style", default="single", show_default=True, help="Box style")
@click.option("--header", multiple=True, help="Column headers (repeat flag)")
@click.option("--row", multiple=True, help="Row values as comma-separated (repeat flag)")
def cmd_table(style, header, row):
    """Generate a box-drawing table.

    Example:
      am table --header Name --header Age --header City
               --row "Alice,30,NYC" --row "Bob,25,LA"
    """
    from ascii_maker.boxes import make_table

    if not header:
        console.print("[red]Provide at least one --header[/]")
        return

    headers = list(header)
    rows = [r.split(",") for r in row]
    result = make_table(headers, rows, style=style)
    console.print(result)


@cli.command("tree")
@click.argument("path", default=".")
@click.option("-d", "--depth", default=3, show_default=True, help="Max depth")
def cmd_tree(path, depth):
    """Render a directory as a tree structure."""
    import os
    from ascii_maker.boxes import make_tree

    def scan(p: str, d: int) -> dict | list:
        if d == 0 or not os.path.isdir(p):
            return []
        result = {}
        try:
            entries = sorted(os.listdir(p))
        except PermissionError:
            return []
        for entry in entries:
            if entry.startswith("."):
                continue
            full = os.path.join(p, entry)
            if os.path.isdir(full):
                result[entry] = scan(full, d - 1)
            else:
                result[entry] = ""
        return result

    tree = scan(path, depth)
    console.print(f"[bold]{path}[/]")
    console.print(make_tree(tree))


# ─── CHART commands ────────────────────────────────────────────────────────────

@cli.group("chart")
def cmd_chart():
    """Generate ASCII charts."""


@cmd_chart.command("bar")
@click.argument("values", nargs=-1, type=float)
@click.option("-l", "--labels", default="", help="Comma-separated labels")
@click.option("-t", "--title", default="")
@click.option("-H", "--height", default=15, show_default=True)
@click.option("-w", "--bar-width", default=5, show_default=True)
def chart_bar(values, labels, title, height, bar_width):
    """Vertical bar chart. Pass VALUES as space-separated numbers."""
    from ascii_maker.charts import bar_chart
    if not values:
        console.print("[red]Provide at least one value[/]")
        return
    lbls = [l.strip() for l in labels.split(",")] if labels else None
    console.print(bar_chart(list(values), lbls, title=title, height=height, bar_width=bar_width))


@cmd_chart.command("hbar")
@click.argument("values", nargs=-1, type=float)
@click.option("-l", "--labels", default="", help="Comma-separated labels")
@click.option("-t", "--title", default="")
@click.option("-w", "--width", default=40, show_default=True)
def chart_hbar(values, labels, title, width):
    """Horizontal bar chart."""
    from ascii_maker.charts import hbar_chart
    if not values:
        console.print("[red]Provide at least one value[/]")
        return
    lbls = [l.strip() for l in labels.split(",")] if labels else None
    console.print(hbar_chart(list(values), lbls, title=title, max_width=width))


@cmd_chart.command("line")
@click.argument("values", nargs=-1, type=float)
@click.option("-l", "--labels", default="")
@click.option("-t", "--title", default="")
@click.option("-H", "--height", default=12, show_default=True)
@click.option("-w", "--width", default=60, show_default=True)
def chart_line(values, labels, title, height, width):
    """Line / scatter chart."""
    from ascii_maker.charts import line_chart
    if not values:
        console.print("[red]Provide at least one value[/]")
        return
    lbls = [l.strip() for l in labels.split(",")] if labels else None
    console.print(line_chart(list(values), lbls, title=title, height=height, width=width))


@cmd_chart.command("spark")
@click.argument("values", nargs=-1, type=float)
@click.option("-t", "--title", default="")
def chart_spark(values, title):
    """Single-line sparkline using block chars ▁▂▃▄▅▆▇█."""
    from ascii_maker.charts import sparkline
    if not values:
        console.print("[red]Provide at least one value[/]")
        return
    console.print(sparkline(list(values), title=title))


@cmd_chart.command("pie")
@click.argument("values", nargs=-1, type=float)
@click.option("-l", "--labels", default="")
@click.option("-t", "--title", default="")
def chart_pie(values, labels, title):
    """ASCII pie chart."""
    from ascii_maker.charts import pie_chart
    if not values:
        console.print("[red]Provide at least one value[/]")
        return
    lbls = [l.strip() for l in labels.split(",")] if labels else None
    console.print(pie_chart(list(values), lbls, title=title))


@cmd_chart.command("progress")
@click.argument("value", type=float)
@click.option("-T", "--total", default=100.0, show_default=True)
@click.option("-l", "--label", default="")
@click.option("-w", "--width", default=40, show_default=True)
def chart_progress(value, total, label, width):
    """Single progress bar."""
    from ascii_maker.charts import progress_bar
    console.print(progress_bar(value, total, width=width, label=label))


# ─── MERMAID command ───────────────────────────────────────────────────────────

@cli.command("mermaid")
@click.argument("template", default="")
@click.option("--list", "list_tmpl", is_flag=True, help="List all available templates")
@click.option("--fence", is_flag=True, default=True, show_default=True, help="Wrap in ```mermaid fences")
@click.option("--no-fence", "fence", flag_value=False)
@click.option("--copy", is_flag=True)
def cmd_mermaid(template, list_tmpl, fence, copy):
    """Show or copy a Mermaid diagram template.

    TEMPLATE: flowchart, sequence, class, er, gantt, state, pie, git, mindmap, timeline, ...
    """
    from ascii_maker.mermaid import list_templates, get_template, wrap_in_fence, TEMPLATES

    if list_tmpl or not template:
        console.print(list_templates())
        return

    content = get_template(template)
    if content is None:
        console.print(f"[red]Unknown template '{template}'. Run 'am mermaid --list' to see options.[/]")
        return

    output = wrap_in_fence(content) if fence else content
    syntax = Syntax(output, "markdown", theme="monokai", line_numbers=False)
    console.print(syntax)

    if copy:
        try:
            import pyperclip; pyperclip.copy(output)
            console.print("[dim]Copied to clipboard.[/]")
        except Exception:
            pass


# ─── README command ────────────────────────────────────────────────────────────

@cli.group("readme")
def cmd_readme():
    """README section and badge generators."""


@cmd_readme.command("badge")
@click.argument("preset", default="")
@click.option("--list", "list_badges", is_flag=True)
@click.option("--label", default="", help="Custom badge label")
@click.option("--message", default="", help="Custom badge message")
@click.option("--color", default="blue", show_default=True)
def readme_badge(preset, list_badges, label, message, color):
    """Generate a shields.io badge.

    PRESET: maintained, made-with-python, docker, contributions-welcome, ...
    """
    from ascii_maker.readme import BADGE_PRESETS, badge as mk_badge

    if list_badges or not (preset or label):
        table = Table(title="Badge Presets", box=rbox.SIMPLE)
        table.add_column("Key", style="cyan")
        table.add_column("Markdown")
        for k, v in BADGE_PRESETS.items():
            table.add_row(k, v[:80])
        console.print(table)
        return

    if label and message:
        result = mk_badge(label, message, color)
    else:
        result = BADGE_PRESETS.get(preset, "")
        if not result:
            console.print(f"[red]Unknown preset '{preset}'[/]")
            return

    console.print(result)


@cmd_readme.command("section")
@click.argument("kind")
@click.option("--title", default="")
@click.option("--items", default="", help="Comma-separated list items")
def readme_section(kind, title, items):
    """Generate a README section.

    KIND: features, toc, contributing, license, roadmap, quick-start
    """
    from ascii_maker.readme import (
        features_section, toc, contributing_section,
        license_section, roadmap_section
    )

    item_list = [i.strip() for i in items.split(",") if i.strip()]

    generators = {
        "features": lambda: features_section(item_list, title=title or "Features"),
        "toc": lambda: toc(item_list),
        "contributing": lambda: contributing_section(),
        "license": lambda: license_section(),
        "roadmap": lambda: roadmap_section(item_list[:len(item_list)//2], item_list[len(item_list)//2:]),
    }

    fn = generators.get(kind)
    if fn is None:
        console.print(f"[red]Unknown section kind '{kind}'[/]")
        console.print("Available: " + ", ".join(generators))
        return

    console.print(fn())


@cmd_readme.command("build")
@click.option("--title", prompt="Project title", help="README title")
@click.option("--description", prompt="Short description", help="One-line description")
@click.option("--package", default="", help="PyPI package name (for install section)")
@click.option("--author", default="", help="Author name")
@click.option("-o", "--output", default="README.md", show_default=True, help="Output file")
def readme_build(title, description, package, author, output):
    """Interactively generate a complete README.md."""
    from ascii_maker.readme import build_readme, badge_python, badge_license

    badges = [badge_python(), badge_license()]

    features_raw = click.prompt(
        "Features (comma-separated, or press Enter to skip)", default="", show_default=False
    )
    features = [f.strip() for f in features_raw.split(",") if f.strip()] or None

    content = build_readme(
        title=title,
        description=description,
        features=features,
        install_cmd=package or title.lower().replace(" ", "-"),
        author=author,
        badges=badges,
    )

    with open(output, "w") as f:
        f.write(content)

    console.print(f"[green]✓ README written to {output}[/]")
    console.print(f"  {len(content.splitlines())} lines, {len(content)} bytes")


# ─── BANNER command ────────────────────────────────────────────────────────────

@cli.command("banner")
@click.argument("title")
@click.option("--subtitle", "--tagline", default="", help="Subtitle / tagline line")
@click.option("-f", "--font", default="slant", show_default=True)
@click.option("-s", "--style", default="double", show_default=True)
@click.option("--theme", default="", help="Color theme name")
@click.option("--color", default="", help="Primary text color override")
@click.option("--animal", "animal_name", default="", help="Animal companion name")
@click.option("--layout", default="side",
              type=click.Choice(["side", "stack", "embed", "frame"]),
              show_default=True)
@click.option("--logo", "logo_name", default="", help="Built-in logo to embed above")
@click.option("--corner", default="", help="Character to place at all 4 box corners")
@click.option("--gap", default=2, show_default=True)
@click.option("--flip", is_flag=True, help="Flip animal to right side")
@click.option("--copy", is_flag=True)
@click.option("--save", "save_name", default="", help="Save to favorites")
def cmd_banner(title, subtitle, font, style, theme, color, animal_name, layout,
               logo_name, corner, gap, flip, copy, save_name):
    """Generate a CLI banner with optional animal, logo, and color theme.

    Examples:
      am banner "MyApp"
      am banner "MyApp" --theme neon --animal dragon --layout stack
      am banner "MyApp" --logo python --corner "★" --theme ocean
    """
    from ascii_maker.text_art import render
    from ascii_maker.boxes import make_box
    from ascii_maker.compose import (
        side_by_side, stack, embed, colorize, from_string, THEMES, block_width, Block
    )

    # 1. Render title art
    art_str = render(title, font).rstrip()
    text_block = from_string(art_str)

    # 2. Embed logo above if requested
    if logo_name:
        try:
            from ascii_maker.logos import get_logo
            logo_block = get_logo(logo_name)
            text_block = stack(logo_block, text_block, gap=1)
        except KeyError as e:
            console.print(f"[yellow]Warning: {e}[/]")

    # 3. Add subtitle/tagline
    if subtitle:
        text_block = stack(text_block, from_string(subtitle), gap=1)

    # 4. Wrap in box
    box_str = make_box(text_block.lines, style=style, padding=2)
    banner_block = from_string(box_str)

    # 5. Embed corner char
    if corner:
        banner_block = embed(banner_block, corner, position="corners")

    # 6. Animal companion
    if animal_name:
        animal_block = None
        try:
            from ascii_maker.animals import get_animal
            animal_block = get_animal(animal_name)
        except KeyError as e:
            console.print(f"[yellow]Warning: {e}[/]")

        if animal_block:
            if layout == "side":
                l, r = (animal_block, banner_block) if not flip else (banner_block, animal_block)
                banner_block = side_by_side(l, r, gap=gap)
            elif layout == "stack":
                t, b = (animal_block, banner_block) if not flip else (banner_block, animal_block)
                banner_block = stack(t, b, gap=1)
            elif layout == "embed":
                char = next((c for c in "\n".join(animal_block.lines) if c not in (" ", "\n")), "*")
                banner_block = embed(banner_block, char, position="corners")
            elif layout == "frame":
                w = block_width(banner_block)
                animal_line = (" ".join("".join(animal_block.lines[:1]).split()) + " ")
                tiled = (animal_line * (w // max(len(animal_line), 1) + 1))[:w]
                banner_block = Block(lines=[tiled] + banner_block.lines + [tiled])

    # 7. Colorize and print
    effective_color = color or (THEMES.get(theme, [""])[0] if theme else "")
    result_str = colorize(banner_block, effective_color) if effective_color else "\n".join(banner_block.lines)
    console.print(result_str)

    if save_name:
        from ascii_maker.fav import save_fav
        save_fav(save_name, f"banner {title}", "\n".join(banner_block.lines))
        console.print(f"[dim]Saved as '{save_name}'.[/]")

    if copy:
        try:
            import pyperclip; pyperclip.copy("\n".join(banner_block.lines))
            console.print("[dim]Copied.[/]")
        except Exception:
            pass


# ─── RAINBOW command ───────────────────────────────────────────────────────────

@cli.command("rainbow")
@click.argument("text")
@click.option("-f", "--font", default="slant", show_default=True)
@click.option("--gradient", default="rainbow", show_default=True,
              help="Gradient preset: rainbow, fire, ocean, sunset")
@click.option("--vertical", is_flag=True, help="Top-to-bottom gradient instead of left-to-right")
@click.option("--copy", is_flag=True)
def cmd_rainbow(text, font, gradient, vertical, copy):
    """Render ASCII art with a gradient color sweep.

    Examples:
      am rainbow "Hello World"
      am rainbow "Hello World" --font doom --gradient fire
      am rainbow "Hello World" --vertical
    """
    from ascii_maker.text_art import render
    from ascii_maker.compose import from_string, apply_gradient

    art_str = render(text, font).rstrip()
    art_block = from_string(art_str)
    output = apply_gradient(art_block, gradient, vertical=vertical)
    console.print(output)

    if copy:
        try:
            import pyperclip; pyperclip.copy(art_str)
            console.print("[dim]Copied (plain text).[/]")
        except Exception:
            pass


# ─── NEON command ──────────────────────────────────────────────────────────────

@cli.command("neon")
@click.argument("text")
@click.option("-f", "--font", default="slant", show_default=True)
@click.option("--color", default="bright_cyan", show_default=True, help="Primary art color")
@click.option("--glow", default="magenta", show_default=True, help="Shadow/glow color")
@click.option("--theme", default="", help="Color theme (sets color and glow automatically)")
@click.option("--copy", is_flag=True)
def cmd_neon(text, font, color, glow, theme, copy):
    """Render ASCII art with a neon glow shadow effect.

    Examples:
      am neon "Hello"
      am neon "Hello" --font doom --color bright_cyan --glow magenta
      am neon "Hello" --theme fire
    """
    from ascii_maker.text_art import render
    from ascii_maker.compose import from_string, apply_neon, THEMES

    if theme and theme in THEMES:
        colors = THEMES[theme]
        color = colors[0]
        glow = colors[1] if len(colors) > 1 else colors[0]

    art_str = render(text, font).rstrip()
    art_block = from_string(art_str)
    output = apply_neon(art_block, color=color, glow=glow)
    console.print(output)

    if copy:
        try:
            import pyperclip; pyperclip.copy(art_str)
            console.print("[dim]Copied (plain text).[/]")
        except Exception:
            pass


# ─── SIGNATURE command ─────────────────────────────────────────────────────────

@cli.command("signature")
@click.argument("name")
@click.option("--title", default="", help="Title line below name art")
@click.option("-f", "--font", default="slant", show_default=True, help="Figlet font name")
@click.option("-s", "--style", default="rounded", show_default=True, help="Box style")
@click.option("--theme", default="", help="Color theme name")
@click.option("--color", default="", help="Color override")
@click.option("--animal", "animal_name", default="", help="Animal companion name")
@click.option("--layout", default="side", type=click.Choice(["side", "stack"]), show_default=True)
@click.option("--copy", is_flag=True, help="Copy raw art to clipboard")
@click.option("--save", "save_name", default="", help="Save name for favorites (future use)")
def cmd_signature(name, title, font, style, theme, color, animal_name, layout, copy, save_name):
    """Generate a personal signature block with optional title and animal companion.

    Examples:
      am signature "Alice"
      am signature "Alice" --title "Senior Dev" --theme neon
      am signature "Alice" --animal fox --layout stack
    """
    from ascii_maker.text_art import render
    from ascii_maker.boxes import make_box
    from ascii_maker.compose import (
        side_by_side, stack, colorize, from_string, THEMES
    )

    # 1. Render name art
    art_str = render(name, font).rstrip()
    sig_block = from_string(art_str)

    # 2. If --title given, add divider line below name art, stack them
    if title:
        divider = "─" * max(len(line) for line in sig_block.lines)
        sig_block = stack(sig_block, from_string(divider + "\n" + title), gap=0)

    # 3. Wrap in box
    box_str = make_box(sig_block.lines, style=style, padding=1)
    sig_block = from_string(box_str)

    # 4. Animal companion
    if animal_name:
        try:
            from ascii_maker.animals import get_animal
            animal_block = get_animal(animal_name)
            if layout == "side":
                sig_block = side_by_side(animal_block, sig_block, gap=2)
            else:
                sig_block = stack(animal_block, sig_block, gap=1)
        except KeyError as e:
            console.print(f"[yellow]Warning: {e}[/]")

    # 5. Colorize and print
    effective_color = color or (THEMES.get(theme, [""])[0] if theme else "")
    result_str = colorize(sig_block, effective_color) if effective_color else "\n".join(sig_block.lines)
    console.print(result_str)

    if save_name:
        from ascii_maker.fav import save_fav
        save_fav(save_name, f"signature {name}", "\n".join(sig_block.lines))
        console.print(f"[dim]Saved as '{save_name}'.[/]")

    if copy:
        try:
            import pyperclip
            pyperclip.copy("\n".join(sig_block.lines))
            console.print("[dim]Copied.[/]")
        except Exception:
            console.print("[yellow]pyperclip not available; install it to enable clipboard.[/]")


# ─── ANIMATE command ────────────────────────────────────────────────────────────

@cli.command("animate")
@click.argument("text")
@click.option("-f", "--font", default="doom", show_default=True, help="Figlet font name")
@click.option("--gradient", default="rainbow", show_default=True, help="Gradient preset")
@click.option("--speed", default=0.08, show_default=True, help="Seconds per frame")
@click.option("--frames", "frames_count", default=40, show_default=True,
              help="Number of frames before stopping (0 = run until Ctrl+C)")
@click.option("--vertical", is_flag=True, help="Vertical gradient instead of left-to-right")
def cmd_animate(text, font, gradient, speed, frames_count, vertical):
    """Animate ASCII art with cycling gradient colors using Rich Live display.

    Examples:
      am animate "Hello"
      am animate "Hello" --gradient fire --speed 0.05
      am animate "Hello" --frames 20 --vertical
    """
    import time
    from rich.live import Live
    from ascii_maker.text_art import render
    from ascii_maker.compose import from_string, GRADIENTS

    art_str = render(text, font).rstrip()
    art_block = from_string(art_str)
    colors = GRADIENTS.get(gradient, GRADIENTS["rainbow"])

    def make_frame(offset: int) -> str:
        rotated = colors[offset % len(colors):] + colors[:offset % len(colors)]
        result_lines = []
        for row_idx, line in enumerate(art_block.lines):
            parts = []
            for col_idx, char in enumerate(line):
                if char == " ":
                    parts.append(" ")
                else:
                    idx = row_idx if vertical else col_idx
                    color = rotated[idx % len(rotated)]
                    parts.append(f"[{color}]{char}[/{color}]")
            result_lines.append("".join(parts))
        return "\n".join(result_lines)

    try:
        with Live(make_frame(0), refresh_per_second=max(1, int(1 / max(speed, 0.01))), auto_refresh=False) as live:
            count = 1  # frame 0 already displayed as initial state
            while frames_count == 0 or count < frames_count:
                live.update(make_frame(count), refresh=True)
                time.sleep(speed)
                count += 1
    except KeyboardInterrupt:
        pass


# ─── FAV command ───────────────────────────────────────────────────────────────

@cli.group("fav")
def cmd_fav():
    """Manage saved ASCII art favorites."""


@cmd_fav.command("list")
def fav_list():
    """List all saved favorites."""
    from ascii_maker.fav import list_favs
    from rich.table import Table
    from rich import box as rbox

    entries = list_favs()
    if not entries:
        console.print("[dim]No favorites saved. Use --save on any art command.[/]")
        return

    table = Table(title="Favorites", box=rbox.SIMPLE)
    table.add_column("Name", style="cyan")
    table.add_column("Command", style="dim")
    table.add_column("Saved At", style="dim")
    for e in entries:
        table.add_row(e["name"], e.get("command", ""), e.get("created_at", ""))
    console.print(table)


@cmd_fav.command("show")
@click.argument("name")
def fav_show(name):
    """Display a saved favorite."""
    from ascii_maker.fav import get_fav
    entry = get_fav(name)
    if not entry:
        console.print(f"[red]No favorite named {name!r}[/]")
        raise SystemExit(1)
    console.print(Panel(entry["output"], title=f"[yellow]{name}[/]", border_style="cyan"))


@cmd_fav.command("copy")
@click.argument("name")
def fav_copy(name):
    """Copy a saved favorite to clipboard."""
    from ascii_maker.fav import get_fav
    entry = get_fav(name)
    if not entry:
        console.print(f"[red]No favorite named {name!r}[/]")
        raise SystemExit(1)
    try:
        import pyperclip; pyperclip.copy(entry["output"])
        console.print(f"[dim]{name} copied to clipboard.[/]")
    except Exception:
        console.print("[yellow]pyperclip not available.[/]")


@cmd_fav.command("delete")
@click.argument("name")
def fav_delete(name):
    """Delete a saved favorite."""
    from ascii_maker.fav import delete_fav
    try:
        delete_fav(name)
        console.print(f"[dim]{name} deleted.[/]")
    except KeyError:
        console.print(f"[red]No favorite named {name!r}[/]")
        raise SystemExit(1)


# ─── EXPORT command ────────────────────────────────────────────────────────────

@cli.group("export")
def cmd_export():
    """Export any am command output to HTML, SVG, scripts, shell config, and more.

    SUBCOMMAND_STRING: quoted am command without 'am', e.g. "banner MyApp --theme fire"

    Examples:
      am export html "banner MyApp --theme neon"
      am export bash "combo dragon DOOM --theme fire" --out greet.sh
      am export py "logo python --theme ocean" --out show_logo.py
      am export shellrc "banner MyApp --theme neon"
      am export inject myscript.sh "banner MyApp"
    """


@cmd_export.command("html")
@click.argument("subcommand_string")
@click.option("--out", default="", help="Output filename (default: ascii-export-<ts>.html)")
def export_html_cmd(subcommand_string, out):
    """Export as a standalone HTML file with colors preserved."""
    from ascii_maker.exporter import export_html
    content = export_html(subcommand_string)
    path = out or f"ascii-export-{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"
    Path(path).write_text(content, encoding="utf-8")
    console.print(f"[green]Saved to {path}[/]")


@cmd_export.command("svg")
@click.argument("subcommand_string")
@click.option("--out", default="", help="Output filename")
def export_svg_cmd(subcommand_string, out):
    """Export as SVG (scalable, embeddable in markdown/web)."""
    from ascii_maker.exporter import export_svg
    content = export_svg(subcommand_string)
    path = out or f"ascii-export-{datetime.now().strftime('%Y%m%d_%H%M%S')}.svg"
    Path(path).write_text(content, encoding="utf-8")
    console.print(f"[green]Saved to {path}[/]")


@cmd_export.command("text")
@click.argument("subcommand_string")
@click.option("--out", default="", help="Output filename (omit to print to stdout)")
def export_text_cmd(subcommand_string, out):
    """Export as plain text (no color codes)."""
    from ascii_maker.exporter import export_text
    content = export_text(subcommand_string)
    if out:
        Path(out).write_text(content, encoding="utf-8")
        console.print(f"[green]Saved to {out}[/]")
    else:
        console.print(content)


@cmd_export.command("bash")
@click.argument("subcommand_string")
@click.option("--out", default="", help="Output .sh filename")
@click.option("--name", "func_name", default="", help="Function name")
def export_bash_cmd(subcommand_string, out, func_name):
    """Export as a runnable bash script with art embedded in a heredoc."""
    from ascii_maker.exporter import export_bash
    content = export_bash(subcommand_string, func_name)
    path = out or f"ascii-export-{datetime.now().strftime('%Y%m%d_%H%M%S')}.sh"
    Path(path).write_text(content, encoding="utf-8")
    console.print(f"[green]Saved to {path}[/]  Run with: bash {path}")


@cmd_export.command("py")
@click.argument("subcommand_string")
@click.option("--out", default="", help="Output .py filename")
@click.option("--name", "func_name", default="", help="Customise the function name")
def export_py_cmd(subcommand_string, out, func_name):
    """Export as a Python script with art embedded as a string constant."""
    from ascii_maker.exporter import export_py
    content = export_py(subcommand_string, func_name)
    path = out or f"ascii-export-{datetime.now().strftime('%Y%m%d_%H%M%S')}.py"
    Path(path).write_text(content, encoding="utf-8")
    console.print(f"[green]Saved to {path}[/]  Run with: python {path}")


@cmd_export.command("shellrc")
@click.argument("subcommand_string")
@click.option("--shell", default="bash", type=click.Choice(["bash", "zsh"]), show_default=True)
@click.option("--install", is_flag=True, help="Append directly to shell config file")
def export_shellrc_cmd(subcommand_string, shell, install):
    """Export a shell config snippet (shows banner on terminal open).

    With --install: appends directly to ~/.bashrc or ~/.zshrc.
    Without --install: prints snippet to stdout.
    """
    from ascii_maker.exporter import export_shellrc
    content = export_shellrc(subcommand_string, shell)
    target = Path.home() / (".bashrc" if shell == "bash" else ".zshrc")

    if install:
        if target.exists():
            backup = target.with_suffix(target.suffix + ".bak")
            backup.write_text(target.read_text(encoding="utf-8"), encoding="utf-8")
            console.print(f"[dim]Backup: {backup}[/]")
        with target.open("a", encoding="utf-8") as f:
            f.write("\n" + content)
        console.print(f"[green]Appended to {target}[/]")
    else:
        console.print(content)


@cmd_export.command("motd")
@click.argument("subcommand_string")
@click.option("--install", is_flag=True, help="Write to /etc/motd (requires root)")
def export_motd_cmd(subcommand_string, install):
    """Export as Linux MOTD (message of the day)."""
    from ascii_maker.exporter import export_motd
    content = export_motd(subcommand_string)
    if install:
        motd = Path("/etc/motd")
        try:
            motd.write_text(content, encoding="utf-8")
            console.print(f"[green]Written to {motd}[/]")
        except PermissionError:
            console.print("[red]Permission denied. Try: sudo am export motd ... --install[/]")
    else:
        console.print(content)


@cmd_export.command("inject")
@click.argument("filepath")
@click.argument("subcommand_string")
@click.option("--position", default="top", type=click.Choice(["top", "bottom"]))
def export_inject_cmd(filepath, subcommand_string, position):
    """Inject ASCII art into an existing script file.

    Creates a .bak backup before modifying.
    Detects file type from extension: .sh .py .js .ts.
    """
    from ascii_maker.exporter import export_inject
    path = Path(filepath)
    if not path.exists():
        console.print(f"[red]File not found: {filepath}[/]")
        raise SystemExit(1)
    backup = path.with_suffix(path.suffix + ".bak")
    backup.write_text(path.read_text(encoding="utf-8"), encoding="utf-8")
    console.print(f"[dim]Backup: {backup}[/]")
    new_content = export_inject(filepath, subcommand_string, position)
    path.write_text(new_content, encoding="utf-8")
    console.print(f"[green]Injected into {filepath}[/]")


@cmd_export.command("md")
@click.argument("subcommand_string")
@click.option("--no-fence", is_flag=True, help="Use plain ``` fence instead of ```ansi")
@click.option("--out", default="", help="Output filename (default: stdout)")
def export_md_cmd(subcommand_string, no_fence, out):
    """Export as a markdown code fence for READMEs.

    Default: wraps in ```ansi fence (GitHub renders colors).
    --no-fence: plain ``` fence for maximum compatibility.
    """
    from ascii_maker.exporter import export_md
    content = export_md(subcommand_string, no_fence=no_fence)
    if out:
        Path(out).write_text(content, encoding="utf-8")
        console.print(f"[green]Saved to {out}[/]")
    else:
        console.print(content, markup=False)


# ─── COMBO command ─────────────────────────────────────────────────────────────

@cli.command("combo")
@click.argument("animal_name", default="")
@click.argument("text", default="")
@click.option("--layout", default="side",
              type=click.Choice(["side", "stack", "embed", "frame"]),
              show_default=True, help="Composition layout")
@click.option("-f", "--font", default="slant", show_default=True)
@click.option("--theme", default="", help="Color theme")
@click.option("--color", default="", help="Text color override")
@click.option("-s", "--style", default="rounded", show_default=True, help="Box style")
@click.option("--gap", default=2, show_default=True, help="Gap between elements (side layout)")
@click.option("--flip", is_flag=True, help="Flip animal to right side")
@click.option("--copy", is_flag=True)
@click.option("--save", "save_name", default="", help="Save to favorites")
@click.option("--search", "search_tag", default="", help="Search animals by tag")
def cmd_combo(animal_name, text, layout, font, theme, color, style, gap, flip, copy, save_name, search_tag):
    """Combine an animal/symbol with ASCII text art.

    ANIMAL_NAME: name from 'am animals'. TEXT: text to render.

    Layouts:
      side   — animal left, text right (default)
      stack  — animal above, text below
      embed  — animal character at box corners
      frame  — animal tiled as top/bottom border

    Examples:
      am combo cat "Hello"
      am combo dragon "DANGER" --layout stack --theme fire
      am combo crown "King" --layout embed --font doom
      am combo fox "Clever" --flip --theme neon
    """
    from ascii_maker.animals import get_animal, search_animals, ANIMALS
    from ascii_maker.text_art import render
    from ascii_maker.compose import (
        side_by_side, stack, embed, colorize, from_string,
        block_width, block_height, pad_to_width, THEMES
    )
    from ascii_maker.boxes import make_box

    if search_tag:
        names = search_animals(search_tag)
        console.print(f"[bold]Animals tagged '{search_tag}':[/] " + ", ".join(names))
        return

    if not animal_name or not text:
        console.print("[red]Provide ANIMAL_NAME and TEXT, or use --search TAG[/]")
        raise SystemExit(1)

    try:
        animal_block = get_animal(animal_name)
    except KeyError as e:
        console.print(f"[red]{e}[/]")
        raise SystemExit(1)

    # Render text art
    art_str = render(text, font)
    text_block = from_string(art_str.rstrip())

    # Determine effective color
    effective_color = color or (THEMES.get(theme, [""])[0] if theme else "")

    if layout == "side":
        left, right = (animal_block, text_block) if not flip else (text_block, animal_block)
        result = side_by_side(left, right, gap=gap)

    elif layout == "stack":
        top, bot = (animal_block, text_block) if not flip else (text_block, animal_block)
        result = stack(top, bot, gap=1)

    elif layout == "embed":
        # Use first non-space char of animal art as corner decoration
        animal_str = "\n".join(animal_block.lines)
        corner_char = next((c for c in animal_str if c not in (" ", "\n")), "*")
        box_str = make_box(text_block.lines, style=style, padding=2)
        box_block = from_string(box_str)
        result = embed(box_block, corner_char, position="corners")

    elif layout == "frame":
        # Tile animal art as top and bottom border
        from ascii_maker.compose import Block
        w = block_width(text_block) + 6
        animal_line = " ".join(("".join(animal_block.lines[:1])).split()) + " "
        tiled = (animal_line * (w // max(len(animal_line), 1) + 1))[:w]
        box_block = from_string(make_box(text_block.lines, style=style, padding=1))
        result = Block(lines=[tiled] + box_block.lines + [tiled])

    else:
        result = side_by_side(animal_block, text_block, gap=gap)

    output = colorize(result, effective_color) if effective_color else "\n".join(result.lines)
    console.print(output)

    if save_name:
        from ascii_maker.fav import save_fav
        save_fav(save_name, f"combo {animal_name} {text}", "\n".join(result.lines))
        console.print(f"[dim]Saved as '{save_name}'.[/]")

    if copy:
        try:
            import pyperclip; pyperclip.copy("\n".join(result.lines))
            console.print("[dim]Copied.[/]")
        except Exception:
            pass


# ─── DESIGNER command (interactive) ───────────────────────────────────────────

@cli.command("design")
def cmd_design():
    """Launch the interactive ASCII art designer."""
    console.print(Panel(
        "[bold cyan]ASCII Maker v2 — Interactive Designer[/]\n\n"
        "Choose what to create:",
        border_style="cyan",
    ))

    options = [
        ("── Text Art ──────────────────────", None, None),
        ("1",  "Text art (pyfiglet fonts)",       "text"),
        ("2",  "Rainbow gradient text",            "rainbow"),
        ("3",  "Neon glow text",                   "neon"),
        ("── Compositions ──────────────────", None, None),
        ("4",  "Banner (text + frame)",            "banner"),
        ("5",  "Combo (animal + text)",            "combo"),
        ("6",  "Signature block",                  "signature"),
        ("── Art Library ───────────────────", None, None),
        ("7",  "Browse animals & symbols",         "animals"),
        ("8",  "Logos (built-in or generate)",     "logo"),
        ("── Tools ─────────────────────────", None, None),
        ("9",  "Box / frame",                      "box"),
        ("10", "Chart",                            "chart"),
        ("11", "Mermaid diagram template",         "mermaid"),
        ("12", "README section / badge",           "readme"),
        ("── Export & Manage ───────────────", None, None),
        ("13", "Export (HTML / script / inject)",  "export"),
        ("14", "Favorites",                        "fav"),
    ]

    for key, label, _ in options:
        if label is None:
            console.print(f"\n[dim]{key}[/]")
        else:
            console.print(f"  [cyan]{key:>2}[/] {label}")

    try:
        choice = console.input("\n[bold]Pick (1-14): [/]").strip()
    except EOFError:
        return

    mapping = {k: cmd for k, label, cmd in options if cmd is not None}
    selected = mapping.get(choice)

    if not selected:
        console.print("[yellow]Invalid choice.[/]")
        return

    console.print(f"\n[dim]Tip: run [cyan]am {selected} --help[/] for all options.[/]\n")

    # Interactive routing for supported commands
    if selected == "text":
        try:
            text = console.input("Text to render: ").strip()
        except EOFError:
            return
        if text:
            ctx = click.Context(cmd_text)
            cmd_text.invoke(ctx, text=text, font="slant", pick=True, preview=False,
                            list_fonts=False, group=None, copy=False,
                            theme="", color="", no_pager=False, limit=30)
    elif selected == "banner":
        try:
            text = console.input("Banner title: ").strip()
            sub = console.input("Subtitle (optional): ").strip()
            animal = console.input("Animal name (optional, e.g. dragon): ").strip()
            theme = console.input("Theme (fire/ocean/neon/forest/gold, or blank): ").strip()
        except EOFError:
            return
        ctx = click.Context(cmd_banner)
        cmd_banner.invoke(ctx, title=text, subtitle=sub, font="slant", style="double",
                          theme=theme, color="", animal_name=animal, layout="side",
                          logo_name="", corner="", gap=2, flip=False, copy=False, save_name="")
    else:
        console.print(f"[dim]Use: am {selected} --help[/]")
