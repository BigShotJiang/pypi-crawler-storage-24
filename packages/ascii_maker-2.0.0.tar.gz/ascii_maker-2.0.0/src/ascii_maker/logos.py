"""Built-in ASCII art logo library for popular tech brands."""
from __future__ import annotations
import pyfiglet
from ascii_maker.compose import Block, from_string

LOGOS: dict[str, dict] = {
    "python": {
        "art": (
            "    ____        __  __\n"
            "   / __ \\__  __/ /_/ /_  ____  ____\n"
            "  / /_/ / / / / __/ __ \\/ __ \\/ __ \\\n"
            " / ____/ /_/ / /_/ / / / /_/ / / / /\n"
            "/_/    \\__, /\\__/_/ /_/\\____/_/ /_/\n"
            "      /____/"
        ),
        "default_theme": "ocean",
        "tags": ["language", "programming"],
    },
    "docker": {
        "art": (
            "  _____             _\n"
            " |  __ \\           | |\n"
            " | |  | | ___   ___| | _____ _ __\n"
            " | |  | |/ _ \\ / __| |/ / _ \\ '__|\n"
            " | |__| | (_) | (__|   <  __/ |\n"
            " |_____/ \\___/ \\___|_|\\_\\___|_|\n"
            "   [_][_][_][_][_][_]"
        ),
        "default_theme": "ocean",
        "tags": ["devops", "containers"],
    },
    "github": {
        "art": (
            "  _____ _ _   _   _       _\n"
            " / ____(_) | | | | |     | |\n"
            "| |  __ _| |_| |_| |_   _| |\n"
            "| | |_ | | __|  _  | | | | |\n"
            "| |__| | | |_| | | | |_| | |\n"
            " \\_____|_|\\__|_| |_|\\__,_|_|"
        ),
        "default_theme": "mono",
        "tags": ["devops", "git"],
    },
    "linux": {
        "art": (
            "    .--.\n"
            "   |o_o |\n"
            "   |:_/ |\n"
            "  //   \\ \\\n"
            " (|     | )\n"
            "/'\\___/  `\\\n"
            "\\___)=(___/"
        ),
        "default_theme": "gold",
        "tags": ["os", "classic"],
    },
    "rust": {
        "art": (
            "  ____            _\n"
            " |  _ \\ _   _ ___| |_\n"
            " | |_) | | | / __| __|\n"
            " |  _ <| |_| \\__ \\ |_\n"
            " |_| \\_\\\\__,_|___/\\__|"
        ),
        "default_theme": "fire",
        "tags": ["language", "systems"],
    },
    "nodejs": {
        "art": (
            "  _   _           _        _     _\n"
            " | \\ | |         | |      | |   | |\n"
            " |  \\| | ___   __| | ___  | |___| |\n"
            " | . ` |/ _ \\ / _` |/ _ \\ | |_  / |\n"
            " | |\\  | (_) | (_| |  __/ | | / /|_|\n"
            " |_| \\_|\\___/ \\__,_|\\___| |_|/_/ (_)"
        ),
        "default_theme": "forest",
        "tags": ["language", "javascript", "runtime"],
    },
    "vim": {
        "art": (
            " __   ___\n"
            " \\ \\ / (_)_ __ __\n"
            "  \\ V /| | '_ '_ \\\n"
            "   | | | | | | | | |\n"
            "   |_| |_|_| |_| |_|"
        ),
        "default_theme": "forest",
        "tags": ["editor", "classic"],
    },
    "git": {
        "art": (
            "   ____  _ _\n"
            "  / ___||_) |_\n"
            " | |  _ | | __|\n"
            " | |_| || | |_\n"
            "  \\____|_|_|\\__|"
        ),
        "default_theme": "fire",
        "tags": ["devops", "vcs"],
    },
    "aws": {
        "art": (
            "    ___   __        _______\n"
            "   /   | / /       / ____ /\n"
            "  / /| |/ / _ __  / /_\n"
            " / ___ / /_| |/ \\ \\__\n"
            "/_/  |_\\____/|_|___\\____/"
        ),
        "default_theme": "retro",
        "tags": ["cloud", "devops"],
    },
    "react": {
        "art": (
            "  ____                 _\n"
            " |  _ \\ ___  __ _  ___| |_\n"
            " | |_) / _ \\/ _` |/ __| __|\n"
            " |  _ <  __/ (_| | (__| |_\n"
            " |_| \\_\\___|\\__,_|\\___|\\__|"
        ),
        "default_theme": "ocean",
        "tags": ["framework", "javascript"],
    },
    "typescript": {
        "art": (
            " _____ ____\n"
            "|_   _/ ___|\n"
            "  | | \\___ \\\n"
            "  | |  ___) |\n"
            "  |_| |____/"
        ),
        "default_theme": "ocean",
        "tags": ["language", "javascript"],
    },
    "kubernetes": {
        "art": (
            "  _  ___\n"
            " | |/ ( )___\n"
            " | ' /| / __|\n"
            " | . \\| \\__ \\\n"
            " |_|\\_\\_|___/"
        ),
        "default_theme": "ocean",
        "tags": ["devops", "containers"],
    },
    "bash": {
        "art": (
            "  ____            _\n"
            " | __ )  __ _ ___| |__\n"
            " |  _ \\ / _` / __| '_ \\\n"
            " | |_) | (_| \\__ \\ | | |\n"
            " |____/ \\__,_|___/_| |_|"
        ),
        "default_theme": "forest",
        "tags": ["shell", "classic"],
    },
    "nginx": {
        "art": (
            "  _   _  _____ _____  _  ____  __\n"
            " | \\ | |/ ____|_   _|| ||_  | \\ \\\n"
            " |  \\| | |  __ | |  | | _| |_ \\ \\\n"
            " | . ` | | |_ || |  | ||_  _| / /\n"
            " | |\\  | |__| || | _| |_ | | / /\n"
            " |_| \\_|\\_____|_||_____|_||_|/_/"
        ),
        "default_theme": "forest",
        "tags": ["server", "devops"],
    },
    "redis": {
        "art": (
            "  _____          _ _\n"
            " |  __ \\        | (_)\n"
            " | |__) |___  __| | ___\n"
            " |  _  // _ \\/ _` | / __|\n"
            " | | \\ \\  __/ (_| | \\__ \\\n"
            " |_|  \\_\\___|\\__,_|_|___/"
        ),
        "default_theme": "fire",
        "tags": ["database", "cache"],
    },
}


def get_logo(name: str) -> Block:
    """Retrieve a built-in logo Block by brand name. Raises KeyError if not found."""
    if name not in LOGOS:
        raise KeyError(f"Unknown logo: {name!r}. Use 'am logo --list' to see all.")
    return from_string(LOGOS[name]["art"])


def list_logos() -> list[str]:
    """Return all built-in logo names."""
    return list(LOGOS.keys())


def generate_logo(
    text: str,
    font: str = "",
    style: str = "double",
    theme: str = "",
    tagline: str = "",
    corner: str = "",
) -> Block:
    """Generate a styled logo Block from text using figlet.

    Font selection: tries banner3-D, block, doom in order — picks first that fits
    80 columns. Falls back to 'standard' if none fit.
    """
    from ascii_maker.boxes import make_box
    from ascii_maker.compose import stack, embed, block_width

    # Font selection
    if font:
        candidate_fonts = [font, "standard"]
    else:
        candidate_fonts = ["banner3-D", "block", "doom", "standard"]

    chosen_font = "standard"
    for f in candidate_fonts:
        try:
            rendered = pyfiglet.figlet_format(text, font=f)
            if max((len(line) for line in rendered.splitlines()), default=0) <= 80:
                chosen_font = f
                break
        except Exception:
            continue

    art_str = pyfiglet.figlet_format(text, font=chosen_font)
    art_block = from_string(art_str.rstrip())

    if tagline:
        tagline_block = from_string(tagline)
        art_block = stack(art_block, tagline_block, gap=1)

    # Wrap in box
    box_str = make_box(art_block.lines, style=style, padding=2)
    box_block = from_string(box_str)

    if corner:
        box_block = embed(box_block, corner, position="corners")

    return box_block
