"""Tests for favorites storage."""
import pytest
from ascii_maker.fav import save_fav, list_favs, get_fav, delete_fav


@pytest.fixture
def tmp_fav_file(tmp_path, monkeypatch):
    """Redirect fav storage to a temp file."""
    fav_path = tmp_path / "favs.json"
    monkeypatch.setattr("ascii_maker.fav.FAV_FILE", fav_path)
    return fav_path


def test_save_and_get_fav(tmp_fav_file):
    save_fav("myart", "combo cat Hello", "  /\\_/\\\n( o.o )\n  Hello")
    result = get_fav("myart")
    assert result is not None
    assert result["name"] == "myart"
    assert result["output"] == "  /\\_/\\\n( o.o )\n  Hello"


def test_list_favs_empty(tmp_fav_file):
    assert list_favs() == []


def test_list_favs_after_save(tmp_fav_file):
    save_fav("art1", "banner Test", "art here")
    save_fav("art2", "combo cat Hi", "more art")
    names = [f["name"] for f in list_favs()]
    assert "art1" in names
    assert "art2" in names


def test_delete_fav(tmp_fav_file):
    save_fav("todelete", "text Hi", "art")
    delete_fav("todelete")
    assert get_fav("todelete") is None


def test_delete_nonexistent_raises(tmp_fav_file):
    with pytest.raises(KeyError):
        delete_fav("doesnotexist")


def test_save_overwrites_existing(tmp_fav_file):
    save_fav("myart", "cmd1", "art1")
    save_fav("myart", "cmd2", "art2")
    result = get_fav("myart")
    assert result["output"] == "art2"
    assert len(list_favs()) == 1  # no duplicates
