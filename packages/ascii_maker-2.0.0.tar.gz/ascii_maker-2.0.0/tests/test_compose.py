"""Tests for compose.py pipeline primitives."""
import pytest
from ascii_maker.compose import (
    Block, from_string, to_string, block_width, block_height,
    pad_to_height, pad_to_width,
)


def test_block_defaults():
    b = Block(lines=["hello"])
    assert b.color == ""
    assert b.label == ""


def test_from_string_single_line():
    b = from_string("hello")
    assert b.lines == ["hello"]


def test_from_string_multiline():
    b = from_string("hello\nworld")
    assert b.lines == ["hello", "world"]


def test_from_string_preserves_color():
    b = from_string("art", color="cyan")
    assert b.color == "cyan"


def test_to_string_joins_lines():
    b = Block(lines=["hello", "world"])
    assert to_string(b) == "hello\nworld"


def test_block_width_max_line():
    b = Block(lines=["hi", "hello", "hey"])
    assert block_width(b) == 5


def test_block_width_empty():
    b = Block(lines=[])
    assert block_width(b) == 0


def test_block_height():
    b = Block(lines=["a", "b", "c"])
    assert block_height(b) == 3


def test_block_height_empty():
    b = Block(lines=[])
    assert block_height(b) == 0


def test_pad_to_height_extends():
    b = Block(lines=["a", "b"])
    result = pad_to_height(b, 4)
    assert result.lines == ["a", "b", "", ""]


def test_pad_to_height_no_truncate():
    b = Block(lines=["a", "b", "c"])
    result = pad_to_height(b, 2)
    assert result.lines == ["a", "b", "c"]  # no truncation


def test_pad_to_width_extends():
    b = Block(lines=["hi", "x"])
    result = pad_to_width(b, 5)
    assert result.lines == ["hi   ", "x    "]


def test_pad_to_width_preserves_content():
    b = Block(lines=["hello"])
    result = pad_to_width(b, 10)
    assert result.lines[0].startswith("hello")
    assert len(result.lines[0]) == 10


def test_from_string_to_string_roundtrip():
    original = "hello\nworld\nfoo"
    assert to_string(from_string(original)) == original


from ascii_maker.compose import side_by_side, stack, colorize


def test_side_by_side_same_height():
    left = from_string("AA\nBB")
    right = from_string("XX\nYY")
    result = side_by_side(left, right, gap=1)
    assert result.lines == ["AA XX", "BB YY"]


def test_side_by_side_pads_shorter_left():
    left = from_string("AA")       # 1 line
    right = from_string("XX\nYY")  # 2 lines
    result = side_by_side(left, right, gap=1)
    assert len(result.lines) == 2
    assert result.lines[1].strip().endswith("YY")


def test_side_by_side_pads_shorter_right():
    left = from_string("AA\nBB")   # 2 lines
    right = from_string("XX")      # 1 line
    result = side_by_side(left, right, gap=1)
    assert len(result.lines) == 2


def test_side_by_side_gap():
    left = from_string("A")
    right = from_string("B")
    result = side_by_side(left, right, gap=3)
    assert result.lines[0] == "A   B"


def test_stack_two_blocks():
    top = from_string("AA")
    bot = from_string("BB")
    result = stack(top, bot, gap=0)
    assert result.lines == ["AA", "BB"]


def test_stack_with_gap():
    top = from_string("AA")
    bot = from_string("BB")
    result = stack(top, bot, gap=2)
    assert result.lines == ["AA", "", "", "BB"]


def test_stack_with_divider():
    top = from_string("AA")
    bot = from_string("BB")
    result = stack(top, bot, gap=0, divider="──")
    assert result.lines == ["AA", "──", "BB"]


def test_colorize_wraps_markup():
    b = from_string("hello")
    result = colorize(b, "cyan")
    assert "[cyan]" in result
    assert "hello" in result
    assert "[/cyan]" in result


def test_colorize_empty_color_returns_plain():
    b = from_string("hello")
    result = colorize(b, "")
    assert result == "hello"


from ascii_maker.compose import embed, THEMES


def test_themes_keys_exist():
    for key in ["fire", "ocean", "neon", "forest", "gold", "royal", "mono", "retro"]:
        assert key in THEMES
        assert len(THEMES[key]) >= 1


def test_embed_corners_replaces_chars():
    outer = Block(lines=[
        "+---------+",
        "|  hello  |",
        "+---------+",
    ])
    result = embed(outer, "★", position="corners")
    assert result.lines[0][0] == "★"
    assert result.lines[0][-1] == "★"
    assert result.lines[-1][0] == "★"
    assert result.lines[-1][-1] == "★"
    assert result.lines[1] == "|  hello  |"


def test_embed_corners_same_dimensions():
    outer = Block(lines=["ABC", "DEF", "GHI"])
    result = embed(outer, "X", position="corners")
    assert block_height(result) == block_height(outer)
    assert block_width(result) == block_width(outer)


def test_embed_header_prepends_block():
    outer = Block(lines=["body line 1", "body line 2"])
    header = from_string("=== HEADER ===")
    result = embed(outer, header, position="header")
    assert result.lines[0] == "=== HEADER ==="
    assert "body line 1" in result.lines


def test_embed_footer_appends_block():
    outer = Block(lines=["body"])
    footer = from_string("=== FOOTER ===")
    result = embed(outer, footer, position="footer")
    assert result.lines[-1] == "=== FOOTER ==="
    assert result.lines[0] == "body"


from ascii_maker.compose import apply_gradient, GRADIENTS


def test_gradients_dict_has_presets():
    for key in ["rainbow", "fire", "ocean", "sunset"]:
        assert key in GRADIENTS
        assert len(GRADIENTS[key]) >= 2


def test_apply_gradient_returns_string():
    b = from_string("Hello World")
    result = apply_gradient(b, "rainbow")
    assert isinstance(result, str)
    assert "Hello" in result or "[" in result  # Rich markup or raw text


def test_apply_gradient_vertical():
    b = from_string("Hello\nWorld")
    result = apply_gradient(b, "fire", vertical=True)
    assert isinstance(result, str)


def test_apply_gradient_unknown_falls_back():
    b = from_string("Hi")
    result = apply_gradient(b, "zzunknown")
    assert isinstance(result, str)


from ascii_maker.compose import apply_neon


def test_apply_neon_returns_string():
    b = from_string("Hi")
    result = apply_neon(b)
    assert isinstance(result, str)


def test_apply_neon_output_larger_than_input():
    b = from_string("Hi\nBy")
    result = apply_neon(b)
    lines = result.split("\n")
    # Shadow extends 1 row down, so output should be block_height + 1
    assert len(lines) == block_height(b) + 1
