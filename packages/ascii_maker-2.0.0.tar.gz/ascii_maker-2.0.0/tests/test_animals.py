"""Tests for the built-in animal/symbol library."""
import pytest
from ascii_maker.animals import (
    get_animal, list_animals, search_animals, random_animal, ANIMALS
)
from ascii_maker.compose import Block


def test_animals_dict_has_minimum_entries():
    assert len(ANIMALS) >= 20


def test_get_animal_returns_block():
    block = get_animal("cat")
    assert isinstance(block, Block)
    assert len(block.lines) > 0


def test_get_animal_unknown_raises():
    with pytest.raises(KeyError):
        get_animal("nonexistent_animal_xyz")


def test_list_animals_returns_strings():
    names = list_animals()
    assert isinstance(names, list)
    assert all(isinstance(n, str) for n in names)
    assert "cat" in names
    assert "dragon" in names


def test_search_animals_by_tag():
    results = search_animals("cute")
    assert isinstance(results, list)
    assert len(results) > 0
    for name in results:
        assert "cute" in ANIMALS[name]["tags"]


def test_search_animals_no_match_returns_empty():
    results = search_animals("zzznomatch")
    assert results == []


def test_random_animal_returns_block():
    block = random_animal()
    assert isinstance(block, Block)


def test_each_animal_has_required_fields():
    for name, data in ANIMALS.items():
        assert "art" in data, f"{name} missing 'art'"
        assert "tags" in data, f"{name} missing 'tags'"
        assert isinstance(data["art"], str), f"{name} art must be str"
        assert len(data["art"].strip()) > 0, f"{name} art is empty"
