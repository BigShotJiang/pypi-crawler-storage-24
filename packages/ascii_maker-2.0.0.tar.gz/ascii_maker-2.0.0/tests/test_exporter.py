"""Tests for export format rendering."""
import pytest
from ascii_maker.exporter import (
    render_command, export_html, export_text, export_svg,
    export_bash, export_py, escape_triple_quotes, _embed_py,
)


def test_render_command_returns_string():
    output = render_command("text hi --font standard")
    assert isinstance(output, str)
    assert len(output) > 0


def test_render_command_invalid_returns_error_output():
    # Click returns usage error text rather than raising for unknown commands
    result = render_command("nonexistent_command_zzz foo")
    assert "No such command" in result or "Error" in result


def test_export_text_returns_plain_string():
    result = export_text("text hi --font standard")
    assert isinstance(result, str)
    assert "\x1b" not in result  # no ANSI codes


def test_export_html_returns_html():
    result = export_html("text hi --font standard")
    assert "<html" in result.lower()


def test_export_bash_contains_heredoc():
    result = export_bash("text hi --font standard")
    assert "ASCIIEOF" in result
    assert "#!/usr/bin/env bash" in result


def test_export_py_contains_print():
    result = export_py("text hi --font standard")
    assert "print" in result
    assert "#!/usr/bin/env python3" in result


def test_escape_triple_quotes():
    s = 'hello """world"""'
    escaped = escape_triple_quotes(s)
    assert '"""' not in escaped


def test_export_py_escapes_triple_quotes():
    art = 'test """ test'
    result = _embed_py(art, func_name="show")
    assert isinstance(result, str)
    # The art section should not have unescaped triple quotes
    # (between ART = """ and the closing """)
    art_section = result.split('ART = """\n')[1].split('\n"""')[0]
    assert '"""' not in art_section
