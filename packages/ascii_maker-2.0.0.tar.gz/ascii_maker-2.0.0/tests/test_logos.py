"""Tests for the built-in logo library."""
import pytest
from ascii_maker.logos import get_logo, list_logos, LOGOS
from ascii_maker.compose import Block


def test_logos_has_minimum_entries():
    assert len(LOGOS) >= 10


def test_get_logo_returns_block():
    block = get_logo("python")
    assert isinstance(block, Block)
    assert len(block.lines) > 0


def test_get_logo_unknown_raises():
    with pytest.raises(KeyError):
        get_logo("nonexistent_brand_xyz")


def test_list_logos_includes_known_brands():
    names = list_logos()
    for brand in ["python", "docker", "git", "linux"]:
        assert brand in names


def test_each_logo_has_required_fields():
    for name, data in LOGOS.items():
        assert "art" in data, f"{name} missing 'art'"
        assert isinstance(data["art"], str), f"{name} art must be str"
        assert len(data["art"].strip()) > 0, f"{name} art is empty"


from ascii_maker.logos import generate_logo


def test_generate_logo_returns_block():
    block = generate_logo("MyApp")
    assert isinstance(block, Block)
    assert len(block.lines) > 0


def test_generate_logo_fits_80_cols():
    block = generate_logo("Hi")
    from ascii_maker.compose import block_width
    assert block_width(block) <= 82  # allow slight overflow from box border


def test_generate_logo_with_tagline():
    block = generate_logo("MyApp", tagline="v2.0")
    text = "\n".join(block.lines)
    assert "v2.0" in text


def test_generate_logo_long_text_uses_fallback():
    block = generate_logo("A" * 20)
    assert isinstance(block, Block)
