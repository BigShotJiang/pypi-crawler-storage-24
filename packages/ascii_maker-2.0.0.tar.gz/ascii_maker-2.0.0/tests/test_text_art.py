"""Tests for text_art.py color fix and render functions."""
import pytest
from ascii_maker.text_art import render, render_colored


def test_render_returns_string():
    result = render("hi", font="standard")
    assert isinstance(result, str)
    assert len(result) > 0


def test_render_no_markup():
    result = render("hi", font="standard")
    assert "[" not in result  # no Rich markup in raw render


def test_render_colored_wraps_markup():
    result = render_colored("hi", font="standard", color="cyan")
    assert result.startswith("[cyan]")
    assert result.endswith("[/cyan]")


def test_render_colored_contains_art():
    raw = render("hi", font="standard")
    colored = render_colored("hi", font="standard", color="red")
    assert raw in colored


def test_render_colored_default_color():
    result = render_colored("hi", font="standard")
    assert "[cyan]" in result
