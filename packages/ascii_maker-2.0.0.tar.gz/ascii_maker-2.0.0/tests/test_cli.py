"""CLI integration tests using Click's test runner."""
import pytest
from click.testing import CliRunner
from ascii_maker.cli import cli


@pytest.fixture
def runner():
    return CliRunner()


def test_animals_list(runner):
    result = runner.invoke(cli, ["animals"])
    assert result.exit_code == 0
    assert "cat" in result.output


def test_animals_single(runner):
    result = runner.invoke(cli, ["animals", "cat"])
    assert result.exit_code == 0


def test_animals_search(runner):
    result = runner.invoke(cli, ["animals", "--search", "cute"])
    assert result.exit_code == 0


def test_animals_unknown(runner):
    result = runner.invoke(cli, ["animals", "zzunknown"])
    assert result.exit_code != 0 or "not found" in result.output.lower() or "unknown" in result.output.lower()


def test_logo_list(runner):
    result = runner.invoke(cli, ["logo", "--list"])
    assert result.exit_code == 0
    assert "python" in result.output


def test_logo_show_builtin(runner):
    result = runner.invoke(cli, ["logo", "python"])
    assert result.exit_code == 0


def test_logo_unknown_brand(runner):
    result = runner.invoke(cli, ["logo", "zzunknown"])
    assert result.exit_code != 0 or "unknown" in result.output.lower()


def test_logo_generate(runner):
    result = runner.invoke(cli, ["logo", "--generate", "TestApp"])
    assert result.exit_code == 0


def test_combo_side_layout(runner):
    result = runner.invoke(cli, ["combo", "cat", "Hi"])
    assert result.exit_code == 0


def test_combo_stack_layout(runner):
    result = runner.invoke(cli, ["combo", "cat", "Hi", "--layout", "stack"])
    assert result.exit_code == 0


def test_combo_embed_layout(runner):
    result = runner.invoke(cli, ["combo", "star", "Hi", "--layout", "embed"])
    assert result.exit_code == 0


def test_combo_unknown_animal(runner):
    result = runner.invoke(cli, ["combo", "zzunknown", "Hi"])
    assert result.exit_code != 0 or "unknown" in result.output.lower()


def test_combo_search(runner):
    result = runner.invoke(cli, ["combo", "--search", "cute"])
    assert result.exit_code == 0
    assert len(result.output) > 0


def test_banner_basic(runner):
    result = runner.invoke(cli, ["banner", "Test"])
    assert result.exit_code == 0


def test_banner_with_theme(runner):
    result = runner.invoke(cli, ["banner", "Test", "--theme", "fire"])
    assert result.exit_code == 0


def test_banner_with_animal(runner):
    result = runner.invoke(cli, ["banner", "Test", "--animal", "cat"])
    assert result.exit_code == 0


def test_banner_with_logo(runner):
    result = runner.invoke(cli, ["banner", "Test", "--logo", "python"])
    assert result.exit_code == 0


def test_banner_with_corner(runner):
    result = runner.invoke(cli, ["banner", "Test", "--corner", "★"])
    assert result.exit_code == 0


def test_text_preview(runner):
    result = runner.invoke(cli, ["text", "hi", "--preview", "--limit", "3", "--no-pager"])
    assert result.exit_code == 0


def test_text_preview_with_color(runner):
    result = runner.invoke(cli, ["text", "hi", "--preview", "--color", "cyan",
                                  "--limit", "2", "--no-pager"])
    assert result.exit_code == 0


def test_rainbow_basic(runner):
    result = runner.invoke(cli, ["rainbow", "Hi"])
    assert result.exit_code == 0


def test_rainbow_with_gradient(runner):
    result = runner.invoke(cli, ["rainbow", "Hi", "--gradient", "fire"])
    assert result.exit_code == 0


def test_rainbow_vertical(runner):
    result = runner.invoke(cli, ["rainbow", "Hi", "--vertical"])
    assert result.exit_code == 0


def test_neon_basic(runner):
    result = runner.invoke(cli, ["neon", "Hi"])
    assert result.exit_code == 0


def test_neon_with_theme(runner):
    result = runner.invoke(cli, ["neon", "Hi", "--theme", "neon"])
    assert result.exit_code == 0


def test_neon_custom_colors(runner):
    result = runner.invoke(cli, ["neon", "Hi", "--color", "bright_cyan", "--glow", "magenta"])
    assert result.exit_code == 0


def test_signature_basic(runner):
    result = runner.invoke(cli, ["signature", "Alice", "--title", "Dev"])
    assert result.exit_code == 0


def test_signature_with_animal(runner):
    result = runner.invoke(cli, ["signature", "Alice", "--title", "Dev", "--animal", "fox"])
    assert result.exit_code == 0
    assert "Warning" not in result.output


def test_signature_with_theme(runner):
    result = runner.invoke(cli, ["signature", "Alice", "--title", "Dev", "--theme", "neon"])
    assert result.exit_code == 0


def test_animate_basic(runner):
    # Animation with --frames 2 so it terminates quickly
    result = runner.invoke(cli, ["animate", "Hi", "--frames", "2", "--font", "standard"])
    assert result.exit_code == 0


def test_fav_list_empty(runner, tmp_path, monkeypatch):
    monkeypatch.setattr("ascii_maker.fav.FAV_FILE", tmp_path / "favs.json")
    result = runner.invoke(cli, ["fav", "list"])
    assert result.exit_code == 0
    assert "No favorites" in result.output


def test_fav_show_unknown(runner, tmp_path, monkeypatch):
    monkeypatch.setattr("ascii_maker.fav.FAV_FILE", tmp_path / "favs.json")
    result = runner.invoke(cli, ["fav", "show", "zzunknown"])
    assert result.exit_code != 0 or "No favorite" in result.output


def test_export_text(runner):
    result = runner.invoke(cli, ["export", "text", "text hi --font standard"])
    assert result.exit_code == 0


def test_export_bash(runner, tmp_path):
    out_file = tmp_path / "test.sh"
    result = runner.invoke(cli, ["export", "bash", "text hi --font standard",
                                  "--out", str(out_file)])
    assert result.exit_code == 0
    assert out_file.exists()
    content = out_file.read_text()
    assert "ASCIIEOF" in content


def test_export_py(runner, tmp_path):
    out_file = tmp_path / "test.py"
    result = runner.invoke(cli, ["export", "py", "text hi --font standard",
                                  "--out", str(out_file)])
    assert result.exit_code == 0
    assert out_file.exists()
    content = out_file.read_text()
    assert "print" in content


def test_export_md_default(runner):
    result = runner.invoke(cli, ["export", "md", "text hi --font standard"])
    assert result.exit_code == 0
    assert "```ansi" in result.output


def test_export_md_no_fence(runner):
    result = runner.invoke(cli, ["export", "md", "text hi --font standard", "--no-fence"])
    assert result.exit_code == 0
    assert "```" in result.output
    assert "ansi" not in result.output


def test_design_command_exists(runner):
    result = runner.invoke(cli, ["design", "--help"])
    assert result.exit_code == 0
