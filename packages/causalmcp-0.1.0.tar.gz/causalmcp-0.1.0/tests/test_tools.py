"""Tests for CausalPFN MCP tools."""

import os
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

# Generate sample data for tests
def generate_test_data(n: int = 200) -> pd.DataFrame:
    """Generate test dataset."""
    np.random.seed(42)
    age = np.random.normal(40, 10, n)
    income = np.random.normal(50000, 15000, n)
    propensity = 1 / (1 + np.exp(-0.05 * (age - 40)))
    treatment = np.random.binomial(1, propensity, n)
    true_cate = 2 + 0.1 * (age - 40)
    y0 = 100 + 0.5 * age + 0.001 * income + np.random.normal(0, 5, n)
    y1 = y0 + true_cate
    outcome = treatment * y1 + (1 - treatment) * y0
    return pd.DataFrame({
        "age": age,
        "income": income,
        "treatment": treatment,
        "outcome": outcome,
        "true_cate": true_cate,
        "customer_id": [f"cust_{i:04d}" for i in range(n)],
    })


@pytest.fixture(scope="module")
def sample_data_path():
    """Create temporary test data file."""
    df = generate_test_data(n=200)
    with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False) as f:
        df.to_csv(f, index=False)
        path = f.name
    yield path
    os.unlink(path)


@pytest.fixture(scope="module")
def sample_data_df():
    """Return sample DataFrame for reference."""
    return generate_test_data(n=200)


class TestDataUtils:
    """Test data loading and validation utilities."""

    def test_load_valid_data(self, sample_data_path):
        """Test loading valid CSV data."""
        from causalpfn_mcp.data_utils import load_and_validate_data

        data = load_and_validate_data(
            data_path=sample_data_path,
            covariate_columns=["age", "income"],
            treatment_column="treatment",
            outcome_column="outcome",
        )

        assert data.n_units == 200
        assert data.X.shape == (200, 2)
        assert data.T.shape == (200,)
        assert data.Y.shape == (200,)
        assert data.n_treated + data.n_control == 200

    def test_load_with_id_column(self, sample_data_path):
        """Test loading with ID column."""
        from causalpfn_mcp.data_utils import load_and_validate_data

        data = load_and_validate_data(
            data_path=sample_data_path,
            covariate_columns=["age", "income"],
            treatment_column="treatment",
            outcome_column="outcome",
            id_column="customer_id",
        )

        assert data.id_column_values is not None
        assert len(data.id_column_values) == 200

    def test_missing_column_error(self, sample_data_path):
        """Test error on missing column."""
        from causalpfn_mcp.data_utils import DataValidationError, load_and_validate_data

        with pytest.raises(DataValidationError, match="Missing columns"):
            load_and_validate_data(
                data_path=sample_data_path,
                covariate_columns=["age", "nonexistent_column"],
                treatment_column="treatment",
                outcome_column="outcome",
            )

    def test_file_not_found_error(self):
        """Test error on missing file."""
        from causalpfn_mcp.data_utils import DataValidationError, load_and_validate_data

        with pytest.raises(DataValidationError, match="File not found"):
            load_and_validate_data(
                data_path="/nonexistent/path.csv",
                covariate_columns=["age"],
                treatment_column="treatment",
                outcome_column="outcome",
            )


class TestEstimateCATETool:
    """Test estimate_cate tool."""

    def test_basic_cate_estimation(self, sample_data_path):
        """Test basic CATE estimation without uncertainty."""
        from causalpfn_mcp.tools import estimate_cate

        result = estimate_cate({
            "data_path": sample_data_path,
            "covariate_columns": ["age", "income"],
            "treatment_column": "treatment",
            "outcome_column": "outcome",
            "include_uncertainty": False,
        })

        assert "error" not in result
        assert "n_units" in result
        assert "summary" in result
        assert "cate_estimates" in result
        assert len(result["cate_estimates"]) == 200
        assert "causal_caveat" in result

    def test_missing_required_arg(self):
        """Test error on missing required argument."""
        from causalpfn_mcp.tools import estimate_cate

        result = estimate_cate({
            "covariate_columns": ["age"],
            "treatment_column": "treatment",
            "outcome_column": "outcome",
        })

        assert "error" in result


class TestEstimateATETool:
    """Test estimate_ate tool."""

    def test_basic_ate_estimation(self, sample_data_path):
        """Test basic ATE estimation."""
        from causalpfn_mcp.tools import estimate_ate

        result = estimate_ate({
            "data_path": sample_data_path,
            "covariate_columns": ["age", "income"],
            "treatment_column": "treatment",
            "outcome_column": "outcome",
        })

        assert "error" not in result
        assert "ate" in result
        assert "credible_interval" in result
        assert len(result["credible_interval"]) == 2
        assert "causal_caveat" in result


class TestUpliftRankingTool:
    """Test uplift ranking tool."""

    def test_basic_ranking(self, sample_data_path):
        """Test basic uplift ranking."""
        from causalpfn_mcp.tools import uplift_ranking

        result = uplift_ranking({
            "data_path": sample_data_path,
            "covariate_columns": ["age", "income"],
            "treatment_column": "treatment",
            "outcome_column": "outcome",
        })

        assert "error" not in result
        assert "ranked_units" in result
        assert "targeting_summary" in result
        assert "cumulative_effects" in result

    def test_top_k_ranking(self, sample_data_path):
        """Test ranking with top_k limit."""
        from causalpfn_mcp.tools import uplift_ranking

        result = uplift_ranking({
            "data_path": sample_data_path,
            "covariate_columns": ["age", "income"],
            "treatment_column": "treatment",
            "outcome_column": "outcome",
            "top_k": 10,
        })

        assert "error" not in result
        assert len(result["ranked_units"]) == 10

    def test_ranking_with_id_column(self, sample_data_path):
        """Test ranking with ID column."""
        from causalpfn_mcp.tools import uplift_ranking

        result = uplift_ranking({
            "data_path": sample_data_path,
            "covariate_columns": ["age", "income"],
            "treatment_column": "treatment",
            "outcome_column": "outcome",
            "id_column": "customer_id",
            "top_k": 5,
        })

        assert "error" not in result
        assert "id" in result["ranked_units"][0]


class TestDiagnosticsTool:
    """Test diagnostics tool."""

    def test_basic_diagnostics(self, sample_data_path):
        """Test basic diagnostic checks."""
        from causalpfn_mcp.tools import run_diagnostics

        result = run_diagnostics({
            "data_path": sample_data_path,
            "covariate_columns": ["age", "income"],
            "treatment_column": "treatment",
            "outcome_column": "outcome",
        })

        assert "error" not in result
        assert "overall_assessment" in result
        assert "checks" in result
        assert "positivity" in result["checks"]
        assert "covariate_balance" in result["checks"]
        assert "overlap" in result["checks"]
        assert "sample_size" in result["checks"]
        assert "ignorability_reminder" in result


class TestInvalidTreatment:
    """Test handling of invalid treatment columns."""

    def test_non_binary_treatment(self):
        """Test error on non-binary treatment values."""
        from causalpfn_mcp.data_utils import DataValidationError, load_and_validate_data

        # Create temp file with invalid treatment
        df = pd.DataFrame({
            "x": [1, 2, 3, 4, 5] * 10,
            "treatment": [0, 1, 2, 0, 1] * 10,  # Invalid: contains 2
            "outcome": [10, 20, 30, 40, 50] * 10,
        })
        with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False) as f:
            df.to_csv(f, index=False)
            path = f.name

        try:
            with pytest.raises(DataValidationError, match="binary"):
                load_and_validate_data(
                    data_path=path,
                    covariate_columns=["x"],
                    treatment_column="treatment",
                    outcome_column="outcome",
                )
        finally:
            os.unlink(path)
