"""Rank units by predicted treatment effect for uplift modeling."""

from typing import Any, Dict, List, Optional

import numpy as np

from ..config import CONFIG
from ..data_utils import DataValidationError, LoadedData, load_and_validate_data
from ..model import get_model_manager


def run(arguments: Dict[str, Any]) -> Dict[str, Any]:
    """
    Rank units by their predicted treatment effect for targeting/uplift modeling.

    Identifies who benefits most from the intervention.

    Args:
        arguments: Dictionary with:
            - data_path: Path to CSV file
            - covariate_columns: List of covariate column names
            - treatment_column: Name of binary treatment column (0/1)
            - outcome_column: Name of outcome column
            - top_k: Optional - return only top K units
            - id_column: Optional - column to use as unit identifier

    Returns:
        Dictionary with ranked units and targeting summary
    """
    # Extract arguments
    data_path = arguments.get("data_path")
    covariate_columns = arguments.get("covariate_columns", [])
    treatment_column = arguments.get("treatment_column")
    outcome_column = arguments.get("outcome_column")
    top_k = arguments.get("top_k")
    id_column = arguments.get("id_column")

    # Validate required arguments
    if not data_path:
        return {"error": "data_path is required"}
    if not covariate_columns:
        return {"error": "covariate_columns is required (list of column names)"}
    if not treatment_column:
        return {"error": "treatment_column is required"}
    if not outcome_column:
        return {"error": "outcome_column is required"}

    try:
        # Load and validate data
        data: LoadedData = load_and_validate_data(
            data_path=data_path,
            covariate_columns=covariate_columns,
            treatment_column=treatment_column,
            outcome_column=outcome_column,
            id_column=id_column,
        )

        # Get model manager and estimate CATE for ranking
        model = get_model_manager()
        cate_estimates = model.estimate_cate_for_ranking(data=data, verbose=False)

        # Sort by CATE descending (highest effect first)
        sorted_indices = np.argsort(cate_estimates)[::-1]

        # Build ranked units list
        n_to_return = min(top_k, len(sorted_indices)) if top_k else len(sorted_indices)
        # Cap at reasonable size for output
        n_to_return = min(n_to_return, CONFIG.max_output_array_size)

        ranked_units = []
        for rank, idx in enumerate(sorted_indices[:n_to_return], start=1):
            unit_info = {
                "rank": rank,
                "cate": float(cate_estimates[idx]),
            }

            # Add ID if available
            if data.id_column_values is not None:
                unit_info["id"] = str(data.id_column_values[idx])
            else:
                unit_info["row_index"] = int(idx)

            # Add covariate summary (first few covariates)
            covariates_summary = []
            for i, col_name in enumerate(data.covariate_names[:5]):  # First 5 covariates
                val = data.X[idx, i]
                covariates_summary.append(f"{col_name}={val:.2f}")
            unit_info["covariates_summary"] = ", ".join(covariates_summary)

            ranked_units.append(unit_info)

        # Compute targeting summary
        n_units = len(cate_estimates)
        sorted_cates = cate_estimates[sorted_indices]

        targeting_summary = {
            "top_10pct_avg_effect": float(np.mean(sorted_cates[: max(1, n_units // 10)])),
            "top_25pct_avg_effect": float(np.mean(sorted_cates[: max(1, n_units // 4)])),
            "top_50pct_avg_effect": float(np.mean(sorted_cates[: max(1, n_units // 2)])),
            "overall_avg_effect": float(np.mean(cate_estimates)),
        }

        # Compute cumulative effect curve data (Qini-like)
        percentiles = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
        cumulative_effects = []
        for pct in percentiles:
            n_top = max(1, int(n_units * pct / 100))
            avg_effect = float(np.mean(sorted_cates[:n_top]))
            cumulative_effects.append({
                "percentile": pct,
                "n_units": n_top,
                "avg_effect": avg_effect,
            })

        # Build response
        response = {
            "ranked_units": ranked_units,
            "targeting_summary": targeting_summary,
            "cumulative_effects": cumulative_effects,
            "total_units": n_units,
            "units_returned": len(ranked_units),
        }

        # Add info about top_k if specified
        if top_k and top_k < n_units:
            response["note"] = f"Returned top {len(ranked_units)} of {n_units} units as requested."

        # Add truncation note if needed
        if len(sorted_indices) > CONFIG.max_output_array_size and (not top_k or top_k > CONFIG.max_output_array_size):
            response["note"] = (
                f"Output truncated to {CONFIG.max_output_array_size} units. "
                f"Use top_k parameter to control output size."
            )

        # Add warnings and diagnostics
        if data.warnings:
            response["warnings"] = data.warnings

        if data.subsampled:
            response["diagnostics"] = {
                "subsampled": True,
                "subsampled_from": data.subsampled_from,
                "subsampled_to": data.n_units,
            }

        # Add causal caveat
        response["causal_caveat"] = (
            "IMPORTANT: Rankings assume strong ignorability — that the provided covariates "
            "capture ALL variables jointly affecting treatment and outcome. "
            "Targeting decisions based on these rankings should be validated with domain expertise "
            "and ideally confirmed through randomized experiments on the targeted population."
        )

        return response

    except DataValidationError as e:
        return {"error": str(e)}
    except Exception as e:
        return {"error": f"Uplift ranking failed: {str(e)}"}
