"""Estimate individual-level causal treatment effects (CATE)."""

import os
import tempfile
from datetime import datetime
from typing import Any, Dict, List

import numpy as np

from ..config import CONFIG
from ..data_utils import DataValidationError, LoadedData, load_and_validate_data, save_results_to_csv
from ..model import get_model_manager


def run(arguments: Dict[str, Any]) -> Dict[str, Any]:
    """
    Estimate Conditional Average Treatment Effect (CATE) for every unit.

    Returns how much the treatment helped or hurt each individual.

    Args:
        arguments: Dictionary with:
            - data_path: Path to CSV file
            - covariate_columns: List of covariate column names
            - treatment_column: Name of binary treatment column (0/1)
            - outcome_column: Name of outcome column
            - include_uncertainty: Whether to include 95% credible intervals (default: False)

    Returns:
        Dictionary with CATE estimates, summary statistics, and optionally intervals
    """
    # Extract arguments
    data_path = arguments.get("data_path")
    covariate_columns = arguments.get("covariate_columns", [])
    treatment_column = arguments.get("treatment_column")
    outcome_column = arguments.get("outcome_column")
    include_uncertainty = arguments.get("include_uncertainty", False)

    # Validate required arguments
    if not data_path:
        return {"error": "data_path is required"}
    if not covariate_columns:
        return {"error": "covariate_columns is required (list of column names)"}
    if not treatment_column:
        return {"error": "treatment_column is required"}
    if not outcome_column:
        return {"error": "outcome_column is required"}

    try:
        # Load and validate data
        data: LoadedData = load_and_validate_data(
            data_path=data_path,
            covariate_columns=covariate_columns,
            treatment_column=treatment_column,
            outcome_column=outcome_column,
        )

        # Get model manager and estimate CATE
        model = get_model_manager()
        result = model.estimate_cate(
            data=data,
            include_uncertainty=include_uncertainty,
            confidence_level=CONFIG.default_confidence_level,
            verbose=False,
        )

        cate_estimates = result["cate_estimates"]

        # Compute summary statistics
        summary = {
            "mean_cate": float(np.mean(cate_estimates)),
            "median_cate": float(np.median(cate_estimates)),
            "std_cate": float(np.std(cate_estimates)),
            "min_cate": float(np.min(cate_estimates)),
            "max_cate": float(np.max(cate_estimates)),
            "pct_positive_effect": float(np.mean(cate_estimates > 0)),
            "pct_negative_effect": float(np.mean(cate_estimates < 0)),
        }

        # Build response
        response = {
            "n_units": data.n_units,
            "n_treated": data.n_treated,
            "n_control": data.n_control,
            "summary": summary,
        }

        # Handle output size
        if data.n_units <= CONFIG.max_output_array_size:
            # Return full arrays
            response["cate_estimates"] = cate_estimates.tolist()

            if include_uncertainty and "credible_intervals" in result:
                response["credible_intervals_95"] = result["credible_intervals"].tolist()
        else:
            # Save to file and return path
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_dir = tempfile.gettempdir()
            output_path = os.path.join(output_dir, f"cate_results_{timestamp}.csv")

            # Prepare data for saving
            save_data = {"cate_estimate": cate_estimates}
            columns_to_save = ["cate_estimate"]

            if include_uncertainty and "credible_intervals" in result:
                save_data["ci_lower"] = result["credible_intervals"][:, 0]
                save_data["ci_upper"] = result["credible_intervals"][:, 1]
                columns_to_save.extend(["ci_lower", "ci_upper"])

            save_results_to_csv(save_data, output_path, columns_to_save)

            response["results_file"] = output_path
            response["note"] = (
                f"Dataset has {data.n_units} units (>{CONFIG.max_output_array_size}). "
                f"Full results saved to {output_path}. Summary statistics included above."
            )

            # Include sample of estimates
            sample_indices = np.linspace(0, len(cate_estimates) - 1, 10, dtype=int)
            response["sample_estimates"] = [
                {"index": int(i), "cate": float(cate_estimates[i])}
                for i in sample_indices
            ]

        # Add warnings and diagnostics
        if data.warnings:
            response["warnings"] = data.warnings

        if data.subsampled:
            response["diagnostics"] = {
                "subsampled": True,
                "subsampled_from": data.subsampled_from,
                "subsampled_to": data.n_units,
            }
        else:
            response["diagnostics"] = {"subsampled": False}

        # Add causal caveat
        response["causal_caveat"] = (
            "IMPORTANT: These CATE estimates assume strong ignorability — that the provided "
            "covariates capture ALL variables jointly affecting treatment and outcome. "
            "If there are unobserved confounders, estimates may be biased. "
            "This assumption cannot be verified from data alone; domain expertise is required."
        )

        return response

    except DataValidationError as e:
        return {"error": str(e)}
    except Exception as e:
        return {"error": f"Estimation failed: {str(e)}"}
