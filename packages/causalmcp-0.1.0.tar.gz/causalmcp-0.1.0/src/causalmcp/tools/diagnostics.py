"""Run diagnostic checks on data before causal estimation."""

from typing import Any, Dict, List

import numpy as np
from sklearn.linear_model import LogisticRegression

from ..config import CONFIG
from ..data_utils import DataValidationError, LoadedData, load_and_validate_data
from ..model import get_model_manager


def compute_propensity_scores(X: np.ndarray, T: np.ndarray) -> np.ndarray:
    """Estimate propensity scores using logistic regression."""
    try:
        lr = LogisticRegression(max_iter=1000, solver="lbfgs")
        lr.fit(X, T)
        propensity = lr.predict_proba(X)[:, 1]
        return propensity
    except Exception:
        # Fallback to simple proportion if logistic regression fails
        return np.full(len(T), T.mean())


def compute_standardized_mean_diff(X: np.ndarray, T: np.ndarray) -> Dict[str, float]:
    """Compute standardized mean differences for each covariate."""
    treated_mask = T == 1
    control_mask = T == 0

    smds = {}
    for i in range(X.shape[1]):
        treated_vals = X[treated_mask, i]
        control_vals = X[control_mask, i]

        mean_diff = treated_vals.mean() - control_vals.mean()
        pooled_std = np.sqrt(
            (treated_vals.var() + control_vals.var()) / 2
        )

        if pooled_std > 0:
            smd = abs(mean_diff / pooled_std)
        else:
            smd = 0.0

        smds[f"covariate_{i}"] = float(smd)

    return smds


def run(arguments: Dict[str, Any]) -> Dict[str, Any]:
    """
    Run diagnostic checks on data before trusting causal conclusions.

    Checks positivity, covariate balance, overlap, sample size, and uncertainty width.

    Args:
        arguments: Dictionary with:
            - data_path: Path to CSV file
            - covariate_columns: List of covariate column names
            - treatment_column: Name of binary treatment column (0/1)
            - outcome_column: Name of outcome column

    Returns:
        Dictionary with diagnostic results and recommendations
    """
    # Extract arguments
    data_path = arguments.get("data_path")
    covariate_columns = arguments.get("covariate_columns", [])
    treatment_column = arguments.get("treatment_column")
    outcome_column = arguments.get("outcome_column")

    # Validate required arguments
    if not data_path:
        return {"error": "data_path is required"}
    if not covariate_columns:
        return {"error": "covariate_columns is required (list of column names)"}
    if not treatment_column:
        return {"error": "treatment_column is required"}
    if not outcome_column:
        return {"error": "outcome_column is required"}

    try:
        # Load and validate data
        data: LoadedData = load_and_validate_data(
            data_path=data_path,
            covariate_columns=covariate_columns,
            treatment_column=treatment_column,
            outcome_column=outcome_column,
        )

        checks = {}
        issues = []

        # 1. Positivity Check - Propensity Score Analysis
        propensity = compute_propensity_scores(data.X, data.T)
        extreme_low = propensity < CONFIG.propensity_extreme_threshold
        extreme_high = propensity > (1 - CONFIG.propensity_extreme_threshold)
        extreme_pct = float((extreme_low | extreme_high).mean() * 100)

        positivity_status = "pass"
        positivity_message = "No extreme propensity scores detected."

        if extreme_pct > 0:
            if extreme_pct > 10:
                positivity_status = "fail"
                positivity_message = (
                    f"{extreme_pct:.1f}% of units have extreme propensity scores "
                    f"(<{CONFIG.propensity_extreme_threshold} or >{1-CONFIG.propensity_extreme_threshold}). "
                    f"Positivity assumption may be violated."
                )
                issues.append("Positivity violation detected")
            else:
                positivity_status = "warning"
                positivity_message = (
                    f"{extreme_pct:.1f}% of units have extreme propensity scores. "
                    f"Monitor for positivity issues."
                )

        checks["positivity"] = {
            "status": positivity_status,
            "message": positivity_message,
            "propensity_range": [float(propensity.min()), float(propensity.max())],
            "extreme_propensity_pct": round(extreme_pct, 2),
        }

        # 2. Covariate Balance Check
        smds = compute_standardized_mean_diff(data.X, data.T)
        imbalanced = [
            (name, smd)
            for name, smd in smds.items()
            if smd > CONFIG.smd_imbalance_threshold
        ]

        balance_status = "pass"
        balance_message = f"All standardized mean differences < {CONFIG.smd_imbalance_threshold}"

        if imbalanced:
            if len(imbalanced) > len(covariate_columns) // 2:
                balance_status = "fail"
                balance_message = f"{len(imbalanced)} covariates have SMD > {CONFIG.smd_imbalance_threshold}"
                issues.append("Severe covariate imbalance")
            else:
                balance_status = "warning"
                balance_message = f"{len(imbalanced)} covariates slightly imbalanced"

        checks["covariate_balance"] = {
            "status": balance_status,
            "message": balance_message,
            "imbalanced_covariates": [
                {"name": covariate_columns[int(name.split("_")[1])], "smd": round(smd, 3)}
                for name, smd in imbalanced
            ],
            "all_smds": {
                covariate_columns[int(name.split("_")[1])]: round(smd, 3)
                for name, smd in smds.items()
            },
        }

        # 3. Overlap Check
        treatment_frac = data.n_treated / data.n_units
        overlap_status = "pass"
        overlap_message = f"Treatment fraction: {treatment_frac:.1%}"

        if treatment_frac < CONFIG.min_group_fraction or treatment_frac > (1 - CONFIG.min_group_fraction):
            overlap_status = "fail"
            overlap_message = (
                f"Severe treatment imbalance: {treatment_frac:.1%} treated. "
                f"Need at least {CONFIG.min_group_fraction:.0%} in each group."
            )
            issues.append("Treatment group imbalance")
        elif treatment_frac < 0.2 or treatment_frac > 0.8:
            overlap_status = "warning"
            overlap_message = f"Moderate treatment imbalance: {treatment_frac:.1%} treated."

        checks["overlap"] = {
            "status": overlap_status,
            "message": overlap_message,
            "n_treated": data.n_treated,
            "n_control": data.n_control,
            "treatment_fraction": round(treatment_frac, 4),
        }

        # 4. Sample Size Assessment
        sample_status = "pass"
        sample_message = f"Sample size: {data.n_units} units"

        if data.n_units < CONFIG.warn_dataset_size:
            sample_status = "warning"
            sample_message = (
                f"Small sample size ({data.n_units} units). "
                f"Results may have high variance. Recommended: ≥{CONFIG.warn_dataset_size}."
            )
        elif data.n_treated < 50 or data.n_control < 50:
            sample_status = "warning"
            sample_message = (
                f"Small group sizes (treated: {data.n_treated}, control: {data.n_control}). "
                f"Recommend ≥50 units per group."
            )

        checks["sample_size"] = {
            "status": sample_status,
            "message": sample_message,
            "total_n": data.n_units,
        }

        # 5. Uncertainty Width Check (quick estimate on subsample)
        try:
            model = get_model_manager()
            # Use small subsample for quick uncertainty check
            subsample_size = min(100, data.n_units)
            indices = np.random.choice(data.n_units, subsample_size, replace=False)

            from ..data_utils import LoadedData
            subsample_data = LoadedData(
                X=data.X[indices],
                T=data.T[indices],
                Y=data.Y[indices],
                n_units=subsample_size,
                n_treated=int((data.T[indices] == 1).sum()),
                n_control=int((data.T[indices] == 0).sum()),
                covariate_names=data.covariate_names,
            )

            result = model.estimate_cate(
                data=subsample_data,
                include_uncertainty=True,
                n_samples=1000,  # Fewer samples for speed
            )

            if "credible_intervals" in result:
                intervals = result["credible_intervals"]
                widths = intervals[:, 1] - intervals[:, 0]
                mean_width = float(np.mean(widths))
                median_width = float(np.median(widths))

                # Heuristic: width < 2*std(Y) is reasonable
                y_std = float(np.std(data.Y))
                width_ratio = mean_width / (2 * y_std) if y_std > 0 else float("inf")

                uncertainty_status = "pass"
                uncertainty_message = f"Mean interval width: {mean_width:.2f}"

                if width_ratio > 2:
                    uncertainty_status = "warning"
                    uncertainty_message = (
                        f"Wide credible intervals (mean: {mean_width:.2f}). "
                        f"Data may be insufficient for precise estimation."
                    )

                checks["uncertainty"] = {
                    "status": uncertainty_status,
                    "message": uncertainty_message,
                    "mean_interval_width": round(mean_width, 3),
                    "median_interval_width": round(median_width, 3),
                }
            else:
                checks["uncertainty"] = {
                    "status": "skipped",
                    "message": "Could not estimate uncertainty width.",
                }
        except Exception as e:
            checks["uncertainty"] = {
                "status": "skipped",
                "message": f"Uncertainty check skipped: {str(e)}",
            }

        # Determine overall assessment
        statuses = [check.get("status", "pass") for check in checks.values()]
        if "fail" in statuses:
            overall = "low_confidence"
        elif "warning" in statuses:
            overall = "moderate_confidence"
        else:
            overall = "high_confidence"

        # Build response
        response = {
            "overall_assessment": overall,
            "checks": checks,
            "issues_found": issues if issues else None,
            "n_units": data.n_units,
            "n_treated": data.n_treated,
            "n_control": data.n_control,
        }

        # Add data warnings
        if data.warnings:
            response["data_warnings"] = data.warnings

        # CRITICAL: Ignorability reminder
        response["ignorability_reminder"] = (
            "IMPORTANT: These diagnostics CANNOT verify the absence of unobserved confounders. "
            "The validity of causal estimates depends on the assumption that the provided "
            "covariates capture ALL variables that jointly influence treatment assignment and outcome. "
            "Domain expertise is REQUIRED to assess whether this assumption is plausible for your "
            "specific application. No statistical test can verify this assumption."
        )

        return response

    except DataValidationError as e:
        return {"error": str(e)}
    except Exception as e:
        return {"error": f"Diagnostics failed: {str(e)}"}
