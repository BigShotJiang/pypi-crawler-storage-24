"""Estimate Average Treatment Effect (ATE)."""

from typing import Any, Dict

import numpy as np

from ..config import CONFIG
from ..data_utils import DataValidationError, LoadedData, load_and_validate_data
from ..model import get_model_manager


def run(arguments: Dict[str, Any]) -> Dict[str, Any]:
    """
    Estimate Average Treatment Effect (ATE) — the population-level causal impact.

    Args:
        arguments: Dictionary with:
            - data_path: Path to CSV file
            - covariate_columns: List of covariate column names
            - treatment_column: Name of binary treatment column (0/1)
            - outcome_column: Name of outcome column
            - confidence_level: Credible interval width (default: 0.95)

    Returns:
        Dictionary with ATE estimate, credible interval, and diagnostics
    """
    # Extract arguments
    data_path = arguments.get("data_path")
    covariate_columns = arguments.get("covariate_columns", [])
    treatment_column = arguments.get("treatment_column")
    outcome_column = arguments.get("outcome_column")
    confidence_level = arguments.get("confidence_level", CONFIG.default_confidence_level)

    # Validate required arguments
    if not data_path:
        return {"error": "data_path is required"}
    if not covariate_columns:
        return {"error": "covariate_columns is required (list of column names)"}
    if not treatment_column:
        return {"error": "treatment_column is required"}
    if not outcome_column:
        return {"error": "outcome_column is required"}

    # Validate confidence level
    if not 0 < confidence_level < 1:
        return {"error": "confidence_level must be between 0 and 1 (e.g., 0.95)"}

    try:
        # Load and validate data
        data: LoadedData = load_and_validate_data(
            data_path=data_path,
            covariate_columns=covariate_columns,
            treatment_column=treatment_column,
            outcome_column=outcome_column,
        )

        # Get model manager and estimate ATE
        model = get_model_manager()
        result = model.estimate_ate(
            data=data,
            confidence_level=confidence_level,
            verbose=False,
        )

        # Build response
        response = {
            "ate": result["ate"],
            "credible_interval": result["credible_interval"],
            "confidence_level": confidence_level,
            "n_units": data.n_units,
            "n_treated": data.n_treated,
            "n_control": data.n_control,
            "treatment_fraction": round(data.n_treated / data.n_units, 4),
        }

        # Add diagnostics
        diagnostics = {
            "subsampled": data.subsampled,
            "subsampled_to": data.n_units if data.subsampled else None,
            "positivity_warning": False,
        }

        # Check for positivity issues (severe imbalance)
        treatment_frac = data.n_treated / data.n_units
        if treatment_frac < CONFIG.min_group_fraction or treatment_frac > (1 - CONFIG.min_group_fraction):
            diagnostics["positivity_warning"] = True
            diagnostics["positivity_message"] = (
                f"Severe treatment imbalance detected: {treatment_frac:.1%} treated. "
                f"This may affect estimate reliability."
            )

        response["diagnostics"] = diagnostics

        # Add warnings
        if data.warnings:
            response["warnings"] = data.warnings

        # Add causal caveat
        response["causal_caveat"] = (
            "IMPORTANT: The ATE estimate assumes strong ignorability — that the provided "
            "covariates capture ALL variables jointly affecting treatment and outcome. "
            "If there are unobserved confounders, the estimate may be biased. "
            "This assumption cannot be verified from data alone; domain expertise is required."
        )

        return response

    except DataValidationError as e:
        return {"error": str(e)}
    except Exception as e:
        return {"error": f"ATE estimation failed: {str(e)}"}
