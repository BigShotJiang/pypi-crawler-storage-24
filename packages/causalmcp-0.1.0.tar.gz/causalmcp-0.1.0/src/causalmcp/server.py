"""CausalPFN MCP Server — Causal effect estimation via MCP tools."""

import json
import logging
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from .tools import estimate_ate, estimate_cate, run_diagnostics, uplift_ranking

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("causalpfn-mcp")

# Create server instance
server = Server("causalpfn-mcp")


# Tool definitions with JSON schemas
TOOLS = [
    Tool(
        name="estimate_cate",
        description=(
            "Estimate individual-level Conditional Average Treatment Effects (CATE) from observational data. "
            "Returns how much the treatment helped or hurt each unit in the dataset. "
            "Requires a CSV with covariates (X), a binary treatment column (T with values 0/1), and an outcome column (Y). "
            "IMPORTANT: Assumes strong ignorability — covariates must capture ALL confounders. "
            "Domain expertise required to assess this assumption."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "data_path": {
                    "type": "string",
                    "description": "Path to CSV file containing the dataset"
                },
                "covariate_columns": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Names of covariate columns (X) — features that may affect treatment and outcome"
                },
                "treatment_column": {
                    "type": "string",
                    "description": "Name of the binary treatment column (must be 0 or 1)"
                },
                "outcome_column": {
                    "type": "string",
                    "description": "Name of the outcome column (Y)"
                },
                "include_uncertainty": {
                    "type": "boolean",
                    "description": "If true, include 95% Bayesian credible intervals per unit (slower)",
                    "default": False
                }
            },
            "required": ["data_path", "covariate_columns", "treatment_column", "outcome_column"]
        }
    ),
    Tool(
        name="estimate_ate",
        description=(
            "Estimate the Average Treatment Effect (ATE) — the population-level causal impact of the treatment. "
            "Returns a point estimate and Bayesian credible interval. "
            "ATE answers: 'On average across the population, how much does the treatment change the outcome?' "
            "IMPORTANT: Assumes strong ignorability — covariates must capture ALL confounders."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "data_path": {
                    "type": "string",
                    "description": "Path to CSV file containing the dataset"
                },
                "covariate_columns": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Names of covariate columns (X)"
                },
                "treatment_column": {
                    "type": "string",
                    "description": "Name of the binary treatment column (must be 0 or 1)"
                },
                "outcome_column": {
                    "type": "string",
                    "description": "Name of the outcome column (Y)"
                },
                "confidence_level": {
                    "type": "number",
                    "description": "Credible interval width (e.g., 0.95 for 95% CI)",
                    "default": 0.95
                }
            },
            "required": ["data_path", "covariate_columns", "treatment_column", "outcome_column"]
        }
    ),
    Tool(
        name="estimate_uplift_ranking",
        description=(
            "Rank units by their predicted treatment effect for targeting/uplift modeling. "
            "Identifies who benefits most from the intervention — essential for personalized marketing, "
            "treatment allocation, and resource optimization. "
            "Returns ranked list with CATE estimates and targeting summaries (top 10/25/50% effects). "
            "IMPORTANT: Rankings assume strong ignorability. Validate with domain expertise."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "data_path": {
                    "type": "string",
                    "description": "Path to CSV file containing the dataset"
                },
                "covariate_columns": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Names of covariate columns (X)"
                },
                "treatment_column": {
                    "type": "string",
                    "description": "Name of the binary treatment column (must be 0 or 1)"
                },
                "outcome_column": {
                    "type": "string",
                    "description": "Name of the outcome column (Y)"
                },
                "top_k": {
                    "type": "integer",
                    "description": "Return only top K units (optional, returns all if not specified)"
                },
                "id_column": {
                    "type": "string",
                    "description": "Column to use as unit identifier in output (optional)"
                }
            },
            "required": ["data_path", "covariate_columns", "treatment_column", "outcome_column"]
        }
    ),
    Tool(
        name="run_causal_diagnostics",
        description=(
            "Run diagnostic checks on data BEFORE causal estimation. "
            "Checks: (1) Positivity — propensity score extremes, (2) Covariate balance — SMD between groups, "
            "(3) Overlap — treatment/control group sizes, (4) Sample size adequacy, (5) Uncertainty width. "
            "CRITICAL: These diagnostics CANNOT verify the absence of unobserved confounders. "
            "The ignorability assumption requires domain expertise to assess."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "data_path": {
                    "type": "string",
                    "description": "Path to CSV file containing the dataset"
                },
                "covariate_columns": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Names of covariate columns (X)"
                },
                "treatment_column": {
                    "type": "string",
                    "description": "Name of the binary treatment column (must be 0 or 1)"
                },
                "outcome_column": {
                    "type": "string",
                    "description": "Name of the outcome column (Y)"
                }
            },
            "required": ["data_path", "covariate_columns", "treatment_column", "outcome_column"]
        }
    ),
]


@server.list_tools()
async def list_tools() -> list[Tool]:
    """List available CausalPFN tools."""
    return TOOLS


@server.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    """Execute a CausalPFN tool."""
    logger.info(f"Calling tool: {name}")

    try:
        if name == "estimate_cate":
            result = estimate_cate(arguments)
        elif name == "estimate_ate":
            result = estimate_ate(arguments)
        elif name == "estimate_uplift_ranking":
            result = uplift_ranking(arguments)
        elif name == "run_causal_diagnostics":
            result = run_diagnostics(arguments)
        else:
            result = {"error": f"Unknown tool: {name}"}

        # Format result as JSON
        result_text = json.dumps(result, indent=2, default=str)
        return [TextContent(type="text", text=result_text)]

    except Exception as e:
        logger.error(f"Tool {name} failed: {e}")
        error_result = {"error": f"Tool execution failed: {str(e)}"}
        return [TextContent(type="text", text=json.dumps(error_result, indent=2))]


async def run_server():
    """Run the MCP server using stdio transport."""
    logger.info("Starting CausalPFN MCP server...")
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options()
        )


def main():
    """Entry point for the server."""
    import asyncio
    asyncio.run(run_server())


if __name__ == "__main__":
    main()
