"""Data loading, validation, and preprocessing utilities."""

from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Tuple

import numpy as np
import pandas as pd

from .config import CONFIG


@dataclass
class LoadedData:
    """Container for loaded and validated dataset."""

    X: np.ndarray  # Covariates (N, D)
    T: np.ndarray  # Treatment (N,) binary 0/1
    Y: np.ndarray  # Outcome (N,)
    n_units: int
    n_treated: int
    n_control: int
    covariate_names: List[str]
    id_column_values: Optional[np.ndarray] = None
    original_df: Optional[pd.DataFrame] = None
    warnings: List[str] = None
    subsampled: bool = False
    subsampled_from: Optional[int] = None

    def __post_init__(self):
        if self.warnings is None:
            self.warnings = []


class DataValidationError(Exception):
    """Raised when data validation fails."""

    pass


def load_csv(data_path: str) -> pd.DataFrame:
    """Load CSV file with basic validation."""
    path = Path(data_path)
    if not path.exists():
        raise DataValidationError(f"File not found: {data_path}")
    if not path.suffix.lower() == ".csv":
        raise DataValidationError(f"Expected CSV file, got: {path.suffix}")

    try:
        df = pd.read_csv(data_path)
    except Exception as e:
        raise DataValidationError(f"Failed to read CSV: {e}")

    if len(df) == 0:
        raise DataValidationError("Dataset is empty")

    return df


def validate_columns(
    df: pd.DataFrame,
    covariate_columns: List[str],
    treatment_column: str,
    outcome_column: str,
    id_column: Optional[str] = None,
) -> None:
    """Validate that all required columns exist."""
    required = set(covariate_columns) | {treatment_column, outcome_column}
    if id_column:
        required.add(id_column)

    missing = required - set(df.columns)
    if missing:
        raise DataValidationError(
            f"Missing columns: {sorted(missing)}. Available columns: {sorted(df.columns)}"
        )


def validate_treatment(df: pd.DataFrame, treatment_column: str) -> None:
    """Validate treatment column is binary (0/1)."""
    unique_values = df[treatment_column].dropna().unique()
    valid_values = {0, 1, 0.0, 1.0}

    invalid = set(unique_values) - valid_values
    if invalid:
        raise DataValidationError(
            f"Treatment column must be binary (0 or 1). "
            f"Found values: {sorted(unique_values)}. Invalid values: {sorted(invalid)}"
        )

    # Check for all treated or all control
    treatment_counts = df[treatment_column].value_counts()
    if len(treatment_counts) < 2:
        raise DataValidationError(
            "Both treated and control units are required. "
            f"Found only: {'treated' if 1 in treatment_counts.index else 'control'} units."
        )


def handle_missing_values(
    df: pd.DataFrame, columns: List[str], warnings: List[str]
) -> pd.DataFrame:
    """Handle missing values in specified columns with median imputation."""
    df = df.copy()
    has_missing = False

    for col in columns:
        n_missing = df[col].isna().sum()
        if n_missing > 0:
            has_missing = True
            if df[col].dtype in [np.float64, np.float32, np.int64, np.int32]:
                median_val = df[col].median()
                df[col] = df[col].fillna(median_val)
            else:
                # For non-numeric, drop rows
                df = df.dropna(subset=[col])

    if has_missing:
        warnings.append(
            f"Missing values detected and imputed with median (numeric) or rows dropped. "
            f"Consider cleaning your data before analysis."
        )

    return df


def stratified_subsample(
    df: pd.DataFrame, treatment_column: str, max_size: int, random_state: int = 42
) -> Tuple[pd.DataFrame, int]:
    """Stratified subsample preserving treatment ratio."""
    if len(df) <= max_size:
        return df, len(df)

    original_size = len(df)
    treatment_ratio = df[treatment_column].mean()

    # Calculate target counts
    n_treated_target = int(max_size * treatment_ratio)
    n_control_target = max_size - n_treated_target

    # Sample from each group
    treated_df = df[df[treatment_column] == 1]
    control_df = df[df[treatment_column] == 0]

    # Adjust if one group is too small
    if len(treated_df) < n_treated_target:
        n_treated_target = len(treated_df)
        n_control_target = max_size - n_treated_target
    if len(control_df) < n_control_target:
        n_control_target = len(control_df)
        n_treated_target = max_size - n_control_target

    np.random.seed(random_state)
    treated_sample = treated_df.sample(n=n_treated_target, random_state=random_state)
    control_sample = control_df.sample(n=n_control_target, random_state=random_state)

    sampled_df = pd.concat([treated_sample, control_sample]).sample(frac=1, random_state=random_state)

    return sampled_df, original_size


def load_and_validate_data(
    data_path: str,
    covariate_columns: List[str],
    treatment_column: str,
    outcome_column: str,
    id_column: Optional[str] = None,
    max_size: Optional[int] = None,
) -> LoadedData:
    """
    Load CSV, validate, handle missing values, and optionally subsample.

    Args:
        data_path: Path to CSV file
        covariate_columns: Names of covariate columns (X)
        treatment_column: Name of binary treatment column (T)
        outcome_column: Name of outcome column (Y)
        id_column: Optional column to use as unit identifier
        max_size: Maximum dataset size (will stratified subsample if larger)

    Returns:
        LoadedData with validated arrays and metadata

    Raises:
        DataValidationError: If validation fails
    """
    if max_size is None:
        max_size = CONFIG.max_dataset_size

    warnings = []

    # Load CSV
    df = load_csv(data_path)

    # Validate columns exist
    validate_columns(df, covariate_columns, treatment_column, outcome_column, id_column)

    # Validate treatment is binary
    validate_treatment(df, treatment_column)

    # Handle missing values
    all_columns = covariate_columns + [treatment_column, outcome_column]
    df = handle_missing_values(df, all_columns, warnings)

    # Check sample size
    if len(df) < CONFIG.min_dataset_size:
        raise DataValidationError(
            f"Dataset too small for reliable causal estimation. "
            f"Found {len(df)} rows, minimum recommended: {CONFIG.min_dataset_size}."
        )

    if len(df) < CONFIG.warn_dataset_size:
        warnings.append(
            f"Small dataset ({len(df)} rows). Results may have high uncertainty. "
            f"Recommended minimum: {CONFIG.warn_dataset_size} rows."
        )

    # Subsample if needed
    subsampled = False
    subsampled_from = None
    if len(df) > max_size:
        df, subsampled_from = stratified_subsample(df, treatment_column, max_size)
        subsampled = True
        warnings.append(
            f"Dataset subsampled from {subsampled_from:,} to {len(df):,} rows "
            f"(stratified on treatment). PFN-style models work best with smaller contexts."
        )

    # Extract arrays
    X = df[covariate_columns].values.astype(np.float32)
    T = df[treatment_column].values.astype(np.float32)
    Y = df[outcome_column].values.astype(np.float32)

    # ID column
    id_values = None
    if id_column:
        id_values = df[id_column].values

    # Count treated/control
    n_treated = int((T == 1).sum())
    n_control = int((T == 0).sum())

    return LoadedData(
        X=X,
        T=T,
        Y=Y,
        n_units=len(df),
        n_treated=n_treated,
        n_control=n_control,
        covariate_names=covariate_columns,
        id_column_values=id_values,
        original_df=df,
        warnings=warnings,
        subsampled=subsampled,
        subsampled_from=subsampled_from,
    )


def save_results_to_csv(
    results: dict, output_path: str, columns_to_save: List[str]
) -> str:
    """Save large result arrays to CSV and return path."""
    df = pd.DataFrame({k: results[k] for k in columns_to_save if k in results})
    df.to_csv(output_path, index=False)
    return output_path
