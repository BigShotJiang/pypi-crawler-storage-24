"""CausalPFN model wrapper managing estimator lifecycle."""

import hashlib
from typing import Dict, Optional, Tuple

import numpy as np
import torch

from causalpfn import CATEEstimator

from .config import CONFIG
from .data_utils import LoadedData


class CausalPFNModelManager:
    """
    Manages CausalPFN estimator instances with caching to avoid re-fitting.
    
    The CausalPFN library loads model weights when fit() is called.
    We cache fitted estimators keyed by data hash to avoid re-fitting
    on repeated calls with the same data.
    """

    def __init__(self):
        self._device = self._get_device()
        self._fitted_estimators: Dict[str, CATEEstimator] = {}
        self._cache_max_size = 3  # Keep last 3 fitted estimators

    def _get_device(self) -> str:
        """Determine device to use."""
        if CONFIG.device == "auto":
            return "cuda:0" if torch.cuda.is_available() else "cpu"
        return CONFIG.device

    def _compute_data_hash(self, X: np.ndarray, T: np.ndarray, Y: np.ndarray) -> str:
        """Compute hash of data for caching."""
        # Use shape + sample of values for fast hashing
        key_data = (
            X.shape,
            T.shape,
            Y.shape,
            X[:10].tobytes() if len(X) > 0 else b"",
            T[:10].tobytes() if len(T) > 0 else b"",
            Y[:10].tobytes() if len(Y) > 0 else b"",
            X[-10:].tobytes() if len(X) > 10 else b"",
        )
        return hashlib.md5(str(key_data).encode()).hexdigest()

    def _get_or_fit_estimator(
        self,
        data: LoadedData,
        calibrate: bool = False,
        verbose: bool = False,
    ) -> CATEEstimator:
        """Get cached estimator or fit a new one."""
        data_hash = self._compute_data_hash(data.X, data.T, data.Y)
        cache_key = f"{data_hash}_{calibrate}"

        if cache_key in self._fitted_estimators:
            return self._fitted_estimators[cache_key]

        # Create and fit new estimator
        estimator = CATEEstimator(
            device=self._device,
            model_path=CONFIG.model_path,
            max_context_length=CONFIG.max_context_length,
            max_query_length=CONFIG.max_query_length,
            num_neighbours=CONFIG.num_neighbours,
            calibrate=calibrate,
            n_folds=CONFIG.n_calibration_folds,
            verbose=verbose,
        )
        estimator.fit(data.X, data.T, data.Y)

        # Cache with LRU eviction
        if len(self._fitted_estimators) >= self._cache_max_size:
            oldest_key = next(iter(self._fitted_estimators))
            del self._fitted_estimators[oldest_key]
        self._fitted_estimators[cache_key] = estimator

        return estimator

    def estimate_cate(
        self,
        data: LoadedData,
        include_uncertainty: bool = False,
        confidence_level: float = 0.95,
        n_samples: int = None,
        verbose: bool = False,
    ) -> Dict:
        """
        Estimate CATE for all units.

        Args:
            data: LoadedData with X, T, Y arrays
            include_uncertainty: Whether to compute credible intervals
            confidence_level: Confidence level for intervals (e.g., 0.95)
            n_samples: Number of samples for uncertainty estimation
            verbose: Print progress

        Returns:
            Dictionary with cate_estimates, optionally credible_intervals
        """
        if n_samples is None:
            n_samples = CONFIG.default_n_samples

        # Use calibration if uncertainty is requested
        calibrate = include_uncertainty and CONFIG.calibrate_by_default
        estimator = self._get_or_fit_estimator(data, calibrate=calibrate, verbose=verbose)

        # Estimate CATE
        cate_estimates = estimator.estimate_cate(data.X)

        result = {
            "cate_estimates": cate_estimates,
        }

        # Compute credible intervals if requested
        if include_uncertainty:
            alpha = 1.0 - confidence_level
            ci_result = estimator.estimate_cate_CI(
                data.X, alpha=alpha, n_samples=n_samples
            )
            result["credible_intervals"] = np.stack(
                [ci_result["lower_bound"].squeeze(), ci_result["upper_bound"].squeeze()],
                axis=1,
            )

        return result

    def estimate_ate(
        self,
        data: LoadedData,
        confidence_level: float = 0.95,
        n_samples: int = None,
        verbose: bool = False,
    ) -> Dict:
        """
        Estimate ATE with credible interval.

        Args:
            data: LoadedData with X, T, Y arrays
            confidence_level: Confidence level for interval
            n_samples: Number of samples for uncertainty estimation
            verbose: Print progress

        Returns:
            Dictionary with ate, credible_interval
        """
        if n_samples is None:
            n_samples = CONFIG.default_n_samples

        # Always calibrate for ATE to get good intervals
        calibrate = CONFIG.calibrate_by_default
        estimator = self._get_or_fit_estimator(data, calibrate=calibrate, verbose=verbose)

        # Get ATE with CI
        alpha = 1.0 - confidence_level
        ate_result = estimator.estimate_ate_CI(data.X, alpha=alpha, n_samples=n_samples)

        return {
            "ate": float(ate_result.get("ate", estimator.estimate_ate(data.X))),
            "credible_interval": [
                float(ate_result["lower_bound"].squeeze()),
                float(ate_result["upper_bound"].squeeze()),
            ],
        }

    def estimate_cate_for_ranking(
        self,
        data: LoadedData,
        verbose: bool = False,
    ) -> np.ndarray:
        """
        Estimate CATE for ranking purposes (no uncertainty needed).

        Args:
            data: LoadedData with X, T, Y arrays
            verbose: Print progress

        Returns:
            Array of CATE estimates
        """
        estimator = self._get_or_fit_estimator(data, calibrate=False, verbose=verbose)
        return estimator.estimate_cate(data.X)

    @property
    def device(self) -> str:
        """Return the device being used."""
        return self._device

    def clear_cache(self):
        """Clear all cached estimators."""
        self._fitted_estimators.clear()


# Global model manager instance
_model_manager: Optional[CausalPFNModelManager] = None


def get_model_manager() -> CausalPFNModelManager:
    """Get or create the global model manager."""
    global _model_manager
    if _model_manager is None:
        _model_manager = CausalPFNModelManager()
    return _model_manager
