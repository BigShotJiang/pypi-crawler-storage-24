"""Entry point for running causalmcp as a module: python -m causalmcp"""
from .server import main

if __name__ == "__main__":
    main()
