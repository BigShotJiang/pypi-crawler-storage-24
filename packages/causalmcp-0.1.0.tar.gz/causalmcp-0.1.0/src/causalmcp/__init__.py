"""CausalPFN MCP Server - Causal effect estimation via MCP tools."""

__version__ = "0.1.0"
