"""Configuration defaults for CausalPFN MCP server."""

import os
from dataclasses import dataclass


@dataclass
class Config:
    """Server configuration with sensible defaults."""

    # Model settings
    model_path: str = "vdblm/causalpfn"
    device: str = "auto"  # "auto", "cpu", or "cuda:0"

    # Context length limits (PFN-style models degrade on very large contexts)
    max_context_length: int = 4096
    max_query_length: int = 4096
    num_neighbours: int = 1024

    # Data size thresholds
    max_dataset_size: int = 10_000  # Subsample if larger
    min_dataset_size: int = 20  # Error if smaller
    warn_dataset_size: int = 100  # Warn if smaller

    # Output truncation
    max_output_array_size: int = 1000  # Return summary + file for larger arrays

    # Uncertainty estimation
    default_n_samples: int = 10_000
    default_confidence_level: float = 0.95

    # Diagnostics thresholds
    propensity_extreme_threshold: float = 0.05  # Flag if <0.05 or >0.95
    smd_imbalance_threshold: float = 0.1  # Standardized mean diff threshold
    min_group_fraction: float = 0.1  # Flag if treatment or control <10%

    # Calibration settings
    calibrate_by_default: bool = True
    n_calibration_folds: int = 3


def get_config() -> Config:
    """Get configuration from environment variables with fallbacks."""
    config = Config()

    # Override from environment
    if os.environ.get("CAUSALPFN_DEVICE"):
        config.device = os.environ["CAUSALPFN_DEVICE"]

    if os.environ.get("CAUSALPFN_MAX_CONTEXT"):
        config.max_context_length = int(os.environ["CAUSALPFN_MAX_CONTEXT"])
        config.max_query_length = int(os.environ["CAUSALPFN_MAX_CONTEXT"])

    if os.environ.get("CAUSALPFN_MAX_DATASET"):
        config.max_dataset_size = int(os.environ["CAUSALPFN_MAX_DATASET"])

    return config


# Global config instance
CONFIG = get_config()
