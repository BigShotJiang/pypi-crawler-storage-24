# causalMCP

An MCP server that enables causal effect estimation from observational data via simple tool calls. Powered by [CausalPFN](https://github.com/vdblm/CausalPFN) — a pretrained transformer for causal inference.

**Answer questions like "did this intervention cause this outcome?" directly from your data, with no ML expertise required.**

## Features

- **`estimate_cate`** — Individual-level treatment effects (CATE) for each unit
- **`estimate_ate`** — Population-level average treatment effect with credible intervals
- **`estimate_uplift_ranking`** — Rank units by predicted treatment benefit for targeting
- **`run_causal_diagnostics`** — Pre-estimation checks (positivity, covariate balance, overlap)

## Installation

```bash
pip install causalMCP
```

## Quick Start

### Claude Desktop

Add to `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "causalmcp": {
      "command": "causalmcp",
      "env": {
        "OMP_NUM_THREADS": "1"
      }
    }
  }
}
```

### Cline (VS Code)

Add to your MCP settings:

```json
{
  "mcpServers": {
    "causalmcp": {
      "command": "causalmcp",
      "type": "stdio",
      "env": {
        "OMP_NUM_THREADS": "1"
      }
    }
  }
}
```

### Claude Code

```json
{
  "mcpServers": {
    "causalmcp": {
      "command": "causalmcp"
    }
  }
}
```

> **Note for Apple Silicon (M1/M2/M3):** The `OMP_NUM_THREADS=1` environment variable is required to prevent threading conflicts.

## Usage Examples

Once configured, ask your AI assistant questions like:

### Estimate Treatment Effects
> "Analyze the causal effect of the marketing campaign on purchase amount using `/path/to/data.csv`. The covariates are age, income, and previous_purchases. Treatment column is 'received_email' and outcome is 'purchase_amount'."

### Run Diagnostics First
> "Run causal diagnostics on my dataset before estimating effects to check if the assumptions are reasonable."

### Uplift Modeling
> "Rank customers by who would benefit most from the promotional offer so we can target our campaign."

## Data Format

Your CSV should have:
- **Covariate columns (X)** — Features that may affect treatment and outcome
- **Treatment column (T)** — Binary (0/1) indicating treatment assignment
- **Outcome column (Y)** — The outcome you're measuring

Example:
```csv
age,income,previous_purchases,treatment,purchase_amount
35,55000,3,1,125.50
42,72000,5,0,80.00
28,45000,1,1,95.00
```

## Important Assumptions

⚠️ **Strong Ignorability Required**: CausalPFN assumes that the covariates you provide capture ALL variables that jointly affect both treatment assignment and outcome. If there are unmeasured confounders, estimates may be biased.

This is a fundamental assumption of causal inference from observational data that **cannot be verified from data alone**. Domain expertise is required to assess whether this assumption is plausible for your specific application.

## Requirements

- Python 3.10+
- Works on macOS, Linux, and Windows

## License

Apache 2.0

## Acknowledgments

This package wraps [CausalPFN](https://github.com/vdblm/CausalPFN) by Balazadeh et al. — a pretrained transformer for amortized causal effect estimation.
