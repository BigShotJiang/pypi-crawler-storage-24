import pandas as pd
from omerbio import run_promethee_analysis, generate_radar_plots
import unittest
import os
import pymupdf
import hashlib


class TestPrometheeAnalysis(unittest.TestCase):
    def test_run_promethee_analysis(self):
        data = pd.DataFrame(
            {
                "Crit1": [1, 2, 3],
                "Crit2": [4, 5, 6],
                "Crit3": [7, 8, 9],
            }
        )
        weights = pd.DataFrame(
            [0.4, 0.3, 0.3], index=["Crit1", "Crit2", "Crit3"]
        )
        criteria = pd.DataFrame([True, False, True])

        result = run_promethee_analysis(
            data, weights, criteria, pref_type=1, q_param=0, p_param=1
        )
        self.assertIn("PrometheeScore", result.columns)
        self.assertEqual(
            result["Crit1"].values.tolist(), data["Crit1"].values.tolist()
        )
        self.assertEqual(
            result["Crit2"].values.tolist(), data["Crit2"].values.tolist()
        )
        self.assertEqual(
            result["Crit3"].values.tolist(), data["Crit3"].values.tolist()
        )
        self.assertEqual(
            result["PrometheeScore"].values.round(6).tolist(),
            [0.0, 0.67, -0.67],
        )

    def test_radar_plot(self):
        data = pd.DataFrame(
            {
                "Crit1": [1, 2, 3],
                "Crit2": [4, 5, 6],
                "Crit3": [7, 8, 9],
                "Crit4": [10, 2, 5],
                "Crit5": [7, 9, 6],
                "Crit6": [7, 8, 23],
            },
            index=["A", "B", "C"],
        )
        generate_radar_plots(
            data,
            indexes=["A", "B", "C"],
            pdf_path="tests/test_tmp/test_plots.pdf",
        )
        self.assertTrue(os.path.exists("tests/test_tmp/test_plots.pdf"))
        output_file = pymupdf.open("tests/test_tmp/test_plots.pdf")
        expected_hash = [
            "995a6ca83a5ae01c15450e21fd030d78",
            "1f4cd47a9472df7ca784e167fe804b5d",
            "0e043ddf1888ff02331c2f83d4660482",
        ]
        self.assertEqual(output_file.page_count, 3)
        for i in range(3):
            self.assertEqual(
                hashlib.md5(
                    output_file.load_page(i).get_pixmap(dpi=24).tobytes()
                ).hexdigest(),
                expected_hash[i],
            )
        os.remove("tests/test_tmp/test_plots.pdf")
        os.rmdir("tests/test_tmp")


if __name__ == "__main__":
    unittest.main()
