# Python package: omerbio

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
<!--  [![MetaboHUB Logo](https://forge.inrae.fr/pfem/gitlab-tools/-/raw/init/projects-templates/logos/metabohub_logo-20x20.png)![MetaboHUB title](https://img.shields.io/badge/MetaboHub-Software-0066cc?style=flat-square)](https://www.metabohub.fr)  -->

## Metadata

- authors: <etienne.jules@inrae.fr> 
- creation date: `2025-08-19`
- main usage: This repo contains the code for the omerbio python package. A Promethee multi-criteria analysis weighted by PCA.

## Description

This package implements a multi-criteria analysis of data using Promethee method, with a weighing procedure based of principal components analysis (PCA).

## Features

The main functions are:
- `run_promethee_analysis`: Execute the multi-criteria analysis
- `generate_radar_plots`: Generates a pdf with radar plots of individuals on a set of criteria.

## Getting Started

These instructions will get you a copy of the project up and running on your local machine for development and testing purposes. 

### Prerequisites


Before you begin, ensure you have met the following requirements:

- **Operating System**: Windows 10+, macOS 10.14+, or Linux
- **Programming Language**: [Python] version 3.6 or higher
- **Package Manager**: [pip] version 24.1 or higher
- **Other dependencies**: Python packages: matplotlib, pandas, numpy, Promethee, sklearn

### Installing

Clone the repo and install the package localy (soon available via pip gitlab or pypi) :

```bash
git clone https://forge.inrae.fr/pfem/dev/libs/omerbio
cd src
pip install -e .
```


### Running the tests

In the root folder of this repository run:
```
python -m unittest
```
This runs the unit test of the package functions.

## Changelog

COMING SOON !

## Authors

- **Elfried Salanon** - *Initial idea and implentation* - MTH, INRAE, UNH, PFEM
- **Salomon Gouiri Loembe** - *First packaging work* - INRAE, UNH, PFEM
- **Marie Lefebvre** - *Project management* - MTH, INRAE, UNH, PFEM
- **Etienne Jules** - *Project management, final packaging, maintainer* - MTH, INRAE, UNH, PFEM

## License

**Omerbio** is distributed under the ~~MIT License~~.

Please refer to [LICENSE](LICENSE) file for further details.

## Support &amp; External resources

<!-- NOTE: this section is facultative; customize / remove useless / add relevant / ... items in the list below -->

- :book: **Documentation** - Coming soon !
- :bug: **Bug Reports** - [GitLab Issues](https://forge.inrae.fr/pfem/dev/libs/omerbio/-/issues)
- :email: **Email** - <etienne.jules@inrae.fr>

## Acknowledgments

<!-- NOTE: this section is required -->

- Thanks to Elfried Salanon, Salomon Gouiri Loembe, Marie Lefebvre and Etienne Jules for their valuable contributions
- Inspired by and built with [Promethee python package](https://pypi.org/project/Promethee/)
- Special thanks to the open-source community

---