from __future__ import annotations

import base64
import copy
import json
import os
import re
from typing import Any, Dict, Optional, Tuple
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin
from urllib.request import Request, urlopen

from f40_toolkit.common import deep_merge


class RemoteConfigError(RuntimeError):
    pass


def parse_bool(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() not in ("", "0", "false", "no", "off")
    return bool(value)


def _env(name: Optional[str]) -> Optional[str]:
    if not name:
        return None
    value = os.getenv(name)
    return value if value not in (None, "") else None


def _value_or_env(value: Any, env_name: Optional[str]) -> Any:
    env_value = _env(env_name)
    if env_value is not None:
        return env_value
    return value


def _build_headers(remote_cfg: Dict[str, Any]) -> Dict[str, str]:
    headers = {"Accept": "application/json"}

    auth = remote_cfg.get("auth", {}) or {}
    mode = str(auth.get("mode", "none")).strip().lower()

    if mode in ("", "none"):
        return headers

    if mode == "bearer":
        token = _env(auth.get("token_env")) or auth.get("token")
        if not token:
            raise RemoteConfigError("Missing bearer token for remote config")
        headers["Authorization"] = f"Bearer {token}"
        return headers

    if mode == "header":
        header_name = auth.get("header_name")
        header_secret = _env(auth.get("header_secret_env")) or auth.get("header_secret")
        if not header_name or not header_secret:
            raise RemoteConfigError("Missing header auth data for remote config")
        headers[str(header_name)] = str(header_secret)
        return headers

    if mode == "basic":
        username = _env(auth.get("username_env")) or auth.get("username")
        password = _env(auth.get("password_env")) or auth.get("password")
        if username is None or password is None:
            raise RemoteConfigError("Missing basic auth credentials for remote config")
        encoded = base64.b64encode(f"{username}:{password}".encode("utf-8")).decode(
            "ascii"
        )
        headers["Authorization"] = f"Basic {encoded}"
        return headers

    raise RemoteConfigError(f"Unsupported remote auth mode: {mode}")


def _normalize_relative_path(path: str) -> str:
    if not isinstance(path, str) or not path.strip():
        raise RemoteConfigError("Remote path cannot be empty")

    rel = path.replace("\\", "/").strip()

    while rel.startswith("./"):
        rel = rel[2:]
    while rel.startswith("/"):
        rel = rel[1:]

    parts = [p for p in rel.split("/") if p not in ("", ".")]
    if any(p == ".." for p in parts):
        raise RemoteConfigError(f"Unsupported path traversal in remote path: {path}")

    return "/".join(parts)


def _join_remote_path(prefix: str | None, path: str) -> str:
    rel = _normalize_relative_path(path)
    if not prefix:
        return rel
    clean_prefix = str(prefix).replace("\\", "/").strip("/")
    return f"{clean_prefix}/{rel}" if clean_prefix else rel


def _template_context(
    remote_cfg: Dict[str, Any], extra: Optional[Dict[str, Any]] = None
) -> Dict[str, str]:
    ctx: Dict[str, str] = {}

    for key, value in remote_cfg.items():
        if isinstance(value, (str, int, float, bool)) and value is not None:
            ctx[key] = str(value)

    if isinstance(extra, dict):
        for key, value in extra.items():
            if value is not None:
                ctx[key] = str(value)

    for key, value in os.environ.items():
        ctx.setdefault(key, value)

    return ctx


def _format_template(
    value: str,
    remote_cfg: Dict[str, Any],
    extra: Optional[Dict[str, Any]] = None,
) -> str:
    ctx = _template_context(remote_cfg, extra)
    try:
        return value.format(**ctx)
    except KeyError as exc:
        missing = exc.args[0]
        raise RemoteConfigError(
            f"Missing placeholder '{missing}' while formatting remote template: {value}"
        ) from exc


def _resolve_remote_relative_path(
    logical_name: str,
    remote_cfg: Dict[str, Any],
    extra: Optional[Dict[str, Any]] = None,
) -> str:
    """
    Translate a logical config layer name (e.g. "base/default",
    "projects/acme/prod-1") into the remote relative path.

    Priority:
      1. exact path_aliases match
      2. first regex rule in path_rules
      3. default: same logical name
    """
    logical = _normalize_relative_path(logical_name)

    path_aliases = remote_cfg.get("path_aliases", {}) or {}
    if path_aliases and not isinstance(path_aliases, dict):
        raise RemoteConfigError("remote_config.path_aliases must be an object")

    if logical in path_aliases:
        rendered = _format_template(str(path_aliases[logical]), remote_cfg, extra=extra)
        return _normalize_relative_path(rendered)

    path_rules = remote_cfg.get("path_rules", []) or []
    if path_rules and not isinstance(path_rules, list):
        raise RemoteConfigError("remote_config.path_rules must be a list")

    for idx, rule in enumerate(path_rules):
        if not isinstance(rule, dict):
            raise RemoteConfigError(
                f"remote_config.path_rules[{idx}] must be an object"
            )

        pattern = rule.get("pattern")
        target = rule.get("target")
        if not pattern or not target:
            raise RemoteConfigError(
                f"remote_config.path_rules[{idx}] requires both 'pattern' and 'target'"
            )

        match = re.fullmatch(str(pattern), logical)
        if not match:
            continue

        template_extra = dict(extra or {})
        template_extra.update(match.groupdict())
        for i, group in enumerate(match.groups(), start=1):
            template_extra[f"g{i}"] = group

        rendered = _format_template(str(target), remote_cfg, extra=template_extra)
        return _normalize_relative_path(rendered)

    return logical


def _resolve_remote_object_path(
    logical_name: str,
    remote_cfg: Dict[str, Any],
    extra: Optional[Dict[str, Any]] = None,
) -> str:
    rel = _resolve_remote_relative_path(logical_name, remote_cfg, extra=extra)

    raw_prefix = remote_cfg.get("path_prefix", "") or ""
    prefix = (
        _format_template(str(raw_prefix), remote_cfg, extra=extra) if raw_prefix else ""
    )

    return _join_remote_path(prefix, rel)


def _build_remote_url(root_url: str, remote_path: str) -> str:
    root = str(root_url or "").strip()
    if not root:
        raise RemoteConfigError("remote_config.root_url is missing")
    if not root.endswith("/"):
        root += "/"
    return urljoin(root, _normalize_relative_path(remote_path))


def _load_json_payload(payload: str, source: str) -> Dict[str, Any]:
    try:
        data = json.loads(payload)
    except json.JSONDecodeError as exc:
        raise RemoteConfigError(f"Remote config at {source} is not valid JSON") from exc

    if not isinstance(data, dict):
        raise RemoteConfigError(f"Remote config at {source} must be a JSON object")

    return data


def load_remote_settings(
    base_config: Dict[str, Any],
    *,
    env_prefix: str = "F40_",
) -> Dict[str, Any]:
    """
    Resolve remote_config from the already loaded local config, with env overrides.

    This is the bootstrap step. Credentials for remote access must still come from
    env vars or from plain values in remote_config, not from a remote secret store.
    """
    raw = base_config.get("remote_config", {})
    remote_cfg = copy.deepcopy(raw if isinstance(raw, dict) else {})

    prefix = env_prefix or "F40_"

    def _set_from_env(env_suffix: str, key: str, cast=None) -> None:
        env_name = f"{prefix}{env_suffix}"
        if env_name not in os.environ:
            return
        value = os.getenv(env_name)
        if cast:
            remote_cfg[key] = cast(value)
        else:
            remote_cfg[key] = value

    _set_from_env("REMOTE_CONFIG_ENABLED", "enabled", lambda v: parse_bool(v, False))
    _set_from_env("REMOTE_CONFIG_MODE", "mode")
    _set_from_env("REMOTE_CONFIG_PROVIDER", "provider")
    _set_from_env("REMOTE_CONFIG_URL", "url")
    _set_from_env("REMOTE_CONFIG_ROOT_URL", "root_url")
    _set_from_env("REMOTE_CONFIG_OBJECT_PATH", "object_path")
    _set_from_env("REMOTE_CONFIG_BUCKET_NAME", "bucket_name")
    _set_from_env("REMOTE_CONFIG_PATH_PREFIX", "path_prefix")
    _set_from_env("REMOTE_CONFIG_ENDPOINT_URL", "endpoint_url")
    _set_from_env("REMOTE_CONFIG_REGION_NAME", "region_name")
    _set_from_env("REMOTE_CONFIG_ADDRESSING_STYLE", "addressing_style")
    _set_from_env("REMOTE_CONFIG_PROJECT", "project")
    _set_from_env("REMOTE_CONFIG_STAGE", "stage")
    _set_from_env("REMOTE_CONFIG_ENV", "env")
    _set_from_env(
        "REMOTE_CONFIG_ALLOW_LOCAL_FALLBACK",
        "allow_local_fallback",
        lambda v: parse_bool(v, False),
    )

    timeout_env = f"{prefix}REMOTE_CONFIG_TIMEOUT_SECONDS"
    if timeout_env in os.environ:
        try:
            remote_cfg["timeout_seconds"] = float(os.getenv(timeout_env, "5"))
        except ValueError:
            pass

    # Optional direct secret injection via prefixed env vars
    _set_from_env("REMOTE_CONFIG_ACCESS_KEY", "access_key")
    _set_from_env("REMOTE_CONFIG_SECRET_KEY", "secret_key")

    # Sensible template defaults from the service env
    remote_cfg.setdefault("project", os.getenv(f"{prefix}PROJECT", ""))
    remote_cfg.setdefault("stage", os.getenv(f"{prefix}ENV", ""))
    remote_cfg.setdefault("env", os.getenv(f"{prefix}ENV", ""))

    return remote_cfg


def is_mirrored_layer_mode(remote_cfg: Dict[str, Any]) -> bool:
    return parse_bool(remote_cfg.get("enabled", False), False) and (
        str(remote_cfg.get("mode", "")).strip().lower() == "mirrored_layers"
    )


def _fetch_remote_layer_http(
    logical_name: str,
    remote_cfg: Dict[str, Any],
    extra: Optional[Dict[str, Any]] = None,
) -> Tuple[Dict[str, Any], str]:
    remote_path = _resolve_remote_object_path(logical_name, remote_cfg, extra=extra)
    url = _build_remote_url(str(remote_cfg.get("root_url", "")).strip(), remote_path)

    timeout_seconds = float(remote_cfg.get("timeout_seconds", 5))
    request = Request(url, headers=_build_headers(remote_cfg), method="GET")

    try:
        with urlopen(request, timeout=timeout_seconds) as response:
            payload = response.read().decode("utf-8")
    except HTTPError as exc:
        raise RemoteConfigError(
            f"Remote config HTTP error {exc.code} while reading {url}"
        ) from exc
    except URLError as exc:
        raise RemoteConfigError(
            f"Remote config connection error while reading {url}: {exc}"
        ) from exc

    return _load_json_payload(payload, url), url


def _fetch_remote_layer_s3(
    logical_name: str,
    remote_cfg: Dict[str, Any],
    extra: Optional[Dict[str, Any]] = None,
) -> Tuple[Dict[str, Any], str]:
    try:
        import boto3
        from botocore.config import Config as BotoConfig
        from botocore.exceptions import BotoCoreError, ClientError
    except ImportError as exc:
        raise RemoteConfigError(
            "boto3 is required for remote_config.provider='s3'"
        ) from exc

    bucket_name = str(remote_cfg.get("bucket_name", "")).strip()
    if not bucket_name:
        raise RemoteConfigError(
            "remote_config.bucket_name is required for provider='s3'"
        )

    key = _resolve_remote_object_path(logical_name, remote_cfg, extra=extra)
    endpoint_url = _value_or_env(
        remote_cfg.get("endpoint_url"),
        remote_cfg.get("endpoint_url_env"),
    )
    region_name = _value_or_env(
        remote_cfg.get("region_name"),
        remote_cfg.get("region_name_env"),
    )
    access_key = _value_or_env(
        remote_cfg.get("access_key"),
        remote_cfg.get("access_key_env"),
    )
    secret_key = _value_or_env(
        remote_cfg.get("secret_key"),
        remote_cfg.get("secret_key_env"),
    )
    session_token = _value_or_env(
        remote_cfg.get("session_token"),
        remote_cfg.get("session_token_env"),
    )
    address_style = (
        str(remote_cfg.get("addressing_style", "path")).strip().lower() or "path"
    )
    timeout_seconds = float(remote_cfg.get("timeout_seconds", 5))

    client_kwargs = {
        "service_name": "s3",
        "endpoint_url": endpoint_url,
        "region_name": region_name,
        "aws_access_key_id": access_key,
        "aws_secret_access_key": secret_key,
        "aws_session_token": session_token,
        "config": BotoConfig(
            signature_version="s3v4",
            connect_timeout=timeout_seconds,
            read_timeout=timeout_seconds,
            retries={"max_attempts": 2},
            s3={"addressing_style": address_style},
        ),
    }
    client_kwargs = {k: v for k, v in client_kwargs.items() if v is not None}

    try:
        client = boto3.client(**client_kwargs)
        response = client.get_object(Bucket=bucket_name, Key=key)
        payload = response["Body"].read().decode("utf-8")
    except (ClientError, BotoCoreError, KeyError) as exc:
        raise RemoteConfigError(
            f"S3 remote config read failed for s3://{bucket_name}/{key}: {exc}"
        ) from exc

    source = f"s3://{bucket_name}/{key}"
    return _load_json_payload(payload, source), source


def _resolve_overlay_object_path(
    remote_cfg: Dict[str, Any],
    extra: Optional[Dict[str, Any]] = None,
) -> str:
    object_path = str(remote_cfg.get("object_path", "")).strip()
    if not object_path:
        raise RemoteConfigError(
            "remote_config.object_path is required for this remote overlay provider"
        )

    rendered = _format_template(object_path, remote_cfg, extra=extra)
    raw_prefix = remote_cfg.get("path_prefix", "") or ""
    prefix = (
        _format_template(str(raw_prefix), remote_cfg, extra=extra) if raw_prefix else ""
    )
    return _join_remote_path(prefix, rendered)


def _fetch_remote_overlay_http(
    remote_cfg: Dict[str, Any],
    extra: Optional[Dict[str, Any]] = None,
) -> Tuple[Dict[str, Any], str]:
    url = str(remote_cfg.get("url", "")).strip()
    if not url:
        root_url = str(remote_cfg.get("root_url", "")).strip()
        if not root_url:
            raise RemoteConfigError(
                "remote_config.url or remote_config.root_url + object_path is required for provider='http'"
            )
        object_path = _resolve_overlay_object_path(remote_cfg, extra=extra)
        url = _build_remote_url(root_url, object_path)

    timeout_seconds = float(remote_cfg.get("timeout_seconds", 5))
    request = Request(url, headers=_build_headers(remote_cfg), method="GET")

    try:
        with urlopen(request, timeout=timeout_seconds) as response:
            payload = response.read().decode("utf-8")
    except HTTPError as exc:
        raise RemoteConfigError(
            f"Remote config HTTP error {exc.code} while reading {url}"
        ) from exc
    except URLError as exc:
        raise RemoteConfigError(
            f"Remote config connection error while reading {url}: {exc}"
        ) from exc

    return _load_json_payload(payload, url), url


def _fetch_remote_overlay_s3(
    remote_cfg: Dict[str, Any],
    extra: Optional[Dict[str, Any]] = None,
) -> Tuple[Dict[str, Any], str]:
    try:
        import boto3
        from botocore.config import Config as BotoConfig
        from botocore.exceptions import BotoCoreError, ClientError
    except ImportError as exc:
        raise RemoteConfigError(
            "boto3 is required for remote_config.provider='s3'"
        ) from exc

    bucket_name = str(remote_cfg.get("bucket_name", "")).strip()
    if not bucket_name:
        raise RemoteConfigError(
            "remote_config.bucket_name is required for provider='s3'"
        )

    key = _resolve_overlay_object_path(remote_cfg, extra=extra)
    endpoint_url = _value_or_env(
        remote_cfg.get("endpoint_url"),
        remote_cfg.get("endpoint_url_env"),
    )
    region_name = _value_or_env(
        remote_cfg.get("region_name"),
        remote_cfg.get("region_name_env"),
    )
    access_key = _value_or_env(
        remote_cfg.get("access_key"),
        remote_cfg.get("access_key_env"),
    )
    secret_key = _value_or_env(
        remote_cfg.get("secret_key"),
        remote_cfg.get("secret_key_env"),
    )
    session_token = _value_or_env(
        remote_cfg.get("session_token"),
        remote_cfg.get("session_token_env"),
    )
    address_style = (
        str(remote_cfg.get("addressing_style", "path")).strip().lower() or "path"
    )
    timeout_seconds = float(remote_cfg.get("timeout_seconds", 5))

    client_kwargs = {
        "service_name": "s3",
        "endpoint_url": endpoint_url,
        "region_name": region_name,
        "aws_access_key_id": access_key,
        "aws_secret_access_key": secret_key,
        "aws_session_token": session_token,
        "config": BotoConfig(
            signature_version="s3v4",
            connect_timeout=timeout_seconds,
            read_timeout=timeout_seconds,
            retries={"max_attempts": 2},
            s3={"addressing_style": address_style},
        ),
    }
    client_kwargs = {k: v for k, v in client_kwargs.items() if v is not None}

    try:
        client = boto3.client(**client_kwargs)
        response = client.get_object(Bucket=bucket_name, Key=key)
        payload = response["Body"].read().decode("utf-8")
    except (ClientError, BotoCoreError, KeyError) as exc:
        raise RemoteConfigError(
            f"S3 remote config read failed for s3://{bucket_name}/{key}: {exc}"
        ) from exc

    source = f"s3://{bucket_name}/{key}"
    return _load_json_payload(payload, source), source


def load_remote_layer(
    logical_name: str,
    remote_cfg: Dict[str, Any],
    *,
    logger=None,
    extra: Optional[Dict[str, Any]] = None,
) -> Tuple[Dict[str, Any], Optional[str]]:
    """
    Load one logical config layer from a remote mirrored storage layout.

    Examples of logical_name:
      - base/default
      - base/logging
      - shared/endpoints_permissions
      - projects/acme/common
      - projects/acme/prod-1
    """
    if not parse_bool(remote_cfg.get("enabled", False), False):
        return {}, None

    provider = str(remote_cfg.get("provider", "http")).strip().lower()

    try:
        if provider in ("http", "https"):
            data, source = _fetch_remote_layer_http(
                logical_name, remote_cfg, extra=extra
            )
        elif provider == "s3":
            data, source = _fetch_remote_layer_s3(logical_name, remote_cfg, extra=extra)
        else:
            raise RemoteConfigError(f"Unsupported remote_config.provider: {provider}")

        if logger:
            logger.info(f"Loaded mirrored remote layer '{logical_name}' from {source}")
        return data, source

    except Exception as exc:
        if parse_bool(remote_cfg.get("allow_local_fallback", False), False):
            if logger:
                logger.warning(
                    f"Remote layer unavailable for '{logical_name}', using local only: {exc}"
                )
            return {}, None
        raise


def apply_remote_overlay(
    base_config: Dict[str, Any],
    *,
    remote_cfg: Optional[Dict[str, Any]] = None,
    logger=None,
) -> Tuple[Dict[str, Any], Optional[str]]:
    """
    Backward-compatible overlay behavior:
      - if remote_config.mode == mirrored_layers -> do nothing here
      - otherwise fetch one remote JSON blob and overlay it on top of the
        already-loaded local config.

    Supported overlay sources:
      - provider=http + url
      - provider=http + root_url + object_path
      - provider=s3 + bucket_name + object_path

    Legacy configs that only set remote_config.url continue to work.
    """
    remote_cfg = remote_cfg or load_remote_settings(base_config)

    if not parse_bool(remote_cfg.get("enabled", False), False):
        return base_config, None

    if is_mirrored_layer_mode(remote_cfg):
        return base_config, None

    provider = str(remote_cfg.get("provider", "http")).strip().lower() or "http"
    overlay_extra = {
        "project": remote_cfg.get("project") or os.getenv("F40_PROJECT", ""),
        "stage": remote_cfg.get("stage") or remote_cfg.get("env") or os.getenv("F40_ENV", ""),
        "env": remote_cfg.get("env") or remote_cfg.get("stage") or os.getenv("F40_ENV", ""),
    }

    try:
        if provider in ("http", "https"):
            remote_data, source = _fetch_remote_overlay_http(
                remote_cfg,
                extra=overlay_extra,
            )
        elif provider == "s3":
            remote_data, source = _fetch_remote_overlay_s3(
                remote_cfg,
                extra=overlay_extra,
            )
        else:
            raise RemoteConfigError(f"Unsupported remote_config.provider: {provider}")

        merged = deep_merge(base_config, remote_data)
        if logger:
            logger.info(f"Loaded remote config overlay from {source}")
        return merged, source

    except (HTTPError, URLError, json.JSONDecodeError, RemoteConfigError) as exc:
        if parse_bool(remote_cfg.get("allow_local_fallback", False), False):
            if logger:
                logger.warning(
                    f"Remote config unavailable, using local configuration only: {exc}"
                )
            return base_config, None
        raise
