from __future__ import annotations

from contextvars import Token

from .context import bind_log_context, log_context, unbind_log_context


def bind_request(
    request_id: str,
    *,
    user: str | None = None,
    trace_id: str | None = None,
    span_id: str | None = None,
) -> Token:
    return bind_log_context(
        request_id=request_id,
        user=user,
        trace_id=trace_id,
        span_id=span_id,
    )


def request_context(
    request_id: str,
    *,
    user: str | None = None,
    trace_id: str | None = None,
    span_id: str | None = None,
):
    return log_context(
        request_id=request_id,
        user=user,
        trace_id=trace_id,
        span_id=span_id,
    )


def clear_request() -> None:
    unbind_log_context("request_id", "user", "trace_id", "span_id")
