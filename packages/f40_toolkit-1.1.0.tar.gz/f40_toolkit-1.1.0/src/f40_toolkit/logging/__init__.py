from .core import configure_logging, get_logger, get_main_logger
from .context import (
    bind_log_context,
    reset_log_context,
    clear_log_context,
    unbind_log_context,
    log_context,
    get_log_context,
)
from .request import bind_request, request_context, clear_request
from .session import bind_session, session_context, clear_session


def __getattr__(name: str):
    if name == "main_logger":
        return get_main_logger()
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "configure_logging",
    "get_logger",
    "get_main_logger",
    "main_logger",
    "bind_log_context",
    "reset_log_context",
    "clear_log_context",
    "unbind_log_context",
    "log_context",
    "get_log_context",
    "bind_session",
    "session_context",
    "clear_session",
    "bind_request",
    "request_context",
    "clear_request",
]
