from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any, Iterable, Mapping, Optional

STANDARD_LOG_RECORD_ATTRS = frozenset(logging.makeLogRecord({}).__dict__.keys()) | {
    "message",
    "asctime",
}

RESERVED_PAYLOAD_KEYS = frozenset(
    {
        "ts",
        "level",
        "logger",
        "message",
        "module",
        "func",
        "line",
        "process",
        "thread",
        "exception",
        "stack",
        "fields",
    }
)

UNSAFE_CONTEXT_KEYS = STANDARD_LOG_RECORD_ATTRS | RESERVED_PAYLOAD_KEYS


class TextFormatter(logging.Formatter):
    def __init__(
        self,
        fmt: Optional[str] = None,
        datefmt: Optional[str] = None,
        *,
        defaults: Optional[Mapping[str, Any]] = None,
    ) -> None:
        super().__init__(fmt=fmt, datefmt=datefmt)
        self.defaults = dict(defaults or {})

    def format(self, record: logging.LogRecord) -> str:
        for key, value in self.defaults.items():
            if not hasattr(record, key):
                setattr(record, key, value)
        return super().format(record)


class JsonFormatter(logging.Formatter):
    def __init__(
        self,
        *,
        defaults: Optional[Mapping[str, Any]] = None,
        extra_fields: Optional[Iterable[str]] = None,
        parse_json_message: bool = False,
    ) -> None:
        super().__init__()
        self.defaults = dict(defaults or {})
        self.extra_fields = list(extra_fields or [])
        self.parse_json_message = parse_json_message

    def _coerce_structured_message(
        self, record: logging.LogRecord
    ) -> Mapping[str, Any] | None:
        if isinstance(record.msg, Mapping):
            return record.msg

        if not self.parse_json_message:
            return None

        if not isinstance(record.msg, str) or record.args:
            return None

        raw = record.msg.strip()
        if not (raw.startswith("{") and raw.endswith("}")):
            return None

        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError:
            return None

        return parsed if isinstance(parsed, Mapping) else None

    def format(self, record: logging.LogRecord) -> str:
        for key, value in self.defaults.items():
            if not hasattr(record, key):
                setattr(record, key, value)

        structured_msg = self._coerce_structured_message(record)
        message_value = (
            structured_msg.get("message")
            if isinstance(structured_msg, Mapping)
            else record.getMessage()
        )

        payload: dict[str, Any] = {
            "ts": datetime.fromtimestamp(record.created, tz=timezone.utc).isoformat(
                timespec="milliseconds"
            ),
            "level": record.levelname,
            "logger": record.name,
            "message": "" if message_value in (None, "", "-") else message_value,
            "module": record.module,
            "func": record.funcName,
            "line": record.lineno,
            "process": record.processName,
            "thread": record.threadName,
        }

        extra_payload: dict[str, Any] = {}

        def add_top_level_or_fields(key: str, value: Any) -> None:
            if value in (None, "", "-"):
                return
            if key in RESERVED_PAYLOAD_KEYS:
                extra_payload.setdefault(key, value)
                return
            payload[key] = value

        # explicitly promoted fields
        for field in self.extra_fields:
            add_top_level_or_fields(field, getattr(record, field, None))

        # structured message fields
        if isinstance(structured_msg, Mapping):
            nested_fields = structured_msg.get("fields")
            if isinstance(nested_fields, Mapping):
                for key, value in nested_fields.items():
                    if value not in (None, "", "-"):
                        extra_payload[str(key)] = value

            for key, value in structured_msg.items():
                if key in {"message", "fields"} or value in (None, "", "-"):
                    continue
                extra_payload.setdefault(str(key), value)

        # caller-provided nested fields
        record_fields = getattr(record, "fields", None)
        if isinstance(record_fields, Mapping):
            for key, value in record_fields.items():
                if value not in (None, "", "-"):
                    extra_payload[str(key)] = value

        # all other custom LogRecord attrs
        for key, value in record.__dict__.items():
            if (
                key in STANDARD_LOG_RECORD_ATTRS
                or key in self.extra_fields
                or key == "fields"
                or key.startswith("_")
            ):
                continue

            if value in (None, "", "-"):
                continue

            if key in RESERVED_PAYLOAD_KEYS:
                extra_payload.setdefault(key, value)
                continue

            if key in payload:
                continue

            extra_payload[key] = value

        if extra_payload:
            payload["fields"] = extra_payload

        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)

        if record.stack_info:
            payload["stack"] = self.formatStack(record.stack_info)

        return json.dumps(payload, ensure_ascii=False, default=str)
