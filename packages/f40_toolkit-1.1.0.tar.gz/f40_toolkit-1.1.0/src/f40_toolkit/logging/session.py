from __future__ import annotations

from contextvars import Token

from .context import bind_log_context, log_context, unbind_log_context


def bind_session(session_id: str) -> Token:
    return bind_log_context(session_id=session_id)


def session_context(session_id: str):
    return log_context(session_id=session_id)


def clear_session() -> None:
    unbind_log_context("session_id")
