from __future__ import annotations

from contextlib import contextmanager
from contextvars import ContextVar, Token
from typing import Any, Dict, Iterator

_LOG_CONTEXT: ContextVar[Dict[str, Any]] = ContextVar("f40_log_context", default={})


def get_log_context() -> Dict[str, Any]:
    return dict(_LOG_CONTEXT.get())


def bind_log_context(**values: Any) -> Token:
    ctx = dict(_LOG_CONTEXT.get())
    for k, v in values.items():
        if v is not None:
            ctx[k] = v
    return _LOG_CONTEXT.set(ctx)


def reset_log_context(token: Token) -> None:
    _LOG_CONTEXT.reset(token)


def clear_log_context() -> None:
    _LOG_CONTEXT.set({})


def unbind_log_context(*keys: str) -> None:
    ctx = dict(_LOG_CONTEXT.get())
    for key in keys:
        ctx.pop(key, None)
    _LOG_CONTEXT.set(ctx)


@contextmanager
def log_context(**values: Any) -> Iterator[None]:
    token = bind_log_context(**values)
    try:
        yield
    finally:
        reset_log_context(token)
