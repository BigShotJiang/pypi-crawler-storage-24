from __future__ import annotations

import logging
import os
import re
import sys
import threading
from logging.handlers import RotatingFileHandler
from typing import Any, Dict, Optional

from .config import LoggingConfig, load_logging_config
from .context import get_log_context
from .formatters import JsonFormatter, TextFormatter, UNSAFE_CONTEXT_KEYS

_main_logger: Optional[logging.Logger] = None
_config: Optional[LoggingConfig] = None
_logger_cache: Dict[str, logging.Logger] = {}
_managed_logger_names: set[str] = set()
_lock = threading.Lock()


# ------------------------------ Helpers -------------------------------- #


def _close_and_remove_handlers(
    logger: logging.Logger,
    *,
    handler_type: (
        type[logging.Handler] | tuple[type[logging.Handler], ...] | None
    ) = None,
) -> None:
    for handler in list(logger.handlers):
        if handler_type is not None and not isinstance(handler, handler_type):
            continue

        logger.removeHandler(handler)

        try:
            handler.flush()
        except Exception:
            pass

        try:
            handler.close()
        except Exception:
            pass


def _cleanup_managed_loggers() -> None:
    global _managed_logger_names

    if _main_logger is not None:
        _close_and_remove_handlers(_main_logger)
        _main_logger.filters.clear()

    for logger_name in list(_managed_logger_names):
        logger = logging.getLogger(logger_name)
        _close_and_remove_handlers(logger, handler_type=RotatingFileHandler)

    _managed_logger_names.clear()


def _normalize_logger_name(name: str, *, base_logger_name: str, channel: str) -> str:
    base_prefix = f"{base_logger_name}."
    channel_prefix = f"{base_logger_name}.{channel}."

    if channel != "default" and (
        name == f"{base_logger_name}.{channel}" or name.startswith(channel_prefix)
    ):
        return name

    if name == base_logger_name:
        suffix = ""
    elif name.startswith(base_prefix):
        suffix = name[len(base_prefix) :]
    else:
        suffix = name

    if not suffix:
        return (
            base_logger_name
            if channel == "default"
            else f"{base_logger_name}.{channel}"
        )

    if channel == "default":
        return f"{base_logger_name}.{suffix}"

    return f"{base_logger_name}.{channel}.{suffix}"


def _safe_filename_component(value: str) -> str:
    safe = value.strip()
    safe = safe.replace(os.sep, ".")
    if os.altsep:
        safe = safe.replace(os.altsep, ".")
    safe = safe.replace(".", "__")
    safe = re.sub(r"[^A-Za-z0-9_-]+", "_", safe)
    return safe or "logger"


class ContextEnricherFilter(logging.Filter):
    def __init__(self, *, static_fields: Optional[Dict[str, Any]] = None) -> None:
        super().__init__()
        self.static_fields = dict(static_fields or {})

    def _safe_set(self, record: logging.LogRecord, key: str, value: Any) -> None:
        if value in (None, ""):
            return
        if key in UNSAFE_CONTEXT_KEYS:
            return
        if not hasattr(record, key):
            setattr(record, key, value)

    def filter(self, record: logging.LogRecord) -> bool:
        # defaults
        self._safe_set(record, "session_id", "-")

        # static fields from config
        for key, value in self.static_fields.items():
            self._safe_set(record, key, value)

        # dynamic ambient context
        for key, value in get_log_context().items():
            self._safe_set(record, key, value)

        return True


def _attach_context_filter(
    handler: logging.Handler, *, static_fields: Optional[Dict[str, Any]] = None
) -> logging.Handler:
    handler.addFilter(ContextEnricherFilter(static_fields=static_fields))
    return handler


class _MaxLevelFilter(logging.Filter):
    def __init__(self, exclusive_max: int) -> None:
        super().__init__()
        self.exclusive_max = exclusive_max

    def filter(self, record: logging.LogRecord) -> bool:
        return record.levelno < self.exclusive_max


def _levelno(value: Any, default: int = logging.INFO) -> int:
    if isinstance(value, int):
        return value
    if isinstance(value, str):
        return getattr(logging, value.upper(), default)
    return default


def _build_formatter(settings: Dict[str, Any]) -> logging.Formatter:
    formatter_name = str(settings.get("formatter", "text")).lower()

    if formatter_name == "json":
        return JsonFormatter(
            defaults=settings.get("defaults", {}),
            extra_fields=settings.get("json_fields", []),
            parse_json_message=bool(settings.get("parse_json_message", False)),
        )

    return TextFormatter(
        fmt=settings.get("text_format"),
        datefmt=settings.get("datefmt"),
        defaults=settings.get("defaults", {}),
    )


def _remove_rotating_file_handlers(logger: logging.Logger) -> None:
    for handler in list(logger.handlers):
        if isinstance(handler, RotatingFileHandler):
            logger.removeHandler(handler)
            try:
                handler.close()
            except Exception:
                pass


def configure_logging(
    *,
    config: Optional[LoggingConfig] = None,
    config_dict: Optional[Dict[str, Any]] = None,
    config_file: Optional[str] = None,
) -> None:
    """
    Configure the global logging setup for f40-toolkit.

    You can:
      - pass a LoggingConfig object directly,
      - OR pass a config_dict / config_file (JSON),
      - OR let it fall back to DEFAULT_CONFIG & env F40_LOGGING_CONFIG_FILE.
    """
    global _main_logger, _config, _logger_cache
    with _lock:
        _cleanup_managed_loggers()

        _config = config or load_logging_config(
            config_dict=config_dict,
            config_file=config_file,
        )

        _logger_cache = {}

        files_conf = _config.files or {}
        main_file_enabled = bool(files_conf.get("main_enabled", False))

        needs_fs = main_file_enabled or any(
            bool(ch.get("file_per_logger", False))
            for ch in (_config.channels or {}).values()
        )
        if needs_fs:
            os.makedirs(_config.logs_path, exist_ok=True)

        console_formatter = _build_formatter(_config.console or {})
        file_formatter = _build_formatter(files_conf)

        main_logger = logging.getLogger(_config.base_logger_name)
        main_logger.setLevel(logging.DEBUG)
        _close_and_remove_handlers(main_logger)
        main_logger.filters.clear()
        main_logger.propagate = False
        console_conf = _config.console or {}
        if bool(console_conf.get("enabled", True)):
            console_level = _levelno(console_conf.get("level", "INFO"))
            stderr_level_raw = console_conf.get("stderr_level", "WARNING")
            console_static_fields = console_conf.get("static_fields", {})

            if stderr_level_raw is None:
                stdout_handler = logging.StreamHandler(sys.stdout)
                stdout_handler.setLevel(console_level)
                _attach_context_filter(
                    stdout_handler,
                    static_fields=console_static_fields,
                )
                stdout_handler.setFormatter(console_formatter)
                main_logger.addHandler(stdout_handler)
            else:
                stderr_level = _levelno(stderr_level_raw)

                stdout_handler = logging.StreamHandler(sys.stdout)
                stdout_handler.setLevel(console_level)
                stdout_handler.addFilter(_MaxLevelFilter(stderr_level))
                _attach_context_filter(
                    stdout_handler,
                    static_fields=console_static_fields,
                )
                stdout_handler.setFormatter(console_formatter)
                main_logger.addHandler(stdout_handler)

                stderr_handler = logging.StreamHandler(sys.stderr)
                stderr_handler.setLevel(max(console_level, stderr_level))
                _attach_context_filter(
                    stderr_handler,
                    static_fields=console_static_fields,
                )
                stderr_handler.setFormatter(console_formatter)
                main_logger.addHandler(stderr_handler)

        if main_file_enabled:
            file_handler = RotatingFileHandler(
                filename=os.path.join(_config.logs_path, _config.log_file_name),
                maxBytes=_config.rotate_max_bytes,
                backupCount=_config.rotate_backup_count,
            )
            file_handler.setLevel(logging.DEBUG)
            _attach_context_filter(
                file_handler,
                static_fields=files_conf.get("static_fields", {}),
            )
            file_handler.setFormatter(file_formatter)
            main_logger.addHandler(file_handler)

        _main_logger = main_logger


def _ensure_configured() -> None:
    if _config is None or _main_logger is None:
        configure_logging()


def is_configured() -> bool:
    return _config is not None and _main_logger is not None


def get_logger(name: str, *, channel: str = "default") -> logging.Logger:
    """
    Return a logger configured according to the given channel.

    Channels are defined in LoggingConfig.channels. Example config:

        "channels": {
            "default": {"level": "INFO", "file_per_logger": False, "subdir": null},
            "service": {"level": "DEBUG", "file_per_logger": True, "subdir": "services"}
        }

    - `file_per_logger` creates a dedicated rotating file for each logger.
    - `subdir` (optional) places logs under logs_path/subdir.
    """
    _ensure_configured()
    assert _config is not None and _main_logger is not None

    with _lock:
        full_name = _normalize_logger_name(
            name,
            base_logger_name=_config.base_logger_name,
            channel=channel,
        )

        cached = _logger_cache.get(full_name)
        if cached is not None:
            return cached

        channel_conf = _config.channels.get(
            channel,
            _config.channels.get("default", {}),
        )
        level = _levelno(channel_conf.get("level", "INFO"))
        file_per_logger = bool(channel_conf.get("file_per_logger", False))
        subdir = channel_conf.get("subdir")

        logger = logging.getLogger(full_name)
        logger.setLevel(level)
        logger.propagate = True

        # important when reconfiguring during tests / startup reloads
        _close_and_remove_handlers(logger, handler_type=RotatingFileHandler)

        if file_per_logger:
            base_path = _config.logs_path
            if subdir:
                base_path = os.path.join(base_path, subdir)
            os.makedirs(base_path, exist_ok=True)

            stem_source = (
                full_name[len(_config.base_logger_name) + 1 :]
                if full_name.startswith(_config.base_logger_name + ".")
                else full_name
            )
            filename = os.path.join(
                base_path,
                f"{_safe_filename_component(stem_source)}.log",
            )

            fh = RotatingFileHandler(
                filename=filename,
                maxBytes=_config.rotate_max_bytes,
                backupCount=_config.rotate_backup_count,
            )
            fh.setLevel(logging.DEBUG)
            _attach_context_filter(
                fh,
                static_fields=(_config.files or {}).get("static_fields", {}),
            )
            fh.setFormatter(_build_formatter(_config.files or {}))
            logger.addHandler(fh)

        _logger_cache[full_name] = logger
        _managed_logger_names.add(full_name)
        return logger


def get_main_logger() -> Optional[logging.Logger]:
    return _main_logger
