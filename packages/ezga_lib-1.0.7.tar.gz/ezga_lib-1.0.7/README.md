# EZGA — Evolutionary Structure Exploration Framework

## Overview

EZGA is a modular, scalable, and chemically aware evolutionary framework for exploring and optimizing atomistic structures. It follows the **GitLab Enterprise Documentation Style**, emphasizing clarity, task‑orientation, operational guidance, and maintainability. This page serves as the primary landing document for new users and contributors.

EZGA enables configuration‑first evolutionary searches across molecular, cluster, crystalline, and surface systems. The engine integrates interchangeable components—initialization, features, objectives, selection, variation, convergence, and simulation—built around reproducible workflows and deterministic archival.

---

## Key capabilities

* **Configuration‑driven GA engine** for molecules and periodic crystals.
* **Advanced Bayesian Optimization**: Integrated BO with efficient warm-starting, model persistence, ARD kernels for anisotropic features, and visualization utilities.
* **Composable modules**: initialization, constraints, features, objectives, selection, variation, simulator, convergence.
* **Robust execution**: deterministic seeds, deduplication, integrity checks, scalable parallelism.
* **Physical‑model integration** with ASE/MACE or any Python‑callable evaluator.
* **Hierarchical Supercell Escalation (HiSE)** for periodic systems.
* **Task‑oriented workflows**: copy → modify → run.

---

## Why use EZGA

* Explore large compositional/structural spaces efficiently.
* Apply human‑readable constraints (e.g., `greater_than("Cu", 1)`).
* Start with datasets or DoE space‑filling seeds; escalate to larger supercells.
* Increase robustness using integrity checks that avoid unphysical trial structures.
* Scale seamlessly from a laptop to multi‑GPU clusters.

---

## Get started fast

### 1. Install (Python ≥ 3.10)

```bash
pip install ezga_lib
```

Optional GPU/ML potential dependencies (MACE/ASE, CUDA/ROCm) depend on your environment.
See **Simulator** in the Wiki.

### 2. Smoke test

```python
import ezga
print(getattr(ezga, "__version__", "unknown"))
```

### 3. Run your first job

Follow the minimal runnable script in **Quickstart**.

**Tip:** In GitLab Wiki, section anchors work like: `./Constraints#greater-than`.

---

## Documentation

Full documentation is available in the project's **GitLab Wiki**:

* **[Home](./-/wikis/home)**
* **[Installation](./-/wikis/Installation)**
* **[Quickstart](./-/wikis/Quickstart)**
* **[Recipes](./-/wikis/Recipes)**
* **[Configuration (GAConfig)](./-/wikis/Configuration)**

---

## Repository structure

```
src/ezga/
    core/                   # GA engine configuration & parameters
    simple/                 # Simplified API (minimize, GA class)
    generative/             # Generative models (Bayesian Optimization)
    selection/              # Parent selectors
    variation/              # Mutation & crossover operators
    hise/                   # Supercell escalation
    thermostat/             # Exploration–exploitation control
    DoE/                    # Design-of-Experiments initializer
    convergence/            # Termination logic
    simulator/              # MD, relaxations, MLIPs
    evaluator/              # Feature & objective metrics
    visualization/          # Plotting & analysis tools
    sync/                   # Island-model mailbox
    io/                     # State persistence (SQL/HDF5)
    cli/                    # Command-line interface
    utils/                  # Helper utilities (including bo_plotter)

docs/                       # Sphinx documentation
tests/                      # Regression tests
dist/                       # Build artifacts
examples/                   # Example workflows

```

---

## Usage

### YAML workflow

```bash
ezga run config.yaml
```

### Python API

```python
from ezga import Agent, load_config
config = load_config("config.yaml")
agent = Agent(config)
agent.run()
```

---

## Bayesian Optimization & Generative AI

EZGA includes a powerful, configuration-driven Bayesian Optimization (BO) module designed to accelerate discovery in expensive search spaces.

### Key Features
*   **Automatic Relevance Determination (ARD)**: Automatically upgrades to an anisotropic Matern kernel for multi-dimensional problems, learning independent length scales for each feature (`use_ard=True`).
*   **Robust Fitting**: Improved kernel bounds prevent model collapse and ensure meaningful uncertainty estimates.
*   **Model Persistence**: Save trained GP models for offline analysis or warm-starting future runs (`save_model=True`).
*   **Subsampling Control**: Efficiently handle large datasets by subsampling training data (`training_subsample=200`).
*   **Visualization**: Built-in utilities to plot 2D surrogate models and diagnostics (`ezga.utils.bo_plotter`).

### Example Usage

```python
from ezga.simple.algorithm import GA

# Configure GA with advanced BO settings
algorithm = GA(
    pop_size=100,
    enable_bo=True,
    warm_start=True,          # Reuse previous solution for faster fitting
    use_ard=True,             # Enable anisotropic kernel
    save_model=True,          # Save GP models to disk
    training_subsample=500    # Limit training data for speed
)
```

---

## Benchmarks

EZGA is validated on:

* Molecular conformational exploration (alanine dipeptide).
* Lennard–Jones cluster global search.
* Binary‑oxide convex‑hull reconstruction.
* Autonomous CuO/Cu₂O grand‑canonical phase diagram.

---

## Issues & Support

Use the GitLab **Issues** board to report problems, request enhancements, or ask questions:

* **[Report a bug](./-/issues/new?issue_type=bug)**
* **[Request a feature](./-/issues/new?issue_type=feature)**
* **[Ask for clarification](./-/issues)**
* **[Suggest documentation improvements](./-/issues)**

Issue templates (if configured) are available here:
**[Issue templates](./-/issues/templates)**

---

## Authors

* Juan Manuel Lombardi
* Felix Riccius
* Charles W. P. Paré
* Karsten Reuter
* Christoph Scheurer

