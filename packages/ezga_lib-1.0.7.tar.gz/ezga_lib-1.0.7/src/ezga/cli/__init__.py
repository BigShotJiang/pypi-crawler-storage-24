# SPDX-License-Identifier: MIT
from typer import Typer

app = Typer(
    help="EZGA – YAML-driven multi-objective GA",
    context_settings={"help_option_names": ["-h", "--help"]}
)

# Import the sub-APIs
from .run import app as run_app
from .resume import app as resume_app
from .wizard import app as wizard_app 

# Mount the sub-APIs as groups
app.add_typer(run_app, name="run")         # => ezga run ...
app.add_typer(resume_app, name="resume")   # => ezga resume ...
app.add_typer(wizard_app, name="wizard")   # => ezga wizard ...

# Mount commands
from .init_cmd import init_cli
app.command(name="init")(init_cli)

def main():
    app()
