"""Public API of EZGA – Evolutionary Structure Explorer.

Import the main high-level facade here:
    >>> from ezga import QuickGA

Or the core components if you need more control:
    >>> from ezga import GAConfig, load_config, build_default_engine
"""

try:
    from importlib.metadata import version
    __version__ = version("ezga-lib")
except Exception:  # pragma: no cover
    __version__ = "1.0.5"

__all__ = [
    "__version__",
    "QuickGA",
    "GAConfig",
    "GeneticAlgorithm",
    "load_config",
    "build_default_engine",
    "MultiTargetSymbolicRegressor",
]

def __getattr__(name):
    if name == "QuickGA":
        from .quick_ga import QuickGA
        return QuickGA
    if name == "MultiTargetSymbolicRegressor":
        from .simple.symbolic_regression import MultiTargetSymbolicRegressor
        return MultiTargetSymbolicRegressor
    if name == "GAConfig":
        from .core.config import GAConfig
        return GAConfig
    if name == "GeneticAlgorithm":
        from .core.engine import GeneticAlgorithm
        return GeneticAlgorithm
    if name == "load_config":
        from .factory import load_config
        return load_config
    if name == "build_default_engine":
        from .factory import build_default_engine
        return build_default_engine
    
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")