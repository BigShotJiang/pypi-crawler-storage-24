from http import HTTPMethod

import pytest

from zayt.web.routing.route import Route


async def handler():
    pass


@pytest.mark.parametrize(
    "path1, path2",
    [
        ("/b", "/a"),
        ("/a/{param}", "/a/b"),
        ("/a/{param}.d", "/b/c"),
        ("/a/d.{param}", "/b/c"),
        ("/a/{param}/c", "/a/{param}/b"),
    ],
    ids=[
        "no param",
        "single param",
        "param at start of segment",
        "param at end of segment",
        "middle param",
    ],
)
def test_route_sorting(path1, path2):
    routes = [
        Route(HTTPMethod.GET, path1, handler, "1"),
        Route(HTTPMethod.GET, path2, handler, "2"),
    ]

    routes.sort()

    assert [r.path for r in routes] == [path2, path1]
