from pathlib import Path

from zayt.conf.settings import Settings
from zayt.conf.defaults import default_settings
from zayt.web.application import Zayt


async def test_middleware_can_receive_dynamic_service_from_startup(monkeypatch):
    monkeypatch.syspath_prepend(Path(__file__).parent / "middleware_with_service")

    settings = Settings(
        default_settings
        | {
            "asgi_middleware": ["application.middleware_factory"],
        },
    )

    app = Zayt(settings)
    await app._lifespan_startup()
