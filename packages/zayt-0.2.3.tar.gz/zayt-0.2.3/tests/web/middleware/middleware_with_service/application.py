from zayt.di.container import Container
from zayt.web.lifecycle.decorator import startup


class Service:
    def __init__(self):
        self.test_passed = False


@startup
async def register_service(container: Container):
    container.register(Service)


def middleware_factory(app, service: Service):
    service.test_passed = True

    async def inner(scope, receive, send):
        pass

    return inner
