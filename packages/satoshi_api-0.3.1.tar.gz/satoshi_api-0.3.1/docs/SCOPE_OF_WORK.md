# Satoshi API -- Scope of Work

**Version:** 0.3.1
**Date:** 2026-03-07
**Author:** Andy Barnes
**Status:** Live -- https://bitcoinsapi.com

---

## 1. Project Overview

**Satoshi API** is a developer-friendly REST API that wraps a Bitcoin Core node with analyzed, structured data. It sits in a three-layer stack: **bitcoinlib-rpc** (Python RPC client) -> **Satoshi API** (REST layer) -> **bitcoin-mcp** (AI agent interface).

**Target users:** Developers building Bitcoin applications, AI agents querying blockchain data, hobbyist node operators wanting a clean API.

**Value proposition:** One `pip install`, instant REST API over your Bitcoin node. Analyzed data (fee recommendations, mempool congestion scores, block analysis) rather than raw RPC dumps.

---

## 2. Architecture

### 2.1 System Diagram

```
Internet
    |
Cloudflare (HTTPS, DDoS protection, IP hiding)
    |
cloudflared tunnel (localhost relay)
    |
Satoshi API (FastAPI, port 9332)
    |-- Auth middleware (API key via X-API-Key header)
    |-- Rate limiter (sliding window per-minute + daily DB-backed)
    |-- TTL cache (reorg-safe, per-cache locks)
    |-- Structured access logging
    |
Bitcoin Core RPC (port 8332, localhost only)
    |-- rpcwhitelist restricts to 16 safe commands
    |-- txindex=1 for full transaction lookups
```

### 2.2 Component Responsibilities

| Component | Responsibility | Design Pattern |
|-----------|---------------|----------------|
| `main.py` | App lifecycle, middleware stack, exception handlers | Middleware chain |
| `auth.py` | API key validation, tier resolution | Strategy (tier-based) |
| `rate_limit.py` | Per-minute sliding window + daily limits | Token bucket / sliding window |
| `cache.py` | TTL caching with reorg-safe depth awareness, `get_cached_node_info()` helper for non-RPC contexts | Cache-aside with lock-per-cache |
| `db.py` | SQLite (WAL mode), usage logging, key storage | Repository pattern |
| `config.py` | 12-factor env var config via Pydantic | Settings singleton |
| `dependencies.py` | Lazy singleton RPC connection | Dependency injection |
| `models.py` | Response envelope, typed data models | DTO / envelope pattern |
| `routers/` | 13 domain routers (address, blocks, tx, fees, mempool, mining, network, prices, status, keys, stream, exchanges, tools) | RESTful resource routing |

### 2.3 Design Principles Applied

- **Single Responsibility:** Each module owns one concern. Routers don't touch DB. Cache doesn't know about HTTP.
- **Dependency Inversion:** Routers depend on `get_rpc()` abstraction, not concrete RPC. Testable via DI override.
- **Open/Closed:** New endpoints = new router file. No modification of middleware needed.
- **12-Factor App:** Config from env vars, stateless processes, explicit dependencies, dev/prod parity.
- **Defense in Depth:** Auth -> rate limit -> input validation -> RPC whitelist -> localhost binding.

---

## 3. API Surface

### 3.1 Endpoints (42 total)

| Category | Endpoint | Method | Auth Required |
|----------|----------|--------|---------------|
| **Status** | `/api/v1/health` | GET | No |
| | `/api/v1/status` | GET | No |
| **Blocks** | `/api/v1/blocks/latest` | GET | No |
| | `/api/v1/blocks/tip/height` | GET | No |
| | `/api/v1/blocks/tip/hash` | GET | No |
| | `/api/v1/blocks/{height_or_hash}` | GET | No |
| | `/api/v1/blocks/{height}/stats` | GET | No |
| | `/api/v1/blocks/{hash}/txids` | GET | No |
| | `/api/v1/blocks/{hash}/txs` | GET | No |
| | `/api/v1/blocks/{hash}/header` | GET | No |
| **Transactions** | `/api/v1/tx/{txid}` | GET | No |
| | `/api/v1/tx/{txid}/raw` | GET | No |
| | `/api/v1/tx/{txid}/hex` | GET | No |
| | `/api/v1/tx/{txid}/status` | GET | No |
| | `/api/v1/tx/{txid}/outspends` | GET | No |
| | `/api/v1/utxo/{txid}/{vout}` | GET | No |
| | `/api/v1/decode` | POST | Yes (free+) |
| | `/api/v1/broadcast` | POST | Yes (free+) |
| **Fees** | `/api/v1/fees` | GET | No |
| | `/api/v1/fees/recommended` | GET | No |
| | `/api/v1/fees/mempool-blocks` | GET | No |
| | `/api/v1/fees/landscape` | GET | No |
| | `/api/v1/fees/estimate-tx` | GET | No |
| | `/api/v1/fees/history` | GET | No |
| | `/api/v1/fees/{target}` | GET | No |
| **Mempool** | `/api/v1/mempool` | GET | No |
| | `/api/v1/mempool/info` | GET | No |
| | `/api/v1/mempool/tx/{txid}` | GET | No |
| | `/api/v1/mempool/txids` | GET | No |
| | `/api/v1/mempool/recent` | GET | No |
| **Mining** | `/api/v1/mining` | GET | No |
| | `/api/v1/mining/nextblock` | GET | No |
| **Network** | `/api/v1/network` | GET | No (redacted) |
| | `/api/v1/network/forks` | GET | No |
| | `/api/v1/network/difficulty` | GET | No |
| | `/api/v1/network/validate-address/{addr}` | GET | No |
| **Prices** | `/api/v1/prices` | GET | No |
| **Address** | `/api/v1/address/{address}` | GET | No |
| | `/api/v1/address/{address}/utxos` | GET | No |
| **Streams** | `/api/v1/stream/blocks` | GET (SSE) | No |
| | `/api/v1/stream/fees` | GET (SSE) | No |
| **Tools** | `/api/v1/tools/exchange-compare` | GET | No |
| **Keys** | `/api/v1/register` | POST | No |

### 3.2 Endpoint Tiers

Endpoints are grouped into Core (always on) and Extended (toggleable via feature flags):

| Tier | Routers | Feature Flag |
|------|---------|-------------|
| **Core** | status, blocks, transactions, fees, mempool, mining, network, stream, keys | Always enabled |
| **Extended** | prices | `ENABLE_PRICES_ROUTER` (default: true) |
| **Extended** | address | `ENABLE_ADDRESS_ROUTER` (default: true) |
| **Extended** | exchanges | `ENABLE_EXCHANGE_COMPARE` (default: true) |

All flags default to `true` so tests pass unchanged and Swagger `/docs` shows everything. Production `.env` controls what's actually exposed.

### 3.3 Rate Limits

| Tier | Price | Rate Limit | Daily Limit | POST Access |
|------|-------|-----------|-------------|-------------|
| **Self-Hosted** | Free forever | Unlimited | Unlimited | Yes |
| **Hosted (anonymous)** | Free | 30/min | 1,000/day | No |
| **Hosted (API key)** | Free | 100/min | 10,000/day | Yes |
| **Pro** | $19/mo | 500/min | 100,000/day | Yes |

Landing page presents 2 tiers (Self-Hosted + Hosted). Pro is preserved but hidden until demand materializes.

### 3.4 Data Integrity Features

| Feature | Implementation | Details |
|---------|---------------|---------|
| **IBD/Sync Warning** | `Meta.syncing: bool` field | Auto-detected via `verificationprogress < 0.9999`. `X-Node-Syncing: true` header added to all responses when node is syncing. |
| **Stale Data Indicators** | `Meta.cached: bool`, `Meta.cache_age_seconds: int \| None` | Auto-populated from blockchain info cache state. Lets clients know data freshness. |
| **Broadcast Pre-Validation** | `decoderawtransaction` before `sendrawtransaction` | `/broadcast` catches malformed hex early. RPC error codes mapped to human-readable HTTP responses (see Section 4). |

### 3.5 Response Format

All responses use a standard envelope:

```json
{
  "data": { ... },
  "meta": {
    "timestamp": "2026-03-06T12:00:00+00:00",
    "request_id": "uuid",
    "node_height": 939462,
    "chain": "main",
    "syncing": false,
    "cached": true,
    "cache_age_seconds": 12
  }
}
```

Errors follow the same structure:

```json
{
  "error": {
    "status": 404,
    "title": "Not Found",
    "detail": "Transaction not found",
    "request_id": "uuid"
  }
}
```

---

## 4. Security Model

### 4.1 Implemented Controls

| Layer | Control | Implementation |
|-------|---------|----------------|
| **Transport** | HTTPS via Cloudflare Tunnel | TLS termination at edge, no home IP exposed |
| **Authentication** | API key (SHA256 hashed) | X-API-Key header, deprecated query param with sunset |
| **Authorization** | Tier-based access | Anonymous: read-only. Free+: POST endpoints |
| **Rate Limiting** | Per-minute + daily | Sliding window (memory) + DB-backed daily counts |
| **Input Validation** | Regex + Pydantic | 64-hex txid, non-negative heights, hex-only bodies |
| **Body Size** | 2MB limit | Pydantic `Field(max_length=2_000_000)` on hex inputs |
| **Node Protection** | RPC whitelist | Only 17 safe commands allowed via `rpcwhitelist` |
| **Network** | Localhost-only RPC | `rpcbind=127.0.0.1`, `rpcallowip=127.0.0.1` |
| **Broadcast Validation** | Decode-before-send | `decoderawtransaction` pre-check; RPC -25 → 409, -26 → 422, -27 → 409 |
| **Information Hiding** | Version redaction | Node version/subversion hidden from anonymous users |
| **Secrets** | SecretStr for RPC password | Pydantic SecretStr prevents accidental logging |
| **Access Logging** | Structured logs | IP, method, path, status, tier, request_id |
| **CORS** | Allowlist-based | Configured origins, not wildcard in production |
| **Security Headers** | Middleware-injected | CSP, X-Frame-Options DENY, HSTS, X-Content-Type-Options nosniff, Referrer-Policy, Permissions-Policy, X-XSS-Protection |
| **HSTS** | Conditional on HTTPS | `max-age=31536000; includeSubDomains` when behind TLS |
| **CSP** | Strict policy (skipped on docs) | `default-src 'self'`, allowlists for Cloudflare analytics, inline styles (landing page), GitHub images. Skipped on `/docs`, `/redoc`, `/openapi.json` so Swagger UI / ReDoc can load CDN assets. |
| **Clickjacking** | Frame denial | `X-Frame-Options: DENY` + CSP `frame-ancestors 'none'` |

### 4.2 Threat Model

| Threat | Mitigation | Residual Risk |
|--------|------------|---------------|
| DDoS | Cloudflare + rate limiting | Low -- Cloudflare absorbs L3/L4 |
| Broadcast spam | API key required for POST | Low -- free key = auditable |
| Node fingerprinting | Version redaction for anon | Low -- authenticated users see it |
| RPC command injection | Whitelist + parameterized calls | Very low |
| SQL injection | Parameterized SQLite queries | Very low |
| API key theft | SHA256 hashing, no plaintext storage, no keys in scripts | Medium -- rotate on compromise |
| Database leak | Keys are hashed, not reversible | Low |
| XSS via landing page | CSP blocks inline scripts (except landing page), nosniff header | Very low |
| Clickjacking | X-Frame-Options DENY + CSP frame-ancestors 'none' | Very low |
| Tab-napping via external links | All external links use `rel="noopener noreferrer"` | Very low |

---

## 5. Production Architecture Review

### 5.1 Grades by Principle

| Principle | Grade | Key Finding |
|-----------|-------|-------------|
| SOLID | B | Clean SRP, good DI. Rate limit strategies could use protocol abstraction. |
| Separation of Concerns | A- | Layers are clean. Minor: middleware does both auth + rate limit + logging. |
| Error Handling | B+ | Comprehensive handlers. Fixed: now logs exceptions server-side. |
| Security | A- | Defense in depth. Security headers (CSP, HSTS, X-Frame-Options). SecretStr for passwords. |
| Scalability | B | Thread-safe caching + rate limiting. SQLite is bottleneck at >1K req/s. |
| Observability | B- | Access logs + request IDs. Missing: Prometheus metrics. |
| Configuration | A- | 12-factor compliant. Sensible defaults. |
| Testing | A- | 118 unit tests + 21 e2e + load test + security script. |
| Dependencies | A- | Minimal, intentional. Could pin tighter. |
| API Design | A- | Versioned, enveloped, deprecation headers. No idempotency keys yet. |
| Data Integrity | B+ | WAL mode, parameterized queries, sync detection, stale data indicators, broadcast pre-validation. No schema migrations framework. |
| Deployment | B+ | Non-root Docker, health checks. Fixed: graceful shutdown. |

### 5.2 Critical Issues Fixed

**Sprint 6:**
1. **Exception swallowing** -- Middleware now logs full tracebacks via `logger.exception()`
2. **Secret leakage risk** -- RPC password changed to Pydantic `SecretStr`
3. **No graceful shutdown** -- Added 30s timeout to CLI and Dockerfile
4. **Unbounded memory** -- `_hash_to_height` dict replaced with `LRUCache(maxsize=256)`
5. **E2E test assertion bug** -- Fixed `"healthy"` -> `"ok"` to match actual status
6. **Missing `request.state.tier`** -- Middleware now sets tier for downstream handlers

**Sprint 7 (Architecture Review):**
7. **RPC singleton never recovers** -- Added `reset_rpc()` called on `ConnectionError` to allow reconnection
8. **POST 403 missing request_id** -- Changed from inline `JSONResponse` to `raise HTTPException`, uses standard error handler
9. **Prod healthcheck uses curl** -- Docker compose prod healthcheck now uses Python urllib (matches Dockerfile)
10. **Duplicate fee field** -- Removed `fee_sat`, kept `fee_sats` (Bitcoin convention)
11. **Rate limit header wrong epoch** -- Changed `time.monotonic()` to `time.time()` for correct unix timestamps
12. **Data leak via extra=allow** -- Changed to `extra="ignore"` on response models
13. **CORS wildcard warning** -- Log WARNING at startup if `*` in origins
14. **Block/mempool null fields** -- Fixed field name mapping: `fee_rate_median`→`median_fee_rate`, `total_fee_btc`→`total_fee`, `total_bytes`→`bytes`, `buckets`→`fee_buckets`
15. **Block hash cache miss** -- `cached_block_by_hash` now checks both `_block_cache` and `_recent_block_cache`
16. **E2E fee test no-op** -- Test checked for "high"/"medium"/"low" keys that don't exist; now validates actual integer-keyed estimates
17. **Dockerfile invalid flag** -- Removed `--limit-max-request-size` (not a valid uvicorn CLI/API param); body limits enforced by Pydantic model validation

**Post-launch (Mar 6):**
18. **Hardcoded API key in security_check.sh** -- Flagged by GitGuardian. Replaced with `$SATOSHI_API_KEY` env var. Exposed key deactivated, new key generated. Committed key is in git history but was for local use only (no third-party exposure).

**v0.3.1 Hardening (Mar 7):**
19. **No RPC timeout** -- Added configurable `RPC_TIMEOUT` (default 30s) via Settings, wired to BitcoinRPC constructor
20. **Address scan can hang** -- Wrapped `scantxoutset` in timeout guard, returns 504 on `ReadTimeout`
21. **No Cache-Control headers** -- Added middleware: fee/mempool→10s, deep blocks→1hr, health→no-cache, register→no-store
22. **404 returns HTML on API routes** -- `http_exception_handler` now returns JSON envelope for `/api/*` paths
23. **Registration not rate-limited** -- Removed `/api/v1/register` from rate limit skip set
24. **Raw mempool fetched repeatedly** -- Added `cached_raw_mempool` with 5s TTL for mempool/recent and fees/mempool-blocks

### 5.3 Known Limitations (Acceptable for v0.1)

| Limitation | Impact | When to Address |
|------------|--------|-----------------|
| SQLite write bottleneck | >1K req/s will see contention | v0.2 -- batch writes or PostgreSQL |
| No Prometheus metrics | Can't monitor cache hit rates, latency | v0.2 -- add `/metrics` endpoint |
| No idempotency keys | POST retries could double-broadcast | v0.2 -- add `Idempotency-Key` header |
| No schema migrations | Manual ALTER TABLE for DB changes | v0.2 -- add Alembic |
| Daily limit COUNT(*) | O(n) per request at scale | v0.2 -- cache count in memory |
| No webhook support | Clients must poll | v0.3 -- WebSocket/webhook subscriptions |

---

## 6. Deliverables

### 6.1 Completed (Sprints 1-6)

| Sprint | Deliverable | Tests |
|--------|-------------|-------|
| 1 | Core API: health, blocks, transactions, fees, mempool | 15 |
| 2 | Rate limiting (per-minute + daily), API key auth | 8 |
| 3 | Caching (TTL, reorg-safe), mining endpoints, network | 10 |
| 4 | Input validation, error unification, deprecation headers | 12 |
| 5 | Thread safety, usage logging, Docker, CI | 10 |
| 6 | Security hardening, production deployment, docs | 4 |
| 7 | Architecture review: 11 fixes (3 critical, 4 high, 4 medium) | 0 |
| 8 | v0.2 endpoints: mempool txids/recent, block txids/txs, tip height/hash, tx status, difficulty | 12 |
| 9 | L402 Lightning payments | Moved to separate extension package (bitcoin-api-l402) |
| 10 | Launch features: fee landscape, tx estimator, SSE streams, fee history | 9 |
| 11 | Security hardening (headers, CSP, HSTS), exchange compare tool, SEO comparison pages, robots.txt, sitemap.xml | 6 |
| 12 | Production hardening: RPC timeout, Cache-Control, 404 JSON, address timeout guard, cached raw mempool | 3 |
| 13 | Simplify for launch: feature flags for extended routers, 2-tier pricing presentation, README trim, Show HN draft | 0 |
| **Total** | **42 endpoints, 13 routers** | **118 unit + 21 e2e** |

### 6.2 Files Delivered

**Source (15 files):**
- `src/bitcoin_api/` -- main, auth, cache, config, db, dependencies, models, rate_limit
- `src/bitcoin_api/routers/` -- address, blocks, exchanges, fees, keys, mempool, mining, network, prices, status, stream, transactions

**Tests (3 files):**
- `tests/test_api.py` -- 118 unit tests
- `tests/test_e2e.py` -- 9 e2e tests (against live node)
- `tests/locustfile.py` -- Load test (8 weighted endpoints)

**Deployment (6 files):**
- `Dockerfile`, `docker-compose.yml`, `docker-compose.prod.yml`
- `.env.example`, `.env.production.example`
- `cloudflared-config.yml.example`

**Documentation (5 files):**
- `README.md`, `CHANGELOG.md`, `blog-post.md`
- `docs/self-hosting.md`, `docs/bitcoin-conf-example.conf`

**CI/CD (3 files):**
- `.github/workflows/ci.yml` -- Tests + lint on push
- `.github/workflows/publish.yml` -- PyPI publish on release
- `.github/workflows/pages.yml` -- GitHub Pages deployment for landing page

**Project config (1 file):**
- `CLAUDE.md` -- Project instructions for AI-assisted development

**Scripts (4 files):**
- `scripts/create_api_key.py`, `scripts/seed_db.py`
- `scripts/security_check.sh` (requires `SATOSHI_API_KEY` env var for POST tests)
- `scripts/staging-check.sh` (pre-deploy validation: starts staging server, checks CSP/headers/docs/endpoints)

**Website (10 files):**
- `static/index.html` -- Landing page with JSON-LD structured data, security headers, SEO meta tags
- `static/vs-mempool.html` -- SEO comparison page: Satoshi API vs mempool.space
- `static/vs-blockcypher.html` -- SEO comparison page: Satoshi API vs BlockCypher
- `static/best-bitcoin-api-for-developers.html` -- SEO decision page: developer guide
- `static/bitcoin-api-for-ai-agents.html` -- SEO decision page: AI/MCP angle
- `static/self-hosted-bitcoin-api.html` -- SEO decision page: self-hosting
- `static/bitcoin-fee-api.html` -- SEO feature page: fee estimation endpoints
- `static/bitcoin-mempool-api.html` -- SEO feature page: mempool analysis endpoints
- `static/robots.txt` -- Search engine crawl directives (welcomes AI crawlers)
- `static/sitemap.xml` -- XML sitemap for search engines (9 URLs)

---

## 7. Deployment Plan

### 7.1 Infrastructure

| Component | Provider | Cost |
|-----------|----------|------|
| Bitcoin Core node | Main PC (existing) | $0 |
| Satoshi API | Main PC Docker | $0 |
| Domain | Cloudflare Registrar | ~$10/yr |
| HTTPS + DDoS | Cloudflare Tunnel (free) | $0 |
| Monitoring | UptimeRobot (free tier) | $0 |

### 7.2 Deployment Steps

1. Buy domain, add to Cloudflare
2. Install `cloudflared`, create tunnel
3. Configure Bitcoin Core with `rpcwhitelist` (see `docs/bitcoin-conf-example.conf`)
4. `docker compose -f docker-compose.prod.yml up -d`
5. Configure `cloudflared` tunnel to `localhost:9332`
6. Set up UptimeRobot on `https://api.domain.dev/healthz`
7. Create initial API keys via `scripts/create_api_key.py`

### 7.3 Go-Live Checklist

- [x] All 118 unit tests pass
- [x] Security check script passes all 9 checks
- [x] E2E tests pass against live node
- [x] Load test: 50 users, 0 errors, p95 < 500ms (4ms median)
- [x] Quick tunnel HTTPS verified via Cloudflare
- [x] Permanent domain `bitcoinsapi.com` + named Cloudflare Tunnel `satoshi-api`
- [x] Anonymous POST /broadcast returns 403
- [x] Anonymous GET /network redacts version
- [x] UptimeRobot monitors /api/v1/health (5-min interval)
- [x] cloudflared Windows service auto-starts tunnel
- [x] SatoshiAPI scheduled task auto-starts API on logon
- [x] API key created for personal use
- [x] Bitcoin Core RPC whitelist configured (17 commands)

---

## 8. Product Strategy & Pricing

### 8.1 What We're Selling

Satoshi API serves three strategic purposes:

1. **Open source product** -- `pip install bitcoin-api` is the fastest path from a Bitcoin node to a REST API. Value = convenience + developer experience.
2. **Portfolio/credibility piece** -- Demonstrates Bitcoin protocol + Python + production engineering competence. Signals to Upwork clients, employers, and the Bitcoin dev community.
3. **Consulting funnel** -- "I built this, I can build custom Bitcoin tooling for you." Leads to paid work.

A hosted API is a secondary revenue opportunity, not the primary business.

### 8.2 Target Users

| User Segment | What They Need | Revenue Potential |
|-------------|---------------|-------------------|
| Node operators wanting a clean API | `pip install`, done | Free (self-host) |
| Wallet/app devs in prototype stage | Quick API, avoid running a node | $0-20/mo |
| AI agent builders (MCP users) | Bitcoin data for Claude/GPT | Free (use MCP layer) |
| Companies needing uptime + SLA | Hosted, dedicated, compliant | $50-500/mo |
| Upwork/freelance clients | Custom Bitcoin tooling | Hourly rate |

### 8.3 Pricing Model

| Tier | Price | Rate Limit | Daily Limit | POST Access | Target |
|------|-------|-----------|-------------|-------------|--------|
| **Self-Hosted** | Free forever | Unlimited | Unlimited | Yes | Node runners |
| **Anonymous (Hosted)** | Free | 30/min | 1,000/day | No | Try it, no signup |
| **Developer (Hosted)** | Free (with key) | 100/min | 10,000/day | Yes | Build & ship |
| **Pro** | $19/mo | 500/min | 100,000/day | Yes | Production apps |

**Launch strategy:** Free tiers at launch, Pro tier via Stripe when demand materializes. L402 Lightning payments available as optional extension (feature, not primary monetization). API keys are free — request via api@bitcoinsapi.com or self-serve `/api/v1/register` endpoint.

### 8.4 Infrastructure Cost

| Item | Monthly Cost |
|------|-------------|
| Electricity (marginal ~15-20W over always-on PC) | $2 |
| Domain (.dev) | $1 |
| Cloudflare Tunnel | $0 |
| Internet (already have) | $0 |
| **Total operating cost** | **~$3/month** |

One-time: 2TB SSD ~$150-200 (already have).

**Break-even:** 1 customer at $9/mo.

### 8.5 Competitive Landscape

| Competitor | Free Tier | Paid Entry | Self-Hostable | Differentiator |
|-----------|-----------|------------|---------------|----------------|
| mempool.space | Yes (undocumented limits) | Enterprise (call sales) | Yes (Docker) | De facto standard explorer |
| Blockstream Esplora | Yes (~50 rps) | N/A (free) | Yes | Most complete open-source REST API |
| BlockCypher | 1K req/day | $100/mo | No | Payment forwarding, multi-chain |
| GetBlock | 50K CU/day | $49/mo | No | 50+ chains |
| QuickNode | 10M credits | $49/mo | No | Best DX, 25+ chains |
| Alchemy | 30M CU | $5/mo PAYG | No | Dominant in EVM |
| **Satoshi API** | **Unlimited (self-host)** | **$0 (free hosted)** | **Yes** | **Analyzed data, MCP/AI-ready, pip install** |

**Our edge:** Nobody else offers analyzed Bitcoin data (fee recommendations, congestion scores, block analysis) + AI agent integration (MCP) + one-line install. We're not competing on hosted infrastructure -- we're competing on developer experience for the self-hosted niche.

### 8.6 Growth Opportunities (from ChatGPT analysis)

Highest-potential adjacencies if the product gains traction:
1. **Smart fee estimation API** -- probability-based confirmation estimates (largest market)
2. **Transaction monitoring** -- webhook-based tx/address watching (lowest difficulty)
3. **Mempool intelligence** -- real-time congestion maps, miner template prediction
4. **Ordinals API** -- inscription indexing, sat tracking (aligns with prior experience)

These would be v1.0+ features, not v0.1 scope.

---

## 9. Distribution Plan

### 9.1 Launch Channels

| Channel | Content | Priority |
|---------|---------|----------|
| Hacker News | "Show HN: Satoshi API -- REST API for your Bitcoin node" | Primary |
| dev.to | Full blog post (architecture deep dive) | High |
| r/BitcoinDev | Technical announcement | High |
| r/Bitcoin | Brief announcement | Medium |
| Nostr | Thread with examples | Medium |
| PyPI | `pip install bitcoin-api` | High |
| MCP directories | modelcontextprotocol/servers PR, Smithery, MCP Hub | Medium |

### 9.2 PyPI Publishing

```bash
# Build
python -m build

# Upload (or use GitHub Actions publish workflow on release)
twine upload dist/*
```

---

## 10. Future Roadmap

### v0.2 (Feature Parity — COMPLETE)
- Mempool: `/mempool/txids`, `/mempool/recent`
- Blocks: `/blocks/tip/height`, `/blocks/tip/hash`, `/blocks/{hash}/txids`, `/blocks/{hash}/txs`
- Transactions: `/tx/{txid}/status`
- Network: `/network/difficulty`
- RPC whitelist: added `getrawmempool`

### v0.3 (Launch Features — COMPLETE)
- `GET /fees/landscape` — "Should I send now?" decision engine with trend analysis
- `GET /fees/estimate-tx` — transaction size/fee estimator (pure math, no RPC)
- `GET /fees/history` — historical fee tracker (SQLite-backed, auto-pruning)
- `GET /stream/blocks` — SSE real-time block events
- `GET /stream/fees` — SSE fee rate updates every 30s
- Background fee collector (5-min snapshots for trend + history)

### v0.3.1 (Security Hardening — Next)
- CSP nonce-based script loading (remove `'unsafe-inline'` from script-src)
- Subresource Integrity (SRI) for any external scripts
- API key rotation endpoint (issue new key, deprecate old)
- SSE connection authentication (optional API key for stream endpoints)
- Rate limiting for SSE connections (connection count per tier)
- `Expect-CT` header for certificate transparency monitoring
- Security.txt (`/.well-known/security.txt`) with disclosure policy

### v0.4 (Medium Effort)
- Prometheus `/metrics` endpoint
- Idempotency key support for POST
- Alembic schema migrations
- Batch usage log writes

### L402 Lightning Payments (Extension Package)
- Separated into `bitcoin-api-l402` package for clean base product
- Layers on via `enable_l402(app, ...)` — no code in core API
- Includes: macaroon minting/verification, Lightning client (Alby Hub + mock), endpoint pricing, FastAPI middleware
- Repository: github.com/Bortlesboat/bitcoin-api-l402

### v0.5 (Address Lookups — PARTIAL)
- [x] `GET /address/{address}` — address balance and UTXO summary via `scantxoutset` (no Electrs needed)
- [x] `GET /address/{address}/utxos` — list UTXOs for address via `scantxoutset` (sorted by value, paginated)
- [ ] `GET /address/{addr}/txs` — address transaction history (requires Electrs/Fulcrum)
- [ ] PostgreSQL backend option

---

## 11. Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Bitcoin Core node goes down | Medium | API returns 502 | UptimeRobot alert, auto-restart via Docker |
| Home power/internet outage | Low | API offline | Cloudflare shows maintenance page |
| RPC password leaked | Low | Node compromise | SecretStr, env-only config, no git commits |
| Rate limit bypass | Low | Resource exhaustion | Cloudflare WAF + application rate limits |
| SQLite corruption | Very Low | API keys lost | WAL mode, periodic backups |
| Dependency vulnerability | Low | Supply chain risk | Minimal deps, pin versions, `pip audit` in CI |

---

*This document is the canonical scope of work for the Satoshi API project. Update it as the project evolves.*
