class DotDict(dict):
    """Dictionary that supports dot notation access."""
    __getattr__ = dict.get
    __setattr__ = dict.__setitem__
    __delattr__ = dict.__delitem__

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for k, v in self.items():
            if isinstance(v, dict):
                self[k] = DotDict(v)
            elif isinstance(v, list):
                self[k] =[DotDict(i) if isinstance(i, dict) else i for i in v]

class User(DotDict): pass
class Chat(DotDict): pass

class Message(DotDict):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if 'chat' in self and isinstance(self.chat, dict):
            self.chat = Chat(self.chat)
        if 'from' in self and isinstance(self['from'], dict):
            self.sender = User(self['from']) # Alias for 'from' since from is a reserved word
        else:
            self.sender = User()

class Update(DotDict):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if 'message' in self:
            self.message = Message(self.message)