import time
import requests
from .types import Message, Update

class Cache:
    """Smart TTL Cache to protect Cloudflare D1 Row Read Quotas."""
    def __init__(self):
        self._store = {}

    def get(self, key):
        if key in self._store:
            val, exp = self._store[key]
            if time.time() < exp:
                return val
            else:
                del self._store[key]
        return None

    def set(self, key, value, ttl=60):
        self._store[key] = (value, time.time() + ttl)

class YukiBot:
    def __init__(self, token: str, base_url: str = "https://yukichat.kviappsgames.workers.dev"):
        self.token = token
        self.base_url = base_url.rstrip('/')
        self.api_url = f"{self.base_url}/bot{self.token}"
        self.message_handlers =[]
        self.cache = Cache()
        self.last_update_id = 0

    def _request(self, method: str, payload: dict = None, cache_ttl: int = 0):
        """Internal API caller with optional caching for Read-Only methods."""
        # 1. Check Cache to save D1 Reads
        cache_key = f"{method}_{hash(frozenset(payload.items()))}" if payload else method
        if cache_ttl > 0:
            cached_result = self.cache.get(cache_key)
            if cached_result:
                return cached_result

        # 2. Make Network Request
        url = f"{self.api_url}/{method}"
        response = requests.post(url, json=payload or {})
        
        if response.status_code != 200:
            raise Exception(f"YukiChat API Error [{response.status_code}]: {response.text}")
        
        data = response.json()
        if not data.get('ok'):
            raise Exception(f"API Error: {data.get('description')}")
            
        result = data.get('result', True)

        # 3. Save to Cache if requested
        if cache_ttl > 0:
            self.cache.set(cache_key, result, cache_ttl)
            
        return result

    # ==========================================
    # DECORATORS & ROUTING (The "Telebot" Feel)
    # ==========================================
    
    def message_handler(self, commands=None, func=None, content_type='text'):
        def decorator(handler):
            self.message_handlers.append({
                'commands': commands or[],
                'func': func,
                'content_type': content_type,
                'handler': handler
            })
            return handler
        return decorator

    def process_new_updates(self, updates):
        for raw_update in updates:
            self.last_update_id = raw_update.get('update_id', self.last_update_id)
            
            # Normalize DB 'getUpdates' format into standard Webhook format
            if 'message' not in raw_update:
                raw_update['message'] = {
                    'message_id': raw_update.get('update_id'),
                    'chat': {'id': raw_update.get('chat_id')},
                    'from': {'id': raw_update.get('sender_id')},
                    'text': raw_update.get('content', ''),
                    'type': raw_update.get('type', 'text')
                }
            
            update = Update(raw_update)
            msg = update.message

            for h in self.message_handlers:
                # Type Check
                if h['content_type'] and msg.get('type', 'text') != h['content_type']:
                    continue
                # Command Check
                if h['commands'] and msg.text:
                    if not any(msg.text.startswith(f"/{cmd}") for cmd in h['commands']):
                        continue
                # Custom Function Check
                if h['func'] and not h['func'](msg):
                    continue
                
                # Execute Handler
                h['handler'](msg)
                break 

    def polling(self, interval=2):
        """Infinite loop to fetch messages without crashing."""
        print("YukiBot started polling...")
        while True:
            try:
                updates = self.getUpdates(offset=self.last_update_id)
                if updates:
                    self.process_new_updates(updates)
            except Exception as e:
                print(f"Polling error: {e}")
            time.sleep(interval)

    # ==========================================
    # API ENDPOINTS (All 37 Methods mapped)
    # ==========================================

    def reply_to(self, message: Message, text: str, reply_markup: dict = None):
        """Convenience method to reply directly to a message object."""
        return self.sendMessage(message.chat.id, text, reply_to_message_id=message.message_id, reply_markup=reply_markup)

    # --- MESSAGING ---
    def sendMessage(self, chat_id, text, reply_to_message_id=None, reply_markup=None):
        return self._request('sendMessage', {'chat_id': chat_id, 'text': text, 'reply_to_message_id': reply_to_message_id, 'reply_markup': reply_markup})

    def sendPhoto(self, chat_id, photo, caption=None, reply_to_message_id=None, reply_markup=None):
        return self._request('sendPhoto', {'chat_id': chat_id, 'photo': photo, 'caption': caption, 'reply_to_message_id': reply_to_message_id, 'reply_markup': reply_markup})

    def sendVideo(self, chat_id, video, caption=None, reply_to_message_id=None, reply_markup=None):
        return self._request('sendVideo', {'chat_id': chat_id, 'video': video, 'caption': caption, 'reply_to_message_id': reply_to_message_id, 'reply_markup': reply_markup})

    def sendDocument(self, chat_id, document, caption=None, reply_to_message_id=None, reply_markup=None):
        return self._request('sendDocument', {'chat_id': chat_id, 'document': document, 'caption': caption, 'reply_to_message_id': reply_to_message_id, 'reply_markup': reply_markup})

    def sendSticker(self, chat_id, sticker, reply_to_message_id=None, reply_markup=None):
        return self._request('sendSticker', {'chat_id': chat_id, 'sticker': sticker, 'reply_to_message_id': reply_to_message_id, 'reply_markup': reply_markup})

    def sendMediaGroup(self, chat_id, media: list):
        return self._request('sendMediaGroup', {'chat_id': chat_id, 'media': media})

    def forwardMessage(self, chat_id, from_chat_id, message_id):
        return self._request('forwardMessage', {'chat_id': chat_id, 'from_chat_id': from_chat_id, 'message_id': message_id})

    def editMessageText(self, message_id, text, reply_markup=None):
        return self._request('editMessageText', {'message_id': message_id, 'text': text, 'reply_markup': reply_markup})

    def editMessageReplyMarkup(self, message_id, reply_markup):
        return self._request('editMessageReplyMarkup', {'message_id': message_id, 'reply_markup': reply_markup})

    def deleteMessage(self, message_id):
        return self._request('deleteMessage', {'message_id': message_id})

    def sendChatAction(self, action):
        return self._request('sendChatAction', {'action': action})

    def pinChatMessage(self, chat_id, message_id):
        return self._request('pinChatMessage', {'chat_id': chat_id, 'message_id': message_id})

    def unpinChatMessage(self, chat_id, message_id):
        return self._request('unpinChatMessage', {'chat_id': chat_id, 'message_id': message_id})

    def answerCallbackQuery(self, callback_query_id):
        return self._request('answerCallbackQuery', {'callback_query_id': callback_query_id})

    def setWebhook(self, url):
        return self._request('setWebhook', {'url': url})

    def deleteWebhook(self):
        return self._request('deleteWebhook')

    def getWebhookInfo(self):
        return self._request('getWebhookInfo')

    # --- CHAT MANAGEMENT (Cached to save D1 Limits) ---
    def getChat(self, chat_id):
        return self._request('getChat', {'chat_id': chat_id}, cache_ttl=60)

    def getChatMembersCount(self, chat_id):
        return self._request('getChatMembersCount', {'chat_id': chat_id}, cache_ttl=60)

    def getChatMember(self, chat_id, user_id):
        return self._request('getChatMember', {'chat_id': chat_id, 'user_id': user_id}, cache_ttl=60)

    def banChatMember(self, chat_id, user_id):
        return self._request('banChatMember', {'chat_id': chat_id, 'user_id': user_id})

    def leaveChat(self, chat_id):
        return self._request('leaveChat', {'chat_id': chat_id})

    def promoteChatMember(self, chat_id, user_id, can_manage_chat=True):
        return self._request('promoteChatMember', {'chat_id': chat_id, 'user_id': user_id, 'can_manage_chat': can_manage_chat})

    def restrictChatMember(self, chat_id, user_id, can_send_messages=False):
        return self._request('restrictChatMember', {'chat_id': chat_id, 'user_id': user_id, 'permissions': {'can_send_messages': can_send_messages}})

    def setChatTitle(self, chat_id, title):
        return self._request('setChatTitle', {'chat_id': chat_id, 'title': title})

    def setChatDescription(self, chat_id, description):
        return self._request('setChatDescription', {'chat_id': chat_id, 'description': description})

    def setChatPhoto(self, chat_id, photo_url):
        return self._request('setChatPhoto', {'chat_id': chat_id, 'photo_url': photo_url})

    def exportChatInviteLink(self, chat_id):
        return self._request('exportChatInviteLink', {'chat_id': chat_id})

    # --- STICKERS ---
    def createNewStickerSet(self, name, title, png_sticker, emojis):
        return self._request('createNewStickerSet', {'name': name, 'title': title, 'png_sticker': png_sticker, 'emojis': emojis})

    def addStickerToSet(self, name, png_sticker, emojis):
        return self._request('addStickerToSet', {'name': name, 'png_sticker': png_sticker, 'emojis': emojis})

    def deleteStickerFromSet(self, sticker):
        return self._request('deleteStickerFromSet', {'sticker': sticker})

    def setStickerSetThumbnail(self, name, thumbnail):
        return self._request('setStickerSetThumbnail', {'name': name, 'thumbnail': thumbnail})

    def getStickerSet(self, name):
        return self._request('getStickerSet', {'name': name}, cache_ttl=120)

    # --- ADVANCED API ---
    def setMyCommands(self, commands: list, scope: dict = None):
        return self._request('setMyCommands', {'commands': commands, 'scope': scope})

    def setMessageReaction(self, message_id, reaction):
        return self._request('setMessageReaction', {'message_id': message_id, 'reaction': reaction})

    def sendSystemNotification(self, text):
        return self._request('sendSystemNotification', {'text': text})

    def getUpdates(self, offset=0):
        return self._request('getUpdates', {'offset': offset})