from setuptools import setup, find_packages

setup(
    name="yukibot",
    version="1.0.1",
    description="The official, simple, and D1-optimized Python framework for YukiChat Bots.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="YukiChat",
    author_email="kviappsgames@gmail.com",
    url="https://github.com/Vasiliy-katsyka/yukibot",
    packages=find_packages(),
    install_requires=[
        "requests>=2.25.1"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.7',
)