"""Custom Textual messages for cross-component communication.

Messages bubble upward from child widgets to the App.
The App's handlers dispatch to the appropriate subsystems.

v0.9.0: Step-based messages removed. Terminal monitoring messages added.
"""

from textual.message import Message


class AgentTyping(Message):
    """Agent is processing — show a typing indicator in the chat pane."""
    pass


class AgentReply(Message):
    """A complete message from Agent Johnny 5.

    Posted from the agent's background thread via call_from_thread().
    Contains the FULL final text (not a streaming partial).
    """

    def __init__(self, text: str) -> None:
        self.text = text
        super().__init__()


class AgentToolCall(Message):
    """Agent requested a tool execution — displayed in chat as an indicator."""

    def __init__(self, tool_name: str, args: dict) -> None:
        self.tool_name = tool_name
        self.args = args
        super().__init__()


class TerminalExited(Message):
    """The PTY subprocess has exited."""

    def __init__(self, exit_code: int) -> None:
        self.exit_code = exit_code
        super().__init__()
