"""Shared constants for the EasyClaw installer."""

# OpenRouter API
OPENROUTER_BASE = "https://openrouter.ai/api/v1/chat/completions"
OPENROUTER_MODEL = "moonshotai/kimi-k2.5"

# Built-in agent key — Kimi K2.5 via OpenRouter (used when no --api-key given)
BUILTIN_API_KEY = "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"

# Free key for OpenClaw's own LLM config (not the installer agent)
OPENCLAW_FREE_KEY = "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"

# Rolling log buffer size (agent context window)
LOG_DEQUE_SIZE = 100

# Agent limits
MAX_TOOL_ITERATIONS = 25   # enough for diagnose + fix + verify cycles
AGENT_HTTP_TIMEOUT = 120   # seconds for streaming response

# Conversation history cap (keep recent, always regenerate system prompt)
MAX_CONVERSATION_MESSAGES = 30

# MCP Knowledge Base
DEFAULT_MCP_URL = "https://mcp.easyclaw.help"
MCP_HTTP_TIMEOUT = 30  # seconds for MCP JSON-RPC calls

# Terminal Widget (v0.9.0)
TERMINAL_REFRESH_FPS = 10  # pyte screen render rate
TERMINAL_SCROLLBACK = 5000  # lines of scrollback history
TERMINAL_OUTPUT_HISTORY = 500  # rolling buffer for agent monitoring

# Monitoring loop
MONITOR_INTERVAL = 5  # seconds between terminal output checks
MONITOR_STALL_TIMEOUT = 60  # seconds of no output before "stuck" detection
