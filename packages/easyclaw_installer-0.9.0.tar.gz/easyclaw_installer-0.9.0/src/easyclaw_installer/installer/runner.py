"""StepRunner — REMOVED in v0.9.0.

The 16-step sequential installer has been replaced by a PTY monitor
architecture. The official OpenClaw installer runs in a real terminal
and Agent Johnny 5 monitors from the right pane.

This file is kept as a stub for import compatibility.
"""
