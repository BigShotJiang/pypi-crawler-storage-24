"""BaseStep ABC — REMOVED in v0.9.0.

The step-based installer has been replaced by a PTY monitor architecture.
This file is kept as a stub for import compatibility.
"""
