"""Step registry — REMOVED in v0.9.0.

The 16-step automated installer has been replaced by a PTY monitor
architecture. Step files are preserved for reference but no longer used.
"""

STEP_REGISTRY = []  # Empty — no steps in v0.9.0
