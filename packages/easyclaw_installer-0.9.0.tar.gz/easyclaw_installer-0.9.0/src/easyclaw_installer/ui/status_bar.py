"""Bottom status bar — shows focus mode, terminal status, and key hints."""

from textual.widgets import Static


class StatusBar(Static):
    """Two-line docked status bar spanning the full terminal width."""

    DEFAULT_CSS = """
    StatusBar {
        dock: bottom;
        height: 2;
        background: #1e1e2e;
        color: #e0e0e0;
        text-style: bold;
        content-align: left middle;
        padding: 0 2;
    }
    """

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self.can_focus = False
        self._focus_mode: str = "terminal"
        self._terminal_status: str = "Starting"

    def on_mount(self) -> None:
        self._refresh_display()

    def _refresh_display(self) -> None:
        """Refresh the status bar content."""
        focus_indicator = (
            "TERMINAL" if self._focus_mode == "terminal" else "CHAT"
        )
        line1 = (
            f" [Tab] Switch focus  |  "
            f"[Ctrl+\\\\] Quit  |  "
            f"Focus: {focus_indicator}  |  "
            f"Terminal: {self._terminal_status}"
        )
        line2 = (
            " Terminal: type into installer  |  "
            "Chat: talk to Johnny 5"
        )
        self.update(f"{line1}\n{line2}")

    def set_focus_mode(self, mode: str) -> None:
        """Update the displayed focus mode."""
        self._focus_mode = mode
        self._refresh_display()

    def set_terminal_status(self, status: str) -> None:
        """Update the terminal status label."""
        self._terminal_status = status
        self._refresh_display()
