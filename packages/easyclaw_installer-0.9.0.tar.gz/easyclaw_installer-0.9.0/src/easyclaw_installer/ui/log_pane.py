"""Left pane (60%) — interactive terminal emulator via TerminalWidget.

v0.9.0: Replaced RichLog with TerminalWidget. The PTY subprocess
(official OpenClaw installer) runs inside this widget. The user
can type directly into it when the terminal has focus.
"""

from textual.app import ComposeResult
from textual.widget import Widget

from .terminal_widget import TerminalWidget


class LogPane(Widget):
    """Wraps the TerminalWidget for the left pane of the split layout."""

    DEFAULT_CSS = """
    LogPane {
        height: 100%;
    }

    LogPane TerminalWidget {
        height: 100%;
    }
    """

    def compose(self) -> ComposeResult:
        yield TerminalWidget(id="terminal")
