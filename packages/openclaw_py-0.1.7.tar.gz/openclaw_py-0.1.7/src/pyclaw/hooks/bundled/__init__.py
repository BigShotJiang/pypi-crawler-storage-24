"""Bundled hook implementations."""
