"""Synology Chat channel plugin."""
