"""Nextcloud Talk channel plugin."""
