"""Mattermost channel plugin."""
