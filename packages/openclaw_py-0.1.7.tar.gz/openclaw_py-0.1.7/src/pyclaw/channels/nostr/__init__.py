"""Nostr channel plugin."""
