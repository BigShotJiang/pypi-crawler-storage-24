"""Zalo Bot channel plugin."""
