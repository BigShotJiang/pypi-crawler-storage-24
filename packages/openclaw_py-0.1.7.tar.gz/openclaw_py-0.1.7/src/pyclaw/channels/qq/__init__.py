"""QQ channel plugin."""
