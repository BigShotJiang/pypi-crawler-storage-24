class A:
	pass
