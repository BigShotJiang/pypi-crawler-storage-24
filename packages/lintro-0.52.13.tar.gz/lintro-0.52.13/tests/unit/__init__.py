"""Unit tests for lintro."""
