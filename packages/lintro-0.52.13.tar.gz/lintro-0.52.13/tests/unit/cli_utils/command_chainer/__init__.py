"""Tests for CommandChainer class."""
