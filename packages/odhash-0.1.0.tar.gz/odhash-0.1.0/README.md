# odhash

Turn any string or bytes into a short, memorable sequence of English words.

```python
import odhash

odhash.hash("hello")
# 'quarantine-cycle-knoll-meatloaf'

odhash.hash("hello", words=2)
# 'quarantine-cycle'
```

## Install

```
pip install odhash
```

## Usage

```python
odhash.hash(inp, algo=hashlib.sha256, words=4) -> str
```

- `inp` — a `str`, `bytes`, or an already-constructed `hashlib` hash object
- `algo` — any `hashlib`-compatible hash constructor (default: `sha256`)
- `words` — number of words in the output (default: 4)

Each word is selected from a curated list of 16,384 common English words using 2 bytes of the digest.

## License

MIT
