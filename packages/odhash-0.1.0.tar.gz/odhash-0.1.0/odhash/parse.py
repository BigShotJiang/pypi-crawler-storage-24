import re

TOKENS = re.compile(r"[a-z]+|[{}\[\],]")

def parse_wordlist(wordlist: str, expected=16384) -> list[str]:
    words = []
    stack = [""]
    pending = None

    wordlist = wordlist.replace("\n", "").replace(" ", "")

    for tok in TOKENS.findall(wordlist):
        match tok:
            case "{":
                stack.append(stack[-1] + pending)
                pending = None
            case "[":
                prefix = stack[-1] + pending
                words.append(prefix)
                stack.append(prefix)
                pending = None
            case ",":
                if pending is not None:
                    words.append(stack[-1] + pending)
                    pending = None
            case "}" | "]":
                if pending is not None:
                    words.append(stack[-1] + pending)
                    pending = None
                stack.pop()
            case _:
                if pending is not None:
                    words.append(stack[-1] + pending)
                pending = tok

    if pending is not None:
        words.append(stack[-1] + pending)

    if expected is not None and len(words) != expected:
        raise ValueError(f"expected {expected} words, got {len(words)}")
    
    return words


_WORDLIST = None

def get_wordlist():
    global _WORDLIST
    if _WORDLIST is None:
        from . import wordlist
        _WORDLIST = parse_wordlist(wordlist.WORDLIST)
    return _WORDLIST