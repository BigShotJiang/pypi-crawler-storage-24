import hashlib
import math
import struct
from typing import Protocol

from . import parse

class HashProto(Protocol):
    def digest(self) -> bytes: ...


def hash(inp: str | bytes | HashProto, algo=hashlib.sha256, words=4) -> str:
    if isinstance(inp, str):
        inp = inp.encode()
    if isinstance(inp, bytes):
        inp = algo(inp)
    digest = inp.digest()

    wordlist = parse.get_wordlist()
    n = len(wordlist)
    indices = struct.unpack_from(f">{words}H", digest)
    return "-".join(wordlist[i % n] for i in indices)


def estimate_bits(algo=hashlib.sha256, words=4) -> int:
    n = len(parse.get_wordlist())
    bits_per_word = int(math.log2(n))
    digest_bits = algo().digest_size * 8
    return min(words * bits_per_word, digest_bits)


def collision_rate(algo=hashlib.sha256, words=4, collision_chance: float = 0.5) -> int:
    space = 2 ** estimate_bits(algo, words)
    return int(math.sqrt(-2 * space * math.log(1 - collision_chance)))
