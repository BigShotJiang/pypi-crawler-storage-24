from .hasher import hash, estimate_bits, collision_rate
