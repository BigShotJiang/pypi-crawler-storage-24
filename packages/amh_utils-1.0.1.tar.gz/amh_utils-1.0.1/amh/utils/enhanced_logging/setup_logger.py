#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""  
@time   : 2026/3/12 15:02
@file   : setup_logger.py
@author : nbyue  
@desc   : 配置logging全局
"""

import logging
from logging.handlers import RotatingFileHandler
import os
import sys
from pathlib import Path

def setup_logging(verbose=False):
    """
    配置全局日志
    - 所有模块通过 getLogger(__name__) 继承配置
    - 使用 RotatingFileHandler 防止日志过大
    """
    # 确保日志目录存在
    log_dir = os.path.join(Path.cwd(), 'logs')
    log_file = os.path.join(log_dir, 'app.log')
    os.makedirs(log_dir, exist_ok=True)

    # 配置 root logger（所有子 logger 的父级）
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)

    # 防御性：避免重复添加 handler（重要！）
    if not root_logger.handlers:
        formatter = logging.Formatter(
            '%(asctime)s | %(name)s | %(levelname)-8s | %(module)s:%(lineno)d - %(message)s' if verbose
            else '%(asctime)s | %(levelname)-8s | %(message)s'
        )

        file_handler = RotatingFileHandler(
            log_file,
            maxBytes=5 * 1024 * 1024,  # 5MB
            backupCount=3,
            encoding='utf-8'
        )

        file_handler.setFormatter(formatter)
        root_logger.addHandler(file_handler)
        
        if verbose:
            console_handler = logging.StreamHandler(sys.stdout)
            console_handler.setFormatter(formatter)
            root_logger.addHandler(console_handler)


