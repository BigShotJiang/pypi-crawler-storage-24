from odoo import models, fields, api, _

class Case(models.Model):
    _name = 'case'
    _description = 'Case'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Name', compute='_compute_client_info', store=True)
    id_number = fields.Char(string='ID Number', compute='_compute_client_info', store=True)
    phone_number = fields.Char(string='Phone Number', compute='_compute_client_info', store=True)
    email_address = fields.Char(string='Email Address', compute='_compute_client_info', store=True)
    case_number = fields.Char(string='Case Number', required=True)
    auto_number = fields.Char(string='Auto Number')
    state = fields.Selection(
        selection=[
            ('open', _('Open')),
            ('closed', _('Closed')),
        ],
        string='Status',
        default='open',
        tracking=True,
    )
    closed_state = fields.Selection(
        selection=[
            ('resignation', _('The represented person resigns from representation')),
            ('withdrawn', _('Withdrawn')),
            ('settlement', _('Out-of-court settlement')),
            ('other', _('Other'))
        ],
        string='Closed status',
        default='resignation',
    )
    reason = fields.Char(string='Reason')
    verdict = fields.Selection(
        selection=[
            ('not_established', _('Not established')),
            ('won', _('Won')),
            ('in_process', _('In process')),
            ('lost', _('Lost'))
        ],
    )
    liable = fields.Many2one('res.users', required=True, string='Liable')
    demandant = fields.Many2many(
        'res.partner',
        'case_demandant_rel',
        'case_id',
        'partner_id',
        string='Demandant',
        required=True
    )
    defendant = fields.Many2many(
        'res.partner',
        'case_defendant_rel',
        'case_id',
        'partner_id',
        string='Defendant',
        required=True
    )
    client = fields.Selection(
        selection=[
            ('demandant', _('Demandant')),
            ('defendant', _('Defendant')),
        ],
    )
    case_type = fields.Many2many('case.type', string='Case type')
    jurisdiction = fields.Selection(
        selection=[
            ('labor', _('Labor')),
            ('litigation', _('Administrative Litigation')),
            ('social_security',_('Social security')),
            ('trade',_('Trade')),
            ('penal',_('Penal')),
        ],
    )
    image_1920 = fields.Image(string='Image', compute='_compute_client_info', max_width=1920, max_height=1920)
    next_activity = fields.Char(
        string="Next Activity",
        compute="_compute_next_activity"
    )

    next_activity_date = fields.Datetime(
        string="Next Activity Date",
        compute="_compute_next_activity"
    )


    @api.depends('client', 'demandant', 'defendant')
    def _compute_client_info(self):
        for rec in self:
            if rec.client == 'demandant' and rec.demandant:
                rec.name = rec.demandant[0].display_name
                rec.id_number = rec.demandant[0].vat
                rec.phone_number = rec.demandant[0].mobile
                rec.email_address = rec.demandant[0].email
                rec.image_1920 = rec.demandant[0].image_1920
            elif rec.client == 'defendant' and rec.defendant:
                rec.name = rec.defendant[0].display_name
                rec.id_number = rec.defendant[0].vat
                rec.phone_number = rec.defendant[0].mobile
                rec.email_address = rec.defendant[0].email
                rec.image_1920 = rec.defendant[0].image_1920
            else:
                rec.name = False


    @api.depends('activity_ids.date_deadline', 'activity_ids.summary', 'activity_ids.state')
    def _compute_next_activity(self):
        for case in self:
            pending_activities = case.activity_ids.filtered(lambda a: a.state == 'planned').sorted(key=lambda a: a.date_deadline)
            if pending_activities:
                case.next_activity = pending_activities[0].summary
                case.next_activity_date = pending_activities[0].date_deadline
            else:
                case.next_activity = False
                case.next_activity_date = False
