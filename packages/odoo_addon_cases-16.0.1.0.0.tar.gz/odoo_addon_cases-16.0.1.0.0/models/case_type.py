from odoo import models, fields, _


class CaseType(models.Model):
    _name = 'case.type'

    name = fields.Char('Name', required=True, translate=True)

    _sql_constraints = [
        ('name_uniq', 'unique (name)', _("Case type already exists!")),
    ]
