from odoo import models, fields

class Trial(models.Model):
    _name = 'trial'
    _description = 'Trial'

    name = fields.Char(string='Name', required=True)
    date_start = fields.Date(string='Start date', required=True)
