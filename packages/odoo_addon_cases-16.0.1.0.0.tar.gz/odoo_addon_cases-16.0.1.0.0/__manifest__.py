{
    "name": "Cases Management",
    "summary": """
        Custom Cases Management Module for ESK
    """,
    "description": """
        'Manage Cases with schedules, trials, conciliations, deadlines, and settings',
    """,
    "author": "Coopdevs",
    "website": "https://git.coopdevs.org/talaios/addons/cases#",
    "category": "Base",
    "version": "16.0.1.0.0",
    "depends": [
        "base",
        "mail",
    ],
    "data": [
        "security/ir.model.access.csv",
        "views/case_type_views.xml",
        "views/case_views.xml",
        "views/trial_views.xml",
        "views/schedule_views.xml",
        "views/menu_views.xml",
    ],
    "installable": True,
    "auto_install": False,
    "lisence": "LGPL-3"
}
