"""DriftGuard — Infrastructure Drift Detection & Self-Healing."""

__version__ = "0.1.0"
