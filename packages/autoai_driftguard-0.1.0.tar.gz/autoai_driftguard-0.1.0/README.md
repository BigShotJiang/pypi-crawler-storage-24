# DriftGuard

Infrastructure Drift Detection & Self-Healing for multi-cloud environments.

DriftGuard compares your Infrastructure-as-Code (Terraform, Pulumi, CloudFormation) desired state against live cloud resources to detect unauthorized changes, security misconfigurations, and cost anomalies.

## Features

- **Multi-cloud drift detection** — Azure, AWS, and GCP resource state readers
- **IaC state parsing** — Terraform (.tfstate v3/v4), Pulumi exports, CloudFormation templates
- **32 security rules** — Open ports, public storage, missing encryption, IAM wildcards, weak TLS, and more
- **8 cost rules** — Oversized instances, unattached volumes, missing tags, premium storage
- **8 compliance rules** — Data residency, encryption at rest, audit logging, retention periods
- **Drift classification** — Automated categorization as unauthorized/intentional/emergency
- **IaC remediation** — Auto-generate Terraform HCL or Pulumi Python to fix drift
- **GitHub PR generation** — Create PRs with remediation code
- **Historical tracking** — SQLite-backed drift history with trend analysis
- **Baseline management** — Accept known deviations with optional TTL
- **MCP server** — 7 tools for Claude/AI integration
- **CLI** — `scan`, `watch`, `fix`, `history`, `report`, `baseline`, `policy` commands

## Quick Start

```bash
pip install autoai-driftguard

# Scan a Terraform state file
driftguard scan --state terraform.tfstate --provider azure

# Continuous monitoring
driftguard watch --state terraform.tfstate --interval 300

# View drift history
driftguard history --severity critical

# Generate remediation code
driftguard fix --scan-id scan-abc123 --format terraform

# List security policies
driftguard policy list --category security

# Generate posture report
driftguard report --days 30
```

## Quick Start -- MCP Server

Add to your Claude Code or Cursor MCP config:

```json
{
  "mcpServers": {
    "driftguard": {
      "command": "uvx",
      "args": ["autoai-driftguard-mcp"],
      "description": "DriftGuard — Detect infrastructure drift across Azure, AWS, and GCP"
    }
  }
}
```

That's it. No signup. No API key. No data leaves your machine.

### Available Tools

| Tool | Description |
|------|-------------|
| `drift_scan` | Scan for drift across cloud providers |
| `drift_history` | View drift detection history |
| `drift_classify` | Classify drift as unauthorized/intentional/emergency |
| `drift_fix` | Generate IaC remediation code |
| `drift_policy` | Manage security/cost/compliance policies |
| `drift_baseline` | Manage accepted deviations |
| `drift_report` | Generate drift posture report |

## Cloud Provider Setup

### Azure
```bash
export ARM_CLIENT_ID="..."
export ARM_CLIENT_SECRET="..."
export ARM_TENANT_ID="..."
export ARM_SUBSCRIPTION_ID="..."
```

### AWS
```bash
export AWS_ACCESS_KEY_ID="..."
export AWS_SECRET_ACCESS_KEY="..."
export AWS_DEFAULT_REGION="us-east-1"
```

### GCP
```bash
export GOOGLE_APPLICATION_CREDENTIALS="/path/to/key.json"
export GOOGLE_CLOUD_PROJECT="my-project"
```

## Configuration

| Environment Variable | Description | Default |
|---------------------|-------------|---------|
| `DRIFTGUARD_DB` | SQLite database path | `driftguard.db` |
| `GITHUB_TOKEN` | GitHub token for PR creation | — |

## Development

```bash
git clone https://github.com/autoailabadmin/driftguard.git
cd driftguard
pip install -e ".[dev]"
pytest
```

## License

Apache 2.0 — see [LICENSE](LICENSE).

Built by [AutoAI Labs](https://autoailabs.co.uk).
