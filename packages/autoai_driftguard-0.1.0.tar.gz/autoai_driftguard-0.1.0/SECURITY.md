# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 0.1.x   | Yes                |

## Reporting a Vulnerability

If you discover a security vulnerability in DriftGuard, please report it responsibly:

1. **Do NOT** open a public GitHub issue
2. Email security@autoailabs.co.uk with:
   - Description of the vulnerability
   - Steps to reproduce
   - Potential impact assessment
3. You will receive acknowledgment within 48 hours
4. A fix will be prioritized based on severity (CVSS score)

## Security Design Principles

- **No credential storage**: DriftGuard never stores cloud credentials. It uses environment variables and existing credential chains (Azure CLI, AWS profiles, GCP ADC).
- **Read-only by default**: All scan operations are read-only. Write operations (remediation) require explicit `--apply` flag and confirmation.
- **Local-first data**: Drift history is stored in local SQLite. No telemetry or external data transmission.
- **Audit trail**: All remediation actions are logged with timestamps and user context.
- **Policy-as-code**: Security policies are declarative and version-controllable.
