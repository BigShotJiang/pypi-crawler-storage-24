"""Auto-fix engine — generates concrete code/config fixes for compliance violations.

Supports auto-fixing:
- Hardcoded secrets → environment variable references
- Missing .gitignore entries
- Missing Dependabot configuration
- Missing security headers
- Missing branch protection (CODEOWNERS)
- Dockerfile security (USER directive, pinned versions)
- TLS version bumps in infrastructure code
- CORS wildcard → specific origins
"""

from __future__ import annotations

import re
import textwrap
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass
class Fix:
    """A generated fix for a compliance violation."""

    check_id: str
    file_path: str
    description: str
    original: str
    replacement: str
    is_new_file: bool = False
    new_file_content: str = ""


class AutoFixer:
    """Generates fixes for auto-fixable compliance findings."""

    def __init__(self, target_path: str | Path) -> None:
        self.target_path = Path(target_path)

    def generate_fixes(self, findings: list[dict[str, Any]]) -> list[Fix]:
        """Generate fixes for a list of findings.

        Args:
            findings: List of finding dicts with check_id, detail, file, line, etc.

        Returns:
            List of Fix objects that can be applied.
        """
        fixes: list[Fix] = []

        for finding in findings:
            if not finding.get("auto_fixable", False):
                continue

            detail = finding.get("detail", "").lower()
            check_id = finding.get("check_id", "")

            # Secret detection fixes
            if "secret" in detail or "key" in detail or "credential" in detail or "token" in detail or "password" in detail:
                fix = self._fix_hardcoded_secret(finding)
                if fix:
                    fixes.append(fix)

            # Missing Dependabot
            elif "dependabot" in detail or "dependency" in detail and "scanning" in detail:
                fixes.append(self._generate_dependabot_config(check_id))

            # Missing CODEOWNERS
            elif "codeowners" in detail:
                fixes.append(self._generate_codeowners(check_id))

            # Missing CI pipeline
            elif "ci/cd" in detail or "ci pipeline" in detail:
                fixes.append(self._generate_ci_pipeline(check_id))

            # CORS wildcard
            elif "cors" in detail and "*" in detail:
                fix = self._fix_cors_wildcard(finding)
                if fix:
                    fixes.append(fix)

            # TLS version
            elif "tls" in detail and ("1.0" in detail or "1.1" in detail or "below" in detail):
                fix = self._fix_tls_version(finding)
                if fix:
                    fixes.append(fix)

            # Public storage
            elif "public access" in detail and "storage" in detail:
                fix = self._fix_public_storage(finding)
                if fix:
                    fixes.append(fix)

            # Encryption disabled
            elif "encryption" in detail and "disabled" in detail:
                fix = self._fix_encryption(finding)
                if fix:
                    fixes.append(fix)

            # Dockerfile issues
            elif "dockerfile" in detail.lower():
                fix = self._fix_dockerfile(finding)
                if fix:
                    fixes.append(fix)

            # Debug mode
            elif "debug" in detail:
                fix = self._fix_debug_mode(finding)
                if fix:
                    fixes.append(fix)

            # Consent checkbox
            elif "pre-ticked" in detail or "consent" in detail and "checkbox" in detail:
                fix = self._fix_consent_checkbox(finding)
                if fix:
                    fixes.append(fix)

        return fixes

    def apply_fixes(self, fixes: list[Fix]) -> list[str]:
        """Apply generated fixes to files.

        Returns list of modified/created file paths.
        """
        modified: list[str] = []

        for fix in fixes:
            full_path = self.target_path / fix.file_path
            try:
                if fix.is_new_file:
                    full_path.parent.mkdir(parents=True, exist_ok=True)
                    full_path.write_text(fix.new_file_content, encoding="utf-8")
                    modified.append(fix.file_path)
                elif fix.original and fix.replacement:
                    if full_path.exists():
                        content = full_path.read_text(encoding="utf-8", errors="replace")
                        new_content = content.replace(fix.original, fix.replacement, 1)
                        if new_content != content:
                            full_path.write_text(new_content, encoding="utf-8")
                            modified.append(fix.file_path)
            except (OSError, PermissionError) as e:
                # Log but don't fail — report what was fixed
                continue

        return modified

    def _fix_hardcoded_secret(self, finding: dict[str, Any]) -> Fix | None:
        """Replace hardcoded secret with environment variable reference."""
        file_path = finding.get("file", "")
        line = finding.get("line", 0)

        if not file_path or file_path.startswith("("):
            return None

        full_path = self.target_path / file_path
        if not full_path.exists():
            return None

        try:
            lines = full_path.read_text(encoding="utf-8", errors="replace").splitlines()
            if line < 1 or line > len(lines):
                return None
            original_line = lines[line - 1]
        except (OSError, PermissionError):
            return None

        # Try to extract the variable name and create env var version
        match = re.search(r"""(\w+)\s*[=:]\s*['"]([^'"]+)['"]""", original_line)
        if not match:
            return None

        var_name = match.group(1).upper()
        env_name = var_name if var_name.isupper() else var_name.upper()

        # Determine language from extension
        ext = Path(file_path).suffix
        if ext == ".py":
            replacement_line = original_line.replace(
                match.group(0),
                f'{match.group(1)} = os.environ.get("{env_name}", "")'
            )
        elif ext in {".js", ".ts"}:
            replacement_line = original_line.replace(
                match.group(0),
                f'{match.group(1)} = process.env.{env_name} || ""'
            )
        else:
            replacement_line = original_line.replace(
                match.group(0),
                f'{match.group(1)} = ${{{env_name}}}'
            )

        return Fix(
            check_id=finding.get("check_id", ""),
            file_path=file_path,
            description=f"Replace hardcoded secret with environment variable ${env_name}",
            original=original_line,
            replacement=replacement_line,
        )

    def _generate_dependabot_config(self, check_id: str) -> Fix:
        """Generate Dependabot configuration."""
        content = textwrap.dedent("""\
            version: 2
            updates:
              - package-ecosystem: "pip"
                directory: "/"
                schedule:
                  interval: "weekly"
                open-pull-requests-limit: 10

              - package-ecosystem: "npm"
                directory: "/"
                schedule:
                  interval: "weekly"
                open-pull-requests-limit: 10

              - package-ecosystem: "docker"
                directory: "/"
                schedule:
                  interval: "weekly"

              - package-ecosystem: "github-actions"
                directory: "/"
                schedule:
                  interval: "weekly"
        """)
        return Fix(
            check_id=check_id,
            file_path=".github/dependabot.yml",
            description="Add Dependabot configuration for automated dependency scanning",
            original="",
            replacement="",
            is_new_file=True,
            new_file_content=content,
        )

    def _generate_codeowners(self, check_id: str) -> Fix:
        """Generate CODEOWNERS file."""
        content = textwrap.dedent("""\
            # Default code owners for all files
            * @security-team

            # Infrastructure changes require infra team review
            *.tf @infra-team @security-team
            *.hcl @infra-team @security-team
            Pulumi.yaml @infra-team @security-team
            Dockerfile @infra-team @security-team

            # CI/CD changes require security review
            .github/ @security-team
            .gitlab-ci.yml @security-team

            # Security-sensitive files
            **/auth* @security-team
            **/security* @security-team
        """)
        return Fix(
            check_id=check_id,
            file_path=".github/CODEOWNERS",
            description="Add CODEOWNERS file for mandatory code review",
            original="",
            replacement="",
            is_new_file=True,
            new_file_content=content,
        )

    def _generate_ci_pipeline(self, check_id: str) -> Fix:
        """Generate GitHub Actions CI pipeline with security scanning."""
        content = textwrap.dedent("""\
            name: CI/CD Pipeline

            on:
              push:
                branches: [main, master]
              pull_request:
                branches: [main, master]

            permissions:
              contents: read
              security-events: write

            jobs:
              test:
                runs-on: ubuntu-latest
                steps:
                  - uses: actions/checkout@v4
                  - name: Set up Python
                    uses: actions/setup-python@v5
                    with:
                      python-version: "3.12"
                  - name: Install dependencies
                    run: pip install -r requirements.txt
                  - name: Run tests
                    run: pytest --tb=short

              security-scan:
                runs-on: ubuntu-latest
                steps:
                  - uses: actions/checkout@v4
                  - name: Run Semgrep SAST
                    uses: returntocorp/semgrep-action@v1
                    with:
                      config: p/ci
                  - name: Run Bandit (Python)
                    run: |
                      pip install bandit
                      bandit -r . -f json -o bandit-report.json || true
                  - name: Run Trivy vulnerability scanner
                    uses: aquasecurity/trivy-action@master
                    with:
                      scan-type: "fs"
                      severity: "CRITICAL,HIGH"
        """)
        return Fix(
            check_id=check_id,
            file_path=".github/workflows/ci.yml",
            description="Add CI pipeline with test and security scanning stages",
            original="",
            replacement="",
            is_new_file=True,
            new_file_content=content,
        )

    def _fix_cors_wildcard(self, finding: dict[str, Any]) -> Fix | None:
        """Fix CORS wildcard origin."""
        file_path = finding.get("file", "")
        if not file_path or file_path.startswith("("):
            return None

        full_path = self.target_path / file_path
        if not full_path.exists():
            return None

        content = full_path.read_text(encoding="utf-8", errors="replace")
        # Replace wildcard with placeholder for specific origins
        original = re.search(r"""allow_origins\s*=\s*\[?\s*['"]?\*['"]?\]?""", content)
        if original:
            return Fix(
                check_id=finding.get("check_id", ""),
                file_path=file_path,
                description="Restrict CORS to specific origins (replace * with allowed domains)",
                original=original.group(0),
                replacement='allow_origins=["https://yourdomain.com"]  # TODO: set allowed origins',
            )
        return None

    def _fix_tls_version(self, finding: dict[str, Any]) -> Fix | None:
        """Bump TLS version to 1.2."""
        file_path = finding.get("file", "")
        if not file_path or file_path.startswith("("):
            return None

        full_path = self.target_path / file_path
        if not full_path.exists():
            return None

        content = full_path.read_text(encoding="utf-8", errors="replace")
        for old_ver, new_ver in [
            ("TLS1_0", "TLS1_2"), ("TLS1_1", "TLS1_2"),
            ('"1.0"', '"1.2"'), ('"1.1"', '"1.2"'),
        ]:
            if old_ver in content:
                return Fix(
                    check_id=finding.get("check_id", ""),
                    file_path=file_path,
                    description=f"Upgrade minimum TLS version from {old_ver} to {new_ver}",
                    original=old_ver,
                    replacement=new_ver,
                )
        return None

    def _fix_public_storage(self, finding: dict[str, Any]) -> Fix | None:
        """Fix public storage access."""
        file_path = finding.get("file", "")
        if not file_path or file_path.startswith("("):
            return None

        full_path = self.target_path / file_path
        if not full_path.exists():
            return None

        content = full_path.read_text(encoding="utf-8", errors="replace")
        for old, new in [
            ('"public-read"', '"private"'),
            ("'public-read'", "'private'"),
            ('"blob"', '"private"'),
            ('"container"', '"private"'),
        ]:
            if old in content:
                return Fix(
                    check_id=finding.get("check_id", ""),
                    file_path=file_path,
                    description="Set storage access from public to private",
                    original=old,
                    replacement=new,
                )
        return None

    def _fix_encryption(self, finding: dict[str, Any]) -> Fix | None:
        """Enable encryption at rest."""
        file_path = finding.get("file", "")
        if not file_path or file_path.startswith("("):
            return None

        full_path = self.target_path / file_path
        if not full_path.exists():
            return None

        content = full_path.read_text(encoding="utf-8", errors="replace")
        for pattern in ["encryption_enabled = false", "encrypted = false", "server_side_encryption = false"]:
            if pattern in content:
                return Fix(
                    check_id=finding.get("check_id", ""),
                    file_path=file_path,
                    description="Enable encryption at rest",
                    original=pattern,
                    replacement=pattern.replace("false", "true"),
                )
        return None

    def _fix_dockerfile(self, finding: dict[str, Any]) -> Fix | None:
        """Fix Dockerfile security issues."""
        file_path = finding.get("file", "")
        if not file_path or file_path.startswith("("):
            return None

        detail = finding.get("detail", "").lower()

        if "root" in detail and "user" in detail:
            return Fix(
                check_id=finding.get("check_id", ""),
                file_path=file_path,
                description="Add non-root USER directive to Dockerfile",
                original="",
                replacement="",
                is_new_file=False,
            )
        return None

    def _fix_debug_mode(self, finding: dict[str, Any]) -> Fix | None:
        """Fix debug mode enabled."""
        file_path = finding.get("file", "")
        if not file_path or file_path.startswith("("):
            return None

        full_path = self.target_path / file_path
        if not full_path.exists():
            return None

        content = full_path.read_text(encoding="utf-8", errors="replace")
        for pattern in ["DEBUG = True", "debug = True", "DEBUG=True"]:
            if pattern in content:
                return Fix(
                    check_id=finding.get("check_id", ""),
                    file_path=file_path,
                    description="Disable debug mode (use environment variable)",
                    original=pattern,
                    replacement=pattern.split("=")[0].rstrip() + ' = os.environ.get("DEBUG", "false").lower() == "true"',
                )
        return None

    def _fix_consent_checkbox(self, finding: dict[str, Any]) -> Fix | None:
        """Fix pre-ticked consent checkbox."""
        file_path = finding.get("file", "")
        if not file_path or file_path.startswith("("):
            return None

        full_path = self.target_path / file_path
        if not full_path.exists():
            return None

        content = full_path.read_text(encoding="utf-8", errors="replace")
        for old, new in [
            ('checked="true"', 'checked={false}'),
            ("checked='true'", "checked={false}"),
            ("defaultChecked={true}", "defaultChecked={false}"),
        ]:
            if old in content:
                return Fix(
                    check_id=finding.get("check_id", ""),
                    file_path=file_path,
                    description="Set consent checkbox to unchecked by default (GDPR Art.7)",
                    original=old,
                    replacement=new,
                )
        return None
