"""ComplianceOS CLI — scan, fix, and report on compliance from the command line.

Usage:
    complianceos scan <path> --framework soc2
    complianceos status --framework soc2
    complianceos fix <path> --framework soc2 [--apply] [--create-pr]
    complianceos evidence <path> --framework soc2
    complianceos report --framework soc2 [--format json]
    complianceos map
    complianceos serve   # Start MCP server
"""

from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

import click

from .frameworks import FRAMEWORKS, FRAMEWORK_NAMES, get_control_overlap
from .store import ComplianceStore


FRAMEWORK_CHOICES = list(FRAMEWORKS.keys())


def _get_store(db: str | None = None) -> ComplianceStore:
    return ComplianceStore(db)


@click.group()
@click.version_option(version="0.1.0", prog_name="ComplianceOS")
def main() -> None:
    """ComplianceOS -- Real Compliance Automation.

    Scans codebases and infrastructure, auto-remediates violations,
    and generates audit-ready evidence packages.
    """
    pass


@main.command()
@click.argument("target", type=click.Path(exists=True))
@click.option("--framework", "-f", type=click.Choice(FRAMEWORK_CHOICES), required=True,
              help="Compliance framework to scan against")
@click.option("--db", default=None, help="Custom database path")
@click.option("--json-output", is_flag=True, help="Output raw JSON")
def scan(target: str, framework: str, db: str | None, json_output: bool) -> None:
    """Scan a codebase against a compliance framework."""
    from .server import _run_scan

    store = _get_store(db)
    try:
        result = _run_scan(target, framework, store)

        if "error" in result:
            click.secho(f"Error: {result['error']}", fg="red")
            sys.exit(1)

        if json_output:
            click.echo(json.dumps(result, indent=2))
            return

        # Pretty print
        fw_name = FRAMEWORK_NAMES.get(framework, framework)
        score = result.get("score", 0)
        color = "green" if score >= 80 else "yellow" if score >= 60 else "red"

        click.echo()
        click.secho(f"  {fw_name} Compliance Scan", fg="blue", bold=True)
        click.echo(f"  Target: {result.get('target', '')}")
        click.echo(f"  Scan ID: {result.get('scan_id', '')}")
        click.echo()
        click.secho(f"  Score: {score:.1f}%", fg=color, bold=True)
        click.echo(f"  Controls: {result.get('passed', 0)} passed / {result.get('failed', 0)} failed / {result.get('total_controls', 0)} total")
        click.echo()

        findings = result.get("findings", [])
        open_findings = [f for f in findings if f.get("status") == "open"]

        if open_findings:
            # Group by severity
            by_sev: dict[str, list] = {}
            for f in open_findings:
                sev = f.get("severity", "info")
                by_sev.setdefault(sev, []).append(f)

            sev_colors = {"critical": "red", "high": "red", "medium": "yellow", "low": "cyan", "info": "white"}

            for sev in ["critical", "high", "medium", "low", "info"]:
                items = by_sev.get(sev, [])
                if not items:
                    continue
                click.secho(f"  [{sev.upper()}] ({len(items)} findings)", fg=sev_colors.get(sev, "white"), bold=True)
                for f in items:
                    fix_tag = " [auto-fix]" if f.get("auto_fixable") else ""
                    click.echo(f"    - [{f.get('check_id', '')}] {f.get('detail', '')}{fix_tag}")
                click.echo()

            fixable = [f for f in open_findings if f.get("auto_fixable")]
            if fixable:
                click.secho(f"  {len(fixable)} findings can be auto-fixed. Run:", fg="green")
                click.echo(f"    complianceos fix {target} -f {framework} --apply")
        else:
            click.secho("  No findings -- all clear!", fg="green", bold=True)

        click.echo()
    finally:
        store.close()


@main.command()
@click.option("--framework", "-f", type=click.Choice(FRAMEWORK_CHOICES), required=True)
@click.option("--db", default=None)
def status(framework: str, db: str | None) -> None:
    """Show current compliance posture for a framework."""
    store = _get_store(db)
    try:
        scan_data = store.get_latest_scan(framework)
        if not scan_data:
            click.secho(f"No scan results for {FRAMEWORK_NAMES.get(framework, framework)}.", fg="yellow")
            click.echo(f"Run: complianceos scan <path> -f {framework}")
            return

        fw_name = FRAMEWORK_NAMES.get(framework, framework)
        score = scan_data.get("score", 0)
        color = "green" if score >= 80 else "yellow" if score >= 60 else "red"

        open_findings = store.get_open_findings(framework)

        click.echo()
        click.secho(f"  {fw_name} Status", fg="blue", bold=True)
        click.echo(f"  Last scan: {scan_data.get('timestamp', '')[:19]}")
        click.secho(f"  Score: {score:.1f}%", fg=color, bold=True)
        click.echo(f"  Passed: {scan_data.get('passed', 0)} / {scan_data.get('total_controls', 0)}")
        click.echo()

        if open_findings:
            critical = len([f for f in open_findings if f["severity"] == "critical"])
            high = len([f for f in open_findings if f["severity"] == "high"])
            medium = len([f for f in open_findings if f["severity"] == "medium"])
            low = len([f for f in open_findings if f["severity"] == "low"])

            click.echo(f"  Open findings:")
            if critical:
                click.secho(f"    Critical: {critical}", fg="red")
            if high:
                click.secho(f"    High:     {high}", fg="red")
            if medium:
                click.secho(f"    Medium:   {medium}", fg="yellow")
            if low:
                click.secho(f"    Low:      {low}", fg="cyan")

            fixable = len([f for f in open_findings if f.get("auto_fixable")])
            if fixable:
                click.echo(f"\n  Auto-fixable: {fixable}")
        click.echo()
    finally:
        store.close()


@main.command()
@click.argument("target", type=click.Path(exists=True))
@click.option("--framework", "-f", type=click.Choice(FRAMEWORK_CHOICES), required=True)
@click.option("--apply", is_flag=True, help="Apply fixes (otherwise preview only)")
@click.option("--create-pr", is_flag=True, help="Create GitHub PR with fixes")
@click.option("--db", default=None)
def fix(target: str, framework: str, apply: bool, create_pr: bool, db: str | None) -> None:
    """Auto-fix compliance violations."""
    from .server import _run_scan
    from .remediation.auto_fix import AutoFixer
    from .remediation.pr_generator import PRGenerator

    store = _get_store(db)
    try:
        click.echo(f"\n  Scanning {target} against {FRAMEWORK_NAMES.get(framework, framework)}...")
        result = _run_scan(target, framework, store)

        if "error" in result:
            click.secho(f"  Error: {result['error']}", fg="red")
            sys.exit(1)

        findings = result.get("findings", [])
        fixable = [f for f in findings if f.get("auto_fixable") and f.get("status") == "open"]

        if not fixable:
            click.secho("  No auto-fixable findings.", fg="green")
            return

        fixer = AutoFixer(Path(target).resolve())
        fixes = fixer.generate_fixes(fixable)

        if not fixes:
            click.secho("  No fixes could be generated.", fg="yellow")
            return

        click.secho(f"\n  {len(fixes)} fixes generated:", fg="blue", bold=True)
        for f in fixes:
            icon = "+" if f.is_new_file else "~"
            click.echo(f"    [{icon}] {f.file_path}: {f.description}")

        if apply:
            click.echo()
            modified = fixer.apply_fixes(fixes)
            click.secho(f"  Applied {len(modified)} fixes:", fg="green", bold=True)
            for m in modified:
                click.echo(f"    {m}")

            if create_pr:
                remaining = [f for f in findings if not f.get("auto_fixable")]
                pr_gen = PRGenerator(Path(target).resolve())
                pr_details = pr_gen.generate_pr_details(
                    framework, fixes, remaining, result.get("score", 0)
                )
                pr_url = pr_gen.create_pr(pr_details)
                if pr_url:
                    click.secho(f"\n  PR created: {pr_url}", fg="green")
                else:
                    click.secho("\n  Failed to create PR (check gh CLI auth)", fg="yellow")
        else:
            click.echo(f"\n  Preview only. Run with --apply to apply fixes.")

        click.echo()
    finally:
        store.close()


@main.command()
@click.argument("target", type=click.Path(exists=True))
@click.option("--framework", "-f", type=click.Choice(FRAMEWORK_CHOICES), required=True)
@click.option("--db", default=None)
def evidence(target: str, framework: str, db: str | None) -> None:
    """Collect compliance evidence from the project."""
    from .evidence.collector import EvidenceCollector

    store = _get_store(db)
    try:
        collector = EvidenceCollector(Path(target).resolve(), store)
        items = collector.collect_all(framework)

        fw_name = FRAMEWORK_NAMES.get(framework, framework)
        click.echo()
        click.secho(f"  {fw_name} Evidence Collection", fg="blue", bold=True)
        click.secho(f"  Collected {len(items)} evidence items:", fg="green")

        by_type: dict[str, int] = {}
        for item in items:
            by_type[item.evidence_type] = by_type.get(item.evidence_type, 0) + 1

        for etype, count in sorted(by_type.items()):
            click.echo(f"    {etype}: {count}")

        click.echo(f"\n  Evidence stored in database.")
        click.echo(f"  Generate report: complianceos report -f {framework}")
        click.echo()
    finally:
        store.close()


@main.command()
@click.option("--framework", "-f", type=click.Choice(FRAMEWORK_CHOICES), required=True)
@click.option("--format", "fmt", type=click.Choice(["markdown", "json"]), default="markdown")
@click.option("--output", "-o", default=None, help="Output file path")
@click.option("--db", default=None)
def report(framework: str, fmt: str, output: str | None, db: str | None) -> None:
    """Generate an audit-ready compliance report."""
    from .evidence.report import ReportGenerator

    store = _get_store(db)
    try:
        reporter = ReportGenerator(store)
        report_text = reporter.generate_report(framework, output_format=fmt)

        if output:
            Path(output).write_text(report_text, encoding="utf-8")
            click.secho(f"  Report saved to {output}", fg="green")
        else:
            click.echo(report_text)
    finally:
        store.close()


@main.command("map")
def control_map() -> None:
    """Show control overlap across compliance frameworks."""
    overlap = get_control_overlap()

    click.echo()
    click.secho("  Control Overlap Across Frameworks", fg="blue", bold=True)
    click.echo()

    for topic, controls in overlap.items():
        click.secho(f"  {topic}", fg="white", bold=True)
        for ctrl in controls:
            fw = ctrl["framework"]
            fw_name = FRAMEWORK_NAMES.get(fw, fw)[:15]
            click.echo(f"    {fw_name:16s}  {ctrl['control']}: {ctrl['check']}")
        click.echo()


@main.command()
@click.option("--db", default=None)
def serve(db: str | None) -> None:
    """Start the ComplianceOS MCP server (stdio)."""
    from .server import main as server_main
    asyncio.run(server_main())


if __name__ == "__main__":
    main()
