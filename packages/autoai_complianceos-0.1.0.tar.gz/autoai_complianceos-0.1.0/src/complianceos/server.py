"""ComplianceOS MCP Server — exposes compliance tools via Model Context Protocol.

Tools:
- compliance_scan: Scan codebase/infra against a framework
- compliance_status: Current compliance posture by framework
- compliance_fix: Auto-generate and apply fixes for violations
- compliance_evidence: Collect and package evidence for auditors
- compliance_report: Generate audit-ready compliance report
- compliance_map: Show control overlap across frameworks
"""

from __future__ import annotations

import datetime
import json
import uuid
from pathlib import Path
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

from .frameworks import FRAMEWORKS, FRAMEWORK_NAMES, get_all_checks, get_control_overlap
from .scanners import SCANNERS
from .store import ComplianceStore, Finding, ScanResult, Severity, FindingStatus
from .remediation.auto_fix import AutoFixer
from .remediation.pr_generator import PRGenerator
from .evidence.collector import EvidenceCollector
from .evidence.report import ReportGenerator


def _run_scan(target: str, framework: str, store: ComplianceStore) -> dict[str, Any]:
    """Core scan logic shared by MCP tool and CLI."""
    target_path = Path(target).resolve()
    if not target_path.exists():
        return {"error": f"Target path does not exist: {target}"}

    if framework not in FRAMEWORKS:
        return {"error": f"Unknown framework: {framework}. Available: {', '.join(FRAMEWORKS.keys())}"}

    checks = get_all_checks(framework)
    scan_id = f"scan-{uuid.uuid4().hex[:12]}"
    timestamp = datetime.datetime.utcnow().isoformat()

    all_findings: list[Finding] = []
    checks_by_scanner: dict[str, list[dict[str, Any]]] = {}

    for check in checks:
        scanner_type = check.get("scanner", "config")
        checks_by_scanner.setdefault(scanner_type, []).append(check)

    for scanner_type, scanner_checks in checks_by_scanner.items():
        scanner_cls = SCANNERS.get(scanner_type)
        if not scanner_cls:
            continue

        scanner = scanner_cls(target_path)
        raw_findings = scanner.scan(scanner_checks)

        for rf in raw_findings:
            # Find the matching check to get control info
            matched_check = None
            for c in scanner_checks:
                if c.get("id") == rf.check_id:
                    matched_check = c
                    break

            if not matched_check:
                # Use check_id to find it across all checks
                for c in checks:
                    if c.get("id") == rf.check_id:
                        matched_check = c
                        break

            control_id = matched_check.get("control_id", "") if matched_check else ""
            check_desc = matched_check.get("check", rf.detail) if matched_check else rf.detail

            all_findings.append(Finding(
                control_id=control_id,
                framework=framework,
                check_id=rf.check_id,
                check_description=check_desc,
                severity=Severity(rf.severity),
                status=FindingStatus.OPEN,
                resource=rf.file,
                detail=rf.detail,
                remediation=rf.remediation,
                auto_fixable=rf.auto_fixable,
                scan_id=scan_id,
                timestamp=timestamp,
            ))

    # Calculate score
    total = len(checks)
    # Unique check IDs that failed
    failed_check_ids = {f.check_id for f in all_findings if f.status == FindingStatus.OPEN}
    failed = len(failed_check_ids)
    passed = total - failed
    score = (passed / total * 100) if total > 0 else 0.0

    result = ScanResult(
        scan_id=scan_id,
        framework=framework,
        target=str(target_path),
        timestamp=timestamp,
        total_controls=total,
        passed=passed,
        failed=failed,
        warnings=0,
        score=score,
        findings=all_findings,
    )

    store.save_scan(result)
    return result.to_dict()


def create_server(db_path: str | None = None) -> Server:
    """Create and configure the MCP server."""
    server = Server("complianceos")
    store = ComplianceStore(db_path)

    @server.list_tools()
    async def list_tools() -> list[Tool]:
        return [
            Tool(
                name="compliance_scan",
                description=(
                    "Scan a codebase or infrastructure directory against a compliance framework. "
                    "Finds violations, scores compliance posture, and identifies auto-fixable issues. "
                    "Frameworks: soc2, iso27001, gdpr, hipaa, pci_dss"
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "target": {
                            "type": "string",
                            "description": "Path to the codebase or project directory to scan",
                        },
                        "framework": {
                            "type": "string",
                            "enum": list(FRAMEWORKS.keys()),
                            "description": "Compliance framework to scan against",
                        },
                    },
                    "required": ["target", "framework"],
                },
            ),
            Tool(
                name="compliance_status",
                description=(
                    "Get current compliance posture for a framework. Shows latest scan results, "
                    "open findings by severity, and overall score."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "framework": {
                            "type": "string",
                            "enum": list(FRAMEWORKS.keys()),
                            "description": "Compliance framework to check status for",
                        },
                    },
                    "required": ["framework"],
                },
            ),
            Tool(
                name="compliance_fix",
                description=(
                    "Auto-generate and optionally apply fixes for compliance violations. "
                    "Can create a GitHub PR with the fixes."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "target": {
                            "type": "string",
                            "description": "Path to the codebase to fix",
                        },
                        "framework": {
                            "type": "string",
                            "enum": list(FRAMEWORKS.keys()),
                            "description": "Compliance framework",
                        },
                        "apply": {
                            "type": "boolean",
                            "description": "Whether to apply fixes (true) or just preview (false)",
                            "default": False,
                        },
                        "create_pr": {
                            "type": "boolean",
                            "description": "Whether to create a GitHub PR with fixes",
                            "default": False,
                        },
                    },
                    "required": ["target", "framework"],
                },
            ),
            Tool(
                name="compliance_evidence",
                description=(
                    "Collect compliance evidence from the project environment. "
                    "Gathers git history, CI/CD configs, policy documents, and more."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "target": {
                            "type": "string",
                            "description": "Path to the project directory",
                        },
                        "framework": {
                            "type": "string",
                            "enum": list(FRAMEWORKS.keys()),
                            "description": "Compliance framework to collect evidence for",
                        },
                    },
                    "required": ["target", "framework"],
                },
            ),
            Tool(
                name="compliance_report",
                description=(
                    "Generate an audit-ready compliance report. Includes executive summary, "
                    "findings, remediation roadmap, and evidence inventory."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "framework": {
                            "type": "string",
                            "enum": list(FRAMEWORKS.keys()),
                            "description": "Compliance framework to report on",
                        },
                        "format": {
                            "type": "string",
                            "enum": ["markdown", "json"],
                            "description": "Output format",
                            "default": "markdown",
                        },
                    },
                    "required": ["framework"],
                },
            ),
            Tool(
                name="compliance_map",
                description=(
                    "Show control overlap and mapping across compliance frameworks. "
                    "Useful for organisations complying with multiple frameworks simultaneously."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {},
                },
            ),
        ]

    @server.call_tool()
    async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
        if name == "compliance_scan":
            result = _run_scan(
                target=arguments["target"],
                framework=arguments["framework"],
                store=store,
            )
            return [TextContent(type="text", text=json.dumps(result, indent=2))]

        elif name == "compliance_status":
            framework = arguments["framework"]
            scan = store.get_latest_scan(framework)
            if not scan:
                return [TextContent(
                    type="text",
                    text=f"No scan results for {FRAMEWORK_NAMES.get(framework, framework)}. Run compliance_scan first.",
                )]

            open_findings = store.get_open_findings(framework)
            status = {
                "framework": FRAMEWORK_NAMES.get(framework, framework),
                "last_scan": scan.get("timestamp", ""),
                "score": scan.get("score", 0),
                "total_controls": scan.get("total_controls", 0),
                "passed": scan.get("passed", 0),
                "failed": scan.get("failed", 0),
                "open_findings": {
                    "critical": len([f for f in open_findings if f["severity"] == "critical"]),
                    "high": len([f for f in open_findings if f["severity"] == "high"]),
                    "medium": len([f for f in open_findings if f["severity"] == "medium"]),
                    "low": len([f for f in open_findings if f["severity"] == "low"]),
                },
                "auto_fixable": len([f for f in open_findings if f.get("auto_fixable")]),
            }
            return [TextContent(type="text", text=json.dumps(status, indent=2))]

        elif name == "compliance_fix":
            target = arguments["target"]
            framework = arguments["framework"]
            apply = arguments.get("apply", False)
            create_pr = arguments.get("create_pr", False)

            # Run scan first to get current findings
            scan_result = _run_scan(target, framework, store)
            if "error" in scan_result:
                return [TextContent(type="text", text=json.dumps(scan_result))]

            findings = scan_result.get("findings", [])
            fixable = [f for f in findings if f.get("auto_fixable") and f.get("status") == "open"]

            fixer = AutoFixer(Path(target).resolve())
            fixes = fixer.generate_fixes(fixable)

            result: dict[str, Any] = {
                "total_findings": len(findings),
                "auto_fixable": len(fixable),
                "fixes_generated": len(fixes),
                "fixes": [
                    {
                        "check_id": f.check_id,
                        "file": f.file_path,
                        "description": f.description,
                        "is_new_file": f.is_new_file,
                    }
                    for f in fixes
                ],
            }

            if apply and fixes:
                modified = fixer.apply_fixes(fixes)
                result["applied"] = True
                result["files_modified"] = modified

                if create_pr:
                    remaining = [f for f in findings if not f.get("auto_fixable")]
                    pr_gen = PRGenerator(Path(target).resolve())
                    pr_details = pr_gen.generate_pr_details(
                        framework, fixes, remaining, scan_result.get("score", 0)
                    )
                    pr_url = pr_gen.create_pr(pr_details)
                    result["pr_url"] = pr_url
                    result["pr_title"] = pr_details.title
            else:
                result["applied"] = False
                result["note"] = "Set apply=true to apply fixes"

            return [TextContent(type="text", text=json.dumps(result, indent=2))]

        elif name == "compliance_evidence":
            target = arguments["target"]
            framework = arguments["framework"]

            collector = EvidenceCollector(Path(target).resolve(), store)
            evidence = collector.collect_all(framework)

            result = {
                "framework": FRAMEWORK_NAMES.get(framework, framework),
                "evidence_collected": len(evidence),
                "items": [
                    {
                        "control_id": e.control_id,
                        "type": e.evidence_type,
                        "title": e.title,
                        "collected_at": e.collected_at,
                    }
                    for e in evidence
                ],
            }
            return [TextContent(type="text", text=json.dumps(result, indent=2))]

        elif name == "compliance_report":
            framework = arguments["framework"]
            fmt = arguments.get("format", "markdown")

            reporter = ReportGenerator(store)
            report = reporter.generate_report(framework, output_format=fmt)
            return [TextContent(type="text", text=report)]

        elif name == "compliance_map":
            overlap = get_control_overlap()
            result = {
                "description": "Control overlap across compliance frameworks",
                "frameworks": list(FRAMEWORK_NAMES.values()),
                "overlap_topics": {},
            }
            for topic, controls in overlap.items():
                result["overlap_topics"][topic] = controls

            return [TextContent(type="text", text=json.dumps(result, indent=2))]

        return [TextContent(type="text", text=f"Unknown tool: {name}")]

    return server


async def _run() -> None:
    """Run the MCP server over stdio."""
    server = create_server()
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())


def main() -> None:
    """Entry point for MCP server."""
    import asyncio
    asyncio.run(_run())
