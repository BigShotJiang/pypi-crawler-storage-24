"""ComplianceOS — Real Compliance Automation.

Scans codebases and infrastructure against SOC 2, ISO 27001, GDPR, HIPAA,
and PCI-DSS frameworks.  Automatically remediates violations and generates
audit-ready evidence packages.
"""

__version__ = "0.1.0"
