"""PCI DSS v4.0 requirements mapped to technical checks.

Maps PCI DSS v4.0 (March 2022) requirements to concrete technical controls.
Covers Requirements 1-12 with focus on technical implementation.
"""

from __future__ import annotations

PCI_DSS_CONTROLS: dict = {
    # ── Requirement 1: Install and Maintain Network Security Controls ──
    "Req1": {
        "name": "Install and Maintain Network Security Controls",
        "category": "Network Security",
        "checks": [
            {
                "id": "Req1.1",
                "check": "Firewall / NSG rules documented and reviewed",
                "scanner": "infra",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Document all firewall rules with business justification; review quarterly.",
            },
            {
                "id": "Req1.2",
                "check": "Inbound traffic restricted to necessary ports only",
                "scanner": "infra",
                "auto_fix": True,
                "severity": "critical",
                "remediation": "Close all unnecessary inbound ports; restrict to required services only.",
            },
            {
                "id": "Req1.3",
                "check": "Network segmentation between CDE and other networks",
                "scanner": "infra",
                "auto_fix": False,
                "severity": "critical",
                "remediation": "Isolate the cardholder data environment (CDE) in a separate network segment.",
            },
        ],
    },
    # ── Requirement 2: Apply Secure Configurations ──
    "Req2": {
        "name": "Apply Secure Configurations to All System Components",
        "category": "Secure Configuration",
        "checks": [
            {
                "id": "Req2.1",
                "check": "Vendor default passwords changed on all systems",
                "scanner": "infra",
                "auto_fix": False,
                "severity": "critical",
                "remediation": "Change all default passwords; disable default accounts where possible.",
            },
            {
                "id": "Req2.2",
                "check": "Unnecessary services and protocols disabled",
                "scanner": "infra",
                "auto_fix": True,
                "severity": "high",
                "remediation": "Disable unused services, protocols, and ports on all CDE systems.",
            },
        ],
    },
    # ── Requirement 3: Protect Stored Account Data ──
    "Req3": {
        "name": "Protect Stored Account Data",
        "category": "Data Protection",
        "checks": [
            {
                "id": "Req3.1",
                "check": "Cardholder data retention policy defined and enforced",
                "scanner": "config",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Define CHD retention periods; implement automated purging of expired data.",
            },
            {
                "id": "Req3.2",
                "check": "Full PAN not stored after authorisation unless business need",
                "scanner": "code",
                "auto_fix": True,
                "severity": "critical",
                "remediation": "Truncate or tokenise PAN after authorisation; never store full track data.",
            },
            {
                "id": "Req3.3",
                "check": "Sensitive authentication data not stored after authorisation",
                "scanner": "code",
                "auto_fix": True,
                "severity": "critical",
                "remediation": "Ensure CVV, PIN, and full track data are never stored post-authorisation.",
            },
            {
                "id": "Req3.4",
                "check": "PAN rendered unreadable wherever stored (encryption/hashing/truncation)",
                "scanner": "code",
                "auto_fix": True,
                "severity": "critical",
                "remediation": "Encrypt stored PAN using AES-256; or use tokenisation/truncation.",
            },
            {
                "id": "Req3.5",
                "check": "Encryption keys managed securely with defined lifecycle",
                "scanner": "infra",
                "auto_fix": False,
                "severity": "critical",
                "remediation": "Use a key management service (KMS); implement key rotation schedule.",
            },
        ],
    },
    # ── Requirement 4: Protect CHD with Strong Cryptography During Transmission ──
    "Req4": {
        "name": "Protect Cardholder Data with Strong Cryptography During Transmission",
        "category": "Transmission Security",
        "checks": [
            {
                "id": "Req4.1",
                "check": "TLS 1.2+ used for all CHD transmission",
                "scanner": "infra",
                "auto_fix": True,
                "severity": "critical",
                "remediation": "Enforce TLS 1.2+ on all endpoints that transmit cardholder data.",
            },
            {
                "id": "Req4.2",
                "check": "Certificate validation enabled (no self-signed in production)",
                "scanner": "infra",
                "auto_fix": True,
                "severity": "high",
                "remediation": "Use CA-signed certificates; enable certificate validation on all connections.",
            },
        ],
    },
    # ── Requirement 5: Protect All Systems Against Malware ──
    "Req5": {
        "name": "Protect All Systems and Networks from Malicious Software",
        "category": "Malware Protection",
        "checks": [
            {
                "id": "Req5.1",
                "check": "Anti-malware deployed on all CDE systems",
                "scanner": "infra",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Deploy anti-malware on all systems in the CDE; enable real-time scanning.",
            },
        ],
    },
    # ── Requirement 6: Develop and Maintain Secure Systems and Software ──
    "Req6": {
        "name": "Develop and Maintain Secure Systems and Software",
        "category": "Secure Development",
        "checks": [
            {
                "id": "Req6.1",
                "check": "Change management process for all system components",
                "scanner": "code",
                "auto_fix": True,
                "severity": "high",
                "remediation": "Enforce change management: PRs, reviews, testing before production deployment.",
            },
            {
                "id": "Req6.2",
                "check": "Custom code reviewed for vulnerabilities before release",
                "scanner": "code",
                "auto_fix": True,
                "severity": "high",
                "remediation": "Implement code review process with security focus; use SAST tools.",
            },
            {
                "id": "Req6.3",
                "check": "Known vulnerabilities patched within defined SLAs",
                "scanner": "code",
                "auto_fix": True,
                "severity": "critical",
                "remediation": "Patch critical vulns within 30 days; high within 90 days.",
            },
            {
                "id": "Req6.4",
                "check": "Public-facing web applications protected (WAF or code review)",
                "scanner": "infra",
                "auto_fix": True,
                "severity": "high",
                "remediation": "Deploy WAF in front of public-facing web applications.",
            },
        ],
    },
    # ── Requirement 7: Restrict Access by Business Need to Know ──
    "Req7": {
        "name": "Restrict Access to System Components and CHD by Business Need to Know",
        "category": "Access Control",
        "checks": [
            {
                "id": "Req7.1",
                "check": "Access control model defined and documented",
                "scanner": "config",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Document access control model with role definitions and CHD access matrix.",
            },
            {
                "id": "Req7.2",
                "check": "Access restricted to minimum necessary (least privilege)",
                "scanner": "infra",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Review all access grants; reduce to minimum necessary for job function.",
            },
        ],
    },
    # ── Requirement 8: Identify Users and Authenticate Access ──
    "Req8": {
        "name": "Identify Users and Authenticate Access to System Components",
        "category": "Authentication",
        "checks": [
            {
                "id": "Req8.1",
                "check": "Unique IDs assigned to all users",
                "scanner": "code",
                "auto_fix": True,
                "severity": "critical",
                "remediation": "Ensure all users have unique IDs; eliminate shared or group accounts.",
            },
            {
                "id": "Req8.2",
                "check": "MFA for all access to CDE",
                "scanner": "infra",
                "auto_fix": True,
                "severity": "critical",
                "remediation": "Enforce MFA for all users accessing the cardholder data environment.",
            },
            {
                "id": "Req8.3",
                "check": "Strong password policy (min 12 chars, complexity)",
                "scanner": "code",
                "auto_fix": True,
                "severity": "high",
                "remediation": "Enforce min 12 characters with numeric and alphabetic characters.",
            },
            {
                "id": "Req8.4",
                "check": "Account lockout after 10 failed attempts",
                "scanner": "code",
                "auto_fix": True,
                "severity": "high",
                "remediation": "Lock accounts for 30 minutes after 10 consecutive failed login attempts.",
            },
        ],
    },
    # ── Requirement 9: Restrict Physical Access ──
    "Req9": {
        "name": "Restrict Physical Access to Cardholder Data",
        "category": "Physical Security",
        "checks": [
            {
                "id": "Req9.1",
                "check": "Cloud provider physical access controls verified",
                "scanner": "config",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Obtain and review cloud provider physical security certifications.",
            },
        ],
    },
    # ── Requirement 10: Log and Monitor All Access ──
    "Req10": {
        "name": "Log and Monitor All Access to System Components and CHD",
        "category": "Logging and Monitoring",
        "checks": [
            {
                "id": "Req10.1",
                "check": "Audit trails capture all access to CHD",
                "scanner": "code",
                "auto_fix": True,
                "severity": "critical",
                "remediation": "Log all access to cardholder data with user, timestamp, action, and outcome.",
            },
            {
                "id": "Req10.2",
                "check": "Audit logs tamper-resistant (immutable storage)",
                "scanner": "infra",
                "auto_fix": True,
                "severity": "high",
                "remediation": "Store audit logs in immutable storage; enable integrity monitoring.",
            },
            {
                "id": "Req10.3",
                "check": "Logs reviewed daily for anomalies",
                "scanner": "infra",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Configure automated daily log review with alerting for anomalies.",
            },
            {
                "id": "Req10.4",
                "check": "Audit log retention minimum 12 months (3 months online)",
                "scanner": "infra",
                "auto_fix": True,
                "severity": "high",
                "remediation": "Retain audit logs for 12 months; keep last 3 months immediately accessible.",
            },
        ],
    },
    # ── Requirement 11: Test Security Regularly ──
    "Req11": {
        "name": "Test Security of Systems and Networks Regularly",
        "category": "Security Testing",
        "checks": [
            {
                "id": "Req11.1",
                "check": "Quarterly internal vulnerability scans",
                "scanner": "config",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Run quarterly internal vulnerability scans; remediate critical/high findings.",
            },
            {
                "id": "Req11.2",
                "check": "Annual penetration test conducted",
                "scanner": "config",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Conduct annual penetration test of CDE; remediate all critical findings.",
            },
            {
                "id": "Req11.3",
                "check": "File integrity monitoring on critical system files",
                "scanner": "infra",
                "auto_fix": True,
                "severity": "high",
                "remediation": "Deploy FIM on critical system files and configuration files.",
            },
        ],
    },
    # ── Requirement 12: Support Information Security with Policies and Programs ──
    "Req12": {
        "name": "Support Information Security with Organisational Policies and Programs",
        "category": "Security Governance",
        "checks": [
            {
                "id": "Req12.1",
                "check": "Information security policy reviewed annually",
                "scanner": "config",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Review and approve information security policy at least annually.",
            },
            {
                "id": "Req12.2",
                "check": "Acceptable use policies for critical technologies",
                "scanner": "config",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Document acceptable use policies for remote access, wireless, removable media.",
            },
            {
                "id": "Req12.3",
                "check": "Security responsibilities defined for all personnel",
                "scanner": "config",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Include security responsibilities in job descriptions and training.",
            },
            {
                "id": "Req12.4",
                "check": "Incident response plan covers CHD breach scenarios",
                "scanner": "config",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Create incident response plan with specific CHD breach response procedures.",
            },
        ],
    },
}
