"""GDPR (EU General Data Protection Regulation 2016/679) — technical checks.

Maps GDPR articles to concrete technical controls that can be scanned.
Focuses on Articles 5, 6, 12-22, 25, 30, 32-35, 44-49 which have
direct technical implementation requirements.
"""

from __future__ import annotations

GDPR_CONTROLS: dict = {
    "Art.5": {
        "name": "Principles Relating to Processing of Personal Data",
        "category": "Data Principles",
        "checks": [
            {
                "id": "Art.5.1",
                "check": "Personal data processing purposes documented (purpose limitation)",
                "scanner": "config",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Document all purposes for which personal data is processed in ROPA.",
            },
            {
                "id": "Art.5.2",
                "check": "Data minimisation — only necessary fields collected",
                "scanner": "code",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Audit API request schemas; remove fields not required for stated purpose.",
            },
            {
                "id": "Art.5.3",
                "check": "Storage limitation — retention periods defined per data category",
                "scanner": "config",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Define retention periods for each personal data category and automate deletion.",
            },
        ],
    },
    "Art.6": {
        "name": "Lawfulness of Processing",
        "category": "Lawful Basis",
        "checks": [
            {
                "id": "Art.6.1",
                "check": "Lawful basis recorded for each processing activity",
                "scanner": "config",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Record lawful basis (consent, contract, legitimate interest, etc.) per processing activity.",
            },
        ],
    },
    "Art.7": {
        "name": "Conditions for Consent",
        "category": "Consent",
        "checks": [
            {
                "id": "Art.7.1",
                "check": "Consent mechanism requires affirmative action (no pre-ticked boxes)",
                "scanner": "code",
                "auto_fix": True,
                "severity": "high",
                "remediation": "Ensure consent checkboxes are unchecked by default; require explicit opt-in.",
            },
            {
                "id": "Art.7.2",
                "check": "Consent records stored with timestamp and version",
                "scanner": "code",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Log consent events with user ID, timestamp, consent version, and IP.",
            },
        ],
    },
    "Art.12": {
        "name": "Transparent Information and Communication",
        "category": "Data Subject Rights",
        "checks": [
            {
                "id": "Art.12.1",
                "check": "Privacy policy written in clear, plain language",
                "scanner": "code",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Review privacy policy for readability (Flesch-Kincaid grade level < 12).",
            },
        ],
    },
    "Art.15": {
        "name": "Right of Access by the Data Subject",
        "category": "Data Subject Rights",
        "checks": [
            {
                "id": "Art.15.1",
                "check": "Data subject access request (DSAR) endpoint or process exists",
                "scanner": "api",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Implement a DSAR endpoint or documented process to export user data.",
            },
        ],
    },
    "Art.17": {
        "name": "Right to Erasure (Right to be Forgotten)",
        "category": "Data Subject Rights",
        "checks": [
            {
                "id": "Art.17.1",
                "check": "User account deletion endpoint exists and purges personal data",
                "scanner": "api",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Implement DELETE /api/users/me that purges all personal data within 30 days.",
            },
            {
                "id": "Art.17.2",
                "check": "Deletion cascades to backups within retention period",
                "scanner": "infra",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Document backup retention policy; ensure deleted data ages out of backups.",
            },
        ],
    },
    "Art.20": {
        "name": "Right to Data Portability",
        "category": "Data Subject Rights",
        "checks": [
            {
                "id": "Art.20.1",
                "check": "Data export in machine-readable format (JSON/CSV)",
                "scanner": "api",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Implement data export endpoint returning JSON or CSV of user data.",
            },
        ],
    },
    "Art.25": {
        "name": "Data Protection by Design and by Default",
        "category": "Privacy by Design",
        "checks": [
            {
                "id": "Art.25.1",
                "check": "Privacy by default — minimum data shared with third parties",
                "scanner": "code",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Audit third-party integrations; share only required data fields.",
            },
            {
                "id": "Art.25.2",
                "check": "Personal data encrypted at rest",
                "scanner": "infra",
                "auto_fix": True,
                "severity": "critical",
                "remediation": "Enable encryption at rest for all databases containing personal data.",
            },
        ],
    },
    "Art.30": {
        "name": "Records of Processing Activities (ROPA)",
        "category": "Accountability",
        "checks": [
            {
                "id": "Art.30.1",
                "check": "Records of processing activities maintained",
                "scanner": "config",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Maintain ROPA with processing purposes, data categories, recipients, and retention.",
            },
        ],
    },
    "Art.32": {
        "name": "Security of Processing",
        "category": "Security",
        "checks": [
            {
                "id": "Art.32.1",
                "check": "Pseudonymisation applied where possible",
                "scanner": "code",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Apply pseudonymisation (tokenisation, hashing) to personal data in analytics.",
            },
            {
                "id": "Art.32.2",
                "check": "Ability to restore availability of personal data (backups)",
                "scanner": "infra",
                "auto_fix": True,
                "severity": "high",
                "remediation": "Enable automated backups for all personal data stores.",
            },
            {
                "id": "Art.32.3",
                "check": "Encryption at rest for personal data",
                "scanner": "infra",
                "auto_fix": True,
                "severity": "critical",
                "remediation": "Enable encryption at rest on all databases and storage containing personal data.",
            },
            {
                "id": "Art.32.4",
                "check": "Encryption in transit (TLS 1.2+)",
                "scanner": "infra",
                "auto_fix": True,
                "severity": "critical",
                "remediation": "Enforce TLS 1.2+ on all endpoints transmitting personal data.",
            },
        ],
    },
    "Art.33": {
        "name": "Notification of Personal Data Breach to Supervisory Authority",
        "category": "Breach Notification",
        "checks": [
            {
                "id": "Art.33.1",
                "check": "Breach notification procedure documented (72-hour requirement)",
                "scanner": "config",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Document breach notification procedure with 72-hour timeline to supervisory authority.",
            },
        ],
    },
    "Art.35": {
        "name": "Data Protection Impact Assessment (DPIA)",
        "category": "Risk Assessment",
        "checks": [
            {
                "id": "Art.35.1",
                "check": "DPIA conducted for high-risk processing activities",
                "scanner": "config",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Conduct DPIA for processing involving profiling, large-scale monitoring, or sensitive data.",
            },
        ],
    },
    "Art.44": {
        "name": "General Principle for Transfers to Third Countries",
        "category": "International Transfers",
        "checks": [
            {
                "id": "Art.44.1",
                "check": "Data transfer mechanisms documented for non-EU/EEA transfers",
                "scanner": "config",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Document legal basis for international transfers (SCCs, adequacy decision, BCRs).",
            },
            {
                "id": "Art.44.2",
                "check": "Cloud infrastructure data residency verified",
                "scanner": "infra",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Verify all cloud resources storing personal data are in compliant regions (EU/EEA).",
            },
        ],
    },
}
