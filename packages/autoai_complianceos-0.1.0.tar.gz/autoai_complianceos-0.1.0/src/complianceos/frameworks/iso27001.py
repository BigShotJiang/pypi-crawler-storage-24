"""ISO/IEC 27001:2022 Annex A controls mapped to technical checks.

Based on ISO 27001:2022 which reorganised controls into 4 themes:
  5 - Organisational (37 controls)
  6 - People (8 controls)
  7 - Physical (14 controls)
  8 - Technological (34 controls)

We map 20+ controls focusing on the technical and organisational controls
most relevant to software and cloud infrastructure.
"""

from __future__ import annotations

ISO27001_CONTROLS: dict = {
    # ── A.5: Organisational Controls ──
    "A.5.1": {
        "name": "Policies for Information Security",
        "category": "Organisational",
        "checks": [
            {
                "id": "A.5.1.1",
                "check": "Information security policy document exists and is approved",
                "scanner": "config",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Draft and approve an information security policy, review annually.",
            },
        ],
    },
    "A.5.7": {
        "name": "Threat Intelligence",
        "category": "Organisational",
        "checks": [
            {
                "id": "A.5.7.1",
                "check": "Threat intelligence feeds configured",
                "scanner": "infra",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Subscribe to threat intelligence feeds (MITRE ATT&CK, CISA KEV).",
            },
        ],
    },
    "A.5.10": {
        "name": "Acceptable Use of Information and Assets",
        "category": "Organisational",
        "checks": [
            {
                "id": "A.5.10.1",
                "check": "Acceptable use policy exists and is acknowledged by staff",
                "scanner": "config",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Publish acceptable use policy and track employee acknowledgements.",
            },
        ],
    },
    "A.5.15": {
        "name": "Access Control",
        "category": "Organisational",
        "checks": [
            {
                "id": "A.5.15.1",
                "check": "Access control policy documented with least privilege principle",
                "scanner": "config",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Document access control policy enforcing least privilege.",
            },
            {
                "id": "A.5.15.2",
                "check": "IAM roles follow least privilege — no wildcard permissions",
                "scanner": "infra",
                "auto_fix": True,
                "severity": "high",
                "remediation": "Remove wildcard (*) permissions from all IAM roles and policies.",
            },
        ],
    },
    "A.5.23": {
        "name": "Information Security for Cloud Services",
        "category": "Organisational",
        "checks": [
            {
                "id": "A.5.23.1",
                "check": "Cloud shared responsibility model documented",
                "scanner": "config",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Document cloud shared responsibility model for each provider.",
            },
        ],
    },
    "A.5.24": {
        "name": "Information Security Incident Management Planning",
        "category": "Organisational",
        "checks": [
            {
                "id": "A.5.24.1",
                "check": "Incident response plan exists with defined roles",
                "scanner": "config",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Create incident response plan with roles, escalation, and communication templates.",
            },
        ],
    },
    "A.5.29": {
        "name": "Information Security During Disruption",
        "category": "Organisational",
        "checks": [
            {
                "id": "A.5.29.1",
                "check": "Business continuity plan includes IT disaster recovery",
                "scanner": "config",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Include IT systems in business continuity plan with RTO/RPO targets.",
            },
        ],
    },
    "A.5.31": {
        "name": "Legal, Statutory, Regulatory and Contractual Requirements",
        "category": "Organisational",
        "checks": [
            {
                "id": "A.5.31.1",
                "check": "Regulatory requirements register maintained",
                "scanner": "config",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Maintain a register of applicable legal and regulatory requirements.",
            },
        ],
    },
    # ── A.8: Technological Controls ──
    "A.8.1": {
        "name": "User Endpoint Devices",
        "category": "Technological",
        "checks": [
            {
                "id": "A.8.1.1",
                "check": "Endpoint protection / EDR deployed on developer machines",
                "scanner": "infra",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Deploy EDR (CrowdStrike, Defender for Endpoint) on all developer devices.",
            },
        ],
    },
    "A.8.2": {
        "name": "Privileged Access Rights",
        "category": "Technological",
        "checks": [
            {
                "id": "A.8.2.1",
                "check": "Privileged access requires MFA and is time-limited",
                "scanner": "infra",
                "auto_fix": True,
                "severity": "critical",
                "remediation": "Enforce MFA for all privileged access; use JIT access where possible.",
            },
        ],
    },
    "A.8.5": {
        "name": "Secure Authentication",
        "category": "Technological",
        "checks": [
            {
                "id": "A.8.5.1",
                "check": "MFA enforced for all user accounts",
                "scanner": "infra",
                "auto_fix": True,
                "severity": "critical",
                "remediation": "Enable MFA for all user accounts via identity provider policy.",
            },
            {
                "id": "A.8.5.2",
                "check": "Password policy enforces minimum 12 characters",
                "scanner": "code",
                "auto_fix": True,
                "severity": "high",
                "remediation": "Configure password policy: minimum 12 chars, complexity, no common passwords.",
            },
            {
                "id": "A.8.5.3",
                "check": "Account lockout after 5 failed attempts",
                "scanner": "code",
                "auto_fix": True,
                "severity": "high",
                "remediation": "Implement account lockout or progressive delay after 5 failed login attempts.",
            },
        ],
    },
    "A.8.8": {
        "name": "Management of Technical Vulnerabilities",
        "category": "Technological",
        "checks": [
            {
                "id": "A.8.8.1",
                "check": "Automated vulnerability scanning for dependencies",
                "scanner": "code",
                "auto_fix": True,
                "severity": "high",
                "remediation": "Enable Dependabot, Snyk, or Trivy for dependency vulnerability scanning.",
            },
            {
                "id": "A.8.8.2",
                "check": "Container image scanning enabled",
                "scanner": "code",
                "auto_fix": True,
                "severity": "high",
                "remediation": "Scan container images with Trivy or Azure Defender before deployment.",
            },
        ],
    },
    "A.8.9": {
        "name": "Configuration Management",
        "category": "Technological",
        "checks": [
            {
                "id": "A.8.9.1",
                "check": "Baseline configurations defined for servers and containers",
                "scanner": "infra",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Define and enforce hardened baseline configurations (CIS Benchmarks).",
            },
        ],
    },
    "A.8.10": {
        "name": "Information Deletion",
        "category": "Technological",
        "checks": [
            {
                "id": "A.8.10.1",
                "check": "Data retention policies enforced with automated deletion",
                "scanner": "infra",
                "auto_fix": True,
                "severity": "medium",
                "remediation": "Implement lifecycle policies for storage accounts and databases.",
            },
        ],
    },
    "A.8.12": {
        "name": "Data Leakage Prevention",
        "category": "Technological",
        "checks": [
            {
                "id": "A.8.12.1",
                "check": "Secrets scanning enabled in CI/CD pipeline",
                "scanner": "code",
                "auto_fix": True,
                "severity": "high",
                "remediation": "Enable GitHub secret scanning or git-secrets pre-commit hook.",
            },
        ],
    },
    "A.8.13": {
        "name": "Information Backup",
        "category": "Technological",
        "checks": [
            {
                "id": "A.8.13.1",
                "check": "Automated backups for all critical data stores",
                "scanner": "infra",
                "auto_fix": True,
                "severity": "critical",
                "remediation": "Enable automated backups with appropriate retention for all databases.",
            },
        ],
    },
    "A.8.15": {
        "name": "Logging",
        "category": "Technological",
        "checks": [
            {
                "id": "A.8.15.1",
                "check": "Application logging captures auth events, errors, and data access",
                "scanner": "code",
                "auto_fix": True,
                "severity": "high",
                "remediation": "Implement structured logging for auth, errors, and sensitive data access.",
            },
            {
                "id": "A.8.15.2",
                "check": "Log integrity protection (immutable storage or signing)",
                "scanner": "infra",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Enable immutable storage or log signing for audit log tamper resistance.",
            },
        ],
    },
    "A.8.20": {
        "name": "Networks Security",
        "category": "Technological",
        "checks": [
            {
                "id": "A.8.20.1",
                "check": "Network security groups restrict inbound traffic to required ports only",
                "scanner": "infra",
                "auto_fix": True,
                "severity": "high",
                "remediation": "Restrict NSG/security group rules to only required ports and source IPs.",
            },
        ],
    },
    "A.8.24": {
        "name": "Use of Cryptography",
        "category": "Technological",
        "checks": [
            {
                "id": "A.8.24.1",
                "check": "Encryption at rest for all data stores",
                "scanner": "infra",
                "auto_fix": True,
                "severity": "critical",
                "remediation": "Enable encryption at rest using AES-256 or equivalent for all data stores.",
            },
            {
                "id": "A.8.24.2",
                "check": "TLS 1.2+ enforced for data in transit",
                "scanner": "infra",
                "auto_fix": True,
                "severity": "critical",
                "remediation": "Enforce TLS 1.2+ on all endpoints; disable TLS 1.0 and 1.1.",
            },
        ],
    },
    "A.8.25": {
        "name": "Secure Development Life Cycle",
        "category": "Technological",
        "checks": [
            {
                "id": "A.8.25.1",
                "check": "Secure coding guidelines documented",
                "scanner": "config",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Publish secure coding guidelines based on OWASP.",
            },
        ],
    },
    "A.8.28": {
        "name": "Secure Coding",
        "category": "Technological",
        "checks": [
            {
                "id": "A.8.28.1",
                "check": "SAST tool integrated in CI pipeline",
                "scanner": "code",
                "auto_fix": True,
                "severity": "high",
                "remediation": "Integrate SAST tool (Semgrep, CodeQL, Bandit) in CI pipeline.",
            },
            {
                "id": "A.8.28.2",
                "check": "No SQL injection vulnerabilities (parameterised queries used)",
                "scanner": "code",
                "auto_fix": True,
                "severity": "critical",
                "remediation": "Replace string concatenation in SQL with parameterised queries.",
            },
        ],
    },
    "A.8.32": {
        "name": "Change Management",
        "category": "Technological",
        "checks": [
            {
                "id": "A.8.32.1",
                "check": "Change management process with approval workflow",
                "scanner": "code",
                "auto_fix": True,
                "severity": "high",
                "remediation": "Enforce PR reviews and approval before merging to production branches.",
            },
        ],
    },
}
