"""Compliance frameworks with real control mappings."""

from __future__ import annotations

from typing import Any

from .soc2 import SOC2_CONTROLS
from .iso27001 import ISO27001_CONTROLS
from .gdpr import GDPR_CONTROLS
from .hipaa import HIPAA_CONTROLS
from .pci_dss import PCI_DSS_CONTROLS

FRAMEWORKS: dict[str, dict[str, Any]] = {
    "soc2": SOC2_CONTROLS,
    "iso27001": ISO27001_CONTROLS,
    "gdpr": GDPR_CONTROLS,
    "hipaa": HIPAA_CONTROLS,
    "pci_dss": PCI_DSS_CONTROLS,
}

FRAMEWORK_NAMES: dict[str, str] = {
    "soc2": "SOC 2 Type II",
    "iso27001": "ISO/IEC 27001:2022",
    "gdpr": "GDPR (EU 2016/679)",
    "hipaa": "HIPAA Security Rule",
    "pci_dss": "PCI DSS v4.0",
}


def get_all_checks(framework: str) -> list[dict[str, Any]]:
    """Flatten a framework's controls into a list of individual checks."""
    controls = FRAMEWORKS.get(framework, {})
    checks: list[dict[str, Any]] = []
    for control_id, control in controls.items():
        for check in control.get("checks", []):
            checks.append({
                "control_id": control_id,
                "control_name": control["name"],
                "framework": framework,
                **check,
            })
    return checks


def get_control_overlap() -> dict[str, list[dict[str, str]]]:
    """Map overlapping controls across frameworks.

    Returns a dict keyed by topic with list of matching controls from each framework.
    """
    overlap_map: dict[str, list[dict[str, str]]] = {
        "Encryption at Rest": [
            {"framework": "soc2", "control": "CC6.1", "check": "CC6.1.3"},
            {"framework": "iso27001", "control": "A.8.24", "check": "A.8.24.1"},
            {"framework": "gdpr", "control": "Art.32", "check": "Art.32.3"},
            {"framework": "hipaa", "control": "164.312(a)(2)(iv)", "check": "164.312.a.2.iv.1"},
            {"framework": "pci_dss", "control": "Req3", "check": "Req3.5"},
        ],
        "Encryption in Transit": [
            {"framework": "soc2", "control": "CC6.1", "check": "CC6.1.4"},
            {"framework": "iso27001", "control": "A.8.24", "check": "A.8.24.2"},
            {"framework": "gdpr", "control": "Art.32", "check": "Art.32.4"},
            {"framework": "hipaa", "control": "164.312(e)(1)", "check": "164.312.e.1.1"},
            {"framework": "pci_dss", "control": "Req4", "check": "Req4.1"},
        ],
        "Access Control / MFA": [
            {"framework": "soc2", "control": "CC6.1", "check": "CC6.1.1"},
            {"framework": "iso27001", "control": "A.8.5", "check": "A.8.5.1"},
            {"framework": "hipaa", "control": "164.312(d)", "check": "164.312.d.1"},
            {"framework": "pci_dss", "control": "Req8", "check": "Req8.1"},
        ],
        "Logging and Monitoring": [
            {"framework": "soc2", "control": "CC7.2", "check": "CC7.2.1"},
            {"framework": "iso27001", "control": "A.8.15", "check": "A.8.15.1"},
            {"framework": "hipaa", "control": "164.312(b)", "check": "164.312.b.1"},
            {"framework": "pci_dss", "control": "Req10", "check": "Req10.1"},
        ],
        "Vulnerability Management": [
            {"framework": "soc2", "control": "CC7.1", "check": "CC7.1.3"},
            {"framework": "iso27001", "control": "A.8.8", "check": "A.8.8.1"},
            {"framework": "pci_dss", "control": "Req6", "check": "Req6.3"},
        ],
        "Incident Response": [
            {"framework": "soc2", "control": "CC7.3", "check": "CC7.3.1"},
            {"framework": "iso27001", "control": "A.5.24", "check": "A.5.24.1"},
            {"framework": "gdpr", "control": "Art.33", "check": "Art.33.1"},
            {"framework": "hipaa", "control": "164.308(a)(6)", "check": "164.308.a.6.1"},
            {"framework": "pci_dss", "control": "Req12", "check": "Req12.4"},
        ],
        "Data Retention / Disposal": [
            {"framework": "soc2", "control": "CC6.5", "check": "CC6.5.1"},
            {"framework": "iso27001", "control": "A.8.10", "check": "A.8.10.1"},
            {"framework": "gdpr", "control": "Art.17", "check": "Art.17.1"},
            {"framework": "hipaa", "control": "164.310(d)(2)(i)", "check": "164.310.d.2.i.1"},
        ],
        "Backup and Recovery": [
            {"framework": "soc2", "control": "A1.2", "check": "A1.2.1"},
            {"framework": "iso27001", "control": "A.8.13", "check": "A.8.13.1"},
            {"framework": "hipaa", "control": "164.308(a)(7)", "check": "164.308.a.7.1"},
        ],
        "Change Management": [
            {"framework": "soc2", "control": "CC8.1", "check": "CC8.1.1"},
            {"framework": "iso27001", "control": "A.8.32", "check": "A.8.32.1"},
            {"framework": "pci_dss", "control": "Req6", "check": "Req6.1"},
        ],
        "Risk Assessment": [
            {"framework": "soc2", "control": "CC3.2", "check": "CC3.2.1"},
            {"framework": "iso27001", "control": "A.5.7", "check": "A.5.7.1"},
            {"framework": "gdpr", "control": "Art.35", "check": "Art.35.1"},
            {"framework": "hipaa", "control": "164.308(a)(1)", "check": "164.308.a.1.1"},
            {"framework": "pci_dss", "control": "Req12", "check": "Req12.1"},
        ],
    }
    return overlap_map
