"""SOC 2 Type II Trust Services Criteria — 50+ controls mapped to technical checks.

Based on AICPA 2017 Trust Services Criteria (TSP Section 100).
Categories: CC (Common Criteria), A (Availability), C (Confidentiality),
PI (Processing Integrity), P (Privacy).
"""

from __future__ import annotations

SOC2_CONTROLS: dict = {
    # ── CC1: Control Environment ──
    "CC1.1": {
        "name": "COSO Principle 1: Demonstrates Commitment to Integrity and Ethical Values",
        "category": "Control Environment",
        "checks": [
            {
                "id": "CC1.1.1",
                "check": "Code of conduct / acceptable use policy exists",
                "scanner": "config",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Create and publish an acceptable use policy document.",
            },
        ],
    },
    "CC1.2": {
        "name": "COSO Principle 2: Board Exercises Oversight Responsibility",
        "category": "Control Environment",
        "checks": [
            {
                "id": "CC1.2.1",
                "check": "Security governance committee documented",
                "scanner": "config",
                "auto_fix": False,
                "severity": "low",
                "remediation": "Document security governance structure and meeting cadence.",
            },
        ],
    },
    # ── CC2: Communication and Information ──
    "CC2.1": {
        "name": "COSO Principle 13: Uses Relevant Information",
        "category": "Communication and Information",
        "checks": [
            {
                "id": "CC2.1.1",
                "check": "Security awareness training program exists",
                "scanner": "config",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Implement annual security awareness training for all employees.",
            },
        ],
    },
    # ── CC3: Risk Assessment ──
    "CC3.1": {
        "name": "COSO Principle 6: Specifies Suitable Objectives",
        "category": "Risk Assessment",
        "checks": [
            {
                "id": "CC3.1.1",
                "check": "Risk assessment policy documented",
                "scanner": "config",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Create a formal risk assessment policy and procedure.",
            },
        ],
    },
    "CC3.2": {
        "name": "COSO Principle 7: Identifies and Analyzes Risk",
        "category": "Risk Assessment",
        "checks": [
            {
                "id": "CC3.2.1",
                "check": "Risk register exists and is current (updated within 90 days)",
                "scanner": "config",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Create or update the risk register with current threats and mitigations.",
            },
            {
                "id": "CC3.2.2",
                "check": "Dependency vulnerability scanning enabled (Dependabot/Snyk)",
                "scanner": "code",
                "auto_fix": True,
                "severity": "high",
                "remediation": "Enable Dependabot or Snyk for automated dependency vulnerability scanning.",
            },
        ],
    },
    "CC3.3": {
        "name": "COSO Principle 8: Assesses Fraud Risk",
        "category": "Risk Assessment",
        "checks": [
            {
                "id": "CC3.3.1",
                "check": "Fraud risk assessment completed",
                "scanner": "config",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Conduct fraud risk assessment covering financial and data fraud scenarios.",
            },
        ],
    },
    # ── CC4: Monitoring Activities ──
    "CC4.1": {
        "name": "COSO Principle 16: Selects, Develops, and Performs Ongoing Evaluations",
        "category": "Monitoring",
        "checks": [
            {
                "id": "CC4.1.1",
                "check": "Continuous monitoring / SIEM configured",
                "scanner": "infra",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Deploy a SIEM solution (e.g. Azure Sentinel, Splunk, Datadog Security).",
            },
            {
                "id": "CC4.1.2",
                "check": "Automated alerting for security events",
                "scanner": "infra",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Configure alerts for failed logins, privilege escalation, and anomalous access.",
            },
        ],
    },
    # ── CC5: Control Activities ──
    "CC5.1": {
        "name": "COSO Principle 10: Selects and Develops Control Activities",
        "category": "Control Activities",
        "checks": [
            {
                "id": "CC5.1.1",
                "check": "Segregation of duties enforced (prod vs dev access)",
                "scanner": "infra",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Separate production and development IAM roles; no dev access to prod data.",
            },
        ],
    },
    "CC5.2": {
        "name": "COSO Principle 11: Selects and Develops General Controls Over Technology",
        "category": "Control Activities",
        "checks": [
            {
                "id": "CC5.2.1",
                "check": "Infrastructure as Code (IaC) used for deployments",
                "scanner": "code",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Adopt Terraform, Pulumi, or CloudFormation for all infrastructure.",
            },
            {
                "id": "CC5.2.2",
                "check": "CI/CD pipeline includes security scanning stage",
                "scanner": "code",
                "auto_fix": True,
                "severity": "high",
                "remediation": "Add SAST/DAST scanning step to CI/CD pipeline.",
            },
        ],
    },
    # ── CC6: Logical and Physical Access Controls ──
    "CC6.1": {
        "name": "Logical and Physical Access Controls",
        "category": "Access Control",
        "checks": [
            {
                "id": "CC6.1.1",
                "check": "MFA enabled for all admin accounts",
                "scanner": "infra",
                "auto_fix": True,
                "severity": "critical",
                "remediation": "Enable MFA on all administrative accounts in the identity provider.",
            },
            {
                "id": "CC6.1.2",
                "check": "No public S3/Blob storage buckets",
                "scanner": "infra",
                "auto_fix": True,
                "severity": "critical",
                "remediation": "Set all storage containers to private access. Block public blob access at account level.",
            },
            {
                "id": "CC6.1.3",
                "check": "Encryption at rest enabled for databases",
                "scanner": "infra",
                "auto_fix": True,
                "severity": "critical",
                "remediation": "Enable Transparent Data Encryption (TDE) or equivalent on all databases.",
            },
            {
                "id": "CC6.1.4",
                "check": "TLS 1.2+ enforced for all connections",
                "scanner": "infra",
                "auto_fix": True,
                "severity": "critical",
                "remediation": "Set minimum TLS version to 1.2 on all endpoints and load balancers.",
            },
            {
                "id": "CC6.1.5",
                "check": "No hardcoded credentials in source code",
                "scanner": "code",
                "auto_fix": True,
                "severity": "critical",
                "remediation": "Move secrets to environment variables or a secrets manager (Azure Key Vault, AWS Secrets Manager).",
            },
            {
                "id": "CC6.1.6",
                "check": "API keys not committed to version control",
                "scanner": "code",
                "auto_fix": True,
                "severity": "critical",
                "remediation": "Add secrets to .gitignore and rotate any exposed keys immediately.",
            },
            {
                "id": "CC6.1.7",
                "check": "Password complexity requirements enforced",
                "scanner": "code",
                "auto_fix": True,
                "severity": "high",
                "remediation": "Enforce minimum 12 characters with complexity requirements in auth system.",
            },
            {
                "id": "CC6.1.8",
                "check": "Session timeout configured (max 30 min idle)",
                "scanner": "code",
                "auto_fix": True,
                "severity": "medium",
                "remediation": "Set session idle timeout to 30 minutes or less.",
            },
        ],
    },
    "CC6.2": {
        "name": "Prior to Issuing System Credentials and Granting System Access",
        "category": "Access Control",
        "checks": [
            {
                "id": "CC6.2.1",
                "check": "User provisioning process documented",
                "scanner": "config",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Document the user provisioning and deprovisioning process.",
            },
            {
                "id": "CC6.2.2",
                "check": "Role-based access control (RBAC) implemented",
                "scanner": "code",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Implement RBAC with least-privilege principle for all application roles.",
            },
        ],
    },
    "CC6.3": {
        "name": "Access to Data and Systems Based on Authorization",
        "category": "Access Control",
        "checks": [
            {
                "id": "CC6.3.1",
                "check": "Least privilege principle enforced in IAM policies",
                "scanner": "infra",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Review IAM policies — remove wildcard (*) permissions and overly broad roles.",
            },
            {
                "id": "CC6.3.2",
                "check": "Service accounts use minimal permissions",
                "scanner": "infra",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Audit service account roles and reduce to minimum required permissions.",
            },
        ],
    },
    "CC6.4": {
        "name": "Restriction and Management of Physical Access",
        "category": "Access Control",
        "checks": [
            {
                "id": "CC6.4.1",
                "check": "Cloud provider physical security certifications verified",
                "scanner": "config",
                "auto_fix": False,
                "severity": "low",
                "remediation": "Obtain and file cloud provider SOC 2 Type II report as evidence.",
            },
        ],
    },
    "CC6.5": {
        "name": "Disposal of Data and Assets",
        "category": "Access Control",
        "checks": [
            {
                "id": "CC6.5.1",
                "check": "Data retention and disposal policy exists",
                "scanner": "config",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Create a data retention schedule and secure disposal procedure.",
            },
        ],
    },
    "CC6.6": {
        "name": "Protection Against External Threats",
        "category": "Access Control",
        "checks": [
            {
                "id": "CC6.6.1",
                "check": "Web Application Firewall (WAF) enabled",
                "scanner": "infra",
                "auto_fix": True,
                "severity": "high",
                "remediation": "Enable WAF (Azure Front Door, AWS WAF, Cloudflare) on all public endpoints.",
            },
            {
                "id": "CC6.6.2",
                "check": "DDoS protection enabled",
                "scanner": "infra",
                "auto_fix": True,
                "severity": "high",
                "remediation": "Enable DDoS protection (Azure DDoS Protection Standard or AWS Shield).",
            },
            {
                "id": "CC6.6.3",
                "check": "Network segmentation configured (VPC/VNet)",
                "scanner": "infra",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Deploy workloads in private subnets with proper network segmentation.",
            },
        ],
    },
    "CC6.7": {
        "name": "Restriction of Data Transmission and Removal",
        "category": "Access Control",
        "checks": [
            {
                "id": "CC6.7.1",
                "check": "Data loss prevention (DLP) controls implemented",
                "scanner": "infra",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Implement DLP rules for sensitive data in email and file sharing.",
            },
        ],
    },
    "CC6.8": {
        "name": "Prevention and Detection of Unauthorized Software",
        "category": "Access Control",
        "checks": [
            {
                "id": "CC6.8.1",
                "check": "Software allowlisting / endpoint protection deployed",
                "scanner": "infra",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Deploy endpoint detection and response (EDR) on all workstations.",
            },
        ],
    },
    # ── CC7: System Operations ──
    "CC7.1": {
        "name": "Detection and Monitoring of Security Events",
        "category": "System Operations",
        "checks": [
            {
                "id": "CC7.1.1",
                "check": "Centralized logging configured (all services)",
                "scanner": "infra",
                "auto_fix": True,
                "severity": "high",
                "remediation": "Route all application and infrastructure logs to centralized logging.",
            },
            {
                "id": "CC7.1.2",
                "check": "Audit logging enabled for data access",
                "scanner": "infra",
                "auto_fix": True,
                "severity": "high",
                "remediation": "Enable audit logging for database queries and file access.",
            },
            {
                "id": "CC7.1.3",
                "check": "Vulnerability scanning runs on schedule",
                "scanner": "code",
                "auto_fix": True,
                "severity": "high",
                "remediation": "Configure weekly automated vulnerability scans (Nessus, Qualys, or equivalent).",
            },
        ],
    },
    "CC7.2": {
        "name": "Monitoring System Components for Anomalies",
        "category": "System Operations",
        "checks": [
            {
                "id": "CC7.2.1",
                "check": "Anomaly detection / intrusion detection configured",
                "scanner": "infra",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Deploy IDS/IPS (Azure Defender, AWS GuardDuty) for anomaly detection.",
            },
            {
                "id": "CC7.2.2",
                "check": "Security event correlation and alerting",
                "scanner": "infra",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Configure SIEM rules to correlate events and generate alerts.",
            },
        ],
    },
    "CC7.3": {
        "name": "Response to Security Incidents",
        "category": "System Operations",
        "checks": [
            {
                "id": "CC7.3.1",
                "check": "Incident response plan documented and tested",
                "scanner": "config",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Create an incident response plan and test it with tabletop exercises.",
            },
            {
                "id": "CC7.3.2",
                "check": "Incident response contacts and escalation documented",
                "scanner": "config",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Document on-call rotation, escalation paths, and notification channels.",
            },
        ],
    },
    "CC7.4": {
        "name": "Containment and Remediation of Security Incidents",
        "category": "System Operations",
        "checks": [
            {
                "id": "CC7.4.1",
                "check": "Ability to isolate compromised systems",
                "scanner": "infra",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Ensure network security groups can isolate individual hosts on demand.",
            },
        ],
    },
    # ── CC8: Change Management ──
    "CC8.1": {
        "name": "Changes to Infrastructure, Data, and Software",
        "category": "Change Management",
        "checks": [
            {
                "id": "CC8.1.1",
                "check": "All changes go through pull request review",
                "scanner": "code",
                "auto_fix": True,
                "severity": "high",
                "remediation": "Enforce branch protection: require PR reviews before merge to main.",
            },
            {
                "id": "CC8.1.2",
                "check": "Branch protection rules enabled on main branch",
                "scanner": "code",
                "auto_fix": True,
                "severity": "high",
                "remediation": "Enable branch protection: require reviews, status checks, no force push.",
            },
            {
                "id": "CC8.1.3",
                "check": "Automated testing in CI before deploy",
                "scanner": "code",
                "auto_fix": True,
                "severity": "high",
                "remediation": "Add automated test suite to CI pipeline; block deploy on test failure.",
            },
            {
                "id": "CC8.1.4",
                "check": "Rollback procedure documented and tested",
                "scanner": "config",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Document rollback procedures for each deployment type.",
            },
        ],
    },
    # ── CC9: Risk Mitigation ──
    "CC9.1": {
        "name": "Identification and Mitigation of Risk from Business Relationships",
        "category": "Risk Mitigation",
        "checks": [
            {
                "id": "CC9.1.1",
                "check": "Vendor security assessments conducted",
                "scanner": "config",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Maintain vendor security questionnaires and review annually.",
            },
        ],
    },
    "CC9.2": {
        "name": "Risk Mitigation Through Insurance",
        "category": "Risk Mitigation",
        "checks": [
            {
                "id": "CC9.2.1",
                "check": "Cyber insurance policy in place",
                "scanner": "config",
                "auto_fix": False,
                "severity": "low",
                "remediation": "Obtain cyber liability insurance appropriate for organization size.",
            },
        ],
    },
    # ── A1: Availability ──
    "A1.1": {
        "name": "System Availability Objectives",
        "category": "Availability",
        "checks": [
            {
                "id": "A1.1.1",
                "check": "SLA / uptime targets defined",
                "scanner": "config",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Define and document SLAs with uptime targets (e.g. 99.9%).",
            },
        ],
    },
    "A1.2": {
        "name": "Recovery Capabilities",
        "category": "Availability",
        "checks": [
            {
                "id": "A1.2.1",
                "check": "Automated backups configured for databases",
                "scanner": "infra",
                "auto_fix": True,
                "severity": "critical",
                "remediation": "Enable automated daily backups with 30-day retention for all databases.",
            },
            {
                "id": "A1.2.2",
                "check": "Backup restoration tested within last 90 days",
                "scanner": "config",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Perform quarterly backup restoration tests and document results.",
            },
            {
                "id": "A1.2.3",
                "check": "Disaster recovery plan documented",
                "scanner": "config",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Create a disaster recovery plan with RPO and RTO targets.",
            },
        ],
    },
    "A1.3": {
        "name": "Recovery Objectives",
        "category": "Availability",
        "checks": [
            {
                "id": "A1.3.1",
                "check": "RTO and RPO defined for critical systems",
                "scanner": "config",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Define Recovery Time Objective and Recovery Point Objective per system.",
            },
        ],
    },
    # ── C1: Confidentiality ──
    "C1.1": {
        "name": "Identification and Classification of Confidential Information",
        "category": "Confidentiality",
        "checks": [
            {
                "id": "C1.1.1",
                "check": "Data classification policy exists",
                "scanner": "config",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Create data classification policy (Public, Internal, Confidential, Restricted).",
            },
        ],
    },
    "C1.2": {
        "name": "Disposal of Confidential Information",
        "category": "Confidentiality",
        "checks": [
            {
                "id": "C1.2.1",
                "check": "Secure deletion procedures for confidential data",
                "scanner": "config",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Implement cryptographic erasure or certified data wiping for decommissioned storage.",
            },
        ],
    },
    # ── PI1: Processing Integrity ──
    "PI1.1": {
        "name": "Completeness and Accuracy of System Processing",
        "category": "Processing Integrity",
        "checks": [
            {
                "id": "PI1.1.1",
                "check": "Input validation implemented on all user inputs",
                "scanner": "code",
                "auto_fix": True,
                "severity": "high",
                "remediation": "Add server-side input validation for all API endpoints using a schema library.",
            },
            {
                "id": "PI1.1.2",
                "check": "Output encoding to prevent injection attacks",
                "scanner": "code",
                "auto_fix": True,
                "severity": "high",
                "remediation": "Apply context-appropriate output encoding (HTML, URL, JS) in all templates.",
            },
        ],
    },
    # ── P1: Privacy ──
    "P1.1": {
        "name": "Privacy Notice and Consent",
        "category": "Privacy",
        "checks": [
            {
                "id": "P1.1.1",
                "check": "Privacy policy published and accessible",
                "scanner": "code",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Publish a privacy policy at /privacy accessible from all pages.",
            },
        ],
    },
}
