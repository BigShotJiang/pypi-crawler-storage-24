"""HIPAA Security Rule (45 CFR Part 164 Subpart C) — technical safeguards.

Maps HIPAA Security Rule standards and implementation specifications
to concrete technical checks. Covers Administrative (164.308),
Physical (164.310), and Technical (164.312) safeguards.
"""

from __future__ import annotations

HIPAA_CONTROLS: dict = {
    # ── 164.308: Administrative Safeguards ──
    "164.308(a)(1)": {
        "name": "Security Management Process",
        "category": "Administrative Safeguards",
        "checks": [
            {
                "id": "164.308.a.1.1",
                "check": "Risk analysis conducted covering all ePHI systems",
                "scanner": "config",
                "auto_fix": False,
                "severity": "critical",
                "remediation": "Conduct comprehensive risk analysis of all systems that create, receive, maintain, or transmit ePHI.",
            },
            {
                "id": "164.308.a.1.2",
                "check": "Risk management plan documented with mitigations",
                "scanner": "config",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Document risk management plan addressing identified risks with specific mitigations.",
            },
            {
                "id": "164.308.a.1.3",
                "check": "Sanction policy for workforce members who violate security policies",
                "scanner": "config",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Create and communicate workforce sanction policy for security violations.",
            },
        ],
    },
    "164.308(a)(3)": {
        "name": "Workforce Security",
        "category": "Administrative Safeguards",
        "checks": [
            {
                "id": "164.308.a.3.1",
                "check": "Access authorisation procedures documented",
                "scanner": "config",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Document procedures for authorising access to ePHI based on job function.",
            },
            {
                "id": "164.308.a.3.2",
                "check": "Termination procedures include immediate access revocation",
                "scanner": "config",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Create termination checklist including same-day access revocation for all systems.",
            },
        ],
    },
    "164.308(a)(4)": {
        "name": "Information Access Management",
        "category": "Administrative Safeguards",
        "checks": [
            {
                "id": "164.308.a.4.1",
                "check": "Role-based access control implemented for ePHI systems",
                "scanner": "code",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Implement RBAC with minimum necessary access to ePHI.",
            },
        ],
    },
    "164.308(a)(5)": {
        "name": "Security Awareness and Training",
        "category": "Administrative Safeguards",
        "checks": [
            {
                "id": "164.308.a.5.1",
                "check": "Security awareness training completed by all workforce members",
                "scanner": "config",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Implement annual HIPAA security awareness training with completion tracking.",
            },
        ],
    },
    "164.308(a)(6)": {
        "name": "Security Incident Procedures",
        "category": "Administrative Safeguards",
        "checks": [
            {
                "id": "164.308.a.6.1",
                "check": "Security incident response plan covers ePHI breach scenarios",
                "scanner": "config",
                "auto_fix": False,
                "severity": "critical",
                "remediation": "Create incident response plan with ePHI-specific breach response procedures.",
            },
        ],
    },
    "164.308(a)(7)": {
        "name": "Contingency Plan",
        "category": "Administrative Safeguards",
        "checks": [
            {
                "id": "164.308.a.7.1",
                "check": "Data backup plan for ePHI with tested restoration",
                "scanner": "infra",
                "auto_fix": True,
                "severity": "critical",
                "remediation": "Enable automated backups for all ePHI data stores; test restoration quarterly.",
            },
            {
                "id": "164.308.a.7.2",
                "check": "Disaster recovery plan includes ePHI systems",
                "scanner": "config",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Include all ePHI systems in disaster recovery plan with RTO/RPO targets.",
            },
            {
                "id": "164.308.a.7.3",
                "check": "Emergency mode operation plan exists",
                "scanner": "config",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Document procedures for operating critical ePHI systems during emergency.",
            },
        ],
    },
    "164.308(a)(8)": {
        "name": "Evaluation",
        "category": "Administrative Safeguards",
        "checks": [
            {
                "id": "164.308.a.8.1",
                "check": "Periodic security evaluation conducted",
                "scanner": "config",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Conduct annual technical and non-technical security evaluation.",
            },
        ],
    },
    # ── 164.310: Physical Safeguards ──
    "164.310(a)(1)": {
        "name": "Facility Access Controls",
        "category": "Physical Safeguards",
        "checks": [
            {
                "id": "164.310.a.1.1",
                "check": "Cloud provider facility security certifications on file",
                "scanner": "config",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Obtain cloud provider SOC 2 and HIPAA BAA documentation.",
            },
        ],
    },
    "164.310(d)(1)": {
        "name": "Device and Media Controls",
        "category": "Physical Safeguards",
        "checks": [
            {
                "id": "164.310.d.1.1",
                "check": "Media disposal procedures for ePHI documented",
                "scanner": "config",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Document media sanitisation and disposal procedures for ePHI storage.",
            },
        ],
    },
    "164.310(d)(2)(i)": {
        "name": "Data Backup and Storage — Media Re-use",
        "category": "Physical Safeguards",
        "checks": [
            {
                "id": "164.310.d.2.i.1",
                "check": "ePHI removed from media before re-use or disposal",
                "scanner": "config",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Implement certified data wiping for storage media containing ePHI.",
            },
        ],
    },
    # ── 164.312: Technical Safeguards ──
    "164.312(a)(1)": {
        "name": "Access Control",
        "category": "Technical Safeguards",
        "checks": [
            {
                "id": "164.312.a.1.1",
                "check": "Unique user identification for all ePHI system users",
                "scanner": "code",
                "auto_fix": True,
                "severity": "critical",
                "remediation": "Ensure all users have unique IDs; no shared or generic accounts for ePHI access.",
            },
            {
                "id": "164.312.a.1.2",
                "check": "Emergency access procedure for ePHI systems",
                "scanner": "config",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Document break-glass procedures for emergency ePHI access.",
            },
            {
                "id": "164.312.a.1.3",
                "check": "Automatic logoff after inactivity period",
                "scanner": "code",
                "auto_fix": True,
                "severity": "high",
                "remediation": "Implement session timeout (15 min idle) for applications accessing ePHI.",
            },
        ],
    },
    "164.312(a)(2)(iv)": {
        "name": "Encryption and Decryption of ePHI",
        "category": "Technical Safeguards",
        "checks": [
            {
                "id": "164.312.a.2.iv.1",
                "check": "ePHI encrypted at rest using AES-256 or equivalent",
                "scanner": "infra",
                "auto_fix": True,
                "severity": "critical",
                "remediation": "Enable AES-256 encryption at rest for all ePHI data stores.",
            },
        ],
    },
    "164.312(b)": {
        "name": "Audit Controls",
        "category": "Technical Safeguards",
        "checks": [
            {
                "id": "164.312.b.1",
                "check": "Audit logging for all ePHI access (read, write, delete)",
                "scanner": "code",
                "auto_fix": True,
                "severity": "critical",
                "remediation": "Log all access to ePHI with user ID, timestamp, action, and resource.",
            },
            {
                "id": "164.312.b.2",
                "check": "Audit logs retained for minimum 6 years",
                "scanner": "infra",
                "auto_fix": True,
                "severity": "high",
                "remediation": "Configure log retention to 6 years minimum for HIPAA audit logs.",
            },
        ],
    },
    "164.312(c)(1)": {
        "name": "Integrity Controls",
        "category": "Technical Safeguards",
        "checks": [
            {
                "id": "164.312.c.1.1",
                "check": "Integrity verification for ePHI (checksums/hashes)",
                "scanner": "code",
                "auto_fix": False,
                "severity": "medium",
                "remediation": "Implement integrity checks (SHA-256 hashes) for stored ePHI data.",
            },
        ],
    },
    "164.312(d)": {
        "name": "Person or Entity Authentication",
        "category": "Technical Safeguards",
        "checks": [
            {
                "id": "164.312.d.1",
                "check": "Multi-factor authentication for ePHI system access",
                "scanner": "infra",
                "auto_fix": True,
                "severity": "critical",
                "remediation": "Enforce MFA for all users accessing systems containing ePHI.",
            },
        ],
    },
    "164.312(e)(1)": {
        "name": "Transmission Security",
        "category": "Technical Safeguards",
        "checks": [
            {
                "id": "164.312.e.1.1",
                "check": "ePHI encrypted in transit (TLS 1.2+)",
                "scanner": "infra",
                "auto_fix": True,
                "severity": "critical",
                "remediation": "Enforce TLS 1.2+ for all network transmissions of ePHI.",
            },
            {
                "id": "164.312.e.1.2",
                "check": "VPN or encrypted tunnel for remote ePHI access",
                "scanner": "infra",
                "auto_fix": False,
                "severity": "high",
                "remediation": "Require VPN or zero-trust network access for remote ePHI access.",
            },
        ],
    },
}
