"""Configuration scanner — checks for policy documents and governance artefacts.

Looks for the existence and freshness of required compliance documents:
- Security policies
- Risk registers
- Incident response plans
- Business continuity plans
- Data classification policies
- Training records
- Vendor assessments
"""

from __future__ import annotations

import json
import datetime
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass
class ConfigFinding:
    """A finding from configuration/policy scanning."""

    check_id: str
    file: str
    line: int
    detail: str
    severity: str
    auto_fixable: bool = False
    remediation: str = ""


# Expected policy documents and their search patterns
POLICY_DOCUMENTS: dict[str, dict[str, Any]] = {
    "security_policy": {
        "names": [
            "security-policy", "security_policy", "information-security-policy",
            "SECURITY", "SECURITY.md", "security.md",
        ],
        "dirs": ["docs", "policies", "compliance", "."],
        "description": "Information security policy",
    },
    "acceptable_use": {
        "names": ["acceptable-use", "acceptable_use", "aup"],
        "dirs": ["docs", "policies", "compliance"],
        "description": "Acceptable use policy",
    },
    "incident_response": {
        "names": [
            "incident-response", "incident_response", "ir-plan",
            "incident-response-plan",
        ],
        "dirs": ["docs", "policies", "compliance", "security"],
        "description": "Incident response plan",
    },
    "risk_register": {
        "names": ["risk-register", "risk_register", "risks"],
        "dirs": ["docs", "policies", "compliance", "security"],
        "description": "Risk register",
    },
    "data_classification": {
        "names": ["data-classification", "data_classification"],
        "dirs": ["docs", "policies", "compliance"],
        "description": "Data classification policy",
    },
    "bcp_dr": {
        "names": [
            "business-continuity", "disaster-recovery", "bcp", "dr-plan",
            "continuity-plan",
        ],
        "dirs": ["docs", "policies", "compliance"],
        "description": "Business continuity / disaster recovery plan",
    },
    "data_retention": {
        "names": ["data-retention", "data_retention", "retention-policy"],
        "dirs": ["docs", "policies", "compliance"],
        "description": "Data retention policy",
    },
    "privacy_policy": {
        "names": ["privacy-policy", "privacy_policy", "privacy", "PRIVACY"],
        "dirs": ["docs", "policies", "compliance", ".", "public"],
        "description": "Privacy policy",
    },
    "change_management": {
        "names": ["change-management", "change_management"],
        "dirs": ["docs", "policies", "compliance"],
        "description": "Change management process",
    },
    "vendor_assessment": {
        "names": ["vendor-assessment", "vendor_assessment", "third-party"],
        "dirs": ["docs", "policies", "compliance"],
        "description": "Vendor security assessment",
    },
    "access_control": {
        "names": ["access-control", "access_control", "rbac-policy"],
        "dirs": ["docs", "policies", "compliance"],
        "description": "Access control policy",
    },
    "training_records": {
        "names": ["training", "security-training", "awareness-training"],
        "dirs": ["docs", "policies", "compliance", "hr"],
        "description": "Security awareness training program",
    },
    "ropa": {
        "names": ["ropa", "processing-activities", "data-processing"],
        "dirs": ["docs", "policies", "compliance", "gdpr"],
        "description": "Records of processing activities (ROPA)",
    },
    "dpia": {
        "names": ["dpia", "data-protection-impact", "privacy-impact"],
        "dirs": ["docs", "policies", "compliance", "gdpr"],
        "description": "Data protection impact assessment",
    },
    "breach_notification": {
        "names": ["breach-notification", "breach_notification", "breach-procedure"],
        "dirs": ["docs", "policies", "compliance", "security"],
        "description": "Breach notification procedure",
    },
}

# Mapping from check description keywords to policy document keys
CHECK_TO_POLICY: dict[str, list[str]] = {
    "code of conduct": ["acceptable_use"],
    "acceptable use": ["acceptable_use"],
    "security governance": ["security_policy"],
    "security awareness training": ["training_records"],
    "risk assessment policy": ["risk_register"],
    "risk register": ["risk_register"],
    "fraud risk": ["risk_register"],
    "incident response": ["incident_response"],
    "incident response contacts": ["incident_response"],
    "data retention": ["data_retention"],
    "data classification": ["data_classification"],
    "secure deletion": ["data_retention"],
    "privacy policy": ["privacy_policy"],
    "vendor security": ["vendor_assessment"],
    "cyber insurance": [],  # No document to check for this
    "sla": ["bcp_dr"],
    "uptime": ["bcp_dr"],
    "backup restoration tested": [],  # operational check
    "disaster recovery": ["bcp_dr"],
    "rto": ["bcp_dr"],
    "rpo": ["bcp_dr"],
    "rollback": ["change_management"],
    "user provisioning": ["access_control"],
    "physical security": [],  # cloud provider check
    "records of processing": ["ropa"],
    "lawful basis": ["ropa"],
    "processing purposes": ["ropa"],
    "breach notification": ["breach_notification"],
    "dpia": ["dpia"],
    "data transfer": [],  # operational check
    "cloud shared responsibility": ["security_policy"],
    "business continuity": ["bcp_dr"],
    "regulatory requirements": ["security_policy"],
    "information security policy": ["security_policy"],
    "access control policy": ["access_control"],
    "threat intelligence": [],  # operational check
    "secure coding": ["security_policy"],
    "risk analysis": ["risk_register"],
    "risk management": ["risk_register"],
    "sanction policy": ["security_policy"],
    "access authorisation": ["access_control"],
    "termination procedures": ["access_control"],
    "security awareness": ["training_records"],
    "security incident": ["incident_response"],
    "contingency plan": ["bcp_dr"],
    "emergency mode": ["bcp_dr"],
    "periodic security evaluation": [],  # operational check
    "media disposal": ["data_retention"],
    "emergency access": ["incident_response"],
    "change management": ["change_management"],
    "firewall": [],  # infra check
    "security responsibilities": ["security_policy"],
    "information security": ["security_policy"],
    "penetration test": [],  # operational check
    "vulnerability scan": [],  # operational check
}


class ConfigScanner:
    """Scans for the existence and freshness of compliance configuration and policy documents."""

    def __init__(self, target_path: str | Path) -> None:
        self.target_path = Path(target_path)
        self.findings: list[ConfigFinding] = []

    def scan(self, checks: list[dict[str, Any]]) -> list[ConfigFinding]:
        """Check for required policy documents based on framework checks."""
        self.findings = []

        if not self.target_path.exists():
            return self.findings

        for check in checks:
            desc = check.get("check", "").lower()
            check_id = check.get("id", "")
            severity = check.get("severity", "medium")

            # Find matching policy documents for this check
            matched_policies: list[str] = []
            for keyword, policies in CHECK_TO_POLICY.items():
                if keyword in desc:
                    matched_policies.extend(policies)
                    break

            if not matched_policies:
                # Generic check — just note it
                self.findings.append(ConfigFinding(
                    check_id=check_id,
                    file="(governance)",
                    line=0,
                    detail=f"Manual verification required: {check.get('check', '')}",
                    severity=severity,
                    auto_fixable=False,
                    remediation=check.get("remediation", ""),
                ))
                continue

            for policy_key in set(matched_policies):
                policy = POLICY_DOCUMENTS.get(policy_key)
                if not policy:
                    continue

                found = self._find_document(policy["names"], policy["dirs"])
                if not found:
                    self.findings.append(ConfigFinding(
                        check_id=check_id,
                        file="(missing)",
                        line=0,
                        detail=f"{policy['description']} not found",
                        severity=severity,
                        auto_fixable=False,
                        remediation=check.get("remediation", f"Create {policy['description']}."),
                    ))
                else:
                    # Check freshness (should be updated within 365 days)
                    age_days = self._file_age_days(found)
                    if age_days > 365:
                        self.findings.append(ConfigFinding(
                            check_id=check_id,
                            file=str(found.relative_to(self.target_path)),
                            line=0,
                            detail=f"{policy['description']} is {age_days} days old (should be reviewed annually)",
                            severity="medium",
                            auto_fixable=False,
                            remediation=f"Review and update {policy['description']}.",
                        ))

        return self.findings

    def _find_document(self, names: list[str], dirs: list[str]) -> Path | None:
        """Search for a document by name in expected directories."""
        extensions = ["", ".md", ".pdf", ".docx", ".doc", ".txt", ".html"]
        for dir_name in dirs:
            search_dir = self.target_path / dir_name if dir_name != "." else self.target_path
            if not search_dir.exists():
                continue
            for name in names:
                for ext in extensions:
                    candidate = search_dir / f"{name}{ext}"
                    if candidate.exists():
                        return candidate
        return None

    def _file_age_days(self, path: Path) -> int:
        """Get the age of a file in days since last modification."""
        try:
            mtime = datetime.datetime.fromtimestamp(path.stat().st_mtime)
            return (datetime.datetime.now() - mtime).days
        except OSError:
            return 9999
