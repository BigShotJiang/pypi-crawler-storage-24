"""Code scanner — inspects source code for compliance issues.

Scans for:
- Hardcoded secrets (API keys, passwords, tokens)
- SQL injection patterns (string concatenation in queries)
- Missing input validation
- Insecure cryptographic usage
- Missing security headers
- Dependency vulnerability indicators
- Branch protection / CI pipeline configuration
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass
class CodeFinding:
    """A finding from code scanning."""

    check_id: str
    file: str
    line: int
    detail: str
    severity: str
    auto_fixable: bool = False
    remediation: str = ""


# Patterns for secret detection (high-precision patterns to minimise false positives)
SECRET_PATTERNS: list[tuple[str, str, str]] = [
    # (name, regex, severity)
    ("AWS Access Key", r"AKIA[0-9A-Z]{16}", "critical"),
    ("AWS Secret Key", r"""(?:aws_secret_access_key|AWS_SECRET)\s*[=:]\s*['"][A-Za-z0-9/+=]{40}['"]""", "critical"),
    ("Generic API Key assignment", r"""(?:api[_-]?key|apikey)\s*[=:]\s*['"][A-Za-z0-9_\-]{20,}['"]""", "high"),
    ("Generic Secret assignment", r"""(?:secret|password|passwd|pwd)\s*[=:]\s*['"][^'"]{8,}['"]""", "high"),
    ("Private Key block", r"-----BEGIN (?:RSA |EC |DSA )?PRIVATE KEY-----", "critical"),
    ("GitHub Token", r"gh[ps]_[A-Za-z0-9_]{36,}", "critical"),
    ("Slack Token", r"xox[bpras]-[A-Za-z0-9-]+", "critical"),
    ("JWT token", r"eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}", "high"),
    ("Azure connection string", r"DefaultEndpointsProtocol=https;AccountName=[^;]+;AccountKey=[^;]+", "critical"),
    ("Database URL with password", r"""(?:postgres|mysql|mongodb)://[^:]+:[^@]+@[^\s'"]+""", "critical"),
]

# SQL injection patterns
SQL_INJECTION_PATTERNS: list[tuple[str, str]] = [
    ("String format in SQL", r"""(?:execute|cursor\.execute|\.query)\s*\(\s*f?['"].*\{.*\}.*['"]"""),
    ("Percent format in SQL", r"""(?:execute|cursor\.execute|\.query)\s*\(\s*['"].*%s.*['"]\s*%"""),
    ("String concat in SQL", r"""(?:execute|cursor\.execute|\.query)\s*\(\s*['"].*['"]\s*\+"""),
]

# Missing security header patterns (for web frameworks)
SECURITY_HEADER_CHECKS: list[tuple[str, str, str]] = [
    ("CORS wildcard", r"""(?:cors|CORS|Access-Control-Allow-Origin).*['"]\*['"]""", "Overly permissive CORS: Access-Control-Allow-Origin: *"),
    ("Debug mode in production", r"""(?:DEBUG|debug)\s*=\s*True""", "Debug mode should be False in production"),
]

# Files to skip during scanning
SKIP_PATTERNS: set[str] = {
    ".git", "__pycache__", "node_modules", ".venv", "venv", ".env",
    "dist", "build", ".tox", ".pytest_cache", ".mypy_cache",
}

# File extensions to scan
CODE_EXTENSIONS: set[str] = {
    ".py", ".js", ".ts", ".jsx", ".tsx", ".java", ".go", ".rb",
    ".php", ".cs", ".rs", ".yaml", ".yml", ".json", ".toml",
    ".tf", ".hcl", ".sh", ".bash",
}


class CodeScanner:
    """Scans source code for compliance violations."""

    def __init__(self, target_path: str | Path) -> None:
        self.target_path = Path(target_path)
        self.findings: list[CodeFinding] = []

    def scan(self, checks: list[dict[str, Any]]) -> list[CodeFinding]:
        """Run all code checks against the target path.

        Args:
            checks: List of check definitions from a framework.
                    Each has an 'id' and 'check' description.

        Returns:
            List of CodeFinding objects.
        """
        self.findings = []

        if not self.target_path.exists():
            return self.findings

        code_files = self._collect_files()

        # Map check IDs to scanner methods
        check_runners: dict[str, Any] = {
            "secrets": self._scan_secrets,
            "sql_injection": self._scan_sql_injection,
            "security_headers": self._scan_security_headers,
            "input_validation": self._scan_input_validation,
            "dependency_scanning": self._scan_dependency_config,
            "branch_protection": self._scan_branch_protection,
            "ci_pipeline": self._scan_ci_pipeline,
            "password_policy": self._scan_password_policy,
        }

        # Determine which scan types are needed based on check descriptions
        for check in checks:
            check_desc = check.get("check", "").lower()
            check_id = check.get("id", "")

            if "hardcoded" in check_desc or "api key" in check_desc or "credential" in check_desc:
                self._scan_secrets(code_files, check_id)
            if "sql injection" in check_desc or "parameteris" in check_desc:
                self._scan_sql_injection(code_files, check_id)
            if "input validation" in check_desc:
                self._scan_input_validation(code_files, check_id)
            if "output encoding" in check_desc or "injection" in check_desc:
                self._scan_output_encoding(code_files, check_id)
            if "vulnerability scanning" in check_desc or "dependabot" in check_desc or "snyk" in check_desc:
                self._scan_dependency_config(check_id)
            if "branch protection" in check_desc or "pull request" in check_desc:
                self._scan_branch_protection(check_id)
            if "ci" in check_desc and ("pipeline" in check_desc or "testing" in check_desc or "security" in check_desc):
                self._scan_ci_pipeline(check_id)
            if "password" in check_desc and ("complex" in check_desc or "policy" in check_desc or "12 char" in check_desc):
                self._scan_password_policy(code_files, check_id)
            if "session timeout" in check_desc or "auto" in check_desc and "logoff" in check_desc:
                self._scan_session_timeout(code_files, check_id)
            if "logging" in check_desc and "auth" in check_desc:
                self._scan_logging(code_files, check_id)
            if "sast" in check_desc:
                self._scan_ci_pipeline(check_id)
            if "iac" in check_desc or "infrastructure as code" in check_desc:
                self._scan_iac_usage(check_id)
            if "consent" in check_desc and "checkbox" in check_desc:
                self._scan_consent_patterns(code_files, check_id)
            if "pan" in check_desc or "cardholder" in check_desc or "cvv" in check_desc:
                self._scan_card_data_storage(code_files, check_id)
            if "unique" in check_desc and "user" in check_desc and "id" in check_desc:
                self._scan_unique_user_ids(code_files, check_id)
            if "change management" in check_desc or "review" in check_desc and "code" in check_desc:
                self._scan_branch_protection(check_id)
            if "privacy policy" in check_desc:
                self._scan_privacy_policy(code_files, check_id)
            if "rbac" in check_desc or "role-based" in check_desc:
                self._scan_rbac(code_files, check_id)
            if "lockout" in check_desc:
                self._scan_account_lockout(code_files, check_id)
            if "audit" in check_desc and "access" in check_desc:
                self._scan_audit_logging(code_files, check_id)

        return self.findings

    def _collect_files(self) -> list[Path]:
        """Collect all scannable code files."""
        files: list[Path] = []
        if self.target_path.is_file():
            return [self.target_path]

        for path in self.target_path.rglob("*"):
            if any(skip in path.parts for skip in SKIP_PATTERNS):
                continue
            if path.is_file() and path.suffix in CODE_EXTENSIONS:
                files.append(path)
        return files

    def _read_file_lines(self, path: Path) -> list[str]:
        """Read file lines, handling encoding errors gracefully."""
        try:
            return path.read_text(encoding="utf-8", errors="replace").splitlines()
        except (OSError, PermissionError):
            return []

    def _scan_secrets(self, files: list[Path], check_id: str) -> None:
        """Scan for hardcoded secrets and credentials."""
        for fpath in files:
            # Skip test files and example files for secret scanning
            if "test" in fpath.name.lower() or "example" in fpath.name.lower() or "fixture" in fpath.name.lower():
                continue
            lines = self._read_file_lines(fpath)
            for line_num, line in enumerate(lines, 1):
                # Skip comments
                stripped = line.strip()
                if stripped.startswith("#") or stripped.startswith("//") or stripped.startswith("*"):
                    continue
                for name, pattern, severity in SECRET_PATTERNS:
                    if re.search(pattern, line):
                        rel_path = str(fpath.relative_to(self.target_path))
                        self.findings.append(CodeFinding(
                            check_id=check_id,
                            file=rel_path,
                            line=line_num,
                            detail=f"{name} detected in source code",
                            severity=severity,
                            auto_fixable=True,
                            remediation=f"Move {name.lower()} to environment variable or secrets manager.",
                        ))

    def _scan_sql_injection(self, files: list[Path], check_id: str) -> None:
        """Scan for SQL injection vulnerabilities."""
        for fpath in files:
            if fpath.suffix not in {".py", ".js", ".ts", ".java", ".php", ".rb", ".go"}:
                continue
            lines = self._read_file_lines(fpath)
            for line_num, line in enumerate(lines, 1):
                for name, pattern in SQL_INJECTION_PATTERNS:
                    if re.search(pattern, line, re.IGNORECASE):
                        rel_path = str(fpath.relative_to(self.target_path))
                        self.findings.append(CodeFinding(
                            check_id=check_id,
                            file=rel_path,
                            line=line_num,
                            detail=f"Potential SQL injection: {name}",
                            severity="critical",
                            auto_fixable=True,
                            remediation="Use parameterised queries instead of string formatting/concatenation.",
                        ))

    def _scan_security_headers(self, files: list[Path], check_id: str) -> None:
        """Scan for security header issues."""
        for fpath in files:
            lines = self._read_file_lines(fpath)
            for line_num, line in enumerate(lines, 1):
                for name, pattern, message in SECURITY_HEADER_CHECKS:
                    if re.search(pattern, line, re.IGNORECASE):
                        rel_path = str(fpath.relative_to(self.target_path))
                        self.findings.append(CodeFinding(
                            check_id=check_id,
                            file=rel_path,
                            line=line_num,
                            detail=message,
                            severity="high",
                            auto_fixable=True,
                            remediation=f"Fix {name}: restrict to specific origins/values.",
                        ))

    def _scan_input_validation(self, files: list[Path], check_id: str) -> None:
        """Check for missing input validation on API endpoints."""
        for fpath in files:
            if fpath.suffix not in {".py", ".js", ".ts"}:
                continue
            content = fpath.read_text(encoding="utf-8", errors="replace") if fpath.exists() else ""
            # Look for route handlers without validation
            route_patterns = [
                r"@app\.(post|put|patch)\(",
                r"@router\.(post|put|patch)\(",
                r"app\.(post|put|patch)\(",
                r"router\.(post|put|patch)\(",
            ]
            has_routes = any(re.search(p, content) for p in route_patterns)
            if has_routes:
                validation_patterns = [
                    r"(?:pydantic|BaseModel|Schema|validator|validate|Joi|zod|yup|class-validator)",
                ]
                has_validation = any(re.search(p, content) for p in validation_patterns)
                if not has_validation:
                    rel_path = str(fpath.relative_to(self.target_path))
                    self.findings.append(CodeFinding(
                        check_id=check_id,
                        file=rel_path,
                        line=1,
                        detail="API route handlers found without input validation library",
                        severity="high",
                        auto_fixable=True,
                        remediation="Add input validation using Pydantic (Python), Zod/Joi (JS/TS).",
                    ))

    def _scan_output_encoding(self, files: list[Path], check_id: str) -> None:
        """Scan for missing output encoding (XSS prevention)."""
        for fpath in files:
            if fpath.suffix not in {".py", ".js", ".ts", ".jsx", ".tsx", ".html"}:
                continue
            lines = self._read_file_lines(fpath)
            for line_num, line in enumerate(lines, 1):
                # Look for dangerous innerHTML usage
                if "innerHTML" in line or "dangerouslySetInnerHTML" in line:
                    rel_path = str(fpath.relative_to(self.target_path))
                    self.findings.append(CodeFinding(
                        check_id=check_id,
                        file=rel_path,
                        line=line_num,
                        detail="Unsafe innerHTML / dangerouslySetInnerHTML usage (XSS risk)",
                        severity="high",
                        auto_fixable=True,
                        remediation="Use textContent or sanitise HTML with DOMPurify before rendering.",
                    ))

    def _scan_dependency_config(self, check_id: str) -> None:
        """Check if dependency vulnerability scanning is configured."""
        dependabot_paths = [
            self.target_path / ".github" / "dependabot.yml",
            self.target_path / ".github" / "dependabot.yaml",
        ]
        snyk_path = self.target_path / ".snyk"
        renovate_paths = [
            self.target_path / "renovate.json",
            self.target_path / ".renovaterc",
            self.target_path / ".renovaterc.json",
        ]

        has_dep_scanning = (
            any(p.exists() for p in dependabot_paths)
            or snyk_path.exists()
            or any(p.exists() for p in renovate_paths)
        )

        if not has_dep_scanning:
            self.findings.append(CodeFinding(
                check_id=check_id,
                file="(project root)",
                line=0,
                detail="No dependency vulnerability scanning configured (Dependabot/Snyk/Renovate)",
                severity="high",
                auto_fixable=True,
                remediation="Add .github/dependabot.yml to enable automated dependency scanning.",
            ))

    def _scan_branch_protection(self, check_id: str) -> None:
        """Check for branch protection indicators."""
        codeowners = self.target_path / ".github" / "CODEOWNERS"
        if not codeowners.exists():
            self.findings.append(CodeFinding(
                check_id=check_id,
                file=".github/CODEOWNERS",
                line=0,
                detail="CODEOWNERS file not found — code review enforcement may be weak",
                severity="medium",
                auto_fixable=True,
                remediation="Create .github/CODEOWNERS and enable branch protection rules.",
            ))

    def _scan_ci_pipeline(self, check_id: str) -> None:
        """Check for CI/CD pipeline with security scanning."""
        ci_paths = [
            self.target_path / ".github" / "workflows",
            self.target_path / ".gitlab-ci.yml",
            self.target_path / "Jenkinsfile",
            self.target_path / ".circleci" / "config.yml",
            self.target_path / "azure-pipelines.yml",
        ]
        has_ci = any(p.exists() for p in ci_paths)
        if not has_ci:
            self.findings.append(CodeFinding(
                check_id=check_id,
                file="(project root)",
                line=0,
                detail="No CI/CD pipeline configuration found",
                severity="high",
                auto_fixable=True,
                remediation="Add CI/CD pipeline (GitHub Actions, GitLab CI) with test and security scan stages.",
            ))
            return

        # Check if CI has security scanning
        workflows_dir = self.target_path / ".github" / "workflows"
        if workflows_dir.exists():
            all_content = ""
            for wf in workflows_dir.glob("*.yml"):
                all_content += wf.read_text(encoding="utf-8", errors="replace")
            for wf in workflows_dir.glob("*.yaml"):
                all_content += wf.read_text(encoding="utf-8", errors="replace")

            security_indicators = ["codeql", "semgrep", "snyk", "trivy", "bandit", "safety", "sonar"]
            has_security = any(ind in all_content.lower() for ind in security_indicators)
            if not has_security:
                self.findings.append(CodeFinding(
                    check_id=check_id,
                    file=".github/workflows/",
                    line=0,
                    detail="CI pipeline exists but no security scanning step detected",
                    severity="high",
                    auto_fixable=True,
                    remediation="Add SAST step (CodeQL, Semgrep, Bandit) to CI workflow.",
                ))

    def _scan_password_policy(self, files: list[Path], check_id: str) -> None:
        """Check for password policy enforcement in code."""
        found_password_validation = False
        for fpath in files:
            if fpath.suffix not in {".py", ".js", ".ts"}:
                continue
            content = fpath.read_text(encoding="utf-8", errors="replace") if fpath.exists() else ""
            if re.search(r"(?:password|passwd).*(?:len|length|min).*(?:1[2-9]|[2-9]\d)", content, re.IGNORECASE):
                found_password_validation = True
                break
            if re.search(r"(?:MIN_PASSWORD_LENGTH|minLength|min_length).*(?:1[2-9]|[2-9]\d)", content):
                found_password_validation = True
                break

        if not found_password_validation:
            self.findings.append(CodeFinding(
                check_id=check_id,
                file="(project-wide)",
                line=0,
                detail="No password length enforcement (min 12 chars) detected in code",
                severity="high",
                auto_fixable=True,
                remediation="Implement password validation: minimum 12 characters with complexity.",
            ))

    def _scan_session_timeout(self, files: list[Path], check_id: str) -> None:
        """Check for session timeout configuration."""
        found_timeout = False
        for fpath in files:
            content = fpath.read_text(encoding="utf-8", errors="replace") if fpath.exists() else ""
            if re.search(r"(?:session.*timeout|SESSION_TIMEOUT|idle.*timeout|token.*expir)", content, re.IGNORECASE):
                found_timeout = True
                break

        if not found_timeout:
            self.findings.append(CodeFinding(
                check_id=check_id,
                file="(project-wide)",
                line=0,
                detail="No session timeout configuration detected",
                severity="medium",
                auto_fixable=True,
                remediation="Set session idle timeout to 30 minutes or less.",
            ))

    def _scan_logging(self, files: list[Path], check_id: str) -> None:
        """Check for security event logging."""
        found_logging = False
        for fpath in files:
            if fpath.suffix not in {".py", ".js", ".ts"}:
                continue
            content = fpath.read_text(encoding="utf-8", errors="replace") if fpath.exists() else ""
            if re.search(r"(?:logger|logging|log)\.\w+.*(?:login|auth|access|permission)", content, re.IGNORECASE):
                found_logging = True
                break

        if not found_logging:
            self.findings.append(CodeFinding(
                check_id=check_id,
                file="(project-wide)",
                line=0,
                detail="No authentication/access event logging detected",
                severity="high",
                auto_fixable=True,
                remediation="Add structured logging for login, logout, permission changes, and data access.",
            ))

    def _scan_iac_usage(self, check_id: str) -> None:
        """Check for Infrastructure as Code usage."""
        iac_indicators = [
            self.target_path / "Pulumi.yaml",
            self.target_path / "main.tf",
            self.target_path / "terraform",
            self.target_path / "cloudformation",
            self.target_path / "cdk.json",
            self.target_path / "infra" / "Pulumi.yaml",
            self.target_path / "infra" / "main.tf",
        ]
        if not any(p.exists() for p in iac_indicators):
            self.findings.append(CodeFinding(
                check_id=check_id,
                file="(project root)",
                line=0,
                detail="No Infrastructure as Code configuration found",
                severity="medium",
                auto_fixable=False,
                remediation="Adopt Terraform, Pulumi, or CDK for infrastructure management.",
            ))

    def _scan_consent_patterns(self, files: list[Path], check_id: str) -> None:
        """Check for GDPR consent implementation."""
        for fpath in files:
            if fpath.suffix not in {".html", ".jsx", ".tsx", ".js", ".ts", ".vue"}:
                continue
            lines = self._read_file_lines(fpath)
            for line_num, line in enumerate(lines, 1):
                if re.search(r'checked\s*=\s*["\']?true|defaultChecked\s*=\s*\{true\}', line, re.IGNORECASE):
                    if re.search(r"consent|gdpr|privacy|agree|terms", line, re.IGNORECASE):
                        rel_path = str(fpath.relative_to(self.target_path))
                        self.findings.append(CodeFinding(
                            check_id=check_id,
                            file=rel_path,
                            line=line_num,
                            detail="Pre-ticked consent checkbox violates GDPR Art.7",
                            severity="high",
                            auto_fixable=True,
                            remediation="Set consent checkbox default to unchecked (checked=false).",
                        ))

    def _scan_card_data_storage(self, files: list[Path], check_id: str) -> None:
        """Scan for potential unencrypted cardholder data storage."""
        for fpath in files:
            if fpath.suffix not in {".py", ".js", ".ts", ".java", ".php", ".rb"}:
                continue
            lines = self._read_file_lines(fpath)
            for line_num, line in enumerate(lines, 1):
                if re.search(r"(?:card_number|pan|credit_card|cc_num)", line, re.IGNORECASE):
                    if not re.search(r"(?:encrypt|hash|mask|truncat|token)", line, re.IGNORECASE):
                        rel_path = str(fpath.relative_to(self.target_path))
                        self.findings.append(CodeFinding(
                            check_id=check_id,
                            file=rel_path,
                            line=line_num,
                            detail="Potential unencrypted cardholder data storage",
                            severity="critical",
                            auto_fixable=True,
                            remediation="Encrypt, hash, or tokenise cardholder data before storage.",
                        ))

    def _scan_unique_user_ids(self, files: list[Path], check_id: str) -> None:
        """Check for shared/generic account patterns."""
        for fpath in files:
            if fpath.suffix not in {".py", ".js", ".ts", ".yaml", ".yml", ".json"}:
                continue
            lines = self._read_file_lines(fpath)
            for line_num, line in enumerate(lines, 1):
                if re.search(r"""['"](?:admin|root|shared|generic|service_user)['"]""", line, re.IGNORECASE):
                    if re.search(r"(?:user|login|account|credential)", line, re.IGNORECASE):
                        rel_path = str(fpath.relative_to(self.target_path))
                        self.findings.append(CodeFinding(
                            check_id=check_id,
                            file=rel_path,
                            line=line_num,
                            detail="Generic/shared account name detected — each user needs unique ID",
                            severity="high",
                            auto_fixable=False,
                            remediation="Replace shared accounts with unique user identifiers.",
                        ))

    def _scan_privacy_policy(self, files: list[Path], check_id: str) -> None:
        """Check for privacy policy page."""
        found_privacy = False
        for fpath in files:
            if "privacy" in fpath.name.lower():
                found_privacy = True
                break
            if fpath.suffix in {".html", ".jsx", ".tsx"}:
                content = fpath.read_text(encoding="utf-8", errors="replace") if fpath.exists() else ""
                if re.search(r"(?:privacy.policy|/privacy)", content, re.IGNORECASE):
                    found_privacy = True
                    break

        if not found_privacy:
            self.findings.append(CodeFinding(
                check_id=check_id,
                file="(project-wide)",
                line=0,
                detail="No privacy policy page or link found",
                severity="medium",
                auto_fixable=False,
                remediation="Create a privacy policy page at /privacy accessible from all pages.",
            ))

    def _scan_rbac(self, files: list[Path], check_id: str) -> None:
        """Check for RBAC implementation."""
        found_rbac = False
        for fpath in files:
            if fpath.suffix not in {".py", ".js", ".ts"}:
                continue
            content = fpath.read_text(encoding="utf-8", errors="replace") if fpath.exists() else ""
            if re.search(r"(?:role|permission|rbac|authorize|has_permission|@require_role|@roles_required)", content, re.IGNORECASE):
                found_rbac = True
                break

        if not found_rbac:
            self.findings.append(CodeFinding(
                check_id=check_id,
                file="(project-wide)",
                line=0,
                detail="No role-based access control (RBAC) implementation detected",
                severity="high",
                auto_fixable=False,
                remediation="Implement RBAC with defined roles and permission checks on endpoints.",
            ))

    def _scan_account_lockout(self, files: list[Path], check_id: str) -> None:
        """Check for account lockout implementation."""
        found_lockout = False
        for fpath in files:
            if fpath.suffix not in {".py", ".js", ".ts"}:
                continue
            content = fpath.read_text(encoding="utf-8", errors="replace") if fpath.exists() else ""
            if re.search(r"(?:lockout|failed_attempts|max_attempts|account_lock|rate.?limit.*login)", content, re.IGNORECASE):
                found_lockout = True
                break

        if not found_lockout:
            self.findings.append(CodeFinding(
                check_id=check_id,
                file="(project-wide)",
                line=0,
                detail="No account lockout mechanism detected",
                severity="high",
                auto_fixable=True,
                remediation="Implement account lockout after 5-10 failed login attempts.",
            ))

    def _scan_audit_logging(self, files: list[Path], check_id: str) -> None:
        """Check for audit trail logging of data access."""
        found_audit = False
        for fpath in files:
            if fpath.suffix not in {".py", ".js", ".ts"}:
                continue
            content = fpath.read_text(encoding="utf-8", errors="replace") if fpath.exists() else ""
            if re.search(r"(?:audit.?log|audit.?trail|access.?log)", content, re.IGNORECASE):
                found_audit = True
                break

        if not found_audit:
            self.findings.append(CodeFinding(
                check_id=check_id,
                file="(project-wide)",
                line=0,
                detail="No audit trail / access logging detected",
                severity="high",
                auto_fixable=True,
                remediation="Implement audit logging for all data access with user, timestamp, action.",
            ))
