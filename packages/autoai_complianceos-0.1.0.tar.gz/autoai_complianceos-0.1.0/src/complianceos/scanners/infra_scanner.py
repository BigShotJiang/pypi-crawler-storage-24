"""Infrastructure scanner — inspects cloud infrastructure configuration.

Scans Terraform, Pulumi, CloudFormation, Docker, and Kubernetes configs for:
- Public storage buckets/containers
- Missing encryption at rest
- Missing TLS enforcement
- Overly permissive security groups
- Missing backup configuration
- Missing WAF/DDoS protection
- Missing logging configuration
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass
class InfraFinding:
    """A finding from infrastructure scanning."""

    check_id: str
    file: str
    line: int
    detail: str
    severity: str
    auto_fixable: bool = False
    remediation: str = ""


# Terraform patterns
TF_PUBLIC_BUCKET = re.compile(r"""acl\s*=\s*['"]public-read""", re.IGNORECASE)
TF_PUBLIC_BLOB = re.compile(r"""container_access_type\s*=\s*['"](?:blob|container)['"]""", re.IGNORECASE)
TF_ALLOW_ALL_INBOUND = re.compile(r"""(?:ingress|inbound).*0\.0\.0\.0/0""", re.IGNORECASE)
TF_HTTP_ONLY = re.compile(r"""(?:protocol|scheme)\s*=\s*['"]http['"]""", re.IGNORECASE)
TF_TLS_OLD = re.compile(r"""(?:min_tls_version|minimum_tls_version)\s*=\s*['"](?:TLS1_0|TLS1_1|1\.0|1\.1)['"]""", re.IGNORECASE)
TF_NO_ENCRYPTION = re.compile(r"""(?:encryption_enabled|encrypted|server_side_encryption)\s*=\s*false""", re.IGNORECASE)
TF_WILDCARD_IAM = re.compile(r"""(?:actions?|effect)\s*[:=]\s*['"]\*['"]""", re.IGNORECASE)

# Docker patterns
DOCKER_ROOT = re.compile(r"^\s*USER\s+root\s*$", re.MULTILINE)
DOCKER_LATEST = re.compile(r"^FROM\s+\S+:latest", re.MULTILINE)
DOCKER_NO_USER = "USER"

# Kubernetes patterns
K8S_PRIVILEGED = re.compile(r"privileged:\s*true", re.IGNORECASE)
K8S_ROOT = re.compile(r"runAsUser:\s*0", re.IGNORECASE)
K8S_NO_LIMITS = "resources"

INFRA_EXTENSIONS = {".tf", ".hcl", ".yaml", ".yml", ".json", ".bicep", ".template"}
CONTAINER_FILES = {"Dockerfile", "docker-compose.yml", "docker-compose.yaml"}
K8S_INDICATORS = {"deployment", "service", "ingress", "statefulset", "daemonset"}


class InfraScanner:
    """Scans infrastructure configuration for compliance issues."""

    def __init__(self, target_path: str | Path) -> None:
        self.target_path = Path(target_path)
        self.findings: list[InfraFinding] = []

    def scan(self, checks: list[dict[str, Any]]) -> list[InfraFinding]:
        """Run infrastructure checks against configuration files."""
        self.findings = []

        if not self.target_path.exists():
            return self.findings

        infra_files = self._collect_infra_files()
        docker_files = self._collect_docker_files()
        k8s_files = self._collect_k8s_files()

        for check in checks:
            desc = check.get("check", "").lower()
            check_id = check.get("id", "")

            if "public" in desc and ("s3" in desc or "blob" in desc or "bucket" in desc or "storage" in desc):
                self._scan_public_storage(infra_files, check_id)
            if "encryption" in desc and "rest" in desc:
                self._scan_encryption_at_rest(infra_files, check_id)
            if "tls" in desc or "transit" in desc:
                self._scan_tls(infra_files, check_id)
            if "mfa" in desc:
                self._check_mfa_config(infra_files, check_id)
            if "backup" in desc:
                self._scan_backups(infra_files, check_id)
            if "waf" in desc:
                self._scan_waf(infra_files, check_id)
            if "ddos" in desc:
                self._scan_ddos(infra_files, check_id)
            if "logging" in desc or "audit" in desc and "log" in desc:
                self._scan_logging(infra_files, check_id)
            if "network" in desc and ("segment" in desc or "security group" in desc or "nsg" in desc):
                self._scan_network_security(infra_files, check_id)
            if "least privilege" in desc or "wildcard" in desc or "iam" in desc:
                self._scan_iam_policies(infra_files, check_id)
            if "inbound" in desc or "port" in desc:
                self._scan_open_ports(infra_files, check_id)
            if "retention" in desc and "log" in desc:
                self._scan_log_retention(infra_files, check_id)
            if "immutable" in desc or "tamper" in desc:
                self._scan_log_immutability(infra_files, check_id)
            if "data residency" in desc or "region" in desc:
                self._scan_data_residency(infra_files, check_id)
            if "certificate" in desc or "self-signed" in desc:
                self._scan_certificates(infra_files, check_id)
            if "unnecessary" in desc and "service" in desc:
                self._scan_unnecessary_services(infra_files, docker_files, check_id)
            if "file integrity" in desc or "fim" in desc:
                self._scan_fim(infra_files, check_id)

            # Docker-specific
            if docker_files:
                if "container" in desc and "scan" in desc:
                    self._scan_docker_security(docker_files, check_id)

        return self.findings

    def _collect_infra_files(self) -> list[Path]:
        files: list[Path] = []
        for path in self.target_path.rglob("*"):
            if any(s in path.parts for s in {".git", "node_modules", "__pycache__", "venv"}):
                continue
            if path.is_file() and path.suffix in INFRA_EXTENSIONS:
                files.append(path)
        return files

    def _collect_docker_files(self) -> list[Path]:
        files: list[Path] = []
        for path in self.target_path.rglob("*"):
            if any(s in path.parts for s in {".git", "node_modules", "__pycache__", "venv"}):
                continue
            if path.is_file() and path.name in CONTAINER_FILES:
                files.append(path)
        return files

    def _collect_k8s_files(self) -> list[Path]:
        files: list[Path] = []
        for path in self.target_path.rglob("*.yaml"):
            if any(s in path.parts for s in {".git", "node_modules", "__pycache__", "venv"}):
                continue
            try:
                content = path.read_text(encoding="utf-8", errors="replace")[:500].lower()
                if any(ind in content for ind in K8S_INDICATORS):
                    files.append(path)
            except (OSError, PermissionError):
                continue
        return files

    def _read_lines(self, path: Path) -> list[str]:
        try:
            return path.read_text(encoding="utf-8", errors="replace").splitlines()
        except (OSError, PermissionError):
            return []

    def _scan_public_storage(self, files: list[Path], check_id: str) -> None:
        for fpath in files:
            lines = self._read_lines(fpath)
            for line_num, line in enumerate(lines, 1):
                if TF_PUBLIC_BUCKET.search(line) or TF_PUBLIC_BLOB.search(line):
                    rel = str(fpath.relative_to(self.target_path))
                    self.findings.append(InfraFinding(
                        check_id=check_id, file=rel, line=line_num,
                        detail="Public access configured on storage bucket/container",
                        severity="critical", auto_fixable=True,
                        remediation="Set storage container to private access level.",
                    ))

    def _scan_encryption_at_rest(self, files: list[Path], check_id: str) -> None:
        for fpath in files:
            lines = self._read_lines(fpath)
            for line_num, line in enumerate(lines, 1):
                if TF_NO_ENCRYPTION.search(line):
                    rel = str(fpath.relative_to(self.target_path))
                    self.findings.append(InfraFinding(
                        check_id=check_id, file=rel, line=line_num,
                        detail="Encryption at rest is explicitly disabled",
                        severity="critical", auto_fixable=True,
                        remediation="Set encryption_enabled = true or server_side_encryption = true.",
                    ))

    def _scan_tls(self, files: list[Path], check_id: str) -> None:
        for fpath in files:
            lines = self._read_lines(fpath)
            for line_num, line in enumerate(lines, 1):
                if TF_TLS_OLD.search(line):
                    rel = str(fpath.relative_to(self.target_path))
                    self.findings.append(InfraFinding(
                        check_id=check_id, file=rel, line=line_num,
                        detail="TLS version below 1.2 configured",
                        severity="critical", auto_fixable=True,
                        remediation="Set minimum TLS version to 1.2.",
                    ))
                if TF_HTTP_ONLY.search(line) and "redirect" not in line.lower():
                    rel = str(fpath.relative_to(self.target_path))
                    self.findings.append(InfraFinding(
                        check_id=check_id, file=rel, line=line_num,
                        detail="HTTP (non-TLS) protocol configured",
                        severity="high", auto_fixable=True,
                        remediation="Use HTTPS/TLS for all connections.",
                    ))

    def _check_mfa_config(self, files: list[Path], check_id: str) -> None:
        # Check for MFA-related configuration in IaC
        found_mfa = False
        for fpath in files:
            content = fpath.read_text(encoding="utf-8", errors="replace") if fpath.exists() else ""
            if re.search(r"(?:mfa|multi.?factor|conditional.?access|2fa|two.?factor)", content, re.IGNORECASE):
                found_mfa = True
                break

        if not found_mfa and files:
            self.findings.append(InfraFinding(
                check_id=check_id, file="(infrastructure)",
                line=0,
                detail="No MFA configuration found in infrastructure code",
                severity="critical", auto_fixable=True,
                remediation="Configure MFA in identity provider (Azure AD Conditional Access, AWS IAM MFA).",
            ))

    def _scan_backups(self, files: list[Path], check_id: str) -> None:
        found_backup = False
        for fpath in files:
            content = fpath.read_text(encoding="utf-8", errors="replace") if fpath.exists() else ""
            if re.search(r"(?:backup|geo_redundant|point_in_time_restore|pitr)", content, re.IGNORECASE):
                found_backup = True
                break

        if not found_backup and files:
            self.findings.append(InfraFinding(
                check_id=check_id, file="(infrastructure)",
                line=0,
                detail="No backup configuration found in infrastructure code",
                severity="critical", auto_fixable=True,
                remediation="Enable automated backups for all databases and critical data stores.",
            ))

    def _scan_waf(self, files: list[Path], check_id: str) -> None:
        found_waf = False
        for fpath in files:
            content = fpath.read_text(encoding="utf-8", errors="replace") if fpath.exists() else ""
            if re.search(r"(?:waf|web.?application.?firewall|front.?door|cloudflare)", content, re.IGNORECASE):
                found_waf = True
                break

        if not found_waf and files:
            self.findings.append(InfraFinding(
                check_id=check_id, file="(infrastructure)",
                line=0,
                detail="No WAF configuration found",
                severity="high", auto_fixable=True,
                remediation="Deploy WAF on all public-facing endpoints.",
            ))

    def _scan_ddos(self, files: list[Path], check_id: str) -> None:
        found_ddos = False
        for fpath in files:
            content = fpath.read_text(encoding="utf-8", errors="replace") if fpath.exists() else ""
            if re.search(r"(?:ddos|shield|protection_plan)", content, re.IGNORECASE):
                found_ddos = True
                break

        if not found_ddos and files:
            self.findings.append(InfraFinding(
                check_id=check_id, file="(infrastructure)",
                line=0,
                detail="No DDoS protection configured",
                severity="high", auto_fixable=True,
                remediation="Enable DDoS protection (Azure DDoS Protection, AWS Shield).",
            ))

    def _scan_logging(self, files: list[Path], check_id: str) -> None:
        found_logging = False
        for fpath in files:
            content = fpath.read_text(encoding="utf-8", errors="replace") if fpath.exists() else ""
            if re.search(r"(?:diagnostic_setting|cloudwatch|log_analytics|logging|audit)", content, re.IGNORECASE):
                found_logging = True
                break

        if not found_logging and files:
            self.findings.append(InfraFinding(
                check_id=check_id, file="(infrastructure)",
                line=0,
                detail="No centralized logging configuration found",
                severity="high", auto_fixable=True,
                remediation="Configure centralized logging (Azure Monitor, CloudWatch, Datadog).",
            ))

    def _scan_network_security(self, files: list[Path], check_id: str) -> None:
        for fpath in files:
            lines = self._read_lines(fpath)
            for line_num, line in enumerate(lines, 1):
                if TF_ALLOW_ALL_INBOUND.search(line):
                    rel = str(fpath.relative_to(self.target_path))
                    self.findings.append(InfraFinding(
                        check_id=check_id, file=rel, line=line_num,
                        detail="Inbound rule allows traffic from 0.0.0.0/0 (entire internet)",
                        severity="high", auto_fixable=True,
                        remediation="Restrict inbound rules to specific IP ranges or CIDR blocks.",
                    ))

    def _scan_iam_policies(self, files: list[Path], check_id: str) -> None:
        for fpath in files:
            lines = self._read_lines(fpath)
            for line_num, line in enumerate(lines, 1):
                if TF_WILDCARD_IAM.search(line):
                    rel = str(fpath.relative_to(self.target_path))
                    self.findings.append(InfraFinding(
                        check_id=check_id, file=rel, line=line_num,
                        detail="Wildcard (*) permission in IAM policy — violates least privilege",
                        severity="high", auto_fixable=False,
                        remediation="Replace wildcard with specific actions required for the role.",
                    ))

    def _scan_open_ports(self, files: list[Path], check_id: str) -> None:
        # Same as network security but specifically for port rules
        self._scan_network_security(files, check_id)

    def _scan_log_retention(self, files: list[Path], check_id: str) -> None:
        found_retention = False
        for fpath in files:
            content = fpath.read_text(encoding="utf-8", errors="replace") if fpath.exists() else ""
            if re.search(r"(?:retention|retention_in_days|retention_policy)", content, re.IGNORECASE):
                found_retention = True
                break

        if not found_retention and files:
            self.findings.append(InfraFinding(
                check_id=check_id, file="(infrastructure)",
                line=0,
                detail="No log retention policy configured in infrastructure",
                severity="high", auto_fixable=True,
                remediation="Configure log retention (90 days minimum, 6 years for HIPAA).",
            ))

    def _scan_log_immutability(self, files: list[Path], check_id: str) -> None:
        found_immutable = False
        for fpath in files:
            content = fpath.read_text(encoding="utf-8", errors="replace") if fpath.exists() else ""
            if re.search(r"(?:immutable|worm|write_once|object_lock)", content, re.IGNORECASE):
                found_immutable = True
                break

        if not found_immutable and files:
            self.findings.append(InfraFinding(
                check_id=check_id, file="(infrastructure)",
                line=0,
                detail="No immutable/tamper-proof log storage configured",
                severity="medium", auto_fixable=False,
                remediation="Enable immutable storage or WORM policy for audit logs.",
            ))

    def _scan_data_residency(self, files: list[Path], check_id: str) -> None:
        for fpath in files:
            lines = self._read_lines(fpath)
            for line_num, line in enumerate(lines, 1):
                # Check for US regions when EU residency might be expected
                if re.search(r"(?:location|region)\s*=\s*['\"](?:us-|eastus|westus)", line, re.IGNORECASE):
                    rel = str(fpath.relative_to(self.target_path))
                    self.findings.append(InfraFinding(
                        check_id=check_id, file=rel, line=line_num,
                        detail="US region configured — verify GDPR data residency compliance",
                        severity="high", auto_fixable=False,
                        remediation="Verify data residency requirements; use EU regions for EU personal data.",
                    ))

    def _scan_certificates(self, files: list[Path], check_id: str) -> None:
        for fpath in files:
            lines = self._read_lines(fpath)
            for line_num, line in enumerate(lines, 1):
                if re.search(r"self.?signed|verify\s*=\s*false|insecure.?skip.?verify", line, re.IGNORECASE):
                    rel = str(fpath.relative_to(self.target_path))
                    self.findings.append(InfraFinding(
                        check_id=check_id, file=rel, line=line_num,
                        detail="Self-signed certificate or certificate verification disabled",
                        severity="high", auto_fixable=True,
                        remediation="Use CA-signed certificates; enable certificate verification.",
                    ))

    def _scan_unnecessary_services(self, infra_files: list[Path], docker_files: list[Path], check_id: str) -> None:
        for fpath in docker_files:
            content = fpath.read_text(encoding="utf-8", errors="replace") if fpath.exists() else ""
            # Check for SSH in containers (usually unnecessary)
            if re.search(r"(?:openssh|sshd|22:22)", content, re.IGNORECASE):
                rel = str(fpath.relative_to(self.target_path))
                self.findings.append(InfraFinding(
                    check_id=check_id, file=rel, line=0,
                    detail="SSH service exposed in container — typically unnecessary",
                    severity="medium", auto_fixable=True,
                    remediation="Remove SSH from containers; use `docker exec` or kubectl for access.",
                ))

    def _scan_fim(self, files: list[Path], check_id: str) -> None:
        found_fim = False
        for fpath in files:
            content = fpath.read_text(encoding="utf-8", errors="replace") if fpath.exists() else ""
            if re.search(r"(?:file.?integrity|tripwire|aide|ossec|wazuh|falco)", content, re.IGNORECASE):
                found_fim = True
                break

        if not found_fim and files:
            self.findings.append(InfraFinding(
                check_id=check_id, file="(infrastructure)",
                line=0,
                detail="No file integrity monitoring (FIM) configured",
                severity="high", auto_fixable=True,
                remediation="Deploy FIM solution (OSSEC, Wazuh, Falco) on critical systems.",
            ))

    def _scan_docker_security(self, docker_files: list[Path], check_id: str) -> None:
        for fpath in docker_files:
            if fpath.name != "Dockerfile":
                continue
            content = fpath.read_text(encoding="utf-8", errors="replace") if fpath.exists() else ""
            lines = content.splitlines()

            # Check for :latest tag
            if DOCKER_LATEST.search(content):
                self.findings.append(InfraFinding(
                    check_id=check_id,
                    file=str(fpath.relative_to(self.target_path)),
                    line=1,
                    detail="Dockerfile uses :latest tag — pin to specific version for reproducibility",
                    severity="medium", auto_fixable=True,
                    remediation="Pin base image to specific version tag.",
                ))

            # Check for running as root
            has_user = False
            for line_num, line in enumerate(lines, 1):
                if line.strip().startswith("USER") and "root" not in line.lower():
                    has_user = True
                    break

            if not has_user and lines:
                self.findings.append(InfraFinding(
                    check_id=check_id,
                    file=str(fpath.relative_to(self.target_path)),
                    line=len(lines),
                    detail="Dockerfile runs as root (no non-root USER directive)",
                    severity="high", auto_fixable=True,
                    remediation="Add USER directive with non-root user.",
                ))
