"""Scanners that inspect code, infrastructure, configuration, and APIs."""

from __future__ import annotations

from .code_scanner import CodeScanner
from .infra_scanner import InfraScanner
from .config_scanner import ConfigScanner
from .api_scanner import APIScanner

SCANNERS = {
    "code": CodeScanner,
    "infra": InfraScanner,
    "config": ConfigScanner,
    "api": APIScanner,
}

__all__ = ["CodeScanner", "InfraScanner", "ConfigScanner", "APIScanner", "SCANNERS"]
