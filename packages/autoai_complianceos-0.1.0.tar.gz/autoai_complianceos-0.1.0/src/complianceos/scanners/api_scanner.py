"""API scanner — inspects API endpoints for compliance issues.

Checks:
- Authentication enforcement
- CORS configuration
- Rate limiting
- Security headers (HSTS, CSP, X-Frame-Options, etc.)
- HTTPS enforcement
- API documentation exposure
- Data subject rights endpoints (GDPR)
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass
class APIFinding:
    """A finding from API scanning."""

    check_id: str
    file: str
    line: int
    detail: str
    severity: str
    auto_fixable: bool = False
    remediation: str = ""


# Security headers that should be present
REQUIRED_SECURITY_HEADERS: list[dict[str, str]] = [
    {
        "header": "Strict-Transport-Security",
        "pattern": r"strict.?transport.?security|hsts",
        "description": "HSTS header not configured",
        "remediation": "Add Strict-Transport-Security header with max-age >= 31536000.",
    },
    {
        "header": "X-Content-Type-Options",
        "pattern": r"x.?content.?type.?options|nosniff",
        "description": "X-Content-Type-Options header not configured",
        "remediation": "Add X-Content-Type-Options: nosniff header.",
    },
    {
        "header": "X-Frame-Options",
        "pattern": r"x.?frame.?options|frame.?ancestors",
        "description": "X-Frame-Options / CSP frame-ancestors not configured",
        "remediation": "Add X-Frame-Options: DENY or CSP frame-ancestors directive.",
    },
    {
        "header": "Content-Security-Policy",
        "pattern": r"content.?security.?policy|csp",
        "description": "Content-Security-Policy header not configured",
        "remediation": "Add Content-Security-Policy header with restrictive directives.",
    },
]

# GDPR data subject rights endpoints
GDPR_ENDPOINTS: list[dict[str, str]] = [
    {
        "right": "Right of Access (Art.15)",
        "patterns": ["data.?export", "data.?access", "my.?data", "dsar", "subject.?access"],
        "description": "Data subject access request endpoint",
    },
    {
        "right": "Right to Erasure (Art.17)",
        "patterns": ["delete.*account", "delete.*user", "erase", "forget.?me"],
        "description": "Account/data deletion endpoint",
    },
    {
        "right": "Right to Portability (Art.20)",
        "patterns": ["export", "download.*data", "portability"],
        "description": "Data portability/export endpoint",
    },
]


class APIScanner:
    """Scans API code for compliance-related patterns."""

    def __init__(self, target_path: str | Path) -> None:
        self.target_path = Path(target_path)
        self.findings: list[APIFinding] = []

    def scan(self, checks: list[dict[str, Any]]) -> list[APIFinding]:
        """Scan API-related source code for compliance issues."""
        self.findings = []

        if not self.target_path.exists():
            return self.findings

        api_files = self._collect_api_files()

        for check in checks:
            desc = check.get("check", "").lower()
            check_id = check.get("id", "")

            if "dsar" in desc or "access request" in desc:
                self._check_dsar_endpoint(api_files, check_id)
            if "deletion" in desc or "erasure" in desc or "purge" in desc:
                self._check_deletion_endpoint(api_files, check_id)
            if "export" in desc or "portability" in desc or "machine-readable" in desc:
                self._check_export_endpoint(api_files, check_id)
            if "security header" in desc:
                self._check_security_headers(api_files, check_id)
            if "rate limit" in desc:
                self._check_rate_limiting(api_files, check_id)
            if "cors" in desc:
                self._check_cors(api_files, check_id)

        return self.findings

    def _collect_api_files(self) -> list[Path]:
        """Collect files likely containing API route definitions."""
        files: list[Path] = []
        skip = {".git", "__pycache__", "node_modules", "venv", ".venv"}
        api_extensions = {".py", ".js", ".ts", ".java", ".go", ".rb"}

        for path in self.target_path.rglob("*"):
            if any(s in path.parts for s in skip):
                continue
            if path.is_file() and path.suffix in api_extensions:
                files.append(path)
        return files

    def _read_content(self, path: Path) -> str:
        try:
            return path.read_text(encoding="utf-8", errors="replace")
        except (OSError, PermissionError):
            return ""

    def _check_dsar_endpoint(self, files: list[Path], check_id: str) -> None:
        """Check for data subject access request endpoint."""
        found = False
        for fpath in files:
            content = self._read_content(fpath)
            for pattern in GDPR_ENDPOINTS[0]["patterns"]:
                if re.search(pattern, content, re.IGNORECASE):
                    found = True
                    break
            if found:
                break

        if not found:
            self.findings.append(APIFinding(
                check_id=check_id,
                file="(API)",
                line=0,
                detail="No data subject access request (DSAR) endpoint found",
                severity="high",
                auto_fixable=False,
                remediation="Implement GET /api/users/me/data endpoint to export user data.",
            ))

    def _check_deletion_endpoint(self, files: list[Path], check_id: str) -> None:
        """Check for account/data deletion endpoint."""
        found = False
        for fpath in files:
            content = self._read_content(fpath)
            # Look for DELETE endpoints or deletion functions
            if re.search(r"(?:DELETE|delete).*(?:account|user|profile)", content, re.IGNORECASE):
                found = True
                break
            for pattern in GDPR_ENDPOINTS[1]["patterns"]:
                if re.search(pattern, content, re.IGNORECASE):
                    found = True
                    break
            if found:
                break

        if not found:
            self.findings.append(APIFinding(
                check_id=check_id,
                file="(API)",
                line=0,
                detail="No account/data deletion endpoint found (Right to Erasure)",
                severity="high",
                auto_fixable=False,
                remediation="Implement DELETE /api/users/me that purges all personal data.",
            ))

    def _check_export_endpoint(self, files: list[Path], check_id: str) -> None:
        """Check for data export/portability endpoint."""
        found = False
        for fpath in files:
            content = self._read_content(fpath)
            for pattern in GDPR_ENDPOINTS[2]["patterns"]:
                if re.search(pattern, content, re.IGNORECASE):
                    found = True
                    break
            if found:
                break

        if not found:
            self.findings.append(APIFinding(
                check_id=check_id,
                file="(API)",
                line=0,
                detail="No data export/portability endpoint found",
                severity="medium",
                auto_fixable=False,
                remediation="Implement data export endpoint returning JSON/CSV of user data.",
            ))

    def _check_security_headers(self, files: list[Path], check_id: str) -> None:
        """Check for security header configuration in API code."""
        all_content = ""
        for fpath in files:
            all_content += self._read_content(fpath)

        for header_info in REQUIRED_SECURITY_HEADERS:
            if not re.search(header_info["pattern"], all_content, re.IGNORECASE):
                self.findings.append(APIFinding(
                    check_id=check_id,
                    file="(API)",
                    line=0,
                    detail=header_info["description"],
                    severity="medium",
                    auto_fixable=True,
                    remediation=header_info["remediation"],
                ))

    def _check_rate_limiting(self, files: list[Path], check_id: str) -> None:
        """Check for rate limiting configuration."""
        found = False
        for fpath in files:
            content = self._read_content(fpath)
            if re.search(r"(?:rate.?limit|throttl|slowapi|express.?rate|ratelimit)", content, re.IGNORECASE):
                found = True
                break

        if not found:
            self.findings.append(APIFinding(
                check_id=check_id,
                file="(API)",
                line=0,
                detail="No rate limiting configuration detected",
                severity="high",
                auto_fixable=True,
                remediation="Add rate limiting middleware (SlowAPI for FastAPI, express-rate-limit for Express).",
            ))

    def _check_cors(self, files: list[Path], check_id: str) -> None:
        """Check for CORS misconfiguration."""
        for fpath in files:
            content = self._read_content(fpath)
            lines = content.splitlines()
            for line_num, line in enumerate(lines, 1):
                if re.search(r"""(?:allow_origins|origin)\s*[:=]\s*\[?\s*['"]?\*['"]?""", line, re.IGNORECASE):
                    rel = str(fpath.relative_to(self.target_path))
                    self.findings.append(APIFinding(
                        check_id=check_id,
                        file=rel,
                        line=line_num,
                        detail="CORS allows all origins (*) — should be restricted to specific domains",
                        severity="high",
                        auto_fixable=True,
                        remediation="Restrict CORS to specific allowed origins.",
                    ))
