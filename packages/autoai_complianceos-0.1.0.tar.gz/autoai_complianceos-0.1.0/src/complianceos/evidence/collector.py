"""Evidence collector — automatically gathers compliance evidence from the environment.

Collects:
- Git history (change management evidence)
- CI/CD pipeline configuration (testing evidence)
- Security scanning reports
- Infrastructure configuration snapshots
- Policy document inventory
- Dependency lists and versions
"""

from __future__ import annotations

import datetime
import json
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from ..store import ComplianceStore


@dataclass
class EvidenceItem:
    """A piece of compliance evidence."""

    control_id: str
    framework: str
    evidence_type: str
    title: str
    content: str
    collected_at: str = field(default_factory=lambda: datetime.datetime.utcnow().isoformat())
    metadata: dict[str, Any] = field(default_factory=dict)


class EvidenceCollector:
    """Collects compliance evidence automatically from the project environment."""

    def __init__(self, target_path: str | Path, store: ComplianceStore | None = None) -> None:
        self.target_path = Path(target_path)
        self.store = store

    def collect_all(self, framework: str) -> list[EvidenceItem]:
        """Collect all available evidence for a framework.

        Returns list of EvidenceItem objects.
        """
        evidence: list[EvidenceItem] = []

        evidence.extend(self._collect_git_evidence(framework))
        evidence.extend(self._collect_ci_evidence(framework))
        evidence.extend(self._collect_dependency_evidence(framework))
        evidence.extend(self._collect_policy_evidence(framework))
        evidence.extend(self._collect_security_config_evidence(framework))

        # Persist evidence if store available
        if self.store:
            for item in evidence:
                self.store.save_evidence(
                    control_id=item.control_id,
                    framework=framework,
                    evidence_type=item.evidence_type,
                    content=item.content,
                    metadata=item.metadata,
                )

        return evidence

    def _collect_git_evidence(self, framework: str) -> list[EvidenceItem]:
        """Collect git-based evidence for change management controls."""
        evidence: list[EvidenceItem] = []

        # Git log as change management evidence
        git_log = self._run_git("log", "--oneline", "--since=90 days ago", "-50")
        if git_log:
            evidence.append(EvidenceItem(
                control_id="CC8.1" if framework == "soc2" else "A.8.32",
                framework=framework,
                evidence_type="change_management",
                title="Git commit history (last 90 days)",
                content=git_log,
                metadata={"source": "git log", "period": "90 days"},
            ))

        # Branch protection check
        branch_info = self._run_git("branch", "-vv")
        if branch_info:
            evidence.append(EvidenceItem(
                control_id="CC8.1" if framework == "soc2" else "A.8.32",
                framework=framework,
                evidence_type="change_management",
                title="Git branch configuration",
                content=branch_info,
                metadata={"source": "git branch"},
            ))

        # Recent merge commits (evidence of code review)
        merges = self._run_git("log", "--merges", "--oneline", "--since=90 days ago", "-20")
        if merges:
            evidence.append(EvidenceItem(
                control_id="CC8.1" if framework == "soc2" else "A.8.32",
                framework=framework,
                evidence_type="code_review",
                title="Merge commits (evidence of PR reviews)",
                content=merges,
                metadata={"source": "git log --merges", "period": "90 days"},
            ))

        return evidence

    def _collect_ci_evidence(self, framework: str) -> list[EvidenceItem]:
        """Collect CI/CD pipeline evidence."""
        evidence: list[EvidenceItem] = []

        # GitHub Actions workflows
        workflows_dir = self.target_path / ".github" / "workflows"
        if workflows_dir.exists():
            for wf_file in workflows_dir.glob("*.y*ml"):
                try:
                    content = wf_file.read_text(encoding="utf-8", errors="replace")
                    evidence.append(EvidenceItem(
                        control_id="CC8.1" if framework == "soc2" else "A.8.28",
                        framework=framework,
                        evidence_type="ci_cd_config",
                        title=f"CI/CD pipeline: {wf_file.name}",
                        content=content,
                        metadata={"source": str(wf_file.relative_to(self.target_path))},
                    ))
                except (OSError, PermissionError):
                    continue

        # GitLab CI
        gitlab_ci = self.target_path / ".gitlab-ci.yml"
        if gitlab_ci.exists():
            try:
                content = gitlab_ci.read_text(encoding="utf-8", errors="replace")
                evidence.append(EvidenceItem(
                    control_id="CC8.1",
                    framework=framework,
                    evidence_type="ci_cd_config",
                    title="GitLab CI pipeline configuration",
                    content=content,
                    metadata={"source": ".gitlab-ci.yml"},
                ))
            except (OSError, PermissionError):
                pass

        return evidence

    def _collect_dependency_evidence(self, framework: str) -> list[EvidenceItem]:
        """Collect dependency/vulnerability management evidence."""
        evidence: list[EvidenceItem] = []

        # Dependabot config
        for name in ["dependabot.yml", "dependabot.yaml"]:
            dep_file = self.target_path / ".github" / name
            if dep_file.exists():
                try:
                    content = dep_file.read_text(encoding="utf-8", errors="replace")
                    evidence.append(EvidenceItem(
                        control_id="CC3.2" if framework == "soc2" else "A.8.8",
                        framework=framework,
                        evidence_type="vulnerability_management",
                        title="Dependabot configuration",
                        content=content,
                        metadata={"source": f".github/{name}"},
                    ))
                except (OSError, PermissionError):
                    pass

        # Requirements files (dependency inventory)
        dep_files = [
            ("requirements.txt", "pip"),
            ("Pipfile.lock", "pipenv"),
            ("poetry.lock", "poetry"),
            ("package-lock.json", "npm"),
            ("yarn.lock", "yarn"),
            ("go.sum", "go"),
            ("Cargo.lock", "cargo"),
        ]
        for dep_name, ecosystem in dep_files:
            dep_path = self.target_path / dep_name
            if dep_path.exists():
                try:
                    content = dep_path.read_text(encoding="utf-8", errors="replace")
                    # Truncate large lock files
                    if len(content) > 10000:
                        content = content[:10000] + "\n... (truncated)"
                    evidence.append(EvidenceItem(
                        control_id="CC7.1" if framework == "soc2" else "A.8.8",
                        framework=framework,
                        evidence_type="dependency_inventory",
                        title=f"Dependency inventory ({ecosystem})",
                        content=content,
                        metadata={"source": dep_name, "ecosystem": ecosystem},
                    ))
                except (OSError, PermissionError):
                    pass

        return evidence

    def _collect_policy_evidence(self, framework: str) -> list[EvidenceItem]:
        """Collect policy document evidence."""
        evidence: list[EvidenceItem] = []

        policy_dirs = ["docs", "policies", "compliance", "security"]
        doc_extensions = {".md", ".txt", ".pdf", ".docx"}

        for dir_name in policy_dirs:
            dir_path = self.target_path / dir_name
            if not dir_path.exists():
                continue
            for doc in dir_path.rglob("*"):
                if doc.is_file() and doc.suffix in doc_extensions:
                    try:
                        if doc.suffix == ".pdf":
                            content = f"[PDF document: {doc.name}, size: {doc.stat().st_size} bytes]"
                        else:
                            content = doc.read_text(encoding="utf-8", errors="replace")
                            if len(content) > 5000:
                                content = content[:5000] + "\n... (truncated)"

                        evidence.append(EvidenceItem(
                            control_id="CC1.1" if framework == "soc2" else "A.5.1",
                            framework=framework,
                            evidence_type="policy_document",
                            title=f"Policy: {doc.name}",
                            content=content,
                            metadata={
                                "source": str(doc.relative_to(self.target_path)),
                                "last_modified": datetime.datetime.fromtimestamp(
                                    doc.stat().st_mtime
                                ).isoformat(),
                            },
                        ))
                    except (OSError, PermissionError):
                        continue

        return evidence

    def _collect_security_config_evidence(self, framework: str) -> list[EvidenceItem]:
        """Collect security configuration evidence."""
        evidence: list[EvidenceItem] = []

        # SECURITY.md
        security_md = self.target_path / "SECURITY.md"
        if security_md.exists():
            try:
                content = security_md.read_text(encoding="utf-8", errors="replace")
                evidence.append(EvidenceItem(
                    control_id="CC7.3" if framework == "soc2" else "A.5.24",
                    framework=framework,
                    evidence_type="security_config",
                    title="Security policy (SECURITY.md)",
                    content=content,
                    metadata={"source": "SECURITY.md"},
                ))
            except (OSError, PermissionError):
                pass

        # .gitignore (evidence of secrets exclusion)
        gitignore = self.target_path / ".gitignore"
        if gitignore.exists():
            try:
                content = gitignore.read_text(encoding="utf-8", errors="replace")
                evidence.append(EvidenceItem(
                    control_id="CC6.1" if framework == "soc2" else "A.8.12",
                    framework=framework,
                    evidence_type="security_config",
                    title="Git ignore configuration (.gitignore)",
                    content=content,
                    metadata={"source": ".gitignore"},
                ))
            except (OSError, PermissionError):
                pass

        return evidence

    def _run_git(self, *args: str) -> str:
        """Run a git command and return output."""
        try:
            result = subprocess.run(
                ["git"] + list(args),
                cwd=str(self.target_path),
                capture_output=True,
                text=True,
                timeout=30,
            )
            return result.stdout.strip() if result.returncode == 0 else ""
        except (subprocess.TimeoutExpired, FileNotFoundError):
            return ""
