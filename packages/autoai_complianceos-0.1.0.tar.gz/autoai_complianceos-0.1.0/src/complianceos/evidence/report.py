"""Report generator — creates audit-ready compliance reports.

Generates:
- Executive summary with compliance scores
- Control-by-control assessment
- Evidence inventory
- Remediation roadmap with priorities
- Gap analysis
"""

from __future__ import annotations

import datetime
import json
from pathlib import Path
from typing import Any

from ..store import ComplianceStore, ScanResult
from ..frameworks import FRAMEWORK_NAMES


class ReportGenerator:
    """Generates audit-ready compliance reports."""

    def __init__(self, store: ComplianceStore) -> None:
        self.store = store

    def generate_report(
        self,
        framework: str,
        scan_result: ScanResult | dict[str, Any] | None = None,
        evidence: list[dict[str, Any]] | None = None,
        output_format: str = "markdown",
    ) -> str:
        """Generate a compliance report.

        Args:
            framework: Framework identifier (e.g. "soc2").
            scan_result: Scan result (dict or ScanResult). If None, uses latest from store.
            evidence: Evidence items. If None, loads from store.
            output_format: "markdown" or "json".

        Returns:
            Formatted report string.
        """
        # Load scan result if not provided
        if scan_result is None:
            scan_result = self.store.get_latest_scan(framework)
        elif isinstance(scan_result, ScanResult):
            scan_result = scan_result.to_dict()

        if scan_result is None:
            return f"No scan results found for {framework}. Run a scan first."

        # Load evidence if not provided
        if evidence is None:
            evidence = self.store.get_all_evidence(framework)

        if output_format == "json":
            return self._generate_json_report(framework, scan_result, evidence)
        return self._generate_markdown_report(framework, scan_result, evidence)

    def _generate_markdown_report(
        self,
        framework: str,
        scan: dict[str, Any],
        evidence: list[dict[str, Any]],
    ) -> str:
        """Generate a Markdown-formatted compliance report."""
        fw_name = FRAMEWORK_NAMES.get(framework, framework.upper())
        now = datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")
        findings = scan.get("findings", [])

        # Categorise findings
        critical = [f for f in findings if f.get("severity") == "critical" and f.get("status") == "open"]
        high = [f for f in findings if f.get("severity") == "high" and f.get("status") == "open"]
        medium = [f for f in findings if f.get("severity") == "medium" and f.get("status") == "open"]
        low = [f for f in findings if f.get("severity") == "low" and f.get("status") == "open"]
        fixed = [f for f in findings if f.get("status") == "fixed"]

        lines: list[str] = []

        # Header
        lines.append(f"# {fw_name} Compliance Report")
        lines.append(f"\n**Generated**: {now}")
        lines.append(f"**Target**: {scan.get('target', 'N/A')}")
        lines.append(f"**Scan ID**: {scan.get('scan_id', 'N/A')}")
        lines.append("")

        # Executive Summary
        lines.append("## Executive Summary\n")
        score = scan.get("score", 0)
        status_emoji = "PASS" if score >= 80 else "NEEDS ATTENTION" if score >= 60 else "FAIL"
        lines.append(f"| Metric | Value |")
        lines.append(f"|--------|-------|")
        lines.append(f"| **Compliance Score** | **{score:.1f}%** ({status_emoji}) |")
        lines.append(f"| Total Controls Assessed | {scan.get('total_controls', 0)} |")
        lines.append(f"| Passed | {scan.get('passed', 0)} |")
        lines.append(f"| Failed | {scan.get('failed', 0)} |")
        lines.append(f"| Warnings | {scan.get('warnings', 0)} |")
        lines.append(f"| Critical Findings | {len(critical)} |")
        lines.append(f"| High Findings | {len(high)} |")
        lines.append(f"| Medium Findings | {len(medium)} |")
        lines.append(f"| Low Findings | {len(low)} |")
        lines.append(f"| Auto-Fixed | {len(fixed)} |")
        lines.append("")

        # Critical Findings
        if critical:
            lines.append("## Critical Findings (Immediate Action Required)\n")
            for f in critical:
                lines.append(f"### [{f.get('check_id', '')}] {f.get('check_description', '')}\n")
                lines.append(f"- **Control**: {f.get('control_id', '')}")
                lines.append(f"- **Resource**: {f.get('resource', 'N/A')}")
                lines.append(f"- **Detail**: {f.get('detail', '')}")
                lines.append(f"- **Remediation**: {f.get('remediation', '')}")
                lines.append(f"- **Auto-fixable**: {'Yes' if f.get('auto_fixable') else 'No'}")
                lines.append("")

        # High Findings
        if high:
            lines.append("## High Severity Findings\n")
            lines.append("| Check ID | Description | Resource | Auto-fix |")
            lines.append("|----------|-------------|----------|----------|")
            for f in high:
                auto = "Yes" if f.get("auto_fixable") else "No"
                lines.append(
                    f"| {f.get('check_id', '')} | {f.get('check_description', '')} | "
                    f"{f.get('resource', 'N/A')} | {auto} |"
                )
            lines.append("")

        # Medium/Low Findings
        if medium or low:
            lines.append("## Medium & Low Findings\n")
            lines.append("| Severity | Check ID | Description | Auto-fix |")
            lines.append("|----------|----------|-------------|----------|")
            for f in medium:
                auto = "Yes" if f.get("auto_fixable") else "No"
                lines.append(f"| MEDIUM | {f.get('check_id', '')} | {f.get('check_description', '')} | {auto} |")
            for f in low:
                auto = "Yes" if f.get("auto_fixable") else "No"
                lines.append(f"| LOW | {f.get('check_id', '')} | {f.get('check_description', '')} | {auto} |")
            lines.append("")

        # Remediation Roadmap
        lines.append("## Remediation Roadmap\n")
        lines.append("### Priority 1: Critical (Fix within 7 days)\n")
        for f in critical:
            lines.append(f"- [ ] [{f.get('check_id', '')}] {f.get('remediation', '')}")
        lines.append("")
        lines.append("### Priority 2: High (Fix within 30 days)\n")
        for f in high:
            lines.append(f"- [ ] [{f.get('check_id', '')}] {f.get('remediation', '')}")
        lines.append("")
        lines.append("### Priority 3: Medium (Fix within 90 days)\n")
        for f in medium:
            lines.append(f"- [ ] [{f.get('check_id', '')}] {f.get('remediation', '')}")
        lines.append("")

        # Evidence Inventory
        if evidence:
            lines.append("## Evidence Inventory\n")
            lines.append("| # | Control | Type | Title | Collected |")
            lines.append("|---|---------|------|-------|-----------|")
            for i, e in enumerate(evidence, 1):
                lines.append(
                    f"| {i} | {e.get('control_id', '')} | {e.get('evidence_type', '')} | "
                    f"{e.get('content', '')[:60]}... | {e.get('collected_at', '')[:10]} |"
                )
            lines.append("")

        # Footer
        lines.append("---")
        lines.append(
            "*Report generated by ComplianceOS (https://autoailabs.co.uk/complianceos). "
            "This report is for informational purposes and does not constitute legal advice.*"
        )

        return "\n".join(lines)

    def _generate_json_report(
        self,
        framework: str,
        scan: dict[str, Any],
        evidence: list[dict[str, Any]],
    ) -> str:
        """Generate a JSON-formatted compliance report."""
        findings = scan.get("findings", [])

        report = {
            "report_type": "compliance_assessment",
            "framework": framework,
            "framework_name": FRAMEWORK_NAMES.get(framework, framework),
            "generated_at": datetime.datetime.utcnow().isoformat(),
            "target": scan.get("target", ""),
            "scan_id": scan.get("scan_id", ""),
            "summary": {
                "score": scan.get("score", 0),
                "total_controls": scan.get("total_controls", 0),
                "passed": scan.get("passed", 0),
                "failed": scan.get("failed", 0),
                "warnings": scan.get("warnings", 0),
                "by_severity": {
                    "critical": len([f for f in findings if f.get("severity") == "critical" and f.get("status") == "open"]),
                    "high": len([f for f in findings if f.get("severity") == "high" and f.get("status") == "open"]),
                    "medium": len([f for f in findings if f.get("severity") == "medium" and f.get("status") == "open"]),
                    "low": len([f for f in findings if f.get("severity") == "low" and f.get("status") == "open"]),
                },
            },
            "findings": findings,
            "evidence_count": len(evidence),
            "evidence": [
                {
                    "control_id": e.get("control_id"),
                    "type": e.get("evidence_type"),
                    "collected_at": e.get("collected_at"),
                }
                for e in evidence
            ],
        }

        return json.dumps(report, indent=2)
