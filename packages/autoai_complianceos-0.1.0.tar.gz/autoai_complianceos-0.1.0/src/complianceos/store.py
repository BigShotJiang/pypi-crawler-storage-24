"""SQLite persistence for scan results, evidence, and remediation history."""

from __future__ import annotations

import json
import sqlite3
import datetime
from dataclasses import dataclass, field, asdict
from enum import Enum
from pathlib import Path
from typing import Any


class Severity(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class FindingStatus(str, Enum):
    OPEN = "open"
    FIXED = "fixed"
    ACCEPTED = "accepted"
    FALSE_POSITIVE = "false_positive"


@dataclass
class Finding:
    """A single compliance finding from a scan."""

    control_id: str
    framework: str
    check_id: str
    check_description: str
    severity: Severity
    status: FindingStatus = FindingStatus.OPEN
    resource: str = ""
    detail: str = ""
    remediation: str = ""
    auto_fixable: bool = False
    evidence: str = ""
    scan_id: str = ""
    timestamp: str = field(default_factory=lambda: datetime.datetime.utcnow().isoformat())

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["severity"] = self.severity.value
        d["status"] = self.status.value
        return d


@dataclass
class ScanResult:
    """Aggregated result of a compliance scan."""

    scan_id: str
    framework: str
    target: str
    timestamp: str
    total_controls: int = 0
    passed: int = 0
    failed: int = 0
    warnings: int = 0
    score: float = 0.0
    findings: list[Finding] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "scan_id": self.scan_id,
            "framework": self.framework,
            "target": self.target,
            "timestamp": self.timestamp,
            "total_controls": self.total_controls,
            "passed": self.passed,
            "failed": self.failed,
            "warnings": self.warnings,
            "score": self.score,
            "findings": [f.to_dict() for f in self.findings],
        }


_SCHEMA = """
CREATE TABLE IF NOT EXISTS scans (
    scan_id TEXT PRIMARY KEY,
    framework TEXT NOT NULL,
    target TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    total_controls INTEGER DEFAULT 0,
    passed INTEGER DEFAULT 0,
    failed INTEGER DEFAULT 0,
    warnings INTEGER DEFAULT 0,
    score REAL DEFAULT 0.0
);

CREATE TABLE IF NOT EXISTS findings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    scan_id TEXT NOT NULL,
    control_id TEXT NOT NULL,
    framework TEXT NOT NULL,
    check_id TEXT NOT NULL,
    check_description TEXT NOT NULL,
    severity TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'open',
    resource TEXT DEFAULT '',
    detail TEXT DEFAULT '',
    remediation TEXT DEFAULT '',
    auto_fixable INTEGER DEFAULT 0,
    evidence TEXT DEFAULT '',
    timestamp TEXT NOT NULL,
    FOREIGN KEY (scan_id) REFERENCES scans(scan_id)
);

CREATE TABLE IF NOT EXISTS evidence (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    control_id TEXT NOT NULL,
    framework TEXT NOT NULL,
    evidence_type TEXT NOT NULL,
    content TEXT NOT NULL,
    collected_at TEXT NOT NULL,
    expires_at TEXT,
    metadata TEXT DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_findings_scan ON findings(scan_id);
CREATE INDEX IF NOT EXISTS idx_findings_framework ON findings(framework);
CREATE INDEX IF NOT EXISTS idx_findings_status ON findings(status);
CREATE INDEX IF NOT EXISTS idx_evidence_control ON evidence(control_id);
"""


class ComplianceStore:
    """SQLite-backed store for compliance data."""

    def __init__(self, db_path: str | Path | None = None) -> None:
        if db_path is None:
            db_path = Path.home() / ".complianceos" / "compliance.db"
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn: sqlite3.Connection | None = None

    @property
    def conn(self) -> sqlite3.Connection:
        if self._conn is None:
            self._conn = sqlite3.connect(str(self.db_path))
            self._conn.row_factory = sqlite3.Row
            self._conn.executescript(_SCHEMA)
        return self._conn

    def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None

    # -- Scans --

    def save_scan(self, result: ScanResult) -> None:
        """Persist a scan result and its findings."""
        self.conn.execute(
            "INSERT OR REPLACE INTO scans (scan_id, framework, target, timestamp, "
            "total_controls, passed, failed, warnings, score) VALUES (?,?,?,?,?,?,?,?,?)",
            (
                result.scan_id,
                result.framework,
                result.target,
                result.timestamp,
                result.total_controls,
                result.passed,
                result.failed,
                result.warnings,
                result.score,
            ),
        )
        for f in result.findings:
            self.conn.execute(
                "INSERT INTO findings (scan_id, control_id, framework, check_id, "
                "check_description, severity, status, resource, detail, remediation, "
                "auto_fixable, evidence, timestamp) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    result.scan_id,
                    f.control_id,
                    f.framework,
                    f.check_id,
                    f.check_description,
                    f.severity.value,
                    f.status.value,
                    f.resource,
                    f.detail,
                    f.remediation,
                    1 if f.auto_fixable else 0,
                    f.evidence,
                    f.timestamp,
                ),
            )
        self.conn.commit()

    def get_scan(self, scan_id: str) -> dict[str, Any] | None:
        row = self.conn.execute("SELECT * FROM scans WHERE scan_id = ?", (scan_id,)).fetchone()
        if not row:
            return None
        d = dict(row)
        findings = self.conn.execute(
            "SELECT * FROM findings WHERE scan_id = ?", (scan_id,)
        ).fetchall()
        d["findings"] = [dict(f) for f in findings]
        return d

    def get_latest_scan(self, framework: str) -> dict[str, Any] | None:
        row = self.conn.execute(
            "SELECT scan_id FROM scans WHERE framework = ? ORDER BY timestamp DESC LIMIT 1",
            (framework,),
        ).fetchone()
        if not row:
            return None
        return self.get_scan(row["scan_id"])

    def get_open_findings(self, framework: str | None = None) -> list[dict[str, Any]]:
        if framework:
            rows = self.conn.execute(
                "SELECT * FROM findings WHERE status = 'open' AND framework = ? "
                "ORDER BY CASE severity WHEN 'critical' THEN 0 WHEN 'high' THEN 1 "
                "WHEN 'medium' THEN 2 WHEN 'low' THEN 3 ELSE 4 END",
                (framework,),
            ).fetchall()
        else:
            rows = self.conn.execute(
                "SELECT * FROM findings WHERE status = 'open' "
                "ORDER BY CASE severity WHEN 'critical' THEN 0 WHEN 'high' THEN 1 "
                "WHEN 'medium' THEN 2 WHEN 'low' THEN 3 ELSE 4 END"
            ).fetchall()
        return [dict(r) for r in rows]

    def update_finding_status(self, finding_id: int, status: FindingStatus) -> None:
        self.conn.execute(
            "UPDATE findings SET status = ? WHERE id = ?", (status.value, finding_id)
        )
        self.conn.commit()

    # -- Evidence --

    def save_evidence(
        self,
        control_id: str,
        framework: str,
        evidence_type: str,
        content: str,
        metadata: dict[str, Any] | None = None,
        expires_at: str | None = None,
    ) -> int:
        cur = self.conn.execute(
            "INSERT INTO evidence (control_id, framework, evidence_type, content, "
            "collected_at, expires_at, metadata) VALUES (?,?,?,?,?,?,?)",
            (
                control_id,
                framework,
                evidence_type,
                content,
                datetime.datetime.utcnow().isoformat(),
                expires_at,
                json.dumps(metadata or {}),
            ),
        )
        self.conn.commit()
        return cur.lastrowid  # type: ignore[return-value]

    def get_evidence(self, control_id: str, framework: str) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT * FROM evidence WHERE control_id = ? AND framework = ? "
            "ORDER BY collected_at DESC",
            (control_id, framework),
        ).fetchall()
        return [dict(r) for r in rows]

    def get_all_evidence(self, framework: str) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT * FROM evidence WHERE framework = ? ORDER BY collected_at DESC",
            (framework,),
        ).fetchall()
        return [dict(r) for r in rows]
