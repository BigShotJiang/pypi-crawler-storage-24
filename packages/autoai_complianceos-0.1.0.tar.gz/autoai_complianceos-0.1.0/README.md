# ComplianceOS

Real Compliance Automation. Scans, remediates, and generates audit-ready evidence.

Vanta and Drata collect evidence. ComplianceOS **fixes** compliance issues.

## Frameworks Supported

| Framework | Controls | Auto-fixable |
|-----------|----------|--------------|
| SOC 2 Type II | 50+ | 20+ |
| ISO 27001:2022 | 25+ | 15+ |
| GDPR | 22+ | 8+ |
| HIPAA Security Rule | 25+ | 10+ |
| PCI DSS v4.0 | 30+ | 15+ |

## Quick Start

```bash
pip install autoai-complianceos

# Scan your project against SOC 2
complianceos scan . --framework soc2

# Auto-fix violations
complianceos fix . --framework soc2 --apply

# Collect evidence for auditors
complianceos evidence . --framework soc2

# Generate audit-ready report
complianceos report --framework soc2 --output compliance-report.md
```

## Quick Start -- MCP Server

Add to your Claude Code or Cursor MCP config:

```json
{
  "mcpServers": {
    "complianceos": {
      "command": "uvx",
      "args": ["autoai-complianceos-mcp"],
      "description": "ComplianceOS — Scan your codebase for SOC2, ISO27001, GDPR, HIPAA, PCI-DSS compliance violations"
    }
  }
}
```

That's it. No signup. No API key. No data leaves your machine.

### MCP Tools

- `compliance_scan` -- Scan codebase/infra against a framework
- `compliance_status` -- Current compliance posture by framework
- `compliance_fix` -- Auto-generate and apply fixes for violations
- `compliance_evidence` -- Collect and package evidence for auditors
- `compliance_report` -- Generate audit-ready compliance report
- `compliance_map` -- Show control overlap across frameworks

## CLI Commands

```
complianceos scan <path> -f <framework>      # Scan codebase
complianceos status -f <framework>            # Show compliance posture
complianceos fix <path> -f <framework>        # Preview fixes
complianceos fix <path> -f <framework> --apply  # Apply fixes
complianceos evidence <path> -f <framework>   # Collect evidence
complianceos report -f <framework>            # Generate report
complianceos map                              # Control overlap map
complianceos serve                            # Start MCP server
```

## What Gets Scanned

### Code Scanner
- Hardcoded secrets (AWS keys, API tokens, private keys, database URLs)
- SQL injection patterns
- Missing input validation
- XSS vulnerabilities (innerHTML, dangerouslySetInnerHTML)
- Missing dependency scanning (Dependabot/Snyk)
- Missing CI/CD pipeline
- Missing branch protection
- Password policy enforcement
- Session timeout configuration

### Infrastructure Scanner
- Public storage buckets/containers
- Encryption at rest disabled
- TLS below 1.2
- Overly permissive IAM policies
- Open security groups (0.0.0.0/0)
- Missing WAF/DDoS protection
- Missing backup configuration
- Dockerfile security (root user, unpinned versions)

### Configuration Scanner
- Security policy documents
- Incident response plans
- Risk registers
- Data retention policies
- Business continuity plans
- Training records
- Vendor assessments

### API Scanner
- GDPR data subject rights endpoints (DSAR, deletion, export)
- Security headers (HSTS, CSP, X-Frame-Options)
- CORS misconfiguration
- Rate limiting

## Architecture

```
complianceos/
  frameworks/     # Real control definitions (SOC2, ISO27001, GDPR, HIPAA, PCI-DSS)
  scanners/       # Code, infra, config, and API scanners
  remediation/    # Auto-fix engine + PR generator
  evidence/       # Evidence collector + audit report generator
  store.py        # SQLite persistence
  server.py       # MCP server
  cli.py          # CLI entry point
```

## License

Apache 2.0
