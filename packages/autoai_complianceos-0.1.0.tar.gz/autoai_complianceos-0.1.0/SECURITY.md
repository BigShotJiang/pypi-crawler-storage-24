# Security Policy

## Reporting Vulnerabilities

If you discover a security vulnerability in ComplianceOS, please report it responsibly.

**Email**: security@autoailabs.co.uk

Please include:
- Description of the vulnerability
- Steps to reproduce
- Potential impact
- Suggested fix (if any)

We will acknowledge receipt within 48 hours and aim to provide a fix within 7 days for critical issues.

## Security Design

ComplianceOS is designed with security in mind:

1. **No credential storage**: ComplianceOS never stores credentials. All cloud API access uses existing environment credentials.
2. **Local-only database**: Scan results and evidence are stored in a local SQLite database. No data is sent to external services.
3. **Read-only scanning**: Scanners only read files and configuration. The `--apply` flag must be explicitly used to modify any files.
4. **No network access**: The core scanning engine does not make network requests. Only the PR generator (optional) uses git/gh CLI.
5. **Minimal dependencies**: We keep the dependency tree small to reduce supply chain risk.

## Supported Versions

| Version | Supported |
|---------|-----------|
| 0.1.x   | Yes       |

## Security Best Practices for Users

- Run ComplianceOS in CI/CD pipelines with read-only filesystem access
- Store the SQLite database in a location with appropriate access controls
- Review auto-generated fixes before applying them
- Use `--apply` only in controlled environments
