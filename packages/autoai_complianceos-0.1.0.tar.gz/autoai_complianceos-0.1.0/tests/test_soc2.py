"""Tests for SOC 2 framework controls and scanning."""

from __future__ import annotations

import json
import tempfile
from pathlib import Path

import pytest

from complianceos.frameworks import get_all_checks, get_control_overlap, FRAMEWORKS
from complianceos.frameworks.soc2 import SOC2_CONTROLS
from complianceos.frameworks.iso27001 import ISO27001_CONTROLS
from complianceos.frameworks.gdpr import GDPR_CONTROLS
from complianceos.frameworks.hipaa import HIPAA_CONTROLS
from complianceos.frameworks.pci_dss import PCI_DSS_CONTROLS
from complianceos.store import ComplianceStore, Finding, ScanResult, Severity, FindingStatus


class TestSOC2Controls:
    """Test SOC 2 control definitions."""

    def test_soc2_has_minimum_30_controls(self):
        checks = get_all_checks("soc2")
        assert len(checks) >= 30, f"SOC 2 has {len(checks)} checks, expected >= 30"

    def test_soc2_control_structure(self):
        for control_id, control in SOC2_CONTROLS.items():
            assert "name" in control, f"{control_id} missing 'name'"
            assert "checks" in control, f"{control_id} missing 'checks'"
            assert isinstance(control["checks"], list), f"{control_id} checks not a list"
            for check in control["checks"]:
                assert "id" in check, f"{control_id} check missing 'id'"
                assert "check" in check, f"{control_id} check missing 'check'"
                assert "scanner" in check, f"{control_id} check missing 'scanner'"
                assert "severity" in check, f"{control_id} check missing 'severity'"
                assert check["severity"] in ("critical", "high", "medium", "low", "info")

    def test_soc2_has_critical_controls(self):
        """Ensure critical security controls are present."""
        checks = get_all_checks("soc2")
        check_ids = {c["id"] for c in checks}
        # MFA
        assert "CC6.1.1" in check_ids, "Missing MFA check"
        # Public storage
        assert "CC6.1.2" in check_ids, "Missing public storage check"
        # Encryption at rest
        assert "CC6.1.3" in check_ids, "Missing encryption at rest check"
        # TLS
        assert "CC6.1.4" in check_ids, "Missing TLS check"
        # Hardcoded creds
        assert "CC6.1.5" in check_ids, "Missing hardcoded credentials check"

    def test_soc2_covers_all_categories(self):
        """Ensure SOC 2 covers all trust service criteria."""
        categories = set()
        for control in SOC2_CONTROLS.values():
            categories.add(control.get("category", ""))
        expected = {"Access Control", "System Operations", "Change Management", "Availability"}
        for cat in expected:
            assert cat in categories, f"Missing category: {cat}"

    def test_soc2_auto_fix_marked(self):
        """Ensure some checks are marked as auto-fixable."""
        checks = get_all_checks("soc2")
        auto_fixable = [c for c in checks if c.get("auto_fix")]
        assert len(auto_fixable) >= 10, f"Only {len(auto_fixable)} auto-fixable checks"

    def test_soc2_remediation_present(self):
        """Ensure all checks have remediation guidance."""
        checks = get_all_checks("soc2")
        for check in checks:
            assert check.get("remediation"), f"Check {check['id']} missing remediation"


class TestAllFrameworks:
    """Test all framework definitions."""

    @pytest.mark.parametrize("framework", ["soc2", "iso27001", "gdpr", "hipaa", "pci_dss"])
    def test_framework_has_minimum_checks(self, framework):
        checks = get_all_checks(framework)
        min_checks = 30 if framework == "soc2" else 20
        assert len(checks) >= min_checks, f"{framework} has {len(checks)} checks, expected >= {min_checks}"

    @pytest.mark.parametrize("framework", ["soc2", "iso27001", "gdpr", "hipaa", "pci_dss"])
    def test_framework_check_ids_unique(self, framework):
        checks = get_all_checks(framework)
        ids = [c["id"] for c in checks]
        assert len(ids) == len(set(ids)), f"{framework} has duplicate check IDs"

    @pytest.mark.parametrize("framework", ["soc2", "iso27001", "gdpr", "hipaa", "pci_dss"])
    def test_framework_scanner_types_valid(self, framework):
        checks = get_all_checks(framework)
        valid_scanners = {"code", "infra", "config", "api"}
        for check in checks:
            assert check.get("scanner") in valid_scanners, (
                f"{framework} check {check['id']} has invalid scanner: {check.get('scanner')}"
            )

    def test_iso27001_has_20_plus_controls(self):
        checks = get_all_checks("iso27001")
        assert len(checks) >= 20

    def test_gdpr_has_20_plus_controls(self):
        checks = get_all_checks("gdpr")
        assert len(checks) >= 20

    def test_hipaa_has_20_plus_controls(self):
        checks = get_all_checks("hipaa")
        assert len(checks) >= 20

    def test_pci_dss_has_20_plus_controls(self):
        checks = get_all_checks("pci_dss")
        assert len(checks) >= 20


class TestControlOverlap:
    """Test control overlap mapping."""

    def test_overlap_has_topics(self):
        overlap = get_control_overlap()
        assert len(overlap) >= 5, "Expected at least 5 overlap topics"

    def test_overlap_encryption_at_rest(self):
        overlap = get_control_overlap()
        assert "Encryption at Rest" in overlap
        frameworks_covered = {c["framework"] for c in overlap["Encryption at Rest"]}
        assert len(frameworks_covered) >= 3, "Encryption at rest should cover 3+ frameworks"

    def test_overlap_entries_reference_valid_frameworks(self):
        overlap = get_control_overlap()
        valid = set(FRAMEWORKS.keys())
        for topic, controls in overlap.items():
            for ctrl in controls:
                assert ctrl["framework"] in valid, f"Invalid framework in overlap: {ctrl['framework']}"


class TestComplianceStore:
    """Test the SQLite store."""

    def test_save_and_retrieve_scan(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            store = ComplianceStore(Path(tmpdir) / "test.db")
            try:
                result = ScanResult(
                    scan_id="test-001",
                    framework="soc2",
                    target="/tmp/project",
                    timestamp="2026-01-01T00:00:00",
                    total_controls=50,
                    passed=40,
                    failed=10,
                    score=80.0,
                    findings=[
                        Finding(
                            control_id="CC6.1",
                            framework="soc2",
                            check_id="CC6.1.1",
                            check_description="MFA check",
                            severity=Severity.CRITICAL,
                            status=FindingStatus.OPEN,
                            detail="MFA not enabled",
                        ),
                    ],
                )
                store.save_scan(result)

                retrieved = store.get_scan("test-001")
                assert retrieved is not None
                assert retrieved["score"] == 80.0
                assert len(retrieved["findings"]) == 1
                assert retrieved["findings"][0]["severity"] == "critical"
            finally:
                store.close()

    def test_get_latest_scan(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            store = ComplianceStore(Path(tmpdir) / "test.db")
            try:
                for i in range(3):
                    result = ScanResult(
                        scan_id=f"test-{i:03d}",
                        framework="soc2",
                        target="/tmp/project",
                        timestamp=f"2026-01-0{i+1}T00:00:00",
                        score=float(70 + i * 5),
                    )
                    store.save_scan(result)

                latest = store.get_latest_scan("soc2")
                assert latest is not None
                assert latest["scan_id"] == "test-002"
                assert latest["score"] == 80.0
            finally:
                store.close()

    def test_open_findings(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            store = ComplianceStore(Path(tmpdir) / "test.db")
            try:
                result = ScanResult(
                    scan_id="test-open",
                    framework="soc2",
                    target="/tmp",
                    timestamp="2026-01-01T00:00:00",
                    findings=[
                        Finding(
                            control_id="CC6.1", framework="soc2",
                            check_id="CC6.1.1", check_description="MFA",
                            severity=Severity.CRITICAL, status=FindingStatus.OPEN,
                        ),
                        Finding(
                            control_id="CC6.1", framework="soc2",
                            check_id="CC6.1.2", check_description="Storage",
                            severity=Severity.HIGH, status=FindingStatus.FIXED,
                        ),
                    ],
                )
                store.save_scan(result)

                open_f = store.get_open_findings("soc2")
                assert len(open_f) == 1
                assert open_f[0]["check_id"] == "CC6.1.1"
            finally:
                store.close()

    def test_save_and_retrieve_evidence(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            store = ComplianceStore(Path(tmpdir) / "test.db")
            try:
                eid = store.save_evidence(
                    control_id="CC8.1",
                    framework="soc2",
                    evidence_type="change_management",
                    content="Git log output...",
                    metadata={"source": "git"},
                )
                assert eid is not None

                evidence = store.get_evidence("CC8.1", "soc2")
                assert len(evidence) == 1
                assert evidence[0]["content"] == "Git log output..."
            finally:
                store.close()
