"""Tests for compliance scanners."""

from __future__ import annotations

import json
import tempfile
from pathlib import Path

import pytest

from complianceos.scanners.code_scanner import CodeScanner
from complianceos.scanners.infra_scanner import InfraScanner
from complianceos.scanners.config_scanner import ConfigScanner
from complianceos.scanners.api_scanner import APIScanner
from complianceos.remediation.auto_fix import AutoFixer, Fix
from complianceos.evidence.collector import EvidenceCollector
from complianceos.evidence.report import ReportGenerator
from complianceos.store import ComplianceStore, ScanResult, Finding, Severity, FindingStatus


class TestCodeScanner:
    """Test code scanner detection capabilities."""

    def test_detect_hardcoded_aws_key(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            p = Path(tmpdir)
            (p / "config.py").write_text('AWS_KEY = "AKIAIOSFODNN7EXAMPLE"\n', encoding="utf-8")
            scanner = CodeScanner(p)
            checks = [{"id": "CC6.1.5", "check": "No hardcoded credentials in source code"}]
            findings = scanner.scan(checks)
            assert any("AWS" in f.detail for f in findings), "Should detect AWS key"

    def test_detect_hardcoded_password(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            p = Path(tmpdir)
            (p / "settings.py").write_text('password = "supersecretpassword123"\n', encoding="utf-8")
            scanner = CodeScanner(p)
            checks = [{"id": "CC6.1.5", "check": "No hardcoded credentials in source code"}]
            findings = scanner.scan(checks)
            assert len(findings) >= 1, "Should detect hardcoded password"

    def test_detect_private_key(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            p = Path(tmpdir)
            (p / "key.py").write_text('key = """-----BEGIN RSA PRIVATE KEY-----\ndata\n"""\n', encoding="utf-8")
            scanner = CodeScanner(p)
            checks = [{"id": "CC6.1.5", "check": "No hardcoded credentials in source code"}]
            findings = scanner.scan(checks)
            assert any("Private Key" in f.detail for f in findings)

    def test_detect_sql_injection(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            p = Path(tmpdir)
            (p / "db.py").write_text(
                'cursor.execute(f"SELECT * FROM users WHERE id = {user_id}")\n',
                encoding="utf-8",
            )
            scanner = CodeScanner(p)
            checks = [{"id": "A.8.28.2", "check": "No SQL injection vulnerabilities (parameterised queries used)"}]
            findings = scanner.scan(checks)
            assert any("SQL injection" in f.detail for f in findings)

    def test_detect_missing_dependabot(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            p = Path(tmpdir)
            (p / "app.py").write_text("print('hello')\n", encoding="utf-8")
            scanner = CodeScanner(p)
            checks = [{"id": "CC3.2.2", "check": "Dependency vulnerability scanning enabled (Dependabot/Snyk)"}]
            findings = scanner.scan(checks)
            assert any("Dependabot" in f.detail or "dependency" in f.detail.lower() for f in findings)

    def test_no_false_positive_on_test_files(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            p = Path(tmpdir)
            (p / "test_auth.py").write_text('password = "testpassword123"\n', encoding="utf-8")
            scanner = CodeScanner(p)
            checks = [{"id": "CC6.1.5", "check": "No hardcoded credentials in source code"}]
            findings = scanner.scan(checks)
            # Test files should be skipped
            assert len(findings) == 0, "Should skip test files"

    def test_detect_missing_ci_pipeline(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            p = Path(tmpdir)
            (p / "app.py").write_text("print('hello')\n", encoding="utf-8")
            scanner = CodeScanner(p)
            checks = [{"id": "CC5.2.2", "check": "CI/CD pipeline includes security scanning stage"}]
            findings = scanner.scan(checks)
            assert any("CI" in f.detail for f in findings)

    def test_detect_no_password_policy(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            p = Path(tmpdir)
            (p / "auth.py").write_text("def login(username, password): pass\n", encoding="utf-8")
            scanner = CodeScanner(p)
            checks = [{"id": "CC6.1.7", "check": "Password complexity requirements enforced"}]
            findings = scanner.scan(checks)
            assert any("password" in f.detail.lower() for f in findings)

    def test_skip_nonexistent_target(self):
        scanner = CodeScanner("/nonexistent/path")
        findings = scanner.scan([{"id": "test", "check": "test"}])
        assert findings == []

    def test_detect_innerHTML_xss(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            p = Path(tmpdir)
            (p / "app.jsx").write_text(
                'element.innerHTML = userInput;\n',
                encoding="utf-8",
            )
            scanner = CodeScanner(p)
            checks = [{"id": "PI1.1.2", "check": "Output encoding to prevent injection attacks"}]
            findings = scanner.scan(checks)
            assert any("innerHTML" in f.detail for f in findings)


class TestInfraScanner:
    """Test infrastructure scanner."""

    def test_detect_public_s3_bucket(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            p = Path(tmpdir)
            (p / "main.tf").write_text('resource "aws_s3_bucket" {\n  acl = "public-read"\n}\n', encoding="utf-8")
            scanner = InfraScanner(p)
            checks = [{"id": "CC6.1.2", "check": "No public S3/Blob storage buckets"}]
            findings = scanner.scan(checks)
            assert any("public" in f.detail.lower() for f in findings)

    def test_detect_old_tls(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            p = Path(tmpdir)
            (p / "main.tf").write_text('min_tls_version = "TLS1_0"\n', encoding="utf-8")
            scanner = InfraScanner(p)
            checks = [{"id": "CC6.1.4", "check": "TLS 1.2+ enforced for all connections"}]
            findings = scanner.scan(checks)
            assert any("TLS" in f.detail for f in findings)

    def test_detect_encryption_disabled(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            p = Path(tmpdir)
            (p / "main.tf").write_text('encryption_enabled = false\n', encoding="utf-8")
            scanner = InfraScanner(p)
            checks = [{"id": "CC6.1.3", "check": "Encryption at rest enabled for databases"}]
            findings = scanner.scan(checks)
            assert any("encryption" in f.detail.lower() for f in findings)

    def test_detect_wildcard_iam(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            p = Path(tmpdir)
            (p / "iam.tf").write_text('actions = "*"\n', encoding="utf-8")
            scanner = InfraScanner(p)
            checks = [{"id": "CC6.3.1", "check": "Least privilege principle enforced in IAM policies"}]
            findings = scanner.scan(checks)
            assert any("wildcard" in f.detail.lower() or "Wildcard" in f.detail for f in findings)

    def test_detect_docker_latest_tag(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            p = Path(tmpdir)
            (p / "Dockerfile").write_text("FROM python:latest\nRUN pip install app\n", encoding="utf-8")
            scanner = InfraScanner(p)
            checks = [{"id": "A.8.8.2", "check": "Container image scanning enabled"}]
            findings = scanner.scan(checks)
            assert any("latest" in f.detail.lower() for f in findings)

    def test_detect_open_inbound(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            p = Path(tmpdir)
            (p / "sg.tf").write_text('ingress cidr_blocks = ["0.0.0.0/0"]\n', encoding="utf-8")
            scanner = InfraScanner(p)
            checks = [{"id": "A.8.20.1", "check": "Network security groups restrict inbound traffic to required ports only"}]
            findings = scanner.scan(checks)
            assert any("0.0.0.0" in f.detail for f in findings)


class TestConfigScanner:
    """Test configuration/policy scanner."""

    def test_detect_missing_security_policy(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            p = Path(tmpdir)
            (p / "app.py").write_text("pass\n", encoding="utf-8")
            scanner = ConfigScanner(p)
            checks = [{"id": "A.5.1.1", "check": "Information security policy document exists and is approved"}]
            findings = scanner.scan(checks)
            assert any("security policy" in f.detail.lower() or "not found" in f.detail.lower() for f in findings)

    def test_detect_existing_security_policy(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            p = Path(tmpdir)
            (p / "SECURITY.md").write_text("# Security Policy\nThis is our security policy.\n", encoding="utf-8")
            scanner = ConfigScanner(p)
            checks = [{"id": "A.5.1.1", "check": "Information security policy document exists and is approved"}]
            findings = scanner.scan(checks)
            # Should not flag as missing (may still flag as stale)
            missing = [f for f in findings if "not found" in f.detail.lower()]
            assert len(missing) == 0, "Should not report security policy as missing"


class TestAutoFixer:
    """Test auto-fix generation."""

    def test_generate_dependabot_fix(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            fixer = AutoFixer(tmpdir)
            findings = [{
                "check_id": "CC3.2.2",
                "detail": "No dependency vulnerability scanning configured (Dependabot/Snyk/Renovate)",
                "auto_fixable": True,
            }]
            fixes = fixer.generate_fixes(findings)
            dependabot_fixes = [f for f in fixes if "dependabot" in f.file_path.lower()]
            assert len(dependabot_fixes) >= 1

    def test_generate_codeowners_fix(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            fixer = AutoFixer(tmpdir)
            findings = [{
                "check_id": "CC8.1.2",
                "detail": "CODEOWNERS file not found",
                "auto_fixable": True,
            }]
            fixes = fixer.generate_fixes(findings)
            assert any("CODEOWNERS" in f.file_path for f in fixes)

    def test_apply_new_file_fix(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            fixer = AutoFixer(tmpdir)
            fix = Fix(
                check_id="test",
                file_path=".github/dependabot.yml",
                description="Add Dependabot",
                original="",
                replacement="",
                is_new_file=True,
                new_file_content="version: 2\n",
            )
            modified = fixer.apply_fixes([fix])
            assert ".github/dependabot.yml" in modified
            assert (Path(tmpdir) / ".github" / "dependabot.yml").exists()

    def test_fix_tls_version(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            p = Path(tmpdir)
            (p / "main.tf").write_text('min_tls_version = "TLS1_0"\n', encoding="utf-8")
            fixer = AutoFixer(tmpdir)
            findings = [{
                "check_id": "CC6.1.4",
                "detail": "TLS version below 1.2 configured",
                "file": "main.tf",
                "line": 1,
                "auto_fixable": True,
            }]
            fixes = fixer.generate_fixes(findings)
            assert any("TLS" in f.description for f in fixes)

    def test_fix_encryption_disabled(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            p = Path(tmpdir)
            (p / "db.tf").write_text("encryption_enabled = false\n", encoding="utf-8")
            fixer = AutoFixer(tmpdir)
            findings = [{
                "check_id": "CC6.1.3",
                "detail": "Encryption at rest is explicitly disabled",
                "file": "db.tf",
                "line": 1,
                "auto_fixable": True,
            }]
            fixes = fixer.generate_fixes(findings)
            applied = fixer.apply_fixes(fixes)
            content = (p / "db.tf").read_text()
            assert "true" in content


class TestEvidenceCollector:
    """Test evidence collection."""

    def test_collect_git_evidence(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create a minimal git repo
            p = Path(tmpdir)
            (p / ".git").mkdir()
            collector = EvidenceCollector(p)
            evidence = collector.collect_all("soc2")
            # May not have git evidence if not a real repo, but shouldn't crash
            assert isinstance(evidence, list)

    def test_collect_policy_evidence(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            p = Path(tmpdir)
            docs = p / "docs"
            docs.mkdir()
            (docs / "security-policy.md").write_text("# Security Policy\n", encoding="utf-8")
            (docs / "incident-response.md").write_text("# IR Plan\n", encoding="utf-8")

            collector = EvidenceCollector(p)
            evidence = collector.collect_all("soc2")
            policy_evidence = [e for e in evidence if e.evidence_type == "policy_document"]
            assert len(policy_evidence) >= 2

    def test_collect_security_config_evidence(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            p = Path(tmpdir)
            (p / "SECURITY.md").write_text("# Security\nReport vulnerabilities to security@example.com\n", encoding="utf-8")
            (p / ".gitignore").write_text(".env\n*.key\n", encoding="utf-8")

            collector = EvidenceCollector(p)
            evidence = collector.collect_all("soc2")
            config_evidence = [e for e in evidence if e.evidence_type == "security_config"]
            assert len(config_evidence) >= 2


class TestReportGenerator:
    """Test report generation."""

    def test_generate_markdown_report(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            store = ComplianceStore(Path(tmpdir) / "test.db")
            try:
                result = ScanResult(
                    scan_id="rpt-001",
                    framework="soc2",
                    target="/tmp",
                    timestamp="2026-01-01T00:00:00",
                    total_controls=50,
                    passed=40,
                    failed=10,
                    score=80.0,
                    findings=[
                        Finding(
                            control_id="CC6.1",
                            framework="soc2",
                            check_id="CC6.1.1",
                            check_description="MFA enabled",
                            severity=Severity.CRITICAL,
                            detail="MFA not enabled",
                            remediation="Enable MFA.",
                        ),
                    ],
                )
                store.save_scan(result)

                reporter = ReportGenerator(store)
                report = reporter.generate_report("soc2")
                assert "SOC 2 Type II" in report
                assert "80.0%" in report
                assert "CC6.1.1" in report
                assert "Remediation" in report
            finally:
                store.close()

    def test_generate_json_report(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            store = ComplianceStore(Path(tmpdir) / "test.db")
            try:
                result = ScanResult(
                    scan_id="rpt-002",
                    framework="soc2",
                    target="/tmp",
                    timestamp="2026-01-01T00:00:00",
                    total_controls=50,
                    passed=45,
                    failed=5,
                    score=90.0,
                )
                store.save_scan(result)

                reporter = ReportGenerator(store)
                report = reporter.generate_report("soc2", output_format="json")
                data = json.loads(report)
                assert data["summary"]["score"] == 90.0
                assert data["framework"] == "soc2"
            finally:
                store.close()

    def test_report_no_scan(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            store = ComplianceStore(Path(tmpdir) / "test.db")
            try:
                reporter = ReportGenerator(store)
                report = reporter.generate_report("gdpr")
                assert "No scan results" in report
            finally:
                store.close()
