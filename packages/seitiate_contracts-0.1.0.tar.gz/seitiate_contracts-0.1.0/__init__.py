"""Shared package root for Seitiate contracts."""
