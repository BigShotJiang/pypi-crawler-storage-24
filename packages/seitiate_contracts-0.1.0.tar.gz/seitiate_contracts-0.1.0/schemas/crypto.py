# Layer: shared
# Category: contracts
"""Encryption interface — contract for user-held key encryption.

This module defines the encryption interface that Step 7 (Codex E2E encryption)
will implement. The interface is defined now so that:
1. Code can depend on the interface before implementation
2. The API is stable when implementation lands
3. ClosedClaw can import crypto types without importing Seitiate internals

Security Model (per Director Ruling #1):
- User-held keys (password-derived or local keystore)
- Envelope encryption (data key wrapped by master key)
- Key rotation mechanism
- Server never sees plaintext or master key

See: docs/plans/2026-03-22-sovereignty-checklist-vs-split-plan-assessment.md
"""

from __future__ import annotations

import base64
import os
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Protocol, runtime_checkable

from argon2.low_level import Type, hash_secret_raw
from cryptography.hazmat.primitives.ciphers.aead import AESGCM, ChaCha20Poly1305


class KeyDerivationMethod(str, Enum):
    """How the master key is derived from user input."""

    PASSPHRASE = "passphrase"  # PBKDF2/Argon2 from password
    KEYFILE = "keyfile"  # External key file
    HARDWARE = "hardware"  # Hardware security module / secure enclave
    NONE = "none"  # No encryption (plaintext mode)


class EncryptionAlgorithm(str, Enum):
    """Encryption algorithm for data keys."""

    FERNET = "fernet"  # Current implementation (server-held)
    AES_GCM_256 = "aes-gcm-256"  # Target for user-held keys
    CHACHA20_POLY1305 = "chacha20-poly1305"  # Alternative


@dataclass(frozen=True)
class EncryptedBlob:
    """An encrypted data blob with metadata for decryption.

    This is the standard output format for all encrypted data.
    The blob is opaque — only someone with the correct key can read it.
    """

    ciphertext: bytes
    algorithm: EncryptionAlgorithm
    key_id: str  # Identifies which key version encrypted this
    nonce: bytes | None = None  # For algorithms that need it
    created_at: datetime = field(default_factory=datetime.utcnow)


@dataclass(frozen=True)
class KeyMetadata:
    """Metadata about an encryption key (not the key itself).

    This metadata can be stored server-side. The actual key material
    is user-held and never transmitted to the server.
    """

    key_id: str
    derivation_method: KeyDerivationMethod
    algorithm: EncryptionAlgorithm
    created_at: datetime
    rotated_from: str | None = None  # Previous key_id if rotated
    is_active: bool = True


@runtime_checkable
class CryptoProvider(Protocol):
    """Protocol for encryption providers.

    Implementations must support both encryption and decryption
    using user-held keys. The provider never stores key material.
    """

    def encrypt(self, plaintext: bytes, key_id: str | None = None) -> EncryptedBlob:
        """Encrypt plaintext using the active key.

        Args:
            plaintext: Data to encrypt
            key_id: Specific key to use (defaults to active key)

        Returns:
            EncryptedBlob with ciphertext and metadata
        """
        ...

    def decrypt(self, blob: EncryptedBlob) -> bytes:
        """Decrypt an encrypted blob.

        Args:
            blob: The encrypted data with metadata

        Returns:
            Decrypted plaintext bytes

        Raises:
            DecryptionError: If decryption fails
        """
        ...

    def rotate_key(self) -> KeyMetadata:
        """Generate a new key and mark it as active.

        The old key remains valid for decryption but is not used
        for new encryption operations.

        Returns:
            Metadata for the new active key
        """
        ...


class CryptoError(Exception):
    """Base exception for crypto operations."""

    pass


class DecryptionError(CryptoError):
    """Raised when decryption fails."""

    pass


class KeyNotFoundError(CryptoError):
    """Raised when the required key is not available."""

    pass


class KeyDerivationError(CryptoError):
    """Raised when key derivation fails."""

    pass


# ---------------------------------------------------------------------------
# Real implementation helpers (Step 7)
# ---------------------------------------------------------------------------

ARGON2_TIME_COST = 3
ARGON2_MEMORY_COST_KIB = 64 * 1024
ARGON2_PARALLELISM = 4
DEFAULT_KEY_BYTES = 32


def _b64encode(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")


def _b64decode(data: str) -> bytes:
    return base64.b64decode(data.encode("ascii"))


def generate_salt(length: int = 16) -> bytes:
    """Generate a random salt for passphrase key derivation."""
    return os.urandom(length)


def generate_data_key(length: int = DEFAULT_KEY_BYTES) -> bytes:
    """Generate a random tenant data key for envelope encryption."""
    return os.urandom(length)


def derive_root_key(
    secret: str | bytes,
    salt: bytes,
    *,
    length: int = DEFAULT_KEY_BYTES,
    time_cost: int = ARGON2_TIME_COST,
    memory_cost_kib: int = ARGON2_MEMORY_COST_KIB,
    parallelism: int = ARGON2_PARALLELISM,
) -> bytes:
    """Derive a root key from user-held secret material using Argon2id."""
    try:
        secret_bytes = secret.encode("utf-8") if isinstance(secret, str) else secret
        return hash_secret_raw(
            secret=secret_bytes,
            salt=salt,
            time_cost=time_cost,
            memory_cost=memory_cost_kib,
            parallelism=parallelism,
            hash_len=length,
            type=Type.ID,
        )
    except Exception as exc:
        raise KeyDerivationError(f"Argon2id derivation failed: {exc}") from exc


def encrypt_with_key(
    plaintext: bytes,
    *,
    key: bytes,
    key_id: str,
    aad: bytes | None = None,
    algorithm: EncryptionAlgorithm = EncryptionAlgorithm.AES_GCM_256,
) -> EncryptedBlob:
    """Encrypt arbitrary bytes with the selected AEAD algorithm."""
    if algorithm == EncryptionAlgorithm.AES_GCM_256:
        nonce = os.urandom(12)
        ciphertext = AESGCM(key).encrypt(nonce, plaintext, aad)
    elif algorithm == EncryptionAlgorithm.CHACHA20_POLY1305:
        nonce = os.urandom(12)
        ciphertext = ChaCha20Poly1305(key).encrypt(nonce, plaintext, aad)
    else:
        raise CryptoError(f"Unsupported algorithm for real encryption: {algorithm}")

    return EncryptedBlob(
        ciphertext=ciphertext,
        algorithm=algorithm,
        key_id=key_id,
        nonce=nonce,
    )


def decrypt_with_key(
    blob: EncryptedBlob,
    *,
    key: bytes,
    aad: bytes | None = None,
) -> bytes:
    """Decrypt an encrypted blob with the provided AEAD key."""
    try:
        if blob.algorithm == EncryptionAlgorithm.AES_GCM_256:
            if blob.nonce is None:
                raise DecryptionError("AES-GCM blob missing nonce")
            return AESGCM(key).decrypt(blob.nonce, blob.ciphertext, aad)
        if blob.algorithm == EncryptionAlgorithm.CHACHA20_POLY1305:
            if blob.nonce is None:
                raise DecryptionError("ChaCha20-Poly1305 blob missing nonce")
            return ChaCha20Poly1305(key).decrypt(blob.nonce, blob.ciphertext, aad)
        if blob.key_id == "none":
            return blob.ciphertext
        raise DecryptionError(f"Unsupported encryption algorithm: {blob.algorithm}")
    except DecryptionError:
        raise
    except Exception as exc:
        raise DecryptionError(f"Failed to decrypt blob: {exc}") from exc


def wrap_data_key(
    *,
    root_key: bytes,
    data_key: bytes,
    key_id: str,
    aad: bytes | None = None,
) -> EncryptedBlob:
    """Wrap a tenant data key under a user-derived root key."""
    return encrypt_with_key(
        data_key,
        key=root_key,
        key_id=key_id,
        aad=aad,
        algorithm=EncryptionAlgorithm.AES_GCM_256,
    )


def unwrap_data_key(
    blob: EncryptedBlob,
    *,
    root_key: bytes,
    aad: bytes | None = None,
) -> bytes:
    """Unwrap a tenant data key encrypted under a root key."""
    return decrypt_with_key(blob, key=root_key, aad=aad)


def serialize_blob(blob: EncryptedBlob) -> dict[str, str | None]:
    """Serialize an encrypted blob for JSON/text storage."""
    return {
        "ciphertext_b64": _b64encode(blob.ciphertext),
        "algorithm": blob.algorithm.value,
        "key_id": blob.key_id,
        "nonce_b64": _b64encode(blob.nonce) if blob.nonce else None,
        "created_at": blob.created_at.isoformat(),
    }


def deserialize_blob(payload: dict[str, str | None]) -> EncryptedBlob:
    """Deserialize an encrypted blob from JSON/text storage."""
    algorithm_raw = payload.get("algorithm")
    if not algorithm_raw:
        raise DecryptionError("Serialized blob missing algorithm")
    key_id = payload.get("key_id")
    if not key_id:
        raise DecryptionError("Serialized blob missing key_id")
    ciphertext_b64 = payload.get("ciphertext_b64")
    if not ciphertext_b64:
        raise DecryptionError("Serialized blob missing ciphertext")
    created_at_raw = payload.get("created_at")
    created_at = (
        datetime.fromisoformat(created_at_raw)
        if created_at_raw
        else datetime.utcnow()
    )
    nonce_raw = payload.get("nonce_b64")
    return EncryptedBlob(
        ciphertext=_b64decode(ciphertext_b64),
        algorithm=EncryptionAlgorithm(algorithm_raw),
        key_id=key_id,
        nonce=_b64decode(nonce_raw) if nonce_raw else None,
        created_at=created_at,
    )


class AesGcmCryptoProvider:
    """Stateful provider using AEAD keys supplied by the caller.

    This is a thin implementation over the shared contracts so Seitiate and
    ClosedClaw can use the same blob format and rotation semantics.
    """

    def __init__(
        self,
        *,
        keys: dict[str, bytes],
        active_key_id: str,
        algorithm: EncryptionAlgorithm = EncryptionAlgorithm.AES_GCM_256,
    ) -> None:
        if active_key_id not in keys:
            raise KeyNotFoundError(f"Active key '{active_key_id}' not found")
        self._keys = dict(keys)
        self._active_key_id = active_key_id
        self._algorithm = algorithm

    def encrypt(self, plaintext: bytes, key_id: str | None = None) -> EncryptedBlob:
        selected_key_id = key_id or self._active_key_id
        key = self._keys.get(selected_key_id)
        if key is None:
            raise KeyNotFoundError(f"Encryption key '{selected_key_id}' not found")
        return encrypt_with_key(
            plaintext,
            key=key,
            key_id=selected_key_id,
            algorithm=self._algorithm,
        )

    def decrypt(self, blob: EncryptedBlob) -> bytes:
        key = self._keys.get(blob.key_id)
        if key is None:
            raise KeyNotFoundError(f"Decryption key '{blob.key_id}' not found")
        return decrypt_with_key(blob, key=key)

    def rotate_key(self) -> KeyMetadata:
        next_key_id = f"key-{datetime.utcnow().strftime('%Y%m%d%H%M%S')}"
        self._keys[next_key_id] = generate_data_key()
        previous = self._active_key_id
        self._active_key_id = next_key_id
        return KeyMetadata(
            key_id=next_key_id,
            derivation_method=KeyDerivationMethod.PASSPHRASE,
            algorithm=self._algorithm,
            created_at=datetime.utcnow(),
            rotated_from=previous,
            is_active=True,
        )


# ---------------------------------------------------------------------------
# Stub Implementation (for use until Step 7 lands)
# ---------------------------------------------------------------------------


class NoCryptoProvider:
    """No-op provider that returns plaintext.

    Used as a placeholder until Step 7 implements real encryption.
    Also used for deployments that opt out of encryption.
    """

    def encrypt(self, plaintext: bytes, key_id: str | None = None) -> EncryptedBlob:
        """Return plaintext wrapped as a 'none' blob."""
        return EncryptedBlob(
            ciphertext=plaintext,
            algorithm=EncryptionAlgorithm.FERNET,  # Marker only
            key_id="none",
            nonce=None,
        )

    def decrypt(self, blob: EncryptedBlob) -> bytes:
        """Return the ciphertext as-is (it's plaintext)."""
        if blob.key_id == "none":
            return blob.ciphertext
        raise DecryptionError("NoCryptoProvider can only decrypt 'none' blobs")

    def rotate_key(self) -> KeyMetadata:
        """No-op rotation."""
        return KeyMetadata(
            key_id="none",
            derivation_method=KeyDerivationMethod.NONE,
            algorithm=EncryptionAlgorithm.FERNET,
            created_at=datetime.utcnow(),
            is_active=True,
        )


__all__ = [
    # Enums
    "KeyDerivationMethod",
    "EncryptionAlgorithm",
    # Data types
    "EncryptedBlob",
    "KeyMetadata",
    # Protocol
    "CryptoProvider",
    # Exceptions
    "CryptoError",
    "DecryptionError",
    "KeyNotFoundError",
    "KeyDerivationError",
    # Helpers
    "AesGcmCryptoProvider",
    "ARGON2_MEMORY_COST_KIB",
    "ARGON2_PARALLELISM",
    "ARGON2_TIME_COST",
    "DEFAULT_KEY_BYTES",
    "decrypt_with_key",
    "derive_root_key",
    "deserialize_blob",
    "encrypt_with_key",
    "generate_data_key",
    "generate_salt",
    "serialize_blob",
    "unwrap_data_key",
    "wrap_data_key",
    # Stub
    "NoCryptoProvider",
]
