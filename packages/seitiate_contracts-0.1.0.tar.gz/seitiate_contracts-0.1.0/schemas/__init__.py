# Layer: shared
# Category: contracts
"""Shared schemas for cross-layer contracts.

These types are imported by Seitiate, ClosedClaw, and Sakme layers.
They define the interfaces between layers without coupling implementations.

Contract Modules:
- governor: Detection → Enforcement handoff (N1-N6, binary gates)
- crypto: Encryption interface (Step 7 implementation)
- llm: LLM response types and provider info
- tenant: Multi-tenant context types

Usage:
    from shared.schemas import GovernorViolation, LLMResponse, TenantContext
    from shared.schemas.crypto import CryptoProvider, EncryptedBlob
"""

# Governor contracts (detection → enforcement)
from shared.schemas.governor import (
    BinaryGateAuditResult,
    BinaryGateResult,
    EnforcementAction,
    EnforcementDecision,
    GovernorAuditResult,
    GovernorViolation,
    KillSwitchResult,
    ORAResult,
    ViolationSeverity,
)

# Crypto contracts (encryption interface)
from shared.schemas.crypto import (
    AesGcmCryptoProvider,
    CryptoError,
    CryptoProvider,
    DecryptionError,
    EncryptedBlob,
    EncryptionAlgorithm,
    decrypt_with_key,
    derive_root_key,
    deserialize_blob,
    encrypt_with_key,
    generate_data_key,
    generate_salt,
    KeyDerivationError,
    KeyDerivationMethod,
    KeyMetadata,
    KeyNotFoundError,
    NoCryptoProvider,
    serialize_blob,
    unwrap_data_key,
    wrap_data_key,
)

# LLM contracts (response types, provider info)
from shared.schemas.llm import (
    BudgetExceededError,
    DEFAULT_MODEL_HINTS,
    PROVIDER_IDS,
    GoogleFreeModelRestrictionError,
    GoogleFreeNoKeyError,
    GoogleRateLimitError,
    LLMResponse,
    ProviderExecutionType,
    ProviderInfo,
    ProviderTier,
    TokenUsage,
)

# Tenant contracts (multi-tenant context)
from shared.schemas.tenant import (
    SubscriptionTier,
    TenantContext,
    TenantQuota,
    TenantStatus,
    is_valid_tenant_id,
    normalize_subscription_tier,
    subscription_tier_rank,
)

__all__ = [
    # Governor
    "BinaryGateAuditResult",
    "BinaryGateResult",
    "EnforcementAction",
    "EnforcementDecision",
    "GovernorAuditResult",
    "GovernorViolation",
    "KillSwitchResult",
    "ORAResult",
    "ViolationSeverity",
    # Crypto
    "AesGcmCryptoProvider",
    "CryptoError",
    "CryptoProvider",
    "DecryptionError",
    "EncryptedBlob",
    "EncryptionAlgorithm",
    "decrypt_with_key",
    "derive_root_key",
    "deserialize_blob",
    "encrypt_with_key",
    "generate_data_key",
    "generate_salt",
    "KeyDerivationError",
    "KeyDerivationMethod",
    "KeyMetadata",
    "KeyNotFoundError",
    "NoCryptoProvider",
    "serialize_blob",
    "unwrap_data_key",
    "wrap_data_key",
    # LLM
    "DEFAULT_MODEL_HINTS",
    "BudgetExceededError",
    "GoogleFreeModelRestrictionError",
    "GoogleFreeNoKeyError",
    "GoogleRateLimitError",
    "LLMResponse",
    "PROVIDER_IDS",
    "ProviderExecutionType",
    "ProviderInfo",
    "ProviderTier",
    "TokenUsage",
    # Tenant
    "SubscriptionTier",
    "TenantContext",
    "TenantQuota",
    "TenantStatus",
    "is_valid_tenant_id",
    "normalize_subscription_tier",
    "subscription_tier_rank",
]
