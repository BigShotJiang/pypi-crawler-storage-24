# Layer: shared
# Category: contracts
"""Tenant contracts — shared types for multi-tenant context.

This module defines the types that cross layer boundaries for tenant isolation:
- Seitiate: Tenant-scoped data storage and retrieval
- ClosedClaw: Tenant-scoped governance enforcement
- Sakme: Tenant-scoped product features

The tenant resolution implementation lives in Seitiate (tenant_resolver.py).
These contracts enable layers to work with tenant context without importing
Seitiate internals.

NOTE: The SubscriptionTier enum and normalize_subscription_tier function are
the canonical cross-layer types. billing_service.py re-exports these for
backward compatibility, but new code should import from here.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import Any
from uuid import UUID


# ---------------------------------------------------------------------------
# Tenant Types
# ---------------------------------------------------------------------------


class SubscriptionTier(str, Enum):
    """Life-OS subscription tiers: Sense ($0) -> Making (~$9) -> Meaning (~$19-29) -> Mastery (~$39-49).

    Names are canonical — don't change without migration.
    The tier progression reflects increasing depth of engagement.
    """

    SENSE = "sense"  # Free tier (Google Free + Gemini Flash only)
    MAKING = "making"  # Paid tier (~$9/mo, multi-model access)
    MEANING = "meaning"  # Premium tier (~$19-29/mo, full features)
    MASTERY = "mastery"  # Top tier (~$39-49/mo, priority support)

    # Backward-compatible aliases (map to canonical values)
    GOOGLE_FREE = "sense"
    EXPLORER = "sense"
    CREATOR = "making"
    SHOWRUNNER = "mastery"


class TenantStatus(str, Enum):
    """Tenant account status."""

    ACTIVE = "active"
    SUSPENDED = "suspended"
    PENDING = "pending"
    DELETED = "deleted"


@dataclass(frozen=True)
class TenantContext:
    """Minimal tenant context for request-scoped operations.

    This is the contract type passed between layers.
    Full tenant details live in the Tenant model (Seitiate).
    """

    tenant_id: UUID
    subscription_tier: SubscriptionTier
    status: TenantStatus = TenantStatus.ACTIVE

    # Optional fields for cross-layer use
    user_uid: str | None = None  # Firebase UID if authenticated
    feature_flags: frozenset[str] = frozenset()

    def is_paid(self) -> bool:
        """Check if tenant is on a paid tier."""
        return self.subscription_tier != SubscriptionTier.SENSE

    def has_feature(self, feature: str) -> bool:
        """Check if tenant has a specific feature flag."""
        return feature in self.feature_flags


@dataclass
class TenantQuota:
    """Quota and usage limits for a tenant.

    Used for rate limiting and budget enforcement.
    """

    daily_llm_calls: int = 1000
    daily_tokens: int = 1_000_000
    monthly_storage_mb: int = 1000
    concurrent_jobs: int = 5

    # Usage tracking (mutable)
    used_llm_calls: int = 0
    used_tokens: int = 0
    used_storage_mb: int = 0
    reset_at: datetime | None = None


# ---------------------------------------------------------------------------
# Tier Normalization
# ---------------------------------------------------------------------------

# Aliases map legacy/variant tier names to canonical tier values
_TIER_ALIASES: dict[str, str] = {
    # Free tier aliases
    "google_free": SubscriptionTier.SENSE.value,
    "explorer": SubscriptionTier.SENSE.value,
    "free": SubscriptionTier.SENSE.value,
    "sense": SubscriptionTier.SENSE.value,
    "basic": SubscriptionTier.SENSE.value,
    # Making tier aliases
    "creator": SubscriptionTier.MAKING.value,
    "pro": SubscriptionTier.MAKING.value,
    "making": SubscriptionTier.MAKING.value,
    # Meaning tier aliases
    "meaning": SubscriptionTier.MEANING.value,
    "premium": SubscriptionTier.MEANING.value,
    # Mastery tier aliases
    "showrunner": SubscriptionTier.MASTERY.value,
    "mastery": SubscriptionTier.MASTERY.value,
    # Internal tier aliases (normalized to top customer tier for gating math)
    "sovereign": SubscriptionTier.MASTERY.value,
    "enterprise": SubscriptionTier.MASTERY.value,
}

_TIER_RANK: dict[str, int] = {
    SubscriptionTier.SENSE.value: 0,
    SubscriptionTier.MAKING.value: 1,
    SubscriptionTier.MEANING.value: 2,
    SubscriptionTier.MASTERY.value: 3,
}


def normalize_subscription_tier(
    tier: SubscriptionTier | str | None,
    *,
    default: str = SubscriptionTier.SENSE.value,
) -> str:
    """Normalize legacy/current tier labels to canonical Life-OS tier keys.

    Args:
        tier: Raw tier value (SubscriptionTier enum, string, or None)
        default: Fallback if tier is None/empty/unrecognized

    Returns:
        Canonical tier string (e.g., "sense", "making", "meaning", "mastery")
    """
    if isinstance(tier, SubscriptionTier):
        raw = tier.value
    else:
        raw = str(tier or "").strip().lower()
    if not raw:
        return default
    return _TIER_ALIASES.get(raw, default)


def subscription_tier_rank(tier: SubscriptionTier | str | None) -> int:
    """Resolve a comparable numeric rank for tier gating decisions.

    Higher rank = more access. Useful for "at least tier X" checks.

    Args:
        tier: Subscription tier (enum, string, or None)

    Returns:
        Numeric rank: sense=0, making=1, meaning=2, mastery=3
    """
    return _TIER_RANK.get(normalize_subscription_tier(tier), 0)


# ---------------------------------------------------------------------------
# Validation Utilities
# ---------------------------------------------------------------------------


def is_valid_tenant_id(tenant_id: str | None) -> bool:
    """Validate tenant ID format.

    Args:
        tenant_id: The tenant ID to validate

    Returns:
        True if valid UUID format, False otherwise
    """
    if not tenant_id:
        return False
    try:
        UUID(str(tenant_id))
        return True
    except (TypeError, ValueError):
        return False


__all__ = [
    # Enums
    "SubscriptionTier",
    "TenantStatus",
    # Data types
    "TenantContext",
    "TenantQuota",
    # Tier utilities
    "normalize_subscription_tier",
    "subscription_tier_rank",
    # Validation utilities
    "is_valid_tenant_id",
]
