# Layer: shared
# Category: contracts
"""LLM contracts — shared types for multi-provider LLM abstraction.

This module defines the types that cross layer boundaries:
- Seitiate: Produces LLM responses via provider adapters
- ClosedClaw: May inspect responses for governance
- Sakme: Consumes responses for product features

The provider implementation lives in Seitiate (llm_service.py).
These contracts enable layers to work with LLM responses without
importing Seitiate internals.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from enum import Enum
from typing import Any


# ---------------------------------------------------------------------------
# Response Types
# ---------------------------------------------------------------------------


@dataclass
class TokenUsage:
    """Token usage statistics from an LLM call.

    Standardized across all providers (OpenAI, Anthropic, Gemini, etc.).
    """

    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0

    def __add__(self, other: TokenUsage) -> TokenUsage:
        """Sum usage across multiple calls."""
        return TokenUsage(
            prompt_tokens=self.prompt_tokens + other.prompt_tokens,
            completion_tokens=self.completion_tokens + other.completion_tokens,
            total_tokens=self.total_tokens + other.total_tokens,
        )


@dataclass
class LLMResponse:
    """Standardized response from any LLM provider.

    All provider adapters convert their native responses to this format.
    """

    content: str = ""
    usage: TokenUsage = field(default_factory=TokenUsage)
    model: str = ""
    finish_reason: str = "stop"
    provider: str = ""  # e.g., "anthropic", "openai", "gemini"
    metadata: dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Provider Types
# ---------------------------------------------------------------------------


class ProviderTier(str, Enum):
    """Classification of LLM provider access level.

    Determines how keys are provisioned and billing is handled.
    """

    CLI = "cli"  # Local CLI tools (Claude Code, Gemini CLI)
    USER = "user"  # BYOK (Bring Your Own Key)
    EMBEDDED = "embedded"  # Platform provides key


class ProviderExecutionType(str, Enum):
    """How the provider executes requests."""

    API = "api"  # HTTP API calls
    SUBPROCESS = "subprocess"  # Local CLI invocation


@dataclass(frozen=True)
class ProviderInfo:
    """Minimal provider information for cross-layer use.

    Full provider specs live in Seitiate's provider_registry.
    This type is for layers that only need basic info.
    """

    id: str  # canonical provider id
    display_name: str
    tier: ProviderTier
    execution_type: ProviderExecutionType
    supports_embeddings: bool = False


# ---------------------------------------------------------------------------
# Access and Routing Errors
# ---------------------------------------------------------------------------


class BudgetExceededError(Exception):
    """Raised when a tenant's budget cap would be exceeded."""

    def __init__(
        self,
        ux_hint: str,
        credits_remaining: Decimal = Decimal("0"),
        upgrade_nudge: str | None = None,
    ):
        self.ux_hint = ux_hint
        self.credits_remaining = credits_remaining
        self.upgrade_nudge = upgrade_nudge
        super().__init__(ux_hint)


class GoogleFreeNoKeyError(Exception):
    """Raised when a free-tier tenant has no Gemini API key configured."""

    def __init__(self):
        super().__init__(
            "Connect your Google AI key in Settings to start creating. "
            "Visit aistudio.google.com/apikey to get a free key."
        )


class GoogleRateLimitError(Exception):
    """Raised when a free-tier tenant hits Google's rate limits."""

    def __init__(self, retry_after: int = 60):
        self.retry_after = retry_after
        super().__init__(
            f"Google's free tier limit reached. Try again in {retry_after}s, "
            "or upgrade to Making for unlimited AI access."
        )


class GoogleFreeModelRestrictionError(Exception):
    """Raised when Google Free requests a non-Gemini or disallowed model."""

    def __init__(self, requested_model: str | None = None):
        requested = f" '{requested_model}'" if requested_model else ""
        super().__init__(
            "Google Free tier supports Gemini Flash models only. "
            f"Requested model{requested} is not allowed. "
            "Use gemini-2.0-flash or upgrade to Making for multi-model access."
        )


# ---------------------------------------------------------------------------
# Model Catalog Constants (Reference Only)
# ---------------------------------------------------------------------------
#
# Full model details live in Seitiate's model_catalog.py.
# These constants are the canonical IDs that other layers may reference.
# Do NOT duplicate the full catalog here — import from Seitiate for details.

# Canonical provider IDs (for validation and logging)
PROVIDER_IDS = frozenset({
    "anthropic",
    "openai",
    "gemini",
    "xai",
    "deepseek",
    "mistral",
    "zhipu",
    "perplexity",
    "ollama",
    # CLI providers
    "claude_code_cli",
    "gemini_cli",
    "codex_cli",
    "qwen_cli",
    "deepseek_cli",
})

# Default model per provider (for reference — authoritative source is llm_service.py)
DEFAULT_MODEL_HINTS: dict[str, str] = {
    "gemini": "gemini-2.0-flash",
    "anthropic": "claude-sonnet-4-5-20250929",
    "openai": "gpt-4o",
    "deepseek": "deepseek-chat",
    "mistral": "mistral-small-latest",
    "xai": "grok-3-mini-fast",
    "zhipu": "glm-5",
    "perplexity": "llama-3.1-sonar-small-128k-online",
    "ollama": "mistral",
}


__all__ = [
    # Response types
    "TokenUsage",
    "LLMResponse",
    # Provider types
    "ProviderTier",
    "ProviderExecutionType",
    "ProviderInfo",
    # Access/routing errors
    "BudgetExceededError",
    "GoogleFreeModelRestrictionError",
    "GoogleFreeNoKeyError",
    "GoogleRateLimitError",
    # Constants
    "PROVIDER_IDS",
    "DEFAULT_MODEL_HINTS",
]
