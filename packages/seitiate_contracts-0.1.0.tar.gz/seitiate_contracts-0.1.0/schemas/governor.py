"""Governor — domain-agnostic quality enforcement contracts.

These schemas define the shared interface between detection and enforcement.
Verticals may define their own gate names, rule codes, and domain-specific
helpers on top of these contracts, but the shared layer must stay generic.
"""

from __future__ import annotations

import re
from enum import Enum
from typing import Any

from pydantic import AliasChoices, BaseModel, Field, field_validator


VIOLATION_CODE_PATTERN = re.compile(r"^[A-Z]{1,4}\d{0,2}$")


class ViolationSeverity(str, Enum):
    """Severity levels for Governor violations."""

    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class EnforcementAction(str, Enum):
    """Actions the enforcer can take based on findings."""

    PASS = "pass"
    REJECT = "reject"
    CORRECT = "correct"
    QUARANTINE = "quarantine"
    PARDON = "pardon"


class BinaryGateResult(BaseModel):
    """Result of a single deterministic gate check."""

    gate: str
    passed: bool
    metric_value: float = Field(description="The computed metric value")
    threshold: float = Field(description="The threshold that was applied")
    failure_reason: str | None = None

    @field_validator("gate")
    @classmethod
    def validate_gate(cls, value: str) -> str:
        gate = value.strip()
        if not gate:
            raise ValueError("gate must be a non-empty string")
        return gate


class BinaryGateAuditResult(BaseModel):
    """Aggregate result of all deterministic gate checks."""

    passed: bool
    gates: list[BinaryGateResult]
    failed_gates: list[str] = Field(default_factory=list)

    @classmethod
    def from_gates(cls, gates: list[BinaryGateResult]) -> BinaryGateAuditResult:
        failed = [gate.gate for gate in gates if not gate.passed]
        return cls(
            passed=len(failed) == 0,
            gates=gates,
            failed_gates=failed,
        )


class GovernorViolation(BaseModel):
    """A single violation detected by a Governor implementation."""

    code: str
    type: str
    severity: str
    description: str
    location: str | None = None
    evidence: str = ""
    correction_guidance: str = ""
    metadata: dict[str, Any] = Field(default_factory=dict)
    confidence_estimate: dict[str, Any] | None = None

    @field_validator("code")
    @classmethod
    def validate_code(cls, value: str) -> str:
        code = value.strip().upper()
        if not VIOLATION_CODE_PATTERN.fullmatch(code):
            raise ValueError(
                "code must match ^[A-Z]{1,4}\\d{0,2}$ for extensible vertical-specific rule codes"
            )
        return code

    @field_validator("severity")
    @classmethod
    def validate_severity(cls, value: str) -> str:
        valid_severities = {"critical", "high", "medium", "low"}
        if value not in valid_severities:
            raise ValueError(
                f"severity must be one of {sorted(valid_severities)}, got '{value}'"
            )
        return value


class KillSwitchResult(BaseModel):
    """Structured summary of deterministic guardrail metrics."""

    kill_switches_pass: bool
    metrics: dict[str, Any] = Field(default_factory=dict)


class GovernorAuditResult(BaseModel):
    """Unified result from a Governor audit."""

    passed: bool
    status: str | None = None
    violations: list[GovernorViolation]
    kill_switches: KillSwitchResult | None = None
    binary_gates: BinaryGateAuditResult | None = None
    detection_summary: dict[str, Any] = Field(default_factory=dict)


class EnforcementDecision(BaseModel):
    """Decision made by the enforcement layer."""

    action: EnforcementAction
    reason: str
    should_retry: bool = False
    max_retries: int = 0


class ORAResult(BaseModel):
    """Result of the Observe-Reason-Act loop."""

    model_config = {"populate_by_name": True}

    status: str
    final_output: str = Field(
        validation_alias=AliasChoices("final_output", "final_scene"),
        description="Final corrected or accepted output payload.",
    )
    iterations_used: int
    violations_found: list[GovernorViolation]
    violations_resolved: list[GovernorViolation]
    unresolved_violations: list[GovernorViolation]

    @property
    def final_scene(self) -> str:
        """Backward-compatible narrative alias for older callers."""

        return self.final_output

    @field_validator("status")
    @classmethod
    def validate_status(cls, value: str) -> str:
        valid_statuses = {"passed", "failed_rejected", "failed_accepted", "escalate_pardon"}
        if value not in valid_statuses:
            raise ValueError(
                f"status must be one of {sorted(valid_statuses)}, got '{value}'"
            )
        return value
