# Shared Contracts (seitiate-contracts)

Cross-layer contracts between Seitiate, ClosedClaw, and Sakme.

Keep this layer product-neutral and stable. Per BOUNDARY.md:
- `shared/` imports **nothing** — it is the foundation
- All other layers may import from `shared/`

## Contract Modules

| Module | Purpose | Used By |
|--------|---------|---------|
| `governor.py` | Detection → Enforcement handoff (N1-N6, binary gates) | ClosedClaw |
| `crypto.py` | Encryption interface for user-held keys | Seitiate, ClosedClaw |
| `llm.py` | LLM response types and provider info | All layers |
| `tenant.py` | Multi-tenant context types | All layers |

## Usage

```python
# Import specific types
from shared.schemas import GovernorViolation, LLMResponse, TenantContext
from shared.schemas.crypto import CryptoProvider, EncryptedBlob

# Or import from specific modules
from shared.schemas.governor import EnforcementAction
from shared.schemas.llm import TokenUsage
from shared.schemas.tenant import SubscriptionTier
```

## Step 5 Decoupling Support

These contracts unblock the following Step 5 decoupling work:

- **5c: llm_service.py** — Use `TokenUsage`, `LLMResponse` from shared instead of local
- **5d: governor_detector.py** — Already using `shared.schemas.governor`
- **Step 7: Codex encryption** — Use `CryptoProvider` interface from shared

## Versioning

This package will become `seitiate-contracts` on PyPI (Step 11).
Semantic versioning — the contracts ARE the platform API.
