from setuptools import setup, find_packages

setup(
    name="biblio_test",
    version="1.0.0",
    packages=find_packages(),
    author="Ton Nom",
    description="Description de ta bibliothèque",
    python_requires=">=3.7",
)