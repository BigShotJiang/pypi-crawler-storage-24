# ma_bibliotheque/module.py
def ma_fonction(x):
    return x**2