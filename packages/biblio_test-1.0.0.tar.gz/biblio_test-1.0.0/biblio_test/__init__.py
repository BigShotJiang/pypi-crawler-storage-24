# ma_bibliotheque/__init__.py
from .module import ma_fonction

__version__ = "1.0.0"