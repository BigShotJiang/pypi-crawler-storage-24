"""Test suite for ztlctl."""
