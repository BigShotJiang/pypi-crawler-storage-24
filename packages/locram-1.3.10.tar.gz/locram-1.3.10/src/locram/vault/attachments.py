"""Attachment helpers: read/save files in vault/attachments/ as base64."""
import base64
from pathlib import Path

from locram.config import VAULT_PATH


def get_attachment(filename: str, vault: Path = VAULT_PATH) -> str | None:
    """Read a file from vault/attachments/ and return base64-encoded content."""
    attachments_dir = vault / "attachments"
    attachments_dir.mkdir(parents=True, exist_ok=True)
    path = attachments_dir / filename
    if not path.exists():
        return None
    return base64.b64encode(path.read_bytes()).decode()


def save_attachment(filename: str, data_b64: str, vault: Path = VAULT_PATH) -> Path:
    """Save base64 content to vault/attachments/filename. Returns the path."""
    attachments_dir = vault / "attachments"
    attachments_dir.mkdir(parents=True, exist_ok=True)
    path = attachments_dir / filename
    path.write_bytes(base64.b64decode(data_b64))
    return path
