import re
from pathlib import Path

import frontmatter


def parse_md(path: Path) -> dict | None:
    """Parse a vault .md file, returning a dict of frontmatter + body.
    Returns None if the file cannot be parsed."""
    try:
        post = frontmatter.load(str(path))
    except Exception:
        return None

    meta = dict(post.metadata)
    meta["_content"] = post.content
    meta["_path"] = path
    return meta


def extract_wikilinks(content: str) -> list[str]:
    """Extract [[Title]] references from note content."""
    return re.findall(r"\[\[([^\[\]|#]+?)(?:\|[^\[\]]+?)?\]\]", content)


def extract_h1_title(content: str) -> str | None:
    """Extract the first level-1 Markdown heading from note content."""
    for line in content.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        match = re.match(r"^#\s+(.+?)\s*$", stripped)
        if match:
            return match.group(1).strip()
    return None
