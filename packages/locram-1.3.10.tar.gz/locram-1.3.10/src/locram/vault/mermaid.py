"""Mermaid diagram rendering: diagram text → SVG or PNG in vault/attachments/."""
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Literal

from locram.config import VAULT_PATH

_ALLOWED_FORMATS: frozenset[str] = frozenset({"svg", "png"})
_MMDC_TIMEOUT = 30


def render_mermaid(
    diagram: str,
    name: str,
    output_format: Literal["svg", "png"] = "svg",
    vault: Path = VAULT_PATH,
) -> Path:
    """Render a Mermaid diagram to vault/attachments/<name>.<output_format>.

    diagram: Mermaid diagram text (without ```mermaid fences).
    name: plain filename stem, no extension, no path separators.
    output_format: 'svg' (default) or 'png'.

    Raises:
        ValueError: invalid name or unsupported format.
        FileNotFoundError: mmdc CLI is not on PATH.
        subprocess.TimeoutExpired: mmdc took longer than 30 seconds.
        RuntimeError: mmdc exited with non-zero status (stderr included in message).
    """
    if not name:
        raise ValueError("name must not be empty")
    resolved_name = Path(name)
    if resolved_name.name != name:
        raise ValueError(f"name must be a plain filename with no path separators: {name!r}")
    if resolved_name.is_absolute():
        raise ValueError(f"name must not be an absolute path: {name!r}")

    if output_format not in _ALLOWED_FORMATS:
        allowed = sorted(_ALLOWED_FORMATS)
        raise ValueError(f"output_format must be one of {allowed}, got {output_format!r}")

    if shutil.which("mmdc") is None:
        raise FileNotFoundError(
            "mmdc not found on PATH — install with: npm install -g @mermaid-js/mermaid-cli"
        )

    attachments_dir = vault / "attachments"
    attachments_dir.mkdir(parents=True, exist_ok=True)
    output_path = attachments_dir / f"{name}.{output_format}"

    temporary_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            suffix=".mmd", mode="w", encoding="utf-8", delete=False
        ) as temporary_file:
            temporary_file.write(diagram)
            temporary_path = Path(temporary_file.name)

        result = subprocess.run(
            ["mmdc", "-i", str(temporary_path), "-o", str(output_path), "-q"],
            capture_output=True,
            text=True,
            timeout=_MMDC_TIMEOUT,
        )

        if result.returncode != 0:
            stderr_output = result.stderr.strip() or result.stdout.strip() or "(no output)"
            raise RuntimeError(f"mmdc exited with code {result.returncode}: {stderr_output}")

    except subprocess.TimeoutExpired as timeout_error:
        raise subprocess.TimeoutExpired(
            timeout_error.cmd, _MMDC_TIMEOUT
        ) from timeout_error

    finally:
        if temporary_path is not None:
            temporary_path.unlink(missing_ok=True)

    return output_path
