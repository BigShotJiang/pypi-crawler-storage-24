"""Shared vault utilities."""
import re


def filename_from_title(text: str) -> str:
    """Convert a note title to a human-readable filesystem-safe filename."""
    text = re.sub(r"[\x00-\x1f]", "", text).strip()
    text = re.sub(r"[/:\\\\]", "-", text)
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"-{2,}", "-", text)
    text = text.rstrip(". ")
    return (text or "Untitled")[:120]
