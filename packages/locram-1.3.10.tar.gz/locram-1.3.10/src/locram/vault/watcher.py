"""macOS launchd watcher installer.

launchd WatchPaths fires when the vault directory changes.
It triggers `locram sync` (full-vault reconcile with debounce).
Note: WatchPaths gives directory-level notifications only — no per-file events.
"""
import shutil
import subprocess
import sys
from pathlib import Path
from xml.sax.saxutils import escape

from locram.config import (
    EMBED_RUNNER_ERR_PATH,
    EMBED_RUNNER_LOG_PATH,
    LOCRAM_EMBED_API_KEY,
    LOCRAM_EMBED_AUTO,
    LOCRAM_EMBED_BATCH_SIZE,
    LOCRAM_EMBED_MODEL,
    LOCRAM_EMBED_PROVIDER,
    LOCRAM_EMBED_QUIET_SECONDS,
    LOCRAM_EMBED_URL,
    LOCRAM_HOME,
    VAULT_PATH,
)

_PLIST_LABEL = "com.locram.vault-watcher"
_PLIST_PATH = Path.home() / "Library" / "LaunchAgents" / f"{_PLIST_LABEL}.plist"
_EMBED_RUNNER_LABEL = "com.locram.embed-runner"
_EMBED_RUNNER_PATH = Path.home() / "Library" / "LaunchAgents" / f"{_EMBED_RUNNER_LABEL}.plist"

_LEGACY_LABELS = ["com.locram.watcher"]


class PlatformError(RuntimeError):
    """Raised when a macOS-only operation is attempted on another platform."""


def require_macos() -> None:
    if sys.platform != "darwin":
        raise PlatformError(
            "locram watch-install is macOS only (uses launchd). "
            "Use 'locram sync' on other platforms."
        )


def locram_bin() -> str:
    bin_path = shutil.which("locram")
    return bin_path or "locram"


def environment_variables_plist() -> str:
    environment = {
        "LOCRAM_HOME": str(LOCRAM_HOME),
        "LOCRAM_EMBED_PROVIDER": LOCRAM_EMBED_PROVIDER,
        "LOCRAM_EMBED_URL": LOCRAM_EMBED_URL,
        "LOCRAM_EMBED_MODEL": LOCRAM_EMBED_MODEL,
        "LOCRAM_EMBED_API_KEY": LOCRAM_EMBED_API_KEY,
        "LOCRAM_EMBED_AUTO": LOCRAM_EMBED_AUTO,
        "LOCRAM_EMBED_QUIET_SECONDS": str(LOCRAM_EMBED_QUIET_SECONDS),
        "LOCRAM_EMBED_BATCH_SIZE": str(LOCRAM_EMBED_BATCH_SIZE),
    }
    items = []
    for key, value in environment.items():
        items.append(f"        <key>{escape(key)}</key>")
        items.append(f"        <string>{escape(value)}</string>")
    body = "\n".join(items)
    return f"""    <key>EnvironmentVariables</key>
    <dict>
{body}
    </dict>"""


def plist_content() -> str:
    bin_path = locram_bin()
    log_err = str(LOCRAM_HOME / "watcher.err")
    log_out = str(LOCRAM_HOME / "watcher.log")
    environment_block = environment_variables_plist()
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>{_PLIST_LABEL}</string>
    <key>ProgramArguments</key>
    <array>
        <string>{bin_path}</string>
        <string>sync</string>
    </array>
{environment_block}
    <key>WatchPaths</key>
    <array>
        <string>{VAULT_PATH}</string>
    </array>
    <key>ThrottleInterval</key>
    <integer>5</integer>
    <key>StandardErrorPath</key>
    <string>{log_err}</string>
    <key>StandardOutPath</key>
    <string>{log_out}</string>
    <key>RunAtLoad</key>
    <false/>
</dict>
</plist>
"""


def embed_runner_plist_content() -> str:
    bin_path = locram_bin()
    environment_block = environment_variables_plist()
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>{_EMBED_RUNNER_LABEL}</string>
    <key>ProgramArguments</key>
    <array>
        <string>{bin_path}</string>
        <string>embed-auto-run</string>
    </array>
{environment_block}
    <key>StartInterval</key>
    <integer>30</integer>
    <key>StandardErrorPath</key>
    <string>{EMBED_RUNNER_ERR_PATH}</string>
    <key>StandardOutPath</key>
    <string>{EMBED_RUNNER_LOG_PATH}</string>
    <key>RunAtLoad</key>
    <false/>
</dict>
</plist>
"""


def cleanup_legacy_plists() -> None:
    """Remove any old watcher plists with different labels."""
    agents_dir = Path.home() / "Library" / "LaunchAgents"
    for label in _LEGACY_LABELS:
        old = agents_dir / f"{label}.plist"
        if old.exists():
            subprocess.run(["launchctl", "unload", str(old)], check=False)
            old.unlink(missing_ok=True)


def install_watcher() -> str:
    require_macos()
    cleanup_legacy_plists()
    if _PLIST_PATH.exists():
        subprocess.run(["launchctl", "unload", str(_PLIST_PATH)], check=False)
    _PLIST_PATH.parent.mkdir(parents=True, exist_ok=True)
    _PLIST_PATH.write_text(plist_content(), encoding="utf-8")
    subprocess.run(["launchctl", "load", str(_PLIST_PATH)], check=True)
    return str(_PLIST_PATH)


def uninstall_watcher() -> None:
    require_macos()
    if _PLIST_PATH.exists():
        subprocess.run(["launchctl", "unload", str(_PLIST_PATH)], check=False)
        _PLIST_PATH.unlink()


def install_embed_runner() -> str:
    require_macos()
    if _EMBED_RUNNER_PATH.exists():
        subprocess.run(["launchctl", "unload", str(_EMBED_RUNNER_PATH)], check=False)
    _EMBED_RUNNER_PATH.parent.mkdir(parents=True, exist_ok=True)
    EMBED_RUNNER_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    _EMBED_RUNNER_PATH.write_text(embed_runner_plist_content(), encoding="utf-8")
    subprocess.run(["launchctl", "load", str(_EMBED_RUNNER_PATH)], check=True)
    return str(_EMBED_RUNNER_PATH)


def uninstall_embed_runner() -> None:
    require_macos()
    if _EMBED_RUNNER_PATH.exists():
        subprocess.run(["launchctl", "unload", str(_EMBED_RUNNER_PATH)], check=False)
        _EMBED_RUNNER_PATH.unlink()
