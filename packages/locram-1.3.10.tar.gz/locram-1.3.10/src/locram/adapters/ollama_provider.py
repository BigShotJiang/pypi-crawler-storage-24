import json
import urllib.error
import urllib.request

from locram.interfaces.embedding_provider import EmbeddingProvider

_REQUEST_TIMEOUT = 30


class OllamaEmbeddingProvider(EmbeddingProvider):
    """EmbeddingProvider backed by a local Ollama instance via stdlib HTTP."""

    def __init__(self, base_url: str, model: str) -> None:
        self._base_url = base_url.rstrip("/")
        self._model = model
        self._dimension: int | None = None

    @property
    def model_name(self) -> str:
        return self._model

    @property
    def dimension(self) -> int:
        if self._dimension is None:
            self.embed("warmup")
        return self._dimension  # type: ignore[return-value]

    def embed(self, text: str) -> list[float]:
        payload = json.dumps({"model": self._model, "input": text}).encode()
        request = urllib.request.Request(
            url=f"{self._base_url}/api/embed",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=_REQUEST_TIMEOUT) as response:
                body = response.read()
        except urllib.error.HTTPError as error:
            raise RuntimeError(
                f"Ollama returned HTTP {error.code} for model '{self._model}'"
            ) from error
        except urllib.error.URLError as error:
            raise RuntimeError(
                f"Cannot reach Ollama at {self._base_url}: {error.reason}"
            ) from error

        try:
            parsed = json.loads(body)
        except json.JSONDecodeError as error:
            raise RuntimeError(
                f"Ollama returned invalid JSON: {body[:200]!r}"
            ) from error

        embeddings = parsed.get("embeddings")
        if not embeddings or not isinstance(embeddings, list) or len(embeddings[0]) == 0:
            raise RuntimeError(
                f"Ollama response missing 'embeddings' field: {parsed!r}"
            )

        values: list[float] = embeddings[0]
        self._dimension = len(values)
        return values
