import json
import os
import time
from pathlib import Path

from locram.config import EMBED_LOCK_PATH, EMBED_PENDING_PATH


class EmbeddingRunState:
    """Filesystem-backed pending/lock state for auto-embed orchestration."""

    def __init__(
        self,
        pending_path: Path = EMBED_PENDING_PATH,
        lock_path: Path = EMBED_LOCK_PATH,
    ) -> None:
        self._pending_path = pending_path
        self._lock_path = lock_path

    def touch_pending(self) -> None:
        self._pending_path.parent.mkdir(parents=True, exist_ok=True)
        self._pending_path.write_text(str(time.time()), encoding="utf-8")

    def pending_exists(self) -> bool:
        return self._pending_path.exists()

    def pending_age_seconds(self) -> float | None:
        if not self._pending_path.exists():
            return None
        return time.time() - self._pending_path.stat().st_mtime

    def clear_pending(self) -> None:
        self._pending_path.unlink(missing_ok=True)

    def acquire_lock(self, max_age_seconds: int) -> bool:
        self._lock_path.parent.mkdir(parents=True, exist_ok=True)
        if self._lock_path.exists():
            lock_age = time.time() - self._lock_path.stat().st_mtime
            if lock_age <= max_age_seconds:
                return False
            self._lock_path.unlink(missing_ok=True)

        payload = json.dumps({"pid": os.getpid(), "created_at": time.time()})
        try:
            fd = os.open(
                self._lock_path,
                os.O_CREAT | os.O_EXCL | os.O_WRONLY,
                0o644,
            )
        except FileExistsError:
            return False

        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(payload)
        return True

    def release_lock(self) -> None:
        self._lock_path.unlink(missing_ok=True)
