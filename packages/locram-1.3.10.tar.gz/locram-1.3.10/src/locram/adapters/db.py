import sqlite3
from collections.abc import Generator
from contextlib import contextmanager
from pathlib import Path

from locram.config import DB_PATH, VAULT_PATH

_SCHEMA_PATH = Path(__file__).parent.parent / "schema.sql"

try:
    import sqlite_vec as _sqlite_vec  # type: ignore[import-untyped]
except ImportError:
    _sqlite_vec = None  # type: ignore[assignment]


@contextmanager
def get_connection(path: Path = DB_PATH) -> Generator[sqlite3.Connection, None, None]:
    conn = sqlite3.connect(str(path))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA foreign_keys = ON")
    if _sqlite_vec is not None:
        conn.enable_load_extension(True)
        _sqlite_vec.load(conn)
        conn.enable_load_extension(False)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


@contextmanager
def get_vec_connection(path: Path = DB_PATH) -> Generator[sqlite3.Connection, None, None]:
    """Connection with sqlite-vec guaranteed loaded. Raises RuntimeError if unavailable."""
    if _sqlite_vec is None:
        raise RuntimeError(
            "sqlite-vec is not installed. "
            "Install it with: pip install 'locram[embeddings]'"
        )
    conn = sqlite3.connect(str(path))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA foreign_keys = ON")
    conn.enable_load_extension(True)
    _sqlite_vec.load(conn)
    conn.enable_load_extension(False)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db(path: Path = DB_PATH) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    VAULT_PATH.mkdir(parents=True, exist_ok=True)
    schema = _SCHEMA_PATH.read_text()
    conn = sqlite3.connect(str(path))
    try:
        conn.executescript(schema)
        conn.commit()
    finally:
        conn.close()
