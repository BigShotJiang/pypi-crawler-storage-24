from pathlib import Path

from locram.adapters.db import get_connection, get_vec_connection
from locram.config import DB_PATH
from locram.interfaces.embedding_store import EmbeddingStore


class SqliteEmbeddingStore(EmbeddingStore):

    def __init__(self, db_path: Path = DB_PATH) -> None:
        self._db_path = db_path

    def store(
        self,
        page_id: str,
        field: str,
        embedding: bytes,
        model: str,
        dimension: int,
    ) -> None:
        with get_connection(self._db_path) as conn:
            conn.execute(
                """INSERT INTO page_embeddings (page_id, field, embedding, model, dimension)
                   VALUES (?, ?, ?, ?, ?)
                   ON CONFLICT(page_id, field) DO UPDATE SET
                       embedding   = excluded.embedding,
                       model       = excluded.model,
                       dimension   = excluded.dimension,
                       embedded_at = strftime('%Y-%m-%dT%H:%M:%SZ','now')""",
                (page_id, field, embedding, model, dimension),
            )

    def get(self, page_id: str, field: str = "content") -> dict | None:
        with get_connection(self._db_path) as conn:
            row = conn.execute(
                "SELECT * FROM page_embeddings WHERE page_id = ? AND field = ?",
                (page_id, field),
            ).fetchone()
            return dict(row) if row else None

    def delete(self, page_id: str) -> None:
        with get_connection(self._db_path) as conn:
            conn.execute(
                "DELETE FROM page_embeddings WHERE page_id = ?", (page_id,)
            )

    def find_unembedded(self, limit: int = 100, model: str | None = None) -> list[str]:
        if model is not None:
            return self.find_stale_embeddings(model=model, limit=limit)
        with get_connection(self._db_path) as conn:
            rows = conn.execute(
                """SELECT id FROM pages
                   WHERE status = 'active'
                     AND id NOT IN (
                         SELECT page_id FROM page_embeddings WHERE field = 'content'
                     )
                   ORDER BY updated_at DESC
                   LIMIT ?""",
                (limit,),
            ).fetchall()
            return [row["id"] for row in rows]

    def search_similar(
        self,
        query_vec: bytes,
        model: str,
        limit: int,
        field: str = "content",
    ) -> list[dict]:
        with get_vec_connection(self._db_path) as conn:
            rows = conn.execute(
                """SELECT p.id, p.title, p.type, p.status,
                          vec_distance_cosine(pe.embedding, ?) AS distance
                   FROM page_embeddings pe
                   JOIN pages p ON p.id = pe.page_id
                   WHERE p.status = 'active'
                     AND pe.field = ?
                     AND pe.model = ?
                   ORDER BY distance ASC
                   LIMIT ?""",
                (query_vec, field, model, limit),
            ).fetchall()
        return [
            {
                "id": row["id"],
                "title": row["title"],
                "type": row["type"],
                "status": row["status"],
                "distance": row["distance"],
            }
            for row in rows
        ]

    def find_stale_embeddings(self, model: str, limit: int = 100) -> list[str]:
        with get_connection(self._db_path) as conn:
            rows = conn.execute(
                """SELECT p.id
                   FROM pages p
                   LEFT JOIN page_embeddings pe
                     ON p.id = pe.page_id
                    AND pe.field = 'content'
                    AND pe.model = ?
                   WHERE p.status = 'active'
                     AND (pe.page_id IS NULL OR pe.embedded_at < p.updated_at)
                   ORDER BY p.updated_at DESC
                   LIMIT ?""",
                (model, limit),
            ).fetchall()
            return [row["id"] for row in rows]

    def get_coverage(self, model: str, field: str = "content") -> dict:
        with get_connection(self._db_path) as conn:
            searched = conn.execute(
                """SELECT COUNT(*) FROM page_embeddings pe
                   JOIN pages p ON p.id = pe.page_id
                   WHERE p.status = 'active'
                     AND pe.field = ?
                     AND pe.model = ?""",
                (field, model),
            ).fetchone()[0]
            total_active = conn.execute(
                "SELECT COUNT(*) FROM pages WHERE status = 'active'"
            ).fetchone()[0]
        return {"searched": searched, "total_active": total_active}

    def find_model_mismatches(self, model: str, field: str = "content") -> dict[str, int]:
        with get_connection(self._db_path) as conn:
            rows = conn.execute(
                """SELECT pe.model, COUNT(*) AS count
                   FROM page_embeddings pe
                   JOIN pages p ON p.id = pe.page_id
                   WHERE p.status = 'active'
                     AND pe.field = ?
                     AND pe.model != ?
                   GROUP BY pe.model""",
                (field, model),
            ).fetchall()
        return {row["model"]: row["count"] for row in rows}
