PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

-- ─── Pages ───────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS pages (
    id                   TEXT PRIMARY KEY,
    title                TEXT NOT NULL,
    content              TEXT NOT NULL DEFAULT '',
    type                 TEXT NOT NULL DEFAULT 'fleeting'
                         CHECK (type IN ('fleeting','note-taking','permanent','structure','hub')),
    status               TEXT NOT NULL DEFAULT 'active'
                         CHECK (status IN ('active','archived','to_delete')),
    subject              TEXT NOT NULL DEFAULT '[]',
    tags                 TEXT NOT NULL DEFAULT '[]',
    parent_id            TEXT REFERENCES pages(id) ON DELETE SET NULL,
    content_hash         TEXT,
    review_interval_days INTEGER NOT NULL DEFAULT 7,
    created_at           TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
    updated_at           TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
    reviewed_at          TEXT
);

CREATE INDEX IF NOT EXISTS idx_pages_status  ON pages(status);
CREATE INDEX IF NOT EXISTS idx_pages_type    ON pages(type);
CREATE INDEX IF NOT EXISTS idx_pages_parent  ON pages(parent_id);
CREATE INDEX IF NOT EXISTS idx_pages_updated ON pages(updated_at DESC);

-- ─── Links (directional, typed) ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS links (
    source_id  TEXT NOT NULL REFERENCES pages(id) ON DELETE CASCADE,
    target_id  TEXT NOT NULL REFERENCES pages(id) ON DELETE CASCADE,
    link_type  TEXT NOT NULL DEFAULT 'related'
               CHECK (link_type IN (
                   'related','extends','extended_by',
                   'supports','supported_by',
                   'contradicts','contradicted_by',
                   'refines','refined_by',
                   'questions','questioned_by',
                   'reference'
               )),
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
    PRIMARY KEY (source_id, target_id, link_type),
    CHECK (source_id != target_id)
);

CREATE INDEX IF NOT EXISTS idx_links_source ON links(source_id, link_type);
CREATE INDEX IF NOT EXISTS idx_links_target ON links(target_id, link_type);

-- ─── FTS5 full-text search ────────────────────────────────────────────────────
CREATE VIRTUAL TABLE IF NOT EXISTS pages_fts USING fts5(
    title, content,
    content = pages,
    content_rowid = rowid,
    tokenize = 'unicode61 remove_diacritics 1'
);

CREATE TRIGGER IF NOT EXISTS fts_insert AFTER INSERT ON pages BEGIN
    INSERT INTO pages_fts(rowid, title, content) VALUES (new.rowid, new.title, new.content);
END;

CREATE TRIGGER IF NOT EXISTS fts_delete AFTER DELETE ON pages BEGIN
    INSERT INTO pages_fts(pages_fts, rowid, title, content)
    VALUES ('delete', old.rowid, old.title, old.content);
END;

CREATE TRIGGER IF NOT EXISTS fts_update AFTER UPDATE ON pages BEGIN
    INSERT INTO pages_fts(pages_fts, rowid, title, content)
    VALUES ('delete', old.rowid, old.title, old.content);
    INSERT INTO pages_fts(rowid, title, content) VALUES (new.rowid, new.title, new.content);
END;

-- ─── Embeddings (written by external agents, not by locram itself) ────────────
-- PRIMARY KEY (page_id, field): one active model per field.
-- To migrate models: agent re-embeds all pages; UPSERT replaces old vectors.
CREATE TABLE IF NOT EXISTS page_embeddings (
    page_id     TEXT NOT NULL REFERENCES pages(id) ON DELETE CASCADE,
    field       TEXT NOT NULL DEFAULT 'content',
    embedding   BLOB NOT NULL,
    model       TEXT NOT NULL,
    dimension   INTEGER NOT NULL,
    embedded_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
    PRIMARY KEY (page_id, field)
);
