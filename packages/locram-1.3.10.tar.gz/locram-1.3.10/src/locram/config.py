import os
from pathlib import Path

LOCRAM_HOME = Path(os.environ.get("LOCRAM_HOME", Path.home() / ".locram"))
DB_PATH = LOCRAM_HOME / "locram.db"
VAULT_PATH = LOCRAM_HOME / "vault"
EMBED_PENDING_PATH = LOCRAM_HOME / "embed.pending"
EMBED_LOCK_PATH = LOCRAM_HOME / "embed.lock"
EMBED_RUNNER_LOG_PATH = LOCRAM_HOME / "embed-runner.log"
EMBED_RUNNER_ERR_PATH = LOCRAM_HOME / "embed-runner.err"

VAULT_EXCLUDED_DIRS = {".obsidian", ".trash", ".archive", "attachments", "templates", "Excalidraw"}

LOCRAM_EMBED_PROVIDER = os.environ.get("LOCRAM_EMBED_PROVIDER", "")
LOCRAM_EMBED_URL = os.environ.get("LOCRAM_EMBED_URL", "http://localhost:11434")
LOCRAM_EMBED_MODEL = os.environ.get("LOCRAM_EMBED_MODEL", "")
LOCRAM_EMBED_API_KEY = os.environ.get("LOCRAM_EMBED_API_KEY", "")
LOCRAM_EMBED_AUTO = os.environ.get("LOCRAM_EMBED_AUTO", "0")
LOCRAM_EMBED_AUTO_ENABLED = LOCRAM_EMBED_AUTO.lower() in {"1", "true", "yes", "on"}
LOCRAM_EMBED_QUIET_SECONDS = int(os.environ.get("LOCRAM_EMBED_QUIET_SECONDS", "60"))
LOCRAM_EMBED_BATCH_SIZE = int(os.environ.get("LOCRAM_EMBED_BATCH_SIZE", "50"))
