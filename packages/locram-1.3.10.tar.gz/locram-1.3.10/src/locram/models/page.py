from dataclasses import dataclass, field

from .enums import PageStatus, PageType


@dataclass
class Page:
    # Core identity
    id: str
    title: str
    content: str = ""

    # Classification
    type: PageType = PageType.FLEETING
    status: PageStatus = PageStatus.ACTIVE
    subject: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)

    # Hierarchy
    parent_id: str | None = None

    # Metadata
    content_hash: str | None = None
    review_interval_days: int = 7
    created_at: str = ""
    updated_at: str = ""
    reviewed_at: str | None = None

    # Graph context — populated by services at read time, NOT stored in DB
    parent: dict | None = None                   # {id, title}
    sub_items: list[dict] = field(default_factory=list)
    connected_to: list[dict] = field(default_factory=list)   # [{id, title, link_type, direction}]
    # DERIVED: parsed from [[wikilinks]] in content, NOT persisted
    inline_mentions: list[dict] = field(default_factory=list)
    next_review_at: str | None = None
