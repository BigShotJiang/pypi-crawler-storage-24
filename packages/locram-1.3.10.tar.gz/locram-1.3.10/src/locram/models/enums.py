from enum import StrEnum


class PageType(StrEnum):
    FLEETING    = "fleeting"
    NOTE_TAKING = "note-taking"
    PERMANENT   = "permanent"
    STRUCTURE   = "structure"
    HUB         = "hub"


class PageStatus(StrEnum):
    ACTIVE    = "active"
    ARCHIVED  = "archived"
    TO_DELETE = "to_delete"


class LinkType(StrEnum):
    RELATED         = "related"
    EXTENDS         = "extends"
    EXTENDED_BY     = "extended_by"
    SUPPORTS        = "supports"
    SUPPORTED_BY    = "supported_by"
    CONTRADICTS     = "contradicts"
    CONTRADICTED_BY = "contradicted_by"
    REFINES         = "refines"
    REFINED_BY      = "refined_by"
    QUESTIONS       = "questions"
    QUESTIONED_BY   = "questioned_by"
    REFERENCE       = "reference"


LINK_INVERSES: dict["LinkType", "LinkType | None"] = {
    LinkType.RELATED:         LinkType.RELATED,
    LinkType.EXTENDS:         LinkType.EXTENDED_BY,
    LinkType.EXTENDED_BY:     LinkType.EXTENDS,
    LinkType.SUPPORTS:        LinkType.SUPPORTED_BY,
    LinkType.SUPPORTED_BY:    LinkType.SUPPORTS,
    LinkType.CONTRADICTS:     LinkType.CONTRADICTED_BY,
    LinkType.CONTRADICTED_BY: LinkType.CONTRADICTS,
    LinkType.REFINES:         LinkType.REFINED_BY,
    LinkType.REFINED_BY:      LinkType.REFINES,
    LinkType.QUESTIONS:       LinkType.QUESTIONED_BY,
    LinkType.QUESTIONED_BY:   LinkType.QUESTIONS,
    LinkType.REFERENCE:       None,
}

MATURITY_ORDER = [PageType.FLEETING, PageType.NOTE_TAKING, PageType.PERMANENT]
