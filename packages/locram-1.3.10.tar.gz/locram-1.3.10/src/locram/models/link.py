from dataclasses import dataclass

from .enums import LinkType


@dataclass(frozen=True)
class Link:
    source_id: str
    target_id: str
    link_type: LinkType
    created_at: str = ""
