import sqlite3
import struct

from locram.interfaces.embedding_provider import EmbeddingProvider
from locram.interfaces.embedding_store import EmbeddingStore
from locram.interfaces.page_repository import PageRepository

_ALL_EMBED_PAGES_LIMIT = 100_000


class EmbeddingService:
    """Application service for manual and automatic embedding refresh."""

    def __init__(
        self,
        repo: PageRepository,
        store: EmbeddingStore,
        provider: EmbeddingProvider,
    ) -> None:
        self._repo = repo
        self._store = store
        self._provider = provider

    def embed_stale(self, limit: int) -> dict:
        page_ids = self._store.find_stale_embeddings(
            model=self._provider.model_name,
            limit=limit,
        )
        return self._embed_page_ids(page_ids)

    def embed_all(self, limit: int | None = None) -> dict:
        page_limit = limit if limit is not None else _ALL_EMBED_PAGES_LIMIT
        rows = self._repo.list_pages(status="active", limit=page_limit)
        page_ids = [row["id"] for row in rows]
        return self._embed_page_ids(page_ids)

    def has_stale(self, limit: int = 1) -> bool:
        stale = self._store.find_stale_embeddings(
            model=self._provider.model_name,
            limit=limit,
        )
        return bool(stale)

    def _embed_page_ids(self, page_ids: list[str]) -> dict:
        embedded = 0
        failed = 0
        skipped = 0

        for page_id in page_ids:
            page = self._repo.get(page_id)
            if page is None:
                skipped += 1
                continue

            try:
                values = self._provider.embed_note(page.title, page.content or "")
                raw = struct.pack(f"<{len(values)}f", *values)
                self._store.store(
                    page_id,
                    "content",
                    raw,
                    self._provider.model_name,
                    len(values),
                )
                embedded += 1
            except (RuntimeError, sqlite3.Error, struct.error, ValueError):
                failed += 1

        mismatches = self._store.find_model_mismatches(model=self._provider.model_name)
        result: dict = {
            "embedded": embedded,
            "skipped": skipped,
            "failed": failed,
            "model": self._provider.model_name,
        }
        if mismatches:
            other_models = ", ".join(f"'{name}'" for name in mismatches)
            result["warning"] = (
                f"DB still contains embeddings from model(s) {other_models}; "
                "run: locram embed --force"
            )
        return result
