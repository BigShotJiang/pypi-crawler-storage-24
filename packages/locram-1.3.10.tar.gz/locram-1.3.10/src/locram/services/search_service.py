import struct

from locram.interfaces.embedding_provider import EmbeddingProvider
from locram.interfaces.embedding_store import EmbeddingStore
from locram.interfaces.page_repository import PageRepository

_RRF_K = 60


class SearchService:

    def __init__(
        self,
        repo: PageRepository,
        embedding_store: EmbeddingStore | None = None,
        provider: EmbeddingProvider | None = None,
    ) -> None:
        self._repo = repo
        self._embedding_store = embedding_store
        self._provider = provider

    def search(self, query: str, limit: int = 20) -> list[dict]:
        return self._repo.search_fts(query, limit=limit)

    def find_similar(self, page_id: str, limit: int = 10) -> list[dict]:
        page = self._repo.get(page_id)
        if not page or not page.title:
            return []
        semantic_results = self._semantic_similar(page_id, limit)
        if semantic_results:
            return semantic_results
        return self._lexical_similar(page.title, page_id, limit)

    def semantic_search(self, query: str, limit: int = 20) -> dict:
        if self._provider is None or self._embedding_store is None:
            coverage = (
                self._embedding_store.get_coverage(model="")
                if self._embedding_store is not None
                else {"searched": 0, "total_active": 0}
            )
            return {
                "results": [],
                "coverage": coverage,
                "error": (
                    "Semantic search is not configured. "
                    "Set LOCRAM_EMBED_PROVIDER, LOCRAM_EMBED_URL, LOCRAM_EMBED_MODEL."
                ),
            }

        try:
            query_vector = self._provider.embed(query)
            query_bytes = struct.pack(f"<{len(query_vector)}f", *query_vector)
            model = self._provider.model_name
            results = self._embedding_store.search_similar(query_bytes, model=model, limit=limit)
            coverage = self._embedding_store.get_coverage(model=model)
            mismatches = self._embedding_store.find_model_mismatches(model=model)
        except RuntimeError as error:
            coverage = self._embedding_store.get_coverage(model=self._provider.model_name)
            return {"results": [], "coverage": coverage, "error": str(error)}

        response: dict = {"results": results, "coverage": coverage}
        if mismatches:
            other_models = ", ".join(f"'{name}'" for name in mismatches)
            response["warning"] = (
                f"database contains embeddings from model(s) {other_models}; "
                "run: locram embed --force"
            )
        return response

    def hybrid_search(self, query: str, limit: int = 20) -> dict:
        fts_hits = self._repo.search_fts(query, limit=limit * 2)

        if self._provider is None or self._embedding_store is None:
            coverage = (
                self._embedding_store.get_coverage(model="")
                if self._embedding_store is not None
                else {"searched": 0, "total_active": 0}
            )
            merged = [{**hit, "sources": ["fts"]} for hit in fts_hits[:limit]]
            return {
                "results": merged,
                "coverage": coverage,
                "warning": (
                    "Semantic search is not configured; returning lexical results only. "
                    "Set LOCRAM_EMBED_PROVIDER, LOCRAM_EMBED_URL, LOCRAM_EMBED_MODEL."
                ),
            }

        try:
            query_vector = self._provider.embed(query)
            query_bytes = struct.pack(f"<{len(query_vector)}f", *query_vector)
            model = self._provider.model_name
            vector_hits = self._embedding_store.search_similar(
                query_bytes, model=model, limit=limit * 2
            )
            coverage = self._embedding_store.get_coverage(model=model)
            mismatches = self._embedding_store.find_model_mismatches(model=model)
        except RuntimeError as error:
            merged = [{**hit, "sources": ["fts"]} for hit in fts_hits[:limit]]
            coverage = self._embedding_store.get_coverage(model=self._provider.model_name)
            return {"results": merged, "coverage": coverage, "error": str(error)}

        merged = self._rrf_merge(fts_hits, vector_hits, limit=limit)

        response: dict = {"results": merged, "coverage": coverage}
        if mismatches:
            other_models = ", ".join(f"'{name}'" for name in mismatches)
            response["warning"] = (
                f"database contains embeddings from model(s) {other_models}; "
                "run: locram embed --force"
            )
        return response

    def _rrf_merge(
        self,
        fts_hits: list[dict],
        vector_hits: list[dict],
        limit: int,
    ) -> list[dict]:
        scores: dict[str, float] = {}
        snippets: dict[str, str] = {}
        sources: dict[str, list[str]] = {}
        merged_hits: dict[str, dict] = {}

        for rank, hit in enumerate(fts_hits):
            page_id = hit["id"]
            scores[page_id] = scores.get(page_id, 0.0) + 1.0 / (_RRF_K + rank + 1)
            sources.setdefault(page_id, [])
            if "fts" not in sources[page_id]:
                sources[page_id].append("fts")
            if hit.get("snippet"):
                snippets[page_id] = hit["snippet"]
            merged_hits[page_id] = hit

        for rank, hit in enumerate(vector_hits):
            page_id = hit["id"]
            scores[page_id] = scores.get(page_id, 0.0) + 1.0 / (_RRF_K + rank + 1)
            sources.setdefault(page_id, [])
            if "semantic" not in sources[page_id]:
                sources[page_id].append("semantic")
            if page_id not in merged_hits:
                merged_hits[page_id] = hit

        ranked = sorted(scores.keys(), key=lambda page_id: scores[page_id], reverse=True)[:limit]

        results = []
        for page_id in ranked:
            hit = dict(merged_hits[page_id])
            hit["sources"] = sources.get(page_id, [])
            if page_id in snippets:
                hit["snippet"] = snippets[page_id]
            results.append(hit)
        return results

    def _semantic_similar(self, page_id: str, limit: int) -> list[dict]:
        if self._provider is None or self._embedding_store is None:
            return []

        embedding_row = self._embedding_store.get(page_id, field="content")
        if embedding_row is None:
            return []
        if embedding_row.get("model") != self._provider.model_name:
            return []

        try:
            results = self._embedding_store.search_similar(
                embedding_row["embedding"],
                model=self._provider.model_name,
                limit=limit + 1,
            )
        except RuntimeError:
            return []

        filtered = []
        for result in results:
            if result["id"] == page_id:
                continue
            filtered.append({**result, "sources": ["semantic"]})
            if len(filtered) >= limit:
                break
        return filtered

    def _lexical_similar(self, title: str, page_id: str, limit: int) -> list[dict]:
        results = self._repo.search_fts(title, limit=limit + 1)
        filtered = []
        for result in results:
            if result["id"] == page_id:
                continue
            filtered.append({**result, "sources": ["fts"]})
            if len(filtered) >= limit:
                break
        return filtered
