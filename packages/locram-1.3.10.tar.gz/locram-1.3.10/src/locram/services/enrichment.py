"""Standalone page enrichment — populates transient graph context fields.

Used by PageService and LinkService to avoid duplication.
No class, no self — pure function operating on interfaces.
"""
from datetime import datetime, timedelta

from locram.interfaces.page_repository import PageRepository
from locram.models.page import Page
from locram.vault.reader import extract_wikilinks


def enrich_page(repo: PageRepository, page: Page) -> Page:
    """Populate connected_to, parent, sub_items, inline_mentions, next_review_at."""
    links = repo.get_links(page.id)

    # connected_to: batch-fetch all linked page briefs in one query
    other_ids = []
    for link in links:
        other_ids.append(link.target_id if link.source_id == page.id else link.source_id)
    briefs = repo.get_page_briefs(other_ids) if other_ids else {}

    connected_to = []
    for link in links:
        if link.source_id == page.id:
            brief = briefs.get(link.target_id)
            direction = "outgoing"
        else:
            brief = briefs.get(link.source_id)
            direction = "incoming"
        if brief:
            connected_to.append({
                "id": brief["id"],
                "title": brief["title"],
                "link_type": link.link_type.value,
                "direction": direction,
            })
    page.connected_to = connected_to

    # parent
    if page.parent_id:
        parent_brief = repo.get_page_briefs([page.parent_id])
        p = parent_brief.get(page.parent_id)
        page.parent = {"id": p["id"], "title": p["title"]} if p else None

    # sub_items: direct SQL query, not O(N) scan
    page.sub_items = [
        {"id": c["id"], "title": c["title"]}
        for c in repo.get_children(page.id)
    ]

    # inline_mentions: exact title match, not fragile FTS
    # take first match (oldest by created_at — deterministic when titles collide)
    titles = extract_wikilinks(page.content)
    mentions = []
    for title in titles:
        results = repo.find_by_title(title)
        if results:
            mentions.append({"id": results[0]["id"], "title": results[0]["title"]})
    page.inline_mentions = mentions

    # next_review_at
    base_timestamp = page.reviewed_at or page.updated_at
    if base_timestamp:
        try:
            base_dt = datetime.fromisoformat(base_timestamp.replace("Z", "+00:00"))
            page.next_review_at = (
                base_dt + timedelta(days=page.review_interval_days)
            ).strftime("%Y-%m-%dT%H:%M:%SZ")
        except ValueError:
            pass

    return page
