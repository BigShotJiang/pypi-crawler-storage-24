from ulid import ULID

from locram.interfaces.page_repository import PageRepository
from locram.interfaces.vault_store import VaultStore
from locram.models.enums import MATURITY_ORDER, PageStatus, PageType
from locram.models.page import Page
from locram.services.enrichment import enrich_page


class AmbiguousTitleError(ValueError):
    """Raised when get_page_by_identifier matches more than one page by title."""


class PageService:

    def __init__(self, repo: PageRepository, vault: VaultStore) -> None:
        self._repo = repo
        self._vault = vault

    def create_page(
        self,
        title: str,
        content: str = "",
        type: str = "fleeting",
        status: str = "active",
        subject: list[str] | None = None,
        tags: list[str] | None = None,
        parent_id: str | None = None,
        review_interval_days: int = 7,
    ) -> Page:
        page = Page(
            id=str(ULID()),
            title=title,
            content=content,
            type=PageType(type),
            status=PageStatus(status),
            subject=subject or [],
            tags=tags or [],
            parent_id=parent_id,
            review_interval_days=review_interval_days,
        )
        page = self._repo.create(page)
        page = self._enrich(page)
        self._vault.write(page)
        return page

    def get_page(self, page_id: str) -> Page | None:
        page = self._repo.get(page_id)
        if page is None:
            return None
        return self._enrich(page)

    def get_page_by_identifier(self, identifier: str) -> Page | None:
        """Lookup by ID first, then by exact title.

        Raises ValueError if the title matches more than one active page
        (caller should prompt the user to use the page_id instead).
        """
        page = self._repo.get(identifier)
        if page is not None:
            return self._enrich(page)
        results = self._repo.find_by_title(identifier)
        if len(results) > 1:
            raise AmbiguousTitleError(
                f"Ambiguous title '{identifier}': {len(results)} pages match. Use page_id instead."
            )
        if len(results) == 1:
            page = self._repo.get(results[0]["id"])
            return self._enrich(page) if page else None
        return None

    def update_page(self, page_id: str, **fields) -> Page | None:
        page = self._repo.update(page_id, **fields)
        if page is None:
            return None
        page = self._enrich(page)
        self._vault.write(page)
        return page

    def delete_page(self, page_id: str, hard: bool = False) -> bool:
        ok = self._repo.delete(page_id, hard=hard)
        if ok and hard:
            self._vault.remove(page_id)
        elif ok:
            page = self._repo.get(page_id)
            if page:
                page = self._enrich(page)
                self._vault.write(page)
        return ok

    def restore_page(self, page_id: str) -> dict:
        """Restore a soft-deleted note and rewrite its vault file.

        Restoring updates updated_at, so the note becomes stale for embedding refresh
        and will be picked up by manual or auto-embed maintenance.
        """
        page = self._repo.get(page_id)
        if page is None:
            return {"error": f"Page {page_id} not found"}
        if page.status != PageStatus.TO_DELETE:
            return {"error": f"Page {page_id} is not in to_delete state"}
        ok = self._repo.restore(page_id)
        if not ok:
            return {"error": f"Page {page_id} could not be restored"}
        restored = self._repo.get(page_id)
        if restored is None:
            return {"error": f"Page {page_id} not found after restore"}
        restored = self._enrich(restored)
        self._vault.write(restored)
        return {"restored": True, "id": page_id, "status": restored.status.value}

    def purge_page(self, page_id: str) -> dict:
        """Permanently delete a note already in to_delete state."""
        page = self._repo.get(page_id)
        if page is None:
            return {"error": f"Page {page_id} not found"}
        if page.status != PageStatus.TO_DELETE:
            return {"error": f"Page {page_id} must be in to_delete state before purge"}
        ok = self._repo.delete(page_id, hard=True)
        if not ok:
            return {"error": f"Page {page_id} could not be purged"}
        self._vault.remove(page_id)
        return {"purged": True, "id": page_id}

    def mark_reviewed(self, page_id: str) -> dict:
        ok = self._repo.mark_reviewed(page_id)
        if not ok:
            return {"error": f"Page {page_id} not found"}
        page = self._repo.get(page_id)
        if page:
            page = self._enrich(page)
            self._vault.write(page)
        return {"id": page_id, "reviewed_at": page.reviewed_at if page else None}

    def list_pages(self, **filters) -> list[dict]:
        return self._repo.list_pages(**filters)

    def promote_page(self, page_id: str) -> dict:
        page = self._repo.get(page_id)
        if page is None:
            return {"error": f"Page {page_id} not found"}
        if page.type not in MATURITY_ORDER:
            return {
                "error": (
                    f"Cannot promote: type '{page.type.value}' is a classification type "
                    f"(structure/hub). Use update_page(type=...) to change classification."
                )
            }
        current_index = MATURITY_ORDER.index(page.type)
        if current_index >= len(MATURITY_ORDER) - 1:
            return {"error": f"Already at maximum maturity: '{page.type.value}'"}
        next_type = MATURITY_ORDER[current_index + 1]
        self.update_page(page_id, type=next_type.value)
        return {
            "id": page_id,
            "previous_type": page.type.value,
            "new_type": next_type.value,
        }

    def _enrich(self, page: Page) -> Page:
        return enrich_page(self._repo, page)
