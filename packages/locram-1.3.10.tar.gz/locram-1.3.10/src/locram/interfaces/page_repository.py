from abc import ABC, abstractmethod
from pathlib import Path

from locram.models.enums import LinkType
from locram.models.link import Link
from locram.models.page import Page


class PageRepository(ABC):

    @property
    @abstractmethod
    def db_path(self) -> Path: ...

    @abstractmethod
    def get(self, page_id: str) -> Page | None: ...

    @abstractmethod
    def create(self, page: Page) -> Page: ...

    @abstractmethod
    def update(self, page_id: str, **fields) -> Page | None: ...

    @abstractmethod
    def delete(self, page_id: str, hard: bool = False) -> bool: ...

    @abstractmethod
    def restore(self, page_id: str) -> bool: ...

    @abstractmethod
    def mark_reviewed(self, page_id: str) -> bool: ...

    @abstractmethod
    def list_pages(
        self,
        status: str | None = None,
        type: str | None = None,
        subject: str | None = None,
        tag: str | None = None,
        since_days: int | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[dict]: ...

    @abstractmethod
    def search_fts(self, query: str, limit: int = 20) -> list[dict]: ...

    @abstractmethod
    def create_link(self, source_id: str, target_id: str, link_type: LinkType) -> bool: ...

    @abstractmethod
    def delete_link(self, source_id: str, target_id: str, link_type: LinkType | None) -> None: ...

    @abstractmethod
    def get_links(self, page_id: str) -> list[Link]: ...

    @abstractmethod
    def set_parent(self, child_id: str, parent_id: str | None) -> None: ...

    @abstractmethod
    def get_children(self, parent_id: str) -> list[dict]: ...

    @abstractmethod
    def find_by_title(self, title: str) -> list[dict]: ...

    @abstractmethod
    def get_page_briefs(self, ids: list[str]) -> dict[str, dict]: ...

    @abstractmethod
    def find_orphaned(self, limit: int = 50) -> list[dict]: ...

    @abstractmethod
    def find_central(self, limit: int = 20) -> list[dict]: ...

    @abstractmethod
    def find_due_for_review(self, limit: int = 50) -> list[dict]: ...

    @abstractmethod
    def get_all_pages_summary(self, limit: int = 500) -> list[dict]: ...

    @abstractmethod
    def get_all_links(self, limit: int = 500) -> list[dict]: ...
