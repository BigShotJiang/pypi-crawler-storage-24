from abc import ABC, abstractmethod


class EmbeddingProvider(ABC):

    @property
    @abstractmethod
    def model_name(self) -> str: ...

    @property
    @abstractmethod
    def dimension(self) -> int: ...

    @abstractmethod
    def embed(self, text: str) -> list[float]: ...

    def embed_note(self, title: str, content: str) -> list[float]:
        text = f"{title}\n\n{content}".strip() if content and content.strip() else title
        return self.embed(text)
