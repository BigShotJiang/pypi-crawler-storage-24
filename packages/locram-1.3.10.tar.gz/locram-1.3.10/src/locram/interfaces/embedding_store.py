from abc import ABC, abstractmethod


class EmbeddingStore(ABC):

    @abstractmethod
    def store(
        self,
        page_id: str,
        field: str,
        embedding: bytes,
        model: str,
        dimension: int,
    ) -> None: ...

    @abstractmethod
    def get(self, page_id: str, field: str = "content") -> dict | None: ...

    @abstractmethod
    def delete(self, page_id: str) -> None: ...

    @abstractmethod
    def find_unembedded(self, limit: int = 100, model: str | None = None) -> list[str]: ...

    @abstractmethod
    def search_similar(
        self,
        query_vec: bytes,
        model: str,
        limit: int,
        field: str = "content",
    ) -> list[dict]: ...

    @abstractmethod
    def find_stale_embeddings(self, model: str, limit: int = 100) -> list[str]: ...

    @abstractmethod
    def get_coverage(self, model: str, field: str = "content") -> dict: ...

    @abstractmethod
    def find_model_mismatches(self, model: str, field: str = "content") -> dict[str, int]: ...
