from abc import ABC, abstractmethod
from pathlib import Path

from locram.models.page import Page


class VaultStore(ABC):

    @property
    @abstractmethod
    def vault_path(self) -> Path: ...

    @abstractmethod
    def write(self, page: Page) -> Path: ...

    @abstractmethod
    def remove(self, page_id: str) -> None: ...

    @abstractmethod
    def read(self, path: Path) -> dict | None: ...

    @abstractmethod
    def sync(self, file_path: Path | None = None) -> dict: ...

    @abstractmethod
    def setup_obsidian(self) -> None: ...
