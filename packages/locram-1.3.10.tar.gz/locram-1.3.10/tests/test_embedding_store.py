"""SqliteEmbeddingStore unit tests — new Phase 2b methods."""

import struct
import time

import pytest

from locram.adapters.db import init_db
from locram.adapters.sqlite_embedding_store import SqliteEmbeddingStore
from locram.adapters.sqlite_page_repo import SqlitePageRepository
from locram.services.page_service import PageService
from locram.vault.writer import ObsidianVaultStore

sqlite_vec = pytest.importorskip("sqlite_vec")

_MODEL_A = "bge-m3"
_MODEL_B = "nomic-embed-text"


def _pack(values: list[float]) -> bytes:
    return struct.pack(f"<{len(values)}f", *values)


@pytest.fixture()
def db_path(tmp_path):
    path = tmp_path / "test.db"
    init_db(path)
    return path


@pytest.fixture()
def store(db_path):
    return SqliteEmbeddingStore(db_path)


@pytest.fixture()
def pages(db_path, tmp_path):
    vault_path = tmp_path / "vault"
    vault_path.mkdir()
    repo = SqlitePageRepository(db_path)
    vault = ObsidianVaultStore(vault_path, db_path=db_path)
    return PageService(repo, vault)


def _make_page(pages: PageService, title: str = "Test") -> str:
    page = pages.create_page(title, content="test content")
    return page.id


class TestFindUnembedded:
    def test_returns_page_without_any_embedding(self, store, pages):
        page_id = _make_page(pages)
        result = store.find_unembedded(limit=100)
        assert page_id in result

    def test_excludes_page_with_any_content_embedding(self, store, pages):
        page_id = _make_page(pages)
        store.store(page_id, "content", _pack([0.1, 0.2]), _MODEL_B, 2)
        result = store.find_unembedded(limit=100)
        assert page_id not in result

    def test_model_aware_includes_page_with_wrong_model(self, store, pages):
        page_id = _make_page(pages)
        store.store(page_id, "content", _pack([0.1, 0.2]), _MODEL_B, 2)
        result = store.find_unembedded(limit=100, model=_MODEL_A)
        assert page_id in result

    def test_model_aware_excludes_page_with_current_model(self, store, pages):
        page_id = _make_page(pages)
        store.store(page_id, "content", _pack([0.1, 0.2]), _MODEL_A, 2)
        result = store.find_unembedded(limit=100, model=_MODEL_A)
        assert page_id not in result


class TestGetCoverage:
    def test_zero_when_no_embeddings(self, store, pages):
        _make_page(pages)
        coverage = store.get_coverage(model=_MODEL_A)
        assert coverage["searched"] == 0
        assert coverage["total_active"] == 1

    def test_counts_only_matching_model(self, store, pages):
        page_id = _make_page(pages)
        store.store(page_id, "content", _pack([0.1, 0.2]), _MODEL_B, 2)
        coverage_a = store.get_coverage(model=_MODEL_A)
        assert coverage_a["searched"] == 0
        assert coverage_a["total_active"] == 1

    def test_counted_after_store(self, store, pages):
        page_id = _make_page(pages)
        store.store(page_id, "content", _pack([0.1, 0.2]), _MODEL_A, 2)
        coverage = store.get_coverage(model=_MODEL_A)
        assert coverage["searched"] == 1
        assert coverage["total_active"] == 1


class TestFindModelMismatches:
    def test_empty_when_no_other_models(self, store, pages):
        page_id = _make_page(pages)
        store.store(page_id, "content", _pack([0.1, 0.2]), _MODEL_A, 2)
        assert store.find_model_mismatches(model=_MODEL_A) == {}

    def test_returns_other_model_counts(self, store, pages):
        page_id = _make_page(pages)
        store.store(page_id, "content", _pack([0.1, 0.2]), _MODEL_B, 2)
        mismatches = store.find_model_mismatches(model=_MODEL_A)
        assert mismatches == {_MODEL_B: 1}


class TestFindStaleEmbeddings:
    def test_missing_embedding_is_stale(self, store, pages):
        page_id = _make_page(pages)
        stale = store.find_stale_embeddings(model=_MODEL_A)
        assert page_id in stale

    def test_up_to_date_embedding_not_stale(self, store, pages, db_path):
        page_id = _make_page(pages)
        store.store(page_id, "content", _pack([0.1, 0.2]), _MODEL_A, 2)
        stale = store.find_stale_embeddings(model=_MODEL_A)
        assert page_id not in stale

    def test_different_model_embedding_is_stale(self, store, pages):
        page_id = _make_page(pages)
        store.store(page_id, "content", _pack([0.1, 0.2]), _MODEL_B, 2)
        stale = store.find_stale_embeddings(model=_MODEL_A)
        assert page_id in stale

    def test_outdated_embedding_is_stale(self, store, pages, db_path):
        page_id = _make_page(pages)
        store.store(page_id, "content", _pack([0.1, 0.2]), _MODEL_A, 2)
        time.sleep(1.1)
        SqlitePageRepository(db_path).update(page_id, content="updated content")
        stale = store.find_stale_embeddings(model=_MODEL_A)
        assert page_id in stale


class TestSearchSimilar:
    def test_filters_by_model(self, store, pages):
        page_id = _make_page(pages, "Relevant Note")
        store.store(page_id, "content", _pack([1.0, 0.0, 0.0, 0.0]), _MODEL_A, 4)
        query = _pack([1.0, 0.0, 0.0, 0.0])
        results_a = store.search_similar(query, model=_MODEL_A, limit=10)
        results_b = store.search_similar(query, model=_MODEL_B, limit=10)
        assert any(result["id"] == page_id for result in results_a)
        assert not any(result["id"] == page_id for result in results_b)

    def test_filters_by_field(self, store, pages):
        page_id = _make_page(pages, "Test Note")
        store.store(page_id, "content", _pack([1.0, 0.0, 0.0, 0.0]), _MODEL_A, 4)
        query = _pack([1.0, 0.0, 0.0, 0.0])
        results_content = store.search_similar(query, model=_MODEL_A, limit=10, field="content")
        results_meta = store.search_similar(query, model=_MODEL_A, limit=10, field="meta")
        assert any(result["id"] == page_id for result in results_content)
        assert not any(result["id"] == page_id for result in results_meta)

    def test_closer_vector_ranks_higher(self, store, pages):
        page_close = _make_page(pages, "Close Note")
        page_far = _make_page(pages, "Far Note")
        store.store(page_close, "content", _pack([0.9, 0.1, 0.0, 0.0]), _MODEL_A, 4)
        store.store(page_far, "content", _pack([0.0, 0.0, 1.0, 0.0]), _MODEL_A, 4)
        query = _pack([1.0, 0.0, 0.0, 0.0])
        results = store.search_similar(query, model=_MODEL_A, limit=10)
        ids = [result["id"] for result in results]
        assert ids.index(page_close) < ids.index(page_far)

    def test_result_shape(self, store, pages):
        page_id = _make_page(pages, "Shape Test")
        store.store(page_id, "content", _pack([1.0, 0.0]), _MODEL_A, 2)
        query = _pack([1.0, 0.0])
        results = store.search_similar(query, model=_MODEL_A, limit=5)
        assert len(results) == 1
        hit = results[0]
        assert set(hit.keys()) == {"id", "title", "type", "status", "distance"}
        assert isinstance(hit["distance"], float)
