"""OllamaEmbeddingProvider unit tests (HTTP fully mocked)."""

import json
import unittest.mock
import urllib.error
import urllib.request
from io import BytesIO

import pytest

from locram.adapters.ollama_provider import OllamaEmbeddingProvider

_MODEL = "bge-m3"
_BASE_URL = "http://localhost:11434"


def _make_response(values: list[float]) -> unittest.mock.MagicMock:
    body = json.dumps({"embeddings": [values]}).encode()
    response = unittest.mock.MagicMock()
    response.read.return_value = body
    response.__enter__ = lambda self: self
    response.__exit__ = unittest.mock.MagicMock(return_value=False)
    return response


class TestEmbedSuccess:
    def test_returns_float_list(self):
        provider = OllamaEmbeddingProvider(_BASE_URL, _MODEL)
        expected = [0.1, 0.2, 0.3]
        with unittest.mock.patch("urllib.request.urlopen", return_value=_make_response(expected)):
            result = provider.embed("hello world")
        assert result == expected

    def test_dimension_cached_after_first_call(self):
        provider = OllamaEmbeddingProvider(_BASE_URL, _MODEL)
        with unittest.mock.patch(
            "urllib.request.urlopen", return_value=_make_response([0.1, 0.2, 0.3])
        ):
            provider.embed("test")
        assert provider._dimension == 3

    def test_model_name_matches_init(self):
        provider = OllamaEmbeddingProvider(_BASE_URL, _MODEL)
        assert provider.model_name == _MODEL


class TestEmbedNoteText:
    def test_concatenates_title_and_content(self):
        provider = OllamaEmbeddingProvider(_BASE_URL, _MODEL)
        captured: list[str] = []

        def fake_urlopen(request, timeout=None):
            payload = json.loads(request.data)
            captured.append(payload["input"])
            return _make_response([0.1])

        with unittest.mock.patch("urllib.request.urlopen", side_effect=fake_urlopen):
            provider.embed_note("My Title", "Some content here.")

        assert captured[0] == "My Title\n\nSome content here."

    def test_title_only_when_content_empty(self):
        provider = OllamaEmbeddingProvider(_BASE_URL, _MODEL)
        captured: list[str] = []

        def fake_urlopen(request, timeout=None):
            payload = json.loads(request.data)
            captured.append(payload["input"])
            return _make_response([0.1])

        with unittest.mock.patch("urllib.request.urlopen", side_effect=fake_urlopen):
            provider.embed_note("My Title", "")

        assert captured[0] == "My Title"

    def test_title_only_when_content_whitespace(self):
        provider = OllamaEmbeddingProvider(_BASE_URL, _MODEL)
        captured: list[str] = []

        def fake_urlopen(request, timeout=None):
            payload = json.loads(request.data)
            captured.append(payload["input"])
            return _make_response([0.1])

        with unittest.mock.patch("urllib.request.urlopen", side_effect=fake_urlopen):
            provider.embed_note("My Title", "   ")

        assert captured[0] == "My Title"


class TestEmbedErrors:
    def test_non_200_raises_runtime_error(self):
        provider = OllamaEmbeddingProvider(_BASE_URL, _MODEL)
        http_error = urllib.error.HTTPError(
            url=f"{_BASE_URL}/api/embed", code=404, msg="Not Found", hdrs={}, fp=BytesIO()
        )
        with (
            unittest.mock.patch("urllib.request.urlopen", side_effect=http_error),
            pytest.raises(RuntimeError, match="HTTP 404"),
        ):
            provider.embed("hello")

    def test_connection_error_raises_runtime_error(self):
        provider = OllamaEmbeddingProvider(_BASE_URL, _MODEL)
        url_error = urllib.error.URLError(reason="Connection refused")
        with (
            unittest.mock.patch("urllib.request.urlopen", side_effect=url_error),
            pytest.raises(RuntimeError, match="Cannot reach Ollama"),
        ):
            provider.embed("hello")

    def test_invalid_json_raises_runtime_error(self):
        provider = OllamaEmbeddingProvider(_BASE_URL, _MODEL)
        response = unittest.mock.MagicMock()
        response.read.return_value = b"not json"
        response.__enter__ = lambda self: self
        response.__exit__ = unittest.mock.MagicMock(return_value=False)
        with (
            unittest.mock.patch("urllib.request.urlopen", return_value=response),
            pytest.raises(RuntimeError, match="invalid JSON"),
        ):
            provider.embed("hello")

    def test_missing_embeddings_field_raises_runtime_error(self):
        provider = OllamaEmbeddingProvider(_BASE_URL, _MODEL)
        response = unittest.mock.MagicMock()
        response.read.return_value = json.dumps({"something": "else"}).encode()
        response.__enter__ = lambda self: self
        response.__exit__ = unittest.mock.MagicMock(return_value=False)
        with (
            unittest.mock.patch("urllib.request.urlopen", return_value=response),
            pytest.raises(RuntimeError, match="missing 'embeddings'"),
        ):
            provider.embed("hello")
