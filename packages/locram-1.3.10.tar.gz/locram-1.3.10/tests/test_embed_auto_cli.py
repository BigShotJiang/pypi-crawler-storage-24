from unittest.mock import Mock

from click.testing import CliRunner

import locram.entrypoints.cli as cli_mod


class TestSyncPendingMarker:
    def test_sync_touches_pending_when_auto_enabled_and_changes_exist(self, monkeypatch):
        runner = CliRunner()
        monkeypatch.setattr(cli_mod, "init_db", lambda: None)
        monkeypatch.setattr(cli_mod, "LOCRAM_EMBED_AUTO_ENABLED", True)

        state = Mock()
        monkeypatch.setattr(cli_mod, "EmbeddingRunState", lambda: state)

        class FakeVault:
            def sync(self, file_path):
                return {"inserted": 1, "updated": 0, "skipped": 0, "deleted": 0, "errors": []}

        monkeypatch.setattr(cli_mod, "ObsidianVaultStore", FakeVault)

        result = runner.invoke(cli_mod.main, ["sync"])

        assert result.exit_code == 0
        state.touch_pending.assert_called_once()

    def test_sync_does_not_touch_pending_when_only_skipped(self, monkeypatch):
        runner = CliRunner()
        monkeypatch.setattr(cli_mod, "init_db", lambda: None)
        monkeypatch.setattr(cli_mod, "LOCRAM_EMBED_AUTO_ENABLED", True)

        state = Mock()
        monkeypatch.setattr(cli_mod, "EmbeddingRunState", lambda: state)

        class FakeVault:
            def sync(self, file_path):
                return {"inserted": 0, "updated": 0, "skipped": 3, "deleted": 0, "errors": []}

        monkeypatch.setattr(cli_mod, "ObsidianVaultStore", FakeVault)

        result = runner.invoke(cli_mod.main, ["sync"])

        assert result.exit_code == 0
        state.touch_pending.assert_not_called()

    def test_sync_does_not_touch_pending_when_auto_disabled(self, monkeypatch):
        runner = CliRunner()
        monkeypatch.setattr(cli_mod, "init_db", lambda: None)
        monkeypatch.setattr(cli_mod, "LOCRAM_EMBED_AUTO_ENABLED", False)

        state = Mock()
        monkeypatch.setattr(cli_mod, "EmbeddingRunState", lambda: state)

        class FakeVault:
            def sync(self, file_path):
                return {"inserted": 1, "updated": 0, "skipped": 0, "deleted": 0, "errors": []}

        monkeypatch.setattr(cli_mod, "ObsidianVaultStore", FakeVault)

        result = runner.invoke(cli_mod.main, ["sync"])

        assert result.exit_code == 0
        state.touch_pending.assert_not_called()


class TestEmbedAutoRun:
    def test_noop_when_auto_disabled(self, monkeypatch):
        runner = CliRunner()
        monkeypatch.setattr(cli_mod, "init_db", lambda: None)
        monkeypatch.setattr(cli_mod, "LOCRAM_EMBED_AUTO_ENABLED", False)

        result = runner.invoke(cli_mod.main, ["embed-auto-run"])

        assert result.exit_code == 0
        assert "auto embedding disabled" in result.output

    def test_noop_when_provider_not_configured(self, monkeypatch):
        runner = CliRunner()
        monkeypatch.setattr(cli_mod, "init_db", lambda: None)
        monkeypatch.setattr(cli_mod, "LOCRAM_EMBED_AUTO_ENABLED", True)
        monkeypatch.setattr(cli_mod, "embedding_provider_is_configured", lambda: False)

        result = runner.invoke(cli_mod.main, ["embed-auto-run"])

        assert result.exit_code == 0
        assert "embedding provider not configured" in result.output

    def test_noop_when_pending_missing(self, monkeypatch):
        runner = CliRunner()
        monkeypatch.setattr(cli_mod, "init_db", lambda: None)
        monkeypatch.setattr(cli_mod, "LOCRAM_EMBED_AUTO_ENABLED", True)
        monkeypatch.setattr(cli_mod, "embedding_provider_is_configured", lambda: True)

        state = Mock()
        state.pending_exists.return_value = False
        monkeypatch.setattr(cli_mod, "EmbeddingRunState", lambda: state)

        result = runner.invoke(cli_mod.main, ["embed-auto-run"])

        assert result.exit_code == 0
        assert "no pending embedding work" in result.output

    def test_noop_when_quiet_period_not_reached(self, monkeypatch):
        runner = CliRunner()
        monkeypatch.setattr(cli_mod, "init_db", lambda: None)
        monkeypatch.setattr(cli_mod, "LOCRAM_EMBED_AUTO_ENABLED", True)
        monkeypatch.setattr(cli_mod, "LOCRAM_EMBED_QUIET_SECONDS", 60)
        monkeypatch.setattr(cli_mod, "embedding_provider_is_configured", lambda: True)

        state = Mock()
        state.pending_exists.return_value = True
        state.pending_age_seconds.return_value = 10
        monkeypatch.setattr(cli_mod, "EmbeddingRunState", lambda: state)

        result = runner.invoke(cli_mod.main, ["embed-auto-run"])

        assert result.exit_code == 0
        assert "quiet period not reached" in result.output

    def test_runs_service_and_clears_pending_when_queue_drained(self, monkeypatch):
        runner = CliRunner()
        monkeypatch.setattr(cli_mod, "init_db", lambda: None)
        monkeypatch.setattr(cli_mod, "LOCRAM_EMBED_AUTO_ENABLED", True)
        monkeypatch.setattr(cli_mod, "LOCRAM_EMBED_QUIET_SECONDS", 60)
        monkeypatch.setattr(cli_mod, "LOCRAM_EMBED_BATCH_SIZE", 50)
        monkeypatch.setattr(cli_mod, "embedding_provider_is_configured", lambda: True)

        state = Mock()
        state.pending_exists.return_value = True
        state.pending_age_seconds.return_value = 100
        state.acquire_lock.return_value = True
        monkeypatch.setattr(cli_mod, "EmbeddingRunState", lambda: state)

        service = Mock()
        service.embed_stale.return_value = {
            "embedded": 2,
            "skipped": 0,
            "failed": 0,
            "model": "bge-m3",
        }
        service.has_stale.return_value = False
        monkeypatch.setattr(cli_mod, "make_embedding_service", lambda: service)

        result = runner.invoke(cli_mod.main, ["embed-auto-run"])

        assert result.exit_code == 0
        state.clear_pending.assert_called_once()
        state.release_lock.assert_called_once()
        assert '"ran": true' in result.output.lower()

    def test_runs_service_and_keeps_pending_when_stale_remains(self, monkeypatch):
        runner = CliRunner()
        monkeypatch.setattr(cli_mod, "init_db", lambda: None)
        monkeypatch.setattr(cli_mod, "LOCRAM_EMBED_AUTO_ENABLED", True)
        monkeypatch.setattr(cli_mod, "LOCRAM_EMBED_QUIET_SECONDS", 60)
        monkeypatch.setattr(cli_mod, "LOCRAM_EMBED_BATCH_SIZE", 50)
        monkeypatch.setattr(cli_mod, "embedding_provider_is_configured", lambda: True)

        state = Mock()
        state.pending_exists.return_value = True
        state.pending_age_seconds.return_value = 100
        state.acquire_lock.return_value = True
        monkeypatch.setattr(cli_mod, "EmbeddingRunState", lambda: state)

        service = Mock()
        service.embed_stale.return_value = {
            "embedded": 2,
            "skipped": 0,
            "failed": 0,
            "model": "bge-m3",
        }
        service.has_stale.return_value = True
        monkeypatch.setattr(cli_mod, "make_embedding_service", lambda: service)

        result = runner.invoke(cli_mod.main, ["embed-auto-run"])

        assert result.exit_code == 0
        state.clear_pending.assert_not_called()
        state.release_lock.assert_called_once()

    def test_runs_service_and_keeps_pending_on_failures(self, monkeypatch):
        runner = CliRunner()
        monkeypatch.setattr(cli_mod, "init_db", lambda: None)
        monkeypatch.setattr(cli_mod, "LOCRAM_EMBED_AUTO_ENABLED", True)
        monkeypatch.setattr(cli_mod, "LOCRAM_EMBED_QUIET_SECONDS", 60)
        monkeypatch.setattr(cli_mod, "LOCRAM_EMBED_BATCH_SIZE", 50)
        monkeypatch.setattr(cli_mod, "embedding_provider_is_configured", lambda: True)

        state = Mock()
        state.pending_exists.return_value = True
        state.pending_age_seconds.return_value = 100
        state.acquire_lock.return_value = True
        monkeypatch.setattr(cli_mod, "EmbeddingRunState", lambda: state)

        service = Mock()
        service.embed_stale.return_value = {
            "embedded": 0,
            "skipped": 0,
            "failed": 1,
            "model": "bge-m3",
        }
        service.has_stale.return_value = False
        monkeypatch.setattr(cli_mod, "make_embedding_service", lambda: service)

        result = runner.invoke(cli_mod.main, ["embed-auto-run"])

        assert result.exit_code == 0
        state.clear_pending.assert_not_called()
        state.release_lock.assert_called_once()
