"""render_mermaid helper and MCP tool behavior."""

import subprocess
import unittest.mock

import pytest

import locram.entrypoints.server as server_module
from locram.vault.mermaid import render_mermaid

_SIMPLE_DIAGRAM = "graph TD\n  A --> B"
_MMDC_PATH = "/usr/bin/mmdc"


@pytest.fixture()
def vault_dir(tmp_path):
    return tmp_path / "vault"


class TestValidation:
    def test_empty_name_raises(self, vault_dir):
        with pytest.raises(ValueError, match="must not be empty"):
            render_mermaid(_SIMPLE_DIAGRAM, "", vault=vault_dir)

    def test_path_traversal_raises(self, vault_dir):
        with pytest.raises(ValueError, match="no path separators"):
            render_mermaid(_SIMPLE_DIAGRAM, "../evil", vault=vault_dir)

    def test_subdirectory_in_name_raises(self, vault_dir):
        with pytest.raises(ValueError, match="no path separators"):
            render_mermaid(_SIMPLE_DIAGRAM, "subdir/file", vault=vault_dir)

    def test_unsupported_format_raises(self, vault_dir):
        with pytest.raises(ValueError, match="output_format must be one of"):
            render_mermaid(_SIMPLE_DIAGRAM, "test", output_format="pdf", vault=vault_dir)


class TestMmdcMissing:
    def test_raises_file_not_found_when_mmdc_absent(self, vault_dir):
        with (
            unittest.mock.patch("locram.vault.mermaid.shutil.which", return_value=None),
            pytest.raises(FileNotFoundError, match="mmdc not found"),
        ):
            render_mermaid(_SIMPLE_DIAGRAM, "test", vault=vault_dir)


class TestMmdcFailure:
    def test_raises_runtime_error_on_nonzero_exit(self, vault_dir):
        failed = unittest.mock.MagicMock(returncode=1, stderr="parse error at line 2", stdout="")
        with (
            unittest.mock.patch("locram.vault.mermaid.shutil.which", return_value=_MMDC_PATH),
            unittest.mock.patch("locram.vault.mermaid.subprocess.run", return_value=failed),
            pytest.raises(RuntimeError, match="mmdc exited with code 1"),
        ):
            render_mermaid(_SIMPLE_DIAGRAM, "test", vault=vault_dir)

    def test_stderr_included_in_error_message(self, vault_dir):
        failed = unittest.mock.MagicMock(returncode=1, stderr="unexpected token", stdout="")
        with (
            unittest.mock.patch("locram.vault.mermaid.shutil.which", return_value=_MMDC_PATH),
            unittest.mock.patch("locram.vault.mermaid.subprocess.run", return_value=failed),
            pytest.raises(RuntimeError, match="unexpected token"),
        ):
            render_mermaid(_SIMPLE_DIAGRAM, "test", vault=vault_dir)

    def test_timeout_raises_timeout_expired(self, vault_dir):
        timeout = subprocess.TimeoutExpired(cmd=["mmdc"], timeout=30)
        with (
            unittest.mock.patch("locram.vault.mermaid.shutil.which", return_value=_MMDC_PATH),
            unittest.mock.patch("locram.vault.mermaid.subprocess.run", side_effect=timeout),
            pytest.raises(subprocess.TimeoutExpired),
        ):
            render_mermaid(_SIMPLE_DIAGRAM, "test", vault=vault_dir)


class TestSuccessfulRender:
    def _success_result(self):
        return unittest.mock.MagicMock(returncode=0, stderr="", stdout="")

    def test_returns_correct_output_path(self, vault_dir):
        with (
            unittest.mock.patch("locram.vault.mermaid.shutil.which", return_value=_MMDC_PATH),
            unittest.mock.patch(
                "locram.vault.mermaid.subprocess.run", return_value=self._success_result()
            ),
        ):
            path = render_mermaid(_SIMPLE_DIAGRAM, "my-diagram", vault=vault_dir)
        assert path == vault_dir / "attachments" / "my-diagram.svg"

    def test_output_format_used_in_filename(self, vault_dir):
        with (
            unittest.mock.patch("locram.vault.mermaid.shutil.which", return_value=_MMDC_PATH),
            unittest.mock.patch(
                "locram.vault.mermaid.subprocess.run", return_value=self._success_result()
            ),
        ):
            path = render_mermaid(
                _SIMPLE_DIAGRAM, "chart", output_format="png", vault=vault_dir
            )
        assert path.name == "chart.png"

    def test_mmdc_called_with_quiet_flag(self, vault_dir):
        with (
            unittest.mock.patch("locram.vault.mermaid.shutil.which", return_value=_MMDC_PATH),
            unittest.mock.patch(
                "locram.vault.mermaid.subprocess.run", return_value=self._success_result()
            ) as mock_run,
        ):
            render_mermaid(_SIMPLE_DIAGRAM, "test", vault=vault_dir)
        assert "-q" in mock_run.call_args[0][0]

    def test_attachments_dir_created_if_missing(self, vault_dir):
        assert not (vault_dir / "attachments").exists()
        with (
            unittest.mock.patch("locram.vault.mermaid.shutil.which", return_value=_MMDC_PATH),
            unittest.mock.patch(
                "locram.vault.mermaid.subprocess.run", return_value=self._success_result()
            ),
        ):
            render_mermaid(_SIMPLE_DIAGRAM, "test", vault=vault_dir)
        assert (vault_dir / "attachments").exists()


class TestMcpToolResponseShape:
    def test_success_response_keys(self, tmp_path):
        fake_path = tmp_path / "diagram.svg"
        with unittest.mock.patch.object(
            server_module, "_render_mermaid", return_value=fake_path
        ):
            result = server_module.render_mermaid("diagram", _SIMPLE_DIAGRAM)
        assert result["rendered"] is True
        assert "path" in result
        assert result["filename"] == "diagram.svg"
        assert result["embed"] == "![[diagram.svg]]"

    def test_missing_mmdc_returns_error_dict(self):
        with unittest.mock.patch(
            "locram.entrypoints.server._render_mermaid",
            side_effect=FileNotFoundError("mmdc not found"),
        ):
            result = server_module.render_mermaid("x", _SIMPLE_DIAGRAM)
        assert "error" in result
        assert "mmdc" in result["error"]

    def test_invalid_name_returns_error_dict(self):
        with unittest.mock.patch(
            "locram.entrypoints.server._render_mermaid",
            side_effect=ValueError("no path separators"),
        ):
            result = server_module.render_mermaid("../bad", _SIMPLE_DIAGRAM)
        assert "error" in result

    def test_timeout_returns_error_dict(self):
        timeout = subprocess.TimeoutExpired(cmd=["mmdc"], timeout=30)
        with unittest.mock.patch(
            "locram.entrypoints.server._render_mermaid", side_effect=timeout
        ):
            result = server_module.render_mermaid("x", _SIMPLE_DIAGRAM)
        assert "error" in result
        assert "timed out" in result["error"]
