from unittest.mock import Mock

from locram.models.page import Page
from locram.services.embedding_service import EmbeddingService


def make_page(page_id: str, title: str = "Title", content: str = "Body") -> Page:
    return Page(id=page_id, title=title, content=content)


class TestEmbeddingService:
    def test_embed_stale_processes_selected_pages(self):
        repo = Mock()
        store = Mock()
        provider = Mock()
        provider.model_name = "bge-m3"
        provider.embed_note.return_value = [0.1, 0.2]
        store.find_stale_embeddings.return_value = ["p1", "p2"]
        store.find_model_mismatches.return_value = {}
        repo.get.side_effect = [make_page("p1"), make_page("p2")]

        service = EmbeddingService(repo, store, provider)

        result = service.embed_stale(limit=10)

        assert result == {"embedded": 2, "skipped": 0, "failed": 0, "model": "bge-m3"}
        assert store.store.call_count == 2

    def test_embed_stale_counts_missing_pages_as_skipped(self):
        repo = Mock()
        store = Mock()
        provider = Mock()
        provider.model_name = "bge-m3"
        store.find_stale_embeddings.return_value = ["p1", "missing"]
        store.find_model_mismatches.return_value = {}
        provider.embed_note.return_value = [0.1, 0.2]
        repo.get.side_effect = [make_page("p1"), None]

        service = EmbeddingService(repo, store, provider)

        result = service.embed_stale(limit=10)

        assert result == {"embedded": 1, "skipped": 1, "failed": 0, "model": "bge-m3"}

    def test_embed_stale_counts_provider_failures(self):
        repo = Mock()
        store = Mock()
        provider = Mock()
        provider.model_name = "bge-m3"
        provider.embed_note.side_effect = RuntimeError("ollama down")
        store.find_stale_embeddings.return_value = ["p1"]
        store.find_model_mismatches.return_value = {}
        repo.get.return_value = make_page("p1")

        service = EmbeddingService(repo, store, provider)

        result = service.embed_stale(limit=10)

        assert result == {"embedded": 0, "skipped": 0, "failed": 1, "model": "bge-m3"}
        store.store.assert_not_called()

    def test_embed_all_uses_repo_list_pages(self):
        repo = Mock()
        store = Mock()
        provider = Mock()
        provider.model_name = "bge-m3"
        provider.embed_note.return_value = [0.1, 0.2]
        store.find_model_mismatches.return_value = {}
        repo.list_pages.return_value = [{"id": "p1"}, {"id": "p2"}]
        repo.get.side_effect = [make_page("p1"), make_page("p2")]

        service = EmbeddingService(repo, store, provider)

        result = service.embed_all(limit=5)

        assert result == {"embedded": 2, "skipped": 0, "failed": 0, "model": "bge-m3"}
        repo.list_pages.assert_called_once_with(status="active", limit=5)

    def test_has_stale_returns_true_when_any_stale_exists(self):
        repo = Mock()
        store = Mock()
        provider = Mock()
        provider.model_name = "bge-m3"
        store.find_stale_embeddings.return_value = ["p1"]

        service = EmbeddingService(repo, store, provider)

        assert service.has_stale() is True

    def test_warning_is_included_when_mismatches_exist(self):
        repo = Mock()
        store = Mock()
        provider = Mock()
        provider.model_name = "bge-m3"
        provider.embed_note.return_value = [0.1, 0.2]
        store.find_stale_embeddings.return_value = ["p1"]
        store.find_model_mismatches.return_value = {"nomic-embed-text": 3}
        repo.get.return_value = make_page("p1")

        service = EmbeddingService(repo, store, provider)

        result = service.embed_stale(limit=10)

        assert "warning" in result
        assert "nomic-embed-text" in result["warning"]
