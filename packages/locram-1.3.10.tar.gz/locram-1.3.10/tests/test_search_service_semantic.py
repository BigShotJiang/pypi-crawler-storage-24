"""SearchService semantic and hybrid search unit tests."""

import struct
import unittest.mock

from locram.services.search_service import SearchService

_MODEL = "bge-m3"


def _pack(values: list[float]) -> bytes:
    return struct.pack(f"<{len(values)}f", *values)


def _make_provider(
    model: str = _MODEL, values: list[float] | None = None
) -> unittest.mock.MagicMock:
    provider = unittest.mock.MagicMock()
    provider.model_name = model
    provider.embed.return_value = values or [0.1, 0.2, 0.3]
    return provider


def _make_store(
    search_results: list[dict] | None = None,
    coverage: dict | None = None,
    mismatches: dict | None = None,
    embedding_row: dict | None = None,
) -> unittest.mock.MagicMock:
    store = unittest.mock.MagicMock()
    store.search_similar.return_value = search_results or []
    store.get_coverage.return_value = coverage or {"searched": 5, "total_active": 10}
    store.find_model_mismatches.return_value = mismatches or {}
    store.get.return_value = embedding_row
    return store


def _make_repo(fts_results: list[dict] | None = None) -> unittest.mock.MagicMock:
    repo = unittest.mock.MagicMock()
    repo.search_fts.return_value = fts_results or []
    return repo


class TestSemanticSearchUnconfigured:
    def test_returns_error_when_no_provider(self):
        service = SearchService(_make_repo())
        result = service.semantic_search("test query")
        assert "error" in result
        assert result["results"] == []

    def test_returns_error_when_no_store(self):
        service = SearchService(_make_repo(), provider=_make_provider())
        result = service.semantic_search("test query")
        assert "error" in result

    def test_coverage_uses_real_total_active_when_store_available(self):
        store = _make_store(coverage={"searched": 0, "total_active": 42})
        service = SearchService(_make_repo(), embedding_store=store)
        result = service.semantic_search("test query")
        assert result["coverage"]["total_active"] == 42

    def test_provider_error_returns_error_dict(self):
        provider = _make_provider()
        provider.embed.side_effect = RuntimeError("Cannot reach Ollama")
        store = _make_store()
        service = SearchService(_make_repo(), embedding_store=store, provider=provider)
        result = service.semantic_search("test query")
        assert "error" in result
        assert "Cannot reach Ollama" in result["error"]
        assert result["results"] == []

    def test_store_error_returns_error_dict(self):
        store = _make_store(coverage={"searched": 3, "total_active": 12})
        store.search_similar.side_effect = RuntimeError("sqlite-vec not installed")
        service = SearchService(_make_repo(), embedding_store=store, provider=_make_provider())
        result = service.semantic_search("test query")
        assert "error" in result
        assert "sqlite-vec" in result["error"]
        assert result["results"] == []
        assert result["coverage"]["total_active"] == 12


class TestSemanticSearch:
    def test_query_packed_as_little_endian_float32(self):
        provider = _make_provider(values=[1.0, 2.0, 3.0])
        store = _make_store()
        service = SearchService(_make_repo(), embedding_store=store, provider=provider)
        service.semantic_search("test")
        call_args = store.search_similar.call_args
        query_bytes = call_args[0][0]
        expected = struct.pack("<3f", 1.0, 2.0, 3.0)
        assert query_bytes == expected

    def test_coverage_included_in_response(self):
        provider = _make_provider()
        store = _make_store(coverage={"searched": 3, "total_active": 7})
        service = SearchService(_make_repo(), embedding_store=store, provider=provider)
        result = service.semantic_search("test")
        assert result["coverage"] == {"searched": 3, "total_active": 7}

    def test_warning_when_model_mismatch(self):
        provider = _make_provider()
        store = _make_store(mismatches={"nomic-embed-text": 50})
        service = SearchService(_make_repo(), embedding_store=store, provider=provider)
        result = service.semantic_search("test")
        assert "warning" in result
        assert "nomic-embed-text" in result["warning"]

    def test_no_warning_when_no_mismatch(self):
        provider = _make_provider()
        store = _make_store(mismatches={})
        service = SearchService(_make_repo(), embedding_store=store, provider=provider)
        result = service.semantic_search("test")
        assert "warning" not in result


class TestFindSimilar:
    def test_uses_semantic_neighbors_when_current_model_embedding_exists(self):
        repo = _make_repo()
        repo.get.return_value = unittest.mock.MagicMock(id="p1", title="A note")
        store = _make_store(
            search_results=[
                {
                    "id": "p1",
                    "title": "A note",
                    "type": "permanent",
                    "status": "active",
                    "distance": 0.0,
                },
                {
                    "id": "p2",
                    "title": "Neighbor",
                    "type": "permanent",
                    "status": "active",
                    "distance": 0.1,
                },
            ],
            embedding_row={"embedding": _pack([0.1, 0.2, 0.3]), "model": _MODEL},
        )
        service = SearchService(repo, embedding_store=store, provider=_make_provider())

        result = service.find_similar("p1", limit=10)

        assert result[0]["id"] == "p2"
        assert result[0]["sources"] == ["semantic"]
        store.search_similar.assert_called_once()

    def test_falls_back_to_lexical_when_embedding_missing(self):
        repo = _make_repo(
            fts_results=[
                {
                    "id": "p1",
                    "title": "A note",
                    "type": "permanent",
                    "status": "active",
                    "snippet": "x",
                },
                {
                    "id": "p2",
                    "title": "Sibling",
                    "type": "permanent",
                    "status": "active",
                    "snippet": "y",
                },
            ]
        )
        repo.get.return_value = unittest.mock.MagicMock(id="p1", title="A note")
        store = _make_store(embedding_row=None)
        service = SearchService(repo, embedding_store=store, provider=_make_provider())

        result = service.find_similar("p1", limit=10)

        assert result[0]["id"] == "p2"
        assert result[0]["sources"] == ["fts"]
        store.search_similar.assert_not_called()

    def test_falls_back_to_lexical_when_embedding_model_mismatches(self):
        repo = _make_repo(
            fts_results=[
                {"id": "p1", "title": "A note", "type": "permanent", "status": "active"},
                {"id": "p2", "title": "Sibling", "type": "permanent", "status": "active"},
            ]
        )
        repo.get.return_value = unittest.mock.MagicMock(id="p1", title="A note")
        store = _make_store(embedding_row={"embedding": _pack([0.1, 0.2]), "model": "old-model"})
        service = SearchService(repo, embedding_store=store, provider=_make_provider())

        result = service.find_similar("p1", limit=10)

        assert result[0]["sources"] == ["fts"]

    def test_falls_back_to_lexical_when_semantic_search_errors(self):
        repo = _make_repo(
            fts_results=[
                {"id": "p1", "title": "A note", "type": "permanent", "status": "active"},
                {"id": "p2", "title": "Sibling", "type": "permanent", "status": "active"},
            ]
        )
        repo.get.return_value = unittest.mock.MagicMock(id="p1", title="A note")
        store = _make_store(embedding_row={"embedding": _pack([0.1, 0.2]), "model": _MODEL})
        store.search_similar.side_effect = RuntimeError("sqlite-vec missing")
        service = SearchService(repo, embedding_store=store, provider=_make_provider())

        result = service.find_similar("p1", limit=10)

        assert result[0]["sources"] == ["fts"]


class TestHybridSearchDegradation:
    def test_returns_fts_only_when_unconfigured(self):
        fts_hits = [
            {"id": "abc", "title": "Hit", "type": "fleeting", "status": "active", "snippet": "..."}
        ]
        service = SearchService(_make_repo(fts_results=fts_hits))
        result = service.hybrid_search("test")
        assert len(result["results"]) == 1
        assert "warning" in result
        assert result["results"][0]["sources"] == ["fts"]

    def test_coverage_zeros_when_neither_store_nor_provider(self):
        service = SearchService(_make_repo())
        result = service.hybrid_search("test")
        assert result["coverage"] == {"searched": 0, "total_active": 0}

    def test_coverage_uses_real_total_active_when_store_available(self):
        store = _make_store(coverage={"searched": 0, "total_active": 7})
        service = SearchService(_make_repo(), embedding_store=store)
        result = service.hybrid_search("test")
        assert result["coverage"]["total_active"] == 7

    def test_fts_hits_not_mutated_on_degrade(self):
        original = {"id": "x", "title": "T", "type": "fleeting", "status": "active"}
        fts_hits = [original]
        service = SearchService(_make_repo(fts_results=fts_hits))
        service.hybrid_search("test")
        assert "sources" not in original

    def test_provider_error_falls_back_to_fts(self):
        provider = _make_provider()
        provider.embed.side_effect = RuntimeError("Cannot reach Ollama")
        fts_hits = [
            {"id": "abc", "title": "Hit", "type": "fleeting", "status": "active"}
        ]
        store = _make_store()
        service = SearchService(
            _make_repo(fts_results=fts_hits), embedding_store=store, provider=provider
        )
        result = service.hybrid_search("test")
        assert "error" in result
        assert len(result["results"]) == 1
        assert result["results"][0]["sources"] == ["fts"]

    def test_store_error_falls_back_to_fts(self):
        store = _make_store(coverage={"searched": 0, "total_active": 8})
        store.search_similar.side_effect = RuntimeError("sqlite-vec not installed")
        fts_hits = [
            {"id": "abc", "title": "Hit", "type": "fleeting", "status": "active"}
        ]
        service = SearchService(
            _make_repo(fts_results=fts_hits), embedding_store=store, provider=_make_provider()
        )
        result = service.hybrid_search("test")
        assert "error" in result
        assert len(result["results"]) == 1
        assert result["results"][0]["sources"] == ["fts"]
        assert result["coverage"]["total_active"] == 8


class TestRrfMerge:
    def _make_service(self):
        return SearchService(_make_repo())

    def test_deduplicates_overlapping_ids(self):
        service = self._make_service()
        fts = [{"id": "a", "title": "A", "type": "fleeting", "status": "active"}]
        vec = [{"id": "a", "title": "A", "type": "fleeting", "status": "active", "distance": 0.1}]
        merged = service._rrf_merge(fts, vec, limit=10)
        assert len(merged) == 1

    def test_lexical_snippet_preserved_after_merge(self):
        service = self._make_service()
        fts = [
            {
                "id": "a", "title": "A", "type": "fleeting",
                "status": "active", "snippet": "found here",
            }
        ]
        vec = [{"id": "a", "title": "A", "type": "fleeting", "status": "active", "distance": 0.1}]
        merged = service._rrf_merge(fts, vec, limit=10)
        assert merged[0]["snippet"] == "found here"

    def test_sources_reflect_both_lists(self):
        service = self._make_service()
        fts = [{"id": "a", "title": "A", "type": "fleeting", "status": "active"}]
        vec = [{"id": "a", "title": "A", "type": "fleeting", "status": "active", "distance": 0.05}]
        merged = service._rrf_merge(fts, vec, limit=10)
        assert set(merged[0]["sources"]) == {"fts", "semantic"}

    def test_fts_only_hit_has_fts_source(self):
        service = self._make_service()
        fts = [{"id": "a", "title": "A", "type": "fleeting", "status": "active"}]
        vec = [{"id": "b", "title": "B", "type": "fleeting", "status": "active", "distance": 0.05}]
        merged = service._rrf_merge(fts, vec, limit=10)
        hit_a = next(hit for hit in merged if hit["id"] == "a")
        assert hit_a["sources"] == ["fts"]

    def test_limit_applied(self):
        service = self._make_service()
        fts = [
            {"id": str(i), "title": str(i), "type": "fleeting", "status": "active"}
            for i in range(10)
        ]
        merged = service._rrf_merge(fts, [], limit=3)
        assert len(merged) == 3
