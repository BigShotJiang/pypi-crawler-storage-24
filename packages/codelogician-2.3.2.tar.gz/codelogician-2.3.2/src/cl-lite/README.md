# codelogician-lite shell

A dependency-free shell script for interacting with CodeLogician.

## Specification

We have a few versions:
- local cl-lite shell version: installed on user's disk
- cloud cl-lite shell version: the most updated version, specified by `https://storage.googleapis.com/imandra-dev-codelogician-releases/codelogician-lite-shell/version.txt`
- CodeLogician CLI version inside the reasoner API: can be obtained by sending an eval request with payload `{"command": "--version"}

Facts:
- if the local cl-lite shell version does not match the cloud cl-lite shell version, it will not work
- there exists multiple CL PyPI versions

## Version check behavior

The shell script includes a built-in update check that compares the local version (from the embedded spec's `__version__`) against the cloud version.

### `--version` flag

Always fetches the cloud version fresh (no cache). Prints the local version and warns if outdated:

```
$ codelogician --version
codelogician-lite-shell 2.1.0
Warning: codelogician 2.2.0 is available. Update with: curl -fsSL codelogician.dev/cl-lite-shell/install.sh | sh
```

### Normal commands (`eval`, `doc`, etc.)

Uses a cached check to avoid network latency on every invocation:

1. On first run, fetches the cloud version and caches the result (timestamp + version) in `~/.cache/codelogician/update-check`.
2. On subsequent runs, reads the cache file. If the cache is older than 24 hours, it re-fetches from the cloud and updates the cache.
3. If the cached cloud version differs from the local version, prints a warning to stderr.
4. If the fetch fails (network error, timeout, non-semver response), the check is silently skipped — it never blocks command execution.
