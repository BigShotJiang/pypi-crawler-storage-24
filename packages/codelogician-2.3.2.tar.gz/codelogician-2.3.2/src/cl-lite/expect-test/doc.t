setup
  $ codelogician() { bash "$TESTDIR"/../shell/codelogician "$@"; }

doc-ref-summary
  $ codelogician doc ref summary
  IML Reference - 250 total entries across 12 modules
  
  Available modules:
    (global): 57 entries
    Int: 20 entries
    LChar: 3 entries
    LString: 18 entries
    List: 47 entries
    Map: 8 entries
    Multiset: 7 entries
    Option: 21 entries
    Real: 18 entries
    Result: 18 entries
    Set: 16 entries
    String: 17 entries


doc-help
  $ codelogician doc --help
  Usage: codelogician doc [OPTIONS] COMMAND [ARGS]...
  
    Documentation, guides and ImandraX reference
  
  Options:
    --help  Show this message and exit.
  
  Commands:
    contents  List the contents of the available documentation
    prompt    Generate a prompt to teach LLMs/Agents how to use ImandraX
    dump      Dump IML overview and API reference to markdown files
    search    Search the entire directory
    view      View a specific chapter or topic in documentation
    ref       IML Reference (built-in functions, types and modules)



