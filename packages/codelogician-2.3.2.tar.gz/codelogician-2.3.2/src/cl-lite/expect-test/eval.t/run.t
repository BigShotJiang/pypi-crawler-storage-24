setup
  $ codelogician() { bash "$TESTDIR"/../../shell/codelogician "$@"; }

top-level-help
  $ codelogician --help
  Usage: codelogician <eval|doc> <subcommand> [options] [file.iml]

eval-check
  $ codelogician eval check $TESTDIR/fixture.iml
  Eval success!

eval-list-vg
  $ codelogician eval list-vg $TESTDIR/fixture.iml
  1: verify (6:7-6:40): fun x -> x > 0 ==> double x > x

eval-check-vg
  $ codelogician eval check-vg $TESTDIR/fixture.iml
  Eval success!
  
  =====VG=====
  
  1: verify (fun x -> x > 0 ==> double x > x)
  proved:
    proof_pp: |-
      { id = 1;
        concl =
  
        |----------------------------------------------------------------------
         x > 0 ==> double x > x
        ;
        view =
        T_deduction {
          premises =
          [("p",
            [{ id = 0;
               concl =
  
               |----------------------------------------------------------------------
                x > 0 ==> double x > x
               ; view = T_deduction {premises = []} }
              ])
            ]}
        }






eval-list-decomp
  $ codelogician eval list-decomp $TESTDIR/fixture.iml
  1: simple_branch

eval-check-decomp
  $ codelogician eval check-decomp $TESTDIR/fixture.iml
  Eval success!
  
  =====Decomp=====
  
  1: decompose simple_branch
  err: null
  errors: []
  regions_str:
  - constraints_str:
    - x <= 0
    invariant_str: x - 1
    model_eval_str: (-1)
    model_str:
      x: '0'
  - constraints_str:
    - x >= 1
    invariant_str: x + 1
    model_eval_str: '2'
    model_str:
      x: '1'



eval-gen-test
  $ codelogician eval gen-test -f simple_branch --lang python $TESTDIR/fixture.iml
  from __future__ import annotations
  
  
  def test_1():
      """test_1
  
      - invariant: x - 1
      - constraints:
          - x <= 0
      """
      result: int = simple_branch(x=0)
      expected: int = -1
      assert result == expected
  
  
  def test_2():
      """test_2
  
      - invariant: x + 1
      - constraints:
          - x >= 1
      """
      result: int = simple_branch(x=1)
      expected: int = 2
      assert result == expected

eval-help
  $ codelogician eval --help
  Usage: codelogician eval [OPTIONS] COMMAND [ARGS]...
  
    Evaluate IML file via ImandraX API
  
  Options:
    --help  Show this message and exit.
  
  Commands:
    check         Evaluate an IML file without VG and decomp.
    list-vg       List verification goals specified by `verify` or...
    check-vg      Check verification goals specified by `verify` or...
    list-decomp   List decomp requests in an IML file.
    check-decomp  Check decomp requests in an IML file.
    gen-test      Generate test cases in Python / TypeScript from region...
