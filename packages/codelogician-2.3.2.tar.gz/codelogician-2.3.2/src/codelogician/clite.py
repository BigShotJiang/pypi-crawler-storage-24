"""
CLI that only includes the eval commands.

For dev-purposes mainly.
"""
#
#   Imandra Inc.
#
#   clite.py
#

import typer

from codelogician import __version__
from codelogician.commands.cmd_eval import app as eval_app

app = typer.Typer(
    name='CodeLogician',
    no_args_is_help=True,
    rich_markup_mode='markdown',
)

# Register all eval commands directly at the top level
for cmd in eval_app.registered_commands:
    app.registered_commands.append(cmd)


@app.callback(invoke_without_command=True)
def _main(
    ctx: typer.Context,
    version: bool = typer.Option(
        False, '--version', is_eager=True, help='Show version and exit.'
    ),
) -> None:
    if version:
        typer.echo(__version__)
        raise typer.Exit()
    elif ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())


if __name__ == '__main__':
    app()
