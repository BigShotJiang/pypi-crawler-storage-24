from __future__ import annotations

from xq_pulse.pulse.dsl import drive, parameter_sweep, pulse_program
from xq_pulse.pulse.program import PulseProgram
from xq_pulse.util import Quantity, unit


def pulsed_odmr(
    start: Quantity,
    stop: Quantity,
    step: Quantity,
    pi_duration: Quantity,
    amplitude: Quantity,
) -> PulseProgram:
    """Return a pulsed ODMR program that sweeps the drive frequency."""
    assert start.is_compatible_with(unit.Hz), "start must have frequency units"
    assert stop.is_compatible_with(unit.Hz), "stop must have frequency units"
    assert step.is_compatible_with(unit.Hz), "step must have frequency units"
    assert pi_duration.is_compatible_with(unit.s), "pi_duration must have time units"
    assert amplitude.is_compatible_with(unit.T), "amplitude must have magnetic field units"

    with pulse_program() as program:
        with parameter_sweep(start=start, stop=stop, step=step) as (_, frequency):
            drive(duration=pi_duration, frequency=frequency, amplitude=amplitude)

    return program
