# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
# See LICENSE file for details.
"""Inline compliance gate — synchronous check before task execution (Layer 11)."""

from pulse.daemons.compliance_validator import HARM_PATTERNS, PII_PATTERNS


def check_task_compliance(task: dict) -> tuple[bool, str]:
    """Check task title + description for harm/PII. Returns (passed, reason)."""
    # Memory tasks are strictly read/write JSON — bypass compliance scanning
    title = task.get("title", "")
    if any(tag in title for tag in ("[EXTRACT_KNOWLEDGE]", "[CLEAN_INTENTS]")):
        return True, ""
    if task.get("domain") == "brain" and task.get("memory_data"):
        return True, ""
    text = f"{title} {task.get('description', '')}"
    for name, pattern in HARM_PATTERNS.items():
        if pattern.search(text):
            return False, f"HARM:{name}"
    for name, pattern in PII_PATTERNS.items():
        if pattern.search(text):
            return False, f"PII:{name}"
    return True, ""
