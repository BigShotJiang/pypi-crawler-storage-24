#!/usr/bin/env python3
# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
# See LICENSE file for details.
"""PULSE Orchestrator (V6) — daemon lifecycle, security in orchestrator_security.py."""
import atexit
import io
import json
import os
import signal
import subprocess
import sys
import time
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

# --- Windows Unicode Fix ---
if os.name == 'nt' and __name__ == '__main__':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

SCRIPT_DIR = Path(__file__).resolve().parent
ROOT_DIR = SCRIPT_DIR.parent.parent

# When run directly, ensure pulse package is importable
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))
from pulse.core.brain_utils import ensure_brain_scaffold, _acquire

from pulse.daemons.orchestrator_security import (
    verify_sealed_environment, verify_immutable_core, enforce_quarantine, load_env_file,
)
from pulse.daemons.orchestrator_schedulers import start_all_schedulers

# --- Core Paths ---
STATE_DIR = ROOT_DIR / "state"
PID_FILE = STATE_DIR / "pulse_orchestrator.pid"
DAEMON_PIDS_FILE = STATE_DIR / "daemon_pids.json"
SAFETY_CHECK = SCRIPT_DIR / "safety_check.py"

# --- Daemon Paths ---
DAEMON_MAP = {
    "claude_daemon": ROOT_DIR / "pulse" / "agents" / "pulse_claude.py",
    "gemini_daemon": ROOT_DIR / "pulse" / "agents" / "pulse_gemini.py",
    "grok_daemon": ROOT_DIR / "pulse" / "agents" / "pulse_grok.py",
    "codex_daemon": ROOT_DIR / "pulse" / "agents" / "pulse_codex.py",
    "bridge_daemon": SCRIPT_DIR / "bridge" / "pulse_bridge.py",
    "memory_dispatcher": SCRIPT_DIR / "bridge" / "memory_dispatcher.py",
    "neural_daemon": SCRIPT_DIR / "neural" / "pulse_neural.py",
    "compliance_daemon": SCRIPT_DIR / "compliance_validator.py",
    "dispatcher_daemon": ROOT_DIR / "pulse" / "tasks" / "pulse_dispatcher.py",
    "api_daemon": ROOT_DIR / "pulse" / "api" / "pulse_api.py",
    "worker_supervisor": SCRIPT_DIR / "worker_supervisor.py",
    "drift_daemon": SCRIPT_DIR / "neural" / "drift_detector.py",
}
DAEMON_LABELS = {
    "claude_daemon": "Claude Watcher", "gemini_daemon": "Gemini Watcher",
    "grok_daemon": "Grok Watcher", "codex_daemon": "Codex Watcher",
    "bridge_daemon": "Log-Evidence Bridge", "memory_dispatcher": "Swarm Memory Dispatcher",
    "neural_daemon": "Neural Interface", "compliance_daemon": "Compliance Validator",
    "dispatcher_daemon": "Task Dispatcher", "api_daemon": "API Gateway",
    "worker_supervisor": "Worker Supervisor",
    "drift_daemon": "Embedding Drift Detector",
}
DAEMON_ALERTS_FILE = STATE_DIR / "daemon_alerts.json"

def _write_daemon_alert(daemon_name: str, exit_code: int, max_restarts: int):
    """Write alert to daemon_alerts.json when a daemon exceeds MAX_RESTARTS."""
    alerts = []
    if DAEMON_ALERTS_FILE.exists():
        try:
            alerts = json.loads(DAEMON_ALERTS_FILE.read_text(encoding="utf-8"))
        except Exception:
            alerts = []
    alerts.append({
        "daemon": daemon_name,
        "label": DAEMON_LABELS.get(daemon_name, daemon_name),
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "max_restarts": max_restarts,
        "exit_code": exit_code,
        "status": "dead",
    })
    try:
        DAEMON_ALERTS_FILE.write_text(json.dumps(alerts, indent=2), encoding="utf-8")
    except Exception as e:
        print(f"[PULSE] Failed to write daemon alert: {e}")


def _is_process_running(pid: int) -> bool:
    if os.name == 'nt':
        try:
            output = subprocess.check_output(
                ["tasklist", "/FI", f"PID eq {pid}"],
                stderr=subprocess.STDOUT, creationflags=0x08000000).decode()
            return str(pid) in output
        except Exception:
            return False
    else:
        try:
            os.kill(pid, 0)
        except OSError:
            return False
        return True


def _kill_orphan_daemons():
    """Gracefully terminate daemon processes left from a previous crashed run."""
    if not DAEMON_PIDS_FILE.exists():
        return
    try:
        pids = json.loads(DAEMON_PIDS_FILE.read_text())
        if not isinstance(pids, list):
            return
        killed = 0
        for pid in pids:
            if _is_process_running(pid):
                try:
                    if os.name == 'nt':
                        subprocess.run(["taskkill", "/PID", str(pid)],
                                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                       creationflags=0x08000000)
                    else:
                        os.kill(pid, signal.SIGTERM)
                        for _ in range(10):
                            if not _is_process_running(pid):
                                break
                            time.sleep(0.5)
                        if _is_process_running(pid):
                            os.kill(pid, signal.SIGKILL)
                    killed += 1
                except Exception:
                    pass
        if killed:
            print(f"[PULSE] Cleaned up {killed} orphan daemon(s).")
        DAEMON_PIDS_FILE.unlink(missing_ok=True)
    except Exception:
        pass


def _save_daemon_pids(processes: dict):
    """Persist child PIDs for orphan cleanup on next boot."""
    try:
        pids = [p.pid for p in processes.values() if p.poll() is None]
        DAEMON_PIDS_FILE.write_text(json.dumps(pids))
    except Exception:
        pass


def _write_pid():
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    with _acquire(PID_FILE):
        PID_FILE.write_text(str(os.getpid()))
    atexit.register(_cleanup_pid)
    atexit.register(_cleanup_orphan_daemons)


def _cleanup_pid():
    try:
        with _acquire(PID_FILE):
            if PID_FILE.exists():
                PID_FILE.unlink()
    except Exception:
        pass


_orchestrator_instance = None

def _cleanup_orphan_daemons():
    if _orchestrator_instance:
        _orchestrator_instance._kill_all_daemons()

# C6: Atomic PID check to prevent TOCTOU race
with _acquire(PID_FILE):
    if PID_FILE.exists():
        try:
            existing = int(PID_FILE.read_text())
        except Exception:
            existing = None
        if existing and _is_process_running(existing):
            print(f"[PULSE] Orchestrator already running (PID {existing}).")
            sys.exit(0)
        else:
            try:
                PID_FILE.unlink()
            except Exception:
                pass


class PulseOrchestrator:
    def __init__(self):
        global _orchestrator_instance
        _orchestrator_instance = self
        self.processes = {}
        self.running = True
        self.quarantine_events = defaultdict(list)
        signal.signal(signal.SIGINT, self._handle_signal)
        signal.signal(signal.SIGTERM, self._handle_signal)

    def _handle_signal(self, signum, frame):
        print("\n[PULSE] Shutting down brain daemons...")
        self.running = False
        self._kill_all_daemons()
        _cleanup_pid()
        sys.exit(0)

    def _kill_all_daemons(self):
        for name, p in self.processes.items():
            try:
                p.kill()
                p.wait(timeout=5)
            except Exception:
                pass
        try:
            DAEMON_PIDS_FILE.unlink(missing_ok=True)
        except Exception:
            pass

    def start_daemon(self, script_path, name, agent_id=None):
        print(f"[PULSE] Starting {name}...")
        try:
            p = subprocess.Popen(
                [sys.executable, str(script_path), "--verbose"],
                stdout=sys.stdout, stderr=sys.stderr)
            self.processes[agent_id or name] = p
        except Exception as e:
            print(f"[PULSE] Error starting {name}: {e}")

    def run(self):
        STATE_DIR.mkdir(parents=True, exist_ok=True)
        _kill_orphan_daemons()
        _write_pid()
        load_env_file()

        print("=======================================================")
        print("  PULSE v6 - The Brain Orchestrator [FORTIFIED]")
        print("=======================================================")

        verify_sealed_environment()
        verify_immutable_core()
        ensure_brain_scaffold()

        if SAFETY_CHECK.exists():
            print("[PULSE] Running safety check (mandatory)...")
            result = subprocess.run([sys.executable, str(SAFETY_CHECK)])
            if result.returncode != 0:
                print("[PULSE] Safety check failed. Aborting startup.")
                return
        else:
            print("[PULSE] Safety check missing. Aborting startup.")
            return

        # License-based daemon gating
        active_daemons = DAEMON_MAP
        try:
            from pulse.core.license import LicenseManager
            _lm = LicenseManager()
            _allowed = _lm.get_limits().get("daemons")
            if _allowed is not None:
                active_daemons = {k: v for k, v in DAEMON_MAP.items() if k in _allowed}
                print(f"[PULSE] {_lm.get_plan().upper()} plan: {len(active_daemons)}/{len(DAEMON_MAP)} daemons")
        except Exception:
            pass

        for agent_id, script in active_daemons.items():
            self.start_daemon(script, DAEMON_LABELS.get(agent_id, agent_id), agent_id)
        _save_daemon_pids(self.processes)

        start_all_schedulers(lambda: self.running)

        print("\n[PULSE] Brain is listening and digesting on all channels.")
        print("[PULSE] Press Ctrl+C to stop.\n")

        restart_counts = defaultdict(int)
        MAX_RESTARTS = 5

        while self.running:
            for name, p in list(self.processes.items()):
                if p.poll() is not None:
                    if restart_counts[name] < MAX_RESTARTS:
                        restart_counts[name] += 1
                        backoff = min(2 ** restart_counts[name], 30)
                        print(f"[PULSE] Daemon '{name}' died (exit={p.returncode}). "
                              f"Restarting in {backoff}s ({restart_counts[name]}/{MAX_RESTARTS})...")
                        time.sleep(backoff)
                        script = active_daemons.get(name)
                        if script and script.exists():
                            self.start_daemon(script, name, name)
                            _save_daemon_pids(self.processes)
                        else:
                            print(f"[PULSE] Cannot restart '{name}': script not found.")
                    else:
                        _write_daemon_alert(name, p.returncode, MAX_RESTARTS)
                        print(f"[PULSE] Daemon '{name}' exceeded max restarts ({MAX_RESTARTS}). Giving up.")
                        del self.processes[name]

            enforce_quarantine(self.processes, self.quarantine_events, DAEMON_MAP)
            time.sleep(1)

if __name__ == "__main__":
    PulseOrchestrator().run()
