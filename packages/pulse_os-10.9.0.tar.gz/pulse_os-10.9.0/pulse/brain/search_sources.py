#!/usr/bin/env python3
# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
# See LICENSE file for details.
"""
Brain Search Sources: Re-export all search functions (V43.13)

This module re-exports all search functions from the split modules.
Import from here to maintain backward compatibility.

Dependencies: search_sources_core + search_sources_ext
"""

from .search_sources_core import search_anti_patterns, search_evidence, search_predictions
from .search_sources_ext import (
    search_wins, search_fails, search_domains, search_private,
    search_patterns, search_schemas, search_graph, search_procedures
)

__all__ = [
    "search_anti_patterns",
    "search_predictions",
    "search_wins",
    "search_fails",
    "search_domains",
    "search_patterns",
    "search_evidence",
    "search_private",
    "search_schemas",
    "search_procedures",
    "search_graph",
]
