---
type: skill
domain: security
links: [Corpus_Callosum/CONSTITUTION.md, PULSE_OS.md]
---

# PROTOCOL_POLICEMAN
> **ROLE:** STANDARDS ENFORCER
> **TRIGGER:** "COMPLIANCE"

## Core Mandate
Rules are meaningless without enforcement. Every commit, every PR, every file change gets measured against hard limits.

## Step-by-Step Protocol
1. **Run brain_query** before reviewing: `python Autonomic_System/Utilities/Tools/brain_query.py --query "compliance standards for <module>"`
2. **Measure complexity** on every changed function: cyclomatic complexity <10, nesting depth <4, function length <50 lines.
3. **Verify file placement** -- every new file must reside in its correct Fractal Chamber per BRAIN_MAP.md.
4. **Audit transaction_audit.json** for manual sealing bypasses or unsigned dispatches.
5. **Issue citation or relay** -- block the change if it fails thresholds, or post a fix task via `python Autonomic_System/Utilities/Tools/pulse_relay.py --tasks "Fix complexity:security:fast"`.

## Metrics & Thresholds
| Metric | Limit | Action if exceeded |
|---|---|---|
| Cyclomatic complexity | <10 per function | Mandatory refactor |
| Nesting depth | <4 levels | Extract to helper |
| Function length | <50 lines | Split into sub-functions |
| File length | <400 lines | Decompose module |
| Unused imports | 0 | Auto-remove with ruff |

## Good Example
```python
# GOOD: flat, single-responsibility, 12 lines
def validate_task(task: dict) -> bool:
    if not task.get("task_id"):
        return False
    if not task.get("title") or len(task["title"]) < 5:
        return False
    if task.get("status") not in ("open", "claimed", "done"):
        return False
    return True
```

## Anti-Patterns
- **God functions**: 200+ line functions that "do everything." Split them.
- **Silent swallows**: `except Exception: pass` hides real failures. Always log or re-raise.
- **Manual hash edits**: Never hand-edit CONSTITUTION_HASH -- use `update_constitution_hash.py`.

## Tools to Use
- `brain_query.py --query "compliance for <area>"` -- check existing standards
- `pulse_relay.py --tasks "Title:security:fast"` -- delegate fixes
- `ruff check --select C901` -- cyclomatic complexity check
- `update_constitution_hash.py` -- sync constitution hash after edits

## Verification Checklist
- [ ] Every function has cyclomatic complexity <10
- [ ] No nesting deeper than 4 levels in any changed file
- [ ] No function exceeds 50 lines
- [ ] All new files placed in correct Fractal Chamber
- [ ] Zero unused imports in changed files
- [ ] Constitution hash is current (run `update_constitution_hash.py`)
