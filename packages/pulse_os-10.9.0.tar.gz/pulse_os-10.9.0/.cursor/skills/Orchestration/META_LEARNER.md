---
type: skill
domain: orchestration
---

# META_LEARNER
> **ROLE:** Extract and persist reusable knowledge
> **TRIGGER:** After completing any task, after encountering a failure, or during retrospectives

## Core Directive
Close the learning loop. Every task completion or failure must produce a concrete, reusable insight saved to the brain. Knowledge that stays in a conversation thread and is never persisted is knowledge lost.

## Step-by-Step Protocol
1. **Check existing knowledge first:** Before saving, run `python Autonomic_System/Utilities/Tools/brain_query.py --query "<topic>"` to avoid duplicating what the brain already knows. If the insight already exists, skip saving.
2. **Extract the insight:** After completing a task, answer these 3 questions in 1 sentence each: (a) What worked? (b) What failed or was surprising? (c) What should future agents do differently? Each answer becomes a learning or failure entry.
3. **Apply quality gates:** Every learning must pass: minimum 25 characters, minimum 5 words, must contain an actionable verb (use, add, check, avoid, ensure, run, test, validate, split, etc.), and must not be a truncated fragment. Reject anything that reads like "Updated the thing" or "Fixed it."
4. **Save to brain:** Use `python Autonomic_System/Utilities/Tools/pulse_save.py --agent <you> --learnings "concrete insight" --failures "what went wrong"`. This writes to `Hippocampus/Lessons/auto_lessons.md` and `Hippocampus/Failures/auto_fails.md`.
5. **Promote patterns:** If the same insight appears 3+ times in `auto_lessons.md`, extract it as a pattern to `Hippocampus/Patterns/auto_patterns.md`. If a failure repeats 2+ times, escalate it to `Hippocampus/Patterns/` via `anti_pattern_builder.py`.

## Metrics & Thresholds
- Every completed task must produce at least 1 learning saved to brain
- Learnings: min 25 chars, min 5 words, must contain actionable verb
- Failures: must include root cause, not just symptom ("API returned 500" is bad; "API returned 500 because auth token expired after 1hr, need refresh logic" is good)
- Duplicate check: query brain before saving -- no repeated insights
- Pattern promotion: after 3 occurrences of same lesson

## Examples

### Good
```bash
python pulse_save.py --agent claude \
  --learnings "Always use atomic_update_json with filelock when modifying task_board.json to prevent race conditions between concurrent workers" \
  --failures "pulse_worker.py line 47 had a raw read-then-write on task_board.json causing duplicate task claims when 2 workers polled simultaneously"
```
Specific file, specific line, root cause identified, actionable fix stated.

### Bad (Anti-Pattern)
```bash
python pulse_save.py --agent claude \
  --learnings "Fixed the bug" \
  --failures "It didn't work"
```
Fails every quality gate: under 25 chars, no actionable verb, no specifics. Future agents learn nothing from this. Rejected by knowledge_extractor.py filters.

## Tools to Use
- `brain_query.py --query "<topic>"` -- check for existing knowledge before saving
- `pulse_save.py --agent <you> --learnings "..." --failures "..."` -- persist to brain
- `anti_pattern_builder.py` -- escalate recurring failures to anti-pattern registry
- `knowledge_extractor.py` -- programmatic extraction with quality gates built in

## Verification
- [ ] Brain queried before saving to avoid duplicates
- [ ] Learning is 25+ chars, 5+ words, contains actionable verb
- [ ] Failure entry includes root cause, not just symptom
- [ ] pulse_save.py called with concrete content
- [ ] Recurring patterns promoted (3+ lessons) or escalated (2+ failures)
