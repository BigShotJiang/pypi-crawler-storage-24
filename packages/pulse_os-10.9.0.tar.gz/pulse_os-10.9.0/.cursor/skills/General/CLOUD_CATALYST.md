---
type: skill
domain: cloud
links: [Corpus_Callosum/CONSTITUTION.md, PULSE_OS.md]
---

# CLOUD_CATALYST.md
> **ROLE:** CLOUD ARCHITECT
> **TRIGGER:** "DEPLOY"

## Protocol

1. **Audit current costs.** Pull billing data for the last 30 days. Identify top 3 cost drivers. Set a monthly budget ceiling and alert at 80% spend.
2. **Right-size resources.** Check CPU/memory utilization. Any resource <30% average utilization = downsize. Any resource >80% sustained = upsize or auto-scale.
3. **Define IaC for everything.** Write Terraform/Pulumi/CDK for all infrastructure. Zero manual console changes. Store state remotely (S3 + DynamoDB lock). Tag every resource with `env`, `owner`, `cost-center`.
4. **Configure auto-scaling.** Set scaling policies: scale out at >70% CPU or queue depth >100. Scale in at <30% CPU. Min instances = 1, max = based on budget. Use spot/preemptible for non-critical workloads.
5. **Validate deployment.** Run `terraform plan` (or equivalent) before apply. Verify health checks pass post-deploy. Confirm rollback works by testing canary or blue-green switch.

## Metrics & Thresholds
- **Resource utilization target:** 30-70% CPU/memory (below = overprovisioned, above = at risk)
- **Cost alert:** Trigger at 80% of monthly budget
- **Scale-out trigger:** >70% CPU sustained 5min OR queue depth >100
- **Scale-in trigger:** <30% CPU sustained 15min
- **Deploy success rate:** >99% (failed deploys auto-rollback)
- **IaC coverage:** 100% of infra defined in code (0 manual resources)

## Good Example
```hcl
# Terraform auto-scaling example
resource "aws_appautoscaling_target" "api" {
  max_capacity       = 10
  min_capacity       = 1
  resource_id        = "service/pulse/api"
  scalable_dimension = "ecs:service:DesiredCount"
  service_namespace  = "ecs"
}

resource "aws_appautoscaling_policy" "cpu" {
  name               = "cpu-scale"
  policy_type        = "TargetTrackingScaling"
  resource_id        = aws_appautoscaling_target.api.resource_id
  scalable_dimension = aws_appautoscaling_target.api.scalable_dimension
  service_namespace  = aws_appautoscaling_target.api.service_namespace

  target_tracking_scaling_policy_configuration {
    target_value = 70.0
    predefined_metric_specification {
      predefined_metric_type = "ECSServiceAverageCPUUtilization"
    }
  }
}
```

## Anti-Patterns
- **Console clicking:** Making infra changes in the AWS/GCP console. It drifts, can't be reviewed, can't be rolled back.
- **No budget alerts:** Running without cost monitoring until the bill shock arrives. Set alerts on day 1.
- **Over-provisioning "just in case":** Running large instances 24/7 for bursty workloads. Use auto-scaling + spot.

## Tools
- `python Autonomic_System/Utilities/Tools/brain_query.py --query "cloud deploy <service>"`
- `python Autonomic_System/Utilities/Tools/pulse_save.py --agent <you> --learnings "deployed X, cost: $Y/mo"`
- `python Autonomic_System/Utilities/Tools/pulse_relay.py --tasks "IaC for <service>:cloud:standard"`

## Verification Checklist
- [ ] All infrastructure defined in code (Terraform/Pulumi/CDK), zero console-only resources
- [ ] Budget alerts configured at 80% threshold
- [ ] Auto-scaling policies active with defined min/max and trigger thresholds
- [ ] `terraform plan` shows no drift from deployed state
- [ ] Health checks pass post-deployment, rollback tested
