---
type: skill
domain: innovation
links: [Corpus_Callosum/CONSTITUTION.md, PULSE_OS.md]
---

# INNOVATION_IGNITER.md
> **ROLE:** FUTURE-PROOFING LEAD
> **TRIGGER:** "NEW TECH"

## Protocol

1. **Define the hypothesis.** Write a one-sentence hypothesis: "If we add X, then Y metric improves by Z%." No hypothesis = no spike. Every experiment needs a measurable outcome before writing code.
2. **Timebox the spike.** Set a hard 2-hour limit for the prototype. Use a branch named `spike/<feature>`. Only build the minimum needed to validate/invalidate the hypothesis. No polish.
3. **Build the prototype.** Implement the simplest possible version. Use mocks for dependencies. Skip tests, skip docs, skip error handling. The only goal is: does the hypothesis hold?
4. **Evaluate against criteria.** After 2 hours, answer: (a) Does it work at all? (b) Does it meet the target metric? (c) Can it integrate without breaking existing architecture? Score each 0-1. Total <2 = kill it.
5. **Decide: promote or kill.** Score >=2: create a real task on the task board with findings. Score <2: document WHY it failed in brain, delete the spike branch, move on. No zombie spikes.

## Metrics & Thresholds
- **Spike timebox:** 2 hours hard limit, no extensions
- **Kill score:** <2/3 on (works, meets metric, integrable) = kill immediately
- **Promote score:** >=2/3 = create implementation task with spike findings attached
- **Max active spikes:** 1 per agent at a time. Finish or kill before starting another.
- **Spike-to-feature conversion rate:** Track over time, target >30%

## Good Example
```markdown
## Spike: MCP Tool Streaming
**Hypothesis:** Adding streaming to brain_query.py reduces agent wait time by >50%.
**Timebox:** 2h (started 14:00, hard stop 16:00)
**Branch:** spike/mcp-streaming

### Results (15:45)
- Works: YES (1/1) - streaming responses functional
- Metric: 60% faster for large queries (1/1) - exceeds 50% target
- Integrable: YES (1/1) - drop-in replacement, same interface
- **Score: 3/3 - PROMOTE**

### Action: Posted task "Implement MCP streaming for brain_query" to board
```

## Anti-Patterns
- **Infinite spikes:** No timebox, prototype grows into unfinished feature. 2 hours, then decide.
- **Premature commitment:** Adopting new tech without a spike. Always validate with a throwaway prototype first.
- **Zombie branches:** Spike branches that never get killed or promoted. Delete within 24h of completion.

## Tools
- `python Autonomic_System/Utilities/Tools/brain_query.py --query "prior spikes on <tech>"`
- `python Autonomic_System/Utilities/Tools/pulse_save.py --agent <you> --learnings "spike <X>: score N/3, result"`
- `python Autonomic_System/Utilities/Tools/pulse_relay.py --tasks "Implement <feature>:development:standard"` if promoted

## Verification Checklist
- [ ] Hypothesis written before any code
- [ ] Spike completed or killed within 2-hour timebox
- [ ] Score recorded (0-3) with clear justification for each criterion
- [ ] Promoted spikes have a task posted to the board with findings
- [ ] Killed spikes documented in brain with failure reason, branch deleted
