---
type: skill
domain: ai-ml
links: [Corpus_Callosum/CONSTITUTION.md, PULSE_OS.md]
---

# AI_NEUROLOGIST.md
> **ROLE:** COGNITIVE SCIENTIST
> **TRIGGER:** "BRAIN UPDATE"

## Protocol

1. **Assess brain health.** Count entries in `auto_lessons.md`, `auto_fails.md`, `auto_patterns.md`. Check for duplicates (>20% duplication = run dedup). Check freshness (oldest entry >30 days = stale).
2. **Validate data quality.** Every knowledge entry must pass: >25 chars, >5 words, contains actionable verb, no truncation. Reject fragments. Run `knowledge_extractor.py` quality gates.
3. **Evaluate retrieval accuracy.** Test `brain_query.py` with 5 known queries. Measure: does it return relevant results? Precision target >0.8 (4/5 queries return useful hits).
4. **Monitor synthesis drift.** Compare `ACTIVE_NEURAL_STATE.md` against raw evidence. Flag any synthesized conclusion not supported by >=2 evidence entries. Prune unsupported claims.
5. **Tune the pipeline.** Adjust extraction thresholds if noise is high (too many fragments) or signal is low (real lessons rejected). Log changes to brain.

## Metrics & Thresholds
- **Brain entry quality:** >25 chars, >5 words, actionable verb required
- **Duplication rate:** <20% across all brain files
- **Retrieval precision:** >0.8 (4/5 test queries return relevant results)
- **Freshness:** Entries older than 30 days flagged for review or archival
- **F1 for extraction:** Track accepted/rejected ratio. Target >0.7 (reject noise, keep signal)

## Good Example
```python
# Test brain retrieval accuracy
queries = ["docker build failure", "task board claiming", "constitution hash",
           "agent idle regression", "knowledge pipeline"]
hits = 0
for q in queries:
    result = subprocess.run(
        ["python", "Autonomic_System/Utilities/Tools/brain_query.py", "--query", q],
        capture_output=True, text=True
    )
    if "MATCH" in result.stdout or len(result.stdout.strip()) > 50:
        hits += 1
precision = hits / len(queries)  # Target: >0.8
```

## Anti-Patterns
- **Garbage in, garbage out:** Skipping quality gates lets fragments pollute the brain. Always enforce min length + word count.
- **Synthesis without evidence:** Writing conclusions in neural state that aren't backed by 2+ raw entries. Every claim needs sources.
- **Hoarding stale data:** Never archiving old entries. Brain bloat slows queries and wastes tokens.

## Tools
- `python Autonomic_System/Utilities/Tools/brain_query.py --query "brain health"` before any changes
- `python Autonomic_System/Utilities/Tools/pulse_save.py --agent <you> --learnings "brain health score: X"`
- `python Autonomic_System/Utilities/Tools/pulse_relay.py --tasks "Brain dedup:ai-ml:fast"`

## Verification Checklist
- [ ] All brain entries pass quality gates (25+ chars, 5+ words, actionable verb)
- [ ] Duplication rate <20% across brain files
- [ ] 5 test queries return relevant results (precision >0.8)
- [ ] No synthesis claims without 2+ supporting evidence entries
- [ ] Stale entries (>30 days) flagged or archived
