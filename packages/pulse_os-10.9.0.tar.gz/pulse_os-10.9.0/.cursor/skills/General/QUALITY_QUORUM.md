---
type: skill
domain: general
links: [Corpus_Callosum/CONSTITUTION.md, PULSE_OS.md]
---

# QUALITY_QUORUM.md
> **ROLE:** QUALITY ASSURANCE LEAD
> **TRIGGER:** "VERIFY"

## Protocol: 5-Step Quality Gate

1. **Brain Check** -- Run `python Autonomic_System/Utilities/Tools/brain_query.py --query "quality issues <module>"` to find past failures in this area.
2. **Static Analysis** -- Run linter/type checker. Zero errors, zero warnings. Every function has type hints.
3. **Test Coverage** -- Run `pytest --cov=<module> --cov-fail-under=80`. Check the coverage report for untested branches.
4. **Code Review Checklist** -- Walk through every changed function:
   - Input validation present? Error handling complete?
   - No hardcoded secrets, no `any`/untyped params?
   - Functions under 50 lines? File under 300 lines (Law 7)?
5. **PR Review Protocol** -- Diff against base branch. Confirm: no regressions (Law 3), no dead imports (Law 8), propagation done (Law 9).

## Metrics & Thresholds

| Metric | Threshold | Action if Failed |
|--------|-----------|------------------|
| Test coverage | >= 80% | Add tests before merge |
| P0 bugs open | 0 | Block release until fixed |
| Lint warnings | 0 | Fix all before commit |
| Max function length | 50 lines | Split immediately |
| Max file length | 300 lines | Refactor per Law 7 |

## Good Example

```bash
# Full quality gate before commit
python Autonomic_System/Utilities/Tools/brain_query.py --query "known bugs in pulse_worker"
pytest tests/ --cov=Autonomic_System --cov-fail-under=80 -q
# Review diff for regressions
git diff --stat main
```

## Anti-Patterns

- **Skipping brain check** -- Past failures repeat. Always query first.
- **Merging with failing tests** -- "I'll fix it later" = tech debt spiral.
- **Coverage theater** -- Tests that assert nothing. Every test must verify behavior, not just run code.

## Tools to Use

- `brain_query.py --query "quality issues <module>"` -- Find past bugs
- `pulse_save.py --agent <you> --learnings "quality gate result"` -- Record findings
- `pulse_relay.py --tasks "Fix <bug>:development:fast"` -- Post fix tasks for others

## Verification Checklist

- [ ] `brain_query.py` ran for this module -- past issues applied
- [ ] All tests pass, coverage >= 80%
- [ ] Zero lint errors, zero type errors
- [ ] No function > 50 lines, no file > 300 lines
- [ ] PR diff reviewed: no regressions, no dead code, propagation complete
