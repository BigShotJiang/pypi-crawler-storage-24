{
    "apple",
    "banana",
    "cherry",
}
