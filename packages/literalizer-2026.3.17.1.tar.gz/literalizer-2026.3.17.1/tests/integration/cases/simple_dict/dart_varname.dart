final my_data = {
    "name": "Alice",
    "age": 30,
    "active": true,
    "score": null,
};
