final my_data = {
    "name": "Alice",
    "score": null,
    "age": 30,
};
