my_data = (
    (),
    {},
)
