my_data = (
    True,
    "hi",
    (1, 2),
    None,
)
