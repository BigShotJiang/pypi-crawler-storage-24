void (
[
    true,
    "hi",
    [1, 2],
    null,
]
)
