"""CSS assets.
"""
