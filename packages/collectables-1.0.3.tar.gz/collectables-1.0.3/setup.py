from setuptools import setup

setup(  name= 'collectables', 
        version='1.0.3', 
        description='collectables', 
        packages=['collectables'],
		author='ops',
		license="Python Script",
        install_requires = ["blessings ~= 1.7"],
        extras_require={
            "dev": [
                "pytest>=3.2",
            ],
        },
    )

