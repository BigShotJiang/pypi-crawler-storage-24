from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="agentbridge-sdk",
    version="1.0.0",
    description="Official Python SDK for AgentBridge — connect AI agents to GitHub, Slack, Notion, Gmail and Google Drive through a single unified API.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="AgentBridge",
    url="https://agentbridge.in",
    project_urls={
        "Homepage": "https://agentbridge.in",
        "Dashboard": "https://agentbridge.in/app/dashboard",
            },
    packages=find_packages(),
    install_requires=["requests>=2.20.0"],
    python_requires=">=3.9",
    keywords=["agentbridge", "ai", "mcp", "agent", "github", "slack", "notion", "gmail", "google-drive", "sdk", "api"],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
)
