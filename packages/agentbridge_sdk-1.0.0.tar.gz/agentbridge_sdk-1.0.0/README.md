# AgentBridge Python SDK

Official Python SDK for [AgentBridge](https://agentbridge.in) — connect AI agents to GitHub, Slack, Notion, Gmail and Google Drive through a single unified API.

[![PyPI](https://img.shields.io/pypi/v/agentbridge-sdk)](https://pypi.org/project/agentbridge-sdk/)

## Installation

```bash
pip install agentbridge-sdk
```

## Quick Start

1. Sign up at [agentbridge.in](https://agentbridge.in)
2. Connect your providers (GitHub, Slack, etc.) from the [dashboard](https://agentbridge.in/app/tools)
3. Create an API key from [API Keys](https://agentbridge.in/app/api-keys)

```python
from agentbridge import AgentBridge

client = AgentBridge(api_key="ab_your_api_key_here")

# List your GitHub repos
repos = client.execute(provider="github", tool="list_repos")
print(repos["data"])

# Create a Slack message
client.execute(
    provider="slack",
    tool="send_message",
    params={"channel": "#general", "text": "Hello from AgentBridge!"},
)

# Search Notion pages
pages = client.execute(
    provider="notion",
    tool="search_pages",
    params={"query": "meeting notes"},
)
```

## Configuration

```python
client = AgentBridge(
    api_key="ab_your_api_key_here",       # required — get one at agentbridge.in/app/api-keys
    base_url="https://agentbridge.in",    # optional, defaults to this
)
```

## API Reference

### `client.execute(provider, tool, params=None)`

Execute a tool on a connected provider.

```python
result = client.execute(
    provider="github",
    tool="create_issue",
    params={
        "owner": "octocat",
        "repo": "hello-world",
        "title": "Bug report",
        "body": "Something is broken",
    },
)

print(result["status"])  # "success"
print(result["data"])    # tool-specific response
```

| Argument   | Type         | Required | Description                                      |
| ---------- | ------------ | -------- | ------------------------------------------------ |
| `provider` | str          | Yes      | Provider slug (`github`, `slack`, `notion`, `gmail`, `google-drive`) |
| `tool`     | str          | Yes      | Tool name (e.g. `list_repos`, `create_issue`)    |
| `params`   | dict or None | No       | Tool-specific parameters                         |

### `client.get_providers()`

List all available providers.

```python
providers = client.get_providers()
# [{"id": "...", "name": "GitHub", "slug": "github", "active": True}, ...]
```

### `client.get_provider_tools(slug)`

List available tools for a provider. Use this to discover tool names and their parameters.

```python
tools = client.get_provider_tools("github")
# [{"name": "list_repos", "description": "...", "parameters": {...}}, ...]
```

## Error Handling

```python
from requests.exceptions import HTTPError

try:
    result = client.execute(provider="github", tool="list_repos")
except HTTPError as e:
    print(f"Request failed: {e.response.status_code} - {e.response.text}")
```

## Providers

| Provider     | Slug           | Example Tools                              |
| ------------ | -------------- | ------------------------------------------ |
| GitHub       | `github`       | `list_repos`, `create_issue`, `create_pr`, `get_file` |
| Slack        | `slack`        | `send_message`, `list_channels`            |
| Notion       | `notion`       | `search_pages`, `create_page`              |
| Gmail        | `gmail`        | `send_email`, `list_messages`              |
| Google Drive | `google-drive` | `list_files`, `upload_file`                |

Use `client.get_provider_tools("slug")` to see all tools and parameters for each provider.

## Requirements

- Python >= 3.9
- requests >= 2.20.0

## Links

- [Website](https://agentbridge.in)
- [Dashboard](https://agentbridge.in/app/dashboard)
- [Documentation](https://agentbridge.in)


## License

MIT
