"""Shared test fixtures for vitals tests."""

from __future__ import annotations

import asyncio

import pytest

from vitals.types import CheckResult, Status


@pytest.fixture
def healthy_check():
    """Return an async callable that produces a healthy CheckResult."""

    async def _check() -> CheckResult:
        return CheckResult(status=Status.HEALTHY, latency_ms=1.0, message="")

    return _check


@pytest.fixture
def degraded_check():
    """Return an async callable that produces a degraded CheckResult."""

    async def _check() -> CheckResult:
        return CheckResult(status=Status.DEGRADED, latency_ms=50.0, message="slow")

    return _check


@pytest.fixture
def outage_check():
    """Return an async callable that produces an outage CheckResult."""

    async def _check() -> CheckResult:
        return CheckResult(status=Status.OUTAGE, latency_ms=0.0, message="connection refused")

    return _check


@pytest.fixture
def slow_check():
    """Return an async callable that sleeps for 0.3s then returns healthy."""

    async def _check() -> CheckResult:
        await asyncio.sleep(0.3)
        return CheckResult(status=Status.HEALTHY, latency_ms=300.0, message="")

    return _check


@pytest.fixture
def timeout_check():
    """Return an async callable that sleeps long enough to always time out."""

    async def _check() -> CheckResult:
        await asyncio.sleep(10.0)
        return CheckResult(status=Status.HEALTHY, latency_ms=0.0, message="")

    return _check


@pytest.fixture
def error_check():
    """Return an async callable that raises an exception."""

    async def _check() -> CheckResult:
        raise RuntimeError("something broke")

    return _check
