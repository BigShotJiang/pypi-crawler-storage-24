"""Tests for vitals.types module."""

from __future__ import annotations

import dataclasses
from datetime import datetime, timezone

import pytest

from vitals.types import CheckResult, HealthcheckResponse, ShallowResponse, Status


class TestStatusFromString:
    """Test Status.from_string classmethod."""

    def test_healthy(self):
        assert Status.from_string("healthy") == Status.HEALTHY

    def test_ok_maps_to_healthy(self):
        assert Status.from_string("ok") == Status.HEALTHY

    def test_degraded(self):
        assert Status.from_string("degraded") == Status.DEGRADED

    def test_outage(self):
        assert Status.from_string("outage") == Status.OUTAGE

    def test_error_maps_to_outage(self):
        assert Status.from_string("error") == Status.OUTAGE

    def test_unknown_maps_to_outage(self):
        assert Status.from_string("something_else") == Status.OUTAGE

    def test_case_insensitive_healthy(self):
        assert Status.from_string("HEALTHY") == Status.HEALTHY

    def test_case_insensitive_ok(self):
        assert Status.from_string("OK") == Status.HEALTHY

    def test_case_insensitive_degraded(self):
        assert Status.from_string("Degraded") == Status.DEGRADED

    def test_case_insensitive_outage(self):
        assert Status.from_string("OUTAGE") == Status.OUTAGE

    def test_case_insensitive_error(self):
        assert Status.from_string("Error") == Status.OUTAGE


class TestStatusJsonValue:
    """Test Status.json_value property."""

    def test_healthy(self):
        assert Status.HEALTHY.json_value == "healthy"

    def test_degraded(self):
        assert Status.DEGRADED.json_value == "degraded"

    def test_outage(self):
        assert Status.OUTAGE.json_value == "outage"


class TestStatusOrdering:
    """Test Status enum value ordering."""

    def test_healthy_greater_than_degraded(self):
        assert Status.HEALTHY.value > Status.DEGRADED.value

    def test_degraded_greater_than_outage(self):
        assert Status.DEGRADED.value > Status.OUTAGE.value

    def test_healthy_greatest(self):
        assert Status.HEALTHY.value > Status.OUTAGE.value


class TestCheckResult:
    """Test CheckResult dataclass."""

    def test_creation(self):
        result = CheckResult(status=Status.HEALTHY, latency_ms=12.0, message="")
        assert result.status == Status.HEALTHY
        assert result.latency_ms == 12.0
        assert result.message == ""

    def test_frozen(self):
        result = CheckResult(status=Status.HEALTHY, latency_ms=12.0)
        with pytest.raises(dataclasses.FrozenInstanceError):
            result.status = Status.OUTAGE  # type: ignore[misc]

    def test_default_message(self):
        result = CheckResult(status=Status.HEALTHY, latency_ms=0.0)
        assert result.message == ""


class TestHealthcheckResponse:
    """Test HealthcheckResponse dataclass."""

    def test_http_status_code_healthy(self):
        resp = HealthcheckResponse(status=Status.HEALTHY)
        assert resp.http_status_code == 200

    def test_http_status_code_degraded(self):
        resp = HealthcheckResponse(status=Status.DEGRADED)
        assert resp.http_status_code == 503

    def test_http_status_code_outage(self):
        resp = HealthcheckResponse(status=Status.OUTAGE)
        assert resp.http_status_code == 503

    def test_default_timestamp_is_utc(self):
        resp = HealthcheckResponse(status=Status.HEALTHY)
        assert resp.timestamp.tzinfo is not None
        assert resp.timestamp.tzinfo == timezone.utc

    def test_default_checks_empty(self):
        resp = HealthcheckResponse(status=Status.HEALTHY)
        assert resp.checks == {}

    def test_to_dict_healthy_no_checks(self):
        ts = datetime(2025, 1, 15, 12, 0, 0, tzinfo=timezone.utc)
        resp = HealthcheckResponse(status=Status.HEALTHY, timestamp=ts)
        result = resp.to_dict()
        assert result == {
            "status": "healthy",
            "timestamp": "2025-01-15T12:00:00+00:00",
            "checks": {},
        }

    def test_to_dict_with_checks(self):
        ts = datetime(2025, 1, 15, 12, 0, 0, tzinfo=timezone.utc)
        checks = {
            "postgres": CheckResult(status=Status.HEALTHY, latency_ms=12.0, message=""),
            "redis": CheckResult(status=Status.HEALTHY, latency_ms=3.0, message=""),
        }
        resp = HealthcheckResponse(status=Status.HEALTHY, timestamp=ts, checks=checks)
        result = resp.to_dict()
        assert result == {
            "status": "healthy",
            "timestamp": "2025-01-15T12:00:00+00:00",
            "checks": {
                "postgres": {"status": "healthy", "latencyMs": 12.0, "message": ""},
                "redis": {"status": "healthy", "latencyMs": 3.0, "message": ""},
            },
        }

    def test_to_dict_degraded_with_message(self):
        ts = datetime(2025, 1, 15, 12, 0, 0, tzinfo=timezone.utc)
        checks = {
            "redis": CheckResult(status=Status.DEGRADED, latency_ms=500.0, message="high latency"),
        }
        resp = HealthcheckResponse(status=Status.DEGRADED, timestamp=ts, checks=checks)
        result = resp.to_dict()
        assert result["status"] == "degraded"
        assert result["checks"]["redis"]["status"] == "degraded"
        assert result["checks"]["redis"]["latencyMs"] == 500.0
        assert result["checks"]["redis"]["message"] == "high latency"

    def test_to_dict_without_cached_at(self):
        ts = datetime(2025, 1, 15, 12, 0, 0, tzinfo=timezone.utc)
        resp = HealthcheckResponse(status=Status.HEALTHY, timestamp=ts)
        result = resp.to_dict()
        assert "cachedAt" not in result

    def test_to_dict_with_cached_at(self):
        ts = datetime(2025, 1, 15, 12, 0, 0, tzinfo=timezone.utc)
        cached = datetime(2025, 1, 15, 11, 59, 0, tzinfo=timezone.utc)
        resp = HealthcheckResponse(status=Status.HEALTHY, timestamp=ts, cached_at=cached)
        result = resp.to_dict()
        assert result["cachedAt"] == "2025-01-15T11:59:00+00:00"


class TestShallowResponse:
    def test_creation(self):
        resp = ShallowResponse(status="ok", timestamp="2025-01-15T12:00:00+00:00")
        assert resp.status == "ok"
        assert resp.timestamp == "2025-01-15T12:00:00+00:00"
        assert resp.metadata == {}

    def test_to_dict_without_metadata(self):
        resp = ShallowResponse(status="ok", timestamp="2025-01-15T12:00:00+00:00")
        result = resp.to_dict()
        assert result == {"status": "ok", "timestamp": "2025-01-15T12:00:00+00:00"}

    def test_to_dict_with_metadata(self):
        resp = ShallowResponse(
            status="ok",
            timestamp="2025-01-15T12:00:00+00:00",
            metadata={"version": "1.0", "region": "us-east-1"},
        )
        result = resp.to_dict()
        assert result == {
            "status": "ok",
            "timestamp": "2025-01-15T12:00:00+00:00",
            "version": "1.0",
            "region": "us-east-1",
        }

    def test_frozen(self):
        resp = ShallowResponse(status="ok", timestamp="2025-01-15T12:00:00+00:00")
        with pytest.raises(dataclasses.FrozenInstanceError):
            resp.status = "bad"  # type: ignore[misc]
