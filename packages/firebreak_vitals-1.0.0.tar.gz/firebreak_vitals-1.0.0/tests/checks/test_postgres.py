"""Tests for vitals.checks.postgres module."""

from __future__ import annotations

import sys
from types import ModuleType
from unittest.mock import AsyncMock, MagicMock

import pytest

from vitals.types import CheckResult, Status


@pytest.fixture(autouse=True)
def _mock_asyncpg():
    """Inject a fake asyncpg module into sys.modules so deferred imports work."""
    mod = ModuleType("asyncpg")
    mod.connect = AsyncMock()  # type: ignore[attr-defined]
    prev = sys.modules.get("asyncpg")
    sys.modules["asyncpg"] = mod
    yield mod
    if prev is None:
        sys.modules.pop("asyncpg", None)
    else:
        sys.modules["asyncpg"] = prev


@pytest.fixture(autouse=True)
def _mock_sqlalchemy():
    """Inject a fake sqlalchemy module into sys.modules so deferred imports work."""
    sa = sys.modules.get("sqlalchemy")
    if sa is None:
        mod = ModuleType("sqlalchemy")
        mod.text = MagicMock()  # type: ignore[attr-defined]
        sys.modules["sqlalchemy"] = mod
    yield
    if sa is None:
        sys.modules.pop("sqlalchemy", None)


class TestAsyncpgCheck:
    """Test AsyncpgCheck with mocked asyncpg."""

    async def test_healthy_connection(self, _mock_asyncpg: ModuleType):
        from vitals.checks.postgres import AsyncpgCheck

        mock_conn = AsyncMock()
        mock_conn.fetchval = AsyncMock(return_value=1)
        mock_conn.close = AsyncMock()

        _mock_asyncpg.connect = AsyncMock(return_value=mock_conn)

        check = AsyncpgCheck(dsn="postgresql://localhost/test")
        result = await check()

        assert result.status == Status.HEALTHY
        assert result.latency_ms > 0
        assert result.message == ""

    async def test_connection_failure(self, _mock_asyncpg: ModuleType):
        from vitals.checks.postgres import AsyncpgCheck

        _mock_asyncpg.connect = AsyncMock(side_effect=ConnectionError("connection refused"))

        check = AsyncpgCheck(dsn="postgresql://localhost/test")
        result = await check()

        assert result.status == Status.OUTAGE
        assert "connection refused" in result.message

    async def test_query_failure(self, _mock_asyncpg: ModuleType):
        from vitals.checks.postgres import AsyncpgCheck

        mock_conn = AsyncMock()
        mock_conn.fetchval = AsyncMock(side_effect=RuntimeError("query failed"))
        mock_conn.close = AsyncMock()

        _mock_asyncpg.connect = AsyncMock(return_value=mock_conn)

        check = AsyncpgCheck(dsn="postgresql://localhost/test")
        result = await check()

        assert result.status == Status.OUTAGE
        assert "query failed" in result.message

    async def test_connection_closed_on_success(self, _mock_asyncpg: ModuleType):
        from vitals.checks.postgres import AsyncpgCheck

        mock_conn = AsyncMock()
        mock_conn.fetchval = AsyncMock(return_value=1)
        mock_conn.close = AsyncMock()

        _mock_asyncpg.connect = AsyncMock(return_value=mock_conn)

        check = AsyncpgCheck(dsn="postgresql://localhost/test")
        await check()

        mock_conn.close.assert_awaited_once()

    async def test_connection_closed_on_failure(self, _mock_asyncpg: ModuleType):
        from vitals.checks.postgres import AsyncpgCheck

        mock_conn = AsyncMock()
        mock_conn.fetchval = AsyncMock(side_effect=RuntimeError("query failed"))
        mock_conn.close = AsyncMock()

        _mock_asyncpg.connect = AsyncMock(return_value=mock_conn)

        check = AsyncpgCheck(dsn="postgresql://localhost/test")
        await check()

        mock_conn.close.assert_awaited_once()


class TestAsyncpgPoolCheck:
    """Test AsyncpgPoolCheck with mocked asyncpg pool."""

    async def test_healthy_pool_check(self):
        from vitals.checks.postgres import AsyncpgPoolCheck

        mock_conn = AsyncMock()
        mock_conn.fetchval = AsyncMock(return_value=1)

        mock_pool = MagicMock()
        mock_pool.acquire = MagicMock(return_value=AsyncMock(
            __aenter__=AsyncMock(return_value=mock_conn),
            __aexit__=AsyncMock(return_value=False),
        ))

        check = AsyncpgPoolCheck(pool=mock_pool)
        result = await check()

        assert result.status == Status.HEALTHY
        assert result.latency_ms > 0
        assert result.message == ""

    async def test_pool_failure(self):
        from vitals.checks.postgres import AsyncpgPoolCheck

        mock_pool = MagicMock()
        mock_pool.acquire = MagicMock(return_value=AsyncMock(
            __aenter__=AsyncMock(side_effect=ConnectionError("pool exhausted")),
            __aexit__=AsyncMock(return_value=False),
        ))

        check = AsyncpgPoolCheck(pool=mock_pool)
        result = await check()

        assert result.status == Status.OUTAGE
        assert "pool exhausted" in result.message


class TestSQLAlchemyCheck:
    """Test SQLAlchemyCheck with mocked SQLAlchemy engine."""

    async def test_healthy_engine(self):
        from vitals.checks.postgres import SQLAlchemyCheck

        mock_result = MagicMock()
        mock_conn = AsyncMock()
        mock_conn.execute = AsyncMock(return_value=mock_result)

        mock_engine = MagicMock()
        mock_engine.connect = MagicMock(return_value=AsyncMock(
            __aenter__=AsyncMock(return_value=mock_conn),
            __aexit__=AsyncMock(return_value=False),
        ))

        check = SQLAlchemyCheck(engine=mock_engine)
        result = await check()

        assert result.status == Status.HEALTHY
        assert result.latency_ms > 0
        assert result.message == ""

    async def test_engine_failure(self):
        from vitals.checks.postgres import SQLAlchemyCheck

        mock_engine = MagicMock()
        mock_engine.connect = MagicMock(return_value=AsyncMock(
            __aenter__=AsyncMock(side_effect=ConnectionError("cannot connect")),
            __aexit__=AsyncMock(return_value=False),
        ))

        check = SQLAlchemyCheck(engine=mock_engine)
        result = await check()

        assert result.status == Status.OUTAGE
        assert "cannot connect" in result.message
