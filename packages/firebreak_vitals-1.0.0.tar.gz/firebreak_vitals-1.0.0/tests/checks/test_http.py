"""Tests for vitals.checks.http module."""

from __future__ import annotations

import sys
from types import ModuleType
from unittest.mock import AsyncMock, MagicMock

import pytest

from vitals.types import Status


@pytest.fixture(autouse=True)
def _mock_httpx_module():
    """Inject fake httpx module into sys.modules."""
    httpx_mod = ModuleType("httpx")

    httpx_mod.AsyncClient = MagicMock()  # type: ignore[attr-defined]
    httpx_mod.TimeoutException = type("TimeoutException", (Exception,), {})  # type: ignore[attr-defined]

    prev_httpx = sys.modules.get("httpx")
    sys.modules["httpx"] = httpx_mod

    yield httpx_mod

    if prev_httpx is None:
        sys.modules.pop("httpx", None)
    else:
        sys.modules["httpx"] = prev_httpx


def _make_mock_client(response_status: int = 200):
    """Create a mock AsyncClient that returns a response with the given status."""
    mock_response = MagicMock()
    mock_response.status_code = response_status

    mock_client = AsyncMock()
    mock_client.request = AsyncMock(return_value=mock_response)
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)
    return mock_client


class TestHttpCheck:
    """Test HttpCheck with mocked httpx."""

    async def test_healthy_200(self, _mock_httpx_module: ModuleType):
        from vitals.checks.http import HttpCheck

        mock_client = _make_mock_client(200)
        _mock_httpx_module.AsyncClient = MagicMock(return_value=mock_client)

        check = HttpCheck("https://example.com")
        result = await check()

        assert result.status == Status.HEALTHY
        assert result.latency_ms > 0
        assert result.message == ""

    async def test_500_error(self, _mock_httpx_module: ModuleType):
        from vitals.checks.http import HttpCheck

        mock_client = _make_mock_client(500)
        _mock_httpx_module.AsyncClient = MagicMock(return_value=mock_client)

        check = HttpCheck("https://example.com")
        result = await check()

        assert result.status == Status.OUTAGE
        assert result.message == "HTTP 500"

    async def test_404_error(self, _mock_httpx_module: ModuleType):
        from vitals.checks.http import HttpCheck

        mock_client = _make_mock_client(404)
        _mock_httpx_module.AsyncClient = MagicMock(return_value=mock_client)

        check = HttpCheck("https://example.com")
        result = await check()

        assert result.status == Status.OUTAGE
        assert result.message == "HTTP 404"

    async def test_network_error(self, _mock_httpx_module: ModuleType):
        from vitals.checks.http import HttpCheck

        mock_client = AsyncMock()
        mock_client.request = AsyncMock(side_effect=ConnectionError("DNS resolution failed"))
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        _mock_httpx_module.AsyncClient = MagicMock(return_value=mock_client)

        check = HttpCheck("https://example.com")
        result = await check()

        assert result.status == Status.OUTAGE
        assert "DNS resolution failed" in result.message

    async def test_timeout(self, _mock_httpx_module: ModuleType):
        from vitals.checks.http import HttpCheck

        timeout_exc = _mock_httpx_module.TimeoutException("timed out")
        mock_client = AsyncMock()
        mock_client.request = AsyncMock(side_effect=timeout_exc)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        _mock_httpx_module.AsyncClient = MagicMock(return_value=mock_client)

        check = HttpCheck("https://example.com", timeout=3.0)
        result = await check()

        assert result.status == Status.OUTAGE
        assert "https://example.com" in result.message
        assert "3.0s" in result.message

    async def test_custom_method_and_headers(self, _mock_httpx_module: ModuleType):
        from vitals.checks.http import HttpCheck

        mock_client = _make_mock_client(200)
        _mock_httpx_module.AsyncClient = MagicMock(return_value=mock_client)

        headers = {"Authorization": "Bearer token123"}
        check = HttpCheck("https://example.com/api", method="POST", headers=headers, timeout=10.0)
        result = await check()

        assert result.status == Status.HEALTHY
        mock_client.request.assert_awaited_once_with(
            "POST", "https://example.com/api", headers=headers, timeout=10.0
        )

    async def test_client_cleanup_on_success(self, _mock_httpx_module: ModuleType):
        from vitals.checks.http import HttpCheck

        mock_client = _make_mock_client(200)
        _mock_httpx_module.AsyncClient = MagicMock(return_value=mock_client)

        check = HttpCheck("https://example.com")
        await check()

        mock_client.__aexit__.assert_awaited_once()

    async def test_client_cleanup_on_error(self, _mock_httpx_module: ModuleType):
        from vitals.checks.http import HttpCheck

        mock_client = AsyncMock()
        mock_client.request = AsyncMock(side_effect=ConnectionError("fail"))
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        _mock_httpx_module.AsyncClient = MagicMock(return_value=mock_client)

        check = HttpCheck("https://example.com")
        await check()

        mock_client.__aexit__.assert_awaited_once()
