"""Tests for vitals.checks.redis module."""

from __future__ import annotations

import sys
from types import ModuleType
from unittest.mock import AsyncMock, MagicMock

import pytest

from vitals.types import CheckResult, Status


@pytest.fixture(autouse=True)
def _mock_redis_module():
    """Inject fake redis and redis.asyncio modules into sys.modules."""
    redis_mod = ModuleType("redis")
    redis_asyncio_mod = ModuleType("redis.asyncio")

    # Provide mock callables on the asyncio submodule
    redis_asyncio_mod.from_url = MagicMock()  # type: ignore[attr-defined]
    redis_asyncio_mod.Redis = MagicMock()  # type: ignore[attr-defined]

    redis_mod.asyncio = redis_asyncio_mod  # type: ignore[attr-defined]

    prev_redis = sys.modules.get("redis")
    prev_redis_asyncio = sys.modules.get("redis.asyncio")

    sys.modules["redis"] = redis_mod
    sys.modules["redis.asyncio"] = redis_asyncio_mod

    yield redis_asyncio_mod

    # Restore previous state
    if prev_redis is None:
        sys.modules.pop("redis", None)
    else:
        sys.modules["redis"] = prev_redis

    if prev_redis_asyncio is None:
        sys.modules.pop("redis.asyncio", None)
    else:
        sys.modules["redis.asyncio"] = prev_redis_asyncio


class TestRedisCheck:
    """Test RedisCheck with mocked redis.asyncio."""

    async def test_healthy_ping(self, _mock_redis_module: ModuleType):
        from vitals.checks.redis import RedisCheck

        mock_client = AsyncMock()
        mock_client.ping = AsyncMock(return_value=True)
        mock_client.aclose = AsyncMock()

        _mock_redis_module.from_url = MagicMock(return_value=mock_client)

        check = RedisCheck(url="redis://localhost:6379/0")
        result = await check()

        assert result.status == Status.HEALTHY
        assert result.latency_ms > 0
        assert result.message == ""

    async def test_connection_failure(self, _mock_redis_module: ModuleType):
        from vitals.checks.redis import RedisCheck

        _mock_redis_module.from_url = MagicMock(side_effect=ConnectionError("connection refused"))

        check = RedisCheck(url="redis://localhost:6379/0")
        result = await check()

        assert result.status == Status.OUTAGE
        assert "connection refused" in result.message

    async def test_ping_returns_false(self, _mock_redis_module: ModuleType):
        from vitals.checks.redis import RedisCheck

        mock_client = AsyncMock()
        mock_client.ping = AsyncMock(return_value=False)
        mock_client.aclose = AsyncMock()

        _mock_redis_module.from_url = MagicMock(return_value=mock_client)

        check = RedisCheck(url="redis://localhost:6379/0")
        result = await check()

        assert result.status == Status.OUTAGE
        assert "PING returned False" in result.message

    async def test_client_closed_on_success(self, _mock_redis_module: ModuleType):
        from vitals.checks.redis import RedisCheck

        mock_client = AsyncMock()
        mock_client.ping = AsyncMock(return_value=True)
        mock_client.aclose = AsyncMock()

        _mock_redis_module.from_url = MagicMock(return_value=mock_client)

        check = RedisCheck(url="redis://localhost:6379/0")
        await check()

        mock_client.aclose.assert_awaited_once()

    async def test_client_closed_on_failure(self, _mock_redis_module: ModuleType):
        from vitals.checks.redis import RedisCheck

        mock_client = AsyncMock()
        mock_client.ping = AsyncMock(side_effect=ConnectionError("ping failed"))
        mock_client.aclose = AsyncMock()

        _mock_redis_module.from_url = MagicMock(return_value=mock_client)

        check = RedisCheck(url="redis://localhost:6379/0")
        await check()

        mock_client.aclose.assert_awaited_once()


class TestRedisPoolCheck:
    """Test RedisPoolCheck with mocked redis.asyncio pool."""

    async def test_healthy_pool_ping(self, _mock_redis_module: ModuleType):
        from vitals.checks.redis import RedisPoolCheck

        mock_client = AsyncMock()
        mock_client.ping = AsyncMock(return_value=True)
        mock_client.aclose = AsyncMock()

        mock_pool = MagicMock()

        _mock_redis_module.Redis = MagicMock(return_value=mock_client)

        check = RedisPoolCheck(pool=mock_pool)
        result = await check()

        assert result.status == Status.HEALTHY
        assert result.latency_ms > 0
        assert result.message == ""

    async def test_pool_failure(self, _mock_redis_module: ModuleType):
        from vitals.checks.redis import RedisPoolCheck

        mock_client = AsyncMock()
        mock_client.ping = AsyncMock(side_effect=ConnectionError("pool error"))
        mock_client.aclose = AsyncMock()

        mock_pool = MagicMock()

        _mock_redis_module.Redis = MagicMock(return_value=mock_client)

        check = RedisPoolCheck(pool=mock_pool)
        result = await check()

        assert result.status == Status.OUTAGE
        assert "pool error" in result.message
