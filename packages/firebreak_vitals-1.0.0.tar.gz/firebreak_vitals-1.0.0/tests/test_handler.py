"""Tests for vitals.handler module."""

from __future__ import annotations

import pytest

from vitals.core import HealthcheckRegistry
from vitals.handler import HandlerResult, create_healthcheck_handler
from vitals.types import RESERVED_KEYS
from vitals.types import CheckResult, Status


@pytest.fixture
def healthy_registry() -> HealthcheckRegistry:
    registry = HealthcheckRegistry()

    async def _check() -> CheckResult:
        return CheckResult(status=Status.HEALTHY, latency_ms=1.0)

    registry.add("db", _check)
    return registry


@pytest.fixture
def outage_registry() -> HealthcheckRegistry:
    registry = HealthcheckRegistry()

    async def _check() -> CheckResult:
        return CheckResult(status=Status.OUTAGE, latency_ms=0.0, message="connection refused")

    registry.add("db", _check)
    return registry


class TestHandlerShallow:
    async def test_default_shallow_when_no_resolve_depth(self, healthy_registry):
        handler = create_healthcheck_handler(registry=healthy_registry)
        result = await handler({})
        assert isinstance(result, HandlerResult)
        assert result.status == 200
        assert result.body["status"] == "ok"
        assert "timestamp" in result.body
        assert "checks" not in result.body

    async def test_shallow_when_resolve_depth_returns_shallow(self, healthy_registry):
        handler = create_healthcheck_handler(
            registry=healthy_registry,
            resolve_depth=lambda _: "shallow",
        )
        result = await handler({})
        assert result.status == 200
        assert result.body["status"] == "ok"


class TestHandlerDeep:
    async def test_deep_when_resolve_depth_returns_deep(self, healthy_registry):
        handler = create_healthcheck_handler(
            registry=healthy_registry,
            resolve_depth=lambda _: "deep",
        )
        result = await handler({})
        assert result.status == 200
        assert result.body["status"] == "healthy"
        assert "checks" in result.body

    async def test_503_on_outage(self, outage_registry):
        handler = create_healthcheck_handler(
            registry=outage_registry,
            resolve_depth=lambda _: "deep",
        )
        result = await handler({})
        assert result.status == 503
        assert result.body["status"] == "outage"


class TestHandlerAsyncResolveDepth:
    async def test_async_resolve_depth(self, healthy_registry):
        async def resolve(req):
            return "deep"

        handler = create_healthcheck_handler(registry=healthy_registry, resolve_depth=resolve)
        result = await handler({})
        assert result.body["status"] == "healthy"
        assert "checks" in result.body


class TestHandlerErrorFallback:
    async def test_error_in_resolve_depth_falls_back_to_shallow(self, healthy_registry):
        def resolve(req):
            raise RuntimeError("boom")

        handler = create_healthcheck_handler(registry=healthy_registry, resolve_depth=resolve)
        result = await handler({})
        assert result.status == 200
        assert result.body["status"] == "ok"

    async def test_invalid_return_falls_back_to_shallow(self, healthy_registry):
        handler = create_healthcheck_handler(
            registry=healthy_registry,
            resolve_depth=lambda _: "invalid",
        )
        result = await handler({})
        assert result.status == 200
        assert result.body["status"] == "ok"


class TestHandlerMetadata:
    async def test_metadata_in_deep_response(self, healthy_registry):
        handler = create_healthcheck_handler(
            registry=healthy_registry,
            resolve_depth=lambda _: "deep",
            metadata={"version": "1.0", "region": "us-east-1"},
        )
        result = await handler({})
        assert result.body["version"] == "1.0"
        assert result.body["region"] == "us-east-1"

    async def test_metadata_in_shallow_response(self, healthy_registry):
        handler = create_healthcheck_handler(
            registry=healthy_registry,
            metadata={"version": "1.0"},
        )
        result = await handler({})
        assert result.body["version"] == "1.0"

    async def test_shallow_metadata_override(self, healthy_registry):
        handler = create_healthcheck_handler(
            registry=healthy_registry,
            metadata={"version": "1.0", "region": "us-east-1"},
            shallow_metadata={"version": "1.0"},
        )
        result = await handler({})
        assert result.body["version"] == "1.0"
        assert "region" not in result.body

    async def test_cached_at_absent_on_fresh_deep(self, healthy_registry):
        handler = create_healthcheck_handler(
            registry=healthy_registry,
            resolve_depth=lambda _: "deep",
        )
        result = await handler({})
        assert "cachedAt" not in result.body

    async def test_cached_at_present_when_cached(self):
        registry = HealthcheckRegistry(cache_ttl_ms=60000)

        async def _check() -> CheckResult:
            return CheckResult(status=Status.HEALTHY, latency_ms=1.0)

        registry.add("db", _check)

        handler = create_healthcheck_handler(
            registry=registry,
            resolve_depth=lambda _: "deep",
        )
        await handler({})
        result = await handler({})
        assert "cachedAt" in result.body


class TestHandlerReservedKeys:
    @pytest.mark.parametrize("key", list(RESERVED_KEYS))
    def test_reserved_metadata_key_raises(self, healthy_registry, key):
        with pytest.raises(ValueError, match="reserved"):
            create_healthcheck_handler(registry=healthy_registry, metadata={key: "bad"})

    @pytest.mark.parametrize("key", list(RESERVED_KEYS))
    def test_reserved_shallow_metadata_key_raises(self, healthy_registry, key):
        with pytest.raises(ValueError, match="reserved"):
            create_healthcheck_handler(registry=healthy_registry, shallow_metadata={key: "bad"})
