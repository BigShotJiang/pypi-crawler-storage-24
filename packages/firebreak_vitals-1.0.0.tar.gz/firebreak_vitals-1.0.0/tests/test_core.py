"""Tests for vitals.core module."""

from __future__ import annotations

import asyncio
import time

import pytest

from vitals.core import HealthcheckRegistry, sync_check
from vitals.types import CheckResult, Status


class TestRegistryEmpty:
    """Test empty registry behavior."""

    async def test_empty_registry_returns_healthy(self):
        registry = HealthcheckRegistry()
        response = await registry.run()
        assert response.status == Status.HEALTHY
        assert response.checks == {}


class TestRegistryDuplicateCheck:
    """Test that duplicate check names are rejected."""

    async def test_duplicate_name_raises_value_error(self, healthy_check):
        registry = HealthcheckRegistry()
        registry.add("db", healthy_check)
        with pytest.raises(ValueError, match="already registered"):
            registry.add("db", healthy_check)


class TestRegistrySingleCheck:
    """Test registry with a single check."""

    async def test_single_healthy_check(self, healthy_check):
        registry = HealthcheckRegistry()
        registry.add("db", healthy_check)
        response = await registry.run()
        assert response.status == Status.HEALTHY
        assert "db" in response.checks
        assert response.checks["db"].status == Status.HEALTHY

    async def test_single_outage_check(self, outage_check):
        registry = HealthcheckRegistry()
        registry.add("db", outage_check)
        response = await registry.run()
        assert response.status == Status.OUTAGE
        assert response.checks["db"].status == Status.OUTAGE


class TestRegistryWorstOfAll:
    """Test that overall status is the worst of all checks."""

    async def test_healthy_and_degraded_yields_degraded(self, healthy_check, degraded_check):
        registry = HealthcheckRegistry()
        registry.add("fast", healthy_check)
        registry.add("slow", degraded_check)
        response = await registry.run()
        assert response.status == Status.DEGRADED

    async def test_degraded_and_outage_yields_outage(self, degraded_check, outage_check):
        registry = HealthcheckRegistry()
        registry.add("slow", degraded_check)
        registry.add("down", outage_check)
        response = await registry.run()
        assert response.status == Status.OUTAGE


class TestRegistryConcurrency:
    """Test that checks run concurrently."""

    async def test_concurrent_execution(self, slow_check):
        registry = HealthcheckRegistry()
        registry.add("check1", slow_check)
        registry.add("check2", slow_check)

        start = time.monotonic()
        response = await registry.run()
        elapsed = time.monotonic() - start

        assert response.status == Status.HEALTHY
        assert elapsed < 0.5, f"Two 0.3s checks should run concurrently, took {elapsed:.2f}s"


class TestRegistryTimeout:
    """Test timeout handling."""

    async def test_timeout_produces_outage(self, timeout_check):
        registry = HealthcheckRegistry(default_timeout=0.1)
        registry.add("slow", timeout_check)
        response = await registry.run()
        assert response.status == Status.OUTAGE
        assert response.checks["slow"].status == Status.OUTAGE
        assert "timeout" in response.checks["slow"].message.lower()

    async def test_per_check_timeout_override(self, timeout_check):
        registry = HealthcheckRegistry(default_timeout=5.0)
        registry.add("slow", timeout_check, timeout=0.1)
        response = await registry.run()
        assert response.status == Status.OUTAGE
        assert response.checks["slow"].status == Status.OUTAGE


class TestRegistryException:
    """Test exception handling in checks."""

    async def test_exception_produces_outage(self, error_check):
        registry = HealthcheckRegistry()
        registry.add("broken", error_check)
        response = await registry.run()
        assert response.status == Status.OUTAGE
        assert response.checks["broken"].status == Status.OUTAGE
        assert "something broke" in response.checks["broken"].message


class TestRegistryDecorator:
    """Test decorator-style registration."""

    async def test_decorator_registration(self):
        registry = HealthcheckRegistry()

        @registry.check("my_service")
        async def my_service_check() -> CheckResult:
            return CheckResult(status=Status.HEALTHY, latency_ms=1.0)

        response = await registry.run()
        assert response.status == Status.HEALTHY
        assert "my_service" in response.checks

    async def test_decorator_with_timeout(self):
        registry = HealthcheckRegistry()

        @registry.check("slow_service", timeout=0.1)
        async def slow_service_check() -> CheckResult:
            await asyncio.sleep(10.0)
            return CheckResult(status=Status.HEALTHY, latency_ms=0.0)

        response = await registry.run()
        assert response.status == Status.OUTAGE


class TestRegistryCaching:
    """Test cache TTL behavior."""

    async def test_no_cache_by_default(self, healthy_check):
        registry = HealthcheckRegistry()
        registry.add("db", healthy_check)
        r1 = await registry.run()
        r2 = await registry.run()
        assert r1.timestamp != r2.timestamp
        assert r1.cached_at is None
        assert r2.cached_at is None

    async def test_cached_response_has_cached_at(self, healthy_check):
        registry = HealthcheckRegistry(cache_ttl_ms=60000)
        registry.add("db", healthy_check)
        r1 = await registry.run()
        r2 = await registry.run()
        assert r1.cached_at is None
        assert r2.cached_at is not None
        assert r2.cached_at == r1.timestamp

    async def test_cached_response_has_fresh_timestamp(self, healthy_check):
        registry = HealthcheckRegistry(cache_ttl_ms=60000)
        registry.add("db", healthy_check)
        r1 = await registry.run()
        r2 = await registry.run()
        assert r2.timestamp >= r1.timestamp

    async def test_cache_preserves_check_results(self, healthy_check):
        registry = HealthcheckRegistry(cache_ttl_ms=60000)
        registry.add("db", healthy_check)
        r1 = await registry.run()
        r2 = await registry.run()
        assert r2.checks["db"].status == r1.checks["db"].status

    async def test_cache_returns_new_response_object(self, healthy_check):
        registry = HealthcheckRegistry(cache_ttl_ms=60000)
        registry.add("db", healthy_check)
        r1 = await registry.run()
        r2 = await registry.run()
        assert r1 is not r2


class TestSyncCheck:
    """Test sync_check wrapper."""

    async def test_sync_check_wraps_sync_callable(self):
        def my_sync_check() -> CheckResult:
            return CheckResult(status=Status.HEALTHY, latency_ms=5.0, message="sync ok")

        async_fn = sync_check(my_sync_check)
        result = await async_fn()
        assert result.status == Status.HEALTHY
        assert result.latency_ms == 5.0
        assert result.message == "sync ok"

    async def test_sync_check_works_in_registry(self):
        def my_sync_check() -> CheckResult:
            return CheckResult(status=Status.HEALTHY, latency_ms=2.0)

        registry = HealthcheckRegistry()
        registry.add("sync_service", sync_check(my_sync_check))
        response = await registry.run()
        assert response.status == Status.HEALTHY
        assert "sync_service" in response.checks
