"""Tests for vitals.html module."""

from __future__ import annotations

from vitals.html import render_healthcheck_html


class TestErrorResponse:
    def test_error_renders_red(self):
        html = render_healthcheck_html({"error": "Forbidden"})
        assert "#ED1C24" in html
        assert "Forbidden" in html

    def test_error_renders_error_badge(self):
        html = render_healthcheck_html({"error": "Forbidden"})
        assert "ERROR" in html

    def test_error_xss_escaped(self):
        html = render_healthcheck_html({"error": "<script>alert('xss')</script>"})
        assert "<script>" not in html
        assert "&lt;script&gt;" in html


class TestShallowResponse:
    def test_shallow_renders_green(self):
        body = {"status": "ok", "timestamp": "2025-01-15T12:00:00+00:00"}
        html = render_healthcheck_html(body)
        assert "#22C55E" in html
        assert "OK" in html

    def test_shallow_renders_timestamp(self):
        body = {"status": "ok", "timestamp": "2025-01-15T12:00:00+00:00"}
        html = render_healthcheck_html(body)
        assert "2025-01-15T12:00:00+00:00" in html

    def test_shallow_renders_metadata(self):
        body = {"status": "ok", "timestamp": "2025-01-15T12:00:00+00:00", "version": "1.0"}
        html = render_healthcheck_html(body)
        assert "version" in html
        assert "1.0" in html


class TestDeepResponse:
    def test_healthy_renders_green(self):
        body = {
            "status": "healthy",
            "timestamp": "2025-01-15T12:00:00+00:00",
            "checks": {"db": {"status": "healthy", "latencyMs": 5.0, "message": ""}},
        }
        html = render_healthcheck_html(body)
        assert "#22C55E" in html

    def test_degraded_renders_amber(self):
        body = {
            "status": "degraded",
            "timestamp": "2025-01-15T12:00:00+00:00",
            "checks": {"db": {"status": "degraded", "latencyMs": 500.0, "message": "slow"}},
        }
        html = render_healthcheck_html(body)
        assert "#F59E0B" in html

    def test_outage_renders_red(self):
        body = {
            "status": "outage",
            "timestamp": "2025-01-15T12:00:00+00:00",
            "checks": {"db": {"status": "outage", "latencyMs": 0.0, "message": "down"}},
        }
        html = render_healthcheck_html(body)
        assert "#ED1C24" in html

    def test_checks_sorted_alphabetically(self):
        body = {
            "status": "healthy",
            "timestamp": "2025-01-15T12:00:00+00:00",
            "checks": {
                "redis": {"status": "healthy", "latencyMs": 1.0, "message": ""},
                "api": {"status": "healthy", "latencyMs": 2.0, "message": ""},
                "db": {"status": "healthy", "latencyMs": 3.0, "message": ""},
            },
        }
        html = render_healthcheck_html(body)
        api_pos = html.index("api")
        db_pos = html.index("db")
        redis_pos = html.index("redis")
        assert api_pos < db_pos < redis_pos

    def test_deep_renders_metadata(self):
        body = {
            "status": "healthy",
            "timestamp": "2025-01-15T12:00:00+00:00",
            "checks": {},
            "version": "2.0",
        }
        html = render_healthcheck_html(body)
        assert "version" in html
        assert "2.0" in html

    def test_deep_xss_check_name(self):
        body = {
            "status": "healthy",
            "timestamp": "2025-01-15T12:00:00+00:00",
            "checks": {"<img src=x>": {"status": "healthy", "latencyMs": 1.0, "message": ""}},
        }
        html = render_healthcheck_html(body)
        assert "<img src=x>" not in html
        assert "&lt;img src=x&gt;" in html


class TestHtmlStructure:
    def test_valid_html_structure(self):
        body = {"status": "ok", "timestamp": "2025-01-15T12:00:00+00:00"}
        html = render_healthcheck_html(body)
        assert html.startswith("<!DOCTYPE html>")
        assert "<html" in html
        assert "</html>" in html
        assert "<body" in html
        assert "</body>" in html
        assert "Healthcheck" in html
