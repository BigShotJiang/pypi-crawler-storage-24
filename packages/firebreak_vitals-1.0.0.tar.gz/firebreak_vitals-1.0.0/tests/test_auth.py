"""Tests for vitals.auth module."""

from __future__ import annotations

import pytest

from vitals.auth import extract_token, verify_token


class TestVerifyToken:
    """Test verify_token function."""

    def test_matching_tokens(self):
        assert verify_token("my-secret-token", "my-secret-token") is True

    def test_mismatching_tokens(self):
        assert verify_token("wrong-token", "my-secret-token") is False

    def test_empty_provided(self):
        assert verify_token("", "my-secret-token") is False

    def test_empty_expected(self):
        assert verify_token("my-secret-token", "") is False

    def test_both_empty(self):
        assert verify_token("", "") is False


class TestExtractToken:
    """Test extract_token function."""

    def test_from_query_param(self):
        token = extract_token(query_params={"token": "abc123"})
        assert token == "abc123"

    def test_from_bearer_header(self):
        token = extract_token(authorization_header="Bearer abc123")
        assert token == "abc123"

    def test_query_param_takes_precedence(self):
        token = extract_token(
            query_params={"token": "from-query"},
            authorization_header="Bearer from-header",
        )
        assert token == "from-query"

    def test_no_token_returns_none(self):
        token = extract_token()
        assert token is None

    def test_no_token_empty_params(self):
        token = extract_token(query_params={}, authorization_header=None)
        assert token is None

    def test_custom_param_name(self):
        token = extract_token(
            query_params={"api_key": "custom123"},
            query_param_name="api_key",
        )
        assert token == "custom123"

    def test_malformed_bearer_basic(self):
        token = extract_token(authorization_header="Basic xyz")
        assert token is None

    def test_malformed_bearer_no_prefix(self):
        token = extract_token(authorization_header="abc123")
        assert token is None

    def test_bearer_case_sensitive(self):
        # "Bearer " must have capital B
        token = extract_token(authorization_header="bearer abc123")
        assert token is None

    def test_empty_query_param_value(self):
        token = extract_token(query_params={"token": ""})
        assert token is None

    def test_empty_bearer_value(self):
        token = extract_token(authorization_header="Bearer ")
        assert token is None
