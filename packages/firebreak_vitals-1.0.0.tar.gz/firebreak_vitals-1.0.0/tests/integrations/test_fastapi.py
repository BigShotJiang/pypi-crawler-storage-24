"""Tests for vitals.integrations.fastapi module."""

from __future__ import annotations

import pytest

fastapi = pytest.importorskip("fastapi")
pytest.importorskip("httpx")

from fastapi import FastAPI
from fastapi.testclient import TestClient

from vitals.core import HealthcheckRegistry
from vitals.integrations.fastapi import create_healthcheck_route
from vitals.types import CheckResult, Status


@pytest.fixture
def healthy_registry() -> HealthcheckRegistry:
    """Return a HealthcheckRegistry with a single check that always returns HEALTHY."""
    registry = HealthcheckRegistry()

    async def _healthy_check() -> CheckResult:
        return CheckResult(status=Status.HEALTHY, latency_ms=1.0, message="")

    registry.add("test_service", _healthy_check)
    return registry


@pytest.fixture
def failing_registry() -> HealthcheckRegistry:
    """Return a HealthcheckRegistry with a check that returns OUTAGE."""
    registry = HealthcheckRegistry()

    async def _failing_check() -> CheckResult:
        return CheckResult(status=Status.OUTAGE, latency_ms=0.0, message="connection refused")

    registry.add("test_service", _failing_check)
    return registry


@pytest.fixture
def client(healthy_registry: HealthcheckRegistry) -> TestClient:
    """Create a FastAPI app with auth-protected healthcheck route."""
    app = FastAPI()
    router = create_healthcheck_route(healthy_registry, token="test-secret")
    app.include_router(router)
    return TestClient(app)


@pytest.fixture
def client_no_auth(healthy_registry: HealthcheckRegistry) -> TestClient:
    """Create a FastAPI app with no-auth healthcheck route."""
    app = FastAPI()
    router = create_healthcheck_route(healthy_registry, token=None)
    app.include_router(router)
    return TestClient(app)


class TestFastapiIntegration:
    """Tests for the FastAPI healthcheck integration."""

    def test_healthy_response(self, client: TestClient) -> None:
        response = client.get("/healthcheck/deep?token=test-secret")
        assert response.status_code == 200
        body = response.json()
        assert body["status"] == "healthy"
        assert isinstance(body["timestamp"], str)
        assert isinstance(body["checks"], dict)

    def test_missing_token_returns_403(self, client: TestClient) -> None:
        response = client.get("/healthcheck/deep")
        assert response.status_code == 403
        assert response.json() == {"error": "Forbidden"}

    def test_invalid_token_returns_403(self, client: TestClient) -> None:
        response = client.get("/healthcheck/deep?token=wrong")
        assert response.status_code == 403
        assert response.json() == {"error": "Forbidden"}

    def test_bearer_auth(self, client: TestClient) -> None:
        response = client.get(
            "/healthcheck/deep",
            headers={"Authorization": "Bearer test-secret"},
        )
        assert response.status_code == 200
        body = response.json()
        assert body["status"] == "healthy"

    def test_unhealthy_returns_503(self, failing_registry: HealthcheckRegistry) -> None:
        app = FastAPI()
        router = create_healthcheck_route(failing_registry, token="test-secret")
        app.include_router(router)
        test_client = TestClient(app)

        response = test_client.get("/healthcheck/deep?token=test-secret")
        assert response.status_code == 503
        body = response.json()
        assert body["status"] == "outage"

    def test_no_auth_when_token_is_none(self, client_no_auth: TestClient) -> None:
        response = client_no_auth.get("/healthcheck/deep")
        assert response.status_code == 200
        body = response.json()
        assert body["status"] == "healthy"

    def test_response_matches_spec_format(self, client: TestClient) -> None:
        response = client.get("/healthcheck/deep?token=test-secret")
        assert response.status_code == 200
        body = response.json()
        assert set(body.keys()) == {"status", "timestamp", "checks"}
        assert isinstance(body["status"], str)
        assert isinstance(body["timestamp"], str)
        assert isinstance(body["checks"], dict)
        for check_name, check_data in body["checks"].items():
            assert isinstance(check_name, str)
            assert set(check_data.keys()) == {"status", "latencyMs", "message"}

    def test_custom_path(self, healthy_registry: HealthcheckRegistry) -> None:
        app = FastAPI()
        router = create_healthcheck_route(healthy_registry, token=None, path="/custom/health")
        app.include_router(router)
        test_client = TestClient(app)

        response = test_client.get("/custom/health")
        assert response.status_code == 200
        body = response.json()
        assert body["status"] == "healthy"


class TestFastapiHtmlResponse:
    """Tests for HTML content negotiation."""

    def test_html_response_on_accept_html(self, client_no_auth: TestClient) -> None:
        response = client_no_auth.get("/healthcheck/deep", headers={"Accept": "text/html"})
        assert response.status_code == 200
        assert "text/html" in response.headers["content-type"]
        assert "<!DOCTYPE html>" in response.text
        assert "Healthcheck" in response.text

    def test_json_response_on_accept_json(self, client_no_auth: TestClient) -> None:
        response = client_no_auth.get("/healthcheck/deep", headers={"Accept": "application/json"})
        assert response.status_code == 200
        assert "application/json" in response.headers["content-type"]
        body = response.json()
        assert body["status"] == "healthy"

    def test_html_error_on_forbidden(self, client: TestClient) -> None:
        response = client.get("/healthcheck/deep", headers={"Accept": "text/html"})
        assert response.status_code == 403
        assert "text/html" in response.headers["content-type"]
        assert "Forbidden" in response.text


class TestFastapiShallowDepth:
    """Tests for shallow depth resolution."""

    def test_shallow_response(self, healthy_registry: HealthcheckRegistry) -> None:
        app = FastAPI()
        router = create_healthcheck_route(
            healthy_registry,
            token=None,
            resolve_depth=lambda _: "shallow",
        )
        app.include_router(router)
        test_client = TestClient(app)

        response = test_client.get("/healthcheck/deep")
        assert response.status_code == 200
        body = response.json()
        assert body["status"] == "ok"
        assert "checks" not in body


class TestFastapiMetadata:
    """Tests for metadata in responses."""

    def test_metadata_in_deep_response(self, healthy_registry: HealthcheckRegistry) -> None:
        app = FastAPI()
        router = create_healthcheck_route(
            healthy_registry,
            token=None,
            metadata={"version": "1.0"},
        )
        app.include_router(router)
        test_client = TestClient(app)

        response = test_client.get("/healthcheck/deep")
        assert response.status_code == 200
        body = response.json()
        assert body["version"] == "1.0"
        assert body["status"] == "healthy"

    def test_metadata_in_shallow_response(self, healthy_registry: HealthcheckRegistry) -> None:
        app = FastAPI()
        router = create_healthcheck_route(
            healthy_registry,
            token=None,
            resolve_depth=lambda _: "shallow",
            metadata={"version": "1.0"},
        )
        app.include_router(router)
        test_client = TestClient(app)

        response = test_client.get("/healthcheck/deep")
        assert response.status_code == 200
        body = response.json()
        assert body["version"] == "1.0"
        assert body["status"] == "ok"
