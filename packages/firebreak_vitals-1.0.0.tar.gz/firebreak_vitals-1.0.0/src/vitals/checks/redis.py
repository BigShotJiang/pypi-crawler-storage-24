"""Redis health check implementations."""

from __future__ import annotations

import time
from typing import Any

from vitals.types import CheckResult, Status


class RedisCheck:
    """Health check that creates a fresh Redis client and pings.

    Args:
        url: Redis connection URL (e.g. "redis://localhost:6379/0").
        **client_kwargs: Additional keyword arguments passed to redis.asyncio.from_url().
    """

    def __init__(self, url: str, **client_kwargs: Any) -> None:
        self._url = url
        self._client_kwargs = client_kwargs

    async def __call__(self) -> CheckResult:
        import redis.asyncio as aioredis

        client = None
        start = time.monotonic()
        try:
            client = aioredis.from_url(self._url, **self._client_kwargs)
            result = await client.ping()
            if not result:
                raise ConnectionError("PING returned False")
            elapsed = (time.monotonic() - start) * 1000
            return CheckResult(status=Status.HEALTHY, latency_ms=elapsed)
        except Exception as exc:
            elapsed = (time.monotonic() - start) * 1000
            return CheckResult(status=Status.OUTAGE, latency_ms=elapsed, message=str(exc))
        finally:
            if client is not None:
                await client.aclose()


class RedisPoolCheck:
    """Health check using an existing Redis connection pool.

    Args:
        pool: A redis.asyncio.ConnectionPool instance.
    """

    def __init__(self, pool: Any) -> None:
        self._pool = pool

    async def __call__(self) -> CheckResult:
        import redis.asyncio as aioredis

        client = None
        start = time.monotonic()
        try:
            client = aioredis.Redis(connection_pool=self._pool)
            result = await client.ping()
            if not result:
                raise ConnectionError("PING returned False")
            elapsed = (time.monotonic() - start) * 1000
            return CheckResult(status=Status.HEALTHY, latency_ms=elapsed)
        except Exception as exc:
            elapsed = (time.monotonic() - start) * 1000
            return CheckResult(status=Status.OUTAGE, latency_ms=elapsed, message=str(exc))
        finally:
            if client is not None:
                await client.aclose(close_connection_pool=False)
