"""HTTP health check implementation."""

from __future__ import annotations

import time

from vitals.types import CheckResult, Status


class HttpCheck:
    """Health check that performs an HTTP request and checks for a 2xx response.

    Args:
        url: The URL to check.
        method: HTTP method to use. Defaults to "GET".
        headers: Optional request headers.
        timeout: Request timeout in seconds. Defaults to 5.0.
    """

    def __init__(
        self,
        url: str,
        *,
        method: str = "GET",
        headers: dict[str, str] | None = None,
        timeout: float = 5.0,
    ) -> None:
        self._url = url
        self._method = method
        self._headers = headers
        self._timeout = timeout

    async def __call__(self) -> CheckResult:
        import httpx

        start = time.monotonic()
        try:
            async with httpx.AsyncClient() as client:
                response = await client.request(
                    self._method,
                    self._url,
                    headers=self._headers,
                    timeout=self._timeout,
                )
                elapsed = (time.monotonic() - start) * 1000
                if 200 <= response.status_code < 300:
                    return CheckResult(status=Status.HEALTHY, latency_ms=elapsed)
                return CheckResult(
                    status=Status.OUTAGE,
                    latency_ms=elapsed,
                    message=f"HTTP {response.status_code}",
                )
        except httpx.TimeoutException:
            elapsed = (time.monotonic() - start) * 1000
            return CheckResult(
                status=Status.OUTAGE,
                latency_ms=elapsed,
                message=f"Request to {self._url} timed out after {self._timeout}s",
            )
        except Exception as exc:
            elapsed = (time.monotonic() - start) * 1000
            return CheckResult(status=Status.OUTAGE, latency_ms=elapsed, message=str(exc))
