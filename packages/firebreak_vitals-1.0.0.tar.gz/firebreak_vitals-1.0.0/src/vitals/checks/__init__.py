"""Health check protocol definition."""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from vitals.types import CheckResult

__all__ = ["HealthCheck"]


@runtime_checkable
class HealthCheck(Protocol):
    """Protocol for async health check callables."""

    async def __call__(self) -> CheckResult: ...
