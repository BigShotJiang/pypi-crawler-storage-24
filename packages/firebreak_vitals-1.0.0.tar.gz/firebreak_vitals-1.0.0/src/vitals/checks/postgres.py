"""PostgreSQL health check implementations."""

from __future__ import annotations

import time
from typing import Any

from vitals.types import CheckResult, Status


class AsyncpgCheck:
    """Health check that creates a fresh asyncpg connection and runs SELECT 1.

    Args:
        dsn: PostgreSQL connection string.
        **connect_kwargs: Additional keyword arguments passed to asyncpg.connect().
    """

    def __init__(self, dsn: str, **connect_kwargs: Any) -> None:
        self._dsn = dsn
        self._connect_kwargs = connect_kwargs

    async def __call__(self) -> CheckResult:
        import asyncpg

        conn = None
        start = time.monotonic()
        try:
            conn = await asyncpg.connect(self._dsn, **self._connect_kwargs)
            await conn.fetchval("SELECT 1")
            elapsed = (time.monotonic() - start) * 1000
            return CheckResult(status=Status.HEALTHY, latency_ms=elapsed)
        except Exception as exc:
            elapsed = (time.monotonic() - start) * 1000
            return CheckResult(status=Status.OUTAGE, latency_ms=elapsed, message=str(exc))
        finally:
            if conn is not None:
                await conn.close()


class AsyncpgPoolCheck:
    """Health check that borrows a connection from an existing asyncpg pool.

    Args:
        pool: An asyncpg connection pool instance.
    """

    def __init__(self, pool: Any) -> None:
        self._pool = pool

    async def __call__(self) -> CheckResult:
        start = time.monotonic()
        try:
            async with self._pool.acquire() as conn:
                await conn.fetchval("SELECT 1")
            elapsed = (time.monotonic() - start) * 1000
            return CheckResult(status=Status.HEALTHY, latency_ms=elapsed)
        except Exception as exc:
            elapsed = (time.monotonic() - start) * 1000
            return CheckResult(status=Status.OUTAGE, latency_ms=elapsed, message=str(exc))


class SQLAlchemyCheck:
    """Health check using a SQLAlchemy AsyncEngine.

    Args:
        engine: A SQLAlchemy AsyncEngine instance.
    """

    def __init__(self, engine: Any) -> None:
        self._engine = engine

    async def __call__(self) -> CheckResult:
        from sqlalchemy import text

        start = time.monotonic()
        try:
            async with self._engine.connect() as conn:
                await conn.execute(text("SELECT 1"))
            elapsed = (time.monotonic() - start) * 1000
            return CheckResult(status=Status.HEALTHY, latency_ms=elapsed)
        except Exception as exc:
            elapsed = (time.monotonic() - start) * 1000
            return CheckResult(status=Status.OUTAGE, latency_ms=elapsed, message=str(exc))
