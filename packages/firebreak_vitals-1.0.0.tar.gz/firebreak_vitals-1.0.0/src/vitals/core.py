"""Core healthcheck registry for running checks concurrently."""

from __future__ import annotations

import asyncio
import functools
import logging
import time
from collections.abc import Callable, Coroutine
from datetime import datetime, timezone
from typing import Any, TypeAlias

from vitals.types import CheckResult, HealthcheckResponse, Status

logger = logging.getLogger("vitals")

AsyncCheckFn: TypeAlias = Callable[[], Coroutine[Any, Any, CheckResult]]


class HealthcheckRegistry:
    """Registry for healthcheck functions that runs them concurrently."""

    def __init__(self, default_timeout: float = 5.0, cache_ttl_ms: int = 0) -> None:
        self._default_timeout = default_timeout
        self._checks: dict[str, tuple[AsyncCheckFn, float | None]] = {}
        self._cache_ttl_ms = cache_ttl_ms
        self._cached_response: HealthcheckResponse | None = None
        self._cache_expires_at: float = 0.0

    def add(self, name: str, check: AsyncCheckFn, *, timeout: float | None = None) -> None:
        """Register a named async callable returning CheckResult."""
        if name in self._checks:
            raise ValueError(f"Health check {name!r} is already registered")
        self._checks[name] = (check, timeout)

    def check(self, name: str, *, timeout: float | None = None) -> Callable[[AsyncCheckFn], AsyncCheckFn]:
        """Decorator form of add()."""

        def decorator(fn: AsyncCheckFn) -> AsyncCheckFn:
            self.add(name, fn, timeout=timeout)
            return fn

        return decorator

    async def run(self) -> HealthcheckResponse:
        """Run all registered checks concurrently and return an aggregate response."""
        if self._cache_ttl_ms <= 0:
            return await self._execute_checks()

        now = time.monotonic()
        if self._cached_response is not None and now < self._cache_expires_at:
            return HealthcheckResponse(
                status=self._cached_response.status,
                timestamp=datetime.now(timezone.utc),
                checks=self._cached_response.checks,
                cached_at=self._cached_response.timestamp,
            )

        response = await self._execute_checks()
        self._cached_response = response
        self._cache_expires_at = time.monotonic() + self._cache_ttl_ms / 1000
        return response

    async def _execute_checks(self) -> HealthcheckResponse:
        """Execute all registered checks concurrently."""
        if not self._checks:
            return HealthcheckResponse(status=Status.HEALTHY)

        results: dict[str, CheckResult] = {}

        async with asyncio.TaskGroup() as tg:
            tasks: dict[str, asyncio.Task[CheckResult]] = {}
            for name, (check_fn, per_check_timeout) in self._checks.items():
                effective_timeout = per_check_timeout if per_check_timeout is not None else self._default_timeout
                tasks[name] = tg.create_task(self._run_single(name, check_fn, effective_timeout))

        for name, task in tasks.items():
            results[name] = task.result()

        overall_status = min(results.values(), key=lambda r: r.status.value).status

        return HealthcheckResponse(status=overall_status, checks=results)

    @staticmethod
    async def _run_single(name: str, check_fn: AsyncCheckFn, timeout: float) -> CheckResult:
        """Execute a single check with timeout and exception handling."""
        start = time.monotonic()
        try:
            result = await asyncio.wait_for(check_fn(), timeout=timeout)
        except asyncio.TimeoutError:
            elapsed = (time.monotonic() - start) * 1000
            logger.warning("Health check %r failed: %s", name, f"Timeout after {timeout}s")
            return CheckResult(status=Status.OUTAGE, latency_ms=elapsed, message=f"Timeout after {timeout}s")
        except Exception as exc:
            elapsed = (time.monotonic() - start) * 1000
            logger.warning("Health check %r failed: %s", name, exc)
            return CheckResult(status=Status.OUTAGE, latency_ms=elapsed, message=str(exc))
        else:
            return result


def sync_check(fn: Callable[[], CheckResult]) -> AsyncCheckFn:
    """Wrap a synchronous callable with asyncio.to_thread for use with the async registry."""

    @functools.wraps(fn)
    async def wrapper() -> CheckResult:
        return await asyncio.to_thread(fn)

    return wrapper
