"""HTML rendering for healthcheck responses."""

from __future__ import annotations

import html
from typing import Any

from vitals.types import RESERVED_KEYS


def _escape(value: str) -> str:
    return html.escape(value, quote=True)


def _status_color(status: str) -> str:
    if status in ("healthy", "ok"):
        return "#22C55E"
    if status == "degraded":
        return "#F59E0B"
    return "#ED1C24"


def _is_error_response(body: dict[str, Any]) -> bool:
    return "error" in body and "status" not in body


def _is_shallow_response(body: dict[str, Any]) -> bool:
    return "status" in body and body["status"] == "ok"


def _is_deep_response(body: dict[str, Any]) -> bool:
    return "checks" in body and "status" in body and body["status"] != "ok"


def _render_status_badge(label: str, color: str) -> str:
    return (
        f'<span style="'
        f"display: inline-flex;"
        f"align-items: center;"
        f"gap: 8px;"
        f"padding: 4px 12px;"
        f"border-radius: 9999px;"
        f"background: {color}1A;"
        f"font-family: 'Inter', system-ui, sans-serif;"
        f"font-size: 12px;"
        f"font-weight: 600;"
        f"letter-spacing: 0.05em;"
        f"text-transform: uppercase;"
        f"color: {color};"
        f'">'
        f'<span style="'
        f"width: 8px;"
        f"height: 8px;"
        f"border-radius: 50%;"
        f"background: {color};"
        f"box-shadow: 0 0 6px {color}80;"
        f'"></span>'
        f"{_escape(label)}</span>"
    )


def _render_metadata_items(items: list[tuple[str, str]]) -> str:
    if not items:
        return ""
    inner = ""
    for label, value in items:
        inner += (
            f"<div>"
            f'<div style="'
            f"font-family: 'Inter', system-ui, sans-serif;"
            f"font-size: 10px;"
            f"font-weight: 600;"
            f"letter-spacing: 0.05em;"
            f"text-transform: uppercase;"
            f"color: #A1A1AA;"
            f"margin-bottom: 4px;"
            f'">{_escape(label)}</div>'
            f'<div style="'
            f"font-family: 'JetBrains Mono', monospace;"
            f"font-size: 13px;"
            f"color: #E4E4E7;"
            f'">{_escape(value)}</div>'
            f"</div>"
        )
    return (
        f'<div style="'
        f"display: flex;"
        f"flex-wrap: wrap;"
        f"gap: 24px;"
        f"margin-top: 16px;"
        f'">{inner}</div>'
    )


def _render_check_row(name: str, check: dict[str, Any]) -> str:
    color = _status_color(check["status"])
    return (
        f'<div style="'
        f"display: flex;"
        f"align-items: center;"
        f"gap: 12px;"
        f"padding: 12px 0;"
        f"border-top: 1px solid #27272A;"
        f'">'
        f'<span style="'
        f"width: 8px;"
        f"height: 8px;"
        f"border-radius: 50%;"
        f"background: {color};"
        f"box-shadow: 0 0 6px {color}80;"
        f"flex-shrink: 0;"
        f'"></span>'
        f'<span style="'
        f"font-family: 'Inter', system-ui, sans-serif;"
        f"font-size: 12px;"
        f"text-transform: uppercase;"
        f"letter-spacing: 0.05em;"
        f"color: {color};"
        f"font-weight: 600;"
        f"min-width: 72px;"
        f'">{_escape(check["status"])}</span>'
        f'<span style="'
        f"font-family: 'Inter', system-ui, sans-serif;"
        f"font-size: 14px;"
        f"font-weight: 500;"
        f"color: #E4E4E7;"
        f"flex: 1;"
        f'">{_escape(name)}</span>'
        f'<span style="'
        f"font-family: 'JetBrains Mono', monospace;"
        f"font-size: 12px;"
        f"color: #A1A1AA;"
        f"min-width: 60px;"
        f"text-align: right;"
        f'">{_escape(str(check["latencyMs"]))}ms</span>'
        f'<span style="'
        f"font-family: 'JetBrains Mono', monospace;"
        f"font-size: 12px;"
        f"color: #71717A;"
        f"max-width: 200px;"
        f"overflow: hidden;"
        f"text-overflow: ellipsis;"
        f"white-space: nowrap;"
        f'">{_escape(check["message"])}</span>'
        f"</div>"
    )


def _render_page(border_color: str, content: str) -> str:
    return (
        '<!DOCTYPE html>\n'
        '<html lang="en">\n'
        "<head>\n"
        '  <meta charset="utf-8">\n'
        '  <meta name="viewport" content="width=device-width, initial-scale=1">\n'
        "  <title>Healthcheck</title>\n"
        "  <style></style>\n"
        "</head>\n"
        '<body style="'
        "margin: 0;"
        "padding: 40px 20px;"
        "background: #08080A;"
        "min-height: 100vh;"
        "display: flex;"
        "justify-content: center;"
        "align-items: flex-start;"
        "box-sizing: border-box;"
        '">\n'
        '  <div style="'
        "width: 100%;"
        "max-width: 560px;"
        "background: #18181B;"
        "border: 1px solid #27272A;"
        f"border-left: 3px solid {border_color};"
        "border-radius: 8px;"
        "padding: 24px;"
        '">\n'
        f"    {content}\n"
        "  </div>\n"
        "</body>\n"
        "</html>"
    )


def _render_header(badge: str) -> str:
    return (
        '<div style="display: flex; align-items: center; justify-content: space-between;">'
        '<span style="'
        "font-family: 'Inter', system-ui, sans-serif;"
        "font-size: 18px;"
        "font-weight: 700;"
        "color: #E4E4E7;"
        '">Healthcheck</span>'
        f"{badge}"
        "</div>"
    )


def render_healthcheck_html(body: dict[str, Any]) -> str:
    """Render a healthcheck response body as a styled HTML page."""
    if _is_error_response(body):
        color = "#ED1C24"
        content = (
            f"{_render_header(_render_status_badge('ERROR', color))}"
            f'<div style="'
            f"margin-top: 16px;"
            f"font-family: 'JetBrains Mono', monospace;"
            f"font-size: 13px;"
            f"color: #EF4444;"
            f'">{_escape(body["error"])}</div>'
        )
        return _render_page(color, content)

    if _is_shallow_response(body):
        color = _status_color("ok")
        metadata_items: list[tuple[str, str]] = [("timestamp", body.get("timestamp", ""))]
        for k, v in body.items():
            if k not in ("status", "timestamp"):
                metadata_items.append((k, str(v)))
        content = f"{_render_header(_render_status_badge('OK', color))}{_render_metadata_items(metadata_items)}"
        return _render_page(color, content)

    if _is_deep_response(body):
        color = _status_color(body["status"])
        metadata_items = [("timestamp", body.get("timestamp", ""))]
        for k, v in body.items():
            if k not in RESERVED_KEYS:
                metadata_items.append((k, str(v)))

        checks = body.get("checks", {})
        check_rows = "".join(
            _render_check_row(name, check)
            for name, check in sorted(checks.items())
        )

        content = (
            f"{_render_header(_render_status_badge(body['status'], color))}"
            f"{_render_metadata_items(metadata_items)}"
            f'<div style="margin-top: 20px;">{check_rows}</div>'
        )
        return _render_page(color, content)

    return _render_page(
        "#ED1C24",
        f'<pre style="color: #E4E4E7; font-family: \'JetBrains Mono\', monospace;">{_escape(str(body))}</pre>',
    )
