"""FastAPI integration for vitals."""

from __future__ import annotations

from fastapi import APIRouter, Request, Response
from fastapi.responses import HTMLResponse, JSONResponse

from vitals.auth import extract_token, verify_token
from vitals.core import HealthcheckRegistry
from vitals.handler import ResolveDepthFn, create_healthcheck_handler
from vitals.html import render_healthcheck_html
from vitals.types import MetadataDict


def _prefers_html(accept: str | None) -> bool:
    if not accept:
        return False
    return "text/html" in accept


def create_healthcheck_route(
    registry: HealthcheckRegistry,
    *,
    token: str | None = None,
    path: str = "/healthcheck/deep",
    query_param_name: str = "token",
    include_in_schema: bool = False,
    resolve_depth: ResolveDepthFn | None = None,
    metadata: MetadataDict | None = None,
    shallow_metadata: MetadataDict | None = None,
) -> APIRouter:
    """Create a FastAPI APIRouter with a healthcheck GET endpoint."""
    effective_resolve_depth = resolve_depth if resolve_depth is not None else lambda _: "deep"

    handler = create_healthcheck_handler(
        registry=registry,
        resolve_depth=effective_resolve_depth,
        metadata=metadata,
        shallow_metadata=shallow_metadata,
    )

    router = APIRouter()

    @router.get(path, include_in_schema=include_in_schema)
    async def healthcheck(request: Request) -> Response:
        want_html = _prefers_html(request.headers.get("accept"))

        if token is not None:
            provided = extract_token(
                query_params=dict(request.query_params),
                authorization_header=request.headers.get("authorization"),
                query_param_name=query_param_name,
            )
            if provided is None or not verify_token(provided, token):
                error_body = {"error": "Forbidden"}
                if want_html:
                    return HTMLResponse(
                        status_code=403,
                        content=render_healthcheck_html(error_body),
                    )
                return JSONResponse(status_code=403, content=error_body)

        result = await handler({"headers": dict(request.headers), "query": dict(request.query_params)})

        if want_html:
            return HTMLResponse(status_code=result.status, content=render_healthcheck_html(result.body))
        return JSONResponse(status_code=result.status, content=result.body)

    return router
