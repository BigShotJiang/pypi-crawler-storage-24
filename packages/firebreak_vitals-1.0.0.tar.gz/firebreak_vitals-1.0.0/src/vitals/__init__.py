"""Deep healthcheck — structured health endpoints following the HEALTHCHECK_SPEC format."""

from vitals._version import __version__
from vitals.auth import extract_token, verify_token
from vitals.checks import HealthCheck
from vitals.core import HealthcheckRegistry, sync_check
from vitals.handler import HandlerResult, create_healthcheck_handler
from vitals.html import render_healthcheck_html
from vitals.types import CheckResult, HealthcheckResponse, ShallowResponse, Status

__all__ = [
    "CheckResult",
    "HandlerResult",
    "HealthCheck",
    "HealthcheckRegistry",
    "HealthcheckResponse",
    "ShallowResponse",
    "Status",
    "__version__",
    "create_healthcheck_handler",
    "extract_token",
    "render_healthcheck_html",
    "sync_check",
    "verify_token",
]
