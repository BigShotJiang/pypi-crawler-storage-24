"""Data model types for vitals responses."""

from __future__ import annotations

import enum
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Union

MetadataDict = dict[str, Union[str, int, bool]]
RESERVED_KEYS = frozenset({"status", "timestamp", "checks", "cachedAt"})


class Status(enum.Enum):
    """Health status with numeric values for ordering (higher = healthier)."""

    HEALTHY = 2
    DEGRADED = 1
    OUTAGE = 0

    @classmethod
    def from_string(cls, value: str) -> Status:
        """Parse a status string, with backward compatibility.

        Mappings:
            "healthy" -> HEALTHY
            "ok"      -> HEALTHY  (backward compat)
            "degraded" -> DEGRADED
            "outage"  -> OUTAGE
            "error"   -> OUTAGE  (backward compat)
            unknown   -> OUTAGE
        """
        mapping: dict[str, Status] = {
            "healthy": cls.HEALTHY,
            "ok": cls.HEALTHY,
            "degraded": cls.DEGRADED,
            "outage": cls.OUTAGE,
            "error": cls.OUTAGE,
        }
        return mapping.get(value.lower(), cls.OUTAGE)

    @property
    def json_value(self) -> str:
        """Return the lowercase name for JSON serialization."""
        return self.name.lower()


@dataclass(frozen=True)
class CheckResult:
    """Result of a single health check."""

    status: Status
    latency_ms: float
    message: str = ""


@dataclass
class HealthcheckResponse:
    """Aggregate healthcheck response containing all check results."""

    status: Status
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    checks: dict[str, CheckResult] = field(default_factory=dict)
    cached_at: datetime | None = None

    @property
    def http_status_code(self) -> int:
        """Return 200 for HEALTHY, 503 otherwise."""
        return 200 if self.status == Status.HEALTHY else 503

    def to_dict(self) -> dict[str, Any]:
        """Serialize to the HEALTHCHECK_SPEC JSON format."""
        result: dict[str, Any] = {
            "status": self.status.json_value,
            "timestamp": self.timestamp.isoformat(),
            "checks": {
                name: {
                    "status": cr.status.json_value,
                    "latencyMs": cr.latency_ms,
                    "message": cr.message,
                }
                for name, cr in self.checks.items()
            },
        }
        if self.cached_at is not None:
            result["cachedAt"] = self.cached_at.isoformat()
        return result


@dataclass(frozen=True)
class ShallowResponse:
    """Minimal healthcheck response for shallow depth."""

    status: str = "ok"
    timestamp: str = ""
    metadata: MetadataDict = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to flat dict, merging metadata into top level."""
        result: dict[str, Any] = {
            "status": self.status,
            "timestamp": self.timestamp,
        }
        result.update(self.metadata)
        return result
