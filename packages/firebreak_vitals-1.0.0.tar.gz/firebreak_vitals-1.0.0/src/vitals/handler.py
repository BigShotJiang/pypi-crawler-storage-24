"""Healthcheck request handler with depth resolution and metadata."""

from __future__ import annotations

import inspect
import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Callable

from vitals.core import HealthcheckRegistry
from vitals.types import RESERVED_KEYS, MetadataDict, ShallowResponse

logger = logging.getLogger("vitals")

ResolveDepthFn = Callable[[dict[str, Any]], Any]


@dataclass(frozen=True)
class HandlerResult:
    """Result returned by the healthcheck handler."""

    status: int
    body: dict[str, Any]


def create_healthcheck_handler(
    *,
    registry: HealthcheckRegistry,
    resolve_depth: ResolveDepthFn | None = None,
    metadata: MetadataDict | None = None,
    shallow_metadata: MetadataDict | None = None,
) -> Callable[[dict[str, Any]], Any]:
    """Create an async handler function for healthcheck requests."""
    meta = metadata or {}
    shallow_meta = shallow_metadata

    for bag in [meta, shallow_meta or {}]:
        for key in bag:
            if key in RESERVED_KEYS:
                raise ValueError(f"Metadata key '{key}' is reserved. Use a different key name.")

    async def handler(req: dict[str, Any]) -> HandlerResult:
        depth = "shallow"

        if resolve_depth is not None:
            try:
                result = resolve_depth(req)
                if inspect.isawaitable(result):
                    result = await result
                if result in ("deep", "shallow"):
                    depth = result
            except Exception:
                logger.warning("resolve_depth raised an exception, defaulting to shallow", exc_info=True)

        if depth == "deep":
            response = await registry.run()
            body = {**meta, **response.to_dict()}
            return HandlerResult(status=response.http_status_code, body=body)

        effective_meta = shallow_meta if shallow_meta is not None else meta
        shallow = ShallowResponse(
            status="ok",
            timestamp=datetime.now(timezone.utc).isoformat(),
            metadata=effective_meta,
        )
        return HandlerResult(status=200, body=shallow.to_dict())

    return handler
