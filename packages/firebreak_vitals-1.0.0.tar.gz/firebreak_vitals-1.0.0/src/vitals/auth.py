"""Token authentication utilities for healthcheck endpoints."""

from __future__ import annotations

import hashlib
import hmac


def verify_token(provided: str, expected: str) -> bool:
    """Verify a provided token against an expected token using constant-time comparison.

    Both values are SHA256-hashed before comparison to ensure constant-time
    behavior regardless of input length. Returns False if either value is empty.
    """
    if not provided or not expected:
        return False

    provided_hash = hashlib.sha256(provided.encode()).digest()
    expected_hash = hashlib.sha256(expected.encode()).digest()
    return hmac.compare_digest(provided_hash, expected_hash)


def extract_token(
    *,
    query_params: dict[str, str] | None = None,
    authorization_header: str | None = None,
    query_param_name: str = "token",
) -> str | None:
    """Extract a token from query parameters or an Authorization header.

    Checks query param first, then Bearer header prefix. Returns the first
    non-empty match, or None if no token is found.
    """
    # Check query param first
    if query_params:
        value = query_params.get(query_param_name, "")
        if value:
            return value

    # Then check Authorization: Bearer header
    if authorization_header and authorization_header.startswith("Bearer "):
        token = authorization_header[len("Bearer ") :]
        if token:
            return token

    return None
