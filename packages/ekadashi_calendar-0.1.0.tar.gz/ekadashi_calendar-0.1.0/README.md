# Ekadashi Python Library

A Python library to calculate ISKCON / Vaishnava Ekadashi dates using Swiss Ephemeris.

## Installation

pip install ekadashi

## Example

```python
import ekadashi

print(ekadashi.next_ekadashi())

print(ekadashi.get_ekadashi_dates(2026))

print(ekadashi.is_ekadashi("2026-03-29"))