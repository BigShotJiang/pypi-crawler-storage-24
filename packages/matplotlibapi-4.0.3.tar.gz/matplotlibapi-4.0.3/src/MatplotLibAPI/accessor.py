"""Pandas accessor exposing MatplotLibAPI plotting helpers."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from matplotlib.axes import Axes
from matplotlib.figure import Figure
from pandas.api.extensions import register_dataframe_accessor

from .style_template import (
    FIG_SIZE,
    AREA_STYLE_TEMPLATE,
    DISTRIBUTION_STYLE_TEMPLATE,
    PIE_STYLE_TEMPLATE,
    TABLE_STYLE_TEMPLATE,
    TIMESERIE_STYLE_TEMPLATE,
    TREEMAP_STYLE_TEMPLATE,
    StyleTemplate,
)

from .types import CorrelationMethod

if TYPE_CHECKING:
    import plotly.graph_objects as go


@register_dataframe_accessor("mpl")
class DataFrameAccessor:
    """Expose MatplotLibAPI plotting helpers as a pandas accessor.

    All plot methods follow the BasePlot interface pattern, providing both
    aplot_* (plot on existing axes) and fplot_* (plot on new figure) variants
    for consistency and ease of use.

    Methods
    -------
    aplot_bubble
        Plot a bubble chart using the underlying DataFrame.
    fplot_bubble
        Plot a bubble chart on a new figure.
    fplot_composite_bubble
        Plot a composite bubble chart with summary tables.
    aplot_bar
        Plot a bar or stacked bar chart on existing axes.
    fplot_bar
        Plot a bar or stacked bar chart on a new figure.
    aplot_histogram_kde
        Plot a histogram with optional KDE overlay.
    fplot_histogram_kde
        Plot a histogram with optional KDE overlay on a new figure.
    aplot_box_violin
        Plot box or violin plots to summarize distributions.
    fplot_box_violin
        Plot box or violin plots on a new figure.
    aplot_heatmap
        Plot a heatmap for dense categorical combinations.
    fplot_heatmap
        Plot a heatmap on a new figure.
    aplot_correlation_matrix
        Plot a correlation matrix heatmap.
    fplot_correlation_matrix
        Plot a correlation matrix heatmap on a new figure.
    aplot_area
        Plot an area chart, optionally stacked.
    fplot_area
        Plot an area chart, optionally stacked, on a new figure.
    aplot_pie_donut
        Plot pie or donut charts for categorical shares.
    fplot_pie_donut
        Plot pie or donut charts on a new figure.
    aplot_waffle
        Plot waffle charts for categorical proportions.
    fplot_waffle
        Plot waffle charts on a new figure.
    fplot_sankey
        Plot a Sankey diagram for flow data.
    aplot_table
        Plot a table of the DataFrame's data on a Matplotlib axes.
    fplot_table
        Plot a table of the DataFrame's data on a new figure.
    aplot_timeserie
        Plot a time series on a Matplotlib axes.
    fplot_timeserie
        Plot a time series on a new figure.
    aplot_wordcloud
        Plot a word cloud on a Matplotlib axes.
    fplot_wordcloud
        Plot a word cloud on a new figure.
    aplot_network
        Plot a network graph on a Matplotlib axes.
    aplot_network_node
        Plot the connected component for a specific node on a Matplotlib axes.
    aplot_network_components
        Plot connected components of a network graph on multiple axes.
    fplot_network
        Plot a network graph on a new figure.
    fplot_network_node
        Plot the connected component for a specific node on a new figure.
    fplot_network_components
        Plot connected components of a network graph on a new figure.
    fplot_treemap
        Plot a treemap on a new Plotly figure.
    fplot_sunburst
        Plot a sunburst chart on a new Plotly figure.
    fplot_composite_treemap
        Plot a composite treemap on a new Plotly figure.
    """

    def __init__(self, pd_df: pd.DataFrame):
        """Store the parent DataFrame."""
        self._obj = pd_df

    def aplot_bubble(
        self,
        label: str,
        x: str,
        y: str,
        z: str,
        title: Optional[str] = None,
        style: Optional[StyleTemplate] = None,
        max_values: int = 50,
        center_to_mean: bool = False,
        sort_by: Optional[str] = None,
        ascending: bool = False,
        hline: bool = False,
        vline: bool = False,
        ax: Optional[Axes] = None,
    ) -> Axes:
        """Plot a bubble chart using the underlying DataFrame.

        Parameters
        ----------
        label : str
            Column to use for bubble labels.
        x : str
            Column to use for the x-axis.
        y : str
            Column to use for the y-axis.
        z : str
            Column to use for the bubble size.
        title : str, optional
            Chart title.
        style : StyleTemplate, optional
            Styling template. The default is `BUBBLE_STYLE_TEMPLATE`.
        max_values : int, optional
            Maximum number of bubbles to plot. The default is 50.
        center_to_mean : bool, optional
            If True, center x-axis values around the mean. The default is `False`.
        sort_by : str, optional
            Column to sort by before plotting.
        ascending : bool, optional
            Sort order. The default is `False`.
        hline : bool, optional
            If True, draw a horizontal line at the mean of y-values. The default is `False`.
        vline : bool, optional
            If True, draw a vertical line at the mean of x-values. The default is `False`.
        ax : Axes, optional
            Matplotlib axes to plot on. If None, uses the current axes.

        Returns
        -------
        Axes
            The Matplotlib axes object with the plot.
        """
        from .bubble import Bubble, BUBBLE_STYLE_TEMPLATE

        return Bubble(
            pd_df=self._obj,
            label=label,
            x=x,
            y=y,
            z=z,
            max_values=max_values,
            center_to_mean=center_to_mean,
            sort_by=sort_by,
            ascending=ascending,
        ).aplot(
            title=title,
            style=style or BUBBLE_STYLE_TEMPLATE,
            hline=hline,
            vline=vline,
            ax=ax,
        )

    def fplot_bubble(
        self,
        label: str,
        x: str,
        y: str,
        z: str,
        title: Optional[str] = None,
        style: Optional[StyleTemplate] = None,
        max_values: int = 50,
        center_to_mean: bool = False,
        sort_by: Optional[str] = None,
        ascending: bool = False,
        hline: bool = False,
        vline: bool = False,
        figsize: Tuple[float, float] = FIG_SIZE,
    ) -> Figure:
        """Plot a bubble chart on a new figure.

        Parameters
        ----------
        label : str
            Column to use for bubble labels.
        x : str
            Column to use for the x-axis.
        y : str
            Column to use for the y-axis.
        z : str
            Column to use for the bubble size.
        title : str, optional
            Chart title.
        style : StyleTemplate, optional
            Styling template. The default is `BUBBLE_STYLE_TEMPLATE`.
        max_values : int, optional
            Maximum number of bubbles to plot. The default is 50.
        center_to_mean : bool, optional
            If True, center x-axis values around the mean. The default is `False`.
        sort_by : str, optional
            Column to sort by before plotting.
        ascending : bool, optional
            Sort order. The default is `False`.
        hline : bool, optional
            If True, draw a horizontal line at the mean of y-values. The default is `False`.
        vline : bool, optional
            If True, draw a vertical line at the mean of x-values. The default is `False`.
        figsize : tuple[float, float], optional
            Figure size. The default is FIG_SIZE.

        Returns
        -------
        Figure
            The new Matplotlib figure with the plot.
        """
        from .bubble import Bubble, BUBBLE_STYLE_TEMPLATE

        return Bubble(
            pd_df=self._obj,
            label=label,
            x=x,
            y=y,
            z=z,
            sort_by=sort_by,
            ascending=ascending,
            max_values=max_values,
            center_to_mean=center_to_mean,
        ).fplot(
            title=title,
            style=style or BUBBLE_STYLE_TEMPLATE,
            hline=hline,
            vline=vline,
            figsize=figsize,
        )

    def fplot_composite_bubble(
        self,
        label: str,
        x: str,
        y: str,
        z: str,
        title: Optional[str] = None,
        style: Optional[StyleTemplate] = None,
        max_values: int = 100,
        center_to_mean: bool = False,
        sort_by: Optional[str] = None,
        ascending: bool = False,
        table_rows: int = 10,
    ) -> Figure:
        """Plot a composite bubble chart with summary tables.

        This plot combines a bubble chart with tables summarizing the
        top and bottom rows of the dataset.

        Parameters
        ----------
        label : str
            Column to use for bubble labels.
        x : str
            Column to use for the x-axis.
        y : str
            Column to use for the y-axis.
        z : str
            Column to use for the bubble size.
        title : str, optional
            Chart title.
        style : StyleTemplate, optional
            Styling template. The default is `BUBBLE_STYLE_TEMPLATE`.
        max_values : int, optional
            Maximum number of bubbles to plot. The default is 100.
        center_to_mean : bool, optional
            If True, center x-axis values around the mean. The default is `False`.
        sort_by : str, optional
            Column to sort by before plotting.
        ascending : bool, optional
            Sort order. The default is `False`.
        table_rows : int, optional
            Number of rows for the summary tables. The default is 10.

        Returns
        -------
        Figure
            The new Matplotlib figure with the composite plot.
        """
        from .composite import plot_composite_bubble as _plot_composite_bubble

        return _plot_composite_bubble(
            pd_df=self._obj,
            label=label,
            x=x,
            y=y,
            z=z,
            title=title,
            style=style,
            max_values=max_values,
            center_to_mean=center_to_mean,
            sort_by=sort_by,
            ascending=ascending,
            table_rows=table_rows,
        )

    def aplot_histogram_kde(
        self,
        column: str,
        bins: int = 20,
        kde: bool = True,
        title: Optional[str] = None,
        style: StyleTemplate = DISTRIBUTION_STYLE_TEMPLATE,
        ax: Optional[Axes] = None,
    ) -> Axes:
        """Plot a histogram with an optional KDE overlay.

        Parameters
        ----------
        column : str
            Column to plot.
        bins : int, optional
            Number of bins. The default is 20.
        kde : bool, optional
            Whether to add a KDE line. The default is ``True``.
        title : str, optional
            Chart title.
        style : StyleTemplate, optional
            Styling template. The default is ``DISTRIBUTION_STYLE_TEMPLATE``.
        ax : Axes, optional
            Matplotlib axes to plot on. If None, uses the current axes.

        Returns
        -------
        Axes
            The Matplotlib axes object with the histogram.
        """
        from .histogram import aplot_histogram as _aplot_histogram

        return _aplot_histogram(
            pd_df=self._obj,
            column=column,
            bins=bins,
            kde=kde,
            title=title,
            style=style,
            ax=ax,
        )

    def fplot_histogram_kde(
        self,
        column: str,
        bins: int = 20,
        kde: bool = True,
        title: Optional[str] = None,
        style: StyleTemplate = DISTRIBUTION_STYLE_TEMPLATE,
        figsize: Tuple[float, float] = FIG_SIZE,
    ) -> Figure:
        """Plot a histogram with an optional KDE on a new figure.

        Parameters
        ----------
        column : str
            Column to plot.
        bins : int, optional
            Number of bins. The default is 20.
        kde : bool, optional
            Whether to add a KDE line. The default is ``True``.
        title : str, optional
            Chart title.
        style : StyleTemplate, optional
            Styling template. The default is ``DISTRIBUTION_STYLE_TEMPLATE``.
        figsize : tuple[float, float], optional
            Figure size. The default is FIG_SIZE.

        Returns
        -------
        Figure
            The new Matplotlib figure with the histogram.
        """
        from .histogram import fplot_histogram as _fplot_histogram

        return _fplot_histogram(
            pd_df=self._obj,
            column=column,
            bins=bins,
            kde=kde,
            title=title,
            style=style,
            figsize=figsize,
        )

    def aplot_heatmap(
        self,
        x: str,
        y: str,
        value: str,
        title: Optional[str] = None,
        style: Optional[StyleTemplate] = None,
        ax: Optional[Axes] = None,
    ) -> Axes:
        """Plot a heatmap for dense categorical combinations.

        Parameters
        ----------
        x : str
            Column for heatmap columns.
        y : str
            Column for heatmap rows.
        value : str
            Column for heatmap values.
        title : str, optional
            Chart title.
        style : StyleTemplate, optional
            Styling template. The default is ``HEATMAP_STYLE_TEMPLATE``.
        ax : Axes, optional
            Matplotlib axes to plot on. If None, uses the current axes.

        Returns
        -------
        Axes
            The Matplotlib axes object with the heatmap.
        """
        from .heatmap import aplot_heatmap as _aplot_heatmap

        return _aplot_heatmap(
            pd_df=self._obj,
            x=x,
            y=y,
            value=value,
            title=title,
            style=style or DISTRIBUTION_STYLE_TEMPLATE,
            ax=ax,
        )

    def fplot_heatmap(
        self,
        x: str,
        y: str,
        value: str,
        title: Optional[str] = None,
        style: Optional[StyleTemplate] = None,
        figsize: Tuple[float, float] = FIG_SIZE,
    ) -> Figure:
        """Plot a heatmap on a new figure.

        Parameters
        ----------
        x : str
            Column for heatmap columns.
        y : str
            Column for heatmap rows.
        value : str
            Column for heatmap values.
        title : str, optional
            Chart title.
        style : StyleTemplate, optional
            Styling template. The default is ``HEATMAP_STYLE_TEMPLATE``.
        figsize : tuple[float, float], optional
            Figure size. The default is FIG_SIZE.

        Returns
        -------
        Figure
            The new Matplotlib figure with the heatmap.
        """
        from .heatmap import fplot_heatmap as _fplot_heatmap

        return _fplot_heatmap(
            pd_df=self._obj,
            x=x,
            y=y,
            value=value,
            title=title,
            style=style,
            figsize=figsize,
        )

    def aplot_correlation_matrix(
        self,
        x: str,
        y: str,
        value: str,
        method: CorrelationMethod = "pearson",
        title: Optional[str] = None,
        style: Optional[StyleTemplate] = None,
        ax: Optional[Axes] = None,
    ) -> Axes:
        """Plot a correlation matrix heatmap.

        Parameters
        ----------
        columns : list[str], optional
            Numeric columns to include. The default is ``None`` for all numeric columns.
        method : CorrelationMethod, optional
            Correlation method. The default is "pearson".
        title : str, optional
            Chart title.
        style : StyleTemplate, optional
            Styling template. The default is ``HEATMAP_STYLE_TEMPLATE``.
        ax : Axes, optional
            Matplotlib axes to plot on. If None, uses the current axes.

        Returns
        -------
        Axes
            The Matplotlib axes object with the correlation matrix.
        """
        from .heatmap import aplot_correlation_matrix as _aplot_correlation_matrix

        return _aplot_correlation_matrix(
            pd_df=self._obj,
            x=x,
            y=y,
            value=value,
            method=method,
            title=title,
            style=style,
            ax=ax,
        )

    def fplot_correlation_matrix(
        self,
        x: str,
        y: str,
        value: str,
        method: CorrelationMethod = "pearson",
        title: Optional[str] = None,
        style: Optional[StyleTemplate] = None,
    ) -> Figure:
        """Plot a correlation matrix heatmap.

        Parameters
        ----------
        columns : list[str], optional
            Numeric columns to include. The default is ``None`` for all numeric columns.
        method : CorrelationMethod, optional
            Correlation method. The default is "pearson".
        title : str, optional
            Chart title.
        style : StyleTemplate, optional
            Styling template. The default is ``HEATMAP_STYLE_TEMPLATE``.
        ax : Axes, optional
            Matplotlib axes to plot on. If None, uses the current axes.

        Returns
        -------
        Axes
            The Matplotlib axes object with the correlation matrix.
        """
        from .heatmap import fplot_correlation_matrix as _fplot_correlation_matrix

        return _fplot_correlation_matrix(
            pd_df=self._obj,
            x=x,
            y=y,
            value=value,
            title=title,
            style=style,
            correlation_method=method,
        )

    def aplot_area(
        self,
        x: str,
        y: str,
        label: Optional[str] = None,
        stacked: bool = True,
        title: Optional[str] = None,
        style: Optional[StyleTemplate] = None,
        ax: Optional[Axes] = None,
        **kwargs: Any,
    ) -> Axes:
        """Plot an area chart, optionally stacked.

        Parameters
        ----------
        x : str
            Column used for x-axis values.
        y : str
            Column used for y-axis values.
        label : str, optional
            Column used to split areas into groups. The default is ``None``.
        stacked : bool, optional
            Whether grouped areas are stacked. The default is ``True``.
        title : str, optional
            Chart title.
        style : StyleTemplate, optional
            Styling template. The default is ``AREA_STYLE_TEMPLATE``.
        ax : Axes, optional
            Matplotlib axes to plot on. If None, uses the current axes.
        **kwargs : Any
            Additional keyword arguments forwarded to the area plotter.

        Returns
        -------
        Axes
            The Matplotlib axes object with the area chart.
        """
        from .area import aplot_area as _aplot_area

        return _aplot_area(
            pd_df=self._obj,
            x=x,
            y=y,
            label=label,
            stacked=stacked,
            title=title,
            style=style or AREA_STYLE_TEMPLATE,
            ax=ax,
            **kwargs,
        )

    def fplot_area(
        self,
        x: str,
        y: str,
        label: Optional[str] = None,
        stacked: bool = True,
        title: Optional[str] = None,
        style: Optional[StyleTemplate] = None,
        figsize: Tuple[float, float] = FIG_SIZE,
        **kwargs: Any,
    ) -> Figure:
        """Plot an area chart, optionally stacked, on a new figure.

        Parameters
        ----------
        x : str
            Column used for x-axis values.
        y : str
            Column used for y-axis values.
        label : str, optional
            Column used to split areas into groups. The default is ``None``.
        stacked : bool, optional
            Whether grouped areas are stacked. The default is ``True``.
        title : str, optional
            Chart title.
        style : StyleTemplate, optional
            Styling template. The default is ``AREA_STYLE_TEMPLATE``.
        figsize : tuple[float, float], optional
            Figure size. The default is FIG_SIZE.
        **kwargs : Any
            Additional keyword arguments forwarded to the area plotter.

        Returns
        -------
        Figure
            The new Matplotlib figure with the area chart.
        """
        from .area import fplot_area as _fplot_area

        return _fplot_area(
            pd_df=self._obj,
            x=x,
            y=y,
            label=label,
            stacked=stacked,
            title=title,
            style=style or AREA_STYLE_TEMPLATE,
            figsize=figsize,
            **kwargs,
        )

    def aplot_pie_donut(
        self,
        category: str,
        value: str,
        donut: bool = False,
        title: Optional[str] = None,
        style: StyleTemplate = PIE_STYLE_TEMPLATE,
        ax: Optional[Axes] = None,
    ) -> Axes:
        """Plot pie or donut charts for categorical shares.

        Parameters
        ----------
        category : str
            Column for slice labels.
        value : str
            Column for slice sizes.
        donut : bool, optional
            Whether to draw a donut chart. The default is ``False``.
        title : str, optional
            Chart title.
        style : StyleTemplate, optional
            Styling template. The default is ``PIE_STYLE_TEMPLATE``.
        ax : Axes, optional
            Matplotlib axes to plot on. If None, uses the current axes.

        Returns
        -------
        Axes
            The Matplotlib axes object with the pie or donut chart.
        """
        from .pie import aplot_pie as _aplot_pie_donut

        return _aplot_pie_donut(
            pd_df=self._obj,
            category=category,
            value=value,
            donut=donut,
            title=title,
            style=style,
            ax=ax,
        )

    def fplot_pie_donut(
        self,
        category: str,
        value: str,
        donut: bool = False,
        title: Optional[str] = None,
        style: StyleTemplate = PIE_STYLE_TEMPLATE,
        figsize: Tuple[float, float] = FIG_SIZE,
    ) -> Figure:
        """Plot pie or donut charts on a new figure.

        Parameters
        ----------
        category : str
            Column for slice labels.
        value : str
            Column for slice sizes.
        donut : bool, optional
            Whether to draw a donut chart. The default is ``False``.
        title : str, optional
            Chart title.
        style : StyleTemplate, optional
            Styling template. The default is ``PIE_STYLE_TEMPLATE``.
        figsize : tuple[float, float], optional
            Figure size. The default is FIG_SIZE.

        Returns
        -------
        Figure
            The new Matplotlib figure with the pie or donut chart.
        """
        from .pie import fplot_pie as _fplot_pie_donut

        return _fplot_pie_donut(
            pd_df=self._obj,
            category=category,
            value=value,
            donut=donut,
            title=title,
            style=style,
            figsize=figsize,
        )

    def aplot_waffle(
        self,
        category: str,
        value: str,
        rows: int = 10,
        title: Optional[str] = None,
        style: StyleTemplate = PIE_STYLE_TEMPLATE,
        ax: Optional[Axes] = None,
    ) -> Axes:
        """Plot waffle charts for categorical proportions.

        Parameters
        ----------
        category : str
            Column for segment labels.
        value : str
            Column for segment sizes.
        rows : int, optional
            Number of grid rows. The default is 10.
        title : str, optional
            Chart title.
        style : StyleTemplate, optional
            Styling template. The default is ``PIE_STYLE_TEMPLATE``.
        ax : Axes, optional
            Matplotlib axes to plot on. If None, uses the current axes.

        Returns
        -------
        Axes
            The Matplotlib axes object with the waffle chart.
        """
        from .waffle import aplot_waffle as _aplot_waffle

        return _aplot_waffle(
            pd_df=self._obj,
            category=category,
            value=value,
            rows=rows,
            title=title,
            style=style,
            ax=ax,
        )

    def fplot_waffle(
        self,
        category: str,
        value: str,
        rows: int = 10,
        title: Optional[str] = None,
        style: StyleTemplate = PIE_STYLE_TEMPLATE,
        figsize: Tuple[float, float] = FIG_SIZE,
    ) -> Figure:
        """Plot waffle charts on a new figure.

        Parameters
        ----------
        category : str
            Column for segment labels.
        value : str
            Column for segment sizes.
        rows : int, optional
            Number of grid rows. The default is 10.
        title : str, optional
            Chart title.
        style : StyleTemplate, optional
            Styling template. The default is ``PIE_STYLE_TEMPLATE``.
        figsize : tuple[float, float], optional
            Figure size. The default is FIG_SIZE.

        Returns
        -------
        Figure
            The new Matplotlib figure with the waffle chart.
        """
        from .waffle import fplot_waffle as _fplot_waffle

        return _fplot_waffle(
            pd_df=self._obj,
            category=category,
            value=value,
            rows=rows,
            title=title,
            style=style,
            figsize=figsize,
        )

    def fplot_sankey(
        self,
        source: str,
        target: str,
        value: str,
        title: Optional[str] = None,
        style: Optional[StyleTemplate] = None,
    ) -> go.Figure:
        """Plot a Sankey diagram for flow data.

        Parameters
        ----------
        source : str
            Column for source nodes.
        target : str
            Column for target nodes.
        value : str
            Column for flow weights.
        title : str, optional
            Diagram title.
        style : StyleTemplate, optional
            Styling template. The default is ``SANKEY_STYLE_TEMPLATE``.

        Returns
        -------
        go.Figure
            The Plotly Sankey figure.
        """
        from .sankey import SANKEY_STYLE_TEMPLATE, fplot_sankey

        return fplot_sankey(
            pd_df=self._obj,
            source=source,
            target=target,
            value=value,
            title=title,
            style=style or SANKEY_STYLE_TEMPLATE,
        )

    def aplot_table(
        self,
        cols: List[str],
        title: Optional[str] = None,
        style: StyleTemplate = TABLE_STYLE_TEMPLATE,
        max_values: int = 20,
        sort_by: Optional[str] = None,
        ascending: bool = False,
        ax: Optional[Axes] = None,
    ) -> Axes:
        """Plot a table of the DataFrame's data on Matplotlib axes.

        Parameters
        ----------
        cols : list[str]
            Columns to include in the table.
        title : str, optional
            Table title.
        style : StyleTemplate, optional
            Styling template. The default is `TABLE_STYLE_TEMPLATE`.
        max_values : int, optional
            Maximum number of rows to show. The default is 20.
        sort_by : str, optional
            Column to sort by.
        ascending : bool, optional
            Sort order. The default is `False`.
        ax : Axes, optional
            Matplotlib axes to plot on. If None, uses the current axes.

        Returns
        -------
        Axes
            The Matplotlib axes object with the plot.
        """
        from .table import aplot_table as _aplot_table

        return _aplot_table(
            pd_df=self._obj,
            cols=cols,
            title=title,
            style=style or TABLE_STYLE_TEMPLATE,
            max_values=max_values,
            sort_by=sort_by,
            ascending=ascending,
            ax=ax,
        )

    def fplot_table(
        self,
        cols: List[str],
        title: Optional[str] = None,
        style: StyleTemplate = TABLE_STYLE_TEMPLATE,
        max_values: int = 20,
        sort_by: Optional[str] = None,
        ascending: bool = False,
        figsize: Tuple[float, float] = FIG_SIZE,
    ) -> Figure:
        """Plot a table of the DataFrame's data on a new figure.

        Parameters
        ----------
        cols : list[str]
            Columns to include in the table.
        title : str, optional
            Table title.
        style : StyleTemplate, optional
            Styling template. The default is `TABLE_STYLE_TEMPLATE`.
        max_values : int, optional
            Maximum number of rows to show. The default is 20.
        sort_by : str, optional
            Column to sort by.
        ascending : bool, optional
            Sort order. The default is `False`.
        figsize : tuple[float, float], optional
            Figure size. The default is FIG_SIZE.

        Returns
        -------
        Figure
            The new Matplotlib figure with the table.
        """
        from .table import fplot_table as _fplot_table

        return _fplot_table(
            pd_df=self._obj,
            cols=cols,
            title=title,
            style=style or TABLE_STYLE_TEMPLATE,
            max_values=max_values,
            sort_by=sort_by,
            ascending=ascending,
            figsize=figsize,
        )

    def aplot_timeserie(
        self,
        label: str,
        x: str,
        y: str,
        title: Optional[str] = None,
        style: StyleTemplate = TIMESERIE_STYLE_TEMPLATE,
        max_values: int = 50,
        sort_by: Optional[str] = None,
        ascending: bool = False,
        std: bool = False,
        ax: Optional[Axes] = None,
    ) -> Axes:
        """Plot a time series on Matplotlib axes.

        Parameters
        ----------
        label : str
            Column for series labels.
        x : str
            Column for the x-axis.
        y : str
            Column for the y-axis.
        title : str, optional
            Chart title.
        style : StyleTemplate, optional
            Styling template. The default is `TIMESERIE_STYLE_TEMPLATE`.
        max_values : int, optional
            Maximum number of series to show. The default is 50.
        sort_by : str, optional
            Column to sort by.
        ascending : bool, optional
            Sort order. The default is `False`.
        std : bool, optional
            If True, plot the standard deviation. The default is `False`.
        ax : Axes, optional
            Matplotlib axes to plot on. If None, uses the current axes.

        Returns
        -------
        Axes
            The Matplotlib axes object with the plot.
        """
        from .timeserie import aplot_timeserie as _aplot_timeserie

        return _aplot_timeserie(
            pd_df=self._obj,
            label=label,
            x=x,
            y=y,
            title=title,
            style=style or TIMESERIE_STYLE_TEMPLATE,
            max_values=max_values,
            sort_by=sort_by,
            ascending=ascending,
            std=std,
            ax=ax,
        )

    def fplot_timeserie(
        self,
        label: str,
        x: str,
        y: str,
        title: Optional[str] = None,
        style: StyleTemplate = TIMESERIE_STYLE_TEMPLATE,
        max_values: int = 50,
        sort_by: Optional[str] = None,
        ascending: bool = False,
        std: bool = False,
        figsize: Tuple[float, float] = FIG_SIZE,
    ) -> Figure:
        """Plot a time series on a new figure.

        Parameters
        ----------
        label : str
            Column for series labels.
        x : str
            Column for the x-axis.
        y : str
            Column for the y-axis.
        title : str, optional
            Chart title.
        style : StyleTemplate, optional
            Styling template. The default is `TIMESERIE_STYLE_TEMPLATE`.
        max_values : int, optional
            Maximum number of series to show. The default is 50.
        sort_by : str, optional
            Column to sort by.
        ascending : bool, optional
            Sort order. The default is `False`.
        std : bool, optional
            If True, plot the standard deviation. The default is `False`.
        figsize : tuple[float, float], optional
            Figure size. The default is FIG_SIZE.

        Returns
        -------
        Figure
            The new Matplotlib figure with the plot.
        """
        from .timeserie import fplot_timeserie as _fplot_timeserie

        return _fplot_timeserie(
            pd_df=self._obj,
            label=label,
            x=x,
            y=y,
            title=title,
            style=style or TIMESERIE_STYLE_TEMPLATE,
            max_values=max_values,
            sort_by=sort_by,
            ascending=ascending,
            std=std,
            figsize=figsize,
        )

    def aplot_wordcloud(
        self,
        text_column: str,
        weight_column: str,
        title: Optional[str] = None,
        style: Optional[StyleTemplate] = None,
        max_words: int = 50,
        stopwords: Optional[List[str]] = None,
        random_state: Optional[int] = None,
        ax: Optional[Axes] = None,
    ) -> Axes:
        """Plot a word cloud on a Matplotlib axes.

        Parameters
        ----------
        text_column : str
            Column containing words or phrases.
        weight_column : str, optional
            Column containing numeric weights. The default is ``None`` for equal weights.
        title : str, optional
            Chart title.
        style : StyleTemplate, optional
            Styling template. The default is `WORDCLOUD_STYLE_TEMPLATE`.
        max_words : int, optional
            Maximum number of words to display. The default is 50.
        stopwords : list[str], optional
            Words to exclude from the visualization. The default is ``None``.
        random_state : int, optional
            Seed for word placement. The default is ``None``.
        ax : Axes, optional
            Matplotlib axes to plot on. If None, uses the current axes.

        Returns
        -------
        Axes
            The Matplotlib axes object with the plot.
        """
        from .word_cloud import WORDCLOUD_STYLE_TEMPLATE, aplot_wordcloud

        return aplot_wordcloud(
            pd_df=self._obj,
            text_column=text_column,
            weight_column=weight_column,
            title=title,
            style=style or WORDCLOUD_STYLE_TEMPLATE,
            max_words=max_words,
            stopwords=stopwords,
            random_state=random_state,
            ax=ax,
        )

    def fplot_wordcloud(
        self,
        text_column: str,
        weight_column: str,
        title: Optional[str] = None,
        style: Optional[StyleTemplate] = None,
        max_words: int = 50,
        stopwords: Optional[List[str]] = None,
        random_state: Optional[int] = None,
        figsize: Tuple[float, float] = FIG_SIZE,
    ) -> Figure:
        """Plot a word cloud on a new figure.

        Parameters
        ----------
        text_column : str
            Column containing words or phrases.
        weight_column : str, optional
            Column containing numeric weights. The default is ``None`` for equal weights.
        title : str, optional
            Chart title.
        style : StyleTemplate, optional
            Styling template. The default is `WORDCLOUD_STYLE_TEMPLATE`.
        max_words : int, optional
            Maximum number of words to display. The default is 50.
        stopwords : list[str], optional
            Words to exclude from the visualization. The default is ``None``.
        random_state : int, optional
            Seed for word placement. The default is ``None``.
        figsize : tuple[float, float], optional
            Figure size. The default is FIG_SIZE.

        Returns
        -------
        Figure
            The new Matplotlib figure with the plot.
        """
        from .word_cloud import WORDCLOUD_STYLE_TEMPLATE, fplot_wordcloud

        return fplot_wordcloud(
            pd_df=self._obj,
            text_column=text_column,
            weight_column=weight_column,
            title=title,
            style=style or WORDCLOUD_STYLE_TEMPLATE,
            max_words=max_words,
            stopwords=stopwords,
            random_state=random_state,
            figsize=figsize,
        )

    def aplot_network_node(
        self,
        node: Any,
        edge_source_col: str = "source",
        edge_target_col: str = "target",
        edge_weight_col: str = "weight",
        layout_seed: Optional[int] = None,
        title: Optional[str] = None,
        style: Optional[StyleTemplate] = None,
        ax: Optional[Axes] = None,
    ) -> Axes:
        """Plot the connected component containing ``node``.

        Parameters
        ----------
        node : Any
            Node identifier whose component should be visualized.
        node_col : str, optional
            Column for node identifiers. The default is "node".
        node_weight_col : str, optional
            Column for node weights. The default is "weight".
        edge_source_col : str, optional
            Column for source nodes. The default is "source".
        edge_target_col : str, optional
            Column for target nodes. The default is "target".
        edge_weight_col : str, optional
            Column for edge weights. The default is "weight".
        sort_by : str, optional
            Column to sort by.
        ascending : bool, optional
            Sort order. The default is `False`.
        node_df : pd.DataFrame, optional
            DataFrame containing ``node`` and ``weight`` columns for weighting.
        layout_seed : int, optional
            Seed forwarded to the spring layout. The default is ``_DEFAULT["SPRING_LAYOUT_SEED"]``.
        title : str, optional
            Chart title. Defaults to the formatted node label when ``None``.
        style : StyleTemplate, optional
            Styling template. The default is `NETWORK_STYLE_TEMPLATE`.
        ax : Axes, optional
            Matplotlib axes to plot on. If None, uses the current axes.

        Returns
        -------
        Axes
            The Matplotlib axes object with the plot.

        Raises
        ------
        ValueError
            If ``node`` is not present in the prepared graph.
        """
        kwargs: Dict[str, Any] = {}
        if layout_seed is not None:
            kwargs["layout_seed"] = layout_seed
        from .network import (
            NETWORK_STYLE_TEMPLATE,
            aplot_network_node as _aplot_network_node,
        )

        return _aplot_network_node(
            pd_df=self._obj,
            node=node,
            edge_source_col=edge_source_col,
            edge_target_col=edge_target_col,
            edge_weight_col=edge_weight_col,
            title=title,
            style=style or NETWORK_STYLE_TEMPLATE,
            ax=ax,
            **kwargs,
        )

    def aplot_network_components(
        self,
        edge_source_col: str = "source",
        edge_target_col: str = "target",
        edge_weight_col: str = "weight",
        sort_by: Optional[str] = None,
        ascending: bool = False,
        title: Optional[str] = None,
        style: Optional[StyleTemplate] = None,
        layout_seed: Optional[int] = None,
        axes: Optional[np.ndarray] = None,
    ) -> None:
        """Plot connected components of a network graph on multiple axes.

        Parameters
        ----------
        node_col : str, optional
            Column for node identifiers. The default is "node".
        node_weight_col : str, optional
            Column for node weights. The default is "weight".
        edge_source_col : str, optional
            Column for source nodes. The default is "source".
        edge_target_col : str, optional
            Column for target nodes. The default is "target".
        edge_weight_col : str, optional
            Column for edge weights. The default is "weight".
        sort_by : str, optional
            Column to sort by.
        ascending : bool, optional
            Sort order. The default is `False`.
        node_df : pd.DataFrame, optional
            DataFrame containing ``node`` and ``weight`` columns for weighting.
        title : str, optional
            Chart title.
        style : StyleTemplate, optional
            Styling template. The default is `NETWORK_STYLE_TEMPLATE`.
        layout_seed : int, optional
            Seed forwarded to the spring layout. The default is ``_DEFAULT["SPRING_LAYOUT_SEED"]``.
        axes : np.ndarray, optional
            Numpy array of Matplotlib axes to plot on. If None, new axes are created.
        """
        kwargs: Dict[str, Any] = {}
        if layout_seed is not None:
            kwargs["layout_seed"] = layout_seed

        from .network import NETWORK_STYLE_TEMPLATE, aplot_network_components

        aplot_network_components(
            pd_df=self._obj,
            edge_source_col=edge_source_col,
            edge_target_col=edge_target_col,
            edge_weight_col=edge_weight_col,
            sort_by=sort_by,
            ascending=ascending,
            title=title,
            style=style or NETWORK_STYLE_TEMPLATE,
            axes=axes,
            **kwargs,
        )

    def fplot_network_node(
        self,
        node: Any,
        edge_source_col: str = "source",
        edge_target_col: str = "target",
        edge_weight_col: str = "weight",
        layout_seed: Optional[int] = None,
        title: Optional[str] = None,
        style: Optional[StyleTemplate] = None,
        figsize: Tuple[float, float] = FIG_SIZE,
    ) -> Figure:
        """Plot the connected component containing ``node`` on a new figure.

        Parameters
        ----------
        node : Any
            Node identifier whose component should be visualized.
        node_col : str, optional
            Column for node identifiers. The default is "node".
        node_weight_col : str, optional
            Column for node weights. The default is "weight".
        edge_source_col : str, optional
            Column for source nodes. The default is "source".
        edge_target_col : str, optional
            Column for target nodes. The default is "target".
        edge_weight_col : str, optional
            Column for edge weights. The default is "weight".
        sort_by : str, optional
            Column to sort by.
        ascending : bool, optional
            Sort order. The default is `False`.
        node_df : pd.DataFrame, optional
            DataFrame containing ``node`` and ``weight`` columns for weighting.
        layout_seed : int, optional
            Seed forwarded to the spring layout. The default is ``_DEFAULT["SPRING_LAYOUT_SEED"]``.
        title : str, optional
            Chart title. Defaults to the formatted node label when ``None``.
        style : StyleTemplate, optional
            Styling template. The default is `NETWORK_STYLE_TEMPLATE`.
        figsize : tuple[float, float], optional
            Figure size. The default is FIG_SIZE.

        Returns
        -------
        Figure
            The new Matplotlib figure with the plot.

        Raises
        ------
        ValueError
            If ``node`` is not present in the prepared graph.
        """
        kwargs: Dict[str, Any] = {}
        if layout_seed is not None:
            kwargs["layout_seed"] = layout_seed

        from .network import NETWORK_STYLE_TEMPLATE, fplot_network_node

        return fplot_network_node(
            pd_df=self._obj,
            node=node,
            edge_source_col=edge_source_col,
            edge_target_col=edge_target_col,
            edge_weight_col=edge_weight_col,
            title=title,
            style=style or NETWORK_STYLE_TEMPLATE,
            figsize=figsize,
            **kwargs,
        )

    def fplot_network_components(
        self,
        edge_source_col: str = "source",
        edge_target_col: str = "target",
        edge_weight_col: str = "weight",
        title: Optional[str] = None,
        style: Optional[StyleTemplate] = None,
        layout_seed: Optional[int] = None,
        figsize: Tuple[float, float] = FIG_SIZE,
        n_cols: Optional[int] = None,
    ) -> Figure:
        """Plot network components on a new figure.

        Parameters
        ----------
        node_col : str, optional
            Column for node identifiers. The default is "node".
        node_weight_col : str, optional
            Column for node weights. The default is "weight".
        edge_source_col : str, optional
            Column for source nodes. The default is "source".
        edge_target_col : str, optional
            Column for target nodes. The default is "target".
        edge_weight_col : str, optional
            Column for edge weights. The default is "weight".
        sort_by : str, optional
            Column to sort by.
        ascending : bool, optional
            Sort order. The default is `False`.
        node_df : pd.DataFrame, optional
            DataFrame containing ``node`` and ``weight`` columns for weighting.
        title : str, optional
            Chart title.
        style : StyleTemplate, optional
            Styling template. The default is `NETWORK_STYLE_TEMPLATE`.
        layout_seed : int, optional
            Seed forwarded to the spring layout. The default is ``_DEFAULT["SPRING_LAYOUT_SEED"]``.
        figsize : tuple[float, float], optional
            Figure size. The default is FIG_SIZE.
        n_cols : int, optional
            Number of columns for arranging component subplots.

        Returns
        -------
        Figure
            The new Matplotlib figure with component plots.
        """
        kwargs: Dict[str, Any] = {}
        if layout_seed is not None:
            kwargs["layout_seed"] = layout_seed

        from .network import NETWORK_STYLE_TEMPLATE, fplot_network_components

        return fplot_network_components(
            pd_df=self._obj,
            edge_source_col=edge_source_col,
            edge_target_col=edge_target_col,
            edge_weight_col=edge_weight_col,
            title=title,
            style=style or NETWORK_STYLE_TEMPLATE,
            figsize=figsize,
            n_cols=n_cols,
            **kwargs,
        )

    def fplot_treemap(
        self,
        path: str,
        values: str,
        style: StyleTemplate = TREEMAP_STYLE_TEMPLATE,
        title: Optional[str] = None,
        color: Optional[str] = None,
        sort_by: Optional[str] = None,
        max_values: int = 100,
        ascending: bool = False,
        fig: Optional[go.Figure] = None,
    ) -> go.Figure:
        """Plot a treemap on a new Plotly figure.

        Parameters
        ----------
        path : str
            Column representing the hierarchical path.
        values : str
            Column with values for the treemap areas.
        style : StyleTemplate, optional
            Styling template. The default is `TREEMAP_STYLE_TEMPLATE`.
        title : str, optional
            Chart title.
        color : str, optional
            Column to use for coloring blocks. The default is ``None``.
        sort_by : str, optional
            Column to sort by.
        max_values : int, optional
            Maximum number of items to display. The default is 100.
        ascending : bool, optional
            Sort order. The default is `False`.
        fig : go.Figure, optional
            Existing Plotly figure to add to. If None, a new figure is created.

        Returns
        -------
        go.Figure
            The Plotly figure with the treemap.
        """
        from .treemap import fplot_treemap

        return fplot_treemap(
            pd_df=self._obj,
            path=path,
            values=values,
            style=style,
            title=title,
            color=color,
            sort_by=sort_by,
            max_values=max_values,
            ascending=ascending,
            fig=fig,  # type: ignore
        )

    def fplot_sunburst(
        self,
        labels: str,
        parents: str,
        values: str,
        style: StyleTemplate = TREEMAP_STYLE_TEMPLATE,
        title: Optional[str] = None,
    ) -> go.Figure:
        """Plot a sunburst chart on a new Plotly figure.

        Parameters
        ----------
        labels : str
            Column representing the labels of the sectors.
        parents : str
            Column representing the parent of each sector.
        values : str
            Column with values for the sunburst areas.
        style : StyleTemplate, optional
            Styling template. The default is `TREEMAP_STYLE_TEMPLATE`.
        title : str, optional
            Chart title.
        sort_by : str, optional
            Column to sort by. Defaults to the ``values`` column when omitted.
        max_values : int, optional
            Maximum number of items to display. The default is 100.
        ascending : bool, optional
            Sort order. The default is `False`.
        fig : go.Figure, optional
            Existing Plotly figure to add to. If None, a new figure is created.

        Returns
        -------
        go.Figure
            The Plotly figure with the sunburst chart.
        """
        from .sunburst import fplot_sunburst

        return fplot_sunburst(
            pd_df=self._obj,
            labels=labels,
            parents=parents,
            values=values,
            title=title,
            style=style,
        )

    def fplot_composite_treemap(
        self,
        paths: List[str],
        values: str,
        style: StyleTemplate = TREEMAP_STYLE_TEMPLATE,
        title: Optional[str] = None,
        color: Optional[str] = None,
        sort_by: Optional[str] = None,
        max_values: int = 100,
        ascending: bool = False,
        fig: Optional[go.Figure] = None,
    ) -> Optional[go.Figure]:
        """Plot a composite treemap on a new Plotly figure.

        Parameters
        ----------
        paths : list[str]
            Columns representing the hierarchy paths for each treemap.
        values : str
            Column with values for the treemap areas.
        style : StyleTemplate, optional
            Styling template. The default is `TREEMAP_STYLE_TEMPLATE`.
        title : str, optional
            Chart title.
        color : str, optional
            Column to use for color coding.
        sort_by : str, optional
            Column to sort by.
        max_values : int, optional
            Maximum number of items to display. The default is 100.
        ascending : bool, optional
            Sort order. The default is `False`.
        fig : go.Figure, optional
            Existing Plotly figure to add to. If None, a new figure is created.

        Returns
        -------
        go.Figure, optional
            The Plotly figure with the composite treemap, or None if the input data is empty.
        """
        from .composite import plot_composite_treemap

        pd_dfs: Dict[str, pd.DataFrame] = {}
        for path in paths:
            pd_dfs[path] = self._obj

        return plot_composite_treemap(
            pd_dfs=pd_dfs,
            values=values,
            title=title,
            style=style,
            color=color,
            sort_by=sort_by,
            ascending=ascending,
            max_values=max_values,
        )


__all__ = ["DataFrameAccessor"]
