mod z85;

use pyo3::prelude::*;

#[pymodule]
mod _core {
    use super::z85;
    use pyo3::exceptions::PyValueError;
    use pyo3::prelude::*;

    #[pyfunction]
    fn hello_from_bin() -> String {
        "Hello from bcs-rs!".to_string()
    }

    /// Decode a z85-encoded byte string into raw bytes (single-threaded).
    #[pyfunction]
    fn decode_z85(data: &[u8]) -> PyResult<Vec<u8>> {
        z85::decode_scalar(data).map_err(PyValueError::new_err)
    }

    /// Decode a z85-encoded byte string into raw bytes (Rayon parallel, releases GIL).
    #[pyfunction]
    fn decode_z85_parallel(py: Python<'_>, data: &[u8]) -> PyResult<Vec<u8>> {
        #[allow(deprecated)]
        py.allow_threads(|| z85::decode_parallel(data))
            .map_err(PyValueError::new_err)
    }
}
