"""Memory store with tier routing (ADR-004)."""

from __future__ import annotations

import os
from datetime import datetime, timezone
from pathlib import Path

from palaia.config import get_aliases, load_config, resolve_agent_with_aliases
from palaia.decay import classify_tier, days_since, decay_score
from palaia.entry import (
    content_hash,
    create_entry,
    extract_title_from_content,
    parse_entry,
    serialize_entry,
    update_access,
    validate_entry_type,
    validate_priority,
    validate_status,
)
from palaia.index import EmbeddingCache
from palaia.lock import PalaiaLock
from palaia.scope import can_access, normalize_scope
from palaia.wal import WAL, WALEntry

TIERS = ("hot", "warm", "cold")


class Store:
    """Memory store with WAL, locking, and tier management."""

    def __init__(self, palaia_root: Path):
        self.root = palaia_root
        self.config = load_config(palaia_root)
        self.wal = WAL(palaia_root)
        self.lock = PalaiaLock(palaia_root, self.config["lock_timeout_seconds"])
        self.embedding_cache = EmbeddingCache(palaia_root)
        self._aliases = get_aliases(palaia_root)

        # Ensure tier directories
        for tier in TIERS:
            (self.root / tier).mkdir(parents=True, exist_ok=True)

    def _resolve_names(self, agent: str | None) -> set[str] | None:
        """Resolve agent to all matching names via aliases."""
        if agent is None:
            return None
        if self._aliases:
            return resolve_agent_with_aliases(agent, self._aliases)
        return {agent}

    def recover(self) -> int:
        """Run WAL recovery on startup."""
        return self.wal.recover(self)

    def write(
        self,
        body: str,
        scope: str | None = None,
        agent: str | None = None,
        tags: list[str] | None = None,
        title: str | None = None,
        project: str | None = None,
        entry_type: str | None = None,
        status: str | None = None,
        priority: str | None = None,
        assignee: str | None = None,
        due_date: str | None = None,
        instance: str | None = None,
    ) -> str:
        """Write a new memory entry. Returns the entry ID.

        Scope cascade:
        1. Explicit --scope argument wins always
        2. Project default_scope if entry is in a project
        3. Global default_scope from config
        4. Hardcoded fallback: 'team'
        """
        if not body or not body.strip():
            raise ValueError("Cannot write empty content. Provide a non-empty text body.")

        # Scope cascade
        if scope is not None:
            # Explicit scope always wins
            scope = normalize_scope(scope)
        elif project:
            # Auto-create project if it doesn't exist, then use its default scope
            from palaia.project import ProjectManager

            pm = ProjectManager(self.root)
            proj = pm.ensure(project, default_scope=self.config["default_scope"])
            scope = normalize_scope(proj.default_scope)
        else:
            scope = normalize_scope(None, self.config["default_scope"])

        # Dedup check
        h = content_hash(body)
        existing = self._find_by_hash(h)
        if existing:
            return existing  # Already stored, return existing ID

        entry_text = create_entry(
            body,
            scope,
            agent,
            tags,
            title,
            project,
            entry_type=entry_type,
            status=status,
            priority=priority,
            assignee=assignee,
            due_date=due_date,
            instance=instance,
        )
        meta, _ = parse_entry(entry_text)
        entry_id = meta["id"]
        filename = f"{entry_id}.md"
        target = f"hot/{filename}"

        with self.lock:
            # WAL: log intent with payload for recovery
            wal_entry = WALEntry(
                operation="write",
                target=target,
                payload_hash=h,
                payload=entry_text,
            )
            self.wal.log(wal_entry)

            # Write the actual file
            self.write_raw(target, entry_text)

            # Commit WAL
            self.wal.commit(wal_entry)

        # Invalidate any stale embedding cache for this entry
        self.embedding_cache.invalidate(entry_id)

        return entry_id

    def edit(
        self,
        entry_id: str,
        body: str | None = None,
        agent: str | None = None,
        tags: list[str] | None = None,
        title: str | None = None,
        status: str | None = None,
        priority: str | None = None,
        assignee: str | None = None,
        due_date: str | None = None,
        entry_type: str | None = None,
    ) -> dict:
        """Edit an existing entry. Returns updated metadata.

        Enforces scope: agent in narrower scope cannot edit broader-scope entries.
        WAL-backed for crash safety.
        """
        path = self._find_entry(entry_id)
        if path is None:
            raise ValueError(f"Entry not found: {entry_id}")

        text = path.read_text(encoding="utf-8")
        meta, old_body = parse_entry(text)

        # Scope enforcement: agent must be able to access the entry
        entry_scope = meta.get("scope", "team")
        entry_agent = meta.get("agent")

        resolved = self._resolve_names(agent)
        if not can_access(entry_scope, agent, entry_agent, agent_names=resolved):
            raise PermissionError(
                f"Scope violation: agent '{agent}' cannot edit entry with scope '{entry_scope}' "
                f"(owned by '{entry_agent}')"
            )

        # Private entries: only the owning agent (or alias) can edit
        if entry_scope == "private" and agent != entry_agent:
            if not (resolved and entry_agent in resolved):
                raise PermissionError(
                    f"Scope violation: agent '{agent}' cannot edit private entry owned by '{entry_agent}'"
                )

        # Apply changes
        content_changed = False

        if body is not None:
            old_body = body
            meta["content_hash"] = content_hash(body)
            content_changed = True

        if tags is not None:
            meta["tags"] = tags

        if title is not None:
            meta["title"] = title
        elif content_changed:
            # Auto-update title from new content if no explicit title was set
            auto_title = extract_title_from_content(body)
            if auto_title:
                meta["title"] = auto_title

        if entry_type is not None:
            meta["type"] = validate_entry_type(entry_type)

        # Task-specific field updates
        if status is not None:
            validate_status(status)
            meta["status"] = status

        if priority is not None:
            validate_priority(priority)
            meta["priority"] = priority

        if assignee is not None:
            meta["assignee"] = assignee

        if due_date is not None:
            meta["due_date"] = due_date

        # Update access metadata
        meta["accessed"] = datetime.now(timezone.utc).isoformat()

        new_text = serialize_entry(meta, old_body)
        relative = str(path.relative_to(self.root))

        with self.lock:
            wal_entry = WALEntry(
                operation="write",
                target=relative,
                payload_hash=meta.get("content_hash", ""),
                payload=new_text,
            )
            self.wal.log(wal_entry)
            self.write_raw(relative, new_text)
            self.wal.commit(wal_entry)

        # Re-index embeddings if content changed
        if content_changed:
            self.embedding_cache.invalidate(entry_id)

        return meta

    def write_raw(self, target: str, content: str) -> None:
        """Write content to a target path (relative to palaia root). Used by WAL recovery."""
        path = self.root / target
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".tmp")
        with open(tmp, "w") as f:
            f.write(content)
            f.flush()
            os.fsync(f.fileno())
        tmp.rename(path)

    def delete_raw(self, target: str) -> None:
        """Delete a target path (relative to palaia root)."""
        path = self.root / target
        if path.exists():
            path.unlink()

    def read(
        self, entry_id: str, agent: str | None = None, projects: list[str] | None = None
    ) -> tuple[dict, str] | None:
        """Read a memory entry by ID. Updates access metadata."""
        path = self._find_entry(entry_id)
        if path is None:
            return None

        text = path.read_text(encoding="utf-8")
        meta, body = parse_entry(text)

        # Scope check
        resolved = self._resolve_names(agent)
        if not can_access(meta.get("scope", "team"), agent, meta.get("agent"), projects, resolved):
            return None

        # Update access
        meta = update_access(meta)
        new_text = serialize_entry(meta, body)

        with self.lock:
            self.write_raw(str(path.relative_to(self.root)), new_text)

        return meta, body

    def list_entries(
        self, tier: str = "hot", agent: str | None = None, projects: list[str] | None = None
    ) -> list[tuple[dict, str]]:
        """List all entries in a tier."""
        tier_dir = self.root / tier
        if not tier_dir.exists():
            return []

        resolved = self._resolve_names(agent)
        results = []
        for p in sorted(tier_dir.glob("*.md")):
            try:
                text = p.read_text(encoding="utf-8")
                meta, body = parse_entry(text)
                if can_access(meta.get("scope", "team"), agent, meta.get("agent"), projects, resolved):
                    results.append((meta, body))
            except (OSError, UnicodeDecodeError):
                continue
        return results

    def all_entries(
        self, include_cold: bool = False, agent: str | None = None, projects: list[str] | None = None
    ) -> list[tuple[dict, str, str]]:
        """Get all entries across tiers. Returns (meta, body, tier)."""
        tiers = ["hot", "warm"] + (["cold"] if include_cold else [])
        results = []
        for tier in tiers:
            for meta, body in self.list_entries(tier, agent, projects):
                results.append((meta, body, tier))
        return results

    def all_entries_unfiltered(self, include_cold: bool = False) -> list[tuple[dict, str, str]]:
        """Get ALL entries across tiers WITHOUT scope filtering.

        Used for indexing/warmup where every entry needs an embedding
        regardless of scope. Scope filtering happens at query time, not
        at index time.

        Returns list of (meta, body, tier).
        """
        tiers = ["hot", "warm"] + (["cold"] if include_cold else [])
        results = []
        for tier in tiers:
            tier_dir = self.root / tier
            if not tier_dir.exists():
                continue
            for p in sorted(tier_dir.glob("*.md")):
                try:
                    text = p.read_text(encoding="utf-8")
                    meta, body = parse_entry(text)
                    results.append((meta, body, tier))
                except (OSError, UnicodeDecodeError):
                    continue
        return results

    def gc(self) -> dict:
        """Garbage collect: rotate tiers based on decay scores."""
        moves = {"hot_to_warm": 0, "warm_to_cold": 0, "cold_to_warm": 0, "warm_to_hot": 0}
        config = self.config

        with self.lock:
            for tier in TIERS:
                tier_dir = self.root / tier
                if not tier_dir.exists():
                    continue
                for p in tier_dir.glob("*.md"):
                    try:
                        text = p.read_text(encoding="utf-8")
                        meta, body = parse_entry(text)
                    except (OSError, UnicodeDecodeError):
                        continue

                    accessed = meta.get("accessed", meta.get("created", ""))
                    if not accessed:
                        continue

                    d = days_since(accessed)
                    ac = meta.get("access_count", 1)
                    score = decay_score(d, ac, config["decay_lambda"])
                    meta["decay_score"] = score

                    new_tier = classify_tier(
                        d,
                        score,
                        config["hot_threshold_days"],
                        config["warm_threshold_days"],
                        config["hot_min_score"],
                        config["warm_min_score"],
                    )

                    # Update the score in file
                    new_text = serialize_entry(meta, body)

                    if new_tier != tier:
                        new_target = f"{new_tier}/{p.name}"
                        # WAL: log the move with payload for crash recovery
                        wal_entry = WALEntry(
                            operation="write",
                            target=new_target,
                            payload_hash=meta.get("content_hash", ""),
                            payload=new_text,
                        )
                        self.wal.log(wal_entry)
                        self.write_raw(new_target, new_text)
                        p.unlink()
                        self.wal.commit(wal_entry)
                        key = f"{tier}_to_{new_tier}"
                        moves[key] = moves.get(key, 0) + 1
                    else:
                        with open(p, "w") as f:
                            f.write(new_text)

        # WAL cleanup
        wal_cleaned = self.wal.cleanup(config["wal_retention_days"])
        moves["wal_cleaned"] = wal_cleaned

        # Embedding cache cleanup: remove entries for deleted IDs
        valid_ids = set()
        for tier in TIERS:
            tier_dir = self.root / tier
            if tier_dir.exists():
                for p in tier_dir.glob("*.md"):
                    valid_ids.add(p.stem)
        stale = self.embedding_cache.cleanup(valid_ids)
        if stale:
            moves["embeddings_cleaned"] = stale

        return moves

    def status(self) -> dict:
        """Get system status info."""
        counts = {}
        for tier in TIERS:
            tier_dir = self.root / tier
            if tier_dir.exists():
                counts[tier] = len(list(tier_dir.glob("*.md")))
            else:
                counts[tier] = 0

        wal_dir = self.root / "wal"
        pending = len(self.wal.get_pending()) if wal_dir.exists() else 0

        return {
            "palaia_root": str(self.root),
            "entries": counts,
            "total": sum(counts.values()),
            "wal_pending": pending,
            "config": self.config,
        }

    def _find_entry(self, entry_id: str) -> Path | None:
        """Find an entry file across tiers."""
        filename = f"{entry_id}.md"
        for tier in TIERS:
            path = self.root / tier / filename
            if path.exists():
                return path
        return None

    def _find_by_hash(self, h: str) -> str | None:
        """Find entry ID by content hash (dedup)."""
        for tier in TIERS:
            tier_dir = self.root / tier
            if not tier_dir.exists():
                continue
            for p in tier_dir.glob("*.md"):
                try:
                    text = p.read_text(encoding="utf-8")
                    meta, _ = parse_entry(text)
                    if meta.get("content_hash") == h:
                        return meta.get("id")
                except (OSError, UnicodeDecodeError):
                    continue
        return None
