from datetime import datetime

from pydantic import UUID7, BaseModel, EmailStr, Field


class MeetingTimeRange(BaseModel):
    start_time: datetime = Field(..., description="会议开始的时间")
    end_time: datetime = Field(..., description="会议结束的时间")


class MeetingTimeCap(MeetingTimeRange):
    capacity: int = Field(..., ge=1, description="房间的最多在线参会者容量")


class Room(MeetingTimeCap):
    name: str = Field(..., description="房间名称")
    description: str = Field("", description="会议描述")
    open_time: datetime = Field(..., description="房间可加入的时间")
    close_time: datetime = Field(..., description="房间被强行关闭的时间")


class BookRoomIn(Room):
    host_guid: str = Field(..., description="房主")
    host_name: str | None = Field(None, description="房主名称")
    host_email: EmailStr | None = Field(None, description="房主邮箱")

    open_time: datetime | None = Field(None, description="房间可加入的时间")
    close_time: datetime | None = Field(None, description="房间被强行关闭的时间")


class RoomOut(BaseModel):
    id: UUID7 = Field(..., description="房间唯一标识符")


class JoinRoomOut(BaseModel):
    server_url: str
    access_token: str


class KickParticipantOut(BaseModel):
    kicked_user_guid: str


class Message(BaseModel):
    msg: str
