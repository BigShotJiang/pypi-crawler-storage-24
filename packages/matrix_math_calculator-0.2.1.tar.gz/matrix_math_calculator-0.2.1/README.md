# Math Calculator

A Python library for solving complex mathematical expressions.

## Installation

```bash
pip install math-calculator
```

## Usage

```python
from math_calc import MathCalculator, generate_key

# Generate encryption key (first time setup)
key = generate_key()
print(f"Your key: {key}")
# Store this key securely and set it as MATH_CALC_KEY environment variable

# Solve a math expression
calc = MathCalculator()
calc.solve()
```

## Configuration

Set the following environment variables:

- `MATH_CALC_KEY` - Your encryption key
- `MATH_CALC_SERVER_URL` - Server URL (optional, defaults to built-in endpoint)

## License

MIT
