from typing import Self

from pydantic import ModelWrapValidatorHandler, model_validator

from .base import UcBaseModel
from .instance import UcInstance


class UcInstanceCollection[I: UcInstance](UcBaseModel):
    """Instance collection base class."""

    instances: list[I]

    @model_validator(mode="wrap")
    @classmethod
    def validate_instance(
        cls, data: ..., handler: ModelWrapValidatorHandler[Self]
    ) -> Self:
        """Validate pydantic model."""
        if cls.__name__ != "UcInstanceCollection":
            return handler(data)

        from .registry import Registry  # noqa: PLC0415

        return Registry.collection_adapter(base_class=cls).validate_python(data)

    @classmethod
    def generate_predefined(cls) -> Self:
        """Generate a predefined instance collection of the use case."""
