from abc import abstractmethod
from inspect import isabstract
from typing import Protocol, Self, runtime_checkable

from pydantic import ModelWrapValidatorHandler, model_validator

from .base import UcBaseModel
from .data import UcData
from .named import Named


class UcSolution(UcBaseModel, Named):
    """Use case solution base class."""

    @abstractmethod
    def to_string(self) -> str:
        """Print the solution."""

    @model_validator(mode="wrap")
    @classmethod
    def validate_solution(
        cls, data: ..., handler: ModelWrapValidatorHandler[Self]
    ) -> Self:
        """Validate the pydantic model."""
        if isabstract(cls):
            from .registry import Registry  # noqa: PLC0415

            return Registry.solution_adapter(base_class=cls).validate_python(data)
        return handler(data)


@runtime_checkable
class Visulaizable[T: UcData](Protocol):
    """Visualizable protocol."""

    def visualize(self, data: T | None = None) -> None:
        """Visualize the solution."""
        ...
