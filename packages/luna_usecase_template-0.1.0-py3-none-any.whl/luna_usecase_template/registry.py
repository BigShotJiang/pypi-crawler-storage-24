import functools
import importlib
import inspect
import pkgutil
from collections.abc import Callable, Iterable
from types import ModuleType
from typing import ClassVar, Union

from pydantic import TypeAdapter

from .collection import UcInstanceCollection
from .data import UcData
from .formulation import UcFormulation
from .instance import UcInstance
from .solution import UcSolution


def _check_concrete[T: type](f: Callable[[T], T]) -> Callable[[T], T]:
    @functools.wraps(f)
    def _inner(t: T) -> T:
        if inspect.isabstract(t):
            msg = (
                f"Abstract class '{t.__name__}' detected. "
                "Registry can only hold concrete models."
            )

            raise ValueError(msg)
        return f(t)

    return _inner


def _generic_adapter(
    types: Iterable[type], base_class: type | None = None
) -> TypeAdapter:
    if base_class is not None:
        types = [t for t in types if issubclass(t, base_class)]
    else:
        types = list(types)
    if len(types) == 0:
        msg = "No suitable types registered."
        raise ValueError(msg)
    return TypeAdapter(Union[*types])


class Registry:
    """Registry of all use case classes."""

    _instances: ClassVar[list[type[UcInstance]]] = []
    _datas: ClassVar[list[type[UcData]]] = []
    _formulations: ClassVar[list[type[UcFormulation]]] = []
    _solutions: ClassVar[list[type[UcSolution]]] = []
    _collections: ClassVar[list[type[UcInstanceCollection]]] = []
    _registered: ClassVar[set[type]] = set()

    @staticmethod
    def adapter() -> TypeAdapter:
        """Get the type adapter of all registered classes."""
        types = (
            Registry._instances
            + Registry._datas
            + Registry._formulations
            + Registry._solutions
            + Registry._collections
        )
        return TypeAdapter(Union[*types])

    @staticmethod
    def _check_registered[T: type](f: Callable[[T], T]) -> Callable[[T], T]:
        @functools.wraps(f)
        def _inner(t: T) -> T:
            if t not in Registry._registered:
                Registry._registered.add(t)
                return f(t)
            return t

        return _inner

    @staticmethod
    def instance_adapter(base_class: None | type[UcInstance] = None) -> TypeAdapter:
        """Get the type adapter of all registered instance classes."""
        return _generic_adapter(Registry._instances, base_class)

    @staticmethod
    def data_adapter(base_class: None | type[UcData] = None) -> TypeAdapter:
        """Get the type adapter of all registered data classes."""
        return _generic_adapter(Registry._datas, base_class)

    @staticmethod
    def formulation_adapter(
        base_class: None | type[UcFormulation] = None,
    ) -> TypeAdapter:
        """Get the type adapter of all registered formulation classes."""
        return _generic_adapter(Registry._formulations, base_class)

    @staticmethod
    def solution_adapter(base_class: None | type[UcSolution] = None) -> TypeAdapter:
        """Get the type adapter of all registered solution classes."""
        return _generic_adapter(Registry._solutions, base_class)

    @staticmethod
    def collection_adapter(
        base_class: None | type[UcInstanceCollection] = None,
    ) -> TypeAdapter:
        """Get the type adapter of all registered collection classes."""
        return _generic_adapter(Registry._collections, base_class)

    @staticmethod
    @_check_registered
    @_check_concrete
    def add_instance[T: type[UcInstance]](instance: T) -> T:
        """Register an instance class."""
        Registry._instances.append(instance)
        return instance

    @staticmethod
    @_check_registered
    @_check_concrete
    def add_data[T: type[UcData]](data: T) -> T:
        """Register a data class."""
        Registry._datas.append(data)
        return data

    @staticmethod
    @_check_registered
    @_check_concrete
    def add_formulation[T: type[UcFormulation]](formulation: T) -> T:
        """Register a formulation class."""
        Registry._formulations.append(formulation)
        return formulation

    @staticmethod
    @_check_registered
    @_check_concrete
    def add_solution[T: type[UcSolution]](solution: T) -> T:
        """Register a solution class."""
        Registry._solutions.append(solution)
        return solution

    @staticmethod
    @_check_registered
    @_check_concrete
    def add_collection[T: type[UcInstanceCollection]](collection: T) -> T:
        """Register a collection class."""
        Registry._collections.append(collection)
        return collection

    @staticmethod
    def add[T: type](input_class: T) -> T:
        """Register any class."""
        if issubclass(input_class, UcInstance):
            Registry.add_instance(input_class)
        elif issubclass(input_class, UcData):
            Registry.add_data(input_class)
        elif issubclass(input_class, UcFormulation):
            Registry.add_formulation(input_class)
        elif issubclass(input_class, UcSolution):
            Registry.add_solution(input_class)
        elif issubclass(input_class, UcInstanceCollection):
            Registry.add_collection(input_class)
        else:
            msg = f"Attempted to register unknown type {input_class}."
            raise TypeError(msg)
        return input_class

    @staticmethod
    def can_register(input_class: type) -> bool:
        """Check if a class can be registered."""
        if input_class in Registry._registered or inspect.isabstract(input_class):
            return False
        if input_class.__name__ in ("UcInstance", "UcInstanceCollection"):
            return False

        return bool(
            issubclass(input_class, UcInstance)
            or issubclass(input_class, UcData)
            or issubclass(input_class, UcFormulation)
            or issubclass(input_class, UcSolution)
            or issubclass(input_class, UcInstanceCollection)
        )

    @staticmethod
    def add_module(mod: ModuleType) -> None:
        """Add a whole module."""
        for info in pkgutil.walk_packages(mod.__path__, prefix=f"{mod.__name__}."):
            submod = importlib.import_module(info.name)  # nosemgrep: non-literal-import

            for _, obj in inspect.getmembers(submod, inspect.isclass):
                if Registry.can_register(obj):
                    Registry.add(obj)

    @staticmethod
    def validate(s: ...) -> ...:
        """Validate a python object."""
        return Registry.adapter().validate_python(s)

    @staticmethod
    def validate_json(s: str | bytes | bytearray) -> ...:
        """Validate a json string."""
        return Registry.adapter().validate_json(s)

    @staticmethod
    def to_string() -> str:
        """Return a string representation of the registry and contents."""
        lines = [
            "UcData: " + ", ".join(f"{t.__name__}" for t in Registry._datas),
            "UcSolution: " + ", ".join(f"{t.__name__}" for t in Registry._solutions),
            "UcInstance: " + ", ".join(f"{t.__name__}" for t in Registry._instances),
            "UcFormulation: "
            + ", ".join(f"{t.__name__}" for t in Registry._formulations),
            "UcInstanceCollection: "
            + ", ".join(f"{t.__name__}" for t in Registry._collections),
        ]
        return "\n".join(lines)

    @staticmethod
    def print() -> None:
        """Print the registry and contents."""
        print(Registry.to_string())  # noqa: T201
