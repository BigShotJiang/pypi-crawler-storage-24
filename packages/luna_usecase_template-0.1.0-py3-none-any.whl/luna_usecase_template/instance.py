from typing import Self

from luna_model import Model, Solution
from pydantic import ModelWrapValidatorHandler, model_validator

from .base import UcBaseModel
from .data import UcData
from .formulation import UcFormulation
from .solution import UcSolution


class UcInstance[D: UcData, F: UcFormulation, S: UcSolution](UcBaseModel):
    """Use case instance is the collection of the data and formulation."""

    data: D
    formulation: F

    def to_string(self) -> str:
        """Get a string representation of the instance."""
        data_descr = "Data:"
        data_descr += self.data.to_string()
        form_descr = "Formulation:"
        form_descr += self.formulation.to_string(self.data)
        return f"{data_descr}\n{form_descr}"

    @property
    def name(self) -> str:
        """Get name of the instance."""
        return self.formulation.name + "<" + self.data.data_name + ">"

    def formulate(self) -> Model:
        """Formulate the instance as AqModel."""
        model = self.formulation.formulate(self.data)
        model.name = self.name
        return model

    def interpret(self, solution: Solution) -> S:
        """Interpret the solution to the AqModel."""
        return self.formulation.interpret(solution=solution, data=self.data)

    @model_validator(mode="wrap")
    @classmethod
    def validate_instance(
        cls, data: ..., handler: ModelWrapValidatorHandler[Self]
    ) -> Self:
        """Validate the pydantic model."""
        if cls.__name__ != "UcInstance":
            return handler(data)

        from .registry import Registry  # noqa: PLC0415

        return Registry.instance_adapter(base_class=cls).validate_python(data)
