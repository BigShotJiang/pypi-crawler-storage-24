from typing import Literal, get_args, get_origin


class Named[N: str]:
    """Named pydantic class mixin."""

    name: N

    @classmethod
    def get_name(cls) -> str:
        """Return the name of the class."""
        name_type = cls.__dict__["__annotations__"]["name"]
        if not (get_origin(name_type) is Literal and len(get_args(name_type)) == 1):
            msg = (
                f"Invalid `name` field in '{cls.__name__}'. "
                "Required to be a Literal of a single string."
            )
            raise RuntimeError(msg)
        return get_args(name_type)[0]
