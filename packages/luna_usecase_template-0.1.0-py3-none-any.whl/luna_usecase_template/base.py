from pathlib import Path
from typing import Self

from pydantic import BaseModel, ConfigDict


class UcBaseModel(BaseModel):
    """Use case base model with config."""

    model_config = ConfigDict(extra="forbid", strict=True)

    def store(self, path: Path | str) -> None:
        """Store model to file.

        Supported file types are `json` and `pkl`
        """
        if isinstance(path, str):
            path = Path(path)

        match path.suffix:
            case ".json":
                with open(path, "w") as f:
                    f.write(self.model_dump_json())
            case _:
                msg = (
                    f"Unsupported suffix '{path.suffix}'. "
                    f"Only .json is supported as of now."
                )
                raise ValueError(msg)

    @classmethod
    def load(cls, path: Path | str) -> Self:
        """Load model from file.

        Supported file types are `json` and `pkl`
        """
        if isinstance(path, str):
            path = Path(path)

        match path.suffix:
            case ".json":
                with open(path) as f:
                    return cls.model_validate_json(f.read())

            case _:
                msg = (
                    f"Unsupported suffix '{path.suffix}'. "
                    f"Only .json is supported as of now."
                )
                raise ValueError(msg)
