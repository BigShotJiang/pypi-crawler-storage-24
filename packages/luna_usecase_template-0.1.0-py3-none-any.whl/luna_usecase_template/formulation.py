from abc import abstractmethod
from inspect import isabstract
from typing import Self

from luna_model import Model, Solution
from pydantic import ModelWrapValidatorHandler, model_validator

from .base import UcBaseModel
from .data import UcData
from .named import Named
from .solution import UcSolution


class UcFormulation[D: UcData, S: UcSolution](UcBaseModel, Named):
    """Use case formulation base class."""

    @staticmethod
    @abstractmethod
    def to_string(data: D) -> str:
        """Print the formulation."""
        ...

    @staticmethod
    @abstractmethod
    def formulate(data: D) -> Model:
        """Formulate the use case as a concrete AqModel."""
        ...

    @staticmethod
    @abstractmethod
    def interpret(solution: Solution, data: D) -> S:
        """Interpret the solution to the AqModel."""
        ...

    @model_validator(mode="wrap")
    @classmethod
    def validate_instance(
        cls, data: ..., handler: ModelWrapValidatorHandler[Self]
    ) -> Self:
        """Validate the pydantic model."""
        if isabstract(cls):
            from .registry import Registry  # noqa: PLC0415

            return Registry.formulation_adapter(base_class=cls).validate_python(data)
        return handler(data)
