from abc import abstractmethod
from inspect import isabstract
from typing import Self

from pydantic import ModelWrapValidatorHandler, model_validator

from .base import UcBaseModel
from .named import Named


class UcData(UcBaseModel, Named):
    """Use Case data base class."""

    data_name: str

    @abstractmethod
    def to_string(self) -> str:
        """Return the model data definition."""
        ...

    @model_validator(mode="wrap")
    @classmethod
    def validate_instance(
        cls, data: ..., handler: ModelWrapValidatorHandler[Self]
    ) -> Self:
        """Validate pydantic model."""
        if isabstract(cls):
            from .registry import Registry  # noqa: PLC0415

            return Registry.data_adapter(base_class=cls).validate_python(data)
        return handler(data)
