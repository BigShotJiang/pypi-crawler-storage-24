"""Local web dashboard for birdword."""

import os
import threading
import webbrowser

from flask import Flask, render_template, request, jsonify

import birdword.config as bw_config
from birdword.config import DEFAULTS
from birdword.history import recent

PORT = 7870
HOST = "127.0.0.1"

HOLD_KEY_OPTIONS = ["rcmd", "lcmd", "ralt", "lalt", "rshift", "lshift", "rctrl", "lctrl"]
TOGGLE_KEY_OPTIONS = ["space", "return", "tab", "escape"]

KEY_LABELS = {
    "rcmd": "Right ⌘", "lcmd": "Left ⌘",
    "ralt": "Right ⌥", "lalt": "Left ⌥",
    "rshift": "Right ⇧", "lshift": "Left ⇧",
    "rctrl": "Right ⌃", "lctrl": "Left ⌃",
    "space": "Space", "return": "Return", "tab": "Tab", "escape": "Escape",
}

TEMPLATE_DIR = os.path.join(os.path.dirname(__file__), "templates")


def _save_config(form_data):
    """Save form data to config.toml."""
    bw_config.ensure_config_dir()
    lines = []
    for key in ["hold_key", "toggle_key", "transcription_model", "fix_model"]:
        val = form_data.get(key, DEFAULTS[key])
        if val != DEFAULTS[key]:
            lines.append(f'{key} = "{val}"')
    if form_data.get("no_fix"):
        lines.append("no_fix = true")
    with open(bw_config.CONFIG_PATH, "w") as f:
        f.write("\n".join(lines) + "\n" if lines else "")


def _get_effective_config() -> dict:
    """Get config with defaults filled in."""
    file_config = bw_config.load_config()
    result = dict(DEFAULTS)
    result.update(file_config)
    return result


_daemon = None


def create_app(daemon=None) -> Flask:
    app = Flask(__name__, template_folder=TEMPLATE_DIR)
    app.config["SEND_FILE_MAX_AGE_DEFAULT"] = 0

    @app.route("/")
    def index():
        return render_template(
            "index.html",
            transcriptions=recent(limit=50),
            config=type("C", (), _get_effective_config())(),
            hold_keys=HOLD_KEY_OPTIONS,
            toggle_keys=TOGGLE_KEY_OPTIONS,
            key_labels=KEY_LABELS,
        )

    @app.route("/api/config", methods=["POST"])
    def save_config():
        _save_config(request.form)
        cfg = _get_effective_config()
        if _daemon is not None:
            _daemon.apply_config(cfg)
        return jsonify({"ok": True})

    return app


def start_server(daemon=None):
    """Start the web server in a background thread."""
    global _daemon
    _daemon = daemon
    app = create_app(daemon)
    thread = threading.Thread(
        target=app.run,
        kwargs={"host": HOST, "port": PORT, "debug": False, "use_reloader": False},
        daemon=True,
    )
    thread.start()
    return f"http://{HOST}:{PORT}"


def open_dashboard():
    """Open the dashboard in the default browser."""
    webbrowser.open(f"http://{HOST}:{PORT}")
