# Amazon Seller Partner changelog

## [0.1.4] - 2026-03-12
- Updated connector definition (YAML version 1.0.3)
- Source commit: b541ca65
- SDK version: 0.1.0

## [0.1.3] - 2026-03-11
- Updated connector definition (YAML version 1.0.3)
- Source commit: 44677ecb
- SDK version: 0.1.0

## [0.1.2] - 2026-03-10
- Updated connector definition (YAML version 1.0.3)
- Source commit: 083869cd
- SDK version: 0.1.0

## [0.1.1] - 2026-03-07
- Updated connector definition (YAML version 1.0.2)
- Source commit: 7f2011ce
- SDK version: 0.1.0

## [0.1.0] - 2026-03-05
- Updated connector definition (YAML version 1.0.1)
- Source commit: f84710e4
- SDK version: 0.1.0
