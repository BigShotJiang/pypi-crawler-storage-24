from pathlib import Path
import sys

PROGRAMS = [
    ("1", "1.txt"),
    ("2", "2.txt"),
    ("3", "3.txt"),
    ("4", "4.txt"),
    ("5a", "5a.txt"),
    ("5b", "5b.txt"),
    ("6a", "6a.txt"),
    ("6b", "6b.txt"),
    ("6c", "6c.txt"),
    ("7", "7.txt"),
    ("8", "8.txt"),
]

def main():
    print("\n====== TENSORFIOW EXAMPLES : RAW AI / ML CODES ======\n")

    base_dir = Path(__file__).parent / "raw"

    # if user requested a specific program
    if len(sys.argv) > 1:
        target = sys.argv[1].lower()
        PROGRAMS_TO_PRINT = [p for p in PROGRAMS if p[0] == target]
    else:
        PROGRAMS_TO_PRINT = PROGRAMS

    for title, filename in PROGRAMS_TO_PRINT:
        print(f"\n----- PROGRAM {title} -----\n")

        file_path = base_dir / filename

        if not file_path.exists():
            print(f"[ERROR] File not found: {filename}")
            continue

        print(file_path.read_text(encoding="utf-8"))

if __name__ == "__main__":
    main()