from .cli import main

def show(program=None):
    import sys

    if program is None:
        sys.argv = ["tensorfiow_examples"]
    else:
        sys.argv = ["tensorfiow_examples", str(program)]

    main()