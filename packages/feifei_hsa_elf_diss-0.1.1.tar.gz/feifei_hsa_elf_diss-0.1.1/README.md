# feifei-hsa-elf-diss

将 AMDGPU Code Object 二进制文件（`.co`）反汇编为可被 clang/LLVM 重新汇编的 LLVM 汇编 `.s` 文件，便于修改指令后再编译回 `.co`。

## 功能

- **输入**：ELF64 amdhsa 格式的 `.co` 文件
- **输出**：含 `.text`、`.rodata`/`.amdhsa_kernel`、`.amdgpu_metadata` 的 `.s` 文件
- **反汇编**：使用 ROCm 提供的 `llvm-objdump -d` 获取指令助记符（含注释与符号行）

## 安装

```bash
pip install feifei-hsa-elf-diss
```

**依赖**：Python 3.8+、`pyelftools`、`msgpack`。安装时会自动安装。另需系统中有 **llvm-objdump**（如 ROCm 的 `/opt/rocm/llvm/bin/llvm-objdump`），可通过环境变量 `LLVM_OBJDUMP` 指定路径。

## 用法

```bash
feifei-hsa-elf-diss -i kernel.co -o kernel.s
```

指定 llvm-objdump 路径：

```bash
LLVM_OBJDUMP=/path/to/llvm-objdump feifei-hsa-elf-diss -i kernel.co -o kernel.s
```

或：

```bash
feifei-hsa-elf-diss -i kernel.co -o kernel.s --objdump /path/to/llvm-objdump
```

## 再汇编为 .co

编辑生成的 `kernel.s` 后，用 clang 重新汇编：

```bash
# 根据实际 gfx 替换 <gfx>，如 gfx942
/opt/rocm/llvm/bin/clang++ -x assembler -target amdgcn--amdhsa --offload-arch=<gfx> kernel.s -o kernel.co
```

## 开发 / 从源码运行

```bash
git clone https://gitee.com/feifei14119/feifei-hsa-elf-diss.git
cd feifei-hsa-elf-diss
pip install -e .
feifei-hsa-elf-diss -i your.co -o your.s
```

或在不安装的情况下：

```bash
cd codiss && pip install -r requirements.txt
PYTHONPATH=. python tools/codiss.py -i kernel.co -o kernel.s
```

## License

MIT
