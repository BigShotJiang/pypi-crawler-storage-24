"""
解码 NT_AMDGPU_METADATA（MessagePack），提供 amdhsa 元数据访问与 .amdgpu_metadata YAML 生成。
参考：amdhsa-codebase/docs/code_object_metadata.md
"""
from __future__ import annotations

import msgpack
from typing import Any


def _normalize_key(k: Any) -> str:
    if isinstance(k, bytes):
        return k.decode("utf-8", errors="replace")
    return str(k)


def _normalize_dict(d: dict) -> dict:
    """递归将 dict 的 key 转为 str（bytes -> utf-8）。"""
    out = {}
    for k, v in d.items():
        key = _normalize_key(k)
        if isinstance(v, dict):
            out[key] = _normalize_dict(v)
        elif isinstance(v, list):
            out[key] = [_normalize_dict(x) if isinstance(x, dict) else x for x in v]
        else:
            out[key] = v
    return out


def decode_metadata(payload: bytes) -> dict:
    """
    将 NT_AMDGPU_METADATA 的 MessagePack 负载解码为 Python dict。
    键统一为 str（如 amdhsa.version, amdhsa.kernels, .name, .symbol 等）。
    """
    if not payload:
        return {}
    try:
        raw = msgpack.unpackb(payload, raw=False, strict_map_key=False)
    except Exception:
        raw = msgpack.unpackb(payload, raw=True, strict_map_key=False)
    if not isinstance(raw, dict):
        return {}
    return _normalize_dict(raw)


def get_amdhsa_target(meta: dict) -> str:
    """V4+ 使用 amdhsa.target；否则返回空，由调用方用 e_flags 推导。"""
    return (meta.get("amdhsa.target") or "").strip()


def get_amdhsa_version(meta: dict) -> list:
    """返回 [major, minor]。"""
    v = meta.get("amdhsa.version")
    if isinstance(v, list) and len(v) >= 2:
        return [int(v[0]), int(v[1])]
    return [1, 0]


def get_kernels(meta: dict) -> list[dict]:
    """返回 amdhsa.kernels 列表（每项为 kernel 元数据 dict）。"""
    k = meta.get("amdhsa.kernels")
    if isinstance(k, list):
        return [x if isinstance(x, dict) else {} for x in k]
    return []


def metadata_to_yaml_like(meta: dict, indent: int = 0) -> list[str]:
    """
    将解码后的 amdhsa 元数据转为 YAML 行列表（用于 .amdgpu_metadata 块）。
    """
    lines = []

    def emit(key: str, val: Any, ind: int) -> None:
        p = "  " * ind
        if isinstance(val, dict):
            lines.append(f"{p}{key}:")
            for k, v in sorted(val.items(), key=lambda x: (str(x[0]),)):
                emit(k, v, ind + 1)
        elif isinstance(val, list):
            if val and isinstance(val[0], dict):
                lines.append(f"{p}{key}:")
                for item in val:
                    lines.append(f"{p}  -")
                    for k, v in sorted(item.items(), key=lambda x: (str(x[0]),)):
                        emit(k, v, ind + 2)
            else:
                lines.append(f"{p}{key}: {val}")
        elif isinstance(val, bool):
            lines.append(f"{p}{key}: {str(val).lower()}")
        else:
            lines.append(f"{p}{key}: {val}")

    for top_key in ("amdhsa.version", "amdhsa.target", "amdhsa.printf", "amdhsa.kernels"):
        if top_key not in meta:
            continue
        val = meta[top_key]
        emit(top_key, val, indent)
    return lines
