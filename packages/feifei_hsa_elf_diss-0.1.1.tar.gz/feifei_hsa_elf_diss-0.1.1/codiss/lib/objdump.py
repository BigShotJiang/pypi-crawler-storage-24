"""
调用 llvm-objdump -d 解析反汇编输出，按符号地址插入 label，提取指令行。
"""
from __future__ import annotations

import re
import subprocess
import os
from dataclasses import dataclass, field
from typing import Callable, Optional

# 默认 objdump 路径，可通过环境变量 LLVM_OBJDUMP 覆盖
DEFAULT_LLVM_OBJDUMP = os.environ.get("LLVM_OBJDUMP", "/opt/rocm/llvm/bin/llvm-objdump")
# 回退到 PATH 中的 llvm-objdump
if not os.path.isfile(DEFAULT_LLVM_OBJDUMP):
    DEFAULT_LLVM_OBJDUMP = "llvm-objdump"


@dataclass
class DisasmLine:
    """单行反汇编：地址、符号名（若为该地址的 label）、指令文本。"""
    addr: int
    symbol: Optional[str] = None  # 若此行是某符号的起始地址
    raw: str = ""  # 原始行
    instruction: Optional[str] = None  # 指令行：助记符+操作数，含 // 后注释（若有）
    is_data: bool = False  # .byte 或 地址: 十六进制 形式
    is_symbol_line: bool = False  # 符号行：仅保留尖括号内符号名+冒号


def run_objdump(co_path: str, objdump_bin: Optional[str] = None, section: Optional[str] = ".text") -> str:
    """运行 llvm-objdump -d [ -j .text ] <co_path>，返回 stdout。"""
    cmd = [objdump_bin or DEFAULT_LLVM_OBJDUMP, "-d"]
    if section:
        cmd.extend(["-j", section])
    cmd.append(co_path)
    try:
        return subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=60,
        ).stdout or ""
    except FileNotFoundError:
        return ""
    except subprocess.TimeoutExpired:
        return ""


# 符号行: "0000000000000100 <sample_kernel>:"
_RE_SYMBOL = re.compile(r"^\s*([0-9a-fA-F]+)\s*<\s*([^>]+)\s*>:\s*$")
# 指令行（带 // 注释）: "\ts_endpgm                                                   // 000000000100: BF810000"
# 或仅 "\tinstruction"
_RE_INSTRUCTION = re.compile(r"^\s*\t(.+?)\s*(?://.*)?$")
# 数据行: "     40: 00 00 00 00 ..." 或 ".byte 0x0"
_RE_DATA_ADDR = re.compile(r"^\s*([0-9a-fA-F]+):\s+([0-9a-fA-F\s]+)\s*$")
_RE_BYTE = re.compile(r"^\s*\.byte\s+\S+")


def parse_objdump_output(
    text: str,
    symbol_at_addr: Optional[Callable[[int], Optional[str]]] = None,
) -> list[DisasmLine]:
    """
    解析 llvm-objdump -d 的文本输出。
    symbol_at_addr: addr (int) -> 该地址的符号名或 None；用于在对应地址插入 label。
    返回按地址顺序的 DisasmLine 列表。
    """
    lines_out: list[DisasmLine] = []
    current_addr: Optional[int] = None
    current_symbol: Optional[str] = None

    for raw_line in text.splitlines():
        line = raw_line.rstrip()
        if not line:
            continue

        # 符号行: "0000000000000100 <sample_kernel>:"
        m = _RE_SYMBOL.match(line)
        if m:
            addr = int(m.group(1), 16)
            sym_name = m.group(2).strip()
            current_addr = addr
            current_symbol = sym_name
            lines_out.append(
                DisasmLine(
                    addr=addr,
                    symbol=sym_name,
                    raw=line,
                    instruction=None,
                    is_data=False,
                    is_symbol_line=True,
                )
            )
            continue

        # .byte 行
        if _RE_BYTE.match(line):
            instr = line.strip()
            addr = current_addr if current_addr is not None else 0
            sym = current_symbol if (symbol_at_addr and symbol_at_addr(addr) == current_symbol) else None
            lines_out.append(
                DisasmLine(addr=addr, symbol=sym, raw=line, instruction=instr, is_data=True)
            )
            if current_addr is not None:
                current_addr += 1  # 单 byte
            current_symbol = None
            continue

        # 数据行 "     40: 00 00 00 00 ..."
        m = _RE_DATA_ADDR.match(line)
        if m:
            addr = int(m.group(1), 16)
            sym = current_symbol if (current_addr == addr and symbol_at_addr and symbol_at_addr(addr) == current_symbol) else None
            lines_out.append(DisasmLine(addr=addr, symbol=sym, raw=line, instruction=line.strip(), is_data=True))
            current_addr = addr + 8  # 常见 8 字节一行
            current_symbol = None
            continue

        # 指令行：制表符开头的助记符（保留 // 后的注释）
        if line.startswith("\t") and not line.strip().startswith(".byte"):
            rest = line[1:].strip()  # \t 后整行，含助记符、操作数及 // 注释
            # 指令部分（用于判断是否 4 字节）：不含注释
            inst_only = rest.split("//")[0].strip() if "//" in rest else rest
            addr = current_addr if current_addr is not None else 0
            sym = None
            if current_symbol and symbol_at_addr and symbol_at_addr(addr) == current_symbol:
                sym = current_symbol
            lines_out.append(
                DisasmLine(addr=addr, symbol=sym, raw=line, instruction=rest or None, is_data=False)
            )
            # AMDGPU 指令通常 4 字节
            if current_addr is not None and inst_only:
                current_addr += 4  # 按指令部分判断，不含注释
            current_symbol = None
            continue

        # 其他（如 "Disassembly of section", "; error in decoding" 等）可忽略或保留为注释
        if line.startswith(";"):
            continue
        if "Disassembly of section" in line:
            continue
    return lines_out


def get_objdump_bin() -> str:
    """返回当前使用的 llvm-objdump 路径。"""
    return os.environ.get("LLVM_OBJDUMP", DEFAULT_LLVM_OBJDUMP)
