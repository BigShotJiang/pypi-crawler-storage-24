"""
生成符合 amdhsa-codebase/docs/assembly_kernel_format.md 的 .s 文件。
整合 .amdgcn_target、.text（含 label 与指令）、.rodata/.amdhsa_kernel、.amdgpu_metadata。
"""
from __future__ import annotations

from typing import Optional

from .elf_reader import CoElf, SymInfo
from .metadata import (
    decode_metadata,
    get_amdhsa_target,
    get_kernels,
    metadata_to_yaml_like,
)
from .objdump import run_objdump, parse_objdump_output, DisasmLine


# EF_AMDGPU_MACH 枚举值 -> amdgcn target 后缀（与 LLVM ELF.h 一致，非“gfx+数字”的用名称）
# https://github.com/llvm/llvm-project/blob/main/llvm/include/llvm/BinaryFormat/ELF.h
_EF_AMDGPU_MACH_TO_GFX: dict[int, str] = {
    0x020: "gfx600", 0x021: "gfx601", 0x022: "gfx700", 0x023: "gfx701",
    0x024: "gfx702", 0x025: "gfx703", 0x026: "gfx704",
    0x028: "gfx801", 0x029: "gfx802", 0x02a: "gfx803", 0x02b: "gfx810",
    0x02c: "gfx900", 0x02d: "gfx902", 0x02e: "gfx904", 0x02f: "gfx906",
    0x030: "gfx908", 0x031: "gfx909", 0x032: "gfx90c",
    0x033: "gfx1010", 0x034: "gfx1011", 0x035: "gfx1012",
    0x036: "gfx1030", 0x037: "gfx1031", 0x038: "gfx1032", 0x039: "gfx1033",
    0x03a: "gfx602", 0x03b: "gfx705", 0x03c: "gfx805",
    0x03d: "gfx1035", 0x03e: "gfx1034", 0x03f: "gfx90a",
    0x041: "gfx1100", 0x042: "gfx1013", 0x043: "gfx1150", 0x044: "gfx1103",
    0x045: "gfx1036", 0x046: "gfx1101", 0x047: "gfx1102",
    0x048: "gfx1200", 0x049: "gfx1250", 0x04a: "gfx1151",
    0x04c: "gfx942", 0x04e: "gfx1201", 0x04f: "gfx950",
    0x050: "gfx1310", 0x051: "gfx9_generic", 0x052: "gfx10_1_generic",
    0x053: "gfx10_3_generic", 0x054: "gfx11_generic", 0x055: "gfx1152",
    0x058: "gfx1153", 0x059: "gfx12_generic", 0x05a: "gfx1251",
    0x05b: "gfx12_5_generic", 0x05d: "gfx1170", 0x05f: "gfx9_4_generic",
}


def _e_flags_to_target(e_flags: int) -> str:
    """从 e_flags 推导 amdgcn target 字符串（无 metadata 时回退）。"""
    mach = e_flags & 0xFF
    gfx = _EF_AMDGPU_MACH_TO_GFX.get(mach)
    if gfx is not None:
        return f"amdgcn-amd-amdhsa--{gfx}"
    return f"amdgcn-amd-amdhsa--gfx{mach}"


def _symbol_at_addr_from_elf(co: CoElf) -> dict[int, str]:
    """从 CoElf 构建 addr -> 符号名（仅 STT_FUNC）的映射。"""
    return {s.value: s.name for s in co.get_functions()}


def _first_code_addr(co: CoElf) -> int:
    """.text 中第一条指令的地址（第一个 STT_FUNC 的 value）。"""
    funcs = co.get_functions()
    if not funcs:
        return 0
    return min(s.value for s in funcs)


def emit_text_section(
    disasm_lines: list[DisasmLine],
    first_code_addr: int,
    addr_to_symbol: dict[int, str],
    func_sizes: Optional[dict[str, int]] = None,
    meta: Optional[dict] = None,
) -> list[str]:
    """
    生成 .text 段：在符号地址处插入 label，只输出 >= first_code_addr 的指令行（跳过 descriptor/.byte）。
    符号行只输出尖括号内的符号名加冒号（如 sample_kernel:）。
    """
    meta_kernels = get_kernels(meta)
    for m in meta_kernels:
        func_name = m.get(".name") or m.get("name") or ""

    lines = [".text"]
    lines.append(f".globl {func_name}")
    lines.append(".p2align 8")
    lines.append(f".type {func_name},@function")

    func_sizes = func_sizes or {}
    prev_sym: Optional[str] = None
    for d in disasm_lines:
        if d.addr < first_code_addr:
            continue
        if d.is_data:
            continue
        if d.is_symbol_line:
            lines.append(f"{d.symbol}:")
            prev_sym = d.symbol
            continue
        if d.instruction:
            lines.append(f"  {d.instruction}")
    if prev_sym and prev_sym in func_sizes:
        lines.append(f".Lfunc_end_{prev_sym}:")
        lines.append(f"  .size {prev_sym}, .Lfunc_end_{prev_sym}-{prev_sym}")
    return lines


# AMDHSA kernel 指令与 metadata 键、默认值、Supported On（参考 LLVM AMDGPUUsage.html AMDHSA Kernel Directives Table）
# 每项: (指令后缀, [metadata 键列表], 默认值, "Supported On" 原文)；默认 None 表示必选
_AMDHSA_KERNEL_DIRECTIVES: list[tuple[str, list[str], Optional[int], str]] = [
    (".amdhsa_group_segment_fixed_size", [".group_segment_fixed_size", "group_segment_fixed_size"], 0, "GFX6-GFX12"),
    (".amdhsa_private_segment_fixed_size", [".private_segment_fixed_size", "private_segment_fixed_size"], 0, "GFX6-GFX12"),
    (".amdhsa_kernarg_size", [".kernarg_segment_size", "kernarg_segment_size", "KernargSegmentSize"], 0, "GFX6-GFX12"),
    (".amdhsa_user_sgpr_count", [".user_sgpr_count", "user_sgpr_count"], 0, "GFX6-GFX12"),
    (".amdhsa_user_sgpr_private_segment_buffer", [".user_sgpr_private_segment_buffer", "user_sgpr_private_segment_buffer"], 0, "GFX6-GFX10 (except GFX942)"),
    (".amdhsa_user_sgpr_dispatch_ptr", [".user_sgpr_dispatch_ptr", "user_sgpr_dispatch_ptr"], 0, "GFX6-GFX12"),
    (".amdhsa_user_sgpr_queue_ptr", [".user_sgpr_queue_ptr", "user_sgpr_queue_ptr"], 0, "GFX6-GFX12"),
    (".amdhsa_user_sgpr_kernarg_segment_ptr", [".amdhsa_user_sgpr_kernarg_segment_ptr", ".user_sgpr_kernarg_segment_ptr", "user_sgpr_kernarg_segment_ptr"], 0, "GFX6-GFX12"),
    (".amdhsa_user_sgpr_dispatch_id", [".user_sgpr_dispatch_id", "user_sgpr_dispatch_id"], 0, "GFX6-GFX12"),
    (".amdhsa_user_sgpr_flat_scratch_init", [".user_sgpr_flat_scratch_init", "user_sgpr_flat_scratch_init"], 0, "GFX6-GFX10 (except GFX942)"),
    (".amdhsa_user_sgpr_private_segment_size", [".user_sgpr_private_segment_size", "user_sgpr_private_segment_size"], 0, "GFX6-GFX12"),
    (".amdhsa_wavefront_size32", [".wavefront_size32", "wavefront_size32"], 0, "GFX10-GFX12"),
    (".amdhsa_uses_dynamic_stack", [".uses_dynamic_stack", "uses_dynamic_stack", "IsDynamicCallStack"], 0, "GFX6-GFX12"),
    (".amdhsa_named_barrier_count", [".named_barrier_count", "named_barrier_count"], 0, "GFX1250+"),
    (".amdhsa_system_sgpr_private_segment_wavefront_offset", [".system_sgpr_private_segment_wavefront_offset", "system_sgpr_private_segment_wavefront_offset"], 0, "GFX6-GFX10 (except GFX942)"),
    (".amdhsa_enable_private_segment", [".enable_private_segment", "enable_private_segment"], 0, "GFX942, GFX11-GFX12"),
    (".amdhsa_system_sgpr_workgroup_id_x", [".system_sgpr_workgroup_id_x", "system_sgpr_workgroup_id_x"], 1, "GFX6-GFX12"),
    (".amdhsa_system_sgpr_workgroup_id_y", [".system_sgpr_workgroup_id_y", "system_sgpr_workgroup_id_y"], 0, "GFX6-GFX12"),
    (".amdhsa_system_sgpr_workgroup_id_z", [".system_sgpr_workgroup_id_z", "system_sgpr_workgroup_id_z"], 0, "GFX6-GFX12"),
    (".amdhsa_system_sgpr_workgroup_info", [".system_sgpr_workgroup_info", "system_sgpr_workgroup_info"], 0, "GFX6-GFX12"),
    (".amdhsa_system_vgpr_workitem_id", [".system_vgpr_workitem_id", "system_vgpr_workitem_id"], 0, "GFX6-GFX12"),
    (".amdhsa_next_free_vgpr", [".vgpr_count", "vgpr_count", "NumVGPRs"], None, "GFX6-GFX12"),
    (".amdhsa_next_free_sgpr", [".sgpr_count", "sgpr_count", "NumSGPRs"], None, "GFX6-GFX12"),
    (".amdhsa_accum_offset", [".accum_offset", "accum_offset"], 0, "GFX90A, GFX942"),
    (".amdhsa_reserve_vcc", [".reserve_vcc", "reserve_vcc"], 1, "GFX6-GFX12"),
    (".amdhsa_reserve_flat_scratch", [".reserve_flat_scratch", "reserve_flat_scratch"], 1, "GFX7-GFX10 (except GFX942)"),
    ("//.amdhsa_reserve_xnack_mask", [".reserve_xnack_mask", "reserve_xnack_mask", "IsXNACKEnabled"], 0, "GFX8-GFX10"),
    (".amdhsa_float_round_mode_32", [".float_round_mode_32", "float_round_mode_32"], 0, "GFX6-GFX12"),
    (".amdhsa_float_round_mode_16_64", [".float_round_mode_16_64", "float_round_mode_16_64"], 0, "GFX6-GFX12"),
    (".amdhsa_float_denorm_mode_32", [".float_denorm_mode_32", "float_denorm_mode_32"], 0, "GFX6-GFX12"),
    (".amdhsa_float_denorm_mode_16_64", [".float_denorm_mode_16_64", "float_denorm_mode_16_64"], 3, "GFX6-GFX12"),
    (".amdhsa_dx10_clamp", [".dx10_clamp", "dx10_clamp"], 1, "GFX6-GFX11 (except GFX1170)"),
    (".amdhsa_ieee_mode", [".ieee_mode", "ieee_mode"], 1, "GFX6-GFX11 (except GFX1170)"),
    (".amdhsa_round_robin_scheduling", [".round_robin_scheduling", "round_robin_scheduling"], 0, "GFX12"),
    (".amdhsa_fp16_overflow", [".fp16_overflow", "fp16_overflow"], 0, "GFX9-GFX12"),
    (".amdhsa_tg_split", [".tg_split", "tg_split"], 0, "GFX90A, GFX942, GFX11-GFX12"),
    (".amdhsa_workgroup_processor_mode", [".workgroup_processor_mode", "workgroup_processor_mode"], 0, "GFX10-GFX12"),
    (".amdhsa_memory_ordered", [".memory_ordered", "memory_ordered"], 1, "GFX10-GFX12"),
    (".amdhsa_forward_progress", [".forward_progress", "forward_progress"], 1, "GFX10-GFX12"),
    (".amdhsa_shared_vgpr_count", [".shared_vgpr_count", "shared_vgpr_count"], 0, "GFX10-GFX11"),
    (".amdhsa_inst_pref_size", [".inst_pref_size", "inst_pref_size"], 0, "GFX11-GFX12"),
    (".amdhsa_exception_fp_ieee_invalid_op", [".exception_fp_ieee_invalid_op", "exception_fp_ieee_invalid_op"], 0, "GFX6-GFX12"),
    (".amdhsa_exception_fp_denorm_src", [".exception_fp_denorm_src", "exception_fp_denorm_src"], 0, "GFX6-GFX12"),
    (".amdhsa_exception_fp_ieee_div_zero", [".exception_fp_ieee_div_zero", "exception_fp_ieee_div_zero"], 0, "GFX6-GFX12"),
    (".amdhsa_exception_fp_ieee_overflow", [".exception_fp_ieee_overflow", "exception_fp_ieee_overflow"], 0, "GFX6-GFX12"),
    (".amdhsa_exception_fp_ieee_underflow", [".exception_fp_ieee_underflow", "exception_fp_ieee_underflow"], 0, "GFX6-GFX12"),
    (".amdhsa_exception_fp_ieee_inexact", [".exception_fp_ieee_inexact", "exception_fp_ieee_inexact"], 0, "GFX6-GFX12"),
    (".amdhsa_exception_int_div_zero", [".exception_int_div_zero", "exception_int_div_zero"], 0, "GFX6-GFX12"),
    (".amdhsa_user_sgpr_kernarg_preload_length", [".user_sgpr_kernarg_preload_length", "user_sgpr_kernarg_preload_length"], 0, "GFX90A, GFX942"),
    (".amdhsa_user_sgpr_kernarg_preload_offset", [".user_sgpr_kernarg_preload_offset", "user_sgpr_kernarg_preload_offset"], 0, "GFX90A, GFX942"),
]


def _target_to_gfx(target: str) -> str:
    """从 .amdgcn_target 字符串提取 gfx 名，如 amdgcn-amd-amdhsa--gfx942 -> gfx942。"""
    if "--" in target:
        return target.split("--")[-1].strip().lower()
    return target.strip().lower()


def _gfx_major_minor(gfx: str) -> tuple[int, int]:
    """
    从 gfx 名解析 (major, minor)，用于 Supported On 范围判断。
    如 gfx600->(6,0), gfx942->(9,42), gfx1010->(10,10), gfx1250->(12,50), gfx90a->(9,0)。
    """
    gfx = gfx.lower().strip()
    if not gfx.startswith("gfx"):
        return (0, 0)
    rest = gfx[3:].replace("-", "").replace("_", "")
    if not rest:
        return (0, 0)
    digits = "".join(c for c in rest if c.isdigit())
    if not digits:
        if "90a" in rest or "90c" in rest:
            return (9, 0)
        return (0, 0)
    if len(digits) == 3:
        return (int(digits[0]), int(digits[1:3]))
    if len(digits) >= 4:
        return (int(digits[:2]), int(digits[2:4]))
    return (int(digits), 0)


def _gfx_supports_directive(gfx: str, supported_on: str) -> bool:
    """
    根据 LLVM 文档 "Supported On" 列判断当前 gfx 是否支持该指令。
    supported_on 可能含 "Target Feature Specific (...)" 前缀，已按文档表原文录入。
    """
    gfx = gfx.lower().strip()
    # 去掉 "Target Feature Specific (...)" 前缀
    s = supported_on.strip()
    if "GFX" in s.upper():
        idx = s.upper().index("GFX")
        s = s[idx:]
    major, minor = _gfx_major_minor(gfx)

    if "GFX1250+" in s:
        return (major == 12 and minor >= 50) or major > 12
    if "GFX90A, GFX942" in s and "GFX11" not in s:
        return gfx in ("gfx90a", "gfx942")
    if "GFX90A, GFX942, GFX11-GFX12" in s:
        return gfx in ("gfx90a", "gfx942") or (11 <= major <= 12)
    if "GFX942, GFX11-GFX12" in s:
        return gfx == "gfx942" or (11 <= major <= 12)
    if "GFX6-GFX10 (except GFX942)" in s:
        return 6 <= major <= 10 and gfx != "gfx942"
    if "GFX7-GFX10 (except GFX942)" in s:
        return 7 <= major <= 10 and gfx != "gfx942"
    if "GFX6-GFX11 (except GFX1170)" in s:
        return 6 <= major <= 11 and gfx != "gfx1170"
    if s == "GFX12":
        return major == 12
    if s == "GFX8-GFX10":
        return 8 <= major <= 10
    if s == "GFX6-GFX12":
        return 6 <= major <= 12
    if s == "GFX10-GFX12":
        return 10 <= major <= 12
    if s == "GFX9-GFX12":
        return 9 <= major <= 12
    if s == "GFX10-GFX11":
        return 10 <= major <= 11
    if s == "GFX11-GFX12":
        return 11 <= major <= 12
    return False


# Code Object V3 Kernel Descriptor 布局（64 字节，与 LLVM AMDHSAKernelDescriptor.h 一致）
_KD_GROUP_SEGMENT_FIXED_SIZE = 0
_KD_PRIVATE_SEGMENT_FIXED_SIZE = 4
_KD_KERNARG_SIZE = 8
_KD_COMPUTE_PGM_RSRC3 = 44
_KD_COMPUTE_PGM_RSRC1 = 48
_KD_COMPUTE_PGM_RSRC2 = 52
_KD_KERNEL_CODE_PROPERTIES = 56
_KD_KERNARG_PRELOAD = 58
_KD_SIZE = 64


def _parse_kernel_descriptor(data: bytes, gfx: str) -> Optional[dict]:
    """
    从 .rodata 中一段 64 字节的 kernel descriptor 解析出 .amdhsa_* 指令所需字段。
    返回 dict：键为 meta_keys 中使用的名称（如 group_segment_fixed_size），值均为 int。
    若 data 长度不足 64 字节返回 None。
    """
    if len(data) < _KD_SIZE:
        return None
    gfx = gfx.lower().strip()
    major, _ = _gfx_major_minor(gfx)

    group = int.from_bytes(data[_KD_GROUP_SEGMENT_FIXED_SIZE : _KD_GROUP_SEGMENT_FIXED_SIZE + 4], "little")
    private = int.from_bytes(data[_KD_PRIVATE_SEGMENT_FIXED_SIZE : _KD_PRIVATE_SEGMENT_FIXED_SIZE + 4], "little")
    kernarg = int.from_bytes(data[_KD_KERNARG_SIZE : _KD_KERNARG_SIZE + 4], "little")
    rsrc3 = int.from_bytes(data[_KD_COMPUTE_PGM_RSRC3 : _KD_COMPUTE_PGM_RSRC3 + 4], "little")
    rsrc1 = int.from_bytes(data[_KD_COMPUTE_PGM_RSRC1 : _KD_COMPUTE_PGM_RSRC1 + 4], "little")
    rsrc2 = int.from_bytes(data[_KD_COMPUTE_PGM_RSRC2 : _KD_COMPUTE_PGM_RSRC2 + 4], "little")
    code_props = int.from_bytes(data[_KD_KERNEL_CODE_PROPERTIES : _KD_KERNEL_CODE_PROPERTIES + 2], "little")
    preload = int.from_bytes(data[_KD_KERNARG_PRELOAD : _KD_KERNARG_PRELOAD + 2], "little")

    props: dict[str, int] = {}
    props["group_segment_fixed_size"] = group
    props["private_segment_fixed_size"] = private
    props["kernarg_segment_size"] = kernarg

    # kernel_code_properties: bit0=private_segment_buffer, 1=dispatch_ptr, 2=queue_ptr, 3=kernarg_segment_ptr,
    # 4=dispatch_id, 5=flat_scratch_init, 6=private_segment_size, 10=wavefront_size32, 11=uses_dynamic_stack
    props["user_sgpr_private_segment_buffer"] = (code_props >> 0) & 1
    props["user_sgpr_dispatch_ptr"] = (code_props >> 1) & 1
    props["user_sgpr_queue_ptr"] = (code_props >> 2) & 1
    props["user_sgpr_kernarg_segment_ptr"] = (code_props >> 3) & 1
    props["user_sgpr_dispatch_id"] = (code_props >> 4) & 1
    props["user_sgpr_flat_scratch_init"] = (code_props >> 5) & 1
    props["user_sgpr_private_segment_size"] = (code_props >> 6) & 1
    props["wavefront_size32"] = (code_props >> 10) & 1
    props["uses_dynamic_stack"] = (code_props >> 11) & 1

    # USER_SGPR_COUNT 在 rsrc2 bits 1-5（GFX6-GFX120）
    props["user_sgpr_count"] = (rsrc2 >> 1) & 0x1F
    if major >= 12:
        props["user_sgpr_count"] = (rsrc2 >> 1) & 0x3F  # GFX125 为 6 bits

    # compute_pgm_rsrc2: enable_private_segment=bit0, workgroup_id_x=7, y=8, z=9, workgroup_info=10, system_vgpr_workitem_id=11-12
    props["enable_private_segment"] = rsrc2 & 1
    props["system_sgpr_workgroup_id_x"] = (rsrc2 >> 7) & 1
    props["system_sgpr_workgroup_id_y"] = (rsrc2 >> 8) & 1
    props["system_sgpr_workgroup_id_z"] = (rsrc2 >> 9) & 1
    props["system_sgpr_workgroup_info"] = (rsrc2 >> 10) & 1
    props["system_vgpr_workitem_id"] = (rsrc2 >> 11) & 3
    # exception bits 24-30
    props["exception_fp_ieee_invalid_op"] = (rsrc2 >> 24) & 1
    props["exception_fp_denorm_src"] = (rsrc2 >> 25) & 1
    props["exception_fp_ieee_div_zero"] = (rsrc2 >> 26) & 1
    props["exception_fp_ieee_overflow"] = (rsrc2 >> 27) & 1
    props["exception_fp_ieee_underflow"] = (rsrc2 >> 28) & 1
    props["exception_fp_ieee_inexact"] = (rsrc2 >> 29) & 1
    props["exception_int_div_zero"] = (rsrc2 >> 30) & 1

    # compute_pgm_rsrc1: granulated vgpr 0-5, granulated sgpr 6-9, float modes 12-19, 21=dx10_clamp, 23=ieee, 26=fp16_overflow, 29=wgp, 30=mem_ordered, 31=fwd_progress
    granulated_vgpr = rsrc1 & 0x3F
    granulated_sgpr = (rsrc1 >> 6) & 0xF
    wave32 = props.get("wavefront_size32", 0)
    if major >= 10 and wave32:
        next_vgpr = (granulated_vgpr + 1) * 8
    else:
        next_vgpr = (granulated_vgpr + 1) * 4
    if major >= 10:
        next_sgpr = 128  # GFX10+ 固定 128 SGPR
    elif major <= 8:
        next_sgpr = (granulated_sgpr + 1) * 8
    else:
        next_sgpr = ((granulated_sgpr // 2) + 1) * 16  # GFX9: granulated = 2*(ceil(sgprs/16)-1)
    props["vgpr_count"] = next_vgpr
    props["sgpr_count"] = min(next_sgpr, 128)

    props["float_round_mode_32"] = (rsrc1 >> 12) & 3
    props["float_round_mode_16_64"] = (rsrc1 >> 14) & 3
    props["float_denorm_mode_32"] = (rsrc1 >> 16) & 3
    props["float_denorm_mode_16_64"] = (rsrc1 >> 18) & 3
    props["dx10_clamp"] = (rsrc1 >> 21) & 1
    props["ieee_mode"] = (rsrc1 >> 23) & 1
    props["fp16_overflow"] = (rsrc1 >> 26) & 1
    props["workgroup_processor_mode"] = (rsrc1 >> 29) & 1
    props["memory_ordered"] = (rsrc1 >> 30) & 1
    props["forward_progress"] = (rsrc1 >> 31) & 1
    props["round_robin_scheduling"] = (rsrc1 >> 21) & 1  # GFX12 复用 bit21 为 WG_RR_EN

    # compute_pgm_rsrc3: GFX90A/GFX942 accum_offset 0-5, tg_split 16; GFX10-GFX11 shared_vgpr_count 0-3; GFX11+ inst_pref_size 4-9; GFX125 named_barrier 14-16
    props["accum_offset"] = (((rsrc3 >> 0) & 0x3F) + 1) * 4
    props["tg_split"] = (rsrc3 >> 16) & 1
    props["shared_vgpr_count"] = (rsrc3 >> 0) & 0xF
    props["inst_pref_size"] = (rsrc3 >> 4) & 0x3F
    props["named_barrier_count"] = (rsrc3 >> 14) & 7

    # kernarg preload: low 7 bits = length, next 9 bits = offset
    props["user_sgpr_kernarg_preload_length"] = preload & 0x7F
    props["user_sgpr_kernarg_preload_offset"] = (preload >> 7) & 0x1FF

    # reserve_* 从 rsrc1/rsrc2 无法直接读出，由 CP 根据指令填写；常见默认
    props["reserve_vcc"] = 1
    props["reserve_flat_scratch"] = 1
    props["reserve_xnack_mask"] = 0
    props["system_sgpr_private_segment_wavefront_offset"] = 0
    return props


def _merge_metadata_sgpr_vgpr(kernels: list[dict], meta: dict) -> None:
    """
    将 metadata 中 amdhsa.kernels 的 .sgpr_count 与 .vgpr_count 合并到 kernels 列表中（按 name 匹配）。
    使 .amdhsa_next_free_sgpr / .amdhsa_next_free_vgpr 始终使用 metadata 的值。
    """
    meta_kernels = get_kernels(meta)
    if not meta_kernels:
        return
    by_name: dict[str, dict] = {}
    for m in meta_kernels:
        n = m.get(".name") or m.get("name") or ""
        if n.endswith(".kd"):
            n = n[:-3]
        if n:
            by_name[n] = m
    for k in kernels:
        name = k.get(".name") or k.get("name") or ""
        if name.endswith(".kd"):
            name = name[:-3]
        m = by_name.get(name)
        if not m:
            continue
        for key in (".sgpr_count", "sgpr_count", "NumSGPRs"):
            v = m.get(key)
            if v is not None:
                try:
                    val = int(v)
                    k[".sgpr_count"] = val
                    k["sgpr_count"] = val
                    break
                except (TypeError, ValueError):
                    pass
        for key in (".vgpr_count", "vgpr_count", "NumVGPRs"):
            v = m.get(key)
            if v is not None:
                try:
                    val = int(v)
                    k[".vgpr_count"] = val
                    k["vgpr_count"] = val
                    break
                except (TypeError, ValueError):
                    pass


def get_kernels_from_rodata(co: CoElf, target: str) -> list[dict]:
    """
    从 .co 的 .rodata 段中按 .kd 符号解析出 kernel 列表。
    每项为 dict：含 "name" 及 .amdhsa_* 对应的字段（与 metadata kernel 键一致，便于复用 _get_kernel_prop）。
    """
    gfx = _target_to_gfx(target)
    kd_syms = co.get_kernel_descriptor_symbols()
    if not kd_syms or not co.rodata_data or co.rodata_addr == 0:
        return []
    kernels = []
    for sym in kd_syms:
        offset = sym.value - co.rodata_addr
        if offset < 0 or offset + _KD_SIZE > len(co.rodata_data):
            continue
        chunk = co.rodata_data[offset : offset + _KD_SIZE]
        props = _parse_kernel_descriptor(chunk, gfx)
        if props is None:
            continue
        name = sym.name[:-3] if sym.name.endswith(".kd") else sym.name
        props["name"] = name
        props[".name"] = name
        kernels.append(props)
    return kernels


def _get_kernel_prop(k: dict, keys: list[str], default: Optional[int]) -> Optional[int]:
    """从 kernel 元数据或从 .rodata 解析出的 props 中取第一个存在的键对应的整数值；若为 bool 则转为 0/1。"""
    for key in keys:
        v = k.get(key)
        if v is None:
            continue
        if isinstance(v, bool):
            return 1 if v else 0
        try:
            return int(v)
        except (TypeError, ValueError):
            continue
    return default


def _wavefront_size_to_wavefront_size32(k: dict) -> Optional[int]:
    """wavefront_size 64 -> .amdhsa_wavefront_size32 0；32 -> 1。若已有 wavefront_size32 则直接返回。"""
    v = k.get("wavefront_size32")
    if v is not None:
        try:
            return int(v)
        except (TypeError, ValueError):
            pass
    w = k.get(".wavefront_size") or k.get("wavefront_size")
    if w is None:
        return None
    try:
        return 1 if int(w) == 32 else 0
    except (TypeError, ValueError):
        return None


def emit_amdhsa_kernel_section(kernels: list[dict], target: str) -> list[str]:
    """
    从 kernel 列表生成 .rodata 与 .amdhsa_kernel 块。
    每条 kernel 为 dict（来自 .rodata 解析或 metadata），含 name 及各 .amdhsa_* 对应字段。
    仅输出当前 target 对应 gfx 在 LLVM 文档 "Supported On" 中支持的 .amdhsa_* 指令。
    """
    gfx = _target_to_gfx(target)
    lines = [".rodata", ".p2align 6"]
    for k in kernels:
        name = k.get(".name") or k.get("name") or "unknown"
        if name.endswith(".kd"):
            name = name[:-3]
        lines.append(f".amdhsa_kernel {name}")
        for directive, meta_keys, default, supported_on in _AMDHSA_KERNEL_DIRECTIVES:
            if not _gfx_supports_directive(gfx, supported_on):
                continue
            if directive == ".amdhsa_wavefront_size32":
                val = _wavefront_size_to_wavefront_size32(k)
                if val is None:
                    val = default
            else:
                val = _get_kernel_prop(k, meta_keys, default)
            if val is None:
                val = 0  # 必选指令无 metadata 时用 0，保证块完整可汇编
            lines.append(f"  {directive} {val}")
        lines.append(".end_amdhsa_kernel")
    return lines


def emit_amdgpu_metadata_section(meta: dict) -> list[str]:
    """生成 .amdgpu_metadata / .end_amdgpu_metadata 包裹的 YAML 块。"""
    if not meta:
        return []
    lines = [".amdgpu_metadata", "---"]
    lines.extend(metadata_to_yaml_like(meta, indent=0))
    lines.append(".end_amdgpu_metadata")
    return lines


def _compute_func_sizes(disasm_lines: list[DisasmLine], addr_to_symbol: dict[int, str], first_code_addr: int) -> dict[str, int]:
    """根据反汇编行计算每个函数的大小（字节）。"""
    funcs = sorted(addr_to_symbol.items())
    if not funcs:
        return {}
    sizes = {}
    for i, (addr, name) in enumerate(funcs):
        if addr < first_code_addr:
            continue
        next_addr = funcs[i + 1][0] if i + 1 < len(funcs) else None
        if next_addr is None:
            # 最后一个函数：到最后一条件令的末尾
            last_addr = first_code_addr
            for d in disasm_lines:
                if d.addr >= addr and not d.is_data and d.instruction:
                    last_addr = d.addr + 4
            sizes[name] = last_addr - addr
        else:
            sizes[name] = next_addr - addr
    return sizes


def co_to_s(
    co_path: str,
    co: CoElf,
    objdump_bin: Optional[str] = None,
) -> str:
    """
    将 .co 文件转换为可汇编的 .s 内容。
    """
    meta = decode_metadata(co.metadata_payload)
    target = get_amdhsa_target(meta)
    if not target:
        target = _e_flags_to_target(co.e_flags)
    # .amdhsa_kernel 内容优先从 .co 的 .rodata 段解析（.kd 符号）；无则回退到 metadata
    kernels = get_kernels_from_rodata(co, target)
    if not kernels:
        kernels = get_kernels(meta)
    # .amdhsa_next_free_sgpr / .amdhsa_next_free_vgpr 始终使用 metadata 中的 .sgpr_count / .vgpr_count
    _merge_metadata_sgpr_vgpr(kernels, meta)
    addr_to_symbol = _symbol_at_addr_from_elf(co)
    first_code_addr = _first_code_addr(co)

    objdump_out = run_objdump(co_path, objdump_bin=objdump_bin, section=".text")
    disasm_lines = parse_objdump_output(
        objdump_out,
        symbol_at_addr=lambda addr: addr_to_symbol.get(addr),
    )
    func_sizes = _compute_func_sizes(disasm_lines, addr_to_symbol, first_code_addr)

    out_lines = []
    # 1. .amdgcn_target
    out_lines.append(f'//.amdgcn_target "{target}"')
    out_lines.append("")
    # 2. .text
    out_lines.extend(emit_text_section(disasm_lines, first_code_addr, addr_to_symbol, func_sizes, meta))
    out_lines.append("")
    # 3. .rodata + .amdhsa_kernel（从 .rodata 或 metadata 解析，仅输出当前 target gfx 支持的指令）
    out_lines.extend(emit_amdhsa_kernel_section(kernels, target))
    out_lines.append("")
    # 4. .amdgpu_metadata（有元数据时）
    meta_lines = emit_amdgpu_metadata_section(meta)
    if meta_lines:
        out_lines.extend(meta_lines)

    return "\n".join(out_lines) + "\n"
