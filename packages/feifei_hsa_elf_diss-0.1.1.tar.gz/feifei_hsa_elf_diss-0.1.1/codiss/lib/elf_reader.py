"""
ELF 解析：读取 .text、.rodata、.note、.symtab/.strtab，提取 NT_AMDGPU_METADATA。
参考：amdhsa-codebase/docs/elf_code_object.md, symbols_relocations.md
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import BinaryIO, Optional

from elftools.elf.elffile import ELFFile
from elftools.elf.sections import NoteSection, SymbolTableSection

NT_AMDGPU_METADATA = 32
AMDGPU_NOTE_NAME = b"AMDGPU"


@dataclass
class SymInfo:
    """符号信息：名称、在 section 内偏移、类型（STT_FUNC/STT_OBJECT）、所属 section 索引。"""
    name: str
    value: int  # st_value: 在 section 内偏移或 VMA
    size: int
    st_type: str  # 'STT_FUNC', 'STT_OBJECT', ...
    shndx: int


@dataclass
class CoElf:
    """从 .co 解析出的 ELF 摘要。"""
    # 节区数据（按需读取）
    text_data: bytes = b""
    text_addr: int = 0  # 节区在文件中的逻辑地址/加载地址（用于与符号 value 对应）
    rodata_data: bytes = b""
    rodata_addr: int = 0  # .rodata 节区 VMA，用于将 .kd 符号 value 转为节内偏移
    e_flags: int = 0
    # NT_AMDGPU_METADATA 的 desc 原始字节（MessagePack）
    metadata_payload: bytes = b""
    # 符号表：STT_FUNC 为 kernel/函数入口，STT_OBJECT 含 <name>.kd
    symbols: list[SymInfo] = field(default_factory=list)
    strtab: Optional[SymbolTableSection] = None  # 用于 get_string；若用 sym.name 则可不保留

    def get_functions(self) -> list[SymInfo]:
        """返回所有 STT_FUNC 符号（按 value 排序）。"""
        return sorted(
            [s for s in self.symbols if s.st_type == "STT_FUNC"],
            key=lambda s: s.value,
        )

    def get_kernel_descriptor_symbols(self) -> list[SymInfo]:
        """返回所有 STT_OBJECT 且名称以 .kd 结尾的符号。"""
        return [s for s in self.symbols if s.st_type == "STT_OBJECT" and s.name.endswith(".kd")]


def _get_note_section(elf: ELFFile):
    """获取 .note 节（可能为 NoteSection 或普通 Section）。"""
    try:
        return elf.get_section_by_name(".note")
    except Exception:
        return None


def _iter_notes(elf: ELFFile, note_section) -> list[tuple[str, int, bytes]]:
    """迭代 .note 节中的 note，返回 (n_name, n_type, n_desc) 列表。"""
    if note_section is None:
        return []
    if isinstance(note_section, NoteSection):
        return [
            (note["n_name"], note["n_type"], note["n_desc"])
            for note in note_section.iter_notes()
        ]
    # 手动解析：SHT_NOTE 格式为每个 note: namesz(4), descsz(4), type(4), name[namesz], pad, desc[descsz], pad
    data = note_section.data()
    notes = []
    offset = 0
    while offset + 12 <= len(data):
        namesz = int.from_bytes(data[offset : offset + 4], "little")
        descsz = int.from_bytes(data[offset + 4 : offset + 8], "little")
        ntype = int.from_bytes(data[offset + 8 : offset + 12], "little")
        offset += 12
        name = data[offset : offset + namesz].split(b"\0")[0].decode("utf-8", errors="replace")
        offset = (offset + namesz + 3) & ~3
        desc = data[offset : offset + descsz]
        offset = (offset + descsz + 3) & ~3
        notes.append((name, ntype, desc))
    return notes


def read_co_elf(path: str) -> CoElf:
    """
    读取 .co 文件，解析 .text、.note、.symtab，提取 NT_AMDGPU_METADATA 与符号表。
    """
    co = CoElf()
    with open(path, "rb") as f:
        elf = ELFFile(f)
        if not elf.little_endian or elf.elfclass != 64:
            raise ValueError("codiss 仅支持 ELF64 小端")
        co.e_flags = elf["e_flags"]

        # .text
        text_sec = elf.get_section_by_name(".text")
        if text_sec:
            co.text_data = text_sec.data()
            co.text_addr = text_sec["sh_addr"]

        # .rodata
        rodata_sec = elf.get_section_by_name(".rodata")
        if rodata_sec:
            co.rodata_data = rodata_sec.data()
            co.rodata_addr = rodata_sec["sh_addr"]

        # .note -> NT_AMDGPU_METADATA
        note_sec = _get_note_section(elf)
        for n_name, n_type, n_desc in _iter_notes(elf, note_sec):
            if n_type != NT_AMDGPU_METADATA:
                continue
            name_str = n_name if isinstance(n_name, str) else (n_name or b"").rstrip(b"\0").decode("utf-8", errors="replace")
            if name_str == "AMDGPU":
                co.metadata_payload = n_desc
                break

        # .symtab + .strtab
        symtab = elf.get_section_by_name(".symtab")
        if symtab and isinstance(symtab, SymbolTableSection):
            for sym in symtab.iter_symbols():
                st_type_val = sym.entry["st_info"]["type"]
                if isinstance(st_type_val, str) and st_type_val.startswith("STT_"):
                    type_str = st_type_val
                elif hasattr(st_type_val, "name"):
                    type_str = getattr(st_type_val, "name", str(st_type_val))
                else:
                    try:
                        type_str = _st_type_to_name(int(st_type_val))
                    except (TypeError, ValueError):
                        type_str = str(st_type_val)
                co.symbols.append(
                    SymInfo(
                        name=sym.name or "",
                        value=sym.entry["st_value"],
                        size=sym.entry["st_size"],
                        st_type=type_str,
                        shndx=sym.entry["st_shndx"],
                    )
                )
    return co


def _st_type_to_name(t: int) -> str:
    """STT_* 数字转名称。"""
    # ELF: STT_NOTYPE=0, STT_OBJECT=1, STT_FUNC=2, STT_SECTION=3, STT_FILE=4, ...
    if t == 2:
        return "STT_FUNC"
    if t == 1:
        return "STT_OBJECT"
    return f"STT_{t}"
