# codiss.lib: ELF 解析、metadata 解码、objdump 解析、.s 生成
