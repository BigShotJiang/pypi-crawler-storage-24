"""feifei-hsa-elf-diss: 将 AMDGPU Code Object (.co) 反汇编为 LLVM 汇编 (.s) 文件。"""

__version__ = "0.1.1"
