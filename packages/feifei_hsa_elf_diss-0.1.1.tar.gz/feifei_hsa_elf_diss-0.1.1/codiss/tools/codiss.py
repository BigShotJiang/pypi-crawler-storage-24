#!/usr/bin/env python3
"""
codiss：将 AMDGPU .co 反汇编为 LLVM 汇编 .s 文件。
用法: codiss -i <input.co> -o <output.s> [--objdump <path>]
"""
from __future__ import annotations

import argparse
import sys
import os

# 允许从仓库根或 codiss 目录运行
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_CODISS_ROOT = os.path.dirname(_SCRIPT_DIR)
if _CODISS_ROOT not in sys.path:
    sys.path.insert(0, _CODISS_ROOT)

from lib.elf_reader import read_co_elf
from lib.emit_s import co_to_s


def main() -> int:
    ap = argparse.ArgumentParser(
        description="将 AMDGPU Code Object (.co) 反汇编为 LLVM 汇编 (.s) 文件",
    )
    ap.add_argument("-i", "--input", required=True, help="输入 .co 文件路径")
    ap.add_argument("-o", "--output", required=True, help="输出 .s 文件路径")
    ap.add_argument(
        "--objdump",
        default=os.environ.get("LLVM_OBJDUMP", ""),
        help="llvm-objdump 可执行文件路径（默认: LLVM_OBJDUMP 或 /opt/rocm/llvm/bin/llvm-objdump）",
    )
    args = ap.parse_args()
    if not os.path.isfile(args.input):
        print(f"codiss: 输入文件不存在: {args.input}", file=sys.stderr)
        return 1
    objdump_bin = args.objdump or None
    try:
        co = read_co_elf(args.input)
    except Exception as e:
        print(f"codiss: 解析 ELF 失败: {e}", file=sys.stderr)
        return 1
    try:
        s_content = co_to_s(args.input, co, objdump_bin=objdump_bin)
    except Exception as e:
        print(f"codiss: 生成汇编失败: {e}", file=sys.stderr)
        return 1
    with open(args.output, "w", encoding="utf-8") as f:
        f.write(s_content)
    return 0


if __name__ == "__main__":
    sys.exit(main())
