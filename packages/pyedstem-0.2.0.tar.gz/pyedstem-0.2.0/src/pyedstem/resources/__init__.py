"""Resource namespaces for pyedstem."""
