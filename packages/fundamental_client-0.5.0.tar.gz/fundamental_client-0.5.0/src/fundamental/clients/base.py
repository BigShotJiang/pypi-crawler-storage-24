"""
Base client for API interactions.

NOTE: Documentation Source for Auto-Generated SDK Reference

The docstrings and structured comments in this file are used by the
SDK documentation generator to build the official API reference.

Please do not remove or significantly alter these comments unless you
also update the documentation generation pipeline.

These comments are intentionally structured to support automated docs.
"""

from abc import ABC
from typing import TYPE_CHECKING, Dict, Optional

from fundamental.config import Config

if TYPE_CHECKING:
    from fundamental.services.models import ModelsService


class BaseClient(ABC):
    """
    Abstract base client for API interactions.

    All client implementations (e.g. :class:`Fundamental`,
    :class:`FundamentalAWSMarketplaceClient`) inherit from this class.

    Attributes
    ----------
    config : Config
        Immutable SDK configuration.
    models : ModelsService
        Model management service for listing, getting, deleting, and
        tagging trained models.
    """

    config: Config
    models: "ModelsService"
    _trace_dict: Optional[Dict[str, str]]

    def __init__(self, *, config: Config) -> None:
        """
        Initialize the base client with service properties.

        Parameters
        ----------
        config : Config
            Immutable SDK configuration object.
        """
        # Local import to avoid circular dependency at runtime
        from fundamental.services.models import ModelsService

        self.config = config
        self.models = ModelsService(client=self)
        self._trace_dict = None

    def get_trace_dict(self) -> Optional[Dict[str, str]]:
        """
        Get the current trace dictionary for workflow correlation.

        Returns
        -------
        dict or None
            Trace dictionary if set, otherwise None.
        """
        return self._trace_dict

    def _set_trace_dict(self, trace_dict: Optional[Dict[str, str]]) -> None:
        """Set the current trace dictionary (internal use only)."""
        self._trace_dict = trace_dict
