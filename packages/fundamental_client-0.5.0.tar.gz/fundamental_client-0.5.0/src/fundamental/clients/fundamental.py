"""
Fundamental client implementation.

NOTE: Documentation Source for Auto-Generated SDK Reference

The docstrings and structured comments in this file are used by the
SDK documentation generator to build the official API reference.

Please do not remove or significantly alter these comments unless you
also update the documentation generation pipeline.

These comments are intentionally structured to support automated docs.
"""

from typing import Any

from fundamental.clients.base import BaseClient
from fundamental.config import Config


class Fundamental(BaseClient):
    """
    Primary client for authenticating and configuring SDK requests.

    Create a ``Fundamental`` instance with your API key and register it
    via ``set_client`` - all estimators will use it automatically, so
    you only need to configure the client once.

    All configuration parameters are forwarded to
    :class:`~fundamental.config.Config`.

    Parameters
    ----------
    api_key : str, optional
        API key for authentication. Defaults to the
        ``FUNDAMENTAL_API_KEY`` environment variable.
    api_url : str, optional
        Base API URL. Defaults to the ``FUNDAMENTAL_API_URL``
        environment variable, or ``https://api.fundamental.tech``.
    retries : int
        Number of retries for failed requests.
    timeout : int
        Default request timeout in seconds.
    fit_timeout : int
        Timeout for fit operations in seconds.
    predict_timeout : int
        Timeout for predict operations in seconds.
    feature_importance_timeout : int
        Timeout for feature importance operations in seconds.
    download_prediction_result_timeout : int
        Timeout for downloading prediction results in seconds.
    download_feature_importance_result_timeout : int
        Timeout for downloading feature importance results in
        seconds.
    verify_ssl : bool
        Whether to verify SSL certificates.

    Notes
    -----
    Timeouts apply only to the processing phase, starting after the
    dataset upload has completed.

    Examples
    --------
    >>> from fundamental import Fundamental, set_client
    >>> client = Fundamental(api_key="your-api-key")
    >>> set_client(client)
    """

    def __init__(
        self,
        **kwargs: Any,  # noqa: ANN401
    ):
        cfg = Config(
            **kwargs,
        )
        super().__init__(config=cfg)
