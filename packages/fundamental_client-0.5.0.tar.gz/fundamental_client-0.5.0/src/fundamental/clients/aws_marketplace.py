"""
Fundamental AWS Marketplace client with AWS SigV4 authentication.

NOTE: Documentation Source for Auto-Generated SDK Reference

The docstrings and structured comments in this file are used by the
SDK documentation generator to build the official API reference.

Please do not remove or significantly alter these comments unless you
also update the documentation generation pipeline.

These comments are intentionally structured to support automated docs.
"""

from typing import Any, Optional

from fundamental.clients.base import BaseClient
from fundamental.config import Config


class FundamentalAWSMarketplaceClient(BaseClient):
    """
    Client for Fundamental API on AWS Marketplace deployments.

    Uses AWS SigV4 signing for authentication via IAM roles instead of
    API keys.

    Parameters
    ----------
    aws_region : str
        AWS region for SigV4 signing (required).
    api_url : str or None, optional
        Base URL for the private deployment API server (API Gateway URL).
        Defaults to the ``FUNDAMENTAL_API_URL`` environment variable.
    **kwargs
        Additional configuration options forwarded to :class:`~fundamental.config.Config`.

    Examples
    --------
    >>> from fundamental import FundamentalAWSMarketplaceClient, set_client
    >>> client = FundamentalAWSMarketplaceClient(
    ...     aws_region="us-east-1",
    ...     api_url="https://your-api-gateway-url.amazonaws.com",
    ... )
    >>> set_client(client)
    """

    def __init__(
        self,
        aws_region: str,
        api_url: Optional[str] = None,
        **kwargs: Any,  # noqa: ANN401
    ):
        cfg = Config(
            api_url=api_url or "",
            use_sigv4_auth=True,
            aws_region=aws_region,
            **kwargs,
        )
        super().__init__(config=cfg)
