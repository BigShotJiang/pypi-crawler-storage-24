"""
Custom exceptions for NEXUS Client SDK.

NOTE: Documentation Source for Auto-Generated SDK Reference

The docstrings and structured comments in this file are used by the
SDK documentation generator to build the official API reference.

Please do not remove or significantly alter these comments unless you
also update the documentation generation pipeline.

These comments are intentionally structured to support automated docs.
"""

from typing import Any, Dict, Literal, Optional


class NEXUSError(Exception):
    """
    Base exception for all NEXUS client errors.

    Attributes
    ----------
    details : dict
        Additional error context (may be empty).
    trace_id : str or None
        Unique request ID for support diagnostics.
    """

    def __init__(
        self,
        message: str,
        details: Optional[Dict[str, Any]] = None,
        trace_id: Optional[str] = None,
    ):
        """
        Initialize a NEXUSError.

        Parameters
        ----------
        message : str
            Human-readable error description.
        details : dict, optional
            Additional error context from the server.
        trace_id : str, optional
            Unique request ID for correlating with server logs.
        """
        super().__init__(message)
        self.details = details or {}
        self.trace_id = trace_id


class HTTPError(NEXUSError):
    """
    Base class for HTTP errors with status codes.

    Attributes
    ----------
    status_code : int
        HTTP status code associated with the error.
    """

    status_code: int

    def __str__(self) -> str:
        return f"HTTP {self.status_code}: {super().__str__()}"


class ValidationError(HTTPError):
    """Raised when input validation fails (HTTP 400)."""

    status_code: Literal[400] = 400  # pyright: ignore[reportIncompatibleVariableOverride]


class AuthenticationError(HTTPError):
    """Raised when authentication fails (HTTP 401)."""

    status_code: Literal[401] = 401  # pyright: ignore[reportIncompatibleVariableOverride]


class AuthorizationError(HTTPError):
    """Raised when authorization fails (HTTP 403)."""

    status_code: Literal[403] = 403  # pyright: ignore[reportIncompatibleVariableOverride]


class NotFoundError(HTTPError):
    """Raised when a resource is not found (HTTP 404)."""

    status_code: Literal[404] = 404  # pyright: ignore[reportIncompatibleVariableOverride]


class RateLimitError(HTTPError):
    """Raised when API rate limits are exceeded (HTTP 429)."""

    status_code: Literal[429] = 429  # pyright: ignore[reportIncompatibleVariableOverride]


class ServerError(HTTPError):
    """Raised when the server returns a 5xx error."""

    status_code: int = 500


class NetworkError(HTTPError):
    """Raised when a network connectivity issue occurs (HTTP 503)."""

    status_code: Literal[503] = 503  # pyright: ignore[reportIncompatibleVariableOverride]


class RequestTimeoutError(HTTPError):
    """Raised when a request times out (HTTP 504)."""

    status_code: Literal[504] = 504  # pyright: ignore[reportIncompatibleVariableOverride]


# Deprecated alias for backward compatibility
FTMError = NEXUSError
