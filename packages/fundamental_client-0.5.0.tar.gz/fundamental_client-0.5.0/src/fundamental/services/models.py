"""
Model management services for NEXUS client.

NOTE: Documentation Source for Auto-Generated SDK Reference

The docstrings and structured comments in this file are used by the
SDK documentation generator to build the official API reference.

Please do not remove or significantly alter these comments unless you
also update the documentation generation pipeline.

These comments are intentionally structured to support automated docs.
"""

import base64
import logging
from typing import Any, Dict

from pydantic import BaseModel
from typing_extensions import TypeAlias

from fundamental.clients.base import BaseClient
from fundamental.exceptions import ValidationError
from fundamental.models import (
    DeleteTrainedModelResponse,
    TrainedModelMetadata,
    UpdateAttributesResponse,
)
from fundamental.utils.http import api_call
from fundamental.utils.safetensors_deserialize import load_estimator_fields_from_bytes

logger = logging.getLogger(__name__)

TrainedModelsListResponse: TypeAlias = list[TrainedModelMetadata]


class LoadedModelResponse(BaseModel):
    estimator_fields: Dict[str, Any]


class ModelsService:
    """
    Manage trained models through the ``client.models`` service.

    Use this to list, inspect, annotate, and delete models
    independently of the estimator that created them.
    """

    def __init__(self, client: BaseClient) -> None:
        """
        Initialize the models service.

        Parameters
        ----------
        client : BaseClient
            Client instance for API communication.
        """
        self.client = client

    def _validate_model_id(self, model_id: str) -> None:
        if not model_id or not model_id.strip():
            raise ValidationError("model_id cannot be empty. Please provide a valid model_id.")

    def list(self) -> TrainedModelsListResponse:
        """
        List all trained models.

        Returns
        -------
        TrainedModelsListResponse
            List of trained model metadata.

        Raises
        ------
        AuthenticationError
            If the API key is invalid or missing.
        AuthorizationError
            If the account has insufficient permissions.
        ServerError
            If a server-side error occurred.
        NetworkError
            If a network connectivity issue occurred.
        RequestTimeoutError
            If the request timed out.

        Examples
        --------
        >>> model_ids = client.models.list()
        """
        response = api_call(
            method="GET",
            full_url=self.client.config.get_full_model_management_url(),
            client=self.client,
        )

        data = response.json()
        return [TrainedModelMetadata(**m) for m in data["models"]]

    def delete(self, model_id: str) -> DeleteTrainedModelResponse:
        """
        Permanently delete a trained model.

        This action cannot be undone - the model will no longer be
        available for predictions or loading via ``load_model``.

        Parameters
        ----------
        model_id : str
            The ID of the model to delete.

        Returns
        -------
        DeleteTrainedModelResponse
            Response with ``message``, ``trained_model_id``, and
            ``user_id`` attributes.

        Raises
        ------
        ValidationError
            If ``model_id`` is empty.
        NotFoundError
            If the model ID does not exist.
        AuthenticationError
            If the API key is invalid or missing.
        AuthorizationError
            If the account has insufficient permissions.
        ServerError
            If a server-side error occurred.
        NetworkError
            If a network connectivity issue occurred.
        RequestTimeoutError
            If the request timed out.

        Examples
        --------
        >>> client.models.delete("model_abc123")
        """
        self._validate_model_id(model_id)
        logger.debug("Deleting model %s", model_id)

        response = api_call(
            method="DELETE",
            full_url=f"{self.client.config.get_full_model_management_url()}/{model_id}",
            client=self.client,
        )

        return DeleteTrainedModelResponse(**response.json())

    def get(self, model_id: str) -> TrainedModelMetadata:
        """
        Retrieve metadata for a trained model.

        Returns the model's ID and any user-defined attributes.

        Parameters
        ----------
        model_id : str
            The ID of the model to retrieve.

        Returns
        -------
        TrainedModelMetadata
            Object with ``trained_model_id`` (``str``) and
            ``attributes`` (``dict[str, str]``) attributes.

        Raises
        ------
        ValidationError
            If ``model_id`` is empty.
        NotFoundError
            If the model ID does not exist.
        AuthenticationError
            If the API key is invalid or missing.
        AuthorizationError
            If the account has insufficient permissions.
        ServerError
            If a server-side error occurred.
        NetworkError
            If a network connectivity issue occurred.
        RequestTimeoutError
            If the request timed out.

        Examples
        --------
        >>> metadata = client.models.get("model_abc123")
        >>> print(metadata.trained_model_id)
        """
        self._validate_model_id(model_id)

        response = api_call(
            method="GET",
            full_url=f"{self.client.config.get_full_model_management_url()}/{model_id}",
            client=self.client,
            max_retries=3,
        )

        return TrainedModelMetadata(**response.json())

    def set_attributes(
        self,
        model_id: str,
        attributes: dict[str, str],
    ) -> UpdateAttributesResponse:
        """
        Set key-value metadata on a trained model.

        Useful for tagging models with version info, ownership, or
        deployment stage. This can also be done directly on a fitted
        estimator via ``clf.set_attributes(...)``
        (see `Classification <./nexus-classifier.md>`_ /
        `Regression <./nexus-regressor.md>`_).

        Parameters
        ----------
        model_id : str
            The ID of the model to update.
        attributes : dict[str, str]
            Key-value pairs to set.

        Returns
        -------
        UpdateAttributesResponse
            Object with ``attributes`` (``dict[str, str]``) -
            the updated attributes.

        Raises
        ------
        ValidationError
            If ``model_id`` is empty.
        AuthenticationError
            If the API key is invalid or missing.
        AuthorizationError
            If the account has insufficient permissions.
        ServerError
            If a server-side error occurred.
        NetworkError
            If a network connectivity issue occurred.
        RequestTimeoutError
            If the request timed out.

        Examples
        --------
        >>> client.models.set_attributes("model_abc123", {
        ...     "name": "Churn Predictor",
        ...     "stage": "production",
        ... })
        """
        self._validate_model_id(model_id)

        response = api_call(
            method="PATCH",
            full_url=f"{self.client.config.get_full_model_management_url()}/{model_id}/attributes",
            client=self.client,
            json={"attributes": attributes},
        )

        return UpdateAttributesResponse(**response.json())

    def load(
        self,
        trained_model_id: str,
    ) -> LoadedModelResponse:
        """
        Load a specific trained model.

        Parameters
        ----------
        trained_model_id : str
            The ID of the model to load.

        Returns
        -------
        LoadedModelResponse
            Deserialized model data including estimator fields.

        Raises
        ------
        ValidationError
            If trained_model_id is empty or invalid.
        NotFoundError
            If the model ID does not exist.
        """
        self._validate_model_id(trained_model_id)

        response = api_call(
            method="GET",
            full_url=f"{self.client.config.get_full_model_management_url()}/{trained_model_id}/load_model",
            client=self.client,
        )
        response_json = response.json()
        raw_bytes = base64.b64decode(response_json["estimator_fields"], validate=True)
        logger.debug("Loaded model %s (%d bytes)", trained_model_id, len(raw_bytes))
        estimator_fields = load_estimator_fields_from_bytes(raw_bytes)
        return LoadedModelResponse(
            estimator_fields=estimator_fields,
        )
