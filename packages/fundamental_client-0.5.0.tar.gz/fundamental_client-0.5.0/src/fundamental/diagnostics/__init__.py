"""Diagnostics toolkit for Fundamental SDK.

Usage::

    from fundamental.diagnostics import activate
    activate()

As context manager::

    from fundamental.diagnostics import diagnose
    with diagnose():
        model.fit(X, y)
"""

import sys
from contextlib import contextmanager
from typing import Generator, Optional

from fundamental.diagnostics.manager import DiagnosticsManager

__all__ = ["activate", "deactivate", "diagnose"]

_active_manager: Optional[DiagnosticsManager] = None


def activate(log_dir: Optional[str] = None) -> None:
    """
    Enable diagnostics globally.

    Creates a timestamped log file
    (``fundamental_debug_YYYYMMDD_HHMMSS.log``) in the specified
    directory. Subsequent calls are ignored if diagnostics are
    already active.

    Parameters
    ----------
    log_dir : str or None, default System temp directory
        Directory for the log file.

    Returns
    -------
    None

    Examples
    --------
    >>> from fundamental.diagnostics import activate
    >>> activate()
    >>> activate(log_dir="/var/log/myapp")
    """
    global _active_manager
    if _active_manager:
        return
    manager = DiagnosticsManager(log_dir=log_dir)
    manager.activate()
    _active_manager = manager


def deactivate() -> None:
    """
    Disable diagnostics and clean up logging handlers.

    No-op if diagnostics are not active.

    Returns
    -------
    None

    Examples
    --------
    >>> from fundamental.diagnostics import deactivate
    >>> deactivate()
    """
    global _active_manager
    if _active_manager:
        _active_manager.deactivate()
        _active_manager = None


@contextmanager
def diagnose(log_dir: Optional[str] = None) -> Generator[None, None, None]:
    """
    Context manager that activates diagnostics for a scoped block.

    Automatically deactivates on exit. If an exception occurs inside
    the block, diagnostics captures an enhanced report (including
    traceback, SDK version, platform info, and trace ID) before
    re-raising the exception.

    Parameters
    ----------
    log_dir : str or None, default System temp directory
        Directory for the log file.

    Examples
    --------
    >>> from fundamental.diagnostics import diagnose
    >>> with diagnose():
    ...     clf.fit(X_train, y_train)
    """
    activate(log_dir=log_dir)
    try:
        yield
    finally:
        exc = sys.exc_info()[1]
        if _active_manager and exc is not None:
            _active_manager._excepthook(type(exc), exc, exc.__traceback__)
        deactivate()
