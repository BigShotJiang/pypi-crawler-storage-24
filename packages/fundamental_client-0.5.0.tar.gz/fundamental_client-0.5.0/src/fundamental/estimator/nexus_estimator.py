"""
NEXUS Estimator with public API methods.

This module contains NEXUSEstimator which extends BaseNEXUSEstimator
with feature importance operations.

NOTE: Documentation Source for Auto-Generated SDK Reference

The docstrings and structured comments in this file are used by the
SDK documentation generator to build the official API reference.

Please do not remove or significantly alter these comments unless you
also update the documentation generation pipeline.

These comments are intentionally structured to support automated docs.
"""

import logging
from abc import ABC
from typing import Optional

import numpy as np
from sklearn.utils.validation import check_is_fitted

from fundamental.estimator.base import BaseNEXUSEstimator
from fundamental.services import remote_get_feature_importance
from fundamental.services.feature_importance import (
    poll_feature_importance_result,
    submit_feature_importance_task,
)
from fundamental.utils.data import XType, log_dataset_info, validate_data, validate_inputs_type

logger = logging.getLogger(__name__)


class NEXUSEstimator(BaseNEXUSEstimator, ABC):
    """
    NEXUS Estimator with public API methods.

    Extends BaseNEXUSEstimator with advanced operations.
    """

    def get_feature_importance(
        self,
        X: XType,
    ) -> np.ndarray:
        """
        Compute feature importance scores for each input feature.

        Requires a fitted model via ``fit`` or ``load_model``. For
        non-blocking computation, see
        ``submit_feature_importance_task``.

        Parameters
        ----------
        X : XType
            Input features as numpy array or pandas DataFrame.

        Returns
        -------
        np.ndarray
            Feature importance scores.

        Raises
        ------
        NotFittedError
            If the model has not been fitted yet.
        TypeError
            If ``X`` is not a DataFrame or ndarray.
        ValueError
            If data is empty.
        AuthenticationError
            If the API key is invalid or missing.
        AuthorizationError
            If the account has insufficient permissions.
        RateLimitError
            If the API rate limit was exceeded.
        ServerError
            If a server-side error occurred.
        NetworkError
            If a network connectivity issue occurred.
        RequestTimeoutError
            If the request timed out.

        Examples
        --------
        >>> importance = clf.get_feature_importance(X)
        """
        validate_inputs_type(X=X)
        validate_data(X=X)
        logger.debug(
            "get_feature_importance: model_id=%s X.shape=%s",
            getattr(self, "trained_model_id_", None),
            X.shape,
        )
        log_dataset_info(X=X)
        check_is_fitted(self)
        assert self.trained_model_id_ is not None
        return remote_get_feature_importance(
            X=X,
            trained_model_id=self.trained_model_id_,
            client=self._get_client(),
        )

    def submit_feature_importance_task(
        self,
        X: XType,
    ) -> str:
        """
        Submit a feature importance computation without blocking.

        Requires a fitted model. Returns a task ID for use with
        ``poll_feature_importance_result``.

        Parameters
        ----------
        X : XType
            Input features as numpy array or pandas DataFrame.

        Returns
        -------
        str
            Task ID for use with ``poll_feature_importance_result``.

        Raises
        ------
        NotFittedError
            If the model has not been fitted yet.
        TypeError
            If ``X`` is not a DataFrame or ndarray.
        ValueError
            If data is empty.
        AuthenticationError
            If the API key is invalid or missing.
        AuthorizationError
            If the account has insufficient permissions.
        RateLimitError
            If the API rate limit was exceeded.
        ServerError
            If a server-side error occurred.
        NetworkError
            If a network connectivity issue occurred.
        RequestTimeoutError
            If the request timed out.

        Examples
        --------
        >>> task_id = clf.submit_feature_importance_task(X)
        """
        validate_inputs_type(X=X)
        validate_data(X=X)
        logger.debug(
            "submit_feature_importance_task: model_id=%s X.shape=%s",
            getattr(self, "trained_model_id_", None),
            X.shape,
        )
        log_dataset_info(X=X)
        check_is_fitted(self)
        assert self.trained_model_id_ is not None
        return submit_feature_importance_task(
            X=X,
            trained_model_id=self.trained_model_id_,
            client=self._get_client(),
        )

    def poll_feature_importance_result(self, task_id: str) -> Optional[np.ndarray]:
        """
        Check if a feature importance job has completed.

        Returns the importance scores array when done, or ``None``
        if still in progress.

        Parameters
        ----------
        task_id : str
            Task ID from ``submit_feature_importance_task``.

        Returns
        -------
        Optional[np.ndarray]
            Feature importance scores if complete, None if still
            in progress.

        Raises
        ------
        NotFittedError
            If the model has not been fitted yet.
        AuthenticationError
            If the API key is invalid or missing.
        AuthorizationError
            If the account has insufficient permissions.
        ServerError
            If a server-side error occurred.
        NetworkError
            If a network connectivity issue occurred.
        RequestTimeoutError
            If the request timed out.

        Examples
        --------
        >>> result = clf.poll_feature_importance_result(task_id)
        """
        logger.debug(
            "poll_feature_importance_result: task_id=%s model_id=%s",
            task_id,
            getattr(self, "trained_model_id_", None),
        )
        check_is_fitted(self)
        assert self.trained_model_id_ is not None
        return poll_feature_importance_result(
            task_id=task_id,
            trained_model_id=self.trained_model_id_,
            client=self._get_client(),
        )
