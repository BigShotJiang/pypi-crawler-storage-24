"""
NEXUS Classification estimator.

NOTE: Documentation Source for Auto-Generated SDK Reference

The docstrings and structured comments in this file are used by the
SDK documentation generator to build the official API reference.

Please do not remove or significantly alter these comments unless you
also update the documentation generation pipeline.

These comments are intentionally structured to support automated docs.
"""

import logging
from typing import Any, Literal

import numpy.typing as npt
from sklearn.base import ClassifierMixin

from fundamental.estimator.nexus_estimator import NEXUSEstimator
from fundamental.utils.data import XType

logger = logging.getLogger(__name__)


class NEXUSClassifier(ClassifierMixin, NEXUSEstimator):
    """
    Scikit-learn compatible classifier powered by Fundamental's NEXUS model.
    Supports ``fit``, ``predict``, ``predict_proba``, feature importance,
    async training via ``submit_fit_task`` / ``poll_fit_result``,
    and async prediction via ``submit_predict_task`` / ``submit_predict_proba_task``
    / ``poll_predict_result``.

    ``X`` accepts ``pandas.DataFrame`` or ``numpy.ndarray``.

    ``y`` accepts ``numpy.ndarray`` or ``pandas.Series``.

    Data must contain numeric types only - object dtypes, strings,
    mixed types, and complex numbers are not supported. Convert
    categorical data to numeric encoding before fitting.
    Missing values (NaN/null) are handled natively.

    Parameters
    ----------
    mode : "quality" | "speed", default "quality"
        Training mode. ``"quality"`` optimises for predictive performance,
        ``"speed"`` reduces training time.

    Examples
    --------
    >>> from fundamental import NEXUSClassifier
    >>> clf = NEXUSClassifier(mode="quality")
    >>> clf.fit(X_train, y_train)
    >>> predictions = clf.predict(X_test)
    """

    _task_type = "classification"  # type: ignore[assignment]

    def __init__(
        self,
        mode: Literal["quality", "speed"] = "quality",
    ):
        super().__init__(mode=mode)

    def predict_proba(self, X: XType) -> npt.NDArray[Any]:
        """
        Predict class probabilities for the given features.
        The model must be fitted first via ``fit`` or ``load_model``.
        Returns an array of shape (n_samples, n_classes) with
        probability estimates for each class.

        Parameters
        ----------
        X : XType
            Input features as numpy array or pandas DataFrame.

        Returns
        -------
        np.ndarray
            Array of shape (n_samples, n_classes) with probability
            estimates.

        Raises
        ------
        NotFittedError
            If the model has not been fitted yet.
        TypeError
            If ``X`` is not a DataFrame or ndarray.
        ValueError
            If data is empty, or feature count doesn't match
            training data.
        AuthenticationError
            If the API key is invalid or missing.
        AuthorizationError
            If the account has insufficient permissions.
        RateLimitError
            If the API rate limit was exceeded.
        ServerError
            If a server-side error occurred.
        NetworkError
            If a network connectivity issue occurred.
        RequestTimeoutError
            If the request timed out.

        Examples
        --------
        >>> probabilities = clf.predict_proba(X_test)
        """
        return self._predict(X=X, output_type="probas")

    def submit_predict_proba_task(self, X: XType) -> str:
        """
        Submit a probability prediction job without blocking.

        Returns a task ID that can be passed to ``poll_predict_result``
        to check for completion.

        Parameters
        ----------
        X : XType
            Input features as numpy array or pandas DataFrame.

        Returns
        -------
        str
            Task ID for use with ``poll_predict_result``.

        Raises
        ------
        NotFittedError
            If the model has not been fitted yet.
        TypeError
            If ``X`` is not a DataFrame or ndarray.
        ValueError
            If data is empty, or feature count doesn't match
            training data.
        AuthenticationError
            If the API key is invalid or missing.
        AuthorizationError
            If the account has insufficient permissions.
        ValidationError
            If the server rejected the request data.
        RateLimitError
            If the API rate limit was exceeded.
        ServerError
            If a server-side error occurred.
        NetworkError
            If a network connectivity issue occurred.
        RequestTimeoutError
            If the request timed out.

        Examples
        --------
        >>> task_id = clf.submit_predict_proba_task(X_test)
        """
        return self._submit_predict_task(X=X, output_type="probas")
