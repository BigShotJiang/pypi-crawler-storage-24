"""
NEXUS Regression estimator.

NOTE: Documentation Source for Auto-Generated SDK Reference

The docstrings and structured comments in this file are used by the
SDK documentation generator to build the official API reference.

Please do not remove or significantly alter these comments unless you
also update the documentation generation pipeline.

These comments are intentionally structured to support automated docs.
"""

import logging
from typing import Literal

from sklearn.base import RegressorMixin

from fundamental.estimator.nexus_estimator import NEXUSEstimator

logger = logging.getLogger(__name__)


class NEXUSRegressor(RegressorMixin, NEXUSEstimator):
    """
    Scikit-learn compatible regressor powered by Fundamental's NEXUS model.
    Supports ``fit``, ``predict``, feature importance, async training
    via ``submit_fit_task`` / ``poll_fit_result``, and async prediction
    via ``submit_predict_task`` / ``poll_predict_result``.

    ``X`` accepts ``pandas.DataFrame`` or ``numpy.ndarray``.

    ``y`` accepts ``numpy.ndarray`` or ``pandas.Series``.

    Data must contain numeric types only - object dtypes, strings,
    mixed types, and complex numbers are not supported. Convert
    categorical data to numeric encoding before fitting.
    Missing values (NaN/null) are handled natively.

    Parameters
    ----------
    mode : "quality" | "speed", default "quality"
        Training mode. ``"quality"`` optimises for predictive performance,
        ``"speed"`` reduces training time.
    time_series : bool, default False
        Enable time-series mode. When True, row ordering is preserved
        during training and prediction.

    Examples
    --------
    >>> from fundamental import NEXUSRegressor
    >>> reg = NEXUSRegressor(mode="quality")
    >>> reg.fit(X_train, y_train)
    >>> predictions = reg.predict(X_test)
    """

    _task_type = "regression"  # type: ignore[assignment]

    def __init__(
        self,
        mode: Literal["quality", "speed"] = "quality",
        time_series: bool = False,
    ):
        super().__init__(mode=mode, time_series=time_series)
