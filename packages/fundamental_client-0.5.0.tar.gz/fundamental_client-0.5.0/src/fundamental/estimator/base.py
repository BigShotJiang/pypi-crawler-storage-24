"""
Base classes for NEXUS estimators.

This module contains the abstract BaseNEXUSEstimator class that provides
common functionality for both classification and regression tasks.

NOTE: Documentation Source for Auto-Generated SDK Reference

The docstrings and structured comments in this file are used by the
SDK documentation generator to build the official API reference.

Please do not remove or significantly alter these comments unless you
also update the documentation generation pipeline.

These comments are intentionally structured to support automated docs.
"""

import logging
from abc import ABC
from typing import Any, ClassVar, Literal, Optional

import numpy.typing as npt
from sklearn.base import BaseEstimator
from sklearn.utils.validation import check_is_fitted
from typing_extensions import Self

import fundamental
from fundamental.clients import BaseClient
from fundamental.services import (
    poll_fit_result,
    poll_predict_result,
    remote_fit,
    remote_predict,
    submit_fit_task,
    submit_predict_task,
)
from fundamental.services.models import ModelsService
from fundamental.utils.data import (
    XType,
    YType,
    check_n_features_compat,
    log_dataset_info,
    validate_data,
    validate_inputs_type,
)

logger = logging.getLogger(__name__)


class BaseNEXUSEstimator(BaseEstimator, ABC):  # type: ignore[misc]
    """
    Abstract base class for NEXUS estimators.

    Provides common functionality and interface for both classification
    and regression estimators.
    """

    _task_type: ClassVar[Literal["classification", "regression"]]

    def __init__(
        self,
        mode: Literal["quality", "speed"] = "quality",
        time_series: bool = False,
    ):
        """
        Initialize the estimator.

        Parameters
        ----------
        mode : "quality" | "speed", default "quality"
            Training mode. ``"quality"`` for best performance,
            ``"speed"`` for faster training.
        time_series : bool, default False
            Enable time-series mode for regression tasks.
        """
        self.mode: Literal["quality", "speed"] = mode
        self.time_series: bool = time_series

    def _get_client(self) -> BaseClient:
        return fundamental.get_client()

    def _set_n_features_in(self, X: XType) -> None:
        """Set n_features_in_ attribute for sklearn compatibility.

        Parameters
        ----------
        X : XType
            Input features array or dataframe.
        """
        self.n_features_in_ = X.shape[1]

    def load_model(self, trained_model_id: str) -> Self:
        """
        Load a previously trained model by its ID.

        After loading, the estimator is ready for ``predict`` calls
        without retraining. Use ``trained_model_id_`` from a
        previous fit to retrieve the ID.

        Parameters
        ----------
        trained_model_id : str
            ID of the trained model to load.

        Returns
        -------
        Self
            The estimator with the loaded model, for method chaining.

        Raises
        ------
        NotFoundError
            If the model ID does not exist.
        AuthenticationError
            If the API key is invalid or missing.
        AuthorizationError
            If the account has insufficient permissions.
        ServerError
            If a server-side error occurred.
        NetworkError
            If a network connectivity issue occurred.
        RequestTimeoutError
            If the request timed out.

        Examples
        --------
        >>> estimator.load_model("model_abc123")
        """
        logger.debug("load_model: model_id=%s", trained_model_id)
        self._load_trained_model(trained_model_id)
        self.fitted_ = True
        return self

    def fit(self, X: XType, y: YType) -> Self:
        """
        Fit the model to training data. Once fitted, the estimator
        is ready for ``predict`` calls.

        Under the hood, fit submits the dataset for remote training
        and polls until the job completes. For non-blocking training,
        see ``submit_fit_task``.

        Parameters
        ----------
        X : XType
            Training features as numpy array or pandas DataFrame
            of shape (n_samples, n_features).
        y : YType
            Training targets as numpy array or pandas Series
            of shape (n_samples,).

        Returns
        -------
        Self
            The fitted estimator, for method chaining.

        Raises
        ------
        TypeError
            If ``X`` is not a DataFrame or ndarray, or ``y`` is not
            an ndarray or Series.
        ValueError
            If data is empty, or ``X`` and ``y`` have different
            number of samples.
        AuthenticationError
            If the API key is invalid or missing.
        AuthorizationError
            If the account has insufficient permissions.
        ValidationError
            If the server rejected the request data.
        RateLimitError
            If the API rate limit was exceeded.
        ServerError
            If a server-side error occurred.
        NetworkError
            If a network connectivity issue occurred.
        RequestTimeoutError
            If the request timed out.

        Examples
        --------
        >>> estimator.fit(X_train, y_train)
        """
        validate_inputs_type(X=X, y=y)
        validate_data(X=X, y=y)
        logger.debug(
            "fit: task=%s mode=%s X.shape=%s y.shape=%s",
            type(self)._task_type,
            self.mode,
            X.shape,
            y.shape,
        )
        log_dataset_info(X=X, y=y)

        response = remote_fit(
            X=X,
            y=y,
            task=type(self)._task_type,
            mode=self.mode,
            client=self._get_client(),
            time_series=self.time_series,
        )
        self._load_estimator_fields(response.estimator_fields)
        self.trained_model_id_ = response.trained_model_id
        self.fitted_ = True
        self._set_n_features_in(X)
        logger.debug("fit: completed model_id=%s", self.trained_model_id_)
        return self

    def set_attributes(
        self,
        attributes: dict[str, str],
    ) -> Self:
        """
        Set key-value metadata on a fitted model.

        Useful for tagging models with version info, ownership, or
        deployment stage. Can also be done via
        ``client.models.set_attributes``
        (see `Model Management <./model-management.md>`_).

        Parameters
        ----------
        attributes : dict[str, str]
            Key-value pairs to set.

        Returns
        -------
        Self
            Self for method chaining.

        Raises
        ------
        NotFittedError
            If the model has not been fitted yet.
        ValidationError
            If the server rejected the attributes.
        AuthenticationError
            If the API key is invalid or missing.
        AuthorizationError
            If the account has insufficient permissions.
        ServerError
            If a server-side error occurred.
        NetworkError
            If a network connectivity issue occurred.
        RequestTimeoutError
            If the request timed out.

        Examples
        --------
        >>> clf.set_attributes({"version": "1.0", "team": "ml-ops"})
        """
        logger.debug(
            "set_attributes: model_id=%s attributes=%s",
            self.trained_model_id_,
            attributes,
        )
        check_is_fitted(self)
        assert self.trained_model_id_ is not None

        models_service = ModelsService(client=self._get_client())
        models_service.set_attributes(
            model_id=self.trained_model_id_,
            attributes=attributes,
        )
        return self

    def submit_fit_task(self, X: XType, y: YType) -> str:
        """
        Submit a training job without blocking.

        Returns a task ID that can be passed to ``poll_fit_result``
        to check for completion. Use this instead of ``fit`` when you
        want to continue other work while training runs in the
        background.

        Parameters
        ----------
        X : XType
            Training features as numpy array or pandas DataFrame
            of shape (n_samples, n_features).
        y : YType
            Training targets as numpy array or pandas Series
            of shape (n_samples,).

        Returns
        -------
        str
            Task ID for use with ``poll_fit_result``.

        Raises
        ------
        TypeError
            If ``X`` is not a DataFrame or ndarray, or ``y`` is not
            an ndarray or Series.
        ValueError
            If data is empty, or ``X`` and ``y`` have different
            number of samples.
        AuthenticationError
            If the API key is invalid or missing.
        AuthorizationError
            If the account has insufficient permissions.
        ValidationError
            If the server rejected the request data.
        RateLimitError
            If the API rate limit was exceeded.
        ServerError
            If a server-side error occurred.
        NetworkError
            If a network connectivity issue occurred.
        RequestTimeoutError
            If the request timed out.

        Examples
        --------
        >>> task_id = clf.submit_fit_task(X_train, y_train)
        """
        validate_inputs_type(X=X, y=y)
        validate_data(X=X, y=y)
        logger.debug(
            "submit_fit_task: task=%s mode=%s X.shape=%s",
            type(self)._task_type,
            self.mode,
            X.shape,
        )
        log_dataset_info(X=X, y=y)
        return submit_fit_task(
            X=X,
            y=y,
            task=type(self)._task_type,
            mode=self.mode,
            client=self._get_client(),
            time_series=self.time_series,
        )

    def poll_fit_result(self, task_id: str) -> Optional[Self]:
        """
        Check if a training job has completed.

        Returns ``self`` when training is done (the estimator is now
        fitted and ready for predictions), or ``None`` if still in
        progress.

        Task IDs are portable - you can save a task ID and poll from
        a different session or even a different process.
        This makes it easy to submit a training job in one session
        and check on it later.

        Task status is available for up to 48 hours after submission.

        Parameters
        ----------
        task_id : str
            Task ID from ``submit_fit_task``.

        Returns
        -------
        Optional[Self]
            Self if training is complete, None if still in progress.

        Raises
        ------
        AuthenticationError
            If the API key is invalid or missing.
        AuthorizationError
            If the account has insufficient permissions.
        ValidationError
            If training failed server-side validation.
        ServerError
            If a server-side error occurred.
        NetworkError
            If a network connectivity issue occurred.
        RequestTimeoutError
            If the request timed out.

        Examples
        --------
        >>> result = clf.poll_fit_result(task_id)
        """
        logger.debug("poll_fit_result: task_id=%s", task_id)
        result = poll_fit_result(
            task_id=task_id,
            client=self._get_client(),
        )
        if result is not None:
            self._load_estimator_fields(result.estimator_fields)
            self.trained_model_id_ = result.trained_model_id
            self.fitted_ = True
            logger.debug("poll_fit_result: task_id=%s completed", task_id)
            return self
        logger.debug("poll_fit_result: task_id=%s still in progress", task_id)
        return None

    def predict(self, X: XType) -> npt.NDArray[Any]:
        """
        Generate predictions for the given features.

        The model must be fitted first via ``fit`` or ``load_model``.

        Parameters
        ----------
        X : XType
            Input features as numpy array or pandas DataFrame.

        Returns
        -------
        np.ndarray
            Predicted values or class labels.

        Raises
        ------
        NotFittedError
            If the model has not been fitted yet.
        TypeError
            If ``X`` is not a DataFrame or ndarray.
        ValueError
            If data is empty, or feature count doesn't match
            training data.
        AuthenticationError
            If the API key is invalid or missing.
        AuthorizationError
            If the account has insufficient permissions.
        RateLimitError
            If the API rate limit was exceeded.
        ServerError
            If a server-side error occurred.
        NetworkError
            If a network connectivity issue occurred.
        RequestTimeoutError
            If the request timed out.

        Examples
        --------
        >>> predictions = estimator.predict(X_test)
        """
        return self._predict(X=X, output_type="preds")

    def _predict(
        self,
        X: XType,
        output_type: Literal["preds", "probas"],
    ) -> npt.NDArray[Any]:
        """Internal prediction method with configurable output type."""
        validate_inputs_type(X=X)
        validate_data(X=X)
        logger.debug(
            "predict: model_id=%s output_type=%s X.shape=%s",
            getattr(self, "trained_model_id_", None),
            output_type,
            X.shape,
        )
        log_dataset_info(X=X)
        check_is_fitted(self)

        # Validate n_features_in_ for sklearn compatibility
        check_n_features_compat(self, X, reset=False)

        assert self.trained_model_id_ is not None
        return remote_predict(
            X=X,
            output_type=output_type,
            trained_model_id=self.trained_model_id_,
            client=self._get_client(),
        )

    def submit_predict_task(self, X: XType) -> str:
        """
        Submit a prediction job without blocking.

        Returns a task ID that can be passed to ``poll_predict_result``
        to check for completion. Use this instead of ``predict`` when you
        want to continue other work while prediction runs in the background.

        The task ID can be polled from a different session or
        process - just load the same model via ``load_model`` first.

        Parameters
        ----------
        X : XType
            Input features as numpy array or pandas DataFrame
            of shape (n_samples, n_features).

        Returns
        -------
        str
            Task ID for use with ``poll_predict_result``.

        Raises
        ------
        NotFittedError
            If the model has not been fitted yet.
        TypeError
            If ``X`` is not a DataFrame or ndarray.
        ValueError
            If data is empty, or feature count doesn't match
            training data.
        AuthenticationError
            If the API key is invalid or missing.
        AuthorizationError
            If the account has insufficient permissions.
        ValidationError
            If the server rejected the request data.
        RateLimitError
            If the API rate limit was exceeded.
        ServerError
            If a server-side error occurred.
        NetworkError
            If a network connectivity issue occurred.
        RequestTimeoutError
            If the request timed out.

        Examples
        --------
        >>> task_id = clf.submit_predict_task(X_test)
        """
        return self._submit_predict_task(X=X, output_type="preds")

    def _submit_predict_task(
        self,
        X: XType,
        output_type: Literal["preds", "probas"],
    ) -> str:
        """Internal predict submission with configurable output type."""
        validate_inputs_type(X=X)
        validate_data(X=X)
        logger.debug(
            "submit_predict_task: model_id=%s output_type=%s X.shape=%s",
            getattr(self, "trained_model_id_", None),
            output_type,
            X.shape,
        )
        log_dataset_info(X=X)
        check_is_fitted(self)
        check_n_features_compat(self, X, reset=False)

        assert self.trained_model_id_ is not None
        return submit_predict_task(
            X=X,
            output_type=output_type,
            trained_model_id=self.trained_model_id_,
            client=self._get_client(),
        )

    def poll_predict_result(self, task_id: str) -> Optional[npt.NDArray[Any]]:
        """
        Check if a prediction job has completed.

        Returns the prediction results when done, or ``None`` if still
        in progress.

        Task IDs are portable - you can save a task ID and poll from
        a different session or even a different process.
        Just load the same model via ``load_model`` first so that
        ``trained_model_id_`` is available. Task status is available
        for up to 48 hours after submission.

        Parameters
        ----------
        task_id : str
            Task ID from ``submit_predict_task``.

        Returns
        -------
        Optional[np.ndarray]
            Prediction results if complete, None if still in progress.

        Raises
        ------
        AuthenticationError
            If the API key is invalid or missing.
        AuthorizationError
            If the account has insufficient permissions.
        ServerError
            If a server-side error occurred.
        NetworkError
            If a network connectivity issue occurred.
        RequestTimeoutError
            If the request timed out.

        Examples
        --------
        >>> result = clf.poll_predict_result(task_id)
        """
        logger.debug("poll_predict_result: task_id=%s", task_id)
        check_is_fitted(self)
        assert self.trained_model_id_ is not None
        result = poll_predict_result(
            task_id=task_id,
            trained_model_id=self.trained_model_id_,
            client=self._get_client(),
        )
        if result is not None:
            logger.debug("poll_predict_result: task_id=%s completed", task_id)
            return result
        logger.debug("poll_predict_result: task_id=%s still in progress", task_id)
        return None

    def _load_trained_model(self, model_id: str) -> None:
        try:
            models_service = ModelsService(client=self._get_client())
            response = models_service.load(
                trained_model_id=model_id,
            )
            self._load_estimator_fields(response.estimator_fields)
            self.trained_model_id_ = model_id
        except Exception as e:
            logger.error(f"Failed to load model {model_id}: {e}")
            raise e

    def _load_estimator_fields(self, estimator_fields: dict[str, Any]) -> None:
        logger.debug(
            "Loading %d estimator fields: %s",
            len(estimator_fields),
            list(estimator_fields.keys()),
        )
        for field, value in estimator_fields.items():
            try:
                # Keep private attrs as-is, add underscore to public attrs (sklearn convention)
                field_name = field if field.endswith("_") or field.startswith("_") else f"{field}_"
                setattr(self, field_name, value)
            except AttributeError:
                logger.warning(f"Field {field} is not a valid attribute in the current estimator")
