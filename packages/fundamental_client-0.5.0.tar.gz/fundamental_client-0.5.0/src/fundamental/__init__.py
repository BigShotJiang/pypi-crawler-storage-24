"""
Fundamental Python SDK for tabular machine learning.

NOTE: Documentation Source for Auto-Generated SDK Reference

The docstrings and structured comments in this file are used by the
SDK documentation generator to build the official API reference.

Please do not remove or significantly alter these comments unless you
also update the documentation generation pipeline.

These comments are intentionally structured to support automated docs.
"""

from importlib.metadata import PackageNotFoundError, version
from typing import Optional

from fundamental.clients import BaseClient, Fundamental, FundamentalAWSMarketplaceClient

# Deprecated aliases
from fundamental.deprecated import FTMClassifier, FTMRegressor
from fundamental.estimator import NEXUSClassifier, NEXUSRegressor

try:
    # Distribution name on PyPI is `fundamental-client` (import name is `fundamental`).
    __version__ = version("fundamental-client")
except PackageNotFoundError:  # pragma: no cover
    __version__ = "unknown"

_global_client: Optional[BaseClient] = None


def set_client(client: BaseClient) -> None:
    """
    Register a client as the global default for all estimators.

    Parameters
    ----------
    client : BaseClient
        Client instance (e.g. ``Fundamental`` or ``FundamentalAWSMarketplaceClient``).

    Returns
    -------
    None

    Examples
    --------
    >>> from fundamental import Fundamental, set_client
    >>> set_client(Fundamental(api_key="your-api-key"))
    """
    global _global_client
    _global_client = client


def get_client() -> BaseClient:
    """
    If no client has been set via :func:`set_client`, creates and returns
    a default ``Fundamental()`` instance.

    Returns
    -------
    BaseClient
        The current global client.
    """
    return _global_client or Fundamental()


__all__ = [
    "FTMClassifier",
    "FTMRegressor",
    "Fundamental",
    "FundamentalAWSMarketplaceClient",
    "NEXUSClassifier",
    "NEXUSRegressor",
    "diagnostics",
    "get_client",
    "set_client",
]
