from setuptools import setup, find_packages

setup(
    name="dataset-download-sdk",
    version="0.1.0",
    description="SDK for downloading datasets from OSS with server-managed credentials",
    packages=find_packages(),
    python_requires=">=3.7",
    install_requires=[
        "requests>=2.20.0",
        "PyJWT>=2.0.0",
    ],
)
