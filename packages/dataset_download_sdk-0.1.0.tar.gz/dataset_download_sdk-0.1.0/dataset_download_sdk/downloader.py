import os
import shutil
import subprocess
import logging

from .models import OSSCredential
from .exceptions import DownloadError
from .config import SDKConfig

logger = logging.getLogger(__name__)


def _find_ossutil() -> str:
    """Find ossutil binary in PATH."""
    for name in ("ossutil", "ossutil64"):
        path = shutil.which(name)
        if path:
            return path
    raise DownloadError(
        "ossutil not found in PATH. "
        "Please install ossutil: https://help.aliyun.com/document_detail/120075.html"
    )


class OSSDownloader:
    """Downloads files/directories from OSS using ossutil command."""

    def __init__(self, credential: OSSCredential, config: SDKConfig):
        self._credential = credential
        self._config = config
        self._ossutil = config.ossutil_path or _find_ossutil()

    def _base_args(self) -> list:
        return [
            self._ossutil,
            "--access-key-id", self._credential.access_key_id,
            "--access-key-secret", self._credential.access_key_secret,
            "--endpoint", self._credential.endpoint,
        ]

    def _oss_url(self, path: str) -> str:
        bucket = self._credential.bucket
        path = path.lstrip("/")
        return f"oss://{bucket}/{path}"

    def download(self, oss_path: str, local_path: str):
        """Download a file or directory from OSS.

        Automatically detects whether oss_path is a directory (ends with /)
        or a single file, and uses the appropriate ossutil command.

        Args:
            oss_path: OSS object key or prefix.
                      Directory: "datasets/xxx/" (trailing slash)
                      File:      "datasets/xxx/train.csv"
            local_path: Local path to save to.
        """
        is_directory = oss_path.endswith("/")

        if is_directory:
            self._sync_directory(oss_path, local_path)
        else:
            self._download_file(oss_path, local_path)

    def _sync_directory(self, oss_prefix: str, local_dir: str):
        os.makedirs(local_dir, exist_ok=True)
        oss_url = self._oss_url(oss_prefix)

        cmd = self._base_args() + [
            "sync", oss_url, local_dir,
            "--jobs", str(self._config.jobs),
            "--parallel", str(self._config.parallel),
        ]

        logger.info(f"Syncing directory: {oss_url} -> {local_dir}")
        self._run(cmd)

    def _download_file(self, file_key: str, local_path: str):
        os.makedirs(os.path.dirname(local_path) or ".", exist_ok=True)
        oss_url = self._oss_url(file_key)

        cmd = self._base_args() + [
            "cp", oss_url, local_path,
            "--jobs", str(self._config.jobs),
            "--parallel", str(self._config.parallel),
        ]

        logger.info(f"Downloading file: {oss_url} -> {local_path}")
        self._run(cmd)

    def _run(self, cmd: list):
        """Execute ossutil command, streaming output in real time."""
        logger.debug(f"Command: {' '.join(cmd)}")
        try:
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
            )
            for line in process.stdout:
                line = line.rstrip()
                if line:
                    print(line)
            returncode = process.wait()
            if returncode != 0:
                raise DownloadError(f"ossutil exited with code {returncode}")
        except FileNotFoundError:
            raise DownloadError(
                f"ossutil binary not found at: {cmd[0]}. "
                "Please install ossutil."
            )
