import logging
from typing import Optional

import jwt

from .config import SDKConfig
from .credential import CredentialProvider
from .downloader import OSSDownloader
from .exceptions import DatasetSDKError

logger = logging.getLogger(__name__)

JWT_ALGORITHM = "HS256"


class DatasetClient:
    """Dataset Download SDK.

    Usage:
        client = DatasetClient(
            server_url="https://data-api.example.com",
            token=jwt_token,
            secret="your-jwt-secret",
        )
        client.download_dataset(local_dir="./my_dataset/")
    """

    def __init__(
        self,
        server_url: str,
        token: str,
        secret: str,
        jobs: int = 20,
        parallel: int = 10,
        timeout: int = 30,
        ossutil_path: Optional[str] = None,
    ):
        self._token = token
        self._oss_path, self._rename = self._decode_token(token, secret)

        self._config = SDKConfig(
            server_url=server_url,
            token=token,
            timeout=timeout,
            jobs=jobs,
            parallel=parallel,
            ossutil_path=ossutil_path,
        )
        self._credential_provider = CredentialProvider(self._config)

    @staticmethod
    def _decode_token(token: str, secret: str) -> tuple:
        try:
            payload = jwt.decode(token, secret, algorithms=[JWT_ALGORITHM])
            return payload["sub"], payload.get("renameFileName")
        except jwt.ExpiredSignatureError:
            raise DatasetSDKError("Token expired")
        except jwt.InvalidTokenError:
            raise DatasetSDKError("Invalid token")

    def download_dataset(self, local_dir: str):
        """Download dataset to local directory.

        The OSS path is derived from the JWT token.
        Supports both single file and directory.

        Args:
            local_dir: Local directory to save files into.
        """
        logger.info(f"OSS path: {self._oss_path}")
        logger.info("Fetching OSS credentials...")
        credential = self._credential_provider.get_credential()

        downloader = OSSDownloader(credential, self._config)
        downloader.download(self._oss_path, local_dir)
        logger.info(f"Download completed: {local_dir}")
