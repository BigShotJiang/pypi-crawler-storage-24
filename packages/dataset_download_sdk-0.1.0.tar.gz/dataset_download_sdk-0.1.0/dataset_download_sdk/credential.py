import requests
from .config import SDKConfig
from .models import OSSCredential
from .exceptions import CredentialError, ServerError


class CredentialProvider:
    """Fetches OSS credentials from the server.

    Server API contract:
        POST {server_url}/api/v1/credentials
        Headers: Authorization: Bearer {token}
        Response: {
            "code": 0,
            "data": {
                "access_key_id": "...",
                "access_key_secret": "...",
                "endpoint": "https://oss-cn-hangzhou.aliyuncs.com"
            }
        }
    """

    def __init__(self, config: SDKConfig):
        self._config = config
        self._session = requests.Session()
        self._session.headers.update({
            "Authorization": f"Bearer {config.token}",
            "Content-Type": "application/json",
        })

    def get_credential(self) -> OSSCredential:
        url = f"{self._config.server_url}/api/v1/credentials"
        try:
            resp = self._session.post(url, timeout=self._config.timeout)
        except requests.RequestException as e:
            raise CredentialError(f"Failed to connect to server: {e}")

        if resp.status_code != 200:
            raise ServerError(resp.status_code, resp.text)

        data = resp.json()
        if data.get("code") != 0:
            raise CredentialError(
                f"Server returned error: {data.get('message', 'unknown error')}"
            )

        cred_data = data["data"]
        return OSSCredential(
            access_key_id=cred_data["access_key_id"],
            access_key_secret=cred_data["access_key_secret"],
            endpoint=cred_data["endpoint"],
            bucket="inspire-alluxio-prod",
        )
