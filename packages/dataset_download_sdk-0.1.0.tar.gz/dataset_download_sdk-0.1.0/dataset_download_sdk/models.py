from dataclasses import dataclass


@dataclass
class OSSCredential:
    access_key_id: str
    access_key_secret: str
    endpoint: str
    bucket: str
