from dataclasses import dataclass
from typing import Optional


@dataclass
class SDKConfig:
    server_url: str
    token: str
    timeout: int = 30  # HTTP request timeout in seconds
    max_retries: int = 3
    jobs: int = 20  # ossutil --jobs, number of concurrent file operations
    parallel: int = 10  # ossutil --parallel, number of parts per file
    ossutil_path: Optional[str] = None  # custom ossutil binary path

    def __post_init__(self):
        self.server_url = self.server_url.rstrip("/")
