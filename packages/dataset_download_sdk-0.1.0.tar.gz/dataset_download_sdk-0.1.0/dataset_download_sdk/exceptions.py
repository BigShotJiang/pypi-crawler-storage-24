class DatasetSDKError(Exception):
    """Base exception for Dataset Download SDK."""
    pass


class CredentialError(DatasetSDKError):
    """Failed to fetch credentials from server."""
    pass


class DownloadError(DatasetSDKError):
    """Error during file download."""
    pass


class ServerError(DatasetSDKError):
    """Server returned an error response."""

    def __init__(self, status_code: int, message: str):
        self.status_code = status_code
        super().__init__(f"Server error ({status_code}): {message}")
