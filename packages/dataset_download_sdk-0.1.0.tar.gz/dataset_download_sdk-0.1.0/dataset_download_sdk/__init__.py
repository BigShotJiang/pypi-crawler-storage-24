"""Dataset Download SDK - Download datasets from OSS via secure credential server."""

from .client import DatasetClient
from .config import SDKConfig
from .exceptions import DatasetSDKError, CredentialError, DownloadError, ServerError

__version__ = "0.1.0"

__all__ = [
    "DatasetClient",
    "SDKConfig",
    "DatasetSDKError",
    "CredentialError",
    "DownloadError",
    "ServerError",
]
