# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class FlavorRespVersionBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'id': 'str',
        'name': 'str',
        'flavors': 'list[Flavor]'
    }

    attribute_map = {
        'id': 'id',
        'name': 'name',
        'flavors': 'flavors'
    }

    def __init__(self, id=None, name=None, flavors=None):
        r"""FlavorRespVersionBody

        The model defined in huaweicloud sdk

        :param id: **参数解释**： 版本id。 **取值范围**： 不涉及
        :type id: str
        :param name: **参数解释**： 版本名称。 **取值范围**： 不涉及
        :type name: str
        :param flavors: **参数解释**： 规格信息。 **取值范围**： 不涉及
        :type flavors: list[:class:`huaweicloudsdkcss.v1.Flavor`]
        """
        
        

        self._id = None
        self._name = None
        self._flavors = None
        self.discriminator = None

        if id is not None:
            self.id = id
        if name is not None:
            self.name = name
        if flavors is not None:
            self.flavors = flavors

    @property
    def id(self):
        r"""Gets the id of this FlavorRespVersionBody.

        **参数解释**： 版本id。 **取值范围**： 不涉及

        :return: The id of this FlavorRespVersionBody.
        :rtype: str
        """
        return self._id

    @id.setter
    def id(self, id):
        r"""Sets the id of this FlavorRespVersionBody.

        **参数解释**： 版本id。 **取值范围**： 不涉及

        :param id: The id of this FlavorRespVersionBody.
        :type id: str
        """
        self._id = id

    @property
    def name(self):
        r"""Gets the name of this FlavorRespVersionBody.

        **参数解释**： 版本名称。 **取值范围**： 不涉及

        :return: The name of this FlavorRespVersionBody.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        r"""Sets the name of this FlavorRespVersionBody.

        **参数解释**： 版本名称。 **取值范围**： 不涉及

        :param name: The name of this FlavorRespVersionBody.
        :type name: str
        """
        self._name = name

    @property
    def flavors(self):
        r"""Gets the flavors of this FlavorRespVersionBody.

        **参数解释**： 规格信息。 **取值范围**： 不涉及

        :return: The flavors of this FlavorRespVersionBody.
        :rtype: list[:class:`huaweicloudsdkcss.v1.Flavor`]
        """
        return self._flavors

    @flavors.setter
    def flavors(self, flavors):
        r"""Sets the flavors of this FlavorRespVersionBody.

        **参数解释**： 规格信息。 **取值范围**： 不涉及

        :param flavors: The flavors of this FlavorRespVersionBody.
        :type flavors: list[:class:`huaweicloudsdkcss.v1.Flavor`]
        """
        self._flavors = flavors

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, FlavorRespVersionBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
