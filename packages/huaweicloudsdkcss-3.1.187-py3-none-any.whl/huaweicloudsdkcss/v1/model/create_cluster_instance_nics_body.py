# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CreateClusterInstanceNicsBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'vpc_id': 'str',
        'net_id': 'str',
        'security_group_id': 'str'
    }

    attribute_map = {
        'vpc_id': 'vpcId',
        'net_id': 'netId',
        'security_group_id': 'securityGroupId'
    }

    def __init__(self, vpc_id=None, net_id=None, security_group_id=None):
        r"""CreateClusterInstanceNicsBody

        The model defined in huaweicloud sdk

        :param vpc_id: 指定虚拟私有云ID，用于集群网络配置。
        :type vpc_id: str
        :param net_id: 子网ID(网络ID)。
        :type net_id: str
        :param security_group_id: 安全组ID。
        :type security_group_id: str
        """
        
        

        self._vpc_id = None
        self._net_id = None
        self._security_group_id = None
        self.discriminator = None

        self.vpc_id = vpc_id
        self.net_id = net_id
        self.security_group_id = security_group_id

    @property
    def vpc_id(self):
        r"""Gets the vpc_id of this CreateClusterInstanceNicsBody.

        指定虚拟私有云ID，用于集群网络配置。

        :return: The vpc_id of this CreateClusterInstanceNicsBody.
        :rtype: str
        """
        return self._vpc_id

    @vpc_id.setter
    def vpc_id(self, vpc_id):
        r"""Sets the vpc_id of this CreateClusterInstanceNicsBody.

        指定虚拟私有云ID，用于集群网络配置。

        :param vpc_id: The vpc_id of this CreateClusterInstanceNicsBody.
        :type vpc_id: str
        """
        self._vpc_id = vpc_id

    @property
    def net_id(self):
        r"""Gets the net_id of this CreateClusterInstanceNicsBody.

        子网ID(网络ID)。

        :return: The net_id of this CreateClusterInstanceNicsBody.
        :rtype: str
        """
        return self._net_id

    @net_id.setter
    def net_id(self, net_id):
        r"""Sets the net_id of this CreateClusterInstanceNicsBody.

        子网ID(网络ID)。

        :param net_id: The net_id of this CreateClusterInstanceNicsBody.
        :type net_id: str
        """
        self._net_id = net_id

    @property
    def security_group_id(self):
        r"""Gets the security_group_id of this CreateClusterInstanceNicsBody.

        安全组ID。

        :return: The security_group_id of this CreateClusterInstanceNicsBody.
        :rtype: str
        """
        return self._security_group_id

    @security_group_id.setter
    def security_group_id(self, security_group_id):
        r"""Sets the security_group_id of this CreateClusterInstanceNicsBody.

        安全组ID。

        :param security_group_id: The security_group_id of this CreateClusterInstanceNicsBody.
        :type security_group_id: str
        """
        self._security_group_id = security_group_id

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CreateClusterInstanceNicsBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
