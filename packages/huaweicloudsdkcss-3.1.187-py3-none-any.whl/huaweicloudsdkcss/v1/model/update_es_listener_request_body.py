# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class UpdateEsListenerRequestBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'listener': 'EsListenerRequest',
        'type': 'str'
    }

    attribute_map = {
        'listener': 'listener',
        'type': 'type'
    }

    def __init__(self, listener=None, type=None):
        r"""UpdateEsListenerRequestBody

        The model defined in huaweicloud sdk

        :param listener: 
        :type listener: :class:`huaweicloudsdkcss.v1.EsListenerRequest`
        :param type: 类型：searchTool 表示修改Elasticsearch/Opensearch负载均衡器，viewTool 表示修改Kibana/Opensearch Dashboard 负载均衡器，默认为searchTool 。
        :type type: str
        """
        
        

        self._listener = None
        self._type = None
        self.discriminator = None

        self.listener = listener
        if type is not None:
            self.type = type

    @property
    def listener(self):
        r"""Gets the listener of this UpdateEsListenerRequestBody.

        :return: The listener of this UpdateEsListenerRequestBody.
        :rtype: :class:`huaweicloudsdkcss.v1.EsListenerRequest`
        """
        return self._listener

    @listener.setter
    def listener(self, listener):
        r"""Sets the listener of this UpdateEsListenerRequestBody.

        :param listener: The listener of this UpdateEsListenerRequestBody.
        :type listener: :class:`huaweicloudsdkcss.v1.EsListenerRequest`
        """
        self._listener = listener

    @property
    def type(self):
        r"""Gets the type of this UpdateEsListenerRequestBody.

        类型：searchTool 表示修改Elasticsearch/Opensearch负载均衡器，viewTool 表示修改Kibana/Opensearch Dashboard 负载均衡器，默认为searchTool 。

        :return: The type of this UpdateEsListenerRequestBody.
        :rtype: str
        """
        return self._type

    @type.setter
    def type(self, type):
        r"""Sets the type of this UpdateEsListenerRequestBody.

        类型：searchTool 表示修改Elasticsearch/Opensearch负载均衡器，viewTool 表示修改Kibana/Opensearch Dashboard 负载均衡器，默认为searchTool 。

        :param type: The type of this UpdateEsListenerRequestBody.
        :type type: str
        """
        self._type = type

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, UpdateEsListenerRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
