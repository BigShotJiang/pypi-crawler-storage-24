#!/usr/bin/env python3
"""
axel/server.py  —  AXEL Network Server v2.1
════════════════════════════════════════════
The central hub of the AXEL distributed agent network.
Any LLM that can make HTTP requests can join and communicate.

Usage:
    axel-server                               # 0.0.0.0:7331
    axel-server --port 8080                   # custom port
    axel-server --key mysecret                # enable API-key auth
    axel-server --db axel.db                  # enable SQLite persistence

REST API:
    POST /agents/announce                     register agent
    GET  /agents                              list agents (with online status)
    GET  /agents/{id}                         agent detail
    GET  /discover?cap=...                    find best agent for a capability
    GET  /discover/{action}                   (legacy alias)

    POST /send                                send AXEL message
    GET  /inbox/{agent_id}?timeout=N          long-poll (max 30s)
    GET  /inbox/{agent_id}/all                drain inbox

    POST /execute                             route TK/CH to LLM
    POST /adapters/mock                       attach mock adapter
    POST /adapters/ollama                     attach Ollama adapter
    POST /adapters/anthropic                  attach Anthropic adapter
    POST /adapters/openai                     attach OpenAI adapter
    POST /adapters/gemini                     attach Google Gemini adapter
    POST /adapters/mistral                    attach Mistral AI adapter
    POST /adapters/groq                       attach Groq adapter
    POST /adapters/together                   attach Together AI adapter
    POST /adapters/cohere                     attach Cohere adapter
    GET  /adapters                            list all registered adapters

    GET  /memory?top=N                        list lessons
    GET  /memory/search?q=...&n=N             BM25 search
    POST /memory/write                        write lesson
    POST /memory/decay                        apply decay + prune

    POST /channels/subscribe                  pub/sub subscribe
    POST /channels/publish                    pub/sub publish
    GET  /channels                            list channels

    GET  /status                              network overview (includes auth/db flags)
    GET  /stream                              SSE live event stream
    GET  /ui                                  browser dashboard
    GET  /                                    server info

Auth (optional):
    Start server with --key <secret> (or AXEL_KEY env var).
    Clients must send:  X-AXEL-Key: <secret>
    Exempt routes (no key needed): GET /, GET /status, GET /ui, GET /stream
"""

import argparse
import json
import os
import queue
import sys
import threading
import time
import uuid
from collections import defaultdict
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

# ── FastAPI (auto-install if missing) ─────────────────────────────
try:
    from fastapi import FastAPI, HTTPException, Query, Request, Depends
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import StreamingResponse, JSONResponse, HTMLResponse
    import uvicorn
except ImportError:
    import subprocess
    print("  Installing FastAPI + uvicorn…")
    subprocess.check_call([
        sys.executable, "-m", "pip", "install",
        "fastapi", "uvicorn[standard]", "--break-system-packages", "-q"
    ])
    from fastapi import FastAPI, HTTPException, Query, Request, Depends
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import StreamingResponse, JSONResponse, HTMLResponse
    import uvicorn

# ── AXEL imports ──────────────────────────────────────────────────
_HERE = Path(__file__).parent
sys.path.insert(0, str(_HERE))
from axel.core import AXELMessage, AXELBuilder
from axel.universal import (
    AXELRegistry, SmartMemory, AXELBridge, AgentRecord,
    MockAdapter, OllamaAdapter, AnthropicAdapter, OpenAIAdapter,
    make_system_prompt, AXEL_HOME, MsgTypeV2,
)

# ══════════════════════════════════════════════════════════════════
# Data Structures
# ══════════════════════════════════════════════════════════════════

@dataclass
class QueuedMessage:
    msg: dict
    queued_at: float = field(default_factory=time.time)
    uid: str = field(default_factory=lambda: uuid.uuid4().hex[:8])


@dataclass
class ChannelSub:
    agent_id: str
    channel: str
    filter_: dict = field(default_factory=dict)


@dataclass
class ServerEvent:
    event: str
    data: dict
    ts: float = field(default_factory=time.time)


# ══════════════════════════════════════════════════════════════════
# Per-Agent Inbox  (thread-safe long-pollable queue)
# ══════════════════════════════════════════════════════════════════

class AgentInbox:
    def __init__(self):
        self._q: queue.Queue = queue.Queue()

    def put(self, msg_dict: dict) -> str:
        qm = QueuedMessage(msg=msg_dict)
        self._q.put(qm)
        return qm.uid

    def poll(self, timeout: float = 5.0) -> Optional[dict]:
        """Block up to `timeout` seconds; return message or None."""
        try:
            qm = self._q.get(timeout=timeout)
            return qm.msg
        except queue.Empty:
            return None

    def drain(self) -> List[dict]:
        msgs = []
        while True:
            try:
                qm = self._q.get_nowait()
                msgs.append(qm.msg)
            except queue.Empty:
                break
        return msgs

    def depth(self) -> int:
        return self._q.qsize()


# ══════════════════════════════════════════════════════════════════
# Pub/Sub
# ══════════════════════════════════════════════════════════════════

class AXELPubSub:
    def __init__(self):
        self._subs: Dict[str, List[ChannelSub]] = defaultdict(list)
        self._lock = threading.Lock()

    def subscribe(self, agent_id: str, channel: str, filter_: dict = None):
        with self._lock:
            self._subs[channel] = [
                s for s in self._subs[channel] if s.agent_id != agent_id
            ]
            self._subs[channel].append(ChannelSub(agent_id, channel, filter_ or {}))

    def unsubscribe(self, agent_id: str, channel: str):
        with self._lock:
            self._subs[channel] = [
                s for s in self._subs[channel] if s.agent_id != agent_id
            ]

    def matching_subscribers(self, channel: str, event: dict) -> List[str]:
        with self._lock:
            result = []
            for sub in self._subs.get(channel, []):
                if all(event.get(k) == v for k, v in sub.filter_.items()):
                    result.append(sub.agent_id)
            return result

    def channel_list(self) -> dict:
        with self._lock:
            return {ch: [s.agent_id for s in subs]
                    for ch, subs in self._subs.items()}


# ══════════════════════════════════════════════════════════════════
# SSE Event Bus
# ══════════════════════════════════════════════════════════════════

class EventBus:
    def __init__(self, max_history: int = 200):
        self._clients: List[queue.Queue] = []
        self._history: List[ServerEvent] = []
        self._max = max_history
        self._lock = threading.Lock()

    def publish(self, event_type: str, data: dict):
        ev = ServerEvent(event=event_type, data=data)
        with self._lock:
            self._history.append(ev)
            if len(self._history) > self._max:
                self._history.pop(0)
            for q in self._clients:
                try:
                    q.put_nowait(ev)
                except queue.Full:
                    pass

    def new_client(self) -> queue.Queue:
        q: queue.Queue = queue.Queue(maxsize=100)
        with self._lock:
            self._clients.append(q)
        return q

    def remove_client(self, q: queue.Queue):
        with self._lock:
            try:
                self._clients.remove(q)
            except ValueError:
                pass

    def recent(self, n: int = 50) -> List[ServerEvent]:
        with self._lock:
            return list(self._history[-n:])


# ══════════════════════════════════════════════════════════════════
# Execution Engine  (routes TK / CH to real LLM adapters)
# ══════════════════════════════════════════════════════════════════

class AXELExecutor:
    def __init__(self, registry, memory, bridge, event_bus, inboxes):
        self.registry = registry
        self.memory = memory
        self.bridge = bridge
        self.event_bus = event_bus
        self.inboxes = inboxes  # agent_id → AgentInbox

    # ── single task ──────────────────────────────────────────────
    def execute_task(self, msg_dict: dict) -> dict:
        try:
            msg = AXELMessage.from_dict(msg_dict)
        except Exception as e:
            return self._err(msg_dict, f"Invalid AXEL: {e}")

        self.event_bus.publish("task.started", {
            "fr": msg.fr, "to": msg.to,
            "act": msg.body.get("act"), "id": msg.id,
        })

        result = self.bridge.execute(msg)
        result_dict = result.to_dict()

        self.event_bus.publish("task.completed", {
            "fr": result.fr, "to": result.to,
            "success": result.t == "OK", "reply_to": msg.id,
        })

        # Deliver result to sender's inbox if connected
        if msg.fr in self.inboxes:
            self.inboxes[msg.fr].put(result_dict)

        return result_dict

    # ── chain pipeline ───────────────────────────────────────────
    def execute_chain(self, chain_dict: dict) -> List[dict]:
        try:
            chain = AXELMessage.from_dict(chain_dict)
        except Exception as e:
            return [self._err(chain_dict, f"Invalid CHAIN: {e}")]

        steps = chain.body.get("steps", [])
        ctx = dict(chain.body.get("ctx", {}))
        stop_on_err = chain.body.get("stop_on_error", True)
        results = []
        prev = None

        self.event_bus.publish("chain.started", {
            "steps": len(steps), "fr": chain.fr, "cid": chain.cid,
        })

        for i, step in enumerate(steps):
            if prev is not None:
                ctx["prev_result"] = prev

            builder = AXELBuilder(chain.fr, chain.cid)
            tk = builder.task(
                to=step.get("to", "*"),
                action=step.get("act", "unknown"),
                args=step.get("args", {}),
                ctx=ctx,
            )
            self.event_bus.publish("chain.step", {
                "step": i + 1, "total": len(steps),
                "to": step.get("to"), "act": step.get("act"),
            })

            res = self.execute_task(tk.to_dict())
            results.append(res)

            if res.get("t") == "ER" and stop_on_err:
                self.event_bus.publish("chain.failed", {
                    "step": i + 1,
                    "reason": res.get("body", {}).get("msg"),
                })
                break

            prev = res.get("body", {}).get("result")

        self.event_bus.publish("chain.completed", {
            "steps_run": len(results), "cid": chain.cid,
        })
        return results

    def _err(self, original: dict, reason: str) -> dict:
        return {
            "v": "2", "t": "ER",
            "id": f"msg_{uuid.uuid4().hex[:12]}",
            "cid": original.get("cid", ""),
            "fr": "server", "to": original.get("fr", "unknown"),
            "ts": int(time.time() * 1000), "pri": 3,
            "body": {"code": "INTERNAL", "msg": reason, "retry": False},
        }


# ══════════════════════════════════════════════════════════════════
# AXELServer  —  the FastAPI application
# ══════════════════════════════════════════════════════════════════

class AXELServer:
    # Routes that never require auth (even when key is set)
    _AUTH_EXEMPT = {"/", "/status", "/ui", "/stream", "/docs",
                    "/openapi.json", "/redoc"}
    # How long (seconds) before an agent is considered offline
    LIVENESS_TTL = 90

    def __init__(
        self,
        host: str = "0.0.0.0",
        port: int = 7331,
        key: Optional[str] = None,
        db: Optional[str] = None,
    ):
        self.host = host
        self.port = port
        # Auth key (None = disabled)
        self.key: Optional[str] = key or os.environ.get("AXEL_KEY") or None
        # Optional SQLite persistence
        self.db_path: Optional[str] = db or os.environ.get("AXEL_DB") or None
        self.persistence = None
        if self.db_path:
            from axel.persistence import PersistenceLayer
            self.persistence = PersistenceLayer(self.db_path)

        self.registry = AXELRegistry()
        self.memory = SmartMemory()
        self.bridge = AXELBridge(self.registry, self.memory)
        self.inboxes: Dict[str, AgentInbox] = {}
        self.pubsub = AXELPubSub()
        self.event_bus = EventBus()
        self.executor = AXELExecutor(
            self.registry, self.memory, self.bridge,
            self.event_bus, self.inboxes,
        )
        self.start_time = time.time()
        self._inbox_lock = threading.Lock()
        # Liveness: agent_id → last-seen timestamp (unix seconds)
        self._last_seen: Dict[str, float] = {}
        self._liveness_lock = threading.Lock()
        # User task queue — dashboard POSTs tasks here; demo loop pops them
        self._task_queue: list = []
        self._task_queue_lock = threading.Lock()
        # User-defined topic library — agents explore these instead of built-in topics
        self._topic_library: list = []
        self._topic_lock = threading.Lock()
        # Restore persisted agents/memory if db is attached
        if self.persistence:
            self._restore_from_db()
        self.app = self._build_app()

    # ── Liveness helpers ─────────────────────────────────────────

    def _touch(self, agent_id: str) -> None:
        """Record that agent_id was just seen."""
        with self._liveness_lock:
            self._last_seen[agent_id] = time.time()
        if self.persistence:
            self.persistence.touch_agent(agent_id)

    def _is_online(self, agent_id: str) -> bool:
        with self._liveness_lock:
            ts = self._last_seen.get(agent_id)
        return ts is not None and (time.time() - ts) < self.LIVENESS_TTL

    # ── DB restore ───────────────────────────────────────────────

    def _restore_from_db(self):
        """Load persisted agents and lessons back into in-memory state."""
        p = self.persistence
        # Restore agents
        for a in p.list_agents():
            try:
                self.registry.register(
                    agent_id=a["agent_id"],
                    model=a.get("model", "?"),
                    provider=a.get("provider", "?"),
                    capabilities=a.get("caps", []),
                )
                self._inbox(a["agent_id"])
            except Exception:
                pass
        # Restore lessons
        from axel.learning import Lesson
        for l in p.list_lessons(top=500):
            try:
                self.memory.write(Lesson(
                    key=l["key"],
                    insight=l["insight"],
                    source=l.get("source", "db"),
                    confidence=l.get("confidence", 0.5),
                ))
            except Exception:
                pass

    def _inbox(self, agent_id: str) -> AgentInbox:
        with self._inbox_lock:
            if agent_id not in self.inboxes:
                self.inboxes[agent_id] = AgentInbox()
            return self.inboxes[agent_id]

    # ── FastAPI app factory ───────────────────────────────────────
    def _build_app(self) -> FastAPI:
        app = FastAPI(
            title="AXEL Network Server",
            version="2.1.0",
            description="Distributed hub for cross-LLM agent communication via AXEL protocol",
        )
        app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"], allow_methods=["*"], allow_headers=["*"],
        )

        # ── Auth middleware ───────────────────────────────────────
        @app.middleware("http")
        async def auth_middleware(request: Request, call_next):
            if self.key:
                path = request.url.path
                # Exempt root, status, ui, stream, docs
                exempt = path in self._AUTH_EXEMPT or path.startswith("/stream")
                if not exempt:
                    client_key = request.headers.get("X-AXEL-Key", "")
                    if client_key != self.key:
                        return JSONResponse(
                            status_code=401,
                            content={"detail": "Unauthorized — X-AXEL-Key header required"},
                        )
            return await call_next(request)

        # ── Root ─────────────────────────────────────────────────
        @app.get("/")
        async def root():
            base = f"http://{self.host}:{self.port}"
            return {
                "name": "AXEL Network Server", "version": "2.1.0",
                "docs":   f"{base}/docs",
                "status": f"{base}/status",
                "stream": f"{base}/stream",
                "ui":     f"{base}/ui",
                "auth":   self.key is not None,
                "db":     self.db_path,
            }

        # ── Dashboard UI ─────────────────────────────────────────
        @app.get("/ui", response_class=HTMLResponse)
        async def serve_ui():
            """Serve the AXEL monitor dashboard."""
            static_path = Path(__file__).parent / "static" / "monitor.html"
            if static_path.exists():
                return HTMLResponse(content=static_path.read_text(encoding="utf-8"))
            return HTMLResponse(
                content="<h1>Dashboard not found</h1>"
                        "<p>Run from the axel-protocol package directory.</p>",
                status_code=404,
            )

        # ── Registry ─────────────────────────────────────────────
        @app.post("/agents/announce")
        async def announce(request: Request):
            body = await request.json()
            agent_id = body.get("agent_id") or body.get("fr")
            if not agent_id:
                raise HTTPException(400, "agent_id required")
            rec = self.registry.register(
                agent_id=agent_id,
                model=body.get("model", "unknown"),
                provider=body.get("provider", "custom"),
                capabilities=body.get("caps", []),
                tags=body.get("tags", []),
                endpoint=body.get("endpoint"),
                metadata={},
            )
            self._inbox(agent_id)  # ensure inbox exists
            self._touch(agent_id)
            if self.persistence:
                self.persistence.upsert_agent(
                    agent_id=agent_id,
                    model=rec.model,
                    provider=rec.provider,
                    caps=rec.capabilities,
                )
            self.event_bus.publish("agent.announced", {
                "agent_id": agent_id, "model": rec.model,
                "provider": rec.provider, "caps": rec.capabilities,
            })
            return {"ok": True, "agent": asdict(rec)}

        @app.get("/agents")
        async def list_agents():
            agents = self.registry.leaderboard()
            for a in agents:
                aid = a.get("agent") or a.get("agent_id") or a.get("id", "?")
                a["agent_id"] = aid
                a["online"]   = self._is_online(aid)
            return {"agents": agents, "count": len(agents)}

        @app.get("/agents/{agent_id}")
        async def get_agent(agent_id: str):
            board = {}
            for a in self.registry.leaderboard():
                key = a.get("agent") or a.get("agent_id") or a.get("id")
                if key:
                    a["agent_id"] = key
                    a["online"]   = self._is_online(key)
                    board[key] = a
            if agent_id not in board:
                raise HTTPException(404, f"Agent '{agent_id}' not found")
            return board[agent_id]

        # ── Discovery (query-param + legacy path param) ───────────
        @app.get("/discover")
        async def discover_by_cap(cap: str = Query(...), top: int = Query(5)):
            candidates = self.registry.find(cap)[:top]
            best = self.registry.best_for(cap)
            score = getattr(best, "score", 0) if best else 0
            caps  = getattr(best, "capabilities", []) if best else []
            return {
                "cap":        cap,
                "best":       best.agent_id if best else None,
                "score":      round(float(score), 2),
                "caps":       caps,
                "candidates": [asdict(c) for c in candidates],
            }

        @app.get("/discover/{action}")
        async def discover_legacy(action: str, top: int = Query(5)):
            candidates = self.registry.find(action)[:top]
            best = self.registry.best_for(action)
            return {
                "action":     action,
                "cap":        action,
                "best":       best.agent_id if best else None,
                "candidates": [asdict(c) for c in candidates],
            }

        # ── Messaging ────────────────────────────────────────────
        @app.post("/send")
        async def send_message(request: Request):
            msg_dict = await request.json()
            try:
                msg = AXELMessage.from_dict(msg_dict)
            except Exception as e:
                raise HTTPException(400, f"Invalid AXEL message: {e}")

            # Determine recipients
            if msg.to == "*":
                with self._inbox_lock:
                    recipients = [a for a in self.inboxes if a != msg.fr]
            else:
                recipients = [msg.to]
                self._inbox(msg.to)

            for r in recipients:
                self._inbox(r).put(msg_dict)
                if self.persistence:
                    self.persistence.enqueue_message(r, msg_dict)

            # Touch liveness for sender
            self._touch(msg.fr)

            # Heartbeat — update liveness only, don't route to inbox
            if msg.t == "HB":
                self.event_bus.publish("agent.heartbeat", {"agent_id": msg.fr})
                return {"ok": True, "delivered_to": [], "msg_id": msg.id}

            # Broadcast run-complete output so dashboard can display pipeline results
            if msg.t == "RC":
                self.event_bus.publish("run.complete", {
                    "run":     msg.body.get("run"),
                    "topic":   msg.body.get("topic", ""),
                    "summary": msg.body.get("summary", ""),
                    "draft":   msg.body.get("draft", ""),
                    "review":  msg.body.get("review", ""),
                    "source":  msg.fr,
                })

            # Auto-write lessons to SmartMemory
            if msg.t == "LS":
                from axel.learning import Lesson
                self.memory.write(Lesson(
                    key=msg.body.get("key", "unknown"),
                    insight=msg.body.get("insight", ""),
                    source=msg.fr,
                    confidence=msg.body.get("confidence", 1.0),
                ))
                self.event_bus.publish("memory.updated", {
                    "key":     msg.body.get("key"),
                    "insight": msg.body.get("insight", ""),
                    "source":  msg.fr,
                })

            # Handle pub/sub publish messages
            if msg.t == "PB":
                channel = msg.body.get("channel", "")
                event = msg.body.get("event", {})
                subs = self.pubsub.matching_subscribers(channel, event)
                for s in subs:
                    self._inbox(s).put(msg_dict)

            self.event_bus.publish("message.sent", {
                "t": msg.t, "fr": msg.fr, "to": msg.to,
                "id": msg.id, "recipients": recipients,
            })
            return {"ok": True, "delivered_to": recipients, "msg_id": msg.id}

        @app.get("/inbox/{agent_id}")
        async def poll_inbox(
            agent_id: str,
            timeout: float = Query(5.0, le=30.0),
        ):
            inbox = self._inbox(agent_id)
            import asyncio
            loop = asyncio.get_event_loop()
            msg = await loop.run_in_executor(None, inbox.poll, timeout)
            return {"msg": msg, "queued": inbox.depth()}

        @app.get("/inbox/{agent_id}/all")
        async def drain_inbox(agent_id: str):
            msgs = self._inbox(agent_id).drain()
            return {"msgs": msgs, "count": len(msgs)}

        # ── Execution ────────────────────────────────────────────
        @app.post("/execute")
        async def execute(request: Request):
            body = await request.json()
            import asyncio
            loop = asyncio.get_event_loop()
            if body.get("t") == "CH":
                results = await loop.run_in_executor(
                    None, self.executor.execute_chain, body)
                return {"results": results, "count": len(results)}
            else:
                return await loop.run_in_executor(
                    None, self.executor.execute_task, body)

        # ── Adapters ─────────────────────────────────────────────
        @app.post("/adapters/mock")
        async def add_mock(request: Request):
            body = await request.json()
            agent_id = body.get("agent_id")
            if not agent_id:
                raise HTTPException(400, "agent_id required")
            self.bridge.add_mock(agent_id)
            return {"ok": True, "adapter": "mock", "agent_id": agent_id}

        @app.post("/adapters/ollama")
        async def add_ollama(request: Request):
            body = await request.json()
            agent_id = body.get("agent_id")
            if not agent_id:
                raise HTTPException(400, "agent_id required")
            self.bridge.add_ollama(
                agent_id,
                model=body.get("model", "llama3"),
                endpoint=body.get("endpoint", "http://localhost:11434"),
                caps=body.get("caps", []),
            )
            return {"ok": True, "adapter": "ollama",
                    "agent_id": agent_id, "model": body.get("model", "llama3")}

        @app.post("/adapters/anthropic")
        async def add_anthropic(request: Request):
            body = await request.json()
            agent_id = body.get("agent_id")
            api_key = body.get("api_key") or os.environ.get("ANTHROPIC_API_KEY")
            if not agent_id or not api_key:
                raise HTTPException(400, "agent_id and api_key required")
            self.bridge.add_anthropic(
                agent_id,
                model=body.get("model", "claude-3-5-haiku-20241022"),
                api_key=api_key,
                caps=body.get("caps", []),
            )
            return {"ok": True, "adapter": "anthropic", "agent_id": agent_id}

        @app.post("/adapters/openai")
        async def add_openai(request: Request):
            body = await request.json()
            agent_id = body.get("agent_id")
            api_key = body.get("api_key") or os.environ.get("OPENAI_API_KEY")
            if not agent_id or not api_key:
                raise HTTPException(400, "agent_id and api_key required")
            self.bridge.add_openai(
                agent_id,
                model=body.get("model", "gpt-4o-mini"),
                api_key=api_key,
                caps=body.get("caps", []),
            )
            return {"ok": True, "adapter": "openai", "agent_id": agent_id}

        @app.post("/adapters/gemini")
        async def add_gemini(request: Request):
            from axel.adapters.gemini import GeminiAdapter
            body = await request.json()
            agent_id = body.get("agent_id")
            api_key  = body.get("api_key") or os.environ.get("GOOGLE_API_KEY")
            if not agent_id or not api_key:
                raise HTTPException(400, "agent_id and api_key required")
            adapter = GeminiAdapter(agent_id,
                model=body.get("model", "gemini-1.5-flash"),
                capabilities=body.get("caps", []),
                api_key=api_key)
            self.bridge.add_adapter(agent_id, adapter, caps=body.get("caps", []))
            return {"ok": True, "adapter": "gemini", "agent_id": agent_id}

        @app.post("/adapters/mistral")
        async def add_mistral(request: Request):
            from axel.adapters.mistral import MistralAdapter
            body = await request.json()
            agent_id = body.get("agent_id")
            api_key  = body.get("api_key") or os.environ.get("MISTRAL_API_KEY")
            if not agent_id or not api_key:
                raise HTTPException(400, "agent_id and api_key required")
            adapter = MistralAdapter(agent_id,
                model=body.get("model", "mistral-small-latest"),
                capabilities=body.get("caps", []),
                api_key=api_key)
            self.bridge.add_adapter(agent_id, adapter, caps=body.get("caps", []))
            return {"ok": True, "adapter": "mistral", "agent_id": agent_id}

        @app.post("/adapters/groq")
        async def add_groq(request: Request):
            from axel.adapters.groq import GroqAdapter
            body = await request.json()
            agent_id = body.get("agent_id")
            api_key  = body.get("api_key") or os.environ.get("GROQ_API_KEY")
            if not agent_id or not api_key:
                raise HTTPException(400, "agent_id and api_key required")
            adapter = GroqAdapter(agent_id,
                model=body.get("model", "llama-3.3-70b-versatile"),
                capabilities=body.get("caps", []),
                api_key=api_key)
            self.bridge.add_adapter(agent_id, adapter, caps=body.get("caps", []))
            return {"ok": True, "adapter": "groq", "agent_id": agent_id}

        @app.post("/adapters/together")
        async def add_together(request: Request):
            from axel.adapters.together import TogetherAdapter
            body = await request.json()
            agent_id = body.get("agent_id")
            api_key  = body.get("api_key") or os.environ.get("TOGETHER_API_KEY")
            if not agent_id or not api_key:
                raise HTTPException(400, "agent_id and api_key required")
            adapter = TogetherAdapter(agent_id,
                model=body.get("model", "meta-llama/Meta-Llama-3.1-70B-Instruct-Turbo"),
                capabilities=body.get("caps", []),
                api_key=api_key)
            self.bridge.add_adapter(agent_id, adapter, caps=body.get("caps", []))
            return {"ok": True, "adapter": "together", "agent_id": agent_id}

        @app.post("/adapters/cohere")
        async def add_cohere(request: Request):
            from axel.adapters.cohere import CohereAdapter
            body = await request.json()
            agent_id = body.get("agent_id")
            api_key  = body.get("api_key") or os.environ.get("COHERE_API_KEY")
            if not agent_id or not api_key:
                raise HTTPException(400, "agent_id and api_key required")
            adapter = CohereAdapter(agent_id,
                model=body.get("model", "command-r-plus"),
                capabilities=body.get("caps", []),
                api_key=api_key)
            self.bridge.add_adapter(agent_id, adapter, caps=body.get("caps", []))
            return {"ok": True, "adapter": "cohere", "agent_id": agent_id}

        @app.get("/adapters")
        async def list_adapters():
            adapters = []
            for agent_id, adapter in self.bridge.adapters.items():
                adapters.append({
                    "agent_id": agent_id,
                    "provider": getattr(adapter, "PROVIDER", "unknown"),
                    "model":    getattr(adapter, "model", getattr(adapter, "model_id", "?")),
                })
            return {"adapters": adapters, "count": len(adapters)}

        # ── Memory ───────────────────────────────────────────────
        @app.get("/memory")
        async def list_memory(top: int = Query(20)):
            lessons = self.memory.top(top)
            return {
                "lessons": [
                    {"key": l.key, "insight": l.insight, "source": l.source,
                     "confidence": round(l.confidence, 3), "uses": l.uses}
                    for l in lessons
                ],
                "stats": self.memory.stats(),
            }

        @app.get("/memory/search")
        async def search_memory(q: str, n: int = Query(5)):
            results = self.memory.search_lessons(q, n)
            return {
                "query": q,
                "results": [
                    {"key": l.key, "insight": l.insight, "source": l.source,
                     "confidence": round(l.confidence, 3)}
                    for l in results
                ],
            }

        @app.post("/memory/write")
        async def write_memory(request: Request):
            body = await request.json()
            from axel.learning import Lesson
            lesson = Lesson(
                key=body["key"],
                insight=body["insight"],
                source=body.get("source", "api"),
                confidence=body.get("confidence", 1.0),
            )
            self.memory.write(lesson)
            if self.persistence:
                self.persistence.write_lesson(
                    lesson.key, lesson.insight,
                    lesson.source, lesson.confidence,
                )
            self.event_bus.publish("memory.updated",
                                   {"key": lesson.key, "source": lesson.source})
            return {"ok": True, "key": lesson.key}

        @app.post("/memory/decay")
        async def decay_memory():
            decayed = self.memory.apply_decay()
            pruned = self.memory.prune_stale()
            return {"decayed": decayed, "pruned": pruned}

        # ── Channels ─────────────────────────────────────────────
        @app.post("/channels/subscribe")
        async def subscribe(request: Request):
            body = await request.json()
            agent_id = body.get("agent_id") or body.get("fr")
            channel = body.get("channel")
            if not agent_id or not channel:
                raise HTTPException(400, "agent_id and channel required")
            self.pubsub.subscribe(agent_id, channel, body.get("filter", {}))
            return {"ok": True, "agent_id": agent_id, "channel": channel}

        @app.post("/channels/publish")
        async def publish_channel(request: Request):
            body = await request.json()
            channel = body.get("channel")
            event = body.get("event", {})
            publisher = body.get("publisher", "unknown")
            if not channel:
                raise HTTPException(400, "channel required")
            subs = self.pubsub.matching_subscribers(channel, event)
            pb_template = {
                "v": "2", "t": "PB",
                "fr": publisher,
                "ts": int(time.time() * 1000), "pri": 3,
                "body": {"channel": channel, "event": event},
            }
            for agent_id in subs:
                pb = {**pb_template,
                      "id": f"msg_{uuid.uuid4().hex[:12]}",
                      "cid": f"cnv_{uuid.uuid4().hex[:8]}",
                      "to": agent_id}
                self._inbox(agent_id).put(pb)
            self.event_bus.publish("channel.published", {
                "channel": channel, "publisher": publisher,
                "notified": len(subs),
            })
            return {"ok": True, "channel": channel, "notified": subs}

        @app.get("/channels")
        async def list_channels():
            return {"channels": self.pubsub.channel_list()}

        # ── Status ───────────────────────────────────────────────
        @app.get("/status")
        async def status():
            agents = self.registry.leaderboard()
            online_count = sum(
                1 for a in agents
                if self._is_online(a.get("agent") or a.get("agent_id") or "")
            )
            result = {
                "version":  "2.1.0",
                "uptime_s": round(time.time() - self.start_time, 1),
                "auth":     self.key is not None,
                "db":       self.db_path,
                "agents": {
                    "count":  len(agents),
                    "online": online_count,
                    "list": [
                        {
                            "id":       a.get("agent") or a.get("agent_id") or "?",
                            "model":    a.get("model", "?"),
                            "provider": a.get("provider", "?"),
                            "score":    round(float(a.get("score") or a.get("avg_score") or 0), 2),
                            "tasks":    a.get("tasks") or a.get("tasks_done") or 0,
                            "caps":     a.get("capabilities") or a.get("caps") or [],
                            "online":   self._is_online(
                                a.get("agent") or a.get("agent_id") or ""
                            ),
                        }
                        for a in agents
                    ],
                },
                "memory": self.memory.stats(),
                "channels": len(self.pubsub.channel_list()),
                "inboxes": {
                    aid: self.inboxes[aid].depth()
                    for aid in self.inboxes
                },
            }
            if self.persistence:
                result["db_stats"] = self.persistence.stats()
            return result

        # ── User Task Queue ───────────────────────────────────────
        @app.post("/queue")
        async def queue_task(request: Request):
            """Dashboard submits a user task here; the demo loop picks it up."""
            body = await request.json()
            task = (body.get("task") or "").strip()
            if not task:
                return {"ok": False, "error": "task is required"}
            with self._task_queue_lock:
                self._task_queue.append(task)
            # Broadcast so the dashboard knows the task was received
            self.event_bus.publish("user.task", {"task": task, "queued": len(self._task_queue)})
            return {"ok": True, "queued": len(self._task_queue)}

        @app.get("/queue")
        async def peek_queue():
            """Pop and return the next user task, or null if queue is empty."""
            with self._task_queue_lock:
                task = self._task_queue.pop(0) if self._task_queue else None
            return {"task": task, "remaining": len(self._task_queue)}

        # ── Topic Library ─────────────────────────────────────────
        @app.post("/topics")
        async def add_topic(request: Request):
            """Add a topic to the learning library."""
            body = await request.json()
            topic = (body.get("topic") or "").strip()
            if not topic:
                return {"ok": False, "error": "topic is required"}
            with self._topic_lock:
                if topic not in self._topic_library:
                    self._topic_library.append(topic)
            self.event_bus.publish("topics.updated", {"topics": list(self._topic_library)})
            return {"ok": True, "topics": list(self._topic_library)}

        @app.get("/topics")
        async def list_topics():
            """Return all user-defined topics."""
            with self._topic_lock:
                return {"topics": list(self._topic_library)}

        @app.delete("/topics/{idx}")
        async def remove_topic(idx: int):
            """Remove a topic by index."""
            with self._topic_lock:
                if idx < 0 or idx >= len(self._topic_library):
                    return {"ok": False, "error": "index out of range"}
                removed = self._topic_library.pop(idx)
            self.event_bus.publish("topics.updated", {"topics": list(self._topic_library)})
            return {"ok": True, "removed": removed, "topics": list(self._topic_library)}

        # ── SSE Event Stream ─────────────────────────────────────
        @app.get("/stream")
        async def event_stream(request: Request):
            """Server-Sent Events: real-time feed of all network activity."""
            client_q = self.event_bus.new_client()

            async def generator():
                import asyncio
                # Replay recent history so new clients catch up
                for ev in self.event_bus.recent(30):
                    payload = json.dumps({
                        "event": ev.event, "data": ev.data, "ts": ev.ts,
                    })
                    yield f"data: {payload}\n\n"
                # Stream live events
                loop = asyncio.get_event_loop()
                try:
                    while True:
                        if await request.is_disconnected():
                            break
                        try:
                            ev = await asyncio.wait_for(
                                loop.run_in_executor(None, client_q.get),
                                timeout=25.0,
                            )
                            payload = json.dumps({
                                "event": ev.event,
                                "data": ev.data,
                                "ts": ev.ts,
                            })
                            yield f"data: {payload}\n\n"
                        except asyncio.TimeoutError:
                            yield "data: {\"event\":\"ping\"}\n\n"
                finally:
                    self.event_bus.remove_client(client_q)

            return StreamingResponse(
                generator(),
                media_type="text/event-stream",
                headers={
                    "Cache-Control": "no-cache",
                    "X-Accel-Buffering": "no",
                    "Connection": "keep-alive",
                },
            )

        return app

    # ── Run modes ────────────────────────────────────────────────
    def run(self, log_level: str = "info"):
        base = f"http://{self.host}:{self.port}"
        print(f"\n{'═'*60}")
        print(f"  AXEL Network Server  v2.1")
        print(f"  {base}")
        print(f"  Dashboard: {base}/ui")
        print(f"  Status:    {base}/status")
        print(f"  Stream:    {base}/stream")
        print(f"  Swagger:   {base}/docs")
        if self.key:
            print(f"  Auth:      enabled  (X-AXEL-Key)")
        if self.db_path:
            print(f"  DB:        {self.db_path}")
        print(f"{'═'*60}\n")
        uvicorn.run(self.app, host=self.host, port=self.port,
                    log_level=log_level)

    def start_background(self, log_level: str = "warning") -> threading.Thread:
        """Start the server in a background daemon thread. Polls until ready."""
        import urllib.request as _ur

        def _run():
            import asyncio
            config = uvicorn.Config(
                self.app, host=self.host, port=self.port,
                log_level=log_level,
            )
            srv = uvicorn.Server(config)
            srv.install_signal_handlers = lambda: None  # safe in a thread
            asyncio.run(srv.serve())

        t = threading.Thread(target=_run, daemon=True, name="axel-server")
        t.start()

        # Poll until the server accepts connections (up to 10 s)
        deadline = time.time() + 10
        while time.time() < deadline:
            time.sleep(0.2)
            try:
                _ur.urlopen(f"http://{self.host}:{self.port}/", timeout=1)
                break
            except Exception:
                pass

        return t


# ══════════════════════════════════════════════════════════════════
# CLI entry point
# ══════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        description="AXEL Network Server",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--host",      default="0.0.0.0",   help="Bind address")
    parser.add_argument("--port",      type=int, default=7331, help="Listen port")
    parser.add_argument("--log-level", default="info",       help="Uvicorn log level")
    parser.add_argument(
        "--key",
        default=os.environ.get("AXEL_KEY", ""),
        help="API key for auth (or set AXEL_KEY env var). Empty = auth disabled.",
    )
    parser.add_argument(
        "--db",
        default=os.environ.get("AXEL_DB", ""),
        help="Path to SQLite DB for persistence (or set AXEL_DB env var). Empty = in-memory only.",
    )
    args = parser.parse_args()
    server = AXELServer(
        host=args.host,
        port=args.port,
        key=args.key or None,
        db=args.db or None,
    )

    # Print extra config lines
    if server.key:
        print(f"  Auth:     enabled (X-AXEL-Key)")
    if server.db_path:
        print(f"  DB:       {server.db_path}")
    print(f"  Dashboard: http://{args.host}:{args.port}/ui")

    server.run(log_level=args.log_level)


def create_app(**kwargs):
    """Convenience factory — returns a bare FastAPI ASGI app for testing."""
    return AXELServer(**kwargs).app


if __name__ == "__main__":
    main()
