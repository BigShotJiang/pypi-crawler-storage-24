from importlib.resources import files
print(files("cfp1").joinpath("data.txt").read_text())
