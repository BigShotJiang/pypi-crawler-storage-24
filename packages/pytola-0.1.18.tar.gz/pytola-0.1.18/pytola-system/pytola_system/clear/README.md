# clear

Cross-platform console screen clearing utility.

## Features

- Cross-platform support (Windows, Linux, macOS)
- Uses ANSI escape codes for better compatibility
- Debug mode for detailed output
- Simple and fast

## Installation

```bash
pip install -e .
```

## Usage

Basic usage:

```bash
clear
```

With debug mode:

```bash
clear --debug
```

## Examples

```bash
# Clear the screen
clear

# Clear with debug information
clear -d
```

## Platform Support

- **Windows**: Uses `cls` command via cmd.exe
- **Linux/macOS**: Uses `clear` command
- **All platforms**: Also sends ANSI escape codes for terminal clearing
