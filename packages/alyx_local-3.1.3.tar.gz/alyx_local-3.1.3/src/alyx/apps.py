from django.apps import AppConfig
import structlog

logger = structlog.get_logger("alyx.main_app")


class AlyxConfig(AppConfig):
    name = "alyx"

    def ready(self):
        logger.info("ALYX MAIN APP IS READY")
