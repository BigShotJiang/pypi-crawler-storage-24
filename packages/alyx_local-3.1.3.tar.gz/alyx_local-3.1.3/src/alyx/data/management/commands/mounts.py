from alyx.data.models import DataRepository

from django.core.management import BaseCommand

import subprocess
from subprocess import CalledProcessError, PIPE
import os, logging
from pathlib import Path

import structlog

logger = structlog.get_logger("data.management")


class Command(BaseCommand):
    """
    ./manage.py files bulksync --lab=cortexlab --dry
    ./manage.py files bulktransfer --lab=cortexlab --dry
    ./manage.py files removelocal --lab=churchlandlab --dry --before=2019-05-15 --limit=5
    """

    help = "Manage files"

    def add_arguments(self, parser):
        parser.add_argument("names", nargs="*", help="Name or names of the DataRepository to mount")
        parser.add_argument("--unmount", action="store_true", help="Unmount instead of mounting")

    def select_repositories(self, **options):
        repo_names = options.get("names", None)
        if repo_names:
            self.selected_repositories = DataRepository.objects.filter(name__in=repo_names)
        else:
            self.selected_repositories = DataRepository.objects.all()

    def unmount(self, repository: DataRepository):
        if repository.host_data_path is None:
            logger.error(
                f"Cannot unmount repository {repository.name} as neither the hostname or host address are set. "
                "One of them at least must be set for being able to unmount it ! "
                f"to {repository.mount_path}"
            )
            return

        logger.info(
            f"Attemping to unmount local folder at {repository.mount_path} from distant address : "
            f"{repository.host_data_path}"
        )
        try:
            subprocess.run(
                ["sudo", "umount", repository.mount_path],
                stdout=PIPE,
                stderr=PIPE,
                check=True,
            )
            repository.mount_path.unlink(missing_ok=True)

        except CalledProcessError as e:
            logger.error(f"Unmount command failed with exit status {e.returncode}")
            logger.error(f"Error: {e.stderr.decode('utf-8')}")
            return
        logger.info(f"Successful unmounting of repository {repository.name}")

    def mount(self, repository: DataRepository):
        """Mounts a data repository to a specified mount path.

        This method attempts to mount a data repository of type `SambaSharedFolder`
        from a given host data path to a specified mount path. It checks for the necessary parameters
        and handles errors during the mounting process.

        Args:
            repository (DataRepository): The data repository to be mounted.
            It must have a valid host data path and be of type `SambaSharedFolder`.

        Returns:
            None: This method does not return a value. It logs the process and any errors encountered.

        Raises:
            CalledProcessError: If the mount command fails during execution.

        Example:
            A type of mount command that is send with this function is :
            ```bash
            sudo mount.cifs <host_data_path> <mount_path> -o
            username=<username>,password=<password>,dir_mode=0777,file_mode=0777"
            ```
        """
        if repository.host_data_path is None:
            logger.error(
                f"Cannot mount repository {repository.name} as neither the hostname or host address are set. "
                "One of them at least must be set for being able to mount it ! "
                f"to {repository.mount_path}"
            )
            return
        logger.info(
            f"Attempting to mount {repository.name} from address : {repository.host_data_path} "
            f"to {repository.mount_path}"
        )
        if repository.repository_type is None or repository.repository_type.name != "SambaSharedFolder":
            logger.error(
                "Cannot mount a datarepository of type "
                f"{repository.repository_type.name if repository.repository_type else 'None'}. "
                "For now, only the type SambaSharedFolder is implemented for mounting"
            )
            return
        try:
            logger.info(f"Creating mount folder {repository.mount_path}")
            repository.mount_path.mkdir(parents=True, exist_ok=True)
            subprocess.run(
                [
                    "sudo",
                    "mount.cifs",
                    repository.host_data_path,
                    repository.mount_path,
                    "-o",
                    (
                        f"username={repository.shared_ressource_username},"
                        f"password={repository.shared_ressource_password},"
                        "dir_mode=0777,file_mode=0777"
                    ),
                ],
                stdout=PIPE,
                stderr=PIPE,
                check=True,
            )
        except CalledProcessError as e:
            logger.error(f"Mount command failed with exit status {e.returncode}")
            logger.error(f"Error: {e.stderr.decode('utf-8')}")
            return
        logger.info(f"Successful mounting of repository {repository.name}")

    def do_mounts(self):
        for repo in self.selected_repositories:
            if not repo.is_mounted:
                self.mount(repo)
            else:
                logger.warning(f"The mount for {repo.name} is already existing")

    def do_unmounts(self):
        for repo in self.selected_repositories:
            if repo.is_mounted:
                self.unmount(repo)
            else:
                logger.warning(f"The mount for {repo.name} doesn't exist. Skipping unmounting")

    def handle(self, *args, **options):
        self.select_repositories(**options)
        if options.get("unmount", False):
            self.do_unmounts()
        else:
            self.do_mounts()
