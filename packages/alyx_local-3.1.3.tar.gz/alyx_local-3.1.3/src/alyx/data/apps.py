from django.apps import AppConfig
import structlog

logger = structlog.get_logger("alyx.data_app")


class DataConfig(AppConfig):
    name = "alyx.data"
    label = "data"

    def ready(self):
        logger.debug("DATA APP IS READY")
