from django.contrib import admin
from django.urls import reverse
from django.utils.html import format_html
from django_admin_listfilter_dropdown.filters import (
    ChoiceDropdownFilter,
    DropdownFilter,
)

from ..actions.models import Session
from ..base.admin import BaseAdmin, get_admin_url
from ..jobs.models import Task

TASK_COLORS = {
    "black": "000000",
    "green": "008000",
    "orange": "FF7F50",
    "red": "FF0000",
}


class TaskAdmin(BaseAdmin):
    exclude = ["json"]
    readonly_fields = ["get_log_link", "parents"]
    list_display = [
        "name",
        "graph",
        "status",
        "version_str",
        "level",
        "datetime",
        "session_str",
        "session_task_protocol",
        "session_projects",
    ]
    search_fields = (
        "session__id",
        "session__lab__name",
        "session__subject__nickname",
        "log",
        "version",
        "session__task_protocol",
        "session__projects__name",
    )
    ordering = ("-datetime",)
    list_editable = ("status",)
    list_filter = [
        ("name", DropdownFilter),
        ("status", ChoiceDropdownFilter),
        ("graph", DropdownFilter),
    ]

    @admin.display(description="log")
    def get_log_link(self, obj):
        url = reverse("task-logs", kwargs={"task_id": str(obj.pk)})
        return format_html('<a href="{url}">{log}</a>', log=obj.log or "-", url=url)

    def has_change_permission(self, request, obj=None):
        if request.user.is_superuser:
            return True
        if obj:
            return obj.session.lab.name in request.user.lab

    @admin.display(description="projects")
    def session_projects(self, obj: "Task") -> str | None:
        if obj.session is not None and obj.session.projects is not None:
            return obj.session.projects.name
        return None

    @admin.display(description="task_protocol")
    def session_task_protocol(self, obj: "Task") -> str:
        if obj.session is not None:
            return obj.session.task_protocol
        return ""

    @admin.display(description="session")
    def session_str(self, obj):
        if obj.session is not None:
            url = get_admin_url(obj.session)
            return format_html(
                '<a href="{url}">{session}</a>', session=obj.session or "-", url=url
            )

    @admin.display(description="version")
    def version_str(self, obj: "Task"):
        if obj.status == 40:  # error
            col = TASK_COLORS["red"]
        elif obj.status == 50:  # empty
            col = TASK_COLORS["orange"]
        elif obj.status == 60:  # complete
            col = TASK_COLORS["green"]
        else:
            col = TASK_COLORS["black"]
        return format_html(
            '<b><a style="color: #{};">{}</a></b>', col, "{}".format(obj.version)
        )

    def formfield_for_foreignkey(self, db_field, request, **kwargs):
        if db_field.name == "session":  # replace 'session' with your session field name
            kwargs["queryset"] = Session.objects.order_by(
                "-start_time"
            )  # replace Session and logic here.
        return super().formfield_for_foreignkey(db_field, request, **kwargs)


admin.site.register(Task, TaskAdmin)
