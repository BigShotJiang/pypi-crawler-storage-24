from rest_framework import generics

from ..base.permissions import rest_permission_classes
from .models import Task
from .serializers import TaskListSerializer, TaskDetailsSeriaizer
from .filters import TaskFilter

class TaskListView(generics.ListCreateAPIView):
    """
    get: **FILTERS**
    -   **task**: task name `/jobs?task=EphysSyncPulses`
    -   **session**: uuid `/jobs?session=aad23144-0e52-4eac-80c5-c4ee2decb198`
    -   **lab**: lab name from session table `/jobs?lab=churchlandlab`
    -   **pipeline**: pipeline field from task `/jobs?pipeline=ephys`

    [===> task model reference](/admin/doc/models/jobs.task)
    """

    queryset = Task.objects.all()
    # queryset = TaskListSerializer.setup_eager_loading(queryset)
    permission_classes = rest_permission_classes()
    filterset_class = TaskFilter

    def get_serializer_class(self):
        if not self.request:
            return TaskListSerializer
        if self.request.method == "GET":
            return TaskListSerializer
        if self.request.method == "POST":
            return TaskDetailsSeriaizer

class TaskDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Task.objects.all()
    # queryset = TaskDetailsSeriaizer.setup_eager_loading(queryset)
    serializer_class = TaskDetailsSeriaizer
    permission_classes = rest_permission_classes()

