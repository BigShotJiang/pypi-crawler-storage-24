from django.urls import path
from django.conf.urls import include
from .api import (
    TaskListView,
    TaskDetailView
)
from .views import (
    TaskLogs,
    CreateAndViewTask,
    SessionTasksView,
    TasksStatusView,
)

api_urls = [
    path("tasks", TaskListView.as_view(), name="tasks-list"),
    path("tasks/<uuid:pk>", TaskDetailView.as_view(), name="tasks-detail"),
]

views_urls = [path(
        "admin-tasks/task-logs/<uuid:task_id>",
        TaskLogs.as_view(),
        name="task-logs",
    ),
    path(
        "admin-tasks/create-task/<uuid:session_pk>/task/<str:step_name>",
        CreateAndViewTask.as_view(),
        name="create-session-task",
    ),
    path(
        "admin-tasks/session/<uuid:session_pk>/task/<str:step_name>",
        SessionTasksView.as_view(),
        name="session-task",
    ),
    path(
        "admin-tasks/session/<uuid:session_pk>/<str:pipeline>/task/<str:step_name>",
        SessionTasksView.as_view(),
        name="session-task-with-pipeline",
    ),
    path(
        "admin-tasks/session/<uuid:session_pk>/<str:pipeline>/",
        SessionTasksView.as_view(),
        name="session-tasks-with-pipeline",
    ),
    path(
        "admin-tasks/session/<uuid:session_pk>",
        SessionTasksView.as_view(),
        name="session-tasks",
    ),
    # path(
    #     "admin-tasks",
    #     job_views.TasksOverview.as_view(),
    #     name="session-tasks-overview",
    # ),
    path(
        "admin-tasks/status",
        TasksStatusView.as_view(),
        name="tasks_status",
    ),
    path(
        "admin-tasks/status/<str:graph>",
        TasksStatusView.as_view(),
        name="tasks_status_graph",
    ),
    path(
        "admin-tasks/status/<str:graph>/<str:lab>",
        TasksStatusView.as_view(),
        name="tasks_status_graph_lab",
    ),
]

urlpatterns = [
    path("api/", include(api_urls)),
    path("", include(views_urls)),
]
