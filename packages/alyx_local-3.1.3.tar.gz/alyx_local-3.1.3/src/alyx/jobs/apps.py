from django.apps import AppConfig
import structlog

logger = structlog.get_logger("alyx.jobs_app")


class JobsConfig(AppConfig):
    name = "alyx.jobs"
    label = "jobs"

    def ready(self):
        logger.debug("JOBS APP IS READY")
