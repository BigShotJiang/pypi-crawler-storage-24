from django.conf import settings
from django.conf.urls import include
from django.contrib import admin
from django.contrib.staticfiles.storage import staticfiles_storage
from django.urls import path
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page
from django.views.generic.base import RedirectView
from drf_spectacular.views import SpectacularAPIView, SpectacularSwaggerView
from rest_framework.authtoken.views import ObtainAuthToken

# from .adminsite import mysite


@method_decorator(cache_page(60 * 60 * 24), name="dispatch")  # 24h
class CachedSpectacularAPIView(SpectacularAPIView):
    pass


api_urls = [
    path("schema/", CachedSpectacularAPIView.as_view(), name="schema"),
    path("", SpectacularSwaggerView.as_view(url_name="schema"), name="swagger-ui"),
    path("auth-token", ObtainAuthToken.as_view()),
]

urlpatterns = [
    # redirect the page to admin login or home interface
    path("", RedirectView.as_view(url="/admin")),
    path("admin/doc/", include("django.contrib.admindocs.urls")),
    # this points to templates/admin_doc/index.html
    path("admin/", admin.site.urls),
    path("api/", include(api_urls)),
    path("", include("alyx.misc.urls")),
    path("", include("alyx.experiments.urls")),
    path("", include("alyx.jobs.urls")),
    path("", include("alyx.actions.urls")),
    path("", include("alyx.data.urls")),
    path("", include("alyx.subjects.urls")),
    path("api/auth/", include("rest_framework.urls", namespace="rest_framework")),
    path("markdownx/", include("markdownx.urls")),
    path(
        "favicon.ico", RedirectView.as_view(url=staticfiles_storage.url("favicon.ico"))
    ),
]

if settings.DEBUG:
    # Debug toolbar provides usefull infos, such as the ability to do the
    # profiling of queries, and code in general, from web interface.
    # Do not activate this feature in production.
    from debug_toolbar.toolbar import debug_toolbar_urls

    urlpatterns.extend(debug_toolbar_urls())
