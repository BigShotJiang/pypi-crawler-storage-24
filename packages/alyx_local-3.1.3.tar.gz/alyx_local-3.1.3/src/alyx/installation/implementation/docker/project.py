import subprocess
from rich_click import secho
from ..utils import PROJECT_NAME
from .utils import verify_outside_container

@verify_outside_container
def delete_project(delete_volumes=False, delete_images=False, clean_orphans=False):
    supplementary_args = ['down']
    removing = ["containers"]

    if delete_volumes :
        supplementary_args.extend(["--volumes"])
        removing.append("volumes")

    if delete_images :
        supplementary_args.extend(["--rmi", "all"])
        removing.append("images (localy built and global)")

    if clean_orphans :
        supplementary_args.extend(["--remove-orphans"])
        removing.append("ophaned containers used for services not defined in the compose file")

    shell_cmd = f"docker compose -p {PROJECT_NAME} {' '.join(supplementary_args)}"
    secho(
            f"Removing {', '.join(removing)} for the project {PROJECT_NAME}",
            fg="yellow"
        )
    secho(shell_cmd)
    subprocess.run(shell_cmd, shell=True)

