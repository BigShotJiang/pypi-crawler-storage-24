from functools import wraps
import subprocess
from rich_click import secho

from ..utils import verify_outside_container, PROJECT_NAME

from typing import ParamSpec, TypeVar, Callable

PS = ParamSpec("PS")
T = TypeVar("T")

EXISTING_CONTAINER_NAMES = [
    "django_server",
    "nginx_server",
    "celery_server",
    "postgres_db",
    "pgadmin",
    "rabbitmq",
]

EXISTING_VOLUME_NAMES = [
    f"{PROJECT_NAME}_db-data",
    f"{PROJECT_NAME}_pgadmin-data",
    f"{PROJECT_NAME}_rabbitmq-data",
    f"{PROJECT_NAME}_uploaded-data",
]

def validates_container_name(func : Callable[PS, T]) -> "Callable[PS, T]":
    """Decorator for fnctions taking container_name as first argument"""
    @wraps(func)
    def wrapper(container_name, *args,**kwargs):
        if container_name is not None and container_name not in EXISTING_CONTAINER_NAMES:
            raise ValueError(f"container_name must be one of : {EXISTING_CONTAINER_NAMES}")
        return func(container_name, *args,**kwargs)
    return wrapper  

def validates_volume_name(func : Callable[PS, T]) -> "Callable[PS, T]":
    """Decorator for fnctions taking container_name as first argument."""
    @wraps(func)
    def wrapper(volume_name, *args,**kwargs):
        if volume_name is not None and volume_name not in EXISTING_VOLUME_NAMES:
            raise ValueError(f"container_name must be one of : {EXISTING_VOLUME_NAMES}")
        return func(volume_name, *args,**kwargs)
    return wrapper  

def verify_docker_daemon_is_running(func : Callable[PS, T]) -> "Callable[PS, T]":
    """Decorator to test wether docker is running or not."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        if not is_docker_daemon_running():
            raise OSError("Docker daemon (docker desktop or another docker service) "
            "is not running, and all docker command will thus not work. "
            "Please start your docker service first, wait a bit until it is initiated, then retry.")
        return func(*args, **kwargs) 
    return wrapper  

def is_docker_daemon_running() -> bool :
    # This CLI comman,d will fail fast if daemon isn't reachable.
    r = subprocess.run(
            ["docker", "info"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    return r.returncode == 0

@verify_docker_daemon_is_running
@verify_outside_container
def clean_docker_unused_assets(volumes=False, confirm=False):
    """Remove all mess and unused images / volumes / etc that are left dangling around.
    Loss of data danger !
    """

    secho("Cleaning docker assets", fg="yellow")  
    commands = ["docker image prune"]
    if volumes :
        commands.append("docker volume prune")
        
    for command in commands : 
        shell_cmd= f"{command} --force" if confirm else command
        secho(f"Using command : {shell_cmd}", fg="bright_black")    
        subprocess.run(shell_cmd, shell=True)


@verify_docker_daemon_is_running
@verify_outside_container
def clean_docker_build_cache(confirm : bool = False):
    secho("Cleaning docker build cache", fg="yellow")   

    commands = ["docker builder prune", "docker buildx prune", "docker buildx history rm --all"]
    needs_confirmation = [True, True, False]
    for command, needs_confirm in zip(commands, needs_confirmation) : 
        shell_cmd = f"{command} --force" if confirm and needs_confirm else command
        secho(f"Using command : {shell_cmd}", fg="bright_black")   
        subprocess.run(shell_cmd, shell=True)