import subprocess
from rich_click import secho

from .utils import verify_docker_daemon_is_running, validates_volume_name, EXISTING_VOLUME_NAMES

from typing import Literal, Optional

@validates_volume_name
@verify_docker_daemon_is_running
def volume_action(volume_name : Optional[str], action : Literal["delete"]):

    name_to_implementation = {
        "delete":"rm",
    }
    action_name  = action.capitalize()

    action_impl = name_to_implementation[action]

    if volume_name is None :
        volume_name = EXISTING_VOLUME_NAMES
    else :
        volume_name = [volume_name]

    secho(f"{action_name}ing volume(s): {", ".join(volume_name)}", fg="yellow")    

    shell_cmd = f"docker volume {action_impl} {" ".join(volume_name)}"
    secho(f"Using command : {shell_cmd}", fg="bright_black")    
    subprocess.run(shell_cmd, shell=True)
