from rich.text import Text
from rich.console import Console, Group
from rich.prompt import Prompt, Confirm
from rich.panel import Panel
from rich import box

from .enums import InstallStatus

from typing import List, Any, Optional, TYPE_CHECKING

if TYPE_CHECKING :
    from .installers import Installer

class Renderer:
    variables_store = {}
    default_style = "blue"
    items_style = "turquoise2"
    max_width = 120

    def __init__(self, verbose : bool = False):
        """Initializes the class with optional verbosity and sets up the console.

        Args:
            verbose (bool, optional): If True, enables verbose output. Defaults to False.

        Attributes:
            console (Console): An instance of the Console class for output.
            content (List[Text]): A list to hold text content.
            verbose (bool): Indicates whether verbose output is enabled.
        """

        # self.live = Live(console=Console(), auto_refresh=False)
        # self.console = self.live.console
        self.console = Console()

        self.content: "List[Text]" = []
        self.verbose = verbose

    def print(self, text: str | Any, style: Optional[str] = "", justify=None):
        """Prints the given text with the specified style and justification.

        Args:
            text (str | Any): The text to be printed. Can be a string or any other type.
            style (Optional[str], optional): The style to apply to the text. Defaults to an empty string,
                which will use the default style if not provided.
            justify (optional): The justification for the text. The default behavior is determined by
                the implementation.

        Returns:
            None: This function does not return a value.

        Raises:
            TypeError: If the text is not of type str or Text.
        """

        if style is None:
            style = self.default_style

        if isinstance(text, (Text, str)):
            text = Text("", style=style).append(text)
        self.content.append(text)
        self.render()

    def title(self, message: str, style=None, emoji=True):
        """Display a title message with optional styling and emoji prefix.

        Args:
            message (str): The message to be displayed as a title.
            style (str, optional): The style to be applied to the title. If None, the default style is used.
              Defaults to None.
            emoji (bool, optional): Whether to prepend an emoji to the title based on the style.
              Defaults to True.

        Returns:
            None: This function does not return a value; it prints the formatted title message.
        """

        if style is None:
            style = self.default_style

        if emoji:
            if "bright_red" in style:
                prefix = "\n🔴 "
            else:
                prefix = "\n🔵 "
        else:
            prefix = "\n"

        self.print(
            Text(prefix, style=style).append(message, style="underline " + style)
        )

    def wont_create(self, file_or_folder: "str | Any"):
        """Logs a message indicating that a file or folder will not be created because it already exists and
        has been validated.

        Args:
            file_or_folder (str | Any): The name of the file or folder that won't be created.
        """
        self.comment(
            f"🫷  Won't create {file_or_folder} as it already exists and has been checked as valid"
        )

    def comment(self, message: str | Any):
        """Logs a comment message if verbose mode is enabled.

        Args:
            message (str | Any): The message to be logged. Can be a string or any other type.

        Returns:
            None
        """
        if self.verbose:
            self.print(Text("", style="grey50").append(message))

    def success(self, message: str | Any, emoji=True):
        """Logs a success message with an optional emoji prefix.

        Args:
            message (str | Any): The message to be logged as a success. Can be a string or any other type.
            emoji (bool, optional): If True, prepends a checkmark emoji to the message. Defaults to True.

        Returns:
            None
        """
        prefix = "✔  " if emoji else ""
        self.print(Text(prefix, style="bright_green").append(message))

    def warning(self, message: str | Any, emoji=True):
        """Displays a warning message with an optional emoji prefix.

        Args:
            message (str | Any): The warning message to be displayed. Can be a string or any other type.
            emoji (bool): If True, prepends a warning emoji to the message. Defaults to True.

        Returns:
            None
        """
        prefix = "⚠️  " if emoji else ""
        self.print(Text(prefix, style="dark_orange").append(message))

    def error(self, message: str | Any, emoji=True):
        """Logs an error message with an optional emoji prefix.

        Args:
            message (str | Any): The error message to be logged. Can be a string or any other type.
            emoji (bool): If True, prepends an emoji to the error message. Defaults to True.

        Returns:
            None
        """
        prefix = "⛔️ " if emoji else ""
        self.print(Text(prefix, style="bright_red").append(message))

    def done(self):
        """Prints a summary message indicating that the configuration is healthy and ready for building and running
        the Docker application.

        This method displays a formatted message in the console, including instructions for building the application
        using specific commands. The message is styled with a bright green color to indicate success.

        Attributes:
            console: The console object used for printing messages.
            items_style: The style applied to specific text items in the message.

        Usage:
            Call this method when the configuration check is complete and successful.
        """
        self.console.print("\n")
        self.console.print(
            Panel.fit(
                Panel.fit(
                    Text(
                        "✔ 💚  Your configuration is healthy, you are ready "
                        "for building and running the docker app with ",
                        justify="center",
                    )
                    .append("pdm run fresh-build-fast", style=self.items_style)
                    .append(" or other build commands ( list all commands with ")
                    .append("pdm run -l", style=self.items_style)
                    .append(" ) 💚 ✔"),
                    title="Summary",
                    box=box.SIMPLE,
                    style="bright_green",
                    border_style="bright_green" + " bold",
                ),
                box=box.HORIZONTALS,
                border_style="bright_green",
                width=self.max_width,
            )
        )

    def done_with_warnings(self):
        """Displays a warning message indicating that some files may contain errors.

        This method prints a summary panel to the console, alerting the user to check
        the files for potential issues. The message is styled with specific colors and
        border styles for emphasis.

        Args:
            self: The instance of the class that this method belongs to.

        Returns:
            None
        """
        self.console.print("\n")
        self.console.print(
            Panel.fit(
                Panel.fit(
                    Text(
                        "⚠️  Some files may contain errors as indicated above, check them if you deem necessary ⚠️",
                        justify="center",
                    ),
                    title="Summary",
                    box=box.SIMPLE,
                    style="wheat1",
                    border_style="wheat1" + " bold",
                ),
                box=box.HORIZONTALS,
                border_style="bright_red",
                width=self.max_width,
            )
        )

    def unfinished_installation(self):
        """Displays a warning message indicating that the configuration did not finish correctly.

        This method prints a formatted panel to the console, alerting the user to an unfinished
        installation process. The message is styled with specific colors and borders to draw
        attention to the issue.

        Attributes:
            console: The console object used for printing messages.
        """
        self.console.print("\n")
        self.console.print(
            Panel.fit(
                Panel.fit(
                    Text(
                        "⚠️  The configuration didn't finished correctly ⚠️",
                        justify="center",
                    ),
                    title="Summary",
                    box=box.SIMPLE,
                    style="wheat1",
                    border_style="wheat1" + " bold",
                ),
                box=box.HORIZONTALS,
                border_style="bright_red",
                width=self.max_width,
            )
        )

    def ask(
        self,
        instruction: str,
        manager: "Installer",
        default="",
        password_mode=False,
    ) -> str:
        """Ask the user for input based on a given instruction.

        Args:
            instruction (str): The instruction or prompt to display to the user.
            manager (Installation): An instance of the Installation manager that may control input behavior.
            default (str, optional): The default value to use if the user does not provide input.
              Defaults to an empty string.
            password_mode (bool, optional): If True, the input will be treated as a password and not displayed.
              Defaults to False.

        Returns:
            str: The user's input or the default value if no input is provided.
        """

        if default:
            adjective = "generated" if password_mode else "default"
            password_help = Text(" (", style="turquoise2").append(
                f"press enter to use the {adjective} one:", style="grey50"
            )
            if manager.no_input_mode:
                return default
        else:
            password_help = ""

        value = Prompt.ask(
            Text("", style="bright_yellow")
            .append("❓ ")
            .append(instruction)
            .append(password_help),
            default=default,
            console=self.console,
            password=password_mode,
        )
        return value

    def confirm(
        self, instruction: str | Text, manager: "Installer", default: Optional[bool] = None
    ) -> bool:
        if manager.no_input_mode:
            if default is None:
                raise ValueError(
                    "Please supply a default value for the question, to work in no input mode"
                )
            return default
        if default is not None:
            return Confirm.ask(instruction, default=default)
        return Confirm.ask(instruction)

    def clear(self):
        """Clears the content of the 'live' attribute if it exists.

        This method checks if the 'live' attribute is present in the instance.
        If it is, it updates its content to an empty string and refreshes it.

        Attributes:
            live (optional): An attribute that is expected to have 'update'
            and 'refresh' methods.

        Returns:
            None
        """
        live = getattr(self, "live", None)
        if live is not None:
            live.update("")
            live.refresh()

    def render(self):
        """Render the content to the console or update the live display.

        This method checks if a live display is available. If it is, it creates a
        Panel with the current content and updates the live display. If not, it
        prints the last item of the content to the console.

        Attributes:
            live (Live): An optional live display object that can be updated.

        Raises:
            AttributeError: If 'live' attribute is not found on the instance.
        """

        live = getattr(self, "live", None)

        if live is not None:
            rendering = Panel(
                Group(*self.content),
                box=box.SIMPLE,
            )
            live.update(rendering)
            live.refresh()
        else:
            self.console.print(self.content[-1])

    def header(self, installation: "Installer"):
        """Creates and displays a header panel indicating the installation of Alyx configuration files.

        Args:
            installation (Installer): An instance of the Installer class containing configuration details,
                                          including the path where the configuration files will be created.

        Returns:
            None
        """
        self.console.print(
            Panel.fit(
                Text(
                    "Creating the folder and files necessary for docker building in ",
                    justify="center",
                ).append(
                    f"{installation.docker_build_path}",
                    style=self.items_style,
                ),
                title="⚙️  Installing alyx configuration files",
                box=box.HORIZONTALS,
                style=self.default_style,
                border_style=self.default_style + " bold",
                width=self.max_width,
            )
        )

    def show_panel(self, *content, title=None):
        self.console.print(
            Panel(Group(*content), box=box.ROUNDED, title=title, border_style="blue",expand=False)
        )

    def report_status(self, installation: "Installer"):
        """Reports the status of the given installation.

        This method checks the status of the provided installation and takes appropriate actions based on its state.
        If the installation status is an error, it calls `done_with_warnings()`.
        For unknown or unfinished error statuses, it calls `unfinished_installation()`.
        If the installation is successful, it calls `done()`.
        If the status is not recognized, it raises a `NotImplementedError`.

        Args:
            installation (Installation): The installation object whose status is to be reported.

        Raises:
            NotImplementedError: If the installation status is not recognized.
        """
        if installation.status == InstallStatus.ERROR:
            self.done_with_warnings()
        elif installation.status in [
            InstallStatus.UNKNOWN,
            InstallStatus.UNFINISHED_ERROR,
            InstallStatus.UNFINISHED,
        ]:
            self.unfinished_installation()
        elif installation.status == InstallStatus.SUCCESS:
            self.done()
        else:
            raise NotImplementedError

    def __enter__(self):
        """Context manager entry method.

        This method is called when entering the runtime context related to this object.
        If the object has a 'live' attribute, it will also call the `__enter__` method
        of that attribute.

        Returns:
            self: The instance of the class, allowing for method chaining.
        """
        live = getattr(self, "live", None)
        if live is not None:
            live.__enter__()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Handles the exit of a context manager.

        This method is called when the execution of a `with` statement is finished.
        It allows for cleanup actions to be performed, such as releasing resources
        or handling exceptions.

        Args:
            exc_type (type): The exception type raised in the `with` block,
                             or None if no exception was raised.
            exc_val (Exception): The exception instance raised in the `with` block,
                                 or None if no exception was raised.
            exc_tb (traceback): The traceback object associated with the exception,
                                or None if no exception was raised.

        Returns:
            None
        """
        live = getattr(self, "live", None)
        if live is not None:
            live.__exit__(exc_type, exc_val, exc_tb)
