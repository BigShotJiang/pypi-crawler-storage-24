import inspect
import os
import platform
import shutil  # import chown, copy2, rmtree
import subprocess
from argparse import Namespace
from os import PathLike
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, List, Optional, Tuple, Type, cast

from platformdirs import user_config_dir
from rich.text import Text

from ..utils import PROJECT_NAME, verify_outside_container
from .enums import InstallStatus
from .renderers import Renderer
from .stores import KeywordsStore

if TYPE_CHECKING:
    from .containers import Container
    from .files import File


def ressource_copy_function(function):
    function.is_a_ressource_copy_function = True
    return function


def _clean_gui_env() -> dict:
    env = os.environ.copy()
    # These are the usual culprits that break system apps’ Python plugin loading:
    for k in ("PYTHONPATH", "PYTHONHOME", "VIRTUAL_ENV"):
        env.pop(k, None)
    # Optional: also avoid venv bin taking precedence for spawned GUI apps
    # (keep if you want, remove if it breaks other things)
    # env["PATH"] = ":".join(p for p in env.get("PATH", "").split(":") if "alyx-local" not in p)
    return env


class Installer:
    keywords_store: KeywordsStore
    renderer: Renderer
    containers_classes: "List[Type[Container]]" = []
    files_classes: "List[Type[File]]" = []

    #### options settable from command line : ------------------------- ####

    # A flag indicating whether to enable delete mode. Defaults to False.
    delete: bool

    # A flag indicating whether to enable verbose output. Defaults to False.
    verbose: bool

    # A flag indicating whether to allow reconfiguration. Defaults to False.
    # reconfiguration consists of all the keys for the keywords config store,
    # being re-asked / recomputed, regardless of wether they are present in config, or not.
    reconfigure: bool

    # A flag indicating whether to enable no input mode. Defaults to False.
    no_input_mode: bool

    # A flag indicating whether to enable fix mode. Defaults to False.
    # fix mode forces the templated files to be rewritten from injected templates,
    # regardless of wether the file validator checked that the template injected versions
    # found on disk matched the one made on ram after populating them with keywords values.
    fix_mode: bool

    # A Flag to indicate wether or not the instance should automatically try to update
    # the config keys, or keep them as is. Defaults to false.
    # note that if some values are set with "reset_values" to define them manually,
    # they will still be savec, even if config_frozen is True.
    config_frozen: bool

    #### --------------------------------------------------------------- ####

    copy_ressource_functions: List[Callable[..., Tuple[str | None, str | None]]]

    important_folders = [
        "appdata_path",
        "docker_build_path",
        "data_path",
        "source_package_path",
        "docker_ressource_path",
    ]

    important_paths = ["config_file_path"] + important_folders

    @classmethod
    def from_cli_arguments(
        cls, cli_arguments: Namespace | dict[str, Any] | None = None, **kwargs
    ) -> "Installer":
        """Creates an instance of the class from the provided command line arguments.

        Args:
            cls (type): The class to instantiate.
            arguments (Namespace): An object containing command line arguments.

        Returns:
            cls: An instance of the class initialized with the specified arguments.

        Raises:
            Exception: If any required argument is missing or invalid.

        Notes:
            - The function modifies the `arguments` object based on certain conditions
              before passing it to the class constructor.
            - The `delete_noinput` argument, if set to True,
              will automatically set both `noinput` and `delete` to True.
        """

        arguments_dict: dict[str, Any] = dict(
            fix_mode=False,
            no_input_mode=False,
            inputs_only=False,
            copy_ressources=False,
            create_folders=False,
            reset_values={},
            reconfigure=False,
            config_frozen=False,
            delete=False,
            verbose=False,
        )

        implementation_to_cli_name_map: dict[str, str] = {
            "fix_mode": "fix",
            "no_input_mode": "noinput",
            "inputs_only": "inputs_only",
            "copy_ressources": "copy_ressources",
            "create_folders": "create_folders",
            "reset_values": "reset_values",
            "delete": "delete",
            "reconfigure": "force",
            "config_frozen": "config_frozen",
            "verbose": "verbose",
        }

        cli_group_to_implementation_equivalence: dict[str, dict[str, bool]] = {
            "delete_noinput": {"no_input_mode": True, "delete": True},
            "inputs_only": {"no_input_mode": False},
        }

        if cli_arguments is None:
            cli_arguments = Namespace()
        elif isinstance(cli_arguments, dict):
            cli_arguments = Namespace(**cast(dict[str, Any], cli_arguments))

        if not isinstance(cli_arguments, Namespace):
            raise TypeError

        for implementation_key in arguments_dict.keys():
            cli_key = implementation_to_cli_name_map[implementation_key]
            if hasattr(cli_arguments, cli_key):
                value = getattr(cli_arguments, cli_key)
                # secho(f"Found argument {cli_key}={value}, will set {implementation_key}={value} in namespace")
                arguments_dict[implementation_key] = value

        for cli_key in cli_group_to_implementation_equivalence.keys():
            if not getattr(cli_arguments, cli_key, False):
                # if the cli_key is not in cli_arguments or it is there,
                # but with a Falsy value, we skip this iteration of the loop
                continue

            for (
                implementation_key,
                implementation_value,
            ) in cli_group_to_implementation_equivalence[cli_key].items():
                # secho(f"Found argument {cli_key}={implementation_value}, will set {implementation_key}={implementation_value} in namespace")
                arguments_dict[implementation_key] = implementation_value

        # kwargs have priority over cli arguments. The rational is that "hardwritten" key value arguments
        # when calling this method, should be kept, despite user input, as the cli function calling this
        # method with hardcoded argument, had been designed with a specific functionnality in mind.
        arguments_dict.update(**kwargs)

        return cls(**arguments_dict)

    @classmethod
    def default_installer(cls) -> "Installer":
        return cls(copy_ressources=True, create_folders=True)

    def __str__(self):
        flags_to_insert = [
            "fix_mode",
            "no_input_mode",
            "inputs_only_mode",
            "reconfigure",
            "delete",
            "reset_values",
            "copy_ressources",
            "create_folders",
        ]
        string = f"<{self.__class__.__name__}> with flags : " + " ".join(
            [f"{flag}={getattr(self, flag)}" for flag in flags_to_insert]
        )
        string = string + f" verbose={self.renderer.verbose}"
        return string

    def __init__(
        self,
        renderer: Optional[Renderer] = None,
        *,
        fix_mode: bool = False,
        no_input_mode: bool = False,
        inputs_only: bool = False,
        copy_ressources: bool = False,
        create_folders: bool = False,
        reset_values: dict[str, str] = {},
        reconfigure: bool = False,
        config_frozen: bool = False,
        delete: bool = False,
        verbose: bool = False,
    ):
        """Initializes an instance of installer manager.

        By default, all arguments are False, leading to the run function do nothing.

        Args:
            renderer (Optional[Renderer]): An optional renderer instance. If not provided, a new Renderer
              will be created with the specified verbosity.
            fix_mode (bool): A flag indicating whether to enable fix mode. Defaults to False.
            no_input_mode (bool): A flag indicating whether to enable no input mode. Defaults to False.
            verbose (bool): A flag indicating whether to enable verbose output. Defaults to False.
            reconfigure (bool): A flag indicating whether to force reconfiguration from keyword getters. Defaults to False.
            delete (bool): A flag indicating whether to delete the installation configuration. Defaults to False.
        """

        self.renderer = Renderer(verbose=verbose) if renderer is None else renderer
        self.status: InstallStatus = InstallStatus.UNKNOWN

        self.keywords_store = KeywordsStore(manager=self)
        self.fix_mode = fix_mode
        self.no_input_mode = no_input_mode
        self.inputs_only_mode = inputs_only
        self.reconfigure = reconfigure
        self.config_frozen = config_frozen
        self.delete = delete
        self.reset_values = reset_values
        self.copy_ressources = copy_ressources
        self.create_folders = create_folders

        self.copy_ressource_functions = [
            method
            for method_name, method in inspect.getmembers(
                self, predicate=inspect.ismethod
            )
            if getattr(method, "is_a_ressource_copy_function", False)
        ]
        self.renderer.comment(self.copy_ressource_functions)
        self.renderer.comment(str(self))

    def __enter__(
        self,
    ) -> "Installer":
        """Context manager entry method.

        This method is called when entering the runtime context related to this object.
        It initializes the renderer and sets up the header.

        Returns:
            self: The instance of the class, allowing for method chaining.
        """
        self.renderer = self.renderer.__enter__()
        self.renderer.header(self)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Handles the exit of a context manager by reporting the status and delegating to the renderer's exit method.

        Args:
            exc_type (type): The exception type raised in the context, or None if no exception occurred.
            exc_val (Exception): The exception instance raised in the context, or None if no exception occurred.
            exc_tb (traceback): The traceback object associated with the exception, or None if no exception occurred.

        Returns:
            bool: Indicates whether the exception should be suppressed (True) or propagated (False).
        """
        self.renderer.report_status(self)
        self.renderer.__exit__(exc_type, exc_val, exc_tb)

    def PROJECT_NAME(self):
        return PROJECT_NAME

    @property
    def appdata_path(self) -> Path:
        if not hasattr(self, "_appdata_path"):
            config_dir = Path(user_config_dir(appname="alyx-local", appauthor=False))
            config_dir.mkdir(exist_ok=True, parents=True)
            self._appdata_path = config_dir
        return self._appdata_path

    @property
    def source_package_path(self) -> Path:
        """Returns the absolute path to the root directory of the project.

        This directory is expected to contain the `pyproject.toml` file and the `.git` directory.

        Returns:
            Path: The absolute path to the root directory.
        """
        import alyx

        alyx_module_path = alyx.__file__
        if alyx_module_path is None:
            raise RuntimeError("Could not resolve the path of alyx's module")

        return Path(alyx_module_path).parent.resolve()

    @property
    def docker_ressource_path(self) -> Path:
        """Returns the path to the Docker installation directory.

        This method constructs the path by appending "ressources/docker" to the
        source package path of the instance.

        Returns:
            Path: The full path to the Docker installation directory.
        """
        return self.source_package_path / "ressources" / "docker"

    @property
    def docker_build_path(self) -> Path:
        """Returns the path to the configuration directory.

        This method constructs the path to the 'config' directory
        by appending it to the install root path.

        Returns:
            Path: The full path to the configuration directory.
        """
        if not hasattr(self, "_docker_build_path"):
            self._docker_build_path = Path(
                self.keywords_store["DOCKER_BUILD_PATH"]
            ).resolve()
        return self._docker_build_path

    @property
    def data_path(self) -> Path:
        if not hasattr(self, "_data_path"):
            self._data_path = Path(self.keywords_store["DJANGO_DATA_PATH"]).resolve()
        return self._data_path

    @property
    def config_file_path(self) -> Path:
        return self.keywords_store.path

    @property
    def containers(self) -> "List[Container]":
        """Returns a list of container instances.

        This method initializes the `_containers` attribute with instances of
        container classes defined in `containers_classes` if it has not been
        initialized yet. It then returns the list of container instances.

        Returns:
            List[Container]: A list of container instances.
        """
        if not hasattr(self, "_containers"):
            self._containers = [cls(self) for cls in self.containers_classes]
        return self._containers

    @property
    def files(self) -> "List[File]":
        """Retrieve a list of file instances.

        This method checks if the instance has a cached list of file instances.
        If not, it creates the list by instantiating each class defined in
        `files_classes` and stores it in the `_files` attribute.

        Returns:
            list: A list of instantiated file objects.
        """
        if not hasattr(self, "_files"):
            self._files = [cls(self) for cls in self.files_classes]
        return self._files

    def populate_keywords_store(self) -> "Installer":

        self.keywords_store.validate_keywords_list()
        self.keywords_store.populate()

        if not self.keywords_store.keywords_list.issubset(self.keywords_store.keys()):
            raise ValueError(
                "Your configuration is not complete, the config misses some keys "
                "after performing populate(). Please run the CLI command : alyx configuration define-keywords"
            )

        self.status = InstallStatus.UNFINISHED

        return self

    def delete_configuration(self):
        """Deletes the configuration folder and its contents.

        This method prompts the user for confirmation before proceeding with the deletion of the configuration folder.
        If the folder does not exist, a success message is displayed indicating that there is no
        configuration to remove. If the user confirms the deletion, all files and subdirectories within the
        configuration folder are removed recursively.

        Raises:
            KeyboardInterrupt: If the user does not confirm the deletion when prompted.

        Returns:
            None
        """

        def empty_folder_content(folder: Path):
            [file.unlink() for file in folder.iterdir() if file.is_file()]
            [
                empty_folder_content(subfolder)
                for subfolder in folder.iterdir()
                if subfolder.is_dir()
            ]
            folder.rmdir()

        self.renderer.title("Configuration complete deletion", style="bright_red")

        if not self.docker_build_path.exists():
            self.renderer.success("No docker build folder to remove. Done.")
            return

        if self.no_input_mode or self.renderer.confirm(
            Text(
                "⚠️ ⚠️ ⚠️  Are you sure that you want to reset the configuration at ",
                style="bright_red",
            )
            .append(f"{self.docker_build_path}", self.renderer.items_style)
            .append(
                " ?\nPrevious configuration data in the form of ANY file in this folder "
            )
            .append("WILL BE LOST FOREVER !!!", style="yellow"),
            manager=self,
        ):
            empty_folder_content(self.docker_build_path)
            self.renderer.success("Removed all previous configuration")
        else:
            raise KeyboardInterrupt(
                "The configuration process was stopped because you added a --delete "
                "option but didn't confirm the deletion when asked for."
            )

    def copy_ressources_to_end_location(self):

        for copy_ressource_function in self.copy_ressource_functions:
            source_path, destination_path = copy_ressource_function()
            if source_path is not None and destination_path is not None:
                shutil.copy2(source_path, destination_path)
                self.renderer.print(
                    f"Successfully copied {Path(source_path).name} from ressources folder to it's "
                    f"destination ({Path(destination_path).parent}) before running config parsing",
                    style="green",
                )

    def create_data_folder(self) -> None:
        """Creates a data folder structure for shared and persistent data.

        This method initializes a main data folder at the specified installation root path,
        and creates subfolders for backups, logs, and tables. If a subfolder already exists,
        it notifies the user that the folder will not be created. Upon successful creation
        of each folder, a success message is displayed.

        Attributes:
            renderer: An object responsible for rendering messages to the user.

        Returns:
            None
        """

        self.renderer.title(
            "folders for shared and persistent data through containers and host"
        )
        # app_username = self.keywords_store["PERMISIONED_USERNAME"]
        data_folder = self.data_path
        sub_folders_to_create = ["backups", "logs", "tables"]
        for foldername in sub_folders_to_create:
            folder = data_folder / foldername
            if folder.is_dir():
                self.renderer.wont_create(folder)
                # self.chown(folder, app_username)
                continue
            folder.mkdir(parents=True)
            # self.chown(folder, app_username)
            self.renderer.success(f"Created empty folder {folder} for docker copying")
        self.renderer.success("All good")

    def install_from_templates(self):
        """Installs the necessary components and updates the installation status.

        This method validates the keywords list, populates the keywords store, and installs
        all containers and files associated with the current instance. It also manages the
        reconfiguration state and updates the installation status based on predefined conditions.

        Attributes:
            reconfigure (bool): Indicates whether the installation should be reconfigured.
            containers (list): A list of container objects to be installed.
            files (list): A list of file objects to be installed.
            status (InstallStatus): The current status of the installation process.

        Raises:
            Any exceptions raised during the installation of containers or files will propagate
            to the caller.
        """

        # make sure the keywords store has been populated
        if not self.keywords_store.populated:
            self.populate_keywords_store()

        for container in self.containers:
            container.install()
        for file in self.files:
            file.install()

    def check(self) -> dict[str, bool]:

        # make sure the keywords store has been populated
        if not self.keywords_store.populated:
            self.populate_keywords_store()

        file_statuses = {}
        for container in self.containers:
            file_statuses.update(container.check())
        for file in self.files:
            file_statuses[str(file.destination_path)] = file.check()

        return file_statuses

    def get_keywords_config_status(self):
        self.keywords_store.validate_keywords_list().load()
        key_validity = {
            keyword: keyword in self.keywords_store.keys()
            for keyword in sorted(
                self.keywords_store.keywords_list.union(set(self.keywords_store.keys()))
            )
        }
        return key_validity

    @verify_outside_container
    def run(self) -> "Installer":
        "Create files and folders necessary for a sucessfull build of the docker containers."

        with self:
            # populate_keywords_store do not "do" template injection or copy actions
            # on templated files yet, but it parses them to retrieve and cache the
            # config keywords's value accordingly, in the config.json file.
            # (which is just a memory for our config keywords values pairs)
            self.populate_keywords_store()

            if self.inputs_only_mode:
                # if the installer is in inputs_only_mode, we finish here, and return, after setting the status for
                # displaying usefull info tu the user.
                return self

            # Before doing anything, we check if the installer's mode asks us to delete or copy anything.
            if self.delete:
                self.delete_configuration()

            # If setup to do so, we copy ressources files to user defined locations.
            if self.copy_ressources:
                self.copy_ressources_to_end_location()

            # once we asked everything, we set reconfigure to False if it was True, to avoid re-asking answers again
            self.reconfigure = False

            # create_data_folder must be running after the keywords store has been populated, as the location
            # of data_path can be changed via keyword configuration.
            if self.create_folders:
                self.create_data_folder()

            # The we proceed the the actual template injection and copying of files, for all container and files
            # declared in the installation manager.
            self.install_from_templates()

            if self.status == InstallStatus.UNFINISHED_ERROR:
                self.status = InstallStatus.ERROR
            if (
                self.status == InstallStatus.UNKNOWN
                or self.status == InstallStatus.UNFINISHED
            ):
                self.status = InstallStatus.SUCCESS

        return self

    @staticmethod
    def generate_password(
        length: int = 15, chars="[a-Z][0-9]!%^&-_+", alphanum=False
    ) -> str:
        """Generate a random password of specified length using given character set.

        Args:
            length (int, optional): The length of the generated password. Defaults to 15.
            chars (str, optional): A string representing the characters to use in the password.
                It can include placeholders like "[a-Z]", "[0-9]", "[A-Z]", and "[a-z]".
                Defaults to "[a-Z][0-9]!%^&-_+".
            alphanum (bool, optional): If True, the character set will be limited to alphanumeric
                characters only (equivalent to "[a-Z][0-9]"). Defaults to False.

        Returns:
            str: A randomly generated password of the specified length.
        """
        from django.utils.crypto import get_random_string

        if alphanum:  # boolean flag shortcut for "[a-Z][0-9]"
            chars = "[a-Z][0-9]"

        latin_alphabet = "abcdefghijklmnopqrstuvwxyz"
        numbers = "1234567890"

        if "[a-Z]" in chars:
            chars = chars.replace("[a-Z]", latin_alphabet + latin_alphabet.upper())

        if "[a-z]" in chars:
            chars = chars.replace("[a-z]", latin_alphabet)

        if "[A-Z]" in chars:
            chars = chars.replace("[A-Z]", latin_alphabet.upper())

        if "[0-9]" in chars:
            chars = chars.replace("[0-9]", numbers)

        return get_random_string(length, chars)

    @staticmethod
    def chown(folder: PathLike, app_username: str):
        raise NotImplementedError("deprecated method")
        if os.name == "posix":  # Unix
            shutil.chown(str(folder), user=app_username, group=app_username)
        elif os.name == "nt":  # Windows
            subprocess.check_call(
                ["icacls", str(folder), "/grant", f"{app_username}:(F)"]
            )
        else:
            raise NotImplementedError("")
        return

    def open_folder(self, foldername: str) -> "Installer":
        path = str(self._get_folder_from_name(foldername))

        self.renderer.print(
            Text("Opening folder ", style="blue")
            .append(f"{foldername}", style="yellow")
            .append(" at ")
            .append(f"{path}", style="yellow")
        )

        if platform.system() == "Windows":
            os.startfile(path)  # ty:ignore[unresolved-attribute]
        elif platform.system() == "Darwin":
            subprocess.run(["open", path], shell=True)
        else:
            if shutil.which("gio"):
                cmd = ["gio", "open", path]
            else:
                cmd = ["xdg-open", path]
            subprocess.run(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True,
                close_fds=True,
            )
        return self

    def delete_folder(self, foldername: str, confirm=False) -> "Installer":
        path = self._get_folder_from_name(foldername)

        if not path.is_dir():
            self.renderer.print(
                f"Folder {foldername} at {path} already doesn't exist", style="yellow"
            )
            return self

        self.renderer.print(
            Text("This operation will delete folder ", style="red")
            .append(f"{foldername}", style="yellow")
            .append(" at ")
            .append(f"{path}", style="yellow")
        )

        if not confirm:
            confirm = self.renderer.confirm(
                "Are you sure you want to delete the "
                f"entire folder, located at {path} ? "
                "Many files and all your configured keywords will be lost",
                manager=self,
            )
        if confirm:
            shutil.rmtree(path)
            self.renderer.print("Deletion done", style="red")

        return self

    def _get_folder_from_name(self, foldername: str) -> Path:
        if foldername not in self.important_folders:
            raise ValueError(
                f"the folder {foldername} does not exists, it must be one of "
                f"the following names : {self.important_folders}"
            )
        path = getattr(self, foldername)
        if not isinstance(path, Path):
            raise TypeError(
                f"{path} is not of the expected type : Path, but instead {type(path)}"
            )
        return path
