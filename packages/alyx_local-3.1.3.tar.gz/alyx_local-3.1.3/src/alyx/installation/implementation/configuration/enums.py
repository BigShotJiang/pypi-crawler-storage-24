from enum import Enum


class FileAction(Enum):
    CREATE_FILE = True
    LET_FILE = False


class FileStatus(Enum):
    FILE_ERROR = True
    FILE_OK = False


class InstallStatus(Enum):
    UNKNOWN = 0
    SUCCESS = 1
    ERROR = 2
    UNFINISHED_ERROR = 3
    UNFINISHED = 4


class InvalidFilePolicy(Enum):
    DO_NOTHING = 0
    RECREATE = 1


class VerifStatus(Enum):
    NO_ERROR = 0
    PLAIN_LINE_IDENTICAL = 1
    PATTERNED_LINE_IDENTICAL = 2
    PLAIN_LINE_ALTERED = 3
    PATTERNED_LINE_ALTERED = 4
    PATTERNED_LINE_UNVERIFIABLE = 5
    UNDETERMINATED_ERROR = 6
    TEMPLATE_LONGER_THAN_CONFIG = 7
    TEMPLATE_SHORTER_THAN_CONFIG = 8