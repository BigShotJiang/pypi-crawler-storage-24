from rich_click import group, option, get_current_context, Context

from ...implementation.configuration import DockerConfigInstaller
from .utils import rich_valid_table

from typing import cast

@group("installation")
def installation_command_group():
    """Create, and edit necessary files and variables for a sucessfull build of the docker containers"""


@installation_command_group.command("create")
@option("-v", "--verbose", is_flag=True, help="Increase output verbosity")
@option(
    "-f",
    "--fix",
    is_flag=True,
    help="Force rewriting all templated files by rewriting them from scratch if any error is found. "
    "Be careful to not use this command if you want to ensure you keep valuable "
    "settings written in the files located in the config folder.",
)
@option(
    "--delete-noinput",
    is_flag=True,
    help="Completely delete any previous configuration file, without asking for confirmation. "
    "Be careful, this is a permanent data deletion operation and you "
    "can lose valuable settings written in the files located in the config folder.",
)
@option(
    "--noinput",
    is_flag=True,
    help="Runs the configuration in no input mode, meaning that all operations that normally ask the user for "
    "an input will auto-complete, using default values for usernames and generated ones for passwords.",
)
@option(
    "--force",
    is_flag=True,
    help="Runs the configuration asking every information that can be entered, again.",
)
@option(
    "--inputs-only",
    is_flag=True,
    help="Makes the configuration input_fields.json file only.",
)
def create_install_command(
    verbose: bool = False,
    fix: bool = False,
    delete: bool = False,
    delete_noinput: bool = False,
    noinput: bool = False,
    force: bool = False,
    inputs_only: bool = False,
):
    """Initializes the files and folders needed, for the current configuration.
    In this process it can eventually 
    asks for the values that require user input, or use the defaults.
    Then it parses the templated files to 
    inject the configured value in them, vefix_moderifying if previously injected filed
    have outdated overall template shape or configured values, to rebuild them only if necessary."""

    context = cast(Context, get_current_context(False))
    DockerConfigInstaller.from_cli_arguments(
        context.params, copy_ressources=True, create_folders=True
    ).run()

@installation_command_group.command("delete")
@option("-y", "--yes", is_flag=True, help="Confirms deleting without asking through a prompt")
def delete_install_command(yes : bool = False):
    """Deletes docker build configured files (templace injected) """
    
    DockerConfigInstaller().delete_folder("docker_build_path",confirm=yes)


@installation_command_group.command("check")
def check_install_commang():
    """Verify that templeted files are up to date, but doesn't ask keywords if some are missing."""

    installation = DockerConfigInstaller(config_frozen=True)
    files_status= installation.check()
    table = rich_valid_table(files_status, title = "Files status", column_titles = ["File","Is Valid"])

    installation.renderer.print(table)

    missing_count = list(files_status.values()).count(False)
    if missing_count :
        installation.renderer.print(f"❌ Your installation has {missing_count} invalid files", style = "yellow")
    else :
        installation.renderer.print(f"✅ Your config is healthy, all {len(files_status)} files are valid", style = "green")
