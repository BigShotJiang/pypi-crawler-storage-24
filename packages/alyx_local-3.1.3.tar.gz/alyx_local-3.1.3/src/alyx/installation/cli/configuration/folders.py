from rich_click import group, argument, option, Choice
from rich.table import Table
from rich.text import Text
from rich import box

from ...implementation.configuration import DockerConfigInstaller

@group("folders")
def folders_command_group():
    """Usefull commands related to your installtion folders, to locate them and manage them"
    ": listing, opening, and deletion of folders is proposed with the commands below."""

@folders_command_group.command("open")
@argument("folder", type=Choice(DockerConfigInstaller.important_folders))
def open_folder_command(folder: str):
    """Open a specified folder using the Docker installation."""

    installation = DockerConfigInstaller()
    installation.open_folder(folder)

@folders_command_group.command("list")
def list_folders_command():
    """Lists the `names` of the folders that are used for docker configuration, building, 
    and istallation, as well as shows their associated paths on your system"""
    
    installation = DockerConfigInstaller()

    table = Table(
        "Name",
        "Path",
        show_header=True,
        box=box.SIMPLE,
        show_lines=True,
        pad_edge=False,
        style="blue",
        title=Text(
            "Alyx user configuration keyword values file path",
            style="bold blue",
        ),
    )

    table.add_row(
        Text("• config_file_path", style="green"),
        Text(f"{installation.config_file_path}", style="cyan"),
    )
    installation.renderer.show_panel(table)
    
    table = Table(
        "Name",
        "Path",
        show_header=True,
        box=box.SIMPLE,
        show_lines=True,
        pad_edge=False,
        style="blue",
        title=Text(
            "Alyx important folders for docker build and django functionning",
            style="bold blue",
        ),
    )

    for folder_name in installation.important_folders:
        table.add_row(
            Text(f"• {folder_name}", style="green"),
            Text(f"{getattr(installation, folder_name)}", style="cyan"),
        )
    installation.renderer.show_panel(table)

   

@folders_command_group.command('delete')
@argument("folder", type=Choice(DockerConfigInstaller.important_folders))
@option("-y", "--yes", is_flag=True, help="Confirms deleting without asking through a prompt")
def delete_folder_command(folder_name : str, yes : bool = False):
    """Deletes an entire folder, using it's folder name (check "
    "the names with the command [blue]alyx configuration folders list[/blue])"""

    DockerConfigInstaller().delete_folder(folder_name,confirm=yes)