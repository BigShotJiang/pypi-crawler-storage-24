from rich_click import group
from .containers import container_command_group
from .project import containers_command_group
from .clean import clean_command_group

@group("docker")
def docker_command_group():
    """Interact with docker API, selectively for alyx related containers, and volumes. (leaving other projects safe)"""

docker_command_group.add_command(container_command_group)
docker_command_group.add_command(containers_command_group)
docker_command_group.add_command(clean_command_group)