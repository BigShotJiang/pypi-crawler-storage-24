from rich_click import group, option, argument, Choice

from ...implementation.docker.utils import clean_docker_unused_assets, clean_docker_build_cache, EXISTING_VOLUME_NAMES
from ...implementation.docker.volumes import volume_action

from typing import Optional

@group("clean")
def clean_command_group():
    """Group of commands to clean docker dangling assets"""


@clean_command_group.command("unused")
@option(
    "--remove-volumes/--keep-volumes",
    default=True,
    help="Clean all unused images / volumes that are left in docker. "
    "Take care as this will remove data, possibly even beyond "
    "the scope of alyx's containers (if you have other docker containers on your system)",
)
def clean_images_command(remove_volumes: bool):
    clean_docker_unused_assets(remove_volumes)

@clean_command_group.command("build-cache")
@option(
    "--yes", "-y",
    required=False,
    is_flag=True,
    help="Confirms deletion directly"
)
def clean_build_cache_command(yes : bool):
    clean_docker_build_cache(yes)

@clean_command_group.command("volume")
@argument(
    "volume_name",
    required=False,
    default=None,
    type=Choice(EXISTING_VOLUME_NAMES),
)
def clean_volumes_command(volume_name : Optional[str]):
    volume_action(volume_name , "delete")