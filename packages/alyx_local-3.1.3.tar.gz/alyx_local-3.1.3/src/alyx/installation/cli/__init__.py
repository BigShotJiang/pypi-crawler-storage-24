from rich_click import group, rich_click
from .configuration import configuration_command_group
from .docker import docker_command_group
from .docs import mkdocs_command
from .utils import utils_command_group, launch_command, uninstall_command
from .manage import manage_command

rich_click.USE_RICH_MARKUP = True

@group()
def alyx():
    """This command line interface (CLI) command acts as a hub for 
    multiple alyx related commands. 
    
    They allows you to configure your installation,
    manage your containers and django server, as well as provides helpers
    for various functions such as serving or building documentation with mkdocs.
    Enter a subcommand below with the --help flag, to see it's help message."""


alyx.add_command(configuration_command_group)
alyx.add_command(docker_command_group)
alyx.add_command(manage_command)
alyx.add_command(mkdocs_command)
alyx.add_command(utils_command_group)
alyx.add_command(launch_command)
alyx.add_command(uninstall_command)