from rich_click import command, argument, pass_context, Context, Choice

from ..implementation.docs import mkdocs

from typing import Literal

@command(
    "documentation",
    context_settings=dict(
        ignore_unknown_options=True,
        allow_extra_args=True,
        allow_interspersed_args=False,
    ),
    add_help_option=False,
)
@argument(
    "action",
    required=False,
    default="serve",
    type=Choice(["serve"]),
)
@pass_context
def mkdocs_command(context: Context, action : Literal["serve"] = "serve"):
    """Starts a local MkDocs server to serve documentation.

    This function constructs a shell command to run MkDocs using the specified
    configuration file and executes it. The MkDocs server will be started in
    the current environment.
    """
    args = context.args
    mkdocs(action, args)

