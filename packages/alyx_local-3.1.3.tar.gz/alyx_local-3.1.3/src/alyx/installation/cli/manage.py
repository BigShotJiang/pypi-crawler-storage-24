from rich_click import Context, command, option, pass_context

from ..implementation.manage import manage


@command(
    "manage",
    context_settings=dict(
        ignore_unknown_options=True, allow_extra_args=True, help_option_names=[]
    ),
)
@option(
    "--internal",
    is_flag=True,
    help="Force running the manage ocmmand in an internal way, without trying to detect wether being "
    "called from outside or inside a docker container.",
)
@option(
    "--help",
    is_flag=True,
    help="Shows this help or the help relative to the django manage command, if supplied.",
)
@pass_context
def manage_command(context: Context, internal: bool = False, help: bool = False):
    """Manage the execution of Django CLI commands either within a Docker container or directly on the host.

    This function constructs a shell command to run a Django management script based on whether it is
    executed inside a Docker container or not.
    It captures the arguments from the context, formats them for shell execution,
    and then runs the command while providing feedback to the user.
    """
    args = context.args

    if help:
        if args:
            # if help was asked without django command, give click help
            args.append("--help")
        else:
            # Otherwise, ask for django to print the help of the command required
            return context.get_help()

    manage(args, internal=internal)
