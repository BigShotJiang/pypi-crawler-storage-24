from django.apps import AppConfig
import structlog

logger = structlog.get_logger("alyx.subjects_app")


class SubjectsConfig(AppConfig):
    name = "alyx.subjects"
    verbose_name = "Subject admin"
    label = "subjects"

    def ready(self):
        logger.debug("SUBJECTS APP IS READY")
