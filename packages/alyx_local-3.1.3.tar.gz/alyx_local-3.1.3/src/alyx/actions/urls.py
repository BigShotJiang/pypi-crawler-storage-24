from django.conf.urls import include
from django.urls import path

from .api import (
    LabLocationAPIDetails,
    LabLocationList,
    ProcedureTypeList,
    SessionAPIDetail,
    SessionAPIDetailByName,
    SessionAPIList,
    SurgeriesList,
    WaterAdministrationAPIDetail,
    WaterAdministrationAPIListCreate,
    WaterRequirement,
    WaterRestrictionList,
    WaterTypeList,
    WeighingAPIDetail,
    WeighingAPIListCreate,
)
from .results_manager.views import SendImageView, ServeImagesView
from .views import (
    training_perf_plot,
    weighing_plot,
)
from .views.history import (
    SubjectHistoryListView,
    TrainingHistoryListView,
    TrainingListView,
    WaterHistoryListView,
)

api_urls = [
    path("locations", LabLocationList.as_view(), name="location-list"),
    path(
        "locations/<str:name>", LabLocationAPIDetails.as_view(), name="location-detail"
    ),
    path("procedures", ProcedureTypeList.as_view(), name="procedures-list"),
    path("sessions", SessionAPIList.as_view(), name="session-list"),
    path("sessions/<uuid:pk>", SessionAPIDetail.as_view(), name="session-detail"),
    path(
        "sessions/<path:name>",
        SessionAPIDetailByName.as_view(),
        name="session-detail-by-name",
    ),
    path("surgeries", SurgeriesList.as_view(), name="surgeries-list"),
    path(
        "water-administrations",
        WaterAdministrationAPIListCreate.as_view(),
        name="water-administration-create",
    ),
    path(
        "water-administrations/<uuid:pk>",
        WaterAdministrationAPIDetail.as_view(),
        name="water-administration-detail",
    ),
    path(
        "water-requirement/<str:name>",
        WaterRequirement.as_view(),
        name="water-requirement",
    ),
    path(
        "water-restriction",
        WaterRestrictionList.as_view(),
        name="water-restriction-list",
    ),
    path("water-type", WaterTypeList.as_view(), name="watertype-list"),
    # path("water-type/<str:name>", WaterTypeList.as_view(), name="watertype-detail"),
    path("weighings", WeighingAPIListCreate.as_view(), name="weighing-create"),
    path("weighings/<uuid:pk>", WeighingAPIDetail.as_view(), name="weighing-detail"),
    path(
        "results-manager/figures/<uuid:pk>",
        ServeImagesView.as_view(),
        name="results-manager-figures",
    ),
    path(
        "results-manager/figure/<path:path>/",
        SendImageView.as_view(),
        name="results-manager-send-figure",
    ),
]

views_urls = [
    path(
        "admin-actions/weighing-plot/<uuid:subject_id>",
        weighing_plot,
        name="weighing-plot",
    ),
    path(
        "admin-actions/training-perf-plot/<uuid:subject_id>",
        training_perf_plot,
        name="training-perf-plot",
    ),
    path(
        "admin-actions/water-history/<uuid:subject_id>",
        WaterHistoryListView.as_view(),
        name="water-history",
    ),
    path(
        "admin-actions/training-history/<uuid:subject_id>",
        TrainingHistoryListView.as_view(),
        name="training-history",
    ),
    path(
        "admin-actions/training/",
        TrainingListView.as_view(),
        name="training",
    ),
    path(
        "admin-actions/training/<date>",
        TrainingListView.as_view(),
        name="training",
    ),
    path(
        "admin-actions/subject-history/<uuid:subject_id>",
        SubjectHistoryListView.as_view(),
        name="subject-history",
    ),
]

urlpatterns = [path("", include(views_urls)), path("api/", include(api_urls))]
