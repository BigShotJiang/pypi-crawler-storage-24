from django.http import HttpResponse

from .water_control import water_control
from .training_control import training_control

import structlog
logger = structlog.get_logger("actions.views")

def training_perf_plot(request, subject_id=None):
    from ...subjects.models import Subject
    if not request.user.is_authenticated:
        return HttpResponse("")
    if subject_id in (None, "None"):
        return HttpResponse("")
    wc = training_control(Subject.objects.get(pk=subject_id))
    return wc.plot()

def weighing_plot(request, subject_id=None):
    from ...subjects.models import Subject
    if not request.user.is_authenticated:
        return HttpResponse("")
    if subject_id in (None, "None"):
        return HttpResponse("")
    wc = water_control(Subject.objects.get(pk=subject_id))
    return wc.plot()
