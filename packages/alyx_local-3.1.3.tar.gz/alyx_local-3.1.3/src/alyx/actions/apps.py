from django.apps import AppConfig
import structlog

logger = structlog.get_logger("alyx.action_app")


class ActionsConfig(AppConfig):
    name = "alyx.actions"
    verbose_name = "Action admin"
    label = "actions"

    def ready(self):
        logger.debug("ACTIONS APP IS READY")
