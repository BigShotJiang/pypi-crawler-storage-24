import json
import os
import urllib.parse
from mimetypes import guess_type
from pathlib import Path

import requests

# from one.remote.aws import get_s3_virtual_host
from django.contrib.auth import get_user_model
from django.http import (
    FileResponse,
    HttpResponseNotFound,
    HttpResponseRedirect,
    JsonResponse,
)
from drf_spectacular.utils import OpenApiResponse, OpenApiTypes, extend_schema
from rest_framework.generics import ListCreateAPIView, RetrieveUpdateDestroyAPIView
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.viewsets import ReadOnlyModelViewSet

from ..base.filters import BaseFilterSet
from ..base.permissions import rest_permission_classes
from ..base.settings import MEDIA_ROOT, TABLES_ROOT
from ..data.models import Tag
from .filters import LabFilter
from .models import Lab, Note
from .serializers import (
    CacheDownloadSerializer,
    CacheVersionSerializer,
    LabSerializer,
    NoteSerializer,
    ServerInfoSerializer,
    UserSerializer,
)


class UserViewSet(ReadOnlyModelViewSet):
    """
    Lists all users with the subjects which they are responsible for.
    """

    queryset = get_user_model().objects.all()
    queryset = UserSerializer.setup_eager_loading(queryset)
    serializer_class = UserSerializer
    lookup_field = "username"
    permission_classes = rest_permission_classes()


class LabList(ListCreateAPIView):
    queryset = Lab.objects.all()
    serializer_class = LabSerializer
    permission_classes = rest_permission_classes()
    lookup_field = "name"
    filterset_class = LabFilter


class LabDetail(RetrieveUpdateDestroyAPIView):
    queryset = Lab.objects.all()
    serializer_class = LabSerializer
    permission_classes = rest_permission_classes()
    lookup_field = "name"


class NoteList(ListCreateAPIView):
    """
    post:
    If an image is provided, the request body can contain an additional item

    `width`: desired width to resize the image for storage. Aspect ratio will be maintained.
    Options are

    - **None** to use the UPLOADED_IMAGE_WIDTH specified in settings (default)
    - **'orig'** to keep original image size
    - any **integer** to specify the image width
    """

    queryset = Note.objects.all()
    serializer_class = NoteSerializer
    permission_classes = rest_permission_classes()
    filterset_class = BaseFilterSet


class NoteDetail(RetrieveUpdateDestroyAPIView):
    queryset = Note.objects.all()
    serializer_class = NoteSerializer
    permission_classes = rest_permission_classes()


class MediaView(APIView):
    permission_classes = rest_permission_classes()

    @extend_schema(
        request=None,
        responses={
            200: OpenApiResponse(
                response=OpenApiTypes.BINARY, description="Binary file response"
            ),
            404: OpenApiResponse(description="Not found"),
        },
        exclude=False,  # set True if you want to hide it from schema entirely
    )
    def get(self, request=None, format=None, img_url=""):
        path = os.path.join(MEDIA_ROOT, img_url)
        # return HttpResponse(path)

        if os.path.exists(path):
            content_type, _ = guess_type(path)
            if content_type is None:
                content_type = "application/octet-stream"
            return FileResponse(open(path, "rb"), content_type=content_type)
        else:
            return HttpResponseNotFound(f"Media not found at {path}")


def _get_cache_info(tag=None):
    """
    Load and return the cache info JSON file. Contains information such as cache table timestamp,
    size and API version.

    Assumes the following folder structure:
    <TABLES_ROOT>/
    ├─ cache_info.json
    ├─ cache.zip
    ├─ <DATASET_TAG_1>/
    │  ├─ cache_info.json
    │  ├─ cache.zip

    :param: optional tag name for fetching a specific cache
    :return: dict of cache table information
    """
    META_NAME = "cache_info.json"
    parsed = urllib.parse.urlparse(TABLES_ROOT)

    if tag:  # Validate
        Tag.objects.get(name=tag)

    scheme = parsed.scheme or "file"  # NB: 'file' only supported on POSIX filesystems
    if scheme == "file":
        # Cache table is local
        file_json_cache = Path(TABLES_ROOT).joinpath(tag or "", META_NAME)
        with open(file_json_cache) as fid:
            cache_info = json.load(fid)
    elif scheme.startswith("http"):
        cache_root = TABLES_ROOT.strip("/") + (f"/{tag}" if tag else "")
        file_json_cache = f"{cache_root}/{META_NAME}"
        resp = requests.get(file_json_cache)
        resp.raise_for_status()
        cache_info = resp.json()
        if "location" not in cache_info:
            cache_info["location"] = cache_root + "/cache.zip"
    else:
        raise ValueError(f'Unsupported URI scheme "{scheme}"')

    return cache_info


class ServerInfoView(APIView):
    permission_classes = rest_permission_classes()
    serializer_class = ServerInfoSerializer

    def get(self, request, *args, **kwargs):
        serializer = ServerInfoSerializer(instance={})
        return Response(serializer.data)


class CacheVersionView(APIView):
    permission_classes = rest_permission_classes()
    serializer_class = CacheVersionSerializer

    def get(self, request=None, tag=None, **kwargs):
        try:
            return JsonResponse(_get_cache_info(tag))
        except Exception as ex:
            return HttpResponseNotFound(str(ex))


class CacheDownloadView(APIView):
    permission_classes = rest_permission_classes()
    serializer_class = CacheDownloadSerializer

    def get(self, request=None, **kwargs):
        if TABLES_ROOT.startswith("http"):
            response = HttpResponseRedirect(TABLES_ROOT.strip("/") + "/cache.zip")
        else:
            cache_file = Path(TABLES_ROOT).joinpath("cache.zip")
            response = FileResponse(open(cache_file, "br"))
        return response
