from django.apps import AppConfig
import structlog

logger = structlog.get_logger("alyx.misc_app")


class MiscConfig(AppConfig):
    name = "alyx.misc"
    label = "misc"

    def ready(self):
        logger.debug("MISC APP IS READY")
