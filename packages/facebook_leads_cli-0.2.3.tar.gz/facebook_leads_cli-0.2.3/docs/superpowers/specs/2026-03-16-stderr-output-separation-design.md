# Design: stderr Output Separation for Facebook CLI

**Date:** 2026-03-16
**Status:** Approved
**Scope:** `src/fb.py`

## Problem Statement

The Facebook CLI prints status/progress messages to stdout, which contaminates JSON output when piping to other tools. This breaks automation pipelines that expect clean JSON from `fb leads fetch --json`.

**Current behavior:**
```bash
$ fb leads fetch --json
Fetching leads from the past 7 days...

✓ Fetched 46 lead(s)

[{"id": "123", "email": "test@example.com"}, ...]
```

The status lines break JSON parsing.

## Solution

Send all status/progress messages to stderr while keeping data output (JSON, formatted tables) on stdout. This follows Unix conventions:

- **stdout** = data output (JSON arrays, formatted tables)
- **stderr** = logs, progress, errors, diagnostics

## Implementation

### Changes to `src/fb.py`

Add `file=sys.stderr` to all status/informational `print()` calls.

#### `cmd_leads_fetch` (lines 182-208)

Status and progress messages to stderr:
- Line 188: `print(f"Fetching leads from the past {days} days...")`
- Line 193: `print("No leads found.")` - when no results
- Line 196: `print(f"✓ Fetched {len(leads)} lead(s)\n")`

```python
print(f"Fetching leads from the past {days} days (limit: {limit} per form)...\n", file=sys.stderr)
# ... if no leads:
print("No leads found.", file=sys.stderr)
# ... else:
print(f"✓ Fetched {len(leads)} lead(s)\n", file=sys.stderr)
```

#### `cmd_leads_list` (lines 210-244)

Status and progress messages to stderr:
- Line 225: `print(f"Fetching leads from form {args.form}...")`
- Line 230: `print("No leads found.")` - when no results
- Line 233: `print(f"✓ Fetched {len(leads)} lead(s)\n")`

```python
print(f"Fetching leads from form {args.form}...\n", file=sys.stderr)
# ... if no leads:
print("No leads found.", file=sys.stderr)
# ... else:
print(f"✓ Fetched {len(leads)} lead(s)\n", file=sys.stderr)
```

#### `cmd_whoami` (lines 75-93)

Success message and account info go to stderr:
- Line 87: `print_success("Authentication successful!")`
- Line 88: `print()` (blank line)
- Lines 89-92: Page and Pixel ID info

```python
print(file=sys.stderr)  # blank line
if result.get('page_name'):
    print(f"Page: {result['page_name']} (ID: {result['page_id']})", file=sys.stderr)
if result.get('pixel_id'):
    print(f"Pixel ID: {result['pixel_id']}", file=sys.stderr)
```

#### `cmd_status` (lines 95-128)

All status output goes to stderr:
- Line 99: "Checking Facebook API connectivity..."
- Lines 104, 106: Authentication status
- Lines 118-119, 121: Lead Gen API status
- Lines 125-126: Conversions API status
- Line 128: "✓ System health check complete"

#### `cmd_forms_list` (lines 131-155)

All output goes to stderr since this is informational, not data for piping:
- Line 146: `print("No lead forms found on this page.")`
- Line 149: `print(f"Found {len(forms)} lead form(s):\n")`
- Lines 150-151: Table header
- Lines 153-154: Table rows

#### `cmd_forms_show` (lines 157-180)

All output goes to stderr:
- Lines 171-174: Form details (name, ID, status, created)
- Lines 176-179: Questions list

#### `cmd_conversions_send` (lines 246-282)

Status messages to stderr:
- Line 260: `print(f"Loaded {len(events)} event(s) from {args.file}")`
- Line 268: `print_success(f"Sent {len(events)} event(s)")`
- Line 269: `print(f"Response: {result.get('response')}")`

#### `cmd_conversions_test` (lines 285-301)

Status messages to stderr:
- Line 289: `print("Sending test conversion event...\n")`
- Line 294: `print_success("Test event sent successfully!")`
- Line 295: `print(f"Response: {result.get('response')}")`

#### `print_error` function (lines 59-67)

Error output should also go to stderr:

```python
def print_error(code: str, message: str, hints: list = None):
    """Print an error message with optional hints."""
    print(f"\nError: {code}\n", file=sys.stderr)
    print(message, file=sys.stderr)
    if hints:
        print(file=sys.stderr)
        for hint in hints:
            print(hint, file=sys.stderr)
    print(file=sys.stderr)
```

#### `print_success` function (lines 70-72)

```python
def print_success(message: str):
    """Print a success message."""
    print(f"✓ {message}", file=sys.stderr)
```

#### `main()` function (lines 304-402)

Diagnostic and help messages go to stderr:

**No command provided (lines 364-373):**
- Line 364: `parser.print_help()` - this outputs to stdout by default, acceptable for help text
- Lines 365-373: Usage hints like "Commands:" and examples

**Missing subcommand (lines 379-386):**
- Lines 379-386: Usage messages for `forms`, `leads`, `conversions` subcommands

**Keyboard interrupt (line 393):**
- Line 393: `print("\nInterrupted")` - should go to stderr

```python
print("\nInterrupted", file=sys.stderr)
```

**Note:** `parser.print_help()` outputs to stdout by design. This is acceptable as help text is the intended output when running `--help`, not data to be piped.

### What Stays on stdout

Only data output remains on stdout:

1. **JSON output** from `--json` flag:
   - `cmd_leads_fetch` line 200: `print(json.dumps(leads, indent=2))`
   - `cmd_leads_list` line 236: `print(json.dumps(leads, indent=2))`

2. **Formatted tables** (debatable - could argue either way):
   - `cmd_leads_fetch` lines 202-207: Lead table
   - `cmd_leads_list` lines 238-243: Lead table

   **Decision:** Keep tables on stdout since they're the "data output" when not using `--json`. Users can redirect stderr to suppress status while keeping table output.

## Testing

After implementation, verify:

```bash
# 1. Clean JSON piping
fb leads fetch --json --days=30 | jq '.[0].email'
# Should work without JSON parse errors

# 2. Redirect JSON to file
fb leads fetch --json --days=30 > leads.json
# Status messages appear in terminal, leads.json contains only JSON

# 3. Suppress all status output
fb leads fetch --days=30 2>/dev/null
# Only table output visible

# 4. Capture everything
fb leads fetch --json --days=30 > leads.json 2> status.log
# leads.json has JSON, status.log has progress messages
```

## Rollback

If issues arise, revert the changes to `print()` calls (remove `file=sys.stderr`).

## Future Considerations

- A `--quiet` flag could be added later to suppress stderr output entirely
- A `--output` flag could write directly to a file
- Structured logging (JSON logs to stderr) for better machine parsing

These are out of scope for this fix but noted for future enhancement.