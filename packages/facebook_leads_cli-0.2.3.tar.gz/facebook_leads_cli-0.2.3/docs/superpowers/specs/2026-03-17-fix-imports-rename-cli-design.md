# Design: Fix Imports and Rename CLI Command

**Date:** 2026-03-17
**Status:** Draft

## Problem Statement

The `facebook-leads-cli` package published to PyPI has a broken import. When installed, running the CLI fails with:

```
ModuleNotFoundError: No module named 'client'
```

Additionally, the user wants to rename the CLI command from `facebook-leads-cli` to `fb-cli` for brevity.

## Root Cause Analysis

The issue is in `src/fb.py` (lines 14-15):

```python
from client import FacebookClient
from conversions import create_batch_events, load_events_from_file
```

These are **bare imports** that only work when Python's current working directory contains `client.py` and `conversions.py`. When the package is installed via pip:

1. The wheel installs files to `src/client.py`, `src/conversions.py`, `src/fb.py`
2. The entry point calls `src.fb:main`
3. Python looks for a top-level `client` module — which doesn't exist
4. Import fails

## Proposed Solution

### Part 1: Fix Imports

Change to **package-relative imports** in `src/fb.py`:

```python
from .client import FacebookClient
from .conversions import create_batch_events, load_events_from_file
```

Relative imports work when the module is imported as part of a package:
- When installed from PyPI (via entry point)
- When run as a module: `uv run python -m src.fb`
- When imported: `from src.fb import main`

**Note:** Direct script execution (`python src/fb.py`) will fail with relative imports. This is expected behavior — users should use the entry point or module execution.

### Part 2: Rename CLI Command

Update `pyproject.toml` entry point:

```toml
[project.scripts]
fb-cli = "src.fb:main"
```

**Package name stays as `facebook-leads-cli`** — this is intentional:
- Package name: `pip install facebook-leads-cli` (descriptive, discoverable)
- Command name: `fb-cli --help` (short, convenient)

This pattern is common (e.g., `pip install black` → `black`, `pip install httpie` → `http`).

Update `README.md` to replace all `facebook-leads-cli` command references with `fb-cli` (global find/replace in command examples, tables, and code blocks).

## Files Changed

| File | Change |
|------|--------|
| `src/fb.py` | Fix imports to use relative imports; update argparse `prog='fb-cli'`; update help text |
| `pyproject.toml` | Rename entry point from `facebook-leads-cli` to `fb-cli` |
| `README.md` | Update command examples; fix "run from source" instructions |

### README Updates

Replace the "Run CLI (when running from source)" section:

```bash
# Run CLI (when running from source)
uv run python -m src.fb --help
```

This uses module execution (`-m src.fb`) which correctly handles relative imports.

### Argparse Updates

Update `src/fb.py` to use consistent naming. Change all `fb` command references to `fb-cli`:

- `prog='fb'` → `prog='fb-cli'` (line 307)
- Error hint: `['fb leads list --form=<form_id>']` → `['fb-cli leads list --form=<form_id>']` (line 218)
- Error hint: `['fb conversions send --file=data.json']` → `['fb-cli conversions send --file=data.json']` (line 254)
- Help text: all `fb whoami`, `fb status`, etc. → `fb-cli whoami`, `fb-cli status`, etc. (lines 366-373)
- Usage messages: `Usage: fb forms...` → `Usage: fb-cli forms...` (lines 379, 382, 385)

## Verification

1. Run existing tests: `uv run python -m unittest discover tests/`
2. Test module execution: `uv run python -m src.fb --help`
3. Build wheel: `uv build`
4. Install and run: `pip install dist/*.whl && fb-cli --help`
5. Confirm old command removed: `facebook-leads-cli --help` should fail

## Version Bump

Bump version to `0.2.3` (patch) since this is a bug fix.

## Risks

- **Breaking change:** Users with scripts calling `facebook-leads-cli` will need to update to `fb-cli`
- Mitigation: Document the change in README and release notes