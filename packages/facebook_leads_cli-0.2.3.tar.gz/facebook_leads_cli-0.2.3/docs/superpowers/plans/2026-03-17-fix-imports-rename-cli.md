# Fix Imports and Rename CLI Command Implementation Plan

> **For agentic workers:** REQUIRED: Use superpowers:subagent-driven-development (if subagents available) or superpowers:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Fix broken PyPI imports and rename CLI command from `facebook-leads-cli` to `fb-cli`.

**Architecture:** Change bare imports to relative imports in `src/fb.py`, update entry point in `pyproject.toml`, update argparse prog name and all command references, and update documentation.

**Tech Stack:** Python, argparse, hatch build system

---

## Chunk 1: Fix Imports and Update CLI Code

### Task 1: Fix imports in src/fb.py

**Files:**
- Modify: `src/fb.py:14-15`

- [ ] **Step 1: Change bare imports to relative imports**

In `src/fb.py`, change lines 14-15:

```python
# Before:
from client import FacebookClient
from conversions import create_batch_events, load_events_from_file

# After:
from .client import FacebookClient
from .conversions import create_batch_events, load_events_from_file
```

- [ ] **Step 2: Run tests to verify imports work**

Run: `uv run python -m unittest discover tests/`
Expected: All tests pass

### Task 2: Update argparse prog name

**Files:**
- Modify: `src/fb.py:307`

- [ ] **Step 1: Change prog from 'fb' to 'fb-cli'**

In `src/fb.py`, change line 307:

```python
# Before:
parser = argparse.ArgumentParser(
    prog='fb',
    description='Facebook CLI - Lead Gen and Conversions API wrapper'
)

# After:
parser = argparse.ArgumentParser(
    prog='fb-cli',
    description='Facebook CLI - Lead Gen and Conversions API wrapper'
)
```

### Task 3: Update error hints

**Files:**
- Modify: `src/fb.py:218`
- Modify: `src/fb.py:254`

- [ ] **Step 1: Update leads list error hint (line 218)**

```python
# Before:
['fb leads list --form=<form_id>']

# After:
['fb-cli leads list --form=<form_id>']
```

- [ ] **Step 2: Update conversions send error hint (line 254)**

```python
# Before:
['fb conversions send --file=data.json']

# After:
['fb-cli conversions send --file=data.json']
```

### Task 4: Update help text (lines 366-373)

**Files:**
- Modify: `src/fb.py:366-373`

- [ ] **Step 1: Update command examples in help text**

```python
# Before:
        print("\nCommands:", file=sys.stderr)
        print("  fb whoami                 - Show connected account info", file=sys.stderr)
        print("  fb status                 - System health check", file=sys.stderr)
        print("  fb forms list             - List all lead forms", file=sys.stderr)
        print("  fb forms show <form_id>   - Show form details", file=sys.stderr)
        print("  fb leads fetch --days=7   - Fetch leads from all forms", file=sys.stderr)
        print("  fb leads list --form=X    - List leads from specific form", file=sys.stderr)
        print("  fb conversions send       - Send conversion events from file", file=sys.stderr)
        print("  fb conversions test       - Send test conversion event", file=sys.stderr)

# After:
        print("\nCommands:", file=sys.stderr)
        print("  fb-cli whoami                 - Show connected account info", file=sys.stderr)
        print("  fb-cli status                 - System health check", file=sys.stderr)
        print("  fb-cli forms list             - List all lead forms", file=sys.stderr)
        print("  fb-cli forms show <form_id>   - Show form details", file=sys.stderr)
        print("  fb-cli leads fetch --days=7   - Fetch leads from all forms", file=sys.stderr)
        print("  fb-cli leads list --form=X    - List leads from specific form", file=sys.stderr)
        print("  fb-cli conversions send       - Send conversion events from file", file=sys.stderr)
        print("  fb-cli conversions test       - Send test conversion event", file=sys.stderr)
```

### Task 5: Update usage messages (lines 379, 382, 385)

**Files:**
- Modify: `src/fb.py:379`
- Modify: `src/fb.py:382`
- Modify: `src/fb.py:385`

- [ ] **Step 1: Update forms usage message (line 379)**

```python
# Before:
print("Usage: fb forms <subcommand>", file=sys.stderr)

# After:
print("Usage: fb-cli forms <subcommand>", file=sys.stderr)
```

- [ ] **Step 2: Update leads usage message (line 382)**

```python
# Before:
print("Usage: fb leads <subcommand>", file=sys.stderr)

# After:
print("Usage: fb-cli leads <subcommand>", file=sys.stderr)
```

- [ ] **Step 3: Update conversions usage message (line 385)**

```python
# Before:
print("Usage: fb conversions <subcommand>", file=sys.stderr)

# After:
print("Usage: fb-cli conversions <subcommand>", file=sys.stderr)
```

### Task 6: Verify changes to src/fb.py

- [ ] **Step 1: Run tests**

Run: `uv run python -m unittest discover tests/`
Expected: All tests pass

- [ ] **Step 2: Test module execution**

Run: `uv run python -m src.fb --help`
Expected: Help text shows `fb-cli` as program name

- [ ] **Step 3: Commit src/fb.py changes**

```bash
git add src/fb.py
git commit -m "fix: use relative imports and rename CLI to fb-cli"
```

---

## Chunk 2: Update Package Configuration and Documentation

### Task 7: Update pyproject.toml

**Files:**
- Modify: `pyproject.toml`

- [ ] **Step 1: Change entry point from facebook-leads-cli to fb-cli**

In `pyproject.toml`, change line 14:

```toml
# Before:
facebook-leads-cli = "src.fb:main"

# After:
fb-cli = "src.fb:main"
```

- [ ] **Step 2: Bump version to 0.2.3**

In `pyproject.toml`, change line 3:

```toml
# Before:
version = "0.2.2"

# After:
version = "0.2.3"
```

- [ ] **Step 3: Commit pyproject.toml changes**

```bash
git add pyproject.toml
git commit -m "chore: rename entry point to fb-cli and bump version to 0.2.3"
```

### Task 8: Update README.md

**Files:**
- Modify: `README.md`

- [ ] **Step 1: Update "Run CLI (when running from source)" section**

Change line 37:

```bash
# Before:
uv run python src/fb.py --help

# After:
uv run python -m src.fb --help
```

- [ ] **Step 2: Replace all command references**

Replace all occurrences of `facebook-leads-cli` with `fb-cli` in command examples:

- Line 34: `facebook-leads-cli --help` → `fb-cli --help`
- Line 57-58: `facebook-leads-cli whoami` → `fb-cli whoami`
- Line 58: `facebook-leads-cli status` → `fb-cli status`
- Lines 64-67: `facebook-leads-cli forms list` → `fb-cli forms list`, etc.
- Lines 71-73: `facebook-leads-cli conversions test` → `fb-cli conversions test`, etc.
- Lines 81, 95, 115, 133, 139: All command examples

- [ ] **Step 3: Commit README.md changes**

```bash
git add README.md
git commit -m "docs: update CLI command to fb-cli and fix run from source instructions"
```

---

## Chunk 3: Build and Verify

### Task 9: Build and verify package

- [ ] **Step 1: Build the wheel**

Run: `uv build`
Expected: Creates `dist/facebook_leads_cli-0.2.3-py3-none-any.whl`

- [ ] **Step 2: Verify wheel contents**

Run: `python3 -m zipfile -l dist/facebook_leads_cli-0.2.3-py3-none-any.whl`
Expected: Shows `src/client.py`, `src/conversions.py`, `src/fb.py`, entry point for `fb-cli`

- [ ] **Step 3: Test import from wheel**

Run:
```bash
python3 -c "import sys; sys.path.insert(0, 'dist/facebook_leads_cli-0.2.3-py3-none-any.whl'); from src.fb import main; print('Import successful')"
```
Expected: `Import successful` (no ModuleNotFoundError)

- [ ] **Step 4: Install and test command**

Run:
```bash
pip install --force-reinstall dist/facebook_leads_cli-0.2.3-py3-none-any.whl
fb-cli --help
```
Expected: Help text displays correctly

- [ ] **Step 5: Verify old command is gone**

Run: `facebook-leads-cli --help`
Expected: `command not found` or similar error

- [ ] **Step 6: Final commit (if any build artifacts or version bumps needed)**

```bash
git add -A
git commit -m "chore: bump version to 0.2.3"
```

---

## Summary

| Task | Description | Status |
|------|-------------|--------|
| 1 | Fix imports in src/fb.py | [ ] |
| 2 | Update argparse prog name | [ ] |
| 3 | Update error hints | [ ] |
| 4 | Update help text | [ ] |
| 5 | Update usage messages | [ ] |
| 6 | Verify and commit src/fb.py | [ ] |
| 7 | Update pyproject.toml | [ ] |
| 8 | Update README.md | [ ] |
| 9 | Build and verify package | [ ] |