# stderr Output Separation Implementation Plan

> **For agentic workers:** REQUIRED: Use superpowers:subagent-driven-development (if subagents available) or superpowers:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Send status/progress messages to stderr while keeping data output (JSON, tables) on stdout.

**Architecture:** Modify print statements in `src/fb.py` to use `file=sys.stderr`. Centralize changes through helper functions (`print_error`, `print_success`) where possible.

**Tech Stack:** Python 3.10+, unittest

---

## Chunk 1: Test for stderr/stdout Separation

### Task 1: Write Test for Output Stream Separation

**Files:**
- Modify: `tests/test_cli.py`

- [ ] **Step 1: Add test verifying error messages go to stderr**

Add this test to `tests/test_cli.py` after line 48:

```python
    def test_error_output_goes_to_stderr(self):
        """Test that error messages go to stderr, not stdout."""
        env = self.env.copy()
        env['FB_ACCESS_TOKEN'] = ''

        result = subprocess.run(
            ['python3', self.cli_path, 'whoami'],
            capture_output=True,
            text=True,
            env=env
        )

        # Error message should be in stderr, not stdout
        self.assertIn('AUTH_FAILED', result.stderr)
        self.assertNotIn('AUTH_FAILED', result.stdout)

    def test_help_output_stays_on_stdout(self):
        """Test that help text goes to stdout."""
        result = subprocess.run(
            ['python3', self.cli_path, '--help'],
            capture_output=True,
            text=True
        )

        # Help text is the primary output, should be on stdout
        self.assertIn('Facebook CLI', result.stdout)
        # No errors expected
        self.assertEqual(result.returncode, 0)
```

**Note on JSON stdout testing:** Testing `fb leads fetch --json` requires valid Facebook API credentials or mocking the `FacebookClient`. The manual verification in Task 12 Step 2 covers this case. An automated integration test could be added later with proper mocking infrastructure.

- [ ] **Step 2: Run test to verify it fails (current behavior)**

Run: `cd /Users/thaddeus/projects/fb-cli && python -m pytest tests/test_cli.py::TestCLICommands::test_error_output_goes_to_stderr -v`

Expected: FAIL - error is currently in stdout, not stderr

- [ ] **Step 3: Commit the failing test**

```bash
git add tests/test_cli.py
git commit -m "test: add test for stderr output separation (failing)"
```

---

## Chunk 2: Implement stderr Output

### Task 2: Update Helper Functions

**Files:**
- Modify: `src/fb.py:59-72`

- [ ] **Step 1: Update `print_error` function to use stderr**

Replace lines 59-67 in `src/fb.py`:

```python
def print_error(code: str, message: str, hints: list = None):
    """Print an error message with optional hints."""
    print(f"\nError: {code}\n", file=sys.stderr)
    print(message, file=sys.stderr)
    if hints:
        print(file=sys.stderr)
        for hint in hints:
            print(hint, file=sys.stderr)
    print(file=sys.stderr)
```

- [ ] **Step 2: Update `print_success` function to use stderr**

Replace lines 70-72 in `src/fb.py`:

```python
def print_success(message: str):
    """Print a success message."""
    print(f"✓ {message}", file=sys.stderr)
```

- [ ] **Step 3: Run test to verify error output works**

Run: `cd /Users/thaddeus/projects/fb-cli && python -m pytest tests/test_cli.py::TestCLICommands::test_error_output_goes_to_stderr -v`

Expected: PASS

- [ ] **Step 4: Commit helper function changes**

```bash
git add src/fb.py
git commit -m "fix: send error and success messages to stderr"
```

### Task 3: Update cmd_whoami

**Files:**
- Modify: `src/fb.py:75-93`

**Note:** `print_success` is already updated in Task 2 to use stderr internally. Only the remaining `print()` calls need `file=sys.stderr` added.

- [ ] **Step 1: Update informational output in `cmd_whoami`**

Replace lines 88-92 in `src/fb.py` (the `print()` calls after `print_success`):

```python
    print_success("Authentication successful!")
    print(file=sys.stderr)  # blank line
    if result.get('page_name'):
        print(f"Page: {result['page_name']} (ID: {result['page_id']})", file=sys.stderr)
    if result.get('pixel_id'):
        print(f"Pixel ID: {result['pixel_id']}", file=sys.stderr)
```

### Task 4: Update cmd_status

**Files:**
- Modify: `src/fb.py:95-128`

- [ ] **Step 1: Update all print statements in `cmd_status`**

Replace lines 99, 104, 106, 118-119, 121, 125-126, 128 to use `file=sys.stderr`:

```python
    print("Checking Facebook API connectivity...\n", file=sys.stderr)

    # Check authentication
    result = client.whoami()
    if result.get('success'):
        print_success("Authentication: OK")
        if result.get('page_name'):
            print(f"  Page: {result['page_name']}", file=sys.stderr)
    else:
        print_error(
            result.get('code', 'ERROR'),
            result.get('error', 'Authentication failed')
        )
        sys.exit(1)

    # Check Lead Gen API access (if page_id is set)
    if PAGE_ID:
        forms = client.get_lead_forms()
        if forms is not None:
            print_success("Lead Gen API: OK")
            print(f"  Forms found: {len(forms)}", file=sys.stderr)
        else:
            print("⚠ Lead Gen API: Limited access", file=sys.stderr)

    # Check Conversions API access (if pixel_id is set)
    if PIXEL_ID:
        print_success("Conversions API: Configured")
        print(f"  Pixel ID: {PIXEL_ID}", file=sys.stderr)

    print("\n✓ System health check complete", file=sys.stderr)
```

### Task 5: Update cmd_forms_list

**Files:**
- Modify: `src/fb.py:131-155`

- [ ] **Step 1: Update all print statements in `cmd_forms_list`**

Replace lines 146, 149-154 to use `file=sys.stderr`:

```python
    if not forms:
        print("No lead forms found on this page.", file=sys.stderr)
        return

    print(f"Found {len(forms)} lead form(s):\n", file=sys.stderr)
    print(f"{'ID':<20} {'Name':<30} {'Status':<10} {'Leads':<10}", file=sys.stderr)
    print("-" * 70, file=sys.stderr)

    for form in forms:
        print(f"{form['id']:<20} {form['name']:<30} {form['status']:<10} {form.get('leads_count', 0):<10}", file=sys.stderr)
```

### Task 6: Update cmd_forms_show

**Files:**
- Modify: `src/fb.py:157-180`

- [ ] **Step 1: Update all print statements in `cmd_forms_show`**

Replace lines 171-179 to use `file=sys.stderr`:

```python
    print(f"Form: {details['name']}", file=sys.stderr)
    print(f"ID: {details['id']}", file=sys.stderr)
    print(f"Status: {details['status']}", file=sys.stderr)
    print(f"Created: {details['created_time']}", file=sys.stderr)

    if details.get('questions'):
        print("\nQuestions:", file=sys.stderr)
        for q in details['questions']:
            print(f"  - {q}", file=sys.stderr)
```

### Task 7: Update cmd_leads_fetch

**Files:**
- Modify: `src/fb.py:182-208`

- [ ] **Step 1: Update status print statements in `cmd_leads_fetch`**

Replace lines 188, 193, 196 to use `file=sys.stderr`:

```python
    print(f"Fetching leads from the past {days} days (limit: {limit} per form)...\n", file=sys.stderr)

    leads = client.get_leads(days=days, limit=limit)

    if not leads:
        print("No leads found.", file=sys.stderr)
        return

    print(f"✓ Fetched {len(leads)} lead(s)\n", file=sys.stderr)
```

**Note:** Lines 200 and 202-207 stay on stdout (JSON output and table data).

### Task 8: Update cmd_leads_list

**Files:**
- Modify: `src/fb.py:210-244`

- [ ] **Step 1: Update status print statements in `cmd_leads_list`**

Replace lines 225, 230, 233 to use `file=sys.stderr`:

```python
    print(f"Fetching leads from form {args.form}...\n", file=sys.stderr)

    leads = client.get_leads(form_id=args.form, days=days, limit=limit)

    if not leads:
        print("No leads found.", file=sys.stderr)
        return

    print(f"✓ Fetched {len(leads)} lead(s)\n", file=sys.stderr)
```

**Note:** Lines 236 and 238-243 stay on stdout (JSON output and table data).

### Task 9: Update cmd_conversions_send

**Files:**
- Modify: `src/fb.py:246-282`

- [ ] **Step 1: Update status print statements in `cmd_conversions_send`**

Replace lines 260, 268-269 to use `file=sys.stderr`:

```python
        print(f"Loaded {len(events)} event(s) from {args.file}", file=sys.stderr)

        # ... after send ...

        if result.get('success'):
            print_success(f"Sent {len(events)} event(s)")
            print(f"Response: {result.get('response')}", file=sys.stderr)
```

### Task 10: Update cmd_conversions_test

**Files:**
- Modify: `src/fb.py:285-301`

- [ ] **Step 1: Update status print statements in `cmd_conversions_test`**

Replace lines 289, 294-295 to use `file=sys.stderr`:

```python
    print("Sending test conversion event...\n", file=sys.stderr)

    # ... after send ...

    if result.get('success'):
        print_success("Test event sent successfully!")
        print(f"Response: {result.get('response')}", file=sys.stderr)
```

### Task 11: Update main() Function

**Files:**
- Modify: `src/fb.py:304-402`

- [ ] **Step 1: Update usage hints and keyboard interrupt**

Replace lines 365-373, 379-386, 393 to use `file=sys.stderr`:

```python
    if not args.command:
        parser.print_help()
        print("\nCommands:", file=sys.stderr)
        print("  fb whoami                 - Show connected account info", file=sys.stderr)
        print("  fb status                 - System health check", file=sys.stderr)
        print("  fb forms list             - List all lead forms", file=sys.stderr)
        print("  fb forms show <form_id>   - Show form details", file=sys.stderr)
        print("  fb leads fetch --days=7   - Fetch leads from all forms", file=sys.stderr)
        print("  fb leads list --form=X    - List leads from specific form", file=sys.stderr)
        print("  fb conversions send       - Send conversion events from file", file=sys.stderr)
        print("  fb conversions test       - Send test conversion event", file=sys.stderr)
        sys.exit(0)

    # Handle nested subcommands
    if args.command in ['forms', 'leads', 'conversions'] and not hasattr(args, 'func'):
        if args.command == 'forms':
            print("Usage: fb forms <subcommand>", file=sys.stderr)
            print("Subcommands: list, show", file=sys.stderr)
        elif args.command == 'leads':
            print("Usage: fb leads <subcommand>", file=sys.stderr)
            print("Subcommands: fetch, list", file=sys.stderr)
        elif args.command == 'conversions':
            print("Usage: fb conversions <subcommand>", file=sys.stderr)
            print("Subcommands: send, test", file=sys.stderr)
        sys.exit(1)

    # Execute command
    try:
        args.func(args)
    except KeyboardInterrupt:
        print("\nInterrupted", file=sys.stderr)
        sys.exit(130)
```

---

## Chunk 3: Verify and Commit

### Task 12: Run Full Test Suite

- [ ] **Step 1: Run all tests**

Run: `cd /Users/thaddeus/projects/fb-cli && python -m pytest tests/ -v`

Expected: All tests PASS

- [ ] **Step 2: Manual verification of primary use case**

Verify the fix works as specified in the design doc:

```bash
# Test that JSON output is clean (requires valid FB credentials)
# The key test: stdout should contain ONLY valid JSON
fb leads fetch --json --days=30 2>/dev/null | python -m json.tool

# If you have jq installed:
fb leads fetch --json --days=30 2>/dev/null | jq '.[0]'
```

Expected: Valid JSON output with no status messages mixed in.

- [ ] **Step 3: Commit all changes**

```bash
git add src/fb.py
git commit -m "fix: send all status messages to stderr

Status and progress messages now go to stderr while data output
(JSON, formatted tables) remains on stdout. This allows clean
piping of JSON output for automation pipelines.

Fixes: JSON parse error when piping 'fb leads fetch --json'
"
```

- [ ] **Step 3: Update version (optional)**

Consider bumping version in `pyproject.toml` from 0.2.1 to 0.2.2 for this bugfix.