"""
Unit tests for the Facebook client.
"""

import unittest
from unittest.mock import patch, MagicMock
import sys
import os

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from client import FacebookClient


class TestFacebookClient(unittest.TestCase):
    """Test cases for FacebookClient."""

    def setUp(self):
        """Set up test fixtures."""
        self.access_token = 'test_token'
        self.pixel_id = '123456789'
        self.page_id = '987654321'

    @patch('client.FacebookAdsApi')
    def test_init(self, mock_api):
        """Test client initialization."""
        client = FacebookClient(
            access_token=self.access_token,
            pixel_id=self.pixel_id,
            page_id=self.page_id
        )

        mock_api.init.assert_called_once_with(access_token=self.access_token)
        self.assertEqual(client.access_token, self.access_token)
        self.assertEqual(client.pixel_id, self.pixel_id)
        self.assertEqual(client.page_id, self.page_id)

    @patch('client.FacebookAdsApi')
    @patch('client.Page')
    def test_whoami_success(self, mock_page, mock_api):
        """Test whoami with successful authentication."""
        mock_page_instance = MagicMock()
        mock_page_instance.get.return_value = 'Test Page'
        mock_page.return_value = mock_page_instance

        client = FacebookClient(self.access_token, page_id=self.page_id)
        result = client.whoami()

        self.assertTrue(result['success'])
        self.assertEqual(result['page_id'], self.page_id)

    @patch('client.FacebookAdsApi')
    @patch('client.Page')
    def test_whoami_auth_failure(self, mock_page, mock_api):
        """Test whoami with authentication failure."""
        # Use a generic exception to simulate API failure
        mock_page.side_effect = Exception('Invalid access token')

        client = FacebookClient(self.access_token, page_id=self.page_id)
        result = client.whoami()

        self.assertFalse(result['success'])
        self.assertEqual(result['code'], 'NETWORK_ERROR')


class TestConversionsHelpers(unittest.TestCase):
    """Test cases for conversion helpers."""

    def test_normalize_and_hash(self):
        """Test value normalization and hashing."""
        from conversions import normalize_and_hash

        # Test basic hashing
        result = normalize_and_hash('test@example.com')
        self.assertEqual(len(result), 64)  # SHA256 hex length

        # Test normalization (whitespace trimming, lowercase)
        result1 = normalize_and_hash('Test@Example.COM')
        result2 = normalize_and_hash('  test@example.com  ')
        self.assertEqual(result1, result2)

        # Test empty input
        self.assertIsNone(normalize_and_hash(''))
        self.assertIsNone(normalize_and_hash(None))

    def test_clean_phone_number(self):
        """Test phone number cleaning."""
        from conversions import clean_phone_number

        # Test basic cleaning
        self.assertEqual(clean_phone_number('123-456-7890'), '1234567890')
        self.assertEqual(clean_phone_number('+1 (555) 123-4567'), '5551234567')

        # Test empty input
        self.assertIsNone(clean_phone_number(''))
        self.assertIsNone(clean_phone_number(None))

    def test_prepare_user_data(self):
        """Test user data preparation."""
        from conversions import prepare_user_data

        lead = {
            'email': 'Test@Example.com',
            'phone': '123-456-7890',
            'first_name': 'John',
            'last_name': 'Doe'
        }

        user_data = prepare_user_data(lead)

        # Check that fields are hashed
        self.assertIn('em', user_data)
        self.assertIn('ph', user_data)
        self.assertIn('fn', user_data)
        self.assertIn('ln', user_data)

        # Verify email was normalized before hashing
        from conversions import normalize_and_hash
        expected_email_hash = normalize_and_hash('test@example.com')
        self.assertEqual(user_data['em'], expected_email_hash)


if __name__ == '__main__':
    unittest.main()
