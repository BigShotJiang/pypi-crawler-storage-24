"""Export a DependencyGraph to JSON or DOT (Graphviz) format."""
# pylint: disable=duplicate-code

from __future__ import annotations

import json
import os
import re
import subprocess  # nosec B404
from html import escape
from pathlib import Path
from typing import Protocol, TypedDict, cast

from import_cruiser.graph import DependencyGraph, Module, detect_cycles

JSONDict = dict[str, object]


class ViolationLike(Protocol):
    source: str
    target: str
    severity: str
    message: str
    rule_name: str

    def to_dict(self) -> dict[str, object]: ...


class Cluster(TypedDict):
    id: str
    label: str
    parent: str | None
    modules: list[Module]


def export_json(
    graph: DependencyGraph,
    violations: list[ViolationLike] | None = None,
    cycles: list[list[str]] | None = None,
) -> str:
    """Serialize *graph* (and optional analysis results) to a JSON string."""
    if violations is None:
        violations = []
    if cycles is None:
        cycles = detect_cycles(graph)

    data = cast(
        JSONDict,
        {
            "summary": {
                "modules": len(graph.modules),
                "dependencies": len(graph.dependencies),
                "cycles": len(cycles),
                "violations": len(violations),
            },
            "modules": [
                {
                    "name": m.name,
                    "path": m.path,
                    "imports": graph.dependencies_of(m.name),
                }
                for m in sorted(graph.modules, key=lambda m: m.name)
            ],
            "dependencies": [
                {"source": d.source, "target": d.target, "line": d.line}
                for d in sorted(graph.dependencies, key=lambda d: (d.source, d.target))
            ],
            "cycles": [cycle for cycle in cycles],
            "violations": [v.to_dict() for v in violations],
        },
    )
    return json.dumps(data, indent=2)


def export_matrix_json(graph: DependencyGraph) -> str:
    """Return a JSON adjacency matrix representation."""
    modules = sorted(m.name for m in graph.modules)
    index_by_name = {name: idx for idx, name in enumerate(modules)}
    matrix = [[0 for _ in modules] for _ in modules]
    for dep in graph.dependencies:
        src_idx = index_by_name.get(dep.source)
        tgt_idx = index_by_name.get(dep.target)
        if src_idx is not None and tgt_idx is not None:
            matrix[src_idx][tgt_idx] = 1
    payload = cast(
        JSONDict,
        {
            "summary": {
                "modules": len(modules),
                "dependencies": len(graph.dependencies),
            },
            "modules": modules,
            "matrix": matrix,
        },
    )
    return json.dumps(payload, indent=2)


def export_matrix_html(
    graph: DependencyGraph, graph_name: str = "import_cruiser"
) -> str:
    """Return an interactive HTML dependency matrix."""
    modules = sorted(m.name for m in graph.modules)
    dep_set = {(d.source, d.target) for d in graph.dependencies}
    index_by_name = {name: idx for idx, name in enumerate(modules)}

    rows: list[str] = []
    for src in modules:
        src_idx = index_by_name[src]
        cells: list[str] = []
        for tgt in modules:
            tgt_idx = index_by_name[tgt]
            has_dep = (src, tgt) in dep_set
            klass = "diag" if src == tgt else ("hit" if has_dep else "miss")
            symbol = "•" if has_dep else ""
            aria = f"{src} -> {tgt}" if has_dep else ""
            cells.append(
                f'<td class="{klass}" data-row="{src_idx}" data-col="{tgt_idx}" '
                f'data-hit="{1 if has_dep else 0}" title="{escape(aria)}">{symbol}</td>'
            )
        rows.append(
            f'<tr><th scope="row" data-row="{src_idx}">{escape(src)}</th>'
            + "".join(cells)
            + "</tr>"
        )

    cols = "".join(
        f'<th scope="col" data-col="{idx}" title="{escape(name)}">{escape(name)}</th>'
        for idx, name in enumerate(modules)
    )
    count = len(modules)
    display_title = _display_graph_title(graph_name)
    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{escape(display_title)} matrix</title>
  <style>
    :root {{
      color-scheme: only light;
    }}
    body {{
      margin: 0;
      font-family: Helvetica, Arial, sans-serif;
      background: #f6f7f9;
      color: #111827;
    }}
    header {{
      display: flex;
      gap: 8px;
      align-items: center;
      flex-wrap: wrap;
      padding: 6px 8px;
      background: #1f2937;
      color: #f9fafb;
      font-size: 12px;
    }}
    #filter {{
      min-width: 220px;
      padding: 4px 7px;
      border: 1px solid #94a3b8;
      border-radius: 6px;
      font-size: 12px;
    }}
    #summary {{
      color: #d1d5db;
      font-size: 11px;
    }}
    .wrap {{
      height: calc(100vh - 42px);
      overflow: auto;
      background: #fff;
      border-top: 1px solid #d1d5db;
    }}
    table {{
      border-collapse: collapse;
      font-size: 11px;
      width: max-content;
      min-width: 100%;
    }}
    thead th {{
      position: sticky;
      top: 0;
      z-index: 3;
      background: #f3f4f6;
      border-bottom: 1px solid #d1d5db;
      writing-mode: vertical-rl;
      transform: rotate(180deg);
      text-align: left;
      height: 130px;
      white-space: nowrap;
      padding: 4px 3px;
      max-width: 28px;
      overflow: hidden;
      text-overflow: ellipsis;
    }}
    tbody th {{
      position: sticky;
      left: 0;
      z-index: 2;
      background: #f9fafb;
      border-right: 1px solid #d1d5db;
      text-align: left;
      white-space: nowrap;
      max-width: 360px;
      overflow: hidden;
      text-overflow: ellipsis;
      padding: 4px 8px;
    }}
    th.corner {{
      position: sticky;
      top: 0;
      left: 0;
      z-index: 4;
      writing-mode: horizontal-tb;
      transform: none;
      height: auto;
      max-width: none;
    }}
    td {{
      width: 18px;
      min-width: 18px;
      height: 18px;
      text-align: center;
      border: 1px solid #eef2f7;
      color: #111827;
      font-size: 13px;
      line-height: 1;
      user-select: none;
    }}
    td.miss {{
      background: #fff;
    }}
    td.hit {{
      background: #2563eb;
      color: #fff;
    }}
    td.diag {{
      background: #e5e7eb;
    }}
    .highlight {{
      outline: 1px solid #f59e0b;
      outline-offset: -1px;
    }}
    .hidden {{
      display: none;
    }}
  </style>
</head>
<body>
  <header>
    <strong>{escape(display_title)} dependency matrix</strong>
    <input id="filter" type="search" placeholder="Filter modules (substring)">
    <span id="summary">{count} modules</span>
  </header>
  <div class="wrap">
    <table id="matrix">
      <thead>
        <tr>
          <th class="corner">from \\\\ to</th>
          {cols}
        </tr>
      </thead>
      <tbody>
        {"".join(rows)}
      </tbody>
    </table>
  </div>
  <script>
    const filterInput = document.getElementById('filter');
    const summary = document.getElementById('summary');
    const rowHeaders = [...document.querySelectorAll('tbody th[data-row]')];
    const colHeaders = [...document.querySelectorAll('thead th[data-col]')];
    const cells = [...document.querySelectorAll('tbody td[data-row]')];

    const updateFilter = () => {{
      const q = filterInput.value.trim().toLowerCase();
      const visibleRows = new Set();
      const visibleCols = new Set();
      rowHeaders.forEach((th) => {{
        const i = Number(th.dataset.row);
        const keep = !q || th.textContent.toLowerCase().includes(q);
        th.classList.toggle('hidden', !keep);
        if (keep) visibleRows.add(i);
      }});
      colHeaders.forEach((th) => {{
        const i = Number(th.dataset.col);
        const keep = !q || th.title.toLowerCase().includes(q);
        th.classList.toggle('hidden', !keep);
        if (keep) visibleCols.add(i);
      }});
      cells.forEach((td) => {{
        const r = Number(td.dataset.row);
        const c = Number(td.dataset.col);
        const keep = visibleRows.has(r) && visibleCols.has(c);
        td.classList.toggle('hidden', !keep);
      }});
      summary.textContent = `${{visibleRows.size}} / {count} modules`;
    }};

    rowHeaders.forEach((th) => {{
      th.addEventListener('mouseenter', () => {{
        const row = th.dataset.row;
        cells.forEach((td) => td.classList.toggle('highlight', td.dataset.row === row));
      }});
      th.addEventListener('mouseleave', () => {{
        cells.forEach((td) => td.classList.remove('highlight'));
      }});
    }});
    colHeaders.forEach((th) => {{
      th.addEventListener('mouseenter', () => {{
        const col = th.dataset.col;
        cells.forEach((td) => td.classList.toggle('highlight', td.dataset.col === col));
      }});
      th.addEventListener('mouseleave', () => {{
        cells.forEach((td) => td.classList.remove('highlight'));
      }});
    }});

    filterInput.addEventListener('input', updateFilter);
    updateFilter();
  </script>
</body>
</html>"""


def export_dot(
    graph: DependencyGraph,
    graph_name: str = "import_cruiser",
    violations: list[ViolationLike] | None = None,
    rankdir: str = "LR",
    cluster_depth: int = 2,
    cluster_mode: str = "path",
    style: str = "default",
    edge_mode: str = "node",
) -> str:
    """Return a DOT-format string representing the dependency graph."""
    if violations is None:
        violations = []
    cycles = detect_cycles(graph)
    cycle_edges = _edges_in_cycles(cycles)
    cycle_nodes = {name for cycle in cycles for name in cycle}
    violation_edges = _edges_from_violations(violations)

    graph_attrs, node_attrs, edge_attrs = _style_attrs(style, rankdir)

    lines: list[str] = [
        f'digraph "{graph_name}" {{',
        f"    graph [{graph_attrs}];",
        f"    node [{node_attrs}];",
        f"    edge [{edge_attrs}];",
        "",
    ]

    cluster_index: dict[str, list[str]] = {}
    node_to_cluster: dict[str, str] = {}
    valid_cluster_keys: set[str] = set()

    path_root = _common_root(graph.modules) if cluster_mode == "path" else None

    if cluster_depth > 0:
        root_clusters, root_modules, flat_clusters = _build_clusters(
            graph.modules, cluster_depth, cluster_mode
        )
        non_empty_clusters = _non_empty_clusters(flat_clusters)
        valid_cluster_keys = set(non_empty_clusters)
        lines.extend(
            _render_cluster_tree(
                root_clusters,
                flat_clusters,
                cycle_nodes,
                indent="    ",
                mode=cluster_mode,
                allowed=non_empty_clusters,
            )
        )
        for module in graph.modules:
            cluster_key = _node_cluster_key(
                module.name,
                module.path,
                cluster_mode,
                cluster_depth,
                path_root,
            )
            if cluster_key and cluster_key in valid_cluster_keys:
                node_to_cluster[module.name] = cluster_key
                cluster_index.setdefault(cluster_key, []).append(module.name)
    else:
        root_modules = sorted(graph.modules, key=lambda m: m.name)

    for module in root_modules:
        lines.extend(
            _dot_node_lines(
                module.name,
                module.path,
                module.name in cycle_nodes,
                indent="    ",
                label=_leaf_label(module, cluster_mode),
            )
        )

    if root_modules:
        lines.append("")

    if edge_mode == "cluster" and cluster_depth > 0:
        cluster_edges: set[tuple[str, str]] = set()
        for dep in graph.dependencies:
            src_cluster = node_to_cluster.get(dep.source)
            tgt_cluster = node_to_cluster.get(dep.target)
            if not src_cluster or not tgt_cluster or src_cluster == tgt_cluster:
                continue
            if _clusters_related(src_cluster, tgt_cluster):
                continue
            cluster_edges.add((src_cluster, tgt_cluster))

        if cluster_edges:
            for src_cluster, tgt_cluster in sorted(cluster_edges):
                src_node = cluster_index[src_cluster][0]
                tgt_node = cluster_index[tgt_cluster][0]
                lines.append(
                    f"    {_dot_id(src_node)} -> {_dot_id(tgt_node)} "
                    f'[ltail="cluster_{_cluster_id(src_cluster)}", '
                    f'lhead="cluster_{_cluster_id(tgt_cluster)}"];'
                )
        else:
            edge_mode = "node"

    if edge_mode != "cluster":
        for dep in sorted(graph.dependencies, key=lambda d: (d.source, d.target)):
            src = _dot_id(dep.source)
            tgt = _dot_id(dep.target)
            violation = violation_edges.get((dep.source, dep.target))
            if violation:
                color = _severity_color(violation.severity)
                lines.append(f'    {src} -> {tgt} [color="{color}", penwidth=2.2];')
            elif (dep.source, dep.target) in cycle_edges:
                lines.append(f'    {src} -> {tgt} [color="#C0392B", penwidth=1.6];')
            else:
                lines.append(f"    {src} -> {tgt};")

    lines.append("}")
    return "\n".join(lines)


def export_svg(
    graph: DependencyGraph,
    graph_name: str = "import_cruiser",
    violations: list[ViolationLike] | None = None,
    engine: str = "dot",
    rankdir: str = "LR",
    cluster_depth: int = 2,
    cluster_mode: str = "path",
    style: str = "default",
    edge_mode: str = "node",
) -> str:
    dot = export_dot(
        graph,
        graph_name=graph_name,
        violations=violations,
        rankdir=rankdir,
        cluster_depth=cluster_depth,
        cluster_mode=cluster_mode,
        style=style,
        edge_mode=edge_mode,
    )
    try:
        svg = _render_dot(dot, "svg", engine=engine)
    except RuntimeError:
        if edge_mode == "cluster":
            dot = export_dot(
                graph,
                graph_name=graph_name,
                violations=violations,
                rankdir=rankdir,
                cluster_depth=cluster_depth,
                cluster_mode=cluster_mode,
                style=style,
                edge_mode="node",
            )
            svg = _render_dot(dot, "svg", engine=engine)
        else:
            raise
    return _add_svg_padding(svg)


def export_html(
    graph: DependencyGraph,
    graph_name: str = "import_cruiser",
    violations: list[ViolationLike] | None = None,
    engine: str = "dot",
    rankdir: str = "LR",
    cluster_depth: int = 2,
    cluster_mode: str = "path",
    style: str = "default",
    edge_mode: str = "node",
) -> str:
    dot = export_dot(
        graph,
        graph_name=graph_name,
        violations=violations,
        rankdir=rankdir,
        cluster_depth=cluster_depth,
        cluster_mode=cluster_mode,
        style=style,
        edge_mode=edge_mode,
    )
    try:
        svg = _add_svg_padding(_render_dot(dot, "svg", engine=engine))
        body = _html_with_svg(svg, graph_name)
    except RuntimeError as exc:
        if edge_mode == "cluster":
            try:
                dot = export_dot(
                    graph,
                    graph_name=graph_name,
                    violations=violations,
                    rankdir=rankdir,
                    cluster_depth=cluster_depth,
                    cluster_mode=cluster_mode,
                    style=style,
                    edge_mode="node",
                )
                svg = _add_svg_padding(_render_dot(dot, "svg", engine=engine))
                body = _html_with_svg(svg, graph_name)
            except RuntimeError as fallback_exc:
                body = _html_with_fallback(dot, graph_name, str(fallback_exc))
        else:
            body = _html_with_fallback(dot, graph_name, str(exc))
    return body


def _dot_id(name: str) -> str:
    """Convert a dotted module name to a valid DOT identifier."""
    return '"' + name.replace('"', '\\"') + '"'


def _dot_node_lines(
    name: str,
    path: str,
    in_cycle: bool,
    indent: str,
    label: str,
) -> list[str]:
    safe = _dot_id(name)
    attrs = [f'label="{label}"', f'tooltip="{path}"']
    if in_cycle:
        attrs.append('fillcolor="#FDECEA"')
        attrs.append('color="#C0392B"')
    return [f"{indent}{safe} [{', '.join(attrs)}];"]


def _edges_in_cycles(cycles: list[list[str]]) -> set[tuple[str, str]]:
    edges: set[tuple[str, str]] = set()
    for cycle in cycles:
        if len(cycle) < 2:
            continue
        for idx in range(len(cycle)):
            src = cycle[idx]
            tgt = cycle[(idx + 1) % len(cycle)]
            edges.add((src, tgt))
    return edges


def _build_clusters(
    modules: list[Module], depth: int, mode: str
) -> tuple[dict[str, Cluster], list[Module], dict[str, Cluster]]:
    clusters: dict[str, Cluster] = {}
    root_modules: list[Module] = []
    root_path = _common_root(modules) if mode == "path" else None

    for module in modules:
        parts = _cluster_parts(module, mode, root_path)
        if len(parts) <= 1 or depth <= 0:
            root_modules.append(module)
            continue

        max_depth = min(depth, len(parts) - (0 if mode == "path" else 1))
        parent_id = None
        for i in range(1, max_depth + 1):
            cid = ".".join(parts[:i])
            if cid not in clusters:
                clusters[cid] = {
                    "id": cid,
                    "label": parts[i - 1],
                    "parent": parent_id,
                    "modules": [],
                }
            parent_id = cid

        if parent_id is None:  # pragma: no cover
            continue
        clusters[parent_id]["modules"].append(module)

    root_clusters: dict[str, Cluster] = {}
    for cid, cluster in clusters.items():
        parent = cluster["parent"]
        if parent is None:
            root_clusters[cid] = cluster

    return root_clusters, sorted(root_modules, key=lambda m: m.name), clusters


def _render_cluster_tree(
    root_clusters: dict[str, Cluster],
    flat_clusters: dict[str, Cluster],
    cycle_nodes: set[str],
    indent: str,
    mode: str,
    allowed: set[str],
) -> list[str]:
    lines: list[str] = []

    def children_of(parent_id: str) -> list[Cluster]:
        return [c for c in flat_clusters.values() if c["parent"] == parent_id]

    def render_cluster(cluster: Cluster, level_indent: str) -> None:
        if cluster["id"] not in allowed:
            return
        cid = _cluster_id(cluster["id"])
        lines.append(f'{level_indent}subgraph "cluster_{cid}" {{')
        lines.append(f'{level_indent}    label="{cluster["label"]}";')
        lines.append(f"{level_indent}    margin=40;")
        lines.append(f'{level_indent}    color="black";')
        lines.append(f"{level_indent}    penwidth=1.0;")
        lines.append(f'{level_indent}    style="rounded,bold";')
        lines.append(f'{level_indent}    fontname="Helvetica";')
        lines.append(f"{level_indent}    fontsize=9;")

        allowed_children = [
            child for child in children_of(cluster["id"]) if child["id"] in allowed
        ]
        if not cluster["modules"] and allowed_children:
            anchor_id = _dot_id(f"__cluster_anchor_{cid}")
            lines.append(
                f"{level_indent}    {anchor_id} "
                '[label="", shape=point, width=0, height=0, style=invis];'
            )

        for child in sorted(allowed_children, key=lambda c: c["label"]):
            render_cluster(child, level_indent + "    ")

        for module in sorted(cluster["modules"], key=lambda m: m.name):
            lines.extend(
                _dot_node_lines(
                    module.name,
                    module.path,
                    module.name in cycle_nodes,
                    indent=level_indent + "    ",
                    label=_leaf_label(module, mode),
                )
            )

        lines.append(f"{level_indent}}}")

    for cluster in sorted(root_clusters.values(), key=lambda c: c["label"]):
        render_cluster(cluster, indent)
        lines.append("")

    return lines


def _cluster_id(group: str) -> str:
    return group.replace('"', "").replace(".", "_").replace("/", "_").replace("\\", "_")


def _non_empty_clusters(flat_clusters: dict[str, Cluster]) -> set[str]:
    children_map: dict[str, list[Cluster]] = {}
    for cluster in flat_clusters.values():
        parent = cluster["parent"]
        if parent is not None:
            children_map.setdefault(parent, []).append(cluster)

    cache: dict[str, bool] = {}

    def has_content(cluster: Cluster) -> bool:
        cid = cluster["id"]
        if cid in cache:
            return cache[cid]
        if cluster["modules"]:
            cache[cid] = True
            return True
        for child in children_map.get(cid, []):
            if has_content(child):
                cache[cid] = True
                return True
        cache[cid] = False
        return False

    return {cid for cid, cluster in flat_clusters.items() if has_content(cluster)}


def _clusters_related(a: str, b: str) -> bool:
    return a.startswith(b + ".") or b.startswith(a + ".")


def _leaf_label(module, mode: str) -> str:
    if mode == "path":
        return Path(module.path).name
    return module.name.split(".")[-1]


def _node_cluster_key(
    name: str,
    path: str,
    mode: str,
    depth: int,
    root_path: str | None,
) -> str:
    if depth <= 0:
        return ""
    if mode == "path":
        if not path or not root_path:
            return ""
        try:
            rel = Path(path).resolve().relative_to(root_path)
        except ValueError:
            return ""
        parts = list(rel.parts[:-1])
        if not parts:
            return ""
        return ".".join(parts[: min(depth, len(parts))])
    parts = name.split(".")
    if len(parts) <= 1:
        return ""
    return ".".join(parts[: min(depth, len(parts))])


def _cluster_parts(module: Module, mode: str, root_path: str | None) -> list[str]:
    if mode == "path":
        if not root_path:
            return [module.name]
        rel = Path(module.path).resolve().relative_to(root_path)
        return list(rel.parts[:-1])  # directories only
    return module.name.split(".")


def _common_root(modules: list[Module]) -> str | None:
    paths = [m.path for m in modules if m.path]
    if not paths:
        return None
    try:
        common = Path(os.path.commonpath(paths)).resolve()
        common_dir = common if common.is_dir() else common.parent
        if common_dir.name == "src":
            return str(common_dir.parent)
        if common_dir.parent.name == "src":
            return str(common_dir.parent.parent)
        return str(common_dir)
    except ValueError:
        return None


def _edges_from_violations(
    violations: list[ViolationLike],
) -> dict[tuple[str, str], ViolationLike]:
    return {(v.source, v.target): v for v in violations}


def _severity_color(severity: str) -> str:
    return {
        "error": "#C0392B",
        "warn": "#E67E22",
        "info": "#2980B9",
    }.get(severity, "#C0392B")


def _style_attrs(style: str, rankdir: str) -> tuple[str, str, str]:
    if style == "archi":
        graph_attrs = (
            f"rankdir={rankdir}, splines=ortho, overlap=false, ranksep=0.9, "
            'nodesep=0.45, pack=true, packmode="array_u", newrank=true, '
            'compound=true, ratio="compress", '
            'fontname="Helvetica", fontsize=10, bgcolor="white", pad=0.35, margin=0.35'
        )
        node_attrs = (
            'shape=box, style="rounded,filled", fontname="Helvetica", fontsize=10, '
            'color="#2F2F2F", fillcolor="#DFF3F8"'
        )
        edge_attrs = 'color="#A0A0A0", arrowsize=0.7'
        return graph_attrs, node_attrs, edge_attrs

    if style == "cruiser":
        graph_attrs = (
            f"rankdir={rankdir}, splines=curved, overlap=false, ranksep=0.75, "
            'nodesep=0.35, pack=true, packmode="clust", newrank=true, '
            'compound=true, ratio="compress", '
            'fontname="Helvetica", fontsize=10, bgcolor="white", pad=0.35, margin=0.35'
        )
        node_attrs = (
            'shape=box, style="rounded,filled", fontname="Helvetica", fontsize=10, '
            'color="#2F2F2F", fillcolor="#DFF3F8"'
        )
        edge_attrs = 'color="#B0B0B0", arrowsize=0.7'
        return graph_attrs, node_attrs, edge_attrs

    if style == "navigator":
        graph_attrs = (
            f"rankdir={rankdir}, splines=curved, overlap=prism, ranksep=0.9, "
            'nodesep=0.5, pack=true, packmode="clust", newrank=true, '
            'compound=true, ratio="compress", '
            'fontname="Helvetica", fontsize=10, bgcolor="white", pad=0.35, margin=0.35'
        )
        node_attrs = (
            'shape=box, style="rounded,filled", fontname="Helvetica", fontsize=10, '
            'color="#2F2F2F", fillcolor="#DFF3F8"'
        )
        edge_attrs = 'color="#B0B0B0", arrowsize=0.7'
        return graph_attrs, node_attrs, edge_attrs

    graph_attrs = (
        f"rankdir={rankdir}, splines=curved, overlap=false, nodesep=0.16, ranksep=0.18, "
        'fontname="Helvetica-bold", fontsize=9, style="rounded,bold,filled", '
        'fillcolor="#FFFFFF", compound=true, pack=true, packmode="array_u", '
        'newrank=true, ratio="compress", pad=0.35, margin=0.35'
    )
    node_attrs = (
        'shape=box, style="rounded,filled", height=0.2, color="black", '
        'fillcolor="#FFFFCC", fontcolor="black", fontname="Helvetica", fontsize=9'
    )
    edge_attrs = (
        'arrowhead="normal", arrowsize=0.6, penwidth=2.0, '
        'color="#00000033", fontname="Helvetica", fontsize=9'
    )
    return graph_attrs, node_attrs, edge_attrs


def _render_dot(dot: str, fmt: str, engine: str = "dot") -> str:
    try:
        result = subprocess.run(  # nosec B603
            [engine, f"-T{fmt}"],
            input=dot,
            text=True,
            capture_output=True,
            check=True,
        )
    except FileNotFoundError as exc:
        raise RuntimeError("Graphviz 'dot' is not installed.") from exc
    except subprocess.CalledProcessError as exc:
        raise RuntimeError(exc.stderr.strip() or "Graphviz rendering failed.") from exc
    return result.stdout


def _add_svg_padding(svg: str, padding: int = 8) -> str:
    viewbox_match = re.search(
        r'viewBox="([\-0-9.eE]+)\s+([\-0-9.eE]+)\s+([\-0-9.eE]+)\s+([\-0-9.eE]+)"',
        svg,
    )
    if not viewbox_match:
        return svg

    min_x = float(viewbox_match.group(1))
    min_y = float(viewbox_match.group(2))
    width = float(viewbox_match.group(3))
    height = float(viewbox_match.group(4))

    new_viewbox = (
        f'viewBox="{min_x - padding:.2f} {min_y - padding:.2f} '
        f'{width + 2 * padding:.2f} {height + 2 * padding:.2f}"'
    )
    svg = svg[: viewbox_match.start()] + new_viewbox + svg[viewbox_match.end() :]

    def _bump_dimension(attr: str, text: str) -> str:
        match = re.search(rf'{attr}="([0-9.]+)([a-z%]*)"', text)
        if not match:
            return text
        old_value = float(match.group(1))
        unit = match.group(2)
        new_attr = f'{attr}="{old_value + 2 * padding:.0f}{unit}"'
        return text[: match.start()] + new_attr + text[match.end() :]

    svg = _bump_dimension("width", svg)
    svg = _bump_dimension("height", svg)
    return svg


def _html_with_svg(svg: str, title: str) -> str:
    display_title = _display_graph_title(title)
    return f"""<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{display_title}</title>
    <style>
        :root {{
            color-scheme: only light;
        }}
        body {{
            margin: 0;
            font-family: Helvetica, Arial, sans-serif;
            background: #f4f4f4;
            color: #1e1e1e;
        }}
        header {{
            padding: 12px 16px;
            background: #1f2937;
            color: #f9fafb;
            font-size: 14px;
            letter-spacing: 0.02em;
        }}
        .canvas {{
            width: 100vw;
            height: calc(100vh - 44px);
            overflow: hidden;
            position: relative;
            background: radial-gradient(circle at 20% 20%, #ffffff 0%, #f4f4f4 45%, #e8e8e8 100%);
        }}
        .viewport {{
            transform-origin: 0 0;
            cursor: grab;
            transition: transform 0.03s linear;
        }}
        .viewport:active {{
            cursor: grabbing;
        }}
        #inspector {{
            position: absolute;
            top: 12px;
            right: 12px;
            width: min(360px, 40vw);
            max-height: calc(100vh - 90px);
            overflow: auto;
            background: rgba(255, 255, 255, 0.95);
            border: 1px solid #d1d5db;
            border-radius: 8px;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.12);
            padding: 10px 12px;
            font-size: 12px;
            line-height: 1.4;
            z-index: 10;
        }}
        #inspector h4 {{
            margin: 2px 0 8px;
            font-size: 12px;
        }}
        #inspector .muted {{
            color: #6b7280;
        }}
        #inspector ul {{
            margin: 4px 0 8px 16px;
            padding: 0;
        }}
        #controls {{
            position: absolute;
            left: 12px;
            top: 12px;
            display: flex;
            gap: 6px;
            z-index: 11;
        }}
        #controls button {{
            border: 1px solid #cbd5f5;
            background: rgba(255, 255, 255, 0.96);
            color: #1f2937;
            padding: 6px 8px;
            border-radius: 6px;
            font-size: 12px;
            cursor: pointer;
        }}
        #controls button:hover {{
            background: #eef2ff;
        }}
        .dimmed {{
            opacity: 0.14;
            transition: opacity 0.08s ease-out;
        }}
        g.node.active > polygon,
        g.node.active > ellipse,
        g.node.active > rect {{
            stroke: #2563eb;
            stroke-width: 2.2px;
        }}
        g.edge.active > path {{
            stroke: #2563eb;
            stroke-width: 2.4px;
            opacity: 1;
        }}
        g.edge.active > polygon {{
            fill: #2563eb;
            stroke: #2563eb;
            opacity: 1;
        }}
        g.cluster > path,
        g.cluster > polygon {{
            fill: none !important;
        }}
    </style>
</head>
<body>
    <header>{display_title}</header>
    <div class="canvas" id="canvas">
        <div id="controls">
            <button id="zoom-in" type="button">+</button>
            <button id="zoom-out" type="button">-</button>
            <button id="zoom-reset" type="button">Reset</button>
            <button id="zoom-fit" type="button">Fit</button>
        </div>
        <div class="viewport" id="viewport">{svg}</div>
        <aside id="inspector">
            <h4>Context</h4>
            <div class="muted">Hover a module or dependency edge to see context.</div>
        </aside>
    </div>
    <script>
        const canvas = document.getElementById('canvas');
        const viewport = document.getElementById('viewport');
        const svg = viewport.querySelector('svg');
        const inspector = document.getElementById('inspector');
        const zoomInButton = document.getElementById('zoom-in');
        const zoomOutButton = document.getElementById('zoom-out');
        const zoomResetButton = document.getElementById('zoom-reset');
        const zoomFitButton = document.getElementById('zoom-fit');
        let scale = 1;
        let originX = 0;
        let originY = 0;
        let isDragging = false;
        let startX = 0;
        let startY = 0;
        let pinned = null;
        const MIN_SCALE = 0.2;
        const MAX_SCALE = 3;

        const esc = (text) => String(text)
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;')
            .replaceAll("'", '&#39;');

        const titleOf = (group) => group?.querySelector('title')?.textContent?.trim() || '';
        const nodeGroups = [...svg.querySelectorAll('g.node')];
        const edgeGroups = [...svg.querySelectorAll('g.edge')];
        const nodeByName = new Map();
        const outgoing = new Map();
        const incoming = new Map();

        nodeGroups.forEach((node) => {{
            const name = titleOf(node);
            node.dataset.name = name;
            nodeByName.set(name, node);
            outgoing.set(name, []);
            incoming.set(name, []);
        }});

        edgeGroups.forEach((edge) => {{
            const raw = titleOf(edge);
            const [src, tgt] = raw.split('->').map((s) => s.trim());
            edge.dataset.src = src || '';
            edge.dataset.tgt = tgt || '';
            if (src && tgt) {{
                outgoing.get(src)?.push(tgt);
                incoming.get(tgt)?.push(src);
            }}
        }});

        const applyTransform = () => {{
            viewport.style.transform = `translate(${{originX}}px, ${{originY}}px) scale(${{scale}})`;
        }};

        const clamp = (value, min, max) => Math.min(max, Math.max(min, value));

        const getViewBox = () => {{
            if (!svg) return null;
            if (svg.viewBox && svg.viewBox.baseVal && svg.viewBox.baseVal.width && svg.viewBox.baseVal.height) {{
                return svg.viewBox.baseVal;
            }}
            const attr = svg.getAttribute('viewBox');
            if (attr) {{
                const parts = attr.split(/\\s+/).map(Number);
                if (parts.length === 4 && parts.every((n) => Number.isFinite(n))) {{
                    return {{ x: parts[0], y: parts[1], width: parts[2], height: parts[3] }};
                }}
            }}
            const width = parseFloat(svg.getAttribute('width') || '0');
            const height = parseFloat(svg.getAttribute('height') || '0');
            if (width > 0 && height > 0) {{
                svg.setAttribute('viewBox', `0 0 ${{width}} ${{height}}`);
                return {{ x: 0, y: 0, width, height }};
            }}
            return null;
        }};

        const fitToView = () => {{
            const vb = getViewBox();
            if (!vb || !vb.width || !vb.height) return;
            const scaleX = canvas.clientWidth / vb.width;
            const scaleY = canvas.clientHeight / vb.height;
            const fitScale = Math.min(scaleX, scaleY) * 0.65;
            scale = fitScale;
            const baseOriginX = (canvas.clientWidth - vb.width * scale) / 2 - vb.x * scale;
            const baseOriginY = (canvas.clientHeight - vb.height * scale) / 2 - vb.y * scale;
            originX = baseOriginX;
            originY = baseOriginY;
            applyTransform();
            const graphGroup = svg.querySelector('g[id^="graph"]') || svg.querySelector('g');
            if (!graphGroup) return;
            const canvasRect = canvas.getBoundingClientRect();
            const graphRect = graphGroup.getBoundingClientRect();
            if (!graphRect.width || !graphRect.height) return;
            const dx =
                canvasRect.left + canvasRect.width / 2 - (graphRect.left + graphRect.width / 2);
            const dy =
                canvasRect.top + canvasRect.height / 2 - (graphRect.top + graphRect.height / 2);
            originX = baseOriginX + dx;
            originY = baseOriginY + dy;
            applyTransform();
        }};

        const clearFocus = (force = false) => {{
            if (pinned && !force) return;
            nodeGroups.forEach((n) => n.classList.remove('dimmed', 'active'));
            edgeGroups.forEach((e) => e.classList.remove('dimmed', 'active'));
            inspector.innerHTML = '<h4>Context</h4><div class="muted">Hover a module or dependency edge to see context.</div>';
        }};

        const markNodeActive = (name) => {{
            const n = nodeByName.get(name);
            if (n) {{
                n.classList.remove('dimmed');
                n.classList.add('active');
            }}
        }};

        const focusNode = (name, isPinned = false) => {{
            const out = outgoing.get(name) || [];
            const inc = incoming.get(name) || [];
            const neighbors = new Set([name, ...out, ...inc]);

            nodeGroups.forEach((n) => {{
                n.classList.add('dimmed');
                n.classList.remove('active');
            }});
            edgeGroups.forEach((e) => {{
                e.classList.add('dimmed');
                e.classList.remove('active');
            }});

            neighbors.forEach(markNodeActive);

            edgeGroups.forEach((edge) => {{
                const src = edge.dataset.src;
                const tgt = edge.dataset.tgt;
                if (src === name || tgt === name) {{
                    edge.classList.remove('dimmed');
                    edge.classList.add('active');
                }}
            }});

            const outList = out.length ? `<ul>${{out.map((n) => `<li>${{esc(n)}}</li>`).join('')}}</ul>` : '<div class="muted">none</div>';
            const inList = inc.length ? `<ul>${{inc.map((n) => `<li>${{esc(n)}}</li>`).join('')}}</ul>` : '<div class="muted">none</div>';
            const pinBadge = isPinned ? '<div class="muted"><strong>Pinned</strong> · click empty space or press Esc to release</div>' : '';

            inspector.innerHTML = `
                <h4>${{esc(name)}}</h4>
                ${{pinBadge}}
                <div><strong>Outgoing</strong> (${{out.length}})</div>
                ${{outList}}
                <div><strong>Incoming</strong> (${{inc.length}})</div>
                ${{inList}}
            `;
        }};

        const focusEdge = (src, tgt, isPinned = false) => {{
            nodeGroups.forEach((n) => {{
                n.classList.add('dimmed');
                n.classList.remove('active');
            }});
            edgeGroups.forEach((e) => {{
                e.classList.add('dimmed');
                e.classList.remove('active');
            }});

            markNodeActive(src);
            markNodeActive(tgt);

            edgeGroups.forEach((edge) => {{
                if (edge.dataset.src === src && edge.dataset.tgt === tgt) {{
                    edge.classList.remove('dimmed');
                    edge.classList.add('active');
                }}
            }});

            const pinBadge = isPinned ? '<div class="muted"><strong>Pinned</strong> · click empty space or press Esc to release</div>' : '';

            inspector.innerHTML = `
                <h4>Dependency</h4>
                ${{pinBadge}}
                <div><strong>From:</strong> ${{esc(src)}}</div>
                <div><strong>To:</strong> ${{esc(tgt)}}</div>
            `;
        }};

        nodeGroups.forEach((node) => {{
            const name = node.dataset.name;
            node.addEventListener('mouseenter', () => {{
                if (pinned) return;
                focusNode(name);
            }});
            node.addEventListener('mouseleave', () => clearFocus());
            node.addEventListener('click', (event) => {{
                event.stopPropagation();
                pinned = {{ kind: 'node', name }};
                focusNode(name, true);
            }});
        }});

        edgeGroups.forEach((edge) => {{
            const src = edge.dataset.src;
            const tgt = edge.dataset.tgt;
            if (!src || !tgt) return;
            edge.addEventListener('mouseenter', () => {{
                if (pinned) return;
                focusEdge(src, tgt);
            }});
            edge.addEventListener('mouseleave', () => clearFocus());
            edge.addEventListener('click', (event) => {{
                event.stopPropagation();
                pinned = {{ kind: 'edge', src, tgt }};
                focusEdge(src, tgt, true);
            }});
        }});

        canvas.addEventListener('click', (event) => {{
            if (event.target.closest('g.node') || event.target.closest('g.edge')) return;
            pinned = null;
            clearFocus(true);
        }});

        window.addEventListener('keydown', (event) => {{
            if (event.key !== 'Escape') return;
            pinned = null;
            clearFocus(true);
        }});

        canvas.addEventListener('wheel', (event) => {{
            event.preventDefault();
            const delta = Math.sign(event.deltaY) * -0.1;
            scale = clamp(scale + delta, MIN_SCALE, MAX_SCALE);
            applyTransform();
        }});

        canvas.addEventListener('mousedown', (event) => {{
            isDragging = true;
            startX = event.clientX - originX;
            startY = event.clientY - originY;
        }});

        window.addEventListener('mousemove', (event) => {{
            if (!isDragging) return;
            originX = event.clientX - startX;
            originY = event.clientY - startY;
            applyTransform();
        }});

        window.addEventListener('mouseup', () => {{
            isDragging = false;
        }});

        window.addEventListener('resize', fitToView);
        zoomInButton.addEventListener('click', () => {{
            scale = clamp(scale + 0.1, MIN_SCALE, MAX_SCALE);
            applyTransform();
        }});
        zoomOutButton.addEventListener('click', () => {{
            scale = clamp(scale - 0.1, MIN_SCALE, MAX_SCALE);
            applyTransform();
        }});
        zoomResetButton.addEventListener('click', () => {{
            fitToView();
        }});
        zoomFitButton.addEventListener('click', fitToView);
        fitToView();
        window.addEventListener('load', fitToView, {{ once: true }});
    </script>
</body>
</html>"""


def _html_with_fallback(dot: str, title: str, error: str) -> str:
    display_title = _display_graph_title(title)
    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{display_title}</title>
  <style>
    body {{
      margin: 0;
      font-family: Helvetica, Arial, sans-serif;
      background: #f4f4f4;
      color: #1e1e1e;
    }}
    header {{
      padding: 12px 16px;
      background: #1f2937;
      color: #f9fafb;
      font-size: 14px;
    }}
    .warning {{
      padding: 12px 16px;
      background: #fff3cd;
      color: #5c4400;
      border-bottom: 1px solid #e8d18a;
    }}
    pre {{
      padding: 16px;
      white-space: pre-wrap;
    }}
  </style>
</head>
<body>
    <header>{display_title}</header>
  <div class="warning">Graphviz rendering failed: {error}</div>
  <pre>{dot}</pre>
</body>
</html>"""


def _display_graph_title(title: str) -> str:
    return title.replace("import_cruiser", "import-cruiser")
