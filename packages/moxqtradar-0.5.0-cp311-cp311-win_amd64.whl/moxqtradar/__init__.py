# moxqtradar/__init__.py
"""
moxqtradar - Qt workers & analyzers (lazy import version).
只在第一次存取名稱時才載入對應子模組／符號，縮短啟動時間並降低循環匯入風險。
"""

from importlib import import_module
from typing import TYPE_CHECKING

# 允許「模組式」匯入的子模組，用法：
#   from moxqtradar import workers_base, qt_threading
_LAZY_SUBMODULES = {
    "qt_threading",
    "workers_base",
}

# 在套件頂層直接暴露的常用類別／函式，用法：
#   from moxqtradar import StepsWorker, start_worker, DistAngleAsmt, ...
_LAZY_ATTRS = {
    "BringUpChecker": ("bringUp_check", "BringUpChecker"),
    "CwMode": ("cwMode", "CwMode"),
    "paramSet": ("paramSet", "ParamSet"),
    "DataAnalyzer": ("dataAnalyzer", "DataAnalyzer"),
    "DataAnalyzer_LocationCSV": ("dataAnalyzer_locationCSV", "DataAnalyzer_LocationCSV"),
    "DataAnalyzer_Rename": ("dataAnalyzer_rnName", "DataAnalyzer_Rename"),
    "DataAnalyzer_SnrRxPower": ("dataAnalyzer_snrRxPower", "DataAnalyzer_SnrRxPower"),
    "DistAngle": ("distAngle", "DistAngle"),
    "DistAngleAsmt": ("distAngleAsmt", "DistAngleAsmt"),
    "MotionLED": ("motionLED", "MotionLED"),
    "Position2D": ("position2D", "Position2D"),
    "RxOnly": ("rxOnly", "RxOnly"),
    "SysLogLevel": ("sysLogLevel", "SysLogLevel"),
    "start_worker": ("qt_threading", "start_worker"),
    "StepsWorker": ("workers_base", "StepsWorker"),
    "FwUpdate": ("fwUpdate", "FwUpdate"),
    "FftAnalyzer": ("fftAnalyzer", "FftAnalyzer"),
    "FftHist": ("fftHist", "FftHist"),
    "RfTest": ("rfTest", "RfTest"),
}

__all__ = sorted(list(_LAZY_SUBMODULES) + list(_LAZY_ATTRS.keys()))

def __getattr__(name: str):
    # 懶載入子模組
    if name in _LAZY_SUBMODULES:
        mod = import_module(f"{__name__}.{name}")
        globals()[name] = mod
        return mod

    # 懶載入並 re-export 類別／函式
    if name in _LAZY_ATTRS:
        mod_name, attr = _LAZY_ATTRS[name]
        mod = import_module(f"{__name__}.{mod_name}")
        obj = getattr(mod, attr)
        globals()[name] = obj
        return obj

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

def __dir__():
    # 讓 dir(moxqtradar) 看起來完整
    return sorted(list(globals().keys()) + list(__all__))

# 讓型別檢查器／IDE 友善（執行時不會真的 import）
if TYPE_CHECKING:
    from . import qt_threading, workers_base
    from .bringUp_check import BringUpChecker
    from .cwMode import CwMode
    from .dataAnalyzer import DataAnalyzer
    from .dataAnalyzer_locationCSV import DataAnalyzer_LocationCSV
    from .dataAnalyzer_rnName import DataAnalyzer_Rename
    from .dataAnalyzer_snrRxPower import DataAnalyzer_SnrRxPower    
    from .distAngle import DistAngle
    from .distAngleAsmt import DistAngleAsmt
    from .motionLED import MotionLED
    from .position2D import Position2D
    from .rxOnly import RxOnly
    from .paramSet import paramSet
    from .sysLogLevel import SysLogLevel
    from .qt_threading import start_worker
    from .workers_base import StepsWorker
    from .fwUpdate import FwUpdate
    from .fftAnalyzer import FftAnalyzer
    from .fftHist import FftHist
    from .rfTest import RfTest
