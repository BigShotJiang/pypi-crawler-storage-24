"""This module hosts various losses for perception tasks."""

from unipercept.utils.python import defer_imports as _defer_imports

__all__ = [
    "_stable",
    "contrastive",
    "depth",
    "focal",
    "functional",
    "guided",
    "image",
    "mixins",
    "panoptic",
]
__getattr__, __dir__ = _defer_imports(__name__, __all__)
