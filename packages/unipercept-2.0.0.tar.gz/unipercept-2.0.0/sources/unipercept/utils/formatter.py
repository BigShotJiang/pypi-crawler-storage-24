from __future__ import annotations

from typing import override

__all__ = ["formatter"]


class formatter(property):
    """Implements a property that resolves a format string using the object's attributes."""

    __slots__ = ("fmt",)

    def __init__(self, fmt: str) -> None:
        self.fmt = fmt

    @override
    def __get__(self, obj, objtype=None):
        return self.fmt.format_map({"self": obj})

    @override
    def __set__(self, obj, value) -> None:
        msg = "Cannot set attribute"
        raise AttributeError(msg)

    @override
    def __delete__(self, obj):
        msg = "Cannot delete attribute"
        raise AttributeError(msg)
