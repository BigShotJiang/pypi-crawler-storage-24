"""Utilities for working with timestamps"""

import enum as E
from datetime import datetime

__all__ = ["TimestampFormat", "get_timestamp"]


class TimestampFormat(E.StrEnum):
    UNIX = E.auto()
    ISO = E.auto()
    LOCALE = E.auto()
    SHORT_YMD_HMS = E.auto()


def get_timestamp(*, format: str | TimestampFormat = TimestampFormat.ISO) -> str:
    """Returns a timestamp in the given format."""
    now = datetime.now()

    match format:
        case TimestampFormat.UNIX:
            return str(int(now.timestamp()))
        case TimestampFormat.ISO:
            return now.isoformat(timespec="seconds")
        case TimestampFormat.LOCALE:
            return now.strftime(r"%c")
        case TimestampFormat.SHORT_YMD_HMS:
            return now.strftime(r"%y%j%H%M%S")
        case _:
            msg = f"Invalid timestamp format: {format}"
            raise ValueError(msg)
