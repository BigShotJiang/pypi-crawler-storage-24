r"""
This module contains various implementations of computer vision algorithms,
conventions, and utilities.

Submodules
----------
- `filter`: Image filtering and convolution operations.
- `geometry`: Geometric transformations and conversions.
- `pointrend`: Point sampling and selection methods.
- `inpaint`: Image inpainting and completion methods.
"""

from . import filter, geometry, pointrend
