# Unipercept

Public repository of tools and libraries powering cutting-edge computer vision and
machine learning research at the [Mobile Perception Systems (MPS)](https://tue-mps.org/)
lab at [Eindhoven University of Technology (TU/e)](https://www.tue.nl/en/).

