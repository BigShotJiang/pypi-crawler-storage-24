"""Chart-level lint rules.

These rules check chart configurations (Lens and ESQL panels) for issues
like missing labels, insufficient dimensions, or configuration problems.
"""

from dashboard_lint.rules.chart.datatable_row_density import DatatableRowDensityRule
from dashboard_lint.rules.chart.dimension_missing_label import DimensionMissingLabelRule
from dashboard_lint.rules.chart.esql_dimension_missing_label import ESQLDimensionMissingLabelRule
from dashboard_lint.rules.chart.esql_dynamic_time_bucket import ESQLDynamicTimeBucketRule
from dashboard_lint.rules.chart.esql_field_escaping import ESQLFieldEscapingRule
from dashboard_lint.rules.chart.esql_group_by_syntax import ESQLGroupBySyntaxRule
from dashboard_lint.rules.chart.esql_metric_missing_label import ESQLMetricMissingLabelRule
from dashboard_lint.rules.chart.esql_missing_limit import ESQLMissingLimitRule
from dashboard_lint.rules.chart.esql_missing_sort_after_bucket import ESQLMissingSortAfterBucketRule
from dashboard_lint.rules.chart.esql_sql_syntax import ESQLSqlSyntaxRule
from dashboard_lint.rules.chart.esql_ts_metrics_min_version import ESQLTSMetricsMinVersionRule
from dashboard_lint.rules.chart.esql_where_clause import ESQLWhereClauseRule
from dashboard_lint.rules.chart.gauge_goal_without_max import GaugeGoalWithoutMaxRule
from dashboard_lint.rules.chart.metric_multiple_metrics_width import MetricMultipleMetricsWidthRule
from dashboard_lint.rules.chart.metric_redundant_label import MetricRedundantLabelRule
from dashboard_lint.rules.chart.narrow_xy_chart_side_legend import NarrowXYChartSideLegendRule
from dashboard_lint.rules.chart.panel_height_for_content import PanelHeightForContentRule
from dashboard_lint.rules.chart.pie_chart_dimension_count import PieChartDimensionCountRule
from dashboard_lint.rules.chart.pie_missing_limit import PieMissingLimitRule

__all__ = [
    'DatatableRowDensityRule',
    'DimensionMissingLabelRule',
    'ESQLDimensionMissingLabelRule',
    'ESQLDynamicTimeBucketRule',
    'ESQLFieldEscapingRule',
    'ESQLGroupBySyntaxRule',
    'ESQLMetricMissingLabelRule',
    'ESQLMissingLimitRule',
    'ESQLMissingSortAfterBucketRule',
    'ESQLSqlSyntaxRule',
    'ESQLTSMetricsMinVersionRule',
    'ESQLWhereClauseRule',
    'GaugeGoalWithoutMaxRule',
    'MetricMultipleMetricsWidthRule',
    'MetricRedundantLabelRule',
    'NarrowXYChartSideLegendRule',
    'PanelHeightForContentRule',
    'PieChartDimensionCountRule',
    'PieMissingLimitRule',
]
