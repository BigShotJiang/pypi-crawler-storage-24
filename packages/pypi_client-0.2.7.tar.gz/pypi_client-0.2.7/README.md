PyPI client
===========

CLI tool for searching Python packages by name. Finds matching packages on PyPI, enriches results with GitHub stars and download counts, and ranks them by relevance.

Install
-------

```
pip install pypi-client
```

Or with [uv](https://docs.astral.sh/uv/):

```
uv tool install pypi-client
```

Usage
-----

```
Usage: pypi-client [OPTIONS] COMMAND [ARGS]...

Options:
  --version  Show the version and exit.
  --help     Show this message and exit.

Commands:
  auth-github  Log into GitHub
  search       Search python package by name
```

Search
------

```
Usage: pypi-client search [OPTIONS] NAME_SEARCH

  Search python package by name

Options:
  --limit INTEGER RANGE           Max number of items to return
  --no-cache                      Clear cache before run
  --log-level [ERROR|WARN|INFO|DEBUG]
                                  Logging level
  --json                          Return in json format
  --threads INTEGER               Number of threads to use
  --help                          Show this message and exit.
```

Example output:

```
$ pypi-client search kafka
Found 155 packages:
name                                 downloads  summary                                                version      home_page                                                stars    releases  last_release_date
---------------------------------  -----------  -----------------------------------------------------  -----------  -----------------------------------------------------  -------  ----------  -------------------
kafka-python                           6863094  Pure Python client for Apache Kafka                    2.0.2        https://github.com/dpkp/kafka-python                      4084          34  2020-09-30
confluent-kafka                        3341286  Confluent's Python client for Apache Kafka             1.5.0        https://github.com/confluentinc/confluent-kafka-py...     2017          20  2020-08-07
...
```

GitHub Authentication
---------------------

Authenticate with GitHub to increase the API rate limit (60 → 5000 requests/hour):

```
pypi-client auth-github
```

Development
-----------

Requires Python 3.13+ and [uv](https://docs.astral.sh/uv/).

```
uv sync --dev
uv run python -m pytest
```
