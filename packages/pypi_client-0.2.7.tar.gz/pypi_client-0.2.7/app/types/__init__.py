from collections.abc import Callable, Iterable
from contextlib import AbstractContextManager
from typing import TypeVar

from pydantic import BaseModel


class Package(BaseModel):
    name: str
    summary: str | None = None
    version: str | None = None
    home_page: str | None = None
    downloads: int | None = None
    stars: int | None = None
    releases: int | None = None
    last_release_date: str | None = None
    score: int | None = None


# Progress bar
Item = TypeVar("Item")
ProgressBar = Callable[[Iterable[Item], int], AbstractContextManager[Iterable[Item]]]


class DeviceFlowVerificationCodes(BaseModel):
    device_code: str
    user_code: str
    verification_uri: str
    expires_in: int
    interval: int


class AccessToken(BaseModel):
    access_token: str
