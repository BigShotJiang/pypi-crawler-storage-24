from pydantic import BaseModel


class GithubRepo(BaseModel):
    stargazers_count: int
