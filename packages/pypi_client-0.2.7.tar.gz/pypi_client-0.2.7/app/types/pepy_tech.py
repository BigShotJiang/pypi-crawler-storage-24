from datetime import date

from pydantic import BaseModel

Version = str


class PackageStats(BaseModel):
    downloads: dict[date, dict[Version, int]]
