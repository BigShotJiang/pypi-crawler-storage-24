from datetime import datetime

from pydantic import BaseModel

Url = str


class PypiProjectUrls(BaseModel):
    Source: Url | None = None


class PypiPackageInfo(BaseModel):
    name: str
    summary: str | None = None
    version: str | None = None
    project_urls: PypiProjectUrls | None = None
    home_page: Url | None = None


class PypiReleaseUpload(BaseModel):
    upload_time: datetime


Version = str


class PypiEntry(BaseModel):
    info: PypiPackageInfo
    releases: dict[Version, list[PypiReleaseUpload]] = {}
