from diskcache import Cache
from platformdirs import user_cache_dir

cache = Cache(user_cache_dir("pypi-client", "PyPI"))
