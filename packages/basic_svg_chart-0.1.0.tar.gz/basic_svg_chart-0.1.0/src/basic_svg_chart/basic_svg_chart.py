""" Basic SVG charting library """
# /// script
# requires-python = ">=3.10"
# ///

import xml.etree.ElementTree as ET
import math
import copy
import sys
from types import SimpleNamespace # https://stackoverflow.com/questions/16279212/how-to-use-dot-notation-for-dict-in-python#16279578
import logging

try: # if package basic-svg-chart installed
    from .utils import replace_tags, num_attr, format_text_numbers
except ImportError: # if basic_svg_chart.py used without installing the package
     from utils import replace_tags, num_attr, format_text_numbers
     
from collections.abc import Sequence # https://docs.python.org/3/library/stdtypes.html#sequence-types-list-tuple-range

# Default tooltip title format
DEFAULT_TOOLTIP = "{name}: x = {x}{x_unit}, y = {y}{y_unit}"

# Okabe-Ito palette:
# https://siegal.bio.nyu.edu/color-palette/
# https://jfly.uni-koeln.de/color/
OKABE_ITO = ("#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7", "grey") # "grey" instead or "black" in case of dark mode used

# Viridis palette: https://waldyrious.net/viridis-palette-generator/
VIRIDIS =  (
("black"),
('#440154', '#fde725'),
('#440154', '#21918c', '#fde725'),
('#440154', '#31688e', '#35b779', '#fde725'),
('#440154', '#3b528b', '#21918c', '#5ec962', '#fde725'),
('#440154', '#414487', '#2a788e', '#22a884', '#7ad151', '#fde725'),
('#440154', '#443983', '#31688e', '#21918c', '#35b779', '#90d743', '#fde725'),
('#440154', '#46327e', '#365c8d', '#277f8e', '#1fa187', '#4ac16d', '#a0da39', '#fde725'),
('#440154', '#472d7b', '#3b528b', '#2c728e', '#21918c', '#28ae80', '#5ec962', '#addc30', '#fde725'),
('#440154', '#482878', '#3e4989', '#31688e', '#26828e', '#1f9e89', '#35b779', '#6ece58', '#b5de2b', '#fde725'),
('#440154', '#482475', '#414487', '#355f8d', '#2a788e', '#21918c', '#22a884', '#44bf70', '#7ad151', '#bddf26', '#fde725'),
('#440154', '#482173', '#433e85', '#38588c', '#2d708e', '#25858e', '#1e9b8a', '#2ab07f', '#52c569', '#86d549', '#c2df23', '#fde725'),
('#440154', '#481f70', '#443983', '#3b528b', '#31688e', '#287c8e', '#21918c', '#20a486', '#35b779', '#5ec962', '#90d743', '#c8e020', '#fde725'),
('#440154', '#481c6e', '#453581', '#3d4d8a', '#34618d', '#2b748e', '#24878e', '#1f998a', '#25ac82', '#40bd72', '#67cc5c', '#98d83e', '#cde11d', '#fde725'),
('#440154', '#481b6d', '#46327e', '#3f4788', '#365c8d', '#2e6e8e', '#277f8e', '#21918c', '#1fa187', '#2db27d', '#4ac16d', '#73d056', '#a0da39', '#d0e11c', '#fde725'),
('#440154', '#481a6c', '#472f7d', '#414487', '#39568c', '#31688e', '#2a788e', '#23888e', '#1f988b', '#22a884', '#35b779', '#54c568', '#7ad151', '#a5db36', '#d2e21b', '#fde725'),
('#440154', '#48186a', '#472d7b', '#424086', '#3b528b', '#33638d', '#2c728e', '#26828e', '#21918c', '#1fa088', '#28ae80', '#3fbc73', '#5ec962', '#84d44b', '#addc30', '#d8e219', '#fde725'),
('#440154', '#481769', '#472a7a', '#433d84', '#3d4e8a', '#355e8d', '#2e6d8e', '#297b8e', '#23898e', '#1f978b', '#21a585', '#2eb37c', '#46c06f', '#65cb5e', '#89d548', '#b0dd2f', '#d8e219', '#fde725'),
('#440154', '#481668', '#482878', '#443983', '#3e4989', '#375a8c', '#31688e', '#2b758e', '#26828e', '#21918c', '#1f9e89', '#25ab82', '#35b779', '#4ec36b', '#6ece58', '#90d743', '#b5de2b', '#dae319', '#fde725'),
('#440154', '#481467', '#482576', '#453781', '#404688', '#39558c', '#33638d', '#2d718e', '#287d8e', '#238a8d', '#1f968b', '#20a386', '#29af7f', '#3dbc74', '#56c667', '#75d054', '#95d840', '#bade28', '#dde318', '#fde725')
)

# CSS style added to all charts (will be extended according to the parameters)
DEFAULT_CSS = (
    "text.title {font-weight: bold; font-size: 1.4em; text-anchor: middle;}",
    "g.series > path:hover {stroke-width: 5px;}",
    "g#series_plots:hover .series {opacity: 0.2;}",
    "g#series_plots > g.series:hover {opacity: 1;}",
    ".abbr {cursor: help; text-decoration:underline dashed; text-underline-position: under; text-decoration-thickness: 1.5px;}",
    "a {fill: darkblue;}",
    "a:hover {text-decoration: underline;}",
    "g#ordinate > text {text-anchor: end; dominant-baseline: central;}",
    "g#ordinate > text.unit {text-anchor: start;}",
    "g#abscissa_text > text {text-anchor: middle;}",
    ".hide {opacity: 0;}",
    "circle:hover + text.hide {opacity: 1;}",
    "circle.hide:hover {opacity: 1;}",
)

# Default CSS style for dark mode
DARK_MODE_CSS = (
    "text {fill: white;}", # text:not([fill])
    "[stroke='black'] {stroke: white;}",
    "line[stroke-dasharray] {stroke: grey;}",
    "a {fill: deepskyblue;}",
    "g#series_plots:hover .series {opacity: 0.4;}",
    "rect#legend_bg[fill='white'] {fill: black;}",
    ".hover_values > line {stroke: white;}",
    "filter#bg_abs > feFlood {flood-color: green;}",
    "filter#bg_val > feFlood {flood-color: black; flood-opacity: 0.7;}",
)

# text-anchor CSS property for values shown of the chart, depending on `values_position` parameter
# https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Properties/text-anchor
VALUES_ANCHOR = {
    'top': "middle",
    'bottom': "middle",
    'right': "start",
    'left': "end"
}

# Default (x, y) shift from the data point for values shown of the chart, depending on `values_position`
DEFAULT_VALUES_POSITION_SHIFT = {
    'top': (0, -12),
    'bottom': (0, 20),
    'right': (12, 0),
    'left': (-12, 0),
}

# Define some Union types reused several times
# https://docs.python.org/3/whatsnew/3.10.html#pep-604-new-type-union-operator
Number = int | float
Number_or_string = int | float | str
Seq = list | tuple | range

def chart(
    x: Sequence[Number_or_string],
    y: Sequence[Sequence[Number | None]] | Sequence[Number | None],
    chart_type: str | Sequence[str] = "line",
    names: Sequence[str] | str = None,
    title: str = None,
    desc: str = None,
    lang: str = None,
    colors: Sequence[str] = None,
    width: Number = 1200,
    height: Number = 800,
    fullscreen: bool = False,
    x_unit: str = None,
    y_unit: str = None,
    x_ticks: int | Sequence[Number_or_string] = 6,
    x_axis_discrete: bool = True,
    y_ticks: int | Sequence[Number] = 6,
    y_ticks_interval: Number = None,
    y_min: Number = 0,
    y_max: Number = None,
    big_mark: str = None,
    decimal_mark: str = None,
    x_ticks_format: str = "{:n}",
    y_ticks_format: str = "{:n}",
    show_values: str | Sequence[Number_or_string] = None,
    values_position: str = "top",
    values_position_shift: Sequence[Number] = None,
    values_format: str = "{y}{y_unit}",
    tooltip_type: str | Sequence[str] = ("title", "value"),
    title_tooltip_format: str | Sequence[str] = DEFAULT_TOOLTIP,
    extra_data: Sequence[Sequence[Number_or_string]] | Sequence[Number_or_string] = None,
    circles: Number = 4,
    extra_lines: Sequence[dict] | dict = None,
    legend_position: str = "right",
    legend_background: str = None,
    css: Sequence[str] | str = None,
    notes: str | Sequence[str] = None,
    font_size: Number = 15,
    background_color: str = "auto",
    dark_mode: str = "user",
    pretty: bool = False,
    output: str = "string",
    **kwargs
) -> str | ET.Element:
    
    """
    Create a SVG chart

    Parameters
    ----------
    x : Sequence[int | float | str]
        The x values.
    y : Sequence[Sequence[int | float | None]] | Sequence[int | float | None]
        The y values. If multiple series must be drawn, must be a sequence of sequences.
        If some series has missing values, they have to be specified with None. If series sequence length < len(x), the last values will be missing.
    chart_type : str | Sequence[str], optional, default "line"
        The type of the chart, can be "line", "scatter" or "scatter line".
        If a sequence is provided and there are multiple series, each series will have the specified type (based on sequence position, same as `y`).
    names : Sequence[str] | str, optional
        Names of a the series. The position in the sequence must match the position of the series in y sequence.
        If not provided (or less names than the number of series defined in y), defaults to "Data series n" (with `n` incremental) or to `title` if there is just one series.
    title : str, optional
        The optional title of the chart. If provided, will be printed as a <text> element above the plotting area + a <title> element.
    desc : str
        The optional description of the chart, used in a <desc> element which is referenced by the <svg> `aria-describedby` attribute.
    lang : str, optional
        A BCP 47 language tag used in `lang` and `xml:lang` attributes added to the root <svg> element.
        if "fr" then `big_mark` parameter defaults to " " and `decimal_mark` to ",".
        See: https://developer.mozilla.org/en-US/docs/Glossary/BCP_47_language_tag.
    colors : Sequence[str], optional
        The colors of the series. Can be either a color name (e.g. "green") or a hex code (e.g. "#e91585").
        If not provided (or less names than the number of series defined in y), defaults to Okabe-Ito palette if 8 series or less, and Viridis palette if 9 <= len(series) <= 20.
        If more than 20 series in `y`, `colors` must be provided.
        Color names: https://www.w3schools.com/tags/ref_colornames.asp
        Okabe-Ito palette: https://siegal.bio.nyu.edu/color-palette
        Viridis palette: https://waldyrious.net/viridis-palette-generator
    width : int | float, optional, default 1200
        The width of the <svg> element. Used in a `viewbox` attribute (viewBox="0 0 {width} {height}").
        Will also be used in a <svg> `width` attribute if `fullscreen` = True.
    height : int | float, optional, default 800
        The height of the <svg> element. Used in a `viewbox` attribute (viewBox="0 0 {width} {height}")
        Will also be used in a <svg> `height` attribute if `fullscreen` = True.
    fullscreen : bool, optional, default False
        If True, the root <svg> element will have `width` and `height` attributes as specified in the eponymous parameters.
    x_unit : str, optional
        An optional unit for x values. If specified, will be drawn below the x axis (and centered).
        Can also be used in `x_ticks_format`, `values_format` and `title_tooltip_format` parameters as "{x_unit}".
    y_unit : str, optional
        An optional unit for y values. If specified, will be drawn above the y axis.
        Can also be used in `y_ticks_format`, `values_format` and `title_tooltip_format` parameters as "{y_unit}".
    x_ticks : int | Sequence[int | float | str], optional, default 6
        The ticks drawn in the x axis. Can be either an int representing the number of ticks to show (see `x_axis_discrete`),
        or a sequence of values.
    x_axis_discrete : bool, optional, default True
        If True and `x_ticks` is an integer, the x ticks will be equally distributed from min(x) to max(x), even if the ticks are not included in `x` values.
        If False and `x_ticks` is an integer, the x ticks values will be pulled from `x` values.
    y_ticks : int | Sequence[int | float], optional, default 6
        The ticks drawn in the y axis. Can be either an int representing the number of ticks to show (not used if `y_ticks_interval` provided),
        or a sequence of values.
    y_ticks_interval : int | float, optional
        If `y_ticks` is not a sequence, `y_ticks_interval` defines the fixed interval between each tick, from `y_min` to `y_max`.
    y_min : int | float, optional, default 0
        The min value drawn on the y ticks.
    y_max : int | float, optional
        The max value drawn on the y ticks. If not provided and `y_ticks` not provided as a sequence, will be defined as max(y), or will be computed using `y_ticks_interval` is provided.
    big_mark : str, optional
        Can be used to replace default "_" big mark separator when some numbers are formatted with "{:_}" in `x_ticks_format`, `y_ticks_format`, `values_format` or `title_tooltip_format`.
        In such a case, dont use "_" as literal text in these formats as it will also be replaced by `big_mark`.
    decimal_mark : str, optional
        Can be used to replace default "." decimal mark when some numbers are formatted with "{:.1f}" in `x_ticks_format`, `y_ticks_format`, `values_format` or `title_tooltip_format`.
        In such a case, dont use "." as literal text in these formats as it will also be replaced by `decimal_mark`.
    x_ticks_format : str, optional, default "{:n}"
        The string format used to format x ticks values. "{x}" (with formatting options) will be replaced by the tick value and "{x_unit}" by the corresponding parameter.
        See: https://docs.python.org/3/library/string.html#format-string-syntax
    y_ticks_format : str, optionall, default "{:n}"
        The string format used to format y ticks values. "{y}" (with formatting options) will be replaced by the tick value and "{y_unit}" by the corresponding parameter.
        See: https://docs.python.org/3/library/string.html#format-string-syntax
    show_values : str | Sequence[int | float | str], optional
        If provided, the specified values will be drawn on the chart (as <text> elements), next to the corresponding data points.
        Can be either "all" for displaying all values, or a sequence of x values for displaying only the corresding y values.
    values_position : str, optional, default "top"
        Where the value will be drawn relatively to the corresponding data point when `show_values` is provided or `tooltip_type` contains "value".
        Can be one of "top", "right", "bottom", "left".
    values_position_shift : Sequence[int | float], optional
        The specific shift in px defined as (x, y) relatively to the data points where to draw values when `show_values` is provided or `tooltip_type` contains "value".
        Defaults to (0, -12) when values_position="top", (0, 20) when "bottom", (12, 0) when "right" and (-12, 0) when "left".
    values_format : str, optional, default "{y}{y_unit}"
        The string format used to format values when `show_values` is provided or `tooltip_type` contains "value".
        "{y}" will be replaced by the y value, "{x}" by the x value, "{name}" by the series name, and "{x_unit}" and "{y_unit}" by the corresponding parameters.
        See: https://docs.python.org/3/library/string.html#format-string-syntax
    tooltip_type : str | Sequence[str] | None, optional, default ("title", "value")
        [Experimental] The type of tooltip to display when hovering a data point. Can be a sequence containing "title", "value", "vertical line" or None to display no tooltip.
        "title" will use <title> elements inside each <circle> elements representing the data points. These <title> elements are not rendered in mobile browsers.
        "value" will use <text> elements hidden by default and shown when hovering. It doesn't work well when there are close data points or multiple series overlapping.
        "vertical line" will show a vertical line and all y values when hovering a x virtual vertical line. It doesn't work well if lots of x values.
    title_tooltip_format : str | Sequence[str], optional, default "{name}: x = {x}{x_unit}, y = {y}{y_unit}"
        The string format used to format tooltip when `tooltip_type` contains "title".
        "{y}" will be replaced by the y value, "{x}" by the x value, "{name}" by the series name, "{extra}" by the corresponding `extra_data` for the point/series hovered, and "{x_unit}" and "{y_unit}" by the corresponding parameters.
        If a sequence is provided and there are multiple series, each series will have the specified tooltip format on hover (based on sequence position, same as `y`).
        See: https://docs.python.org/3/library/string.html#format-string-syntax
    extra_data : Sequence[Sequence[int | float | str]] | Sequence[int | float | str], optional
        Extra data that can be used in `title_tooltip_format` when `tooltip_type` contains "title".
        Must be the same type as `y`: each data point will match the specified extra data based on sequence (of sequence) position.
    circles : int | float, optional, default 4
        The <circle> radius in px (as `r` attribute).
        Used when `chart_type` contains "scatter", or `show values` is provided, or `tooltip_type` is not None.
    extra_lines : Sequence[dict] | dict, optional
        Extra horizontal or vertical lines to draw on the chart.
        Each line is defined by a dictionary containing between 1 and 4 keys:
        * 'x' for a vertical line or 'y' for a horizontal line, the value representing where to draw the line in the x or y axis. Must be the same type as `x` and `y`, multiple lines are drawn is a sequence is provided.
        * 'color' (optional, default "black"): the color of the line, either as a color name (e.g. "green") or a hex code (e.g. "#e91585").
        * 'thickness' (optional, default 2): the `stroke-width` attribute of the <line> element.
        * 'position' (optional, default "back"): whether the lines are drawn behind ("back") or in front of ("front") the plots.
        Multiple lines can be drawn using a sequence of dictionaries.
    legend_position : str | None, optional, default "right"
        Where to draw the legend (containing series names).
        To draw the legend outside the plotting area, use one of "top", "right", "bottom", "left".
        To draw the legend inside the plotting area, use one of "top left", "top right", "bottom left", "bottom right".
        None if legend must not be displayed.
    legend_background : str, optional
        If provided, the background color of the legend, either as a color name (e.g. "green") or a hex code (e.g. "#e91585").
    css : Sequence[str] | str, optional
        The optional css properties to add as is to the <style> element.
    notes : str | Sequence[str], optional
        The optional notes to display as a <text> element above the chart.
        Can contain svg elements (such as <a> for example) and raw text.
        If a note starts with "<i>", text will be displayed in italic. If it starts with "<b>", text will be displayed in bold.
        If a sequence is provided, each element will be treated as a new line, using <tspan dy="1.5em">.
    font_size : int | float, optional, default 15
        The font size (in px) of the root <svg> element.
    background_color : str | None, optional, default "auto"
        If not None, draw a <rect> fill with the specified color behind the chart.
        Can be a color name (e.g. "green") or a hex code (e.g. "#e91585").
        Defaults to "auto", which translates to "black" if `dark_mode`="force", otherwise "white".
        if `dark_mode`="user", the background <rect> will be hidden if the browser is configured in dark color scheme. 
    dark_mode : str | None, optional, default "user"
        If "user", add a few css properties to handle color scheme preference of user on web browser.
        If "force", display the chart with a black background (instead of white in light mode) and white texts and axis lines (instead of black in light mode).
        Otherwise, use light mode (white background + black text and axis lines).
    pretty : bool, optional, default False
        If True, the <svg> output will be prettified using xml.etree.ElementTree.indent() function.
        If False, the <svg> output will be minified (fits in one line).
        See: https://docs.python.org/3/library/xml.etree.elementtree.html#xml.etree.ElementTree.indent
    output : str, optional, default "string"
        If "string", the function will return the <svg> content as a string.
        If "etree", the function will return the <svg> content as a xml.etree.ElementTree.Element.
        Otherwise, will be interpreted as the name (absolute or relative path) of the svg file to create containing the chart.
        In such a case, the function will also return the xml.etree.ElementTree.Element.

    Returns
    -------
    str | xml.etree.ElementTree.Element
        SVG chart, either as a string if `output` = "string" or a xml.etree.ElementTree.Element otherwise.
        Note that if `output` is the name (absolute or relative) of a file, the SVG content is written to that file
        and the function returns the xml.etree.ElementTree.Element.
    
    Examples
    -------
    
    Create a SVG line chart with 1 series and store it in a string:
    
    >>>> my_line_chart = basic_svg_chart.chart(x = range(3), y = [100, 1000, 10000])
    
    Create a line + scatter chart with 3 series, and write it to a file named `my_chart.svg`:
    
    >>>> basic_svg_chart.chart(
    ...     type = "line scatter",
    ...     x = (2000, 2010, 2020, 2030),
    ...     y = [[10, 20, 30, None], [15, 8, 13, 22], [None, 15, 5, 10]],
    ...     names = ("", "", ""),
    ...     colors = ("red", "green", "#0d7cf8"),
    ...     output = "my_chart.svg"
    ... )

    """

    ## Check parameters and modify them when needed ##
    
    # if not isinstance(height, int | float):
    #     logging.error("🚨 height must be a number")
    #     raise SystemExit
    
    # y must be a list of lists
    if not any(isinstance(el, Seq) for el in y):
        y = (y, )
    
    if isinstance(chart_type, str):
        chart_type = [chart_type for i in range(len(y))]
    elif len(chart_type) < len(y):
        chart_type = list(chart_type)
        chart_type.extend([chart_type[-1] for i in range(len(y) - len(chart_type))])
    
    # x and x_ticks
    if x_ticks is None:
        x_ticks = list(x)
    elif isinstance(x_ticks, tuple | range):
        x_ticks = list(x_ticks)
    elif isinstance(x_ticks, int):
        x_ticks = min(x_ticks, len(x))
    
    # x must be a list of numbers or a list of strings
    if any(isinstance(el, str) for el in x):
        x = [str(el) for el in x]
        x_type_number = False
        if not(isinstance(x_ticks, int)):
            x_ticks = [str(el) for el in x_ticks]
    else:
        x_type_number = True
    
    # Names
    if names is None:
        names = []
    elif isinstance(names, tuple) or isinstance(names, range):
        names = list(names)
    elif not isinstance(names, list):
        names = [str(names)]
    
    for i in range(len(names)):
        if not isinstance(names[i], str):
            names[i] = str(names[i])
    
    # If less names provided than series, add default extra names
    old_length = len(names)
    if len(y) == 1 and old_length == 0 and title is not None and title != "":
        names = [title]
    else:
        for i in range(len(y) - len(names)):
            names.append(f"Data series {old_length + i + 1}")
    
    names_text = [replace_tags(n, keep_title = False) for n in names]
    
    # Default big_mark and decimal_mark when lang="fr"
    if lang is not None and "fr" in lang.lower():
        big_mark = " " if big_mark is None else big_mark
        decimal_mark = "," if decimal_mark is None else decimal_mark
           
    ## y ticks ##
    
    if y_ticks_format is None:
        y_ticks_format = "{}"
    
    y_ticks_values = []
    if isinstance(y_ticks, range | tuple):
        y_ticks = list(y_ticks)

    if isinstance(y_ticks, list):
        y_max = max(y_ticks)
        y_min = min(y_ticks)
        y_ticks_values = [format_text_numbers(y_ticks_format.format(z, y = z, y_unit = y_unit), big_mark, decimal_mark) for z in y_ticks]
   
    elif y_ticks_interval is not None:
        y_ticks_interval = abs(y_ticks_interval)
        y_max_defined = True
        if y_max is None:
            y_max_defined = False
            y_max = max([max([i for i in el if i is not None]) for el in y])
            
        if y_max <= y_min:
            y_min = min([min([i for i in el if i is not None]) for el in y])

        y_ticks = []
        y_value = y_min
        while y_value < y_max:
            y_ticks.append(y_value)
            y_value = y_value + y_ticks_interval
        
        if y_max_defined:
            y_ticks.append(y_max)
        else:
            y_ticks.append(y_value)
            y_max = y_value
        
        # power_tens = math.floor(math.log10(abs(y_max))) - 1
    
    elif isinstance(y_ticks, int):
        y_ticks = max(y_ticks, 2)
        if y_max is None:
            y_max = max([max([i for i in el if i is not None]) for el in y])
            power_tens = math.ceil(math.log10(abs(y_max))) - 1 # https://stackoverflow.com/questions/61008937/python-round-to-next-highest-power-of-10
            factor = 10 ** power_tens
            if 1 < y_max/factor < 1.6 or 2 < y_max/factor < 2.6 :
                power_tens -= 1
            factor = 10 ** power_tens
            y_max = math.ceil(y_max/factor) * factor * y_max / y_max
        # else:
            # power_tens = math.floor(math.log10(abs(y_max))) - 1
            
        if isinstance(y_max, float) and y_max.is_integer():
            y_max = int(y_max)
        
        if y_max <= y_min:
            y_min = min([min([i for i in el if i is not None]) for el in y])
            
        y_ticks = [y_min + i * (y_max - y_min) / (y_ticks - 1) for i in range(y_ticks)]
    
    else:
        raise TypeError("`y_ticks` must be an integer or a sequence of numbers")

    if y_ticks_values == []:
        for y_value in y_ticks:
            if isinstance(y_value, float) and y_value.is_integer():
                y_value = int(y_value)
                
            y_ticks_values.append(format_text_numbers(y_ticks_format.format(y_value, y = y_value, y_unit = y_unit), big_mark, decimal_mark))

    # Units
    x_unit = str(x_unit or "")
    y_unit = str(y_unit or "")
    
    # Tooltip
    if tooltip_type is None:
        tooltip_type = "no"
        
    if extra_data is not None and not any(isinstance(el, Seq) for el in extra_data):
        extra_data = (extra_data, )
        
    # Show values
    if show_values is not None and not isinstance(show_values, Sequence | Number_or_string) and show_values != "all":
        show_values = None

    if isinstance(show_values, Number_or_string) and show_values != "all":
        show_values = (show_values, )
    
    if isinstance(values_position_shift, Number):
        values_position_shift = (values_position_shift, 0)
    elif values_position_shift is not None and not isinstance(values_position_shift, Seq):
        logging.warning(f"⚠️  `values_position_shift` must be a sequence, not a {type(values_position_shift)}")
        values_position_shift = None
        
    show_some_values = show_values is not None or "vertical line" in tooltip_type or "value" in tooltip_type
      
    if values_position_shift is None and show_some_values:
        values_position_shift = DEFAULT_VALUES_POSITION_SHIFT[values_position]
    
    # Circles
    # if circles <= 0 and ("title" in tooltip_type or "vertical line" in tooltip_type or show_values is not None):
    if circles is None or circles <= 0:
        circles = 4
    
    ## Chart plotting area size, and space around it for title, legend, notes... ##
    
    if title is not None and title != "":
        top = font_size * 1.4 * 2
    else:
        top = 20
    
    width_y_max = max([len(x) for x in y_ticks_values])
    left = 20 + 9 * width_y_max
    
    abscissa_height = 12 + font_size
    bottom = abscissa_height
    
    if isinstance(notes, str):
        notes = [notes]
    
    if notes is not None and len(notes) > 0:
        bottom = bottom + (font_size / 2) + (font_size * 1.5 * len(notes))
    else:
        bottom = bottom + (font_size / 2)
    
    right = 20
    
    # Space for legend
    legend_width = 70 + (max([len(n) for n in names_text]) * font_size / 2)
    legend_height = font_size * 2
    
    if legend_position == "right":
        right = legend_width
    elif legend_position == "top":
        top = top + legend_height
    elif legend_position == "left":
        left = left + legend_width
    elif legend_position == "bottom":
        bottom = bottom + legend_height
        
    if show_some_values and values_position == "right":
        right = right + (font_size * 2)

    if x_unit is not None and x_unit != "":
        bottom = bottom + (font_size * 1.5)
    
    spaces = SimpleNamespace(top = top, right = right, bottom = bottom, left = left)
    chart_width = width - spaces.left - spaces.right
    chart_height = height - spaces.top - spaces.bottom
    
    logging.info(f"plotting area size: {num_attr(chart_width)} x {num_attr(chart_height)}")
    
    ## x axis ##
    
    if isinstance(x, range | tuple):
        x = list(x)
    
    if x_type_number:
        x_min = min(x)
        if isinstance(x_ticks, list) and min(x_ticks) < x_min:
            x_min = min(x_ticks)
        
        x_max = max(x)
        if isinstance(x_ticks, list) and max(x_ticks) > x_max:
            x_max = max(x_ticks)
        
        x_interval_px = chart_width / (x_max - x_min)
        
        if isinstance(x_ticks, int):
            x_ticks = max(2, x_ticks)
            if x_axis_discrete:
                x_values = x.copy()
                x_values.sort()
                
                interval = round((len(x) - 1)  / (x_ticks - 1))
                list_ticks = []
                for i in range(x_ticks - 1):
                    list_ticks.append(x_values[i * interval])
                    
                list_ticks.append(x_max)
                x_ticks = list_ticks
            
            else:
                list_ticks = []
                x_value = x_min
                for i in range(x_ticks):
                    list_ticks.append(x_value)
                    x_value = x_value + (x_max - x_min) / (x_ticks - 1)
                    if isinstance(x_value, float) and x_value.is_integer():
                        x_value = int(x_value)
                x_ticks = list_ticks
        
    else:
        x_interval_px = chart_width / (len(x) - 1)
        x_min = x[0]
        
        if isinstance(x_ticks, int):
            interval = round((len(x) - 1)  / (x_ticks - 1))
            list_ticks = []
            for i in range(x_ticks - 1):
                list_ticks.append(x[i * interval])
                
            list_ticks.append(x[-1])
            x_ticks = list_ticks
    
    # x ticks format
    if x_ticks_format is None:
        x_ticks_format = "{}"

    
    ## <svg> ##
    chart = ET.Element("svg",
        # https://stackoverflow.com/questions/56061765/inkscape-ignores-use
        # https://www.unimelb.edu.au/accessibility/techniques/accessible-svgs
        attrib = {'xmlns': "http://www.w3.org/2000/svg", 'xmlns:xlink': "http://www.w3.org/1999/xlink"},
        viewBox = f"0 0 {width} {height}",
        # preserveAspectRatio = "xMinYMin", # https://developer.mozilla.org/fr/docs/Web/SVG/Reference/Attribute/preserveAspectRatio
        style = f"font-size: {font_size}px",
        role = "img",
    )
    
    if not fullscreen:
       chart.attrib.update({'width': str(width), 'height': str(height)}) 
    
    if lang is not None:
        # https://kb.daisy.org/publishing/docs/html/svg.html#desc-lang
        chart.attrib.update({'lang': lang, 'xml:lang': lang})
    
    # <style>
    style = ET.SubElement(chart, "style", type = "text/css")
    style_css = list(DEFAULT_CSS)
    r_circles_hover = max(circles + 2, circles * 1.25)
    style_css.append(f"circle:hover {{r: {r_circles_hover}px;}}")
        
    # Background color
    if background_color is not None and background_color != "":
        chart.append(ET.Element("rect", width = "100%", height = "100%", attrib = {'class': "background-color"}))
        if background_color == "auto":
            background_color = "black" if dark_mode == "force" else "white"
        style_css.append(f"rect.background-color {{fill: {background_color};}}")
    else:
        background_color = None
    
    # <title>
    if title is not None and title != "":
        # No builtin support for CDATA with ET: https://stackoverflow.com/questions/174890/how-to-output-cdata-using-elementtree
        # "<![CDATA[" + title + "]]>"
        ET.SubElement(chart, "title", id = "title").text = replace_tags(title)
        chart.attrib["aria-labelledby"] = "title"
    
    # <desc>
    if desc is not None and desc != "":
        ET.SubElement(chart, "desc", id = "description").text = desc
        chart.attrib["aria-describedby"] = "description"
    
    # <defs>
    defs = ET.SubElement(chart, "defs")
    
    if show_some_values:
        baseline = " dominant-baseline: central;" if values_position in ["left", "right"] else ""
        style_css.append(f"g.series > text {{text-anchor: {VALUES_ANCHOR[values_position]};{baseline}}}")
        
        # Add background color for value hovered
        if background_color is not None:
            filter_bg_val = ET.SubElement(defs, "filter", id = "bg_val", x = "0", width = "1", y = "0.1", height = "0.8")
            ET.SubElement(filter_bg_val, "feFlood", {'flood-color': background_color, 'flood-opacity': "0.9", 'result': "bg_val_text"})
            feMerge = ET.SubElement(filter_bg_val, "feMerge")
            ET.SubElement(feMerge, "feMergeNode", {'in': "bg_val_text"})
            ET.SubElement(feMerge, "feMergeNode", {'in': "SourceGraphic"})
                
            style_css.append("g.series > text {filter: url(#bg_val);}")
    
    # Colors
    if colors is None:
        colors = []
    elif isinstance(colors, str):
        colors = [colors]
    elif isinstance(colors, tuple):
        colors = list(colors)
    
    missing_colors_nb = len(y) - len(colors)
    if missing_colors_nb > len(VIRIDIS):
        logging.error("🚨 You have to specify `colors` when more than 20 series")
        raise SystemExit
    elif missing_colors_nb > 0:
        # palette = OKABE_ITO if len(y) <= 8 else VIRIDIS
        if missing_colors_nb <= len(OKABE_ITO):
            colors.extend(OKABE_ITO[0:missing_colors_nb])
        else:
            colors.extend(VIRIDIS[missing_colors_nb - 1])
    
    for i in range(len(y)):
        color = colors[min(len(colors) - 1, i)]
        style_css.append(f".color{i + 1} {{fill: {color}; stroke: {color};}}")
        style_css.append(f".color{i + 1} text, text.color{i + 1} {{fill: {color}; stroke: none; font-weight: bold;}}")
    
    # Title text
    if title is not None and title != "":
        title = "<text>" + title + "</text>"
        title = ET.fromstring(title)
        title.attrib = {'class': "title", 'x': num_attr(spaces.left + chart_width/2), 'y': num_attr(spaces.top / 1.8)}
        chart.append(title)
    
    # Chart shift
    translate = ET.SubElement(chart, "g", id = "position", transform = f"translate({spaces.left}, {spaces.top})")
    
    ## Abscissa axis ##
    
    g_abscissa_lines = ET.Element("g", id = "abscissa_lines")
    g_abscissa_text = ET.Element("g", id = "abscissa_text")
    
    # Abscissa line
    ET.SubElement(g_abscissa_lines, "line", x1 = "-8", x2 = num_attr(chart_width), y1 = num_attr(chart_height), y2 = num_attr(chart_height), stroke = "black", attrib = {'stroke-width': "2", 'stroke-linecap': "square"})
    
    # Vertical dotted gridlines
    vertical_dotted_lines = ET.SubElement(defs, "g", id = "vertical_dotted_lines")
    ET.SubElement(vertical_dotted_lines, "line", x1 = "0", x2 = "0", y1 = "0", y2 = num_attr(chart_height), stroke = "lightgrey", attrib = {'stroke-width': "1", 'stroke-linecap': "square", 'stroke-dasharray': "5.5"})
    ET.SubElement(vertical_dotted_lines, "line", x1 = "0", x2 = "0", y1 = num_attr(chart_height), y2 = num_attr(chart_height + 8), stroke = "black")

    coord_x = 0
    for tick in [el for el in x_ticks if (not(x_type_number) or el >= x_min)]:
        if x_type_number:
            coord_x = x_interval_px * (tick - x_min)
            text = format_text_numbers(x_ticks_format.format(tick, x = tick, x_unit = x_unit), big_mark, decimal_mark)
        else:
            coord_x = x_interval_px * x.index(tick)
            text = str(tick) if x_ticks_format == "{:n}" else x_ticks_format.format(str(tick), x = str(tick), x_unit = x_unit)
        if round(coord_x, 2) <= round(chart_width, 2):
            if (tick != x_min):
                ET.SubElement(g_abscissa_lines, "use", attrib = {"xlink:href": "#vertical_dotted_lines"}, x = num_attr(coord_x))
            ET.SubElement(g_abscissa_text, "text", x = num_attr(coord_x), y = num_attr(chart_height + abscissa_height)).text = text

        
    # Unit
    if x_unit != "":
        ET.SubElement(g_abscissa_text, "text", {'class': "unit", 'dominant-baseline': "central"}, x = num_attr(chart_width/2), y = num_attr(chart_height + 30 + font_size)).text = x_unit
  
    ## Ordinate axis ##
    
    g_ordinate_axis = ET.Element("g", id = "ordinate")
    
    # Vertical ordinate line
    ET.SubElement(g_ordinate_axis, "line", {'stroke-width': "2", 'stroke-linecap': "square"}, x1 = "0", x2 = "0", y1 = num_attr(chart_height + 8), y2 = "0", stroke = "black")
    
    # Horizontal dotted gridlines
    horizontal_dotted_lines = ET.SubElement(defs, "g", id = "horizontal_dotted_lines")
    ET.SubElement(horizontal_dotted_lines, "line", x1 = "0", x2 = num_attr(chart_width), y1 = "0", y2 = "0", stroke = "lightgrey", attrib = {'stroke-width': "1", 'stroke-linecap': "square", 'stroke-dasharray': "5.5"})
    ET.SubElement(horizontal_dotted_lines, "line", x1 = "0", x2 = "-8", y1 = "0", y2 = "0", stroke = "black")   

    for i in range(len(y_ticks)):
        y_value = y_ticks[i]
        pos = chart_height * (y_max - y_value) / (y_max - y_min)

        if y_value != y_min:
            ET.SubElement(g_ordinate_axis, "use", attrib = {"xlink:href": "#horizontal_dotted_lines"}, y = num_attr(pos))

        val = y_ticks_values[i]
        ET.SubElement(g_ordinate_axis, "text", x = "-14", y = num_attr(pos)).text = val
    
    # Ordinate unit
    if y_unit != "":
        ET.SubElement(g_ordinate_axis, "text", {'class': "unit"}, x = "-20", y = num_attr(-font_size * 1.25)).text = y_unit
        
    ## Extra lines ##
    # If color, thickness and/or position not provided, add default values
    back_lines, front_lines = [], []
    if extra_lines is not None:
        if isinstance(extra_lines, dict):
            extra_lines = (extra_lines, )
        for li in extra_lines:
            if "color" not in li:
                li["color"] = "black"
            if "thickness" not in li:
                li["thickness"] = 2
            if "position" not in li:
                li["position"] = "back"
    else:
        extra_lines = ()
        
    for li in extra_lines:
        if "y" in li:
            if not isinstance(li["y"], list):
                li["y"] = [li["y"]]
            
            for y_value in li["y"]:
                pos = chart_height * (y_max - y_value) / (y_max - y_min)
                line = ET.Element("line", attrib = {'x1': "0", 'x2': num_attr(chart_width), 'y1': num_attr(pos), 'y2': num_attr(pos), 'stroke': li["color"], 'stroke-width': num_attr(li["thickness"]), 'stroke-linecap': "square"})
                back_lines.append(line) if li["position"] == "back" else front_lines.append(line)
                
        if "x" in li:
            if not isinstance(li["x"], list):
                li["x"] = [li["x"]]
                
            for x_value in li["x"]:
                pos = x_interval_px * (x_value - x_min) if x_type_number else x_interval_px * x.index(x_value)
                line = ET.Element("line", attrib = {'x1': num_attr(pos), 'x2': num_attr(pos), 'y1': "0", 'y2': num_attr(chart_height), 'stroke': li["color"], 'stroke-width': num_attr(li["thickness"]), 'stroke-linecap': "square"})
                back_lines.append(line) if li["position"] == "back" else front_lines.append(line)
    
    # Add elements to translate root element
    translate.append(g_ordinate_axis)
    translate.append(g_abscissa_lines)
    translate.extend(back_lines)
    # translate.append(g_abscissa_text)
    
    ## Vertical line showing values on hover ##
    if "vertical line" in tooltip_type:
        style_css.append(".hover_values * {opacity: 0;}")
        style_css.append(".hover_values:hover * {stroke-width: 3px; opacity: 1;}")
        style_css.append(".hover_values > text.abscissa {text-anchor: middle; font-weight: bold; filter: url(#bg_abs);}")
        style_css.append(f".hover_values > line {{stroke: black; stroke-width: {round(x_interval_px * 1.5)}px;}}")
        style_css.append(".hover_values:hover ~ g#abscissa_text {opacity: 0.2;}")
        
        # Add background color for highlighted abscissa
        # https://stackoverflow.com/questions/15500894/background-color-of-text-in-svg
        filter_bg_abs = ET.SubElement(defs, "filter", id = "bg_abs", x = "-0.3", y = "-0.1", width = "1.6", height = "1.2")
        ET.SubElement(filter_bg_abs, "feFlood", {'flood-color': "yellow", 'result': "bg_abs_text"})
        feMerge = ET.SubElement(filter_bg_abs, "feMerge")
        ET.SubElement(feMerge, "feMergeNode", {'in': "bg_abs_text"})
        ET.SubElement(feMerge, "feMergeNode", {'in': "SourceGraphic"})
        
        # Line and abscissa text
        hv_line = ET.Element("line", x1 = "0", x2 = "0", y1 = "0", y2 = num_attr(chart_height + 8))
        hv_abs_text = ET.Element("text", {'class': "abscissa"}, x = "0", y = num_attr(chart_height + abscissa_height))

        for i in range(len(x)):
            if x_type_number:
                coord_x = x_interval_px * (x[i] - x_min)
            else:
                coord_x = x_interval_px * i
            
            hover_values = ET.SubElement(translate, "g", {'class': f"hover_values x{i + 1}"}, transform = f"translate({num_attr(coord_x)})")
            hover_values.append(hv_line)
            text = format_text_numbers(x_ticks_format.format(x[i], x = x[i], x_unit = x_unit), big_mark, decimal_mark) if x_type_number else str(x[i])
            t = copy.deepcopy(hv_abs_text)
            t.text = text
            hover_values.append(t)
            style_css.append(f".hover_values.x{i + 1}:hover ~ g#series_plots .x{i + 1} {{opacity: 1; r: {r_circles_hover}px;}}")
    
    translate.append(g_abscissa_text)
    
    ### Series plots ###
    
    series_plots = ET.SubElement(translate, "g", id = "series_plots")
        
    ## Line or scatter chart
    
    # For each series
    for i_y in range(len(y)):
        fig = ET.SubElement(series_plots, "g", {'class': f"series color{i_y + 1}"}, id = f"series{i_y + 1}")
        ET.SubElement(fig, "title").text = names_text[i_y]
        points = ""
        coord_x = 0
        first = True

        show_circles = ("scatter" in chart_type[i_y] or ("title" in tooltip_type and title_tooltip_format[i_y] is not None) or "vertical line" in tooltip_type or "value" in tooltip_type or show_values == "all")

        # For each data point
        for i in range(min(len(x), len(y[i_y]))):
            if y[i_y][i] is not None:
                if x_type_number:
                    coord_x = x_interval_px * (x[i] - x_min)
                else:
                    coord_x = x_interval_px * i

                coord_y = (y_max - y[i_y][i]) * chart_height / (y_max - y_min)
                        
                # <path>
                if "line" in chart_type[i_y] :
                    if first and (i == len(y[i_y]) - 1 or y[i_y][i+1] is None):
                        isolated_point = True
                    else:
                        isolated_point = False
                        command = "M " if first else "L "
                        points += command + num_attr(coord_x) + "," + num_attr(coord_y) + " "
                else:
                    isolated_point = True
                
                # extra data
                if isinstance(extra_data, Seq):
                    try:
                        extra_text = extra_data[i_y][i]
                    except (IndexError, TypeError):
                        extra_text = None
                else:
                    extra_text = None
                
                # show some values
                show_val = show_values is not None and (show_values == "all" or x[i] in show_values)
                if show_val or "vertical line" in tooltip_type or "value" in tooltip_type:
                    val = format_text_numbers(values_format.format(y[i_y][i], y = y[i_y][i], y_unit = y_unit, name = names_text[i_y], x = x[i], x_unit = x_unit, extra = extra_text), big_mark, decimal_mark)
                    cur_text = ET.Element("text", x = num_attr(coord_x + values_position_shift[0]), y = num_attr(coord_y + values_position_shift[1]))
                    cur_text.text = val
                    
                    cl = "" if show_val else "hide"
                    if "vertical line" in tooltip_type:
                        cl = cl + f" x{i + 1}"
                    if cl != "":
                        cur_text.attrib["class"] = cl.strip()
                    
                # <circle>
                if show_circles or show_val or isolated_point:
                    cur_circle = ET.SubElement(fig, "circle", r = str(circles), cx = num_attr(coord_x), cy = num_attr(coord_y))
                    cl = "" if show_val or isolated_point or "scatter" in chart_type[i_y] else "hide"
                    if "vertical line" in tooltip_type:
                        cl = cl + f" x{i + 1}"
                    if cl != "":
                        cur_circle.attrib["class"] = cl.strip()
                    
                    if "title" in tooltip_type:
                        if isinstance(title_tooltip_format, Seq):
                            try:
                                tooltip_text = title_tooltip_format[i_y]
                            except IndexError:
                                tooltip_text = DEFAULT_TOOLTIP
                        else:
                            tooltip_text = title_tooltip_format
                        
                        if tooltip_text is not None and tooltip_text != "":
                            tooltip_text = format_text_numbers(
                                tooltip_text.format(name = names_text[i_y], x = x[i], x_unit = x_unit, y = y[i_y][i], y_unit = y_unit, extra = extra_text),
                                big_mark,
                                decimal_mark)
                                
                            ET.SubElement(cur_circle, "title").text = tooltip_text
                
                # Add <text> after <circle>
                if show_val or "vertical line" in tooltip_type or "value" in tooltip_type:
                    fig.append(cur_text)
                
                if first:
                    first = False

            else:
                first = True
        
        if points != "":
            fig.insert(1, ET.Element("path", d = points, fill = "none", attrib = {'stroke-width': "3", 'stroke-linejoin': "round"}))


    # Extra font lines
    translate.extend(front_lines)
    
    ## Legend ##
    if legend_position is not None and legend_position != "" and legend_position != "no":
        # x coordinate
        if legend_position == "right":
            coord_x = chart_width + 25
        elif legend_position == "left":
            coord_x = 20 - spaces.left
        elif "right" in legend_position:
            coord_x = chart_width - legend_width
        elif legend_position == "top":
            coord_x = 20 if y_unit is None else 5 + (len(y_unit) * font_size / 2)
        elif legend_position == "bottom":
            coord_x = 20 - spaces.left
        else:
            coord_x = 20
        
        # y coordinate
        if legend_position in ["right", "left", "top right", "top left"]:
            coord_y = 15
        elif legend_position == "top":
            coord_y = -font_size * 1.25
        elif legend_position == "bottom":
            coord_y = chart_height + abscissa_height + font_size
            if x_unit is not None and x_unit != "":
                coord_y = coord_y + font_size
        elif "bottom" in legend_position:
            coord_y = chart_height - (2 * font_size * len(y))
            
        if legend_background is not None:
            coord_y_rect = coord_y - font_size + 2
        
        # Symbol + text
        for i_y in range(len(y)):
            g_legend = ET.SubElement(series_plots[i_y], "g", id = f"legend{i_y + 1}", attrib = {'class': "legend"})
            if "line" in chart_type[i_y] :
                ET.SubElement(g_legend, "line", {'stroke-width': "5"}, x1 = num_attr(coord_x), x2 = num_attr(coord_x + 25), y1 = num_attr(coord_y), y2 = num_attr(coord_y))
            if "scatter" in chart_type[i_y] or show_values == "all":
                ET.SubElement(g_legend, "circle", cx = num_attr(coord_x + 12.5), cy = num_attr(coord_y), r = num_attr(circles))

            if names_text[i_y] != names[i_y]:
                cur_legend = ET.SubElement(g_legend, "text", x = num_attr(coord_x + 40), y = num_attr(coord_y + 5))
                if names[i_y].startswith("<") and names[i_y].endswith(">"):
                    cur_legend.append(ET.fromstring(names[i_y]))
                else:
                    cur_legend.append(ET.fromstring("<tspan>" + names[i_y] + "</tspan>"))
            else:
                ET.SubElement(g_legend, "text", x = num_attr(coord_x + 40), y = num_attr(coord_y + 5)).text = f"{names[i_y]}"
            
            if legend_position in ["top", "bottom"]:
                coord_x += 60 + (len(names_text[i_y]) * font_size / 2)
            else:
                coord_y += 2 * font_size
        
        # Add a rect background color behind the legend elements
        if legend_background is not None and legend_background != "":
            height = coord_y - font_size if "top" in legend_position else 2 * font_size * len(y)
            pos = len(translate) - 1
            translate.insert(pos, ET.Element("rect", id = "legend_bg", opacity = "0.7", x = num_attr(coord_x - 5), width = num_attr(legend_width), y = num_attr(coord_y_rect), height = num_attr(height - 4), fill = legend_background))
    
    ## Notes ##
    
    if notes is not None and len(notes) > 0:
        text_notes = ET.SubElement(translate, "text", id = "notes")
        text_y = chart_height + abscissa_height
        if legend_position == "bottom":
            text_y += legend_height
        if x_unit != "":
            text_y += font_size * 1.5
        
        text_notes.attrib["y"] = num_attr(text_y)

        for n in notes:
            tag = n[:3]
            if tag in ["<i>", "<b>"]:
                n = n[3:]
            
            n = "<tspan>" + n + "</tspan>"
            tspan = ET.fromstring(n)
            tspan.attrib = {'x': num_attr(20 - spaces.left), 'dy': "1.5em"}
            if tag == "<i>":
                tspan.attrib["font-style"] = "italic"
            elif tag == "<b>":
                tspan.attrib["font-weight"] = "bold"
            text_notes.append(tspan)
    
    ## CSS ##
    # Dark mode
    if background_color is None or background_color in ("white", "black"):
        if dark_mode == "user":
            style_css.append(":root {color-scheme: light dark;}")
            style_css.append("@media (prefers-color-scheme: dark) {")
            style_css.append("  rect.background-color {display: none;}")
            style_css.extend(["  " + c for c in DARK_MODE_CSS])
            style_css.append("}")
            
        elif dark_mode == "force":
            style_css.append(":root {color-scheme: dark;}")
            style_css.extend(DARK_MODE_CSS)
    
    # Personalised css
    if css is not None:
        css = [css] if isinstance(css, str) else css
        style_css.extend(css)
    
    # String transformation
    if pretty:
        style_css = ["    " + c for c in style_css]
    
    css_sep = "\n" if pretty else " "
    style_css = css_sep.join(style_css)
    
    style.text = css_sep + style_css + css_sep

    if pretty:
        # requires Python >= 3.9 : https://docs.python.org/3/library/xml.etree.elementtree.html#xml.etree.ElementTree.indent
        try:
            ET.indent(chart) 
        except AttributeError:
            python_version = "python " + ".".join(map(str, sys.version_info[:3]))
            logging.warning(f"⚠️  You're using {python_version}, but python >= 3.9 required if parameter pretty=True (because it's using `xml.etree.ElementTree.indent` function)\n➡️ The SVG output won't be prettified")
    
    if output == "string":
        chart = ET.tostring(chart, encoding = "UTF-8").decode("UTF-8")
        # try:
            # chart = ET.tostring(chart, encoding = "UTF-8", xml_declaration = True).decode("UTF-8")
        # except TypeError:
            # `xml_declaration` parameter added in Python 3.8 : https://docs.python.org/3/library/xml.etree.elementtree.html#xml.etree.ElementTree.tostring
            # chart = ET.tostring(chart, encoding = "UTF-8").decode("UTF-8")
    
    elif output != "etree":
        ET.ElementTree(chart).write(output, encoding = "UTF-8", xml_declaration = True)
        logging.info(f"chart written in file {output}")
        # return

    logging.info(chart.__class__)
    
    return chart

# Alternate functions with fixed chart_type

# https://www.geeksforgeeks.org/python/transfer-kwargs-parameter-to-a-different-function-in-python/
def line_chart(**kwargs):
    """ Create a SVG line chart """
    return chart(chart_type = "line", **kwargs)

def scatter_chart(**kwargs):
    """ Create a SVG scatter chart """
    return chart(chart_type = "scatter", **kwargs)

def scatter_line_chart(**kwargs):
    """ Create a SVG scatter + line chart """
    return chart(chart_type = "scatter line", **kwargs)

