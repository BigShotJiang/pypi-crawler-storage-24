""" Basic SVG charting library """

from .basic_svg_chart import chart, line_chart, scatter_chart, scatter_line_chart
from .utils import replace_tags, num_attr

# https://docs.python.org/3/tutorial/modules.html#importing-from-a-package
__all__ = ["chart", "line_chart", "scatter_chart", "scatter_line_chart", "replace_tags", "num_attr"]

__version__ = "0.1.0"

