"""Utility functions"""

import re

def replace_tags(text: str, keep_title: bool = True) -> str:
    """
    Remove xml tags from a string, while keeping their content except for <title> if keep_title is False.

    Parameters
    ----------
    text : str
        The string containing xml tags.
    keep_title : bool, optional
        If true, if text contains <title> tags, the content is kept (and surrounded by parenthesis). Otherwise the content is removed. The default is True.

    Returns
    -------
    str
        The text string without tags.
        
    Examples
    --------
    >>> replace_tags("Source : <tspan class='abbr'>ONU<title>Organisation des Nations unies</title></tspan> division Population, <a href='https://population.un.org/wpp/'>World Population Prospects 2024</a>.")
    'Source : ONU (Organisation des Nations unies), division Population, World Population Prospects 2024.'
    
    >>> replace_tags("<p><title id='p1'>First paragraph</title>Blablablabla</p><p><a href='#top'><title>Back top top</title>Top</p>", keep_title = False)
    'Blablablabla Top'

    """
    if keep_title:
        text = re.sub(r"<title[^>]*>([^<]+)</title>", " (\\1) ", text)
    else:
        text = re.sub(r"<title[^>]*>([^<]+)</title>", " ", text)
    text = re.sub(r"<[^<]+>", "", text)
    text = re.sub(" {2,}", " ", text)
    return(text.strip())


def num_attr(x: float, decimals: int = 2) -> str:
    """
    Convert a float to string, while first converting it to integer if this number is_integer() or rounding it if it isn't.

    Parameters
    ----------
    x : float
        The number to convert to string.
    decimals : int, optional
        Number of decimals to keep for real floats. The default is 2.

    Returns
    -------
    str
        The number converted to string with the requested number of decimals.
        
    Examples
    --------
    >>> num_attr(123.4567, 1)
    '123.5'

    >>> num_attr(3.0)
    '3'
    """
    if isinstance(x, float) and x.is_integer():
        return str(int(x))
    elif isinstance(x, float):
        return f"{{:.{decimals}f}}".format(x)
        # x = round(x, decimals)

    return(str(x))


def format_decimal(x: float, decimals: int = 0) -> str:
    """
    Format a float (rounded to decimals) by using " " for big mark and "," for decimal mark.

    Parameters
    ----------
    x : float
        The number to format.
    decimals : int, optional
        Number of decimals to keep. The default is 0.

    Returns
    -------
    str
        The number rounded to the requested number of decimals, and formatted with " " as big mark and "," as decimal mark.
        
    Example
    --------
    >>> format_decimal(123456.789, 1)
    '123 456,8'
    """
    num_format = f"{{0:_.{decimals}f}}"
    return(num_format.format(x).replace('_', ' ').replace('.', ','))

def format_text_numbers(text: str, big_mark: str, decimal_mark: str) -> str:
    """
    Replace characters "_" and "." in a string by specified replacements.
    
    Parameters
    ----------
    text : str
        The string potentially containing "_" and "." to be replaced.
    big_mark : str
        The replacement for "_" characters.
    decimal_mark : str
        The replacement for "." characters.

    Returns
    -------
    str
        A string with "_" and "." replaced as requested.
        
    Example
    --------
    >>> format_text_numbers(text = "Population mondiale 2023 : 8_091.73 millions", big_mark = " ", decimal_mark = ",")
    'Population mondiale 2023 : 8 091,73 millions'
    """
    if big_mark is not None and big_mark != "":
        text = text.replace('_', big_mark)
    if decimal_mark is not None and decimal_mark != "":
       text = text.replace('.', decimal_mark)
    return text
