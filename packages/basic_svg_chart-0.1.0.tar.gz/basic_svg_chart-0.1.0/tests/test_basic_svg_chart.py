import os
import re
import xml.etree.ElementTree as ET

import pytest

import basic_svg_chart as bsc


def test_chart_string_output():
    svg = bsc.chart(x = [0, 1, 2], y = [[10, 20, 30], [15, 8, 22], [None, 15, 5]])
    expected = '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1200 800" style="font-size: 15px" role="img" width="1200" height="800"><style type="text/css"> text.title {font-weight: bold; font-size: 1.4em; text-anchor: middle;} g.series &gt; path:hover {stroke-width: 5px;} g#series_plots:hover .series {opacity: 0.2;} g#series_plots &gt; g.series:hover {opacity: 1;} .abbr {cursor: help; text-decoration:underline dashed; text-underline-position: under; text-decoration-thickness: 1.5px;} a {fill: darkblue;} a:hover {text-decoration: underline;} g#ordinate &gt; text {text-anchor: end; dominant-baseline: central;} g#ordinate &gt; text.unit {text-anchor: start;} g#abscissa_text &gt; text {text-anchor: middle;} .hide {opacity: 0;} circle:hover + text.hide {opacity: 1;} circle.hide:hover {opacity: 1;} circle:hover {r: 6px;} rect.background-color {fill: white;} g.series &gt; text {text-anchor: middle;} g.series &gt; text {filter: url(#bg_val);} .color1 {fill: #E69F00; stroke: #E69F00;} .color1 text, text.color1 {fill: #E69F00; stroke: none; font-weight: bold;} .color2 {fill: #56B4E9; stroke: #56B4E9;} .color2 text, text.color2 {fill: #56B4E9; stroke: none; font-weight: bold;} .color3 {fill: #009E73; stroke: #009E73;} .color3 text, text.color3 {fill: #009E73; stroke: none; font-weight: bold;} :root {color-scheme: light dark;} @media (prefers-color-scheme: dark) {   rect.background-color {display: none;}   text {fill: white;}   [stroke=\'black\'] {stroke: white;}   line[stroke-dasharray] {stroke: grey;}   a {fill: deepskyblue;}   g#series_plots:hover .series {opacity: 0.4;}   rect#legend_bg[fill=\'white\'] {fill: black;}   .hover_values &gt; line {stroke: white;}   filter#bg_abs &gt; feFlood {flood-color: green;}   filter#bg_val &gt; feFlood {flood-color: black; flood-opacity: 0.7;} } </style><rect class="background-color" width="100%" height="100%" /><defs><filter id="bg_val" x="0" width="1" y="0.1" height="0.8"><feFlood flood-color="white" flood-opacity="0.9" result="bg_val_text" /><feMerge><feMergeNode in="bg_val_text" /><feMergeNode in="SourceGraphic" /></feMerge></filter><g id="vertical_dotted_lines"><line stroke-width="1" stroke-linecap="square" stroke-dasharray="5.5" x1="0" x2="0" y1="0" y2="745.50" stroke="lightgrey" /><line x1="0" x2="0" y1="745.50" y2="753.50" stroke="black" /></g><g id="horizontal_dotted_lines"><line stroke-width="1" stroke-linecap="square" stroke-dasharray="5.5" x1="0" x2="994.50" y1="0" y2="0" stroke="lightgrey" /><line x1="0" x2="-8" y1="0" y2="0" stroke="black" /></g></defs><g id="position" transform="translate(38, 20)"><g id="ordinate"><line stroke-width="2" stroke-linecap="square" x1="0" x2="0" y1="753.50" y2="0" stroke="black" /><text x="-14" y="745.50">0</text><use xlink:href="#horizontal_dotted_lines" y="596.40" /><text x="-14" y="596.40">6</text><use xlink:href="#horizontal_dotted_lines" y="447.30" /><text x="-14" y="447.30">12</text><use xlink:href="#horizontal_dotted_lines" y="298.20" /><text x="-14" y="298.20">18</text><use xlink:href="#horizontal_dotted_lines" y="149.10" /><text x="-14" y="149.10">24</text><use xlink:href="#horizontal_dotted_lines" y="0" /><text x="-14" y="0">30</text></g><g id="abscissa_lines"><line stroke-width="2" stroke-linecap="square" x1="-8" x2="994.50" y1="745.50" y2="745.50" stroke="black" /><use xlink:href="#vertical_dotted_lines" x="497.25" /><use xlink:href="#vertical_dotted_lines" x="994.50" /></g><g id="abscissa_text"><text x="0" y="772.50">0</text><text x="497.25" y="772.50">1</text><text x="994.50" y="772.50">2</text></g><g id="series_plots"><g class="series color1" id="series1"><title>Data series 1</title><path stroke-width="3" stroke-linejoin="round" d="M 0,497 L 497.25,248.50 L 994.50,0 " fill="none" /><circle r="4" cx="0" cy="497" class="hide"><title>Data series 1: x = 0, y = 10</title></circle><text x="0" y="485" class="hide">10</text><circle r="4" cx="497.25" cy="248.50" class="hide"><title>Data series 1: x = 1, y = 20</title></circle><text x="497.25" y="236.50" class="hide">20</text><circle r="4" cx="994.50" cy="0" class="hide"><title>Data series 1: x = 2, y = 30</title></circle><text x="994.50" y="-12" class="hide">30</text><g class="legend" id="legend1"><line stroke-width="5" x1="1019.50" x2="1044.50" y1="15" y2="15" /><text x="1059.50" y="20">Data series 1</text></g></g><g class="series color2" id="series2"><title>Data series 2</title><path stroke-width="3" stroke-linejoin="round" d="M 0,372.75 L 497.25,546.70 L 994.50,198.80 " fill="none" /><circle r="4" cx="0" cy="372.75" class="hide"><title>Data series 2: x = 0, y = 15</title></circle><text x="0" y="360.75" class="hide">15</text><circle r="4" cx="497.25" cy="546.70" class="hide"><title>Data series 2: x = 1, y = 8</title></circle><text x="497.25" y="534.70" class="hide">8</text><circle r="4" cx="994.50" cy="198.80" class="hide"><title>Data series 2: x = 2, y = 22</title></circle><text x="994.50" y="186.80" class="hide">22</text><g class="legend" id="legend2"><line stroke-width="5" x1="1019.50" x2="1044.50" y1="45" y2="45" /><text x="1059.50" y="50">Data series 2</text></g></g><g class="series color3" id="series3"><title>Data series 3</title><path stroke-width="3" stroke-linejoin="round" d="M 497.25,372.75 L 994.50,621.25 " fill="none" /><circle r="4" cx="497.25" cy="372.75" class="hide"><title>Data series 3: x = 1, y = 15</title></circle><text x="497.25" y="360.75" class="hide">15</text><circle r="4" cx="994.50" cy="621.25" class="hide"><title>Data series 3: x = 2, y = 5</title></circle><text x="994.50" y="609.25" class="hide">5</text><g class="legend" id="legend3"><line stroke-width="5" x1="1019.50" x2="1044.50" y1="75" y2="75" /><text x="1059.50" y="80">Data series 3</text></g></g></g></g></svg>'
    assert isinstance(svg, str)
    assert svg.strip().startswith("<svg")
    assert svg == expected


def test_chart_etree_output():
    root = bsc.chart(x = [0, 1, 2], y = [[10, 20, 30], [15, 8, 22], [None, 15, 5]], output = "etree")
    assert isinstance(root, ET.Element)
    assert root.tag == "svg"
    assert root.attrib["width"] == "1200"
    assert len(root) == 4


def test_chart_write_file(tmp_path):
    out_file = tmp_path / "my_chart.svg"
    root = bsc.chart(x = range(100), y = range(100), pretty = True, output = str(out_file))
    assert isinstance(root, ET.Element)
    assert out_file.is_file()
    assert os.path.getsize(out_file) > 10000
    content = out_file.read_text(encoding = "utf-8")
    assert len(content) > 10000
    num_lines = sum(1 for _ in open(out_file))
    assert num_lines > 200
    assert content.startswith("<?xml version='1.0' encoding='UTF-8'?>\n<svg")
    assert content.endswith("</svg>")


def test_line_chart():
    svg = bsc.chart(x = range(100), y = range(100), tooltip_type = None)
    svg2 = bsc.line_chart(x = range(100), y = range(100), tooltip_type = None)
    assert svg == svg2
    assert "<circle " not in svg
    regex = re.compile(r'.+<path stroke-width="3" stroke-linejoin="round" d="[0-9ML\,\. ]+" fill="none" />.+')
    assert bool(regex.match(svg))


def test_scatter_chart():
    svg = bsc.chart(chart_type = "scatter", x = range(100), y = range(100))
    svg2 = bsc.scatter_chart(x = range(100), y = range(100))
    assert "<path " not in svg
    assert svg == svg2


def test_scatter_line_chart():
    svg = bsc.chart(chart_type = "line+scatter", x = range(100), y = range(100), tooltip_type = None)
    svg2 = bsc.scatter_line_chart(x = range(100), y = range(100), tooltip_type = None)
    assert svg == svg2
    assert "<circle " in svg
    assert "<path " in svg


def test_title():
    svg = bsc.chart(x = range(100), y = range(100), title = "Identity function")
    assert isinstance(svg, str)
    assert svg.strip().startswith("<svg")
    assert "<title id=\"title\">Identity function</title>" in svg
    regex = re.compile(r".+<text class=\"title\"[^>]+>Identity function</text>.+")
    assert bool(regex.match(svg))


def test_default_colors():
    svg = bsc.chart(x = [0, 1, 2], y = [[10, 20, 30], [15, 8, 22], [None, 15, 5]])
     # Okabe-Ito
    assert ".color1 {fill: #E69F00; stroke: #E69F00;}" in svg
    assert "#56B4E9" in svg and ".color2" in svg
    assert "#009E73" in svg and ".color3" in svg
    assert "#F0E442" not in svg and ".color4" not in svg # only 3 series
    assert "#440154" not in svg # Viridis


def test_tooltip_title():
    svg = bsc.chart(
        x = range(3),
        y = (5, 10, 15),
        tooltip_type="vertical line",
        output="string",
    )
    assert ".hover_values" in svg
    assert 'id="bg_abs"' in svg


def test_extra_lines():
    svg = bsc.chart(
        x = range(3),
        y = (5, 10, 15),
        extra_lines = ({"x": 2}, {"y": 12, "color": "blue", "thickness": 5, "position": "front"})
    )
    regex = re.compile(r'.+<line [^>]+ stroke="black" stroke-width="2" stroke-linecap="square" />.+')
    assert bool(regex.match(svg))
    regex = re.compile(r'.+<line [^>]+ stroke="blue" stroke-width="5" stroke-linecap="square" />.+')
    assert bool(regex.match(svg))


def test_chart_invalid_y_ticks():
    with pytest.raises(TypeError):
        bsc.chart(range(100), y = range(100), y_ticks = "NaN")
