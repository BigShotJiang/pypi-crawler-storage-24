import os
from pathlib import Path
import importlib
import sys
import time

import pytest

this_dir = Path(__file__).resolve().parent
dir_real_examples = this_dir.parent / "examples"
sys.path.insert(1, str(dir_real_examples))
real_modules = [os.path.basename(m) for m in dir_real_examples.glob("*.py")]
real_modules = [e[:-3] for e in real_modules if e != "run_examples.py"]

dir_tests_examples = this_dir / "examples"
sys.path.insert(2, str(dir_tests_examples))
tests_modules = [os.path.basename(m)[:-3] for m in dir_tests_examples.glob("*.py")]

# https://github.com/orsinium-labs/svg.py/blob/master/tests/test_examples.py
@pytest.mark.parametrize("module", real_modules)
def test_real_examples(tmp_path, module: str):
    out_file = tmp_path / f"{module}.svg"

    mod_example = importlib.import_module(module)
    params = mod_example.get_params()
    
    start_time = time.time()
    mod_example.write_chart(**params, output = out_file)
    elapsed = 1000 * (time.time() - start_time)

    min_size = 5000

    assert out_file.is_file()
    assert os.path.getsize(out_file) > min_size

    content = out_file.read_text(encoding = "utf-8")
    assert len(content) > min_size
    num_lines = sum(1 for _ in open(out_file))
    assert num_lines >= 2
    assert content.startswith("<?xml version='1.0' encoding='UTF-8'?>\n<svg")
    assert content.endswith("</svg>")

    expected = dir_real_examples / f"{module}.svg"
    expected = expected.read_text(encoding = "utf-8")
    assert len(expected) > min_size

    assert content == expected
    assert elapsed < 500


@pytest.mark.parametrize("module", tests_modules)
def test_simple_examples(tmp_path, module: str):
    out_file = tmp_path / f"{module}.svg"

    mod_example = importlib.import_module(module)
    
    start_time = time.time()
    mod_example.write_chart(output = out_file)
    elapsed = 1000 * (time.time() - start_time)

    min_size = 1000

    assert out_file.is_file()
    assert os.path.getsize(out_file) > min_size

    content = out_file.read_text(encoding = "utf-8")
    assert len(content) > min_size
    num_lines = sum(1 for _ in open(out_file))
    assert num_lines >= 2
    assert content.startswith("<?xml version='1.0' encoding='UTF-8'?>\n<svg")
    assert content.endswith("</svg>")

    expected = dir_tests_examples / "charts" / f"{module}.svg"
    expected = expected.read_text(encoding = "utf-8")
    assert len(expected) > min_size

    assert content == expected
    assert elapsed < 500
