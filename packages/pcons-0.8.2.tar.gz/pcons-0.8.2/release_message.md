    Gary Oberbrunner (2):
          Add public try_compile() method to ToolChecks
          Bump version to v0.8.2

