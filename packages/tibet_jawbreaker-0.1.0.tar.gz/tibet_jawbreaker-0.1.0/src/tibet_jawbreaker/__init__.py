"""
tibet-jawbreaker — Provenance-first crypto transactions.

Every transfer has intent. Every wallet has identity.
Blind mining is suspicious. Wash trading is detected.

    from tibet_jawbreaker import Ledger

    ledger = Ledger()
    jasper = ledger.register_wallet("jis:jasper", verified=True)
    tx = ledger.transfer(
        from_jis="jis:jasper",
        to_jis="jis:humotica",
        amount=5.0,
        currency="ETH",
        intent="Payment for Q1 development",
    )
    print(tx.legitimacy)  # LegitimacyLevel.LEGITIMATE
"""

__version__ = "0.1.0"

from .wallet import WalletAddress, JawbreakerWallet, WalletRegistry
from .transaction import (
    TransactionType,
    LegitimacyLevel,
    JawbreakerTransaction,
    TransactionEngine,
)
from .ledger import Ledger, NotaryAttestation

__all__ = [
    "Ledger",
    "NotaryAttestation",
    "WalletAddress",
    "JawbreakerWallet",
    "WalletRegistry",
    "TransactionType",
    "LegitimacyLevel",
    "JawbreakerTransaction",
    "TransactionEngine",
]
