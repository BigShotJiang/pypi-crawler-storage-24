"""
Wallet Identity — JIS-mapped crypto wallets.

Every wallet address gets a JIS DID. Not anonymous addresses
passing tokens around — identified entities with trust history.

    jis:jasper      → 0x1a2b3c...  (Ethereum)
    jis:humotica    → So1abc...    (Solana)
    jis:bank-nl     → bc1qxy...   (Bitcoin)

Blind wallets (no JIS mapping) can still transact,
but their legitimacy score drops. Provenance > anonymity.
"""

import hashlib
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional


@dataclass
class WalletAddress:
    """A crypto wallet address on a specific chain."""
    address: str
    chain: str  # ethereum, solana, bitcoin, polygon, etc.
    label: str = ""  # Human-readable label

    def to_dict(self) -> dict:
        return {"address": self.address, "chain": self.chain, "label": self.label}


@dataclass
class JawbreakerWallet:
    """
    A TIBET-provenance wallet — identity-first, not address-first.

    Traditional crypto: wallet = address. Anonymous by default.
    Jawbreaker: wallet = JIS identity with address(es) attached.
    You CAN be anonymous, but your legitimacy score reflects it.
    """
    jis_did: str  # e.g. "jis:jasper"
    display_name: str = ""
    addresses: list[WalletAddress] = field(default_factory=list)
    created_at: str = ""
    trust_score: float = 1.0  # FIR/A-style trust
    total_transactions: int = 0
    legitimate_transactions: int = 0
    suspicious_transactions: int = 0
    verified: bool = False  # KYC or notary-verified
    metadata: dict = field(default_factory=dict)

    def __post_init__(self):
        if not self.created_at:
            self.created_at = datetime.now(timezone.utc).isoformat()

    @property
    def legitimacy_ratio(self) -> float:
        """Ratio of legitimate vs total transactions."""
        if self.total_transactions == 0:
            return 1.0  # No history = benefit of the doubt
        return self.legitimate_transactions / self.total_transactions

    def add_address(self, address: str, chain: str, label: str = "") -> WalletAddress:
        """Register a wallet address on a chain."""
        wa = WalletAddress(address=address, chain=chain, label=label)
        self.addresses.append(wa)
        return wa

    def get_address(self, chain: str) -> Optional[WalletAddress]:
        """Get wallet address for a specific chain."""
        for addr in self.addresses:
            if addr.chain == chain:
                return addr
        return None

    def record_transaction(self, legitimate: bool) -> None:
        """Record a transaction result."""
        self.total_transactions += 1
        if legitimate:
            self.legitimate_transactions += 1
        else:
            self.suspicious_transactions += 1
        self._recalculate_trust()

    def _recalculate_trust(self) -> None:
        """Recalculate trust score based on transaction history."""
        if self.total_transactions == 0:
            self.trust_score = 1.0
            return

        # Base: legitimacy ratio (60%)
        legitimacy = self.legitimacy_ratio

        # Verification bonus (20%)
        verification = 1.0 if self.verified else 0.5

        # History depth bonus (20%) — more transactions = more reliable score
        depth = min(1.0, self.total_transactions / 50)

        self.trust_score = round(
            legitimacy * 0.60
            + verification * 0.20
            + depth * 0.20,
            4,
        )

    def to_dict(self) -> dict:
        return {
            "jis_did": self.jis_did,
            "display_name": self.display_name,
            "addresses": [a.to_dict() for a in self.addresses],
            "trust_score": self.trust_score,
            "total_transactions": self.total_transactions,
            "legitimate_transactions": self.legitimate_transactions,
            "suspicious_transactions": self.suspicious_transactions,
            "legitimacy_ratio": round(self.legitimacy_ratio, 4),
            "verified": self.verified,
            "created_at": self.created_at,
        }


class WalletRegistry:
    """
    Registry of JIS-mapped wallets.

    Maps JIS DIDs to wallet addresses across chains.
    Tracks trust per wallet. Unknown wallets get a default low score.
    """

    def __init__(self):
        self._wallets: dict[str, JawbreakerWallet] = {}
        self._address_index: dict[str, str] = {}  # address → jis_did

    def register(
        self,
        jis_did: str,
        display_name: str = "",
        verified: bool = False,
    ) -> JawbreakerWallet:
        """Register a new wallet identity."""
        if jis_did in self._wallets:
            return self._wallets[jis_did]

        wallet = JawbreakerWallet(
            jis_did=jis_did,
            display_name=display_name or jis_did,
            verified=verified,
        )
        self._wallets[jis_did] = wallet
        return wallet

    def add_address(self, jis_did: str, address: str, chain: str, label: str = "") -> None:
        """Map a wallet address to a JIS identity."""
        wallet = self._wallets.get(jis_did)
        if not wallet:
            wallet = self.register(jis_did)
        wallet.add_address(address, chain, label)
        self._address_index[address] = jis_did

    def lookup_by_address(self, address: str) -> Optional[JawbreakerWallet]:
        """Find wallet by chain address."""
        jis_did = self._address_index.get(address)
        if jis_did:
            return self._wallets.get(jis_did)
        return None

    def lookup(self, jis_did: str) -> Optional[JawbreakerWallet]:
        """Find wallet by JIS DID."""
        return self._wallets.get(jis_did)

    def get_or_create_anonymous(self, address: str, chain: str) -> JawbreakerWallet:
        """
        Get wallet for address, or create anonymous entry.

        Anonymous wallets start with lower trust — no identity = less trust.
        """
        existing = self.lookup_by_address(address)
        if existing:
            return existing

        # Generate anonymous JIS DID from address
        anon_id = f"jis:anon:{hashlib.sha256(address.encode()).hexdigest()[:8]}"
        wallet = self.register(anon_id, display_name=f"Unknown ({address[:8]}...)")
        wallet.trust_score = 0.3  # Anonymous = low initial trust
        wallet.add_address(address, chain, label="anonymous")
        return wallet

    def leaderboard(self) -> list[dict]:
        """Trust leaderboard — highest trust first."""
        wallets = sorted(
            self._wallets.values(),
            key=lambda w: w.trust_score,
            reverse=True,
        )
        return [w.to_dict() for w in wallets]

    def stats(self) -> dict:
        total = len(self._wallets)
        verified = sum(1 for w in self._wallets.values() if w.verified)
        anonymous = sum(1 for w in self._wallets.values() if w.jis_did.startswith("jis:anon:"))
        return {
            "total_wallets": total,
            "verified": verified,
            "anonymous": anonymous,
            "identified": total - anonymous,
        }
