"""
Transaction Engine — every transfer is a TIBET token.

Dual registration: TIBET provenance + on-chain representation.
The TIBET token carries what blockchain can't: intent.

    WHY did you send 5 ETH to 0xabc?
    - "Payment for web development" (ERACHTER = intent)
    - "Salary March 2026" (ERACHTER = intent)
    - "" (no intent = suspicious)

Blind mining, wash trading, tumbling — all produce transactions
WITHOUT meaningful ERACHTER. That's the signal.
"""

import hashlib
import json
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Optional


class TransactionType(Enum):
    """Types of crypto transactions."""
    TRANSFER = "transfer"       # Simple send
    SWAP = "swap"               # Token exchange
    STAKE = "stake"             # Staking
    UNSTAKE = "unstake"         # Unstaking
    MINT = "mint"               # Token minting
    BURN = "burn"               # Token burning
    CONTRACT = "contract"       # Smart contract interaction
    BRIDGE = "bridge"           # Cross-chain bridge
    REWARD = "reward"           # Mining/staking reward
    FEE = "fee"                 # Gas/transaction fee
    PURCHASE = "purchase"       # Buying goods/services
    INCOME = "income"           # Salary, freelance, etc.


class LegitimacyLevel(Enum):
    """Transaction legitimacy classification."""
    VERIFIED = "verified"       # Notary-verified, both parties identified
    LEGITIMATE = "legitimate"   # Has intent, identified parties
    PLAUSIBLE = "plausible"     # Has intent but weak identity
    UNKNOWN = "unknown"         # No intent, no context
    SUSPICIOUS = "suspicious"   # Pattern matches fraud/laundering
    FLAGGED = "flagged"         # Multiple red flags


@dataclass
class JawbreakerTransaction:
    """
    A crypto transaction with TIBET provenance.

    Every transaction is a TIBET token:
    - ERIN: What happened (amount, from, to, type)
    - ERAAN: Previous transaction in chain (linked)
    - EROMHEEN: Context (chain, gas, block, exchange rate)
    - ERACHTER: Intent — WHY this transaction exists

    The ERACHTER is what makes Jawbreaker different.
    No intent? Your legitimacy score drops.
    """
    tx_id: str
    tx_type: TransactionType
    from_jis: str               # Sender JIS DID
    to_jis: str                 # Receiver JIS DID
    amount: float
    currency: str               # ETH, SOL, BTC, USDC, etc.
    chain: str                  # ethereum, solana, bitcoin, etc.
    timestamp: str = ""

    # ERACHTER — the intent (this is the key differentiator)
    intent: str = ""            # "Payment for service X", "Salary", etc.
    intent_category: str = ""   # payment, salary, investment, donation, etc.
    reference: str = ""         # Invoice number, contract ID, etc.

    # On-chain reference (dual registration)
    chain_tx_hash: str = ""     # On-chain transaction hash
    block_number: int = 0
    gas_used: float = 0.0
    gas_price: float = 0.0

    # Exchange context
    exchange_rate_usd: float = 0.0
    amount_usd: float = 0.0

    # TIBET provenance
    content_hash: str = ""
    parent_tx: Optional[str] = None  # Previous tx in chain
    erin: dict = field(default_factory=dict)
    eraan: dict = field(default_factory=dict)
    eromheen: dict = field(default_factory=dict)
    erachter: dict = field(default_factory=dict)

    # Legitimacy
    legitimacy: LegitimacyLevel = LegitimacyLevel.UNKNOWN
    legitimacy_score: float = 0.5
    flags: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "tx_id": self.tx_id,
            "type": self.tx_type.value,
            "from": self.from_jis,
            "to": self.to_jis,
            "amount": self.amount,
            "currency": self.currency,
            "chain": self.chain,
            "timestamp": self.timestamp,
            "intent": self.intent,
            "intent_category": self.intent_category,
            "reference": self.reference,
            "chain_tx_hash": self.chain_tx_hash,
            "amount_usd": round(self.amount_usd, 2),
            "content_hash": self.content_hash,
            "parent_tx": self.parent_tx,
            "legitimacy": self.legitimacy.value,
            "legitimacy_score": round(self.legitimacy_score, 4),
            "flags": self.flags,
            "erin": self.erin,
            "eraan": self.eraan,
            "eromheen": self.eromheen,
            "erachter": self.erachter,
        }


class TransactionEngine:
    """
    Creates TIBET-provenance transactions.

    Every transaction gets:
    1. A TIBET token with full provenance
    2. A legitimacy score based on available context
    3. Flags for suspicious patterns
    """

    def __init__(self):
        self._transactions: list[JawbreakerTransaction] = []
        self._seq = 0

    def create(
        self,
        tx_type: TransactionType,
        from_jis: str,
        to_jis: str,
        amount: float,
        currency: str,
        chain: str = "ethereum",
        intent: str = "",
        intent_category: str = "",
        reference: str = "",
        chain_tx_hash: str = "",
        block_number: int = 0,
        gas_used: float = 0.0,
        gas_price: float = 0.0,
        exchange_rate_usd: float = 0.0,
        metadata: dict | None = None,
    ) -> JawbreakerTransaction:
        """Create a new TIBET-provenance transaction."""
        now = datetime.now(timezone.utc).isoformat()
        self._seq += 1

        # Generate tx ID
        raw = f"{from_jis}:{to_jis}:{amount}:{now}:{os.urandom(4).hex()}"
        tx_id = hashlib.sha256(raw.encode()).hexdigest()[:16]

        # Content hash
        content = json.dumps({
            "type": tx_type.value,
            "from": from_jis,
            "to": to_jis,
            "amount": amount,
            "currency": currency,
            "chain": chain,
        }, sort_keys=True)
        content_hash = hashlib.sha256(content.encode()).hexdigest()[:24]

        # Parent reference
        parent_tx = self._transactions[-1].tx_id if self._transactions else None

        # Calculate USD value
        amount_usd = amount * exchange_rate_usd if exchange_rate_usd > 0 else 0.0

        # TIBET provenance layers
        erin = {
            "action": tx_type.value,
            "from": from_jis,
            "to": to_jis,
            "amount": amount,
            "currency": currency,
            "content_hash": content_hash,
        }

        eraan = {
            "parent_tx": parent_tx,
            "sequence": self._seq,
            "chain_tx_hash": chain_tx_hash or None,
        }

        eromheen = {
            "chain": chain,
            "block": block_number,
            "gas_used": gas_used,
            "gas_price": gas_price,
            "exchange_rate_usd": exchange_rate_usd,
            "timestamp": now,
        }

        erachter = {
            "intent": intent or "(no intent provided)",
            "category": intent_category or "unspecified",
            "reference": reference or None,
            "protocol": "tibet-jawbreaker/0.1",
        }

        # Score legitimacy
        legitimacy_score, legitimacy_level, flags = self._score_legitimacy(
            tx_type=tx_type,
            from_jis=from_jis,
            to_jis=to_jis,
            amount=amount,
            intent=intent,
            intent_category=intent_category,
            reference=reference,
            exchange_rate_usd=exchange_rate_usd,
        )

        tx = JawbreakerTransaction(
            tx_id=tx_id,
            tx_type=tx_type,
            from_jis=from_jis,
            to_jis=to_jis,
            amount=amount,
            currency=currency,
            chain=chain,
            timestamp=now,
            intent=intent,
            intent_category=intent_category,
            reference=reference,
            chain_tx_hash=chain_tx_hash,
            block_number=block_number,
            gas_used=gas_used,
            gas_price=gas_price,
            exchange_rate_usd=exchange_rate_usd,
            amount_usd=amount_usd,
            content_hash=content_hash,
            parent_tx=parent_tx,
            erin=erin,
            eraan=eraan,
            eromheen=eromheen,
            erachter=erachter,
            legitimacy=legitimacy_level,
            legitimacy_score=legitimacy_score,
            flags=flags,
        )

        self._transactions.append(tx)
        return tx

    def _score_legitimacy(
        self,
        tx_type: TransactionType,
        from_jis: str,
        to_jis: str,
        amount: float,
        intent: str,
        intent_category: str,
        reference: str,
        exchange_rate_usd: float,
    ) -> tuple[float, LegitimacyLevel, list[str]]:
        """
        Score transaction legitimacy.

        Higher score = more legitimate. Based on:
        - Has intent? (+0.3)
        - Has category? (+0.1)
        - Has reference? (+0.1)
        - Both parties identified (not anonymous)? (+0.2)
        - Has exchange rate context? (+0.1)
        - Reasonable amount? (+0.1)
        - Known patterns? (wash trading, round-tripping, etc.)
        """
        score = 0.1  # Base score — you exist
        flags = []

        # Intent (the big one — 30%)
        if intent and intent != "(no intent provided)":
            score += 0.30
        else:
            flags.append("no_intent")

        # Category
        if intent_category and intent_category != "unspecified":
            score += 0.10
        else:
            flags.append("no_category")

        # Reference (invoice, contract, etc.)
        if reference:
            score += 0.10

        # Identity (not anonymous)
        from_identified = not from_jis.startswith("jis:anon:")
        to_identified = not to_jis.startswith("jis:anon:")
        if from_identified and to_identified:
            score += 0.20
        elif from_identified or to_identified:
            score += 0.10
            flags.append("partial_identity")
        else:
            flags.append("both_anonymous")

        # Exchange rate context
        if exchange_rate_usd > 0:
            score += 0.10

        # Self-transfer detection (potential wash trading)
        if from_jis == to_jis:
            score -= 0.20
            flags.append("self_transfer")

        # Suspicious patterns from recent history
        recent = self._transactions[-20:] if self._transactions else []

        # Round-trip detection: A→B then B→A same amount
        for prev in recent:
            if (prev.from_jis == to_jis and prev.to_jis == from_jis
                    and abs(prev.amount - amount) < 0.001
                    and prev.currency == "ETH"):  # Same currency check simplified
                score -= 0.30
                flags.append("round_trip")
                break

        # Rapid-fire: too many transactions in short time
        if len(recent) >= 10:
            rapid_count = sum(
                1 for t in recent[-10:]
                if t.from_jis == from_jis
            )
            if rapid_count >= 8:
                score -= 0.15
                flags.append("rapid_fire")

        # Clamp
        score = max(0.0, min(1.0, score))

        # Determine level
        if score >= 0.8:
            level = LegitimacyLevel.VERIFIED
        elif score >= 0.6:
            level = LegitimacyLevel.LEGITIMATE
        elif score >= 0.4:
            level = LegitimacyLevel.PLAUSIBLE
        elif score >= 0.2:
            level = LegitimacyLevel.UNKNOWN
        elif score >= 0.1:
            level = LegitimacyLevel.SUSPICIOUS
        else:
            level = LegitimacyLevel.FLAGGED

        return round(score, 4), level, flags

    def chain(self) -> list[JawbreakerTransaction]:
        """Get full transaction chain."""
        return list(self._transactions)

    def verify_chain(self) -> dict:
        """Verify transaction chain integrity."""
        issues = []
        for i, tx in enumerate(self._transactions):
            if i > 0:
                prev = self._transactions[i - 1]
                if tx.parent_tx != prev.tx_id:
                    issues.append({
                        "tx_id": tx.tx_id,
                        "issue": "chain_broken",
                        "expected_parent": prev.tx_id,
                        "got": tx.parent_tx,
                    })
        return {
            "valid": len(issues) == 0,
            "transactions_checked": len(self._transactions),
            "issues": issues,
        }

    def stats(self) -> dict:
        total = len(self._transactions)
        by_level = {}
        for tx in self._transactions:
            level = tx.legitimacy.value
            by_level[level] = by_level.get(level, 0) + 1

        return {
            "total_transactions": total,
            "by_legitimacy": by_level,
            "chain_valid": self.verify_chain()["valid"],
        }
