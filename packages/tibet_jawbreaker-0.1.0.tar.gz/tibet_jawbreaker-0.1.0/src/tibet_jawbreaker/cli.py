"""
tibet-jawbreaker CLI — demo provenance-first crypto.

Usage::

    tibet-jawbreaker demo       # Full scenario: legit, suspicious, wash trading, notary
    tibet-jawbreaker stats       # Show current ledger stats
    tibet-jawbreaker version     # Show version
"""

import sys
import json
from .ledger import Ledger
from .transaction import LegitimacyLevel


def _header(text: str) -> None:
    print(f"\n{'=' * 60}")
    print(f"  {text}")
    print(f"{'=' * 60}")


def _tx_line(tx, label: str = "") -> None:
    level = tx.legitimacy.value.upper()
    score = f"{tx.legitimacy_score:.2f}"
    flags = ", ".join(tx.flags) if tx.flags else "none"
    prefix = f"  [{label}] " if label else "  "
    print(f"{prefix}{tx.from_jis} -> {tx.to_jis}: {tx.amount} {tx.currency}")
    print(f"    Legitimacy: {level} (score: {score})  Flags: {flags}")
    if tx.intent:
        print(f"    Intent: {tx.intent}")


def cmd_demo() -> None:
    """Run the full Jawbreaker demo."""
    ledger = Ledger()
    suspicious_log = []

    def on_suspicious(tx):
        suspicious_log.append(tx)

    ledger.on_suspicious(on_suspicious)

    # ── Phase 1: Register wallets ──────────────────────────
    _header("PHASE 1: Wallet Registration")

    ledger.register_wallet("jis:jasper", display_name="Jasper", verified=True)
    ledger.add_address("jis:jasper", "0x1a2b3c4d5e6f7890abcdef1234567890abcdef12", "ethereum")
    print("  Registered: jis:jasper (verified, Ethereum)")

    ledger.register_wallet("jis:humotica", display_name="Humotica BV", verified=True)
    ledger.add_address("jis:humotica", "0xfedcba0987654321fedcba0987654321fedcba09", "ethereum")
    print("  Registered: jis:humotica (verified, Ethereum)")

    ledger.register_wallet("jis:alice", display_name="Alice")
    ledger.add_address("jis:alice", "0xaaaa1111bbbb2222cccc3333dddd4444eeee5555", "ethereum")
    print("  Registered: jis:alice (unverified, Ethereum)")

    ledger.register_wallet("jis:bob", display_name="Bob")
    ledger.add_address("jis:bob", "0xbbbb2222cccc3333dddd4444eeee5555ffff6666", "ethereum")
    print("  Registered: jis:bob (unverified, Ethereum)")

    # ── Phase 2: Legitimate transfers ──────────────────────
    _header("PHASE 2: Legitimate Transfers (with intent)")

    tx1 = ledger.transfer(
        from_jis="jis:jasper",
        to_jis="jis:humotica",
        amount=5.0,
        currency="ETH",
        intent="Payment for Q1 development work",
        intent_category="payment",
        reference="INV-2026-042",
        exchange_rate_usd=3200.0,
    )
    _tx_line(tx1, "LEGIT")

    tx2 = ledger.transfer(
        from_jis="jis:humotica",
        to_jis="jis:alice",
        amount=1500.0,
        currency="USDC",
        intent="Freelance design payment March 2026",
        intent_category="salary",
        reference="PAY-2026-03-ALICE",
        exchange_rate_usd=1.0,
    )
    _tx_line(tx2, "LEGIT")

    # ── Phase 3: Suspicious transfers ──────────────────────
    _header("PHASE 3: Suspicious Transfers (no intent)")

    tx3 = ledger.transfer(
        from_jis="jis:anon:x8f3a2b1",
        to_jis="jis:anon:9c7d4e5f",
        amount=50.0,
        currency="ETH",
    )
    _tx_line(tx3, "NO INTENT")

    tx4 = ledger.transfer(
        from_jis="jis:alice",
        to_jis="jis:anon:deadbeef",
        amount=10000.0,
        currency="USDC",
    )
    _tx_line(tx4, "NO INTENT")

    # ── Phase 4: Wash trading detection ────────────────────
    _header("PHASE 4: Wash Trading Detection")

    print("  Sending 2.5 ETH from Alice -> Bob...")
    tx5 = ledger.transfer(
        from_jis="jis:alice",
        to_jis="jis:bob",
        amount=2.5,
        currency="ETH",
        intent="Gift",
        intent_category="personal",
    )
    _tx_line(tx5, "A->B")

    print("\n  Sending 2.5 ETH back from Bob -> Alice (round-trip!)...")
    tx6 = ledger.transfer(
        from_jis="jis:bob",
        to_jis="jis:alice",
        amount=2.5,
        currency="ETH",
        intent="Return gift",
        intent_category="personal",
    )
    _tx_line(tx6, "B->A ROUND-TRIP")

    # ── Phase 5: Self-transfer ─────────────────────────────
    _header("PHASE 5: Self-Transfer Detection")

    tx7 = ledger.transfer(
        from_jis="jis:bob",
        to_jis="jis:bob",
        amount=100.0,
        currency="ETH",
    )
    _tx_line(tx7, "SELF-TRANSFER")

    # ── Phase 6: Blind mining ──────────────────────────────
    _header("PHASE 6: Blind Mining Detection")

    print("  Mining reward WITH context:")
    tx8 = ledger.mining_reward(
        to_jis="jis:jasper",
        amount=0.05,
        currency="ETH",
        block_number=19847523,
        intent="Ethpool staking reward, validator jis:jasper, epoch 298471",
    )
    _tx_line(tx8, "TRANSPARENT")

    print("\n  Mining reward WITHOUT context (blind mining):")
    tx9 = ledger.mining_reward(
        to_jis="jis:anon:miner001",
        amount=6.25,
        currency="BTC",
    )
    _tx_line(tx9, "BLIND MINING")

    # ── Phase 7: Token swap ────────────────────────────────
    _header("PHASE 7: Token Swap")

    tx10 = ledger.swap(
        jis_did="jis:alice",
        from_amount=2.0,
        from_currency="ETH",
        to_amount=6400.0,
        to_currency="USDC",
        exchange="uniswap",
        intent="Converting ETH to stablecoin for expenses",
    )
    _tx_line(tx10, "SWAP")

    # ── Phase 8: Notary attestation ────────────────────────
    _header("PHASE 8: Notary Attestation")

    att1 = ledger.notarize(
        tx_id=tx1.tx_id,
        notary_jis="jis:notary:humotica-legal",
        verdict="valid",
        confidence=0.95,
        reason="Invoice INV-2026-042 verified against contract HUM-DEV-2026",
    )
    print(f"  Notarized tx {tx1.tx_id[:8]}... by {att1.notary_jis}")
    print(f"    Verdict: {att1.verdict} (confidence: {att1.confidence})")
    print(f"    Reason: {att1.reason}")

    att2 = ledger.notarize(
        tx_id=tx3.tx_id,
        notary_jis="jis:notary:compliance-bot",
        verdict="suspicious",
        confidence=0.85,
        reason="Both parties anonymous, no intent, large amount",
    )
    print(f"\n  Notarized tx {tx3.tx_id[:8]}... by {att2.notary_jis}")
    print(f"    Verdict: {att2.verdict} (confidence: {att2.confidence})")
    print(f"    Reason: {att2.reason}")

    # ── Phase 9: Results ───────────────────────────────────
    _header("RESULTS: Wallet Trust Leaderboard")

    for i, w in enumerate(ledger.leaderboard(), 1):
        verified = " [VERIFIED]" if w["verified"] else ""
        ratio = f"{w['legitimacy_ratio']:.0%}"
        print(f"  {i}. {w['jis_did']:<25} trust: {w['trust_score']:.4f}  "
              f"legit: {ratio}  txs: {w['total_transactions']}{verified}")

    # ── Suspicious alerts ──────────────────────────────────
    _header("SUSPICIOUS TRANSACTION ALERTS")

    if suspicious_log:
        for tx in suspicious_log:
            level = tx.legitimacy.value.upper()
            flags = ", ".join(tx.flags)
            print(f"  ALERT: {tx.tx_id[:8]}... {tx.from_jis} -> {tx.to_jis} "
                  f"{tx.amount} {tx.currency}")
            print(f"         Level: {level}  Flags: {flags}")
    else:
        print("  No suspicious transactions detected.")

    # ── Stats ──────────────────────────────────────────────
    _header("LEDGER STATS")

    stats = ledger.stats()
    print(f"  Total wallets:        {stats['total_wallets']}")
    print(f"    Verified:           {stats['verified']}")
    print(f"    Anonymous:          {stats['anonymous']}")
    print(f"    Identified:         {stats['identified']}")
    print(f"  Total transactions:   {stats['total_transactions']}")
    print(f"  Notary attestations:  {stats['notary_attestations']}")
    print(f"  Audit tokens:         {stats['audit_tokens']}")
    if stats.get("by_legitimacy"):
        print(f"  By legitimacy:")
        for level, count in sorted(stats["by_legitimacy"].items()):
            print(f"    {level:<12} {count}")

    # ── Audit trail ────────────────────────────────────────
    _header("TIBET AUDIT TRAIL (last 3)")

    trail = ledger.audit_trail()
    for token in trail[-3:]:
        print(f"  [{token['token_id'][:8]}...] {token['action']}: "
              f"{token['erachter']['intent'][:60]}")

    print(f"\n  Total audit tokens: {len(trail)}")
    print()


def cmd_stats() -> None:
    """Show empty ledger stats."""
    ledger = Ledger()
    print(json.dumps(ledger.stats(), indent=2))


def cmd_version() -> None:
    """Show version."""
    from . import __version__
    print(f"tibet-jawbreaker {__version__}")


def main() -> None:
    """CLI entry point."""
    args = sys.argv[1:]

    if not args or args[0] in ("-h", "--help", "help"):
        print("tibet-jawbreaker — Provenance-first crypto transactions")
        print()
        print("Usage:")
        print("  tibet-jawbreaker demo       Full scenario demo")
        print("  tibet-jawbreaker stats      Show ledger stats")
        print("  tibet-jawbreaker version    Show version")
        return

    cmd = args[0]

    if cmd == "demo":
        cmd_demo()
    elif cmd == "stats":
        cmd_stats()
    elif cmd == "version":
        cmd_version()
    else:
        print(f"Unknown command: {cmd}")
        print("Run 'tibet-jawbreaker help' for usage.")
        sys.exit(1)


if __name__ == "__main__":
    main()
