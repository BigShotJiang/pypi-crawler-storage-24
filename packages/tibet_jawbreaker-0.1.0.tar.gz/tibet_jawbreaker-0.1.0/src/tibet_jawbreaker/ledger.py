"""
Jawbreaker Ledger — local provenance ledger with notary support.

The ledger combines:
- WalletRegistry: JIS identity → wallet addresses
- TransactionEngine: TIBET-provenance transactions
- NotaryService: independent verification of transactions

Every transaction updates wallet trust scores.
Blind mining and wash trading are detected and flagged.

Usage::

    from tibet_jawbreaker import Ledger

    ledger = Ledger()
    jasper = ledger.register_wallet("jis:jasper", verified=True)
    ledger.add_address("jis:jasper", "0x1a2b3c...", "ethereum")

    tx = ledger.transfer(
        from_jis="jis:jasper",
        to_jis="jis:humotica",
        amount=5.0,
        currency="ETH",
        intent="Payment for Q1 development",
        reference="INV-2026-042",
    )
    print(tx.legitimacy)  # LegitimacyLevel.LEGITIMATE
"""

import hashlib
import json
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional, Callable

from .wallet import WalletRegistry, JawbreakerWallet
from .transaction import (
    TransactionEngine,
    TransactionType,
    JawbreakerTransaction,
    LegitimacyLevel,
)


@dataclass
class NotaryAttestation:
    """A notary's attestation of a transaction."""
    attestation_id: str
    tx_id: str
    notary_jis: str
    verdict: str  # "valid", "suspicious", "rejected"
    confidence: float
    reason: str
    timestamp: str
    signature_hash: str  # Simulated signature

    def to_dict(self) -> dict:
        return {
            "attestation_id": self.attestation_id,
            "tx_id": self.tx_id,
            "notary_jis": self.notary_jis,
            "verdict": self.verdict,
            "confidence": round(self.confidence, 4),
            "reason": self.reason,
            "timestamp": self.timestamp,
            "signature_hash": self.signature_hash,
        }


class Ledger:
    """
    The Jawbreaker Ledger — provenance-first crypto.

    Combines wallet identity, transaction provenance, and
    notary verification into one system.

    Every transaction:
    1. Gets a TIBET token (intent, identity, context)
    2. Gets a legitimacy score
    3. Updates wallet trust scores
    4. Can be notary-attested for extra trust
    """

    def __init__(self):
        self.wallets = WalletRegistry()
        self.engine = TransactionEngine()
        self._notary_attestations: list[NotaryAttestation] = []
        self._on_suspicious: list[Callable] = []
        self._tokens: list[dict] = []
        self._token_seq = 0

    def register_wallet(
        self,
        jis_did: str,
        display_name: str = "",
        verified: bool = False,
    ) -> JawbreakerWallet:
        """Register a wallet with JIS identity."""
        return self.wallets.register(jis_did, display_name, verified)

    def add_address(self, jis_did: str, address: str, chain: str, label: str = "") -> None:
        """Map a chain address to a JIS identity."""
        self.wallets.add_address(jis_did, address, chain, label)

    def transfer(
        self,
        from_jis: str,
        to_jis: str,
        amount: float,
        currency: str,
        chain: str = "ethereum",
        intent: str = "",
        intent_category: str = "",
        reference: str = "",
        exchange_rate_usd: float = 0.0,
    ) -> JawbreakerTransaction:
        """
        Create a transfer with full TIBET provenance.

        The intent parameter is what makes Jawbreaker different.
        No intent? Legitimacy drops. It's not forbidden — but it's noticed.
        """
        # Ensure wallets exist
        from_wallet = self.wallets.lookup(from_jis) or self.wallets.get_or_create_anonymous(from_jis, chain)
        to_wallet = self.wallets.lookup(to_jis) or self.wallets.get_or_create_anonymous(to_jis, chain)

        tx = self.engine.create(
            tx_type=TransactionType.TRANSFER,
            from_jis=from_jis,
            to_jis=to_jis,
            amount=amount,
            currency=currency,
            chain=chain,
            intent=intent,
            intent_category=intent_category,
            reference=reference,
            exchange_rate_usd=exchange_rate_usd,
        )

        # Update wallet trust
        is_legitimate = tx.legitimacy in (LegitimacyLevel.VERIFIED, LegitimacyLevel.LEGITIMATE)
        from_wallet.record_transaction(is_legitimate)
        to_wallet.record_transaction(is_legitimate)

        # Create audit token
        self._create_token(
            action="transfer",
            details={
                "tx_id": tx.tx_id,
                "from": from_jis,
                "to": to_jis,
                "amount": amount,
                "currency": currency,
                "legitimacy": tx.legitimacy.value,
                "score": tx.legitimacy_score,
            },
            intent=f"Transfer {amount} {currency}: {intent or '(no intent)'}",
        )

        # Notify on suspicious
        if tx.legitimacy in (LegitimacyLevel.SUSPICIOUS, LegitimacyLevel.FLAGGED):
            for cb in self._on_suspicious:
                cb(tx)

        return tx

    def swap(
        self,
        jis_did: str,
        from_amount: float,
        from_currency: str,
        to_amount: float,
        to_currency: str,
        chain: str = "ethereum",
        intent: str = "",
        exchange: str = "",
    ) -> JawbreakerTransaction:
        """Create a token swap with provenance."""
        tx = self.engine.create(
            tx_type=TransactionType.SWAP,
            from_jis=jis_did,
            to_jis=f"jis:exchange:{exchange or 'dex'}",
            amount=from_amount,
            currency=from_currency,
            chain=chain,
            intent=intent or f"Swap {from_amount} {from_currency} → {to_amount} {to_currency}",
            intent_category="swap",
            metadata={"to_amount": to_amount, "to_currency": to_currency},
        )

        wallet = self.wallets.lookup(jis_did)
        if wallet:
            is_legit = tx.legitimacy in (LegitimacyLevel.VERIFIED, LegitimacyLevel.LEGITIMATE)
            wallet.record_transaction(is_legit)

        return tx

    def stake(
        self,
        jis_did: str,
        amount: float,
        currency: str,
        chain: str = "ethereum",
        validator: str = "",
        intent: str = "",
    ) -> JawbreakerTransaction:
        """Create a staking transaction with provenance."""
        return self.engine.create(
            tx_type=TransactionType.STAKE,
            from_jis=jis_did,
            to_jis=f"jis:validator:{validator or 'pool'}",
            amount=amount,
            currency=currency,
            chain=chain,
            intent=intent or f"Stake {amount} {currency}",
            intent_category="staking",
        )

    def mining_reward(
        self,
        to_jis: str,
        amount: float,
        currency: str,
        chain: str = "ethereum",
        block_number: int = 0,
        intent: str = "",
    ) -> JawbreakerTransaction:
        """
        Record a mining/staking reward.

        Blind mining rewards (no intent, no context) are flagged.
        Legitimate mining should state what pool/validator and why.
        """
        tx = self.engine.create(
            tx_type=TransactionType.REWARD,
            from_jis="jis:network:mining-pool",
            to_jis=to_jis,
            amount=amount,
            currency=currency,
            chain=chain,
            intent=intent,
            intent_category="mining_reward" if intent else "",
            block_number=block_number,
        )

        wallet = self.wallets.lookup(to_jis)
        if wallet:
            is_legit = tx.legitimacy in (LegitimacyLevel.VERIFIED, LegitimacyLevel.LEGITIMATE)
            wallet.record_transaction(is_legit)

        return tx

    def notarize(
        self,
        tx_id: str,
        notary_jis: str,
        verdict: str = "valid",
        confidence: float = 0.9,
        reason: str = "",
    ) -> NotaryAttestation:
        """
        Notarize a transaction — independent third-party attestation.

        A notary co-signs the transaction, adding trust.
        Multiple notaries = higher trust. Like real-world notarization.
        """
        now = datetime.now(timezone.utc).isoformat()
        raw = f"{tx_id}:{notary_jis}:{now}:{os.urandom(4).hex()}"
        attestation_id = hashlib.sha256(raw.encode()).hexdigest()[:12]

        # Signature over the transaction
        sig_content = f"{tx_id}:{notary_jis}:{verdict}:{now}"
        signature_hash = hashlib.sha256(sig_content.encode()).hexdigest()[:32]

        attestation = NotaryAttestation(
            attestation_id=attestation_id,
            tx_id=tx_id,
            notary_jis=notary_jis,
            verdict=verdict,
            confidence=confidence,
            reason=reason or f"Notarized by {notary_jis}",
            timestamp=now,
            signature_hash=signature_hash,
        )

        self._notary_attestations.append(attestation)

        self._create_token(
            action="notarize",
            details={
                "attestation_id": attestation_id,
                "tx_id": tx_id,
                "notary": notary_jis,
                "verdict": verdict,
            },
            intent=f"Notary {notary_jis} attests transaction {tx_id}: {verdict}",
        )

        return attestation

    def on_suspicious(self, callback: Callable) -> None:
        """Register handler for suspicious transactions."""
        self._on_suspicious.append(callback)

    def leaderboard(self) -> list[dict]:
        """Wallet trust leaderboard."""
        return self.wallets.leaderboard()

    def audit_trail(self) -> list[dict]:
        """Full TIBET audit trail."""
        return list(self._tokens)

    def stats(self) -> dict:
        wallet_stats = self.wallets.stats()
        tx_stats = self.engine.stats()
        return {
            **wallet_stats,
            **tx_stats,
            "notary_attestations": len(self._notary_attestations),
            "audit_tokens": len(self._tokens),
        }

    def _create_token(self, action: str, details: dict, intent: str) -> dict:
        now = datetime.now(timezone.utc).isoformat()
        self._token_seq += 1

        raw = f"{action}:{now}:{self._token_seq}"
        token_id = hashlib.sha256(raw.encode()).hexdigest()[:16]

        token = {
            "token_id": token_id,
            "timestamp": now,
            "type": "jawbreaker",
            "action": action,
            "erin": {"action": action, "details": details},
            "eraan": {
                "parent_token": self._tokens[-1]["token_id"] if self._tokens else None,
                "sequence": self._token_seq,
            },
            "eromheen": {"timestamp": now, "node": os.uname().nodename},
            "erachter": {"intent": intent, "protocol": "tibet-jawbreaker/0.1"},
        }

        self._tokens.append(token)
        return token
