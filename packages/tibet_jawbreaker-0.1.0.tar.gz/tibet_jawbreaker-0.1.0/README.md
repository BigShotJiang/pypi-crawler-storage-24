# tibet-jawbreaker

**Provenance-first crypto transactions — every transfer has intent, every wallet has identity.**

Part of the [TIBET Protocol](https://pypi.org/project/tibet-core/) stack.

## The Problem

Blockchain transactions are anonymous by default. This enables:
- **Blind mining** — rewards without context or accountability
- **Wash trading** — A sends to B, B sends back to A
- **Intent-free transfers** — 50 ETH moved with zero explanation

The chain records *what happened*. Nobody records *why*.

## The Solution

Jawbreaker adds a TIBET provenance layer to every crypto transaction:

- **ERIN** (what): amount, from, to, type
- **ERAAN** (linked to): previous transaction in chain
- **EROMHEEN** (context): chain, gas, block, exchange rate
- **ERACHTER** (intent): *WHY* this transaction exists

No intent? Your legitimacy score drops. It's not forbidden — but it's noticed.

## Quick Start

```bash
pip install tibet-jawbreaker
tibet-jawbreaker demo
```

## Python API

```python
from tibet_jawbreaker import Ledger, LegitimacyLevel

ledger = Ledger()

# Register wallets with identity
jasper = ledger.register_wallet("jis:jasper", verified=True)
ledger.add_address("jis:jasper", "0x1a2b3c...", "ethereum")

# Transfer WITH intent = legitimate
tx = ledger.transfer(
    from_jis="jis:jasper",
    to_jis="jis:humotica",
    amount=5.0,
    currency="ETH",
    intent="Payment for Q1 development",
    reference="INV-2026-042",
)
print(tx.legitimacy)  # LegitimacyLevel.LEGITIMATE

# Transfer WITHOUT intent = suspicious
tx2 = ledger.transfer(
    from_jis="jis:anon:someone",
    to_jis="jis:anon:other",
    amount=50.0,
    currency="ETH",
)
print(tx2.legitimacy)  # LegitimacyLevel.SUSPICIOUS
print(tx2.flags)       # ['no_intent', 'no_category', 'both_anonymous']
```

## Features

### Legitimacy Scoring

Every transaction gets a score (0.0 - 1.0) based on:
- Has intent? (+0.3)
- Has category? (+0.1)
- Has reference? (+0.1)
- Both parties identified? (+0.2)
- Has exchange rate context? (+0.1)

### Suspicious Pattern Detection

- **Self-transfer**: A sends to A (wash trading signal)
- **Round-trip**: A sends to B, B sends same amount back
- **Rapid-fire**: Too many transactions from same wallet in short time
- **Blind mining**: Rewards without context or pool identification

### Notary Attestation

Third-party co-signing for extra trust:

```python
attestation = ledger.notarize(
    tx_id=tx.tx_id,
    notary_jis="jis:notary:legal-dept",
    verdict="valid",
    confidence=0.95,
    reason="Invoice verified against contract",
)
```

### Wallet Trust Scores

Trust evolves based on transaction history:
- Legitimacy ratio (60%)
- Verification status (20%)
- History depth (20%)

```python
leaderboard = ledger.leaderboard()
```

## Legitimacy Levels

| Level | Score | Meaning |
|-------|-------|---------|
| VERIFIED | 0.8+ | Notary-verified, both parties identified |
| LEGITIMATE | 0.6+ | Has intent, identified parties |
| PLAUSIBLE | 0.4+ | Has intent but weak identity |
| UNKNOWN | 0.2+ | No intent, no context |
| SUSPICIOUS | 0.1+ | Pattern matches fraud/laundering |
| FLAGGED | <0.1 | Multiple red flags |

## Transaction Types

TRANSFER, SWAP, STAKE, UNSTAKE, MINT, BURN, CONTRACT, BRIDGE, REWARD, FEE, PURCHASE, INCOME

## License

MIT — Humotica AI Lab 2025-2026
