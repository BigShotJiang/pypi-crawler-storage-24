"""Provider abstraction for image generation backends."""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any


def unique_output_path(output_dir: Path, stem: str) -> Path:
    """Return a unique ``output_dir / {stem}.png`` path.

    If ``{stem}.png`` already exists, appends ``_2``, ``_3``, … until a
    free name is found.
    """
    candidate = output_dir / f"{stem}.png"
    counter = 2
    while candidate.exists():
        candidate = output_dir / f"{stem}_{counter}.png"
        counter += 1
    return candidate

PROMPT_TEMPLATE = (
    "Change the outfit of the person in this photo. "
    "Keep their face, body, pose, and background exactly the same. "
    "Only change their clothing and accessories to match this description:\n\n"
    "{description}"
)


class Provider(ABC):
    """Base class for image generation providers."""

    name: str
    config_key: str

    @abstractmethod
    def get_client(self) -> Any:
        """Initialise and return the provider's API client."""

    @abstractmethod
    def generate_outfit_image(
        self,
        photo_path: Path,
        outfit_name: str,
        outfit_description: str,
        output_dir: Path,
    ) -> Path:
        """Generate an outfit image and return the path to the saved file."""

    def build_prompt(self, outfit_description: str) -> str:
        """Build the image-edit prompt from an outfit description."""
        return PROMPT_TEMPLATE.format(description=outfit_description)

    def describe_outfit(self, photo_path: Path) -> str:
        """Analyse a photo and return a text description of the outfit.

        Subclasses that support vision should override this method.
        """
        raise NotImplementedError(
            f"{self.name} does not support outfit description from photos."
        )
