"""OpenAI image-generation provider for Looking Glass."""

from __future__ import annotations

import base64
import json
import mimetypes
import time
from pathlib import Path
from typing import Any

from openai import OpenAI, RateLimitError

from looking_glass import config
from looking_glass.providers.base import Provider, unique_output_path

MAX_RETRIES = 5
INITIAL_BACKOFF = 2.0

_REF_DIR = Path(__file__).resolve().parent.parent / "reference"


class OpenAIProvider(Provider):
    """Image generation via OpenAI's Image Edit API."""

    name = "OpenAI"
    config_key = "openai_api_key"

    def __init__(self) -> None:
        self._client: OpenAI | None = None

    def get_client(self) -> OpenAI:
        if self._client is None:
            api_key = config.get(self.config_key)
            if not api_key:
                raise RuntimeError(
                    "OpenAI API key not configured. "
                    f"Run: glass config set {self.config_key} <your-key>"
                )
            self._client = OpenAI(api_key=api_key)
        return self._client

    def generate_outfit_image(
        self,
        photo_path: Path,
        outfit_name: str,
        outfit_description: str,
        output_dir: Path,
    ) -> Path:
        client = self.get_client()
        prompt = self.build_prompt(outfit_description)
        photo_name = photo_path.stem

        result = self._call_with_retry(client, photo_path, prompt)
        image_data = base64.b64decode(result.data[0].b64_json)

        output_dir.mkdir(parents=True, exist_ok=True)
        output_path = unique_output_path(output_dir, f"{photo_name}_{outfit_name}")
        output_path.write_bytes(image_data)
        return output_path

    @staticmethod
    def _call_with_retry(client: OpenAI, photo_path: Path, prompt: str) -> Any:
        """Call images.edit with exponential backoff on rate-limit errors."""
        backoff = INITIAL_BACKOFF
        for attempt in range(MAX_RETRIES):
            try:
                return client.images.edit(
                    model="gpt-image-1.5",
                    image=photo_path,
                    prompt=prompt,
                    input_fidelity="high",
                    quality="high",
                    size="auto",
                    extra_body={"moderation": "low"},
                )
            except RateLimitError:
                if attempt == MAX_RETRIES - 1:
                    raise
                time.sleep(backoff)
                backoff *= 2

    def describe_outfit(self, photo_path: Path) -> str:
        """Analyse a photo with GPT vision and return a structured outfit description."""
        client = self.get_client()

        prompt_data = json.loads((_REF_DIR / "photo-to-outfit-prompt.json").read_text())
        schema_data = json.loads((_REF_DIR / "outfit_schema_v3.json").read_text())

        system_content = (
            json.dumps(prompt_data, indent=2)
            + "\n\n--- Target JSON Schema ---\n\n"
            + json.dumps(schema_data, indent=2)
        )

        mime_type = mimetypes.guess_type(str(photo_path))[0] or "image/jpeg"
        image_b64 = base64.b64encode(photo_path.read_bytes()).decode()
        data_url = f"data:{mime_type};base64,{image_b64}"

        backoff = INITIAL_BACKOFF
        for attempt in range(MAX_RETRIES):
            try:
                response = client.chat.completions.create(
                    model="gpt-5.4",
                    reasoning_effort="xhigh",
                    messages=[
                        {"role": "system", "content": system_content},
                        {
                            "role": "user",
                            "content": [
                                {
                                    "type": "image_url",
                                    "image_url": {"url": data_url},
                                },
                            ],
                        },
                    ],
                    response_format={"type": "json_object"},
                )
                raw = response.choices[0].message.content.strip()
                # Re-serialise for consistent pretty formatting
                return json.dumps(json.loads(raw), indent=2)
            except RateLimitError:
                if attempt == MAX_RETRIES - 1:
                    raise
                time.sleep(backoff)
                backoff *= 2
