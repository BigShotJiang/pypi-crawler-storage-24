"""Holocron Toolset installation wrapper: game path, resources, 2DA/talktable, and UI helpers."""

from __future__ import annotations

import os

from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, cast

from qtpy.QtCore import (
    QPoint,
    Qt,
    Slot,  # pyright: ignore[reportPrivateImportUsage]
)
from qtpy.QtGui import QImage, QPixmap, QTransform
from qtpy.QtWidgets import (
    QAction,  # pyright: ignore[reportPrivateImportUsage]
    QComboBox,
    QDialog,
    QLineEdit,
    QMenu,
)

from loggerplus import RobustLogger  # pyright: ignore[reportMissingTypeStubs]
from pykotor.extract.chitin import Chitin
from pykotor.extract.file import FileResource, ResourceIdentifier
from pykotor.extract.installation import Installation, SearchLocation
from pykotor.extract.talktable import TalkTable
from pykotor.extract.twoda import TwoDARegistry
from pykotor.resource.formats.tpc.tpc_data import TPC
from pykotor.resource.formats.twoda import read_2da
from pykotor.resource.formats.twoda.twoda_data import TwoDA
from pykotor.resource.type import ResourceType
from pykotor.tools.misc import is_capsule_file, is_erf_file, is_mod_file, is_rim_file
from toolset.gui.common.localization import tr, trf
from toolset.utils.window import add_window

if TYPE_CHECKING:
    from qtpy.QtGui import QStandardItemModel
    from qtpy.QtWidgets import (
        QPlainTextEdit,
        QWidget,
    )
    from typing_extensions import (  # pyright: ignore[reportMissingModuleSource]
        Literal,
        Self,
    )

    from pykotor.extract.capsule import Capsule
    from pykotor.extract.file import LocationResult, ResourceResult
    from pykotor.resource.formats.tpc import TPC
    from pykotor.resource.formats.tpc.tpc_data import TPCMipmap
    from pykotor.resource.formats.twoda import TwoDA
    from pykotor.resource.generics.uti import UTI
    from pykotor.tools.reference_finder import (
        ReferenceSearchResult,
    )


class HTInstallation(Installation):
    """Extended Installation class for Holocron Toolset with 2DA caching and game-specific features.

    This class provides access to canonical 2DA file names that are verified to be loaded
    by the game engine. All 2DA constants below reference files confirmed through reverse
    engineering analysis of swkotor.exe and swkotor2.exe using Ghidra (RE server).

    See TwoDARegistry class docstring for detailed function references showing where each
    2DA file is loaded in the game executables.
    """

    # All 2DA file names below are verified to be loaded by the game engine.
    # See Libraries/PyKotor/src/pykotor/extract/twoda.py TwoDARegistry class for details.
    TwoDA_APPEARANCES: str = TwoDARegistry.APPEARANCES
    TwoDA_BASEITEMS: str = TwoDARegistry.BASEITEMS
    TwoDA_CAMERAS: str = TwoDARegistry.CAMERAS
    TwoDA_CLASSES: str = TwoDARegistry.CLASSES
    TwoDA_CLASSPOWERGAIN: str = TwoDARegistry.CLASSPOWERGAIN
    TwoDA_COMBATANIMATIONS: str = TwoDARegistry.COMBATANIMATIONS
    TwoDA_CREATURESPEED: str = TwoDARegistry.CREATURESPEED
    TwoDA_CURSORS: str = TwoDARegistry.CURSORS
    TwoDA_DIALOG_ANIMS: str = TwoDARegistry.DIALOG_ANIMS
    TwoDA_DOORS: str = TwoDARegistry.DOORS
    TwoDA_EMOTIONS: str = TwoDARegistry.EMOTIONS
    TwoDA_ENC_DIFFICULTIES: str = TwoDARegistry.ENC_DIFFICULTIES
    TwoDA_EXPRESSIONS: str = TwoDARegistry.EXPRESSIONS
    TwoDA_FACTIONS: str = TwoDARegistry.FACTIONS
    TwoDA_FEATS: str = TwoDARegistry.FEATS
    TwoDA_GENDERS: str = TwoDARegistry.GENDERS
    TwoDA_IPRP_ABILITIES: str = TwoDARegistry.IPRP_ABILITIES
    TwoDA_IPRP_ACMODTYPE: str = TwoDARegistry.IPRP_ACMODTYPE
    TwoDA_IPRP_ALIGNGRP: str = TwoDARegistry.IPRP_ALIGNGRP
    TwoDA_IPRP_AMMOTYPE: str = TwoDARegistry.IPRP_AMMOTYPE
    TwoDA_IPRP_COMBATDAM: str = TwoDARegistry.IPRP_COMBATDAM
    TwoDA_IPRP_COSTTABLE: str = TwoDARegistry.IPRP_COSTTABLE
    TwoDA_IPRP_DAMAGETYPE: str = TwoDARegistry.IPRP_DAMAGETYPE
    TwoDA_IPRP_IMMUNITY: str = TwoDARegistry.IPRP_IMMUNITY
    TwoDA_IPRP_MONSTERHIT: str = TwoDARegistry.IPRP_MONSTERHIT
    TwoDA_IPRP_ONHIT: str = TwoDARegistry.IPRP_ONHIT
    TwoDA_IPRP_PARAMTABLE: str = TwoDARegistry.IPRP_PARAMTABLE
    TwoDA_IPRP_PROTECTION: str = TwoDARegistry.IPRP_PROTECTION
    TwoDA_IPRP_SAVEELEMENT: str = TwoDARegistry.IPRP_SAVEELEMENT
    TwoDA_IPRP_SAVINGTHROW: str = TwoDARegistry.IPRP_SAVINGTHROW
    TwoDA_IPRP_WALK: str = TwoDARegistry.IPRP_WALK
    TwoDA_ITEM_PROPERTIES: str = TwoDARegistry.ITEM_PROPERTIES
    TwoDA_PERCEPTIONS: str = TwoDARegistry.PERCEPTIONS
    TwoDA_PLACEABLES: str = TwoDARegistry.PLACEABLES
    TwoDA_PLANETS: str = TwoDARegistry.PLANETS
    TwoDA_PLOT: str = TwoDARegistry.PLOT
    TwoDA_PORTRAITS: str = TwoDARegistry.PORTRAITS
    TwoDA_POWERS: str = TwoDARegistry.POWERS
    TwoDA_RACES: str = TwoDARegistry.RACES
    TwoDA_SKILLS: str = TwoDARegistry.SKILLS
    TwoDA_SOUNDSETS: str = TwoDARegistry.SOUNDSETS
    TwoDA_SPEEDS: str = TwoDARegistry.SPEEDS
    TwoDA_SUBRACES: str = TwoDARegistry.SUBRACES
    TwoDA_TRAPS: str = TwoDARegistry.TRAPS
    TwoDA_UPGRADES: str = TwoDARegistry.UPGRADES
    TwoDA_VIDEO_EFFECTS: str = TwoDARegistry.VIDEO_EFFECTS

    def __init__(
        self,
        path: str | os.PathLike,
        name: str,
        *,
        tsl: bool | None = None,
        progress_callback: Callable[
            [
                int | str,
                Literal[
                    "set_maximum",
                    "increment",
                    "update_maintask_text",
                    "update_subtask_text",
                ],
            ],
            Any,
        ]
        | None = None,
    ):
        super().__init__(path, progress_callback=progress_callback)

        self.name: str = name
        self.cache_core_items: QStandardItemModel | None = None

        self._tsl: bool | None = tsl
        self._cache2da: dict[str, TwoDA] = {}
        self._cache_tpc: dict[str, TPC] = {}

        # New cache dictionaries
        self._cache_chitin: list[FileResource] = []
        self._cache_lips: dict[str, list[FileResource]] = {}
        self._cache_modules: dict[str, list[FileResource]] = {}
        self._cache_override: dict[str, list[FileResource]] = {}
        self._cache_rims: dict[str, list[FileResource]] = {}
        self._cache_saves: dict[Path, dict[Path, list[FileResource]]] = {}
        self._cache_streammusic: list[FileResource] = []
        self._cache_streamsounds: list[FileResource] = []
        self._cache_streamwaves: list[FileResource] = []
        self._cache_texturepacks: dict[str, list[FileResource]] = {}

    def _clear_cache(
        self,
        cache_name: Literal[
            "core_items",
            "chitin",
            "lips",
            "modules",
            "override",
            "rims",
            "saves",
            "streammusic",
            "streamsounds",
            "streamwaves",
            "texturepacks",
        ],
    ):
        """Clear a specific cache and print a debug message."""
        cache_attr = f"_cache_{cache_name}"
        if not hasattr(self, cache_attr):
            RobustLogger().warning(f"Cache for '{cache_name}' not found")
            return
        setattr(self, cache_attr, None)
        RobustLogger().debug(f"Cleared cache for '{cache_name}'")

    def clear_all_caches(self):
        """Clear all caches."""
        for attr in dir(self):
            if attr.startswith("_cache_"):
                setattr(self, attr, None)
        RobustLogger().debug("Cleared all caches")

    def _get_cached_or_load(
        self,
        cache_name: str,
        load_method: Callable[[], Any],
    ) -> Any:
        """Get data from cache or load it if not present."""
        cache_attr = f"_cache_{cache_name}"
        cached_data: Any | None = getattr(self, cache_attr, None)
        if not cached_data:
            cached_data = load_method()
            setattr(self, cache_attr, cached_data)
        return cached_data

    # Override these methods with placeholders to allow for lazy loading of resources
    def reload_all(self): ...
    def load_chitin(self): ...
    def load_lips(self): ...
    def load_modules(self): ...
    def load_streammusic(self): ...
    def load_streamsounds(self): ...
    def load_textures(self): ...
    def load_saves(self): ...
    def load_streamwaves(self): ...
    def load_streamvoice(self): ...
    def load_override(self, directory: str | None = None): ...

    @property
    def _chitin(self) -> list[FileResource]:
        return self._get_cached_or_load("chitin", self._load_chitin)

    @_chitin.setter
    def _chitin(self, value: list[FileResource]) -> None: ...  # pylint: disable=unused-argument  # pyright: ignore[reportIncompatibleVariableOverride]
    def _load_chitin(self) -> list[FileResource]:
        """Load the chitin resources."""
        chitin_path: Path = self._path / "chitin.key"
        return list(Chitin(key_path=chitin_path)) if chitin_path.is_file() else []

    @property
    def _female_talktable(self) -> TalkTable:
        return TalkTable(self._path / "dialogf.tlk")

    @_female_talktable.setter
    def _female_talktable(self, value: TalkTable) -> None: ...  # pylint: disable=unused-argument  # pyright: ignore[reportIncompatibleVariableOverride]

    @property
    def _lips(self) -> dict[str, list[FileResource]]:
        def _load_lips_local_function() -> dict[str, list[FileResource]]:
            return self.load_resources_dict(self.lips_path(), capsule_check=is_mod_file)

        return self._get_cached_or_load("lips", _load_lips_local_function)

    @_lips.setter
    def _lips(self, value: dict[str, list[FileResource]]) -> None: ...  # pylint: disable=unused-argument  # pyright: ignore[reportIncompatibleVariableOverride]
    def _load_lips(self) -> dict[str, list[FileResource]]:
        """Load the lips resources."""
        lips_path: Path = self.lips_path()
        result: dict[str, list[FileResource]] = {}
        for folder in [f for f in lips_path.rglob("*") if f.is_dir()] + [lips_path]:
            relative_folder: str = folder.relative_to(lips_path).as_posix()
            result[relative_folder] = self.load_resources_list(folder, recurse=True)
        return result

    @property
    def _modules(self) -> dict[str, list[FileResource]]:
        def _load_modules_local_function() -> dict[str, list[FileResource]]:
            return self.load_resources_dict(
                self.module_path(), capsule_check=is_capsule_file,
            )

        return self._get_cached_or_load("modules", _load_modules_local_function)

    @_modules.setter
    def _modules(self, value: dict[str, list[FileResource]]) -> None: ...  # pylint: disable=unused-argument  # pyright: ignore[reportIncompatibleVariableOverride]

    @property
    def _override(self) -> dict[str, list[FileResource]]:
        return self._get_cached_or_load("override", self._load_override)

    @_override.setter
    def _override(self, value: dict[str, list[FileResource]]) -> None: ...  # pylint: disable=unused-argument  # pyright: ignore[reportIncompatibleVariableOverride]
    def _load_override(self) -> dict[str, list[FileResource]]:
        """Load the override resources."""
        override_path: Path = self.override_path()
        result: dict[str, list[FileResource]] = {}
        for folder in [f for f in override_path.rglob("*") if f.is_dir()] + [
            override_path,
        ]:
            relative_folder: str = folder.relative_to(override_path).as_posix()
            result[relative_folder] = self.load_resources_list(folder, recurse=True)
        return result

    @property
    def _rims(self) -> dict[str, list[FileResource]]:
        return self.load_resources_dict(self.rims_path(), capsule_check=is_rim_file)

    @_rims.setter
    def _rims(self, value: dict[str, list[FileResource]]) -> None: ...  # pylint: disable=unused-argument  # pyright: ignore[reportIncompatibleVariableOverride]

    @property
    def saves(self) -> dict[Path, dict[Path, list[FileResource]]]:
        def _load_saves_local_function() -> dict[Path, dict[Path, list[FileResource]]]:
            return self._load_saves()

        return self._get_cached_or_load("saves", _load_saves_local_function)

    @saves.setter
    def saves(self, value: dict[Path, dict[Path, list[FileResource]]]) -> None: ...  # pylint: disable=unused-argument  # pyright: ignore[reportIncompatibleVariableOverride]
    def _load_saves(self) -> dict[Path, dict[Path, list[FileResource]]]:  # pylint: disable=unused-argument
        """Load the saves."""
        if getattr(self, "_saves", None):
            return self._saves
        self._saves = {  # pylint: disable=attribute-defined-outside-init
            save_location: {
                save_path: [
                    FileResource(
                        ResourceIdentifier.from_path(file).resname,
                        ResourceIdentifier.from_path(file).restype,
                        file.stat().st_size,
                        0,
                        file,
                    )
                    for file in save_path.iterdir()
                    if file.is_file()
                ]
                for save_path in save_location.iterdir()
                if save_path.is_dir()
            }
            for save_location in self.save_locations()
            if save_location.is_dir()
        }
        return self._saves

    @saves.setter
    def saves(self, value: dict[Path, dict[Path, list[FileResource]]]) -> None: ...  # pylint: disable=unused-argument  # pyright: ignore[reportIncompatibleVariableOverride]

    @property
    def _streammusic(self) -> list[FileResource]:
        def _load_streammusic_local_function() -> list[FileResource]:
            return self.load_resources_list(self.streammusic_path())

        return self._get_cached_or_load("streammusic", _load_streammusic_local_function)

    @_streammusic.setter
    def _streammusic(self, value: list[FileResource]) -> None: ...  # pylint: disable=unused-argument  # pyright: ignore[reportIncompatibleVariableOverride]
    def _load_streammusic(self) -> list[FileResource]:
        return self.load_resources_list(self.streammusic_path())

    @property
    def _streamsounds(self) -> list[FileResource]:
        def _load_streamsounds_local_function() -> list[FileResource]:
            return self.load_resources_list(self.streamsounds_path())

        return self._get_cached_or_load(
            "streamsounds", _load_streamsounds_local_function,
        )

    @_streamsounds.setter
    def _streamsounds(self, value: list[FileResource]) -> None: ...  # pylint: disable=unused-argument  # pyright: ignore[reportIncompatibleVariableOverride]
    def _load_streamsounds(self) -> list[FileResource]:
        return self.load_resources_list(self.streamsounds_path())

    @property
    def _streamwaves(self) -> list[FileResource]:
        def _load_streamwaves_local_function() -> list[FileResource]:
            return self.load_resources_list(
                self._find_resource_folderpath(("streamwaves", "streamvoice")),
                recurse=True,
            )

        return self._get_cached_or_load("streamwaves", _load_streamwaves_local_function)

    @_streamwaves.setter
    def _streamwaves(self, value: list[FileResource]) -> None: ...  # pylint: disable=unused-argument  # pyright: ignore[reportIncompatibleVariableOverride]
    def _load_streamwaves(self) -> list[FileResource]:
        return self.load_resources_list(
            self._find_resource_folderpath(("streamwaves", "streamvoice")), recurse=True,
        )

    @property
    def _streamvoice(self) -> list[FileResource]:
        def _load_streamvoice_local_function() -> list[FileResource]:
            return self.load_resources_list(
                self._find_resource_folderpath(("streamvoice", "streamwaves")),
                recurse=True,
            )

        return self._get_cached_or_load("streamvoice", _load_streamvoice_local_function)

    @_streamvoice.setter
    def _streamvoice(self, value: list[FileResource]) -> None: ...  # pylint: disable=unused-argument  # pyright: ignore[reportIncompatibleVariableOverride]
    def _load_streamvoice(self) -> list[FileResource]:
        return self.load_resources_list(
            self._find_resource_folderpath(("streamvoice", "streamwaves")), recurse=True,
        )

    @property
    def _talktable(self) -> TalkTable:
        return self._get_cached_or_load("talktable", self._load_talktable)

    @_talktable.setter
    def _talktable(self, value: TalkTable) -> None: ...  # pylint: disable=unused-argument  # pyright: ignore[reportIncompatibleVariableOverride]
    def _load_talktable(self) -> TalkTable:
        return TalkTable(self._path / "dialog.tlk")

    @property
    def _texturepacks(self) -> dict[str, list[FileResource]]:
        return self._get_cached_or_load("texturepacks", self._load_texturepacks)

    @_texturepacks.setter
    def _texturepacks(self, value: dict[str, list[FileResource]]) -> None: ...  # pylint: disable=unused-argument  # pyright: ignore[reportIncompatibleVariableOverride]
    def _load_texturepacks(self) -> dict[str, list[FileResource]]:
        return self.load_resources_dict(
            self.texturepacks_path(), capsule_check=is_erf_file,
        )

    @classmethod
    def from_base_instance(
        cls,
        installation: Installation,
    ) -> Self:
        """Create a new HTInstallation instance from an existing Installation instance."""
        ht_installation: HTInstallation = installation  # type: ignore[assignment]
        ht_installation.__class__ = cls
        assert isinstance(ht_installation, cls)
        ht_installation.name = (
            f"NonHTInit_{installation.__class__.__name__}_{id(installation)}"
        )
        ht_installation._tsl = installation.game().is_k2()  # noqa: SLF001  # pylint: disable=protected-access
        ht_installation.cache_core_items = None
        ht_installation._cache2da = {}  # noqa: SLF001  # pylint: disable=protected-access
        ht_installation._cache_tpc = {}  # noqa: SLF001  # pylint: disable=protected-access

        return ht_installation

    def build_file_context_menu(  # noqa: PLR0913
        self,
        root_menu: QMenu,
        *,
        parent_widget: QWidget,
        widget_text: str,
        resref_type: list[ResourceType] | list[ResourceIdentifier],
        order: list[SearchLocation] | None = None,
        enable_reference_search: bool = False,
        reference_search_type: Literal[
            "script", "tag", "template_resref", "conversation", "resref", "quest",
        ]
        | None = None,
    ) -> None:
        """Populate `root_menu` with the standard 'file(s) located' menu for a resref.

        This is the shared implementation used by the toolset wherever we show the
        '# file(s) located…' expander + per-location actions + Details… dialog.

        Args:
        ----
            root_menu: The menu to populate
            parent_widget: Parent widget for menu actions
            widget_text: The resref/text value to search for
            resref_type: Resource types to search for file locations
            order: Search location order
            enable_reference_search: If True, add "Find References..." action
            reference_search_type: Type of reference search ("script", "tag", "template_resref", "conversation", or None for generic resref)
        """
        from toolset.gui.dialogs.load_from_location_result import ResourceItems

        # NOTE: This logic is intentionally kept in-sync with the previous nested implementation
        # inside `setup_file_context_menu`. If you change behavior here, you are changing the
        # menu behavior toolset-wide.

        file_menu = QMenu("File...", parent_widget)
        root_menu.addMenu(file_menu)
        root_menu.addSeparator()

        # Defensive: callers can (and sometimes do) pass an empty list here (e.g. when the
        # resource type is user-selectable or not yet known). Avoid IndexError on `resref_type[0]`
        # and present the standard (disabled) "File..." submenu instead.
        if not resref_type:
            file_menu.setDisabled(True)
            for action in root_menu.actions():
                if action.text() == "File...":
                    action.setText("0 file(s) located")
                    break
            return

        search_order: list[SearchLocation] = order or [
            SearchLocation.CHITIN,
            SearchLocation.OVERRIDE,
            SearchLocation.MODULES,
            SearchLocation.RIMS,
        ]
        resource_types: list[ResourceType] | list[ResourceIdentifier] = (
            resref_type if isinstance(resref_type[0], ResourceType) else resref_type
        )
        # FIXME(th3w1zard1): Seems the type hinter override's for `locations` are wrong, need to fix
        locations: dict[str, list[LocationResult]] = self.locations(
            ([widget_text], resource_types),  # pyright: ignore[reportArgumentType, reportAssignmentType]
            search_order,
        )
        flat_locations: list[LocationResult] = (
            [item for sublist in locations.values() for item in sublist]
            if isinstance(locations, dict)
            else locations
        )

        if flat_locations:
            for location in flat_locations:
                display_path: Path = location.filepath.relative_to(self.path())
                file_resource: FileResource = location.as_file_resource()
                if file_resource.inside_bif:
                    display_path /= file_resource.filename()
                location_menu: QMenu | None = file_menu.addMenu(str(display_path))
                ResourceItems(resources=[location]).build_menu(location_menu, self)

            details_action = QAction("Details...", file_menu)

            def _open_details_action() -> None:
                self._open_details(flat_locations)

            details_action.triggered.connect(_open_details_action)
            file_menu.addAction(details_action)
        else:
            file_menu.setDisabled(True)

        for action in root_menu.actions():
            if action.text() == "File...":
                action.setText(f"{len(flat_locations)} file(s) located")
                break

        # Add "Find References..." action if enabled
        if enable_reference_search and widget_text.strip():
            root_menu.addSeparator()
            find_refs_action = QAction("Find References...", parent_widget)

            def _find_references_action(
                checked: bool = False,
                search_text: str = widget_text.strip(),
                search_type: Literal[
                    "script", "tag", "template_resref", "conversation", "resref", "quest",
                ] = reference_search_type or "resref",
            ) -> None:
                """Find references to the given search text and type."""
                self._find_references(
                    parent_widget,
                    search_text,
                    search_type,
                )

            find_refs_action.triggered.connect(_find_references_action)
            root_menu.addAction(find_refs_action)

    def setup_file_context_menu(
        self,
        widget: QPlainTextEdit | QLineEdit | QComboBox,
        resref_type: list[ResourceType] | list[ResourceIdentifier],
        order: list[SearchLocation] | None = None,
        enable_reference_search: bool = False,
        reference_search_type: Literal[
            "script", "tag", "template_resref", "conversation", "resref", "quest",
        ]
        | None = None,
    ):
        from toolset.gui.common.localization import tr

        @Slot(QPoint)
        def extend_context_menu(pos: QPoint):
            root_menu = (
                QMenu(widget)
                if isinstance(widget, QComboBox)
                else widget.createStandardContextMenu()
            )
            assert root_menu is not None, (
                f"{type(self).__name__}.setup_file_context_menu: root_menu cannot be None"
            )
            widget_text: str = str(
                widget.currentText()
                if isinstance(widget, QComboBox)
                else (
                    widget.text()
                    if isinstance(widget, QLineEdit)
                    else widget.toPlainText()
                ),
            )
            self.build_file_context_menu(
                root_menu,
                parent_widget=widget,
                widget_text=widget_text.strip(),
                resref_type=resref_type,
                order=order,
                enable_reference_search=enable_reference_search,
                reference_search_type=reference_search_type,
            )
            root_menu.exec(widget.mapToGlobal(pos))

        widget.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        widget.customContextMenuRequested.connect(extend_context_menu)

        # Set tooltip to inform users about the right-click functionality
        existing_tooltip = widget.toolTip()
        tooltip_text = tr("Right-click to view file locations")
        if existing_tooltip and existing_tooltip.strip():
            widget.setToolTip(f"{existing_tooltip}\n{tooltip_text}")
        else:
            widget.setToolTip(tooltip_text)

    @Slot(list)
    def _open_details(
        self,
        locations: list[LocationResult],
    ):
        from toolset.gui.dialogs.load_from_location_result import FileSelectionWindow

        selection_window = FileSelectionWindow(locations, self)
        selection_window.show()
        selection_window.activateWindow()
        add_window(selection_window)

    def _find_references(
        self,
        parent_widget: QWidget,
        search_text: str,
        search_type: Literal[
            "script", "tag", "template_resref", "conversation", "resref", "quest",
        ]
        | None = None,
    ) -> None:
        """Perform a reference search and display results.

        Args:
        ----
            parent_widget: Parent widget for dialogs
            search_text: The text/resref to search for
            search_type: Type of search ("script", "tag", "template_resref", "conversation", "resref", or None)
        """
        from pykotor.tools.reference_finder import (
            find_conversation_references,
            find_quest_journal_references,
            find_resref_references,
            find_script_references,
            find_tag_references,
            find_template_resref_references,
        )
        from toolset.gui.dialogs.asyncloader import AsyncLoader
        from toolset.gui.dialogs.reference_search_options import ReferenceSearchOptions
        from toolset.gui.dialogs.search import FileResults
        from toolset.utils.window import add_window

        # Show search options dialog
        options_dialog = ReferenceSearchOptions(parent_widget)
        if options_dialog.exec() != QDialog.DialogCode.Accepted:
            return

        partial_match = options_dialog.get_partial_match()
        case_sensitive = options_dialog.get_case_sensitive()
        file_pattern = options_dialog.get_file_pattern()
        file_types = options_dialog.get_file_types()

        # Determine which search function to use
        def search_fn() -> list[ReferenceSearchResult]:
            """Perform the search and return the results."""
            if search_type == "script":
                return find_script_references(
                    self,
                    search_text,
                    partial_match=partial_match,
                    case_sensitive=case_sensitive,
                    file_pattern=file_pattern,
                    file_types=file_types,
                )

            if search_type == "tag":
                return find_tag_references(
                    self,
                    search_text,
                    partial_match=partial_match,
                    case_sensitive=case_sensitive,
                    file_pattern=file_pattern,
                    file_types=file_types,
                )

            if search_type == "template_resref":
                return find_template_resref_references(
                    self,
                    search_text,
                    partial_match=partial_match,
                    case_sensitive=case_sensitive,
                    file_pattern=file_pattern,
                    file_types=file_types,
                )

            if search_type == "conversation":
                return find_conversation_references(
                    self,
                    search_text,
                    partial_match=partial_match,
                    case_sensitive=case_sensitive,
                    file_pattern=file_pattern,
                    file_types=file_types,
                )

            if search_type == "quest":
                return find_quest_journal_references(
                    self,
                    search_text,
                    partial_match=partial_match,
                    case_sensitive=case_sensitive,
                    file_pattern=file_pattern,
                    file_types=file_types,
                )

            # Generic resref search
            return find_resref_references(
                self,
                search_text,
                partial_match=partial_match,
                case_sensitive=case_sensitive,
                file_pattern=file_pattern,
                file_types=file_types,
            )

        loader = AsyncLoader(
            parent_widget,
            f"Searching for references to '{search_text}'...",
            search_fn,
            error_title="An unexpected error occurred searching for references.",
            start_immediately=False,
        )
        loader.setModal(False)
        loader.show()

        def handle_search_completed(results_list: list[ReferenceSearchResult]):
            """Handle the search completed event."""
            from qtpy.QtWidgets import QMessageBox

            if not results_list:
                QMessageBox(
                    QMessageBox.Icon.Information,
                    tr("No references found"),
                    trf(
                        "No references found for '{search_text}'",
                        search_text=search_text,
                    ),
                    parent=parent_widget,
                ).exec()
                return

            # Pass ReferenceSearchResult objects directly to FileResults for field path display
            results_dialog = FileResults(parent_widget, results_list, self)
            results_dialog.show()
            results_dialog.activateWindow()
            results_dialog.setWindowTitle(
                trf(
                    "{count} reference(s) found for '{search_text}'",
                    count=len(results_list),
                    search_text=search_text,
                ),
            )
            add_window(results_dialog)

        loader.optional_finish_hook.connect(handle_search_completed)
        loader.start_worker()
        add_window(loader)

    @Slot(list)
    def handle_file_system_changes(
        self,
        changed_files: list[str],
    ) -> None:
        """Handle file system changes and update caches accordingly.

        This function handles changes in the file system by clearing specific caches
        based on the changed files. It ensures that the caches are updated correctly
        when files are modified, added, or removed.

        Args:
            changed_files (list[str]): A list of file paths that have changed.
        """
        lower_install_path = str(self._path).lower()
        lower_lips_path = str(self.lips_path()).lower()
        lower_module_path = str(self.module_path()).lower()
        lower_override_path = str(self.override_path()).lower()
        lower_rims_path = str(self.rims_path()).lower()
        lower_streammusic_path = str(self.streammusic_path()).lower()
        lower_streamsounds_path = str(self.streamsounds_path()).lower()
        lower_streamwaves_path = str(
            self._find_resource_folderpath(("streamvoice", "streamwaves")),
        ).lower()
        lower_texturepacks_path = str(self.texturepacks_path()).lower()
        lower_save_locations: list[str] = [
            str(save_loc).lower() for save_loc in self.save_locations()
        ]

        for path in changed_files:
            lower_path: str = path.lower()
            if lower_path == lower_install_path:
                self._clear_cache("chitin")
            elif lower_lips_path in lower_path:
                self._clear_cache("lips")
            elif lower_module_path in lower_path:
                self._clear_cache("modules")
            elif lower_override_path in lower_path:
                self._clear_cache("override")
            elif lower_rims_path in lower_path:
                self._clear_cache("rims")
            elif any(save_loc in lower_path for save_loc in lower_save_locations):
                self._clear_cache("saves")
            elif lower_streammusic_path in lower_path:
                self._clear_cache("streammusic")
            elif lower_streamsounds_path in lower_path:
                self._clear_cache("streamsounds")
            elif lower_streamwaves_path in lower_path:
                self._clear_cache("streamwaves")
            elif lower_texturepacks_path in lower_path:
                self._clear_cache("texturepacks")
            else:
                RobustLogger().warning(f"Unhandled file change: '{path}'")

    # region Cache 2DA
    def ht_get_cache_2da(self, resname: str) -> TwoDA | None:
        """Gets a 2DA resource from the cache or loads it if not present.

        This method caches 2DA files that are verified to be loaded by the game engine.
        All 2DA files accessible through this cache are confirmed through reverse engineering
        analysis of swkotor.exe and swkotor2.exe using Ghidra (RE server).

        See TwoDARegistry class in Libraries/PyKotor/src/pykotor/extract/twoda.py for the
        complete list of verified 2DA files and their game engine loading functions.

        Args:
        ----
            resname: The name of the 2DA resource to retrieve (e.g., "appearance", "classes")

        Returns:
        -------
            TwoDA | None: The retrieved 2DA data, or None if not found

        Processing Logic:
        ----------------
            - Check if the 2DA is already cached
            - If not cached, retrieve the 2DA data from the resource system
            - Parse and cache the retrieved 2DA data
            - Return the cached 2DA data.
        """
        resname = resname.lower()
        if resname not in self._cache2da:
            result: ResourceResult | None = self.resource(
                resname,
                ResourceType.TwoDA,
                order=[SearchLocation.OVERRIDE, SearchLocation.CHITIN],
            )
            if result is None:
                return None
            self._cache2da[resname] = read_2da(result.data)
        return self._cache2da[resname]

    def get_relevant_resources(
        self,
        restype: ResourceType,
        src_filepath: Path | None = None,
    ) -> set[FileResource]:
        """Get relevant resources for a given resource type and source filepath.

        This function retrieves relevant resources based on the specified resource type
        and an optional source file path. It uses the installation's resources and caches
        to determine which resources are relevant.

        Args:
        ----
            restype (ResourceType): The type of resource to retrieve.
            src_filepath (PurePath | None): The source file path to use for determining relevant resources.

        Returns:
        -------
            set[FileResource]: A set of relevant resources.

        Processing Logic:
        ----------------
            - If no source file path is provided, return all resources of the specified type.
            - If a source file path is provided, check if it is inside the module or override folder.
            - If inside module, add all resources of the specified type from the module.
            - If inside override, add all resources of the specified type from the override.
            - Return the set of relevant resources.
        """
        from pykotor.common.module import (
            Module,  # pyright: ignore[reportMissingImports]
        )

        if src_filepath is None:
            return {res for res in self if res.restype() is restype}

        relevant_resources: set[FileResource] = {
            res
            for res in (*self.override_resources(), *self.chitin_resources())
            if res.restype() == restype
        }

        src_absolute = Path(src_filepath).absolute()
        module_path = Path(self.module_path()).absolute()
        override_path = Path(self.override_path()).absolute()

        def _is_within(child: Path, parent: Path) -> bool:
            try:
                child.relative_to(parent)
            except ValueError:
                return False
            return True

        if _is_within(src_absolute, module_path):
            relevant_resources.update(
                res
                for cap in cast(
                    "dict[str, Capsule]",
                    Module.get_capsules_dict_matching(self, src_filepath.name),
                ).values()
                if cap is not None
                for res in cap
                if res.restype() == restype
            )
        elif _is_within(src_absolute, override_path):
            relevant_resources.update(
                res
                for reslist in self._modules.values()
                if any(r.identifier() == src_filepath.name for r in reslist)
                for res in reslist
                if res.restype() == restype
            )

        return relevant_resources

    def ht_batch_cache_2da(
        self,
        resnames: list[str],
        *,
        reload: bool = False,
    ):
        """Cache 2D array resources in batch.

        This method efficiently caches multiple 2DA files that are verified to be loaded
        by the game engine. All 2DA files accessible through this cache are confirmed
        through reverse engineering analysis of swkotor.exe and swkotor2.exe using Ghidra
        (RE server).

        Args:
        ----
            resnames: List of resource names to cache (e.g., ["appearance", "classes", "feat"])
            reload: Whether to reload cached resources even if already cached

        Processing Logic:
        ----------------
            1. Check if reload is True, query all resources. Else, query only non-cached resources
            2. Query the resources from override and chitin locations
            3. Read and cache the 2DA data for each queried resource.
        """
        queries: list[ResourceIdentifier] = []
        if reload:
            queries.extend(
                ResourceIdentifier(resname, ResourceType.TwoDA) for resname in resnames
            )
        else:
            queries.extend(
                ResourceIdentifier(resname, ResourceType.TwoDA)
                for resname in resnames
                if resname not in self._cache2da
            )

        if not queries:
            return

        resources: dict[ResourceIdentifier, ResourceResult | None] = self.resources(
            queries, [SearchLocation.OVERRIDE, SearchLocation.CHITIN],
        )
        for iden, resource in resources.items():
            if not resource:
                continue
            self._cache2da[iden.resname] = read_2da(resource.data)

    def htClearCache2DA(self):
        self._cache2da = {}

    # endregion

    # region Cache TPC
    def ht_get_cache_tpc(
        self,
        resname: str,
    ) -> TPC | None:
        """Get a TPC resource from the cache or load it if not present."""
        if resname not in self._cache_tpc:
            tex: TPC | None = self.texture(
                resname,
                order=[
                    SearchLocation.OVERRIDE,
                    SearchLocation.TEXTURES_TPA,
                    SearchLocation.TEXTURES_TPB,
                    SearchLocation.TEXTURES_TPC,
                    SearchLocation.TEXTURES_GUI,
                ],
            )
            if tex is not None:
                self._cache_tpc[resname] = tex
        return self._cache_tpc.get(resname, None)

    def ht_batch_cache_tpc(
        self,
        names: list[str],
        *,
        reload: bool = False,
    ):
        """Cache TPC resources in batch."""
        queries: list[str] = (
            list(names)
            if reload
            else [name for name in names if name not in self._cache_tpc]
        )
        if not queries:
            return

        for resname in queries:
            tex: TPC | None = self.texture(
                resname,
                order=[
                    SearchLocation.TEXTURES_TPA,
                    SearchLocation.TEXTURES_TPB,
                    SearchLocation.TEXTURES_TPC,
                    SearchLocation.TEXTURES_GUI,
                ],
            )
            if tex is not None:
                self._cache_tpc[resname] = tex

    def ht_clear_cache_tpc(self):
        self._cache_tpc = {}

    # endregion

    def get_item_icon_from_uti(
        self,
        uti: UTI,
    ) -> QPixmap:
        """Get an item icon from a UTI."""
        pixmap = QPixmap(":/images/inventory/unknown.png")
        baseitems: TwoDA | None = self.ht_get_cache_2da(HTInstallation.TwoDA_BASEITEMS)
        if baseitems is None:
            RobustLogger().error("Failed to retrieve BASEITEMS 2DA.")
            return pixmap

        try:
            item_class: str = baseitems.get_cell(uti.base_item, "itemclass")
            variation: int = (
                uti.model_variation
                if uti.model_variation != 0
                else uti.texture_variation
            )
            texture_resname: str = f"i{item_class}_{str(variation).rjust(3, '0')}"
            texture: TPC | None = self.ht_get_cache_tpc(texture_resname.lower())

            if texture is None:
                return pixmap
        except Exception:  # noqa: BLE001  # pylint: disable=broad-exception-caught
            RobustLogger().warning(
                f"An error occurred while getting item icon from UTI '{uti}'.",
                exc_info=True,
            )
            return pixmap
        else:
            return self._get_icon(texture)

    def get_item_base_name(
        self,
        base_item: int,
    ) -> str:
        """Get the name of the base item from its ID."""
        try:
            baseitems: TwoDA | None = self.ht_get_cache_2da(
                HTInstallation.TwoDA_BASEITEMS,
            )
            if baseitems is None:
                RobustLogger().error(
                    "Failed to retrieve `baseitems.2da` from your installation.",
                )
                return "Unknown"
        except Exception:  # noqa: BLE001  # pylint: disable=broad-exception-caught
            RobustLogger().exception(
                "An exception occurred while retrieving `baseitems.2da` from your installation.",
            )
            return "Unknown"
        else:
            return baseitems.get_cell(base_item, "label")

    def get_model_var_name(
        self,
        model_variation: int,
    ) -> str:
        """Get the name of the model variation from its ID."""
        return "Default" if model_variation == 0 else f"Variation {model_variation}"

    def get_texture_var_name(
        self,
        texture_variation: int,
    ) -> str:
        """Get the name of the texture variation from its ID."""
        return "Default" if texture_variation == 0 else f"Texture {texture_variation}"

    def get_item_icon_path(
        self,
        base_item: int,
        model_variation: int,
        texture_variation: int,
    ) -> str:
        """Get the icon path based on base item, model variation, and texture variation."""
        baseitems: TwoDA | None = self.ht_get_cache_2da(HTInstallation.TwoDA_BASEITEMS)
        if baseitems is None:
            RobustLogger().warning(
                "Failed to retrieve `baseitems.2da` from your installation.",
            )
            return "Unknown"
        try:
            item_class: str = baseitems.get_cell(base_item, "itemclass")
        except Exception:  # noqa: BLE001  # pylint: disable=broad-exception-caught
            RobustLogger().exception(
                f"An exception occurred while getting cell '{base_item}' from `baseitems.2da`.",
            )
            return "Unknown"
        else:
            variation: int = (
                model_variation if model_variation != 0 else texture_variation
            )
            return f"i{item_class}_{str(variation).rjust(3, '0')}"

    def get_item_icon(
        self,
        base_item: int,
        model_variation: int,
        texture_variation: int,
    ) -> QPixmap:
        """Get an item icon from a base item, model variation, and texture variation."""
        pixmap = QPixmap(":/images/inventory/unknown.png")
        icon_path: str = self.get_item_icon_path(
            base_item, model_variation, texture_variation,
        )
        print(f"Icon path: '{icon_path}'")
        try:
            texture: TPC | None = self.ht_get_cache_tpc(
                os.path.basename(icon_path.lower()),
            )  # noqa: PTH119
            if texture is None:
                return pixmap
        except Exception:  # noqa: BLE001  # pylint: disable=broad-exception-caught
            RobustLogger().exception(
                f"An error occurred loading the icon at '{icon_path}' model variation '{model_variation}' and texture variation '{texture_variation}'.",
            )
            return pixmap
        else:
            return self._get_icon(texture)

    def _get_icon(
        self,
        texture: TPC,
        mipmap: int = 0,
    ) -> QPixmap:
        """Get an icon from a texture."""
        if texture.format().is_dxt():
            texture.decode()
        mm: TPCMipmap = texture.get(0, mipmap)
        image = QImage(
            bytes(mm.data), mm.width, mm.height, mm.tpc_format.to_qimage_format(),
        )
        return QPixmap.fromImage(image).transformed(QTransform().scale(1, -1))

    @property
    def tsl(self) -> bool:
        """Get whether the installation is TSL."""
        if self._tsl is None:
            self._tsl = self.game().is_k2()
        return self._tsl
