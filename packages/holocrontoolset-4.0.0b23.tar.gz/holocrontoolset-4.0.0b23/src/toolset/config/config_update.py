"""Update checks: fetch GitHub release info, compare versions, and parse release JSON."""

from __future__ import annotations

import base64
import json
import re

from contextlib import suppress
from typing import Any, Literal

try:
    import requests  # type: ignore[import-untyped]
except ImportError:
    requests = None  # type: ignore[assignment, unused-ignore]

from qtpy.QtWidgets import QMessageBox

from loggerplus import (
    RobustLogger,  # type: ignore[import-untyped]  # pyright: ignore[reportMissingTypeStubs]
)

# LOCAL_PROGRAM_INFO is imported inside functions to avoid circular import
# config.py imports from config_update, so we can't import config.py at module level


def _clean_json_trailing_commas(json_str: str) -> str:
    """Remove trailing commas from JSON strings to make parsing more robust.

    This function handles trailing commas in JSON arrays and objects,
    which are not allowed by the standard JSON parser but are common
    in hand-edited JSON files.

    Args:
    ----
        json_str: The JSON string that may contain trailing commas

    Returns:
    -------
        A cleaned JSON string without trailing commas
    """
    # Remove trailing commas before closing brackets/braces
    # This regex matches: comma, optional whitespace, closing bracket/brace
    # Pattern: ,\s*([}\]])
    cleaned = re.sub(r",\s*([}\]])", r"\1", json_str)
    return cleaned


def fetch_update_info(
    update_link: str,
    timeout: int = 15,
) -> dict[str, Any]:
    if requests is None:
        raise ImportError("The 'requests' module is not installed. Please install it to enable update checking functionality. You can install it with: pip install requests")
    req = requests.get(
        update_link,
        timeout=timeout,
    )
    req.raise_for_status()
    file_data: dict[str, Any] = req.json()
    return file_data


def get_remote_toolset_update_info(
    *,
    use_beta_channel: bool = False,
    silent: bool = False,
) -> Exception | dict[str, Any]:
    # Import here to avoid circular import (config.py imports from this module)
    from toolset.config.config_info import LOCAL_PROGRAM_INFO  # noqa: PLC0415

    if use_beta_channel:
        update_info_link: str = LOCAL_PROGRAM_INFO["updateBetaInfoLink"]
    else:
        update_info_link = LOCAL_PROGRAM_INFO["updateInfoLink"]

    try:
        timeout: Literal[2, 10] = 2 if silent else 10
        file_data: dict[str, Any] = fetch_update_info(update_info_link, timeout)
        base64_content: str = file_data["content"]
        decoded_content: bytes = base64.b64decode(base64_content)
        decoded_content_str: str = decoded_content.decode(encoding="utf-8")
        json_data_match: re.Match[str] | None = re.search(r"<---JSON_START--->\s*\#\s*(.*?)\s*\#\s*<---JSON_END--->", decoded_content_str, flags=re.DOTALL)

        if not json_data_match:
            raise ValueError(f"JSON data not found or markers are incorrect: {json_data_match}")  # noqa: TRY301
        json_str: str = json_data_match[1]
        # Clean trailing commas before parsing to handle malformed JSON
        cleaned_json_str: str = _clean_json_trailing_commas(json_str)
        remote_info: dict[str, Any] = json.loads(cleaned_json_str)
        if not isinstance(remote_info, dict):
            raise TypeError(f"Expected remote_info to be a dict, instead got type {remote_info.__class__.__name__}")  # noqa: TRY301
    except ImportError as e:
        # Handle missing requests module specifically
        err_msg: str = str((e.__class__.__name__, str(e)))
        result: int | QMessageBox.StandardButton = silent or QMessageBox.question(
            None,
            "Internet connection unavailable",
            (
                "The 'requests' module is not installed, so the toolset cannot check for updates online.<br><br>"
                + err_msg.replace("\n", "<br>")
                + "<br><br>"
                + "Would you like to use the local configuration instead?"
            ),
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.Yes,
        )
        if result not in {QMessageBox.StandardButton.Yes, True}:
            return e
        remote_info = LOCAL_PROGRAM_INFO
    except Exception as e:  # noqa: BLE001
        err_msg = str((e.__class__.__name__, str(e)))
        result = silent or QMessageBox.question(
            None,
            "Error occurred fetching update information.",
            (
                "An error occurred while fetching the latest toolset information.<br><br>"
                + err_msg.replace("\n", "<br>")
                + "<br><br>"
                + "Would you like to check against the local database instead?"
            ),  # noqa: E501
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.Yes,
        )
        if result not in {QMessageBox.StandardButton.Yes, True}:
            return e
        remote_info = LOCAL_PROGRAM_INFO
    return remote_info


def is_remote_version_newer(
    local_version: str,
    remote_version: str,
) -> bool | None:
    version_check: bool | None = None
    with suppress(Exception):
        from packaging import version

        version_check = version.parse(remote_version) > version.parse(local_version)
    if version_check is None:
        RobustLogger().warning(f"Version string might be malformed, attempted 'packaging.version.parse({local_version}) > packaging.version.parse({remote_version})'")
        with suppress(Exception):
            from distutils.version import LooseVersion

            version_check = LooseVersion(remote_version) > LooseVersion(local_version)
    return version_check
