"""
CogProfile — AI 认知身份证

把对话记忆变成持续进化的用户认知档案。

用法:
    from cogprofile import CogProfileEngine, Memory

    engine = CogProfileEngine(llm_api_key="sk-xxx")
    profile = await engine.update(user_id="u1", memories=[...])
    print(profile.emotion.trend.direction)  # "declining"
"""

from cogprofile.engine import CogProfileEngine
from cogprofile.models import CogProfile, Memory, MemoryCategory, MemoryImportance

__version__ = "0.1.0"

__all__ = [
    "CogProfileEngine",
    "CogProfile",
    "Memory",
    "MemoryCategory",
    "MemoryImportance",
]
