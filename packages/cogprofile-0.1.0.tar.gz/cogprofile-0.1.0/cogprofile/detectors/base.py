"""检测器基类和注册机制"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Optional

from cogprofile.llm import LLMClient
from cogprofile.models import Insight, InsightType, Memory


class BaseDetector(ABC):
    """
    洞察检测器基类。

    每个维度对应一个检测器。所有检测器遵循相同的接口：
    输入一组记忆 → 输出零到多条洞察。
    """

    insight_type: InsightType

    def __init__(self, llm: LLMClient):
        self.llm = llm

    @abstractmethod
    async def detect(
        self,
        memories: list[Memory],
        user_id: str,
        **kwargs,
    ) -> list[Insight]:
        """
        执行检测。

        参数:
            memories: 按时间排序的记忆列表
            user_id: 用户ID
        返回:
            发现的洞察列表（可能为空）
        """
        ...


# 检测器注册表
_DETECTOR_REGISTRY: dict[InsightType, type[BaseDetector]] = {}


def register_detector(insight_type: InsightType):
    """装饰器：注册一个检测器到全局注册表"""
    def decorator(cls: type[BaseDetector]):
        cls.insight_type = insight_type
        _DETECTOR_REGISTRY[insight_type] = cls
        return cls
    return decorator


def get_detector(insight_type: InsightType) -> type[BaseDetector]:
    """根据类型获取检测器类"""
    if insight_type not in _DETECTOR_REGISTRY:
        raise ValueError(f"未注册的检测器类型: {insight_type}")
    return _DETECTOR_REGISTRY[insight_type]


def get_all_detectors() -> dict[InsightType, type[BaseDetector]]:
    """获取所有已注册的检测器"""
    return dict(_DETECTOR_REGISTRY)
