"""洞察检测器 —— CogProfile 的内部引擎"""

from cogprofile.detectors.base import (
    BaseDetector,
    get_all_detectors,
    get_detector,
    register_detector,
)
from cogprofile.detectors.emotion_trend import EmotionTrendDetector
from cogprofile.detectors.topic_anomaly import TopicAnomalyDetector
from cogprofile.detectors.goal_drift import GoalDriftDetector

__all__ = [
    "BaseDetector",
    "register_detector",
    "get_detector",
    "get_all_detectors",
    "EmotionTrendDetector",
    "TopicAnomalyDetector",
    "GoalDriftDetector",
]
