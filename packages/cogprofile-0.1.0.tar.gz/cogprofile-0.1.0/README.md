# CogProfile Python SDK

> **把对话记忆变成持续进化的认知身份证。**

[CogProfile](https://github.com/cogprofile/cogprofile-spec) 是一个开放标准，定义了 AI 系统如何表达对一个人的理解。本仓库是它的 Python 参考实现。

## 和现有工具的区别

Mem0、Memobase 做的是**记忆存储**——记住用户说了什么。

CogProfile 做的是**认知建模**——理解用户说的这些话意味着什么。

```
Mem0/Memobase 输出:
  用户是程序员，喜欢咖啡，在北京工作

CogProfile 输出:
  用户是程序员，但最近三周5次提到想转产品经理
  情绪持续两周下滑（0.7 → 0.3），主要触发因素是工作压力
  和上级关系恶化中（3个月内从正面转向负面）
  行为规律：提到加班后2天内会聊美食（出现3次）
  学日语的目标40天未提及，可能已放弃
```

## 安装

```bash
pip install cogprofile
```

## 快速开始

```python
import asyncio
from datetime import datetime, timedelta
from cogprofile import CogProfileEngine, Memory

engine = CogProfileEngine(
    llm_api_key="sk-xxx",
    llm_provider="deepseek",  # 也支持 dashscope / moonshot / zhipu / openai
)

memories = [
    Memory(id="1", user_id="u1", content="新项目开始了，很兴奋",
           created_at=datetime.now() - timedelta(days=14)),
    Memory(id="2", user_id="u1", content="连续加班一周，感觉很疲惫",
           created_at=datetime.now() - timedelta(days=2)),
]

async def main():
    profile = await engine.update(user_id="u1", memories=memories)

    print(profile.emotion.current.label)       # "stressed"
    print(profile.emotion.trend.direction)      # "declining"
    print(profile.goals.fading)                 # 正在放弃的目标列表

asyncio.run(main())
```

## 对接已有记忆系统

### Mem0

```python
from mem0 import Memory as Mem0Memory
from cogprofile import CogProfileEngine
from cogprofile.storage import Mem0Adapter

mem0 = Mem0Memory()
store = Mem0Adapter(mem0_client=mem0)
engine = CogProfileEngine(llm_api_key="sk-xxx", store=store)

profile = await engine.update(user_id="user_001")
```

### 自定义数据库

```python
from cogprofile.storage import MemoryStore

class MyStore(MemoryStore):
    async def get_memories(self, user_id, since=None, until=None, category=None, limit=500):
        rows = await my_db.query(...)
        return [Memory(...) for row in rows]

    async def get_all_users(self):
        return await my_db.query("SELECT DISTINCT user_id FROM memories")
```

## 认知身份证包含什么

| 模块 | 内容 | 示例 |
|------|------|------|
| 身份 | 静态事实和偏好 | 姓名、职业、饮食偏好 |
| 情绪 | 情感状态和变化轨迹 | "压力持续两周上升，触发因素是工作" |
| 注意力 | 话题焦点和异常 | "工作压力最近7天提了8次，异常升温" |
| 目标 | 计划和承诺追踪 | "学日语：提了3次，然后40天没再提" |
| 关系 | 关键人物和关系动态 | "对李经理的态度连续3个月恶化" |
| 模式 | 行为规律 | "提到加班后2天内会聊美食" |
| 预测 | 前瞻推断 | "可能1-2周内提出离职" |

## 支持的大模型

| 提供商 | provider 值 | 默认模型 |
|--------|------------|---------|
| DeepSeek | `deepseek` | deepseek-chat |
| 阿里通义 | `dashscope` | qwen-plus |
| Moonshot | `moonshot` | moonshot-v1-8k |
| 智谱AI | `zhipu` | glm-4-flash |
| OpenAI | `openai` | gpt-4o-mini |

## 规范

完整的 CogProfile 数据格式定义见：[cogprofile-spec](https://github.com/cogprofile/cogprofile-spec)

## 许可证

Apache 2.0

## 引用

```bibtex
@misc{cogprofile2026,
  title={CogProfile: An Open Standard for AI Cognitive Identity},
  author={CogProfile Project},
  year={2026},
  url={https://github.com/cogprofile/cogprofile-spec}
}
```
