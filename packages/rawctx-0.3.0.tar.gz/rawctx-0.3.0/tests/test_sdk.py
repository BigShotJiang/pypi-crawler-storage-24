from __future__ import annotations

import asyncio
import base64
from io import BytesIO
import json
from pathlib import Path
import tarfile

from click.testing import CliRunner

import rawctx
from rawctx.cli import main
from rawctx.registry.client import AsyncRegistryClient, RegistryClient, SearchResult
from rawctx.registry.models import ApiTokenInfo, OAuthLoginInfo, PackageDetail, SearchItem, VersionInfo


def _fake_jwt(payload: dict[str, object]) -> str:
    header = base64.urlsafe_b64encode(json.dumps({"alg": "none", "typ": "JWT"}).encode("utf-8")).decode("utf-8").rstrip("=")
    body = base64.urlsafe_b64encode(json.dumps(payload).encode("utf-8")).decode("utf-8").rstrip("=")
    return f"{header}.{body}.signature"


def _archive_bytes(version: str) -> bytes:
    payload = BytesIO()
    with tarfile.open(fileobj=payload, mode="w:gz") as tar:
        files = {
            "package/rawctx.yaml": (
                f"name: \"@owner/sample\"\n"
                f"version: \"{version}\"\n"
                "format: \"osi\"\n"
                "models:\n"
                "  - models/sample.osi.yaml\n"
            ),
            "package/models/sample.osi.yaml": (
                "version: \"1.0\"\n"
                "dialects:\n"
                "  - ANSI_SQL\n"
                "vendors:\n"
                "  - COMMON\n"
                "semantic_model:\n"
                "  - name: sample\n"
                "    datasets:\n"
                "      - name: sample\n"
                "        source: analytics.sample\n"
            ),
        }
        for name, content in files.items():
            content_bytes = content.encode("utf-8")
            info = tarfile.TarInfo(name=name)
            info.size = len(content_bytes)
            info.mtime = 0
            tar.addfile(info, BytesIO(content_bytes))
    return payload.getvalue()


def _write_valid_package(base: Path) -> Path:
    package_dir = base / "example"
    models_dir = package_dir / "models"
    models_dir.mkdir(parents=True)

    (package_dir / "rawctx.yaml").write_text(
        """
name: "@demo/retail-analytics"
version: "1.0.0"
format: "osi"
description: "Retail analytics semantic model"
models:
  - models/sales_summary.osi.yaml
""".strip()
        + "\n",
        encoding="utf-8",
    )

    (package_dir / "README.md").write_text("# Retail Analytics\n", encoding="utf-8")

    (models_dir / "sales_summary.osi.yaml").write_text(
        """
version: "1.0"
dialects:
  - ANSI_SQL
vendors:
  - COMMON
semantic_model:
  - name: sales_summary
    datasets:
      - name: sales_summary
        source: analytics.sales_summary
        fields:
          - name: order_count
            expression:
              dialects:
                - dialect: ANSI_SQL
                  expression: "count(*)"
          - name: order_date
            expression:
              dialects:
                - dialect: ANSI_SQL
                  expression: "order_date"
            dimension:
              is_time: true
    metrics:
      - name: order_count
        expression:
          dialects:
            - dialect: ANSI_SQL
              expression: "count(*)"
""".strip()
        + "\n",
        encoding="utf-8",
    )

    return package_dir


def _write_metricflow_project(base: Path) -> Path:
    project_dir = base / "dbt_project"
    models_dir = project_dir / "models" / "semantic_models"
    models_dir.mkdir(parents=True, exist_ok=True)

    (project_dir / "dbt_project.yml").write_text(
        """
name: "jaffle_shop"
version: "1.2.3"
config-version: 2
""".strip()
        + "\n",
        encoding="utf-8",
    )

    (models_dir / "orders.yml").write_text(
        """
version: 2
semantic_models:
  - name: orders
    model: ref('fct_orders')
    entities:
      - name: order
        type: primary
        expr: order_id
    dimensions:
      - name: ordered_at
        type: time
        expr: ordered_at
    measures:
      - name: order_count
        expr: 1

metrics:
  - name: order_count
    type: simple
    type_params:
      measure: order_count
""".strip()
        + "\n",
        encoding="utf-8",
    )

    return project_dir


def test_rawctx_exports_and_sync_login_logout(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))

    assert callable(rawctx.search)
    assert callable(rawctx.download)
    assert callable(rawctx.snapshot_download)
    assert rawctx.RawctxClient is not None
    assert rawctx.AsyncRawctxClient is not None

    monkeypatch.setattr(
        RegistryClient,
        "oauth_login",
        lambda self: OAuthLoginInfo(authorize_url="https://auth.example/login", state="state123"),
    )
    monkeypatch.setattr(
        RegistryClient,
        "create_api_token",
        lambda self, *, id_token, name, expires_in_days=None: ApiTokenInfo(
            id="token-id",
            name=name,
            token="rxctx_token",
            prefix="rxctx_",
            created_at="2026-02-28T00:00:00Z",
            expires_at=None,
        ),
    )
    monkeypatch.setattr(RegistryClient, "revoke_api_token", lambda self, token_id: True)

    payload = rawctx.login(
        registry="https://registry.example",
        no_browser=True,
        id_token=_fake_jwt({"preferred_username": "owner"}),
    )
    assert payload["username"] == "owner"
    assert payload["token_id"] == "token-id"

    logout_payload = rawctx.logout()
    assert logout_payload["had_token"] is True
    assert logout_payload["revoked"] is True


def test_search_json_parity_with_sdk(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))

    def fake_search_packages(self, *, query, format, source_format, origin, domain, source, tags, sort, page, size):
        return SearchResult(
            items=[
                SearchItem(
                    id="pkg-1",
                    scope="owner",
                    name="sample",
                    description="Sample",
                    format="osi",
                    source_format=None,
                    origin="native",
                    origin_url=None,
                    origin_repo=None,
                    source="shopify",
                    domain="finance",
                    tags=["demo"],
                    download_count=1,
                    star_count=2,
                )
            ],
            meta={"page": page, "size": size, "total": 1, "sort": sort},
        )

    monkeypatch.setattr(RegistryClient, "search_packages", fake_search_packages)

    sdk_payload = rawctx.search("sample", registry="https://registry.example", sort="downloads")

    runner = CliRunner()
    result = runner.invoke(
        main,
        ["search", "sample", "--sort", "downloads", "--registry", "https://registry.example", "--json"],
    )

    assert result.exit_code == 0, result.output
    assert json.loads(result.output) == sdk_payload


def test_search_prefers_public_results_before_authenticated_fallback(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))
    monkeypatch.setenv("RAWCTX_TOKEN", "rxctx_secret")

    observed_tokens: list[str | None] = []

    def fake_search_packages(self, *, query, format, source_format, origin, domain, source, tags, sort, page, size):
        observed_tokens.append(self.token)
        if self.token:
            return SearchResult(
                items=[
                    SearchItem(
                        id="private-1",
                        scope="owner",
                        name="private-result",
                        description="Private fallback result",
                        format="osi",
                        source_format=None,
                        origin="native",
                        origin_url=None,
                        origin_repo=None,
                        source="salesforce",
                        domain="crm",
                        tags=["private"],
                        download_count=0,
                        star_count=0,
                    )
                ],
                meta={"page": page, "size": size, "total": 1, "engine": "postgres", "query_mode": "fallback"},
            )
        return SearchResult(
            items=[
                SearchItem(
                    id="public-1",
                    scope="owner",
                    name="public-result",
                    description="Public search result",
                    format="osi",
                    source_format=None,
                    origin="native",
                    origin_url=None,
                    origin_repo=None,
                    source="salesforce",
                    domain="crm",
                    tags=["public"],
                    download_count=0,
                    star_count=0,
                )
            ],
            meta={"page": page, "size": size, "total": 1, "engine": "opensearch", "query_mode": "exact"},
        )

    monkeypatch.setattr(RegistryClient, "search_packages", fake_search_packages)

    payload = rawctx.search("sf revenue", registry="https://registry.example")

    assert payload["items"][0]["name"] == "public-result"
    assert payload["meta"]["engine"] == "opensearch"
    assert observed_tokens == [None]


def test_search_falls_back_to_authenticated_results_when_public_is_empty(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))
    monkeypatch.setenv("RAWCTX_TOKEN", "rxctx_secret")

    observed_tokens: list[str | None] = []

    def fake_search_packages(self, *, query, format, source_format, origin, domain, source, tags, sort, page, size):
        observed_tokens.append(self.token)
        if self.token:
            return SearchResult(
                items=[
                    SearchItem(
                        id="private-1",
                        scope="owner",
                        name="private-result",
                        description="Private fallback result",
                        format="osi",
                        source_format=None,
                        origin="native",
                        origin_url=None,
                        origin_repo=None,
                        source="salesforce",
                        domain="crm",
                        tags=["private"],
                        download_count=0,
                        star_count=0,
                    )
                ],
                meta={"page": page, "size": size, "total": 1, "engine": "postgres", "query_mode": "fallback"},
            )
        return SearchResult(items=[], meta={"page": page, "size": size, "total": 0, "engine": "opensearch", "query_mode": "exact"})

    monkeypatch.setattr(RegistryClient, "search_packages", fake_search_packages)

    payload = rawctx.search("private package", registry="https://registry.example")

    assert payload["items"][0]["name"] == "private-result"
    assert payload["meta"]["engine"] == "postgres"
    assert observed_tokens == [None, "rxctx_secret"]


def test_download_json_parity_with_sdk(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))

    monkeypatch.setattr(
        RegistryClient,
        "get_package",
        lambda self, scope, name: PackageDetail(
            id="pkg",
            scope=scope,
            name=name,
            description="Sample",
            format="osi",
            source_format=None,
            origin="native",
            origin_url=None,
            origin_repo=None,
            source=None,
            domain=None,
            license=None,
            repository_url=None,
            readme=None,
            tags=[],
            is_private=False,
            download_count=0,
            star_count=0,
            owner=None,
        ),
    )
    monkeypatch.setattr(
        RegistryClient,
        "list_versions",
        lambda self, scope, name, page=1, size=100: (
            [
                VersionInfo(
                    id="v100",
                    version="1.0.0",
                    status="published",
                    search_index_status="indexed",
                    file_size=1,
                    checksum_sha256="a" * 64,
                    model_summary=None,
                    created_at="2026-02-28T00:00:00Z",
                    published_at="2026-02-28T00:00:00Z",
                )
            ],
            {"page": 1, "size": 100, "total": 1},
        ),
    )
    monkeypatch.setattr(
        RegistryClient,
        "request_download",
        lambda self, *, scope, name, version: {"download_url": f"https://download.example/{scope}/{name}/{version}", "expires_in": 900},
    )
    monkeypatch.setattr(RegistryClient, "download_bytes", lambda self, download_url: _archive_bytes("1.0.0"))

    sdk_path = rawctx.download("@owner/sample", "models/sample.osi.yaml", registry="https://registry.example")

    runner = CliRunner()
    cli_result = runner.invoke(
        main,
        [
            "download",
            "@owner/sample",
            "models/sample.osi.yaml",
            "--registry",
            "https://registry.example",
            "--json",
        ],
    )

    assert cli_result.exit_code == 0, cli_result.output
    assert json.loads(cli_result.output) == {
        "package": "@owner/sample",
        "version": "1.0.0",
        "path": "models/sample.osi.yaml",
        "local_path": sdk_path,
    }


def test_snapshot_download_json_parity_with_sdk(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))

    monkeypatch.setattr(
        RegistryClient,
        "get_package",
        lambda self, scope, name: PackageDetail(
            id="pkg",
            scope=scope,
            name=name,
            description="Sample",
            format="osi",
            source_format=None,
            origin="native",
            origin_url=None,
            origin_repo=None,
            source=None,
            domain=None,
            license=None,
            repository_url=None,
            readme=None,
            tags=[],
            is_private=False,
            download_count=0,
            star_count=0,
            owner=None,
        ),
    )
    monkeypatch.setattr(
        RegistryClient,
        "list_versions",
        lambda self, scope, name, page=1, size=100: (
            [
                VersionInfo(
                    id="v100",
                    version="1.0.0",
                    status="published",
                    search_index_status="indexed",
                    file_size=1,
                    checksum_sha256="a" * 64,
                    model_summary=None,
                    created_at="2026-02-28T00:00:00Z",
                    published_at="2026-02-28T00:00:00Z",
                )
            ],
            {"page": 1, "size": 100, "total": 1},
        ),
    )
    monkeypatch.setattr(
        RegistryClient,
        "request_download",
        lambda self, *, scope, name, version: {"download_url": f"https://download.example/{scope}/{name}/{version}", "expires_in": 900},
    )
    monkeypatch.setattr(RegistryClient, "download_bytes", lambda self, download_url: _archive_bytes("1.0.0"))

    sdk_path = rawctx.snapshot_download("@owner/sample", registry="https://registry.example")

    runner = CliRunner()
    cli_result = runner.invoke(
        main,
        ["snapshot-download", "@owner/sample", "--registry", "https://registry.example", "--json"],
    )

    assert cli_result.exit_code == 0, cli_result.output
    assert json.loads(cli_result.output) == {
        "package": "@owner/sample",
        "version": "1.0.0",
        "local_path": sdk_path,
        "files": ["models/sample.osi.yaml"],
    }


def test_async_rawctx_client_search(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))

    async def fake_search_packages(self, *, query, format, source_format, origin, domain, source, tags, sort, page, size):
        return SearchResult(
            items=[
                SearchItem(
                    id="pkg-1",
                    scope="owner",
                    name="sample",
                    description="Sample",
                    format="osi",
                    source_format=None,
                    origin="native",
                    origin_url=None,
                    origin_repo=None,
                    source="shopify",
                    domain="finance",
                    tags=["demo"],
                    download_count=1,
                    star_count=2,
                )
            ],
            meta={"page": page, "size": size, "total": 1, "sort": sort},
        )

    monkeypatch.setattr(AsyncRegistryClient, "search_packages", fake_search_packages)

    async def run() -> dict:
        async with rawctx.AsyncRawctxClient(registry="https://registry.example") as client:
            return await client.search("sample", sort="stars")

    payload = asyncio.run(run())
    assert payload["meta"]["sort"] == "stars"
    assert payload["items"][0]["name"] == "sample"


def test_async_search_prefers_public_results_before_authenticated_fallback(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))
    monkeypatch.setenv("RAWCTX_TOKEN", "rxctx_secret")

    observed_tokens: list[str | None] = []

    async def fake_search_packages(self, *, query, format, source_format, origin, domain, source, tags, sort, page, size):
        observed_tokens.append(self.token)
        if self.token:
            return SearchResult(
                items=[
                    SearchItem(
                        id="private-1",
                        scope="owner",
                        name="private-result",
                        description="Private fallback result",
                        format="osi",
                        source_format=None,
                        origin="native",
                        origin_url=None,
                        origin_repo=None,
                        source="salesforce",
                        domain="crm",
                        tags=["private"],
                        download_count=0,
                        star_count=0,
                    )
                ],
                meta={"page": page, "size": size, "total": 1, "engine": "postgres", "query_mode": "fallback"},
            )
        return SearchResult(
            items=[
                SearchItem(
                    id="public-1",
                    scope="owner",
                    name="public-result",
                    description="Public search result",
                    format="osi",
                    source_format=None,
                    origin="native",
                    origin_url=None,
                    origin_repo=None,
                    source="salesforce",
                    domain="crm",
                    tags=["public"],
                    download_count=0,
                    star_count=0,
                )
            ],
            meta={"page": page, "size": size, "total": 1, "engine": "opensearch", "query_mode": "exact"},
        )

    monkeypatch.setattr(AsyncRegistryClient, "search_packages", fake_search_packages)

    async def run() -> dict:
        async with rawctx.AsyncRawctxClient(registry="https://registry.example") as client:
            return await client.search("sf revenue")

    payload = asyncio.run(run())
    assert payload["items"][0]["name"] == "public-result"
    assert payload["meta"]["engine"] == "opensearch"
    assert observed_tokens == [None]


def test_async_download_and_snapshot_download(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))

    async def fake_get_package(self, *, scope, name):
        return PackageDetail(
            id="pkg",
            scope=scope,
            name=name,
            description="Sample",
            format="osi",
            source_format=None,
            origin="native",
            origin_url=None,
            origin_repo=None,
            source=None,
            domain=None,
            license=None,
            repository_url=None,
            readme=None,
            tags=[],
            is_private=False,
            download_count=0,
            star_count=0,
            owner=None,
        )

    async def fake_list_versions(self, *, scope, name, page=1, size=100):
        return (
            [
                VersionInfo(
                    id="v100",
                    version="1.0.0",
                    status="published",
                    search_index_status="indexed",
                    file_size=1,
                    checksum_sha256="a" * 64,
                    model_summary=None,
                    created_at="2026-02-28T00:00:00Z",
                    published_at="2026-02-28T00:00:00Z",
                )
            ],
            {"page": 1, "size": 100, "total": 1},
        )

    async def fake_request_download(self, *, scope, name, version):
        return {"download_url": f"https://download.example/{scope}/{name}/{version}", "expires_in": 900}

    async def fake_download_bytes(self, *, download_url):
        return _archive_bytes("1.0.0")

    monkeypatch.setattr(AsyncRegistryClient, "get_package", fake_get_package)
    monkeypatch.setattr(AsyncRegistryClient, "list_versions", fake_list_versions)
    monkeypatch.setattr(AsyncRegistryClient, "request_download", fake_request_download)
    monkeypatch.setattr(AsyncRegistryClient, "download_bytes", fake_download_bytes)

    async def run() -> tuple[str, str]:
        async with rawctx.AsyncRawctxClient(registry="https://registry.example") as client:
            snapshot_path = await client.snapshot_download("@owner/sample")
            file_path = await client.download("@owner/sample", "models/sample.osi.yaml")
            return snapshot_path, file_path

    snapshot_path, file_path = asyncio.run(run())
    assert snapshot_path.endswith("/@owner/sample/1.0.0")
    assert file_path.endswith("/models/sample.osi.yaml")


def test_validate_and_pack_json_parity_with_sdk(tmp_path: Path) -> None:
    package_dir = _write_valid_package(tmp_path)
    sdk_validate = rawctx.validate(package_dir)
    sdk_pack = rawctx.pack(package_dir, output_dir=tmp_path / "dist")

    runner = CliRunner()
    validate_result = runner.invoke(main, ["validate", str(package_dir), "--json"])
    pack_result = runner.invoke(main, ["pack", str(package_dir), "--output-dir", str(tmp_path / "dist"), "--json"])

    assert validate_result.exit_code == 0, validate_result.output
    assert pack_result.exit_code == 0, pack_result.output
    assert json.loads(validate_result.output) == sdk_validate
    assert json.loads(pack_result.output) == sdk_pack


def test_convert_json_parity_with_sdk(monkeypatch, tmp_path: Path) -> None:
    project_dir = _write_metricflow_project(tmp_path)
    config_path = tmp_path / "rawctx" / "config.yaml"
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text("profile:\n  username: owner\n", encoding="utf-8")
    monkeypatch.setenv("RAWCTX_CONFIG", str(config_path))

    output_dir = tmp_path / "converted"
    sdk_payload = rawctx.convert(project_dir, from_format="metricflow", to_format="osi", output=output_dir)

    runner = CliRunner()
    cli_result = runner.invoke(
        main,
        [
            "convert",
            "--from",
            "metricflow",
            "--to",
            "osi",
            str(project_dir),
            "--output",
            str(output_dir),
            "--overwrite",
            "--json",
        ],
    )

    assert cli_result.exit_code == 0, cli_result.output
    assert json.loads(cli_result.output) == sdk_payload
