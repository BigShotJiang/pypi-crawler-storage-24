from __future__ import annotations

from io import BytesIO
from pathlib import Path
import tarfile

from click.testing import CliRunner

from rawctx.cli import main
from rawctx.registry.client import RegistryClient, RegistryError
from rawctx.registry.models import PackageDetail, VersionInfo


def _archive_bytes(version: str) -> bytes:
    payload = BytesIO()
    with tarfile.open(fileobj=payload, mode="w:gz") as tar:
        rawctx_yaml = f"name: \"@owner/sample\"\nversion: \"{version}\"\nformat: \"osi\"\nmodels:\n  - models/sample.osi.yaml\n"
        model_yaml = (
            "version: \"1.0\"\n"
            "dialects:\n"
            "  - ANSI_SQL\n"
            "vendors:\n"
            "  - COMMON\n"
            "semantic_model:\n"
            "  - name: sample\n"
            "    datasets:\n"
            "      - name: sample\n"
            "        source: analytics.sample\n"
        )
        for name, content in {
            "package/rawctx.yaml": rawctx_yaml,
            "package/models/sample.osi.yaml": model_yaml,
        }.items():
            content_bytes = content.encode("utf-8")
            info = tarfile.TarInfo(name=name)
            info.size = len(content_bytes)
            info.mtime = 0
            tar.addfile(info, BytesIO(content_bytes))
    return payload.getvalue()


def _native_package(scope: str, name: str) -> PackageDetail:
    return PackageDetail(
        id="pkg",
        scope=scope,
        name=name,
        description="Sample",
        format="osi",
        source_format=None,
        origin="native",
        origin_url=None,
        origin_repo=None,
        source=None,
        domain=None,
        license=None,
        repository_url=None,
        readme=None,
        tags=[],
        is_private=False,
        download_count=0,
        star_count=0,
        owner=None,
    )


def test_snapshot_download_online_selects_latest_semver(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))
    monkeypatch.setattr(RegistryClient, "get_package", lambda self, scope, name: _native_package(scope, name))

    versions = [
        VersionInfo(
            id="v100",
            version="1.0.0",
            status="published",
            search_index_status="indexed",
            file_size=1,
            checksum_sha256="a" * 64,
            model_summary=None,
            created_at="2026-02-28T00:00:00Z",
            published_at="2026-02-28T00:00:00Z",
        ),
        VersionInfo(
            id="v120",
            version="1.2.0",
            status="published",
            search_index_status="indexed",
            file_size=1,
            checksum_sha256="b" * 64,
            model_summary=None,
            created_at="2026-02-28T00:00:00Z",
            published_at="2026-02-28T00:00:00Z",
        ),
    ]
    monkeypatch.setattr(RegistryClient, "list_versions", lambda self, scope, name, page=1, size=100: (versions, {"page": 1, "size": 100, "total": 2}))

    observed: dict[str, str] = {}

    def fake_request_download(self, *, scope: str, name: str, version: str):
        observed["version"] = version
        return {"download_url": f"https://download.example/{scope}/{name}/{version}", "expires_in": 900}

    monkeypatch.setattr(RegistryClient, "request_download", fake_request_download)
    monkeypatch.setattr(RegistryClient, "download_bytes", lambda self, download_url: _archive_bytes("1.2.0"))

    runner = CliRunner()
    result = runner.invoke(main, ["snapshot-download", "@owner/sample", "--registry", "https://registry.example"])

    assert result.exit_code == 0
    assert observed["version"] == "1.2.0"
    assert result.output.strip().endswith("/@owner/sample/1.2.0")


def test_download_stdout_prints_yaml(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))
    monkeypatch.setattr(RegistryClient, "get_package", lambda self, scope, name: _native_package(scope, name))
    monkeypatch.setattr(
        RegistryClient,
        "list_versions",
        lambda self, scope, name, page=1, size=100: (
            [
                VersionInfo(
                    id="v100",
                    version="1.0.0",
                    status="published",
                    search_index_status="indexed",
                    file_size=1,
                    checksum_sha256="a" * 64,
                    model_summary=None,
                    created_at="2026-02-28T00:00:00Z",
                    published_at="2026-02-28T00:00:00Z",
                )
            ],
            {"page": 1, "size": 100, "total": 1},
        ),
    )
    monkeypatch.setattr(
        RegistryClient,
        "request_download",
        lambda self, *, scope, name, version: {"download_url": f"https://download.example/{scope}/{name}/{version}", "expires_in": 900},
    )
    monkeypatch.setattr(RegistryClient, "download_bytes", lambda self, download_url: _archive_bytes("1.0.0"))

    runner = CliRunner()
    result = runner.invoke(
        main,
        ["download", "@owner/sample", "models/sample.osi.yaml", "--stdout", "--registry", "https://registry.example"],
    )

    assert result.exit_code == 0
    assert 'version: "1.0"' in result.output
    assert "models/sample.osi.yaml" not in result.output


def test_download_blocks_indexed_package(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))

    monkeypatch.setattr(
        RegistryClient,
        "get_package",
        lambda self, scope, name: PackageDetail(
            id="pkg",
            scope=scope,
            name=name,
            description="Indexed sample",
            format="osi",
            source_format="metricflow",
            origin="indexed",
            origin_url="https://hub.getdbt.com/fivetran/shopify/latest/",
            origin_repo="fivetran/dbt_shopify",
            source="dbt-hub",
            domain=None,
            license=None,
            repository_url=None,
            readme=None,
            tags=[],
            is_private=False,
            download_count=0,
            star_count=0,
            owner=None,
        ),
    )

    runner = CliRunner()
    result = runner.invoke(main, ["snapshot-download", "@owner/sample", "--registry", "https://registry.example"])

    assert result.exit_code != 0
    assert "indexed from dbt Hub" in result.output


def test_snapshot_download_blocks_indexed_package_from_github(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))

    monkeypatch.setattr(
        RegistryClient,
        "get_package",
        lambda self, scope, name: PackageDetail(
            id="pkg",
            scope=scope,
            name=name,
            description="Indexed OSI sample",
            format="osi",
            source_format=None,
            origin="indexed",
            origin_url="https://github.com/open-semantic-interchange/OSI/tree/main",
            origin_repo="open-semantic-interchange/OSI",
            source="github",
            domain=None,
            license=None,
            repository_url=None,
            readme=None,
            tags=[],
            is_private=False,
            download_count=0,
            star_count=0,
            owner=None,
        ),
    )

    runner = CliRunner()
    result = runner.invoke(main, ["snapshot-download", "@github-hub/osi", "--registry", "https://registry.example"])

    assert result.exit_code != 0
    assert "indexed from GitHub" in result.output


def test_snapshot_download_handles_indexed_download_403(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))
    monkeypatch.setattr(RegistryClient, "get_package", lambda self, scope, name: _native_package(scope, name))

    versions = [
        VersionInfo(
            id="v100",
            version="0.1.0",
            status="published",
            search_index_status="indexed",
            file_size=1,
            checksum_sha256="a" * 64,
            model_summary=None,
            created_at="2026-03-02T00:00:00Z",
            published_at="2026-03-02T00:00:00Z",
        )
    ]
    monkeypatch.setattr(RegistryClient, "list_versions", lambda self, scope, name, page=1, size=100: (versions, {"page": 1, "size": 100, "total": 1}))

    def fake_request_download(self, *, scope: str, name: str, version: str):
        raise RegistryError(
            "Registry request failed (403)",
            status_code=403,
            payload={
                "error": "indexed_package",
                "message": "This package is indexed from dbt Hub. Download is not supported.",
                "origin_url": "https://hub.getdbt.com/dbt-labs/jaffle-shop/latest/",
                "claim_url": "https://hub.rawctx.dev/packages/@dbt-hub/jaffle-shop/claim",
            },
        )

    monkeypatch.setattr(RegistryClient, "request_download", fake_request_download)

    runner = CliRunner()
    result = runner.invoke(main, ["snapshot-download", "@owner/sample@0.1.0", "--registry", "https://registry.example"])

    assert result.exit_code != 0
    assert "indexed from dbt Hub" in result.output
    assert "https://hub.getdbt.com/dbt-labs/jaffle-shop/latest/" in result.output
    assert "https://hub.rawctx.dev/packages/@dbt-hub/jaffle-shop/claim" in result.output
