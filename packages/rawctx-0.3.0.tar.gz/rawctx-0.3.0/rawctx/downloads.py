from __future__ import annotations

from dataclasses import dataclass
from io import BytesIO
from pathlib import Path
import shutil
import tarfile
from typing import Any

from rawctx.config import cache_key, registry_cache_segment
from rawctx.errors import OfflineCacheMissError, RawctxError, UsageError
from rawctx.packaging.manifest import Manifest, ValidationError as ManifestValidationError, load_manifest
from rawctx.registry.models import choose_latest_version, is_valid_semver


@dataclass(frozen=True)
class SnapshotMaterialization:
    package: str
    version: str
    local_path: Path
    files: list[str]
    manifest: Manifest


@dataclass(frozen=True)
class FileMaterialization:
    package: str
    version: str
    path: str
    local_path: Path


def indexed_source_label(*, source: str | None, origin_url: str | None) -> str:
    source_norm = (source or "").strip().lower()
    if source_norm in {"github", "github-hub"}:
        return "GitHub"
    if source_norm in {"dbt", "dbt-hub", "dbt hub"}:
        return "dbt Hub"

    url = (origin_url or "").strip().lower()
    if "github.com" in url:
        return "GitHub"
    if "hub.getdbt.com" in url:
        return "dbt Hub"
    return "external source"


def indexed_blocked_message(
    *,
    package_name: str,
    source: str | None,
    origin_url: str | None,
    claim_hint: str | None = None,
) -> str:
    source_label = indexed_source_label(source=source, origin_url=origin_url)
    claim_line = claim_hint or f"rawctx claim {package_name}"
    return (
        f"This package is indexed from {source_label} and cannot be downloaded directly.\n"
        f"Source: {origin_url or '-'}\n"
        f"If you are the maintainer, claim it first: {claim_line}"
    )


def select_cached_version(
    cache: dict[str, dict[str, Any]],
    *,
    packages_root: Path,
    archives_root: Path,
    registry: str,
    scope: str,
    name: str,
    preferred_version: str | None,
) -> str:
    if preferred_version:
        return preferred_version

    candidates: list[str] = []
    entry = cache.get(cache_key(scope, name, registry), {})
    versions = entry.get("versions")
    if isinstance(versions, list):
        for item in versions:
            if isinstance(item, dict):
                candidate = item.get("version")
                if isinstance(candidate, str) and is_valid_semver(candidate):
                    candidates.append(candidate)

    archive_dir = archives_root / registry_cache_segment(registry) / f"@{scope}" / name
    if archive_dir.exists():
        for file_path in archive_dir.glob("*.rawctx.tar.gz"):
            candidate = file_path.name.removesuffix(".rawctx.tar.gz")
            if is_valid_semver(candidate):
                candidates.append(candidate)

    package_dir = packages_root / registry_cache_segment(registry) / f"@{scope}" / name
    if package_dir.exists():
        for child in package_dir.iterdir():
            if child.is_dir() and is_valid_semver(child.name) and snapshot_exists(child):
                candidates.append(child.name)

    selected = choose_latest_version(candidates)
    if not selected:
        raise OfflineCacheMissError(f"No cached versions found for @{scope}/{name}")
    return selected


def snapshot_exists(path: Path) -> bool:
    return (path / "rawctx.yaml").is_file()


def load_snapshot_manifest(snapshot_dir: Path) -> Manifest:
    manifest_path = snapshot_dir / "rawctx.yaml"
    if not manifest_path.is_file():
        raise RawctxError(f"Snapshot is incomplete: missing {manifest_path}")
    try:
        return load_manifest(manifest_path)
    except ManifestValidationError as exc:
        raise RawctxError(str(exc)) from exc


def snapshot_matches(snapshot_dir: Path, *, package_name: str, version: str) -> bool:
    if not snapshot_exists(snapshot_dir):
        return False
    try:
        manifest = load_snapshot_manifest(snapshot_dir)
    except RawctxError:
        return False
    return manifest.name == package_name and manifest.version == version


def extract_archive(*, archive_bytes: bytes, target_dir: Path) -> None:
    target_resolved = target_dir.resolve()
    target_dir.mkdir(parents=True, exist_ok=True)
    try:
        with tarfile.open(fileobj=BytesIO(archive_bytes), mode="r:gz") as tar:
            for member in tar.getmembers():
                if not member.name.startswith("package/"):
                    continue
                if member.issym() or member.islnk():
                    raise RawctxError(f"Unsafe archive entry: {member.name}")
                relative = Path(member.name).relative_to("package")
                if not relative.parts:
                    continue

                destination = (target_dir / relative).resolve()
                if destination != target_resolved and target_resolved not in destination.parents:
                    raise RawctxError(f"Unsafe archive entry: {member.name}")

                if member.isdir():
                    destination.mkdir(parents=True, exist_ok=True)
                    continue

                destination.parent.mkdir(parents=True, exist_ok=True)
                extracted = tar.extractfile(member)
                if extracted is None:
                    continue
                destination.write_bytes(extracted.read())
    except tarfile.TarError as exc:
        raise RawctxError(f"Invalid package archive: {exc}") from exc


def ensure_clean_dir(path: Path) -> None:
    if path.is_dir():
        shutil.rmtree(path)
    elif path.exists():
        path.unlink()
    path.mkdir(parents=True, exist_ok=True)


def copy_snapshot(*, source_dir: Path, target_dir: Path, force: bool) -> None:
    source_resolved = source_dir.resolve()
    target_resolved = target_dir.resolve()
    if source_resolved == target_resolved:
        return

    if target_dir.exists():
        if not force:
            raise RawctxError(f"Snapshot target already exists: {target_dir}")
        if target_dir.is_dir():
            shutil.rmtree(target_dir)
        else:
            target_dir.unlink()

    target_dir.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(source_dir, target_dir)


def validate_model_path(manifest: Manifest, model_path: str) -> str:
    normalized = model_path.strip()
    if not normalized:
        raise UsageError("MODEL_PATH is required")
    if normalized not in manifest.models:
        raise UsageError(f"MODEL_PATH must match a manifest entry exactly: {normalized}")
    return normalized


def copy_model_file(*, source_root: Path, model_path: str, local_dir: Path, force: bool) -> Path:
    source = (source_root / model_path).resolve()
    root = source_root.resolve()
    if source != root and root not in source.parents:
        raise RawctxError(f"Model path escapes snapshot: {model_path}")
    if not source.is_file():
        raise RawctxError(f"Model file declared in manifest is missing: {model_path}")

    target = (local_dir / model_path).resolve()
    local_root = local_dir.resolve()
    if target != local_root and local_root not in target.parents:
        raise RawctxError(f"Unsafe destination for MODEL_PATH: {model_path}")

    if target.exists():
        if not force:
            return target
        if target.is_dir():
            shutil.rmtree(target)
        else:
            target.unlink()

    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    return target
