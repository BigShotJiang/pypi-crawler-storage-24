from __future__ import annotations

import click

from rawctx.commands.common import echo_json, raise_click_for_error
from rawctx.sdk import _serialize_snapshot_materialization
from rawctx.sdk import client as rawctx_client


@click.command()
@click.argument("package_ref", required=True)
@click.option("--local-dir", default=None, help="Destination directory for the extracted snapshot")
@click.option("--offline", is_flag=True, default=False)
@click.option("--force", is_flag=True, default=False)
@click.option("--json", "json_output", is_flag=True, default=False)
@click.option("--registry", "registry_override", default=None, help="Registry base URL")
def snapshot_download(
    package_ref: str,
    local_dir: str | None,
    offline: bool,
    force: bool,
    json_output: bool,
    registry_override: str | None,
) -> None:
    """Download the full package snapshot. [user]"""

    try:
        with rawctx_client(registry=registry_override) as sdk_client:
            result = sdk_client._snapshot_download_materialized(
                package_ref,
                local_dir=local_dir,
                offline=offline,
                force=force,
            )
    except Exception as exc:
        raise_click_for_error(exc)
        return

    if json_output:
        echo_json(_serialize_snapshot_materialization(result))
        return

    click.echo(str(result.local_path))
