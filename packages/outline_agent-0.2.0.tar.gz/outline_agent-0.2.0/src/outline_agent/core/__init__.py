"""Core configuration and logging."""
