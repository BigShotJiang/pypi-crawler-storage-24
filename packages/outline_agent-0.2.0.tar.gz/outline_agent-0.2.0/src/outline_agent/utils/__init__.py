"""Small shared helpers."""
