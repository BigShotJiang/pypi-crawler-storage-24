AURA: Automated Updater and Restoration Agent
aura-dep-agent is a Python tool that helps you safely modernize your project’s
dependencies. It can also be used to maintain your dependencies in the long run and does not probe or open a PR like Dependabot; it only commits changes when the update passes your validation tests.

You give it a repository and a validation entry point (a Python script or a pytest
suite). AURA then searches for newer dependency versions that still pass your validation.
If an update breaks your validation, AURA does not submit that change.

Installation:
    pip install aura-dep-agent
    This installs the aura command-line tool.

Quick start:
    Go to your project repo
    cd /path/to/your-project

Make sure you have:

    a requirements.txt file

either:

    a Python script you can run with python your_script.py, or

    a pytest test suite (for example, a tests/ folder)

Run the AURA initializer:

    aura init
    The wizard will:

        detect whether your project is an installable package or not

        ask how to run your validation (script path or pytest target)

        ask which Python version to use in CI

        generate:

            dependency_agent.py in your repo

            .github/workflows/aura.yml GitHub Actions workflow

Commit and push:

    git add dependency_agent.py .github/workflows/aura.yml
    git commit -m "Add AURA dependency agent"
    git push
    Run AURA in GitHub Actions

In your GitHub repo, go to the Actions tab.

Find the “AURA Speed Run” workflow.

Click “Run workflow” to start your first run.

AURA will run your validation as it explores dependency updates and only keep
an update when your validation still passes.

How it works (high level):
    dependency_agent.py contains a configuration dictionary (AGENT_CONFIG) for your
    repository and a small runner that calls the AURA dependency agent.

The GitHub Actions workflow:

    sets up Python

    installs aura-dep-agent

    runs dependency_agent.py    

The AURA agent:

    proposes candidate dependency upgrades

    runs your validation for each candidate

    writes a summary log (for example, aura_ua_execution.log)

    can commit and push a modernized requirements.txt when validation passes.

Requirements and limitations:

    Requires Python 3.10+ (3.10 or 3.11 recommended).

    Requires a working requirements.txt.

    Requires an existing validation entry point (script or pytest); AURA does not
    automatically generate full test suites.

License:
    This project is licensed under the MIT License.