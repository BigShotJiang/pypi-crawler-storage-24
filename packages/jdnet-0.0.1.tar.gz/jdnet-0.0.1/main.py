def main():
    print("Hello from jdnet!")


if __name__ == "__main__":
    main()
