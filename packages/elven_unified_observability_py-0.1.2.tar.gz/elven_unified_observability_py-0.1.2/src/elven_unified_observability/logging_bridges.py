from __future__ import annotations

import importlib
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, cast

from .config import UnifiedObservabilityConfig, normalize_data, parse_bool

SUPPORTED_LOGGING_INTEGRATIONS = ("loguru", "structlog")


@dataclass(frozen=True)
class RequestedLoggingIntegration:
    name: str
    explicit: bool


def install_logging_integrations(
    config: UnifiedObservabilityConfig,
    logger_instance: Any,
    *,
    warn: Callable[[str], None],
) -> list[Callable[[], None]]:
    uninstallers: list[Callable[[], None]] = []
    for request in resolve_requested_logging_integrations(config):
        installer = _INSTALLERS.get(request.name)
        if installer is None:
            continue
        try:
            uninstaller = installer(config, logger_instance)
        except ModuleNotFoundError:
            if request.explicit:
                warn(
                    "Logging bridge "
                    f"'{request.name}' was requested but its dependency is not installed."
                )
            continue
        except Exception as exc:
            warn(f"Logging bridge '{request.name}' installation failed: {exc}")
            continue
        if uninstaller is not None:
            uninstallers.append(uninstaller)
    return uninstallers


def uninstall_logging_integrations(uninstallers: list[Callable[[], None]]) -> None:
    for uninstall in reversed(uninstallers):
        try:
            uninstall()
        except Exception:
            continue


def resolve_requested_logging_integrations(
    config: UnifiedObservabilityConfig,
) -> list[RequestedLoggingIntegration]:
    integrations = _normalized_integrations_config(config)
    if not integrations:
        return []

    requested: dict[str, RequestedLoggingIntegration] = {}
    raw_values = integrations.get("auto_install")
    names = raw_values if isinstance(raw_values, list) else []
    normalized_names = {
        str(item).strip().lower()
        for item in names
        if isinstance(item, str) and str(item).strip()
    }

    if "none" in normalized_names:
        normalized_names.clear()
    if "auto" in normalized_names:
        for name in SUPPORTED_LOGGING_INTEGRATIONS:
            requested[name] = RequestedLoggingIntegration(name=name, explicit=False)
    for name in SUPPORTED_LOGGING_INTEGRATIONS:
        if name in normalized_names:
            requested[name] = RequestedLoggingIntegration(name=name, explicit=True)

    for name in SUPPORTED_LOGGING_INTEGRATIONS:
        raw_config = integrations.get(name)
        integration_config = raw_config if isinstance(raw_config, dict) else {}
        enabled = parse_bool(integration_config.get("enabled"))
        if enabled is True:
            requested[name] = RequestedLoggingIntegration(name=name, explicit=True)
        elif enabled is False:
            requested.pop(name, None)

    return [requested[name] for name in SUPPORTED_LOGGING_INTEGRATIONS if name in requested]


def _normalized_integrations_config(config: UnifiedObservabilityConfig) -> dict[str, Any]:
    normalized = normalize_data(config.logging_integrations or {})
    return normalized if isinstance(normalized, dict) else {}


def _install_loguru_bridge(
    config: UnifiedObservabilityConfig,
    logger_instance: Any,
) -> Callable[[], None] | None:
    integrations = _normalized_integrations_config(config)
    loguru_config = integrations.get("loguru")
    options = loguru_config if isinstance(loguru_config, dict) else {}

    loguru_module = importlib.import_module("loguru")
    integrations_module = importlib.import_module("logs_interceptor.integrations")

    sink = integrations_module.LoguruSink(logger_instance)
    sink_id = loguru_module.logger.add(
        sink,
        level=str(options.get("level", "DEBUG")),
        enqueue=True if options.get("enqueue") is None else bool(options["enqueue"]),
        backtrace=False if options.get("backtrace") is None else bool(options["backtrace"]),
        diagnose=False if options.get("diagnose") is None else bool(options["diagnose"]),
    )

    def uninstall() -> None:
        try:
            loguru_module.logger.remove(sink_id)
        except Exception:
            pass

    return uninstall


def _install_structlog_bridge(
    _config: UnifiedObservabilityConfig,
    logger_instance: Any,
) -> Callable[[], None] | None:
    structlog_module = cast(Any, importlib.import_module("structlog"))
    integrations_module = importlib.import_module("logs_interceptor.integrations")

    original_configure = structlog_module.configure
    original_configure_once = getattr(structlog_module, "configure_once", None)
    processor = integrations_module.StructlogProcessor(logger_instance)

    def ensure_processors(processors: Any) -> list[Any]:
        current = list(processors) if isinstance(processors, list) else []
        if any(_is_structlog_processor(item) for item in current):
            return current
        return [processor, *current]

    def apply_config(processors: list[Any] | None = None) -> None:
        current = _get_structlog_config(structlog_module)
        resolved_processors = current.get("processors") if processors is None else processors
        structlog_module.configure(
            processors=ensure_processors(resolved_processors),
            wrapper_class=current.get("wrapper_class"),
            context_class=current.get("context_class"),
            logger_factory=current.get("logger_factory"),
            cache_logger_on_first_use=current.get("cache_logger_on_first_use"),
        )

    def configure_proxy(*args: Any, **kwargs: Any) -> Any:
        current = _get_structlog_config(structlog_module)
        forwarded = dict(kwargs)
        forwarded["processors"] = ensure_processors(
            forwarded.get("processors", current.get("processors"))
        )
        return original_configure(*args, **forwarded)

    def configure_once_proxy(*args: Any, **kwargs: Any) -> Any:
        if original_configure_once is None:
            return None
        current = _get_structlog_config(structlog_module)
        forwarded = dict(kwargs)
        forwarded["processors"] = ensure_processors(
            forwarded.get("processors", current.get("processors"))
        )
        return original_configure_once(*args, **forwarded)

    apply_config()
    structlog_module.configure = configure_proxy
    if callable(original_configure_once):
        structlog_module.configure_once = configure_once_proxy

    def uninstall() -> None:
        try:
            structlog_module.configure = original_configure
            if callable(original_configure_once):
                structlog_module.configure_once = original_configure_once
            current = _get_structlog_config(structlog_module)
            processors = [
                item
                for item in list(current.get("processors", []))
                if not _is_structlog_processor(item)
            ]
            structlog_module.configure(
                processors=processors,
                wrapper_class=current.get("wrapper_class"),
                context_class=current.get("context_class"),
                logger_factory=current.get("logger_factory"),
                cache_logger_on_first_use=current.get("cache_logger_on_first_use"),
            )
        except Exception:
            pass

    return uninstall


def _get_structlog_config(structlog_module: Any) -> dict[str, Any]:
    getter = getattr(structlog_module, "get_config", None)
    if not callable(getter):
        return {}
    current = getter()
    return current if isinstance(current, dict) else {}


def _is_structlog_processor(value: Any) -> bool:
    return (
        value.__class__.__name__ == "StructlogProcessor"
        and value.__class__.__module__ == "logs_interceptor.integrations.structlog"
    )


_INSTALLERS: dict[str, Callable[[UnifiedObservabilityConfig, Any], Callable[[], None] | None]] = {
    "loguru": _install_loguru_bridge,
    "structlog": _install_structlog_bridge,
}
