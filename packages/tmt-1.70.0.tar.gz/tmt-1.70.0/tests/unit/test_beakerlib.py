import shutil
from unittest.mock import MagicMock

import pytest

import tmt.base.core
import tmt.libraries.beakerlib
import tmt.utils.git
from tmt.utils import Path


@pytest.mark.web
def test_basic(root_logger, tmppath):
    """
    Fetch a beakerlib library with/without providing a parent
    """

    parent = tmt.utils.Common(logger=root_logger, workdir=tmppath)
    library_with_parent = tmt.libraries.Library.from_identifier(
        logger=root_logger,
        identifier=tmt.base.core.DependencySimple('library(openssl/certgen)'),
        parent=parent,
    )
    library_without_parent = tmt.libraries.Library.from_identifier(
        logger=root_logger, identifier=tmt.base.core.DependencySimple('library(openssl/certgen)')
    )

    for library in [library_with_parent, library_without_parent]:
        assert library.format == 'rpm'
        assert library.repo == Path('openssl')
        assert library.url == 'https://github.com/beakerlib/openssl'
        assert library.ref == 'master'  # The default branch is master
        assert (
            library.dest.resolve()
            == Path.cwd().joinpath(tmt.libraries.beakerlib.DEFAULT_DESTINATION).resolve()
        )
        shutil.rmtree(library.parent.workdir)


@pytest.mark.web
@pytest.mark.parametrize(
    ('url', 'name', 'default_branch'),
    [
        ('https://github.com/beakerlib/httpd', '/http', 'master'),
        ('https://github.com/beakerlib/example', '/file', 'main'),
    ],
)
def test_require_from_fmf(url, name, default_branch, root_logger):
    """
    Fetch beakerlib library referenced by fmf identifier
    """

    library = tmt.libraries.Library.from_identifier(
        logger=root_logger, identifier=tmt.base.core.DependencyFmfId(url=url, name=name)
    )
    assert library.format == 'fmf'
    assert library.ref == default_branch
    assert library.url == url
    assert (
        library.dest.resolve()
        == Path.cwd().joinpath(tmt.libraries.beakerlib.DEFAULT_DESTINATION).resolve()
    )
    assert library.repo == Path(url.split('/')[-1])
    assert library.name == name
    shutil.rmtree(library.parent.workdir)


@pytest.mark.web
def test_invalid_url_conflict(root_logger, tmppath):
    """
    Saner check if url mismatched for translated library
    """

    parent = tmt.utils.Common(logger=root_logger, workdir=tmppath)
    # Fetch to cache 'tmt' repo
    tmt.libraries.Library.from_identifier(
        logger=root_logger,
        identifier=tmt.base.core.DependencyFmfId(
            url='https://github.com/teemtee/tmt',
            name='/',
            path=Path('/tests/libraries/local/data'),
        ),
        parent=parent,
    )
    # Library 'tmt' repo is already fetched from different git,
    # however upstream (gh.com/beakerlib/tmt) repo does not exist,
    # so there can't be "already fetched" error
    with pytest.raises(tmt.libraries.LibraryError):
        tmt.libraries.Library.from_identifier(
            logger=root_logger, identifier='library(tmt/foo)', parent=parent
        )


@pytest.mark.web
def test_dependencies(root_logger, tmppath):
    """
    Check requires for possible libraries
    """

    parent = tmt.utils.Common(logger=root_logger, workdir=tmppath)
    requires, recommends = tmt.libraries.resolve_dependencies(
        original_require=[
            tmt.base.core.DependencySimple('library(httpd/http)'),
            tmt.base.core.DependencySimple('wget'),
        ],
        original_recommend=[tmt.base.core.DependencySimple('forest')],
        parent=parent,
        logger=root_logger,
    )
    # Check for correct requires and recommends
    for require in ['httpd', 'lsof', 'mod_ssl']:
        assert require in requires
    assert 'forest' in recommends
    assert 'wget' in requires
    # Library require should be in httpd requires but not in the final result
    assert 'library(openssl/certgen)' not in requires
    # TODO: assert the libraries that were resolved


@pytest.mark.web
def test_mark_nonexistent_url(root_logger, monkeypatch, tmppath):
    """
    Check url existence just one time
    """

    non_existent_url = 'https://github.com/beakerlib/THISDOESNTEXIST'
    parent = tmt.utils.Common(logger=root_logger, workdir=tmppath)
    identifier = tmt.base.core.DependencyFmfId(
        url=non_existent_url,
        name='/',
    )
    with pytest.raises(tmt.utils.GeneralError):
        tmt.libraries.beakerlib.BeakerLibFromUrl.from_identifier(
            logger=root_logger, identifier=identifier, parent=parent
        ).fetch()
    # Second time there shouldn't be an attempt to clone...
    assert non_existent_url in tmt.utils.git.NON_EXISTING_GIT_URL
    # TODO: Try to narrow to check for the git clone specifically
    monkeypatch.setattr(
        "tmt.utils.Command.run", MagicMock(side_effect=RuntimeError('Should not be called'))
    )
    with pytest.raises(tmt.utils.GeneralError):
        tmt.libraries.beakerlib.BeakerLibFromUrl.from_identifier(
            logger=root_logger, identifier=identifier, parent=parent
        ).fetch()
    shutil.rmtree(parent.workdir)
