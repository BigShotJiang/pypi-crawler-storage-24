"""cc_cortex.boundary_guard — Library/application boundary enforcement.

Detects two anti-patterns in PreToolUse Write/Edit:

1. **App bloat**: Writing to a hook/wrapper directory with >N lines of business
   logic (non-stdin/stdout/import) → warn "should be a library module"
2. **Library pollution**: Writing to a library directory with hardcoded personal
   paths or non-portable patterns → warn "should be app-layer config"

This guard is generic: any cc-cortex user benefits from keeping their hooks thin
and their library code portable.

Usage:
    from cc_cortex.boundary_guard import check_boundary
    warning = check_boundary(tool_name, tool_input, config)

Config keys (in cc_config.json under "boundary_guard"):
    hook_dirs: list of directory patterns that are "app layer" (default: [".claude/hooks"])
    library_dirs: list of directory patterns that are "library layer"
    max_hook_logic_lines: int threshold (default: 30)
    personal_patterns: list of regex patterns considered personal/non-portable
"""

from __future__ import annotations

import re
from typing import Optional

# ── Defaults ────────────────────────────────────────────────────

_DEFAULT_HOOK_DIRS = [".claude/hooks", ".claude\\hooks"]
_DEFAULT_LIBRARY_DIRS = ["cc_cortex", "src/cc_cortex"]
_DEFAULT_MAX_HOOK_LINES = 30
_DEFAULT_PERSONAL_PATTERNS = [
    r"[A-Z]:\\Users\\",        # Windows absolute user paths
    r"/home/\w+/",             # Linux home dirs
    r"_AI_BRAIN",              # CC-specific brain dir
    r"hardcoded",              # Literally "hardcoded"
]

# Lines that are "thin wrapper" boilerplate (don't count as business logic)
_BOILERPLATE_RE = re.compile(
    r"^\s*(?:"
    r"import\s|from\s|#|$"                    # imports, comments, blank
    r'|\s*"""|\s*\'\'\'|"""'                   # docstrings
    r"|if\s+__name__"                          # main guard
    r"|sys\.std(?:in|out|err)"                 # stdin/stdout/stderr
    r"|json\.(?:loads|dumps|dump|load)"        # JSON parsing
    r"|hook_data|tool_name|tool_input"         # standard hook vars
    r"|return|pass|raise|except|try|finally"   # control flow
    r"|def\s+main|def\s+_run"                 # entry points
    r"|os\.environ"                            # env vars
    r")"
)


# ── Core check ──────────────────────────────────────────────────


def _get_config() -> dict:
    """Load boundary_guard config from Config singleton."""
    try:
        from cc_cortex.core.config import get_config
        return get_config().raw("boundary_guard", {})
    except Exception:
        return {}


def _normalize(path: str) -> str:
    """Normalize path for comparison."""
    return path.replace("\\", "/").lower()


def _is_in_dirs(file_path: str, dir_patterns: list[str]) -> bool:
    """Check if file_path is within any of the given directory patterns."""
    norm = _normalize(file_path)
    for d in dir_patterns:
        if _normalize(d) in norm:
            return True
    return False


def _count_logic_lines(content: str) -> int:
    """Count non-boilerplate lines in content."""
    count = 0
    for line in content.splitlines():
        if line.strip() and not _BOILERPLATE_RE.match(line):
            count += 1
    return count


def check_boundary(
    tool_name: str,
    tool_input: dict,
    config: dict | None = None,
) -> Optional[str]:
    """Check for boundary violations.

    Args:
        tool_name: "Write" or "Edit"
        tool_input: Tool input dict with file_path and content/new_string
        config: Optional override for boundary_guard config

    Returns:
        Warning string if violation detected, None otherwise.
    """
    if tool_name not in ("Write", "Edit"):
        return None

    file_path = tool_input.get("file_path", "") or ""
    if not file_path:
        return None

    cfg = config if config is not None else _get_config()
    hook_dirs = cfg.get("hook_dirs", _DEFAULT_HOOK_DIRS)
    library_dirs = cfg.get("library_dirs", _DEFAULT_LIBRARY_DIRS)
    max_lines = cfg.get("max_hook_logic_lines", _DEFAULT_MAX_HOOK_LINES)
    personal_pats = cfg.get("personal_patterns", _DEFAULT_PERSONAL_PATTERNS)

    # Check 1: App bloat — writing a big file in hook directory
    if _is_in_dirs(file_path, hook_dirs):
        content = tool_input.get("content", "") or tool_input.get("new_string", "") or ""
        if content:
            logic = _count_logic_lines(content)
            if logic > max_lines:
                return (
                    f"⚠ [BoundaryGuard] Hook file has {logic} logic lines "
                    f"(threshold: {max_lines}). Consider extracting business "
                    f"logic into a cc_cortex module."
                )

    # Check 2: Library pollution — personal paths in library code
    if _is_in_dirs(file_path, library_dirs):
        content = tool_input.get("content", "") or tool_input.get("new_string", "") or ""
        if content:
            for pat in personal_pats:
                m = re.search(pat, content, re.IGNORECASE)
                if m:
                    return (
                        f"⚠ [BoundaryGuard] Library code contains personal/non-portable "
                        f"pattern: '{m.group()[:40]}'. Move to app-layer config."
                    )

    return None
