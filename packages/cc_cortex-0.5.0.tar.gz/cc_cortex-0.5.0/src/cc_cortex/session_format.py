"""
cc_cortex.session_format — Session ID format enforcement + task-pool ABCD validation.

Validates that:
1. Session IDs in handoff/task-pool files match the expected format
2. ABCD parallel dispatch in handoff files requires a task-pool.md in the same directory

Usage:
    from cc_cortex.session_format import check_session_id, check_taskpool_required
    error = check_session_id(tool_name, tool_input, prefixes, handoff_prefixes)
    error = check_taskpool_required(tool_name, tool_input, handoff_prefixes)
"""

import os
import re
from typing import Optional

# Tools that modify files
WRITE_TOOLS = frozenset(["Write", "Edit", "NotebookEdit"])

# Files that need session ID checking
SESSION_CHECK_BASENAMES = frozenset([
    "task-pool.md", "L0-signals.md", "L1-findings.md",
])


def _build_session_patterns(prefixes: str):
    """Build strict and loose session ID patterns from prefix string."""
    strict = re.compile(rf"(?:{prefixes})_[a-f0-9]{{4}}_\d{{4}}")
    loose = re.compile(rf"(?:{prefixes})_[A-Za-z0-9_]+")
    return strict, loose


def _build_abcd_pattern():
    """Build ABCD dispatch detection pattern."""
    return re.compile(
        r'母[A-D]|Phase-[A-D]|角色[A-D]|\b[A-D]\s*（|'
        r'四母代理|ABCD\s*分|分成\s*ABCD|'
        r'\[A\d?\].*\[B\d?\]|\[C\d?\].*\[D\d?\]',
        re.IGNORECASE,
    )


# Pre-compiled ABCD pattern
_ABCD_PATTERN = _build_abcd_pattern()


def check_session_id(
    tool_name: str,
    tool_input: dict,
    prefixes: str = "CC|IA|PS|TR|BK|EV|AQ|SC|TK|GN",
    handoff_prefixes: tuple = (),
    check_basenames: frozenset = SESSION_CHECK_BASENAMES,
) -> Optional[str]:
    """Check if session IDs in written content match the expected format.

    Returns error message string if invalid, None if OK.
    """
    if tool_name not in WRITE_TOOLS:
        return None
    if not isinstance(tool_input, dict):
        return None

    file_path = (
        tool_input.get("file_path")
        or tool_input.get("path")
        or tool_input.get("notebook_path")
        or ""
    )
    basename = os.path.basename(file_path)

    needs_check = (
        basename in check_basenames
        or any(basename.startswith(p) for p in handoff_prefixes)
    )
    if not needs_check:
        return None

    # Get content being written
    if tool_name == "Edit":
        content = tool_input.get("new_string", "")
    elif tool_name == "Write":
        content = tool_input.get("content", "")
    else:
        return None

    if not content:
        return None

    strict, loose = _build_session_patterns(prefixes)

    all_matches = loose.findall(content)
    if not all_matches:
        return None

    bad = [m for m in all_matches if not strict.fullmatch(m)]
    if not bad:
        return None

    bad_list = ", ".join(set(bad))
    return (
        f"⛔ SESSION ID 格式錯誤：{bad_list}\n"
        f"正確格式：<專案前綴>_<4位hex>_<HHmm>（如 IA_a3f1_0835、PS_d9e4_2215）\n"
        f"前綴表：{prefixes}\n"
        "根據你正在操作的專案選擇前綴，hex4 隨機生成，HHmm 為當前時間。"
    )


def check_taskpool_required(
    tool_name: str,
    tool_input: dict,
    handoff_prefixes: tuple = (),
) -> Optional[str]:
    """Check if ABCD dispatch in handoff files has a corresponding task-pool.md.

    Returns error message string if task-pool is missing, None if OK.
    """
    if tool_name not in WRITE_TOOLS:
        return None
    if not isinstance(tool_input, dict):
        return None

    file_path = tool_input.get("file_path") or tool_input.get("path") or ""
    basename = os.path.basename(file_path)

    # Only check handoff files (not task-pool itself)
    if not any(basename.startswith(p) for p in handoff_prefixes):
        return None
    if basename == "task-pool.md":
        return None

    # Get content being written
    if tool_name == "Edit":
        content = tool_input.get("new_string", "")
    elif tool_name == "Write":
        content = tool_input.get("content", "")
    else:
        return None

    if not content:
        return None

    # Check for ABCD dispatch pattern
    if not _ABCD_PATTERN.search(content):
        return None

    # ABCD pattern found — check for task-pool.md in same directory
    parent_dir = os.path.dirname(file_path)
    if not parent_dir:
        return None

    taskpool_path = os.path.join(parent_dir, "task-pool.md")
    if os.path.isfile(taskpool_path):
        return None

    return (
        f"⛔ 交接檔含 ABCD 分派但同目錄無 task-pool.md\n"
        f"檔案：{basename}\n"
        f"缺少：{taskpool_path}\n"
        "必須先建 task-pool.md（含依賴圖+角色分工+子任務），再寫 ABCD 分派到交接檔。"
    )
