"""
cc_cortex.cognitive — Cognitive layer for Claude Code.

Makes Claude Code genuinely smarter across sessions by learning patterns,
adapting thresholds, and tracking decision quality.

Four components:
1. SessionProfile — Classify session type, track work patterns, file domains
2. DecisionJournal — Record AI decisions + outcomes for self-improvement
3. AdaptiveThresholds — Adjust sentinel/guard thresholds from learned patterns
4. CognitiveEngine — Orchestrator that integrates sentinel, knowledge, evolution

Integration points (CC → CCF, not reverse):
- AdaptiveThresholds → sentinel: feed learned thresholds into sentinel checks
- knowledge corrections → DecisionJournal: corrections become decision outcomes
- SessionProfile → evolution: session type informs tidy thresholds

Persistence: ~/.claude/cognitive/ (JSON files, one per component)
"""

from __future__ import annotations

import hashlib
import json
import os
import time
from datetime import datetime, timezone
from typing import Optional

# ── Constants ──────────────────────────────────────────────

COGNITIVE_DIR_NAME = "cognitive"
PROFILE_FILE = "session_profiles.json"
JOURNAL_FILE = "decision_journal.json"
THRESHOLDS_FILE = "adaptive_thresholds.json"

# Session type classification
SESSION_TYPES = {
    "bugfix": {"signals": ["fix", "bug", "error", "broken", "fail", "issue", "debug"]},
    "feature": {"signals": ["add", "new", "create", "implement", "build", "feature"]},
    "refactor": {"signals": ["refactor", "clean", "rename", "move", "extract", "simplify"]},
    "review": {"signals": ["review", "check", "audit", "inspect", "look", "read"]},
    "config": {"signals": ["config", "setup", "install", "deploy", "ci", "env"]},
    "docs": {"signals": ["doc", "readme", "comment", "explain", "describe"]},
    "test": {"signals": ["test", "spec", "coverage", "assert", "mock"]},
}

# File domain classification (first path component → domain)
FILE_DOMAINS = {
    "src": "source",
    "lib": "source",
    "app": "source",
    "test": "test",
    "tests": "test",
    "spec": "test",
    "docs": "docs",
    "config": "config",
    ".github": "ci",
    ".claude": "ai-config",
    "scripts": "tooling",
}

# Default adaptive thresholds (sentinel/guard baselines)
DEFAULT_THRESHOLDS = {
    "sentinel_repeat": 3,
    "sentinel_paralysis": 7,
    "sentinel_scope": 10,
    "sentinel_drift": 4,
    "sentinel_diminish": 3,
    "tidy_md_lines": 8,
    "tidy_code_lines": 40,
    "destruction_confirm_level": 2,  # R2+ requires confirmation
}

# Threshold adjustment bounds (min, max) to prevent runaway adaptation
THRESHOLD_BOUNDS = {
    "sentinel_repeat": (2, 8),
    "sentinel_paralysis": (4, 15),
    "sentinel_scope": (5, 25),
    "sentinel_drift": (2, 8),
    "sentinel_diminish": (2, 6),
    "tidy_md_lines": (4, 20),
    "tidy_code_lines": (15, 80),
    "destruction_confirm_level": (1, 4),
}

WRITE_TOOLS = frozenset(["Edit", "Write", "NotebookEdit"])
READ_TOOLS = frozenset(["Read", "Grep", "Glob", "WebSearch", "WebFetch"])
MAX_PROFILES = 200
MAX_JOURNAL_ENTRIES = 500


# ── Helpers ────────────────────────────────────────────────


def _cognitive_dir(base_dir: Optional[str] = None) -> str:
    """Get cognitive data directory."""
    if base_dir:
        return base_dir
    return os.path.join(os.path.expanduser("~"), ".claude", COGNITIVE_DIR_NAME)


def _read_json(path: str) -> dict:
    """Read JSON file, return empty dict on failure."""
    try:
        if os.path.isfile(path):
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return {}


def _write_json(path: str, data: dict) -> bool:
    """Write JSON file atomically."""
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        os.replace(tmp, path)
        return True
    except Exception:
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            return True
        except Exception:
            return False


def _classify_file_domain(file_path: str) -> str:
    """Classify a file path into a domain category."""
    if not file_path:
        return "unknown"
    normalized = file_path.replace("\\", "/").lstrip("/")
    parts = normalized.split("/")
    for part in parts[:3]:  # Check first 3 path components
        low = part.lower()
        if low in FILE_DOMAINS:
            return FILE_DOMAINS[low]
    # Fallback: extension-based
    low_path = file_path.lower()
    ext_map = {
        ".md": "docs",
        ".json": "config",
        ".yaml": "config",
        ".yml": "config",
        ".toml": "config",
        ".ini": "config",
        ".env": "config",
        ".test.ts": "test",
        ".test.js": "test",
        ".spec.ts": "test",
    }
    for suffix, domain in ext_map.items():
        if low_path.endswith(suffix):
            return domain
    return "source"


# ── SessionProfile ─────────────────────────────────────────


class SessionProfile:
    """Tracks and classifies session work patterns.

    Builds a profile of each session: what type of work, which file domains,
    read/write ratio, tool distribution. Used to adapt thresholds and
    detect anomalies.
    """

    def __init__(self, session_id: str, base_dir: Optional[str] = None):
        self.session_id = session_id
        self.short_id = session_id[:8] if session_id else "unknown"
        self._dir = _cognitive_dir(base_dir)
        self.start_time = time.time()
        self.tool_counts: dict[str, int] = {}
        self.file_domains: dict[str, int] = {}
        self.files_touched: set[str] = set()
        self.session_type: str = "unknown"
        self.user_messages: list[str] = []

    def record_tool(self, tool_name: str, tool_input: dict) -> None:
        """Record a tool invocation."""
        self.tool_counts[tool_name] = self.tool_counts.get(tool_name, 0) + 1

        file_path = ""
        if isinstance(tool_input, dict):
            file_path = (
                tool_input.get("file_path")
                or tool_input.get("path")
                or tool_input.get("notebook_path")
                or ""
            )

        if file_path:
            self.files_touched.add(file_path)
            domain = _classify_file_domain(file_path)
            self.file_domains[domain] = self.file_domains.get(domain, 0) + 1

    def record_user_message(self, text: str) -> None:
        """Record a user message for session type classification."""
        if text and len(text) < 1000:
            self.user_messages.append(text[:200])

    def classify(self) -> str:
        """Classify the session type based on accumulated signals."""
        if not self.user_messages:
            self.session_type = "unknown"
            return self.session_type

        combined = " ".join(self.user_messages).lower()
        scores: dict[str, int] = {}

        for stype, info in SESSION_TYPES.items():
            score = sum(1 for sig in info["signals"] if sig in combined)
            if score > 0:
                scores[stype] = score

        if scores:
            self.session_type = max(scores, key=scores.get)  # type: ignore[arg-type]
        else:
            self.session_type = "general"
        return self.session_type

    @property
    def read_write_ratio(self) -> float:
        """Calculate read/write tool ratio. >1 means more reading."""
        reads = sum(self.tool_counts.get(t, 0) for t in READ_TOOLS)
        writes = sum(self.tool_counts.get(t, 0) for t in WRITE_TOOLS)
        if writes == 0:
            return float(reads) if reads > 0 else 0.0
        return reads / writes

    @property
    def duration_seconds(self) -> float:
        """Session duration in seconds."""
        return time.time() - self.start_time

    def to_dict(self) -> dict:
        """Serialize profile for storage."""
        return {
            "session_id": self.session_id,
            "short_id": self.short_id,
            "session_type": self.session_type or self.classify(),
            "start_time": self.start_time,
            "duration_seconds": round(self.duration_seconds, 1),
            "tool_counts": dict(self.tool_counts),
            "file_domains": dict(self.file_domains),
            "files_touched_count": len(self.files_touched),
            "read_write_ratio": round(self.read_write_ratio, 2),
            "user_message_count": len(self.user_messages),
        }

    def save(self) -> bool:
        """Save profile to persistent storage."""
        path = os.path.join(self._dir, PROFILE_FILE)
        data = _read_json(path)
        profiles = data.get("profiles", [])

        # Update or append
        existing = next((p for p in profiles if p.get("session_id") == self.session_id), None)
        profile_dict = self.to_dict()
        if existing:
            profiles[profiles.index(existing)] = profile_dict
        else:
            profiles.append(profile_dict)

        # Trim to max
        if len(profiles) > MAX_PROFILES:
            profiles = profiles[-MAX_PROFILES:]

        data["profiles"] = profiles
        data["last_updated"] = datetime.now(timezone.utc).isoformat()
        return _write_json(path, data)

    @staticmethod
    def load_history(base_dir: Optional[str] = None, limit: int = 50) -> list[dict]:
        """Load recent session profiles."""
        path = os.path.join(_cognitive_dir(base_dir), PROFILE_FILE)
        data = _read_json(path)
        profiles = data.get("profiles", [])
        return profiles[-limit:]

    @staticmethod
    def get_type_distribution(base_dir: Optional[str] = None, limit: int = 50) -> dict[str, int]:
        """Get distribution of session types from recent history."""
        profiles = SessionProfile.load_history(base_dir, limit)
        dist: dict[str, int] = {}
        for p in profiles:
            stype = p.get("session_type", "unknown")
            dist[stype] = dist.get(stype, 0) + 1
        return dist


# ── DecisionJournal ────────────────────────────────────────


class DecisionJournal:
    """Records AI decisions and their outcomes for self-improvement.

    Tracks what the AI decided to do, why, and whether the outcome was
    positive (user accepted) or negative (user corrected). Over time,
    builds a decision quality profile that can inform future behavior.
    """

    def __init__(self, base_dir: Optional[str] = None):
        self._dir = _cognitive_dir(base_dir)
        self._path = os.path.join(self._dir, JOURNAL_FILE)

    def record(
        self,
        session_id: str,
        decision_type: str,
        context: str,
        action: str,
        confidence: float = 0.5,
        tags: Optional[list[str]] = None,
    ) -> str:
        """Record a decision.

        Args:
            session_id: Current session ID.
            decision_type: Category (e.g., "tool_choice", "file_edit", "approach").
            context: What prompted the decision.
            action: What was decided.
            confidence: AI's confidence in the decision (0.0-1.0).
            tags: Optional tags for categorization.

        Returns:
            Decision ID (8-char hash).
        """
        decision_id = hashlib.sha256(
            f"{session_id}:{decision_type}:{action}:{time.time()}".encode()
        ).hexdigest()[:8]

        entry = {
            "id": decision_id,
            "session_id": session_id[:16] if session_id else "",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "decision_type": decision_type,
            "context": context[:300],
            "action": action[:300],
            "confidence": round(confidence, 2),
            "outcome": None,  # Filled later by record_outcome
            "tags": tags or [],
        }

        data = _read_json(self._path)
        entries = data.get("entries", [])
        entries.append(entry)

        # Trim
        if len(entries) > MAX_JOURNAL_ENTRIES:
            entries = entries[-MAX_JOURNAL_ENTRIES:]

        data["entries"] = entries
        data["last_updated"] = entry["timestamp"]
        _write_json(self._path, data)
        return decision_id

    def record_outcome(
        self,
        decision_id: str,
        outcome: str,
        user_feedback: Optional[str] = None,
    ) -> bool:
        """Record the outcome of a previous decision.

        Args:
            decision_id: The ID returned by record().
            outcome: "accepted", "corrected", "reverted", or "ignored".
            user_feedback: Optional user feedback text.

        Returns:
            True if decision was found and updated.
        """
        data = _read_json(self._path)
        entries = data.get("entries", [])

        for entry in reversed(entries):  # Search from newest
            if entry.get("id") == decision_id:
                entry["outcome"] = outcome
                if user_feedback:
                    entry["user_feedback"] = user_feedback[:200]
                entry["outcome_time"] = datetime.now(timezone.utc).isoformat()
                _write_json(self._path, data)
                return True
        return False

    def get_quality_score(self, decision_type: Optional[str] = None, limit: int = 50) -> float:
        """Calculate decision quality score (0.0-1.0).

        Args:
            decision_type: Filter by type (None = all).
            limit: Number of recent decisions to consider.

        Returns:
            Quality score where 1.0 = all accepted, 0.0 = all corrected.
        """
        data = _read_json(self._path)
        entries = data.get("entries", [])

        if decision_type:
            entries = [e for e in entries if e.get("decision_type") == decision_type]

        # Only consider entries with outcomes
        scored = [e for e in entries[-limit:] if e.get("outcome")]
        if not scored:
            return 0.5  # No data = neutral

        weights = {"accepted": 1.0, "ignored": 0.7, "corrected": 0.0, "reverted": 0.0}
        total = sum(weights.get(e["outcome"], 0.5) for e in scored)
        return round(total / len(scored), 3)

    def get_weak_spots(self, threshold: float = 0.4, min_entries: int = 3) -> list[dict]:
        """Find decision types where quality is consistently low.

        Returns:
            List of {decision_type, quality, count} for weak areas.
        """
        data = _read_json(self._path)
        entries = data.get("entries", [])

        # Group by decision_type
        by_type: dict[str, list] = {}
        for e in entries:
            dt = e.get("decision_type", "unknown")
            by_type.setdefault(dt, []).append(e)

        weak: list[dict] = []
        for dt, dt_entries in by_type.items():
            scored = [e for e in dt_entries if e.get("outcome")]
            if len(scored) < min_entries:
                continue
            weights = {"accepted": 1.0, "ignored": 0.7, "corrected": 0.0, "reverted": 0.0}
            quality = sum(weights.get(e["outcome"], 0.5) for e in scored) / len(scored)
            if quality < threshold:
                weak.append(
                    {
                        "decision_type": dt,
                        "quality": round(quality, 3),
                        "count": len(scored),
                    }
                )

        weak.sort(key=lambda x: x["quality"])
        return weak

    def get_recent(self, limit: int = 10) -> list[dict]:
        """Get recent journal entries."""
        data = _read_json(self._path)
        entries = data.get("entries", [])
        return entries[-limit:]

    def stats(self) -> dict:
        """Get journal statistics."""
        data = _read_json(self._path)
        entries = data.get("entries", [])
        total = len(entries)
        scored = [e for e in entries if e.get("outcome")]
        outcomes: dict[str, int] = {}
        for e in scored:
            o = e.get("outcome", "unknown")
            outcomes[o] = outcomes.get(o, 0) + 1
        return {
            "total_decisions": total,
            "scored_decisions": len(scored),
            "outcomes": outcomes,
            "quality_score": self.get_quality_score(),
            "weak_spots": self.get_weak_spots(),
        }


# ── AdaptiveThresholds ─────────────────────────────────────


class AdaptiveThresholds:
    """Dynamically adjusts sentinel/guard thresholds based on session history.

    Instead of static thresholds, learns from user behavior patterns:
    - Users who write lots of files → raise scope_creep threshold
    - Sessions with heavy reading → raise paralysis threshold
    - Frequent corrections on a threshold → loosen it

    All adjustments are bounded by THRESHOLD_BOUNDS for safety.
    """

    def __init__(self, base_dir: Optional[str] = None):
        self._dir = _cognitive_dir(base_dir)
        self._path = os.path.join(self._dir, THRESHOLDS_FILE)

    def get(self, key: str) -> int:
        """Get current adaptive threshold value."""
        data = _read_json(self._path)
        thresholds = data.get("thresholds", {})
        return thresholds.get(key, DEFAULT_THRESHOLDS.get(key, 0))

    def get_all(self) -> dict[str, int]:
        """Get all current thresholds (adaptive merged with defaults)."""
        result = dict(DEFAULT_THRESHOLDS)
        data = _read_json(self._path)
        result.update(data.get("thresholds", {}))
        return result

    def adjust(self, key: str, delta: int, reason: str = "") -> int:
        """Adjust a threshold by delta, respecting bounds.

        Args:
            key: Threshold key.
            delta: Amount to adjust (positive = loosen, negative = tighten).
            reason: Why the adjustment was made.

        Returns:
            New threshold value.
        """
        data = _read_json(self._path)
        thresholds = data.get("thresholds", {})
        history = data.get("adjustment_history", [])

        current = thresholds.get(key, DEFAULT_THRESHOLDS.get(key, 0))
        new_val = current + delta

        # Apply bounds
        if key in THRESHOLD_BOUNDS:
            lo, hi = THRESHOLD_BOUNDS[key]
            new_val = max(lo, min(hi, new_val))

        thresholds[key] = new_val
        history.append(
            {
                "key": key,
                "old": current,
                "new": new_val,
                "delta": delta,
                "reason": reason[:200],
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        )

        # Keep history manageable
        if len(history) > 200:
            history = history[-200:]

        data["thresholds"] = thresholds
        data["adjustment_history"] = history
        data["last_updated"] = datetime.now(timezone.utc).isoformat()
        _write_json(self._path, data)
        return new_val

    def learn_from_profiles(self, base_dir: Optional[str] = None) -> list[str]:
        """Analyze session profiles and adjust thresholds.

        Returns list of adjustments made.
        """
        profiles = SessionProfile.load_history(base_dir or self._dir, limit=30)
        if len(profiles) < 5:
            return []  # Not enough data

        adjustments: list[str] = []

        # 1. Average files touched → adjust scope threshold
        avg_files = sum(p.get("files_touched_count", 0) for p in profiles) / len(profiles)
        current_scope = self.get("sentinel_scope")
        scope_max = THRESHOLD_BOUNDS["sentinel_scope"][1]
        if avg_files > current_scope * 0.8 and current_scope < scope_max:
            new_val = self.adjust(
                "sentinel_scope",
                2,
                f"avg_files={avg_files:.0f}",
            )
            adjustments.append(
                f"sentinel_scope: {current_scope} → {new_val} (avg files: {avg_files:.0f})"
            )

        # 2. Average read/write ratio → adjust paralysis threshold
        ratios = [p.get("read_write_ratio", 1.0) for p in profiles]
        avg_ratio = sum(ratios) / len(ratios)
        current_paralysis = self.get("sentinel_paralysis")
        par_max = THRESHOLD_BOUNDS["sentinel_paralysis"][1]
        if avg_ratio > 3.0 and current_paralysis < par_max:
            new_val = self.adjust(
                "sentinel_paralysis",
                2,
                f"avg_rw_ratio={avg_ratio:.1f}",
            )
            adjustments.append(
                f"sentinel_paralysis: {current_paralysis} → {new_val} (ratio: {avg_ratio:.1f})"
            )

        # 3. Session type patterns → adjust tidy thresholds
        type_dist = SessionProfile.get_type_distribution(base_dir or self._dir, limit=30)
        if type_dist.get("refactor", 0) + type_dist.get("feature", 0) > len(profiles) * 0.6:
            current_tidy = self.get("tidy_code_lines")
            if current_tidy < THRESHOLD_BOUNDS["tidy_code_lines"][1]:
                new_val = self.adjust("tidy_code_lines", 5, "heavy refactor/feature sessions")
                adjustments.append(f"tidy_code_lines: {current_tidy} → {new_val}")

        return adjustments

    def reset(self, key: Optional[str] = None) -> None:
        """Reset threshold(s) to defaults."""
        data = _read_json(self._path)
        thresholds = data.get("thresholds", {})
        if key:
            if key in thresholds:
                del thresholds[key]
        else:
            thresholds = {}
        data["thresholds"] = thresholds
        _write_json(self._path, data)

    def status(self) -> dict:
        """Get threshold status: current values, defaults, deviations."""
        current = self.get_all()
        result = {}
        for key, val in current.items():
            default = DEFAULT_THRESHOLDS.get(key, val)
            result[key] = {
                "current": val,
                "default": default,
                "deviation": val - default,
                "bounds": THRESHOLD_BOUNDS.get(key, (None, None)),
            }
        return result


# ── CognitiveEngine ────────────────────────────────────────


class CognitiveEngine:
    """Orchestrator that integrates sentinel, knowledge, and evolution.

    Provides hook entry points and CLI inspection methods.
    Ties together SessionProfile, DecisionJournal, AdaptiveThresholds,
    and bridges to sentinel/knowledge/evolution modules.
    """

    def __init__(self, session_id: str = "", base_dir: Optional[str] = None):
        self._dir = _cognitive_dir(base_dir)
        self.session_id = session_id
        self.profile = SessionProfile(session_id, self._dir) if session_id else None
        self.journal = DecisionJournal(self._dir)
        self.thresholds = AdaptiveThresholds(self._dir)

    def on_session_start(self, user_message: str = "") -> Optional[str]:
        """Hook: called at session start.

        Initializes profile, checks for insights from past sessions.
        Returns context string for the AI, or None.
        """
        if self.profile and user_message:
            self.profile.record_user_message(user_message)
            self.profile.classify()

        # Check decision quality and surface weak spots
        insights: list[str] = []
        weak_spots = self.journal.get_weak_spots()
        if weak_spots:
            areas = ", ".join(w["decision_type"] for w in weak_spots[:3])
            insights.append(f"⚠ Cognitive: weak areas detected — {areas}. Extra care needed.")

        # Check if thresholds have adapted
        status = self.thresholds.status()
        adapted = [k for k, v in status.items() if v["deviation"] != 0]
        if adapted:
            insights.append(
                f"🧠 Cognitive: {len(adapted)} threshold(s) adapted from learning: "
                + ", ".join(adapted[:5])
            )

        return "\n".join(insights) if insights else None

    def get_sentinel_params(self) -> dict[str, int]:
        """Get sentinel threshold params from adaptive thresholds.

        Returns kwargs suitable for sentinel.check_sentinel().
        Maps adaptive threshold keys to sentinel parameter names.
        """
        t = self.thresholds
        return {
            "repeat_threshold": t.get("sentinel_repeat"),
            "stale_threshold": t.get("sentinel_diminish"),
            "paralysis_threshold": t.get("sentinel_paralysis"),
            "scope_threshold": t.get("sentinel_scope"),
            "drift_threshold": t.get("sentinel_drift"),
            "diminish_threshold": t.get("sentinel_diminish"),
        }

    def get_tidy_params(self) -> dict[str, int]:
        """Get tidy balance params from adaptive thresholds.

        Returns kwargs suitable for evolution.check_tidy_balance().
        """
        t = self.thresholds
        return {
            "md_threshold": t.get("tidy_md_lines"),
            "code_threshold": t.get("tidy_code_lines"),
        }

    def check_sentinel(
        self,
        tool_name: str,
        tool_input: dict,
        state_dir: str,
    ) -> Optional[str]:
        """Run sentinel checks with adaptive thresholds.

        Bridges AdaptiveThresholds → sentinel.check_sentinel().
        Falls back to default sentinel if import fails.
        """
        try:
            from cc_cortex.sentinel import check_sentinel
        except ImportError:
            return None

        params = self.get_sentinel_params()
        return check_sentinel(
            self.session_id,
            tool_name,
            tool_input,
            state_dir,
            **params,
        )

    def check_tidy(self, tool_name: str, tool_input: dict) -> Optional[str]:
        """Run tidy balance check with adaptive thresholds.

        Bridges AdaptiveThresholds → evolution.check_tidy_balance().
        """
        try:
            from cc_cortex.evolution import check_tidy_balance
        except ImportError:
            return None

        params = self.get_tidy_params()
        return check_tidy_balance(tool_name, tool_input, **params)

    def ingest_corrections(
        self,
        corrections: list[dict],
        source: str = "knowledge",
    ) -> int:
        """Ingest corrections from knowledge module into DecisionJournal.

        Bridges knowledge.extract_corrections() → DecisionJournal.
        Each correction becomes a 'corrected' decision entry.

        Args:
            corrections: List of correction dicts from knowledge.extract_corrections().
            source: Source label for tagging.

        Returns:
            Number of corrections ingested.
        """
        count = 0
        for c in corrections:
            self.journal.record(
                session_id=c.get("session_id", self.session_id),
                decision_type="user_correction",
                context=c.get("assistant_before", "")[:200],
                action=c.get("user_correction", "")[:200],
                confidence=1.0 - c.get("confidence", 1.0),
                tags=[source, "auto_extracted"],
            )
            count += 1
        return count

    def on_tool_use(self, tool_name: str, tool_input: dict) -> Optional[str]:
        """Hook: called before each tool use.

        Records tool in profile. Returns sentinel/tidy warnings using
        adaptive thresholds when relevant.
        """
        if self.profile:
            self.profile.record_tool(tool_name, tool_input)

        return None

    def on_correction(self, correction_text: str, context: str = "") -> None:
        """Hook: called when a user correction is detected.

        Records in journal as a negative outcome, and considers
        threshold adjustments.
        """
        # Record as a corrected decision
        self.journal.record(
            session_id=self.session_id,
            decision_type="user_correction",
            context=context[:200],
            action=correction_text[:200],
            confidence=0.0,
            tags=["correction"],
        )

    def on_session_end(self, transcript_path: str = "") -> None:
        """Hook: called at session end.

        Finalizes and saves profile, triggers threshold learning,
        and ingests corrections from transcript via knowledge module.
        """
        if self.profile:
            self.profile.classify()
            self.profile.save()

        # Periodically learn from accumulated profiles
        self.thresholds.learn_from_profiles(self._dir)

        # Extract and ingest corrections from transcript
        if transcript_path:
            try:
                from cc_cortex.knowledge import extract_corrections

                corrections = extract_corrections(transcript_path)
                if corrections:
                    self.ingest_corrections(corrections)
            except ImportError:
                pass

    def get_dashboard(self) -> dict:
        """Get comprehensive cognitive dashboard for CLI display."""
        return {
            "session_profile": self.profile.to_dict() if self.profile else None,
            "decision_quality": self.journal.stats(),
            "adaptive_thresholds": self.thresholds.status(),
            "session_type_distribution": SessionProfile.get_type_distribution(self._dir),
        }

    def get_summary(self) -> str:
        """Get a human-readable cognitive summary."""
        lines: list[str] = []
        lines.append("🧠 cc-cortex Cognitive Layer")
        lines.append("")

        # Decision quality
        stats = self.journal.stats()
        quality = stats["quality_score"]
        quality_icon = "🟢" if quality >= 0.7 else "🟡" if quality >= 0.4 else "🔴"
        lines.append(
            f"  {quality_icon} Decision quality: {quality:.0%} "
            f"({stats['scored_decisions']} scored / {stats['total_decisions']} total)"
        )

        if stats["weak_spots"]:
            for ws in stats["weak_spots"][:3]:
                lines.append(
                    f"     ⚠ Weak: {ws['decision_type']} ({ws['quality']:.0%}, n={ws['count']})"
                )

        # Thresholds
        thresholds = self.thresholds.status()
        adapted = {k: v for k, v in thresholds.items() if v["deviation"] != 0}
        if adapted:
            lines.append(f"  🔧 Adapted thresholds: {len(adapted)}")
            for k, v in adapted.items():
                sign = "+" if v["deviation"] > 0 else ""
                lines.append(f"     {k}: {v['default']} → {v['current']} ({sign}{v['deviation']})")
        else:
            lines.append("  🔧 Thresholds: all at defaults")

        # Session types
        dist = SessionProfile.get_type_distribution(self._dir)
        if dist:
            total = sum(dist.values())
            top = sorted(dist.items(), key=lambda x: x[1], reverse=True)[:5]
            dist_str = ", ".join(f"{k}:{v}" for k, v in top)
            lines.append(f"  📊 Session types ({total} sessions): {dist_str}")
        else:
            lines.append("  📊 Session types: no data yet")

        # Current session
        if self.profile:
            p = self.profile
            lines.append(
                f"  📍 Current: {p.session_type} | "
                f"{len(p.files_touched)} files | "
                f"R/W ratio: {p.read_write_ratio:.1f}"
            )

        return "\n".join(lines)


# ── Hook entry points ──────────────────────────────────────


def check_session_start(payload: dict) -> Optional[dict]:
    """Hook entry: SessionStart event."""
    session_id = os.environ.get("CC_SESSION_ID", "")
    if not session_id:
        return None

    engine = CognitiveEngine(session_id)
    context = engine.on_session_start()
    if context:
        return {"additionalContext": context}
    return None


def check_pre_tool(payload: dict) -> Optional[dict]:
    """Hook entry: PreToolUse event."""
    session_id = os.environ.get("CC_SESSION_ID", "")
    if not session_id:
        return None

    tool_name = payload.get("tool_name", "")
    tool_input = payload.get("tool_input", {})

    engine = CognitiveEngine(session_id)
    context = engine.on_tool_use(tool_name, tool_input)
    if context:
        return {"additionalContext": context}
    return None


def check_stop(payload: dict) -> Optional[dict]:
    """Hook entry: Stop event."""
    session_id = os.environ.get("CC_SESSION_ID", "")
    if not session_id:
        return None

    # Find transcript path for knowledge extraction
    transcript_path = ""
    transcript_dir = os.path.join(
        os.path.expanduser("~"),
        ".claude",
        "projects",
    )
    if os.path.isdir(transcript_dir):
        # Look for most recent transcript matching this session
        for root, _dirs, files in os.walk(transcript_dir):
            for f in files:
                if f.endswith(".jsonl") and session_id[:8] in f:
                    transcript_path = os.path.join(root, f)
                    break
            if transcript_path:
                break

    engine = CognitiveEngine(session_id)
    engine.on_session_end(transcript_path)
    return None


# ── CLI commands ───────────────────────────────────────────


def cli_status() -> str:
    """CLI: show cognitive layer status."""
    engine = CognitiveEngine()
    return engine.get_summary()


def cli_thresholds() -> str:
    """CLI: show adaptive thresholds."""
    thresholds = AdaptiveThresholds()
    status = thresholds.status()
    lines = ["🔧 Adaptive Thresholds", ""]
    for key, info in status.items():
        dev = info["deviation"]
        marker = f" ({'+' if dev > 0 else ''}{dev})" if dev != 0 else ""
        bounds = info["bounds"]
        lines.append(
            f"  {key:30s} {info['current']:>3d}{marker:>8s}"
            f"  [default: {info['default']},"
            f" bounds: {bounds[0]}-{bounds[1]}]"
        )
    return "\n".join(lines)


def cli_journal(limit: int = 10) -> str:
    """CLI: show recent decisions."""
    journal = DecisionJournal()
    entries = journal.get_recent(limit)
    if not entries:
        return "📓 Decision Journal: empty"

    lines = [f"📓 Decision Journal (last {limit})", ""]
    for e in entries:
        outcome = e.get("outcome", "pending")
        outcome_icons = {
            "accepted": "✅",
            "corrected": "❌",
            "reverted": "↩",
            "ignored": "⏭",
        }
        icon = outcome_icons.get(outcome, "⏳")
        lines.append(
            f"  {icon} [{e.get('decision_type', '?')}] {e.get('action', '')[:60]}"
            f"  (conf: {e.get('confidence', '?')}, {outcome})"
        )
    return "\n".join(lines)


def cli_profiles(limit: int = 10) -> str:
    """CLI: show recent session profiles."""
    profiles = SessionProfile.load_history(limit=limit)
    if not profiles:
        return "📊 Session Profiles: no data yet"

    lines = [f"📊 Session Profiles (last {limit})", ""]
    for p in profiles[-limit:]:
        dur = p.get("duration_seconds", 0)
        dur_str = f"{dur / 60:.0f}m" if dur > 60 else f"{dur:.0f}s"
        lines.append(
            f"  {p.get('short_id', '?'):8s} {p.get('session_type', '?'):10s} "
            f"{p.get('files_touched_count', 0):>3d} files  "
            f"R/W {p.get('read_write_ratio', 0):.1f}  "
            f"{dur_str}"
        )
    return "\n".join(lines)


def cli_reset_thresholds() -> str:
    """CLI: reset all thresholds to defaults."""
    AdaptiveThresholds().reset()
    return "🔧 All thresholds reset to defaults."


def cli_promotions(threshold: int = 3) -> str:
    """CLI: show learnings ready for promotion to rules.

    Displays high-frequency corrections that could become persistent rules.
    """
    try:
        from cc_cortex.knowledge import suggest_rule_promotions
    except ImportError:
        return "❌ knowledge module not available"

    learnings_path = os.path.join(
        _cognitive_dir(),
        "learnings.json",
    )
    suggestions = suggest_rule_promotions(learnings_path, threshold)
    if not suggestions:
        return "📋 No learnings ready for promotion (need count ≥ {}).".format(threshold)

    lines = [f"📋 Rule Promotion Suggestions ({len(suggestions)} pending)", ""]
    for s in suggestions:
        lines.append(f"  🔺 [{s['learning_id']}] (×{s['count']}, conf={s['confidence']:.0%})")
        lines.append(f"     Correction: {s['correction_text'][:80]}")
        if s.get("context"):
            lines.append(f"     Context: {s['context'][:60]}...")
        lines.append(f"     → Target: .claude/rules/{s['target_file']}")
        lines.append("")

    lines.append("Use `cc-cortex cognitive promote <id>` to create a rule file.")
    return "\n".join(lines)


def cli_promote(learning_id: str, rules_dir: str = "") -> str:
    """CLI: promote a learning to a rule file.

    Creates a .md rule file in .claude/rules/ from a high-frequency learning.
    """
    try:
        from cc_cortex.knowledge import (
            mark_promoted,
            suggest_rule_promotions,
        )
    except ImportError:
        return "❌ knowledge module not available"

    learnings_path = os.path.join(_cognitive_dir(), "learnings.json")
    suggestions = suggest_rule_promotions(learnings_path, threshold=1)

    target = next((s for s in suggestions if s["learning_id"] == learning_id), None)
    if not target:
        return f"❌ Learning '{learning_id}' not found or already promoted."

    if not rules_dir:
        rules_dir = os.path.join(os.path.expanduser("~"), ".claude", "rules")

    os.makedirs(rules_dir, exist_ok=True)
    rule_path = os.path.join(rules_dir, target["target_file"])

    content = (
        f"# Learned Rule: {target['correction_text'][:60]}\n\n"
        f"> Auto-promoted from {target['count']}x recurring correction "
        f"(confidence: {target['confidence']:.0%})\n\n"
        f"{target['correction_text']}\n"
    )
    if target.get("context"):
        content += f"\n## Context\n\n{target['context']}\n"

    with open(rule_path, "w", encoding="utf-8") as f:
        f.write(content)

    mark_promoted(learnings_path, learning_id)
    return f"✅ Rule created: {rule_path}"


__all__ = [
    "SessionProfile",
    "DecisionJournal",
    "AdaptiveThresholds",
    "CognitiveEngine",
    "check_session_start",
    "check_pre_tool",
    "check_stop",
    "cli_status",
    "cli_thresholds",
    "cli_journal",
    "cli_profiles",
    "cli_reset_thresholds",
    "cli_promotions",
    "cli_promote",
    "DEFAULT_THRESHOLDS",
    "THRESHOLD_BOUNDS",
]
