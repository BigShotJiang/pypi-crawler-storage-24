"""
cc_cortex.process_guard — Cross-platform Claude Code process management.

Ported from claude-process-guard.ps1. Zero external dependencies (stdlib only).

Rules:
  Rule 1 (Orphan kill): parent IDE dead → always kill
  Rule 2 (Stale kill):  parent IDE alive but no active session + age > threshold → kill
  Rule 3 (RAM/Quota):   warn only, never kill alive sessions
  Protection: IDE alive + active session = NEVER kill

Platforms: Windows (tasklist/taskkill/wmic), macOS/Linux (ps/kill//proc)
"""

from __future__ import annotations

import ctypes
import ctypes.wintypes
import json
import logging
import os
import platform
import re
import signal
import subprocess
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Optional

logger = logging.getLogger("cc_cortex.process_guard")

# ──────────────────────────────────────────────
# Constants
# ──────────────────────────────────────────────

IDLE_MINUTES = 30
STALE_MINUTES = 120
CLAUDE_MAX_MB = 8192

SYSTEM = platform.system()  # "Windows", "Darwin", "Linux"


class Tier(Enum):
    ALIVE = "ALIVE"
    STALE = "STALE"
    ORPHAN = "ORPHAN"
    SCHEDULED = "SCHEDULED"


@dataclass
class ClaudeProcess:
    pid: int
    name: str
    mem_mb: int = 0
    start_time: Optional[float] = None  # epoch seconds
    cmdline: str = ""
    tier: Tier = Tier.ALIVE
    kill_reason: str = ""


@dataclass
class GuardResult:
    scanned: int = 0
    killed: int = 0
    freed_mb: int = 0
    warnings: list[str] = field(default_factory=list)
    actions: list[str] = field(default_factory=list)
    lock_cleaned: int = 0


# ──────────────────────────────────────────────
# Cross-platform process helpers
# ──────────────────────────────────────────────


_CREATE_NO_WINDOW = 0x08000000


def _run(cmd: list[str], timeout: int = 10) -> str:
    """Run a command and return stdout, empty string on failure.
    Uses CREATE_NO_WINDOW on Windows to prevent console flash.
    """
    try:
        r = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            creationflags=_CREATE_NO_WINDOW if SYSTEM == "Windows" else 0,
        )
        return r.stdout
    except Exception:
        return ""


def _get_all_processes() -> list[dict]:
    """Get all running processes as list of {pid, ppid, name, cmdline, mem_kb, start_time}.

    Uses two-phase approach on Windows:
      Phase A: CreateToolhelp32Snapshot (fast, no console flash, gives pid/ppid/name)
      Phase B: wmic with CREATE_NO_WINDOW (slow, for cmdline of Claude-related processes only)
    """
    if SYSTEM == "Windows":
        return _get_all_processes_windows()
    return _get_all_processes_unix()


# Windows API constants for CreateToolhelp32Snapshot
_TH32CS_SNAPPROCESS = 0x00000002


class _PROCESSENTRY32(ctypes.Structure):
    _fields_ = [
        ("dwSize", ctypes.c_ulong),
        ("cntUsage", ctypes.c_ulong),
        ("th32ProcessID", ctypes.c_ulong),
        ("th32DefaultHeapID", ctypes.POINTER(ctypes.c_ulong)),
        ("th32ModuleID", ctypes.c_ulong),
        ("cntThreads", ctypes.c_ulong),
        ("th32ParentProcessID", ctypes.c_ulong),
        ("pcPriClassBase", ctypes.c_long),
        ("dwFlags", ctypes.c_ulong),
        ("szExeFile", ctypes.c_char * 260),
    ]


def _snapshot_processes_windows() -> list[dict]:
    """Phase A: Fast process list via Windows API (no wmic, no console flash).
    Returns list of {pid, ppid, name, cmdline:'', mem_kb:0, start_time:None}.
    """
    kernel32 = ctypes.windll.kernel32
    snapshot = kernel32.CreateToolhelp32Snapshot(_TH32CS_SNAPPROCESS, 0)
    if snapshot == ctypes.wintypes.HANDLE(-1).value:
        return []

    pe = _PROCESSENTRY32()
    pe.dwSize = ctypes.sizeof(pe)
    processes = []

    if kernel32.Process32First(snapshot, ctypes.byref(pe)):
        while True:
            processes.append(
                {
                    "pid": pe.th32ProcessID,
                    "ppid": pe.th32ParentProcessID,
                    "name": pe.szExeFile.decode("utf-8", errors="replace"),
                    "cmdline": "",
                    "mem_kb": 0,
                    "start_time": None,
                }
            )
            if not kernel32.Process32Next(snapshot, ctypes.byref(pe)):
                break

    kernel32.CloseHandle(snapshot)
    return processes


def _enrich_claude_processes(processes: list[dict]) -> list[dict]:
    """Phase B: Enrich Claude-candidate processes with cmdline + mem via wmic.
    Only queries processes with names matching Claude patterns (Code.exe, node.exe, claude.exe).
    Uses CREATE_NO_WINDOW to prevent console flash.
    """
    # Find PIDs that need cmdline enrichment
    claude_names = {"code.exe", "node.exe", "claude.exe", "claude", "bash.exe"}
    candidate_pids = [p["pid"] for p in processes if p["name"].lower() in claude_names]

    if not candidate_pids:
        return processes

    # Query wmic for cmdline + WorkingSetSize (batched, hidden window)
    cmdline_map = {}
    try:
        out = _run(
            [
                "wmic",
                "process",
                "where",
                "name='Code.exe' OR name='node.exe' OR name='claude.exe'",
                "get",
                "ProcessId,CommandLine,WorkingSetSize",
                "/FORMAT:CSV",
            ],
            timeout=15,
        )
        for line in out.strip().splitlines():
            line = line.strip()
            if not line or "ProcessId" in line or line.startswith("Node"):
                continue
            parts = line.split(",")
            if len(parts) < 4:
                continue
            try:
                cmdline = ",".join(parts[1:-2])
                pid = int(parts[-2])
                ws = int(parts[-1]) if parts[-1].strip() else 0
                cmdline_map[pid] = {"cmdline": cmdline, "mem_kb": ws // 1024}
            except (ValueError, IndexError):
                continue
    except Exception:
        pass

    # Merge cmdline into process list
    for p in processes:
        if p["pid"] in cmdline_map:
            p["cmdline"] = cmdline_map[p["pid"]]["cmdline"]
            p["mem_kb"] = cmdline_map[p["pid"]]["mem_kb"]

    return processes


def _get_all_processes_windows() -> list[dict]:
    """Two-phase Windows process discovery:
    Phase A: CreateToolhelp32Snapshot for full tree (fast, no flash)
    Phase B: wmic for cmdline of Claude-related PIDs only (CREATE_NO_WINDOW)
    """
    processes = _snapshot_processes_windows()
    if not processes:
        # Fallback to wmic-only (legacy)
        return _get_all_processes_wmic_legacy()
    return _enrich_claude_processes(processes)


def _get_all_processes_wmic_legacy() -> list[dict]:
    """Legacy fallback: full wmic query (used when CreateToolhelp32Snapshot fails)."""
    out = _run(
        [
            "wmic",
            "process",
            "get",
            "ProcessId,ParentProcessId,Name,CommandLine,WorkingSetSize",
            "/FORMAT:CSV",
        ],
        timeout=15,
    )
    processes = []
    for line in out.strip().splitlines():
        parts = line.split(",")
        if len(parts) < 5 or "ProcessId" in line:
            continue
        try:
            cmdline = parts[1] if len(parts) >= 6 else ""
            name = parts[2] if len(parts) >= 6 else parts[1]
            ppid = int(parts[3]) if len(parts) >= 6 else 0
            pid = int(parts[4]) if len(parts) >= 6 else int(parts[2])
            ws = int(parts[5]) if len(parts) >= 6 else 0
            processes.append(
                {
                    "pid": pid,
                    "ppid": ppid,
                    "name": name,
                    "cmdline": cmdline,
                    "mem_kb": ws // 1024,
                    "start_time": None,
                }
            )
        except (ValueError, IndexError):
            continue
    return processes


def _get_all_processes_unix() -> list[dict]:
    """Use ps on macOS/Linux."""
    out = _run(["ps", "-eo", "pid,ppid,rss,lstart,comm,args"], timeout=10)
    processes = []
    for line in out.strip().splitlines()[1:]:  # skip header
        line = line.strip()
        if not line:
            continue
        # Parse: PID PPID RSS LSTART(multi-word) COMM ARGS
        parts = line.split(None, 5)
        if len(parts) < 5:
            continue
        try:
            pid = int(parts[0])
            ppid = int(parts[1])
            rss_kb = int(parts[2])
            # lstart is like "Mon Mar 10 14:30:00 2025" — 5 tokens
            # We need to find where comm starts
            # Re-parse with more columns
            match = re.match(
                r"\s*(\d+)\s+(\d+)\s+(\d+)\s+"
                r"(\w+\s+\w+\s+\d+\s+[\d:]+\s+\d+)\s+"
                r"(\S+)\s*(.*)",
                line,
            )
            if not match:
                continue
            pid = int(match.group(1))
            ppid = int(match.group(2))
            rss_kb = int(match.group(3))
            lstart_str = match.group(4)
            comm = match.group(5)
            args = match.group(6) if match.group(6) else comm

            start_epoch = None
            try:
                dt = datetime.strptime(lstart_str, "%a %b %d %H:%M:%S %Y")
                start_epoch = dt.timestamp()
            except ValueError:
                pass

            processes.append(
                {
                    "pid": pid,
                    "ppid": ppid,
                    "name": os.path.basename(comm),
                    "cmdline": args,
                    "mem_kb": rss_kb,
                    "start_time": start_epoch,
                }
            )
        except (ValueError, IndexError):
            continue
    return processes


def _kill_process(pid: int) -> bool:
    """Kill a process (and its tree on Windows)."""
    try:
        if SYSTEM == "Windows":
            subprocess.run(
                ["taskkill", "/PID", str(pid), "/T", "/F"],
                capture_output=True,
                timeout=10,
                creationflags=subprocess.CREATE_NO_WINDOW,
            )
        else:
            os.kill(pid, signal.SIGTERM)
            time.sleep(0.5)
            try:
                os.kill(pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        return True
    except Exception:
        return False


def _pid_alive(pid: int) -> bool:
    """Check if a PID is still running."""
    if pid <= 0:
        return False
    try:
        if SYSTEM == "Windows":
            out = _run(["tasklist", "/FI", f"PID eq {pid}", "/NH"])
            return str(pid) in out
        else:
            os.kill(pid, 0)
            return True
    except (ProcessLookupError, PermissionError):
        return SYSTEM != "Windows"
    except Exception:
        return False


# ──────────────────────────────────────────────
# Core Logic
# ──────────────────────────────────────────────


def _find_claude_processes(all_procs: list[dict]) -> list[ClaudeProcess]:
    """Find Claude-related processes from the full process list."""
    result = []
    seen_pids = set()

    for p in all_procs:
        pid = p["pid"]
        if pid in seen_pids:
            continue
        name = p.get("name", "").lower()
        cmdline = p.get("cmdline", "")

        is_claude = False
        display_name = ""

        # claude.exe / claude (binary)
        if name in ("claude", "claude.exe"):
            is_claude = True
            display_name = "claude"

        # node.exe running claude
        elif name in ("node", "node.exe") and "claude" in cmdline.lower():
            if "process-guard" not in cmdline.lower():
                is_claude = True
                display_name = "node(claude)"

        # Code.exe running cli.js (VS Code extension)
        elif name in ("code", "code.exe") and re.search(r"cli\.js.*--output-format", cmdline):
            is_claude = True
            display_name = "code(claude-cli)"

        if is_claude:
            seen_pids.add(pid)
            result.append(
                ClaudeProcess(
                    pid=pid,
                    name=display_name,
                    mem_mb=p.get("mem_kb", 0) // 1024,
                    start_time=p.get("start_time"),
                    cmdline=cmdline,
                )
            )

    return sorted(result, key=lambda x: x.start_time or 0)


def _find_ancestor(
    pid: int,
    target_pids: set[int],
    proc_map: dict[int, dict],
    max_depth: int = 6,
) -> int:
    """Walk up process tree to find an ancestor PID in target_pids."""
    current = pid
    for _ in range(max_depth):
        parent = proc_map.get(current, {}).get("ppid", 0)
        if parent <= 0:
            break
        if parent in target_pids:
            return parent
        current = parent
    return 0


def _is_scheduled_task(pid: int, proc_map: dict[int, dict], max_depth: int = 6) -> bool:
    """Check if process is a child of scheduled_launcher or auto-agent."""
    current = pid
    for _ in range(max_depth):
        parent_info = proc_map.get(current)
        if not parent_info:
            break
        cmdline = parent_info.get("cmdline", "")
        if "auto-agent" in cmdline or "scheduled_launcher" in cmdline:
            return True
        current = parent_info.get("ppid", 0)
        if current <= 0:
            break
    return False


def _read_instance_lock(lock_path: str) -> dict:
    """Read instance_lock.json, return empty dict on failure."""
    try:
        with open(lock_path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _classify_processes(
    claude_procs: list[ClaudeProcess],
    all_procs: list[dict],
    lock_path: str,
    idle_minutes: int = IDLE_MINUTES,
    stale_minutes: int = STALE_MINUTES,
) -> list[ClaudeProcess]:
    """Classify each Claude process into ALIVE/STALE/ORPHAN/SCHEDULED."""
    now = time.time()
    proc_map = {p["pid"]: p for p in all_procs}

    # Find all IDE PIDs (VS Code / Cursor)
    ide_names = {"code", "code.exe", "cursor", "cursor.exe"}
    ide_pids = {p["pid"] for p in all_procs if p.get("name", "").lower() in ide_names}

    # Read instance lock
    lock = _read_instance_lock(lock_path)
    sessions = lock.get("sessions", {})

    # Find active (non-idle) sessions and their IDE PIDs
    active_ide_pids = set()
    idle_session_keys = set()
    for key, sess in sessions.items():
        last_active = sess.get("last_active")
        if last_active:
            try:
                dt = datetime.fromisoformat(last_active.replace("Z", "+00:00"))
                idle_min = (now - dt.timestamp()) / 60
                if idle_min > idle_minutes:
                    idle_session_keys.add(key)
                    continue
            except (ValueError, TypeError):
                pass
        vscode_pid = sess.get("vscode_pid", 0)
        if isinstance(vscode_pid, (int, float)) and int(vscode_pid) > 0:
            active_ide_pids.add(int(vscode_pid))

    # Classify
    for cp in claude_procs:
        ancestor_ide = _find_ancestor(cp.pid, ide_pids, proc_map)

        if ancestor_ide == 0:
            # No IDE parent — check if scheduled task
            if _is_scheduled_task(cp.pid, proc_map):
                cp.tier = Tier.SCHEDULED
            else:
                cp.tier = Tier.ORPHAN
                cp.kill_reason = "no IDE parent"
            continue

        # Has IDE parent — check if active session
        if ancestor_ide in active_ide_pids:
            cp.tier = Tier.ALIVE
            continue

        # IDE alive but no active session — check age
        age_min = 0
        if cp.start_time:
            age_min = (now - cp.start_time) / 60

        if age_min > stale_minutes:
            # Before marking STALE, check if process has active children (subagents)
            has_active_children = False
            child_pids = [
                p["pid"]
                for p in all_procs
                if p.get("ppid") == cp.pid
                and p.get("name", "").lower()
                in ("bash", "bash.exe", "node", "node.exe", "claude", "claude.exe")
            ]
            if child_pids:
                has_active_children = True
            else:
                # Check grandchildren (claude -> bash -> node)
                direct_children = [p["pid"] for p in all_procs if p.get("ppid") == cp.pid]
                for dc_pid in direct_children:
                    gc = [
                        p
                        for p in all_procs
                        if p.get("ppid") == dc_pid
                        and p.get("name", "").lower()
                        in ("bash", "bash.exe", "node", "node.exe", "claude", "claude.exe")
                    ]
                    if gc:
                        has_active_children = True
                        break
            if has_active_children:
                cp.tier = Tier.ALIVE
                cp.kill_reason = ""
                logger.info("ALIVE | PID %d — stale-age but has active children", cp.pid)
            else:
                cp.tier = Tier.STALE
                cp.kill_reason = f"no active session, age {int(age_min)}min > {stale_minutes}min"
        else:
            cp.tier = Tier.ALIVE  # benefit of doubt

    return claude_procs


def _find_orphan_children(all_procs: list[dict]) -> list[int]:
    """Find orphaned bash/node processes from dead Claude sessions."""
    proc_map = {p["pid"]: p for p in all_procs}
    orphans = []

    for p in all_procs:
        name = p.get("name", "").lower()
        cmdline = p.get("cmdline", "")

        is_target = False
        if name in ("bash", "bash.exe") and "claude" in cmdline.lower():
            is_target = True
        elif name in ("node", "node.exe") and re.search(
            r"(phase\d+\.test|npm\s+(test|run\s+dev))", cmdline
        ):
            is_target = True

        if is_target:
            ppid = p.get("ppid", 0)
            if ppid > 0 and ppid not in proc_map:
                orphans.append(p["pid"])
            elif ppid > 0 and not _pid_alive(ppid):
                orphans.append(p["pid"])

    return orphans


def _cleanup_instance_lock(
    lock_path: str,
    idle_session_keys: set[str],
    ide_pids: set[int],
) -> int:
    """Remove dead/superseded sessions from instance_lock.json."""
    try:
        with open(lock_path, encoding="utf-8") as f:
            lock = json.load(f)
    except Exception:
        return 0

    sessions = lock.get("sessions", {})
    if not sessions:
        return 0

    # Find superseded sessions (same IDE PID, older session)
    by_ide: dict[int, list[tuple[str, str]]] = {}
    for key, sess in sessions.items():
        vp = int(sess.get("vscode_pid", 0))
        started = sess.get("started", "")
        if vp > 0:
            by_ide.setdefault(vp, []).append((key, started))

    superseded = set()
    for vp, group in by_ide.items():
        if len(group) <= 1:
            continue
        group.sort(key=lambda x: x[1], reverse=True)
        for key, _ in group[1:]:
            if key in idle_session_keys:
                superseded.add(key)

    # Remove dead IDE + superseded
    removed = 0
    keys_to_remove = []
    for key in idle_session_keys:
        vp = int(sessions.get(key, {}).get("vscode_pid", 0))
        ide_alive = vp > 0 and vp in ide_pids and _pid_alive(vp)
        is_superseded = key in superseded

        if not ide_alive or is_superseded:
            keys_to_remove.append(key)

    for key in keys_to_remove:
        del sessions[key]
        removed += 1

    if removed > 0:
        lock["last_updated"] = datetime.now(timezone.utc).isoformat()
        try:
            with open(lock_path, "w", encoding="utf-8") as f:
                json.dump(lock, f, indent=2, ensure_ascii=False)
        except Exception:
            pass

    return removed


# ──────────────────────────────────────────────
# Public API
# ──────────────────────────────────────────────


def run_guard(
    *,
    lock_path: Optional[str] = None,
    idle_minutes: int = IDLE_MINUTES,
    stale_minutes: int = STALE_MINUTES,
    dry_run: bool = False,
) -> GuardResult:
    """Run the process guard — scan, classify, and cleanup.

    Args:
        lock_path: Path to instance_lock.json. Auto-detected if None.
        idle_minutes: Minutes before a session is considered idle.
        stale_minutes: Minutes before a stale process is killed.
        dry_run: If True, log actions but don't kill anything.

    Returns:
        GuardResult with scan/kill/warning details.
    """
    result = GuardResult()

    # Auto-detect lock path
    if not lock_path:
        workspace = os.environ.get("CLAUDE_PROJECT_DIR", os.getcwd())
        lock_path = os.path.join(workspace, "_AI_BRAIN", "cognition_shared", "instance_lock.json")

    # Phase 1: Discover
    all_procs = _get_all_processes()
    claude_procs = _find_claude_processes(all_procs)
    result.scanned = len(claude_procs)

    if not claude_procs:
        return result

    total_mb = sum(cp.mem_mb for cp in claude_procs)
    result.actions.append(f"SCAN: {len(claude_procs)} Claude processes, {total_mb}MB total")

    # Phase 2: Classify
    claude_procs = _classify_processes(
        claude_procs,
        all_procs,
        lock_path,
        idle_minutes=idle_minutes,
        stale_minutes=stale_minutes,
    )

    # Phase 3: Kill orphans + stale
    kill_targets = [cp for cp in claude_procs if cp.tier in (Tier.ORPHAN, Tier.STALE)]

    for cp in kill_targets:
        mode = "DRY-RUN" if dry_run else "KILL"
        action = (
            f"{mode}: PID {cp.pid} ({cp.name}, {cp.mem_mb}MB) — {cp.tier.value}: {cp.kill_reason}"
        )
        result.actions.append(action)
        logger.info(action)

        if not dry_run:
            if _kill_process(cp.pid):
                result.killed += 1
                result.freed_mb += cp.mem_mb

    # Phase 4: Kill orphan children (bash/node)
    orphan_children = _find_orphan_children(all_procs)
    for pid in orphan_children:
        action = f"{'DRY-RUN' if dry_run else 'KILL'}: orphan child PID {pid}"
        result.actions.append(action)
        if not dry_run:
            _kill_process(pid)

    # Phase 5: RAM warnings
    if total_mb > CLAUDE_MAX_MB:
        result.warnings.append(f"Claude processes using {total_mb}MB > {CLAUDE_MAX_MB}MB limit")

    # Phase 6: Cleanup instance_lock
    if not dry_run and os.path.exists(lock_path):
        now = time.time()
        lock = _read_instance_lock(lock_path)
        sessions = lock.get("sessions", {})
        idle_keys = set()
        for key, sess in sessions.items():
            last_active = sess.get("last_active")
            if last_active:
                try:
                    dt = datetime.fromisoformat(last_active.replace("Z", "+00:00"))
                    if (now - dt.timestamp()) / 60 > idle_minutes:
                        idle_keys.add(key)
                except (ValueError, TypeError):
                    pass

        ide_names = {"code", "code.exe", "cursor", "cursor.exe"}
        ide_pids = {p["pid"] for p in all_procs if p.get("name", "").lower() in ide_names}
        result.lock_cleaned = _cleanup_instance_lock(lock_path, idle_keys, ide_pids)
        if result.lock_cleaned:
            result.actions.append(f"LOCK-CLEAN: removed {result.lock_cleaned} stale session(s)")

    return result


# ──────────────────────────────────────────────
# Session Registration (SessionStart hook)
# ──────────────────────────────────────────────


@dataclass
class RegistrationResult:
    cli_pid: int = 0
    vscode_pid: int = 0
    session_key: str = ""
    suspects: list[int] = field(default_factory=list)
    stale_cleaned: int = 0
    actions: list[str] = field(default_factory=list)


def _build_proc_map(all_procs: list[dict]) -> dict[int, dict]:
    """Build {pid: {ppid, name}} map from process list."""
    return {
        p["pid"]: {"ppid": p.get("ppid", 0), "name": p.get("name", "").lower()} for p in all_procs
    }


def _find_cli_pid(proc_map: dict[int, dict]) -> int:
    """Walk up from current Python process to find Code.exe/Cursor.exe CLI parent.

    Process chain: Code.exe(cli) → node.exe → bash.exe → python.exe(us)
    """
    ide_names = {"code.exe", "code", "cursor.exe", "cursor"}
    pid = os.getpid()
    for _ in range(10):
        info = proc_map.get(pid)
        if not info:
            break
        ppid = info["ppid"]
        if ppid <= 0:
            break
        parent = proc_map.get(ppid)
        if not parent:
            break
        if parent["name"] in ide_names:
            return ppid
        pid = ppid
    return 0


def _find_vscode_main_pid(cli_pid: int, proc_map: dict[int, dict]) -> int:
    """Walk up from CLI to find topmost Code.exe/Cursor.exe ancestor."""
    ide_names = {"code.exe", "code", "cursor.exe", "cursor"}
    pid = cli_pid
    topmost = cli_pid
    for _ in range(8):
        info = proc_map.get(pid)
        if not info:
            break
        ppid = info["ppid"]
        if ppid <= 0:
            break
        parent = proc_map.get(ppid)
        if not parent:
            break
        if parent["name"] in ide_names:
            topmost = ppid
            pid = ppid
        else:
            break
    return topmost


def _get_or_create_session_key(
    session_id: str,
    marker_dir: str,
    tz_offset_hours: int = 8,
) -> str:
    """Read session_name from marker file, or generate + save one.

    Unified format: ABBR_<4hex>_<HHMM> (e.g. cc_a1b2_0900, EVO_b500_1423).
    Initial sessions use 'cc_' prefix; update_session_task.py renames to project abbr.
    """
    import re
    import uuid

    _VALID = re.compile(r"^[A-Za-z]{2,8}_[0-9a-f]{4,8}_\d{4}$")
    if not session_id:
        return ""
    marker = os.path.join(marker_dir, f"{session_id}.session_name")
    try:
        if os.path.isfile(marker):
            with open(marker, "r", encoding="utf-8") as f:
                name = f.read().strip()
                if name and _VALID.match(name):
                    return name
    except Exception:
        pass
    tz = timezone(timedelta(hours=tz_offset_hours))
    hhmm = datetime.now(tz).strftime("%H%M")
    hex4 = uuid.uuid4().hex[:4]
    key = f"cc_{hex4}_{hhmm}"
    try:
        os.makedirs(marker_dir, exist_ok=True)
        with open(marker, "w", encoding="utf-8") as f:
            f.write(key)
    except Exception:
        pass
    return key


def _register_cli_in_lock(
    lock_path: str,
    session_id: str,
    session_key: str,
    cli_pid: int,
    vscode_pid: int,
    tz_offset_hours: int = 8,
) -> dict:
    """Register cli_pid in instance_lock.json. Returns sessions dict."""
    tz = timezone(timedelta(hours=tz_offset_hours))
    now = datetime.now(tz).isoformat()

    lock: dict = {}
    try:
        with open(lock_path, "r", encoding="utf-8") as f:
            lock = json.load(f)
    except Exception:
        pass

    sessions = lock.setdefault("sessions", {})
    if session_key in sessions:
        sessions[session_key]["cli_pid"] = cli_pid
        sessions[session_key]["last_active"] = now
    else:
        sessions[session_key] = {
            "session_id": session_id,
            "vscode_pid": vscode_pid,
            "cli_pid": cli_pid,
            "holder": "",
            "project": "",
            "task": "",
            "files": [],
            "started": now,
            "last_active": now,
        }

    lock["last_updated"] = now
    tmp = lock_path + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(lock, f, indent=2, ensure_ascii=False)
        os.replace(tmp, lock_path)
    except Exception:
        pass

    return sessions


def _clean_stale_from_lock(lock_path: str, proc_map: dict[int, dict]) -> int:
    """Remove sessions whose VSCode/CLI is dead. Returns count removed."""
    try:
        with open(lock_path, "r", encoding="utf-8") as f:
            lock = json.load(f)
    except Exception:
        return 0

    sessions = lock.get("sessions", {})
    if not sessions:
        return 0

    ide_names = {"code.exe", "code", "cursor.exe", "cursor"}
    alive_ides = {pid for pid, info in proc_map.items() if info["name"] in ide_names}

    to_remove = []
    for key, sess in sessions.items():
        vp = int(sess.get("vscode_pid", 0))
        cp = int(sess.get("cli_pid", 0))
        if vp > 0 and vp not in alive_ides:
            to_remove.append(key)
        elif cp > 0 and cp not in proc_map:
            to_remove.append(key)

    if to_remove:
        for key in to_remove:
            del sessions[key]
        lock["last_updated"] = datetime.now(timezone.utc).isoformat()
        try:
            tmp = lock_path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(lock, f, indent=2, ensure_ascii=False)
            os.replace(tmp, lock_path)
        except Exception:
            pass

    return len(to_remove)


def register_session_startup(
    session_id: str,
    *,
    lock_path: Optional[str] = None,
    marker_dir: Optional[str] = None,
    tz_offset_hours: int = 8,
) -> RegistrationResult:
    """High-level SessionStart registration: find CLI PID, register, detect suspects.

    This is the main API for the SessionStart hook. It:
    1. Snapshots the process tree (zero overhead, no console flash on Windows)
    2. Finds our CLI PID by walking up the process tree
    3. Finds the VSCode main PID
    4. Generates/reads session key from marker file
    5. Registers cli_pid in instance_lock.json
    6. Detects unregistered CLI processes (suspects, logged only)
    7. Cleans stale sessions from instance_lock

    Args:
        session_id: Claude Code session ID from hook stdin.
        lock_path: Path to instance_lock.json. Auto-detected if None.
        marker_dir: Directory for session marker files. Default ~/.claude/session_markers.
        tz_offset_hours: Timezone offset (default 8 for Asia/Taipei).

    Returns:
        RegistrationResult with cli_pid, session_key, suspects, etc.
    """
    result = RegistrationResult()

    if not session_id:
        result.actions.append("SKIP: no session_id")
        return result

    # Auto-detect paths
    if not lock_path:
        workspace = os.environ.get("CLAUDE_PROJECT_DIR", os.getcwd())
        lock_path = os.path.join(
            workspace,
            "_AI_BRAIN",
            "cognition_shared",
            "instance_lock.json",
        )
    if not marker_dir:
        home = os.environ.get("USERPROFILE") or os.path.expanduser("~")
        marker_dir = os.path.join(home, ".claude", "session_markers")

    # Step 1: Snapshot process tree
    all_procs = _get_all_processes()
    if not all_procs:
        result.actions.append("SKIP: empty process snapshot")
        return result

    proc_map = _build_proc_map(all_procs)

    # Step 2: Find CLI PID
    cli_pid = _find_cli_pid(proc_map)
    if not cli_pid:
        result.actions.append("SKIP: could not find CLI PID")
        return result
    result.cli_pid = cli_pid

    # Step 3: Find VSCode main PID
    vscode_pid = int(os.environ.get("VSCODE_PID", "0"))
    if not vscode_pid:
        vscode_pid = _find_vscode_main_pid(cli_pid, proc_map)
    result.vscode_pid = vscode_pid

    # Step 4: Get/create session key
    session_key = _get_or_create_session_key(session_id, marker_dir, tz_offset_hours)
    result.session_key = session_key

    # Step 5: Register in instance_lock
    sessions = _register_cli_in_lock(
        lock_path,
        session_id,
        session_key,
        cli_pid,
        vscode_pid,
        tz_offset_hours,
    )
    result.actions.append(f"REGISTER: {session_key} cli_pid={cli_pid} vscode_pid={vscode_pid}")

    # Step 6: Detect unregistered CLI suspects (log only, no kill)
    registered = {s.get("cli_pid") for s in sessions.values() if s.get("cli_pid")}
    registered.add(cli_pid)
    claude_procs = _find_claude_processes(all_procs)
    suspects = [cp.pid for cp in claude_procs if cp.pid not in registered]
    result.suspects = suspects
    if suspects:
        result.actions.append(
            f"SUSPECT: {len(suspects)} unregistered CLI(s): {','.join(map(str, suspects))}"
        )

    # Step 7: Clean stale sessions
    result.stale_cleaned = _clean_stale_from_lock(lock_path, proc_map)
    if result.stale_cleaned:
        result.actions.append(f"LOCK-CLEAN: removed {result.stale_cleaned} stale session(s)")

    return result


# ──────────────────────────────────────────────
# CLI entry point
# ──────────────────────────────────────────────


def main() -> None:
    """CLI: python -m cc_cortex.process_guard [--dry-run] [--verbose]"""
    import argparse

    parser = argparse.ArgumentParser(description="Claude Code Process Guard")
    parser.add_argument("--dry-run", action="store_true", help="Log but don't kill")
    parser.add_argument("--verbose", "-v", action="store_true")
    parser.add_argument("--lock-path", help="Path to instance_lock.json")
    parser.add_argument("--idle-minutes", type=int, default=IDLE_MINUTES)
    parser.add_argument("--stale-minutes", type=int, default=STALE_MINUTES)
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    result = run_guard(
        lock_path=args.lock_path,
        idle_minutes=args.idle_minutes,
        stale_minutes=args.stale_minutes,
        dry_run=args.dry_run,
    )

    for action in result.actions:
        print(action)
    for warning in result.warnings:
        print(f"WARN: {warning}")

    print(
        f"{'DRY-RUN' if args.dry_run else 'DONE'}: "
        f"scanned={result.scanned}, killed={result.killed}, "
        f"freed={result.freed_mb}MB, lock_cleaned={result.lock_cleaned}"
    )


if __name__ == "__main__":
    main()
