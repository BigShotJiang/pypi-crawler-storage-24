"""Warn Router — Single-channel priority router with cooldown and budget.

Accepts a list of (name, message) warning items sorted by priority,
applies mode filtering, per-name cooldown, and token budget, then
returns at most one message (single channel) to avoid alert fatigue.
"""

from __future__ import annotations

import json
import os
import time
from typing import Optional

# ─── Mode Definitions ─────────────────────────────────────

DEFAULT_MODES = {
    "off": frozenset(),
    "minimal": frozenset(
        {
            "token",
            "handoff",
            "sentinel",
        }
    ),
    "balanced": frozenset(
        {
            "token",
            "handoff",
            "sentinel",
            "awareness",
            "scavenger",
        }
    ),
    "full": frozenset(
        {
            "token",
            "handoff",
            "sentinel",
            "awareness",
            "scavenger",
            "token_info",
            "agent_gate",
            "char_limit",
            "rules_bloat",
            "autonomy",
        }
    ),
}

# Names exempt from budget throttle (always pass)
DEFAULT_BUDGET_EXEMPT = frozenset(
    {
        "token",
        "handoff",
        "sentinel",
    }
)

DEFAULT_COOLDOWNS = {
    "token": 0,
    "handoff": 0,
    "sentinel": 300,
    "awareness": 120,
    "scavenger": 300,
    "token_info": 600,
    "agent_gate": 120,
    "char_limit": 300,
    "rules_bloat": 300,
    "autonomy": 120,
}


# ─── Router ───────────────────────────────────────────────


def route(
    warn_items: list[tuple[str, Optional[str]]],
    state_path: str,
    *,
    mode: str = "balanced",
    modes: Optional[dict] = None,
    cooldowns: Optional[dict] = None,
    budget_limit: int = 1500,
    budget_exempt: Optional[frozenset] = None,
    default_cooldown: int = 120,
    overrides: Optional[dict] = None,
) -> list[str]:
    """Route warnings through mode/cooldown/budget filters.

    Args:
        warn_items: [(name, message), ...] ordered by priority.
        state_path: File path for cooldown/budget state persistence.
        mode: Active mode name (key in modes dict).
        modes: Override mode→active_names mapping.
        cooldowns: Override per-name cooldown seconds.
        budget_limit: Max token budget for non-exempt warnings.
        budget_exempt: Names that bypass budget check.
        default_cooldown: Fallback cooldown for unknown names.
        overrides: Per-name force on (True) / force off (False).

    Returns:
        List of at most 1 message string that passed all filters.
    """
    mode_map = modes or DEFAULT_MODES
    cd_map = cooldowns or DEFAULT_COOLDOWNS
    exempt = budget_exempt or DEFAULT_BUDGET_EXEMPT
    ovr = overrides or {}
    active = mode_map.get(mode, mode_map.get("balanced", set()))
    now = time.time()

    # Read state
    try:
        with open(state_path, "r", encoding="utf-8") as f:
            cd = json.load(f)
    except Exception:
        cd = {}

    budget_used = cd.get("_budget_used", 0)
    result: list[str] = []

    for name, msg in warn_items:
        if not msg:
            continue

        # Per-feature override
        override = ovr.get(name)
        if override is False:
            continue
        if override is not True and name not in active:
            continue

        # Budget check
        if name not in exempt and budget_used >= budget_limit:
            continue

        # Per-name cooldown
        cooldown = cd_map.get(name, default_cooldown)
        if cooldown > 0:
            last = cd.get(name, 0)
            if isinstance(last, (int, float)):
                if now - last < cooldown:
                    continue

        # Passed — take this one (single channel)
        result.append(msg)
        cd[name] = now
        if name not in exempt:
            budget_used += len(msg) // 4 + 10
        break

    # Update state
    cd["_budget_used"] = budget_used
    max_cd = max(cd_map.values()) if cd_map else 600
    cd = {
        k: v
        for k, v in cd.items()
        if k.startswith("_") or (isinstance(v, (int, float)) and now - v < max_cd)
    }
    cd["_budget_used"] = budget_used

    try:
        os.makedirs(os.path.dirname(state_path), exist_ok=True)
        with open(state_path, "w", encoding="utf-8") as f:
            json.dump(cd, f)
    except Exception:
        pass

    return result
