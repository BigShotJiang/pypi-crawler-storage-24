"""cc_cortex.attention_audit — Attention Budget lifecycle management.

Three scanning modes for the LLM-Proof Architecture:

1. **strike**  — Scan corrections for recurring patterns (three-strike upgrade)
2. **release** — Find hardened behaviors whose rules should be deleted
3. **audit**   — Token budget vs actual usage report
4. **upgrade** — Auto-promote (0-violation 30d) + auto-release (hardened→delete rule)

All paths are configurable via ``cc_cortex.core.config``.

Usage:
    from cc_cortex.attention_audit import scan_strikes, audit_budget
    results = scan_strikes(corrections_path)
    report = audit_budget(budget_path)

CLI:
    cc-cortex audit strike
    cc-cortex audit release
    cc-cortex audit budget
    cc-cortex audit upgrade [--dry]
"""

from __future__ import annotations

import json
import os
from collections import Counter
from datetime import datetime
from typing import Any

# ── Default category keywords (overridable via config) ──────────

DEFAULT_CATEGORY_KEYWORDS: dict[str, list[str]] = {
    "naming": ["naming", "prefix", "format"],
    "api": ["API", "index", "lookup"],
    "handoff": ["handoff", "dispatch", "ABCD", "role", "task"],
    "hook": ["hook", "stderr", "notify"],
    "architecture": ["architecture", "direction", "evolution"],
    "deploy": ["deploy", "VPS", "SSH", "key"],
    "knowledge": ["knowledge", "kb", "rule"],
}

ZERO_VIOLATION_DAYS = 30


# ── Helpers ─────────────────────────────────────────────────────


def _categorize(text: str, keywords: dict[str, list[str]]) -> str:
    """Categorize a correction by keyword matching."""
    lower = text.lower()
    for category, kws in keywords.items():
        if any(kw.lower() in lower for kw in kws):
            return category
    return "other"


def _deduplicate(corrections: list[dict]) -> list[dict]:
    """Remove exact duplicates (same correction text)."""
    seen: set[str] = set()
    unique: list[dict] = []
    for c in corrections:
        key = c.get("user_correction", "")[:80]
        if key not in seen:
            seen.add(key)
            unique.append(c)
    return unique


def _load_jsonl(path: str) -> list[dict]:
    """Load a JSONL file into a list of dicts."""
    items: list[dict] = []
    if not os.path.isfile(path):
        return items
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    items.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
    return items


def _load_json(path: str) -> dict:
    """Load a JSON file."""
    if not os.path.isfile(path):
        return {}
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


# ── Strike scan ─────────────────────────────────────────────────


def scan_strikes(
    corrections_path: str,
    category_keywords: dict[str, list[str]] | None = None,
) -> dict[str, Any]:
    """Scan corrections for recurring patterns.

    Returns:
        {
            "total": int, "unique": int,
            "categories": {name: {"count": int, "level": str, "example": str}},
            "hard_count": int, "soft_count": int,
        }
    """
    kws = category_keywords or DEFAULT_CATEGORY_KEYWORDS
    corrections = _load_jsonl(corrections_path)
    unique = _deduplicate(corrections)

    counts: Counter[str] = Counter()
    examples: dict[str, str] = {}
    for c in unique:
        text = c.get("user_correction", "")
        cat = _categorize(text, kws)
        counts[cat] += 1
        if cat not in examples:
            examples[cat] = text[:60]

    categories: dict[str, dict] = {}
    for cat, count in counts.most_common():
        level = "HARD" if count >= 3 else ("SOFT" if count >= 2 else "OK")
        categories[cat] = {"count": count, "level": level, "example": examples.get(cat, "")}

    return {
        "total": len(corrections),
        "unique": len(unique),
        "categories": categories,
        "hard_count": sum(1 for v in categories.values() if v["level"] == "HARD"),
        "soft_count": sum(1 for v in categories.values() if v["level"] == "SOFT"),
    }


# ── Release scan ────────────────────────────────────────────────


def scan_release_candidates(budget_path: str) -> list[dict]:
    """Find hardened/hooked behaviors whose rules should be deleted.

    Returns list of behavior dicts that are candidates for rule deletion.
    """
    budget = _load_json(budget_path)
    if not budget:
        return []

    candidates: list[dict] = []
    for b in budget.get("behaviors", []):
        stage = b.get("stage", "")
        rule_status = b.get("rule_status", "")
        if rule_status in ("deleted", "released"):
            continue
        if stage in ("hardened", "hooked"):
            candidates.append(b)

    return candidates


# ── Auto upgrade ────────────────────────────────────────────────


def auto_upgrade(
    budget_path: str,
    dry_run: bool = False,
) -> dict[str, Any]:
    """Two-phase auto-upgrade engine.

    Phase 1: 0-violation ≥30 days → candidate_for_hardening
    Phase 2: hardened + rule not deleted → mark deleted

    Returns {"promoted": [...], "released": [...], "written": bool}
    """
    budget = _load_json(budget_path)
    if not budget:
        return {"promoted": [], "released": [], "written": False}

    behaviors = budget.get("behaviors", [])
    today_str = datetime.now().strftime("%Y-%m-%d")
    today = datetime.strptime(today_str, "%Y-%m-%d")

    promoted: list[str] = []
    released: list[str] = []

    # Phase 1: zero-violation promote
    for b in behaviors:
        if b.get("stage", "") not in ("learning", "hooked"):
            continue
        if b.get("rule_status") in ("deleted", "released"):
            continue
        if b.get("violation_count", 0) > 0:
            continue

        zero_since = b.get("zero_since")
        if not zero_since:
            if not dry_run:
                b["zero_since"] = today_str
            continue

        try:
            zero_date = datetime.strptime(zero_since, "%Y-%m-%d")
        except ValueError:
            continue

        if (today - zero_date).days >= ZERO_VIOLATION_DAYS:
            promoted.append(b.get("name", "?"))
            if not dry_run:
                b["stage"] = "candidate_for_hardening"
                b["promoted_date"] = today_str

    # Phase 2: hardened release
    for b in behaviors:
        if b.get("stage") != "hardened":
            continue
        if b.get("rule_status") in ("deleted", "released"):
            continue
        released.append(b.get("name", "?"))
        if not dry_run:
            b["rule_status"] = "deleted"
            b["released_date"] = today_str
            b["action"] = "done"

    written = False
    if not dry_run and (promoted or released):
        old_tokens = budget.get("current_estimated_tokens", 0)
        budget["last_audit"] = today_str
        budget["current_estimated_tokens"] = max(0, old_tokens - len(released) * 200)
        with open(budget_path, "w", encoding="utf-8") as f:
            json.dump(budget, f, ensure_ascii=False, indent=2)
            f.write("\n")
        written = True

    return {"promoted": promoted, "released": released, "written": written}


# ── Budget audit ────────────────────────────────────────────────


def audit_budget(budget_path: str) -> dict[str, Any]:
    """Audit attention budget: token usage vs target.

    Returns summary dict with counts and recommendations.
    """
    budget = _load_json(budget_path)
    if not budget:
        return {"error": "budget file not found"}

    target = budget.get("budget_target_tokens", 3000)
    current = budget.get("current_estimated_tokens", 0)
    delta = current - target
    behaviors = budget.get("behaviors", [])

    active = [b for b in behaviors if b.get("rule_status") == "active"]
    released = [b for b in behaviors if b.get("rule_status") in ("deleted", "released")]
    redundant = [b for b in behaviors if b.get("rule_status") in ("redundant", "partial_redundant")]
    hardened_not_released = [
        b for b in behaviors
        if b.get("stage") in ("hardened", "hooked")
        and b.get("rule_status") not in ("deleted", "released")
    ]

    recommendations: list[str] = []
    if hardened_not_released:
        recommendations.append(
            f"Release {len(hardened_not_released)} hardened rule(s) to reclaim tokens"
        )
    if delta > 0 and redundant:
        recommendations.append(
            f"Remove {len(redundant)} redundant rule(s) to save ~{len(redundant) * 200} tokens"
        )

    return {
        "budget_target": target,
        "current_estimated": current,
        "delta": delta,
        "over_budget": delta > 0,
        "total_behaviors": len(behaviors),
        "active_count": len(active),
        "released_count": len(released),
        "redundant_count": len(redundant),
        "hardened_not_released": len(hardened_not_released),
        "release_candidates": [b.get("name", "?") for b in hardened_not_released],
        "recommendations": recommendations,
    }


# ── CLI formatting ──────────────────────────────────────────────


def format_strike_report(result: dict) -> str:
    """Format strike scan result as human-readable text."""
    lines = [
        f"Corrections: {result['total']} total, {result['unique']} unique",
        "",
    ]
    for cat, info in result.get("categories", {}).items():
        icon = "!!!" if info["level"] == "HARD" else (" ! " if info["level"] == "SOFT" else " . ")
        lines.append(f"[{icon}] {cat}: {info['count']}x → {info['level']}")
        lines.append(f"      example: {info['example']}")
    lines.append("")
    lines.append(f"Upgrade: {result['hard_count']} HARD + {result['soft_count']} SOFT")
    return "\n".join(lines)


def format_budget_report(result: dict) -> str:
    """Format budget audit result as human-readable text."""
    if "error" in result:
        return f"Error: {result['error']}"
    status = "OVER BUDGET" if result["over_budget"] else "OK"
    lines = [
        f"Target: {result['budget_target']} | Current: {result['current_estimated']} | "
        f"Delta: {result['delta']:+d} [{status}]",
        f"Behaviors: {result['total_behaviors']} total | "
        f"{result['active_count']} active | {result['released_count']} released | "
        f"{result['redundant_count']} redundant | "
        f"{result['hardened_not_released']} hardened (unreleased)",
    ]
    if result["recommendations"]:
        lines.append("")
        for r in result["recommendations"]:
            lines.append(f"  → {r}")
    return "\n".join(lines)
