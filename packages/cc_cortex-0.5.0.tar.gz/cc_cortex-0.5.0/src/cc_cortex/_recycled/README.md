# Recycled Modules — Future Potential

Modules kept in-place (not moved) to avoid breaking imports.
Removed from active pipeline because ROI = (effect × value) - (attention cost) was **negative**.

## Recycled from Pipeline

| Module | Was | ROI Problem | Revival Condition |
|--------|-----|------------|-------------------|
| `cognitive.py` | PostToolUse adaptive thresholds | Soft adjusts soft = 0 effect | CC gains stateful hook memory |
| `three_layer.py` | Prompt generation | No injection point = 0 effect | CC gains system prompt injection |
| `boundary_guard.py` | PreToolUse warn | Too subjective, model ignores | Gets concrete rules + hard deny |
| `rules_guard.py` | PreToolUse warn | User-managed, model can't fix | CC adds auto-prune capability |

## Converted (no longer soft)

These WERE soft warnings, now upgraded:

| Module | Was Soft | Now Hard | How |
|--------|----------|----------|-----|
| `pre_tool_guards.bash_guard` | warn long-running | **deny** without background | `gate_bash_background()` |
| `pre_tool_guards.python_guard` | warn python -c >5 lines | **deny** python -c >5 lines | `gate_python_c()` |
| `pre_tool_guards.read_first` | warn edit-without-read | **deny** for files >50 lines | `gate_read_first()` |
| `agent_gate` soft warn | additionalContext | **stderr only** (zero model cost) | User sees, model doesn't |
| `sentinel` soft warn | additionalContext | **stderr only** + **deny gate** | Soft→stderr, hard→deny at N |

## Zero-Cost Conversions (stderr only)

These still work but no longer waste model attention:
- `agent_gate` warn → stderr yellow text (user sees #3, #4 counts)
- `sentinel` warn → via warn_router to stderr
- `scope_warn` → via warn_router to stderr

## Vestigial Code (Cleaned Up)

| Module | Was | Now |
|--------|-----|-----|
| `agent_gate.check()` warn | additionalContext escalation | Replaced by `gate_agent_cap()` hard deny + stderr counter |
| `warn_router.py` | Mode/cooldown/budget filter for soft warns | Almost nothing routes through it. Soft warns → hard deny or stderr. Kept importable but no longer in main pipeline |
| `_run_rules_bloat()` | PreToolUse warn | Recycled (negative ROI) |
| `_run_boundary_guard()` | PreToolUse warn | Recycled (negative ROI) |

## Policy

- Don't delete recycled modules — keep importable
- Review when Claude Code architecture changes
- To revive: must have hard enforcement mechanism (deny or lint-level error)
