"""cc_cortex.pre_tool_guards — Generic PreToolUse guards.

Guards:
1. BashGuard       — long-running commands without ``run_in_background`` (warn)
2. PythonGuard     — complex ``python -c`` one-liners (>5 lines) (warn)
3. ReadFirst warn  — editing files without reading them first (warn)
4. ReadFirst gate  — DENY Edit/Write on existing files not yet Read (hard gate)

Integrate via ``on_pre_tool.py``.
"""

from __future__ import annotations

import json
import os
import re
from typing import Optional

# ── BashGuard ──────────────────────────────────────────────────

_LONG_RUNNING_RE = re.compile(
    r"(?:^|\s)(?:"
    r"npm\s+(?:start|run\s+dev|run\s+serve)"
    r"|npx\s+(?:vite|next)\s+dev"
    r"|python\s+-m\s+(?:http\.server|uvicorn|flask)"
    r"|uvicorn\s+"
    r"|flask\s+run"
    r"|gunicorn\s+"
    r"|while\s+(?:true|:|\[\[)"
    r"|tail\s+-[fF]"
    r"|docker\s+compose\s+up(?!\s+.*-d)"
    r"|watch\s+"
    r"|node\s+.*server"
    r")",
    re.IGNORECASE,
)


def check_bash(tool_input: dict) -> list[str]:
    """Check Bash tool input for risky patterns. Returns warning list."""
    warnings: list[str] = []
    cmd = tool_input.get("command", "")
    bg = tool_input.get("run_in_background", False)

    # Long-running command without background
    if not bg and _LONG_RUNNING_RE.search(cmd):
        warnings.append(
            "⚠ [BashGuard] Detected potentially long-running command "
            "(server/watch/while/tail -f). Use run_in_background: true "
            "to avoid session deadlock."
        )

    # Sleep > 30s without background
    sleep_m = re.search(r"sleep\s+(\d+)", cmd)
    if sleep_m and int(sleep_m.group(1)) > 30 and not bg:
        warnings.append(
            "⚠ [BashGuard] sleep > 30s detected. Use run_in_background: true."
        )

    return warnings


# ── PythonGuard ────────────────────────────────────────────────


def check_python_c(tool_input: dict) -> Optional[str]:
    """Check for complex python -c commands (>5 lines). Returns warning or None."""
    cmd = tool_input.get("command", "")
    if "python" in cmd and " -c " in cmd and cmd.count("\n") >= 5:
        return (
            "⚠ [PythonGuard] python -c exceeds 5 lines. "
            "Write a .py script instead to avoid syntax and encoding issues."
        )
    return None


def gate_python_c(tool_input: dict) -> Optional[dict]:
    """DENY python -c commands with >5 lines. Returns deny dict or None."""
    cmd = tool_input.get("command", "")
    if "python" in cmd and " -c " in cmd and cmd.count("\n") >= 5:
        return {
            "permissionDecision": "deny",
            "reason": "PythonGuard Gate: python -c exceeds 5 lines",
            "additionalContext": (
                "Complex python -c one-liners (>5 lines) cause syntax and "
                "encoding issues. Write a .py script file instead, then run it."
            ),
        }
    return None


def gate_bash_background(tool_input: dict) -> Optional[dict]:
    """DENY long-running Bash commands without run_in_background. Returns deny dict or None."""
    cmd = tool_input.get("command", "")
    bg = tool_input.get("run_in_background", False)

    if not bg and _LONG_RUNNING_RE.search(cmd):
        return {
            "permissionDecision": "deny",
            "reason": "BashGuard Gate: long-running command without background",
            "additionalContext": (
                "This command (server/watch/while/tail -f) will block the session. "
                "Re-run with run_in_background: true to avoid deadlock."
            ),
        }
    return None


# ── ReadFirst ──────────────────────────────────────────────────

_READFIRST_SKIP_EXTS = frozenset({
    ".json", ".jsonl", ".env", ".log", ".tmp", ".lock",
})

_READFIRST_SKIP_BASENAMES = frozenset({
    "package-lock.json", "pnpm-lock.yaml", "yarn.lock",
})


def _read_log_path(cache_dir: str, session_id: str) -> str:
    """Return path to the session's read-log file."""
    short = session_id[:8] if session_id else "unknown"
    return os.path.join(cache_dir, "read_log", f"{short}.json")


def log_read(file_path: str, cache_dir: str, session_id: str) -> None:
    """Record a Read operation for this session."""
    try:
        log_path = _read_log_path(cache_dir, session_id)
        os.makedirs(os.path.dirname(log_path), exist_ok=True)

        data: dict = {"reads": [], "updated": ""}
        if os.path.isfile(log_path):
            with open(log_path, "r", encoding="utf-8") as f:
                data = json.load(f)

        normalized = os.path.normpath(file_path).replace("\\", "/").lower()
        reads: list = data.get("reads", [])
        if normalized not in reads:
            reads.append(normalized)
            data["reads"] = reads
            from datetime import datetime, timedelta, timezone

            data["updated"] = datetime.now(timezone(timedelta(hours=8))).isoformat()
            with open(log_path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False)
    except Exception:
        pass


def check_read_first(
    file_path: str,
    cache_dir: str,
    session_id: str,
) -> Optional[str]:
    """Check if file was Read before Edit/Write. Returns warning or None."""
    try:
        # Skip new files
        if not os.path.exists(file_path):
            return None

        # Skip config/lock/log files
        lower = file_path.lower()
        basename = os.path.basename(lower)
        _, ext = os.path.splitext(lower)
        if ext in _READFIRST_SKIP_EXTS or basename in _READFIRST_SKIP_BASENAMES:
            return None

        log_path = _read_log_path(cache_dir, session_id)
        if not os.path.isfile(log_path):
            short_path = file_path.replace("\\", "/")
            return (
                f"⚠ [ReadFirst] {short_path} not yet read this session. "
                f"Read before editing to avoid overwriting unfamiliar content."
            )

        with open(log_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        normalized = os.path.normpath(file_path).replace("\\", "/").lower()
        reads = data.get("reads", [])
        if normalized not in reads:
            short_path = file_path.replace("\\", "/")
            return (
                f"⚠ [ReadFirst] {short_path} not yet read this session. "
                f"Read before editing to avoid overwriting unfamiliar content."
            )

        return None
    except Exception:
        return None


# ── ReadFirst Gate (HARD DENY) ────────────────────────────────

# Files that were created (Write) this session — skip deny for these
_CREATED_THIS_SESSION: set[str] = set()


def log_write_create(file_path: str) -> None:
    """Record that a file was created via Write this session (skip deny)."""
    if file_path:
        _CREATED_THIS_SESSION.add(
            os.path.normpath(file_path).replace("\\", "/").lower()
        )


def gate_read_first(
    file_path: str,
    cache_dir: str,
    session_id: str,
    *,
    min_lines: int = 50,
) -> Optional[dict]:
    """DENY Edit/Write on existing files not yet Read this session.

    Returns deny dict for PreToolUse hook, or None if allowed.

    Exceptions (no deny):
      - File doesn't exist yet (new file)
      - File was created via Write this session
      - File has fewer than min_lines lines
      - File is in skip list (json/lock/log/etc.)

    Performance: <2ms (stat + read log JSON).
    """
    try:
        if not file_path or not os.path.exists(file_path):
            return None

        # Skip config/lock/log files
        lower = file_path.lower()
        basename = os.path.basename(lower)
        _, ext = os.path.splitext(lower)
        if ext in _READFIRST_SKIP_EXTS or basename in _READFIRST_SKIP_BASENAMES:
            return None

        # Skip files created this session
        normalized = os.path.normpath(file_path).replace("\\", "/").lower()
        if normalized in _CREATED_THIS_SESSION:
            return None

        # Skip small files
        try:
            line_count = 0
            with open(file_path, "r", encoding="utf-8", errors="replace") as f:
                for _ in f:
                    line_count += 1
                    if line_count >= min_lines:
                        break
            if line_count < min_lines:
                return None
        except Exception:
            return None

        # Check read log
        log_path = _read_log_path(cache_dir, session_id)
        if os.path.isfile(log_path):
            with open(log_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if normalized in data.get("reads", []):
                return None

        short_path = os.path.basename(file_path)
        return {
            "permissionDecision": "deny",
            "reason": (
                f"ReadFirst Gate: {short_path} ({line_count}+ lines) "
                f"not yet Read this session"
            ),
            "additionalContext": (
                f"You must Read {file_path} before editing it. "
                f"This file has {line_count}+ lines — editing without reading "
                f"risks overwriting content you haven't seen."
            ),
        }
    except Exception:
        return None  # fail-open
