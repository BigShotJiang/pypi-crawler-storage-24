"""Window Flash Guard — Prevent console window flashing on Windows.

Detects Bash commands that spawn visible console windows (schtasks,
reg, wmic, etc.) and blocks them unless wrapped with a hidden executor.
"""

from __future__ import annotations

import re
from typing import Optional

# Commands that flash a console window on Windows
_FLASH_CMDS = re.compile(
    r"\b(?:schtasks|reg\b|msiexec|wmic|netsh|sc\s"
    r"|runas|certutil|bitsadmin|mshta)\b",
    re.IGNORECASE,
)

# Hidden wrappers that suppress the window
_HIDDEN_WRAPPERS = re.compile(
    r"run-hidden\.pyw|run-hidden-utf8\.ps1|Run-Hidden\b",
    re.IGNORECASE,
)

DEFAULT_MESSAGE = (
    "Window Flash Guard: `{cmd}` spawns a visible console window. "
    "Wrap with a hidden executor to prevent flashing."
)


def check(
    tool_name: str,
    tool_input: dict,
    *,
    message: Optional[str] = None,
) -> Optional[dict]:
    """Check if a Bash command would flash a console window.

    Args:
        tool_name: Must be "Bash" to trigger.
        tool_input: Tool input dict with "command" key.
        message: Override message template ({cmd} placeholder).

    Returns:
        Dict {permissionDecision: "deny", cmd, message} or None.
    """
    if tool_name != "Bash":
        return None
    command = tool_input.get("command", "") if isinstance(tool_input, dict) else ""
    if not command:
        return None
    if _HIDDEN_WRAPPERS.search(command):
        return None
    match = _FLASH_CMDS.search(command)
    if not match:
        return None

    cmd_found = match.group(0)
    msg = (message or DEFAULT_MESSAGE).format(cmd=cmd_found)
    return {"permissionDecision": "deny", "cmd": cmd_found, "reason": msg}
