"""Feature Configuration — risk metadata, validation, and safe get/set.

Every feature has:
  - enabled: bool (default True)
  - numeric params with min/max/recommended + risk descriptions
  - validate() returns risk warnings before applying changes

Usage:
    from cc_cortex.feature_config import list_features, get_feature, set_feature
    features = list_features()                   # all features + current values
    info = get_feature("agent_cap")              # single feature with risks
    warnings = set_feature("agent_cap", "max_spawns", 3)  # set + get risks
"""

from __future__ import annotations

from typing import Any, Optional

# ── Risk Metadata ─────────────────────────────────────────

FEATURE_META: dict[str, dict] = {
    # ── Hard Gates ──
    "token_gate": {
        "category": "hard_gate",
        "description": "Block Agent spawn when context tokens exceed threshold",
        "description_zh": "Token 超過閾值時阻擋 Agent spawn",
        "params": {
            "agent_threshold": {
                "type": "int",
                "default": 140000,
                "min": 80000,
                "max": 180000,
                "recommended": 140000,
                "risk_low": (
                    "Below 80K blocks agents too early"
                    " — breaks normal multi-agent workflows"
                ),
                "risk_high": "Above 180K risks context overflow — session may corrupt",
                "risk_low_zh": "低於 80K 會過早擋 Agent，正常多代理工作流會壞掉",
                "risk_high_zh": "高於 180K 有上下文溢出風險，session 可能損壞",
            },
            "critical_threshold": {
                "type": "int",
                "default": 160000,
                "min": 120000,
                "max": 195000,
                "recommended": 160000,
                "risk_low": "Below 120K triggers urgent handoff too early",
                "risk_high": "Above 195K is dangerously close to context limit",
                "risk_low_zh": "低於 120K 會過早觸發緊急交接",
                "risk_high_zh": "高於 195K 危險接近上下文極限",
            },
        },
    },
    "read_first_gate": {
        "category": "hard_gate",
        "description": "Block Edit/Write on existing files not yet Read this session",
        "description_zh": "阻擋未讀就改的操作（防止盲改）",
        "params": {
            "min_lines": {
                "type": "int",
                "default": 50,
                "min": 10,
                "max": 500,
                "recommended": 50,
                "risk_low": "Below 10 blocks edits on tiny files — too aggressive",
                "risk_high": "Above 500 only catches very large files — misses most blind edits",
                "risk_low_zh": "低於 10 連小檔案都擋，太激進",
                "risk_high_zh": "高於 500 只擋超大檔案，大部分盲改抓不到",
            },
        },
    },
    "agent_cap": {
        "category": "hard_gate",
        "description": "Block Agent spawn after N times per session",
        "description_zh": "同一 session 超過 N 次 Agent spawn 後阻擋",
        "params": {
            "max_spawns": {
                "type": "int",
                "default": 5,
                "min": 2,
                "max": 20,
                "recommended": 5,
                "risk_low": (
                    "Below 2 blocks almost all agent use"
                    " — Explore/Plan agents become unusable"
                ),
                "risk_high": "Above 20 effectively disables the cap — token waste from agent spam",
                "risk_low_zh": "低於 2 幾乎擋掉所有 Agent 用途，Explore/Plan 無法使用",
                "risk_high_zh": "高於 20 等於沒上限，Agent 濫用浪費 token",
            },
        },
    },
    "sentinel_gate": {
        "category": "hard_gate",
        "description": "Block repeated Edit on same file N+ times (with lint exception)",
        "description_zh": "同檔案連續 Edit N+ 次時阻擋（lint 修復例外）",
        "params": {
            "max_repeats": {
                "type": "int",
                "default": 5,
                "min": 3,
                "max": 15,
                "recommended": 5,
                "risk_low": "Below 3 may false-positive on legitimate 2-step refactors",
                "risk_high": (
                    "Above 15 only catches extreme loops"
                    " — most stuck patterns slip through"
                ),
                "risk_low_zh": "低於 3 正常的兩步重構可能被誤擋",
                "risk_high_zh": "高於 15 只擋極端迴圈，大多數卡住模式會漏掉",
            },
            "lint_exception": {
                "type": "bool",
                "default": True,
                "recommended": True,
                "risk_off": "Disabling lint exception will block legitimate fix iterations",
                "risk_off_zh": "關閉 lint 例外會擋掉正常的修復迭代",
            },
        },
    },
    # ── Hard Quality ──
    "code_guard": {
        "category": "hard_quality",
        "description": "Python(ruff) / Rust(cargo) / Go(vet) static analysis",
        "description_zh": "Python/Rust/Go 靜態分析",
        "params": {},
    },
    "typescript": {
        "category": "hard_quality",
        "description": "tsc --noEmit type checking with SHA256 cache",
        "description_zh": "TypeScript 型別檢查（有快取）",
        "params": {},
    },
    "linting": {
        "category": "hard_quality",
        "description": "ESLint for JavaScript files",
        "description_zh": "JavaScript ESLint 檢查",
        "params": {},
    },
    "handoff_format": {
        "category": "hard_quality",
        "description": "Validate handoff file structure on write",
        "description_zh": "寫交接檔時驗證結構（lint 級錯誤）",
        "params": {},
    },
    # ── UX ──
    "streak_ux": {
        "category": "ux",
        "description": "Clean edit streak celebrations (🔥x5, ✅ fixed, etc.)",
        "description_zh": "連擊慶祝（🔥x5、✅ 修復 等）",
        "params": {
            "milestone_interval": {
                "type": "int",
                "default": 5,
                "min": 1,
                "max": 50,
                "recommended": 5,
                "risk_low": "At 1, every single edit triggers celebration — noise",
                "risk_high": "Above 50, celebrations are so rare they lose motivational impact",
                "risk_low_zh": "設 1 每次編輯都慶祝，變噪音",
                "risk_high_zh": "超過 50 太少慶祝，失去激勵效果",
            },
        },
    },
    "session_summary": {
        "category": "ux",
        "description": "Visual session end summary (token/streak/files box)",
        "description_zh": "Session 結束時視覺化摘要框",
        "params": {},
    },
    "deny_marker": {
        "category": "ux",
        "description": "Red ANSI counter on every deny (✖ 阻擋 #N)",
        "description_zh": "每次阻擋時的紅色計數通知",
        "params": {},
    },
    # ── Soft Warnings ──
    "bash_guard": {
        "category": "soft",
        "description": "Long-running command detection",
        "description_zh": "偵測長時間執行的指令",
        "params": {},
    },
    "python_guard": {
        "category": "soft",
        "description": "Complex python -c one-liner detection",
        "description_zh": "偵測過長的 python -c 指令",
        "params": {},
    },
    "read_first_warn": {
        "category": "soft",
        "description": "Warn (not block) on edit-without-read for small files",
        "description_zh": "小檔案未讀就改時的軟提醒",
        "params": {},
    },
    "boundary_guard": {
        "category": "soft",
        "description": "Hook/library boundary violation detection",
        "description_zh": "偵測 Hook/庫邊界違規",
        "params": {},
    },
    "rules_bloat": {
        "category": "soft",
        "description": ".claude/rules/ size guard",
        "description_zh": ".claude/rules/ 膨脹警告",
        "params": {
            "max_tokens": {
                "type": "int",
                "default": 3000,
                "min": 500,
                "max": 10000,
                "recommended": 3000,
                "risk_low": "Below 500 triggers on minimal rule sets",
                "risk_high": "Above 10000 defeats the purpose of the guard",
                "risk_low_zh": "低於 500 連最小的規則集都會觸發",
                "risk_high_zh": "高於 10000 等於沒有這個守衛",
            },
        },
    },
    "agent_gate_warn": {
        "category": "soft",
        "description": "Agent spawn count soft warning (before cap)",
        "description_zh": "Agent spawn 計數軟提醒（在 cap 之前）",
        "params": {
            "warn_at": {
                "type": "int",
                "default": 3,
                "min": 1,
                "max": 10,
                "recommended": 3,
                "risk_low": "At 1, warns on every single agent — noise",
                "risk_high": "Above 10 may never warn before cap kicks in",
                "risk_low_zh": "設 1 每個 Agent 都警告，太吵",
                "risk_high_zh": "超過 10 可能在 cap 擋住前都不會警告",
            },
        },
    },
    "sentinel_warn": {
        "category": "soft",
        "description": "Behavioral pattern soft warnings (before gate)",
        "description_zh": "行為模式軟警告（在 gate 之前）",
        "params": {},
    },
    "scope_warn": {
        "category": "soft",
        "description": "Too many files modified warning",
        "description_zh": "修改過多檔案的警告",
        "params": {
            "max_files": {
                "type": "int",
                "default": 10,
                "min": 3,
                "max": 50,
                "recommended": 10,
                "risk_low": "Below 3 triggers on most multi-file tasks",
                "risk_high": "Above 50 effectively disables scope detection",
                "risk_low_zh": "低於 3 大部分多檔任務都會觸發",
                "risk_high_zh": "超過 50 等於關掉範疇偵測",
            },
        },
    },
    # ── Language Enforcement ──
    "language_enforce": {
        "category": "context",
        "description": (
            "Inject language enforcement on every tool call"
            " — forces thinking + responses in configured language"
        ),
        "description_zh": "每次工具呼叫注入語言強制 — 思考和回答都用設定語言",
        "params": {
            "language": {
                "type": "str",
                "default": "English",
                "recommended": "English",
                "risk_off": (
                    "Disabling removes language enforcement"
                    " — model may switch languages unpredictably"
                ),
                "risk_off_zh": "關閉後模型可能隨意切換語言",
            },
        },
    },
}


# ── Public API ────────────────────────────────────────────


def list_features(lang: str = "en") -> list[dict]:
    """List all features with current config values."""
    try:
        from cc_cortex.core.config import get_config

        cfg = get_config()
    except Exception:
        cfg = None

    result = []
    for name, meta in FEATURE_META.items():
        desc = meta.get(f"description_{lang}", meta["description"])
        current = cfg.feature_all(name) if cfg else {}
        result.append({
            "name": name,
            "category": meta["category"],
            "description": desc,
            "enabled": current.get("enabled", True),
            "params": {
                k: {
                    "value": current.get(k, v.get("default")),
                    "default": v.get("default"),
                    "recommended": v.get("recommended"),
                }
                for k, v in meta.get("params", {}).items()
            },
        })
    return result


def get_feature(name: str, lang: str = "en") -> Optional[dict]:
    """Get feature info with full risk metadata."""
    meta = FEATURE_META.get(name)
    if not meta:
        return None

    try:
        from cc_cortex.core.config import get_config

        cfg = get_config()
        current = cfg.feature_all(name)
    except Exception:
        current = {}

    desc = meta.get(f"description_{lang}", meta["description"])
    params = {}
    for k, v in meta.get("params", {}).items():
        risk_suffix = f"_{lang}" if lang != "en" else ""
        params[k] = {
            "value": current.get(k, v.get("default")),
            **v,
        }
        # Add localized risk text if available
        for risk_key in ("risk_low", "risk_high", "risk_off"):
            localized = v.get(f"{risk_key}{risk_suffix}")
            if localized:
                params[k][risk_key] = localized

    return {
        "name": name,
        "category": meta["category"],
        "description": desc,
        "enabled": current.get("enabled", True),
        "params": params,
    }


def validate_value(name: str, key: str, value: Any) -> list[str]:
    """Validate a value change and return risk warnings (empty = safe)."""
    meta = FEATURE_META.get(name)
    if not meta:
        return [f"Unknown feature: {name}"]

    if key == "enabled":
        if not isinstance(value, bool):
            return [f"enabled must be bool, got {type(value).__name__}"]
        return []

    param = meta.get("params", {}).get(key)
    if not param:
        return [f"Unknown param: {name}.{key}"]

    warnings = []
    ptype = param.get("type", "int")

    if ptype == "int":
        if not isinstance(value, int):
            return [f"{name}.{key} must be int, got {type(value).__name__}"]
        if "min" in param and value < param["min"]:
            warnings.append(
                f"⚠ {name}.{key}={value} below minimum {param['min']}. "
                f"{param.get('risk_low', '')}"
            )
        elif "max" in param and value > param["max"]:
            warnings.append(
                f"⚠ {name}.{key}={value} above maximum {param['max']}. "
                f"{param.get('risk_high', '')}"
            )
        rec = param.get("recommended")
        if rec is not None and value != rec:
            warnings.append(
                f"ℹ Recommended: {name}.{key}={rec} (you set {value})"
            )

    elif ptype == "bool":
        if not isinstance(value, bool):
            return [f"{name}.{key} must be bool, got {type(value).__name__}"]
        if not value and "risk_off" in param:
            warnings.append(f"⚠ {param['risk_off']}")

    return warnings


def set_feature(
    name: str, key: str, value: Any, *, force: bool = False,
) -> list[str]:
    """Set a feature config value. Returns risk warnings.

    If force=False and there are warnings, does NOT apply the change.
    If force=True, applies regardless of warnings.
    """
    warnings = validate_value(name, key, value)

    if warnings and not force:
        warnings.append("→ Use force=True to apply anyway.")
        return warnings

    try:
        from cc_cortex.core.config import get_config

        cfg = get_config()
        cfg.set_feature(name, key, value)
    except Exception as e:
        return [f"Failed to set: {e}"]

    return warnings
