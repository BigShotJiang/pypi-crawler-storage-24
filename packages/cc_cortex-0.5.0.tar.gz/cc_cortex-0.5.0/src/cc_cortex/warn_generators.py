"""Warn Generators — Named warning producers for PostToolUse routing.

Each generator returns (name, message) or None.
Name must match a key in warn_router.DEFAULT_COOLDOWNS.

Generators:
  - awareness  : Script KB reminders (wraps script_kb)
  - scavenger  : Stale session marker detection
  - char_limit : Oversized content warnings
"""

from __future__ import annotations

import os
import time
from typing import Optional

# ── awareness (wraps script_kb) ─────────────────────────────

_WRITE_TOOLS = frozenset({"Write", "Edit", "NotebookEdit", "MultiEdit"})


def gen_awareness(
    tool_name: str, tool_input: dict
) -> Optional[tuple[str, str]]:
    """Remind to check KB when writing scripts with known APIs."""
    if tool_name not in _WRITE_TOOLS:
        return None
    try:
        from cc_cortex.hooks.script_kb import check_script_kb

        warnings = check_script_kb(tool_input, tool_name)
        if warnings:
            return ("awareness", "\n".join(warnings))
    except (ImportError, Exception):
        pass
    return None


# ── scavenger (stale session detection) ─────────────────────

_DEFAULT_MARKER_DIR = os.path.join(
    os.environ.get("CLAUDE_PROJECT_DIR", "."),
    ".cc_cortex_cache",
    "sessions",
)

_STALE_THRESHOLD = 24 * 3600  # 24 hours


def gen_scavenger(
    tool_name: str,
    tool_input: dict,
    *,
    marker_dir: str = "",
    stale_threshold: float = _STALE_THRESHOLD,
) -> Optional[tuple[str, str]]:
    """Detect stale session markers (orphaned from dead sessions).

    Only triggers on write tools to avoid noise on every read.
    """
    if tool_name not in _WRITE_TOOLS:
        return None

    mdir = marker_dir or _DEFAULT_MARKER_DIR
    if not os.path.isdir(mdir):
        return None

    now = time.time()
    stale: list[str] = []
    try:
        for fname in os.listdir(mdir):
            fpath = os.path.join(mdir, fname)
            if not os.path.isfile(fpath):
                continue
            age = now - os.path.getmtime(fpath)
            if age > stale_threshold:
                stale.append(fname)
    except OSError:
        return None

    if not stale:
        return None

    count = len(stale)
    names = ", ".join(stale[:3])
    suffix = f" +{count - 3}" if count > 3 else ""
    return (
        "scavenger",
        f"[Scavenger] {count} stale session marker(s): {names}{suffix}"
        f" — consider running /tidy",
    )


# ── char_limit (oversized content warning) ──────────────────

_LINE_THRESHOLD = 500
_CHAR_THRESHOLD = 50_000


def gen_char_limit(
    tool_name: str,
    tool_input: dict,
    *,
    line_threshold: int = _LINE_THRESHOLD,
    char_threshold: int = _CHAR_THRESHOLD,
) -> Optional[tuple[str, str]]:
    """Warn when written content is very large (risk of truncation/slow edit)."""
    if tool_name not in _WRITE_TOOLS:
        return None

    content = tool_input.get("content") or tool_input.get("new_string") or ""
    if not content:
        return None

    lines = content.count("\n") + 1
    chars = len(content)

    if lines >= line_threshold:
        return (
            "char_limit",
            f"[CharLimit] Written content is {lines} lines — consider splitting.",
        )
    if chars >= char_threshold:
        return (
            "char_limit",
            f"[CharLimit] Written content is {chars:,} chars — consider splitting.",
        )
    return None


# ── Collect all generators ──────────────────────────────────

def collect_warnings(
    tool_name: str,
    tool_input: dict,
    *,
    marker_dir: str = "",
) -> list[tuple[str, str]]:
    """Run all warn generators, return list of (name, msg) tuples."""
    items: list[tuple[str, str]] = []
    for gen in (gen_awareness, gen_scavenger, gen_char_limit):
        try:
            if gen is gen_scavenger:
                result = gen(tool_name, tool_input, marker_dir=marker_dir)
            else:
                result = gen(tool_name, tool_input)
            if result:
                items.append(result)
        except Exception:
            continue
    return items
