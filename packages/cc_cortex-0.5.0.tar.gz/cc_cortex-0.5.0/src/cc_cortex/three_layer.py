"""
cc_cortex.three_layer — Three-Layer Cognitive Architecture for system prompts.

Research-backed prompt engineering that maximizes LLM task performance:
  Layer 1: Identity Anchor (action-oriented, ≤20 words)
  Layer 2: Behavioral Constraints (step-by-step + consequence analysis)
  Layer 3: Dynamic Domain Expertise (keyword-based expert injection)

Based on: NAACL 2024 role-prompting, Chroma 2025 context-rot,
Lost-in-the-Middle attention analysis.

Usage:
    from cc_cortex.three_layer import CognitivePrompt, detect_domain

    prompt = CognitivePrompt(
        identity="I solve every problem. Cross-domain integration is my core capability.",
    )
    # Auto-detect domain from user message
    result = prompt.build("Fix the authentication bug in the API endpoint")
    # result includes Layer 1 + 2 + dynamic Layer 3 expert injection
"""

from __future__ import annotations

import re
from typing import Optional

# ── Domain Map ────────────────────────────────────────────

DOMAIN_MAP: dict[str, dict] = {
    "code": {
        "keywords": [
            "bug",
            "api",
            "deploy",
            "test",
            "refactor",
            "function",
            "class",
            "error",
            "exception",
            "debug",
            "compile",
            "build",
            "lint",
            "type",
            "import",
            "module",
            "package",
            "dependency",
            "endpoint",
            "database",
            "query",
            "migration",
            "schema",
            "docker",
            "ci",
            "cd",
            "pipeline",
        ],
        "expert": "senior software engineer specialized in production systems",
        "weight": 1.0,
    },
    "frontend": {
        "keywords": [
            "ui",
            "ux",
            "component",
            "react",
            "vue",
            "css",
            "html",
            "layout",
            "responsive",
            "animation",
            "style",
            "button",
            "form",
            "modal",
            "page",
            "navigation",
            "design",
            "tailwind",
            "scss",
        ],
        "expert": "senior frontend engineer specialized in UI/UX implementation",
        "weight": 1.2,
    },
    "data": {
        "keywords": [
            "data",
            "csv",
            "json",
            "parse",
            "transform",
            "etl",
            "pipeline",
            "analytics",
            "metric",
            "dashboard",
            "chart",
            "visualization",
            "pandas",
            "numpy",
            "sql",
            "aggregate",
            "statistics",
        ],
        "expert": "data engineer specialized in data pipelines and analytics",
        "weight": 1.0,
    },
    "security": {
        "keywords": [
            "auth",
            "authentication",
            "authorization",
            "token",
            "jwt",
            "oauth",
            "encrypt",
            "decrypt",
            "hash",
            "password",
            "credential",
            "permission",
            "role",
            "access",
            "vulnerability",
            "xss",
            "injection",
            "cors",
        ],
        "expert": "security engineer specialized in application security",
        "weight": 1.3,
    },
    "devops": {
        "keywords": [
            "deploy",
            "server",
            "container",
            "kubernetes",
            "k8s",
            "nginx",
            "terraform",
            "ansible",
            "monitoring",
            "log",
            "alert",
            "scaling",
            "load",
            "balancer",
            "ssl",
            "certificate",
            "dns",
            "cloud",
        ],
        "expert": "DevOps engineer specialized in infrastructure and deployment",
        "weight": 1.1,
    },
    "ai": {
        "keywords": [
            "model",
            "prompt",
            "llm",
            "embedding",
            "vector",
            "token",
            "fine-tune",
            "training",
            "inference",
            "neural",
            "transformer",
            "agent",
            "chain",
            "rag",
            "retrieval",
            "generation",
        ],
        "expert": "AI/ML engineer specialized in LLM applications",
        "weight": 1.2,
    },
    "business": {
        "keywords": [
            "acquisition",
            "valuation",
            "market",
            "revenue",
            "strategy",
            "pitch",
            "investor",
            "fundraise",
            "pricing",
            "growth",
            "user",
            "retention",
            "conversion",
            "competitor",
            "moat",
        ],
        "expert": "business strategist specialized in tech company growth",
        "weight": 1.0,
    },
}

# ── Default Layers ────────────────────────────────────────

DEFAULT_IDENTITY = "I solve every problem. Cross-domain integration is my core capability."

DEFAULT_BEHAVIORAL = [
    "Think step by step: decompose → reason step-by-step → verify each step → zero-error delivery.",
    "Consequence analysis: before acting, trace the impact chain"
    " — will changing A break B? Side effects? Reversible?",
]

# Token budget targets
BUDGET = {
    "identity": 50,
    "behavioral": 100,
    "dynamic": 80,
    "task_rules": 500,
    "reminders": 50,
    "total_max": 2000,
}


# ── Domain Detection ─────────────────────────────────────


def detect_domain(
    text: str,
    domain_map: Optional[dict[str, dict]] = None,
    threshold: int = 2,
) -> Optional[str]:
    """Detect the primary domain from text using keyword scoring.

    Args:
        text: User message or task description.
        domain_map: Custom domain map (default: DOMAIN_MAP).
        threshold: Minimum score to consider a match.

    Returns:
        Domain name string, or None if no domain scores above threshold.
    """
    if not text:
        return None

    domains = domain_map or DOMAIN_MAP
    text_lower = text.lower()
    scores: dict[str, float] = {}

    for domain, info in domains.items():
        keywords = info.get("keywords", [])
        weight = info.get("weight", 1.0)
        score = sum(1 for kw in keywords if re.search(r"\b" + re.escape(kw) + r"\b", text_lower))
        weighted = score * weight
        if weighted >= threshold:
            scores[domain] = weighted

    if not scores:
        return None

    return max(scores, key=scores.get)  # type: ignore[arg-type]


def get_expert_framing(
    domain: str,
    domain_map: Optional[dict[str, dict]] = None,
) -> str:
    """Get the expert framing string for a domain.

    Args:
        domain: Domain name from detect_domain().
        domain_map: Custom domain map (default: DOMAIN_MAP).

    Returns:
        Expert framing string, or empty string if domain not found.
    """
    domains = domain_map or DOMAIN_MAP
    info = domains.get(domain, {})
    expert = info.get("expert", "")
    if expert:
        return (
            f"[Dynamic Expertise] You are now a {expert}."
            " Return to integration perspective after completion."
        )
    return ""


# ── CognitivePrompt ───────────────────────────────────────


class CognitivePrompt:
    """Three-Layer Cognitive Architecture prompt builder.

    Assembles system prompts following the U-shaped attention pattern:
    START (high attention) → Layer 1 + 2
    MIDDLE (low attention) → task rules + Layer 3
    END (high attention) → critical reminders

    Example:
        prompt = CognitivePrompt()
        system = prompt.build("Fix the auth bug")
        # Returns optimized system prompt with auto-detected domain
    """

    def __init__(
        self,
        identity: str = DEFAULT_IDENTITY,
        behavioral: Optional[list[str]] = None,
        domain_map: Optional[dict[str, dict]] = None,
        reminders: Optional[list[str]] = None,
    ):
        """Initialize cognitive prompt builder.

        Args:
            identity: Layer 1 identity anchor (≤20 words, action verbs).
            behavioral: Layer 2 behavioral constraints.
            domain_map: Custom domain keyword map.
            reminders: Critical reminders for prompt END (high attention zone).
        """
        self.identity = identity
        self.behavioral = behavioral or list(DEFAULT_BEHAVIORAL)
        self.domain_map = domain_map or DOMAIN_MAP
        self.reminders = reminders or []

    def build(
        self,
        user_message: str = "",
        task_rules: Optional[list[str]] = None,
        force_domain: Optional[str] = None,
    ) -> str:
        """Build an optimized system prompt.

        Follows U-shaped attention:
        - START: identity + behavioral (highest attention)
        - MIDDLE: task rules + domain expertise (lower attention)
        - END: reminders (high attention)

        Args:
            user_message: User's task/message for domain detection.
            task_rules: Optional task-specific rules for the middle section.
            force_domain: Override auto-detection with a specific domain.

        Returns:
            Complete system prompt string.
        """
        sections: list[str] = []

        # START — highest attention zone
        sections.append(self.identity)
        sections.append("")
        for b in self.behavioral:
            sections.append(b)

        # MIDDLE — lower attention zone
        if task_rules:
            sections.append("")
            for rule in task_rules:
                sections.append(rule)

        # Layer 3 — dynamic domain expertise
        domain = force_domain or detect_domain(user_message, self.domain_map)
        if domain:
            framing = get_expert_framing(domain, self.domain_map)
            if framing:
                sections.append("")
                sections.append(framing)

        # END — high attention zone
        if self.reminders:
            sections.append("")
            for r in self.reminders:
                sections.append(r)

        return "\n".join(sections)

    def estimate_tokens(self, text: str) -> int:
        """Rough token estimate (chars / 4 for English, / 2 for CJK).

        Good enough for budget checking. Not meant to replace tiktoken.
        """
        cjk_chars = len(re.findall(r"[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff\uac00-\ud7af]", text))
        non_cjk = len(text) - cjk_chars
        return int(non_cjk / 4 + cjk_chars / 1.5)

    def check_budget(self, built_prompt: str) -> dict:
        """Check if a built prompt stays within token budget.

        Returns:
            Dict with estimated_tokens, budget_max, over_budget, recommendation.
        """
        estimated = self.estimate_tokens(built_prompt)
        max_budget = BUDGET["total_max"]
        over = estimated > max_budget
        return {
            "estimated_tokens": estimated,
            "budget_max": max_budget,
            "over_budget": over,
            "recommendation": (
                f"Reduce by ~{estimated - max_budget} tokens" if over else "Within budget"
            ),
        }

    def add_domain(
        self,
        name: str,
        keywords: list[str],
        expert: str,
        weight: float = 1.0,
    ) -> None:
        """Add a custom domain to the domain map.

        Args:
            name: Domain identifier.
            keywords: List of trigger keywords.
            expert: Expert framing description.
            weight: Score multiplier (default 1.0).
        """
        self.domain_map[name] = {
            "keywords": keywords,
            "expert": expert,
            "weight": weight,
        }

    def remove_domain(self, name: str) -> bool:
        """Remove a domain from the domain map.

        Returns:
            True if domain existed and was removed.
        """
        if name in self.domain_map:
            del self.domain_map[name]
            return True
        return False

    def list_domains(self) -> list[str]:
        """List all registered domain names."""
        return list(self.domain_map.keys())


__all__ = [
    "CognitivePrompt",
    "detect_domain",
    "get_expert_framing",
    "DOMAIN_MAP",
    "BUDGET",
    "DEFAULT_IDENTITY",
    "DEFAULT_BEHAVIORAL",
]
