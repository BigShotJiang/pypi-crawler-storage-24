"""Handoff Engine — Token-aware hard gate + handoff guidance generation.

When context tokens approach the limit, this module:
  1. HARD BLOCKS Agent spawns (PreToolUse deny) at configurable thresholds
  2. Generates structured handoff guidance for the AI to write a proper handoff

Performance: <5ms (reuses token_monitor's 20KB tail read).
"""

from __future__ import annotations

import json
import os
from typing import Optional

# ── Thresholds ────────────────────────────────────────────

# Gate thresholds (context_tokens)
GATE_AGENT = 140_000      # Block Agent spawn
GATE_CRITICAL = 160_000   # Block Agent + urgent handoff
REMINDER_TOKEN_MIN = 80_000   # Soft reminder threshold
REMINDER_FILE_MIN = 3         # Min modified files to trigger reminder

# ── Handoff Reminder State (module-level, per-process) ────

_reminder_fired_sessions: set[str] = set()   # sessions that already got the reminder
_modified_files: set[str] = set()            # files modified in current process
_handoff_updated: bool = False               # whether a handoff file was written

# ── Transcript Finder (cached) ────────────────────────────


def _find_transcript(session_id: str) -> str:
    """Find transcript JSONL path for session. <2ms with cache."""
    if not session_id:
        return ""

    project_dir = os.environ.get("CLAUDE_PROJECT_DIR", "")
    home = os.environ.get("USERPROFILE") or os.path.expanduser("~")

    # Check cache first
    cache_dir = os.path.join(project_dir, ".cc_cortex_cache") if project_dir else ""
    cache_file = os.path.join(cache_dir, "transcript_path.txt") if cache_dir else ""
    if cache_file and os.path.isfile(cache_file):
        try:
            cached = open(cache_file, "r", encoding="utf-8").read().strip()
            if cached and os.path.isfile(cached):
                return cached
        except Exception:
            pass

    # Try common paths (no glob — fast)
    proj_slug = os.path.basename(project_dir).replace("\\", "-").replace(":", "-")
    candidates = [
        os.path.join(home, ".claude", "projects", proj_slug, f"{session_id}.jsonl"),
        os.path.join(
            home, ".claude", "projects",
            project_dir.replace("\\", "-").replace(":", "").lower(),
            f"{session_id}.jsonl",
        ),
    ]
    for c in candidates:
        if os.path.isfile(c):
            # Cache it
            if cache_dir:
                try:
                    os.makedirs(cache_dir, exist_ok=True)
                    with open(cache_file, "w", encoding="utf-8") as f:
                        f.write(c)
                except Exception:
                    pass
            return c

    # Glob fallback (only runs once per session)
    try:
        proj_dirs_root = os.path.join(home, ".claude", "projects")
        if os.path.isdir(proj_dirs_root):
            for d in os.listdir(proj_dirs_root):
                p = os.path.join(proj_dirs_root, d, f"{session_id}.jsonl")
                if os.path.isfile(p):
                    if cache_dir:
                        try:
                            os.makedirs(cache_dir, exist_ok=True)
                            with open(cache_file, "w", encoding="utf-8") as f:
                                f.write(p)
                        except Exception:
                            pass
                    return p
    except Exception:
        pass

    return ""


# ── Token Gate (PreToolUse) ───────────────────────────────


def check_token_gate(
    session_id: str,
    tool_name: str,
    *,
    gate_agent: int = GATE_AGENT,
    gate_critical: int = GATE_CRITICAL,
) -> Optional[dict]:
    """Check if tool should be blocked due to high token usage.

    Returns deny dict for PreToolUse hook, or None if allowed.
    Only blocks Agent tool (other tools need to work for handoff writing).

    Performance: <5ms (20KB tail read + JSON parse).
    """
    # Only gate Agent spawns — editing/writing must stay open for handoff
    if tool_name != "Agent":
        return None

    transcript = _find_transcript(session_id)
    if not transcript:
        return None

    try:
        from cc_cortex.token_monitor import read_real_token_usage

        usage = read_real_token_usage(transcript)
        if not usage:
            return None

        context_k = usage["context_tokens"] // 1000
        cost_k = usage["cost_tokens"] // 1000

        if usage["context_tokens"] >= gate_critical:
            return {
                "permissionDecision": "deny",
                "reason": f"🚨 Token Gate: {context_k}K tokens — CRITICAL. "
                          f"Agent spawn blocked.",
                "additionalContext": _handoff_guidance(context_k, cost_k, critical=True),
            }

        if usage["context_tokens"] >= gate_agent:
            return {
                "permissionDecision": "deny",
                "reason": f"⚠️ Token Gate: {context_k}K tokens — Agent spawn blocked.",
                "additionalContext": _handoff_guidance(context_k, cost_k, critical=False),
            }
    except Exception:
        pass

    return None


# ── Handoff Reminder (PreToolUse additionalContext) ───────


def _is_handoff_path(file_path: str) -> bool:
    """Check if a file path looks like a handoff doc."""
    if not file_path:
        return False
    lower = file_path.lower().replace("\\", "/")
    return "handoff" in lower or "\u4ea4\u63a5" in lower  # 交接


def track_file_modification(tool_name: str, tool_input: dict) -> None:
    """Track files modified by Edit/Write tools. Call from PreToolUse hook.

    Updates module-level ``_modified_files`` and ``_handoff_updated`` state.

    Args:
        tool_name: The tool being invoked (Edit, Write, etc.).
        tool_input: The tool's input dict (must contain ``file_path``).
    """
    global _handoff_updated
    if tool_name not in ("Edit", "Write"):
        return
    fp = tool_input.get("file_path", "")
    if not fp:
        return
    _modified_files.add(fp)
    if _is_handoff_path(fp):
        _handoff_updated = True


def check_handoff_reminder(
    tool_name: str,
    tool_input: dict,
    session_id: str,
    token_usage: int,
    *,
    token_min: int = REMINDER_TOKEN_MIN,
    file_min: int = REMINDER_FILE_MIN,
) -> Optional[str]:
    """Return an additionalContext reminder if handoff is overdue.

    Conditions (ALL must be true):
      1. ``token_usage`` > ``token_min`` (default 80K)
      2. ``_modified_files`` count >= ``file_min`` (default 3)
      3. No handoff file has been written in this session
      4. Reminder not already fired for this ``session_id``

    After firing once, the reminder is suppressed for the rest of the session.

    Args:
        tool_name: Current tool name (used to track file modifications).
        tool_input: Current tool input dict.
        session_id: Active session ID.
        token_usage: Current context token count.
        token_min: Token threshold to start reminding.
        file_min: Minimum distinct files modified before reminding.

    Returns:
        Reminder string for additionalContext, or None.
    """
    # Always track, even if reminder already fired
    track_file_modification(tool_name, tool_input)

    # Guard: already reminded or conditions not met
    if session_id in _reminder_fired_sessions:
        return None
    if token_usage < token_min:
        return None
    if len(_modified_files) < file_min:
        return None
    if _handoff_updated:
        return None

    # Fire once
    _reminder_fired_sessions.add(session_id)

    token_k = token_usage // 1000
    n_files = len(_modified_files)
    lang = os.environ.get("CC_UX_LANG", "en")

    if lang == "zh":
        return (
            f"\u270f\ufe0f \u672c Session \u5df2\u6d88\u8017 {token_k}K tokens"
            f" / \u4fee\u6539 {n_files} \u6a94\u6848\uff0c"
            f"\u4f46\u4ea4\u63a5\u6a94\u672a\u66f4\u65b0\u3002"
            f"\u5efa\u8b70\u73fe\u5728\u5c31\u5beb\u4ea4\u63a5\u3002"
        )

    return (
        f"\u270f\ufe0f This session has used {token_k}K tokens and modified "
        f"{n_files} files, but no handoff doc has been updated. "
        f"Consider writing a handoff now."
    )


def reset_handoff_reminder_state() -> None:
    """Reset module-level reminder state. Useful for testing."""
    global _handoff_updated
    _reminder_fired_sessions.clear()
    _modified_files.clear()
    _handoff_updated = False


def _handoff_guidance(context_k: int, cost_k: int, *, critical: bool) -> str:
    """Generate handoff guidance text injected into additionalContext."""
    lang = os.environ.get("CC_UX_LANG", "en")

    if lang == "zh":
        if critical:
            return (
                f"🚨 **Token 交接：{context_k}K（成本 {cost_k}K）— 立即交接**\n\n"
                "Agent spawn 已被阻擋。請立即完成以下步驟：\n"
                "1. **停止新工作** — 不要開始新任務\n"
                "2. **寫交接檔** — 更新對應的 `交接_*.md`：\n"
                "   - 本次完成了什麼（含檔案路徑）\n"
                "   - 還有什麼沒做（⬜ 待辦）\n"
                "   - 當前阻礙或注意事項\n"
                "   - 下個 session 的建議起手式\n"
                "3. **結束 session** — 交接寫完就停\n"
            )
        return (
            f"⚠️ **Token 交接準備：{context_k}K（成本 {cost_k}K）**\n\n"
            "Agent spawn 已被阻擋，請用主線程完成剩餘工作。\n"
            "- 完成手上的任務後寫交接\n"
            "- 不要開新的大任務\n"
            "- 交接檔模板：本次完成 / 待做 / 注意事項 / 下步建議\n"
        )

    # English
    if critical:
        return (
            f"🚨 **Token Handoff: {context_k}K (cost {cost_k}K) — IMMEDIATE**\n\n"
            "Agent spawn blocked. Complete these steps now:\n"
            "1. **Stop new work** — do not start new tasks\n"
            "2. **Write handoff** — update the relevant handoff doc:\n"
            "   - What was accomplished (with file paths)\n"
            "   - What remains (⬜ todos)\n"
            "   - Current blockers or caveats\n"
            "   - Suggested first move for next session\n"
            "3. **End session** — stop after handoff is written\n"
        )
    return (
        f"⚠️ **Token Handoff Prep: {context_k}K (cost {cost_k}K)**\n\n"
        "Agent spawn blocked — use main thread to finish current work.\n"
        "- Complete current task, then write handoff\n"
        "- Do not start large new tasks\n"
        "- Handoff template: done / remaining / caveats / next steps\n"
    )


# ── Session Summary (Stop hook UX) ───────────────────────


def generate_session_summary(
    session_id: str,
    *,
    streak: int = 0,
    start_time: str = "",
) -> str:
    """Generate a visual session end summary for stderr (user-visible).

    Performance: <10ms (reads cached token data + streak state).
    """
    lang = os.environ.get("CC_UX_LANG", "en")

    # Token usage
    token_line = ""
    transcript = _find_transcript(session_id)
    if transcript:
        try:
            from cc_cortex.token_monitor import read_real_token_usage

            usage = read_real_token_usage(transcript)
            if usage:
                ctx_k = usage["context_tokens"] // 1000
                cost_k = usage["cost_tokens"] // 1000
                cache_k = usage["cache_read_tokens"] // 1000
                token_line = f"💰 Token: {ctx_k}K (cost {cost_k}K, cache {cache_k}K)"
        except Exception:
            pass

    # Streak
    streak_line = ""
    if streak > 0:
        if streak >= 25:
            streak_line = f"🔥 Streak: {streak} — ON FIRE"
        elif streak >= 10:
            streak_line = f"🔥 Streak: {streak} — solid run"
        elif streak >= 5:
            streak_line = f"✨ Streak: {streak}"
        else:
            streak_line = f"📝 Streak: {streak}"

    # Modified files count
    files_line = ""
    try:
        project_dir = os.environ.get("CLAUDE_PROJECT_DIR", "")
        lock_path = os.path.join(
            project_dir, "_AI_BRAIN", "cognition_shared", "instance_lock.json",
        )
        if os.path.isfile(lock_path):
            with open(lock_path, "r", encoding="utf-8") as f:
                lock = json.load(f)
            for _name, s in lock.get("sessions", {}).items():
                if s.get("session_id") == session_id:
                    files = s.get("files", [])
                    if files:
                        files_line = f"📂 Files: {len(files)} touched"
                    break
    except Exception:
        pass

    # Assemble
    lines = [x for x in [token_line, streak_line, files_line] if x]
    if not lines:
        return ""

    # Box drawing
    w = max(len(x) for x in lines) + 4
    w = max(w, 30)

    title = "Session Complete" if lang != "zh" else "Session 結束"
    border_top = f"╔{'═' * w}╗"
    border_mid = f"╠{'═' * w}╣"
    border_bot = f"╚{'═' * w}╝"

    result = [border_top]
    result.append(f"║  {title:<{w - 2}}║")
    result.append(border_mid)
    for line in lines:
        result.append(f"║  {line:<{w - 2}}║")
    result.append(border_bot)

    return "\n".join(result)
