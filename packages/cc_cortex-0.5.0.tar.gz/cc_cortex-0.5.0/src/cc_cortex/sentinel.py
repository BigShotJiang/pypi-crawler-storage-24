"""Sentinel — Behavioral pattern detection for stuck/brute-force loops.

Tracks recent tool calls per session and detects:
1. Tool Repeat: same write tool + same file N times in a row
2. Edit Stagnation: identical diffs attempted repeatedly
3. Analysis Paralysis: too many consecutive read-only operations
4. Scope Creep: modifying too many distinct files
5. Split Detection: suggest task splitting when file count is high

All messages are configurable via the `messages` parameter.
"""

from __future__ import annotations

import json
import os
import time
from typing import Optional

# ─── Constants ────────────────────────────────────────────

WRITE_TOOLS = frozenset(["Edit", "Write", "NotebookEdit"])
READ_ONLY_TOOLS = frozenset(
    [
        "Read",
        "Grep",
        "Glob",
        "WebSearch",
        "WebFetch",
    ]
)

DEFAULT_THRESHOLDS = {
    "repeat": 3,
    "repeat_force": 5,
    "stale": 2,
    "paralysis": 7,
    "scope": 10,
    "split": 4,
}

# Default English messages (can be overridden by caller)
DEFAULT_MESSAGES = {
    "repeat": (
        "Sentinel: {tool} on {file} repeated {count} times. "
        "Step-Back: re-examine your approach — "
        "list 3 root cause hypotheses, verify the most likely one, "
        "then continue only if direction confirmed."
    ),
    "repeat_force": (
        "Sentinel: {tool} on {file} repeated {count} times — strategy switch required. "
        "Current approach is NOT working. You MUST: "
        "1) Stop editing this file immediately. "
        "2) Try a completely different approach (different tool / different file / different hypothesis). "
        "3) If stuck, use Step-Back or Decompose from prompt-engineering strategies."
    ),
    "stagnation": (
        "Sentinel: identical Edit diffs detected (stagnation). "
        "Re-analyze the root cause and try a different approach."
    ),
    "paralysis_start": (
        "Sentinel: {count} consecutive read-only operations. "
        "If you have enough info, start acting. "
        "If not, change direction."
    ),
    "paralysis_end": ("Attention recovered: switched from analysis to action mode."),
    "scope": (
        "Sentinel: {count} distinct files modified this session. "
        "Is scope too large? Confirm all changes are within task scope."
    ),
    "split": (
        "Sentinel: {count} distinct files edited. "
        "Consider splitting into sub-tasks if touching 3+ subsystems."
    ),
}


# ─── State Management ─────────────────────────────────────


def _state_path(state_dir: str, session_id: str) -> str:
    return os.path.join(state_dir, f"{session_id[:8]}.json")


def _read_state(state_dir: str, session_id: str) -> dict:
    path = _state_path(state_dir, session_id)
    try:
        os.makedirs(state_dir, exist_ok=True)
        if os.path.isfile(path):
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return {"calls": []}


def _write_state(state_dir: str, session_id: str, state: dict):
    path = _state_path(state_dir, session_id)
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False)
    except Exception:
        pass


# ─── Main Check ───────────────────────────────────────────


def check(
    session_id: str,
    tool_name: str,
    tool_input: dict,
    state_dir: str,
    *,
    thresholds: Optional[dict] = None,
    messages: Optional[dict] = None,
    max_calls: int = 10,
) -> Optional[list[dict]]:
    """Detect behavioral anti-patterns from recent tool calls.

    Args:
        session_id: Current session ID.
        tool_name: Name of the tool being called.
        tool_input: Tool input dict.
        state_dir: Directory for persisting call history.
        thresholds: Override default thresholds.
        messages: Override default message templates.
        max_calls: Number of recent calls to keep.

    Returns:
        List of {type, message} dicts, or None if no warnings.
    """
    if not session_id:
        return None

    th = {**DEFAULT_THRESHOLDS, **(thresholds or {})}
    msgs = {**DEFAULT_MESSAGES, **(messages or {})}
    state = _read_state(state_dir, session_id)
    calls = state.get("calls", [])

    # Extract file path
    file_path = ""
    if isinstance(tool_input, dict):
        file_path = (
            tool_input.get("file_path")
            or tool_input.get("path")
            or tool_input.get("notebook_path")
            or ""
        )

    # Edit signature for stagnation detection
    edit_sig = ""
    if tool_name == "Edit" and isinstance(tool_input, dict):
        old_s = tool_input.get("old_string", "")[:80]
        new_s = tool_input.get("new_string", "")[:80]
        edit_sig = f"{old_s}||{new_s}"

    # Record call
    calls.append(
        {
            "tool": tool_name,
            "path": file_path,
            "edit_sig": edit_sig,
            "ts": time.time(),
        }
    )
    calls = calls[-max_calls:]
    state["calls"] = calls

    # Track edited files for split detection
    split_warn = False
    if tool_name in WRITE_TOOLS and file_path:
        ef = state.get("edited_files", [])
        if file_path not in ef:
            ef.append(file_path)
            state["edited_files"] = ef
        if len(ef) >= th["split"] and not state.get("split_warned"):
            state["split_warned"] = True
            split_warn = True

    # Save state before checks
    _write_state(state_dir, session_id, state)

    warnings: list[dict] = []

    # Check 1: Tool Repeat (write tool + same file N times)
    # Graduated response: repeat threshold → Step-Back, repeat_force → strategy switch
    if file_path and tool_name in WRITE_TOOLS:
        # Count consecutive same-tool same-path calls from the end
        consec = 0
        for c in reversed(calls):
            if c["tool"] == tool_name and c["path"] == file_path:
                consec += 1
            else:
                break

        rt_force = th.get("repeat_force", 5)
        rt = th["repeat"]
        basename = os.path.basename(file_path)

        if consec >= rt_force:
            warnings.append(
                {
                    "type": "repeat_force",
                    "message": msgs["repeat_force"].format(
                        tool=tool_name,
                        file=basename,
                        count=consec,
                    ),
                }
            )
        elif consec >= rt:
            warnings.append(
                {
                    "type": "repeat",
                    "message": msgs["repeat"].format(
                        tool=tool_name,
                        file=basename,
                        count=consec,
                    ),
                }
            )

    # Check 2: Edit Stagnation (identical diffs)
    st = th["stale"]
    if tool_name == "Edit" and edit_sig and len(calls) >= st:
        edit_calls = [c for c in calls[-6:] if c["tool"] == "Edit" and c["edit_sig"]]
        if len(edit_calls) >= st:
            sigs = [c["edit_sig"] for c in edit_calls[-st:]]
            if len(set(sigs)) == 1:
                warnings.append(
                    {
                        "type": "stagnation",
                        "message": msgs["stagnation"],
                    }
                )

    # Check 3: Analysis Paralysis
    consecutive_reads = 0
    for c in reversed(calls):
        if c["tool"] in READ_ONLY_TOOLS:
            consecutive_reads += 1
        else:
            break

    was_paralyzed = state.get("paralysis_warned", False)
    if was_paralyzed and tool_name not in READ_ONLY_TOOLS:
        state["paralysis_warned"] = False
        _write_state(state_dir, session_id, state)
        warnings.append(
            {
                "type": "paralysis_end",
                "message": msgs["paralysis_end"],
            }
        )
    elif consecutive_reads >= th["paralysis"] and not was_paralyzed:
        state["paralysis_warned"] = True
        _write_state(state_dir, session_id, state)
        warnings.append(
            {
                "type": "paralysis_start",
                "message": msgs["paralysis_start"].format(
                    count=consecutive_reads,
                ),
            }
        )

    # Check 4: Scope Creep
    modified = set()
    for c in calls:
        if c["tool"] in WRITE_TOOLS and c.get("path"):
            modified.add(c["path"])
    if len(modified) >= th["scope"]:
        warnings.append(
            {
                "type": "scope",
                "message": msgs["scope"].format(count=len(modified)),
            }
        )

    # Check 5: Split Detection
    if split_warn:
        ef_count = len(state.get("edited_files", []))
        warnings.append(
            {
                "type": "split",
                "message": msgs["split"].format(count=ef_count),
            }
        )

    return warnings if warnings else None


# ── Hard Gate (DENY) ─────────────────────────────────────


def gate_sentinel(
    session_id: str,
    tool_name: str,
    tool_input: dict,
    state_dir: str,
    *,
    max_repeats: int = 5,
    lint_exception: bool = True,
) -> Optional[dict]:
    """DENY Edit on same file when consecutive count >= max_repeats.

    Lint exception: if the file has lint errors (tracked in streak_ux.json),
    the edit is considered a fix attempt and doesn't count toward the limit.

    Returns deny dict for PreToolUse hook, or None if allowed.
    Does NOT modify state (check() does that).

    Performance: <3ms (read state + optional streak check).
    """
    if tool_name not in WRITE_TOOLS or not session_id:
        return None

    file_path = ""
    if isinstance(tool_input, dict):
        file_path = (
            tool_input.get("file_path")
            or tool_input.get("path")
            or tool_input.get("notebook_path")
            or ""
        )
    if not file_path:
        return None

    # Read call history
    state = _read_state(state_dir, session_id)
    calls = state.get("calls", [])

    # Count consecutive same-tool same-file from end
    consec = 0
    for c in reversed(calls):
        if c.get("tool") == tool_name and c.get("path") == file_path:
            consec += 1
        else:
            break

    if consec < max_repeats:
        return None

    # Lint exception: check if file currently has errors
    if lint_exception:
        try:
            project_dir = os.environ.get("CLAUDE_PROJECT_DIR", ".")
            ux_path = os.path.join(
                project_dir, ".cc_cortex_cache", "streak_ux.json",
            )
            if os.path.isfile(ux_path):
                with open(ux_path, "r", encoding="utf-8") as f:
                    ux = json.load(f)
                norm = file_path.lower().replace("\\", "/")
                if ux.get("errors", {}).get(norm, 0) > 0:
                    # File has lint errors — this edit is a fix attempt
                    return None
        except Exception:
            pass  # fail-open: if can't check, allow

    basename = os.path.basename(file_path)
    return {
        "permissionDecision": "deny",
        "reason": (
            f"Sentinel Gate: {tool_name} on {basename} "
            f"repeated {consec}x — stuck loop detected"
        ),
        "additionalContext": (
            f"You've edited {basename} {consec} times consecutively "
            f"without progress. This pattern indicates a stuck loop. "
            f"STOP and try a completely different approach:\n"
            f"1. Read the file fresh to re-examine the problem\n"
            f"2. Try a different file or different tool\n"
            f"3. Use Step-Back to list 3 root cause hypotheses"
        ),
    }
