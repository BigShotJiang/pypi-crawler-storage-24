#!/usr/bin/env python3
"""cc-cortex Stop hook — session cleanup, notifications, learning extraction.

Fail-open: any crash -> exit silently.
"""

from __future__ import annotations

import json
import sys


def main(hook_data: dict | None = None) -> None:
    """Entry point."""
    try:
        if hook_data is None:
            hook_data = json.loads(sys.stdin.read())
    except Exception:
        return

    # --- Module: knowledge (extract learnings from conversation) ---
    try:
        from cc_cortex.knowledge import on_stop

        on_stop(hook_data)
    except (ImportError, Exception):
        pass

    # --- Module: cognitive (save session profile) ---
    try:
        from cc_cortex.cognitive import on_stop as cog_stop

        cog_stop(hook_data)
    except (ImportError, Exception):
        pass

    # --- Module: multi_instance (release lock) ---
    try:
        from cc_cortex.multi_instance import release_lock

        release_lock()
    except (ImportError, Exception):
        pass

    # --- Module: stop_guard (premature stop detection) ---
    try:
        from cc_cortex.stop_guard import on_stop as sg_stop

        warning = sg_stop(hook_data)
        if warning:
            import sys as _sys

            print(warning, file=_sys.stderr)
    except (ImportError, Exception):
        pass

    # --- Module: session summary UX (stderr — user visible) ---
    try:
        _session_summary(hook_data)
    except Exception:
        pass

    # --- Module: notification (toast) ---
    try:
        _notify_stop(hook_data)
    except Exception:
        pass


def _session_summary(hook_data: dict) -> None:
    """Output visual session summary to stderr (user-visible). <10ms."""
    import os

    session_id = hook_data.get("session_id", "")
    if not session_id:
        return

    # Load streak count
    streak = 0
    try:
        project_dir = os.environ.get("CLAUDE_PROJECT_DIR", ".")
        ux_path = os.path.join(project_dir, ".cc_cortex_cache", "streak_ux.json")
        if os.path.isfile(ux_path):
            with open(ux_path, "r", encoding="utf-8") as f:
                ux = json.load(f)
            streak = ux.get("streak", 0)
    except Exception:
        pass

    try:
        from cc_cortex.handoff_engine import generate_session_summary

        summary = generate_session_summary(session_id, streak=streak)
        if summary:
            import sys as _sys

            _sys.stderr.write(f"\n{summary}\n")
            _sys.stderr.flush()
    except (ImportError, Exception):
        pass


def _notify_stop(hook_data: dict) -> None:
    """Show toast: session name + task + git status, locale-aware."""
    import os

    from cc_cortex.core.notify import _get_locale, _t, show_toast

    locale = _get_locale()
    project_dir = os.environ.get("CLAUDE_PROJECT_DIR", "")
    lock_path = os.path.join(
        project_dir,
        "_AI_BRAIN",
        "cognition_shared",
        "instance_lock.json",
    )
    session_id = hook_data.get("session_id", "")
    session_name = ""
    task = ""
    if os.path.isfile(lock_path):
        try:
            with open(lock_path, "r", encoding="utf-8") as f:
                lock = json.load(f)
            for name, s in lock.get("sessions", {}).items():
                sid = s.get("session_id", "")
                if sid == session_id or not session_id:
                    session_name = name
                    task = s.get("task", "")
                    break
        except Exception:
            pass

    # If no task, extract first user message from transcript
    if not task:
        try:
            from cc_cortex.core.notify import extract_first_user_message

            # Transcript: ~/.claude/projects/<hash>/<session_id>.jsonl
            home = os.path.expanduser("~")
            proj_dir = os.path.join(home, ".claude", "projects")
            for d in os.listdir(proj_dir):
                t_path = os.path.join(proj_dir, d, f"{session_id}.jsonl")
                if os.path.isfile(t_path):
                    task = extract_first_user_message(t_path, 40)
                    break
        except Exception:
            pass

    # Line 1: session name
    line1 = session_name or "Session"
    # Line 2: task + response_ready
    if task:
        line2 = f"{task[:40]} — {_t('response_ready')}"
    else:
        line2 = _t("response_ready")
    # Line 3+: git status
    git_line = ""
    try:
        from cc_cortex.git_assist import generate_report

        report = generate_report(
            cwd=project_dir or None,
            locale=locale,
        )
        if report:
            # Only first 2 lines to fit toast
            git_line = "\n".join(report.splitlines()[:2])
    except Exception:
        pass

    body = f"{line1}\n{line2}"
    if git_line:
        body += f"\n{git_line}"

    show_toast(
        "Claude Code",
        body,
        enabled=True,
        tag="claude-stop",
        group="claude-code",
    )


if __name__ == "__main__":
    main()
