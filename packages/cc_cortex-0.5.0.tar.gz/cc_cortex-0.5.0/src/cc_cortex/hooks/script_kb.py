#!/usr/bin/env python3
"""cc-cortex Script KB Check — remind to consult KB when writing scripts.

Triggers only when ALL conditions are met:
  1. Tool is a write/edit operation
  2. Target file is under a scripts/ directory
  3. File content contains specific API/library keywords

Each keyword group maps to a specific KB section, so only the relevant
hint is shown — no blanket reminders.
"""

from __future__ import annotations

from typing import Any

# ── KB Section Registry ──────────────────────────────────────

KB_SECTIONS: dict[str, dict[str, Any]] = {
    "book": {
        "keywords": [
            "python-docx",
            "Document(",
            "OxmlElement",
            "qn(",
            "add_paragraph",
        ],
        "kb_hint": "kb/script-recipes.md#word-書籍操作",
    },
    "image": {
        "keywords": [
            "fal.ai",
            "fal-ai",
            "flux",
            "pulid",
            "FalGuard",
            "fal_client",
        ],
        "kb_hint": "kb/script-recipes.md#ai-圖片生成",
    },
    "face": {
        "keywords": [
            "DeepFace",
            "faiss",
            "face_index",
            "Facenet",
            "embedding",
        ],
        "kb_hint": "kb/script-recipes.md#臉部搜尋",
    },
    "deploy": {
        "keywords": [
            "paramiko",
            "SSHClient",
            "sftp",
            "docker",
        ],
        "kb_hint": "kb/script-recipes.md#部署",
    },
    "translate": {
        "keywords": [
            "genai",
            "gemini",
            "translate",
            "翻譯",
        ],
        "kb_hint": "kb/script-recipes.md#翻譯",
    },
}

_WRITE_TOOLS = frozenset({"Write", "Edit", "NotebookEdit", "MultiEdit"})


def _extract_file_path(tool_input: dict) -> str:
    """Extract file path from tool input dict."""
    return (
        tool_input.get("file_path")
        or tool_input.get("notebook_path")
        or tool_input.get("path")
        or ""
    )


def _is_scripts_dir(file_path: str) -> bool:
    """Check if file is under a scripts/ directory."""
    # Normalize separators for cross-platform
    normalized = file_path.replace("\\", "/")
    return "/scripts/" in normalized or normalized.startswith("scripts/")


def _extract_content(tool_input: dict) -> str:
    """Extract writable content from tool input for keyword matching."""
    parts: list[str] = []
    # Write tool
    if "content" in tool_input:
        parts.append(tool_input["content"])
    # Edit tool
    if "new_string" in tool_input:
        parts.append(tool_input["new_string"])
    if "old_string" in tool_input:
        parts.append(tool_input["old_string"])
    return "\n".join(parts)


def _match_sections(content: str) -> list[str]:
    """Return KB hints for all sections whose keywords appear in content."""
    hints: list[str] = []
    for section_name, section in KB_SECTIONS.items():
        for kw in section["keywords"]:
            if kw in content:
                hints.append(section["kb_hint"])
                break  # One match per section is enough
    return hints


def check_script_kb(tool_input: dict, tool_name: str) -> list[str]:
    """Check if a script write/edit should trigger a KB reminder.

    Trigger conditions (ALL must be met):
      1. tool_name is a write/edit tool
      2. file_path is under scripts/
      3. Content contains keywords from at least one KB section

    Args:
        tool_input: The tool's input dictionary.
        tool_name: The Claude Code tool name (Write, Edit, etc.).

    Returns:
        List of warning/reminder messages. Empty list means no trigger.
    """
    if tool_name not in _WRITE_TOOLS:
        return []

    file_path = _extract_file_path(tool_input)
    if not file_path or not _is_scripts_dir(file_path):
        return []

    content = _extract_content(tool_input)
    if not content:
        return []

    matched_hints = _match_sections(content)
    if not matched_hints:
        return []

    # Build concise reminder (one line per matched section)
    warnings: list[str] = []
    hint_list = " | ".join(matched_hints)
    warnings.append(f"[Script KB] Check before proceeding: {hint_list}")
    return warnings
