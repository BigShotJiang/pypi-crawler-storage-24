#!/usr/bin/env python3
"""cc-cortex SessionStart hook — session init, zombie cleanup.

Fail-open: any crash -> exit silently.
"""

from __future__ import annotations

import json
import sys


def main(hook_data: dict | None = None) -> None:
    """Entry point."""
    try:
        if hook_data is None:
            hook_data = json.loads(sys.stdin.read())
    except Exception:
        return

    # --- Module: multi_instance (acquire lock + zombie GC) ---
    try:
        from cc_cortex.multi_instance import acquire_lock

        acquire_lock()
    except (ImportError, Exception):
        pass

    # --- Module: cognitive (start session profiling) ---
    try:
        from cc_cortex.cognitive import on_session_start

        on_session_start(hook_data)
    except (ImportError, Exception):
        pass


if __name__ == "__main__":
    main()
