#!/usr/bin/env python3
"""cc-cortex PostToolUse hook — code quality + routed warnings + streak UX.

Output: JSON {"hookSpecificOutput": {"hookEventName": "PostToolUse", "additionalContext": "..."}}

Pipeline:
  A. Always-on (bypass warn_router):
     1. Code Guard  — Python(ruff) / Rust(cargo) / Go(go vet) + SHA256 cache
     2. TypeScript   — tsc --noEmit + SHA256 cache + project auto-detect
     3. Linting      — ESLint for JS/JSX
     4. Streak UX    — clean edit streak tracking
     5. Knowledge    — learning loop (corrections → kb)
     6. Cognitive    — adaptive thresholds

  B. Routed through warn_router (mode/cooldown/budget):
     - awareness   — script KB reminders
     - scavenger   — stale session marker detection
     - char_limit  — oversized content warnings

Three-tier classification (in CC wrapper) prevents model habituation:
  CRITICAL  — errors/fixes: always relay with [SHOW USER VERBATIM]
  MILESTONE — streak fire: only at intervals (every N)
  INFO      — pass through as context
"""

from __future__ import annotations

import json
import os
import re
import sys

_MILESTONE_INTERVAL = 5
_WRITE_TOOLS = frozenset({"Write", "Edit", "NotebookEdit", "MultiEdit"})

_WARN_STATE_FILE = os.path.join(
    os.environ.get("CLAUDE_PROJECT_DIR", "."), ".cc_cortex_cache", "warn_state.json"
)

# ── Streak UX State ──────────────────────────────────────

_UX_STATE_FILE = os.path.join(
    os.environ.get("CLAUDE_PROJECT_DIR", "."), ".cc_cortex_cache", "streak_ux.json"
)

_MAX_ERRORS = 50


def _norm_path(p: str) -> str:
    """Normalize path for consistent dict key (lowercase + forward slash)."""
    return p.lower().replace("\\", "/") if p else ""


def _load_ux() -> dict:
    try:
        with open(_UX_STATE_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        # Normalize existing keys + trim to _MAX_ERRORS
        raw_errors = data.get("errors", {})
        normed: dict[str, int] = {}
        for k, v in raw_errors.items():
            nk = _norm_path(k)
            normed[nk] = v
        # Trim to max — keep most recent (last inserted)
        if len(normed) > _MAX_ERRORS:
            normed = dict(list(normed.items())[-_MAX_ERRORS:])
        data["errors"] = normed
        return data
    except Exception:
        return {"errors": {}, "streak": 0}


def _save_ux(state: dict):
    try:
        os.makedirs(os.path.dirname(_UX_STATE_FILE), exist_ok=True)
        with open(_UX_STATE_FILE, "w", encoding="utf-8") as f:
            json.dump(state, f)
    except Exception:
        pass


# ── Three-tier Classification ────────────────────────────


def _classify(line: str) -> str:
    low = line.lower()
    # Fix confirmations (✅) are always CRITICAL — user must see them
    if "\u2705" in line:  # ✅
        return "CRITICAL"
    if any(k in low for k in ("error", "錯誤", "warning", "警告", "fix", "修復", "⚠", "❌")):
        return "CRITICAL"
    if "\U0001f525" in line:  # 🔥
        return "MILESTONE"
    return "INFO"


def _extract_streak_count(line: str) -> int:
    m = re.search(r"x(\d+)", line)
    return int(m.group(1)) if m else 0


def _emit_stderr(msg: str) -> None:
    """Write UX message to stderr so the user sees it directly (not just AI)."""
    try:
        if hasattr(sys.stderr, "buffer"):
            sys.stderr.buffer.write(f"  {msg}\n".encode("utf-8"))
            sys.stderr.buffer.flush()
        else:
            print(f"  {msg}", file=sys.stderr)
    except Exception:
        pass


def _throttle(lines: list[str]) -> list[str]:
    output = []
    for line in lines:
        level = _classify(line)
        if level == "CRITICAL":
            _emit_stderr(line)
            output.append(f"[SHOW USER VERBATIM] {line}")
            output.append(
                "(Note: fix when you next touch this file — do NOT abandon your current task)"
            )
        elif level == "MILESTONE":
            count = _extract_streak_count(line)
            is_named = count in (25, 50, 100)
            is_interval = count > 0 and count % _MILESTONE_INTERVAL == 0
            if is_named or is_interval:
                _emit_stderr(line)
                output.append(f"[SHOW USER VERBATIM] {line}")
        else:
            output.append(line)
    return output


# ── Linting Dispatch ─────────────────────────────────────


def _run_linting(tool_name: str, tool_input: dict) -> str | None:
    """Run the appropriate linter based on file extension. Returns error msg or None."""
    file_path = (
        tool_input.get("file_path")
        or tool_input.get("notebook_path")
        or tool_input.get("path")
        or ""
    )
    if not file_path:
        return None

    ext = os.path.splitext(file_path)[1].lower()

    # Python / Rust / Go → code_guard
    try:
        from cc_cortex.code_guard import SUPPORTED_EXTENSIONS as CG_EXTS
        from cc_cortex.code_guard import check_code_guard

        if ext in CG_EXTS:
            return check_code_guard(tool_name, tool_input, use_cache=True)
    except ImportError:
        pass

    # TypeScript → typescript
    if ext in (".ts", ".tsx"):
        try:
            from cc_cortex.typescript import check_typescript

            return check_typescript(tool_name, tool_input)
        except ImportError:
            pass

    # JavaScript → linting (eslint)
    if ext in (".js", ".jsx", ".mjs", ".cjs"):
        try:
            from cc_cortex.linting import run_linter

            return run_linter(file_path)
        except ImportError:
            pass

    return None


# ── Streak UX ────────────────────────────────────────────


def _get_streak_config() -> dict:
    """Load streak_ux config from Config singleton."""
    try:
        from cc_cortex.core.config import get_config

        return get_config().raw("streak_ux", {})
    except Exception:
        return {}


def _extract_error_count(lint_msg: str | None) -> int:
    """Extract error/issue count from lint message like '🔴 ruff ❌ 3 issues'."""
    if not lint_msg:
        return 1
    m = re.search(r"(\d+)\s+(?:issues?|errors?)", lint_msg)
    return int(m.group(1)) if m else 1


def _build_streak_msg(
    has_errors: bool, file_path: str, lint_msg: str | None = None,
) -> str | None:
    """Track streak and generate UX message."""
    ux = _load_ux()
    fname = os.path.basename(file_path) if file_path else ""
    norm = _norm_path(file_path)

    if has_errors:
        if norm:
            error_count = _extract_error_count(lint_msg)
            ux.setdefault("errors", {})[norm] = error_count
        ux["streak"] = 0
        _save_ux(ux)
        return None  # Error msg already in linting output

    prev_errors = ux.get("errors", {}).get(norm, 0) if norm else 0

    if prev_errors > 0 and norm:
        # Was broken, now fixed
        ux["errors"].pop(norm, None)
        ux["streak"] = ux.get("streak", 0) + 1
        _save_ux(ux)
        streak = ux["streak"]
        cfg = _get_streak_config()
        fix_fmt = cfg.get("fix_fmt", "✅ {fname} fixed {fixed}/{total} | 🔥x{streak} COMBO!")
        return fix_fmt.format(
            fname=fname, streak=streak,
            fixed_label="fixed", fixed=prev_errors, total=prev_errors,
        )

    # Clean edit
    ux["streak"] = ux.get("streak", 0) + 1
    _save_ux(ux)
    streak = ux["streak"]
    cfg = _get_streak_config()
    milestone_interval = int(cfg.get("milestone_interval", _MILESTONE_INTERVAL))
    if streak > 0 and streak % milestone_interval == 0:
        streak_fmt = cfg.get("streak_fmt", "🔥x{streak} COMBO!")
        return streak_fmt.format(
            streak=streak, label="", stats="",
        ).strip(" |")

    return None


# ── Routed Warnings (via warn_router) ───────────────────


def _collect_routed_warnings(tool_name: str, tool_input: dict) -> list[str]:
    """Collect warnings from generators, route through warn_router."""
    try:
        from cc_cortex.warn_generators import collect_warnings
        from cc_cortex.warn_router import route

        items = collect_warnings(tool_name, tool_input)
        if not items:
            return []

        return route(
            warn_items=[(name, msg) for name, msg in items],
            state_path=_WARN_STATE_FILE,
        )
    except (ImportError, Exception):
        return []


# ── Main ─────────────────────────────────────────────────


def main(hook_data: dict | None = None) -> None:
    """Entry point. Can be called directly or from a local wrapper."""
    try:
        if hook_data is None:
            hook_data = json.loads(sys.stdin.read())
    except Exception:
        return

    tool_name = hook_data.get("tool_name", "")
    raw_input = hook_data.get("tool_input")
    tool_input = raw_input if isinstance(raw_input, dict) else {}

    fragments: list[str] = []

    # ── A. Always-on: Code quality linting + streak ──
    if tool_name in _WRITE_TOOLS:
        lint_msg = _run_linting(tool_name, tool_input)
        file_path = tool_input.get("file_path") or tool_input.get("path") or ""
        has_errors = lint_msg is not None

        if lint_msg:
            fragments.append(lint_msg)

        # Streak UX
        streak_msg = _build_streak_msg(has_errors, file_path, lint_msg)
        if streak_msg:
            fragments.append(streak_msg)

    # ── A. Always-on: Handoff format validation ──
    if tool_name in _WRITE_TOOLS:
        try:
            from cc_cortex.core.config import get_config

            cfg = get_config()
            if cfg.feature("handoff_format"):
                from cc_cortex.handoff_validator import check_handoff_on_write

                hf_msg = check_handoff_on_write(tool_name, tool_input)
                if hf_msg:
                    fragments.append(hf_msg)
        except (ImportError, Exception):
            pass

    # ── A. Always-on: Knowledge (learning loop) ──
    try:
        from cc_cortex.knowledge import on_post_tool

        ctx = on_post_tool(hook_data)
        if ctx:
            fragments.append(ctx)
    except (ImportError, Exception):
        pass

    # ── A. Always-on: Cognitive (adaptive thresholds) ──
    try:
        from cc_cortex.cognitive import on_post_tool as cog_post

        ctx = cog_post(hook_data)
        if ctx:
            fragments.append(ctx)
    except (ImportError, Exception):
        pass

    # ── A. Always-on: Token monitor (real API usage) ──
    try:
        from cc_cortex.token_monitor import check_threshold

        session_id = hook_data.get("session_id", "")
        # Locate transcript JSONL by session_id
        project_dir = os.environ.get("CLAUDE_PROJECT_DIR", ".")
        home = os.environ.get("USERPROFILE") or os.path.expanduser("~")
        # CC stores transcripts as ~/.claude/projects/<slug>/<session_id>.jsonl
        transcript = ""
        proj_slug = os.path.basename(project_dir).replace("\\", "-").replace(":", "-")
        candidates = [
            os.path.join(home, ".claude", "projects", proj_slug, f"{session_id}.jsonl"),
            os.path.join(
                home, ".claude", "projects",
                project_dir.replace("\\", "-").replace(":", "").lower(),
                f"{session_id}.jsonl",
            ),
        ]
        for c in candidates:
            if os.path.isfile(c):
                transcript = c
                break
        if not transcript:
            # Glob fallback: find most recent JSONL matching session_id
            import glob
            proj_dirs = glob.glob(os.path.join(home, ".claude", "projects", "*"))
            for pd in proj_dirs:
                p = os.path.join(pd, f"{session_id}.jsonl")
                if os.path.isfile(p):
                    transcript = p
                    break

        if transcript:
            thresholds = [
                (160_000, "🚨", "已達 160K — 立即寫交接，下一輪新 session", True),
                (140_000, "⚠️", "已達 140K — 準備交接，停止 spawn 子代理", False),
                (100_000, "📊", "已達 100K — 注意 token 消耗，規劃收尾", False),
            ]
            state_dir = os.path.join(
                os.environ.get("CLAUDE_PROJECT_DIR", "."),
                ".cc_cortex_cache", "token_state",
            )
            result = check_threshold(
                transcript, thresholds,
                state_dir=state_dir, session_id=session_id,
            )
            if result:
                icon = result["icon"]
                msg = result["message"]
                est_k = result["est_k"]
                cost_k = result["cost_k"]
                token_msg = f"{icon} Token: {est_k}K（成本加權 {cost_k}K）— {msg}"
                fragments.append(f"[SHOW USER VERBATIM] {token_msg}")

                # At 140K+: inject structured handoff guidance
                if result["threshold"] >= 140_000:
                    try:
                        from cc_cortex.handoff_engine import _handoff_guidance

                        critical = result["threshold"] >= 160_000
                        guidance = _handoff_guidance(est_k, cost_k, critical=critical)
                        fragments.append(guidance)
                    except (ImportError, Exception):
                        pass
    except (ImportError, Exception):
        pass

    # ── B. Routed warnings (awareness/scavenger/char_limit) ──
    routed = _collect_routed_warnings(tool_name, tool_input)
    fragments.extend(routed)

    if not fragments:
        return

    # Apply three-tier throttle
    combined = "\n\n".join(fragments)
    lines = combined.split("\n\n")
    throttled = _throttle(lines)

    if not throttled:
        return

    final_ctx = "\n\n".join(throttled)
    output = json.dumps(
        {
            "hookSpecificOutput": {
                "hookEventName": "PostToolUse",
                "additionalContext": final_ctx,
            }
        },
        ensure_ascii=False,
    )
    # Support both direct execution (needs buffer for Windows encoding)
    # and redirect_stdout(StringIO) from CC wrapper
    if hasattr(sys.stdout, "buffer"):
        sys.stdout.buffer.write(output.encode("utf-8"))
        sys.stdout.buffer.flush()
    else:
        sys.stdout.write(output)
        sys.stdout.flush()


if __name__ == "__main__":
    os.environ.setdefault("CC_UX_LANG", "en")
    main()
