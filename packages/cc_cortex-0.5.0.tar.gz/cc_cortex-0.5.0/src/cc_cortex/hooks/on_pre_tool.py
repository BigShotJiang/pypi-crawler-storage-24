#!/usr/bin/env python3
"""cc-cortex PreToolUse hook — orchestrates all pre-tool checks.

Pipeline (short-circuit on first deny):
  1. pre_window_guard      — Windows console flash prevention (deny)
  2. pre_destruction_guard  — risk-based destructive op interception (deny)
  3. pre_token_gate         — block Agent at 140K+ tokens (deny)
  4. pre_agent_cap          — block Agent at ≥N spawns/session (deny)
  5. pre_read_first         — block Edit/Write on unread files (deny)
  6. pre_bash_python        — block long-running/complex commands (deny)
  7. pre_sentinel           — block repeated edits on same file (deny)
  8. pre_file_tracker       — multi-session file conflict (deny)
  9. pre_session_format     — session ID format validation (warn)
  10. pre_read_log          — log Read ops + soft read-first warn (warn)

Deny Marker: red ANSI stderr notification on every deny (default on, toggleable).
Fail-open: any crash -> allow (never block the user).
"""

from __future__ import annotations

import json
import os
import sys
from typing import Any

# ── Default Configuration ────────────────────────────────────────

_WORKSPACE = os.environ.get("CLAUDE_PROJECT_DIR", "")

_SHARED_BASENAMES = frozenset([
    "instance_lock.json", "compact_state.json", "active_tasks.md",
    "learnings.json", "corrections-queue.jsonl", "token_usage_log.jsonl",
    "drive-state.json", "attention-budget.json", "kb_index.md",
    "MEMORY.md", "CLAUDE.md",
])

_SHARED_PATHS = frozenset([
    "_AI_BRAIN/cognition_shared/instance_lock.json",
    "_AI_BRAIN/01_Memory/compact_state.json",
    "_AI_BRAIN/01_Memory/active_tasks.md",
])

_HANDOFF_PREFIXES = ("交接_", "task-pool")

_SESSION_PREFIXES = "CC|IA|PS|TR|BK|EV|AQ|SC|TK|GN|CCC"

_LOCK_PATH = os.path.join(_WORKSPACE, "_AI_BRAIN", "cognition_shared", "instance_lock.json")
_MARKER_DIR = os.path.join(_WORKSPACE, ".cc_cortex_cache", "sessions")

_DENY_COUNTER_DIR = (
    os.path.join(_WORKSPACE, ".cc_cortex_cache", "deny_counts") if _WORKSPACE else ""
)


# ── Pipeline ─────────────────────────────────────────────────────

def main(hook_data: dict | None = None) -> None:
    """Entry point. Accepts hook_data dict or reads from stdin."""
    try:
        if hook_data is None:
            hook_data = json.loads(sys.stdin.read())
    except Exception:
        _allow()
        return

    tool_name = hook_data.get("tool_name", "")
    tool_input = hook_data.get("tool_input", {})
    session_id = hook_data.get("session_id", "")

    # 1. pre_window_guard (deny)
    flash_deny = _run_pre_window_guard(tool_name, tool_input)
    if flash_deny:
        _emit_deny_stderr(session_id, flash_deny)
        json.dump({
            "permissionDecision": "deny",
            "reason": flash_deny,
        }, sys.stdout, ensure_ascii=False)
        return

    # 2. pre_destruction_guard (deny)
    result = _run_pre_destruction_guard(tool_name, tool_input)
    if result and result.get("permissionDecision") != "allow":
        _emit_deny_stderr(session_id, result.get("reason", "destruction guard"))
        json.dump(result, sys.stdout, ensure_ascii=False)
        return

    # 3. pre_token_gate (deny Agent at 140K+)
    token_deny = _run_pre_token_gate(session_id, tool_name)
    if token_deny:
        _emit_deny_stderr(session_id, token_deny.get("reason", "token gate"))
        json.dump(token_deny, sys.stdout, ensure_ascii=False)
        return

    # 4. pre_agent_cap (deny Agent at ≥N spawns)
    agent_cap_deny = _run_pre_agent_cap(session_id, tool_name)
    if agent_cap_deny:
        _emit_deny_stderr(session_id, agent_cap_deny.get("reason", "agent cap"))
        json.dump(agent_cap_deny, sys.stdout, ensure_ascii=False)
        return

    # Track Write creates for ReadFirst exception
    if tool_name == "Write":
        try:
            fp = tool_input.get("file_path") or ""
            if fp and not os.path.exists(fp):
                from cc_cortex.pre_tool_guards import log_write_create

                log_write_create(fp)
        except Exception:
            pass

    # 5. pre_read_first (deny Edit/Write on unread files ≥N lines)
    rf_deny = _run_pre_read_first(session_id, tool_name, tool_input)
    if rf_deny:
        _emit_deny_stderr(session_id, rf_deny.get("reason", "read first"))
        json.dump(rf_deny, sys.stdout, ensure_ascii=False)
        return

    # 6. pre_bash_python (deny long-running / python -c >5 lines)
    bash_py_deny = _run_pre_bash_python(tool_name, tool_input)
    if bash_py_deny:
        _emit_deny_stderr(session_id, bash_py_deny.get("reason", "bash/python gate"))
        json.dump(bash_py_deny, sys.stdout, ensure_ascii=False)
        return

    # 7. pre_sentinel (deny repeated edits on same file)
    sentinel_deny = _run_pre_sentinel(session_id, tool_name, tool_input)
    if sentinel_deny:
        _emit_deny_stderr(session_id, sentinel_deny.get("reason", "sentinel"))
        json.dump(sentinel_deny, sys.stdout, ensure_ascii=False)
        return

    # 8. pre_file_tracker (deny file conflict)
    deny = _run_pre_file_tracker(session_id, tool_name, tool_input)
    if deny:
        _emit_deny_stderr(session_id, deny["reason"])
        json.dump({
            "permissionDecision": "deny",
            "reason": deny["reason"],
            "additionalContext": deny.get("additional", ""),
        }, sys.stdout, ensure_ascii=False)
        return

    # ── Past this point: all denies passed → collect context injections ──

    warnings: list[str] = []

    # 9. pre_session_format (warn)
    warnings.extend(_run_pre_session_format(tool_name, tool_input))

    # 10. pre_read_log (log reads + soft warn for small files)
    warnings.extend(_run_pre_read_log(tool_name, tool_input, session_id))

    # 11. handoff reminder (warn if overdue)
    handoff_warn = _run_handoff_reminder(tool_name, tool_input, session_id)
    if handoff_warn:
        warnings.append(handoff_warn)

    # Agent spawn counter → stderr only (user sees, model doesn't)
    _emit_agent_counter(session_id, tool_name, tool_input)

    # All passed — allow with optional context
    out: dict[str, Any] = {"permissionDecision": "allow"}
    if warnings:
        out["additionalContext"] = "\n".join(warnings)
    json.dump(out, sys.stdout, ensure_ascii=False)


# ── 1. pre_window_guard ─────────────────────────────────────────

def _run_pre_window_guard(tool_name: str, tool_input: dict) -> str | None:
    """Prevent console flash on Windows. Returns deny message or None."""
    try:
        from cc_cortex.window_guard import check as wg_check
        result = wg_check(tool_name, tool_input)
        return result["message"] if result else None
    except (ImportError, Exception):
        return None


# ── 2. pre_destruction_guard ────────────────────────────────────

def _run_pre_destruction_guard(tool_name: str, tool_input: dict) -> dict | None:
    """Risk-based destructive op interception. Returns result dict or None."""
    try:
        from cc_cortex.destruction_guard import evaluate
        return evaluate(tool_name, tool_input)
    except (ImportError, Exception):
        return None


# ── 3. pre_token_gate ───────────────────────────────────────────

def _run_pre_token_gate(session_id: str, tool_name: str) -> dict | None:
    """Block Agent spawn when tokens >= 140K. <5ms."""
    if tool_name != "Agent":
        return None
    try:
        from cc_cortex.handoff_engine import check_token_gate

        return check_token_gate(session_id, tool_name)
    except (ImportError, Exception):
        return None


# ── 4. pre_agent_cap ────────────────────────────────────────────

def _run_pre_agent_cap(session_id: str, tool_name: str) -> dict | None:
    """Block Agent at ≥N spawns per session. Configurable: features.agent_cap."""
    if tool_name != "Agent":
        return None
    try:
        from cc_cortex.core.config import get_config

        cfg = get_config()
        if not cfg.feature("agent_cap"):
            return None
        max_spawns = cfg.feature("agent_cap", "max_spawns") or 5

        from cc_cortex.agent_gate import gate_agent_cap

        state_dir = os.path.join(
            os.path.expanduser("~/.claude"), "token_state",
        )
        return gate_agent_cap(tool_name, session_id, state_dir, max_spawns=max_spawns)
    except (ImportError, Exception):
        return None


# ── 5. pre_read_first ───────────────────────────────────────────

def _run_pre_read_first(
    session_id: str, tool_name: str, tool_input: dict,
) -> dict | None:
    """Block Edit/Write on unread files ≥N lines. Configurable: features.read_first_gate."""
    if tool_name not in ("Write", "Edit"):
        return None
    try:
        from cc_cortex.core.config import get_config

        cfg = get_config()
        if not cfg.feature("read_first_gate"):
            return None
        min_lines = cfg.feature("read_first_gate", "min_lines") or 50

        from cc_cortex.pre_tool_guards import gate_read_first

        file_path = tool_input.get("file_path") or tool_input.get("path") or ""
        if not file_path:
            return None

        cache_dir = os.path.join(_WORKSPACE, ".cc_cortex_cache") if _WORKSPACE else ""
        if not cache_dir:
            return None

        return gate_read_first(file_path, cache_dir, session_id, min_lines=min_lines)
    except (ImportError, Exception):
        return None


# ── 6. pre_bash_python ──────────────────────────────────────────

def _run_pre_bash_python(tool_name: str, tool_input: dict) -> dict | None:
    """Block long-running Bash / python -c >5 lines. Configurable: features."""
    if tool_name != "Bash":
        return None
    try:
        from cc_cortex.core.config import get_config

        cfg = get_config()

        if cfg.feature("bash_guard"):
            from cc_cortex.pre_tool_guards import gate_bash_background

            deny = gate_bash_background(tool_input)
            if deny:
                return deny

        if cfg.feature("python_guard"):
            from cc_cortex.pre_tool_guards import gate_python_c

            deny = gate_python_c(tool_input)
            if deny:
                return deny
    except (ImportError, Exception):
        pass
    return None


# ── 7. pre_sentinel ─────────────────────────────────────────────

def _run_pre_sentinel(
    session_id: str, tool_name: str, tool_input: dict,
) -> dict | None:
    """Block repeated edits on same file. Configurable: features.sentinel_gate."""
    if tool_name not in ("Edit", "Write", "NotebookEdit"):
        return None
    try:
        from cc_cortex.core.config import get_config

        cfg = get_config()
        if not cfg.feature("sentinel_gate"):
            return None
        max_repeats = cfg.feature("sentinel_gate", "max_repeats") or 5
        lint_exception = cfg.feature("sentinel_gate", "lint_exception")
        if lint_exception is None:
            lint_exception = True

        from cc_cortex.sentinel import gate_sentinel

        state_dir = os.path.join(
            _WORKSPACE, ".cc_cortex_cache", "sentinel",
        ) if _WORKSPACE else ""
        if not state_dir:
            return None

        return gate_sentinel(
            session_id, tool_name, tool_input, state_dir,
            max_repeats=max_repeats, lint_exception=lint_exception,
        )
    except (ImportError, Exception):
        return None


# ── 8. pre_file_tracker ─────────────────────────────────────────

def _run_pre_file_tracker(session_id: str, tool_name: str, tool_input: dict) -> dict | None:
    """Multi-session file conflict detection. Returns deny dict or None."""
    if not session_id or not _WORKSPACE:
        return None
    try:
        from cc_cortex.file_tracker import FileTracker

        tracker = FileTracker(
            workspace=_WORKSPACE,
            lock_path=_LOCK_PATH,
            marker_dir=_MARKER_DIR,
            shared_basenames=_SHARED_BASENAMES,
            shared_paths=_SHARED_PATHS,
            handoff_prefixes=_HANDOFF_PREFIXES,
        )
        result = tracker.process(
            session_id=session_id,
            tool_name=tool_name,
            tool_input=tool_input,
            vscode_pid=_get_vscode_pid(),
        )
        if result and "deny" in result:
            return result["deny"]
    except (ImportError, Exception):
        pass
    return None


def _get_vscode_pid() -> int:
    try:
        return int(os.environ.get("VSCODE_PID", 0))
    except (ValueError, TypeError):
        return 0


# ── 9. pre_session_format ───────────────────────────────────────

def _run_pre_session_format(tool_name: str, tool_input: dict) -> list[str]:
    """Session ID format + task-pool validation. Returns warning list."""
    warnings: list[str] = []
    try:
        from cc_cortex.session_format import check_session_id, check_taskpool_required

        err = check_session_id(
            tool_name, tool_input,
            prefixes=_SESSION_PREFIXES,
            handoff_prefixes=_HANDOFF_PREFIXES,
        )
        if err:
            warnings.append(err)

        err = check_taskpool_required(
            tool_name, tool_input,
            handoff_prefixes=_HANDOFF_PREFIXES,
        )
        if err:
            warnings.append(err)
    except (ImportError, Exception):
        pass
    return warnings


# ── 10. pre_read_log ────────────────────────────────────────────

def _run_pre_read_log(
    tool_name: str, tool_input: dict, session_id: str,
) -> list[str]:
    """Log Read ops for ReadFirst gate. Soft warn on small-file edit-without-read."""
    warnings: list[str] = []
    try:
        from cc_cortex.pre_tool_guards import log_read

        cache_dir = os.path.join(_WORKSPACE, ".cc_cortex_cache") if _WORKSPACE else ""

        if tool_name == "Read":
            fp = tool_input.get("file_path", "")
            if fp and cache_dir:
                log_read(fp, cache_dir, session_id)
        elif tool_name in ("Write", "Edit"):
            from cc_cortex.pre_tool_guards import check_read_first

            fp = tool_input.get("file_path", "")
            if fp and cache_dir:
                warn = check_read_first(fp, cache_dir, session_id)
                if warn:
                    warnings.append(warn)
    except (ImportError, Exception):
        pass
    return warnings


# ── 11. handoff reminder ───────────────────────────────────────

def _run_handoff_reminder(
    tool_name: str, tool_input: dict, session_id: str,
) -> str | None:
    """Remind to write handoff when token usage is high + many files modified."""
    if not session_id:
        return None
    try:
        # Get current token usage
        from cc_cortex.token_monitor import read_real_token_usage

        transcript = os.path.join(
            os.path.expanduser("~/.claude"), "projects",
            session_id[:8] if session_id else "",
            "transcript.jsonl",
        )
        usage = read_real_token_usage(transcript)
        token_usage = usage["context_tokens"] if usage else 0

        from cc_cortex.handoff_engine import check_handoff_reminder

        return check_handoff_reminder(
            tool_name, tool_input, session_id, token_usage,
        )
    except (ImportError, Exception):
        return None


# ── Agent counter (stderr only — user sees, model doesn't) ─────

def _emit_agent_counter(session_id: str, tool_name: str, tool_input: dict) -> None:
    """Write agent spawn count to stderr. Zero model attention cost."""
    if tool_name != "Agent" or not session_id:
        return
    try:
        from cc_cortex.agent_gate import check as ag_check
        state_dir = os.path.join(
            os.path.expanduser("~/.claude"), "token_state"
        )
        result = ag_check(tool_name, tool_input, session_id, state_dir)
        if result:
            count = result["count"]
            sys.stderr.write(f"\033[33mAgent #{count}\033[0m\n")
            sys.stderr.flush()
    except (ImportError, Exception):
        pass


# ── Deny Marker (stderr red notification) ───────────────────────

def _is_deny_stderr_enabled() -> bool:
    try:
        from cc_cortex.core.config import get_config
        cfg = get_config()
        return bool(cfg.raw("deny_stderr", True))
    except (ImportError, Exception):
        return True


def _emit_deny_stderr(session_id: str, reason: str) -> None:
    """Red ANSI deny notification → stderr (user sees, model doesn't)."""
    if not _is_deny_stderr_enabled():
        return
    try:
        count = _increment_deny_count(session_id)
        short_reason = reason[:80] if reason else "unknown"
        sys.stderr.write(
            f"\033[91m✖ 阻擋 #{count}：{short_reason}\033[0m\n"
        )
        sys.stderr.flush()
    except Exception:
        pass


def _increment_deny_count(session_id: str) -> int:
    if not _DENY_COUNTER_DIR or not session_id:
        return 1
    try:
        os.makedirs(_DENY_COUNTER_DIR, exist_ok=True)
        safe_id = session_id[:8].replace("/", "_").replace("\\", "_")
        counter_file = os.path.join(_DENY_COUNTER_DIR, f"{safe_id}.count")
        count = 0
        if os.path.isfile(counter_file):
            with open(counter_file, "r") as f:
                count = int(f.read().strip() or "0")
        count += 1
        with open(counter_file, "w") as f:
            f.write(str(count))
        return count
    except Exception:
        return 1


# ── Helpers ──────────────────────────────────────────────────────

def _allow():
    json.dump({"permissionDecision": "allow"}, sys.stdout)


if __name__ == "__main__":
    main()
