"""Rules Bloat Guard — Prevent .claude/rules/ from exceeding size limits.

Monitors the total size of markdown files in the rules directory and
warns or blocks when writes would push it past configurable thresholds.
"""

from __future__ import annotations

import os
from typing import Optional

# ─── Constants ────────────────────────────────────────────

DEFAULT_LIMIT = 45000  # bytes — hard limit
DEFAULT_WARN_RATIO = 0.85  # warn at 85% of limit


# ─── Guard Check ─────────────────────────────────────────


def check(
    tool_name: str,
    tool_input: dict,
    rules_dir: str,
    *,
    limit: int = DEFAULT_LIMIT,
    warn_ratio: float = DEFAULT_WARN_RATIO,
) -> Optional[dict]:
    """Check if a Write/Edit to rules dir would exceed size limit.

    Args:
        tool_name: "Edit" or "Write" (others return None).
        tool_input: Tool input dict.
        rules_dir: Absolute path to .claude/rules/ directory.
        limit: Max total bytes for all .md files in rules_dir.
        warn_ratio: Fraction of limit at which to start warning.

    Returns:
        Dict {decision: "warn"|"deny", message, current, estimated}
        or None if OK.
    """
    if tool_name not in ("Edit", "Write"):
        return None
    if not isinstance(tool_input, dict):
        return None

    file_path = tool_input.get("file_path") or tool_input.get("path", "")
    if not file_path:
        return None

    fp_norm = file_path.replace("\\", "/")
    if "/.claude/rules/" not in fp_norm:
        return None
    if not file_path.lower().endswith(".md"):
        return None
    if not os.path.isdir(rules_dir):
        return None

    # Sum current .md file sizes
    current_total = 0
    try:
        for fname in os.listdir(rules_dir):
            if fname.endswith(".md"):
                try:
                    fpath = os.path.join(rules_dir, fname)
                    current_total += os.path.getsize(fpath)
                except OSError:
                    pass
    except OSError:
        return None

    # Estimate post-write total
    if tool_name == "Edit":
        old_str = tool_input.get("old_string", "")
        new_str = tool_input.get("new_string", "")
        old_b = len(old_str.encode("utf-8"))
        new_b = len(new_str.encode("utf-8"))
        estimated = current_total + new_b - old_b
    else:  # Write
        new_content = tool_input.get("content", "")
        try:
            old_size = os.path.getsize(file_path)
        except OSError:
            old_size = 0
        new_size = len(new_content.encode("utf-8"))
        estimated = current_total - old_size + new_size

    warn_threshold = int(limit * warn_ratio)

    if estimated > limit:
        return {
            "decision": "warn",
            "current": current_total,
            "estimated": estimated,
            "limit": limit,
            "message": (
                f"Rules bloat: write would reach "
                f"{estimated // 1000}K bytes "
                f"(limit {limit // 1000}K). "
                f"Simplify rules before adding more."
            ),
        }
    elif estimated > warn_threshold:
        return {
            "decision": "warn",
            "current": current_total,
            "estimated": estimated,
            "limit": limit,
            "message": (
                f"Rules approaching limit: "
                f"{estimated // 1000}K bytes "
                f"(warn {warn_threshold // 1000}K, "
                f"limit {limit // 1000}K). "
                f"Consider moving details to external files."
            ),
        }

    return None
