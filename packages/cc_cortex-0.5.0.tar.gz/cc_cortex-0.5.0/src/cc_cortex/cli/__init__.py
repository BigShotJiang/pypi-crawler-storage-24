"""cc-cortex CLI entry point."""

from .main import main

__all__ = ["main"]
