"""Agent Spawn Gate — Escalating warnings + hard cap for subagent overuse.

Tracks per-session agent spawn count and provides:
  - Soft warnings at warn_at threshold (additionalContext)
  - HARD DENY at max_spawns threshold (PreToolUse deny)

Misuse detection: flags patterns where direct tools would suffice.
"""

from __future__ import annotations

import os
from typing import Optional

# ─── Constants ────────────────────────────────────────────

DEFAULT_THRESHOLDS = [3, 5]  # escalation at these counts

# Keywords that suggest misuse (could use direct tools instead)
_MISUSE_PATTERNS = {
    "read": [
        "read the file",
        "read this file",
        "cat ",
        "看一下",
        "讀取",
        "讀這個",
    ],
    "search": [
        "search for",
        "find the",
        "grep",
        "找一下",
        "搜尋",
        "搜一下",
    ],
    "edit": [
        "edit",
        "write",
        "modify",
        "改",
        "寫入",
        "修改",
    ],
}

_MISUSE_HINTS = {
    "read": "Use Read tool directly instead of spawning an agent",
    "search": (
        "Simple searches: Grep/Glob. Only use Explore agent for complex multi-step exploration"
    ),
    "edit": "Edit/Write from main thread, no agent needed",
}


# ─── Gate Check ───────────────────────────────────────────


def check(
    tool_name: str,
    tool_input: dict,
    session_id: str,
    state_dir: str,
    *,
    thresholds: Optional[list[int]] = None,
    lang: str = "en",
) -> Optional[dict]:
    """Check agent spawn and return escalating warning if needed.

    Args:
        tool_name: Must be "Agent" to trigger.
        tool_input: Tool input dict (prompt, subagent_type, etc).
        session_id: Current session ID.
        state_dir: Directory for persisting spawn counts.
        thresholds: [warn_count, critical_count]. Default [3, 5].
        lang: "en" or "zh" for message language.

    Returns:
        Dict with {decision, level, count, message, hints} or None.
    """
    if tool_name != "Agent":
        return None

    if not session_id:
        return None

    if thresholds is None:
        thresholds = DEFAULT_THRESHOLDS

    short_id = session_id[:8]
    count_file = os.path.join(state_dir, f"{short_id}_agent_count")
    os.makedirs(state_dir, exist_ok=True)

    # Read + increment count
    count = 0
    try:
        if os.path.isfile(count_file):
            with open(count_file) as f:
                count = int(f.read().strip())
    except Exception:
        pass
    count += 1
    try:
        with open(count_file, "w") as f:
            f.write(str(count))
    except Exception:
        pass

    # Detect misuse patterns
    prompt = (tool_input.get("prompt") or "")[:200].lower()
    subagent_type = tool_input.get("subagent_type", "")
    hints = []

    for category, keywords in _MISUSE_PATTERNS.items():
        if any(kw in prompt for kw in keywords):
            if category == "search" and subagent_type == "Explore":
                continue  # Explore agent for search is OK
            hints.append(_MISUSE_HINTS[category])

    # Determine escalation level
    warn_at = thresholds[0] if len(thresholds) > 0 else 3
    crit_at = thresholds[1] if len(thresholds) > 1 else 5

    if count >= crit_at:
        level = "critical"
    elif count >= warn_at:
        level = "warning"
    else:
        level = "info"

    return {
        "permissionDecision": "allow",
        "level": level,
        "count": count,
        "hints": hints,
    }


# ── Hard Cap Gate (DENY) ─────────────────────────────────


def gate_agent_cap(
    tool_name: str,
    session_id: str,
    state_dir: str,
    *,
    max_spawns: int = 5,
) -> Optional[dict]:
    """DENY Agent spawn when session count >= max_spawns.

    Returns deny dict for PreToolUse hook, or None if allowed.
    Does NOT increment counter (check() does that).

    Performance: <1ms (read counter file).
    """
    if tool_name != "Agent" or not session_id:
        return None

    short_id = session_id[:8]
    count_file = os.path.join(state_dir, f"{short_id}_agent_count")

    try:
        if not os.path.isfile(count_file):
            return None
        with open(count_file) as f:
            count = int(f.read().strip())
    except Exception:
        return None

    if count < max_spawns:
        return None

    return {
        "permissionDecision": "deny",
        "reason": (
            f"Agent Cap: {count}/{max_spawns} spawns this session — "
            f"limit reached"
        ),
        "additionalContext": (
            f"You've spawned {count} agents this session (cap: {max_spawns}). "
            f"Use direct tools (Read, Grep, Glob, Edit) for remaining work. "
            f"Agent spawns waste tokens when direct tools suffice."
        ),
    }
