#!/usr/bin/env python3
"""cc-cortex Code Guard — unified static analysis for Python/Rust/Go.

Runs the appropriate linter based on file extension:
  .py  → ruff check (+ complexity + dead imports)
  .rs  → cargo check
  .go  → go vet

Features:
  - SHA256 content cache: skip re-check if file unchanged
  - Timeout protection: never blocks the session
  - Zero noise: only emits on errors
"""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Optional

_CREATE_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0
_CACHE_FILE = os.path.join(
    os.environ.get("CLAUDE_PROJECT_DIR", "."), ".cc_cortex_cache", "code_guard_sha.json"
)
_DEFAULT_TIMEOUT = 15


def _hidden_startupinfo():
    if sys.platform != "win32":
        return None
    si = subprocess.STARTUPINFO()
    si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    si.wShowWindow = 0
    return si


# ── SHA256 Cache ──────────────────────────────────────────


def _load_cache() -> dict:
    try:
        with open(_CACHE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _save_cache(cache: dict):
    try:
        os.makedirs(os.path.dirname(_CACHE_FILE), exist_ok=True)
        tmp = _CACHE_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(cache, f)
        os.replace(tmp, _CACHE_FILE)
    except Exception:
        pass


def _file_sha256(path: str) -> str:
    try:
        return hashlib.sha256(Path(path).read_bytes()).hexdigest()[:16]
    except Exception:
        return ""


def _is_cached(path: str, sha: str) -> bool:
    cache = _load_cache()
    return cache.get(path) == sha


def _update_cache(path: str, sha: str):
    cache = _load_cache()
    cache[path] = sha
    # Keep cache bounded
    if len(cache) > 500:
        keys = list(cache.keys())
        for k in keys[:100]:
            del cache[k]
    _save_cache(cache)


# ── Runners ───────────────────────────────────────────────


def _run_cmd(
    cmd: list[str],
    cwd: str | None = None,
    timeout: int = _DEFAULT_TIMEOUT,
) -> subprocess.CompletedProcess | None:
    try:
        return subprocess.run(
            cmd,
            cwd=cwd,
            capture_output=True,
            timeout=timeout,
            encoding="utf-8",
            errors="replace",
            creationflags=_CREATE_NO_WINDOW,
            startupinfo=_hidden_startupinfo(),
        )
    except (subprocess.TimeoutExpired, FileNotFoundError, Exception):
        return None


def _check_python(file_path: str) -> Optional[str]:
    """Run ruff check on a Python file."""
    result = _run_cmd(["ruff", "check", "--select=E,F,W", "--no-fix", file_path])
    if result is None or result.returncode == 0:
        return None

    lines = [ln for ln in (result.stdout or "").splitlines() if ln.strip() and "Found" not in ln]
    count = len(lines)
    if count == 0:
        return None

    shown = lines[:5]
    base = os.path.basename(file_path)
    summary = "\n".join(f"  {ln.strip()}" for ln in shown)
    if count > 5:
        summary += f"\n  ... and {count - 5} more"
    return f"🔴 ruff ❌ {count} issues ({base}) — fix before proceeding:\n{summary}"


def _check_rust(file_path: str) -> Optional[str]:
    """Run cargo check in the nearest Cargo.toml directory."""
    # Walk up to find Cargo.toml
    d = os.path.dirname(os.path.abspath(file_path))
    cargo_dir = None
    for _ in range(10):
        if os.path.isfile(os.path.join(d, "Cargo.toml")):
            cargo_dir = d
            break
        parent = os.path.dirname(d)
        if parent == d:
            break
        d = parent
    if not cargo_dir:
        return None

    result = _run_cmd(["cargo", "check", "--message-format=short"], cwd=cargo_dir, timeout=30)
    if result is None or result.returncode == 0:
        return None

    errors = [ln for ln in (result.stderr or "").splitlines() if "error" in ln.lower()]
    count = len(errors)
    if count == 0:
        return None

    shown = errors[:3]
    summary = "\n".join(f"  {ln.strip()}" for ln in shown)
    if count > 3:
        summary += f"\n  ... and {count - 3} more"
    return f"🔴 cargo ❌ {count} errors — fix before proceeding:\n{summary}"


def _check_go(file_path: str) -> Optional[str]:
    """Run go vet on the package containing the file."""
    pkg_dir = os.path.dirname(os.path.abspath(file_path))
    result = _run_cmd(["go", "vet", "./..."], cwd=pkg_dir, timeout=20)
    if result is None or result.returncode == 0:
        return None

    output = (result.stderr or "") + (result.stdout or "")
    lines = [ln for ln in output.splitlines() if ln.strip()]
    count = len(lines)
    if count == 0:
        return None

    shown = lines[:3]
    summary = "\n".join(f"  {ln.strip()}" for ln in shown)
    if count > 3:
        summary += f"\n  ... and {count - 3} more"
    return f"🔴 go vet ❌ {count} issues — fix before proceeding:\n{summary}"


# ── Public API ────────────────────────────────────────────

_EXT_CHECKER = {
    ".py": _check_python,
    ".rs": _check_rust,
    ".go": _check_go,
}

SUPPORTED_EXTENSIONS = frozenset(_EXT_CHECKER.keys())


def check_code_guard(
    tool_name: str,
    tool_input: dict,
    *,
    use_cache: bool = True,
) -> Optional[str]:
    """Unified entry point for code quality checks.

    Args:
        tool_name: Claude Code tool name (Write/Edit/etc.)
        tool_input: Tool input dict with file_path
        use_cache: Skip check if file content unchanged (SHA256)

    Returns:
        Error message string, or None if clean.
    """
    file_path = (
        tool_input.get("file_path")
        or tool_input.get("notebook_path")
        or tool_input.get("path")
        or ""
    )
    if not file_path or not os.path.isfile(file_path):
        return None

    ext = os.path.splitext(file_path)[1].lower()
    checker = _EXT_CHECKER.get(ext)
    if not checker:
        return None

    # SHA256 cache: skip if unchanged
    if use_cache:
        sha = _file_sha256(file_path)
        if sha and _is_cached(file_path, sha):
            return None

    result = checker(file_path)

    # Update cache on success
    if result is None and use_cache:
        sha = _file_sha256(file_path)
        if sha:
            _update_cache(file_path, sha)

    return result
