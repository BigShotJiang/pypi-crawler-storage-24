"""Abstract base class for multi-instance coordination strategies.

All coordination implementations must subclass CoordinationStrategy
and implement every abstract method.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class SessionInfo:
    """Immutable snapshot of a registered session."""

    session_id: str
    pid: int
    started_at: str
    active_files: list[str] = field(default_factory=list)


@dataclass
class LockResult:
    """Result of a file-lock acquisition attempt."""

    success: bool
    holder: Optional[str] = None  # who holds the lock if failed
    message: str = ""


class CoordinationStrategy(ABC):
    """Base class for multi-instance coordination strategies.

    Implementations can use file locks, in-memory state, SDK-level
    coordination, or any other mechanism — as long as they honour this
    contract.
    """

    @abstractmethod
    def register_session(self, info: SessionInfo) -> bool:
        """Register a new session.  Returns True on success."""
        ...

    @abstractmethod
    def unregister_session(self, session_id: str) -> bool:
        """Remove a session from the registry.  Returns True if it existed."""
        ...

    @abstractmethod
    def acquire_file_lock(self, session_id: str, file_path: str) -> LockResult:
        """Try to claim *file_path* for *session_id*.

        Returns a ``LockResult`` indicating success or who currently holds
        the lock.
        """
        ...

    @abstractmethod
    def release_file_lock(self, session_id: str, file_path: str) -> bool:
        """Release a previously acquired file lock.  Returns True if released."""
        ...

    @abstractmethod
    def get_active_sessions(self) -> list[SessionInfo]:
        """Return a list of all currently active sessions."""
        ...

    @abstractmethod
    def cleanup_zombies(self, timeout_seconds: int = 1800) -> list[str]:
        """Remove sessions that have been inactive for *timeout_seconds*.

        Returns a list of removed session IDs.
        """
        ...

    @abstractmethod
    def check_conflict(self, session_id: str, file_path: str) -> Optional[str]:
        """Check whether *file_path* conflicts with another session.

        Returns the conflicting session ID, or ``None`` if no conflict.
        """
        ...
