"""File-based JSON lock coordination strategy.

Wraps the battle-tested logic from ``cc_cortex.multi_instance`` behind the
``CoordinationStrategy`` interface so it can be swapped for an SDK-level
implementation later.

The underlying data lives in a JSON file on disk (the same ``instance_lock.json``
used today).  All public helpers in ``multi_instance`` are re-used — this class
is a thin adapter, *not* a rewrite.
"""

import json
import os
from datetime import datetime, timezone
from typing import Optional

from cc_cortex.multi_instance import (
    check_conflict as _check_conflict,
)
from cc_cortex.multi_instance import (
    clean_zombies as _clean_zombies,
)
from cc_cortex.multi_instance import (
    register_session as _register_session,
)
from cc_cortex.multi_instance import (
    remove_session as _remove_session,
)
from cc_cortex.multi_instance import (
    track_file as _track_file,
)

from .base import CoordinationStrategy, LockResult, SessionInfo

_DEFAULT_LOCK_PATH = os.path.join(
    os.path.expanduser("~"), ".claude", "token_state", "instance_lock.json"
)


class FileLockStrategy(CoordinationStrategy):
    """Coordinate multiple Claude Code sessions via a shared JSON file.

    Parameters
    ----------
    lock_path : str | None
        Path to the JSON lock file.  Defaults to
        ``~/.claude/token_state/instance_lock.json``.
    marker_dir : str | None
        Directory for per-session marker files.  Defaults to
        ``~/.claude/token_state/``.
    """

    def __init__(
        self,
        lock_path: Optional[str] = None,
        marker_dir: Optional[str] = None,
    ) -> None:
        self.lock_path = lock_path or _DEFAULT_LOCK_PATH
        self.marker_dir = marker_dir or os.path.dirname(self.lock_path)

    # ── helpers ────────────────────────────────────────────────────

    def _read_lock(self) -> dict:
        """Read the lock file, returning empty structure on any error."""
        try:
            with open(self.lock_path, "r", encoding="utf-8") as fh:
                return json.load(fh)
        except (FileNotFoundError, json.JSONDecodeError):
            return {"sessions": {}}

    def _write_lock(self, data: dict) -> None:
        """Atomically write the lock file."""
        os.makedirs(os.path.dirname(self.lock_path), exist_ok=True)
        tmp = self.lock_path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False, indent=2)
        os.replace(tmp, self.lock_path)

    @staticmethod
    def _now_iso() -> str:
        return datetime.now(timezone.utc).isoformat()

    def _session_key(self, session_id: str) -> str:
        return f"cc_{session_id[:8]}" if len(session_id) > 8 else f"cc_{session_id}"

    # ── CoordinationStrategy implementation ────────────────────────

    def register_session(self, info: SessionInfo) -> bool:
        lock = self._read_lock()
        key = self._session_key(info.session_id)
        now = self._now_iso()
        _register_session(lock, key, info.session_id, vscode_pid=info.pid, now=now)
        # Track initially declared files
        for fp in info.active_files:
            _track_file(lock, key, fp, now=now)
        self._write_lock(lock)
        return True

    def unregister_session(self, session_id: str) -> bool:
        lock = self._read_lock()
        key = self._session_key(session_id)
        if key not in lock.get("sessions", {}):
            return False
        _remove_session(lock, key)
        self._write_lock(lock)
        return True

    def acquire_file_lock(self, session_id: str, file_path: str) -> LockResult:
        lock = self._read_lock()
        key = self._session_key(session_id)
        sessions = lock.get("sessions", {})

        # Must be registered first
        if key not in sessions:
            return LockResult(success=False, message="Session not registered")

        # Check for conflicts
        conflict = _check_conflict(sessions, key, file_path)
        if conflict:
            return LockResult(
                success=False,
                holder=conflict.get("key"),
                message=f"File held by {conflict.get('holder', conflict['key'])}",
            )

        # Claim the file
        now = self._now_iso()
        _track_file(lock, key, file_path, now=now)
        self._write_lock(lock)
        return LockResult(success=True)

    def release_file_lock(self, session_id: str, file_path: str) -> bool:
        lock = self._read_lock()
        key = self._session_key(session_id)
        session = lock.get("sessions", {}).get(key)
        if not session:
            return False
        files = session.get("files", [])
        if file_path in files:
            files.remove(file_path)
            session.get("file_timestamps", {}).pop(file_path, None)
            self._write_lock(lock)
            return True
        return False

    def get_active_sessions(self) -> list[SessionInfo]:
        lock = self._read_lock()
        result: list[SessionInfo] = []
        for key, data in lock.get("sessions", {}).items():
            result.append(
                SessionInfo(
                    session_id=data.get("session_id", key),
                    pid=data.get("vscode_pid", 0),
                    started_at=data.get("started", ""),
                    active_files=list(data.get("files", [])),
                )
            )
        return result

    def cleanup_zombies(self, timeout_seconds: int = 1800) -> list[str]:
        lock = self._read_lock()
        removed = _clean_zombies(
            lock,
            threshold_sec=timeout_seconds,
            marker_dir=self.marker_dir,
        )
        if removed:
            self._write_lock(lock)
        return removed

    def check_conflict(self, session_id: str, file_path: str) -> Optional[str]:
        lock = self._read_lock()
        key = self._session_key(session_id)
        sessions = lock.get("sessions", {})
        conflict = _check_conflict(sessions, key, file_path)
        if conflict:
            return conflict["key"]
        return None
