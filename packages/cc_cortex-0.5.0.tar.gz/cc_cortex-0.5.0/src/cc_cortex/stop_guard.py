"""cc_cortex.stop_guard — Detect premature or suspicious session stops.

Analyzes the last assistant message to classify how the session ended:
  - clean: completion keywords present, no pending work
  - question: assistant asked a question (may be waiting for user)
  - continuation: assistant expressed intent to continue (premature stop)
  - pending: unfinished tasks detected without completion signal
  - unknown: insufficient data to classify

Usage:
    from cc_cortex.stop_guard import classify_stop
    result = classify_stop(hook_data)
    if result.premature:
        print(result.warning)
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class StopResult:
    """Classification result for a session stop event."""

    category: str  # clean | question | continuation | pending | unknown
    premature: bool  # True if stop looks unintentional
    signals: list[str] = field(default_factory=list)  # matched keywords/patterns
    warning: str = ""  # human-readable warning (empty if clean)


def _get_stop_config() -> dict:
    """Load stop_guard config from Config singleton."""
    try:
        from cc_cortex.core.config import get_config

        return get_config().raw("stop_guard", {})
    except Exception:
        return {}


def _extract_last_assistant_text(hook_data: dict) -> str:
    """Extract the last assistant message text from hook_data.

    Claude Code Stop hook provides ``stop_hook_active`` and the transcript
    in ``messages`` (list of {role, content}).  We grab the last assistant turn.
    """
    messages = hook_data.get("messages", [])
    # Walk backwards to find last assistant message
    for msg in reversed(messages):
        role = msg.get("role", "")
        if role != "assistant":
            continue
        content = msg.get("content", "")
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            parts = []
            for part in content:
                if isinstance(part, dict) and part.get("type") == "text":
                    parts.append(part.get("text", ""))
            return "\n".join(parts)
    return ""


def _match_any(text: str, patterns: list[str]) -> list[str]:
    """Return all patterns found in *text* (case-insensitive)."""
    lower = text.lower()
    return [p for p in patterns if p.lower() in lower]


def classify_stop(hook_data: dict | None = None) -> StopResult:
    """Classify a Stop event and return a :class:`StopResult`.

    Args:
        hook_data: The raw hook JSON from Claude Code's Stop event.
                   If *None* or missing ``messages``, returns ``unknown``.
    """
    if not hook_data:
        return StopResult(category="unknown", premature=False)

    text = _extract_last_assistant_text(hook_data)
    if not text:
        return StopResult(category="unknown", premature=False)

    cfg = _get_stop_config()
    if not cfg.get("enabled", True):
        return StopResult(category="clean", premature=False)

    completion_kw = cfg.get("completion_keywords", [])
    question_kw = cfg.get("question_keywords", [])
    continuation_pat = cfg.get("continuation_patterns", [])
    pending_pat = cfg.get("pending_patterns", [])

    # Check each category
    completions = _match_any(text, completion_kw)
    questions = _match_any(text, question_kw)
    continuations = _match_any(text, continuation_pat)
    pendings = _match_any(text, pending_pat)

    # Priority: continuation > pending > question > clean
    if continuations and not completions:
        return StopResult(
            category="continuation",
            premature=True,
            signals=continuations,
            warning=f"Stop while assistant intended to continue: {', '.join(continuations[:3])}",
        )

    if pendings and not completions:
        return StopResult(
            category="pending",
            premature=True,
            signals=pendings,
            warning=f"Stop with pending tasks: {', '.join(pendings[:3])}",
        )

    if questions and not completions:
        return StopResult(
            category="question",
            premature=False,  # asking a question is a valid stop point
            signals=questions,
            warning="",
        )

    if completions:
        return StopResult(
            category="clean",
            premature=False,
            signals=completions,
            warning="",
        )

    return StopResult(category="unknown", premature=False)


def on_stop(hook_data: dict) -> str | None:
    """Hook entry point — returns a warning string if premature, else None."""
    result = classify_stop(hook_data)
    if result.premature:
        return result.warning
    return None
