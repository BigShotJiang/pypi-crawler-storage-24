"""
cc_cortex.mcp_server -- MCP (Model Context Protocol) Server for CC Cortex.

Exposes CC Cortex status, metrics, and knowledge via JSON-RPC over stdio.
Zero external dependencies -- hand-rolled MCP protocol implementation.

Resources:
    cc-cortex://session/status    -- Current session state
    cc-cortex://metrics/quality   -- C4 quality scores
    cc-cortex://metrics/tokens    -- Token usage stats
    cc-cortex://knowledge/stats   -- Knowledge base statistics

Tools:
    cc-cortex-status  -- Full module status dashboard
    cc-cortex-doctor  -- Health check

Usage:
    python -m cc_cortex.mcp_server
"""

from __future__ import annotations

import json
import os
import sys
from datetime import datetime, timezone
from typing import Any, Optional

# ── MCP Protocol Constants ────────────────────────────────

MCP_PROTOCOL_VERSION = "2025-03-26"
SERVER_NAME = "cc-cortex"
SERVER_VERSION = "0.3.0"

RESOURCES = [
    {
        "uri": "cc-cortex://session/status",
        "name": "Session Status",
        "description": "Session state: ID, start time, active files, token usage, quality grade",
        "mimeType": "application/json",
    },
    {
        "uri": "cc-cortex://metrics/quality",
        "name": "Quality Metrics",
        "description": "C4 quality scores: completion, accuracy, focus, efficiency, overall grade",
        "mimeType": "application/json",
    },
    {
        "uri": "cc-cortex://metrics/tokens",
        "name": "Token Usage",
        "description": "Token consumption: current usage, budget, percentage, tier level",
        "mimeType": "application/json",
    },
    {
        "uri": "cc-cortex://knowledge/stats",
        "name": "Knowledge Stats",
        "description": (
            "Knowledge base statistics: total entries, recent corrections, staleness ratio"
        ),
        "mimeType": "application/json",
    },
]

TOOLS = [
    {
        "name": "cc-cortex-status",
        "description": (
            "Returns full module status dashboard (equivalent to `cc-cortex status` CLI)"
        ),
        "inputSchema": {
            "type": "object",
            "properties": {},
            "required": [],
        },
    },
    {
        "name": "cc-cortex-doctor",
        "description": (
            "Run health check on CC Cortex installation (equivalent to `cc-cortex doctor` CLI)"
        ),
        "inputSchema": {
            "type": "object",
            "properties": {},
            "required": [],
        },
    },
]


# ── Data Readers ──────────────────────────────────────────


def _read_json_file(path: str) -> dict:
    """Read a JSON file, returning empty dict on failure."""
    try:
        if os.path.isfile(path):
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return {}


def _cfg():
    """Return the Config singleton, initialised with default hooks dir."""
    from cc_cortex.core.config import get_config

    hooks_dir = os.path.join(os.path.expanduser("~"), ".claude", "hooks")
    return get_config(hooks_dir=hooks_dir)


# ── Resource Data Providers ───────────────────────────────


def read_session_status() -> dict:
    """Read current session status from instance_lock.json and session state."""
    cfg = _cfg()
    lock_path = cfg.path("instance_lock")
    if not lock_path:
        lock_path = os.path.join(
            cfg.workspace,
            ".claude-forge",
            "state",
            "instance_lock.json",
        )

    lock_data = _read_json_file(lock_path)
    sessions = lock_data.get("sessions", {})

    # Find current session (most recently active)
    current = None
    latest_ts = ""
    for _key, session in sessions.items():
        la = session.get("last_active", "")
        if la > latest_ts:
            latest_ts = la
            current = session

    if not current:
        return {
            "session_id": None,
            "start_time": None,
            "active_files": [],
            "active_sessions_count": 0,
            "token_usage": None,
            "quality_grade": None,
        }

    # Read token state if available
    token_state_dir = os.path.join(os.path.expanduser("~"), ".claude", "token_state")
    session_id = current.get("session_id", "")
    short_id = session_id[:8] if session_id else ""
    token_usage = None

    if short_id:
        # Look for token tracking file
        token_file = os.path.join(token_state_dir, f"{short_id}_tokens")
        if os.path.isfile(token_file):
            try:
                with open(token_file, "r") as f:
                    token_usage = int(f.read().strip())
            except Exception:
                pass

    return {
        "session_id": current.get("session_id", ""),
        "start_time": current.get("started", ""),
        "last_active": current.get("last_active", ""),
        "active_files": current.get("files", []),
        "active_files_count": len(current.get("files", [])),
        "holder": current.get("holder", ""),
        "project": current.get("project", ""),
        "task": current.get("task", ""),
        "active_sessions_count": len(sessions),
        "token_usage": token_usage,
        "quality_grade": None,  # Populated from cognitive if available
    }


def read_quality_metrics() -> dict:
    """Read C4 quality scores from cognitive layer."""
    cognitive_dir = os.path.join(
        os.path.expanduser("~"),
        ".claude",
        "cognitive",
    )

    # Read decision journal for quality score
    journal_path = os.path.join(cognitive_dir, "decision_journal.json")
    journal_data = _read_json_file(journal_path)
    entries = journal_data.get("entries", [])

    # Calculate quality dimensions
    scored = [e for e in entries if e.get("outcome")]
    total = len(scored)

    if total == 0:
        return {
            "completion": None,
            "accuracy": None,
            "focus": None,
            "efficiency": None,
            "overall_grade": "N/A",
            "total_decisions": len(entries),
            "scored_decisions": 0,
        }

    weights = {"accepted": 1.0, "ignored": 0.7, "corrected": 0.0, "reverted": 0.0}
    quality = sum(weights.get(e.get("outcome", ""), 0.5) for e in scored) / total

    # Derive dimensional scores from available data
    outcomes = {}
    for e in scored:
        o = e.get("outcome", "unknown")
        outcomes[o] = outcomes.get(o, 0) + 1

    accepted_ratio = outcomes.get("accepted", 0) / total if total else 0
    corrected_ratio = outcomes.get("corrected", 0) / total if total else 0

    # Grade mapping
    if quality >= 0.9:
        grade = "A+"
    elif quality >= 0.8:
        grade = "A"
    elif quality >= 0.7:
        grade = "B+"
    elif quality >= 0.6:
        grade = "B"
    elif quality >= 0.5:
        grade = "C"
    elif quality >= 0.4:
        grade = "D"
    else:
        grade = "F"

    return {
        "completion": round(accepted_ratio, 3),
        "accuracy": round(1.0 - corrected_ratio, 3),
        "focus": round(quality, 3),
        "efficiency": round(quality, 3),
        "overall_grade": grade,
        "overall_score": round(quality, 3),
        "total_decisions": len(entries),
        "scored_decisions": total,
        "outcomes": outcomes,
    }


def read_token_usage() -> dict:
    """Read token usage from token tracking files."""
    cfg = _cfg()
    budget = cfg.threshold("default_token_budget", 40000)

    token_state_dir = os.path.join(os.path.expanduser("~"), ".claude", "token_state")
    current_usage = 0

    # Read the most recent token state file
    if os.path.isdir(token_state_dir):
        try:
            for f in sorted(os.listdir(token_state_dir), reverse=True):
                if f.endswith("_tokens"):
                    fpath = os.path.join(token_state_dir, f)
                    try:
                        with open(fpath, "r") as fh:
                            current_usage = int(fh.read().strip())
                        break
                    except Exception:
                        continue
        except Exception:
            pass

    percentage = round(current_usage / budget * 100, 1) if budget > 0 else 0

    # Determine tier based on token warnings config
    if current_usage >= 180000:
        tier = "emergency"
    elif current_usage >= 140000:
        tier = "critical"
    elif current_usage >= 100000:
        tier = "warn"
    else:
        tier = "info"

    return {
        "current_usage": current_usage,
        "budget": budget,
        "percentage": percentage,
        "tier": tier,
        "tier_thresholds": {
            "info": 0,
            "warn": 100000,
            "critical": 140000,
            "emergency": 180000,
        },
    }


def read_knowledge_stats() -> dict:
    """Read knowledge base statistics from learnings.json."""
    cfg = _cfg()
    learnings_path = cfg.path("learnings")
    if not learnings_path:
        learnings_path = os.path.join(
            cfg.workspace,
            ".claude-forge",
            "memory",
            "evolution",
            "learnings.json",
        )

    data = _read_json_file(learnings_path)
    learnings = data.get("learnings", [])
    total = len(learnings)

    if total == 0:
        return {
            "total_entries": 0,
            "recent_corrections": 0,
            "staleness_ratio": 0.0,
            "promoted_count": 0,
            "high_frequency_count": 0,
        }

    # Count recent corrections (last 7 days)
    now = datetime.now(timezone.utc)
    recent_count = 0
    stale_count = 0
    promoted_count = 0
    high_freq_count = 0

    for item in learnings:
        # Recent
        last_seen = item.get("last_seen", "")
        if last_seen:
            try:
                ts = datetime.fromisoformat(last_seen)
                if ts.tzinfo is None:
                    ts = ts.replace(tzinfo=timezone.utc)
                days_ago = (now - ts).days
                if days_ago <= 7:
                    recent_count += 1
                if days_ago > 90:
                    stale_count += 1
            except (ValueError, TypeError):
                pass

        # Promoted
        if item.get("promoted"):
            promoted_count += 1

        # High frequency
        if item.get("count", 0) >= 3:
            high_freq_count += 1

    staleness_ratio = round(stale_count / total, 3) if total else 0.0

    return {
        "total_entries": total,
        "recent_corrections": recent_count,
        "staleness_ratio": staleness_ratio,
        "stale_count": stale_count,
        "promoted_count": promoted_count,
        "high_frequency_count": high_freq_count,
        "last_updated": data.get("last_updated", ""),
    }


# ── Tool Handlers ─────────────────────────────────────────


def handle_status() -> str:
    """Execute cc-cortex status and return formatted output."""
    try:
        from cc_cortex.cli.main import MODULES, _load_module_states
    except ImportError:
        MODULES = {}

        def _load_module_states() -> dict:
            return {}

    lines = ["cc-cortex modules:", ""]
    states = _load_module_states()

    if MODULES:
        for name, info in MODULES.items():
            if info.get("required"):
                icon = "locked"
                label = "always on"
            elif name in states:
                icon = "on" if states[name] else "off"
                label = "enabled" if states[name] else "disabled"
            else:
                icon = "on" if info.get("default") else "off"
                label = "default"
            lines.append(f"  [{icon}] {name:20s} {info['description']:40s} ({label})")
    else:
        lines.append("  (module registry not available)")

    config_path = _cfg().config_file_path
    if config_path and os.path.isfile(config_path):
        lines.append(f"\n  Config: {config_path}")
    else:
        lines.append("\n  Config: not found (run `cc-cortex init`)")

    return "\n".join(lines)


def handle_doctor() -> str:
    """Execute cc-cortex doctor and return formatted output."""
    lines = ["cc-cortex doctor", ""]
    issues = 0
    hooks_dir = os.path.join(os.path.expanduser("~"), ".claude", "hooks")
    config_path = _cfg().config_file_path or os.path.join(hooks_dir, "cc_config.json")

    # 1. Config file
    if os.path.isfile(config_path):
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                json.load(f)
            lines.append("  [ok] cc_config.json -- valid")
        except Exception as exc:
            lines.append(f"  [error] cc_config.json -- invalid JSON: {exc}")
            issues += 1
    else:
        lines.append("  [error] cc_config.json -- not found")
        issues += 1

    # 2. Hook files
    hook_files = [
        "on-session-start.py",
        "on-stop.py",
        "on-pre-tool.py",
        "on-post-tool.py",
        "extract-learnings.py",
    ]
    for hf in hook_files:
        path = os.path.join(hooks_dir, hf)
        if os.path.isfile(path):
            lines.append(f"  [ok] {hf}")
        else:
            lines.append(f"  [missing] {hf}")
            issues += 1

    # 3. Settings hook registration
    settings_path = os.path.join(os.path.expanduser("~"), ".claude", "settings.json")
    if os.path.isfile(settings_path):
        try:
            with open(settings_path, "r", encoding="utf-8") as f:
                settings = json.load(f)
            hooks_cfg = settings.get("hooks", {})
            for hf, event in [
                ("on-session-start.py", "SessionStart"),
                ("on-stop.py", "Stop"),
                ("on-pre-tool.py", "PreToolUse"),
                ("on-post-tool.py", "PostToolUse"),
            ]:
                found = any(
                    hf in h.get("command", "")
                    for group in hooks_cfg.get(event, [])
                    for h in group.get("hooks", [])
                )
                status = "ok" if found else "not registered"
                lines.append(f"  [{status}] settings.json [{event}] -> {hf}")
                if not found:
                    issues += 1
        except Exception:
            lines.append("  [error] settings.json -- invalid JSON")
            issues += 1
    else:
        lines.append("  [warn] settings.json -- not found")
        issues += 1

    lines.append("")
    if issues == 0:
        lines.append("  All checks passed!")
    else:
        lines.append(f"  {issues} issue(s) found. Run `cc-cortex init` to fix.")

    return "\n".join(lines)


# ── MCP Protocol Handler ─────────────────────────────────


RESOURCE_HANDLERS = {
    "cc-cortex://session/status": read_session_status,
    "cc-cortex://metrics/quality": read_quality_metrics,
    "cc-cortex://metrics/tokens": read_token_usage,
    "cc-cortex://knowledge/stats": read_knowledge_stats,
}

TOOL_HANDLERS = {
    "cc-cortex-status": handle_status,
    "cc-cortex-doctor": handle_doctor,
}


def make_response(id: Any, result: Any) -> dict:
    """Create a JSON-RPC 2.0 response."""
    return {"jsonrpc": "2.0", "id": id, "result": result}


def make_error(id: Any, code: int, message: str, data: Any = None) -> dict:
    """Create a JSON-RPC 2.0 error response."""
    error = {"code": code, "message": message}
    if data is not None:
        error["data"] = data
    return {"jsonrpc": "2.0", "id": id, "error": error}


# JSON-RPC error codes
PARSE_ERROR = -32700
INVALID_REQUEST = -32600
METHOD_NOT_FOUND = -32601
INVALID_PARAMS = -32602
INTERNAL_ERROR = -32603


def _handle_initialize(req_id: Any, _params: dict) -> dict:
    """Handle MCP initialize request."""
    return make_response(
        req_id,
        {
            "protocolVersion": MCP_PROTOCOL_VERSION,
            "capabilities": {
                "resources": {"listChanged": False},
                "tools": {"listChanged": False},
            },
            "serverInfo": {
                "name": SERVER_NAME,
                "version": SERVER_VERSION,
            },
        },
    )


def _handle_resources_list(req_id: Any, _params: dict) -> dict:
    """Handle resources/list request."""
    mcp = _cfg().raw("mcp", {})
    _default_res = [
        "session/status", "metrics/quality",
        "metrics/tokens", "knowledge/stats",
    ]
    enabled = mcp.get("resources", _default_res)
    filtered = [r for r in RESOURCES if any(e in r["uri"] for e in enabled)]
    return make_response(req_id, {"resources": filtered})


def _handle_resources_read(req_id: Any, params: dict) -> dict:
    """Handle resources/read request."""
    uri = params.get("uri", "")
    handler = RESOURCE_HANDLERS.get(uri)
    if not handler:
        return make_error(req_id, INVALID_PARAMS, f"Unknown resource: {uri}")
    try:
        data = handler()
        return make_response(
            req_id,
            {
                "contents": [
                    {
                        "uri": uri,
                        "mimeType": "application/json",
                        "text": json.dumps(data, indent=2, ensure_ascii=False),
                    }
                ],
            },
        )
    except Exception as exc:
        return make_error(req_id, INTERNAL_ERROR, str(exc))


def _handle_tools_list(req_id: Any, _params: dict) -> dict:
    """Handle tools/list request."""
    mcp = _cfg().raw("mcp", {})
    enabled = mcp.get("tools", ["cc-cortex-status", "cc-cortex-doctor"])
    filtered = [t for t in TOOLS if t["name"] in enabled]
    return make_response(req_id, {"tools": filtered})


def _handle_tools_call(req_id: Any, params: dict) -> dict:
    """Handle tools/call request."""
    tool_name = params.get("name", "")
    handler = TOOL_HANDLERS.get(tool_name)
    if not handler:
        return make_error(req_id, INVALID_PARAMS, f"Unknown tool: {tool_name}")
    try:
        result = handler()
        return make_response(
            req_id,
            {
                "content": [
                    {
                        "type": "text",
                        "text": result if isinstance(result, str) else json.dumps(result),
                    }
                ],
            },
        )
    except Exception as exc:
        return make_error(req_id, INTERNAL_ERROR, str(exc))


def _handle_ping(req_id: Any, _params: dict) -> dict:
    """Handle ping request."""
    return make_response(req_id, {})


# Method dispatch table
_METHOD_HANDLERS: dict[str, Any] = {
    "initialize": _handle_initialize,
    "resources/list": _handle_resources_list,
    "resources/read": _handle_resources_read,
    "tools/list": _handle_tools_list,
    "tools/call": _handle_tools_call,
    "ping": _handle_ping,
}

# Methods that are notifications (no response needed even without id)
_NOTIFICATION_METHODS = frozenset({"notifications/initialized"})


def handle_request(request: dict) -> Optional[dict]:
    """Handle a single JSON-RPC request. Returns response dict or None for notifications."""
    if not isinstance(request, dict):
        return make_error(None, INVALID_REQUEST, "Invalid request")

    req_id = request.get("id")
    method = request.get("method", "")
    params = request.get("params", {})

    # Known notifications -- no response
    if method in _NOTIFICATION_METHODS:
        return None

    # Unknown methods without an id are notifications -- ignore
    if req_id is None and method not in _METHOD_HANDLERS:
        return None

    handler = _METHOD_HANDLERS.get(method)
    if not handler:
        return make_error(req_id, METHOD_NOT_FOUND, f"Unknown method: {method}")

    return handler(req_id, params)


# ── Stdio Transport ──────────────────────────────────────


def run_stdio_server() -> None:
    """Run MCP server over stdio transport (line-delimited JSON-RPC)."""
    # Ensure binary mode for stdin/stdout on Windows
    if sys.platform == "win32":
        import msvcrt

        msvcrt.setmode(sys.stdin.fileno(), os.O_BINARY)
        msvcrt.setmode(sys.stdout.fileno(), os.O_BINARY)

    input_stream = sys.stdin.buffer
    output_stream = sys.stdout.buffer

    while True:
        try:
            line = input_stream.readline()
            if not line:
                break  # EOF

            line = line.strip()
            if not line:
                continue

            try:
                request = json.loads(line.decode("utf-8"))
            except (json.JSONDecodeError, UnicodeDecodeError) as exc:
                error_resp = make_error(None, PARSE_ERROR, f"Parse error: {exc}")
                _write_response(output_stream, error_resp)
                continue

            response = handle_request(request)
            if response is not None:
                _write_response(output_stream, response)

        except KeyboardInterrupt:
            break
        except Exception:
            # Don't crash the server on unexpected errors
            continue


def _write_response(stream: Any, response: dict) -> None:
    """Write a JSON-RPC response to the output stream."""
    data = json.dumps(response, ensure_ascii=False).encode("utf-8")
    stream.write(data + b"\n")
    stream.flush()


# ── Entry Point ───────────────────────────────────────────


def main() -> None:
    """CLI entry point for MCP server."""
    run_stdio_server()


if __name__ == "__main__":
    main()
