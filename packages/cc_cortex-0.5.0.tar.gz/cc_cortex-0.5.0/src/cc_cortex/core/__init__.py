"""
cc_cortex.core — Central configuration, atomic I/O, session management, notifications.

This is the foundation module that all other modules depend on.
Extracted from: cc_config.py, on-session-start.py, on-stop.py, pre-compact-save-state.py
"""

from .atomic import acquire_file_lock, read_json, release_file_lock, write_atomic
from .compact import extract_recent_user_messages, save_compact_state
from .config import Config, get_config
from .notify import play_sound, show_toast
from .session import cleanup_session_marker, generate_session_id, save_session_marker

__all__ = [
    "Config",
    "get_config",
    "write_atomic",
    "read_json",
    "acquire_file_lock",
    "release_file_lock",
    "generate_session_id",
    "save_session_marker",
    "cleanup_session_marker",
    "play_sound",
    "show_toast",
    "save_compact_state",
    "extract_recent_user_messages",
]
