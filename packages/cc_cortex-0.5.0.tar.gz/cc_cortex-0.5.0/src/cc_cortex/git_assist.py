#!/usr/bin/env python3
"""cc-cortex Git Assist — detect uncommitted changes.

Called by on-stop hook to remind about unsaved work.
Zero noise: only emits when there are uncommitted changes.
i18n: respects user locale from cc_config.json.
"""

from __future__ import annotations

import os
import subprocess
import sys
from typing import Optional

_CREATE_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0

_GIT_STRINGS = {
    "en": {
        "uncommitted": "uncommitted changes",
        "staged": "Staged",
        "modified": "Modified",
        "untracked": "Untracked",
        "more": "more",
    },
    "zh-TW": {
        "uncommitted": "未提交變更",
        "staged": "已暫存",
        "modified": "已修改",
        "untracked": "未追蹤",
        "more": "更多",
    },
    "zh-CN": {
        "uncommitted": "未提交变更",
        "staged": "已暂存",
        "modified": "已修改",
        "untracked": "未跟踪",
        "more": "更多",
    },
    "ja": {
        "uncommitted": "未コミット変更",
        "staged": "ステージ済",
        "modified": "変更済",
        "untracked": "未追跡",
        "more": "件",
    },
    "ko": {
        "uncommitted": "미커밋 변경",
        "staged": "스테이지",
        "modified": "수정됨",
        "untracked": "미추적",
        "more": "더",
    },
}


def _gt(key: str, locale: str = "en") -> str:
    strings = _GIT_STRINGS.get(locale, _GIT_STRINGS["en"])
    return strings.get(key, _GIT_STRINGS["en"].get(key, key))


def _hidden_startupinfo():
    if sys.platform != "win32":
        return None
    si = subprocess.STARTUPINFO()
    si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    si.wShowWindow = 0
    return si


def _git(args: list[str], cwd: str, timeout: int = 10) -> Optional[str]:
    """Run a git command and return stdout, or None on failure."""
    try:
        result = subprocess.run(
            ["git"] + args,
            cwd=cwd,
            capture_output=True,
            timeout=timeout,
            encoding="utf-8",
            errors="replace",
            creationflags=_CREATE_NO_WINDOW,
            startupinfo=_hidden_startupinfo(),
        )
        if result.returncode == 0:
            return result.stdout.strip()
        return None
    except Exception:
        return None


def generate_report(
    cwd: str | None = None,
    locale: str = "en",
) -> Optional[str]:
    """Generate a git status report for uncommitted changes.

    Args:
        cwd: Working directory (defaults to CLAUDE_PROJECT_DIR or cwd).
        locale: Locale for i18n strings.

    Returns:
        Report string, or None if repo is clean / not a git repo.
    """
    if cwd is None:
        cwd = os.environ.get("CLAUDE_PROJECT_DIR", os.getcwd())

    if _git(["rev-parse", "--is-inside-work-tree"], cwd) != "true":
        return None

    status = _git(["status", "--short"], cwd)
    if not status:
        return None

    lines = status.splitlines()
    if not lines:
        return None

    staged = []
    unstaged = []
    untracked = []

    for line in lines:
        if len(line) < 3:
            continue
        x, y = line[0], line[1]
        fname = line[3:].strip()
        if x == "?":
            untracked.append(fname)
        elif x != " ":
            staged.append(fname)
        if y != " " and y != "?":
            unstaged.append(fname)

    m = _gt("more", locale)

    parts = []
    if staged:
        names = ", ".join(staged[:5])
        extra = f" +{len(staged) - 5} {m}" if len(staged) > 5 else ""
        parts.append(f"🟡 {_gt('staged', locale)} ({len(staged)}): {names}{extra}")
    if unstaged:
        names = ", ".join(unstaged[:5])
        extra = f" +{len(unstaged) - 5} {m}" if len(unstaged) > 5 else ""
        parts.append(f"📝 {_gt('modified', locale)} ({len(unstaged)}): {names}{extra}")
    if untracked:
        names = ", ".join(untracked[:3])
        extra = f" +{len(untracked) - 3} {m}" if len(untracked) > 3 else ""
        parts.append(f"❓ {_gt('untracked', locale)} ({len(untracked)}): {names}{extra}")

    total = len(staged) + len(unstaged) + len(untracked)
    branch = _git(["branch", "--show-current"], cwd) or "unknown"

    header = f"🔀 Git: {total} {_gt('uncommitted', locale)} ({branch})"
    return header + "\n" + "\n".join(parts)
