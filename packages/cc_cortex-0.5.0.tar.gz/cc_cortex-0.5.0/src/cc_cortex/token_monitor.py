"""Token Monitor — Real token usage tracking from Claude Code transcripts.

Reads actual API usage data from transcript JSONL files instead of
estimating from file size (which is wildly inaccurate due to base64 images).

Primary: Parse the last API response's `usage` field (<1ms).
Fallback: File size estimation with base64 correction.
"""

from __future__ import annotations

import json
import os
import re
from typing import Optional

# ─── Constants ────────────────────────────────────────────

DEFAULT_BYTES_PER_TOKEN = 5
DEFAULT_SYSTEM_PROMPT_EST = 8000


# ─── Real Token Usage ────────────────────────────────────


def read_real_token_usage(filepath: str) -> Optional[dict]:
    """Read real token usage from the last API response in transcript JSONL.

    Each API response includes a 'usage' field with exact token counts.
    Only reads the last 20KB of the file (< 1ms).

    Returns dict with context_tokens (window occupancy) and cost_tokens
    (weighted by pricing: cache_read 10%, cache_create 125%), or None.
    """
    try:
        file_size = os.path.getsize(filepath)
        with open(filepath, "rb") as f:
            f.seek(max(0, file_size - 20000))
            tail = f.read().decode("utf-8", errors="replace")
        for line in reversed(tail.strip().split("\n")):
            try:
                d = json.loads(line)
                u = d.get("message", {}).get("usage")
                if u and "input_tokens" in u:
                    inp = u.get("input_tokens", 0)
                    cache_read = u.get("cache_read_input_tokens", 0)
                    cache_create = u.get("cache_creation_input_tokens", 0)
                    out = u.get("output_tokens", 0)
                    # Context window = all input tokens (cache or not)
                    context = inp + cache_read + cache_create
                    # Cost-weighted (cache_read is 90% cheaper)
                    cost = inp + int(cache_read * 0.1) + int(cache_create * 1.25) + out
                    return {
                        "context_tokens": context,
                        "cost_tokens": cost,
                        "output_tokens": out,
                        "cache_read_tokens": cache_read,
                    }
            except (json.JSONDecodeError, AttributeError):
                continue
    except Exception:
        pass
    return None


# ─── Base64 Size Estimation (Fallback) ───────────────────


def estimate_base64_bytes(filepath: str) -> tuple[int, int]:
    """Estimate base64-encoded binary data in transcript.

    Images stored as base64 inflate file size massively
    (3 images can be 93% of a 5MB file) but only ~1K tokens
    each in Claude's vision. Uses regex to find long base64
    runs (>10KB). Regex is C-level fast: ~5ms for 5MB.

    Returns (total_bytes, block_count).
    """
    try:
        with open(filepath, "rb") as f:
            data = f.read()
        matches = re.findall(rb"[A-Za-z0-9+/=]{10000,}", data)
        total = sum(len(m) for m in matches)
        return total, len(matches)
    except Exception:
        return 0, 0


# ─── Token Estimation ────────────────────────────────────


def estimate_tokens(
    filepath: str,
    bytes_per_token: int = DEFAULT_BYTES_PER_TOKEN,
    system_prompt_est: int = DEFAULT_SYSTEM_PROMPT_EST,
) -> Optional[int]:
    """Get token count: real usage first, fallback to file size estimation.

    Args:
        filepath: Path to transcript JSONL file.
        bytes_per_token: Bytes-per-token ratio for fallback estimation.
        system_prompt_est: Estimated system prompt tokens for fallback.

    Returns:
        Estimated total tokens, or None if file not found.
    """
    if not os.path.isfile(filepath):
        return None

    # Primary: real token count from API usage field
    real = read_real_token_usage(filepath)
    if real is not None:
        return real["context_tokens"]

    # Fallback: file size estimation with base64 correction
    try:
        file_size = os.path.getsize(filepath)
    except OSError:
        return None

    b64_bytes, b64_count = estimate_base64_bytes(filepath)
    adjusted_size = max(0, file_size - b64_bytes)
    return (adjusted_size // bytes_per_token) + system_prompt_est + (b64_count * 1000)


# ─── Threshold Check ─────────────────────────────────────


def check_threshold(
    filepath: str,
    thresholds: list[tuple],
    *,
    state_dir: Optional[str] = None,
    session_id: str = "",
    bytes_per_token: int = DEFAULT_BYTES_PER_TOKEN,
    system_prompt_est: int = DEFAULT_SYSTEM_PROMPT_EST,
) -> Optional[dict]:
    """Check token usage against warning thresholds.

    Args:
        filepath: Path to transcript JSONL file.
        thresholds: List of (threshold, icon, message, repeat?) tuples,
                    sorted descending by threshold.
        state_dir: Directory for persisting warned-level state.
        session_id: Current session ID for state tracking.
        bytes_per_token: Fallback estimation ratio.
        system_prompt_est: Fallback system prompt estimate.

    Returns:
        Dict with {threshold, icon, message, est_tokens, est_k} or None.
    """
    # Only use real API usage for threshold checks (file size estimation is unreliable
    # due to TypeScript compilation output, base64 images, etc.)
    real = read_real_token_usage(filepath)
    est_tokens = real["context_tokens"] if real else None
    if est_tokens is None:
        return None

    # Find highest crossed threshold
    crossed = None
    for entry in thresholds:
        t = entry[0]
        if est_tokens >= t:
            crossed = entry
            break

    if not crossed:
        return None

    threshold = crossed[0]
    icon = crossed[1]
    action = crossed[2]
    repeat = crossed[3] if len(crossed) > 3 else False
    est_k = est_tokens // 1000

    # Deduplicate: only warn once per level per session
    if state_dir and session_id and not repeat:
        short_id = session_id[:8]
        state_file = os.path.join(state_dir, f"{short_id}.json")
        try:
            os.makedirs(state_dir, exist_ok=True)
            if os.path.isfile(state_file):
                with open(state_file, "r", encoding="utf-8") as f:
                    state = json.load(f)
                if state.get("last_warned", 0) >= threshold:
                    return None
        except Exception:
            pass

    # Save warned level
    if state_dir and session_id:
        short_id = session_id[:8]
        state_file = os.path.join(state_dir, f"{short_id}.json")
        try:
            os.makedirs(state_dir, exist_ok=True)
            with open(state_file, "w", encoding="utf-8") as f:
                json.dump({"last_warned": threshold, "est_tokens": est_tokens}, f)
        except Exception:
            pass

    # Get cost-weighted tokens if available
    real = read_real_token_usage(filepath)
    cost_k = real["cost_tokens"] // 1000 if real else est_k

    return {
        "threshold": threshold,
        "icon": icon,
        "message": action,
        "est_tokens": est_tokens,
        "est_k": est_k,
        "cost_k": cost_k,
    }
