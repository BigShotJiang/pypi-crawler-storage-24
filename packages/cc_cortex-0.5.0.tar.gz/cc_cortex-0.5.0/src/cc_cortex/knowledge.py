"""
cc_cortex.knowledge — Automatic learning extraction from transcripts.

Scans Claude Code transcripts for user corrections, extracts learning pairs,
deduplicates against existing learnings, and tracks recurrence counts.

Extracted from: extract-learnings.py
"""

import hashlib
import json
import os
import re
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

# ── Correction Detection Patterns ──────────────────────────
# Level 1: Explicit negation/correction keywords (high confidence)
CN_PATTERNS_L1 = [
    r"不對",
    r"不是這樣",
    r"錯了",
    r"改成",
    r"應該是",
    r"換成",
    r"不要用",
    r"別用",
    r"那個不行",
    r"搞錯了",
    r"弄錯了",
    r"不要這樣",
    r"重新來",
    r"你搞錯",
    r"糾正",
]

# Level 2: Implicit correction — directive/override patterns (medium confidence)
CN_PATTERNS_L2 = [
    r"把.{1,20}改",
    r"把.{1,20}換",
    r"把.{1,20}刪",  # 把X改成Y
    r"先.{1,30}再",
    r"先做",  # 先做A再做B (reordering)
    r"不是.{1,20}是",  # 不是X是Y
    r"這裡要",
    r"那裡要",
    r"這邊要",  # 這裡要改
    r"幹嘛",
    r"為什麼要",  # 質疑 AI 行為
    r"多此一舉",
    r"太複雜",
    r"太多了",
    r"太少了",  # 評價
    r"少了",
    r"漏了",
    r"忘了",
    r"沒有做",  # 遺漏
    r"不需要",
    r"不用",
    r"拿掉",
    r"移除",  # 否定/移除
    r"加上",
    r"補上",
    r"加一個",
    r"還要",  # 要求補充
    r"反過來",
    r"順序.{0,5}反",
    r"倒過來",  # 順序錯誤
    r"剛才.{0,20}壞",
    r"剛才.{0,20}掛",  # 改壞了
    r"怎麼又",
    r"又.{1,10}了",
    r"還是.{1,10}問題",  # 重複問題
    r"沉澱",
    r"記住",
    r"以後.{0,10}不要",  # 要求學習
]

EN_PATTERNS_L1 = [
    r"\bwrong\b",
    r"\bno[,.\s]",
    r"\bactually[,.\s]",
    r"\binstead\b",
    r"\bnot that\b",
    r"\bshould be\b",
    r"\bdon'?t use\b",
    r"\bshouldn'?t\b",
    r"\bfix (this|that)\b",
    r"\bnot right\b",
    r"\bincorrect\b",
    r"\bthat'?s not\b",
    r"\bplease change\b",
]

EN_PATTERNS_L2 = [
    r"\bchange .{1,30} to\b",  # change X to Y
    r"\breplace .{1,30} with\b",  # replace X with Y
    r"\bremove\b",
    r"\bdelete\b",
    r"\bget rid of\b",  # removal
    r"\badd\b .{1,20}",
    r"\binclude\b",  # addition
    r"\bmissing\b",
    r"\bforgot\b",
    r"\bleft out\b",  # omission
    r"\bwhy (did|are|is)\b",
    r"\bwhat happened\b",  # questioning AI
    r"\btoo (much|many|complex|simple)\b",  # evaluation
    r"\bstill (broken|failing|wrong)\b",  # recurring issue
    r"\bbroke\b",
    r"\bbreaking\b",
    r"\bregression\b",  # broke something
    r"\bnot what I\b",
    r"\bthat'?s not what\b",  # mismatch
    r"\bdo .{1,20} first\b",
    r"\bbefore that\b",  # reordering
    r"\bremember\b",
    r"\bnext time\b",
    r"\balways\b",  # learning request
    r"\bnever\b .{1,20}",  # prohibition
    r"\bundo\b",
    r"\brevert\b",
    r"\broll\s*back\b",  # undo
    r"\bother way\b",
    r"\bopposite\b",
    r"\breverse\b",  # direction change
]

JA_PATTERNS = [
    r"違う",
    r"間違",
    r"ダメ",
    r"やめて",
    r"変えて",
    r"修正して",
    r"そうじゃない",
    r"それじゃない",
    r"直して",
    r"使わないで",
]

KO_PATTERNS = [
    r"아니",
    r"틀렸",
    r"잘못",
    r"고쳐",
    r"바꿔",
    r"그거\s*아니",
    r"안\s*돼",
    r"수정해",
    r"사용하지\s*마",
    r"쓰지\s*마",
]

ES_PATTERNS = [
    r"\bno\s+es\b",
    r"\bestá\s+mal\b",
    r"\bincorrecto\b",
    r"\bcambia\b",
    r"\bno\s+uses\b",
    r"\bestá\s+equivocado\b",
    r"\bcorrige\b",
    r"\bno\s+así\b",
    r"\bmal\s+hecho\b",
    r"\barregla\b",
]

# L1 = high confidence (original patterns)
_L1_PATTERNS = CN_PATTERNS_L1 + EN_PATTERNS_L1 + JA_PATTERNS + KO_PATTERNS + ES_PATTERNS
# L2 = medium confidence (implicit corrections)
_L2_PATTERNS = CN_PATTERNS_L2 + EN_PATTERNS_L2

COMPILED_L1 = [re.compile(p, re.IGNORECASE) for p in _L1_PATTERNS]
COMPILED_L2 = [re.compile(p, re.IGNORECASE) for p in _L2_PATTERNS]
# Combined for backward compat
COMPILED_PATTERNS = COMPILED_L1 + COMPILED_L2

# Max text length for correction detection (raised from 300 to 500)
MAX_CORRECTION_LEN = 500

SKIP_PREFIXES = (
    "<ide_",
    "<system",
    "<project_handoff",
    "<command",
    "<context",
    "交接",
    "進化",
    "清理",
    "能力對照",
)


def is_correction(text: str, return_confidence: bool = False) -> bool | tuple[bool, float]:
    """Check if text matches correction patterns.

    Short messages (4-500 chars) are more likely corrections;
    long messages are new tasks.

    Args:
        text: The user message to check.
        return_confidence: If True, return (bool, confidence) tuple.

    Returns:
        bool or (bool, confidence) where confidence is 0.0-1.0.
    """
    if len(text) > MAX_CORRECTION_LEN or len(text) < 4:
        return (False, 0.0) if return_confidence else False

    # L1: explicit correction keywords → high confidence
    if any(p.search(text) for p in COMPILED_L1):
        return (True, 1.0) if return_confidence else True

    # L2: implicit correction patterns → medium confidence
    if any(p.search(text) for p in COMPILED_L2):
        return (True, 0.6) if return_confidence else True

    return (False, 0.0) if return_confidence else False


def extract_corrections(
    transcript_path: str,
    tz: Any = None,
    max_corrections: int = 10,
    max_file_size: int = 10 * 1024 * 1024,
) -> list[dict]:
    """Read transcript JSONL, find user corrections with preceding context.

    Args:
        transcript_path: Path to the transcript JSONL file.
        tz: Timezone for timestamps.
        max_corrections: Max corrections to extract per session.
        max_file_size: Skip transcripts larger than this (bytes).

    Returns:
        List of correction dicts with assistant_before, user_correction, timestamp.
    """
    path = os.path.expanduser(transcript_path)
    if not os.path.isfile(path):
        return []
    try:
        if os.path.getsize(path) > max_file_size:
            return []
    except OSError:
        return []

    corrections = []
    prev_assistant_text = ""

    try:
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                except json.JSONDecodeError:
                    continue

                msg_type = entry.get("type", "")
                message = entry.get("message", {})
                if not isinstance(message, dict):
                    continue

                content = message.get("content", "")
                text = _extract_text(content)
                if not text:
                    continue
                if any(text.startswith(p) for p in SKIP_PREFIXES):
                    continue

                if msg_type == "assistant":
                    prev_assistant_text = text[-500:]
                elif msg_type == "user":
                    if prev_assistant_text:
                        matched, confidence = is_correction(text, return_confidence=True)
                        if matched:
                            corrections.append(
                                {
                                    "assistant_before": prev_assistant_text[:300],
                                    "user_correction": text[:500],
                                    "confidence": confidence,
                                    "timestamp": (
                                        datetime.now(tz).isoformat()
                                        if tz
                                        else datetime.now().isoformat()
                                    ),
                                }
                            )
                            if len(corrections) >= max_corrections:
                                break
    except Exception:
        pass

    return corrections


def log_corrections(corrections: list[dict], session_id: str, log_path: str) -> None:
    """Append raw corrections to a JSONL queue file (audit trail)."""
    try:
        os.makedirs(os.path.dirname(log_path), exist_ok=True)
        with open(log_path, "a", encoding="utf-8") as f:
            for c in corrections:
                c["session_id"] = session_id[:8]
                f.write(json.dumps(c, ensure_ascii=False) + "\n")
    except Exception:
        pass


def update_learnings(
    corrections: list[dict],
    learnings_path: str,
    max_stored: int = 50,
) -> None:
    """Update learnings.json with new corrections. Dedup + increment count.

    Args:
        corrections: List of correction dicts from extract_corrections.
        learnings_path: Path to learnings.json.
        max_stored: Maximum learnings to keep.
    """
    learnings = _read_learnings(learnings_path)
    existing = learnings.get("learnings", [])

    for c in corrections:
        key_text = c["user_correction"][:100]
        match = _find_similar(existing, key_text)

        if match:
            match["count"] += 1
            match["last_seen"] = c["timestamp"]
            if len(c.get("assistant_before", "")) > len(match.get("context", "")):
                match["context"] = c["assistant_before"][:300]
        else:
            existing.append(
                {
                    "id": hashlib.sha256(key_text.encode()).hexdigest()[:8],
                    "correction_text": c["user_correction"][:200],
                    "context": c.get("assistant_before", "")[:200],
                    "count": 1,
                    "confidence": c.get("confidence", 1.0),
                    "first_seen": c["timestamp"],
                    "last_seen": c["timestamp"],
                    "promoted": False,
                }
            )

    existing.sort(key=lambda x: x.get("last_seen", ""), reverse=True)
    learnings["learnings"] = existing[:max_stored]
    learnings["last_updated"] = corrections[-1]["timestamp"] if corrections else ""

    _write_learnings(learnings, learnings_path)


def check_staleness(
    learnings_path: str,
    stale_days: int = 90,
    now: Optional[datetime] = None,
) -> list[dict]:
    """Find learnings not seen in >stale_days and mark them stale.

    Args:
        learnings_path: Path to learnings.json.
        stale_days: Days since last_seen to consider stale.
        now: Override current time (for testing).

    Returns:
        List of learnings newly marked as stale.
    """
    data = _read_learnings(learnings_path)
    items = data.get("learnings", [])
    if not items:
        return []

    ref = now or datetime.now(timezone.utc)
    cutoff = ref - timedelta(days=stale_days)
    newly_stale: list[dict] = []

    for item in items:
        if item.get("stale"):
            continue
        last_seen = item.get("last_seen", "")
        if not last_seen:
            continue
        try:
            ts = datetime.fromisoformat(last_seen)
            if ts.tzinfo is None:
                ts = ts.replace(tzinfo=timezone.utc)
            if ts < cutoff:
                item["stale"] = True
                newly_stale.append(item)
        except (ValueError, TypeError):
            continue

    if newly_stale:
        _write_learnings(data, learnings_path)

    return newly_stale


def check_conflicts(learnings_path: str, similarity_chars: int = 30) -> list[tuple[dict, dict]]:
    """Detect contradictory learnings (similar context, different corrections).

    Two learnings conflict when their context prefixes match but their
    correction texts differ — indicating the user gave opposite guidance
    on similar situations.

    Args:
        learnings_path: Path to learnings.json.
        similarity_chars: Number of leading chars to compare for context match.

    Returns:
        List of (learning_a, learning_b) conflict pairs.
    """
    data = _read_learnings(learnings_path)
    items = data.get("learnings", [])
    if len(items) < 2:
        return []

    conflicts: list[tuple[dict, dict]] = []
    for i, a in enumerate(items):
        ctx_a = a.get("context", "")[:similarity_chars].lower().strip()
        corr_a = a.get("correction_text", "")[:similarity_chars].lower().strip()
        if not ctx_a:
            continue
        for b in items[i + 1 :]:
            ctx_b = b.get("context", "")[:similarity_chars].lower().strip()
            corr_b = b.get("correction_text", "")[:similarity_chars].lower().strip()
            if not ctx_b:
                continue
            # Same context prefix but different correction prefix = conflict
            if ctx_a == ctx_b and corr_a != corr_b:
                conflicts.append((a, b))

    return conflicts


def get_pending_promotions(learnings_path: str, threshold: int = 3) -> list[dict]:
    """Get learnings with count >= threshold that haven't been promoted yet.

    Args:
        learnings_path: Path to learnings.json.
        threshold: Minimum count to consider for promotion.

    Returns:
        List of learning dicts ready for promotion.
    """
    data = _read_learnings(learnings_path)
    items = data.get("learnings", [])
    if not isinstance(items, list):
        return []
    return [
        item
        for item in items
        if isinstance(item, dict)
        and item.get("count", 0) >= threshold
        and not item.get("promoted", False)
    ]


def suggest_rule_promotions(
    learnings_path: str,
    threshold: int = 3,
) -> list[dict]:
    """Generate concrete rule suggestions from high-frequency learnings.

    Each suggestion includes the learning text, a proposed rule snippet,
    and the target rules directory. Users review and approve before writing.

    Args:
        learnings_path: Path to learnings.json.
        threshold: Minimum recurrence count to suggest.

    Returns:
        List of suggestion dicts with keys:
        - learning_id, correction_text, count, confidence
        - suggested_rule: one-line rule text derived from correction
        - target_file: proposed .md filename slug
    """
    pending = get_pending_promotions(learnings_path, threshold)
    if not pending:
        return []

    suggestions: list[dict] = []
    for item in pending:
        correction = item.get("correction_text", "").strip()
        if not correction:
            continue

        # Derive a rule slug from first 40 chars
        slug = _slugify(correction[:40])
        if not slug:
            slug = item.get("id", "rule")

        suggestions.append(
            {
                "learning_id": item.get("id", ""),
                "correction_text": correction,
                "count": item.get("count", 0),
                "confidence": item.get("confidence", 0.0),
                "context": item.get("context", "")[:150],
                "suggested_rule": correction[:200],
                "target_file": f"learned-{slug}.md",
            }
        )

    # Sort by count descending (most recurring = most important)
    suggestions.sort(key=lambda x: x["count"], reverse=True)
    return suggestions


def mark_promoted(learnings_path: str, learning_id: str) -> bool:
    """Mark a learning as promoted (rule created).

    Args:
        learnings_path: Path to learnings.json.
        learning_id: The learning ID to mark.

    Returns:
        True if found and marked.
    """
    data = _read_learnings(learnings_path)
    items = data.get("learnings", [])
    for item in items:
        if item.get("id") == learning_id:
            item["promoted"] = True
            item["promoted_at"] = datetime.now(timezone.utc).isoformat()
            _write_learnings(data, learnings_path)
            return True
    return False


def _slugify(text: str) -> str:
    """Convert text to a safe filename slug."""
    # Keep alphanumeric, CJK, hyphens
    slug = re.sub(r"[^\w\u4e00-\u9fff-]", "-", text.lower())
    slug = re.sub(r"-+", "-", slug).strip("-")
    return slug[:30]


# ── Internal helpers ──────────────────────────────────────


def _extract_text(content) -> str:
    """Extract plain text from content (str or list of content blocks)."""
    if isinstance(content, str):
        return content.strip()
    if isinstance(content, list):
        texts = []
        for p in content:
            if isinstance(p, dict) and p.get("type") == "text":
                t = p.get("text", "").strip()
                if t:
                    texts.append(t)
        return " ".join(texts).strip()
    return ""


def _read_learnings(path: str) -> dict:
    if os.path.isfile(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, dict) and "learnings" in data:
                    return data
        except Exception:
            pass
    return {"version": "1.0", "learnings": []}


def _write_learnings(learnings: dict, path: str) -> None:
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(learnings, f, indent=2, ensure_ascii=False)
        os.replace(tmp, path)
    except Exception:
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(learnings, f, indent=2, ensure_ascii=False)
        except Exception:
            pass


def _find_similar(existing: list, key_text: str) -> Optional[dict]:
    """Simple dedup: first 50 chars match = same learning."""
    key_prefix = key_text[:50].lower()
    for item in existing:
        if item.get("correction_text", "")[:50].lower() == key_prefix:
            return item
    return None


__all__ = [
    "is_correction",
    "extract_corrections",
    "log_corrections",
    "update_learnings",
    "get_pending_promotions",
    "suggest_rule_promotions",
    "mark_promoted",
    "check_staleness",
    "check_conflicts",
]
