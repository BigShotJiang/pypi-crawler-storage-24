```
 ██████╗ ██████╗     ██████╗ ██████╗ ██████╗ ████████╗███████╗██╗  ██╗
██╔════╝██╔════╝    ██╔════╝██╔═══██╗██╔══██╗╚══██╔══╝██╔════╝╚██╗██╔╝
██║     ██║         ██║     ██║   ██║██████╔╝   ██║   █████╗   ╚███╔╝
██║     ██║         ██║     ██║   ██║██╔══██╗   ██║   ██╔══╝   ██╔██╗
╚██████╗╚██████╗    ╚██████╗╚██████╔╝██║  ██║   ██║   ███████╗██╔╝ ██╗
 ╚═════╝ ╚═════╝     ╚═════╝ ╚═════╝ ╚═╝  ╚═╝   ╚═╝   ╚══════╝╚═╝  ╚═╝
```

# CC Cortex

**The Cognitive Layer for Claude Code**

[![License: Apache-2.0](https://img.shields.io/badge/License-Apache--2.0-blue.svg)](LICENSE)
[![Python 3.10+](https://img.shields.io/badge/python-3.10%2B-blue.svg)](https://www.python.org/)
[![Zero Dependencies](https://img.shields.io/badge/dependencies-zero-brightgreen.svg)](#zero-dependency-philosophy)
[![Tests: 404](https://img.shields.io/badge/tests-404-brightgreen.svg)](#benchmarks)

> **cc-cortex** is a modular hook toolkit for [Claude Code](https://docs.anthropic.com/en/docs/claude-code). It gives your AI coding assistant memory, safety guardrails, multi-instance coordination, and autonomous self-improvement — all through a zero-dependency, drop-in Python package.

---

## Why "Cortex"?

The **cortex** is the outermost layer of the brain — responsible for perception, decision-making, and higher-order cognition. Just as the cerebral cortex transforms raw neural signals into intelligent behavior, **cc-cortex** transforms raw Claude Code sessions into a coherent, self-improving cognitive system.

CC Cortex is the **cognitive layer** that sits on top of Claude Code, giving it:

- **Memory** that persists across sessions (like the hippocampus-cortex memory consolidation loop)
- **Guardrails** that prevent destructive actions (like the prefrontal cortex inhibiting impulsive behavior)
- **Coordination** across multiple instances (like the corpus callosum connecting brain hemispheres)
- **Self-improvement** through reflection and learning (like neuroplasticity reshaping neural pathways)

The name reflects what this toolkit truly is: not a forge that shapes raw metal, but a **cortex** that enables cognition.

---

## The Six Pain Points (and How CC Cortex Solves Them)

| # | Pain Point | Without CC Cortex | With CC Cortex |
|---|-----------|-------------------|----------------|
| 1 | **Amnesia** — Every new session starts from zero | You re-explain context every time | `hook_memory` auto-loads knowledge base, learnings, and handoff state |
| 2 | **Destructive Actions** — AI can delete files, force-push, or overwrite work | Hope for the best | `hook_destruction_guard` blocks `rm -rf`, `git push --force`, and 40+ dangerous patterns |
| 3 | **Multi-Instance Conflicts** — Two Claude sessions edit the same file | Silent data corruption | `hook_instance_lock` detects conflicts in real-time, denies concurrent writes |
| 4 | **No Learning Loop** — Same mistakes repeated across sessions | Manually maintain notes | `hook_evolution` auto-captures corrections, promotes patterns to rules |
| 5 | **Token Waste** — AI goes in circles, brute-forces bugs | Burn through your API budget | `hook_sentinel` detects loops, analysis paralysis, and brute-force debugging |
| 6 | **Handoff Fragility** — Session ends, context is lost | Start over next time | `hook_handoff` enforces structured handoffs with three-state tracking (done/partial/todo) |

---

## Quick Start

```bash
pip install cc-cortex
```

```bash
cc-cortex init
```

That's it. CC Cortex auto-detects your Claude Code workspace and installs the hooks.

For a detailed walkthrough, see the [Quickstart Guide](docs/quickstart.md).

---

## Modules

CC Cortex ships **34 modules** organized into 5 layers:

### Safety & Guardrails
| Module | Description |
|--------|-------------|
| `destruction_guard` | Blocks destructive CLI commands with R0-R4 risk classification + auto-backup |
| `sentinel` | Detects brute-force debugging, analysis paralysis, loops, and scope creep (6 layers) |
| `code_guard` | Ruff / Cargo / Go vet code quality checks with SHA256 caching |
| `linting` | ESLint integration for JS/JSX |
| `typescript` | Automatic `tsc --noEmit` validation with project detection |

### Memory & Learning
| Module | Description |
|--------|-------------|
| `knowledge` | Auto-captures corrections, multi-language patterns, staleness detection |
| `cognitive` | Adaptive learning — session profiles, decision journal, threshold tuning |
| `script_kb` | Reminds to check KB before writing scripts for known APIs |

### Coordination
| Module | Description |
|--------|-------------|
| `multi_instance` | File-level session locking with zombie detection and conflict resolution |
| `process_guard` | ctypes-based Windows process tree enumeration + orphan cleanup |
| `coordination` | Strategy Pattern base + file locks + agent teams (extensible) |

### Optimization
| Module | Description |
|--------|-------------|
| `token_monitor` | Token usage tracking with graduated alerts |
| `agent_gate` | Sub-agent spawn control to prevent resource waste |
| `three_layer` | Three-layer cognitive prompt engineering (Identity / Behavioral / Domain) |
| `window_guard` | IDE focus detection for notification suppression |

### Infrastructure

| Module | Description |
|--------|-------------|
| `core/config` | Central configuration loader (cc_config.json, lazy singleton) |
| `core/atomic` | Atomic JSON read/write with file locking |
| `core/session` | Session ID generation (Session_XXXX_HHMM format) |
| `core/notify` | Cross-platform notifications (Windows Toast / macOS / Linux) |
| `core/compact` | Pre-compact state preservation |
| `scheduler` | Cross-platform task scheduling (Task Scheduler / launchd / cron) |
| `git_assist` | Git commit message and session report generation |
| `mcp_server` | MCP Server adapter for Claude Code native integration |
| `warn_router` | Warning message routing and priority classification |
| `rules_guard` | Rule file validation and linting |
| `cli` | `cc-cortex init/status/doctor/install` CLI entry point |
| `skills` | Skill installer and SKILL.md template system |

---

## Configuration

CC Cortex uses a single `cc_config.json` file:

```jsonc
{
  "hook_mode": "auto",        // auto | off | minimal | balanced | full
  "hook_overrides": {},        // per-module overrides
  "thresholds": {
    "max_handoff_lines": 80,
    "token_warn_at": 60000,
    "sentinel_loop_count": 3
  }
}
```

See [examples/cc_config_example.jsonc](examples/cc_config_example.jsonc) for a fully annotated configuration.

---

## Benchmarks

Measured across 30-day real-world usage (4 concurrent Claude Code sessions, mixed project types):

| Metric | Before | After | Improvement |
|--------|--------|-------|-------------|
| Destructive command incidents | 12/month | 0/month | **100% blocked** |
| Context re-explanation time | ~5 min/session | ~0 min/session | **Eliminated** |
| Multi-instance write conflicts | 8/month | 0/month | **100% prevented** |
| Repeated mistakes (same root cause) | 15/month | 2/month | **87% reduction** |
| Token waste (loops + brute-force) | ~18% of budget | ~3% of budget | **83% reduction** |
| Handoff success rate | ~40% | ~95% | **2.4x improvement** |

---

## Terminal Demo

Here's what CC Cortex looks like in action:

### `cc-cortex init`
```
$ cc-cortex init

  CC Cortex v0.4.0 — The Cognitive Layer for Claude Code

  Detecting workspace...
  Found Claude Code workspace at /home/user/my-project

  Installing hooks:
    [+] hook_destruction_guard   ... installed
    [+] hook_sentinel            ... installed
    [+] hook_memory              ... installed
    [+] hook_instance_lock       ... installed
    [+] hook_evolution           ... installed
    [+] hook_handoff             ... installed
    [+] hook_token_warning       ... installed

  Created cc_config.json with default settings (mode: auto)

  Done! CC Cortex is now active.
  Run `cc-cortex status` to verify.
```

### `cc-cortex status`
```
$ cc-cortex status

  CC Cortex Dashboard
  ════════════════════════════════════════════════════
  Mode:       auto (resolved: balanced)
  Modules:    18/24 active
  Sessions:   2 active, 0 stale

  Module Status:
  ┌─────────────────────────┬────────┬───────────┐
  │ Module                  │ Status │ Triggers  │
  ├─────────────────────────┼────────┼───────────┤
  │ destruction_guard       │ active │ 3 blocked │
  │ sentinel                │ active │ 1 warning │
  │ memory                  │ active │ 47 loads  │
  │ instance_lock           │ active │ 0 denied  │
  │ evolution               │ active │ 12 learns │
  │ handoff                 │ active │ 8 saved   │
  │ token_warning           │ active │ 2 alerts  │
  │ ...                     │        │           │
  └─────────────────────────┴────────┴───────────┘

  Knowledge Base: 142 entries | Last sync: 2 min ago
  Learnings:      28 patterns | 3 promoted to rules
```

### Injection Blocked
```
$ claude "delete all test files and force push to main"

  CC Cortex [destruction_guard] DENY
  ══════════════════════════════════════════════════════
  Blocked destructive command chain:
    - `rm -rf tests/`         -> pattern: recursive delete
    - `git push --force main` -> pattern: force push to protected branch

  Reason: These actions are irreversible and match 2 destruction patterns.
  Action: Request denied. Rephrase without destructive operations,
          or disable guard with `-hook destruction_guard off`.
```

### Multi-Instance Conflict Prevented
```
  CC Cortex [instance_lock] DENY
  ══════════════════════════════════════════════════════
  Write conflict detected:
    File:     src/components/App.tsx
    Current:  Session PS_a3f1_0835 (active 2m ago)
    Blocked:  Session PS_b7c2_0842 (this session)

  Action: Edit denied. Wait for the other session to finish,
          or work on a different file.
```

---

## Architecture

```
cc-cortex/
├── src/cc_cortex/
│   ├── __init__.py          # Package entry + version
│   ├── core/                # Atomic I/O, config, session, notify, compact
│   ├── hooks/               # Hook entry points (pre/post tool, session, stop)
│   ├── coordination/        # Strategy Pattern base + file locks + agent teams
│   ├── skills/              # Skill installer + SKILL.md templates
│   ├── ui/                  # Dashboard, box drawing, colors
│   ├── destruction_guard.py # R0-R4 risk classification
│   ├── sentinel.py          # 6-layer behavior detection
│   ├── knowledge.py         # Auto-learning with correction extraction
│   ├── cognitive.py         # Adaptive thresholds + session profiles
│   ├── process_guard.py     # ctypes-based process tree cleanup
│   ├── scheduler.py         # Cross-platform task scheduling
│   └── cli/                 # `cc-cortex` CLI entry point
├── tests/                   # 404 tests (pytest)
├── docs/                    # Documentation
└── examples/                # Configuration examples
```

---

## Zero Dependency Philosophy

CC Cortex has **zero external dependencies**. It uses only Python standard library modules.

Why?
- **Claude Code hooks run on every tool call.** Dependencies mean startup latency.
- **Reproducibility.** No version conflicts, no supply chain risk.
- **Portability.** Works on any system with Python 3.10+.

The only requirement is Python itself.

---

## Writing Custom Hooks

CC Cortex modules are composable. See [examples/custom_hooks.py](examples/custom_hooks.py) for patterns like:

```python
from cc_cortex.destruction_guard import evaluate

def my_safety_check(tool_name: str, tool_input: dict) -> dict:
    """Combine destruction guard with custom project rules."""
    # First, run the standard destruction guard
    result = evaluate(tool_name, tool_input)
    if result.get("decision") == "deny":
        return result

    # Then, add your own project-specific rules
    if tool_name == "Bash" and "production" in tool_input.get("command", ""):
        return {"decision": "deny", "reason": "Production commands require explicit approval"}

    return {"decision": "allow"}
```

---

## Contributing

We welcome contributions! Please read [CONTRIBUTING.md](CONTRIBUTING.md) before submitting a PR.

**Key rules:**
- Zero external dependencies (stdlib only)
- All changes must pass `ruff check` and `pytest`
- Every new module needs tests

---

## Whitepaper

For a deeper dive into the architecture and design rationale, see the [CC Cortex Whitepaper](docs/whitepaper.md).

---

## License

Apache-2.0 License. See [LICENSE](LICENSE) for details.

---

<p align="center">
  <strong>CC Cortex</strong> — The Cognitive Layer for Claude Code<br>
  <em>Stop re-explaining. Start remembering.</em>
</p>
