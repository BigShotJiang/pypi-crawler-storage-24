# Copyright (C) 2025 Bloomberg LP
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#  <http://www.apache.org/licenses/LICENSE-2.0>
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Remove deleted column from SQL CAS index

Revision ID: 3737630fc9cf
Revises: ff09fbc30c3e
Create Date: 2026-01-27 14:49:47.715880

"""

import sqlalchemy as sa
from alembic import op


# revision identifiers, used by Alembic.
revision = "3737630fc9cf"
down_revision = "ff09fbc30c3e"
branch_labels = None
depends_on = None


def upgrade() -> None:
    with op.batch_alter_table("index", schema=None) as batch_op:
        batch_op.drop_column("deleted")


def downgrade() -> None:
    with op.batch_alter_table("index", schema=None) as batch_op:
        batch_op.add_column(
            sa.Column("deleted", sa.BOOLEAN(), server_default=sa.text("false"), autoincrement=False, nullable=False)
        )
