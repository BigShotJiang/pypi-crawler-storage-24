# Copyright (C) 2025 Bloomberg LP
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#  <http://www.apache.org/licenses/LICENSE-2.0>
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import functools
from dataclasses import dataclass


@dataclass(frozen=True)
class Cohort:
    name: str
    property_labels: frozenset[str]


class CohortSet:
    def __init__(self, cohorts: list[Cohort]):
        self.cohorts = cohorts
        self.cohort_map = {cohort.name: cohort for cohort in cohorts}

        # reverse lookup: label -> cohort
        self.label_map: dict[str, str] = {}
        for cohort in cohorts:
            for label in cohort.property_labels:
                if label in self.label_map:
                    raise ValueError(f"Label {label} is in multiple cohorts: {self.label_map[label]} and {cohort.name}")
                self.label_map[label] = cohort.name

    def get_labels_by_cohort(self, cohort: str) -> frozenset[str]:
        c = self.cohort_map.get(cohort)
        if c is None:
            return frozenset()
        return c.property_labels

    @functools.lru_cache(maxsize=32)
    def get_cohort_by_labels(self, labels: frozenset[str]) -> str | None:
        # A worker is in a cohort if all of its labels are in the cohort's property labels
        for cohort in self.cohorts:
            if labels <= cohort.property_labels:
                return cohort.name
        return None

    def get_cohorts_by_job_label(self, label: str) -> str | None:
        return self.label_map.get(label)
