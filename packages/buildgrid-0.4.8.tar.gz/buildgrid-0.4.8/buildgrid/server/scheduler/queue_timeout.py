from datetime import datetime, timedelta, timezone
import threading
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Generator, Self

from buildgrid.server.logging import buildgrid_logger

from buildgrid.server.metrics_names import METRIC
from buildgrid.server.metrics_utils import (
    publish_counter_metric,
    timer,
)

if TYPE_CHECKING:
    # Avoid circular import
    from .impl import Scheduler

from buildgrid.server.threading import ContextWorker

LOGGER = buildgrid_logger(__name__)


class QueueTimeoutThread:
    instance_names: frozenset[str] | None
    job_max_age: timedelta = timedelta(days=30)
    handling_period: timedelta = timedelta(minutes=5)
    max_handling_window: int = 10000

    def __init__(
        self,
        name: str,
        scheduler: "Scheduler",
        instance_names: frozenset[str] | None,
        job_max_age: timedelta,
        handling_period: timedelta,
        max_handling_window: int,
    ):
        self._scheduler = scheduler
        self.instance_names = instance_names
        self.job_max_age = job_max_age
        self.handling_period = handling_period
        self.max_handling_window = max_handling_window
        self._timeout_thread = ContextWorker(
            target=self.begin,
            name=name,
        )

    def __enter__(self) -> Self:
        self.start()
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        self.stop()

    def start(self) -> None:
        self._timeout_thread.start()

    def stop(self) -> None:
        self._timeout_thread.stop()

    def begin(self, shutdown_requested: threading.Event) -> None:
        while not shutdown_requested.is_set():
            last_timeout_time = datetime.now(timezone.utc)
            while not shutdown_requested.is_set():
                now = datetime.now(timezone.utc)
                if now - last_timeout_time < self.handling_period:
                    LOGGER.info(f"Job queue timeout thread sleeping for {self.handling_period} seconds")
                    shutdown_requested.wait(timeout=self.handling_period.total_seconds())
                    continue

                timeout_jobs_scheduled_before = now - self.job_max_age
                try:
                    with timer(METRIC.SCHEDULER.QUEUE_TIMEOUT_DURATION):
                        num_timeout = self._scheduler.timeout_queued_jobs_scheduled_before(
                            timeout_jobs_scheduled_before, self.max_handling_window
                        )
                    LOGGER.info(f"Timed-out {num_timeout} queued jobs scheduled before {timeout_jobs_scheduled_before}")
                    if num_timeout > 0:
                        publish_counter_metric(METRIC.SCHEDULER.QUEUE_TIMEOUT_COUNT, num_timeout)

                except Exception as e:
                    LOGGER.exception("Failed to timeout aged queued jobs.", exc_info=e)
                finally:
                    last_timeout_time = now


@dataclass
class QueueTimeoutConfig:
    name: str
    job_max_age: dict[str, float]
    handling_period: dict[str, float] | None = None
    max_handling_window: int | None = None
    instance_names: frozenset[str] | None = None

    def _dict_to_timedelta(self, config: dict[str, float]) -> timedelta:
        return timedelta(
            weeks=config.get("weeks", 0),
            days=config.get("days", 0),
            hours=config.get("hours", 0),
            minutes=config.get("minutes", 0),
            seconds=config.get("seconds", 0),
        )

    def generate_timeout_threads(self, scheduler: "Scheduler") -> Generator[QueueTimeoutThread, None, None]:
        yield QueueTimeoutThread(
            scheduler=scheduler,
            name=self.name,
            instance_names=self.instance_names,
            job_max_age=self._dict_to_timedelta(self.job_max_age),
            handling_period=(
                self._dict_to_timedelta(self.handling_period) if self.handling_period else timedelta(minutes=5)
            ),
            max_handling_window=self.max_handling_window if self.max_handling_window is not None else 10000,
        )
