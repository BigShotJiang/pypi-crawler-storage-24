"""Unit tests for Eye pupil radii methods."""

import numpy as np

from pyetsimul.core.eye import Eye
from pyetsimul.types import Position3D


def test_get_pupil_radii_default() -> None:
    """Test get_pupil_radii returns correct default radii."""
    e = Eye()
    x_radius, y_radius = e.get_pupil_radii()

    # Default pupil radius is 3mm for both axes
    expected_radius = 3
    assert np.isclose(x_radius, expected_radius, rtol=1e-12)
    assert np.isclose(y_radius, expected_radius, rtol=1e-12)


def test_set_get_pupil_radii() -> None:
    """Test set_pupil_radii and get_pupil_radii work together correctly."""
    e = Eye()

    # Test setting both radii
    e.set_pupil_radii(x_radius=3, y_radius=2)
    x_radius, y_radius = e.get_pupil_radii()
    assert np.isclose(x_radius, 3, rtol=1e-12)
    assert np.isclose(y_radius, 2, rtol=1e-12)

    # Test setting different radii
    e.set_pupil_radii(x_radius=4, y_radius=1)
    x_radius, y_radius = e.get_pupil_radii()
    assert np.isclose(x_radius, 4, rtol=1e-12)
    assert np.isclose(y_radius, 1, rtol=1e-12)


def test_set_pupil_diameter() -> None:
    """Test set_pupil_diameter method."""
    e = Eye()

    # Test setting diameter
    e.set_pupil_diameter(diameter=6)  # 6mm diameter = 3mm radius
    x_radius, y_radius = e.get_pupil_radii()
    assert np.isclose(x_radius, 3, rtol=1e-12)
    assert np.isclose(y_radius, 3, rtol=1e-12)


def test_set_pupil_radii_updates_vectors() -> None:
    """Test that set_pupil_radii correctly updates x_pupil and y_pupil vectors."""
    e = Eye()
    x_radius = 3  # 3mm
    y_radius = 2  # 2mm

    e.set_pupil_radii(x_radius=x_radius, y_radius=y_radius)

    # Check that vectors have correct magnitude
    x_magnitude = np.linalg.norm(np.array(e.pupil.x_pupil)[:3])
    y_magnitude = np.linalg.norm(np.array(e.pupil.y_pupil)[:3])

    assert np.isclose(x_magnitude, x_radius, rtol=1e-12)
    assert np.isclose(y_magnitude, y_radius, rtol=1e-12)

    # Check vector directions
    expected_x = np.array([x_radius, 0, 0, 0])
    expected_y = np.array([0, y_radius, 0, 0])

    e.pupil.x_pupil.assert_close(Position3D.from_array(expected_x), rtol=1e-12)
    e.pupil.y_pupil.assert_close(Position3D.from_array(expected_y), rtol=1e-12)
