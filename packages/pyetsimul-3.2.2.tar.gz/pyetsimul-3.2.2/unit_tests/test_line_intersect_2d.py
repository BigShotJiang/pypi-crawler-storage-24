"""Unit tests for line_intersect_2d function."""

import numpy as np

from pyetsimul.geometry.utils import line_intersect_2d
from pyetsimul.types import Point2D


def test_horizontal_vertical_lines() -> None:
    """Test intersection of horizontal and vertical lines with MATLAB reference values."""
    # Horizontal line: y = 0.5, points (0, 0.5) and (1, 0.5)
    p1 = Point2D(0.0, 0.5)
    p2 = Point2D(1.0, 0.5)

    # Vertical line: x = 0.3, points (0.3, 0) and (0.3, 1)
    p3 = Point2D(0.3, 0.0)
    p4 = Point2D(0.3, 1.0)

    intersection = line_intersect_2d(p1, p2, p3, p4)

    # MATLAB reference values
    expected_intersection = Point2D(0.3, 0.5)

    intersection.assert_close(expected_intersection, rtol=1e-14, atol=1e-15)


def test_non_integer_coordinates() -> None:
    """Test intersection with non-integer coordinates and MATLAB reference values."""
    # Line 1: from (0.1, 0.2) to (0.9, 0.8)
    p1 = Point2D(0.1, 0.2)
    p2 = Point2D(0.9, 0.8)

    # Line 2: from (0.2, 0.7) to (0.8, 0.3)
    p3 = Point2D(0.2, 0.7)
    p4 = Point2D(0.8, 0.3)

    intersection = line_intersect_2d(p1, p2, p3, p4)

    # MATLAB reference values
    expected_intersection = Point2D(0.5, 0.5)

    intersection.assert_close(expected_intersection, rtol=1e-14, atol=1e-15)


def test_output_properties() -> None:
    """Test that output has correct properties."""
    # Simple intersecting lines
    p1 = Point2D(0.0, 0.0)
    p2 = Point2D(1.0, 1.0)
    p3 = Point2D(0.0, 1.0)
    p4 = Point2D(1.0, 0.0)

    intersection = line_intersect_2d(p1, p2, p3, p4)

    # Check types and shapes
    assert isinstance(intersection, Point2D)

    # Should be finite values for intersecting lines
    assert np.all(np.isfinite(np.array(intersection)))

    # Test parallel lines (should return NaN like MATLAB)
    p1_parallel = Point2D(0.0, 0.0)
    p2_parallel = Point2D(1.0, 1.0)
    p3_parallel = Point2D(0.0, 1.0)
    p4_parallel = Point2D(1.0, 2.0)  # Parallel to first line

    intersection_parallel = line_intersect_2d(p1_parallel, p2_parallel, p3_parallel, p4_parallel)

    # Should return NaN for parallel lines (like MATLAB)
    assert isinstance(intersection_parallel, Point2D)
    assert np.all(np.isnan(np.array(intersection_parallel)))
