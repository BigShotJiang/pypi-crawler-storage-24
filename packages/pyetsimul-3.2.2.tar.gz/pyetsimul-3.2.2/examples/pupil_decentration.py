#!/usr/bin/env python3
"""Pupil decentration comparison figure.

Shows pupil decentration across different pupil sizes comparing eye types.
Four configurations: right eye population average, right eye individual, left eye population average, left eye individual.
Five pupil sizes from constricted to dilated conditions.
"""

import matplotlib.pyplot as plt
import numpy as np

from pyetsimul.core import Eye
from pyetsimul.core.pupil_decentration import PupilDecentrationConfig
from pyetsimul.types import Position3D, RotationMatrix


def main() -> None:
    """Demonstrate pupil decentration across different pupil sizes and variation profiles."""
    # Five different pupil sizes (diameters in mm)
    # Range from bright light constriction to dark adaptation dilation
    pupil_sizes = [
        ("Very Small", 2.5),  # Bright light (constricted)
        ("Small", 3.5),  # Indoor lighting
        ("Baseline", 4.75),  # Wildenmann baseline (800 lux)
        ("Large", 6.0),  # Dim lighting
        ("Very Large", 7.5),  # Dark adaptation (dilated)
    ]

    baseline_diameter = 4.75  # Baseline from Wildenmann & Schaeffel (2013)

    # Four decentration configurations: right eye, individual right, left eye, individual left
    eye_configs = [
        (
            "Right Eye (Population Average)",
            PupilDecentrationConfig(
                enabled=True,
                model_name="wildenmann_2013",
                baseline_diameter=baseline_diameter,
                which_eye="right",  # Uses -0.03, -0.04 mm/mm
            ),
        ),
        (
            "Right Eye (Individual Variation)",
            PupilDecentrationConfig(
                enabled=True,
                model_name="wildenmann_2013",
                baseline_diameter=baseline_diameter,
                which_eye="right",
                use_individual_variation=True,  # Random around right eye mean
            ),
        ),
        (
            "Right Eye (Direct Slope)",
            PupilDecentrationConfig(
                enabled=True,
                model_name="wildenmann_2013",
                baseline_diameter=baseline_diameter,
                which_eye="right",
                x_coeff=0.0903,  # parameters of right eye of Subject 5 in Wildenmann & Schaeffel (2013), see figure 3
                y_coeff=-0.1794,
            ),
        ),
        (
            "Left Eye (Population Average)",
            PupilDecentrationConfig(
                enabled=True,
                model_name="wildenmann_2013",
                baseline_diameter=baseline_diameter,
                which_eye="left",  # Uses +0.03, -0.05 mm/mm
            ),
        ),
        (
            "Left Eye (Individual Variation)",
            PupilDecentrationConfig(
                enabled=True,
                model_name="wildenmann_2013",
                baseline_diameter=baseline_diameter,
                which_eye="left",
                use_individual_variation=True,  # Random around left eye mean
            ),
        ),
    ]

    # Create figure with 5 rows (eye types) x 5 columns (pupil sizes)
    fig, axes = plt.subplots(5, 5, figsize=(15, 14))

    # Print coefficients for reference
    print("Decentration coefficients:")
    for config_name, config in eye_configs:
        # Get model parameters to show the actual coefficients being used
        params = config.get_model_params()
        if params and "x_coeff" in params:
            print(f"  {config_name}: x_coeff={params['x_coeff']:.6f}, y_coeff={params['y_coeff']:.6f}")
        else:
            print(f"  {config_name}: No coefficients available")
    print()

    for row, (config_name, config) in enumerate(eye_configs):
        for col, (size_name, diameter) in enumerate(pupil_sizes):
            ax = axes[row, col]

            # Create eye with current decentration config
            eye = Eye(pupil_type="elliptical", pupil_boundary_points=100, decentration_config=config)

            # Create reference eye without decentration for comparison
            ref_eye = Eye(pupil_type="elliptical", pupil_boundary_points=100)

            # Set pupil diameter (this will trigger decentration if enabled)
            eye.set_pupil_diameter(diameter)
            ref_eye.set_pupil_diameter(diameter)

            # Set same orientation for both eyes
            rest_orientation = RotationMatrix([[1, 0, 0], [0, 0, 1], [0, -1, 0]], validate_handedness=False)
            eye.set_rest_orientation(rest_orientation)
            ref_eye.set_rest_orientation(rest_orientation)

            # Position eyes and look at target
            target_point = Position3D(0, 0, 0)
            eye_position = Position3D(0, 50, 0)

            eye.position = eye_position
            ref_eye.position = eye_position

            eye.look_at(target_point)
            ref_eye.look_at(target_point)

            # Get pupil boundary points
            eye_boundary = eye.pupil.get_boundary_points()
            centered_boundary = ref_eye.pupil.get_boundary_points()

            # Boundary points in mm (4xN matrix, take x and y rows)
            eye_x = eye_boundary[0, :]  # X coordinates
            eye_y = eye_boundary[1, :]  # Y coordinates
            centered_x = centered_boundary[0, :]
            centered_y = centered_boundary[1, :]

            # Close the boundaries for plotting
            eye_x = np.append(eye_x, eye_x[0])
            eye_y = np.append(eye_y, eye_y[0])
            centered_x = np.append(centered_x, centered_x[0])
            centered_y = np.append(centered_y, centered_y[0])

            # Get pupil centers for comparison
            eye_center = eye.pupil.pos_pupil
            centered_center = ref_eye.pupil.pos_pupil

            # Plot both pupil positions
            ax.plot(
                centered_x,
                centered_y,
                "b--",
                linewidth=1.5,
                alpha=0.5,
                label="Centered" if row == 0 and col == 0 else "",
            )
            ax.plot(eye_x, eye_y, "r-", linewidth=2, label="Decentered" if row == 0 and col == 0 else "")

            # Mark pupil centers
            ax.plot(centered_center.x, centered_center.y, "bo", markersize=4, alpha=0.7)
            ax.plot(eye_center.x, eye_center.y, "ro", markersize=4)

            # Draw arrow showing decentration vector
            dx = eye_center.x - centered_center.x
            dy = eye_center.y - centered_center.y
            if abs(dx) > 0.001 or abs(dy) > 0.001:  # Only draw if significant offset
                ax.arrow(
                    centered_center.x,
                    centered_center.y,
                    dx,
                    dy,
                    head_width=0.15,
                    head_length=0.08,
                    fc="red",
                    ec="red",
                    alpha=0.8,
                )

            # Set equal aspect ratio and formatting
            ax.set_aspect("equal")
            ax.grid(True, alpha=0.3)

            # Calculate decentration info for title
            diameter_change = diameter - baseline_diameter
            params = config.get_model_params()
            if params and "x_coeff" in params:
                expected_x_offset = params["x_coeff"] * diameter_change
                expected_y_offset = params["y_coeff"] * diameter_change
                offset_text = f"Δx={expected_x_offset:.2f}, Δy={expected_y_offset:.2f} mm"
            else:
                offset_text = "No decentration"

            # Create title - show size name only on top row
            title = f"{size_name} ({diameter:.1f} mm)\n{offset_text}" if row == 0 else f"{offset_text}"
            ax.set_title(title, fontsize=9, fontweight="bold")

            # Set consistent axis limits
            max_radius_mm = 5.0  # Fixed limits for consistency
            ax.set_xlim(-max_radius_mm, max_radius_mm)
            ax.set_ylim(-max_radius_mm, max_radius_mm)

            # Reduce number of ticks for cleaner look
            ax.set_xticks([-4, -2, 0, 2, 4])
            ax.set_yticks([-4, -2, 0, 2, 4])
            ax.tick_params(labelsize=8)

            # Label axes only on left and bottom
            if col == 0:
                ax.set_ylabel("y (mm)", fontsize=9)
            if row == 3:
                ax.set_xlabel("x (mm)", fontsize=9)

        # Add row labels on the right
        axes[row, -1].text(
            1.05,
            0.5,
            config_name,
            transform=axes[row, -1].transAxes,
            rotation=90,
            va="center",
            ha="left",
            fontsize=10,
            fontweight="bold",
        )

    # Add legend to the first subplot
    handles, labels = axes[0, 0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper center", bbox_to_anchor=(0.5, 0.95), ncol=2)

    # Add main title
    fig.suptitle(
        "Pupil Decentration: Eye Type Comparison\nWildenmann & Schaeffel (2013) Model",
        fontsize=14,
        fontweight="bold",
        y=0.98,
    )

    plt.tight_layout(rect=[0, 0, 1, 0.93])

    plt.show()


if __name__ == "__main__":
    main()
