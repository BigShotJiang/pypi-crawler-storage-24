## [0.3.0] - 2026-03-10

### 🚀 Features

- *(iam_scan)* Add high‑risk action detection for credential‑theft
- *(tagging)* Log skipped Lambda functions on tag lookup failure
- *(cli)* Add 30‑day cost forecast and extend anomalies to 30d
- *(cloudwatch)* Add alarm gap detection for ElastiCache and Redshift
- *(cost_scan)* Make snapshot age configurable via env
- *(cost)* Add cost forecast and enhance anomaly detection
- *(inventory)* Make lambda stale days configurable via env
- *(security)* Enhance scans and refactor S3 block public access
- *(types)* Add CRITICAL severity and extend CostAnomaly fields
- *(aws_lighthouse)* Add cost attribution tool and CLI rendering
- *(aws_lighthouse)* Add CloudTrail cost attribution tool
- *(aws_lighthouse)* Add cost attribution types
- *(aws_lighthouse)* Add RI/SP purchase recommendations and CLI panel
- *(aws_lighthouse)* Add RI and SP purchase recommendation tool
- *(aws_lighthouse)* Add remediation plan tool and CLI support
- *(aws_lighthouse)* Add remediation plan builder and phase parser
- *(aws_lighthouse)* Add SG blast radius analysis tool and CLI support
- *(aws_lighthouse)* Implement SG blast radius analysis tool
- *(aws_lighthouse)* Add multi-profile scanning support
- *(aws_lighthouse)* Add Terraform drift classification utility
- *(aws_lighthouse)* Add Terraform drift classification and CLI support
- *(aws_lighthouse)* Add SARIF output support to analyze command
- *(aws_lighthouse)* Add Compute Optimizer EC2 rightsizing tool
- *(aws_lighthouse)* Add VPC flow logs check to security scan
- *(aws_lighthouse)* Add Terraform drift snippet for flow logs
- *(aws_lighthouse)* Add cost allocation tag enforcer
- *(aws_lighthouse)* Add tag cost coverage tool
- *(aws_lighthouse)* Add tag cost coverage reporting
- *(aws_lighthouse)* Add idle NAT gateway and load balancer checks
- *(aws_lighthouse)* Add NAT gateway and load balancer drift checks
- *(aws_lighthouse)* Add webhook notification utilities for alerts
- *(aws_lighthouse)* Add webhook alerts for high/critical findings
- *(aws_lighthouse)* Add idle RDS instance detection to cost scan
- *(aws_lighthouse)* Add idle DB instance suggestion to terraform drift
- *(aws_lighthouse)* Add idle Lambda function detection
- *(aws_lighthouse)* Add HCL fix for non‑invoked Lambda functions
- *(aws_lighthouse)* Add CloudWatch log group retention check
- *(aws_lighthouse)* Add retention detection for CloudWatch logs
- *(aws_lighthouse)* Add audit log command and DB query
- *(aws_lighthouse)* Add proactive session expiry handling
- *(aws_lighthouse)* Add Effective Rate analysis tool
- *(aws_lighthouse)* Add effective rate analysis tool
- *(aws_lighthouse)* Add scenario planning tool and cost estimator CLI

### 🐛 Bug Fixes

- *(logger)* Synchronize error capture stack with threading lock
- *(auth)* Handle BotoCoreError in authentication flow
- *(tools)* Handle fetch errors in RI/SP coverage

### 🚜 Refactor

- *(agent)* Add strict filter parsing and safe-tool validation
- *(security_scan)* Share IAM credential report between checks
- *(remediation)* Delegate EBS deletion to delete_ebs_volume helper
- *(aws_lighthouse)* Tidy cost tool formatting
- *(aws_lighthouse)* Add precise type hints to agent functions

### 🧪 Testing

- *(agent)* Add edge case and validation tests for approval and filters
- Add high-risk IAM action detection tests
- Add tests for credential report reuse and pre‑fetched IAM reports
- *(tagging)* Assert warning logged when per-function tag lookup fails
- *(cli)* Use 30‑day fields in anomaly tests and add forecast output
- *(cloudwatch)* Add ElastiCache and Redshift alarm gap tests
- *(tests)* Add cost forecast and env var override tests
- *(inventory)* Add env var override test for lambda stale days
- *(opportunities)* Update anomaly fields to 30d and add detection_type
- *(remediation)* Mock delete_ebs_volume and simplify error handling
- Add test for preserving partial results on unexpected exception
- *(security)* Add KMS rotation tests and improve security mocks
- *(tests)* Add integration tests for full cycle scenarios
- *(tests)* Add comprehensive bash tool unit and security tests
- *(tests)* Reformat test code and improve readability
- *(tests)* Add cost_attribution field to JSON output verification
- *(tests)* Add comprehensive CloudTrail attribution unit tests
- *(tests)* Add RI/SP advisor tests and update CLI test expectations
- *(remediation)* Add remediation plan tests and adjust CLI selection
- *(sg_blast_radius)* Add unit tests and CLI expectations
- *(tests)* Add unit tests for profile parsing and listing
- *(tests)* Add tests for --terraform-dir flag on analyze command
- *(tests)* Add unit tests for Terraform drift classification utilities
- *(tests)* Add SARIF output tests and improve output validation
- *(tests)* Add unit tests for Compute Optimizer tool
- *(tests)* Add unit tests for VPC flow logs check
- *(tests)* Add VPC flow logs unit test
- *(tests)* Add unit tests for tag cost enforcer
- *(tests)* Add unit tests for tag cost coverage and untagged spend
- *(tests)* Add unit tests for idle NAT gateways and load balancers
- *(tests)* Add NAT gateway and load balancer drift tests
- *(tests)* Add unit tests for notify utilities
- *(tests)* Add unit tests for idle RDS instance detection
- *(tests)* Add unit test for RDS instances with no connections
- *(tests)* Add comprehensive idle Lambda function checks
- *(tests)* Add lambda not invoked detection test
- *(tests)* Add tests for _check_log_group_retention
- *(tests)* Add test for log group retention detection
- *(tests)* Add tests for audit CLI command and DB audit log
- *(tests)* Combine multiple patches into a single with block
- *(tests)* Add comprehensive session expiry unit tests
- *(tests)* Clean up assertions and add effective_rate tests
- *(tests)* Add cost estimator and scenario planner unit tests

### ⚙️ Miscellaneous Tasks

- *(test)* Add pytest markers for unit, integration, slow, security
- *(.github)* Add test matrix and build check jobs to CI workflow
- *(.github)* Use uv pip install for wheel smoke-test
- *(.github)* Install Gitleaks and switch to CLI scanning
- *(.github)* Add Gitleaks config file and use it in CI
- *(lint)* Add C90, SIM, RUF selects and enable mccabe complexity
- Bump version to 0.3.0
