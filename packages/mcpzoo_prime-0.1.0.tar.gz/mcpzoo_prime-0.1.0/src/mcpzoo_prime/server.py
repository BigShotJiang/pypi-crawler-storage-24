import math
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("prime")

def check_is_prime(n: int) -> bool:
    if n <= 1: return False
    if n <= 3: return True
    if n % 2 == 0 or n % 3 == 0: return False
    i = 5
    while i * i <= n:
        if n % i == 0 or n % (i + 2) == 0:
            return False
        i += 6
    return True

def prime_factors(n: int) -> list[int]:
    factors = []
    # 2
    while n % 2 == 0:
        factors.append(2)
        n = n // 2
    # 3 及以上奇数
    for i in range(3, int(math.sqrt(n)) + 1, 2):
        while n % i == 0:
            factors.append(i)
            n = n // i
    if n > 2:
        factors.append(n)
    return factors

@mcp.tool()
def check_prime(number: int) -> str:
    """判断一个整数是否为素数，并输出其质因数分解。"""
    if number <= 0:
        return "请输入正整数"
        
    is_p = check_is_prime(number)
    factors = prime_factors(number)
    
    res = f"数值: {number}\n是否素数: {'是' if is_p else '否'}\n"
    res += f"质因数分解: {' * '.join(map(str, factors))}"
    
    return res

def main():
    mcp.run()

if __name__ == "__main__":
    main()
