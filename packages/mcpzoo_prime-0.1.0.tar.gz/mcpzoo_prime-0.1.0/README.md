# mcpzoo-prime

> 素数判断 — 判断是否为素数并分解质因数

## Installation

```bash
uvx mcpzoo-prime
```

## uvx JSON

```json
{
  "mcpServers": {
    "prime": {
      "args": ["mcpzoo-prime"],
      "command": "uvx"
    }
  }
}
```
