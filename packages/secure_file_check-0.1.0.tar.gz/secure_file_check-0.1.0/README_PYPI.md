# secure-file-check (Python)

**CLI + API for file type validation and suspicious Office detection**

A lightweight utility to validate file types by comparing extensions against magic bytes and detecting potentially malicious Office documents (e.g., VBA macros). This tool is designed for security-conscious Python applications that handle user uploads, ensuring that a file is exactly what it claims to be.

## Features

- Magic Byte Validation: Verifies file content against extensions to prevent spoofing.
- Suspicious Office Detection: Identifies the presence of VBA projects or macros in documents like `.docx` or `.xlsx`.
- Structured Output: Emits JSON for easy integration with CI/CD and log aggregators.
- Audit Logging: Writes structured JSON audit lines to stderr or a dedicated log file.
- Supported Types: `png`, `jpg`, `jpeg`, `pdf`, `docx`, `xlsx`, `gif`, `bmp`, `tiff`, `mp3`, `wav`, `svg`.

## Installation

```sh
pip install secure-file-check
```

## CLI Usage

```sh
secure-file-check --file=path/to/file
```

## API Usage

```python
from secure_file_check.validator import validate_file
result = validate_file("path/to/file.docx")
print(result)
```
