import struct

def parse_zip_entries(f, file_size):
    # Read last 64KB for EOCD
    read_size = min(65536, file_size)
    f.seek(file_size - read_size)
    tail = f.read(read_size)
    sig = b'\x50\x4b\x05\x06'
    idx = tail.rfind(sig)
    if idx == -1:
        raise ValueError("Invalid ZIP (no EOCD)")
    central_dir_offset = struct.unpack_from('<I', tail, idx + 16)[0]
    f.seek(central_dir_offset)
    header = f.read(4096)
    entries = []
    i = 0
    while i < len(header) - 46:
        if header[i:i+2] != b'PK':
            break
        file_name_length = struct.unpack_from('<H', header, i + 28)[0]
        extra_length = struct.unpack_from('<H', header, i + 30)[0]
        comment_length = struct.unpack_from('<H', header, i + 32)[0]
        name_start = i + 46
        name_end = name_start + file_name_length
        name = header[name_start:name_end].decode('utf-8', errors='replace')
        entries.append(name)
        i = name_end + extra_length + comment_length
    return entries

def validate_office(entries, ext):
    if ext == "docx":
        return "word/document.xml" in entries
    if ext == "xlsx":
        return "xl/workbook.xml" in entries
    return False
