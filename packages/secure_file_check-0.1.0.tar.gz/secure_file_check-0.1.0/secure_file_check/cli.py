import argparse
import json
import sys
from .validator import validate_file, ValidationError
from .logger import init_logger

def main():
    parser = argparse.ArgumentParser(description="Secure File Check: Validate file types and detect suspicious Office files.")
    parser.add_argument('--file', help='File to validate')
    parser.add_argument('--allow', help='Comma-separated list of allowed extensions')
    parser.add_argument('--log', help='Log file path')
    parser.add_argument('--quiet', action='store_true', help='Suppress non-error output')
    parser.add_argument('--json', action='store_true', help='Output result as JSON')
    parser.add_argument('--fail-fast', action='store_true', help='Exit on first failure')
    parser.add_argument('--ci', action='store_true', help='CI mode: quiet, fail-fast, JSON streaming')
    args = parser.parse_args()

    allowed_types = args.allow.split(',') if args.allow else None
    logger = init_logger(args.log, args.quiet or args.ci)

    if args.file:
        try:
            result = validate_file(args.file, allowed_types=allowed_types)
            if args.json or args.ci:
                print(json.dumps(result))
            else:
                print(f"Valid: {args.file} ({result['ext']}, {result['size']} bytes, suspicious={result['suspicious']})")
        except ValidationError as e:
            if args.json or args.ci:
                print(json.dumps({"file": args.file, "error": str(e)}))
            else:
                print(f"Invalid: {args.file} - {e}")
            sys.exit(1)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
