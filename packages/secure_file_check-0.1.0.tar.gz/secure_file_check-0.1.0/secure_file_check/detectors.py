"""
File Type Detectors

This module provides functions to detect file types based on their magic numbers
or specific file signatures. Each function reads the necessary bytes from the
file and validates the signature.
"""

from typing import BinaryIO

def read_chunk(f: BinaryIO, start: int, length: int) -> bytes:
    """Read a specific chunk of bytes from a file."""
    f.seek(start)
    chunk = f.read(length)
    if len(chunk) < length:
        raise ValueError("File is too small to read the required chunk")
    return chunk

def is_png(f: BinaryIO) -> bool:
    """Check if the file is a PNG image."""
    return read_chunk(f, 0, 8) == b'\x89PNG\r\n\x1a\n'

def is_jpeg(f: BinaryIO) -> bool:
    """Check if the file is a JPEG image."""
    return read_chunk(f, 0, 3).startswith(b'\xFF\xD8\xFF')

def is_pdf(f: BinaryIO) -> bool:
    """Check if the file is a PDF document."""
    return read_chunk(f, 0, 4) == b'%PDF'

def is_zip(f: BinaryIO) -> bool:
    """Check if the file is a ZIP archive."""
    return read_chunk(f, 0, 2) == b'PK'

def is_gif(f: BinaryIO) -> bool:
    """Check if the file is a GIF image."""
    sig = read_chunk(f, 0, 6)
    return sig in (b'GIF87a', b'GIF89a')

def is_bmp(f: BinaryIO) -> bool:
    """Check if the file is a BMP image."""
    return read_chunk(f, 0, 2) == b'BM'

def is_tiff(f: BinaryIO) -> bool:
    """Check if the file is a TIFF image."""
    b = read_chunk(f, 0, 4)
    return b[:2] in (b'II', b'MM') and b[2:] in (b'\x2A\x00', b'\x00\x2A')

def is_mp3(f: BinaryIO) -> bool:
    """Check if the file is an MP3 audio file."""
    return read_chunk(f, 0, 3).startswith(b'ID3')

def is_wav(f: BinaryIO) -> bool:
    """Check if the file is a WAV audio file."""
    return read_chunk(f, 0, 4) == b'RIFF'

def is_svg(f: BinaryIO) -> bool:
    """Check if the file is an SVG image."""
    f.seek(0)
    start = f.read(100).lower()
    return b'<svg' in start