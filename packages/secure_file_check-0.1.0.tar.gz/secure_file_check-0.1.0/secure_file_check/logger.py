import logging
import sys

def init_logger(log_file=None, quiet=False):
    logger = logging.getLogger("secure_file_check")
    logger.setLevel(logging.INFO)
    handler = logging.StreamHandler(sys.stderr)
    if log_file:
        handler = logging.FileHandler(log_file)
    formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
    handler.setFormatter(formatter)
    if not logger.handlers:
        logger.addHandler(handler)
    if quiet:
        logger.setLevel(logging.ERROR)
    return logger

def audit_log(entry):
    logger = logging.getLogger("secure_file_check")
    logger.info(entry)
