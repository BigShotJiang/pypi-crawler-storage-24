import logging
from pathlib import Path
from .detectors import *
from .zip_utils import parse_zip_entries, validate_office

logger = logging.getLogger("secure_file_check")

class ValidationError(Exception):
    pass

def _is_printable_text(file_obj):
    """
    Basic heuristic to check if the file is non-empty and starts with printable characters.
    Moved outside the main function to avoid redefining it on every call.
    """
    file_obj.seek(0)
    start = file_obj.read(100)
    return len(start) > 0 and all(32 <= b <= 126 or b in (9, 10, 13) for b in start)

SIMPLE_DETECTORS = {
    "png": is_png,
    "jpg": is_jpeg,
    "jpeg": is_jpeg,
    "pdf": is_pdf,
    "gif": is_gif,
    "bmp": is_bmp,
    "tiff": is_tiff,
    "tif": is_tiff,
    "mp3": is_mp3,
    "wav": is_wav,
    "svg": is_svg,
}

def validate_file(file_path, allowed_types=None, max_size=50*1024*1024, detect_suspicious=True):
    if allowed_types is None:
        allowed_types = {
            "png", "jpg", "jpeg", "pdf", "docx", "xlsx", 
            "gif", "bmp", "tiff", "mp3", "wav", "svg"
        }
    else:
        allowed_types = set(allowed_types)

    path = Path(file_path)

    if not path.is_file():
        raise ValidationError(f"File does not exist or is not a regular file: {file_path}")

    file_size = path.stat().st_size
    if file_size > max_size:
        raise ValidationError(f"File too large: {file_size} bytes exceeds limit of {max_size}")
    if file_size == 0:
        raise ValidationError("File is empty")

    ext = path.suffix[1:].lower() if path.suffix else ""
    if not ext or ext not in allowed_types:
        raise ValidationError(f"Extension '{ext}' not allowed or missing")

    suspicious = False
    valid = False

    with open(path, "rb") as f:
        try:
            if ext in SIMPLE_DETECTORS:
                valid = SIMPLE_DETECTORS[ext](f)

            elif ext in {"docx", "xlsx"}:
                if is_zip(f):
                    entries = parse_zip_entries(f, file_size)
                    valid = validate_office(entries, ext)
                    if detect_suspicious and valid:
                        suspicious = any("vbaproject.bin" in e.lower() for e in entries)
                else:
                    logger.error(f"Invalid ZIP structure for Office file: {path}")
                    valid = False

            else:
                if _is_printable_text(f):
                    logger.warning(f"Unknown file type '{ext}' passed text heuristic check")
                    valid = True
                else:
                    logger.error(f"Unknown file type '{ext}' failed text heuristic check (Binary files need a custom detector)")
                    valid = False

        except Exception as e:
            logger.error(f"Validation failed for {path}: {e}")
            valid = False

    if not valid:
        logger.error(f"File content invalid or does not match expected signature for '{ext}': {path}")
        raise ValidationError("File content invalid")

    result = {
        "file": str(path),
        "ext": ext,
        "size": file_size,
        "suspicious": suspicious,
        "valid": valid,
    }
    logger.info(f"File valid: {path} | Details: {result}")
    
    return result