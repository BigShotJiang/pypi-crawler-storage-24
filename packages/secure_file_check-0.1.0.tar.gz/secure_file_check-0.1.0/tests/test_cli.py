import subprocess
import sys
import os
import json

def test_cli_valid_png(tmp_path):
    file_path = tmp_path / "test.png"
    file_path.write_bytes(b"\x89PNG\r\n\x1a\n" + b"0"*10)
    result = subprocess.run([
        sys.executable, "-m", "secure_file_check.cli", "--file", str(file_path), "--json"
    ], capture_output=True, text=True)
    assert result.returncode == 0
    data = json.loads(result.stdout.strip())
    assert data["ext"] == "png"
    assert data["suspicious"] is False

def test_cli_invalid_ext(tmp_path):
    file_path = tmp_path / "test.txt"
    file_path.write_bytes(b"Hello")
    result = subprocess.run([
        sys.executable, "-m", "secure_file_check.cli", "--file", str(file_path), "--json"
    ], capture_output=True, text=True)
    assert result.returncode != 0
    data = json.loads(result.stdout.strip())
    assert "not allowed" in data["error"]
