from setuptools import setup, find_packages

setup(
    name="secure-file-check",
    version="0.1.0",
    description="CLI & API for secure file upload validation: check file type (magic bytes, MIME), detect Office macros/malware, audit logging, and CI/CD integration.",
    author="vietvq",
    packages=find_packages(),
    install_requires=[],
    entry_points={
        'console_scripts': [
            'secure-file-check=secure_file_check.cli:main',
        ],
    },
    python_requires='>=3.7',
    include_package_data=True,
    license="MIT",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)