import re

HEADING_RE = re.compile(r"^(#{1,8})\s+(.+)$", re.MULTILINE)


def split_markdown_hierarchical(md_text: str, doc_name: str, include_metadata:bool=True):
    
    # metadata stamps
    METADATA_START = "<!-- METADATA_START -->"
    METADATA_END = "<!-- METADATA_END -->"
    
    if not include_metadata:
        if METADATA_START in md_text and METADATA_END in md_text:
            pre = md_text.split(METADATA_START)[0]
            post = md_text.split(METADATA_END,1)[1]
            md_text = pre + post
        
        
    matches = list(HEADING_RE.finditer(md_text))
    nodes = []

    for i, m in enumerate(matches):
        start = m.start()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(md_text)

        level = len(m.group(1))
        title = m.group(2).strip()
        body = md_text[start:end].strip()

        nodes.append({
            "level": level,
            "title": title,
            "body": body,
        })

    stack = []
    tree = []

    for n in nodes:
        while stack and stack[-1]["level"] >= n["level"]:
            stack.pop()
        if stack:
            stack[-1].setdefault("children", []).append(n)
        else:
            tree.append(n)
        stack.append(n)

    def collapse(node):
        text = node["body"]
        for c in node.get("children", []):
            text += "\n\n" + collapse(c)
        return text

    sections = {}

    def walk(n):
        key = f"{doc_name}::{n['title']}"
        sections[key] = collapse(n)
        for c in n.get("children", []):
            walk(c)

    for root in tree:
        walk(root)

    return sections
 
 
 
import json

def process_markdown_file(path: str, qd_number: str=None, doc_name: str=None,link:str=link, OUT_DIR= None, include_metadata:bool=True):
    
    path = Path(path)
    if OUT_DIR is None:
         out = path.with_suffix(".sections.json")
    else:        
        OUT_DIR = Path(OUT_DIR)
        OUT_DIR.mkdir(exist_ok=True)
        out = OUT_DIR / path.with_suffix(".sections.json").name
       
    
    text = Path(path).read_text(encoding="utf-8")

    sections = split_markdown_hierarchical(text, doc_name=doc_name, include_metadata=True)

    payload = {
        "qd": qd_number,
        "document": doc_name,
        "link":link,
        "sections": sections
    }

    # out.write_text(json.dump(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    with open(out, 'w', encoding='utf-8') as file:
        json.dump(payload, file, indent=2, ensure_ascii=False)
    
    

from docpipe.metadata import get_metadata

for idx, md_path in enumerate(files):
    idx+=1
    
    doc_name = md_path.stem
    qd_number = None
    document_title = doc_name
    link = None

    try:
        metadata = get_metadata(document_name=doc_name, metadata_path=metadata_path)
        print(metadata)
        qd_number = metadata.get("document_number")
        document_title = metadata.get("blob_filename", doc_name)
        link = metadata.get("url_document_name","")
        print("📄 Metadata found:", doc_name)
    except Exception as e:
        print("⚠️ Metadata missing:", doc_name)
        print("ERROR:",e)

    try:
        process_markdown_file(
            md_path,
            qd_number=qd_number,
            doc_name=document_title,
            link = link,
            OUT_DIR=JSON_DIR,
        )
        print(idx, "✅ processed:", doc_name)
    except Exception as e:
        print(idx, "❌ failed to process:", doc_name, "|", e)
        
        

def enrich_sections_for_vector(sections_json: dict):
    """
    Takes sections JSON and injects document + hierarchy context
    into the section text for vector indexing.
    """

    qd = sections_json["qd"]
    doc_name = sections_json["document"]
    sections = sections_json["sections"]
    link = sections_json["link"]
    

    # Map heading number → heading title (for H1 lookup)
    h1_map = {}

    enriched = {}

    for key, text in sections.items():
        _, heading = key.split("::", 1)

        # Extract numeric prefix
        number = heading.split()[0]  # e.g. "5", "5.1"

        if "." not in number:
            # Heading 1
            h1_map[number] = heading

            enriched_text = (
                f"In document {doc_name}.\n\n"
                f"{text}"
            )

        else:
            # Heading 2
            parent_num = number.split(".", 1)[0]
            parent_heading = h1_map.get(parent_num)

            enriched_text = (
                f"In document {doc_name}, under {parent_heading}.\n\n"
                f"{text}"
            )

        enriched[key] = enriched_text
    enriched_payload = {
        'qd-number': qd,
        'doc_name': doc_name,
        'link':link,
        'enriched' : enriched
    }
    return enriched_payload


from azure.search.documents import SearchClient
from azure.core.credentials import AzureKeyCredential

search_client = SearchClient(
        endpoint=AZURE_SEARCH_ENDPOINT,
        index_name=collection_name, # option_a
        credential=AzureKeyCredential(AZURE_SEARCH_ADMIN_KEY)
    )

import uuid

def make_doc(
    qd_number: str,
    document_name: str,
    veeva_link:str,
    section_heading: str,
    text: str
):
    embedding = embedding_model.embed_query(text)

    return {
        "id": f"{ uuid.uuid4().hex }",
        "qd_number": qd_number,
        "document_name": document_name,
        "veeva_link":veeva_link,
        "section_heading": section_heading,
        "content": text,
        "embedding": embedding,
    }
 