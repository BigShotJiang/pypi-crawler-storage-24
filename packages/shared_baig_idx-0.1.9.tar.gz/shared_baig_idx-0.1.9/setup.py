from pathlib import Path
from setuptools import setup, Extension, find_packages
from Cython.Build import cythonize

PACKAGE_NAME = "shared"
DIST_NAME = "shared-baig-idx"
VERSION = "0.1.9"

root = Path(PACKAGE_NAME)

excluded_files = {
    "__init__.py",
}

# agar kuch files .py hi rakhni ho to yahan add karo
keep_as_py = {
    "chunking_json.py",
}

extensions = []

for py_file in root.rglob("*.py"):
    if py_file.name in excluded_files:
        continue
    if py_file.name in keep_as_py:
        continue

    module_name = ".".join(py_file.with_suffix("").parts)
    print(f"Adding extension: {module_name} -> {py_file}")

    extensions.append(
        Extension(
            module_name,
            [str(py_file)],
        )
    )

setup(
    name=DIST_NAME,
    version=VERSION,
    description="Shared processing package",
    packages=find_packages(include=["shared", "shared.*"]),
    include_package_data=True,
    package_data={
        "": ["*.so"],
    },
    ext_modules=cythonize(
        extensions,
        compiler_directives={"language_level": "3"},
    ),
    zip_safe=False,
    python_requires=">=3.11",
    install_requires=[
        # external dependencies yahan add karo
        # "rapidfuzz",
        # "numpy",
        # "pandas",
    ],
)