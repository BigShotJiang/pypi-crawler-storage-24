# Contributing to pyvista-js

Thank you for your interest in contributing to pyvista-js! This document provides guidelines and instructions for contributing to the project.

## Table of Contents

<!-- START doctoc generated TOC please keep comment here to allow auto update -->
<!-- DON'T EDIT THIS SECTION, INSTEAD RE-RUN doctoc TO UPDATE -->

- [Code of Conduct](#code-of-conduct)
- [Getting Started](#getting-started)
- [Development Setup](#development-setup)
  - [Prerequisites](#prerequisites)
  - [Initial Setup](#initial-setup)
- [Development Workflow](#development-workflow)
  - [Creating a Branch](#creating-a-branch)
  - [Making Changes](#making-changes)
  - [Committing Changes](#committing-changes)
- [Code Quality Standards](#code-quality-standards)
  - [Pre-commit Hooks](#pre-commit-hooks)
  - [Running Code Quality Checks Manually](#running-code-quality-checks-manually)
  - [Code Style Guidelines](#code-style-guidelines)
- [Testing](#testing)
  - [Running Tests](#running-tests)
  - [Writing Tests](#writing-tests)
  - [Test Requirements](#test-requirements)
- [Documentation](#documentation)
  - [Documentation Framework](#documentation-framework)
  - [Building Documentation](#building-documentation)
  - [Documentation Standards](#documentation-standards)
- [Pull Request Process](#pull-request-process)
  - [Before Submitting](#before-submitting)
  - [Submitting a Pull Request](#submitting-a-pull-request)
  - [PR Requirements](#pr-requirements)
  - [Continuous Integration](#continuous-integration)
- [Types of Contributions](#types-of-contributions)
  - [Code Contributions](#code-contributions)
  - [Documentation](#documentation-1)
  - [Community](#community)
  - [Recognition](#recognition)
- [Scientific Python Standards](#scientific-python-standards)
  - [SPEC 0 — Minimum Supported Dependencies](#spec-0--minimum-supported-dependencies)
  - [SPEC 1 — Lazy Loading of Submodules](#spec-1--lazy-loading-of-submodules)
  - [SPEC 4 — Nightly Tests](#spec-4--nightly-tests)
  - [SPEC 6 — Upper Bound Constraints](#spec-6--upper-bound-constraints)
  - [SPEC 7 — Seeding Random Number Generation](#spec-7--seeding-random-number-generation)
  - [SPEC 8 — Securing the Release Process](#spec-8--securing-the-release-process)
- [Community Resources](#community-resources)
- [Questions?](#questions)

<!-- END doctoc generated TOC please keep comment here to allow auto update -->

## Code of Conduct

This project adheres to the [Contributor Covenant 3.0](CODE_OF_CONDUCT.md). By participating, you are expected to uphold this code. Please report unacceptable behavior to [@tkoyama010](https://github.com/tkoyama010).

## Getting Started

pyvista-js is a PyVista-like API for vtk.js that brings intuitive 3D visualization to the browser. Before contributing:

1. Check the [issue tracker](https://github.com/tkoyama010/pyvista-js/issues) for existing issues or create a new one
1. Join the discussion on [GitHub Discussions](https://github.com/tkoyama010/pyvista-js/discussions)
1. Read through the [documentation](https://pyvista-js.readthedocs.io/)

## Development Setup

### Prerequisites

- Python 3.12 or higher (3.12, 3.13, or 3.14 recommended for testing)
- [uv](https://github.com/astral-sh/uv) - Ultra-fast Python package installer
- Git

### Initial Setup

1. Fork the repository on GitHub

1. Clone your fork:

   ```bash
   git clone https://github.com/YOUR-USERNAME/pyvista-js.git
   cd pyvista-js
   ```

1. Install uv if you haven't already:

   ```bash
   # On macOS and Linux
   curl -LsSf https://astral.sh/uv/install.sh | sh

   # On Windows
   powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
   ```

1. Install development dependencies:

   ```bash
   uv sync --group dev
   ```

1. Install pre-commit hooks:

   ```bash
   uv run pre-commit install
   ```

1. Install Playwright browsers (required for browser tests):

   ```bash
   uv run playwright install chromium
   ```

## Development Workflow

[![Conventional Commits](https://img.shields.io/badge/Conventional%20Commits-1.0.0-%23FE5196?logo=conventionalcommits&logoColor=white)](https://conventionalcommits.org)

### Creating a Branch

Create a descriptive branch name:

```bash
git checkout -b feature/your-feature-name
# or
git checkout -b fix/issue-description
```

### Making Changes

1. Make your changes in the appropriate files
1. Write or update tests as needed
1. Update documentation if necessary
1. Run pre-commit checks (happens automatically on commit, or manually with `uv run pre-commit run --all-files`)

### Committing Changes

This project uses [Conventional Commits](https://www.conventionalcommits.org/). Your commit messages should follow this format:

```
type(scope): description

[optional body]

[optional footer]
```

Common types:

- `feat`: A new feature
- `fix`: A bug fix
- `docs`: Documentation only changes
- `style`: Changes that do not affect the meaning of the code
- `refactor`: A code change that neither fixes a bug nor adds a feature
- `perf`: A code change that improves performance
- `test`: Adding missing tests or correcting existing tests
- `chore`: Changes to the build process or auxiliary tools

Example:

```bash
git commit -m "feat(plotter): add support for physically based rendering"
```

## Code Quality Standards

[![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)
[![djlint](https://img.shields.io/badge/html%20templates-djLint-blueviolet.svg)](https://www.djlint.com)

### Pre-commit Hooks

The project uses pre-commit hooks to ensure code quality. These run automatically on commit:

- **Formatting**: `ruff-format` for Python code, `mdformat` for Markdown
- **Linting**: `ruff` for Python linting
- **Type Checking**: `mypy` for static type analysis
- **HTML Templates**: `djlint` for Jinja template formatting
- **Security**: `pygrep-hooks` for common security issues
- **Documentation**: `codespell` for spell checking
- **Repository Review**: `sp-repo-review` for Scientific Python standards

### Running Code Quality Checks Manually

```bash
# Run all pre-commit hooks
uv run pre-commit run --all-files

# Run specific tools
uv run ruff check src/
uv run ruff format src/
uv run mypy src/
```

### Code Style Guidelines

- **Line Length**: Maximum 100 characters
- **Type Hints**: Use type hints where appropriate (gradual typing approach)
- **Docstrings**: Follow existing patterns in the codebase
- **Naming**: Use descriptive variable and function names
- **Imports**: Organize imports logically; pre-commit will sort them

## Testing

[![uv](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/uv/main/assets/badge/v0.json)](https://github.com/astral-sh/uv)

### Running Tests

```bash
# Run all tests
uv run pytest

# Run tests for specific Python version using tox
uv run tox -e py312
uv run tox -e py313
uv run tox -e py314

# Run tests without Playwright tests
uv run pytest -m "not playwright"

# Run with coverage
uv run pytest --cov=pyvista_js --cov-report=html
```

### Writing Tests

- Place tests in the `tests/` directory
- Use `pytest` for test framework
- Follow existing test patterns
- Include tests for new features and bug fixes
- Browser-based tests use `playwright` and should be marked with `@pytest.mark.playwright`

### Test Requirements

- All new features should include tests
- Bug fixes should include regression tests
- Maintain or improve code coverage
- Tests should pass on Python 3.12, 3.13, and 3.14

## Documentation

[![Diátaxis](https://img.shields.io/badge/Documentation-Di%C3%A1taxis-blue.svg?style=flat)](https://diataxis.fr/)

### Documentation Framework

This project follows the [Diátaxis](https://diataxis.fr/) documentation framework:

- **Tutorials** (`docs/tutorials/`): Learning-oriented lessons
- **How-to Guides** (`docs/howtos/`): Problem-oriented guides
- **Explanation** (`docs/explanation/`): Understanding-oriented discussions
- **Reference** (`docs/api/`): Information-oriented technical descriptions

### Building Documentation

```bash
# Install documentation dependencies
uv sync --group docs

# Build documentation
uv run tox -e docs

# The built documentation will be in docs/_build/html/
```

### Documentation Standards

- Write clear, concise documentation
- Include code examples where appropriate
- Update API documentation for new features
- Check spelling with `codespell`
- Follow existing documentation structure

## Pull Request Process

### Before Submitting

1. Ensure all tests pass locally
1. Run pre-commit hooks: `uv run pre-commit run --all-files`
1. Update documentation if needed
1. Add yourself to the contributors list (maintainers will help with this)

### Submitting a Pull Request

1. Push your changes to your fork
1. Create a pull request against the `main` branch
1. Use a descriptive PR title following [Conventional Commits](https://www.conventionalcommits.org/) format:
   - `feat: add new visualization feature`
   - `fix: resolve rendering issue in Safari`
   - `docs: update installation instructions`
1. Fill out the pull request template
1. Link any related issues (e.g., "Closes #123")
1. Wait for review and address any feedback

### PR Requirements

- **Conventional Commits**: PR title must follow conventional commits format
- **Tests**: All tests must pass (checked by CI)
- **Pre-commit**: All pre-commit checks must pass (pre-commit.ci will auto-fix some issues)
- **Coverage**: Code coverage should not decrease
- **Documentation**: Update documentation for new features

### Continuous Integration

Pull requests are automatically tested using GitHub Actions:

- Linting and formatting checks
- Tests on Python 3.12, 3.13, and 3.14
- Tests on Linux, Windows, and macOS
- Code coverage reporting to Codecov
- Conventional commit PR title validation

## Types of Contributions

We welcome various types of contributions:

### Code Contributions

- New features
- Bug fixes
- Performance improvements
- Code refactoring

### Documentation

- Improving existing documentation
- Adding examples and tutorials
- Fixing typos and clarifications
- Translating documentation (via [Transifex](https://app.transifex.com/tkoyama010/pyvista-js/))

### Community

- Answering questions in [GitHub Discussions](https://github.com/tkoyama010/pyvista-js/discussions)
- Reporting bugs
- Suggesting new features
- Reviewing pull requests
- Creating demos and examples

### Recognition

All contributions are recognized using [all-contributors](https://allcontributors.org/). Contributions include:

- 💻 Code
- 📖 Documentation
- 🤔 Ideas and planning
- 🐛 Bug reports
- 🌍 Translation
- ✅ Tests
- 👀 Review
- 📦 Packaging

## Scientific Python Standards

This project follows several [Scientific Python SPECs](https://scientific-python.org/specs/):

### SPEC 0 — Minimum Supported Dependencies

[![SPEC 0 — Minimum Supported Dependencies](https://img.shields.io/badge/SPEC-0-green?labelColor=%23004811&color=%235CA038)](https://scientific-python.org/specs/spec-0000/)

- **Python**: 3.12+ (drop support 36 months after release)
- **NumPy**: 2.0+ (drop support 24 months after release)
- Other core dependencies follow similar policies

### SPEC 1 — Lazy Loading of Submodules

[![SPEC 1 — Lazy Loading of Submodules and Functions](https://img.shields.io/badge/SPEC-1-green?labelColor=%23004811&color=%235CA038)](https://scientific-python.org/specs/spec-0001/)

- Submodules are lazily loaded using `lazy-loader`
- Improves import time and memory usage

### SPEC 4 — Nightly Tests

[![SPEC 4 — Nightly Tests](https://img.shields.io/badge/SPEC-4-green?labelColor=%23004811&color=%235CA038)](https://scientific-python.org/specs/spec-0004/)

- Regular testing against development versions of dependencies
- Ensures forward compatibility

### SPEC 6 — Upper Bound Constraints

[![SPEC 6 — Upper Bound Constraints on Dependencies](https://img.shields.io/badge/SPEC-6-green?labelColor=%23004811&color=%235CA038)](https://scientific-python.org/specs/spec-0006/)

- No upper bounds on dependency versions unless technically required
- Prevents dependency conflicts in downstream projects

### SPEC 7 — Seeding Random Number Generation

[![SPEC 7 — Seeding Pseudo-Random Number Generation](https://img.shields.io/badge/SPEC-7-green?labelColor=%23004811&color=%235CA038)](https://scientific-python.org/specs/spec-0007/)

- Use `numpy.random.default_rng()` for random number generation
- Use `rng` parameter for seeding
- Avoid global state and legacy generators

### SPEC 8 — Securing the Release Process

- Trusted publishing via OpenID Connect (OIDC) to PyPI
- Build provenance attestations using Sigstore
- All GitHub Actions pinned to commit SHAs

## Community Resources

[![Transifex](https://img.shields.io/badge/Translations-Transifex-blue.svg)](https://app.transifex.com/tkoyama010/pyvista-js/)
[![Join the community](https://img.shields.io/badge/Join%20the%20community-on%20GitHub%20Discussions-blue)](https://github.com/tkoyama010/pyvista-js/discussions)

- **Issues**: [GitHub Issues](https://github.com/tkoyama010/pyvista-js/issues)
- **Discussions**: [GitHub Discussions](https://github.com/tkoyama010/pyvista-js/discussions)
- **Translations**: [Transifex](https://app.transifex.com/tkoyama010/pyvista-js/)
- **Documentation**: [Read the Docs](https://pyvista-js.readthedocs.io/)
- **Live Demo**: [JupyterLite](https://tkoyama010.github.io/pyvista-js/)

## Questions?

If you have questions about contributing, feel free to:

- Open a [GitHub Discussion](https://github.com/tkoyama010/pyvista-js/discussions)
- Check existing [issues](https://github.com/tkoyama010/pyvista-js/issues)
- Review the [documentation](https://pyvista-js.readthedocs.io/)

Thank you for contributing to pyvista-js! 🎉
