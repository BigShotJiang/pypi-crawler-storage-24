"""Run Operator with channels and agents."""

import asyncio
import os
import shutil
from pathlib import Path

from dotenv import load_dotenv
import logging
from rich.console import Console

load_dotenv()

logger = logging.getLogger(__name__)

_console = Console()
_P = "#e5c07b"   # primary   – warm gold
_S = "#61afef"   # secondary – blue
_M = "#abb2bf"   # muted     – gray


def _row(label: str, value: str) -> None:
    _console.print(f"│ [{_M}]{label:<10}[/{_M}] [{_S}]{value}[/{_S}]")


def _version() -> str:
    try:
        from importlib.metadata import version
        return version("operator-use")
    except Exception:
        return ""

def _print_startup(lines: list[tuple[str, str]], title_suffix: str = "") -> None:
    ver = _version()
    ver_str = f" [{_M}]v{ver}[/{_M}]" if ver else ""
    _console.print(f"┌ [bold {_P}]Operator[/bold {_P}]{ver_str}[{_M}]{title_suffix}[/{_M}]")
    _console.print("│")
    for label, value in lines:
        _row(label, value)


def setup_logging(userdata_dir: Path) -> None:
    log_file = userdata_dir / "operator.log"
    userdata_dir.mkdir(parents=True, exist_ok=True)

    fmt = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
    datefmt = "%H:%M:%S"
    handlers = [
        logging.StreamHandler(),
        logging.FileHandler(log_file, encoding="utf-8"),
    ]

    logging.basicConfig(level=logging.WARNING, format=fmt, datefmt=datefmt, handlers=handlers)

import operator_use
from operator_use.agent import Agent
from operator_use.orchestrator import Orchestrator
from operator_use.bus import Bus
from operator_use.gateway import Gateway
from operator_use.gateway.channels import TelegramChannel, DiscordChannel, SlackChannel, MQTTChannel
from operator_use.acp import ACPStdioChannel, ACPStdioConfig, ACPChannel, ACPServerConfig
from operator_use.gateway.channels.config import TelegramConfig, MQTTConfig
from operator_use.gateway.channels.discord import DiscordConfig
from operator_use.gateway.channels.slack import SlackConfig
from operator_use.providers.base import BaseChatLLM, BaseSTT, BaseTTS

from operator_use.heartbeat import Heartbeat
from operator_use.crons.views import CronJob
from operator_use.crons import Cron
from operator_use.bus import OutgoingMessage, IncomingMessage, TextPart
from operator_use.config import Config, load_config, AgentDefinition
from operator_use.paths import get_named_workspace_dir
from typing import Optional
from pathlib import Path

LLM_CLASS_MAP = {
    "openai": "ChatOpenAI",
    "anthropic": "ChatAnthropic",
    "google": "ChatGoogle",
    "mistral": "ChatMistral",
    "groq": "ChatGroq",
    "nvidia": "ChatNvidia",
    "ollama": "ChatOllama",
    "cerebras": "ChatCerebras",
    "open_router": "ChatOpenRouter",
    "azure_openai": "ChatAzureOpenAI",
    "litellm": "ChatLiteLLM",
    "vllm": "ChatVLLM",
    "deepseek": "ChatDeepSeek",
    "codex": "ChatCodex",
    "claude_code": "ChatClaudeCode",
    "antigravity": "ChatAntigravity",
    "github_copilot": "ChatGitHubCopilot",
}

STT_CLASS_MAP = {
    "openai": "STTOpenAI",
    "google": "STTGoogle",
    "groq": "STTGroq",
    "elevenlabs": "STTElevenLabs",
    "deepgram": "STTDeepgram",
    "sarvam": "STTSarvam",
}

TTS_CLASS_MAP = {
    "openai": "TTSOpenAI",
    "google": "TTSGoogle",
    "groq": "TTSGroq",
    "elevenlabs": "TTSElevenLabs",
    "deepgram": "TTSDeepgram",
    "sarvam": "TTSSarvam",
}


def _make_llm(config: Config, llm_conf) -> Optional[BaseChatLLM]:
    import operator_use.providers as providers
    if not llm_conf.provider:
        return None
    llm_cls_name = LLM_CLASS_MAP.get(llm_conf.provider)
    if not llm_cls_name or not hasattr(providers, llm_cls_name):
        return None
    llm_cls = getattr(providers, llm_cls_name)
    p_conf = getattr(config.providers, llm_conf.provider, None)
    return llm_cls(
        model=llm_conf.model,
        api_key=(p_conf.api_key or None) if p_conf else None,
        base_url=(p_conf.api_base or None) if p_conf else None,
    )


def _make_stt(config: Config) -> Optional[BaseSTT]:
    import operator_use.providers as providers
    stt_conf = config.stt
    if not stt_conf.enabled or not stt_conf.provider:
        return None
    stt_cls_name = STT_CLASS_MAP.get(stt_conf.provider)
    if not stt_cls_name or not hasattr(providers, stt_cls_name):
        return None
    stt_cls = getattr(providers, stt_cls_name)
    p_conf = getattr(config.providers, stt_conf.provider, None)
    return stt_cls(model=stt_conf.model, api_key=p_conf.api_key if p_conf else None)


def _make_tts(config: Config) -> Optional[BaseTTS]:
    import operator_use.providers as providers
    tts_conf = config.tts
    if not tts_conf.enabled or not tts_conf.provider:
        return None
    tts_cls_name = TTS_CLASS_MAP.get(tts_conf.provider)
    if not tts_cls_name or not hasattr(providers, tts_cls_name):
        return None
    tts_cls = getattr(providers, tts_cls_name)
    p_conf = getattr(config.providers, tts_conf.provider, None)
    tts_kwargs = {"model": tts_conf.model, "api_key": p_conf.api_key if p_conf else None}
    if tts_conf.voice:
        tts_kwargs["voice"] = tts_conf.voice
    return tts_cls(**tts_kwargs)


def _make_models(config: Config) -> tuple[Optional[BaseChatLLM], Optional[BaseSTT], Optional[BaseTTS]]:
    """Build default LLM + STT + TTS from config (used by REPL and other single-agent commands)."""
    llm_conf = config.agents.defaults.llm_config
    return _make_llm(config, llm_conf), _make_stt(config), _make_tts(config)


def _resolve_agent_workspace(defn: AgentDefinition) -> Path:
    if defn.workspace:
        return Path(defn.workspace).expanduser().resolve()
    return get_named_workspace_dir(defn.id)


def _build_agents(config: Config, cron, gateway, bus) -> dict[str, Agent]:
    """Instantiate one Agent per agent definition in config."""
    defaults = config.agents.defaults
    agent_defs = config.agents.list

    if not agent_defs:
        raise ValueError("No agents defined in config. Run 'operator onboard' to set up an agent.")

    agents = {}
    for defn in agent_defs:
        llm_conf = defn.llm_config or defaults.llm_config
        llm = _make_llm(config, llm_conf)
        workspace = _resolve_agent_workspace(defn)
        agents[defn.id] = Agent(
            llm=llm,
            workspace=workspace,
            use_computer=defn.use_computer if defn.use_computer is not None else defaults.use_computer,
            max_iterations=defn.max_tool_iterations or defaults.max_tool_iterations,
            cron=cron,
            gateway=gateway,
            bus=bus,
            acp_registry=config.acp_agents,
        )

    return agents


def _build_router(config: Config):
    """Build a router callable from config bindings (top-down, first match wins)."""
    bindings = config.bindings
    agent_ids = {defn.id for defn in config.agents.list}
    default_agent = config.agents.list[0].id if config.agents.list else ""

    def router(msg) -> str:
        for binding in bindings:
            m = binding.match
            if not m.channel or m.channel != msg.channel:
                continue
            if m.peer:
                if msg.chat_id == m.peer.id:
                    return binding.agent_id
                continue  # peer specified but didn't match — keep evaluating
            return binding.agent_id
        return default_agent

    return router


def copy_templates_to_workspace(user_data_dir: Path, workspace: Path) -> None:
    """Copy template files to workspace, skipping files that already exist."""
    template_dir = Path(operator_use.__file__).resolve().parent / "templates"

    if not template_dir.exists():
        return

    (workspace / "skills").mkdir(parents=True, exist_ok=True)

    for src in template_dir.iterdir():
        if src.is_file():
            dest = workspace / src.name
            if dest.exists():
                continue
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dest)
        elif src.is_dir():
            dest_dir = workspace / src.name
            dest_dir.mkdir(parents=True, exist_ok=True)
            for f in src.iterdir():
                if f.is_file():
                    dest_file = dest_dir / f.name
                    if not dest_file.exists():
                        shutil.copy2(f, dest_file)

async def main():
    from operator_use.paths import get_userdata_dir
    USERDATA_DIR = get_userdata_dir()
    setup_logging(USERDATA_DIR)

    try:
        config = load_config(USERDATA_DIR)
    except FileNotFoundError:
        print("Error: No config.json found. Please run 'uv run main.py onboard' first.")
        return

    # Copy templates for each defined agent workspace
    if not config.agents.list:
        print("Error: No agents defined in config. Run 'operator onboard' to set up an agent.")
        return
    for defn in config.agents.list:
        copy_templates_to_workspace(USERDATA_DIR, workspace=_resolve_agent_workspace(defn))

    bus = Bus()
    gateway = Gateway(bus=bus)

    # Add Telegram channel if enabled
    telegram_config = config.channels.telegram
    if not telegram_config.token:
        telegram_config.token = os.getenv("TELEGRAM_TOKEN", "")
    if telegram_config.enabled and telegram_config.token:
        channel = TelegramChannel(config=telegram_config, bus=bus)
        gateway.add_channel(channel)

    # Add Discord channel if enabled
    discord_config = config.channels.discord
    if not discord_config.token:
        discord_config.token = os.getenv("DISCORD_TOKEN", "")
    if discord_config.enabled and discord_config.token:
        discord_channel = DiscordChannel(config=discord_config, bus=bus)
        gateway.add_channel(discord_channel)

    # Add Slack channel if enabled
    slack_config = config.channels.slack
    if not slack_config.bot_token:
        slack_config.bot_token = os.getenv("SLACK_BOT_TOKEN", "")
    if not slack_config.app_token:
        slack_config.app_token = os.getenv("SLACK_APP_TOKEN", "")
    if slack_config.enabled and slack_config.bot_token and slack_config.app_token:
        slack_channel = SlackChannel(config=slack_config, bus=bus)
        gateway.add_channel(slack_channel)

    # Add MQTT channel if enabled
    mqtt_config = getattr(config.channels, "mqtt", None) or MQTTConfig()
    if mqtt_config.enabled and mqtt_config.broker_host:
        mqtt_channel = MQTTChannel(config=mqtt_config, bus=bus)
        gateway.add_channel(mqtt_channel)

    # Add JSON-RPC 2.0 stdio channel if OPERATOR_STDIO=1
    stdio_enabled = os.getenv("OPERATOR_STDIO", "").lower() in ("1", "true", "yes")
    if stdio_enabled:
        stdio_cfg = ACPStdioConfig(enabled=True)
        stdio_channel = ACPStdioChannel(config=stdio_cfg, bus=bus)
        gateway.add_channel(stdio_channel)

    # Add ACP server channel if enabled in config
    acp_server_cfg = config.acp_server
    acp_server_enabled = acp_server_cfg.enabled
    if acp_server_enabled:
        acp_srv_config = ACPServerConfig(
            enabled=True,
            host=acp_server_cfg.host,
            port=acp_server_cfg.port,
            agent_id=acp_server_cfg.agent_id,
            agent_name=acp_server_cfg.agent_name,
            agent_description=acp_server_cfg.agent_description,
            auth_token=acp_server_cfg.auth_token,
            public_url=acp_server_cfg.public_url,
        )
        acp_channel = ACPChannel(config=acp_srv_config, bus=bus)
        gateway.add_channel(acp_channel)

    if (
        not (telegram_config.enabled and telegram_config.token)
        and not (discord_config.enabled and discord_config.token)
        and not (slack_config.enabled and slack_config.bot_token and slack_config.app_token)
        and not (mqtt_config.enabled and mqtt_config.broker_host)
        and not stdio_enabled
        and not acp_server_enabled
    ):
        print("Error: No channel configured (Telegram, Discord, Slack, MQTT, stdio, or ACP server).")
        return

    stt = _make_stt(config)
    tts = _make_tts(config)

    async def on_job(job: CronJob):
        channel = job.payload.channel
        chat_id = job.payload.chat_id
        message = job.payload.message
        if not message or not channel or not chat_id:
            return

        if job.payload.deliver:
            await bus.publish_outgoing(
                OutgoingMessage(
                    chat_id=chat_id,
                    channel=channel,
                    parts=[TextPart(content=message)],
                    reply=False,
                )
            )
        else:
            await bus.publish_incoming(
                IncomingMessage(
                    channel=channel,
                    chat_id=chat_id,
                    parts=[TextPart(content=message)],
                    user_id="cron",
                    metadata={"_cron_job": True, "job_id": job.id, "job_name": job.name},
                )
            )

    cron_store = USERDATA_DIR / "crons.json"
    cron = Cron(store_path=cron_store, on_job=on_job)

    agents = _build_agents(config, cron=cron, gateway=gateway, bus=bus)
    router = _build_router(config)

    defaults = config.agents.defaults
    orchestrator = Orchestrator(
        bus=bus,
        agents=agents,
        stt=stt,
        tts=tts,
        streaming=defaults.streaming,
        gateway=gateway,
        cron=cron,
        router=router,
    )

    async def on_heartbeat(content: str) -> None:
        return await orchestrator.process_direct(
            content=content,
            channel="cli",
            chat_id="heartbeat",
        )

    first_agent_workspace = _resolve_agent_workspace(config.agents.list[0])
    heartbeat = Heartbeat(workspace=first_agent_workspace, on_heartbeat=on_heartbeat)

    channels_active = []
    if telegram_config.enabled and telegram_config.token:
        channels_active.append("Telegram")
    if discord_config.enabled and discord_config.token:
        channels_active.append("Discord")
    if mqtt_config.enabled and mqtt_config.broker_host:
        channels_active.append(f"MQTT({mqtt_config.broker_host})")
    if slack_config.enabled and slack_config.bot_token and slack_config.app_token:
        channels_active.append("Slack")
    if stdio_enabled:
        channels_active.append("Stdio(JSON-RPC 2.0)")
    if acp_server_enabled:
        channels_active.append(f"ACP({acp_server_cfg.host}:{acp_server_cfg.port})")

    restart_file = USERDATA_DIR / "restart.json"
    if restart_file.exists():
        _console.clear()

    llm_conf = defaults.llm_config
    stt_conf = config.stt
    tts_conf = config.tts
    startup_rows: list[tuple[str, str]] = []
    if llm_conf.provider:
        startup_rows.append(("LLM", f"{llm_conf.provider} / {llm_conf.model}"))
    if stt_conf.enabled and stt_conf.provider:
        startup_rows.append(("STT", f"{stt_conf.provider} / {stt_conf.model}"))
    if tts_conf.enabled and tts_conf.provider:
        startup_rows.append(("TTS", f"{tts_conf.provider} / {tts_conf.model}"))
    if len(agents) > 1:
        startup_rows.append(("Agents", ", ".join(agents.keys())))

    suffix = "  (Ctrl+C to stop)"
    if defaults.use_computer:
        suffix = " + Computer-Use" + suffix
    _print_startup(startup_rows, suffix)

    _row("Channels", ", ".join(channels_active) if channels_active else "none")

    restart_file = USERDATA_DIR / "restart.json"

    try:
        if config.heartbeat_enabled:
            heartbeat.start()
        cron.start()

        cron_jobs = cron.list_jobs()
        heartbeat_mins = int(heartbeat.interval // 60)
        _row("Heartbeat", f"every {heartbeat_mins} min" if config.heartbeat_enabled else "disabled")
        _row("Cron", f"{len(cron_jobs)} jobs")

        if restart_file.exists():
            import json as _json
            restart_data = _json.loads(restart_file.read_text(encoding="utf-8"))
            restart_file.unlink()
            task = restart_data.get("task", "")
            resume_channel = restart_data.get("channel")
            resume_chat_id = restart_data.get("chat_id")
            print(f"[restart] Continuation found (channel={resume_channel} chat_id={resume_chat_id}): {task[:80]}", flush=True)
            if task and resume_channel and resume_chat_id:
                async def _dispatch_continuation():
                    await asyncio.sleep(10)
                    print(f"[restart] Dispatching continuation to channel={resume_channel} chat_id={resume_chat_id}", flush=True)
                    await bus.publish_incoming(
                        IncomingMessage(
                            channel=resume_channel,
                            chat_id=resume_chat_id,
                            parts=[TextPart(content=task)],
                            user_id="restart",
                        )
                    )
                asyncio.ensure_future(_dispatch_continuation())

        await asyncio.gather(
            gateway.start(),
            orchestrator.ainvoke(),
        )
    except (asyncio.CancelledError, KeyboardInterrupt):
        pass
    finally:
        if config.heartbeat_enabled:
            heartbeat.stop()
        cron.stop()
        try:
            await asyncio.shield(gateway.stop())
        except asyncio.CancelledError:
            pass


RESTART_EXIT_CODE = 75


def run() -> None:
    """Supervisor/worker restart pattern.

    If IS_WORKER=1 is set, this is the worker — run main() directly and exit.
    Otherwise this is the supervisor — spawn the worker as a child subprocess
    and relaunch it whenever it exits with RESTART_EXIT_CODE (75).

    This gives a fresh Python process on every restart (fresh imports, fresh
    state) while keeping the terminal attached on Windows, because the
    supervisor blocks on subprocess.run() the whole time.
    """
    import subprocess
    import sys

    if os.getenv("IS_WORKER"):
        asyncio.run(main())
        sys.exit(0)

    worker_env = {**os.environ, "IS_WORKER": "1"}
    while True:
        result = subprocess.run([sys.executable, "-m", "operator_use"] + sys.argv[1:], env=worker_env)
        if result.returncode == RESTART_EXIT_CODE:
            print("[supervisor] Restarting...", flush=True)
            continue
        sys.exit(result.returncode)


if __name__ == "__main__":
    run()
