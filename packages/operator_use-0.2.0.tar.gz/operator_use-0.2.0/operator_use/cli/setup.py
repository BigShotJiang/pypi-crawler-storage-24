import os
import sys
import json
import re as _re
from pathlib import Path

from dotenv import load_dotenv
load_dotenv()

sys.path.insert(0, str(Path(__file__).parent.parent))
from operator_use.cli.tui import print_banner, print_start, select, text_input, confirm, print_end, console

# --- Registry Data ---

LLM_PROVIDERS: dict[str, list[tuple[str, str]]] = {
    "Groq": [
        ("Llama 4 Scout 17B (recommended)", "meta-llama/llama-4-scout-17b-16e-instruct"),
        ("Llama 3.3 70B", "llama-3.3-70b-versatile"),
        ("Llama 3.1 8B", "llama-3.1-8b-instant"),
        ("Qwen3 32B", "qwen/qwen3-32b"),
        ("Compound (agentic)", "groq/compound"),
    ],
    "NVIDIA": [
        ("Qwen 3.5 122B", "qwen/qwen3.5-122b-a10b"),
        ("Llama 3.3 70B", "meta/llama-3.3-70b-instruct"),
        ("Llama 3.1 405B", "meta/llama-3.1-405b-instruct"),
        ("DeepSeek R1", "deepseek-ai/deepseek-r1"),
        ("Mistral Large", "mistralai/mistral-large"),
        ("Nemotron 4 340B", "nvidia/nemotron-4-340b-instruct"),
    ],
    "OpenAI": [
        ("GPT-4.1", "gpt-4.1"),
        ("GPT-4.1 mini", "gpt-4.1-mini"),
        ("GPT-4o", "gpt-4o"),
        ("GPT-4o mini", "gpt-4o-mini"),
        ("o3", "o3"),
        ("o4-mini", "o4-mini"),
        ("o1", "o1"),
    ],
    "Anthropic": [
        ("Claude Sonnet 4.5 (recommended)", "claude-sonnet-4-5"),
        ("Claude Opus 4", "claude-opus-4-20250514"),
        ("Claude 3.5 Sonnet", "claude-3-5-sonnet-latest"),
        ("Claude 3.5 Haiku", "claude-3-5-haiku-latest"),
        ("Claude 3 Haiku", "claude-3-haiku-latest"),
    ],
    "Google": [
        ("Gemini 2.5 Pro", "gemini-2.5-pro"),
        ("Gemini 2.5 Flash", "gemini-2.5-flash"),
        ("Gemini 2.0 Flash", "gemini-2.0-flash"),
        ("Gemini 1.5 Pro", "gemini-1.5-pro"),
    ],
    "Mistral": [
        ("Mistral Large 3", "mistral-large-2512"),
        ("Mistral Medium 3.1", "mistral-medium-2508"),
        ("Mistral Small 3.2", "mistral-small-2506"),
        ("Mistral Large (legacy)", "mistral-large-latest"),
    ],
    "DeepSeek": [
        ("DeepSeek V3 (Chat)", "deepseek-chat"),
        ("DeepSeek R1 (Reasoner)", "deepseek-reasoner"),
    ],
    "Cerebras": [
        ("Llama 3.3 70B", "llama-3.3-70b"),
        ("Llama 3.1 8B", "llama3.1-8b"),
        ("Llama 3.1 70B", "llama-3.1-70b"),
    ],
    "OpenRouter": [
        ("Llama 4 Scout (recommended)", "meta-llama/llama-4-scout-17b-16e-instruct"),
        ("Claude 3.5 Sonnet", "anthropic/claude-3.5-sonnet"),
        ("GPT-4o", "openai/gpt-4o"),
        ("Gemini 2.0 Flash", "google/gemini-2.0-flash"),
        ("Llama 3.3 70B", "meta-llama/llama-3.3-70b-instruct"),
    ],
    "Ollama": [
        ("Llama 3.3 70B", "llama3.3"),
        ("Llama 3.2", "llama3.2"),
        ("DeepSeek R1", "deepseek-r1"),
        ("Qwen 3.5", "qwen3.5"),
        ("Mistral", "mistral"),
        ("Gemma 3", "gemma3"),
    ],
    "Antigravity": [
        ("Gemini 3 Pro (recommended)", "gemini-3-pro"),
        ("Gemini 3 Flash", "gemini-3-flash"),
        ("Gemini 2.5 Pro", "gemini-2.5-pro"),
        ("Gemini 2.5 Flash", "gemini-2.5-flash"),
        ("Claude Opus 4.6", "claude-opus-4-6"),
        ("Claude Sonnet 4.6", "claude-sonnet-4-6"),
    ],
    "Codex": [
        ("GPT-5.4 (recommended)", "gpt-5.4"),
    ],
    "Claude Code": [
        ("Claude Sonnet 4.6 (recommended)", "claude-sonnet-4-6"),
        ("Claude Opus 4.6", "claude-opus-4-6"),
    ],
    "GitHub Copilot": [
        ("GPT-4o (recommended)", "gpt-4o"),
        ("Claude Sonnet 4.6", "claude-sonnet-4-6"),
        ("Claude Opus 4.6", "claude-opus-4-6"),
        ("Gemini 2.5 Pro", "gemini-2.5-pro"),
        ("GPT-4.1", "gpt-4.1"),
    ],
}

STT_PROVIDERS: dict[str, list[tuple[str, str]]] = {
    "Groq": [
        ("Whisper Large v3 Turbo (recommended)", "whisper-large-v3-turbo"),
        ("Whisper Large v3", "whisper-large-v3"),
    ],
    "OpenAI": [
        ("Whisper 1", "whisper-1"),
    ],
    "Google": [
        ("Gemini 2.0 Flash", "gemini-2.0-flash"),
        ("Gemini 2.5 Flash", "gemini-2.5-flash"),
    ],
    "ElevenLabs": [
        ("Scribe v1", "scribe_v1"),
    ],
    "Deepgram": [
        ("Nova 3 (recommended)", "nova-3"),
        ("Nova 2", "nova-2"),
    ],
    "Sarvam": [
        ("Saaras v3 (recommended)", "saaras:v3"),
    ],
}

TTS_PROVIDERS: dict[str, list[tuple[str, str]]] = {
    "Groq": [
        ("Orpheus v1 English", "canopylabs/orpheus-v1-english"),
    ],
    "OpenAI": [
        ("TTS-1 HD", "tts-1-hd"),
        ("TTS-1", "tts-1"),
    ],
    "Google": [
        ("Gemini 2.0 Flash Preview TTS", "gemini-2.0-flash-preview-tts"),
    ],
    "ElevenLabs": [
        ("Multilingual v2", "eleven_multilingual_v2"),
        ("Flash v2.5", "eleven_flash_v2_5"),
    ],
    "Deepgram": [
        ("Aura 2", "aura-2"),
    ],
    "Sarvam": [
        ("Bulbul v3 (recommended)", "bulbul:v3"),
    ],
}

VOICES: dict[str, list[str]] = {
    "OpenAI": ["alloy", "echo", "fable", "onyx", "nova", "shimmer"],
    "Groq": ["autumn", "diana", "hannah", "austin", "daniel", "troy"],
    "Google": ["Aoede", "Charon", "Fenrir", "Kore", "Puck"],
    "ElevenLabs": ["Rachel", "Drew", "Clyde", "Paul", "Domi"],
    "Deepgram": ["asteria-en", "luna-en", "stella-en", "athena-en", "hera-en"],
    "Sarvam": ["aditya", "ritu", "ashutosh", "priya", "neha", "rahul", "pooja", "rohan", "simran", "kavya", "amit", "dev", "ishita", "shreya", "ratan", "varun", "manan", "sumit", "roopa", "kabir", "aayan", "shubh", "advait", "amelia", "sophia", "anand", "tanya", "tarun", "sunny", "mani", "gokul", "vijay", "shruti", "suhani", "mohit", "kavitha", "rehan", "soham", "rupali"],
}

OAUTH_PROVIDERS = {"Antigravity", "Codex", "Claude Code", "GitHub Copilot"}

OAUTH_NOTES = {
    "Antigravity": "Uses Google Cloud Code Assist OAuth. Run: operator auth antigravity",
    "Codex": "Uses ChatGPT subscription OAuth. Run: operator auth codex",
    "Claude Code": "Uses Claude Code CLI OAuth. Run: operator auth claude-code",
    "GitHub Copilot": "Uses GitHub OAuth (Device Flow). Run: operator auth github-copilot",
}

CHANNEL_NOTES = {
    "Telegram": "Create a bot via @BotFather on Telegram and copy the token.",
    "Discord":  "Create a bot at discord.com/developers, enable Message Content Intent, and copy the token.",
    "Slack":    "Create a Slack app at api.slack.com. Bot token starts with xoxb-, app token with xapp-.",
}


def get_provider_key(name: str) -> str:
    key_map = {
        "OpenRouter": "open_router",
        "ElevenLabs": "elevenlabs",
        "Deepgram": "deepgram",
        "NVIDIA": "nvidia",
        "DeepSeek": "deepseek",
        "Sarvam": "sarvam",
        "Claude Code": "claude_code",
        "GitHub Copilot": "github_copilot",
    }
    return key_map.get(name, name.lower())


def _select_model(label: str, options: list[tuple[str, str]]) -> str:
    display_names = [d for d, _ in options]
    chosen_display = select(label, display_names)
    return next(mid for d, mid in options if d == chosen_display)


from operator_use.config import (
    Config, LLMConfig, STTConfig, TTSConfig,
    AgentDefaults, AgentsConfig, ProvidersConfig, ProviderConfig,
    ChannelsConfig, TelegramConfig, DiscordConfig, SlackConfig,
    AgentDefinition,
)


def configure_channel(existing: ChannelsConfig | None = None) -> ChannelsConfig:
    """Prompt the user to pick and configure one channel. Returns updated ChannelsConfig."""
    channels = existing or ChannelsConfig()
    channel_name = select("Pick a channel to connect:", ["Telegram", "Discord", "Slack"])

    note = CHANNEL_NOTES.get(channel_name, "")
    if note:
        console.print("│")
        console.print(f"│  [dim]{note}[/dim]")

    if channel_name == "Telegram":
        token = text_input("Enter Telegram Bot Token:", is_password=True)
        channels.telegram = TelegramConfig(enabled=True, token=token)
    elif channel_name == "Discord":
        token = text_input("Enter Discord Bot Token:", is_password=True)
        channels.discord = DiscordConfig(enabled=True, token=token)
    elif channel_name == "Slack":
        bot_token = text_input("Enter Slack Bot Token (xoxb-...):", is_password=True)
        app_token = text_input("Enter Slack App Token (xapp-...):", is_password=True)
        channels.slack = SlackConfig(enabled=True, bot_token=bot_token, app_token=app_token)

    return channels


def run_initial_setup():
    print_banner()
    print_start()

    from operator_use.paths import get_userdata_dir
    _config_path = get_userdata_dir() / "config.json"

    # --- Load existing config ---
    existing_data: dict = {}
    if _config_path.exists():
        try:
            with open(_config_path, encoding="utf-8") as f:
                existing_data = json.load(f)
        except Exception:
            pass

    # Collect already-saved API keys so we never re-ask for them
    api_keys_dict: dict[str, str] = {}
    for prov, pconf in existing_data.get("providers", {}).items():
        k = pconf.get("apiKey") or pconf.get("api_key", "")
        if k:
            api_keys_dict[prov] = k

    # Unpack existing global defaults
    _defaults = existing_data.get("agents", {}).get("defaults", {})
    _llm = _defaults.get("llmConfig", _defaults.get("llm_config", {}))
    _stt = existing_data.get("stt", {})
    _tts = existing_data.get("tts", {})
    _ch  = existing_data.get("channels", {})
    heartbeat_enabled: bool = bool(existing_data.get("heartbeatEnabled", existing_data.get("heartbeat_enabled", True)))

    # --- Global mutable state ---
    llm_provider_key: str = _llm.get("provider", "")
    llm_model: str        = _llm.get("model", "")

    stt_enabled: bool     = bool(_stt.get("enabled", False))
    stt_provider_key: str = _stt.get("provider", "") or ""
    stt_model: str        = _stt.get("model", "") or ""

    tts_enabled: bool     = bool(_tts.get("enabled", False))
    tts_provider_key: str = _tts.get("provider", "") or ""
    tts_model: str        = _tts.get("model", "") or ""
    tts_voice: str | None = _tts.get("voice", None)

    channels = ChannelsConfig(**_ch) if _ch else ChannelsConfig()

    # Agent definitions: list of dicts with per-agent overrides.
    # None values mean "use global default".
    agent_defs: list[dict] = []
    for a in existing_data.get("agents", {}).get("list", []):
        _a_llm = a.get("llmConfig", a.get("llm_config")) or {}
        agent_defs.append({
            "id":               a.get("id", ""),
            "llm_provider_key": _a_llm.get("provider") or None,
            "llm_model":        _a_llm.get("model") or None,
            "use_computer":     a.get("useComputer", a.get("use_computer", None)),
        })

    def _need_key(prov_key: str, prov_name: str) -> bool:
        return prov_key not in api_keys_dict and prov_name not in OAUTH_PROVIDERS

    def _configure_llm(cur_prov: str, cur_model: str) -> tuple[str, str]:
        """Shared LLM picker. Returns (provider_key, model)."""
        prov_name = select("Pick the LLM provider:", list(LLM_PROVIDERS.keys()))
        prov_key  = get_provider_key(prov_name)
        model     = _select_model("Pick the LLM model:", LLM_PROVIDERS[prov_name])
        if prov_name in OAUTH_PROVIDERS:
            console.print("│")
            console.print(f"│  [dim]ℹ  {OAUTH_NOTES[prov_name]}[/dim]")
        elif _need_key(prov_key, prov_name):
            api_keys_dict[prov_key] = text_input(f"Enter API Key for {prov_name}:", is_password=True)
        return prov_key, model

    # --- First run: create the initial agent ---
    if not agent_defs:
        raw = text_input("Name your agent (e.g. mybot, personal, work):", default="default")
        initial_id = _re.sub(r"[^a-z0-9_-]", "-", raw.strip().lower()) or "default"
        agent_defs.append({
            "id": initial_id,
            "llm_provider_key": None,
            "llm_model": None,
            "use_computer": None,
        })

    # ── Per-agent submenu ─────────────────────────────────────────────────────
    def _agent_submenu(idx: int) -> None:
        while True:
            a = agent_defs[idx]

            if a["llm_provider_key"] and a["llm_model"]:
                a_llm_label = f"{a['llm_provider_key']} / {a['llm_model']}"
            else:
                default_llm = f"{llm_provider_key} / {llm_model}" if llm_provider_key else "not configured"
                a_llm_label = f"(default: {default_llm})"

            choice = select(f"Configure agent: {a['id']}", [
                f"Rename         {a['id']}",
                f"LLM            {a_llm_label}",
                "Remove agent",
                "← Back",
            ])

            if choice.startswith("←"):
                break

            elif choice.startswith("Rename"):
                raw = text_input("New agent name:", default=a["id"])
                new_id = _re.sub(r"[^a-z0-9_-]", "-", raw.strip().lower()) or a["id"]
                if any(o["id"] == new_id for i2, o in enumerate(agent_defs) if i2 != idx):
                    console.print("│")
                    console.print(f"│  [red]Name '{new_id}' is already taken.[/red]")
                else:
                    agent_defs[idx]["id"] = new_id

            elif choice.startswith("LLM"):
                if confirm("Use global LLM default for this agent?"):
                    agent_defs[idx]["llm_provider_key"] = None
                    agent_defs[idx]["llm_model"] = None
                else:
                    pk, m = _configure_llm(a["llm_provider_key"] or "", a["llm_model"] or "")
                    agent_defs[idx]["llm_provider_key"] = pk
                    agent_defs[idx]["llm_model"] = m

            elif choice.startswith("Remove"):
                if len(agent_defs) <= 1:
                    console.print("│")
                    console.print("│  [red]Cannot remove the last agent.[/red]")
                elif confirm(f"Remove agent '{a['id']}'?"):
                    agent_defs.pop(idx)
                    break

    # ── Agents submenu ────────────────────────────────────────────────────────
    def _agents_menu() -> None:
        while True:
            default_llm = f"{llm_provider_key} / {llm_model}" if llm_provider_key else "not configured"
            agent_choices = []
            for a in agent_defs:
                if a["llm_provider_key"] and a["llm_model"]:
                    llm_lbl = f"{a['llm_provider_key']} / {a['llm_model']}"
                else:
                    llm_lbl = f"(default: {default_llm})"
                agent_choices.append(f"{a['id']}  —  {llm_lbl}")
            agent_choices.append("+ Add agent")
            agent_choices.append("← Back")

            choice = select("Manage Agents:", agent_choices)

            if choice.startswith("←"):
                break

            elif choice.startswith("+"):
                raw = text_input("New agent name:")
                new_id = _re.sub(r"[^a-z0-9_-]", "-", raw.strip().lower()) or "agent"
                if any(a["id"] == new_id for a in agent_defs):
                    console.print("│")
                    console.print(f"│  [red]Agent '{new_id}' already exists.[/red]")
                else:
                    agent_defs.append({
                        "id": new_id,
                        "llm_provider_key": None,
                        "llm_model": None,
                        "use_computer": None,
                    })
                    _agent_submenu(len(agent_defs) - 1)

            else:
                for i, a in enumerate(agent_defs):
                    if choice.startswith(a["id"]):
                        _agent_submenu(i)
                        break

    # --- Main menu loop ---
    while True:
        llm_label    = f"{llm_provider_key} / {llm_model}" if llm_provider_key else "not configured"
        stt_label    = f"{stt_provider_key} / {stt_model}" if stt_enabled else "disabled"
        tts_label    = f"{tts_provider_key} / {tts_model}" if tts_enabled else "disabled"
        active_ch    = [n for n, t in [
            ("Telegram", channels.telegram.token),
            ("Discord",  channels.discord.token),
            ("Slack",    channels.slack.bot_token),
        ] if t]
        ch_label     = ", ".join(active_ch) if active_ch else "none"
        agents_label = ", ".join(a["id"] for a in agent_defs)
        cu_owner     = next((a["id"] for a in agent_defs if a.get("use_computer")), None)
        if cu_owner:
            cu_label = cu_owner if len(agent_defs) > 1 else "enabled"
        else:
            cu_label = "disabled"
        hb_label     = "enabled" if heartbeat_enabled else "disabled"

        choice = select("What would you like to configure?", [
            f"LLM           {llm_label}",
            f"STT           {stt_label}",
            f"TTS           {tts_label}",
            f"Computer Use  {cu_label}",
            f"Heartbeat     {hb_label}",
            f"Agents        {agents_label}",
            f"Channels      {ch_label}",
            "Save & Exit",
        ])

        # ── LLM (global default) ──────────────────────────────────────────────
        if choice.startswith("LLM"):
            llm_provider_key, llm_model = _configure_llm(llm_provider_key, llm_model)

        # ── STT ──────────────────────────────────────────────────────────────
        elif choice.startswith("STT"):
            if confirm("Enable Speech-to-Text (STT)?"):
                prov_name = select("Pick the STT provider:", list(STT_PROVIDERS.keys()))
                stt_provider_key = get_provider_key(prov_name)
                stt_model = _select_model("Pick the STT model:", STT_PROVIDERS[prov_name])
                if _need_key(stt_provider_key, prov_name):
                    api_keys_dict[stt_provider_key] = text_input(f"Enter API Key for {prov_name}:", is_password=True)
                stt_enabled = True
            else:
                stt_enabled = False
                stt_provider_key = ""
                stt_model = ""

        # ── TTS ──────────────────────────────────────────────────────────────
        elif choice.startswith("TTS"):
            if confirm("Enable Text-to-Speech (TTS)?"):
                prov_name = select("Pick the TTS provider:", list(TTS_PROVIDERS.keys()))
                tts_provider_key = get_provider_key(prov_name)
                tts_model = _select_model("Pick the TTS model:", TTS_PROVIDERS[prov_name])
                tts_voice = None
                if prov_name in VOICES:
                    tts_voice = select("Pick a voice:", VOICES[prov_name])
                if _need_key(tts_provider_key, prov_name):
                    api_keys_dict[tts_provider_key] = text_input(f"Enter API Key for {prov_name}:", is_password=True)
                tts_enabled = True
            else:
                tts_enabled = False
                tts_provider_key = ""
                tts_model = ""
                tts_voice = None

        # ── Computer Use ─────────────────────────────────────────────────────
        elif choice.startswith("Computer Use"):
            if len(agent_defs) == 1:
                # Single agent: simple toggle
                agent_defs[0]["use_computer"] = confirm(
                    f"Enable Computer Use for '{agent_defs[0]['id']}'?"
                )
            else:
                # Multiple agents: pick which one owns it
                cu_owner = next((a["id"] for a in agent_defs if a.get("use_computer")), None)
                choices  = [a["id"] for a in agent_defs] + ["Disable"]
                picked   = select(
                    "Which agent should have Computer Use?" + (f"  (currently: {cu_owner})" if cu_owner else ""),
                    choices,
                )
                for a in agent_defs:
                    a["use_computer"] = False
                if picked != "Disable":
                    next(a for a in agent_defs if a["id"] == picked)["use_computer"] = True

        # ── Heartbeat ─────────────────────────────────────────────────────────
        elif choice.startswith("Heartbeat"):
            heartbeat_enabled = confirm("Enable Heartbeat? (agent runs periodic self-maintenance tasks)")

        # ── Agents ───────────────────────────────────────────────────────────
        elif choice.startswith("Agents"):
            _agents_menu()

        # ── Channels ─────────────────────────────────────────────────────────
        elif choice.startswith("Channels"):
            channels = configure_channel(channels)

        # ── Save & Exit ──────────────────────────────────────────────────────
        elif choice.startswith("Save"):
            if not llm_provider_key:
                console.print("│")
                console.print("│  [red]LLM is required.[/red] Please configure it before saving.")
                continue
            break

    # --- Build and save config ---
    providers = ProvidersConfig()
    for prov, key in api_keys_dict.items():
        if hasattr(providers, prov):
            setattr(providers, prov, ProviderConfig(api_key=key))

    agent_list = []
    for a in agent_defs:
        defn_kwargs: dict = {"id": a["id"]}
        if a["llm_provider_key"] and a["llm_model"]:
            defn_kwargs["llm_config"] = LLMConfig(provider=a["llm_provider_key"], model=a["llm_model"])
        if a["use_computer"] is not None:
            defn_kwargs["use_computer"] = a["use_computer"]
        agent_list.append(AgentDefinition(**defn_kwargs))

    config_obj = Config(
        heartbeat_enabled=heartbeat_enabled,
        agents=AgentsConfig(
            defaults=AgentDefaults(
                llm_config=LLMConfig(provider=llm_provider_key, model=llm_model),
                use_computer=False,
            ),
            list=agent_list,
        ),
        stt=STTConfig(enabled=stt_enabled, provider=stt_provider_key or None, model=stt_model or None),
        tts=TTSConfig(enabled=tts_enabled, provider=tts_provider_key or None, model=tts_model or None, voice=tts_voice),
        providers=providers,
        channels=channels,
    )

    operator_use_dir = get_userdata_dir()
    operator_use_dir.mkdir(parents=True, exist_ok=True)
    config_path = operator_use_dir / "config.json"
    with open(config_path, "w", encoding="utf-8") as f:
        json.dump(config_obj.model_dump(by_alias=True, exclude_none=True), f, indent=4, ensure_ascii=False)

    # Write new API keys to .env
    key_to_env = {
        "groq":        "GROQ_API_KEY",
        "openai":      "OPENAI_API_KEY",
        "anthropic":   "ANTHROPIC_API_KEY",
        "google":      "GEMINI_API_KEY",
        "nvidia":      "NVIDIA_API_KEY",
        "deepseek":    "DEEPSEEK_API_KEY",
        "cerebras":    "CEREBRAS_API_KEY",
        "open_router": "OPENROUTER_API_KEY",
        "elevenlabs":  "ELEVENLABS_API_KEY",
        "deepgram":    "DEEPGRAM_API_KEY",
        "mistral":     "MISTRAL_API_KEY",
        "azure_openai":"AZURE_OPENAI_API_KEY",
        "sarvam":      "SARVAM_API_KEY",
    }
    env_vars = {key_to_env[k]: v for k, v in api_keys_dict.items() if k in key_to_env}
    if env_vars:
        with open(".env", "a") as f:
            f.write("\n")
            for k, v in env_vars.items():
                f.write(f"{k}={v}\n")

    print_end()


if __name__ == "__main__":
    run_initial_setup()
