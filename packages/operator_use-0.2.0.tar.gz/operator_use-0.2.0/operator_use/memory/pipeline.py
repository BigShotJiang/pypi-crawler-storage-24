"""Memory pipeline: slice → reflect → distill.

Three-stage pipeline triggered after each agent response:
  Stage 1 (slice)   — copies new messages from sessions/<id>.jsonl
                       into memory/YYYY-MM-DD/<id>.jsonl
  Stage 2 (reflect) — LLM reads today's slice, writes structured summary.md
  Stage 3 (distill) — runs on day rollover: LLM reads recent summaries,
                       promotes important items into MEMORY.md

Stages 2 and 3 run as background tasks and never block the main response.
All file I/O is handled in Python — no tool calls needed, minimal token usage.
"""

import asyncio
import json
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Awaitable, Callable

logger = logging.getLogger(__name__)

# Bare LLM callable: prompt → response text
RunLLM = Callable[[str], Awaitable[str]]

# Max messages to include in reflect prompt (oldest are dropped if exceeded)
MAX_REFLECT_MESSAGES = 60

REFLECT_PROMPT = """\
You are writing a daily memory summary. Return ONLY the summary content — no preamble, no explanation.

Today's conversation ({session_id}, {date}):

{conversation}

{existing_instruction}

Return the complete summary using EXACTLY this structure:

# {date}

## What Happened
[1-3 sentence narrative of what was discussed or done today]

## What I Learned
[new knowledge, insights, facts discovered — bullet points, or "None"]

## Failures & Blockers
[things that didn't work, errors, misunderstandings — or "None"]

## How to Overcome
[solutions found, workarounds, what to try next time — or "N/A"]

## Key Decisions
[important choices made today — or "None"]

## To Promote to MEMORY.md
- [ ] [item worth keeping long-term — one per line, or remove this section if nothing]
"""

DISTILL_PROMPT = """\
You are updating a long-term memory file. Return ONLY the updated MEMORY.md content — no preamble, no explanation.

Recent daily summaries:

{summaries}

Current MEMORY.md:

{memory_content}

Instructions:
- Add important facts, decisions, and lessons from the summaries above
- Remove entries that are clearly outdated or no longer relevant
- Keep it concise — this file loads every session, so every line has a cost
- Preserve the existing structure and headings

Return the complete updated MEMORY.md content:
"""


class MemoryPipeline:
    """Manages the slice → reflect → distill memory pipeline for one agent workspace."""

    def __init__(self, workspace: Path, run_llm: RunLLM) -> None:
        self.workspace    = Path(workspace)
        self.memory_dir   = self.workspace / "memory"
        self.sessions_dir = self.workspace / "sessions"
        self._state_file  = self.memory_dir / ".pipeline-state.json"
        self.run_llm      = run_llm
        self._lock        = asyncio.Lock()

    # ------------------------------------------------------------------
    # Public entry point
    # ------------------------------------------------------------------

    async def on_message_processed(self, session_id: str) -> None:
        """Called after each agent response. Must be fire-and-forget."""
        async with self._lock:
            try:
                await self._run(session_id)
            except Exception as e:
                logger.warning(f"[MemoryPipeline] error: {e}", exc_info=True)

    # ------------------------------------------------------------------
    # Internal orchestration
    # ------------------------------------------------------------------

    async def _run(self, session_id: str) -> None:
        state = self._load_state()
        today     = self._today()
        last_date = state.get("last_date", today)

        # Stage 3: day rolled over — distill previous day in background
        if last_date != today:
            asyncio.create_task(self._stage3_distill(last_date))

        # Stage 1: slice new messages into memory/YYYY-MM-DD/
        new_count = self._stage1_slice(session_id, today, state)

        # Stage 2: reflect in background if there's new content
        if new_count > 0:
            safe_id = self._safe_id(session_id)
            asyncio.create_task(self._stage2_reflect(safe_id, today))

        state["last_date"] = today
        self._save_state(state)

    # ------------------------------------------------------------------
    # Stage 1 — Slice  (sync, fast, no LLM)
    # ------------------------------------------------------------------

    def _stage1_slice(self, session_id: str, today: str, state: dict) -> int:
        """Copy new message lines from sessions/ into memory/YYYY-MM-DD/.
        Returns the number of new message lines written."""
        safe_id      = self._safe_id(session_id)
        session_path = self.sessions_dir / f"{safe_id}.jsonl"
        if not session_path.exists():
            return 0

        sessions_state = state.setdefault("sessions", {})
        session_state  = sessions_state.setdefault(safe_id, {})
        last_line      = session_state.get("last_line", 0)

        with open(session_path, encoding="utf-8") as f:
            all_lines = f.readlines()

        new_lines = all_lines[last_line:]
        # Only message lines (have a "role" key), skip metadata
        message_lines = [l for l in new_lines if '"role"' in l]

        session_state["last_line"] = len(all_lines)

        if not message_lines:
            return 0

        day_dir    = self.memory_dir / today
        day_dir.mkdir(parents=True, exist_ok=True)
        slice_path = day_dir / f"{safe_id}.jsonl"

        with open(slice_path, "a", encoding="utf-8") as f:
            for line in message_lines:
                f.write(line if line.endswith("\n") else line + "\n")

        logger.debug(f"[MemoryPipeline] sliced {len(message_lines)} lines → {slice_path}")
        return len(message_lines)

    # ------------------------------------------------------------------
    # Stage 2 — Reflect  (async, bare LLM call, writes summary.md)
    # ------------------------------------------------------------------

    async def _stage2_reflect(self, safe_id: str, today: str) -> None:
        slice_path   = self.memory_dir / today / f"{safe_id}.jsonl"
        summary_path = self.memory_dir / today / "summary.md"
        if not slice_path.exists():
            return

        # Build conversation transcript from slice
        messages = self._parse_slice(slice_path)
        if not messages:
            return

        # Cap to avoid context overflow
        if len(messages) > MAX_REFLECT_MESSAGES:
            messages = messages[-MAX_REFLECT_MESSAGES:]

        conversation = "\n".join(
            f"{'User' if m['role'] == 'human' else 'Assistant'}: {m['content'][:500]}"
            for m in messages
        )

        # Merge instruction if summary already exists
        if summary_path.exists():
            existing = summary_path.read_text(encoding="utf-8")
            existing_instruction = (
                f"An earlier summary exists — merge new content into each section:\n\n"
                f"{existing}\n\n---\nNow merge the new conversation above into the summary."
            )
        else:
            existing_instruction = ""

        prompt = REFLECT_PROMPT.format(
            session_id=safe_id,
            date=today,
            conversation=conversation,
            existing_instruction=existing_instruction,
        )

        try:
            result = await self.run_llm(prompt)
            summary_path.parent.mkdir(parents=True, exist_ok=True)
            summary_path.write_text(result.strip(), encoding="utf-8")
            logger.debug(f"[MemoryPipeline] Stage 2 reflect done for {today}")
        except Exception as e:
            logger.warning(f"[MemoryPipeline] Stage 2 reflect failed: {e}")

    # ------------------------------------------------------------------
    # Stage 3 — Distill  (async, bare LLM call, writes MEMORY.md)
    # ------------------------------------------------------------------

    async def _stage3_distill(self, last_date: str) -> None:
        sections: list[tuple[str, Path]] = []
        for date in self._recent_dates(last_date, days=7):
            p = self.memory_dir / date / "summary.md"
            if p.exists():
                sections.append((date, p))

        if not sections:
            return

        summaries_text = "\n\n---\n\n".join(
            f"### {date}\n\n{p.read_text(encoding='utf-8')}"
            for date, p in sections
        )

        memory_path = self.memory_dir / "MEMORY.md"
        current_memory = memory_path.read_text(encoding="utf-8") if memory_path.exists() else "(empty)"

        prompt = DISTILL_PROMPT.format(
            summaries=summaries_text,
            memory_content=current_memory,
        )

        try:
            result = await self.run_llm(prompt)
            memory_path.parent.mkdir(parents=True, exist_ok=True)
            memory_path.write_text(result.strip(), encoding="utf-8")
            # Mark all promoted checklist items as [x] in summary files
            for _date, p in sections:
                text = p.read_text(encoding="utf-8")
                updated = text.replace("- [ ] ", "- [x] ")
                if updated != text:
                    p.write_text(updated, encoding="utf-8")
            logger.debug(f"[MemoryPipeline] Stage 3 distill done (up to {last_date})")
        except Exception as e:
            logger.warning(f"[MemoryPipeline] Stage 3 distill failed: {e}")

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _parse_slice(self, slice_path: Path) -> list[dict]:
        """Parse JSONL slice into list of {role, content} dicts."""
        messages = []
        for line in slice_path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
                if "role" in obj and "content" in obj:
                    messages.append({"role": obj["role"], "content": str(obj["content"] or "")})
            except json.JSONDecodeError:
                pass
        return messages

    def _today(self) -> str:
        return datetime.now().strftime("%Y-%m-%d")

    def _safe_id(self, session_id: str) -> str:
        return session_id.replace(":", "_")

    def _recent_dates(self, up_to: str, days: int) -> list[str]:
        base = datetime.strptime(up_to, "%Y-%m-%d")
        return [(base - timedelta(days=i)).strftime("%Y-%m-%d") for i in range(days)]

    def _load_state(self) -> dict:
        if self._state_file.exists():
            try:
                return json.loads(self._state_file.read_text(encoding="utf-8"))
            except Exception:
                return {}
        return {}

    def _save_state(self, state: dict) -> None:
        self.memory_dir.mkdir(parents=True, exist_ok=True)
        self._state_file.write_text(
            json.dumps(state, indent=2, ensure_ascii=False), encoding="utf-8"
        )
