"""Agent service: LLM loop + tool execution.

The Agent no longer owns the bus consume loop, STT/TTS, or message building.
Those responsibilities belong to the Orchestrator. The Agent receives an
already-built HumanMessage/ImageMessage via run() and returns an AIMessage.
"""

import asyncio
import logging
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Callable, Awaitable

from operator_use.messages import AIMessage, HumanMessage, ImageMessage, ToolMessage
from operator_use.agent.tools import ToolRegistry, BUILTIN_TOOLS
from operator_use.bus import IncomingMessage
from operator_use.providers.events import LLMEventType, LLMStreamEventType
from operator_use.agent.computer_use import Desktop, WatchDog
from operator_use.session import SessionStore, Session
from operator_use.agent.context import Context
from operator_use.subagent import SubagentStore
from operator_use.process import ProcessStore
from operator_use.hooks import Hooks, HookEvent
from operator_use.hooks.events import (
    BeforeAgentStartContext,
    AfterAgentStartContext,
    BeforeAgentEndContext,
    AfterAgentEndContext,
    BeforeToolCallContext,
    AfterToolCallContext,
)

if TYPE_CHECKING:
    from operator_use.providers.base import BaseChatLLM
    from operator_use.crons.service import Cron

logger = logging.getLogger(__name__)


class Agent:
    """Runs the LLM agentic loop for a single workspace/persona.

    Receives pre-built HumanMessage/ImageMessage from the Orchestrator via
    run() and returns an AIMessage. Has no knowledge of channels, STT, TTS,
    or bus consumption — those are Orchestrator concerns.
    """

    def __init__(
        self,
        llm: "BaseChatLLM",
        workspace: Path | None = None,
        sessions: SessionStore | None = None,
        max_iterations: int = 100,
        userdata_dir: Path | None = None,
        use_computer: bool = False,
        cron: "Cron | None" = None,
        gateway=None,
        bus=None,
        exclude_tools: list | None = None,
        acp_registry: dict | None = None,
    ):
        if workspace is None:
            from operator_use.paths import get_userdata_dir, get_named_workspace_dir
            workspace = get_named_workspace_dir("default")
        self.workspace = workspace
        self.sessions = sessions or SessionStore(workspace=self.workspace)
        self.context = Context(workspace=self.workspace)
        self.use_computer = use_computer
        self.tool_register = ToolRegistry()
        self.max_iterations = max_iterations
        self.llm = llm
        self.cron = cron
        self.gateway = gateway
        self.bus = bus
        self.subagent_store = SubagentStore(llm=llm, bus=bus)
        self.process_store = ProcessStore()
        self.hooks = Hooks()

        self.desktop = None
        if Desktop and use_computer:
            try:
                self.desktop = Desktop(use_accessibility=True, use_vision=False)
            except Exception as e:
                logger.warning(f"Desktop init failed, computer use disabled: {e}")

        self.tool_register.register_tools(BUILTIN_TOOLS)
        if exclude_tools:
            self.tool_register.unregister_tools(exclude_tools)
        if use_computer:
            try:
                from operator_use.agent.tools.computer_use import COMPUTER_USE_TOOLS
                self.tool_register.register_tools(COMPUTER_USE_TOOLS)
            except Exception as e:
                logger.warning(f"Computer-use tools unavailable: {e}")

        # Set stable tool extensions (don't change per message)
        self.tool_register.set_extension("_workspace", self.workspace)
        self.tool_register.set_extension("_bus", self.bus)
        self.tool_register.set_extension("_gateway", self.gateway)
        self.tool_register.set_extension("_cron", self.cron)
        self.tool_register.set_extension("_subagent_store", self.subagent_store)
        self.tool_register.set_extension("_process_store", self.process_store)
        self.tool_register.set_extension("_acp_registry", acp_registry or {})
        self.tool_register.set_extension("_llm", self.llm)

        logger.debug(f"Registered tools: {[t.name for t in self.tool_register.list_tools()]}")

    # ------------------------------------------------------------------
    # Public entry point
    # ------------------------------------------------------------------

    async def run(
        self,
        message: "HumanMessage | ImageMessage",
        session_id: str,
        incoming: "IncomingMessage | None" = None,
        publish_stream: "Callable[..., Awaitable[None]] | None" = None,
        pending_replies: "dict | None" = None,
    ) -> AIMessage:
        """Run the agentic loop for one message and return the AIMessage response.

        Args:
            message: Pre-built HumanMessage or ImageMessage (STT already applied).
            session_id: Unique session identifier (e.g. "telegram:12345").
            incoming: Original IncomingMessage for per-message tool extensions.
            publish_stream: Callback for streaming chunks. If None, non-streaming.
            pending_replies: Shared dict for tools that wait for a user reply.
        """
        # Set per-message tool extensions
        if incoming:
            self.tool_register.set_extension("_channel", incoming.channel)
            self.tool_register.set_extension("_chat_id", incoming.chat_id)
            self.tool_register.set_extension("_metadata", incoming.metadata or {})
            self.tool_register.set_extension("_session_id", session_id)
        if pending_replies is not None:
            self.tool_register.set_extension("_pending_replies", pending_replies)

        session = self.sessions.get_or_create(session_id=session_id)
        session.add_message(message)

        await self.hooks.emit(
            HookEvent.BEFORE_AGENT_START,
            BeforeAgentStartContext(message=incoming, session=session),
        )

        if publish_stream is not None:
            response_message = await self._loop_stream(
                session=session, publish_stream=publish_stream, message=incoming
            )
        else:
            response_message = await self._loop(session=session, message=incoming)

        # Allow hooks to modify the final response before saving
        end_ctx = await self.hooks.emit(
            HookEvent.BEFORE_AGENT_END,
            BeforeAgentEndContext(message=incoming, session=session, response=response_message),
        )
        response_message = end_ctx.response

        self.sessions.save(session)

        await self.hooks.emit(
            HookEvent.AFTER_AGENT_END,
            AfterAgentEndContext(message=incoming, session=session, response=response_message),
        )

        return response_message

    # ------------------------------------------------------------------
    # Reaction handling (no LLM call — update metadata only)
    # ------------------------------------------------------------------

    async def _handle_reaction(self, message: IncomingMessage) -> None:
        """Add or remove a user reaction on the target AIMessage in the session."""
        session_id = f"{message.channel}:{message.chat_id}"
        bot_message_id = message.metadata.get("_reaction_bot_message_id")
        emojis = message.metadata.get("_reaction_emojis", [])
        removed_emojis = message.metadata.get("_reaction_removed_emojis", [])
        user_id = message.metadata.get("user_id")

        session = self.sessions.get_or_create(session_id=session_id)
        for msg in reversed(session.messages):
            if isinstance(msg, AIMessage) and msg.metadata.get("message_id") == bot_message_id:
                if not isinstance(msg.metadata, dict):
                    msg.metadata = {}
                reactions: list = msg.metadata.setdefault("reactions", [])

                if removed_emojis:
                    removed_set = set(removed_emojis)
                    msg.metadata["reactions"] = [
                        r for r in reactions
                        if not (r.get("user_id") == user_id and set(r.get("emojis", [])) & removed_set)
                    ]
                    logger.info("Removed reaction %s from bot message %s", removed_emojis, bot_message_id)

                if emojis:
                    msg.metadata["reactions"].append({
                        "emojis": emojis,
                        "user_id": user_id,
                        "timestamp": datetime.now().isoformat(),
                    })
                    logger.info("Stored reaction %s on bot message %s", emojis, bot_message_id)
                break
        self.sessions.save(session)

    # ------------------------------------------------------------------
    # LLM loops
    # ------------------------------------------------------------------

    async def _prepare_messages(
        self,
        session: Session,
        message: "IncomingMessage | None",
    ) -> list:
        """Build the LLM message list: system prompt + history + optional desktop state."""
        is_voice = (
            any(
                type(p).__name__ == "AudioPart"
                for p in (message.parts or [])
            )
            if message
            else False
        )
        messages = self.context.build_messages(history=session.get_history(), is_voice=is_voice)
        if self.use_computer and self.desktop:
            try:
                loop = asyncio.get_event_loop()
                desktop_state = await loop.run_in_executor(None, self.desktop.get_state)
                desktop_content = desktop_state.to_string()
                if self.desktop.use_vision and desktop_state.screenshot:
                    messages.append(ImageMessage(images=[desktop_state.screenshot], content=desktop_content))
                else:
                    messages.append(HumanMessage(content=desktop_content))
            except Exception as e:
                logger.warning(f"Desktop state capture failed: {e}")
        return messages

    async def _execute_tool(self, tool_call, thinking, thinking_signature, session: Session):
        """Execute a tool call and append a ToolMessage to the session."""
        logger.debug(f"Tool call | name={tool_call.name} params={tool_call.params}")

        pre_ctx = await self.hooks.emit(
            HookEvent.BEFORE_TOOL_CALL,
            BeforeToolCallContext(session=session, tool_call=tool_call),
        )
        if pre_ctx.skip:
            tool_result = pre_ctx.result
            content = tool_result.output if tool_result.success else tool_result.error
        else:
            tool_result = await self.tool_register.aexecute(tool_call.name, tool_call.params)
            content = tool_result.output if tool_result.success else tool_result.error

        if tool_result.success:
            logger.debug(f"Tool success | {str(content)[:200]}")
        else:
            logger.warning(f"Tool error | {str(content)[:200]}")

        await self.hooks.emit(
            HookEvent.AFTER_TOOL_CALL,
            AfterToolCallContext(session=session, tool_call=tool_call, tool_result=tool_result, content=content),
        )

        session.add_message(ToolMessage(
            id=tool_call.id,
            name=tool_call.name,
            params=tool_call.params,
            content=content,
            thinking=thinking,
            thinking_signature=thinking_signature,
        ))
        return tool_result, content

    @staticmethod
    def _clean_content(content: str) -> str:
        """Strip <think> blocks, leading message IDs, and control tags from LLM output."""
        import re
        content = re.sub(r'<think>.*?</think>\s*', '', content, flags=re.DOTALL)
        content = re.sub(r'^\[(bot_)?msg_id:\d+\]\s*', '', content)
        content = re.sub(r'<ctrl\d+>', '', content)
        return content.strip() or "(no response)"

    async def _loop(
        self,
        session: Session,
        message: "IncomingMessage | None" = None,
    ) -> AIMessage:
        """Non-streaming agentic loop."""
        tools = self.tool_register.list_tools()
        for iteration in range(self.max_iterations):
            messages = await self._prepare_messages(session, message)
            logger.info(f"LLM call | model={self.llm.model_name} messages={len(messages)} tools={len(tools)}")
            if iteration == 0 and message:
                await self.hooks.emit(
                    HookEvent.AFTER_AGENT_START,
                    AfterAgentStartContext(message=message, session=session, iteration=iteration),
                )
            llm_event = await self.llm.ainvoke(messages=messages, tools=tools)
            logger.info(f"LLM response | {llm_event.type.name}")
            thinking, thinking_signature = (
                (llm_event.thinking.content, llm_event.thinking.signature)
                if llm_event.thinking else (None, None)
            )
            match llm_event.type:
                case LLMEventType.TOOL_CALL:
                    tool_result, content = await self._execute_tool(
                        llm_event.tool_call, thinking, thinking_signature, session
                    )
                    if tool_result.metadata and tool_result.metadata.get("stop_loop"):
                        return AIMessage(content=content or "")
                case LLMEventType.TEXT:
                    clean = self._clean_content(llm_event.content or "")
                    logger.info(f"Response | {clean[:120]!r}{'...' if len(clean) > 120 else ''}")
                    msg = AIMessage(content=clean, thinking=thinking, thinking_signature=thinking_signature)
                    session.add_message(msg)
                    return msg
        raise RuntimeError(f"Agent exceeded max_iterations ({self.max_iterations})")

    async def _loop_stream(
        self,
        session: Session,
        publish_stream: "Callable[..., Awaitable[None]]",
        message: "IncomingMessage | None" = None,
    ) -> AIMessage:
        """Streaming agentic loop."""
        tools = self.tool_register.list_tools()
        for iteration in range(self.max_iterations):
            messages = await self._prepare_messages(session, message)
            thinking = None
            thinking_signature = None
            content = ""
            last_publish_len = 0
            stream_init_sent = False
            chunk_size = 15

            if iteration == 0 and message:
                await self.hooks.emit(
                    HookEvent.AFTER_AGENT_START,
                    AfterAgentStartContext(message=message, session=session, iteration=iteration),
                )

            async for event in self.llm.astream(messages=messages, tools=tools):
                if event.thinking:
                    thinking = event.thinking.content
                    thinking_signature = event.thinking.signature

                match event.type:
                    case LLMStreamEventType.TEXT_START:
                        pass
                    case LLMStreamEventType.TOOL_CALL:
                        tool_result, content = await self._execute_tool(
                            event.tool_call, thinking, thinking_signature, session
                        )
                        if tool_result.metadata and tool_result.metadata.get("stop_loop"):
                            return AIMessage(content=content or "")
                        break
                    case LLMStreamEventType.TEXT_DELTA:
                        if event.content:
                            content += event.content
                            if len(content) - last_publish_len >= chunk_size:
                                await publish_stream(content, False, init=not stream_init_sent)
                                stream_init_sent = True
                                last_publish_len = len(content)
                    case LLMStreamEventType.TEXT_END:
                        logger.info(
                            f"Response | {content[:120]!r}{'...' if len(content) > 120 else ''} usage={event.usage}"
                        )
                        content = self._clean_content(content or "(no response)")
                        await publish_stream(content, True, init=not stream_init_sent)
                        msg = AIMessage(content=content, thinking=thinking, thinking_signature=thinking_signature)
                        session.add_message(msg)
                        return msg
        raise RuntimeError(f"Agent exceeded max_iterations ({self.max_iterations})")
