"""Pydantic configuration models for steerdev."""

from pathlib import Path
from typing import Annotated

import yaml
from pydantic import BaseModel, Field

from steerdev_agent.api.client import DEFAULT_API_ENDPOINT


class WorktreeConfig(BaseModel):
    """Git worktree isolation configuration.

    When enabled, the Claude CLI --worktree flag is used to run each task
    in an isolated git worktree. Worktree lifecycle is managed by Claude CLI.
    """

    enabled: Annotated[
        bool,
        Field(default=False, description="Enable Claude CLI --worktree isolation per task"),
    ]


class AgentConfig(BaseModel):
    """Configuration for the CLI coding agent."""

    model: Annotated[
        str | None,
        Field(
            default=None,
            description="Model to use (e.g., claude-sonnet-4-20250514)",
        ),
    ]
    max_turns: Annotated[
        int | None,
        Field(
            default=None,
            description="Maximum number of agent turns",
        ),
    ]
    timeout_seconds: Annotated[
        int,
        Field(default=3600, ge=60, description="Maximum execution time in seconds"),
    ]
    workflow_id: Annotated[
        str | None,
        Field(
            default=None,
            description="Workflow ID for multi-phase task execution",
        ),
    ]


class ExecutorConfig(BaseModel):
    """Configuration for the agent executor."""

    type: Annotated[
        str,
        Field(
            default="claude",
            description="Executor type (claude, codex, aider)",
        ),
    ]
    permission_mode: Annotated[
        str,
        Field(
            default="dangerously-skip-permissions",
            description="Permission mode for the executor",
        ),
    ]
    allowed_tools: Annotated[
        list[str],
        Field(
            default_factory=list,
            description="List of tools to allow (empty = all allowed)",
        ),
    ]
    disallowed_tools: Annotated[
        list[str],
        Field(
            default_factory=list,
            description="List of tools to disallow",
        ),
    ]
    mcp_config: Annotated[
        str | None,
        Field(
            default=None,
            description="Path to MCP config file",
        ),
    ]


class APIConfig(BaseModel):
    """Configuration for steerdev.com API."""

    api_endpoint: Annotated[
        str,
        Field(
            default=DEFAULT_API_ENDPOINT,
            description="API endpoint for steerdev.com",
        ),
    ]
    api_key_env: Annotated[
        str,
        Field(
            default="STEERDEV_API_KEY",
            description="Environment variable name for API key",
        ),
    ]
    project_id_env: Annotated[
        str,
        Field(
            default="STEERDEV_PROJECT_ID",
            description="Environment variable name for project ID",
        ),
    ]


class EventsConfig(BaseModel):
    """Configuration for event streaming to API."""

    batch_size: Annotated[
        int,
        Field(default=10, ge=1, le=100, description="Number of events to batch before sending"),
    ]
    flush_interval_seconds: Annotated[
        float,
        Field(default=5.0, ge=1.0, description="Maximum seconds between flushes"),
    ]


class AgentLoopConfig(BaseModel):
    """Configuration for agent loop (persistent agent) mode.

    When running in agent mode, the agent polls for commands from the API.
    """

    poll_interval_seconds: Annotated[
        float,
        Field(default=5.0, ge=1.0, description="Seconds between command queue polls when busy"),
    ]
    heartbeat_interval_seconds: Annotated[
        float,
        Field(default=30.0, ge=10.0, description="Seconds between heartbeat updates"),
    ]
    idle_poll_interval_seconds: Annotated[
        float,
        Field(default=10.0, ge=1.0, description="Seconds between polls when idle (no commands)"),
    ]
    max_consecutive_errors: Annotated[
        int,
        Field(default=5, ge=1, description="Exit after this many consecutive errors"),
    ]
    command_timeout_seconds: Annotated[
        int,
        Field(default=3600, ge=60, description="Timeout for individual command execution"),
    ]
    gap_seconds: Annotated[
        float,
        Field(
            default=0.0,
            ge=0.0,
            description="Delay in seconds between finishing one command and polling for the next",
        ),
    ]


class WorkspaceConfig(BaseModel):
    """Workspace agent configuration.

    When running in workspace mode, a single agent manages multiple projects.
    Projects are assigned via the platform and auto-cloned locally.
    """

    workspace_dir: Annotated[
        Path | None,
        Field(default=None, description="Root directory for workspace projects"),
    ]
    auto_clone: Annotated[
        bool,
        Field(default=True, description="Automatically clone repos for assigned projects"),
    ]
    project_refresh_interval: Annotated[
        int,
        Field(default=300, ge=30, description="Seconds between project assignment refresh"),
    ]
    max_concurrent_tasks: Annotated[
        int,
        Field(default=1, ge=1, le=10, description="Maximum concurrent task executions"),
    ]


class CanalConfig(BaseModel):
    """Canal workflow configuration.

    When enabled, agents merge feature branches to canal integration branches
    instead of directly to dev. Canals batch related PRs for consolidated review.
    """

    enabled: Annotated[
        bool,
        Field(default=False, description="Enable canal-based verification workflow"),
    ]
    base_branch: Annotated[
        str,
        Field(default="dev", description="Default base branch for canals"),
    ]


class RetryConfig(BaseModel):
    """Retry configuration for failed task/session execution."""

    enabled: Annotated[
        bool,
        Field(default=False, description="Enable automatic retry on task failure"),
    ]
    max_retries: Annotated[
        int,
        Field(default=3, ge=0, le=10, description="Maximum number of retry attempts"),
    ]
    delay_seconds: Annotated[
        float,
        Field(
            default=3600.0, ge=0.0, description="Delay between retries in seconds (default 1 hour)"
        ),
    ]
    backoff_multiplier: Annotated[
        float,
        Field(
            default=1.0,
            ge=1.0,
            le=10.0,
            description="Backoff multiplier (1.0 = constant delay, >1.0 = exponential)",
        ),
    ]
    max_delay_seconds: Annotated[
        float,
        Field(default=7200.0, ge=0.0, description="Maximum delay between retries in seconds"),
    ]


class SteerDevConfig(BaseModel):
    """Main configuration for steerdev.

    This config focuses on:
    - Agent runtime settings (timeout, model)
    - API connection settings
    - Event streaming settings
    - Executor settings
    - Agent loop mode settings
    - Canal workflow settings
    """

    agent: Annotated[
        AgentConfig,
        Field(default_factory=AgentConfig, description="Agent configuration"),
    ]
    api: Annotated[
        APIConfig,
        Field(default_factory=APIConfig, description="API configuration"),
    ]
    events: Annotated[
        EventsConfig,
        Field(default_factory=EventsConfig, description="Event streaming configuration"),
    ]
    executor: Annotated[
        ExecutorConfig,
        Field(default_factory=ExecutorConfig, description="Executor configuration"),
    ]
    worktrees: Annotated[
        WorktreeConfig,
        Field(default_factory=WorktreeConfig, description="Git worktree isolation configuration"),
    ]
    agent_loop: Annotated[
        AgentLoopConfig,
        Field(
            default_factory=AgentLoopConfig,
            description="Agent loop (persistent agent) mode configuration",
        ),
    ]
    canal: Annotated[
        CanalConfig,
        Field(default_factory=CanalConfig, description="Canal workflow configuration"),
    ]
    workspace: Annotated[
        WorkspaceConfig,
        Field(default_factory=WorkspaceConfig, description="Workspace agent configuration"),
    ]
    retry: Annotated[
        RetryConfig,
        Field(default_factory=RetryConfig, description="Retry configuration for failed tasks"),
    ]

    @classmethod
    def from_yaml(cls, path: str | Path) -> "SteerDevConfig":
        """Load configuration from a YAML file.

        Args:
            path: Path to the YAML configuration file.

        Returns:
            Parsed SteerDevConfig instance.

        Raises:
            FileNotFoundError: If the file doesn't exist.
            yaml.YAMLError: If the YAML is invalid.
            ValidationError: If the configuration is invalid.
        """
        path = Path(path)
        with path.open() as f:
            data = yaml.safe_load(f)
        return cls.model_validate(data or {})

    def to_yaml(self, path: str | Path) -> None:
        """Save configuration to a YAML file.

        Args:
            path: Path to save the YAML configuration file.
        """
        path = Path(path)
        with path.open("w") as f:
            yaml.safe_dump(
                self.model_dump(mode="json"),
                f,
                default_flow_style=False,
                sort_keys=False,
            )
