import argparse
import os
from typing import Any
from unittest.mock import patch

import pytest

from tiny_object_storage.cli import build_parser, main, str_to_bool


def test_str_to_bool() -> None:
    assert str_to_bool("1") is True
    assert str_to_bool("true") is True
    assert str_to_bool("yes") is True
    assert str_to_bool("y") is True
    assert str_to_bool("on") is True

    assert str_to_bool("0") is False
    assert str_to_bool("false") is False
    assert str_to_bool("no") is False
    assert str_to_bool("n") is False
    assert str_to_bool("off") is False

    with pytest.raises(argparse.ArgumentTypeError):
        str_to_bool("invalid")


def test_build_parser() -> None:
    parser = build_parser()
    args = parser.parse_args(["--port", "8080", "--host", "127.0.0.1", "--dev-mode", "true"])
    assert args.port == 8080
    assert args.host == "127.0.0.1"
    assert args.dev_mode is True


@patch("tiny_object_storage.cli.uvicorn.run")
def test_main_cli(mock_uvicorn_run: Any) -> None:
    # Test that the main CLI entrypoint correctly parses args and calls uvicorn.run
    test_args = [
        "tos-server",
        "--host",
        "0.0.0.0",
        "--port",
        "9000",
        "--dev-mode",
        "false",
        "--max-object-size",
        "1024",
        "--log-level",
        "debug",
        "--reload",
        "--data-dir",
        "/tmp/data",
        "--log-dir",
        "/tmp/logs",
    ]
    with patch("sys.argv", test_args):
        main()

    # Verify environments were set
    assert os.environ.get("TOS_HOST") == "0.0.0.0"
    assert os.environ.get("TOS_PORT") == "9000"
    assert os.environ.get("TOS_LOG_LEVEL") == "DEBUG"
    assert os.environ.get("TOS_MAX_OBJECT_SIZE") == "1024"
    assert os.environ.get("TOS_DATA_DIR") == "/tmp/data"
    assert os.environ.get("TOS_LOG_DIR") == "/tmp/logs"

    # Verify uvicorn run was called
    assert mock_uvicorn_run.called


@patch("tiny_object_storage.cli.uvicorn.run")
def test_main_cli_no_reload(mock_uvicorn_run: Any) -> None:
    test_args = ["tos-server", "--no-reload"]
    with patch("sys.argv", test_args):
        main()

    # Check that reload was disabled
    args, kwargs = mock_uvicorn_run.call_args
    assert kwargs.get("reload") is False
