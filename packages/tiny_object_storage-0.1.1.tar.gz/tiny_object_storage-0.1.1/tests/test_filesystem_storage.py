from pathlib import Path

import pytest

from tiny_object_storage.config import get_settings
from tiny_object_storage.core.errors import (
    BucketAlreadyExistsError,
    BucketNotEmptyError,
    BucketNotFoundError,
    InvalidBucketNameError,
    InvalidObjectKeyError,
    ObjectNotFoundError,
)
from tiny_object_storage.logging_config import configure_logging
from tiny_object_storage.storage.filesystem import FilesystemStorage


@pytest.fixture
def storage(tmp_path: Path) -> FilesystemStorage:
    # Create a filesystem storage instance backed by a temporary directory.
    log_dir = tmp_path / "logs"
    configure_logging(log_dir=log_dir, log_level="DEBUG")
    return FilesystemStorage(base_dir=tmp_path / "storage")


def test_create_bucket(storage: FilesystemStorage) -> None:
    # Verify bucket creation and listing.
    storage.create_bucket("photos")

    assert storage.bucket_exists("photos") is True
    buckets = storage.list_buckets()
    assert len(buckets) == 1
    assert buckets[0]["name"] == "photos"


def test_create_existing_bucket_raises(storage: FilesystemStorage) -> None:
    # Verify duplicate bucket creation fails.
    storage.create_bucket("photos")

    with pytest.raises(BucketAlreadyExistsError):
        storage.create_bucket("photos")


def test_invalid_bucket_name_raises(storage: FilesystemStorage) -> None:
    # Verify bucket name validation is enforced.
    with pytest.raises(InvalidBucketNameError):
        storage.create_bucket("INVALID_BUCKET")


def test_delete_non_empty_bucket_raises(storage: FilesystemStorage) -> None:
    # Verify non-empty buckets cannot be deleted.
    storage.create_bucket("photos")
    storage.put_object("photos", "cat.jpg", b"binary-data", content_type="image/jpeg")

    with pytest.raises(BucketNotEmptyError):
        storage.delete_bucket("photos")


def test_delete_empty_bucket(storage: FilesystemStorage) -> None:
    # Verify empty bucket deletion works.
    storage.create_bucket("photos")
    storage.delete_bucket("photos")

    assert storage.bucket_exists("photos") is False


def test_delete_missing_bucket_raises(storage: FilesystemStorage) -> None:
    # Verify deleting a missing bucket fails.
    with pytest.raises(BucketNotFoundError):
        storage.delete_bucket("missing-bucket")


def test_put_and_get_object(storage: FilesystemStorage) -> None:
    # Verify object write and read flow.
    storage.create_bucket("photos")

    metadata = storage.put_object("photos", "cat.jpg", b"hello-world", content_type="image/jpeg")
    stored = storage.get_object("photos", "cat.jpg")

    assert metadata["bucket_name"] == "photos"
    assert metadata["object_key"] == "cat.jpg"
    assert metadata["size"] == 11
    assert stored.data == b"hello-world"
    assert stored.metadata["content_type"] == "image/jpeg"


def test_put_nested_object_and_list(storage: FilesystemStorage) -> None:
    # Verify nested object keys are supported.
    storage.create_bucket("photos")
    storage.put_object("photos", "2026/trip/cat.jpg", b"nested-data", content_type="image/jpeg")

    objects = storage.list_objects("photos")

    assert len(objects) == 1
    assert objects[0]["object_key"] == "2026/trip/cat.jpg"


def test_put_object_missing_bucket_raises(storage: FilesystemStorage) -> None:
    # Verify writing to a missing bucket fails.
    with pytest.raises(BucketNotFoundError):
        storage.put_object("photos", "cat.jpg", b"hello")


def test_invalid_object_key_raises(storage: FilesystemStorage) -> None:
    # Verify object key validation is enforced.
    storage.create_bucket("photos")

    with pytest.raises(InvalidObjectKeyError):
        storage.put_object("photos", "../cat.jpg", b"hello")


def test_get_missing_object_raises(storage: FilesystemStorage) -> None:
    # Verify reading a missing object fails.
    storage.create_bucket("photos")

    with pytest.raises(ObjectNotFoundError):
        storage.get_object("photos", "missing.jpg")


def test_delete_object(storage: FilesystemStorage) -> None:
    # Verify object deletion removes data and metadata.
    storage.create_bucket("photos")
    storage.put_object("photos", "cat.jpg", b"hello-world")

    assert storage.object_exists("photos", "cat.jpg") is True

    storage.delete_object("photos", "cat.jpg")

    assert storage.object_exists("photos", "cat.jpg") is False
    with pytest.raises(ObjectNotFoundError):
        storage.get_object("photos", "cat.jpg")


def test_delete_missing_object_raises(storage: FilesystemStorage) -> None:
    # Verify deleting a missing object fails.
    storage.create_bucket("photos")

    with pytest.raises(ObjectNotFoundError):
        storage.delete_object("photos", "missing.jpg")


def test_metadata_file_is_created(storage: FilesystemStorage) -> None:
    # Verify metadata file is written for stored objects.
    storage.create_bucket("photos")
    storage.put_object("photos", "cat.jpg", b"hello-world", content_type="image/jpeg")

    metadata_path = storage.base_dir / "photos" / ".meta" / "cat.jpg.json"
    assert metadata_path.exists() is True


def test_app_settings_create_directories(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    # Verify settings create expected directories.
    monkeypatch.setenv("TOS_DATA_DIR", str(tmp_path / "data"))
    monkeypatch.setenv("TOS_LOG_DIR", str(tmp_path / "logs"))

    get_settings.cache_clear()
    settings = get_settings()

    assert settings.data_dir.exists() is True
    assert settings.log_dir.exists() is True

    get_settings.cache_clear()
