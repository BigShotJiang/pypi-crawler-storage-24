from fastapi.testclient import TestClient

from tiny_object_storage.main import app


def test_healthcheck_returns_ok() -> None:
    # Verify that the health endpoint returns a successful payload.
    with TestClient(app) as client:
        response = client.get("/health")

    assert response.status_code == 200
    payload = response.json()
    assert payload["status"] == "ok"
    assert payload["app_name"] == "tiny-object-storage"
