import pytest
from pydantic import ValidationError

from tiny_object_storage.models.bucket import BucketInfo
from tiny_object_storage.models.object_info import ObjectInfo


def test_bucket_info_model() -> None:
    bucket = BucketInfo(name="photos")
    assert bucket.name == "photos"
    assert bucket.created_at is None

    bucket2 = BucketInfo(name="docs", created_at="2026-03-09T14:11:41Z")
    assert bucket2.name == "docs"
    assert bucket2.created_at == "2026-03-09T14:11:41Z"

    with pytest.raises(ValidationError):
        BucketInfo()  # type: ignore[call-arg]


def test_object_info_model() -> None:
    obj = ObjectInfo(
        bucket_name="photos",
        object_key="cat.jpg",
        size=1024,
        content_type="image/jpeg",
        etag="abcd",
    )
    assert obj.bucket_name == "photos"
    assert obj.object_key == "cat.jpg"
    assert obj.size == 1024
    assert obj.content_type == "image/jpeg"
    assert obj.etag == "abcd"
    assert obj.created_at is None
    assert obj.updated_at is None

    with pytest.raises(ValidationError):
        ObjectInfo(bucket_name="photos")  # type: ignore[call-arg]
