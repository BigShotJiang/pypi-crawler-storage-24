from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from tiny_object_storage.config import get_settings
from tiny_object_storage.main import app


@pytest.fixture(autouse=True)
def isolate_storage(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    # Isolate storage to a temporary directory for each test
    monkeypatch.setenv("TOS_DATA_DIR", str(tmp_path / "data"))
    monkeypatch.setenv("TOS_LOG_DIR", str(tmp_path / "logs"))
    get_settings.cache_clear()


def test_list_buckets_returns_xml() -> None:
    # Verify the root listing endpoint returns S3-style XML.
    with TestClient(app) as client:
        response = client.get("/")

    assert response.status_code == 200
    assert response.headers["content-type"].startswith("application/xml")
    assert b"<ListAllMyBucketsResult" in response.content


def test_list_buckets_json_debug_endpoint() -> None:
    # Verify the debug bucket listing endpoint returns JSON.
    with TestClient(app) as client:
        response = client.get("/_debug/buckets")

    assert response.status_code == 200
    payload = response.json()
    assert "buckets" in payload


def test_create_bucket_endpoint() -> None:
    # Verify bucket creation through the API.
    with TestClient(app) as client:
        response = client.put("/photos")

    assert response.status_code == 200
    payload = response.json()
    assert payload["message"] == "Bucket created successfully."
    assert payload["bucket"]["name"] == "photos"


def test_create_duplicate_bucket_endpoint() -> None:
    # Verify duplicate bucket creation returns conflict.
    with TestClient(app) as client:
        client.put("/photos")
        response = client.put("/photos")

    assert response.status_code == 409
    assert b"<Code>BucketAlreadyExists</Code>" in response.content


def test_delete_bucket_endpoint() -> None:
    # Verify empty bucket deletion works through the API.
    with TestClient(app) as client:
        client.put("/photos")
        response = client.delete("/photos")

    assert response.status_code == 204


def test_delete_missing_bucket_endpoint() -> None:
    # Verify missing bucket deletion returns not found.
    with TestClient(app) as client:
        response = client.delete("/missing")

    assert response.status_code == 404
    assert b"<Code>NoSuchBucket</Code>" in response.content


def test_upload_and_download_object_endpoint() -> None:
    # Verify raw upload and object download.
    with TestClient(app) as client:
        client.put("/photos")
        upload_response = client.put(
            "/photos/cat.jpg",
            content=b"hello-world",
            headers={"Content-Type": "image/jpeg"},
        )
        head_response = client.head("/photos/cat.jpg")
        download_response = client.get("/photos/cat.jpg")

    assert upload_response.status_code == 200
    assert upload_response.headers["etag"].startswith('"')

    assert head_response.status_code == 200
    assert head_response.headers["content-type"].startswith("image/jpeg")
    assert head_response.headers["content-length"] == "11"
    assert head_response.headers["etag"].startswith('"')

    assert download_response.status_code == 200
    assert download_response.content == b"hello-world"
    assert download_response.headers["content-type"].startswith("image/jpeg")
    assert download_response.headers["etag"].startswith('"')
    assert "last-modified" in download_response.headers


def test_upload_object_to_missing_bucket_endpoint() -> None:
    # Verify uploads to missing buckets fail.
    with TestClient(app) as client:
        response = client.put(
            "/missing/cat.jpg",
            content=b"hello-world",
            headers={"Content-Type": "image/jpeg"},
        )

    assert response.status_code == 404
    assert b"<Code>NoSuchBucket</Code>" in response.content


def test_list_objects_endpoint_returns_xml() -> None:
    # Verify object listing works with list-type=2 and returns XML.
    with TestClient(app) as client:
        client.put("/photos")
        client.put("/photos/cat.jpg", content=b"hello", headers={"Content-Type": "image/jpeg"})
        client.put("/photos/dog.jpg", content=b"world", headers={"Content-Type": "image/jpeg"})
        response = client.get("/photos", params={"list-type": 2})

    assert response.status_code == 200
    assert response.headers["content-type"].startswith("application/xml")
    assert b"<ListBucketResult" in response.content
    assert b"<Key>cat.jpg</Key>" in response.content
    assert b"<Key>dog.jpg</Key>" in response.content


def test_list_objects_json_debug_endpoint() -> None:
    # Verify the debug objects endpoint returns JSON.
    with TestClient(app) as client:
        client.put("/photos")
        client.put("/photos/cat.jpg", content=b"hello", headers={"Content-Type": "image/jpeg"})
        response = client.get("/_debug/photos")

    assert response.status_code == 200
    payload = response.json()
    assert payload["bucket_name"] == "photos"
    assert len(payload["objects"]) == 1


def test_list_objects_invalid_list_type() -> None:
    # Verify unsupported listing type returns a bad request.
    with TestClient(app) as client:
        client.put("/photos")
        response = client.get("/photos", params={"list-type": 1})

    assert response.status_code == 400
    assert b"<Code>InvalidArgument</Code>" in response.content


def test_delete_object_endpoint() -> None:
    # Verify object deletion works through the API.
    with TestClient(app) as client:
        client.put("/photos")
        client.put("/photos/cat.jpg", content=b"hello", headers={"Content-Type": "image/jpeg"})
        delete_response = client.delete("/photos/cat.jpg")
        download_response = client.get("/photos/cat.jpg")

    assert delete_response.status_code == 204
    assert download_response.status_code == 404


def test_openapi_schema_is_available() -> None:
    # Verify OpenAPI schema is exposed.
    with TestClient(app) as client:
        response = client.get("/openapi.json")

    assert response.status_code == 200
    payload = response.json()
    assert payload["info"]["title"] == "tiny-object-storage"


def test_delete_non_empty_bucket_endpoint() -> None:
    # Verify that attempting to delete a non-empty bucket through API returns 409
    with TestClient(app) as client:
        client.put("/photos")
        client.put("/photos/cat.jpg", content=b"hello", headers={"Content-Type": "image/jpeg"})
        response = client.delete("/photos")

    assert response.status_code == 409
    assert b"<Code>BucketNotEmpty</Code>" in response.content


def test_malformed_bucket_name_endpoint() -> None:
    # Verify malformed bucket name rejected
    with TestClient(app) as client:
        response = client.put("/invalid_name")  # Underscore not allowed

    assert response.status_code == 400
    assert b"<Code>InvalidBucketName</Code>" in response.content


def test_invalid_upload_without_content_type() -> None:
    # Default behavior might handle it or we might require content-type.
    # We just make sure it doesn't crash 500 when no headers are supplied.
    with TestClient(app) as client:
        client.put("/photos")
        response = client.put("/photos/dog.txt", content=b"bark")

    assert response.status_code == 200
    assert response.headers["etag"].startswith('"')
    # Fallback to application/octet-stream if missing


def test_upload_large_chunk() -> None:
    # Upload slightly larger file for streaming coverage
    data = b"a" * (1024 * 1024 * 2)  # 2 MB
    with TestClient(app) as client:
        client.put("/big")
        response = client.put(
            "/big/file.dat", content=data, headers={"Content-Type": "application/octet-stream"}
        )

    assert response.status_code == 200

    with TestClient(app) as client:
        d_resp = client.get("/big/file.dat")
        assert len(d_resp.content) == len(data)
