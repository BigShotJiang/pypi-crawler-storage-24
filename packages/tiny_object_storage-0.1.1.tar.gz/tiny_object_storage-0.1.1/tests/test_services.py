from pathlib import Path

import pytest

from tiny_object_storage.core.errors import BucketNotFoundError, ObjectNotFoundError
from tiny_object_storage.logging_config import configure_logging
from tiny_object_storage.services.bucket_service import BucketService
from tiny_object_storage.services.object_service import ObjectService
from tiny_object_storage.storage.filesystem import FilesystemStorage


@pytest.fixture
def services(tmp_path: Path) -> tuple[BucketService, ObjectService, FilesystemStorage]:
    # Create service instances backed by temporary filesystem storage.
    log_dir = tmp_path / "logs"
    configure_logging(log_dir=log_dir, log_level="DEBUG")

    storage = FilesystemStorage(base_dir=tmp_path / "storage")
    bucket_service = BucketService(storage=storage)
    object_service = ObjectService(storage=storage)
    return bucket_service, object_service, storage


def test_bucket_service_create_and_list(
    services: tuple[BucketService, ObjectService, FilesystemStorage],
) -> None:
    # Verify bucket service can create and list buckets.
    bucket_service, _, _ = services

    created_bucket = bucket_service.create_bucket("photos")
    buckets = bucket_service.list_buckets()

    assert created_bucket["name"] == "photos"
    assert len(buckets) == 1
    assert buckets[0]["name"] == "photos"


def test_bucket_service_delete(
    services: tuple[BucketService, ObjectService, FilesystemStorage],
) -> None:
    # Verify bucket service can delete an empty bucket.
    bucket_service, _, _ = services

    bucket_service.create_bucket("photos")
    assert bucket_service.bucket_exists("photos") is True

    bucket_service.delete_bucket("photos")

    assert bucket_service.bucket_exists("photos") is False


def test_object_service_put_and_get(
    services: tuple[BucketService, ObjectService, FilesystemStorage],
) -> None:
    # Verify object service can store and read objects.
    bucket_service, object_service, _ = services

    bucket_service.create_bucket("photos")
    metadata = object_service.put_object(
        bucket_name="photos",
        object_key="cat.jpg",
        data=b"hello-world",
        content_type="image/jpeg",
    )
    stored = object_service.get_object(bucket_name="photos", object_key="cat.jpg")

    assert metadata["bucket_name"] == "photos"
    assert metadata["object_key"] == "cat.jpg"
    assert stored.data == b"hello-world"
    assert stored.metadata["content_type"] == "image/jpeg"


def test_object_service_list_objects(
    services: tuple[BucketService, ObjectService, FilesystemStorage],
) -> None:
    # Verify object service can list stored objects.
    bucket_service, object_service, _ = services

    bucket_service.create_bucket("photos")
    object_service.put_object(bucket_name="photos", object_key="a.txt", data=b"a")
    object_service.put_object(bucket_name="photos", object_key="nested/b.txt", data=b"b")

    objects = object_service.list_objects(bucket_name="photos")

    assert len(objects) == 2
    keys = {item["object_key"] for item in objects}
    assert keys == {"a.txt", "nested/b.txt"}


def test_object_service_delete_object(
    services: tuple[BucketService, ObjectService, FilesystemStorage],
) -> None:
    # Verify object service can delete objects.
    bucket_service, object_service, _ = services

    bucket_service.create_bucket("photos")
    object_service.put_object(bucket_name="photos", object_key="cat.jpg", data=b"hello-world")

    assert object_service.object_exists("photos", "cat.jpg") is True

    object_service.delete_object(bucket_name="photos", object_key="cat.jpg")

    assert object_service.object_exists("photos", "cat.jpg") is False


def test_object_service_put_missing_bucket_raises(
    services: tuple[BucketService, ObjectService, FilesystemStorage],
) -> None:
    # Verify writing to a missing bucket fails through the service layer.
    _, object_service, _ = services

    with pytest.raises(BucketNotFoundError):
        object_service.put_object(bucket_name="missing", object_key="cat.jpg", data=b"hello")


def test_object_service_get_missing_object_raises(
    services: tuple[BucketService, ObjectService, FilesystemStorage],
) -> None:
    # Verify reading a missing object fails through the service layer.
    bucket_service, object_service, _ = services

    bucket_service.create_bucket("photos")

    with pytest.raises(ObjectNotFoundError):
        object_service.get_object(bucket_name="photos", object_key="missing.jpg")


def test_bucket_service_invalid_name_raises(
    services: tuple[BucketService, ObjectService, FilesystemStorage],
) -> None:
    bucket_service, _, _ = services

    from tiny_object_storage.core.errors import InvalidBucketNameError

    with pytest.raises(InvalidBucketNameError):
        bucket_service.create_bucket("INVALID_NAME")


def test_bucket_service_delete_non_empty_raises(
    services: tuple[BucketService, ObjectService, FilesystemStorage],
) -> None:
    bucket_service, object_service, _ = services

    bucket_service.create_bucket("photos")
    object_service.put_object(bucket_name="photos", object_key="cat.jpg", data=b"hello")

    from tiny_object_storage.core.errors import BucketNotEmptyError

    with pytest.raises(BucketNotEmptyError):
        bucket_service.delete_bucket("photos")


def test_object_service_invalid_key_raises(
    services: tuple[BucketService, ObjectService, FilesystemStorage],
) -> None:
    bucket_service, object_service, _ = services

    bucket_service.create_bucket("photos")

    from tiny_object_storage.core.errors import InvalidObjectKeyError

    with pytest.raises(InvalidObjectKeyError):
        object_service.put_object(bucket_name="photos", object_key="../cat.jpg", data=b"hello")
