from datetime import UTC
from pathlib import Path

import pytest

from tiny_object_storage.core.errors import InvalidBucketNameError, InvalidObjectKeyError
from tiny_object_storage.core.utils import (
    bucket_path,
    build_list_buckets_xml,
    build_list_objects_v2_xml,
    compute_etag,
    ensure_path_within_base,
    http_date,
    metadata_dir_path,
    metadata_file_path,
    object_path,
    parse_iso_datetime,
    read_json,
    utc_now,
    utc_now_iso,
    validate_bucket_name,
    validate_object_key,
    write_json,
)


def test_utc_now() -> None:
    now = utc_now()
    assert now.tzinfo == UTC


def test_utc_now_iso() -> None:
    iso = utc_now_iso()
    assert "T" in iso
    assert "+00:00" in iso


def test_parse_iso_datetime() -> None:
    assert parse_iso_datetime(None) is None
    parsed = parse_iso_datetime("2026-03-09T14:11:41Z")
    assert parsed is not None
    assert parsed.tzinfo == UTC
    assert parsed.year == 2026


def test_http_date() -> None:
    assert http_date(None) is None
    date_str = http_date("2026-03-09T14:11:41Z")
    assert date_str == "Mon, 09 Mar 2026 14:11:41 GMT"


def test_validate_bucket_name() -> None:
    # Valid names
    validate_bucket_name("valid-bucket-name")
    validate_bucket_name("a.b.c.d")
    validate_bucket_name("12345")

    # Invalid names
    with pytest.raises(InvalidBucketNameError):
        validate_bucket_name("")
    with pytest.raises(InvalidBucketNameError):
        validate_bucket_name("ab")  # Too short
    with pytest.raises(InvalidBucketNameError):
        validate_bucket_name("a" * 64)  # Too long
    with pytest.raises(InvalidBucketNameError):
        validate_bucket_name("Invalid-Name")  # Uppercase
    with pytest.raises(InvalidBucketNameError):
        validate_bucket_name("invalid_name")  # Underscore
    with pytest.raises(InvalidBucketNameError):
        validate_bucket_name("a..b")  # Consecutive dots
    with pytest.raises(InvalidBucketNameError):
        validate_bucket_name(".start")  # Starts with dot
    with pytest.raises(InvalidBucketNameError):
        validate_bucket_name("-start")  # Starts with hyphen


def test_validate_object_key() -> None:
    # Valid keys
    validate_object_key("valid/key.jpg")

    # Invalid keys
    with pytest.raises(InvalidObjectKeyError):
        validate_object_key("")
    with pytest.raises(InvalidObjectKeyError):
        validate_object_key("   ")
    with pytest.raises(InvalidObjectKeyError):
        validate_object_key("/starts/with/slash")
    with pytest.raises(InvalidObjectKeyError):
        validate_object_key("contains/../dots")
    with pytest.raises(InvalidObjectKeyError):
        validate_object_key("contains/\x00/null")


def test_ensure_path_within_base(tmp_path: Path) -> None:
    base = tmp_path
    valid_target = tmp_path / "valid"
    invalid_target = tmp_path / ".." / "invalid"

    ensure_path_within_base(base, valid_target)

    with pytest.raises(InvalidObjectKeyError):
        ensure_path_within_base(base, invalid_target)


def test_bucket_path(tmp_path: Path) -> None:
    path = bucket_path(tmp_path, "photos")
    assert path.name == "photos"


def test_object_path(tmp_path: Path) -> None:
    path = object_path(tmp_path, "photos", "cat.jpg")
    assert path.name == "cat.jpg"


def test_metadata_paths(tmp_path: Path) -> None:
    dir_path = metadata_dir_path(tmp_path, "photos")
    assert dir_path.name == ".meta"

    file_path = metadata_file_path(tmp_path, "photos", "foo/bar.jpg")
    assert file_path.name == "foo__bar.jpg.json"


def test_compute_etag() -> None:
    etag = compute_etag(b"hello")
    assert etag == "5d41402abc4b2a76b9719d911017c592"


def test_write_and_read_json(tmp_path: Path) -> None:
    file_path = tmp_path / "data.json"
    payload = {"key": "value"}
    write_json(file_path, payload)
    read_payload = read_json(file_path)
    assert read_payload == payload


def test_build_list_buckets_xml() -> None:
    buckets = [{"name": "test1", "created_at": "2026-03-09T14:11:41Z"}, {"name": "test2"}]
    xml_bytes = build_list_buckets_xml(buckets)
    assert b"<Name>test1</Name>" in xml_bytes
    assert b"<CreationDate>2026-03-09T14:11:41Z</CreationDate>" in xml_bytes
    assert b"<Name>test2</Name>" in xml_bytes


def test_build_list_objects_v2_xml() -> None:
    objects = [
        {
            "object_key": "cat.jpg",
            "size": 1024,
            "etag": "abc",
            "updated_at": "2026-03-09T14:11:41Z",
        },
        {"object_key": "dog.jpg", "size": 2048, "etag": "def"},  # No updated_at/created_at
    ]
    xml_bytes = build_list_objects_v2_xml("photos", objects)
    assert b"<Name>photos</Name>" in xml_bytes
    assert b"<Key>cat.jpg</Key>" in xml_bytes
    assert b"<Size>1024</Size>" in xml_bytes
    assert b"<Key>dog.jpg</Key>" in xml_bytes
    assert b"<Size>2048</Size>" in xml_bytes
