from functools import lru_cache
from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    # Runtime settings for the application.
    app_name: str = Field(default="tiny-object-storage", alias="TOS_APP_NAME")
    host: str = Field(default="0.0.0.0", alias="TOS_HOST")
    port: int = Field(default=9000, alias="TOS_PORT")
    data_dir: Path = Field(default=Path("./storage_data"), alias="TOS_DATA_DIR")
    log_dir: Path = Field(default=Path("./logs"), alias="TOS_LOG_DIR")
    log_level: str = Field(default="INFO", alias="TOS_LOG_LEVEL")
    dev_mode: bool = Field(default=True, alias="TOS_DEV_MODE")
    max_object_size: int = Field(default=104857600, alias="TOS_MAX_OBJECT_SIZE")

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        populate_by_name=True,
    )

    def ensure_directories(self) -> None:
        # Create required directories if they do not exist.
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.log_dir.mkdir(parents=True, exist_ok=True)


@lru_cache
def get_settings() -> Settings:
    # Return cached application settings.
    settings = Settings()
    settings.ensure_directories()
    return settings
