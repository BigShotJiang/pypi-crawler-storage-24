from pydantic import BaseModel, Field


class ObjectInfo(BaseModel):
    # Represent object metadata returned by the API.
    bucket_name: str = Field(..., description="Bucket name.")
    object_key: str = Field(..., description="Object key.")
    size: int = Field(..., description="Object size in bytes.")
    content_type: str = Field(..., description="Object content type.")
    etag: str = Field(..., description="Entity tag for the stored object.")
    created_at: str | None = Field(
        default=None,
        description="Object creation timestamp in ISO 8601 format.",
    )
    updated_at: str | None = Field(
        default=None,
        description="Object update timestamp in ISO 8601 format.",
    )
