from pydantic import BaseModel, Field

from tiny_object_storage.models.bucket import BucketInfo
from tiny_object_storage.models.object_info import ObjectInfo


class HealthResponse(BaseModel):
    # Represent healthcheck response payload.
    status: str = Field(..., description="Service status.")
    app_name: str = Field(..., description="Application name.")
    data_dir: str = Field(..., description="Configured storage data directory.")
    log_dir: str = Field(..., description="Configured log directory.")
    log_level: str = Field(..., description="Configured log level.")
    dev_mode: bool = Field(..., description="Whether dev mode is enabled.")


class MessageResponse(BaseModel):
    # Represent a generic API message response.
    message: str = Field(..., description="Human-readable status message.")


class ErrorResponse(BaseModel):
    # Represent a standardized error response.
    error: str = Field(..., description="Machine-readable error code.")
    message: str = Field(..., description="Human-readable error message.")


class BucketsListResponse(BaseModel):
    # Represent bucket listing response.
    buckets: list[BucketInfo] = Field(..., description="List of buckets.")


class ObjectsListResponse(BaseModel):
    # Represent object listing response.
    bucket_name: str = Field(..., description="Bucket name.")
    objects: list[ObjectInfo] = Field(..., description="List of objects.")


class BucketCreatedResponse(BaseModel):
    # Represent bucket creation response.
    message: str = Field(..., description="Human-readable status message.")
    bucket: BucketInfo = Field(..., description="Created bucket metadata.")


class ObjectStoredResponse(BaseModel):
    # Represent object upload response.
    message: str = Field(..., description="Human-readable status message.")
    object: ObjectInfo = Field(..., description="Stored object metadata.")
