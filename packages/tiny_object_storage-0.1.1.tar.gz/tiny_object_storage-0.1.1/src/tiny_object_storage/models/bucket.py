from pydantic import BaseModel, Field


class BucketInfo(BaseModel):
    # Represent bucket metadata returned by the API.
    name: str = Field(..., description="Bucket name.")
    created_at: str | None = Field(
        default=None,
        description="Bucket creation timestamp in ISO 8601 format.",
    )
