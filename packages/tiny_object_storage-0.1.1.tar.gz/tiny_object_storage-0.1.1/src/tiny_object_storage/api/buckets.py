from fastapi import APIRouter, Request, Response, status
from fastapi.responses import Response as FastAPIResponse

from tiny_object_storage.core.utils import build_list_buckets_xml
from tiny_object_storage.models.bucket import BucketInfo
from tiny_object_storage.models.responses import (
    BucketCreatedResponse,
    BucketsListResponse,
    ErrorResponse,
)

router = APIRouter(tags=["buckets"])


@router.get(
    "/",
    responses={
        200: {
            "description": "Buckets returned in S3-style XML.",
            "content": {"application/xml": {}},
        },
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    summary="List buckets",
    description="Return all available buckets as a minimal S3-compatible XML response.",
)
def list_buckets(request: Request) -> FastAPIResponse:
    # Return all buckets from the service layer as XML.
    bucket_service = request.app.state.bucket_service
    buckets = bucket_service.list_buckets()
    xml_payload = build_list_buckets_xml(buckets)
    return FastAPIResponse(content=xml_payload, media_type="application/xml")


@router.get(
    "/_debug/buckets",
    response_model=BucketsListResponse,
    include_in_schema=True,
    summary="List buckets as JSON",
    description="Return all available buckets in JSON format for debugging and development.",
    responses={
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
)
def list_buckets_json(request: Request) -> BucketsListResponse:
    # Return all buckets from the service layer as JSON.
    bucket_service = request.app.state.bucket_service
    buckets = bucket_service.list_buckets()
    return BucketsListResponse(buckets=[BucketInfo(**bucket) for bucket in buckets])


@router.put(
    "/{bucket_name}",
    response_model=BucketCreatedResponse,
    status_code=status.HTTP_200_OK,
    summary="Create bucket",
    description="Create a new bucket using an S3-style path.",
    responses={
        200: {"description": "Bucket created."},
        400: {"model": ErrorResponse, "description": "Invalid bucket name."},
        409: {"model": ErrorResponse, "description": "Bucket already exists."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
)
def create_bucket(bucket_name: str, request: Request) -> BucketCreatedResponse:
    # Create a new bucket and return its metadata.
    bucket_service = request.app.state.bucket_service
    bucket = bucket_service.create_bucket(bucket_name=bucket_name)
    return BucketCreatedResponse(
        message="Bucket created successfully.",
        bucket=BucketInfo(**bucket),
    )


@router.delete(
    "/{bucket_name}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete bucket",
    description="Delete an existing bucket. The bucket must be empty.",
    responses={
        204: {"description": "Bucket deleted."},
        400: {"model": ErrorResponse, "description": "Invalid bucket name."},
        404: {"model": ErrorResponse, "description": "Bucket not found."},
        409: {"model": ErrorResponse, "description": "Bucket is not empty."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
)
def delete_bucket(bucket_name: str, request: Request) -> Response:
    # Delete the requested bucket.
    bucket_service = request.app.state.bucket_service
    bucket_service.delete_bucket(bucket_name=bucket_name)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.head(
    "/{bucket_name}",
    status_code=status.HTTP_200_OK,
    summary="Head bucket",
    description="Determine if a bucket exists and if you have permission to access it.",
    responses={
        200: {"description": "Bucket exists."},
        400: {"model": ErrorResponse, "description": "Invalid bucket name."},
        404: {"model": ErrorResponse, "description": "Bucket not found."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
)
def head_bucket(bucket_name: str, request: Request) -> Response:
    # Check if a bucket exists. Boto3 relies on this to verify buckets before acting.
    bucket_service = request.app.state.bucket_service
    from tiny_object_storage.core.errors import BucketNotFoundError

    if not bucket_service.bucket_exists(bucket_name):
        raise BucketNotFoundError(f"Bucket '{bucket_name}' does not exist.")
    return Response(status_code=status.HTTP_200_OK)
