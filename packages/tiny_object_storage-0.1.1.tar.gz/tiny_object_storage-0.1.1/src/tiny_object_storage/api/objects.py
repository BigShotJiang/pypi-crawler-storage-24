from datetime import UTC, datetime
from io import BytesIO

from fastapi import APIRouter, Header, Query, Request, Response, status
from fastapi.responses import StreamingResponse

from tiny_object_storage.core.utils import build_list_objects_v2_xml, http_date
from tiny_object_storage.models.object_info import ObjectInfo
from tiny_object_storage.models.responses import (
    ErrorResponse,
    ObjectsListResponse,
)

router = APIRouter(tags=["objects"])


@router.get(
    "/{bucket_name}",
    responses={
        200: {
            "description": "Objects returned in minimal S3 ListObjectsV2 XML format.",
            "content": {"application/xml": {}},
        },
        400: {"model": ErrorResponse, "description": "Invalid bucket name or query parameter."},
        404: {"model": ErrorResponse, "description": "Bucket not found."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
    summary="List objects",
    description="Return objects in a bucket using a minimal S3 ListObjectsV2 XML response.",
)
def list_objects(
    bucket_name: str,
    request: Request,
    list_type: int = Query(
        default=2,
        alias="list-type",
        description="S3-style listing mode. Only value 2 is currently supported.",
    ),
    prefix: str = Query(default="", description="Optional key prefix filter."),
    max_keys: int = Query(default=1000, alias="max-keys", description="Maximum number of keys."),
) -> Response:
    # Return bucket contents in minimal S3-compatible XML.
    if list_type != 2:
        raise ValueError("Only list-type=2 is supported.")

    object_service = request.app.state.object_service
    objects = object_service.list_objects(bucket_name=bucket_name)

    if prefix:
        objects = [item for item in objects if item["object_key"].startswith(prefix)]

    limited = objects[:max_keys]
    truncated = len(objects) > max_keys

    xml_payload = build_list_objects_v2_xml(
        bucket_name=bucket_name,
        objects=limited,
        prefix=prefix,
        max_keys=max_keys,
        is_truncated=truncated,
    )
    return Response(content=xml_payload, media_type="application/xml")


@router.get(
    "/_debug/{bucket_name}",
    response_model=ObjectsListResponse,
    include_in_schema=True,
    summary="List objects as JSON",
    description="Return objects in a bucket as JSON for debugging and development.",
    responses={
        400: {"model": ErrorResponse, "description": "Invalid bucket name or query parameter."},
        404: {"model": ErrorResponse, "description": "Bucket not found."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
)
def list_objects_json(bucket_name: str, request: Request) -> ObjectsListResponse:
    # Return all objects in the requested bucket as JSON.
    object_service = request.app.state.object_service
    objects = object_service.list_objects(bucket_name=bucket_name)
    return ObjectsListResponse(
        bucket_name=bucket_name,
        objects=[ObjectInfo(**item) for item in objects],
    )


@router.put(
    "/{bucket_name}/{object_key:path}",
    status_code=status.HTTP_200_OK,
    summary="Upload object",
    description="Store an object in a bucket using an S3-style path and a raw request body.",
    responses={
        200: {"description": "Object stored."},
        400: {"model": ErrorResponse, "description": "Invalid input."},
        404: {"model": ErrorResponse, "description": "Bucket not found."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
)
async def put_object(
    bucket_name: str,
    object_key: str,
    request: Request,
    content_type: str | None = Header(default=None, alias="Content-Type"),
) -> Response:
    # Upload an object using a raw request body.
    body = await request.body()
    object_service = request.app.state.object_service
    metadata = object_service.put_object(
        bucket_name=bucket_name,
        object_key=object_key,
        data=body,
        content_type=content_type,
    )
    headers = {"ETag": f"\"{metadata['etag']}\""}
    return Response(status_code=status.HTTP_200_OK, headers=headers)


@router.head(
    "/{bucket_name}/{object_key:path}",
    status_code=status.HTTP_200_OK,
    summary="Head object",
    description="Return object metadata headers without returning the object body.",
    responses={
        200: {"description": "Object metadata returned in headers."},
        400: {"model": ErrorResponse, "description": "Invalid input."},
        404: {"model": ErrorResponse, "description": "Bucket or object not found."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
)
def head_object(bucket_name: str, object_key: str, request: Request) -> Response:
    # Return object metadata using standard S3-style headers.
    object_service = request.app.state.object_service
    stored_object = object_service.get_object(bucket_name=bucket_name, object_key=object_key)

    headers = {
        "ETag": f"\"{stored_object.metadata['etag']}\"",
        "Content-Length": str(stored_object.metadata["size"]),
        "Content-Type": stored_object.metadata["content_type"],
        "Last-Modified": http_date(stored_object.metadata.get("updated_at"))
        or format_fallback_http_date(),
    }
    return Response(status_code=status.HTTP_200_OK, headers=headers)


@router.get(
    "/{bucket_name}/{object_key:path}",
    summary="Download object",
    description="Download a stored object using an S3-style path.",
    responses={
        200: {"description": "Object returned."},
        400: {"model": ErrorResponse, "description": "Invalid input."},
        404: {"model": ErrorResponse, "description": "Bucket or object not found."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
)
def get_object(bucket_name: str, object_key: str, request: Request) -> StreamingResponse:
    # Stream the stored object back to the client.
    object_service = request.app.state.object_service
    stored_object = object_service.get_object(bucket_name=bucket_name, object_key=object_key)

    headers = {
        "ETag": f"\"{stored_object.metadata['etag']}\"",
        "Content-Length": str(stored_object.metadata["size"]),
        "Last-Modified": http_date(stored_object.metadata.get("updated_at"))
        or format_fallback_http_date(),
    }

    return StreamingResponse(
        content=BytesIO(stored_object.data),
        media_type=stored_object.metadata["content_type"],
        headers=headers,
    )


@router.delete(
    "/{bucket_name}/{object_key:path}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete object",
    description="Delete an object from a bucket using an S3-style path.",
    responses={
        204: {"description": "Object deleted."},
        400: {"model": ErrorResponse, "description": "Invalid input."},
        404: {"model": ErrorResponse, "description": "Bucket or object not found."},
        500: {"model": ErrorResponse, "description": "Internal server error."},
    },
)
def delete_object(bucket_name: str, object_key: str, request: Request) -> Response:
    # Delete the requested object.
    object_service = request.app.state.object_service
    object_service.delete_object(bucket_name=bucket_name, object_key=object_key)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


def format_fallback_http_date() -> str:
    # Return the current UTC time formatted for HTTP headers.
    return datetime.now(UTC).strftime("%a, %d %b %Y %H:%M:%S GMT")
