from fastapi import APIRouter, Request

from tiny_object_storage.models.responses import HealthResponse

router = APIRouter(tags=["health"])


@router.get(
    "/health",
    response_model=HealthResponse,
    summary="Health check",
    description="Return the current service health status and active runtime configuration.",
)
def healthcheck(request: Request) -> HealthResponse:
    # Return a simple health status payload.
    settings = request.app.state.settings

    return HealthResponse(
        status="ok",
        app_name=settings.app_name,
        data_dir=str(settings.data_dir),
        log_dir=str(settings.log_dir),
        log_level=settings.log_level,
        dev_mode=settings.dev_mode,
    )
