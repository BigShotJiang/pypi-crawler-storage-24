from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, BinaryIO


@dataclass(slots=True)
class StoredObject:
    # Represent an object returned from the storage backend.
    bucket_name: str
    object_key: str
    data: bytes
    metadata: dict[str, Any]


class BaseStorage(ABC):
    # Define the storage backend contract.

    @abstractmethod
    def create_bucket(self, bucket_name: str) -> None:
        # Create a new bucket.
        raise NotImplementedError

    @abstractmethod
    def delete_bucket(self, bucket_name: str) -> None:
        # Delete an existing bucket.
        raise NotImplementedError

    @abstractmethod
    def list_buckets(self) -> list[dict[str, Any]]:
        # Return all available buckets.
        raise NotImplementedError

    @abstractmethod
    def bucket_exists(self, bucket_name: str) -> bool:
        # Check whether a bucket exists.
        raise NotImplementedError

    @abstractmethod
    def put_object(
        self,
        bucket_name: str,
        object_key: str,
        data: bytes | BinaryIO,
        content_type: str | None = None,
    ) -> dict[str, Any]:
        # Store an object and return its metadata.
        raise NotImplementedError

    @abstractmethod
    def get_object(self, bucket_name: str, object_key: str) -> StoredObject:
        # Read and return an object.
        raise NotImplementedError

    @abstractmethod
    def delete_object(self, bucket_name: str, object_key: str) -> None:
        # Delete an object.
        raise NotImplementedError

    @abstractmethod
    def list_objects(self, bucket_name: str) -> list[dict[str, Any]]:
        # Return all objects in a bucket.
        raise NotImplementedError

    @abstractmethod
    def object_exists(self, bucket_name: str, object_key: str) -> bool:
        # Check whether an object exists.
        raise NotImplementedError
