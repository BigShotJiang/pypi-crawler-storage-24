import mimetypes
from pathlib import Path
from typing import Any, BinaryIO

from tiny_object_storage.core.errors import (
    BucketAlreadyExistsError,
    BucketNotEmptyError,
    BucketNotFoundError,
    ObjectNotFoundError,
)
from tiny_object_storage.core.utils import (
    bucket_path,
    compute_etag,
    metadata_dir_path,
    metadata_file_path,
    object_path,
    read_json,
    utc_now_iso,
    validate_bucket_name,
    validate_object_key,
    write_json,
)
from tiny_object_storage.logging_config import get_logger
from tiny_object_storage.storage.base import BaseStorage, StoredObject


class FilesystemStorage(BaseStorage):
    # Implement the storage backend using the local filesystem.

    def __init__(self, base_dir: str | Path):
        # Initialize the storage backend.
        self.base_dir = Path(base_dir)
        self.base_dir.mkdir(parents=True, exist_ok=True)
        self.logger = get_logger("tiny_object_storage.storage.filesystem")
        self.logger.info("Filesystem storage initialized base_dir=%s", self.base_dir)

    def create_bucket(self, bucket_name: str) -> None:
        # Create a new bucket as a directory with a metadata subdirectory.
        validate_bucket_name(bucket_name)
        path = bucket_path(self.base_dir, bucket_name)

        if path.exists():
            self.logger.warning("Bucket already exists bucket=%s", bucket_name)
            raise BucketAlreadyExistsError(f"Bucket '{bucket_name}' already exists.")

        path.mkdir(parents=True, exist_ok=False)
        metadata_dir_path(self.base_dir, bucket_name).mkdir(parents=True, exist_ok=True)

        bucket_metadata = {
            "name": bucket_name,
            "created_at": utc_now_iso(),
        }
        write_json(path / ".bucket.meta.json", bucket_metadata)

        self.logger.info("Bucket created bucket=%s path=%s", bucket_name, path)

    def delete_bucket(self, bucket_name: str) -> None:
        # Delete an empty bucket.
        path = self._require_bucket(bucket_name)

        entries = [
            entry for entry in path.iterdir() if entry.name not in {".meta", ".bucket.meta.json"}
        ]
        if entries:
            self.logger.warning("Bucket not empty bucket=%s", bucket_name)
            raise BucketNotEmptyError(f"Bucket '{bucket_name}' is not empty.")

        meta_dir = path / ".meta"
        if meta_dir.exists():
            for meta_file in meta_dir.iterdir():
                meta_file.unlink()
            meta_dir.rmdir()

        bucket_meta_file = path / ".bucket.meta.json"
        if bucket_meta_file.exists():
            bucket_meta_file.unlink()

        path.rmdir()
        self.logger.info("Bucket deleted bucket=%s path=%s", bucket_name, path)

    def list_buckets(self) -> list[dict[str, Any]]:
        # List all buckets stored under the base directory.
        buckets: list[dict[str, Any]] = []

        for path in sorted(self.base_dir.iterdir(), key=lambda item: item.name):
            if not path.is_dir():
                continue

            bucket_meta_file = path / ".bucket.meta.json"
            created_at = None
            if bucket_meta_file.exists():
                try:
                    created_at = read_json(bucket_meta_file).get("created_at")
                except Exception:
                    self.logger.exception("Failed to read bucket metadata bucket=%s", path.name)

            buckets.append(
                {
                    "name": path.name,
                    "created_at": created_at,
                }
            )

        self.logger.info("Buckets listed count=%s", len(buckets))
        return buckets

    def bucket_exists(self, bucket_name: str) -> bool:
        # Return whether the given bucket exists.
        validate_bucket_name(bucket_name)
        exists = bucket_path(self.base_dir, bucket_name).is_dir()
        self.logger.debug("Bucket existence checked bucket=%s exists=%s", bucket_name, exists)
        return exists

    def put_object(
        self,
        bucket_name: str,
        object_key: str,
        data: bytes | BinaryIO,
        content_type: str | None = None,
    ) -> dict[str, Any]:
        # Write object data to disk and persist metadata.
        self._require_bucket(bucket_name)
        validate_object_key(object_key)

        payload = self._read_bytes(data)
        object_file_path = object_path(self.base_dir, bucket_name, object_key)
        object_file_path.parent.mkdir(parents=True, exist_ok=True)

        object_file_path.write_bytes(payload)

        resolved_content_type = (
            content_type or mimetypes.guess_type(object_key)[0] or "application/octet-stream"
        )
        now = utc_now_iso()

        previous_metadata = self._read_metadata_if_exists(bucket_name, object_key)
        created_at = previous_metadata.get("created_at", now) if previous_metadata else now

        metadata = {
            "bucket_name": bucket_name,
            "object_key": object_key,
            "size": len(payload),
            "content_type": resolved_content_type,
            "etag": compute_etag(payload),
            "created_at": created_at,
            "updated_at": now,
        }

        meta_path = metadata_file_path(self.base_dir, bucket_name, object_key)
        write_json(meta_path, metadata)

        self.logger.info(
            "Object stored bucket=%s key=%s size=%s path=%s",
            bucket_name,
            object_key,
            len(payload),
            object_file_path,
        )
        return metadata

    def get_object(self, bucket_name: str, object_key: str) -> StoredObject:
        # Read an object from disk and return its bytes and metadata.
        self._require_bucket(bucket_name)
        validate_object_key(object_key)

        object_file_path = object_path(self.base_dir, bucket_name, object_key)
        if not object_file_path.is_file():
            self.logger.warning("Object not found bucket=%s key=%s", bucket_name, object_key)
            raise ObjectNotFoundError(
                f"Object '{object_key}' was not found in bucket '{bucket_name}'."
            )

        data = object_file_path.read_bytes()
        metadata = self._read_metadata_if_exists(bucket_name, object_key)
        if not metadata:
            metadata = {
                "bucket_name": bucket_name,
                "object_key": object_key,
                "size": len(data),
                "content_type": mimetypes.guess_type(object_key)[0] or "application/octet-stream",
                "etag": compute_etag(data),
                "created_at": None,
                "updated_at": None,
            }

        self.logger.info("Object read bucket=%s key=%s size=%s", bucket_name, object_key, len(data))
        return StoredObject(
            bucket_name=bucket_name,
            object_key=object_key,
            data=data,
            metadata=metadata,
        )

    def delete_object(self, bucket_name: str, object_key: str) -> None:
        # Delete an object and its metadata.
        self._require_bucket(bucket_name)
        validate_object_key(object_key)

        object_file_path = object_path(self.base_dir, bucket_name, object_key)
        if not object_file_path.is_file():
            self.logger.warning(
                "Object not found for deletion bucket=%s key=%s", bucket_name, object_key
            )
            raise ObjectNotFoundError(
                f"Object '{object_key}' was not found in bucket '{bucket_name}'."
            )

        object_file_path.unlink()

        meta_path = metadata_file_path(self.base_dir, bucket_name, object_key)
        if meta_path.exists():
            meta_path.unlink()

        self._cleanup_empty_parent_directories(bucket_name=bucket_name, object_key=object_key)

        self.logger.info("Object deleted bucket=%s key=%s", bucket_name, object_key)

    def list_objects(self, bucket_name: str) -> list[dict[str, Any]]:
        # List all objects in a bucket recursively.
        bucket_dir = self._require_bucket(bucket_name)
        results: list[dict[str, Any]] = []

        for path in sorted(bucket_dir.rglob("*"), key=lambda item: str(item)):
            if not path.is_file():
                continue

            if path.name == ".bucket.meta.json":
                continue

            if ".meta" in path.parts:
                continue

            object_key = str(path.relative_to(bucket_dir)).replace("\\", "/")
            metadata = self._read_metadata_if_exists(bucket_name, object_key)

            if not metadata:
                data = path.read_bytes()
                metadata = {
                    "bucket_name": bucket_name,
                    "object_key": object_key,
                    "size": len(data),
                    "content_type": mimetypes.guess_type(object_key)[0]
                    or "application/octet-stream",
                    "etag": compute_etag(data),
                    "created_at": None,
                    "updated_at": None,
                }

            results.append(metadata)

        self.logger.info("Objects listed bucket=%s count=%s", bucket_name, len(results))
        return results

    def object_exists(self, bucket_name: str, object_key: str) -> bool:
        # Return whether the given object exists.
        self._require_bucket(bucket_name)
        validate_object_key(object_key)

        exists = object_path(self.base_dir, bucket_name, object_key).is_file()
        self.logger.debug(
            "Object existence checked bucket=%s key=%s exists=%s",
            bucket_name,
            object_key,
            exists,
        )
        return exists

    def _require_bucket(self, bucket_name: str) -> Path:
        # Return the bucket path or raise if the bucket does not exist.
        validate_bucket_name(bucket_name)
        path = bucket_path(self.base_dir, bucket_name)

        if not path.is_dir():
            self.logger.warning("Bucket not found bucket=%s", bucket_name)
            raise BucketNotFoundError(f"Bucket '{bucket_name}' does not exist.")

        return path

    def _read_bytes(self, data: bytes | BinaryIO) -> bytes:
        # Normalize supported input types into bytes.
        if isinstance(data, bytes):
            return data

        return data.read()

    def _read_metadata_if_exists(self, bucket_name: str, object_key: str) -> dict[str, Any] | None:
        # Read metadata if the file exists.
        meta_path = metadata_file_path(self.base_dir, bucket_name, object_key)
        if not meta_path.exists():
            return None

        try:
            metadata = read_json(meta_path)
            self.logger.debug(
                "Metadata read bucket=%s key=%s path=%s", bucket_name, object_key, meta_path
            )
            return metadata
        except Exception:
            self.logger.exception(
                "Failed to read metadata bucket=%s key=%s path=%s",
                bucket_name,
                object_key,
                meta_path,
            )
            return None

    def _cleanup_empty_parent_directories(self, bucket_name: str, object_key: str) -> None:
        # Remove empty object directories after deletion.
        bucket_dir = bucket_path(self.base_dir, bucket_name)
        object_file_path = object_path(self.base_dir, bucket_name, object_key)

        current = object_file_path.parent
        while current != bucket_dir and current.exists():
            if any(current.iterdir()):
                break
            current.rmdir()
            self.logger.debug("Removed empty directory path=%s", current)
            current = current.parent
