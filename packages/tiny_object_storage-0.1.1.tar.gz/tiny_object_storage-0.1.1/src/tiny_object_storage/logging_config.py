import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path

LOG_FORMAT = "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
DATE_FORMAT = "%Y-%m-%d %H:%M:%S"


def _build_formatter() -> logging.Formatter:
    # Create a shared formatter for all handlers.
    return logging.Formatter(fmt=LOG_FORMAT, datefmt=DATE_FORMAT)


def _build_console_handler(log_level: str) -> logging.Handler:
    # Create console log handler.
    handler = logging.StreamHandler()
    handler.setLevel(log_level.upper())
    handler.setFormatter(_build_formatter())
    return handler


def _build_rotating_file_handler(file_path: Path, log_level: str) -> logging.Handler:
    # Create a rotating file handler.
    handler = RotatingFileHandler(
        filename=file_path,
        maxBytes=5 * 1024 * 1024,
        backupCount=5,
        encoding="utf-8",
    )
    handler.setLevel(log_level.upper())
    handler.setFormatter(_build_formatter())
    return handler


def _build_error_file_handler(file_path: Path) -> logging.Handler:
    # Create a dedicated error log file handler.
    handler = RotatingFileHandler(
        filename=file_path,
        maxBytes=5 * 1024 * 1024,
        backupCount=5,
        encoding="utf-8",
    )
    handler.setLevel(logging.ERROR)
    handler.setFormatter(_build_formatter())
    return handler


def configure_logging(log_dir: Path, log_level: str) -> None:
    # Configure root logger once for the entire application.
    log_dir.mkdir(parents=True, exist_ok=True)

    root_logger = logging.getLogger()
    if root_logger.handlers:
        return

    root_logger.setLevel(logging.DEBUG)

    server_log_path = log_dir / "server.log"
    error_log_path = log_dir / "error.log"

    handlers = [
        _build_console_handler(log_level=log_level),
        _build_rotating_file_handler(file_path=server_log_path, log_level=log_level),
        _build_error_file_handler(file_path=error_log_path),
    ]

    for handler in handlers:
        root_logger.addHandler(handler)


def get_logger(name: str) -> logging.Logger:
    # Return a named logger instance.
    return logging.getLogger(name)
