class TinyObjectStorageError(Exception):
    # Base exception for all domain-specific errors.
    pass


class BucketAlreadyExistsError(TinyObjectStorageError):
    # Raised when trying to create a bucket that already exists.
    pass


class BucketNotFoundError(TinyObjectStorageError):
    # Raised when the target bucket does not exist.
    pass


class BucketNotEmptyError(TinyObjectStorageError):
    # Raised when trying to delete a non-empty bucket.
    pass


class ObjectNotFoundError(TinyObjectStorageError):
    # Raised when the target object does not exist.
    pass


class InvalidBucketNameError(TinyObjectStorageError):
    # Raised when a bucket name does not meet validation rules.
    pass


class InvalidObjectKeyError(TinyObjectStorageError):
    # Raised when an object key does not meet validation rules.
    pass
