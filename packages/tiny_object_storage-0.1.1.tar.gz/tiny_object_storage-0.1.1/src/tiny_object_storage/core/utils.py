import hashlib
import json
import re
from datetime import UTC, datetime
from email.utils import format_datetime
from pathlib import Path
from typing import Any
from xml.etree.ElementTree import Element, SubElement, tostring

from tiny_object_storage.core.errors import InvalidBucketNameError, InvalidObjectKeyError

_BUCKET_NAME_PATTERN = re.compile(r"^[a-z0-9][a-z0-9.-]{1,61}[a-z0-9]$")


def utc_now() -> datetime:
    # Return the current UTC datetime.
    return datetime.now(UTC)


def utc_now_iso() -> str:
    # Return the current UTC time in ISO 8601 format.
    return utc_now().isoformat()


def parse_iso_datetime(value: str | None) -> datetime | None:
    # Parse an ISO 8601 datetime string.
    if not value:
        return None

    normalized = value.replace("Z", "+00:00")
    parsed = datetime.fromisoformat(normalized)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


def http_date(value: str | None) -> str | None:
    # Convert an ISO 8601 timestamp to an RFC 7231 HTTP date string.
    parsed = parse_iso_datetime(value)
    if parsed is None:
        return None
    return format_datetime(parsed, usegmt=True)


def validate_bucket_name(bucket_name: str) -> None:
    # Validate bucket name using a simplified S3-like rule set.
    if not bucket_name:
        raise InvalidBucketNameError("Bucket name cannot be empty.")

    if len(bucket_name) < 3 or len(bucket_name) > 63:
        raise InvalidBucketNameError("Bucket name length must be between 3 and 63 characters.")

    if not _BUCKET_NAME_PATTERN.fullmatch(bucket_name):
        raise InvalidBucketNameError(
            "Bucket name must contain only lowercase letters, numbers, dots, and hyphens."
        )

    if ".." in bucket_name or ".-" in bucket_name or "-." in bucket_name:
        raise InvalidBucketNameError("Bucket name contains an invalid sequence.")

    if bucket_name.startswith(".") or bucket_name.endswith("."):
        raise InvalidBucketNameError("Bucket name cannot start or end with a dot.")

    if bucket_name.startswith("-") or bucket_name.endswith("-"):
        raise InvalidBucketNameError("Bucket name cannot start or end with a hyphen.")


def validate_object_key(object_key: str) -> None:
    # Validate object key and reject obviously dangerous values.
    if not object_key:
        raise InvalidObjectKeyError("Object key cannot be empty.")

    normalized = object_key.strip()
    if not normalized:
        raise InvalidObjectKeyError("Object key cannot be blank.")

    if normalized.startswith("/"):
        raise InvalidObjectKeyError("Object key cannot start with '/'.")

    parts = normalized.split("/")
    for part in parts:
        if part in {"", ".", ".."}:
            raise InvalidObjectKeyError("Object key contains an invalid path segment.")

    if "\x00" in normalized:
        raise InvalidObjectKeyError("Object key contains a null byte.")


def ensure_path_within_base(base_path: Path, target_path: Path) -> None:
    # Ensure that the target path stays within the configured base directory.
    base_resolved = base_path.resolve()
    target_resolved = target_path.resolve()

    if base_resolved not in {target_resolved, *target_resolved.parents}:
        raise InvalidObjectKeyError("Resolved path escapes the storage base directory.")


def bucket_path(base_dir: Path, bucket_name: str) -> Path:
    # Build a safe bucket path.
    validate_bucket_name(bucket_name)
    path = base_dir / bucket_name
    ensure_path_within_base(base_dir, path)
    return path


def object_path(base_dir: Path, bucket_name: str, object_key: str) -> Path:
    # Build a safe object path.
    validate_bucket_name(bucket_name)
    validate_object_key(object_key)

    path = base_dir / bucket_name / Path(object_key)
    ensure_path_within_base(base_dir / bucket_name, path)
    return path


def metadata_dir_path(base_dir: Path, bucket_name: str) -> Path:
    # Build the metadata directory path for a bucket.
    path = bucket_path(base_dir, bucket_name) / ".meta"
    ensure_path_within_base(base_dir / bucket_name, path)
    return path


def metadata_file_path(base_dir: Path, bucket_name: str, object_key: str) -> Path:
    # Build a safe metadata file path for an object.
    validate_object_key(object_key)

    safe_name = object_key.replace("/", "__")
    path = metadata_dir_path(base_dir, bucket_name) / f"{safe_name}.json"
    ensure_path_within_base(base_dir / bucket_name, path)
    return path


def compute_etag(data: bytes) -> str:
    # Compute a simple ETag using MD5.
    return hashlib.md5(data).hexdigest()  # noqa: S324


def write_json(file_path: Path, payload: dict[str, Any]) -> None:
    # Write JSON content to disk.
    file_path.parent.mkdir(parents=True, exist_ok=True)
    with file_path.open("w", encoding="utf-8") as file:
        json.dump(payload, file, indent=2, ensure_ascii=False)


def read_json(file_path: Path) -> dict[str, Any]:
    # Read JSON content from disk.
    with file_path.open("r", encoding="utf-8") as file:
        return json.load(file)  # type: ignore


def _xml_bytes(root: Element) -> bytes:
    # Serialize an XML tree with a standard XML declaration.
    body = tostring(root, encoding="utf-8", xml_declaration=True)
    return body  # type: ignore


def build_list_buckets_xml(buckets: list[dict[str, Any]]) -> bytes:
    # Build a minimal S3-style XML response for bucket listing.
    root = Element("ListAllMyBucketsResult")
    owner = SubElement(root, "Owner")
    SubElement(owner, "ID").text = "tiny-object-storage"
    SubElement(owner, "DisplayName").text = "tiny-object-storage"

    buckets_el = SubElement(root, "Buckets")
    for bucket in buckets:
        bucket_el = SubElement(buckets_el, "Bucket")
        SubElement(bucket_el, "Name").text = bucket["name"]
        if bucket.get("created_at"):
            created = parse_iso_datetime(bucket["created_at"])
            if created is not None:
                SubElement(bucket_el, "CreationDate").text = created.isoformat().replace(
                    "+00:00", "Z"
                )

    return _xml_bytes(root)


def build_list_objects_v2_xml(
    bucket_name: str,
    objects: list[dict[str, Any]],
    prefix: str = "",
    max_keys: int = 1000,
    is_truncated: bool = False,
) -> bytes:
    # Build a minimal S3 ListObjectsV2 XML response.
    root = Element("ListBucketResult")
    root.set("xmlns", "http://s3.amazonaws.com/doc/2006-03-01/")

    SubElement(root, "Name").text = bucket_name
    SubElement(root, "Prefix").text = prefix
    SubElement(root, "KeyCount").text = str(len(objects))
    SubElement(root, "MaxKeys").text = str(max_keys)
    SubElement(root, "IsTruncated").text = "true" if is_truncated else "false"

    for item in objects:
        contents = SubElement(root, "Contents")
        SubElement(contents, "Key").text = item["object_key"]

        updated = parse_iso_datetime(item.get("updated_at") or item.get("created_at"))
        if updated is not None:
            SubElement(contents, "LastModified").text = updated.isoformat().replace("+00:00", "Z")
        else:
            SubElement(contents, "LastModified").text = utc_now_iso().replace("+00:00", "Z")

        SubElement(contents, "ETag").text = f"\"{item['etag']}\""
        SubElement(contents, "Size").text = str(item["size"])
        SubElement(contents, "StorageClass").text = "STANDARD"

    return _xml_bytes(root)
