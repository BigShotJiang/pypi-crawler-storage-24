from typing import Any, BinaryIO

from tiny_object_storage.logging_config import get_logger
from tiny_object_storage.storage.base import BaseStorage, StoredObject


class ObjectService:
    # Handle object-related business logic.

    def __init__(self, storage: BaseStorage):
        # Store the configured storage backend.
        self.storage = storage
        self.logger = get_logger("tiny_object_storage.services.object")

    def put_object(
        self,
        bucket_name: str,
        object_key: str,
        data: bytes | BinaryIO,
        content_type: str | None = None,
    ) -> dict[str, Any]:
        # Store an object and return its metadata.
        self.logger.info(
            "Uploading object bucket=%s key=%s content_type=%s",
            bucket_name,
            object_key,
            content_type,
        )
        metadata = self.storage.put_object(
            bucket_name=bucket_name,
            object_key=object_key,
            data=data,
            content_type=content_type,
        )
        self.logger.info(
            "Object uploaded bucket=%s key=%s size=%s etag=%s",
            bucket_name,
            object_key,
            metadata["size"],
            metadata["etag"],
        )
        return metadata

    def get_object(self, bucket_name: str, object_key: str) -> StoredObject:
        # Return a stored object from the backend.
        self.logger.info("Downloading object bucket=%s key=%s", bucket_name, object_key)
        stored_object = self.storage.get_object(bucket_name=bucket_name, object_key=object_key)
        self.logger.info(
            "Object downloaded bucket=%s key=%s size=%s",
            bucket_name,
            object_key,
            stored_object.metadata["size"],
        )
        return stored_object

    def delete_object(self, bucket_name: str, object_key: str) -> None:
        # Delete an object from the backend.
        self.logger.info("Deleting object bucket=%s key=%s", bucket_name, object_key)
        self.storage.delete_object(bucket_name=bucket_name, object_key=object_key)
        self.logger.info("Object deleted bucket=%s key=%s", bucket_name, object_key)

    def list_objects(self, bucket_name: str) -> list[dict[str, Any]]:
        # Return all objects for the requested bucket.
        self.logger.info("Listing objects bucket=%s", bucket_name)
        objects = self.storage.list_objects(bucket_name=bucket_name)
        self.logger.info("Objects listed bucket=%s count=%s", bucket_name, len(objects))
        return objects

    def object_exists(self, bucket_name: str, object_key: str) -> bool:
        # Return whether the given object exists.
        self.logger.debug("Checking object existence bucket=%s key=%s", bucket_name, object_key)
        exists = self.storage.object_exists(bucket_name=bucket_name, object_key=object_key)
        self.logger.debug(
            "Object existence checked bucket=%s key=%s exists=%s",
            bucket_name,
            object_key,
            exists,
        )
        return exists
