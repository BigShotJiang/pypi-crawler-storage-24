from typing import Any

from tiny_object_storage.logging_config import get_logger
from tiny_object_storage.storage.base import BaseStorage


class BucketService:
    # Handle bucket-related business logic.

    def __init__(self, storage: BaseStorage):
        # Store the configured storage backend.
        self.storage = storage
        self.logger = get_logger("tiny_object_storage.services.bucket")

    def create_bucket(self, bucket_name: str) -> dict[str, Any]:
        # Create a bucket and return its metadata.
        self.logger.info("Creating bucket bucket=%s", bucket_name)
        self.storage.create_bucket(bucket_name)

        for bucket in self.storage.list_buckets():
            if bucket["name"] == bucket_name:
                self.logger.info("Bucket created bucket=%s", bucket_name)
                return bucket

        result = {
            "name": bucket_name,
            "created_at": None,
        }
        self.logger.info("Bucket created bucket=%s", bucket_name)
        return result

    def delete_bucket(self, bucket_name: str) -> None:
        # Delete an existing bucket.
        self.logger.info("Deleting bucket bucket=%s", bucket_name)
        self.storage.delete_bucket(bucket_name)
        self.logger.info("Bucket deleted bucket=%s", bucket_name)

    def list_buckets(self) -> list[dict[str, Any]]:
        # Return all buckets from the storage backend.
        self.logger.info("Listing buckets")
        buckets = self.storage.list_buckets()
        self.logger.info("Buckets listed count=%s", len(buckets))
        return buckets

    def bucket_exists(self, bucket_name: str) -> bool:
        # Return whether the given bucket exists.
        self.logger.debug("Checking bucket existence bucket=%s", bucket_name)
        exists = self.storage.bucket_exists(bucket_name)
        self.logger.debug("Bucket existence checked bucket=%s exists=%s", bucket_name, exists)
        return exists
