import argparse
import os
from pathlib import Path

import uvicorn
from dotenv import load_dotenv

from tiny_object_storage.config import get_settings


def str_to_bool(value: str) -> bool:
    # Convert common string values to boolean.
    normalized = value.strip().lower()
    if normalized in {"1", "true", "yes", "y", "on"}:
        return True
    if normalized in {"0", "false", "no", "n", "off"}:
        return False
    raise argparse.ArgumentTypeError(f"Invalid boolean value: {value}")


def build_parser() -> argparse.ArgumentParser:
    # Build the CLI argument parser.
    parser = argparse.ArgumentParser(
        prog="tos-server",
        description="Run the tiny-object-storage server.",
    )

    parser.add_argument(
        "--env-file",
        default=".env",
        help="Path to the .env file to load before starting the server.",
    )
    parser.add_argument(
        "--host",
        help="Override server host.",
    )
    parser.add_argument(
        "--port",
        type=int,
        help="Override server port.",
    )
    parser.add_argument(
        "--log-level",
        choices=["critical", "error", "warning", "info", "debug", "trace"],
        help="Override uvicorn log level.",
    )
    parser.add_argument(
        "--reload",
        action="store_true",
        help="Enable auto-reload.",
    )
    parser.add_argument(
        "--no-reload",
        action="store_true",
        help="Disable auto-reload even if dev mode is enabled.",
    )
    parser.add_argument(
        "--data-dir",
        help="Override storage data directory.",
    )
    parser.add_argument(
        "--log-dir",
        help="Override application log directory.",
    )
    parser.add_argument(
        "--dev-mode",
        type=str_to_bool,
        help="Override development mode.",
    )
    parser.add_argument(
        "--max-object-size",
        type=int,
        help="Override maximum object size in bytes.",
    )

    return parser


def main() -> None:
    # Load configuration sources, apply CLI overrides, and start the server.
    parser = build_parser()
    args = parser.parse_args()

    env_file = Path(args.env_file)
    if env_file.exists():
        load_dotenv(dotenv_path=env_file, override=False)

    if args.host is not None:
        os.environ["TOS_HOST"] = args.host

    if args.port is not None:
        os.environ["TOS_PORT"] = str(args.port)

    if args.data_dir is not None:
        os.environ["TOS_DATA_DIR"] = args.data_dir

    if args.log_dir is not None:
        os.environ["TOS_LOG_DIR"] = args.log_dir

    if args.dev_mode is not None:
        os.environ["TOS_DEV_MODE"] = "true" if args.dev_mode else "false"

    if args.max_object_size is not None:
        os.environ["TOS_MAX_OBJECT_SIZE"] = str(args.max_object_size)

    if args.log_level is not None:
        os.environ["TOS_LOG_LEVEL"] = args.log_level.upper()

    get_settings.cache_clear()
    settings = get_settings()

    reload_enabled = settings.dev_mode
    if args.reload:
        reload_enabled = True
    if args.no_reload:
        reload_enabled = False

    uvicorn.run(
        "tiny_object_storage.main:app",
        host=settings.host,
        port=settings.port,
        reload=reload_enabled,
        log_level=settings.log_level.lower(),
    )


if __name__ == "__main__":
    main()
