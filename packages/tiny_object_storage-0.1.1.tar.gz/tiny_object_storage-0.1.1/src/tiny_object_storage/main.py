import time
from collections.abc import AsyncIterator, Awaitable, Callable
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.responses import Response

from tiny_object_storage.api.buckets import router as buckets_router
from tiny_object_storage.api.health import router as health_router
from tiny_object_storage.api.objects import router as objects_router
from tiny_object_storage.config import get_settings
from tiny_object_storage.core.errors import (
    BucketAlreadyExistsError,
    BucketNotEmptyError,
    BucketNotFoundError,
    InvalidBucketNameError,
    InvalidObjectKeyError,
    ObjectNotFoundError,
)
from tiny_object_storage.logging_config import configure_logging, get_logger
from tiny_object_storage.services.bucket_service import BucketService
from tiny_object_storage.services.object_service import ObjectService
from tiny_object_storage.storage.filesystem import FilesystemStorage


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    # Initialize application resources during startup.
    settings = get_settings()
    configure_logging(log_dir=settings.log_dir, log_level=settings.log_level)

    storage = FilesystemStorage(base_dir=settings.data_dir)
    bucket_service = BucketService(storage=storage)
    object_service = ObjectService(storage=storage)

    app.state.settings = settings
    app.state.logger = get_logger("tiny_object_storage.main")
    app.state.storage = storage
    app.state.bucket_service = bucket_service
    app.state.object_service = object_service

    app.state.logger.info("Starting %s", settings.app_name)
    app.state.logger.info("Host: %s", settings.host)
    app.state.logger.info("Port: %s", settings.port)
    app.state.logger.info("Data directory: %s", settings.data_dir)
    app.state.logger.info("Log directory: %s", settings.log_dir)
    app.state.logger.info("Log level: %s", settings.log_level)
    app.state.logger.info("Dev mode: %s", settings.dev_mode)

    yield

    app.state.logger.info("Shutting down %s", settings.app_name)


app = FastAPI(
    title="tiny-object-storage",
    version="0.1.0",
    summary="A lightweight S3-style object storage server.",
    description=(
        "tiny-object-storage is a lightweight S3-style object storage server for local "
        "development, testing, and learning. It provides bucket and object operations, "
        "file-based persistence, structured logging, and OpenAPI documentation."
    ),
    lifespan=lifespan,
)


@app.middleware("http")
async def request_logging_middleware(
    request: Request, call_next: Callable[[Request], Awaitable[Response]]
) -> Response:
    # Log incoming requests and their response status.
    logger = get_logger("tiny_object_storage.api")
    started_at = time.perf_counter()

    try:
        response = await call_next(request)
    except Exception:
        duration_ms = (time.perf_counter() - started_at) * 1000
        logger.exception(
            "Unhandled request error method=%s path=%s duration_ms=%.2f",
            request.method,
            request.url.path,
            duration_ms,
        )
        raise

    duration_ms = (time.perf_counter() - started_at) * 1000
    logger.info(
        "Request completed method=%s path=%s status_code=%s duration_ms=%.2f",
        request.method,
        request.url.path,
        response.status_code,
        duration_ms,
    )
    return response


def _build_xml_error(code: str, message: str) -> str:
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<Error>
    <Code>{code}</Code>
    <Message>{message}</Message>
</Error>"""


@app.exception_handler(InvalidBucketNameError)
async def invalid_bucket_name_handler(request: Request, exc: InvalidBucketNameError) -> Response:
    logger = get_logger("tiny_object_storage.main")
    logger.warning("Invalid bucket name path=%s message=%s", request.url.path, str(exc))
    return Response(
        status_code=400,
        content=_build_xml_error("InvalidBucketName", str(exc)),
        media_type="application/xml",
    )


@app.exception_handler(InvalidObjectKeyError)
async def invalid_object_key_handler(request: Request, exc: InvalidObjectKeyError) -> Response:
    logger = get_logger("tiny_object_storage.main")
    logger.warning("Invalid object key path=%s message=%s", request.url.path, str(exc))
    return Response(
        status_code=400,
        content=_build_xml_error("InvalidObjectKey", str(exc)),
        media_type="application/xml",
    )


@app.exception_handler(BucketAlreadyExistsError)
async def bucket_already_exists_handler(
    request: Request, exc: BucketAlreadyExistsError
) -> Response:
    logger = get_logger("tiny_object_storage.main")
    logger.warning("Bucket already exists path=%s message=%s", request.url.path, str(exc))
    return Response(
        status_code=409,
        content=_build_xml_error("BucketAlreadyExists", str(exc)),
        media_type="application/xml",
    )


@app.exception_handler(BucketNotFoundError)
async def bucket_not_found_handler(request: Request, exc: BucketNotFoundError) -> Response:
    logger = get_logger("tiny_object_storage.main")
    logger.warning("Bucket not found path=%s message=%s", request.url.path, str(exc))
    return Response(
        status_code=404,
        content=_build_xml_error("NoSuchBucket", str(exc)),
        media_type="application/xml",
    )


@app.exception_handler(BucketNotEmptyError)
async def bucket_not_empty_handler(request: Request, exc: BucketNotEmptyError) -> Response:
    logger = get_logger("tiny_object_storage.main")
    logger.warning("Bucket not empty path=%s message=%s", request.url.path, str(exc))
    return Response(
        status_code=409,
        content=_build_xml_error("BucketNotEmpty", str(exc)),
        media_type="application/xml",
    )


@app.exception_handler(ObjectNotFoundError)
async def object_not_found_handler(request: Request, exc: ObjectNotFoundError) -> Response:
    logger = get_logger("tiny_object_storage.main")
    logger.warning("Object not found path=%s message=%s", request.url.path, str(exc))
    return Response(
        status_code=404,
        content=_build_xml_error("NoSuchKey", str(exc)),
        media_type="application/xml",
    )


@app.exception_handler(ValueError)
async def value_error_handler(request: Request, exc: ValueError) -> Response:
    logger = get_logger("tiny_object_storage.main")
    logger.warning("Invalid request value path=%s message=%s", request.url.path, str(exc))
    return Response(
        status_code=400,
        content=_build_xml_error("InvalidArgument", str(exc)),
        media_type="application/xml",
    )


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception) -> Response:
    logger = get_logger("tiny_object_storage.main")
    logger.exception("Unhandled application error path=%s", request.url.path)
    return Response(
        status_code=500,
        content=_build_xml_error("InternalError", "An unexpected error occurred."),
        media_type="application/xml",
    )


app.include_router(health_router)
app.include_router(buckets_router)
app.include_router(objects_router)
