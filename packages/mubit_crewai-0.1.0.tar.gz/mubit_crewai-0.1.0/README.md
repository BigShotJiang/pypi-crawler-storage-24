# `mubit-crewai`

CrewAI memory backend backed by [MuBit](https://mubit.ai).

This adapter provides a `StorageBackend`-compatible class for CrewAI's Memory system, routing all memory operations through MuBit's control plane. Also includes an extended `MubitCrewMemory` class with MAS coordination helpers.

## Install

```bash
pip install mubit-crewai[crewai]
```

## Basic usage

### Drop-in StorageBackend

```python
from mubit_crewai import MubitStorage
from crewai import Crew
from crewai.memory import Memory

storage = MubitStorage(api_key="mbt_...", session_id="crew-run-1")
crew = Crew(
    agents=[...],
    memory=Memory(storage=storage),
)
```

### Extended MuBit features

```python
from mubit_crewai import MubitCrewMemory

memory = MubitCrewMemory(api_key="mbt_...", session_id="crew-run-1")
crew = Crew(agents=[...], memory=memory.as_crew_memory())

# Extended:
context = memory.get_context("What do we know about the customer?")
memory.checkpoint("Finished research phase")
memory.record_outcome("task-123", "success", rationale="All tests passed")
memory.handoff("researcher", "writer", "Here are the findings...")
```

## StorageBackend interface

| Method | MuBit mapping |
| --- | --- |
| `save(value, metadata, agent_id)` | `control.ingest` with intent from metadata |
| `search(query, limit, score_threshold)` | `control.query` with score filtering |
| `reset()` | `control.delete_run` |

## Intent inference

The `memory_type` metadata key maps to MuBit intents:

| `memory_type` | MuBit intent |
| --- | --- |
| `short_term` | `trace` |
| `long_term` | `lesson` |
| `entity` | `fact` |

## MuBit extension methods

- `get_context()` — assembled context retrieval
- `checkpoint()` — save memory state snapshot
- `record_outcome()` — outcome feedback for tasks
- `surface_strategies()` — strategy clusters from lessons
- `register_agent()` — MAS agent registration
- `handoff()` — agent-to-agent handoff
- `diagnose()` — failure-path lesson surfacing

## Config

| Parameter | Default | Purpose |
| --- | --- | --- |
| `endpoint` | `http://127.0.0.1:3000` | MuBit HTTP endpoint |
| `api_key` | `""` | MuBit API key |
| `session_id` | `"default"` | Session/run scope |
| `agent_id` | `"crewai"` | Default agent ID |

For tests, inject `mubit_client` directly.

## Development

```bash
PYTHONPATH=sdk/python/mubit-sdk/src:integrations/python \
python3 -m unittest integrations.python.mubit_crewai.tests.test_storage -v
```

## License

Apache-2.0
