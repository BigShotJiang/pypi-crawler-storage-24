from __future__ import annotations

import importlib
import sys
import types
import unittest
from pathlib import Path


def install_crewai_stub() -> None:
    """Install minimal crewai stubs so we can import mubit_crewai without crewai."""
    storage_interface = types.ModuleType("crewai.memory.storage.interface")

    class Storage:
        def save(self, value, metadata, agent_id): ...
        def search(self, query, limit, score_threshold): ...
        def reset(self): ...

    storage_interface.Storage = Storage

    crewai = types.ModuleType("crewai")
    memory_mod = types.ModuleType("crewai.memory")
    storage_mod = types.ModuleType("crewai.memory.storage")
    crewai.memory = memory_mod
    memory_mod.storage = storage_mod
    storage_mod.interface = storage_interface

    sys.modules["crewai"] = crewai
    sys.modules["crewai.memory"] = memory_mod
    sys.modules["crewai.memory.storage"] = storage_mod
    sys.modules["crewai.memory.storage.interface"] = storage_interface


class MockClient:
    def __init__(self) -> None:
        self.calls: list[tuple[str, dict]] = []

    def remember(self, **payload):
        self.calls.append(("remember", payload))
        return {"accepted": True, "job_id": "job-1"}

    def recall(self, **payload):
        self.calls.append(("recall", payload))
        return {
            "evidence": [
                {
                    "id": "mem-1",
                    "content": "Stored text",
                    "metadata_json": '{"author":"planner","kind":"lesson"}',
                    "score": 0.88,
                }
            ]
        }

    def get_context(self, **payload):
        self.calls.append(("get_context", payload))
        return {"context_block": "assembled context"}

    def delete_run(self, **payload):
        self.calls.append(("delete_run", payload))
        return {"success": True}

    def checkpoint(self, **payload):
        self.calls.append(("checkpoint", payload))
        return {"success": True}

    def record_outcome(self, **payload):
        self.calls.append(("record_outcome", payload))
        return {"success": True}

    def surface_strategies(self, **payload):
        self.calls.append(("surface_strategies", payload))
        return {"strategies": []}

    def register_agent(self, **payload):
        self.calls.append(("register_agent", payload))
        return {"success": True}

    def handoff(self, **payload):
        self.calls.append(("handoff", payload))
        return {"success": True, "handoff_id": "handoff-1"}

    def diagnose(self, **payload):
        self.calls.append(("diagnose", payload))
        return {"failure_lessons": []}


class TestMubitStorage(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        install_crewai_stub()
        package_root = Path(__file__).resolve().parents[2]
        if str(package_root) not in sys.path:
            sys.path.insert(0, str(package_root))
        cls.module = importlib.import_module("mubit_crewai")

    def test_save_routes_through_remember(self) -> None:
        client = MockClient()
        storage = self.module.MubitStorage(
            session_id="crew-run-1",
            mubit_client=client,
        )

        storage.save(
            value="Always run canary before rollout.",
            metadata={"intent": "lesson", "memory_type": "long_term"},
            agent_id="researcher",
        )

        self.assertEqual(len(client.calls), 1)
        name, payload = client.calls[0]
        self.assertEqual(name, "remember")
        self.assertEqual(payload["session_id"], "crew-run-1")
        self.assertEqual(payload["text"], "Always run canary before rollout.")
        self.assertEqual(payload["intent"], "lesson")
        self.assertEqual(payload["agent_id"], "researcher")

    def test_search_returns_crewai_format(self) -> None:
        client = MockClient()
        storage = self.module.MubitStorage(
            session_id="crew-run-1",
            mubit_client=client,
        )

        results = storage.search(query="rollout lessons", limit=5, score_threshold=0.5)

        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["context"], "Stored text")
        self.assertEqual(results[0]["score"], 0.88)
        self.assertEqual(results[0]["metadata"]["author"], "planner")

    def test_search_filters_by_score_threshold(self) -> None:
        client = MockClient()
        storage = self.module.MubitStorage(
            session_id="crew-run-1",
            mubit_client=client,
        )

        results = storage.search(query="test", limit=5, score_threshold=0.95)

        self.assertEqual(len(results), 0)

    def test_reset_calls_delete_run(self) -> None:
        client = MockClient()
        storage = self.module.MubitStorage(
            session_id="crew-run-1",
            mubit_client=client,
        )

        storage.reset()

        self.assertEqual(len(client.calls), 1)
        self.assertEqual(client.calls[0][0], "delete_run")
        self.assertEqual(client.calls[0][1]["session_id"], "crew-run-1")

    def test_infer_intent_from_memory_type(self) -> None:
        client = MockClient()
        storage = self.module.MubitStorage(
            session_id="crew-run-1",
            mubit_client=client,
        )

        storage.save(value="short term info", metadata={"memory_type": "short_term"})
        storage.save(value="entity info", metadata={"memory_type": "entity"})

        self.assertEqual(client.calls[0][1]["intent"], "trace")
        self.assertEqual(client.calls[1][1]["intent"], "fact")


class TestMubitCrewMemory(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        install_crewai_stub()
        package_root = Path(__file__).resolve().parents[2]
        if str(package_root) not in sys.path:
            sys.path.insert(0, str(package_root))
        cls.module = importlib.import_module("mubit_crewai")

    def test_get_context_returns_context_block(self) -> None:
        client = MockClient()
        memory = self.module.MubitCrewMemory(
            session_id="crew-run-1",
            mubit_client=client,
        )

        result = memory.get_context("What do we know?")

        self.assertEqual(result, "assembled context")
        self.assertEqual(client.calls[0][0], "get_context")

    def test_checkpoint_routes_to_client(self) -> None:
        client = MockClient()
        memory = self.module.MubitCrewMemory(
            session_id="crew-run-1",
            mubit_client=client,
        )

        memory.checkpoint("Finished research phase")

        self.assertEqual(client.calls[0][0], "checkpoint")
        self.assertEqual(client.calls[0][1]["snapshot"], "Finished research phase")

    def test_record_outcome_routes_to_client(self) -> None:
        client = MockClient()
        memory = self.module.MubitCrewMemory(
            session_id="crew-run-1",
            mubit_client=client,
        )

        memory.record_outcome("task-123", "success", rationale="All tests passed")

        self.assertEqual(client.calls[0][0], "record_outcome")
        self.assertEqual(client.calls[0][1]["reference_id"], "task-123")
        self.assertEqual(client.calls[0][1]["outcome"], "success")

    def test_handoff_routes_to_client(self) -> None:
        client = MockClient()
        memory = self.module.MubitCrewMemory(
            session_id="crew-run-1",
            mubit_client=client,
        )

        memory.handoff("researcher", "writer", "Here are the findings")

        self.assertEqual(client.calls[0][0], "handoff")
        self.assertEqual(client.calls[0][1]["from_agent_id"], "researcher")
        self.assertEqual(client.calls[0][1]["to_agent_id"], "writer")

    def test_extension_methods_available(self) -> None:
        client = MockClient()
        memory = self.module.MubitCrewMemory(
            session_id="crew-run-1",
            mubit_client=client,
        )

        memory.get_context("status")
        memory.checkpoint("phase 1 done")
        memory.record_outcome("task-1", "success")
        memory.surface_strategies()
        memory.register_agent("planner", role="planner")
        memory.handoff("a", "b", "content")
        memory.diagnose("error occurred")

        self.assertEqual(
            [name for name, _ in client.calls],
            [
                "get_context",
                "checkpoint",
                "record_outcome",
                "surface_strategies",
                "register_agent",
                "handoff",
                "diagnose",
            ],
        )


if __name__ == "__main__":
    unittest.main()
