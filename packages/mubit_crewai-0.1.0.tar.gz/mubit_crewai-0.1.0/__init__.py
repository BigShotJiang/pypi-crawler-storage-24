"""
mubit-crewai — CrewAI memory backend backed by MuBit.

Provides a StorageBackend-compatible adapter for CrewAI's Memory system,
plus a convenience MubitCrewMemory class for easy setup.
"""

from __future__ import annotations

import json
import threading
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from .mubit_client import MubitControlClient, normalize_metadata

try:
    from crewai.memory.storage.backend import StorageBackend
    from crewai.memory.types import MemoryRecord, ScopeInfo

    _HAS_CREWAI = True
except ImportError:
    _HAS_CREWAI = False

    class StorageBackend:
        """Fallback base class when crewai is not installed."""
        pass

    class MemoryRecord:
        """Fallback stub."""
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    class ScopeInfo:
        """Fallback stub."""
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)


class MubitStorage(StorageBackend):
    """CrewAI StorageBackend backed by MuBit memory engine.

    Drop-in replacement for CrewAI's default storage, routing all
    memory operations through MuBit's control plane.

    Usage::

        from mubit_crewai import MubitStorage
        from crewai import Crew
        from crewai.memory import Memory

        storage = MubitStorage(api_key="mbt_...", session_id="crew-run-1")
        crew = Crew(
            agents=[...],
            memory=Memory(storage=storage),
        )
    """

    def __init__(
        self,
        *,
        endpoint: str = "http://127.0.0.1:3000",
        api_key: str = "",
        session_id: str = "default",
        user_id: str = "",
        agent_id: str = "crewai",
        mubit_client: Optional[Any] = None,
    ) -> None:
        self._session_id = session_id
        self._user_id = user_id
        self._default_agent_id = agent_id
        self._client = mubit_client or MubitControlClient(
            endpoint=endpoint.rstrip("/"), api_key=api_key
        )
        # Local tracking for scope/record listing
        self._scopes: dict[str, set[str]] = {}  # scope -> set of record_ids
        self._records: dict[str, Any] = {}  # record_id -> MemoryRecord-like
        self._write_lock = threading.Lock()

    @property
    def write_lock(self):
        """Thread lock for concurrent write safety."""
        return self._write_lock

    def save(self, records: list, **kwargs) -> None:
        """Store memory records in MuBit.

        Accepts both new-style list[MemoryRecord] and legacy (value, metadata, agent_id).
        """
        # Handle legacy call signature: save(value, metadata, agent_id)
        if records and isinstance(records, str):
            return self._save_legacy(records, kwargs.get("metadata"), kwargs.get("agent_id"))

        for record in records:
            content = getattr(record, "content", "") if not isinstance(record, dict) else record.get("content", "")
            record_id = getattr(record, "id", str(uuid.uuid4())) if not isinstance(record, dict) else record.get("id", str(uuid.uuid4()))
            scope = getattr(record, "scope", "/") if not isinstance(record, dict) else record.get("scope", "/")
            categories = getattr(record, "categories", []) if not isinstance(record, dict) else record.get("categories", [])
            metadata = getattr(record, "metadata", {}) if not isinstance(record, dict) else record.get("metadata", {})
            importance = getattr(record, "importance", 0.5) if not isinstance(record, dict) else record.get("importance", 0.5)
            source = getattr(record, "source", None) if not isinstance(record, dict) else record.get("source")

            intent = _infer_intent_from_categories(categories)

            self._client.remember(
                session_id=self._session_id,
                user_id=self._user_id or None,
                text=content,
                agent_id=self._default_agent_id,
                intent=intent,
                source=source,
                upsert_key=record_id,
                metadata={
                    "scope": scope,
                    "categories": categories,
                    "importance": importance,
                    **(metadata or {}),
                },
            )

            # Track locally
            self._scopes.setdefault(scope, set()).add(record_id)
            self._records[record_id] = record

    def _save_legacy(self, value: str, metadata=None, agent_id=None):
        """Handle legacy save(value, metadata, agent_id) call."""
        meta = dict(metadata or {})
        intent = meta.pop("intent", None) or _infer_intent(meta)
        self._client.remember(
            session_id=self._session_id,
            user_id=self._user_id or None,
            text=value,
            agent_id=agent_id or self._default_agent_id,
            intent=intent,
            metadata=meta if meta else None,
        )

    def search(
        self,
        query_embedding: list = None,
        scope_prefix: str = None,
        categories: list = None,
        metadata_filter: dict = None,
        limit: int = 10,
        min_score: float = 0.0,
        **kwargs,
    ) -> list:
        """Search memories in MuBit.

        Uses MuBit's semantic search. Since MuBit does its own embedding,
        we use a text-based query derived from scope/categories context.
        """
        # Handle legacy call: search(query_str, limit, score_threshold)
        if isinstance(query_embedding, str):
            return self._search_legacy(query_embedding, limit=limit, score_threshold=min_score)

        # Build a text query from available context
        query_parts = []
        if scope_prefix:
            query_parts.append(scope_prefix.replace("/", " "))
        if categories:
            query_parts.append(" ".join(categories))
        query_text = " ".join(query_parts) or "recent memories"

        data = self._client.recall(
            session_id=self._session_id,
            user_id=self._user_id or None,
            query=query_text,
            limit=limit,
        )

        results = []
        for ev in data.get("evidence", []):
            score = ev.get("score", 0.0)
            if score < min_score:
                continue
            now = datetime.now(timezone.utc)
            meta = normalize_metadata(ev)
            if _HAS_CREWAI:
                raw_importance = meta.get("importance", 0.5)
                try:
                    importance_val = float(raw_importance)
                except (ValueError, TypeError):
                    importance_val = 0.5
                record = MemoryRecord(
                    id=ev.get("id", str(uuid.uuid4())),
                    content=ev.get("content", ""),
                    scope=str(meta.get("scope", "/")),
                    categories=meta.get("categories") if isinstance(meta.get("categories"), list) else [],
                    metadata={k: v for k, v in meta.items() if k not in ("scope", "categories", "importance")},
                    importance=importance_val,
                    created_at=now,
                    last_accessed=now,
                )
            else:
                record = {
                    "context": ev.get("content", ""),
                    "metadata": meta,
                    "score": score,
                }
            results.append((record, score))

        return results

    def _search_legacy(self, query: str, limit: int = 3, score_threshold: float = 0.0) -> list:
        """Handle legacy search(query, limit, score_threshold)."""
        data = self._client.recall(
            session_id=self._session_id,
            user_id=self._user_id or None,
            query=query,
            limit=limit,
        )
        results = []
        for ev in data.get("evidence", []):
            score = ev.get("score", 0.0)
            if score < score_threshold:
                continue
            results.append({
                "context": ev.get("content", ""),
                "metadata": normalize_metadata(ev),
                "score": score,
            })
        return results

    def list_scopes(self, parent: str = "/") -> list:
        """List known memory scopes."""
        return [s for s in self._scopes if s.startswith(parent)]

    def list_categories(self, scope_prefix: str = None) -> dict:
        """List categories with counts."""
        return {}

    def list_records(self, scope_prefix: str = None, limit: int = 200, offset: int = 0) -> list:
        """List records in scope."""
        records = list(self._records.values())
        if scope_prefix:
            records = [r for r in records if getattr(r, "scope", "/").startswith(scope_prefix)]
        return records[offset:offset + limit]

    def count(self, scope_prefix: str = None) -> int:
        """Count records in scope."""
        if scope_prefix:
            return sum(1 for r in self._records.values() if getattr(r, "scope", "/").startswith(scope_prefix))
        return len(self._records)

    def get_record(self, record_id: str):
        """Get a record by ID."""
        return self._records.get(record_id)

    def get_scope_info(self, scope: str):
        """Get info about a scope."""
        ids = self._scopes.get(scope, set())
        now = datetime.now(timezone.utc)
        if _HAS_CREWAI:
            return ScopeInfo(
                path=scope,
                record_count=len(ids),
                categories=[],
                oldest_record=now,
                newest_record=now,
                child_scopes=[],
            )
        return {"path": scope, "record_count": len(ids)}

    def update(self, record) -> None:
        """Update a record."""
        record_id = getattr(record, "id", None)
        if record_id:
            self._records[record_id] = record
            content = getattr(record, "content", "")
            if content:
                self._client.remember(
                    session_id=self._session_id,
                    user_id=self._user_id or None,
                    text=content,
                    agent_id=self._default_agent_id,
                    intent="trace",
                    upsert_key=record_id,
                )

    def delete(
        self,
        scope_prefix: str = None,
        categories: list = None,
        record_ids: list = None,
        older_than=None,
        metadata_filter: dict = None,
    ) -> int:
        """Delete records matching criteria."""
        count = 0
        if record_ids:
            for rid in record_ids:
                if rid in self._records:
                    del self._records[rid]
                    count += 1
        return count

    def reset(self, scope_prefix: str = None) -> None:
        """Clear all memories for the current session."""
        self._client.delete_run(session_id=self._session_id)
        self._scopes.clear()
        self._records.clear()


class MubitCrewMemory:
    """Convenience class for integrating MuBit memory with CrewAI.

    Provides both the StorageBackend for CrewAI and extended MuBit
    capabilities (context retrieval, reflection, MAS coordination).

    Usage::

        from mubit_crewai import MubitCrewMemory

        memory = MubitCrewMemory(api_key="mbt_...", session_id="crew-run-1")
        crew = Crew(agents=[...], memory=memory.as_crew_memory())

        # Extended MuBit features
        context = memory.get_context("What do we know about the customer?")
        memory.checkpoint("Finished research phase")
        memory.record_outcome("task-123", "success", rationale="All tests passed")
    """

    def __init__(
        self,
        *,
        endpoint: str = "http://127.0.0.1:3000",
        api_key: str = "",
        session_id: str = "default",
        user_id: str = "",
        agent_id: str = "crewai",
        mubit_client: Optional[Any] = None,
    ) -> None:
        self._session_id = session_id
        self._user_id = user_id
        self._agent_id = agent_id
        self._client = mubit_client or MubitControlClient(
            endpoint=endpoint.rstrip("/"), api_key=api_key
        )
        self._storage = MubitStorage(
            session_id=session_id,
            user_id=user_id,
            agent_id=agent_id,
            mubit_client=self._client,
        )

    @property
    def storage(self) -> MubitStorage:
        """Return the StorageBackend for CrewAI."""
        return self._storage

    def as_crew_memory(self) -> Any:
        """Create a CrewAI Memory instance backed by MuBit.

        Returns:
            A crewai.memory.Memory instance using MuBit storage.

        Raises:
            ImportError: If crewai is not installed.
        """
        try:
            from crewai.memory import Memory
            return Memory(storage=self._storage)
        except ImportError:
            raise ImportError(
                "crewai is required: pip install mubit-crewai[crewai]"
            )

    def get_context(
        self,
        query: str,
        *,
        mode: Optional[str] = None,
        sections: Optional[List[str]] = None,
        entry_types: Optional[List[str]] = None,
        max_token_budget: int = 2048,
    ) -> str:
        """Fetch assembled context from MuBit.

        Returns:
            Pre-formatted context string.
        """
        result = self._client.get_context(
            session_id=self._session_id,
            user_id=self._user_id or None,
            query=query,
            mode=mode,
            sections=sections,
            entry_types=entry_types,
            max_token_budget=max_token_budget,
            agent_id=self._agent_id,
        )
        return result.get("context_block", "")

    def checkpoint(
        self,
        snapshot: str,
        *,
        label: str = "",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Create a checkpoint of current memory state."""
        return self._client.checkpoint(
            session_id=self._session_id,
            user_id=self._user_id or None,
            snapshot=snapshot,
            label=label,
            metadata=metadata,
            agent_id=self._agent_id,
        )

    def record_outcome(
        self,
        reference_id: str,
        outcome: str,
        *,
        signal: Optional[float] = None,
        rationale: str = "",
    ) -> Dict[str, Any]:
        """Record outcome feedback for a task or decision."""
        return self._client.record_outcome(
            session_id=self._session_id,
            user_id=self._user_id or None,
            reference_id=reference_id,
            outcome=outcome,
            signal=signal,
            rationale=rationale,
            agent_id=self._agent_id,
        )

    def surface_strategies(
        self,
        *,
        lesson_types: Optional[List[str]] = None,
        max_strategies: int = 5,
    ) -> Dict[str, Any]:
        """Surface strategy clusters from lessons."""
        return self._client.surface_strategies(
            session_id=self._session_id,
            user_id=self._user_id or None,
            lesson_types=lesson_types,
            max_strategies=max_strategies,
        )

    def register_agent(
        self,
        agent_id: str,
        *,
        role: Optional[str] = None,
        status: Optional[str] = None,
        read_scopes: Optional[List[str]] = None,
        write_scopes: Optional[List[str]] = None,
        shared_memory_lanes: Optional[List[str]] = None,
        capabilities: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Register an agent for MAS coordination."""
        return self._client.register_agent(
            session_id=self._session_id,
            user_id=self._user_id or None,
            agent_id=agent_id,
            role=role,
            status=status,
            read_scopes=read_scopes,
            write_scopes=write_scopes,
            shared_memory_lanes=shared_memory_lanes,
            capabilities=capabilities,
        )

    def handoff(
        self,
        from_agent_id: str,
        to_agent_id: str,
        content: str,
        *,
        requested_action: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Create a handoff between agents."""
        return self._client.handoff(
            session_id=self._session_id,
            user_id=self._user_id or None,
            from_agent_id=from_agent_id,
            to_agent_id=to_agent_id,
            content=content,
            requested_action=requested_action,
            metadata=metadata,
        )

    def diagnose(
        self,
        error_text: str,
        *,
        error_type: Optional[str] = None,
        limit: int = 10,
    ) -> Dict[str, Any]:
        """Surface failure-path lessons for debugging."""
        return self._client.diagnose(
            session_id=self._session_id,
            user_id=self._user_id or None,
            error_text=error_text,
            error_type=error_type,
            limit=limit,
        )


def _infer_intent(metadata: Dict[str, Any]) -> str:
    """Infer intent from CrewAI metadata (legacy)."""
    memory_type = metadata.pop("memory_type", None)
    if memory_type == "short_term":
        return "trace"
    if memory_type == "long_term":
        return "lesson"
    if memory_type == "entity":
        return "fact"
    return "trace"


def _infer_intent_from_categories(categories: list) -> str:
    """Infer MuBit intent from CrewAI memory categories."""
    if not categories:
        return "trace"
    cats = set(c.lower() for c in categories)
    if "lesson" in cats or "long_term" in cats:
        return "lesson"
    if "entity" in cats or "fact" in cats:
        return "fact"
    if "rule" in cats:
        return "rule"
    return "trace"
