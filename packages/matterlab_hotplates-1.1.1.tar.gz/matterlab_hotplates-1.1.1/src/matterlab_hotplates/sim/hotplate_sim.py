from __future__ import annotations

from dataclasses import dataclass

from matterlab_serial_device.transport import SerialTransport, SerialTransportConfig


@dataclass
class HotplateSimState:
    current_temp: float = 25.0
    target_temp: float = 0.0
    current_rpm: int = 0
    target_rpm: int = 0
    heat_on: bool = False
    stir_on: bool = False
    max_temp: int = 200
    max_rpm: int = 1400
    tare_status: int = 1041
    weight: float = 12.5
    name: str = "HB10"


class StatefulHotplateTransport(SerialTransport):
    def __init__(self, config: SerialTransportConfig, protocol) -> None:
        self.config = config
        self._protocol = protocol
        self._is_open = True
        self._pending_response = b""
        self.write_history: list[bytes] = []

    @property
    def is_open(self) -> bool:
        return self._is_open

    def open(self) -> None:
        self._is_open = True

    def close(self) -> None:
        self._is_open = False

    def write(self, data: bytes) -> None:
        self.write_history.append(data)
        self._pending_response = self._protocol(data, b"", None)

    def read_until(self, expected: bytes = b"\n", size: int | None = None) -> bytes:
        response = self._pending_response
        self._pending_response = b""
        if size is not None:
            response = response[:size]
        return response


class HeidolphSimProtocol:
    def __init__(self, state: HotplateSimState) -> None:
        self.state = state

    def __call__(self, write_data: bytes, expected: bytes, size: int | None) -> bytes:
        del expected, size
        command = write_data.decode("utf-8").strip()

        if command.startswith("OUT_SP_1 "):
            self.state.target_temp = float(command.split()[1])
            self.state.current_temp = self.state.target_temp if self.state.target_temp else self.state.current_temp
            return b""
        if command == "START_1":
            self.state.heat_on = True
            return b""
        if command == "STOP_1":
            self.state.heat_on = False
            self.state.target_temp = 0.0
            return b""
        if command.startswith("OUT_SP_3 "):
            self.state.target_rpm = int(command.split()[1])
            return b""
        if command == "START_2":
            self.state.stir_on = True
            if self.state.target_rpm > 0 and self.state.current_rpm == 0:
                self.state.current_rpm = min(self.state.target_rpm, max(1, self.state.target_rpm // 3))
            return b""
        if command == "STOP_2":
            self.state.stir_on = False
            self.state.target_rpm = 0
            self.state.current_rpm = 0
            return b""
        if command == "PA_NEW":
            return b""
        if command == "IN_PV_1":
            return f"IN_PV_1 {self.state.current_temp:.1f}\r\n".encode("utf-8")
        if command == "IN_PV_5":
            if self.state.stir_on and self.state.current_rpm < self.state.target_rpm:
                step = max(1, self.state.target_rpm // 3)
                self.state.current_rpm = min(self.state.target_rpm, self.state.current_rpm + step)
            return f"IN_PV_5 {self.state.current_rpm}\r\n".encode("utf-8")
        return b""


class IKAHotplateSimProtocol:
    def __init__(self, state: HotplateSimState) -> None:
        self.state = state

    def __call__(self, write_data: bytes, expected: bytes, size: int | None) -> bytes:
        del expected, size
        command = write_data.decode("utf-8").strip()

        if command == "RESET":
            self.state.current_temp = 25.0
            self.state.target_temp = 0.0
            self.state.current_rpm = 0
            self.state.target_rpm = 0
            self.state.heat_on = False
            self.state.stir_on = False
            return b""
        if command.startswith("OUT_SP_1 "):
            self.state.target_temp = float(command.split()[1])
            self.state.current_temp = self.state.target_temp if self.state.target_temp else self.state.current_temp
            return b""
        if command == "START_1":
            self.state.heat_on = True
            return b""
        if command == "STOP_1":
            self.state.heat_on = False
            self.state.target_temp = 0.0
            return b""
        if command.startswith("OUT_SP_4 "):
            self.state.target_rpm = int(command.split()[1])
            self.state.current_rpm = self.state.target_rpm
            return b""
        if command == "START_4":
            self.state.stir_on = True
            return b""
        if command == "STOP_4":
            self.state.stir_on = False
            self.state.target_rpm = 0
            self.state.current_rpm = 0
            return b""
        if command == "START_90":
            return b""
        if command == "STATUS_90":
            return f"{self.state.tare_status}\r\n".encode("utf-8")
        if command == "IN_PV_90":
            return f"{self.state.weight}\r\n".encode("utf-8")
        if command == "IN_PV_80":
            return b"7.0\r\n"
        if command == "IN_PV_1":
            return f"{self.state.current_temp}\r\n".encode("utf-8")
        if command == "IN_PV_4":
            return f"{self.state.current_rpm}\r\n".encode("utf-8")
        return b"OK\r\n"


class IKAHotbathSimProtocol:
    def __init__(self, state: HotplateSimState) -> None:
        self.state = state

    def __call__(self, write_data: bytes, expected: bytes, size: int | None) -> bytes:
        del expected, size
        command = write_data.decode("utf-8").strip()

        if command.startswith("OUT_SP_2 "):
            self.state.target_temp = float(command.split()[1])
            self.state.current_temp = self.state.target_temp if self.state.target_temp else self.state.current_temp
            return b"OK\r\n"
        if command.startswith("OUT_SP_3 "):
            self.state.max_temp = int(command.split()[1])
            return b"OK\r\n"
        if command == "START_1":
            self.state.heat_on = True
            return b"OK\r\n"
        if command == "STOP_1":
            self.state.heat_on = False
            self.state.target_temp = 0.0
            return b"OK\r\n"
        if command == "IN_NAME":
            return f"{self.state.name}\r\n".encode("utf-8")
        if command == "IN_PV_2":
            return f"{int(self.state.current_temp)}\r\n".encode("utf-8")
        if command == "IN_SP_3":
            return f"{int(self.state.max_temp)}\r\n".encode("utf-8")
        return b"OK\r\n"


def create_heidolph_sim_transport_factory(
    *,
    current_temp: float = 25.0,
    current_rpm: int = 0,
    max_temp: int = 200,
    max_rpm: int = 1400,
):
    state = HotplateSimState(current_temp=current_temp, current_rpm=current_rpm, max_temp=max_temp, max_rpm=max_rpm)
    protocol = HeidolphSimProtocol(state)

    def _factory(config: SerialTransportConfig):
        return StatefulHotplateTransport(config, protocol)

    _factory.state = state
    return _factory


def create_ika_hotplate_sim_transport_factory(
    *,
    current_temp: float = 25.0,
    current_rpm: int = 0,
    max_temp: int = 200,
    max_rpm: int = 1700,
    weight: float = 12.5,
):
    state = HotplateSimState(
        current_temp=current_temp,
        current_rpm=current_rpm,
        max_temp=max_temp,
        max_rpm=max_rpm,
        weight=weight,
    )
    protocol = IKAHotplateSimProtocol(state)

    def _factory(config: SerialTransportConfig):
        return StatefulHotplateTransport(config, protocol)

    _factory.state = state
    return _factory


def create_ika_hotbath_sim_transport_factory(
    *,
    current_temp: float = 25.0,
    max_temp: int = 80,
    name: str = "HB10",
):
    state = HotplateSimState(current_temp=current_temp, max_temp=max_temp, name=name)
    protocol = IKAHotbathSimProtocol(state)

    def _factory(config: SerialTransportConfig):
        return StatefulHotplateTransport(config, protocol)

    _factory.state = state
    return _factory
