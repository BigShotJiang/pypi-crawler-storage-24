from unittest.mock import patch

import pytest

from matterlab_hotplates.heidolph_hotplate import HeidolphHotplate
from tests.conftest import PORT


@pytest.fixture
def hotplate_fixture(mock_serial):
    return HeidolphHotplate(com_port=PORT, connect_hardware=False)


def test_initialization_defaults(mock_serial, hotplate_fixture):
    assert isinstance(hotplate_fixture, HeidolphHotplate)
    assert hotplate_fixture.max_temp == 200
    assert hotplate_fixture.max_rpm == 1400
    assert hotplate_fixture.device._connection is mock_serial


def test_default_initialization_sequence(mock_serial):
    with patch.object(HeidolphHotplate, "_set_new_interface_protocol", autospec=True) as protocol_spy, patch.object(
        HeidolphHotplate,
        "stand_by",
        autospec=True,
    ) as standby_spy:
        hotplate = HeidolphHotplate(com_port=PORT)

    protocol_spy.assert_called_once_with(hotplate)
    standby_spy.assert_called_once_with(hotplate)


def test_write_hotplate(hotplate_fixture, mocker):
    mocker.patch("matterlab_hotplates.heidolph_hotplate.time.sleep")
    write_spy = mocker.patch.object(hotplate_fixture, "write")

    hotplate_fixture._write_hotplate("test")

    write_spy.assert_called_once_with("test\r\n")


def test_query_hotplate(hotplate_fixture, mocker):
    query_spy = mocker.patch.object(hotplate_fixture, "query", return_value="IN_PV_1 55.0\r\n")

    assert hotplate_fixture._query_hotplate("test") == "55.0"

    query_spy.assert_called_once_with(write_command="test\r\n", remove_from_end=2, read_delay=0.5)


def test_set_new_interface_protocol(hotplate_fixture, mocker):
    write_spy = mocker.patch.object(hotplate_fixture, "_write_hotplate")

    hotplate_fixture._set_new_interface_protocol()

    write_spy.assert_called_once_with(command="PA_NEW")


def test_get_temp(hotplate_fixture, mocker):
    query_spy = mocker.patch.object(hotplate_fixture, "_query_hotplate", return_value="50.0")

    assert hotplate_fixture.temp == 50.0
    query_spy.assert_called_once_with(HeidolphHotplate._temp_query)


@pytest.mark.parametrize(
    ("temp", "switch_status", "switch_cmd"),
    [
        (0, False, HeidolphHotplate._heat_stop),
        (100, True, HeidolphHotplate._heat_start),
    ],
)
def test_set_temp(hotplate_fixture, mocker, temp, switch_status, switch_cmd):
    write_spy = mocker.patch.object(hotplate_fixture, "_write_hotplate")

    hotplate_fixture.temp = temp

    assert hotplate_fixture.target_temp == temp
    assert hotplate_fixture._heat_switch is switch_status
    write_spy.assert_has_calls(
        [
            mocker.call(f"{HeidolphHotplate._temp_set} {temp:.1f}"),
            mocker.call(switch_cmd),
        ]
    )


def test_set_temp_raises_type_error(hotplate_fixture):
    with pytest.raises(TypeError, match="Temperature must be float or int!"):
        hotplate_fixture.temp = "invalid"


@pytest.mark.parametrize("temp", [-10, 250])
def test_set_temp_raises_value_error(hotplate_fixture, temp):
    with pytest.raises(ValueError, match="Temperature out of range: min 0, max 200!"):
        hotplate_fixture.temp = temp


@pytest.mark.parametrize("heat_switch_status", [True, False])
def test_heat_switch_property(hotplate_fixture, mocker, heat_switch_status):
    write_spy = mocker.patch.object(hotplate_fixture, "_write_hotplate")

    hotplate_fixture._heat_switch = heat_switch_status

    assert hotplate_fixture._heat_switch is heat_switch_status
    write_spy.assert_called_once_with(HeidolphHotplate._heat_start if heat_switch_status else HeidolphHotplate._heat_stop)


def test_get_rpm(hotplate_fixture, mocker):
    query_spy = mocker.patch.object(hotplate_fixture, "_query_hotplate", return_value="500")

    assert hotplate_fixture.rpm == 500
    query_spy.assert_called_once_with(HeidolphHotplate._rpm_query)


def test_set_rpm_turns_stirring_off(hotplate_fixture, mocker):
    write_spy = mocker.patch.object(hotplate_fixture, "_write_hotplate")

    hotplate_fixture.rpm = 0

    assert hotplate_fixture.target_rpm == 0
    assert hotplate_fixture._stir_switch is False
    write_spy.assert_called_once_with(HeidolphHotplate._stir_stop)


def test_set_rpm_turns_stirring_on(hotplate_fixture, mocker):
    write_spy = mocker.patch.object(hotplate_fixture, "_write_hotplate")

    hotplate_fixture.rpm = 400

    assert hotplate_fixture.target_rpm == 400
    assert hotplate_fixture._stir_switch is True
    write_spy.assert_has_calls(
        [
            mocker.call(f"{HeidolphHotplate._rpm_set} 400"),
            mocker.call(HeidolphHotplate._stir_start),
        ]
    )


def test_set_rpm_raises_type_error(hotplate_fixture):
    with pytest.raises(TypeError, match="rpm must be an integer"):
        hotplate_fixture.rpm = "invalid"


@pytest.mark.parametrize("rpm", [50, 1500])
def test_set_rpm_raises_value_error(hotplate_fixture, rpm):
    with pytest.raises(ValueError, match="RPM out of range: min 100, max 1400!"):
        hotplate_fixture.rpm = rpm


@pytest.mark.parametrize("stir_switch_status", [True, False])
def test_stir_switch_property(hotplate_fixture, mocker, stir_switch_status):
    write_spy = mocker.patch.object(hotplate_fixture, "_write_hotplate")

    hotplate_fixture._stir_switch = stir_switch_status

    assert hotplate_fixture._stir_switch is stir_switch_status
    write_spy.assert_called_once_with(HeidolphHotplate._stir_start if stir_switch_status else HeidolphHotplate._stir_stop)
