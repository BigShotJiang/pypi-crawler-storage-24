"""Allow running as ``python -m barcodefyi``."""

from barcodefyi.cli import app

app()
