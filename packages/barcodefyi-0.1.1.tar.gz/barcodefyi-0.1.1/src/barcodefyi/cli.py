"""Command-line interface for barcodefyi.

Requires the ``cli`` extra: ``pip install barcodefyi[cli]``

Usage::

    barcodefyi search "upc"
    barcodefyi symbology upc-a
    barcodefyi compare upc-a ean-13
    barcodefyi random
"""

from __future__ import annotations

import typer
from rich.console import Console
from rich.table import Table

app = typer.Typer(
    name="barcodefyi",
    help="Barcode symbology encyclopedia — look up formats, standards, and specs from BarcodeFYI.",
    no_args_is_help=True,
)
console = Console()


@app.command()
def search(
    query: str = typer.Argument(help="Search term (e.g. 'upc', 'code 128', 'gs1')"),
) -> None:
    """Search across symbologies, standards, components, and glossary."""
    from barcodefyi.api import BarcodeFYI

    with BarcodeFYI() as api:
        results = api.search(query)

    table = Table(title=f"Search: {query}")
    table.add_column("Type", style="cyan", no_wrap=True)
    table.add_column("Name")
    table.add_column("Slug")

    items = results.get("results", [])
    if not items:
        console.print(f"[yellow]No results found for '{query}'[/yellow]")
        return

    for item in items:
        table.add_row(item.get("type", ""), item.get("name", ""), item.get("slug", ""))

    console.print(table)


@app.command()
def symbology(
    slug: str = typer.Argument(help="Symbology slug (e.g. 'upc-a', 'code-128')"),
) -> None:
    """Look up a barcode symbology with full specifications."""
    from barcodefyi.api import BarcodeFYI

    with BarcodeFYI() as api:
        data = api.symbology(slug)

    console.print(f"\n[bold]{data.get('name', slug)}[/bold]")
    if data.get("description"):
        console.print(f"  {data['description'][:200]}")
    console.print()

    table = Table(title="Specifications")
    table.add_column("Property", style="cyan")
    table.add_column("Value")

    specs = [
        ("Category", data.get("category")),
        ("Year Introduced", data.get("year_introduced")),
        ("Character Set", data.get("character_set")),
        ("Data Length", data.get("data_length")),
        ("Variable Length", data.get("is_variable_length")),
        ("GS1 Support", data.get("supports_gs1")),
        ("Unicode Support", data.get("supports_unicode")),
        ("Max Capacity", data.get("max_data_capacity")),
    ]
    for label, value in specs:
        if value is not None:
            table.add_row(label, str(value))

    console.print(table)


@app.command()
def compare(
    slug_a: str = typer.Argument(help="First symbology slug"),
    slug_b: str = typer.Argument(help="Second symbology slug"),
) -> None:
    """Compare two barcode symbologies side by side."""
    from barcodefyi.api import BarcodeFYI

    with BarcodeFYI() as api:
        data = api.compare(slug_a, slug_b)

    a = data.get("a", {})
    b = data.get("b", {})

    table = Table(title=f"{a.get('name', slug_a)} vs {b.get('name', slug_b)}")
    table.add_column("Property", style="cyan")
    table.add_column(a.get("name", slug_a), style="green")
    table.add_column(b.get("name", slug_b), style="yellow")

    fields = [
        ("Category", "category"),
        ("Year", "year_introduced"),
        ("Data Length", "data_length"),
        ("Variable Length", "is_variable_length"),
        ("GS1 Support", "supports_gs1"),
        ("Unicode", "supports_unicode"),
    ]
    for label, key in fields:
        table.add_row(label, str(a.get(key, "-")), str(b.get(key, "-")))

    console.print(table)


@app.command()
def random() -> None:
    """Discover a random barcode symbology."""
    from barcodefyi.api import BarcodeFYI

    with BarcodeFYI() as api:
        data = api.random()

    console.print(f"\n[bold]{data.get('name', 'Unknown')}[/bold]")
    if data.get("description"):
        console.print(f"  {data['description'][:200]}")
    console.print(f"  Year: {data.get('year_introduced', 'N/A')}")
    console.print(f"  Category: {data.get('category', 'N/A')}")
    console.print(f"  GS1: {data.get('supports_gs1', 'N/A')}")
    console.print()


if __name__ == "__main__":
    app()
