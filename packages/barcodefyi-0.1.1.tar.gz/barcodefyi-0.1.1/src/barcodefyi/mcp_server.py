"""MCP server for barcodefyi — AI assistant tools for barcodefyi.com.

Run: uvx --from "barcodefyi[mcp]" python -m barcodefyi.mcp_server
"""
from __future__ import annotations

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("BarcodeFYI")


@mcp.tool()
def list_families(limit: int = 20, offset: int = 0) -> str:
    """List families from barcodefyi.com.

    Args:
        limit: Maximum number of results. Default 20.
        offset: Number of results to skip. Default 0.
    """
    from barcodefyi.api import BarcodeFYI

    with BarcodeFYI() as api:
        data = api.list_families(limit=limit, offset=offset)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return "No families found."
        items = results[:limit] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


@mcp.tool()
def get_family(slug: str) -> str:
    """Get detailed information about a specific family.

    Args:
        slug: URL slug identifier for the family.
    """
    from barcodefyi.api import BarcodeFYI

    with BarcodeFYI() as api:
        data = api.get_family(slug)
        return str(data)


@mcp.tool()
def list_algorithms(limit: int = 20, offset: int = 0) -> str:
    """List algorithms from barcodefyi.com.

    Args:
        limit: Maximum number of results. Default 20.
        offset: Number of results to skip. Default 0.
    """
    from barcodefyi.api import BarcodeFYI

    with BarcodeFYI() as api:
        data = api.list_algorithms(limit=limit, offset=offset)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return "No algorithms found."
        items = results[:limit] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


@mcp.tool()
def search_barcode(query: str) -> str:
    """Search barcodefyi.com for barcode formats, standards, and GS1 prefixes.

    Args:
        query: Search query string.
    """
    from barcodefyi.api import BarcodeFYI

    with BarcodeFYI() as api:
        data = api.search(query)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return f"No results found for \"{query}\"."
        items = results[:10] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


def main() -> None:
    """Run the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
