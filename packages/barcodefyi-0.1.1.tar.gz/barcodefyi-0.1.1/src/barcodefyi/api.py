"""HTTP API client for barcodefyi.com REST endpoints.

Requires the ``api`` extra: ``pip install barcodefyi[api]``

Usage::

    from barcodefyi.api import BarcodeFYI

    with BarcodeFYI() as api:
        items = api.list_algorithms()
        detail = api.get_algorithm("example-slug")
        results = api.search("query")
"""

from __future__ import annotations

from typing import Any

import httpx


class BarcodeFYI:
    """API client for the barcodefyi.com REST API.

    Provides typed access to all barcodefyi.com endpoints including
    list, detail, and search operations.

    Args:
        base_url: API base URL. Defaults to ``https://barcodefyi.com``.
        timeout: Request timeout in seconds. Defaults to ``10.0``.
    """

    def __init__(
        self,
        base_url: str = "https://barcodefyi.com",
        timeout: float = 10.0,
    ) -> None:
        self._client = httpx.Client(base_url=base_url, timeout=timeout)

    def _get(self, path: str, **params: Any) -> dict[str, Any]:
        resp = self._client.get(
            path,
            params={k: v for k, v in params.items() if v is not None},
        )
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    # -- Endpoints -----------------------------------------------------------

    def list_algorithms(self, **params: Any) -> dict[str, Any]:
        """List all algorithms."""
        return self._get("/api/v1/algorithms/", **params)

    def get_algorithm(self, slug: str) -> dict[str, Any]:
        """Get algorithm by slug."""
        return self._get(f"/api/v1/algorithms/" + slug + "/")

    def list_categories(self, **params: Any) -> dict[str, Any]:
        """List all categories."""
        return self._get("/api/v1/categories/", **params)

    def get_category(self, slug: str) -> dict[str, Any]:
        """Get category by slug."""
        return self._get(f"/api/v1/categories/" + slug + "/")

    def list_components(self, **params: Any) -> dict[str, Any]:
        """List all components."""
        return self._get("/api/v1/components/", **params)

    def get_component(self, slug: str) -> dict[str, Any]:
        """Get component by slug."""
        return self._get(f"/api/v1/components/" + slug + "/")

    def list_families(self, **params: Any) -> dict[str, Any]:
        """List all families."""
        return self._get("/api/v1/families/", **params)

    def get_family(self, slug: str) -> dict[str, Any]:
        """Get family by slug."""
        return self._get(f"/api/v1/families/" + slug + "/")

    def list_faqs(self, **params: Any) -> dict[str, Any]:
        """List all faqs."""
        return self._get("/api/v1/faqs/", **params)

    def get_faq(self, slug: str) -> dict[str, Any]:
        """Get faq by slug."""
        return self._get(f"/api/v1/faqs/" + slug + "/")

    def list_glossary(self, **params: Any) -> dict[str, Any]:
        """List all glossary."""
        return self._get("/api/v1/glossary/", **params)

    def get_term(self, slug: str) -> dict[str, Any]:
        """Get term by slug."""
        return self._get(f"/api/v1/glossary/" + slug + "/")

    def list_gs1_prefixes(self, **params: Any) -> dict[str, Any]:
        """List all gs1 prefixes."""
        return self._get("/api/v1/gs1-prefixes/", **params)

    def get_gs1_prefixe(self, slug: str) -> dict[str, Any]:
        """Get gs1 prefixe by slug."""
        return self._get(f"/api/v1/gs1-prefixes/" + slug + "/")

    def list_guides(self, **params: Any) -> dict[str, Any]:
        """List all guides."""
        return self._get("/api/v1/guides/", **params)

    def get_guide(self, slug: str) -> dict[str, Any]:
        """Get guide by slug."""
        return self._get(f"/api/v1/guides/" + slug + "/")

    def list_industries(self, **params: Any) -> dict[str, Any]:
        """List all industries."""
        return self._get("/api/v1/industries/", **params)

    def get_industry(self, slug: str) -> dict[str, Any]:
        """Get industry by slug."""
        return self._get(f"/api/v1/industries/" + slug + "/")

    def list_standards(self, **params: Any) -> dict[str, Any]:
        """List all standards."""
        return self._get("/api/v1/standards/", **params)

    def get_standard(self, slug: str) -> dict[str, Any]:
        """Get standard by slug."""
        return self._get(f"/api/v1/standards/" + slug + "/")

    def list_symbologies(self, **params: Any) -> dict[str, Any]:
        """List all symbologies."""
        return self._get("/api/v1/symbologies/", **params)

    def get_symbology(self, slug: str) -> dict[str, Any]:
        """Get symbology by slug."""
        return self._get(f"/api/v1/symbologies/" + slug + "/")

    def list_tools(self, **params: Any) -> dict[str, Any]:
        """List all tools."""
        return self._get("/api/v1/tools/", **params)

    def get_tool(self, slug: str) -> dict[str, Any]:
        """Get tool by slug."""
        return self._get(f"/api/v1/tools/" + slug + "/")

    def search(self, query: str, **params: Any) -> dict[str, Any]:
        """Search across all content."""
        return self._get(f"/api/v1/search/", q=query, **params)

    # -- Lifecycle -----------------------------------------------------------

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> BarcodeFYI:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()
