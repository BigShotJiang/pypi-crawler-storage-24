"""barcodefyi — Barcode symbology encyclopedia API client for developers.

Look up barcode formats, standards, anatomy components, and GS1 prefixes from BarcodeFYI.

Usage::

    from barcodefyi.api import BarcodeFYI

    with BarcodeFYI() as api:
        results = api.search("upc")
        print(results)
"""

__version__ = "0.1.0"
