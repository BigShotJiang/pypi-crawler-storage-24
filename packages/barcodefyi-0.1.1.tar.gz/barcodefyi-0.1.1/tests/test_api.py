"""Tests for barcodefyi API client."""

from __future__ import annotations

from barcodefyi.api import BarcodeFYI


def test_client_init() -> None:
    client = BarcodeFYI()
    assert client._client.base_url == "https://barcodefyi.com"
    client.close()


def test_client_custom_base_url() -> None:
    client = BarcodeFYI(base_url="https://test.example.com")
    assert client._client.base_url == "https://test.example.com"
    client.close()


def test_client_context_manager() -> None:
    with BarcodeFYI() as api:
        assert api._client.base_url == "https://barcodefyi.com"


def test_version() -> None:
    from barcodefyi import __version__

    assert __version__ == "0.1.0"
