from setuptools import setup

setup(
    name="slashmark-hash-gen",
    version="1.0.0",
    py_modules=["sm_hash_gen"],
    entry_points={
        "console_scripts": [
            "sm-hash=sm_hash_gen:main"
        ]
    },
    author="Slash Mark",
    author_email="info@slashmark.in",
    description="Generate MD5 and SHA256 hashes",
    long_description="CLI tool to generate hashes from text.",
    long_description_content_type="text/plain",
    url="https://slashmark.in",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
)
