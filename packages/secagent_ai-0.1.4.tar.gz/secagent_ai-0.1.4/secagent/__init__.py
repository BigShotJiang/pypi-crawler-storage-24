"""SecAgent — Autonomous Security Agent CLI."""

__version__ = "0.1.4"
