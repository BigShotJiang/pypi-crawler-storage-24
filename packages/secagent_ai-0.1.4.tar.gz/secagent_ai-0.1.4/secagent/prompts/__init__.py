"""Prompt loader — reads prompt text files from the prompts/ directory."""

from __future__ import annotations

from pathlib import Path

_DIR = Path(__file__).parent


def load(name: str) -> str:
    """Return the contents of *name* from the prompts directory."""
    return (_DIR / name).read_text(encoding="utf-8")
