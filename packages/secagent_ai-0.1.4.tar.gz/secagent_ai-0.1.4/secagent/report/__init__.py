"""SecAgent report generation."""
