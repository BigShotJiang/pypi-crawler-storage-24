"""SecAgent LLM integration layer."""
