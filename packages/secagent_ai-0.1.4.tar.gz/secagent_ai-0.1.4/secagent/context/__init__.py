"""SecAgent context management utilities."""
