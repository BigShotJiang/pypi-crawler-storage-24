"""SecAgent scanner integrations."""
