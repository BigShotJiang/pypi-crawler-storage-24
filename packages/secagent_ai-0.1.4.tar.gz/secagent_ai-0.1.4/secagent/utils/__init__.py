"""SecAgent utility helpers."""
