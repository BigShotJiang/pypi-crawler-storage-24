"""SecAgent result parsers / normalizers."""
