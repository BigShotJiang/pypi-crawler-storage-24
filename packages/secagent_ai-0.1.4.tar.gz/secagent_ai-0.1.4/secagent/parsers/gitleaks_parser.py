"""Gitleaks result parser — normalizes secret-scanning findings."""

from __future__ import annotations

from typing import Any

from secagent.models import Severity, Vulnerability
from secagent.parsers.base_parser import BaseParser


class GitleaksParser(BaseParser):
    """Convert raw Gitleaks JSON findings into ``Vulnerability`` objects."""

    def parse(self, raw_findings: list[dict[str, Any]]) -> list[Vulnerability]:
        """Map Gitleaks fields to the unified vulnerability format.

        Gitleaks findings typically contain:
        - ``RuleID``, ``Description``
        - ``File``, ``StartLine``
        - ``Match``, ``Secret``
        """
        results: list[Vulnerability] = []

        for finding in raw_findings:
            vuln = Vulnerability(
                scanner="gitleaks",
                file=finding.get("File", "unknown"),
                line=finding.get("StartLine", 0),
                severity=Severity.HIGH,
                vuln_type="secret",
                description=(
                    finding.get("Description", "")
                    or f"Secret detected: {finding.get('RuleID', 'unknown rule')}"
                ),
                raw=finding,
            )
            results.append(vuln)

        return results
