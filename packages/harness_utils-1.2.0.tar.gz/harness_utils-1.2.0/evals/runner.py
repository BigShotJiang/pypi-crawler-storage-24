"""Eval runner - executes all evals and reports results."""

import json
import os
import sys
import time
from typing import Any

from harnessutils.types import LLMClient


def run_all_evals(llm: LLMClient | None = None) -> dict[str, Any]:
    """Run all evals and collect results.

    Args:
        llm: Optional LLM client for quality evals

    Returns:
        Eval results with summary
    """
    print("=" * 60)
    print("Running harness-utils Evals")
    print("=" * 60)
    print()

    results = []
    start_time = time.time()

    # Quality evals
    print("Running quality evals...")
    from evals.test_quality import eval_compaction_ratio, eval_information_preservation

    result = eval_information_preservation(llm)
    results.append(result)
    print_eval_result(result)

    result = eval_compaction_ratio()
    results.append(result)
    print_eval_result(result)

    # Budget evals
    print("\nRunning budget evals...")
    from evals.test_budget import eval_overflow_detection, eval_stays_within_limits

    result = eval_stays_within_limits()
    results.append(result)
    print_eval_result(result)

    result = eval_overflow_detection()
    results.append(result)
    print_eval_result(result)

    # Performance benchmarks
    print("\nRunning performance benchmarks...")
    from evals.test_performance import (
        benchmark_end_to_end,
        benchmark_pruning,
        benchmark_storage_operations,
        benchmark_truncation,
    )

    result = benchmark_truncation()
    results.append(result)
    print_eval_result(result)

    result = benchmark_pruning()
    results.append(result)
    print_eval_result(result)

    result = benchmark_storage_operations()
    results.append(result)
    print_eval_result(result)

    result = benchmark_end_to_end()
    results.append(result)
    print_eval_result(result)

    elapsed = time.time() - start_time

    # Summary
    print()
    print("=" * 60)
    print("Summary")
    print("=" * 60)

    passed = sum(1 for r in results if r.get("passed"))
    skipped = sum(1 for r in results if r.get("skipped"))
    failed = len(results) - passed - skipped

    print(f"Total: {len(results)} evals")
    print(f"Passed: {passed}")
    print(f"Failed: {failed}")
    print(f"Skipped: {skipped}")
    print(f"Time: {elapsed:.2f}s")
    print()

    all_passed = failed == 0

    if all_passed:
        print("✓ All evals passed!")
    else:
        print(f"✗ {failed} evals failed")

    return {
        "total": len(results),
        "passed": passed,
        "failed": failed,
        "skipped": skipped,
        "elapsed_seconds": elapsed,
        "results": results,
        "all_passed": all_passed,
    }


def print_eval_result(result: dict[str, Any]) -> None:
    """Print eval result in human-readable format.

    Args:
        result: Eval result dict
    """
    name = result.get("name", "unknown")
    passed = result.get("passed", False)
    skipped = result.get("skipped", False)

    if skipped:
        status = "SKIP"
        symbol = "-"
        reason = result.get("reason", "")
        print(f"  {symbol} {name}: {status} ({reason})")
        return

    status = "PASS" if passed else "FAIL"
    symbol = "✓" if passed else "✗"

    # Print basic status
    print(f"  {symbol} {name}: {status}", end="")

    # Add metrics
    if "overall_score" in result:
        print(f" (score: {result['overall_score']:.1f}/10)", end="")
    if "avg_compaction_ratio" in result:
        print(f" (ratio: {result['avg_compaction_ratio']:.2f})", end="")
    if "avg_ms_per_turn" in result:
        print(f" ({result['avg_ms_per_turn']:.2f}ms/turn)", end="")

    print()


def save_results(results: dict[str, Any], output_file: str) -> None:
    """Save eval results to JSON file.

    Args:
        results: Eval results
        output_file: Output file path
    """
    with open(output_file, "w") as f:
        json.dump(results, f, indent=2)
    print(f"\nResults saved to {output_file}")


def main() -> None:
    """Run evals from command line."""
    import argparse

    parser = argparse.ArgumentParser(description="Run harness-utils evals")
    parser.add_argument(
        "--with-llm",
        action="store_true",
        help="Run evals that require LLM",
    )
    parser.add_argument(
        "--ollama-url",
        type=str,
        default=os.getenv("OLLAMA_URL", "http://localhost:11434"),
        help="Ollama server URL (default: $OLLAMA_URL or http://localhost:11434)",
    )
    parser.add_argument(
        "--ollama-model",
        type=str,
        default=os.getenv("OLLAMA_MODEL", "qwen2.5:7b"),
        help="Ollama model to use (default: $OLLAMA_MODEL or qwen2.5:7b)",
    )
    parser.add_argument(
        "--output",
        type=str,
        help="Save results to JSON file",
    )

    args = parser.parse_args()

    llm = None
    if args.with_llm:
        print("LLM-based evals enabled")
        print("Using Ollama for evaluations")
        print()
        try:
            from evals.ollama_client import OllamaClient

            llm = OllamaClient(
                base_url=args.ollama_url,
                model=args.ollama_model,
            )
            print(f"Connected to Ollama at {llm.base_url}")
            print(f"Using model: {llm.model}")
            print()
        except Exception as e:
            print(f"Failed to connect to Ollama: {e}")
            print("Skipping LLM-based evals")
            print()

    results = run_all_evals(llm)

    if args.output:
        save_results(results, args.output)

    # Exit with error code if any failed
    sys.exit(0 if results["all_passed"] else 1)


if __name__ == "__main__":
    main()
