# telegram-mcp

Telegram MCP server for Claude Code.

## Tools

- **wait_for_message** — Blocks until a new Telegram message arrives (long polling internally)
- **send_message** — Send a message to a Telegram chat

## Usage

```bash
uvx --from xbghc-telegram-mcp telegram-mcp
```

### Claude Code `.mcp.json`

```json
{
  "mcpServers": {
    "telegram": {
      "command": "uvx",
      "args": ["--from", "xbghc-telegram-mcp", "telegram-mcp"],
      "env": {
        "TELEGRAM_BOT_TOKEN": "${TELEGRAM_BOT_TOKEN}",
        "TELEGRAM_ALLOWED_CHAT_ID": "${TELEGRAM_ALLOWED_CHAT_ID}"
      }
    }
  }
}
```

### Environment Variables

- `TELEGRAM_BOT_TOKEN` (required) — Bot token from [@BotFather](https://t.me/BotFather)
- `TELEGRAM_ALLOWED_CHAT_ID` (optional) — Only accept messages from this chat ID. Other messages are silently ignored.
- `http_proxy` / `https_proxy` (optional) — Auto-detected for proxy support
