import os
import urllib.request
import json
from mcp.server.fastmcp import FastMCP

BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "")
BASE_URL = f"https://api.telegram.org/bot{BOT_TOKEN}"
ALLOWED_CHAT_ID = os.environ.get("TELEGRAM_ALLOWED_CHAT_ID", "")

mcp = FastMCP("telegram")

last_update_id = 0


def _skip_pending_updates():
    """Skip all pending updates on startup to avoid replaying old messages."""
    global last_update_id
    try:
        result = telegram_api("getUpdates", {"offset": -1})
        if result.get("ok") and result.get("result"):
            last_update_id = result["result"][-1]["update_id"]
    except Exception:
        pass


_skip_pending_updates()

proxy_url = (
    os.environ.get("https_proxy")
    or os.environ.get("HTTPS_PROXY")
    or os.environ.get("http_proxy")
    or os.environ.get("HTTP_PROXY")
)
opener = urllib.request.build_opener(
    urllib.request.ProxyHandler({"https": proxy_url, "http": proxy_url})
) if proxy_url else urllib.request.build_opener()


def telegram_api(method: str, params: dict | None = None) -> dict:
    url = f"{BASE_URL}/{method}"
    if params:
        data = json.dumps(params).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
    else:
        req = urllib.request.Request(url)
    with opener.open(req, timeout=60) as resp:
        return json.loads(resp.read().decode("utf-8"))


@mcp.tool()
def wait_for_message() -> str:
    """Wait for a new Telegram message. Blocks indefinitely until a message arrives.
    Internally loops with 30s long polls to Telegram API.
    """
    global last_update_id

    while True:
        params = {"timeout": 30, "allowed_updates": ["message"]}
        if last_update_id > 0:
            params["offset"] = last_update_id + 1

        try:
            result = telegram_api("getUpdates", params)
        except Exception:
            continue

        if not result.get("ok") or not result.get("result"):
            continue

        updates = result["result"]
        last_update_id = updates[-1]["update_id"]

        messages = []
        for update in updates:
            msg = update.get("message", {})
            chat_id = msg.get("chat", {}).get("id")
            if ALLOWED_CHAT_ID and str(chat_id) != ALLOWED_CHAT_ID:
                continue
            messages.append({
                "update_id": update["update_id"],
                "chat_id": chat_id,
                "from": msg.get("from", {}).get("first_name", "") + " " + msg.get("from", {}).get("last_name", ""),
                "username": msg.get("from", {}).get("username", ""),
                "text": msg.get("text", ""),
                "date": msg.get("date"),
            })

        if not messages:
            continue

        return json.dumps({"status": "ok", "messages": messages}, ensure_ascii=False)


@mcp.tool()
def send_message(chat_id: int, text: str) -> str:
    """Send a message to a Telegram chat.

    Args:
        chat_id: The chat ID to send the message to.
        text: The message text to send. Supports Markdown.
    """
    result = telegram_api("sendMessage", {
        "chat_id": chat_id,
        "text": text,
        "parse_mode": "Markdown",
    })
    if result.get("ok"):
        return json.dumps({"status": "ok", "message_id": result["result"]["message_id"]})
    return json.dumps({"status": "error", "detail": result})


def main():
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
