r'''
# cdk-immukv

AWS CDK constructs for deploying ImmuKV infrastructure.

## Installation

### TypeScript/JavaScript

```bash
npm install cdk-immukv
```

### Python

```bash
pip install cdk-immukv
```

## Usage

### Basic Setup

The `ImmuKV` construct uses a multi-prefix architecture. Each prefix defines an isolated ImmuKV namespace within a shared S3 bucket, with its own lifecycle rules, event notifications, IAM policies, and optional OIDC federation.

#### TypeScript

```python
import * as cdk from "aws-cdk-lib";
import { ImmuKV } from "cdk-immukv";

const app = new cdk.App();
const stack = new cdk.Stack(app, "MyStack");

// Single prefix at bucket root
const store = new ImmuKV(stack, "ImmuKV", {
  bucketName: "my-immukv-bucket",
  prefixes: [{ s3Prefix: "" }],
});

// Access the prefix's IAM policies
store.prefix("").readWritePolicy;
store.prefix("").readOnlyPolicy;
```

#### Python

```python
import aws_cdk as cdk
from cdk_immukv import ImmuKV

app = cdk.App()
stack = cdk.Stack(app, "MyStack")

store = ImmuKV(stack, "ImmuKV",
    bucket_name="my-immukv-bucket",
    prefixes=[{"s3_prefix": ""}],
)
```

### Multi-Prefix Setup

Multiple prefixes share a single S3 bucket while remaining fully isolated at the IAM level.

```python
import * as cdk from "aws-cdk-lib";
import * as s3n from "aws-cdk-lib/aws-s3-notifications";
import { ImmuKV } from "cdk-immukv";

const store = new ImmuKV(stack, "ImmuKV", {
  prefixes: [
    {
      s3Prefix: "pipeline/",
      logVersionRetention: cdk.Duration.days(2555),
      onLogEntryCreated: new s3n.LambdaDestination(shadowUpdateFn),
    },
    {
      s3Prefix: "config/",
      logVersionRetention: cdk.Duration.days(90),
      onLogEntryCreated: new s3n.LambdaDestination(configSyncFn),
    },
  ],
});

// Access per-prefix resources
store.prefix("pipeline/").readWritePolicy;
store.prefix("config/").readOnlyPolicy;
```

### S3 Event Notifications

Event notifications are configured per-prefix. Each prefix can have its own notification destination triggered when log entries are created. Supports Lambda functions, SNS topics, and SQS queues.

#### TypeScript - Lambda Trigger

```python
import * as cdk from "aws-cdk-lib";
import * as lambda from "aws-cdk-lib/aws-lambda";
import * as s3n from "aws-cdk-lib/aws-s3-notifications";
import { ImmuKV } from "cdk-immukv";

const processorFn = new lambda.Function(stack, "LogProcessor", {
  runtime: lambda.Runtime.PYTHON_3_11,
  handler: "index.handler",
  code: lambda.Code.fromAsset("lambda"),
});

new ImmuKV(stack, "ImmuKV", {
  bucketName: "my-immukv-bucket",
  prefixes: [
    {
      s3Prefix: "",
      onLogEntryCreated: new s3n.LambdaDestination(processorFn),
    },
  ],
});
```

#### TypeScript - SNS Topic

```python
import * as sns from "aws-cdk-lib/aws-sns";
import * as s3n from "aws-cdk-lib/aws-s3-notifications";
import { ImmuKV } from "cdk-immukv";

const topic = new sns.Topic(stack, "LogEntryTopic");

new ImmuKV(stack, "ImmuKV", {
  bucketName: "my-immukv-bucket",
  prefixes: [
    {
      s3Prefix: "",
      onLogEntryCreated: new s3n.SnsDestination(topic),
    },
  ],
});
```

#### TypeScript - SQS Queue

```python
import * as sqs from "aws-cdk-lib/aws-sqs";
import * as s3n from "aws-cdk-lib/aws-s3-notifications";
import { ImmuKV } from "cdk-immukv";

const queue = new sqs.Queue(stack, "LogEntryQueue");

new ImmuKV(stack, "ImmuKV", {
  bucketName: "my-immukv-bucket",
  prefixes: [
    {
      s3Prefix: "",
      onLogEntryCreated: new s3n.SqsDestination(queue),
    },
  ],
});
```

#### Python - Lambda Trigger

```python
import aws_cdk as cdk
from aws_cdk import aws_lambda as lambda_
from aws_cdk.aws_s3_notifications import LambdaDestination
from cdk_immukv import ImmuKV

processor_fn = lambda_.Function(stack, "LogProcessor",
    runtime=lambda_.Runtime.PYTHON_3_11,
    handler="index.handler",
    code=lambda_.Code.from_asset("lambda"),
)

ImmuKV(stack, "ImmuKV",
    bucket_name="my-immukv-bucket",
    prefixes=[{
        "s3_prefix": "",
        "on_log_entry_created": LambdaDestination(processor_fn),
    }],
)
```

### OIDC Federation

OIDC identity providers are configured per-prefix. Each prefix can have its own federated IAM role scoped to that prefix's resources.

```python
import { ImmuKV } from "cdk-immukv";

const store = new ImmuKV(stack, "ImmuKV", {
  prefixes: [
    {
      s3Prefix: "app/",
      oidcProviders: [
        {
          issuerUrl: "https://accounts.google.com",
          clientIds: ["your-client-id.apps.googleusercontent.com"],
        },
      ],
      // oidcReadOnly: true,  // Set to true for read-only federated access
    },
  ],
});

// The federated role is available on the prefix resources
store.prefix("app/").federatedRole; // IAM role for OIDC users
```

#### Email-Based Access Control

Use `allowedEmails` on an `OidcProvider` to restrict federation to specific email addresses. This adds a `StringEquals` condition on `${issuerUrl}:email` to the trust policy.

```python
const store = new ImmuKV(stack, "ImmuKV", {
  prefixes: [
    {
      s3Prefix: "app/",
      oidcProviders: [
        {
          issuerUrl: "https://accounts.google.com",
          clientIds: ["your-client-id.apps.googleusercontent.com"],
          allowedEmails: ["alice@example.com", "bob@example.com"],
        },
      ],
    },
  ],
});
```

When `allowedEmails` is omitted, the trust policy only checks `:aud` (client ID). When provided, it must be non-empty.

#### Provider Deduplication

OIDC providers are deduplicated by issuer URL. If the same issuer URL appears across multiple prefixes (literal or wildcard), a single IAM OIDC provider resource is created and shared. Issuer URLs are normalized (`new URL(issuerUrl).href`) so that cosmetic variants like trailing slashes, mixed-case hostnames, and default ports are treated as the same provider.

If the same issuer URL is referenced with different `clientIds` across prefixes, the construct throws an error at synthesis time.

### Wildcard Prefixes

Wildcard prefixes provide IAM-only scoping using patterns like `tenant-*/logs/*`. They support `*` (zero or more characters) and `?` (exactly one character) via IAM `StringLike` conditions and ARN matching.

Wildcard prefixes do **not** support S3 lifecycle rules, event notifications, or listing -- those require literal prefixes. They are purely for IAM policy scoping.

```python
import { ImmuKV } from "cdk-immukv";

const store = new ImmuKV(stack, "ImmuKV", {
  prefixes: [{ s3Prefix: "" }],
  wildcardPrefixes: [
    {
      pattern: "tenant-*/logs/",
      oidcProviders: [
        {
          issuerUrl: "https://accounts.google.com",
          clientIds: ["your-client-id.apps.googleusercontent.com"],
        },
      ],
    },
    {
      pattern: "*/config/",
      oidcReadOnly: true,
      oidcProviders: [
        {
          issuerUrl: "https://accounts.google.com",
          clientIds: ["your-client-id.apps.googleusercontent.com"],
        },
      ],
    },
  ],
});

// Access wildcard prefix resources
store.wildcardPrefix("tenant-*/logs/").readWritePolicy;
store.wildcardPrefix("tenant-*/logs/").federatedRole;
```

## API

### `OidcProvider`

Configuration for an OIDC identity provider:

* `issuerUrl` (required): OIDC issuer URL (must start with `"https://"`).
* `clientIds` (required): Client IDs (audiences) to trust from this provider. Must contain at least one element.
* `allowedEmails` (optional): Email addresses allowed to assume the federated role. Adds a `StringEquals` condition on `${issuerUrl}:email` to the trust policy. Must be non-empty when provided. When omitted, the trust policy only checks `:aud` (client ID).

### `ImmuKVProps`

Top-level properties for the `ImmuKV` construct:

* `bucketName` (optional): Name for the S3 bucket. If not specified, an auto-generated bucket name will be used.
* `useKmsEncryption` (optional): Enable KMS encryption instead of S3-managed encryption (default: false).
* `prefixes` (required): Array of `ImmuKVPrefixConfig` entries. At least one entry is required.
* `wildcardPrefixes` (optional): Array of `ImmuKVWildcardPrefixConfig` entries for IAM-only wildcard scoping.

### `ImmuKVPrefixConfig`

Configuration for a single ImmuKV prefix within the bucket:

* `s3Prefix` (required): S3 key prefix for this namespace. Use `""` for bucket root, or directory-style like `"myapp/"` for namespacing.
* `logVersionRetention` (optional): Duration to retain old log versions. Must be expressible in whole days.
* `logVersionsToRetain` (optional): Number of old log versions to retain.
* `keyVersionRetention` (optional): Duration to retain old key object versions. Must be expressible in whole days.
* `keyVersionsToRetain` (optional): Number of old key versions to retain per key.
* `onLogEntryCreated` (optional): S3 notification destination triggered when log entries are created under this prefix. Supports Lambda, SNS, and SQS.
* `oidcProviders` (optional): Array of `OidcProvider` entries for web identity federation scoped to this prefix.
* `oidcReadOnly` (optional): Whether the federated role gets read-only access instead of read-write (default: false).

### Prefix Validation Rules

* Prefixes must not start with `/` or contain `..`
* Duplicate prefixes are not allowed
* Overlapping prefixes are not allowed (one being a prefix of the other)
* Empty string prefix `""` cannot coexist with other prefixes (it matches all objects)

### `ImmuKVWildcardPrefixConfig`

Configuration for a wildcard-based IAM prefix pattern:

* `pattern` (required): Wildcard prefix pattern for IAM scoping. Supports `*` (zero or more characters) and `?` (exactly one character). Must not be empty, start with `/`, or contain `..`.
* `oidcProviders` (optional): Array of `OidcProvider` entries for web identity federation scoped to this wildcard pattern.
* `oidcReadOnly` (optional): Whether the federated role gets read-only access instead of read-write (default: false).

### `ImmuKV` Class

The `ImmuKV` construct exposes:

* `bucket`: The S3 bucket shared by all prefixes.
* `prefixes`: Object mapping prefix strings to `ImmuKVPrefixResources`.
* `wildcardPrefixes`: Object mapping wildcard pattern strings to `ImmuKVWildcardPrefixResources`.
* `prefix(s3Prefix)`: Method to get resources for a specific prefix (throws if not found).
* `wildcardPrefix(pattern)`: Method to get resources for a specific wildcard prefix pattern (throws if not found).

### `ImmuKVPrefixResources`

Resources created for each prefix:

* `s3Prefix`: The S3 prefix string (as provided in the config).
* `readWritePolicy`: IAM managed policy granting read-write access scoped to this prefix.
* `readOnlyPolicy`: IAM managed policy granting read-only access scoped to this prefix.
* `federatedRole` (optional): Federated IAM role for OIDC users scoped to this prefix. Only present when `oidcProviders` was specified.

### `ImmuKVWildcardPrefixResources`

Resources created for each wildcard prefix pattern:

* `pattern`: The wildcard pattern string (as provided in the config).
* `readWritePolicy`: IAM managed policy granting read-write access scoped to this wildcard pattern. Uses `StringLike` conditions on `s3:prefix`.
* `readOnlyPolicy`: IAM managed policy granting read-only access scoped to this wildcard pattern.
* `federatedRole` (optional): Federated IAM role for OIDC users scoped to this wildcard pattern. Only present when `oidcProviders` was specified.

## License

MIT
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_iam as _aws_cdk_aws_iam_ceddda9d
import aws_cdk.aws_s3 as _aws_cdk_aws_s3_ceddda9d
import constructs as _constructs_77d1e7e8


class ImmuKV(
    _constructs_77d1e7e8.Construct,
    metaclass=jsii.JSIIMeta,
    jsii_type="cdk-immukv.ImmuKV",
):
    '''(experimental) AWS CDK Construct for ImmuKV infrastructure.

    Creates an S3 bucket with versioning enabled and per-prefix IAM policies,
    lifecycle rules, event notifications, and optional OIDC federation.

    :stability: experimental
    '''

    def __init__(
        self,
        scope: _constructs_77d1e7e8.Construct,
        id: builtins.str,
        *,
        prefixes: typing.Sequence[typing.Union["ImmuKVPrefixConfig", typing.Dict[builtins.str, typing.Any]]],
        bucket_name: typing.Optional[builtins.str] = None,
        use_kms_encryption: typing.Optional[builtins.bool] = None,
        wildcard_prefixes: typing.Optional[typing.Sequence[typing.Union["ImmuKVWildcardPrefixConfig", typing.Dict[builtins.str, typing.Any]]]] = None,
    ) -> None:
        '''
        :param scope: -
        :param id: -
        :param prefixes: (experimental) Prefix configurations. At least one entry is required. Each entry defines an isolated ImmuKV namespace within the shared bucket, with its own lifecycle rules, event notifications, IAM policies, and optional OIDC federation.
        :param bucket_name: (experimental) Name of the S3 bucket. Default: — auto-generated
        :param use_kms_encryption: (experimental) Enable KMS encryption instead of S3-managed encryption. Default: false
        :param wildcard_prefixes: (experimental) Wildcard prefix configurations for IAM-only scoping. Each entry defines IAM policies using wildcard patterns (e.g., ``tenant-*\\/logs/``). Wildcards work in IAM via ``StringLike`` conditions and ARN matching but do NOT support S3 lifecycle rules, notifications, or listing. Default: undefined — no wildcard prefixes

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cf89bf43b11632d41df9085531c36079dbf8b6c7b0e05db6941b2fedec39190f)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        props = ImmuKVProps(
            prefixes=prefixes,
            bucket_name=bucket_name,
            use_kms_encryption=use_kms_encryption,
            wildcard_prefixes=wildcard_prefixes,
        )

        jsii.create(self.__class__, self, [scope, id, props])

    @jsii.member(jsii_name="prefix")
    def prefix(self, s3_prefix: builtins.str) -> "ImmuKVPrefixResources":
        '''(experimental) Get resources for a specific prefix.

        :param s3_prefix: -

        :stability: experimental
        :throws: Error if no prefix with that name exists.

        Example::

            instance.prefix("config/").readWritePolicy
            instance.prefix("").readWritePolicy  // root prefix
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7c96ca2ec9690ac7d03b17d77a26c0e36358f90b98107efcdc12aedee97903ee)
            check_type(argname="argument s3_prefix", value=s3_prefix, expected_type=type_hints["s3_prefix"])
        return typing.cast("ImmuKVPrefixResources", jsii.invoke(self, "prefix", [s3_prefix]))

    @jsii.member(jsii_name="wildcardPrefix")
    def wildcard_prefix(self, pattern: builtins.str) -> "ImmuKVWildcardPrefixResources":
        '''(experimental) Get resources for a specific wildcard prefix pattern.

        :param pattern: -

        :stability: experimental
        :throws: Error if no wildcard prefix with that pattern exists.

        Example::

            instance.wildcardPrefix("tenant-*\/logs/").readWritePolicy
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__753a80a0e963e9c1f718a62c198744e0367b656fca53d607c6ac829c0d24a3da)
            check_type(argname="argument pattern", value=pattern, expected_type=type_hints["pattern"])
        return typing.cast("ImmuKVWildcardPrefixResources", jsii.invoke(self, "wildcardPrefix", [pattern]))

    @builtins.property
    @jsii.member(jsii_name="bucket")
    def bucket(self) -> _aws_cdk_aws_s3_ceddda9d.Bucket:
        '''(experimental) The S3 bucket shared by all prefixes.

        :stability: experimental
        '''
        return typing.cast(_aws_cdk_aws_s3_ceddda9d.Bucket, jsii.get(self, "bucket"))

    @builtins.property
    @jsii.member(jsii_name="prefixes")
    def prefixes(self) -> typing.Mapping[builtins.str, "ImmuKVPrefixResources"]:
        '''(experimental) Per-prefix resources, keyed by the s3Prefix string.

        Use ``prefix()`` for type-safe access with runtime validation.

        :stability: experimental
        '''
        return typing.cast(typing.Mapping[builtins.str, "ImmuKVPrefixResources"], jsii.get(self, "prefixes"))

    @builtins.property
    @jsii.member(jsii_name="wildcardPrefixes")
    def wildcard_prefixes(
        self,
    ) -> typing.Mapping[builtins.str, "ImmuKVWildcardPrefixResources"]:
        '''(experimental) Per-wildcard-pattern resources, keyed by the pattern string.

        Use ``wildcardPrefix()`` for type-safe access with runtime validation.

        :stability: experimental
        '''
        return typing.cast(typing.Mapping[builtins.str, "ImmuKVWildcardPrefixResources"], jsii.get(self, "wildcardPrefixes"))


@jsii.data_type(
    jsii_type="cdk-immukv.ImmuKVPrefixConfig",
    jsii_struct_bases=[],
    name_mapping={
        "s3_prefix": "s3Prefix",
        "key_version_retention": "keyVersionRetention",
        "key_versions_to_retain": "keyVersionsToRetain",
        "log_version_retention": "logVersionRetention",
        "log_versions_to_retain": "logVersionsToRetain",
        "oidc_providers": "oidcProviders",
        "oidc_read_only": "oidcReadOnly",
        "on_log_entry_created": "onLogEntryCreated",
    },
)
class ImmuKVPrefixConfig:
    def __init__(
        self,
        *,
        s3_prefix: builtins.str,
        key_version_retention: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
        key_versions_to_retain: typing.Optional[jsii.Number] = None,
        log_version_retention: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
        log_versions_to_retain: typing.Optional[jsii.Number] = None,
        oidc_providers: typing.Optional[typing.Sequence[typing.Union["OidcProvider", typing.Dict[builtins.str, typing.Any]]]] = None,
        oidc_read_only: typing.Optional[builtins.bool] = None,
        on_log_entry_created: typing.Optional[_aws_cdk_aws_s3_ceddda9d.IBucketNotificationDestination] = None,
    ) -> None:
        '''(experimental) Configuration for a single ImmuKV prefix within a bucket.

        Each prefix operates as an independent ImmuKV namespace with its own
        lifecycle rules, event notifications, IAM policies, and optional OIDC
        federation. Prefixes are isolated at the IAM level — a policy generated
        for one prefix does not grant access to another.

        :param s3_prefix: (experimental) S3 key prefix for this ImmuKV namespace. Controls where ImmuKV stores its data within the S3 bucket: - Empty string: Files at bucket root (``_log.json``, ``keys/mykey.json``) - With trailing slash (e.g., ``myapp/``): Directory-style (``myapp/_log.json``, ``myapp/keys/mykey.json``) - Without trailing slash (e.g., ``myapp``): Flat prefix (``myapp_log.json``, ``myappkeys/mykey.json``) Validation: - Must not start with ``/`` or contain ``..`` - Must not duplicate another prefix in the same instance - Must not overlap another prefix (one being a prefix of the other) - Empty string ``""`` cannot coexist with other prefixes (it matches all objects)
        :param key_version_retention: (experimental) Duration to retain old key object versions for this prefix. Must be expressible in whole days. Default: undefined — keep forever
        :param key_versions_to_retain: (experimental) Number of old key versions to retain per key for this prefix. Must be a non-negative integer. Default: undefined — keep all versions
        :param log_version_retention: (experimental) Duration to retain old log versions for this prefix. Must be expressible in whole days. Default: undefined — keep forever
        :param log_versions_to_retain: (experimental) Number of old log versions to retain for this prefix. Must be a non-negative integer. Default: undefined — keep all versions
        :param oidc_providers: (experimental) OIDC identity providers for web identity federation scoped to this prefix. Creates a federated IAM role whose policies are scoped to this prefix only. The role receives this prefix's readWritePolicy by default, or readOnlyPolicy if ``oidcReadOnly`` is true. Default: undefined — no OIDC federation
        :param oidc_read_only: (experimental) Whether the federated role gets read-only access instead of read-write. Only meaningful when ``oidcProviders`` is set. Default: false
        :param on_log_entry_created: (experimental) Notification destination triggered when log entries are created under this prefix. Supports Lambda, SNS, and SQS. Event filter matches ``${s3Prefix}_log.json`` via S3 prefix matching. Default: undefined — no notification

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e2e3aa4d4c37ae1a9463501c85b7db01bafadd9b1cf1675edf0934d98c7e56f7)
            check_type(argname="argument s3_prefix", value=s3_prefix, expected_type=type_hints["s3_prefix"])
            check_type(argname="argument key_version_retention", value=key_version_retention, expected_type=type_hints["key_version_retention"])
            check_type(argname="argument key_versions_to_retain", value=key_versions_to_retain, expected_type=type_hints["key_versions_to_retain"])
            check_type(argname="argument log_version_retention", value=log_version_retention, expected_type=type_hints["log_version_retention"])
            check_type(argname="argument log_versions_to_retain", value=log_versions_to_retain, expected_type=type_hints["log_versions_to_retain"])
            check_type(argname="argument oidc_providers", value=oidc_providers, expected_type=type_hints["oidc_providers"])
            check_type(argname="argument oidc_read_only", value=oidc_read_only, expected_type=type_hints["oidc_read_only"])
            check_type(argname="argument on_log_entry_created", value=on_log_entry_created, expected_type=type_hints["on_log_entry_created"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "s3_prefix": s3_prefix,
        }
        if key_version_retention is not None:
            self._values["key_version_retention"] = key_version_retention
        if key_versions_to_retain is not None:
            self._values["key_versions_to_retain"] = key_versions_to_retain
        if log_version_retention is not None:
            self._values["log_version_retention"] = log_version_retention
        if log_versions_to_retain is not None:
            self._values["log_versions_to_retain"] = log_versions_to_retain
        if oidc_providers is not None:
            self._values["oidc_providers"] = oidc_providers
        if oidc_read_only is not None:
            self._values["oidc_read_only"] = oidc_read_only
        if on_log_entry_created is not None:
            self._values["on_log_entry_created"] = on_log_entry_created

    @builtins.property
    def s3_prefix(self) -> builtins.str:
        '''(experimental) S3 key prefix for this ImmuKV namespace.

        Controls where ImmuKV stores its data within the S3 bucket:

        - Empty string: Files at bucket root (``_log.json``, ``keys/mykey.json``)
        - With trailing slash (e.g., ``myapp/``): Directory-style (``myapp/_log.json``, ``myapp/keys/mykey.json``)
        - Without trailing slash (e.g., ``myapp``): Flat prefix (``myapp_log.json``, ``myappkeys/mykey.json``)

        Validation:

        - Must not start with ``/`` or contain ``..``
        - Must not duplicate another prefix in the same instance
        - Must not overlap another prefix (one being a prefix of the other)
        - Empty string ``""`` cannot coexist with other prefixes (it matches all objects)

        :stability: experimental
        '''
        result = self._values.get("s3_prefix")
        assert result is not None, "Required property 's3_prefix' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def key_version_retention(self) -> typing.Optional[_aws_cdk_ceddda9d.Duration]:
        '''(experimental) Duration to retain old key object versions for this prefix.

        Must be expressible in whole days.

        :default: undefined — keep forever

        :stability: experimental
        '''
        result = self._values.get("key_version_retention")
        return typing.cast(typing.Optional[_aws_cdk_ceddda9d.Duration], result)

    @builtins.property
    def key_versions_to_retain(self) -> typing.Optional[jsii.Number]:
        '''(experimental) Number of old key versions to retain per key for this prefix.

        Must be a non-negative integer.

        :default: undefined — keep all versions

        :stability: experimental
        '''
        result = self._values.get("key_versions_to_retain")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def log_version_retention(self) -> typing.Optional[_aws_cdk_ceddda9d.Duration]:
        '''(experimental) Duration to retain old log versions for this prefix.

        Must be expressible in whole days.

        :default: undefined — keep forever

        :stability: experimental
        '''
        result = self._values.get("log_version_retention")
        return typing.cast(typing.Optional[_aws_cdk_ceddda9d.Duration], result)

    @builtins.property
    def log_versions_to_retain(self) -> typing.Optional[jsii.Number]:
        '''(experimental) Number of old log versions to retain for this prefix.

        Must be a non-negative integer.

        :default: undefined — keep all versions

        :stability: experimental
        '''
        result = self._values.get("log_versions_to_retain")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def oidc_providers(self) -> typing.Optional[typing.List["OidcProvider"]]:
        '''(experimental) OIDC identity providers for web identity federation scoped to this prefix.

        Creates a federated IAM role whose policies are scoped to this prefix only.
        The role receives this prefix's readWritePolicy by default,
        or readOnlyPolicy if ``oidcReadOnly`` is true.

        :default: undefined — no OIDC federation

        :stability: experimental
        '''
        result = self._values.get("oidc_providers")
        return typing.cast(typing.Optional[typing.List["OidcProvider"]], result)

    @builtins.property
    def oidc_read_only(self) -> typing.Optional[builtins.bool]:
        '''(experimental) Whether the federated role gets read-only access instead of read-write.

        Only meaningful when ``oidcProviders`` is set.

        :default: false

        :stability: experimental
        '''
        result = self._values.get("oidc_read_only")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def on_log_entry_created(
        self,
    ) -> typing.Optional[_aws_cdk_aws_s3_ceddda9d.IBucketNotificationDestination]:
        '''(experimental) Notification destination triggered when log entries are created under this prefix. Supports Lambda, SNS, and SQS.

        Event filter matches ``${s3Prefix}_log.json`` via S3 prefix matching.

        :default: undefined — no notification

        :stability: experimental
        '''
        result = self._values.get("on_log_entry_created")
        return typing.cast(typing.Optional[_aws_cdk_aws_s3_ceddda9d.IBucketNotificationDestination], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ImmuKVPrefixConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="cdk-immukv.ImmuKVPrefixResources",
    jsii_struct_bases=[],
    name_mapping={
        "read_only_policy": "readOnlyPolicy",
        "read_write_policy": "readWritePolicy",
        "s3_prefix": "s3Prefix",
        "federated_role": "federatedRole",
    },
)
class ImmuKVPrefixResources:
    def __init__(
        self,
        *,
        read_only_policy: _aws_cdk_aws_iam_ceddda9d.ManagedPolicy,
        read_write_policy: _aws_cdk_aws_iam_ceddda9d.ManagedPolicy,
        s3_prefix: builtins.str,
        federated_role: typing.Optional[_aws_cdk_aws_iam_ceddda9d.Role] = None,
    ) -> None:
        '''(experimental) Resources created for a single ImmuKV prefix.

        :param read_only_policy: (experimental) IAM managed policy granting read-only access scoped to this prefix. Same as readWritePolicy but without PutObject.
        :param read_write_policy: (experimental) IAM managed policy granting read-write access scoped to this prefix. Object actions (GetObject, GetObjectVersion, PutObject, HeadObject) on ``bucketArn/${prefix}*``. Bucket actions (ListBucket, ListBucketVersions) on ``bucketArn`` with ``s3:prefix`` condition.
        :param s3_prefix: (experimental) The S3 prefix string (as provided in the config).
        :param federated_role: (experimental) Federated IAM role for OIDC users scoped to this prefix. Only present when ``oidcProviders`` was specified.

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bf3d0970abe1671afa2decc2a3b7280123a1fe660e9e9a9cc648833bb5c3649d)
            check_type(argname="argument read_only_policy", value=read_only_policy, expected_type=type_hints["read_only_policy"])
            check_type(argname="argument read_write_policy", value=read_write_policy, expected_type=type_hints["read_write_policy"])
            check_type(argname="argument s3_prefix", value=s3_prefix, expected_type=type_hints["s3_prefix"])
            check_type(argname="argument federated_role", value=federated_role, expected_type=type_hints["federated_role"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "read_only_policy": read_only_policy,
            "read_write_policy": read_write_policy,
            "s3_prefix": s3_prefix,
        }
        if federated_role is not None:
            self._values["federated_role"] = federated_role

    @builtins.property
    def read_only_policy(self) -> _aws_cdk_aws_iam_ceddda9d.ManagedPolicy:
        '''(experimental) IAM managed policy granting read-only access scoped to this prefix.

        Same as readWritePolicy but without PutObject.

        :stability: experimental
        '''
        result = self._values.get("read_only_policy")
        assert result is not None, "Required property 'read_only_policy' is missing"
        return typing.cast(_aws_cdk_aws_iam_ceddda9d.ManagedPolicy, result)

    @builtins.property
    def read_write_policy(self) -> _aws_cdk_aws_iam_ceddda9d.ManagedPolicy:
        '''(experimental) IAM managed policy granting read-write access scoped to this prefix.

        Object actions (GetObject, GetObjectVersion, PutObject, HeadObject)
        on ``bucketArn/${prefix}*``. Bucket actions (ListBucket, ListBucketVersions)
        on ``bucketArn`` with ``s3:prefix`` condition.

        :stability: experimental
        '''
        result = self._values.get("read_write_policy")
        assert result is not None, "Required property 'read_write_policy' is missing"
        return typing.cast(_aws_cdk_aws_iam_ceddda9d.ManagedPolicy, result)

    @builtins.property
    def s3_prefix(self) -> builtins.str:
        '''(experimental) The S3 prefix string (as provided in the config).

        :stability: experimental
        '''
        result = self._values.get("s3_prefix")
        assert result is not None, "Required property 's3_prefix' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def federated_role(self) -> typing.Optional[_aws_cdk_aws_iam_ceddda9d.Role]:
        '''(experimental) Federated IAM role for OIDC users scoped to this prefix.

        Only present when ``oidcProviders`` was specified.

        :stability: experimental
        '''
        result = self._values.get("federated_role")
        return typing.cast(typing.Optional[_aws_cdk_aws_iam_ceddda9d.Role], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ImmuKVPrefixResources(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="cdk-immukv.ImmuKVProps",
    jsii_struct_bases=[],
    name_mapping={
        "prefixes": "prefixes",
        "bucket_name": "bucketName",
        "use_kms_encryption": "useKmsEncryption",
        "wildcard_prefixes": "wildcardPrefixes",
    },
)
class ImmuKVProps:
    def __init__(
        self,
        *,
        prefixes: typing.Sequence[typing.Union[ImmuKVPrefixConfig, typing.Dict[builtins.str, typing.Any]]],
        bucket_name: typing.Optional[builtins.str] = None,
        use_kms_encryption: typing.Optional[builtins.bool] = None,
        wildcard_prefixes: typing.Optional[typing.Sequence[typing.Union["ImmuKVWildcardPrefixConfig", typing.Dict[builtins.str, typing.Any]]]] = None,
    ) -> None:
        '''
        :param prefixes: (experimental) Prefix configurations. At least one entry is required. Each entry defines an isolated ImmuKV namespace within the shared bucket, with its own lifecycle rules, event notifications, IAM policies, and optional OIDC federation.
        :param bucket_name: (experimental) Name of the S3 bucket. Default: — auto-generated
        :param use_kms_encryption: (experimental) Enable KMS encryption instead of S3-managed encryption. Default: false
        :param wildcard_prefixes: (experimental) Wildcard prefix configurations for IAM-only scoping. Each entry defines IAM policies using wildcard patterns (e.g., ``tenant-*\\/logs/``). Wildcards work in IAM via ``StringLike`` conditions and ARN matching but do NOT support S3 lifecycle rules, notifications, or listing. Default: undefined — no wildcard prefixes

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2f38ba88d5eb7c35a08092e7656a1247dfe38e78f3d61072f111badd15889223)
            check_type(argname="argument prefixes", value=prefixes, expected_type=type_hints["prefixes"])
            check_type(argname="argument bucket_name", value=bucket_name, expected_type=type_hints["bucket_name"])
            check_type(argname="argument use_kms_encryption", value=use_kms_encryption, expected_type=type_hints["use_kms_encryption"])
            check_type(argname="argument wildcard_prefixes", value=wildcard_prefixes, expected_type=type_hints["wildcard_prefixes"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "prefixes": prefixes,
        }
        if bucket_name is not None:
            self._values["bucket_name"] = bucket_name
        if use_kms_encryption is not None:
            self._values["use_kms_encryption"] = use_kms_encryption
        if wildcard_prefixes is not None:
            self._values["wildcard_prefixes"] = wildcard_prefixes

    @builtins.property
    def prefixes(self) -> typing.List[ImmuKVPrefixConfig]:
        '''(experimental) Prefix configurations. At least one entry is required.

        Each entry defines an isolated ImmuKV namespace within the shared bucket,
        with its own lifecycle rules, event notifications, IAM policies,
        and optional OIDC federation.

        :stability: experimental

        Example::

            // Two prefixes with different retention and notifications:
            new ImmuKV(this, 'Store', {
              prefixes: [
                { s3Prefix: 'pipeline/', logVersionRetention: cdk.Duration.days(2555),
                  onLogEntryCreated: new s3n.LambdaDestination(shadowUpdateFn) },
                { s3Prefix: 'config/', logVersionRetention: cdk.Duration.days(90),
                  onLogEntryCreated: new s3n.LambdaDestination(configSyncFn) },
              ],
            });
        '''
        result = self._values.get("prefixes")
        assert result is not None, "Required property 'prefixes' is missing"
        return typing.cast(typing.List[ImmuKVPrefixConfig], result)

    @builtins.property
    def bucket_name(self) -> typing.Optional[builtins.str]:
        '''(experimental) Name of the S3 bucket.

        :default: — auto-generated

        :stability: experimental
        '''
        result = self._values.get("bucket_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def use_kms_encryption(self) -> typing.Optional[builtins.bool]:
        '''(experimental) Enable KMS encryption instead of S3-managed encryption.

        :default: false

        :stability: experimental
        '''
        result = self._values.get("use_kms_encryption")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def wildcard_prefixes(
        self,
    ) -> typing.Optional[typing.List["ImmuKVWildcardPrefixConfig"]]:
        '''(experimental) Wildcard prefix configurations for IAM-only scoping.

        Each entry defines IAM policies using wildcard patterns (e.g., ``tenant-*\\/logs/``).
        Wildcards work in IAM via ``StringLike`` conditions and ARN matching but do NOT
        support S3 lifecycle rules, notifications, or listing.

        :default: undefined — no wildcard prefixes

        :stability: experimental

        Example::

            new ImmuKV(this, 'Store', {
              prefixes: [{ s3Prefix: '' }],
              wildcardPrefixes: [
                { pattern: 'tenant-*\/logs/' },
                { pattern: '*\/config/', oidcReadOnly: true, oidcProviders: [...] },
              ],
            });
        '''
        result = self._values.get("wildcard_prefixes")
        return typing.cast(typing.Optional[typing.List["ImmuKVWildcardPrefixConfig"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ImmuKVProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="cdk-immukv.ImmuKVWildcardPrefixConfig",
    jsii_struct_bases=[],
    name_mapping={
        "pattern": "pattern",
        "oidc_providers": "oidcProviders",
        "oidc_read_only": "oidcReadOnly",
    },
)
class ImmuKVWildcardPrefixConfig:
    def __init__(
        self,
        *,
        pattern: builtins.str,
        oidc_providers: typing.Optional[typing.Sequence[typing.Union["OidcProvider", typing.Dict[builtins.str, typing.Any]]]] = None,
        oidc_read_only: typing.Optional[builtins.bool] = None,
    ) -> None:
        '''(experimental) Configuration for a wildcard-based IAM prefix pattern.

        Wildcards (``*``, ``?``) are supported in IAM policies via ``StringLike`` conditions
        and IAM ARN matching, but do NOT work for S3 lifecycle rules, notifications,
        or listing. This interface therefore only exposes IAM-related options.

        :param pattern: (experimental) Wildcard prefix pattern for IAM scoping. Supports ``*`` (matches zero or more characters) and ``?`` (matches exactly one character). Used in IAM policy resource ARNs and ``StringLike`` conditions on ``s3:prefix``. Validation: - Must not be empty - Must not start with ``/`` or contain ``..`` - Must not duplicate another wildcard pattern in the same instance
        :param oidc_providers: (experimental) OIDC identity providers for web identity federation scoped to this wildcard pattern. Creates a federated IAM role whose policies are scoped to this pattern only. The role receives this pattern's readWritePolicy by default, or readOnlyPolicy if ``oidcReadOnly`` is true. Default: undefined — no OIDC federation
        :param oidc_read_only: (experimental) Whether the federated role gets read-only access instead of read-write. Only meaningful when ``oidcProviders`` is set. Default: false

        :stability: experimental

        Example::

            // Scope IAM to any tenant's logs:
            { pattern: 'tenant-*\/logs/', oidcProviders: [...] }
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__099557eaa9530283869a2037b4e3b102d72d7e297b34cc366b86d7a99df20651)
            check_type(argname="argument pattern", value=pattern, expected_type=type_hints["pattern"])
            check_type(argname="argument oidc_providers", value=oidc_providers, expected_type=type_hints["oidc_providers"])
            check_type(argname="argument oidc_read_only", value=oidc_read_only, expected_type=type_hints["oidc_read_only"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "pattern": pattern,
        }
        if oidc_providers is not None:
            self._values["oidc_providers"] = oidc_providers
        if oidc_read_only is not None:
            self._values["oidc_read_only"] = oidc_read_only

    @builtins.property
    def pattern(self) -> builtins.str:
        '''(experimental) Wildcard prefix pattern for IAM scoping.

        Supports ``*`` (matches zero or more characters) and ``?`` (matches exactly one character).
        Used in IAM policy resource ARNs and ``StringLike`` conditions on ``s3:prefix``.

        Validation:

        - Must not be empty
        - Must not start with ``/`` or contain ``..``
        - Must not duplicate another wildcard pattern in the same instance

        :stability: experimental
        '''
        result = self._values.get("pattern")
        assert result is not None, "Required property 'pattern' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def oidc_providers(self) -> typing.Optional[typing.List["OidcProvider"]]:
        '''(experimental) OIDC identity providers for web identity federation scoped to this wildcard pattern.

        Creates a federated IAM role whose policies are scoped to this pattern only.
        The role receives this pattern's readWritePolicy by default,
        or readOnlyPolicy if ``oidcReadOnly`` is true.

        :default: undefined — no OIDC federation

        :stability: experimental
        '''
        result = self._values.get("oidc_providers")
        return typing.cast(typing.Optional[typing.List["OidcProvider"]], result)

    @builtins.property
    def oidc_read_only(self) -> typing.Optional[builtins.bool]:
        '''(experimental) Whether the federated role gets read-only access instead of read-write.

        Only meaningful when ``oidcProviders`` is set.

        :default: false

        :stability: experimental
        '''
        result = self._values.get("oidc_read_only")
        return typing.cast(typing.Optional[builtins.bool], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ImmuKVWildcardPrefixConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="cdk-immukv.ImmuKVWildcardPrefixResources",
    jsii_struct_bases=[],
    name_mapping={
        "pattern": "pattern",
        "read_only_policy": "readOnlyPolicy",
        "read_write_policy": "readWritePolicy",
        "federated_role": "federatedRole",
    },
)
class ImmuKVWildcardPrefixResources:
    def __init__(
        self,
        *,
        pattern: builtins.str,
        read_only_policy: _aws_cdk_aws_iam_ceddda9d.ManagedPolicy,
        read_write_policy: _aws_cdk_aws_iam_ceddda9d.ManagedPolicy,
        federated_role: typing.Optional[_aws_cdk_aws_iam_ceddda9d.Role] = None,
    ) -> None:
        '''(experimental) Resources created for a single wildcard prefix pattern.

        :param pattern: (experimental) The wildcard pattern string (as provided in the config).
        :param read_only_policy: (experimental) IAM managed policy granting read-only access scoped to this wildcard pattern. Same as readWritePolicy but without PutObject.
        :param read_write_policy: (experimental) IAM managed policy granting read-write access scoped to this wildcard pattern. Object actions (GetObject, GetObjectVersion, PutObject, HeadObject) on ``bucketArn/${pattern}*``. Bucket actions (ListBucket, ListBucketVersions) on ``bucketArn`` with ``StringLike`` condition on ``s3:prefix``.
        :param federated_role: (experimental) Federated IAM role for OIDC users scoped to this wildcard pattern. Only present when ``oidcProviders`` was specified.

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c8f21868a67e75b904a65ad94681e03484acc82b17cc660e91b8d03c967f2c29)
            check_type(argname="argument pattern", value=pattern, expected_type=type_hints["pattern"])
            check_type(argname="argument read_only_policy", value=read_only_policy, expected_type=type_hints["read_only_policy"])
            check_type(argname="argument read_write_policy", value=read_write_policy, expected_type=type_hints["read_write_policy"])
            check_type(argname="argument federated_role", value=federated_role, expected_type=type_hints["federated_role"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "pattern": pattern,
            "read_only_policy": read_only_policy,
            "read_write_policy": read_write_policy,
        }
        if federated_role is not None:
            self._values["federated_role"] = federated_role

    @builtins.property
    def pattern(self) -> builtins.str:
        '''(experimental) The wildcard pattern string (as provided in the config).

        :stability: experimental
        '''
        result = self._values.get("pattern")
        assert result is not None, "Required property 'pattern' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def read_only_policy(self) -> _aws_cdk_aws_iam_ceddda9d.ManagedPolicy:
        '''(experimental) IAM managed policy granting read-only access scoped to this wildcard pattern.

        Same as readWritePolicy but without PutObject.

        :stability: experimental
        '''
        result = self._values.get("read_only_policy")
        assert result is not None, "Required property 'read_only_policy' is missing"
        return typing.cast(_aws_cdk_aws_iam_ceddda9d.ManagedPolicy, result)

    @builtins.property
    def read_write_policy(self) -> _aws_cdk_aws_iam_ceddda9d.ManagedPolicy:
        '''(experimental) IAM managed policy granting read-write access scoped to this wildcard pattern.

        Object actions (GetObject, GetObjectVersion, PutObject, HeadObject)
        on ``bucketArn/${pattern}*``. Bucket actions (ListBucket, ListBucketVersions)
        on ``bucketArn`` with ``StringLike`` condition on ``s3:prefix``.

        :stability: experimental
        '''
        result = self._values.get("read_write_policy")
        assert result is not None, "Required property 'read_write_policy' is missing"
        return typing.cast(_aws_cdk_aws_iam_ceddda9d.ManagedPolicy, result)

    @builtins.property
    def federated_role(self) -> typing.Optional[_aws_cdk_aws_iam_ceddda9d.Role]:
        '''(experimental) Federated IAM role for OIDC users scoped to this wildcard pattern.

        Only present when ``oidcProviders`` was specified.

        :stability: experimental
        '''
        result = self._values.get("federated_role")
        return typing.cast(typing.Optional[_aws_cdk_aws_iam_ceddda9d.Role], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ImmuKVWildcardPrefixResources(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="cdk-immukv.OidcProvider",
    jsii_struct_bases=[],
    name_mapping={
        "client_ids": "clientIds",
        "issuer_url": "issuerUrl",
        "allowed_emails": "allowedEmails",
    },
)
class OidcProvider:
    def __init__(
        self,
        *,
        client_ids: typing.Sequence[builtins.str],
        issuer_url: builtins.str,
        allowed_emails: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param client_ids: (experimental) Client IDs (audiences) to trust from this provider.
        :param issuer_url: (experimental) OIDC issuer URL (must start with "https://").
        :param allowed_emails: (experimental) Email addresses allowed to assume the federated role. When provided, the trust policy adds a ``StringEquals`` condition on ``${issuerUrl}:email`` listing these addresses, restricting federation to the specified identities. Must be non-empty when provided. When omitted, the trust policy only checks ``:aud`` (client ID).

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a02241726bfefaea51032ab11ab6d1731518458c55afd8af4b779d4544396ab5)
            check_type(argname="argument client_ids", value=client_ids, expected_type=type_hints["client_ids"])
            check_type(argname="argument issuer_url", value=issuer_url, expected_type=type_hints["issuer_url"])
            check_type(argname="argument allowed_emails", value=allowed_emails, expected_type=type_hints["allowed_emails"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "client_ids": client_ids,
            "issuer_url": issuer_url,
        }
        if allowed_emails is not None:
            self._values["allowed_emails"] = allowed_emails

    @builtins.property
    def client_ids(self) -> typing.List[builtins.str]:
        '''(experimental) Client IDs (audiences) to trust from this provider.

        :stability: experimental
        '''
        result = self._values.get("client_ids")
        assert result is not None, "Required property 'client_ids' is missing"
        return typing.cast(typing.List[builtins.str], result)

    @builtins.property
    def issuer_url(self) -> builtins.str:
        '''(experimental) OIDC issuer URL (must start with "https://").

        :stability: experimental
        '''
        result = self._values.get("issuer_url")
        assert result is not None, "Required property 'issuer_url' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def allowed_emails(self) -> typing.Optional[typing.List[builtins.str]]:
        '''(experimental) Email addresses allowed to assume the federated role.

        When provided, the trust policy adds a ``StringEquals`` condition on
        ``${issuerUrl}:email`` listing these addresses, restricting federation
        to the specified identities. Must be non-empty when provided.

        When omitted, the trust policy only checks ``:aud`` (client ID).

        :stability: experimental
        '''
        result = self._values.get("allowed_emails")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "OidcProvider(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


__all__ = [
    "ImmuKV",
    "ImmuKVPrefixConfig",
    "ImmuKVPrefixResources",
    "ImmuKVProps",
    "ImmuKVWildcardPrefixConfig",
    "ImmuKVWildcardPrefixResources",
    "OidcProvider",
]

publication.publish()

def _typecheckingstub__cf89bf43b11632d41df9085531c36079dbf8b6c7b0e05db6941b2fedec39190f(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    prefixes: typing.Sequence[typing.Union[ImmuKVPrefixConfig, typing.Dict[builtins.str, typing.Any]]],
    bucket_name: typing.Optional[builtins.str] = None,
    use_kms_encryption: typing.Optional[builtins.bool] = None,
    wildcard_prefixes: typing.Optional[typing.Sequence[typing.Union[ImmuKVWildcardPrefixConfig, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7c96ca2ec9690ac7d03b17d77a26c0e36358f90b98107efcdc12aedee97903ee(
    s3_prefix: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__753a80a0e963e9c1f718a62c198744e0367b656fca53d607c6ac829c0d24a3da(
    pattern: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e2e3aa4d4c37ae1a9463501c85b7db01bafadd9b1cf1675edf0934d98c7e56f7(
    *,
    s3_prefix: builtins.str,
    key_version_retention: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
    key_versions_to_retain: typing.Optional[jsii.Number] = None,
    log_version_retention: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
    log_versions_to_retain: typing.Optional[jsii.Number] = None,
    oidc_providers: typing.Optional[typing.Sequence[typing.Union[OidcProvider, typing.Dict[builtins.str, typing.Any]]]] = None,
    oidc_read_only: typing.Optional[builtins.bool] = None,
    on_log_entry_created: typing.Optional[_aws_cdk_aws_s3_ceddda9d.IBucketNotificationDestination] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bf3d0970abe1671afa2decc2a3b7280123a1fe660e9e9a9cc648833bb5c3649d(
    *,
    read_only_policy: _aws_cdk_aws_iam_ceddda9d.ManagedPolicy,
    read_write_policy: _aws_cdk_aws_iam_ceddda9d.ManagedPolicy,
    s3_prefix: builtins.str,
    federated_role: typing.Optional[_aws_cdk_aws_iam_ceddda9d.Role] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2f38ba88d5eb7c35a08092e7656a1247dfe38e78f3d61072f111badd15889223(
    *,
    prefixes: typing.Sequence[typing.Union[ImmuKVPrefixConfig, typing.Dict[builtins.str, typing.Any]]],
    bucket_name: typing.Optional[builtins.str] = None,
    use_kms_encryption: typing.Optional[builtins.bool] = None,
    wildcard_prefixes: typing.Optional[typing.Sequence[typing.Union[ImmuKVWildcardPrefixConfig, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__099557eaa9530283869a2037b4e3b102d72d7e297b34cc366b86d7a99df20651(
    *,
    pattern: builtins.str,
    oidc_providers: typing.Optional[typing.Sequence[typing.Union[OidcProvider, typing.Dict[builtins.str, typing.Any]]]] = None,
    oidc_read_only: typing.Optional[builtins.bool] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c8f21868a67e75b904a65ad94681e03484acc82b17cc660e91b8d03c967f2c29(
    *,
    pattern: builtins.str,
    read_only_policy: _aws_cdk_aws_iam_ceddda9d.ManagedPolicy,
    read_write_policy: _aws_cdk_aws_iam_ceddda9d.ManagedPolicy,
    federated_role: typing.Optional[_aws_cdk_aws_iam_ceddda9d.Role] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a02241726bfefaea51032ab11ab6d1731518458c55afd8af4b779d4544396ab5(
    *,
    client_ids: typing.Sequence[builtins.str],
    issuer_url: builtins.str,
    allowed_emails: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass
