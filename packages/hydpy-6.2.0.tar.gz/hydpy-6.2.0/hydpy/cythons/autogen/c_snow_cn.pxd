#!python
# distutils: define_macros=NPY_NO_DEPRECATED_API=NPY_1_7_API_VERSION
# cython: language_level=3
# cython: cpow=True
# cython: boundscheck=False
# cython: wraparound=False
# cython: initializedcheck=False
# cython: cdivision=True
from typing import Optional
import numpy
cimport numpy
from libc.math cimport exp, fabs, log, sin, cos, tan, tanh, asin, acos, atan, isnan, isinf
from libc.math cimport NAN as nan
from libc.math cimport INFINITY as inf
import cython
from cpython.mem cimport PyMem_Malloc
from cpython.mem cimport PyMem_Realloc
from cpython.mem cimport PyMem_Free
from hydpy.cythons.autogen cimport configutils
from hydpy.cythons.autogen cimport interfaceutils
from hydpy.cythons.autogen cimport interputils
from hydpy.cythons.autogen import pointerutils
from hydpy.cythons.autogen cimport pointerutils
from hydpy.cythons.autogen cimport quadutils
from hydpy.cythons.autogen cimport rootutils
from hydpy.cythons.autogen cimport smoothutils
from hydpy.cythons.autogen cimport masterinterface
ctypedef void (*CallbackType) (Model)  noexcept nogil
cdef class CallbackWrapper:
    cdef CallbackType callback
@cython.final
cdef class Parameters:
    cdef public ControlParameters control
    cdef public DerivedParameters derived
    cdef public FixedParameters fixed
@cython.final
cdef class ControlParameters:
    cdef public numpy.int64_t nlayers
    cdef public double[:] zlayers
    cdef public double[:] layerarea
    cdef public double gradp
    cdef public double[:] gradtmean
    cdef public double[:] meanansolidprecip
    cdef public double cn1
    cdef public double cn2
    cdef public double cn3
    cdef public double cn4
    cdef public numpy.npy_bool hysteresis
@cython.final
cdef class DerivedParameters:
    cdef public numpy.int64_t[:] doy
    cdef public double[:] gthresh
    cdef public double zmean
@cython.final
cdef class FixedParameters:
    cdef public double zthreshold
    cdef public double minmelt
    cdef public double tthreshsnow
    cdef public double tthreshrain
    cdef public double ming
@cython.final
cdef class Sequences:
    cdef public InputSequences inputs
    cdef public FactorSequences factors
    cdef public FluxSequences fluxes
    cdef public StateSequences states
    cdef public LogSequences logs
    cdef public StateSequences old_states
    cdef public StateSequences new_states
@cython.final
cdef class InputSequences:
    cdef public double p
    cdef public numpy.int64_t _p_ndim
    cdef public numpy.int64_t _p_length
    cdef public bint _p_ramflag
    cdef public double[:] _p_array
    cdef public bint _p_diskflag_reading
    cdef public bint _p_diskflag_writing
    cdef public double[:] _p_ncarray
    cdef public bint _p_inputflag
    cdef double *_p_inputpointer
    cdef public double t
    cdef public numpy.int64_t _t_ndim
    cdef public numpy.int64_t _t_length
    cdef public bint _t_ramflag
    cdef public double[:] _t_array
    cdef public bint _t_diskflag_reading
    cdef public bint _t_diskflag_writing
    cdef public double[:] _t_ncarray
    cdef public bint _t_inputflag
    cdef double *_t_inputpointer
    cpdef inline void load_data(self, numpy.int64_t idx)  noexcept nogil
    cpdef inline void save_data(self, numpy.int64_t idx)  noexcept nogil
    cpdef inline set_pointerinput(self, str name, pointerutils.PDouble value)
@cython.final
cdef class FactorSequences:
    cdef public double[:] tlayer
    cdef public numpy.int64_t _tlayer_ndim
    cdef public numpy.int64_t _tlayer_length
    cdef public numpy.int64_t _tlayer_length_0
    cdef public bint _tlayer_ramflag
    cdef public double[:,:] _tlayer_array
    cdef public bint _tlayer_diskflag_reading
    cdef public bint _tlayer_diskflag_writing
    cdef public double[:] _tlayer_ncarray
    cdef public double[:] solidfractionprecipitation
    cdef public numpy.int64_t _solidfractionprecipitation_ndim
    cdef public numpy.int64_t _solidfractionprecipitation_length
    cdef public numpy.int64_t _solidfractionprecipitation_length_0
    cdef public bint _solidfractionprecipitation_ramflag
    cdef public double[:,:] _solidfractionprecipitation_array
    cdef public bint _solidfractionprecipitation_diskflag_reading
    cdef public bint _solidfractionprecipitation_diskflag_writing
    cdef public double[:] _solidfractionprecipitation_ncarray
    cpdef inline void load_data(self, numpy.int64_t idx)  noexcept nogil
    cpdef inline void save_data(self, numpy.int64_t idx)  noexcept nogil
    cpdef inline set_pointeroutput(self, str name, pointerutils.PDouble value)
    cpdef inline void update_outputs(self) noexcept nogil
@cython.final
cdef class FluxSequences:
    cdef public double[:] player
    cdef public numpy.int64_t _player_ndim
    cdef public numpy.int64_t _player_length
    cdef public numpy.int64_t _player_length_0
    cdef public bint _player_ramflag
    cdef public double[:,:] _player_array
    cdef public bint _player_diskflag_reading
    cdef public bint _player_diskflag_writing
    cdef public double[:] _player_ncarray
    cdef public double[:] psnowlayer
    cdef public numpy.int64_t _psnowlayer_ndim
    cdef public numpy.int64_t _psnowlayer_length
    cdef public numpy.int64_t _psnowlayer_length_0
    cdef public bint _psnowlayer_ramflag
    cdef public double[:,:] _psnowlayer_array
    cdef public bint _psnowlayer_diskflag_reading
    cdef public bint _psnowlayer_diskflag_writing
    cdef public double[:] _psnowlayer_ncarray
    cdef public double[:] prainlayer
    cdef public numpy.int64_t _prainlayer_ndim
    cdef public numpy.int64_t _prainlayer_length
    cdef public numpy.int64_t _prainlayer_length_0
    cdef public bint _prainlayer_ramflag
    cdef public double[:,:] _prainlayer_array
    cdef public bint _prainlayer_diskflag_reading
    cdef public bint _prainlayer_diskflag_writing
    cdef public double[:] _prainlayer_ncarray
    cdef public double[:] potmelt
    cdef public numpy.int64_t _potmelt_ndim
    cdef public numpy.int64_t _potmelt_length
    cdef public numpy.int64_t _potmelt_length_0
    cdef public bint _potmelt_ramflag
    cdef public double[:,:] _potmelt_array
    cdef public bint _potmelt_diskflag_reading
    cdef public bint _potmelt_diskflag_writing
    cdef public double[:] _potmelt_ncarray
    cdef public double[:] melt
    cdef public numpy.int64_t _melt_ndim
    cdef public numpy.int64_t _melt_length
    cdef public numpy.int64_t _melt_length_0
    cdef public bint _melt_ramflag
    cdef public double[:,:] _melt_array
    cdef public bint _melt_diskflag_reading
    cdef public bint _melt_diskflag_writing
    cdef public double[:] _melt_ncarray
    cdef public double[:] pnetlayer
    cdef public numpy.int64_t _pnetlayer_ndim
    cdef public numpy.int64_t _pnetlayer_length
    cdef public numpy.int64_t _pnetlayer_length_0
    cdef public bint _pnetlayer_ramflag
    cdef public double[:,:] _pnetlayer_array
    cdef public bint _pnetlayer_diskflag_reading
    cdef public bint _pnetlayer_diskflag_writing
    cdef public double[:] _pnetlayer_ncarray
    cdef public double pnet
    cdef public numpy.int64_t _pnet_ndim
    cdef public numpy.int64_t _pnet_length
    cdef public bint _pnet_ramflag
    cdef public double[:] _pnet_array
    cdef public bint _pnet_diskflag_reading
    cdef public bint _pnet_diskflag_writing
    cdef public double[:] _pnet_ncarray
    cdef public bint _pnet_outputflag
    cdef double *_pnet_outputpointer
    cpdef inline void load_data(self, numpy.int64_t idx)  noexcept nogil
    cpdef inline void save_data(self, numpy.int64_t idx)  noexcept nogil
    cpdef inline set_pointeroutput(self, str name, pointerutils.PDouble value)
    cpdef inline void update_outputs(self) noexcept nogil
@cython.final
cdef class StateSequences:
    cdef public double[:] g
    cdef public numpy.int64_t _g_ndim
    cdef public numpy.int64_t _g_length
    cdef public numpy.int64_t _g_length_0
    cdef public bint _g_ramflag
    cdef public double[:,:] _g_array
    cdef public bint _g_diskflag_reading
    cdef public bint _g_diskflag_writing
    cdef public double[:] _g_ncarray
    cdef public double[:] etg
    cdef public numpy.int64_t _etg_ndim
    cdef public numpy.int64_t _etg_length
    cdef public numpy.int64_t _etg_length_0
    cdef public bint _etg_ramflag
    cdef public double[:,:] _etg_array
    cdef public bint _etg_diskflag_reading
    cdef public bint _etg_diskflag_writing
    cdef public double[:] _etg_ncarray
    cdef public double[:] gratio
    cdef public numpy.int64_t _gratio_ndim
    cdef public numpy.int64_t _gratio_length
    cdef public numpy.int64_t _gratio_length_0
    cdef public bint _gratio_ramflag
    cdef public double[:,:] _gratio_array
    cdef public bint _gratio_diskflag_reading
    cdef public bint _gratio_diskflag_writing
    cdef public double[:] _gratio_ncarray
    cpdef inline void load_data(self, numpy.int64_t idx)  noexcept nogil
    cpdef inline void save_data(self, numpy.int64_t idx)  noexcept nogil
    cpdef inline set_pointeroutput(self, str name, pointerutils.PDouble value)
    cpdef inline void update_outputs(self) noexcept nogil
@cython.final
cdef class LogSequences:
    cdef public double[:] glocalmax
    cdef public numpy.int64_t _glocalmax_ndim
    cdef public numpy.int64_t _glocalmax_length
    cdef public numpy.int64_t _glocalmax_length_0
@cython.final
cdef class Model:
    cdef public numpy.int64_t idx_sim
    cdef public numpy.npy_bool threading
    cdef public Parameters parameters
    cdef public Sequences sequences
    cpdef inline void simulate(self, numpy.int64_t idx)  noexcept nogil
    cpdef void simulate_period(self, numpy.int64_t i0, numpy.int64_t i1)  noexcept nogil
    cpdef void reset_reuseflags(self) noexcept nogil
    cpdef void load_data(self, numpy.int64_t idx) noexcept nogil
    cpdef void save_data(self, numpy.int64_t idx) noexcept nogil
    cpdef void new2old(self) noexcept nogil
    cpdef inline void run(self) noexcept nogil
    cpdef void update_inlets(self) noexcept nogil
    cpdef void update_outlets(self) noexcept nogil
    cpdef void update_observers(self) noexcept nogil
    cpdef void update_receivers(self, numpy.int64_t idx) noexcept nogil
    cpdef void update_senders(self, numpy.int64_t idx) noexcept nogil
    cpdef void update_outputs(self) noexcept nogil
    cpdef inline void calc_player_v1(self) noexcept nogil
    cpdef inline void calc_tlayer_v1(self) noexcept nogil
    cpdef inline void calc_solidfractionprecipitation_v1(self) noexcept nogil
    cpdef inline void calc_prainlayer_v1(self) noexcept nogil
    cpdef inline void calc_psnowlayer_v1(self) noexcept nogil
    cpdef inline void update_g_v1(self) noexcept nogil
    cpdef inline void calc_etg_v1(self) noexcept nogil
    cpdef inline void calc_potmelt_v1(self) noexcept nogil
    cpdef inline void update_gratio_glocalmax_v1(self) noexcept nogil
    cpdef inline void calc_melt_v1(self) noexcept nogil
    cpdef inline void update_g_v2(self) noexcept nogil
    cpdef inline void update_gratio_glocalmax_v2(self) noexcept nogil
    cpdef inline void calc_pnetlayer_v1(self) noexcept nogil
    cpdef inline void calc_pnet_v1(self) noexcept nogil
    cpdef inline double return_t_v1(self, double t, numpy.int64_t k, double[:] g) noexcept nogil
    cpdef inline void calc_player(self) noexcept nogil
    cpdef inline void calc_tlayer(self) noexcept nogil
    cpdef inline void calc_solidfractionprecipitation(self) noexcept nogil
    cpdef inline void calc_prainlayer(self) noexcept nogil
    cpdef inline void calc_psnowlayer(self) noexcept nogil
    cpdef inline void calc_etg(self) noexcept nogil
    cpdef inline void calc_potmelt(self) noexcept nogil
    cpdef inline void calc_melt(self) noexcept nogil
    cpdef inline void calc_pnetlayer(self) noexcept nogil
    cpdef inline void calc_pnet(self) noexcept nogil
    cpdef inline double return_t(self, double t, numpy.int64_t k, double[:] g) noexcept nogil
