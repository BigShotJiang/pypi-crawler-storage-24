#!python
# distutils: define_macros=NPY_NO_DEPRECATED_API=NPY_1_7_API_VERSION
# cython: language_level=3
# cython: cpow=True
# cython: boundscheck=False
# cython: wraparound=False
# cython: initializedcheck=False
# cython: cdivision=True
from typing import Optional
import numpy
cimport numpy
from libc.math cimport exp, fabs, log, sin, cos, tan, tanh, asin, acos, atan, isnan, isinf
from libc.math cimport NAN as nan
from libc.math cimport INFINITY as inf
import cython
from cpython.mem cimport PyMem_Malloc
from cpython.mem cimport PyMem_Realloc
from cpython.mem cimport PyMem_Free
from hydpy.cythons.autogen cimport configutils
from hydpy.cythons.autogen cimport interfaceutils
from hydpy.cythons.autogen cimport interputils
from hydpy.cythons.autogen import pointerutils
from hydpy.cythons.autogen cimport pointerutils
from hydpy.cythons.autogen cimport quadutils
from hydpy.cythons.autogen cimport rootutils
from hydpy.cythons.autogen cimport smoothutils
from hydpy.cythons.autogen cimport masterinterface


cdef void do_nothing(Model model)  noexcept nogil:
    pass

cpdef get_wrapper():
    cdef CallbackWrapper wrapper = CallbackWrapper()
    wrapper.callback = do_nothing
    return wrapper

@cython.final
cdef class Parameters:
    pass
@cython.final
cdef class ControlParameters:
    pass
@cython.final
cdef class DerivedParameters:
    pass
@cython.final
cdef class FixedParameters:
    pass
@cython.final
cdef class Sequences:
    pass
@cython.final
cdef class InputSequences:
    cpdef inline void load_data(self, numpy.int64_t idx)  noexcept nogil:
        cdef numpy.int64_t k
        if self._p_inputflag:
            self.p = self._p_inputpointer[0]
        elif self._p_diskflag_reading:
            self.p = self._p_ncarray[0]
        elif self._p_ramflag:
            self.p = self._p_array[idx]
        if self._t_inputflag:
            self.t = self._t_inputpointer[0]
        elif self._t_diskflag_reading:
            self.t = self._t_ncarray[0]
        elif self._t_ramflag:
            self.t = self._t_array[idx]
    cpdef inline void save_data(self, numpy.int64_t idx)  noexcept nogil:
        cdef numpy.int64_t k
        if self._p_diskflag_writing:
            self._p_ncarray[0] = self.p
        if self._p_ramflag:
            self._p_array[idx] = self.p
        if self._t_diskflag_writing:
            self._t_ncarray[0] = self.t
        if self._t_ramflag:
            self._t_array[idx] = self.t
    cpdef inline set_pointerinput(self, str name, pointerutils.PDouble value):
        if name == "p":
            self._p_inputpointer = value.p_value
        if name == "t":
            self._t_inputpointer = value.p_value
@cython.final
cdef class FactorSequences:
    cpdef inline void load_data(self, numpy.int64_t idx)  noexcept nogil:
        cdef numpy.int64_t jdx0
        cdef numpy.int64_t k
        if self._tlayer_diskflag_reading:
            k = 0
            for jdx0 in range(self._tlayer_length_0):
                self.tlayer[jdx0] = self._tlayer_ncarray[k]
                k += 1
        elif self._tlayer_ramflag:
            for jdx0 in range(self._tlayer_length_0):
                self.tlayer[jdx0] = self._tlayer_array[idx, jdx0]
        if self._solidfractionprecipitation_diskflag_reading:
            k = 0
            for jdx0 in range(self._solidfractionprecipitation_length_0):
                self.solidfractionprecipitation[jdx0] = self._solidfractionprecipitation_ncarray[k]
                k += 1
        elif self._solidfractionprecipitation_ramflag:
            for jdx0 in range(self._solidfractionprecipitation_length_0):
                self.solidfractionprecipitation[jdx0] = self._solidfractionprecipitation_array[idx, jdx0]
    cpdef inline void save_data(self, numpy.int64_t idx)  noexcept nogil:
        cdef numpy.int64_t jdx0
        cdef numpy.int64_t k
        if self._tlayer_diskflag_writing:
            k = 0
            for jdx0 in range(self._tlayer_length_0):
                self._tlayer_ncarray[k] = self.tlayer[jdx0]
                k += 1
        if self._tlayer_ramflag:
            for jdx0 in range(self._tlayer_length_0):
                self._tlayer_array[idx, jdx0] = self.tlayer[jdx0]
        if self._solidfractionprecipitation_diskflag_writing:
            k = 0
            for jdx0 in range(self._solidfractionprecipitation_length_0):
                self._solidfractionprecipitation_ncarray[k] = self.solidfractionprecipitation[jdx0]
                k += 1
        if self._solidfractionprecipitation_ramflag:
            for jdx0 in range(self._solidfractionprecipitation_length_0):
                self._solidfractionprecipitation_array[idx, jdx0] = self.solidfractionprecipitation[jdx0]
    cpdef inline set_pointeroutput(self, str name, pointerutils.PDouble value):
        pass
    cpdef inline void update_outputs(self) noexcept nogil:
        pass
@cython.final
cdef class FluxSequences:
    cpdef inline void load_data(self, numpy.int64_t idx)  noexcept nogil:
        cdef numpy.int64_t jdx0
        cdef numpy.int64_t k
        if self._player_diskflag_reading:
            k = 0
            for jdx0 in range(self._player_length_0):
                self.player[jdx0] = self._player_ncarray[k]
                k += 1
        elif self._player_ramflag:
            for jdx0 in range(self._player_length_0):
                self.player[jdx0] = self._player_array[idx, jdx0]
        if self._psnowlayer_diskflag_reading:
            k = 0
            for jdx0 in range(self._psnowlayer_length_0):
                self.psnowlayer[jdx0] = self._psnowlayer_ncarray[k]
                k += 1
        elif self._psnowlayer_ramflag:
            for jdx0 in range(self._psnowlayer_length_0):
                self.psnowlayer[jdx0] = self._psnowlayer_array[idx, jdx0]
        if self._prainlayer_diskflag_reading:
            k = 0
            for jdx0 in range(self._prainlayer_length_0):
                self.prainlayer[jdx0] = self._prainlayer_ncarray[k]
                k += 1
        elif self._prainlayer_ramflag:
            for jdx0 in range(self._prainlayer_length_0):
                self.prainlayer[jdx0] = self._prainlayer_array[idx, jdx0]
        if self._potmelt_diskflag_reading:
            k = 0
            for jdx0 in range(self._potmelt_length_0):
                self.potmelt[jdx0] = self._potmelt_ncarray[k]
                k += 1
        elif self._potmelt_ramflag:
            for jdx0 in range(self._potmelt_length_0):
                self.potmelt[jdx0] = self._potmelt_array[idx, jdx0]
        if self._melt_diskflag_reading:
            k = 0
            for jdx0 in range(self._melt_length_0):
                self.melt[jdx0] = self._melt_ncarray[k]
                k += 1
        elif self._melt_ramflag:
            for jdx0 in range(self._melt_length_0):
                self.melt[jdx0] = self._melt_array[idx, jdx0]
        if self._pnetlayer_diskflag_reading:
            k = 0
            for jdx0 in range(self._pnetlayer_length_0):
                self.pnetlayer[jdx0] = self._pnetlayer_ncarray[k]
                k += 1
        elif self._pnetlayer_ramflag:
            for jdx0 in range(self._pnetlayer_length_0):
                self.pnetlayer[jdx0] = self._pnetlayer_array[idx, jdx0]
        if self._pnet_diskflag_reading:
            self.pnet = self._pnet_ncarray[0]
        elif self._pnet_ramflag:
            self.pnet = self._pnet_array[idx]
    cpdef inline void save_data(self, numpy.int64_t idx)  noexcept nogil:
        cdef numpy.int64_t jdx0
        cdef numpy.int64_t k
        if self._player_diskflag_writing:
            k = 0
            for jdx0 in range(self._player_length_0):
                self._player_ncarray[k] = self.player[jdx0]
                k += 1
        if self._player_ramflag:
            for jdx0 in range(self._player_length_0):
                self._player_array[idx, jdx0] = self.player[jdx0]
        if self._psnowlayer_diskflag_writing:
            k = 0
            for jdx0 in range(self._psnowlayer_length_0):
                self._psnowlayer_ncarray[k] = self.psnowlayer[jdx0]
                k += 1
        if self._psnowlayer_ramflag:
            for jdx0 in range(self._psnowlayer_length_0):
                self._psnowlayer_array[idx, jdx0] = self.psnowlayer[jdx0]
        if self._prainlayer_diskflag_writing:
            k = 0
            for jdx0 in range(self._prainlayer_length_0):
                self._prainlayer_ncarray[k] = self.prainlayer[jdx0]
                k += 1
        if self._prainlayer_ramflag:
            for jdx0 in range(self._prainlayer_length_0):
                self._prainlayer_array[idx, jdx0] = self.prainlayer[jdx0]
        if self._potmelt_diskflag_writing:
            k = 0
            for jdx0 in range(self._potmelt_length_0):
                self._potmelt_ncarray[k] = self.potmelt[jdx0]
                k += 1
        if self._potmelt_ramflag:
            for jdx0 in range(self._potmelt_length_0):
                self._potmelt_array[idx, jdx0] = self.potmelt[jdx0]
        if self._melt_diskflag_writing:
            k = 0
            for jdx0 in range(self._melt_length_0):
                self._melt_ncarray[k] = self.melt[jdx0]
                k += 1
        if self._melt_ramflag:
            for jdx0 in range(self._melt_length_0):
                self._melt_array[idx, jdx0] = self.melt[jdx0]
        if self._pnetlayer_diskflag_writing:
            k = 0
            for jdx0 in range(self._pnetlayer_length_0):
                self._pnetlayer_ncarray[k] = self.pnetlayer[jdx0]
                k += 1
        if self._pnetlayer_ramflag:
            for jdx0 in range(self._pnetlayer_length_0):
                self._pnetlayer_array[idx, jdx0] = self.pnetlayer[jdx0]
        if self._pnet_diskflag_writing:
            self._pnet_ncarray[0] = self.pnet
        if self._pnet_ramflag:
            self._pnet_array[idx] = self.pnet
    cpdef inline set_pointeroutput(self, str name, pointerutils.PDouble value):
        if name == "pnet":
            self._pnet_outputpointer = value.p_value
    cpdef inline void update_outputs(self) noexcept nogil:
        if self._pnet_outputflag:
            self._pnet_outputpointer[0] = self.pnet
@cython.final
cdef class StateSequences:
    cpdef inline void load_data(self, numpy.int64_t idx)  noexcept nogil:
        cdef numpy.int64_t jdx0
        cdef numpy.int64_t k
        if self._g_diskflag_reading:
            k = 0
            for jdx0 in range(self._g_length_0):
                self.g[jdx0] = self._g_ncarray[k]
                k += 1
        elif self._g_ramflag:
            for jdx0 in range(self._g_length_0):
                self.g[jdx0] = self._g_array[idx, jdx0]
        if self._etg_diskflag_reading:
            k = 0
            for jdx0 in range(self._etg_length_0):
                self.etg[jdx0] = self._etg_ncarray[k]
                k += 1
        elif self._etg_ramflag:
            for jdx0 in range(self._etg_length_0):
                self.etg[jdx0] = self._etg_array[idx, jdx0]
        if self._gratio_diskflag_reading:
            k = 0
            for jdx0 in range(self._gratio_length_0):
                self.gratio[jdx0] = self._gratio_ncarray[k]
                k += 1
        elif self._gratio_ramflag:
            for jdx0 in range(self._gratio_length_0):
                self.gratio[jdx0] = self._gratio_array[idx, jdx0]
    cpdef inline void save_data(self, numpy.int64_t idx)  noexcept nogil:
        cdef numpy.int64_t jdx0
        cdef numpy.int64_t k
        if self._g_diskflag_writing:
            k = 0
            for jdx0 in range(self._g_length_0):
                self._g_ncarray[k] = self.g[jdx0]
                k += 1
        if self._g_ramflag:
            for jdx0 in range(self._g_length_0):
                self._g_array[idx, jdx0] = self.g[jdx0]
        if self._etg_diskflag_writing:
            k = 0
            for jdx0 in range(self._etg_length_0):
                self._etg_ncarray[k] = self.etg[jdx0]
                k += 1
        if self._etg_ramflag:
            for jdx0 in range(self._etg_length_0):
                self._etg_array[idx, jdx0] = self.etg[jdx0]
        if self._gratio_diskflag_writing:
            k = 0
            for jdx0 in range(self._gratio_length_0):
                self._gratio_ncarray[k] = self.gratio[jdx0]
                k += 1
        if self._gratio_ramflag:
            for jdx0 in range(self._gratio_length_0):
                self._gratio_array[idx, jdx0] = self.gratio[jdx0]
    cpdef inline set_pointeroutput(self, str name, pointerutils.PDouble value):
        pass
    cpdef inline void update_outputs(self) noexcept nogil:
        pass
@cython.final
cdef class LogSequences:
    pass
@cython.final
cdef class Model:
    cpdef inline void simulate(self, numpy.int64_t idx)  noexcept nogil:
        cdef double state
        self.idx_sim = idx
        self.load_data(idx)
        self.run()
        self.new2old()
        self.update_outputs()
    cpdef void simulate_period(self, numpy.int64_t i0, numpy.int64_t i1)  noexcept nogil:
        cdef numpy.int64_t i
        with nogil:
            for i in range(i0, i1):
                self.simulate(i)
                self.update_senders(i)
                self.update_receivers(i)
                self.save_data(i)
    cpdef void reset_reuseflags(self) noexcept nogil:
        pass
    cpdef void load_data(self, numpy.int64_t idx) noexcept nogil:
        self.idx_sim = idx
        self.sequences.inputs.load_data(idx)
    cpdef void save_data(self, numpy.int64_t idx) noexcept nogil:
        self.idx_sim = idx
        self.sequences.inputs.save_data(idx)
        self.sequences.factors.save_data(idx)
        self.sequences.fluxes.save_data(idx)
        self.sequences.states.save_data(idx)
    cpdef void new2old(self) noexcept nogil:
        cdef numpy.int64_t jdx0
        for jdx0 in range(self.sequences.states._g_length_0):
            self.sequences.old_states.g[jdx0] = self.sequences.new_states.g[jdx0]
        for jdx0 in range(self.sequences.states._etg_length_0):
            self.sequences.old_states.etg[jdx0] = self.sequences.new_states.etg[jdx0]
        for jdx0 in range(self.sequences.states._gratio_length_0):
            self.sequences.old_states.gratio[jdx0] = self.sequences.new_states.gratio[jdx0]
    cpdef inline void run(self) noexcept nogil:
        self.calc_player_v1()
        self.calc_tlayer_v1()
        self.calc_solidfractionprecipitation_v1()
        self.calc_prainlayer_v1()
        self.calc_psnowlayer_v1()
        self.update_g_v1()
        self.calc_etg_v1()
        self.calc_potmelt_v1()
        self.update_gratio_glocalmax_v1()
        self.calc_melt_v1()
        self.update_g_v2()
        self.update_gratio_glocalmax_v2()
        self.calc_pnetlayer_v1()
        self.calc_pnet_v1()
    cpdef void update_inlets(self) noexcept nogil:
        cdef numpy.int64_t i
        pass
    cpdef void update_outlets(self) noexcept nogil:
        pass
        cdef numpy.int64_t i
    cpdef void update_observers(self) noexcept nogil:
        cdef numpy.int64_t i
        pass
    cpdef void update_receivers(self, numpy.int64_t idx) noexcept nogil:
        self.idx_sim = idx
        cdef numpy.int64_t i
        pass
    cpdef void update_senders(self, numpy.int64_t idx) noexcept nogil:
        self.idx_sim = idx
        pass
        cdef numpy.int64_t i
    cpdef void update_outputs(self) noexcept nogil:
        if not self.threading:
            self.sequences.fluxes.update_outputs()
    cpdef inline void calc_player_v1(self) noexcept nogil:
        cdef double delta
        cdef numpy.int64_t k
        cdef double p
        p = 0.0
        for k in range(self.parameters.control.nlayers):
            if self.parameters.control.zlayers[k] <= self.parameters.fixed.zthreshold:
                delta = self.parameters.control.zlayers[k] - self.parameters.derived.zmean
            else:
                delta = max(self.parameters.fixed.zthreshold - self.parameters.derived.zmean, 0.0)
            self.sequences.fluxes.player[k] = self.sequences.inputs.p * exp(self.parameters.control.gradp * delta)
            p = p + (self.sequences.fluxes.player[k] * self.parameters.control.layerarea[k])
        if p > 0.0:
            for k in range(self.parameters.control.nlayers):
                self.sequences.fluxes.player[k] = self.sequences.fluxes.player[k] / p * self.sequences.inputs.p
    cpdef inline void calc_tlayer_v1(self) noexcept nogil:
        cdef numpy.int64_t k
        for k in range(self.parameters.control.nlayers):
            self.sequences.factors.tlayer[k] = self.return_t_v1(self.sequences.inputs.t, k, self.parameters.control.gradtmean)
    cpdef inline void calc_solidfractionprecipitation_v1(self) noexcept nogil:
        cdef double t
        cdef double s
        cdef double r
        cdef numpy.int64_t k
        for k in range(self.parameters.control.nlayers):
            r = self.parameters.fixed.tthreshrain
            s = self.parameters.fixed.tthreshsnow
            t = self.sequences.factors.tlayer[k]
            self.sequences.factors.solidfractionprecipitation[k] = min(max((r - t) / (r - s), 0.0), 1.0)
    cpdef inline void calc_prainlayer_v1(self) noexcept nogil:
        cdef double f
        cdef numpy.int64_t k
        for k in range(self.parameters.control.nlayers):
            f = self.sequences.factors.solidfractionprecipitation[k]
            self.sequences.fluxes.prainlayer[k] = (1.0 - f) * self.sequences.fluxes.player[k]
    cpdef inline void calc_psnowlayer_v1(self) noexcept nogil:
        cdef numpy.int64_t k
        for k in range(self.parameters.control.nlayers):
            self.sequences.fluxes.psnowlayer[k] = self.sequences.factors.solidfractionprecipitation[k] * self.sequences.fluxes.player[k]
    cpdef inline void update_g_v1(self) noexcept nogil:
        cdef numpy.int64_t k
        for k in range(self.parameters.control.nlayers):
            self.sequences.states.g[k] = self.sequences.states.g[k] + (self.sequences.fluxes.psnowlayer[k])
    cpdef inline void calc_etg_v1(self) noexcept nogil:
        cdef numpy.int64_t k
        for k in range(self.parameters.control.nlayers):
            self.sequences.states.etg[k] = min(                self.parameters.control.cn1 * self.sequences.states.etg[k] + (1.0 - self.parameters.control.cn1) * self.sequences.factors.tlayer[k], 0.0            )
    cpdef inline void calc_potmelt_v1(self) noexcept nogil:
        cdef numpy.int64_t k
        for k in range(self.parameters.control.nlayers):
            if self.sequences.states.etg[k] < 0.0:
                self.sequences.fluxes.potmelt[k] = 0.0
            else:
                self.sequences.fluxes.potmelt[k] = min(self.sequences.states.g[k], max(self.parameters.control.cn2 * self.sequences.factors.tlayer[k], 0.0))
    cpdef inline void update_gratio_glocalmax_v1(self) noexcept nogil:
        cdef numpy.int64_t k
        for k in range(self.parameters.control.nlayers):
            if self.parameters.control.hysteresis:
                if self.sequences.logs.glocalmax[k] == 0.0:
                    self.sequences.logs.glocalmax[k] = self.parameters.derived.gthresh[k]
                if self.sequences.fluxes.potmelt[k] > 0.0:
                    if self.sequences.states.gratio[k] == 1.0:
                        self.sequences.logs.glocalmax[k] = min(self.sequences.states.g[k], self.sequences.logs.glocalmax[k])
                    self.sequences.states.gratio[k] = min(self.sequences.states.g[k] / self.sequences.logs.glocalmax[k], 1.0)
            else:
                self.sequences.states.gratio[k] = min(self.sequences.states.g[k] / self.parameters.derived.gthresh[k], 1.0)
                self.sequences.logs.glocalmax[k] = 0.0
    cpdef inline void calc_melt_v1(self) noexcept nogil:
        cdef numpy.int64_t k
        for k in range(self.parameters.control.nlayers):
            self.sequences.fluxes.melt[k] = self.sequences.fluxes.potmelt[k]
            if self.sequences.states.g[k] >= self.parameters.fixed.ming:
                self.sequences.fluxes.melt[k] = self.sequences.fluxes.melt[k] * ((1.0 - self.parameters.fixed.minmelt) * self.sequences.states.gratio[k] + self.parameters.fixed.minmelt)
    cpdef inline void update_g_v2(self) noexcept nogil:
        cdef numpy.int64_t k
        for k in range(self.parameters.control.nlayers):
            self.sequences.states.g[k] = self.sequences.states.g[k] - (self.sequences.fluxes.melt[k])
    cpdef inline void update_gratio_glocalmax_v2(self) noexcept nogil:
        cdef double dg
        cdef numpy.int64_t k
        if self.parameters.control.hysteresis:
            for k in range(self.parameters.control.nlayers):
                dg = self.sequences.fluxes.psnowlayer[k] - self.sequences.fluxes.melt[k]
                if dg > 0.0:
                    self.sequences.states.gratio[k] = min(self.sequences.states.gratio[k] + dg / self.parameters.control.cn3, 1.0)
                    if self.sequences.states.gratio[k] == 1.0:
                        self.sequences.logs.glocalmax[k] = self.parameters.derived.gthresh[k]
                elif dg < 0.0:
                    self.sequences.states.gratio[k] = min(self.sequences.states.g[k] / self.sequences.logs.glocalmax[k], 1.0)
    cpdef inline void calc_pnetlayer_v1(self) noexcept nogil:
        cdef numpy.int64_t k
        for k in range(self.parameters.control.nlayers):
            self.sequences.fluxes.pnetlayer[k] = self.sequences.fluxes.prainlayer[k] + self.sequences.fluxes.melt[k]
    cpdef inline void calc_pnet_v1(self) noexcept nogil:
        cdef numpy.int64_t k
        self.sequences.fluxes.pnet = 0.0
        for k in range(self.parameters.control.nlayers):
            self.sequences.fluxes.pnet = self.sequences.fluxes.pnet + (self.sequences.fluxes.pnetlayer[k] * self.parameters.control.layerarea[k])
    cpdef inline double return_t_v1(self, double t, numpy.int64_t k, double[:] g) noexcept nogil:
        return t + (self.parameters.derived.zmean - self.parameters.control.zlayers[k]) * g[self.parameters.derived.doy[self.idx_sim]] / 100.0
    cpdef inline void calc_player(self) noexcept nogil:
        cdef double delta
        cdef numpy.int64_t k
        cdef double p
        p = 0.0
        for k in range(self.parameters.control.nlayers):
            if self.parameters.control.zlayers[k] <= self.parameters.fixed.zthreshold:
                delta = self.parameters.control.zlayers[k] - self.parameters.derived.zmean
            else:
                delta = max(self.parameters.fixed.zthreshold - self.parameters.derived.zmean, 0.0)
            self.sequences.fluxes.player[k] = self.sequences.inputs.p * exp(self.parameters.control.gradp * delta)
            p = p + (self.sequences.fluxes.player[k] * self.parameters.control.layerarea[k])
        if p > 0.0:
            for k in range(self.parameters.control.nlayers):
                self.sequences.fluxes.player[k] = self.sequences.fluxes.player[k] / p * self.sequences.inputs.p
    cpdef inline void calc_tlayer(self) noexcept nogil:
        cdef numpy.int64_t k
        for k in range(self.parameters.control.nlayers):
            self.sequences.factors.tlayer[k] = self.return_t_v1(self.sequences.inputs.t, k, self.parameters.control.gradtmean)
    cpdef inline void calc_solidfractionprecipitation(self) noexcept nogil:
        cdef double t
        cdef double s
        cdef double r
        cdef numpy.int64_t k
        for k in range(self.parameters.control.nlayers):
            r = self.parameters.fixed.tthreshrain
            s = self.parameters.fixed.tthreshsnow
            t = self.sequences.factors.tlayer[k]
            self.sequences.factors.solidfractionprecipitation[k] = min(max((r - t) / (r - s), 0.0), 1.0)
    cpdef inline void calc_prainlayer(self) noexcept nogil:
        cdef double f
        cdef numpy.int64_t k
        for k in range(self.parameters.control.nlayers):
            f = self.sequences.factors.solidfractionprecipitation[k]
            self.sequences.fluxes.prainlayer[k] = (1.0 - f) * self.sequences.fluxes.player[k]
    cpdef inline void calc_psnowlayer(self) noexcept nogil:
        cdef numpy.int64_t k
        for k in range(self.parameters.control.nlayers):
            self.sequences.fluxes.psnowlayer[k] = self.sequences.factors.solidfractionprecipitation[k] * self.sequences.fluxes.player[k]
    cpdef inline void calc_etg(self) noexcept nogil:
        cdef numpy.int64_t k
        for k in range(self.parameters.control.nlayers):
            self.sequences.states.etg[k] = min(                self.parameters.control.cn1 * self.sequences.states.etg[k] + (1.0 - self.parameters.control.cn1) * self.sequences.factors.tlayer[k], 0.0            )
    cpdef inline void calc_potmelt(self) noexcept nogil:
        cdef numpy.int64_t k
        for k in range(self.parameters.control.nlayers):
            if self.sequences.states.etg[k] < 0.0:
                self.sequences.fluxes.potmelt[k] = 0.0
            else:
                self.sequences.fluxes.potmelt[k] = min(self.sequences.states.g[k], max(self.parameters.control.cn2 * self.sequences.factors.tlayer[k], 0.0))
    cpdef inline void calc_melt(self) noexcept nogil:
        cdef numpy.int64_t k
        for k in range(self.parameters.control.nlayers):
            self.sequences.fluxes.melt[k] = self.sequences.fluxes.potmelt[k]
            if self.sequences.states.g[k] >= self.parameters.fixed.ming:
                self.sequences.fluxes.melt[k] = self.sequences.fluxes.melt[k] * ((1.0 - self.parameters.fixed.minmelt) * self.sequences.states.gratio[k] + self.parameters.fixed.minmelt)
    cpdef inline void calc_pnetlayer(self) noexcept nogil:
        cdef numpy.int64_t k
        for k in range(self.parameters.control.nlayers):
            self.sequences.fluxes.pnetlayer[k] = self.sequences.fluxes.prainlayer[k] + self.sequences.fluxes.melt[k]
    cpdef inline void calc_pnet(self) noexcept nogil:
        cdef numpy.int64_t k
        self.sequences.fluxes.pnet = 0.0
        for k in range(self.parameters.control.nlayers):
            self.sequences.fluxes.pnet = self.sequences.fluxes.pnet + (self.sequences.fluxes.pnetlayer[k] * self.parameters.control.layerarea[k])
    cpdef inline double return_t(self, double t, numpy.int64_t k, double[:] g) noexcept nogil:
        return t + (self.parameters.derived.zmean - self.parameters.control.zlayers[k]) * g[self.parameters.derived.doy[self.idx_sim]] / 100.0
