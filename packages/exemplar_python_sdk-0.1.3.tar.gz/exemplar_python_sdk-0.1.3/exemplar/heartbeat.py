from __future__ import annotations

import asyncio
import logging
from typing import Any, Optional

import httpx

from exemplar.client import get_client

logger = logging.getLogger(__name__)


def send_heartbeat(
    monitor_id: str,
    metadata: Optional[dict[str, Any]] = None,
    *,
    raise_for_status: bool = True,
) -> None:
    """Send a single heartbeat (synchronous). Wrap this from cron, Celery, or app hooks.

    Requires :func:`exemplar.init` to have been called with your API key.

    Args:
        monitor_id: Exemplar monitor identifier.
        metadata: Optional JSON object (e.g. ``{"hostname": "worker-01"}``).
        raise_for_status: If True, raise :class:`httpx.HTTPStatusError` on 4xx/5xx.
    """
    client = get_client()
    resp = client.send_heartbeat_sync(monitor_id, metadata)
    if raise_for_status:
        resp.raise_for_status()


async def heartbeat_background_loop(
    monitor_id: str,
    *,
    interval_seconds: float = 60.0,
    metadata: Optional[dict[str, Any]] = None,
    raise_for_status: bool = False,
    client: Optional[httpx.AsyncClient] = None,
) -> None:
    """Async background loop: send heartbeat every ``interval_seconds`` (cron-style).

    Schedule with your framework's async runner, for example:

    * **asyncio**: ``asyncio.create_task(heartbeat_background_loop(...))``
    * **FastAPI / Starlette**: run as a lifespan or background task
    * **AnyIO**: run in a task group

    Requires :func:`exemplar.init` before the loop runs. Pass a shared
    :class:`httpx.AsyncClient` if you want connection pooling across tasks.

    This function runs until cancelled.
    """
    ex = get_client()
    own_client = client is None
    if own_client:
        client = httpx.AsyncClient(timeout=30.0)

    try:
        while True:
            try:
                resp = await ex.send_heartbeat_async(
                    monitor_id, metadata, client=client
                )
                if raise_for_status:
                    resp.raise_for_status()
            except Exception:
                logger.exception("Exemplar heartbeat failed for monitor_id=%s", monitor_id)
            await asyncio.sleep(interval_seconds)
    finally:
        if own_client and client is not None:
            await client.aclose()
