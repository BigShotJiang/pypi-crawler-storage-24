from __future__ import annotations

import threading
from typing import Any, Optional

import httpx

DEFAULT_BASE_URL = "https://production-api.exemplar.dev"
HEARTBEAT_PATH = "/api/monitoring/heartbeat"

_lock = threading.Lock()
_client: Optional["ExemplarClient"] = None


class ExemplarClient:
    """Thread-safe singleton. Obtain via :func:`init` or :func:`get_client`."""

    __slots__ = ("_api_key", "_base_url", "_sync_client")

    def __init__(self, api_key: str, base_url: str) -> None:
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._sync_client = httpx.Client(
            base_url=self._base_url,
            headers={
                "Content-Type": "application/json",
                "X-API-Key": self._api_key,
            },
            timeout=30.0,
        )

    @property
    def base_url(self) -> str:
        return self._base_url

    def close(self) -> None:
        self._sync_client.close()

    def send_heartbeat_sync(
        self,
        monitor_id: str,
        metadata: Optional[dict[str, Any]] = None,
    ) -> httpx.Response:
        payload: dict[str, Any] = {"monitor_id": monitor_id}
        if metadata is not None:
            payload["metadata"] = metadata
        return self._sync_client.post(HEARTBEAT_PATH, json=payload)

    async def send_heartbeat_async(
        self,
        monitor_id: str,
        metadata: Optional[dict[str, Any]] = None,
        *,
        client: Optional[httpx.AsyncClient] = None,
    ) -> httpx.Response:
        payload: dict[str, Any] = {"monitor_id": monitor_id}
        if metadata is not None:
            payload["metadata"] = metadata
        headers = {
            "Content-Type": "application/json",
            "X-API-Key": self._api_key,
        }
        url = f"{self._base_url}{HEARTBEAT_PATH}"
        if client is not None:
            return await client.post(url, json=payload, headers=headers)
        async with httpx.AsyncClient(timeout=30.0) as ac:
            return await ac.post(url, json=payload, headers=headers)


def init(
    api_key: str,
    *,
    base_url: str = DEFAULT_BASE_URL,
) -> ExemplarClient:
    """Initialize the singleton with your API key. Call once at process startup.

    Raises:
        RuntimeError: If the client was already initialized.
    """
    global _client
    with _lock:
        if _client is not None:
            raise RuntimeError(
                "Exemplar client is already initialized; use get_client() instead."
            )
        _client = ExemplarClient(api_key, base_url)
        return _client


def get_client() -> ExemplarClient:
    """Return the initialized singleton.

    Raises:
        RuntimeError: If :func:`init` has not been called yet.
    """
    if _client is None:
        raise RuntimeError(
            "Exemplar client is not initialized; call exemplar.init(api_key=...) first."
        )
    return _client
