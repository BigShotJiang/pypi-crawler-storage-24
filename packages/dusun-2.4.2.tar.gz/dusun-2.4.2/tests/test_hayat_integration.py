"""
tests/test_hayat_integration.py — Hayat Integration Layer Validation

/dusun Pipeline BUILD-mode test scenario validating v2.0.0 Hayat layer:
  - §1.6 Self-Critique Gate (SC-1 to SC-4)
  - dusun-check.prompt.md (manual /self-check diagnostic)
  - dusun-engagement.instructions.md (always-on via applyTo: '**')

Design Principles:
  AX5:  Hayat is the integration prerequisite — without it, all other
        attributes become inert.  These tests verify the triad is ALIVE.
  AX2→AX3→AX4: Three-phase actualization — each test class represents
        Distinction → Selection → Actualization of a structural claim.
  KV₇:  Tests are independent — no shared state between classes or methods.
  AX52: Multiplicative gate — zero in ANY dimension = total failure.
  T17:  Coverage ≤ 6/7 — we acknowledge one dimension is always unmapped.
  AX56: Max grade = İlmelyakîn — never claim Hakkalyakîn.
  KV₄:  0 < composite < 1 — convergence is always bounded.

Usage:
    python -m pytest tests/test_hayat_integration.py -v
    python tests/test_hayat_integration.py   # standalone
"""

import json
import re
import unittest
from pathlib import Path

# ---------------------------------------------------------------------------
# Paths (KV₇ — independent of other test modules' path definitions)
# ---------------------------------------------------------------------------
ROOT = Path(__file__).resolve().parent.parent
AGENTS = ROOT / "DUSUN.md"
COPILOT = ROOT / ".github" / "instructions" / "dusun-router.instructions.md"
FW_PROMPT = ROOT / ".github" / "prompts" / "dusun.prompt.md"
SELF_CHECK = ROOT / ".github" / "prompts" / "dusun-check.prompt.md"
FRAMEWORK_ENGAGEMENT = (
    ROOT / ".github" / "instructions" / "dusun-engagement.instructions.md"
)


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


# ═══════════════════════════════════════════════════════════════════════
# CLASS 1: Hayat Layer File Existence (AX5 — integration prerequisite)
# ═══════════════════════════════════════════════════════════════════════


class TestHayatLayerExists(unittest.TestCase):
    """All three Hayat integration components must exist.

    AX5: ¬Hayat → ∀s' ∈ S_Sifat\\{Hayat}: Inert(s')
    If ANY component is missing, the integration layer is dead.
    AX52: Multiplicative gate — zero in one dimension = collapse.
    """

    def test_self_critique_gate_in_copilot(self):
        """§1.6 Self-Critique Gate must exist in dusun-router.instructions.md."""
        text = _read(COPILOT)
        self.assertIn("Self-Critique Gate", text)
        self.assertIn("SC-1", text)
        self.assertIn("SC-2", text)
        self.assertIn("SC-3", text)
        self.assertIn("SC-4", text)

    def test_self_check_prompt_exists(self):
        """dusun-check.prompt.md must exist on disk."""
        self.assertTrue(
            SELF_CHECK.exists(),
            f"Missing: {SELF_CHECK.relative_to(ROOT)}",
        )

    def test_framework_engagement_exists(self):
        """dusun-engagement.instructions.md must exist on disk."""
        self.assertTrue(
            FRAMEWORK_ENGAGEMENT.exists(),
            f"Missing: {FRAMEWORK_ENGAGEMENT.relative_to(ROOT)}",
        )

    def test_fw_prompt_exists(self):
        """dusun.prompt.md (Kudret organ) must exist on disk."""
        self.assertTrue(
            FW_PROMPT.exists(),
            f"Missing: {FW_PROMPT.relative_to(ROOT)}",
        )

    def test_triad_completeness(self):
        """Document triad İlim + İrade + Kudret must all exist (AX5)."""
        for path, label in [
            (AGENTS, "İlim (DUSUN.md)"),
            (COPILOT, "İrade (dusun-router.instructions.md)"),
            (FW_PROMPT, "Kudret (dusun.prompt.md)"),
        ]:
            with self.subTest(label=label):
                self.assertTrue(path.exists(), f"Triad broken: {label}")


# ═══════════════════════════════════════════════════════════════════════
# CLASS 2: Framework Engagement Instructions — Always-On (AX5)
# ═══════════════════════════════════════════════════════════════════════


class TestFrameworkEngagementContent(unittest.TestCase):
    """dusun-engagement.instructions.md must enforce AX5 always-on.

    This component turns the Hayat principle from a document-level claim
    into an always-injected context that every VS Code chat receives.
    """

    @classmethod
    def setUpClass(cls):
        cls.text = _read(FRAMEWORK_ENGAGEMENT)

    def test_apply_to_all(self):
        """Must have applyTo: '**' for universal injection."""
        self.assertRegex(self.text, r"applyTo:\s*['\"]?\*\*['\"]?")

    def test_step_0_mandatory(self):
        """Step 0 classification must be declared MANDATORY."""
        self.assertIn("Step 0", self.text)
        self.assertIn("MANDATORY", self.text)

    def test_p0_classification_reference(self):
        """Must reference P0/P1/P2/P3/P4 classification."""
        for p in ["P0", "P1", "P2", "P3", "P4"]:
            with self.subTest(path=p):
                self.assertIn(p, self.text)

    def test_self_critique_reference(self):
        """Must reference §1.6 Self-Critique Gate firing."""
        self.assertIn("SC-1", self.text)
        self.assertIn("SC-2", self.text)
        self.assertIn("SC-3", self.text)
        self.assertIn("SC-4", self.text)

    def test_structural_bounds_present(self):
        """Must declare the four structural bounds (§7.2)."""
        # T17 — Coverage ≤ 6/7
        self.assertRegex(self.text, r"6/7|Coverage")
        # AX56 — max İlmelyakîn
        self.assertIn("İlmelyakîn", self.text)
        # KV₄ — convergence < 1
        self.assertRegex(self.text, r"Convergence|KV")
        # AX58 — structure ≠ experience
        self.assertIn("experience", self.text.lower())

    def test_ax57_disclosure_requirement(self):
        """AX57 Disclosure must be required for P1–P4."""
        self.assertIn("AX57", self.text)
        self.assertIn("Disclosure", self.text)

    def test_fw_engine_tools_mentioned(self):
        """Must reference fw-engine MCP tools for grounded analysis."""
        self.assertIn("fw-engine", self.text)
        # At least a few key tools
        for tool in ["check_kavaid", "run_bileshke_pipeline"]:
            with self.subTest(tool=tool):
                self.assertIn(tool, self.text)


# ═══════════════════════════════════════════════════════════════════════
# CLASS 3: Self-Critique Gate Structure (§1.6)
# ═══════════════════════════════════════════════════════════════════════


class TestSelfCritiqueGateStructure(unittest.TestCase):
    """The §1.6 Self-Critique Gate must specify all four checks.

    SC-1: Structural patterns applied?
    SC-2: T15 weighting (structural > detail)?
    SC-3: Tool opportunity (fw-engine MCP)?
    SC-4: AX57 accuracy (disclosure matches reasoning)?
    """

    @classmethod
    def setUpClass(cls):
        cls.text = _read(COPILOT)

    def test_sc1_structural_patterns(self):
        """SC-1 checks for ≥1 structural pattern from §4."""
        self.assertIn("SC-1", self.text)
        # Must mention patterns
        self.assertRegex(self.text, r"SC-1.*pattern|pattern.*SC-1")

    def test_sc2_t15_weighting(self):
        """SC-2 checks structural > detail (T15)."""
        self.assertIn("SC-2", self.text)
        self.assertIn("T15", self.text)

    def test_sc3_tool_opportunity(self):
        """SC-3 checks if fw-engine MCP tools could have grounded a claim."""
        self.assertIn("SC-3", self.text)
        self.assertIn("fw-engine", self.text)

    def test_sc4_ax57_accuracy(self):
        """SC-4 verifies AX57 disclosure matches actual reasoning."""
        self.assertIn("SC-4", self.text)
        self.assertIn("AX57", self.text)

    def test_p0_exempt(self):
        """P0 responses must be exempt from self-critique."""
        # Find the self-critique section
        section = re.search(
            r"Self-Critique.*?(?=^## |\Z)", self.text,
            re.DOTALL | re.MULTILINE,
        )
        self.assertIsNotNone(section, "Self-Critique section not found")
        section_text = section.group()
        self.assertIn("P0", section_text)
        self.assertIn("EXEMPT", section_text.upper())

    def test_silent_operation(self):
        """Self-critique must be SILENT — never shown to user."""
        section = re.search(
            r"Self-Critique.*?(?=^## |\Z)", self.text,
            re.DOTALL | re.MULTILINE,
        )
        self.assertIsNotNone(section)
        section_text = section.group().upper()
        self.assertIn("SILENT", section_text)


# ═══════════════════════════════════════════════════════════════════════
# CLASS 4: MCP Tool — bileshke Pipeline (T6, KV₄, AX56, AX57)
# ═══════════════════════════════════════════════════════════════════════


class TestBileshkePipelineHayat(unittest.TestCase):
    """Exercise run_bileshke_pipeline as integration test.

    Validates:
      T6:  Convergence < 1.0
      KV₄: Composite ∈ (0, 1) — flag ≥ 0.95 as error
      AX56: Grade ≤ İlmelyakîn
      AX57: Disclosure block present
      T17: Completeness ≤ 6/7
      AX52: Multiplicative gate
    """

    @classmethod
    def setUpClass(cls):
        from fw_server.server import run_bileshke_pipeline
        # Supply meaningful text so lenses produce non-trivial scores.
        # Without content every lens correctly returns 0.0 — that is correct
        # behaviour but this test validates the T6/KV₄ bounds on *real* analysis.
        sample_text = (
            "Tecelli of Esmâ through Hayat demonstrates holographic "
            "structure. AX1 AX17 T6 KV4 convergence functor category."
        )
        lens_params = {
            lid: {"text": sample_text}
            for lid in (
                "Ontoloji", "Mereoloji", "FOL", "Bayes",
                "OyunTeorisi", "KategoriTeorisi", "Topoloji + Holografik",
            )
        }
        raw = run_bileshke_pipeline(json.dumps(lens_params), None, "[1,1,1]")
        cls.result = json.loads(raw)

    def test_composite_score_bounded(self):
        """T6 + KV₄: 0 < composite < 1.0."""
        if "error" in self.result:
            self.skipTest(f"Pipeline error: {self.result['error']}")
        score = self.result["composite_score"]
        self.assertGreater(score, 0.0, "Composite must be > 0")
        self.assertLess(score, 1.0, "T6: Composite must be < 1.0")

    def test_kv4_threshold_warning(self):
        """KV₄: If composite ≥ 0.95, kv4_status must be FAIL/WARNING."""
        if "error" in self.result:
            self.skipTest(f"Pipeline error: {self.result['error']}")
        score = self.result["composite_score"]
        disclosure = self.result.get("ax57_disclosure", {})
        if score >= 0.95:
            kv4 = disclosure.get("kv4_status", "")
            self.assertFalse(
                kv4.startswith("PASS"),
                f"KV₄ violation: score={score:.4f} but kv4_status={kv4}",
            )

    def test_ax57_disclosure_block_present(self):
        """AX57: Every pipeline response must carry disclosure."""
        if "error" in self.result:
            self.skipTest(f"Pipeline error: {self.result['error']}")
        disclosure = self.result.get("ax57_disclosure")
        self.assertIsNotNone(disclosure, "ax57_disclosure missing")
        for key in [
            "composite_score", "grade", "completeness",
            "kv4_status", "kv7_status", "ax56_status",
        ]:
            with self.subTest(key=key):
                self.assertIn(
                    key, disclosure,
                    f"ax57_disclosure missing key: {key}",
                )

    def test_ax56_grade_ceiling(self):
        """AX56: Grade must be ≤ İlmelyakîn, never Hakkalyakîn."""
        if "error" in self.result:
            self.skipTest(f"Pipeline error: {self.result['error']}")
        disclosure = self.result.get("ax57_disclosure", {})
        grade = disclosure.get("grade", "")
        self.assertNotIn("Hakkalyakîn", grade, "AX56 violation")

    def test_t17_completeness_bound(self):
        """T17: Completeness ≤ 6/7 ≈ 0.857."""
        if "error" in self.result:
            self.skipTest(f"Pipeline error: {self.result['error']}")
        disclosure = self.result.get("ax57_disclosure", {})
        completeness = disclosure.get("completeness", "")
        # completeness is formatted as "X/7" or a float
        if isinstance(completeness, str) and "/" in completeness:
            num, denom = completeness.split("/")
            ratio = float(num) / float(denom)
        elif isinstance(completeness, (int, float)):
            ratio = float(completeness)
        else:
            ratio = 0.0
        self.assertLessEqual(
            ratio, 6 / 7 + 0.001,
            f"T17: Completeness {completeness} exceeds 6/7",
        )

    def test_all_seven_lenses_produce_results(self):
        """T16 + AX50: All 7 lenses must produce results for full coverage."""
        if "error" in self.result:
            self.skipTest(f"Pipeline error: {self.result['error']}")
        lens_results = self.result.get("lens_results", [])
        self.assertEqual(
            len(lens_results), 7,
            f"Expected 7 lens results, got {len(lens_results)}",
        )

    def test_each_lens_score_below_one(self):
        """T6: Every individual lens score < 1.0."""
        if "error" in self.result:
            self.skipTest(f"Pipeline error: {self.result['error']}")
        for lr in self.result.get("lens_results", []):
            lid = lr.get("lens_id", "?")
            score = lr.get("score", 0.0)
            with self.subTest(lens=lid):
                self.assertLess(
                    score, 1.0,
                    f"T6: {lid} score={score} ≥ 1.0",
                )


# ═══════════════════════════════════════════════════════════════════════
# CLASS 5: MCP Tool — check_kavaid (KV₁–KV₈, AX52)
# ═══════════════════════════════════════════════════════════════════════


class TestKavaidEvaluation(unittest.TestCase):
    """Exercise check_kavaid tool with standard parameters.

    Validates:
      All 8 kavaid are evaluated (KV₁ through KV₈)
      Descriptions present for each
      KV₄ bound enforced at 0.95 threshold
      Multiplicative nature (AX52) — all_pass requires ALL 8
    """

    @classmethod
    def setUpClass(cls):
        from fw_server.server import check_kavaid
        # Standard parameters: composite=0.5, 6 of 7 latife active (Ahfâ=0)
        raw = check_kavaid(0.5, "[1,1,1,1,1,1,0]", None)
        cls.result = json.loads(raw)

    def test_all_eight_kavaid_present(self):
        """All 8 kavaid (KV1–KV8) must be evaluated."""
        if "error" in self.result:
            self.skipTest(f"Kavaid error: {self.result['error']}")
        descs = self.result.get("descriptions", {})
        for kv in ["KV1", "KV2", "KV3", "KV4", "KV5", "KV6", "KV7", "KV8"]:
            with self.subTest(kv=kv):
                self.assertIn(kv, descs, f"Missing kavaid: {kv}")

    def test_kv4_safe_at_half(self):
        """KV₄: composite=0.5 is safely below 0.95 threshold."""
        if "error" in self.result:
            self.skipTest(f"Kavaid error: {self.result['error']}")
        checks = self.result.get("checks", {})
        self.assertTrue(
            checks.get("KV4", False),
            "KV₄ should pass at composite=0.5",
        )

    def test_kv4_warns_at_threshold(self):
        """KV₄: composite=0.96 must trigger warning."""
        from fw_server.server import check_kavaid
        raw = check_kavaid(0.96, "[1,1,1,1,1,1,0]", None)
        result = json.loads(raw)
        if "error" in result:
            self.skipTest(f"Kavaid error: {result['error']}")
        kv4_warning = result.get("kv4_warning")
        self.assertIsNotNone(
            kv4_warning,
            "KV₄ must issue warning at composite=0.96",
        )

    def test_all_pass_is_multiplicative(self):
        """AX52: all_pass is True only if ALL 8 kavaid pass."""
        if "error" in self.result:
            self.skipTest(f"Kavaid error: {self.result['error']}")
        checks = self.result.get("checks", {})
        all_pass = self.result.get("all_pass", False)
        individual_all = all(checks.values())
        self.assertEqual(
            all_pass, individual_all,
            "AX52: all_pass must equal AND of all individual checks",
        )

    def test_kavaid_descriptions_non_empty(self):
        """Each kavaid must have a non-empty description."""
        if "error" in self.result:
            self.skipTest(f"Kavaid error: {self.result['error']}")
        descs = self.result.get("descriptions", {})
        for kv, desc in descs.items():
            with self.subTest(kv=kv):
                self.assertTrue(
                    len(desc) > 5,
                    f"{kv} description too short: '{desc}'",
                )


# ═══════════════════════════════════════════════════════════════════════
# CLASS 6: MCP Tool — verify_chains (C1–C7, IG.2, IG.3)
# ═══════════════════════════════════════════════════════════════════════


class TestChainVerification(unittest.TestCase):
    """Exercise verify_chains tool for all 7 inference chains.

    Validates:
      C1–C7 all present and valid
      Hub nodes identified (KV₄ in 3 chains per IG.3)
      Kaskad verification integration
    """

    @classmethod
    def setUpClass(cls):
        from fw_server.server import verify_chains
        raw = verify_chains(None, None)
        cls.result = json.loads(raw)

    def test_all_seven_chains_present(self):
        """C1 through C7 must all be present."""
        if "error" in self.result:
            self.skipTest(f"Chain error: {self.result['error']}")
        chains = self.result.get("chains", {})
        for c in ["C1", "C2", "C3", "C4", "C5", "C6", "C7"]:
            with self.subTest(chain=c):
                self.assertIn(c, chains, f"Missing chain: {c}")

    def test_all_chains_valid(self):
        """Every chain must be structurally valid."""
        if "error" in self.result:
            self.skipTest(f"Chain error: {self.result['error']}")
        self.assertTrue(
            self.result.get("all_valid", False),
            "Not all chains are valid",
        )

    def test_hub_nodes_identified(self):
        """Hub nodes must be identified per IG.3."""
        if "error" in self.result:
            self.skipTest(f"Chain error: {self.result['error']}")
        hubs = self.result.get("hub_nodes", [])
        self.assertGreater(
            len(hubs), 0,
            "Hub nodes must be identified (IG.3)",
        )

    def test_kv4_is_hub(self):
        """KV₄ must be a hub node — it appears in C3, C4, C7 (IG.3)."""
        if "error" in self.result:
            self.skipTest(f"Chain error: {self.result['error']}")
        hubs = self.result.get("hub_nodes", [])
        hub_ids = set()
        for h in hubs:
            if isinstance(h, dict):
                hub_ids.add(h.get("node", ""))
            elif isinstance(h, str):
                hub_ids.add(h)
        # KV₄ or KV4 must be present
        found = any("KV" in hid and "4" in hid for hid in hub_ids)
        self.assertTrue(found, f"KV₄ not found among hubs: {hub_ids}")

    def test_kaskad_verification_present(self):
        """Kaskad verification data must be included."""
        if "error" in self.result:
            self.skipTest(f"Chain error: {self.result['error']}")
        kv = self.result.get("kaskad_verification")
        self.assertIsNotNone(
            kv, "kaskad_verification missing from verify_chains output",
        )


# ═══════════════════════════════════════════════════════════════════════
# CLASS 7: MCP Tool — run_kaskad verify action (AX23)
# ═══════════════════════════════════════════════════════════════════════


class TestKaskadVerify(unittest.TestCase):
    """Exercise run_kaskad with action='verify' for structural integrity.

    AX23: Names form a DAG with root in S_Seun.
    All 7 structural checks must pass.
    """

    @classmethod
    def setUpClass(cls):
        from fw_server.server import run_kaskad
        raw = run_kaskad("verify", None, None, 0)
        cls.result = json.loads(raw)

    def test_action_is_verify(self):
        self.assertEqual(self.result.get("action"), "verify")

    def test_all_checks_pass(self):
        """All structural checks must pass."""
        if "error" in self.result:
            self.skipTest(f"Kaskad error: {self.result['error']}")
        self.assertTrue(
            self.result.get("all_pass", False),
            "Kaskad structural verification failed",
        )

    def test_checks_are_present(self):
        """At least one check was run."""
        checks = self.result.get("checks", [])
        self.assertGreater(
            len(checks), 0,
            "No checks were run in kaskad verify",
        )

    def test_each_check_has_name_and_result(self):
        """Each check has name, passed, message fields."""
        for check in self.result.get("checks", []):
            with self.subTest(check=check.get("name", "?")):
                self.assertIn("name", check)
                self.assertIn("passed", check)
                self.assertIn("message", check)


# ═══════════════════════════════════════════════════════════════════════
# CLASS 8: MCP Tool — get_framework_summary (9 modules)
# ═══════════════════════════════════════════════════════════════════════


class TestFrameworkSummaryIntegration(unittest.TestCase):
    """Exercise get_framework_summary — aggregates all 9 modules.

    Validates multi-module health. Each module providing framework_summary()
    must contribute valid metadata. This is the Hayat integration test
    at the module level — if ANY module fails, integration is broken (AX52).
    """

    @classmethod
    def setUpClass(cls):
        from fw_server.server import get_framework_summary
        raw = get_framework_summary()
        cls.result = json.loads(raw)

    def test_result_is_dict(self):
        self.assertIsInstance(self.result, dict)

    def test_all_nine_modules_present(self):
        """All 9 modules must contribute to framework summary."""
        expected = {
            "kavram_sozlugu", "mereoloji", "bileshke",
            "fol_formalizasyon", "bayes_analiz", "oyun_teorisi",
            "kategori_teorisi", "holografik", "kaskad",
        }
        for mod in expected:
            with self.subTest(module=mod):
                self.assertIn(
                    mod, self.result,
                    f"Module {mod} missing from framework summary",
                )

    def test_no_module_has_error(self):
        """No module should report an error in its summary."""
        for mod, summary in self.result.items():
            with self.subTest(module=mod):
                if isinstance(summary, dict):
                    self.assertNotIn(
                        "error", summary,
                        f"{mod} reported error: {summary.get('error')}",
                    )


# ═══════════════════════════════════════════════════════════════════════
# CLASS 9: MCP Tool — run_single_lens (KV₇, T6, AX56)
# ═══════════════════════════════════════════════════════════════════════


class TestSingleLensIndependence(unittest.TestCase):
    """Exercise run_single_lens for each of the 7 lenses.

    KV₇: Each lens operates independently (no shared state).
    T6:  Each score < 1.0.
    AX56: Grade ≤ İlmelyakîn.
    AX27: Lenses are transparent vessels — they mediate, don't originate.
    """

    LENS_IDS = [
        "Ontoloji", "Mereoloji", "FOL", "Bayes",
        "OyunTeorisi", "KategoriTeorisi", "Topoloji + Holografik",
    ]

    def _run_lens(self, lens_id, params=None):
        from fw_server.server import run_single_lens
        raw = run_single_lens(lens_id, params)
        return json.loads(raw)

    def test_all_seven_lenses_callable(self):
        """Every lens must be callable without error."""
        for lid in self.LENS_IDS:
            with self.subTest(lens=lid):
                result = self._run_lens(lid)
                self.assertNotIn(
                    "error", result,
                    f"{lid} returned error: {result.get('error')}",
                )

    def test_t6_all_scores_below_one(self):
        """T6: Every lens score must be < 1.0."""
        for lid in self.LENS_IDS:
            with self.subTest(lens=lid):
                result = self._run_lens(lid)
                if "error" not in result:
                    self.assertLess(
                        result.get("score", 0.0), 1.0,
                        f"T6: {lid} score ≥ 1.0",
                    )

    def test_ax56_no_hakkalyakin(self):
        """AX56: No lens may return Hakkalyakîn grade."""
        for lid in self.LENS_IDS:
            with self.subTest(lens=lid):
                result = self._run_lens(lid)
                if "error" not in result:
                    grade = result.get("grade", "")
                    self.assertNotIn(
                        "Hakkalyakîn", grade,
                        f"AX56: {lid} returned Hakkalyakîn",
                    )

    def test_kv7_fol_independence(self):
        """KV₇: Two FOL calls with different input must not share state."""
        r1 = self._run_lens(
            "FOL",
            json.dumps({"text": "AX1 states order. T3 propagates perfection."}),
        )
        r2 = self._run_lens("FOL", None)
        # Both must succeed
        if "error" in r1 or "error" in r2:
            self.skipTest("FOL lens error — cannot test independence")
        # They should produce different detail or scores
        # (mere non-crash is already a pass for independence)
        self.assertIsNotNone(r1.get("score"))
        self.assertIsNotNone(r2.get("score"))


# ═══════════════════════════════════════════════════════════════════════
# CLASS 10: Cross-Component Integration (AX5 — Triad Coherence)
# ═══════════════════════════════════════════════════════════════════════


class TestTriadCoherence(unittest.TestCase):
    """Cross-validate the three Hayat components for coherence.

    AX5: Integration prerequisite — components must work TOGETHER.
    T14: NeAynNeGayr — participation without identity.
    AX39: Edeb — methodological propriety.
    """

    @classmethod
    def setUpClass(cls):
        cls.copilot = _read(COPILOT)
        cls.engagement = _read(FRAMEWORK_ENGAGEMENT)
        cls.agents = _read(AGENTS)

    def test_engagement_references_copilot_sections(self):
        """framework-engagement must reference dusun-router.instructions.md §1.1."""
        self.assertRegex(
            self.engagement,
            r"§1\.1|copilot-instructions",
        )

    def test_self_critique_references_agents_axioms(self):
        """§1.6 Self-Critique in copilot must reference DUSUN.md axioms."""
        # SC-3 references fw-engine tools (defined in DUSUN.md Layer 4)
        self.assertIn("fw-engine", self.copilot)
        # AX57 must be mentioned in self-critique context
        self.assertIn("AX57", self.copilot)

    def test_engagement_references_structural_bounds(self):
        """Engagement file must list bounds from DUSUN.md §7.2."""
        # T17 bound
        self.assertIn("6/7", self.engagement)
        # AX56 bound
        self.assertIn("İlmelyakîn", self.engagement)

    def test_copilot_paths_match_agents_layer8(self):
        """P0–P4 paths in copilot must be consistent with DUSUN.md §8.1."""
        for path_id in ["P0", "P1", "P2", "P3", "P4"]:
            with self.subTest(path=path_id):
                self.assertIn(path_id, self.copilot)
                self.assertIn(path_id, self.agents)

    def test_ax5_formula_in_agents(self):
        """AX5 Hayat formula must be in DUSUN.md."""
        self.assertIn("¬Hayat", self.agents)
        self.assertIn("Inert", self.agents)

    def test_ax5_operationalized_in_engagement(self):
        """AX5 must be operationalized in framework-engagement (not just cited)."""
        self.assertIn("AX5", self.engagement)
        # Must describe what happens when framework is NOT engaged
        self.assertRegex(
            self.engagement,
            r"[Ii]nert|[Ii]ntegration|[Pp]rerequisite",
        )


# ═══════════════════════════════════════════════════════════════════════
# CLASS 11: Structural Incompleteness Assertions (§7.2)
# ═══════════════════════════════════════════════════════════════════════


class TestStructuralIncompleteness(unittest.TestCase):
    """Explicitly validate the four structural incompleteness results.

    These are NOT bugs — they are boundaries to honor (§7.2).
    The test scenario must VERIFY they are enforced, not try to exceed them.
    """

    def test_t17_latife_vektor_max_six(self):
        """T17: latife_vektor maximum is 6 out of 7 (Ahfâ = 0)."""
        from bileshke.engine import compute_latife_vektor
        # ALL 7 lens IDs active
        from bileshke.types import LensId
        all_lenses = list(LensId)
        vektor = compute_latife_vektor(all_lenses)
        # Ahfâ bit (index 6) must be 0
        self.assertEqual(
            vektor.bits[6], 0,
            "T17: Ahfâ (index 6) must be permanently 0",
        )
        # Sum must be ≤ 6
        self.assertLessEqual(
            vektor.active_count, 6,
            "T17: Maximum active latifeler = 6",
        )

    def test_ax56_grade_enum_excludes_hakkalyakin_from_valid(self):
        """AX56: VALID_GRADES must not include Hakkalyakîn."""
        from fw_server.types import VALID_GRADES
        for g in VALID_GRADES:
            self.assertNotIn(
                "Hakkalyakîn", g,
                f"AX56: VALID_GRADES contains Hakkalyakîn: {g}",
            )

    def test_ax58_agents_declares_gap(self):
        """AX58: DUSUN.md must declare the şuhud–istidlal gap."""
        text = _read(AGENTS)
        self.assertIn("Şuhud", text)
        self.assertIn("İstidlal", text)
        # The gap must be in §7.2
        self.assertRegex(text, r"AX58.*gap|gap.*AX58")

    def test_kv4_bileshke_clamp(self):
        """KV₄: bileshke engine must enforce composite < 1.0."""
        from bileshke.engine import bileshke as compute_bileshke
        from bileshke.types import LensResult, LensId, EpistemicGrade

        # Create synthetic results with high scores
        results = [
            LensResult(
                lens_id=lid,
                score=0.99,
                grade=EpistemicGrade.ILMELYAKIN,
                checks_passed=10,
                checks_total=10,
                detail="synthetic high score",
            )
            for lid in LensId
        ]
        composite = compute_bileshke(results)
        self.assertLess(
            composite, 1.0,
            f"KV₄: bileshke composite must be < 1.0, got {composite}",
        )

    def test_kv4_warning_detected(self):
        """KV₄: detect_kv4_warning triggers at ≥ 0.95."""
        from bileshke.engine import detect_kv4_warning

        self.assertIsNone(
            detect_kv4_warning(0.85),
            "KV₄: 0.85 should NOT trigger warning",
        )
        warning = detect_kv4_warning(0.96)
        self.assertIsNotNone(
            warning,
            "KV₄: 0.96 MUST trigger warning",
        )


# ═══════════════════════════════════════════════════════════════════════
# CLASS 12: Run kaskad report + tesanud (AX23, AX63)
# ═══════════════════════════════════════════════════════════════════════


class TestKaskadReportAndTesanud(unittest.TestCase):
    """Exercise kaskad report and tesanüd analysis.

    AX23: Cascade structure (DAG).
    AX63: Affirmations compose super-additively (tesanüd);
          denials remain isolated (infirâdî).
    """

    def test_report_returns_valid_structure(self):
        """Kaskad report must return graph stats and chain integrity."""
        from fw_server.server import run_kaskad
        raw = run_kaskad("report", None, None, 0)
        result = json.loads(raw)
        self.assertEqual(result.get("action"), "report")
        # Report uses flat keys for graph stats
        self.assertIn("total_nodes", result)
        self.assertIn("total_edges", result)
        self.assertIn("chain_integrity", result)

    def test_tesanud_identifies_superadditive_nodes(self):
        """AX63: Tesanüd analysis must identify super-additive nodes."""
        from fw_server.server import run_kaskad
        raw = run_kaskad("tesanud", None, None, 0)
        result = json.loads(raw)
        self.assertEqual(result.get("action"), "tesanud")
        self.assertIn("tesanud_count", result)
        # At least some tesanüd nodes should exist per IG.3
        self.assertGreater(
            result.get("tesanud_count", 0), 0,
            "AX63: At least one tesanüd node expected",
        )

    def test_hubs_identifies_high_degree_nodes(self):
        """IG.3: Hub analysis must find high-degree nodes."""
        from fw_server.server import run_kaskad
        raw = run_kaskad("hubs", None, None, 0)
        result = json.loads(raw)
        self.assertEqual(result.get("action"), "hubs")
        hubs = result.get("hubs", [])
        self.assertGreater(len(hubs), 0, "Must find at least one hub node")


# ═══════════════════════════════════════════════════════════════════════
# CLASS 13: Hayat Layer Reporting in framework_summary
# ═══════════════════════════════════════════════════════════════════════


class TestHayatLayerReporting(unittest.TestCase):
    """Validate the hayat_layer section added to get_framework_summary().

    AX5:  ¬Hayat → Inert — without integration, modules are dead data.
    AX52: Multiplicative gate — zero in any dimension collapses the whole.
    AX57: Transparency — must disclose integration health alongside modules.

    The 3 Hayat components:
      1. dusun-engagement.instructions.md (always-on, applyTo: '**')
      2. dusun-router.instructions.md §1.6 (Self-Critique Gate: SC-1..SC-4)
      3. dusun-check.prompt.md (manual /self-check diagnostic)
    """

    @classmethod
    def setUpClass(cls):
        from fw_server.server import get_framework_summary
        raw = get_framework_summary()
        cls.result = json.loads(raw)
        cls.hayat = cls.result.get("hayat_layer", {})
        cls.integration = cls.result.get("system_integration", {})

    # ── hayat_layer top-level ──────────────────────────────────────

    def test_hayat_layer_present(self):
        """framework_summary must include hayat_layer key."""
        self.assertIn("hayat_layer", self.result)

    def test_hayat_status_active(self):
        """With all data files shipped, Hayat layer should be active."""
        self.assertEqual(self.hayat.get("status"), "active")

    def test_hayat_axiom_reference(self):
        """Must cite AX5 axiom."""
        self.assertIn("AX5", self.hayat.get("axiom", ""))

    # ── hayat_layer.components ─────────────────────────────────────

    def test_all_three_components_present(self):
        """All 3 Hayat components must appear in components dict."""
        components = self.hayat.get("components", {})
        for comp_id in ("framework_engagement", "self_critique_gate",
                        "self_check_prompt"):
            with self.subTest(component=comp_id):
                self.assertIn(comp_id, components)

    def test_framework_engagement_healthy(self):
        """dusun-engagement.instructions.md must be present and healthy."""
        comp = self.hayat.get("components", {}).get("framework_engagement", {})
        self.assertTrue(comp.get("present"), "File must exist")
        self.assertTrue(comp.get("healthy"), "All markers must be found")

    def test_self_critique_gate_healthy(self):
        """dusun-router.instructions.md must contain SC-1..SC-4 markers."""
        comp = self.hayat.get("components", {}).get("self_critique_gate", {})
        self.assertTrue(comp.get("present"), "File must exist")
        self.assertTrue(comp.get("healthy"), "All SC markers must be found")

    def test_self_check_prompt_healthy(self):
        """dusun-check.prompt.md must be present and healthy."""
        comp = self.hayat.get("components", {}).get("self_check_prompt", {})
        self.assertTrue(comp.get("present"), "File must exist")
        self.assertTrue(comp.get("healthy"), "All markers must be found")

    def test_each_component_has_role(self):
        """Each component must describe its role."""
        for comp_id, comp in self.hayat.get("components", {}).items():
            with self.subTest(component=comp_id):
                self.assertIsInstance(comp.get("role"), str)
                self.assertGreater(len(comp.get("role", "")), 10)

    def test_each_component_has_path(self):
        """Each healthy component must report its path."""
        for comp_id, comp in self.hayat.get("components", {}).items():
            with self.subTest(component=comp_id):
                if comp.get("present"):
                    self.assertIsNotNone(comp.get("path"))

    # ── hayat_layer.integration_health ─────────────────────────────

    def test_integration_health_present(self):
        health = self.hayat.get("integration_health", {})
        self.assertIn("all_components_present", health)
        self.assertIn("always_on_confirmed", health)
        self.assertIn("sc_gate_checks_found", health)
        self.assertIn("sc_gate_checks_expected", health)

    def test_all_components_present_flag(self):
        health = self.hayat.get("integration_health", {})
        self.assertTrue(health.get("all_components_present"))

    def test_always_on_confirmed(self):
        """applyTo: '**' must be detected in framework-engagement."""
        health = self.hayat.get("integration_health", {})
        self.assertTrue(health.get("always_on_confirmed"))

    def test_sc_gate_all_four_checks(self):
        """SC-1 through SC-4 must all be detected."""
        health = self.hayat.get("integration_health", {})
        self.assertEqual(health.get("sc_gate_checks_found"), 4)
        self.assertEqual(health.get("sc_gate_checks_expected"), 4)

    # ── system_integration ─────────────────────────────────────────

    def test_system_integration_present(self):
        """framework_summary must include system_integration key."""
        self.assertIn("system_integration", self.result)

    def test_total_modules_count(self):
        """Must report 9 analytical modules."""
        self.assertEqual(self.integration.get("total_modules"), 9)

    def test_healthy_modules_count(self):
        """All 9 modules should be healthy."""
        self.assertEqual(self.integration.get("healthy_modules"), 9)

    def test_hayat_active_flag(self):
        """system_integration.hayat_active must be true."""
        self.assertTrue(self.integration.get("hayat_active"))

    def test_coverage_bound(self):
        """Must cite T17 — 6/7 structural maximum."""
        self.assertIn("6/7", self.integration.get("coverage", ""))
        self.assertIn("T17", self.integration.get("coverage", ""))

    def test_max_grade_bound(self):
        """Must cite AX56 — İlmelyakîn maximum."""
        self.assertIn("AX56", self.integration.get("max_grade", ""))

    def test_ax52_gate_pass(self):
        """AX52 multiplicative gate should PASS with all modules healthy."""
        self.assertEqual(self.integration.get("ax52_gate"), "PASS")


# ═══════════════════════════════════════════════════════════════════════
# CLASS 14: _check_hayat_layer edge cases
# ═══════════════════════════════════════════════════════════════════════


class TestCheckHayatLayerEdgeCases(unittest.TestCase):
    """Test _check_hayat_layer internals for degraded/inactive scenarios."""

    def test_direct_call_returns_dict(self):
        """_check_hayat_layer() must return a dict with status key."""
        from fw_server.server import _check_hayat_layer
        result = _check_hayat_layer()
        self.assertIsInstance(result, dict)
        self.assertIn("status", result)

    def test_status_is_valid_value(self):
        """Status must be one of active/degraded/inactive."""
        from fw_server.server import _check_hayat_layer
        result = _check_hayat_layer()
        self.assertIn(result["status"], ("active", "degraded", "inactive"))

    def test_components_dict_has_three_keys(self):
        """Must report exactly 3 components."""
        from fw_server.server import _check_hayat_layer
        result = _check_hayat_layer()
        self.assertEqual(len(result["components"]), 3)

    def test_markers_expected_ge_markers_found(self):
        """markers_found <= markers_expected for each component."""
        from fw_server.server import _check_hayat_layer
        result = _check_hayat_layer()
        for comp_id, comp in result["components"].items():
            with self.subTest(component=comp_id):
                self.assertLessEqual(
                    comp["markers_found"], comp["markers_expected"])


# ═══════════════════════════════════════════════════════════════════════
# Runner
# ═══════════════════════════════════════════════════════════════════════


if __name__ == "__main__":
    unittest.main()
