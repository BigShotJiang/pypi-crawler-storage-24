"""
fw_server/adapters.py — Stateless adapters: JSON dict → lens yakinlasma → LensResult.

Design invariants:
  KV₇:  Each adapter creates a FRESH instance per call — zero shared state.
  AX27: Adapters are transparent vessels; they mediate but don't originate.
  AX56: Grade never reaches Hakkalyakîn.
  T6:   Score clamped < 1.0.

Each ``run_*`` function accepts a plain ``dict`` (from MCP JSON) and
returns a ``bileshke.types.LensResult``.  The adapters translate between
the wire format and the heterogeneous yakinlasma signatures.
"""

from __future__ import annotations

import re
from typing import Any, Callable, Dict, Optional

from bileshke.types import EpistemicGrade, LensId, LensResult, clamp_score
from fw_server.grade_map import pass_ratio_to_grade, score_to_grade
from fw_server.tracer import trace


# =====================================================================
# Text-based domain vocabulary for content-aware scoring
# =====================================================================
# When no structured model is provided, adapters scan user text for
# domain-specific terms and produce a score proportional to coverage.
# This ensures lenses respond to content even without pre-built models.

_ONTOLOJI_TERMS: frozenset = frozenset({
    # Framework concepts (DUSUN.md §2)
    "tecelli", "hakikat", "mahiyet", "esma", "esmâ", "sifat", "sıfat",
    "isim", "fiil", "eser", "zat", "zât", "şuunat", "suunat",
    "vahidiyet", "ehadiyet", "harfi", "ismi", "fakr", "acz",
    "tereşşuhat", "sudur", "delalet", "istinad", "mana-yı harfi",
    "ne ayn ne gayr", "ontolojik", "ontological",
    # The 7 Sifat
    "hayat", "ilim", "irade", "kudret", "sem", "basar", "kelam",
})

_MEREOLOJI_TERMS: frozenset = frozenset({
    "part", "whole", "compose", "composed", "component", "element",
    "structure", "mereology", "mereological", "telos", "teleology",
    "teleological", "containment",
    "subpart", "holographic seed", "transparent vessel", "part-whole",
    "bölüm", "parça", "bütün",
})

_BAYES_TERMS: frozenset = frozenset({
    "evidence", "probability", "prior", "posterior", "likelihood",
    "bayes", "bayesian", "hypothesis", "confirmation", "update",
    "conditional", "credence", "degree of belief", "probabilistic",
    "delil", "ispat", "burhan",
})

_OYUN_TERMS: frozenset = frozenset({
    "strategy", "payoff", "equilibrium", "game theory", "cooperation",
    "defection", "nash", "nefs", "rational", "player", "interaction",
    "utility", "dominant", "game model",
    "emmare", "levvame", "mulhime", "mutmainne",
})

_KATEGORI_TERMS: frozenset = frozenset({
    "functor", "morphism", "category", "categorical",
    "natural transformation",
    "commute", "faithful", "isomorphism", "homomorphism",
    "diagram", "arrow", "composition", "functorial",
    "endofunctor",
})

_HOLOGRAFIK_TERMS: frozenset = frozenset({
    "holographic", "holografik", "fractal", "self-similar", "seed",
    "besmele", "fatiha", "isomorphism", "compressed", "reflection",
    "part-whole", "celali", "cemali", "hologram",
    "küçük bir kainat",
})


def _count_text_matches(text: str, terms: frozenset) -> int:
    """Count unique term matches in text (case-insensitive, word-boundary).

    Uses ``\\b`` at both token start and end to prevent substring false
    positives (e.g. 'part' no longer matches 'department' or 'partly').
    Multi-word phrases like 'holographic seed' still match normally.
    """
    if not text:
        return 0
    text_lower = text.lower()
    return sum(
        1 for t in terms
        if re.search(r'\b' + re.escape(t) + r'\b', text_lower)
    )


def _text_domain_score(
    text: str,
    terms: frozenset,
    *,
    per_match: float = 0.03,
    cap: float = 0.30,
) -> float:
    """Compute domain score from text keyword matches.

    Each unique match adds *per_match*; total capped at *cap*.
    Returns 0.0 when text is empty or no matches found.

    .. deprecated:: Phase 1
        Use the per-lens ``_text_score_*()`` functions instead.
        Retained for backward compatibility.
    """
    matched = _count_text_matches(text, terms)
    if matched == 0:
        return 0.0
    return min(matched * per_match, cap)


# =====================================================================
# Per-Lens Text Scoring (Phase 1 — replaces shared _text_domain_score)
# =====================================================================
# Each scorer uses individualized caps and multi-feature weighting.
# Caps from WATERFALL_PLAN §5.1:
#   Ontoloji=0.65, Mereoloji=0.50, FOL=0.70, Bayes=0.55,
#   OyunTeorisi=0.50, KategoriTeorisi=0.45, Holografik=0.55
# Multi-feature: base term matches + structural bonus for deeper signals.
# KV₇: all are pure functions.

_ESMA_PREFIX_RE = re.compile(
    r"\b(?:el-|er-|es-|eş-|ez-|al-|ar-|as-|aş-|az-)\w+",
    re.IGNORECASE,
)

_PART_WHOLE_RE = re.compile(
    r"\b(?:is\s+part\s+of|consists?\s+of|composed?\s+of|"
    r"contains?|comprises?|subdivided?\s+into|made\s+up\s+of)\b",
    re.IGNORECASE,
)

_LOGICAL_RE = re.compile(
    r"\b(?:for\s*all|there\s*exists?|implies?|therefore|"
    r"if\s+and\s+only\s+if|iff|necessarily|possibly|"
    r"∀|∃|→|⇒|¬|∧|∨|⊥|⊢|⊨)\b",
    re.IGNORECASE,
)

_AX_T_KV_RE = re.compile(r"\bAX\d{1,2}\b|\bT\d{1,2}\b|\bKV[₁₂₃₄₅₆₇₈1-8]\b")

_PROB_QUANTIFIER_RE = re.compile(
    r"\b(?:P\s*\(|Pr\s*\(|probability\s*of|degree\s*of\s*belief)\b",
    re.IGNORECASE,
)

_PAYOFF_MATRIX_RE = re.compile(
    r"\bpayoff\s*matrix|strategy\s*profile|nash\s*equilibrium\b",
    re.IGNORECASE,
)

_NEFS_RE = re.compile(
    r"\b(?:emmare|levvame|mulhime|mutmainne|nefs)\b",
    re.IGNORECASE,
)

_FUNCTOR_ARROW_RE = re.compile(
    r"(?:→|⇒|\bF\s*:\s*\w+\s*→|\bη\s*:)",
    re.IGNORECASE,
)

_BESMELE_DIM_RE = re.compile(r"\bB(?:0[1-9]|1\d|2[0-2])\b")

_HOLOGRAPHIC_SEED_RE = re.compile(
    r"\b(?:holographic\s+seed|part[- ]whole\s+iso(?:morphism)?|"
    r"seed\s+encod(?:e|es|ing)|compressed\s+image|besmele.*fatiha)\b",
    re.IGNORECASE,
)


def _text_score_ontoloji(text: str) -> float:
    """Score text for Ontoloji lens relevance. Cap: 0.65."""
    if not text:
        return 0.0
    base = _count_text_matches(text, _ONTOLOJI_TERMS)
    esma_hits = len(_ESMA_PREFIX_RE.findall(text))
    # base terms: 0.03 each; esma hits: 0.05 each (Names are high-signal)
    raw = base * 0.03 + esma_hits * 0.05
    return min(raw, 0.65)


def _text_score_mereoloji(text: str) -> float:
    """Score text for Mereoloji lens relevance. Cap: 0.50."""
    if not text:
        return 0.0
    base = _count_text_matches(text, _MEREOLOJI_TERMS)
    rel_hits = len(_PART_WHOLE_RE.findall(text))
    # base terms: 0.04 each; relational phrases: 0.06 each
    raw = base * 0.04 + rel_hits * 0.06
    return min(raw, 0.50)


def _text_score_fol(text: str) -> float:
    """Score text for FOL lens relevance. Cap: 0.70."""
    if not text:
        return 0.0
    logic_hits = len(_LOGICAL_RE.findall(text))
    ref_hits = len(_AX_T_KV_RE.findall(text))
    # logical connectives: 0.04 each; axiom/theorem refs: 0.06 each
    raw = logic_hits * 0.04 + ref_hits * 0.06
    return min(raw, 0.70)


def _text_score_bayes(text: str) -> float:
    """Score text for Bayes lens relevance. Cap: 0.55."""
    if not text:
        return 0.0
    base = _count_text_matches(text, _BAYES_TERMS)
    formal_hits = len(_PROB_QUANTIFIER_RE.findall(text))
    # base terms: 0.04 each; formal probability notation: 0.06 each
    raw = base * 0.04 + formal_hits * 0.06
    return min(raw, 0.55)


def _text_score_oyun_teorisi(text: str) -> float:
    """Score text for OyunTeorisi lens relevance. Cap: 0.50."""
    if not text:
        return 0.0
    base = _count_text_matches(text, _OYUN_TERMS)
    matrix_hits = len(_PAYOFF_MATRIX_RE.findall(text))
    nefs_hits = len(_NEFS_RE.findall(text))
    # base terms: 0.04 each; matrix language: 0.06 each; nefs: 0.05 each
    raw = base * 0.04 + matrix_hits * 0.06 + nefs_hits * 0.05
    return min(raw, 0.50)


def _text_score_kategori_teorisi(text: str) -> float:
    """Score text for KategoriTeorisi lens relevance. Cap: 0.45."""
    if not text:
        return 0.0
    base = _count_text_matches(text, _KATEGORI_TERMS)
    arrow_hits = len(_FUNCTOR_ARROW_RE.findall(text))
    # base terms: 0.04 each; arrow/functor notation: 0.06 each
    raw = base * 0.04 + arrow_hits * 0.06
    return min(raw, 0.45)


def _text_score_holografik(text: str) -> float:
    """Score text for Holografik lens relevance. Cap: 0.55."""
    if not text:
        return 0.0
    base = _count_text_matches(text, _HOLOGRAFIK_TERMS)
    dim_hits = len(_BESMELE_DIM_RE.findall(text))
    seed_hits = len(_HOLOGRAPHIC_SEED_RE.findall(text))
    # base terms: 0.04 each; B-dimensions: 0.05 each; seed phrases: 0.06 each
    raw = base * 0.04 + dim_hits * 0.05 + seed_hits * 0.06
    return min(raw, 0.55)


# Dispatch map for per-lens scoring
TEXT_SCORE_MAP: Dict[str, callable] = {
    "Ontoloji": _text_score_ontoloji,
    "Mereoloji": _text_score_mereoloji,
    "FOL": _text_score_fol,
    "Bayes": _text_score_bayes,
    "OyunTeorisi": _text_score_oyun_teorisi,
    "KategoriTeorisi": _text_score_kategori_teorisi,
    "Topoloji + Holografik": _text_score_holografik,
}


def compute_text_scores(text: str) -> Dict[str, float]:
    """Run every TEXT_SCORE_MAP function and return per-lens relevance scores.

    Returns:
        Dict mapping lens string id (e.g. ``"Bayes"``) to a relevance
        score in [0, cap].  Used by ``compute_dynamic_weights()`` in
        ``bileshke/engine.py`` to produce content-adaptive weights.
    """
    return {lid: fn(text) for lid, fn in TEXT_SCORE_MAP.items()}


# =====================================================================
# Lens 1 — Ontoloji (kavram_sozlugu)
# =====================================================================

@trace
def run_ontoloji(params: Dict[str, Any]) -> LensResult:
    """Run the Ontoloji lens (kavram_sozlugu).

    params:
        kavramlar: list[dict]  — optional pre-built Kavram dicts
            Each dict: {"name": str, "hakikat": [{"isim": str, "derece": float}],
                        "mahiyet": str, "dual_class": "harfi"|"ismi",
                        "is_living": bool}

    If kavramlar is empty, runs a default self-check on the registry.
    KV₇: fresh KavramSozlugu per call.
    """
    from kavram_sozlugu.registry import KavramSozlugu
    from kavram_sozlugu.types import Kavram, Tecelli

    registry = KavramSozlugu(preload=True)  # fresh instance

    kavramlar_raw = params.get("kavramlar", [])
    for kd in kavramlar_raw:
        hakikat = tuple(
            Tecelli(isim=t["isim"], derece=t.get("derece", 0.5))
            for t in kd.get("hakikat", [])
        )
        if not hakikat:
            # KV₈: must ground in >= 1 Name — provide minimal default
            hakikat = (Tecelli(isim="el-Hakîm", derece=0.1),)
        k = Kavram(
            name=kd["name"],
            hakikat=hakikat,
            mahiyet=kd.get("mahiyet", ""),
            dual_class=kd.get("dual_class", "harfi"),
            is_living=kd.get("is_living", False),
        )
        registry.register_kavram(k)

    score = clamp_score(registry.yakinlasma())
    checks_total = max(len(registry._kavramlar), 1)
    checks_passed = int(score * checks_total)
    detail = f"Registry size: {len(registry._kavramlar)} kavram(s)"

    # Text-based fallback: scan for known Names + framework vocabulary
    text = params.get("text", "")
    if score == 0.0 and not kavramlar_raw and text:
        known_names = registry.list_isimler()
        text_lower = text.lower()
        name_hits = 0
        for nm in known_names:
            nm_lower = nm.lower()
            if nm_lower in text_lower:
                name_hits += 1
                continue
            # Try without Arabic prefix (el-/er-/es-/eş-/ez-)
            for pfx in ("el-", "er-", "es-", "eş-", "ez-"):
                if nm_lower.startswith(pfx) and nm_lower[len(pfx):] in text_lower:
                    name_hits += 1
                    break
        fw_hits = _count_text_matches(text, _ONTOLOJI_TERMS)
        total_hits = name_hits + fw_hits
        if total_hits > 0:
            # Phase 1: use per-lens scorer (cap=0.65) instead of shared 0.35
            text_score = _text_score_ontoloji(text)
            score = clamp_score(max(text_score, min(total_hits * 0.02, 0.65)))
            checks_total = max(total_hits, 1)
            checks_passed = total_hits
            detail = f"Text scan: {name_hits} Names, {fw_hits} framework terms"

    grade = score_to_grade(score)

    return LensResult(
        lens_id=LensId.ONTOLOJI,
        score=score,
        grade=grade,
        checks_passed=checks_passed,
        checks_total=checks_total,
        detail=detail,
    )


# =====================================================================
# Lens 2 — Mereoloji
# =====================================================================

@trace
def run_mereoloji(params: Dict[str, Any]) -> LensResult:
    """Run the Mereoloji lens.

    params:
        parts: list[dict]  — optional part definitions
            Each dict: {"id": str, "type": str, "telos": str|None}
        relations: list[dict]  — optional relations
            Each dict: {"whole": str, "part": str}

    KV₇: fresh MereologicalStructure per call.
    """
    from mereoloji.relations import MereologicalStructure

    ms = MereologicalStructure()  # fresh instance

    for p in params.get("parts", []):
        ms.add_part(
            part_id=p["id"],
            part_type=p.get("type", "generic"),
            telos=p.get("telos"),
        )
    for r in params.get("relations", []):
        ms.add_relation(whole=r["whole"], part=r["part"])

    score = clamp_score(ms.yakinlasma())
    result = ms.verify_all()
    checks_passed = sum(1 for v in result.values() if v)
    checks_total = len(result)
    detail = f"Parts: {len(params.get('parts', []))}; checks: {checks_passed}/{checks_total}"

    # Text-based fallback when structure is empty
    text = params.get("text", "")
    has_structure = bool(params.get("parts")) or bool(params.get("relations"))
    if score == 0.0 and not has_structure and text:
        hits = _count_text_matches(text, _MEREOLOJI_TERMS)
        if hits > 0:
            # Phase 1: per-lens scorer (cap=0.50)
            score = clamp_score(_text_score_mereoloji(text))
            checks_passed = hits
            checks_total = max(hits, 1)
            detail = f"Text scan: {hits} mereological terms"

    grade = pass_ratio_to_grade(checks_passed, max(checks_total, 1))

    return LensResult(
        lens_id=LensId.MEREOLOJI,
        score=score,
        grade=grade,
        checks_passed=checks_passed,
        checks_total=checks_total,
        detail=detail,
    )


# =====================================================================
# Lens 3 — FOL (fol_formalizasyon)
# =====================================================================

@trace
def run_fol(params: Dict[str, Any]) -> LensResult:
    """Run the FOL lens.

    params:
        text: str   — source text to scan for AX/T/KV references
        model: dict | None — optional Model for axiom satisfaction checks

    KV₇: pure function, no shared state.
    """
    from fol_formalizasyon import yakinlasma, extract_axiom_refs

    text = params.get("text", "")
    model = params.get("model")  # None is valid

    score = clamp_score(yakinlasma(text, model))
    refs = extract_axiom_refs(text)
    total_refs = sum(len(v) for v in refs.values())

    grade = score_to_grade(score)

    return LensResult(
        lens_id=LensId.FOL,
        score=score,
        grade=grade,
        checks_passed=total_refs,
        checks_total=max(total_refs, 1),
        detail=f"AX refs: {len(refs.get('axioms', []))}; T refs: {len(refs.get('theorems', []))}; KV refs: {len(refs.get('kavaid', []))}",
    )


# =====================================================================
# Lens 4 — Bayes (bayes_analiz)
# =====================================================================

@trace
def run_bayes(params: Dict[str, Any]) -> LensResult:
    """Run the Bayes lens.

    params:
        model: dict | None — serialised BayesModel, or None for default check.

    KV₇: fresh computation, no shared state.
    """
    from bayes_analiz import yakinlasma

    model = params.get("model")  # None → score 0.0 (expected)

    score = clamp_score(yakinlasma(model))

    # Text-based fallback when no model provided
    text = params.get("text", "")
    if score == 0.0 and model is None and text:
        # Phase 1: per-lens scorer (cap=0.55)
        text_score = _text_score_bayes(text)
        if text_score > 0:
            score = clamp_score(text_score)

    grade = score_to_grade(score)
    hits = _count_text_matches(text, _BAYES_TERMS) if score > 0 and model is None else 0

    return LensResult(
        lens_id=LensId.BAYES,
        score=score,
        grade=grade,
        checks_passed=max(1, hits) if score > 0 else 0,
        checks_total=max(1, hits) if score > 0 else 1,
        detail=f"Bayes yakinlasma: {score:.4f}" + (f" (text: {hits} terms)" if hits else ""),
    )


# =====================================================================
# Lens 5 — OyunTeorisi (oyun_teorisi)
# =====================================================================

@trace
def run_oyun_teorisi(params: Dict[str, Any]) -> LensResult:
    """Run the OyunTeorisi lens.

    params:
        model: dict | None — serialised GameModel, or None for default check.

    KV₇: fresh computation, no shared state.
    """
    from oyun_teorisi import yakinlasma

    model = params.get("model")  # None → score 0.0

    score = clamp_score(yakinlasma(model))

    # Text-based fallback when no model provided
    text = params.get("text", "")
    if score == 0.0 and model is None and text:
        # Phase 1: per-lens scorer (cap=0.50)
        text_score = _text_score_oyun_teorisi(text)
        if text_score > 0:
            score = clamp_score(text_score)

    grade = score_to_grade(score)
    hits = _count_text_matches(text, _OYUN_TERMS) if score > 0 and model is None else 0

    return LensResult(
        lens_id=LensId.OYUN_TEORISI,
        score=score,
        grade=grade,
        checks_passed=max(1, hits) if score > 0 else 0,
        checks_total=max(1, hits) if score > 0 else 1,
        detail=f"OyunTeorisi yakinlasma: {score:.4f}" + (f" (text: {hits} terms)" if hits else ""),
    )


# =====================================================================
# Lens 6 — KategoriTeorisi (kategori_teorisi)
# =====================================================================

@trace
def run_kategori_teorisi(params: Dict[str, Any]) -> LensResult:
    """Run the KategoriTeorisi lens.

    params:
        cat: dict | None     — serialised Category
        functor: dict | None — serialised Functor
        eta: dict | None     — serialised NaturalTransformation

    KV₇: fresh computation, no shared state.
    """
    from kategori_teorisi import yakinlasma

    cat = params.get("cat")
    functor = params.get("functor")
    eta = params.get("eta")

    score = clamp_score(yakinlasma(cat, functor, eta))

    # Text-based fallback when no category data provided
    text = params.get("text", "")
    if score == 0.0 and cat is None and functor is None and text:
        # Phase 1: per-lens scorer (cap=0.45)
        text_score = _text_score_kategori_teorisi(text)
        if text_score > 0:
            score = clamp_score(text_score)

    grade = score_to_grade(score)
    hits = _count_text_matches(text, _KATEGORI_TERMS) if score > 0 and cat is None else 0

    return LensResult(
        lens_id=LensId.KATEGORI_TEORISI,
        score=score,
        grade=grade,
        checks_passed=max(1, hits) if score > 0 else 0,
        checks_total=max(1, hits) if score > 0 else 1,
        detail=f"KategoriTeorisi yakinlasma: {score:.4f}" + (f" (text: {hits} terms)" if hits else ""),
    )


# =====================================================================
# Lens 7 — Topoloji + Holografik (holografik)
# =====================================================================

@trace
def run_holografik(params: Dict[str, Any]) -> LensResult:
    """Run the Holografik lens.

    params:
        model: dict | None — serialised HolographicModel, or None for default.

    KV₇: fresh computation, no shared state.
    """
    from holografik import yakinlasma

    model = params.get("model")  # None → score 0.0

    score = clamp_score(yakinlasma(model))

    # Text-based fallback when no model provided
    text = params.get("text", "")
    if score == 0.0 and model is None and text:
        # Phase 1: per-lens scorer (cap=0.55)
        text_score = _text_score_holografik(text)
        if text_score > 0:
            score = clamp_score(text_score)

    grade = score_to_grade(score)
    hits = _count_text_matches(text, _HOLOGRAFIK_TERMS) if score > 0 and model is None else 0

    return LensResult(
        lens_id=LensId.TOPOLOJI_HOLOGRAFIK,
        score=score,
        grade=grade,
        checks_passed=max(1, hits) if score > 0 else 0,
        checks_total=max(1, hits) if score > 0 else 1,
        detail=f"Holografik yakinlasma: {score:.4f}" + (f" (text: {hits} terms)" if hits else ""),
    )


# =====================================================================
# Dispatch map: lens_id string → adapter function
# =====================================================================

ADAPTER_MAP: Dict[str, Callable[[Dict[str, Any]], LensResult]] = {
    "Ontoloji": run_ontoloji,
    "Mereoloji": run_mereoloji,
    "FOL": run_fol,
    "Bayes": run_bayes,
    "OyunTeorisi": run_oyun_teorisi,
    "KategoriTeorisi": run_kategori_teorisi,
    "Topoloji + Holografik": run_holografik,
}


@trace
def run_lens(lens_id: str, params: Optional[Dict[str, Any]] = None) -> LensResult:
    """Execute a single lens by ID.

    Args:
        lens_id: One of the 7 valid lens ID strings.
        params: Lens-specific parameters (default: empty dict).

    Returns:
        LensResult with score, grade, and checks.

    Raises:
        ValueError: If lens_id is not recognised.
    """
    if params is None:
        params = {}
    adapter = ADAPTER_MAP.get(lens_id)
    if adapter is None:
        raise ValueError(
            f"Unknown lens_id: {lens_id!r}. "
            f"Valid IDs: {list(ADAPTER_MAP.keys())}"
        )
    return adapter(params)
