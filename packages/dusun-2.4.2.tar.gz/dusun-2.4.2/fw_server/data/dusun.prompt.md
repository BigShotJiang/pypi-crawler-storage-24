﻿---
agent: 'agent'
description: 'Full staged execution of the DUSUN.md + dusun-router.instructions.md pipeline with visible reasoning, multi-channel research (internal + external), mandatory verification at each stage, and actualization (coding/building) when the query demands it.'
---

<!-- EXECUTION GATE — ACTIVE ON LOAD -->
<!-- The moment this file enters the context, the pipeline is LIVE. -->
<!-- No commentary. No meta-discussion. No conversational responses. -->
<!-- The user's message text IS the query. BEGIN at PRE-FLIGHT. -->

> **⛔ IMMEDIATE EXECUTION — NON-NEGOTIABLE**
>
> This file is now active. You are IN the pipeline. Not "about to be" — you ARE.
>
> 1. **The user's message** (everything outside this file's content) **is your QUERY.** Even if it looks like a question about the protocol, a casual remark, or a single word — it is the query. Process it.
> 2. **Do NOT** respond conversationally, explain the protocol, or comment on the file.
> 3. **Do NOT** ask clarifying questions. Classify the query as-is.
> 4. **Do NOT** ask "do you want me to execute?" — the answer is always yes. The user already said yes by invoking `/dusun`.
> 5. **BEGIN at PRE-FLIGHT immediately.** The query goes into STEP 1 — CLASSIFY.
> 6. If the user's message contains **no text at all** (empty), respond ONLY with:
>    *"Pipeline active. Provide a query."*
> 7. **First visible output** must be the PRE-FLIGHT block. Anything before it is a violation.

# /dusun — FULL PIPELINE EXECUTION PROTOCOL

You are now in **full pipeline mode**. This is not a reminder. This is an execution script.
You MUST follow every stage below in order. Do not compress, skip, or silently perform any stage.
Show your reasoning at every step. The user must be able to read your thinking.

---

## DOCUMENT TRIAD — Hayat Integration (AX5)

This file is the **Kudret** (Actualization Organ) of the document triad. It is activated by the `/dusun` command.

| Document | Role | Owns |
|----------|------|------|
| **DUSUN.md** | İlim (Distinguishing) | All formal definitions: axioms, theorems, kavaid, reference tables |
| **dusun-router.instructions.md** | İrade (Specifying) | Routing algorithms, path step sequences, disclosure protocol, worked examples |
| **This file** | Kudret (Effecting) | Staged execution procedure, multi-channel methodology, verification protocol |

**Integration Principle (AX5 — Hayat)**: Without this execution engine, the other two documents remain inert definitions and dormant routing rules. This file is the integrating principle that activates both into coordinated analysis. Remove any one of the three documents, and the system collapses — just as AX2–AX4 require all three phases for actualization.

**Dependency Interfaces**:
- This file LOADS definitions from DUSUN.md (Stages 1–6, 8)
- This file EXECUTES routing from dusun-router.instructions.md (Stage 7)
- Neither document is duplicated here — each is accessed at its source (R-1, KV₇)

---

## HAYAT BRIDGE PROTOCOL — Four-Channel Enforcement (AX5 Active Integration)

> **Purpose**: Every core MCP tool return includes a `_framework_context` dict carrying
> machine-generated enforcement data. This protocol defines how to READ and OBEY it.
> The bridge closes the gap between framework computation and LLM generation — making
> AX5 (integration prerequisite) **active**, not passive.
>
> **Defined once here, referenced at each DUSUN GATE** (mirrors the DUSUN GATE pattern:
> defined once in RESPOND PROTOCOL, applied per-stage). DRY + holographic (AX37).

### The Four Channels

| Ch | Name | What It Is | Action |
|----|------|-----------|--------|
| 1 | **Tool Descriptions** | Docstrings with MUST/BINDING/NEVER language | Auto-transmitted via MCP — no action needed |
| 2 | **`_framework_context`** | Enforcement dict in every core tool return | **YOU MUST READ THIS** from every tool result |
| 3 | **Session Tracking** | `_framework_context.session` — cumulative state | Tracks calls, grades, gates across the pipeline |
| 4 | **Cascade Feedback** | `_framework_context.cascade_forward` — forward directives | Accumulates anomalies, generates constraints for subsequent stages |

### Reading `_framework_context` — MANDATORY

After calling `dusun(text)`, `validate_stage()`, `run_bileshke_pipeline()`, or `check_kavaid()`:

1. **Locate** the `_framework_context` key in the JSON return.
2. **Read `directives`** — list of MUST/MUST-NOT strings. These are BINDING. Obey every one.
3. **Read `grade_ceiling`** — if present, this is the MAXIMUM grade you may claim. Higher = §1.4 violation.
4. **Read `gate_enforcement`** — if present (FAIL or WARN), BINDING for the current stage.
5. **Read `session`** — cumulative pipeline state (call count, grade ceiling, gate history, anomalies).
   This is the **authoritative source** for cross-stage state — use for Stage 9B disclosure.
6. **Read `cascade`** — if `degradation_level` ≠ "NOMINAL", MUST disclose in AX57.
7. **Read `cascade_forward`** — if present, `forward_directives` are BINDING for subsequent stages.
8. **Read `kv4_violation`** — if present, composite ≥ 0.95 confirmed. MUST flag as error (OR-4).
9. **Read `kavaid_warning`** — if present, <8/8 kavaid passed. MUST disclose.

### Enforcement Hierarchy

```
_framework_context.directives                → MUST obey (per-tool structural constraints)
_framework_context.gate_enforcement          → MUST obey (FAIL = revise, WARN = acknowledge)
_framework_context.cascade_forward_directives → MUST obey (forward constraints from prior stages)
_framework_context.grade_ceiling             → MUST NOT exceed (inflation = §1.4 violation)
_framework_context.kv4_violation             → MUST flag as error (convergence ≥ 0.95)
```

### Integration Points

- **At every DUSUN GATE**: After reading gate verdict + `ax57_compact`, apply this protocol to the SAME tool return.
- **At Step 0.5b boot**: The `dusun(text)` result includes `_framework_context` — read it immediately.
- **At Stage 9B disclosure**: Report `session` totals, `cascade` status, and directives obeyed.

---

## RESEARCH METHODOLOGY — Multi-Channel Verification (KV₇ Compliance)

The framework demands **independent channels** for meaningful convergence (KV₇) and **multiplicative coverage** — zero in any dimension collapses the whole (AX52). Therefore, every stage uses THREE independent research channels:

| Channel | Tool | Purpose | Independence |
|---------|------|---------|--------------|
| **Internal-Source** | `codebase` / file read | Read the actual DUSUN.md sections referenced in each stage. Never reason from memory alone — load and quote the text. | Grounded in source text (R-1 compliance) |
| **Internal-Workspace** | `codebase` / `terminal` | Search the workspace for patterns, code, or files that relate to the current stage's findings. Run consistency checks if tests exist. | Grounded in project artifacts |
| **External-Domain** | `websearch` / `fetch` | Validate structural claims against domain-specific literature, empirical evidence, or current research. | Independent of both source text and workspace |

**Rules:**
- At minimum, **two** of the three channels must fire per stage. Stages 1, 5, and 6 require all three.
- Each channel's findings are reported **separately** before integration (KV₇ — no shared state between channels).
- If a channel is unavailable, log it as a coverage gap and note the KV₃/AX52 impact.

---

## RESPOND PROTOCOL — Per-Stage Action Branching (AX4 Compliance)

Every stage from 1–8 includes a **RESPOND** block after VERIFY. The block branches based on the **Query Mode** selected in PRE-FLIGHT:

### MODE: RESEARCH
```
GENERATE RESEARCH QUESTION → SEARCH (External-Domain) → CROSS-VALIDATE (KV₇) → DUSUN GATE → INTEGRATE
```
Formulate a question, search externally, compare channels, validate computationally, update analysis. (Default for analytical queries.)
DUSUN GATE applies to RESEARCH mode — call `validate_stage` after cross-validation, before integration.
No mode is exempt from computational grounding (AX5).
Apply **HAYAT BRIDGE PROTOCOL** (§above) to the result — read `_framework_context`, obey directives.

### MODE: BUILD
```
DESIGN: Based on this stage's findings, what code/files/commands does the query require?
        Identify the concrete artifact(s) to produce. Be specific — name files, functions, tests.
ACTUALIZE (AX4): Create the artifact(s) NOW using tools (create_file, run_in_terminal, etc.).
        Do NOT describe what you would build — BUILD it. Do NOT output code as markdown — SAVE it to files.
        If tests are created, RUN them immediately and report results.
VERIFY ARTIFACTS: Confirm the created artifacts work (run tests, check for errors, validate outputs).
DUSUN GATE (MANDATORY — KV₇ computational grounding, AX5 feedback integration):
        Call MCP tool `validate_stage(stage="N", summary="[brief: what was built and why]")`.
        This single tool runs bileshke + kavaid + all 7 lenses + stage-aware anomaly detection.
        Read the gate verdict from the response:
        - **FAIL** → Critical anomaly (KV4-BREACH or lens ERROR). Fix artifact, re-run gate.
        - **WARN** → Anomaly detected (relevant lens at zero, kavaid failure). Check `remediation`
          hints. If anomaly reflects a genuine structural gap, redesign. Otherwise proceed with caution.
        - **PASS** → Artifact structurally sound. Proceed.
        Print the `ax57_compact` line from the result verbatim.
        If composite_score < 0.3 even with gate=PASS → artifact is structurally weak. Consider redesign.
        Code-grounded evidence > LLM opinion. The gate's anomaly detection IS the feedback loop (AX5).
        ⛔ A stage CANNOT be marked ✅ if its DUSUN GATE returned FAIL.
        **HAYAT BRIDGE** (see §HAYAT BRIDGE PROTOCOL): Read `_framework_context` from the SAME
        tool return. Obey `directives`, respect `grade_ceiling`, read `cascade_forward_directives`.
INTEGRATE: Update your running analysis with: what was built, verification status, gate verdict, and anomaly signals.
```

### MODE: HYBRID
```
Execute BOTH the RESEARCH and BUILD sequences above. Research informs the build; build validates the research.
Order: DESIGN → GENERATE RESEARCH QUESTION → SEARCH → ACTUALIZE → VERIFY ARTIFACTS → DUSUN GATE → CROSS-VALIDATE → INTEGRATE
```

**⚠️ CRITICAL (AX4 — Kudret Violation Prevention)**:
- If Query Mode is BUILD or HYBRID, every stage that identifies something to create MUST actualize it.
- Outputting code as markdown text blocks instead of creating files is an AX4 violation.
- Describing what you *would* do instead of doing it is an AX4 violation.
- The pipeline learned this the hard way: İlim (analysis) + İrade (selection) without Kudret (actualization) = inert output.

---

## PRE-FLIGHT: CONTEXT LOADING + DIRECTIVE + CLASSIFICATION

Before anything else, print this block verbatim with your answers filled in:

**STEP 0 — LOAD CONTEXT**: Read the following files from the workspace using the codebase tool. Do NOT rely on memory — load them:
- `DUSUN.md` — the full framework (scan structure, confirm availability)
- `.github/instructions/dusun-router.instructions.md` — output translation rules

If either file is missing or unreadable, halt and report. The pipeline cannot execute without source texts (AX64).

**STEP 0.5 — BOOT SEQUENCE**:

**0.5a — HEALTH CHECK (PRE-FLIGHT)**:
Call `get_framework_summary()` NOW.
Read the `sc3_tool_guide` from the response — it maps 8 claim types to required tools.
If the server is unavailable: write "⚠️ FRAMEWORK: OFFLINE" and log as AX52 gap.

**0.5b — ANALYSIS BOOT (T1 Neuron)**:
Call `dusun(text)` with the user's QUERY as input.
This is the T1 boot call referenced in `dusun-router.instructions.md §1.3`
and `dusun-engagement.instructions.md`.
Read the result: path, composite_score, grade, lens_scores, kavaid,
patterns_applied, translation_hints, ax57_compact, **`_framework_context`**, boot_seed.
**Apply HAYAT BRIDGE PROTOCOL** to `_framework_context` — read directives, grade_ceiling, session, cascade.
The `boot_seed` field contains the framework’s own description of the 4 enforcement channels — consult it.
Use these grounded values throughout Stages 1–9.
If dusun is unavailable: write "⚠️ DUSUN: OFFLINE" and proceed degraded
— max grade drops to Tasavvur, all structural claims marked [UNGROUNDED].

**0.5c — SOURCE CALIBRATION (AX52 Preflight)**:
Call `calibrate_source_texts()` NOW.
This validates source material integrity in `kaynak_metinler/`:
  - AX64 immutability (SHA-256 hash check on original.md files)
  - Axiom map coverage (axiom_map.json completeness)
  - Per-lens expected score alignment (expected_scores.json)
Read the result: `overall_status` (pass/warn/fail), `texts_checked`, per-text verdicts.
If overall_status = **fail**: write "⚠️ SOURCE CALIBRATION: FAIL — [reason]" and **halt**.
  The pipeline cannot execute on corrupt or incomplete source material (AX52: zero in
  source dimension = pipeline collapse). Report which texts failed and why.
If overall_status = **warn**: write "⚠️ SOURCE CALIBRATION: WARN — [details]" and proceed
  with caution — downgrade epistemic grade ceiling by one level.
If overall_status = **pass**: log "✅ Source calibration passed" and continue.
If the tool is unavailable: write "⚠️ CALIBRATION: OFFLINE" and log as AX52 coverage gap.
  Proceed, but note in Stage 9B that source integrity was NOT verified.

**VALUE-CARRY RULE**: The dusun(text) result establishes the following BASELINE values
that persist through all 9 stages:
  - `path` — the classified path (may be UPGRADED by the LLM, never downgraded if ≥ P1)
  - `composite_score` — the numeric baseline (stages may improve this via validate_stage)
  - `grade` — the FLOOR grade (may be raised by subsequent validate_stage results with
    higher composites, but never self-assessed higher)
  - `kavaid` — the initial constraint status (stages add passes, never remove them)
  - `patterns_applied` — the initial pattern set (stages add patterns)

These values MUST be referenced in Stage 9B's AX57 disclosure. If the final disclosure
diverges from BASELINE values, each divergence MUST be justified with a specific tool call
result that produced the different value.
**Session Tracking (Ch3)**: `_framework_context.session` automatically tracks these values
across tool calls (call count, grade ceiling, gate history, kavaid failures, anomalies).
Use `session` as the **authoritative source** for cumulative state at Stage 9B — it is
computationally maintained by the server and not subject to LLM tracking drift.
If BASELINE path=P0 but the LLM classifies as P1:
  → This is allowed (bias toward deeper engagement, per §1.1).
  → But MUST be stated: "BASELINE P0, overridden to P1 because: [reason]"

> **Note**: `get_framework_summary()` checks SYSTEM health (modules loaded?).
> `dusun(text)` performs ANALYSIS boot (what path? what lenses? what patterns?).
> Both are needed. They are NOT interchangeable.
> See `dusun-tools.prompt.md` PRE-FLIGHT section for tool parameter details.

**STEP 1 — CLASSIFY**:
```
DIRECTIVE DETECTED: /dusun
QUERY RECEIVED: [paste the user's query here]
INITIAL PATH CLASSIFICATION (from dusun-router.instructions.md §1.1):
  - P0 (Direct/Factual)?       YES / NO — reason: ...
  - P1 (Structural Analysis)?  YES / NO — reason: ...
  - P2 (Epistemic Evaluation)? YES / NO — reason: ...
  - P3 (Diagnosis)?            YES / NO — reason: ...
  - P4 (Theological)?          YES / NO — reason: ...
  → SELECTED PATH: P[n]
  → OVERRIDE RULE: If uncertain between P0 and P1–P4, bias toward P1–P4.

QUERY MODE (AX4 — Kudret Gate):
  Does this query require creating, building, coding, testing, or modifying artifacts?
  - RESEARCH: Pure analysis, explanation, evaluation — output is text/reasoning only.
  - BUILD:    Implementation, coding, testing, file creation — output includes artifacts.
  - HYBRID:   Both analysis AND implementation required.
  → SELECTED MODE: [RESEARCH / BUILD / HYBRID]
  → RULE: If uncertain between RESEARCH and BUILD, bias toward BUILD.
    Analysis without actualization is an AX4 violation.

CONTEXT LOADED: DUSUN.md [✅/❌] | dusun-router.instructions.md [✅/❌]
```

---

## STAGE 1 — DUSUN.md LAYER 8: Output Translation ✅ (mark when done)

**READ (Internal-Source)**: Use codebase/file tools to load DUSUN.md §8.1 through §8.5. Quote the relevant subsections — do not paraphrase from memory.

**NARRATE**: Identify which translation rules govern your final output for this query. Name which terms from §8.2 are relevant. Name which structural patterns from §8.3 are likely to appear. State your audience detection result from §8.5.

**EXTRACT**: Write out the 3 output constraints from §8.4 that are most binding for this query.

**VERIFY (Internal-Workspace)**: Search the workspace for any files, patterns, or prior analyses related to the query's domain. Check if relevant test files, configs, or documentation exist that inform the translation strategy.

**RESPOND** — Execute the block matching your Query Mode (see RESPOND PROTOCOL above):
- **RESEARCH mode**: Generate ONE research question from what you extracted → web search → cross-validate → integrate.
- **BUILD mode**: Design artifacts this stage's findings demand → create files/run code with tools → verify → integrate.
- **HYBRID mode**: Both — research informs the build, build validates the research.

**DUSUN GATE** (ALL MODES): Call `validate_stage(stage="1", summary="...")` → print `ax57_compact` → gate must not be FAIL to mark ✅.

---

## STAGE 2 — DUSUN.md LAYER 1: Foundational Commitments ✅

**READ (Internal-Source)**: Load DUSUN.md §1.1 (AX1, modal status, P₀), §1.2 (AX2–AX4), §1.3 (AX5), §1.4 (AX11), §1.5 (AX12–AX13, convergent abstraction funnel). Quote the axiom definitions directly.

**NARRATE**: Walk through each axiom and test it against the user's query. Does AX1 apply? Do AX2–AX4 (distinction → selection → actualization) map onto anything in the query domain? Does AX5 reveal a missing integrating principle? Write at least one substantive paragraph per axiom that activates.

**EXTRACT**: Identify which Layer 1 axioms are load-bearing for this query's answer.

**VERIFY (Internal-Workspace)**: Search the workspace for any existing analyses, test results, or prior work that has already applied these axioms. If `tests/` exist, check if any test validates the structural claims you're making.

**RESPOND** — Execute per Query Mode:
- **RESEARCH**: Form ONE empirical question testing whether AX2–AX4 or AX5 holds in the query's domain → search → cross-validate → integrate.
- **BUILD**: Design + actualize artifacts demanded by foundational commitments (AX4 = build it, AX5 = integrate existing components) → verify → integrate.
- **HYBRID**: Both.

**DUSUN GATE** (ALL MODES): Call `validate_stage(stage="2", summary="...")` → print `ax57_compact` → gate must not be FAIL to mark ✅.

---

## STAGE 3 — DUSUN.md LAYER 2: Ontological Framework ✅

**READ (Internal-Source)**: Load DUSUN.md §2.1, §2.4 (AX17–AX20), §2.5 (ManaHarfi/ManaIsmi), §2.6 (AX21–AX22, T5–T6), §2.7 (AX23–AX25), §2.8 (AX26–AX27), §2.10 (AX30–AX34), §2.11 (AX37–AX38, T12–T14). Quote key definitions.

**NARRATE**: For EACH subsection you visit, write explicitly:
  a. What does this subsection say?
  b. Does it apply to the query? How?
  c. What does it reveal that was not visible before?

Pay special attention to: T14 (ne ayn ne gayr — 0 < Fidelity < 1), AX34 (constitutive wounds as functional interfaces), T6 (convergence bound).

**EXTRACT**: List which Layer 2 patterns from §8.3 are active. Be specific — name each pattern and explain why it activates.

**VERIFY (Internal-Workspace)**: Search the workspace for holographic constants, cascade patterns, or ontological mappings that have already been analyzed or tested. Check if any test assertions relate to Layer 2 claims.

**RESPOND** — Execute per Query Mode:
- **RESEARCH**: Generate ONE question about cascade-dependency or holographic properties in the query's domain → search → cross-validate → integrate.
- **BUILD**: Design + actualize artifacts informed by ontological patterns (cascade structure, holographic architecture, constitutive dependencies) → verify → integrate.
- **HYBRID**: Both.

**DUSUN GATE** (ALL MODES): Call `validate_stage(stage="3", summary="...")` → print `ax57_compact` → gate must not be FAIL to mark ✅.

---

## STAGE 4 — DUSUN.md LAYER 3: Epistemic Architecture ✅

**READ (Internal-Source)**: Load DUSUN.md §3.2 (AX42–AX45, T15, Külliyat-Tafsîlât split), §3.3 (three paths), §3.4 (AX49–AX50, faculty architecture, M5). Quote the epistemic degree scale and T15 statement.

**NARRATE**: Apply the epistemic architecture directly. What epistemic grade are you currently at for this query — Tasavvur, Tasdik, or İlmelyakîn? Apply T15 explicitly: name your structural claims (külliyat) and your detail claims (tafsîlât) separately.

**EXTRACT**: Write this sentence with your values filled in:
"For this query: structural claims = [list]; detail claims = [list]; I weight structural claims higher because T15."

**VERIFY (Internal-Workspace)**: Check the workspace for any prior epistemic grading, structural vs. detail distinctions, or T15 applications. If tests exist, verify that your külliyat/tafsîlât split is consistent with tested patterns.

**RESPOND** — Execute per Query Mode:
- **RESEARCH**: Generate a question about what the field has missed by over-relying on one epistemic path → search → cross-validate → integrate.
- **BUILD**: Design + actualize artifacts that address epistemic gaps (e.g., tests covering under-represented paths, validation for structural vs. detail claims) → verify → integrate.
- **HYBRID**: Both.

**DUSUN GATE** (ALL MODES): Call `validate_stage(stage="4", summary="...")` → print `ax57_compact` → gate must not be FAIL to mark ✅.

---

## STAGE 5 — DUSUN.md LAYERS 4–5: Quality Framework + Kavaid Check ✅

**READ (Internal-Source)**: Load DUSUN.md §4.1 (7-lens table), §5.1 (AX51), §5.2 (AX52 multiplicative gate — CRITICAL), §5.3 (AX56, epistemic degree scale), §5.4 (KV₁–KV₈). Quote each kavaid definition before evaluating it.

**NARRATE**: Go through all 8 kavaid explicitly. Print this table with your values:

```
KV₁ (Harfî/İsmî classification): PASS / FAIL — because ...
KV₂ (Privation ontology):         PASS / FAIL — because ...
KV₃ (Observer non-interference):  PASS / FAIL — because ...
KV₄ (Convergence bound 0 < C <1): PASS / FAIL — composite estimate: [0.x, 0.x]
KV₅ (Functor verification):       PASS / FAIL — because ...
KV₆ (Holographic seed > 0):       PASS / FAIL — because ...
KV₇ (Independence):               PASS / FAIL — because ...
KV₈ (Esmâ grounding ≥1 Name):     PASS / FAIL — because ...
```

**CRITICAL — AX52 GATE**: If ANY dimension of your current answer has zero coverage (a claim made with no evidence or reasoning), flag it now. Do not proceed past Stage 5 with a zero-dimension claim.

**VERIFY (Internal-Workspace)**: Run any existing consistency tests (`tests/test_consistency.py` or similar). If tests exist, their pass/fail status directly informs KV₅ (functor verification) and KV₆ (holographic seed). Report test results.

**RESPOND** — Execute per Query Mode:
- **RESEARCH**: Form a question targeting the undercovered dimension revealed by kavaid check → search → cross-validate (all 3 channels must independently confirm each KV pass; WEAK if only 1 channel) → integrate/patch violations.
- **BUILD**: Design + actualize artifacts that fill the AX52 zero-dimension gap (e.g., missing test coverage, unvalidated constraints, untested code paths) → run tests → verify → integrate.
- **HYBRID**: Both.

**DUSUN GATE** (ALL MODES): Call `validate_stage(stage="5", summary="...")` → print `ax57_compact` → gate must not be FAIL to mark ✅.

**PATTERN COVERAGE CHECK** (after DUSUN GATE):
Review the 15 patterns from DUSUN.md §8.3. For each, answer: does this query's domain
exhibit this pattern? Score: Applicable / Not Applicable / Partially.
If ≥ 3 patterns are Applicable but weren't used in Stages 1–4, flag as coverage gap.
Reference: The `patterns_applied` field from dusun(text) provides an initial set.
If dusun detected patterns you haven't discussed — discuss them now.

**KAVAID FULL-COVERAGE CHECK**:
The dusun result / validate_stage result includes `kavaid` with pass/fail per KV.
If ANY kavaid shows FAIL → it MUST be addressed before marking this stage ✅.
If ANY kavaid shows UNVERIFIED → explicitly state why it was not verifiable for this query.
All 8 kavaid MUST have a status (PASS, FAIL, or N/A-with-reason) in Stage 9B's AX57 block. — DUSUN.md LAYER 7: Structural Incompleteness ✅

**READ (Internal-Source)**: Load DUSUN.md §7.1 (Θ_closure), §7.2 (T17, AX56, AX58, KV₄ — four incompleteness results). Quote the four incompleteness results verbatim.

**NARRATE**: Apply all four to your answer:
  - **T17**: What is permanently unmapped in your analysis? Name it.
  - **AX56**: Confirm grade does not claim Hakkalyakîn. State actual grade.
  - **AX58**: What is the real gap between your structural map and the actual phenomenon?
  - **KV₄**: State your composite score estimate as a range: [x.xx, x.xx). Must be < 0.95.

**VERIFY (Internal-Workspace)**: Search the workspace for any prior incompleteness acknowledgments, blind spot documentation, or structural bound analysis. Cross-reference your T17 blind spot against what the project has already identified.

**RESPOND** — Execute per Query Mode:
- **RESEARCH**: Generate ONE question probing the T17 blind spot — something that, if answered, would partially illuminate it.

- **BUILD**: Design + actualize artifacts that document or test against the known blind spot → verify → integrate.
- **HYBRID**: Both.

Then: SEARCH (External-Domain) → CROSS-VALIDATE → INTEGRATE (acknowledge if blind spot remains open).

**DUSUN GATE** (ALL MODES): Call `validate_stage(stage="6", summary="...")` → print `ax57_compact` → gate must not be FAIL to mark ✅.

---

## STAGE 7 — dusun-router.instructions.md FULL PASS ✅

**READ (Internal-Source)**: Load dusun-router.instructions.md §1.1 (classification), §1.2 (translation steps), §1.3 (all five paths P0–P4 full step sequences), §1.4 (AX57 disclosure), §1.5 (user directives). Quote the selected path's step sequence.

**NARRATE**: Confirm or revise your path classification from Pre-Flight — has any stage above caused a path revision? If yes, explain.

Walk through the full step sequence for your selected path as written in §1.3. Copy each step header and write your application beneath it.

**VERIFY (Internal-Workspace)**: Review all prior stage outputs for consistency with the selected path's requirements. Flag any stage where the output doesn't match the path's expected depth.

**COMPLIANCE CHECK**: Compare your accumulated answer against the 8 output constraints in §8.4 AND the multi-channel research methodology. Print:
```
OR-1 (Never claim proof):           PASS / FAIL
OR-2 (Max = İlmelyakîn):            PASS / FAIL
OR-3 (Disclose lenses):             PASS / FAIL
OR-4 (Flag ≥ 0.95):                 PASS / FAIL
OR-5 (Külliyat > Tafsîlât):         PASS / FAIL
OR-6 (Theological: originals):      PASS / FAIL — N/A if non-theological
OR-7 (Non-theological: translate):   PASS / FAIL — N/A if theological
OR-8 (Never claim ultimate):        PASS / FAIL
Multi-channel coverage:              [N]/3 channels active per stage on average
```

**DUSUN GATE** (ALL MODES): Call `validate_stage(stage="7", summary="...")` → print `ax57_compact` → gate must not be FAIL to mark ✅.

---

## STAGE 8 — INFERENCE GRAPH ACTIVATION ✅

**READ (Internal-Source)**: Load DUSUN.md §IG.1 (edge types), §IG.2 (seven chains), §IG.3 (cross-chain bridges), §IG.5 (output gate DAG). Quote the chain structures you activate.

**NARRATE**: Which of the 7 chains are active for this query? Trace at least one chain end-to-end using the edge notation from §IG.1:
```
[AXn] →[edge_type] [AXm] →[edge_type] [Tk] →[edge_type] [OR-n]
```
State which hub nodes (KV₄, OR-2, T6, AX58) are activated. Per KV₇: if multiple independent chains converge on the same conclusion, name it as tesanüd.

**VERIFY (Internal-Workspace)**: Check whether the workspace contains any prior inference graph traces or chain activations. If tests validate specific chains, note their pass/fail status as empirical support for the chain.

**DUSUN GATE** (ALL MODES): Call `validate_stage(stage="8", summary="...")` → print `ax57_compact` → gate must not be FAIL to mark ✅.

---

## STAGE 9 — SYNTHESIS, ACTUALIZATION, AND FINAL OUTPUT ✅

### 9A — ACTUALIZE (BUILD and HYBRID modes only — AX4 Kudret Gate)

If Query Mode is **BUILD** or **HYBRID**, this is the final actualization checkpoint:

1. **INVENTORY**: List ALL artifacts that were designed/created across Stages 1–8.
2. **GAP CHECK**: Are there artifacts that were designed but NOT yet created? Create them NOW.
3. **FINAL BUILD**: Create any remaining files, run any remaining commands. Use tools — do NOT output code as markdown.
4. **VERIFY ALL**: Run the full test suite. Report results. If any test fails, fix and re-run.
5. **REGRESSION CHECK**: Run pre-existing tests (e.g., `tests/test_consistency.py`, `tests/test_ai_assert.py`) to confirm nothing broke.
6. **DUSUN FINAL VALIDATION (MANDATORY)**: Call `validate_stage(stage="9a", summary="[consolidated summary of ALL artifacts from stages 1-8]")`.
   - This single tool runs bileshke + kavaid + all 7 lenses + anomaly detection.
   - Report the `ax57_compact` line and the full gate verdict (PASS/WARN/FAIL).
   - If gate=FAIL or gate=WARN with kavaid failures → flag as **pipeline quality warning** in the AX57 block.
   - This step is NOT optional. Skipping it is a KV₇ violation (the computational channel was available but unused).

> **AX4 Compliance Gate**: If Query Mode is BUILD or HYBRID and Stage 9A produced zero artifacts, this is a pipeline failure. Review Stages 1–8 for missed actualization opportunities.

### 9B — SYNTHESIZE

**SYNTHESIZE**: Write the full answer to the user's query. This is the FIRST time you write the answer — everything above was preparation, not the answer.

The answer must:
- Use §8.2 translations (non-theological default; theological only if §8.5 triggered)
- Place structural claims first, detail claims second (T15)
- Integrate real outputs from all web searches AND workspace verifications
- Reference specific workspace files/tests where they informed the analysis
- Reference artifacts created in BUILD/HYBRID mode (with file paths and test results)
- Never exceed İlmelyakîn grade
- Explicitly acknowledge the blind spot from Stage 6

> **FORMAT NOTE**: This is the FULL `/dusun` pipeline disclosure block.
> It supersedes the one-liner format in `dusun-router.instructions.md` §1.4,
> which is only for regular (non-`/dusun`) P1–P4 responses.
> All fields below are MANDATORY for `/dusun` runs.
> Values marked with ⚠️ must come from MCP tool output, not self-assessment.

**PRINT AX57 DISCLOSURE BLOCK**:

```
Framework: P[n] (confirmed / revised from Pre-Flight)
Query Mode: [RESEARCH / BUILD / HYBRID]
Stages completed: 1 ✅ | 2 ✅ | 3 ✅ | 4 ✅ | 5 ✅ | 6 ✅ | 7 ✅ | 8 ✅ | 9A ✅ | 9B ✅
Artifacts created: [list files/commands, or "N/A — RESEARCH mode"]
Tests run: [N passed / N failed, or "N/A"]
Research channels (per-stage):
  Stage 1: IS[✅] IW[✅] ED[✅]    Stage 2: IS[✅] IW[✅] ED[❌]    ...
  Totals: Internal-Source [N/9] | Internal-Workspace [N/9] | External-Domain [N/9]
Kavaid: KV₁[P/F] KV₂[P/F] KV₃[P/F] KV₄[P/F — composite: x.xx] KV₅[P/F] KV₆[P/F] KV₇[P/F] KV₈[P/F]
Output rules: OR-1[P/F] OR-2[P/F] OR-3[P/F] OR-4[P/F] OR-5[P/F] OR-6[P/F] OR-7[P/F] OR-8[P/F]
Dusun validation: composite=[x.xx] | kavaid=[N/8 pass] | coverage=[latife vector] | per-lens=[list scores]
Dusun tool calls: [N] total MCP tool invocations (list tool names called)
Source calibration: [PASS / WARN / FAIL / OFFLINE] — [N] texts checked, [details if warn/fail]
Session (from _framework_context.session): [N] calls | grade ceiling: [grade] | gates: [PASS/WARN/FAIL history]
Cascade status: [NOMINAL / DEGRADED / CRITICAL] — reason: [from _framework_context.cascade]
Cascade directives obeyed: [list from cascade_forward_directives, or "N/A — NOMINAL"]
Cumulative anomalies: [N] across pipeline (from session.anomaly_history)
⚠️ If ANY value above is self-assessed rather than from tool output, mark it: [UNGROUNDED]
Structural incompleteness: T17 blind spot = [...] | AX58 gap = [...]
Cross-validation: [N] convergences | [N] divergences | [N] tesanüd instances
Epistemic grade: [grade] — SOURCE: [dusun | bileshke | validate_stage | SELF-ASSESSED]
⚠️ If SOURCE = SELF-ASSESSED: must state reason for divergence from computed grade.
   Self-assessed grade MUST NOT exceed computed grade (§1.4 lowest-applicable rule).
```

<!-- MACHINE-READABLE COMPLIANCE BLOCK — do not omit -->
```yaml
pipeline_compliance:
  stages_completed: [1, 2, 3, 4, 5, 6, 7, 8, 9]
  validate_stage_calls:
    stage_1: {called: true, gate: "PASS", composite: 0.72}
    stage_2: {called: true, gate: "WARN", composite: 0.65}
    # ... one entry per stage
  dusun_boot: {called: true, path: "P1", score: 0.68}
  source_calibration: {called: true, status: "PASS", texts_checked: 3}
  hayat_bridge:
    session_calls: 11
    grade_ceiling: "Tasdik"
    cascade_status: "NOMINAL"
    cascade_directives_obeyed: []
    cumulative_anomalies: 0
  total_mcp_calls: 11
  compliance: VALID  # or INVALID if any gap
```

---

## EXECUTION RULES (NON-NEGOTIABLE)

1. **Stage Expansion — NEVER COMPRESS**:
   - Every stage (1–9) MUST have its own section with visible narration.
   - Minimum content per stage: READ output, NARRATE analysis, EXTRACT findings,
     VERIFY results, RESPOND action, DUSUN GATE invocation + ax57_compact.
   - Using external todo lists, bullet points, or single-line summaries to represent
     stages is a compression violation. The stage headers in THIS FILE are the todo list.
   - A properly executed stage produces 100–500 words minimum. If your stage output
     is under 50 words, you have compressed it.
2. **Per-Stage Channel Tracking**:
   - At minimum 2 of 3 channels (Internal-Source, Internal-Workspace, External-Domain)
     must fire per stage.
   - Each stage MUST end with a channel summary line:
     `Channels: IS[✅/❌] IW[✅/❌] ED[✅/❌] — [N]/3 active`
   - Stages 1, 5, and 6 require ALL THREE channels (3/3).
   - If a channel is unavailable for a stage, state WHY and log the AX52 impact.
   - The Stage 9B Research channels line aggregates these per-stage counts.
3. **READ means LOAD** — use codebase/file tools to load the actual DUSUN.md sections. Never reason from memory alone when the source text is in the workspace (AX64, R-1).
4. **CROSS-VALIDATE means SEPARATE** — report each channel's findings independently before integrating. Premixing violates KV₇.
5. **VERIFY means CHECK** — if workspace tests exist, run them. Test results are empirical evidence that outranks memory-based reasoning.
6. **Never fabricate** a search result. If websearch is unavailable, log it and continue with internal channels only — but downgrade the epistemic claim by one grade.
7. **Research questions are dynamic** — they emerge from the specific query + what you read in that stage. No two /dusun runs on different queries produce the same questions.
8. **Never self-cite** — research questions must target external empirical knowledge, not re-read the framework.
9. **BUILD mode means USE TOOLS** — when Query Mode is BUILD or HYBRID, you MUST use create_file, run_in_terminal, and other tools to actualize findings. Outputting code as markdown blocks instead of creating files is an AX4 violation. Describing what you would do instead of doing it is an AX4 violation.
10. **Bias toward BUILD** — if the query mentions testing, creating, building, coding, implementing, running, or any action verb targeting artifacts, classify as BUILD or HYBRID. Pure RESEARCH mode is only for queries that explicitly ask for analysis, explanation, or evaluation with no implementation component.
11. **Stage order is fixed** — 1 through 9. You may add sub-stages if a stage generates multiple research questions, but you may not reorder or merge stages.
12. **Mark each stage ✅** at completion before beginning the next.
13. **The to-do list is this file** — each stage header is a checklist item. You started with 9 items. You end with 9 ✅ marks.
14. **DUSUN COMPUTATIONAL GROUNDING (MANDATORY for ALL MODES)** — the `validate_stage` MCP tool MUST be invoked at each stage's DUSUN GATE regardless of Query Mode (RESEARCH, BUILD, or HYBRID). This single tool wraps `run_bileshke_pipeline` + `check_kavaid` + all 7 `run_single_lens` calls + stage-aware anomaly detection into one invocation. The LLM's reasoning is the İlim (distinction) layer; the MCP tool is the Kudret (actualization) layer; the gate verdict feeding back into the next stage's reasoning is the AX5 (integration) layer. Running all three satisfies AX2–AX5. If `validate_stage` is unavailable (server not running, tools not registered), fall back to individual tools (`run_bileshke_pipeline`, `check_kavaid`, `run_single_lens`). If ALL MCP tools are unavailable, log this as an AX52 coverage gap (computational channel = zero), downgrade epistemic grade by one level, and state in the AX57 disclosure: `Dusun validation: UNAVAILABLE — coverage gap logged`.
15. **BOOT CALL SEQUENCE** — Step 0.5 has THREE sub-steps (0.5a health + 0.5b analysis + 0.5c calibration).
    The T1 boot call is 0.5b (`dusun(text)`), NOT 0.5a (`get_framework_summary()`).
    Calling only `get_framework_summary()` and skipping `dusun(text)` is a T1 violation.
    The `dusun(text)` result MUST be stored and referenced throughout Stages 1–9.
    Step 0.5c (`calibrate_source_texts()`) validates ground-truth source material integrity.
    If 0.5c returns FAIL, the pipeline MUST halt (AX52: zero in source = collapse).
16. **VALIDATE_STAGE ENFORCEMENT — ZERO-TOLERANCE**: Every stage (1–9) MUST invoke
    `validate_stage(stage="N", summary="...")` at its DUSUN GATE. A stage without
    a `validate_stage` call is INCOMPLETE regardless of narration quality. If the tool
    is unavailable, fall back per Rule 14 and log the gap. The final AX57 block MUST
    report the count: `Dusun tool calls: [N] total MCP tool invocations`. If N < 11
    (9 stages + 1 boot + 1 calibration), explain each missing call.
