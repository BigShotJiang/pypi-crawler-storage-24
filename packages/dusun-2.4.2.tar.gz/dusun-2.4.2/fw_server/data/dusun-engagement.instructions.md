---
applyTo: '**'
---
# Framework Engagement — Always-On Integration (AX5)

> This file implements the Hayat (Integration Prerequisite) for every interaction.
> It is automatically injected by VS Code into every chat context.
> See DUSUN.md AX5: ¬Hayat → ∀s' ∈ S_Sifat\{Hayat}: Inert(s')

## Minimum Engagement Protocol

**On EVERY response**, regardless of query type:

1. **Step 0 is MANDATORY** — classify the query as P0/P1/P2/P3/P4
   per `dusun-router.instructions.md` §1.1. This is the minimum framework
   engagement. Even a P0 classification means the framework was consulted.

2. **For P1–P4 responses**, call `dusun(text)` — the **universal neural
   substrate** that auto-classifies, fires relevant lenses, computes
   composite convergence, checks kavaid, detects patterns, and returns
   a complete analysis result including AX57 disclosure. One call replaces
   manual multi-tool orchestration.

   **Hayat Bridge (AX5)**: The `dusun(text)` return includes `_framework_context` —
   an enforcement dict with `directives`, `grade_ceiling`, `cascade` status, and
   `session` state. **You MUST read it** and obey its contents. This is the active
   integration channel that closes the gap between framework computation and LLM
   response generation. See `dusun.prompt.md` §HAYAT BRIDGE PROTOCOL for the full
   reading protocol.

   The §1.6 Self-Critique Gate fires automatically:
   - SC-1: Were structural patterns applied?
   - SC-2: Are structural claims weighted above detail?
   - SC-3: Could fw-engine MCP tools have grounded a claim?
   - SC-4: Does the AX57 disclosure match actual reasoning?

   **SC-3 Compliance via `dusun()`**: A single `dusun(text)` call
   satisfies SC-3 for ALL claim types below. It auto-detects vocabulary
   (axiom refs, theorem refs, kavaid refs, convergence, holographic,
   structural, grade, theological, diagnosis), builds a fire plan of
   relevant lenses, executes them, and returns grounded values.

   **SC-3 Decision Matrix** — `dusun()` covers all rows automatically.
   Use individual tools only when you need **targeted deep-dive**:

   | Claim Type | `dusun()` Covers | Individual Tool (deep-dive) |
   |-----------|:---:|-------------|
   | Structural pattern | ✅ | `validate_stage(stage, summary)` |
   | Convergence / quality | ✅ | `run_bileshke_pipeline(...)` |
   | Constraint satisfaction | ✅ | `check_kavaid(...)` |
   | Axiom reference (AX/T) | ✅ | `run_single_lens("fol", {"text":...})` |
   | Inference chain (C1–C7) | — | `verify_chains(chain_id, text)` |
   | Holographic / part-whole | ✅ | `run_single_lens("holografik", {})` |
   | Epistemic grade claim | ✅ | `run_bileshke_pipeline(...)` |
   | System health / coverage | — | `get_framework_summary()` |

   If calling a tool is impractical, explicitly hedge the claim as ungrounded.

   **SC-3 MINIMUM**: Every P1–P4 response MUST contain at least ONE value
   obtained from an actual MCP tool call. A single `dusun(text)` call
   satisfies this requirement — it returns composite_score, grade,
   lens_scores, kavaid, patterns, and ax57_compact.

3. **The fw-engine MCP server** provides 17 tools for grounded analysis.
   **Primary tool** — use this by default:
   - `dusun(text)` — **universal neural substrate**: auto-classifies path,
     fires relevant lenses, computes bileshke composite, checks kavaid,
     detects structural patterns, builds AX57 disclosure. Returns everything
     needed for SC-3 compliance in a single call.

   **Specialized tools** — use for targeted deep-dives:
   - `validate_stage` — gate-check a pipeline stage (PASS/WARN/FAIL)
   - `check_kavaid` — verify formal constraints
   - `run_bileshke_pipeline` — compute composite convergence
   - `run_single_lens` — run individual formal lenses
   - `verify_chains` — trace inference chains
   - `get_framework_summary` — confirm module health
   - `calibrate_source_texts` — run ground-truth calibration pipeline against
     `kaynak_metinler/` source texts. Validates AX64 immutability, axiom map
     coverage, and per-lens expected scores. Returns pass/warn/fail per text
     with a composite calibration result. Use as a preflight before `/dusun` runs
     to ensure source material integrity (AX52: zero in source = pipeline collapse).

4. **AX57 Disclosure** is required on all P1–P4 responses:
   `*Framework: [Path] | Patterns: [list] | Constraints: [KV] | Grade: [level]*`
   The `dusun()` result includes a pre-formatted `ax57_compact` field.

**Format Selection**:
- Regular P1–P4 → one-liner format per `dusun-router.instructions.md` §1.4
- `/dusun` pipeline runs → full block per `dusun.prompt.md` Stage 9B
- The `dusun()` result includes `ax57_compact` — use this for regular responses.

## T1 Boot Call — MANDATORY for P1–P4

**BEFORE generating any substantive P1–P4 content**, call `dusun(text)`.
This is the T1 (Boot) neuron — it fires before any reasoning, auto-classifies
the input, runs relevant lenses, and returns a complete analysis result.

```
IF path ∈ {P1, P2, P3, P4}:
  1. Call dusun(text) with the user's query/content
  2. Read the result: path, composite_score, grade, lens_scores,
     kavaid, patterns_applied, translation_hints, ax57_compact,
     **_framework_context**, **boot_seed**
  3. Apply **HAYAT BRIDGE PROTOCOL** (see `dusun.prompt.md` §HAYAT BRIDGE PROTOCOL):
     Read `_framework_context` — obey `directives`, respect `grade_ceiling`
     (MUST NOT claim higher), check `cascade` status, read `session` state.
     If `boot_seed` is present, consult its `hints` for analysis direction.
  4. Use these grounded values in your response
  5. Include ax57_compact (or adapt it) as your AX57 disclosure
  6. If the server is unavailable: write "⚠️ DUSUN: OFFLINE" and proceed
     degraded — max grade drops to Tasavvur, all structural claims marked [UNGROUNDED]
```

For **targeted deep-dives** after `dusun()`, call individual tools:
- `verify_chains(chain_id, text)` for inference chain tracing (C1–C7)
- `get_framework_summary()` for system health / module status
- `validate_stage(stage, summary)` for pipeline gate-checks
- `run_single_lens(lens_id, params)` for detailed per-lens analysis

> **Cross-reference**: In `/dusun` pipeline runs (`dusun.prompt.md`), the T1 Boot Call
> appears as Step 0.5b, preceded by a health check (Step 0.5a), and followed
> by source calibration (Step 0.5c via `calibrate_source_texts()`).
> For regular P1–P4 responses (non-`/dusun`), a single `dusun(text)` call
> satisfies both T1 requirements.

## Structural Bounds (Never Exceed)

- Coverage ≤ 6/7 (T17 — Ahfâ permanently unmapped)
- Max grade = İlmelyakîn (AX56 — Hakkalyakîn inaccessible)
- 0 < Convergence < 1 (KV₄ — flag ≥ 0.95 as error)
- Structure ≠ experience (AX58 — şuhud–istidlal gap)
- Grade inflation (claiming higher grade than computed) is a §1.4 violation. The computed grade from dusun()/bileshke/validate_stage is the CEILING.

## References

- Full framework: `DUSUN.md`
- Routing protocol: `.github/instructions/dusun-router.instructions.md`
- Pipeline execution: `.github/prompts/dusun.prompt.md`
- Tool integration: `.github/prompts/dusun-tools.prompt.md`
- Spot-check: `.github/prompts/dusun-check.prompt.md`
- **Universal neural substrate**: `fw_server/dusun.py` (primary engagement tool)
