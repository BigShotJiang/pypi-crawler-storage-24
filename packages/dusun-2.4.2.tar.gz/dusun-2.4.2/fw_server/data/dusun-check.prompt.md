---
agent: 'agent'
description: 'Spot-check framework engagement. Runs check_kavaid and bileshke on the current conversation to verify the /dusun pipeline is active and structurally sound.'
---

# /self-check — Framework Engagement Verification

> **Purpose**: Lightweight diagnostic to confirm the framework is active and
> reasoning through the structural apparatus, not merely quoting it.
> Use this when you suspect the framework has gone dormant mid-conversation.

## DIRECTIVE: /self-check

When this prompt is invoked, perform the following diagnostic sequence:

### 1. Run Kavaid Check

Call the fw-engine MCP tool:
```
check_kavaid(
  composite_score=0.0,
  latife_bits=[1,1,1,1,1,1,0],
  kavaid_overrides={}
)
```
If this call **fails** (tool not found, server not running), the framework
engine is disconnected. Report: "fw-engine MCP server is not active."

If it **succeeds**, report the kavaid pass/fail results.

### 2. Run Bileshke Pipeline

Call the fw-engine MCP tool:
```
run_bileshke_pipeline(
  lens_params={
    "ontoloji": {"kavramlar": []},
    "mereoloji": {"parts": [], "relations": []},
    "fol": {"text": "self-check diagnostic"},
    "bayes": {},
    "oyun_teorisi": {},
    "kategori_teorisi": {},
    "holografik": {}
  },
  weights=null,
  ortam_bits=[1,1,1]
)
```
Report the composite score, grade, and any KV₄ warnings.

### 3. Classify Current State

Based on the tool results, report:

```
/self-check results:
  fw-engine:     [connected / disconnected]
  Kavaid:        [X/8 pass]
  Composite:     [score]
  Grade:         [epistemic grade]
  KV₄ warning:   [yes/no]
  Self-Critique:  §1.6 [active / not detected]
  Assessment:    [Framework engaged / Framework dormant / Partial engagement]
```

### 4. Remediation (if dormant)

If the framework is dormant:
1. Re-read DUSUN.md (or invoke `get_framework_summary()`)
2. Re-classify the current query via Step 0 (§1.1)
3. Re-engage the appropriate path (P0–P4)
4. Confirm re-engagement by running this diagnostic again

---

*Companion to §1.6 Self-Critique Gate. This is the manual trigger; §1.6 is the automatic one.*
