from CustomeLibrary.Util import Util

_version_ = '0.0.5'

class CustomeLibrary(Util):
    ROBOT_LIBRARY_SCOPE = 'GLOBAL'