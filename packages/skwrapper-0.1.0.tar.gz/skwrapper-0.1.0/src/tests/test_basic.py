import pandas as pd
from skwrapper import sc, sr
import matplotlib.pyplot as plt
import seaborn as sns

import kagglehub

# path = kagglehub.dataset_download("raipiyush558/social-network-ad")
# print(path)

import os
os.listdir('C:/Users/91989/.cache/kagglehub/datasets/raipiyush558/social-network-ad/versions/1')


df = pd.read_csv("C:/Users/91989/.cache/kagglehub/datasets/raipiyush558/social-network-ad/versions/1/Social_Network_Ads.csv")
# print(df.head(5))
# print(df.tail(5))

maxSal = df["EstimatedSalary"].max()
minSal = df['EstimatedSalary'].min()

print(f"max = {maxSal}, min = {minSal}")

selected_row = df.loc[:, 'Age': 'Purchased']

# print(selected_row)

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
## first we have to define X and y where X is the variable or feature input and y is the output target basically
x = selected_row[['Age', 'EstimatedSalary']]
# print(x) just to see the outcome
y = selected_row['Purchased']
# print(y)

## Split the Data
X_train, x_test, Y_train, y_test = train_test_split( x, y, train_size=0.8, random_state=48 )

X_train.shape, x_test.shape


# doing standardization
scaler = StandardScaler()

#fit the scaler to the train set, it will learn the parameter
scaler.fit(X_train)  ## learn mean and std from the train dataset
X_train_scaled = scaler.transform(X_train)  ## Apply sacling
X_test_scaler = scaler.transform(x_test) ## Apply same scaling on X_test as well

# scaler.mean_

X_train_scaled_df = pd.DataFrame(X_train_scaled, columns=X_train.columns)  #convert the numpy 2D arry to pd dataframes with column names on it as numpy array dont have column name after scaling
X_test_scaler_df = pd.DataFrame(X_test_scaler, columns=x_test.columns)     #convert the numpy 2D arry to pd dataframes with column names on it as numpy array dont have column name after scaling
print(X_train_scaled_df.describe())
print(X_train.describe())

sc = sc()
sr = sr()

# print(help(sr))

# print(help(sr.perform))
result = sr.perform(case=["linearR", "svr"], 
                    xy_train=[X_train_scaled_df, Y_train], 
                    xy_test=[X_test_scaler_df, y_test]
                    )

sns.scatterplot(result['svr']['predicted_value'])
# print(result['linearR']["mse"])

plt.show()

# print(df)