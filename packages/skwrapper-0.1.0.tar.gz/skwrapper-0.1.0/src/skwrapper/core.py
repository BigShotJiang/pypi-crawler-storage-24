from .Supervised.classificationModels import logistic, svc, randomForestClassifer, GBC, KNC, DTC
from .Supervised.regressionModels import linerR, RFR, GBR, svr, KNR, lasso, ridge, DTR

import logging
logger = logging.getLogger(__name__)

class supervised_classification:
    """
    Wrapper class for multiple sklearn classification models.
    See module docstring for usage examples.

    Supported Models
    ----------------
    "logistic": Logistic Classification,
    "svc": Support Vector Classification,
    "rfc": Random-Forest Classifer,
    "gbc": Gradient-Boosting Classifer,
    "knc": K-Nearest Neighbors Classifer,
    "dtc": Decision Tree Classifer
    """

    def __init__(self):
        self.operations = {
            "logistic": logistic,
            "svc": svc,
            "rfc": randomForestClassifer,
            "gbc": GBC,
            "knc": KNC,
            "dtc": DTC
        }
    
    def perform(self, case=None, xy_train = None, xy_test=None, show_pred:bool = False, **kwargs ):
        """
Classification Utilities
=========================

This module provides tools to execute and evaluate multiple classification models.
It supports models such as Logistic Regression, Support Vector Classifier (SVC),
Random Forest Classifier (RFC), K-Nearest Classifier (KNC), and others. The module
computes standard classification metrics and can optionally display predicted values.

To check supported models:
    >>> help(sc)

Classes
-------
sc
    Main class to run classification models. Use the `perform` method to execute selected models.

Methods
-------
sc.perform(case, xy_train, xy_test, show_pred=False, **kwargs)
    Run selected classification models and return predictions along with evaluation metrics.

Parameters
----------
case : list
    List of model names to execute, e.g., ["logistic", "svc", "rfc"].

    To check supported models:
    >>> help(sc)

xy_train : list
    Training dataset in the format [X_train, y_train].

xy_test : list
    Testing dataset in the format [X_test, y_test].

show_pred : bool, default=False
    If True, predicted values will be printed.
    If False, only evaluation metrics will be displayed.

**kwargs : dict
    Model-specific parameters passed to the underlying classification functions.

Returns
-------
dict
    Dictionary containing results for each executed model:
    - predicted_value
    - accuracy
    - confusion_matrix

Examples
--------
Single Model Execution:
>>> sc_instance.perform(
...     case=["logistic"],
...     xy_train=[X_train, y_train],
...     xy_test=[X_test, y_test],
...     show_pred=True
... )

Multiple Model Execution:
>>> sc_instance.perform(
...     case=["logistic", "svc", "knc"],
...     xy_train=[X_train, y_train],
...     xy_test=[X_test, y_test]
... )
"""
        
        if case is None or xy_train is None or xy_test is None :
            raise ValueError("case, xy_tarin and xy_test is required")
        if len(xy_train) != 2 or len(xy_test) != 2:
            raise ValueError("xy_train and xy_test must contain exactly 2 items")
        
        result = {}
        for operation in case:
            if operation in self.operations:
                try:
                    result[operation] = self.operations[operation](xy_train, xy_test, show_pred, **kwargs)
                except (ValueError, IndexError) as e:
                    logger.error("Operation '%s' failed: %s", operation, e)
                else:
                    raise ValueError(f"Model '{operation }' is not supported.")
        return result


class supervised_regression:
    """
    Wrapper class for multiple sklearn regression models.
    See module docstring for usage examples.

    Supported Models
    ----------------
    linearR :Linear Regression
    ridge  : Ridge Regression
    lasso  : Lasso Regression
    svr    : Support Vector Regression
    knr    : K-Nearest Neighbors Regressor
    gbr    : Gradient-Boosting Regressor
    rfr    : Random-Forest Regressor
    dtr    : Decision Tree Regressor
    """
    def __init__(self):
        # Each key is a model name, and the value is the corresponding function.
        self.operationss = {
            "linearR": linerR,
            "rfr": RFR,
            "gbr": GBR,
            "svr": svr,
            "knr": KNR,
            "lasso": lasso,
            "ridge": ridge,
            "dtr": DTR
        }
    
    def perform(self, case=None, xy_train=None, xy_test=None, show_pred:bool =False, **kwargs):
        """
Regression Utilities Module
===========================

This module provides tools to train and evaluate multiple regression models.
It supports linear regression, support vector regression, k-nearest neighbors regression,
and other models, with automatic computation of common regression metrics.

Classes
-------
sr
    Main class to run regression models. Use the `perform` method to execute selected models.

Methods
-------
sr.perform(case, xy_train, xy_test, show_pred=False, **kwargs)
    Runs the selected regression models and returns predictions
    along with evaluation metrics.

Parameters
----------
case : list
    List of model names to execute.
    Example: ["linearR", "svr"].

    To check supported models:
    >>> help(sr)

xy_train : list
    Training dataset in the format [X_train, y_train].

xy_test : list
    Testing dataset in the format [X_test, y_test].

show_pred : bool, default=False
    If True, predicted values will be printed.
    If False, only evaluation metrics will be printed.

**kwargs : dict
    Model-specific parameters that will be passed to the
    underlying regression model.

Returns
-------
dict
    Dictionary containing results for each executed model:
    - predicted_value
    - mse
    - mae
    - rmse
    - r2

Examples
--------
Single Model Execution
>>> sr_instance.perform(
...     case=["linearR"],
...     xy_train=[X_train, y_train],
...     xy_test=[X_test, y_test],
...     show_pred=True
... )

Multiple Model Execution
>>> sr_instance.perform(
...     case=["linearR", "svr", "knr"],
...     xy_train=[X_train, y_train],
...     xy_test=[X_test, y_test]
... )
"""
        
        if case is None or xy_train is None or xy_test is None :
            raise ValueError("case, xy_train, and xy_test are required")
        if len(xy_train) != 2 or len(xy_test) != 2:
            raise ValueError("xy_train and xy_test must contain exactly 2 items")
        result = {}
        for operation in case:
            if operation in self.operationss:
                try:
                    result[operation] = self.operationss[operation](xy_train, xy_test, show_pred, **kwargs)
                except (ValueError, IndexError) as e:
                    logger.error("Operation '%s' failed: %s", operation, e)
            else:
                raise ValueError(f"Model '{operation }' is not supported.")
        return result




