from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.metrics  import accuracy_score, classification_report, confusion_matrix

def logistic(xy_train, xy_test, show_pred:bool, **kwargs):
    if xy_test is None or xy_train is None:
        raise ValueError("xy_train and xy_test is required to perform Logistic Regression")
    x_train, y_train = xy_train
    x_test, y_test = xy_test


    #Model Parameters
    C: float = kwargs.get("C", 1.0)
    solver: str = kwargs.get("solver", "lbfgs")
    max_iter: int = kwargs.get("max_iter", 1000)
    fit_intercept: bool = kwargs.get("fit_intercept", True)
    class_weight = kwargs.get("class_weight", None)
    random_state = kwargs.get("random_state", 42)
    print("<------------------------Running LogisticRegression---------------------------------------->")

    model = LogisticRegression( C=C, solver=solver, max_iter=max_iter, fit_intercept=fit_intercept,
                            class_weight=class_weight,
                            random_state=random_state )
    model.fit(x_train, y_train)
    y_pred = model.predict(x_test)

    accuracy = accuracy_score(y_test, y_pred)
    cm = confusion_matrix(y_test, y_pred)

    metrics = {
        "predicted_value": y_pred,
        "accuracy": accuracy,
        "confusion_matrix": cm
    }

    for key, v in metrics.items():
        if key == "predicted_value" and show_pred != True:
            continue
        if( key == "predicted_value" ):
            print(f"{key}:\n {v}")
            print("-----------------metrics-----------------")        
    print(f"accuracy score for LogisticRegression:  {accuracy :.4f}")           
    print(f"Confusion_matrix:\n {cm}")
    print(classification_report(y_test, y_pred))

    return metrics

###################################################################################################################################
 
def randomForestClassifer(xy_train, xy_test, show_pred:bool, **kwargs):
    if xy_test is None or xy_train is None:
        raise ValueError("xy_train and xy_test is required to perform RandomForestClassifer")
    x_train, y_train = xy_train
    x_test, y_test = xy_test


    ##Modal Parameters
    n_estimators: int = kwargs.get("n_estimators", 100)
    max_depth: int = kwargs.get("max_depth", None)
    criterion: str = kwargs.get("criterion", "gini")
    class_weight = kwargs.get("class_weight", None)
    random_state = kwargs.get("random_state", 42)
    n_jobs: int = kwargs.get("n_jobs", -1)

    print("<-------------------------Running RandomForestClassifer------------------------------------->")
    
    model = RandomForestClassifier(n_estimators=n_estimators, max_depth=max_depth, criterion=criterion, 
                                class_weight=class_weight, random_state=random_state, n_jobs=n_jobs)
    model.fit(x_train, y_train)
    y_pred = model.predict(x_test)
    accuracy = accuracy_score(y_test, y_pred)
    cm = confusion_matrix(y_test, y_pred)

    metrics = {
        "predicted_value": y_pred,
        "accuracy": accuracy,
        "confusion_matrix": cm
    }

    for key, v in metrics.items():
        if key == "predicted_value" and show_pred != True:
            print(f"{key}:\n {v}")
            print("-----------------metrics-----------------")        
    print(f"accuracy score for LogisticRegression:  {accuracy :.4f}")           
    print(f"Confusion_matrix:\n {cm}")
    print(classification_report(y_test, y_pred))

    return metrics

######################################################################################################################################

def svc(xy_train, xy_test, show_pred:bool, **kwargs):
    if xy_test is None or xy_train is None:
        raise ValueError("xy_train and xy_test is required to perform SupportVectorClassifer")
    x_train, y_train = xy_train
    x_test, y_test = xy_test


    #Model Parameters
    kernel: str = kwargs.get("kernel", 'linear')
    C: int = kwargs.get("C", 1.0)
    random_state:int = kwargs.get("random_state", 0)
    probability: bool = kwargs.get("probability", False) 

    print("<-------------------------Running SupportVectorClassifer------------------------------------->")
    
    model = SVC( kernel=kernel, C=C, random_state=random_state, probability=probability )
    model.fit(x_train, y_train)
    y_pred = model.predict(x_test)
    accuracy = accuracy_score(y_test, y_pred)
    cm = confusion_matrix(y_test, y_pred)

    metrics = {
        "predicted_value": y_pred,
        "accuracy": accuracy,
        "confusion_matrix": cm
    }

    for key, v in metrics.items():
        if key == "predicted_value" and show_pred != True:
            print(f"{key}:\n {v}")
            print("-----------------metrics-----------------")        
    print(f"accuracy score for LogisticRegression:  {accuracy :.4f}")           
    print(f"Confusion_matrix:\n {cm}")
    print(classification_report(y_test, y_pred))

    return metrics

######################################################################################################################################

def GBC(xy_train, xy_test, show_pred:bool, **kwargs):
    if xy_test is None or xy_train is None:
        raise ValueError("xy_train and xy_test is required to perform GradientBoostingClassifier")
    x_train, y_train = xy_train
    x_test, y_test = xy_test


    #Model Parameters
    n_estimators: int = kwargs.get("n_estimators", 100)
    learning_rate: float = kwargs.get("learning_rate", 0.1)
    max_depth:int = kwargs.get("max_depth", 3)
    subsample: float = kwargs.get("subsample", 1.0)
    min_samples_split = kwargs.get("min_samples_split", 2)
    min_samples_leaf = kwargs.get("min_samples_leaf", 1)
    random_state: int = kwargs.get("random_state", None)

    print("<-------------------------Running GradientBoostingClassifier------------------------------------->")
    
    model = GradientBoostingClassifier(n_estimators= n_estimators, learning_rate= learning_rate, 
                                       max_depth= max_depth, subsample= subsample, 
                                       min_samples_split= min_samples_split, min_samples_leaf= min_samples_leaf, random_state= random_state )
    model.fit(x_train, y_train)
    y_pred = model.predict(x_test)
    accuracy = accuracy_score(y_test, y_pred)
    cm = confusion_matrix(y_test, y_pred)

    metrics = {
        "predicted_value": y_pred,
        "accuracy": accuracy,
        "confusion_matrix": cm
    }

    for key, v in metrics.items():
        if key == "predicted_value" and show_pred != True:
            print(f"{key}:\n {v}")
            print("-----------------metrics-----------------")        
    print(f"accuracy score for LogisticRegression:  {accuracy :.4f}")           
    print(f"Confusion_matrix:\n {cm}")
    print(classification_report(y_test, y_pred))

    return metrics

######################################################################################################################################

def KNC(xy_train, xy_test, show_pred:bool, **kwargs):
    if xy_test is None or xy_train is None:
        raise ValueError("xy_train and xy_test is required to perform KNeighborsClassifier")
    x_train, y_train = xy_train
    x_test, y_test = xy_test


    #Model Parameters
    n_neighbors: int = kwargs.get("n_neighbors", 5)
    weights : str = kwargs.get("weights", 'uniform')
    algorithm :int = kwargs.get("algorithm", 'auto')
    leaf_size: int = kwargs.get("leaf_size", 30)
    p: int = kwargs.get("p", 2)
    metric = kwargs.get("metric", 'minkowski')
    n_jobs: int = kwargs.get("n_jobs", None)

    print("<-------------------------Running KNeighborsClassifier------------------------------------->")
    
    model = KNeighborsClassifier( n_neighbors=n_neighbors, weights=weights, 
                                 algorithm=algorithm, leaf_size=leaf_size, p=p, 
                                 metric=metric, n_jobs=n_jobs )
    model.fit(x_train, y_train)
    y_pred = model.predict(x_test)
    accuracy = accuracy_score(y_test, y_pred)
    cm = confusion_matrix(y_test, y_pred)

    metrics = {
        "predicted_value": y_pred,
        "accuracy": accuracy,
        "confusion_matrix": cm
    }

    for key, v in metrics.items():
        if key == "predicted_value" and show_pred != True:
            print(f"{key}:\n {v}")
            print("-----------------metrics-----------------")        
    print(f"accuracy score for LogisticRegression:  {accuracy :.4f}")           
    print(f"Confusion_matrix:\n {cm}")
    print(classification_report(y_test, y_pred))

    return metrics

######################################################################################################################################

def DTC(xy_train, xy_test, show_pred:bool, **kwargs):
    if xy_test is None or xy_train is None:
        raise ValueError("xy_train and xy_test is required to perform KNeighborsClassifier")
    x_train, y_train = xy_train
    x_test, y_test = xy_test


    #Model Parameters
    criterion:str = kwargs.get("criterion", "gini")
    splitter: str = kwargs.get("splitter", "best")
    max_depth = kwargs.get("max_depth", None)
    min_samples_split = kwargs.get("min_samples_split", 2)
    min_samples_leaf = kwargs.get("min_samples_leaf", 1)
    max_features = kwargs.get("max_features", None)
    random_state: int = kwargs.get("random_state", None)

    print("<-------------------------Running DecisionTreeClassifier------------------------------------->")
    
    model = DecisionTreeClassifier(criterion=criterion, splitter=splitter, max_depth=max_depth,
                                   min_samples_split= min_samples_split, min_samples_leaf= min_samples_leaf, max_features= max_features,
                                    random_state=random_state )
    model.fit(x_train, y_train)
    y_pred = model.predict(x_test)
    accuracy = accuracy_score(y_test, y_pred)
    cm = confusion_matrix(y_test, y_pred)

    metrics = {
        "predicted_value": y_pred,
        "accuracy": accuracy,
        "confusion_matrix": cm
    }

    for key, v in metrics.items():
        if key == "predicted_value" and show_pred != True:
            print(f"{key}:\n {v}")
            print("-----------------metrics-----------------")        
    print(f"accuracy score for DecisionTreeClassifier:  {accuracy :.4f}")           
    print(f"Confusion_matrix:\n {cm}")
    print(classification_report(y_test, y_pred))

    return metrics


