from sklearn.linear_model import LinearRegression, Lasso, Ridge
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.neighbors import KNeighborsRegressor
from sklearn.tree import DecisionTreeRegressor
from sklearn.svm import SVR
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score, root_mean_squared_error

def linerR(xy_train, xy_test, show_pred:bool, **kwargs):
    if xy_train is None or xy_test is None:
        raise ValueError("xy_train & xy_test is needed")
    if len(xy_train) != 2 or len(xy_test) != 2:
        raise ValueError("xy_train and xy_test require 2 items x_train, y_train, x_test, y_test")
    
    x_train, y_train = xy_train
    x_test, y_test = xy_test

    ## Model Parameters
    fit_intercept=kwargs.get("fit_intercept", True)
    copy_X= kwargs.get("copy_x", True)
    positive= kwargs.get("positive",False)

    print("<------------------------Running LinearRegression---------------------------------------->")

    model = LinearRegression(fit_intercept=fit_intercept, copy_X=copy_X, positive=positive)
    model.fit(x_train, y_train)

    pred = model.predict(x_test)

    metrics = {
    "predicted_value": pred,
    "mse" : mean_squared_error(y_test, pred),
    "mae" : mean_absolute_error(y_test, pred),
    "rmse" : root_mean_squared_error(y_test, pred),
    "r2" : r2_score(y_test, pred),
    }
    for key, v in metrics.items():

        if key == "predicted_value" and show_pred != True:
            continue
        if key == "predicted_value":
            print(f"{key}:\n {v}")
            print("-----------------metrics-----------------")
        else:
            print(f"{key.upper()}: {v:.3f}")
    
    return metrics

###################################################################################################################################

def RFR(xy_train, xy_test, show_pred:bool, **kwargs):
    if xy_train is None or xy_test is None:
        raise ValueError("xy_train & xy_test is needed")
    if len(xy_train) != 2 or len(xy_test) != 2:
        raise ValueError("xy_train and xy_test require 2 items x_train, y_train, x_test, y_test")
    
    x_train, y_train = xy_train
    x_test, y_test = xy_test

    ## Model Parameters
    n_estimators = kwargs.get("n_esti", 100)
    max_depth = kwargs.get("max_d", None)
    min_samples_split = kwargs.get("min_samples_split", 2)
    min_samples_leaf = kwargs.get("min_samples_leaf", 1)
    random_state = kwargs.get("random_state", None)

    print("<------------------------Running RandomForestRegressor---------------------------------------->")

    model = RandomForestRegressor(n_estimators= n_estimators, max_depth= max_depth, 
                                  min_samples_split= min_samples_split, min_samples_leaf= min_samples_leaf, 
                                  random_state= random_state )
    model.fit(x_train, y_train)

    pred = model.predict(x_test)

    metrics = {
    "predicted_value": pred,
    "mse" : mean_squared_error(y_test, pred),
    "mae" : mean_absolute_error(y_test, pred),
    "rmse" : root_mean_squared_error(y_test, pred),
    "r2" : r2_score(y_test, pred),
    }
    for key, v in metrics.items():
        if key == "predicted_value" and show_pred != True:
            continue
        if key == "predicted_value":
            print(f"{key}:\n {v}")
            print("-----------------metrics-----------------")
        else:
            print(f"{key.upper()}: {v:.3f}")
    
    return metrics

###################################################################################################################################

def GBR(xy_train, xy_test, show_pred:bool, **kwargs):
    if xy_train is None or xy_test is None:
        raise ValueError("xy_train & xy_test is needed")
    if len(xy_train) != 2 or len(xy_test) != 2:
        raise ValueError("xy_train and xy_test require 2 items x_train, y_train, x_test, y_test")
    
    x_train, y_train = xy_train
    x_test, y_test = xy_test

    ## Model Parameters
    n_estimators: int = kwargs.get("n_esti", 100)
    learning_rate: float = kwargs.get("l_r", 0.1)
    max_depth:int = kwargs.get("max_d", 3)
    subsample: float = kwargs.get("subsample", 1.0)
    min_samples_split = kwargs.get("min_samples_split", 2)
    min_samples_leaf = kwargs.get("min_samples_leaf", 1)
    loss = kwargs.get("loss", "squared_error")
    random_state: int = kwargs.get("random_state", None)

    print("<------------------------Running GradientBoostingRegressor---------------------------------------->")

    model = GradientBoostingRegressor(n_estimators= n_estimators, max_depth= max_depth, 
                                  min_samples_split= min_samples_split, min_samples_leaf= min_samples_leaf, 
                                  random_state=random_state, subsample=subsample, learning_rate=learning_rate, loss=loss)
    model.fit(x_train, y_train)

    pred = model.predict(x_test)

    metrics = {
    "predicted_value": pred,
    "mse" : mean_squared_error(y_test, pred),
    "mae" : mean_absolute_error(y_test, pred),
    "rmse" : root_mean_squared_error(y_test, pred),
    "r2" : r2_score(y_test, pred),
    }
    for key, v in metrics.items():
        if key == "predicted_value" and show_pred != True:
            continue
        if key == "predicted_value":
            print(f"{key}:\n {v}")
            print("-----------------metrics-----------------")
        else:
            print(f"{key.upper()}: {v:.3f}")
    
    return metrics

###################################################################################################################################

def KNR(xy_train, xy_test, show_pred:bool, **kwargs):
    if xy_train is None or xy_test is None:
        raise ValueError("xy_train & xy_test is needed")
    if len(xy_train) != 2 or len(xy_test) != 2:
        raise ValueError("xy_train and xy_test require 2 items x_train, y_train, x_test, y_test")
    
    x_train, y_train = xy_train
    x_test, y_test = xy_test

    ## Model Parameters
    n_neighbors: int = kwargs.get("n_neighbors", 5)
    weights : str = kwargs.get("weights", 'uniform')
    algorithm :int = kwargs.get("algorithm", 'auto')
    leaf_size: int = kwargs.get("leaf_size", 30)
    p: int = kwargs.get("p", 2)
    metric = kwargs.get("metric", 'minkowski')
    n_jobs: int = kwargs.get("n_jobs", None)

    print("<------------------------Running KNeighborsRegressor---------------------------------------->")

    model = KNeighborsRegressor( n_neighbors=n_neighbors, weights=weights, 
                                 algorithm=algorithm, leaf_size=leaf_size, p= p, 
                                 metric=metric, n_jobs= n_jobs )
    model.fit(x_train, y_train)

    pred = model.predict(x_test)

    metrics = {
    "predicted_value": pred,
    "mse" : mean_squared_error(y_test, pred),
    "mae" : mean_absolute_error(y_test, pred),
    "rmse" : root_mean_squared_error(y_test, pred),
    "r2" : r2_score(y_test, pred),
    }
    for key, v in metrics.items():
        if key == "predicted_value" and show_pred != True:
            continue
        if key == "predicted_value":
            print(f"{key}:\n {v}")
            print("-----------------metrics-----------------")
        else:
            print(f"{key.upper()}: {v:.3f}")
    
    return metrics

###################################################################################################################################

def svr(xy_train, xy_test, show_pred:bool, **kwargs):
    if xy_train is None or xy_test is None:
        raise ValueError("xy_train & xy_test is needed")
    if len(xy_train) != 2 or len(xy_test) != 2:
        raise ValueError("xy_train and xy_test require 2 items x_train, y_train, x_test, y_test")
    
    x_train, y_train = xy_train
    x_test, y_test = xy_test

    ## Model Parameters
    kernel: str = kwargs.get("kernel", "rbf")
    C: float = kwargs.get("C", 1.0)
    epsilon: float = kwargs.get("epsilon", 0.1)
    gamma = kwargs.get("gamma", "scale")

    print("<------------------------Running SupportVectorRegression.---------------------------------------->")

    model = SVR( kernel=kernel, C=C, epsilon=epsilon, gamma=gamma, )
    model.fit(x_train, y_train)

    pred = model.predict(x_test)

    metrics = {
    "predicted_value": pred,
    "mse" : mean_squared_error(y_test, pred),
    "mae" : mean_absolute_error(y_test, pred),
    "rmse" : root_mean_squared_error(y_test, pred),
    "r2" : r2_score(y_test, pred),
    }
    for key, v in metrics.items():
        if key == "predicted_value" and show_pred != True:
            continue
        if key == "predicted_value":
            print(f"{key}:\n {v}")
            print("-----------------metrics-----------------")
        else:
            print(f"{key.upper()}: {v:.3f}")
    
    return metrics

###################################################################################################################################

def lasso(xy_train, xy_test, show_pred:bool, **kwargs):
    if xy_train is None or xy_test is None:
        raise ValueError("xy_train & xy_test is needed")
    if len(xy_train) != 2 or len(xy_test) != 2:
        raise ValueError("xy_train and xy_test require 2 items x_train, y_train, x_test, y_test")
    
    x_train, y_train = xy_train
    x_test, y_test = xy_test

    ## Model Parameters
    alpha: float = kwargs.get("alpha", 1.0)
    fit_intercept: bool = kwargs.get("fit_intercept", True)
    max_iter: int = kwargs.get("max_iter", 1000)


    print("<------------------------Running Lasso Regression.---------------------------------------->")

    model = Lasso( max_iter=max_iter, fit_intercept=fit_intercept, alpha=alpha )
    model.fit(x_train, y_train)

    pred = model.predict(x_test)

    metrics = {
    "predicted_value": pred,
    "mse" : mean_squared_error(y_test, pred),
    "mae" : mean_absolute_error(y_test, pred),
    "rmse" : root_mean_squared_error(y_test, pred),
    "r2" : r2_score(y_test, pred),
    }
    for key, v in metrics.items():
        if key == "predicted_value" and show_pred != True:
            continue
        if key == "predicted_value":
            print(f"{key}:\n {v}")
            print("-----------------metrics-----------------")
        else:
            print(f"{key.upper()}: {v:.3f}")
    
    return metrics

###################################################################################################################################

def ridge(xy_train, xy_test, show_pred:bool, **kwargs):
    if xy_train is None or xy_test is None:
        raise ValueError("xy_train & xy_test is needed")
    if len(xy_train) != 2 or len(xy_test) != 2:
        raise ValueError("xy_train and xy_test require 2 items x_train, y_train, x_test, y_test")
    
    x_train, y_train = xy_train
    x_test, y_test = xy_test

    ## Model Parameters
    alpha: float = kwargs.get("alpha", 1.0)
    fit_intercept: bool = kwargs.get("fit_intercept", True)
    solver: str = kwargs.get("solver", "auto")


    print("<------------------------Running Ridge Regression.---------------------------------------->")

    model = Ridge( solver=solver, fit_intercept=fit_intercept, alpha=alpha )
    model.fit(x_train, y_train)

    pred = model.predict(x_test)

    metrics = {
    "predicted_value": pred,
    "mse" : mean_squared_error(y_test, pred),
    "mae" : mean_absolute_error(y_test, pred),
    "rmse" : root_mean_squared_error(y_test, pred),
    "r2" : r2_score(y_test, pred),
    }
    for key, v in metrics.items():
        if key == "predicted_value" and show_pred != True:
            continue
        if key == "predicted_value":
            print(f"{key}:\n {v}")
            print("-----------------metrics-----------------")
        else:
            print(f"{key.upper()}: {v:.3f}")
    
    return metrics

###################################################################################################################################

def DTR(xy_train, xy_test, show_pred:bool, **kwargs):
    if xy_train is None or xy_test is None:
        raise ValueError("xy_train & xy_test is needed")
    if len(xy_train) != 2 or len(xy_test) != 2:
        raise ValueError("xy_train and xy_test require 2 items x_train, y_train, x_test, y_test")
    
    x_train, y_train = xy_train
    x_test, y_test = xy_test

    ## Model Parameters
    criterion = kwargs.get("criterion", "squared_error")
    splitter = kwargs.get("splitter", "best")
    max_depth = kwargs.get("max_depth", None)
    min_samples_split = kwargs.get("min_samples_split", 2)
    min_samples_leaf = kwargs.get("min_samples_leaf", 1)
    max_features = kwargs.get("max_features", None)
    random_state = kwargs.get("random_state", None)


    print("<------------------------Running DecisionTreeRegressor.---------------------------------------->")

    model = DecisionTreeRegressor( criterion=criterion, splitter=splitter, max_depth=max_depth,
                                min_samples_split= min_samples_split, min_samples_leaf= min_samples_leaf, max_features= max_features,
                                random_state=random_state )
    model.fit(x_train, y_train)

    pred = model.predict(x_test)

    metrics = {        
    "predicted_value": pred,
    "mse" : mean_squared_error(y_test, pred),
    "mae" : mean_absolute_error(y_test, pred),
    "rmse" : root_mean_squared_error(y_test, pred),
    "r2" : r2_score(y_test, pred),
    }
    for key, v in metrics.items():
        if key == "predicted_value" and show_pred != True:
            continue
        if key == "predicted_value":
            print(f"{key}:\n {v}")
            print("-----------------metrics-----------------")
        else:
            print(f"{key.upper()}: {v:.3f}")
    
    return metrics

###################################################################################################################################

