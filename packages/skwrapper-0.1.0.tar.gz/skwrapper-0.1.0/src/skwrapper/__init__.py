from .core import supervised_classification as sc, supervised_regression as sr

__all__ = ["sc", "sr"]

