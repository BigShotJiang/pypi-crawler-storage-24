# **skwrapper**
This package helps the Data Scientist to train there model on dataset with different models without copy pasting the code again and again, this package is a Sklearn wrapper which does performs the model training. this saves time of developer and it also helps with detail metrics and for quick scan which model best fits for dataset

## Features
- Supports regression and classifications models
- Computes common regression and classificatons metrics.
- Optional display of predicted values.
- Easy-to-use unified interface for training and evaluation.

---

## Installation
```bash```

---

## **Usage Example**
```python
## Import class from Library
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from skwrapper import sc, sr

df = pd.read_csv("Social_Network_Ads.csv")

selected_row = df.loc[:, 'Age': 'Purchased']

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
# first we have to define X and y where X is the variable or feature input and y is the output target basically
x = selected_row[['Age', 'EstimatedSalary']]
y = selected_row['Purchased']

## Split the Data
X_train, x_test, Y_train, y_test = train_test_split( x, y, train_size=0.8, random_state=48 )

X_train.shape, x_test.shape


# doing standardization
scaler = StandardScaler()

#fit the scaler to the train set, it will learn the parameter
scaler.fit(X_train)  ## learn mean and std from the train dataset
X_train_scaled = scaler.transform(X_train)  ## Apply sacling
X_test_scaler = scaler.transform(x_test) ## Apply same scaling on X_test as well

#convert the numpy 2D arry to pd dataframes with column names on it as numpy array dont have column name after scaling
X_train_scaled_df = pd.DataFrame(X_train_scaled, columns=X_train.columns)  
X_test_scaler_df = pd.DataFrame(X_test_scaler, columns=x_test.columns) 

print(X_train_scaled_df.describe())
print(X_train.describe())


# Initialize class
sc = sc() ## Supervised Classifications class
sr = sr() ## Supervised Regression class

# Train and evaluate Models
|
## Single Model Execution for sr(Supervised Classification Models)
sc.perform(
    case=["logistic"],
    xy_train=[X_train_scaled_df, y_train],
    xy_test=[X_test_scaler_df, y_test],

    ## Optional Parameter
    show_pred=True # If True, predicted_values will be printed. If False, only evaluation metrics will be displayed.
)

## Multiple Model Execution for sr(Supervised Regression Models)
result = sc.perform(
    case=[" logistic", "svc", "knc"],
    xy_train=[X_train_scaled_df, y_train],
    xy_test=[X_test_scaler_df, y_test],

    ## Optional Parameter
    show_pred=True # If True, predicted_values will be printed. If False, only evaluation metrics will be displayed.
)

#----------------and for Supervised Regression Models-------------------#
## Single Model Execution:
sr.perform(
    case=["linearR"],
    xy_train=[X_train, y_train],
    xy_test=[X_test, y_test],

    #Optional Parameter
    show_pred=True # If True, predicted_values will be printed. If False, only evaluation metrics will be displayed.
)

## Multiple Model Execution:
sr.perform(
    case=["linearR", "svr", "knr"],
    xy_train=[X_train, y_train],
    xy_test=[X_test, y_test]
)

print(result) ## This will print all the metrics for all defiend models in **case**

# Access specific model metrics or predection value
print("MSE for Linear Regression:", results["linearR"]["mse"])
print("predicted_value for SVR:", results["svr"]["predicted_value"])

## You Can Plot the predicted Values
sns.scatterplot(result['svr']['predicted_value'])
plt.show()

```
---

## **Supported Models**
- **Wrapper class for multiple sklearn regression models.**:

| Model | Description |
|-------|-------------|
| linearR | Linear Regression |
| ridge  | Ridge Regression |
| lasso  | Lasso Regression |
| svr    | Support Vector Regression |
| knr    | K-Nearest Neighbors Regressor |
| gbr    | Gradient Boosting Regressor |
| rfr    | Random Forest Regressor |
| dtr    | Decision Tree Regressor |

## **Metrics**
- **metrics computed automatically**:

```markdown
- Mean Squared Error (MSE)
- Mean Absolute Error (MAE)
- Root Mean Squared Error (RMSE)
- R² Score
```

---

- **Wrapper class for multiple sklearn Classifications models.**:

| Model | Description |
|-------|-------------|
| logistic | Logistic Regression Classifier |
| svc      | Support Vector Classifier (SVC) |
| rfc      | Random Forest Classifier |
| gbc      | Gradient Boosting Classifier |
| knc      | K-Nearest Neighbors Classifier |
| dtc      | Decision Tree Classifier |

## **Metrics**
- **metrics computed automatically**:

```markdown
- accuracy
- confusion_matrix
- classification_report
```
---




