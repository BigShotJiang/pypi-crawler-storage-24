"""
BSS Skill: Content Router
Reads the TYPE/CONFIDENCE/WORDS header written by type-classifier and applies
a type-specific extraction strategy to produce a compact, LLM-ready summary.
Falls back to generic truncation for unknown types.
"""
import re

text = PROMPT  # noqa: F821

# ── Parse header ──────────────────────────────────────────────────────────────
header_match = re.match(
    r"TYPE:(\w+)\nCONFIDENCE:(\d+)\nWORDS:(\d+)\n---\n(.*)",
    text,
    re.DOTALL,
)
if header_match:
    doc_type = header_match.group(1)
    content = header_match.group(4)
else:
    doc_type = "document"
    content = text

# ── Type-specific routing ─────────────────────────────────────────────────────

if doc_type == "invoice":
    amounts = re.findall(r"[\$€£¥]?\s*[\d,]+\.?\d*", content)
    amounts = [a.strip() for a in amounts if re.search(r"\d{2,}", a)][:10]
    lines = [l.strip() for l in content.splitlines() if l.strip()][:20]
    print("[INVOICE SUMMARY]")
    for line in lines[:15]:
        print(line)
    if amounts:
        print(f"Key figures: {', '.join(amounts[:8])}")

elif doc_type == "contract":
    headings = re.findall(r"(?m)^\s*(?:\d+[\.\)]|[A-Z]{2,})\s+[A-Z][A-Za-z ]{3,40}", content)
    print(f"[CONTRACT — {len(headings)} sections]")
    for h in headings[:12]:
        print(f"  {h.strip()}")
    print(content[:800])

elif doc_type == "report":
    # Keep section headings + first sentence of each paragraph
    paras = re.split(r"\n{2,}", content)
    print("[REPORT SUMMARY]")
    for para in paras[:8]:
        first_sentence = re.split(r"(?<=[.!?])\s+", para.strip())[0]
        print(f"  {first_sentence[:120]}")

elif doc_type == "email":
    print("[EMAIL SUMMARY]")
    lines = [l.strip() for l in content.splitlines() if l.strip()]
    # Keep subject, from, to and first/last paragraphs
    header_lines = [l for l in lines if re.match(r"(subject|from|to|cc|date):", l, re.IGNORECASE)]
    body_lines = [l for l in lines if l not in header_lines]
    for l in header_lines[:4]:
        print(l)
    if body_lines:
        print("Body preview:")
        print("  " + body_lines[0][:200])
        if len(body_lines) > 1:
            print("  " + body_lines[-1][:200])

elif doc_type == "code":
    sigs = re.findall(r"(?:def|function|class|async def|public\s+\w+)\s+\w+[^{;\n]*", content)
    print(f"[CODE — {len(sigs)} definitions]")
    for sig in sigs[:15]:
        print(f"  {sig.strip()[:80]}")
    print(content[:600])

else:
    print(f"[{doc_type.upper()} SUMMARY]")
    print(content[:1000])
