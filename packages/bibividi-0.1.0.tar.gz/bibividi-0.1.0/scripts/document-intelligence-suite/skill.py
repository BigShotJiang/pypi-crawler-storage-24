"""
BSS Skill: Document Intelligence Suite — chain finalizer
Receives the content-router summary and trims it to a guaranteed compact output.
Adds a processing header so the LLM knows the document was pre-processed.
"""
import textwrap

# PROMPT is the routed summary produced by content-router (last dep step).
summary = PROMPT.strip()  # noqa: F821

MAX_CHARS = 1200

if len(summary) > MAX_CHARS:
    summary = textwrap.shorten(summary, width=MAX_CHARS, placeholder=" [trimmed]")

print("[BIBIVIDI: document pre-processed]")
print(summary)
