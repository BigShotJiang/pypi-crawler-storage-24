"""
BSS Skill: Complexity Scorer
Reads diff-parser output and computes a 0–10 complexity score based on
change size, file spread, and structural signals. Appends score + flags
to the structured diff summary for review-formatter.
"""
import re

text = PROMPT  # noqa: F821

files_changed = 0
additions = 0
deletions = 0
hunks = 0
functions: list = []
diff_format = "unified"

for line in text.splitlines():
    stripped = line.strip()
    if stripped.startswith("DIFF_FORMAT:"):
        diff_format = stripped.split(":", 1)[1].strip()
    elif stripped.startswith("FILES_CHANGED:"):
        try:
            files_changed = int(stripped.split(":", 1)[1].strip())
        except ValueError:
            pass
    elif stripped.startswith("STATS:"):
        m = re.search(r"\+(\d+) -(\d+) lines in (\d+)", stripped)
        if m:
            additions, deletions, hunks = int(m.group(1)), int(m.group(2)), int(m.group(3))
    elif stripped.startswith("FUNCTIONS:"):
        pass
    elif line.startswith("  ") and re.match(r"  [+\-]", line):
        functions.append(stripped[:60])

total_changes = additions + deletions

# ── Scoring ───────────────────────────────────────────────────────────────────
# Size: 0–5 points (0 = <50 lines, 5 = 500+ lines)
size_score = min(5, total_changes // 100)
# Spread: 0–3 points (0 = 1 file, 3 = 10+ files)
spread_score = min(3, files_changed // 3)
# Hunk density: 0–2 points
hunk_score = min(2, hunks // 5)

complexity = size_score + spread_score + hunk_score  # 0–10

# ── Flags ─────────────────────────────────────────────────────────────────────
flags: list = []
if total_changes > 500:
    flags.append("LARGE_DIFF")
if files_changed > 10:
    flags.append("WIDE_SPREAD")
if deletions > additions * 1.5:
    flags.append("MOSTLY_DELETIONS")
if additions > deletions * 3 and total_changes > 200:
    flags.append("HEAVY_ADDITION")

func_ids = [f.lower() for f in functions]
has_tests = any("test" in f or "spec" in f for f in func_ids)
if has_tests:
    flags.append("HAS_TESTS")
elif total_changes > 50 and diff_format == "unified":
    flags.append("NO_TESTS_DETECTED")

# ── Output ────────────────────────────────────────────────────────────────────
print(text)
print(f"COMPLEXITY:{complexity}/10")
print(f"FLAGS:{', '.join(flags) if flags else 'NONE'}")
