"""
BSS Skill: Review Formatter
Reads complexity-scorer output (diff-parser → complexity-scorer → this) and
formats a structured code-review brief: risk level, scope, attention flags,
key changes, and an actionable checklist. Target: ~150 tokens.
"""
import re

text = PROMPT  # noqa: F821

files_changed = 0
additions = 0
deletions = 0
complexity = 0
flags: list = []
functions: list = []

for line in text.splitlines():
    stripped = line.strip()
    if stripped.startswith("FILES_CHANGED:"):
        try:
            files_changed = int(stripped.split(":", 1)[1].strip())
        except ValueError:
            pass
    elif stripped.startswith("STATS:"):
        m = re.search(r"\+(\d+) -(\d+)", stripped)
        if m:
            additions, deletions = int(m.group(1)), int(m.group(2))
    elif stripped.startswith("COMPLEXITY:"):
        m = re.search(r"(\d+)", stripped)
        if m:
            complexity = int(m.group(1))
    elif stripped.startswith("FLAGS:"):
        raw = stripped.split(":", 1)[1].strip()
        flags = [f.strip() for f in raw.split(",") if f.strip() and f.strip() != "NONE"]
    elif line.startswith("  ") and re.match(r"  [+\-]", line):
        functions.append(stripped[:70])

# ── Risk level ────────────────────────────────────────────────────────────────
risk = "HIGH" if complexity >= 7 else "MEDIUM" if complexity >= 4 else "LOW"

# ── Checklist ─────────────────────────────────────────────────────────────────
checklist: list = []
if "NO_TESTS_DETECTED" in flags:
    checklist.append("Add/update tests for changed logic")
if "LARGE_DIFF" in flags:
    checklist.append("Consider splitting into smaller PRs")
if "WIDE_SPREAD" in flags:
    checklist.append("Review cross-module impact carefully")
if risk == "HIGH":
    checklist.append("Requires senior review before merge")
if "MOSTLY_DELETIONS" in flags:
    checklist.append("Verify no functionality was accidentally removed")

# ── Output ────────────────────────────────────────────────────────────────────
print("=== CODE REVIEW BRIEF ===")
print(f"RISK:{risk} | COMPLEXITY:{complexity}/10")
print(f"SCOPE:{files_changed} file(s) +{additions}/-{deletions} lines")
if flags:
    print(f"ATTENTION:{', '.join(flags[:5])}")
if functions:
    print("KEY CHANGES:")
    for f in functions[:5]:
        print(f"  {f}")
if checklist:
    print("CHECKLIST:")
    for item in checklist:
        print(f"  [{' ' if item else 'x'}] {item}")
print("=== END REVIEW ===")
