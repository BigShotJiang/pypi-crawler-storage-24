"""
BSS Skill: Totals Summariser
Reads the validated invoice output (invoice-parser → line-validator) and
collapses it to a ~200-token financial summary: invoice ID, vendor, total,
validation status, and any flags.
"""
import re

text = PROMPT  # noqa: F821

invoice_line = ""
total_line = ""
validation_status = "UNKNOWN"
flags = []
context = ""
currency = ""

for line in text.splitlines():
    stripped = line.strip()
    if stripped.startswith("INVOICE:"):
        invoice_line = stripped
        cur_match = re.search(r"CURRENCY:([A-Z€$£¥]+)", stripped)
        if cur_match:
            currency = cur_match.group(1)
    elif stripped.startswith("TOTAL:"):
        total_line = stripped
    elif stripped.startswith("VALIDATION:"):
        validation_status = stripped.split(":", 1)[1].strip()
    elif stripped.startswith("FLAG:"):
        flags.append(stripped[5:].strip())
    elif stripped.startswith("CONTEXT:"):
        context = stripped[8:].strip()[:150]

# ── Compact summary ────────────────────────────────────────────────────────────
print("=== FINANCIAL SUMMARY ===")
if invoice_line:
    # Strip CURRENCY field from the display line for brevity
    display = re.sub(r"\s*\|\s*CURRENCY:[A-Z€$£¥]+", "", invoice_line)
    print(display)
else:
    print("INVOICE: unknown")

if total_line:
    total_val = total_line.split(":", 1)[1].strip()
    print(f"TOTAL: {currency}{total_val}" if currency and currency not in total_val else total_line)
else:
    print("TOTAL: unknown")

print(f"STATUS: {'VALIDATED' if validation_status == 'PASS' else 'NEEDS_REVIEW'}")

if flags:
    print(f"FLAGS({len(flags)}):")
    for f in flags[:3]:
        print(f"  {f}")

if context:
    print(f"REQUEST: {context}")

print("=== END ===")
