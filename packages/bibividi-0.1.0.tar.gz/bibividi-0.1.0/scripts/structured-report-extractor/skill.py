"""
BSS Skill: Structured Report Extractor
Scans a business/financial report for KPIs, monetary amounts, percentages,
dates, and named sections — outputs a compact structured summary.
"""
import re
import collections

text = PROMPT

# ── Extract monetary amounts ──────────────────────────────────────────────────
# e.g. €1.2M, $450K, 3 200 000 €, USD 12,500
money_pattern = (
    r"(?:"
    r"[€$£¥]\s*[\d\s,.']+(?:[KkMmBbGg](?:il(?:lion)?s?)?)?"
    r"|[\d\s,.']+\s*(?:[KkMmBbGg](?:il(?:lion)?s?)?)?\s*(?:EUR|USD|GBP|€|\$|£)"
    r"|[\d\s,.']+\s*(?:million|milliard|billion|thousand|k)\s*(?:EUR|USD|GBP|€|\$|£)?"
    r")"
)
amounts = re.findall(money_pattern, text)
amounts = [a.strip() for a in amounts if re.search(r'\d', a)][:20]

# ── Extract percentages ───────────────────────────────────────────────────────
pct_contexts = re.findall(r"([^\n.]{0,50}[-+]?\d+[.,]\d*\s*%[^\n.]{0,50})", text)
pct_contexts = [p.strip() for p in pct_contexts][:15]

# ── Extract dates and periods ─────────────────────────────────────────────────
dates = re.findall(
    r"\b(?:"
    r"Q[1-4]\s*\d{4}"
    r"|(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?"
    r"|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)"
    r"\s*\d{4}"
    r"|\d{4}(?:[-/]\d{2}){0,2}"
    r"|H[12]\s*\d{4}"
    r"|FY\s*\d{2,4}"
    r")\b",
    text, re.IGNORECASE
)
dates = list(dict.fromkeys(dates))[:10]  # deduplicate, preserve order

# ── Extract section headers / KPI labels ─────────────────────────────────────
headers = re.findall(r"^#+\s*(.+)|^([A-Z][A-Z\s]{4,40})\s*$|^([A-Z].{3,50})\s*:", text, re.MULTILINE)
section_names = []
for h in headers:
    name = next((s.strip() for s in h if s.strip()), None)
    if name:
        section_names.append(name)
section_names = list(dict.fromkeys(section_names))[:12]

# ── Extract key sentences (those containing numbers + context words) ──────────
key_sentences = []
sentences = re.split(r"(?<=[.!?])\s+", text)
score_words = re.compile(
    r"\b(revenue|chiffre|profit|loss|growth|croissance|decline|baisse|increase|"
    r"augmentation|target|objectif|forecast|prévision|budget|actual|réel|"
    r"margin|marge|cost|coût|sales|vente|client|user|employee)\b",
    re.IGNORECASE
)
for sent in sentences:
    if re.search(r"\d", sent) and score_words.search(sent):
        key_sentences.append(sent.strip())
    if len(key_sentences) >= 10:
        break

# ── Extract user instructions from the prompt ─────────────────────────────────
# Remove the report body, keep only the question/task at the end
task_match = re.search(
    r"(?:analyse|analyze|summarize|résume|résumez|explain|explique|comment|"
    r"que penses|what do you|can you|pouvez.vous)[^\n.?]{0,200}[.?]?",
    text, re.IGNORECASE
)
task = task_match.group(0).strip() if task_match else ""

# ── Output ────────────────────────────────────────────────────────────────────
print("=== BIBIVIDI REPORT SUMMARY ===")

if dates:
    print(f"Periods: {', '.join(dates)}")

if section_names:
    print(f"Sections: {', '.join(section_names[:8])}")

if amounts:
    print(f"\nKey figures:")
    for a in amounts[:10]:
        print(f"  • {a}")

if pct_contexts:
    print(f"\nPercentages in context:")
    for p in pct_contexts[:8]:
        print(f"  • {p}")

if key_sentences:
    print(f"\nKey statements:")
    for s in key_sentences[:6]:
        clean = re.sub(r'\s+', ' ', s)
        print(f"  — {clean[:160]}")

if task:
    print(f"\nUser request: {task}")

print(f"\n(Extracted from {len(text)} chars — original report condensed by BIBIVIDI)")
print("=== END REPORT SUMMARY ===")
