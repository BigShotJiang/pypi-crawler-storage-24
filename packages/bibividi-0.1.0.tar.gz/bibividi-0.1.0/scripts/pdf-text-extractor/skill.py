"""
BSS Skill: PDF Text Extractor
Strips markup, code fences, excessive whitespace, and boilerplate from document prompts.
Outputs clean, normalised text for downstream classifiers and summarisers.
"""
import re

text = PROMPT  # noqa: F821

# Strip code fences while keeping their content
text = re.sub(r'```[a-zA-Z]*\n', '', text)
text = re.sub(r'```', '', text)

# Remove inline HTML tags
text = re.sub(r'<[^>]{1,80}>', ' ', text)

# Remove Markdown headings markers (keep the text)
text = re.sub(r'^#{1,6}\s+', '', text, flags=re.MULTILINE)

# Collapse page headers / footers (lines that are just a number or dashes)
text = re.sub(r'(?m)^\s*[\-_]{3,}\s*$', '', text)
text = re.sub(r'(?m)^\s*\d{1,4}\s*$', '', text)

# Collapse excessive whitespace
text = re.sub(r'[ \t]{2,}', ' ', text)
text = re.sub(r'\n{3,}', '\n\n', text)

# Truncate to 4 000 chars — enough context for downstream steps
output = text.strip()[:4000]
print(output)
