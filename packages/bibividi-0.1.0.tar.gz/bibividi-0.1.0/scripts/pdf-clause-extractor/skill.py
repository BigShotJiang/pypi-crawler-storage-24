"""
BSS Skill: PDF Clause Extractor
Reads a contract/document text from PROMPT, extracts key clauses,
and outputs a structured summary (dramatically reducing token count).
"""
import re
import json

# PROMPT is injected by the BIBIVIDI sandbox wrapper
text = PROMPT

# ── Heuristic clause extraction ───────────────────────────────────────────────
CLAUSE_PATTERNS = [
    (r"(?i)(termination|cancellation)[^\n]{0,300}", "Termination"),
    (r"(?i)(payment|invoice|fee)[^\n]{0,300}", "Payment"),
    (r"(?i)(confidential|non.disclosure|nda)[^\n]{0,300}", "Confidentiality"),
    (r"(?i)(liability|indemnif)[^\n]{0,300}", "Liability"),
    (r"(?i)(intellectual property|ip rights|copyright)[^\n]{0,300}", "IP Rights"),
    (r"(?i)(governing law|jurisdiction)[^\n]{0,300}", "Governing Law"),
    (r"(?i)(force majeure)[^\n]{0,300}", "Force Majeure"),
    (r"(?i)(warranty|warrants)[^\n]{0,300}", "Warranty"),
]

clauses = {}
for pattern, label in CLAUSE_PATTERNS:
    matches = re.findall(pattern, text)
    if matches:
        # Take first match, truncate to 200 chars
        clauses[label] = matches[0][:200].strip()

# ── Output ────────────────────────────────────────────────────────────────────
if clauses:
    print("=== BIBIVIDI EXTRACTED CLAUSES ===")
    for label, excerpt in clauses.items():
        print(f"\n[{label}]\n{excerpt}")
    print(f"\n=== END (extracted {len(clauses)} clauses from {len(text)} chars) ===")
else:
    # No clauses found — output original text truncated
    print(text[:500])
