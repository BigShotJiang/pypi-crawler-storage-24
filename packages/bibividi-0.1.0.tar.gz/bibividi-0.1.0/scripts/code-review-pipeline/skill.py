"""
BSS Skill: Code Review Pipeline — chain finalizer
Receives the review-formatter brief and strips the outer === delimiters so
the LLM receives clean structured data without redundant wrapper lines.
"""
# PROMPT is the review-formatter output.
lines = PROMPT.strip().split("\n")  # noqa: F821

# Strip === CODE REVIEW BRIEF === header and === END REVIEW === footer
if lines and lines[0].strip() == "=== CODE REVIEW BRIEF ===":
    lines = lines[1:]
if lines and lines[-1].strip() == "=== END REVIEW ===":
    lines = lines[:-1]

output = "\n".join(lines).strip()

# Hard cap: 600 chars keeps it under 150 tokens
if len(output) > 600:
    output = output[:600].rsplit("\n", 1)[0]

print("[BIBIVIDI: diff pre-processed]")
print(output)
