"""
BSS Skill: Type Classifier
Classifies the document type (invoice, contract, report, email, code, or generic)
using keyword frequency scoring. Prepends a TYPE/CONFIDENCE/WORDS header to the text
so downstream skills can route accordingly.
"""
import collections
import re

text = PROMPT  # noqa: F821
lower = text.lower()

_KEYWORDS = {
    "invoice": [
        "invoice", "bill to", "amount due", "payment terms", "vendor",
        "subtotal", "qty", "unit price", "vat", "tax id", "purchase order",
        "remit to", "due date", "net 30",
    ],
    "contract": [
        "agreement", "parties", "clause", "termination", "liability",
        "governing law", "confidential", "warranty", "indemnif", "herein",
        "whereas", "witnesseth", "service agreement", "jurisdiction",
    ],
    "report": [
        "executive summary", "findings", "recommendations", "methodology",
        "conclusion", "analysis", "results", "figure", "table", "appendix",
        "objective", "scope", "overview",
    ],
    "email": [
        "dear ", "regards", "sincerely", "subject:", "from:", "to:", "cc:",
        "please find", "attached", "hope this email", "kind regards",
        "best regards", "fyi",
    ],
    "code": [
        "def ", "function ", "class ", "import ", "return ", "if (",
        "for (", "const ", "var ", "#!/", "async def", "public class",
        "pragma", "#include",
    ],
}

scores: collections.Counter = collections.Counter()
for doc_type, keywords in _KEYWORDS.items():
    for kw in keywords:
        if kw in lower:
            scores[doc_type] += 1

doc_type = scores.most_common(1)[0][0] if scores else "document"
confidence = scores.most_common(1)[0][1] if scores else 0
words = len(text.split())

print(f"TYPE:{doc_type}")
print(f"CONFIDENCE:{confidence}")
print(f"WORDS:{words}")
print("---")
print(text[:3500])
