"""
BSS Skill: Financial Pipeline — chain finalizer
Receives the totals-summarizer output (compact invoice summary) and ensures
it fits within the 200-token target. Strips any trailing === END === delimiter.
"""
# PROMPT is the totals-summarizer output.
lines = PROMPT.strip().split("\n")  # noqa: F821

# Drop delimiter added by totals-summarizer
if lines and lines[-1].strip() == "=== END ===":
    lines = lines[:-1]

output = "\n".join(lines).strip()

# Hard cap: 800 chars keeps it well under 200 tokens
if len(output) > 800:
    output = output[:800].rsplit("\n", 1)[0]

print("[BIBIVIDI: invoice pre-processed]")
print(output)
