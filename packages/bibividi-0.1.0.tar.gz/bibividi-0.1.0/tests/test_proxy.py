"""
BIBIVIDI — Proxy tests
Run with: pytest tests/
"""
import json
from unittest.mock import AsyncMock, patch

import pytest
from httpx import ASGITransport, AsyncClient

from bvd.core.proxy import _estimate_tokens, _extract_prompt, _inject_result, app
from bvd.engine.library import Script
from bvd.engine.matcher import MatchResult
from bvd.engine.runner import RunResult

# ── Unit tests ────────────────────────────────────────────────────────────────

def test_extract_prompt_openai_format():
    body = {
        "model": "gpt-4",
        "messages": [
            {"role": "system", "content": "You are helpful."},
            {"role": "user", "content": "Summarise this contract."},
        ],
    }
    assert _extract_prompt(body) == "Summarise this contract."


def test_extract_prompt_anthropic_format():
    body = {
        "model": "claude-3-5-sonnet-20241022",
        "messages": [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "Hello from Anthropic format."}
                ],
            }
        ],
    }
    assert _extract_prompt(body) == "Hello from Anthropic format."


def test_extract_prompt_no_messages():
    body = {"prompt": "\n\nHuman: What is 2+2?\n\nAssistant:"}
    assert "2+2" in _extract_prompt(body)


def test_inject_result():
    body = {
        "messages": [
            {"role": "user", "content": "Long document..."},
        ]
    }
    result = _inject_result(body, "Condensed: 3 clauses found.")
    assert "Condensed" in result["messages"][0]["content"]
    assert "BIBIVIDI" in result["messages"][0]["content"]


def test_estimate_tokens():
    text = "a" * 400
    # tiktoken is available — result should be a positive integer
    count = _estimate_tokens(text)
    assert isinstance(count, int)
    assert count >= 1


# ── Integration tests ─────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_health_endpoint():
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.get("/bibividi/health")
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "ok"
    assert "proxy" in data


@pytest.mark.asyncio
async def test_ssrf_blocked_for_non_allowlisted_host():
    """Requests to hosts not in BIBIVIDI_TARGET_APIS must return 403."""
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.post(
            "/v1/messages",
            headers={"Host": "169.254.169.254"},
            json={"messages": [{"role": "user", "content": "hi"}]},
        )
    assert resp.status_code == 403
    assert b"allowlist" in resp.content


@pytest.mark.asyncio
async def test_ssrf_blocked_for_internal_service():
    """Crafted Host pointing to a local service is rejected."""
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.post(
            "/v1/messages",
            headers={"Host": "localhost:5432"},
            json={"messages": [{"role": "user", "content": "hi"}]},
        )
    assert resp.status_code == 403


# ── Dry-run mode ──────────────────────────────────────────────────────────────

_DRY_SCRIPT = Script(
    id="dry-run-script",
    name="Dry Run Script",
    description="Used in dry-run tests",
    code='print("[CONDENSED]")',
)
_DRY_MATCH = MatchResult(script=_DRY_SCRIPT, script_id=_DRY_SCRIPT.id, score=0.92)
_DRY_RUN = RunResult(
    output="[CONDENSED OUTPUT]",
    stdout="[CONDENSED OUTPUT]",
    stderr="",
    exit_code=0,
    timed_out=False,
)


@pytest.mark.asyncio
async def test_dry_run_does_not_inject_condensed_content(tmp_path):
    """In dry-run mode the original request body reaches the upstream unchanged."""
    captured_body: dict = {}

    async def fake_request(method, url, **kwargs):
        captured_body.update(json.loads(kwargs.get("content", b"{}")))
        import httpx
        return httpx.Response(
            200,
            json={
                "id": "msg_dry",
                "type": "message",
                "role": "assistant",
                "model": "claude-haiku-4-5-20251001",
                "content": [{"type": "text", "text": "dry"}],
                "stop_reason": "end_turn",
                "usage": {"input_tokens": 10, "output_tokens": 2},
            },
        )

    mock_client = AsyncMock()
    mock_client.request = fake_request

    original_prompt = "Analyse ce contrat et résume les clauses importantes."

    with (
        patch("bvd.config.settings.target_apis", ["api.anthropic.com"]),
        patch("bvd.config.settings.db_path", tmp_path / "dry.db"),
        patch("bvd.config.settings.track_savings", False),
        patch("bvd.config.settings.dry_run", True),
        patch("bvd.core.proxy.get_client", AsyncMock(return_value=mock_client)),
        patch("bvd.core.proxy.matcher.match", AsyncMock(return_value=_DRY_MATCH)),
        patch("bvd.core.proxy.run_script", AsyncMock(return_value=_DRY_RUN)),
    ):
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.post(
                "/v1/messages",
                headers={"Host": "api.anthropic.com"},
                content=json.dumps({
                    "model": "claude-haiku-4-5-20251001",
                    "max_tokens": 50,
                    "messages": [{"role": "user", "content": original_prompt}],
                }).encode(),
            )

    assert resp.status_code == 200
    # Original prompt must be forwarded unchanged — dry-run must NOT inject
    user_msg = captured_body["messages"][-1]["content"]
    assert original_prompt in user_msg
    assert "[CONDENSED OUTPUT]" not in user_msg
    assert "[BIBIVIDI: pre-processed]" not in user_msg


# ── Negative-saving guard ──────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_negative_saving_skill_not_injected(tmp_path):
    """If the skill output is larger than the original prompt, do NOT inject it."""
    captured_body: dict = {}

    async def fake_request(method, url, **kwargs):
        captured_body.update(json.loads(kwargs.get("content", b"{}")))
        import httpx
        return httpx.Response(
            200,
            json={
                "id": "msg_neg",
                "type": "message",
                "role": "assistant",
                "model": "claude-haiku-4-5-20251001",
                "content": [{"type": "text", "text": "ok"}],
                "stop_reason": "end_turn",
                "usage": {"input_tokens": 5, "output_tokens": 1},
            },
        )

    mock_client = AsyncMock()
    mock_client.request = fake_request

    # A short prompt so the bloated skill output will have more tokens
    short_prompt = "Translate: hello"
    # Skill output that is clearly larger than the 4-token prompt
    bloated_output = "=== BIBIVIDI HEADER ===" + (" extra words" * 50)

    bloated_run = RunResult(
        output=bloated_output,
        stdout=bloated_output,
        stderr="",
        exit_code=0,
        timed_out=False,
    )
    bloated_script = Script(
        id="bloated-skill",
        name="Bloated Skill",
        description="Returns more tokens than it receives",
        code='print("big output")',
    )
    bloated_match = MatchResult(script=bloated_script, script_id=bloated_script.id, score=0.91)

    with (
        patch("bvd.config.settings.target_apis", ["api.anthropic.com"]),
        patch("bvd.config.settings.db_path", tmp_path / "neg.db"),
        patch("bvd.config.settings.track_savings", False),
        patch("bvd.config.settings.dry_run", False),
        patch("bvd.core.proxy.get_client", AsyncMock(return_value=mock_client)),
        patch("bvd.core.proxy.matcher.match", AsyncMock(return_value=bloated_match)),
        patch("bvd.core.proxy.run_script", AsyncMock(return_value=bloated_run)),
    ):
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.post(
                "/v1/messages",
                headers={"Host": "api.anthropic.com"},
                content=json.dumps({
                    "model": "claude-haiku-4-5-20251001",
                    "max_tokens": 50,
                    "messages": [{"role": "user", "content": short_prompt}],
                }).encode(),
            )

    assert resp.status_code == 200
    # Skill had negative saving — original prompt must be forwarded unchanged
    user_msg = captured_body["messages"][-1]["content"]
    assert short_prompt in user_msg
    assert "BIBIVIDI: pre-processed" not in user_msg
    assert bloated_output not in user_msg
