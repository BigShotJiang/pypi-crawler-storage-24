"""
BIBIVIDI — ROI calculator tests (TODO-17)
Tests for GET /bibividi/roi endpoint.
"""
from __future__ import annotations

from unittest.mock import AsyncMock
from unittest.mock import patch as _patch

import pytest
from fastapi.testclient import TestClient

from bvd.core.proxy import app


def _client():
    with (
        _patch("bvd.engine.library.library.init", AsyncMock()),
        _patch("bvd.notifier.digest_scheduler", AsyncMock()),
    ):
        return TestClient(app, raise_server_exceptions=True)


@pytest.mark.asyncio
async def test_roi_returns_html():
    """GET /bibividi/roi returns HTML page."""
    resp = _client().get("/bibividi/roi")
    assert resp.status_code == 200
    assert "text/html" in resp.headers["content-type"]
    assert "ROI Calculator" in resp.text


@pytest.mark.asyncio
async def test_roi_contains_sliders():
    """ROI page has spend and token sliders."""
    resp = _client().get("/bibividi/roi")
    assert 'id="spend"' in resp.text
    assert 'id="tokens"' in resp.text


@pytest.mark.asyncio
async def test_roi_contains_model_prices():
    """ROI page embeds current model price data."""
    resp = _client().get("/bibividi/roi")
    assert "GPT-4o" in resp.text
    assert "Claude Haiku" in resp.text
    assert "Claude Sonnet" in resp.text


@pytest.mark.asyncio
async def test_roi_shows_result_boxes():
    """ROI page has the four result display boxes."""
    resp = _client().get("/bibividi/roi")
    assert "r-gross" in resp.text
    assert "r-net" in resp.text
    assert "r-bibividi" in resp.text
    assert "r-co2" in resp.text
