"""BIBIVIDI — Token optimization middleware for AI APIs."""
__version__ = "0.1.0"
