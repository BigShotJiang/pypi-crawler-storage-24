import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// In Tauri dev mode the backend is the Tauri process, not a Vite dev server.
// TAURI_ENV_DEV is set by Tauri's CLI during `tauri dev`.
const isTauri = process.env.TAURI_ENV_DEV === 'true'

export default defineConfig({
  plugins: [react()],

  // Tauri needs relative paths in prod; web build uses absolute.
  base: isTauri ? './' : '/',

  build: {
    outDir: 'dist',
    emptyOutDir: true,
    sourcemap: false,
    // Tauri uses Chromium / WebKit — no need to target old browsers.
    target: isTauri ? ['chrome105', 'safari15'] : 'es2020',
  },

  server: {
    // Tauri dev: do NOT proxy (Tauri injects its own IPC).
    // Web dev: proxy API calls to the running BIBIVIDI proxy.
    ...(isTauri
      ? {}
      : {
          proxy: {
            '/bibividi/api': 'http://localhost:8080',
            '/bibividi/events': {
              target: 'http://localhost:8080',
              changeOrigin: true,
            },
          },
        }),
  },
})
