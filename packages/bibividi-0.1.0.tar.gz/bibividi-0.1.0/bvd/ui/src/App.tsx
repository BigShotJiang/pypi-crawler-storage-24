import { useState } from 'react'
import {
  LayoutDashboard, Activity, Puzzle, Clock,
  CreditCard, Store, Settings, ChevronLeft, ChevronRight,
  WifiOff, Download, X,
} from 'lucide-react'
import { useUpdater } from './hooks/useUpdater'
import Dashboard from './components/Dashboard'
import LiveFeed, { useLiveFeed } from './components/LiveFeed'
import SkillsLibrary from './components/SkillsLibrary'
import PendingQueue, { usePending } from './components/PendingQueue'
import Billing from './components/Billing'
import MarketplacePayouts from './components/MarketplacePayouts'
import SettingsPanel from './components/SettingsPanel'
import './index.css'

type Tab = 'dashboard' | 'feed' | 'skills' | 'pending' | 'billing' | 'marketplace' | 'settings'

export default function App() {
  const [tab, setTab] = useState<Tab>('dashboard')
  const [collapsed, setCollapsed] = useState(false)
  const { pending, reload } = usePending()
  const { connected } = useLiveFeed()
  const update = useUpdater()

  const nav = (id: Tab, Icon: React.ElementType, label: string, badge?: number) => (
    <button
      className={`nav-item${tab === id ? ' active' : ''}`}
      onClick={() => setTab(id)}
      title={collapsed ? label : undefined}
    >
      <Icon size={18} />
      {!collapsed && <span>{label}</span>}
      {!collapsed && badge != null && badge > 0 && (
        <span className="badge">{badge}</span>
      )}
    </button>
  )

  return (
    <div className={`shell${collapsed ? ' collapsed' : ''}`}>
      {/* ── Titlebar ─────────────────────────────────────── */}
      <header className="titlebar">
        <button
          className="collapse-btn"
          onClick={() => setCollapsed(!collapsed)}
          title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {collapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
        </button>
        {!collapsed && <span className="logo">BIBIVIDI</span>}
        <div className="proxy-status">
          {connected
            ? <><span className="dot dot-green" /><span>Proxy live</span></>
            : <><WifiOff size={13} /><span>Disconnected</span></>
          }
        </div>
      </header>

      {/* ── Sidebar ──────────────────────────────────────── */}
      <aside className="sidebar">
        {nav('dashboard',   LayoutDashboard, 'Dashboard')}
        {nav('feed',        Activity,        'Live Feed')}
        {nav('skills',      Puzzle,          'Skills')}
        {nav('pending',     Clock,           'Pending', pending.length)}
        {nav('billing',     CreditCard,      'Billing')}
        {nav('marketplace', Store,           'Marketplace')}
        <div className="nav-spacer" />
        {nav('settings',    Settings,        'Settings')}
      </aside>

      {/* ── Main ─────────────────────────────────────────── */}
      <main className="main">
        {/* Update banner — shown when a new version is available */}
        {update.available && (
          <div className="update-banner">
            <Download size={15} />
            <span>BIBIVIDI {update.version} is available.</span>
            <button
              className="update-btn"
              onClick={update.install}
              disabled={update.installing}
            >
              {update.installing ? 'Installing…' : 'Update & restart'}
            </button>
            <button className="update-dismiss" onClick={update.dismiss} title="Dismiss">
              <X size={13} />
            </button>
          </div>
        )}
        {tab === 'dashboard'   && <Dashboard />}
        {tab === 'feed'        && <LiveFeedPage />}
        {tab === 'skills'      && <SkillsLibrary />}
        {tab === 'pending'     && <PendingQueue pending={pending} reload={reload} />}
        {tab === 'billing'     && <Billing />}
        {tab === 'marketplace' && <MarketplacePayouts />}
        {tab === 'settings'    && <SettingsPanel />}
      </main>
    </div>
  )
}

function LiveFeedPage() {
  return <LiveFeed />
}
