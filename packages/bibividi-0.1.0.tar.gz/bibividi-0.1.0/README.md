# BIBIVIDI

> **Token optimization middleware for AI APIs**
> Intercepts Anthropic / OpenAI requests, runs a matching Python script locally, and sends a condensed prompt — reducing token consumption by **60–95%**.

```
Your app ──► BIBIVIDI proxy :8080 ──► Anthropic / OpenAI
                   │
         Matching engine (embeddings)
                   │
     Script found → local Python execution
                   │
         Condensed context (90% fewer tokens)
```

No prompt is ever stored. Processing is 100% local.

---

## Quick start

```bash
pip install bibividi
bibividi start                    # proxy starts on :8080
bibividi add scripts/pdf-clause-extractor/
bibividi status
```

### Integrate in 2 lines

**Anthropic SDK**
```python
import anthropic
from bvd.sdk import anthropic_http_client

client = anthropic.Anthropic(
    api_key="sk-ant-...",
    http_client=anthropic_http_client(),   # ← only change
)
# All calls now route through BIBIVIDI — zero code changes elsewhere
```

**OpenAI SDK**
```python
import openai
from bvd.sdk import openai_http_client

client = openai.OpenAI(
    api_key="sk-...",
    http_client=openai_http_client(),      # ← only change
)
```

**Async variants**
```python
from bvd.sdk import async_anthropic_http_client, async_openai_http_client

client = anthropic.AsyncAnthropic(http_client=async_anthropic_http_client(), ...)
```

---

## What is a BSS skill?

A **BSS (BIBIVIDI Skill Specification) pack** is a directory with two files:

| File | Role |
|------|------|
| `skill.json` | Metadata: `id`, `name`, `description`, `tags`, `hash` |
| `skill.py` | Python script. Reads `PROMPT`, prints condensed output to stdout |

```python
# skill.py — PROMPT is injected automatically
import re, json

clauses = re.findall(r'(?:Article|Clause)\s+\d+[^.]*\.', PROMPT)
print(json.dumps({"clauses": clauses[:10], "total": len(clauses)}))
```

```bash
bibividi add  scripts/my-skill/    # install
bibividi list                       # inspect
bibividi test my-skill-id           # run against stdin
```

**Sandbox**: only `json, re, math, statistics, datetime, collections, itertools,
functools, pathlib, string, textwrap, csv, io, base64, hashlib, uuid` are allowed.
No OS, network, or subprocess access. Scripts are SHA-256 verified on install.

### 5 demo packs included

| Pack | Typical saving |
|------|---------------|
| `pdf-clause-extractor` | 80–95% |
| `csv-data-summarizer` | 85–95% |
| `structured-report-extractor` | 75–90% |
| `batch-translation-condenser` | 70–90% |
| `code-review-condenser` | 60–80% |

---

## HTTPS interception (optional)

For apps that send directly to `https://api.anthropic.com` without going through
the SDK integration above:

```bash
bibividi cert generate   # create local CA + server cert
bibividi cert install    # trust the CA (may require sudo)
bibividi start --ssl     # HTTP :8080 + HTTPS CONNECT tunnel :8443
```

Configure your HTTP client to use `http://127.0.0.1:8443` as a proxy:
```python
import httpx
client = httpx.Client(proxy="http://127.0.0.1:8443", verify="~/.bibividi/ca.crt")
```

---

## Auto-generate skills (generator)

When no script matches a prompt, BIBIVIDI can call the LLM once to generate
a new BSS skill automatically. The next similar request will be handled locally.

```env
BIBIVIDI_GENERATOR_ENABLED=true
BIBIVIDI_GENERATOR_API_KEY=sk-ant-...   # key used only for generation
```

---

## CLI reference

```bash
bibividi start [--ssl] [--host HOST] [--port PORT]
bibividi status
bibividi list
bibividi add <pack-dir>
bibividi test <script-id>           # prompt via stdin
bibividi cert generate|install|path
```

## Configuration

All settings via `BIBIVIDI_` environment variables (or `.env`):

| Variable | Default | Description |
|---|---|---|
| `BIBIVIDI_PROXY_PORT` | `8080` | Proxy listen port |
| `BIBIVIDI_TUNNEL_PORT` | `8443` | HTTPS CONNECT tunnel port |
| `BIBIVIDI_MATCH_THRESHOLD` | `0.75` | Cosine similarity threshold |
| `BIBIVIDI_MAX_SCRIPT_RUNTIME_S` | `10.0` | Sandbox timeout |
| `BIBIVIDI_GENERATOR_ENABLED` | `false` | Auto-generate skills on no-match |
| `BIBIVIDI_LOG_REQUESTS` | `false` | Log prompt content (dev only) |

---

## Development

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
cp .env.example .env

pytest                    # 49 tests
ruff check .
mypy bvd/

# Zero-credit local testing
uvicorn mock_api:app --port 9090 &
BIBIVIDI_TARGET_APIS='["localhost:9090"]' bibividi start
```

---

## License

MIT — engine is open source. Cloud runner and marketplace are proprietary (Pro/Enterprise).
