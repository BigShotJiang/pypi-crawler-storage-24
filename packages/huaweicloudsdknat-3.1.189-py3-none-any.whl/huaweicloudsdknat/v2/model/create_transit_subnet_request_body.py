# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CreateTransitSubnetRequestBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'transit_subnet': 'CreateTransitSubnetOption'
    }

    attribute_map = {
        'transit_subnet': 'transit_subnet'
    }

    def __init__(self, transit_subnet=None):
        r"""CreateTransitSubnetRequestBody

        The model defined in huaweicloud sdk

        :param transit_subnet: 
        :type transit_subnet: :class:`huaweicloudsdknat.v2.CreateTransitSubnetOption`
        """
        
        

        self._transit_subnet = None
        self.discriminator = None

        self.transit_subnet = transit_subnet

    @property
    def transit_subnet(self):
        r"""Gets the transit_subnet of this CreateTransitSubnetRequestBody.

        :return: The transit_subnet of this CreateTransitSubnetRequestBody.
        :rtype: :class:`huaweicloudsdknat.v2.CreateTransitSubnetOption`
        """
        return self._transit_subnet

    @transit_subnet.setter
    def transit_subnet(self, transit_subnet):
        r"""Sets the transit_subnet of this CreateTransitSubnetRequestBody.

        :param transit_subnet: The transit_subnet of this CreateTransitSubnetRequestBody.
        :type transit_subnet: :class:`huaweicloudsdknat.v2.CreateTransitSubnetOption`
        """
        self._transit_subnet = transit_subnet

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CreateTransitSubnetRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
