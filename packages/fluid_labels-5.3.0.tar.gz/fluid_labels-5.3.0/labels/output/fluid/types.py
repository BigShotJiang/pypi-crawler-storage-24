from typing import Any, TypedDict


class FluidSBOM(TypedDict):
    sbom_details: dict[str, str | None]
    packages: list[dict[str, Any]]  # type: ignore[explicit-any]
    relationships: list[dict[str, str | list[str]]]
