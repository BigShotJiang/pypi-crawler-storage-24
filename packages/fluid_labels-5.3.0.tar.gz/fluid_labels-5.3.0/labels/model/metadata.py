from pydantic import BaseModel

from labels.model.constraints import NonEmptyStr


class Digest(BaseModel):
    algorithm: NonEmptyStr | None = None
    value: NonEmptyStr | None = None


class Artifact(BaseModel):
    integrity: Digest | None = None


class HealthMetadata(BaseModel):
    artifact: Artifact | None = None
