from pydantic import BaseModel


class AwsCredentials(BaseModel):
    access_key_id: str
    secret_access_key: str
    session_token: str | None


class AwsRole(BaseModel):
    external_id: str
    role: str
