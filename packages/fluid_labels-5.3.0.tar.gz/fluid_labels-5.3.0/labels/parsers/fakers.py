from collections.abc import Generator
from typing import TextIO

from labels.model.file import Location
from labels.model.resolver import FileReader, Resolver


class FakeResolver(Resolver):
    def __init__(
        self,
        *,
        file_content: TextIO | None = None,
        glob_results: list[Location] | None = None,
    ) -> None:
        self._file_content = file_content
        self._glob_results = glob_results or []

    def file_contents_by_location(
        self,
        location: Location,
        *,
        function_reader: FileReader | None = None,
        mode: str = "r",
    ) -> TextIO | None:
        return self._file_content

    def has_path(self, path: str) -> bool:
        return False

    def files_by_path(self, *paths: str) -> list[Location]:
        return []

    def files_by_glob(self, *patterns: str) -> list[Location]:
        return self._glob_results

    def relative_file_path(self, _: Location, path: str) -> Location | None:
        return None

    def walk_file(self) -> Generator[str, None, None]:
        yield from ()
