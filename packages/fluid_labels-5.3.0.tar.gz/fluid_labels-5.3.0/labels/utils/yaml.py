from collections.abc import Mapping
from pathlib import Path
from typing import cast

import yaml


def load_yaml_mapping(path: str) -> Mapping[str, object]:
    file_path = Path(path)
    with file_path.open(encoding="utf-8") as file:
        data = cast("object", yaml.safe_load(file))

    if data is None:
        return {}

    if not isinstance(data, Mapping):
        msg = "YAML root must be a mapping"
        raise TypeError(msg)

    return data
