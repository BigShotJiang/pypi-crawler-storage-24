"""客户端配置"""

VERSION = "1.2.35"

# 网络配置
PORT = 5555
DEFAULT_HOST = "112.126.80.53"

# Win11 风格配色
# 背景色
COLOR_BG_PRIMARY = '#202020'      # 主背景（深灰黑）
COLOR_BG_SECONDARY = '#2d2d2d'    # 次级背景
COLOR_BG_TERTIARY = '#383838'     # 三级背景（卡片）
COLOR_BG_HOVER = '#404040'        # 悬停背景

# 前景色
COLOR_FG_PRIMARY = '#ffffff'      # 主文字
COLOR_FG_SECONDARY = '#b3b3b3'    # 次级文字
COLOR_FG_TERTIARY = '#808080'     # 三级文字

# 强调色（灰度）
COLOR_ACCENT = '#a0a0a0'          # 主强调色（中灰）
COLOR_ACCENT_HOVER = '#b8b8b8'    # 悬停强调（亮灰）
COLOR_ACCENT_LIGHT = '#d0d0d0'    # 浅强调色（浅灰）

# 边框色
COLOR_BORDER = '#454545'          # 边框
COLOR_BORDER_LIGHT = '#5a5a5a'    # 浅边框

# 功能色（灰度）
COLOR_SUCCESS = '#a0a0a0'         # 成功/在线
COLOR_WARNING = '#c0c0c0'         # 警告
COLOR_ERROR = '#707070'           # 错误


