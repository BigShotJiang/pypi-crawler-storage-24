"""
模块状态层 — 独立于 Widget 的持久化数据存储

核心原则：
  Widget 是无状态的纯视图，随时可销毁重建。
  所有持久数据存储在本模块的 State 对象中。
  Widget 创建后通过 restore() 从 State 恢复全部内容。
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any

# 聊天消息条目类型
MSG = 'msg'          # (MSG, name, text, channel, time_str)
SYS = 'sys'          # (SYS, text)
HISTORY = 'history'  # (HISTORY, messages_list, channel) — 替换该频道的全部消息


class ChatState:
    """聊天面板的全部状态"""

    def __init__(self):
        self.entries: list[tuple] = []
        self.current_channel: int = 1
        self.online_count: int = 0

    def add_message(self, name: str, text: str, channel: int = 1, time_str: str = ""):
        self.entries.append((MSG, name, text, channel, time_str))

    def add_system_message(self, text: str):
        self.entries.append((SYS, text))

    def set_history(self, messages: list, channel: int):
        # 移除该频道的旧消息，替换为新历史
        self.entries = [e for e in self.entries
                        if not (e[0] == MSG and e[3] == channel)]
        self.entries.append((HISTORY, messages, channel))

    def switch_channel(self, channel_id: int):
        self.current_channel = channel_id

    def update_online_count(self, users: list):
        self.online_count = len(users) if users else 0


class CmdState:
    """指令面板的全部状态"""

    def __init__(self):
        self.lines: list[str] = []
        self.action_bar: str = ""
        self.max_lines: int = 1000

    def add_line(self, text: str):
        self.lines.append(text)
        # 限制行数防止内存膨胀
        if len(self.lines) > self.max_lines:
            self.lines = self.lines[-self.max_lines:]

    def clear(self):
        self.lines.clear()

    def set_action_bar(self, text: str):
        self.action_bar = text

    def clear_action_bar(self):
        self.action_bar = ""


class BoardState:
    """棋盘面板的全部状态（可视化：棋盘/牌桌/地图）"""

    def __init__(self):
        self.player_data: dict = {}
        self.map_data: Any = None
        self.room_data: dict | None = None
        self.location: str = "lobby"


class StatusState:
    """状态面板的全部状态（通用：由渲染器解读 game_data）"""

    def __init__(self):
        self.lines: list[str] = []
        self.game_type: str = ""     # 当前游戏类型
        self.game_data: dict = {}    # 游戏特定状态（渲染器自行解读）
        self.need_discard: bool = False
        self.max_lines: int = 500

    def update_game_status(self, game_type: str, game_data: dict):
        """更新游戏状态（通用接口）"""
        self.game_type = game_type
        self.game_data = game_data
        self.need_discard = game_data.get("need_discard", False)

    def add_line(self, text: str):
        self.lines.append(text)
        if len(self.lines) > self.max_lines:
            self.lines = self.lines[-self.max_lines:]

    def clear(self):
        self.lines.clear()
        self.game_type = ""
        self.game_data = {}
        self.need_discard = False

    def clear_game(self):
        """清除游戏状态但保留日志"""
        self.game_type = ""
        self.game_data = {}
        self.need_discard = False
        if len(self.lines) > self.max_lines:
            self.lines = self.lines[-self.max_lines:]


class OnlineState:
    """在线用户面板的全部状态"""

    def __init__(self):
        self.users: list = []


class ModuleStateManager:
    """所有模块状态的统一管理器，生命周期跟随 GameScreen"""

    def __init__(self):
        self.chat = ChatState()
        self.cmd = CmdState()
        self.board = BoardState()
        self.status = StatusState()
        self.online = OnlineState()
