"""
Textual TUI 主应用 — 极简终端风格
"""

from __future__ import annotations

from textual.app import App, ComposeResult
from textual.screen import Screen
from textual.widgets import Static, Input, RichLog
from textual.containers import Vertical, Horizontal, Center, Middle
from textual.binding import Binding
from textual.message import Message
from textual import work

from .config import PORT, DEFAULT_HOST
from .network import NetworkManager
from .vim_mode import VimMode, Mode
from .message_handler import (
    parse_server_message,
    LoginPrompt, RequestAvatar, LoginSuccess,
    SystemMessage, GameMessage, ChatMessage, ChatHistory,
    StatusUpdate, OnlineUsers, GameInvite,
    RoomUpdate, RoomLeave, GameQuit, LocationUpdate,
    HandUpdate, ActionPrompt, SelfActionPrompt,
    WinAnimation, ActionCommand,
)
from .tui_layout import (
    LayoutNode, PaneNode, SplitNode,
    get_default_layout, serialize, deserialize,
    all_panes, find_pane, find_module_pane,
    split_pane, close_pane, navigate, next_pane_id, resize_pane,
)
from .tui_canvas import Canvas, PaneWrapper, MODULE_REGISTRY
from .tui_widgets import ChatPanel, CommandPanel, BoardPanel, StatusPanel, OnlineUsersPanel
from .module_state import ModuleStateManager, MSG, SYS, HISTORY
from .game_registry import get_renderer

# 导入渲染器包触发自动注册
from . import renderers  # noqa: F401

try:
    from .config import VERSION
except ImportError:
    VERSION = None


# ═══════════════════════════════════════════════════════
#  自定义消息
# ═══════════════════════════════════════════════════════

class ServerMsg(Message):
    def __init__(self, data: dict) -> None:
        super().__init__()
        self.data = data


class Disconnected(Message):
    pass


# ═══════════════════════════════════════════════════════
#  LoginScreen
# ═══════════════════════════════════════════════════════

class LoginScreen(Screen):
    BINDINGS = [Binding("escape", "quit", "退出", show=True)]

    def compose(self) -> ComposeResult:
        with Center():
            with Middle():
                with Vertical(id="login-container"):
                    yield Static("游戏大厅", id="login-title")
                    yield Input(placeholder=f"服务器地址 ({DEFAULT_HOST})", id="login-input")
                    yield Static("按 Enter 连接", id="login-status")

    def on_mount(self) -> None:
        pass

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id != "login-input":
            return
        ip = event.value.strip() or DEFAULT_HOST
        self.query_one("#login-status", Static).update(f"正在连接 {ip}…")
        self.app.connect_to_server(ip)

    def set_status(self, text: str):
        try:
            self.query_one("#login-status", Static).update(text)
        except Exception:
            pass


# ═══════════════════════════════════════════════════════
#  GameScreen — NVim 风格动态窗口
# ═══════════════════════════════════════════════════════

class GameScreen(Screen):
    BINDINGS = [Binding("escape", "enter_normal", "", show=False)]

    def __init__(self, layout_data: dict | None = None, **kw):
        super().__init__(**kw)
        self.logged_in = False
        self.current_location = "lobby"
        self.current_room_id = None
        self._input_buffer = ""
        self._focused_pane_id = ""
        self._which_key = None        # None / "top" / "window" / "modules"
        self._picker_selected = 0     # 模块选择器当前选中
        # 状态层：独立于 Widget，持久化保存所有模块数据
        self.state = ModuleStateManager()
        # 恢复或创建默认布局
        tree = None
        if layout_data:
            tree = deserialize(layout_data)
        if tree is None:
            tree = get_default_layout()
        self._layout_tree = tree

    def compose(self) -> ComposeResult:
        yield Canvas(self._layout_tree, id="canvas")
        with Vertical(id="which-key-overlay"):
            yield Static("", id="which-key-content")
        with Horizontal(id="footer-bar"):
            yield Static(" NORMAL ", id="mode-indicator")
            yield Static("大厅", id="location-indicator")
            yield Static(f"v{VERSION}" if VERSION else "", id="connection-status")

    def on_mount(self) -> None:
        # 聚焦到第一个可输入窗格（cmd 优先）
        panes = all_panes(self._layout_tree)
        focus_id = ""
        for p in panes:
            if p.module == 'cmd':
                focus_id = p.pane_id
                break
        if not focus_id and panes:
            focus_id = panes[0].pane_id
        if focus_id:
            self._set_focused_pane(focus_id)
        # 初始化面板标题
        self._init_panel_titles()
        # 登录阶段自动进入输入模式
        self._enter_insert()

    def _init_panel_titles(self):
        """初始化各模块面板标题并从 State 恢复内容"""
        self._restore_all_modules()

    # ── 画布与面板访问 ──

    @property
    def canvas(self) -> Canvas:
        return self.query_one("#canvas", Canvas)

    def _get_module(self, module_name: str):
        """获取指定模块的 Widget 实例"""
        return self.canvas.get_module_widget(module_name)

    def _get_pane_for_module(self, module_name: str) -> PaneNode | None:
        return find_module_pane(self._layout_tree, module_name)

    @property
    def vim(self) -> VimMode:
        return self.app.vim

    # ── 焦点管理 ──

    def _set_focused_pane(self, pane_id: str):
        self._focused_pane_id = pane_id
        canvas = self.canvas
        for p in all_panes(self._layout_tree):
            wrapper = canvas.get_pane(p.pane_id)
            if wrapper:
                if p.pane_id == pane_id:
                    wrapper.add_class("--focused")
                else:
                    wrapper.remove_class("--focused")

    def _focused_module(self) -> str | None:
        pane = find_pane(self._layout_tree, self._focused_pane_id)
        return pane.module if pane else None

    @property
    def _input_target(self) -> str:
        mod = self._focused_module()
        if mod == 'chat':
            return 'chat'
        if mod == 'cmd':
            return 'cmd'
        return ''

    def _can_input(self) -> bool:
        return self._input_target in ('chat', 'cmd')

    # ── 模式切换 ──

    def action_enter_normal(self):
        self._hide_which_key()
        if self.vim.mode == Mode.INSERT:
            self._input_buffer = ""
            self._hide_panel_prompt()
        self.vim.enter_normal()
        self._update_mode_indicator()
        self.set_focus(None)

    def _enter_insert(self):
        if not self._can_input():
            return
        self._input_buffer = ""
        self.vim.enter_insert()
        self._update_mode_indicator()
        self._show_panel_prompt("")

    def _update_mode_indicator(self):
        indicator = self.query_one("#mode-indicator", Static)
        mode = self.vim.mode
        if mode == Mode.NORMAL:
            indicator.update(" NORMAL ")
        elif mode == Mode.INSERT:
            indicator.update(" INSERT ")

    # ── 面板内输入提示 ──

    def _show_panel_prompt(self, text: str):
        mod = self._focused_module()
        widget = self._get_module(mod) if mod else None
        if isinstance(widget, (ChatPanel, CommandPanel)):
            widget.show_prompt(text)

    def _update_panel_prompt(self, text: str):
        mod = self._focused_module()
        widget = self._get_module(mod) if mod else None
        if isinstance(widget, (ChatPanel, CommandPanel)):
            widget.update_prompt(text)

    def _hide_panel_prompt(self):
        for mod in ('chat', 'cmd'):
            widget = self._get_module(mod)
            if isinstance(widget, (ChatPanel, CommandPanel)):
                widget.hide_prompt()

    # ── Which-key 菜单（屏幕中央浮动） ──

    def _show_which_key(self, level: str):
        from .tui_layout import MODULE_LABELS, MODULES
        from rich.text import Text
        overlay = self.query_one("#which-key-overlay")
        content = self.query_one("#which-key-content", Static)
        lines = []
        if level == "top":
            overlay.border_title = "菜单"
            lines.append("  [b]e[/b]  模块")
            lines.append("  [b]w[/b]  窗口")
            lines.append("  [b]q[/b]  退出")
        elif level == "window":
            overlay.border_title = "窗口"
            lines.append("  [b]/[/b]      横分")
            lines.append("  [b]-[/b]      纵分")
            lines.append("  [b]h j k l[/b]  导航")
            lines.append("  [b]H / L[/b]  横向缩放")
            lines.append("  [b]J / K[/b]  纵向缩放")
            lines.append("  [b]q[/b]      关闭")
        elif level == "modules":
            overlay.border_title = "模块"
            for i, mod in enumerate(MODULES):
                label = MODULE_LABELS.get(mod, mod)
                if i == self._picker_selected:
                    lines.append(f"  [reverse] {label} [/]")
                else:
                    lines.append(f"    {label}")
            lines.append("")
            lines.append("  [dim]j/k 选择  Enter 确认  Esc 取消[/dim]")
        content.update("\n".join(lines))
        overlay.add_class("visible")

    def _hide_which_key(self):
        self._which_key = None
        overlay = self.query_one("#which-key-overlay")
        overlay.remove_class("visible")

    # ── 模块选择确认 ──

    def _picker_confirm(self):
        from .tui_layout import MODULES
        module_name = MODULES[self._picker_selected]
        self._hide_which_key()
        self.call_later(self._do_open_module, module_name)

    async def _do_open_module(self, module_name: str):
        """打开模块：空窗格直接设置，已有模块的窗格先自动 split"""
        canvas = self.canvas
        # 如果该模块已在其他窗格打开，清除旧位置
        existing = find_module_pane(self._layout_tree, module_name)
        if existing and existing.pane_id != self._focused_pane_id:
            existing.module = None
        # 当前窗格已有模块 → 自动横向 split，在新窗格中打开
        current = find_pane(self._layout_tree, self._focused_pane_id)
        target_pane_id = self._focused_pane_id
        if current and current.module is not None:
            self._layout_tree = split_pane(self._layout_tree, self._focused_pane_id, 'h')
            # 找到新创建的空窗格
            for p in all_panes(self._layout_tree):
                if p.module is None:
                    target_pane_id = p.pane_id
                    break
        # 在目标窗格设置模块（布局树层面）
        target = find_pane(self._layout_tree, target_pane_id)
        if target:
            target.module = module_name
        # 整体 rebuild + 恢复全部状态
        await canvas.rebuild(self._layout_tree)
        self._restore_all_modules()
        self._set_focused_pane(target_pane_id)
        self._save_layout()

    def _restore_all_modules(self):
        """从 State 层恢复所有已打开模块的完整内容"""
        for pane in all_panes(self._layout_tree):
            if pane.module:
                self._restore_module(pane.module)

    def _restore_module(self, module_name: str):
        """从 State 恢复单个模块的完整内容到 Widget"""
        widget = self._get_module(module_name)
        if not widget:
            return
        st = self.state

        if module_name == 'chat' and isinstance(widget, ChatPanel):
            # 恢复频道
            widget.switch_channel(st.chat.current_channel)
            # 重放消息
            log = widget.query_one("#chat-log", RichLog)
            for entry in st.chat.entries:
                if entry[0] == MSG:
                    _, name, text, channel, time_str = entry
                    if channel == st.chat.current_channel:
                        log.write(f"{name}> {text}")
                elif entry[0] == SYS:
                    log.write(f"[dim]>>> {entry[1]}[/]")
                elif entry[0] == HISTORY:
                    _, messages, channel = entry
                    if channel == st.chat.current_channel:
                        log.clear()
                        for m in messages:
                            log.write(f"{m.get('name', '???')}> {m.get('text', '')}")
            # 恢复在线人数
            if st.chat.online_count:
                widget.border_subtitle = f"在线({st.chat.online_count})"

        elif module_name == 'cmd' and isinstance(widget, CommandPanel):
            log = widget.query_one("#cmd-log", RichLog)
            for line in st.cmd.lines:
                log.write(line)
            if st.cmd.action_bar:
                widget.border_subtitle = st.cmd.action_bar

        elif module_name == 'board' and isinstance(widget, BoardPanel):
            if st.board.player_data:
                widget.update_status(st.board.player_data)
            if st.board.map_data:
                widget.update_map(st.board.map_data)
            if st.board.room_data:
                widget.update_table(st.board.room_data)
            widget.set_location(st.board.location)

        elif module_name == 'status' and isinstance(widget, StatusPanel):
            if st.status.game_type and st.status.game_data:
                widget.update_game_status(st.status.game_type, st.status.game_data)
            else:
                log = widget.query_one("#status-content", RichLog)
                for line in st.status.lines:
                    log.write(line)

        elif module_name == 'online' and isinstance(widget, OnlineUsersPanel):
            if st.online.users:
                widget.update_users(st.online.users)

    # ── 布局操作 ──

    async def _do_split(self, direction: str):
        self._layout_tree = split_pane(self._layout_tree, self._focused_pane_id, direction)
        await self.canvas.rebuild(self._layout_tree)
        self._restore_all_modules()
        self._set_focused_pane(self._focused_pane_id)
        self._save_layout()

    async def _do_close_pane(self):
        panes = all_panes(self._layout_tree)
        if len(panes) <= 1:
            return  # 不关闭最后一个
        # 找到下一个窗格
        ids = [p.pane_id for p in panes]
        idx = ids.index(self._focused_pane_id) if self._focused_pane_id in ids else 0
        next_id = ids[(idx + 1) % len(ids)] if len(ids) > 1 else ""
        if next_id == self._focused_pane_id:
            next_id = ids[(idx - 1) % len(ids)]
        result = close_pane(self._layout_tree, self._focused_pane_id)
        if result is None:
            return
        self._layout_tree = result
        await self.canvas.rebuild(self._layout_tree)
        self._restore_all_modules()
        if next_id:
            self._set_focused_pane(next_id)
        self._save_layout()

    def _resize_focused(self, delta: float, direction: str = 'h'):
        """调整当前焦点窗格的权重，direction='h'横向/'v'纵向"""
        if resize_pane(self._layout_tree, self._focused_pane_id, delta, direction):
            self.canvas.sync_weights(self._layout_tree)
            self._save_layout()

    def _save_layout(self):
        """序列化布局并发送到服务端保存"""
        if not self.logged_in:
            return
        layout_data = serialize(self._layout_tree)
        self.app.network.send({"type": "save_layout", "layout": layout_data})

    def _update_location(self, location: str):
        self.current_location = location
        self.state.board.location = location
        indicator = self.query_one("#location-indicator", Static)
        board = self._get_module('board')
        if isinstance(board, BoardPanel):
            board.set_location(location)
            board.update_table(None)
        # 离开 JRPG 时清除地图数据，防止残留
        if location != 'jrpg' and self.state.board.map_data:
            self.state.board.map_data = None
        # 清除旧游戏状态面板
        self.state.board.room_data = None
        self.state.status.clear_game()
        status = self._get_module('status')
        if isinstance(status, StatusPanel):
            status.clear()
        indicator.update(location)

    # ── 键位处理 ──

    def on_key(self, event) -> None:
        vim = self.vim

        # ── INSERT 模式 ──
        if vim.mode == Mode.INSERT:
            event.prevent_default()
            event.stop()

            if event.key == "escape":
                self.action_enter_normal()
            elif event.key == "enter":
                self._submit_input()
            elif event.key == "backspace":
                self._input_buffer = self._input_buffer[:-1]
                self._update_panel_prompt(self._input_buffer)
            elif event.key == "space":
                self._input_buffer += " "
                self._update_panel_prompt(self._input_buffer)
            else:
                ch = event.character
                if ch and ch.isprintable():
                    self._input_buffer += ch
                    self._update_panel_prompt(self._input_buffer)
            return

        # ── NORMAL 模式 ──
        event.prevent_default()
        event.stop()
        key = event.key

        # 前缀键
        if vim.pending_key == "g":
            vim.pending_key = ""
            if key == "g":
                self._scroll_focused_top()
            return

        if vim.pending_key == "d":
            vim.pending_key = ""
            ch = event.character
            if ch and ch.isprintable():
                self._discard_tile(ch)
            return

        # which-key 菜单
        if self._which_key is not None:
            if key == "escape":
                self._hide_which_key()
            elif self._which_key == "top":
                if key == "e":
                    self._which_key = "modules"
                    self._picker_selected = 0
                    self._show_which_key("modules")
                elif key == "w":
                    self._which_key = "window"
                    self._show_which_key("window")
                elif key == "q":
                    self._hide_which_key()
                    self._send_command("/back")
                else:
                    self._hide_which_key()
            elif self._which_key == "modules":
                from .tui_layout import MODULES
                if key == "j":
                    self._picker_selected = (self._picker_selected + 1) % len(MODULES)
                    self._show_which_key("modules")
                elif key == "k":
                    self._picker_selected = (self._picker_selected - 1) % len(MODULES)
                    self._show_which_key("modules")
                elif key == "enter":
                    self._picker_confirm()
                else:
                    self._hide_which_key()
            elif self._which_key == "window":
                self._hide_which_key()
                if key == "slash":
                    self.call_later(self._do_split, 'h')
                elif key == "minus":
                    self.call_later(self._do_split, 'v')
                elif key in ("h", "j", "k", "l"):
                    new_id = navigate(self._layout_tree, self._focused_pane_id, key)
                    self._set_focused_pane(new_id)
                elif key == "H":
                    self._resize_focused(-0.25, 'h')
                elif key == "L":
                    self._resize_focused(0.25, 'h')
                elif key == "J":
                    self._resize_focused(0.25, 'v')
                elif key == "K":
                    self._resize_focused(-0.25, 'v')
                elif key == "q":
                    self.call_later(self._do_close_pane)
            return

        # 单键
        if key == "space":
            self._which_key = "top"
            self._show_which_key("top")
        elif key == "i":
            self._enter_insert()
        elif key == "j":
            self._scroll_focused_down()
        elif key == "k":
            self._scroll_focused_up()
        elif key == "G":
            self._scroll_focused_bottom()
        elif key == "g":
            vim.pending_key = "g"
        elif key == "d":
            if self.state.status.need_discard:
                vim.pending_key = "d"
        elif key == "q":
            self._send_command("/back")
        elif key == "tab":
            self._cycle_channel()
        elif event.character and event.character.isdigit() and event.character != "0":
            self._send_command(f"/{event.character}")

    # ── 输入提交 ──

    def _submit_input(self):
        text = self._input_buffer.strip()
        self._input_buffer = ""
        self._hide_panel_prompt()
        self.vim.enter_normal()
        self._update_mode_indicator()

        if not text:
            return

        if self._input_target == "chat":
            chat = self._get_module('chat')
            ch = chat.current_channel if isinstance(chat, ChatPanel) else 1
            self._send_chat(text, ch)
        else:
            if not self.logged_in:
                self._send_command(text)
            else:
                if not text.startswith("/"):
                    text = "/" + text
                self._send_command(text)
        if not self.logged_in:
            self._enter_insert()

    # ── 滚动 ──

    def _get_focused_log(self) -> RichLog | None:
        pane = find_pane(self._layout_tree, self._focused_pane_id)
        if not pane or not pane.module:
            return None
        widget = self._get_module(pane.module)
        if widget is None:
            return None
        # 找到该 widget 内的 RichLog
        try:
            logs = widget.query(RichLog)
            return logs.first() if logs else None
        except Exception:
            return None

    def _scroll_focused_down(self):
        log = self._get_focused_log()
        if log:
            log.scroll_down(animate=False)

    def _scroll_focused_up(self):
        log = self._get_focused_log()
        if log:
            log.scroll_up(animate=False)

    def _scroll_focused_bottom(self):
        log = self._get_focused_log()
        if log:
            log.scroll_end(animate=False)

    def _scroll_focused_top(self):
        log = self._get_focused_log()
        if log:
            log.scroll_home(animate=False)

    # ── 指令发送 ──

    def _send_command(self, text: str):
        self.app.send_command(text)

    def _send_chat(self, text: str, channel: int):
        self.app.send_chat(text, channel)

    def _discard_tile(self, tile_name: str):
        self._send_command(f"/d {tile_name}")

    def _cycle_channel(self):
        chat = self._get_module('chat')
        if not isinstance(chat, ChatPanel):
            return
        ch = chat.current_channel
        new_ch = 2 if ch == 1 else 1
        self.state.chat.switch_channel(new_ch)
        chat.switch_channel(new_ch)
        self.app.switch_channel(new_ch)

    # ── 操作提示 ──

    def show_action_prompt(self, actions: dict, tile: str, from_player: str):
        parts = []
        idx = 1
        for action_name, label in [("ron", "荣和"), ("pon", "碰"), ("kan", "杠")]:
            if action_name in actions:
                parts.append(f"[{idx}]{label}")
                idx += 1
        if "chi" in actions:
            chi_opts = actions["chi"]
            if isinstance(chi_opts, list):
                for c in chi_opts:
                    parts.append(f"[{idx}]吃{c}")
                    idx += 1
            else:
                parts.append(f"[{idx}]吃")
                idx += 1
        parts.append(f"[{idx}]跳过")
        bar_text = f"{from_player}打出 {tile}: {' '.join(parts)}"
        self.state.cmd.set_action_bar(bar_text)
        cmd = self._get_module('cmd')
        if isinstance(cmd, CommandPanel):
            cmd.set_action_bar(bar_text)

    def show_self_action_prompt(self, actions: dict):
        parts = []
        idx = 1
        if "tsumo" in actions:
            parts.append(f"[{idx}]自摸"); idx += 1
        if "riichi" in actions:
            parts.append(f"[{idx}]立直"); idx += 1
        if "ankan" in actions:
            for tiles in actions["ankan"]:
                parts.append(f"[{idx}]暗杠{tiles}"); idx += 1
        if "kakan" in actions:
            for tile in actions["kakan"]:
                parts.append(f"[{idx}]加杠{tile}"); idx += 1
        parts.append(f"[{idx}]跳过")
        bar_text = " ".join(parts)
        self.state.cmd.set_action_bar(bar_text)
        cmd = self._get_module('cmd')
        if isinstance(cmd, CommandPanel):
            cmd.set_action_bar(bar_text)


# ═══════════════════════════════════════════════════════
#  GameLobbyApp — 主应用
# ═══════════════════════════════════════════════════════


class GameLobbyApp(App):
    """游戏大厅 TUI 客户端"""

    TITLE = "游戏大厅"
    CSS_PATH = "theme.tcss"

    BINDINGS = [
        Binding("ctrl+c", "quit", "退出", show=True, priority=True),
    ]

    def __init__(self, **kw):
        super().__init__(**kw)
        self.network = NetworkManager(PORT)
        self.vim = VimMode()
        self.player_data: dict = {}
        self._pending_messages: list[dict] = []
        self._current_channel = 1
        self._saved_layout: dict | None = None

    def on_mount(self) -> None:
        self.push_screen(LoginScreen())

    # ── 网络 ──

    def connect_to_server(self, ip: str):
        """从 LoginScreen 调用，建立连接"""
        try:
            self.network.connect(ip)
        except Exception as e:
            screen = self.screen
            if isinstance(screen, LoginScreen):
                screen.set_status(f"连接失败: {e}")
            return

        self.network.disconnect_callback = self._on_disconnect
        self._start_receive_worker()

        # 切换到游戏界面
        self.switch_screen(GameScreen(layout_data=self._saved_layout))

        # 处理缓冲消息
        for msg in self._pending_messages:
            self.post_message(ServerMsg(msg))
        self._pending_messages.clear()

    @work(thread=True)
    def _start_receive_worker(self):
        """后台线程：接收服务器消息并投递到事件循环"""
        buffer = ""
        import json
        while self.network.connected:
            try:
                data = self.network.socket.recv(4096)
                if not data:
                    break
                buffer += data.decode("utf-8")
                while "\n" in buffer:
                    msg_str, buffer = buffer.split("\n", 1)
                    if msg_str:
                        try:
                            msg = json.loads(msg_str)
                            self.post_message(ServerMsg(msg))
                        except Exception:
                            pass
            except Exception:
                break

        self.network.connected = False
        self.post_message(Disconnected())

    def _on_disconnect(self):
        self.post_message(Disconnected())

    def on_disconnected(self, _msg: Disconnected) -> None:
        """处理连接断开"""
        screen = self.screen
        if isinstance(screen, GameScreen):
            screen.state.cmd.add_line("[dim]连接已断开[/]")
            cmd = screen._get_module('cmd')
            if isinstance(cmd, CommandPanel):
                cmd.add_message("[dim]连接已断开[/]")
            try:
                conn = screen.query_one("#connection-status", Static)
                conn.update("已断开")
            except Exception:
                pass

    # ── 消息处理 ──

    def on_server_msg(self, event: ServerMsg) -> None:
        """统一处理服务器消息"""
        screen = self.screen
        if not isinstance(screen, GameScreen):
            self._pending_messages.append(event.data)
            return

        parsed = parse_server_message(event.data)
        gs = screen
        st = gs.state

        # 获取模块的便捷方法
        def _chat() -> ChatPanel | None:
            w = gs._get_module('chat')
            return w if isinstance(w, ChatPanel) else None

        def _cmd() -> CommandPanel | None:
            w = gs._get_module('cmd')
            return w if isinstance(w, CommandPanel) else None

        def _board() -> BoardPanel | None:
            w = gs._get_module('board')
            return w if isinstance(w, BoardPanel) else None

        def _status() -> StatusPanel | None:
            w = gs._get_module('status')
            return w if isinstance(w, StatusPanel) else None

        def _online() -> OnlineUsersPanel | None:
            w = gs._get_module('online')
            return w if isinstance(w, OnlineUsersPanel) else None

        if isinstance(parsed, LoginPrompt):
            st.cmd.add_line(parsed.text)
            cmd = _cmd()
            if cmd:
                cmd.add_message(parsed.text)

        elif isinstance(parsed, RequestAvatar):
            st.cmd.add_line(parsed.text)
            st.cmd.add_line("[dim]（TUI 模式下暂不支持编辑头像，跳过）[/]")
            cmd = _cmd()
            if cmd:
                cmd.add_message(parsed.text)
                cmd.add_message("[dim]（TUI 模式下暂不支持编辑头像，跳过）[/]")

        elif isinstance(parsed, LoginSuccess):
            gs.logged_in = True
            st.cmd.add_line(parsed.text)
            cmd = _cmd()
            if cmd:
                cmd.add_message(parsed.text)
            gs.action_enter_normal()

        elif isinstance(parsed, SystemMessage):
            st.chat.add_system_message(parsed.text)
            chat = _chat()
            if chat:
                chat.add_system_message(parsed.text)

        elif isinstance(parsed, GameMessage):
            st.cmd.add_line(parsed.text)
            cmd = _cmd()
            if cmd:
                cmd.add_message(parsed.text, update_last=parsed.update_last)
            if parsed.clear_discard:
                st.status.need_discard = False

        elif isinstance(parsed, ChatMessage):
            st.chat.add_message(parsed.name, parsed.text, parsed.channel, parsed.time)
            chat = _chat()
            if chat:
                chat.add_message(parsed.name, parsed.text, parsed.channel, parsed.time)

        elif isinstance(parsed, ChatHistory):
            st.chat.set_history(parsed.messages, parsed.channel)
            chat = _chat()
            if chat:
                chat.show_history(parsed.messages, parsed.channel)

        elif isinstance(parsed, StatusUpdate):
            self.player_data = parsed.data
            st.board.player_data = parsed.data
            if parsed.map_data:
                st.board.map_data = parsed.map_data
            # 保存布局数据
            layout_data = parsed.data.get('window_layout')
            if layout_data:
                self._saved_layout = layout_data
            board = _board()
            if board:
                board.update_status(parsed.data)
            if parsed.map_data and board:
                board.update_map(parsed.map_data)

        elif isinstance(parsed, OnlineUsers):
            st.online.users = parsed.users
            st.chat.update_online_count(parsed.users)
            chat = _chat()
            if chat:
                chat.update_online_users(parsed.users)
            online = _online()
            if online:
                online.update_users(parsed.users)

        elif isinstance(parsed, GameInvite):
            inv = parsed.raw
            invite_text = f"[b]游戏邀请[/b]: {inv.get('from', '?')} 邀请你加入 {inv.get('game', '?')}"
            st.cmd.add_line(invite_text)
            cmd = _cmd()
            if cmd:
                cmd.add_message(invite_text)

        elif isinstance(parsed, RoomUpdate):
            if parsed.room_data:
                st.board.room_data = parsed.room_data
                board = _board()
                if board:
                    board.update_table(parsed.room_data)
                room_id = parsed.room_data.get("room_id")
                if room_id:
                    gs.current_room_id = room_id
                game_type = parsed.room_data.get("game_type", "")
                state = parsed.room_data.get("state", "waiting")
                # 通用：有对局状态时更新状态面板
                if state == "playing":
                    st.status.update_game_status(game_type, parsed.room_data)
                    status = _status()
                    if status:
                        status.update_game_status(game_type, parsed.room_data)
            if parsed.message:
                st.cmd.add_line(parsed.message)
                cmd = _cmd()
                if cmd:
                    cmd.add_message(parsed.message)

        elif isinstance(parsed, (RoomLeave, GameQuit)):
            st.board.room_data = None
            st.status.clear_game()
            board = _board()
            if board:
                board.update_table(None)
            status = _status()
            if status:
                status.clear()
            gs.current_room_id = None
            if parsed.location:
                gs._update_location(parsed.location)

        elif isinstance(parsed, LocationUpdate):
            gs._update_location(parsed.location)

        elif isinstance(parsed, HandUpdate):
            game_type = st.status.game_type or "mahjong"
            game_data = {
                "hand": parsed.hand,
                "drawn": parsed.drawn,
                "tenpai": parsed.tenpai_analysis,
                "need_discard": parsed.need_discard,
            }
            st.status.update_game_status(game_type, game_data)
            status = _status()
            if status:
                status.update_game_status(game_type, game_data)

        elif isinstance(parsed, ActionPrompt):
            gs.show_action_prompt(parsed.actions, parsed.tile, parsed.from_player)

        elif isinstance(parsed, SelfActionPrompt):
            gs.show_self_action_prompt(parsed.actions)

        elif isinstance(parsed, WinAnimation):
            self._show_win_animation(gs, parsed)

        elif isinstance(parsed, ActionCommand):
            action = parsed.action
            if action == "clear":
                st.cmd.clear()
                cmd = _cmd()
                if cmd:
                    cmd.clear()
            elif action == "version":
                sv = parsed.raw.get("server_version", "未知")
                cv = VERSION or "开发版"
                ver_text = f"版本信息\n客户端: v{cv}\n服务器: v{sv}"
                st.cmd.add_line(ver_text)
                cmd = _cmd()
                if cmd:
                    cmd.add_message(ver_text)
            elif action == "exit":
                self.network.disconnect()
                self.exit()
            elif action == "maintenance":
                maint_text = "[b]系统维护[/b]: 服务器正在维护，请稍后重连。"
                st.cmd.add_line(maint_text)
                cmd = _cmd()
                if cmd:
                    cmd.add_message(maint_text)
                self.network.disconnect()

    def _show_win_animation(self, gs: GameScreen, w: WinAnimation):
        st = gs.state
        cmd = gs._get_module('cmd')
        if not isinstance(cmd, CommandPanel):
            # 即使没有展示 Widget，也要写入 State
            if w.win_type == "tsumo":
                header = f"[b]【{w.winner} 自摸】[/b] [{w.tile}]"
            else:
                header = f"[b]【{w.winner} 荣和】[/b] [{w.tile}]"
                if w.loser:
                    header += f" (放铳: {w.loser})"
            st.cmd.add_line(header)
            for yaku in w.yakus:
                yaku_name = yaku[0]
                yaku_han = yaku[1]
                is_yakuman = yaku[2] if len(yaku) > 2 else False
                if is_yakuman:
                    st.cmd.add_line(f"  ★ {yaku_name} (役满)")
                else:
                    st.cmd.add_line(f"  · {yaku_name} ({yaku_han}番)")
            if w.is_yakuman:
                st.cmd.add_line(f"\n[b]【点数】役满 {w.score}点[/b]")
            else:
                st.cmd.add_line(f"\n[b]【点数】{w.han}番{w.fu}符 = {w.score}点[/b]")
            st.cmd.add_line("\n输入 /next 开始下一局")
            return

        if w.win_type == "tsumo":
            header = f"[b]【{w.winner} 自摸】[/b] [{w.tile}]"
        else:
            header = f"[b]【{w.winner} 荣和】[/b] [{w.tile}]"
            if w.loser:
                header += f" (放铳: {w.loser})"
        st.cmd.add_line(header)
        cmd.add_message(header)

        delay = 0.8
        for i, yaku in enumerate(w.yakus):
            yaku_name = yaku[0]
            yaku_han = yaku[1]
            is_yakuman = yaku[2] if len(yaku) > 2 else False
            if is_yakuman:
                text = f"  ★ {yaku_name} (役满)"
            else:
                text = f"  · {yaku_name} ({yaku_han}番)"
            st.cmd.add_line(text)
            self.set_timer(delay * (i + 1), lambda t=text: self._add_to_cmd(t))

        final_delay = delay * (len(w.yakus) + 1)
        if w.is_yakuman:
            score_text = f"\n[b]【点数】役满 {w.score}点[/b]"
        else:
            score_text = f"\n[b]【点数】{w.han}番{w.fu}符 = {w.score}点[/b]"

        st.cmd.add_line(score_text)
        self.set_timer(final_delay, lambda: self._add_to_cmd(score_text))
        next_text = "\n输入 /next 开始下一局"
        st.cmd.add_line(next_text)
        self.set_timer(
            final_delay + 0.4,
            lambda: self._add_to_cmd(next_text),
        )

    def _add_to_cmd(self, text: str):
        screen = self.screen
        if isinstance(screen, GameScreen):
            # _add_to_cmd 仅用于延时回调（动画），State 已在调用侧写入
            cmd = screen._get_module('cmd')
            if isinstance(cmd, CommandPanel):
                cmd.add_message(text)

    # ── 发送 ──

    def send_command(self, text: str):
        self.network.send({"type": "command", "text": text})

    def send_chat(self, text: str, channel: int):
        self.network.send({"type": "chat", "text": text, "channel": channel})

    def switch_channel(self, channel_id: int):
        self._current_channel = channel_id
        self.network.send({"type": "switch_channel", "channel": channel_id})

    # ── 退出 ──

    def action_quit(self) -> None:
        self.network.disconnect()
        self.exit()


def _check_version() -> bool:
    """检查是否最新版，返回 True 表示可以启动"""
    import json
    import urllib.request
    import sys
    current = VERSION or "0.0.0"
    print(f"gamelobby v{current}")
    print("正在检查更新...")
    try:
        req = urllib.request.Request(
            "https://pypi.org/pypi/gamelobby/json",
            headers={"Accept": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            latest = json.loads(resp.read().decode())["info"]["version"]
        cur = tuple(int(x) for x in current.split("."))
        lat = tuple(int(x) for x in latest.split("."))
        if lat > cur:
            print(f"\n发现新版本 v{latest}（当前 v{current}）")
            choice = input("是否立即更新？(y/N): ").strip().lower()
            if choice == 'y':
                import subprocess
                pip_cmd = [sys.executable, "-m", "pip", "install", "--upgrade", "gamelobby"]
                if sys.platform == "win32":
                    # Windows: 当前进程持有文件锁，需要启动独立进程等待本进程退出后再升级
                    # cmd /c 'timeout /t 2 /nobreak >nul & pip upgrade & gamelobby'
                    script = (
                        f'timeout /t 2 /nobreak >nul'
                        f' & "{sys.executable}" -m pip install --upgrade gamelobby'
                        f' & echo.'
                        f' & echo 更新完成，正在重新启动...'
                        f' & "{sys.executable}" -m client'
                    )
                    subprocess.Popen(
                        f'cmd /c "{script}"',
                        creationflags=subprocess.CREATE_NEW_CONSOLE,
                    )
                    print("正在后台更新，当前窗口即将关闭...")
                else:
                    # Unix: 无文件锁问题，直接同步升级
                    print("正在更新...")
                    subprocess.run(pip_cmd)
                    print("\n更新完成，请重新运行 gamelobby\n")
                return False
            else:
                print("已跳过更新。\n")
                return True
    except Exception:
        pass
    print()
    return True


def main():
    """CLI 入口点"""
    if not _check_version():
        return
    app = GameLobbyApp()
    app.run()
