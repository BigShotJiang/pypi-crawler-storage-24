import numpy as np
import wave
import pyaudio
import time
from PyFT8.callhashes import call_hashes, add_call_hashes

#==================== AUDIO OUT ================================================================

class AudioOut:

    def find_device(self, device_str_contains):
        pya = pyaudio.PyAudio()
        for dev_idx in range(pya.get_device_count()):
            name = pya.get_device_info_by_index(dev_idx)['name']
            match = True
            for pattern in device_str_contains:
                if (not pattern in name): match = False
            if(match):
                return dev_idx
        print(f"[Audio] No outout audio device found matching {device_str_contains}")

    def create_ft8_symbols(self, tx_msg):
        c1, c2, grid_rpt = tx_msg.split()
        return pack_message(c1, c2, grid_rpt)

    def create_ft8_wave(self, symbols, fs=12000, f_base=873.0, f_step=6.25, amplitude = 0.5):
        symbol_len = int(fs * 0.160)
        t = np.arange(symbol_len) / fs
        phase = 0
        waveform = []
        for s in symbols:
            f = f_base + s * f_step
            phase_inc = 2 * np.pi * f / fs
            w = np.sin(phase + phase_inc * np.arange(symbol_len))
            waveform.append(w)
            phase = (phase + phase_inc * symbol_len) % (2 * np.pi)
        waveform = np.concatenate(waveform).astype(np.float32)
        waveform = waveform.astype(np.float32)
        waveform = amplitude * waveform / np.max(np.abs(waveform))
        waveform_int16 = np.int16(waveform * 32767)
        return waveform_int16

    def write_to_wave_file(self, audio_data, wave_file):
        wavefile = wave.open(wave_file, 'wb')
        wavefile.setframerate(12000)
        wavefile.setnchannels(1)
        wavefile.setsampwidth(2)
        wavefile.writeframes(audio_data.tobytes())
        wavefile.close()

    def play_data_to_soundcard(self, audio_data_int16, output_device_idx, fs=12000):
        stream = pyaudio.PyAudio().open(format=pyaudio.paInt16, channels=1, rate=fs,
                          output=True,
                          output_device_index = output_device_idx)
        stream.write(audio_data_int16.tobytes())
        stream.stop_stream()
        stream.close()

#==================== PACK AND ENCODE ================================================================
generator_matrix_rows = ["8329ce11bf31eaf509f27fc",  "761c264e25c259335493132",  "dc265902fb277c6410a1bdc",  "1b3f417858cd2dd33ec7f62",  "09fda4fee04195fd034783a",  "077cccc11b8873ed5c3d48a",  "29b62afe3ca036f4fe1a9da",  "6054faf5f35d96d3b0c8c3e",  "e20798e4310eed27884ae90",  "775c9c08e80e26ddae56318",  "b0b811028c2bf997213487c",  "18a0c9231fc60adf5c5ea32",  "76471e8302a0721e01b12b8",  "ffbccb80ca8341fafb47b2e",  "66a72a158f9325a2bf67170",  "c4243689fe85b1c51363a18",  "0dff739414d1a1b34b1c270",  "15b48830636c8b99894972e",  "29a89c0d3de81d665489b0e",  "4f126f37fa51cbe61bd6b94",  "99c47239d0d97d3c84e0940",  "1919b75119765621bb4f1e8",  "09db12d731faee0b86df6b8",  "488fc33df43fbdeea4eafb4",  "827423ee40b675f756eb5fe",  "abe197c484cb74757144a9a",  "2b500e4bc0ec5a6d2bdbdd0",  "c474aa53d70218761669360",  "8eba1a13db3390bd6718cec",  "753844673a27782cc42012e",  "06ff83a145c37035a5c1268",  "3b37417858cc2dd33ec3f62",  "9a4a5a28ee17ca9c324842c",  "bc29f465309c977e89610a4",  "2663ae6ddf8b5ce2bb29488",  "46f231efe457034c1814418",  "3fb2ce85abe9b0c72e06fbe",  "de87481f282c153971a0a2e",  "fcd7ccf23c69fa99bba1412",  "f0261447e9490ca8e474cec",  "4410115818196f95cdd7012",  "088fc31df4bfbde2a4eafb4",  "b8fef1b6307729fb0a078c0",  "5afea7acccb77bbc9d99a90",  "49a7016ac653f65ecdc9076",  "1944d085be4e7da8d6cc7d0",  "251f62adc4032f0ee714002",  "56471f8702a0721e00b12b8",  "2b8e4923f2dd51e2d537fa0",  "6b550a40a66f4755de95c26",  "a18ad28d4e27fe92a4f6c84",  "10c2e586388cb82a3d80758",  "ef34a41817ee02133db2eb0",  "7e9c0c54325a9c15836e000",  "3693e572d1fde4cdf079e86",  "bfb2cec5abe1b0c72e07fbe",  "7ee18230c583cccc57d4b08",  "a066cb2fedafc9f52664126",  "bb23725abc47cc5f4cc4cd2",  "ded9dba3bee40c59b5609b4",  "d9a7016ac653e6decdc9036",  "9ad46aed5f707f280ab5fc4",  "e5921c77822587316d7d3c2",  "4f14da8242a8b86dca73352",  "8b8b507ad467d4441df770e",  "22831c9cf1169467ad04b68",  "213b838fe2ae54c38ee7180",  "5d926b6dd71f085181a4e12",  "66ab79d4b29ee6e69509e56",  "958148682d748a38dd68baa",  "b8ce020cf069c32a723ab14",  "f4331d6d461607e95752746",  "6da23ba424b9596133cf9c8",  "a636bcbc7b30c5fbeae67fe",  "5cb0d86a07df654a9089a20",  "f11f106848780fc9ecdd80a",  "1fbb5364fb8d2c9d730d5ba",  "fcb86bc70a50c9d02a5d034",  "a534433029eac15f322e34c",  "c989d9c7c3d3b8c55d75130",  "7bb38b2f0186d46643ae962",  "2644ebadeb44b9467d1f42c",  "608cc857594bfbb55d69600"]
kGEN = np.array([int(row,16)>>1 for row in generator_matrix_rows])

def pack_message(c1, c2, gr):
    symbols, bits77 = _pack_message(c1, c2, gr)
    return symbols

def _pack_message(c1, c2, gr):
    c28a, p1a = pack_ft8_c28(c1)
    c28b, p1b = pack_ft8_c28(c2)
    g15, ir = pack_ft8_g15(gr)
    i3 = 2 if p1a or p1b else 1
    n3 = 0
    symbols, bits77 = [], 0
    if(c28a>=0 and c28b>=0):
        bits77 = (c28a<<28+1+1+1+15+3) | (p1a<<28+1+1+15+3) | (c28b<<1+1+15+3) | (p1b <<1+15+3) | (ir<<15+3) | (g15<< 3) | (i3)
        symbols  = encode_bits77(bits77)
    if not any(symbols):
        i3 = 4
        full_call = c1 if c28b>0 else c2
        hash_call = c2 if c28b>0 else c1
        c58 = pack_ft8_c58(full_call)
        hashes = add_call_hashes(hash_call)
        swp = 1 if hash_call == c2 else 0
        rrr, cq_ = 0, 0
        if gr in ('RRR', 'RR73', '73'):
            rrr = ('', 'RRR', 'RR73', '73').index(gr)
        bits77 = (hashes[1]<<58+1+2+1+3) | (c58 <<1+2+1+3) | (swp<<2+1+3) | (rrr<<1+3) | (cq_<<3) | (i3)
        symbols  = encode_bits77(bits77)
    return symbols, bits77


def pack_ft8_c58(call):
    chars = " 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ/"
    n58=0
    call = (call + "          ")[:11]
    for i in range(0,11):
        n58 = n58*38 + chars.index(call[i])
    return n58

def pack_ft8_c28(call):
    if '/' in call and not call.endswith("P") and not call.endswith("R"): return -1, 0
    tkns = ['DE','QRZ','CQ']
    if (call in tkns):
        c28, p1 = tkns.index(call), 0
    else:
        p1 = 1 if call[-2:] == '/P' else 0
        call = call.replace('/P','')
        if len(call) > 6:
            return -1, 0
        prepend_space = '' if call[2].isdigit() else ' '
        call = (prepend_space + call + '  ')[:6]
        a = ' 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'
        b = ' ABCDEFGHIJKLMNOPQRSTUVWXYZ'
        x = [a.index(call[0]),  a.index(call[1])-1, a.index(call[2])-1, b.index(call[3]),   b.index(call[4]), b.index(call[5]), 1                    ]
        y = [36*10*27*27*27,    10*27*27*27,        27*27*27,           27*27,              27,               1,                2_063_592 + 4_194_304]
        c28 = int(np.dot(x,y))
    return c28, p1

def pack_ft8_g15(txt):
    ir = 0
    if txt.startswith('-') or txt.startswith('+'): #verified via audio -> wsjt-x
        n = int(txt)
        return 32400 + 35 + n , ir
    if txt.startswith('R-') or txt.startswith('R+'): #verified via audio -> wsjt-x
        ir = 1
        n = int(txt[1:])
        return 32400 + 35 + n  , ir
    if txt == 'RRR': #verified via audio -> wsjt-x
        return 32402 , ir
    if txt == 'RR73': #verified via audio -> wsjt-x
        return 32403 , ir
    if txt == '73': #verified via audio -> wsjt-x
        return 32404 , ir
    if(len(txt) != 4):
        return 0, ir
    v = (ord(txt[0].upper()) - 65)
    v = v * 18 + (ord(txt[1].upper()) - 65)
    v = v * 10 + int(txt[2])
    v = v * 10 + int(txt[3])
    return int(v), ir

def ldpc_encode(msg_crc: int) -> int:
    msg_crc = int(msg_crc)
    parity_bits = 0
    for row in map(int, kGEN):
        bit = bin(msg_crc & row).count("1") & 1
        parity_bits = (parity_bits << 1) | bit
    return (msg_crc << 83) | parity_bits, parity_bits

def gray_encode(bits: int) -> list[int]:
    syms = []
    gray_seq = [0,1,3,2,5,6,4,7]
    for _ in range(174 // 3):
        chunk = bits & 0x7
        syms.insert(0, gray_seq[chunk])
        bits >>= 3
    return syms

def encode_bits77(bits77_int):
    bits91_int, bits14_int = append_crc(bits77_int)
    bits174_int, bits83_int = ldpc_encode(bits91_int)
    syms = gray_encode(bits174_int)
    costas=[3,1,4,0,6,5,2]
    return costas + syms[:29] + costas + syms[29:] + costas

def append_crc(bits77_int):
    poly = 0x2757
    width = 14
    mask = (1 << width) - 1
    # Pad to 96 bits (77 + 14 + 5)
    nbits = 96
    bits14_int = 0
    for i in range(nbits):
        # bits77 is expected MSB-first (bit 76 first)
        inbit = ((bits77_int >> (76 - i)) & 1) if i < 77 else 0
        bit14 = (bits14_int >> (width - 1)) & 1
        bits14_int = ((bits14_int << 1) & mask) | inbit
        if bit14:
            bits14_int ^= poly
    bits91_int = (bits77_int << 14) | bits14_int
    return bits91_int, bits14_int

#==================== TESTS ================================================================

if __name__ == "__main__":
    OK = True
    msgs = [("G1OJS/P", "G1OJS/P", "IO90"),("WM3PEN","EA6VQ","+08"),("E67A/P","EA6VQ","R-08"),
            ("CQ","CT7ARQ/P","RRR"), ("EC5A","9A5E","RR73"), ("EC5A/P","9A5E","73"), ("EC5A/MM","9A5E","73")]
    for msg_tx in msgs:
        symbols, bits77 = _pack_message(*msg_tx)
        from PyFT8.receiver import unpack
        msg_rx = unpack(bits77)
        print(f"\n{msg_tx}\n{msg_rx}")
        OK = OK and (msg_tx == msg_rx) or 'implemented' in msg_rx
        #print(''.join([str(s) for s in symbols]))
    print("\nPASSED" if OK else "\nFAILED")
        
