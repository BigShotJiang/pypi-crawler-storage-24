"""
minson - Minify JSON to reduce LLM API token costs.
"""

from .core import minify

__version__ = "0.1.0"
__all__ = ["minify"]