# minson

**min**ify + **json** — strip

## Install

```bash
pip install minson
```

## Usage

### In Python

```python
from minson import minify

# From a dict/list
minify({"name": "Alice", "age": 30})
# → '{"name":"Alice","age":30}'

# From a JSON string
minify('{ "name": "Alice",  "age": 30 }')
# → '{"name":"Alice","age":30}'

# From a file
minify("/path/to/data.json")
# → '{"name":"Alice","age":30}'
```

### Check your savings

```python
from minson.core import token_savings

stats = token_savings({"name": "Alice", "age": 30, "city": "London"})
# {
#   'original_chars': 48,
#   'minified_chars': 38,
#   'chars_saved': 10,
#   'estimated_pct_saved': 20.8,
#   'estimated_tokens_saved': 2
# }
```

### Minify a file (and write output)

```python
from minson.core import minify_file

minify_file("data.json", "data.min.json")
```

### From the command line

```bash
# Print minified JSON
minson data.json

# Write to file
minson data.json --output data.min.json

# Show token savings stats
minson data.json --stats

# Pipe from stdin
echo '{"a": 1, "b": 2}' | minson -
```

## Why?

LLM APIs charge per token. Pretty-printed or verbose JSON wastes tokens on whitespace that carries no meaning. Minifying before sending data to the API is one of the simplest, zero-effort ways to cut costs.

| Format              | Relative token cost |
|---------------------|---------------------|
| Pretty JSON         | 100% (baseline)     |
| Minified JSON       | ~69–80%             |
| YAML                | ~82%                |
| XML                 | ~114%               |

## License

MIT