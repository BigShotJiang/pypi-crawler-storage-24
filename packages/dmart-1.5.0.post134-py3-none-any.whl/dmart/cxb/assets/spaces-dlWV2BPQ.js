import{w as s}from"./svelte-B52u0Ccc.js";const o=s(null);export{o as s};
