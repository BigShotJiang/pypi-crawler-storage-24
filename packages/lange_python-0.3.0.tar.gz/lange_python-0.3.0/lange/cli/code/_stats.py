from pathlib import Path
from typing import Iterable
import os
import click

SUPPORTED_EXTENSIONS: tuple[str, ...] = (
    # Python
    ".py",
    # JavaScript / TypeScript / React
    ".js", ".jsx", ".ts", ".tsx",
    # Web (Markup / Styling)
    ".html", ".css", ".scss", ".sass", ".less",
    # Shell / Bash
    ".sh", ".bash", ".zsh",
    # C / C++
    ".c", ".h", ".cpp", ".hpp", ".cc", ".cxx",
    # Java
    ".java",
    # C#
    ".cs",
    # Ruby
    ".rb",
    # PHP
    ".php",
    # Go
    ".go",
    # Rust
    ".rs",
    # Swift
    ".swift",
    # Kotlin
    ".kt",
    # Dart
    ".dart",
    # Lua
    ".lua",
    # SQL
    ".sql",
    # R
    ".r",
    # Perl
    ".pl",
    # Scala
    ".scala",
)

IGNORED_DIRECTORIES: tuple[str, ...] = (
    ".venv", "venv", "env",
    "node_modules",
    ".git",
    ".next",
    "__pycache__",
    "build",
    "dist",
    "target",
    "vendor",
    ".idea",
    ".vscode"
)


def _render_stats_table(stats: dict[str, int]) -> str:
    """
    Render LOC statistics as an ASCII box table.

    :param stats: Mapping from file ending to line count.
    :returns: Table string with file type, LOC and percentage values.
    """
    total = sum(stats.values())
    rows: list[tuple[str, str, str]] = []

    for extension, loc in sorted(stats.items(), key=lambda item: (-item[1], item[0])):
        # Skip extensions with 0 lines to keep the table clean
        if loc == 0:
            continue

        percentage = (loc / total * 100.0) if total else 0.0
        rows.append((extension, str(loc), f"{percentage:.2f}%"))

    total_percentage = 100.0 if total else 0.0
    rows.append(("TOTAL", str(total), f"{total_percentage:.2f}%"))

    headers = ("File-Type", "LOC", "Percentage")
    col_widths = [
        max(len(headers[index]), max((len(row[index]) for row in rows), default=0))
        for index in range(3)
    ]

    border = "+" + "+".join("-" * (width + 2) for width in col_widths) + "+"

    def _render_row(values: tuple[str, str, str]) -> str:
        padded = [value.ljust(col_widths[index]) for index, value in enumerate(values)]
        return "| " + " | ".join(padded) + " |"

    lines = [border, _render_row(headers), border]
    lines.extend(_render_row(row) for row in rows)
    lines.append(border)
    return "\n".join(lines)


def _count_lines_by_extension(root: Path, extensions: Iterable[str]) -> dict[str, int]:
    """
    Count file lines recursively grouped by file ending.

    :param root: Directory that should be scanned recursively.
    :param extensions: Allowed file endings, including the leading dot.
    :returns: Mapping from file ending to counted LOC.
    """
    normalized_extensions = tuple(extension.lower() for extension in extensions)
    counts = {extension: 0 for extension in normalized_extensions}

    for current_root, directories, files in os.walk(root, topdown=True):
        directories[:] = [name for name in directories if name not in IGNORED_DIRECTORIES]

        for file_name in files:
            suffix = Path(file_name).suffix.lower()
            if suffix not in counts:
                continue

            file_path = Path(current_root) / file_name
            try:
                with file_path.open("r", encoding="utf-8", errors="ignore") as file_handle:
                    counts[suffix] += sum(1 for _ in file_handle)
            except Exception:
                # Silently skip files that can't be opened (e.g., permissions issues)
                pass

    return counts


@click.command("stats")
def code_stats() -> None:
    """
    Print LOC statistics for the current working directory.

    :returns: ``None``.
    """
    stats = _count_lines_by_extension(Path.cwd(), SUPPORTED_EXTENSIONS)

    # Filter out empty languages for the recognized printout so it's not overwhelming
    active_extensions = [ext for ext, count in stats.items() if count > 0]

    click.echo()
    click.echo()
    click.echo(f"Recognized file endings found: {' '.join(active_extensions) if active_extensions else 'None'}")
    click.echo(f"Ignored folders: {' '.join(IGNORED_DIRECTORIES)}")
    click.echo(_render_stats_table(stats))


if __name__ == '__main__':
    code_stats()