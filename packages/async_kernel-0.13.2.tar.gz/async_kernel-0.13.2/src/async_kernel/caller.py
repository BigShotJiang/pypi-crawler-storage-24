from __future__ import annotations

import asyncio
import contextlib
import contextvars
import inspect
import logging
import reprlib
import sys
import threading
import time
import weakref
from collections import deque
from collections.abc import AsyncGenerator, Awaitable, Callable
from contextlib import asynccontextmanager
from types import CoroutineType, coroutine
from typing import TYPE_CHECKING, Any, ClassVar, Generic, Literal, Self, Unpack, cast, final

import anyio
import anyio.from_thread
from aiologic import BinarySemaphore, Event
from aiologic.lowlevel import async_checkpoint, create_async_event, create_async_waiter, current_async_library
from aiologic.meta import await_for
from anyio.lowlevel import current_token
from typing_extensions import override
from wrapt import lazy_import

import async_kernel.event_loop
from async_kernel import utils
from async_kernel.common import Fixed
from async_kernel.event_loop.run import Host, get_start_guest_run
from async_kernel.pending import Pending, PendingCancelled, PendingGroup, PendingManager, PendingTracker
from async_kernel.typing import Backend, CallerCreateOptions, CallerState, Loop, NoValue, RunSettings, T

with contextlib.suppress(ImportError):
    # Monkey patch sniffio.current_async_library` with aiologic's version which does a better job.
    import sniffio

    sniffio.current_async_library = current_async_library

if TYPE_CHECKING:
    from collections.abc import Iterable
    from types import CoroutineType

    import zmq
    from anyio.abc import TaskGroup

    from async_kernel.typing import P

__all__ = ["Caller", "PendingGroup"]

truncated_rep = reprlib.Repr()
truncated_rep.maxlevel = 1
truncated_rep.maxother = 100
truncated_rep.fillvalue = "…"


def noop() -> None:
    pass


trio_checkpoint: Callable[[], Awaitable] = lazy_import("trio.lowlevel", "checkpoint")  # pyright: ignore[reportAssignmentType]


@coroutine
def asyncio_checkpoint():
    yield


class SingleConsumerAsyncQueue(Generic[T]):
    """
    A single use queue for a single asynchronous iterator consumer.

    Notes:
        - Adding to the queue is synchronous and non-blocking.
        - The size of the queue is not limited.
        - The queue will only yield for one async iterator.
        - When [SingleConsumerAsyncQueue.stop][] is called:
            - Any items in the queue are rejected.
            - Adding more items will be rejected immediately.
    """

    __slots__ = ["__weakref__", "_active", "_checkpoint", "_reject", "_resume"]

    _active: bool | None
    queue: Fixed[Self, deque[T]] = Fixed(deque)

    def __init__(
        self, backend: Backend | Literal["asyncio", "trio"], /, *, reject: Callable[[T], Any] | None = None
    ) -> None:
        self._resume = noop
        self._checkpoint = asyncio_checkpoint if Backend(backend) is Backend.asyncio else trio_checkpoint
        self._active = None
        self._reject = reject

    async def __aiter__(self) -> AsyncGenerator[T]:
        if self._active is not None:
            return
        self._active = True
        try:
            while self._active:
                if self.queue:
                    yield self.queue.popleft()
                    await self._checkpoint()
                else:
                    event = create_async_event()
                    self._resume = event.set
                    if not self.queue and self._active:
                        await event
                    self._resume = noop
        finally:
            self.stop()

    def stop(self) -> None:
        """
        Stop the queue rejecting any items currently in the queue.
        """
        self._active = False
        self._resume()
        if self._reject:
            for item in self.queue:
                self._reject(item)
        self.queue.clear()
        self._resume = noop

    def append(self, item: T) -> None:
        """
        Append an item to the queue.

        If the queue has been stopped it will be rejected immediately.
        """
        if self._active is False:
            if self._reject:
                self._reject(item)
        else:
            self.queue.append(item)
            self._resume()

    @property
    def stopped(self) -> bool:
        """
        Will return `True` once stop has been called meaning there are no items left in the queue.
        """
        return self._active is False


@final
class Caller(anyio.AsyncContextManagerMixin):
    """
    Caller is a class that facilitates thread-safe function calls and coroutine execution using an asynchronous backend (asyncio or trio).

    Caller uses [async_kernel.pending.Pending][] objects to support cancellation and access to results/exceptions.
    Pending uses thread-safe synchronous and asynchronous primitives meaning results can be awaited in most places.

    In CPython, there is only one caller instance per thread. In Pyodide (where threading does not exist), multiple
    caller instances can exist in the same thread, but is limited to one instance per context.

    Multi-eventloop management is supported including:
    - zero or one host gui event loop.
    - one or two backends.

    Code execution is always performed using an asynchronous backend.

    **High level methods**

    - [Caller.call_soon][]: Schedule a function call in the caller's thread.
    - [Caller.call_later][]: Schedule a function call in the caller's thread after a delay.
    - [Caller.to_thread][]: Schedule a function call using a worker caller (separate thread).
    - [Caller.call_using_backend][]: Schedule a function call using the backend in the caller's thread.
    - [Caller.as_completed][]: An async iterator to access pending as they complete.
    - [Caller.wait][]: A method to wait for pending to complete with a timeout.
    - [Caller.create_pending_group][]: Create a new pending group to use as an asynchronous context.
    - [Caller.get][]: Get a new caller instance (child).

    **Low level methods**

    - [Caller.schedule_call][]: Schedule a function call in the caller's thread - configurable (used by high level methods).
    - [Caller.call_direct][]: Call a function directly in the scheduler in the caller's thread.
    - [Caller.queue_call][]: Execute a function in the caller's thread using a queue (sequential).
    - [Caller.queue_get][]: Get the pending associated with the queue call.
    - [Caller.queue_close][]: Close the queue associated with the function.

    **Class methods**

    - [Caller.current_pending][]: Get the active pending in the current context.
    - [Caller.id_current][]: Get the id of the caller in the current thread/context.
    - [Caller.get_existing][]: Get the caller by id.
    - [Caller.all_callers][]: Get a list of all callers.
    """

    MAX_IDLE_POOL_INSTANCES = 10
    "The number of `pool` instances to leave idle (See also [to_thread][async_kernel.caller.Caller.to_thread])."

    IDLE_WORKER_SHUTDOWN_DURATION = 0 if "pytest" in sys.modules else 60
    """
    The minimum duration in seconds for a worker to remain in the worker pool before it is shutdown.
    
    Set to 0 to disable (default when running tests).
    """

    CALLER_MAIN_THREAD_ID: int = id(threading.main_thread())

    _caller_token = contextvars.ContextVar("caller_tokens", default=CALLER_MAIN_THREAD_ID)
    _instances: ClassVar[dict[int, Self]] = {}
    _lock: ClassVar = BinarySemaphore()

    _thread: threading.Thread
    _caller_id: int
    _name: str
    _idle_time: float = 0.0
    _backend: Backend
    _backend_options: dict[str, Any] | None
    _loop: Loop | None
    _loop_options: dict[str, Any] | None
    _protected = False
    _use_safe_checkpoint = False
    _state: CallerState = CallerState.initial
    _state_reprs: ClassVar[dict] = {
        CallerState.initial: "❗ not running",
        CallerState.start_sync: "starting sync",
        CallerState.running: "🏃 running",
        CallerState.stopping: "🏁 stopping",
        CallerState.stopped: "🏁 stopped",
    }
    _zmq_context: zmq.Context[Any] | None = None

    _parent_ref: weakref.ref[Self] | None = None

    # Fixed
    _child_lock = Fixed(BinarySemaphore)
    _children: Fixed[Self, set[Self]] = Fixed(set)
    _tasks: Fixed[Self, set[asyncio.Task]] = Fixed(set)
    _worker_pool: Fixed[Self, deque[Self]] = Fixed(deque)
    _queue_map: Fixed[Self, dict[int, Pending]] = Fixed(dict)
    _queue: Fixed[Self, SingleConsumerAsyncQueue[Pending | tuple[Callable, tuple, dict]]] = Fixed(
        lambda c: SingleConsumerAsyncQueue(c["owner"].backend, reject=c["owner"]._reject)
    )

    stopped = Fixed(Event)
    "A thread-safe Event that is set when the caller has stopped."

    _pending_var: contextvars.ContextVar[Pending | None] = contextvars.ContextVar("_pending_var", default=None)

    log: logging.LoggerAdapter[Any]
    ""
    iopub_sockets: ClassVar[dict[int, zmq.Socket]] = {}
    ""
    iopub_url: ClassVar = "inproc://iopub"
    ""

    @property
    def name(self) -> str:
        "The name of the thread when the caller was created."
        return self._name

    @property
    def id(self) -> int:
        "The id for the caller."
        return self._caller_id

    @property
    def backend(self) -> Backend:
        "The backend used by caller."
        return self._backend

    @property
    def backend_options(self) -> dict | None:
        "Options used to create the backend."
        return self._backend_options

    @property
    def loop(self) -> Loop | None:
        "The gui event loop if there is one."
        return self._loop

    @property
    def loop_options(self) -> dict | None:
        "Options used to create the gui event loop."
        return self._loop_options

    @property
    def protected(self) -> bool:
        "Returns `True` if the caller is protected from stopping."
        return self._protected

    @property
    def zmq_context(self) -> zmq.Context | None:
        "A zmq socket, which if present indicates that an iopub socket is loaded."
        return self._zmq_context

    @property
    def running(self):
        "Returns `True` when the caller is available to run requests."
        return self._state is CallerState.running

    @property
    def children(self) -> frozenset[Self]:
        """A frozenset copy of the instances that were created by the caller.

        Notes:
            - When the parent is stopped, all children are stopped.
            - All children are stopped prior to the parent exiting its async context.
        """
        return frozenset(self._children)

    @property
    def thread(self) -> threading.Thread:
        "The thread where the caller is running."
        return self._thread

    @property
    def parent(self) -> Self | None:
        "The parent caller if it exists."
        if (ref := self._parent_ref) and (inst := ref()) and not inst.stopped:
            return inst
        return None

    def _get_info(self) -> dict[str, Any]:
        return {
            "name": self._name,
            "backend": str(self._backend),
            "loop": self._loop,
            "thread": self._thread.name,
            "id": self._caller_id,
        }

    @override
    def __repr__(self) -> str:
        info = " ".join(f"{k}={v!r}" for k, v in self._get_info().items())
        current = "🟢" if self.id_current() == self._caller_id else "〇"  # noqa: RUF001
        protected = "🔐 " if self.protected else " "
        n = len(self._children)
        children = "" if not n else ("1 child" if n == 1 else f"{n} children")
        return f"<Caller {current}{protected}{info}{children}>"

    def __new__(
        cls,
        modifier: Literal["CurrentThread", "MainThread", "NewThread", "manual"] = "CurrentThread",
        /,
        **kwargs: Unpack[CallerCreateOptions],
    ) -> Self:
        """
        Create or retrieve a Caller instance.

        Args:
            modifier: Specifies how the Caller instance should be created or retrieved.

                - "CurrentThread": Automatically create or retrieve the instance.
                - "MainThread": Use the main thread for the Caller.
                - "NewThread": Create a new thread.
                - "manual": Manually create a new instance for the current thread.

            **kwargs: Additional options for Caller creation, such as:
                - name: The name to use.
                - backend: The async backend to use.
                - backend_options: Options for the backend.
                - protected: Whether the Caller is protected.
                - zmq_context: ZeroMQ context.
                - log: Logger instance.

        Returns:
            Self: The created or retrieved Caller instance.

        Raises:
            RuntimeError: If the backend is not provided and backend can't be determined.
            ValueError: If the thread and caller's name do not match.
        """
        with cls._lock:
            name, backend = kwargs.get("name", ""), kwargs.get("backend")
            match modifier:
                case "CurrentThread" | "manual":
                    caller_id = cls.id_current()
                case "MainThread":
                    caller_id = cls.CALLER_MAIN_THREAD_ID
                case "NewThread":
                    caller_id = None

            # Locate existing
            if caller_id is not None and (caller := cls._instances.get(caller_id)):
                if modifier == "manual":
                    msg = f"An instance already exists for {caller_id=}"
                    raise RuntimeError(msg)
                if name and name != caller.name:
                    msg = f"The thread and caller's name do not match! {name=} {caller=}"
                    raise ValueError(msg)
                if backend and backend != caller.backend:
                    msg = f"The backend does not match! {backend=} {caller.backend=}"
                    raise ValueError(msg)
                return caller

            # create a new instance
            inst = super().__new__(cls)
            inst._name = name
            inst._backend = Backend(backend or current_async_library())
            inst._loop = Loop(loop) if (loop := kwargs.get("loop")) else None
            inst._backend_options = kwargs.get("backend_options")
            inst._loop_options = kwargs.get("loop_options")
            inst._protected = kwargs.get("protected", False)
            inst._zmq_context = kwargs.get("zmq_context")
            inst.log = kwargs.get("log") or logging.LoggerAdapter(logging.getLogger())
            if (sys.platform == "emscripten") and (caller_id is None):
                caller_id = id(inst)
            if caller_id is not None:
                inst._caller_id = caller_id
                inst._thread = threading.current_thread()

            # finalize
            if modifier != "manual":
                inst.start_sync(no_debug=kwargs.get("no_debug", False))
            assert inst._caller_id
            assert inst._caller_id not in cls._instances
            cls._instances[inst._caller_id] = inst
        return inst

    def start_sync(self, *, no_debug: bool = False) -> None:
        """
        Start synchronously.

        Args:
            no_debug: If debugpy should be disabled in the thread.
        """

        assert self._state is CallerState.initial
        self._state = CallerState.start_sync

        async def run_caller_in_context() -> None:
            if self._state is CallerState.start_sync:
                if no_debug:
                    utils.mark_thread_pydev_do_not_trace()
                self._state = CallerState.initial
                async with self:
                    await self.stopped

        if getattr(self, "_caller_id", None) is not None:
            # An event loop for the current thread.

            if self.backend == Backend.asyncio:
                self._tasks.add(asyncio.create_task(run_caller_in_context()))
            else:
                # trio
                token = current_token()

                def to_thread():
                    utils.mark_thread_pydev_do_not_trace()
                    try:
                        anyio.from_thread.run(run_caller_in_context, token=token)
                    except (BaseExceptionGroup, BaseException) as e:
                        if not "shutdown" not in str(e):
                            raise

                threading.Thread(target=to_thread, daemon=False).start()
        else:
            name = self.name or "async_kernel_caller"
            settings = RunSettings(
                backend=self.backend,
                loop=self.loop,
                backend_options=self.backend_options,
                loop_options=self.loop_options,
            )
            args = [run_caller_in_context, (), settings]
            self._thread = threading.Thread(target=async_kernel.event_loop.run, args=args, name=name, daemon=True)
            self._caller_id = id(self._thread)
            self._thread.start()

    def stop(self, *, force: bool = False) -> CallerState:
        """
        Stop the caller cancelling all incomplete tasks.

        Args:
            force: If the caller is protected the call is a no-op unless force=True.
        """
        if (self._protected and not force) or self._state is CallerState.stopping:
            return self._state
        set_stop = self._state in [CallerState.initial, CallerState.start_sync]
        self._state = CallerState.stopping
        self._instances.pop(self._caller_id, None)
        if parent := self.parent:
            try:
                parent._worker_pool.remove(self)
            except ValueError:
                pass
        for child in self.children:
            child.stop(force=True)
        if queue := getattr(self, "_guest_queue", None):
            queue.stop()
        self._queue.stop()
        for func in tuple(self._queue_map):
            self.queue_close(func)
        if set_stop:
            self._state = CallerState.stopped
            self.stopped.set()
        return self._state

    @asynccontextmanager
    async def __asynccontextmanager__(self) -> AsyncGenerator[Self]:
        "The asynchronous context for caller."
        if (state := self._state) is not CallerState.initial:
            if state is CallerState.start_sync:
                msg = 'Already starting! Did you mean to use Caller("manual")?'
            else:
                msg = "Caller cannot be been re-entered!"
            raise RuntimeError(msg)
        if not self._name:
            self._name = threading.current_thread().name
        async with anyio.create_task_group() as tg:
            socket = None
            self._state = CallerState.running
            tg.start_soon(self._scheduler, self.backend, self._queue, tg)
            if self._zmq_context:
                socket = self._zmq_context.socket(1)  # zmq.SocketType.PUB
                socket.linger = 50
                socket.connect(self.iopub_url)
                self.iopub_sockets[self._caller_id] = socket
            try:
                yield self
            finally:
                if stop_guest := getattr(self, "_stop_guest", None):
                    with anyio.CancelScope(shield=True):
                        await stop_guest()
                self.stop(force=True)
                if socket:
                    self.iopub_sockets.pop(self._caller_id, None)
                    socket.close()
                with anyio.CancelScope(shield=True):
                    while self._children:
                        await self._children.pop().stopped
                    if parent := self.parent:
                        parent._children.discard(self)
                    self._state = CallerState.stopped
                    self.stopped.set()
                    await self._checkpoint()

    async def _scheduler(self, backend: Backend, queue: SingleConsumerAsyncQueue, tg: TaskGroup) -> None:
        """
        An asynchronous coroutine to schedule or execute functions as they arrive in the queue.

        It handles two different types of items in the queue:
            - tuple: A tuple of func, args, kwargs intended to be called directly in the scheduler.
            - Pending: A pending that is to be started as a 'task' with the backend wrapped with

        Args:
            backend: The backend where the scheduler is operating.
            tg: The task group used to manage concurrent tasks.
            task_status: Used to signal when the scheduler has started.
        """
        kwgs = {}
        asyncio_backend = backend == Backend.asyncio
        if asyncio_backend:
            loop = asyncio.get_running_loop()
            coro = asyncio.sleep(0)
            try:
                await loop.create_task(coro, eager_start=True)  # pyright: ignore[reportCallIssue]
                kwgs["eager_start"] = True
            except Exception:
                coro.close()
        try:
            async for item in queue:
                result = None
                if not isinstance(item, Pending):
                    try:
                        result = item[0](*item[1], **item[2])
                        if inspect.iscoroutine(result):
                            await result
                    except Exception as e:
                        self.log.exception("Direct call failed", exc_info=e)
                else:
                    if asyncio_backend:
                        task = loop.create_task(self._wrap_call(item), context=item.context, **kwgs)  # pyright: ignore[reportPossiblyUnboundVariable]
                        if not task.done():
                            self._tasks.add(task)
                            task.add_done_callback(self._tasks.discard)
                        del task
                    else:
                        if context := item.context:
                            context.run(tg.start_soon, self._wrap_call, item)
                        else:
                            tg.start_soon(self._wrap_call, item)
                del item, result
        finally:
            if asyncio_backend:
                for task in self._tasks:
                    task.cancel()
            tg.cancel_scope.cancel()

    async def _wrap_call(self, pen: Pending) -> None:
        """
        Asynchronously executes the function associated with the given pending, handling cancellation, delays, and exceptions.

        Args:
            pen: The [async_kernel.Pending][] object containing metadata about the function to execute, its arguments, and execution state.
        """
        md = pen.metadata
        token_pending = self._pending_var.set(pen)
        token_ident = self._caller_token.set(self._caller_id)
        try:
            if pen.cancelled():
                if not pen.done():
                    pen.set_exception(PendingCancelled("Cancelled before started."))
            else:
                with anyio.CancelScope() as scope:
                    pen.set_canceller(lambda msg: self.call_direct(scope.cancel, msg))
                    # Call later.
                    if (delay := md.get("delay")) and ((delay := delay - time.monotonic() + md["start_time"]) > 0):
                        await anyio.sleep(delay)
                    # Call now.
                    try:
                        result = md["func"](*md["args"], **md["kwargs"])
                        if inspect.iscoroutine(result):
                            result = await result
                        pen.set_result(result)
                    # Cancelled.
                    except anyio.get_cancelled_exc_class() as e:
                        if not pen.cancelled():
                            pen.cancel()
                        pen.set_exception(e)
                    # Catch exceptions.
                    except Exception as e:
                        pen.set_exception(e)
        except Exception as e:
            pen.set_exception(e)
        finally:
            self._pending_var.reset(token_pending)
            self._caller_token.reset(token_ident)

    @staticmethod
    def _reject(item: tuple | Pending) -> None:
        if isinstance(item, Pending):
            item.cancel("The caller has been closed")
            item.set_result(None)

    @classmethod
    def _start_idle_worker_cleanup_thead(cls) -> None:
        "A single thread to shutdown idle workers that have not been used for an extended duration."
        if cls.IDLE_WORKER_SHUTDOWN_DURATION > 0 and not hasattr(cls, "_thread_cleanup_idle_workers"):

            def _cleanup_workers():
                utils.mark_thread_pydev_do_not_trace()
                n = 0
                cutoff = time.monotonic()
                time.sleep(cls.IDLE_WORKER_SHUTDOWN_DURATION)
                for caller in tuple(cls._instances.values()):
                    for worker in frozenset(caller._worker_pool):
                        n += 1
                        if worker._idle_time < cutoff:
                            with contextlib.suppress(IndexError):
                                caller._worker_pool.remove(worker)
                                worker.stop()
                if n:
                    _cleanup_workers()
                else:
                    del cls._thread_cleanup_idle_workers

            cls._thread_cleanup_idle_workers = threading.Thread(target=_cleanup_workers, daemon=True)
            cls._thread_cleanup_idle_workers.start()

    @classmethod
    def id_current(cls) -> int:
        "The id that is used for a caller for the current thread in CPython or context in Pyodide."
        if sys.platform == "emscripten":
            return cls._caller_token.get()
        return id(threading.current_thread())

    @classmethod
    def get_existing(cls, caller_id: int | None = None, /) -> Self | None:
        """
        A [classmethod][] to get the caller instance from the corresponding thread if it exists.

        Args:
            caller_id: The id of the caller which in CPython is also the the id of the thread in which it is running.
        """
        caller_id = cls.id_current() if caller_id is None else caller_id
        with cls._lock:
            return cls._instances.get(caller_id)

    @classmethod
    def current_pending(cls) -> Pending[Any] | None:
        """A [classmethod][] that returns the current pending when called from inside a function scheduled by Caller."""
        return cls._pending_var.get()

    @classmethod
    def all_callers(cls, running_only: bool = True) -> list[Caller]:
        """
        A [classmethod][] to get a list of the callers.

        Args:
            running_only: Restrict the list to callers that are active (running in an async context).
        """
        return [caller for caller in Caller._instances.values() if caller.running or not running_only]

    def get(self, **kwargs: Unpack[CallerCreateOptions]) -> Self:
        """
        Retrieves an existing child caller by name and backend, or creates a new one if not found.

        Args:
            **kwargs: Options for creating or retrieving a caller instance.

        Returns:
            Self: The retrieved or newly created caller instance.

        Raises:
            RuntimeError: If a caller with the specified name exists but the backend does not match.

        Notes:
            - The returned caller is added to `children` and stopped with this instance.
            - If 'backend' or 'zmq_context' are not specified they are copied from this instance.
        """

        with self._child_lock:
            if name := kwargs.get("name"):
                for caller in self.children:
                    if caller.name == name:
                        if (backend := kwargs.get("backend")) and caller.backend != backend:
                            msg = f"Backend mismatch! {backend=} {caller.backend=}"
                            raise RuntimeError(msg)
                        if (loop := kwargs.get("loop")) and caller.loop != loop:
                            msg = f"Event loop mismatch! {loop=} {caller.loop=}"
                            raise RuntimeError(msg)
                        return caller
            if "backend" not in kwargs:
                kwargs["backend"] = self._backend
                kwargs["backend_options"] = self.backend_options
            if "zmq_context" not in kwargs and self._zmq_context:
                kwargs["zmq_context"] = self._zmq_context
            caller = self.__class__("NewThread", **kwargs)
            self._children.add(caller)
            caller._parent_ref = weakref.ref(self)
            return caller

    def schedule_call(
        self,
        func: Callable[..., CoroutineType[Any, Any, T] | T],
        args: tuple,
        kwargs: dict,
        context: contextvars.Context | None = None,
        trackers: type[PendingTracker] | tuple[type[PendingTracker], ...] = PendingTracker,
        backend: NoValue | Backend = NoValue,  # pyright: ignore[reportInvalidTypeForm]
        /,
        **metadata: Any,
    ) -> Pending[T]:
        """
        Schedule `func` to be called inside a task running in the caller's thread (thread-safe).

        The methods [call_soon][Caller.call_soon] and [call_later][Caller.call_later]
        use this method in the background,  they should be used in preference to this method since they provide type hinting for the arguments.

        Args:
            func: The function to be called. If it returns a coroutine, it will be awaited and its result will be returned.
            args: Arguments corresponding to in the call to  `func`.
            kwargs: Keyword arguments to use with in the call to `func`.
            context: The context to use, if not provided the current context is used.
            trackers: The tracker subclasses of active trackers which to add the pending.
            **metadata: Additional metadata to store in the instance.
        """
        pen = Pending(context, trackers, func=func, args=args, kwargs=kwargs, caller=self, **metadata)
        if backend is NoValue or (backend := Backend(backend)) is self.backend:
            self._queue.append(pen)
        else:
            if not hasattr(self, "_guest_queue"):
                self._guest_queue = SingleConsumerAsyncQueue(backend, reject=self._reject)
                self.schedule_call(
                    self._guest_backend_loop, (), {"backend": backend, "queue": self._guest_queue}, None, ()
                )
            self._guest_queue.append(pen)
        return pen

    async def _guest_backend_loop(self, backend: Backend, queue: SingleConsumerAsyncQueue) -> None:
        async def _guest_scheduler() -> None:
            async with anyio.create_task_group() as tg:
                tg.start_soon(self._scheduler, Backend(backend), queue, tg)

        if self._state is CallerState.running:
            # Prefer callbacks from the host.
            host = Host.current(self.thread)
            run_soon_threadsafe_queue = SingleConsumerAsyncQueue(self.backend)
            start_guest_run = get_start_guest_run(backend)
            start_guest_run(
                _guest_scheduler,
                done_callback=lambda _: run_soon_threadsafe_queue.stop(),
                run_sync_soon_threadsafe=host.run_sync_soon_threadsafe if host else run_soon_threadsafe_queue.append,
                run_sync_soon_not_threadsafe=host.run_sync_soon_not_threadsafe if host else None,
                host_uses_signal_set_wakeup_fd=host.host_uses_signal_set_wakeup_fd if host else True,
            )
            if pen := self.current_pending():
                self._stop_guest = lambda: [queue.stop(), pen.wait(result=False)][1]
            with anyio.CancelScope(shield=True):
                async for func in run_soon_threadsafe_queue:
                    try:
                        func()
                    except Exception:
                        pass

    def call_later(
        self,
        delay: float,
        func: Callable[P, T | CoroutineType[Any, Any, T]],
        /,
        *args: P.args,
        **kwargs: P.kwargs,
    ) -> Pending[T]:
        """
        Schedule func to be called in caller's event loop copying the current context.

        Args:
            func: The function.
            delay: The minimum delay to add between submission and execution.
            *args: Arguments to use with `func`.
            **kwargs: Keyword arguments to use with `func`.

        Info:
            All call arguments are packed into the instance's metadata.
        """
        return self.schedule_call(func, args, kwargs, delay=delay, start_time=time.monotonic())

    def call_soon(
        self,
        func: Callable[P, T | CoroutineType[Any, Any, T]],
        /,
        *args: P.args,
        **kwargs: P.kwargs,
    ) -> Pending[T]:
        """
        Schedule func to be executed.

        Args:
            func: The function.
            *args: Arguments to use with `func`.
            **kwargs: Keyword arguments to use with `func`.
        """
        return self.schedule_call(func, args, kwargs)

    def call_using_backend(
        self,
        backend: Backend | Literal["asyncio", "trio"],
        func: Callable[P, T | CoroutineType[Any, Any, T]],
        /,
        *args: P.args,
        **kwargs: P.kwargs,
    ) -> Pending[T]:
        """
        Schedule func to be executed using the specified backend.

        This methods enables coroutines written for a specific function to be run irresective
        of the callers backend.

        - `backend == caller.backend` - `func` is executed via [Caller.call_soon][].
        - `backend != caller.backend` - `func` is executed with a backend running as a guest.

        Args:
            backend: The backend in which `func` must be executed.
            func: The function.
            *args: Arguments to use with `func`.
            **kwargs: Keyword arguments to use with `func`.

        Notes:

            - **Only use this to execute coroutines that require a specific backend to run in the caller's thread.**
            - Where possible use a separate caller/thread with [Caller.get][] instead.
        """
        return self.schedule_call(func, args, kwargs, None, PendingTracker, Backend(backend))

    def call_direct(
        self,
        func: Callable[P, T | CoroutineType[Any, Any, T]],
        /,
        *args: P.args,
        **kwargs: P.kwargs,
    ) -> None:
        """
        Schedule `func` to be called in caller's event loop directly.

        Use this for short-running function calls only.

        Args:
            func: The function.
            *args: Arguments to use with `func`.
            **kwargs: Keyword arguments to use with `func`.

        Warning:

            **Use this method for lightweight calls only!**
        """
        self._queue.append((func, args, kwargs))

    def to_thread(
        self,
        func: Callable[P, T | CoroutineType[Any, Any, T]],
        /,
        *args: P.args,
        **kwargs: P.kwargs,
    ) -> Pending[T]:
        """
        Call func in a worker thread using the same backend as the current instance.

        Args:
            func: The function.
            *args: Arguments to use with func.
            **kwargs: Keyword arguments to use with func.

        Notes:
            - A minimum number of caller instances are retained for this method.
            - Async code run inside func should use taskgroups for creating task.
        """

        def _to_thread_on_done(_) -> None:
            if not caller.stopped and self.running:
                if len(self._worker_pool) < self.MAX_IDLE_POOL_INSTANCES:
                    caller._idle_time = time.monotonic()
                    self._worker_pool.append(caller)
                    self._start_idle_worker_cleanup_thead()
                else:
                    caller.stop()

        try:
            caller = self._worker_pool.popleft()
        except IndexError:
            caller = self.get()
        pen = caller.call_soon(func, *args, **kwargs)
        pen.add_done_callback(_to_thread_on_done)
        return pen

    def queue_get(self, func: Callable) -> Pending[None] | None:
        """Returns `Pending` instance for `func` where the queue is running.

        Notes:
            - `queue_close` is the preferred means to shutdown the queue.
        """
        return self._queue_map.get(hash(func))

    def queue_call(
        self,
        func: Callable[P, T | CoroutineType[Any, Any, T]],
        /,
        *args: P.args,
        **kwargs: P.kwargs,
    ) -> None:
        """
        A low level function to queue the execution of `func` in a queue unique to it and the caller instance (thread-safe).

        Args:
            func: The function.
            *args: Arguments to use with `func`.
            **kwargs: Keyword arguments to use with `func`.

        Notes:
            - The queue runs inside a pending that remains running until one of the following occurs:
                1. The queue is stopped.
                2. The method [Caller.queue_close][] is called with `func` or `func`'s hash.
                3. `func` is deleted (utilising [weakref.finalize][]).
            - The [context][contextvars.Context] of the initial call is used for subsequent queue calls.
            - Exceptions are logged to caller.log but not propagated.
            - The pending created on the first call will only registered with PendingManager subclassed trackers and **not** PendingGroup.
        """
        key = hash(func)
        if not (pen_ := self._queue_map.get(key)):
            queue = SingleConsumerAsyncQueue[tuple[Callable, tuple, dict]](self.backend)
            with contextlib.suppress(TypeError):
                weakref.finalize(func.__self__ if inspect.ismethod(func) else func, self.queue_close, key)

            async def queue_loop() -> None:
                pen = self.current_pending()
                assert pen
                result = None
                try:
                    async for item in queue:
                        try:
                            result = item[0](*item[1], **item[2])
                            if inspect.iscoroutine(object=result):
                                result = await result
                        except (anyio.get_cancelled_exc_class(), Exception) as e:
                            if pen.cancelled():
                                raise
                            self.log.exception("Execution %s failed", item, exc_info=e)
                        item = result = None  # noqa: PLW2901
                finally:
                    self._queue_map.pop(key)

            pen_ = self.schedule_call(queue_loop, (), {}, None, PendingManager, key=key, queue=queue)
            self._queue_map[key] = pen_
        pen_.metadata["queue"].append((func, args, kwargs))

    def queue_close(self, func: Callable | int) -> None:
        """
        Close the execution queue associated with `func` (thread-safe).

        Args:
            func: The queue of the function to close.
        """
        key = func if isinstance(func, int) else hash(func)
        if pen := self._queue_map.pop(key, None):
            pen.metadata["queue"].stop()
            pen.cancel()

    async def _checkpoint(self) -> None:
        "Yield to the event loop."
        if not self._use_safe_checkpoint:
            try:
                if self.backend is Backend.trio:
                    await trio_checkpoint()
                else:
                    await asyncio_checkpoint()
            except Exception:
                self._use_safe_checkpoint = True
            else:
                return
        await async_checkpoint(force=True)

    async def as_completed(
        self,
        items: Iterable[Awaitable[T]] | AsyncGenerator[Awaitable[T]],
        *,
        max_concurrent: NoValue | int = NoValue,  # pyright: ignore[reportInvalidTypeForm]
        cancel_unfinished: bool = True,
    ) -> AsyncGenerator[Pending[T], Any]:
        """
        An iterator to get result as they complete.

        Args:
            items: Either a container with existing results or generator of Pendings.
            max_concurrent: The maximum number of concurrent results to monitor at a time.
                This is useful when `items` is a generator utilising [Caller.to_thread][].
                By default this will limit to `Caller.MAX_IDLE_POOL_INSTANCES`.
            cancel_unfinished: Cancel any `pending` when exiting.

        Tip:
            1. Pass a generator if you wish to limit the number result jobs when calling to_thread/to_task etc.
            2. Pass a container with all results when the limiter is not relevant.
        """
        resume = noop
        queue: SingleConsumerAsyncQueue[Pending[T]] = SingleConsumerAsyncQueue(self.backend)
        unfinished: set[Pending[T]] = set()
        pen_current = self.current_pending()
        if isinstance(items, set | list | tuple):
            max_concurrent_ = 0
        else:
            max_concurrent_ = self.MAX_IDLE_POOL_INSTANCES if max_concurrent is NoValue else int(max_concurrent)

        async def scheduler():
            nonlocal resume
            gen = items if isinstance(items, AsyncGenerator) else iter(items)
            is_async = isinstance(gen, AsyncGenerator)
            while not queue.stopped and (pen := await anext(gen, None) if is_async else next(gen, None)) is not None:
                if pen is pen_current:
                    queue.stop()
                    msg = "Waiting for the pending in which it is running would result in deadlock!"
                    raise RuntimeError(msg)
                if not isinstance(pen, Pending):
                    pen = cast("Pending[T]", self.call_soon(await_for, pen))
                pen.add_done_callback(queue.append)
                if not pen.done():
                    unfinished.add(pen)
                    if max_concurrent_ and len(unfinished) == max_concurrent_:
                        waiter = create_async_waiter()
                        resume = waiter.wake
                        if len(unfinished) == max_concurrent_:
                            await waiter
                        resume = noop
            if not queue.queue and not unfinished:
                queue.stop()

        pen_ = self.call_soon(scheduler)
        try:
            async for pen in queue:
                unfinished.discard(pen)
                yield pen
                if pen_.done() and not unfinished and not queue.queue:
                    break
                else:
                    if max_concurrent_ and len(unfinished) < max_concurrent_:
                        resume()
            pen_.result()
        finally:
            queue.stop()
            pen_.cancel()
            for pen in unfinished:
                pen.remove_done_callback(queue.append)
                if cancel_unfinished:
                    pen.cancel("Cancelled by as_completed")
            with anyio.CancelScope():
                await pen_.wait(result=False)

    async def wait(
        self,
        items: Iterable[Awaitable[T]],
        *,
        timeout: float | None = None,
        return_when: Literal["FIRST_COMPLETED", "FIRST_EXCEPTION", "ALL_COMPLETED"] = "ALL_COMPLETED",
    ) -> tuple[set[Pending[T]], set[Pending[T]]]:
        """
        Wait for the results given by items to complete.

        Returns two sets of the results: (done, pending).

        Args:
            items: An iterable of results to wait for.
            timeout: The maximum time before returning.
            return_when: The same options as available for [asyncio.wait][].

        Example:
            ```python
            done, pending = await asyncio.wait(items)
            ```
        Info:
            - This does not raise a TimeoutError!
            - Pendings that aren't done when the timeout occurs are returned in the second set.
        """
        pending: set[Pending[T]] = set()
        done = set()
        for item in items:
            if isinstance(item, Pending):
                done.add(item) if item.done() else pending.add(item)
            else:
                pending.add(self.call_soon(await_for, item))
        if done:
            if return_when == "FIRST_COMPLETED":
                return done, pending
            if return_when == "FIRST_EXCEPTION":
                for pen in done:
                    if pen.cancelled() or pen.exception():
                        return done, pending
        if pending:
            with anyio.move_on_after(timeout):
                async for pen in self.as_completed(pending.copy(), cancel_unfinished=False):
                    pending.discard(pen)
                    done.add(pen)
                    if return_when == "FIRST_COMPLETED":
                        break
                    if return_when == "FIRST_EXCEPTION" and (pen.cancelled() or pen.exception()):
                        break
        return done, pending

    def create_pending_group(self, *, shield: bool = False, mode: Literal[0, 1, 2] = 0) -> PendingGroup:
        """
        Create a new [PendingGroup][async_kernel.pending.PendingGroup] instance.

        The pending group registers all pending created in its context that opt in (via trackers). On exiting
        the context, it will await all remaining pending to complete. The exit and cancellation behaviour of
        the instance is a function of `mode`.

        If any pending result in exception, the pending group and all registered pending are cancelled.
        If the pending group context is cancelled or results in exception, all pending in the group are
        also cancelled.

        Args:
            shield: Shield the pending group from external cancellation.
            mode: The mode.
                - 0: Ignore cancellation of pending.
                - 1: Cancel if any pending is cancelled - raise PendingCancelled on exit.
                - 2: Cancel if any pending is cancelled - exit quietly.

        Usage:

            ```python
            async with Caller().create_pending_group() as pg:
                pg.caller.to_thread(my_func)
                ...
            ```
        """
        return PendingGroup(shield=shield, mode=mode)
