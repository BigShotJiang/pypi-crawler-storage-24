# Autotouch CLI

Installable CLI for the Smart Table developer API.

Use it when you want command-driven access to search, tables, columns, runs, jobs, leads, sequences, and task workflows without hand-writing raw HTTP requests.

The CLI talks to the same API the product uses. For automation, prefer `--output json`.

For a machine-readable local command contract, use `autotouch cli-manifest --output json`.
For a shipped human-readable reference generated from the installed parser, use `autotouch cli-reference`.

## Install

```bash
pipx install autotouch-cli
# or
pip install autotouch-cli
```

## First Run

Existing developer key:

```bash
autotouch setup --api-key stk_... --base-url https://app.autotouch.ai
```

Equivalent manual steps:

```bash
autotouch auth set-key --api-key stk_... --base-url https://app.autotouch.ai
autotouch auth check --base-url https://app.autotouch.ai
```

Fresh account:

```bash
export AUTOTOUCH_CONFIG_PATH=/tmp/autotouch-audit.json

autotouch auth bootstrap \
  --first-name Ada \
  --last-name Lovelace \
  --email ada+audit@example.com \
  --password 'use-a-strong-random-password' \
  --organization-name "Audit Org" \
  --save-key

autotouch auth check
```

## 5-Minute Flow

```bash
# 0) First-run setup
autotouch setup --api-key stk_... --base-url https://app.autotouch.ai

# 1) Inspect machine-readable contract
autotouch capabilities --output json

# 2) Create a table and capture its id
TABLE_ID=$(autotouch tables create --name "CLI Contacts" --output json --select id)

# 3) Add a couple rows with the default lead_finder recipe's expected field
ROW_ID=$(autotouch rows add \
  --table-id "$TABLE_ID" \
  --records-json '[{"domain":"openai.com","companyName":"OpenAI"},{"domain":"stripe.com","companyName":"Stripe"}]' \
  --output json --select rowIds.0)

# 4) Generate a provider-backed column payload
autotouch columns recipe --type lead_finder --out-file column.json

# 5) Create the column and capture its id
COLUMN_ID=$(autotouch columns create --table-id "$TABLE_ID" --data-file column.json --output json --select id)

# 6) Run a small controlled slice and capture the bulk job id
JOB_ID=$(autotouch columns run-next \
  --table-id "$TABLE_ID" \
  --column-id "$COLUMN_ID" \
  --count 10 \
  --show-estimate \
  --wait \
  --output json --select job_id)

# 7) Verify backend truth
autotouch jobs get --job-id "$JOB_ID" --output json

# 8) Inspect exactly what changed
autotouch rows get --table-id "$TABLE_ID" --row-id "$ROW_ID" --output json
```

## Cheat Sheet

- Create table: `autotouch tables create`
- Add rows: `autotouch rows add`
- Inspect rows: `autotouch rows list`, `autotouch rows get`
- Inspect one cell: `autotouch cells get`
- Create a workflow column: `autotouch columns recipe`, `autotouch columns create`
- Run provider-hidden search: `autotouch search companies`, `autotouch search people`
- Run controlled slices: `autotouch columns run-next`
- Poll authoritative state: `autotouch jobs get`
- Create/activate sequences: `autotouch sequences recipe`, `autotouch sequences create`, `autotouch sequences activate`
- Query leads: `autotouch leads query`

## Automation Workflow

For automation or agent-driven setup, read machine-readable contract first:

```bash
autotouch capabilities --output json
```

Important sections:

- `cli-manifest`: local command grammar, flags, aliases, and output contracts shipped with the CLI
- `automation.providers`: provider setup contracts
- `automation.workflow_blueprints`: common multi-step workflow patterns
- `inspection.research_table`: exact row/cell audit endpoints and audit loop

## Local Backend

Point the CLI at a local backend when you want fast iteration against `run_local.sh` or another local stack:

```bash
autotouch capabilities --base-url http://localhost:8005 --output json
```

Use a dedicated `AUTOTOUCH_CONFIG_PATH` if you want a clean local account instead of your saved config.

## Docs

- Full CLI reference: https://github.com/nicolonic/autotouch_main/blob/autotouch-cli-v0.2.42/docs/research-table/reference/autotouch-cli.md
- Agent playbook: https://github.com/nicolonic/autotouch_main/blob/autotouch-cli-v0.2.42/docs/research-table/guides/autotouch-cli-agent-playbook.md
- Tables/API reference: https://github.com/nicolonic/autotouch_main/blob/autotouch-cli-v0.2.42/docs/research-table/reference/tables-api.md
- Authentication/scopes: https://github.com/nicolonic/autotouch_main/blob/autotouch-cli-v0.2.42/docs/platform/authentication.md
