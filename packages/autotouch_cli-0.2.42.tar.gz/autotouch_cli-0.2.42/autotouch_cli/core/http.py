from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any, Callable, Dict, Optional

import requests


def _decode_response_body(response: Any) -> Any:
    content_type = response.headers.get("content-type", "").lower()
    if "application/json" in content_type:
        try:
            return response.json()
        except Exception:
            return response.text
    return response.text


def _print_error_body(body: Any) -> None:
    if isinstance(body, (dict, list)):
        print(json.dumps(body, indent=2, default=str), file=sys.stderr)
    else:
        print(str(body), file=sys.stderr)


def request_api(
    method: str,
    path: str,
    *,
    base_url: str,
    token: Optional[str],
    api_url_fn: Callable[[Optional[str]], str],
    auth_headers_fn: Callable[[Optional[str], bool], Dict[str, str]],
    requests_module: Any = requests,
    use_x_api_key: bool = False,
    params: Optional[Dict[str, Any]] = None,
    payload: Optional[Any] = None,
    form_payload: Optional[Dict[str, Any]] = None,
    files: Optional[Any] = None,
    extra_headers: Optional[Dict[str, str]] = None,
    timeout: int = 30,
    default_timeout_seconds: int = 30,
    verbose: bool = False,
    error_body_writer: Optional[Callable[[Any], None]] = None,
) -> Any:
    url = f"{api_url_fn(base_url)}{path if path.startswith('/') else f'/{path}'}"
    headers = auth_headers_fn(token, use_x_api_key=use_x_api_key)
    if extra_headers:
        headers = {
            **headers,
            **{str(k): str(v) for k, v in extra_headers.items() if k and v is not None},
        }
    if verbose:
        print(f"[HTTP] {method.upper()} {url}", file=sys.stderr)
        if params:
            print(f"[HTTP] params={json.dumps(params, default=str)}", file=sys.stderr)
        if payload is not None:
            print(f"[HTTP] payload={json.dumps(payload, default=str)}", file=sys.stderr)
        if form_payload is not None:
            print(f"[HTTP] form={json.dumps(form_payload, default=str)}", file=sys.stderr)

    try:
        response = requests_module.request(
            method=method.upper(),
            url=url,
            headers=headers,
            params=params,
            json=payload,
            data=form_payload,
            files=files,
            timeout=max(1, int(timeout or default_timeout_seconds)),
        )
    except requests.RequestException as exc:
        print(f"ERROR: request failed: {exc}", file=sys.stderr)
        sys.exit(1)

    body = _decode_response_body(response)

    if response.status_code >= 300:
        print(f"ERROR: API {response.status_code}", file=sys.stderr)
        if error_body_writer is not None:
            error_body_writer(body)
        else:
            _print_error_body(body)
        sys.exit(1)
    return body


def request_multipart_api(
    method: str,
    path: str,
    *,
    base_url: str,
    token: Optional[str],
    file_path: str,
    api_url_fn: Callable[[Optional[str]], str],
    auth_headers_fn: Callable[[Optional[str], bool], Dict[str, str]],
    requests_module: Any = requests,
    file_field: str = "file",
    form_fields: Optional[Dict[str, Any]] = None,
    params: Optional[Dict[str, Any]] = None,
    use_x_api_key: bool = False,
    timeout: int = 30,
    default_timeout_seconds: int = 30,
    verbose: bool = False,
    error_body_writer: Optional[Callable[[Any], None]] = None,
) -> Any:
    url = f"{api_url_fn(base_url)}{path if path.startswith('/') else f'/{path}'}"
    headers = auth_headers_fn(token, use_x_api_key=use_x_api_key)
    form_payload = {
        str(k): (str(v).lower() if isinstance(v, bool) else str(v))
        for k, v in (form_fields or {}).items()
        if k is not None and v is not None
    }

    if verbose:
        print(f"[HTTP] {method.upper()} {url}", file=sys.stderr)
        if params:
            print(f"[HTTP] params={json.dumps(params, default=str)}", file=sys.stderr)
        if form_payload:
            print(f"[HTTP] form={json.dumps(form_payload, default=str)}", file=sys.stderr)

    try:
        with open(file_path, "rb") as handle:
            files = {file_field: (Path(file_path).name, handle, "text/csv")}
            response = requests_module.request(
                method=method.upper(),
                url=url,
                headers=headers,
                params=params,
                data=form_payload,
                files=files,
                timeout=max(1, int(timeout or default_timeout_seconds)),
            )
    except FileNotFoundError:
        print(f"ERROR: file not found: {file_path}", file=sys.stderr)
        sys.exit(2)
    except requests.RequestException as exc:
        print(f"ERROR: request failed: {exc}", file=sys.stderr)
        sys.exit(1)

    body = _decode_response_body(response)

    if response.status_code >= 300:
        print(f"ERROR: API {response.status_code}", file=sys.stderr)
        if error_body_writer is not None:
            error_body_writer(body)
        else:
            _print_error_body(body)
        sys.exit(1)
    return body
