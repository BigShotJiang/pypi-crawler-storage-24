"""Shared runtime helpers for the Autotouch CLI."""

