from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional, Tuple

from autotouch_shared.provider_registry import (
    automation_workflow_blueprints,
    get_recipe_contract,
    recipe_types,
)


@dataclass(frozen=True)
class TemplateRuntime:
    output_mode: str
    print_json: Callable[[Any, bool], None]
    emit_text: Callable[[str], None]


COLUMN_RECIPE_TYPES = recipe_types()
WORKFLOW_BLUEPRINT_TYPES = tuple(sorted(automation_workflow_blueprints().keys()))


def _build_column_recipe_catalog() -> Tuple[Dict[str, Dict[str, Any]], Dict[str, List[str]]]:
    recipes: Dict[str, Dict[str, Any]] = {}
    notes: Dict[str, List[str]] = {}
    for recipe_type in COLUMN_RECIPE_TYPES:
        contract = get_recipe_contract(recipe_type)
        if not contract:
            continue
        payload = contract.recipe_payload_copy()
        if isinstance(payload, dict):
            recipes[recipe_type] = payload
        notes[recipe_type] = contract.recipe_notes_list()
    return recipes, notes


COLUMN_CREATE_RECIPES, COLUMN_RECIPE_NOTES = _build_column_recipe_catalog()
WORKFLOW_BLUEPRINTS = json.loads(json.dumps(automation_workflow_blueprints()))

SEQUENCE_RECIPE_TYPES = [
    "create",
    "bulk_automated",
    "enroll",
]

SEQUENCE_RECIPES: Dict[str, Dict[str, Any]] = {
    "create": {
        "name": "Outbound v1",
        "sourceTableId": "<TABLE_ID>",
        "sourceTableName": "ICP Prospects",
        "exitRules": {
            "stopOnReply": True,
            "stopOnBounce": True,
            "stopOnManualOptOut": True,
        },
        "schedule": {
            "timezone": "America/New_York",
            "workingDays": [1, 2, 3, 4, 5],
            "dailyWindowStart": "09:00",
            "dailyWindowEnd": "17:00",
            "skipHolidays": False,
        },
        "emailDelivery": {
            "mode": "personal",
        },
        "defaultAppendSignature": True,
        "steps": [
            {
                "id": "email_1",
                "kind": "EMAIL",
                "waitDays": 0,
                "waitHours": 0,
                "waitMinutes": 0,
                "emailSendMode": "MANUAL",
                "emailIsReply": False,
                "appendSignature": True,
                "aiDraft": True,
                "aiInstructions": "Write a short personalized first-touch email based on the lead and account context.",
                "subjectTemplate": "",
                "bodyTemplate": "",
            },
            {
                "id": "call_1",
                "kind": "CALL",
                "waitDays": 1,
                "waitHours": 0,
                "waitMinutes": 0,
                "priority": "medium",
                "aiDraft": True,
                "aiInstructions": "Write a short call opener plus 2-3 discovery questions tailored to the account.",
                "scriptTemplate": "",
            },
            {
                "id": "linkedin_1",
                "kind": "LINKEDIN_MESSAGE",
                "waitDays": 2,
                "waitHours": 0,
                "waitMinutes": 0,
                "priority": "medium",
                "aiDraft": True,
                "aiInstructions": "Write a short LinkedIn follow-up that feels human and references the strongest relevant context.",
                "scriptTemplate": "",
            },
        ],
    },
    "bulk_automated": {
        "name": "Bulk outbound v1",
        "sourceTableId": "<TABLE_ID>",
        "sourceTableName": "ICP Prospects",
        "exitRules": {
            "stopOnReply": True,
            "stopOnBounce": True,
            "stopOnManualOptOut": True,
        },
        "schedule": {
            "timezone": "America/New_York",
            "workingDays": [1, 2, 3, 4, 5],
            "dailyWindowStart": "09:00",
            "dailyWindowEnd": "17:00",
            "skipHolidays": False,
        },
        "emailDelivery": {
            "mode": "bulk",
            "bulkProvider": "instantly",
        },
        "defaultAppendSignature": True,
        "steps": [
            {
                "id": "email_1",
                "kind": "EMAIL",
                "waitDays": 0,
                "waitHours": 0,
                "waitMinutes": 0,
                "emailSendMode": "AUTOMATED",
                "emailIsReply": False,
                "appendSignature": True,
                "subjectTemplate": "Quick intro",
                "bodyTemplate": "Hi {{first_name}}, ...",
            },
            {
                "id": "email_2",
                "kind": "EMAIL",
                "waitDays": 2,
                "waitHours": 0,
                "waitMinutes": 0,
                "emailSendMode": "AUTOMATED",
                "emailIsReply": False,
                "appendSignature": True,
                "subjectTemplate": "Following up",
                "bodyTemplate": "Hi {{first_name}}, circling back on this.",
            },
        ],
    },
    "enroll": {
        "leadIds": ["<LEAD_ID_1>", "<LEAD_ID_2>"],
        "researchContext": {
            "sourceTableId": "<TABLE_ID>",
        },
        "reviewOnly": False,
    },
}

SEQUENCE_RECIPE_NOTES: Dict[str, List[str]] = {
    "create": [
        "Recommended default: personal delivery plus MANUAL email with aiDraft=true.",
        "AI draft for manual email generates a subject + body at task review time.",
        "AI draft for LinkedIn message generates message copy; AI draft for call generates a call script.",
        "External sequence create/update requires sourceTableId.",
        "Pass --actor-user-id on mutating commands when you need explicit actor resolution.",
    ],
    "bulk_automated": [
        "Use this when the provider should send email automatically at scale.",
        "Bulk delivery sequences cannot contain MANUAL email steps, so aiDraft does not apply to those email steps.",
        "Activate only after provider readiness is configured (autotouch sequences delivery-status).",
    ],
    "enroll": [
        "task_id is the bulk-job id; use autotouch jobs watch --job-id <TASK_ID> or pass --wait.",
        "Set reviewOnly=true to stage enrollments on DRAFT/PAUSED sequences without starting them yet.",
    ],
}

LEAD_RECIPE_TYPES = [
    "create",
    "update",
    "contact_upsert",
    "query",
    "research",
    "selection",
]

LEAD_RECIPES: Dict[str, Dict[str, Any]] = {
    "create": {
        "company_domain": "acme.com",
        "linkedin_url": "https://www.linkedin.com/in/jane-doe",
        "first_name": "Jane",
        "last_name": "Doe",
        "title": "VP Sales",
        "email_addresses": [
            {
                "address": "jane@acme.com",
                "provider": "manual",
                "type": "work",
                "primary": True,
            }
        ],
        "phone_numbers": [
            {
                "number": "+14155551234",
                "provider": "manual",
                "type": "mobile",
                "primary": True,
            }
        ],
        "notes": "Created by an agent during outbound prospecting.",
    },
    "update": {
        "title": "VP Revenue",
        "notes": "Confirmed role update from LinkedIn.",
        "location": "San Francisco, CA",
        "timezone": "America/Los_Angeles",
    },
    "contact_upsert": {
        "emails": [
            {
                "address": "jane@acme.com",
                "provider": "manual",
                "type": "work",
                "primary": True,
            }
        ],
        "phones": [
            {
                "number": "+14155551234",
                "provider": "manual",
                "type": "mobile",
                "primary": True,
            }
        ],
    },
    "query": {
        "filter": {
            "root": {
                "kind": "group",
                "logic": "and",
                "children": [
                    {"kind": "rule", "field": "status", "operator": "eq", "value": "active"},
                    {"kind": "rule", "field": "company_domain", "operator": "contains", "value": "acme"},
                ],
            }
        },
        "sort": [{"field": "created_at", "direction": "desc"}],
        "pagination": {"limit": 25},
        "scope": "org",
        "include_research_data": False,
    },
    "research": {
        "lead_ids": ["<LEAD_ID_1>", "<LEAD_ID_2>"],
        "source_table_id": "<TABLE_ID>",
        "field_ids": ["<FIELD_ID_1>", "<FIELD_ID_2>"],
    },
    "selection": {
        "selection": {
            "mode": "descriptor",
            "descriptor": {
                "root": {
                    "kind": "group",
                    "logic": "and",
                    "children": [
                        {"kind": "rule", "field": "status", "operator": "eq", "value": "active"},
                    ],
                }
            },
            "sort": [{"field": "created_at", "direction": "desc"}],
            "search": "revops",
            "limit": 100,
        }
    },
}

LEAD_RECIPE_NOTES: Dict[str, List[str]] = {
    "create": [
        "Use canonical lead schema fields when creating a new lead.",
        "Create can include email_addresses and phone_numbers directly.",
    ],
    "update": [
        "Use update for scalar/profile fields only.",
        "Do not pass email/phone fields here; use contact_upsert instead.",
        "Status and owner also have dedicated commands: leads update-status and leads reassign-owner.",
    ],
    "contact_upsert": [
        "This route merges emails/phones into the existing lead instead of replacing the arrays.",
        "Use canonical emails[] / phones[] input, or the equivalent emailAddresses / phoneNumbers aliases in raw API payloads.",
    ],
    "query": [
        "Use this shape for leads query/count/stats.",
        "filter uses the descriptor form accepted by the Leads API.",
    ],
    "research": [
        "Use this shape for leads research when you want specific lead ids and source table fields.",
    ],
    "selection": [
        "Use this selection payload shape for bulk lead actions like update-status and reassign-owner.",
    ],
}

TASK_RECIPE_TYPES = [
    "query",
    "create",
    "update",
    "bulk_update",
    "bulk_delete",
    "draft",
    "schedule_email",
]

TASK_RECIPES: Dict[str, Dict[str, Any]] = {
    "query": {
        "filters": [
            {"field": "task_status", "operator": "eq", "value": "pending"},
            {"field": "channel", "operator": "eq", "value": "email"},
        ],
        "sort": {"field": "due_date", "direction": "asc"},
        "include_skipped": False,
        "include_total_count": True,
        "include_research_values": True,
        "research_field_ids": ["<FIELD_ID_1>"],
    },
    "create": {
        "lead_ids": ["<LEAD_ID_1>"],
        "assigned_to_ids": ["<USER_ID>"],
        "channel": "email",
        "priority": "medium",
        "subject": "Intro follow-up",
        "scheduling": {"due_date": "2026-03-12T15:00:00Z"},
        "content": {
            "subject": "Quick intro",
            "body_text": "Hi {{first_name}}, wanted to reach out about your team.",
        },
        "notes": "Created from the CLI recipe.",
        "origin": "manual",
    },
    "update": {
        "task_status": "scheduled",
        "priority": "high",
        "due_date": "2026-03-13T16:00:00Z",
        "notes": "Move this task to tomorrow afternoon.",
    },
    "bulk_update": {
        "selection": {"mode": "ids", "ids": ["<TASK_ID_1>", "<TASK_ID_2>"]},
        "status": "scheduled",
        "priority": "high",
        "assigned_to": "<USER_ID>",
    },
    "bulk_delete": {
        "selection": {"mode": "ids", "ids": ["<TASK_ID_1>", "<TASK_ID_2>"]},
    },
    "draft": {
        "force": False,
    },
    "schedule_email": {
        "provider": "gmail",
        "provider_account_email": "rep@example.com",
        "subject": "Quick intro",
        "body_text": "Hi {{first_name}}, reaching out after reviewing your profile.",
        "body_format": "auto",
        "send_at": "2026-03-12T16:30:00Z",
    },
}

TASK_RECIPE_NOTES: Dict[str, List[str]] = {
    "query": [
        "Use this shape for tasks query, count, and assignee-counts.",
        "filters and sort follow the Tasks CRM request contract.",
    ],
    "create": [
        "lead_ids and assigned_to_ids are required.",
        "scheduling is required and should include at least one due/scheduling value.",
    ],
    "update": [
        "Use this for a single task update payload.",
    ],
    "bulk_update": [
        "selection can be ids-based or descriptor-based depending on the backend contract.",
    ],
    "bulk_delete": [
        "Use task_ids or selection; this recipe shows the explicit selection form.",
    ],
    "draft": [
        "Task draft only accepts a small optional payload; pass --force to regenerate content.",
    ],
    "schedule_email": [
        "provider is usually gmail or microsoft for direct scheduling.",
    ],
}

WEBHOOK_RECIPE_TYPES = [
    "ingest",
    "subscription_create",
    "subscription_update",
    "subscription_test",
]

WEBHOOK_RECIPES: Dict[str, Dict[str, Any]] = {
    "ingest": {
        "records": [
            {
                "first_name": "Jane",
                "last_name": "Doe",
                "company_domain": "acme.com",
                "linkedin_url": "https://www.linkedin.com/in/jane-doe",
            }
        ]
    },
    "subscription_create": {
        "url": "https://example.com/webhooks/autotouch",
        "events": ["bulk_job.completed", "lead.created"],
        "enabled": True,
        "filters": {"organization_id": "<ORG_ID>"},
        "metadata": {"environment": "production"},
        "retryPolicy": {
            "max_attempts": 5,
            "base_delay_seconds": 30,
            "max_delay_seconds": 900,
            "timeout_seconds": 15,
        },
    },
    "subscription_update": {
        "events": ["bulk_job.completed", "bulk_job.partial"],
        "enabled": True,
        "filters": {"table_id": "<TABLE_ID>"},
        "metadata": {"owner": "ops"},
    },
    "subscription_test": {
        "eventType": "lead.created",
        "data": {"lead_id": "<LEAD_ID>", "source": "cli-test"},
    },
}

WEBHOOK_RECIPE_NOTES: Dict[str, List[str]] = {
    "ingest": [
        "Use this with webhooks ingest when writing rows through a table webhook token.",
    ],
    "subscription_create": [
        "retryPolicy is optional, but including it makes the request contract explicit for agents.",
    ],
    "subscription_update": [
        "Patch payloads can include only the fields you want to change.",
    ],
    "subscription_test": [
        "Use this to fire a synthetic event at a subscription endpoint.",
    ],
}

SHARED_SCHEMA_TYPES = [
    "filter_descriptor",
    "sort_spec",
    "run_request",
    "selection_descriptor",
]

SHARED_SCHEMAS: Dict[str, Dict[str, Any]] = {
    "filter_descriptor": {
        "mode": "and",
        "filters": [
            {"columnKey": "country", "operator": "equals", "value": "United States"},
            {"columnKey": "work_email", "operator": "isEmpty"},
        ],
    },
    "sort_spec": {"columnKey": "created_at", "direction": "desc"},
    "run_request": {
        "scope": "filtered",
        "filters": {
            "mode": "and",
            "filters": [
                {"columnKey": "company_domain", "operator": "isNotEmpty"},
                {"columnKey": "linkedin_url", "operator": "isNotEmpty"},
            ],
        },
        "unprocessedOnly": True,
        "firstN": 25,
    },
    "selection_descriptor": {
        "selection": {
            "mode": "descriptor",
            "descriptor": {
                "root": {
                    "kind": "group",
                    "logic": "and",
                    "children": [
                        {"kind": "rule", "field": "status", "operator": "eq", "value": "active"},
                    ],
                }
            },
            "sort": [{"field": "created_at", "direction": "desc"}],
            "limit": 100,
        }
    },
}

SHARED_SCHEMA_NOTES: Dict[str, List[str]] = {
    "filter_descriptor": [
        "Used by rows list, column runs, and conditional auto-run filters.",
    ],
    "sort_spec": [
        "Rows list accepts a sort object; some bulk selection APIs accept a list of sort objects.",
    ],
    "run_request": [
        "Use this shape with columns run or columns estimate when you want an explicit payload.",
    ],
    "selection_descriptor": [
        "Use this shape for ids-or-descriptor bulk selection APIs like leads and tasks bulk operations.",
    ],
}

AUTH_SCHEMA_TYPES = ["bootstrap", "login"]
AUTH_SCHEMAS: Dict[str, Dict[str, Any]] = {
    "bootstrap": {
        "first_name": "Ada",
        "last_name": "Lovelace",
        "email": "ada@example.com",
        "password": "use-a-strong-random-password",
        "organization_name": "Autotouch Labs",
        "keyName": "Agent bootstrap key",
        "scopes": ["tables:read", "tables:write"],
    },
    "login": {
        "email": "ada@example.com",
        "password": "use-a-strong-random-password",
    },
}
AUTH_SCHEMA_NOTES = {
    "bootstrap": ["Use this for auth bootstrap when you want to bypass individual flags and send the full payload."],
    "login": ["Use this for auth login when you want to provide the full payload via --data-json/--data-file."],
}

ONBOARDING_SCHEMA_TYPES = ["submit_domain"]
ONBOARDING_SCHEMAS = {
    "submit_domain": {
        "website": "https://www.autotouch.ai",
    }
}
ONBOARDING_SCHEMA_NOTES = {
    "submit_domain": ["Accepts website or domain; website is the most explicit form."],
}

ORG_CONTEXT_SCHEMA_TYPES = ["set"]
ORG_CONTEXT_SCHEMAS = {
    "set": {
        "source": "cli",
        "value_proposition": "We automate SDR research and admin work so reps can spend more time on live selling.",
        "ideal_titles": ["VP Sales", "Head of Growth"],
        "buyer_persona": "Revenue leadership",
        "user_persona": "SDR and AE teams",
        "voice_profile": "Direct, practical, operator-first.",
        "case_study_urls": ["https://example.com/case-study"],
    }
}
ORG_CONTEXT_SCHEMA_NOTES = {
    "set": ["Use this for org-context set when you want to send the full context payload instead of flags."],
}

PERSONAL_CONTEXT_SCHEMA_TYPES = ["set"]
PERSONAL_CONTEXT_SCHEMAS = {
    "set": {
        "title": "Founder",
        "linkedin_url": "https://www.linkedin.com/in/example",
        "territories": ["North America"],
        "personal_value_proposition": "I help GTM teams eliminate repetitive research work.",
        "voice_profile": "Founder-led, concise, technical.",
        "use_personal_value_proposition": True,
        "use_personal_voice_profile": True,
    }
}
PERSONAL_CONTEXT_SCHEMA_NOTES = {
    "set": ["Use this for personal-context set when you want the full JSON payload path."],
}

WORKSPACE_SECRET_SCHEMA_TYPES = ["set"]
WORKSPACE_SECRET_SCHEMAS = {
    "set": {
        "name": "clearbit",
        "value": "sk_live_replace_me",
    }
}
WORKSPACE_SECRET_SCHEMA_NOTES = {
    "set": [
        "Use this with workspace-secrets set when you want to pass the full payload via --data-json/--data-file.",
        "Developer API keys need secrets:write (or *) to create/update secrets.",
    ],
}

TABLE_SCHEMA_TYPES = ["create"]
TABLE_SCHEMAS = {
    "create": {
        "name": "CLI Contacts",
        "metadata": {"source": "csv_import", "owner": "ops"},
    }
}
TABLE_SCHEMA_NOTES = {
    "create": ["Use this with tables create when you want to pass the full payload instead of flags."],
}

ROW_SCHEMA_TYPES = ["add_records", "import_field_mappings"]
ROW_SCHEMAS = {
    "add_records": {
        "records": [
            {"first_name": "Jane", "last_name": "Doe", "company_domain": "acme.com"},
            {"first_name": "John", "last_name": "Smith", "company_domain": "example.com"},
        ]
    },
    "import_field_mappings": {
        "First Name": "first_name",
        "Last Name": "last_name",
        "Company Website": "company_domain",
        "LinkedIn URL": "linkedin_url",
    },
}
ROW_SCHEMA_NOTES = {
    "add_records": ["rows add also accepts a single object or a bare list; this recipe uses the explicit {records:[...]} form."],
    "import_field_mappings": ["Maps CSV headers to target column keys/standard fields for import-csv."],
}

CELL_SCHEMA_TYPES = ["patch_updates"]
CELL_SCHEMAS = {
    "patch_updates": {
        "updates": [
            {"rowId": "<ROW_ID>", "columnId": "<COLUMN_ID>", "value": "New value"},
            {"rowId": "<ROW_ID_2>", "columnId": "<COLUMN_ID>", "value": 42},
        ]
    }
}
CELL_SCHEMA_NOTES = {
    "patch_updates": ["cells patch accepts a bare list too; this schema uses the explicit updates[] wrapper."],
}


def _workflow_blueprint_payload(workflow_type: str) -> Dict[str, Any]:
    payload = WORKFLOW_BLUEPRINTS.get(workflow_type)
    if not payload:
        print(f"ERROR: unsupported workflow type '{workflow_type}'", file=sys.stderr)
        sys.exit(2)
    return json.loads(json.dumps(payload))


def _recipe_payload(recipe_type: str) -> Dict[str, Any]:
    payload = COLUMN_CREATE_RECIPES.get(recipe_type)
    if not payload:
        print(f"ERROR: unsupported recipe type '{recipe_type}'", file=sys.stderr)
        sys.exit(2)
    return json.loads(json.dumps(payload))


def _sequence_recipe_payload(recipe_type: str) -> Dict[str, Any]:
    payload = SEQUENCE_RECIPES.get(recipe_type)
    if not payload:
        print(f"ERROR: unsupported sequence recipe type '{recipe_type}'", file=sys.stderr)
        sys.exit(2)
    return json.loads(json.dumps(payload))


def _lead_recipe_payload(recipe_type: str) -> Dict[str, Any]:
    payload = LEAD_RECIPES.get(recipe_type)
    if not payload:
        print(f"ERROR: unsupported lead recipe type '{recipe_type}'", file=sys.stderr)
        sys.exit(2)
    return json.loads(json.dumps(payload))


def _task_recipe_payload(recipe_type: str) -> Dict[str, Any]:
    payload = TASK_RECIPES.get(recipe_type)
    if not payload:
        print(f"ERROR: unsupported task recipe type '{recipe_type}'", file=sys.stderr)
        sys.exit(2)
    return json.loads(json.dumps(payload))


def _webhook_recipe_payload(recipe_type: str) -> Dict[str, Any]:
    payload = WEBHOOK_RECIPES.get(recipe_type)
    if not payload:
        print(f"ERROR: unsupported webhook recipe type '{recipe_type}'", file=sys.stderr)
        sys.exit(2)
    return json.loads(json.dumps(payload))


def _schema_payload(recipe_type: str, payloads: Dict[str, Dict[str, Any]], *, noun: str) -> Dict[str, Any]:
    payload = payloads.get(recipe_type)
    if not payload:
        print(f"ERROR: unsupported {noun} type '{recipe_type}'", file=sys.stderr)
        sys.exit(2)
    return json.loads(json.dumps(payload))


def _write_json_file(path: Optional[str], payload: Any) -> None:
    if path:
        with open(path, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2)


def _emit_template_bundle(
    *,
    selected_type: str,
    template_types: List[str],
    payload_getter: Callable[[str], Dict[str, Any]],
    notes_lookup: Dict[str, List[str]],
    usage_lookup: Any,
    label: str,
    out_file: Optional[str],
    compact: bool,
    runtime: TemplateRuntime,
) -> None:
    if selected_type == "all":
        payloads = {name: payload_getter(name) for name in template_types}
        output = {
            "recipes" if label == "recipe" else "schemas": payloads,
            "notes": notes_lookup,
            "usage": usage_lookup,
        }
        _write_json_file(out_file, output)
        if runtime.output_mode == "human":
            title = "Recipes" if label == "recipe" else "Schemas"
            runtime.emit_text(title)
            runtime.emit_text("-" * len(title))
            for name in template_types:
                runtime.emit_text("")
                _print_generic_template_human(
                    label=label,
                    recipe_type=name,
                    payload=payloads[name],
                    notes=notes_lookup.get(name) or [],
                    usage=usage_lookup.get(name) if isinstance(usage_lookup, dict) else usage_lookup,
                    out_file=None,
                    runtime=runtime,
                )
            if out_file:
                runtime.emit_text(f"\nSaved: {out_file}")
            return
        runtime.print_json(output, compact)
        return

    payload = payload_getter(selected_type)
    output = {
        "type": selected_type,
        "payload": payload,
        "notes": notes_lookup.get(selected_type) or [],
        "usage": usage_lookup.get(selected_type) if isinstance(usage_lookup, dict) else usage_lookup,
    }
    _write_json_file(out_file, payload)
    if runtime.output_mode == "human":
        _print_generic_template_human(
            label=label,
            recipe_type=selected_type,
            payload=payload,
            notes=notes_lookup.get(selected_type) or [],
            usage=output["usage"],
            out_file=out_file,
            runtime=runtime,
        )
        return
    runtime.print_json(output, compact)


def _print_generic_template_human(
    *,
    label: str,
    recipe_type: str,
    payload: Dict[str, Any],
    notes: List[str],
    usage: Any,
    out_file: Optional[str],
    runtime: TemplateRuntime,
) -> None:
    runtime.emit_text(f"{recipe_type} {label}")
    runtime.emit_text("----------------")
    runtime.emit_text(json.dumps(payload, indent=2))
    if notes:
        runtime.emit_text("")
        for note in notes:
            runtime.emit_text(f"- {note}")
    if usage:
        runtime.emit_text("\nUse with:")
        if isinstance(usage, dict):
            for command in usage.values():
                runtime.emit_text(str(command))
        else:
            runtime.emit_text(str(usage))
    if out_file:
        runtime.emit_text(f"\nSaved payload file: {out_file}")


def emit_workflows_list(args: argparse.Namespace, runtime: TemplateRuntime) -> None:
    blueprints = {name: _workflow_blueprint_payload(name) for name in WORKFLOW_BLUEPRINT_TYPES}
    output = {
        "workflows": blueprints,
        "usage": "autotouch workflows recipe --type <WORKFLOW_TYPE> --out-file <workflow.json>",
        "notes": [
            "Workflow blueprints describe recommended multi-step pipelines; they do not create tables/columns automatically.",
            "Use workflow blueprints together with `autotouch columns recipe`, `autotouch sequences recipe`, and `autotouch capabilities`.",
        ],
    }
    _write_json_file(getattr(args, "out_file", None), output)
    if runtime.output_mode == "human":
        runtime.emit_text("Workflow blueprints")
        runtime.emit_text("-------------------")
        for name in WORKFLOW_BLUEPRINT_TYPES:
            bp = blueprints[name]
            runtime.emit_text(f"\n[{name}]")
            runtime.emit_text(f"Goal: {bp.get('goal') or 'n/a'}")
            recommended_when = bp.get("recommended_when") or []
            if recommended_when:
                runtime.emit_text("Recommended when:")
                for note in recommended_when:
                    runtime.emit_text(f"- {note}")
            steps = bp.get("steps") or []
            if steps:
                runtime.emit_text("Steps:")
                for idx, step in enumerate(steps, start=1):
                    provider = step.get("provider") or "unknown"
                    purpose = step.get("purpose") or ""
                    runtime.emit_text(f"{idx}. {provider}: {purpose}")
        runtime.emit_text("\nUse with:")
        runtime.emit_text("autotouch workflows recipe --type <WORKFLOW_TYPE> --out-file <workflow.json>")
        if getattr(args, "out_file", None):
            runtime.emit_text(f"\nSaved: {args.out_file}")
        return
    runtime.print_json(output, getattr(args, "compact", False))


def emit_workflows_recipe(args: argparse.Namespace, runtime: TemplateRuntime) -> None:
    selected_type = str(args.type or "")
    payload = _workflow_blueprint_payload(selected_type)
    output = {
        "type": selected_type,
        "workflow": payload,
        "usage": {
            "columns_recipe": "autotouch columns recipe --type <COLUMN_TYPE> --out-file <payload.json>",
            "sequence_recipe": "autotouch sequences recipe --type create --out-file <payload.json>",
            "capabilities": "autotouch capabilities --output json",
        },
    }
    _write_json_file(getattr(args, "out_file", None), payload)
    if runtime.output_mode == "human":
        runtime.emit_text(f"{selected_type} workflow")
        runtime.emit_text("----------------")
        runtime.emit_text(json.dumps(payload, indent=2))
        runtime.emit_text("\nUse with:")
        runtime.emit_text("autotouch columns recipe --type <COLUMN_TYPE> --out-file <payload.json>")
        runtime.emit_text("autotouch sequences recipe --type create --out-file <payload.json>")
        if getattr(args, "out_file", None):
            runtime.emit_text(f"\nSaved workflow file: {args.out_file}")
        return
    runtime.print_json(output, getattr(args, "compact", False))


def emit_columns_recipe(args: argparse.Namespace, runtime: TemplateRuntime) -> None:
    selected_type = str(args.type or "all")
    if selected_type == "all":
        recipes = {name: _recipe_payload(name) for name in COLUMN_RECIPE_TYPES}
        output = {
            "recipes": recipes,
            "notes": COLUMN_RECIPE_NOTES,
            "usage": "autotouch columns create --table-id <TABLE_ID> --data-file <payload.json>",
        }
        _write_json_file(getattr(args, "out_file", None), output)
        if runtime.output_mode == "human":
            runtime.emit_text("Column create payload recipes")
            runtime.emit_text("-----------------------------")
            for name in COLUMN_RECIPE_TYPES:
                runtime.emit_text(f"\n[{name}]")
                runtime.emit_text(json.dumps(recipes[name], indent=2))
                for note in COLUMN_RECIPE_NOTES.get(name) or []:
                    runtime.emit_text(f"- {note}")
            runtime.emit_text("\nUse with:")
            runtime.emit_text("autotouch columns create --table-id <TABLE_ID> --data-file <payload.json>")
            if getattr(args, "out_file", None):
                runtime.emit_text(f"\nSaved: {args.out_file}")
            return
        runtime.print_json(output, getattr(args, "compact", False))
        return

    payload = _recipe_payload(selected_type)
    output_single = {
        "type": selected_type,
        "payload": payload,
        "notes": COLUMN_RECIPE_NOTES.get(selected_type) or [],
        "usage": "autotouch columns create --table-id <TABLE_ID> --data-file <payload.json>",
    }
    _write_json_file(getattr(args, "out_file", None), payload)
    if runtime.output_mode == "human":
        runtime.emit_text(f"{selected_type} payload")
        runtime.emit_text("----------------")
        runtime.emit_text(json.dumps(payload, indent=2))
        for note in COLUMN_RECIPE_NOTES.get(selected_type) or []:
            runtime.emit_text(f"- {note}")
        runtime.emit_text("\nUse with:")
        runtime.emit_text("autotouch columns create --table-id <TABLE_ID> --data-file <payload.json>")
        if getattr(args, "out_file", None):
            runtime.emit_text(f"\nSaved payload file: {args.out_file}")
        return
    runtime.print_json(output_single, getattr(args, "compact", False))


def emit_sequences_recipe(args: argparse.Namespace, runtime: TemplateRuntime) -> None:
    _emit_template_bundle(
        selected_type=str(args.type or "all"),
        template_types=SEQUENCE_RECIPE_TYPES,
        payload_getter=_sequence_recipe_payload,
        notes_lookup=SEQUENCE_RECIPE_NOTES,
        usage_lookup={
            "create": "autotouch sequences create --data-file <payload.json>",
            "bulk_automated": "autotouch sequences create --data-file <payload.json>",
            "enroll": "autotouch sequences enroll --sequence-id <SEQUENCE_ID> --data-file <payload.json>",
        },
        label="recipe",
        out_file=getattr(args, "out_file", None),
        compact=getattr(args, "compact", False),
        runtime=runtime,
    )


def emit_leads_recipe(args: argparse.Namespace, runtime: TemplateRuntime) -> None:
    _emit_template_bundle(
        selected_type=str(args.type or "all"),
        template_types=LEAD_RECIPE_TYPES,
        payload_getter=_lead_recipe_payload,
        notes_lookup=LEAD_RECIPE_NOTES,
        usage_lookup={
            "create": "autotouch leads create --data-file <payload.json>",
            "update": "autotouch leads update --lead-id <LEAD_ID> --data-file <payload.json>",
            "contact_upsert": "autotouch leads upsert-contact-channels --lead-id <LEAD_ID> --data-file <payload.json>",
            "query": "autotouch leads query --data-file <payload.json>",
            "research": "autotouch leads research --data-file <payload.json>",
            "selection": "autotouch leads update-status --data-file <payload.json> --status <STATUS>",
        },
        label="recipe",
        out_file=getattr(args, "out_file", None),
        compact=getattr(args, "compact", False),
        runtime=runtime,
    )


def emit_tasks_recipe(args: argparse.Namespace, runtime: TemplateRuntime) -> None:
    _emit_template_bundle(
        selected_type=str(args.type or "all"),
        template_types=TASK_RECIPE_TYPES,
        payload_getter=_task_recipe_payload,
        notes_lookup=TASK_RECIPE_NOTES,
        usage_lookup={
            "query": "autotouch tasks query --data-file <payload.json>",
            "create": "autotouch tasks create --data-file <payload.json>",
            "update": "autotouch tasks update --task-id <TASK_ID> --data-file <payload.json>",
            "bulk_update": "autotouch tasks bulk-update --data-file <payload.json>",
            "bulk_delete": "autotouch tasks bulk-delete --data-file <payload.json>",
            "draft": "autotouch tasks draft --task-id <TASK_ID> --data-file <payload.json>",
            "schedule_email": "autotouch tasks schedule-email --task-id <TASK_ID> --data-file <payload.json>",
        },
        label="recipe",
        out_file=getattr(args, "out_file", None),
        compact=getattr(args, "compact", False),
        runtime=runtime,
    )


def emit_webhooks_recipe(args: argparse.Namespace, runtime: TemplateRuntime) -> None:
    _emit_template_bundle(
        selected_type=str(args.type or "all"),
        template_types=WEBHOOK_RECIPE_TYPES,
        payload_getter=_webhook_recipe_payload,
        notes_lookup=WEBHOOK_RECIPE_NOTES,
        usage_lookup={
            "ingest": "autotouch webhooks ingest --table-id <TABLE_ID> --records-file <payload.json>",
            "subscription_create": "autotouch webhooks subscriptions create --data-file <payload.json>",
            "subscription_update": "autotouch webhooks subscriptions update --subscription-id <SUB_ID> --data-file <payload.json>",
            "subscription_test": "autotouch webhooks subscriptions test --subscription-id <SUB_ID> --data-file <payload.json>",
        },
        label="recipe",
        out_file=getattr(args, "out_file", None),
        compact=getattr(args, "compact", False),
        runtime=runtime,
    )


def emit_schema(args: argparse.Namespace, runtime: TemplateRuntime) -> None:
    _emit_template_bundle(
        selected_type=str(args.type or "all"),
        template_types=SHARED_SCHEMA_TYPES,
        payload_getter=lambda schema_type: _schema_payload(schema_type, SHARED_SCHEMAS, noun="schema"),
        notes_lookup=SHARED_SCHEMA_NOTES,
        usage_lookup={
            "filter_descriptor": "Use with rows list, columns run, or conditional auto-run payloads.",
            "sort_spec": "Use with rows list or descriptor-based APIs that accept sort JSON.",
            "run_request": "autotouch columns run --table-id <TABLE_ID> --column-id <COLUMN_ID> --data-file <payload.json>",
            "selection_descriptor": "Use with tasks/leads bulk operations that accept selection payloads.",
        },
        label="schema",
        out_file=getattr(args, "out_file", None),
        compact=getattr(args, "compact", False),
        runtime=runtime,
    )


def emit_auth_schema(args: argparse.Namespace, runtime: TemplateRuntime) -> None:
    _emit_template_bundle(
        selected_type=str(args.type or "all"),
        template_types=AUTH_SCHEMA_TYPES,
        payload_getter=lambda schema_type: _schema_payload(schema_type, AUTH_SCHEMAS, noun="auth schema"),
        notes_lookup=AUTH_SCHEMA_NOTES,
        usage_lookup={
            "bootstrap": "autotouch auth bootstrap --data-file <payload.json>",
            "login": "autotouch auth login --data-file <payload.json>",
        },
        label="schema",
        out_file=getattr(args, "out_file", None),
        compact=getattr(args, "compact", False),
        runtime=runtime,
    )


def emit_onboarding_schema(args: argparse.Namespace, runtime: TemplateRuntime) -> None:
    _emit_template_bundle(
        selected_type=str(args.type or "all"),
        template_types=ONBOARDING_SCHEMA_TYPES,
        payload_getter=lambda schema_type: _schema_payload(schema_type, ONBOARDING_SCHEMAS, noun="onboarding schema"),
        notes_lookup=ONBOARDING_SCHEMA_NOTES,
        usage_lookup={"submit_domain": "autotouch onboarding submit-domain --data-file <payload.json>"},
        label="schema",
        out_file=getattr(args, "out_file", None),
        compact=getattr(args, "compact", False),
        runtime=runtime,
    )


def emit_org_context_schema(args: argparse.Namespace, runtime: TemplateRuntime) -> None:
    _emit_template_bundle(
        selected_type=str(args.type or "all"),
        template_types=ORG_CONTEXT_SCHEMA_TYPES,
        payload_getter=lambda schema_type: _schema_payload(schema_type, ORG_CONTEXT_SCHEMAS, noun="org-context schema"),
        notes_lookup=ORG_CONTEXT_SCHEMA_NOTES,
        usage_lookup={"set": "autotouch org-context set --data-file <payload.json>"},
        label="schema",
        out_file=getattr(args, "out_file", None),
        compact=getattr(args, "compact", False),
        runtime=runtime,
    )


def emit_personal_context_schema(args: argparse.Namespace, runtime: TemplateRuntime) -> None:
    _emit_template_bundle(
        selected_type=str(args.type or "all"),
        template_types=PERSONAL_CONTEXT_SCHEMA_TYPES,
        payload_getter=lambda schema_type: _schema_payload(schema_type, PERSONAL_CONTEXT_SCHEMAS, noun="personal-context schema"),
        notes_lookup=PERSONAL_CONTEXT_SCHEMA_NOTES,
        usage_lookup={"set": "autotouch personal-context set --data-file <payload.json>"},
        label="schema",
        out_file=getattr(args, "out_file", None),
        compact=getattr(args, "compact", False),
        runtime=runtime,
    )


def emit_workspace_secrets_schema(args: argparse.Namespace, runtime: TemplateRuntime) -> None:
    _emit_template_bundle(
        selected_type=str(args.type or "all"),
        template_types=WORKSPACE_SECRET_SCHEMA_TYPES,
        payload_getter=lambda schema_type: _schema_payload(schema_type, WORKSPACE_SECRET_SCHEMAS, noun="workspace-secrets schema"),
        notes_lookup=WORKSPACE_SECRET_SCHEMA_NOTES,
        usage_lookup={"set": "autotouch workspace-secrets set --data-file <payload.json>"},
        label="schema",
        out_file=getattr(args, "out_file", None),
        compact=getattr(args, "compact", False),
        runtime=runtime,
    )


def emit_tables_schema(args: argparse.Namespace, runtime: TemplateRuntime) -> None:
    _emit_template_bundle(
        selected_type=str(args.type or "all"),
        template_types=TABLE_SCHEMA_TYPES,
        payload_getter=lambda schema_type: _schema_payload(schema_type, TABLE_SCHEMAS, noun="tables schema"),
        notes_lookup=TABLE_SCHEMA_NOTES,
        usage_lookup={"create": "autotouch tables create --data-file <payload.json>"},
        label="schema",
        out_file=getattr(args, "out_file", None),
        compact=getattr(args, "compact", False),
        runtime=runtime,
    )


def emit_rows_schema(args: argparse.Namespace, runtime: TemplateRuntime) -> None:
    _emit_template_bundle(
        selected_type=str(args.type or "all"),
        template_types=ROW_SCHEMA_TYPES,
        payload_getter=lambda schema_type: _schema_payload(schema_type, ROW_SCHEMAS, noun="rows schema"),
        notes_lookup=ROW_SCHEMA_NOTES,
        usage_lookup={
            "add_records": "autotouch rows add --table-id <TABLE_ID> --records-file <payload.json>",
            "import_field_mappings": "autotouch rows import-csv --table-id <TABLE_ID> --file contacts.csv --field-mappings-file <payload.json>",
        },
        label="schema",
        out_file=getattr(args, "out_file", None),
        compact=getattr(args, "compact", False),
        runtime=runtime,
    )


def emit_cells_schema(args: argparse.Namespace, runtime: TemplateRuntime) -> None:
    _emit_template_bundle(
        selected_type=str(args.type or "all"),
        template_types=CELL_SCHEMA_TYPES,
        payload_getter=lambda schema_type: _schema_payload(schema_type, CELL_SCHEMAS, noun="cells schema"),
        notes_lookup=CELL_SCHEMA_NOTES,
        usage_lookup={"patch_updates": "autotouch cells patch --table-id <TABLE_ID> --updates-file <payload.json>"},
        label="schema",
        out_file=getattr(args, "out_file", None),
        compact=getattr(args, "compact", False),
        runtime=runtime,
    )
