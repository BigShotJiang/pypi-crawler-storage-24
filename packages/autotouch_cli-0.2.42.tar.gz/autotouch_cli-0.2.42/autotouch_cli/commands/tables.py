from __future__ import annotations

import argparse
import sys
from dataclasses import dataclass
from typing import Any, Callable, Dict, Optional, Sequence


@dataclass(frozen=True)
class TableCommandRuntime:
    resolve_token: Callable[[Optional[str], bool], Optional[str]]
    request_api: Callable[..., Any]
    print_json: Callable[[Any, bool], None]
    load_json_input: Callable[..., Any]


def cmd_tables_list(args: argparse.Namespace, *, runtime: TableCommandRuntime) -> None:
    token = runtime.resolve_token(args.token, required=True)
    params: Dict[str, Any] = {}
    if args.view_mode:
        params["view_mode"] = args.view_mode
    data = runtime.request_api(
        "GET",
        "/api/tables",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        params=params or None,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    runtime.print_json(data, args.compact)


def cmd_tables_create(args: argparse.Namespace, *, runtime: TableCommandRuntime) -> None:
    token = runtime.resolve_token(args.token, required=True)
    data_payload = runtime.load_json_input(
        inline_json=args.data_json,
        file_path=args.data_file,
        context="data",
        default=None,
    )
    if data_payload is not None:
        if not isinstance(data_payload, dict):
            print("ERROR: table create payload must be a JSON object", file=sys.stderr)
            sys.exit(2)
        payload = data_payload
    else:
        if not args.name:
            print("ERROR: --name is required when --data-* is not provided", file=sys.stderr)
            sys.exit(2)
        metadata = runtime.load_json_input(
            inline_json=args.metadata_json,
            file_path=args.metadata_file,
            context="metadata",
            default={},
        )
        if metadata is None:
            metadata = {}
        if not isinstance(metadata, dict):
            print("ERROR: metadata must be a JSON object", file=sys.stderr)
            sys.exit(2)
        payload = {"name": args.name, "metadata": metadata}

    data = runtime.request_api(
        "POST",
        "/api/tables",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        payload=payload,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    runtime.print_json(data, args.compact)


def register_tables_subcommands(
    subparsers: argparse._SubParsersAction[argparse.ArgumentParser],
    *,
    add_api_common_arguments: Callable[[argparse.ArgumentParser], None],
    add_output_formatting_arguments: Callable[[argparse.ArgumentParser], None],
    handlers: Dict[str, Callable[[argparse.Namespace], None]],
    table_schema_types: Sequence[str],
) -> None:
    pt = subparsers.add_parser("tables", help="Table operations")
    tables_sub = pt.add_subparsers(dest="tables_cmd", required=True)

    ptl = tables_sub.add_parser("list", help="List tables")
    ptl.add_argument("--view-mode", help="Optional view mode filter")
    add_api_common_arguments(ptl)
    ptl.set_defaults(func=handlers["list"])

    ptc = tables_sub.add_parser("create", help="Create a table")
    ptc.add_argument("--name", help="Table name (when not using --data-json/--data-file)")
    ptc.add_argument("--metadata-json", help="Optional table metadata JSON object")
    ptc.add_argument("--metadata-file", help="Optional file with table metadata JSON")
    ptc.add_argument("--data-json", help="Explicit table create payload JSON")
    ptc.add_argument("--data-file", help="Path to table create payload JSON file")
    add_api_common_arguments(ptc)
    ptc.set_defaults(func=handlers["create"])

    ptschema = tables_sub.add_parser("schema", help="Print table payload schemas")
    ptschema.add_argument("--type", choices=["all", *table_schema_types], default="all")
    ptschema.add_argument("--out-file", help="Write schema JSON to file")
    add_output_formatting_arguments(ptschema)
    ptschema.set_defaults(func=handlers["schema"])
