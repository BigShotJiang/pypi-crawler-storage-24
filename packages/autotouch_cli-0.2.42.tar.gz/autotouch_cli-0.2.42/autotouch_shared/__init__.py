"""Shared Autotouch contracts and metadata."""
