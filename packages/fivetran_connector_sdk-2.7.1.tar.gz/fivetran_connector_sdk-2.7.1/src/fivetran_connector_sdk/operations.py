import json

from datetime import datetime, date
from google.protobuf import timestamp_pb2

from fivetran_connector_sdk.constants import (
    JAVA_LONG_MAX_VALUE, TABLES, UPDATE_TYPE, DELETE_TYPE,
    UPSERT_TYPE, UNSPECIFIED_COLUMNS_TYPE, TABLES_COLUMNS_TYPES
)
from fivetran_connector_sdk.protos import connector_sdk_pb2, common_pb2
from fivetran_connector_sdk.operation_stream import _OperationStream


class Operations:
    operation_stream = _OperationStream()

    @staticmethod
    def upsert(table: str, data: dict):
        """Updates records with the same primary key if already present in the destination. Inserts new records if not already present in the destination.

        Args:
            table (str): The name of the table.
            data (dict): The data to upsert.

        Returns:
            list[connector_sdk_pb2.UpdateResponse]: A list of update responses.
        """
        columns = _get_columns(table)
        mapped_data = _map_data_to_columns(data, columns)
        record = connector_sdk_pb2.Record(
            schema_name=None,
            table_name=table,
            type=UPSERT_TYPE,
            data=mapped_data
        )

        Operations.operation_stream.add(record)

    @staticmethod
    def update(table: str, modified: dict):
        """Performs an update operation on the specified table with the given modified data.

        Args:
            table (str): The name of the table.
            modified (dict): The modified data.

        Returns:
            connector_sdk_pb2.UpdateResponse: The update response.
        """
        columns = _get_columns(table)
        mapped_data = _map_data_to_columns(modified, columns)
        record = connector_sdk_pb2.Record(
            schema_name=None,
            table_name=table,
            type=UPDATE_TYPE,
            data=mapped_data
        )

        Operations.operation_stream.add(record)

    @staticmethod
    def delete(table: str, keys: dict):
        """Performs a soft delete operation on the specified table with the given keys.

        Args:
            table (str): The name of the table.
            keys (dict): The keys to delete.

        Returns:
            connector_sdk_pb2.UpdateResponse: The delete response.
        """
        columns = _get_columns(table)
        mapped_data = _map_data_to_columns(keys, columns)
        record = connector_sdk_pb2.Record(
            schema_name=None,
            table_name=table,
            type=DELETE_TYPE,
            data=mapped_data
        )

        Operations.operation_stream.add(record)

    @staticmethod
    def checkpoint(state: dict):
        """Checkpoint saves the connector's state. State is a dict which stores information to continue the
        sync from where it left off in the previous sync. For example, you may choose to have a field called
        "cursor" with a timestamp value to indicate up to when the data has been synced. This makes it possible
        for the next sync to fetch data incrementally from that time forward. See below for a few example fields
        which act as parameters for use by the connector code.\n
        {
            "initialSync": true,\n
            "cursor": "1970-01-01T00:00:00.00Z",\n
            "last_resync": "1970-01-01T00:00:00.00Z",\n
            "thread_count": 5,\n
            "api_quota_left": 5000000
        }

        Args:
            state (dict): The state to checkpoint/save.

        Returns:
            connector_sdk_pb2.UpdateResponse: The checkpoint response.
        """
        checkpoint = connector_sdk_pb2.Checkpoint(state_json=json.dumps(state))

        Operations.operation_stream.add(checkpoint)

def _get_columns(table: str) -> dict:
    """Retrieves the columns and maps to their type for the specified table.

    Args:
        table (str): The name of the table.

    Returns:
        dict: The columns for the table.
    """
    columns = {}
    if table in TABLES_COLUMNS_TYPES:
        columns = TABLES_COLUMNS_TYPES[table]
    if not columns and table in TABLES:
        for column in TABLES[table].columns:
            columns[column.name] = column.type
        TABLES_COLUMNS_TYPES[table] = columns

    return columns

def _map_data_to_columns(data: dict, columns: dict) -> dict:
    """Maps data to the specified columns.

    Args:
        data (dict): The data to map.
        columns (dict): The columns to map the data to.

    Returns:
        dict: The mapped data.
    """
    mapped_data = {}
    for key, v in data.items():
        if v is None:
            mapped_data[key] = common_pb2.ValueType(null=True)
        elif (key in columns) and columns[key] != UNSPECIFIED_COLUMNS_TYPE:
            map_defined_data_type(columns[key], key, mapped_data, v)
        else:
            map_inferred_data_type(key, mapped_data, v)
    return mapped_data

_INFERENCE_TYPE_HANDLERS = {
    int: lambda v: common_pb2.ValueType(float=v) if abs(v)>JAVA_LONG_MAX_VALUE else common_pb2.ValueType(long=v),
    float: lambda v: common_pb2.ValueType(float=v),
    bool: lambda v: common_pb2.ValueType(bool=v),
    bytes: lambda v: common_pb2.ValueType(binary=v),
    dict: lambda v: common_pb2.ValueType(json=json.dumps(v)),
    str: lambda v: common_pb2.ValueType(string=v)
}

def map_inferred_data_type(k, mapped_data, v):
    data_type = type(v)
    handler = _INFERENCE_TYPE_HANDLERS.get(data_type)
    if handler:
        mapped_data[k] = handler(v)
    elif isinstance(v, bool):
        mapped_data[k] = common_pb2.ValueType(bool=v)
    elif isinstance(v, int):
        if abs(v) > JAVA_LONG_MAX_VALUE:
            mapped_data[k] = common_pb2.ValueType(float=v)
        else:
            mapped_data[k] = common_pb2.ValueType(long=v)
    elif isinstance(v, float):
        mapped_data[k] = common_pb2.ValueType(float=v)
    elif isinstance(v, bytes):
        mapped_data[k] = common_pb2.ValueType(binary=v)
    elif isinstance(v, (list, dict)):
        mapped_data[k] = common_pb2.ValueType(json=json.dumps(v))
    elif isinstance(v, str):
        mapped_data[k] = common_pb2.ValueType(string=v)
    else:
        # Convert arbitrary objects to string
        mapped_data[k] = common_pb2.ValueType(string=str(v))

_TYPE_HANDLERS = {
    common_pb2.DataType.BOOLEAN: lambda val: common_pb2.ValueType(bool=val),
    common_pb2.DataType.SHORT: lambda val: common_pb2.ValueType(short=val),
    common_pb2.DataType.INT: lambda val: common_pb2.ValueType(int=val),
    common_pb2.DataType.LONG: lambda val: common_pb2.ValueType(long=val),
    common_pb2.DataType.DECIMAL: lambda val: common_pb2.ValueType(decimal=val),
    common_pb2.DataType.FLOAT: lambda val: common_pb2.ValueType(float=val),
    common_pb2.DataType.DOUBLE: lambda val: common_pb2.ValueType(double=val),
    common_pb2.DataType.NAIVE_DATE: lambda val: common_pb2.ValueType(naive_date= _parse_naive_date_str(val)),
    common_pb2.DataType.NAIVE_DATETIME: lambda val: common_pb2.ValueType(naive_datetime= _parse_naive_datetime_str(val)),
    common_pb2.DataType.UTC_DATETIME: lambda val: common_pb2.ValueType(utc_datetime= _parse_utc_datetime_str(val)),
    common_pb2.DataType.BINARY: lambda val: common_pb2.ValueType(binary=val),
    common_pb2.DataType.XML: lambda val: common_pb2.ValueType(xml=val),
    common_pb2.DataType.STRING: lambda val: common_pb2.ValueType(string=val if isinstance(val, str) else str(val)),
    common_pb2.DataType.JSON: lambda val: common_pb2.ValueType(json=json.dumps(val))
}

def map_defined_data_type(data_type, k, mapped_data, v):
    handler = _TYPE_HANDLERS.get(data_type)
    if handler:
        mapped_data[k] = handler(v)
    else:
        raise ValueError(f"Unsupported data type encountered: {data_type}. Please use valid data types.")

def _parse_utc_datetime_str(v):
    """
    Accepts a timezone-aware datetime object or a datetime string in one of the following formats:
    - '%Y-%m-%dT%H:%M:%S.%f%z' (e.g., '2025-08-12T15:00:00.123456+00:00')
    - '%Y-%m-%dT%H:%M:%S%z'    (e.g., '2025-08-12T15:00:00+00:00')
    - Same as above formats but with a space instead of 'T' as the separator (e.g., '2025-08-12 15:00:00+00:00')

    Returns a `google.protobuf.timestamp_pb2.Timestamp` object.
    """
    timestamp = timestamp_pb2.Timestamp()
    dt = v
    if not isinstance(v, datetime):
        dt = dt.strip().replace(' ', 'T', 1)  # Replace first space with 'T' for ISO format
        dt = datetime.strptime(dt, "%Y-%m-%dT%H:%M:%S.%f%z" if '.' in dt else "%Y-%m-%dT%H:%M:%S%z")
    timestamp.FromDatetime(dt)
    return timestamp

def _parse_naive_datetime_str(v):
    """
    Accepts a datetime.datetime object or naive datetime string in one of the following formats:
    - '%Y-%m-%dT%H:%M:%S.%f'
    - '%Y-%m-%d %H:%M:%S.%f'
    Returns a `google.protobuf.timestamp_pb2.Timestamp` object.
    """
    timestamp = timestamp_pb2.Timestamp()
    dt = v
    if not isinstance(v, datetime):
        dt = dt.strip().replace(' ', 'T', 1)  # Replace first space with 'T' for ISO format
        dt = datetime.strptime(dt, "%Y-%m-%dT%H:%M:%S.%f" if '.' in dt else "%Y-%m-%dT%H:%M:%S")

    timestamp.FromDatetime(dt)
    return timestamp

def _parse_naive_date_str(v):
    """
    Accepts a `datetime.date` object or a date string ('YYYY-MM-DD'),
    Returns a `google.protobuf.timestamp_pb2.Timestamp` object.
    """
    timestamp = timestamp_pb2.Timestamp()

    if isinstance(v, str):
        dt = datetime.strptime(v, "%Y-%m-%d")
    elif isinstance(v, (datetime, date)):
        dt = datetime.combine(v if isinstance(v, date) else v.date(), datetime.min.time())
    else:
        raise TypeError(f"Expected str, datetime.date, or datetime.datetime, got {type(v)}")

    timestamp.FromDatetime(dt)
    return timestamp
