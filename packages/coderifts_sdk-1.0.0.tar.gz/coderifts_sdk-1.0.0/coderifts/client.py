"""CodeRifts HTTP client with auth and error handling."""

import requests

from .exceptions import ApiError, AuthError, CodeRiftsError, RateLimitError

DEFAULT_BASE_URL = "https://app.coderifts.com/api/v1"
DEFAULT_TIMEOUT = 30


class _Response:
    """Dot-access wrapper around a dict response."""

    def __init__(self, data: dict):
        self._data = data

    def __getattr__(self, name: str):
        try:
            value = self._data[name]
        except KeyError:
            raise AttributeError(f"Response has no attribute '{name}'")
        if isinstance(value, dict):
            return _Response(value)
        return value

    def __repr__(self):
        return f"Response({self._data})"

    def __contains__(self, key):
        return key in self._data

    def __getitem__(self, key):
        return self._data[key]

    def to_dict(self) -> dict:
        """Return the raw response dict."""
        return self._data


class CodeRifts:
    """CodeRifts API client.

    Args:
        api_key: Your CodeRifts API key (starts with ``cr_live_`` or ``cr_test_``).
        base_url: Override the default API base URL.
        timeout: Request timeout in seconds.
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: int = DEFAULT_TIMEOUT,
    ):
        if not api_key:
            raise AuthError("API key is required")
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._session = requests.Session()
        self._session.headers.update(
            {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "User-Agent": "coderifts-python-sdk/1.0.0",
            }
        )

    # ── internal ──────────────────────────────────────────────

    def _request(self, method: str, path: str, **kwargs) -> dict:
        url = f"{self._base_url}{path}"
        try:
            resp = self._session.request(
                method, url, timeout=self._timeout, **kwargs
            )
        except requests.exceptions.Timeout:
            raise CodeRiftsError("Request timed out", "timeout_error")
        except requests.exceptions.ConnectionError:
            raise CodeRiftsError("Connection failed", "connection_error")

        if resp.status_code == 401:
            raise AuthError()
        if resp.status_code == 429:
            raise RateLimitError()
        if resp.status_code >= 400:
            try:
                body = resp.json()
                msg = body.get("error", body.get("message", resp.text))
            except Exception:
                msg = resp.text
            raise ApiError(str(msg), status_code=resp.status_code)

        try:
            return resp.json()
        except Exception:
            return {"raw": resp.text}

    def _post(self, path: str, body: dict) -> _Response:
        data = self._request("POST", path, json=body)
        return _Response(data)

    def _get(self, path: str, params: dict = None) -> _Response:
        data = self._request("GET", path, params=params)
        return _Response(data)

    # ── public methods ────────────────────────────────────────

    def diff(self, before: str, after: str) -> _Response:
        """Run a full OpenAPI spec diff analysis.

        Args:
            before: The old OpenAPI spec (YAML or JSON string).
            after: The new OpenAPI spec (YAML or JSON string).

        Returns:
            Response with ``omega_decision``, ``risk_score``,
            ``breaking_changes``, ``before``, ``after``, etc.
        """
        return self._post("/diff", {"before": before, "after": after})

    def preflight_check(
        self,
        tool_name: str,
        old_spec: str,
        new_spec: str,
    ) -> _Response:
        """Check if a tool invocation is safe.

        Args:
            tool_name: Name of the tool being invoked.
            old_spec: The previous OpenAPI spec.
            new_spec: The new OpenAPI spec.

        Returns:
            Response with ``decision``, ``safe``, ``reflex_triggers``.
        """
        return self._post(
            "/agent/preflight",
            {
                "tool_name": tool_name,
                "old_spec": old_spec,
                "new_spec": new_spec,
            },
        )

    def explain_decision(
        self,
        omega_api: float,
        decision: str,
        reflex_triggers: list = None,
    ) -> _Response:
        """Get a human-readable explanation of a governance decision.

        Args:
            omega_api: The omega API score.
            decision: The decision string (BLOCK, WARN, ALLOW, etc.).
            reflex_triggers: List of triggered reflex rules.

        Returns:
            Response with ``explanation``, ``summary``.
        """
        triggers = reflex_triggers or []
        lines = [f"Decision: {decision} (omega_api={omega_api})"]
        if decision == "BLOCK":
            lines.append(
                "This change was BLOCKED because it introduces breaking "
                "changes that exceed the safety threshold."
            )
        elif decision == "WARN":
            lines.append(
                "This change triggered a WARNING. Review recommended "
                "before merging."
            )
        else:
            lines.append("This change is ALLOWED to proceed.")

        if triggers:
            lines.append(f"Triggered rules: {', '.join(str(t) for t in triggers)}")

        explanation = "\n".join(lines)
        return _Response(
            {
                "explanation": explanation,
                "summary": f"{decision} — omega_api={omega_api}",
                "decision": decision,
                "omega_api": omega_api,
                "reflex_triggers": triggers,
            }
        )

    def how_to_unblock(
        self,
        decision: str,
        breaking_changes: list = None,
        detected_patterns: list = None,
    ) -> _Response:
        """Get actionable steps to resolve a BLOCK decision.

        Args:
            decision: The decision string.
            breaking_changes: List of breaking changes.
            detected_patterns: List of detected patterns.

        Returns:
            Response with ``steps``, ``summary``.
        """
        changes = breaking_changes or []
        patterns = detected_patterns or []
        steps = []

        if decision != "BLOCK":
            return _Response(
                {
                    "steps": [],
                    "summary": f"No action needed — decision is {decision}.",
                }
            )

        if "ENDPOINT_REMOVAL" in patterns:
            steps.append(
                "Deprecate removed endpoints with a sunset header "
                "instead of deleting them immediately."
            )
        if "AUTH_FLOW_DRIFT" in patterns:
            steps.append(
                "Ensure authentication flow changes are backward-compatible "
                "or provide a migration path."
            )
        if changes:
            steps.append(
                f"Address {len(changes)} breaking change(s): "
                + "; ".join(str(c) for c in changes[:5])
            )
        if not steps:
            steps.append(
                "Review the omega scoring report and address the "
                "highest-risk changes first."
            )

        return _Response(
            {
                "steps": steps,
                "summary": f"{len(steps)} step(s) to unblock.",
                "decision": decision,
            }
        )

    def score_mcp(self, manifest: dict) -> _Response:
        """Score an MCP manifest for agent safety.

        Args:
            manifest: The MCP manifest dict (must contain ``tools``).

        Returns:
            Response with ``overall_score``, ``band``, ``tool_scores``.
        """
        return self._post("/agent-readiness-score", {"manifest": manifest})

    def get_ledger(
        self,
        repo: str = None,
        decision: str = None,
        limit: int = None,
        from_date: str = None,
        to_date: str = None,
    ) -> _Response:
        """Query compliance ledger entries.

        Args:
            repo: Filter by repository (owner/repo).
            decision: Filter by decision type.
            limit: Max entries to return.
            from_date: Start date filter (ISO 8601).
            to_date: End date filter (ISO 8601).

        Returns:
            Response with ``entries``, ``total``.
        """
        params = {}
        if repo:
            params["repo"] = repo
        if decision:
            params["decision"] = decision
        if limit is not None:
            params["limit"] = limit
        if from_date:
            params["from"] = from_date
        if to_date:
            params["to"] = to_date
        return self._get("/ledger", params)

    def simulate_policy(
        self,
        policy_yaml: str,
        old_spec: str,
        new_spec: str,
    ) -> _Response:
        """Test a YAML policy against two specs.

        Args:
            policy_yaml: The YAML policy content.
            old_spec: The old OpenAPI spec.
            new_spec: The new OpenAPI spec.

        Returns:
            Response with ``effective_action``, ``matched_rules``.
        """
        return self._post(
            "/policy-simulator",
            {
                "policy_yaml": policy_yaml,
                "old_spec": old_spec,
                "new_spec": new_spec,
            },
        )
