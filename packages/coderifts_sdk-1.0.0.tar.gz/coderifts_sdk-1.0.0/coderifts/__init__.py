"""CodeRifts Python SDK — API governance for AI agents."""

from .client import CodeRifts
from .exceptions import ApiError, AuthError, CodeRiftsError, RateLimitError

__version__ = "1.0.0"
__all__ = [
    "CodeRifts",
    "CodeRiftsError",
    "ApiError",
    "AuthError",
    "RateLimitError",
]
