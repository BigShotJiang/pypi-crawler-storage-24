# Method modules are integrated directly in client.py for simplicity.
