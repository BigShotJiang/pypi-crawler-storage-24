# coderifts-sdk

Python SDK for [CodeRifts](https://coderifts.com) — API governance for AI agents.

## Installation

```bash
pip install coderifts-sdk
```

## Quick Start

```python
from coderifts import CodeRifts

client = CodeRifts(api_key="cr_live_...")

# Full OpenAPI spec diff analysis
result = client.diff(before="...", after="...")
print(result.omega_decision, result.risk_score)

# Agent preflight check
result = client.preflight_check(
    tool_name="get_refund_status",
    old_spec="...",
    new_spec="..."
)
print(result.decision, result.safe)

# Compliance ledger
ledger = client.get_ledger(repo="owner/repo", limit=10)
print(ledger.total, ledger.entries)
```

## Methods

| Method | Description |
|--------|-------------|
| `diff(before, after)` | Full OpenAPI spec diff analysis |
| `preflight_check(tool_name, old_spec, new_spec)` | Agent tool invocation safety check |
| `explain_decision(omega_api, decision, reflex_triggers)` | Human-readable explanation |
| `how_to_unblock(decision, breaking_changes, detected_patterns)` | Actionable steps to resolve BLOCK |
| `score_mcp(manifest)` | MCP manifest agent safety score |
| `get_ledger(repo, decision, limit)` | Query compliance ledger |
| `simulate_policy(policy_yaml, old_spec, new_spec)` | Test YAML policy against specs |

## Error Handling

```python
from coderifts import CodeRiftsError

try:
    result = client.diff(before="...", after="...")
except CodeRiftsError as e:
    print(e.code, e.message)
```

## License

MIT
