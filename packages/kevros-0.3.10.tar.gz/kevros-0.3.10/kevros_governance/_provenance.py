"""
Build provenance record — auto-generated, do not edit.

This file is embedded by the CI/CD pipeline at build time.
It provides hash verification and optional cryptographic
signature verification for this package distribution.
"""

PROVENANCE = {
    'schema_version': '1.0',
    'artifact_hash': 'sha512:b0902b0a24d272d6fbf680f0f4d192581bb97621bbcebbc902333026eb217421309a6c863baabb5b5a51230a01979a0100be93a59a841b549db7056e23b7618d',
    'version': '0.3.10',
    'registry': 'pypi',
    'package_name': 'kevros',
    'build_timestamp': '2026-03-23T21:22:09Z',
    'build_host_hash': 'sha256:662b791465090e83f3f5d452c444c6d307bbda0b81137b466308aac435ab32db',
    'git_commit': 'cef095d425edcea4add4a56f2966aa901c580938',
    'git_branch': 'sdk-v0.3.10',
    'signer': 'github-actions-oidc',
    'signature_algorithm': '',
    'signature': '',
    'public_key': '',
    'dependencies_hash': 'sha256:4e26d22a547afd7168e5160cf6cdd405fb74b4d0d1458a3225a6b0e87e2174f4',
}


def get_provenance() -> dict:
    """Return a copy of the build provenance record."""
    return dict(PROVENANCE)
