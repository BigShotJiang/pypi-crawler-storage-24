import pytest
import sys
import os
sys.path.insert(0,os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

from moduletemplate.moduletemplate import hello_world

def test_hello_word():
    assert hello_world() == "Hello world!"