from setuptools import setup, find_packages

setup(
   name='fbnsampa-moduletemplate',
   version='0.3',
   packages=find_packages(),
   install_requires=[],
   author='Fabiano Sampaio',
   author_email='fabiano.sampa@gmail.com',
   description='Meu primeiro upload de pypi.',
   url='https://github.com/fbnsampa',
   classifiers=[
       'Programming Language :: Python :: 3',
       'License :: OSI Approved :: MIT License',
       'Operating System :: OS Independent',
   ],
   python_requires='>=3.6',
)