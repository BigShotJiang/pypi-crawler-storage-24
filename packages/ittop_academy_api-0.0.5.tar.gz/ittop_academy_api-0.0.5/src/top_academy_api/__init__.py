from .client import TopAcademyClient
import logging

logging.getLogger("top_academy_api").addHandler(logging.NullHandler())

__all__ = ["TopAcademyClient"]
