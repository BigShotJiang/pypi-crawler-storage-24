from typing import Any

from ..models.metrics import AttendanceMetrics, AverageGradesMetrics


class MetricsEndpoints:
    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def get_future_exams(self) -> Any:
        """
        GET /dashboard/info/future-exams.
        Возвращает: список предстоящих экзаменов (структура из API).
        """
        return await self._client._request("GET", "/dashboard/info/future-exams")

    async def get_activity(self) -> Any:
        """
        GET /dashboard/progress/activity.
        Возвращает: данные об активности студента (структура из API).
        """
        return await self._client._request("GET", "/dashboard/progress/activity")

    async def get_progress_chart(self) -> Any:
        """
        GET /dashboard/chart/progress.
        Возвращает: список элементов графика прогресса (date, points, previous_points, has_rasp).
        """
        return await self._client._request("GET", "/dashboard/chart/progress")

    async def get_attendance(self) -> AttendanceMetrics:
        """
        GET /dashboard/chart/attendance.
        Возвращает: список {date, points, previous_points, has_rasp} — посещаемость по датам.
        """
        data = await self._client._request("GET", "/dashboard/chart/attendance")
        return AttendanceMetrics.model_validate(data)

    async def get_average_grade(self) -> AverageGradesMetrics:
        """
        GET /dashboard/chart/average-progress.
        Возвращает: список элементов графика среднего прогресса по датам.
        """
        data = await self._client._request("GET", "/dashboard/chart/average-progress")
        return AverageGradesMetrics.model_validate(data)
