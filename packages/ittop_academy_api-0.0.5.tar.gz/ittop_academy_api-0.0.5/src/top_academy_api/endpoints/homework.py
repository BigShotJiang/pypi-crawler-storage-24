import json
from pathlib import Path
from typing import List, Optional

from ..models.homework import (
    HomeworkList,
    HomeworkItem,
    HomeworkCounters,
    HomeworkUploadResponse,
    HomeworkEvaluationResponse,
)


class HomeworkEndpoints:
    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def get_counters(self) -> HomeworkCounters:
        """
        GET /count/homework.
        Возвращает: список {counter_type: int, counter: int} — счётчики ДЗ.
        Пример: [{"counter_type": 1, "counter": 23}, {"counter_type": 0, "counter": 20}, ...]
        """
        data = await self._client._request("GET", "/count/homework")
        return HomeworkCounters.model_validate(data)

    async def get_group_history(self, group_id: Optional[int] = None) -> list:
        """
        GET /homework/settings/group-history.
        Опционально: group_id в query. Возвращает: история групп по домашним заданиям.
        """
        params = {"group_id": group_id} if group_id is not None else None
        data = await self._client._request(
            "GET",
            "/homework/settings/group-history",
            params=params,
        )
        return data if isinstance(data, list) else [data]

    async def get_evaluation_tags(self) -> list:
        """
        GET /homework/evaluation/operations/get-tags.
        Возвращает: список тегов для оценки ДЗ (структура из API).
        """
        data = await self._client._request("GET", "/homework/evaluation/operations/get-tags")
        return data if isinstance(data, list) else [data]

    async def get_info(self, id_: int) -> HomeworkItem:
        """GET /homework/evaluation/operations/get?id=... Возвращает: один элемент ДЗ (HomeworkItem)."""
        data = await self._client._request(
            "GET",
            "/homework/evaluation/operations/get",
            params={"id": id_},
        )
        return HomeworkItem.model_validate(data)

    async def has_material(self, id_: int) -> bool:
        """POST /homework/operations/has-material. Возвращает: есть ли материал по ДЗ (bool)."""
        data = await self._client._request(
            "POST",
            "/homework/operations/has-material",
            json_={"id": id_},
        )
        return bool(data)

    async def list_homeworks(
        self,
        page_start: int = 1,
        status: int = 0,
        type_: int = 0,
        group_id: Optional[int] = None,
    ) -> HomeworkList:
        """
        GET /homework/operations/list?page=&status=&type=&group_id=.
        Возвращает: список ДЗ (HomeworkList). Пагинация по 10, обход до 11 страницы.
        """

        items: List[HomeworkItem] = []

        for page in range(page_start, 11):
            params = {
                "page": page,
                "status": status,
                "type": type_,
                "group_id": group_id,
            }

            data = await self._client._request(
                "GET",
                "/homework/operations/list",
                params=params,
            )

            if not data:
                break

            page_items = [HomeworkItem.model_validate(i) for i in data]
            items.extend(page_items)

            # если вернулось меньше 10 — дальше страниц нет
            if len(data) < 10:
                break

        return HomeworkList(root=items)


    async def create_homework(
        self,
        id_: int,
        file_path: Optional[str] = None,
        answer_text: Optional[str] = None,
        spent_hours: str = "00",
        spent_minutes: str = "00",
    ) -> HomeworkUploadResponse:
        """
        POST /homework/operations/create (multipart: id, answerText, spentTimeHour, spentTimeMin, file).
        Возвращает: HomeworkUploadResponse (id, filename, file_path, mark, creation_time, stud_answer, auto_mark).
        """

        files = {}
        data = {
            "id": str(id_),
            "answerText": answer_text or "",
            "spentTimeHour": spent_hours,
            "spentTimeMin": spent_minutes,
        }

        if file_path:
            file = Path(file_path)
            files["file"] = (file.name, file.open("rb"))

        response = await self._client._client.post(
            "/homework/operations/create",
            data=data,
            files=files if files else None,
        )

        response.raise_for_status()
        return HomeworkUploadResponse.model_validate(response.json())

    async def rate_homework(
        self,
        id_dom_zad: int,
        mark: int,
        comment: str = "",
        tags: Optional[List[str]] = None,
    ) -> HomeworkEvaluationResponse:
        """
        POST /homework/evaluation/operations/save (EvaluationHomeworkForm JSON).
        Возвращает: HomeworkEvaluationResponse (id, id_dom_zad, id_stud, mark, comment, tags).
        """

        payload = {
            "EvaluationHomeworkForm": json.dumps({
                "id": None,
                "idDomZad": id_dom_zad,
                "idStud": None,
                "mark": mark,
                "comment": comment,
                "tags": tags or [],
            })
        }

        response = await self._client._client.post(
            "/homework/evaluation/operations/save",
            data=payload,
        )

        response.raise_for_status()
        return HomeworkEvaluationResponse.model_validate(response.json())
