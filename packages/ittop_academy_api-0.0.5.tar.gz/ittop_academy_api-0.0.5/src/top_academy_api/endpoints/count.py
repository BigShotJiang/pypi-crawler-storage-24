"""
Эндпоинты счётчиков (коллекция Postman ITTOPAcademy API).
"""

from typing import Any, List

from ..models.homework import HomeworkCounters


class CountEndpoints:
    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def get_page_counters(self, filter_type: int = 0) -> List[Any]:
        """
        GET /count/page-counters?filter_type={filter_type}.
        Возвращает: список {counter_type: int, counter: int} — счётчики для страниц.
        Пример из Postman: [{"counter_type": 1, "counter": 23}, {"counter_type": 3, "counter": 1}, ...]
        """
        data = await self._client._request(
            "GET", "/count/page-counters", params={"filter_type": filter_type}
        )
        return data if isinstance(data, list) else [data]

    async def get_library_count(self) -> Any:
        """
        GET /count/library.
        Возвращает: счётчик библиотеки (формат ответа из API).
        """
        return await self._client._request("GET", "/count/library")

    async def get_homework_count(self) -> HomeworkCounters:
        """
        GET /count/homework.
        Возвращает: список {counter_type: int, counter: int} — счётчики домашних заданий.
        Пример из Postman: [{"counter_type": 1, "counter": 23}, {"counter_type": 0, "counter": 20}, ...]
        """
        data = await self._client._request("GET", "/count/homework")
        return HomeworkCounters.model_validate(data)
