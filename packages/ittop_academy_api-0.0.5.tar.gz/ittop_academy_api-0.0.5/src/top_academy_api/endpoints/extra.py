"""
Дополнительные эндпоинты из коллекции Postman ITTOPAcademy API:
Library, Payment, Profile, Progress, Portfolio, Settings, Contacts, Reviews, Feedback, News, Signal, Story, Public, Files.
Ответы возвращаются как dict/list (Any); структуры описаны в docstring и в docs/API_ENDPOINTS.md.
"""

from typing import Any, Optional


class LibraryEndpoints:
    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def get_opened_interview(self) -> Any:
        """GET /library/quiz/opened-interview. Возвращает: открытое интервью/квиз."""
        return await self._client._request("GET", "/library/quiz/opened-interview")

    async def list_(
        self,
        material_type: int = 7,
        recommended_type: int = 0,
    ) -> Any:
        """GET /library/operations/list. Параметры: material_type, recommended_type. Возвращает: список материалов библиотеки."""
        return await self._client._request(
            "GET",
            "/library/operations/list",
            params={"material_type": material_type, "recommended_type": recommended_type},
        )


class PaymentEndpoints:
    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def check_epay_link(self) -> Any:
        """HEAD /payment/epay/link. Проверка ссылки ePay. Возвращает dict с ok/status (HEAD без body)."""
        try:
            r = await self._client._client.request("HEAD", "/payment/epay/link")
            r.raise_for_status()
            return {"ok": True, "status": r.status_code}
        except Exception:
            return {"ok": False}

    async def get_schedule(self) -> Any:
        """GET /payment/operations/schedule. Возвращает: график платежей."""
        return await self._client._request("GET", "/payment/operations/schedule")

    async def get_index(self) -> Any:
        """GET /payment/operations/index. Возвращает: индекс/список платежей."""
        return await self._client._request("GET", "/payment/operations/index")

    async def get_history(self) -> Any:
        """GET /payment/operations/history. Возвращает: история платежей."""
        return await self._client._request("GET", "/payment/operations/history")

    async def check_cancellation(self) -> Any:
        """GET /payment/operations/check-cancellation. Проверка отмены."""
        return await self._client._request("GET", "/payment/operations/check-cancellation")


class ProfileEndpoints:
    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def get_student_achievements(self) -> Any:
        """
        GET /profile/statistic/student-achievements.
        Возвращает: список достижений (id, translate_key, is_active, achieve_points с points_count).
        """
        return await self._client._request("GET", "/profile/statistic/student-achievements")

    async def get_settings(self) -> Any:
        """GET /profile/operations/settings. Возвращает: настройки профиля."""
        return await self._client._request("GET", "/profile/operations/settings")


class ProgressEndpoints:
    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def get_student_visits(self) -> Any:
        """GET /progress/operations/student-visits. Возвращает: посещения студента."""
        return await self._client._request("GET", "/progress/operations/student-visits")

    async def get_student_exams(self) -> Any:
        """GET /progress/operations/student-exams. Возвращает: экзамены студента."""
        return await self._client._request("GET", "/progress/operations/student-exams")


class PortfolioEndpoints:
    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def list_(self) -> Any:
        """GET /portfolio/operations/list. Возвращает: список портфолио."""
        return await self._client._request("GET", "/portfolio/operations/list")

    async def get_design_teachers(self) -> Any:
        """GET /portfolio/operations/design-teachers. Возвращает: преподаватели по дизайну."""
        return await self._client._request("GET", "/portfolio/operations/design-teachers")

    async def get_design_specs(self, id_spec: Optional[int] = None) -> Any:
        """GET /portfolio/operations/design-specs. Опционально: id (query id=). Возвращает: спецификации дизайна."""
        params = {"id": id_spec} if id_spec is not None else None
        return await self._client._request("GET", "/portfolio/operations/design-specs", params=params)


class SettingsEndpoints:
    """Доп. настройки (user.get_info = GET /settings/user-info уже есть в UserEndpoints)."""

    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def get_history_specs(self) -> Any:
        """GET /settings/history-specs. Возвращает: история спецификаций."""
        return await self._client._request("GET", "/settings/history-specs")

    async def get_group_specs(self) -> Any:
        """GET /settings/group-specs. Возвращает: спецификации групп."""
        return await self._client._request("GET", "/settings/group-specs")


class ContactsEndpoints:
    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def check_mailing_confirmation(self) -> Any:
        """GET /contacts/mailing/check-confirmation. Проверка подтверждения рассылки."""
        return await self._client._request("GET", "/contacts/mailing/check-confirmation")

    async def get_contacts(self) -> Any:
        """GET /contacts/operations/index. Возвращает: контакты."""
        return await self._client._request("GET", "/contacts/operations/index")


class ReviewsEndpoints:
    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def list_(self) -> Any:
        """GET /reviews/index/list. Возвращает: список отзывов."""
        return await self._client._request("GET", "/reviews/index/list")

    async def get_instruction(self) -> Any:
        """GET /reviews/index/instruction. Инструкция по отзывам."""
        return await self._client._request("GET", "/reviews/index/instruction")


class FeedbackEndpoints:
    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def get_evaluate_lesson_list(self) -> Any:
        """GET /feedback/students/evaluate-lesson-list. Список уроков для оценки."""
        return await self._client._request("GET", "/feedback/students/evaluate-lesson-list")

    async def get_social_reviews(self) -> Any:
        """GET /feedback/social-review/get-review-list. Социальные отзывы."""
        return await self._client._request("GET", "/feedback/social-review/get-review-list")


class NewsEndpoints:
    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def get_latest(self) -> Any:
        """GET /news/operations/latest-news. Последние новости."""
        return await self._client._request("GET", "/news/operations/latest-news")


class SignalEndpoints:
    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def list_(self) -> Any:
        """GET /signal/operations/signals-list. Список сигналов."""
        return await self._client._request("GET", "/signal/operations/signals-list")


class StoryEndpoints:
    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def get_stories(self) -> Any:
        """GET /story/operations/get-stories. Истории."""
        return await self._client._request("GET", "/story/operations/get-stories")


class PublicEndpoints:
    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def get_languages(self) -> Any:
        """GET /public/languages. Список языков."""
        return await self._client._request("GET", "/public/languages")


class FilesEndpoints:
    """
    Файлы. В коллекции Postman: Download Homework File ведёт на storage.yandexcloud.net,
    Get File — на fs.top-academy.ru. Ниже — вызовы к msapi; при необходимости URL для
    скачивания берётся из ответа API (например, file_path в homework).
    """

    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def get_file_url(self, file_id: str) -> Any:
        """GET к API файлов (если есть эндпоинт /files/... на msapi). Возвращает URL или метаданные файла."""
        return await self._client._request("GET", "/files/operations/get", params={"id": file_id})
