from ..models.dashboard import LeaderPointsResponse
from ..models.rating import GroupRating, StreamRating


class RatingEndpoints:
    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def get_leader_stream_points(self) -> LeaderPointsResponse:
        """
        GET /dashboard/progress/leader-stream-points.
        Возвращает: totalCount, studentPosition, weekDiff, monthDiff (позиция в рейтинге потока).
        """
        data = await self._client._request("GET", "/dashboard/progress/leader-stream-points")
        return LeaderPointsResponse.model_validate(data)

    async def get_leader_stream(self) -> StreamRating:
        """
        GET /dashboard/progress/leader-stream.
        Возвращает: список {id, full_name, photo_path, position, amount} — рейтинг потока.
        """
        data = await self._client._request("GET", "/dashboard/progress/leader-stream")
        return StreamRating.model_validate(data)

    async def get_leader_group_points(self) -> LeaderPointsResponse:
        """
        GET /dashboard/progress/leader-group-points.
        Возвращает: totalCount, studentPosition, weekDiff, monthDiff (позиция в рейтинге группы).
        """
        data = await self._client._request("GET", "/dashboard/progress/leader-group-points")
        return LeaderPointsResponse.model_validate(data)

    async def get_group_leaders(self) -> GroupRating:
        """
        GET /dashboard/progress/leader-group.
        Возвращает: список {id, full_name, photo_path, position, amount} — рейтинг группы.
        """
        data = await self._client._request("GET", "/dashboard/progress/leader-group")
        return GroupRating.model_validate(data)
