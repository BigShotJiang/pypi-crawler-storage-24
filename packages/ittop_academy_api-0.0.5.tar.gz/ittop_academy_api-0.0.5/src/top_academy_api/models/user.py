from pydantic import BaseModel, Field
from typing import List

class GamingPoint(BaseModel):
    type_id: int = Field(alias="new_gaming_point_types__id")
    points: int

class Groups(BaseModel):
    name: str           = Field(alias="name")
    id: int             = Field(alias="id")
    status: int         = Field(alias="group_status")
    is_primary: bool    = Field(alias="is_primary")

class UserInfo(BaseModel):
    groups: List[Groups]
    current_group_id: int
    photo: str
    full_name: str
    age: int
    group_name: str
    stream_name: str
    birthday: str
    gaming_points: List[GamingPoint]

