from typing import List, Iterator

from pydantic import BaseModel, RootModel


class ScheduleItem(BaseModel):
    date: str
    lesson: int
    started_at: str
    finished_at: str
    teacher_name: str
    subject_name: str
    room_name: str


class ScheduleMonth(RootModel[List[ScheduleItem]]):
    root: List[ScheduleItem]

    def __iter__(self) -> Iterator[ScheduleItem]:
        return iter(self.root)

    def __getitem__(self, index) -> ScheduleItem:
        return self.root[index]

    def __len__(self) -> int:
        return len(self.root)

    def __str__(self) -> str:
        return str(self.root)


class ScheduleDay(RootModel[List[ScheduleItem]]):
    root: List[ScheduleItem]

    def __iter__(self) -> Iterator[ScheduleItem]:
        return iter(self.root)

    def __getitem__(self, index) -> ScheduleItem:
        return self.root[index]

    def __len__(self) -> int:
        return len(self.root)

    def __str__(self) -> str:
        return str(self.root)