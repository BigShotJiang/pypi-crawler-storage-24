"""Модели ответов эндпоинтов Dashboard (из коллекции Postman ITTOPAcademy API)."""

from typing import Optional

from pydantic import BaseModel


class LeaderPointsResponse(BaseModel):
    """
    Ответ: GET /dashboard/progress/leader-stream-points, leader-group-points.
    Позиция студента в рейтинге потока/группы.
    Пример из Postman: {"totalCount": null, "studentPosition": 16, "weekDiff": 0, "monthDiff": 0}
    """

    totalCount: Optional[int] = None
    studentPosition: int
    weekDiff: int
    monthDiff: int


# Для chart/progress, activity, future-exams при необходимости можно добавить
# типизированные модели; структура ответов описана в docstring эндпоинтов.
