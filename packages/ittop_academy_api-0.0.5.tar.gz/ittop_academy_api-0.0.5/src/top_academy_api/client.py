import httpx
import json
import logging

from . import config
from .auth import AuthManager
from .endpoints.auth import AuthEndpoints
from .endpoints.count import CountEndpoints
from .endpoints.extra import (
    ContactsEndpoints,
    FeedbackEndpoints,
    FilesEndpoints,
    LibraryEndpoints,
    NewsEndpoints,
    PaymentEndpoints,
    PortfolioEndpoints,
    ProfileEndpoints,
    ProgressEndpoints,
    PublicEndpoints,
    ReviewsEndpoints,
    SettingsEndpoints,
    SignalEndpoints,
    StoryEndpoints,
)
from .endpoints.homework import HomeworkEndpoints
from .endpoints.metrics import MetricsEndpoints
from .endpoints.rating import RatingEndpoints
from .endpoints.schedule import ScheduleEndpoints
from .endpoints.user import UserEndpoints
from .exceptions import TopAcademyError
from .utils import sanitize_data

logger = logging.getLogger("top_academy_api")

class TopAcademyClient:
    def __init__(self,
                 base_url=config.BASE_URL,
                 timeout=config.TIMEOUT,
                 logger: logging.Logger | None = None):

        self.base_url = base_url
        self.timeout = timeout
        self.logger = logger
        self._client: httpx.AsyncClient | None = None

        # endpoints
        self.auth: AuthEndpoints
        self.user: UserEndpoints | None = None
        self.schedule: ScheduleEndpoints | None = None
        self.metrics: MetricsEndpoints | None = None
        self.rating: RatingEndpoints | None = None
        self.homework: HomeworkEndpoints | None = None
        self.count: CountEndpoints | None = None
        self.library: LibraryEndpoints | None = None
        self.payment: PaymentEndpoints | None = None
        self.profile: ProfileEndpoints | None = None
        self.progress: ProgressEndpoints | None = None
        self.portfolio: PortfolioEndpoints | None = None
        self.settings_extra: SettingsEndpoints | None = None
        self.contacts: ContactsEndpoints | None = None
        self.reviews: ReviewsEndpoints | None = None
        self.feedback: FeedbackEndpoints | None = None
        self.news: NewsEndpoints | None = None
        self.signal: SignalEndpoints | None = None
        self.story: StoryEndpoints | None = None
        self.public: PublicEndpoints | None = None
        self.files: FilesEndpoints | None = None

    async def __aenter__(self):
        self._client = httpx.AsyncClient(base_url=self.base_url,
                                         timeout=self.timeout,
                                         headers={
                                            "accept": "application/json, text/plain, */*",
                                            "content-type": "application/json",
                                            "origin": "https://journal.top-academy.ru",
                                            "referer": "https://journal.top-academy.ru/",
                                            "authorization": "Bearer null",
                                            "x-cache-client": "600",
                                            "user-agent": "Mozilla/5.0",
                                         })
        self.auth = AuthManager(self)

        # инициализация endpoints
        self.authmanager = AuthEndpoints(self)
        self.user = UserEndpoints(self)
        self.schedule = ScheduleEndpoints(self)
        self.metrics = MetricsEndpoints(self)
        self.rating = RatingEndpoints(self)
        self.homework = HomeworkEndpoints(self)
        self.count = CountEndpoints(self)
        self.library = LibraryEndpoints(self)
        self.payment = PaymentEndpoints(self)
        self.profile = ProfileEndpoints(self)
        self.progress = ProgressEndpoints(self)
        self.portfolio = PortfolioEndpoints(self)
        self.settings_extra = SettingsEndpoints(self)
        self.contacts = ContactsEndpoints(self)
        self.reviews = ReviewsEndpoints(self)
        self.feedback = FeedbackEndpoints(self)
        self.news = NewsEndpoints(self)
        self.signal = SignalEndpoints(self)
        self.story = StoryEndpoints(self)
        self.public = PublicEndpoints(self)
        self.files = FilesEndpoints(self)
        return self

    async def __aexit__(self, exc_type, exc, tb):
        await self._client.aclose()

    async def _request(self, method: str, endpoint: str, *, params=None, json_=None) -> dict:
        if not self._client:
            raise TopAcademyError("Client not initialized. Use 'async with TopAcademyClient()'")

        if self.logger:
            self.logger.debug("REQUEST %s %s", method, endpoint)
            if params:
                self.logger.debug("Params: %s", params)
            if json_:
                safe_json = sanitize_data(json_)
                self.logger.debug("JSON: %s", safe_json)


        try:
            response = await self._client.request(method, endpoint, params=params, json=json_)
            response.raise_for_status()
        except httpx.HTTPStatusError:
            raise TopAcademyError("You Unauthorized!")

        if self.logger:
            self.logger.debug("Status: %s", response.status_code)

        data = response.json()

        if self.logger:
            safe_response = sanitize_data(data)
            self.logger.debug(
                "Response JSON:\n%s",
                json.dumps(safe_response, indent=2, ensure_ascii=False)
            )

        return data

