from typing import TYPE_CHECKING

from .exceptions import TopAcademyAuthError
from .config import APP_KEY
from .models.auth import AuthLogin

if TYPE_CHECKING:
    from .client import TopAcademyClient

class AuthManager:
    """Менеджер авторизации"""
    def __init__(self, client: "TopAcademyClient"):
        self._client = client

        self.model: AuthLogin | None = None
        self.token: str | None = None

    async def login(self, username: str, password: str):

        self.model = await self._client.authmanager.login(APP_KEY, username, password)

        self.token = self.model.access_token

    async def logout(self):
        if not self.token:
            return

        await self._client.authmanager.logout()

        self.token = None
