# src/top_academy_api/exceptions.py

class TopAcademyError(Exception):
    """Базовая ошибка SDK"""
    pass

class TopAcademyAuthError(TopAcademyError):
    """Ошибка авторизации"""
    pass

class TopAcademyRateLimit(TopAcademyError):
    """Превышен лимит запросов"""
    pass

class TopAcademyRequestError(TopAcademyError):
    """Ошибка запроса"""
    def __init__(self, status_code: int, message: str):
        super().__init__(f"{status_code}: {message}")
        self.status_code = status_code
