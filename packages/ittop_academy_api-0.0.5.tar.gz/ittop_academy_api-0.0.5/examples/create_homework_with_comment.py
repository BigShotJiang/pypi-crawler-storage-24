import asyncio
import logging

from top_academy_api import TopAcademyClient

logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s | %(levelname)s | %(message)s",
)

logger = logging.getLogger("top_academy_api_debug")


async def main():
    async with TopAcademyClient(logger=logger) as api:
        # Авторизация
        await api.auth.login(
            username="YOUR_LOGIN",
            password="YOUR_PASSWORD",
        )

        # ID домашнего задания
        homework_id = 12345

        # Создание домашки только с текстовым ответом
        response = await api.homework.create_homework(
            id_=homework_id,
            answer_text="""
Домашняя работа выполнена.

Что сделано:
- реализована логика
- добавлены проверки
- протестировано вручную
""",
            spent_hours="02",
            spent_minutes="00",
        )

        print("Homework submitted successfully")
        print(response)


if __name__ == "__main__":
    asyncio.run(main())
