import asyncio
import logging

from top_academy_api import TopAcademyClient

logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s | %(levelname)s | %(message)s",
)

logger = logging.getLogger("top_academy_api_debug")


async def main():
    async with TopAcademyClient(logger=logger) as api:
        # Авторизация (нужны права преподавателя)
        await api.auth.login(
            username="YOUR_LOGIN",
            password="YOUR_PASSWORD",
        )

        # ID домашнего задания
        homework_id = 12345

        # Оценка заданию
        mark = 5

        comment="Работа понравилась. Всё очень просто :D"

        # Выставляем оценку
        response = await api.homework.rate_homework(
            id_dom_zad=homework_id,
            mark=mark,
            comment=comment,
            tags=[], # TODO: Теги
        )

        print("Homework rated successfully")
        print("Response:", response)


if __name__ == "__main__":
    asyncio.run(main())
