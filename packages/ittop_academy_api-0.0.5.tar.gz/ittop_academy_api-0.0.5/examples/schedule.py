import asyncio
import logging
from datetime import datetime

from top_academy_api import TopAcademyClient

logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s | %(levelname)s | %(message)s",
)

logger = logging.getLogger("top_academy_api_debug")


async def main():
    async with TopAcademyClient(logger=logger) as api:
        # Авторизация
        await api.auth.login(
            username="YOUR_LOGIN",
            password="YOUR_PASSWORD",
        )

        date: datetime = datetime.today()

        # Расписание на день
        schedule_d = await api.schedule.get_schedule_day(date=date)
        print(schedule_d)

        # Расписание на месяц
        schedule_m = await api.schedule.get_schedule_month(date=date)
        print(schedule_m)


if __name__ == "__main__":
    asyncio.run(main())
