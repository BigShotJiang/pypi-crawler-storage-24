import asyncio

from src.top_academy_api.client import TopAcademyClient
from tests.models.settings import Settings

settings = Settings()

async def main():
    async with TopAcademyClient() as api:
        # Авторизация
        await api.auth.login(username=settings.login, password=settings.password)

        print(await api.user.get_info())



asyncio.run(main())
