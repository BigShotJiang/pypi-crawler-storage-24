# Эндпоинты ITTOPAcademy API

Данные взяты из коллекции Postman **ITTOPAcademy API**. Базовый URL: `https://msapi.top-academy.ru/api/v2`.

## Auth

| Метод | Путь | Описание | Ответ (пример из Postman) |
|-------|------|----------|---------------------------|
| POST | `/auth/login` | Вход | `access_token`, `refresh_token`, `expires_in_refresh`, `expires_in_access`, `user_type`, `city_data` (id_city, prefix, translate_key, timezone_name, country_code, market_status, name), `user_role` |

## Dashboard / Рейтинг (rating, metrics)

| Метод | Путь | Описание | Ответ |
|-------|------|----------|--------|
| GET | `/dashboard/progress/leader-stream-points` | Позиция в рейтинге потока | `totalCount`, `studentPosition`, `weekDiff`, `monthDiff` |
| GET | `/dashboard/progress/leader-stream` | Рейтинг потока | Список: `id`, `full_name`, `photo_path`, `position`, `amount` |
| GET | `/dashboard/progress/leader-group-points` | Позиция в рейтинге группы | `totalCount`, `studentPosition`, `weekDiff`, `monthDiff` |
| GET | `/dashboard/progress/leader-group` | Рейтинг группы | Список: `id`, `full_name`, `photo_path`, `position`, `amount` |
| GET | `/dashboard/progress/activity` | Активность | Список: `date`, `action`, `current_point`, `point_types_id`, `achievements_id`, ... |
| GET | `/dashboard/info/future-exams` | Предстоящие экзамены | Список (структура из API) |
| GET | `/dashboard/chart/progress` | График прогресса | Список: `date`, `points`, `previous_points`, `has_rasp` |
| GET | `/dashboard/chart/attendance` | График посещаемости | Список: `date`, `points`, `previous_points`, `has_rasp` |
| GET | `/dashboard/chart/average-progress` | Средний прогресс | Список элементов по датам |

## Homework

| Метод | Путь | Описание | Ответ |
|-------|------|----------|--------|
| GET | `/count/homework` | Счётчики ДЗ | Список: `counter_type`, `counter` |
| GET | `/homework/settings/group-history` | История групп ДЗ | Список (опционально `group_id`) |
| POST | `/homework/operations/has-material` | Есть ли материал | bool |
| GET | `/homework/operations/list` | Список ДЗ | Список HomeworkItem (id, id_spec, theme, file_path, status, ...) |
| GET | `/homework/evaluation/operations/get-tags` | Теги для оценки | Список тегов |
| GET | `/homework/evaluation/operations/get?id=` | Одно ДЗ | HomeworkItem |
| POST | `/homework/operations/create` | Создать ДЗ (multipart) | HomeworkUploadResponse |
| POST | `/homework/evaluation/operations/save` | Сохранить оценку | HomeworkEvaluationResponse |

## Count

| Метод | Путь | Описание | Ответ |
|-------|------|----------|--------|
| GET | `/count/page-counters?filter_type=` | Счётчики страниц | Список: `counter_type`, `counter` |
| GET | `/count/library` | Счётчик библиотеки | По формату API |
| GET | `/count/homework` | Счётчики ДЗ | Список: `counter_type`, `counter` |

## Library

| Метод | Путь | Описание |
|-------|------|----------|
| GET | `/library/quiz/opened-interview` | Открытое интервью/квиз |
| GET | `/library/operations/list?material_type=&recommended_type=` | Список материалов |

## Payment

| Метод | Путь | Описание |
|-------|------|----------|
| HEAD | `/payment/epay/link` | Проверка ссылки ePay |
| GET | `/payment/operations/schedule` | График платежей |
| GET | `/payment/operations/index` | Индекс платежей |
| GET | `/payment/operations/history` | История платежей |
| GET | `/payment/operations/check-cancellation` | Проверка отмены |

## Profile

| Метод | Путь | Описание | Ответ (пример) |
|-------|------|----------|----------------|
| GET | `/profile/statistic/student-achievements` | Достижения студента | Список: `id`, `translate_key`, `is_active`, `achieve_points` (id, points_count) |
| GET | `/profile/operations/settings` | Настройки профиля | id, ful_name, address, date_birth, email, photo_path, phones, links, ... |

## Progress

| Метод | Путь | Описание |
|-------|------|----------|
| GET | `/progress/operations/student-visits` | Посещения студента |
| GET | `/progress/operations/student-exams` | Экзамены студента |

## Portfolio

| Метод | Путь | Описание |
|-------|------|----------|
| GET | `/portfolio/operations/list` | Список портфолио |
| GET | `/portfolio/operations/design-teachers` | Преподаватели по дизайну |
| GET | `/portfolio/operations/design-specs?id=` | Спецификации дизайна |

## Settings

| Метод | Путь | Описание | Ответ (пример) |
|-------|------|----------|----------------|
| GET | `/settings/user-info` | Инфо пользователя | groups, current_group_id, photo, full_name, gaming_points, stream_name, ... |
| GET | `/settings/history-specs` | История спецификаций | Список |
| GET | `/settings/group-specs` | Спецификации групп | Список |

## Schedule

| Метод | Путь | Описание |
|-------|------|----------|
| GET | `/schedule/operations/get-month?date_filter=` | Расписание на месяц |
| GET | `/schedule/operations/get-by-date?date_filter=` | Расписание на день |

## Contacts, Reviews, Feedback, News, Signal, Story, Public

| Метод | Путь | Описание |
|-------|------|----------|
| GET | `/contacts/mailing/check-confirmation` | Подтверждение рассылки |
| GET | `/contacts/operations/index` | Контакты |
| GET | `/reviews/index/list` | Список отзывов |
| GET | `/reviews/index/instruction` | Инструкция по отзывам |
| GET | `/feedback/students/evaluate-lesson-list` | Уроки для оценки |
| GET | `/feedback/social-review/get-review-list` | Социальные отзывы |
| GET | `/news/operations/latest-news` | Последние новости |
| GET | `/signal/operations/signals-list` | Список сигналов |
| GET | `/story/operations/get-stories` | Истории |
| GET | `/public/languages` | Языки |

## Files

В коллекции Postman: скачивание файла ДЗ ведёт на `storage.yandexcloud.net`, Get File — на `fs.top-academy.ru`. В клиенте: `client.files.get_file_url(file_id)` для вызова API файлов при наличии эндпоинта на msapi.
