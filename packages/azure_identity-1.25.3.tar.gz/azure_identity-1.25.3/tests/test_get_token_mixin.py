# ------------------------------------
# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
# ------------------------------------
import time
from unittest import mock

from azure.core.credentials import AccessTokenInfo
import pytest

from azure.identity._constants import DEFAULT_REFRESH_OFFSET
from azure.identity._internal.get_token_mixin import GetTokenMixin

from helpers import GET_TOKEN_METHODS


class MockCredential(GetTokenMixin):
    NEW_TOKEN = AccessTokenInfo("new token", 42)

    def __init__(self, cached_token=None):
        super(MockCredential, self).__init__()
        self.request_token = mock.Mock(return_value=MockCredential.NEW_TOKEN)
        self.acquire_token_silently = mock.Mock(return_value=cached_token)

    def _acquire_token_silently(self, *scopes, **kwargs):
        return self.acquire_token_silently(*scopes, **kwargs)

    def _request_token(self, *scopes, **kwargs):
        return self.request_token(*scopes, **kwargs)

    def get_token(self, *_, **__):
        return super(MockCredential, self).get_token(*_, **__)

    def get_token_info(self, *_, **__):
        return super(MockCredential, self).get_token_info(*_, **__)


CACHED_TOKEN = "cached token"
SCOPE = "scope"


@pytest.mark.parametrize("get_token_method", GET_TOKEN_METHODS)
def test_no_cached_token(get_token_method):
    """When it has no token cached, a credential should request one every time get_token is called"""

    credential = MockCredential()
    token = getattr(credential, get_token_method)(SCOPE)

    credential.acquire_token_silently.assert_called_once_with(SCOPE, claims=None, enable_cae=False, tenant_id=None)
    credential.request_token.assert_called_once_with(SCOPE, claims=None, enable_cae=False, tenant_id=None)
    assert token.token == MockCredential.NEW_TOKEN.token


@pytest.mark.parametrize("get_token_method", GET_TOKEN_METHODS)
def test_tenant_id(get_token_method):
    credential = MockCredential()
    kwargs = {"tenant_id": "tenant_id"}
    if get_token_method == "get_token_info":
        kwargs = {"options": kwargs}
    token = getattr(credential, get_token_method)(SCOPE, **kwargs)

    assert token.token == MockCredential.NEW_TOKEN.token


@pytest.mark.parametrize("get_token_method", GET_TOKEN_METHODS)
def test_token_acquisition_failure(get_token_method):
    """When the credential has no token cached, every get_token call should prompt a token request"""

    credential = MockCredential()
    credential.request_token = mock.Mock(side_effect=Exception("whoops"))
    for i in range(4):
        with pytest.raises(Exception):
            getattr(credential, get_token_method)(SCOPE)
        assert credential.request_token.call_count == i + 1
        credential.request_token.assert_called_with(SCOPE, claims=None, enable_cae=False, tenant_id=None)


@pytest.mark.parametrize("get_token_method", GET_TOKEN_METHODS)
def test_expired_token(get_token_method):
    """A credential should request a token when it has an expired token cached"""

    now = int(time.time())
    credential = MockCredential(cached_token=AccessTokenInfo(CACHED_TOKEN, now - 1))
    token = getattr(credential, get_token_method)(SCOPE)

    credential.acquire_token_silently.assert_called_once_with(SCOPE, claims=None, enable_cae=False, tenant_id=None)
    credential.request_token.assert_called_once_with(SCOPE, claims=None, enable_cae=False, tenant_id=None)
    assert token.token == MockCredential.NEW_TOKEN.token


@pytest.mark.parametrize("get_token_method", GET_TOKEN_METHODS)
def test_cached_token_outside_refresh_window(get_token_method):
    """A credential shouldn't request a new token when it has a cached one with sufficient validity remaining"""

    credential = MockCredential(
        cached_token=AccessTokenInfo(CACHED_TOKEN, int(time.time() + DEFAULT_REFRESH_OFFSET + 10))
    )
    token = getattr(credential, get_token_method)(SCOPE)

    credential.acquire_token_silently.assert_called_once_with(SCOPE, claims=None, enable_cae=False, tenant_id=None)
    assert credential.request_token.call_count == 0
    assert token.token == CACHED_TOKEN


@pytest.mark.parametrize("get_token_method", GET_TOKEN_METHODS)
def test_cached_token_within_refresh_window(get_token_method):
    """A credential should request a new token when its cached one is within the refresh window"""

    credential = MockCredential(
        cached_token=AccessTokenInfo(CACHED_TOKEN, int(time.time() + DEFAULT_REFRESH_OFFSET - 1))
    )
    token = getattr(credential, get_token_method)(SCOPE)

    credential.acquire_token_silently.assert_called_once_with(SCOPE, claims=None, enable_cae=False, tenant_id=None)
    credential.request_token.assert_called_once_with(SCOPE, claims=None, enable_cae=False, tenant_id=None)
    assert token.token == MockCredential.NEW_TOKEN.token


@pytest.mark.parametrize("get_token_method", GET_TOKEN_METHODS)
def test_retry_delay(get_token_method):
    """A credential should wait between requests when trying to refresh a token"""

    now = time.time()
    credential = MockCredential(cached_token=AccessTokenInfo(CACHED_TOKEN, int(now + DEFAULT_REFRESH_OFFSET - 1)))

    # the credential should swallow exceptions during proactive refresh attempts
    credential.request_token = mock.Mock(side_effect=Exception("whoops"))
    for i in range(4):
        token = getattr(credential, get_token_method)(SCOPE)
        assert token.token == CACHED_TOKEN
        credential.acquire_token_silently.assert_called_with(SCOPE, claims=None, enable_cae=False, tenant_id=None)
        credential.request_token.assert_called_once_with(SCOPE, claims=None, enable_cae=False, tenant_id=None)


@pytest.mark.parametrize("get_token_method", GET_TOKEN_METHODS)
def test_refresh_on_in_past(get_token_method):
    """A credential should refresh when the token's refresh_on is in the past"""

    now = int(time.time())
    # Token is still valid but refresh_on is in the past
    cached = AccessTokenInfo(CACHED_TOKEN, now + 3600, refresh_on=now - 1)
    credential = MockCredential(cached_token=cached)
    token = getattr(credential, get_token_method)(SCOPE)

    credential.acquire_token_silently.assert_called_once()
    credential.request_token.assert_called_once_with(SCOPE, claims=None, enable_cae=False, tenant_id=None)
    assert token.token == MockCredential.NEW_TOKEN.token


@pytest.mark.parametrize("get_token_method", GET_TOKEN_METHODS)
def test_refresh_on_in_future(get_token_method):
    """A credential should not refresh when the token's refresh_on is in the future"""

    now = int(time.time())
    cached = AccessTokenInfo(CACHED_TOKEN, now + 3600, refresh_on=now + 600)
    credential = MockCredential(cached_token=cached)
    token = getattr(credential, get_token_method)(SCOPE)

    credential.acquire_token_silently.assert_called_once()
    assert credential.request_token.call_count == 0
    assert token.token == CACHED_TOKEN


@pytest.mark.parametrize("get_token_method", GET_TOKEN_METHODS)
def test_expired_token_ignores_retry_delay(get_token_method):
    """An expired token should always prompt a refresh, even within the retry delay window"""

    now = int(time.time())
    expired = AccessTokenInfo(CACHED_TOKEN, now - 1)
    credential = MockCredential(cached_token=expired)
    # Simulate a recent request to set the retry delay
    credential._last_request_time = now
    token = getattr(credential, get_token_method)(SCOPE)

    credential.request_token.assert_called_once_with(SCOPE, claims=None, enable_cae=False, tenant_id=None)
    assert token.token == MockCredential.NEW_TOKEN.token


@pytest.mark.parametrize("get_token_method", GET_TOKEN_METHODS)
def test_refresh_on_respects_retry_delay(get_token_method):
    """A token past refresh_on should not be refreshed if a request was just made (retry delay)"""

    now = int(time.time())
    cached = AccessTokenInfo(CACHED_TOKEN, now + 3600, refresh_on=now - 1)
    credential = MockCredential(cached_token=cached)
    # Simulate a recent request
    credential._last_request_time = now
    token = getattr(credential, get_token_method)(SCOPE)

    credential.acquire_token_silently.assert_called_once()
    assert credential.request_token.call_count == 0
    assert token.token == CACHED_TOKEN


@pytest.mark.parametrize("get_token_method", GET_TOKEN_METHODS)
def test_expired_token_propagates_error(get_token_method):
    """When a cached token is expired (required), request failures should propagate, not be swallowed."""

    now = int(time.time())
    expired = AccessTokenInfo(CACHED_TOKEN, now - 1)
    credential = MockCredential(cached_token=expired)
    credential.request_token = mock.Mock(side_effect=Exception("auth failed"))

    with pytest.raises(Exception, match="auth failed"):
        getattr(credential, get_token_method)(SCOPE)


@pytest.mark.parametrize("get_token_method", GET_TOKEN_METHODS)
def test_recommended_refresh_swallows_error(get_token_method):
    """When a cached token is within the refresh window (recommended), request failures should be swallowed."""

    credential = MockCredential(
        cached_token=AccessTokenInfo(CACHED_TOKEN, int(time.time() + DEFAULT_REFRESH_OFFSET - 1))
    )
    credential.request_token = mock.Mock(side_effect=Exception("transient error"))
    token = getattr(credential, get_token_method)(SCOPE)

    # The credential should swallow the error and return the cached token.
    assert token.token == CACHED_TOKEN
    credential.request_token.assert_called_once()
