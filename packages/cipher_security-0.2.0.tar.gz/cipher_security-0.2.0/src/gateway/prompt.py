# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""System prompt assembly for CIPHER gateway.

Provides:
- load_base_prompt: reads CLAUDE.md and strips the Trigger Keywords section
- assemble_system_prompt: composes full system prompt with mode-specific skill injection
"""

import logging
import re
from pathlib import Path

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Repo root resolution
# ---------------------------------------------------------------------------

def _find_repo_root(start: Path) -> Path:
    """Walk upward from *start* until a directory containing pyproject.toml is found."""
    for candidate in [start] + list(start.parents):
        if (candidate / "pyproject.toml").exists():
            return candidate
    raise FileNotFoundError(
        f"Could not locate repo root from {start!r} (no pyproject.toml found)"
    )


# Cached at module import time — resolved from this file's location.
_MODULE_DIR = Path(__file__).resolve().parent
try:
    REPO_ROOT: Path = _find_repo_root(_MODULE_DIR)
except FileNotFoundError:
    REPO_ROOT = _MODULE_DIR.parent.parent  # best-effort fallback


# ---------------------------------------------------------------------------
# Keyword table stripping
# ---------------------------------------------------------------------------

# Matches from "#### Trigger Keywords" through the next horizontal rule or end of file.
# Uses re.DOTALL so `.` spans newlines.
_TRIGGER_KW_RE = re.compile(
    r"####\s*Trigger Keywords.*?(?=\n---|\Z)",
    re.DOTALL | re.IGNORECASE,
)


def load_base_prompt(repo_root: Path | None = None) -> str:
    """Read CLAUDE.md and strip the Trigger Keywords section.

    The keyword table is stripped so the LLM cannot override gateway mode
    routing by seeing the trigger mapping. CIPHER identity, operating mode
    definitions, output format specs, and all other content are preserved.

    Args:
        repo_root: Explicit repo root path. Defaults to the module-level REPO_ROOT.

    Returns:
        Stripped CLAUDE.md content as a string.
    """
    root = repo_root or REPO_ROOT
    claude_md = root / "CLAUDE.md"

    if not claude_md.exists():
        logger.warning("load_base_prompt: CLAUDE.md not found at %s", claude_md)
        return ""

    text = claude_md.read_text(encoding="utf-8")
    stripped = _TRIGGER_KW_RE.sub("", text)
    # Collapse any triple+ blank lines left by the removal.
    stripped = re.sub(r"\n{3,}", "\n\n", stripped).strip()
    return stripped


# ---------------------------------------------------------------------------
# Skill map and loading
# ---------------------------------------------------------------------------

# Maps CIPHER mode names to SKILL.md paths relative to skills/.
MODE_SKILL_MAP: dict[str, str] = {
    "RED": "red-team/SKILL.md",
    "BLUE": "blue-team/SKILL.md",
    "PURPLE": "purple-team/SKILL.md",
    "PRIVACY": "privacy-engineering/SKILL.md",
    "RECON": "osint-recon/SKILL.md",
    "INCIDENT": "incident-response/SKILL.md",
    "ARCHITECT": "security-architecture/SKILL.md",
}

# Background layers injected per mode.
# RED always gets PURPLE as background; ALL modes get PRIVACY.
_BACKGROUND_LAYERS: dict[str, list[str]] = {
    "RED": ["PURPLE", "PRIVACY"],
}
_DEFAULT_BACKGROUND: list[str] = ["PRIVACY"]


def load_skill(mode: str, repo_root: Path | None = None) -> str:
    """Load the SKILL.md file for *mode*.

    Args:
        mode: CIPHER mode name (e.g. "RED", "BLUE").
        repo_root: Explicit repo root. Defaults to REPO_ROOT.

    Returns:
        SKILL.md contents, or empty string if mode unknown or file missing.
    """
    root = repo_root or REPO_ROOT
    rel_path = MODE_SKILL_MAP.get(mode.upper())
    if rel_path is None:
        return ""

    skill_file = root / "skills" / rel_path
    if not skill_file.exists():
        logger.warning("load_skill: skill file not found at %s", skill_file)
        return ""

    return skill_file.read_text(encoding="utf-8")


def assemble_system_prompt(mode: str, repo_root: Path | None = None) -> str:
    """Assemble the full CIPHER system prompt for *mode*.

    Composition:
    1. Base prompt (CLAUDE.md with keyword table stripped)
    2. Primary skill for the requested mode
    3. Background layers (PURPLE for RED; PRIVACY for all modes)

    Sections are joined with ``\\n\\n---\\n\\n``. Empty sections are omitted.

    Args:
        mode: CIPHER operating mode (e.g. "RED", "BLUE", "ARCHITECT").
        repo_root: Explicit repo root. Defaults to REPO_ROOT.

    Returns:
        Assembled system prompt string.
    """
    root = repo_root or REPO_ROOT
    upper_mode = mode.upper()

    sections: list[str] = []

    # 1. Base prompt.
    base = load_base_prompt(root)
    if base:
        sections.append(base)

    # 2. Primary skill.
    primary = load_skill(upper_mode, root)
    if primary:
        sections.append(primary)

    # 3. Background layers.
    backgrounds = _BACKGROUND_LAYERS.get(upper_mode, _DEFAULT_BACKGROUND)
    for bg_mode in backgrounds:
        if bg_mode == upper_mode:
            # Never double-inject the primary skill.
            continue
        bg_skill = load_skill(bg_mode, root)
        if bg_skill:
            sections.append(bg_skill)

    return "\n\n---\n\n".join(sections)
