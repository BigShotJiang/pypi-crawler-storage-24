# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""CIPHER CLI — Typer-based command interface.

Usage:
    cipher "how to detect Kerberoasting"
    cipher --backend ollama "reverse shell techniques"
    cipher --smart "design a zero trust architecture"
    cipher setup
    cipher doctor
    cipher status
    cipher ingest
"""
from __future__ import annotations

import sys
from enum import Enum
from typing import Optional

import typer
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table

from gateway.theme import (
    MODE_COLORS,
    console,
    err_console,
    print_banner,
    print_error,
    print_info,
    print_success,
    print_warn,
)

app = typer.Typer(
    name="cipher",
    help="CIPHER — Security Engineering Assistant",
    no_args_is_help=True,
    rich_markup_mode="rich",
    add_completion=True,
)


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class Backend(str, Enum):
    ollama = "ollama"
    claude = "claude"


# ---------------------------------------------------------------------------
# Smart routing (preserved from original CLI)
# ---------------------------------------------------------------------------

COMPLEXITY_KEYWORDS = {
    "design", "architecture", "threat model", "analyze", "analyse",
    "compare", "explain", "model", "dpia", "risk assessment",
    "implement", "system", "strategy",
}


def _select_backend_smart(message: str) -> str:
    if len(message) > 200:
        return "claude"
    lower = message.lower()
    if any(kw in lower for kw in COMPLEXITY_KEYWORDS):
        return "claude"
    return "ollama"


# ---------------------------------------------------------------------------
# cipher query (default command)
# ---------------------------------------------------------------------------

@app.command()
def query(
    message: Optional[str] = typer.Argument(None, help="Security query to send to CIPHER."),
    backend: Optional[Backend] = typer.Option(None, "--backend", "-b", help="LLM backend override."),
    smart: bool = typer.Option(False, "--smart", "-s", help="Auto-route: simple→Ollama, complex→Claude."),
) -> None:
    """Send a security query through the CIPHER pipeline."""
    if message is None:
        if not sys.stdin.isatty():
            message = sys.stdin.read().strip()
        else:
            console.print("[cipher.error]No query provided.[/] Pass a message or pipe via stdin.")
            raise typer.Exit(2)

    if not message:
        console.print("[cipher.error]Query is empty.[/]")
        raise typer.Exit(2)

    from gateway.gateway import Gateway

    # Smart routing
    backend_str = None
    if smart and backend is None:
        backend_str = _select_backend_smart(message)
        err_console.print(f"[cipher.muted]smart routing → {backend_str}[/]")
    elif backend is not None:
        backend_str = backend.value

    # Send with spinner
    with console.status("[cipher.primary]Thinking...", spinner="dots"):
        gw = Gateway(backend_override=backend_str)
        result = gw.send(message)

    # Colorize mode header
    _print_response(result)


def _print_response(text: str) -> None:
    """Print a CIPHER response with colorized mode header."""
    lines = text.split("\n", 1)
    header = lines[0]
    body = lines[1] if len(lines) > 1 else ""

    # Extract mode from header
    mode = None
    if header.startswith("[MODE:"):
        mode = header.split(":")[1].strip().rstrip("]").strip()

    if mode and mode in MODE_COLORS:
        color = MODE_COLORS[mode]
        console.print(f"[{color}]{header}[/]")
    else:
        console.print(header)

    if body.strip():
        console.print(Markdown(body))


# ---------------------------------------------------------------------------
# cipher ingest
# ---------------------------------------------------------------------------

@app.command()
def ingest() -> None:
    """Re-index the knowledge base into the RAG vector store."""
    from gateway.retriever import Retriever

    print_banner()
    console.print("[cipher.primary]RAG Ingestion[/]\n")

    with console.status("[cipher.primary]Indexing knowledge base...", spinner="dots"):
        retriever = Retriever()
        count = retriever.ingest()

    print_success(f"Indexed {count} chunks into ChromaDB")
    print_info("RAG retrieval is now active for queries")


# ---------------------------------------------------------------------------
# cipher dashboard
# ---------------------------------------------------------------------------

@app.command()
def dashboard() -> None:
    """Launch the interactive cyberpunk terminal dashboard."""
    from gateway.dashboard import run_dashboard
    run_dashboard()


# ---------------------------------------------------------------------------
# cipher setup
# ---------------------------------------------------------------------------

@app.command()
def setup(
    backend: Optional[Backend] = typer.Option(None, "--backend", "-b", help="Pre-select backend (skip prompt)."),
    api_key: Optional[str] = typer.Option(None, "--api-key", help="Claude API key (skip prompt)."),
    non_interactive: bool = typer.Option(False, "--non-interactive", help="No prompts, use flags + env vars."),
) -> None:
    """Interactive onboarding wizard — configure CIPHER on first run."""
    import shutil
    import subprocess

    import yaml
    from rich.prompt import Confirm, Prompt

    from gateway.prompt import REPO_ROOT

    print_banner()
    console.print("[cipher.primary]Setup Wizard[/]\n")

    config: dict = {}

    # Step 1: Choose backend
    if backend is not None:
        chosen_backend = backend.value
    elif non_interactive:
        chosen_backend = "ollama"
    else:
        console.print("  [cipher.primary]Choose your LLM backend:[/]\n")
        console.print("  [bold]1[/] [cipher.success]Ollama[/]  — Local inference, free, private (requires GPU)")
        console.print("  [bold]2[/] [cipher.accent]Claude API[/] — Cloud inference, paid, highest quality\n")
        choice = Prompt.ask("  Select", choices=["1", "2"], default="1")
        chosen_backend = "ollama" if choice == "1" else "claude"

    config["llm_backend"] = chosen_backend
    print_success(f"Backend: {chosen_backend}")
    console.print()

    # Step 2: Backend-specific configuration
    if chosen_backend == "ollama":
        # Check if Ollama is running
        ollama_url = "http://127.0.0.1:11434"
        config["ollama"] = {"base_url": ollama_url, "model": "cipher", "timeout": 300}

        if shutil.which("ollama"):
            try:
                r = subprocess.run(["ollama", "list"], capture_output=True, timeout=5)
                if r.returncode == 0:
                    print_success("Ollama is running")
                    output = r.stdout.decode()
                    if "cipher" not in output:
                        console.print()
                        if non_interactive or Confirm.ask("  [cipher.warning]cipher model not found.[/] Create it now?", default=True):
                            modelfile = REPO_ROOT / "Modelfile"
                            if modelfile.exists():
                                with console.status("[cipher.primary]Creating cipher model (this may take a minute)...", spinner="dots"):
                                    subprocess.run(
                                        ["ollama", "create", "cipher", "-f", str(modelfile)],
                                        capture_output=True, timeout=300,
                                    )
                                print_success("cipher model created (qwen2.5:32b)")
                            else:
                                print_warn("Modelfile not found — create manually: ollama create cipher -f Modelfile")
                    else:
                        print_success("cipher model loaded")
                else:
                    print_warn("Ollama installed but not responding — start with: ollama serve")
            except (subprocess.TimeoutExpired, FileNotFoundError):
                print_warn("Ollama not responding — start with: ollama serve")
        else:
            print_warn("Ollama not installed — see https://ollama.com/download")

        # Set default Claude config (empty, for when user switches later)
        config["claude"] = {"api_key": "", "model": "claude-sonnet-4-5-20250929", "timeout": 120}

    else:  # claude
        config["ollama"] = {"base_url": "http://127.0.0.1:11434", "model": "cipher", "timeout": 300}

        # Get API key
        if api_key:
            key = api_key
        elif non_interactive:
            import os
            key = os.environ.get("ANTHROPIC_API_KEY", "")
            if not key:
                print_error("--non-interactive requires ANTHROPIC_API_KEY env var or --api-key")
                raise typer.Exit(1)
        else:
            key = Prompt.ask("  [cipher.accent]Anthropic API key[/]", password=True)

        if key:
            # Validate key
            with console.status("[cipher.primary]Validating API key...", spinner="dots"):
                try:
                    import anthropic
                    client = anthropic.Anthropic(api_key=key)
                    client.messages.create(
                        model="claude-sonnet-4-5-20250929",
                        max_tokens=10,
                        messages=[{"role": "user", "content": "ping"}],
                    )
                    print_success("API key validated")
                except Exception as exc:
                    print_error(f"API key validation failed: {exc}")
                    if not non_interactive and not Confirm.ask("  Continue anyway?", default=False):
                        raise typer.Exit(1)

        config["claude"] = {"api_key": key, "model": "claude-sonnet-4-5-20250929", "timeout": 120}

    # Step 3: Write config
    console.print()
    config_path = REPO_ROOT / "config.yaml"
    with open(config_path, "w") as f:
        yaml.safe_dump(config, f, default_flow_style=False, sort_keys=False)
    print_success(f"Config written to {config_path}")

    # Step 4: Ingest knowledge base
    console.print()
    console.print("  [cipher.primary]Indexing knowledge base...[/]")
    try:
        with console.status("[cipher.primary]Building RAG index...", spinner="dots"):
            from gateway.retriever import Retriever
            retriever = Retriever()
            count = retriever.ingest()
        print_success(f"Indexed {count:,} chunks from knowledge/")
    except Exception as exc:
        print_warn(f"RAG indexing failed: {exc}")
        print_info("Run 'cipher ingest' later to retry")

    # Step 5: Demo query
    console.print()
    if not non_interactive and Confirm.ask("  [cipher.primary]Run a demo query?[/]", default=True):
        demo_query = "What are the top 3 techniques for detecting lateral movement?"
        console.print(f"\n  [cipher.muted]> {demo_query}[/]\n")
        try:
            with console.status("[cipher.primary]Thinking...", spinner="dots"):
                from gateway.gateway import Gateway
                gw = Gateway(backend_override=chosen_backend)
                result = gw.send(demo_query)
            _print_response(result)
        except Exception as exc:
            print_warn(f"Demo query failed: {exc}")
            print_info("This is normal if the backend isn't fully configured yet")

    # Done
    console.print()
    console.print(Panel(
        "[cipher.success]Setup complete![/]\n\n"
        'Try: [bold]cipher "how do I detect Kerberoasting"[/]\n'
        "Run: [bold]cipher doctor[/] to verify everything\n"
        "Run: [bold]cipher status[/] to see system info",
        title="[cipher.primary]Ready[/]",
        border_style="cipher.primary",
    ))


# ---------------------------------------------------------------------------
# cipher status
# ---------------------------------------------------------------------------

@app.command()
def status() -> None:
    """Show CIPHER system status."""
    from gateway.config import load_config
    from gateway.prompt import REPO_ROOT

    print_banner()

    cfg = load_config()

    # Backend
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Key", style="cipher.muted")
    table.add_column("Value")

    table.add_row("Backend", f"[bold]{cfg.backend}[/]")

    if cfg.backend == "ollama":
        table.add_row("Model", cfg.ollama_model)
        table.add_row("Ollama URL", cfg.ollama_base_url)
    else:
        table.add_row("Model", cfg.claude_model)

    # RAG
    try:
        from gateway.retriever import Retriever
        r = Retriever()
        table.add_row("RAG Chunks", f"[cipher.success]{r.count:,}[/]")
    except Exception:
        table.add_row("RAG Chunks", "[cipher.warning]unavailable[/]")

    # Knowledge
    kb_dir = REPO_ROOT / "knowledge"
    if kb_dir.is_dir():
        md_count = len(list(kb_dir.glob("*.md")))
        table.add_row("Knowledge Docs", str(md_count))

    # Skills
    skills_dir = REPO_ROOT / "skills"
    if skills_dir.is_dir():
        skill_count = len(list(skills_dir.rglob("SKILL.md")))
        table.add_row("Skill Files", str(skill_count))

    # Modes
    table.add_row("Modes", "RED, BLUE, PURPLE, PRIVACY, RECON, INCIDENT, ARCHITECT")

    console.print(Panel(table, title="[cipher.primary]CIPHER Status[/]", border_style="cipher.primary"))


# ---------------------------------------------------------------------------
# cipher doctor
# ---------------------------------------------------------------------------

@app.command()
def doctor(
    fix: bool = typer.Option(False, "--fix", help="Auto-repair issues where possible."),
) -> None:
    """Run diagnostics and health checks."""
    import shutil
    import subprocess

    from gateway.prompt import REPO_ROOT

    print_banner()
    console.print("[cipher.primary]Diagnostics[/]\n")

    issues = 0

    # 1. Python version
    v = sys.version_info
    if v >= (3, 10):
        print_success(f"Python {v.major}.{v.minor}.{v.micro}")
    else:
        print_error(f"Python {v.major}.{v.minor} — need 3.10+")
        issues += 1

    # 2. Ollama running
    if shutil.which("ollama"):
        try:
            r = subprocess.run(["ollama", "list"], capture_output=True, timeout=5)
            if r.returncode == 0:
                output = r.stdout.decode()
                if "cipher" in output:
                    print_success("Ollama running, cipher model loaded")
                else:
                    print_warn("Ollama running but cipher model not found")
                    if fix:
                        print_info("Creating cipher model...")
                        modelfile = REPO_ROOT / "Modelfile"
                        if modelfile.exists():
                            subprocess.run(["ollama", "create", "cipher", "-f", str(modelfile)], timeout=300)
                            print_success("cipher model created")
                    else:
                        print_info("Run: ollama create cipher -f Modelfile")
                    issues += 1
            else:
                print_error("Ollama not responding")
                issues += 1
        except (subprocess.TimeoutExpired, FileNotFoundError):
            print_error("Ollama not responding")
            issues += 1
    else:
        print_warn("Ollama not installed (optional for local inference)")

    # 3. Claude API key
    import os
    if os.environ.get("ANTHROPIC_API_KEY"):
        print_success("Claude API key configured (env)")
    else:
        try:
            from gateway.config import load_config
            cfg = load_config()
            if cfg.claude_api_key:
                print_success("Claude API key configured (config)")
            else:
                print_warn("No Claude API key (optional if using Ollama)")
        except Exception:
            print_warn("No Claude API key configured")

    # 4. RAG index
    try:
        from gateway.retriever import Retriever
        r = Retriever()
        if r.count > 0:
            print_success(f"RAG index: {r.count:,} chunks")
        else:
            print_error("RAG index empty")
            if fix:
                print_info("Ingesting knowledge base...")
                count = r.ingest()
                print_success(f"Ingested {count:,} chunks")
            else:
                print_info("Run: cipher ingest")
            issues += 1
    except Exception as exc:
        print_error(f"RAG unavailable: {exc}")
        issues += 1

    # 5. Knowledge directory
    kb_dir = REPO_ROOT / "knowledge"
    if kb_dir.is_dir():
        md_files = list(kb_dir.glob("*.md"))
        empty = [f for f in md_files if f.stat().st_size < 100]
        if empty:
            print_warn(f"Knowledge: {len(md_files)} docs, {len(empty)} empty/tiny")
            for f in empty:
                print_info(f"  {f.name}")
            issues += 1
        else:
            print_success(f"Knowledge: {len(md_files)} docs, all have content")
    else:
        print_error("Knowledge directory missing")
        issues += 1

    # 6. Skill files
    skills_dir = REPO_ROOT / "skills"
    expected_skills = [
        "red-team", "blue-team", "purple-team", "privacy-engineering",
        "osint-recon", "incident-response", "threat-intelligence",
        "automation-scripting", "security-architecture",
    ]
    missing_skills = [s for s in expected_skills if not (skills_dir / s / "SKILL.md").exists()]
    if missing_skills:
        print_error(f"Missing skill files: {', '.join(missing_skills)}")
        issues += 1
    else:
        print_success(f"All {len(expected_skills)} skill files present")

    # Summary
    console.print()
    if issues == 0:
        console.print("[cipher.success]All checks passed.[/]")
    else:
        console.print(f"[cipher.warning]{issues} issue(s) found.[/]")
        if not fix:
            console.print("[cipher.muted]Run with --fix to auto-repair.[/]")


# ---------------------------------------------------------------------------
# cipher setup-signal (preserved from original)
# ---------------------------------------------------------------------------

@app.command("setup-signal")
def setup_signal(
    signal_api: str = typer.Option("http://localhost:8080", help="signal-cli-rest-api URL."),
) -> None:
    """Register a Signal phone number for the CIPHER bot."""
    import httpx

    print_banner()
    console.print("[cipher.primary]Signal Bot Registration[/]\n")
    print_info("Prerequisites: docker compose up -d signal-api\n")

    with httpx.Client(timeout=10) as client:
        # Verify API
        try:
            client.get(f"{signal_api.rstrip('/')}/v1/about").raise_for_status()
            print_success("signal-cli-rest-api is reachable")
        except Exception as exc:
            print_error(f"Cannot reach signal-cli-rest-api: {exc}")
            raise typer.Exit(1)

        # Register
        number = typer.prompt("Phone number (E.164)")
        console.print("\n[cipher.muted]Captcha steps:[/]")
        print_info("1. Open https://signalcaptchas.org/registration/generate.html")
        print_info("2. Solve the captcha")
        print_info("3. Right-click 'Open Signal' → Copy link address")
        raw = typer.prompt("Captcha URL or token")
        token = raw.removeprefix("signalcaptcha://")

        try:
            client.post(
                f"{signal_api.rstrip('/')}/v1/register/{number}",
                json={"captcha": token, "use_voice": False},
            ).raise_for_status()
        except httpx.HTTPStatusError as exc:
            print_error(f"Registration failed: {exc}")
            print_info("Captcha must be solved from same IP as signal-cli-rest-api")
            raise typer.Exit(1)

        code = typer.prompt("Verification code")
        try:
            client.post(f"{signal_api.rstrip('/')}/v1/register/{number}/verify/{code}").raise_for_status()
        except httpx.HTTPStatusError as exc:
            print_error(f"Verification failed: {exc}")
            raise typer.Exit(1)

    print_success(f"Registered {number}")
    print_info(f"Set signal.phone_number: {number} in config.yaml")
    print_info("Run: docker compose up cipher-bot")


# ---------------------------------------------------------------------------
# cipher version
# ---------------------------------------------------------------------------

@app.command()
def version() -> None:
    """Show CIPHER version."""
    console.print("[cipher.primary]CIPHER[/] v0.2.0")


# ---------------------------------------------------------------------------
# Default: bare `cipher "query"` without subcommand
# ---------------------------------------------------------------------------

def main() -> None:
    """CLI entrypoint — handles bare `cipher "message"` by prepending `query`.

    Supports:
        cipher "how do I detect Kerberoasting"     → cipher query "..."
        cipher --backend ollama "query"             → cipher query --backend ollama "..."
        cipher -s "complex analysis"                → cipher query -s "..."
        cipher status                               → runs status subcommand
    """
    args = sys.argv[1:]
    known_commands = {"query", "ingest", "status", "doctor", "setup", "setup-signal", "dashboard", "version"}
    global_flags = {"--help", "-h", "--install-completion", "--show-completion"}

    # Find the first non-flag argument
    first_positional = None
    for a in args:
        if not a.startswith("-"):
            first_positional = a
            break

    # If the first positional isn't a known command, prepend "query"
    if first_positional is not None and first_positional not in known_commands:
        args = ["query"] + args
    elif not args or (args and args[0] in global_flags):
        pass  # --help or no args — let Typer handle it

    sys.argv = [sys.argv[0]] + args
    app()


if __name__ == "__main__":
    main()
