# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""CIPHER gateway LLM client factory.

Returns a configured anthropic.Anthropic client for the active backend.
Both Ollama and Claude API use the same SDK — Ollama's Anthropic-compat
layer (v0.14.0+) handles the translation transparently.

Usage:
    client, model = make_client(cfg)
    response = client.messages.create(
        model=model,
        max_tokens=4096,
        system=system_prompt,
        messages=[{"role": "user", "content": message}],
    )
"""
from __future__ import annotations

import anthropic
import httpx

from gateway.config import GatewayConfig


def make_client(cfg: GatewayConfig) -> tuple[anthropic.Anthropic, str]:
    """Build an anthropic.Anthropic client for the configured backend.

    Args:
        cfg: Validated gateway configuration. GatewayConfig.__post_init__
             ensures the backend and active model are set.

    Returns:
        (client, model_name) — the client is ready to call .messages.create().

    Notes:
        - Ollama: base_url points to localhost:11434, api_key="ollama" (SDK
          requires a key; Ollama ignores its value).
        - Claude: standard Anthropic API with configured api_key and default
          base_url (api.anthropic.com).
        - Timeouts come from GatewayConfig — 300s for Ollama (local inference
          can be slow), 60s for Claude API.
    """
    if cfg.backend == "ollama":
        client = anthropic.Anthropic(
            base_url=cfg.ollama_base_url,
            api_key="ollama",  # Ollama ignores the key; SDK constructor requires it
            timeout=httpx.Timeout(float(cfg.ollama_timeout)),
        )
        return client, cfg.ollama_model

    # backend == "claude"
    client = anthropic.Anthropic(
        api_key=cfg.claude_api_key,
        timeout=httpx.Timeout(float(cfg.claude_timeout)),
    )
    return client, cfg.claude_model
