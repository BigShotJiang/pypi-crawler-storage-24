# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""CIPHER Dashboard — cyberpunk terminal UI built with Textual.

Usage:
    cipher dashboard
"""
from __future__ import annotations

from textual import on, work
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.css.query import NoMatches
from textual.widgets import (
    Footer,
    Header,
    Input,
    Label,
    Markdown,
    Static,
)


# ---------------------------------------------------------------------------
# Cyberpunk CSS
# ---------------------------------------------------------------------------

CIPHER_CSS = """
Screen {
    background: #0a0a0a;
}

Header {
    background: #0d1117;
    color: #00ff41;
    text-style: bold;
}

Footer {
    background: #0d1117;
    color: #5a6480;
}

#status-panel {
    height: 7;
    background: #0d1117;
    border: solid #1a1f2e;
    padding: 0 1;
}

.status-key {
    color: #5a6480;
    width: 14;
}

.status-val {
    color: #c9d1d9;
}

.status-val-good {
    color: #00e5cc;
}

#mode-bar {
    height: 3;
    background: #0d1117;
    border: solid #1a1f2e;
    padding: 0 1;
}

.mode-label {
    width: 12;
    content-align: center middle;
    text-style: bold;
    margin: 0 1;
}

.mode-red { background: #2d0a0a; color: #ff2d2d; }
.mode-blue { background: #0a1a2d; color: #2d9bff; }
.mode-purple { background: #1a0a2d; color: #9b59b6; }
.mode-privacy { background: #0a1a0d; color: #27ae60; }
.mode-recon { background: #1a1a0a; color: #f39c12; }
.mode-incident { background: #2d0a0a; color: #e74c3c; }
.mode-architect { background: #0a1a2d; color: #3498db; }

#response-area {
    background: #0d1117;
    border: solid #1a1f2e;
    padding: 1 2;
    overflow-y: auto;
}

#response-area Markdown {
    background: #0d1117;
    color: #c9d1d9;
}

#query-input {
    dock: bottom;
    background: #161b22;
    color: #00ff41;
    border: tall #00ff41;
    padding: 0 1;
}

#query-input:focus {
    border: tall #00ff41;
}

#welcome {
    color: #5a6480;
    text-align: center;
    padding: 2;
}

.spinner-label {
    color: #00ff41;
    text-style: italic;
}
"""


# ---------------------------------------------------------------------------
# Dashboard App
# ---------------------------------------------------------------------------

class CipherDashboard(App):
    """CIPHER cyberpunk terminal dashboard."""

    TITLE = "CIPHER"
    SUB_TITLE = "Security Engineering Assistant"
    CSS = CIPHER_CSS

    BINDINGS = [
        Binding("ctrl+q", "quit", "Quit"),
        Binding("ctrl+l", "clear", "Clear"),
        Binding("escape", "focus_input", "Focus Input", show=False),
    ]

    def __init__(self) -> None:
        super().__init__()
        self._gateway = None
        self._history: list[dict] = []

    def compose(self) -> ComposeResult:
        yield Header()

        # Status panel
        with Horizontal(id="status-panel"):
            with Vertical():
                yield Label("[b]Backend[/]", classes="status-key")
                yield Label("[b]Model[/]", classes="status-key")
                yield Label("[b]RAG[/]", classes="status-key")
            with Vertical():
                yield Label("loading...", id="val-backend", classes="status-val")
                yield Label("loading...", id="val-model", classes="status-val")
                yield Label("loading...", id="val-rag", classes="status-val")
            with Vertical():
                yield Label("[b]Knowledge[/]", classes="status-key")
                yield Label("[b]Skills[/]", classes="status-key")
                yield Label("[b]Modes[/]", classes="status-key")
            with Vertical():
                yield Label("loading...", id="val-knowledge", classes="status-val")
                yield Label("loading...", id="val-skills", classes="status-val")
                yield Label("7", id="val-modes", classes="status-val-good")

        # Mode bar
        with Horizontal(id="mode-bar"):
            yield Label("RED", classes="mode-label mode-red")
            yield Label("BLUE", classes="mode-label mode-blue")
            yield Label("PURPLE", classes="mode-label mode-purple")
            yield Label("PRIVACY", classes="mode-label mode-privacy")
            yield Label("RECON", classes="mode-label mode-recon")
            yield Label("INCIDENT", classes="mode-label mode-incident")
            yield Label("ARCHITECT", classes="mode-label mode-architect")

        # Response area
        with VerticalScroll(id="response-area"):
            yield Static(
                "[dim]Type a security query below and press Enter.\n\n"
                "Examples:\n"
                '  "how do I detect Kerberoasting"\n'
                '  "write a Sigma rule for lateral movement via PsExec"\n'
                '  "GDPR breach notification requirements"\n'
                '  "[MODE: RED] exploit AS-REP roasting"\n\n'
                "Ctrl+L to clear, Ctrl+Q to quit.[/]",
                id="welcome",
            )

        # Query input
        yield Input(placeholder="Enter security query...", id="query-input")

        yield Footer()

    def on_mount(self) -> None:
        """Load status on startup."""
        self._load_status()
        self.query_one("#query-input", Input).focus()

    @work(thread=True)
    def _load_status(self) -> None:
        """Load system status in background thread."""
        try:
            from gateway.config import load_config
            cfg = load_config()
            self.call_from_thread(self._update_label, "val-backend", cfg.backend, good=True)
            model = cfg.ollama_model if cfg.backend == "ollama" else cfg.claude_model
            self.call_from_thread(self._update_label, "val-model", model, good=True)
        except Exception:
            self.call_from_thread(self._update_label, "val-backend", "not configured", good=False)
            self.call_from_thread(self._update_label, "val-model", "—", good=False)

        try:
            from gateway.retriever import Retriever
            r = Retriever()
            self.call_from_thread(self._update_label, "val-rag", f"{r.count:,} chunks", good=True)
        except Exception:
            self.call_from_thread(self._update_label, "val-rag", "unavailable", good=False)

        try:
            from gateway.prompt import REPO_ROOT
            kb = REPO_ROOT / "knowledge"
            count = len(list(kb.glob("*.md"))) if kb.is_dir() else 0
            self.call_from_thread(self._update_label, "val-knowledge", f"{count} docs", good=True)
            skills = REPO_ROOT / "skills"
            scount = len(list(skills.rglob("SKILL.md"))) if skills.is_dir() else 0
            self.call_from_thread(self._update_label, "val-skills", str(scount), good=True)
        except Exception:
            pass

    def _update_label(self, label_id: str, text: str, good: bool = True) -> None:
        try:
            label = self.query_one(f"#{label_id}", Label)
            cls = "status-val-good" if good else "status-val"
            label.update(text)
            label.set_classes(cls)
        except NoMatches:
            pass

    @on(Input.Submitted, "#query-input")
    def on_query_submit(self, event: Input.Submitted) -> None:
        """Handle query submission."""
        query = event.value.strip()
        if not query:
            return

        event.input.value = ""
        self._send_query(query)

    @work(thread=True)
    def _send_query(self, query: str) -> None:
        """Send query to gateway in background thread."""
        # Show user query
        self.call_from_thread(self._append_message, "user", query)
        self.call_from_thread(self._append_message, "system", "Thinking...")

        try:
            if self._gateway is None:
                from gateway.gateway import Gateway
                self._gateway = Gateway()

            result = self._gateway.send(query, history=self._history if self._history else None)

            # Update history
            self._history.append({"role": "user", "content": query})
            self._history.append({"role": "assistant", "content": result})

            # Remove "Thinking..." and show response
            self.call_from_thread(self._remove_thinking)
            self.call_from_thread(self._append_response, result)

        except Exception as exc:
            self.call_from_thread(self._remove_thinking)
            self.call_from_thread(self._append_message, "error", f"Error: {exc}")

    def _append_message(self, role: str, text: str) -> None:
        container = self.query_one("#response-area", VerticalScroll)
        # Remove welcome on first message
        try:
            welcome = self.query_one("#welcome", Static)
            welcome.remove()
        except NoMatches:
            pass

        if role == "user":
            container.mount(Static(f"[bold #00ff41]> {text}[/]"))
        elif role == "system":
            container.mount(Static(f"[italic #5a6480]{text}[/]", classes="spinner-label"))
        elif role == "error":
            container.mount(Static(f"[bold #ff4d4d]{text}[/]"))

        container.scroll_end()

    def _remove_thinking(self) -> None:
        try:
            for widget in self.query(".spinner-label"):
                widget.remove()
        except NoMatches:
            pass

    def _append_response(self, text: str) -> None:
        container = self.query_one("#response-area", VerticalScroll)

        # Colorize mode header
        lines = text.split("\n", 1)
        header = lines[0]
        body = lines[1] if len(lines) > 1 else ""

        mode_colors = {
            "RED": "#ff2d2d", "BLUE": "#2d9bff", "PURPLE": "#9b59b6",
            "PRIVACY": "#27ae60", "RECON": "#f39c12", "INCIDENT": "#e74c3c",
            "ARCHITECT": "#3498db",
        }

        if header.startswith("[MODE:"):
            mode = header.split(":")[1].strip().rstrip("]").strip()
            color = mode_colors.get(mode, "#00ff41")
            container.mount(Static(f"[bold {color}]{header}[/]"))
        else:
            body = text

        if body.strip():
            container.mount(Markdown(body))

        container.mount(Static("[dim]─────────────────────────────────────────[/]"))
        container.scroll_end()

    def action_clear(self) -> None:
        """Clear response area and history."""
        container = self.query_one("#response-area", VerticalScroll)
        container.remove_children()
        container.mount(Static("[dim]Cleared. Type a new query.[/]"))
        self._history.clear()

    def action_focus_input(self) -> None:
        self.query_one("#query-input", Input).focus()


def run_dashboard() -> None:
    """Launch the CIPHER dashboard."""
    app = CipherDashboard()
    app.run()


if __name__ == "__main__":
    run_dashboard()
