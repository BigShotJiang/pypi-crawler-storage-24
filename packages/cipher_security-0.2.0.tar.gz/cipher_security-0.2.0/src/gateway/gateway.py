# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""CIPHER Gateway orchestrator.

Wires config, client, prompt, mode, and retriever modules into a single send() interface.

Usage:
    from gateway import Gateway

    gw = Gateway()
    response = gw.send("how do I exploit a SQLi vulnerability")
    print(response)  # [MODE: RED] ...
"""
from __future__ import annotations

import logging

import anthropic

from gateway.client import make_client
from gateway.config import load_config
from gateway.mode import detect_mode, parse_keyword_table, strip_mode_prefix
from gateway.prompt import assemble_system_prompt

logger = logging.getLogger(__name__)


def _load_retriever():
    """Lazy-load the RAG retriever. Returns None if unavailable."""
    try:
        from gateway.retriever import Retriever
        r = Retriever()
        if r.count > 0:
            return r
        logger.info("Gateway: RAG collection empty — running without retrieval")
    except Exception as exc:
        logger.info("Gateway: RAG unavailable (%s) — running without retrieval", exc)
    return None


class Gateway:
    """CIPHER gateway orchestrator.

    Initialises once from config and routes every message through the
    full pipeline: mode detection → prompt assembly → RAG retrieval → LLM call → response.
    """

    def __init__(self, backend_override: str | None = None, rag: bool = True) -> None:
        """Initialise gateway.

        Args:
            backend_override: If provided, replaces config.backend.
                              Useful for testing or CLI --backend flag.
            rag: Whether to enable RAG retrieval. Defaults to True.
        """
        cfg = load_config()
        if backend_override is not None:
            # Replace backend in-place — GatewayConfig is a mutable dataclass.
            cfg.backend = backend_override
            logger.info("Gateway: backend overridden to %r", backend_override)

        self._client, self._model = make_client(cfg)
        logger.info("Gateway: client ready (backend=%r, model=%r)", cfg.backend, self._model)

        # Cache keyword table at startup so every send() call is O(1) lookup.
        # Parse from raw CLAUDE.md (not the stripped base prompt) since
        # load_base_prompt() removes the Trigger Keywords section.
        from gateway.prompt import REPO_ROOT
        raw_claude_md = (REPO_ROOT / "CLAUDE.md").read_text(encoding="utf-8")
        self._keyword_table: dict[str, list[str]] = parse_keyword_table(raw_claude_md)
        logger.info("Gateway: keyword table loaded (%d modes)", len(self._keyword_table))

        # RAG retriever (lazy, graceful fallback if chromadb not installed or empty).
        self._retriever = _load_retriever() if rag else None
        if self._retriever:
            logger.info("Gateway: RAG enabled (%d chunks)", self._retriever.count)

    def send(self, message: str, history: list[dict] | None = None) -> str:
        """Send a message through the full CIPHER pipeline.

        Pipeline:
        1. Detect mode (explicit prefix or keyword scoring).
        2. If needs_clarification → return disambiguation string (no LLM call).
        3. Assemble system prompt for detected mode.
        4. Strip mode prefix from message.
        5. Build messages list (history + new user message).
        6. Call LLM.
        7. Prepend [MODE: X] header if missing.
        8. Return response.

        Args:
            message: User message text. May include [MODE: X] prefix.
            history: Optional list of prior message dicts
                     ({"role": "user"|"assistant", "content": "..."}).

        Returns:
            Response string, always starting with [MODE: X] header.
        """
        # 1. Detect mode.
        mode, needs_clarification = detect_mode(message, self._keyword_table)

        # 2. Disambiguation short-circuit.
        if needs_clarification:
            logger.info("Gateway: mode overlap detected (%r) — requesting clarification", mode)
            return (
                f"Multiple modes detected ({mode}). "
                "Are you approaching this offensively or defensively?"
            )

        logger.info("Gateway: routing to mode %r", mode)

        # 3. Assemble system prompt.
        system_prompt = assemble_system_prompt(mode)

        # 3b. RAG retrieval — inject relevant knowledge chunks.
        if self._retriever:
            chunks = self._retriever.query(message, top_k=5)
            if chunks:
                from gateway.retriever import Retriever
                context_block = Retriever.format_context(chunks)
                if context_block:
                    system_prompt = system_prompt + "\n\n---\n\n" + context_block
                    logger.info(
                        "Gateway: injected %d RAG chunks (%.1f KB)",
                        len(chunks),
                        len(context_block) / 1024,
                    )

        # 4. Strip mode prefix.
        clean_message = strip_mode_prefix(message)

        # 5. Prepend [MODE: X] for LLM context.
        user_content = f"[MODE: {mode}] {clean_message}"

        # 6. Build messages list.
        messages: list[dict] = []
        if history:
            messages.extend(history)
        messages.append({"role": "user", "content": user_content})

        # 7. Call LLM.
        try:
            response = self._client.messages.create(
                model=self._model,
                max_tokens=4096,
                system=system_prompt,
                messages=messages,
            )
            response_text: str = response.content[0].text

        except anthropic.APITimeoutError:
            logger.error("Gateway: LLM backend timed out")
            return "[ERROR] Backend timed out. Is the LLM backend running?"

        except anthropic.APIConnectionError as exc:
            logger.error("Gateway: cannot reach backend — %s", exc)
            return f"[ERROR] Cannot reach backend: {exc}"

        except anthropic.APIStatusError as exc:
            logger.error("Gateway: backend returned HTTP %s — %s", exc.status_code, exc.message)
            return f"[ERROR] Backend returned {exc.status_code}: {exc.message}"

        # 8. Ensure exactly one [MODE: X] header is present.
        if not response_text.startswith("[MODE:"):
            response_text = f"[MODE: {mode}]\n{response_text}"
        # Strip duplicate header if LLM echoed it twice.
        lines = response_text.split("\n", 2)
        if len(lines) >= 2 and lines[0].startswith("[MODE:") and lines[1].startswith("[MODE:"):
            response_text = "\n".join([lines[0]] + lines[2:]) if len(lines) > 2 else lines[0]

        return response_text
