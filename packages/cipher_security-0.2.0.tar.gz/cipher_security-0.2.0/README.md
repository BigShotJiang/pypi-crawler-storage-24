<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

<div align="center">

```
   ██████╗██╗██████╗ ██╗  ██╗███████╗██████╗
  ██╔════╝██║██╔══██╗██║  ██║██╔════╝██╔══██╗
  ██║     ██║██████╔╝███████║█████╗  ██████╔╝
  ██║     ██║██╔═══╝ ██╔══██║██╔══╝  ██╔══██╗
  ╚██████╗██║██║     ██║  ██║███████╗██║  ██║
   ╚═════╝╚═╝╚═╝     ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝
```

**Security Engineering Assistant**

[![License: AGPL-3.0](https://img.shields.io/badge/License-AGPL%20v3-blue.svg)](LICENSE)
[![Tests](https://github.com/defconxt/CIPHER/actions/workflows/ci.yml/badge.svg)](https://github.com/defconxt/CIPHER/actions)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-00ff41.svg)](https://python.org)

A principal-level security engineering assistant with 96 deep-dive knowledge docs,
RAG-powered retrieval, 7 operating modes, and 28 specialized skills.
Runs locally via Ollama or cloud via Claude API.

[Install](#install) · [Quick Start](#quick-start) · [Features](#features) · [Documentation](https://blacktemple.net/cipher)

</div>

---

## Install

**One-liner (Linux/macOS):**
```bash
curl -fsSL https://blacktemple.net/cipher/install.sh | bash
```

**Windows PowerShell:**
```powershell
iwr -useb https://blacktemple.net/cipher/install.ps1 | iex
```

> **Note:** Install scripts also available at `https://raw.githubusercontent.com/defconxt/CIPHER/main/scripts/install.sh`

**pip:**
```bash
pip install cipher-security
cipher setup
```

**Docker:**
```bash
docker run -it ghcr.io/defconxt/cipher "how do I detect Kerberoasting"
```

## Quick Start

```bash
# Ask anything security
cipher "how do I detect lateral movement via PsExec"

# Force a specific mode
cipher "[MODE: RED] exploit AS-REP roasting in Active Directory"

# Auto-route: simple queries → local Ollama, complex → Claude API
cipher --smart "design a zero trust architecture for multi-cloud"

# Interactive dashboard
cipher dashboard

# System health check
cipher doctor
```

## Features

### 7 Operating Modes

| Mode | Focus | Triggers |
|------|-------|----------|
| **RED** | Offensive security, attack paths, exploitation | exploit, payload, privesc, C2, red team |
| **BLUE** | Detection, SIEM, hardening, threat hunting | detection, Sigma, SIEM, EDR, hardening |
| **PURPLE** | Adversary emulation, coverage mapping | emulation, ATT&CK mapping, gap analysis |
| **PRIVACY** | GDPR, CCPA, HIPAA, DPIAs, anonymization | GDPR, CCPA, HIPAA, DPIA, privacy |
| **RECON** | OSINT, reconnaissance, footprinting | OSINT, recon, subdomain, footprinting |
| **INCIDENT** | IR playbooks, forensics, containment | triage, incident response, IOC, forensics |
| **ARCHITECT** | Zero trust, threat modeling, design | design, architecture, threat model, zero trust |

Modes auto-detect from your query. Ambiguous queries prompt for clarification.

### 96 Deep-Dive Knowledge Docs

RAG-powered retrieval over 145K+ lines of security knowledge:

- **Offensive**: AD attacks, web exploitation, cloud attacks, C2, shells, evasion techniques
- **Defensive**: Sigma rules, SIEM/SOC, EDR internals, hardening guides, Windows Event Log mastery
- **Forensics**: DFIR hunting, forensic artifacts, timeline analysis, memory forensics, email forensics
- **Architecture**: Threat modeling (STRIDE/PASTA), cloud reference architectures, crypto/PKI/TLS
- **Compliance**: NIST, CIS, SOC2, ISO 27001, GDPR, PCI DSS, HIPAA
- **Emerging**: Breach case studies (12 major incidents), AI/ML security, vulnerability research, ransomware ecosystem

### 28 Slash Commands (Claude Code)

```
/cipher:redteam    /cipher:web        /cipher:phishing    /cipher:malware
/cipher:hunt       /cipher:sigma      /cipher:hardening   /cipher:forensics
/cipher:purple     /cipher:recon      /cipher:privacy     /cipher:insider
/cipher:threatmodel /cipher:cloud     /cipher:crypto      /cipher:devsecops
/cipher:ir         /cipher:cve        /cipher:threatintel  /cipher:aisec
/cipher:audit      /cipher:report     /cipher:ics         /cipher:mobile
/cipher:cc         /cipher:ollama     /cipher:claudeapi   /cipher:smart
```

### Multiple Interfaces

| Interface | Command | Cost |
|-----------|---------|------|
| **CLI** | `cipher "query"` | Free (Ollama) or paid (Claude) |
| **Dashboard** | `cipher dashboard` | Free (Ollama) or paid (Claude) |
| **Claude Code** | `/cipher:cc "query"` | Included with Claude Code |
| **Signal Bot** | Message the bot | Free (Ollama) or paid (Claude) |
| **Docker** | `docker run -it cipher "query"` | Free (Ollama) or paid (Claude) |

### RAG Pipeline

Semantic search over the entire knowledge base:
- **14,600+ chunks** indexed in ChromaDB
- Markdown-aware chunking preserving section context
- Top-5 retrieval injected into system prompt before every query
- Auto re-ingests on knowledge base changes (git hook)

## CLI Commands

```
cipher "query"              Send a security query (default command)
cipher --smart "query"      Auto-route: simple→Ollama, complex→Claude
cipher --backend ollama     Force local inference
cipher --backend claude     Force cloud inference
cipher setup                Interactive onboarding wizard
cipher dashboard            Cyberpunk terminal UI
cipher doctor               Diagnostics and health checks
cipher doctor --fix         Auto-repair issues
cipher status               Show system status
cipher ingest               Re-index the knowledge base
cipher version              Show version
```

## Architecture

```
┌─────────────────────────────────────────────────────┐
│                    Interfaces                        │
│  CLI · Dashboard · Claude Code · Signal Bot · Docker │
└──────────────────────┬──────────────────────────────┘
                       │
              ┌────────▼────────┐
              │    Gateway      │
              │  Mode Detection │──── 7 modes
              │  Prompt Assembly│──── 13 skill files
              │  RAG Retrieval  │──── 14,600 chunks
              └────────┬────────┘
                       │
           ┌───────────┼───────────┐
           │                       │
    ┌──────▼──────┐        ┌──────▼──────┐
    │   Ollama    │        │  Claude API │
    │  (local)    │        │   (cloud)   │
    │ qwen2.5:32b │        │ sonnet-4-5  │
    └─────────────┘        └─────────────┘
```

## Configuration

Config file: `config.yaml` (project root) or `~/.config/cipher/config.yaml`

Supports `${VAR}` and `${VAR:-default}` environment variable substitution:

```yaml
llm_backend: ollama

ollama:
  base_url: "http://127.0.0.1:11434"
  model: "cipher"
  timeout: 300

claude:
  api_key: "${ANTHROPIC_API_KEY}"
  model: "claude-sonnet-4-5-20250929"
  timeout: 120
```

Priority: env vars > project config > home config.

## Development

```bash
git clone https://github.com/defconxt/CIPHER.git && cd CIPHER
python -m venv .venv && source .venv/bin/activate
pip install -e ".[signal]"
pytest tests/ --ignore=tests/test_integration.py
```

**318 tests** covering gateway, mode routing, RAG quality, architecture guardrails, and configuration.

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines. Security researchers welcome.

## License

[AGPL-3.0](LICENSE) — CIPHER is a trademark of [defconxt](https://github.com/defconxt).
