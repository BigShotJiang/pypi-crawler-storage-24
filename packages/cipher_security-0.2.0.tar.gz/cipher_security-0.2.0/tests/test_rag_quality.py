# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""RAG quality regression tests — validate retrieval across all security domains.

Each test sends a canonical query and asserts the correct knowledge doc
is retrieved. Catches knowledge degradation after re-ingestion.
"""
from __future__ import annotations

import pytest


def _rag_available() -> bool:
    try:
        from gateway.retriever import Retriever
        r = Retriever()
        return r.count > 0
    except Exception:
        return False


# Skip all tests if RAG index is empty (CI without ingestion)
pytestmark = pytest.mark.skipif(
    not _rag_available(),
    reason="RAG index empty or ChromaDB unavailable",
)


@pytest.fixture(scope="module")
def retriever():
    from gateway.retriever import Retriever
    return Retriever()


def _assert_source_in_results(retriever, query: str, expected_source: str, top_k: int = 5):
    """Assert that the expected source file appears in the top-k results."""
    results = retriever.query(query, top_k=top_k)
    sources = [r["source"] for r in results]
    assert expected_source in sources, (
        f"Expected '{expected_source}' in results for query '{query}', "
        f"got: {sources}"
    )


# ---------------------------------------------------------------------------
# RED mode — Offensive security
# ---------------------------------------------------------------------------

class TestRAGOffensive:
    def test_kerberoasting(self, retriever):
        _assert_source_in_results(retriever, "Kerberoasting AS-REP roasting", "active-directory-deep.md")

    def test_sql_injection(self, retriever):
        _assert_source_in_results(retriever, "SQL injection UNION SELECT blind SQLi web application", "websec-deep.md", top_k=10)

    def test_linux_privesc(self, retriever):
        _assert_source_in_results(retriever, "Linux privilege escalation SUID", "linux-exploitation-deep.md")

    def test_c2_framework(self, retriever):
        _assert_source_in_results(retriever, "C2 post exploitation Sliver Cobalt Strike implant", "c2-postexploit-deep.md", top_k=10)

    def test_cloud_attacks(self, retriever):
        _assert_source_in_results(retriever, "AWS SSRF metadata credential theft", "cloud-attacks-deep.md")

    def test_reverse_shell(self, retriever):
        _assert_source_in_results(retriever, "reverse shell bash netcat", "shells-arsenal-deep.md")


# ---------------------------------------------------------------------------
# BLUE mode — Defensive security
# ---------------------------------------------------------------------------

class TestRAGDefensive:
    def test_sigma_rules(self, retriever):
        _assert_source_in_results(retriever, "Sigma detection rule process creation", "sigma-detection-deep.md")

    def test_windows_event_logs(self, retriever):
        _assert_source_in_results(retriever, "Windows Event ID 4688 4624", "windows-eventlog-mastery.md")

    def test_siem_soc(self, retriever):
        _assert_source_in_results(retriever, "SIEM log management SOC analyst workflow Splunk", "siem-soc-deep.md", top_k=10)

    def test_hardening(self, retriever):
        _assert_source_in_results(retriever, "CIS benchmark Linux hardening sysctl", "hardening-guides-ultimate.md")

    def test_edr_internals(self, retriever):
        _assert_source_in_results(retriever, "EDR hooks AMSI bypass", "edr-av-internals-deep.md")


# ---------------------------------------------------------------------------
# INCIDENT mode
# ---------------------------------------------------------------------------

class TestRAGIncident:
    def test_ransomware_playbook(self, retriever):
        _assert_source_in_results(retriever, "ransomware incident response containment", "incident-playbooks-deep.md")

    def test_forensic_artifacts(self, retriever):
        _assert_source_in_results(retriever, "forensic artifacts MFT prefetch", "forensics-artifacts-deep.md")

    def test_memory_forensics(self, retriever):
        _assert_source_in_results(retriever, "Volatility memory analysis LSASS", "dfir-hunting-deep.md")


# ---------------------------------------------------------------------------
# PRIVACY mode
# ---------------------------------------------------------------------------

class TestRAGPrivacy:
    def test_gdpr(self, retriever):
        _assert_source_in_results(retriever, "GDPR breach notification Article 33", "privacy-regulations-deep.md")

    def test_privacy_engineering(self, retriever):
        _assert_source_in_results(retriever, "Privacy by Design data minimization DPIA", "privacy-engineering-deep.md")


# ---------------------------------------------------------------------------
# ARCHITECT mode
# ---------------------------------------------------------------------------

class TestRAGArchitect:
    def test_threat_modeling(self, retriever):
        _assert_source_in_results(retriever, "STRIDE threat model data flow diagram", "threat-modeling-arch-deep.md")

    def test_aws_security(self, retriever):
        _assert_source_in_results(retriever, "AWS IAM policy S3 bucket security", "aws-security-ultimate.md")

    def test_kubernetes(self, retriever):
        _assert_source_in_results(retriever, "Kubernetes container escape privileged pod RBAC abuse", "kubernetes-attacks-deep.md", top_k=10)

    def test_tls_crypto(self, retriever):
        _assert_source_in_results(retriever, "TLS 1.3 certificate pinning cipher suite", "crypto-pki-tls-deep.md")


# ---------------------------------------------------------------------------
# RECON mode
# ---------------------------------------------------------------------------

class TestRAGRecon:
    def test_osint(self, retriever):
        _assert_source_in_results(retriever, "OSINT subdomain enumeration passive recon", "recon-osint-deep.md")


# ---------------------------------------------------------------------------
# Cross-cutting domains
# ---------------------------------------------------------------------------

class TestRAGCrossCutting:
    def test_breach_case_studies(self, retriever):
        _assert_source_in_results(retriever, "SolarWinds supply chain breach SUNBURST", "breach-case-studies-deep.md")

    def test_ai_security(self, retriever):
        _assert_source_in_results(retriever, "LLM prompt injection adversarial AI abliteration", "ai-defense-deep.md")

    def test_windows_internals(self, retriever):
        _assert_source_in_results(retriever, "Windows token manipulation LSASS syscall", "windows-internals-deep.md")

    def test_emerging_threats(self, retriever):
        _assert_source_in_results(retriever, "ransomware as a service RaaS affiliate", "emerging-threats-deep.md")

    def test_vulnerability_research(self, retriever):
        _assert_source_in_results(retriever, "fuzzing AFL exploit development ROP chain", "vuln-research-deep.md")
