"""Shared pytest fixtures for CIPHER gateway tests."""
from __future__ import annotations

from pathlib import Path

import pytest
import yaml


# ---------------------------------------------------------------------------
# Bot / signalbot mock fixtures
# ---------------------------------------------------------------------------

class MockMessage:
    """Minimal stand-in for signalbot.Message."""

    def __init__(self, source: str, text: str, source_uuid: str | None = None, source_number: str | None = None) -> None:
        self.source = source
        self.source_uuid = source_uuid or source
        self.source_number = source_number
        self.text = text


class MockContext:
    """Minimal stand-in for signalbot.Context.

    Tracks all calls to send() and react() for assertion in tests.
    """

    def __init__(self, source: str, text: str) -> None:
        self.message = MockMessage(source=source, text=text)
        self.sent: list[str] = []
        self.reactions: list[str] = []

    async def send(self, text: str) -> None:  # noqa: D102
        self.sent.append(text)

    async def react(self, emoji: str) -> None:  # noqa: D102
        self.reactions.append(emoji)


@pytest.fixture()
def make_ctx():
    """Factory fixture: make_ctx(source, text) -> MockContext."""

    def _make(source: str = "+15551234567", text: str = "hello") -> MockContext:
        return MockContext(source=source, text=text)

    return _make


@pytest.fixture()
def sample_config_dict() -> dict:
    """Returns a dict matching the config.yaml.example structure with valid test values."""
    return {
        "llm_backend": "ollama",
        "ollama": {
            "base_url": "http://127.0.0.1:11434",
            "model": "llama3.1:8b",
            "timeout": 300,
        },
        "claude": {
            "api_key": "sk-ant-test-key",
            "model": "claude-sonnet-4-5",
            "timeout": 60,
        },
    }


@pytest.fixture()
def tmp_config(tmp_path: Path, sample_config_dict: dict):
    """
    Writes a temporary config.yaml with known values.
    Yields (config_path, config_dict). Cleans up automatically via tmp_path.
    """
    config_path = tmp_path / "config.yaml"
    with config_path.open("w") as f:
        yaml.safe_dump(sample_config_dict, f)
    yield config_path, sample_config_dict


@pytest.fixture()
def ollama_gateway_config(sample_config_dict):
    """Returns a GatewayConfig for the ollama backend."""
    from gateway.config import GatewayConfig

    d = sample_config_dict
    return GatewayConfig(
        backend=d["llm_backend"],
        ollama_base_url=d["ollama"]["base_url"],
        ollama_model=d["ollama"]["model"],
        ollama_timeout=d["ollama"]["timeout"],
        claude_api_key=d["claude"]["api_key"],
        claude_model=d["claude"]["model"],
        claude_timeout=d["claude"]["timeout"],
    )


@pytest.fixture()
def claude_gateway_config(sample_config_dict):
    """Returns a GatewayConfig for the claude backend."""
    from gateway.config import GatewayConfig

    d = sample_config_dict
    return GatewayConfig(
        backend="claude",
        ollama_base_url=d["ollama"]["base_url"],
        ollama_model=d["ollama"]["model"],
        ollama_timeout=d["ollama"]["timeout"],
        claude_api_key=d["claude"]["api_key"],
        claude_model=d["claude"]["model"],
        claude_timeout=d["claude"]["timeout"],
    )
