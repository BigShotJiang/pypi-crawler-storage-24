"""Tests for gateway.config — GatewayConfig, load_config, env substitution, redaction."""
from __future__ import annotations


import pytest
import yaml

from gateway.config import _substitute_env, redact_config


# ---------------------------------------------------------------------------
# GatewayConfig validation
# ---------------------------------------------------------------------------

def test_gateway_config_valid_ollama(sample_config_dict):
    from gateway.config import GatewayConfig

    d = sample_config_dict
    cfg = GatewayConfig(
        backend="ollama",
        ollama_base_url=d["ollama"]["base_url"],
        ollama_model=d["ollama"]["model"],
        ollama_timeout=d["ollama"]["timeout"],
        claude_api_key=d["claude"]["api_key"],
        claude_model=d["claude"]["model"],
        claude_timeout=d["claude"]["timeout"],
    )
    assert cfg.backend == "ollama"
    assert cfg.ollama_model == "llama3.1:8b"


def test_gateway_config_valid_claude(sample_config_dict):
    from gateway.config import GatewayConfig

    d = sample_config_dict
    cfg = GatewayConfig(
        backend="claude",
        ollama_base_url=d["ollama"]["base_url"],
        ollama_model=d["ollama"]["model"],
        ollama_timeout=d["ollama"]["timeout"],
        claude_api_key=d["claude"]["api_key"],
        claude_model=d["claude"]["model"],
        claude_timeout=d["claude"]["timeout"],
    )
    assert cfg.backend == "claude"
    assert cfg.claude_model == "claude-sonnet-4-5"


def test_gateway_config_invalid_backend(sample_config_dict):
    from gateway.config import GatewayConfig

    d = sample_config_dict
    with pytest.raises(ValueError, match="backend"):
        GatewayConfig(
            backend="gpt4",  # invalid
            ollama_base_url=d["ollama"]["base_url"],
            ollama_model=d["ollama"]["model"],
            ollama_timeout=d["ollama"]["timeout"],
            claude_api_key=d["claude"]["api_key"],
            claude_model=d["claude"]["model"],
            claude_timeout=d["claude"]["timeout"],
        )


def test_gateway_config_raises_on_empty_ollama_model(sample_config_dict):
    """Active backend's model must be non-empty."""
    from gateway.config import GatewayConfig

    d = sample_config_dict
    with pytest.raises(ValueError, match="ollama_model"):
        GatewayConfig(
            backend="ollama",
            ollama_base_url=d["ollama"]["base_url"],
            ollama_model="",  # empty — must raise
            ollama_timeout=d["ollama"]["timeout"],
            claude_api_key=d["claude"]["api_key"],
            claude_model=d["claude"]["model"],
            claude_timeout=d["claude"]["timeout"],
        )


def test_gateway_config_raises_on_empty_claude_model(sample_config_dict):
    """Active backend's model must be non-empty."""
    from gateway.config import GatewayConfig

    d = sample_config_dict
    with pytest.raises(ValueError, match="claude_model"):
        GatewayConfig(
            backend="claude",
            ollama_base_url=d["ollama"]["base_url"],
            ollama_model=d["ollama"]["model"],
            ollama_timeout=d["ollama"]["timeout"],
            claude_api_key=d["claude"]["api_key"],
            claude_model="",  # empty — must raise
            claude_timeout=d["claude"]["timeout"],
        )


def test_gateway_config_empty_inactive_model_ok(sample_config_dict):
    """Inactive backend's model can be empty."""
    from gateway.config import GatewayConfig

    d = sample_config_dict
    # backend=ollama, claude_model is empty — that's fine
    cfg = GatewayConfig(
        backend="ollama",
        ollama_base_url=d["ollama"]["base_url"],
        ollama_model=d["ollama"]["model"],
        ollama_timeout=d["ollama"]["timeout"],
        claude_api_key="",
        claude_model="",  # inactive backend — no error
        claude_timeout=d["claude"]["timeout"],
    )
    assert cfg.claude_model == ""


# ---------------------------------------------------------------------------
# load_config — project-root YAML
# ---------------------------------------------------------------------------

def test_load_config_from_project_root(tmp_config, monkeypatch):
    """load_config() with project-root config.yaml returns parsed values."""
    from gateway.config import load_config

    config_path, expected = tmp_config
    project_root = config_path.parent

    # Clear env overrides so they don't interfere
    monkeypatch.delenv("LLM_BACKEND", raising=False)
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)

    cfg = load_config(project_root=project_root)
    assert cfg.backend == expected["llm_backend"]
    assert cfg.ollama_base_url == expected["ollama"]["base_url"]
    assert cfg.ollama_model == expected["ollama"]["model"]
    assert cfg.ollama_timeout == expected["ollama"]["timeout"]
    assert cfg.claude_api_key == expected["claude"]["api_key"]
    assert cfg.claude_model == expected["claude"]["model"]
    assert cfg.claude_timeout == expected["claude"]["timeout"]


def test_load_config_from_home_config(tmp_path, monkeypatch, sample_config_dict):
    """load_config() falls back to ~/.config/cipher/config.yaml when no project-root config."""
    from gateway.config import load_config

    # Set up fake home dir with config
    fake_home = tmp_path / "home"
    config_dir = fake_home / ".config" / "cipher"
    config_dir.mkdir(parents=True)
    config_file = config_dir / "config.yaml"
    with config_file.open("w") as f:
        yaml.safe_dump(sample_config_dict, f)

    # Project root with no config.yaml
    empty_root = tmp_path / "project"
    empty_root.mkdir()

    monkeypatch.setenv("HOME", str(fake_home))
    monkeypatch.delenv("LLM_BACKEND", raising=False)
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)

    cfg = load_config(project_root=empty_root)
    assert cfg.backend == sample_config_dict["llm_backend"]
    assert cfg.ollama_model == sample_config_dict["ollama"]["model"]


# ---------------------------------------------------------------------------
# load_config — env var overrides
# ---------------------------------------------------------------------------

def test_env_llm_backend_overrides_yaml(tmp_config, monkeypatch):
    """env var LLM_BACKEND overrides YAML llm_backend."""
    from gateway.config import load_config

    config_path, _ = tmp_config
    project_root = config_path.parent

    # YAML says "ollama", but we override to "claude" via env
    # Need claude model set (it is, in the fixture)
    monkeypatch.setenv("LLM_BACKEND", "claude")
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)

    cfg = load_config(project_root=project_root)
    assert cfg.backend == "claude"


def test_env_anthropic_api_key_overrides_yaml(tmp_config, monkeypatch):
    """env var ANTHROPIC_API_KEY overrides YAML claude.api_key."""
    from gateway.config import load_config

    config_path, _ = tmp_config
    project_root = config_path.parent

    monkeypatch.delenv("LLM_BACKEND", raising=False)
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-override-key")

    cfg = load_config(project_root=project_root)
    assert cfg.claude_api_key == "sk-ant-override-key"


# ---------------------------------------------------------------------------
# Precedence: env vars > project-root > home config
# ---------------------------------------------------------------------------

def test_project_root_overrides_home_config(tmp_path, monkeypatch, sample_config_dict):
    """Project-root config.yaml wins over ~/.config/cipher/config.yaml."""
    from gateway.config import load_config

    # Home config — different model name
    fake_home = tmp_path / "home"
    config_dir = fake_home / ".config" / "cipher"
    config_dir.mkdir(parents=True)
    home_cfg = dict(sample_config_dict)
    home_cfg["ollama"] = dict(sample_config_dict["ollama"])
    home_cfg["ollama"]["model"] = "home-model"
    with (config_dir / "config.yaml").open("w") as f:
        yaml.safe_dump(home_cfg, f)

    # Project-root config — different model name (should win)
    project_root = tmp_path / "project"
    project_root.mkdir()
    project_cfg = dict(sample_config_dict)
    project_cfg["ollama"] = dict(sample_config_dict["ollama"])
    project_cfg["ollama"]["model"] = "project-model"
    with (project_root / "config.yaml").open("w") as f:
        yaml.safe_dump(project_cfg, f)

    monkeypatch.setenv("HOME", str(fake_home))
    monkeypatch.delenv("LLM_BACKEND", raising=False)
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)

    cfg = load_config(project_root=project_root)
    assert cfg.ollama_model == "project-model"


def test_env_overrides_project_root_config(tmp_config, monkeypatch):
    """env vars win over project-root config.yaml (env > project-root > home)."""
    from gateway.config import load_config

    config_path, _ = tmp_config
    project_root = config_path.parent

    monkeypatch.setenv("LLM_BACKEND", "claude")
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-env-wins")

    cfg = load_config(project_root=project_root)
    assert cfg.backend == "claude"
    assert cfg.claude_api_key == "sk-ant-env-wins"


# ---------------------------------------------------------------------------
# Environment variable substitution
# ---------------------------------------------------------------------------

class TestEnvSubstitution:
    def test_simple_var(self, monkeypatch):
        monkeypatch.setenv("TEST_VAR", "hello")
        assert _substitute_env("${TEST_VAR}") == "hello"

    def test_var_with_default(self):
        assert _substitute_env("${NONEXISTENT_VAR:-fallback}") == "fallback"

    def test_var_exists_ignores_default(self, monkeypatch):
        monkeypatch.setenv("EXISTS", "real")
        assert _substitute_env("${EXISTS:-fallback}") == "real"

    def test_nested_dict(self, monkeypatch):
        monkeypatch.setenv("MY_KEY", "secret123")
        result = _substitute_env({"api_key": "${MY_KEY}", "other": "plain"})
        assert result == {"api_key": "secret123", "other": "plain"}

    def test_nested_list(self, monkeypatch):
        monkeypatch.setenv("ITEM", "val")
        result = _substitute_env(["${ITEM}", "static"])
        assert result == ["val", "static"]

    def test_unresolved_kept(self):
        assert _substitute_env("${TOTALLY_MISSING}") == "${TOTALLY_MISSING}"

    def test_non_string_passthrough(self):
        assert _substitute_env(42) == 42
        assert _substitute_env(True) is True
        assert _substitute_env(None) is None

    def test_mixed_text(self, monkeypatch):
        monkeypatch.setenv("HOST", "localhost")
        assert _substitute_env("http://${HOST}:8080") == "http://localhost:8080"


# ---------------------------------------------------------------------------
# Secret redaction
# ---------------------------------------------------------------------------

class TestRedaction:
    def test_redacts_api_key(self):
        cfg = {"claude": {"api_key": "sk-ant-secret-123", "model": "opus"}}
        redacted = redact_config(cfg)
        assert redacted["claude"]["api_key"] == "***"
        assert redacted["claude"]["model"] == "opus"

    def test_redacts_token(self):
        cfg = {"auth": {"token": "my-secret-token"}}
        assert redact_config(cfg)["auth"]["token"] == "***"

    def test_preserves_non_secret(self):
        cfg = {"backend": "ollama", "model": "cipher"}
        assert redact_config(cfg) == cfg

    def test_empty_secret_not_redacted(self):
        cfg = {"api_key": ""}
        assert redact_config(cfg)["api_key"] == ""

    def test_nested_redaction(self):
        cfg = {"providers": {"anthropic": {"api_key": "sk-123"}, "ollama": {"base_url": "http://localhost"}}}
        r = redact_config(cfg)
        assert r["providers"]["anthropic"]["api_key"] == "***"
        assert r["providers"]["ollama"]["base_url"] == "http://localhost"
