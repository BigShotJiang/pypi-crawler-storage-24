"""Tests for API functions."""

import pytest
from pydantic import ValidationError

from ziptax.exceptions import ZipTaxCloudConfigError, ZipTaxValidationError
from ziptax.models import (
    CalculateCartRequest,
    CalculateCartResponse,
    CartAddress,
    CartCurrency,
    CartItem,
    CartLineItem,
    CreateOrderFromCartRequest,
    CreateOrderRequest,
    OrderResponse,
    ProductCodeRecommendationResponse,
    ProductCodeSearchResponse,
    RefundTransactionRequest,
    RefundTransactionResponse,
    TaxCloudCalculateCartResponse,
    UpdateOrderRequest,
    V60AccountMetrics,
    V60PostalCodeResponse,
    V60Response,
)
from ziptax.resources.functions import Functions


class TestGetSalesTaxByAddress:
    """Test cases for GetSalesTaxByAddress function."""

    def test_basic_request(self, mock_http_client, mock_config, sample_v60_response):
        """Test basic address request."""
        mock_http_client.get.return_value = sample_v60_response
        functions = Functions(mock_http_client, mock_config)

        response = functions.GetSalesTaxByAddress(
            "200 Spectrum Center Drive, Irvine, CA 92618"
        )

        assert isinstance(response, V60Response)
        assert response.metadata.version == "v60"
        assert response.metadata.response.code == 100
        mock_http_client.get.assert_called_once()

    def test_with_optional_parameters(
        self, mock_http_client, mock_config, sample_v60_response
    ):
        """Test request with optional parameters."""
        mock_http_client.get.return_value = sample_v60_response
        functions = Functions(mock_http_client, mock_config)

        response = functions.GetSalesTaxByAddress(
            address="200 Spectrum Center Drive, Irvine, CA 92618",
            taxability_code="12345",
            country_code="USA",
            historical="202401",
            format="json",
        )

        assert isinstance(response, V60Response)
        call_args = mock_http_client.get.call_args
        assert (
            call_args[1]["params"]["address"]
            == "200 Spectrum Center Drive, Irvine, CA 92618"
        )
        assert call_args[1]["params"]["taxabilityCode"] == "12345"
        assert call_args[1]["params"]["historical"] == "202401"

    def test_empty_address_validation(self, mock_http_client, mock_config):
        """Test validation of empty address."""
        functions = Functions(mock_http_client, mock_config)

        with pytest.raises(ZipTaxValidationError, match="Address cannot be empty"):
            functions.GetSalesTaxByAddress("")

    def test_address_too_long_validation(self, mock_http_client, mock_config):
        """Test validation of address length."""
        functions = Functions(mock_http_client, mock_config)
        long_address = "a" * 101

        with pytest.raises(ZipTaxValidationError, match="cannot exceed 100 characters"):
            functions.GetSalesTaxByAddress(long_address)

    def test_invalid_country_code(self, mock_http_client, mock_config):
        """Test validation of country code."""
        functions = Functions(mock_http_client, mock_config)

        with pytest.raises(ZipTaxValidationError, match="Country code must be one of"):
            functions.GetSalesTaxByAddress(
                "200 Spectrum Center Drive",
                country_code="INVALID",
            )

    def test_invalid_historical_format(self, mock_http_client, mock_config):
        """Test validation of historical date format."""
        functions = Functions(mock_http_client, mock_config)

        with pytest.raises(ZipTaxValidationError, match="must be in YYYYMM format"):
            functions.GetSalesTaxByAddress(
                "200 Spectrum Center Drive",
                historical="2024-13-01",
            )


class TestGetSalesTaxByGeoLocation:
    """Test cases for GetSalesTaxByGeoLocation function."""

    def test_basic_request(self, mock_http_client, mock_config, sample_v60_response):
        """Test basic geolocation request."""
        mock_http_client.get.return_value = sample_v60_response
        functions = Functions(mock_http_client, mock_config)

        response = functions.GetSalesTaxByGeoLocation(
            lat="33.6489",
            lng="-117.8386",
        )

        assert isinstance(response, V60Response)
        assert response.metadata.version == "v60"
        assert response.metadata.response.code == 100
        mock_http_client.get.assert_called_once()

    def test_with_optional_parameters(
        self, mock_http_client, mock_config, sample_v60_response
    ):
        """Test request with optional parameters."""
        mock_http_client.get.return_value = sample_v60_response
        functions = Functions(mock_http_client, mock_config)

        response = functions.GetSalesTaxByGeoLocation(
            lat="33.6489",
            lng="-117.8386",
            country_code="USA",
            historical="202401",
            format="json",
        )

        assert isinstance(response, V60Response)
        call_args = mock_http_client.get.call_args
        assert call_args[1]["params"]["lat"] == "33.6489"
        assert call_args[1]["params"]["lng"] == "-117.8386"

    def test_empty_coordinates_validation(self, mock_http_client, mock_config):
        """Test validation of empty coordinates."""
        functions = Functions(mock_http_client, mock_config)

        with pytest.raises(ZipTaxValidationError, match="cannot be empty"):
            functions.GetSalesTaxByGeoLocation(lat="", lng="")

    def test_invalid_latitude_range(self, mock_http_client, mock_config):
        """Test validation of latitude range."""
        functions = Functions(mock_http_client, mock_config)

        with pytest.raises(ZipTaxValidationError, match="Latitude must be between"):
            functions.GetSalesTaxByGeoLocation(lat="100.0", lng="-117.8386")

    def test_invalid_longitude_range(self, mock_http_client, mock_config):
        """Test validation of longitude range."""
        functions = Functions(mock_http_client, mock_config)

        with pytest.raises(ZipTaxValidationError, match="Longitude must be between"):
            functions.GetSalesTaxByGeoLocation(lat="33.6489", lng="200.0")

    def test_invalid_coordinate_format(self, mock_http_client, mock_config):
        """Test validation of coordinate format."""
        functions = Functions(mock_http_client, mock_config)

        with pytest.raises(ZipTaxValidationError, match="must be valid numbers"):
            functions.GetSalesTaxByGeoLocation(lat="invalid", lng="-117.8386")


class TestGetAccountMetrics:
    """Test cases for GetAccountMetrics function."""

    def test_basic_request(self, mock_http_client, mock_config, sample_account_metrics):
        """Test basic account metrics request."""
        mock_http_client.get.return_value = sample_account_metrics
        functions = Functions(mock_http_client, mock_config)

        response = functions.GetAccountMetrics()

        assert isinstance(response, V60AccountMetrics)
        assert response.request_count == 15595
        assert response.is_active is True
        mock_http_client.get.assert_called_once()

    def test_with_key_parameter(
        self, mock_http_client, mock_config, sample_account_metrics
    ):
        """Test request with key parameter."""
        mock_http_client.get.return_value = sample_account_metrics
        functions = Functions(mock_http_client, mock_config)

        response = functions.GetAccountMetrics(key="test-key")

        assert isinstance(response, V60AccountMetrics)
        call_args = mock_http_client.get.call_args
        assert call_args[1]["params"]["key"] == "test-key"

    def test_response_fields(
        self, mock_http_client, mock_config, sample_account_metrics
    ):
        """Test all response fields are properly parsed."""
        mock_http_client.get.return_value = sample_account_metrics
        functions = Functions(mock_http_client, mock_config)

        response = functions.GetAccountMetrics()

        assert response.request_count == 15595
        assert response.request_limit == 1000000
        assert response.usage_percent == 1.5595
        assert response.is_active is True
        assert "support@zip.tax" in response.message

    def test_core_prefixed_fields(self, mock_http_client, mock_config):
        """Test that core_* prefixed fields are accepted as aliases."""
        mock_http_client.get.return_value = {
            "core_request_count": 500,
            "core_request_limit": 10000,
            "core_usage_percent": 5.0,
            "is_active": True,
            "message": "OK",
        }
        functions = Functions(mock_http_client, mock_config)

        response = functions.GetAccountMetrics()

        assert isinstance(response, V60AccountMetrics)
        assert response.request_count == 500
        assert response.request_limit == 10000
        assert response.usage_percent == 5.0

    def test_geo_prefixed_fields(self, mock_http_client, mock_config):
        """Test that geo_* prefixed fields are accepted as aliases."""
        mock_http_client.get.return_value = {
            "geo_request_count": 200,
            "geo_request_limit": 5000,
            "geo_usage_percent": 4.0,
            "is_active": True,
            "message": "OK",
        }
        functions = Functions(mock_http_client, mock_config)

        response = functions.GetAccountMetrics()

        assert isinstance(response, V60AccountMetrics)
        assert response.request_count == 200
        assert response.request_limit == 5000
        assert response.usage_percent == 4.0

    def test_flat_fields_take_priority(self, mock_http_client, mock_config):
        """Test that flat fields are preferred when both flat and prefixed exist."""
        mock_http_client.get.return_value = {
            "request_count": 999,
            "core_request_count": 111,
            "request_limit": 50000,
            "core_request_limit": 11111,
            "usage_percent": 2.0,
            "core_usage_percent": 1.0,
            "is_active": True,
            "message": "OK",
        }
        functions = Functions(mock_http_client, mock_config)

        response = functions.GetAccountMetrics()

        assert isinstance(response, V60AccountMetrics)
        assert response.request_count == 999
        assert response.request_limit == 50000
        assert response.usage_percent == 2.0


class TestGetRatesByPostalCode:
    """Test cases for GetRatesByPostalCode function."""

    def test_basic_request(
        self, mock_http_client, mock_config, sample_postal_code_response
    ):
        """Test basic postal code request."""
        mock_http_client.get.return_value = sample_postal_code_response
        functions = Functions(mock_http_client, mock_config)

        response = functions.GetRatesByPostalCode("92694")

        assert isinstance(response, V60PostalCodeResponse)
        assert response.version == "v60"
        assert response.r_code == 100
        assert len(response.results) == 1
        assert response.results[0].geo_postal_code == "92694"
        mock_http_client.get.assert_called_once()

    def test_with_format_parameter(
        self, mock_http_client, mock_config, sample_postal_code_response
    ):
        """Test request with format parameter."""
        mock_http_client.get.return_value = sample_postal_code_response
        functions = Functions(mock_http_client, mock_config)

        response = functions.GetRatesByPostalCode(postal_code="92694", format="json")

        assert isinstance(response, V60PostalCodeResponse)
        call_args = mock_http_client.get.call_args
        assert call_args[1]["params"]["postalcode"] == "92694"
        assert call_args[1]["params"]["format"] == "json"

    def test_invalid_postal_code(self, mock_http_client, mock_config):
        """Test validation of invalid postal code."""
        functions = Functions(mock_http_client, mock_config)

        with pytest.raises(ZipTaxValidationError, match="Postal code must be"):
            functions.GetRatesByPostalCode("invalid")

    def test_nine_digit_postal_code_rejected(self, mock_http_client, mock_config):
        """Test that 9-digit postal codes are rejected (API does not accept them)."""
        functions = Functions(mock_http_client, mock_config)

        with pytest.raises(ZipTaxValidationError, match="Postal code must be"):
            functions.GetRatesByPostalCode("92694-1234")

    def test_empty_postal_code(self, mock_http_client, mock_config):
        """Test validation of empty postal code."""
        functions = Functions(mock_http_client, mock_config)

        with pytest.raises(ZipTaxValidationError, match="Postal code cannot be empty"):
            functions.GetRatesByPostalCode("")

    def test_response_fields(
        self, mock_http_client, mock_config, sample_postal_code_response
    ):
        """Test all response fields are properly parsed."""
        mock_http_client.get.return_value = sample_postal_code_response
        functions = Functions(mock_http_client, mock_config)

        response = functions.GetRatesByPostalCode("92694")
        result = response.results[0]

        assert result.geo_city == "LADERA RANCH"
        assert result.geo_county == "ORANGE"
        assert result.geo_state == "CA"
        assert result.tax_sales == 0.0775
        assert result.tax_use == 0.0775


class TestSearchProductCodes:
    """Test cases for SearchProductCodes function."""

    def test_basic_request(
        self,
        mock_http_client,
        mock_config,
        sample_product_code_search_response,
    ):
        """Test basic product code search request."""
        mock_http_client.post.return_value = sample_product_code_search_response
        functions = Functions(mock_http_client, mock_config)

        response = functions.SearchProductCodes("baked goods sold in plastic packaging")

        assert isinstance(response, ProductCodeSearchResponse)
        assert response.query == "baked goods sold in plastic packaging"
        assert len(response.results) == 2
        mock_http_client.post.assert_called_once()

    def test_uses_correct_path(
        self,
        mock_http_client,
        mock_config,
        sample_product_code_search_response,
    ):
        """Test that SearchProductCodes calls the correct API path."""
        mock_http_client.post.return_value = sample_product_code_search_response
        functions = Functions(mock_http_client, mock_config)

        functions.SearchProductCodes("test query")

        call_args = mock_http_client.post.call_args
        assert call_args[0][0] == "/search/tic"

    def test_request_body(
        self,
        mock_http_client,
        mock_config,
        sample_product_code_search_response,
    ):
        """Test that request body contains the query."""
        mock_http_client.post.return_value = sample_product_code_search_response
        functions = Functions(mock_http_client, mock_config)

        functions.SearchProductCodes("baked goods")

        call_args = mock_http_client.post.call_args
        json_body = call_args[1]["json"]
        assert json_body == {"query": "baked goods"}

    def test_result_fields_parsed(
        self,
        mock_http_client,
        mock_config,
        sample_product_code_search_response,
    ):
        """Test that result fields are properly parsed with correct types."""
        mock_http_client.post.return_value = sample_product_code_search_response
        functions = Functions(mock_http_client, mock_config)

        response = functions.SearchProductCodes("test")

        result = response.results[0]
        assert result.tic_id == 41030
        assert isinstance(result.tic_id, int)
        assert result.label == "Bakery Items"
        assert result.natural_label == "Bakery Items"
        assert "Bakery items" in result.description
        assert "Bakery items" in result.documentation
        assert result.rank == 1
        assert isinstance(result.rank, int)
        assert result.score == 0.891025641025641
        assert isinstance(result.score, float)

    def test_multiple_results_parsed(
        self,
        mock_http_client,
        mock_config,
        sample_product_code_search_response,
    ):
        """Test that multiple results are properly parsed."""
        mock_http_client.post.return_value = sample_product_code_search_response
        functions = Functions(mock_http_client, mock_config)

        response = functions.SearchProductCodes("test")

        assert len(response.results) == 2
        assert response.results[0].tic_id == 41030
        assert response.results[0].rank == 1
        assert response.results[1].tic_id == 40030
        assert response.results[1].rank == 2

    def test_empty_query_validation(self, mock_http_client, mock_config):
        """Test validation of empty query."""
        functions = Functions(mock_http_client, mock_config)

        with pytest.raises(ZipTaxValidationError, match="cannot be empty"):
            functions.SearchProductCodes("")

    def test_whitespace_only_query_validation(self, mock_http_client, mock_config):
        """Test validation of whitespace-only query."""
        functions = Functions(mock_http_client, mock_config)

        with pytest.raises(ZipTaxValidationError, match="cannot be empty"):
            functions.SearchProductCodes("   ")

    @pytest.mark.parametrize(
        "invalid_query", [None, 123, 12.34, ["list"], {"dict": "val"}]
    )
    def test_non_string_query_validation(
        self, mock_http_client, mock_config, invalid_query
    ):
        """Test validation of non-string query values."""
        functions = Functions(mock_http_client, mock_config)

        with pytest.raises(ZipTaxValidationError, match="must be a string"):
            functions.SearchProductCodes(invalid_query)

    def test_empty_results_list(self, mock_http_client, mock_config):
        """Test handling of empty results from API."""
        mock_http_client.post.return_value = {
            "query": "nonexistent product xyz",
            "results": [],
        }
        functions = Functions(mock_http_client, mock_config)

        response = functions.SearchProductCodes("nonexistent product xyz")

        assert isinstance(response, ProductCodeSearchResponse)
        assert response.query == "nonexistent product xyz"
        assert len(response.results) == 0


class TestRecommendProductCode:
    """Test cases for RecommendProductCode function."""

    def test_basic_request(
        self,
        mock_http_client,
        mock_config,
        sample_product_code_recommendation_response,
    ):
        """Test basic product code recommendation request."""
        mock_http_client.post.return_value = sample_product_code_recommendation_response
        functions = Functions(mock_http_client, mock_config)

        response = functions.RecommendProductCode(
            "baked goods sold in plastic packaging"
        )

        assert isinstance(response, ProductCodeRecommendationResponse)
        assert len(response.predictions) == 1
        mock_http_client.post.assert_called_once()

    def test_uses_correct_path(
        self,
        mock_http_client,
        mock_config,
        sample_product_code_recommendation_response,
    ):
        """Test that RecommendProductCode calls the correct API path."""
        mock_http_client.post.return_value = sample_product_code_recommendation_response
        functions = Functions(mock_http_client, mock_config)

        functions.RecommendProductCode("test query")

        call_args = mock_http_client.post.call_args
        assert call_args[0][0] == "/search/tic/recommend"

    def test_request_body(
        self,
        mock_http_client,
        mock_config,
        sample_product_code_recommendation_response,
    ):
        """Test that request body contains the query."""
        mock_http_client.post.return_value = sample_product_code_recommendation_response
        functions = Functions(mock_http_client, mock_config)

        functions.RecommendProductCode("baked goods")

        call_args = mock_http_client.post.call_args
        json_body = call_args[1]["json"]
        assert json_body == {"query": "baked goods"}

    def test_prediction_fields_parsed(
        self,
        mock_http_client,
        mock_config,
        sample_product_code_recommendation_response,
    ):
        """Test that prediction fields are properly parsed with correct types."""
        mock_http_client.post.return_value = sample_product_code_recommendation_response
        functions = Functions(mock_http_client, mock_config)

        response = functions.RecommendProductCode("test")

        prediction = response.predictions[0]
        assert prediction.status == "success"
        assert prediction.error is None
        assert prediction.tic_id == 41030
        assert isinstance(prediction.tic_id, int)
        assert prediction.label == "Bakery Items"
        assert prediction.natural_label == "Bakery Items"
        assert "Bakery items" in prediction.tic_description
        assert prediction.product_description == (
            "baked goods sold in plastic packaging"
        )

    def test_empty_query_validation(self, mock_http_client, mock_config):
        """Test validation of empty query."""
        functions = Functions(mock_http_client, mock_config)

        with pytest.raises(ZipTaxValidationError, match="cannot be empty"):
            functions.RecommendProductCode("")

    def test_whitespace_only_query_validation(self, mock_http_client, mock_config):
        """Test validation of whitespace-only query."""
        functions = Functions(mock_http_client, mock_config)

        with pytest.raises(ZipTaxValidationError, match="cannot be empty"):
            functions.RecommendProductCode("   ")

    @pytest.mark.parametrize(
        "invalid_query", [None, 123, 12.34, ["list"], {"dict": "val"}]
    )
    def test_non_string_query_validation(
        self, mock_http_client, mock_config, invalid_query
    ):
        """Test validation of non-string query values."""
        functions = Functions(mock_http_client, mock_config)

        with pytest.raises(ZipTaxValidationError, match="must be a string"):
            functions.RecommendProductCode(invalid_query)

    def test_prediction_with_error(self, mock_http_client, mock_config):
        """Test handling of a prediction with error status."""
        mock_http_client.post.return_value = {
            "predictions": [
                {
                    "status": "fail",
                    "error": "Unable to determine product code",
                    "ticId": "0",
                    "label": "",
                    "naturalLabel": "",
                    "tic_description": "",
                    "product_description": "ambiguous product",
                }
            ]
        }
        functions = Functions(mock_http_client, mock_config)

        response = functions.RecommendProductCode("ambiguous product")

        assert isinstance(response, ProductCodeRecommendationResponse)
        prediction = response.predictions[0]
        assert prediction.status == "fail"
        assert prediction.error == "Unable to determine product code"
        assert prediction.tic_id == 0


class TestCalculateCart:
    """Test cases for CalculateCart function."""

    def _build_request(self):
        """Build a sample CalculateCartRequest for testing."""
        return CalculateCartRequest(
            items=[
                CartItem(
                    customer_id="customer-453",
                    currency=CartCurrency(currency_code="USD"),
                    destination=CartAddress(
                        address="200 Spectrum Center Dr, Irvine, CA 92618-1905"
                    ),
                    origin=CartAddress(
                        address="323 Washington Ave N, Minneapolis, MN 55401-2427"
                    ),
                    line_items=[
                        CartLineItem(
                            item_id="item-1",
                            price=10.75,
                            quantity=1.5,
                        ),
                        CartLineItem(
                            item_id="item-2",
                            price=25.00,
                            quantity=2.0,
                            taxability_code=0,
                        ),
                    ],
                )
            ]
        )

    def test_basic_request(
        self,
        mock_http_client,
        mock_config,
        sample_calculate_cart_response,
    ):
        """Test basic cart tax calculation request."""
        mock_http_client.post.return_value = sample_calculate_cart_response
        functions = Functions(mock_http_client, mock_config)

        request = self._build_request()
        response = functions.CalculateCart(request)

        assert isinstance(response, CalculateCartResponse)
        assert len(response.items) == 1
        assert response.items[0].cart_id == "ce4a1234-5678-90ab-cdef-1234567890ab"
        assert response.items[0].customer_id == "customer-453"
        mock_http_client.post.assert_called_once()

    def test_request_uses_correct_path(
        self,
        mock_http_client,
        mock_config,
        sample_calculate_cart_response,
    ):
        """Test that CalculateCart calls the correct API path."""
        mock_http_client.post.return_value = sample_calculate_cart_response
        functions = Functions(mock_http_client, mock_config)

        request = self._build_request()
        functions.CalculateCart(request)

        call_args = mock_http_client.post.call_args
        assert call_args[0][0] == "/calculate/cart"

    def test_request_body_serialization(
        self,
        mock_http_client,
        mock_config,
        sample_calculate_cart_response,
    ):
        """Test that request body uses camelCase field names (by_alias)."""
        mock_http_client.post.return_value = sample_calculate_cart_response
        functions = Functions(mock_http_client, mock_config)

        request = self._build_request()
        functions.CalculateCart(request)

        call_args = mock_http_client.post.call_args
        json_body = call_args[1]["json"]

        # Verify top-level structure
        assert "items" in json_body
        assert len(json_body["items"]) == 1

        cart = json_body["items"][0]
        # Verify camelCase aliases are used
        assert "customerId" in cart
        assert cart["customerId"] == "customer-453"
        assert "lineItems" in cart
        assert len(cart["lineItems"]) == 2

        # Verify line item serialization
        line_item = cart["lineItems"][0]
        assert "itemId" in line_item
        assert line_item["itemId"] == "item-1"
        assert line_item["price"] == 10.75
        assert line_item["quantity"] == 1.5

    def test_optional_taxability_code_excluded_when_none(
        self,
        mock_http_client,
        mock_config,
        sample_calculate_cart_response,
    ):
        """Test that taxabilityCode is excluded from JSON when not set."""
        mock_http_client.post.return_value = sample_calculate_cart_response
        functions = Functions(mock_http_client, mock_config)

        request = CalculateCartRequest(
            items=[
                CartItem(
                    customer_id="cust-1",
                    currency=CartCurrency(currency_code="USD"),
                    destination=CartAddress(
                        address="200 Spectrum Center Dr, Irvine, CA 92618"
                    ),
                    origin=CartAddress(
                        address="323 Washington Ave N, Minneapolis, MN 55401"
                    ),
                    line_items=[
                        CartLineItem(
                            item_id="item-1",
                            price=10.00,
                            quantity=1.0,
                        )
                    ],
                )
            ]
        )
        functions.CalculateCart(request)

        call_args = mock_http_client.post.call_args
        json_body = call_args[1]["json"]
        line_item = json_body["items"][0]["lineItems"][0]
        assert "taxabilityCode" not in line_item

    def test_optional_taxability_code_included_when_set(
        self,
        mock_http_client,
        mock_config,
        sample_calculate_cart_response,
    ):
        """Test that taxabilityCode is included in JSON when set."""
        mock_http_client.post.return_value = sample_calculate_cart_response
        functions = Functions(mock_http_client, mock_config)

        request = self._build_request()
        functions.CalculateCart(request)

        call_args = mock_http_client.post.call_args
        json_body = call_args[1]["json"]
        # Second line item has taxability_code=0
        line_item = json_body["items"][0]["lineItems"][1]
        assert "taxabilityCode" in line_item
        assert line_item["taxabilityCode"] == 0

    def test_response_line_items_parsed(
        self,
        mock_http_client,
        mock_config,
        sample_calculate_cart_response,
    ):
        """Test that response line items and tax details are properly parsed."""
        mock_http_client.post.return_value = sample_calculate_cart_response
        functions = Functions(mock_http_client, mock_config)

        request = self._build_request()
        response = functions.CalculateCart(request)

        cart = response.items[0]
        assert len(cart.line_items) == 2

        # First line item
        item1 = cart.line_items[0]
        assert item1.item_id == "item-1"
        assert item1.price == 10.75
        assert item1.quantity == 1.5
        assert item1.tax.rate == 0.09025
        assert item1.tax.amount == 1.45528

        # Second line item
        item2 = cart.line_items[1]
        assert item2.item_id == "item-2"
        assert item2.price == 25.00
        assert item2.quantity == 2.0
        assert item2.tax.rate == 0.09025
        assert item2.tax.amount == 4.5125

    def test_response_addresses_parsed(
        self,
        mock_http_client,
        mock_config,
        sample_calculate_cart_response,
    ):
        """Test that response addresses are properly parsed."""
        mock_http_client.post.return_value = sample_calculate_cart_response
        functions = Functions(mock_http_client, mock_config)

        request = self._build_request()
        response = functions.CalculateCart(request)

        cart = response.items[0]
        assert (
            cart.destination.address == "200 Spectrum Center Dr, Irvine, CA 92618-1905"
        )
        assert cart.origin.address == "323 Washington Ave N, Minneapolis, MN 55401-2427"

    # ----- Pydantic Validation Tests -----

    def test_price_must_be_greater_than_zero(self):
        """Test that CartLineItem rejects price <= 0."""
        with pytest.raises(ValidationError, match="greater than 0"):
            CartLineItem(item_id="item-1", price=0, quantity=1.0)

        with pytest.raises(ValidationError, match="greater than 0"):
            CartLineItem(item_id="item-1", price=-5.00, quantity=1.0)

    def test_quantity_must_be_greater_than_zero(self):
        """Test that CartLineItem rejects quantity <= 0."""
        with pytest.raises(ValidationError, match="greater than 0"):
            CartLineItem(item_id="item-1", price=10.00, quantity=0)

        with pytest.raises(ValidationError, match="greater than 0"):
            CartLineItem(item_id="item-1", price=10.00, quantity=-1.0)

    def test_items_must_contain_exactly_one_cart(self):
        """Test that CalculateCartRequest rejects empty or multi-cart arrays."""
        with pytest.raises(ValidationError, match="too_short"):
            CalculateCartRequest(items=[])

        cart = CartItem(
            customer_id="cust-1",
            currency=CartCurrency(currency_code="USD"),
            destination=CartAddress(address="123 Main St"),
            origin=CartAddress(address="456 Other St"),
            line_items=[CartLineItem(item_id="item-1", price=10.00, quantity=1.0)],
        )
        with pytest.raises(ValidationError, match="too_long"):
            CalculateCartRequest(items=[cart, cart])

    def test_line_items_must_have_at_least_one(self):
        """Test that CartItem rejects empty line_items."""
        with pytest.raises(ValidationError, match="too_short"):
            CartItem(
                customer_id="cust-1",
                currency=CartCurrency(currency_code="USD"),
                destination=CartAddress(address="123 Main St"),
                origin=CartAddress(address="456 Other St"),
                line_items=[],
            )

    def test_currency_code_must_be_usd(self):
        """Test that CartCurrency rejects non-USD currency codes."""
        with pytest.raises(ValidationError, match="literal_error"):
            CartCurrency(currency_code="EUR")


class TestCalculateCartTaxCloudRouting:
    """Test cases for CalculateCart TaxCloud routing."""

    def _build_request(self):
        """Build a sample CalculateCartRequest for testing."""
        return CalculateCartRequest(
            items=[
                CartItem(
                    customer_id="customer-453",
                    currency=CartCurrency(currency_code="USD"),
                    destination=CartAddress(
                        address="200 Spectrum Center Dr, Irvine, CA 92618-1905"
                    ),
                    origin=CartAddress(
                        address="323 Washington Ave N, Minneapolis, MN 55401-2427"
                    ),
                    line_items=[
                        CartLineItem(
                            item_id="item-1",
                            price=10.75,
                            quantity=1.5,
                        ),
                        CartLineItem(
                            item_id="item-2",
                            price=25.00,
                            quantity=2.0,
                            taxability_code=0,
                        ),
                    ],
                )
            ]
        )

    # ----- Routing Logic Tests -----

    def test_routes_to_ziptax_without_taxcloud_config(
        self,
        mock_http_client,
        mock_config,
        sample_calculate_cart_response,
    ):
        """Test that CalculateCart routes to ZipTax when TaxCloud is not configured."""
        mock_http_client.post.return_value = sample_calculate_cart_response
        functions = Functions(mock_http_client, mock_config)

        request = self._build_request()
        response = functions.CalculateCart(request)

        assert isinstance(response, CalculateCartResponse)
        mock_http_client.post.assert_called_once()
        call_args = mock_http_client.post.call_args
        assert call_args[0][0] == "/calculate/cart"

    def test_routes_to_taxcloud_with_taxcloud_config(
        self,
        mock_http_client,
        mock_taxcloud_config,
        mock_taxcloud_http_client,
        sample_taxcloud_calculate_cart_response,
    ):
        """Test that CalculateCart routes to TaxCloud when configured."""
        mock_taxcloud_http_client.post.return_value = (
            sample_taxcloud_calculate_cart_response
        )
        functions = Functions(
            mock_http_client,
            mock_taxcloud_config,
            taxcloud_http_client=mock_taxcloud_http_client,
        )

        request = self._build_request()
        response = functions.CalculateCart(request)

        assert isinstance(response, TaxCloudCalculateCartResponse)
        mock_taxcloud_http_client.post.assert_called_once()
        # ZipTax http_client should NOT be called
        mock_http_client.post.assert_not_called()

    def test_taxcloud_uses_correct_path(
        self,
        mock_http_client,
        mock_taxcloud_config,
        mock_taxcloud_http_client,
        sample_taxcloud_calculate_cart_response,
    ):
        """Test that TaxCloud route uses the correct API path with connectionId."""
        mock_taxcloud_http_client.post.return_value = (
            sample_taxcloud_calculate_cart_response
        )
        functions = Functions(
            mock_http_client,
            mock_taxcloud_config,
            taxcloud_http_client=mock_taxcloud_http_client,
        )

        request = self._build_request()
        functions.CalculateCart(request)

        call_args = mock_taxcloud_http_client.post.call_args
        assert call_args[0][0] == "/tax/connections/test-connection-id-uuid/carts"

    # ----- Request Transformation Tests -----

    def test_address_parsing_destination(
        self,
        mock_http_client,
        mock_taxcloud_config,
        mock_taxcloud_http_client,
        sample_taxcloud_calculate_cart_response,
    ):
        """Test that destination address is parsed into structured components."""
        mock_taxcloud_http_client.post.return_value = (
            sample_taxcloud_calculate_cart_response
        )
        functions = Functions(
            mock_http_client,
            mock_taxcloud_config,
            taxcloud_http_client=mock_taxcloud_http_client,
        )

        request = self._build_request()
        functions.CalculateCart(request)

        call_args = mock_taxcloud_http_client.post.call_args
        json_body = call_args[1]["json"]
        dest = json_body["items"][0]["destination"]
        assert dest["line1"] == "200 Spectrum Center Dr"
        assert dest["city"] == "Irvine"
        assert dest["state"] == "CA"
        assert dest["zip"] == "92618-1905"

    def test_address_parsing_origin(
        self,
        mock_http_client,
        mock_taxcloud_config,
        mock_taxcloud_http_client,
        sample_taxcloud_calculate_cart_response,
    ):
        """Test that origin address is parsed into structured components."""
        mock_taxcloud_http_client.post.return_value = (
            sample_taxcloud_calculate_cart_response
        )
        functions = Functions(
            mock_http_client,
            mock_taxcloud_config,
            taxcloud_http_client=mock_taxcloud_http_client,
        )

        request = self._build_request()
        functions.CalculateCart(request)

        call_args = mock_taxcloud_http_client.post.call_args
        json_body = call_args[1]["json"]
        origin = json_body["items"][0]["origin"]
        assert origin["line1"] == "323 Washington Ave N"
        assert origin["city"] == "Minneapolis"
        assert origin["state"] == "MN"
        assert origin["zip"] == "55401-2427"

    def test_line_items_have_index(
        self,
        mock_http_client,
        mock_taxcloud_config,
        mock_taxcloud_http_client,
        sample_taxcloud_calculate_cart_response,
    ):
        """Test that line items get 0-based index added."""
        mock_taxcloud_http_client.post.return_value = (
            sample_taxcloud_calculate_cart_response
        )
        functions = Functions(
            mock_http_client,
            mock_taxcloud_config,
            taxcloud_http_client=mock_taxcloud_http_client,
        )

        request = self._build_request()
        functions.CalculateCart(request)

        call_args = mock_taxcloud_http_client.post.call_args
        json_body = call_args[1]["json"]
        line_items = json_body["items"][0]["lineItems"]
        assert line_items[0]["index"] == 0
        assert line_items[1]["index"] == 1

    def test_taxability_code_mapped_to_tic(
        self,
        mock_http_client,
        mock_taxcloud_config,
        mock_taxcloud_http_client,
        sample_taxcloud_calculate_cart_response,
    ):
        """Test that taxabilityCode is mapped to tic field."""
        mock_taxcloud_http_client.post.return_value = (
            sample_taxcloud_calculate_cart_response
        )
        functions = Functions(
            mock_http_client,
            mock_taxcloud_config,
            taxcloud_http_client=mock_taxcloud_http_client,
        )

        request = self._build_request()
        functions.CalculateCart(request)

        call_args = mock_taxcloud_http_client.post.call_args
        json_body = call_args[1]["json"]
        line_items = json_body["items"][0]["lineItems"]
        # item-1 has no taxability_code -> tic defaults to 0
        assert line_items[0]["tic"] == 0
        # item-2 has taxability_code=0 -> tic is 0
        assert line_items[1]["tic"] == 0

    def test_taxability_code_nonzero_mapped_to_tic(
        self,
        mock_http_client,
        mock_taxcloud_config,
        mock_taxcloud_http_client,
        sample_taxcloud_calculate_cart_response,
    ):
        """Test that a non-zero taxabilityCode is passed through to tic."""
        mock_taxcloud_http_client.post.return_value = (
            sample_taxcloud_calculate_cart_response
        )
        functions = Functions(
            mock_http_client,
            mock_taxcloud_config,
            taxcloud_http_client=mock_taxcloud_http_client,
        )

        request = CalculateCartRequest(
            items=[
                CartItem(
                    customer_id="cust-1",
                    currency=CartCurrency(currency_code="USD"),
                    destination=CartAddress(
                        address="200 Spectrum Center Dr, Irvine, CA 92618"
                    ),
                    origin=CartAddress(
                        address="323 Washington Ave N, Minneapolis, MN 55401"
                    ),
                    line_items=[
                        CartLineItem(
                            item_id="item-1",
                            price=10.00,
                            quantity=1.0,
                            taxability_code=31000,
                        )
                    ],
                )
            ]
        )
        functions.CalculateCart(request)

        call_args = mock_taxcloud_http_client.post.call_args
        json_body = call_args[1]["json"]
        assert json_body["items"][0]["lineItems"][0]["tic"] == 31000

    def test_currency_code_passed_through(
        self,
        mock_http_client,
        mock_taxcloud_config,
        mock_taxcloud_http_client,
        sample_taxcloud_calculate_cart_response,
    ):
        """Test that currency code is passed through to TaxCloud."""
        mock_taxcloud_http_client.post.return_value = (
            sample_taxcloud_calculate_cart_response
        )
        functions = Functions(
            mock_http_client,
            mock_taxcloud_config,
            taxcloud_http_client=mock_taxcloud_http_client,
        )

        request = self._build_request()
        functions.CalculateCart(request)

        call_args = mock_taxcloud_http_client.post.call_args
        json_body = call_args[1]["json"]
        assert json_body["items"][0]["currency"]["currencyCode"] == "USD"

    def test_customer_id_passed_through(
        self,
        mock_http_client,
        mock_taxcloud_config,
        mock_taxcloud_http_client,
        sample_taxcloud_calculate_cart_response,
    ):
        """Test that customerId is passed through to TaxCloud."""
        mock_taxcloud_http_client.post.return_value = (
            sample_taxcloud_calculate_cart_response
        )
        functions = Functions(
            mock_http_client,
            mock_taxcloud_config,
            taxcloud_http_client=mock_taxcloud_http_client,
        )

        request = self._build_request()
        functions.CalculateCart(request)

        call_args = mock_taxcloud_http_client.post.call_args
        json_body = call_args[1]["json"]
        assert json_body["items"][0]["customerId"] == "customer-453"

    # ----- Response Parsing Tests -----

    def test_taxcloud_response_parsed(
        self,
        mock_http_client,
        mock_taxcloud_config,
        mock_taxcloud_http_client,
        sample_taxcloud_calculate_cart_response,
    ):
        """Test that TaxCloud response is properly parsed."""
        mock_taxcloud_http_client.post.return_value = (
            sample_taxcloud_calculate_cart_response
        )
        functions = Functions(
            mock_http_client,
            mock_taxcloud_config,
            taxcloud_http_client=mock_taxcloud_http_client,
        )

        request = self._build_request()
        response = functions.CalculateCart(request)

        assert isinstance(response, TaxCloudCalculateCartResponse)
        assert response.connection_id == "test-connection-id-uuid"
        assert response.transaction_date == "2024-01-15T09:30:00Z"
        assert len(response.items) == 1

    def test_taxcloud_response_cart_fields(
        self,
        mock_http_client,
        mock_taxcloud_config,
        mock_taxcloud_http_client,
        sample_taxcloud_calculate_cart_response,
    ):
        """Test TaxCloud response cart item fields are properly parsed."""
        mock_taxcloud_http_client.post.return_value = (
            sample_taxcloud_calculate_cart_response
        )
        functions = Functions(
            mock_http_client,
            mock_taxcloud_config,
            taxcloud_http_client=mock_taxcloud_http_client,
        )

        request = self._build_request()
        response = functions.CalculateCart(request)

        cart = response.items[0]
        assert cart.cart_id == "ce4a1234-5678-90ab-cdef-1234567890ab"
        assert cart.customer_id == "customer-453"
        assert cart.currency.currency_code == "USD"
        assert cart.delivered_by_seller is False
        assert cart.exemption.exemption_id is None
        assert cart.exemption.is_exempt is None

    def test_taxcloud_response_addresses(
        self,
        mock_http_client,
        mock_taxcloud_config,
        mock_taxcloud_http_client,
        sample_taxcloud_calculate_cart_response,
    ):
        """Test TaxCloud response structured addresses are properly parsed."""
        mock_taxcloud_http_client.post.return_value = (
            sample_taxcloud_calculate_cart_response
        )
        functions = Functions(
            mock_http_client,
            mock_taxcloud_config,
            taxcloud_http_client=mock_taxcloud_http_client,
        )

        request = self._build_request()
        response = functions.CalculateCart(request)

        cart = response.items[0]
        assert cart.destination.line1 == "200 Spectrum Center Dr"
        assert cart.destination.city == "Irvine"
        assert cart.destination.state == "CA"
        assert cart.destination.zip == "92618-1905"
        assert cart.destination.country_code == "US"
        assert cart.origin.line1 == "323 Washington Ave N"
        assert cart.origin.city == "Minneapolis"
        assert cart.origin.state == "MN"
        assert cart.origin.zip == "55401-2427"
        assert cart.origin.country_code == "US"

    def test_taxcloud_response_line_items(
        self,
        mock_http_client,
        mock_taxcloud_config,
        mock_taxcloud_http_client,
        sample_taxcloud_calculate_cart_response,
    ):
        """Test TaxCloud response line items with tax details are parsed."""
        mock_taxcloud_http_client.post.return_value = (
            sample_taxcloud_calculate_cart_response
        )
        functions = Functions(
            mock_http_client,
            mock_taxcloud_config,
            taxcloud_http_client=mock_taxcloud_http_client,
        )

        request = self._build_request()
        response = functions.CalculateCart(request)

        cart = response.items[0]
        assert len(cart.line_items) == 2

        item1 = cart.line_items[0]
        assert item1.index == 0
        assert item1.item_id == "item-1"
        assert item1.price == 10.75
        assert item1.quantity == 1.5
        assert item1.tax.rate == 0.0903
        assert item1.tax.amount == 1.46
        assert item1.tic == 0

        item2 = cart.line_items[1]
        assert item2.index == 1
        assert item2.item_id == "item-2"
        assert item2.price == 25.00
        assert item2.quantity == 2.0
        assert item2.tax.rate == 0.0903
        assert item2.tax.amount == 4.52
        assert item2.tic == 0

    # ----- Address Parsing Error Tests -----

    def test_invalid_address_raises_validation_error(
        self,
        mock_http_client,
        mock_taxcloud_config,
        mock_taxcloud_http_client,
    ):
        """Test that unparseable address raises ZipTaxValidationError."""
        functions = Functions(
            mock_http_client,
            mock_taxcloud_config,
            taxcloud_http_client=mock_taxcloud_http_client,
        )

        request = CalculateCartRequest(
            items=[
                CartItem(
                    customer_id="cust-1",
                    currency=CartCurrency(currency_code="USD"),
                    destination=CartAddress(address="bad address"),
                    origin=CartAddress(
                        address="323 Washington Ave N, Minneapolis, MN 55401"
                    ),
                    line_items=[
                        CartLineItem(item_id="item-1", price=10.00, quantity=1.0)
                    ],
                )
            ]
        )

        with pytest.raises(ZipTaxValidationError, match="Cannot parse address"):
            functions.CalculateCart(request)

    def test_address_missing_state_zip_raises_error(
        self,
        mock_http_client,
        mock_taxcloud_config,
        mock_taxcloud_http_client,
    ):
        """Test that address with invalid state/zip segment raises error."""
        functions = Functions(
            mock_http_client,
            mock_taxcloud_config,
            taxcloud_http_client=mock_taxcloud_http_client,
        )

        request = CalculateCartRequest(
            items=[
                CartItem(
                    customer_id="cust-1",
                    currency=CartCurrency(currency_code="USD"),
                    destination=CartAddress(
                        address="200 Spectrum Center Dr, Irvine, California"
                    ),
                    origin=CartAddress(
                        address="323 Washington Ave N, Minneapolis, MN 55401"
                    ),
                    line_items=[
                        CartLineItem(item_id="item-1", price=10.00, quantity=1.0)
                    ],
                )
            ]
        )

        with pytest.raises(ZipTaxValidationError, match="Cannot parse state and ZIP"):
            functions.CalculateCart(request)


class TestTaxCloudFunctions:
    """Test cases for TaxCloud order management functions."""

    def test_check_taxcloud_config_raises_without_config(
        self, mock_http_client, mock_config
    ):
        """Test that TaxCloud functions raise without TaxCloud config."""
        functions = Functions(mock_http_client, mock_config)

        with pytest.raises(
            ZipTaxCloudConfigError,
            match="TaxCloud credentials not configured",
        ):
            functions._check_taxcloud_config()

    def test_create_order(
        self,
        mock_http_client,
        mock_taxcloud_config,
        mock_taxcloud_http_client,
        sample_order_response,
    ):
        """Test creating an order."""
        mock_taxcloud_http_client.post.return_value = sample_order_response
        functions = Functions(
            mock_http_client,
            mock_taxcloud_config,
            taxcloud_http_client=mock_taxcloud_http_client,
        )

        request = CreateOrderRequest(
            order_id="test-order-1",
            customer_id="customer-1",
            transaction_date="2024-01-15T09:30:00Z",
            completed_date="2024-01-15T09:30:00Z",
            origin={
                "line1": "323 Washington Ave N",
                "city": "Minneapolis",
                "state": "MN",
                "zip": "55401",
            },
            destination={
                "line1": "323 Washington Ave N",
                "city": "Minneapolis",
                "state": "MN",
                "zip": "55401",
            },
            line_items=[
                {
                    "index": 0,
                    "itemId": "item-1",
                    "price": 10.80,
                    "quantity": 1.5,
                    "tax": {"amount": 1.31, "rate": 0.0813},
                }
            ],
            currency={"currencyCode": "USD"},
        )

        response = functions.CreateOrder(request)

        assert isinstance(response, OrderResponse)
        assert response.order_id == "test-order-1"
        mock_taxcloud_http_client.post.assert_called_once()

    def test_get_order(
        self,
        mock_http_client,
        mock_taxcloud_config,
        mock_taxcloud_http_client,
        sample_order_response,
    ):
        """Test retrieving an order."""
        mock_taxcloud_http_client.get.return_value = sample_order_response
        functions = Functions(
            mock_http_client,
            mock_taxcloud_config,
            taxcloud_http_client=mock_taxcloud_http_client,
        )

        response = functions.GetOrder("test-order-1")

        assert isinstance(response, OrderResponse)
        assert response.order_id == "test-order-1"
        mock_taxcloud_http_client.get.assert_called_once()

    def test_update_order(
        self,
        mock_http_client,
        mock_taxcloud_config,
        mock_taxcloud_http_client,
        sample_order_response,
    ):
        """Test updating an order."""
        mock_taxcloud_http_client.patch.return_value = sample_order_response
        functions = Functions(
            mock_http_client,
            mock_taxcloud_config,
            taxcloud_http_client=mock_taxcloud_http_client,
        )

        request = UpdateOrderRequest(completed_date="2024-01-16T10:00:00Z")
        response = functions.UpdateOrder("test-order-1", request)

        assert isinstance(response, OrderResponse)
        assert response.order_id == "test-order-1"
        mock_taxcloud_http_client.patch.assert_called_once()

    def test_refund_order(
        self,
        mock_http_client,
        mock_taxcloud_config,
        mock_taxcloud_http_client,
        sample_refund_response,
    ):
        """Test refunding an order."""
        mock_taxcloud_http_client.post.return_value = [sample_refund_response]
        functions = Functions(
            mock_http_client,
            mock_taxcloud_config,
            taxcloud_http_client=mock_taxcloud_http_client,
        )

        request = RefundTransactionRequest(
            items=[{"itemId": "item-1", "quantity": 1.0}]
        )
        response = functions.RefundOrder("test-order-1", request)

        assert isinstance(response, list)
        assert len(response) == 1
        assert isinstance(response[0], RefundTransactionResponse)
        mock_taxcloud_http_client.post.assert_called_once()

    def test_refund_order_full(
        self,
        mock_http_client,
        mock_taxcloud_config,
        mock_taxcloud_http_client,
        sample_refund_response,
    ):
        """Test full refund (no request body)."""
        mock_taxcloud_http_client.post.return_value = [sample_refund_response]
        functions = Functions(
            mock_http_client,
            mock_taxcloud_config,
            taxcloud_http_client=mock_taxcloud_http_client,
        )

        response = functions.RefundOrder("test-order-1")

        assert isinstance(response, list)
        assert len(response) == 1
        mock_taxcloud_http_client.post.assert_called_once()

    def test_refund_order_single_dict_response(
        self,
        mock_http_client,
        mock_taxcloud_config,
        mock_taxcloud_http_client,
        sample_refund_response,
    ):
        """Test that RefundOrder handles API returning a single dict (not a list)."""
        # API sometimes returns a single dict for partial refunds
        mock_taxcloud_http_client.post.return_value = sample_refund_response
        functions = Functions(
            mock_http_client,
            mock_taxcloud_config,
            taxcloud_http_client=mock_taxcloud_http_client,
        )

        request = RefundTransactionRequest(
            items=[{"itemId": "item-1", "quantity": 1.0}]
        )
        response = functions.RefundOrder("test-order-1", request)

        assert isinstance(response, list)
        assert len(response) == 1
        assert isinstance(response[0], RefundTransactionResponse)
        assert response[0].connection_id == "test-connection-id-uuid"

    def test_create_order_without_taxcloud_config(self, mock_http_client, mock_config):
        """Test CreateOrder raises without TaxCloud config."""
        functions = Functions(mock_http_client, mock_config)

        with pytest.raises(ZipTaxCloudConfigError):
            functions.CreateOrder(
                CreateOrderRequest(
                    order_id="x",
                    customer_id="y",
                    transaction_date="2024-01-15T09:30:00Z",
                    completed_date="2024-01-15T09:30:00Z",
                    origin={
                        "line1": "123 Main",
                        "city": "City",
                        "state": "ST",
                        "zip": "12345",
                    },
                    destination={
                        "line1": "123 Main",
                        "city": "City",
                        "state": "ST",
                        "zip": "12345",
                    },
                    line_items=[
                        {
                            "index": 0,
                            "itemId": "i",
                            "price": 1.0,
                            "quantity": 1,
                            "tax": {"amount": 0.1, "rate": 0.1},
                        }
                    ],
                    currency={"currencyCode": "USD"},
                )
            )

    def test_create_order_with_valid_address_autocomplete(
        self,
        mock_http_client,
        mock_taxcloud_config,
        mock_taxcloud_http_client,
        sample_order_response,
    ):
        """Test CreateOrder accepts all valid address_autocomplete values."""
        mock_taxcloud_http_client.post.return_value = sample_order_response
        functions = Functions(
            mock_http_client,
            mock_taxcloud_config,
            taxcloud_http_client=mock_taxcloud_http_client,
        )

        request = CreateOrderRequest(
            order_id="test-order-1",
            customer_id="customer-1",
            transaction_date="2024-01-15T09:30:00Z",
            completed_date="2024-01-15T09:30:00Z",
            origin={
                "line1": "323 Washington Ave N",
                "city": "Minneapolis",
                "state": "MN",
                "zip": "55401",
            },
            destination={
                "line1": "323 Washington Ave N",
                "city": "Minneapolis",
                "state": "MN",
                "zip": "55401",
            },
            line_items=[
                {
                    "index": 0,
                    "itemId": "item-1",
                    "price": 10.80,
                    "quantity": 1.5,
                    "tax": {"amount": 1.31, "rate": 0.0813},
                }
            ],
            currency={"currencyCode": "USD"},
        )

        for value in ["none", "origin", "destination", "all"]:
            mock_taxcloud_http_client.post.reset_mock()
            response = functions.CreateOrder(request, address_autocomplete=value)
            assert isinstance(response, OrderResponse)

    def test_create_order_with_invalid_address_autocomplete(
        self,
        mock_http_client,
        mock_taxcloud_config,
        mock_taxcloud_http_client,
    ):
        """Test CreateOrder raises for invalid address_autocomplete."""
        functions = Functions(
            mock_http_client,
            mock_taxcloud_config,
            taxcloud_http_client=mock_taxcloud_http_client,
        )

        request = CreateOrderRequest(
            order_id="test-order-1",
            customer_id="customer-1",
            transaction_date="2024-01-15T09:30:00Z",
            completed_date="2024-01-15T09:30:00Z",
            origin={
                "line1": "323 Washington Ave N",
                "city": "Minneapolis",
                "state": "MN",
                "zip": "55401",
            },
            destination={
                "line1": "323 Washington Ave N",
                "city": "Minneapolis",
                "state": "MN",
                "zip": "55401",
            },
            line_items=[
                {
                    "index": 0,
                    "itemId": "item-1",
                    "price": 10.80,
                    "quantity": 1.5,
                    "tax": {"amount": 1.31, "rate": 0.0813},
                }
            ],
            currency={"currencyCode": "USD"},
        )

        with pytest.raises(
            ZipTaxValidationError,
            match="address_autocomplete must be one of",
        ):
            functions.CreateOrder(request, address_autocomplete="invalid")

    def test_get_order_without_taxcloud_config(self, mock_http_client, mock_config):
        """Test GetOrder raises without TaxCloud config."""
        functions = Functions(mock_http_client, mock_config)

        with pytest.raises(ZipTaxCloudConfigError):
            functions.GetOrder("test-order-1")


class TestCreateOrderFromCart:
    """Test cases for CreateOrderFromCart function."""

    def test_basic_request(
        self,
        mock_http_client,
        mock_taxcloud_config,
        mock_taxcloud_http_client,
        sample_create_order_from_cart_response,
    ):
        """Test basic CreateOrderFromCart request."""
        mock_taxcloud_http_client.post.return_value = (
            sample_create_order_from_cart_response
        )
        functions = Functions(
            mock_http_client,
            mock_taxcloud_config,
            taxcloud_http_client=mock_taxcloud_http_client,
        )

        request = CreateOrderFromCartRequest(
            cart_id="ce4a1234-5678-90ab-cdef-1234567890ab",
            order_id="my-order-1",
        )
        response = functions.CreateOrderFromCart(request)

        assert isinstance(response, OrderResponse)
        assert response.order_id == "my-order-1"
        assert response.customer_id == "customer-453"
        assert response.connection_id == "test-connection-id-uuid"
        mock_taxcloud_http_client.post.assert_called_once()

    def test_uses_correct_path(
        self,
        mock_http_client,
        mock_taxcloud_config,
        mock_taxcloud_http_client,
        sample_create_order_from_cart_response,
    ):
        """Test that CreateOrderFromCart uses the correct API path."""
        mock_taxcloud_http_client.post.return_value = (
            sample_create_order_from_cart_response
        )
        functions = Functions(
            mock_http_client,
            mock_taxcloud_config,
            taxcloud_http_client=mock_taxcloud_http_client,
        )

        request = CreateOrderFromCartRequest(
            cart_id="ce4a1234-5678-90ab-cdef-1234567890ab",
            order_id="my-order-1",
        )
        functions.CreateOrderFromCart(request)

        call_args = mock_taxcloud_http_client.post.call_args
        assert (
            call_args[0][0] == "/tax/connections/test-connection-id-uuid/carts/orders"
        )

    def test_request_body_serialization(
        self,
        mock_http_client,
        mock_taxcloud_config,
        mock_taxcloud_http_client,
        sample_create_order_from_cart_response,
    ):
        """Test that request body uses camelCase field names (by_alias)."""
        mock_taxcloud_http_client.post.return_value = (
            sample_create_order_from_cart_response
        )
        functions = Functions(
            mock_http_client,
            mock_taxcloud_config,
            taxcloud_http_client=mock_taxcloud_http_client,
        )

        request = CreateOrderFromCartRequest(
            cart_id="ce4a1234-5678-90ab-cdef-1234567890ab",
            order_id="my-order-1",
        )
        functions.CreateOrderFromCart(request)

        call_args = mock_taxcloud_http_client.post.call_args
        json_body = call_args[1]["json"]
        assert json_body["cartId"] == "ce4a1234-5678-90ab-cdef-1234567890ab"
        assert json_body["orderId"] == "my-order-1"

    def test_response_fields_parsed(
        self,
        mock_http_client,
        mock_taxcloud_config,
        mock_taxcloud_http_client,
        sample_create_order_from_cart_response,
    ):
        """Test that all response fields are properly parsed."""
        mock_taxcloud_http_client.post.return_value = (
            sample_create_order_from_cart_response
        )
        functions = Functions(
            mock_http_client,
            mock_taxcloud_config,
            taxcloud_http_client=mock_taxcloud_http_client,
        )

        request = CreateOrderFromCartRequest(
            cart_id="ce4a1234-5678-90ab-cdef-1234567890ab",
            order_id="my-order-1",
        )
        response = functions.CreateOrderFromCart(request)

        assert response.transaction_date == "2024-01-15T09:30:00Z"
        assert response.completed_date is None
        assert response.origin.line1 == "323 Washington Ave N"
        assert response.origin.state == "MN"
        assert response.destination.line1 == "200 Spectrum Center Dr"
        assert response.destination.state == "CA"
        assert len(response.line_items) == 1
        assert response.line_items[0].item_id == "item-1"
        assert response.line_items[0].tax.amount == 1.46
        assert response.line_items[0].tax.rate == 0.0903
        assert response.currency.currency_code == "USD"
        assert response.delivered_by_seller is False
        assert response.exclude_from_filing is False

    def test_without_taxcloud_config_raises(self, mock_http_client, mock_config):
        """Test CreateOrderFromCart raises without TaxCloud config."""
        functions = Functions(mock_http_client, mock_config)

        request = CreateOrderFromCartRequest(
            cart_id="ce4a1234-5678-90ab-cdef-1234567890ab",
            order_id="my-order-1",
        )

        with pytest.raises(
            ZipTaxCloudConfigError,
            match="TaxCloud credentials not configured",
        ):
            functions.CreateOrderFromCart(request)

    def test_does_not_call_ziptax_http_client(
        self,
        mock_http_client,
        mock_taxcloud_config,
        mock_taxcloud_http_client,
        sample_create_order_from_cart_response,
    ):
        """Test that CreateOrderFromCart only uses TaxCloud client."""
        mock_taxcloud_http_client.post.return_value = (
            sample_create_order_from_cart_response
        )
        functions = Functions(
            mock_http_client,
            mock_taxcloud_config,
            taxcloud_http_client=mock_taxcloud_http_client,
        )

        request = CreateOrderFromCartRequest(
            cart_id="ce4a1234-5678-90ab-cdef-1234567890ab",
            order_id="my-order-1",
        )
        functions.CreateOrderFromCart(request)

        mock_http_client.post.assert_not_called()
        mock_http_client.get.assert_not_called()

    # ----- Pydantic Validation Tests -----

    def test_empty_cart_id_rejected(self):
        """Test that empty cart_id is rejected by Pydantic validation."""
        with pytest.raises(ValidationError, match="String should have at least 1"):
            CreateOrderFromCartRequest(cart_id="", order_id="my-order-1")

    def test_empty_order_id_rejected(self):
        """Test that empty order_id is rejected by Pydantic validation."""
        with pytest.raises(ValidationError, match="String should have at least 1"):
            CreateOrderFromCartRequest(
                cart_id="ce4a1234-5678-90ab-cdef-1234567890ab",
                order_id="",
            )

    def test_camel_case_alias_accepted(self):
        """Test that camelCase field names are accepted via aliases."""
        request = CreateOrderFromCartRequest(
            cartId="ce4a1234-5678-90ab-cdef-1234567890ab",
            orderId="my-order-1",
        )
        assert request.cart_id == "ce4a1234-5678-90ab-cdef-1234567890ab"
        assert request.order_id == "my-order-1"
