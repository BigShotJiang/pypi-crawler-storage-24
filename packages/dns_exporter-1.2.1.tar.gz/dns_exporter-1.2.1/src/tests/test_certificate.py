"""Certificate related tests."""

import logging
import ssl

import pytest
import requests


@pytest.mark.parametrize("protocol", ["dot", "doh", "doh3", "doq"])
def test_cert_verify_fail(dns_exporter_example_config, protocol, caplog):
    """Test cert verify functionality when there is a certificate<>hostname mismatch."""
    caplog.clear()
    caplog.set_level(logging.DEBUG)
    r = requests.get(
        "http://127.0.0.1:25353/query",
        params={
            "server": "dns.google",
            "query_name": "example.com",
            "protocol": protocol,
            "family": "ipv4",
            "ip": "94.140.14.140",
        },
        timeout=5,
    )
    assert "dnsexp_dns_query_success 0.0" in r.text


@pytest.mark.parametrize("protocol", ["dot", "doh", "doh3", "doq"])
def test_cert_verify_fail_custom_ca(dns_exporter_example_config, protocol, caplog):
    """Test cert verify functionality with a selfsigned cert as CA."""
    caplog.clear()
    caplog.set_level(logging.DEBUG)
    r = requests.get(
        "http://127.0.0.1:25353/query",
        params={
            "server": "dns-unfiltered.adguard.com",
            "query_name": "example.com",
            "protocol": protocol,
            "family": "ipv4",
            "verify_certificate_path": "tests/certificates/test.crt",
        },
        timeout=5,
    )
    assert "dnsexp_dns_query_success 0.0" in r.text


@pytest.mark.parametrize("protocol", ["dot", "doh", "doh3", "doq"])
def test_cert_verify_false(dns_exporter_example_config, protocol, caplog):
    """Test cert verify functionality disabled allows lookups with bad certs for doh."""
    caplog.clear()
    caplog.set_level(logging.DEBUG)
    r = requests.get(
        "http://127.0.0.1:25353/query",
        params={
            "server": "94.140.14.141",  # dns-unfiltered.adguard.com
            "query_name": "example.com",
            "protocol": protocol,
            "family": "ipv4",
            "verify_certificate": False,
        },
        timeout=5,
    )
    assert "dnsexp_dns_query_success 1.0" in r.text


@pytest.mark.parametrize("protocol", ["dot", "doh", "doh3", "doq"])
def test_cert_verify_invalid_path(dns_exporter_example_config, protocol, caplog):
    """Test cert verify functionality when an invalid CA path is provided."""
    caplog.clear()
    caplog.set_level(logging.DEBUG)
    r = requests.get(
        "http://127.0.0.1:25353/query",
        params={
            "server": "91.239.100.100",
            "query_name": "example.com",
            "protocol": protocol,
            "family": "ipv4",
            "verify_certificate_path": "/nonexistant",
        },
        timeout=5,
    )
    assert "FailCollector returning failure reason: invalid_request_path" in caplog.text
    assert "dnsexp_dns_query_success 0.0" in r.text


@pytest.mark.parametrize(
    "protocol",
    [
        "dot",
        "doh",
        "doh3",
        "doq",
    ],
)
def test_cert_verify_custom_ca_dir(dns_exporter_example_config, protocol, caplog):
    """Test cert verify functionality with a custom CA dir."""
    caplog.clear()
    caplog.set_level(logging.DEBUG)
    r = requests.get(
        "http://127.0.0.1:25353/query",
        params={
            "server": "dns-unfiltered.adguard.com",
            "query_name": "example.com",
            "protocol": protocol,
            "family": "ipv4",
            "verify_certificate_path": ssl.get_default_verify_paths().capath,
        },
        timeout=5,
    )
    assert "dnsexp_dns_query_success 1.0" in r.text
