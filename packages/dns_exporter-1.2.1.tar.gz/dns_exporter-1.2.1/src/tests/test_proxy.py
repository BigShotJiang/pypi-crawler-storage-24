"""Unit tests for proxy functionality."""

import logging
import sys

import pytest
import requests

###################################################################################


@pytest.mark.parametrize(
    ("protocol", "server"),
    [
        ("udp", "dns.google"),
        ("tcp", "dns.google"),
        pytest.param(
            "dot",
            "anycast.uncensoreddns.org",
            marks=pytest.mark.xfail(
                reason="Proxy not yet supported for DoT, see https://github.com/tykling/dns_exporter/issues/76"
            ),
        ),
        ("doh", "anycast.uncensoreddns.org"),
        ("doq", "dns-unfiltered.adguard.com"),
        ("doh3", "dns-unfiltered.adguard.com"),
    ],
)
@pytest.mark.xfail(
    sys.version_info[:2] == (3, 14), reason="Skip under Python 3.14 https://github.com/tykling/dns_exporter/issues/202"
)
def test_proxy(dns_exporter_example_config, proxy_server, protocol, server):
    """Test proxy functionality for all protocols."""
    r = requests.get(
        "http://127.0.0.1:25353/query",
        params={
            "query_name": "example.com",
            "server": server,
            "family": "ipv4",
            "protocol": protocol,
            "proxy": "socks5://127.0.0.1",
        },
        timeout=5,
    )
    assert 'proxy="socks5://127.0.0.1:1080"' in r.text
    assert f'server="{protocol}://{server}:' in r.text


###################################################################################


@pytest.mark.xfail(
    sys.version_info[:2] == (3, 14), reason="Skip under Python 3.14 https://github.com/tykling/dns_exporter/issues/202"
)
@pytest.mark.parametrize("protocol", ["udp", "tcp", "dot", "doh", "doh3", "doq"])
def test_proxy_fail(dns_exporter_example_config, proxy_server, protocol):
    """Test proxy failure for all protocols."""
    r = requests.get(
        "http://127.0.0.1:25353/query",
        params={
            "query_name": "example.com",
            "server": "dns.google",
            "family": "ipv4",
            "protocol": protocol,
            "proxy": "socks5://127.0.0.1:1081",
        },
        timeout=5,
    )
    assert "dnsexp_dns_query_success 0.0" in r.text


###################################################################################


def test_proxy_without_scheme(dns_exporter_example_config):
    """Trigger an invalid_request_proxy failure by providing a proxy without a scheme."""
    r = requests.get(
        "http://127.0.0.1:25353/query",
        params={
            "query_name": "example.com",
            "server": "dns.google",
            "proxy": "127.0.0.1:1080",
        },
        timeout=5,
    )
    assert r.status_code == 200, "non-200 returncode"


def test_proxy_unknown_scheme(dns_exporter_example_config):
    """Trigger an invalid_request_proxy failure by providing a proxy with an unknown scheme."""
    r = requests.get(
        "http://127.0.0.1:25353/query",
        params={
            "query_name": "example.com",
            "server": "dns.google",
            "proxy": "foo://127.0.0.1:1080",
        },
        timeout=5,
    )
    assert r.status_code == 200, "non-200 returncode"


def test_exporter_modules_none(caplog, exporter):
    """Make sure calling configure() with modules=None works."""
    caplog.clear()
    caplog.set_level(logging.DEBUG)
    exporter.configure(modules=None)
    assert "0 module(s) loaded OK, total modules: 0." in caplog.text


@pytest.mark.xfail(
    sys.version_info[:2] == (3, 14), reason="Skip under Python 3.14 https://github.com/tykling/dns_exporter/issues/202"
)
def test_proxy_module(dns_exporter_example_config, proxy_server):
    """Test proxy functionality for udp protocol."""
    r = requests.get(
        "http://127.0.0.1:25353/query",
        params={
            "query_name": "example.com",
            "server": "dns.google",
            "family": "ipv4",
            "protocol": "udp",
            "module": "socks1080",
        },
        timeout=5,
    )
    assert 'proxy="socks5://127.0.0.1:1080"' in r.text
    assert 'server="udp://dns.google:53"' in r.text
