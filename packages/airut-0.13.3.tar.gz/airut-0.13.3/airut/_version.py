"""Auto-generated at build time — do not edit."""

VERSION = 'v0.13.3'
GIT_SHA_SHORT = '4b75551'
GIT_SHA_FULL = '4b75551a5d80a7a4bf98a8afec9efdd242e06876'
