"""Branch protection models for bb2gh.

Models for representing Bitbucket Cloud branch restrictions,
GitHub Enterprise Cloud rulesets, and the mapping between them.
"""

from __future__ import annotations

from enum import StrEnum
from typing import Any

from pydantic import BaseModel, Field, model_validator

# ---------------------------------------------------------------------------
# Source Models (Bitbucket Cloud)
# ---------------------------------------------------------------------------


class BranchRestrictionKind(StrEnum):
    """Bitbucket Cloud branch restriction kind.

    All 16 valid `kind` values from the BB Cloud branch-restrictions API.
    """

    PUSH = "push"
    RESTRICT_MERGES = "restrict_merges"
    FORCE = "force"
    DELETE = "delete"
    REQUIRE_APPROVALS_TO_MERGE = "require_approvals_to_merge"
    REQUIRE_DEFAULT_REVIEWER_APPROVALS_TO_MERGE = "require_default_reviewer_approvals_to_merge"
    REQUIRE_PASSING_BUILDS_TO_MERGE = "require_passing_builds_to_merge"
    REQUIRE_TASKS_TO_BE_COMPLETED = "require_tasks_to_be_completed"
    REQUIRE_NO_CHANGES_REQUESTED = "require_no_changes_requested"
    REQUIRE_ALL_DEPENDENCIES_MERGED = "require_all_dependencies_merged"
    RESET_PULLREQUEST_APPROVALS_ON_CHANGE = "reset_pullrequest_approvals_on_change"
    SMART_RESET_PULLREQUEST_APPROVALS = "smart_reset_pullrequest_approvals"
    RESET_PULLREQUEST_CHANGES_REQUESTED_ON_CHANGE = "reset_pullrequest_changes_requested_on_change"
    REQUIRE_COMMITS_BEHIND = "require_commits_behind"
    ENFORCE_MERGE_CHECKS = "enforce_merge_checks"
    ALLOW_AUTO_MERGE_WHEN_BUILDS_PASS = "allow_auto_merge_when_builds_pass"


class BranchMatchKind(StrEnum):
    """How a branch restriction matches branches."""

    GLOB = "glob"
    BRANCHING_MODEL = "branching_model"


class BranchType(StrEnum):
    """Bitbucket branching model branch types."""

    FEATURE = "feature"
    BUGFIX = "bugfix"
    RELEASE = "release"
    HOTFIX = "hotfix"
    DEVELOPMENT = "development"
    PRODUCTION = "production"


class BranchRestrictionUser(BaseModel):
    """A user referenced in a Bitbucket branch restriction."""

    uuid: str
    display_name: str | None = None
    account_id: str | None = None


class BranchRestrictionGroup(BaseModel):
    """A group referenced in a Bitbucket branch restriction."""

    slug: str
    owner_username: str


class BranchRestriction(BaseModel):
    """A single Bitbucket Cloud branch restriction rule.

    Represents one entry from the ``/branch-restrictions`` API endpoint.
    """

    id: int
    kind: BranchRestrictionKind
    branch_match_kind: BranchMatchKind
    pattern: str | None = None
    branch_type: BranchType | None = None
    value: int | None = None
    users: list[BranchRestrictionUser] = Field(default_factory=list)
    groups: list[BranchRestrictionGroup] = Field(default_factory=list)

    @model_validator(mode="after")
    def _validate_match_kind_fields(self) -> BranchRestriction:
        """Ensure branching_model has branch_type, glob has pattern."""
        if self.branch_match_kind == BranchMatchKind.BRANCHING_MODEL:
            if self.branch_type is None:
                msg = "branch_type is required when branch_match_kind is 'branching_model'"
                raise ValueError(msg)
        elif self.branch_match_kind == BranchMatchKind.GLOB and self.pattern is None:
            msg = "pattern is required when branch_match_kind is 'glob'"
            raise ValueError(msg)
        return self


class DefaultReviewer(BaseModel):
    """A default reviewer from Bitbucket (repo or project level)."""

    uuid: str
    display_name: str | None = None
    reviewer_type: str = Field(
        description="Source level: 'repository' or 'project'",
    )


class RepoBranchProtection(BaseModel):
    """Container for all branch protection data for a single repository.

    Aggregates restrictions, branching model, and default reviewers.
    """

    repo_full_name: str
    restrictions: list[BranchRestriction] = Field(default_factory=list)
    branching_model: dict[str, Any] | None = None
    default_reviewers: list[DefaultReviewer] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Target Models (GitHub Enterprise Cloud Rulesets)
# ---------------------------------------------------------------------------


class RulesetEnforcement(StrEnum):
    """GitHub ruleset enforcement level."""

    ACTIVE = "active"
    EVALUATE = "evaluate"
    DISABLED = "disabled"


class RulesetTarget(StrEnum):
    """GitHub ruleset target type."""

    BRANCH = "branch"
    TAG = "tag"


class RulesetScope(StrEnum):
    """Scope at which a ruleset is applied."""

    REPOSITORY = "repository"
    ORGANIZATION = "organization"


class BypassActorType(StrEnum):
    """Types of actors that can bypass a GitHub ruleset."""

    ORGANIZATION_ADMIN = "OrganizationAdmin"
    REPOSITORY_ROLE = "RepositoryRole"
    TEAM = "Team"
    INTEGRATION = "Integration"


class BypassMode(StrEnum):
    """When a bypass actor can bypass the ruleset."""

    ALWAYS = "always"
    PULL_REQUEST = "pull_request"


class BypassActor(BaseModel):
    """An actor that can bypass a GitHub ruleset."""

    actor_id: int
    actor_type: BypassActorType
    bypass_mode: BypassMode


class RefNameCondition(BaseModel):
    """GitHub ruleset ref name condition (branch/tag patterns)."""

    include: list[str] = Field(default_factory=list)
    exclude: list[str] = Field(default_factory=list)


class RepositoryNameCondition(BaseModel):
    """GitHub ruleset repository name condition (org-level targeting)."""

    include: list[str] = Field(default_factory=list)
    exclude: list[str] = Field(default_factory=list)
    protected: bool = False


class RulesetConditions(BaseModel):
    """Conditions that determine which refs/repos a ruleset applies to."""

    ref_name: RefNameCondition
    repository_name: RepositoryNameCondition | None = None


class PullRequestRuleParams(BaseModel):
    """Parameters for the ``pull_request`` ruleset rule type."""

    dismiss_stale_reviews_on_push: bool = False
    require_code_owner_review: bool = False
    require_last_push_approval: bool = False
    required_approving_review_count: int = 0
    required_review_thread_resolution: bool = False


class StatusCheckConfig(BaseModel):
    """A single required status check entry."""

    context: str
    integration_id: int | None = None


class StatusChecksRuleParams(BaseModel):
    """Parameters for the ``required_status_checks`` ruleset rule type."""

    strict_required_status_checks_policy: bool = False
    do_not_enforce_on_create: bool = False
    required_status_checks: list[StatusCheckConfig] = Field(default_factory=list)


class RulesetRule(BaseModel):
    """A single rule within a GitHub ruleset.

    The ``type`` field determines which parameter model applies.
    Simple rules like ``non_fast_forward`` and ``deletion`` have no parameters.
    """

    type: str
    parameters: PullRequestRuleParams | StatusChecksRuleParams | None = None


class GitHubRulesetConfig(BaseModel):
    """Full configuration for a GitHub ruleset (repo or org level).

    Represents the JSON payload for ``POST /repos/{owner}/{repo}/rulesets``
    or ``POST /orgs/{org}/rulesets``.
    """

    name: str
    target: RulesetTarget = RulesetTarget.BRANCH
    enforcement: RulesetEnforcement = RulesetEnforcement.EVALUATE
    scope: RulesetScope = RulesetScope.REPOSITORY
    bypass_actors: list[BypassActor] = Field(default_factory=list)
    conditions: RulesetConditions
    rules: list[RulesetRule] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Mapping Models
# ---------------------------------------------------------------------------


class MappingStatus(StrEnum):
    """Status of a BB → GH restriction mapping."""

    MAPPED = "mapped"
    APPROXIMATE = "approximate"
    UNMAPPED = "unmapped"
    IMPLICIT = "implicit"


class RestrictionMapping(BaseModel):
    """Mapping from a single BB restriction to a GH ruleset rule."""

    source: BranchRestriction
    target_rule: RulesetRule | None = None
    status: MappingStatus
    notes: str | None = None
    warnings: list[str] = Field(default_factory=list)


class BranchProtectionPlan(BaseModel):
    """Complete branch protection migration plan for one repository.

    Contains the source-to-target mapping and the generated rulesets.
    """

    source_repo: str
    target_repo: str
    mappings: list[RestrictionMapping] = Field(default_factory=list)
    rulesets: list[GitHubRulesetConfig] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    requires_manual_review: bool = False
    codeowners_content: str | None = None
    enable_auto_merge: bool = False
