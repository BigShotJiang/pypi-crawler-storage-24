"""PR migration service for bb2gh.

Handles fetching PRs from Bitbucket and creating them in GitHub.
Supports two migration modes:
1. Enterprise Importer (GEI) - For GitHub Enterprise with full PR state preservation
2. Standard API - For regular GitHub with Issue fallback for closed PRs
"""

from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Any

import structlog

from bb2gh.models.pull_request import (
    GitHubPRCreateRequest,
    PRAuthor,
    PRBranch,
    PRMigrationResult,
    PRMigrationStats,
    PRReviewer,
    PRReviewerState,
    PRState,
    PullRequest,
)
from bb2gh.services.gei_archive import GEIArchiveGenerator
from bb2gh.services.pr_activity import PRActivityService

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

    from bb2gh.adapters.base import SourceAdapter, TargetAdapter
    from bb2gh.models.user_mapping import UserMappingStore

logger = structlog.get_logger(__name__)


class PRMigrationService:
    """Service for migrating Pull Requests from Bitbucket to GitHub.

    Supports two migration modes:
    1. Enterprise Importer (GEI) - For GitHub Enterprise with full PR state preservation
    2. Standard API - For regular GitHub with Issue fallback for closed PRs
    """

    def __init__(
        self,
        *,
        source_adapter: SourceAdapter,
        target_adapter: TargetAdapter,
        user_mapping: UserMappingStore | None = None,
        use_enterprise_importer: bool | None = None,
    ) -> None:
        """Initialize PRMigrationService.

        Args:
            source_adapter: Adapter for source platform (Bitbucket).
            target_adapter: Adapter for target platform (GitHub).
            user_mapping: User mapping store for attribution.
            use_enterprise_importer: Force Enterprise Importer mode (None = auto-detect).
        """
        self._source = source_adapter
        self._target = target_adapter
        self._user_mapping = user_mapping
        self._use_gei = use_enterprise_importer
        self._gei_available: bool | None = None

    async def _check_enterprise_importer(self) -> bool:
        """Check if Enterprise Importer is available.

        Returns:
            True if GEI mutations are accessible.
        """
        if self._use_gei is not None:
            return self._use_gei

        if self._gei_available is None:
            # Check if target adapter supports GEI
            if hasattr(self._target, "check_enterprise_importer_access"):
                self._gei_available = await self._target.check_enterprise_importer_access()
                if self._gei_available:
                    logger.info("enterprise_importer_available")
                else:
                    logger.debug("enterprise_importer_not_available")
            else:
                self._gei_available = False

        return self._gei_available

    async def migrate_closed_prs_via_gei(
        self,
        prs: list[PullRequest],
        source_repo: str,
        target_repo: str,
        *,
        archive_base_url: str | None = None,
    ) -> PRMigrationStats:
        """Migrate closed PRs using GitHub Enterprise Importer archive.

        This method generates a GEI-compatible archive containing all closed PRs
        and initiates a migration using the Enterprise Importer API. This preserves
        full historical state including timestamps and merge commits.

        Args:
            prs: List of closed PullRequests to migrate.
            source_repo: Source repository (workspace/repo).
            target_repo: Target repository (org/repo).
            archive_base_url: Base URL where archives will be accessible.
                              If not provided, will attempt to use gh-gei's approach.

        Returns:
            PRMigrationStats with migration results.
        """
        stats = PRMigrationStats()

        if not prs:
            return stats

        # Parse target repo
        org, repo_name = target_repo.split("/", 1)

        # Parse source repo
        workspace, source_name = source_repo.split("/", 1)

        logger.info(
            "starting_gei_pr_migration",
            source=source_repo,
            target=target_repo,
            pr_count=len(prs),
        )

        # Generate GEI archive
        archive_generator = GEIArchiveGenerator(
            source_workspace=workspace,
            source_repo=source_name,
            target_org=org,
            target_repo=repo_name,
        )

        try:
            # Add all PRs to archive
            for pr in prs:
                archive_generator.add_pull_request(pr)
                stats.total += 1

            # Generate archive file
            archive_path = archive_generator.generate_archive()
            logger.info("gei_archive_generated", path=str(archive_path))

            # Get organization ID
            org_id = await self._target.get_organization_id(org)  # type: ignore[attr-defined]
            if not org_id:
                raise ValueError(f"Could not get organization ID for {org}")

            # Create migration source
            source_id = await self._target.create_migration_source(  # type: ignore[attr-defined]
                org_id=org_id,
                source_name=f"bb2gh-{workspace}",
                source_url=f"https://bitbucket.org/{source_repo}",
                source_type="GITHUB_ARCHIVE",  # Use archive type for PR-only migration
            )

            if not source_id:
                raise ValueError("Failed to create migration source")

            # For GEI to work, the archive needs to be accessible via URL
            # In a production setup, this would be uploaded to blob storage
            # For now, we log the archive path for manual handling
            if archive_base_url:
                metadata_archive_url = f"{archive_base_url.rstrip('/')}/{archive_path.name}"

                # Start migration
                migration = await self._target.start_repository_migration(  # type: ignore[attr-defined]
                    migration_source_id=source_id,
                    org_id=org_id,
                    source_repo_url=f"https://bitbucket.org/{source_repo}",
                    target_repo_name=repo_name,
                    metadata_archive_url=metadata_archive_url,
                )

                if migration:
                    # Wait for migration to complete
                    final_status = await self._target.wait_for_migration(  # type: ignore[attr-defined]
                        migration["id"],
                        poll_interval=5,
                        timeout=1800,  # 30 minutes
                    )

                    if final_status and final_status.get("state") == "SUCCEEDED":
                        stats.migrated = len(prs)
                        for pr in prs:
                            result = PRMigrationResult(
                                source_pr_id=pr.id,
                                source_pr_url=pr.html_url,
                                success=True,
                            )
                            if pr.is_merged:
                                stats.merged_migrated += 1
                            else:
                                stats.declined_migrated += 1
                            stats.migrated_as_prs += 1
                            stats.results.append(result)
                    else:
                        failure_reason = (
                            final_status.get("failureReason") if final_status else "Unknown"
                        )
                        logger.error(
                            "gei_migration_failed",
                            failure_reason=failure_reason,
                        )
                        stats.failed = len(prs)
                        for pr in prs:
                            result = PRMigrationResult(
                                source_pr_id=pr.id,
                                source_pr_url=pr.html_url,
                                success=False,
                                error_message=f"GEI migration failed: {failure_reason}",
                            )
                            stats.results.append(result)
            else:
                # No archive URL provided - return archive path for manual handling
                logger.warning(
                    "gei_archive_ready_for_upload",
                    archive_path=str(archive_path),
                    message="Upload this archive to blob storage and provide URL to complete migration",
                )
                # Mark PRs as skipped pending archive upload
                stats.skipped = len(prs)
                for pr in prs:
                    result = PRMigrationResult(
                        source_pr_id=pr.id,
                        source_pr_url=pr.html_url,
                        success=False,
                        error_message=f"GEI archive generated at {archive_path}. Upload required.",
                    )
                    stats.results.append(result)

        except Exception as e:
            logger.error("gei_migration_error", error=str(e))
            stats.failed = len(prs)
            for pr in prs:
                result = PRMigrationResult(
                    source_pr_id=pr.id,
                    source_pr_url=pr.html_url,
                    success=False,
                    error_message=str(e),
                )
                stats.results.append(result)
        finally:
            # Clean up temporary files
            archive_generator.cleanup()

        logger.info(
            "gei_pr_migration_complete",
            migrated=stats.migrated,
            failed=stats.failed,
            skipped=stats.skipped,
        )

        return stats

    async def fetch_open_prs(
        self,
        repo_full_name: str,
    ) -> AsyncIterator[PullRequest]:
        """Fetch all open PRs from a Bitbucket repository.

        Args:
            repo_full_name: Full repository name (workspace/repo).

        Yields:
            PullRequest objects.
        """
        logger.info("fetching_open_prs", repo=repo_full_name)

        async for pr_data in self._source.list_pull_requests(
            repo_full_name,
            state="OPEN",
        ):
            pr = self._parse_bitbucket_pr(pr_data, repo_full_name)
            yield pr

    async def fetch_closed_prs(
        self,
        repo_full_name: str,
        *,
        since: datetime | None = None,
        until: datetime | None = None,
    ) -> AsyncIterator[PullRequest]:
        """Fetch closed/merged PRs from a Bitbucket repository.

        Args:
            repo_full_name: Full repository name (workspace/repo).
            since: Only fetch PRs updated after this date.
            until: Only fetch PRs updated before this date.

        Yields:
            PullRequest objects.
        """
        logger.info("fetching_closed_prs", repo=repo_full_name)

        for state in ["MERGED", "DECLINED", "SUPERSEDED"]:
            async for pr_data in self._source.list_pull_requests(
                repo_full_name,
                state=state,
            ):
                pr = self._parse_bitbucket_pr(pr_data, repo_full_name)

                # Filter by date if specified
                if since and pr.updated_at and pr.updated_at < since:
                    continue
                if until and pr.updated_at and pr.updated_at > until:
                    continue

                yield pr

    def _parse_bitbucket_pr(
        self,
        pr_data: dict[str, Any],
        repo_full_name: str,
    ) -> PullRequest:
        """Parse Bitbucket PR API response into PullRequest model.

        Args:
            pr_data: Raw PR data from Bitbucket API.
            repo_full_name: Full repository name.

        Returns:
            PullRequest model.
        """
        # Parse author
        author_data = pr_data.get("author", {})
        author = PRAuthor(
            username=author_data.get("username", author_data.get("account_id", "unknown")),
            display_name=author_data.get("display_name"),
            account_id=author_data.get("account_id"),
        )

        # Parse branches (use 'or {}' pattern to handle explicit None values)
        source = pr_data.get("source") or {}
        destination = pr_data.get("destination") or {}
        source_data = source.get("branch") or {}
        target_data = destination.get("branch") or {}

        source_branch = PRBranch(
            name=source_data.get("name", "unknown"),
            commit_hash=(source.get("commit") or {}).get("hash"),
        )
        target_branch = PRBranch(
            name=target_data.get("name", "main"),
            commit_hash=(destination.get("commit") or {}).get("hash"),
        )

        # Parse reviewers
        reviewers = []
        for reviewer_data in pr_data.get("reviewers", []):
            reviewer = PRReviewer(
                username=reviewer_data.get("username", reviewer_data.get("account_id", "")),
                display_name=reviewer_data.get("display_name"),
            )
            reviewers.append(reviewer)

        # Parse participants for approval state
        for participant in pr_data.get("participants", []):
            if participant.get("approved"):
                for r in reviewers:
                    if r.username == (participant.get("user") or {}).get("username"):
                        r.state = PRReviewerState.APPROVED
                        break

        # Map state
        bb_state = pr_data.get("state", "OPEN").upper()
        state_map = {
            "OPEN": PRState.OPEN,
            "MERGED": PRState.MERGED,
            "DECLINED": PRState.DECLINED,
            "SUPERSEDED": PRState.SUPERSEDED,
        }
        state = state_map.get(bb_state, PRState.OPEN)

        # Parse timestamps
        created_at = None
        updated_at = None
        if pr_data.get("created_on"):
            created_at = datetime.fromisoformat(pr_data["created_on"].replace("Z", "+00:00"))
        if pr_data.get("updated_on"):
            updated_at = datetime.fromisoformat(pr_data["updated_on"].replace("Z", "+00:00"))

        # Parse labels from Bitbucket properties (bb-label)
        labels: list[str] = []
        for prop in pr_data.get("properties", []):
            if prop.get("name") == "bb-label" and prop.get("value"):
                labels.append(prop["value"])

        # Parse merge info (merge_commit may be None for open PRs)
        merge_commit_data = pr_data.get("merge_commit") or {}
        merge_commit = merge_commit_data.get("hash")

        return PullRequest(
            id=str(pr_data.get("id")),
            title=pr_data.get("title", ""),
            description=pr_data.get("description"),
            state=state,
            author=author,
            source_branch=source_branch,
            target_branch=target_branch,
            reviewers=reviewers,
            labels=labels,
            created_at=created_at,
            updated_at=updated_at,
            merge_commit_hash=merge_commit,
            html_url=(pr_data.get("links") or {}).get("html", {}).get("href"),
            source_repo_full_name=repo_full_name,
            comment_count=pr_data.get("comment_count", 0),
        )

    async def create_github_pr(
        self,
        pr: PullRequest,
        target_repo: str,
        *,
        migrate_activities: bool = True,
    ) -> PRMigrationResult:
        """Create a PR in GitHub.

        Args:
            pr: Source PullRequest to migrate.
            target_repo: Target repository (org/repo).
            migrate_activities: Whether to migrate PR activities (comments, etc.).

        Returns:
            PRMigrationResult with migration details.
        """
        result = PRMigrationResult(
            source_pr_id=pr.id,
            source_pr_url=pr.html_url,
        )

        log = logger.bind(
            source_pr=pr.id,
            target_repo=target_repo,
        )

        try:
            # Fetch activity timeline BEFORE creating PR so it can be included in body
            activity_timeline = None
            if migrate_activities and pr.source_repo_full_name:
                try:
                    activity_service = PRActivityService(
                        source_adapter=self._source,
                        target_adapter=self._target,
                        user_mapping=self._user_mapping,
                    )
                    activities = await activity_service.fetch_activities(
                        pr.source_repo_full_name,
                        pr.id,
                    )
                    if activities:
                        activity_timeline = activity_service.build_activity_timeline(activities)
                except Exception as e:
                    log.warning("activity_timeline_fetch_failed", error=str(e))

            # Build PR body with attribution and activity timeline
            body = self._build_pr_body(
                pr,
                result,
                include_activity_timeline=bool(activity_timeline),
                activity_timeline=activity_timeline,
            )

            # Create PR request
            request = GitHubPRCreateRequest(
                title=pr.title,
                body=body,
                head=pr.source_branch.name,
                base=pr.target_branch.name,
            )

            # Create PR in GitHub
            gh_pr = await self._target.create_pull_request(
                target_repo,
                title=request.title,
                body=request.body,
                head=request.head,
                base=request.base,
                draft=request.draft,
            )

            result.target_pr_number = gh_pr.get("number")
            result.target_pr_url = gh_pr.get("html_url")

            # Request reviewers (filter out PR author to avoid GitHub 422)
            if pr.reviewers and result.target_pr_number:
                await self._request_reviewers(
                    target_repo,
                    result.target_pr_number,
                    pr.reviewers,
                    result,
                    pr_author_username=result.author_username,
                )

            # Apply labels
            if pr.labels and result.target_pr_number:
                await self._apply_labels(
                    target_repo,
                    result.target_pr_number,
                    pr.labels,
                    result,
                )

            # Migrate activity comments (timeline already in PR body from above)
            if migrate_activities and result.target_pr_number and pr.source_repo_full_name:
                try:
                    activity_service = PRActivityService(
                        source_adapter=self._source,
                        target_adapter=self._target,
                        user_mapping=self._user_mapping,
                    )
                    # Migrate comments as individual GitHub comments
                    activity_stats = await activity_service.migrate_pr_activities(
                        pr.source_repo_full_name,
                        pr.id,
                        target_repo,
                        result.target_pr_number,
                        include_in_description=False,  # Timeline already in PR body
                    )
                    result.comments_migrated = activity_stats.get("comments_migrated", 0)
                except Exception as e:
                    log.warning("activity_migration_failed", error=str(e))

            result.success = True
            log.info("pr_created", gh_pr=result.target_pr_number)

        except Exception as e:
            result.error_message = str(e)
            log.error("pr_creation_failed", error=str(e))

        return result

    async def create_closed_github_pr(
        self,
        pr: PullRequest,
        target_repo: str,
    ) -> PRMigrationResult:
        """Create a closed PR in GitHub (for historical PRs).

        Uses Enterprise Importer if available for full state preservation,
        otherwise falls back to creating PR (with Issue fallback if branch missing).

        Args:
            pr: Source PullRequest to migrate.
            target_repo: Target repository (org/repo).

        Returns:
            PRMigrationResult with migration details.
        """
        result = PRMigrationResult(
            source_pr_id=pr.id,
            source_pr_url=pr.html_url,
        )

        log = logger.bind(
            source_pr=pr.id,
            target_repo=target_repo,
            state=pr.state.value,
        )

        # Check if Enterprise Importer is available for better closed PR handling
        # Note: GEI migration is done in batch, so we queue PRs for archive-based migration
        # For now, we use the standard approach with Issue fallback

        try:
            # Build PR body with attribution and state info
            body = self._build_pr_body(pr, result, include_state=True)

            # Add decline reason if applicable
            if pr.state == PRState.DECLINED and pr.decline_reason:
                body += f"\n\n**Decline reason:** {pr.decline_reason}"

            # Try to create PR in GitHub (will be immediately closed)
            try:
                gh_pr = await self._target.create_pull_request(
                    target_repo,
                    title=pr.title,
                    body=body,
                    head=pr.source_branch.name,
                    base=pr.target_branch.name,
                )

                result.target_pr_number = gh_pr.get("number")
                result.target_pr_url = gh_pr.get("html_url")

                # Close the PR
                if result.target_pr_number:
                    await self._target.update_pull_request(
                        target_repo,
                        result.target_pr_number,
                        state="closed",
                    )

                    # Add merge commit comment if merged
                    if pr.is_merged and pr.merge_commit_hash:
                        await self._add_merge_commit_comment(
                            target_repo,
                            result.target_pr_number,
                            pr.merge_commit_hash,
                        )

                result.success = True
                log.info("closed_pr_created", gh_pr=result.target_pr_number)

            except Exception as pr_error:
                # PR creation failed (likely 422 - branch doesn't exist)
                # Fall back to creating an Issue to preserve the history
                error_str = str(pr_error)
                if "422" in error_str or "Unprocessable" in error_str:
                    log.info(
                        "pr_creation_failed_falling_back_to_issue",
                        reason="Branch no longer exists",
                    )
                    await self._create_historical_pr_as_issue(pr, target_repo, body, result, log)
                else:
                    # Re-raise non-422 errors
                    raise

        except Exception as e:
            result.error_message = str(e)
            log.error("closed_pr_creation_failed", error=str(e))

        return result

    async def _create_historical_pr_as_issue(
        self,
        pr: PullRequest,
        target_repo: str,
        body: str,
        result: PRMigrationResult,
        log: Any,
    ) -> None:
        """Create a historical PR as an Issue when branch is missing.

        This is a fallback for merged/closed PRs where the source branch
        no longer exists in the repository.

        Args:
            pr: Source PullRequest.
            target_repo: Target repository (org/repo).
            body: Issue body (already formatted).
            result: PRMigrationResult to update.
            log: Bound logger.
        """
        # Add header indicating this was a PR
        state_label = "merged" if pr.is_merged else pr.state.value.lower()
        issue_title = f"[Historical PR #{pr.id}] {pr.title}"

        # Add branch info to body since we can't show it as a PR
        branch_info = (
            f"\n\n**Original branches:** `{pr.source_branch.name}` → `{pr.target_branch.name}`"
        )
        if pr.is_merged and pr.merge_commit_hash:
            branch_info += f"\n**Merge commit:** `{pr.merge_commit_hash}`"

        issue_body = body + branch_info
        issue_body += "\n\n> ⚠️ *Created as an Issue because the source branch no longer exists.*"

        # Determine labels
        labels = ["migrated-pr", f"pr-{state_label}"]

        # Create the issue
        gh_issue = await self._target.create_issue(  # type: ignore[attr-defined]
            target_repo,
            title=issue_title,
            body=issue_body,
            labels=labels,
        )

        result.target_pr_number = gh_issue.get("number")
        result.target_pr_url = gh_issue.get("html_url")
        result.migrated_as_issue = True

        # Close the issue immediately (to match the closed PR state)
        if result.target_pr_number:
            await self._target.close_issue(target_repo, result.target_pr_number)  # type: ignore[attr-defined]

        result.success = True
        log.info(
            "closed_pr_created_as_issue",
            issue_number=result.target_pr_number,
            state=state_label,
        )

    def _build_pr_body(
        self,
        pr: PullRequest,
        result: PRMigrationResult,
        *,
        include_state: bool = False,
        include_activity_timeline: bool = False,
        activity_timeline: str | None = None,
    ) -> str:
        """Build PR body with original description and attribution.

        Args:
            pr: Source PullRequest.
            result: Migration result to update with attribution info.
            include_state: Whether to include original state info.
            include_activity_timeline: Whether to include activity timeline.
            activity_timeline: Pre-formatted activity timeline markdown.

        Returns:
            PR body string.
        """
        parts = []

        # Original description
        if pr.description:
            parts.append(pr.description)
            parts.append("")

        # Attribution section
        parts.append("---")
        parts.append("*Migrated from Bitbucket*")

        # Author attribution
        target_user, attribution_note = self._resolve_user(pr.author.username)
        if attribution_note:
            parts.append(f"**Original author:** {attribution_note}")
            result.attribution_note = attribution_note
        else:
            parts.append(f"**Original author:** @{target_user}")
            result.author_mapped = True
            result.author_username = target_user

        # State info for closed PRs
        if include_state:
            parts.append(f"**Original state:** {pr.state.value}")
            if pr.created_at:
                parts.append(f"**Created:** {pr.created_at.isoformat()}")
            if pr.merged_at:
                parts.append(f"**Merged:** {pr.merged_at.isoformat()}")
            elif pr.closed_at:
                parts.append(f"**Closed:** {pr.closed_at.isoformat()}")

        # Link to original
        if pr.html_url:
            parts.append(f"**Original PR:** {pr.html_url}")

        # Activity timeline for historical context
        if include_activity_timeline and activity_timeline:
            parts.append("")
            parts.append(activity_timeline)

        return "\n".join(parts)

    def _resolve_user(self, bb_username: str) -> tuple[str | None, str | None]:
        """Resolve a Bitbucket username to GitHub username.

        Args:
            bb_username: Bitbucket username.

        Returns:
            Tuple of (github_username, attribution_note).
        """
        if self._user_mapping:
            return self._user_mapping.resolve_user(bb_username)

        # No mapping available - use attribution note
        return None, f"[Migrated from Bitbucket: @{bb_username}]"

    async def _request_reviewers(
        self,
        repo: str,
        pr_number: int,
        reviewers: list[PRReviewer],
        result: PRMigrationResult,
        *,
        pr_author_username: str | None = None,
    ) -> None:
        """Request reviewers on a GitHub PR.

        Args:
            repo: Target repository.
            pr_number: PR number.
            reviewers: List of reviewers.
            result: Result to update with counts.
            pr_author_username: GitHub username of the PR author, to filter out
                (GitHub API rejects requesting review from the PR author).
        """
        gh_reviewers = []

        for reviewer in reviewers:
            target_user, _ = self._resolve_user(reviewer.username)
            if target_user:
                if pr_author_username and target_user == pr_author_username:
                    result.reviewers_skipped += 1
                    logger.debug(
                        "reviewer_skipped",
                        bb_user=reviewer.username,
                        gh_user=target_user,
                        reason="reviewer_is_pr_author",
                    )
                else:
                    gh_reviewers.append(target_user)
                    result.reviewers_requested += 1
            else:
                result.reviewers_skipped += 1
                logger.debug(
                    "reviewer_skipped",
                    bb_user=reviewer.username,
                    reason="unmapped",
                )

        if gh_reviewers:
            try:
                await self._target.request_reviewers(repo, pr_number, gh_reviewers)
            except Exception as e:
                logger.warning(
                    "failed_to_request_reviewers",
                    error=str(e),
                    reviewers=gh_reviewers,
                )

    async def _apply_labels(
        self,
        repo: str,
        pr_number: int,
        labels: list[str],
        result: PRMigrationResult,
    ) -> None:
        """Apply labels to a GitHub PR.

        Args:
            repo: Target repository.
            pr_number: PR number (issues and PRs share numbers).
            labels: List of label names.
            result: Result to update with count.
        """
        try:
            # Ensure labels exist
            for label in labels:
                await self._target.ensure_label(repo, label)

            # Apply labels to PR
            await self._target.add_labels(repo, pr_number, labels)
            result.labels_applied = len(labels)

        except Exception as e:
            logger.warning(
                "failed_to_apply_labels",
                error=str(e),
                labels=labels,
            )

    async def _add_merge_commit_comment(
        self,
        repo: str,
        pr_number: int,
        merge_commit_hash: str,
    ) -> None:
        """Add a comment about the merge commit.

        Args:
            repo: Target repository.
            pr_number: PR number.
            merge_commit_hash: Original merge commit hash.
        """
        try:
            comment = f"**Merge commit:** `{merge_commit_hash}`"
            await self._target.create_issue_comment(repo, pr_number, comment)
        except Exception as e:
            logger.warning(
                "failed_to_add_merge_commit_comment",
                error=str(e),
            )

    async def migrate_repository_prs(
        self,
        source_repo: str,
        target_repo: str,
        *,
        include_closed: bool = True,
        since: datetime | None = None,
        gei_archive_url: str | None = None,
    ) -> PRMigrationStats:
        """Migrate all PRs from a repository.

        Supports two migration modes:
        1. Enterprise Importer (GEI) - For GitHub Enterprise, uses archive-based
           migration for closed PRs to preserve full historical state.
        2. Standard API - For regular GitHub, creates PRs via REST API with
           Issue fallback when source branches are missing.

        The mode is auto-detected based on target capabilities.

        Args:
            source_repo: Source repository (workspace/repo).
            target_repo: Target repository (org/repo).
            include_closed: Whether to include closed/merged PRs.
            since: Only include PRs updated after this date.
            gei_archive_url: Base URL where GEI archives can be uploaded.
                             Required for GEI migration to work.

        Returns:
            PRMigrationStats with migration results.
        """
        stats = PRMigrationStats()

        logger.info(
            "starting_pr_migration",
            source=source_repo,
            target=target_repo,
            include_closed=include_closed,
        )

        # Check if Enterprise Importer is available for closed PR migration
        use_gei_for_closed = False
        if include_closed and await self._check_enterprise_importer():
            use_gei_for_closed = True
            logger.info("using_enterprise_importer_for_closed_prs")

        # Migrate open PRs (always use standard API)
        async for pr in self.fetch_open_prs(source_repo):
            stats.total += 1
            result = await self.create_github_pr(pr, target_repo)
            stats.results.append(result)

            if result.success:
                stats.migrated += 1
                stats.open_migrated += 1
                stats.migrated_as_prs += 1
            else:
                stats.failed += 1

        # Migrate closed PRs
        if include_closed:
            if use_gei_for_closed:
                # Collect all closed PRs for batch GEI migration
                closed_prs: list[PullRequest] = []
                async for pr in self.fetch_closed_prs(source_repo, since=since):
                    closed_prs.append(pr)

                if closed_prs:
                    gei_stats = await self.migrate_closed_prs_via_gei(
                        closed_prs,
                        source_repo,
                        target_repo,
                        archive_base_url=gei_archive_url,
                    )
                    # Merge GEI stats into main stats
                    stats.total += gei_stats.total
                    stats.migrated += gei_stats.migrated
                    stats.failed += gei_stats.failed
                    stats.skipped += gei_stats.skipped
                    stats.merged_migrated += gei_stats.merged_migrated
                    stats.declined_migrated += gei_stats.declined_migrated
                    stats.migrated_as_prs += gei_stats.migrated_as_prs
                    stats.migrated_as_issues += gei_stats.migrated_as_issues
                    stats.results.extend(gei_stats.results)
            else:
                # Standard API approach with Issue fallback
                async for pr in self.fetch_closed_prs(source_repo, since=since):
                    stats.total += 1
                    result = await self.create_closed_github_pr(pr, target_repo)
                    stats.results.append(result)

                    if result.success:
                        stats.migrated += 1
                        if pr.is_merged:
                            stats.merged_migrated += 1
                        else:
                            stats.declined_migrated += 1
                        # Track migration type
                        if result.migrated_as_issue:
                            stats.migrated_as_issues += 1
                        else:
                            stats.migrated_as_prs += 1
                    else:
                        stats.failed += 1

        logger.info(
            "pr_migration_complete",
            source=source_repo,
            total=stats.total,
            migrated=stats.migrated,
            failed=stats.failed,
            used_gei=use_gei_for_closed,
        )

        return stats
