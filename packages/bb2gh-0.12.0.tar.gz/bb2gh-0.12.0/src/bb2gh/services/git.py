"""Git operations service for bb2gh.

Handles git clone, push, and related operations for repository migration.
"""

from __future__ import annotations

import asyncio
import contextlib
import os
import shutil
import tempfile
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import StrEnum
from pathlib import Path

import structlog

from bb2gh.exceptions import BB2GHError
from bb2gh.models.plan import TransferMode

logger = structlog.get_logger(__name__)


class GitError(BB2GHError):
    """Git operation failed."""

    pass


class AuthMethod(StrEnum):
    """Authentication method for git operations."""

    HTTPS = "https"
    SSH = "ssh"


@dataclass
class GitProgress:
    """Progress information for git operations."""

    operation: str  # "clone", "push", "fetch"
    phase: str  # "counting", "compressing", "receiving", "resolving"
    current: int = 0
    total: int = 0
    percent: float = 0.0
    message: str = ""


@dataclass
class CloneResult:
    """Result of a git clone operation."""

    local_path: Path
    branch_count: int = 0
    tag_count: int = 0
    commit_count: int = 0
    size_bytes: int = 0
    default_branch: str = "main"
    has_lfs: bool = False
    lfs_patterns: list[str] = field(default_factory=list)


@dataclass
class PushResult:
    """Result of a git push operation."""

    refs_pushed: int = 0
    branches_pushed: int = 0
    tags_pushed: int = 0
    success: bool = True
    error_message: str | None = None


@dataclass
class ChunkedPushResult:
    """Result of a chunked push operation."""

    total_refs: int = 0
    refs_pushed: int = 0
    branches_pushed: int = 0
    tags_pushed: int = 0
    chunks_completed: int = 0
    chunks_total: int = 0
    success: bool = True
    failed_refs: list[str] = field(default_factory=list)
    error_message: str | None = None

    @property
    def percent_complete(self) -> float:
        """Percentage of refs pushed."""
        if self.total_refs == 0:
            return 100.0
        return (self.refs_pushed / self.total_refs) * 100


@dataclass
class VerificationResult:
    """Result of migration verification."""

    success: bool = True

    # Branch verification
    source_branches: int = 0
    target_branches: int = 0
    missing_branches: list[str] = field(default_factory=list)
    extra_branches: list[str] = field(default_factory=list)

    # Tag verification
    source_tags: int = 0
    target_tags: int = 0
    missing_tags: list[str] = field(default_factory=list)
    extra_tags: list[str] = field(default_factory=list)

    # Commit verification (optional deep check)
    commit_mismatches: dict[str, tuple[str, str]] = field(default_factory=dict)

    # Default branch
    source_default_branch: str = "main"
    target_default_branch: str = "main"
    default_branch_match: bool = True

    # Summary
    error_messages: list[str] = field(default_factory=list)

    @property
    def branches_match(self) -> bool:
        """Check if all branches match."""
        return len(self.missing_branches) == 0

    @property
    def tags_match(self) -> bool:
        """Check if all tags match."""
        return len(self.missing_tags) == 0


@dataclass
class LFSInfo:
    """Information about LFS objects in a repository."""

    has_lfs: bool = False
    patterns: list[str] = field(default_factory=list)
    object_count: int = 0
    total_size_bytes: int = 0

    @property
    def total_size_mb(self) -> float:
        """Total size in megabytes."""
        return self.total_size_bytes / (1024 * 1024)


@dataclass
class LFSMigrationResult:
    """Result of LFS migration operation."""

    success: bool = True
    lfs_available: bool = True
    objects_fetched: int = 0
    objects_pushed: int = 0
    bytes_transferred: int = 0
    error_message: str | None = None
    quota_exceeded: bool = False
    skipped: bool = False  # True if LFS was skipped (not available or not needed)


# Type alias for progress callback
ProgressCallback = Callable[[GitProgress], None]


class GitService:
    """Service for git operations.

    Handles cloning from source and pushing to target with progress reporting.
    """

    def __init__(
        self,
        *,
        work_dir: Path | str | None = None,
        git_executable: str = "git",
        timeout_seconds: int = 3600,  # 1 hour default
    ) -> None:
        """Initialize GitService.

        Args:
            work_dir: Working directory for git operations. If None, uses temp dir.
            git_executable: Path to git executable.
            timeout_seconds: Timeout for git operations in seconds.
        """
        self._work_dir = Path(work_dir) if work_dir else None
        self._git = git_executable
        self._timeout = timeout_seconds
        self._temp_dirs: list[Path] = []

    async def __aenter__(self) -> GitService:
        """Async context manager entry."""
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: object,
    ) -> None:
        """Async context manager exit - cleanup temp directories."""
        await self.cleanup()

    async def cleanup(self) -> None:
        """Clean up temporary directories."""
        for temp_dir in self._temp_dirs:
            if temp_dir.exists():
                logger.debug("Cleaning up temp directory", path=str(temp_dir))
                shutil.rmtree(temp_dir, ignore_errors=True)
        self._temp_dirs.clear()

    def _get_work_dir(self) -> Path:
        """Get or create working directory.

        Returns:
            Path to working directory.
        """
        if self._work_dir:
            self._work_dir.mkdir(parents=True, exist_ok=True)
            return self._work_dir

        # Create a temp directory
        temp_dir = Path(tempfile.mkdtemp(prefix="bb2gh-"))
        self._temp_dirs.append(temp_dir)
        return temp_dir

    async def _run_git(
        self,
        args: list[str],
        *,
        cwd: Path | None = None,
        env: dict[str, str] | None = None,
        capture_stderr: bool = True,
        progress_callback: ProgressCallback | None = None,
        stream_progress: bool = False,
    ) -> tuple[int, str, str]:
        """Run a git command asynchronously.

        Args:
            args: Git command arguments.
            cwd: Working directory.
            env: Additional environment variables.
            capture_stderr: Whether to capture stderr.
            progress_callback: Optional callback for progress updates.
            stream_progress: If True, stream stderr and call progress callback in real-time.

        Returns:
            Tuple of (return_code, stdout, stderr).
        """
        cmd = [self._git, *args]
        full_env = os.environ.copy()
        if env:
            full_env.update(env)

        # Git progress goes to stderr
        logger.debug("Running git command", cmd=" ".join(cmd), cwd=str(cwd or "."))

        process = await asyncio.create_subprocess_exec(
            *cmd,
            cwd=cwd,
            env=full_env,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE if capture_stderr else None,
        )

        # Stream progress in real-time if requested and callback provided
        if stream_progress and progress_callback and capture_stderr:
            stdout, stderr = await self._stream_git_output(process, progress_callback)
        else:
            stdout_data, stderr_data = await asyncio.wait_for(
                process.communicate(), timeout=self._timeout
            )

            stdout = stdout_data.decode("utf-8", errors="replace") if stdout_data else ""
            stderr = stderr_data.decode("utf-8", errors="replace") if stderr_data else ""

            # Parse progress from stderr if callback provided (batch mode)
            if progress_callback and stderr:
                self._parse_progress(stderr, progress_callback)

        return process.returncode or 0, stdout, stderr

    async def _stream_git_output(
        self,
        process: asyncio.subprocess.Process,
        progress_callback: ProgressCallback,
    ) -> tuple[str, str]:
        """Stream git output and call progress callback in real-time.

        Args:
            process: The running subprocess.
            progress_callback: Callback for progress updates.

        Returns:
            Tuple of (stdout, stderr) as accumulated strings.
        """
        stdout_chunks: list[str] = []
        stderr_chunks: list[str] = []
        stderr_buffer = ""

        async def read_stdout() -> None:
            """Read stdout to completion."""
            if process.stdout:
                while True:
                    chunk = await process.stdout.read(4096)
                    if not chunk:
                        break
                    stdout_chunks.append(chunk.decode("utf-8", errors="replace"))

        async def read_stderr() -> None:
            """Read stderr with progress parsing."""
            nonlocal stderr_buffer
            if process.stderr:
                while True:
                    chunk = await process.stderr.read(256)  # Smaller chunks for responsiveness
                    if not chunk:
                        break
                    text = chunk.decode("utf-8", errors="replace")
                    stderr_chunks.append(text)
                    stderr_buffer += text

                    # Git uses \r for progress updates, process complete lines
                    while "\r" in stderr_buffer or "\n" in stderr_buffer:
                        # Find the first line terminator
                        r_pos = stderr_buffer.find("\r")
                        n_pos = stderr_buffer.find("\n")

                        if r_pos == -1:
                            pos = n_pos
                        elif n_pos == -1:
                            pos = r_pos
                        else:
                            pos = min(r_pos, n_pos)

                        line = stderr_buffer[:pos]
                        stderr_buffer = stderr_buffer[pos + 1 :]

                        if line.strip():
                            self._parse_progress(line, progress_callback)

        try:
            # Read both streams concurrently with timeout
            await asyncio.wait_for(
                asyncio.gather(read_stdout(), read_stderr()),
                timeout=self._timeout,
            )
        except TimeoutError:
            process.kill()
            raise

        await process.wait()

        return "".join(stdout_chunks), "".join(stderr_chunks)

    def _parse_progress(self, output: str, callback: ProgressCallback) -> None:
        """Parse git progress output and invoke callback.

        Args:
            output: Git stderr output.
            callback: Progress callback function.
        """
        # Git progress output uses \r for in-place updates with percentage and counts
        for line in output.split("\r"):
            line = line.strip()
            if not line:
                continue

            progress = GitProgress(operation="git", phase="unknown", message=line)

            # Try to parse percentage
            if "%" in line:
                try:
                    # Extract phase (e.g., "Receiving objects")
                    if ":" in line:
                        phase_part = line.split(":")[0].strip()
                        progress.phase = phase_part.lower().replace(" ", "_")

                    # Extract percentage
                    pct_part = line.split("%")[0]
                    pct_str = pct_part.split()[-1]
                    progress.percent = float(pct_str)

                    # Extract counts if present (e.g., "5/10")
                    if "(" in line and "/" in line:
                        counts = line.split("(")[1].split(")")[0]
                        if "/" in counts:
                            current, total = counts.split("/")
                            progress.current = int(current.strip())
                            progress.total = int(total.strip())
                except (ValueError, IndexError):
                    pass

            callback(progress)

    async def clone_mirror(
        self,
        clone_url: str,
        *,
        repo_name: str | None = None,
        auth_token: str | None = None,
        progress_callback: ProgressCallback | None = None,
    ) -> CloneResult:
        """Clone a repository using git clone --mirror.

        This creates a bare mirror clone that includes all refs (branches, tags).

        Args:
            clone_url: URL to clone from (HTTPS or SSH).
            repo_name: Optional name for the local directory.
            auth_token: Optional auth token for HTTPS URLs.
            progress_callback: Optional callback for progress updates.

        Returns:
            CloneResult with information about the cloned repository.

        Raises:
            GitError: If clone fails.
        """
        work_dir = self._get_work_dir()

        # Determine repo name from URL if not provided
        if not repo_name:
            repo_name = clone_url.rstrip("/").split("/")[-1]
            if repo_name.endswith(".git"):
                repo_name = repo_name[:-4]

        local_path = work_dir / f"{repo_name}.git"

        # Remove existing directory if present
        if local_path.exists():
            shutil.rmtree(local_path)

        # Build clone URL with auth if needed
        effective_url = clone_url
        env: dict[str, str] = {}

        if auth_token and clone_url.startswith("https://"):
            # Use GIT_ASKPASS to inject credentials
            # This avoids putting credentials in the URL
            env["GIT_ASKPASS"] = "echo"
            env["GIT_PASSWORD"] = auth_token

            # Or use credential helper
            # Insert token into URL for basic auth
            if "@" not in clone_url:
                # Format: https://x-token-auth:TOKEN@bitbucket.org/...
                url_parts = clone_url.split("://", 1)
                if len(url_parts) == 2:
                    effective_url = f"{url_parts[0]}://x-token-auth:{auth_token}@{url_parts[1]}"

        logger.info(
            "Cloning repository",
            url=clone_url,  # Log original URL, not with token
            local_path=str(local_path),
        )

        # Run git clone --mirror with real-time progress streaming
        args = ["clone", "--mirror", "--progress", effective_url, str(local_path)]

        returncode, stdout, stderr = await self._run_git(
            args,
            env=env,
            progress_callback=progress_callback,
            stream_progress=True,  # Enable real-time progress
        )

        if returncode != 0:
            error_msg = stderr or stdout or f"Clone failed with exit code {returncode}"
            # Don't include auth token in error message
            error_msg = error_msg.replace(auth_token, "***") if auth_token else error_msg
            logger.error("Clone failed", error=error_msg)
            raise GitError(f"Failed to clone repository: {error_msg}")

        # Gather information about the cloned repository
        result = await self._analyze_mirror(local_path)
        result.local_path = local_path

        logger.info(
            "Clone complete",
            local_path=str(local_path),
            branches=result.branch_count,
            tags=result.tag_count,
            commits=result.commit_count,
        )

        return result

    async def _analyze_mirror(self, repo_path: Path) -> CloneResult:
        """Analyze a mirror clone to gather statistics.

        Args:
            repo_path: Path to the bare git repository.

        Returns:
            CloneResult with repository statistics.
        """
        result = CloneResult(local_path=repo_path)

        # Count branches
        returncode, stdout, _ = await self._run_git(["branch", "--list"], cwd=repo_path)
        if returncode == 0:
            branches = [b.strip().lstrip("* ") for b in stdout.strip().split("\n") if b.strip()]
            result.branch_count = len(branches)

        # Count tags
        returncode, stdout, _ = await self._run_git(["tag", "--list"], cwd=repo_path)
        if returncode == 0:
            tags = [t.strip() for t in stdout.strip().split("\n") if t.strip()]
            result.tag_count = len(tags)

        # Count commits
        returncode, stdout, _ = await self._run_git(["rev-list", "--all", "--count"], cwd=repo_path)
        if returncode == 0:
            with contextlib.suppress(ValueError):
                result.commit_count = int(stdout.strip())

        # Get default branch
        returncode, stdout, _ = await self._run_git(["symbolic-ref", "HEAD"], cwd=repo_path)
        if returncode == 0:
            # Output is refs/heads/main
            ref = stdout.strip()
            if ref.startswith("refs/heads/"):
                result.default_branch = ref[len("refs/heads/") :]

        # Calculate size
        try:
            total_size = sum(f.stat().st_size for f in repo_path.rglob("*") if f.is_file())
            result.size_bytes = total_size
        except OSError:
            pass

        # Check for LFS
        result.has_lfs, result.lfs_patterns = await self._check_lfs(repo_path)

        return result

    async def _check_lfs(self, repo_path: Path) -> tuple[bool, list[str]]:
        """Check if repository uses Git LFS.

        Args:
            repo_path: Path to the git repository.

        Returns:
            Tuple of (has_lfs, lfs_patterns).
        """
        # Check for .gitattributes with LFS entries
        # In a bare repo, we need to get the file from the tree
        returncode, stdout, _ = await self._run_git(["show", "HEAD:.gitattributes"], cwd=repo_path)

        if returncode != 0:
            return False, []

        patterns = []
        for line in stdout.split("\n"):
            line = line.strip()
            if "filter=lfs" in line:
                # Extract the pattern (first part before space)
                pattern = line.split()[0] if line.split() else ""
                if pattern:
                    patterns.append(pattern)

        return bool(patterns), patterns

    async def push_mirror(
        self,
        local_path: Path,
        push_url: str,
        *,
        auth_token: str | None = None,
        transfer_mode: TransferMode = TransferMode.MIRROR,
        progress_callback: ProgressCallback | None = None,
    ) -> PushResult:
        """Push a mirror clone to a target repository.

        Args:
            local_path: Path to the local mirror clone.
            push_url: URL to push to.
            auth_token: Optional auth token for HTTPS URLs.
            transfer_mode: What to push (mirror, branches-only, main-only).
            progress_callback: Optional callback for progress updates.

        Returns:
            PushResult with push statistics.

        Raises:
            GitError: If push fails.
        """
        if not local_path.exists():
            raise GitError(f"Local repository not found: {local_path}")

        # Build push URL with auth if needed
        effective_url = push_url
        env: dict[str, str] = {}

        if auth_token and push_url.startswith("https://") and "@" not in push_url:
            url_parts = push_url.split("://", 1)
            if len(url_parts) == 2:
                effective_url = f"{url_parts[0]}://x-token-auth:{auth_token}@{url_parts[1]}"

        logger.info(
            "Pushing repository",
            url=push_url,  # Log original URL
            local_path=str(local_path),
            mode=transfer_mode.value,
        )

        # Build push command based on transfer mode
        args = self._build_push_args(effective_url, transfer_mode, local_path)

        returncode, stdout, stderr = await self._run_git(
            args,
            cwd=local_path,
            env=env,
            progress_callback=progress_callback,
            stream_progress=True,  # Enable real-time progress
        )

        if returncode != 0:
            error_msg = stderr or stdout or f"Push failed with exit code {returncode}"
            error_msg = error_msg.replace(auth_token, "***") if auth_token else error_msg
            logger.error("Push failed", error=error_msg)
            return PushResult(success=False, error_message=error_msg)

        # Parse push output to count refs
        result = self._parse_push_output(stdout, stderr)
        logger.info(
            "Push complete",
            branches=result.branches_pushed,
            tags=result.tags_pushed,
        )

        return result

    def _build_push_args(
        self,
        push_url: str,
        transfer_mode: TransferMode,
        _local_path: Path,
    ) -> list[str]:
        """Build git push arguments based on transfer mode.

        Args:
            push_url: URL to push to.
            transfer_mode: What to push.
            _local_path: Path to local repo (for reading refs).

        Returns:
            List of git push arguments.
        """
        if transfer_mode == TransferMode.MIRROR:
            return ["push", "--mirror", "--progress", push_url]

        elif transfer_mode == TransferMode.BRANCHES_ONLY:
            # Push all branches but no tags
            return ["push", "--all", "--progress", push_url]

        elif transfer_mode == TransferMode.MAIN_ONLY:
            # Push only the default branch
            # We need to get the default branch name
            return ["push", "--progress", push_url, "HEAD:refs/heads/main"]

        return ["push", "--mirror", "--progress", push_url]

    def _parse_push_output(self, stdout: str, stderr: str) -> PushResult:
        """Parse git push output to extract statistics.

        Args:
            stdout: Command stdout.
            stderr: Command stderr.

        Returns:
            PushResult with parsed statistics.
        """
        result = PushResult(success=True)

        # Count refs in output
        # Format: "To https://github.com/...
        #          * [new branch]      main -> main
        #          * [new tag]         v1.0.0 -> v1.0.0"
        output = stdout + "\n" + stderr
        for line in output.split("\n"):
            line = line.strip()
            if "[new branch]" in line or "-> refs/heads/" in line:
                result.branches_pushed += 1
            elif "[new tag]" in line or "-> refs/tags/" in line:
                result.tags_pushed += 1

        result.refs_pushed = result.branches_pushed + result.tags_pushed

        return result

    async def list_refs(self, repo_path: Path) -> tuple[list[str], list[str]]:
        """List all refs (branches and tags) in a repository.

        Args:
            repo_path: Path to the git repository.

        Returns:
            Tuple of (branches, tags) as lists of ref names.
        """
        branches = []
        tags = []

        # List branches
        returncode, stdout, _ = await self._run_git(
            ["for-each-ref", "--format=%(refname)", "refs/heads/"],
            cwd=repo_path,
        )
        if returncode == 0:
            branches = [r.strip() for r in stdout.strip().split("\n") if r.strip()]

        # List tags
        returncode, stdout, _ = await self._run_git(
            ["for-each-ref", "--format=%(refname)", "refs/tags/"],
            cwd=repo_path,
        )
        if returncode == 0:
            tags = [r.strip() for r in stdout.strip().split("\n") if r.strip()]

        return branches, tags

    async def push_chunked(
        self,
        local_path: Path,
        push_url: str,
        *,
        auth_token: str | None = None,
        batch_size: int = 50,
        transfer_mode: TransferMode = TransferMode.MIRROR,
        progress_callback: ProgressCallback | None = None,
        resume_from: list[str] | None = None,
    ) -> ChunkedPushResult:
        """Push a repository in chunks for large repos.

        This is useful for repositories with many refs that may timeout
        or fail when pushing all at once.

        Args:
            local_path: Path to the local mirror clone.
            push_url: URL to push to.
            auth_token: Optional auth token for HTTPS URLs.
            batch_size: Number of refs per batch.
            transfer_mode: What to push (mirror, branches-only, main-only).
            progress_callback: Optional callback for progress updates.
            resume_from: List of failed refs to retry from previous attempt.

        Returns:
            ChunkedPushResult with detailed push statistics.

        Raises:
            GitError: If local repository not found.
        """
        if not local_path.exists():
            raise GitError(f"Local repository not found: {local_path}")

        result = ChunkedPushResult()

        # Build effective URL with auth
        effective_url = push_url
        if auth_token and push_url.startswith("https://") and "@" not in push_url:
            url_parts = push_url.split("://", 1)
            if len(url_parts) == 2:
                effective_url = f"{url_parts[0]}://x-token-auth:{auth_token}@{url_parts[1]}"

        # Get refs to push based on transfer mode
        refs_to_push = await self._get_refs_for_mode(local_path, transfer_mode, resume_from)

        if not refs_to_push:
            logger.info("No refs to push")
            result.success = True
            return result

        result.total_refs = len(refs_to_push)

        # Calculate chunks
        chunks = [refs_to_push[i : i + batch_size] for i in range(0, len(refs_to_push), batch_size)]
        result.chunks_total = len(chunks)

        logger.info(
            "Starting chunked push",
            total_refs=result.total_refs,
            batch_size=batch_size,
            chunks=result.chunks_total,
        )

        # Push each chunk
        for chunk_idx, chunk in enumerate(chunks):
            if progress_callback:
                progress = GitProgress(
                    operation="push",
                    phase="chunked_push",
                    current=chunk_idx + 1,
                    total=result.chunks_total,
                    percent=(chunk_idx / result.chunks_total) * 100,
                    message=f"Pushing chunk {chunk_idx + 1}/{result.chunks_total}",
                )
                progress_callback(progress)

            chunk_success = await self._push_refs_batch(
                local_path,
                effective_url,
                chunk,
                auth_token,
            )

            if chunk_success:
                result.chunks_completed += 1
                # Count what we pushed
                for ref in chunk:
                    result.refs_pushed += 1
                    if ref.startswith("refs/heads/"):
                        result.branches_pushed += 1
                    elif ref.startswith("refs/tags/"):
                        result.tags_pushed += 1
            else:
                # Track failed refs for potential retry
                result.failed_refs.extend(chunk)
                logger.warning(
                    "Chunk push failed",
                    chunk=chunk_idx + 1,
                    refs=len(chunk),
                )

        # Determine overall success
        if result.failed_refs:
            result.success = False
            result.error_message = (
                f"Failed to push {len(result.failed_refs)} refs out of {result.total_refs}"
            )
        else:
            result.success = True

        logger.info(
            "Chunked push complete",
            success=result.success,
            refs_pushed=result.refs_pushed,
            failed=len(result.failed_refs),
        )

        return result

    async def _get_refs_for_mode(
        self,
        local_path: Path,
        transfer_mode: TransferMode,
        resume_from: list[str] | None = None,
    ) -> list[str]:
        """Get list of refs to push based on transfer mode.

        Args:
            local_path: Path to the git repository.
            transfer_mode: What to push.
            resume_from: Optional list of refs to resume from.

        Returns:
            List of ref names to push.
        """
        if resume_from:
            return resume_from

        branches, tags = await self.list_refs(local_path)

        if transfer_mode == TransferMode.MIRROR:
            return branches + tags
        elif transfer_mode == TransferMode.BRANCHES_ONLY:
            return branches
        elif transfer_mode == TransferMode.MAIN_ONLY:
            # Find the default branch
            default_branch = await self.get_default_branch(local_path)
            return [f"refs/heads/{default_branch}"]

        return branches + tags

    async def _push_refs_batch(
        self,
        local_path: Path,
        push_url: str,
        refs: list[str],
        auth_token: str | None = None,
    ) -> bool:
        """Push a batch of refs.

        Args:
            local_path: Path to the local repository.
            push_url: URL to push to (with auth if needed).
            refs: List of refs to push.
            auth_token: Auth token for masking in error messages.

        Returns:
            True if push succeeded, False otherwise.
        """
        # Build refspecs: refs/heads/main:refs/heads/main
        refspecs = [f"{ref}:{ref}" for ref in refs]

        args = ["push", "--progress", push_url, *refspecs]

        returncode, stdout, stderr = await self._run_git(
            args,
            cwd=local_path,
        )

        if returncode != 0:
            error_msg = stderr or stdout
            if auth_token:
                error_msg = error_msg.replace(auth_token, "***")
            logger.warning("Batch push failed", error=error_msg)
            return False

        return True

    async def fetch_lfs(
        self,
        local_path: Path,
        *,
        source_url: str | None = None,
        auth_token: str | None = None,
        auth_username: str | None = None,
        progress_callback: ProgressCallback | None = None,
    ) -> bool:
        """Fetch LFS objects for a repository.

        Args:
            local_path: Path to the git repository.
            source_url: Source repository URL (for LFS authentication).
            auth_token: Auth token for source repository.
            auth_username: Username for authentication (required for Bitbucket Cloud).
            progress_callback: Optional callback for progress updates.

        Returns:
            True if LFS fetch succeeded, False otherwise.
        """
        logger.info("Fetching LFS objects", local_path=str(local_path))

        # First, check if git-lfs is available
        returncode, _, _ = await self._run_git(["lfs", "version"])
        if returncode != 0:
            logger.warning("git-lfs not available, skipping LFS fetch")
            return False

        # Configure LFS URL with credentials if provided
        if source_url and auth_token:
            effective_url = source_url
            if source_url.startswith("https://"):
                # Extract username from URL if not provided
                username = auth_username
                if not username and "@" in source_url:
                    # URL format: https://user@host/path -> extract user
                    proto, rest = source_url.split("://", 1)
                    if "@" in rest:
                        username = rest.split("@", 1)[0]

                # Remove existing auth from URL
                if "@" in source_url:
                    proto, rest = source_url.split("://", 1)
                    if "@" in rest:
                        rest = rest.split("@", 1)[1]
                    effective_url = f"{proto}://{rest}"

                # Add basic auth to URL (username:password format for Bitbucket Cloud)
                url_parts = effective_url.split("://", 1)
                if len(url_parts) == 2:
                    if username:
                        # Use username:token format (works for Bitbucket Cloud App Passwords)
                        effective_url = f"{url_parts[0]}://{username}:{auth_token}@{url_parts[1]}"
                    else:
                        # Fallback to x-token-auth format (works for some services)
                        effective_url = f"{url_parts[0]}://x-token-auth:{auth_token}@{url_parts[1]}"

            # Configure the origin remote URL for LFS fetch
            await self._run_git(
                ["remote", "set-url", "origin", effective_url],
                cwd=local_path,
            )

            # Also set lfs.url to ensure LFS uses the right endpoint
            await self._run_git(
                ["config", "lfs.url", effective_url + "/info/lfs"],
                cwd=local_path,
            )

        # Fetch all LFS objects with real-time progress streaming
        returncode, stdout, stderr = await self._run_git(
            ["lfs", "fetch", "--all"],
            cwd=local_path,
            progress_callback=progress_callback,
            stream_progress=True,  # Enable real-time progress
        )

        if returncode != 0:
            error_msg = stderr or stdout
            if auth_token:
                error_msg = error_msg.replace(auth_token, "***")
            logger.error("LFS fetch failed", error=error_msg)
            return False

        logger.info("LFS fetch complete")
        return True

    async def push_lfs(
        self,
        local_path: Path,
        push_url: str,
        *,
        auth_token: str | None = None,
        progress_callback: ProgressCallback | None = None,
    ) -> bool:
        """Push LFS objects to target.

        Args:
            local_path: Path to the git repository.
            push_url: URL to push to.
            auth_token: Optional auth token for HTTPS URLs.
            progress_callback: Optional callback for progress updates.

        Returns:
            True if LFS push succeeded, False otherwise.
        """
        logger.info("Pushing LFS objects", local_path=str(local_path))

        # Set up LFS remote with auth embedded in URL
        effective_url = push_url
        lfs_url = push_url + "/info/lfs"
        if auth_token and push_url.startswith("https://") and "@" not in push_url:
            url_parts = push_url.split("://", 1)
            if len(url_parts) == 2:
                # Use x-access-token format for GitHub LFS
                effective_url = f"{url_parts[0]}://x-access-token:{auth_token}@{url_parts[1]}"
                lfs_url = effective_url + "/info/lfs"

        # Configure LFS URL with auth
        await self._run_git(
            ["config", "lfs.url", lfs_url],
            cwd=local_path,
        )

        # Disable LFS lock verification (not supported by all servers)
        await self._run_git(
            ["config", "lfs.locksverify", "false"],
            cwd=local_path,
        )

        # Set the remote URL for LFS push
        await self._run_git(
            ["remote", "set-url", "origin", effective_url],
            cwd=local_path,
        )

        # Push LFS objects with real-time progress streaming
        returncode, stdout, stderr = await self._run_git(
            ["lfs", "push", "--all", "origin"],
            cwd=local_path,
            progress_callback=progress_callback,
            stream_progress=True,  # Enable real-time progress
            env={"GIT_TERMINAL_PROMPT": "0"},
        )

        if returncode != 0:
            error_msg = stderr or stdout
            # Mask token in error output
            if auth_token:
                error_msg = error_msg.replace(auth_token, "***")
            logger.error("LFS push failed", error=error_msg)
            return False

        logger.info("LFS push complete")
        return True

    async def get_lfs_info(self, repo_path: Path) -> LFSInfo:
        """Get detailed LFS information for a repository.

        Args:
            repo_path: Path to the git repository.

        Returns:
            LFSInfo with LFS details.
        """
        info = LFSInfo()

        # Check for LFS patterns
        info.has_lfs, info.patterns = await self._check_lfs(repo_path)

        if not info.has_lfs:
            return info

        # Try to get LFS object stats
        returncode, stdout, _ = await self._run_git(
            ["lfs", "ls-files", "--all", "-l"],
            cwd=repo_path,
        )

        if returncode == 0 and stdout.strip():
            lines = stdout.strip().split("\n")
            info.object_count = len(lines)

            # Parse size from output (format: "oid - filename (size)")
            for line in lines:
                # Try to extract size
                if "(" in line and ")" in line:
                    try:
                        size_part = line.rsplit("(", 1)[1].rstrip(")")
                        # Convert size string to bytes
                        info.total_size_bytes += self._parse_size(size_part)
                    except (ValueError, IndexError):
                        pass

        return info

    def _parse_size(self, size_str: str) -> int:
        """Parse a size string like '1.5 MB' to bytes.

        Args:
            size_str: Size string with optional unit.

        Returns:
            Size in bytes.
        """
        size_str = size_str.strip().upper()

        multipliers = {
            "B": 1,
            "KB": 1024,
            "MB": 1024 * 1024,
            "GB": 1024 * 1024 * 1024,
            "TB": 1024 * 1024 * 1024 * 1024,
        }

        for unit, mult in multipliers.items():
            if size_str.endswith(unit):
                try:
                    num = float(size_str[: -len(unit)].strip())
                    return int(num * mult)
                except ValueError:
                    pass

        # Try to parse as plain number
        try:
            return int(float(size_str))
        except ValueError:
            return 0

    async def is_lfs_available(self) -> bool:
        """Check if git-lfs is available on the system.

        Returns:
            True if git-lfs is available.
        """
        returncode, _, _ = await self._run_git(["lfs", "version"])
        return returncode == 0

    async def migrate_lfs(
        self,
        local_path: Path,
        push_url: str,
        *,
        auth_token: str | None = None,
        progress_callback: ProgressCallback | None = None,
    ) -> LFSMigrationResult:
        """Migrate LFS objects from source to target.

        This is a comprehensive LFS migration that:
        1. Checks if git-lfs is available
        2. Fetches all LFS objects from source
        3. Pushes all LFS objects to target
        4. Handles errors gracefully

        Args:
            local_path: Path to the local mirror clone.
            push_url: URL to push LFS objects to.
            auth_token: Optional auth token for HTTPS URLs.
            progress_callback: Optional callback for progress updates.

        Returns:
            LFSMigrationResult with detailed status.
        """
        result = LFSMigrationResult()

        # Check if git-lfs is available
        if not await self.is_lfs_available():
            result.lfs_available = False
            result.skipped = True
            result.error_message = "git-lfs not installed"
            logger.warning("git-lfs not available, skipping LFS migration")
            return result

        # Check if repo has LFS
        lfs_info = await self.get_lfs_info(local_path)
        if not lfs_info.has_lfs:
            result.skipped = True
            logger.info("Repository does not use LFS, skipping")
            return result

        logger.info(
            "Starting LFS migration",
            objects=lfs_info.object_count,
            size_mb=f"{lfs_info.total_size_mb:.2f}",
        )

        # Fetch LFS objects
        if progress_callback:
            progress = GitProgress(
                operation="lfs",
                phase="fetching",
                message="Fetching LFS objects from source",
            )
            progress_callback(progress)

        fetch_success = await self.fetch_lfs(local_path, progress_callback=progress_callback)
        if not fetch_success:
            result.success = False
            result.error_message = "Failed to fetch LFS objects from source"
            return result

        result.objects_fetched = lfs_info.object_count
        result.bytes_transferred = lfs_info.total_size_bytes

        # Push LFS objects
        if progress_callback:
            progress = GitProgress(
                operation="lfs",
                phase="pushing",
                message="Pushing LFS objects to target",
            )
            progress_callback(progress)

        push_success = await self._push_lfs_with_retry(
            local_path,
            push_url,
            auth_token=auth_token,
            progress_callback=progress_callback,
        )

        if not push_success["success"]:
            result.success = False
            result.error_message = str(push_success.get("error", "Failed to push LFS objects"))
            result.quota_exceeded = bool(push_success.get("quota_exceeded", False))
            return result

        result.objects_pushed = lfs_info.object_count
        result.success = True

        logger.info(
            "LFS migration complete",
            objects=result.objects_pushed,
            size_mb=f"{lfs_info.total_size_mb:.2f}",
        )

        return result

    async def _push_lfs_with_retry(
        self,
        local_path: Path,
        push_url: str,
        *,
        auth_token: str | None = None,
        progress_callback: ProgressCallback | None = None,
        max_retries: int = 3,
    ) -> dict[str, object]:
        """Push LFS objects with retry logic and quota detection.

        Args:
            local_path: Path to the local repository.
            push_url: URL to push to.
            auth_token: Optional auth token.
            progress_callback: Optional progress callback.
            max_retries: Maximum number of retries.

        Returns:
            Dict with success status and error details.
        """
        # Set up LFS remote with auth embedded in URL
        effective_url = push_url
        lfs_url = push_url + "/info/lfs"
        if auth_token and push_url.startswith("https://") and "@" not in push_url:
            url_parts = push_url.split("://", 1)
            if len(url_parts) == 2:
                # Use x-access-token format for GitHub LFS
                effective_url = f"{url_parts[0]}://x-access-token:{auth_token}@{url_parts[1]}"
                lfs_url = effective_url + "/info/lfs"

        # Configure LFS URL with auth
        await self._run_git(
            ["config", "lfs.url", lfs_url],
            cwd=local_path,
        )

        # Disable LFS lock verification (not supported by all servers)
        await self._run_git(
            ["config", "lfs.locksverify", "false"],
            cwd=local_path,
        )

        # Set up remote for push
        await self._run_git(
            ["remote", "set-url", "--push", "origin", effective_url],
            cwd=local_path,
        )

        last_error = ""
        for attempt in range(max_retries):
            returncode, stdout, stderr = await self._run_git(
                ["lfs", "push", "--all", "origin"],
                cwd=local_path,
                progress_callback=progress_callback,
                stream_progress=True,  # Enable real-time progress
                env={"GIT_TERMINAL_PROMPT": "0"},
            )

            if returncode == 0:
                return {"success": True}

            last_error = stderr or stdout
            if auth_token:
                last_error = last_error.replace(auth_token, "***")

            # Check for quota exceeded
            if "quota" in last_error.lower() or "storage limit" in last_error.lower():
                logger.error("LFS quota exceeded", error=last_error)
                return {
                    "success": False,
                    "error": last_error,
                    "quota_exceeded": True,
                }

            # Check for auth errors (don't retry)
            if (
                "401" in last_error
                or "403" in last_error
                or "authentication" in last_error.lower()
                or "authorization" in last_error.lower()
            ):
                logger.error("LFS push auth failed", error=last_error)
                return {
                    "success": False,
                    "error": last_error,
                    "quota_exceeded": False,
                }

            logger.warning(
                "LFS push attempt failed, retrying",
                attempt=attempt + 1,
                max_retries=max_retries,
                error=last_error,
            )

        return {
            "success": False,
            "error": f"LFS push failed after {max_retries} attempts: {last_error}",
            "quota_exceeded": False,
        }

    async def list_branches(self, repo_path: Path) -> list[str]:
        """List all branches in a repository.

        Args:
            repo_path: Path to the git repository.

        Returns:
            List of branch names.
        """
        returncode, stdout, _ = await self._run_git(
            ["branch", "--list", "--format=%(refname:short)"],
            cwd=repo_path,
        )
        if returncode != 0:
            return []

        return [b.strip() for b in stdout.strip().split("\n") if b.strip()]

    async def list_tags(self, repo_path: Path) -> list[str]:
        """List all tags in a repository.

        Args:
            repo_path: Path to the git repository.

        Returns:
            List of tag names.
        """
        returncode, stdout, _ = await self._run_git(["tag", "--list"], cwd=repo_path)
        if returncode != 0:
            return []

        return [t.strip() for t in stdout.strip().split("\n") if t.strip()]

    async def get_default_branch(self, repo_path: Path) -> str:
        """Get the default branch of a repository.

        Args:
            repo_path: Path to the git repository.

        Returns:
            Default branch name, or "main" if not found.
        """
        returncode, stdout, _ = await self._run_git(["symbolic-ref", "HEAD"], cwd=repo_path)
        if returncode == 0:
            ref = stdout.strip()
            if ref.startswith("refs/heads/"):
                return ref[len("refs/heads/") :]

        return "main"

    async def verify_migration(
        self,
        source_path: Path,
        target_path: Path,
        *,
        verify_commits: bool = False,
    ) -> VerificationResult:
        """Verify that a migration was successful by comparing refs.

        Args:
            source_path: Path to source repository.
            target_path: Path to target repository.
            verify_commits: If True, also verify commit hashes match.

        Returns:
            VerificationResult with detailed verification data.
        """
        result = VerificationResult()

        # Get branches
        source_branches = set(await self.list_branches(source_path))
        target_branches = set(await self.list_branches(target_path))

        result.source_branches = len(source_branches)
        result.target_branches = len(target_branches)
        result.missing_branches = list(source_branches - target_branches)
        result.extra_branches = list(target_branches - source_branches)

        # Get tags
        source_tags = set(await self.list_tags(source_path))
        target_tags = set(await self.list_tags(target_path))

        result.source_tags = len(source_tags)
        result.target_tags = len(target_tags)
        result.missing_tags = list(source_tags - target_tags)
        result.extra_tags = list(target_tags - source_tags)

        # Get default branches
        result.source_default_branch = await self.get_default_branch(source_path)
        result.target_default_branch = await self.get_default_branch(target_path)
        result.default_branch_match = result.source_default_branch == result.target_default_branch

        # Optional: verify commit hashes for common branches
        if verify_commits:
            common_branches = source_branches & target_branches
            for branch in common_branches:
                source_hash = await self._get_branch_head(source_path, branch)
                target_hash = await self._get_branch_head(target_path, branch)
                if source_hash and target_hash and source_hash != target_hash:
                    result.commit_mismatches[branch] = (source_hash, target_hash)

        # Determine overall success
        result.success = (
            result.branches_match
            and result.tags_match
            and result.default_branch_match
            and len(result.commit_mismatches) == 0
        )

        # Build error messages
        if result.missing_branches:
            result.error_messages.append(f"Missing branches: {', '.join(result.missing_branches)}")
        if result.missing_tags:
            result.error_messages.append(f"Missing tags: {', '.join(result.missing_tags)}")
        if not result.default_branch_match:
            result.error_messages.append(
                f"Default branch mismatch: source={result.source_default_branch}, "
                f"target={result.target_default_branch}"
            )
        if result.commit_mismatches:
            for branch, (src, tgt) in result.commit_mismatches.items():
                result.error_messages.append(
                    f"Commit mismatch on {branch}: source={src[:8]}, target={tgt[:8]}"
                )

        logger.info(
            "Migration verification complete",
            success=result.success,
            branches_match=result.branches_match,
            tags_match=result.tags_match,
            default_branch_match=result.default_branch_match,
        )

        return result

    async def _get_branch_head(self, repo_path: Path, branch: str) -> str | None:
        """Get the HEAD commit hash for a branch.

        Args:
            repo_path: Path to the git repository.
            branch: Branch name.

        Returns:
            Commit hash or None if branch not found.
        """
        returncode, stdout, _ = await self._run_git(
            ["rev-parse", f"refs/heads/{branch}"],
            cwd=repo_path,
        )
        if returncode == 0:
            return stdout.strip()
        return None

    async def get_commit_count(self, repo_path: Path, ref: str = "HEAD") -> int:
        """Get the total commit count for a ref.

        Args:
            repo_path: Path to the git repository.
            ref: Git ref to count commits from.

        Returns:
            Number of commits, or 0 if error.
        """
        returncode, stdout, _ = await self._run_git(
            ["rev-list", "--count", ref],
            cwd=repo_path,
        )
        if returncode == 0:
            try:
                return int(stdout.strip())
            except ValueError:
                pass
        return 0

    async def compare_commit_counts(
        self,
        source_path: Path,
        target_path: Path,
    ) -> dict[str, tuple[int, int]]:
        """Compare commit counts between source and target for all branches.

        Args:
            source_path: Path to source repository.
            target_path: Path to target repository.

        Returns:
            Dict mapping branch name to (source_count, target_count) for mismatches.
        """
        mismatches = {}

        source_branches = await self.list_branches(source_path)
        target_branches = await self.list_branches(target_path)
        common_branches = set(source_branches) & set(target_branches)

        for branch in common_branches:
            source_count = await self.get_commit_count(source_path, f"refs/heads/{branch}")
            target_count = await self.get_commit_count(target_path, f"refs/heads/{branch}")

            if source_count != target_count:
                mismatches[branch] = (source_count, target_count)

        return mismatches
