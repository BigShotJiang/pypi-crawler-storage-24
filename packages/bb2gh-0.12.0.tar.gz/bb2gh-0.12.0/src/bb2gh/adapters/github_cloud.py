"""GitHub Cloud adapter for bb2gh.

Implements the TargetAdapter interface for GitHub Cloud (github.com).
"""

from __future__ import annotations

from bb2gh.adapters.github_base import GitHubBaseAdapter

# GitHub Cloud API endpoint
GITHUB_CLOUD_API_URL = "https://api.github.com"


class GitHubCloudAdapter(GitHubBaseAdapter):
    """GitHub Cloud API adapter.

    Connects to the standard GitHub Cloud API at api.github.com.

    Example usage:
        # PAT auth
        adapter = GitHubCloudAdapter(token="ghp_xxx")

        # GitHub App auth
        adapter = GitHubCloudAdapter(
            app_id=12345,
            private_key="-----BEGIN RSA PRIVATE KEY-----...",
            installation_id=67890,
        )

        async with adapter:
            repo = await adapter.create_repository(
                name="my-repo",
                organization="my-org",
            )
    """

    @property
    def api_url(self) -> str:
        """Get the GitHub Cloud API URL."""
        return GITHUB_CLOUD_API_URL
