"""Abstract base classes for source and target adapters.

Defines the interface contract that all adapters must implement.
All methods are async for non-blocking I/O operations.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

    from bb2gh.models.analysis import LargeFilesResult, LFSResult
    from bb2gh.models.branch_protection import (
        GitHubRulesetConfig,
        RepoBranchProtection,
    )
    from bb2gh.models.repository import Repository
    from bb2gh.models.user import User


class SourceAdapter(ABC):
    """Abstract base class for source system adapters (e.g., Bitbucket).

    Source adapters provide read-only access to repositories and users
    in the source system during migration discovery and planning.

    All methods are async for efficient I/O handling.
    """

    @abstractmethod
    async def list_repositories(
        self,
        *,
        workspace: str | None = None,
        project: str | None = None,
        page: int = 1,
        page_size: int = 100,
    ) -> list[Repository]:
        """List repositories from the source system.

        Args:
            workspace: Optional workspace/organization filter.
            project: Optional project filter.
            page: Page number for pagination (1-indexed).
            page_size: Number of items per page.

        Returns:
            List of Repository models.
        """
        ...

    @abstractmethod
    async def get_repository(self, repo_id: str) -> Repository | None:
        """Get a single repository by ID or full name.

        Args:
            repo_id: Repository identifier (ID or full name like "workspace/repo").

        Returns:
            Repository model if found, None otherwise.
        """
        ...

    @abstractmethod
    async def list_users(
        self,
        *,
        workspace: str | None = None,
        page: int = 1,
        page_size: int = 100,
    ) -> list[User]:
        """List users from the source system.

        Args:
            workspace: Optional workspace/organization filter.
            page: Page number for pagination (1-indexed).
            page_size: Number of items per page.

        Returns:
            List of User models.
        """
        ...

    @abstractmethod
    async def get_user(self, user_id: str) -> User | None:
        """Get a single user by ID or username.

        Args:
            user_id: User identifier (ID or username).

        Returns:
            User model if found, None otherwise.
        """
        ...

    async def list_workspace_members(
        self,
        workspace: str,
    ) -> AsyncIterator[dict[str, Any]]:
        """List members of a workspace.

        Args:
            workspace: Workspace slug/identifier.

        Yields:
            Dict with member info (username, email, display_name, account_id).
        """
        # Default implementation uses list_users
        users = await self.list_users(workspace=workspace)
        for user in users:
            yield {
                "username": user.username,
                "email": user.email,
                "display_name": user.display_name,
                "account_id": user.id,
                "avatar_url": user.avatar_url,
            }

    async def list_pull_requests(
        self,
        repo_full_name: str,  # noqa: ARG002
        *,
        state: str = "OPEN",  # noqa: ARG002
    ) -> AsyncIterator[dict[str, Any]]:
        """List pull requests for a repository.

        Args:
            repo_full_name: Full repository name (workspace/repo).
            state: PR state filter (OPEN, MERGED, DECLINED, etc.).

        Yields:
            Dict with PR data.
        """
        raise NotImplementedError("list_pull_requests not implemented")
        yield  # pragma: no cover  # makes this a valid async generator

    async def list_pr_comments(
        self,
        repo_full_name: str,  # noqa: ARG002
        pr_id: str,  # noqa: ARG002
    ) -> AsyncIterator[dict[str, Any]]:
        """List comments on a pull request.

        Args:
            repo_full_name: Full repository name (workspace/repo).
            pr_id: Pull request ID.

        Yields:
            Dict with comment data.
        """
        raise NotImplementedError("list_pr_comments not implemented")
        yield  # pragma: no cover  # makes this a valid async generator

    async def get_branch_protection(
        self,
        repo_id: str,
    ) -> RepoBranchProtection | None:
        """Get branch protection data for a repository.

        Fetches branch restrictions, branching model, and default reviewers.

        Args:
            repo_id: Repository identifier (full name like "workspace/repo").

        Returns:
            RepoBranchProtection with all protection data, or None if unavailable.
        """
        raise NotImplementedError("get_branch_protection not implemented")

    async def verify_credentials(self) -> bool:
        """Verify that credentials are valid.

        Returns:
            True if credentials are valid.

        Raises:
            AuthenticationError: If credentials are invalid or missing.
        """
        raise NotImplementedError("verify_credentials not implemented")

    async def count_branches(self, repo_id: str) -> int:
        """Count branches in a repository.

        Args:
            repo_id: Repository identifier (full name like "workspace/repo").

        Returns:
            Total count of branches.
        """
        raise NotImplementedError("count_branches not implemented")

    async def count_pull_requests(
        self,
        repo_id: str,
        *,
        state: str | None = None,
    ) -> int:
        """Count pull requests in a repository.

        Args:
            repo_id: Repository identifier (full name like "workspace/repo").
            state: Optional state filter.

        Returns:
            Total count of pull requests.
        """
        raise NotImplementedError("count_pull_requests not implemented")

    async def analyze_large_files(
        self,
        repo_id: str,
        *,
        branch: str | None = None,
        threshold_bytes: int = 100_000_000,
    ) -> LargeFilesResult:
        """Analyze repository for large files.

        Args:
            repo_id: Repository identifier.
            branch: Branch to analyze.
            threshold_bytes: Size threshold in bytes (default: 100MB).

        Returns:
            LargeFilesResult with detected large files.
        """
        raise NotImplementedError("analyze_large_files not implemented")

    async def detect_lfs_patterns(
        self,
        repo_id: str,
        *,
        branch: str | None = None,
    ) -> LFSResult:
        """Detect LFS configuration from .gitattributes.

        Args:
            repo_id: Repository identifier.
            branch: Branch to check.

        Returns:
            LFSResult with LFS patterns if configured.
        """
        raise NotImplementedError("detect_lfs_patterns not implemented")

    async def get_pipeline_config(
        self,
        repo_id: str,
        *,
        branch: str | None = None,
    ) -> str | None:
        """Fetch raw pipeline configuration file content.

        Args:
            repo_id: Repository identifier (full name like "workspace/repo").
            branch: Branch to fetch from (default: main).

        Returns:
            Raw YAML string if pipeline config exists, None otherwise.
        """
        raise NotImplementedError("get_pipeline_config not implemented")

    @abstractmethod
    async def close(self) -> None:
        """Close any open connections.

        Should be called when the adapter is no longer needed.
        """
        ...

    async def __aenter__(self) -> SourceAdapter:
        """Async context manager entry."""
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any,
    ) -> None:
        """Async context manager exit - closes connections."""
        await self.close()


class TargetAdapter(ABC):
    """Abstract base class for target system adapters (e.g., GitHub).

    Target adapters provide read and write access to repositories
    in the target system during migration execution.

    All methods are async for efficient I/O handling.
    """

    @abstractmethod
    async def create_repository(
        self,
        *,
        name: str,
        organization: str,
        description: str | None = None,
        private: bool = True,
        default_branch: str = "main",
    ) -> Repository:
        """Create a new repository in the target system.

        Args:
            name: Repository name.
            organization: Target organization/owner.
            description: Optional repository description.
            private: Whether the repository should be private.
            default_branch: Default branch name.

        Returns:
            Created Repository model.

        Raises:
            APIError: If creation fails.
        """
        ...

    @abstractmethod
    async def update_repository(
        self,
        repo_id: str,
        *,
        description: str | None = None,
        private: bool | None = None,
        default_branch: str | None = None,
        archived: bool | None = None,
    ) -> Repository:
        """Update an existing repository.

        Args:
            repo_id: Repository identifier.
            description: New description (if provided).
            private: New visibility (if provided).
            default_branch: New default branch (if provided).
            archived: Whether to archive the repo (if provided).

        Returns:
            Updated Repository model.

        Raises:
            APIError: If update fails.
        """
        ...

    @abstractmethod
    async def get_repository(self, repo_id: str) -> Repository | None:
        """Get a single repository by ID or full name.

        Args:
            repo_id: Repository identifier (ID or full name like "org/repo").

        Returns:
            Repository model if found, None otherwise.
        """
        ...

    @abstractmethod
    async def list_users(
        self,
        *,
        organization: str | None = None,
        page: int = 1,
        page_size: int = 100,
    ) -> list[User]:
        """List users from the target system.

        Args:
            organization: Optional organization filter.
            page: Page number for pagination (1-indexed).
            page_size: Number of items per page.

        Returns:
            List of User models.
        """
        ...

    async def list_org_members(
        self,
        org: str,
    ) -> AsyncIterator[dict[str, Any]]:
        """List members of an organization.

        Args:
            org: Organization name.

        Yields:
            Dict with member info (login, email, name, id, avatar_url).
        """
        # Default implementation uses list_users
        users = await self.list_users(organization=org)
        for user in users:
            yield {
                "login": user.username,
                "email": user.email,
                "name": user.display_name,
                "id": user.id,
                "avatar_url": user.avatar_url,
            }

    # PR-related methods for migration
    async def create_pull_request(
        self,
        repo: str,
        *,
        title: str,
        body: str,
        head: str,
        base: str,
        draft: bool = False,
    ) -> dict[str, Any]:
        """Create a pull request.

        Args:
            repo: Repository name (org/repo).
            title: PR title.
            body: PR body/description.
            head: Source branch.
            base: Target branch.
            draft: Whether to create as draft.

        Returns:
            Dict with PR data including 'number' and 'html_url'.
        """
        raise NotImplementedError("create_pull_request not implemented")

    async def update_pull_request(
        self,
        repo: str,
        pr_number: int,
        *,
        state: str | None = None,
        title: str | None = None,
        body: str | None = None,
    ) -> dict[str, Any]:
        """Update a pull request.

        Args:
            repo: Repository name (org/repo).
            pr_number: PR number.
            state: New state ('open' or 'closed').
            title: New title.
            body: New body.

        Returns:
            Dict with updated PR data.
        """
        raise NotImplementedError("update_pull_request not implemented")

    async def request_reviewers(
        self,
        repo: str,
        pr_number: int,
        reviewers: list[str],
    ) -> None:
        """Request reviewers on a PR.

        Args:
            repo: Repository name (org/repo).
            pr_number: PR number.
            reviewers: List of GitHub usernames.
        """
        raise NotImplementedError("request_reviewers not implemented")

    async def ensure_label(
        self,
        repo: str,
        label: str,
        *,
        color: str = "ededed",
    ) -> None:
        """Ensure a label exists in the repository.

        Args:
            repo: Repository name (org/repo).
            label: Label name.
            color: Label color (hex without #).
        """
        raise NotImplementedError("ensure_label not implemented")

    async def add_labels(
        self,
        repo: str,
        issue_number: int,
        labels: list[str],
    ) -> None:
        """Add labels to an issue or PR.

        Args:
            repo: Repository name (org/repo).
            issue_number: Issue/PR number.
            labels: List of label names.
        """
        raise NotImplementedError("add_labels not implemented")

    # Branch protection / ruleset methods

    async def create_repository_ruleset(
        self,
        repo: str,
        config: GitHubRulesetConfig,
    ) -> dict[str, Any]:
        """Create a ruleset on a repository.

        Args:
            repo: Repository name (org/repo).
            config: Ruleset configuration.

        Returns:
            Dict with created ruleset data including 'id'.
        """
        raise NotImplementedError("create_repository_ruleset not implemented")

    async def list_repository_rulesets(
        self,
        repo: str,
    ) -> list[dict[str, Any]]:
        """List rulesets for a repository.

        Args:
            repo: Repository name (org/repo).

        Returns:
            List of ruleset dicts.
        """
        raise NotImplementedError("list_repository_rulesets not implemented")

    async def delete_repository_ruleset(
        self,
        repo: str,
        ruleset_id: int,
    ) -> None:
        """Delete a repository ruleset.

        Args:
            repo: Repository name (org/repo).
            ruleset_id: Ruleset ID to delete.
        """
        raise NotImplementedError("delete_repository_ruleset not implemented")

    async def create_organization_ruleset(
        self,
        org: str,
        config: GitHubRulesetConfig,
    ) -> dict[str, Any]:
        """Create an organization-level ruleset.

        Args:
            org: Organization name.
            config: Ruleset configuration (should include repository_name conditions).

        Returns:
            Dict with created ruleset data including 'id'.
        """
        raise NotImplementedError("create_organization_ruleset not implemented")

    async def list_organization_rulesets(
        self,
        org: str,
    ) -> list[dict[str, Any]]:
        """List rulesets for an organization.

        Args:
            org: Organization name.

        Returns:
            List of ruleset dicts.
        """
        raise NotImplementedError("list_organization_rulesets not implemented")

    async def delete_organization_ruleset(
        self,
        org: str,
        ruleset_id: int,
    ) -> None:
        """Delete an organization ruleset.

        Args:
            org: Organization name.
            ruleset_id: Ruleset ID to delete.
        """
        raise NotImplementedError("delete_organization_ruleset not implemented")

    async def enable_auto_merge(
        self,
        repo: str,
    ) -> None:
        """Enable auto-merge setting on a repository.

        Args:
            repo: Repository name (org/repo).
        """
        raise NotImplementedError("enable_auto_merge not implemented")

    async def delete_repository(
        self,
        repo: str,
    ) -> None:
        """Delete a repository.

        Args:
            repo: Repository name (org/repo).

        Raises:
            APIError: If deletion fails.
        """
        raise NotImplementedError("delete_repository not implemented")

    async def create_issue_comment(
        self,
        repo: str,
        issue_number: int,
        body: str,
    ) -> dict[str, Any]:
        """Create a comment on an issue or PR.

        Args:
            repo: Repository name (org/repo).
            issue_number: Issue/PR number.
            body: Comment body.

        Returns:
            Dict with comment data.
        """
        raise NotImplementedError("create_issue_comment not implemented")

    @abstractmethod
    async def close(self) -> None:
        """Close any open connections.

        Should be called when the adapter is no longer needed.
        """
        ...

    async def __aenter__(self) -> TargetAdapter:
        """Async context manager entry."""
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any,
    ) -> None:
        """Async context manager exit - closes connections."""
        await self.close()
