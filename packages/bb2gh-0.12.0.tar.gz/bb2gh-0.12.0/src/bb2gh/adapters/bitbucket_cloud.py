"""Bitbucket Cloud adapter for bb2gh.

Implements the SourceAdapter interface for Bitbucket Cloud API.
Supports both app password and OAuth 2.0 authentication.
"""

from __future__ import annotations

import base64
import time
from typing import TYPE_CHECKING, Any, Literal

import httpx
import structlog

from bb2gh.adapters.base import SourceAdapter
from bb2gh.exceptions import AuthenticationError, ConfigurationError

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

    from bb2gh.models.analysis import LargeFilesResult, LFSResult
    from bb2gh.models.branch_protection import (
        BranchRestriction,
        DefaultReviewer,
        RepoBranchProtection,
    )
    from bb2gh.models.repository import Repository
    from bb2gh.models.user import User

logger = structlog.get_logger(__name__)

# Bitbucket API endpoints
BITBUCKET_API_URL = "https://api.bitbucket.org/2.0"
BITBUCKET_AUTH_URL = "https://bitbucket.org/site/oauth2/access_token"


class BitbucketCloudAdapter(SourceAdapter):
    """Bitbucket Cloud API adapter.

    Supports two authentication methods:
    - API Token: Basic auth with username and API token (recommended)
    - OAuth 2.0: Client credentials flow with automatic token refresh

    API token authentication takes precedence if both are configured.

    Example usage:
        # API token auth (recommended)
        adapter = BitbucketCloudAdapter(
            username="myuser",
            api_token="my-api-token",
        )

        # OAuth auth
        adapter = BitbucketCloudAdapter(
            client_id="my-client-id",
            client_secret="my-client-secret",
        )

        async with adapter:
            repos = await adapter.list_repositories(workspace="myworkspace")
    """

    def __init__(
        self,
        *,
        username: str | None = None,
        api_token: str | None = None,
        app_password: str | None = None,  # Deprecated alias for api_token
        client_id: str | None = None,
        client_secret: str | None = None,
        base_url: str = BITBUCKET_API_URL,
        max_retries: int = 3,
        base_backoff: float = 1.0,
        ssl_verify: str | bool = True,
    ) -> None:
        """Initialize Bitbucket Cloud adapter.

        Args:
            username: Bitbucket username for API token auth.
            api_token: Bitbucket API token (replaces app passwords).
            app_password: Deprecated - use api_token instead.
            client_id: OAuth 2.0 client ID.
            client_secret: OAuth 2.0 client secret.
            base_url: API base URL (default: Bitbucket Cloud API).
            max_retries: Maximum retries on rate limit (default: 3).
            base_backoff: Base backoff time in seconds (default: 1.0).
            ssl_verify: SSL verification setting — ``True`` for default
                certifi verification, or a string path to a custom CA
                bundle (PEM).  Passed to ``httpx.AsyncClient(verify=...)``.

        Raises:
            ConfigurationError: If authentication is not properly configured.
        """
        self._base_url = base_url.rstrip("/")
        self._username = username
        # Support both api_token and legacy app_password
        self._api_token = api_token or app_password
        self._client_id = client_id
        self._client_secret = client_secret
        self._max_retries = max_retries
        self._base_backoff = base_backoff
        self._ssl_verify = ssl_verify

        # OAuth token state
        self._access_token: str | None = None
        self._refresh_token: str | None = None
        self._token_expires_at: float = 0

        # HTTP client (created lazily)
        self._client: httpx.AsyncClient | None = None

        # Validate configuration
        self._validate_auth_config()

        # Log initialization (without credentials)
        logger.debug(
            "bitbucket_cloud_adapter_initialized",
            auth_type=self.auth_type,
            base_url=self._base_url,
        )

    def _validate_auth_config(self) -> None:
        """Validate authentication configuration.

        Raises:
            ConfigurationError: If auth config is invalid or incomplete.
        """
        has_api_token = self._username is not None or self._api_token is not None
        has_oauth = self._client_id is not None or self._client_secret is not None

        if not has_api_token and not has_oauth:
            raise ConfigurationError(
                "Bitbucket authentication required. Provide either:\n"
                "  - username and api_token for API token auth, or\n"
                "  - client_id and client_secret for OAuth 2.0"
            )

        # Check for incomplete API token config
        if self._username is not None and self._api_token is None:
            raise ConfigurationError(
                "Incomplete API token configuration: api_token (or app_password) is required when username is provided"
            )
        if self._api_token is not None and self._username is None:
            raise ConfigurationError(
                "Incomplete API token configuration: username is required when api_token is provided"
            )

        # Check for incomplete OAuth config
        if self._client_id is not None and self._client_secret is None:
            raise ConfigurationError(
                "Incomplete OAuth configuration: client_secret is required when client_id is provided"
            )
        if self._client_secret is not None and self._client_id is None:
            raise ConfigurationError(
                "Incomplete OAuth configuration: client_id is required when client_secret is provided"
            )

    @property
    def auth_type(self) -> Literal["api_token", "oauth"]:
        """Get the authentication type being used."""
        # API token takes precedence
        if self._username is not None and self._api_token is not None:
            return "api_token"
        return "oauth"

    @property
    def base_url(self) -> str:
        """Get the API base URL."""
        return self._base_url

    def _get_client(self) -> httpx.AsyncClient:
        """Get or create HTTP client."""
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                timeout=httpx.Timeout(30.0),
                follow_redirects=True,
                verify=self._ssl_verify,
            )
        return self._client

    async def _get_auth_headers(self) -> dict[str, str]:
        """Get authentication headers for API requests.

        Returns:
            Dict with Authorization header.
        """
        if self.auth_type == "api_token":
            # Basic auth with username:api_token
            credentials = f"{self._username}:{self._api_token}"
            encoded = base64.b64encode(credentials.encode()).decode()
            return {"Authorization": f"Basic {encoded}"}
        else:
            # OAuth - ensure we have a valid token
            await self._ensure_valid_token()
            return {"Authorization": f"Bearer {self._access_token}"}

    async def _ensure_valid_token(self) -> None:
        """Ensure we have a valid OAuth access token.

        Fetches a new token or refreshes if expired.
        """
        # Check if we need a new token (with 60s buffer)
        if self._access_token is None or time.time() >= (self._token_expires_at - 60):
            await self._fetch_oauth_token()

    async def _fetch_oauth_token(self) -> None:
        """Fetch or refresh OAuth access token.

        Raises:
            AuthenticationError: If token request fails.
        """
        client = self._get_client()

        # Prepare token request
        data: dict[str, str] = {}
        if self._refresh_token is not None:
            data["grant_type"] = "refresh_token"
            data["refresh_token"] = self._refresh_token
        else:
            data["grant_type"] = "client_credentials"

        # Client credentials in Basic auth header
        credentials = f"{self._client_id}:{self._client_secret}"
        encoded = base64.b64encode(credentials.encode()).decode()
        headers = {"Authorization": f"Basic {encoded}"}

        logger.debug("fetching_oauth_token", grant_type=data["grant_type"])

        try:
            response = await client.post(
                BITBUCKET_AUTH_URL,
                data=data,
                headers=headers,
            )

            if response.status_code == 401:
                error_data = response.json() if response.content else {}
                error_msg = error_data.get("error_description", "Invalid OAuth credentials")
                raise AuthenticationError(f"OAuth authentication failed: {error_msg}")

            response.raise_for_status()
            token_data = response.json()

            self._access_token = token_data["access_token"]
            self._refresh_token = token_data.get("refresh_token")
            expires_in = token_data.get("expires_in", 7200)
            self._token_expires_at = time.time() + expires_in

            logger.debug(
                "oauth_token_obtained",
                expires_in=expires_in,
                has_refresh_token=self._refresh_token is not None,
            )

        except httpx.HTTPStatusError as e:
            raise AuthenticationError(
                f"Failed to obtain OAuth token: {e.response.status_code}"
            ) from e

    async def _request(
        self,
        method: str,
        path: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """Make an authenticated API request with rate limit handling.

        Args:
            method: HTTP method.
            path: API path (relative to base URL).
            **kwargs: Additional arguments for httpx request.

        Returns:
            HTTP response.

        Raises:
            APIError: If rate limit retries exhausted.
        """
        import asyncio

        from bb2gh.exceptions import APIError

        client = self._get_client()
        url = f"{self._base_url}/{path.lstrip('/')}"

        for attempt in range(self._max_retries + 1):
            headers = await self._get_auth_headers()

            # Merge with any provided headers
            request_kwargs = kwargs.copy()
            if "headers" in request_kwargs:
                headers.update(request_kwargs.pop("headers"))

            response = await client.request(method, url, headers=headers, **request_kwargs)

            if response.status_code != 429:
                return response

            # Rate limited - check if we should retry
            if attempt >= self._max_retries:
                logger.warning(
                    "rate_limit_retries_exhausted",
                    url=url,
                    attempts=attempt + 1,
                )
                raise APIError(
                    "Rate limit exceeded and max retries exhausted",
                    status_code=429,
                )

            # Calculate wait time
            retry_after = response.headers.get("Retry-After")
            wait_time = float(retry_after) if retry_after else self._base_backoff * (2**attempt)

            logger.warning(
                "rate_limited",
                url=url,
                attempt=attempt + 1,
                wait_seconds=wait_time,
                retry_after_header=retry_after,
            )

            await asyncio.sleep(wait_time)

        # Should not reach here, but satisfy type checker
        raise APIError("Rate limit handling failed", status_code=429)

    async def verify_credentials(self) -> bool:
        """Verify that credentials are valid.

        Returns:
            True if credentials are valid.

        Raises:
            AuthenticationError: If credentials are invalid.
        """
        logger.debug("verifying_credentials", auth_type=self.auth_type)

        try:
            response = await self._request("GET", "/user")

            if response.status_code == 401:
                error_data = response.json() if response.content else {}
                error_msg = error_data.get("error", {}).get("message", "Invalid credentials")
                raise AuthenticationError(
                    f"Bitbucket authentication failed: {error_msg}. "
                    "Please verify your credentials are correct."
                )

            response.raise_for_status()
            user_data = response.json()

            logger.info(
                "credentials_verified",
                username=user_data.get("username"),
                auth_type=self.auth_type,
            )
            return True

        except httpx.HTTPStatusError as e:
            if e.response.status_code == 401:
                raise AuthenticationError(
                    "Bitbucket authentication failed: Invalid or expired credentials"
                ) from e
            raise

    # SourceAdapter interface implementation

    async def list_repositories(
        self,
        *,
        workspace: str | None = None,
        project: str | None = None,
        page: int = 1,
        page_size: int = 100,
    ) -> list[Repository]:
        """List repositories from Bitbucket workspace.

        Args:
            workspace: Bitbucket workspace slug (required).
            project: Optional project key filter.
            page: Page number (1-indexed).
            page_size: Items per page (max 100).

        Returns:
            List of Repository models.

        Raises:
            ValueError: If workspace is not provided.
        """

        if workspace is None:
            raise ValueError("workspace is required to list repositories")

        # Build query parameters
        params: dict[str, Any] = {
            "page": page,
            "pagelen": min(page_size, 100),  # Bitbucket max is 100
        }

        # Add project filter if specified
        if project:
            params["q"] = f'project.key="{project}"'

        logger.debug(
            "listing_repositories",
            workspace=workspace,
            project=project,
            page=page,
            page_size=page_size,
        )

        response = await self._request(
            "GET",
            f"/repositories/{workspace}",
            params=params,
        )
        response.raise_for_status()
        data = response.json()

        repositories: list[Repository] = []
        for repo_data in data.get("values", []):
            repo = self._parse_repository(repo_data)
            repositories.append(repo)

        logger.debug(
            "repositories_listed",
            workspace=workspace,
            count=len(repositories),
            total=data.get("size", len(repositories)),
        )

        return repositories

    def _parse_repository(self, data: dict[str, Any]) -> Repository:
        """Parse Bitbucket API response into Repository model.

        Args:
            data: Raw repository data from Bitbucket API.

        Returns:
            Repository model.
        """
        from datetime import datetime

        from bb2gh.models.repository import Repository

        # Extract clone URLs
        clone_url_https = None
        clone_url_ssh = None
        for clone_link in data.get("links", {}).get("clone", []):
            if clone_link.get("name") == "https":
                clone_url_https = clone_link.get("href")
            elif clone_link.get("name") == "ssh":
                clone_url_ssh = clone_link.get("href")

        # Parse timestamps
        created_at = None
        updated_at = None
        if data.get("created_on"):
            created_at = datetime.fromisoformat(data["created_on"].replace("Z", "+00:00"))
        if data.get("updated_on"):
            updated_at = datetime.fromisoformat(data["updated_on"].replace("Z", "+00:00"))

        # Extract main branch
        default_branch = "main"
        if data.get("mainbranch"):
            default_branch = data["mainbranch"].get("name", "main")

        return Repository(
            id=data.get("uuid", ""),
            name=data.get("name", ""),
            full_name=data.get("full_name", ""),
            description=data.get("description"),
            private=data.get("is_private", True),
            default_branch=default_branch,
            clone_url_https=clone_url_https,
            clone_url_ssh=clone_url_ssh,
            size_bytes=data.get("size"),
            owner=data.get("owner", {}).get("username", ""),
            project=data.get("project", {}).get("key") if data.get("project") else None,
            created_at=created_at,
            updated_at=updated_at,
            archived=False,  # Bitbucket doesn't have archive concept
            fork=data.get("parent") is not None,
            source="bitbucket",
            has_lfs=False,  # Will be detected separately
            has_large_files=False,  # Will be detected separately
        )

    async def get_repository(
        self,
        repo_id: str,
        *,
        include_branch_restrictions: bool = False,
    ) -> Repository | None:
        """Get a single repository by ID or full name.

        Args:
            repo_id: Repository identifier (full name like "workspace/repo").
            include_branch_restrictions: Whether to fetch branch restrictions.

        Returns:
            Repository model if found, None otherwise.
        """

        logger.debug("getting_repository", repo_id=repo_id)

        response = await self._request("GET", f"/repositories/{repo_id}")

        if response.status_code == 404:
            logger.debug("repository_not_found", repo_id=repo_id)
            return None

        response.raise_for_status()
        data = response.json()

        repo = self._parse_repository(data)

        # Optionally fetch branch restrictions
        if include_branch_restrictions:
            await self._fetch_branch_restrictions(repo_id)

        logger.debug(
            "repository_fetched",
            repo_id=repo_id,
            name=repo.name,
            size_bytes=repo.size_bytes,
        )

        return repo

    async def _fetch_branch_restrictions(self, repo_id: str) -> list[BranchRestriction]:
        """Fetch all branch restrictions for a repository with pagination.

        Paginates through all results and parses into typed models.

        Args:
            repo_id: Repository identifier (full name like "workspace/repo").

        Returns:
            List of BranchRestriction models. Empty list if no permissions.
        """
        from bb2gh.models.branch_protection import (
            BranchRestriction as BranchRestrictionModel,
        )

        logger.debug("fetching_branch_restrictions", repo_id=repo_id)

        all_restrictions: list[BranchRestrictionModel] = []
        url: str | None = f"/repositories/{repo_id}/branch-restrictions"

        while url is not None:
            response = await self._request("GET", url)

            if response.status_code == 404:
                return []

            if response.status_code == 403:
                logger.warning(
                    "branch_restrictions_permission_denied",
                    repo_id=repo_id,
                )
                return []

            response.raise_for_status()
            data = response.json()

            for raw in data.get("values", []):
                try:
                    restriction = BranchRestrictionModel.model_validate(
                        self._normalize_restriction(raw)
                    )
                    all_restrictions.append(restriction)
                except Exception:
                    logger.warning(
                        "branch_restriction_parse_error",
                        repo_id=repo_id,
                        restriction_id=raw.get("id"),
                        kind=raw.get("kind"),
                    )

            # Follow pagination — next_url is absolute; strip base URL to use _request
            next_url = data.get("next")
            url = next_url.replace(self._base_url, "") if next_url else None

        logger.debug(
            "branch_restrictions_fetched",
            repo_id=repo_id,
            count=len(all_restrictions),
        )

        return all_restrictions

    @staticmethod
    def _normalize_restriction(raw: dict[str, Any]) -> dict[str, Any]:
        """Normalize raw BB API restriction dict to model-compatible format.

        Args:
            raw: Raw dict from BB API response.

        Returns:
            Dict suitable for BranchRestriction.model_validate().
        """
        users = []
        for u in raw.get("users", []):
            users.append(
                {
                    "uuid": u.get("uuid", ""),
                    "display_name": u.get("display_name"),
                    "account_id": u.get("account_id"),
                }
            )

        groups = []
        for g in raw.get("groups", []):
            owner = g.get("owner", {})
            groups.append(
                {
                    "slug": g.get("slug", ""),
                    "owner_username": owner.get("username", ""),
                }
            )

        return {
            "id": raw.get("id", 0),
            "kind": raw.get("kind", ""),
            "branch_match_kind": raw.get("branch_match_kind", "glob"),
            "pattern": raw.get("pattern"),
            "branch_type": raw.get("branch_type"),
            "value": raw.get("value"),
            "users": users,
            "groups": groups,
        }

    async def _fetch_branching_model(self, repo_id: str) -> dict[str, Any] | None:
        """Fetch the active branching model for a repository.

        Args:
            repo_id: Repository identifier (full name like "workspace/repo").

        Returns:
            Branching model dict, or None if unavailable.
        """
        logger.debug("fetching_branching_model", repo_id=repo_id)

        response = await self._request(
            "GET",
            f"/repositories/{repo_id}/branching-model",
        )

        if response.status_code in (403, 404):
            logger.warning(
                "branching_model_unavailable",
                repo_id=repo_id,
                status=response.status_code,
            )
            return None

        response.raise_for_status()
        data: dict[str, Any] = response.json()

        logger.debug("branching_model_fetched", repo_id=repo_id)
        return data

    async def _fetch_effective_default_reviewers(self, repo_id: str) -> list[DefaultReviewer]:
        """Fetch effective default reviewers (repo + project inherited).

        Args:
            repo_id: Repository identifier (full name like "workspace/repo").

        Returns:
            List of DefaultReviewer models. Empty list if unavailable.
        """
        from bb2gh.models.branch_protection import (
            DefaultReviewer as DefaultReviewerModel,
        )

        logger.debug("fetching_default_reviewers", repo_id=repo_id)

        response = await self._request(
            "GET",
            f"/repositories/{repo_id}/effective-default-reviewers",
        )

        if response.status_code in (403, 404):
            logger.warning(
                "default_reviewers_unavailable",
                repo_id=repo_id,
                status=response.status_code,
            )
            return []

        response.raise_for_status()
        data = response.json()

        reviewers: list[DefaultReviewerModel] = []
        for raw in data.get("values", []):
            reviewers.append(
                DefaultReviewerModel(
                    uuid=raw.get("uuid", ""),
                    display_name=raw.get("display_name"),
                    reviewer_type=raw.get("reviewer_type", "repository"),
                )
            )

        logger.debug(
            "default_reviewers_fetched",
            repo_id=repo_id,
            count=len(reviewers),
        )
        return reviewers

    async def get_branch_protection(self, repo_id: str) -> RepoBranchProtection:
        """Get all branch protection data for a repository.

        Combines branch restrictions, branching model, and default reviewers.

        Args:
            repo_id: Repository identifier (full name like "workspace/repo").

        Returns:
            RepoBranchProtection with all protection data.
        """
        from bb2gh.models.branch_protection import (
            RepoBranchProtection as RepoBranchProtectionModel,
        )

        logger.info("fetching_branch_protection", repo_id=repo_id)

        restrictions = await self._fetch_branch_restrictions(repo_id)
        branching_model = await self._fetch_branching_model(repo_id)
        default_reviewers = await self._fetch_effective_default_reviewers(repo_id)

        warnings: list[str] = []
        warnings.append(
            "Project-level branch restrictions cannot be read via API (Bitbucket Cloud limitation)"
        )

        return RepoBranchProtectionModel(
            repo_full_name=repo_id,
            restrictions=restrictions,
            branching_model=branching_model,
            default_reviewers=default_reviewers,
            warnings=warnings,
        )

    async def analyze_large_files(
        self,
        repo_id: str,
        *,
        branch: str | None = None,
        threshold_bytes: int = 100_000_000,
    ) -> LargeFilesResult:
        """Analyze repository for large files that may cause migration issues.

        Args:
            repo_id: Repository identifier (full name like "workspace/repo").
            branch: Branch to analyze (default: main).
            threshold_bytes: Size threshold in bytes (default: 100MB).

        Returns:
            LargeFilesResult with detected large files.
        """
        from bb2gh.models.analysis import LargeFile, LargeFilesResult

        effective_branch = branch or "main"
        logger.debug(
            "analyzing_large_files",
            repo_id=repo_id,
            branch=effective_branch,
            threshold_mb=threshold_bytes / (1024 * 1024),
        )

        # Fetch source tree with depth to catch nested files
        response = await self._request(
            "GET",
            f"/repositories/{repo_id}/src/{effective_branch}/",
            params={"max_depth": 10},
        )

        if response.status_code == 404:
            logger.warning("branch_not_found", repo_id=repo_id, branch=branch)
            return LargeFilesResult(threshold_bytes=threshold_bytes)

        response.raise_for_status()
        data = response.json()

        large_files: list[LargeFile] = []
        files_scanned = 0

        for item in data.get("values", []):
            if item.get("type") == "commit_file":
                files_scanned += 1
                size = item.get("size", 0)
                if size >= threshold_bytes:
                    large_files.append(LargeFile(path=item.get("path", ""), size_bytes=size))

        result = LargeFilesResult(
            has_large_files=len(large_files) > 0,
            large_files=large_files,
            threshold_bytes=threshold_bytes,
            files_scanned=files_scanned,
        )

        logger.debug(
            "large_files_analysis_complete",
            repo_id=repo_id,
            files_scanned=files_scanned,
            large_files_found=len(large_files),
        )

        return result

    async def detect_lfs_patterns(
        self,
        repo_id: str,
        *,
        branch: str | None = None,
    ) -> LFSResult:
        """Detect LFS configuration from .gitattributes.

        Args:
            repo_id: Repository identifier (full name like "workspace/repo").
            branch: Branch to check (default: main).

        Returns:
            LFSResult with LFS patterns if configured.
        """
        from bb2gh.models.analysis import LFSResult

        effective_branch = branch or "main"
        logger.debug("detecting_lfs", repo_id=repo_id, branch=effective_branch)

        response = await self._request(
            "GET",
            f"/repositories/{repo_id}/src/{effective_branch}/.gitattributes",
        )

        if response.status_code == 404:
            logger.debug("no_gitattributes", repo_id=repo_id)
            return LFSResult()

        response.raise_for_status()
        content = response.text

        # Parse .gitattributes for LFS patterns
        patterns: list[str] = []
        for line in content.splitlines():
            line = line.strip()
            if "filter=lfs" in line:
                # Extract the pattern (first part of the line)
                parts = line.split()
                if parts:
                    patterns.append(parts[0])

        result = LFSResult(
            has_lfs=len(patterns) > 0,
            patterns=patterns,
            gitattributes_found=True,
        )

        logger.debug(
            "lfs_detection_complete",
            repo_id=repo_id,
            has_lfs=result.has_lfs,
            pattern_count=len(patterns),
        )

        return result

    async def get_pipeline_config(
        self,
        repo_id: str,
        *,
        branch: str | None = None,
    ) -> str | None:
        """Fetch raw bitbucket-pipelines.yml content from a repository.

        Args:
            repo_id: Repository identifier (full name like "workspace/repo").
            branch: Branch to fetch from (default: main).

        Returns:
            Raw YAML string if pipeline config exists, None otherwise.
        """
        effective_branch = branch or "main"
        logger.debug("fetching_pipeline_config", repo_id=repo_id, branch=effective_branch)

        response = await self._request(
            "GET",
            f"/repositories/{repo_id}/src/{effective_branch}/bitbucket-pipelines.yml",
        )

        if response.status_code == 404:
            logger.debug("no_pipeline_config", repo_id=repo_id)
            return None

        response.raise_for_status()
        return response.text

    async def count_pull_requests(
        self,
        repo_id: str,
        *,
        state: str | None = None,
    ) -> int:
        """Count pull requests in a repository.

        Args:
            repo_id: Repository identifier (full name like "workspace/repo").
            state: Optional state filter: "OPEN", "MERGED", "DECLINED", "SUPERSEDED".
                   If None, counts all pull requests.

        Returns:
            Total count of pull requests matching the filter.
        """
        logger.debug(
            "counting_pull_requests",
            repo_id=repo_id,
            state=state,
        )

        params: dict[str, Any] = {
            "pagelen": 1,  # We only need the count, not the data
        }

        if state:
            params["state"] = state

        response = await self._request(
            "GET",
            f"/repositories/{repo_id}/pullrequests",
            params=params,
        )

        if response.status_code == 404:
            logger.debug("repository_not_found_for_prs", repo_id=repo_id)
            return 0

        response.raise_for_status()
        data = response.json()

        # Bitbucket returns total count in "size" field
        total: int = data.get("size", 0)

        logger.debug(
            "pull_requests_counted",
            repo_id=repo_id,
            state=state,
            count=total,
        )

        return total

    async def count_branches(
        self,
        repo_id: str,
    ) -> int:
        """Count branches in a repository.

        Args:
            repo_id: Repository identifier (full name like "workspace/repo").

        Returns:
            Total count of branches.
        """
        logger.debug("counting_branches", repo_id=repo_id)

        params: dict[str, Any] = {
            "pagelen": 1,  # We only need the count
        }

        response = await self._request(
            "GET",
            f"/repositories/{repo_id}/refs/branches",
            params=params,
        )

        if response.status_code == 404:
            logger.debug("repository_not_found_for_branches", repo_id=repo_id)
            return 0

        response.raise_for_status()
        data = response.json()

        total: int = data.get("size", 0)

        logger.debug(
            "branches_counted",
            repo_id=repo_id,
            count=total,
        )

        return total

    async def list_users(
        self,
        *,
        workspace: str | None = None,
        page: int = 1,
        page_size: int = 100,
    ) -> list[User]:
        """List users from Bitbucket workspace.

        Args:
            workspace: Bitbucket workspace slug (required).
            page: Page number (1-indexed).
            page_size: Items per page.

        Returns:
            List of User models.

        Raises:
            ValueError: If workspace is not provided.
        """

        if workspace is None:
            raise ValueError("workspace is required to list users")

        logger.debug(
            "listing_users",
            workspace=workspace,
            page=page,
            page_size=page_size,
        )

        from urllib.parse import urlparse

        pagelen = min(page_size, 100)
        params: dict[str, Any] = {
            "page": page,
            "pagelen": pagelen,
            "fields": "+values.user.email",
        }

        users: list[User] = []
        path: str | None = f"/workspaces/{workspace}/members"

        while path is not None:
            response = await self._request(
                "GET",
                path,
                params=params,
            )
            response.raise_for_status()
            data = response.json()

            for member_data in data.get("values", []):
                user_data = member_data.get("user", {})
                user = self._parse_user(user_data)
                users.append(user)

            # Follow next URL for auto-pagination
            next_url = data.get("next")
            if next_url:
                # next URL is absolute — extract path relative to base URL
                parsed = urlparse(next_url)
                base_path = urlparse(self._base_url).path
                rel_path = parsed.path
                if rel_path.startswith(base_path):
                    rel_path = rel_path[len(base_path) :]
                path = rel_path
                # Clear params — next URL includes its own query parameters
                params = {}
                if parsed.query:
                    from urllib.parse import parse_qs

                    for key, values in parse_qs(parsed.query).items():
                        params[key] = values[0]
            else:
                path = None

        logger.debug(
            "users_listed",
            workspace=workspace,
            count=len(users),
            total=data.get("size", len(users)),
        )

        return users

    def _parse_user(self, data: dict[str, Any]) -> User:
        """Parse Bitbucket API response into User model.

        Note: Bitbucket removed the ``username`` field in April 2019 (GDPR).
        We use ``nickname`` (human-readable, not guaranteed unique) and
        ``account_id`` (stable UUID) as the primary identifiers.

        Args:
            data: Raw user data from Bitbucket API.

        Returns:
            User model.
        """
        from bb2gh.models.user import User

        avatar_url = None
        if data.get("links", {}).get("avatar"):
            avatar_url = data["links"]["avatar"].get("href")

        return User(
            id=data.get("uuid", data.get("account_id", "")),
            username=data.get("nickname", ""),
            display_name=data.get("display_name"),
            email=data.get("email"),
            avatar_url=avatar_url,
            source="bitbucket",
            account_id=data.get("account_id"),
        )

    async def get_user(self, user_id: str) -> User | None:
        """Get a single user by ID or username.

        Args:
            user_id: User identifier (UUID or username).

        Returns:
            User model if found, None otherwise.
        """

        logger.debug("getting_user", user_id=user_id)

        response = await self._request("GET", f"/users/{user_id}")

        if response.status_code == 404:
            logger.debug("user_not_found", user_id=user_id)
            return None

        response.raise_for_status()
        data = response.json()

        user = self._parse_user(data)

        logger.debug(
            "user_fetched",
            user_id=user_id,
            username=user.username,
        )

        return user

    async def list_pull_requests(
        self,
        repo_full_name: str,
        *,
        state: str = "OPEN",
    ) -> AsyncIterator[dict[str, Any]]:
        """List pull requests for a repository.

        Args:
            repo_full_name: Full repository name (workspace/repo).
            state: PR state filter (OPEN, MERGED, DECLINED, SUPERSEDED).

        Yields:
            Dict with PR data.
        """
        logger.debug(
            "listing_pull_requests",
            repo=repo_full_name,
            state=state,
        )

        # Bitbucket API: GET /repositories/{workspace}/{repo_slug}/pullrequests
        url: str | None = f"/repositories/{repo_full_name}/pullrequests"
        params: dict[str, object] | None = {
            "state": state,
            "pagelen": 50,
        }

        while url:
            response = await self._request("GET", url, params=params)
            params = None  # Only use params on first request
            data = response.json()

            for pr in data.get("values", []):
                yield pr

            # Get next page
            next_url = data.get("next")
            if next_url:
                # Extract path from full URL
                from urllib.parse import urlparse

                url = urlparse(next_url).path
            else:
                url = None

    async def list_pr_comments(
        self,
        repo_full_name: str,
        pr_id: str,
    ) -> AsyncIterator[dict[str, Any]]:
        """List comments on a pull request.

        Args:
            repo_full_name: Full repository name (workspace/repo).
            pr_id: Pull request ID.

        Yields:
            Dict with comment data.
        """
        logger.debug(
            "listing_pr_comments",
            repo=repo_full_name,
            pr_id=pr_id,
        )

        # Bitbucket API: GET /repositories/{workspace}/{repo}/pullrequests/{pr_id}/comments
        url: str | None = f"/repositories/{repo_full_name}/pullrequests/{pr_id}/comments"
        params: dict[str, int] | None = {
            "pagelen": 100,
        }

        while url:
            response = await self._request("GET", url, params=params)
            params = None  # Only use params on first request
            data = response.json()

            for comment in data.get("values", []):
                yield comment

            # Get next page
            next_url = data.get("next")
            if next_url:
                from urllib.parse import urlparse

                url = urlparse(next_url).path
            else:
                url = None

    async def list_pr_activity(
        self,
        repo_full_name: str,
        pr_id: str,
    ) -> AsyncIterator[dict[str, Any]]:
        """List all activity for a pull request.

        Activity includes comments, approvals, updates, and state changes.

        Args:
            repo_full_name: Full repository name (workspace/repo).
            pr_id: Pull request ID.

        Yields:
            Dict with activity data including type indicator.
        """
        logger.debug(
            "listing_pr_activity",
            repo=repo_full_name,
            pr_id=pr_id,
        )

        url: str | None = f"/repositories/{repo_full_name}/pullrequests/{pr_id}/activity"
        # Note: Activity endpoint has max pagelen of 50 (not 100 like other endpoints)
        params: dict[str, int] | None = {
            "pagelen": 50,
        }

        while url:
            response = await self._request("GET", url, params=params)
            params = None  # Only use params on first request
            data = response.json()

            for item in data.get("values", []):
                # Determine activity type and yield with type indicator
                if "comment" in item:
                    yield {"type": "comment", **item}
                elif "update" in item:
                    yield {"type": "update", **item}
                elif "approval" in item:
                    yield {"type": "approval", **item}
                elif "changes_requested" in item:
                    yield {"type": "changes_requested", **item}
                else:
                    # Unknown activity type, yield as-is
                    yield {"type": "unknown", **item}

            # Get next page
            next_url = data.get("next")
            if next_url:
                from urllib.parse import urlparse

                url = urlparse(next_url).path
            else:
                url = None

    async def close(self) -> None:
        """Close HTTP client and release resources."""
        if self._client is not None and not self._client.is_closed:
            await self._client.aclose()
            logger.debug("bitbucket_client_closed")

    def __repr__(self) -> str:
        """Return string representation without exposing credentials."""
        return f"BitbucketCloudAdapter(auth_type={self.auth_type!r}, base_url={self._base_url!r})"

    def __str__(self) -> str:
        """Return string representation."""
        return f"BitbucketCloudAdapter({self.auth_type})"
