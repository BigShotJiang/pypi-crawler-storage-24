"""GitHub Multi-App adapter for bb2gh.

Provides support for multiple GitHub App installations with:
- Round-robin selection for load distribution
- Automatic fallback on rate limits
- Rate limit tracking and monitoring
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Generic, TypeVar

import structlog

from bb2gh.adapters.base import TargetAdapter
from bb2gh.adapters.github_base import GitHubBaseAdapter
from bb2gh.exceptions import APIError, ConfigurationError

if TYPE_CHECKING:
    import httpx

    from bb2gh.models.repository import Repository
    from bb2gh.models.user import User

logger = structlog.get_logger(__name__)

T = TypeVar("T", bound=GitHubBaseAdapter)


@dataclass
class GitHubAppConfig:
    """Configuration for a single GitHub App installation.

    Attributes:
        app_id: GitHub App ID.
        private_key: GitHub App private key (PEM format).
        installation_id: GitHub App installation ID.
        name: Optional friendly name for logging/identification.
    """

    app_id: int
    private_key: str
    installation_id: int
    name: str | None = None

    def __post_init__(self) -> None:
        """Validate configuration."""
        if not self.app_id:
            raise ConfigurationError("app_id is required")
        if not self.private_key:
            raise ConfigurationError("private_key is required")
        if not self.installation_id:
            raise ConfigurationError("installation_id is required")

    @property
    def display_name(self) -> str:
        """Get display name for logging."""
        if self.name:
            return self.name
        return f"app-{self.app_id}-install-{self.installation_id}"


@dataclass
class AppRateLimitState:
    """Tracks rate limit state for a single app.

    Attributes:
        remaining: Remaining requests in current window.
        limit: Total requests allowed in window.
        reset_at: Unix timestamp when rate limit resets.
        is_limited: Whether currently rate limited.
    """

    remaining: int = 5000
    limit: int = 5000
    reset_at: float = 0
    is_limited: bool = field(default=False, init=False)

    def update_from_headers(self, headers: httpx.Headers) -> None:
        """Update state from response headers.

        Args:
            headers: HTTP response headers containing rate limit info.
        """
        if "x-ratelimit-remaining" in headers:
            self.remaining = int(headers["x-ratelimit-remaining"])
        if "x-ratelimit-limit" in headers:
            self.limit = int(headers["x-ratelimit-limit"])
        if "x-ratelimit-reset" in headers:
            self.reset_at = float(headers["x-ratelimit-reset"])

        # Check if we're rate limited
        self.is_limited = self.remaining == 0 and time.time() < self.reset_at

    def is_available(self) -> bool:
        """Check if this app is available for requests.

        Returns:
            True if the app can accept requests.
        """
        if not self.is_limited:
            return True

        # Check if rate limit has reset
        if time.time() >= self.reset_at:
            self.is_limited = False
            return True

        return False

    def time_until_reset(self) -> float:
        """Get seconds until rate limit resets.

        Returns:
            Seconds until reset, or 0 if not limited.
        """
        if not self.is_limited:
            return 0
        return max(0, self.reset_at - time.time())


class MultiAppGitHubAdapter(TargetAdapter, Generic[T]):
    """GitHub adapter with multiple app support.

    Manages multiple GitHub App installations for:
    - Load distribution via round-robin selection
    - Automatic fallback when an app hits rate limits
    - Rate limit monitoring across all apps

    Example usage:
        from bb2gh.adapters.github_cloud import GitHubCloudAdapter

        apps = [
            GitHubAppConfig(
                app_id=111,
                private_key="...",
                installation_id=1001,
                name="app-1",
            ),
            GitHubAppConfig(
                app_id=222,
                private_key="...",
                installation_id=2002,
                name="app-2",
            ),
        ]

        adapter = MultiAppGitHubAdapter(
            adapter_class=GitHubCloudAdapter,
            apps=apps,
        )

        async with adapter:
            # Requests are distributed across apps
            repo = await adapter.create_repository(...)
    """

    def __init__(
        self,
        adapter_class: type[T],
        apps: list[GitHubAppConfig],
        **adapter_kwargs: Any,
    ) -> None:
        """Initialize multi-app adapter.

        Args:
            adapter_class: The GitHubBaseAdapter subclass to use.
            apps: List of GitHub App configurations.
            **adapter_kwargs: Additional arguments passed to each adapter instance.

        Raises:
            ConfigurationError: If no apps are provided.
        """
        if not apps:
            raise ConfigurationError("At least one GitHub App configuration is required")

        self._adapter_class = adapter_class
        self._app_configs = apps
        self._adapter_kwargs = adapter_kwargs

        # Create adapter instances for each app
        self._adapters: list[T] = []
        self._rate_limits: list[AppRateLimitState] = []

        for config in apps:
            adapter = adapter_class(
                app_id=config.app_id,
                private_key=config.private_key,
                installation_id=config.installation_id,
                **adapter_kwargs,
            )
            self._adapters.append(adapter)
            self._rate_limits.append(AppRateLimitState())

        # Round-robin index
        self._current_index = 0

        logger.info(
            "multi_app_adapter_initialized",
            app_count=len(apps),
            app_names=[c.display_name for c in apps],
        )

    @property
    def app_count(self) -> int:
        """Get the number of configured apps."""
        return len(self._adapters)

    @property
    def api_url(self) -> str:
        """Get the API URL from the first adapter."""
        return self._adapters[0].api_url

    def get_rate_limit_status(self) -> list[dict[str, Any]]:
        """Get rate limit status for all apps.

        Returns:
            List of rate limit info dicts per app.
        """
        return [
            {
                "name": self._app_configs[i].display_name,
                "remaining": self._rate_limits[i].remaining,
                "limit": self._rate_limits[i].limit,
                "reset_at": self._rate_limits[i].reset_at,
                "is_limited": self._rate_limits[i].is_limited,
                "available": self._rate_limits[i].is_available(),
            }
            for i in range(len(self._adapters))
        ]

    def _get_next_available_adapter(self) -> tuple[T, int] | None:
        """Get the next available adapter using round-robin.

        Returns:
            Tuple of (adapter, index) or None if all are rate limited.
        """
        # Try round-robin starting from current index
        for _ in range(len(self._adapters)):
            idx = self._current_index
            self._current_index = (self._current_index + 1) % len(self._adapters)

            if self._rate_limits[idx].is_available():
                return self._adapters[idx], idx

        # All adapters are rate limited
        return None

    def _get_adapter_with_fallback(self) -> tuple[T, int]:
        """Get an available adapter, raising if all are rate limited.

        Returns:
            Tuple of (adapter, index).

        Raises:
            APIError: If all apps are rate limited.
        """
        result: tuple[T, int] | None = self._get_next_available_adapter()

        if result is None:
            # Find the app that will reset soonest
            min_reset = min((rl.time_until_reset(), i) for i, rl in enumerate(self._rate_limits))
            reset_time = min_reset[0]

            raise APIError(
                f"All GitHub Apps are rate limited. Earliest reset in {int(reset_time)} seconds.",
                status_code=429,
            )

        return result

    def _update_rate_limit(self, index: int, response: httpx.Response) -> None:
        """Update rate limit state from response.

        Args:
            index: Adapter index.
            response: HTTP response with rate limit headers.
        """
        self._rate_limits[index].update_from_headers(response.headers)

        if self._rate_limits[index].is_limited:
            logger.warning(
                "app_rate_limited",
                app=self._app_configs[index].display_name,
                reset_in=int(self._rate_limits[index].time_until_reset()),
            )

    async def _request_with_fallback(
        self,
        method: str,
        path: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """Make a request with automatic fallback on rate limits.

        Args:
            method: HTTP method.
            path: API path.
            **kwargs: Additional request arguments.

        Returns:
            HTTP response.
        """
        adapter: T
        adapter, idx = self._get_adapter_with_fallback()
        app_name = self._app_configs[idx].display_name

        logger.debug(
            "request_using_app",
            app=app_name,
            method=method,
            path=path,
        )

        response = await adapter._request(method, path, **kwargs)
        self._update_rate_limit(idx, response)

        # If we got rate limited, try fallback
        if response.status_code == 403:
            data = response.json() if response.content else {}
            if "rate limit" in data.get("message", "").lower():
                self._rate_limits[idx].is_limited = True

                logger.info(
                    "rate_limit_hit_trying_fallback",
                    app=app_name,
                )

                # Try to get another adapter
                fallback: tuple[T, int] | None = self._get_next_available_adapter()
                if fallback is not None:
                    adapter, idx = fallback
                    response = await adapter._request(method, path, **kwargs)
                    self._update_rate_limit(idx, response)

        return response

    # TargetAdapter interface - delegate to underlying adapters with fallback

    async def create_repository(
        self,
        *,
        name: str,
        organization: str,
        description: str | None = None,
        private: bool = True,
        default_branch: str = "main",
    ) -> Repository:
        """Create a new repository using an available app."""
        adapter: T
        adapter, idx = self._get_adapter_with_fallback()

        logger.debug(
            "create_repository_using_app",
            app=self._app_configs[idx].display_name,
            name=name,
            organization=organization,
        )

        return await adapter.create_repository(
            name=name,
            organization=organization,
            description=description,
            private=private,
            default_branch=default_branch,
        )

    async def update_repository(
        self,
        repo_id: str,
        *,
        description: str | None = None,
        private: bool | None = None,
        default_branch: str | None = None,
        archived: bool | None = None,
    ) -> Repository:
        """Update a repository using an available app."""
        adapter: T
        adapter, _ = self._get_adapter_with_fallback()
        return await adapter.update_repository(
            repo_id,
            description=description,
            private=private,
            default_branch=default_branch,
            archived=archived,
        )

    async def get_repository(self, repo_id: str) -> Repository | None:
        """Get a repository using an available app."""
        adapter: T
        adapter, _ = self._get_adapter_with_fallback()
        return await adapter.get_repository(repo_id)

    async def list_users(
        self,
        *,
        organization: str | None = None,
        page: int = 1,
        page_size: int = 100,
    ) -> list[User]:
        """List users using an available app."""
        adapter: T
        adapter, _ = self._get_adapter_with_fallback()
        return await adapter.list_users(
            organization=organization,
            page=page,
            page_size=page_size,
        )

    async def verify_credentials(self) -> bool:
        """Verify credentials for all apps.

        Returns:
            True if at least one app has valid credentials.

        Raises:
            AuthenticationError: If all apps have invalid credentials.
        """
        valid_count = 0
        errors = []

        for i, adapter in enumerate(self._adapters):
            try:
                await adapter.verify_credentials()
                valid_count += 1
                logger.debug(
                    "app_credentials_valid",
                    app=self._app_configs[i].display_name,
                )
            except Exception as e:
                errors.append((self._app_configs[i].display_name, str(e)))
                logger.warning(
                    "app_credentials_invalid",
                    app=self._app_configs[i].display_name,
                    error=str(e),
                )

        if valid_count == 0:
            from bb2gh.exceptions import AuthenticationError

            error_summary = "; ".join(f"{name}: {err}" for name, err in errors)
            raise AuthenticationError(f"All GitHub Apps failed authentication: {error_summary}")

        logger.info(
            "multi_app_credentials_verified",
            valid_apps=valid_count,
            total_apps=len(self._adapters),
        )
        return True

    async def close(self) -> None:
        """Close all adapter connections."""
        for adapter in self._adapters:
            await adapter.close()
        logger.debug("multi_app_adapters_closed", count=len(self._adapters))

    async def __aenter__(self) -> MultiAppGitHubAdapter[T]:
        """Async context manager entry."""
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any,
    ) -> None:
        """Async context manager exit."""
        await self.close()

    def __repr__(self) -> str:
        """Return string representation."""
        return (
            f"MultiAppGitHubAdapter("
            f"adapter_class={self._adapter_class.__name__}, "
            f"app_count={len(self._adapters)})"
        )

    def __str__(self) -> str:
        """Return string representation."""
        app_names = [c.display_name for c in self._app_configs]
        return f"MultiAppGitHubAdapter({app_names})"
