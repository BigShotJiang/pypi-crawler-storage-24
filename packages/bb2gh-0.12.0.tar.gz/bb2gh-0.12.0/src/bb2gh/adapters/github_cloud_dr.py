"""GitHub Cloud Data Residency adapter for bb2gh.

Implements the TargetAdapter interface for GitHub Cloud with Data Residency.
Supports regional endpoints like api.github.eu for EU data residency.
"""

from __future__ import annotations

from typing import Literal

import structlog

from bb2gh.adapters.github_base import GitHubBaseAdapter
from bb2gh.exceptions import ConfigurationError

logger = structlog.get_logger(__name__)

# Known regional endpoints
REGIONAL_ENDPOINTS: dict[str, str] = {
    "eu": "https://api.github.eu",
    "us": "https://api.github.com",  # Standard GitHub Cloud
}


class GitHubCloudDRAdapter(GitHubBaseAdapter):
    """GitHub Cloud Data Residency API adapter.

    Connects to regional GitHub Cloud endpoints for data residency compliance.
    Supports EU and other regional data centers.

    Example usage:
        # EU data residency
        adapter = GitHubCloudDRAdapter(
            token="ghp_xxx",
            region="eu",
        )

        # Custom regional endpoint
        adapter = GitHubCloudDRAdapter(
            token="ghp_xxx",
            api_endpoint="https://api.github.example.com",
        )

        async with adapter:
            repo = await adapter.create_repository(
                name="my-repo",
                organization="my-org",
            )
    """

    def __init__(
        self,
        *,
        token: str | None = None,
        app_id: int | None = None,
        private_key: str | None = None,
        installation_id: int | None = None,
        region: Literal["eu", "us"] | None = None,
        api_endpoint: str | None = None,
    ) -> None:
        """Initialize GitHub Cloud DR adapter.

        Args:
            token: Personal Access Token (classic or fine-grained).
            app_id: GitHub App ID.
            private_key: GitHub App private key (PEM format).
            installation_id: GitHub App installation ID.
            region: Regional shortcut ("eu", "us").
            api_endpoint: Custom API endpoint URL.

        Raises:
            ConfigurationError: If configuration is invalid.
        """
        # Validate region/endpoint configuration
        if region is None and api_endpoint is None:
            raise ConfigurationError(
                "GitHub Cloud DR requires either region or api_endpoint. "
                "Provide region='eu' or a custom api_endpoint URL."
            )

        if region is not None and api_endpoint is not None:
            raise ConfigurationError("Specify either region or api_endpoint, not both.")

        self._region = region
        self._custom_endpoint = api_endpoint

        # Resolve the API URL
        if region is not None:
            if region not in REGIONAL_ENDPOINTS:
                raise ConfigurationError(
                    f"Unknown region '{region}'. Valid regions: {', '.join(REGIONAL_ENDPOINTS.keys())}"
                )
            self._api_url = REGIONAL_ENDPOINTS[region]
        else:
            # Validate custom endpoint
            if not api_endpoint or not api_endpoint.startswith("https://"):
                raise ConfigurationError("api_endpoint must be a valid HTTPS URL")
            self._api_url = api_endpoint.rstrip("/")

        # Initialize base class
        super().__init__(
            token=token,
            app_id=app_id,
            private_key=private_key,
            installation_id=installation_id,
        )

        logger.debug(
            "github_cloud_dr_adapter_initialized",
            region=self._region,
            api_url=self._api_url,
        )

    @property
    def api_url(self) -> str:
        """Get the regional API URL."""
        return self._api_url

    @property
    def region(self) -> str | None:
        """Get the configured region (if using region shortcut)."""
        return self._region

    def __repr__(self) -> str:
        """Return string representation without exposing credentials."""
        region_info = f"region={self._region!r}" if self._region else f"endpoint={self._api_url!r}"
        return f"GitHubCloudDRAdapter(auth_type={self.auth_type!r}, {region_info})"
