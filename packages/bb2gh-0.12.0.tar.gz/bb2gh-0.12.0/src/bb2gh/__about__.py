"""Version information for bb2gh."""

__version__ = "0.12.0"
