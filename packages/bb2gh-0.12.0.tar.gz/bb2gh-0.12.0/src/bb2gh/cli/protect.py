"""Branch protection CLI commands.

Provides the `bb2gh protect` command group for branch protection
migration: plan, apply, diff, validate, rollback, promote.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from rich.console import Console


# ---------------------------------------------------------------------------
# Rich reporting helpers
# ---------------------------------------------------------------------------

_STATUS_STYLES: dict[str, str] = {
    "mapped": "[green]mapped[/green]",
    "approximate": "[yellow]approximate[/yellow]",
    "unmapped": "[red]unmapped[/red]",
    "implicit": "[dim]implicit[/dim]",
}


def format_mapping_status(status: str) -> str:
    """Return a Rich-markup string for a mapping status value."""
    return _STATUS_STYLES.get(status, status)


def print_branch_protection_summary(
    plan_data: dict[str, Any],
    *,
    console: Console | None = None,
) -> None:
    """Print a summary panel for a branch protection plan.

    Args:
        plan_data: Serialized BranchProtectionPlan dict.
        console: Optional Rich console.
    """
    from rich.panel import Panel
    from rich.table import Table

    from bb2gh.cli.console import get_shared_console

    if console is None:
        console = get_shared_console()

    mappings = plan_data.get("mappings", [])
    rulesets = plan_data.get("rulesets", [])
    warnings = plan_data.get("warnings", [])

    # Count mapping statuses
    status_counts: dict[str, int] = {}
    for m in mappings:
        s = m.get("status", "unknown")
        status_counts[s] = status_counts.get(s, 0) + 1

    overview = Table(show_header=False, box=None, padding=(0, 2))
    overview.add_column("Label", style="dim")
    overview.add_column("Value")

    overview.add_row("Source", str(plan_data.get("source_repo", "")))
    overview.add_row("Target", str(plan_data.get("target_repo", "")))
    overview.add_row("Rulesets", str(len(rulesets)))
    overview.add_row("Restrictions", str(len(mappings)))

    # Status breakdown
    for status_key in ("mapped", "approximate", "unmapped", "implicit"):
        count = status_counts.get(status_key, 0)
        if count > 0:
            overview.add_row(f"  {status_key}", format_mapping_status(status_key) + f" ({count})")

    overview.add_row("Warnings", str(len(warnings)))

    if plan_data.get("requires_manual_review"):
        overview.add_row("Manual review", "[yellow]Yes[/yellow]")

    if plan_data.get("codeowners_content"):
        overview.add_row("CODEOWNERS", "[green]Generated[/green]")

    if plan_data.get("enable_auto_merge"):
        overview.add_row("Auto-merge", "[cyan]Enabled[/cyan]")

    console.print()
    console.print(
        Panel(overview, title="[bold]Branch Protection Summary[/bold]", border_style="blue")
    )


def print_plan_review(
    plan_data: dict[str, Any],
    *,
    console: Console | None = None,
) -> None:
    """Print a detailed plan review with mapping table and rulesets.

    Args:
        plan_data: Serialized BranchProtectionPlan dict.
        console: Optional Rich console.
    """
    from rich.panel import Panel
    from rich.table import Table

    from bb2gh.cli.console import get_shared_console

    if console is None:
        console = get_shared_console()

    mappings = plan_data.get("mappings", [])
    rulesets = plan_data.get("rulesets", [])
    warnings = plan_data.get("warnings", [])

    # Mapping table
    if mappings:
        table = Table(title="Restriction Mappings", show_lines=True)
        table.add_column("BB Kind", style="cyan")
        table.add_column("Pattern")
        table.add_column("Status", style="bold")
        table.add_column("GH Rule")
        table.add_column("Notes", style="dim", max_width=40)

        for m in mappings:
            source = m.get("source", {})
            target_rule = m.get("target_rule")
            rule_type = target_rule.get("type", "-") if target_rule else "-"
            notes = m.get("notes", "") or ""

            table.add_row(
                str(source.get("kind", "")),
                str(source.get("pattern", "") or source.get("branch_type", "")),
                format_mapping_status(m.get("status", "")),
                rule_type,
                notes[:40] if notes else "",
            )

        console.print()
        console.print(table)
    else:
        console.print()
        console.print("[dim]No restriction mappings found.[/dim]")

    # Rulesets to be created
    if rulesets:
        rs_table = Table(title="Rulesets to Create", show_lines=False)
        rs_table.add_column("Name", style="cyan")
        rs_table.add_column("Enforcement")

        for rs in rulesets:
            enforcement = rs.get("enforcement", "evaluate")
            enforcement_str = (
                "[green]active[/green]"
                if enforcement == "active"
                else f"[yellow]{enforcement}[/yellow]"
            )
            rs_table.add_row(str(rs.get("name", "")), enforcement_str)

        console.print()
        console.print(rs_table)

    # Warnings
    if warnings:
        warning_lines = "\n".join(f"  [yellow]![/yellow] {w}" for w in warnings)
        console.print()
        console.print(
            Panel(
                warning_lines,
                title="[bold yellow]Warnings[/bold yellow]",
                border_style="yellow",
            )
        )


def print_validation_report(
    issues: list[str],
    *,
    console: Console | None = None,
) -> None:
    """Print a validation report for applied rulesets.

    Args:
        issues: List of validation issue strings.
        console: Optional Rich console.
    """
    from rich.panel import Panel
    from rich.table import Table

    from bb2gh.cli.console import get_shared_console

    if console is None:
        console = get_shared_console()

    if not issues:
        console.print()
        console.print(
            Panel(
                "[green]All rulesets passed validation.[/green]",
                title="[bold green]Validation Passed[/bold green]",
                border_style="green",
            )
        )
        return

    table = Table(title=f"Validation Issues ({len(issues)})", show_lines=False)
    table.add_column("#", style="dim", justify="right")
    table.add_column("Issue", style="red")

    for i, issue in enumerate(issues, 1):
        table.add_row(str(i), issue)

    console.print()
    console.print(table)


# ---------------------------------------------------------------------------
# CLI command handlers
# ---------------------------------------------------------------------------


def run_protect_plan(
    source_repo: str,
    target_repo: str,
    *,
    output: str | None = None,
) -> None:
    """Generate a branch protection migration plan.

    Args:
        source_repo: Source BB repo (workspace/repo).
        target_repo: Target GH repo (org/repo).
        output: Optional output file path.
    """
    import asyncio
    import json

    from bb2gh.cli.console import get_shared_console
    from bb2gh.cli.output import print_error, print_success

    # Check license before proceeding
    try:
        from bb2gh.licensing.decorators import LicenseRequiredError
        from bb2gh.licensing.features import require_license

        require_license()
    except LicenseRequiredError as e:
        print_error(str(e))
        import typer

        raise typer.Exit(1) from None

    console = get_shared_console()

    async def _plan() -> dict[str, Any]:
        from bb2gh.adapters.bitbucket_cloud import BitbucketCloudAdapter
        from bb2gh.services.branch_protection import BranchProtectionService

        async with BitbucketCloudAdapter() as source:
            service = BranchProtectionService(
                source_adapter=source,
                target_adapter=None,
            )
            plan = await service.plan(source_repo, target_repo)
            return plan.model_dump(mode="json")

    try:
        plan_data = asyncio.run(_plan())
    except Exception as e:
        print_error(f"Failed to generate plan: {e}")
        return

    plan_json = json.dumps(plan_data, indent=2)

    if output:
        from pathlib import Path

        Path(output).write_text(plan_json)
        print_success(f"Plan saved to {output}")
    else:
        console.print_json(plan_json)

    # Rich summary + detailed review
    print_branch_protection_summary(plan_data, console=console)
    print_plan_review(plan_data, console=console)

    if plan_data.get("requires_manual_review"):
        from bb2gh.cli.output import print_warning

        print_warning("Plan requires manual review before applying")


def run_protect_apply(
    plan_file: str,
    *,
    mode: str = "evaluate",
) -> None:
    """Apply a branch protection plan.

    Args:
        plan_file: Path to plan JSON file.
        mode: Enforcement mode (evaluate or active).
    """
    import asyncio
    import json
    from pathlib import Path

    from bb2gh.cli.output import print_error, print_info, print_success

    # Check license before proceeding
    try:
        from bb2gh.licensing.decorators import LicenseRequiredError
        from bb2gh.licensing.features import require_license

        require_license()
    except LicenseRequiredError as e:
        print_error(str(e))
        import typer

        raise typer.Exit(1) from None

    from bb2gh.models.branch_protection import BranchProtectionPlan, RulesetEnforcement
    from bb2gh.services.branch_protection import BranchProtectionService

    plan_data = json.loads(Path(plan_file).read_text())
    plan = BranchProtectionPlan.model_validate(plan_data)

    # Override enforcement mode if specified
    if mode == "active":
        for ruleset in plan.rulesets:
            ruleset.enforcement = RulesetEnforcement.ACTIVE

    async def _apply() -> list[dict[str, Any]]:
        from bb2gh.adapters.github_cloud import GitHubCloudAdapter

        async with GitHubCloudAdapter() as target:
            service = BranchProtectionService(
                source_adapter=None,
                target_adapter=target,
            )
            return await service.apply(plan)

    try:
        results = asyncio.run(_apply())
    except Exception as e:
        print_error(f"Apply failed: {e}")
        return

    print_success(f"Applied {len(results)} rulesets to {plan.target_repo} (mode: {mode})")
    for r in results:
        print_info(f"  Created ruleset #{r.get('id')}: {r.get('name')}")


def run_protect_diff(
    source_repo: str,
    target_repo: str,
) -> None:
    """Show what branch protection changes would be made.

    Args:
        source_repo: Source BB repo (workspace/repo).
        target_repo: Target GH repo (org/repo).
    """
    import asyncio

    from rich.table import Table

    from bb2gh.cli.console import get_shared_console
    from bb2gh.cli.output import print_error, print_info

    # Check license before proceeding
    try:
        from bb2gh.licensing.decorators import LicenseRequiredError
        from bb2gh.licensing.features import require_license

        require_license()
    except LicenseRequiredError as e:
        print_error(str(e))
        import typer

        raise typer.Exit(1) from None

    console = get_shared_console()

    async def _diff() -> dict[str, Any]:
        from bb2gh.adapters.bitbucket_cloud import BitbucketCloudAdapter
        from bb2gh.services.branch_protection import BranchProtectionService

        async with BitbucketCloudAdapter() as source:
            service = BranchProtectionService(
                source_adapter=source,
                target_adapter=None,
            )
            plan = await service.plan(source_repo, target_repo)
            return plan.model_dump(mode="json")

    try:
        plan_data = asyncio.run(_diff())
    except Exception as e:
        print_error(f"Failed to generate diff: {e}")
        return

    mappings = plan_data.get("mappings", [])
    if not mappings:
        print_info("No branch restrictions found.")
        return

    table = Table(title="Branch Protection Mapping", show_lines=True)
    table.add_column("BB Kind", style="cyan")
    table.add_column("Pattern")
    table.add_column("Status", style="bold")
    table.add_column("GH Rule")
    table.add_column("Notes", style="dim", max_width=40)

    for m in mappings:
        source = m.get("source", {})
        target_rule = m.get("target_rule")
        rule_type = target_rule.get("type", "-") if target_rule else "-"
        notes = m.get("notes", "") or ""

        table.add_row(
            source.get("kind", ""),
            source.get("pattern", "") or source.get("branch_type", ""),
            format_mapping_status(m.get("status", "")),
            rule_type,
            notes[:40] if notes else "",
        )

    console.print()
    console.print(table)
    console.print()


def run_protect_validate(
    plan_file: str,
) -> None:
    """Validate applied rulesets match the plan.

    Args:
        plan_file: Path to plan JSON file.
    """
    import asyncio
    import json
    from pathlib import Path

    from bb2gh.cli.output import print_error

    # Check license before proceeding
    try:
        from bb2gh.licensing.decorators import LicenseRequiredError
        from bb2gh.licensing.features import require_license

        require_license()
    except LicenseRequiredError as e:
        print_error(str(e))
        import typer

        raise typer.Exit(1) from None

    from bb2gh.models.branch_protection import BranchProtectionPlan
    from bb2gh.services.branch_protection import BranchProtectionService

    plan_data = json.loads(Path(plan_file).read_text())
    plan = BranchProtectionPlan.model_validate(plan_data)

    async def _validate() -> list[str]:
        from bb2gh.adapters.github_cloud import GitHubCloudAdapter

        async with GitHubCloudAdapter() as target:
            service = BranchProtectionService(
                source_adapter=None,
                target_adapter=target,
            )
            return await service.validate(plan)

    try:
        issues = asyncio.run(_validate())
    except Exception as e:
        print_error(f"Validation failed: {e}")
        return

    print_validation_report(issues)


def run_protect_rollback(
    target_repo: str,
) -> None:
    """Delete all bb2gh-created rulesets from a repository.

    Args:
        target_repo: Target GH repo (org/repo).
    """
    import asyncio

    from bb2gh.cli.output import print_error, print_success

    # Check license before proceeding
    try:
        from bb2gh.licensing.decorators import LicenseRequiredError
        from bb2gh.licensing.features import require_license

        require_license()
    except LicenseRequiredError as e:
        print_error(str(e))
        import typer

        raise typer.Exit(1) from None

    from bb2gh.services.branch_protection import BranchProtectionService

    async def _rollback() -> None:
        from bb2gh.adapters.github_cloud import GitHubCloudAdapter

        async with GitHubCloudAdapter() as target:
            service = BranchProtectionService(
                source_adapter=None,
                target_adapter=target,
            )
            await service.rollback(target_repo)

    try:
        asyncio.run(_rollback())
    except Exception as e:
        print_error(f"Rollback failed: {e}")
        return

    print_success(f"Rolled back all bb2gh rulesets from {target_repo}")


def run_protect_promote(
    target_repo: str,
) -> None:
    """Promote rulesets from evaluate to active enforcement.

    Args:
        target_repo: Target GH repo (org/repo).
    """
    import asyncio

    from bb2gh.cli.output import print_error, print_success

    # Check license before proceeding
    try:
        from bb2gh.licensing.decorators import LicenseRequiredError
        from bb2gh.licensing.features import require_license

        require_license()
    except LicenseRequiredError as e:
        print_error(str(e))
        import typer

        raise typer.Exit(1) from None

    from bb2gh.services.branch_protection import BranchProtectionService

    async def _promote() -> None:
        from bb2gh.adapters.github_cloud import GitHubCloudAdapter

        async with GitHubCloudAdapter() as target:
            service = BranchProtectionService(
                source_adapter=None,
                target_adapter=target,
            )
            await service.promote(target_repo)

    try:
        asyncio.run(_promote())
    except Exception as e:
        print_error(f"Promote failed: {e}")
        return

    print_success(f"Promoted bb2gh rulesets to active in {target_repo}")
